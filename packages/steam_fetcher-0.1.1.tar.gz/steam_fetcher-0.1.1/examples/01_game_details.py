"""
Получение информации об игре (без API ключа).

Запуск:
    uv run python examples/01_game_details.py
"""

from steam_fetcher import SteamClient

with SteamClient() as client:
    game = client.get_game(730)  # Counter-Strike 2

if game is None:
    print("Игра не найдена")
    raise SystemExit(1)

print(f"Название:    {game.name}")
print(f"Тип:         {game.type}")
print(f"Бесплатная:  {game.is_free}")
print(f"Разработчик: {', '.join(game.developers)}")
print(f"Издатель:    {', '.join(game.publishers)}")
print(f"Возраст:     {game.required_age}+")

if game.price:
    print(f"Цена:        {game.price.final_formatted}")
    if game.price.discount_percent > 0:
        print(f"Скидка:      {game.price.discount_percent}%")

if game.platforms:
    platforms = []
    if game.platforms.windows:
        platforms.append("Windows")
    if game.platforms.mac:
        platforms.append("macOS")
    if game.platforms.linux:
        platforms.append("Linux")
    print(f"Платформы:   {', '.join(platforms)}")

if game.metacritic:
    print(f"Metacritic:  {game.metacritic.score}")

print(f"DLC:         {game.dlc_count}")
print(f"Достижения:  {game.achievements}")
print(f"Жанры:       {', '.join(g.description for g in game.genres)}")
print(f"Категории:   {', '.join(c.description for c in game.categories[:5])}")

if game.release_date:
    print(f"Дата выхода: {game.release_date.date}")

print(f"Языков:      {len(game.supported_languages)}")
