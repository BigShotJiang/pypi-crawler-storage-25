from __future__ import annotations

import argparse
import sys
import os

import cv2

from img2sktch.sketch import PencilSketch, EdgeSketch, HatchSketch
from img2sktch.contours import image_to_contours, contours_to_svg, contours_to_arduino
from img2sktch import io as img_io
from img2sktch.transform import resize


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="img2sktch",
        description="Convert an image to a pencil sketch or extract contours.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    sub = p.add_subparsers(dest="command", required=True)

    # --- sketch subcommand ---
    sk = sub.add_parser("sketch", help="Apply a sketch effect and save the result.")
    sk.add_argument("input", help="Input image path or - for stdin bytes.")
    sk.add_argument("output", help="Output image path.")
    sk.add_argument(
        "--mode",
        choices=["pencil", "edge", "hatch"],
        default="pencil",
        help="Sketch mode.",
    )
    sk.add_argument("--blur-sigma", type=int, default=21)
    sk.add_argument("--sharpen", type=int, default=None, metavar="VALUE")
    sk.add_argument("--canny-t1", type=int, default=80)
    sk.add_argument("--canny-t2", type=int, default=160)
    sk.add_argument("--hatch-directions", type=int, default=4)
    sk.add_argument("--hatch-spacing", type=int, default=6)
    sk.add_argument("--scale", type=float, default=None)
    sk.add_argument("--width", type=int, default=None)
    sk.add_argument("--height", type=int, default=None)

    # --- contours subcommand ---
    ct = sub.add_parser("contours", help="Extract contours and export SVG or Arduino code.")
    ct.add_argument("input", help="Input image path.")
    ct.add_argument("output", help="Output path (.svg or .ino).")
    ct.add_argument("--mode", choices=["pencil", "edge"], default="pencil")
    ct.add_argument("--simplification", type=float, default=1.0)
    ct.add_argument("--canny-t1", type=int, default=50)
    ct.add_argument("--canny-t2", type=int, default=150)
    ct.add_argument("--pen-diameter", type=float, default=2.0)
    ct.add_argument("--max-width", type=int, default=2000)
    ct.add_argument("--multiplier", type=float, default=4.5)
    ct.add_argument("--scale", type=float, default=1.0)

    return p


def _load_input(path: str):
    if path == "-":
        data = sys.stdin.buffer.read()
        return img_io.from_bytes(data)
    return img_io.from_file(path)


def cmd_sketch(args: argparse.Namespace) -> None:
    frame = _load_input(args.input)

    if args.scale or args.width or args.height:
        frame = resize(frame, width=args.width, height=args.height, scale=args.scale)

    if args.mode == "pencil":
        sketcher = PencilSketch(blur_sigma=args.blur_sigma, sharpen_value=args.sharpen)
    elif args.mode == "edge":
        sketcher = EdgeSketch(threshold1=args.canny_t1, threshold2=args.canny_t2)
    else:
        sketcher = HatchSketch(
            num_directions=args.hatch_directions, spacing=args.hatch_spacing
        )

    result = sketcher(frame)
    img_io.to_file(result, args.output)
    print(f"saved {args.output}")


def cmd_contours(args: argparse.Namespace) -> None:
    frame = _load_input(args.input)

    if args.mode == "pencil":
        frame = PencilSketch()(frame)
    else:
        frame = EdgeSketch(threshold1=args.canny_t1, threshold2=args.canny_t2)(frame)

    contours = image_to_contours(
        frame,
        simplification=args.simplification,
        canny_threshold1=args.canny_t1,
        canny_threshold2=args.canny_t2,
        pen_diameter=args.pen_diameter,
        max_width=args.max_width,
        multiplier=args.multiplier,
    )

    out = args.output
    if out.endswith(".svg"):
        data = contours_to_svg(contours)
        with open(out, "w") as f:
            f.write(data)
    elif out.endswith(".ino"):
        data = contours_to_arduino(contours, scale=args.scale)
        with open(out, "w") as f:
            f.write(data)
    else:
        print("Unknown output format. Use .svg or .ino", file=sys.stderr)
        sys.exit(1)

    print(f"saved {out} ({len(contours)} contours)")


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "sketch":
        cmd_sketch(args)
    elif args.command == "contours":
        cmd_contours(args)


if __name__ == "__main__":
    main()
