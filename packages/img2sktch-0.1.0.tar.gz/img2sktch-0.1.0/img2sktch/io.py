from __future__ import annotations

import io
import typing

import cv2
import numpy as np
from PIL import Image


def from_file(path: str) -> np.ndarray:
    """Load an image from disk into a BGR numpy array."""
    img = cv2.imread(path)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return img


def from_bytes(data: typing.Union[bytes, bytearray, io.IOBase]) -> np.ndarray:
    """Load an image from a bytes-like object or a file-like object.

    Accepts raw bytes, bytearray, or any object with a .read() method
    (e.g. BytesIO, open file handle).
    """
    if hasattr(data, "read"):
        data = data.read()
    buf = np.frombuffer(bytes(data), dtype=np.uint8)
    img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image from bytes.")
    return img


def from_pil(img: Image.Image) -> np.ndarray:
    """Convert a PIL Image to a BGR numpy array."""
    rgb = np.array(img.convert("RGB"))
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def from_numpy(arr: np.ndarray) -> np.ndarray:
    """Ensure the array is in a usable uint8 BGR form.

    Accepts grayscale (H, W) or color (H, W, 3/4) arrays.
    """
    if arr.dtype != np.uint8:
        arr = np.clip(arr, 0, 255).astype(np.uint8)
    if arr.ndim == 2:
        return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)
    if arr.shape[2] == 4:
        return cv2.cvtColor(arr, cv2.COLOR_BGRA2BGR)
    return arr


def to_file(img: np.ndarray, path: str, quality: int = 95) -> None:
    """Save a BGR numpy array to disk.

    Quality applies to JPEG output (1-100).
    """
    params: typing.List[int] = []
    if path.lower().endswith((".jpg", ".jpeg")):
        params = [cv2.IMWRITE_JPEG_QUALITY, quality]
    elif path.lower().endswith(".png"):
        compress = max(0, min(9, (100 - quality) // 10))
        params = [cv2.IMWRITE_PNG_COMPRESSION, compress]
    ok = cv2.imwrite(path, img, params)
    if not ok:
        raise IOError(f"Failed to write image to {path}")


def to_bytes(
    img: np.ndarray,
    fmt: str = ".png",
    quality: int = 95,
) -> bytes:
    """Encode a BGR numpy array to raw image bytes.

    Args:
        img: BGR image array.
        fmt: File extension including dot, e.g. '.jpg' or '.png'.
        quality: JPEG quality (1-100) or PNG compression level proxy.

    Returns:
        Raw encoded bytes.
    """
    params: typing.List[int] = []
    if fmt.lower() in (".jpg", ".jpeg"):
        params = [cv2.IMWRITE_JPEG_QUALITY, quality]
    elif fmt.lower() == ".png":
        compress = max(0, min(9, (100 - quality) // 10))
        params = [cv2.IMWRITE_PNG_COMPRESSION, compress]
    ok, buf = cv2.imencode(fmt, img, params)
    if not ok:
        raise ValueError(f"Failed to encode image as {fmt}")
    return buf.tobytes()


def to_pil(img: np.ndarray) -> Image.Image:
    """Convert a BGR numpy array to a PIL Image (RGB mode)."""
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb)


def to_numpy(img: np.ndarray) -> np.ndarray:
    """Return the image as-is (identity, for uniform pipeline code)."""
    return img


def to_bytesio(img: np.ndarray, fmt: str = ".png", quality: int = 95) -> io.BytesIO:
    """Encode a BGR image and wrap it in a BytesIO buffer."""
    return io.BytesIO(to_bytes(img, fmt=fmt, quality=quality))
