from __future__ import annotations

import typing
import cv2
import numpy as np


def resize(
    img: np.ndarray,
    width: typing.Optional[int] = None,
    height: typing.Optional[int] = None,
    scale: typing.Optional[float] = None,
    interpolation: int = cv2.INTER_LANCZOS4,
) -> np.ndarray:
    """Resize an image by target dimensions or a scale factor.

    Exactly one of (width, height) or scale must be provided.
    If only width or only height is given, the other is computed to
    preserve the aspect ratio.
    """
    h, w = img.shape[:2]
    if scale is not None:
        new_w = int(w * scale)
        new_h = int(h * scale)
    elif width is not None and height is not None:
        new_w, new_h = width, height
    elif width is not None:
        new_w = width
        new_h = int(h * width / w)
    elif height is not None:
        new_h = height
        new_w = int(w * height / h)
    else:
        raise ValueError("Provide scale, width, height, or width+height.")
    return cv2.resize(img, (new_w, new_h), interpolation=interpolation)


def crop_center(img: np.ndarray, width: int, height: int) -> np.ndarray:
    """Crop the center region of the given size from an image."""
    h, w = img.shape[:2]
    x0 = max((w - width) // 2, 0)
    y0 = max((h - height) // 2, 0)
    return img[y0 : y0 + height, x0 : x0 + width]


def pad_to_square(
    img: np.ndarray,
    fill: typing.Union[int, typing.Tuple[int, int, int]] = 255,
) -> np.ndarray:
    """Pad an image with a solid color so that it becomes square."""
    h, w = img.shape[:2]
    side = max(h, w)
    if img.ndim == 3:
        canvas = np.full((side, side, img.shape[2]), fill, dtype=img.dtype)
    else:
        canvas = np.full((side, side), fill if isinstance(fill, int) else fill[0], dtype=img.dtype)
    y0 = (side - h) // 2
    x0 = (side - w) // 2
    canvas[y0 : y0 + h, x0 : x0 + w] = img
    return canvas


def rotate(
    img: np.ndarray,
    angle: float,
    expand: bool = True,
    fill: typing.Union[int, typing.Tuple[int, int, int]] = 255,
) -> np.ndarray:
    """Rotate an image by the given angle (degrees, counter-clockwise).

    If expand is True the canvas is enlarged to fit the rotated image.
    """
    h, w = img.shape[:2]
    cx, cy = w / 2, h / 2
    M = cv2.getRotationMatrix2D((cx, cy), angle, 1.0)

    if expand:
        cos = abs(M[0, 0])
        sin = abs(M[0, 1])
        new_w = int(h * sin + w * cos)
        new_h = int(h * cos + w * sin)
        M[0, 2] += (new_w - w) / 2
        M[1, 2] += (new_h - h) / 2
        dsize = (new_w, new_h)
    else:
        dsize = (w, h)

    border_value: typing.Any = fill if img.ndim == 3 else (fill if isinstance(fill, int) else fill[0])
    return cv2.warpAffine(img, M, dsize, borderMode=cv2.BORDER_CONSTANT, borderValue=border_value)


def auto_contrast(img: np.ndarray) -> np.ndarray:
    """Stretch pixel intensities to the full 0-255 range (per channel)."""
    if img.ndim == 2:
        lo, hi = img.min(), img.max()
        if hi == lo:
            return img.copy()
        return cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    channels = cv2.split(img)
    stretched = [cv2.normalize(c, None, 0, 255, cv2.NORM_MINMAX) for c in channels]
    return cv2.merge(stretched).astype(np.uint8)
