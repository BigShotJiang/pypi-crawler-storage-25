from __future__ import annotations

import typing
import cv2
import numpy as np


Contour = typing.List[typing.Tuple[int, int]]


def image_to_contours(
    img: np.ndarray,
    simplification: float = 0.0,
    canny_threshold1: int = 50,
    canny_threshold2: int = 150,
    pen_diameter: float = 2.0,
    max_width: int = 2000,
    multiplier: float = 4.5,
    min_area: float = 10.0,
) -> typing.List[Contour]:
    """Extract and scale contours from a sketch image.

    Returns a list of polylines, each a list of (x, y) integer tuples,
    centered around the origin and scaled to fit within max_width * multiplier.
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, canny_threshold1, canny_threshold2)

    kernel_size = max(1, int(pen_diameter * 2))
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    edges = cv2.dilate(edges, kernel, iterations=1)

    raw_contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

    h, w = img.shape[:2]
    scale = multiplier * max_width / max(w, h)

    simplified: typing.List[Contour] = []
    for contour in raw_contours:
        if cv2.contourArea(contour) < min_area:
            continue
        if simplification > 0:
            epsilon = simplification * cv2.arcLength(contour, True) / 100.0
            contour = cv2.approxPolyDP(contour, epsilon, True)
        pts = contour.squeeze()
        if pts.ndim == 1:
            pts = pts[np.newaxis, :]
        scaled: Contour = [
            (int(x * scale), int(multiplier * max_width - y * scale))
            for x, y in pts
        ]
        simplified.append(scaled)

    all_pts = [pt for c in simplified for pt in c]
    if not all_pts:
        return simplified

    xs = [p[0] for p in all_pts]
    ys = [p[1] for p in all_pts]
    cx = (min(xs) + max(xs)) // 2
    cy = (min(ys) + max(ys)) // 2

    return [[(x - cx, y - cy) for x, y in c] for c in simplified]


def contours_to_svg(
    contours: typing.List[Contour],
    width: int = 800,
    height: int = 800,
    stroke: str = "black",
    stroke_width: float = 1.0,
    background: str = "white",
) -> str:
    """Render contours to an SVG string."""
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="-{width//2} -{height//2} {width} {height}">',
        f'<rect x="-{width//2}" y="-{height//2}" width="{width}" height="{height}" fill="{background}"/>',
    ]
    for contour in contours:
        if len(contour) < 2:
            continue
        d = "M " + " L ".join(f"{x},{-y}" for x, y in contour)
        lines.append(
            f'<path d="{d}" fill="none" stroke="{stroke}" stroke-width="{stroke_width}"/>'
        )
    lines.append("</svg>")
    return "\n".join(lines)


def contours_to_arduino(
    contours: typing.List[Contour],
    scale: float = 1.0,
    offset_x: float = 0.0,
    offset_y: float = 0.0,
) -> str:
    """Render contours as an Arduino .ino sketch for a 3-stepper pen plotter."""
    header = """\
#include <Stepper.h>
#include <math.h>

#define STEPS_PER_REV 2048
#define rayon 800
#define step_dyal_angle 1
#define steps_kolhom (360 / step_dyal_angle)
#define max_step 4500
#define half_max 2250

int motor1[] = {13, 12, 11, 10};
int motor2[] = {9, 8, 7, 6};
int motor3[] = {5, 4, 3, 2};

Stepper stepper1(STEPS_PER_REV, motor1[0], motor1[2], motor1[1], motor1[3]);
Stepper stepper2(STEPS_PER_REV, motor2[0], motor2[2], motor2[1], motor2[3]);
Stepper stepper3(STEPS_PER_REV, motor3[0], motor3[2], motor3[1], motor3[3]);

void moveSteppers(Stepper& stepperX, Stepper& stepperY, int dx, int dy) {
    int steps = fmax(abs(dx), abs(dy));
    float x_step = (float)dx / steps;
    float y_step = (float)dy / steps;
    float x_acc = 0, y_acc = 0;
    for (int i = 0; i < steps; i++) {
        x_acc += x_step; y_acc += y_step;
        if (round(x_acc) != 0) { stepperX.step(round(x_acc)); x_acc -= round(x_acc); }
        if (round(y_acc) != 0) { stepperY.step(round(y_acc)); y_acc -= round(y_acc); }
    }
}

class Cursor {
  private:
    Stepper& penuse; Stepper& stepperX; Stepper& stepperY;
    float o_x, o_y;
  public:
    Cursor(Stepper& p, Stepper& sx, Stepper& sy, float xx=0, float yy=0)
        : penuse(p), stepperX(sx), stepperY(sy), o_x(xx), o_y(yy) {}
    void move(float x, float y) {
        int dx = round(x - o_x); int dy = round(y - o_y);
        o_x = x; o_y = y;
        moveSteppers(stepperX, stepperY, dx, -dy);
    }
    void penup()   { penuse.step(150);  }
    void pendown() { penuse.step(-150); }
};

void setup() {
    stepper1.setSpeed(10); stepper2.setSpeed(10); stepper3.setSpeed(10);
    Cursor cursor(stepper1, stepper2, stepper3);
    Serial.begin(115200);
    cursor.penup();
    stepper2.step(2000); stepper3.step(2000);
"""
    body_lines = []
    for i, contour in enumerate(contours):
        if len(contour) < 2:
            continue
        x0, y0 = contour[0]
        body_lines.append(
            f"    cursor.move({x0 * scale + offset_x:.1f}, {y0 * scale + offset_y:.1f});"
        )
        body_lines.append("    cursor.pendown();")
        for x, y in contour[1:]:
            body_lines.append(
                f"    cursor.move({x * scale + offset_x:.1f}, {y * scale + offset_y:.1f});"
            )
        body_lines.append("    cursor.penup();")
        body_lines.append("")

    footer = """\
    cursor.move(0, 0);
    stepper2.step(-2000); stepper3.step(-2000);
}

void loop() {}
"""
    return header + "\n".join(body_lines) + "\n" + footer
