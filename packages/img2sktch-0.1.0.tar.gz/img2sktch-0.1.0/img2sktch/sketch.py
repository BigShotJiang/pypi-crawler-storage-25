from __future__ import annotations

import typing
import cv2
import numpy as np


class PencilSketch:
    """Classic dodge-blend pencil sketch effect."""

    def __init__(
        self,
        blur_sigma: int = 21,
        ksize: typing.Tuple[int, int] = (0, 0),
        sharpen_value: typing.Optional[int] = None,
        kernel: typing.Optional[np.ndarray] = None,
    ) -> None:
        self.blur_sigma = blur_sigma
        self.ksize = ksize
        self.sharpen_value = sharpen_value
        if kernel is not None:
            self.kernel = kernel
        elif sharpen_value is not None:
            self.kernel = np.array([[0, -1, 0], [-1, sharpen_value, -1], [0, -1, 0]])
        else:
            self.kernel = None

    def _to_gray(self, frame: np.ndarray) -> np.ndarray:
        if frame.ndim == 2:
            gray = frame
        else:
            gray = np.dot(frame[..., :3], [0.299, 0.587, 0.114]).astype(np.uint8)
        return np.stack((gray,) * 3, axis=-1)

    def _dodge(self, front: np.ndarray, back: np.ndarray) -> np.ndarray:
        with np.errstate(divide="ignore", invalid="ignore"):
            result = back * 255.0 / (255.0 - front)
        result = np.where(front == 255, 255.0, result)
        return np.clip(result, 0, 255).astype(np.uint8)

    def _sharpen(self, image: np.ndarray) -> np.ndarray:
        if self.kernel is None:
            return image
        inverted = 255 - image
        return 255 - cv2.filter2D(src=inverted, ddepth=-1, kernel=self.kernel)

    def __call__(self, frame: np.ndarray) -> np.ndarray:
        grayscale = self._to_gray(frame)
        inverted = 255 - grayscale
        blurred = cv2.GaussianBlur(inverted, ksize=self.ksize, sigmaX=self.blur_sigma)
        dodged = self._dodge(blurred, grayscale)
        return self._sharpen(dodged)


class EdgeSketch:
    """Canny-based edge sketch that produces a clean white-on-black line drawing."""

    def __init__(
        self,
        threshold1: int = 80,
        threshold2: int = 160,
        blur_ksize: int = 5,
        invert: bool = True,
    ) -> None:
        self.threshold1 = threshold1
        self.threshold2 = threshold2
        self.blur_ksize = blur_ksize
        self.invert = invert

    def __call__(self, frame: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
        blurred = cv2.GaussianBlur(gray, (self.blur_ksize, self.blur_ksize), 0)
        edges = cv2.Canny(blurred, self.threshold1, self.threshold2)
        result = 255 - edges if self.invert else edges
        return cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)


class HatchSketch:
    """Produces a hatching effect by overlaying directional line patterns on brightness regions."""

    def __init__(
        self,
        num_directions: int = 4,
        spacing: int = 6,
        angle_offset: float = 0.0,
        blur_sigma: int = 3,
    ) -> None:
        self.num_directions = num_directions
        self.spacing = spacing
        self.angle_offset = angle_offset
        self.blur_sigma = blur_sigma

    def __call__(self, frame: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame.copy()
        gray = cv2.GaussianBlur(gray, (0, 0), self.blur_sigma)

        h, w = gray.shape
        canvas = np.ones((h, w), dtype=np.uint8) * 255
        angles = [
            self.angle_offset + i * (180.0 / self.num_directions)
            for i in range(self.num_directions)
        ]
        thresholds = np.linspace(50, 220, self.num_directions + 1)

        for idx, angle in enumerate(angles):
            mask = gray < thresholds[idx]
            rad = np.deg2rad(angle)
            dx, dy = int(np.cos(rad) * self.spacing), int(np.sin(rad) * self.spacing)
            for y in range(0, h, self.spacing):
                for x in range(0, w, self.spacing):
                    if mask[y, x]:
                        x2 = min(w - 1, x + dx * 4)
                        y2 = min(h - 1, y + dy * 4)
                        cv2.line(canvas, (x, y), (x2, y2), 0, 1)

        return cv2.cvtColor(canvas, cv2.COLOR_GRAY2BGR)
