"""
tria-mcp — tria.ai MCP server and CLI.

  tria-mcp              Start the MCP server (stdio)
  tria-mcp login        Authenticate and store credentials
  tria-mcp logout       Remove stored credentials
  tria-mcp whoami       Show the logged-in account
  tria-mcp --transport http --port 9100   Start HTTP server

Environment:
    TRIA_API_URL   tria.ai API base URL (default: https://agent.obs.leapxpert.io)
    TRIA_API_KEY   API token — overrides stored credentials (CI/CD, service accounts)
"""
import sys

CLI_COMMANDS = {"login", "logout", "whoami"}


def main():
    if len(sys.argv) > 1 and sys.argv[1] in CLI_COMMANDS:
        from mcp_server.cli import COMMANDS
        COMMANDS[sys.argv[1]]()
        return

    import argparse
    from mcp_server.server import mcp

    parser = argparse.ArgumentParser(
        prog="tria-mcp",
        description="tria.ai MCP server",
        epilog="Auth commands: tria-mcp login | logout | whoami",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="stdio",
        help="Transport mode (default: stdio)",
    )
    parser.add_argument("--host", default="127.0.0.1", help="HTTP host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=9100, help="HTTP port (default: 9100)")
    args = parser.parse_args()

    if args.transport == "stdio":
        import os
        from mcp_server.credentials import load as _load_creds
        if not os.environ.get("TRIA_API_KEY") and not _load_creds():
            sys.stderr.write(
                "Not authenticated. Run: tria-mcp login\n"
                "Or set TRIA_API_KEY env var.\n"
            )
            sys.exit(1)
        mcp.run(transport="stdio")
    else:
        mcp.run(transport="http", host=args.host, port=args.port)


if __name__ == "__main__":
    main()
