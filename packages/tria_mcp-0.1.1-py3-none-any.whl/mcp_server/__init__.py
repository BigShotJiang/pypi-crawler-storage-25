"""
tria.ai MCP Server

Exposes Commander.ai SRE capabilities as MCP tools for use in
Cursor, Claude Code, VS Code Copilot, OpenAI Codex, and any
MCP-compatible client.

Tools communicate with the Commander.ai REST API via HTTP, so the
server works both when mounted in-process (FastAPI mount) and when
running standalone (stdio/HTTP transport for IDE integrations).
"""
from mcp_server.server import mcp
from mcp_server.server import create_mcp_app
from mcp_server.client import close_client

__all__ = ["mcp", "create_mcp_app", "close_client"]
