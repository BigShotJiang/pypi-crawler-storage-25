"""tria CLI — login / logout / whoami."""
from __future__ import annotations

import sys
import getpass

import httpx

from mcp_server import credentials


def _api_base() -> str:
    import os
    base = os.environ.get("TRIA_API_URL", "https://agent.obs.leapxpert.io").rstrip("/")
    if not base.endswith("/api/v1"):
        base += "/api/v1"
    return base


def cmd_login() -> None:
    base = _api_base()
    settings_url = base.replace("/api/v1", "") + "/settings/tokens"

    print(f"\n  Create a Personal Access Token at:\n")
    print(f"    {settings_url}\n")

    try:
        token = getpass.getpass("  Paste your token (pat_...): ").strip()
    except (KeyboardInterrupt, EOFError):
        print("\n  Cancelled.")
        sys.exit(1)

    if not token:
        print("  No token entered.")
        sys.exit(1)

    # Verify token and fetch email
    print("  Verifying...", end="", flush=True)
    try:
        resp = httpx.get(
            f"{base}/clusters",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10.0,
        )
        if resp.status_code == 401:
            print("\n  Invalid token — check the value and try again.")
            sys.exit(1)
        if resp.status_code == 403:
            print("\n  Token valid but no cluster access — saving anyway.")
        resp.raise_for_status()
    except httpx.ConnectError:
        print(f"\n  Cannot reach {base} — is the server running?")
        sys.exit(1)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code not in (200, 403):
            print(f"\n  Verification failed: {exc}")
            sys.exit(1)

    # Fetch email from /me if available, fall back to token prefix
    email = _fetch_email(base, token)
    credentials.save(token, email)
    print(f"\r  Logged in as {email}          \n")


def _fetch_email(base: str, token: str) -> str:
    try:
        resp = httpx.get(
            f"{base}/users/me",
            headers={"Authorization": f"Bearer {token}"},
            timeout=5.0,
        )
        if resp.is_success:
            return resp.json().get("email", "unknown")
    except Exception:
        pass
    return "unknown"


def cmd_logout() -> None:
    credentials.delete()
    print("Logged out.")


def cmd_whoami() -> None:
    token = credentials.load()
    if not token:
        print("Not logged in. Run: tria-mcp login")
        sys.exit(1)
    email = credentials.load_email() or "unknown"
    print(f"Logged in as {email}")


COMMANDS = {
    "login": cmd_login,
    "logout": cmd_logout,
    "whoami": cmd_whoami,
}


def main() -> None:
    cmd = sys.argv[1] if len(sys.argv) > 1 else None
    if cmd not in COMMANDS:
        print(f"Usage: tria <{'|'.join(COMMANDS)}>")
        sys.exit(1)
    COMMANDS[cmd]()
