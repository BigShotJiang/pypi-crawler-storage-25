"""HTTP client for calling the Commander.ai REST API.

Base URL resolution: TRIA_API_URL env var (same as Settings UI),
falls back to https://agent.obs.leapxpert.io.

Token resolution (in priority order):
1. Per-request Bearer token from MCP HTTP headers (remote HTTP transport)
2. TRIA_API_KEY environment variable (stdio transport, CI/CD)
3. ~/.tria/credentials.json written by `tria login`
"""
from __future__ import annotations

import functools
import json
import os
import logging
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_ERROR_HINTS = {
    401: "Authentication failed — check your token (pat_… or sk_…). Run `tria login` or set TRIA_API_KEY.",
    403: "Permission denied — your token does not have the required role for this operation. (Requires editor role or higher)",
    404: "Resource not found.",
    429: "Rate limited — try again shortly.",
}


@functools.lru_cache(maxsize=1)
def _base_url() -> str:
    base = os.environ.get("TRIA_API_URL", "https://agent.obs.leapxpert.io").rstrip("/")
    if not base.endswith("/api/v1"):
        base += "/api/v1"
    return base


# ---------------------------------------------------------------------------
# Shared httpx client (connection pooling)
# ---------------------------------------------------------------------------

_client: httpx.AsyncClient | None = None
_DEFAULT_LIMITS = httpx.Limits(max_connections=20, max_keepalive_connections=10)
_DEFAULT_TIMEOUT = httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=5.0)


def _get_client() -> httpx.AsyncClient:
    """Return a shared httpx client, creating it lazily on first use."""
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(
            timeout=_DEFAULT_TIMEOUT,
            limits=_DEFAULT_LIMITS,
        )
    return _client


async def close_client() -> None:
    """Close the shared httpx client. Call on process shutdown."""
    global _client
    if _client is not None and not _client.is_closed:
        await _client.aclose()
        _client = None


def _resolve_token() -> str:
    """Get the auth token for the current request.

    Priority:
      1. Authorization header from the inbound MCP HTTP request (per-user)
      2. TRIA_API_KEY env var (stdio mode, CI/CD)
      3. ~/.tria/credentials.json written by `tria login`
    """
    try:
        from fastmcp.server.dependencies import get_http_headers
        headers = get_http_headers(include={"authorization"})
        auth = headers.get("authorization", "")
        if auth.lower().startswith("bearer "):
            return auth.split(None, 1)[1]
    except Exception:
        pass  # Not in an HTTP request context (stdio mode)

    if key := os.environ.get("TRIA_API_KEY"):
        return key

    from mcp_server.credentials import load as _load_creds
    return _load_creds() or ""


def _headers() -> dict[str, str]:
    h = {"Content-Type": "application/json"}
    token = _resolve_token()
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def _sse_headers() -> dict[str, str]:
    h = _headers()
    h["Accept"] = "text/event-stream"
    return h


def _raise_friendly(resp: httpx.Response) -> None:
    """Translate HTTP errors into concise, user-facing messages."""
    if resp.is_success:
        return
    hint = _ERROR_HINTS.get(resp.status_code, "")
    try:
        detail = resp.json().get("detail", "")
    except Exception:
        detail = resp.text[:200] if resp.text else ""
    msg = f"{resp.status_code} {resp.reason_phrase}"
    if hint:
        msg = f"{msg} — {hint}"
    if detail:
        msg = f"{msg} ({detail})"
    raise httpx.HTTPStatusError(msg, request=resp.request, response=resp)


def _safe_json(resp: httpx.Response) -> dict | list:
    """Parse JSON, raising a clear error on non-JSON responses."""
    ct = resp.headers.get("content-type", "")
    if "json" not in ct:
        raise ValueError(
            f"Expected JSON response but got {ct or 'unknown content-type'}: "
            f"{resp.text[:200]}"
        )
    return resp.json()


# ---------------------------------------------------------------------------
# Standard request helpers
# ---------------------------------------------------------------------------

async def api_get(path: str, params: dict[str, Any] | None = None) -> dict | list:
    """GET request to the Commander.ai API."""
    client = _get_client()
    try:
        resp = await client.get(
            f"{_base_url()}{path}",
            params={k: v for k, v in (params or {}).items() if v is not None},
            headers=_headers(),
        )
    except httpx.ConnectError:
        raise ConnectionError(
            f"Cannot reach Commander.ai at {_base_url()} — is the server running?"
        )
    except httpx.TimeoutException:
        raise TimeoutError(f"Request to {path} timed out after 30s.")
    _raise_friendly(resp)
    return _safe_json(resp)


async def api_post(
    path: str,
    json_body: dict[str, Any] | None = None,
    timeout: float = 600.0,
) -> dict | list:
    """POST request to the Commander.ai API."""
    client = _get_client()
    try:
        resp = await client.post(
            f"{_base_url()}{path}",
            json=json_body or {},
            headers=_headers(),
            timeout=timeout,
        )
    except httpx.ConnectError:
        raise ConnectionError(
            f"Cannot reach Commander.ai at {_base_url()} — is the server running?"
        )
    except httpx.TimeoutException:
        raise TimeoutError(f"Request to {path} timed out after {timeout:.0f}s.")
    _raise_friendly(resp)
    return _safe_json(resp)


# ---------------------------------------------------------------------------
# SSE streaming consumer
# ---------------------------------------------------------------------------

@dataclass
class SSEResult:
    """Accumulated result from consuming an SSE stream."""
    content: str = ""
    thinking: str = ""
    tool_calls: list[dict] = field(default_factory=list)
    conversation_id: str = ""
    tokens_used: int = 0
    execution_time: float = 0.0
    done_payload: dict = field(default_factory=dict)
    partial: bool = False
    error: str = ""


async def api_post_sse(
    path: str,
    json_body: dict[str, Any] | None = None,
    timeout: float = 600.0,
    ctx: Any | None = None,
) -> SSEResult:
    """POST with SSE streaming — consumes events and returns accumulated result.

    Stays connected for the full duration; heartbeat/progress events from the
    server keep the connection alive.  On timeout or disconnect, returns
    whatever was accumulated (partial=True) instead of raising.

    When ``ctx`` (FastMCP Context) is provided, tool activity and progress are
    forwarded to the MCP client in real time via ``ctx.report_progress()`` and
    ``ctx.info()``, so IDE tooling can display live updates.
    """
    result = SSEResult()
    started = time.monotonic()
    active_tools: dict[str, str] = {}

    timeout_cfg = httpx.Timeout(
        connect=10.0,
        read=30.0,   # per-chunk read timeout (heartbeats arrive every ~8s)
        write=10.0,
        pool=10.0,
    )

    _progress_pct = 0.0

    async def _notify_progress(msg: str, progress: float | None = None) -> None:
        """Forward progress to the MCP client via report_progress.

        Always uses report_progress (not ctx.info) because Claude Code
        only renders notifications/progress, not notifications/message.
        """
        nonlocal _progress_pct
        if ctx is None:
            return
        if progress is not None:
            _progress_pct = progress
        try:
            await ctx.report_progress(
                progress=_progress_pct, total=100.0, message=msg,
            )
        except Exception:
            pass  # Best-effort; don't break the stream

    try:
        # SSE streams hold a connection for minutes; use a dedicated client
        # so we don't block the shared pool's keep-alive slots.
        async with httpx.AsyncClient(timeout=timeout_cfg, limits=_DEFAULT_LIMITS) as client:
            async with client.stream(
                "POST",
                f"{_base_url()}{path}",
                json=json_body or {},
                headers=_sse_headers(),
            ) as resp:
                if not resp.is_success:
                    await resp.aread()
                    _raise_friendly(resp)

                await _notify_progress("Connected — waiting for agent response…")
                tool_count = 0
                _thinking_buf = ""
                _THINKING_FLUSH_LEN = 800

                # NOTE: Simplified SSE parser — assumes each event is a
                # single "data:" line with a JSON payload.  Commander.ai's
                # streaming endpoints never emit multi-line data fields, so
                # a full SSE accumulator is unnecessary here.
                async for raw_line in resp.aiter_lines():
                    elapsed = time.monotonic() - started
                    if elapsed > timeout:
                        result.partial = True
                        result.error = f"Client-side timeout after {timeout:.0f}s"
                        break

                    if not raw_line.startswith("data:"):
                        continue
                    payload = raw_line[5:].strip()
                    if not payload:
                        continue
                    try:
                        event = json.loads(payload)
                    except json.JSONDecodeError:
                        continue

                    etype = event.get("type", "")

                    if etype == "delta":
                        result.content += event.get("content", "")

                    elif etype == "thinking_delta":
                        chunk = event.get("content", "")
                        result.thinking += chunk
                        _thinking_buf += chunk
                        if len(_thinking_buf) >= _THINKING_FLUSH_LEN:
                            line = _thinking_buf.strip().replace("\n", " ")
                            if len(line) > 300:
                                line = line[:300] + "…"
                            await _notify_progress(f"Reasoning: {line}")
                            _thinking_buf = ""

                    elif etype == "tool_activity":
                        tools = event.get("tools", [])
                        status = event.get("status", "")
                        tool_elapsed = event.get("elapsed_seconds", 0)
                        if status == "calling":
                            tool_count += 1
                            for t in tools:
                                active_tools[t] = t
                                await _notify_progress(
                                    f"Calling tool: {t} (#{tool_count})",
                                    progress=min(elapsed / timeout * 80, 80),
                                )
                        elif status == "done":
                            for t in tools:
                                active_tools.pop(t, None)
                                result.tool_calls.append({
                                    "tool": t,
                                    "elapsed_seconds": tool_elapsed,
                                })
                                await _notify_progress(
                                    f"Tool done: {t} ({tool_elapsed}s)",
                                    progress=min(elapsed / timeout * 80, 80),
                                )

                    elif etype == "progress":
                        tool_name = event.get("tool", "")
                        prog_elapsed = event.get("elapsed_seconds", 0)
                        if tool_name:
                            await _notify_progress(
                                f"Running: {tool_name} ({prog_elapsed}s)",
                                progress=min(elapsed / timeout * 80, 80),
                            )

                    elif etype == "done":
                        if _thinking_buf.strip():
                            line = _thinking_buf.strip().replace("\n", " ")
                            if len(line) > 300:
                                line = line[:300] + "…"
                            await _notify_progress(f"Reasoning: {line}")
                        result.done_payload = event
                        result.conversation_id = event.get("conversation_id", "")
                        result.tokens_used = event.get("tokens_used", 0)
                        result.execution_time = time.monotonic() - started
                        if event.get("tool_calls"):
                            result.tool_calls = event["tool_calls"]
                        await _notify_progress("Complete", progress=100.0)
                        break

                    elif etype == "error":
                        result.error = event.get("message", "Unknown streaming error")
                        result.partial = True
                        await _notify_progress(f"Error: {result.error}")
                        break

    except httpx.ConnectError:
        raise ConnectionError(
            f"Cannot reach Commander.ai at {_base_url()} — is the server running?"
        )
    except (httpx.TimeoutException, httpx.ReadError) as exc:
        result.partial = True
        result.execution_time = time.monotonic() - started
        result.error = f"Stream interrupted after {result.execution_time:.0f}s: {type(exc).__name__}"
        for tool_name in active_tools.values():
            result.tool_calls.append({"tool": tool_name, "status": "interrupted"})

    if not result.execution_time:
        result.execution_time = time.monotonic() - started

    return result
