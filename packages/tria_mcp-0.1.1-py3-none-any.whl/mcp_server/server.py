"""
tria.ai MCP Server — FastMCP implementation.

Exposes Commander.ai's SRE capabilities as MCP tools. Each tool is a thin
wrapper around the REST API, so the server works identically whether mounted
inside the FastAPI process or run standalone for IDE integrations.

Server environment:
    TRIA_API_URL  Base URL of the Commander.ai API (default: https://agent.obs.leapxpert.io)

Client-side (set by the user in their MCP client config, stdio only):
    TRIA_API_KEY   SA token (sk_...) for stdio transport
                                 HTTP transport uses Authorization header instead
"""
from __future__ import annotations

import json
import logging
from typing import Annotated

from fastmcp import Context, FastMCP

from mcp_server.client import api_get, api_post, api_post_sse, SSEResult

logger = logging.getLogger(__name__)


class _NoTraceback(logging.Filter):
    """Replace exc_info tracebacks with a single-line exception message."""

    def filter(self, record: logging.LogRecord) -> bool:
        if record.exc_info:
            record.msg = f"{record.msg}: {record.exc_info[1]}"
            record.exc_info = None
            record.exc_text = None
        return True


logging.getLogger("fastmcp").addFilter(_NoTraceback())

from starlette.responses import JSONResponse

mcp = FastMCP(
    "tria-ai",
    instructions=(
        "tria.ai is an AI-native SRE platform. Use these tools to investigate "
        "production issues, query alerts, check cluster health, review SLO "
        "compliance, and access SRE reports. Start with tria_list_clusters to "
        "see available clusters, then use tria_investigate or tria_chat for "
        "deep analysis."
    ),
)


_tool_count: int | None = None


@mcp.custom_route("/health", methods=["GET"])
async def mcp_health(request):
    """Health check — accessible at /mcp/health via a normal browser GET."""
    global _tool_count
    if _tool_count is None:
        _tool_count = len(await mcp.list_tools())
    return JSONResponse({
        "status": "ok",
        "server": "tria-ai",
        "protocol": "mcp",
        "transport": "streamable-http",
        "tools": _tool_count,
    })


# ---------------------------------------------------------------------------
# Tool helpers
# ---------------------------------------------------------------------------

def _fmt_json(data, indent: int = 2, max_items: int | None = None) -> str:
    """Format API response data as a compact readable string."""
    if isinstance(data, list) and max_items and len(data) > max_items:
        data = data[:max_items]
    return json.dumps(data, indent=indent, default=str)


def _format_sse_result(sse: SSEResult, tool_name: str = "") -> str:
    """Format an SSEResult into a clean response.

    Returns just the agent's content plus conversation_id for follow-up.
    Tool calls are already shown as live progress — no need to repeat them.
    On partial results, marks the output as incomplete so the AI client
    does NOT retry.
    """
    parts: list[str] = []

    if sse.content:
        parts.append(sse.content.strip())

    if sse.partial:
        if not sse.content:
            parts.append("The agent was still working when the response was interrupted.")
        parts.append(
            f"\n[Partial result after {sse.execution_time:.0f}s — "
            f"do NOT retry, present the findings above to the user]"
        )

    if sse.conversation_id:
        parts.append(f"\nconversation_id: {sse.conversation_id}")

    return "\n".join(parts) if parts else "No response from agent."


# ---------------------------------------------------------------------------
# Cluster tools
# ---------------------------------------------------------------------------

@mcp.tool(tags={"core"})
async def tria_list_clusters() -> str:
    """List all Kubernetes clusters accessible to your token.

    Returns cluster names, display names, and org assignments. Use a cluster
    name from this list when calling other tools that require a cluster parameter.
    """
    rows = await api_get("/clusters")
    clusters = [
        {"name": r["name"], "display_name": r.get("display_name", ""), "grafana_org": r.get("grafana_org", "")}
        for r in rows
    ]
    if not clusters:
        return "No clusters found. Check that your token has the correct org_roles."
    return _fmt_json(clusters)


# ---------------------------------------------------------------------------
# Investigation / Query tools
# ---------------------------------------------------------------------------

@mcp.tool(tags={"core"})
async def tria_investigate(
    query: Annotated[str, "The SRE question or investigation request (e.g. 'Check p99 latency and error rates in the last 30 minutes')"],
    cluster: Annotated[str, "Target cluster name (from tria_list_clusters)"],
    timeout: Annotated[int, "Max seconds to wait for the investigation (30-600). Higher values allow deeper analysis."] = 600,
    ctx: Context | None = None,
) -> str:
    """Run a one-shot SRE investigation on a cluster.

    The tria.ai agent queries Prometheus metrics, Loki logs, Tempo traces,
    and Kubernetes state to answer your question. Returns structured findings
    including root cause analysis, key findings, and action items.

    Best for: performance checks, incident investigation, health audits,
    anomaly detection, post-deploy verification.
    """
    clamped_timeout = min(max(timeout, 30), 600)

    sse = await api_post_sse(
        "/query/stream",
        json_body={
            "query": query,
            "cluster": cluster,
            "timeout": clamped_timeout,
            "request_source": "mcp",
        },
        timeout=float(clamped_timeout) + 90,
        ctx=ctx,
    )

    parts: list[str] = []

    if sse.tool_calls:
        parts.append("## Tools Executed")
        for tc in sse.tool_calls:
            name = tc.get("tool", "unknown")
            elapsed = tc.get("elapsed_seconds", "")
            parts.append(f"- {name}" + (f" ({elapsed}s)" if elapsed else ""))
        parts.append("")

    if sse.content:
        parts.append(sse.content.strip())

    plan = (sse.done_payload or {}).get("investigation_plan", "")
    if plan:
        parts.append(f"\n**Investigation Plan:** {plan}")

    if sse.partial:
        if not sse.content:
            parts.append("The agent was still working when the response was interrupted.")
        parts.append(
            f"\n[Partial result after {sse.execution_time:.0f}s — "
            f"do NOT retry, present the findings above to the user]"
        )

    meta = f"\n_Tokens: {sse.tokens_used} | Time: {sse.execution_time:.1f}s"
    meta += " | Follow up with /tria-chat for deeper analysis_"
    parts.append(meta)
    return "\n".join(parts)


@mcp.tool(tags={"core"})
async def tria_chat(
    message: Annotated[str, "Your question or follow-up message to the SRE agent"],
    cluster: Annotated[str, "Target cluster name (from tria_list_clusters)"],
    time_range: Annotated[str, "Lookback window: '30m', '1h', '2h', '6h', '1d', etc."] = "1h",
    conversation_id: Annotated[str | None, "Conversation ID from a previous tria_chat response for multi-turn follow-up"] = None,
    ctx: Context | None = None,
) -> str:
    """Chat with the SRE agent about a cluster (multi-turn capable).

    Like tria_investigate but supports follow-up questions. Pass the
    conversation_id from the previous response to continue the same
    conversation thread.

    Best for: iterative debugging, drill-down analysis, asking follow-up
    questions after an initial investigation.
    """
    body: dict = {
        "message": message,
        "cluster": cluster,
        "time_range": time_range,
        "stream": True,
        "request_source": "mcp",
    }
    if conversation_id:
        body["conversation_id"] = conversation_id

    sse = await api_post_sse("/chat", json_body=body, timeout=600.0, ctx=ctx)
    return _format_sse_result(sse, tool_name="tria_chat")


# ---------------------------------------------------------------------------
# Alert tools
# ---------------------------------------------------------------------------

@mcp.tool(tags={"core"})
async def tria_list_alerts(
    cluster: Annotated[str | None, "Filter by cluster name"] = None,
    status: Annotated[str | None, "Filter by status: 'firing', 'resolved', 'pending'"] = None,
    severity: Annotated[str | None, "Filter by severity: 'critical', 'warning', 'info'"] = None,
    service: Annotated[str | None, "Filter by service name (partial match)"] = None,
    limit: Annotated[int, "Max number of alerts to return"] = 20,
) -> str:
    """List recent alerts across your clusters.

    Returns alert name, cluster, service, severity, status, and timestamps.
    Use filters to narrow results. Useful for understanding what's firing
    before diving into an investigation.
    """
    params = {
        "cluster": cluster,
        "status": status,
        "severity": severity,
        "service": service,
        "limit": limit,
    }
    rows = await api_get("/alerts", params=params)
    if not rows:
        return "No alerts found matching the given filters."
    alerts = [
        {
            "alert_id": r.get("alert_id", ""),
            "name": r.get("alert_name", r.get("name", "")),
            "cluster": r.get("cluster", ""),
            "service": r.get("service", ""),
            "severity": r.get("severity", ""),
            "status": r.get("status", ""),
            "started_at": r.get("starts_at", r.get("started_at", "")),
        }
        for r in rows
    ]
    return _fmt_json(alerts, max_items=30)


# ---------------------------------------------------------------------------
# Investigation history tools
# ---------------------------------------------------------------------------

@mcp.tool(tags={"core"})
async def tria_list_investigations(
    cluster: Annotated[str | None, "Filter by cluster name"] = None,
    status: Annotated[str | None, "Filter: 'completed', 'in_progress', 'failed', 'reused'"] = None,
    service: Annotated[str | None, "Filter by service name (partial match)"] = None,
    limit: Annotated[int, "Max results to return"] = 10,
) -> str:
    """List recent automated investigations.

    Returns investigation ID, alert name, status, root cause, confidence,
    and timing. Useful for reviewing what the L0 agent has already analyzed.
    """
    params = {"cluster": cluster, "status": status, "service": service, "limit": limit}
    rows = await api_get("/investigations", params=params)
    if not rows:
        return "No investigations found matching the given filters."
    investigations = [
        {
            "investigation_id": r.get("investigation_id", ""),
            "alert_name": r.get("alert_name", ""),
            "cluster": r.get("cluster", ""),
            "service": r.get("service", ""),
            "status": r.get("status", ""),
            "root_cause": (r.get("root_cause") or "")[:200],
            "confidence": r.get("root_cause_confidence", ""),
            "started_at": r.get("started_at", ""),
        }
        for r in rows
    ]
    return _fmt_json(investigations, max_items=20)


@mcp.tool(tags={"core"})
async def tria_get_investigation(
    investigation_id: Annotated[str, "Investigation UUID (from tria_list_investigations)"],
) -> str:
    """Get full details of a specific investigation.

    Returns the complete investigation including root cause analysis,
    key findings, action items, summary, and tool calls executed.
    Use this after tria_list_investigations to drill into a specific result.
    """
    result = await api_get(f"/investigations/{investigation_id}")
    parts = [f"# Investigation: {result.get('alert_name', 'Unknown')}"]
    parts.append(f"**Cluster:** {result.get('cluster', '')} | **Service:** {result.get('service', '')}")
    parts.append(f"**Status:** {result.get('status', '')} | **Confidence:** {result.get('root_cause_confidence', '')}")
    if result.get("root_cause"):
        parts.append(f"\n## Root Cause\n{result['root_cause']}")
    if result.get("summary"):
        parts.append(f"\n## Summary\n{result['summary']}")
    findings = result.get("key_findings") or []
    if findings:
        parts.append("\n## Key Findings")
        for f in findings:
            parts.append(f"- {f}")
    actions = result.get("action_items") or []
    if actions:
        parts.append("\n## Action Items")
        for i, a in enumerate(actions, 1):
            parts.append(f"{i}. {a}")
    return "\n".join(parts)


@mcp.tool(tags={"investigations"})
async def tria_chat_investigation(
    investigation_id: Annotated[str, "Investigation UUID to chat about"],
    message: Annotated[str, "Your follow-up question about this investigation"],
    conversation_id: Annotated[str | None, "Conversation ID from previous response for multi-turn"] = None,
    ctx: Context | None = None,
) -> str:
    """Chat with the SRE agent in the context of a specific investigation.

    The agent has full context of the investigation's findings, root cause,
    and tool outputs. Ask follow-up questions like 'show me the relevant logs'
    or 'what would happen if we scale up the pods?'
    """
    body: dict = {
        "message": message,
        "stream": True,
        "request_source": "mcp",
    }
    if conversation_id:
        body["conversation_id"] = conversation_id

    sse = await api_post_sse(
        f"/investigations/{investigation_id}/chat",
        json_body=body,
        timeout=600.0,
        ctx=ctx,
    )
    return _format_sse_result(sse, tool_name="tria_chat_investigation")


# ---------------------------------------------------------------------------
# Reporting / Analytics tools
# ---------------------------------------------------------------------------

@mcp.tool(tags={"reports"})
async def tria_get_scorecards(
    cluster_filter: Annotated[str | None, "Filter by cluster name"] = None,
    date: Annotated[str | None, "ISO date for historical scorecards (default: most recent)"] = None,
) -> str:
    """Get service health scorecards.

    Returns a health score (0-100) per service with breakdown across
    availability, latency, error rate, and resource utilization dimensions.
    Useful for getting a quick overview of which services need attention.
    """
    params = {"cluster_filter": cluster_filter, "date": date}
    result = await api_get("/reports/scorecards", params=params)
    if isinstance(result, dict) and result.get("scorecards"):
        scorecards = result["scorecards"]
    elif isinstance(result, list):
        scorecards = result
    else:
        return "No scorecard data available."

    summary = []
    for sc in scorecards[:20]:
        name = sc.get("service", sc.get("name", "unknown"))
        score = sc.get("overall_score", sc.get("score", "N/A"))
        summary.append(f"- **{name}**: {score}/100")
    return "\n".join(summary) if summary else "No scorecard data available."


@mcp.tool(tags={"reports"})
async def tria_get_trends(
    cluster_filter: Annotated[str | None, "Filter by cluster name"] = None,
    period: Annotated[str, "Time period: '7d', '30d', '90d'"] = "7d",
) -> str:
    """Get metric trends and anomaly summary.

    Shows how key metrics (error rates, latency, availability) are trending
    across services — improving, stable, or degrading. Highlights services
    with significant changes.
    """
    params = {"cluster_filter": cluster_filter, "period": period}
    result = await api_get("/reports/trends", params=params)
    return _fmt_json(result, max_items=50)


@mcp.tool(tags={"reports"})
async def tria_get_slo_overview(
    cluster_filter: Annotated[str | None, "Filter by cluster name"] = None,
) -> str:
    """Get SLO (Service Level Objective) compliance overview.

    Returns current SLO status, error budget remaining, and burn rate
    for each service. Highlights services at risk of breaching their SLOs.
    """
    params = {"cluster_filter": cluster_filter}
    result = await api_get("/reports/slo-overview", params=params)
    return _fmt_json(result, max_items=50)


@mcp.tool(tags={"reports"})
async def tria_get_anomalies(
    cluster_filter: Annotated[str | None, "Filter by cluster name"] = None,
    service: Annotated[str | None, "Filter by service name"] = None,
    severity: Annotated[str | None, "Filter: 'critical', 'high', 'warning', 'info'"] = None,
) -> str:
    """Get detected anomalies across services.

    Returns anomalies detected by statistical analysis — sudden spikes,
    drops, or unusual patterns in metrics. Each anomaly includes the
    affected service, metric, severity, and description.
    """
    params = {"cluster_filter": cluster_filter, "service": service, "severity": severity}
    result = await api_get("/reports/anomalies", params=params)
    return _fmt_json(result, max_items=50)


@mcp.tool(tags={"reports"})
async def tria_get_action_items(
    cluster_filter: Annotated[str | None, "Filter by cluster name"] = None,
    status: Annotated[str | None, "Filter: 'open', 'in_progress', 'completed', 'dismissed', 'archived'"] = None,
    service: Annotated[str | None, "Filter by service name"] = None,
) -> str:
    """Get outstanding action items from investigations and reports.

    Returns prioritized action items with assignee, status, source
    investigation, and recommended actions. Useful for tracking
    remediation progress.
    """
    params = {"cluster_filter": cluster_filter, "status": status, "service": service}
    result = await api_get("/reports/action-items", params=params)
    return _fmt_json(result, max_items=50)


# ---------------------------------------------------------------------------
# Dashboard metrics
# ---------------------------------------------------------------------------

@mcp.tool(tags={"core"})
async def tria_dashboard(
) -> str:
    """Get a high-level dashboard summary of your SRE posture.

    Returns alert counts by status, investigation KPIs (total, reuse rate,
    mean time to resolution), and cluster health overview. A good starting
    point for understanding the current state.
    """
    result = await api_get("/metrics/dashboard")
    return _fmt_json(result)


# ---------------------------------------------------------------------------
# On-demand log / metric query tools (no AI, no agent — direct retrieval)
# ---------------------------------------------------------------------------

@mcp.tool(tags={"core"})
async def tria_query_logs(
    cluster: Annotated[str, "Cluster name (from tria_list_clusters)"],
    start: Annotated[str | None, "Start time ISO8601 UTC e.g. '2024-01-01T00:00:00Z'"] = None,
    end: Annotated[str | None, "End time ISO8601 UTC e.g. '2024-01-07T23:59:59Z'"] = None,
    time_range: Annotated[str, "Relative lookback when start/end not given: '30m','1h','6h','7d','30d'"] = "30m",
    logql: Annotated[str | None, "Raw LogQL query (takes priority). e.g. '{app=\"auth\"} |= \"error\"'"] = None,
    service: Annotated[str | None, "Service / app name (simple mode, no logql needed)"] = None,
    namespace: Annotated[str | None, "Kubernetes namespace (simple mode)"] = None,
    level: Annotated[str | None, "Log level filter: 'error', 'warn', 'info' (simple mode)"] = None,
    pattern: Annotated[str | None, "Literal substring that must appear in the log line (simple mode)"] = None,
    limit: Annotated[int, "Max total lines returned. 0 = unlimited (use with output_dir for file export)"] = 10_000,
    output_dir: Annotated[str | None, "Directory to write per-day log files: output_dir/{cluster}/{date}.log"] = None,
) -> str:
    """Query Loki logs directly. No AI — pure log retrieval.

    Supports any time range (hours, days, weeks, months); auto-splits into
    24-hour intervals internally to avoid Loki timeouts.

    Two query modes (mutually exclusive):
    - LogQL mode: logql='{app="auth"} |= "error" | json'
    - Simple mode: service="auth", level="error", pattern="timeout"

    File export (mirrors logcli-query-batch.py behavior):
    - Set output_dir to write one file per day: {output_dir}/{cluster}/{date}.log
    - Set limit=0 for unlimited lines when exporting to files

    Inline display is capped at 2000 lines (total_lines always shows the real count).
    """
    body: dict = {
        "cluster": cluster,
        "time_range": time_range,
        "limit": limit,
        "include_days": output_dir is not None,
    }
    for key, val in {
        "logql": logql, "service": service, "namespace": namespace,
        "level": level, "pattern": pattern, "start": start, "end": end,
    }.items():
        if val is not None:
            body[key] = val

    try:
        result = await api_post("/logs/query", json_body=body)
    except Exception as exc:
        return str(exc)

    if output_dir and result.get("days"):
        import os
        cluster_dir = os.path.join(output_dir, cluster)
        os.makedirs(cluster_dir, exist_ok=True)
        written: list[str] = []
        for day in result["days"]:
            path = os.path.join(cluster_dir, f"{day['date']}.log")
            with open(path, "w", encoding="utf-8") as f:
                f.write(day["content"] + "\n")
            written.append(f"  {path} ({day['lines']} lines)")
        return (
            f"Written {len(written)} file(s) to {cluster_dir}:\n"
            + "\n".join(written)
            + f"\n\nTotal: {result['total_lines']} lines"
            + f" | Intervals: {result['intervals_queried']}"
            + f"\nLogQL: {result['logql']}"
        )

    header = (
        f"LogQL: {result['logql']}\n"
        f"Window: {result['query_start']} → {result['query_end']}\n"
        f"Lines: {result['total_lines']}"
        + (" (truncated — use output_dir to save all)" if result.get("truncated") else "")
        + f" | Intervals: {result['intervals_queried']}\n"
        + "─" * 60 + "\n"
    )
    return header + result["result"]


@mcp.tool(tags={"core"})
async def tria_query_metrics(
    cluster: Annotated[str, "Cluster name (from tria_list_clusters)"],
    promql: Annotated[str, "PromQL expression e.g. 'rate(http_requests_total[5m])'"],
    start: Annotated[str | None, "Start time ISO8601 UTC e.g. '2024-01-01T00:00:00Z'"] = None,
    end: Annotated[str | None, "End time ISO8601 UTC"] = None,
    time_range: Annotated[str, "Relative lookback when start/end not given: '30m','1h','6h','7d','30d'"] = "1h",
    step: Annotated[str, "Resolution step: '30s','1m','5m','15m','1h'. Auto-scaled on long ranges."] = "1m",
    query_type: Annotated[str, "'range' (time-series) or 'instant' (point-in-time)"] = "range",
    output_dir: Annotated[str | None, "Directory to write CSV: output_dir/{cluster}/{date}.csv"] = None,
) -> str:
    """Query Prometheus metrics with PromQL. No AI — pure metric retrieval.

    Step is automatically scaled to keep output ≤ 2000 data points on long ranges.
    Minimum step is always 60s regardless of what is requested.
    Use output_dir to save all data points as CSV (timestamp,labels,value): output_dir/{cluster}/{date}.csv
    """
    body: dict = {
        "cluster": cluster,
        "promql": promql,
        "time_range": time_range,
        "step": step,
        "query_type": query_type,
        "include_raw": output_dir is not None,
    }
    for key, val in {"start": start, "end": end}.items():
        if val is not None:
            body[key] = val

    try:
        result = await api_post("/metrics/query", json_body=body)
    except Exception as exc:
        return str(exc)

    if output_dir:
        if not result.get("csv"):
            return (
                f"No data returned — file not written.\n"
                f"PromQL: {result['promql']}\n"
                f"Window: {result['query_start']} → {result['query_end']}"
            )
        import os
        date = result["query_end"][:10]  # "2024-01-15"
        cluster_dir = os.path.join(output_dir, cluster)
        os.makedirs(cluster_dir, exist_ok=True)
        output_file = os.path.join(cluster_dir, f"{date}.csv")
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(result["csv"])
            f.write("\n")
        size = os.path.getsize(output_file)
        return (
            f"Written: {output_file}  ({result['total_points']:,} points, {size / 1024:.1f} KB)\n"
            f"PromQL: {result['promql']}\n"
            f"Window: {result['query_start']} → {result['query_end']}"
            f" | Step: {result['step_seconds']}s"
        )

    header = (
        f"PromQL: {result['promql']}\n"
        f"Window: {result['query_start']} → {result['query_end']}"
        f" | Step: {result['step_seconds']}s\n"
        + "─" * 60 + "\n"
    )
    return header + result.get("result", "No data returned.")


# ---------------------------------------------------------------------------
# Factory for mounting into FastAPI
# ---------------------------------------------------------------------------

def create_mcp_app(path: str = "/"):
    """Create an ASGI app from the MCP server for mounting in FastAPI.

    Usage in api/app.py:
        from mcp_server import create_mcp_app
        mcp_app = create_mcp_app(path="/")
        app.mount("/mcp", mcp_app)

    stateless_http: each request creates a fresh transport context so the
    server works correctly behind load balancers and with multiple uvicorn
    workers — no session affinity required.  MCP clients like Cursor and
    Claude Code don't forward Set-Cookie headers, so sticky sessions are
    unreliable; stateless mode is the recommended approach.
    """
    return mcp.http_app(path=path, stateless_http=True)
