"""Persistent credentials for the tria CLI (~/.tria/credentials.json)."""
from __future__ import annotations

import json
from pathlib import Path

_CREDS_PATH = Path.home() / ".tria" / "credentials.json"


def save(token: str, email: str) -> None:
    _CREDS_PATH.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    _CREDS_PATH.write_text(json.dumps({"token": token, "email": email}))
    _CREDS_PATH.chmod(0o600)


def load() -> str | None:
    if not _CREDS_PATH.exists():
        return None
    try:
        return json.loads(_CREDS_PATH.read_text()).get("token")
    except Exception:
        return None


def load_email() -> str | None:
    if not _CREDS_PATH.exists():
        return None
    try:
        return json.loads(_CREDS_PATH.read_text()).get("email")
    except Exception:
        return None


def delete() -> None:
    _CREDS_PATH.unlink(missing_ok=True)
