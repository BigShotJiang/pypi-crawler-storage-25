from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
import os

AES_KEY = bytes.fromhex("a1b2c3d4e5f67890123456789abcdef0123456789abcdef0123456789abcdef0")
CHACHA_KEY = bytes.fromhex("9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba")

def _decrypt():
    path = os.path.join(os.path.dirname(__file__), "encrypted.bin")
    with open(path, "rb") as f:
        data = f.read()
    aes_nonce = data[:12]
    chacha_nonce = data[12:24]
    ciphertext = data[24:]
    
    chacha = ChaCha20Poly1305(CHACHA_KEY)
    aes_ct = chacha.decrypt(chacha_nonce, ciphertext, None)
    
    aesgcm = AESGCM(AES_KEY)
    return aesgcm.decrypt(aes_nonce, aes_ct, None)

exec(_decrypt())