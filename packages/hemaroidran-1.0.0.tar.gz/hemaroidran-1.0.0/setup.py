from setuptools import setup, find_packages

setup(
    name="hemaroidran",
    version="1.0.0",
    packages=find_packages(),
    description="Randomize but more selections",
    author="hemaroidrane",
    python_requires=">=3.7",
)