# hemaroidran

hemaroidran a fork from random.py

## Installation

```bash
pip install hemaroidran