"""Textual TUI for TeleVault."""

import asyncio
import contextlib
import logging
import os

from rich.console import Console
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.reactive import reactive
from textual.screen import Screen
from textual.widgets import (
    Button,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    Static,
)

from .cli import format_size
from .config import Config
from .config import get_config_dir as televault_config_dir
from .core import TeleVault

logger = logging.getLogger("televault.tui")

console = Console()

FILE_ICONS = {
    "image": "🖼️",
    "video": "🎬",
    "audio": "🎵",
    "archive": "📦",
    "document": "📄",
    "code": "💻",
    "unknown": "📁",
}


def get_file_icon(filename: str) -> str:
    """Get an icon based on file extension."""
    ext = filename.lower().split(".")[-1] if "." in filename else ""

    image_exts = {"jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "heic", "heif"}
    video_exts = {"mp4", "mkv", "avi", "mov", "webm", "m4v", "wmv", "flv"}
    audio_exts = {"mp3", "wav", "ogg", "flac", "aac", "m4a", "opus"}
    archive_exts = {"zip", "tar", "gz", "bz2", "xz", "7z", "rar", "zst"}
    code_exts = {"py", "js", "ts", "go", "rs", "c", "cpp", "h", "java", "rb", "php"}
    doc_exts = {"pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md"}

    if ext in image_exts:
        return FILE_ICONS["image"]
    elif ext in video_exts:
        return FILE_ICONS["video"]
    elif ext in audio_exts:
        return FILE_ICONS["audio"]
    elif ext in archive_exts:
        return FILE_ICONS["archive"]
    elif ext in code_exts:
        return FILE_ICONS["code"]
    elif ext in doc_exts:
        return FILE_ICONS["document"]
    else:
        return FILE_ICONS["unknown"]


def check_api_credentials() -> tuple[bool, str | None]:
    """Check if Telegram API credentials are set.

    Returns:
        (is_configured, config_path_or_error)
    """
    # Check environment variables
    api_id = os.environ.get("TELEGRAM_API_ID")
    api_hash = os.environ.get("TELEGRAM_API_HASH")

    if api_id and api_hash:
        return True, None

    # Check config file
    config_path = televault_config_dir() / "telegram.json"
    if config_path.exists():
        try:
            import json

            with open(config_path) as f:
                data = json.load(f)
                if data.get("api_id") and data.get("api_hash"):
                    return True, None
        except Exception:
            pass

    return False, str(config_path)


class VaultApp(App):
    """TeleVault Terminal User Interface."""

    TITLE = "TeleVault"
    SUB_TITLE = "Encrypted Cloud Storage via Telegram"

    CSS = """
    /* Main layout */
    #main-container {
        layout: horizontal;
        height: 100%;
    }

    /* Sidebar */
    #sidebar {
        width: 22;
        height: 100%;
        padding: 1 2;
        border-right: thick $primary;
        background: $surface;
    }

    #sidebar .title {
        text-align: center;
        color: $text;
        text-style: bold;
        margin-bottom: 1;
    }

    #sidebar .stats-box {
        padding: 1;
        margin-bottom: 1;
        background: $surface-darken-1;
        border: round $primary;
    }

    #sidebar .stats-box .title {
        color: $accent;
        text-style: bold;
    }

    .sidebar-button {
        width: 100%;
        margin-bottom: 1;
    }

    /* Content area */
    #content {
        width: 1fr;
        height: 100%;
        padding: 1 2;
    }

    #content .title {
        color: $text;
        text-style: bold;
        margin-bottom: 1;
    }

    #file-table {
        height: 1fr;
    }

    #status-bar {
        dock: bottom;
        height: 1;
        background: $primary;
        color: $text;
        padding: 0 1;
    }

    /* Detail panel */
    #detail-panel {
        width: 40;
        height: 100%;
        padding: 1 2;
        border-left: thick $primary;
        background: $surface;
        overflow-y: auto;
    }

    #detail-panel .title {
        color: $accent;
        text-style: bold;
        margin-bottom: 1;
    }

    #detail-panel .field-label {
        color: $text-muted;
    }

    #detail-panel .field-value {
        color: $text;
        margin-bottom: 1;
    }

    #detail-panel .preview-box {
        background: $surface-darken-1;
        border: round $primary;
        padding: 1;
        margin-top: 1;
        max-height: 16;
        overflow-y: auto;
    }

    /* Login screens */
    .login-container {
        max-width: 60;
        padding: 2 4;
        margin: 2;
    }

    .info-text {
        color: $text-muted;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("r", "refresh", "Refresh"),
        Binding("u", "upload", "Upload"),
        Binding("d", "download", "Download"),
        Binding("s", "search", "Search"),
        Binding("l", "login", "Login"),
        Binding("p", "preview", "Preview"),
        Binding("delete", "delete", "Delete"),
    ]

    is_authenticated = reactive(False)
    api_configured = reactive(False)
    files = reactive([])

    def __init__(self):
        super().__init__()
        self._vault: TeleVault | None = None
        self._connected = False
        self.config = Config.load_or_create()
        self.selected_file = None

    async def _get_vault(self) -> TeleVault:
        """Get or create a persistent TeleVault connection."""
        if self._vault is None or not self._connected:
            self._vault = TeleVault()
            await self._vault.connect()
            self._connected = True
        return self._vault

    async def _release_vault(self) -> None:
        """Disconnect and release the persistent connection."""
        if self._vault and self._connected:
            await self._vault.disconnect()
            self._vault = None
            self._connected = False

    status_message = reactive("Ready")

    def on_unmount(self) -> None:
        """Clean up connection when app exits."""
        if self._vault and self._connected:
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(self._vault.disconnect())
                else:
                    loop.run_until_complete(self._vault.disconnect())
            except Exception:
                pass

    def compose(self) -> ComposeResult:
        """Compose the main UI."""
        yield Header(show_clock=True)

        if not self.api_configured:
            yield from self._compose_api_setup_screen()
        elif not self.is_authenticated:
            yield from self._compose_login_screen()
        else:
            yield from self._compose_main_screen()

        yield Footer()

    def _compose_api_setup_screen(self) -> ComposeResult:
        """Compose the API credentials setup screen."""
        with Container(id="login-screen"), Container(classes="login-container"):
            yield Label("⚙️ API Configuration Required", classes="title")
            yield Label("")
            yield Label("Telegram API credentials not found!", classes="info-text")
            yield Label("")
            yield Label(
                "You need to provide your Telegram API credentials.", classes="info-text"
            )
            yield Label("Get them at: https://my.telegram.org", classes="info-text")
            yield Label("")
            yield Label("API ID:", classes="info-text")
            yield Input(placeholder="12345", id="api-id-input")
            yield Label("")
            yield Label("API Hash:", classes="info-text")
            yield Input(placeholder="your_api_hash_here", id="api-hash-input")
            yield Label("")
            yield Label("These will be saved to your config file.", classes="info-text")
            yield Label("")

            with Horizontal():
                yield Button("💾 Save", id="btn-save-api", variant="primary")
                yield Button("❌ Exit", id="btn-exit-setup", variant="error")

            yield Label("")
            yield Label("Press Ctrl+C to exit anytime", classes="info-text")

    def _compose_login_screen(self) -> ComposeResult:
        """Compose the login screen."""
        with Container(id="login-screen"), Container(classes="login-container"):
            yield Label("TeleVault", classes="title")
            yield Label("")
            yield Label("Welcome to TeleVault", classes="info-text")
            yield Label("Your encrypted Telegram cloud storage", classes="info-text")
            yield Label("")

            yield Label("Status: Not Authenticated", id="auth-status")
            yield Label("")

            with Horizontal():
                yield Button("🔐 Login", id="btn-login", variant="primary")
                yield Button("❌ Exit", id="btn-exit", variant="error")

            yield Label("")
            yield Label("Press Ctrl+C to exit anytime", classes="info-text")

    def _compose_main_screen(self) -> ComposeResult:
        """Compose the main application screen."""
        with Container(id="main-container"):
            # Sidebar
            with Vertical(id="sidebar"):
                yield Label("📁 TeleVault", classes="title")
                yield Label("")

                # Stats
                with Container(classes="stats-box"):
                    yield Label("📊 Statistics", classes="title")
                    yield Label("Files: 0", id="stat-files")
                    yield Label("Total Size: 0 B", id="stat-size")
                    yield Label("Storage: -", id="stat-storage")

                yield Label("")
                yield Button("📤 Upload", id="btn-upload", classes="sidebar-button")
                yield Button("🔍 Search", id="btn-search", classes="sidebar-button")
                yield Button("🔄 Refresh", id="btn-refresh", classes="sidebar-button")
                yield Button("ℹ️ Status", id="btn-status", classes="sidebar-button")
                yield Button("👤 Whoami", id="btn-whoami", classes="sidebar-button")
                yield Button("🔓 Logout", id="btn-logout", classes="sidebar-button")

            # Main content
            with Vertical(id="content"):
                yield Label("📁 File Browser", classes="title")
                yield Input(placeholder="Search files...", id="search-input")

                # File table
                table = DataTable(id="file-table")
                table.add_columns("ID", "Name", "Size", "Chunks", "Encrypted", "Actions")
                table.cursor_type = "row"
                table.zebra_stripes = True
                yield table

                # Status bar
                yield Static(
                    "Ready - Press 'q' to quit, 'u' to upload, 'd' to download, 'p' to preview",
                    id="status-bar",
                )

            # Detail / Preview panel
            with Vertical(id="detail-panel"):
                yield Label("📋 File Details", id="detail-title", classes="title")
                yield Static("Select a file to see details", id="detail-content")

    async def on_mount(self) -> None:
        """Handle app mount."""
        self.title = "TeleVault - Encrypted Cloud Storage"

        # Check API credentials first
        is_configured, _ = check_api_credentials()
        self.api_configured = is_configured

        if self.api_configured:
            # Check authentication on mount
            await self._check_auth()

    async def _check_auth(self) -> None:
        """Check if user is authenticated."""
        try:
            vault = await self._get_vault()

            if await vault.is_authenticated():
                self.is_authenticated = True
                self.refresh(layout=True)
                await self._load_files()
            else:
                await self._release_vault()
                self.is_authenticated = False
                self.status_message = "Not logged in - Press 'l' to login"
        except Exception as e:
            self.status_message = f"Error: {str(e)}"
            self.is_authenticated = False

    async def _load_files(self) -> None:
        """Load files from vault."""
        if not self.is_authenticated:
            return

        try:
            self.status_message = "Loading files..."
            vault = await self._get_vault()

            files = await vault.list_files()
            self.files = files

            # Update table
            table = self.query_one("#file-table", DataTable)
            table.clear()

            for f in files:
                table.add_row(
                    f.id[:8],
                    f.name[:40] + "..." if len(f.name) > 40 else f.name,
                    format_size(f.size),
                    str(f.chunk_count),
                    "🔒" if f.encrypted else "📄",
                    "[Enter] Download | [Del] Delete",
                )

            # Update stats
            total_size = sum(f.size for f in files)
            self.query_one("#stat-files", Label).update(f"Files: {len(files)}")
            self.query_one("#stat-size", Label).update(f"Total Size: {format_size(total_size)}")

            try:
                status = await vault.get_status()
                stored = status.get("stored_size", 0)
                self.query_one("#stat-storage", Label).update(f"Stored: {format_size(stored)}")
            except Exception:
                pass

            self.status_message = f"Loaded {len(files)} files"

        except Exception as e:
            self.status_message = f"Error loading files: {str(e)}"

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        button_id = event.button.id

        if button_id == "btn-save-api":
            await self._save_api_credentials()
        elif button_id == "btn-exit-setup":
            self.exit()
        elif button_id == "btn-login":
            await self._do_login()
        elif button_id == "btn-exit":
            self.exit()
        elif button_id == "btn-upload":
            await self._do_upload()
        elif button_id == "btn-search":
            await self._do_search()
        elif button_id == "btn-refresh":
            await self._load_files()
        elif button_id == "btn-status":
            await self._show_status()
        elif button_id == "btn-whoami":
            await self._show_whoami()
        elif button_id == "btn-logout":
            await self._do_logout()

    async def _save_api_credentials(self) -> None:
        """Save API credentials to config file."""
        api_id = self.query_one("#api-id-input", Input).value.strip()
        api_hash = self.query_one("#api-hash-input", Input).value.strip()

        if not api_id or not api_hash:
            self.notify("Please enter both API ID and API Hash", severity="error")
            return

        try:
            # Validate API ID is a number
            api_id_int = int(api_id)

            # Save to config file
            config_path = televault_config_dir() / "telegram.json"
            config_path.parent.mkdir(parents=True, exist_ok=True)

            import json

            config_data = {"api_id": api_id_int, "api_hash": api_hash, "session_string": None}

            with open(config_path, "w") as f:
                json.dump(config_data, f, indent=2)

            self.notify("✓ API credentials saved successfully!")
            self.api_configured = True
            self.refresh(layout=True)
            await self._check_auth()

        except ValueError:
            self.notify("API ID must be a number", severity="error")
        except Exception as e:
            self.notify(f"Error saving credentials: {str(e)}", severity="error")

    async def _do_login(self) -> None:
        """Show login dialog."""
        self.push_screen(LoginScreen())

    async def _do_upload(self) -> None:
        """Show upload dialog."""
        if not self.is_authenticated:
            self.notify("Please login first", severity="error")
            return
        self.push_screen(UploadScreen())

    async def _do_search(self) -> None:
        """Focus search input."""
        if not self.is_authenticated:
            self.notify("Please login first", severity="error")
            return
        self.query_one("#search-input", Input).focus()

    async def _show_status(self) -> None:
        """Show vault status."""
        if not self.is_authenticated:
            self.notify("Please login first", severity="error")
            return

        try:
            vault = await self._get_vault()
            status = await vault.get_status()

            channel_id = status.get("channel_id", "N/A")
            file_count = status.get("file_count", 0)
            total_size = status.get("total_size", 0)
            stored_size = status.get("stored_size", 0)
            ratio = status.get("compression_ratio", 0)
            ratio_str = f"{ratio:.1%}" if isinstance(ratio, (int, float)) else "N/A"

            message = f"""
📊 Vault Status

Channel ID: {channel_id}
Files: {file_count}
Total Size: {format_size(total_size)}
Stored Size: {format_size(stored_size)}
Compression: {ratio_str}
            """.strip()

            self.notify(message, title="Status", timeout=10)
        except Exception as e:
            self.notify(f"Error: {str(e)}", severity="error")

    async def _show_whoami(self) -> None:
        """Show current user info."""
        if not self.is_authenticated:
            self.notify("Please login first", severity="error")
            return

        try:
            vault = await self._get_vault()
            if not await vault.is_authenticated():
                self.notify("Not logged in", severity="error")
                return
            me = await vault.telegram._client.get_me()

            if me:
                name = f"{me.first_name or ''} {me.last_name or ''}".strip()
                username = f"@{me.username}" if me.username else "No username"

                message = f"""
👤 Account Info

Name: {name}
Username: {username}
ID: {me.id}
                """.strip()

                self.notify(message, title="Whoami", timeout=10)
        except Exception as e:
            self.notify(f"Error: {str(e)}", severity="error")

    async def _do_logout(self) -> None:
        """Logout user."""
        await self._release_vault()

        config_dir = televault_config_dir()
        telegram_config = config_dir / "telegram.json"

        if telegram_config.exists():
            telegram_config.unlink()
            self.is_authenticated = False
            self.files = []
            self.refresh(layout=True)
            self.notify("Logged out successfully", severity="information")
        else:
            self.is_authenticated = False
            self.refresh(layout=True)
            self.notify("Not logged in", severity="warning")

    def action_refresh(self) -> None:
        """Refresh action."""
        asyncio.create_task(self._load_files())

    def action_upload(self) -> None:
        """Upload action."""
        asyncio.create_task(self._do_upload())

    def action_download(self) -> None:
        """Download action."""
        self.notify("Select a file and press Enter to download", severity="information")

    def action_preview(self) -> None:
        """Preview action - show selected file details in side panel."""
        if not self.files:
            self.notify("No files to preview", severity="warning")
            return

        try:
            table = self.query_one("#file-table", DataTable)
            row_index = table.cursor_row
            if 0 <= row_index < len(self.files):
                file_meta = self.files[row_index]
                self._update_detail_panel(file_meta)
            else:
                self.notify("Select a file to preview", severity="information")
        except Exception:
            self.notify("Select a file to preview", severity="information")

    def _update_detail_panel(self, file_meta) -> None:
        """Update the detail panel with file information."""
        try:
            detail_title = self.query_one("#detail-title", Label)
            detail_content = self.query_one("#detail-content", Static)

            icon = get_file_icon(file_meta.name)
            from datetime import datetime

            created_str = (
                datetime.fromtimestamp(file_meta.created_at).strftime("%Y-%m-%d %H:%M")
                if file_meta.created_at
                else "Unknown"
            )
            hash_str = (
                file_meta.hash[:16] + "..."
                if file_meta.hash and len(file_meta.hash) > 16
                else (file_meta.hash or "N/A")
            )

            lines = []
            lines.append(f"{icon} {file_meta.name}")
            lines.append("")
            lines.append(f"[bold]ID:[/bold] {file_meta.id}")
            lines.append(f"[bold]Size:[/bold] {format_size(file_meta.size)}")
            lines.append(f"[bold]Hash:[/bold] {hash_str}")
            lines.append(f"[bold]Chunks:[/bold] {file_meta.chunk_count}")
            lines.append(f"[bold]Encrypted:[/bold] {'Yes' if file_meta.encrypted else 'No'}")
            lines.append(f"[bold]Compressed:[/bold] {'Yes' if file_meta.compressed else 'No'}")
            if file_meta.compressed and file_meta.compression_ratio:
                lines.append(f"[bold]Comp. ratio:[/bold] {file_meta.compression_ratio:.1%}")
            lines.append(f"[bold]Created:[/bold] {created_str}")
            if file_meta.mime_type:
                lines.append(f"[bold]MIME:[/bold] {file_meta.mime_type}")
            if file_meta.chunks:
                stored = sum(c.size for c in file_meta.chunks)
                lines.append(f"[bold]Stored:[/bold] {format_size(stored)}")

            detail_title.update(f"📋 {icon} {file_meta.name[:30]}")
            detail_content.update("\n".join(lines))

        except Exception as e:
            logger.debug(f"Error updating detail panel: {e}")

    def action_delete(self) -> None:
        """Delete action."""
        if not self.files:
            self.notify("No files to delete", severity="warning")
            return

        # Get selected file from table
        try:
            table = self.query_one("#file-table", DataTable)
            row_index = table.cursor_row
            if 0 <= row_index < len(self.files):
                file_to_delete = self.files[row_index]

                async def do_delete():
                    try:
                        vault = await self._get_vault()
                        deleted = await vault.delete(file_to_delete.id)

                        if deleted:
                            self.notify(f"✓ Deleted: {file_to_delete.name}")
                            await self._load_files()
                        else:
                            self.notify(
                                f"✗ Failed to delete: {file_to_delete.name}", severity="error"
                            )
                    except Exception as e:
                        self.notify(f"Error: {str(e)}", severity="error")

                self.push_screen(
                    ConfirmScreen(
                        "🗑️ Confirm Delete",
                        f"Delete '{file_to_delete.name}'? Cannot be undone.",
                        do_delete,
                    )
                )
            else:
                self.notify("Select a file to delete", severity="information")
        except Exception:
            self.notify("Select a file to delete", severity="information")

    def action_search(self) -> None:
        """Search action."""
        asyncio.create_task(self._do_search())

    def action_login(self) -> None:
        """Login action."""
        asyncio.create_task(self._do_login())

    async def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle file selection."""
        if not self.files:
            return

        row_index = event.row_index
        if 0 <= row_index < len(self.files):
            self.selected_file = self.files[row_index]
            self._update_detail_panel(self.selected_file)

    async def _download_file(self, file_metadata) -> None:
        """Download selected file."""
        self.push_screen(DownloadScreen(file_metadata))

    def watch_status_message(self, message: str) -> None:
        """Update status bar when message changes."""
        try:
            status_bar = self.query_one("#status-bar", Static)
            status_bar.update(message)
        except Exception:
            pass


class LoginScreen(Screen):
    """Login screen for authentication."""

    def compose(self) -> ComposeResult:
        with Container(classes="login-container"):
            yield Label("🔐 Login to Telegram", classes="title")
            yield Label("")
            yield Label("Enter your phone number:", classes="info-text")
            yield Input(placeholder="+1234567890", id="phone-input")
            yield Label("")
            yield Button("Send Code", id="btn-send-code", variant="primary")
            yield Button("Cancel", id="btn-cancel")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-send-code":
            phone = self.query_one("#phone-input", Input).value
            if phone:
                await self._do_login(phone)
        elif event.button.id == "btn-cancel":
            self.app.pop_screen()

    async def _do_login(self, phone: str) -> None:
        """Perform login."""
        try:
            self.app.notify("Connecting to Telegram...")

            vault = TeleVault()
            await vault.connect(skip_channel=True)

            if await vault.is_authenticated():
                self.app.notify("Already logged in!")
                self.app.is_authenticated = True
                self.app.refresh(layout=True)
                await vault.disconnect()
                self.app.pop_screen()
                return

            self.app.notify("Sending verification code...")
            sent_code = await vault.telegram._client.send_code_request(phone)

            self.app.notify(f"Code sent to {phone}")
            self.app.push_screen(CodeScreen(vault, phone, sent_code.phone_code_hash))

        except Exception as e:
            error_msg = str(e)
            self.app.notify(f"Login error: {error_msg}", severity="error")


class CodeScreen(Screen):
    """Screen for entering verification code."""

    def __init__(self, vault: TeleVault, phone: str, sent_code_hash: str | None = None):
        super().__init__()
        self.vault = vault
        self.phone = phone
        self.sent_code_hash = sent_code_hash

    def compose(self) -> ComposeResult:
        with Container(classes="login-container"):
            yield Label("📱 Verification Code", classes="title")
            yield Label("")
            yield Label(f"Enter the code sent to {self.phone}:", classes="info-text")
            yield Input(placeholder="12345", id="code-input")
            yield Label("")
            yield Label("2FA Password (if enabled):", classes="info-text")
            yield Input(placeholder="Leave empty if no 2FA", id="password-input", password=True)
            yield Label("")
            yield Button("Verify", id="btn-verify", variant="primary")
            yield Button("Back", id="btn-back")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-verify":
            code = self.query_one("#code-input", Input).value
            password = self.query_one("#password-input", Input).value
            if code:
                await self._verify_code(code, password or None)
        elif event.button.id == "btn-back":
            await self.vault.disconnect()
            self.app.pop_screen()

    async def _verify_code(self, code: str, password: str | None) -> None:
        """Verify the code."""
        try:
            from telethon.errors import SessionPasswordNeededError

            try:
                await self.vault.telegram._client.sign_in(self.phone, code)
            except SessionPasswordNeededError:
                if password:
                    await self.vault.telegram._client.sign_in(password=password)
                else:
                    self.app.notify(
                        "2FA password required. Please enter your password.", severity="error"
                    )
                    return

            session_string = self.vault.telegram._client.session.save()
            from .telegram import TelegramConfig

            config = TelegramConfig.from_env()
            config.session_string = session_string
            config.save()

            self.app.notify("✓ Login successful!")
            self.app.is_authenticated = True
            self.app.refresh(layout=True)
            await self.vault.disconnect()
            self.app.pop_screen()
            self.app.pop_screen()

        except Exception as e:
            error_msg = str(e)
            if "2FA" in error_msg or "password" in error_msg.lower():
                self.app.notify(
                    "2FA password required. Please enter your password.", severity="error"
                )
            else:
                self.app.notify(f"Verification failed: {error_msg}", severity="error")


class UploadScreen(Screen):
    """Screen for uploading files."""

    def compose(self) -> ComposeResult:
        with Container(classes="login-container"):
            yield Label("📤 Upload File", classes="title")
            yield Label("")
            yield Label("Enter file path:", classes="info-text")
            yield Input(placeholder="/path/to/file", id="path-input")
            yield Label("")
            yield Label("Password (optional):", classes="info-text")
            yield Input(
                placeholder="Leave empty to use env var", id="password-input", password=True
            )
            yield Label("")
            yield Static("", id="upload-progress")
            yield Label("")
            with Horizontal():
                yield Button("Upload", id="btn-do-upload", variant="primary")
                yield Button("Cancel", id="btn-cancel")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-do-upload":
            path = self.query_one("#path-input", Input).value
            password = self.query_one("#password-input", Input).value
            if path:
                await self._upload_file(path, password or None)
        elif event.button.id == "btn-cancel":
            self.app.pop_screen()

    async def _upload_file(self, path: str, password: str | None) -> None:
        """Upload the file."""
        progress_label = self.query_one("#upload-progress", Static)
        vault = None
        try:
            from pathlib import Path

            file_path = Path(path)
            if not file_path.exists():
                self.app.notify(f"File not found: {path}", severity="error")
                return

            progress_label.update(f"Uploading {file_path.name}...")

            vault = TeleVault(password=password)
            await vault.connect()

            def on_progress(p):
                try:
                    asyncio.get_running_loop()
                    progress_label.update(
                        f"Upload: {p.percent:.1f}% ({p.uploaded_chunks}/{p.total_chunks})"
                    )
                except RuntimeError:
                    pass

            metadata = await vault.upload(path, progress_callback=on_progress)

            progress_label.update(f"✓ Uploaded: {metadata.name}")
            self.app.notify(f"✓ Uploaded: {metadata.name}")

            await asyncio.sleep(1)
            self.app.pop_screen()

            await self.app._load_files()

        except Exception as e:
            progress_label.update(f"Error: {str(e)}")
            self.app.notify(f"Upload failed: {str(e)}", severity="error")
        finally:
            if vault:
                with contextlib.suppress(Exception):
                    await vault.disconnect()


class DownloadScreen(Screen):
    """Screen for downloading files."""

    def __init__(self, file_metadata):
        super().__init__()
        self.file_metadata = file_metadata

    def compose(self) -> ComposeResult:
        with Container(classes="login-container"):
            yield Label("📥 Download File", classes="title")
            yield Label("")
            yield Label(f"File: {self.file_metadata.name}", classes="info-text")
            yield Label(f"Size: {format_size(self.file_metadata.size)}")
            yield Label("")
            yield Label("Output path (optional):", classes="info-text")
            yield Input(placeholder="Current directory", id="output-input")
            yield Label("")
            if self.file_metadata.encrypted:
                yield Label("Password:", classes="info-text")
                yield Input(
                    placeholder="Enter decryption password", id="password-input", password=True
                )
                yield Label("")
            yield Static("", id="download-progress")
            yield Label("")
            with Horizontal():
                yield Button("Download", id="btn-do-download", variant="primary")
                yield Button("Cancel", id="btn-cancel")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-do-download":
            output = self.query_one("#output-input", Input).value
            password_input = (
                self.query_one("#password-input", Input) if self.file_metadata.encrypted else None
            )
            password = password_input.value if password_input else None
            await self._download_file(output or None, password or None)
        elif event.button.id == "btn-cancel":
            self.app.pop_screen()

    async def _download_file(self, output: str | None, password: str | None) -> None:
        """Download the file."""
        progress_label = self.query_one("#download-progress", Static)
        vault = None
        try:
            progress_label.update(f"Downloading {self.file_metadata.name}...")

            vault = TeleVault(password=password)
            await vault.connect()

            def on_progress(p):
                try:
                    asyncio.get_running_loop()
                    progress_label.update(
                        f"Download: {p.percent:.1f}% ({p.downloaded_chunks}/{p.total_chunks})"
                    )
                except RuntimeError:
                    pass

            output_path = await vault.download(
                self.file_metadata.id, output_path=output, progress_callback=on_progress
            )

            progress_label.update(f"✓ Downloaded to: {output_path}")
            self.app.notify(f"✓ Downloaded to: {output_path}")

            await asyncio.sleep(1)
            self.app.pop_screen()

        except Exception as e:
            progress_label.update(f"Error: {str(e)}")
            self.app.notify(f"Download failed: {str(e)}", severity="error")
        finally:
            if vault:
                with contextlib.suppress(Exception):
                    await vault.disconnect()


class ConfirmScreen(Screen):
    """Screen for confirming destructive actions."""

    def __init__(self, title: str, message: str, on_confirm=None):
        super().__init__()
        self.title_text = title
        self.message = message
        self._on_confirm = on_confirm

    def compose(self) -> ComposeResult:
        with Container(classes="login-container"):
            yield Label(self.title_text, classes="title")
            yield Label("")
            yield Label(self.message, classes="info-text")
            yield Label("")
            with Horizontal():
                yield Button("Confirm", id="btn-confirm", variant="error")
                yield Button("Cancel", id="btn-cancel")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-confirm":
            self.app.pop_screen()
            if self._on_confirm:
                result = self._on_confirm()
                if asyncio.iscoroutine(result):
                    asyncio.create_task(result)
        elif event.button.id == "btn-cancel":
            self.app.pop_screen()


def run_tui():
    """Run the TUI application."""
    app = VaultApp()
    app.run()


if __name__ == "__main__":
    run_tui()
