# BSD 3-Clause License
#
# Copyright (c) 2025, Jean-Pierre Morard, THALES SIX GTS France SAS
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
# 3. Neither the name of Jean-Pierre Morard nor the names of its contributors, or THALES SIX GTS France SAS, may be used to endorse or promote products derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import os
import shutil
import warnings
from pathlib import Path
from typing import Any

import polars as pl
from pydantic import ValidationError

from agi_node.agi_dispatcher import BaseWorker, WorkDispatcher
from .flight_args import (
    FlightArgs,
    FlightArgsTD,
    UNSUPPORTED_DATA_SOURCE_MESSAGE,
    dump_args_to_toml,
    load_args_from_toml,
    merge_args,
)
from agi_env.agi_logger import AgiLogger

logger = AgiLogger.get_logger(__name__)
warnings.filterwarnings("ignore")


class Flight(BaseWorker):
    """Flight class provides methods to orchestrate the run."""

    ivq_logs = None

    def __init__(
        self,
        env,
        args: FlightArgs | None = None,
        **kwargs: FlightArgsTD,
    ) -> None:
        self.env = env
        self._ensure_managed_pc_share_dir(env)
        # Allow caller-provided verbosity flag even though the Pydantic model forbids extras.
        self.verbose = bool(kwargs.pop("verbose", env.verbose))

        if isinstance(args, FlightArgs):
            parsed_args = args
        else:
            if args is None or isinstance(args, list):
                payload = dict(kwargs)
            elif isinstance(args, dict):
                payload = {**args, **kwargs}
            else:
                try:
                    payload = {**vars(args), **kwargs}
                except TypeError as exc:
                    raise ValueError(f"Invalid Flight arguments: {args!r}") from exc
            try:
                parsed_args = FlightArgs(**payload)
            except ValidationError as exc:
                raise ValueError(f"Invalid Flight arguments: {exc}") from exc
        self.args = parsed_args
        self.args.data_in = env.resolve_share_path(self.args.data_in)
        self.args.data_out = env.resolve_share_path(self.args.data_out)
        self.data_out = self.args.data_out

        WorkDispatcher.args = self.args.model_dump(mode="json")

        if getattr(self.args, "reset_target", False):
            try:
                if self.data_out.exists():
                    shutil.rmtree(
                        self.data_out,
                        ignore_errors=True,
                        onerror=WorkDispatcher._onerror,
                    )
                logger.info(f"mkdir {self.data_out}")
                self.data_out.mkdir(parents=True, exist_ok=True)
            except Exception as exc:  # pragma: no cover - defensive guard
                logger.warning(
                    "Issue while trying to reset dataframe directory %s: %s",
                    self.data_out,
                    exc,
                )
        else:
            logger.info(f"mkdir {self.data_out}")
            self.data_out.mkdir(parents=True, exist_ok=True)

    @classmethod
    def from_toml(
        cls,
        env,
        settings_path: str | Path = "app_settings.toml",
        section: str = "args",
        **overrides: FlightArgsTD,
    ) -> "Flight":
        base_args = load_args_from_toml(settings_path, section)
        merged = merge_args(base_args, overrides or None)
        return cls(env, args=merged)

    def to_toml(
        self,
        settings_path: str | Path = "app_settings.toml",
        section: str = "args",
        create_missing: bool = True,
    ) -> None:
        dump_args_to_toml(
            self.args,
            settings_path=settings_path,
            section=section,
            create_missing=create_missing,
        )

    def as_dict(self, mode: str = "json") -> dict[str, Any]:
        """Return current arguments as a serialisable dictionary."""

        return self.args.model_dump(mode=mode)

    def build_distribution(self, workers):
        """Build worker -> aircraft -> file batches for file-based telemetry."""

        workers_chunks: list | None = []
        workers_planes_dist: list | None = []

        try:
            # create list of works weighted
            planes_partition, planes_partition_size, df = self.get_partition_by_planes(
                self.get_data_from_files()
            )

            # get the second level of the distribution tree by by dispatching these works per workers
            # make chunk of planes by worker with a load balancing that takes into consideration workers capacities
            workers_chunks = WorkDispatcher.make_chunks(
                len(planes_partition),
                planes_partition_size,
                verbose=self.verbose,
                workers=workers,
                threshold=12,
            )
            if workers_chunks:
                # build tree: workers = dask workers -> works = planes -> files <=> list of list of list
                # files by plane are capped  to max number of files requested per workers

                workers_planes_dist = []
                df = df.with_columns([pl.col("id_plane").cast(pl.Int64)])

                for planes in workers_chunks:
                    workers_planes_dist.append(
                        [
                            df.filter(pl.col("id_plane") == plane_id)["files"]
                            .head(self.args.nfile)
                            .to_list()
                            for plane_id, _ in planes
                        ]
                    )

                workers_chunks = [
                    [(plane, round(size / 1000, 3)) for plane, size in chunk]
                    for chunk in workers_chunks
                ]

        except Exception as exc:
            raise RuntimeError(
                f"Unable to build flight distribution from {self.args.data_in}"
            ) from exc
        return workers_planes_dist or [], workers_chunks or [], "plane", "files", "KB"

    def get_data_from_hawk(self):
        """Fail fast for legacy snippets that still select Hawk ingestion."""

        raise NotImplementedError(UNSUPPORTED_DATA_SOURCE_MESSAGE)

    @staticmethod
    def extract_plane_from_file_name(file_path):
        """provide airplane id from log file name

        Args:
          file_path:

        Returns:

        """
        return int(file_path.split("/")[-1].split("_")[2][2:4])

    def get_data_from_files(self):
        """Return file slices to distribute across workers."""

        if self.args.data_source != "file":
            self.get_data_from_hawk()

        if self.args.data_source == "file":
            data_in = Path(self.args.data_in)
            home_dir = Path.home()

            def _display_path(path: Path) -> str:
                try:
                    return str(path.relative_to(home_dir))
                except ValueError:
                    return str(path)

            discovered_files = sorted(
                (
                    f
                    for f in data_in.rglob(self.args.files)
                    if f.is_file() and not f.name.startswith("._")
                ),
                key=_display_path,
            )
            self.logs_ivq = {
                _display_path(f): os.path.getsize(f) // 1000
                for f in discovered_files
            }

            if not self.logs_ivq:
                raise FileNotFoundError(
                    "Error in make_chunk: no files found with"
                    f" Path('{data_in}').rglob('{self.args.files}')"
                )

            df = pl.DataFrame(
                {
                    "files": list(self.logs_ivq.keys()),
                    "size": list(self.logs_ivq.values()),
                },
                schema={"files": pl.String, "size": pl.Int64},
            )

        return df

    def get_partition_by_planes(self, df):
        """build the first level of the distribution tree with planes as atomics partition

        Args:
          s: df: dataframe containing the output-data to partition
          df:

        Returns:

        """
        df = df.with_columns(
            pl.col("files")
            .str.extract(
                r"(?:.*/)?(\d{2})_"
            )  # Optionally match directories, then capture two digits followed by an underscore
            .cast(pl.Int32)  # Cast the captured string to Int32
            .alias("id_plane")  # Rename the column
        )

        # Get the first 'nfile' rows per 'id_plane' group
        df = df.group_by("id_plane").head(self.args.nfile)

        # Sort the DataFrame by 'id_plane'
        df = df.sort("id_plane")

        # Compute the sum of 'size' per 'id_plane' and sort in descending order
        planes_partition = (
            df.group_by("id_plane")
            .agg(pl.col("size").sum().alias("size"))
            .sort("size", descending=True)
        )

        # Extract 'id_plane' and 'size' into lists and create tuples
        planes_partition_size = list(
            zip(
                planes_partition["id_plane"].to_list(),
                planes_partition["size"].to_list(),
            )
        )

        return planes_partition, planes_partition_size, df


class FlightApp(Flight):
    """Alias keeping legacy imports alive."""


__all__ = ["Flight", "FlightApp"]
