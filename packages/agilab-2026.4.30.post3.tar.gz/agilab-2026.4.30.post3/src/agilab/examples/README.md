# AGILAB Packaged Examples

These examples are small Python entry points for public AGILAB workflows. The
app-specific `AGI_*.py` scripts are copied by the app installer into
`~/log/execute/<app>/`; the read-only previews stay in the package or source
checkout because they teach orchestration concepts without launching long-lived
or multi-app work.

## Learning Path

Start with the examples in this order. Each step adds one concept while keeping
the command shape stable.

| Order | Example | App | Main lesson |
|---:|---|---|---|
| 1 | `flight` | `flight_project` | First proof: install one app, run one file, inspect map-ready output. |
| 2 | `mycode` | `mycode_project` | Smallest worker template and execution smoke. |
| 3 | `meteo_forecast` | `meteo_forecast_project` | Turn a notebook-style forecast into a reproducible app run. |
| 4 | `data_io_2026` | `data_io_2026_project` | Deterministic mission-data decision run with richer artifacts. |
| 5 | `inter_project_dag` | `flight_project` -> `meteo_forecast_project` | Read-only DAG contract: app nodes, artifact handoff, and runner-state preview. |
| 6 | `service_mode` | `mycode_project` | Read-only service lifecycle preview: start, status, health, stop. |

## What To Notice

- `AGI_install_*.py` prepares the app environment and worker runtime.
- `AGI_run_*.py` builds a `RunRequest` and calls `AGI.run`.
- `inter_project_dag/preview_inter_project_dag.py` plans a cross-project
  handoff without executing either app.
- `service_mode/preview_service_mode.py` explains persistent-worker operations
  and health gates without starting a service.
- `data_in` and `data_out` are share-root relative paths, so examples stay
  portable across machines.
- Run modes use named AGI constants instead of magic numbers, and keep Cython
  off in packaged first-run examples so the demo is not tied to a compiled
  extension for a specific Python ABI.
- The examples are intentionally local-first: one scheduler, one worker, and
  deterministic public inputs.

## Typical Use

```bash
python ~/log/execute/flight/AGI_install_flight.py
python ~/log/execute/flight/AGI_run_flight.py
```

## How To Read An Example

1. Read the app README to understand the goal and expected output.
2. Open the install script and identify the app name and enabled modes.
3. Open the run script and find `RunRequest`.
4. Change one parameter only, rerun, and compare the output directory.

## When To Use These Scripts

Run `agilab first-proof --json` when you want the shortest packaged product
proof. Use these scripts when you want to inspect or adapt the generated
programmatic calls. Use `inter_project_dag` when you want to understand how
project-level app runs can be connected by explicit artifact contracts. Use
`service_mode` before enabling persistent workers for an already-working app.
