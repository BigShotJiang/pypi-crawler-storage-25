# tests/test_logger.py

import json
from bson import ObjectId
from opticedge_cloud_utils.logger import log, LogLevel


def parse_output(capsys):
    captured = capsys.readouterr()
    return json.loads(captured.out.strip())


# ---------------------------------------------------------------------
# Basic behavior
# ---------------------------------------------------------------------

def test_log_outputs_valid_json(capsys):
    log(LogLevel.INFO, "Test message")

    parsed = parse_output(capsys)

    assert parsed["severity"] == "INFO"
    assert parsed["message"] == "Test message"


def test_log_includes_extra_fields(capsys):
    log(LogLevel.ERROR, "Something failed", card_id="123", session_id="abc")

    parsed = parse_output(capsys)

    assert parsed["severity"] == "ERROR"
    assert parsed["message"] == "Something failed"
    assert parsed["card_id"] == "123"
    assert parsed["session_id"] == "abc"


def test_log_handles_empty_kwargs(capsys):
    log(LogLevel.WARNING, "No extras")

    parsed = parse_output(capsys)

    assert parsed == {
        "severity": "WARNING",
        "message": "No extras",
    }


# ---------------------------------------------------------------------
# Auto-serialization tests
# ---------------------------------------------------------------------

def test_log_serializes_object_id(capsys):
    oid = ObjectId()

    log(LogLevel.INFO, "Has ObjectId", session_id=oid)

    parsed = parse_output(capsys)

    assert parsed["session_id"] == str(oid)


def test_log_serializes_non_json_object(capsys):
    class Dummy:
        def __str__(self):
            return "dummy-value"

    dummy = Dummy()

    log(LogLevel.INFO, "Has custom object", custom=dummy)

    parsed = parse_output(capsys)

    assert parsed["custom"] == "dummy-value"


def test_log_handles_mixed_field_types(capsys):
    oid = ObjectId()

    log(
        LogLevel.DEBUG,
        "Mixed fields",
        number=42,
        text="hello",
        boolean=True,
        object_id=oid,
    )

    parsed = parse_output(capsys)

    assert parsed["severity"] == "DEBUG"
    assert parsed["number"] == 42
    assert parsed["text"] == "hello"
    assert parsed["boolean"] is True
    assert parsed["object_id"] == str(oid)