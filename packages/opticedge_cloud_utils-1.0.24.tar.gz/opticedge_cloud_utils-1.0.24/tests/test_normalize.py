# tests/test_normalize.py

from enum import IntEnum, Enum
from bson.objectid import ObjectId
from opticedge_cloud_utils.normalize import normalize_enum, normalize_object_id


class NumberEnum(IntEnum):
    A = 1
    B = 2


class StringEnum(str, Enum):
    X = "x"
    Y = "y"


# -------------------------
# Valid cases
# -------------------------

def test_intenum_valid_value():
    assert normalize_enum(1, NumberEnum) == NumberEnum.A


def test_string_enum_valid_value():
    assert normalize_enum("x", StringEnum) == StringEnum.X


def test_existing_enum_instance():
    assert normalize_enum(NumberEnum.B, NumberEnum) == NumberEnum.B


# -------------------------
# Invalid cases
# -------------------------

def test_invalid_int_value_returns_none():
    assert normalize_enum(999, NumberEnum) is None


def test_invalid_string_value_returns_none():
    assert normalize_enum("invalid", StringEnum) is None


def test_none_value_returns_none():
    assert normalize_enum(None, NumberEnum) is None


# ------------------------------------------------------------------
# normalize_object_id tests
# ------------------------------------------------------------------

def test_normalize_object_id_with_objectid():
    oid = ObjectId()
    assert normalize_object_id(oid) is oid


def test_normalize_object_id_with_valid_objectid_string():
    oid = ObjectId()
    result = normalize_object_id(str(oid))

    assert isinstance(result, ObjectId)
    assert result == oid


def test_normalize_object_id_with_invalid_string():
    value = "not-a-valid-objectid"
    assert normalize_object_id(value) == value


def test_normalize_object_id_with_non_string_value():
    value = 12345
    assert normalize_object_id(value) == value
