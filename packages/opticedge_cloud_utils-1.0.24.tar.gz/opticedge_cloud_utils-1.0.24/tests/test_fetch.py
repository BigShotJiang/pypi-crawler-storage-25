# tests/test_fetch.py
import sys
import types

import pytest
import requests

from opticedge_cloud_utils.fetch import (
    fetch_with_retry_requests,
    fetch_with_playwright,
)


class MockResponse:
    def __init__(self, status_code=200, text="ok"):
        self.status_code = status_code
        self.text = text

    def raise_for_status(self):
        if 400 <= self.status_code < 600:
            raise requests.HTTPError(
                f"{self.status_code} error",
                response=self,
            )


class MockSession:
    def __init__(self, mock_get):
        self.mock_get = mock_get

    def get(self, url, headers=None, timeout=None):
        return self.mock_get(url, headers=headers, timeout=timeout)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        pass


def patch_session(monkeypatch, mock_get):
    monkeypatch.setattr(requests, "Session", lambda: MockSession(mock_get))


def test_fetch_success(monkeypatch):
    def mock_get(url, headers=None, timeout=None):
        return MockResponse(200, "hello world")

    patch_session(monkeypatch, mock_get)

    result = fetch_with_retry_requests("https://example.com")

    assert result == "hello world"


def test_fetch_retries_then_success(monkeypatch):
    calls = {"count": 0}

    def mock_get(url, headers=None, timeout=None):
        calls["count"] += 1
        if calls["count"] < 3:
            return MockResponse(500, "server error")
        return MockResponse(200, "success")

    patch_session(monkeypatch, mock_get)
    monkeypatch.setattr("time.sleep", lambda _: None)

    result = fetch_with_retry_requests("https://example.com", retries=4)

    assert result == "success"
    assert calls["count"] == 3


def test_fetch_raises_after_retries(monkeypatch):
    def mock_get(url, headers=None, timeout=None):
        return MockResponse(500, "server error")

    patch_session(monkeypatch, mock_get)
    monkeypatch.setattr("time.sleep", lambda _: None)

    with pytest.raises(RuntimeError) as exc_info:
        fetch_with_retry_requests("https://example.com", retries=2)

    assert "Request failed after 3 attempt(s)" in str(exc_info.value)
    assert "Retryable=True" in str(exc_info.value)


def test_fetch_does_not_retry_non_retryable_404(monkeypatch):
    calls = {"count": 0}

    def mock_get(url, headers=None, timeout=None):
        calls["count"] += 1
        return MockResponse(404, "not found")

    patch_session(monkeypatch, mock_get)
    monkeypatch.setattr("time.sleep", lambda _: None)

    with pytest.raises(RuntimeError) as exc_info:
        fetch_with_retry_requests("https://example.com/not-found", retries=4)

    assert calls["count"] == 1
    assert "Retryable=False" in str(exc_info.value)


def test_fetch_retries_on_429(monkeypatch):
    calls = {"count": 0}

    def mock_get(url, headers=None, timeout=None):
        calls["count"] += 1
        if calls["count"] == 1:
            return MockResponse(429, "too many requests")
        return MockResponse(200, "ok after retry")

    patch_session(monkeypatch, mock_get)
    monkeypatch.setattr("time.sleep", lambda _: None)

    result = fetch_with_retry_requests("https://example.com", retries=2)

    assert result == "ok after retry"
    assert calls["count"] == 2


def test_fetch_retries_on_403(monkeypatch):
    calls = {"count": 0}

    def mock_get(url, headers=None, timeout=None):
        calls["count"] += 1
        if calls["count"] == 1:
            return MockResponse(403, "forbidden")
        return MockResponse(200, "ok after 403 retry")

    patch_session(monkeypatch, mock_get)
    monkeypatch.setattr("time.sleep", lambda _: None)

    result = fetch_with_retry_requests("https://example.com", retries=2)

    assert result == "ok after 403 retry"
    assert calls["count"] == 2


def test_fetch_retries_on_timeout_then_success(monkeypatch):
    calls = {"count": 0}

    def mock_get(url, headers=None, timeout=None):
        calls["count"] += 1
        if calls["count"] == 1:
            raise requests.Timeout("request timed out")
        return MockResponse(200, "success")

    patch_session(monkeypatch, mock_get)
    monkeypatch.setattr("time.sleep", lambda _: None)

    result = fetch_with_retry_requests("https://example.com", retries=2)

    assert result == "success"
    assert calls["count"] == 2


class MockPage:
    def __init__(self, html="<html>ok</html>", fail_goto=False):
        self.html = html
        self.fail_goto = fail_goto

    def goto(self, url, wait_until=None, timeout=None):
        if self.fail_goto:
            raise Exception("navigation failed")

    def content(self):
        return self.html


class MockBrowser:
    def __init__(self, page):
        self.page = page
        self.closed = False

    def new_page(self, user_agent=None, viewport=None):
        return self.page

    def close(self):
        self.closed = True


class MockChromium:
    def __init__(self, browser):
        self.browser = browser

    def launch(self, headless=True):
        return self.browser


class MockPlaywright:
    def __init__(self, browser):
        self.chromium = MockChromium(browser)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        pass


def patch_playwright(monkeypatch, mock_sync_playwright):
    fake_sync_api = types.SimpleNamespace(sync_playwright=mock_sync_playwright)
    fake_playwright = types.SimpleNamespace(sync_api=fake_sync_api)

    monkeypatch.setitem(sys.modules, "playwright", fake_playwright)
    monkeypatch.setitem(sys.modules, "playwright.sync_api", fake_sync_api)


def test_fetch_with_playwright_success(monkeypatch):
    page = MockPage("<html>hello playwright</html>")
    browser = MockBrowser(page)

    patch_playwright(monkeypatch, lambda: MockPlaywright(browser))

    result = fetch_with_playwright("https://example.com")

    assert result == "<html>hello playwright</html>"
    assert browser.closed is True


def test_fetch_with_playwright_retries_then_success(monkeypatch):
    calls = {"count": 0}

    def mock_sync_playwright():
        calls["count"] += 1

        if calls["count"] == 1:
            page = MockPage(fail_goto=True)
        else:
            page = MockPage("<html>success</html>")

        return MockPlaywright(MockBrowser(page))

    patch_playwright(monkeypatch, mock_sync_playwright)
    monkeypatch.setattr("time.sleep", lambda _: None)

    result = fetch_with_playwright("https://example.com", retries=2)

    assert result == "<html>success</html>"
    assert calls["count"] == 2


def test_fetch_with_playwright_raises_after_retries(monkeypatch):
    def mock_sync_playwright():
        return MockPlaywright(MockBrowser(MockPage(fail_goto=True)))

    patch_playwright(monkeypatch, mock_sync_playwright)
    monkeypatch.setattr("time.sleep", lambda _: None)

    with pytest.raises(RuntimeError) as exc_info:
        fetch_with_playwright("https://example.com", retries=2)

    assert "Playwright request failed after 3 attempt(s)" in str(exc_info.value)
    assert "navigation failed" in str(exc_info.value)