import random
import time
import requests


RETRYABLE_STATUS_CODES = {403, 429, 500, 502, 503, 504}

def fetch_with_retry_requests(url: str, retries: int = 4, timeout: int = 20) -> str:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://www.google.com/",
        "Connection": "keep-alive",
    }

    with requests.Session() as session:
        for attempt in range(retries + 1):
            try:
                r = session.get(url, headers=headers, timeout=timeout)

                if r.status_code in RETRYABLE_STATUS_CODES:
                    raise requests.HTTPError(
                        f"retryable status {r.status_code}",
                        response=r,
                    )

                r.raise_for_status()
                return r.text

            except requests.RequestException as exc:
                retryable = True

                if exc.response is not None:
                    status = exc.response.status_code
                    retryable = status in RETRYABLE_STATUS_CODES

                if attempt >= retries or not retryable:
                    raise RuntimeError(
                        f"Request failed after {attempt + 1} attempt(s). "
                        f"Retryable={retryable}. Error: {exc}"
                    ) from exc

                delay = random.uniform(0, min(8.0, 0.5 * (2 ** attempt)))
                time.sleep(delay)

    raise RuntimeError("unreachable")  # pragma: no cover


def fetch_with_playwright(url: str, retries: int = 2, timeout: int = 30) -> str:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError(
            "Playwright is not installed. Use fetch_with_retry_requests, "
            "or deploy with Playwright/browser support."
        ) from exc
    
    timeout_ms = timeout * 1000

    user_agent = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )

    last_error = None

    for attempt in range(retries + 1):
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)

                try:
                    page = browser.new_page(
                        user_agent=user_agent,
                        viewport={"width": 1366, "height": 768},
                    )

                    page.goto(
                        url,
                        wait_until="domcontentloaded",
                        timeout=timeout_ms,
                    )

                    return page.content()

                finally:
                    browser.close()

        except Exception as exc:
            last_error = exc

            if attempt >= retries:
                raise RuntimeError(
                    f"Playwright request failed after {attempt + 1} attempt(s). "
                    f"Error: {exc}"
                ) from exc

            delay = random.uniform(0, min(8.0, 1.0 * (2 ** attempt)))
            time.sleep(delay)

    raise RuntimeError(f"unreachable: {last_error}")  # pragma: no cover
