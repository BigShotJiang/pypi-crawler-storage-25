# opticedge_cloud_utils/logger.py

import json
from enum import Enum


class LogLevel(str, Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


def log(level: LogLevel, message: str, **kwargs):
    payload = {
        "severity": level.value,
        "message": message,
        **_serialize(kwargs),
    }
    print(json.dumps(payload))


def _serialize(data):
    """Make values JSON-safe (e.g., ObjectId)."""
    safe = {}
    for k, v in data.items():
        try:
            json.dumps(v)
            safe[k] = v
        except TypeError:
            safe[k] = str(v)
    return safe