# opticedge_cloud_utils/normalize.py
from bson.objectid import ObjectId

def normalize_enum(value, enum_cls):
    """
    Safely convert a raw value to an Enum member.

    Returns:
        Enum member if valid
        None if value cannot be converted
    """
    try:
        return enum_cls(value)
    except (ValueError, TypeError):
        return None


def normalize_object_id(value):
    """Convert string to ObjectId when possible, otherwise return as-is."""
    if isinstance(value, ObjectId):
        return value
    if isinstance(value, str):
        try:
            return ObjectId(value)
        except Exception:
            return value
    return value
