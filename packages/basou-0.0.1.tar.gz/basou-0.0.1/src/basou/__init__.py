"""
Basou - A multi-AI agent harness.

This package name is reserved for the upcoming Basou release.
The actual implementation is under active development.

Visit https://basou.dev for updates.
"""

__version__ = "0.0.1"
__homepage__ = "https://basou.dev"


def main():
    """Entry point - displays Coming Soon message."""
    print(
        "Basou is coming soon.\n"
        "Visit https://basou.dev for updates."
    )


if __name__ == "__main__":
    main()
