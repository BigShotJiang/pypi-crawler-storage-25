#!/usr/bin/env python3
"""
Datris MCP Server

MCP server for AI-driven data platform operations — ingest, validate, transform,
analyze, and query data from enterprise sources. 32 tools covering ETL orchestration,
AI-generated data quality rules (Python codegen via LLM), vector database search,
and secrets-managed connectivity. Supports PostgreSQL, MongoDB, Kafka, S3/MinIO,
HashiCorp Vault, and vector stores (Qdrant, Weaviate, Milvus, Chroma, pgvector).

Usage:
    pip install -r requirements.txt

    # stdio mode (for Claude Desktop / Claude Code)
    python server.py

    # SSE mode (for Docker / remote agents)
    python server.py --sse --port 3000

    # Streamable HTTP mode (for Smithery / remote clients)
    python server.py --streamable-http --port 3000
"""

import argparse
import contextvars
import json
import os
import threading
import time
import uuid
from collections import deque
from typing import Any

import requests
from dotenv import load_dotenv
from mcp.server import Server
from mcp.types import Resource, Tool, TextContent

load_dotenv()

PIPELINE_URL = os.getenv("PIPELINE_URL", "http://localhost:8080")
PIPELINE_API_KEY = os.getenv("PIPELINE_API_KEY", "")
REQUIRE_API_KEY = os.getenv("REQUIRE_API_KEY", "").lower() in ("true", "1", "yes")
WEBSITE_URL = os.getenv("WEBSITE_URL", "https://datris.ai")

# Per-session API key for multi-tenant SSE/HTTP connections
_session_api_key: contextvars.ContextVar[str] = contextvars.ContextVar("_session_api_key", default="")
# Per-session id used for agent-monitor attribution
_session_id: contextvars.ContextVar[str] = contextvars.ContextVar("_session_id", default="")

# Agent-monitor: in-process activity buffer + session tracker.
# Ephemeral; cleared on restart. Safe to read via a plain lock.
_activity_buffer: deque = deque(maxlen=200)
_activity_sessions: dict[str, dict[str, Any]] = {}
_activity_lock = threading.Lock()
SESSION_IDLE_SECS = 30  # sessions with no activity for this many seconds are considered gone


_PREVIEW_ARG_KEYS = [
    "pipeline", "tap", "name", "collection", "query", "question",
    "text", "limit", "top_k", "page", "file", "filename",
]
_PREVIEW_VALUE_MAX = 40
_PREVIEW_MAX = 140


def _build_args_preview(args: Any) -> str:
    if not isinstance(args, dict):
        return ""
    parts: list[str] = []
    for key in _PREVIEW_ARG_KEYS:
        if key not in args:
            continue
        val = args[key]
        if isinstance(val, (dict, list)):
            s = "…"
        else:
            s = str(val).replace("\n", " ").strip()
            if len(s) > _PREVIEW_VALUE_MAX:
                s = s[:_PREVIEW_VALUE_MAX - 1] + "…"
        parts.append(f"{key}={s}")
        if len(parts) == 3:
            break
    preview = ", ".join(parts)
    if len(preview) > _PREVIEW_MAX:
        preview = preview[:_PREVIEW_MAX - 1] + "…"
    return preview


def _pretty_json(value: Any, max_chars: int | None = None) -> str:
    """Pretty-print a Python object as indented JSON. When max_chars is set,
    truncate with an ellipsis; pass None to keep the full string."""
    try:
        s = json.dumps(value, indent=2, default=str)
    except Exception:
        s = str(value)
    if max_chars is not None and len(s) > max_chars:
        s = s[:max_chars] + "\n…"
    return s


def _pretty_json_text(text: str, max_chars: int | None = None) -> str:
    """Pretty-print a string that may or may not already be JSON.
    Falls back to the raw string if parsing fails. When max_chars is set,
    truncate with an ellipsis; pass None to keep the full string."""
    if not text:
        return ""
    try:
        parsed = json.loads(text)
        s = json.dumps(parsed, indent=2, default=str)
    except Exception:
        s = text
    if max_chars is not None and len(s) > max_chars:
        s = s[:max_chars] + "\n…"
    return s


def _record_count_from_result(result_text: str) -> int | None:
    try:
        parsed = json.loads(result_text)
    except Exception:
        return None
    if isinstance(parsed, list):
        return len(parsed)
    if isinstance(parsed, dict):
        for key in ("pipelines", "taps", "results", "items", "records", "data", "rows"):
            val = parsed.get(key)
            if isinstance(val, list):
                return len(val)
    return None


def _read_client_info() -> tuple[str, str]:
    """Read MCP clientInfo (name, version) from the current request context.
    Returns ("", "") when unavailable (e.g. stdio-only bootstrap, or SDK internals changed)."""
    try:
        ctx = server.request_context
        if ctx is None:
            return ("", "")
        session = getattr(ctx, "session", None)
        if session is None:
            return ("", "")
        # Try common attribute names across MCP SDK versions.
        params = getattr(session, "client_params", None) or getattr(session, "_client_params", None)
        if params is None:
            return ("", "")
        ci = getattr(params, "clientInfo", None)
        if ci is None:
            return ("", "")
        name = getattr(ci, "name", "") or ""
        version = getattr(ci, "version", "") or ""
        return (name, version)
    except Exception:
        return ("", "")


def _activity_record(session_id: str, tool: str, status: str, latency_ms: int, api_key: str,
                     args: Any, result_text: str, error_msg: str) -> None:
    now = time.time()
    api_key_hint = api_key[:6] if api_key else ""
    client_name, client_version = _read_client_info()
    args_preview = _build_args_preview(args)
    args_full = _pretty_json(args) if args else ""
    response_preview = ""
    response_size = 0
    if result_text:
        response_size = len(result_text)
        response_preview = _pretty_json_text(result_text)
    record_count = _record_count_from_result(result_text) if status == "ok" else None
    error = ""
    if error_msg:
        error = error_msg if len(error_msg) <= 300 else error_msg[:300] + "…"

    with _activity_lock:
        _activity_buffer.append({
            "ts": now,
            "session_id": session_id,
            "tool": tool,
            "status": status,
            "latency_ms": latency_ms,
            "api_key_hint": api_key_hint,
            "client_name": client_name,
            "client_version": client_version,
            "args_preview": args_preview,
            "args_full": args_full,
            "response_preview": response_preview,
            "response_size": response_size,
            "record_count": record_count,
            "error": error,
        })
        sess = _activity_sessions.get(session_id)
        if sess is None:
            _activity_sessions[session_id] = {
                "session_id": session_id,
                "first_seen": now,
                "last_seen": now,
                "call_count": 1,
                "api_key_hint": api_key_hint,
                "client_name": client_name,
                "client_version": client_version,
            }
        else:
            sess["last_seen"] = now
            sess["call_count"] += 1
            if api_key_hint:
                sess["api_key_hint"] = api_key_hint
            if client_name and not sess.get("client_name"):
                sess["client_name"] = client_name
                sess["client_version"] = client_version


def _activity_session_open(session_id: str, api_key: str) -> None:
    now = time.time()
    api_key_hint = api_key[:6] if api_key else ""
    with _activity_lock:
        _activity_sessions[session_id] = {
            "session_id": session_id,
            "first_seen": now,
            "last_seen": now,
            "call_count": 0,
            "api_key_hint": api_key_hint,
        }


def _activity_session_close(session_id: str) -> None:
    with _activity_lock:
        _activity_sessions.pop(session_id, None)


def _activity_snapshot(since: float) -> dict[str, Any]:
    now = time.time()
    with _activity_lock:
        active_sessions = [
            s for s in _activity_sessions.values()
            if (now - s["last_seen"]) < SESSION_IDLE_SECS
        ]
        calls = [c for c in _activity_buffer if c["ts"] > since]
        return {
            "server_time": now,
            "sessions": sorted(active_sessions, key=lambda s: s["first_seen"]),
            "calls": calls,
        }

server = Server("datris", instructions="""\
Datris is the first AI Agent-Native Data Platform. It ingests, validates, transforms, and routes data to databases, message queues, and vector stores — all driven by pipeline configurations that AI agents can create and manage programmatically.

A pipeline config has two required sections: source and destination. Keep configs simple: source + destination only.

NEVER rules:
  - NEVER use profile_data to determine how to generate a pipeline configuration
  - NEVER add dataQuality or transformation sections unless explicitly requested
  - If data quality is needed, use codegen_rule on create_pipeline (plain-English validation instruction)
  - If transformation is needed, use codegen_transform on create_pipeline (plain-English transformation instruction)

Required workflow:
  1. Check existing pipelines and taps: call list_pipelines and list_taps. If a pipeline exists, data may already be in the destination — use metadata tools to discover and query it directly. If a tap exists, use run_tap or test_tap directly. Only create new pipelines or taps if needed.
  2. Create a pipeline: call create_pipeline. For STRUCTURED destinations (postgres, mongodb), pass sample data (base64-encoded) + filename so the schema is auto-detected. For VECTOR destinations (pgvector, qdrant, weaviate, milvus, chroma), pass ONLY pipeline name + destination — there is no schema, and base64'ing the document here just to satisfy the call is wasted tokens (the document goes through upload_data instead).
  3. Ingest data (choose one):
     Option A — Direct upload: call upload_data ONCE with the entire base64-encoded content and the pipeline name. Do NOT split the content into multiple uploads — vector destinations (pgvector, qdrant, weaviate, milvus, chroma) chunk server-side, and structured pipelines accept the whole file as one batch.
     Option B — Create a tap: use create_tap to provide an instruction (AI generates the script) or your own Python script that fetches data from an external source and pushes it into the pipeline automatically. See Tap workflow below.
  4. Monitor: call get_job_status and poll until status is COMPLETED or FAILED. You MUST wait for COMPLETED before querying.
  5. If FAILED: read the error message from get_job_status. Fix the issue (e.g., delete the pipeline, re-create with corrected parameters, re-upload).
  6. Query & search: use query_postgres, query_mongodb for structured data; search_qdrant, search_pgvector, etc. for vector search
  7. RAG: pass search results as context to ai_answer with the user's question

Tap workflow (for step 3 Option B):
  Taps are Python scripts that fetch data from external sources and push it into pipelines. Use taps when data needs to be pulled from APIs, websites, databases, or other external sources on demand or on a schedule.
  Two ways to create a tap:
    - With instruction: provide a plain-English instruction and the platform's AI generates the script. This is slower (1-2 minutes) because the platform must generate and store the script.
    - With your own script: write the Python fetch() function yourself and pass it as the script parameter. This is faster and gives you full control. The script must define a fetch() function that takes no arguments and returns a list of dictionaries.
  Writing the script yourself is often quicker and more reliable — you control the logic directly instead of waiting for AI generation and hoping it gets the implementation right on the first try.
  1. Create a tap: call create_tap with an instruction (AI generates the script) or with your own script
  2. Test: call test_tap to validate the script without pushing data
  3. If test fails: read the error, fix the script, and call create_tap again with a corrected script or updated instruction to regenerate. Repeat test until it succeeds.
  4. Run: call run_tap to execute and push data to the pipeline.
     After `run_tap` returns, READ the response's `persisted` field BEFORE doing anything else:
       - `persisted: true` → records were handed to the pipeline, but the load is async. You MUST call `get_pipeline_status(publisher_token=response.publisherToken)` and poll (re-call every few seconds) until `rollup.allDone` is true. Only THEN query the destination or report completion to the user. Reporting success before the poll finishes is a bug — the destination will appear empty. Read `rollup.status` for the outcome and `rollup.jobs[].lastError` for any failures.
       - `persisted: false` → records did NOT land in the destination. Read `persistedReason` and tell the user exactly why: `no_target_pipeline` (call update_tap to set one, then re-run), `test_mode` (you ran it in test mode — or mcp-server/datris are out of sync; flag it and stop), `run_error` (show the `error` string), `no_records` (source returned nothing).
     Note: `run_tap` does NOT return the records themselves (only `recordCount`). If you need to preview what the script produces, use `test_tap`.
  5. Schedule (optional): call update_tap with a cron_expression to run the tap on a schedule
  6. Verify ingestion outcome — the same check works for any run, manual or scheduled. The `publisherToken` is your handle on whether the data actually landed in the destination. After a manual `run_tap` you already have it in the response; for a scheduled (cron) run, call `get_tap_logs` and pick the relevant entry — every log entry that submitted records includes its `publisherToken`. Either way, call `get_pipeline_status(publisher_token=...)` and poll until `rollup.allDone` is true; then `rollup.status` tells you success/warning/error and `rollup.jobs[].lastError` tells you which file failed and why. The tap log only tells you the script ran; the publisher token is how you trace it through to whether the destination actually has the data. Prefer `get_tap_logs` over holding the token in your own context across many turns — if the conversation is compressed or you reconnect, you can always re-derive the token from the log.
  7. Manage: call update_tap to enable/disable, change schedule, or retarget pipeline; call get_tap to view details and script

Do NOT call check_service_health as part of the normal workflow — it is slow. Only use it for diagnostics if something fails.
Do NOT call update_secret unless you need to configure AI provider keys and they are not already set.
""")


def _effective_api_key() -> str:
    """Return the per-session API key if set, otherwise the global env var."""
    return _session_api_key.get() or PIPELINE_API_KEY


def _headers():
    """Build request headers."""
    h = {"Content-Type": "application/json"}
    key = _effective_api_key()
    if key:
        h["x-api-key"] = key
    return h


def _call(method, path, **kwargs):
    """Make an HTTP request to the pipeline API."""
    url = f"{PIPELINE_URL}{path}"
    try:
        resp = getattr(requests, method)(url, headers=_headers(), timeout=300, **kwargs)
        return resp.text
    except requests.RequestException as e:
        return json.dumps({"error": str(e)})


def _upload(path, file_path, data=None):
    """Upload a file via multipart POST to the pipeline API (local file path)."""
    with open(file_path, "rb") as f:
        files = {"file": (os.path.basename(file_path), f)}
        h = {}
        key = _effective_api_key()
        if key:
            h["x-api-key"] = key
        resp = requests.post(
            f"{PIPELINE_URL}{path}",
            headers=h,
            files=files,
            data=data or {},
            timeout=300
        )
        return resp.text


def _upload_content(path, content_b64, filename, data=None):
    """Upload base64-encoded content via multipart POST to the pipeline API."""
    import base64
    import tempfile

    # Fix missing base64 padding
    padded = content_b64 + "=" * (-len(content_b64) % 4)
    file_bytes = base64.b64decode(padded)
    with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{filename}") as tmp:
        tmp.write(file_bytes)
        tmp_path = tmp.name
    try:
        with open(tmp_path, "rb") as f:
            files = {"file": (filename, f)}
            h = {}
            key = _effective_api_key()
            if key:
                h["x-api-key"] = key
            resp = requests.post(
                f"{PIPELINE_URL}{path}",
                headers=h,
                files=files,
                data=data or {},
                timeout=300
            )
            return resp.text
    finally:
        os.unlink(tmp_path)


# ---------------------------------------------------------------------------
# MCP Resources
# ---------------------------------------------------------------------------

PIPELINE_CONFIG_REFERENCE = """\
# Datris Pipeline Configuration Reference

## Required Workflow — Follow These Steps

1. Call `list_pipelines` to check if the pipeline already exists.
2. If it exists, data may already be in the destination. Use metadata tools (`list_postgres_tables`, `list_mongodb_collections`, `list_qdrant_collections`, etc.) to discover it and query/search directly. Only re-ingest if the data is stale or needs updating.
3. If the pipeline does not exist, call `create_pipeline`. Structured destinations (postgres, mongodb) need sample data (base64) for schema auto-detection. Vector destinations (pgvector/qdrant/weaviate/milvus/chroma) need only pipeline name + destination — no sample content; the document goes through `upload_data`.
5. Call `check_service_health` to verify the target destination service is available.
6. Call `create_pipeline` with the config.
7. Call `upload_data` ONCE with your full data (base64-encoded) and the pipeline name. Do not pre-chunk — vector destinations chunk server-side, structured pipelines accept the whole file as one batch.
8. Call `get_job_status` to monitor processing. Poll until status is COMPLETED or FAILED.
9. Query or search the data: `query_postgres`, `query_mongodb`, `search_qdrant`, `search_pgvector`, etc.
10. For RAG: pass search results as context to `ai_answer` with the user's question.

---

## Config Structure

Pass this JSON to `create_pipeline`. Only `name`, `source`, and `destination` are required. For reliable data sources, do NOT add dataQuality, transformation, or preprocessor sections — keep it simple. Only add those sections if the data source is unreliable or you have a specific processing requirement.

```json
{
  "name": "pipeline_name",
  "source": { ... },
  "preprocessor": { ... },
  "dataQuality": { ... },
  "transformation": { ... },
  "destination": { ... }
}
```

## Source

Set `source.fileAttributes` to one of these (create_pipeline does this automatically):

### fileAttributes — choose one

**csvAttributes** — use for CSV/TSV files:
```json
"csvAttributes": {
  "delimiter": ",",
  "header": true,
  "encoding": "UTF-8"
}
```

**jsonAttributes** — for JSON files:
```json
"jsonAttributes": {
  "everyRowContainsObject": false,
  "encoding": "UTF-8"
}
```

**xmlAttributes** — for XML files:
```json
"xmlAttributes": {
  "everyRowContainsObject": false,
  "encoding": "UTF-8"
}
```

**xlsAttributes** — for Excel files:
```json
"xlsAttributes": {
  "worksheet": 0,
  "tempCsvFileDelimiter": ","
}
```

**unstructuredAttributes** — use for PDFs, DOCX, TXT. Must use a vector DB destination:
```json
"unstructuredAttributes": {
  "fileExtension": "pdf",
  "preserveFilename": true
}
```

### schemaProperties — set field names and types (create_pipeline does this automatically, omit for unstructured)

```json
"schemaProperties": {
  "fields": [
    {"name": "column_name", "type": "string"},
    {"name": "price", "type": "double"},
    {"name": "quantity", "type": "int"}
  ]
}
```

Supported field types: `string`, `int`, `bigint`, `float`, `double`, `boolean`, `date`, `timestamp`

### streamAttributes (optional, for streaming sources like Kafka)

```json
"streamAttributes": {
  "type": "kafka"
}
```

### databaseAttributes (optional, for database pull sources)

```json
"databaseAttributes": {
  "type": "postgres",
  "postgresSecretsName": "oss/postgres",
  "database": "mydb",
  "schema": "public",
  "table": "source_table",
  "cronExpression": "0 0 * * *",
  "timestampFieldName": "updated_at",
  "includeFields": ["col1", "col2"],
  "sqlOverride": "SELECT * FROM source_table WHERE active = true"
}
```

## Preprocessor (optional)

Set this to call an external REST endpoint before processing. Use for custom validation or enrichment.

```json
"preprocessor": {
  "endpoint": "https://my-service.example.com/preprocess",
  "bearerToken": "token123",
  "apiKey": "key123",
  "timeoutMs": 300000,
  "async": false
}
```

## Data Quality (optional — only if explicitly requested)

Use `codegen_rule` on `create_pipeline` for AI-powered validation. Datris generates a Python script from the instruction and runs it locally.

For JSON/XML schema validation, use `validationSchema` (upload schema file first with `upload_config`).

For CSV header validation, use `validateFileHeader: true`.

## Transformation (optional — only if explicitly requested)

Use `codegen_transform` on `create_pipeline` for AI-powered transformation. Datris generates a Python script from the instruction and runs it locally.

Example config (for reference only — agents should use create_pipeline params, not construct configs):

```json
"transformation": {
  "aiTransformation": {
    "instruction": "convert all dates to YYYY-MM-DD format"
  }
}
```

## Destination (required — set one)

Call `check_service_health` first to verify the target service is available.

### database — PostgreSQL (use for structured CSV data)

```json
"destination": {
  "database": {
    "dbName": "datris",
    "schema": "public",
    "table": "my_table",
    "usePostgres": true,
    "keyFields": ["id"],
    "truncateBeforeWrite": false,
    "manageTableManually": false
  }
}
```

### database — MongoDB (use for JSON data)

```json
"destination": {
  "database": {
    "dbName": "datris",
    "table": "my_collection",
    "useMongoDB": true
  }
}
```

### objectStore — S3/MinIO

```json
"destination": {
  "objectStore": {
    "prefixKey": "data/output/",
    "fileFormat": "parquet",
    "writeMode": "overwrite",
    "partitionBy": ["date", "region"]
  }
}
```

File formats: `parquet`, `csv`, `json`, `orc`
Write modes: `overwrite`, `append`, `ignore`, `error`

### kafka

```json
"destination": {
  "kafka": {
    "topic": "my-topic",
    "keyField": "id"
  }
}
```

### activeMQ

```json
"destination": {
  "activeMQ": {
    "queueName": "my-queue"
  }
}
```

### restEndpoint

```json
"destination": {
  "restEndpoint": {
    "endpoint": "https://my-service.example.com/ingest",
    "bearerToken": "token123",
    "timeoutMs": 300000
  }
}
```

### Vector databases — use for RAG / semantic search with unstructured files (PDF, DOCX, TXT)

All vector DB destinations require chunking and embedding config. Call `check_service_health` to see which vector DBs are available.

**qdrant:**
```json
"destination": {
  "qdrant": {
    "collectionName": "my_documents",
    "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50},
    "metadata": {"source": "annual_reports", "year": "2026"},
    "embeddingSecretName": "oss/embedding",
    "qdrantSecretName": "oss/qdrant"
  }
}
```

**weaviate:**
```json
"destination": {
  "weaviate": {
    "className": "MyDocuments",
    "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50},
    "metadata": {"source": "annual_reports"},
    "embeddingSecretName": "oss/embedding",
    "weaviateSecretName": "oss/weaviate"
  }
}
```

**milvus:**
```json
"destination": {
  "milvus": {
    "collectionName": "my_documents",
    "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50},
    "metadata": {"source": "annual_reports"},
    "embeddingSecretName": "oss/embedding",
    "milvusSecretName": "oss/milvus"
  }
}
```

**chroma:**
```json
"destination": {
  "chroma": {
    "collectionName": "my_documents",
    "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50},
    "metadata": {"source": "annual_reports"},
    "embeddingSecretName": "oss/embedding",
    "chromaSecretName": "oss/chroma"
  }
}
```

**pgvector:**
```json
"destination": {
  "pgvector": {
    "tableName": "my_documents",
    "schemaName": "public",
    "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50},
    "metadata": {"source": "annual_reports"},
    "embeddingSecretName": "oss/embedding",
    "postgresSecretName": "oss/pgvector"
  }
}
```

## Example Configs — for reference only (create_pipeline generates these automatically)

### CSV → PostgreSQL with AI data quality

```json
{
  "name": "stock_prices",
  "source": {
    "fileAttributes": {
      "csvAttributes": {"delimiter": ",", "header": true, "encoding": "UTF-8"}
    },
    "schemaProperties": {
      "fields": [
        {"name": "symbol", "type": "string"},
        {"name": "date", "type": "string"},
        {"name": "close", "type": "double"},
        {"name": "volume", "type": "int"}
      ]
    }
  },
  "dataQuality": {
    "aiRule": {
      "instruction": "All price columns must be positive. Volume must be a positive integer.",
      "onFailureIsError": false
    }
  },
  "destination": {
    "database": {
      "dbName": "datris",
      "schema": "public",
      "table": "stock_prices",
      "usePostgres": true
    }
  }
}
```

### PDF → pgvector for RAG

```json
{
  "name": "financial_docs",
  "source": {
    "fileAttributes": {
      "unstructuredAttributes": {"fileExtension": "pdf", "preserveFilename": true}
    }
  },
  "destination": {
    "pgvector": {
      "tableName": "financial_documents",
      "schemaName": "public",
      "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50},
      "metadata": {"company": "Acme Corp", "document_type": "10-K"},
      "embeddingSecretName": "oss/embedding",
      "postgresSecretName": "oss/pgvector"
    }
  }
}
```

### JSON → MongoDB

```json
{
  "name": "events",
  "source": {
    "fileAttributes": {
      "jsonAttributes": {"everyRowContainsObject": false, "encoding": "UTF-8"}
    },
    "schemaProperties": {
      "fields": [{"name": "_json", "type": "string"}]
    }
  },
  "destination": {
    "database": {
      "dbName": "datris",
      "table": "events",
      "useMongoDB": true
    }
  }
}
```
"""


@server.list_resources()
async def list_resources():
    return [
        Resource(
            uri="datris://pipeline-config-reference",
            name="Pipeline Configuration Reference",
            description="Complete reference for building Datris pipeline configurations. Covers all source types (CSV, JSON, XML, PDF), AI-powered data quality (CodeGen), AI transformations (CodeGen), and all destination types (PostgreSQL, MongoDB, Kafka, vector databases). Read this before using create_pipeline.",
            mimeType="text/plain",
        )
    ]


@server.read_resource()
async def read_resource(uri):
    if str(uri) == "datris://pipeline-config-reference":
        return PIPELINE_CONFIG_REFERENCE
    raise ValueError(f"Unknown resource: {uri}")


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------

@server.list_tools()
async def list_tools():
    return [
        # --- Pipeline Management ---
        Tool(
            name="list_pipelines",
            description="List all registered pipeline configurations. Each pipeline defines a complete data processing flow: source format and schema, AI-powered data quality and transformations, and destination (database, message queue, or vector store).",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="get_pipeline",
            description="Get a specific pipeline configuration by name. Returns the full JSON config including source, dataQuality, transformation, preprocessor, and destination sections.",
            inputSchema={
                "type": "object",
                "properties": {
                    "pipeline": {
                        "type": "string",
                        "description": "Pipeline name"
                    }
                },
                "required": ["pipeline"]
            }
        ),
        Tool(
            name="create_pipeline",
            description="Create a pipeline. For STRUCTURED destinations (postgres, mongodb): send a small sample file and the schema is auto-detected — you do not specify field names or types. For VECTOR destinations (pgvector, qdrant, weaviate, milvus, chroma): there is no schema; pass ONLY pipeline + destination (and optionally filename to set the file-extension hint). Do NOT base64 the document just to satisfy this call — that's wasted tokens; send the document later via upload_data.",
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "Base64-encoded sample data file content. REQUIRED for structured destinations (postgres, mongodb). OMIT for vector destinations — the file goes through upload_data after this call returns."
                    },
                    "filename": {
                        "type": "string",
                        "description": "Filename (e.g., data.csv, report.json, orders.xml). REQUIRED for structured destinations. Optional for vector destinations — only used as a fileExtension hint (defaults to txt)."
                    },
                    "pipeline": {
                        "type": "string",
                        "description": "Pipeline name"
                    },
                    "destination": {
                        "type": "string",
                        "enum": ["postgres", "mongodb", "qdrant", "weaviate", "milvus", "chroma", "pgvector"],
                        "description": "Destination type (default: postgres for CSV, mongodb for JSON/XML)"
                    },
                    "table": {
                        "type": "string",
                        "description": "Destination table or collection name (default: pipeline name)"
                    },
                    "database": {
                        "type": "string",
                        "description": "Destination database name (default: datris)"
                    },
                    "delimiter": {
                        "type": "string",
                        "description": "CSV delimiter (default: comma)"
                    },
                    "header": {
                        "type": "boolean",
                        "description": "Whether CSV has a header row (default: true)"
                    },
                    "codegen_rule": {
                        "type": "string",
                        "description": "Optional data quality validation rule as a plain-English instruction. Only add when the user explicitly requests validation. Datris will generate a Python validation script from this instruction and run it locally against all data. Example: 'Validate that all dates are YYYY-MM-DD format and all email addresses are valid'"
                    },
                    "codegen_transform": {
                        "type": "string",
                        "description": "Optional transformation instruction as a plain-English description. Only add when the user explicitly requests transformation. Datris will generate a Python script from this instruction and run it locally to transform all data. Example: 'Convert all date columns to YYYY/MM/DD format and uppercase all name fields'"
                    }
                },
                "required": ["pipeline"]
            }
        ),
        Tool(
            name="delete_pipeline",
            description="Delete a registered pipeline configuration by name. This removes the config but does not delete any data already processed by the pipeline.",
            inputSchema={
                "type": "object",
                "properties": {
                    "pipeline": {
                        "type": "string",
                        "description": "Pipeline name to delete"
                    }
                },
                "required": ["pipeline"]
            }
        ),
        Tool(
            name="upload_data",
            description="Upload data to a registered pipeline for processing. Send the ENTIRE file content as a single base64-encoded string in ONE call — do not pre-split or chunk the content client-side. Vector destinations (pgvector, qdrant, weaviate, milvus, chroma) apply recursive chunking server-side using the pipeline's configured chunkSize/chunkOverlap; for those, one upload_data call yields many embedded chunks automatically. The pipeline's rules are applied: schema validation, data quality checks, transformations, then routing to the configured destination. Returns a pipelineToken for tracking job status via get_job_status.",
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "Base64-encoded file content"
                    },
                    "filename": {
                        "type": "string",
                        "description": "Filename (e.g., data.csv, report.json, orders.xml)"
                    },
                    "pipeline": {
                        "type": "string",
                        "description": "Pipeline name to process the data with"
                    }
                },
                "required": ["content", "filename", "pipeline"]
            }
        ),
        Tool(
            name="get_job_status",
            description="Get job status. Query by pipeline_token (from upload_data) for detailed status of a specific job, or by pipeline_name for a paginated summary of all jobs for that pipeline. Status values: RUNNING, COMPLETED, FAILED, CANCELLED. IMPORTANT: If status is RUNNING, you MUST keep polling (wait a few seconds and call again) until status changes to COMPLETED or FAILED. Do NOT proceed to query/search until the job is COMPLETED. If FAILED, read the error message and fix the issue.",
            inputSchema={
                "type": "object",
                "properties": {
                    "pipeline_token": {
                        "type": "string",
                        "description": "Pipeline token returned from upload_file"
                    },
                    "pipeline_name": {
                        "type": "string",
                        "description": "Pipeline name to get latest status for"
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for paginated results (default: 1)"
                    }
                }
            }
        ),
        Tool(
            name="kill_job",
            description="Kill a running pipeline job by its pipeline token. The job thread will be interrupted and the job marked as cancelled.",
            inputSchema={
                "type": "object",
                "properties": {
                    "pipeline_token": {
                        "type": "string",
                        "description": "Pipeline token of the running job to kill"
                    }
                },
                "required": ["pipeline_token"]
            }
        ),
        Tool(
            name="profile_data",
            description="Send data and use AI to generate a comprehensive data profile: summary statistics per column, data quality issues detected, and suggested validation rules. Use the suggested aiRule when building a pipeline's dataQuality section.",
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "Base64-encoded file content"
                    },
                    "filename": {
                        "type": "string",
                        "description": "Filename (e.g., sample.csv)"
                    },
                    "delimiter": {
                        "type": "string",
                        "description": "CSV delimiter (default: comma)"
                    },
                    "header": {
                        "type": "boolean",
                        "description": "Whether CSV has a header row (default: true)"
                    },
                    "sample_size": {
                        "type": "integer",
                        "description": "Number of rows to sample for profiling (default: 200)"
                    }
                },
                "required": ["content", "filename"]
            }
        ),
        Tool(
            name="get_version",
            description="Get the Datris server version.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="check_service_health",
            description="Check which backend services are up, down, or not configured. Returns the health status of PostgreSQL, MongoDB, MinIO, ActiveMQ, Kafka, and any configured vector databases (Qdrant, Weaviate, Milvus, Chroma, pgvector). Call this before attempting search or query operations to know which services are available.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        # --- Vector Database Search Tools ---
        Tool(
            name="search_qdrant",
            description="Semantic search across a Qdrant vector database collection. Takes a natural language query, generates an embedding, and returns the most similar document chunks with similarity scores. For RAG: pass the returned text to ai_answer with the user's question.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Natural language search query"},
                    "collection": {"type": "string", "description": "Qdrant collection name (default: financial_documents)"},
                    "top_k": {"type": "integer", "description": "Number of results to return (default: 5)"},
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="search_weaviate",
            description="Semantic search across a Weaviate vector database class. Takes a natural language query, generates an embedding, and returns the most similar document chunks with similarity scores. For RAG: pass the returned text to ai_answer with the user's question.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Natural language search query"},
                    "class_name": {"type": "string", "description": "Weaviate class name (default: FinancialDocuments)"},
                    "top_k": {"type": "integer", "description": "Number of results to return (default: 5)"},
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="search_milvus",
            description="Semantic search across a Milvus vector database collection. Takes a natural language query, generates an embedding, and returns the most similar document chunks with similarity scores. For RAG: pass the returned text to ai_answer with the user's question.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Natural language search query"},
                    "collection": {"type": "string", "description": "Milvus collection name (default: financial_documents)"},
                    "top_k": {"type": "integer", "description": "Number of results to return (default: 5)"},
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="search_pgvector",
            description="Semantic search across a PostgreSQL pgvector table using cosine distance. Takes a natural language query, generates an embedding, and returns the most similar document chunks with similarity scores. Use list_postgres_tables with vector_only=true to discover available pgvector tables. For RAG: pass the returned text to ai_answer.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Natural language search query"},
                    "table": {"type": "string", "description": "Table name (default: financial_documents)"},
                    "schema": {"type": "string", "description": "PostgreSQL schema (default: public)"},
                    "top_k": {"type": "integer", "description": "Number of results to return (default: 5)"},
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="search_chroma",
            description="Semantic search across a Chroma vector database collection. Takes a natural language query, generates an embedding, and returns the most similar document chunks with similarity scores. For RAG: pass the returned text to ai_answer with the user's question.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Natural language search query"},
                    "collection": {"type": "string", "description": "Chroma collection name (default: financial_documents)"},
                    "top_k": {"type": "integer", "description": "Number of results to return (default: 5)"},
                },
                "required": ["query"]
            }
        ),
        # --- Database Query Tools ---
        Tool(
            name="query_postgres",
            description="Execute a read-only SQL SELECT query against PostgreSQL. Use the metadata discovery tools (list_postgres_databases, list_postgres_schemas, list_postgres_tables, list_postgres_columns) first to explore available data before constructing queries. Only SELECT is allowed; LIMIT is auto-appended if missing.",
            inputSchema={
                "type": "object",
                "properties": {
                    "sql": {"type": "string", "description": "SQL SELECT query to execute"},
                    "limit": {"type": "integer", "description": "Maximum rows to return (default: 100). Pass -1 for unlimited — no cap, returns every matching row."},
                },
                "required": ["sql"]
            }
        ),
        Tool(
            name="query_mongodb",
            description="Query a MongoDB collection with optional filter and projection. Use list_mongodb_databases and list_mongodb_collections first to discover available data. Returns matching documents as JSON.",
            inputSchema={
                "type": "object",
                "properties": {
                    "collection": {"type": "string", "description": "MongoDB collection name"},
                    "filter": {"type": "object", "description": "MongoDB query filter (default: {})"},
                    "projection": {"type": "object", "description": "Fields to include/exclude (default: all fields)"},
                    "limit": {"type": "integer", "description": "Maximum documents to return (default: 20). Pass -1 for unlimited — no cap, returns every matching document."},
                },
                "required": ["collection"]
            }
        ),
        Tool(
            name="query_natural",
            description="Ask a question in natural language about data in a PostgreSQL table. The AI generates a SQL query from the question and table schema, executes it, and returns the results. Use this instead of writing SQL manually.",
            inputSchema={
                "type": "object",
                "properties": {
                    "question": {"type": "string", "description": "Natural language question about the data"},
                    "table": {"type": "string", "description": "PostgreSQL table name to query"},
                    "schema": {"type": "string", "description": "PostgreSQL schema (default: public)"},
                    "database": {"type": "string", "description": "Database name (default: datris)"},
                    "limit": {"type": "integer", "description": "Maximum rows to return (default: 100). Pass -1 for unlimited — no cap, returns every matching row."},
                },
                "required": ["question", "table"]
            }
        ),
        # --- Metadata Discovery Tools ---
        Tool(
            name="list_postgres_databases",
            description="List all PostgreSQL databases available in the Datris platform. Use this as the first step when exploring what data has been ingested into PostgreSQL destinations.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="list_postgres_schemas",
            description="List all schemas in a PostgreSQL database. Schemas organize tables within a database (e.g., 'public', 'analytics'). Use after list_postgres_databases to drill into a specific database.",
            inputSchema={
                "type": "object",
                "properties": {
                    "database": {"type": "string", "description": "Database name (default: datris)"},
                },
            }
        ),
        Tool(
            name="list_postgres_tables",
            description="List all tables in a PostgreSQL schema. Set vector_only=true to show only pgvector embedding tables, or false (default) to show regular data tables. Use after list_postgres_schemas.",
            inputSchema={
                "type": "object",
                "properties": {
                    "database": {"type": "string", "description": "Database name (default: datris)"},
                    "schema": {"type": "string", "description": "Schema name (default: public)"},
                    "vector_only": {"type": "boolean", "description": "If true, only return tables with an embedding column (pgvector tables). Default: false"},
                },
            }
        ),
        Tool(
            name="list_postgres_columns",
            description="List all columns and their data types for a specific PostgreSQL table. Use this to understand table structure before writing a query_postgres SQL query.",
            inputSchema={
                "type": "object",
                "properties": {
                    "database": {"type": "string", "description": "Database name (default: datris)"},
                    "schema": {"type": "string", "description": "Schema name (default: public)"},
                    "table": {"type": "string", "description": "Table name"},
                },
                "required": ["table"]
            }
        ),
        Tool(
            name="list_mongodb_databases",
            description="List all MongoDB databases available in the Datris platform. Use this as the first step when exploring what data has been ingested into MongoDB destinations.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="list_mongodb_collections",
            description="List MongoDB collections. If database is specified, lists collections in that database. If omitted, lists all collections across all databases in 'db.collection' format.",
            inputSchema={
                "type": "object",
                "properties": {
                    "database": {"type": "string", "description": "Database name (optional; omit to list from all databases)"},
                },
            }
        ),
        # --- Vector Store Metadata ---
        Tool(
            name="list_qdrant_collections",
            description="List all collections in the Qdrant vector database. Use this to discover available collections before running search_qdrant.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="list_weaviate_classes",
            description="List all classes in the Weaviate vector database. Use this to discover available classes before running search_weaviate.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="list_milvus_collections",
            description="List all collections in the Milvus vector database. Use this to discover available collections before running search_milvus.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="list_chroma_collections",
            description="List all collections in the Chroma vector database. Use this to discover available collections before running search_chroma.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="list_pgvector_collections",
            description="List all pgvector tables (tables with an embedding column) in PostgreSQL. Use this to discover available collections before running search_pgvector.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        # --- AI Tools ---
        Tool(
            name="ai_answer",
            description="Ask the Datris AI to answer a question based on provided context. Ideal for RAG workflows: first retrieve relevant chunks using a search tool (search_qdrant, search_pgvector, etc.), then pass the retrieved text as context along with the user's question to get a synthesized answer.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "The question to answer"},
                    "context": {"type": "string", "description": "Context text to base the answer on (e.g., retrieved document chunks)"},
                },
                "required": ["query", "context"]
            }
        ),
        # --- Configuration Tools ---
        Tool(
            name="upload_config",
            description="Upload a configuration file to the Datris platform. Supports 'validation-schema' (JSON Schema files used in pipeline dataQuality schema validation). Send the file content as base64.",
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {"type": "string", "description": "Base64-encoded file content"},
                    "filename": {"type": "string", "description": "Filename (e.g., schema.json, transform.js)"},
                    "type": {"type": "string", "enum": ["validation-schema"], "description": "Config file type: 'validation-schema' for JSON Schema"},
                },
                "required": ["content", "filename", "type"]
            }
        ),
        # --- Secrets ---
        Tool(
            name="update_secret",
            description="Update an AI provider secret in the Datris platform. Use this to configure your AI API keys so Datris can use AI features (data profiling, schema generation, AI transformations, RAG). Only AI-related secrets can be updated: anthropic, openai, ollama, embedding.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "enum": ["anthropic", "openai", "ollama", "embedding"],
                        "description": "Secret name: anthropic, openai, ollama, or embedding"
                    },
                    "fields": {
                        "type": "object",
                        "description": "Key-value fields to set. Typical fields: endpoint (API URL), model (model name), apiKey (API key)"
                    },
                },
                "required": ["name", "fields"]
            }
        ),
        Tool(
            name="create_tap_secret",
            description=(
                "Create or update a secret for a tap to use. The secret's fields are "
                "injected as environment variables into the tap's Python script at runtime. "
                "Use this before create_tap when the tap needs credentials (API key, DB "
                "password, etc.). Reference the secret by passing its name as secret_name "
                "to create_tap. By default, fails if a secret with this name already exists — "
                "pass overwrite=true to replace it (ask the user first). Agents can only "
                "overwrite secrets that were also created by an agent (tagged _type=tap); "
                "secrets owned by a human user must be updated via the UI."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Secret name. Must not use reserved AI-slot names (anthropic, openai, ollama, embedding, ai-primary, codegen). Convention: lowercase, hyphenated, e.g. 'stripe-api-key'."
                    },
                    "fields": {
                        "type": "object",
                        "description": "Key-value fields. Each key becomes an env var name in the tap script; e.g., {\"apiKey\": \"sk_...\"} is read as os.environ['apiKey']."
                    },
                    "overwrite": {
                        "type": "boolean",
                        "description": "If true, replace an existing secret with the same name. Default false (fails on collision). Only tap-typed secrets can be overwritten by an agent.",
                        "default": False
                    },
                },
                "required": ["name", "fields"]
            }
        ),
        Tool(
            name="delete_tap_secret",
            description=(
                "Delete a tap secret. Only secrets created by an agent (tagged _type=tap) "
                "can be deleted via this tool; secrets owned by a human user must be "
                "removed from the Secrets tab. Use this to clean up after a tap is no "
                "longer needed."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the tap secret to delete."
                    },
                },
                "required": ["name"]
            }
        ),
        # --- Managed Service ---
        Tool(
            name="signup_trial",
            description="Sign up for a free 14-day Datris trial. Returns an API key you can use to connect to the hosted MCP endpoint. No API key required to call this tool — it is the bootstrap for getting one.",
            inputSchema={
                "type": "object",
                "properties": {
                    "email": {"type": "string", "description": "Email address for the trial account"},
                    "password": {"type": "string", "description": "Password for the trial account (min 8 characters)"},
                    "company": {"type": "string", "description": "Company or project name"},
                    "ai_provider": {
                        "type": "string",
                        "enum": ["anthropic", "openai"],
                        "description": "AI provider for the trial (default: anthropic)"
                    },
                },
                "required": ["email", "password", "company"]
            }
        ),
        Tool(
            name="upgrade_to_dedicated",
            description="Upgrade from a shared trial to a dedicated Datris instance. Returns a Stripe checkout URL — the user must complete payment in their browser. After payment, provisioning starts automatically. Use check_upgrade_status to monitor progress.",
            inputSchema={
                "type": "object",
                "properties": {
                    "droplet_size": {
                        "type": "string",
                        "enum": ["s-2vcpu-8gb", "s-4vcpu-16gb", "s-8vcpu-32gb", "s-16vcpu-64gb"],
                        "description": "Compute size (default: s-2vcpu-8gb)"
                    },
                    "storage_gb": {
                        "type": "integer",
                        "enum": [25, 50, 100, 250, 500, 1000],
                        "description": "Block storage in GB (default: 25)"
                    },
                    "region": {
                        "type": "string",
                        "description": "Datacenter region (default: nyc1). Options: nyc1, nyc3, sfo3, ams3, lon1, fra1, tor1, blr1, sgp1, syd1"
                    },
                },
                "required": []
            }
        ),
        Tool(
            name="check_upgrade_status",
            description="Check the status of a dedicated instance upgrade. Returns 'none' if no upgrade started, 'provisioning' if in progress, or 'active' with the new MCP endpoint URL and API key when ready. No input needed — your identity is resolved from your API key.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),

        # --- Discovery ---
        Tool(
            name="discover_source",
            description="Discover available datasets from any data source. Chat with AI to enumerate datasets from a Python package, API, website, or database. Returns a structured dataset catalog with parameters and tap instruction templates. Use the returned tap instructions with create_tap to build taps for selected datasets.",
            inputSchema={
                "type": "object",
                "properties": {
                    "message": {
                        "type": "string",
                        "description": "What to discover (e.g., 'What datasets are available in yfinance?')"
                    },
                    "messages": {
                        "type": "array",
                        "description": "Full conversation history for multi-turn discovery. Each item has 'role' and 'content'. If omitted, 'message' is used as a single user message.",
                        "items": {
                            "type": "object",
                            "properties": {
                                "role": {"type": "string"},
                                "content": {"type": "string"}
                            }
                        }
                    }
                },
                "required": ["message"]
            }
        ),

        # --- Taps ---
        Tool(
            name="create_tap",
            description=(
                "Create a tap — a Python script that fetches data from an external source and pushes it into a pipeline. Provide a plain-English instruction to have AI generate the script, or supply your own script directly. "
                "If the user wants the tap to feed a pipeline, pass `target_pipeline` now. Without it, `run_tap` will fetch but not persist (response will show `persisted: false, persistedReason: \"no_target_pipeline\"`) — you'd then need to call update_tap to wire a pipeline. Only skip target_pipeline if the user explicitly wants a fetch-only tap."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Unique tap name (e.g., 'weather-data')"
                    },
                    "instruction": {
                        "type": "string",
                        "description": "Plain-English instruction for AI script generation (e.g., 'Fetch current weather for NYC from Open-Meteo API'). If provided, AI generates the Python script."
                    },
                    "script": {
                        "type": "string",
                        "description": "Raw Python source code with a fetch() function. Use this to provide your own script instead of AI generation."
                    },
                    "target_pipeline": {
                        "type": "string",
                        "description": "Name of the pipeline to push fetched data into"
                    },
                    "cron_expression": {
                        "type": "string",
                        "description": "Optional Quartz CRON expression for scheduling (e.g., '0 0 * * * ?' for hourly)"
                    },
                    "secret_name": {
                        "type": "string",
                        "description": "Vault secret name containing API keys/credentials the script needs"
                    },
                    "tap_type": {
                        "type": "string",
                        "enum": ["structured", "document"],
                        "description": "Tap type. 'structured' (default) returns rows of records. 'document' returns a list of {uri, filename, content (base64)} dicts; the platform stages each document and uses a ledger to skip files it has already processed. A document tap's target_pipeline MUST have an unstructuredAttributes source and a vector-store destination (qdrant, pgvector, weaviate, milvus, or chroma) — the server rejects save attempts that violate this."
                    },
                    "packages": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Extra pip packages the script imports that aren't pre-installed. Required when `script` imports non-stdlib modules beyond the pre-installed set (requests, beautifulsoup4, pandas, lxml, feedparser, boto3, google-cloud-storage, azure-storage-blob, openpyxl, pyyaml, python-dateutil, pytz). Example: ['yfinance', 'alpha_vantage']. When `instruction` is used instead of `script`, the AI populates this automatically — if you pass it anyway, your value wins."
                    },
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="list_taps",
            description="List all taps with their status, target pipeline, schedule, and last run info.",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="run_tap",
            description=(
                "Manually trigger a tap. Executes the script; when a target pipeline is configured, hands records to the pipeline async. "
                "The response carries `recordCount`, `publisherToken`, `pipelineTokens`, `persisted`, `persistedReason`, and the script's `logs` — but NOT the records themselves. "
                "If you need to preview what the script produces, call `test_tap` instead. "
                "REQUIRED next steps based on the response:\n"
                "  • `persisted: true` → load is still running. Call `get_pipeline_status(publisher_token=response.publisherToken)` and poll until `rollup.allDone` is true. Then read `rollup.status` (`success`/`warning`/`error`) and `rollup.jobs[].lastError`. Do not report completion or query the destination before that.\n"
                "  • `persisted: false` → the destination was NOT written. Read `persistedReason`:\n"
                "      - `no_target_pipeline`: tap has no pipeline wired. Tell the user; offer to call update_tap.\n"
                "      - `test_mode`: ran in test mode (or mcp-server/datris version mismatch). Flag it; do not report data as stored.\n"
                "      - `run_error`: show the `error` string.\n"
                "      - `no_records`: source returned nothing.\n"
                "      - `debounced`: this tap was triggered server-side within the last 5 seconds. Do NOT retry — your previous call is still running. Use `get_tap_logs` to find the live run's `publisherToken`, then poll `get_pipeline_status`.\n"
                "      - `already_running` (response `status: skipped`): another run_tap for this tap is already in flight in this agent session. Same handling as `debounced`: wait, then look up the live run in `get_tap_logs`.\n"
                "The response's `publisherToken` covers every ingestion job this run submitted (structured taps = 1, document taps = N). One `get_pipeline_status` call with the publisherToken sees them all."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the tap to run"
                    },
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="get_pipeline_status",
            description=(
                "Read pipeline ingestion status. Use this after `run_tap` to watch a tap-submitted load progress. "
                "Pass `publisher_token` to see every job the tap run submitted (the recommended option — works for both structured and document taps). "
                "Pass `pipeline_token` for a single ingestion job. Exactly one of the two must be supplied. "
                "Response shape: `{rollup: {allDone, status, jobs: [...]}, events: [...]}`. "
                "Poll every few seconds until `rollup.allDone` is true, then read `rollup.status` (`success` | `warning` | `error`) for the outcome. "
                "Per-job detail is in `rollup.jobs[]` — each entry has `pipelineToken`, `pipeline`, `filename`, `status`, `startedAt`, `lastEventAt`, `elapsed`, and `lastError` (populated on failure with `processName` and `description`). "
                "`events[]` is the raw begin/info/end audit trail if you need it; the rollup is the source of truth for completion."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "publisher_token": {
                        "type": "string",
                        "description": "UUID returned from run_tap response. Returns status rows for ALL jobs this tap run submitted."
                    },
                    "pipeline_token": {
                        "type": "string",
                        "description": "UUID for a single ingestion job. Returns status rows for that one job."
                    },
                },
                "required": []
            }
        ),
        Tool(
            name="delete_tap",
            description="Delete a tap and its stored script.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the tap to delete"
                    },
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="get_tap",
            description="Get the full details of a single tap, including its configuration and the generated Python script content.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the tap to retrieve"
                    },
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="get_tap_logs",
            description=(
                "Get the run history for a tap. Returns the last 50 run log entries sorted by most recent first, including status, record count, duration, errors, logs, and `publisherToken` for each run that submitted records to a pipeline. "
                "Works for both manual runs (triggered by `run_tap`) and scheduled runs (triggered by the platform's cron scheduler) — they share the same log. "
                "Use this to verify whether a scheduled run fired, whether any recent run's script succeeded, and to recover the `publisherToken` for any run if you didn't keep the original `run_tap` response in context. "
                "To verify the actual destination ingestion outcome — not just that the script ran — pick the relevant entry and call `get_pipeline_status(publisher_token=entry.publisherToken)`. The tap log only records what the script did; the publisher token is how you trace a run through to whether the data actually landed in the destination."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the tap to get logs for"
                    },
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="get_tap_ledger",
            description="For a document tap: return the ledger of discovered documents (URI, filename, status, hashes, first/last seen timestamps). The ledger is what tells the platform which documents have already been processed so re-runs skip unchanged files. Pass 'clear_uri' to delete one entry (forces that document to be re-processed on the next run) or 'clear_all=true' to wipe the entire ledger (forces a full re-scan).",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the document tap"
                    },
                    "clear_uri": {
                        "type": "string",
                        "description": "Optional. If set, deletes the ledger entry for this URI so the document is re-processed on the next run."
                    },
                    "clear_all": {
                        "type": "boolean",
                        "description": "Optional. If true, deletes the entire ledger for this tap, forcing every document to be re-processed on the next run."
                    }
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="test_tap",
            description="Test-run a tap without pushing data to the pipeline. Executes the tap's script and returns results, record count, and any errors. Use this to validate a script before running it for real.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the tap to test"
                    },
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="update_tap",
            description="Update an existing tap's configuration without regenerating the script. You can change the enabled state, CRON schedule, target pipeline, or description.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the tap to update"
                    },
                    "enabled": {
                        "type": "boolean",
                        "description": "Enable or disable the tap"
                    },
                    "cron_expression": {
                        "type": "string",
                        "description": "New Quartz CRON expression (e.g., '0 0 * * * ?' for hourly)"
                    },
                    "target_pipeline": {
                        "type": "string",
                        "description": "New target pipeline name"
                    },
                    "description": {
                        "type": "string",
                        "description": "New plain-English description"
                    },
                },
                "required": ["name"]
            }
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    started = time.time()
    session_id = _session_id.get() or "stdio"
    api_key = _session_api_key.get()
    status = "ok"
    result_text = ""
    error_msg = ""
    try:
        result_text = _dispatch(name, arguments)
        return [TextContent(type="text", text=result_text)]
    except Exception as e:
        status = "error"
        error_msg = str(e)
        result_text = json.dumps({"error": error_msg})
        return [TextContent(type="text", text=result_text)]
    finally:
        latency_ms = int((time.time() - started) * 1000)
        _activity_record(session_id, name, status, latency_ms, api_key,
                         arguments, result_text, error_msg)


def _dispatch(name: str, args: dict) -> str:
    # --- Pipeline Management ---
    if name == "list_pipelines":
        result = _call("get", "/api/v1/pipelines")
        try:
            pipelines = json.loads(result)
            if not pipelines or (isinstance(pipelines, list) and len(pipelines) == 0):
                return json.dumps({"pipelines": [], "message": "No pipelines exist. You MUST create a pipeline before you can ingest or query data. Call create_pipeline — for structured destinations pass sample data (base64) + filename; for vector destinations (pgvector, qdrant, weaviate, milvus, chroma) pass only pipeline name + destination."})
        except (json.JSONDecodeError, TypeError):
            pass
        return result

    elif name == "get_pipeline":
        return _call("get", "/api/v1/pipeline", params={"pipeline": args["pipeline"]})

    elif name == "create_pipeline":
        pipeline_name = args["pipeline"]
        table_name = args.get("table", pipeline_name)
        db_name = args.get("database", "datris")
        dest_type = args.get("destination", "")
        filename = args.get("filename", "")

        # Auto-detect destination if not specified
        if not dest_type:
            fn_lower = filename.lower()
            if fn_lower.endswith(".json"):
                dest_type = "mongodb"
            elif fn_lower.endswith(".xml"):
                dest_type = "postgres"
            elif fn_lower.endswith(".pdf") or fn_lower.endswith(".docx") or fn_lower.endswith(".txt"):
                dest_type = "pgvector"
            else:
                dest_type = "postgres"

        is_vector = dest_type in ("pgvector", "qdrant", "weaviate", "milvus", "chroma")

        if is_vector:
            # Vector destinations have no schema to detect — synthesize the config
            # directly and skip the /generate round-trip. Saves ~90K tokens of
            # base64'd sample content for typical PDF/DOCX uploads.
            file_ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "txt"
            config = {
                "name": pipeline_name,
                "source": {
                    "fileAttributes": {
                        "unstructuredAttributes": {"fileExtension": file_ext}
                    }
                }
            }
        else:
            # Structured destinations: send sample to /generate for schema detection
            if not args.get("content") or not filename:
                return json.dumps({"error": "content and filename are required for non-vector destinations (used for schema auto-detection)"})
            gen_data = {"pipeline": pipeline_name, "allStrings": "true"}
            if args.get("delimiter"):
                gen_data["delimiter"] = args["delimiter"]
            header = args.get("header", True)
            gen_data["header"] = str(header).lower()
            gen_result = _upload_content("/api/v1/pipeline/generate", args["content"], filename, gen_data)
            try:
                config = json.loads(gen_result)
            except json.JSONDecodeError:
                return json.dumps({"error": "Failed to generate schema: " + gen_result})

        # Build destination
        dest = {}
        if dest_type == "postgres":
            dest["database"] = {"dbName": db_name, "schema": "public", "table": table_name, "usePostgres": True}
        elif dest_type == "mongodb":
            dest["database"] = {"dbName": db_name, "table": table_name, "useMongoDB": True}
        elif dest_type == "qdrant":
            dest["qdrant"] = {"collectionName": table_name, "embeddingSecretName": "oss/embedding", "qdrantSecretName": "oss/qdrant", "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50}}
        elif dest_type == "weaviate":
            dest["weaviate"] = {"className": table_name, "embeddingSecretName": "oss/embedding", "weaviateSecretName": "oss/weaviate", "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50}}
        elif dest_type == "milvus":
            dest["milvus"] = {"collectionName": table_name, "embeddingSecretName": "oss/embedding", "milvusSecretName": "oss/milvus", "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50}}
        elif dest_type == "chroma":
            dest["chroma"] = {"collectionName": table_name, "embeddingSecretName": "oss/embedding", "chromaSecretName": "oss/chroma", "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50}}
        elif dest_type == "pgvector":
            dest["pgvector"] = {"tableName": table_name, "schemaName": "public", "embeddingSecretName": "oss/embedding", "postgresSecretName": "oss/pgvector", "chunking": {"strategy": "recursive", "chunkSize": 500, "chunkOverlap": 50}}
        else:
            dest["database"] = {"dbName": db_name, "schema": "public", "table": table_name, "usePostgres": True}

        config["destination"] = dest

        # Step 2b: Add optional CodeGen data quality rule
        if args.get("codegen_rule"):
            config["dataQuality"] = {"aiRule": {"instruction": args["codegen_rule"], "onFailureIsError": True}}

        # Step 2c: Add optional CodeGen transformation
        if args.get("codegen_transform"):
            config["transformation"] = {"aiTransformation": {"instruction": args["codegen_transform"]}}

        # Step 3: Register the pipeline
        create_result = _call("post", "/api/v1/pipeline", json=config)

        # Check if registration failed
        if create_result and ("Exception" in create_result or "error" in create_result.lower()):
            return json.dumps({"error": "Failed to register pipeline: " + create_result[:500]})

        # Verify the pipeline was actually created by reading it back
        verify = _call("get", "/api/v1/pipeline", params={"pipeline": pipeline_name})
        if verify and "not configured" in verify.lower():
            return json.dumps({"error": "Pipeline registration failed silently. Generated config may be invalid.", "config": str(config)[:500]})

        actual_name = config.get("name", pipeline_name)
        response = {"status": "Pipeline created", "pipeline": actual_name, "destination": dest_type, "table": table_name}
        if dest_type in ("pgvector", "qdrant", "weaviate", "milvus", "chroma"):
            response["nextStep"] = (
                "Vector destination — call upload_data ONCE with the entire document content. "
                "The server chunks it server-side (chunkSize 500, overlap 50) and embeds each chunk."
            )
        return json.dumps(response)

    elif name == "delete_pipeline":
        return _call("delete", "/api/v1/pipeline", params={"pipeline": args["pipeline"]})

    elif name == "upload_data":
        data = {"pipeline": args["pipeline"]}
        result = _upload_content("/api/v1/pipeline/upload", args["content"], args["filename"], data)
        token = result.strip() if result else ""
        if token and not token.startswith("{"):
            return json.dumps({"pipelineToken": token, "message": "Upload successful. Use this pipelineToken with get_job_status to monitor processing."})
        return result

    elif name == "get_job_status":
        params = {}
        if args.get("pipeline_token"):
            params["pipelinetoken"] = args["pipeline_token"]
        if args.get("pipeline_name"):
            params["pipelinename"] = args["pipeline_name"]
        if args.get("page"):
            params["page"] = args["page"]
        result = _call("get", "/api/v1/pipeline/status", params=params)
        try:
            data = json.loads(result)
            # Detect status from either detail (state field) or summary (status field)
            status = None
            if isinstance(data, list) and len(data) > 0:
                last = data[-1] if isinstance(data[-1], dict) else data[0]
                # Detail view uses "state" (begin/processing/end/error)
                # Summary view uses "status" (processing/success/completed/error)
                status = last.get("status") or last.get("state")
            elif isinstance(data, dict):
                status = data.get("status") or data.get("state")

            if status:
                s = status.lower()
                if s in ("processing", "begin"):
                    return "STILL RUNNING — you MUST call get_job_status again in a few seconds. Do NOT proceed to query/search until job is complete.\n\n" + result
                elif s == "error":
                    return "JOB FAILED — read the error details below. Delete the pipeline and recreate if needed.\n\n" + result
        except (json.JSONDecodeError, TypeError, KeyError):
            pass
        return result

    elif name == "kill_job":
        payload = {"pipelineToken": args["pipeline_token"]}
        return _call("post", "/api/v1/job/kill", json=payload)

    elif name == "profile_data":
        data = {}
        if args.get("delimiter"):
            data["delimiter"] = args["delimiter"]
        if args.get("header") is not None:
            data["header"] = str(args["header"]).lower()
        if args.get("sample_size"):
            data["sampleSize"] = str(args["sample_size"])
        return _upload_content("/api/v1/pipeline/profile", args["content"], args["filename"], data)

    elif name == "get_version":
        return _call("get", "/api/v1/version")

    elif name == "check_service_health":
        return _call("get", "/api/v1/health/services")

    # --- Vector Database Search (via REST API) ---
    elif name == "search_qdrant":
        payload = {"query": args["query"]}
        if args.get("collection"):
            payload["collection"] = args["collection"]
        if args.get("top_k"):
            payload["topK"] = args["top_k"]
        return _call("post", "/api/v1/search/qdrant", json=payload)

    elif name == "search_weaviate":
        payload = {"query": args["query"]}
        if args.get("class_name"):
            payload["className"] = args["class_name"]
        if args.get("top_k"):
            payload["topK"] = args["top_k"]
        return _call("post", "/api/v1/search/weaviate", json=payload)

    elif name == "search_milvus":
        payload = {"query": args["query"]}
        if args.get("collection"):
            payload["collection"] = args["collection"]
        if args.get("top_k"):
            payload["topK"] = args["top_k"]
        return _call("post", "/api/v1/search/milvus", json=payload)

    elif name == "search_pgvector":
        payload = {"query": args["query"]}
        if args.get("table"):
            payload["table"] = args["table"]
        if args.get("schema"):
            payload["schema"] = args["schema"]
        if args.get("top_k"):
            payload["topK"] = args["top_k"]
        return _call("post", "/api/v1/search/pgvector", json=payload)

    elif name == "search_chroma":
        payload = {"query": args["query"]}
        if args.get("collection"):
            payload["collection"] = args["collection"]
        if args.get("top_k"):
            payload["topK"] = args["top_k"]
        return _call("post", "/api/v1/search/chroma", json=payload)

    # --- Database Queries (via REST API) ---
    elif name == "query_postgres":
        payload = {"sql": args["sql"]}
        if args.get("limit"):
            payload["limit"] = args["limit"]
        return _call("post", "/api/v1/query/postgres", json=payload)

    elif name == "query_mongodb":
        payload = {"collection": args["collection"]}
        if args.get("filter"):
            payload["filter"] = args["filter"]
        if args.get("projection"):
            payload["projection"] = args["projection"]
        if args.get("limit"):
            payload["limit"] = args["limit"]
        return _call("post", "/api/v1/query/mongodb", json=payload)

    elif name == "query_natural":
        payload = {"question": args["question"], "table": args["table"]}
        if args.get("schema"):
            payload["schema"] = args["schema"]
        if args.get("database"):
            payload["database"] = args["database"]
        if args.get("limit"):
            payload["limit"] = args["limit"]
        return _call("post", "/api/v1/query/natural", json=payload)

    # --- Metadata Discovery (via REST API) ---
    elif name == "list_postgres_databases":
        return _call("get", "/api/v1/metadata/postgres/databases")

    elif name == "list_postgres_schemas":
        params = {}
        if args.get("database"):
            params["database"] = args["database"]
        return _call("get", "/api/v1/metadata/postgres/schemas", params=params)

    elif name == "list_postgres_tables":
        params = {}
        if args.get("database"):
            params["database"] = args["database"]
        if args.get("schema"):
            params["schema"] = args["schema"]
        if args.get("vector_only") is not None:
            params["vectorOnly"] = str(args["vector_only"]).lower()
        return _call("get", "/api/v1/metadata/postgres/tables", params=params)

    elif name == "list_postgres_columns":
        params = {"table": args["table"]}
        if args.get("database"):
            params["database"] = args["database"]
        if args.get("schema"):
            params["schema"] = args["schema"]
        return _call("get", "/api/v1/metadata/postgres/columns", params=params)

    elif name == "list_mongodb_databases":
        return _call("get", "/api/v1/metadata/mongodb/databases")

    elif name == "list_mongodb_collections":
        params = {}
        if args.get("database"):
            params["database"] = args["database"]
        return _call("get", "/api/v1/metadata/mongodb/collections", params=params)

    # --- Vector Store Metadata ---
    elif name == "list_qdrant_collections":
        return _call("get", "/api/v1/metadata/qdrant/collections")

    elif name == "list_weaviate_classes":
        return _call("get", "/api/v1/metadata/weaviate/classes")

    elif name == "list_milvus_collections":
        return _call("get", "/api/v1/metadata/milvus/collections")

    elif name == "list_chroma_collections":
        return _call("get", "/api/v1/metadata/chroma/collections")

    elif name == "list_pgvector_collections":
        return _call("get", "/api/v1/metadata/postgres/tables", params={"vectorOnly": "true"})

    # --- AI ---
    elif name == "ai_answer":
        payload = {"query": args["query"], "context": args["context"]}
        return _call("post", "/api/v1/ai/answer", json=payload)

    # --- Config ---
    elif name == "upload_config":
        data = {"type": args["type"]}
        return _upload_content("/api/v1/config/upload", args["content"], args["filename"], data)

    # --- Secrets ---
    elif name == "update_secret":
        allowed = {"anthropic", "openai", "ollama", "embedding"}
        secret_name = args["name"]
        if secret_name not in allowed:
            return json.dumps({"error": f"Only these secrets can be updated: {', '.join(sorted(allowed))}"})
        return _call("put", f"/api/v1/secrets/{secret_name}", json=args["fields"])

    elif name == "create_tap_secret":
        reserved = {"anthropic", "openai", "ollama", "embedding", "ai-primary", "codegen"}
        secret_name = args["name"]
        if secret_name in reserved:
            return json.dumps({"error": f"'{secret_name}' is a reserved AI-provider slot. Use update_secret for those, or pick a different name for your tap secret."})
        overwrite = args.get("overwrite", False)
        existing_fields = None
        try:
            existing_data = json.loads(_call("get", f"/api/v1/secrets/{secret_name}"))
            if isinstance(existing_data, dict) and "error" not in existing_data:
                existing_fields = existing_data.get("fields") or {}
        except (json.JSONDecodeError, TypeError):
            existing_fields = None
        if existing_fields is not None:
            if not overwrite:
                return json.dumps({"error": f"Secret '{secret_name}' already exists. Pass overwrite=true to replace it (confirm with the user first)."})
            if existing_fields.get("_type") != "tap":
                return json.dumps({"error": f"Secret '{secret_name}' is not a tap secret and was not created by an agent. Agents can only modify tap secrets — have the user update this one in the Secrets tab."})
        fields = dict(args["fields"])
        fields.setdefault("_type", "tap")
        return _call("put", f"/api/v1/secrets/{secret_name}", json=fields)

    elif name == "delete_tap_secret":
        secret_name = args["name"]
        try:
            existing_data = json.loads(_call("get", f"/api/v1/secrets/{secret_name}"))
        except (json.JSONDecodeError, TypeError):
            return json.dumps({"error": f"Could not look up secret '{secret_name}'."})
        if not isinstance(existing_data, dict) or "error" in existing_data:
            return json.dumps({"error": f"Secret '{secret_name}' not found."})
        existing_fields = existing_data.get("fields") or {}
        if existing_fields.get("_type") != "tap":
            return json.dumps({"error": f"Secret '{secret_name}' is not a tap secret. Agents can only delete tap secrets."})
        return _call("delete", f"/api/v1/secrets/{secret_name}")

    # --- Managed Service ---
    elif name == "signup_trial":
        payload = {
            "email": args["email"],
            "password": args["password"],
            "company": args["company"],
            "ai_provider": args.get("ai_provider", "anthropic"),
        }
        try:
            resp = requests.post(f"{WEBSITE_URL}/api/provision/agent-trial", json=payload, timeout=30)
            data = resp.json()
            if resp.status_code == 201:
                return json.dumps({
                    "status": "Trial created",
                    "api_key": data.get("apiKey"),
                    "mcp_url": f"https://mcp.trial.datris.ai/sse",
                    "trial_expires": data.get("trialExpires"),
                    "message": "Reconnect to the MCP endpoint with your API key in the x-api-key header to start using Datris tools."
                })
            return json.dumps({"error": data.get("error", f"Signup failed (HTTP {resp.status_code})")})
        except requests.RequestException as e:
            return json.dumps({"error": f"Failed to reach Datris website: {e}"})

    elif name == "upgrade_to_dedicated":
        api_key = _effective_api_key()
        if not api_key:
            return json.dumps({"error": "API key required. Sign up first using signup_trial."})
        payload = {
            "dropletSize": args.get("droplet_size", "s-2vcpu-8gb"),
            "storageGb": args.get("storage_gb", 25),
            "region": args.get("region", "nyc1"),
        }
        try:
            resp = requests.post(
                f"{WEBSITE_URL}/api/billing/checkout",
                json=payload,
                headers={"x-api-key": api_key},
                timeout=30
            )
            data = resp.json()
            if resp.status_code == 200 and data.get("url"):
                return json.dumps({
                    "status": "Checkout ready",
                    "checkout_url": data["url"],
                    "message": "Open this URL in a browser to complete payment. After payment, provisioning starts automatically. Use check_upgrade_status to monitor progress."
                })
            return json.dumps({"error": data.get("error", f"Checkout failed (HTTP {resp.status_code})")})
        except requests.RequestException as e:
            return json.dumps({"error": f"Failed to reach Datris website: {e}"})

    elif name == "check_upgrade_status":
        api_key = _effective_api_key()
        if not api_key:
            return json.dumps({"error": "API key required. Sign up first using signup_trial."})
        try:
            resp = requests.get(
                f"{WEBSITE_URL}/api/provision/status",
                headers={"x-api-key": api_key},
                timeout=30
            )
            data = resp.json()
            status = data.get("status", "none")
            result = {"status": status}
            if status == "active" and data.get("domain"):
                result["domain"] = data["domain"]
                result["mcp_url"] = f"https://mcp.{data['domain']}/sse"
                result["api_key"] = data.get("apiKey")
                result["message"] = "Your dedicated instance is ready! Reconnect to the new MCP URL with the new API key."
            elif status == "provisioning":
                result["message"] = "Your dedicated instance is being provisioned. Check back in a few minutes."
            elif status == "none":
                result["message"] = "No upgrade in progress. Use upgrade_to_dedicated to start."
            return json.dumps(result)
        except requests.RequestException as e:
            return json.dumps({"error": f"Failed to reach Datris website: {e}"})

    # --- Discovery ---
    elif name == "discover_source":
        messages = args.get("messages")
        if not messages:
            messages = [{"role": "user", "content": args["message"]}]
        return _call("post", "/api/v1/discover", json={"messages": messages})

    # --- Taps ---
    elif name == "create_tap":
        tap_name = args["name"]
        instruction = args.get("instruction")
        script = args.get("script")
        target_pipeline = args.get("target_pipeline")
        cron_expression = args.get("cron_expression")
        secret_name = args.get("secret_name")
        tap_type = args.get("tap_type", "structured")
        caller_packages = args.get("packages")

        script_path = None
        packages = caller_packages

        # Mode 1: User-provided script — store directly
        if script:
            store_result = _call("post", "/api/v1/tap/script", json={"tapName": tap_name, "script": script})
            try:
                store_data = json.loads(store_result)
                if "error" in store_data:
                    return store_result
                script_path = store_data.get("scriptPath")
            except (json.JSONDecodeError, TypeError):
                return json.dumps({"error": f"Script storage failed: {store_result[:200]}"})

        # Mode 2: AI-generated script from instruction
        elif instruction:
            gen_payload = {"description": instruction, "tapName": tap_name, "tapType": tap_type}
            if secret_name:
                gen_payload["secretName"] = secret_name
            gen_result = _call("post", "/api/v1/tap/generate", json=gen_payload)
            try:
                gen_data = json.loads(gen_result)
                if "error" in gen_data:
                    return gen_result
                script_path = gen_data.get("scriptPath")
                if caller_packages is None:
                    packages = gen_data.get("packages")
            except (json.JSONDecodeError, TypeError):
                return json.dumps({"error": f"Script generation failed: {gen_result[:200]}"})

        # Mode 3: No script — config only (script added later)

        # Save the tap config
        tap_config = {
            "name": tap_name,
            "enabled": True,
            "tapType": tap_type,
        }
        if instruction:
            tap_config["description"] = instruction
        if script_path:
            tap_config["scriptPath"] = script_path
        if packages:
            tap_config["packages"] = packages
        if target_pipeline:
            tap_config["targetPipeline"] = target_pipeline
        if cron_expression:
            tap_config["cronExpression"] = cron_expression
        if secret_name:
            tap_config["secretName"] = secret_name

        save_result = _call("post", "/api/v1/tap", json=tap_config)
        try:
            saved = json.loads(save_result)
            if "error" in saved:
                return save_result
            return json.dumps({"message": f"Tap '{tap_name}' created successfully", "tap": saved})
        except (json.JSONDecodeError, TypeError):
            return json.dumps({"message": f"Tap '{tap_name}' created"})

    elif name == "list_taps":
        result = _call("get", "/api/v1/taps")
        try:
            taps = json.loads(result)
            if isinstance(taps, list):
                summary = []
                for t in taps:
                    summary.append({
                        "name": t.get("name"),
                        "description": t.get("description"),
                        "tapType": t.get("tapType") or "structured",
                        "targetPipeline": t.get("targetPipeline"),
                        "cronExpression": t.get("cronExpression"),
                        "enabled": t.get("enabled"),
                        "lastRunStatus": t.get("lastRunStatus"),
                        "lastRunTime": t.get("lastRunTime"),
                        "lastRunRecordCount": t.get("lastRunRecordCount"),
                        "lastTestRunStatus": t.get("lastTestRunStatus"),
                        "lastTestRunTime": t.get("lastTestRunTime"),
                        "lastTestRunRecordCount": t.get("lastTestRunRecordCount"),
                    })
                return json.dumps(summary, indent=2)
        except (json.JSONDecodeError, TypeError):
            pass
        return result

    elif name == "run_tap":
        return _call("post", "/api/v1/tap/run", json={"name": args["name"], "mode": "run"})

    elif name == "get_pipeline_status":
        publisher = args.get("publisher_token")
        pipeline = args.get("pipeline_token")
        if not publisher and not pipeline:
            return json.dumps({"error": "Pass publisher_token (preferred) or pipeline_token."})
        params = {"withrollup": "true"}
        if publisher:
            params["publishertoken"] = publisher
        elif pipeline:
            params["pipelinetoken"] = pipeline
        return _call("get", "/api/v1/pipeline/status", params=params)

    elif name == "delete_tap":
        return _call("delete", f"/api/v1/tap?name={args['name']}")

    elif name == "get_tap":
        return _call("get", f"/api/v1/tap?name={args['name']}")

    elif name == "get_tap_logs":
        return _call("get", f"/api/v1/tap/logs?name={args['name']}")

    elif name == "get_tap_ledger":
        tap_name = args["name"]
        clear_uri = args.get("clear_uri")
        clear_all = args.get("clear_all")
        if clear_uri:
            from urllib.parse import quote
            return _call("delete", f"/api/v1/tap/ledger?name={quote(tap_name)}&uri={quote(clear_uri)}")
        if clear_all:
            return _call("delete", f"/api/v1/tap/ledger?name={tap_name}")
        return _call("get", f"/api/v1/tap/ledger?name={tap_name}")

    elif name == "test_tap":
        return _call("post", "/api/v1/tap/run", json={"name": args["name"], "mode": "test"})

    elif name == "update_tap":
        # Fetch existing config
        tap_result = _call("get", f"/api/v1/tap?name={args['name']}")
        try:
            tap_config = json.loads(tap_result)
            if "error" in tap_config:
                return tap_result
        except (json.JSONDecodeError, TypeError):
            return json.dumps({"error": f"Tap '{args['name']}' not found"})

        # Merge provided fields
        if "enabled" in args:
            tap_config["enabled"] = args["enabled"]
        if "cron_expression" in args:
            tap_config["cronExpression"] = args["cron_expression"]
        if "target_pipeline" in args:
            tap_config["targetPipeline"] = args["target_pipeline"]
        if "description" in args:
            tap_config["description"] = args["description"]

        # Remove the script content field (GET /tap adds it but POST /tap doesn't expect it)
        tap_config.pop("script", None)

        # Save via upsert
        save_result = _call("post", "/api/v1/tap", json=tap_config)
        try:
            saved = json.loads(save_result)
            if "error" in saved:
                return save_result
            return json.dumps({"message": f"Tap '{args['name']}' updated", "tap": saved})
        except (json.JSONDecodeError, TypeError):
            return json.dumps({"message": f"Tap '{args['name']}' updated"})

    else:
        return json.dumps({"error": f"Unknown tool: {name}"})


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def run_stdio():
    from mcp.server.stdio import stdio_server
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def _extract_api_key(scope) -> str:
    """Extract x-api-key from ASGI scope headers or query string."""
    # Check headers first
    for header_name, header_value in scope.get("headers", []):
        if header_name == b"x-api-key":
            return header_value.decode("utf-8")
    # Fall back to query string (?api_key=...)
    qs = scope.get("query_string", b"").decode("utf-8")
    for part in qs.split("&"):
        if part.startswith("api_key="):
            return part[8:]
    return ""


async def _handle_activity(scope, send) -> None:
    qs = scope.get("query_string", b"").decode("utf-8")
    since = 0.0
    for part in qs.split("&"):
        if part.startswith("since="):
            try:
                since = float(part[6:])
            except ValueError:
                since = 0.0
    body = json.dumps(_activity_snapshot(since)).encode("utf-8")
    await send({"type": "http.response.start", "status": 200,
                "headers": [[b"content-type", b"application/json"]]})
    await send({"type": "http.response.body", "body": body})


async def run_sse(port: int):
    from mcp.server.sse import SseServerTransport
    import uvicorn

    sse = SseServerTransport("/messages")

    async def app(scope, receive, send):
        if scope["type"] == "http":
            path = scope.get("path", "")
            if path == "/sse":
                api_key = _extract_api_key(scope)
                if REQUIRE_API_KEY and not api_key:
                    await send({"type": "http.response.start", "status": 401,
                                "headers": [[b"content-type", b"application/json"]]})
                    await send({"type": "http.response.body",
                                "body": b'{"error":"x-api-key header required. Use the signup_trial tool or sign up at datris.ai to get an API key."}'})
                    return
                _session_api_key.set(api_key)
                sess_id = uuid.uuid4().hex
                _session_id.set(sess_id)
                _activity_session_open(sess_id, api_key)
                try:
                    async with sse.connect_sse(scope, receive, send) as streams:
                        await server.run(streams[0], streams[1], server.create_initialization_options())
                finally:
                    _activity_session_close(sess_id)
                return
            elif path == "/messages":
                await sse.handle_post_message(scope, receive, send)
                return
            elif path == "/activity":
                await _handle_activity(scope, send)
                return
        # 404 for anything else
        await send({"type": "http.response.start", "status": 404, "headers": []})
        await send({"type": "http.response.body", "body": b"Not Found"})

    config = uvicorn.Config(app, host="0.0.0.0", port=port)
    srv = uvicorn.Server(config)
    await srv.serve()


async def run_streamable_http(port: int):
    from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
    import contextlib
    import uvicorn

    session_manager = StreamableHTTPSessionManager(app=server, json_response=False, stateless=True)

    @contextlib.asynccontextmanager
    async def lifespan(app):
        async with session_manager.run():
            yield

    async def app(scope, receive, send):
        if scope["type"] == "lifespan":
            from starlette.applications import Starlette
            starlette_app = Starlette(lifespan=lifespan)
            await starlette_app(scope, receive, send)
            return
        if scope["type"] == "http":
            path = scope.get("path", "")
            if path == "/mcp":
                api_key = _extract_api_key(scope)
                if REQUIRE_API_KEY and not api_key:
                    await send({"type": "http.response.start", "status": 401,
                                "headers": [[b"content-type", b"application/json"]]})
                    await send({"type": "http.response.body",
                                "body": b'{"error":"x-api-key header required. Use the signup_trial tool or sign up at datris.ai to get an API key."}'})
                    return
                _session_api_key.set(api_key)
                sess_id = uuid.uuid4().hex
                _session_id.set(sess_id)
                _activity_session_open(sess_id, api_key)
                try:
                    await session_manager.handle_request(scope, receive, send)
                finally:
                    _activity_session_close(sess_id)
                return
            elif path == "/activity":
                await _handle_activity(scope, send)
                return
        await send({"type": "http.response.start", "status": 404, "headers": []})
        await send({"type": "http.response.body", "body": b"Not Found"})

    config = uvicorn.Config(app, host="0.0.0.0", port=port, lifespan="on")
    srv = uvicorn.Server(config)
    await srv.serve()


def main():
    import asyncio

    parser = argparse.ArgumentParser(description="Datris MCP Server")
    parser.add_argument("--sse", action="store_true", help="Run in SSE mode (default: stdio)")
    parser.add_argument("--streamable-http", action="store_true", help="Run in Streamable HTTP mode")
    parser.add_argument("--port", type=int, default=3000, help="Server port (default: 3000)")
    args = parser.parse_args()

    if args.streamable_http:
        asyncio.run(run_streamable_http(args.port))
    elif args.sse:
        asyncio.run(run_sse(args.port))
    else:
        asyncio.run(run_stdio())


if __name__ == "__main__":
    main()
