# Wedata Feature Engineering Library

Wedata 特征工程库，提供特征存储、特征管理等功能。

## 发布到 Test PyPI 完整流程

### 1. 注册 Test PyPI 账号并获取 Token

#### 1.1 注册账号

1. 访问 https://test.pypi.org/account/register/
2. 填写用户名、邮箱、密码完成注册 colinshang Wedata@2022
3. 验证邮箱 colinshang@tencent.com

#### 1.2 创建 API Token

1. 登录后访问 https://test.pypi.org/manage/account/
2. 滚动到 **API tokens** 部分
3. 点击 **Add API token**
4. 填写 Token 名称（如 `colin-api-token`）
5. 选择 Scope（可选择整个账户或特定项目）
6. 点击 **Create token**
7. **立即复制并保存 Token**（只显示一次，格式为 `pypi-AgENdGVzdC5weXBpLm9yZwIkOTNmYmI3OTUtMmQ2YS00YWQxLWExOTQtYjM2N2FlNWM3MmRmAAIqWzMsIjBlZGUyZmY3LWJlMmYtNGRjNy1hOWZlLTQ5OTQ1OTdlZDJmMCJdAAAGIKkxZw9vxjNR5yy9w5ZelgvEP7fhHk_piJHFfjB3rIgc`）

#### 1.3 配置本地凭证

创建或编辑 `~/.pypirc` 文件：

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-xxxxxxxxxxxxxxxx

[testpypi]
username = __token__
password = pypi-AgENdGVzdC5weXBpLm9yZwIkOTNmYmI3OTUtMmQ2YS00YWQxLWExOTQtYjM2N2FlNWM3MmRmAAIqWzMsIjBlZGUyZmY3LWJlMmYtNGRjNy1hOWZlLTQ5OTQ1OTdlZDJmMCJdAAAGIKkxZw9vxjNR5yy9w5ZelgvEP7fhHk_piJHFfjB3rIgc
```

> **注意**: 
> - `username` 固定为 `__token__`，`password` 填写你的 API Token
> - 建议设置文件权限 `chmod 600 ~/.pypirc`

---

### 2. 项目配置

#### 2.1 包名配置

在 `setup.py` 中配置包名：

```python
#name="tencent_wedata_feature_engineering",      # 正式环境包名（已注释）
name="tencent_wedata_feature_engineering_dev",   # 测试环境包名（当前使用）
```

#### 2.2 版本号配置

版本号在 `wedata/__init__.py` 中定义：

```python
__version__ = "0.1.50"
```

---

### 3. 执行发布

#### 3.1 发布到 Test PyPI（测试环境）

```bash
chmod +x build-test.sh
./build-test.sh
```

#### 3.2 发布到 PyPI（正式环境）

```bash
chmod +x build.sh
./build.sh
```

#### 3.3 脚本执行内容

发布脚本会执行以下操作：

1. 清理旧的构建文件 (`dist/`, `build/`, `*.egg-info/`)
2. 读取版本号（从 `wedata/__init__.py`）
3. 安装构建工具 (`twine`, `build`)
4. 打包为 wheel 格式 (`python3 setup.py sdist bdist_wheel`)
5. 上传到 PyPI/Test PyPI

---

### 4. 发布结果

发布成功后会显示：

```
View at:
https://test.pypi.org/project/tencent-wedata-feature-engineering-dev/0.1.50/
```

---

### 5. 安装使用

#### 5.1 从 Test PyPI 安装

```bash
# 仅从 Test PyPI 安装
pip install -i https://test.pypi.org/simple/ tencent-wedata-feature-engineering-dev==0.1.50

# 如果有依赖在正式 PyPI 上，使用混合源安装
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ tencent-wedata-feature-engineering-dev==0.1.50
```

#### 5.2 从正式 PyPI 安装

```bash
pip install tencent-wedata-feature-engineering
```

---

### 6. 相关文件说明

| 文件 | 用途 |
|------|------|
| `~/.pypirc` | PyPI 凭证配置 |
| `setup.py` | 包配置（名称、版本、依赖等） |
| `wedata/__init__.py` | 版本号定义 |
| `build-test.sh` | 发布到 Test PyPI |
| `build.sh` | 发布到正式 PyPI |

---

### 7. 注意事项

- Test PyPI 和正式 PyPI 是**独立的仓库**，需要分别注册账号和创建 Token
- 同一版本号发布后**无法覆盖**，如需修改必须升级版本号
- Test PyPI 仅用于测试，不应用于生产环境
- `~/.pypirc` 文件包含敏感信息，注意保护

---
