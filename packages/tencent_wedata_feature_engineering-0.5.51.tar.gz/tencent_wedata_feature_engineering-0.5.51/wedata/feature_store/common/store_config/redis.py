# -*- coding: utf-8 -*-

__doc__ = """
Feature Redis存储配置
"""

import socket
import logging
from typing import Tuple, Optional

_logger = logging.getLogger(__name__)


class RedisConnectionError(Exception):
    """Redis连接错误"""
    pass


class RedisStoreConfig:
    def __init__(self, host='localhost', port=6379, db=0, password=None, instance_id=None):
        self._host = host
        self._port = port
        self._db = db
        self._password = password
        self._instance_id = instance_id

    @property
    def host(self):
        return self._host

    @property
    def port(self):
        return self._port

    @property
    def db(self):
        return self._db

    @property
    def password(self):
        return self._password

    @property
    def instance_id(self):
        return self._instance_id

    @property
    def connection_string(self):
        if self.password:
            connection_string = f"{self.host}:{self.port},db={self.db},password={self._password}"
        else:
            connection_string = f"{self.host}:{self.port},db={self.db}"
        return connection_string

    def test_network_connectivity(self, timeout: float = 5.0) -> Tuple[bool, str]:
        """
        测试 Redis 服务器的网络连通性（仅测试 TCP 端口是否可达）
        
        Args:
            timeout: 连接超时时间（秒），默认5秒
            
        Returns:
            Tuple[bool, str]: (是否连通, 详细信息)
            
        示例:
            >>> config = RedisStoreConfig(host="43.137.103.43", port=21176)
            >>> success, message = config.test_network_connectivity()
            >>> if not success:
            ...     print(f"网络不通: {message}")
        """
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((self._host, self._port))
            sock.close()
            
            if result == 0:
                return True, f"网络连通: {self._host}:{self._port} 端口可达"
            else:
                error_msg = self._get_socket_error_message(result)
                return False, f"网络不通: {self._host}:{self._port} - {error_msg}"
        except socket.timeout:
            return False, f"连接超时: {self._host}:{self._port} - 请检查网络连通性和防火墙设置"
        except socket.gaierror as e:
            return False, f"DNS解析失败: {self._host} - {str(e)}"
        except Exception as e:
            return False, f"连接异常: {self._host}:{self._port} - {str(e)}"

    def test_redis_connection(self, timeout: float = 5.0) -> Tuple[bool, str]:
        """
        测试 Redis 服务的完整连接（包括认证）
        
        Args:
            timeout: 连接超时时间（秒），默认5秒
            
        Returns:
            Tuple[bool, str]: (是否连接成功, 详细信息)
            
        示例:
            >>> config = RedisStoreConfig(host="43.137.103.43", port=21176, password="xxx")
            >>> success, message = config.test_redis_connection()
            >>> print(message)
        """
        try:
            import redis
        except ImportError:
            return False, "缺少 redis 依赖包，请执行: pip install redis"
        
        # 先测试网络连通性
        network_ok, network_msg = self.test_network_connectivity(timeout)
        if not network_ok:
            return False, network_msg
        
        try:
            client = redis.Redis(
                host=self._host,
                port=self._port,
                db=self._db,
                password=self._password,
                socket_timeout=timeout,
                socket_connect_timeout=timeout,
                decode_responses=True
            )
            # 测试 PING 命令
            response = client.ping()
            if response:
                return True, f"Redis连接成功: {self._host}:{self._port}, db={self._db}"
            else:
                return False, f"Redis PING 返回异常响应"
        except redis.AuthenticationError:
            return False, f"Redis认证失败: 密码错误或未设置密码，请检查 password 参数"
        except redis.ConnectionError as e:
            error_str = str(e)
            if "Connection refused" in error_str:
                return False, f"连接被拒绝: {self._host}:{self._port} - 请检查 Redis 服务是否运行"
            elif "Connection timed out" in error_str or "timed out" in error_str.lower():
                return False, f"连接超时: {self._host}:{self._port} - 可能的原因:\n" \
                              f"  1. VPC网络不通（DLC引擎和Redis不在同一VPC）\n" \
                              f"  2. 安全组未开放 {self._port} 端口\n" \
                              f"  3. 防火墙规则限制"
            else:
                return False, f"Redis连接失败: {error_str}"
        except Exception as e:
            return False, f"Redis连接异常: {str(e)}"
        finally:
            try:
                client.close()
            except:
                pass

    def diagnose(self, timeout: float = 5.0) -> str:
        """
        诊断 Redis 连接问题，返回详细的诊断报告
        
        Args:
            timeout: 超时时间（秒）
            
        Returns:
            str: 诊断报告
            
        示例:
            >>> config = RedisStoreConfig(host="43.137.103.43", port=21176, password="xxx")
            >>> print(config.diagnose())
        """
        report_lines = [
            "=" * 60,
            "Redis 连接诊断报告",
            "=" * 60,
            f"目标地址: {self._host}:{self._port}",
            f"数据库: {self._db}",
            f"密码: {'已设置' if self._password else '未设置'}",
            f"实例ID: {self._instance_id or '未指定'}",
            "-" * 60,
        ]
        
        # 1. DNS 解析检查
        report_lines.append("【步骤1】DNS 解析检查:")
        try:
            ip_addr = socket.gethostbyname(self._host)
            if ip_addr == self._host:
                report_lines.append(f"  ✓ 使用 IP 地址直连: {ip_addr}")
            else:
                report_lines.append(f"  ✓ DNS 解析成功: {self._host} -> {ip_addr}")
        except socket.gaierror as e:
            report_lines.append(f"  ✗ DNS 解析失败: {str(e)}")
            report_lines.append("  建议: 请检查域名是否正确，或直接使用 IP 地址")
            report_lines.append("=" * 60)
            return "\n".join(report_lines)
        
        # 2. 端口连通性检查
        report_lines.append("")
        report_lines.append("【步骤2】网络端口检查:")
        network_ok, network_msg = self.test_network_connectivity(timeout)
        if network_ok:
            report_lines.append(f"  ✓ {network_msg}")
        else:
            report_lines.append(f"  ✗ {network_msg}")
            report_lines.append("")
            report_lines.append("  可能的原因和解决方案:")
            report_lines.append("  1. VPC 网络隔离:")
            report_lines.append("     - 确保 Redis 实例与 DLC/EMR 引擎在同一 VPC")
            report_lines.append("     - 或配置 VPC 对等连接")
            report_lines.append("  2. 安全组未开放端口:")
            report_lines.append(f"     - 在安全组中添加入站规则，开放 TCP 端口 {self._port}")
            report_lines.append("  3. 防火墙限制:")
            report_lines.append("     - 检查云防火墙或主机防火墙规则")
            report_lines.append("=" * 60)
            return "\n".join(report_lines)
        
        # 3. Redis 服务检查
        report_lines.append("")
        report_lines.append("【步骤3】Redis 服务检查:")
        redis_ok, redis_msg = self.test_redis_connection(timeout)
        if redis_ok:
            report_lines.append(f"  ✓ {redis_msg}")
            report_lines.append("")
            report_lines.append("【结论】Redis 连接正常，可以使用在线特征表功能")
        else:
            report_lines.append(f"  ✗ {redis_msg}")
            if "认证失败" in redis_msg:
                report_lines.append("")
                report_lines.append("  解决方案: 请检查密码是否正确")
        
        report_lines.append("=" * 60)
        return "\n".join(report_lines)

    @staticmethod
    def _get_socket_error_message(error_code: int) -> str:
        """根据socket错误码返回友好的错误信息"""
        error_messages = {
            10061: "连接被拒绝 (Connection refused)",
            10060: "连接超时 (Connection timed out)",
            10051: "网络不可达 (Network unreachable)",
            10065: "主机不可达 (Host unreachable)",
            111: "连接被拒绝 (Connection refused)",  # Linux
            110: "连接超时 (Connection timed out)",  # Linux
            113: "没有到主机的路由 (No route to host)",  # Linux
        }
        return error_messages.get(error_code, f"未知错误 (错误码: {error_code})")

    def __repr__(self):
        return f"RedisStoreConfig(host={self.host}, port={self.port}, db={self.db}, instance_id={self.instance_id})"

    def __str__(self):
        return self.__repr__()