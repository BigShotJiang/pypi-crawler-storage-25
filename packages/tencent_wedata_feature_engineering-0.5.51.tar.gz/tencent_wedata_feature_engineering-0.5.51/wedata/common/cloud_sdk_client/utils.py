import os
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.profile.client_profile import ClientProfile


def _is_test_environment():
    """判断是否是测试环境"""
    return os.environ.get("IS_WEDATA_TEST", "").lower() in ["true", "1"]


def _sdk_language() -> str:
    """
    Tencent Cloud API error/detail language.
    Default is en-US (tencentcloud-sdk-python's ClientProfile defaults to zh-CN).
    Set TENCENTCLOUD_SDK_LANGUAGE=zh-CN if you need Chinese API error messages.
    """
    lang = os.environ.get("TENCENTCLOUD_SDK_LANGUAGE", "").strip()
    if lang in ("en-US", "zh-CN"):
        return lang
    return "en-US"


def get_client_profile() -> 'ClientProfile':
    """
    获取网络客户端配置
    """
    if _is_test_environment():
        endpoint = "wedata.test.tencentcloudapi.com"
    else:
        endpoint = os.getenv("TENCENT_CLOUD_SDK_ENDPOINT", "wedata.internal.tencentcloudapi.com")

    http_profile = HttpProfile()
    http_profile.protocol = "https"
    http_profile.endpoint = endpoint

    client_profile = ClientProfile(httpProfile=http_profile, language=_sdk_language())
    return client_profile


def set_request_header(headers):
    """
    获取腾讯云API请求头, 如果是测试环境:
      1. 必须设置环境变量TEST_USER_ID, 否则报错
      2. 添加X-Qcloud-User-Id；否则不添加
    """
    if headers is None:
        headers = {}
    if _is_test_environment():
        test_user_id = os.environ.get("TEST_USER_ID")
        if not test_user_id:
            raise ValueError("TEST_USER_ID environment variable is required in test environment")
        headers["X-Qcloud-User-Id"] = test_user_id
    return headers


def is_mock() -> bool:
    """
    是否为模拟环境
    """
    return os.getenv("IS_MOCK_API") == "true"


def is_warning() -> bool:
    """
    是否展示警告环境
    """
    return os.getenv("IS_CLOUD_API_WARNING") == "true"

