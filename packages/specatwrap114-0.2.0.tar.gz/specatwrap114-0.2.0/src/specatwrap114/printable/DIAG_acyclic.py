import polars as pl

lf: pl.LazyFrame = None
lf_allowed: pl.LazyFrame = None
lf_strict: pl.LazyFrame = None
# {{paste:begin}}

# {{paste:DIAG_initial_sorting_all}}

# {{paste:DIAG_stats}}

lf = lf.filter((pl.col("TDiag") == "Death").last().over("case:PNR"))

lf = lf.with_columns(
    TDiag=pl.concat_str(
        [
            pl.lit("_"),
            pl.int_range(1, pl.len() + 1).over("case:PNR"),
            pl.lit("_"),
            pl.col("TDiag")
        ]
    )
)

# {{paste:DIAG_filter}}
df, df_allowed, df_strict = pl.collect_all([lf, lf_allowed, lf_strict])
# {{paste:DIAG_df_stats}}
