
# 🧠 AI Services Modules

This repository provides a unified interface to interact with multiple Large Language Model (LLM) providers for tasks like:

- 💬 Text Generation & Chat Completion  
- 🗣️ Text-to-Speech (TTS)  
- 🎧 Speech-to-Text (STT)  
- 📊 Evaluation via prompt templates  

---

## 📌 Features

- 🔄 Unified API across major providers:
  - **LLM**: OpenAI, Gemini, Groq, Anthropic
  - **TTS**: OpenAI, GTTS, Gemini
  - **STT**: OpenAI
- ✅ Easy integration of multiple providers
- 🎯 Evaluation prompt templates

---

---

## 🔧 Quick Start via GitHub (No Need to Clone)

You can install the package directly from GitHub using pip:

```bash
pip install git+https://github.com/guvi-research/guvi-ai-service.git
```

### ✅ Steps to Use

1. **Create a new project folder** and inside it, add a `.env` file with your API keys:

```ini
OPENAI_API_KEY=your_openai_key_here
GEMINI_API_KEY=your_gemini_key_here
GROQ_API_KEY=your_groq_key_here
ANTHROPIC_API_KEY=your_anthropic_key_here
MONGODB_URI=your_mongo_uri_here
```

2. **Create a `test.py` file** like this:

```python
from dotenv import load_dotenv
from ai_services.utils.mongo_logger import MongoEventLogger
from ai_services.client import LLMClient
from ai_services.provider_factory import get_provider
import os

load_dotenv()

# Setup logger
mongo_logger = MongoEventLogger(
    db_uri=os.getenv("MONGODB_URI"),
    db_name="AI_logs",
    collection_name="chat_completion_logs"
)

# Messages for the model
messages = [
    {"role": "system", "content": "You are a interview assistant."},
    {"role": "user", "content": "give me a single tip for peace"}
]

# Get provider
provider = get_provider(
    name="openai",
    model="gpt-4.1-nano",
    event_logger=mongo_logger
)

# Initialize client
client = LLMClient(provider)
response = client.chat(messages)
print("Response:", response)
```

3. **Run the file:**
```bash
python test.py
```

---

## 🔌 Supported Providers

| Task                | Providers                             |
|---------------------|----------------------------------------|
| Text Generation     | OpenAI, Groq, Gemini, Anthropic        |
| Text-to-Speech (TTS)| OpenAI, GTTS, Gemini                   |
| Speech-to-Text (STT)| OpenAI                                 |

Use `provider_type` as:
- `llm` → for text generation
- `tts` → for text-to-speech
- `stt` → for speech-to-text

---

## 🧾 MongoDB Event Logging (Optional)

This project supports logging API events (LLM, TTS, STT) into MongoDB for analytics, debugging, or auditing.

### Mongo Log Structure:

Each interaction stores:
```json
{
  "timestamp": "2025-06-19T10:45:12Z",
  "service_type": "TTS",
  "module": "openai_provider",
  "function": "generate_speech",
  "request_data": { "text": "Hello world" },
  "response_data": { "status": "audio_generated" },
  "status": "success",
  "error": null
}
```

### .env Setup:
```env
MONGODB_URI=mongodb+srv://<user>:<pass>@cluster.mongodb.net/
```

### MongoDB Integration:
```python
from utils.mongo_logger import MongoEventLogger

mongo_logger = MongoEventLogger(
    db_uri=os.getenv("MONGODB_URI"),
    db_name="AI_Interview",
    collection_name="tts_logs"
)

tts_provider = get_provider(
    name="openai",
    provider_type="tts",
    model="gpt-4o-mini-tts",
    voice="alloy",
    event_logger=mongo_logger
)
```

---

## 🚀 How to Run by cloning the repo

HOW TO CLONE AI SERVICE REPO:

git clone "https://github.com/guvi-research/guvi-ai-service.git"

## 🛠 Prerequisites

- **Python 3.8+**
- API Keys (store in `.env` file):
  ```env
  OPENAI_API_KEY=your_openai_key_here
  GEMINI_API_KEY=your_gemini_key_here
  GROQ_API_KEY=your_groq_key_here
  ANTHROPIC_API_KEY=your_anthropic_key_here
  MONGODB_URI=your_uri_link_here
  ```

- Install requirements:
  ```bash
  pip install -r requirements.txt
  ```


### 1️⃣ Text Generation (LLM)

**File:** `examples/llm_usage.py`

```python
from llm_module.client import LLMClient
from llm_module.provider_factory import get_provider

uri = os.getenv("MONGODB_URI")
mongo_logger = MongoEventLogger(
    db_uri=uri,
    db_name = "AI_Services",
    collection_name = "chat_completion_logs"
)

messages = [
  {"role": "system", "content": "You are a helpful assistant."},
  {"role": "user", "content": "What is your role?"}
]

provider = get_provider(
    name="gemini",  
    model="gemini-2.0-flash",
    event_logger=mongo_logger
)
client = LLMClient(provider)

response = client.chat(messages)
print("Response:", response)
```

Run:
```bash
python examples/llm_usage.py
```

---

### 2️⃣ Text-to-Speech (TTS)

**File:** `examples/tts_usage.py`

```python
from tts_module.client import TTSClient
from tts_module.provider_factory import get_provider

uri = os.getenv("MONGODB_URI")
mongo_logger = MongoEventLogger(
    db_uri=uri,
    db_name = "AI_Services",
    collection_name = "tts_logs"
)

tts_provider = get_provider("openai", provider_type="tts",  model="gpt-4o-mini-tts", voice="alloy", event_logger=mongo_logger)

client = TTSClient(tts_provider)
client.speak("Hello, this is a text-to-speech test.")
```

Run:
```bash
python examples/tts_usage.py
```

---

### 3️⃣ Speech-to-Text (STT)

**File:** `examples/stt_usage.py`

```python
from stt_module.client import STTClient
from stt_module.provider_factory import get_provider

uri = os.getenv("MONGODB_URI")
mongo_logger = MongoEventLogger(
    db_uri=uri,
    db_name = "AI_Services",
    collection_name = "stt_logs"
)

audio_path = "path/to/audio.mp3"

stt_provider = get_provider("openai", provider_type="stt", model="gpt-4o-mini-transcribe",event_logger=mongo_logger)
client = STTClient(stt_provider)

result = client.transcribe(audio_path)
print("Transcription:", result)
```

Run:
```bash
python examples/stt_usage.py
```

---

## ✅ Notes

- Ensure `.env` is set before running any script.
- Choose the correct provider and model as required.
- All logs are automatically stored in MongoDB (if `event_logger` is passed).

```
guvi-ai-service-main
├─ ai_services
│  ├─ base.py
│  ├─ client.py
│  ├─ config.py
│  ├─ dependencies
│  │  ├─ stt_common_functions.py
│  │  ├─ tts_common_functions.py
│  │  └─ __init__.py
│  ├─ logger.py
│  ├─ prompts
│  │  ├─ evaluation_prompt_generator.py
│  │  └─ __init__.py
│  ├─ providers
│  │  ├─ anthropic_provider.py
│  │  ├─ gemini_provider.py
│  │  ├─ groq_provider.py
│  │  ├─ gtts_provider.py
│  │  ├─ openai_provider.py
│  │  └─ __init__.py
│  ├─ provider_factory.py
│  ├─ utils
│  │  ├─ error_handler.py
│  │  ├─ input_validator.py
│  │  ├─ mongo_logger.py
│  │  └─ __init__.py
│  └─ __init__.py
├─ examples
│  ├─ llm_usage.py
│  ├─ s3versioncontrollesson7.mp3
│  ├─ stt_usage.py
│  └─ tts_usage.py
├─ pyproject.toml
└─ README.md

```