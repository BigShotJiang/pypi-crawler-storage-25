from typing import List, Dict, Optional
from pydantic import BaseModel, ValidationError


# -----------------------------
# 🔹 Pydantic Models
# -----------------------------

class ChatMessage(BaseModel):
    role: str
    content: str


class LLMRequest(BaseModel):
    messages: List[ChatMessage]


class TTSRequest(BaseModel):
    text: str


class STTRequest(BaseModel):
    audio_input: str  # file path or url (you can extend later)


# -----------------------------
# 🔹 LLM CLIENT
# -----------------------------

class LLMClient:
    def __init__(self, provider):
        if not hasattr(provider, "generate"):
            raise ValueError("Provider does not support LLM capability")
        self.provider = provider

    def chat(self, messages: List[Dict], **kwargs) -> str:
        try:
            validated = LLMRequest(
                messages=[ChatMessage(**m) for m in messages]
            )
        except ValidationError as e:
            raise ValueError(f"Invalid messages format: {e}")

        return self.provider.generate(validated.messages, **kwargs)


# -----------------------------
# 🔹 TTS CLIENT
# -----------------------------

class TTSClient:
    def __init__(self, provider):
        if not hasattr(provider, "generate_speech"):
            raise ValueError("Provider does not support TTS capability")
        self.provider = provider

    def speak(self, text: str, **kwargs) -> str:
        try:
            validated = TTSRequest(text=text)
        except ValidationError as e:
            raise ValueError(f"Invalid TTS input: {e}")

        return self.provider.generate_speech(validated.text, **kwargs)


# -----------------------------
# 🔹 STT CLIENT
# -----------------------------

class STTClient:
    def __init__(self, provider):
        if not hasattr(provider, "generate_text"):
            raise ValueError("Provider does not support STT capability")
        self.provider = provider

    def transcribe(self, audio_input: str, **kwargs) -> str:
        try:
            validated = STTRequest(audio_input=audio_input)
        except ValidationError as e:
            raise ValueError(f"Invalid STT input: {e}")

        return self.provider.generate_text(validated.audio_input, **kwargs)