# utils/mongo_event_logger.py
from pymongo import MongoClient
import certifi
import datetime

class MongoEventLogger:
    def __init__(self, db_uri, db_name, collection_name):
        self.client = MongoClient(db_uri, tls=True, tlsCAFile=certifi.where())
        self.collection = self.client[db_name][collection_name]

    def log_event(self, service_type, module, function, request_data, response_data=None, status="success", error=None):
        log_entry = {
            "timestamp": datetime.datetime.utcnow(),
            "service_type": service_type,  # "LLM", "TTS", "STT"
            "module": module,
            "function": function,
            "request": request_data,
            "response": response_data,
            "status": status,
            "error": str(error) if error else None,
        }

        try:
            self.collection.insert_one(log_entry)
        except Exception as e:
            print(f"MongoDB logging failed: {e}")
