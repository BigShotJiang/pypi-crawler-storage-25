

import logging


logger = logging.getLogger(__name__)


def validate_llm_messages(messages):    
    try:
        if not messages or not isinstance(messages, list):
            logger.warning("Invalid messages input; expected a non-empty list of message dicts.")
            return False

        for i, msg in enumerate(messages):
            if not isinstance(msg, dict):
                logger.warning(f"Invalid message type at index {i}: Expected dict but got {type(msg).__name__}. Content: {msg}")
                return False

            role = msg.get("role", "<missing>")
            content = msg.get("content", "<missing>")

            if "role" not in msg:
                logger.warning(f"Message missing 'role' field: {msg}")
                return False

            if "content" not in msg:
                logger.warning(f"Message with role '{role}' is missing 'content' field.")
                return False

            if not isinstance(content, str) or not content.strip():
                preview = content[:30] + "..." if isinstance(content, str) and len(content) > 30 else content
                logger.warning(f"Message with role '{role}' has empty or invalid content: '{preview}'")
                return False

        return True
    except Exception as e:
        logger.exception(f"Exception while validating messages: {e}")
        return False

        
def validate_tts_input(text):   
    if not text or not text.strip():       
        logger.warning("Text input is empty or whitespace.")
        return False 
    return True  
        