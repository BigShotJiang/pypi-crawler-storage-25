# utils/error_handler.py

import logging
import socket
import requests

logger = logging.getLogger(__name__)

def handle_api_errors(provider_name: str, error: Exception, context: str = ""):
    context_msg = f" | Context: {context}" if context else ""

    # Network-related issues
    if isinstance(error, (ConnectionError, socket.gaierror, requests.exceptions.ConnectionError)):
        logger.error(f"[{provider_name}] Network connection error or no internet{context_msg}")

    # Timeout
    elif isinstance(error, (TimeoutError, requests.exceptions.Timeout)):
        logger.error(f"[{provider_name}] Request timed out{context_msg}")

    # Rate limits (generic)
    elif 'rate limit' in str(error).lower():
        logger.error(f"[{provider_name}] Rate limit exceeded{context_msg}")

    # General API error pattern
    elif 'api error' in str(error).lower() or 'invalid request' in str(error).lower():
        logger.error(f"[{provider_name}] API error: {error}{context_msg}")
        
    elif "api key" in str(error).lower() or "unauthorized" in str(error).lower() or "authentication" in str(error).lower():
        logger.error(f"[{provider_name}] Invalid or missing API key | Context: {context}")
    
    # All other unhandled errors
    else:
        logger.exception(f"[{provider_name}] Unhandled exception: {error}{context_msg}")
