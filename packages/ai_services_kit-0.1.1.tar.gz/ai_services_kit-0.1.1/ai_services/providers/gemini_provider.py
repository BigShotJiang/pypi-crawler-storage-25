import io
import base64
import wave
import requests
import pygame
from google import genai
from google.genai import types
from ai_services.dependencies.tts_common_functions import _play_audio
from ai_services.base import LLMProviderBase , TTSProviderBase
from ai_services.utils.error_handler import handle_api_errors
from ai_services.config import GEMINI_API_KEY
import logging

logger = logging.getLogger(__name__)

class GeminiClientProvider(LLMProviderBase):
    def __init__(
        self,
        api_key: str = GEMINI_API_KEY,
        model: str = "gemini-2.0-flash",
        temperature: float = 0.7,
        max_tokens: int = 1024,
        event_logger=None
    ):
        self.client = genai.Client(api_key=api_key)
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.event_logger = event_logger  # ✅ Add this
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"GeminiProvider initialized with model: {self.model}")

    def generate(self, messages, **kwargs):
        temperature = kwargs.get("temperature", self.temperature)
        max_tokens = kwargs.get("max_tokens", self.max_tokens)

        try:
            if not self.validate_messages(messages):
                self.logger.warning("Message validation failed. Aborting generation.")
                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="LLM",
                        module=__name__,
                        function="generate",
                        request_data={"messages": messages},
                        status="validation_failed",
                        error="Invalid message format"
                    )
                return None

            prompt = ""
            if isinstance(messages, list):
                user_messages = [msg.get("content", "") for msg in messages if msg.get("role") == "user" and msg.get("content")]
                prompt = "\n".join(user_messages).strip()
            elif isinstance(messages, str):
                prompt = messages.strip()

            if not prompt:
                self.logger.warning("Prompt is empty after parsing messages. Aborting generation.")
                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="LLM",
                        module=__name__,
                        function="generate",
                        request_data={"messages": messages},
                        status="validation_failed",
                        error="Empty prompt"
                    )
                return None

            self.logger.info(f"Sending prompt to Gemini model: {prompt[:100]}...")
            self.logger.debug(f"Temperature: {temperature}, Max tokens: {max_tokens}")

            response = self.client.models.generate_content(
                model=self.model,
                config=types.GenerateContentConfig(
                    temperature=temperature,
                    max_output_tokens=max_tokens,
                ),
                contents=[prompt]
            )

            if hasattr(response, "text") and response.text.strip():
                result = response.text.strip()
                self.logger.info(f"Received response from Gemini model: {result[:75]}...")
                if self.event_logger:
                    self.event_logger.log_event(
                        service_type="LLM",
                        module=__name__,
                        function="generate",
                        request_data={"messages": messages},
                        response_data={"result": result}
                    )
                return result
            else:
                self.logger.warning("Gemini returned no text content.")
                return "No valid response returned from Gemini."

        except Exception as e:
            self.logger.exception("Exception during Gemini response generation.")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="LLM",
                    module=__name__,
                    function="generate",
                    request_data={"messages": messages},
                    status="error",
                    error=str(e)
                )
            return "Error in generating response from Gemini."

    

class GeminiTTSProvider(TTSProviderBase):
    CHANNELS = 1
    SAMPLE_WIDTH = 2
    FRAME_RATE = 24000

    def __init__(self, api_key: str = GEMINI_API_KEY, model: str = "gemini-2.5-flash-preview-tts", voice: str = "Kore", event_logger=None):
        self.api_key = api_key
        self.model = model
        self.voice = voice
        self.event_logger = event_logger  # ✅ Add this
        pygame.mixer.init()
        self.logger = logging.getLogger(__name__)

    def generate_speech(self, text: str) -> io.BytesIO | None:
        if not self.validate_text(text):
            self.logger.warning("Text input is empty or invalid.")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    status="validation_failed",
                    error="Empty or invalid text input"
                )
            return None

        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"

        headers = {
            "Content-Type": "application/json"
        }

        payload = {
            "contents": [{"role": "user", "parts": [{"text": text}]}],
            "generationConfig": {
                "responseModalities": ["AUDIO"],
                "speechConfig": {
                    "voiceConfig": {
                        "prebuiltVoiceConfig": {
                            "voiceName": self.voice
                        }
                    }
                }
            }
        }

        try:
            self.logger.info(f"Generating speech with model: {self.model}")
            res = requests.post(url, headers=headers, json=payload)
            res_json = res.json()

            audio_base64 = res_json["candidates"][0]["content"]["parts"][0]["inlineData"]["data"]
            if not audio_base64:
                self.logger.warning("No audio data received from TTS.")
                return None

            audio_bytes = base64.b64decode(audio_base64)

            wav_buffer = io.BytesIO()
            with wave.open(wav_buffer, 'wb') as wf:
                wf.setnchannels(self.CHANNELS)
                wf.setsampwidth(self.SAMPLE_WIDTH)
                wf.setframerate(self.FRAME_RATE)
                wf.writeframes(audio_bytes)

            wav_buffer.seek(0)
            try:
                _play_audio(wav_buffer)
            except Exception as e:
                self.logger.error(f"Error during audio playback: {e}")

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text, "model": self.model, "voice": self.voice},
                    response_data={"status": "audio_generated"}
                )

            return io.BytesIO(audio_bytes)

        except Exception as e:
            self.logger.exception("Exception during Gemini TTS generation.")
            handle_api_errors(self.__class__.__name__, e, context="generating TTS response")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    status="error",
                    error=str(e)
                )
            return None

       
    
