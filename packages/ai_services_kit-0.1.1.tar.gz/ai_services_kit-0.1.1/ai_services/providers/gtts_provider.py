import io
import time
import pygame
from gtts import gTTS
from ai_services.base import TTSProviderBase
from ai_services.dependencies.tts_common_functions import _play_audio
from ai_services.utils.error_handler import handle_api_errors
import logging

logger = logging.getLogger(__name__)

class GTTSProvider(TTSProviderBase):
    def __init__(self, lang: str = "en", model: str = "", voice: str = "", event_logger=None):
        self.lang = lang
        self.model = model
        self.voice = voice
        self.event_logger = event_logger  # ✅ Add this
        pygame.mixer.init()
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"gTTSProvider initialized")

    def generate_speech(self, text: str) -> io.BytesIO | None:
        if not self.validate_text(text):
            self.logger.warning("Text input is empty or invalid.")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    status="validation_failed",
                    error="Empty or invalid text input"
                )
            return None

        try:
            tts = gTTS(text=text.strip(), lang=self.lang)
            audio_io = io.BytesIO()
            tts.write_to_fp(audio_io)
            audio_io.seek(0)

            _play_audio(audio_io)

            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text, "lang": self.lang},
                    response_data={"status": "audio_generated"}
                )

            return audio_io

        except Exception as e:
            self.logger.error(f"gTTS Error: {e}")
            if self.event_logger:
                self.event_logger.log_event(
                    service_type="TTS",
                    module=__name__,
                    function="generate_speech",
                    request_data={"text": text},
                    status="error",
                    error=str(e)
                )
            return None
