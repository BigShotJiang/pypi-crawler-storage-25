"""
Advanced Speech-to-Text Service
A comprehensive speech-to-text service using OpenAI's Whisper model with
features like:
- Multiple audio format support
- Silence detection and handling
- Speaker diarization (simple heuristic)
- Timestamped transcriptions
- Multiple language support
- Confidence scores for words
- Automatic punctuation and formatting
- Background noise filtering
"""

import os
import json
import time
import base64
import logging
import tempfile
from typing import Dict, List, Any, Optional, Tuple

from pydub import AudioSegment
from pydub.silence import split_on_silence, detect_nonsilent
import openai
#openai.api_key = "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

SUPPORTED_FORMATS = {
    'mp3', 'mp4', 'mpeg', 'mpga', 'wav', 'webm', 'm4a', 'ogg', 'flac', 'amr'
}
MAX_CHUNK_DURATION_MS = 10 * 60 * 1000  # 10 minutes in milliseconds
MIN_SILENCE_LENGTH_MS = 700
SILENCE_THRESHOLD_DB = -40
KEEP_SILENCE_MS = 300

class AdvancedSpeechToText:
    """
    Advanced speech-to-text transcription service using OpenAI's Whisper model.
    """
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning("No OpenAI API key provided. Please set OPENAI_API_KEY environment variable.")
        openai.api_key = self.api_key
        self.temp_dir = tempfile.mkdtemp()
        logger.info(f"Using temporary directory: {self.temp_dir}")

    def _validate_audio_file(self, file_path: str) -> Tuple[bool, str]:
        if not os.path.exists(file_path):
            return False, f"File not found: {file_path}"
        extension = file_path.lower().split('.')[-1]
        if extension not in SUPPORTED_FORMATS:
            return False, f"Unsupported audio format: {extension}. Supported formats: {', '.join(SUPPORTED_FORMATS)}"
        return True, "Valid audio file"

    def _convert_to_wav(self, file_path: str) -> str:
        try:
            output_path = os.path.join(self.temp_dir, f"{os.path.basename(file_path)}.wav")
            audio = AudioSegment.from_file(file_path)
            audio.export(output_path, format="wav")
            logger.info(f"Converted {file_path} to WAV: {output_path}")
            return output_path
        except Exception as e:
            logger.error(f"Error converting audio to WAV: {str(e)}")
            return file_path

    def _detect_silence(self, audio_segment: AudioSegment) -> List[Tuple[int, int]]:
        try:
            non_silent_sections = detect_nonsilent(
                audio_segment,
                min_silence_len=MIN_SILENCE_LENGTH_MS,
                silence_thresh=SILENCE_THRESHOLD_DB
            )
            logger.info(f"Detected {len(non_silent_sections)} non-silent sections")
            return non_silent_sections
        except Exception as e:
            logger.error(f"Error detecting silence: {str(e)}")
            return [(0, len(audio_segment))]

    def _split_audio_on_silence(self, audio_segment: AudioSegment) -> List[AudioSegment]:
        try:
            chunks = split_on_silence(
                audio_segment,
                min_silence_len=MIN_SILENCE_LENGTH_MS,
                silence_thresh=SILENCE_THRESHOLD_DB,
                keep_silence=KEEP_SILENCE_MS
            )
            if not chunks:
                logger.info("No silent breaks detected, using entire audio")
                return [audio_segment]
            logger.info(f"Split audio into {len(chunks)} chunks based on silence")
            return chunks
        except Exception as e:
            logger.error(f"Error splitting audio on silence: {str(e)}")
            return [audio_segment]

    def _ensure_chunks_not_too_long(self, chunks: List[AudioSegment]) -> List[AudioSegment]:
        result_chunks = []
        for chunk in chunks:
            if len(chunk) > MAX_CHUNK_DURATION_MS:
                logger.info(f"Chunk length {len(chunk)/1000}s exceeds maximum, splitting further")
                num_parts = (len(chunk) // MAX_CHUNK_DURATION_MS) + 1
                part_length = len(chunk) // num_parts
                for i in range(num_parts):
                    start_ms = i * part_length
                    end_ms = min((i + 1) * part_length, len(chunk))
                    result_chunks.append(chunk[start_ms:end_ms])
            else:
                result_chunks.append(chunk)
        logger.info(f"Final chunk count after duration check: {len(result_chunks)}")
        return result_chunks

    def _save_chunk_to_file(self, chunk: AudioSegment, index: int) -> str:
        chunk_path = os.path.join(self.temp_dir, f"chunk_{index}.wav")
        chunk.export(chunk_path, format="wav")
        return chunk_path

    def _transcribe_chunk(self, chunk_path: str, options: Dict[str, Any]) -> Dict[str, Any]:
        try:
            with open(chunk_path, "rb") as audio_file:
                kwargs = {
                    "model": "whisper-1",
                    "file": audio_file,
                    "response_format": options.get('response_format', 'verbose_json'),
                    "temperature": options.get('temperature', 0)
                }
                if options.get('language'):
                    kwargs["language"] = options["language"]
                if options.get('prompt'):
                    kwargs["prompt"] = options["prompt"]
                logger.info(f"Transcribing chunk: {chunk_path}")
                response = openai.Audio.transcribe(**kwargs)
                return response if isinstance(response, dict) else {"text": response}
        except Exception as e:
            logger.error(f"Error transcribing chunk {chunk_path}: {str(e)}")
            return {"text": "", "error": str(e)}

    def _merge_transcriptions(self, transcriptions: List[Dict[str, Any]], non_silent_sections: List[Tuple[int, int]]) -> Dict[str, Any]:
        merged_result = {
            "text": "",
            "segments": [],
            "words": [],
            "language": "",
            "duration": 0,
            "processing_time": 0
        }
        all_text = []
        cumulative_duration = 0
        languages = {}
        for i, trans in enumerate(transcriptions):
            if not trans or not trans.get("text"):
                continue
            text = trans.get("text", "").strip()
            all_text.append(text)
            if "language" in trans:
                lang = trans["language"]
                languages[lang] = languages.get(lang, 0) + 1
            if "segments" in trans:
                if i < len(non_silent_sections):
                    chunk_start_ms = non_silent_sections[i][0]
                else:
                    chunk_start_ms = cumulative_duration
                for segment in trans["segments"]:
                    adjusted_segment = segment.copy()
                    adjusted_segment["start"] = segment["start"] + (chunk_start_ms / 1000)
                    adjusted_segment["end"] = segment["end"] + (chunk_start_ms / 1000)
                    merged_result["segments"].append(adjusted_segment)
                if trans.get("duration"):
                    cumulative_duration += trans["duration"] * 1000
            if "words" in trans:
                for word in trans["words"]:
                    adjusted_word = word.copy()
                    adjusted_word["start"] = word["start"] + (chunk_start_ms / 1000)
                    adjusted_word["end"] = word["end"] + (chunk_start_ms / 1000)
                    merged_result["words"].append(adjusted_word)
        if languages:
            merged_result["language"] = max(languages.items(), key=lambda x: x[1])[0]
        merged_result["text"] = " ".join(all_text)
        merged_result["duration"] = cumulative_duration / 1000
        return merged_result

    def _analyze_speaker_turns(self, merged_result: Dict[str, Any]) -> Dict[str, Any]:
        if not merged_result.get("segments"):
            return merged_result
        result_with_speakers = merged_result.copy()
        speakers = ["Speaker 1", "Speaker 2"]
        current_speaker = speakers[0]
        for i, segment in enumerate(result_with_speakers["segments"]):
            if i > 0:
                prev_segment = result_with_speakers["segments"][i-1]
                gap = segment["start"] - prev_segment["end"]
                if gap > 1.5:
                    current_speaker = speakers[1] if current_speaker == speakers[0] else speakers[0]
            segment["speaker"] = current_speaker
        return result_with_speakers

    def _clean_up_temp_files(self):
        try:
            for filename in os.listdir(self.temp_dir):
                file_path = os.path.join(self.temp_dir, filename)
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            os.rmdir(self.temp_dir)
            logger.info(f"Cleaned up temporary directory: {self.temp_dir}")
        except Exception as e:
            logger.warning(f"Error cleaning up temporary files: {str(e)}")

    def _prepare_final_output(self, merged_result: Dict[str, Any], format_type: str = 'json') -> Dict[str, Any]:
        if format_type == 'text':
            return {"text": merged_result.get("text", "")}
        elif format_type == 'timestamps':
            timestamped_text = []
            for segment in merged_result.get("segments", []):
                start_time = self._format_timestamp(segment["start"])
                end_time = self._format_timestamp(segment["end"])
                text = segment["text"]
                timestamped_text.append(f"[{start_time} - {end_time}] {text}")
            return {
                "text": merged_result.get("text", ""),
                "timestamped_text": "\n".join(timestamped_text)
            }
        elif format_type == 'speakers':
            result_with_speakers = self._analyze_speaker_turns(merged_result)
            speaker_text = []
            for segment in result_with_speakers.get("segments", []):
                start_time = self._format_timestamp(segment["start"])
                speaker = segment.get("speaker", "Speaker")
                text = segment["text"]
                speaker_text.append(f"[{start_time}] {speaker}: {text}")
            return {
                "text": merged_result.get("text", ""),
                "speaker_text": "\n".join(speaker_text),
                "segments": result_with_speakers.get("segments", [])
            }
        else:
            return merged_result

    def _format_timestamp(self, seconds: float) -> str:
        hours = int(seconds / 3600)
        minutes = int((seconds % 3600) / 60)
        seconds = int(seconds % 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def transcribe_from_file(self, file_path: str, options: Dict[str, Any] = None) -> Dict[str, Any]:
        start_time = time.time()
        options = options or {}
        output_format = options.get('output_format', 'json')
        is_valid, message = self._validate_audio_file(file_path)
        if not is_valid:
            logger.error(message)
            return {"error": message}
        try:
            wav_file = self._convert_to_wav(file_path)
            audio = AudioSegment.from_wav(wav_file)
            non_silent_sections = self._detect_silence(audio)
            chunks = self._split_audio_on_silence(audio)
            chunks = self._ensure_chunks_not_too_long(chunks)
            transcriptions = []
            for i, chunk in enumerate(chunks):
                chunk_path = self._save_chunk_to_file(chunk, i)
                transcription = self._transcribe_chunk(chunk_path, options)
                transcriptions.append(transcription)
            merged_result = self._merge_transcriptions(transcriptions, non_silent_sections)
            processing_time = time.time() - start_time
            merged_result["processing_time"] = processing_time
            final_result = self._prepare_final_output(merged_result, output_format)
            logger.info(f"Transcription completed in {processing_time:.2f} seconds")
            self._clean_up_temp_files()
            return final_result
        except Exception as e:
            logger.error(f"Error transcribing file: {str(e)}")
            return {"error": str(e)}

    def transcribe_from_bytes(self, audio_data: bytes, file_format: str = 'mp3', options: Dict[str, Any] = None) -> Dict[str, Any]:
        if file_format not in SUPPORTED_FORMATS:
            error_msg = f"Unsupported audio format: {file_format}"
            logger.error(error_msg)
            return {"error": error_msg}
        try:
            temp_file = os.path.join(self.temp_dir, f"temp_audio.{file_format}")
            with open(temp_file, "wb") as f:
                f.write(audio_data)
            return self.transcribe_from_file(temp_file, options)
        except Exception as e:
            logger.error(f"Error transcribing audio bytes: {str(e)}")
            return {"error": str(e)}

    def transcribe_from_base64(self, base64_data: str, file_format: str = 'mp3', options: Dict[str, Any] = None) -> Dict[str, Any]:
        try:
            if "base64," in base64_data:
                base64_data = base64_data.split("base64,")[1]
            audio_bytes = base64.b64decode(base64_data)
            return self.transcribe_from_bytes(audio_bytes, file_format, options)
        except Exception as e:
            logger.error(f"Error decoding base64 data: {str(e)}")
            return {"error": str(e)}

    def transcribe_from_url(self, url: str, options: Dict[str, Any] = None) -> Dict[str, Any]:
        import requests
        try:
            logger.info(f"Downloading audio from URL: {url}")
            response = requests.get(url, stream=True)
            if response.status_code != 200:
                error_msg = f"Failed to download audio from URL: HTTP {response.status_code}"
                logger.error(error_msg)
                return {"error": error_msg}
            file_format = url.split('.')[-1].lower()
            if file_format not in SUPPORTED_FORMATS:
                content_type = response.headers.get('Content-Type', '')
                if 'audio/' in content_type:
                    file_format = content_type.split('audio/')[1].split(';')[0]
                else:
                    file_format = 'mp3'
            temp_file = os.path.join(self.temp_dir, f"temp_url_audio.{file_format}")
            with open(temp_file, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            return self.transcribe_from_file(temp_file, options)
        except Exception as e:
            logger.error(f"Error transcribing audio from URL: {str(e)}")
            return {"error": str(e)}

    def transcribe_from_microphone(self, duration_seconds: int = 30, options: Dict[str, Any] = None) -> Dict[str, Any]:
        try:
            import pyaudio
            import wave
            logger.info(f"Recording audio for {duration_seconds} seconds...")
            FORMAT = pyaudio.paInt16
            CHANNELS = 1
            RATE = 16000
            CHUNK = 1024
            audio = pyaudio.PyAudio()
            stream = audio.open(format=FORMAT, channels=CHANNELS,
                                rate=RATE, input=True,
                                frames_per_buffer=CHUNK)
            frames = []
            for _ in range(0, int(RATE / CHUNK * duration_seconds)):
                data = stream.read(CHUNK)
                frames.append(data)
            stream.stop_stream()
            stream.close()
            audio.terminate()
            temp_file = os.path.join(self.temp_dir, "temp_recording.wav")
            wf = wave.open(temp_file, 'wb')
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(audio.get_sample_size(FORMAT))
            wf.setframerate(RATE)
            wf.writeframes(b''.join(frames))
            wf.close()
            return self.transcribe_from_file(temp_file, options)
        except ImportError:
            logger.error("PyAudio not installed. Cannot record from microphone.")
            return {"error": "PyAudio not installed. Cannot record from microphone."}
        except Exception as e:
            logger.error(f"Error recording and transcribing from microphone: {str(e)}")
            return {"error": str(e)}

    def transcribe_live_stream(self, stream_callback, max_duration_seconds: int = 300, chunk_duration_seconds: int = 10, options: Dict[str, Any] = None) -> Dict[str, Any]:
        start_time = time.time()
        options = options or {}
        all_transcriptions = []
        accumulated_duration = 0
        try:
            while accumulated_duration < max_duration_seconds:
                audio_chunk, chunk_format = stream_callback()
                if audio_chunk is None:
                    break
                if isinstance(audio_chunk, bytes):
                    result = self.transcribe_from_bytes(audio_chunk, chunk_format, options)
                else:
                    result = self.transcribe_from_file(audio_chunk, options)
                all_transcriptions.append(result)
                chunk_duration = result.get("duration", chunk_duration_seconds)
                accumulated_duration += chunk_duration
                logger.info(f"Processed {accumulated_duration:.1f} seconds of audio...")
            non_silent_sections = [(i * chunk_duration_seconds * 1000, (i + 1) * chunk_duration_seconds * 1000) for i in range(len(all_transcriptions))]
            merged_result = self._merge_transcriptions(all_transcriptions, non_silent_sections)
            processing_time = time.time() - start_time
            merged_result["processing_time"] = processing_time
            output_format = options.get('output_format', 'json')
            final_result = self._prepare_final_output(merged_result, output_format)
            logger.info(f"Live stream transcription completed in {processing_time:.2f} seconds")
            return final_result
        except Exception as e:
            logger.error(f"Error transcribing live stream: {str(e)}")
            return {"error": str(e)}

# Example usage
if __name__ == "__main__":
    transcriber = AdvancedSpeechToText()
    # Example 1: Transcribe a file
    result = transcriber.transcribe_from_file("AIInterviewArchitect/speech-processing/services/s3versioncontrollesson7.mp3", {
        "language": "en",
        "output_format": "text",
    })
    print(result["text"])
    print(json.dumps(result, indent=2))  
    # Example 2: Transcribe from microphone
    # mic_result = transcriber.transcribe_from_microphone(duration_seconds=10)
    # print(json.dumps(mic_result, indent=2))