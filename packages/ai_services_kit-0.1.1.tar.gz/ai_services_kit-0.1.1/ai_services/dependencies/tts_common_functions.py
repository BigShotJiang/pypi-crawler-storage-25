import pygame
import time
import io
import logging

logger = logging.getLogger(__name__) 

def _play_audio(audio_fp: io.BytesIO):
        try:
            pygame.mixer.music.load(audio_fp)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                time.sleep(0.5)
        except Exception as e:
            logger.error(f"Playback Error: {e}")  