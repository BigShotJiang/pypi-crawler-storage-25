
def generate_evaluation_prompt(user_name, job_role, qa_list):
    prompt = f"""
You are an AI-driven HR evaluator.

Candidate: {user_name}
Job Role: {job_role}

Instructions:
1. Evaluate each Q&A pair:
    - Identify if the question is **Relevant** to the job role.
    - If **Relevant**, analyze:
        - "Relevant": true
        - "Question": original question
        - "Answer": original answer
        - "Accuracy/Depth": x/10 (correctness, completeness)
        - "Tone": One of the following:
            1. Confident & Clear 💪
            2. Enthusiastic & Engaging 😃
            3. Neutral & Calm 😐
            4. Nervous & Hesitant 😟
            5. Monotone & Dull 😴
            6. Defensive or Overly Assertive 😤
        - "Score": x/10
        - "Corrected Answer": If Accuracy/Depth ≤ 5, provide an improved answer.
        - "Feedback": Constructive suggestions for clarity and tone.

    - If **Not Relevant**, return:
        - "Relevant": false
        - "Question": original question
        - "Answer": original answer
        - "Accuracy/Depth": "N/A"
        - "Tone": label only
        - "Score": "N/A"
        - "Corrected Answer": Fix grammar only
        - "Feedback": Explain irrelevance.

2. Final Evaluation:
    - Calculate **Overall Score**
    - Highlight weak areas and topics needing improvement.
    - Suggest learning topics if Accuracy/Depth ≤ 5.
    - Provide personalized feedback for {user_name}.

Return response in **valid JSON**. Remove unnecessary newlines.

Interview Data:
"""
    for idx, item in enumerate(qa_list, 1):
        prompt += f'\nQ{idx}: {item["question"]}\nA{idx}: {item["answer"]}'

    return prompt.strip()
