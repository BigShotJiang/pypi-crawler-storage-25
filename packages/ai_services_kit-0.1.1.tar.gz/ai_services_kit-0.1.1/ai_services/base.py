from ai_services.utils.input_validator import validate_llm_messages, validate_tts_input

class LLMProviderBase:
    def generate(self, messages: list[dict], **kwargs) -> str:
        raise NotImplementedError("Must implement generate()")
    def validate_messages(self, messages):
        return validate_llm_messages(messages)
class TTSProviderBase:
    def generate_speech(self,text,**kwargs):
        raise NotImplementedError("Must implement generate_speech()")  
    def validate_text(self, text):
        return validate_tts_input(text)
class STTProviderBase:
    def generate_text(self,audio,**kwargs):
        raise NotImplementedError("Must implement generate_text()")        
# class EvaluatorProviderBase:
#     def evaluate_answers(self,name,role,conversation,**kwargs):
#         raise NotImplementedError("Must implement evaluate_answers()")