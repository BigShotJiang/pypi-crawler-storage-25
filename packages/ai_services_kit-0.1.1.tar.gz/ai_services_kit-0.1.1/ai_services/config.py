import os
from dotenv import load_dotenv
import logging 

logger = logging.getLogger(__name__)

load_dotenv()

def get_key(name: str) -> str | None:
    key = os.getenv(name)
    if key:
        logger.info(f"{name} loaded successfully.")
    else:
        logger.warning(f"{name} not found in .env file.")
    return key

OPENAI_API_KEY = get_key("OPENAI_API_KEY")
GEMINI_API_KEY = get_key("GEMINI_API_KEY")
GROQ_API_KEY = get_key("GROQ_API_KEY")
ANTHROPIC_API_KEY = get_key("ANTHROPIC_API_KEY")