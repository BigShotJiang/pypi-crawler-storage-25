"""
sandbox_pool.py
───────────────
Manages a pool of warm, ready-to-use containers per sandbox.

The pool pre-starts `config.pool_size` containers so that when the agent
needs to execute a script there's no Docker cold-start delay (~1–3s).
A container is "checked out" for one session/turn and returned when done.

Container lifecycle:
  1. Created by _spawn()  — container is running, harness has emitted "ready"
  2. Checked out          — assigned to one ScriptExecutor at a time
  3. Returned             — scratch volume wiped, added back to available pool
  4. Retired              — removed on image rebuild or pool shutdown

Concurrency model:
  Each sandbox has:
    - An asyncio.Queue of idle (warm, available) containers.
    - An asyncio.Semaphore capped at pool_size + max_overflow that tracks
      every live container regardless of whether it is idle or checked out.

  Checkout fast path: queue.get_nowait() — zero contention when idle containers
  are available.

  Checkout slow path (pool exhausted): sem.acquire() blocks the caller until
  a container is returned and retired (freeing a slot) or the overflow budget
  allows a new one to be spawned. Callers wait rather than spawning without
  bound, preventing Docker OOM under sustained load.

  All spawned containers are appended to self._all under self._lock so that
  shutdown() kills every container regardless of whether it was pre-warmed or
  spawned on demand.

Security invariant:
  Every returned container has its /workspace tmpfs cleared before reuse.
  Secrets are injected at container start time via env vars — they are never
  written to the filesystem or visible to subsequent users of the same container.

DooD note (Docker-out-of-Docker)
─────────────────────────────────
When the agent runs inside a container the Docker daemon that receives
containers.run() calls is the HOST daemon.  Volume bind-mount paths must
therefore be HOST filesystem paths, not paths that exist only inside the
agent container.

Use the host_path_map constructor argument to declare prefix translations:

    pool = SandboxPool(
        registry, builder,
        host_path_map={
            "/data":   "/srv/data",    # agent sees /data, host has /srv/data
            "/models": "/opt/models",
        }
    )

Longest prefix wins, so /data/kb is checked before /data.

Alternatively, set FileResource.docker_host_path on individual resources
for per-resource overrides (takes precedence over host_path_map).

On a bare host (no DooD) host_path_map is not needed and can be omitted.
"""

from __future__ import annotations

import asyncio
import json as _json
import logging
import os
import struct as _struct
import time
from typing import Any, Dict, List, Optional

import docker
import docker.errors

from jazzmine.core.tools.sandbox.builder import SandboxBuilder
from jazzmine.core.tools.sandbox.config import SandboxConfig
from jazzmine.core.tools.registry import ToolRegistry

log = logging.getLogger(__name__)


# ── Docker multiplex stream reader ─────────────────────────────────────────────
#
# Docker attach sockets use a multiplexed framing protocol:
#   [1B stream_type][3B padding][4B big-endian payload_length][payload bytes]
#
# A single frame's payload can contain multiple newline-terminated JSON lines.
# A stateless read_line helper that discards bytes after the first \n causes
# stream misalignment on the next call: readexactly(8) reads from the middle
# of the previous payload instead of the next frame header, and the reader
# hangs until the timeout fires.
#
# DockerLineReader solves this by keeping an internal byte buffer that
# accumulates payload bytes across frames.  readline() drains complete lines
# from the buffer before reading the next frame, so no bytes are ever lost.

class DockerLineReader:
    """
    Wraps an asyncio.StreamReader from a Docker attach socket and presents
    a clean readline() interface, stripping the 8-byte multiplex headers and
    correctly buffering across frame boundaries.
    """

    def __init__(self, reader: asyncio.StreamReader) -> None:
        self._reader = reader
        self._buf: bytes = b""

    async def readline(self, timeout: float) -> str:
        """
        Return the next complete (newline-terminated) line as a decoded string,
        with leading/trailing whitespace stripped.

        Raises:
            asyncio.TimeoutError       — no complete line received within timeout
            asyncio.IncompleteReadError — the underlying stream reached EOF
                                          (container crashed or exited)
        """
        deadline = asyncio.get_event_loop().time() + timeout

        while True:
            # Serve from buffer first — avoids reading a new frame unnecessarily
            if b"\n" in self._buf:
                line, self._buf = self._buf.split(b"\n", 1)
                decoded = line.decode("utf-8", errors="replace").strip()
                if decoded:          # skip blank lines
                    return decoded
                continue             # empty line — keep draining

            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise asyncio.TimeoutError()

            # Read the 8-byte frame header
            header = await asyncio.wait_for(
                self._reader.readexactly(8), timeout=remaining
            )
            payload_len = _struct.unpack(">I", header[4:8])[0]
            if payload_len == 0:
                continue             # keep-alive / empty frame

            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise asyncio.TimeoutError()

            # Read the full payload and append to buffer
            payload = await asyncio.wait_for(
                self._reader.readexactly(payload_len), timeout=remaining
            )
            self._buf += payload
            # Loop back to check for \n in the updated buffer


class _SocketAsyncReader:
    """
    Minimal async reader adapter for socket-like objects that do not integrate
    with asyncio.open_connection (for example Docker NpipeSocket on Windows).
    """

    def __init__(self, sock: Any, loop: asyncio.AbstractEventLoop) -> None:
        self._sock = sock
        self._loop = loop
        self._buf = bytearray()
        # NpipeSocket.recv() may block indefinitely on Windows. Prefer a short
        # socket timeout and recv_into() path so read polling can be canceled
        # safely by upper-layer timeouts without orphaned blocking reads.
        try:
            self._sock.settimeout(0.5)
        except Exception:
            pass

    async def readexactly(self, n: int) -> bytes:
        if n <= 0:
            return b""

        while len(self._buf) < n:
            missing = n - len(self._buf)

            def _recv_chunk() -> bytes:
                if hasattr(self._sock, "recv_into"):
                    target = bytearray(missing)
                    read = self._sock.recv_into(target, missing)
                    return bytes(target[:read])
                return self._sock.recv(missing)

            chunk = await self._loop.run_in_executor(None, _recv_chunk)
            if not chunk:
                partial = bytes(self._buf)
                self._buf.clear()
                raise asyncio.IncompleteReadError(partial=partial, expected=n)
            self._buf.extend(chunk)

        out = bytes(self._buf[:n])
        del self._buf[:n]
        return out


class _SocketStreamWriter:
    """
    Minimal writer adapter that matches the write/drain surface used by
    ScriptExecutor for socket-like objects without asyncio transports.
    """

    def __init__(self, sock: Any, loop: asyncio.AbstractEventLoop) -> None:
        self._sock = sock
        self._loop = loop
        self._pending: list[asyncio.Future[Any]] = []

    def write(self, data: bytes) -> None:
        if not data:
            return
        fut = self._loop.run_in_executor(None, lambda: self._sock.sendall(data))
        self._pending.append(fut)

    async def drain(self) -> None:
        if not self._pending:
            return
        pending, self._pending = self._pending, []
        await asyncio.gather(*pending)

    def close(self) -> None:
        try:
            self._sock.close()
        except Exception:
            pass

    async def wait_closed(self) -> None:
        await self.drain()


# ── Container record ───────────────────────────────────────────────────────────

class ManagedContainer:
    """One running container instance tracked by the pool."""

    def __init__(
        self,
        container_id: str,
        sandbox_name: str,
        image_tag:    str,
        stdin_pipe:   asyncio.StreamWriter,
        stdout_pipe:  DockerLineReader,
        created_at:   float,
    ):
        self.container_id = container_id
        self.sandbox_name = sandbox_name
        self.image_tag    = image_tag
        self.stdin_pipe   = stdin_pipe
        self.stdout_pipe  = stdout_pipe
        self.created_at   = created_at
        self.checked_out  = False
        self.use_count    = 0

    def __repr__(self) -> str:
        state = "out" if self.checked_out else "idle"
        return (
            f"<Container {self.container_id[:12]} sandbox={self.sandbox_name!r} "
            f"state={state} uses={self.use_count}>"
        )


# ── SandboxPool ────────────────────────────────────────────────────────────────

class SandboxPool:
    """
    Pool of warm containers, one pool per sandbox name.

    Usage:
        async with pool.checkout("default") as container:
            # container.stdin_pipe and container.stdout_pipe are ready
            ...

    Concurrency:
        Idle containers are served immediately from a per-sandbox asyncio.Queue.
        When all containers are in use, callers block on a Semaphore until
        capacity is available (either a container is returned, or overflow
        budget allows spawning a new one up to pool_size + max_overflow total).
        This bounds total live containers per sandbox and prevents unbounded
        Docker spawning under load.
    """

    MAX_CONTAINER_USES = 50

    def __init__(
        self,
        registry:      ToolRegistry,
        builder:       SandboxBuilder,
        secrets:       Optional[Dict[str, str]] = None,
        max_overflow:  int                      = 10,
        host_path_map: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Parameters
        ----------
        registry       : the ToolRegistry this pool serves.
        builder        : a SandboxBuilder used to build images and manage networks.
        secrets        : mapping of secret name → value. Merged with os.environ
                         at container start time.
        max_overflow   : how many extra containers (beyond pool_size) may be
                         spawned under load before callers start blocking.
        host_path_map  : optional prefix-translation table for DooD mode.
                         Maps agent-container path prefixes to the corresponding
                         Docker host filesystem paths.  Example:
                             {"/data": "/srv/data", "/models": "/opt/models"}
                         Longest prefix wins.  FileResource.docker_host_path
                         takes precedence over any matching entry here.
                         Leave None (or empty) on a bare host — no translation
                         is applied and host_path works as-is.
        """
        self._registry     = registry
        self._builder      = builder
        self._secrets      = secrets or {}
        self._max_overflow = max_overflow

        # Sort descending by prefix length so longest prefix always wins.
        # Stored as a list of (prefix, replacement) tuples for deterministic
        # iteration order — dict ordering is insertion-order, not length-order.
        self._host_path_map: List[tuple[str, str]] = sorted(
            (host_path_map or {}).items(),
            key=lambda kv: -len(kv[0]),
        )

        # Per-sandbox idle container queues
        self._pools:      Dict[str, asyncio.Queue]     = {}
        # Per-sandbox semaphores — cap is pool_size + max_overflow
        self._semaphores: Dict[str, asyncio.Semaphore] = {}
        # All live containers regardless of idle/checked-out state
        self._all:        List[ManagedContainer]        = []
        # Mutex for mutations to self._all
        self._lock        = asyncio.Lock()
        # Re-use the builder's already-validated docker client to avoid a
        # second round-trip to the daemon.  Falls back to docker.from_env()
        # for defensive construction (e.g. in unit tests).
        self._docker      = getattr(builder, "_docker", None) or docker.from_env()

    # ── Host-path translation (DooD support) ───────────────────────────────────

    def _translate_host_path(self, path: str) -> str:
        """
        Translate an agent-container path to a Docker host path using the
        configured host_path_map.

        On a bare host (no DooD) the map is empty and this is a no-op.
        With DooD the daemon resolves bind-mount paths on the HOST filesystem,
        so agent-local paths like /data/kb must be translated to the matching
        host path like /srv/data/kb before being passed to containers.run().

        FileResource.docker_host_path is applied by to_docker_mount() before
        this method is called, so only resources that use host_path (without
        an explicit docker_host_path) reach this translation step.
        """
        for prefix, replacement in self._host_path_map:
            if path.startswith(prefix):
                tail = path[len(prefix):]
                # Ensure we don't produce double slashes when replacement
                # ends with / and tail starts with / (or vice-versa).
                if replacement.endswith("/") and tail.startswith("/"):
                    tail = tail.lstrip("/")
                elif not replacement.endswith("/") and tail and not tail.startswith("/"):
                    tail = "/" + tail
                translated = replacement.rstrip("/") + ("/" + tail.lstrip("/") if tail else "")
                log.debug(f"DooD path translation: {path!r} → {translated!r}")
                return translated
        return path

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def startup(self, sandbox_names: Optional[List[str]] = None) -> None:
        names = sandbox_names or self._registry.all_sandbox_names()
        for name in names:
            config = self._registry.get_sandbox(name)
            if config is None:
                log.warning(f"No config for sandbox '{name}' — skipping pre-warm")
                continue

            image_tag = await self._builder.ensure_sandbox(name)
            net_name  = await self._builder.ensure_network(name)

            cap = config.pool_size + self._max_overflow
            self._semaphores[name] = asyncio.Semaphore(cap)
            self._pools[name]      = asyncio.Queue()

            for _ in range(config.pool_size):
                # Acquire a semaphore slot for each pre-warmed container.
                # These slots are released only when the container is retired.
                await self._semaphores[name].acquire()
                container = await self._spawn(config, image_tag, net_name)
                if container:
                    await self._pools[name].put(container)
                else:
                    # Spawn failed — free the slot we just took
                    self._semaphores[name].release()

        log.info(
            f"SandboxPool ready — {len(self._all)} containers across "
            f"{len(self._pools)} sandboxes"
        )

    async def shutdown(self) -> None:
        # Retire every tracked container (idle and checked-out)
        async with self._lock:
            containers = list(self._all)
        for container in containers:
            await self._retire(container)
        await self._builder.stop_proxy()
        log.info("SandboxPool shut down")

    # ── Checkout context manager ───────────────────────────────────────────────

    class _Checkout:
        def __init__(self, pool: "SandboxPool", sandbox_name: str):
            self._pool         = pool
            self._sandbox_name = sandbox_name
            self._container: Optional[ManagedContainer] = None

        async def __aenter__(self) -> ManagedContainer:
            self._container = await self._pool._checkout(self._sandbox_name)
            return self._container

        async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
            if self._container:
                await self._pool._return(self._container)

    def checkout(self, sandbox_name: str) -> "_Checkout":
        return self._Checkout(self, sandbox_name)

    # ── Internal: checkout / return ────────────────────────────────────────────

    async def _checkout(self, sandbox_name: str) -> ManagedContainer:
        if sandbox_name not in self._pools:
            raise ValueError(
                f"No pool for sandbox '{sandbox_name}'. "
                "Did you call pool.startup() first?"
            )

        queue = self._pools[sandbox_name]

        # ── Fast path: idle container available ───────────────────────────────
        # get_nowait() is atomic from asyncio's perspective — no await point
        # between the dequeue and marking the container as checked out, so two
        # coroutines can never receive the same container.
        try:
            container = queue.get_nowait()
            container.checked_out = True
            container.use_count  += 1
            log.debug(f"Checked out idle container {container.container_id[:12]}")
            return container
        except asyncio.QueueEmpty:
            pass

        # ── Slow path: no idle containers ─────────────────────────────────────
        # Block until either:
        #   (a) a container is returned and retired, freeing a semaphore slot, OR
        #   (b) the overflow budget allows a new container to be spawned.
        # This is the backpressure point — callers queue here under load instead
        # of spawning containers without bound.
        log.info(
            f"Pool exhausted for '{sandbox_name}' — "
            "waiting for capacity before spawning"
        )
        sem = self._semaphores[sandbox_name]
        await sem.acquire()

        # Slot acquired — try the queue one more time in case a container was
        # returned between our get_nowait() failure and sem.acquire().
        try:
            container = queue.get_nowait()
            # We acquired a semaphore slot but are reusing an existing container,
            # so release the extra slot we just took.
            sem.release()
            container.checked_out = True
            container.use_count  += 1
            log.debug(
                f"Checked out container {container.container_id[:12]} "
                "(available after semaphore wait)"
            )
            return container
        except asyncio.QueueEmpty:
            pass

        # Truly need to spawn a new container for this slot.
        config    = self._registry.get_sandbox(sandbox_name)
        image_tag = self._builder._built_images.get(sandbox_name, "")
        net_name  = f"jazzmine-net-{sandbox_name}"

        try:
            container = await self._spawn(config, image_tag, net_name)
        except Exception as exc:
            sem.release()
            raise RuntimeError(
                f"Failed to spawn overflow container for '{sandbox_name}': {exc}"
            ) from exc

        if container is None:
            sem.release()
            raise RuntimeError(
                f"Failed to spawn overflow container for '{sandbox_name}'"
            )

        container.checked_out = True
        container.use_count  += 1
        log.info(f"Spawned overflow container {container.container_id[:12]}")
        return container

    async def _return(self, container: ManagedContainer) -> None:
        container.checked_out = False

        if container.use_count >= self.MAX_CONTAINER_USES:
            log.info(
                f"Retiring container {container.container_id[:12]} "
                f"after {container.use_count} uses"
            )
            await self._retire(container)
            # Semaphore slot was released by _retire. Spawn a fresh replacement
            # to keep the pool at its intended size, acquiring a new slot for it.
            config = self._registry.get_sandbox(container.sandbox_name)
            if config:
                sem = self._semaphores.get(container.sandbox_name)
                if sem:
                    await sem.acquire()
                image_tag = self._builder._built_images.get(container.sandbox_name, "")
                net_name  = f"jazzmine-net-{container.sandbox_name}"
                fresh = await self._spawn(config, image_tag, net_name)
                if fresh:
                    await self._pools[container.sandbox_name].put(fresh)
                elif sem:
                    sem.release()
            return

        await self._clear_scratch(container)

        queue = self._pools.get(container.sandbox_name)
        if queue is not None:
            await queue.put(container)
            log.debug(f"Returned container {container.container_id[:12]} to pool")
        else:
            # Pool was shut down while this container was checked out — retire it.
            await self._retire(container)

    # ── Internal: spawn / retire / clear ──────────────────────────────────────

    async def _spawn(
        self,
        config:    SandboxConfig,
        image_tag: str,
        net_name:  str,
    ) -> Optional[ManagedContainer]:
        """
        Start a new container and wait for the harness to emit 'ready'.
        Always appends the new container to self._all so shutdown() can find it.
        The caller is responsible for acquiring the sandbox semaphore before
        calling this method and for releasing it if spawn fails.

        DooD changes vs original:
          - ensure_proxy() receives net_name so the proxy is connected to the
            sandbox network and returns the correct per-network IP.
          - Each FileResource path is run through _translate_host_path() before
            being passed to containers.run(), converting agent-container paths
            to the Docker host paths the daemon actually requires.
        """
        loop = asyncio.get_event_loop()

        env_vars: Dict[str, str] = {}
        for secret_name in self._registry.aggregate_secrets(config.name):
            val = self._secrets.get(secret_name) or os.environ.get(secret_name, "")
            if val:
                env_vars[secret_name] = val

        proxy_ip = None
        if not config.network_policy.is_isolated:
            try:
                # Pass net_name so the proxy is:
                #   (a) joined to this sandbox's isolated network, and
                #   (b) returns the IP on THAT network (not the default bridge).
                proxy_ip = await self._builder.ensure_proxy(net_name)
            except Exception as exc:
                log.warning(f"Could not start proxy: {exc} — network will be isolated")

        if proxy_ip:
            env_vars["HTTP_PROXY"]  = f"http://{proxy_ip}:8888"
            env_vars["HTTPS_PROXY"] = f"http://{proxy_ip}:8888"
            env_vars["NO_PROXY"]    = "localhost,127.0.0.1"

        # Build the volumes dict, translating host paths for DooD if needed.
        # Resolution order for each resource's bind-mount source path:
        #   1. resource.docker_host_path  (explicit per-resource override)
        #   2. _translate_host_path(resource.host_path)  (prefix map)
        #   3. resource.host_path  (bare-host fallback, no translation needed)
        volumes: Dict[str, dict] = {}
        for resource in config.resources:
            resolved = self._translate_host_path(resource.host_path)
            volumes.update(resource.to_docker_mount(resolved_host_path=resolved))

        try:
            raw = await loop.run_in_executor(
                None,
                lambda: self._docker.containers.run(
                    image        = image_tag,
                    detach       = True,
                    stdin_open   = True,
                    network      = net_name,
                    environment  = env_vars,
                    volumes      = volumes,
                    tmpfs        = {"/workspace": f"size={config.scratch_size_mb}m,uid=1001"},
                    read_only    = True,
                    cap_drop     = ["ALL"],
                    security_opt = ["no-new-privileges:true"],
                    user         = "sandbox",
                    **config.resource_limits.docker_flags(),
                )
            )
        except Exception as exc:
            log.error(f"Failed to start container for '{config.name}': {exc}")
            return None

        socket_handle = await loop.run_in_executor(
            None,
            lambda: raw.attach_socket(params={"stdin": 1, "stdout": 1, "stream": 1})
        )

        if os.name == "nt":
            # Windows Docker named pipes expose NpipeSocket, which does not have
            # the raw _sock attribute expected by asyncio.open_connection.
            socket_obj = getattr(socket_handle, "_sock", None)
            if socket_obj is None:
                socket_obj = getattr(socket_handle, "sock", socket_handle)
            writer = _SocketStreamWriter(socket_obj, loop)
            docker_reader = DockerLineReader(_SocketAsyncReader(socket_obj, loop))
        else:
            # Keep original behavior on non-Windows platforms.
            reader, writer = await asyncio.open_connection(
                sock=socket_handle._sock  # type: ignore[attr-defined]
            )
            docker_reader = DockerLineReader(reader)

        try:
            while True:
                ready_line = await docker_reader.readline(timeout=30.0)
                try:
                    event = _json.loads(ready_line)
                except _json.JSONDecodeError:
                    log.debug(f"Non-JSON line before ready: {ready_line!r}")
                    continue
                if event.get("type") == "ready":
                    break
                log.debug(f"Container pre-ready event: {event}")
        except asyncio.TimeoutError:
            log.error(f"Container for '{config.name}' did not emit 'ready' within 30s")
            await loop.run_in_executor(None, lambda: raw.remove(force=True))
            return None
        except (asyncio.IncompleteReadError, EOFError):
            log.error(f"Container for '{config.name}' exited before emitting 'ready'")
            await loop.run_in_executor(None, lambda: raw.remove(force=True))
            return None

        container = ManagedContainer(
            container_id = raw.id,
            sandbox_name = config.name,
            image_tag    = image_tag,
            stdin_pipe   = writer,
            stdout_pipe  = docker_reader,
            created_at   = time.monotonic(),
        )

        # Always track every spawned container so shutdown() cleans up everything.
        async with self._lock:
            self._all.append(container)

        return container

    async def _retire(self, container: ManagedContainer) -> None:
        """
        Stop and remove the container, remove it from self._all, and release
        its semaphore slot so the capacity is available for a new container.
        """
        loop = asyncio.get_event_loop()
        try:
            raw = await loop.run_in_executor(
                None, lambda: self._docker.containers.get(container.container_id)
            )
            await loop.run_in_executor(None, lambda: raw.remove(force=True))
        except docker.errors.NotFound:
            pass
        except Exception as exc:
            log.warning(f"Error retiring {container.container_id[:12]}: {exc}")

        async with self._lock:
            if container in self._all:
                self._all.remove(container)

        # Release the semaphore slot this container was holding so the next
        # caller waiting in _checkout can proceed.
        sem = self._semaphores.get(container.sandbox_name)
        if sem is not None:
            sem.release()

    async def _clear_scratch(self, container: ManagedContainer) -> None:
        loop = asyncio.get_event_loop()
        try:
            raw = await loop.run_in_executor(
                None, lambda: self._docker.containers.get(container.container_id)
            )
            result = await loop.run_in_executor(
                None,
                lambda: raw.exec_run(
                    "find /workspace -mindepth 1 -delete",
                    user="sandbox",
                )
            )
            if result.exit_code != 0:
                log.debug(f"Scratch clear non-zero exit: {result.output}")
        except Exception as exc:
            log.warning(
                f"Failed to clear scratch for {container.container_id[:12]}: {exc}"
            )