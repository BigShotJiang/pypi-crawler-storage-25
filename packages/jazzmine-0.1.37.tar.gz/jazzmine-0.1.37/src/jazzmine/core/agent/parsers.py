from __future__ import annotations

import json
import re

_TASK_RE = re.compile(
    r'<task(?:\s+sandbox=["\']([^"\']*)["\'])?(?:\s+mode=["\']([^"\']*)["\'])?[^>]*>'
    r'(.*?)</task>',
    re.DOTALL | re.IGNORECASE,
)
_RESPONSE_RE = re.compile(r'<response>(.*?)</response>', re.DOTALL)
_CONFIRM_RE = re.compile(r'<confirm\s*/?>', re.IGNORECASE)
_CANCEL_RE = re.compile(r'<cancel\s*/?>', re.IGNORECASE)
_FLOW_COMPLETE_RE = re.compile(r'<flow_complete\s*/?>', re.IGNORECASE)
_TOOL_EXEC_RE = re.compile(r'<tool_execution\b[^>]*>.*?</tool_execution>', re.DOTALL | re.IGNORECASE)
_TOOL_RESULT_RE = re.compile(r'<r>\s*(.*?)\s*</r>', re.DOTALL | re.IGNORECASE)
_TOOL_ERROR_RE = re.compile(r'<e>\s*(.*?)\s*</e>', re.DOTALL | re.IGNORECASE)


def _to_float(value: object) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _format_number(value: object, decimals: int = 2) -> str:
    number = _to_float(value)
    if number is None:
        return "n/a"
    return f"{number:,.{decimals}f}"


def _format_money(value: object) -> str:
    number = _to_float(value)
    if number is None:
        return "n/a"
    return f"${number:,.2f}"


def _format_percent(value: object) -> str:
    number = _to_float(value)
    if number is None:
        return "n/a"
    return f"{number:.2f}%"


def _format_volume(value: object) -> str:
    number = _to_float(value)
    if number is None:
        return "n/a"
    return f"{int(round(number)):,}"


def _format_as_of(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if "T" in text:
        return text.split("T", 1)[0]
    return text.split(" ", 1)[0]


def _is_market_snapshot_payload(payload: object) -> bool:
    if not isinstance(payload, dict):
        return False
    required_keys = {"ticker", "period", "close", "high", "low"}
    return required_keys.issubset(payload.keys())


def _format_market_snapshot_payload(payload: dict, detail_suffix: str) -> str:
    ticker = str(payload.get("ticker") or "the ticker")
    period = str(payload.get("period") or "requested period")
    as_of = _format_as_of(payload.get("as_of"))

    close = _format_money(payload.get("close"))
    previous_close = _format_money(payload.get("previous_close"))
    change_abs = _to_float(payload.get("change_abs"))
    change_pct = _to_float(payload.get("change_pct"))

    open_price = _format_money(payload.get("open"))
    high = _format_money(payload.get("high"))
    low = _format_money(payload.get("low"))
    period_high = _format_money(payload.get("period_high"))
    period_low = _format_money(payload.get("period_low"))

    volume = _format_volume(payload.get("volume"))
    avg_volume_20 = _format_volume(payload.get("avg_volume_20"))

    header = f"Here is the {period} market snapshot for {ticker}"
    if as_of:
        header += f" as of {as_of}"
    header += "."

    if change_abs is not None and change_pct is not None:
        direction = "up" if change_abs >= 0 else "down"
        change_sentence = (
            f"The latest close is {close}, {direction} {abs(change_abs):,.2f} "
            f"({abs(change_pct):.2f}%) from the previous close of {previous_close}."
        )
    else:
        change_sentence = f"The latest close is {close} (previous close: {previous_close})."

    lines = [
        header,
        change_sentence,
        f"The day range was {low} to {high} with an open at {open_price}.",
        f"Over this {period} window, the range was {period_low} to {period_high}.",
        f"Latest volume was {volume} shares versus a 20-day average of {avg_volume_20}.",
    ]

    if detail_suffix:
        lines.append(f"Execution details{detail_suffix}.")

    return "\n\n".join(lines)


def _format_generic_payload(payload: object, detail_suffix: str) -> str:
    if isinstance(payload, dict):
        snippets: list[str] = []
        for key, value in payload.items():
            label = key.replace("_", " ")
            if isinstance(value, (str, int, float, bool)) or value is None:
                snippets.append(f"{label}: {value}")
            elif isinstance(value, list):
                snippets.append(f"{label}: {len(value)} item(s)")
            elif isinstance(value, dict):
                snippets.append(f"{label}: {len(value)} field(s)")

            if len(snippets) >= 6:
                break

        if snippets:
            sentence = "I completed the request. Key results: " + "; ".join(snippets) + "."
        else:
            sentence = "I completed the request and received structured output."
    elif isinstance(payload, list):
        sentence = f"I completed the request and received {len(payload)} result item(s)."
    else:
        sentence = f"I completed the request. Result: {payload}"

    if detail_suffix:
        sentence += f" Execution details{detail_suffix}."
    return sentence


def _format_tool_execution_block(block: str) -> str:
    open_tag = block.split(">", 1)[0]
    success = bool(
        re.search(r'\bsuccess=(?:["\'])?true(?:["\'])?(?:\s|$)', open_tag, flags=re.IGNORECASE)
    )
    attempts_match = re.search(
        r'\battempts=(?:["\'])?(\d+)(?:["\'])?(?:\s|$)', open_tag, flags=re.IGNORECASE
    )
    ms_match = re.search(
        r'\bms=(?:["\'])?(\d+)(?:["\'])?(?:\s|$)', open_tag, flags=re.IGNORECASE
    )

    details: list[str] = []
    if attempts_match:
        details.append(f"{attempts_match.group(1)} attempt(s)")
    if ms_match:
        details.append(f"{ms_match.group(1)} ms")
    detail_suffix = f" ({', '.join(details)})" if details else ""

    if success:
        payload_match = _TOOL_RESULT_RE.search(block)
        payload = payload_match.group(1).strip() if payload_match else ""
        if not payload:
            return f"I completed the request successfully{detail_suffix}."

        try:
            parsed = json.loads(payload)
        except json.JSONDecodeError:
            fallback_text = f"I completed the request successfully{detail_suffix}."
            return f"{fallback_text} Raw result: {payload}"

        if _is_market_snapshot_payload(parsed):
            return _format_market_snapshot_payload(parsed, detail_suffix)
        return _format_generic_payload(parsed, detail_suffix)

    error_match = _TOOL_ERROR_RE.search(block)
    error_text = error_match.group(1).strip() if error_match else "Unknown tool error."
    return f"I could not complete the request{detail_suffix}. Error: {error_text}"


def _fallback_without_response_tags(clean: str) -> str:
    matches = list(_TOOL_EXEC_RE.finditer(clean))
    if not matches:
        return clean.strip()

    plain_text = _TOOL_EXEC_RE.sub("", clean).strip()
    if plain_text:
        return plain_text

    return _format_tool_execution_block(matches[-1].group(0))


def parse_task_request(text: str) -> tuple[str, str, str] | None:
    match = _TASK_RE.search(text)
    if not match:
        return None
    sandbox = (match.group(1) or "").strip()
    mode = (match.group(2) or "").strip()
    task = match.group(3).strip()
    return sandbox, mode, task


def extract_response(text: str) -> str:
    match = _RESPONSE_RE.search(text)
    if match:
        return match.group(1).strip()
    clean = _TASK_RE.sub("", text)
    clean = re.sub(r'<(confirm|cancel|flow_complete)\s*/?>', "", clean, flags=re.IGNORECASE)
    return _fallback_without_response_tags(clean)