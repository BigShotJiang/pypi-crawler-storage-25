# -*- coding: utf-8 -*-
import os
import platform

# nacos 的配置信息。保留环境变量 or 默认值，方便本地调试
spider_nacos_addr = os.getenv("NACOS_ADDR")
spider_nacos_access_key = os.getenv("NACOS_SPIDER_ACCESS_KEY")
spider_nacos_secret_key = os.getenv("NACOS_SPIDER_SECRET_KEY")

SYSTEM_NAME = platform.system().lower()
LOCAL_ENV = SYSTEM_NAME in ["windows", "darwin"]

nacos_namespace = os.getenv("NACOS_NAMESPACE") or "qa"

NACOS_CONFIG_MAP = {
    "spider_public": {
        "name_space": os.getenv("NACOS_SPIDER_NAMESPACE") or "qa-spider",
        "group": "victor-spider",
        "data_id": "spider-public-service-template.properties",
        "type": "env",
    },
    "spider_mysql": {
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "tdmysql_tx_spider_conn.properties",
        "type": "mysql",
        "mount_prefix": "DATA_DB",
    },
    "spider_rabbitmq": {
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "rabbitmq_tx_spider_conn.properties",
        "type": "rabbitmq",
        "mount_prefix": "RABBIT",
    },
    "spider_redis": {
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "redis_spider_conn.properties",
        "type": "redis",
        "mount_prefix": "REDIS",
    },
    # 重构库
    "onshore_mysql": {
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "mysql_onshore_conn.properties",
        "type": "mysql",
        "mount_prefix": "ONSHORE_DB",
    },
    # 卖出库
    "sell_mysql": {
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "mysql_sell_conn.properties",
        "type": "mysql",
        "mount_prefix": "SELL_DB",
    },
    # 老国内
    "innodealing_mysql": {
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "mysql_innodealing_conn.properties",
        "type": "mysql",
        "mount_prefix": "INNODEALING_DB",
    },
    # 三方库
    "third_mysql": {
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "mysql_third_conn.properties",
        "type": "mysql",
        "mount_prefix": "THIRD_DB",
    },
    # 新三方库，三方库的同步库
    # mysql_csci002_conn.properties
    "csci002_mysql": {
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "mysql_csci002_conn.properties",
        "type": "mysql",
        "mount_prefix": "CSCI002_DB",
    },
    "mysql_polar_general":{
        "name_space": nacos_namespace,
        "group": "public",
        "data_id": "polar_general_conn.properties",
        "type": "mysql",
        "mount_prefix": "POLAR_GENERAL_DB",
    }
}


def get_nacos_config_meta(name: str) -> dict:
    """
    根据名称获取 nacos 配置元信息
    """
    if name not in NACOS_CONFIG_MAP:
        raise KeyError(f"unknown nacos config name: {name}")
    return NACOS_CONFIG_MAP[name]

# def register_nacos_config(
#     name: str,
#     namespace: str,
#     group: str,
#     data_id: str,
#     config_type: str = "env",
# ):
#     """
#     运行时动态注册新的 nacos 配置
#     例如后续新增其它 mysql / redis / rabbitmq / 自定义配置时可直接调用
#     """
#     NACOS_CONFIG_MAP[name] = {
#         "name_space": namespace,
#         "group": group,
#         "data_id": data_id,
#         "type": config_type,
#     }
