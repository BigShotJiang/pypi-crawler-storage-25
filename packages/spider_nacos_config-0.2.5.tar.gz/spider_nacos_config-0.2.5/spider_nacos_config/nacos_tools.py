# -*- coding: utf-8 -*-
import json

import nacos

from .base_config import (
    spider_nacos_addr,
    get_nacos_config_meta,
)


class NacosSpiderPublicConfigLoader:
    """Nacos 爬虫公共环境变量"""

    def __init__(self, access_key, secret_key):
        self.spider_nacos_access_key = access_key
        self.spider_nacos_secret_key = secret_key
        self._client_cache = {}

    def _get_client(self, nacos_addr, namespace):
        """获取 nacos client，按 namespace 缓存"""
        cache_key = f"{nacos_addr}:{namespace}"
        client = self._client_cache.get(cache_key)
        if client is not None:
            return client

        client = nacos.NacosClient(
            nacos_addr,
            namespace=namespace,
            ak=self.spider_nacos_access_key,
            sk=self.spider_nacos_secret_key
        )
        self._client_cache[cache_key] = client
        return client

    def _init_config(self, nacos_addr, namespace, data_id, group):
        """初始化配置"""
        client = self._get_client(nacos_addr, namespace)
        content = client.get_config(data_id=data_id, group=group)
        if not content:
            raise RuntimeError(
                f"empty nacos config, nacos_addr={nacos_addr}, namespace={namespace}, "
                f"group={group}, data_id={data_id}"
            )
        return content

    @staticmethod
    def _parse_value(value: str):
        """尽量把字符串解析成更合适的 Python 类型"""
        value = value.strip()

        if value == "":
            return ""

        # json list / dict
        if (value.startswith("{") and value.endswith("}")) or (
            value.startswith("[") and value.endswith("]")
        ):
            try:
                return json.loads(value)
            except Exception:
                return value

        # bool
        lower_value = value.lower()
        if lower_value == "true":
            return True
        if lower_value == "false":
            return False

        # int
        if value.isdigit() or (value.startswith("-") and value[1:].isdigit()):
            try:
                return int(value)
            except Exception:
                pass

        # float
        try:
            if "." in value:
                return float(value)
        except Exception:
            pass

        return value

    def parse_nacos_kv_to_nested(self, content: str) -> dict:
        """
        把 Nacos 返回的 key=value 格式配置解析成嵌套 dict。
        例如：
            public.redis_spider_conn.host=1.2.3.4
        =>
            {"public": {"redis_spider_conn": {"host": "1.2.3.4"}}}
        """
        result = {}

        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue

            key, value = line.split("=", 1)
            value = self._parse_value(value)
            parts = key.strip().split(".")

            current = result
            for i, p in enumerate(parts):
                if i == len(parts) - 1:
                    current[p] = value
                else:
                    current = current.setdefault(p, {})

        return result

    def parse_env_style_config(self, content: str) -> dict:
        """
        将类似 ENV_VAR=value 格式的内容解析成字典
        自动忽略空行和注释
        """
        result = {}
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue

            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            result[key] = self._parse_value(value)

        return result

    def get_mysql_config(self, nacos_addr, namespace, data_id, group):
        """获取 mysql 配置"""
        content = self._init_config(nacos_addr, namespace, data_id, group)
        result = self.parse_nacos_kv_to_nested(content)

        # 兼容你当前配置格式：public.polar_data_conn.host=...
        root_name = data_id.split(".")[0]
        polar_conf = result.get(group, {}).get(root_name, {})

        item = {
            "host": polar_conf.get("host"),
            "port": int(polar_conf.get("port", 3306) or 3306),
            "user": polar_conf.get("rw_user"),
            "password": polar_conf.get("rw_passwd"),
            "db": polar_conf.get("db"),
        }
        return item

    def get_mysql_config_by_path(
        self,
        nacos_addr,
        namespace,
        data_id,
        group,
        root_group=None,
        root_name=None,
        user_key="rw_user",
        password_key="rw_passwd",
    ):
        """
        通用 mysql 获取方法，兼容后续新增 mysql 配置时的扩展。
        """
        content = self._init_config(nacos_addr, namespace, data_id, group)
        result = self.parse_nacos_kv_to_nested(content)

        root_group = root_group or group
        root_name = root_name or data_id.split(".")[0]

        conf = result.get(root_group, {}).get(root_name, {})
        return {
            "host": conf.get("host"),
            "port": int(conf.get("port", 3306) or 3306),
            "user": conf.get(user_key),
            "password": conf.get(password_key),
            "db": conf.get("db"),
        }

    def get_redis_config(self, nacos_addr, namespace, data_id, group):
        """获取 redis 配置"""
        content = self._init_config(nacos_addr, namespace, data_id, group)
        result = self.parse_nacos_kv_to_nested(content)

        root_name = data_id.split(".")[0]
        conf = result.get(group, {}).get(root_name, {})

        item = {
            "host": conf.get("host"),
            "port": int(conf.get("port", 6379) or 6379),
            "user": conf.get("user"),
            "password": conf.get("passwd"),
            "db": conf.get("db"),
        }
        return item

    def get_rabbitmq_config(self, nacos_addr, namespace, data_id, group):
        """获取 rabbitmq 配置"""
        content = self._init_config(nacos_addr, namespace, data_id, group)
        result = self.parse_nacos_kv_to_nested(content)

        root_name = data_id.split(".")[0]
        conf = result.get(group, {}).get(root_name, {})

        item = {
            "host": conf.get("host"),
            "port": int(conf.get("port", 5672) or 5672),
            "user": conf.get("user"),
            "password": conf.get("passwd"),
            "vhost": conf.get("vhost", "/"),
        }
        return item

    def get_spider_public_config(self, nacos_addr, namespace, data_id, group, local_env: bool = False):
        """获取公共接口配置"""
        content = self._init_config(nacos_addr, namespace, data_id, group)
        all_conf = self.parse_env_style_config(content)

        # 先用非 _LOCAL 的键建立基线
        result = {}
        for k, v in all_conf.items():
            if k.endswith("_LOCAL"):
                continue
            result[k] = v

        # 本地环境时，用 *_LOCAL 覆盖对应基础键
        if local_env:
            for k, v in all_conf.items():
                if k.endswith("_LOCAL"):
                    base_key = k[:-6]
                    result[base_key] = v

        return result

    def get_config_by_name(self, name: str, local_env: bool = False):
        """
        根据 base_config.py 中注册的名字，自动拉取并解析配置
        """
        meta = get_nacos_config_meta(name)
        config_type = meta.get("type", "env")

        namespace = meta["name_space"]
        group = meta["group"]
        data_id = meta["data_id"]

        if config_type == "mysql":
            return self.get_mysql_config(
                nacos_addr=spider_nacos_addr,
                namespace=namespace,
                data_id=data_id,
                group=group,
            )

        if config_type == "redis":
            return self.get_redis_config(
                nacos_addr=spider_nacos_addr,
                namespace=namespace,
                data_id=data_id,
                group=group,
            )

        if config_type == "rabbitmq":
            return self.get_rabbitmq_config(
                nacos_addr=spider_nacos_addr,
                namespace=namespace,
                data_id=data_id,
                group=group,
            )

        if config_type == "env":
            return self.get_spider_public_config(
                nacos_addr=spider_nacos_addr,
                namespace=namespace,
                data_id=data_id,
                group=group,
                local_env=local_env,
            )

        # 兜底：原始 env 解析
        content = self._init_config(
            nacos_addr=spider_nacos_addr,
            namespace=namespace,
            data_id=data_id,
            group=group,
        )
        return self.parse_env_style_config(content)