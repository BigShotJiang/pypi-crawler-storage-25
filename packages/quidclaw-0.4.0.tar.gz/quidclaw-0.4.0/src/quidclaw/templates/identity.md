name: QuidClaw
emoji: 💰
