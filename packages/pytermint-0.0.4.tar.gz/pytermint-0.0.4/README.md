# PyTermint
This is a cross-platform terminal abstraction that converts a tile map to a non-flickering terminal output with 3 bit rgb support using escape codes. It also has significant amounts of input automation for things like typing and movement. It clocks in at just under 27k bytes (k is 1024) *(uncompressed, It goes down to 16k just with windows file compression)* and has no significant dependencies outside of the [***Python Standard Library***](https://docs.python.org/3/library/index.html) (*other than evdev for linux input but it handles the lack of this automatically*). While ~27k bytes sounds like a lot this is boiler plate not in your project which means a full colored snake game comes in at around 2.2k bytes. It also has a large amount of graphics macros for things like drawing a window, a line, a rectangle or a text_box. Through gplot() the horozontal and vertical resolution are doubled into a 1bpp bitmap with 2x2 pixel 3bpp rgb attribute coloring. The array is edited and read through screen[y][x].
***
* **Install with "*pip install PyTermint*"** 
* **Import as "*import PyTerm*"**
* **Create a *init()* function that takes *screen* and returns the inital state of the tile map (*a list of lists addresable as arr[y][x] or [y0 [x0, x1, x2...], y1 [x0, x1, x2...]...]*), a dictionary holding all variables that should persist after the end of a frame and a optional command string**
* **Create a *tick()* command that takes as inputs *tick(screen, vars, keys)*. Screen is an array, vars is the dict you initialized in *init* and keys which is a set of every key thats pressed**
* **Call the *run(tick_func, init_func)***
***
```w
import PyTerm as pt
from PyTerm import clear, blit, color, TILE_SET, HEIGHT, WIDTH, pressed

def init(screen):
    return (screen, {
        'text': '', 
        'cpos': (0, 0),  
    })

def tick(screen, v, keys):
    pt.clear(screen, pt.color(0, bg=1)) 
    pt.handle_input(v, keys)
    if "alt" in keys and "q" in keys: return "quit"
    pt.blit(screen, pt.str_to_arr(v["text"], pt.color(0)), 0, 0)
    # Cursor rendering
    x, y = v['cpos']
    if pt.inside(screen, (x, y)):
        screen[y][x] = pt.color(8, fg=1, bg=2)

if __name__ == "__main__":
    pt.run(tick, init, False)
```
* ***A small text editor for PyTerm***

***
[GitHub Home page link](https://github.com/Antlar256/PyTerm)