from __future__ import annotations

from typing import Any, Mapping

from tigrbl_core.config.constants import __JSONRPC_DEFAULT_ENDPOINT_MAPPINGS__

from ... import events as _ev
from ...stages import Ingress, Bound
from ...types import Atom, BoundCtx, Ctx

ANCHOR = _ev.DISPATCH_BINDING_MATCH


def _dispatch_dict(ctx: Any) -> dict[str, object]:
    temp = getattr(ctx, "temp", None)
    if not isinstance(temp, dict):
        temp = {}
        setattr(ctx, "temp", temp)
    obj = temp.setdefault("dispatch", {})
    if isinstance(obj, dict):
        return obj
    temp["dispatch"] = {}
    return temp["dispatch"]


def _method(ctx: Any) -> str:
    return str(getattr(ctx, "method", "") or "").upper()


def _path(ctx: Any) -> str:
    path = str(getattr(ctx, "path", "/") or "/")
    return path.rstrip("/") or "/"


def _endpoint(dispatch: Mapping[str, object], ctx: Any) -> str | None:
    endpoint = dispatch.get("endpoint")
    if isinstance(endpoint, str) and endpoint:
        return endpoint
    temp = getattr(ctx, "temp", None)
    if isinstance(temp, Mapping):
        route = temp.get("route")
        if isinstance(route, Mapping):
            endpoint = route.get("endpoint")
            if isinstance(endpoint, str) and endpoint:
                return endpoint
    return None


def _jsonrpc_endpoint_for_request(
    dispatch: Mapping[str, object],
    ctx: Any,
    *,
    method: str,
    path: str,
) -> str | None:
    if method != "POST":
        return None

    endpoint = _endpoint(dispatch, ctx)
    if endpoint:
        return endpoint

    for owner_key in ("router", "app"):
        owner = getattr(ctx, owner_key, None)
        if owner is None and hasattr(ctx, "get"):
            owner = ctx.get(owner_key)
        mounts = getattr(owner, "_jsonrpc_endpoint_mounts", None)
        if isinstance(mounts, Mapping):
            mounted = mounts.get(path) or mounts.get(f"{path}/")
            if isinstance(mounted, str) and mounted:
                return mounted

    for mapped_endpoint, mapped_path in __JSONRPC_DEFAULT_ENDPOINT_MAPPINGS__.items():
        if path == (str(mapped_path).rstrip("/") or "/"):
            return str(mapped_endpoint)
    return None


def _rpc_method(dispatch: Mapping[str, object], ctx: Any) -> str | None:
    payload = _rpc_payload(dispatch, ctx)
    if isinstance(payload, Mapping):
        method = payload.get("method")
        if isinstance(method, str):
            return method
    return None


def _rpc_payload(dispatch: Mapping[str, object], ctx: Any) -> Mapping[str, object] | None:
    rpc = dispatch.get("rpc")
    if isinstance(rpc, Mapping):
        return rpc
    body_json = dispatch.get("body_json")
    if isinstance(body_json, Mapping):
        return body_json
    temp = getattr(ctx, "temp", None)
    if isinstance(temp, Mapping):
        ingress = temp.get("ingress")
        if isinstance(ingress, Mapping):
            ingress_body_json = ingress.get("body_json")
            if isinstance(ingress_body_json, Mapping):
                return ingress_body_json
    body = getattr(ctx, "body", None)
    if isinstance(body, (bytes, bytearray)):
        try:
            import json

            decoded = json.loads(bytes(body).decode("utf-8"))
        except Exception:
            decoded = None
        if isinstance(decoded, Mapping):
            return decoded
    if isinstance(body, Mapping):
        return body
    return None


def _run(obj: object | None, ctx: Any) -> None:
    del obj
    dispatch = _dispatch_dict(ctx)
    temp = getattr(ctx, "temp", None)
    route = temp.setdefault("route", {}) if isinstance(temp, dict) else {}
    plan = getattr(ctx, "kernel_plan", None) or getattr(ctx, "plan", None)
    proto_indices = getattr(plan, "proto_indices", {}) if plan is not None else {}

    method = _method(ctx)
    path = _path(ctx)
    endpoint = _jsonrpc_endpoint_for_request(
        dispatch,
        ctx,
        method=method,
        path=path,
    )
    rpc_payload = _rpc_payload(dispatch, ctx)
    rpc_method = _rpc_method(dispatch, ctx)

    matched_proto: str | None = None
    matched_selector: str | None = None
    matched_path_params: dict[str, object] = {}

    if isinstance(proto_indices, Mapping):
        for proto, bucket in proto_indices.items():
            if not isinstance(proto, str) or not isinstance(bucket, Mapping):
                continue
            if (
                proto.endswith(".jsonrpc")
                and isinstance(endpoint, str)
                and isinstance(rpc_method, str)
            ):
                endpoints = bucket.get("endpoints")
                if isinstance(endpoints, Mapping):
                    endpoint_bucket = endpoints.get(endpoint)
                    if isinstance(endpoint_bucket, Mapping):
                        entry = endpoint_bucket.get(rpc_method)
                        if isinstance(entry, Mapping):
                            matched_proto = proto
                            matched_selector = str(
                                entry.get("selector") or f"{endpoint}:{rpc_method}"
                            )
                            dispatch["endpoint"] = str(
                                entry.get("endpoint") or endpoint
                            )
                            break
            if proto.endswith(".rest"):
                exact = bucket.get("exact")
                selector = f"{method} {path}"
                if isinstance(exact, Mapping) and selector in exact:
                    matched_proto = proto
                    matched_selector = selector
                    break
                templated = bucket.get("templated")
                if isinstance(templated, list):
                    for entry in templated:
                        if not isinstance(entry, Mapping):
                            continue
                        pattern = entry.get("pattern")
                        if pattern is None or not hasattr(pattern, "match"):
                            continue
                        m = pattern.match(path)
                        if m is None:
                            continue
                        entry_method = str(entry.get("method", "") or "").upper()
                        if entry_method and entry_method != method:
                            continue
                        matched_proto = proto
                        matched_selector = str(entry.get("selector") or selector)
                        names = entry.get("names")
                        if isinstance(names, (list, tuple)):
                            matched_path_params = {
                                str(name): value
                                for name, value in zip(names, m.groups())
                            }
                        break
                    if matched_selector is not None:
                        break
            if proto in {"ws", "wss"}:
                exact = bucket.get("exact")
                if isinstance(exact, Mapping) and path in exact:
                    matched_proto = proto
                    matched_selector = path
                    break

    if matched_proto is not None:
        dispatch["binding_protocol"] = matched_proto
        if isinstance(route, dict):
            route["protocol"] = matched_proto
        setattr(ctx, "protocol", matched_proto)
    if matched_selector is not None:
        dispatch["binding_selector"] = matched_selector
        if isinstance(route, dict):
            route["selector"] = matched_selector
        setattr(ctx, "selector", matched_selector)
    if matched_proto is not None and matched_proto.endswith(".jsonrpc"):
        if isinstance(rpc_payload, Mapping):
            if isinstance(temp, dict):
                temp["jsonrpc_request_id"] = rpc_payload.get("id")
            dispatch["rpc"] = dict(rpc_payload)
            dispatch["rpc_method"] = rpc_payload.get("method")
            dispatch["parsed_payload"] = rpc_payload.get("params", {})
        if isinstance(route, dict):
            route["endpoint"] = str(dispatch.get("endpoint") or endpoint)
            if isinstance(rpc_payload, Mapping):
                route["rpc_envelope"] = dict(rpc_payload)
                route["payload"] = rpc_payload.get("params", {})
        setattr(ctx, "endpoint", str(dispatch.get("endpoint") or endpoint))
    if matched_path_params:
        dispatch["path_params"] = matched_path_params
        if isinstance(route, dict):
            route["path_params"] = matched_path_params
        setattr(ctx, "path_params", matched_path_params)


class AtomImpl(Atom[Ingress, Bound, Exception]):
    name = "dispatch.binding_match"
    anchor = ANCHOR

    async def __call__(self, obj: object | None, ctx: Ctx[Ingress]) -> Ctx[Bound]:
        _run(obj, ctx)
        return ctx.promote(BoundCtx)


INSTANCE = AtomImpl()

__all__ = ["ANCHOR", "INSTANCE"]
