"""AI review agent using the Azure OpenAI SDK."""

from __future__ import annotations

import json
import re
from pathlib import Path

from .config import AIReviewConfig, Config
from .models import FileComment, LintFinding, ReviewResult
from .settings import Settings, load_settings

# ── Skill loader ──────────────────────────────────────────────────────────────

def _load_skills(repo_path: Path) -> str:
    """Read all SKILL.md files from <repo>/.commit-defender/*/SKILL.md.

    Returns a formatted string ready to embed in the system prompt, or an
    empty string if no skill directory exists.
    """
    skill_dir = repo_path / ".commit-defender"
    if not skill_dir.is_dir():
        return ""

    sections: list[str] = []
    for skill_md in sorted(skill_dir.glob("*/SKILL.md")):
        category = skill_md.parent.name
        content = skill_md.read_text(encoding="utf-8").strip()
        sections.append(f"### [{category}]\n\n{content}")

    if not sections:
        return ""

    return "## Active Review Skills\n\n" + "\n\n---\n\n".join(sections)


# ── Behavior modifiers ────────────────────────────────────────────────────────

_SEVERITY_PROMPTS: dict[str, str] = {
    "severe": (
        "Apply the absolute strictest possible review. Flag every deviation from "
        "best practice, every style inconsistency, every potential issue — no matter "
        "how minor. Zero tolerance."
    ),
    "rigorous": (
        "Apply a strict review. Flag most issues including minor style and "
        "best-practice deviations. Err on the side of raising concerns."
    ),
    "moderate": (
        "Apply a balanced review. Flag meaningful issues and genuine best-practice "
        "violations, but do not nitpick trivial style details."
    ),
    "generous": (
        "Apply a lenient review. Only flag significant issues that carry clear risk "
        "or that deviate substantially from convention. Allow minor imperfections."
    ),
    "lean": (
        "Apply a minimal review. Only flag critical issues: those that will break "
        "functionality, introduce security vulnerabilities, or cause data loss."
    ),
}

_RICHNESS_PROMPTS: dict[str, str] = {
    "colorful": (
        "For each finding, provide an elaborate explanation: describe the problem in "
        "depth, give a concrete example of the fix, explain the reasoning, and mention "
        "any trade-offs. The summary may be up to 600 words."
    ),
    "chatty": (
        "For each finding, provide helpful context and a suggested fix. "
        "The summary should be thorough but focused, up to 400 words."
    ),
    "moderate": (
        "Provide clear, concise explanations for each finding. "
        "Keep the summary under 300 words."
    ),
    "simple": (
        "Be brief. One or two sentences per finding. "
        "Keep the summary under 150 words."
    ),
    "silent": (
        "Output one-line descriptions only. No elaboration, no examples, no context. "
        "Keep the summary under 60 words."
    ),
}

_LOCALE_PROMPTS: dict[str, str] = {
    "en": "Write all output in English.",
    "ko": "모든 출력을 한국어로 작성하세요.",
}

_BASE_SYSTEM_PROMPT_DIFF = """\
You are commit-defender, an AI code reviewer integrated into a git pre-commit hook.

Your job is to review the provided git diff and static analysis findings, then produce a
concise, actionable review that helps the developer understand what needs to be fixed
before committing.

## Core guidelines
- Be direct and specific. Reference file names and line numbers.
- Group related issues together.
- Distinguish between must-fix issues (errors) and suggestions (warnings/style).
- Do not repeat every lint finding verbatim — synthesize patterns and highlight the most important ones.
- If the changes look good overall, say so clearly.

## Output format
Respond ONLY with a valid JSON object matching this schema:
{
  "summary": "<narrative review, markdown allowed>",
  "blocking": <true if the code should not be committed as-is, false otherwise>,
  "file_comments": [
    {
      "file": "<path relative to repo root, e.g. src/main.py>",
      "line": <1-based line number from the diff; 0 for a file-level comment>,
      "comment": "<actionable suggestion, markdown allowed>"
    }
  ]
}

Rules for file_comments:
- Only reference lines that appear in the provided diff.
- Limit to at most 15 comments total.
- Omit the array (or use []) if there is nothing specific to annotate.
- Do not include anything outside the JSON object.
"""

_BASE_SYSTEM_PROMPT_FILE = """\
You are commit-defender, an AI code reviewer.

Your job is to review the provided file contents and static analysis findings, then
produce a concise, actionable review that helps the developer improve the code.

## Core guidelines
- Be direct and specific. Reference file names and exact line numbers.
- Group related issues together.
- Distinguish between must-fix issues (bugs, security) and suggestions (style, design).
- Do not repeat every lint finding verbatim — synthesize patterns and highlight important ones.
- If the code looks good overall, say so clearly.

## Output format
Respond ONLY with a valid JSON object matching this schema:
{
  "summary": "<narrative review, markdown allowed>",
  "blocking": false,
  "file_comments": [
    {
      "file": "<path relative to repo root, e.g. src/main.py>",
      "line": <1-based line number in the file; 0 for a file-level comment>,
      "comment": "<actionable suggestion, markdown allowed>"
    }
  ]
}

Rules for file_comments:
- You may reference any line number in the file — not limited to changed lines.
- Limit to at most 20 comments total across all files.
- Omit the array (or use []) if there is nothing specific to annotate.
- Do not include anything outside the JSON object.
"""


def _build_system_prompt(
    settings: Settings,
    config: Config,
    skills_text: str,
    project_suffix: str,
    review_mode: str = "diff",
) -> str:
    base = _BASE_SYSTEM_PROMPT_FILE if review_mode == "file" else _BASE_SYSTEM_PROMPT_DIFF
    parts = [base]

    if skills_text:
        parts.append(skills_text)

    # Priority: env var (set by VS Code / hook) > .commit-defender/settings.json > built-in default
    rs = config.review_settings
    severity = settings.cd_severity_level.strip().lower() or rs.severityLevel
    richness = settings.cd_richness_level.strip().lower() or rs.richnessLevel
    locale   = settings.cd_locale.strip().lower()          or rs.locale

    modifier_lines = [
        f"- Severity: {_SEVERITY_PROMPTS.get(severity, _SEVERITY_PROMPTS['moderate'])}",
        f"- Detail level: {_RICHNESS_PROMPTS.get(richness, _RICHNESS_PROMPTS['moderate'])}",
        f"- Language: {_LOCALE_PROMPTS.get(locale, _LOCALE_PROMPTS['en'])}",
    ]
    parts.append("## Review behavior\n\n" + "\n".join(modifier_lines))

    if project_suffix:
        parts.append(f"## Project-specific context\n\n{project_suffix}")

    return "\n\n".join(parts)


# ── JSON parsing ─────────────────────────────────────────────────────────────

def _parse_json(raw: str) -> dict:
    """Parse JSON from the model response, stripping markdown fences if present."""
    # Direct parse — works when response_format=json_object was honoured
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # Extract the first {...} block (handles ```json ... ``` wrapping)
    match = re.search(r'\{[\s\S]*\}', raw)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass

    raise json.JSONDecodeError("No valid JSON found in response", raw, 0)


# ── Agent ─────────────────────────────────────────────────────────────────────

class AIReviewAgent:
    def __init__(self, config: AIReviewConfig, full_config: Config | None = None) -> None:
        self.config = config
        self._full_config = full_config

    def review(
        self,
        diff: str,
        lint_findings: list[LintFinding],
        repo_path: Path | None = None,
        review_mode: str = "diff",  # "diff" | "file"
    ) -> ReviewResult:
        settings = load_settings()

        if not self.config.enabled or settings.skip_ai:
            return ReviewResult.skipped()

        missing = settings.missing_azure_fields()
        if missing:
            return ReviewResult.error(
                f"Missing credentials in ~/.commit-defender.env: {', '.join(missing)}"
            )

        try:
            from openai import (
                AzureOpenAI,
                APIConnectionError,
                APIStatusError,
                APITimeoutError,
                AuthenticationError,
                RateLimitError,
            )
        except ImportError:
            return ReviewResult.error("openai package not installed")

        client = AzureOpenAI(
            api_key=settings.azure_openai_api_key,
            azure_endpoint=settings.azure_openai_endpoint,
            api_version=settings.azure_openai_api_version,
        )

        deployment = settings.azure_openai_deployment or self.config.model

        # Load skill guidelines from the repo's .commit-defender directory
        skills_text = _load_skills(repo_path) if repo_path else ""

        # Use the full Config for review_settings fallback; build a default if absent
        from .config import Config as _Config
        full_cfg = self._full_config or _Config()

        system_content = _build_system_prompt(
            settings,
            full_cfg,
            skills_text,
            self.config.system_prompt_suffix,
            review_mode=review_mode,
        )

        findings_text = "\n".join(str(f) for f in lint_findings) if lint_findings else "None"

        if review_mode == "file":
            content_header = "## File contents"
            content_body = diff or "(no content available)"
        else:
            content_header = "## Staged diff"
            content_body = f"```diff\n{diff or '(no diff available)'}\n```"

        user_message = f"""\
{content_header}

{content_body}

## Static analysis findings

```
{findings_text}
```

Please review the above and respond with the JSON object as instructed.
"""

        try:
            # Try with structured JSON mode first; fall back to plain text if the
            # deployment does not support response_format (older API versions, fine-tuned
            # models, or deployments with content-filtering restrictions).
            try:
                response = client.chat.completions.create(
                    model=deployment,
                    max_completion_tokens=self.config.max_tokens,
                    response_format={"type": "json_object"},
                    messages=[
                        {"role": "system", "content": system_content},
                        {"role": "user", "content": user_message},
                    ],
                )
            except Exception as fmt_err:
                # response_format not supported — retry without it
                _fmt_msg = str(fmt_err).lower()
                if not any(k in _fmt_msg for k in ("response_format", "json_object", "unsupported")):
                    raise  # unrelated error — re-raise
                response = client.chat.completions.create(
                    model=deployment,
                    max_completion_tokens=self.config.max_tokens,
                    messages=[
                        {"role": "system", "content": system_content},
                        {"role": "user", "content": user_message},
                    ],
                )

            raw = response.choices[0].message.content.strip()

            # Extract JSON even when the model wraps it in markdown fences
            data = _parse_json(raw)

            file_comments = [
                FileComment(
                    file=fc["file"],
                    line=int(fc.get("line", 0)),
                    comment=fc["comment"],
                )
                for fc in data.get("file_comments", [])
                if "file" in fc and "comment" in fc
            ]
            return ReviewResult(
                summary=data.get("summary", "(no summary)"),
                blocking=bool(data.get("blocking", False)),
                raw_response=raw,
                file_comments=file_comments,
            )

        except AuthenticationError as e:
            return ReviewResult.error(
                f"Authentication failed — check AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT.\n"
                f"  Detail: {e.message}"
            )
        except APIConnectionError as e:
            return ReviewResult.error(
                f"Could not reach Azure OpenAI endpoint '{settings.azure_openai_endpoint}'.\n"
                f"  Check your network and AZURE_OPENAI_ENDPOINT value.\n"
                f"  Detail: {e}"
            )
        except APITimeoutError:
            return ReviewResult.error(
                "Request to Azure OpenAI timed out. "
                "Check network connectivity or increase max_tokens."
            )
        except RateLimitError as e:
            return ReviewResult.error(
                f"Azure OpenAI rate limit exceeded — try again in a moment.\n"
                f"  Detail: {e.message}"
            )
        except APIStatusError as e:
            return ReviewResult.error(
                f"Azure OpenAI returned HTTP {e.status_code}.\n"
                f"  Detail: {e.message}"
            )
        except json.JSONDecodeError:
            return ReviewResult.error(
                f"Could not parse AI response as JSON.\n"
                f"  Raw response (first 300 chars): {raw[:300] if 'raw' in dir() else '(none)'}"
            )
        except Exception as e:
            return ReviewResult.error(f"Unexpected error: {type(e).__name__}: {e}")
