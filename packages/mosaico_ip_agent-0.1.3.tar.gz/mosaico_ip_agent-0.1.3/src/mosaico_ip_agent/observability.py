"""Shared Langfuse initialization helpers for all agents."""

from __future__ import annotations

from typing import Sequence

from langfuse import Langfuse


def initialize_langfuse(
        *,
        blocked_instrumentation_scopes: Sequence[str] | None = None,
        **client_kwargs: object,
) -> Langfuse | None:
    """Create a Langfuse client with a consistent configuration."""
    scopes = list(blocked_instrumentation_scopes) if blocked_instrumentation_scopes else None

    try:
        client = Langfuse(
            blocked_instrumentation_scopes=scopes,
            **client_kwargs,
        )
    except Exception as e:
        print(f"Langfuse initialization failed: {e}. Agent will start without observability.")
        return None


__all__ = ["initialize_langfuse"]
