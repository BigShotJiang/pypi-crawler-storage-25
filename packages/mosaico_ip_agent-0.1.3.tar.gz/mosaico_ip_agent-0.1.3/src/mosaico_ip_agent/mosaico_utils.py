from collections.abc import Mapping
from typing import TypedDict

MosaicoObservabilityMetadata = TypedDict("MosaicoObservabilityMetadata", {
    "mosaico-root-task-id": str,
    "mosaico-super-task-id": str,
    "mosaico-root-task-name": str,
})

_REQUIRED_KEYS = (
    "mosaico-root-task-id",
    "mosaico-super-task-id",
    "mosaico-root-task-name",
)


def parse_observability_metadata(raw: object) -> MosaicoObservabilityMetadata:
    if not isinstance(raw, Mapping):
        raise TypeError("context.metadata must be a mapping")

    missing = [key for key in _REQUIRED_KEYS if key not in raw]
    if missing:
        raise KeyError(f"missing metadata keys: {', '.join(missing)}")

    root_task_id = raw["mosaico-root-task-id"]
    super_task_id = raw["mosaico-super-task-id"]
    root_task_name = raw["mosaico-root-task-name"]
    if not all(isinstance(value, str) for value in (root_task_id, super_task_id, root_task_name)):
        raise TypeError("metadata values must be strings")
    return {
        "mosaico-root-task-id": root_task_id,
        "mosaico-super-task-id": super_task_id,
        "mosaico-root-task-name": root_task_name,
    }
