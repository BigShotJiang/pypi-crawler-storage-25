import argparse
import enum
import functools
import inspect
import re
from typing import Any, Literal, get_origin, get_args


def _boolean(as_str: str) -> bool:
    if as_str.lower() == 'false':
        return False
    elif as_str.lower() == 'true':
        return True
    raise ValueError()


def autoargs(fn):
    pattern = re.compile(r':param ([A-z_]+): (.*)(?!:param [A-z_]+:)')
    arg_help = {kv[0]: kv[1] for kv in pattern.findall(fn.__doc__ or '')}
    parser = argparse.ArgumentParser()
    parser.description = (fn.__doc__ or '').split(':param')[0] or None
    sig = inspect.signature(fn)
    arg_list = []
    kwarg_list = []
    for n, param in sig.parameters.items():
        addarg_args = []
        addarg_kwargs: dict[str, Any] = {}
        match param.kind:
            case param.POSITIONAL_ONLY:
                addarg_kwargs['nargs'] = 1
                addarg_args.append(param.name)
                arg_list.append(param.name)
            case param.POSITIONAL_OR_KEYWORD:
                if param.default is not param.empty:
                    addarg_args.append(f'--{param.name}')
                    kwarg_list.append(param.name)
                    addarg_kwargs['nargs'] = '?'
                else:
                    addarg_args.append(param.name)
                    addarg_kwargs['nargs'] = 1
                    arg_list.append(param.name)
            case param.VAR_POSITIONAL:
                addarg_kwargs['nargs'] = '+'
                addarg_args.append(param.name)
                arg_list.append(param.name)
            case param.KEYWORD_ONLY:
                addarg_kwargs['nargs'] = 1
                addarg_args.append(f'--{param.name}')
                kwarg_list.append(param.name)
            case param.VAR_KEYWORD:
                addarg_kwargs['nargs'] = '+'
                addarg_args.append(f'--{param.name}')
                kwarg_list.append(param.name)
        if param.name in arg_help:
            addarg_kwargs['help'] = arg_help[param.name]
        if param.annotation is not param.empty:
            if get_origin(param.annotation) is Literal:
                addarg_kwargs['type'] = str
                addarg_kwargs['choices'] = get_args(param.annotation)
            elif param.annotation is bool:
                addarg_kwargs['type'] = _boolean
                addarg_kwargs['choices'] = (True, False)
            elif issubclass(param.annotation, enum.Enum):
                addarg_kwargs['type'] = param.annotation
                addarg_kwargs['choices'] = tuple(param.annotation)
            else:
                addarg_kwargs['type'] = param.annotation
        if param.default is not param.empty:
            addarg_kwargs['default'] = param.default
            addarg_kwargs['nargs'] = '?'
        parser.add_argument(*addarg_args, **addarg_kwargs)

    @functools.wraps(fn)
    def wrapper():
        ns = parser.parse_args()
        args = [getattr(ns, arg)[0] for arg in arg_list]
        kwargs = {kwarg: getattr(ns, kwarg) for kwarg in kwarg_list}

        fn(*args, **kwargs)

    return wrapper


__all__ = ['autoargs']
