from typing import Literal

from mokei.autoargs import autoargs


@autoargs
def main(command: Literal['boilerplate']):
    """The following commands are available:\n\n
    boilerplate"""
    print('Running main')


if __name__ == '__main__':
    main()
