import mokei

app = mokei.Mokei()


@app.get('/')
async def basic():
    pass
