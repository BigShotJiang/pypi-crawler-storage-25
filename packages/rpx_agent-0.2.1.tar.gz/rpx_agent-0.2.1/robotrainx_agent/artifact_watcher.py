"""artifact_watcher.py — Background thread that detects checkpoint files.

Polls watch_dirs every POLL_INTERVAL seconds for files matching
ARTIFACT_EXTENSIONS. When a new or updated checkpoint is found it
calls the provided callback(path, size_bytes, mtime_iso).

No inotify/FSEvents dependency — pure polling, works on Linux/Windows/macOS.
"""
from __future__ import annotations

import hashlib
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, List, Optional, Set

POLL_INTERVAL = 10.0   # seconds between directory scans

ARTIFACT_EXTENSIONS: Set[str] = {
    ".pt", ".pth", ".pkl", ".ckpt", ".zip",
    ".safetensors", ".h5", ".pb", ".onnx", ".jit",
}

ARTIFACT_SKIP_DIRS: Set[str] = {
    "__pycache__", ".git", "node_modules", ".venv", "venv",
}

ArtifactCallback = Callable[[str, int, str, str], None]
# callback(abs_path, size_bytes, mtime_iso, sha256_prefix)


def _file_sha256_prefix(path: str, prefix_bytes: int = 8192) -> str:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            h.update(f.read(prefix_bytes))
    except Exception:
        pass
    return h.hexdigest()[:16]


def _scan_dir(root: Path, seen: dict[str, float], callback: ArtifactCallback) -> None:
    try:
        for entry in os.scandir(root):
            if entry.is_dir(follow_symlinks=False):
                if entry.name not in ARTIFACT_SKIP_DIRS:
                    _scan_dir(Path(entry.path), seen, callback)
            elif entry.is_file(follow_symlinks=False):
                suffix = Path(entry.name).suffix.lower()
                if suffix in ARTIFACT_EXTENSIONS:
                    try:
                        st = entry.stat()
                        prev_mtime = seen.get(entry.path)
                        if prev_mtime is None or st.st_mtime > prev_mtime:
                            seen[entry.path] = st.st_mtime
                            mtime_iso = datetime.fromtimestamp(
                                st.st_mtime, tz=timezone.utc
                            ).isoformat()
                            sha = _file_sha256_prefix(entry.path)
                            callback(entry.path, int(st.st_size), mtime_iso, sha)
                    except OSError:
                        pass
    except PermissionError:
        pass


class ArtifactWatcher:
    """
    Usage::

        def on_artifact(path, size, mtime, sha):
            client.register_artifact(run_id, path, size, mtime, sha)

        w = ArtifactWatcher(watch_dirs=["."], callback=on_artifact)
        w.start()
        # ... training runs ...
        w.stop()
    """

    def __init__(
        self,
        watch_dirs: List[str],
        callback: ArtifactCallback,
        poll_interval: float = POLL_INTERVAL,
    ) -> None:
        self._watch_dirs = [Path(d).resolve() for d in watch_dirs if Path(d).exists()]
        self._callback = callback
        self._interval = poll_interval
        self._seen: dict[str, float] = {}
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="artifact-watcher")
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=self._interval + 2)

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            for d in self._watch_dirs:
                _scan_dir(d, self._seen, self._callback)
            self._stop_event.wait(timeout=self._interval)
