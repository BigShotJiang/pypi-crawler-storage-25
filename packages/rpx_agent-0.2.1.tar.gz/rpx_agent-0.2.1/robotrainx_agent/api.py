from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


class AgentApiError(RuntimeError):
    pass


class AgentApiOfflineError(AgentApiError):
    """Raised when the backend is unreachable (network/connection error)."""
    pass


class AgentApiAuthError(AgentApiError):
    """Raised on 401/403 — bad or missing API key."""
    pass


_RETRY_CODES = {429, 500, 502, 503, 504}
_MAX_RETRIES = 3
_BACKOFF_BASE = 1.5   # seconds


@dataclass
class AgentClient:
    server_url: str
    api_key: Optional[str] = None
    timeout_sec: int = 20
    _offline: bool = field(default=False, repr=False, init=False)

    # ── Low-level HTTP ────────────────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        payload: Optional[Dict[str, Any]] = None,
        retries: int = _MAX_RETRIES,
    ) -> Dict[str, Any]:
        url = f"{self.server_url}{path}"
        body = json.dumps(payload or {}).encode("utf-8") if payload is not None else None
        headers: Dict[str, str] = {}
        if body is not None:
            headers["Content-Type"] = "application/json"
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
            headers["X-API-Key"] = self.api_key

        for attempt in range(retries + 1):
            req = urllib.request.Request(url=url, data=body, headers=headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=self.timeout_sec) as resp:
                    raw = resp.read().decode("utf-8", errors="replace") or "{}"
                    try:
                        data = json.loads(raw)
                    except json.JSONDecodeError:
                        return {}
                self._offline = False
                # Accept both {success, data} envelope and raw dicts
                if isinstance(data, dict) and "success" in data:
                    if not data.get("success", False):
                        raise AgentApiError(
                            str(data.get("error") or f"Request failed for {path}")
                        )
                    return data.get("data") or {}
                return data

            except urllib.error.HTTPError as e:
                code = e.code
                if code in (401, 403):
                    raise AgentApiAuthError(
                        f"Authentication failed (HTTP {code}). "
                        "Set ROBOTRAINX_API_KEY or run: robotrainx-agent login --api-key <KEY>"
                    ) from e
                if code in _RETRY_CODES and attempt < retries:
                    time.sleep(_BACKOFF_BASE * (2 ** attempt))
                    continue
                detail = e.read().decode("utf-8", errors="replace")[:200]
                raise AgentApiError(f"HTTP {code} on {path}: {detail}") from e

            except (urllib.error.URLError, OSError, TimeoutError) as e:
                if attempt < retries:
                    time.sleep(_BACKOFF_BASE * (2 ** attempt))
                    continue
                self._offline = True
                raise AgentApiOfflineError(f"Backend unreachable ({path}): {e}") from e

        raise AgentApiError(f"Max retries exceeded for {path}")

    def _post_json(self, path: str, payload: Dict[str, Any], retries: int = _MAX_RETRIES) -> Dict[str, Any]:
        return self._request("POST", path, payload, retries=retries)

    def is_reachable(self) -> bool:
        try:
            self._request("GET", "/health", retries=1)
            return True
        except Exception:
            return False

    # ── Run lifecycle ─────────────────────────────────────────────────────────

    def start_run(
        self,
        task: str,
        label: Optional[str] = None,
        platform: Optional[str] = None,
        run_id: Optional[str] = None,
        tags: Optional[str] = None,
        num_envs: Optional[int] = None,
        max_iterations: Optional[int] = None,
        config: Optional[Dict[str, Any]] = None,
        env_snapshot: Optional[Dict[str, Any]] = None,
    ) -> str:
        payload: Dict[str, Any] = {
            "task": task,
            "source": "robotrainx-agent",
        }
        if label:
            payload["label"] = label
        if platform:
            payload["platform"] = platform
        if run_id:
            payload["run_id"] = run_id
        if tags:
            payload["tags"] = tags
        if num_envs is not None:
            payload["num_envs"] = int(num_envs)
        if max_iterations is not None:
            payload["max_iterations"] = int(max_iterations)
        if config:
            payload["config"] = config
        if env_snapshot:
            payload["env_snapshot"] = env_snapshot
        out = self._post_json("/api/v1/runs/start", payload)
        rid = out.get("run_id")
        if not rid:
            raise AgentApiError("Backend did not return run_id")
        return str(rid)

    def send_logs_batch(self, run_id: str, events: List[Dict[str, Any]]) -> int:
        try:
            out = self._post_json(
                "/api/v1/runs/logs/batch",
                {"run_id": run_id, "events": events},
            )
            return int(out.get("appended", len(events)))
        except AgentApiOfflineError:
            raise
        except AgentApiError:
            raise

    def end_run(self, run_id: str, status: str, summary: Optional[Dict[str, Any]] = None) -> None:
        payload: Dict[str, Any] = {"run_id": run_id, "status": status}
        if summary:
            payload["summary"] = summary
        self._post_json("/api/v1/runs/end", payload, retries=5)

    # ── Structured metrics ────────────────────────────────────────────────────

    def send_metric(self, run_id: str, metric: Dict[str, Any]) -> None:
        """POST one structured metric record to /api/v1/ingest-metrics."""
        payload = {"run_id": run_id, **metric}
        # iteration must be an integer
        if "iteration" in payload:
            try:
                payload["iteration"] = int(payload["iteration"])
            except (TypeError, ValueError):
                payload["iteration"] = 0
        self._post_json("/api/v1/ingest-metrics", payload, retries=2)

    # ── Heartbeat ─────────────────────────────────────────────────────────────

    def send_heartbeat(self, run_id: str) -> None:
        """POST to run console endpoint to signal the run is still alive."""
        try:
            self._post_json(
                f"/api/v1/runs/{run_id}/console",
                {"message": "__heartbeat__", "stream": "system"},
                retries=1,
            )
        except Exception:
            pass  # heartbeat is best-effort

    # ── System telemetry ──────────────────────────────────────────────────────

    def send_system_telemetry(self, run_id: str, stats: Dict[str, Any], iteration: int) -> None:
        """Piggyback system stats onto an ingest-metrics call."""
        if not stats:
            return
        try:
            self.send_metric(run_id, {"iteration": iteration, **stats})
        except Exception:
            pass  # system telemetry is best-effort

    # ── Artifact registration ─────────────────────────────────────────────────

    def register_artifact(
        self,
        run_id: str,
        path: str,
        size_bytes: int,
        mtime_iso: str,
        sha256_prefix: str,
    ) -> None:
        """Register a discovered checkpoint file with the backend."""
        try:
            self._post_json(
                "/api/v1/artifacts",
                {
                    "run_id": run_id,
                    "name": os.path.basename(path),
                    "path": path,
                    "size_bytes": size_bytes,
                    "recorded_at": mtime_iso,
                    "sha256_prefix": sha256_prefix,
                    "artifact_type": "checkpoint",
                    "confirmed": True,
                },
                retries=2,
            )
        except Exception:
            pass  # artifact registration is best-effort
