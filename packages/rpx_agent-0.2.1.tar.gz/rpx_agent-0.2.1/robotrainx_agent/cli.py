from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from .api import AgentApiAuthError, AgentApiError, AgentApiOfflineError, AgentClient
from .config import (
    DEFAULT_SERVER_URL,
    load_config,
    load_project_config,
    resolve_api_key,
    resolve_server_url,
    save_config,
)
from .runner import run_and_stream


def _client(args: argparse.Namespace) -> AgentClient:
    server_url = resolve_server_url(getattr(args, "server_url", None))
    api_key = resolve_api_key(getattr(args, "api_key", None))
    return AgentClient(server_url=server_url, api_key=api_key)


def _auto_task_from_cmd(cmd: List[str]) -> str:
    """Infer a task label from the training command if --task not given."""
    for token in cmd:
        if token.endswith(".py") and not token.startswith("-"):
            return Path(token).stem
    return "robot-training"


def _strip_double_dash(cmd: List[str]) -> List[str]:
    """Remove leading '--' separator that argparse captures as part of REMAINDER."""
    if cmd and cmd[0] == "--":
        return cmd[1:]
    return cmd


# ── Commands ──────────────────────────────────────────────────────────────────

def cmd_login(args: argparse.Namespace) -> int:
    cfg = load_config()
    if getattr(args, "api_key", None):
        cfg["api_key"] = args.api_key.strip()
    if getattr(args, "server_url", None):
        cfg["server_url"] = args.server_url.rstrip("/")
    save_config(cfg)
    server = cfg.get("server_url", DEFAULT_SERVER_URL)
    print(f"[roboprotx] Credentials saved.")
    print(f"            Backend : {server}")
    print(f"            API key : {'(set)' if cfg.get('api_key') else '(not set)'}")

    # Quick connectivity test
    client = AgentClient(
        server_url=server,
        api_key=cfg.get("api_key"),
    )
    if client.is_reachable():
        print("[roboprotx] Backend reachable ✓")
    else:
        print("[roboprotx] WARNING: Backend not reachable. Check server URL.", file=sys.stderr)
    return 0


def cmd_init(args: argparse.Namespace) -> int:
    """Interactive project setup — creates roboprotx.yaml in the current directory."""
    cwd = Path.cwd()
    config_path = cwd / "roboprotx.yaml"

    print("[roboprotx] Initialising project in:", cwd)

    # Detect existing project name
    project_name = cwd.name

    # Detect simulator
    sim = "custom"
    for f in cwd.rglob("*.py"):
        try:
            txt = f.read_text(errors="ignore")[:2000]
        except Exception:
            continue
        if "isaaclab" in txt.lower() or "rsl_rl" in txt.lower():
            sim = "isaaclab"
            break
        if "mujoco" in txt.lower() or "dm_control" in txt.lower():
            sim = "mujoco"
            break
        if "stable_baselines3" in txt.lower():
            sim = "mujoco"
            break
        if "gazebo" in txt.lower():
            sim = "gazebo"
            break

    # Detect training entry point
    train_script = None
    for candidate in ["train.py", "train_headless.py", "run.py", "main.py"]:
        if (cwd / candidate).exists():
            train_script = candidate
            break

    server_url = resolve_server_url(None)
    api_key = resolve_api_key(None)

    lines = [
        f"project: {project_name}",
        f"simulator: {sim}",
        f"server_url: {server_url}",
        "",
        "# Uncomment and set if not using ROBOTRAINX_API_KEY env var:",
        "# api_key: YOUR_KEY_HERE",
        "",
        "# Directories to watch for checkpoint files:",
        "watch_dirs:",
        "  - .",
        "",
    ]
    if train_script:
        lines += [
            "# Detected training entry point:",
            f"# im run -- python {train_script}",
            "",
        ]

    config_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"[roboprotx] Created {config_path}")
    print(f"            Simulator : {sim}")
    if train_script:
        print(f"            Train cmd  : python {train_script}")
    print()
    print("Next steps:")
    print(f"  1. Set your API key:")
    print(f"       export ROBOTRAINX_API_KEY=<your-key>")
    print(f"     or: rpx-agent login --api-key <your-key>")
    print(f"  2. Start training:")
    if train_script:
        print(f"       rpx-agent run -- python {train_script}")
    else:
        print(f"       rpx-agent run -- python your_train_script.py")
    print(f"  3. View dashboard at: {server_url}")
    return 0


def cmd_start(args: argparse.Namespace) -> int:
    client = _client(args)
    cfg: Optional[Dict[str, Any]] = None
    if args.config_json:
        cfg = json.loads(args.config_json)
    run_id = client.start_run(
        task=args.task,
        label=args.label,
        platform=args.platform,
        run_id=args.run_id,
        tags=args.tags,
        num_envs=args.num_envs,
        max_iterations=args.max_iterations,
        config=cfg,
    )
    print(run_id)
    return 0


def cmd_logs(args: argparse.Namespace) -> int:
    client = _client(args)
    events = [{
        "message": args.message,
        "stream": args.stream,
        "seq": args.seq,
        "ts": args.ts,
    }]
    appended = client.send_logs_batch(args.run_id, events)
    print(f"appended={appended}")
    return 0


def cmd_end(args: argparse.Namespace) -> int:
    client = _client(args)
    client.end_run(args.run_id, args.status)
    print(f"ended run_id={args.run_id} status={args.status}")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    raw_cmd = _strip_double_dash(list(args.command or []))
    if not raw_cmd:
        print(
            "[roboprotx] ERROR: No command provided.\n"
            "  Usage: rpx-agent run -- python train.py [args...]\n"
            "         rpx-agent run --task my-task -- python train.py\n",
            file=sys.stderr,
        )
        return 2

    # Auto-detect task if not supplied
    task = getattr(args, "task", None) or _auto_task_from_cmd(raw_cmd)

    # Merge project config for watch_dirs
    proj_cfg = load_project_config()
    watch_dirs_cfg: List[str] = proj_cfg.get("watch_dirs", [])
    watch_dirs_arg: List[str] = list(getattr(args, "watch_dirs", None) or [])
    watch_dirs = watch_dirs_arg or watch_dirs_cfg or [os.getcwd()]

    client = _client(args)

    # Warn if no API key set and using production server
    api_key = resolve_api_key(None)
    server = resolve_server_url(None)
    if not api_key and "localhost" not in server and "127.0.0.1" not in server:
        print(
            "[roboprotx] WARNING: No API key set. "
            "Runs may be rejected by the server.\n"
            "  Fix: export ROBOTRAINX_API_KEY=<key>  "
            "or: rpx-agent login --api-key <key>",
            file=sys.stderr,
        )

    return run_and_stream(
        client=client,
        cmd=raw_cmd,
        task=task,
        label=getattr(args, "label", None),
        platform_hint=getattr(args, "platform", None),
        run_id=getattr(args, "run_id", None),
        tags=getattr(args, "tags", None),
        watch_dirs=watch_dirs,
        batch_size=getattr(args, "batch_size", 80),
        flush_interval_sec=getattr(args, "flush_interval", 1.5),
        enable_metrics=not getattr(args, "no_metrics", False),
        enable_sysinfo=not getattr(args, "no_sysinfo", False),
        enable_artifacts=not getattr(args, "no_artifacts", False),
    )


# ── Parser ────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rpx-agent",
        description="rpx-agent — wrap any robot training command with full end-to-end analytics.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  rpx-agent run -- python train.py --num-envs 1024\n"
            "  rpx-agent run --task anymal-locomotion --platform isaaclab -- python train.py\n"
            "  rpx-agent login --api-key abc123\n"
            "  rpx-agent init\n"
        ),
    )
    parser.add_argument("--server-url", default=None,
                        help="Backend URL (default: ROBOTRAINX_SERVER_URL or robosynx.com)")
    parser.add_argument("--api-key", default=None,
                        help="API key (default: ROBOTRAINX_API_KEY env var)")

    sub = parser.add_subparsers(dest="command_name", required=True)

    # ── login ─────────────────────────────────────────────────────────────────
    p_login = sub.add_parser("login", help="Save API key / server URL and test connectivity")
    p_login.add_argument("--api-key", required=True, help="Your RoboProtX API key")
    p_login.add_argument("--server-url", default=None, help="Backend URL (optional)")
    p_login.set_defaults(func=cmd_login)

    # ── init ──────────────────────────────────────────────────────────────────
    p_init = sub.add_parser("init", help="Initialise a roboprotx.yaml in the current directory")
    p_init.set_defaults(func=cmd_init)

    # ── start ─────────────────────────────────────────────────────────────────
    p_start = sub.add_parser("start", help="Manually start a run record")
    p_start.add_argument("--task", required=True)
    p_start.add_argument("--label")
    p_start.add_argument("--platform")
    p_start.add_argument("--run-id")
    p_start.add_argument("--tags")
    p_start.add_argument("--num-envs", type=int)
    p_start.add_argument("--max-iterations", type=int)
    p_start.add_argument("--config-json", help="JSON string of training config")
    p_start.set_defaults(func=cmd_start)

    # ── logs ──────────────────────────────────────────────────────────────────
    p_logs = sub.add_parser("logs", help="Send a single log event")
    p_logs.add_argument("--run-id", required=True)
    p_logs.add_argument("--message", required=True)
    p_logs.add_argument("--stream", default="stdout", choices=["stdout", "stderr"])
    p_logs.add_argument("--seq", type=int, default=1)
    p_logs.add_argument("--ts", default=None)
    p_logs.set_defaults(func=cmd_logs)

    # ── end ───────────────────────────────────────────────────────────────────
    p_end = sub.add_parser("end", help="Manually end a run")
    p_end.add_argument("--run-id", required=True)
    p_end.add_argument("--status", default="success",
                       choices=["success", "failed", "cancelled"])
    p_end.set_defaults(func=cmd_end)

    # ── run ───────────────────────────────────────────────────────────────────
    p_run = sub.add_parser(
        "run",
        help="Wrap a training command with full telemetry (main command)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Example: rpx-agent run -- python train.py --num-envs 1024",
    )
    p_run.add_argument("--task", default=None,
                       help="Task/experiment name (auto-detected from script name if omitted)")
    p_run.add_argument("--label", default=None, help="Human-readable run label")
    p_run.add_argument("--platform", default=None,
                       help="Simulator: isaaclab | mujoco | gazebo | custom (auto-detected if omitted)")
    p_run.add_argument("--run-id", default=None, help="Explicit run ID (auto-generated if omitted)")
    p_run.add_argument("--tags", default=None, help="Comma-separated tags")
    p_run.add_argument("--watch-dir", dest="watch_dirs", action="append", default=None,
                       metavar="DIR", help="Extra directories to watch for checkpoints (repeatable)")
    p_run.add_argument("--batch-size", type=int, default=80,
                       help="Log events per HTTP batch (default: 80)")
    p_run.add_argument("--flush-interval", type=float, default=1.5,
                       help="Seconds between log flushes (default: 1.5)")
    p_run.add_argument("--no-metrics", action="store_true",
                       help="Disable automatic metric parsing from stdout")
    p_run.add_argument("--no-sysinfo", action="store_true",
                       help="Disable GPU/CPU system telemetry collection")
    p_run.add_argument("--no-artifacts", action="store_true",
                       help="Disable checkpoint file detection")
    p_run.add_argument("command", nargs=argparse.REMAINDER,
                       help="Command to run (after --)")
    p_run.set_defaults(func=cmd_run)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        code = int(args.func(args))
    except AgentApiAuthError as e:
        print(f"\n[roboprotx] Authentication error: {e}", file=sys.stderr)
        code = 1
    except AgentApiOfflineError as e:
        print(f"\n[roboprotx] Backend offline: {e}", file=sys.stderr)
        code = 1
    except AgentApiError as e:
        print(f"\n[roboprotx] API error: {e}", file=sys.stderr)
        code = 1
    except json.JSONDecodeError as e:
        print(f"[roboprotx] Invalid JSON: {e}", file=sys.stderr)
        code = 2
    except KeyboardInterrupt:
        code = 130
    except Exception as e:
        print(f"[roboprotx] Unexpected error: {e}", file=sys.stderr)
        code = 1
    raise SystemExit(code)


if __name__ == "__main__":
    main()
