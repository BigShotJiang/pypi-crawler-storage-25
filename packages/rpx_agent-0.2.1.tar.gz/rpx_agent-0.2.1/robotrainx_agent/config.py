from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

DEFAULT_SERVER_URL = "https://api.robosynx.com"
CONFIG_DIR = Path.home() / ".robotrainx-agent"
CONFIG_FILE = CONFIG_DIR / "config.json"
PROJECT_CONFIG_NAMES = ("roboprotx.yaml", "roboprotx.yml", ".roboprotx.yaml")


# ── Global config (~/.robotrainx-agent/config.json) ──────────────────────────

def load_config() -> Dict[str, Any]:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg: Dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


# ── Project config (roboprotx.yaml, searched up from cwd) ────────────────────

def _find_project_config() -> Optional[Path]:
    """Search from cwd up to filesystem root for a roboprotx.yaml file."""
    current = Path.cwd()
    for _ in range(10):  # max 10 levels up
        for name in PROJECT_CONFIG_NAMES:
            candidate = current / name
            if candidate.exists():
                return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def load_project_config() -> Dict[str, Any]:
    """
    Load roboprotx.yaml from cwd (or parent directories).
    Returns empty dict if not found. Supports a minimal YAML-like format
    without requiring PyYAML as a dependency (key: value lines only).
    """
    path = _find_project_config()
    if not path:
        return {}

    try:
        # Try real YAML first (PyYAML optional)
        try:
            import yaml  # type: ignore
            with path.open(encoding="utf-8") as f:
                data = yaml.safe_load(f)
            return data if isinstance(data, dict) else {}
        except ImportError:
            pass

        # Fallback: minimal key: value parser (handles simple roboprotx.yaml)
        result: Dict[str, Any] = {}
        current_list_key: Optional[str] = None
        for line in path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                current_list_key = None
                continue
            # List item under a list key
            if stripped.startswith("- ") and current_list_key:
                val = stripped[2:].strip()
                result.setdefault(current_list_key, [])
                if isinstance(result[current_list_key], list):
                    result[current_list_key].append(val)
                continue
            if ":" in stripped:
                key, _, val = stripped.partition(":")
                key = key.strip()
                val = val.strip()
                if val == "":
                    # Could be start of a list block
                    current_list_key = key
                    result[key] = []
                else:
                    current_list_key = None
                    result[key] = val
        return result
    except Exception:
        return {}


# ── Resolution helpers ────────────────────────────────────────────────────────

def resolve_server_url(cli_value: Optional[str]) -> str:
    if cli_value:
        return cli_value.rstrip("/")
    # env vars (both names accepted)
    for env_name in ("ROBOTRAINX_SERVER_URL", "IM_SERVER_URL", "ROBOPROTX_SERVER_URL"):
        env = os.getenv(env_name)
        if env:
            return env.rstrip("/")
    # project config
    proj = load_project_config()
    if proj.get("server_url"):
        return str(proj["server_url"]).rstrip("/")
    # global config
    cfg = load_config()
    return str(cfg.get("server_url", DEFAULT_SERVER_URL)).rstrip("/")


def resolve_api_key(cli_value: Optional[str]) -> Optional[str]:
    if cli_value:
        return cli_value.strip()
    # env vars (multiple aliases)
    for env_name in ("ROBOTRAINX_API_KEY", "IM_API_KEY", "ROBOPROTX_API_KEY"):
        env = os.getenv(env_name)
        if env:
            return env.strip()
    # project config
    proj = load_project_config()
    if proj.get("api_key"):
        return str(proj["api_key"]).strip()
    # global config
    cfg = load_config()
    key = cfg.get("api_key")
    return str(key).strip() if key else None
