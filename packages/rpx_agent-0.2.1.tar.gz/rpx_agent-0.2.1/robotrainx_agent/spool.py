"""spool.py — Disk-based offline event buffer with replay.

When the backend is unreachable, events are written to a JSONL file under
~/.robotrainx-agent/spool/<run_id>.jsonl and replayed on the next
successful network connection.

Size is capped at MAX_SPOOL_BYTES. Oldest entries are dropped when full.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

MAX_SPOOL_BYTES = 50 * 1024 * 1024   # 50 MB per run
SPOOL_DIR = Path.home() / ".robotrainx-agent" / "spool"


def _spool_path(run_id: str) -> Path:
    SPOOL_DIR.mkdir(parents=True, exist_ok=True)
    safe = run_id.replace("/", "_").replace("\\", "_")[:64]
    return SPOOL_DIR / f"{safe}.jsonl"


def write_events(run_id: str, events: List[Dict[str, Any]]) -> None:
    """Append events to the spool file, enforcing size cap."""
    path = _spool_path(run_id)
    lines = [json.dumps(e) + "\n" for e in events]
    blob = "".join(lines)

    # Rotate if over cap
    try:
        current_size = path.stat().st_size if path.exists() else 0
        if current_size + len(blob.encode()) > MAX_SPOOL_BYTES:
            # Trim oldest ~20% of file
            existing = path.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
            trim_count = max(1, len(existing) // 5)
            path.write_text("".join(existing[trim_count:]), encoding="utf-8")
    except Exception:
        pass

    try:
        with path.open("a", encoding="utf-8") as f:
            f.write(blob)
    except Exception:
        pass


def write_metric(run_id: str, metric: Dict[str, Any]) -> None:
    write_events(run_id, [{"_type": "metric", **metric}])


def read_and_clear(run_id: str) -> List[Dict[str, Any]]:
    """Read all spooled items and remove the file."""
    path = _spool_path(run_id)
    if not path.exists():
        return []
    records: List[Dict[str, Any]] = []
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if line:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
        path.unlink(missing_ok=True)
    except Exception:
        pass
    return records


def has_spooled(run_id: str) -> bool:
    p = _spool_path(run_id)
    return p.exists() and p.stat().st_size > 0


def spool_size_bytes(run_id: str) -> int:
    p = _spool_path(run_id)
    try:
        return p.stat().st_size if p.exists() else 0
    except Exception:
        return 0
