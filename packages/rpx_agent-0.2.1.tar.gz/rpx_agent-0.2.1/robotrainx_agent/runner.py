"""runner.py — Subprocess wrapper with full telemetry pipeline.

Features
--------
* Streams stdout/stderr to backend in real-time (batched)
* Parses RL training log formats (SB3, RSL-RL, Isaac Lab, CleanRL, generic)
  and sends structured metrics to /api/v1/ingest-metrics automatically
* Heartbeat thread every 30 s keeps the run marked alive
* System telemetry (GPU/CPU/RAM) every 60 s
* Artifact watcher detects checkpoint files and registers them
* Disk spool buffers events when backend is temporarily unreachable;
  replayed on reconnect
* Proper process-group kill on SIGINT/SIGTERM (no orphan GPU processes)
* Binary-safe stdout reading with encoding error replacement
* Long-line truncation (>8 KB) to avoid payload bloat
* Auto-detects simulator from stdout patterns
"""
from __future__ import annotations

import os
import platform
import queue
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .api import AgentApiOfflineError, AgentClient
from .artifact_watcher import ArtifactWatcher
from .metrics_parser import MetricsParser
from .spool import has_spooled, read_and_clear, write_events, write_metric
from .sysinfo import env_snapshot, poll_system_metrics

# ── Constants ─────────────────────────────────────────────────────────────────

HEARTBEAT_INTERVAL = 30.0      # seconds
SYSINFO_INTERVAL = 60.0        # seconds
MAX_LINE_BYTES = 8 * 1024      # truncate very long lines
LOG_BATCH_SIZE = 80            # log events per HTTP call
LOG_FLUSH_INTERVAL = 1.5       # seconds between log flushes
SPOOL_REPLAY_INTERVAL = 30.0   # seconds between spool replay attempts


# ── Helpers ───────────────────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _truncate(line: str) -> str:
    if len(line.encode("utf-8", errors="replace")) > MAX_LINE_BYTES:
        return line[:MAX_LINE_BYTES] + " ...[truncated]\n"
    return line


def _pump_stream(stream, name: str, q: "queue.Queue[Tuple[str, str]]") -> None:
    """Read lines from a stream and push to queue. Handles binary/encoding errors."""
    try:
        while True:
            line = stream.readline()
            if not line:
                break
            q.put((name, line))
    except Exception:
        pass
    finally:
        try:
            stream.close()
        except Exception:
            pass


def _kill_process_tree(proc: subprocess.Popen) -> None:
    """Kill process and all its children. Works on Linux and Windows."""
    try:
        if platform.system() == "Windows":
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                capture_output=True, timeout=5,
            )
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            time.sleep(0.5)
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except ProcessLookupError:
                pass
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass


def _detect_platform_from_logs(lines: List[str]) -> Optional[str]:
    """Heuristically detect simulator from first stdout lines."""
    combined = " ".join(lines[:20]).lower()
    if "isaaclab" in combined or "isaac lab" in combined or "rsl_rl" in combined:
        return "isaaclab"
    if "mujoco" in combined or "dm_control" in combined:
        return "mujoco"
    if "gazebo" in combined or "ros2" in combined:
        return "gazebo"
    if "stable_baselines3" in combined or "stable-baselines3" in combined:
        return "sb3"
    return None


# ── Background threads ────────────────────────────────────────────────────────

def _heartbeat_loop(
    client: AgentClient,
    run_id: str,
    stop: threading.Event,
    interval: float,
) -> None:
    while not stop.wait(timeout=interval):
        client.send_heartbeat(run_id)


def _sysinfo_loop(
    client: AgentClient,
    run_id: str,
    stop: threading.Event,
    interval: float,
    iteration_ref: List[int],
) -> None:
    while not stop.wait(timeout=interval):
        stats = poll_system_metrics()
        if stats:
            client.send_system_telemetry(run_id, stats, iteration_ref[0])


def _spool_replay_loop(
    client: AgentClient,
    run_id: str,
    stop: threading.Event,
    interval: float,
) -> None:
    """Periodically attempt to replay spooled events when back online."""
    while not stop.wait(timeout=interval):
        if not has_spooled(run_id):
            continue
        if not client.is_reachable():
            continue
        records = read_and_clear(run_id)
        if not records:
            continue
        log_events = [r for r in records if r.get("_type") != "metric"]
        metric_records = [r for r in records if r.get("_type") == "metric"]
        if log_events:
            try:
                client.send_logs_batch(run_id, log_events)
            except Exception:
                write_events(run_id, log_events)
        for m in metric_records:
            m.pop("_type", None)
            try:
                client.send_metric(run_id, m)
            except Exception:
                write_metric(run_id, m)


# ── Main entry point ──────────────────────────────────────────────────────────

def run_and_stream(
    client: AgentClient,
    cmd: Sequence[str],
    task: str,
    label: Optional[str] = None,
    platform_hint: Optional[str] = None,
    run_id: Optional[str] = None,
    tags: Optional[str] = None,
    watch_dirs: Optional[List[str]] = None,
    batch_size: int = LOG_BATCH_SIZE,
    flush_interval_sec: float = LOG_FLUSH_INTERVAL,
    enable_metrics: bool = True,
    enable_sysinfo: bool = True,
    enable_artifacts: bool = True,
) -> int:
    """
    Wrap ``cmd`` as a subprocess, stream all output to the backend, and
    collect end-to-end robotics training analytics.

    Returns the process exit code (130 = KeyboardInterrupt/cancelled).
    """

    # ── Pre-flight: capture environment snapshot ──────────────────────────────
    snap: Dict[str, Any] = {}
    try:
        snap = env_snapshot()
    except Exception:
        pass

    # Auto-detect platform from snapshot if not provided
    detected_platform = platform_hint
    if not detected_platform and snap.get("detected_simulators"):
        sims = snap["detected_simulators"]
        if "isaaclab" in sims:
            detected_platform = "isaaclab"
        elif "mujoco" in sims:
            detected_platform = "mujoco"

    # ── Start run on backend ──────────────────────────────────────────────────
    rid: Optional[str] = run_id
    offline_start = False
    try:
        rid = client.start_run(
            task=task,
            label=label,
            platform=detected_platform,
            run_id=run_id,
            tags=tags,
            env_snapshot=snap if snap else None,
        )
        print(f"\033[32m[roboprotx]\033[0m run started → {client.server_url}/runs/{rid}")
    except AgentApiOfflineError as e:
        rid = run_id or f"offline-{int(time.time())}"
        offline_start = True
        print(f"\033[33m[roboprotx] WARNING:\033[0m Backend unreachable. "
              f"Running offline, events spooled to disk. run_id={rid}", file=sys.stderr)
        print(f"            Error: {e}", file=sys.stderr)
    except Exception as e:
        print(f"\033[31m[roboprotx] ERROR:\033[0m Could not start run: {e}", file=sys.stderr)
        print("[roboprotx] Continuing without backend tracking.", file=sys.stderr)
        rid = run_id or f"error-{int(time.time())}"
        offline_start = True

    assert rid is not None

    # ── Launch subprocess ─────────────────────────────────────────────────────
    cmd_list = [str(c) for c in cmd]
    try:
        popen_kwargs: Dict[str, Any] = {
            "stdout": subprocess.PIPE,
            "stderr": subprocess.PIPE,
            "bufsize": 1,
        }
        if platform.system() != "Windows":
            popen_kwargs["start_new_session"] = True  # enables process group kill

        # Force UTF-8; replace undecodable bytes rather than crashing
        popen_kwargs["text"] = False  # read bytes, decode manually for safety

        proc = subprocess.Popen(cmd_list, **popen_kwargs)
    except FileNotFoundError:
        cmd0 = cmd_list[0] if cmd_list else "<empty>"
        print(f"\033[31m[roboprotx] ERROR:\033[0m Command not found: '{cmd0}'", file=sys.stderr)
        print(f"            Make sure '{cmd0}' is on PATH and your environment is activated.",
              file=sys.stderr)
        if not offline_start:
            try:
                client.end_run(rid, "failed")
            except Exception:
                pass
        return 127
    except PermissionError as e:
        print(f"\033[31m[roboprotx] ERROR:\033[0m Permission denied: {e}", file=sys.stderr)
        return 126

    # ── Start background threads ──────────────────────────────────────────────
    stop_event = threading.Event()
    iteration_ref: List[int] = [0]   # mutable reference for sysinfo thread

    t_heartbeat = threading.Thread(
        target=_heartbeat_loop,
        args=(client, rid, stop_event, HEARTBEAT_INTERVAL),
        daemon=True, name="hb",
    )
    t_heartbeat.start()

    if enable_sysinfo:
        t_sysinfo = threading.Thread(
            target=_sysinfo_loop,
            args=(client, rid, stop_event, SYSINFO_INTERVAL, iteration_ref),
            daemon=True, name="sysinfo",
        )
        t_sysinfo.start()

    t_spool = threading.Thread(
        target=_spool_replay_loop,
        args=(client, rid, stop_event, SPOOL_REPLAY_INTERVAL),
        daemon=True, name="spool-replay",
    )
    t_spool.start()

    # Artifact watcher
    artifact_watcher: Optional[ArtifactWatcher] = None
    if enable_artifacts:
        dirs = list(watch_dirs or []) or [os.getcwd()]

        def _on_artifact(path: str, size: int, mtime: str, sha: str) -> None:
            print(f"\033[36m[roboprotx]\033[0m checkpoint detected: {os.path.basename(path)} ({size // 1024} KB)")
            client.register_artifact(rid, path, size, mtime, sha)  # type: ignore[arg-type]

        artifact_watcher = ArtifactWatcher(watch_dirs=dirs, callback=_on_artifact)
        artifact_watcher.start()

    # ── stdout/stderr pump threads ────────────────────────────────────────────
    q: queue.Queue[Tuple[str, bytes]] = queue.Queue()
    t_out = threading.Thread(
        target=_pump_stream, args=(proc.stdout, "stdout", q), daemon=True
    )
    t_err = threading.Thread(
        target=_pump_stream, args=(proc.stderr, "stderr", q), daemon=True
    )
    t_out.start()
    t_err.start()

    # ── Main loop ─────────────────────────────────────────────────────────────
    metrics_parser = MetricsParser() if enable_metrics else None
    seq = 0
    last_flush = time.time()
    pending_logs: List[Dict[str, Any]] = []
    first_lines: List[str] = []
    platform_detected = False
    total_log_lines = 0
    total_metrics_sent = 0

    def _flush_logs() -> None:
        nonlocal pending_logs, last_flush
        if not pending_logs:
            return
        batch = pending_logs[:]
        pending_logs = []
        last_flush = time.time()
        try:
            client.send_logs_batch(rid, batch)  # type: ignore[arg-type]
        except AgentApiOfflineError:
            write_events(rid, batch)  # type: ignore[arg-type]
        except Exception as e:
            print(f"\033[33m[roboprotx] log flush error:\033[0m {e}", file=sys.stderr)
            write_events(rid, batch)  # type: ignore[arg-type]

    def _send_metric(metric: Dict[str, Any]) -> None:
        nonlocal total_metrics_sent
        iteration_ref[0] = int(metric.get("iteration", iteration_ref[0]))
        try:
            client.send_metric(rid, metric)  # type: ignore[arg-type]
            total_metrics_sent += 1
        except AgentApiOfflineError:
            write_metric(rid, metric)  # type: ignore[arg-type]
        except Exception:
            pass

    try:
        while True:
            done = proc.poll() is not None

            try:
                stream_name, raw_bytes = q.get(timeout=0.2)
                # Decode safely
                line = raw_bytes.decode("utf-8", errors="replace") if isinstance(raw_bytes, bytes) else raw_bytes
                line = _truncate(line)

                # Echo to our own stdout
                sys.stdout.write(line)
                sys.stdout.flush()

                total_log_lines += 1
                seq += 1

                # Collect first lines for platform auto-detection
                if not platform_detected and len(first_lines) < 20:
                    first_lines.append(line)
                    if len(first_lines) == 20:
                        detected = _detect_platform_from_logs(first_lines)
                        if detected and not detected_platform:
                            print(f"\033[36m[roboprotx]\033[0m auto-detected simulator: {detected}")
                        platform_detected = True

                pending_logs.append({
                    "message": line,
                    "stream": stream_name,
                    "ts": _now_iso(),
                    "seq": seq,
                })

                # Parse metrics from this line
                if metrics_parser is not None:
                    try:
                        metric = metrics_parser.feed_line(line)
                        if metric:
                            _send_metric(metric)
                    except Exception:
                        pass

            except queue.Empty:
                pass

            # Flush log batch on size or time
            now = time.time()
            if len(pending_logs) >= batch_size or (
                pending_logs and (now - last_flush) >= flush_interval_sec
            ):
                _flush_logs()

            if done and q.empty():
                break

        # ── Process finished ──────────────────────────────────────────────────
        _flush_logs()

        # Flush any pending parsed metrics
        if metrics_parser is not None:
            try:
                final_metric = metrics_parser.flush_pending()
                if final_metric:
                    _send_metric(final_metric)
            except Exception:
                pass

        code = int(proc.returncode or 0)
        final_status = "success" if code == 0 else "failed"
        summary = {
            "exit_code": code,
            "total_log_lines": total_log_lines,
            "total_metrics_sent": total_metrics_sent,
        }
        try:
            client.end_run(rid, final_status, summary=summary)
        except AgentApiOfflineError:
            write_events(rid, [{"_type": "end", "status": final_status, **summary}])

        status_color = "\033[32m" if code == 0 else "\033[31m"
        print(
            f"{status_color}[roboprotx]\033[0m run finished → "
            f"status={final_status} exit={code} "
            f"logs={total_log_lines} metrics={total_metrics_sent}"
        )
        return code

    except KeyboardInterrupt:
        print("\n\033[33m[roboprotx]\033[0m Interrupted — terminating training process...",
              file=sys.stderr)
        _kill_process_tree(proc)
        _flush_logs()
        if metrics_parser is not None:
            try:
                final_metric = metrics_parser.flush_pending()
                if final_metric:
                    _send_metric(final_metric)
            except Exception:
                pass
        try:
            client.end_run(rid, "cancelled")
        except Exception:
            pass
        print(f"\033[33m[roboprotx]\033[0m run cancelled: run_id={rid}", file=sys.stderr)
        return 130

    finally:
        stop_event.set()
        if artifact_watcher:
            artifact_watcher.stop()
