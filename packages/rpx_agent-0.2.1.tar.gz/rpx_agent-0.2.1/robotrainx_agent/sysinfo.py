"""sysinfo.py — System + GPU telemetry snapshot.

Zero mandatory dependencies. Uses:
  1. nvidia-smi XML output  (GPU stats, no Python deps)
  2. psutil                 (CPU/RAM, optional import)
  3. /proc/meminfo fallback (Linux, no deps)
  4. subprocess python -c   (version info)
"""
from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional


# ─── GPU via nvidia-smi ───────────────────────────────────────────────────────

def _nvidia_smi_xml() -> Optional[str]:
    if not shutil.which("nvidia-smi"):
        return None
    try:
        result = subprocess.run(
            ["nvidia-smi", "-q", "-x"],
            capture_output=True, text=True, timeout=8
        )
        return result.stdout if result.returncode == 0 else None
    except Exception:
        return None


def _parse_nvidia_xml(xml: str) -> List[Dict[str, Any]]:
    gpus: List[Dict[str, Any]] = []
    blocks = re.findall(r"<gpu[^>]*>(.*?)</gpu>", xml, re.DOTALL)
    for block in blocks:
        def tag(name: str) -> Optional[str]:
            m = re.search(rf"<{name}>(.*?)</{name}>", block)
            return m.group(1).strip() if m else None

        def pct(name: str) -> Optional[float]:
            v = tag(name)
            if v:
                m = re.search(r"([\d.]+)\s*%", v)
                if m:
                    return float(m.group(1))
            return None

        def mib(name: str) -> Optional[float]:
            v = tag(name)
            if v:
                m = re.search(r"([\d.]+)\s*MiB", v)
                if m:
                    return float(m.group(1))
            return None

        def celsius(name: str) -> Optional[float]:
            v = tag(name)
            if v:
                m = re.search(r"([\d.]+)\s*C", v)
                if m:
                    return float(m.group(1))
            return None

        gpu: Dict[str, Any] = {}
        name = tag("product_name")
        if name:
            gpu["name"] = name
        util = pct("gpu_util")
        if util is not None:
            gpu["util_pct"] = util
        mem_used = mib("used_memory")
        mem_total = mib("total_memory")
        if mem_used is not None:
            gpu["mem_used_mb"] = mem_used
        if mem_total is not None:
            gpu["mem_total_mb"] = mem_total
        temp = celsius("gpu_temp")
        if temp is not None:
            gpu["temp_c"] = temp
        power_tag = tag("power_draw")
        if power_tag:
            pm = re.search(r"([\d.]+)\s*W", power_tag)
            if pm:
                gpu["power_w"] = float(pm.group(1))
        if gpu:
            gpus.append(gpu)
    return gpus


# ─── CPU / RAM ────────────────────────────────────────────────────────────────

def _cpu_ram_psutil() -> Dict[str, Any]:
    try:
        import psutil  # type: ignore
        cpu = psutil.cpu_percent(interval=0.2)
        vm = psutil.virtual_memory()
        return {
            "cpu_pct": cpu,
            "ram_used_mb": vm.used / 1024 / 1024,
            "ram_total_mb": vm.total / 1024 / 1024,
            "ram_pct": vm.percent,
        }
    except Exception:
        return {}


def _ram_proc_meminfo() -> Dict[str, Any]:
    try:
        txt = open("/proc/meminfo").read()
        total = re.search(r"MemTotal:\s+(\d+)", txt)
        avail = re.search(r"MemAvailable:\s+(\d+)", txt)
        if total and avail:
            t = int(total.group(1)) / 1024
            a = int(avail.group(1)) / 1024
            used = t - a
            return {
                "ram_used_mb": used,
                "ram_total_mb": t,
                "ram_pct": used / t * 100.0,
            }
    except Exception:
        pass
    return {}


# ─── Environment snapshot ─────────────────────────────────────────────────────

def _git_sha() -> Optional[str]:
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=5, cwd=os.getcwd()
        )
        return r.stdout.strip() or None
    except Exception:
        return None


def _cuda_version() -> Optional[str]:
    try:
        r = subprocess.run(
            ["nvcc", "--version"],
            capture_output=True, text=True, timeout=5
        )
        m = re.search(r"release ([\d.]+)", r.stdout)
        return m.group(1) if m else None
    except Exception:
        # Try nvidia-smi CUDA version
        try:
            r = subprocess.run(
                ["nvidia-smi"], capture_output=True, text=True, timeout=5
            )
            m = re.search(r"CUDA Version:\s+([\d.]+)", r.stdout)
            return m.group(1) if m else None
        except Exception:
            return None


def env_snapshot() -> Dict[str, Any]:
    """One-time snapshot taken when a run starts."""
    snap: Dict[str, Any] = {
        "python_version": sys.version.split()[0],
        "platform": platform.system(),
        "hostname": platform.node(),
        "os_release": platform.release(),
        "cpu_count": os.cpu_count(),
    }
    git = _git_sha()
    if git:
        snap["git_sha"] = git
    cuda = _cuda_version()
    if cuda:
        snap["cuda_version"] = cuda

    xml = _nvidia_smi_xml()
    if xml:
        gpus = _parse_nvidia_xml(xml)
        if gpus:
            snap["gpu_count"] = len(gpus)
            snap["gpu_names"] = [g.get("name", "unknown") for g in gpus]
            snap["gpu_mem_total_mb"] = gpus[0].get("mem_total_mb")

    # Detect simulator from installed packages
    sims = []
    for pkg in ("isaaclab", "isaacgym", "mujoco", "dm_control", "gymnasium"):
        try:
            __import__(pkg)
            sims.append(pkg)
        except ImportError:
            pass
    if sims:
        snap["detected_simulators"] = sims

    return snap


# ─── Periodic poll ────────────────────────────────────────────────────────────

def poll_system_metrics() -> Dict[str, Any]:
    """Returns a flat dict suitable for merging into an IngestMetricsRequest."""
    out: Dict[str, Any] = {}

    # GPU
    xml = _nvidia_smi_xml()
    if xml:
        gpus = _parse_nvidia_xml(xml)
        if gpus:
            g0 = gpus[0]
            if "util_pct" in g0:
                out["gpu_util_pct"] = g0["util_pct"]
            if "mem_used_mb" in g0:
                out["gpu_mem_mb"] = g0["mem_used_mb"]

    # CPU / RAM
    cpu_ram = _cpu_ram_psutil()
    if not cpu_ram:
        cpu_ram = _ram_proc_meminfo()
    if "cpu_pct" in cpu_ram:
        out["cpu_percent"] = cpu_ram["cpu_pct"]
    if "ram_used_mb" in cpu_ram:
        out["ram_mb"] = cpu_ram["ram_used_mb"]

    return out
