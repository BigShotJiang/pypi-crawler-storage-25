"""metrics_parser.py — Stateful stdout parser for RL training log formats.

Supports:
  - Stable Baselines3  (| key | value | table)
  - RSL-RL / Isaac Lab (Learning iteration N/M blocks)
  - CleanRL            (global_step=N, episodic_return=F lines)
  - MuJoCo / Gymnasium (key=value pairs)
  - Generic            (step N: key=value ...)
  - [IsaacMonitor]     failure captured lines
  - Episode_Termination / Episode_Reward label lines
"""
from __future__ import annotations

import re
import time
from typing import Any, Dict, Optional


# ─── Compiled patterns ────────────────────────────────────────────────────────

_RE_SB3_ROW = re.compile(r"\|\s+(\S.*?\S)\s+\|\s+([^\|]+)\s+\|")
_RE_SB3_SEP = re.compile(r"^-{10,}$")

_RE_RSLRL_ITER = re.compile(r"Learning iteration\s+(\d+)\s*/\s*(\d+)")
_RE_RSLRL_STEPS = re.compile(r"Computation:\s+([\d.]+)\s+steps/s")
_RE_RSLRL_REWARD = re.compile(r"Mean total reward/step:\s*([-\d.]+)")
_RE_RSLRL_EP_LEN = re.compile(r"Mean episode length:\s*([-\d.]+)")
_RE_RSLRL_VF = re.compile(r"[Vv]alue function loss:\s*([-\d.]+)")
_RE_RSLRL_SUR = re.compile(r"[Ss]urrogate loss:\s*([-\d.]+)")
_RE_RSLRL_NOISE = re.compile(r"Mean action noise std:\s*([-\d.]+)")
_RE_RSLRL_KL = re.compile(r"KL divergence:\s*([-\d.]+)")
_RE_RSLRL_ENTROPY = re.compile(r"[Ee]ntropy:\s*([-\d.]+)")
_RE_RSLRL_GRAD = re.compile(r"[Gg]radient norm:\s*([-\d.]+)")
_RE_RSLRL_LR = re.compile(r"[Ll]earning rate:\s*([-\d.eE+\-]+)")

_RE_EP_TERMINATION = re.compile(r"Episode_Termination/(\S+):\s*([-\d.]+)")
_RE_EP_REWARD_COMP = re.compile(r"Episode_Reward/(\S+):\s*([-\d.]+)")
_RE_EP_CURRICULUM = re.compile(r"Episode_Curriculum/(\S+):\s*([-\d.]+)")

_RE_FAILURE_CAPTURED = re.compile(
    r"\[IsaacMonitor\] failure captured:\s*(\S+)\s+rate=([-\d.]+)"
)

_RE_CLEANRL = re.compile(r"global_step=(\d+),\s*episodic_return=([-\d.]+)")
_RE_CLEANRL_LEN = re.compile(r"episodic_length=([-\d.]+)")

_RE_KV_GENERIC = re.compile(r"(\b[a-zA-Z_][a-zA-Z0-9_/]*)\s*[=:]\s*([-\d.eE+\-]+)")

_SB3_KEY_MAP: Dict[str, str] = {
    "rollout/ep_rew_mean": "mean_reward",
    "rollout/ep_len_mean": "mean_episode_length",
    "time/iterations": "iteration",
    "time/total_timesteps": "total_timesteps",
    "time/time_elapsed": "time_elapsed",
    "time/fps": "steps_per_second",
    "train/approx_kl": "kl_divergence",
    "train/clip_fraction": "clip_fraction",
    "train/entropy_loss": "entropy_loss",
    "train/explained_variance": "explained_variance",
    "train/learning_rate": "learning_rate",
    "train/loss": "total_loss",
    "train/n_updates": "n_updates",
    "train/policy_gradient_loss": "surrogate_loss",
    "train/value_loss": "value_function_loss",
    "train/std": "action_std",
    "train/clip_range": "clip_range",
    "ep_rew_mean": "mean_reward",
    "ep_len_mean": "mean_episode_length",
}


def _try_float(s: str) -> Optional[float]:
    try:
        v = float(s.strip())
        return v if (v == v and abs(v) < 1e15) else None  # reject NaN/Inf
    except (ValueError, OverflowError):
        return None


def _try_int(s: str) -> Optional[int]:
    try:
        return int(s.strip())
    except ValueError:
        return None


class MetricsParser:
    """
    Feed stdout lines one at a time via ``feed_line()``.
    When a complete metric record is ready it is returned; otherwise None.

    A single ``run_and_stream`` session creates one MetricsParser instance.
    """

    def __init__(self) -> None:
        self._mode: str = "idle"        # idle | sb3_table | rslrl_block
        self._current: Dict[str, Any] = {}
        self._sb3_buf: Dict[str, Any] = {}
        self._last_emit_ts: float = 0.0
        self._iteration: int = 0        # running counter used when not parsed

    # ── Public ────────────────────────────────────────────────────────────────

    def feed_line(self, line: str) -> Optional[Dict[str, Any]]:
        """
        Feed one line of stdout.  Returns a metric dict (ready for
        POST /api/v1/ingest-metrics) or None.
        """
        line = line.rstrip("\r\n")
        if not line.strip():
            return None

        result = (
            self._try_sb3(line)
            or self._try_rslrl(line)
            or self._try_failure_captured(line)
            or self._try_cleanrl(line)
            or self._try_episode_labels(line)
            or self._try_generic_kv(line)
        )
        return result

    def flush_pending(self) -> Optional[Dict[str, Any]]:
        """Force-emit whatever is buffered (call on process exit)."""
        if self._current:
            return self._emit()
        return None

    # ── SB3 table parser ─────────────────────────────────────────────────────

    def _try_sb3(self, line: str) -> Optional[Dict[str, Any]]:
        if _RE_SB3_SEP.match(line.strip()):
            if self._mode == "sb3_table" and self._sb3_buf:
                # end of table → emit
                self._mode = "idle"
                rec = dict(self._sb3_buf)
                self._sb3_buf.clear()
                return self._finalise(rec)
            elif self._mode == "idle":
                self._mode = "sb3_table"
            return None

        if self._mode == "sb3_table":
            m = _RE_SB3_ROW.search(line)
            if m:
                raw_key = m.group(1).strip()
                raw_val = m.group(2).strip()
                mapped = _SB3_KEY_MAP.get(raw_key, raw_key)
                v = _try_float(raw_val)
                if v is not None:
                    self._sb3_buf[mapped] = v
            return None

        return None

    # ── RSL-RL / Isaac Lab block parser ───────────────────────────────────────

    def _try_rslrl(self, line: str) -> Optional[Dict[str, Any]]:
        m = _RE_RSLRL_ITER.search(line)
        if m:
            prev = None
            if self._mode == "rslrl_block" and self._current:
                prev = self._emit()
            self._mode = "rslrl_block"
            self._current["iteration"] = int(m.group(1))
            return prev

        if self._mode != "rslrl_block":
            return None

        for pat, key in [
            (_RE_RSLRL_REWARD, "mean_reward"),
            (_RE_RSLRL_EP_LEN, "mean_episode_length"),
            (_RE_RSLRL_STEPS, "steps_per_second"),
            (_RE_RSLRL_VF, "value_function_loss"),
            (_RE_RSLRL_SUR, "surrogate_loss"),
            (_RE_RSLRL_NOISE, "mean_noise_std"),
            (_RE_RSLRL_KL, "kl_divergence"),
            (_RE_RSLRL_ENTROPY, "entropy"),
            (_RE_RSLRL_GRAD, "gradient_norm"),
            (_RE_RSLRL_LR, "learning_rate"),
        ]:
            mm = pat.search(line)
            if mm:
                v = _try_float(mm.group(1))
                if v is not None:
                    self._current[key] = v

        return None

    # ── Failure captured ──────────────────────────────────────────────────────

    def _try_failure_captured(self, line: str) -> Optional[Dict[str, Any]]:
        m = _RE_FAILURE_CAPTURED.search(line)
        if not m:
            return None
        reason = m.group(1)
        rate = _try_float(m.group(2))
        if rate is not None:
            tr = self._current.setdefault("termination_reasons", {})
            tr[reason] = rate
        return None

    # ── Episode_Termination / Episode_Reward labels ───────────────────────────

    def _try_episode_labels(self, line: str) -> Optional[Dict[str, Any]]:
        mt = _RE_EP_TERMINATION.search(line)
        if mt:
            v = _try_float(mt.group(2))
            if v is not None:
                d = self._current.setdefault("termination_reasons", {})
                d[mt.group(1)] = v
            return None

        mr = _RE_EP_REWARD_COMP.search(line)
        if mr:
            v = _try_float(mr.group(2))
            if v is not None:
                d = self._current.setdefault("reward_components", {})
                d[mr.group(1)] = v
            return None

        mc = _RE_EP_CURRICULUM.search(line)
        if mc:
            key = mc.group(1).lower()
            v = _try_float(mc.group(2))
            if v is not None:
                if "terrain" in key or "level" in key:
                    self._current["terrain_level"] = v
                elif "stage" in key:
                    self._current["curriculum_stage"] = int(v)
            return None

        return None

    # ── CleanRL ───────────────────────────────────────────────────────────────

    def _try_cleanrl(self, line: str) -> Optional[Dict[str, Any]]:
        m = _RE_CLEANRL.search(line)
        if not m:
            return None
        rec: Dict[str, Any] = {
            "total_timesteps": int(m.group(1)),
            "mean_reward": _try_float(m.group(2)),
        }
        ml = _RE_CLEANRL_LEN.search(line)
        if ml:
            rec["mean_episode_length"] = _try_float(ml.group(1))
        self._iteration += 1
        rec["iteration"] = self._iteration
        return self._finalise(rec)

    # ── Generic key=value / key:value ─────────────────────────────────────────

    _GENERIC_MAP: Dict[str, str] = {
        "reward": "mean_reward",
        "mean_reward": "mean_reward",
        "ep_rew_mean": "mean_reward",
        "episodic_return": "mean_reward",
        "ep_len_mean": "mean_episode_length",
        "episode_length": "mean_episode_length",
        "iteration": "iteration",
        "iter": "iteration",
        "step": "total_timesteps",
        "global_step": "total_timesteps",
        "timesteps": "total_timesteps",
        "kl": "kl_divergence",
        "kl_div": "kl_divergence",
        "approx_kl": "kl_divergence",
        "entropy": "entropy",
        "loss": "total_loss",
        "value_loss": "value_function_loss",
        "policy_loss": "surrogate_loss",
        "lr": "learning_rate",
        "learning_rate": "learning_rate",
        "fps": "steps_per_second",
        "steps_per_sec": "steps_per_second",
        "grad_norm": "gradient_norm",
        "gradient_norm": "gradient_norm",
        "clip_fraction": "clip_fraction",
        "explained_variance": "explained_variance",
        "success_rate": "success_rate",
        "cpu": "cpu_percent",
        "cpu_pct": "cpu_percent",
        "gpu": "gpu_util_pct",
        "gpu_pct": "gpu_util_pct",
        "ram_mb": "ram_mb",
        "gpu_mem_mb": "gpu_mem_mb",
    }

    def _try_generic_kv(self, line: str) -> Optional[Dict[str, Any]]:
        matches = _RE_KV_GENERIC.findall(line)
        if not matches:
            return None

        rec: Dict[str, Any] = {}
        for raw_key, raw_val in matches:
            key = raw_key.lower().strip()
            mapped = self._GENERIC_MAP.get(key)
            if mapped:
                v = _try_float(raw_val)
                if v is not None:
                    rec[mapped] = v

        if not rec:
            return None

        # Only emit if we have something meaningful (reward or iteration)
        if "mean_reward" not in rec and "iteration" not in rec and "total_timesteps" not in rec:
            return None

        # Rate-limit: don't emit more than once every 2 seconds for generic lines
        now = time.monotonic()
        if now - self._last_emit_ts < 2.0:
            self._current.update(rec)
            return None

        self._current.update(rec)
        return self._emit()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _emit(self) -> Dict[str, Any]:
        rec = dict(self._current)
        self._current = {}
        return self._finalise(rec)

    def _finalise(self, rec: Dict[str, Any]) -> Dict[str, Any]:
        if "iteration" not in rec:
            self._iteration += 1
            rec["iteration"] = self._iteration
        else:
            self._iteration = int(rec["iteration"])
        self._last_emit_ts = time.monotonic()
        return rec
