# 变更日志

## 0.3.0

### 新增

- **完整示例目录** — `examples/` 包含 7 个可运行文件，覆盖 SDK 全部能力
  - `wechat_all_methods.py` — 微信全场景（4 种支付 + 查询/关单/退款/转账/余额/回调）
  - `alipay_all_methods.py` — 支付宝全场景（4 种支付 + 查询/关单/退款/转账/余额/回调）
  - `fastapi_server.py` — FastAPI 生产级集成（多 Provider 切换 + 回调端点 + 全局异常处理）
  - `multi_provider.py` — PayProvider ABC 多态 / 依赖注入模式
  - `settings.py` — pydantic-settings 配置模型（环境变量 + .env 文件）

### 改进

- 提取 `_prepare_json_body()` 到 `BaseHttpClient`，消除子类间重复的 JSON 序列化代码
- 提取 `resolve_status()` 泛型工具函数，统一 8 处状态映射查找模式
- 提取 `AsyncProvider` mixin，统一 Provider 生命周期管理（close/\_\_aenter\_\_/\_\_aexit\_\_）
- 合并 Alipay `create_page_payment` / `create_wap_payment` 为 `_create_redirect_payment`
- 移除 `BaseHttpClient` 未使用的 `self._config` 属性
- `_BASE_URL` 重命名为 `BASE_URL`（消除跨模块导入私有变量）
- `assert` 类型收窄改为显式条件判断（兼容 Python `-O` 模式）

### 修复

- `errors.py` 异常捕获类型：`KeyError` 改为 `AttributeError`（JSON 数组响应场景）
- 修复全部 38 个 mypy strict 模式错误（StrEnum 比较、SecretStr 类型、过时 type: ignore）

## 0.2.0

### 新增

- **支付宝 V3 Provider** — 当面付扫码、电脑网站、手机网站、App 四种支付方式
- **微信支付扩展方式** — JSAPI（公众号/小程序）、H5（手机浏览器）、App 支付
- **转账能力** — 微信商家转账到零钱 + 支付宝单笔转账（WithdrawProvider）
- **余额查询** — 微信 + 支付宝余额查询（WalletProvider）
- **Yuan 金额类型** — 支付宝元单位支持，fen_to_yuan / yuan_to_fen 精确转换（Decimal）
- **共享密码学模块** — providers/crypto.py 提取 RSA 签名/验签共享函数
- **错误转换统一** — providers/errors.py 共享错误转换，provider_name 常量化

### 改进

- WithdrawRequest 添加 recipient（收款人）和 description（转账说明）字段
- PaymentResult 添加 credential 字段（支付凭证：二维码 URL、前端参数等）
- RefundRequest 添加 total_amount 字段（原订单总额）
- WechatPay 提取 _build_payment_payload 消除三个 create 方法重复
- Alipay 同样提取 _build_payment_payload
- raise_for_error 参数化 error_cls 支持不同异常类型

## 0.1.0

### 新增

- 项目初始化
- 搭建工程脚手架：pyproject.toml、src/ 布局、工具链配置
- 添加 httpx、pydantic、cryptography 核心依赖
- 配置 ruff、mypy、pytest 开发工具
- 核心抽象层：PayProvider / WithdrawProvider / WalletProvider ABC
- 异常体系：PayKitError 及 7 个子类
- 数据模型：BaseProviderConfig + 9 个请求/响应模型
- 类型定义：Fen NewType + 状态枚举
- BaseHttpClient：传输层错误转换
- 微信支付 V3 Native Provider（PayProvider）
