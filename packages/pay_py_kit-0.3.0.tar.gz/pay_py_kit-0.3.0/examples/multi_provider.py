"""多支付商统一接口示例 — 展示 PayProvider / WithdrawProvider ABC 的多态用法。

运行方式: uv run python examples/multi_provider.py
核心价值: 业务代码接受抽象类型，不关心底层是微信还是支付宝。
"""

import asyncio
import sys
import time

from pydantic import ValidationError
from settings import AlipaySettings, WechatSettings

from pay_kit.exceptions import PayKitError
from pay_kit.models import PaymentRequest, PaymentResult, WithdrawRequest, WithdrawResult
from pay_kit.providers.alipay import Alipay
from pay_kit.providers.base import PayProvider, WithdrawProvider
from pay_kit.providers.wechat import WechatPay
from pay_kit.types import Fen

# ---------------------------------------------------------------------------
# 业务函数 — 只依赖抽象接口，不关心具体 Provider
# ---------------------------------------------------------------------------


async def create_order(provider: PayProvider, order_no: str, amount: Fen, subject: str) -> PaymentResult:
    """统一下单 — 微信返回二维码 URL，支付宝返回二维码 URL，调用方式完全相同。"""
    return await provider.create_payment(PaymentRequest(out_trade_no=order_no, total_amount=amount, subject=subject))


async def check_order(provider: PayProvider, order_no: str) -> PaymentResult:
    """统一查单 — 接口相同，返回结构相同。"""
    return await provider.query_payment(order_no)


async def transfer_to_user(provider: WithdrawProvider, withdrawal_no: str, recipient: str) -> WithdrawResult:
    """统一转账 — 微信转到零钱（openid），支付宝转到账户（user_id）。"""
    return await provider.create_withdrawal(
        WithdrawRequest(out_withdrawal_no=withdrawal_no, amount=Fen(100), recipient=recipient, description="佣金提现")
    )


# ---------------------------------------------------------------------------
# Provider 工厂
# ---------------------------------------------------------------------------


def create_provider(channel: str) -> PayProvider:
    """根据渠道名创建 Provider — 适合 Django / Flask 等框架使用。"""
    if channel == "wechat":
        return WechatPay(WechatSettings().build_config())
    if channel == "alipay":
        return Alipay(AlipaySettings().build_config())
    raise ValueError(f"不支持的渠道: {channel}")


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------


async def main() -> None:
    channel = "wechat"  # ← 可改为 "alipay"，下面代码无需任何修改
    ts = str(int(time.time()))

    provider = create_provider(channel)
    async with provider:
        print(f"使用 {channel} 支付商\n")

        # 下单
        result = await create_order(provider, f"MULTI_{ts}", Fen(1), "多支付商测试")
        print(f"下单成功: {result.out_trade_no}")
        print(f"  状态: {result.status.value}")
        print(f"  凭证: {result.credential}\n")

        # 查单
        status = await check_order(provider, f"MULTI_{ts}")
        print(f"查单结果: {status.status.value}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except ValidationError:
        print("请先配置环境变量：复制 .env.example 为 .env 并填入真实商户信息")
        print("详见 examples/README.md")
        sys.exit(1)
    except PayKitError as e:
        print(f"SDK 错误: {type(e).__name__}: {e}")
        sys.exit(1)
