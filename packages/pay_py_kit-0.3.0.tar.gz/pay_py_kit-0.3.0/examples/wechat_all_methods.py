"""微信支付全场景示例 — 覆盖 WechatPay 全部 12 个公开方法。

运行方式: uv run python examples/wechat_all_methods.py
首次运行默认查询余额，验证凭证是否正确。其余操作按需取消注释。
"""

import asyncio
import sys
import time

from pydantic import ValidationError
from settings import WechatSettings

from pay_kit.exceptions import PayKitError
from pay_kit.models import PaymentRequest, RefundRequest, WithdrawRequest
from pay_kit.providers.wechat import WechatPay
from pay_kit.types import Fen, fen_to_yuan

# ---------------------------------------------------------------------------
# 余额查询（只读，推荐首次运行）
# ---------------------------------------------------------------------------


async def demo_query_balance(pay: WechatPay) -> None:
    """查询商户余额 — 只读操作，适合验证凭证是否正确。"""
    result = await pay.query_balance()
    print("=== 余额查询 ===")
    print(f"  可用: {result.available} 分 ({fen_to_yuan(result.available)} 元)")
    print(f"  待结: {result.pending} 分 ({fen_to_yuan(result.pending)} 元)")


# ---------------------------------------------------------------------------
# 支付（4 种方式）
# ---------------------------------------------------------------------------


async def demo_native_payment(pay: WechatPay, order_no: str) -> None:
    """Native 扫码支付 — 返回二维码 URL，用户扫码后完成支付。"""
    result = await pay.create_payment(
        PaymentRequest(out_trade_no=order_no, total_amount=Fen(1), subject="Native 扫码测试")
    )
    print("=== Native 扫码支付 ===")
    print(f"  订单号: {result.out_trade_no}")
    print(f"  状态:   {result.status.value}")
    print(f"  二维码: {result.credential}")


async def demo_jsapi_payment(pay: WechatPay, order_no: str) -> None:
    """JSAPI 公众号/小程序支付 — 返回前端 wx.requestPayment() 所需参数。"""
    result = await pay.create_jsapi_payment(
        PaymentRequest(out_trade_no=order_no, total_amount=Fen(1), subject="JSAPI 测试"),
        openid="oUpF8uMuAJO_M2pxb1Q9zNjWeS6o",  # ← 替换为真实 openid（通过微信 OAuth 获取）
    )
    print("=== JSAPI 支付 ===")
    print(f"  订单号:   {result.out_trade_no}")
    print(f"  前端参数: {result.credential}")


async def demo_h5_payment(pay: WechatPay, order_no: str) -> None:
    """H5 手机浏览器支付 — 返回跳转 URL。"""
    result = await pay.create_h5_payment(
        PaymentRequest(out_trade_no=order_no, total_amount=Fen(1), subject="H5 测试"),
        payer_client_ip="123.45.67.89",  # ← 替换为用户真实 IP（从 request.client.host 获取）
    )
    print("=== H5 支付 ===")
    print(f"  订单号:  {result.out_trade_no}")
    print(f"  跳转URL: {result.credential}")


async def demo_app_payment(pay: WechatPay, order_no: str) -> None:
    """App 支付 — 返回移动端 SDK 调起支付所需参数。"""
    result = await pay.create_app_payment(
        PaymentRequest(out_trade_no=order_no, total_amount=Fen(1), subject="App 测试"),
    )
    print("=== App 支付 ===")
    print(f"  订单号:  {result.out_trade_no}")
    print(f"  SDK参数: {result.credential}")


# ---------------------------------------------------------------------------
# 订单操作
# ---------------------------------------------------------------------------


async def demo_query_payment(pay: WechatPay, order_no: str) -> None:
    """查询订单状态 — 需要订单已创建。"""
    result = await pay.query_payment(order_no)
    print("=== 查询订单 ===")
    print(f"  订单号: {result.out_trade_no}")
    print(f"  状态:   {result.status.value}")
    print(f"  交易号: {result.trade_no}")


async def demo_close_payment(pay: WechatPay, order_no: str) -> None:
    """关闭订单 — 仅未支付（PENDING）的订单可关闭。"""
    await pay.close_payment(order_no)
    print("=== 关闭订单 ===")
    print(f"  已关闭: {order_no}")


# ---------------------------------------------------------------------------
# 退款
# ---------------------------------------------------------------------------


async def demo_refund(pay: WechatPay, order_no: str, refund_no: str) -> None:
    """发起退款 — 需要已支付（PAID）的订单，沙箱环境可用 1 分测试。"""
    result = await pay.refund(
        RefundRequest(out_trade_no=order_no, out_refund_no=refund_no, total_amount=Fen(1), refund_amount=Fen(1))
    )
    print("=== 发起退款 ===")
    print(f"  退款单号: {result.out_refund_no}")
    print(f"  状态:     {result.status.value}")


async def demo_query_refund(pay: WechatPay, refund_no: str) -> None:
    """查询退款状态 — 需要退款已发起。"""
    result = await pay.query_refund(refund_no)
    print("=== 查询退款 ===")
    print(f"  退款单号: {result.out_refund_no}")
    print(f"  状态:     {result.status.value}")


# ---------------------------------------------------------------------------
# 回调验签
# ---------------------------------------------------------------------------


async def demo_verify_callback(pay: WechatPay) -> None:
    """回调验签解密 — 需要 HTTP 请求上下文，通常在 Web 框架端点中调用。

    完整 FastAPI 集成见 examples/fastapi_server.py。
    调用方式和返回结构：

        headers = dict(request.headers)    # HTTP 请求头
        body = await request.body()        # 原始请求体 bytes
        event = await pay.verify_callback(headers, body)

        event.event_type   → "TRANSACTION.SUCCESS"
        event.out_trade_no → "ORDER_001"
        event.trade_no     → 微信交易号
        event.raw          → 完整解密后的回调数据 dict
    """
    print("=== 回调验签 ===")
    print("  需要 HTTP 请求上下文，完整示例见 examples/fastapi_server.py")


# ---------------------------------------------------------------------------
# 转账
# ---------------------------------------------------------------------------


async def demo_create_withdrawal(pay: WechatPay, withdrawal_no: str) -> None:
    """商家转账到零钱。"""
    result = await pay.create_withdrawal(
        WithdrawRequest(
            out_withdrawal_no=withdrawal_no,
            amount=Fen(100),
            recipient="oUpF8uMuAJO_M2pxb1Q9zNjWeS6o",  # ← 替换为收款人 openid
            description="测试转账",
        )
    )
    print("=== 发起转账 ===")
    print(f"  转账单号: {result.out_withdrawal_no}")
    print(f"  状态:     {result.status.value}")


async def demo_query_withdrawal(pay: WechatPay, withdrawal_no: str) -> None:
    """查询转账状态 — 需要转账已发起。"""
    result = await pay.query_withdrawal(withdrawal_no)
    print("=== 查询转账 ===")
    print(f"  转账单号: {result.out_withdrawal_no}")
    print(f"  状态:     {result.status.value}")


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------


async def main() -> None:
    config = WechatSettings().build_config()
    ts = str(int(time.time()))  # noqa: F841  # 被注释掉的示例行引用

    async with WechatPay(config) as pay:
        # --- 首次运行建议先查余额，验证凭证是否正确 ---
        await demo_query_balance(pay)

        # --- 支付（按需取消注释，每种方式用不同订单号）---
        # await demo_native_payment(pay, f"NATIVE_{ts}")
        # await demo_jsapi_payment(pay, f"JSAPI_{ts}")
        # await demo_h5_payment(pay, f"H5_{ts}")
        # await demo_app_payment(pay, f"APP_{ts}")

        # --- 订单操作（需要先创建订单，用对应的订单号）---
        # await demo_query_payment(pay, f"NATIVE_{ts}")
        # await demo_close_payment(pay, f"NATIVE_{ts}")

        # --- 退款（需要已支付的订单）---
        # await demo_refund(pay, f"NATIVE_{ts}", f"REFUND_{ts}")
        # await demo_query_refund(pay, f"REFUND_{ts}")

        # --- 回调验签（展示说明）---
        # await demo_verify_callback(pay)

        # --- 转账 ---
        # await demo_create_withdrawal(pay, f"TRANSFER_{ts}")
        # await demo_query_withdrawal(pay, f"TRANSFER_{ts}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except ValidationError:
        print("请先配置环境变量：复制 .env.example 为 .env 并填入真实商户信息")
        print("详见 examples/README.md")
        sys.exit(1)
    except PayKitError as e:
        print(f"SDK 错误: {type(e).__name__}: {e}")
        sys.exit(1)
