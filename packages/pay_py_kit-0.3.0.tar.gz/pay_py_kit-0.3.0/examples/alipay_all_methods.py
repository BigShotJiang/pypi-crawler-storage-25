"""支付宝全场景示例 — 覆盖 Alipay 全部 12 个公开方法。

运行方式: uv run python examples/alipay_all_methods.py
首次运行默认查询余额，验证凭证是否正确。其余操作按需取消注释。
"""

import asyncio
import sys
import time

from pydantic import ValidationError
from settings import AlipaySettings

from pay_kit.exceptions import PayKitError
from pay_kit.models import PaymentRequest, RefundRequest, WithdrawRequest
from pay_kit.providers.alipay import Alipay
from pay_kit.types import Fen, fen_to_yuan

# ---------------------------------------------------------------------------
# 余额查询（只读，推荐首次运行）
# ---------------------------------------------------------------------------


async def demo_query_balance(pay: Alipay) -> None:
    """查询商户余额 — 只读操作，适合验证凭证是否正确。"""
    result = await pay.query_balance()
    print("=== 余额查询 ===")
    print(f"  可用: {result.available} 分 ({fen_to_yuan(result.available)} 元)")
    print(f"  待结: {result.pending} 分 ({fen_to_yuan(result.pending)} 元)")


# ---------------------------------------------------------------------------
# 支付（4 种方式）
# ---------------------------------------------------------------------------


async def demo_qr_payment(pay: Alipay, order_no: str) -> None:
    """当面付扫码支付 — 返回二维码 URL。"""
    result = await pay.create_payment(
        PaymentRequest(out_trade_no=order_no, total_amount=Fen(1), subject="扫码支付测试")
    )
    print("=== 当面付扫码支付 ===")
    print(f"  订单号: {result.out_trade_no}")
    print(f"  状态:   {result.status.value}")
    print(f"  二维码: {result.credential}")


async def demo_page_payment(pay: Alipay, order_no: str) -> None:
    """电脑网站支付 — 返回支付页面跳转 URL。"""
    result = await pay.create_page_payment(
        PaymentRequest(out_trade_no=order_no, total_amount=Fen(1), subject="电脑网站测试"),
        return_url="https://your-site.com/return",  # ← 替换为支付完成后的跳转地址
    )
    print("=== 电脑网站支付 ===")
    print(f"  订单号:  {result.out_trade_no}")
    print(f"  跳转URL: {result.credential}")


async def demo_wap_payment(pay: Alipay, order_no: str) -> None:
    """手机网站支付 — 返回跳转 URL。"""
    result = await pay.create_wap_payment(
        PaymentRequest(out_trade_no=order_no, total_amount=Fen(1), subject="手机网站测试"),
        return_url="https://your-site.com/return",  # ← 替换为支付完成后的跳转地址
    )
    print("=== 手机网站支付 ===")
    print(f"  订单号:  {result.out_trade_no}")
    print(f"  跳转URL: {result.credential}")


async def demo_app_payment(pay: Alipay, order_no: str) -> None:
    """App 支付 — 返回移动端 SDK 所需的订单字符串。"""
    result = await pay.create_app_payment(
        PaymentRequest(out_trade_no=order_no, total_amount=Fen(1), subject="App 测试"),
    )
    print("=== App 支付 ===")
    print(f"  订单号:    {result.out_trade_no}")
    print(f"  订单字符串: {result.credential}")


# ---------------------------------------------------------------------------
# 订单操作
# ---------------------------------------------------------------------------


async def demo_query_payment(pay: Alipay, order_no: str) -> None:
    """查询订单状态 — 需要订单已创建。"""
    result = await pay.query_payment(order_no)
    print("=== 查询订单 ===")
    print(f"  订单号: {result.out_trade_no}")
    print(f"  状态:   {result.status.value}")
    print(f"  交易号: {result.trade_no}")


async def demo_close_payment(pay: Alipay, order_no: str) -> None:
    """关闭订单 — 仅未支付（PENDING）的订单可关闭。"""
    await pay.close_payment(order_no)
    print("=== 关闭订单 ===")
    print(f"  已关闭: {order_no}")


# ---------------------------------------------------------------------------
# 退款
# ---------------------------------------------------------------------------


async def demo_refund(pay: Alipay, order_no: str, refund_no: str) -> None:
    """发起退款 — 需要已支付（PAID）的订单。"""
    result = await pay.refund(
        RefundRequest(out_trade_no=order_no, out_refund_no=refund_no, total_amount=Fen(1), refund_amount=Fen(1))
    )
    print("=== 发起退款 ===")
    print(f"  退款单号: {result.out_refund_no}")
    print(f"  状态:     {result.status.value}")


async def demo_query_refund(pay: Alipay, refund_no: str) -> None:
    """查询退款状态 — 需要退款已发起。"""
    result = await pay.query_refund(refund_no)
    print("=== 查询退款 ===")
    print(f"  退款单号: {result.out_refund_no}")
    print(f"  状态:     {result.status.value}")


# ---------------------------------------------------------------------------
# 回调验签
# ---------------------------------------------------------------------------


async def demo_verify_callback(pay: Alipay) -> None:
    """回调验签 — 需要 HTTP 请求上下文，通常在 Web 框架端点中调用。

    支付宝回调是明文 JSON（无需解密），验签后直接解析。
    完整 FastAPI 集成见 examples/fastapi_server.py。

        headers = dict(request.headers)
        body = await request.body()
        event = await pay.verify_callback(headers, body)

        event.event_type   → "trade_status_sync"
        event.out_trade_no → "ORDER_001"
        event.trade_no     → 支付宝交易号
        event.raw          → 完整回调数据 dict
    """
    print("=== 回调验签 ===")
    print("  需要 HTTP 请求上下文，完整示例见 examples/fastapi_server.py")


# ---------------------------------------------------------------------------
# 转账
# ---------------------------------------------------------------------------


async def demo_create_withdrawal(pay: Alipay, withdrawal_no: str) -> None:
    """转账到支付宝账户。"""
    result = await pay.create_withdrawal(
        WithdrawRequest(
            out_withdrawal_no=withdrawal_no,
            amount=Fen(100),
            recipient="2088102169823968",  # ← 替换为收款人支付宝 user_id
            description="测试转账",
        )
    )
    print("=== 发起转账 ===")
    print(f"  转账单号: {result.out_withdrawal_no}")
    print(f"  状态:     {result.status.value}")


async def demo_query_withdrawal(pay: Alipay, withdrawal_no: str) -> None:
    """查询转账状态 — 需要转账已发起。"""
    result = await pay.query_withdrawal(withdrawal_no)
    print("=== 查询转账 ===")
    print(f"  转账单号: {result.out_withdrawal_no}")
    print(f"  状态:     {result.status.value}")


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------


async def main() -> None:
    config = AlipaySettings().build_config()
    ts = str(int(time.time()))  # noqa: F841  # 用于下方注释掉的示例订单号

    async with Alipay(config) as pay:
        # --- 首次运行建议先查余额，验证凭证是否正确 ---
        await demo_query_balance(pay)

        # --- 支付（按需取消注释，每种方式用不同订单号）---
        # await demo_qr_payment(pay, f"QR_{ts}")
        # await demo_page_payment(pay, f"PAGE_{ts}")
        # await demo_wap_payment(pay, f"WAP_{ts}")
        # await demo_app_payment(pay, f"APP_{ts}")

        # --- 订单操作（需要先创建订单，用对应的订单号）---
        # await demo_query_payment(pay, f"QR_{ts}")
        # await demo_close_payment(pay, f"QR_{ts}")

        # --- 退款（需要已支付的订单）---
        # await demo_refund(pay, f"QR_{ts}", f"REFUND_{ts}")
        # await demo_query_refund(pay, f"REFUND_{ts}")

        # --- 回调验签（展示说明）---
        # await demo_verify_callback(pay)

        # --- 转账 ---
        # await demo_create_withdrawal(pay, f"TRANSFER_{ts}")
        # await demo_query_withdrawal(pay, f"TRANSFER_{ts}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except ValidationError:
        print("请先配置环境变量：复制 .env.example 为 .env 并填入真实商户信息")
        print("详见 examples/README.md")
        sys.exit(1)
    except PayKitError as e:
        print(f"SDK 错误: {type(e).__name__}: {e}")
        sys.exit(1)
