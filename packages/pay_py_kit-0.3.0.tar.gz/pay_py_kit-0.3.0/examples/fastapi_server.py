"""FastAPI 生产级支付服务示例 — 多 Provider 集成 + 回调处理 + 全局异常处理。

运行方式: uv run uvicorn fastapi_server:app --app-dir examples --reload
API 文档: http://127.0.0.1:8000/docs
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from enum import StrEnum
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import ValidationError
from settings import AlipaySettings, WechatSettings

from pay_kit.exceptions import ConfigError, NetworkError, PayKitError, ProviderError, SignatureError
from pay_kit.models import PaymentRequest, PaymentResult, RefundRequest, RefundResult, WithdrawRequest, WithdrawResult
from pay_kit.providers.alipay import Alipay
from pay_kit.providers.base import PayProvider, WalletProvider, WithdrawProvider
from pay_kit.providers.wechat import WechatPay

# ---------------------------------------------------------------------------
# Provider 管理
# ---------------------------------------------------------------------------


class Channel(StrEnum):
    WECHAT = "wechat"
    ALIPAY = "alipay"


@asynccontextmanager
async def lifespan(app: FastAPI):  # type: ignore[no-untyped-def]
    """应用生命周期 — 启动时按需初始化 Provider，关闭时释放连接。"""
    providers: dict[str, PayProvider] = {}
    try:
        providers["wechat"] = WechatPay(WechatSettings().build_config())
        print("[启动] 微信支付 ✓")
    except (ValidationError, ConfigError) as e:
        print(f"[启动] 微信支付未配置，跳过: {e}")
    try:
        providers["alipay"] = Alipay(AlipaySettings().build_config())
        print("[启动] 支付宝 ✓")
    except (ValidationError, ConfigError) as e:
        print(f"[启动] 支付宝未配置，跳过: {e}")

    if not providers:
        raise RuntimeError("至少需要配置一个支付商，请检查 examples/.env")

    app.state.providers = providers
    yield
    for p in providers.values():
        await p.close()


def get_pay_provider(request: Request, channel: Channel) -> PayProvider:
    """获取支付 Provider，未配置则 404。"""
    providers = request.app.state.providers
    if channel.value not in providers:
        raise HTTPException(status_code=404, detail=f"{channel.value} 未配置")
    return providers[channel.value]


def get_withdraw_provider(request: Request, channel: Channel) -> WithdrawProvider:
    """获取转账 Provider。"""
    provider = get_pay_provider(request, channel)
    if not isinstance(provider, WithdrawProvider):
        raise HTTPException(status_code=501, detail=f"{channel.value} 不支持转账")
    return provider


def get_wallet_provider(request: Request, channel: Channel) -> WalletProvider:
    """获取余额 Provider。"""
    provider = get_pay_provider(request, channel)
    if not isinstance(provider, WalletProvider):
        raise HTTPException(status_code=501, detail=f"{channel.value} 不支持余额查询")
    return provider


# ---------------------------------------------------------------------------
# FastAPI App
# ---------------------------------------------------------------------------

app = FastAPI(title="pay-kit 示例服务", lifespan=lifespan)


# ---------------------------------------------------------------------------
# 全局异常处理
# ---------------------------------------------------------------------------


@app.exception_handler(NetworkError)
async def network_error_handler(request: Request, exc: NetworkError) -> JSONResponse:
    return JSONResponse(status_code=502, content={"error": "gateway_timeout", "message": str(exc)})


@app.exception_handler(SignatureError)
async def signature_error_handler(request: Request, exc: SignatureError) -> JSONResponse:
    # 回调端点已在内部处理 SignatureError，此 handler 覆盖其余端点
    return JSONResponse(status_code=400, content={"error": "signature_failed", "message": str(exc)})


@app.exception_handler(ProviderError)
async def provider_error_handler(request: Request, exc: ProviderError) -> JSONResponse:
    return JSONResponse(
        status_code=400,
        content={"error": exc.error_code, "message": str(exc), "provider": exc.provider_name},
    )


@app.exception_handler(PayKitError)
async def pay_kit_error_handler(request: Request, exc: PayKitError) -> JSONResponse:
    return JSONResponse(status_code=500, content={"error": "internal", "message": str(exc)})


# ---------------------------------------------------------------------------
# 支付端点
# ---------------------------------------------------------------------------


@app.post("/pay/{channel}")
async def create_payment(request: Request, channel: Channel, body: PaymentRequest) -> PaymentResult:
    """创建支付订单（Native/扫码）。"""
    provider = get_pay_provider(request, channel)
    return await provider.create_payment(body)


@app.get("/pay/{channel}/{out_trade_no}")
async def query_payment(request: Request, channel: Channel, out_trade_no: str) -> PaymentResult:
    """查询订单状态。"""
    provider = get_pay_provider(request, channel)
    return await provider.query_payment(out_trade_no)


@app.post("/pay/{channel}/{out_trade_no}/close")
async def close_payment(request: Request, channel: Channel, out_trade_no: str) -> dict[str, str]:
    """关闭未支付的订单。"""
    provider = get_pay_provider(request, channel)
    await provider.close_payment(out_trade_no)
    return {"status": "closed", "out_trade_no": out_trade_no}


# ---------------------------------------------------------------------------
# 退款端点
# ---------------------------------------------------------------------------


@app.post("/refund/{channel}")
async def refund(request: Request, channel: Channel, body: RefundRequest) -> RefundResult:
    """发起退款。"""
    provider = get_pay_provider(request, channel)
    return await provider.refund(body)


@app.get("/refund/{channel}/{out_refund_no}")
async def query_refund(request: Request, channel: Channel, out_refund_no: str) -> RefundResult:
    """查询退款状态。"""
    provider = get_pay_provider(request, channel)
    return await provider.query_refund(out_refund_no)


# ---------------------------------------------------------------------------
# 回调端点（微信/支付宝分开，响应格式不同）
# ---------------------------------------------------------------------------


@app.post("/callback/wechat")
async def wechat_callback(request: Request) -> JSONResponse:
    """微信支付回调 — 验签 + AES-GCM 解密。"""
    provider = request.app.state.providers.get("wechat")
    if provider is None:
        return JSONResponse(status_code=404, content={"code": "FAIL", "message": "微信支付未配置"})

    try:
        event = await provider.verify_callback(dict(request.headers), await request.body())
    except SignatureError as e:
        return JSONResponse(status_code=400, content={"code": "FAIL", "message": str(e)})

    # TODO: 在此处理业务逻辑（更新订单状态、发货等）
    print(f"[微信回调] {event.event_type}: {event.out_trade_no} → {event.trade_no}")

    # 微信要求的成功响应格式
    return JSONResponse(content={"code": "SUCCESS", "message": "成功"})


@app.post("/callback/alipay")
async def alipay_callback(request: Request) -> PlainTextResponse:
    """支付宝回调 — 验签（明文 JSON，无需解密）。"""
    provider = request.app.state.providers.get("alipay")
    if provider is None:
        return PlainTextResponse("fail", status_code=404)

    try:
        event = await provider.verify_callback(dict(request.headers), await request.body())
    except SignatureError as e:
        print(f"[支付宝回调] 验签失败: {e}")
        return PlainTextResponse("fail", status_code=400)

    # TODO: 在此处理业务逻辑
    print(f"[支付宝回调] {event.event_type}: {event.out_trade_no} → {event.trade_no}")

    # 支付宝要求的成功响应格式
    return PlainTextResponse("success")


# ---------------------------------------------------------------------------
# 转账端点
# ---------------------------------------------------------------------------


@app.post("/transfer/{channel}")
async def create_withdrawal(request: Request, channel: Channel, body: WithdrawRequest) -> WithdrawResult:
    """发起转账。"""
    provider = get_withdraw_provider(request, channel)
    return await provider.create_withdrawal(body)


@app.get("/transfer/{channel}/{out_withdrawal_no}")
async def query_withdrawal(request: Request, channel: Channel, out_withdrawal_no: str) -> WithdrawResult:
    """查询转账状态。"""
    provider = get_withdraw_provider(request, channel)
    return await provider.query_withdrawal(out_withdrawal_no)


# ---------------------------------------------------------------------------
# 余额端点
# ---------------------------------------------------------------------------


@app.get("/balance/{channel}")
async def query_balance(request: Request, channel: Channel) -> dict[str, Any]:
    """查询商户余额。"""
    provider = get_wallet_provider(request, channel)
    result = await provider.query_balance()
    return {"available": result.available, "pending": result.pending}
