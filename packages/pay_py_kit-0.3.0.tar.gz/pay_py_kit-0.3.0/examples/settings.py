"""pay-kit 示例公共配置 — 从 .env 读取环境变量，构建 SDK 配置对象。"""

from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

from pay_kit.providers.alipay.config import AlipayConfig
from pay_kit.providers.wechat.config import WechatPayConfig

_ENV_FILE = Path(__file__).parent / ".env"


class WechatSettings(BaseSettings):
    """微信支付配置 — 从 WECHAT_ 前缀环境变量读取。"""

    model_config = SettingsConfigDict(env_prefix="WECHAT_", env_file=_ENV_FILE)

    appid: str
    mch_id: str
    private_key_path: Path
    cert_serial_no: str
    public_key_path: Path
    public_key_id: str
    apiv3_key: SecretStr
    notify_url: str

    def build_config(self) -> WechatPayConfig:
        """读取密钥文件，构建 SDK 配置对象。"""
        return WechatPayConfig(
            appid=self.appid,
            mch_id=self.mch_id,
            private_key=SecretStr(self.private_key_path.read_text()),
            cert_serial_no=self.cert_serial_no,
            wechat_public_key=self.public_key_path.read_text(),
            wechat_public_key_id=self.public_key_id,
            apiv3_key=self.apiv3_key,
            notify_url=self.notify_url,
        )


class AlipaySettings(BaseSettings):
    """支付宝配置 — 从 ALIPAY_ 前缀环境变量读取。"""

    model_config = SettingsConfigDict(env_prefix="ALIPAY_", env_file=_ENV_FILE)

    app_id: str
    private_key_path: Path
    public_key_path: Path
    notify_url: str

    def build_config(self) -> AlipayConfig:
        """读取密钥文件，构建 SDK 配置对象。"""
        return AlipayConfig(
            app_id=self.app_id,
            private_key=SecretStr(self.private_key_path.read_text()),
            alipay_public_key=self.public_key_path.read_text(),
            notify_url=self.notify_url,
        )
