# pay-kit 示例

可运行的完整代码示例，覆盖 pay-kit SDK 的全部能力。

## 前置条件

- Python 3.11+
- 已安装 pay-kit 及示例依赖：

```bash
uv sync --group examples
```

## 配置

1. 复制环境变量模板：

```bash
cp examples/.env.example examples/.env
```

2. 编辑 `examples/.env`，填入真实商户信息
3. 将密钥 PEM 文件放入 `examples/keys/` 目录（该目录已被 .gitignore 排除）

密钥获取方式：
- 微信：[微信商户平台](https://pay.weixin.qq.com) → 账户中心 → API 安全
- 支付宝：[支付宝开放平台](https://open.alipay.com) → 开发设置 → 接口加签方式

## 示例索引

| 文件 | 场景 | 运行方式 |
|------|------|----------|
| `wechat_all_methods.py` | 微信全场景（4 种支付 + 查询/关单/退款/转账/余额） | `uv run python examples/wechat_all_methods.py` |
| `alipay_all_methods.py` | 支付宝全场景（4 种支付 + 查询/关单/退款/转账/余额） | `uv run python examples/alipay_all_methods.py` |
| `fastapi_server.py` | FastAPI 生产级集成（多 Provider + 回调 + 异常处理） | `uv run uvicorn fastapi_server:app --app-dir examples --reload` |
| `multi_provider.py` | 多支付商统一接口（PayProvider ABC 多态） | `uv run python examples/multi_provider.py` |
| `settings.py` | pydantic-settings 配置模型（所有示例共用） | 被其他示例导入 |

## 注意事项

- 所有示例调用**真实支付 API**，请使用沙箱环境或小额测试
- 首次运行建议先执行余额查询（只读），验证凭证是否正确
- 回调端点需要公网可访问的 URL，本地开发可使用 ngrok 等内网穿透工具
- `examples/.env` 和 `examples/keys/` 已在 `.gitignore` 中排除，不会被提交
