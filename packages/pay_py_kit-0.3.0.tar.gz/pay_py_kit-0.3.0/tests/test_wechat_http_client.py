"""pay_kit.providers.wechat.http_client 测试。"""

import base64
import secrets
import time

import httpx
import pytest
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from pydantic import SecretStr

from pay_kit.exceptions import ConfigError, SignatureError
from pay_kit.providers.wechat.config import WechatPayConfig
from pay_kit.providers.wechat.http_client import BASE_URL, WechatHttpClient
from tests.conftest import make_wechat_signed_transport


class TestWechatHttpClientInit:
    def test_init_caches_keys(self, wechat_config: WechatPayConfig) -> None:
        client = WechatHttpClient(wechat_config)
        assert isinstance(client._private_key, rsa.RSAPrivateKey)
        assert isinstance(client._wechat_public_key, rsa.RSAPublicKey)

    def test_init_invalid_private_key(self, wechat_public_pem: str) -> None:
        config = WechatPayConfig(
            appid="wx_test",
            mch_id="123",
            private_key=SecretStr("INVALID_PEM"),
            cert_serial_no="SERIAL",
            wechat_public_key=wechat_public_pem,
            wechat_public_key_id="PUB_KEY_ID",
            apiv3_key=SecretStr("test_apiv3_key_32chars_pad000000"),
            notify_url="https://example.com/callback",
        )
        with pytest.raises(ConfigError):
            WechatHttpClient(config)


class TestWechatHttpClientRequest:
    async def test_request_adds_authorization_header(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        captured_request: httpx.Request | None = None

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal captured_request
            captured_request = request
            body_str = ""
            timestamp = str(int(time.time()))
            nonce = secrets.token_hex(16)
            verify_str = f"{timestamp}\n{nonce}\n{body_str}\n"
            sig = base64.b64encode(
                wechat_key_pair[0].sign(verify_str.encode(), padding.PKCS1v15(), hashes.SHA256())
            ).decode()
            return httpx.Response(
                204,
                headers={
                    "Wechatpay-Timestamp": timestamp,
                    "Wechatpay-Nonce": nonce,
                    "Wechatpay-Signature": sig,
                    "Wechatpay-Serial": "TEST_PUB_KEY_ID",
                },
            )

        transport = httpx.MockTransport(handler)
        async with WechatHttpClient(wechat_config, transport=transport) as client:
            url = f"{BASE_URL}/v3/pay/transactions/out-trade-no/T001/close"
            await client.request("POST", url, json={"mchid": "123"})

        assert captured_request is not None
        auth = captured_request.headers["authorization"]
        assert auth.startswith("WECHATPAY2-SHA256-RSA2048")
        assert 'mchid="1234567890"' in auth
        assert 'serial_no="TEST_CERT_SERIAL"' in auth

    async def test_successful_request_with_json(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"code_url": "weixin://wxpay/..."})
        async with WechatHttpClient(wechat_config, transport=transport) as client:
            response = await client.request("POST", f"{BASE_URL}/v3/pay/transactions/native", json={"mchid": "123"})
        assert response.status_code == 200

    async def test_response_verification_failure(
        self,
        wechat_config: WechatPayConfig,
        merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(merchant_key_pair[0], 200, {"data": "test"})
        async with WechatHttpClient(wechat_config, transport=transport) as client:
            with pytest.raises(SignatureError, match="签名验证失败"):
                await client.request("GET", f"{BASE_URL}/v3/certificates")

    async def test_2xx_missing_signature_headers(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 200, {"data": "test"}, include_signature_headers=False
        )
        async with WechatHttpClient(wechat_config, transport=transport) as client:
            with pytest.raises(SignatureError):
                await client.request("GET", f"{BASE_URL}/v3/pay")

    async def test_non_2xx_missing_headers_skips_verification(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 502, None, include_signature_headers=False)
        async with WechatHttpClient(wechat_config, transport=transport) as client:
            response = await client.request("GET", f"{BASE_URL}/v3/pay")
        assert response.status_code == 502

    async def test_serial_mismatch(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 200, {"data": "test"}, public_key_id="WRONG_KEY_ID"
        )
        async with WechatHttpClient(wechat_config, transport=transport) as client:
            with pytest.raises(SignatureError, match="公钥 ID 不匹配"):
                await client.request("GET", f"{BASE_URL}/v3/pay")


class TestWechatHttpClientVerifySignature:
    def test_verify_signature_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        client = WechatHttpClient(wechat_config)
        timestamp = "1695000000"
        nonce = "testnonce"
        body = '{"key":"val"}'
        verify_str = f"{timestamp}\n{nonce}\n{body}\n"
        sig = base64.b64encode(
            wechat_key_pair[0].sign(verify_str.encode(), padding.PKCS1v15(), hashes.SHA256())
        ).decode()
        client.verify_signature(timestamp, nonce, body, sig, "TEST_PUB_KEY_ID")

    def test_verify_signature_serial_mismatch(self, wechat_config: WechatPayConfig) -> None:
        client = WechatHttpClient(wechat_config)
        with pytest.raises(SignatureError, match="公钥 ID 不匹配"):
            client.verify_signature("ts", "nonce", "body", "sig", "WRONG_SERIAL")
