"""pay_kit.providers.wechat.sign 签名/验签测试。"""

import base64

import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from pay_kit.exceptions import ConfigError, SignatureError
from pay_kit.providers.wechat.sign import (
    build_sign_string,
    build_verify_string,
    decrypt_callback,
    load_private_key,
    load_public_key,
    sign,
    verify,
)


class TestLoadKeys:
    def test_load_private_key(self, merchant_private_pem: str) -> None:
        key = load_private_key(merchant_private_pem)
        assert isinstance(key, rsa.RSAPrivateKey)

    def test_load_private_key_invalid_pem(self) -> None:
        with pytest.raises(ConfigError, match="私钥"):
            load_private_key("not a pem")

    def test_load_private_key_wrong_type(self, wechat_public_pem: str) -> None:
        with pytest.raises(ConfigError, match="RSA"):
            load_private_key(wechat_public_pem)

    def test_load_public_key(self, wechat_public_pem: str) -> None:
        key = load_public_key(wechat_public_pem)
        assert isinstance(key, rsa.RSAPublicKey)

    def test_load_public_key_invalid_pem(self) -> None:
        with pytest.raises(ConfigError, match="公钥"):
            load_public_key("not a pem")

    def test_load_public_key_wrong_type(self, merchant_private_pem: str) -> None:
        with pytest.raises(ConfigError, match="RSA"):
            load_public_key(merchant_private_pem)


class TestBuildStrings:
    def test_build_sign_string(self) -> None:
        result = build_sign_string("POST", "/v3/pay/transactions/native", "1695000000", "abc123", '{"key":"val"}')
        assert result == 'POST\n/v3/pay/transactions/native\n1695000000\nabc123\n{"key":"val"}\n'

    def test_build_sign_string_empty_body(self) -> None:
        result = build_sign_string("GET", "/v3/certificates", "1695000000", "abc123", "")
        assert result == "GET\n/v3/certificates\n1695000000\nabc123\n\n"

    def test_build_verify_string(self) -> None:
        result = build_verify_string("1695000000", "abc123", '{"key":"val"}')
        assert result == '1695000000\nabc123\n{"key":"val"}\n'

    def test_build_verify_string_empty_body(self) -> None:
        result = build_verify_string("1695000000", "abc123", "")
        assert result == "1695000000\nabc123\n\n"


class TestSignAndVerify:
    def test_sign_and_verify_roundtrip(
        self,
        merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        private_key, public_key = merchant_key_pair
        sign_string = "POST\n/v3/pay\n1695000000\nnonce\n{}\n"
        signature = sign(sign_string, private_key)
        assert isinstance(signature, str)
        assert verify(sign_string, signature, public_key)

    def test_verify_tampered_data(
        self,
        merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        private_key, public_key = merchant_key_pair
        sign_string = "POST\n/v3/pay\n1695000000\nnonce\n{}\n"
        signature = sign(sign_string, private_key)
        assert not verify("TAMPERED\n" + sign_string, signature, public_key)

    def test_verify_wrong_key(
        self,
        merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        merchant_private = merchant_key_pair[0]
        wechat_public = wechat_key_pair[1]
        sign_string = "POST\n/v3/pay\n1695000000\nnonce\n{}\n"
        signature = sign(sign_string, merchant_private)
        assert not verify(sign_string, signature, wechat_public)


class TestDecryptCallback:
    def _encrypt(self, plaintext: str, key: str, nonce: str, aad: str) -> str:
        """辅助方法：AES-GCM 加密，模拟微信回调。"""
        aesgcm = AESGCM(key.encode())
        ciphertext = aesgcm.encrypt(
            nonce.encode(),
            plaintext.encode(),
            aad.encode() if aad else None,
        )
        return base64.b64encode(ciphertext).decode()

    def test_decrypt_success(self) -> None:
        key = "test_apiv3_key_32chars_pad000000"
        nonce = "nonce_abc123"
        aad = "transaction"
        plaintext = '{"out_trade_no":"T001"}'
        ciphertext_b64 = self._encrypt(plaintext, key, nonce, aad)
        result = decrypt_callback(ciphertext_b64, nonce, aad, key)
        assert result == plaintext

    def test_decrypt_empty_aad(self) -> None:
        key = "test_apiv3_key_32chars_pad000000"
        nonce = "nonce_abc123"
        plaintext = '{"data":"test"}'
        ciphertext_b64 = self._encrypt(plaintext, key, nonce, "")
        result = decrypt_callback(ciphertext_b64, nonce, "", key)
        assert result == plaintext

    def test_decrypt_wrong_key(self) -> None:
        key = "test_apiv3_key_32chars_pad000000"
        wrong_key = "wrong_apiv3_key_32chars_pad00000"
        nonce = "nonce_abc123"
        ciphertext_b64 = self._encrypt("data", key, nonce, "")
        with pytest.raises(SignatureError, match="解密"):
            decrypt_callback(ciphertext_b64, nonce, "", wrong_key)

    def test_decrypt_tampered_ciphertext(self) -> None:
        key = "test_apiv3_key_32chars_pad000000"
        nonce = "nonce_abc123"
        ciphertext_b64 = base64.b64encode(b"tampered_data").decode()
        with pytest.raises(SignatureError, match="解密"):
            decrypt_callback(ciphertext_b64, nonce, "", key)
