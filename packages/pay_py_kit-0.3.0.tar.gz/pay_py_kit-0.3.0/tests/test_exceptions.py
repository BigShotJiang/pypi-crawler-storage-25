"""pay_kit.exceptions 异常体系测试。"""

from pay_kit.exceptions import (
    ConfigError,
    NetworkError,
    PayKitError,
    PaymentError,
    ProviderError,
    SignatureError,
    WalletError,
    WithdrawError,
)


class TestInheritance:
    def test_config_error_inherits_pay_kit_error(self) -> None:
        assert issubclass(ConfigError, PayKitError)

    def test_provider_error_inherits_pay_kit_error(self) -> None:
        assert issubclass(ProviderError, PayKitError)

    def test_payment_error_inherits_provider_error(self) -> None:
        assert issubclass(PaymentError, ProviderError)
        assert issubclass(PaymentError, PayKitError)

    def test_withdraw_error_inherits_provider_error(self) -> None:
        assert issubclass(WithdrawError, ProviderError)

    def test_wallet_error_inherits_provider_error(self) -> None:
        assert issubclass(WalletError, ProviderError)

    def test_signature_error_inherits_pay_kit_error(self) -> None:
        assert issubclass(SignatureError, PayKitError)

    def test_network_error_inherits_pay_kit_error(self) -> None:
        assert issubclass(NetworkError, PayKitError)


class TestProviderErrorAttributes:
    def test_provider_error_with_all_attributes(self) -> None:
        err = ProviderError("支付失败", error_code="ORDER_CLOSED", provider_name="wechat")
        assert str(err) == "支付失败"
        assert err.error_code == "ORDER_CLOSED"
        assert err.provider_name == "wechat"

    def test_provider_error_default_attributes(self) -> None:
        err = ProviderError("错误")
        assert err.error_code is None
        assert err.provider_name is None

    def test_payment_error_inherits_attributes(self) -> None:
        err = PaymentError("退款失败", error_code="REFUND_ERR", provider_name="alipay")
        assert err.error_code == "REFUND_ERR"
        assert err.provider_name == "alipay"

    def test_withdraw_error_inherits_attributes(self) -> None:
        err = WithdrawError("提现失败", error_code="W001", provider_name="wechat")
        assert err.error_code == "W001"

    def test_wallet_error_inherits_attributes(self) -> None:
        err = WalletError("余额查询失败", error_code="BAL_ERR", provider_name="alipay")
        assert err.provider_name == "alipay"


class TestExceptionCatch:
    def test_catch_payment_error_as_provider_error(self) -> None:
        try:
            raise PaymentError("test")
        except ProviderError as e:
            assert str(e) == "test"

    def test_catch_provider_error_as_pay_kit_error(self) -> None:
        try:
            raise ProviderError("test")
        except PayKitError as e:
            assert str(e) == "test"

    def test_catch_network_error_as_pay_kit_error(self) -> None:
        try:
            raise NetworkError("超时")
        except PayKitError as e:
            assert str(e) == "超时"
