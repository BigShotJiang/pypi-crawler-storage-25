"""pay_kit.providers.wechat.provider 测试。"""

import base64
import json
import secrets
import time
from typing import Any

import pytest
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from pay_kit.exceptions import PaymentError, SignatureError, WalletError, WithdrawError
from pay_kit.models import (
    BalanceResult,
    PaymentRequest,
    PaymentResult,
    RefundRequest,
    RefundResult,
    WithdrawRequest,
    WithdrawResult,
)
from pay_kit.providers.wechat.config import WechatPayConfig
from pay_kit.providers.wechat.provider import WechatPay
from pay_kit.types import Fen, PaymentStatus, RefundStatus, WithdrawStatus
from tests.conftest import make_wechat_signed_transport


class TestCreatePayment:
    async def test_create_payment_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 200, {"code_url": "weixin://wxpay/bizpayurl?pr=xxx"}
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.create_payment(
                PaymentRequest(out_trade_no="T001", total_amount=Fen(100), subject="测试订单")
            )
        assert isinstance(result, PaymentResult)
        assert result.out_trade_no == "T001"
        assert result.status == PaymentStatus.PENDING
        assert result.credential == {"code_url": "weixin://wxpay/bizpayurl?pr=xxx"}

    async def test_create_payment_error(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 400, {"code": "PARAM_ERROR", "message": "参数错误"}
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="参数错误"):
                await pay.create_payment(PaymentRequest(out_trade_no="T002", total_amount=Fen(100), subject="测试"))


class TestQueryPayment:
    async def test_query_payment_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        response_data = {"transaction_id": "WX123", "trade_state": "SUCCESS", "out_trade_no": "T001"}
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, response_data)
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.query_payment("T001")
        assert result.trade_no == "WX123"
        assert result.status == PaymentStatus.PAID

    async def test_query_payment_pending(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 200, {"trade_state": "NOTPAY", "out_trade_no": "T001"}
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.query_payment("T001")
        assert result.status == PaymentStatus.PENDING

    async def test_query_payment_unknown_status(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        data = {"trade_state": "NEW_STATE", "out_trade_no": "T001"}
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, data)
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="未知支付状态"):
                await pay.query_payment("T001")


class TestClosePayment:
    async def test_close_payment_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 204)
        async with WechatPay(wechat_config, transport=transport) as pay:
            await pay.close_payment("T001")


class TestRefund:
    async def test_refund_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 200, {"out_refund_no": "R001", "status": "PROCESSING"}
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.refund(
                RefundRequest(out_trade_no="T001", out_refund_no="R001", total_amount=Fen(100), refund_amount=Fen(50))
            )
        assert isinstance(result, RefundResult)
        assert result.status == RefundStatus.PENDING

    async def test_query_refund_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 200, {"out_refund_no": "R001", "status": "SUCCESS"}
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.query_refund("R001")
        assert result.status == RefundStatus.SUCCESS

    async def test_query_refund_unknown_status(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 200, {"out_refund_no": "R001", "status": "UNKNOWN"}
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="未知退款状态"):
                await pay.query_refund("R001")


class TestVerifyCallback:
    def _make_callback(
        self,
        wechat_private_key: rsa.RSAPrivateKey,
        apiv3_key: str,
        inner_data: dict[str, Any],
        event_type: str = "TRANSACTION.SUCCESS",
    ) -> tuple[dict[str, str], bytes]:
        """构造模拟微信回调。"""
        nonce_aes = "callback_nonce"
        associated_data = "transaction"
        plaintext = json.dumps(inner_data).encode()
        aesgcm = AESGCM(apiv3_key.encode())
        ciphertext = aesgcm.encrypt(nonce_aes.encode(), plaintext, associated_data.encode())
        ciphertext_b64 = base64.b64encode(ciphertext).decode()

        outer = {
            "event_type": event_type,
            "resource_type": "encrypt-resource",
            "resource": {
                "algorithm": "AEAD_AES_256_GCM",
                "ciphertext": ciphertext_b64,
                "nonce": nonce_aes,
                "associated_data": associated_data,
            },
        }
        body = json.dumps(outer).encode()
        body_str = body.decode()

        timestamp = str(int(time.time()))
        nonce_sig = secrets.token_hex(16)
        verify_str = f"{timestamp}\n{nonce_sig}\n{body_str}\n"
        sig = base64.b64encode(
            wechat_private_key.sign(verify_str.encode(), padding.PKCS1v15(), hashes.SHA256())
        ).decode()

        headers = {
            "Wechatpay-Timestamp": timestamp,
            "Wechatpay-Nonce": nonce_sig,
            "Wechatpay-Signature": sig,
            "Wechatpay-Serial": "TEST_PUB_KEY_ID",
        }
        return headers, body

    async def test_verify_callback_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        inner = {"out_trade_no": "T001", "transaction_id": "WX123", "trade_state": "SUCCESS"}
        headers, body = self._make_callback(wechat_key_pair[0], "test_apiv3_key_32chars_pad000000", inner)
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200)
        async with WechatPay(wechat_config, transport=transport) as pay:
            event = await pay.verify_callback(headers, body)
        assert event.event_type == "TRANSACTION.SUCCESS"
        assert event.out_trade_no == "T001"
        assert event.trade_no == "WX123"
        assert event.raw["trade_state"] == "SUCCESS"

    async def test_verify_callback_missing_header(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200)
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(SignatureError, match="缺少回调签名头"):
                await pay.verify_callback({"some-header": "value"}, b'{"data":"test"}')

    async def test_verify_callback_case_insensitive_headers(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        inner = {"out_trade_no": "T002", "transaction_id": "WX456", "trade_state": "SUCCESS"}
        headers, body = self._make_callback(wechat_key_pair[0], "test_apiv3_key_32chars_pad000000", inner)
        lowercase_headers = {k.lower(): v for k, v in headers.items()}
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200)
        async with WechatPay(wechat_config, transport=transport) as pay:
            event = await pay.verify_callback(lowercase_headers, body)
        assert event.out_trade_no == "T002"


class TestLifecycle:
    async def test_context_manager(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200)
        async with WechatPay(wechat_config, transport=transport) as pay:
            assert not pay._http._client.is_closed
        assert pay._http._client.is_closed


class TestCreateWithdrawal:
    async def test_create_withdrawal_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        response_data = {
            "out_batch_no": "W001",
            "batch_id": "1030000071100999991182020050700019480001",
            "create_time": "2026-04-14T12:00:00+08:00",
        }
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, response_data)
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.create_withdrawal(
                WithdrawRequest(
                    out_withdrawal_no="W001",
                    amount=Fen(100),
                    recipient="oUpF8uMuAJO_M2pxb1Q9zNjWeS6o",
                    description="佣金提现",
                )
            )
        assert isinstance(result, WithdrawResult)
        assert result.out_withdrawal_no == "W001"
        assert result.status == WithdrawStatus.PENDING

    async def test_create_withdrawal_error(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0], 403, {"code": "NO_AUTH", "message": "产品权限验证失败"}
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(WithdrawError, match="产品权限验证失败"):
                await pay.create_withdrawal(
                    WithdrawRequest(
                        out_withdrawal_no="W002",
                        amount=Fen(100),
                        recipient="oUpF8...",
                        description="测试",
                    )
                )


class TestQueryWithdrawal:
    async def test_query_withdrawal_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        response_data = {"out_batch_no": "W001", "out_detail_no": "W001", "detail_status": "SUCCESS"}
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, response_data)
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.query_withdrawal("W001")
        assert result.status == WithdrawStatus.SUCCESS

    async def test_query_withdrawal_processing(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"detail_status": "PROCESSING"})
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.query_withdrawal("W001")
        assert result.status == WithdrawStatus.PENDING

    async def test_query_withdrawal_failed(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"detail_status": "FAIL"})
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.query_withdrawal("W001")
        assert result.status == WithdrawStatus.FAILED

    async def test_query_withdrawal_unknown_status(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"detail_status": "NEW_STATE"})
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(WithdrawError, match="未知转账状态"):
                await pay.query_withdrawal("W001")


class TestQueryBalance:
    async def test_query_balance_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        response_data = {"available_amount": 100000, "pending_amount": 5000}
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, response_data)
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.query_balance()
        assert isinstance(result, BalanceResult)
        assert result.available == 100000
        assert result.pending == 5000

    async def test_query_balance_zero(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"available_amount": 0, "pending_amount": 0})
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.query_balance()
        assert result.available == 0
        assert result.pending == 0

    async def test_query_balance_error(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 403, {"code": "NO_AUTH", "message": "没有权限"})
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(WalletError, match="没有权限"):
                await pay.query_balance()


class TestCreateJsapiPayment:
    async def test_create_jsapi_payment_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"prepay_id": "wx20260414120000abcdef"})
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.create_jsapi_payment(
                PaymentRequest(out_trade_no="T001", total_amount=Fen(100), subject="测试订单"),
                openid="oUpF8uMuAJO_M2pxb1Q9zNjWeS6o",
            )
        assert isinstance(result, PaymentResult)
        assert result.out_trade_no == "T001"
        assert result.status == PaymentStatus.PENDING
        assert result.credential is not None
        assert result.credential["appId"] == "wx_test"
        assert result.credential["signType"] == "RSA"
        assert "paySign" in result.credential
        assert result.credential["package"] == "prepay_id=wx20260414120000abcdef"

    async def test_create_jsapi_payment_pay_sign_valid(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
        merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        """验证 paySign 是有效的 RSA-SHA256 签名。"""
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"prepay_id": "wx20260414test"})
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.create_jsapi_payment(
                PaymentRequest(out_trade_no="T002", total_amount=Fen(200), subject="签名测试"),
                openid="oUpF8test",
            )
        cred = result.credential
        assert cred is not None
        sign_string = f"{cred['appId']}\n{cred['timeStamp']}\n{cred['nonceStr']}\n{cred['package']}\n"
        from pay_kit.providers.wechat.sign import verify

        assert verify(sign_string, cred["paySign"], merchant_key_pair[1])

    async def test_create_jsapi_payment_error(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0],
            400,
            {"code": "PARAM_ERROR", "message": "openid无效"},
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="openid无效"):
                await pay.create_jsapi_payment(
                    PaymentRequest(out_trade_no="T003", total_amount=Fen(100), subject="测试"),
                    openid="invalid_openid",
                )


class TestCreateH5Payment:
    async def test_create_h5_payment_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        h5_url = "https://wx.tenpay.com/cgi-bin/mmpayweb-bin/checkmweb?prepay_id=wx20260414"
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"h5_url": h5_url})
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.create_h5_payment(
                PaymentRequest(out_trade_no="T001", total_amount=Fen(100), subject="测试订单"),
                payer_client_ip="123.45.67.89",
            )
        assert isinstance(result, PaymentResult)
        assert result.out_trade_no == "T001"
        assert result.status == PaymentStatus.PENDING
        assert result.credential is not None
        assert result.credential["h5_url"] == h5_url

    async def test_create_h5_payment_error(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0],
            400,
            {"code": "PARAM_ERROR", "message": "场景信息无效"},
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="场景信息无效"):
                await pay.create_h5_payment(
                    PaymentRequest(out_trade_no="T002", total_amount=Fen(100), subject="测试"),
                    payer_client_ip="invalid",
                )


class TestCreateAppPayment:
    async def test_create_app_payment_success(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"prepay_id": "wx20260414app001"})
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.create_app_payment(
                PaymentRequest(out_trade_no="T001", total_amount=Fen(100), subject="测试订单"),
            )
        assert isinstance(result, PaymentResult)
        assert result.out_trade_no == "T001"
        assert result.status == PaymentStatus.PENDING
        assert result.credential is not None
        assert result.credential["appId"] == "wx_test"
        assert result.credential["partnerId"] == "1234567890"
        assert result.credential["prepayId"] == "wx20260414app001"
        assert result.credential["package"] == "Sign=WXPay"
        assert "sign" in result.credential

    async def test_create_app_payment_sign_valid(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
        merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        """验证 sign 是有效的 RSA-SHA256 签名。"""
        transport = make_wechat_signed_transport(wechat_key_pair[0], 200, {"prepay_id": "wx20260414apptest"})
        async with WechatPay(wechat_config, transport=transport) as pay:
            result = await pay.create_app_payment(
                PaymentRequest(out_trade_no="T002", total_amount=Fen(200), subject="签名测试"),
            )
        cred = result.credential
        assert cred is not None
        sign_string = f"{cred['appId']}\n{cred['timeStamp']}\n{cred['nonceStr']}\nprepay_id={cred['prepayId']}\n"
        from pay_kit.providers.wechat.sign import verify

        assert verify(sign_string, cred["sign"], merchant_key_pair[1])

    async def test_create_app_payment_error(
        self,
        wechat_config: WechatPayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_wechat_signed_transport(
            wechat_key_pair[0],
            400,
            {"code": "PARAM_ERROR", "message": "参数错误"},
        )
        async with WechatPay(wechat_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="参数错误"):
                await pay.create_app_payment(
                    PaymentRequest(out_trade_no="T003", total_amount=Fen(100), subject="测试"),
                )
