"""pay_kit.providers.alipay.config 配置模型测试。"""

import pytest
from pydantic import SecretStr, ValidationError

from pay_kit.providers.alipay.config import AlipayConfig


class TestAlipayConfig:
    def test_create_config(self, merchant_private_pem: str, alipay_public_pem: str) -> None:
        config = AlipayConfig(
            app_id="2021001100000001",
            private_key=SecretStr(merchant_private_pem),
            alipay_public_key=alipay_public_pem,
            notify_url="https://example.com/callback",
        )
        assert config.app_id == "2021001100000001"
        assert config.notify_url == "https://example.com/callback"

    def test_private_key_is_secret(self, merchant_private_pem: str, alipay_public_pem: str) -> None:
        config = AlipayConfig(
            app_id="2021001100000001",
            private_key=SecretStr(merchant_private_pem),
            alipay_public_key=alipay_public_pem,
            notify_url="https://example.com/callback",
        )
        assert isinstance(config.private_key, SecretStr)
        assert "BEGIN" not in repr(config.private_key)

    def test_alipay_public_key_is_plain_str(self, merchant_private_pem: str, alipay_public_pem: str) -> None:
        config = AlipayConfig(
            app_id="2021001100000001",
            private_key=SecretStr(merchant_private_pem),
            alipay_public_key=alipay_public_pem,
            notify_url="https://example.com/callback",
        )
        assert isinstance(config.alipay_public_key, str)

    def test_config_is_frozen(self, merchant_private_pem: str, alipay_public_pem: str) -> None:
        config = AlipayConfig(
            app_id="2021001100000001",
            private_key=SecretStr(merchant_private_pem),
            alipay_public_key=alipay_public_pem,
            notify_url="https://example.com/callback",
        )
        with pytest.raises(ValidationError):
            config.app_id = "changed"

    def test_missing_required_field(self) -> None:
        with pytest.raises(ValidationError):
            AlipayConfig(  # type: ignore[call-arg]
                app_id="2021001100000001",
                notify_url="https://example.com/callback",
            )
