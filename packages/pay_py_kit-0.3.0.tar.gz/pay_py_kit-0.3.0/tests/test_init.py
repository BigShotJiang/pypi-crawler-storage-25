"""pay_kit 包公开 API 测试。"""

from pay_kit import __version__
from pay_kit.exceptions import (
    ConfigError,
    NetworkError,
    PayKitError,
    PaymentError,
    ProviderError,
    SignatureError,
    WalletError,
    WithdrawError,
)
from pay_kit.models import (
    BalanceResult,
    BaseProviderConfig,
    CallbackEvent,
    PaymentRequest,
    PaymentResult,
    RefundRequest,
    RefundResult,
    WithdrawRequest,
    WithdrawResult,
)
from pay_kit.providers import PayProvider, WalletProvider, WithdrawProvider
from pay_kit.providers.alipay import Alipay, AlipayConfig
from pay_kit.providers.http_client import BaseHttpClient
from pay_kit.providers.wechat import WechatPay, WechatPayConfig
from pay_kit.types import Fen, PaymentStatus, RefundStatus, WithdrawStatus, Yuan, fen_to_yuan, yuan_to_fen


def test_version_is_string() -> None:
    assert isinstance(__version__, str)


def test_version_value() -> None:
    assert __version__ == "0.3.0"


def test_all_exceptions_importable() -> None:
    assert issubclass(PayKitError, Exception)
    assert issubclass(ConfigError, PayKitError)
    assert issubclass(ProviderError, PayKitError)
    assert issubclass(PaymentError, ProviderError)
    assert issubclass(WithdrawError, ProviderError)
    assert issubclass(WalletError, ProviderError)
    assert issubclass(SignatureError, PayKitError)
    assert issubclass(NetworkError, PayKitError)


def test_all_models_importable() -> None:
    assert BaseProviderConfig is not None
    assert PaymentRequest is not None
    assert PaymentResult is not None
    assert RefundRequest is not None
    assert RefundResult is not None
    assert WithdrawRequest is not None
    assert WithdrawResult is not None
    assert BalanceResult is not None
    assert CallbackEvent is not None


def test_all_providers_importable() -> None:
    assert PayProvider is not None
    assert WithdrawProvider is not None
    assert WalletProvider is not None
    assert BaseHttpClient is not None


def test_all_types_importable() -> None:
    assert Fen is not None
    assert PaymentStatus is not None
    assert RefundStatus is not None
    assert WithdrawStatus is not None


def test_wechat_provider_importable() -> None:
    assert WechatPay is not None
    assert WechatPayConfig is not None


def test_alipay_provider_importable() -> None:
    assert Alipay is not None
    assert AlipayConfig is not None


def test_yuan_type_importable() -> None:
    assert Yuan is not None
    assert fen_to_yuan is not None
    assert yuan_to_fen is not None
