"""pay_kit.providers.alipay.provider 测试。"""

import base64
import json
import secrets
from datetime import UTC, datetime
from typing import Any

import pytest
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from pay_kit.exceptions import PaymentError, SignatureError, WalletError, WithdrawError
from pay_kit.models import (
    BalanceResult,
    PaymentRequest,
    PaymentResult,
    RefundRequest,
    RefundResult,
    WithdrawRequest,
    WithdrawResult,
)
from pay_kit.providers.alipay.config import AlipayConfig
from pay_kit.providers.alipay.provider import Alipay
from pay_kit.types import Fen, PaymentStatus, RefundStatus, WithdrawStatus
from tests.conftest import make_alipay_signed_transport


class TestCreatePayment:
    async def test_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"qr_code": "https://qr.alipay.com/xxx"})
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.create_payment(
                PaymentRequest(out_trade_no="T001", total_amount=Fen(100), subject="测试订单")
            )
        assert isinstance(result, PaymentResult)
        assert result.out_trade_no == "T001"
        assert result.status == PaymentStatus.PENDING
        assert result.credential == {"qr_code": "https://qr.alipay.com/xxx"}

    async def test_error(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(
            wechat_key_pair[0], 400, {"code": "INVALID_PARAMETER", "message": "参数无效"}
        )
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="参数无效"):
                await pay.create_payment(PaymentRequest(out_trade_no="T002", total_amount=Fen(100), subject="测试"))


class TestQueryPayment:
    async def test_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        data = {"trade_no": "ALI123", "trade_status": "TRADE_SUCCESS", "out_trade_no": "T001"}
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, data)
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.query_payment("T001")
        assert result.trade_no == "ALI123"
        assert result.status == PaymentStatus.PAID

    async def test_unknown_status(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(
            wechat_key_pair[0], 200, {"trade_status": "NEW_STATE", "out_trade_no": "T001"}
        )
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="未知交易状态"):
                await pay.query_payment("T001")


class TestClosePayment:
    async def test_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"msg": "Success"})
        async with Alipay(alipay_config, transport=transport) as pay:
            await pay.close_payment("T001")


class TestRefund:
    async def test_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"fund_change": "Y", "refund_fee": "0.50"})
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.refund(
                RefundRequest(out_trade_no="T001", out_refund_no="R001", total_amount=Fen(100), refund_amount=Fen(50))
            )
        assert isinstance(result, RefundResult)
        assert result.status == RefundStatus.SUCCESS

    async def test_query_refund_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(
            wechat_key_pair[0], 200, {"out_request_no": "R001", "refund_status": "REFUND_SUCCESS"}
        )
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.query_refund("R001")
        assert result.status == RefundStatus.SUCCESS

    async def test_query_refund_unknown(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(
            wechat_key_pair[0], 200, {"out_request_no": "R001", "refund_status": "UNKNOWN"}
        )
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="未知退款状态"):
                await pay.query_refund("R001")


class TestVerifyCallback:
    def _make_callback(
        self,
        alipay_private_key: rsa.RSAPrivateKey,
        inner_data: dict[str, Any],
    ) -> tuple[dict[str, str], bytes]:
        body = json.dumps(inner_data).encode()
        body_str = body.decode()
        timestamp = datetime.now(tz=UTC).isoformat(timespec="seconds")
        nonce = secrets.token_hex(16)
        verify_str = f"{timestamp}\n{nonce}\n{body_str}\n"
        sig = base64.b64encode(
            alipay_private_key.sign(verify_str.encode(), padding.PKCS1v15(), hashes.SHA256())
        ).decode()
        return {"alipay-timestamp": timestamp, "alipay-nonce": nonce, "alipay-signature": sig}, body

    async def test_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        inner = {
            "notify_type": "trade_status_sync",
            "out_trade_no": "T001",
            "trade_no": "ALI123",
            "trade_status": "TRADE_SUCCESS",
        }
        headers, body = self._make_callback(wechat_key_pair[0], inner)
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200)
        async with Alipay(alipay_config, transport=transport) as pay:
            event = await pay.verify_callback(headers, body)
        assert event.event_type == "trade_status_sync"
        assert event.out_trade_no == "T001"
        assert event.trade_no == "ALI123"

    async def test_missing_header(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200)
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(SignatureError, match="缺少回调签名头"):
                await pay.verify_callback({"some-header": "value"}, b'{"data":"test"}')

    async def test_case_insensitive(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        inner = {"notify_type": "trade_status_sync", "out_trade_no": "T002", "trade_no": "ALI456"}
        headers, body = self._make_callback(wechat_key_pair[0], inner)
        upper_headers = {k.upper(): v for k, v in headers.items()}
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200)
        async with Alipay(alipay_config, transport=transport) as pay:
            event = await pay.verify_callback(upper_headers, body)
        assert event.out_trade_no == "T002"


class TestCreatePagePayment:
    async def test_create_page_payment_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        pay_url = "https://openapi.alipay.com/gateway.do?alipay_sdk=pay-kit&sign=xxx"
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"pay_url": pay_url})
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.create_page_payment(
                PaymentRequest(out_trade_no="T001", total_amount=Fen(100), subject="测试订单"),
                return_url="https://merchant.com/return",
            )
        assert isinstance(result, PaymentResult)
        assert result.out_trade_no == "T001"
        assert result.status == PaymentStatus.PENDING
        assert result.credential is not None
        assert result.credential["pay_url"] == pay_url

    async def test_create_page_payment_error(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(
            wechat_key_pair[0],
            400,
            {"code": "INVALID_PARAMETER", "message": "参数无效"},
        )
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="参数无效"):
                await pay.create_page_payment(
                    PaymentRequest(out_trade_no="T002", total_amount=Fen(100), subject="测试"),
                    return_url="https://merchant.com/return",
                )


class TestLifecycle:
    async def test_context_manager(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200)
        async with Alipay(alipay_config, transport=transport) as pay:
            assert not pay._http._client.is_closed
        assert pay._http._client.is_closed


class TestCreateWithdrawal:
    async def test_create_withdrawal_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        response_data = {"out_biz_no": "W001", "order_id": "20260414001", "status": "SUCCESS"}
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, response_data)
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.create_withdrawal(
                WithdrawRequest(
                    out_withdrawal_no="W001",
                    amount=Fen(100),
                    recipient="2088102169823968",
                    description="佣金提现",
                )
            )
        assert isinstance(result, WithdrawResult)
        assert result.out_withdrawal_no == "W001"
        assert result.status == WithdrawStatus.SUCCESS

    async def test_create_withdrawal_dealing(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        response_data = {"out_biz_no": "W002", "order_id": "20260414002", "status": "DEALING"}
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, response_data)
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.create_withdrawal(
                WithdrawRequest(
                    out_withdrawal_no="W002",
                    amount=Fen(100),
                    recipient="2088102169823968",
                    description="测试",
                )
            )
        assert result.status == WithdrawStatus.PENDING

    async def test_create_withdrawal_error(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 403, {"code": "NO_AUTH", "message": "权限不足"})
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(WithdrawError, match="权限不足"):
                await pay.create_withdrawal(
                    WithdrawRequest(out_withdrawal_no="W003", amount=Fen(100), recipient="2088xxx", description="测试")
                )


class TestQueryWithdrawal:
    async def test_query_withdrawal_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"out_biz_no": "W001", "status": "SUCCESS"})
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.query_withdrawal("W001")
        assert result.status == WithdrawStatus.SUCCESS

    async def test_query_withdrawal_dealing(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"out_biz_no": "W001", "status": "DEALING"})
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.query_withdrawal("W001")
        assert result.status == WithdrawStatus.PENDING

    async def test_query_withdrawal_unknown_status(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"out_biz_no": "W001", "status": "NEW_STATE"})
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(WithdrawError, match="未知转账状态"):
                await pay.query_withdrawal("W001")


class TestQueryBalance:
    async def test_query_balance_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        response_data = {"available_amount": "1000.00", "freeze_amount": "50.00"}
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, response_data)
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.query_balance()
        assert isinstance(result, BalanceResult)
        assert result.available == 100000
        assert result.pending == 5000

    async def test_query_balance_no_freeze(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        response_data = {"available_amount": "100.00"}
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, response_data)
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.query_balance()
        assert result.available == 10000
        assert result.pending == 0

    async def test_query_balance_error(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 403, {"code": "NO_AUTH", "message": "没有权限"})
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(WalletError, match="没有权限"):
                await pay.query_balance()


class TestCreateWapPayment:
    async def test_create_wap_payment_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        pay_url = "https://openapi.alipay.com/gateway.do?alipay_sdk=pay-kit&sign=xxx"
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"pay_url": pay_url})
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.create_wap_payment(
                PaymentRequest(out_trade_no="T001", total_amount=Fen(100), subject="测试订单"),
                return_url="https://merchant.com/return",
            )
        assert isinstance(result, PaymentResult)
        assert result.out_trade_no == "T001"
        assert result.status == PaymentStatus.PENDING
        assert result.credential is not None
        assert result.credential["pay_url"] == pay_url

    async def test_create_wap_payment_error(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(
            wechat_key_pair[0],
            400,
            {"code": "INVALID_PARAMETER", "message": "参数无效"},
        )
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="参数无效"):
                await pay.create_wap_payment(
                    PaymentRequest(out_trade_no="T002", total_amount=Fen(100), subject="测试"),
                    return_url="https://merchant.com/return",
                )


class TestCreateAppPayment:
    async def test_create_app_payment_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        order_str = "alipay_sdk=pay-kit&app_id=2021001100000001&sign=xxx&timestamp=2026-04-14"
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"order_str": order_str})
        async with Alipay(alipay_config, transport=transport) as pay:
            result = await pay.create_app_payment(
                PaymentRequest(out_trade_no="T001", total_amount=Fen(100), subject="测试订单"),
            )
        assert isinstance(result, PaymentResult)
        assert result.out_trade_no == "T001"
        assert result.status == PaymentStatus.PENDING
        assert result.credential is not None
        assert result.credential["order_str"] == order_str

    async def test_create_app_payment_error(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(
            wechat_key_pair[0],
            400,
            {"code": "INVALID_PARAMETER", "message": "参数无效"},
        )
        async with Alipay(alipay_config, transport=transport) as pay:
            with pytest.raises(PaymentError, match="参数无效"):
                await pay.create_app_payment(
                    PaymentRequest(out_trade_no="T002", total_amount=Fen(100), subject="测试"),
                )
