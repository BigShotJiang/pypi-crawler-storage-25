"""pay_kit.models 数据模型测试。"""

import pytest
from pydantic import ValidationError

from pay_kit.models import (
    BalanceResult,
    BaseProviderConfig,
    CallbackEvent,
    PaymentRequest,
    PaymentResult,
    RefundRequest,
    RefundResult,
    WithdrawRequest,
    WithdrawResult,
)
from pay_kit.types import (
    Fen,
    PaymentStatus,
    RefundStatus,
    WithdrawStatus,
)


class TestBaseProviderConfig:
    def test_create_config(self) -> None:
        config = BaseProviderConfig(notify_url="https://example.com/callback")
        assert config.notify_url == "https://example.com/callback"

    def test_config_is_frozen(self) -> None:
        config = BaseProviderConfig(notify_url="https://example.com/callback")
        with pytest.raises(ValidationError):
            config.notify_url = "https://other.com"

    def test_config_missing_notify_url(self) -> None:
        with pytest.raises(ValidationError):
            BaseProviderConfig()  # type: ignore[call-arg]


class TestPaymentModels:
    def test_payment_request(self) -> None:
        req = PaymentRequest(
            out_trade_no="T20260414001",
            total_amount=Fen(100),
            subject="测试订单",
        )
        assert req.out_trade_no == "T20260414001"
        assert req.total_amount == 100
        assert req.subject == "测试订单"

    def test_payment_result(self) -> None:
        result = PaymentResult(
            out_trade_no="T001",
            trade_no="WX123456",
            status=PaymentStatus.PAID,
        )
        assert result.trade_no == "WX123456"
        assert result.status == PaymentStatus.PAID
        assert result.credential is None

    def test_payment_result_trade_no_optional(self) -> None:
        result = PaymentResult(
            out_trade_no="T001",
            status=PaymentStatus.PENDING,
        )
        assert result.trade_no is None

    def test_payment_result_with_credential(self) -> None:
        result = PaymentResult(
            out_trade_no="T001",
            status=PaymentStatus.PENDING,
            credential={"code_url": "weixin://wxpay/bizpayurl?pr=xxx"},
        )
        assert result.credential == {"code_url": "weixin://wxpay/bizpayurl?pr=xxx"}


class TestRefundModels:
    def test_refund_request(self) -> None:
        req = RefundRequest(
            out_trade_no="T001",
            out_refund_no="R001",
            total_amount=Fen(100),
            refund_amount=Fen(50),
        )
        assert req.total_amount == 100
        assert req.refund_amount == 50

    def test_refund_result(self) -> None:
        result = RefundResult(
            out_refund_no="R001",
            status=RefundStatus.SUCCESS,
        )
        assert result.status == RefundStatus.SUCCESS


class TestWithdrawModels:
    def test_withdraw_request(self) -> None:
        req = WithdrawRequest(
            out_withdrawal_no="W001",
            amount=Fen(10000),
            recipient="oUpF8uMuAJO_M2pxb1Q9zNjWeS6o",
            description="佣金提现",
        )
        assert req.amount == 10000
        assert req.recipient == "oUpF8uMuAJO_M2pxb1Q9zNjWeS6o"
        assert req.description == "佣金提现"

    def test_withdraw_result(self) -> None:
        result = WithdrawResult(
            out_withdrawal_no="W001",
            status=WithdrawStatus.PENDING,
        )
        assert result.status == WithdrawStatus.PENDING


class TestBalanceAndCallback:
    def test_balance_result(self) -> None:
        result = BalanceResult(
            available=Fen(100000),
            pending=Fen(5000),
        )
        assert result.available == 100000
        assert result.pending == 5000

    def test_callback_event(self) -> None:
        event = CallbackEvent(
            event_type="payment.success",
            out_trade_no="T001",
            trade_no="WX123",
            raw={"key": "value"},
        )
        assert event.event_type == "payment.success"
        assert event.raw == {"key": "value"}
