"""pay_kit.providers.http_client 测试。"""

import httpx
import pytest

from pay_kit.exceptions import NetworkError
from pay_kit.models import BaseProviderConfig
from pay_kit.providers.http_client import BaseHttpClient


@pytest.fixture()
def config() -> BaseProviderConfig:
    return BaseProviderConfig(notify_url="https://example.com/callback")


def _raising_transport(exc: Exception) -> httpx.MockTransport:
    """构造抛出指定异常的 MockTransport。"""

    def handler(request: httpx.Request) -> httpx.Response:
        raise exc

    return httpx.MockTransport(handler)


class TestBaseHttpClientLifecycle:
    async def test_context_manager(self, config: BaseProviderConfig) -> None:
        async with BaseHttpClient(config) as client:
            assert not client._client.is_closed
        assert client._client.is_closed

    async def test_close(self, config: BaseProviderConfig) -> None:
        client = BaseHttpClient(config)
        assert not client._client.is_closed
        await client.close()
        assert client._client.is_closed

    async def test_custom_timeout(self, config: BaseProviderConfig) -> None:
        async with BaseHttpClient(config, timeout=10.0) as client:
            assert client._client.timeout.connect == 10.0


class TestBaseHttpClientErrorConversion:
    async def test_timeout_raises_network_error(self, config: BaseProviderConfig) -> None:
        transport = _raising_transport(httpx.ReadTimeout("read timed out"))
        async with BaseHttpClient(config, transport=transport) as client:
            with pytest.raises(NetworkError, match="请求超时"):
                await client.request("GET", "https://api.example.com/test")

    async def test_connect_error_raises_network_error(self, config: BaseProviderConfig) -> None:
        transport = _raising_transport(httpx.ConnectError("connection refused"))
        async with BaseHttpClient(config, transport=transport) as client:
            with pytest.raises(NetworkError, match="连接失败"):
                await client.request("GET", "https://api.example.com/test")

    async def test_successful_request_returns_response(self, config: BaseProviderConfig) -> None:
        transport = httpx.MockTransport(lambda req: httpx.Response(200, json={"status": "ok"}))
        async with BaseHttpClient(config, transport=transport) as client:
            response = await client.request("GET", "https://api.example.com/test")
            assert response.status_code == 200
            assert response.json() == {"status": "ok"}

    async def test_4xx_returns_response_not_error(self, config: BaseProviderConfig) -> None:
        transport = httpx.MockTransport(lambda req: httpx.Response(400, json={"error": "bad request"}))
        async with BaseHttpClient(config, transport=transport) as client:
            response = await client.request("GET", "https://api.example.com/test")
            assert response.status_code == 400

    async def test_5xx_returns_response_not_error(self, config: BaseProviderConfig) -> None:
        transport = httpx.MockTransport(lambda req: httpx.Response(500, json={"error": "server error"}))
        async with BaseHttpClient(config, transport=transport) as client:
            response = await client.request("GET", "https://api.example.com/test")
            assert response.status_code == 500
