"""pay_kit.providers.alipay.sign 签名测试。"""

from cryptography.hazmat.primitives.asymmetric import rsa

from pay_kit.providers.alipay.sign import (
    build_auth_string,
    build_sign_string,
    build_verify_string,
    load_private_key,
    load_public_key,
    sign,
    verify,
)


class TestReexports:
    def test_load_private_key(self, merchant_private_pem: str) -> None:
        key = load_private_key(merchant_private_pem)
        assert isinstance(key, rsa.RSAPrivateKey)

    def test_load_public_key(self, alipay_public_pem: str) -> None:
        key = load_public_key(alipay_public_pem)
        assert isinstance(key, rsa.RSAPublicKey)

    def test_sign_and_verify(self, merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]) -> None:
        private_key, public_key = merchant_key_pair
        signature = sign("test\n", private_key)
        assert verify("test\n", signature, public_key)

    def test_build_verify_string(self) -> None:
        result = build_verify_string("2026-04-14T12:00:00+08:00", "nonce123", '{"key":"val"}')
        assert result == '2026-04-14T12:00:00+08:00\nnonce123\n{"key":"val"}\n'


class TestAlipaySpecific:
    def test_build_auth_string(self) -> None:
        result = build_auth_string("2021001100000001", "2026-04-14T12:00:00+08:00", "nonce123")
        assert result == "app_id=2021001100000001,timestamp=2026-04-14T12:00:00+08:00,nonce=nonce123"

    def test_build_sign_string(self) -> None:
        auth_str = "app_id=2021001100000001,timestamp=2026-04-14T12:00:00+08:00,nonce=nonce123"
        result = build_sign_string(auth_str, '{"total_amount":"1.00"}')
        assert result == f'{auth_str}\n{{"total_amount":"1.00"}}\n'

    def test_build_sign_string_empty_body(self) -> None:
        auth_str = "app_id=2021001100000001,timestamp=2026-04-14T12:00:00+08:00,nonce=nonce123"
        result = build_sign_string(auth_str, "")
        assert result == f"{auth_str}\n\n"
