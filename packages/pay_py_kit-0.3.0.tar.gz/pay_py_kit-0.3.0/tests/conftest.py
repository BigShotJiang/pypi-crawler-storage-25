"""pay-kit 测试公共 fixtures。"""

import base64
import json
import secrets
import time
from datetime import UTC, datetime
from typing import Any

import httpx
import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from pydantic import SecretStr

from pay_kit.providers.alipay.config import AlipayConfig
from pay_kit.providers.wechat.config import WechatPayConfig

# ---------------------------------------------------------------------------
# 密钥 fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def merchant_key_pair() -> tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]:
    """商户密钥对：私钥签请求。"""
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return private_key, private_key.public_key()


@pytest.fixture(scope="session")
def wechat_key_pair() -> tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]:
    """模拟微信密钥对：私钥签 mock 响应，公钥配入 config 验签。"""
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return private_key, private_key.public_key()


@pytest.fixture(scope="session")
def merchant_private_pem(merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]) -> str:
    """商户私钥 PEM 字符串。"""
    return (
        merchant_key_pair[0]
        .private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        .decode()
    )


@pytest.fixture(scope="session")
def wechat_public_pem(wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]) -> str:
    """微信公钥 PEM 字符串。"""
    return (
        wechat_key_pair[1]
        .public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        .decode()
    )


@pytest.fixture(scope="session")
def alipay_public_pem(wechat_public_pem: str) -> str:
    """模拟支付宝公钥 PEM 字符串（复用 wechat_key_pair 的公钥）。"""
    return wechat_public_pem


# ---------------------------------------------------------------------------
# Config fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def wechat_config(merchant_private_pem: str, wechat_public_pem: str) -> WechatPayConfig:
    return WechatPayConfig(
        appid="wx_test",
        mch_id="1234567890",
        private_key=SecretStr(merchant_private_pem),
        cert_serial_no="TEST_CERT_SERIAL",
        wechat_public_key=wechat_public_pem,
        wechat_public_key_id="TEST_PUB_KEY_ID",
        apiv3_key=SecretStr("test_apiv3_key_32chars_pad000000"),
        notify_url="https://example.com/callback",
    )


@pytest.fixture()
def alipay_config(merchant_private_pem: str, alipay_public_pem: str) -> AlipayConfig:
    return AlipayConfig(
        app_id="2021001100000001",
        private_key=SecretStr(merchant_private_pem),
        alipay_public_key=alipay_public_pem,
        notify_url="https://example.com/callback",
    )


# ---------------------------------------------------------------------------
# Mock transport helpers
# ---------------------------------------------------------------------------


def make_wechat_signed_transport(
    wechat_private_key: rsa.RSAPrivateKey,
    status_code: int = 200,
    json_data: dict[str, Any] | None = None,
    public_key_id: str = "TEST_PUB_KEY_ID",
    include_signature_headers: bool = True,
) -> httpx.MockTransport:
    """构造返回签名响应的微信 mock transport。"""

    def handler(request: httpx.Request) -> httpx.Response:
        body_str = json.dumps(json_data) if json_data is not None else ""
        body_bytes = body_str.encode() if json_data is not None else b""
        headers: dict[str, str] = {}
        if json_data is not None:
            headers["content-type"] = "application/json"
        if include_signature_headers:
            timestamp = str(int(time.time()))
            nonce = secrets.token_hex(16)
            verify_str = f"{timestamp}\n{nonce}\n{body_str}\n"
            sig = base64.b64encode(
                wechat_private_key.sign(verify_str.encode(), padding.PKCS1v15(), hashes.SHA256())
            ).decode()
            headers.update(
                {
                    "Wechatpay-Timestamp": timestamp,
                    "Wechatpay-Nonce": nonce,
                    "Wechatpay-Signature": sig,
                    "Wechatpay-Serial": public_key_id,
                }
            )
        return httpx.Response(status_code, content=body_bytes, headers=headers)

    return httpx.MockTransport(handler)


def make_alipay_signed_transport(
    alipay_private_key: rsa.RSAPrivateKey,
    status_code: int = 200,
    json_data: dict[str, Any] | None = None,
    include_signature_headers: bool = True,
) -> httpx.MockTransport:
    """构造返回签名响应的支付宝 mock transport。"""

    def handler(request: httpx.Request) -> httpx.Response:
        body_str = json.dumps(json_data) if json_data is not None else ""
        body_bytes = body_str.encode() if json_data is not None else b""
        headers: dict[str, str] = {}
        if json_data is not None:
            headers["content-type"] = "application/json"
        if include_signature_headers:
            timestamp = datetime.now(tz=UTC).isoformat(timespec="seconds")
            nonce = secrets.token_hex(16)
            verify_str = f"{timestamp}\n{nonce}\n{body_str}\n"
            sig = base64.b64encode(
                alipay_private_key.sign(verify_str.encode(), padding.PKCS1v15(), hashes.SHA256())
            ).decode()
            headers.update({"alipay-timestamp": timestamp, "alipay-nonce": nonce, "alipay-signature": sig})
        return httpx.Response(status_code, content=body_bytes, headers=headers)

    return httpx.MockTransport(handler)
