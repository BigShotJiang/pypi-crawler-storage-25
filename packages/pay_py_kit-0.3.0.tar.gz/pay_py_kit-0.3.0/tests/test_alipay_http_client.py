"""pay_kit.providers.alipay.http_client 测试。"""

import base64
import secrets
from datetime import UTC, datetime

import httpx
import pytest
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from pydantic import SecretStr

from pay_kit.exceptions import ConfigError, SignatureError
from pay_kit.providers.alipay.config import AlipayConfig
from pay_kit.providers.alipay.http_client import BASE_URL, AlipayHttpClient
from tests.conftest import make_alipay_signed_transport


class TestAlipayHttpClientInit:
    def test_init_caches_keys(self, alipay_config: AlipayConfig) -> None:
        client = AlipayHttpClient(alipay_config)
        assert isinstance(client._private_key, rsa.RSAPrivateKey)
        assert isinstance(client._alipay_public_key, rsa.RSAPublicKey)

    def test_init_invalid_private_key(self, alipay_public_pem: str) -> None:
        config = AlipayConfig(
            app_id="2021001100000001",
            private_key=SecretStr("INVALID_PEM"),
            alipay_public_key=alipay_public_pem,
            notify_url="https://example.com/callback",
        )
        with pytest.raises(ConfigError):
            AlipayHttpClient(config)


class TestAlipayHttpClientRequest:
    async def test_request_adds_authorization_header(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        captured_request: httpx.Request | None = None

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal captured_request
            captured_request = request
            body_str = '{"qr_code":"https://qr.alipay.com/xxx"}'
            body_bytes = body_str.encode()
            timestamp = datetime.now(tz=UTC).isoformat(timespec="seconds")
            nonce = secrets.token_hex(16)
            verify_str = f"{timestamp}\n{nonce}\n{body_str}\n"
            sig = base64.b64encode(
                wechat_key_pair[0].sign(verify_str.encode(), padding.PKCS1v15(), hashes.SHA256())
            ).decode()
            return httpx.Response(
                200,
                content=body_bytes,
                headers={
                    "content-type": "application/json",
                    "alipay-timestamp": timestamp,
                    "alipay-nonce": nonce,
                    "alipay-signature": sig,
                },
            )

        transport = httpx.MockTransport(handler)
        async with AlipayHttpClient(alipay_config, transport=transport) as client:
            await client.request("POST", f"{BASE_URL}/v3/alipay/trade/precreate", json={"total_amount": "1.00"})
        assert captured_request is not None
        auth = captured_request.headers["authorization"]
        assert auth.startswith("ALIPAY-SHA256withRSA")
        assert "app_id=2021001100000001" in auth

    async def test_successful_request(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 200, {"qr_code": "https://qr.alipay.com/xxx"})
        async with AlipayHttpClient(alipay_config, transport=transport) as client:
            resp = await client.request("POST", f"{BASE_URL}/v3/alipay/trade/precreate", json={"total_amount": "1.00"})
        assert resp.status_code == 200

    async def test_response_verification_failure(
        self,
        alipay_config: AlipayConfig,
        merchant_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(merchant_key_pair[0], 200, {"data": "test"})
        async with AlipayHttpClient(alipay_config, transport=transport) as client:
            with pytest.raises(SignatureError, match="签名验证失败"):
                await client.request("GET", f"{BASE_URL}/v3/alipay/trade/query")

    async def test_2xx_missing_signature_headers(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(
            wechat_key_pair[0], 200, {"data": "test"}, include_signature_headers=False
        )
        async with AlipayHttpClient(alipay_config, transport=transport) as client:
            with pytest.raises(SignatureError):
                await client.request("GET", f"{BASE_URL}/v3/alipay/trade/query")

    async def test_non_2xx_missing_headers_skips(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        transport = make_alipay_signed_transport(wechat_key_pair[0], 502, None, include_signature_headers=False)
        async with AlipayHttpClient(alipay_config, transport=transport) as client:
            resp = await client.request("GET", f"{BASE_URL}/v3/alipay/trade/query")
        assert resp.status_code == 502


class TestAlipayHttpClientVerifySignature:
    def test_verify_signature_success(
        self,
        alipay_config: AlipayConfig,
        wechat_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    ) -> None:
        client = AlipayHttpClient(alipay_config)
        ts = "2026-04-14T12:00:00+08:00"
        nonce = "testnonce"
        body = '{"key":"val"}'
        verify_str = f"{ts}\n{nonce}\n{body}\n"
        sig = base64.b64encode(
            wechat_key_pair[0].sign(verify_str.encode(), padding.PKCS1v15(), hashes.SHA256())
        ).decode()
        client.verify_signature(ts, nonce, body, sig)

    def test_verify_signature_failure(self, alipay_config: AlipayConfig) -> None:
        client = AlipayHttpClient(alipay_config)
        with pytest.raises(SignatureError, match="签名验证失败"):
            client.verify_signature("ts", "nonce", "body", "invalid_sig_base64==")
