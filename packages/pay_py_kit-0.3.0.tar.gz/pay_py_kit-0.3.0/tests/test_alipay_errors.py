"""pay_kit.providers.alipay.errors 错误转换测试。"""

import httpx
import pytest

from pay_kit.exceptions import PaymentError, WithdrawError
from pay_kit.providers.alipay.errors import raise_for_error


class TestRaiseForError:
    def test_2xx_no_error(self) -> None:
        response = httpx.Response(200, json={"qr_code": "https://qr.alipay.com/xxx"})
        raise_for_error(response)

    def test_204_no_error(self) -> None:
        response = httpx.Response(204)
        raise_for_error(response)

    def test_4xx_json_error(self) -> None:
        response = httpx.Response(400, json={"code": "INVALID_PARAMETER", "message": "参数无效"})
        with pytest.raises(PaymentError) as exc_info:
            raise_for_error(response)
        assert exc_info.value.error_code == "INVALID_PARAMETER"
        assert "参数无效" in str(exc_info.value)
        assert exc_info.value.provider_name == "alipay"

    def test_4xx_json_missing_fields(self) -> None:
        response = httpx.Response(403, json={"error": "forbidden"})
        with pytest.raises(PaymentError) as exc_info:
            raise_for_error(response)
        assert exc_info.value.error_code is None
        assert "未知错误" in str(exc_info.value)

    def test_5xx_non_json(self) -> None:
        response = httpx.Response(502, text="<html>Bad Gateway</html>")
        with pytest.raises(PaymentError) as exc_info:
            raise_for_error(response)
        assert "HTTP 502" in str(exc_info.value)

    def test_5xx_json_error(self) -> None:
        response = httpx.Response(500, json={"code": "SYSTEM_ERROR", "message": "系统繁忙"})
        with pytest.raises(PaymentError) as exc_info:
            raise_for_error(response)
        assert exc_info.value.error_code == "SYSTEM_ERROR"


class TestRaiseForErrorWithCustomClass:
    def test_withdraw_error_class(self) -> None:
        response = httpx.Response(400, json={"code": "NO_AUTH", "message": "没有权限"})
        with pytest.raises(WithdrawError) as exc_info:
            raise_for_error(response, error_cls=WithdrawError)
        assert exc_info.value.error_code == "NO_AUTH"
        assert exc_info.value.provider_name == "alipay"

    def test_default_is_payment_error(self) -> None:
        response = httpx.Response(400, json={"code": "ERR", "message": "错误"})
        with pytest.raises(PaymentError):
            raise_for_error(response)
