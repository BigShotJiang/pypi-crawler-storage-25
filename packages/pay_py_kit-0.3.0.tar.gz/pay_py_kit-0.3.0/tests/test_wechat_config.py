"""pay_kit.providers.wechat.config 配置模型测试。"""

import pytest
from pydantic import SecretStr, ValidationError

from pay_kit.providers.wechat.config import WechatPayConfig


class TestWechatPayConfig:
    def test_create_config(self, merchant_private_pem: str, wechat_public_pem: str) -> None:
        config = WechatPayConfig(
            appid="wxd930ea5d5a258f4f",
            mch_id="1230000109",
            private_key=SecretStr(merchant_private_pem),
            cert_serial_no="SERIAL123",
            wechat_public_key=wechat_public_pem,
            wechat_public_key_id="PUB_KEY_ID_001",
            apiv3_key=SecretStr("test_apiv3_key_32chars_pad000000"),
            notify_url="https://example.com/callback",
        )
        assert config.appid == "wxd930ea5d5a258f4f"
        assert config.mch_id == "1230000109"
        assert config.notify_url == "https://example.com/callback"

    def test_private_key_is_secret(self, merchant_private_pem: str, wechat_public_pem: str) -> None:
        config = WechatPayConfig(
            appid="wx_test",
            mch_id="123",
            private_key=SecretStr(merchant_private_pem),
            cert_serial_no="SERIAL",
            wechat_public_key=wechat_public_pem,
            wechat_public_key_id="PUB_KEY_ID",
            apiv3_key=SecretStr("test_apiv3_key_32chars_pad000000"),
            notify_url="https://example.com/callback",
        )
        assert isinstance(config.private_key, SecretStr)
        assert "BEGIN" not in repr(config.private_key)
        assert config.private_key.get_secret_value() == merchant_private_pem

    def test_apiv3_key_is_secret(self, merchant_private_pem: str, wechat_public_pem: str) -> None:
        config = WechatPayConfig(
            appid="wx_test",
            mch_id="123",
            private_key=SecretStr(merchant_private_pem),
            cert_serial_no="SERIAL",
            wechat_public_key=wechat_public_pem,
            wechat_public_key_id="PUB_KEY_ID",
            apiv3_key=SecretStr("test_apiv3_key_32chars_pad000000"),
            notify_url="https://example.com/callback",
        )
        assert isinstance(config.apiv3_key, SecretStr)

    def test_wechat_public_key_is_plain_str(self, merchant_private_pem: str, wechat_public_pem: str) -> None:
        config = WechatPayConfig(
            appid="wx_test",
            mch_id="123",
            private_key=SecretStr(merchant_private_pem),
            cert_serial_no="SERIAL",
            wechat_public_key=wechat_public_pem,
            wechat_public_key_id="PUB_KEY_ID",
            apiv3_key=SecretStr("test_apiv3_key_32chars_pad000000"),
            notify_url="https://example.com/callback",
        )
        assert isinstance(config.wechat_public_key, str)
        assert "BEGIN PUBLIC KEY" in config.wechat_public_key

    def test_config_is_frozen(self, merchant_private_pem: str, wechat_public_pem: str) -> None:
        config = WechatPayConfig(
            appid="wx_test",
            mch_id="123",
            private_key=SecretStr(merchant_private_pem),
            cert_serial_no="SERIAL",
            wechat_public_key=wechat_public_pem,
            wechat_public_key_id="PUB_KEY_ID",
            apiv3_key=SecretStr("test_apiv3_key_32chars_pad000000"),
            notify_url="https://example.com/callback",
        )
        with pytest.raises(ValidationError):
            config.appid = "changed"

    def test_missing_required_field(self) -> None:
        with pytest.raises(ValidationError):
            WechatPayConfig(  # type: ignore[call-arg]
                appid="wx_test",
                mch_id="123",
                notify_url="https://example.com/callback",
            )
