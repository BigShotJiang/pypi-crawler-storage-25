"""pay_kit.providers Provider ABC 测试。"""

import pytest

from pay_kit.models import (
    BalanceResult,
    CallbackEvent,
    PaymentRequest,
    PaymentResult,
    RefundRequest,
    RefundResult,
    WithdrawRequest,
    WithdrawResult,
)
from pay_kit.providers import PayProvider, WalletProvider, WithdrawProvider
from pay_kit.types import Fen, PaymentStatus, RefundStatus, WithdrawStatus


class TestPayProviderABC:
    def test_cannot_instantiate(self) -> None:
        with pytest.raises(TypeError, match="abstract"):
            PayProvider()  # type: ignore[abstract]

    def test_concrete_implementation(self) -> None:
        class FakePayProvider(PayProvider):
            async def create_payment(self, request: PaymentRequest) -> PaymentResult:
                return PaymentResult(out_trade_no=request.out_trade_no, status=PaymentStatus.PENDING)

            async def query_payment(self, out_trade_no: str) -> PaymentResult:
                return PaymentResult(out_trade_no=out_trade_no, status=PaymentStatus.PAID)

            async def close_payment(self, out_trade_no: str) -> None:
                pass

            async def refund(self, request: RefundRequest) -> RefundResult:
                return RefundResult(out_refund_no=request.out_refund_no, status=RefundStatus.PENDING)

            async def query_refund(self, out_refund_no: str) -> RefundResult:
                return RefundResult(out_refund_no=out_refund_no, status=RefundStatus.SUCCESS)

            async def verify_callback(self, headers: dict[str, str], body: bytes) -> CallbackEvent:
                return CallbackEvent(event_type="payment.success", out_trade_no="T1", trade_no="X1", raw={})

        provider = FakePayProvider()
        assert isinstance(provider, PayProvider)

    def test_missing_method_raises(self) -> None:
        class IncompleteProvider(PayProvider):
            async def create_payment(self, request: PaymentRequest) -> PaymentResult:
                return PaymentResult(out_trade_no="T1", status=PaymentStatus.PENDING)

        with pytest.raises(TypeError):
            IncompleteProvider()  # type: ignore[abstract]


class TestWithdrawProviderABC:
    def test_cannot_instantiate(self) -> None:
        with pytest.raises(TypeError, match="abstract"):
            WithdrawProvider()  # type: ignore[abstract]

    def test_concrete_implementation(self) -> None:
        class FakeWithdrawProvider(WithdrawProvider):
            async def create_withdrawal(self, request: WithdrawRequest) -> WithdrawResult:
                return WithdrawResult(out_withdrawal_no=request.out_withdrawal_no, status=WithdrawStatus.PENDING)

            async def query_withdrawal(self, out_withdrawal_no: str) -> WithdrawResult:
                return WithdrawResult(out_withdrawal_no=out_withdrawal_no, status=WithdrawStatus.SUCCESS)

        provider = FakeWithdrawProvider()
        assert isinstance(provider, WithdrawProvider)


class TestWalletProviderABC:
    def test_cannot_instantiate(self) -> None:
        with pytest.raises(TypeError, match="abstract"):
            WalletProvider()  # type: ignore[abstract]

    def test_concrete_implementation(self) -> None:
        class FakeWalletProvider(WalletProvider):
            async def query_balance(self) -> BalanceResult:
                return BalanceResult(available=Fen(10000), pending=Fen(500))

        provider = FakeWalletProvider()
        assert isinstance(provider, WalletProvider)


class TestMultiInheritance:
    def test_combined_provider(self) -> None:
        class FakeFullProvider(PayProvider, WithdrawProvider, WalletProvider):
            async def create_payment(self, request: PaymentRequest) -> PaymentResult:
                return PaymentResult(out_trade_no="T1", status=PaymentStatus.PENDING)

            async def query_payment(self, out_trade_no: str) -> PaymentResult:
                return PaymentResult(out_trade_no=out_trade_no, status=PaymentStatus.PAID)

            async def close_payment(self, out_trade_no: str) -> None:
                pass

            async def refund(self, request: RefundRequest) -> RefundResult:
                return RefundResult(out_refund_no="R1", status=RefundStatus.PENDING)

            async def query_refund(self, out_refund_no: str) -> RefundResult:
                return RefundResult(out_refund_no=out_refund_no, status=RefundStatus.SUCCESS)

            async def verify_callback(self, headers: dict[str, str], body: bytes) -> CallbackEvent:
                return CallbackEvent(event_type="payment.success", out_trade_no="T1", trade_no="X1", raw={})

            async def create_withdrawal(self, request: WithdrawRequest) -> WithdrawResult:
                return WithdrawResult(out_withdrawal_no="W1", status=WithdrawStatus.PENDING)

            async def query_withdrawal(self, out_withdrawal_no: str) -> WithdrawResult:
                return WithdrawResult(out_withdrawal_no=out_withdrawal_no, status=WithdrawStatus.SUCCESS)

            async def query_balance(self) -> BalanceResult:
                return BalanceResult(available=Fen(10000), pending=Fen(500))

        provider = FakeFullProvider()
        assert isinstance(provider, PayProvider)
        assert isinstance(provider, WithdrawProvider)
        assert isinstance(provider, WalletProvider)
