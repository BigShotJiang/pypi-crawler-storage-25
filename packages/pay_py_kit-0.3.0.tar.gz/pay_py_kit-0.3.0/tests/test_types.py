"""pay_kit.types 类型和枚举测试。"""

from pay_kit.types import (
    Fen,
    PaymentStatus,
    RefundStatus,
    WithdrawStatus,
    Yuan,
    fen_to_yuan,
    yuan_to_fen,
)


def test_fen_is_int() -> None:
    amount = Fen(100)
    assert amount == 100
    assert isinstance(amount, int)


def test_fen_arithmetic() -> None:
    a = Fen(100)
    b = Fen(200)
    assert a + b == 300


def test_payment_status_values() -> None:
    assert PaymentStatus.PENDING.value == "pending"
    assert PaymentStatus.PAID.value == "paid"
    assert PaymentStatus.CLOSED.value == "closed"
    assert PaymentStatus.REFUNDING.value == "refunding"
    assert PaymentStatus.REFUNDED.value == "refunded"


def test_payment_status_is_str() -> None:
    assert isinstance(PaymentStatus.PAID, str)


def test_refund_status_values() -> None:
    assert RefundStatus.PENDING.value == "pending"
    assert RefundStatus.SUCCESS.value == "success"
    assert RefundStatus.FAILED.value == "failed"


def test_withdraw_status_values() -> None:
    assert WithdrawStatus.PENDING.value == "pending"
    assert WithdrawStatus.SUCCESS.value == "success"
    assert WithdrawStatus.FAILED.value == "failed"


def test_yuan_is_str() -> None:
    amount = Yuan("1.00")
    assert amount == "1.00"
    assert isinstance(amount, str)


def test_fen_to_yuan_basic() -> None:
    assert fen_to_yuan(Fen(100)) == "1.00"
    assert fen_to_yuan(Fen(1)) == "0.01"
    assert fen_to_yuan(Fen(0)) == "0.00"
    assert fen_to_yuan(Fen(1050)) == "10.50"
    assert fen_to_yuan(Fen(99999)) == "999.99"


def test_yuan_to_fen_basic() -> None:
    assert yuan_to_fen(Yuan("1.00")) == 100
    assert yuan_to_fen(Yuan("0.01")) == 1
    assert yuan_to_fen(Yuan("0.00")) == 0
    assert yuan_to_fen(Yuan("10.50")) == 1050
    assert yuan_to_fen(Yuan("999.99")) == 99999


def test_fen_yuan_roundtrip() -> None:
    for fen_val in [0, 1, 50, 100, 333, 1050, 99999]:
        assert yuan_to_fen(fen_to_yuan(Fen(fen_val))) == fen_val
