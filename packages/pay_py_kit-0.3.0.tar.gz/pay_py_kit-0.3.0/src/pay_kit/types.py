"""pay-kit 类型定义。"""

from decimal import Decimal
from enum import StrEnum
from typing import NewType

Fen = NewType("Fen", int)
"""金额类型，单位为分。"""

Yuan = NewType("Yuan", str)
"""金额类型，单位为元（两位小数字符串）。"""


def fen_to_yuan(amount: Fen) -> Yuan:
    """分转元。Fen(100) → Yuan("1.00")。使用 Decimal 精确计算。"""
    return Yuan(f"{Decimal(int(amount)) / 100:.2f}")


def yuan_to_fen(amount: Yuan) -> Fen:
    """元转分。Yuan("1.00") → Fen(100)。使用 Decimal 精确计算。"""
    return Fen(int(Decimal(amount) * 100))


class PaymentStatus(StrEnum):
    """支付状态。"""

    PENDING = "pending"
    PAID = "paid"
    CLOSED = "closed"
    REFUNDING = "refunding"
    REFUNDED = "refunded"


class RefundStatus(StrEnum):
    """退款状态。"""

    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"


class WithdrawStatus(StrEnum):
    """提现状态。"""

    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"
