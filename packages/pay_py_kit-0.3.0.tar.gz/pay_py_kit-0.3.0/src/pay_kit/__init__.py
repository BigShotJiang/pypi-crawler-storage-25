"""pay-kit: 统一支付基础设施 SDK。"""

__version__ = "0.3.0"
