"""pay-kit 数据模型。"""

from typing import Any

from pydantic import BaseModel, ConfigDict

from pay_kit.types import (
    Fen,
    PaymentStatus,
    RefundStatus,
    WithdrawStatus,
)


class BaseProviderConfig(BaseModel):
    """支付商通用配置基类。"""

    notify_url: str

    model_config = ConfigDict(frozen=True)


class PaymentRequest(BaseModel):
    """支付下单请求。"""

    out_trade_no: str
    total_amount: Fen
    subject: str


class PaymentResult(BaseModel):
    """支付结果。"""

    out_trade_no: str
    trade_no: str | None = None
    status: PaymentStatus
    credential: dict[str, Any] | None = None


class RefundRequest(BaseModel):
    """退款请求。"""

    out_trade_no: str
    out_refund_no: str
    total_amount: Fen
    refund_amount: Fen


class RefundResult(BaseModel):
    """退款结果。"""

    out_refund_no: str
    status: RefundStatus


class WithdrawRequest(BaseModel):
    """提现请求。"""

    out_withdrawal_no: str
    amount: Fen
    recipient: str
    description: str


class WithdrawResult(BaseModel):
    """提现结果。"""

    out_withdrawal_no: str
    status: WithdrawStatus


class BalanceResult(BaseModel):
    """余额查询结果。"""

    available: Fen
    pending: Fen


class CallbackEvent(BaseModel):
    """回调事件。"""

    event_type: str
    out_trade_no: str
    trade_no: str
    raw: dict[str, Any]
