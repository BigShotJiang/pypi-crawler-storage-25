"""pay-kit 异常体系。"""


class PayKitError(Exception):
    """pay-kit 所有异常的基类。"""


class ConfigError(PayKitError):
    """配置错误（缺少字段、格式错误、证书无效）。"""


class ProviderError(PayKitError):
    """支付商业务错误的父类。"""

    def __init__(
        self,
        message: str,
        *,
        error_code: str | None = None,
        provider_name: str | None = None,
    ) -> None:
        super().__init__(message)
        self.error_code = error_code
        self.provider_name = provider_name


class PaymentError(ProviderError):
    """支付失败（下单、查询、关单、退款）。"""


class WithdrawError(ProviderError):
    """提现失败。"""


class WalletError(ProviderError):
    """钱包操作失败。"""


class SignatureError(PayKitError):
    """签名/验签失败。"""


class NetworkError(PayKitError):
    """网络层错误（超时、连接失败）。"""
