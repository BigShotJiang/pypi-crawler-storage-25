"""pay-kit Provider 抽象基类。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Self

from pay_kit.models import (
    BalanceResult,
    CallbackEvent,
    PaymentRequest,
    PaymentResult,
    RefundRequest,
    RefundResult,
    WithdrawRequest,
    WithdrawResult,
)
from pay_kit.providers.http_client import BaseHttpClient


class PayProvider(ABC):
    """支付能力接口。"""

    @abstractmethod
    async def create_payment(self, request: PaymentRequest) -> PaymentResult:
        """创建支付订单。"""

    @abstractmethod
    async def query_payment(self, out_trade_no: str) -> PaymentResult:
        """查询支付订单状态。"""

    @abstractmethod
    async def close_payment(self, out_trade_no: str) -> None:
        """关闭未支付的订单。"""

    @abstractmethod
    async def refund(self, request: RefundRequest) -> RefundResult:
        """发起退款。"""

    @abstractmethod
    async def query_refund(self, out_refund_no: str) -> RefundResult:
        """查询退款状态。"""

    @abstractmethod
    async def verify_callback(self, headers: dict[str, str], body: bytes) -> CallbackEvent:
        """验证支付商回调签名并解析回调数据。"""


class WithdrawProvider(ABC):
    """提现能力接口。"""

    @abstractmethod
    async def create_withdrawal(self, request: WithdrawRequest) -> WithdrawResult:
        """发起提现。"""

    @abstractmethod
    async def query_withdrawal(self, out_withdrawal_no: str) -> WithdrawResult:
        """查询提现状态。"""


class WalletProvider(ABC):
    """钱包/余额查询接口。"""

    @abstractmethod
    async def query_balance(self) -> BalanceResult:
        """查询商户余额。"""


class AsyncProvider:
    """Provider 生命周期管理 mixin。子类须定义 _http: BaseHttpClient。"""

    _http: BaseHttpClient

    async def close(self) -> None:
        """关闭 HTTP 客户端。"""
        await self._http.close()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()
