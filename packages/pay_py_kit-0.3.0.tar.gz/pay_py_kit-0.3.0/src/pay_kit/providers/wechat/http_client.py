"""微信支付 V3 HTTP 客户端。"""

from __future__ import annotations

import secrets
import time
from typing import Any
from urllib.parse import urlparse

import httpx

from pay_kit.exceptions import SignatureError
from pay_kit.providers.http_client import BaseHttpClient
from pay_kit.providers.wechat.config import WechatPayConfig
from pay_kit.providers.wechat.sign import (
    build_sign_string,
    build_verify_string,
    load_private_key,
    load_public_key,
    sign,
    verify,
)

BASE_URL = "https://api.mch.weixin.qq.com"


class WechatHttpClient(BaseHttpClient):
    """微信支付 V3 HTTP 客户端。

    职责：请求签名、响应验签、密钥缓存。
    不关心业务逻辑，只关心 HTTP + 密码学。
    """

    def __init__(
        self,
        config: WechatPayConfig,
        *,
        timeout: float = 30.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._private_key = load_private_key(config.private_key.get_secret_value())
        self._wechat_public_key = load_public_key(config.wechat_public_key)
        super().__init__(config, timeout=timeout, transport=transport)
        self._mch_id = config.mch_id
        self._cert_serial_no = config.cert_serial_no
        self._wechat_public_key_id = config.wechat_public_key_id

    async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """签名请求 → 发送 → 验签响应。"""
        body = self._prepare_json_body(kwargs)

        timestamp = str(int(time.time()))
        nonce_str = secrets.token_hex(16)

        parsed = urlparse(url)
        url_path = parsed.path
        if parsed.query:
            url_path = f"{url_path}?{parsed.query}"

        sign_string = build_sign_string(method, url_path, timestamp, nonce_str, body)
        signature = sign(sign_string, self._private_key)

        auth_header = (
            f'WECHATPAY2-SHA256-RSA2048 mchid="{self._mch_id}",'
            f'nonce_str="{nonce_str}",timestamp="{timestamp}",'
            f'serial_no="{self._cert_serial_no}",signature="{signature}"'
        )
        headers = kwargs.get("headers", {})
        headers["Authorization"] = auth_header
        kwargs["headers"] = headers

        response = await super().request(method, url, **kwargs)
        self._verify_response(response)
        return response

    def verify_signature(
        self,
        timestamp: str,
        nonce: str,
        body: str,
        signature_b64: str,
        serial: str,
    ) -> None:
        """验证微信签名（响应验签/回调验签通用）。失败抛 SignatureError。"""
        if serial != self._wechat_public_key_id:
            raise SignatureError(f"公钥 ID 不匹配: 期望 {self._wechat_public_key_id}, 实际 {serial}")
        verify_string = build_verify_string(timestamp, nonce, body)
        if not verify(verify_string, signature_b64, self._wechat_public_key):
            raise SignatureError("签名验证失败")

    def sign_data(self, data: str) -> str:
        """用商户私钥签名。返回 Base64 编码结果。"""
        return sign(data, self._private_key)

    def _verify_response(self, response: httpx.Response) -> None:
        """验证响应签名。"""
        timestamp = response.headers.get("Wechatpay-Timestamp")
        nonce = response.headers.get("Wechatpay-Nonce")
        signature = response.headers.get("Wechatpay-Signature")
        serial = response.headers.get("Wechatpay-Serial")

        if timestamp is None or nonce is None or signature is None or serial is None:
            if response.is_success:
                raise SignatureError("2xx 响应缺少签名头")
            return

        self.verify_signature(timestamp, nonce, response.text, signature, serial)
