"""微信支付 V3 配置。"""

from pydantic import SecretStr

from pay_kit.models import BaseProviderConfig


class WechatPayConfig(BaseProviderConfig):
    """微信支付 V3 配置。"""

    appid: str
    mch_id: str
    private_key: SecretStr
    cert_serial_no: str
    wechat_public_key: str
    wechat_public_key_id: str
    apiv3_key: SecretStr
