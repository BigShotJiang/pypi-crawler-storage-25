"""微信支付 V3 签名/验签/解密。"""

import base64

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from pay_kit.exceptions import SignatureError
from pay_kit.providers.crypto import (
    build_verify_string as build_verify_string,
)
from pay_kit.providers.crypto import (
    load_private_key as load_private_key,
)
from pay_kit.providers.crypto import (
    load_public_key as load_public_key,
)
from pay_kit.providers.crypto import (
    sign as sign,
)
from pay_kit.providers.crypto import (
    verify as verify,
)

__all__ = [
    "build_sign_string",
    "build_verify_string",
    "decrypt_callback",
    "load_private_key",
    "load_public_key",
    "sign",
    "verify",
]


def build_sign_string(
    method: str,
    url_path: str,
    timestamp: str,
    nonce_str: str,
    body: str,
) -> str:
    """构造请求待签名字符串。"""
    return f"{method}\n{url_path}\n{timestamp}\n{nonce_str}\n{body}\n"


def decrypt_callback(
    ciphertext_b64: str,
    nonce: str,
    associated_data: str,
    apiv3_key: str,
) -> str:
    """AES-256-GCM 解密回调通知数据。解密失败抛 SignatureError。"""
    try:
        aesgcm = AESGCM(apiv3_key.encode())
        plaintext = aesgcm.decrypt(
            nonce.encode(),
            base64.b64decode(ciphertext_b64),
            associated_data.encode() if associated_data else None,
        )
    except (InvalidTag, ValueError) as e:
        raise SignatureError(f"回调数据解密失败: {e}") from e
    return plaintext.decode()
