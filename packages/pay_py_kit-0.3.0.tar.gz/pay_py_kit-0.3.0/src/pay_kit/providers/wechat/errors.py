"""微信支付 V3 错误转换。"""

from functools import partial

from pay_kit.providers.errors import raise_for_error as _raise_for_error

raise_for_error = partial(_raise_for_error, provider_name="wechat")
