"""微信支付 V3 Native 支付 Provider。"""

from __future__ import annotations

import json
import secrets
import time
from typing import Any

import httpx

from pay_kit.exceptions import PaymentError, SignatureError, WalletError, WithdrawError
from pay_kit.models import (
    BalanceResult,
    CallbackEvent,
    PaymentRequest,
    PaymentResult,
    RefundRequest,
    RefundResult,
    WithdrawRequest,
    WithdrawResult,
)
from pay_kit.providers.base import AsyncProvider, PayProvider, WalletProvider, WithdrawProvider
from pay_kit.providers.status import resolve_status
from pay_kit.providers.wechat.config import WechatPayConfig
from pay_kit.providers.wechat.errors import raise_for_error
from pay_kit.providers.wechat.http_client import BASE_URL, WechatHttpClient
from pay_kit.providers.wechat.sign import decrypt_callback
from pay_kit.types import Fen, PaymentStatus, RefundStatus, WithdrawStatus

_PAYMENT_STATUS_MAP: dict[str, PaymentStatus] = {
    "SUCCESS": PaymentStatus.PAID,
    "NOTPAY": PaymentStatus.PENDING,
    "USERPAYING": PaymentStatus.PENDING,
    "CLOSED": PaymentStatus.CLOSED,
    "PAYERROR": PaymentStatus.CLOSED,
    "REFUND": PaymentStatus.REFUNDING,
    "REVOKED": PaymentStatus.CLOSED,
}

_REFUND_STATUS_MAP: dict[str, RefundStatus] = {
    "SUCCESS": RefundStatus.SUCCESS,
    "PROCESSING": RefundStatus.PENDING,
    "CLOSED": RefundStatus.FAILED,
    "ABNORMAL": RefundStatus.FAILED,
}

_WITHDRAW_STATUS_MAP: dict[str, WithdrawStatus] = {
    "INIT": WithdrawStatus.PENDING,
    "PROCESSING": WithdrawStatus.PENDING,
    "SUCCESS": WithdrawStatus.SUCCESS,
    "FAIL": WithdrawStatus.FAILED,
}


_PROVIDER_NAME = "wechat"


class WechatPay(AsyncProvider, PayProvider, WithdrawProvider, WalletProvider):
    """微信支付 V3 Native 支付 + 转账 + 余额查询实现。"""

    _http: WechatHttpClient

    def __init__(
        self,
        config: WechatPayConfig,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._http = WechatHttpClient(config, transport=transport)
        self._appid = config.appid
        self._mch_id = config.mch_id
        self._notify_url = config.notify_url
        self._apiv3_key = config.apiv3_key.get_secret_value()

    def _build_payment_payload(self, request: PaymentRequest) -> dict[str, Any]:
        """构造支付请求通用 payload。"""
        return {
            "appid": self._appid,
            "mchid": self._mch_id,
            "description": request.subject,
            "out_trade_no": request.out_trade_no,
            "notify_url": self._notify_url,
            "amount": {"total": request.total_amount},
        }

    async def create_payment(self, request: PaymentRequest) -> PaymentResult:
        """POST /v3/pay/transactions/native"""
        payload = self._build_payment_payload(request)
        response = await self._http.request("POST", f"{BASE_URL}/v3/pay/transactions/native", json=payload)
        raise_for_error(response)
        data = response.json()
        return PaymentResult(
            out_trade_no=request.out_trade_no,
            status=PaymentStatus.PENDING,
            credential={"code_url": data["code_url"]},
        )

    async def create_jsapi_payment(
        self,
        request: PaymentRequest,
        *,
        openid: str,
    ) -> PaymentResult:
        """JSAPI 公众号/小程序支付。返回前端 wx.requestPayment() 所需参数。"""
        payload = self._build_payment_payload(request)
        payload["payer"] = {"openid": openid}
        response = await self._http.request("POST", f"{BASE_URL}/v3/pay/transactions/jsapi", json=payload)
        raise_for_error(response)
        data = response.json()
        prepay_id = data["prepay_id"]

        timestamp = str(int(time.time()))
        nonce_str = secrets.token_hex(16)
        package = f"prepay_id={prepay_id}"
        sign_string = f"{self._appid}\n{timestamp}\n{nonce_str}\n{package}\n"
        pay_sign = self._http.sign_data(sign_string)

        return PaymentResult(
            out_trade_no=request.out_trade_no,
            status=PaymentStatus.PENDING,
            credential={
                "appId": self._appid,
                "timeStamp": timestamp,
                "nonceStr": nonce_str,
                "package": package,
                "signType": "RSA",
                "paySign": pay_sign,
            },
        )

    async def create_h5_payment(
        self,
        request: PaymentRequest,
        *,
        payer_client_ip: str,
    ) -> PaymentResult:
        """H5 手机浏览器支付。返回跳转 URL。"""
        payload = self._build_payment_payload(request)
        payload["scene_info"] = {
            "payer_client_ip": payer_client_ip,
            "h5_info": {"type": "Wap"},
        }
        response = await self._http.request("POST", f"{BASE_URL}/v3/pay/transactions/h5", json=payload)
        raise_for_error(response)
        data = response.json()
        return PaymentResult(
            out_trade_no=request.out_trade_no,
            status=PaymentStatus.PENDING,
            credential={"h5_url": data["h5_url"]},
        )

    async def create_app_payment(self, request: PaymentRequest) -> PaymentResult:
        """App 支付。返回移动端 SDK 所需参数。"""
        payload = self._build_payment_payload(request)
        response = await self._http.request("POST", f"{BASE_URL}/v3/pay/transactions/app", json=payload)
        raise_for_error(response)
        data = response.json()
        prepay_id = data["prepay_id"]

        timestamp = str(int(time.time()))
        nonce_str = secrets.token_hex(16)
        sign_string = f"{self._appid}\n{timestamp}\n{nonce_str}\nprepay_id={prepay_id}\n"
        pay_sign = self._http.sign_data(sign_string)

        return PaymentResult(
            out_trade_no=request.out_trade_no,
            status=PaymentStatus.PENDING,
            credential={
                "appId": self._appid,
                "partnerId": self._mch_id,
                "prepayId": prepay_id,
                "package": "Sign=WXPay",
                "nonceStr": nonce_str,
                "timeStamp": timestamp,
                "sign": pay_sign,
            },
        )

    async def query_payment(self, out_trade_no: str) -> PaymentResult:
        """GET /v3/pay/transactions/out-trade-no/{out_trade_no}?mchid={mchid}"""
        response = await self._http.request(
            "GET",
            f"{BASE_URL}/v3/pay/transactions/out-trade-no/{out_trade_no}?mchid={self._mch_id}",
        )
        raise_for_error(response)
        data = response.json()
        status = resolve_status(
            data["trade_state"],
            _PAYMENT_STATUS_MAP,
            label="支付状态",
            error_cls=PaymentError,
            provider_name=_PROVIDER_NAME,
        )
        return PaymentResult(
            out_trade_no=out_trade_no,
            trade_no=data.get("transaction_id"),
            status=status,
        )

    async def close_payment(self, out_trade_no: str) -> None:
        """POST /v3/pay/transactions/out-trade-no/{out_trade_no}/close"""
        response = await self._http.request(
            "POST",
            f"{BASE_URL}/v3/pay/transactions/out-trade-no/{out_trade_no}/close",
            json={"mchid": self._mch_id},
        )
        raise_for_error(response)

    async def refund(self, request: RefundRequest) -> RefundResult:
        """POST /v3/refund/domestic/refunds"""
        payload: dict[str, Any] = {
            "out_trade_no": request.out_trade_no,
            "out_refund_no": request.out_refund_no,
            "amount": {
                "refund": request.refund_amount,
                "total": request.total_amount,
            },
        }
        response = await self._http.request("POST", f"{BASE_URL}/v3/refund/domestic/refunds", json=payload)
        raise_for_error(response)
        data = response.json()
        status = resolve_status(
            data["status"], _REFUND_STATUS_MAP, label="退款状态", error_cls=PaymentError, provider_name=_PROVIDER_NAME
        )
        return RefundResult(
            out_refund_no=request.out_refund_no,
            status=status,
        )

    async def query_refund(self, out_refund_no: str) -> RefundResult:
        """GET /v3/refund/domestic/refunds/{out_refund_no}"""
        response = await self._http.request("GET", f"{BASE_URL}/v3/refund/domestic/refunds/{out_refund_no}")
        raise_for_error(response)
        data = response.json()
        status = resolve_status(
            data["status"], _REFUND_STATUS_MAP, label="退款状态", error_cls=PaymentError, provider_name=_PROVIDER_NAME
        )
        return RefundResult(
            out_refund_no=out_refund_no,
            status=status,
        )

    async def verify_callback(self, headers: dict[str, str], body: bytes) -> CallbackEvent:
        """验签 → 解密 → 解析回调数据。"""
        body_str = body.decode("utf-8")
        normalized = {k.lower(): v for k, v in headers.items()}
        try:
            timestamp = normalized["wechatpay-timestamp"]
            nonce = normalized["wechatpay-nonce"]
            signature = normalized["wechatpay-signature"]
            serial = normalized["wechatpay-serial"]
        except KeyError as e:
            raise SignatureError(f"缺少回调签名头: {e}") from e

        self._http.verify_signature(timestamp, nonce, body_str, signature, serial)

        outer = json.loads(body_str)
        resource = outer["resource"]
        decrypted = decrypt_callback(
            ciphertext_b64=resource["ciphertext"],
            nonce=resource["nonce"],
            associated_data=resource.get("associated_data", ""),
            apiv3_key=self._apiv3_key,
        )
        inner = json.loads(decrypted)
        return CallbackEvent(
            event_type=outer["event_type"],
            out_trade_no=inner["out_trade_no"],
            trade_no=inner["transaction_id"],
            raw=inner,
        )

    async def create_withdrawal(self, request: WithdrawRequest) -> WithdrawResult:
        """POST /v3/transfer/batches（单笔批次封装）"""
        payload: dict[str, Any] = {
            "appid": self._appid,
            "out_batch_no": request.out_withdrawal_no,
            "batch_name": request.description,
            "batch_remark": request.description,
            "total_amount": request.amount,
            "total_num": 1,
            "transfer_detail_list": [
                {
                    "out_detail_no": request.out_withdrawal_no,
                    "transfer_amount": request.amount,
                    "transfer_remark": request.description,
                    "openid": request.recipient,
                }
            ],
        }
        response = await self._http.request("POST", f"{BASE_URL}/v3/transfer/batches", json=payload)
        raise_for_error(response, error_cls=WithdrawError)
        return WithdrawResult(
            out_withdrawal_no=request.out_withdrawal_no,
            status=WithdrawStatus.PENDING,
        )

    async def query_withdrawal(self, out_withdrawal_no: str) -> WithdrawResult:
        """GET /v3/transfer/batches/out-batch-no/{no}/details/out-detail-no/{no}"""
        url = (
            f"{BASE_URL}/v3/transfer/batches/out-batch-no/{out_withdrawal_no}/details/out-detail-no/{out_withdrawal_no}"
        )
        response = await self._http.request("GET", url)
        raise_for_error(response, error_cls=WithdrawError)
        data = response.json()
        status = resolve_status(
            data["detail_status"],
            _WITHDRAW_STATUS_MAP,
            label="转账状态",
            error_cls=WithdrawError,
            provider_name=_PROVIDER_NAME,
        )
        return WithdrawResult(
            out_withdrawal_no=out_withdrawal_no,
            status=status,
        )

    async def query_balance(self) -> BalanceResult:
        """GET /v3/merchant/fund/balance/BASIC"""
        response = await self._http.request("GET", f"{BASE_URL}/v3/merchant/fund/balance/BASIC")
        raise_for_error(response, error_cls=WalletError)
        data = response.json()
        return BalanceResult(
            available=Fen(data["available_amount"]),
            pending=Fen(data["pending_amount"]),
        )
