"""pay-kit HTTP 客户端基类。"""

from __future__ import annotations

import json
from typing import Any, Self

import httpx

from pay_kit.exceptions import NetworkError
from pay_kit.models import BaseProviderConfig


class BaseHttpClient:
    """支付商 HTTP 客户端基类。

    管理 httpx.AsyncClient 生命周期。仅转换传输层错误（超时、连接失败）
    为 NetworkError，业务错误（HTTP 4xx/5xx、业务错误码）留给 Provider 层处理。
    """

    def __init__(
        self,
        config: BaseProviderConfig,
        *,
        timeout: float = 30.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._client = httpx.AsyncClient(timeout=timeout, transport=transport)

    @staticmethod
    def _prepare_json_body(kwargs: dict[str, Any]) -> str:
        """从 kwargs 提取 json 参数，序列化并设置 content/Content-Type。返回 body 字符串。"""
        if "json" not in kwargs:
            return ""
        json_data = kwargs.pop("json")
        body = json.dumps(json_data, ensure_ascii=False)
        kwargs["content"] = body.encode("utf-8")
        headers = kwargs.get("headers", {})
        headers["Content-Type"] = "application/json"
        kwargs["headers"] = headers
        return body

    async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """发送 HTTP 请求。子类可重写以添加签名逻辑。"""
        try:
            return await self._client.request(method, url, **kwargs)
        except httpx.TimeoutException as e:
            raise NetworkError(f"请求超时: {url}") from e
        except httpx.ConnectError as e:
            raise NetworkError(f"连接失败: {url}") from e
        except httpx.HTTPError as e:
            raise NetworkError(f"HTTP 错误: {url}: {e}") from e

    async def close(self) -> None:
        """关闭 HTTP 客户端，释放连接池。"""
        await self._client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()
