"""pay-kit 状态映射工具。"""

from typing import TypeVar

from pay_kit.exceptions import ProviderError

_T = TypeVar("_T")


def resolve_status(
    raw: str,
    mapping: dict[str, _T],
    *,
    label: str,
    error_cls: type[ProviderError],
    provider_name: str,
) -> _T:
    """查状态映射表，未匹配则抛出带上下文的 ProviderError。"""
    result = mapping.get(raw)
    if result is None:
        raise error_cls(
            f"未知{label}: {raw}",
            error_code=raw,
            provider_name=provider_name,
        )
    return result
