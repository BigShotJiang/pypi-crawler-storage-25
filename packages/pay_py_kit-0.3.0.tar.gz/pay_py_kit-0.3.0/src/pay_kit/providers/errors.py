"""pay-kit 共享错误转换。"""

import httpx

from pay_kit.exceptions import PaymentError, ProviderError


def raise_for_error(
    response: httpx.Response,
    *,
    error_cls: type[ProviderError] = PaymentError,
    provider_name: str,
) -> None:
    """非 2xx 响应抛出指定异常类。"""
    if response.is_success:
        return
    try:
        data = response.json()
        message = data.get("message", "未知错误")
        code = data.get("code")
    except (ValueError, AttributeError):
        message = f"HTTP {response.status_code}"
        code = None
    raise error_cls(message, error_code=code, provider_name=provider_name)
