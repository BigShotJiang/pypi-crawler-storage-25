"""支付宝 V3 当面付 Provider。"""

from __future__ import annotations

import json
from typing import Any

import httpx

from pay_kit.exceptions import PaymentError, SignatureError, WalletError, WithdrawError
from pay_kit.models import (
    BalanceResult,
    CallbackEvent,
    PaymentRequest,
    PaymentResult,
    RefundRequest,
    RefundResult,
    WithdrawRequest,
    WithdrawResult,
)
from pay_kit.providers.alipay.config import AlipayConfig
from pay_kit.providers.alipay.errors import raise_for_error
from pay_kit.providers.alipay.http_client import BASE_URL, AlipayHttpClient
from pay_kit.providers.base import AsyncProvider, PayProvider, WalletProvider, WithdrawProvider
from pay_kit.providers.status import resolve_status
from pay_kit.types import (
    PaymentStatus,
    RefundStatus,
    WithdrawStatus,
    Yuan,
    fen_to_yuan,
    yuan_to_fen,
)

_TRADE_STATUS_MAP: dict[str, PaymentStatus] = {
    "TRADE_SUCCESS": PaymentStatus.PAID,
    "WAIT_BUYER_PAY": PaymentStatus.PENDING,
    "TRADE_CLOSED": PaymentStatus.CLOSED,
    "TRADE_FINISHED": PaymentStatus.PAID,
}

_REFUND_STATUS_MAP: dict[str, RefundStatus] = {
    "REFUND_SUCCESS": RefundStatus.SUCCESS,
}

_WITHDRAW_STATUS_MAP: dict[str, WithdrawStatus] = {
    "SUCCESS": WithdrawStatus.SUCCESS,
    "DEALING": WithdrawStatus.PENDING,
    "FAIL": WithdrawStatus.FAILED,
    "REFUND": WithdrawStatus.FAILED,
}


_PROVIDER_NAME = "alipay"


class Alipay(AsyncProvider, PayProvider, WithdrawProvider, WalletProvider):
    """支付宝 V3 当面付 + 转账 + 余额查询实现。"""

    _http: AlipayHttpClient

    def __init__(
        self,
        config: AlipayConfig,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._http = AlipayHttpClient(config, transport=transport)
        self._app_id = config.app_id
        self._notify_url = config.notify_url

    # --- PayProvider ---

    def _build_payment_payload(self, request: PaymentRequest) -> dict[str, Any]:
        """构造支付请求通用 payload。"""
        return {
            "out_trade_no": request.out_trade_no,
            "total_amount": fen_to_yuan(request.total_amount),
            "subject": request.subject,
            "notify_url": self._notify_url,
        }

    async def create_payment(self, request: PaymentRequest) -> PaymentResult:
        """POST /v3/alipay/trade/precreate"""
        payload = self._build_payment_payload(request)
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/trade/precreate", json=payload)
        raise_for_error(response)
        data = response.json()
        return PaymentResult(
            out_trade_no=request.out_trade_no,
            status=PaymentStatus.PENDING,
            credential={"qr_code": data["qr_code"]},
        )

    async def create_page_payment(
        self,
        request: PaymentRequest,
        *,
        return_url: str,
    ) -> PaymentResult:
        """电脑网站支付。返回支付页面跳转 URL。"""
        return await self._create_redirect_payment(
            request, return_url=return_url, product_code="FAST_INSTANT_TRADE_PAY", path="/v3/alipay/trade/page/pay"
        )

    async def create_wap_payment(
        self,
        request: PaymentRequest,
        *,
        return_url: str,
    ) -> PaymentResult:
        """手机网站支付。返回跳转 URL。"""
        return await self._create_redirect_payment(
            request, return_url=return_url, product_code="QUICK_WAP_WAY", path="/v3/alipay/trade/wap/pay"
        )

    async def _create_redirect_payment(
        self,
        request: PaymentRequest,
        *,
        return_url: str,
        product_code: str,
        path: str,
    ) -> PaymentResult:
        """通用跳转类支付（page/wap 共用）。"""
        payload = self._build_payment_payload(request)
        payload["product_code"] = product_code
        payload["return_url"] = return_url
        response = await self._http.request("POST", f"{BASE_URL}{path}", json=payload)
        raise_for_error(response)
        data = response.json()
        return PaymentResult(
            out_trade_no=request.out_trade_no,
            status=PaymentStatus.PENDING,
            credential={"pay_url": data["pay_url"]},
        )

    async def create_app_payment(self, request: PaymentRequest) -> PaymentResult:
        """App 支付。返回移动端 SDK 所需的订单字符串。"""
        payload = self._build_payment_payload(request)
        payload["product_code"] = "QUICK_MSECURITY_PAY"
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/trade/app/pay", json=payload)
        raise_for_error(response)
        data = response.json()
        return PaymentResult(
            out_trade_no=request.out_trade_no,
            status=PaymentStatus.PENDING,
            credential={"order_str": data["order_str"]},
        )

    async def query_payment(self, out_trade_no: str) -> PaymentResult:
        """POST /v3/alipay/trade/query"""
        payload: dict[str, Any] = {"out_trade_no": out_trade_no}
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/trade/query", json=payload)
        raise_for_error(response)
        data = response.json()
        status = resolve_status(
            data["trade_status"],
            _TRADE_STATUS_MAP,
            label="交易状态",
            error_cls=PaymentError,
            provider_name=_PROVIDER_NAME,
        )
        return PaymentResult(
            out_trade_no=out_trade_no,
            trade_no=data.get("trade_no"),
            status=status,
        )

    async def close_payment(self, out_trade_no: str) -> None:
        """POST /v3/alipay/trade/close"""
        payload: dict[str, Any] = {"out_trade_no": out_trade_no}
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/trade/close", json=payload)
        raise_for_error(response)

    async def refund(self, request: RefundRequest) -> RefundResult:
        """POST /v3/alipay/trade/refund"""
        payload: dict[str, Any] = {
            "out_trade_no": request.out_trade_no,
            "refund_amount": fen_to_yuan(request.refund_amount),
            "out_request_no": request.out_refund_no,
        }
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/trade/refund", json=payload)
        raise_for_error(response)
        data = response.json()
        fund_change = data.get("fund_change", "N")
        return RefundResult(
            out_refund_no=request.out_refund_no,
            status=RefundStatus.SUCCESS if fund_change == "Y" else RefundStatus.FAILED,
        )

    async def query_refund(self, out_refund_no: str) -> RefundResult:
        """POST /v3/alipay/trade/fastpay/refund/query"""
        payload: dict[str, Any] = {"out_request_no": out_refund_no}
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/trade/fastpay/refund/query", json=payload)
        raise_for_error(response)
        data = response.json()
        refund_status = data.get("refund_status")
        if refund_status is None:
            raise PaymentError(
                "退款状态缺失",
                provider_name=_PROVIDER_NAME,
            )
        status = resolve_status(
            refund_status, _REFUND_STATUS_MAP, label="退款状态", error_cls=PaymentError, provider_name=_PROVIDER_NAME
        )
        return RefundResult(
            out_refund_no=out_refund_no,
            status=status,
        )

    async def verify_callback(self, headers: dict[str, str], body: bytes) -> CallbackEvent:
        """验签 → 解析回调数据（支付宝回调是明文 JSON，无需解密）。"""
        body_str = body.decode("utf-8")
        normalized = {k.lower(): v for k, v in headers.items()}
        try:
            timestamp = normalized["alipay-timestamp"]
            nonce = normalized["alipay-nonce"]
            signature = normalized["alipay-signature"]
        except KeyError as e:
            raise SignatureError(f"缺少回调签名头: {e}") from e

        self._http.verify_signature(timestamp, nonce, body_str, signature)

        data = json.loads(body_str)
        return CallbackEvent(
            event_type=data.get("notify_type", "trade_status_sync"),
            out_trade_no=data["out_trade_no"],
            trade_no=data["trade_no"],
            raw=data,
        )

    # --- WithdrawProvider ---

    async def create_withdrawal(self, request: WithdrawRequest) -> WithdrawResult:
        """POST /v3/alipay/fund/trans/uni/transfer"""
        payload: dict[str, Any] = {
            "out_biz_no": request.out_withdrawal_no,
            "trans_amount": fen_to_yuan(request.amount),
            "product_code": "TRANS_ACCOUNT_NO_PWD",
            "biz_scene": "DIRECT_TRANSFER",
            "payee_info": {
                "identity": request.recipient,
                "identity_type": "ALIPAY_USER_ID",
            },
            "order_title": request.description,
        }
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/fund/trans/uni/transfer", json=payload)
        raise_for_error(response, error_cls=WithdrawError)
        data = response.json()
        raw_status = data.get("status", "DEALING")
        status = resolve_status(
            raw_status, _WITHDRAW_STATUS_MAP, label="转账状态", error_cls=WithdrawError, provider_name=_PROVIDER_NAME
        )
        return WithdrawResult(
            out_withdrawal_no=request.out_withdrawal_no,
            status=status,
        )

    async def query_withdrawal(self, out_withdrawal_no: str) -> WithdrawResult:
        """POST /v3/alipay/fund/trans/common/query"""
        payload: dict[str, Any] = {
            "out_biz_no": out_withdrawal_no,
            "product_code": "TRANS_ACCOUNT_NO_PWD",
        }
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/fund/trans/common/query", json=payload)
        raise_for_error(response, error_cls=WithdrawError)
        data = response.json()
        raw_status = data.get("status")
        if raw_status is None:
            raise WithdrawError(
                "转账状态缺失",
                provider_name=_PROVIDER_NAME,
            )
        status = resolve_status(
            raw_status, _WITHDRAW_STATUS_MAP, label="转账状态", error_cls=WithdrawError, provider_name=_PROVIDER_NAME
        )
        return WithdrawResult(
            out_withdrawal_no=out_withdrawal_no,
            status=status,
        )

    # --- WalletProvider ---

    async def query_balance(self) -> BalanceResult:
        """POST /v3/alipay/fund/account/query"""
        payload: dict[str, Any] = {"account_type": "ACCTRANS_ACCOUNT"}
        response = await self._http.request("POST", f"{BASE_URL}/v3/alipay/fund/account/query", json=payload)
        raise_for_error(response, error_cls=WalletError)
        data = response.json()
        return BalanceResult(
            available=yuan_to_fen(Yuan(data["available_amount"])),
            pending=yuan_to_fen(Yuan(data.get("freeze_amount", "0.00"))),
        )
