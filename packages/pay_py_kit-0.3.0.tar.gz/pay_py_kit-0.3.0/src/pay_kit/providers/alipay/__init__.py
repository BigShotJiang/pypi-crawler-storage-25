"""支付宝 V3 Provider。"""

from pay_kit.providers.alipay.config import AlipayConfig
from pay_kit.providers.alipay.provider import Alipay

__all__ = ["Alipay", "AlipayConfig"]
