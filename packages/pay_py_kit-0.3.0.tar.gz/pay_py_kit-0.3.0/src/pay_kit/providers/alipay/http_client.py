"""支付宝 V3 HTTP 客户端。"""

from __future__ import annotations

import secrets
from datetime import UTC, datetime
from typing import Any

import httpx

from pay_kit.exceptions import SignatureError
from pay_kit.providers.alipay.config import AlipayConfig
from pay_kit.providers.alipay.sign import (
    build_auth_string,
    build_sign_string,
    build_verify_string,
    load_private_key,
    load_public_key,
    sign,
    verify,
)
from pay_kit.providers.http_client import BaseHttpClient

BASE_URL = "https://openapi.alipay.com"


class AlipayHttpClient(BaseHttpClient):
    """支付宝 V3 HTTP 客户端。

    职责：请求签名、响应验签、密钥缓存。
    """

    def __init__(
        self,
        config: AlipayConfig,
        *,
        timeout: float = 30.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._private_key = load_private_key(config.private_key.get_secret_value())
        self._alipay_public_key = load_public_key(config.alipay_public_key)
        super().__init__(config, timeout=timeout, transport=transport)
        self._app_id = config.app_id

    async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """签名请求 → 发送 → 验签响应。"""
        body = self._prepare_json_body(kwargs)

        timestamp = datetime.now(tz=UTC).isoformat(timespec="seconds")
        nonce_str = secrets.token_hex(16)

        auth_string = build_auth_string(self._app_id, timestamp, nonce_str)
        sign_string = build_sign_string(auth_string, body)
        signature = sign(sign_string, self._private_key)

        auth_header = f"ALIPAY-SHA256withRSA {auth_string},sign={signature}"
        headers = kwargs.get("headers", {})
        headers["Authorization"] = auth_header
        kwargs["headers"] = headers

        response = await super().request(method, url, **kwargs)
        self._verify_response(response)
        return response

    def verify_signature(
        self,
        timestamp: str,
        nonce: str,
        body: str,
        signature_b64: str,
    ) -> None:
        """验证支付宝签名。失败抛 SignatureError。"""
        verify_string = build_verify_string(timestamp, nonce, body)
        if not verify(verify_string, signature_b64, self._alipay_public_key):
            raise SignatureError("签名验证失败")

    def _verify_response(self, response: httpx.Response) -> None:
        """验证响应签名。"""
        timestamp = response.headers.get("alipay-timestamp")
        nonce = response.headers.get("alipay-nonce")
        signature = response.headers.get("alipay-signature")

        if timestamp is None or nonce is None or signature is None:
            if response.is_success:
                raise SignatureError("2xx 响应缺少签名头")
            return

        self.verify_signature(timestamp, nonce, response.text, signature)
