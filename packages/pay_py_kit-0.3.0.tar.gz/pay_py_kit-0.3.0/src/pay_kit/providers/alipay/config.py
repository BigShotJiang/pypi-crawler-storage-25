"""支付宝 V3 配置。"""

from pydantic import SecretStr

from pay_kit.models import BaseProviderConfig


class AlipayConfig(BaseProviderConfig):
    """支付宝 V3 配置。"""

    app_id: str
    private_key: SecretStr
    alipay_public_key: str
