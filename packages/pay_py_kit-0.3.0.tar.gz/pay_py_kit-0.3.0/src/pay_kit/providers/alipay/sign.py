"""支付宝 V3 签名。"""

from pay_kit.providers.crypto import (
    build_verify_string as build_verify_string,
)
from pay_kit.providers.crypto import (
    load_private_key as load_private_key,
)
from pay_kit.providers.crypto import (
    load_public_key as load_public_key,
)
from pay_kit.providers.crypto import (
    sign as sign,
)
from pay_kit.providers.crypto import (
    verify as verify,
)

__all__ = [
    "build_auth_string",
    "build_sign_string",
    "build_verify_string",
    "load_private_key",
    "load_public_key",
    "sign",
    "verify",
]


def build_auth_string(app_id: str, timestamp: str, nonce: str) -> str:
    """构造认证字符串。"""
    return f"app_id={app_id},timestamp={timestamp},nonce={nonce}"


def build_sign_string(auth_string: str, body: str) -> str:
    """构造请求待签名字符串。格式: {auth_string}\\n{body}\\n"""
    return f"{auth_string}\n{body}\n"
