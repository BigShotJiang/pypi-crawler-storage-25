"""pay-kit 共享密码学函数。"""

import base64

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from pay_kit.exceptions import ConfigError


def load_private_key(pem_data: str) -> rsa.RSAPrivateKey:
    """解析 PEM 格式私钥。非 RSA 或格式错误抛 ConfigError。"""
    try:
        key = serialization.load_pem_private_key(pem_data.encode(), password=None)
    except (ValueError, TypeError) as e:
        raise ConfigError(f"私钥必须是 RSA 私钥 PEM 格式: {e}") from e
    if not isinstance(key, rsa.RSAPrivateKey):
        raise ConfigError("私钥必须是 RSA 类型")
    return key


def load_public_key(pem_data: str) -> rsa.RSAPublicKey:
    """解析 PEM 格式公钥。非 RSA 或格式错误抛 ConfigError。"""
    try:
        key = serialization.load_pem_public_key(pem_data.encode())
    except (ValueError, TypeError) as e:
        raise ConfigError(f"公钥必须是 RSA 公钥 PEM 格式: {e}") from e
    if not isinstance(key, rsa.RSAPublicKey):
        raise ConfigError("公钥必须是 RSA 类型")
    return key


def sign(sign_string: str, private_key: rsa.RSAPrivateKey) -> str:
    """RSA-SHA256 签名，返回 Base64 编码结果。"""
    signature = private_key.sign(
        sign_string.encode(),
        padding.PKCS1v15(),
        hashes.SHA256(),
    )
    return base64.b64encode(signature).decode()


def verify(
    verify_string: str,
    signature_b64: str,
    public_key: rsa.RSAPublicKey,
) -> bool:
    """RSA-SHA256 验签。验证失败返回 False。"""
    try:
        public_key.verify(
            base64.b64decode(signature_b64),
            verify_string.encode(),
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
    except InvalidSignature:
        return False
    return True


def build_verify_string(timestamp: str, nonce: str, body: str) -> str:
    """构造响应/回调待验签字符串。"""
    return f"{timestamp}\n{nonce}\n{body}\n"
