DEFAULT_BASE_URL = "https://api.oso.xyz/v1/"
OSO_API_KEY = "OSO_API_KEY"
