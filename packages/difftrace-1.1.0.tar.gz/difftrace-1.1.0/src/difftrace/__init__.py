try:
    from difftrace._version import __version__
except ModuleNotFoundError:
    __version__ = "0.0.0+unknown"
