"""spata.model"""
