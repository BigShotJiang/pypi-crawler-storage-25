# emt-skill-sync

CLI tool to sync AI skills from a private Azure DevOps repository into **Claude Code** or **GitHub Copilot**.

## Requirements

- Python 3.10+
- Git
- Access to the Azure DevOps skills repository
- Azure account (for authentication)

## Installation

```bash
pip install emt-skill-sync
```

## Quick Start

```bash
emt-skill-sync sync
```

First run will launch an interactive setup wizard:

```
Azure DevOps repository URL [https://dev.azure.com/azurefsoft139/emt/_git/flezi-emt-skills]:
Branch [main]:
Auto-detected provider: claude
Scope (global, project) [global]:
```

Press **Enter** to accept defaults, then the CLI authenticates via Azure and syncs all skills.

## Commands

### `emt-skill-sync sync`

Sync skills from the remote repository to your local machine.

```bash
emt-skill-sync sync
```

**Options:**

| Flag | Description |
|------|-------------|
| `--provider` | Target provider: `claude` or `copilot` |
| `--scope` | Install scope: `global` or `project` |
| `--dry-run` | Preview what would change without writing any files |
| `--force` | Overwrite locally modified managed files (creates backups) |
| `--project-path <path>` | Project root when using `--scope project` (defaults to current directory) |
| `--only skill:<name>` | Sync a single skill, e.g. `--only skill:emt-skill-help` |
| `--profile <bundle-id>` | Sync a stage bundle, e.g. `--profile emt-stage-assessment` |
| `--filter-tags <tags>` | CSV tag filter (OR semantics), e.g. `--filter-tags baseline,xray` |
| `--yes / -y` | Non-interactive mode: accept all defaults (for CI) |

**Examples:**

```bash
# Preview changes without writing
emt-skill-sync sync --dry-run

# Sync only for the current project
emt-skill-sync sync --scope project

# Sync only one skill
emt-skill-sync sync --only skill:emt-skill-help

# Sync all skills for the Assessment stage
emt-skill-sync sync --profile emt-stage-assessment

# Sync skills tagged "baseline" or "xray"
emt-skill-sync sync --filter-tags baseline,xray

# Combine: skills in bundle AND have matching tag
emt-skill-sync sync --profile emt-stage-assessment --filter-tags baseline

# Force overwrite modified files (a backup is saved automatically)
emt-skill-sync sync --force
```

**Sync actions shown in output:**

| Action | Meaning |
|--------|---------|
| `ADD` | New skill, will be installed |
| `UPDATE` | Skill has a newer version in the repo |
| `SKIP` | Already up to date |
| `CONFLICT` | Local file was manually modified — use `--force` to overwrite |

---

### `emt-skill-sync status`

Show current configuration and sync state.

```bash
emt-skill-sync status
```

Output includes repo URL, branch, provider, scope, last sync time, managed file count, and whether any files have been modified locally (drift).

---

### `emt-skill-sync doctor`

Run environment diagnostics to verify everything is configured correctly.

```bash
emt-skill-sync doctor
```

Checks:
- Python version ≥ 3.10
- Git installed
- Config file exists and is complete
- Azure authentication works
- Repository is accessible
- Destination path is writable
- State file is valid

---

### `emt-skill-sync reset`

Delete config and state files. Already-synced skill files are **not** removed.

```bash
emt-skill-sync reset
```

## Where Skills Are Installed

### Global scope (default)

| Provider | Path |
|----------|------|
| `claude` | `~/.claude/skills/` |
| `copilot` | `~/.github/copilot/skills/` |

### Project scope

| Provider | Path |
|----------|------|
| `claude` | `<project>/.claude/skills/` |
| `copilot` | `<project>/.github/instructions/` |

## Authentication

`emt-skill-sync` uses [azure-identity](https://pypi.org/project/azure-identity/). On first run it will prompt device-code login if the Azure CLI credential is not available. Subsequent runs reuse the cached credential.

You can also authenticate in advance using the Azure CLI:

```bash
az login
```

## Per-Project Config (`.flezi-emt/config.yaml`)

Place a `.flezi-emt/config.yaml` at your project root to configure `emt-skill-sync` per project without touching global settings:

```yaml
# .flezi-emt/config.yaml
profile: emt-stage-assessment    # sync only assessment-stage skills
filter_tags: [baseline, xray]    # further filter by tags
scope: project                   # always use project scope for this repo
```

The CLI auto-detects this file by walking up from your current directory. Precedence: **CLI flags > `.flezi-emt/config.yaml` > global config**.

> **Note:** Agents sync is not yet supported in this release (planned for a future sprint).

## Config & State Files

| File | Location | Notes |
| ---- | -------- | ----- |
| Global config | `~/.config/emt-skill-sync/config.json` | Persists repo URL, branch, provider, scope |
| Project config | `<project>/.flezi-emt/config.yaml` | Read-only; per-project profile/filter overrides |
| State | platform user data dir | Managed files, last sync time |
| Repo cache | platform user cache dir | Cloned remote repo |

To view the active config path, run `emt-skill-sync doctor`.

## Conflict Handling

If a managed skill file was edited locally after the last sync, it will show as `CONFLICT`. The CLI will stop and ask you to either:

- Inspect and revert the file manually, then re-run `sync`
- Or run with `--force` to overwrite — a backup copy is saved automatically before overwriting
