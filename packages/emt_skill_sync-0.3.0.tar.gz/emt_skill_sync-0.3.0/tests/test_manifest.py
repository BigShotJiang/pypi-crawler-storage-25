"""Tests for emt_skill_sync.manifest — load_manifest() version handling."""
import json
import pytest
from pathlib import Path

from emt_skill_sync.manifest import load_manifest


def _write_manifest(tmp_path: Path, data: dict) -> Path:
    f = tmp_path / "index.json"
    f.write_text(json.dumps(data), encoding="utf-8")
    return tmp_path


def _base_manifest(version: int, extra: dict | None = None) -> dict:
    m = {
        "$schema": "emt-index-v2",
        "version": version,
        "updated": "2026-04-20",
        "skills": [
            {"id": "emt-skill-help", "source": "flezi-emt/skills/master/emt-skill-help", "tags": ["help"]},
        ],
        "bundles": [],
    }
    if extra:
        m.update(extra)
    return m


# --- version acceptance ---

def test_v1_loads_ok(tmp_path):
    root = _write_manifest(tmp_path, _base_manifest(1))
    manifest = load_manifest(root)
    assert len(manifest.skills) == 1
    assert manifest.skills[0].id == "emt-skill-help"


def test_v2_loads_ok(tmp_path):
    root = _write_manifest(tmp_path, _base_manifest(2))
    manifest = load_manifest(root)
    assert len(manifest.skills) == 1


def test_v3_loads_ok_no_warning(tmp_path, capsys):
    root = _write_manifest(tmp_path, _base_manifest(3))
    manifest = load_manifest(root)
    assert len(manifest.skills) == 1


def test_v3_with_workflows_emits_warning(tmp_path, capsys):
    data = _base_manifest(3, {"workflows": [{"id": "wf-test"}]})
    root = _write_manifest(tmp_path, data)
    manifest = load_manifest(root)
    assert len(manifest.skills) == 1


def test_v3_with_stages_emits_warning(tmp_path):
    data = _base_manifest(3, {"stages": [{"id": "st-test"}, {"id": "st-test2"}]})
    root = _write_manifest(tmp_path, data)
    manifest = load_manifest(root)
    assert len(manifest.skills) == 1


def test_v4_raises(tmp_path):
    root = _write_manifest(tmp_path, _base_manifest(4))
    with pytest.raises(ValueError, match="Unsupported manifest version: 4"):
        load_manifest(root)


# --- missing required fields ---

def test_skill_missing_id_raises(tmp_path):
    data = _base_manifest(2)
    data["skills"] = [{"source": "some/path"}]
    root = _write_manifest(tmp_path, data)
    with pytest.raises(ValueError, match="missing 'id' or 'source'"):
        load_manifest(root)


def test_skill_missing_source_raises(tmp_path):
    data = _base_manifest(2)
    data["skills"] = [{"id": "emt-skill-help"}]
    root = _write_manifest(tmp_path, data)
    with pytest.raises(ValueError, match="missing 'id' or 'source'"):
        load_manifest(root)


def test_missing_index_json_raises(tmp_path):
    with pytest.raises(FileNotFoundError, match="Manifest not found"):
        load_manifest(tmp_path)


# --- bundles ---

def test_bundle_without_id_skipped(tmp_path):
    data = _base_manifest(2)
    data["bundles"] = [{"source": "some.bundle.yaml", "skills": ["emt-skill-help"]}]
    root = _write_manifest(tmp_path, data)
    manifest = load_manifest(root)
    assert len(manifest.bundles) == 0


def test_bundle_parsed_correctly(tmp_path):
    data = _base_manifest(2)
    data["bundles"] = [
        {
            "id": "emt-stage-assessment",
            "source": "flezi-emt/bundles/emt-stage-assessment.bundle.yaml",
            "skills": ["emt-skill-help"],
            "tags": ["xray"],
        }
    ]
    root = _write_manifest(tmp_path, data)
    manifest = load_manifest(root)
    assert len(manifest.bundles) == 1
    assert manifest.bundles[0].id == "emt-stage-assessment"
    assert "emt-skill-help" in manifest.bundles[0].skills
