from __future__ import annotations

from pathlib import Path

import git
from rich.console import Console

from . import auth, state

console = Console()


def _cache_path() -> Path:
    return state.cache_dir()


def ensure_repo(repo_url: str, branch: str = "main", token: str = "") -> git.Repo:
    """Clone or fetch the remote repository into the local cache.

    The bearer token is injected into the URL only for the network operation
    and is never persisted in .git/config between runs.
    """
    cache = _cache_path()
    auth_url = auth.build_auth_url(repo_url, token) if token else repo_url

    if cache.exists() and (cache / ".git").exists():
        console.print("[dim]Fetching latest from remote…[/dim]")
        repo = git.Repo(cache)
        repo.remotes.origin.set_url(auth_url)
        try:
            repo.remotes.origin.fetch()
        finally:
            # Always strip the token from stored config, even if fetch fails.
            repo.remotes.origin.set_url(repo_url)
        repo.git.checkout(branch)
        repo.git.reset("--hard", f"origin/{branch}")
    else:
        console.print("[dim]Cloning repository (first run)…[/dim]")
        cache.mkdir(parents=True, exist_ok=True)
        repo = git.Repo.clone_from(auth_url, cache, branch=branch)
        # Strip token from stored remote URL.
        repo.remotes.origin.set_url(repo_url)

    return repo


def current_commit(repo: git.Repo) -> str:
    return repo.head.commit.hexsha


def repo_root(repo: git.Repo) -> Path:
    return Path(repo.working_dir)
