from __future__ import annotations

from pathlib import Path

from .manifest import SkillEntry
from .paths import resolve_root


def dest_path(
    entry: SkillEntry,
    provider: str,
    scope: str,
    project_path: Path | None = None,
) -> Path:
    """Return the local destination directory for a given skill entry."""
    root = resolve_root(provider, scope, project_path)
    return root / entry.id
