"""filter.py — Apply --profile, --filter-tags, and --only filters to skill entries."""
from __future__ import annotations

from rich.console import Console

from .manifest import Manifest, SkillEntry

console = Console()


def apply_filters(
    manifest: Manifest,
    *,
    profile: str | None = None,
    filter_tags: str | None = None,
    only: str | None = None,
) -> list[SkillEntry]:
    """Return filtered skill entries based on the given flags.

    Semantics:
    - --only: exact ID match; cannot combine with --profile or --filter-tags.
    - --profile: restrict to skills listed in the named bundle (AND with filter_tags).
    - --filter-tags: CSV list; OR within the list (match any tag).
    - --profile + --filter-tags: AND between the two filters.

    Raises ValueError for:
    - --only combined with --profile or --filter-tags
    - unknown --profile name
    """
    if only and (profile or filter_tags):
        raise ValueError(
            "--only cannot be combined with --profile or --filter-tags. "
            "Use --only for a single skill, or --profile/--filter-tags for bulk filtering."
        )

    entries = manifest.skills

    # --only: simple ID match (accepts "skill:id" or bare "id")
    if only:
        only_id = only.split(":", 1)[-1]
        return [e for e in entries if e.id == only_id]

    # --profile: restrict to skills listed in the bundle
    if profile:
        bundle = next((b for b in manifest.bundles if b.id == profile), None)
        if bundle is None:
            available = [b.id for b in manifest.bundles]
            raise ValueError(
                f"Unknown profile '{profile}'. "
                f"Available: {available if available else '(none — no bundles in index.json yet)'}"
            )
        bundle_skill_ids = set(bundle.skills)
        entries = [e for e in entries if e.id in bundle_skill_ids]

    # --filter-tags: OR within the tag list
    if filter_tags:
        requested_tags = {t.strip().lower() for t in filter_tags.split(",") if t.strip()}
        if requested_tags:
            # Warn about tags that don't exist on any skill
            all_tags: set[str] = set()
            for e in manifest.skills:
                all_tags.update(e.tags)
            unknown = requested_tags - all_tags
            if unknown:
                console.print(
                    f"[yellow]⚠ filter-tags: unknown tag(s): {sorted(unknown)}[/yellow]"
                )
            entries = [e for e in entries if requested_tags & set(e.tags)]

    return entries


def log_filter_summary(
    original_count: int,
    filtered_entries: list[SkillEntry],
    profile: str | None,
    filter_tags: str | None,
) -> None:
    """Print a dim summary line showing filter effect, if any filter was active."""
    if not profile and not filter_tags:
        return
    parts = []
    if profile:
        parts.append(f"profile={profile}")
    if filter_tags:
        parts.append(f"tags=[{filter_tags}]")
    console.print(
        f"[dim]Filter: {', '.join(parts)} → "
        f"{len(filtered_entries)} of {original_count} skills[/dim]"
    )
