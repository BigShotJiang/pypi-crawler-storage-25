"""project_config.py — Per-project .flezi-emt/config.yaml loader.

Walk-up algorithm:
  - Start from `start` directory.
  - Stop at filesystem root OR when a .git/ directory is found (repo boundary).
  - Return the first .flezi-emt/config.yaml found, or None if absent.

Precedence (handled in cli.py): CLI flags > project config > global config.json > defaults.
"""
from __future__ import annotations

from pathlib import Path

import yaml

CONFIG_FILENAME = ".flezi-emt/config.yaml"

KNOWN_KEYS = {"profile", "filter_tags", "provider", "scope"}


def find_project_config(start: Path) -> Path | None:
    """Walk up from `start` and return the first .flezi-emt/config.yaml found.

    Stops at filesystem root or at a .git/ directory boundary (whichever comes first).
    Returns None if not found.
    """
    current = start.resolve()
    while True:
        candidate = current / CONFIG_FILENAME
        if candidate.exists():
            return candidate

        # Stop at git repo boundary
        if (current / ".git").exists():
            return None

        parent = current.parent
        if parent == current:
            # Filesystem root
            return None
        current = parent


def load_project_config(config_path: Path) -> dict:
    """Parse .flezi-emt/config.yaml and return a dict with known keys.

    Warns about unknown keys (forward-compat: does not raise).
    Raises ValueError if the file is not valid YAML or not a mapping.
    """
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        raise ValueError(f".flezi-emt/config.yaml is not valid YAML: {e}") from e

    if raw is None:
        return {}

    if not isinstance(raw, dict):
        raise ValueError(".flezi-emt/config.yaml must be a YAML mapping (key: value pairs)")

    unknown = set(raw.keys()) - KNOWN_KEYS
    if unknown:
        from rich.console import Console
        Console().print(
            f"[yellow]⚠ .flezi-emt/config.yaml: unknown key(s) {sorted(unknown)} — ignored[/yellow]"
        )

    result = {}
    if "profile" in raw:
        result["profile"] = str(raw["profile"])
    if "filter_tags" in raw:
        val = raw["filter_tags"]
        if isinstance(val, list):
            result["filter_tags"] = ",".join(str(v) for v in val)
        else:
            result["filter_tags"] = str(val)
    if "provider" in raw:
        result["provider"] = str(raw["provider"])
    if "scope" in raw:
        result["scope"] = str(raw["scope"])

    return result


def merge_configs(global_cfg: dict, project_cfg: dict, cli_overrides: dict) -> dict:
    """Merge configs with precedence: CLI > project > global > defaults.

    All three dicts use the same key space. cli_overrides contains only the
    keys explicitly passed on the command line (None values are NOT passed).
    """
    merged = {**global_cfg}
    merged.update(project_cfg)
    merged.update(cli_overrides)
    return merged
