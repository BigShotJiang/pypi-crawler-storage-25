from __future__ import annotations

from pathlib import Path

# Canonical local roots per provider + scope.
# These are the ONLY place in the codebase that knows the convention for each tool.
_GLOBAL_ROOTS: dict[str, Path] = {
    "claude":  Path.home() / ".claude" / "skills",
    "copilot": Path.home() / ".github" / "copilot" / "skills",
}

_PROJECT_SUBPATHS: dict[str, str] = {
    "claude":  ".claude/skills",
    "copilot": ".github/instructions",
}


def global_root(provider: str) -> Path:
    root = _GLOBAL_ROOTS.get(provider)
    if root is None:
        raise ValueError(f"Unknown provider '{provider}'. Valid choices: {list(_GLOBAL_ROOTS)}")
    return root


def project_root(provider: str, project_path: Path) -> Path:
    subpath = _PROJECT_SUBPATHS.get(provider)
    if subpath is None:
        raise ValueError(f"Unknown provider '{provider}'. Valid choices: {list(_PROJECT_SUBPATHS)}")
    return project_path / subpath


def resolve_root(provider: str, scope: str, project_path: Path | None = None) -> Path:
    if scope == "global":
        return global_root(provider)
    if scope == "project":
        return project_root(provider, project_path or Path.cwd())
    raise ValueError(f"Unknown scope '{scope}'. Valid choices: global, project")


def detect_providers() -> list[str]:
    """Return providers whose parent directories already exist on this machine."""
    detected = []
    for provider, root in _GLOBAL_ROOTS.items():
        if root.parent.exists():
            detected.append(provider)
    return detected
