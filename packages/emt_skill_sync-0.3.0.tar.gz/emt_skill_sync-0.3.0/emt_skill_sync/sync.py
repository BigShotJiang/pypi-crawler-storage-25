"""sync.py — drift detection, plan building, and file copy engine."""
from __future__ import annotations

import hashlib
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from rich.console import Console

from . import state
from .manifest import SkillEntry
from .mapper import dest_path

console = Console()

ActionType = Literal["add", "update", "skip", "conflict"]


@dataclass
class SyncAction:
    entry: SkillEntry
    action: ActionType
    local_dest: Path
    conflict_files: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Hashing helpers
# ---------------------------------------------------------------------------

def _hash_file(path: Path) -> str:
    sha = hashlib.sha256()
    sha.update(path.read_bytes())
    return f"sha256:{sha.hexdigest()}"


def _hash_dir(directory: Path) -> dict[str, str]:
    """Return {relative_path_str: hash} for every file under *directory*."""
    result: dict[str, str] = {}
    for f in sorted(directory.rglob("*")):
        if f.is_file():
            result[f.relative_to(directory).as_posix()] = _hash_file(f)
    return result


# ---------------------------------------------------------------------------
# Plan builder
# ---------------------------------------------------------------------------

def build_plan(
    entries: list[SkillEntry],
    repo_root: Path,
    provider: str,
    scope: str,
    project_path: Path | None,
    managed_files: dict,
) -> list[SyncAction]:
    """Classify each pre-filtered manifest entry as add / update / skip / conflict.

    Filtering (--only, --profile, --filter-tags) is done upstream in filter.apply_filters()
    before calling this function.
    """
    plan: list[SyncAction] = []

    for entry in entries:
        source_dir = repo_root / entry.source
        if not source_dir.is_dir():
            console.print(f"[yellow]⚠ Source not found, skipping:[/yellow] {source_dir}")
            continue

        local_dest = dest_path(entry, provider, scope, project_path)
        remote_hashes = _hash_dir(source_dir)

        # ── brand-new skill ──────────────────────────────────────────────
        if not local_dest.exists():
            plan.append(SyncAction(entry=entry, action="add", local_dest=local_dest))
            continue

        # ── check for local drift against stored hashes ──────────────────
        conflict_files: list[str] = []
        for rel, _remote_hash in remote_hashes.items():
            abs_local = local_dest / rel
            stored = managed_files.get(str(abs_local), {})
            stored_hash = stored.get("hash")
            if stored_hash and abs_local.exists():
                if _hash_file(abs_local) != stored_hash:
                    conflict_files.append(rel)

        if conflict_files:
            plan.append(SyncAction(
                entry=entry,
                action="conflict",
                local_dest=local_dest,
                conflict_files=conflict_files,
            ))
            continue

        # ── check whether remote content differs from local ───────────────
        needs_update = any(
            not (local_dest / rel).exists() or _hash_file(local_dest / rel) != h
            for rel, h in remote_hashes.items()
        )
        plan.append(SyncAction(
            entry=entry,
            action="update" if needs_update else "skip",
            local_dest=local_dest,
        ))

    return plan


# ---------------------------------------------------------------------------
# Apply
# ---------------------------------------------------------------------------

def apply_plan(
    plan: list[SyncAction],
    repo_root: Path,
    force: bool = False,
    backup_dir: Path | None = None,
) -> tuple[dict, dict]:
    """Copy files according to *plan*.

    Returns ``(updated_managed_files, stats)`` where stats has keys:
    added, updated, skipped, conflicts.
    """
    managed_files: dict = state.load_state().get("managed_files", {})
    stats = {"added": 0, "updated": 0, "skipped": 0, "conflicts": 0}

    for action in plan:
        if action.action == "skip":
            stats["skipped"] += 1
            continue

        if action.action == "conflict" and not force:
            stats["conflicts"] += 1
            console.print(
                f"[red]✗ Conflict[/red]  {action.entry.id} — "
                f"{len(action.conflict_files)} locally modified file(s). "
                "Use [bold]--force[/bold] to overwrite."
            )
            continue

        source_dir = repo_root / action.entry.source

        # Back up before force-overwriting
        if action.action == "conflict" and force and backup_dir:
            ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            backup_path = backup_dir / ts / action.entry.id
            if action.local_dest.exists():
                shutil.copytree(action.local_dest, backup_path)
                console.print(f"[dim]  Backed up to {backup_path}[/dim]")

        # Copy every file in the source folder
        action.local_dest.mkdir(parents=True, exist_ok=True)
        for src_file in sorted(source_dir.rglob("*")):
            if not src_file.is_file():
                continue
            rel = src_file.relative_to(source_dir)
            dst_file = action.local_dest / rel
            dst_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_file, dst_file)
            managed_files[str(dst_file)] = {
                "hash": _hash_file(dst_file),
                "item_id": action.entry.id,
            }

        if action.action in ("add", "conflict"):
            label = "Added  " if action.action == "add" else "Forced "
            color = "green" if action.action == "add" else "yellow"
            stats["added"] += 1
            console.print(f"[{color}]✓ {label}[/{color}]  {action.entry.id}")
        else:
            stats["updated"] += 1
            console.print(f"[cyan]✓ Updated[/cyan]  {action.entry.id}")

    return managed_files, stats
