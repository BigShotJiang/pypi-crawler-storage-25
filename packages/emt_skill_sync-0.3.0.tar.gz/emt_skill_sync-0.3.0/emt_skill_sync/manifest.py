from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SkillEntry:
    id: str
    source: str
    license: str = ""
    owner: str = ""
    tags: list[str] = field(default_factory=list)
    phase: str = ""
    category: str = ""


@dataclass
class BundleEntry:
    id: str
    source: str
    phase: str = ""
    skills: list[str] = field(default_factory=list)
    agents: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)


@dataclass
class Manifest:
    skills: list[SkillEntry]
    bundles: list[BundleEntry]


def load_manifest(repo_root: Path) -> Manifest:
    """Read index.json from repo root and return a Manifest with skills and bundles."""
    manifest_file = repo_root / "index.json"
    if not manifest_file.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_file}")

    data = json.loads(manifest_file.read_text(encoding="utf-8"))
    version = data.get("version", 1)
    if version not in (1, 2, 3):
        raise ValueError(f"Unsupported manifest version: {version}")

    if version == 3:
        unsupported = []
        if data.get("workflows"):
            unsupported.append(f"workflows[] ({len(data['workflows'])} entries)")
        if data.get("stages"):
            unsupported.append(f"stages[] ({len(data['stages'])} entries)")
        if unsupported:
            from rich.console import Console as _Console
            _Console().print(
                f"[yellow]⚠ Manifest v3: {', '.join(unsupported)} not yet supported by this CLI; skipped.[/yellow]"
            )

    skills: list[SkillEntry] = []
    for item in data.get("skills", []):
        if "id" not in item or "source" not in item:
            raise ValueError(f"Manifest entry missing 'id' or 'source': {item}")
        skills.append(SkillEntry(
            id=item["id"],
            source=item["source"],
            license=item.get("license", ""),
            owner=item.get("owner", ""),
            tags=item.get("tags") or [],
            phase=item.get("phase", ""),
            category=item.get("category", ""),
        ))

    bundles: list[BundleEntry] = []
    for item in data.get("bundles", []):
        if "id" not in item:
            continue
        bundles.append(BundleEntry(
            id=item["id"],
            source=item.get("source", ""),
            phase=item.get("phase", ""),
            skills=item.get("skills") or [],
            agents=item.get("agents") or [],
            tags=item.get("tags") or [],
        ))

    return Manifest(skills=skills, bundles=bundles)
