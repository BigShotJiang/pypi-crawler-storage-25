from __future__ import annotations

from azure.identity import AzureCliCredential, DeviceCodeCredential, ChainedTokenCredential

# Azure DevOps resource ID — used to request an access token scoped to Azure DevOps.
AZURE_DEVOPS_RESOURCE = "499b84ac-1321-427f-aa17-267ca6975798"


def get_credential() -> ChainedTokenCredential:
    """Return a credential that tries Azure CLI first, then device-code login."""
    return ChainedTokenCredential(
        AzureCliCredential(),
        DeviceCodeCredential(),
    )


def get_token(credential: ChainedTokenCredential | None = None) -> str:
    if credential is None:
        credential = get_credential()
    token = credential.get_token(f"{AZURE_DEVOPS_RESOURCE}/.default")
    return token.token


def build_auth_url(repo_url: str, token: str) -> str:
    """Inject the bearer token into an Azure DevOps HTTPS URL as a PAT-style password.

    E.g.: https://dev.azure.com/org/proj/_git/repo
       -> https://:{token}@dev.azure.com/org/proj/_git/repo
    """
    if "://" not in repo_url:
        raise ValueError(f"Expected an HTTPS URL, got: {repo_url}")
    scheme, rest = repo_url.split("://", 1)
    # Strip any existing credentials embedded in the URL
    if "@" in rest:
        rest = rest.split("@", 1)[1]
    return f"{scheme}://:{token}@{rest}"
