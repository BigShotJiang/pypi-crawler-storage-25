"""cli.py — Typer-based CLI: sync, status, doctor, reset."""
from __future__ import annotations

import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.table import Table

from . import auth, filter as skill_filter, repo, state, sync
from .manifest import load_manifest
from .paths import detect_providers, resolve_root
from .project_config import find_project_config, load_project_config, merge_configs

app = typer.Typer(
    no_args_is_help=True,
    help="Sync skills from a private Azure Git repository into Claude Code or GitHub Copilot.",
)
console = Console()

VALID_PROVIDERS = ["claude", "copilot"]
VALID_SCOPES = ["global", "project"]

DEFAULT_REPO_URL = "https://dev.azure.com/azurefsoft139/emt/_git/flezi-emt-skills"
DEFAULT_BRANCH = "main"


# ---------------------------------------------------------------------------
# First-run setup wizard
# ---------------------------------------------------------------------------

def _setup_wizard(cfg: dict, yes: bool = False) -> dict:
    """Prompt for any missing config fields. With yes=True, use defaults silently."""
    if not cfg.get("repo_url"):
        if yes:
            cfg["repo_url"] = DEFAULT_REPO_URL
        else:
            cfg["repo_url"] = Prompt.ask(
                "[bold]Azure DevOps repository URL[/bold]",
                default=DEFAULT_REPO_URL,
                console=console,
            )

    if not cfg.get("branch"):
        if yes:
            cfg["branch"] = DEFAULT_BRANCH
        else:
            cfg["branch"] = Prompt.ask("Branch", default=DEFAULT_BRANCH, console=console)

    if not cfg.get("provider"):
        detected = detect_providers()
        if len(detected) == 1:
            console.print(f"[dim]Auto-detected provider:[/dim] {detected[0]}")
            cfg["provider"] = detected[0]
        elif yes:
            cfg["provider"] = detected[0] if detected else "claude"
        else:
            default = detected[0] if detected else "claude"
            cfg["provider"] = Prompt.ask(
                "Provider",
                choices=VALID_PROVIDERS,
                default=default,
                console=console,
            )

    if not cfg.get("scope"):
        if yes:
            cfg["scope"] = "global"
        else:
            cfg["scope"] = Prompt.ask(
                "Scope",
                choices=VALID_SCOPES,
                default="global",
                console=console,
            )

    return cfg


# ---------------------------------------------------------------------------
# sync
# ---------------------------------------------------------------------------

@app.command(name="sync")
def sync_cmd(
    provider: Optional[str] = typer.Option(None, "--provider", help="claude or copilot"),
    scope: Optional[str] = typer.Option(None, "--scope", help="global or project"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview changes without writing files"),
    force: bool = typer.Option(False, "--force", help="Overwrite locally modified managed files"),
    project_path: Optional[str] = typer.Option(None, "--project-path", help="Project root (defaults to cwd)"),
    only: Optional[str] = typer.Option(None, "--only", help="Sync a single item, e.g. skill:emt-skill-help"),
    profile: Optional[str] = typer.Option(None, "--profile", help="Sync a stage bundle, e.g. emt-stage-assessment"),
    filter_tags: Optional[str] = typer.Option(None, "--filter-tags", help="CSV tag filter (OR semantics), e.g. baseline,xray"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Non-interactive mode: accept all defaults (for CI)"),
) -> None:
    """Sync skills from the remote repository. Runs first-run setup if needed."""

    # ── 1. Load + complete config ────────────────────────────────────────
    global_cfg = state.load_config()

    # Detect and apply .flezi-emt/config.yaml if present
    _start_path = Path(project_path or Path.cwd())
    _project_config_path = find_project_config(_start_path)
    project_cfg: dict = {}
    if _project_config_path:
        try:
            project_cfg = load_project_config(_project_config_path)
            console.print(f"[dim]Using .flezi-emt/config.yaml from {_project_config_path}[/dim]")
        except ValueError as exc:
            console.print(f"[yellow]⚠ {exc} — project config ignored[/yellow]")

    # CLI overrides (only non-None values)
    cli_overrides: dict = {}
    if provider:
        cli_overrides["provider"] = provider
    if scope:
        cli_overrides["scope"] = scope
    if project_path:
        cli_overrides["project_path"] = project_path

    cfg = merge_configs(global_cfg, project_cfg, cli_overrides)
    cfg = _setup_wizard(cfg, yes=yes)

    # Persist CLI-level choices (not project_cfg — that lives in .flezi-emt/config.yaml)
    if provider:
        if provider not in VALID_PROVIDERS:
            console.print(f"[red]Unknown provider '{provider}'. Valid: {VALID_PROVIDERS}[/red]")
            raise typer.Exit(1)

    if scope:
        if scope not in VALID_SCOPES:
            console.print(f"[red]Unknown scope '{scope}'. Valid: {VALID_SCOPES}[/red]")
            raise typer.Exit(1)

    # Validate merged values
    if cfg.get("provider") not in VALID_PROVIDERS + [None, ""]:
        console.print(f"[red]Unknown provider '{cfg['provider']}'. Valid: {VALID_PROVIDERS}[/red]")
        raise typer.Exit(1)
    if cfg.get("scope") not in VALID_SCOPES + [None, ""]:
        console.print(f"[red]Unknown scope '{cfg['scope']}'. Valid: {VALID_SCOPES}[/red]")
        raise typer.Exit(1)

    # Save only the global-persistent keys (profile/filter_tags stay in .flezi-emt/config.yaml)
    _GLOBAL_KEYS = {"repo_url", "branch", "provider", "scope", "project_path"}
    state.save_config({k: v for k, v in cfg.items() if k in _GLOBAL_KEYS and v})

    # Also apply --profile/--filter-tags from project_cfg if not passed via CLI
    if not profile and project_cfg.get("profile"):
        profile = project_cfg["profile"]
    if not filter_tags and project_cfg.get("filter_tags"):
        filter_tags = project_cfg["filter_tags"]

    _provider: str = cfg["provider"]
    _scope: str = cfg["scope"]
    _project_path = Path(cfg.get("project_path") or project_path or Path.cwd())
    _repo_url: str = cfg["repo_url"]
    _branch: str = cfg.get("branch", "main")

    # ── 2. Authenticate ──────────────────────────────────────────────────
    console.rule("[bold]Authenticating[/bold]")
    try:
        token = auth.get_token()
        console.print("[green]✓[/green] Authenticated")
    except Exception as exc:
        console.print(f"[red]✗ Authentication failed:[/red] {exc}")
        raise typer.Exit(1)

    # ── 3. Fetch remote repository ───────────────────────────────────────
    console.rule("[bold]Fetching repository[/bold]")
    try:
        git_repo = repo.ensure_repo(_repo_url, _branch, token)
        commit = repo.current_commit(git_repo)
        repo_root = repo.repo_root(git_repo)
        console.print(f"[green]✓[/green] HEAD [dim]{commit[:12]}[/dim]  branch [dim]{_branch}[/dim]")
    except Exception as exc:
        console.print(f"[red]✗ Repository error:[/red] {exc}")
        raise typer.Exit(1)

    # ── 4. Parse manifest ────────────────────────────────────────────────
    try:
        manifest = load_manifest(repo_root)
        console.print(f"[green]✓[/green] Manifest  [dim]{len(manifest.skills)} skills · {len(manifest.bundles)} bundles[/dim]")
    except Exception as exc:
        console.print(f"[red]✗ Manifest error:[/red] {exc}")
        raise typer.Exit(1)

    # ── 4b. Apply filters ────────────────────────────────────────────────
    try:
        entries = skill_filter.apply_filters(
            manifest,
            profile=profile,
            filter_tags=filter_tags,
            only=only,
        )
    except ValueError as exc:
        console.print(f"[red]✗ Filter error:[/red] {exc}")
        raise typer.Exit(1)

    skill_filter.log_filter_summary(len(manifest.skills), entries, profile, filter_tags)

    # ── 5. Build sync plan ───────────────────────────────────────────────
    console.rule("[bold]Analyzing[/bold]")
    st = state.load_state()
    managed_files: dict = st.get("managed_files", {})

    plan = sync.build_plan(
        entries,
        repo_root,
        _provider,
        _scope,
        _project_path if _scope == "project" else None,
        managed_files,
    )

    # ── 6. Show plan ─────────────────────────────────────────────────────
    adds      = sum(1 for a in plan if a.action == "add")
    updates   = sum(1 for a in plan if a.action == "update")
    skips     = sum(1 for a in plan if a.action == "skip")
    conflicts = sum(1 for a in plan if a.action == "conflict")

    table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    table.add_column("Skill")
    table.add_column("Owner", style="dim")
    table.add_column("Action")
    table.add_column("Destination", style="dim")

    _ACTION_COLOR = {"add": "green", "update": "cyan", "skip": "dim", "conflict": "red"}
    for action in plan:
        color = _ACTION_COLOR[action.action]
        extra = f"  ({len(action.conflict_files)} file(s))" if action.conflict_files else ""
        table.add_row(
            action.entry.id,
            action.entry.owner or "—",
            f"[{color}]{action.action.upper()}{extra}[/{color}]",
            str(action.local_dest),
        )

    console.print(table)
    console.print(
        f"\n[dim]{adds} add · {updates} update · {skips} skip · {conflicts} conflict[/dim]"
    )

    if dry_run:
        console.print("\n[yellow]Dry run — no files written.[/yellow]")
        return

    if conflicts and not force:
        console.print(
            f"\n[red]{conflicts} conflict(s) detected.[/red] "
            "Local managed files were modified. "
            "Re-run with [bold]--force[/bold] to overwrite, or inspect the files first."
        )
        raise typer.Exit(1)

    if adds + updates == 0 and not conflicts:
        console.print("\n[green]Everything is up to date.[/green]")
        return

    # ── 7. Apply ─────────────────────────────────────────────────────────
    console.rule("[bold]Applying[/bold]")
    backup_dir = (state.cache_dir().parent / "backups") if force else None

    new_managed, stats = sync.apply_plan(plan, repo_root, force=force, backup_dir=backup_dir)

    # ── 8. Persist state ─────────────────────────────────────────────────
    now = datetime.now(timezone.utc).isoformat()
    st["last_commit"] = commit
    st["last_sync_time"] = now
    st["managed_files"] = new_managed
    st.setdefault("history", []).append({
        "time": now,
        "commit": commit,
        "provider": _provider,
        "scope": _scope,
        "files_added": stats["added"],
        "files_updated": stats["updated"],
        "files_skipped": stats["skipped"],
        "conflicts_skipped": stats["conflicts"],
        "force": force,
    })
    state.save_state(st)

    # ── 9. Summary ───────────────────────────────────────────────────────
    console.rule()
    console.print(
        f"[bold green]✓ Sync complete.[/bold green]  "
        f"Added [green]{stats['added']}[/green]  "
        f"Updated [cyan]{stats['updated']}[/cyan]  "
        f"Skipped [dim]{stats['skipped']}[/dim]  "
        f"Conflicts skipped [red]{stats['conflicts']}[/red]"
    )


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------

@app.command()
def status() -> None:
    """Show current sync configuration and state."""
    global_cfg = state.load_config()
    st  = state.load_state()

    if not global_cfg:
        console.print(
            "[yellow]Not configured.[/yellow] "
            "Run [bold]emt-skill-sync sync[/bold] to set up."
        )
        return

    # Detect project config
    _project  = Path(global_cfg.get("project_path") or Path.cwd())
    _proj_cfg_path = find_project_config(_project)
    project_cfg: dict = {}
    if _proj_cfg_path:
        try:
            project_cfg = load_project_config(_proj_cfg_path)
        except ValueError:
            pass

    cfg = merge_configs(global_cfg, project_cfg, {})
    _provider = cfg.get("provider", "")
    _scope    = cfg.get("scope", "")

    try:
        local_root = resolve_root(_provider, _scope, _project) if _provider and _scope else "—"
    except Exception:
        local_root = "—"

    managed: dict = st.get("managed_files", {})

    # Drift detection
    drift_count = 0
    for abs_path, meta in managed.items():
        p = Path(abs_path)
        if p.exists() and sync._hash_file(p) != meta.get("hash", ""):
            drift_count += 1

    tbl = Table(show_header=False, box=None, padding=(0, 2))
    tbl.add_column(style="bold")
    tbl.add_column()
    tbl.add_row("Repo URL",       cfg.get("repo_url", "—"))
    tbl.add_row("Branch",         cfg.get("branch", "main"))
    tbl.add_row("Provider",       _provider or "—")
    tbl.add_row("Scope",          _scope    or "—")
    tbl.add_row("Local root",     str(local_root))
    if _proj_cfg_path:
        tbl.add_row("Project config", str(_proj_cfg_path))
        if project_cfg.get("profile"):
            tbl.add_row("  profile",     project_cfg["profile"])
        if project_cfg.get("filter_tags"):
            tbl.add_row("  filter_tags", project_cfg["filter_tags"])
    tbl.add_row("Last commit",    st.get("last_commit", "—"))
    tbl.add_row("Last sync",      st.get("last_sync_time", "—"))
    tbl.add_row("Managed files",  str(len(managed)))
    tbl.add_row(
        "Local drift",
        f"[red]{drift_count} modified[/red]" if drift_count else "[green]clean[/green]",
    )
    console.print(tbl)


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------

@app.command()
def doctor() -> None:
    """Run environment diagnostics."""
    all_ok = True

    def chk(label: str, ok: bool, detail: str = "") -> None:
        nonlocal all_ok
        icon = "[green]✓[/green]" if ok else "[red]✗[/red]"
        note = f"  [dim]{detail}[/dim]" if detail else ""
        console.print(f"  {icon}  {label}{note}")
        if not ok:
            all_ok = False

    console.rule("[bold]Diagnostics[/bold]")

    # Python version
    chk("Python ≥ 3.10", sys.version_info >= (3, 10), sys.version.split()[0])

    # Git binary
    git_bin = shutil.which("git")
    chk("Git installed", git_bin is not None, git_bin or "not found")

    # Config
    cfg = state.load_config()
    chk("Config file exists", bool(cfg), str(state.config_path()))
    chk("repo_url configured", bool(cfg.get("repo_url")))
    chk("provider configured", bool(cfg.get("provider")))
    chk("scope configured",    bool(cfg.get("scope")))

    # Azure authentication
    try:
        auth.get_token()
        chk("Azure authentication", True)
    except Exception as exc:
        chk("Azure authentication", False, str(exc)[:100])

    # Repository reachability
    if cfg.get("repo_url"):
        try:
            token    = auth.get_token()
            git_repo = repo.ensure_repo(cfg["repo_url"], cfg.get("branch", "main"), token)
            chk("Repository accessible", True, repo.current_commit(git_repo)[:12])
        except Exception as exc:
            chk("Repository accessible", False, str(exc)[:100])

    # Destination writability
    if cfg.get("provider") and cfg.get("scope"):
        try:
            root = resolve_root(cfg["provider"], cfg["scope"])
            root.mkdir(parents=True, exist_ok=True)
            chk("Destination path writable", True, str(root))
        except Exception as exc:
            chk("Destination path writable", False, str(exc)[:100])

    # State file
    sp = state.state_path()
    if sp.exists():
        try:
            import json
            json.loads(sp.read_text(encoding="utf-8"))
            chk("State file valid", True, str(sp))
        except Exception as exc:
            chk("State file valid", False, str(exc))
    else:
        chk("State file", True, "not yet created — OK")

    # Project config (.flezi-emt/config.yaml)
    _start = Path(cfg.get("project_path") or Path.cwd()) if cfg else Path.cwd()
    proj_cfg_path = find_project_config(_start)
    if proj_cfg_path:
        try:
            load_project_config(proj_cfg_path)
            chk(".flezi-emt/config.yaml valid", True, str(proj_cfg_path))
        except ValueError as exc:
            chk(".flezi-emt/config.yaml valid", False, str(exc))
    else:
        chk(".flezi-emt/config.yaml", True, "not found — using global config only")

    console.rule()
    if all_ok:
        console.print("[bold green]All checks passed.[/bold green]")
    else:
        console.print("[bold red]Some checks failed — see above.[/bold red]")


# ---------------------------------------------------------------------------
# reset
# ---------------------------------------------------------------------------

@app.command()
def reset(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt (for CI)"),
) -> None:
    """Delete CLI config and state. Already-synced files are NOT removed."""
    if not yes:
        console.print(
            "[yellow]This will remove config and state files.[/yellow]\n"
            "[dim]Files already synced into provider directories are NOT deleted.[/dim]\n"
        )
        if not Confirm.ask("Proceed?", console=console):
            console.print("Aborted.")
            return

    removed: list[str] = []
    for path in (state.config_path(), state.state_path()):
        if path.exists():
            path.unlink()
            removed.append(str(path))

    if removed:
        for r in removed:
            console.print(f"[dim]Removed: {r}[/dim]")
        console.print("[green]✓ Reset complete.[/green]")
    else:
        console.print("[dim]Nothing to remove.[/dim]")
