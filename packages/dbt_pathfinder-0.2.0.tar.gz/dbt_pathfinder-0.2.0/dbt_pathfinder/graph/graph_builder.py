from __future__ import annotations

from typing import Dict, Iterable

import networkx as nx

from dbt_pathfinder.models.manifest import Manifest, ManifestNode


def _iter_nodes(manifest: Manifest) -> Iterable[ManifestNode]:
    for collection in (manifest.nodes, manifest.sources, manifest.metrics, manifest.exposures):
        yield from collection.values()


def _all_known_nodes(manifest: Manifest) -> Dict[str, ManifestNode]:
    known: Dict[str, ManifestNode] = {}
    for node in _iter_nodes(manifest):
        known[node.unique_id] = node
    return known


def build_graph(manifest: Manifest) -> nx.DiGraph:
    graph = nx.DiGraph()
    known_nodes = _all_known_nodes(manifest)

    for node in known_nodes.values():
        graph.add_node(
            node.unique_id,
            unique_id=node.unique_id,
            resource_type=node.resource_type,
            name=node.name,
            package_name=node.package_name,
            path=node.path,
            original_file_path=node.original_file_path,
            description=node.description,
            columns={k: v.model_dump() for k, v in node.columns.items()},
        )

    for node in known_nodes.values():
        for upstream in node.depends_on.nodes:
            if upstream in known_nodes:
                # Directed edge from upstream -> downstream.
                graph.add_edge(upstream, node.unique_id)

    return graph
