from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class DependsOn(BaseModel):
    nodes: List[str] = Field(default_factory=list)


class ManifestColumn(BaseModel):
    name: Optional[str] = None
    data_type: Optional[str] = None
    description: Optional[str] = None


class ManifestNode(BaseModel):
    unique_id: str
    resource_type: str
    name: str
    package_name: Optional[str] = None
    path: Optional[str] = None
    original_file_path: Optional[str] = None
    description: Optional[str] = None
    raw_code: Optional[str] = None
    compiled_sql: Optional[str] = None
    test_metadata: Optional[Dict[str, Any]] = None
    columns: Dict[str, ManifestColumn] = Field(default_factory=dict)
    depends_on: DependsOn = Field(default_factory=DependsOn)


class Manifest(BaseModel):
    nodes: Dict[str, ManifestNode] = Field(default_factory=dict)
    sources: Dict[str, ManifestNode] = Field(default_factory=dict)
    metrics: Dict[str, ManifestNode] = Field(default_factory=dict)
    exposures: Dict[str, ManifestNode] = Field(default_factory=dict)
