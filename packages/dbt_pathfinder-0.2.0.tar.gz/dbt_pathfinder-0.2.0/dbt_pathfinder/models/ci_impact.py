from __future__ import annotations

from pydantic import BaseModel, Field


class CIImpactResult(BaseModel):
    changed_files: list[str] = Field(default_factory=list)
    changed_nodes: list[str] = Field(default_factory=list)
    impacted_by_depth: dict[int, list[str]] = Field(default_factory=dict)
    tests: list[str] = Field(default_factory=list)
    suggested_command: str = ""
