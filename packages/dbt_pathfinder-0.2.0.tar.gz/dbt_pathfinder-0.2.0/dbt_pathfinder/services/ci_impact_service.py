from __future__ import annotations

from collections import deque
from pathlib import Path
from typing import Dict, List, Optional, Set

import networkx as nx

from dbt_pathfinder.graph.graph_builder import build_graph
from dbt_pathfinder.models.ci_impact import CIImpactResult
from dbt_pathfinder.models.manifest import Manifest, ManifestNode
from dbt_pathfinder.parser.manifest_parser import parse_manifest


def _normalize_rel_path(path: str) -> str:
    return Path(path).as_posix().lstrip("./")


class CIImpactService:
    def __init__(self, manifest: Manifest, graph: nx.DiGraph) -> None:
        self.manifest = manifest
        self.graph = graph
        self._node_index: Dict[str, ManifestNode] = {}
        for coll in (manifest.nodes, manifest.sources, manifest.metrics, manifest.exposures):
            self._node_index.update(coll)

    @classmethod
    def from_manifest(cls, manifest_path: str | Path) -> "CIImpactService":
        manifest = parse_manifest(manifest_path)
        graph = build_graph(manifest)
        return cls(manifest=manifest, graph=graph)

    def _original_paths_index(self) -> Dict[str, List[str]]:
        """Map normalized original_file_path -> unique_ids (order of iteration)."""
        by_path: Dict[str, List[str]] = {}
        for unique_id, node in self._node_index.items():
            raw = node.original_file_path
            if not raw:
                continue
            key = _normalize_rel_path(raw)
            by_path.setdefault(key, []).append(unique_id)
        return by_path

    def resolve_changed_files(self, files: list[str]) -> list[str]:
        """Return unique_ids for manifest nodes whose original_file_path matches a given file."""
        index = self._original_paths_index()
        seen: Set[str] = set()
        ordered: List[str] = []
        for f in files:
            key = _normalize_rel_path(f)
            for uid in index.get(key, []):
                if uid not in seen:
                    seen.add(uid)
                    ordered.append(uid)
        return ordered

    def get_downstream_impact(self, nodes: list[str]) -> dict[int, list[str]]:
        """
        Shortest-path depth from any root in ``nodes`` to each reachable node.
        Excludes roots and test nodes from the returned depth map (tests are listed separately).
        """
        seeds = [n for n in nodes if n in self.graph]
        if not seeds:
            return {}

        inf = 10**9
        min_depth: Dict[str, int] = {n: inf for n in self.graph}
        queue: deque[str] = deque()
        for s in seeds:
            min_depth[s] = 0
            queue.append(s)

        while queue:
            u = queue.popleft()
            du = min_depth[u]
            for v in self.graph.successors(u):
                cand = du + 1
                if cand < min_depth[v]:
                    min_depth[v] = cand
                    queue.append(v)

        seed_set = set(seeds)
        by_depth: Dict[int, List[str]] = {}
        for node_id, d in min_depth.items():
            if d <= 0 or d >= inf:
                continue
            if node_id in seed_set:
                continue
            meta = self._node_index.get(node_id)
            if meta and meta.resource_type == "test":
                continue
            by_depth.setdefault(d, []).append(node_id)

        return {depth: sorted(ids) for depth, ids in sorted(by_depth.items())}

    def get_impacted_tests(self, anchor_unique_ids: Set[str]) -> list[str]:
        """Tests that are in the anchor set or depend on any non-test node in the anchor set."""
        anchor_models = {
            uid
            for uid in anchor_unique_ids
            if (m := self._node_index.get(uid)) is not None and m.resource_type != "test"
        }
        names: List[str] = []
        seen: Set[str] = set()
        for node in self.manifest.nodes.values():
            if node.resource_type != "test":
                continue
            uid = node.unique_id
            if uid in anchor_unique_ids and uid not in seen:
                seen.add(uid)
                names.append(node.name)
                continue
            deps = node.depends_on.nodes
            if any(d in anchor_models for d in deps):
                if uid not in seen:
                    seen.add(uid)
                    names.append(node.name)
        return sorted(names)

    def format_node_label(self, unique_id: str) -> str:
        """Short label for CLI text output (not necessarily unique across packages)."""
        node = self._node_index.get(unique_id)
        if not node:
            return unique_id
        if node.resource_type in ("model", "seed", "snapshot", "test"):
            return node.name
        if node.resource_type == "source":
            pkg = node.package_name or ""
            return f"{pkg}.{node.name}" if pkg else node.name
        return node.name or unique_id

    def _selector_token(self, unique_id: str) -> Optional[str]:
        node = self._node_index.get(unique_id)
        if not node:
            return None
        if node.resource_type == "test":
            return None
        if node.resource_type == "model":
            return node.name
        if node.resource_type == "seed":
            return node.name
        if node.resource_type == "snapshot":
            return node.name
        if node.resource_type == "source":
            pkg = node.package_name or ""
            return f"source:{pkg}:{node.name}"
        return node.unique_id

    def _suggested_build_command(self, changed_unique_ids: list[str]) -> str:
        tokens: List[str] = []
        seen_tok: Set[str] = set()
        for uid in changed_unique_ids:
            tok = self._selector_token(uid)
            if not tok:
                continue
            piece = f"{tok}+"
            if piece not in seen_tok:
                seen_tok.add(piece)
                tokens.append(piece)
        if not tokens:
            return "dbt build"
        return "dbt build --select " + " ".join(tokens)

    def build_result(self, files: list[str], *, include_tests: bool = True) -> CIImpactResult:
        norm_files = [_normalize_rel_path(f) for f in files]
        changed = self.resolve_changed_files(norm_files)
        impacted = self.get_downstream_impact(changed)

        downstream_flat = {uid for ids in impacted.values() for uid in ids}
        anchor = set(changed) | downstream_flat
        tests: List[str] = []
        if include_tests:
            tests = self.get_impacted_tests(anchor)

        short_names = []
        seen_name: Set[str] = set()
        for uid in changed:
            meta = self._node_index.get(uid)
            label = meta.name if meta else uid
            if label not in seen_name:
                seen_name.add(label)
                short_names.append(label)

        return CIImpactResult(
            changed_files=norm_files,
            changed_nodes=short_names,
            impacted_by_depth=impacted,
            tests=tests,
            suggested_command=self._suggested_build_command(changed),
        )
