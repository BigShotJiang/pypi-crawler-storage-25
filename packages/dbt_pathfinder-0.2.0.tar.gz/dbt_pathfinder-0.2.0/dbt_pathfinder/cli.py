from __future__ import annotations

from typing import Literal

import typer
from rich.console import Console

from dbt_pathfinder.commands.ci_impact_command import run_ci_impact
from dbt_pathfinder.commands.impact_command import run_impact
from dbt_pathfinder.commands.path_explain_command import run_path_explain
from dbt_pathfinder.commands.path_command import run_path
from dbt_pathfinder.commands.show_command import run_show
from dbt_pathfinder.parser.manifest_parser import ManifestParseError
from dbt_pathfinder.services.ci_impact_service import CIImpactService
from dbt_pathfinder.services.pathfinder_service import PathfinderError, PathfinderService

app = typer.Typer(help="Explore dbt dependency graphs from manifest.json")
console = Console()


def _load_service(manifest: str) -> PathfinderService:
    return PathfinderService.from_manifest(manifest)


def _load_ci_impact_service(manifest: str) -> CIImpactService:
    return CIImpactService.from_manifest(manifest)


@app.command("show", help="Show metadata, upstream, and downstream for one node.")
def show(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    model: str = typer.Option(..., "--model", help="Model name or unique_id"),
    ui: Literal["rich", "text"] = typer.Option("rich", "--ui", help="UI mode"),
    verbose: bool = typer.Option(False, "--verbose", help="Include detailed metadata and columns"),
) -> None:
    try:
        service = _load_service(manifest)
        result = run_show(service, model, ui=ui, verbose=verbose)
        if ui == "rich":
            console.print(result)
        else:
            typer.echo(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command("impact", help="Show downstream impact grouped by dependency depth.")
def impact(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    model: str = typer.Option(..., "--model", help="Model name or unique_id"),
    output: Literal["text", "json"] = typer.Option("text", "--output", help="Output format"),
    ui: Literal["rich", "text"] = typer.Option("rich", "--ui", help="UI mode"),
) -> None:
    try:
        service = _load_service(manifest)
        result = run_impact(service, model, output=output, ui=ui)
        if output == "json" or ui == "text":
            typer.echo(result)
        else:
            console.print(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command(
    "ci-impact",
    help="Downstream impact and suggested dbt build selection from changed project files.",
)
def ci_impact(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    files: list[str] = typer.Option(
        ...,
        "--files",
        help="Project-relative path to a changed file (repeat --files for each path).",
    ),
    output: Literal["text", "json"] = typer.Option("text", "--output", help="Output format"),
    ui: Literal["rich", "text"] = typer.Option(
        "rich",
        "--ui",
        help="Plain vs Rich terminal output when --output is text (JSON is always plain).",
    ),
    include_tests: bool = typer.Option(
        True,
        "--include-tests/--no-include-tests",
        help="Include impacted tests in the report",
    ),
) -> None:
    try:
        service = _load_ci_impact_service(manifest)
        result = run_ci_impact(service, files, output=output, include_tests=include_tests, ui=ui)
        if output == "json" or ui == "text":
            typer.echo(result)
        else:
            console.print(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command("path", help="Find shortest path between two nodes.")
def path(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    from_node: str = typer.Option(..., "--from", help="Source model name or unique_id"),
    to_node: str = typer.Option(..., "--to", help="Target model name or unique_id"),
    mode: Literal["directed", "any"] = typer.Option(
        "directed",
        "--mode",
        help="Path traversal mode",
    ),
    ui: Literal["rich", "text"] = typer.Option("rich", "--ui", help="UI mode"),
) -> None:
    try:
        directed = mode != "any"
        service = _load_service(manifest)
        result = run_path(service, from_node, to_node, directed=directed, ui=ui)
        if ui == "rich":
            console.print(result)
        else:
            typer.echo(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


@app.command(
    "path-explain",
    help="Explain path edges with inferred join keys and cardinality.",
)
def path_explain(
    manifest: str = typer.Option(..., "--manifest", help="Path to dbt manifest.json"),
    from_node: str = typer.Option(..., "--from", help="Source model name or unique_id"),
    to_node: str = typer.Option(..., "--to", help="Target model name or unique_id"),
    mode: Literal["directed", "any"] = typer.Option(
        "directed",
        "--mode",
        help="Path traversal mode",
    ),
    output: Literal["text", "json"] = typer.Option("text", "--output", help="Output format"),
    ui: Literal["rich", "text"] = typer.Option("rich", "--ui", help="UI mode"),
) -> None:
    try:
        directed = mode != "any"
        service = _load_service(manifest)
        result = run_path_explain(
            service,
            from_node=from_node,
            to_node=to_node,
            directed=directed,
            output=output,
            ui=ui,
        )
        if output == "json" or ui == "text":
            typer.echo(result)
        else:
            console.print(result)
    except (ManifestParseError, PathfinderError) as exc:
        typer.secho(str(exc), fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
