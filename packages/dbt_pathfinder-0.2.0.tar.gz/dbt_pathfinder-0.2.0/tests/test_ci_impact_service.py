from pathlib import Path

import pytest
from rich.console import Group

from dbt_pathfinder.commands.ci_impact_command import run_ci_impact
from dbt_pathfinder.services.ci_impact_service import CIImpactService
from dbt_pathfinder.services.pathfinder_service import PathfinderError


@pytest.fixture
def manifest_path() -> Path:
    return Path(__file__).parent / "fixtures" / "manifest.json"


@pytest.fixture
def ci_service(manifest_path: Path) -> CIImpactService:
    return CIImpactService.from_manifest(manifest_path)


def test_ci_impact_single_file(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(["models/staging/stg_orders.sql"])
    assert result.changed_nodes == ["stg_orders"]
    assert result.impacted_by_depth[1] == sorted(
        ["model.pkg.fct_orders", "model.pkg.report_orders"]
    )
    assert result.impacted_by_depth[2] == ["model.pkg.mart_customer_ltv"]
    assert "unique_fct_orders_order_id" in result.tests
    assert "not_null_fct_orders_order_id" in result.tests
    assert result.suggested_command == "dbt build --select stg_orders+"


def test_ci_impact_multiple_files(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(
        [
            "models/staging/stg_orders.sql",
            "models/staging/stg_customers.sql",
        ]
    )
    assert set(result.changed_nodes) == {"stg_orders", "stg_customers"}
    d1 = set(result.impacted_by_depth.get(1, []))
    assert "model.pkg.fct_orders" in d1
    assert "model.pkg.report_orders" in d1


def test_ci_impact_no_matching_nodes(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(["models/ghost.sql"])
    assert result.changed_nodes == []
    assert result.impacted_by_depth == {}
    assert result.tests == []
    assert result.suggested_command == "dbt build"


def test_ci_impact_deep_lineage(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(["models/staging/stg_orders.sql"])
    assert result.impacted_by_depth[2]


def test_ci_impact_test_detection_on_downstream(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(["models/staging/stg_orders.sql"])
    assert "not_null_stg_customers_customer_id" not in result.tests
    assert "unique_fct_orders_order_id" in result.tests


def test_ci_impact_tests_on_changed_model(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(["models/staging/stg_customers.sql"])
    assert "stg_customers" in result.changed_nodes
    assert "unique_stg_customers_customer_id" in result.tests
    assert "not_null_stg_customers_customer_id" in result.tests


def test_ci_impact_yml_source_file(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(["models/sources/raw_orders.yml"])
    assert result.changed_nodes == ["raw_orders"]
    assert "source:pkg:raw_orders+" in result.suggested_command


def test_ci_impact_deduplicates_shared_downstream(ci_service: CIImpactService) -> None:
    """stg_orders and stg_customers both reach fct_orders; list once per depth."""
    result = ci_service.build_result(
        ["models/staging/stg_orders.sql", "models/staging/stg_customers.sql"]
    )
    seen = set()
    for ids in result.impacted_by_depth.values():
        for uid in ids:
            assert uid not in seen
            seen.add(uid)


def test_ci_impact_no_include_tests(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(["models/staging/stg_orders.sql"], include_tests=False)
    assert result.tests == []


def test_ci_impact_command_json(ci_service: CIImpactService) -> None:
    out = run_ci_impact(ci_service, ["models/staging/stg_orders.sql"], output="json")
    assert "changed_nodes" in out
    assert "stg_orders" in out


def test_ci_impact_command_bad_output(ci_service: CIImpactService) -> None:
    with pytest.raises(PathfinderError):
        run_ci_impact(ci_service, ["models/staging/stg_orders.sql"], output="yaml")


def test_ci_impact_command_bad_ui(ci_service: CIImpactService) -> None:
    with pytest.raises(PathfinderError):
        run_ci_impact(ci_service, ["models/staging/stg_orders.sql"], output="text", ui="wat")


def test_ci_impact_command_rich_output(ci_service: CIImpactService) -> None:
    out = run_ci_impact(ci_service, ["models/staging/stg_orders.sql"], output="text", ui="rich")
    assert isinstance(out, Group)


def test_ci_impact_command_plain_text_ui(ci_service: CIImpactService) -> None:
    out = run_ci_impact(ci_service, ["models/staging/stg_orders.sql"], output="text", ui="text")
    assert isinstance(out, str)
    assert "Changed files:" in out


def test_ci_impact_resolve_changed_files_normalizes_paths(ci_service: CIImpactService) -> None:
    assert ci_service.resolve_changed_files(["./models/staging/stg_orders.sql"]) == [
        "model.pkg.stg_orders",
    ]


def test_ci_impact_schema_yml_resolves_multiple_tests(ci_service: CIImpactService) -> None:
    result = ci_service.build_result(["models/marts/schema.yml"])
    names = set(result.changed_nodes)
    assert names == {"unique_fct_orders_order_id", "not_null_fct_orders_order_id"}
    assert result.suggested_command == "dbt build"
