from pathlib import Path

import pytest

from dbt_pathfinder.commands.impact_command import run_impact
from dbt_pathfinder.commands.path_explain_command import run_path_explain
from dbt_pathfinder.parser.manifest_parser import ManifestParseError, parse_manifest
from dbt_pathfinder.services.pathfinder_service import (
    AmbiguousNodeError,
    NoPathError,
    NodeNotFoundError,
    PathfinderError,
    PathfinderService,
)


@pytest.fixture
def manifest_path() -> Path:
    return Path(__file__).parent / "fixtures" / "manifest.json"


@pytest.fixture
def service(manifest_path: Path) -> PathfinderService:
    return PathfinderService.from_manifest(manifest_path)


def test_parse_manifest_success(manifest_path: Path) -> None:
    manifest = parse_manifest(manifest_path)
    assert "model.pkg.stg_orders" in manifest.nodes
    assert "source.pkg.raw_orders" in manifest.sources


def test_parse_manifest_file_not_found() -> None:
    with pytest.raises(ManifestParseError):
        parse_manifest("tests/fixtures/not_found_manifest.json")


def test_show_by_name(service: PathfinderService) -> None:
    payload = service.show("fct_orders")
    assert payload["node"] == "model.pkg.fct_orders"
    assert payload["upstream"] == ["model.pkg.stg_customers", "model.pkg.stg_orders"]
    assert payload["downstream"] == sorted(
        [
            "model.pkg.mart_customer_ltv",
            "test.pkg.not_null_fct_orders_order_id",
            "test.pkg.unique_fct_orders_order_id",
        ]
    )


def test_impact_groups_by_depth(service: PathfinderService) -> None:
    impact = service.impact("stg_orders")
    assert impact[1] == sorted(["model.pkg.fct_orders", "model.pkg.report_orders"])
    assert impact[2] == sorted(
        [
            "model.pkg.mart_customer_ltv",
            "test.pkg.not_null_fct_orders_order_id",
            "test.pkg.unique_fct_orders_order_id",
        ]
    )


def test_impact_command_json_output(service: PathfinderService) -> None:
    output = run_impact(service, "stg_orders", output="json")
    assert '"1"' in output
    assert "model.pkg.fct_orders" in output


def test_impact_command_bad_ui_raises(service: PathfinderService) -> None:
    with pytest.raises(PathfinderError):
        run_impact(service, "stg_orders", output="text", ui="bad_ui")


def test_directed_path(service: PathfinderService) -> None:
    path = service.path("stg_orders", "mart_customer_ltv", directed=True)
    assert path == [
        "model.pkg.stg_orders",
        "model.pkg.fct_orders",
        "model.pkg.mart_customer_ltv",
    ]


def test_path_explain_contains_join_key_and_cardinality(service: PathfinderService) -> None:
    payload = service.explain_path("stg_orders", "mart_customer_ltv", directed=True)
    assert payload["path"] == [
        "model.pkg.stg_orders",
        "model.pkg.fct_orders",
        "model.pkg.mart_customer_ltv",
    ]
    first_edge = payload["edges"][0]
    assert "o.customer_id = c.customer_id" in first_edge["join_keys"]
    assert first_edge["cardinality"] in {"N:1", "unknown"}


def test_path_explain_command_json_output(service: PathfinderService) -> None:
    output = run_path_explain(
        service,
        from_node="stg_orders",
        to_node="mart_customer_ltv",
        directed=True,
        output="json",
        ui="rich",
    )
    assert "join_keys" in output


def test_any_path_works_upstream(service: PathfinderService) -> None:
    path = service.path("mart_customer_ltv", "stg_orders", directed=False)
    assert path == [
        "model.pkg.mart_customer_ltv",
        "model.pkg.fct_orders",
        "model.pkg.stg_orders",
    ]


def test_no_directed_path_raises(service: PathfinderService) -> None:
    with pytest.raises(NoPathError):
        service.path("mart_customer_ltv", "stg_orders", directed=True)


def test_node_not_found_raises(service: PathfinderService) -> None:
    with pytest.raises(NodeNotFoundError):
        service.show("not_a_real_model")


def test_ambiguous_name_raises(service: PathfinderService) -> None:
    with pytest.raises(AmbiguousNodeError):
        service.show("dup_model")
