# Memory Backend Migration Guide

## Overview

PyClaw v2.0 uses LanceDB as the default memory backend, providing semantic search capabilities for better memory retrieval. This guide helps you migrate from SQLite to LanceDB or continue using SQLite if preferred.

## What Changed

| Feature | SQLite (Before) | LanceDB (Now Default) |
|---------|-----------------|------------------------|
| Search | Keyword matching (FTS5) | Semantic similarity + FTS5 |
| Recall | Exact keyword matches | Contextually relevant results |
| Performance | Fast for exact matches | Fast for semantic queries |
| Dependencies | Python stdlib | `lancedb` + `pyarrow` |

## For New Users

No action needed. LanceDB is automatically configured as the default backend:

```json5
// ~/.pyclaw/config.json5 (auto-generated defaults)
{
  memory: {
    backend: "lancedb",
    lancedbPath: "~/.pyclaw/memory-lance",
    embeddingDim: 1536
  }
}
```

## For Existing Users

### Option 1: Keep Using SQLite

If you prefer keyword-based search or have existing memories, add to your `~/.pyclaw/config.json5`:

```json5
{
  memory: {
    backend: "sqlite",
    sqlitePath: "~/.pyclaw/memory.db"
  }
}
```

Your existing memories will continue to work without changes.

### Option 2: Migrate to LanceDB

To benefit from semantic search, migrate your existing memories:

#### Step 1: Export Existing Memories

```bash
# Export all memories to JSON
pyclaw memory export --output memories-backup.json
```

#### Step 2: Update Configuration

```json5
// ~/.pyclaw/config.json5
{
  memory: {
    backend: "lancedb",
    lancedbPath: "~/.pyclaw/memory-lance",
    embeddingDim: 1536  // OpenAI default, adjust if using other models
  }
}
```

#### Step 3: Import Memories

```bash
# Import memories to LanceDB
pyclaw memory import --input memories-backup.json

# Verify migration
pyclaw memory count
```

#### Step 4: Verify and Clean Up

```bash
# Verify all memories migrated
pyclaw memory search "test query"

# Optionally remove old SQLite database
rm ~/.pyclaw/memory.db
```

## Configuration Reference

### MemoryConfig Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `backend` | `"sqlite"` \| `"lancedb"` | `"lancedb"` | Backend type |
| `lancedbPath` | string | `"~/.pyclaw/memory-lance"` | LanceDB database path |
| `sqlitePath` | string | `"~/.pyclaw/memory.db"` | SQLite database path |
| `embeddingDim` | integer | `1536` | Embedding vector dimension |

### Example: Custom Configuration

```json5
{
  memory: {
    backend: "lancedb",
    lancedbPath: "/data/pyclaw/memory-lance",
    embeddingDim: 768  // For other embedding models
  }
}
```

## Benefits of LanceDB

### Semantic Search

LanceDB finds memories based on meaning, not just keywords:

```
Query: "coffee preferences"
SQLite matches: Only memories containing "coffee" or "preferences"
LanceDB matches: "User likes espresso", "Prefers morning coffee", "Starbucks loyalty member"
```

### Hybrid Search

LanceDB combines vector similarity with keyword relevance:

1. **Vector Search**: Finds semantically similar content
2. **FTS5 Search**: Matches exact keywords
3. **Merge**: Weights and combines both results

This ensures you never miss exact matches while finding relevant context.

## Programmatic Usage

### Python API

```python
from pyclaw.config.schema import MemoryConfig, BackendType
from pyclaw.memory.backend import create_and_initialize_backend

# Use default (LanceDB)
backend = await create_and_initialize_backend()

# Use SQLite explicitly
config = MemoryConfig(backend=BackendType.SQLITE)
backend = await create_and_initialize_backend(config)

# Add memories
record = await backend.add("User prefers dark roast coffee", tags=["preference"])

# Search (semantically finds related content)
results = await backend.search("coffee drinks")
```

### Async Initialization

```python
from pyclaw.memory.backend import create_default_backend, create_and_initialize_backend

# Sync creation (needs initialization)
backend = create_default_backend()
await backend.initialize()

# Async creation (initialized automatically)
backend = await create_and_initialize_backend()
```

## Troubleshooting

### ImportError: lancedb is required

Install the LanceDB dependencies:

```bash
pip install lancedb pyarrow
```

### Embedding Dimension Mismatch

If your embedding model uses a different dimension:

```json5
{
  memory: {
    embeddingDim: 768  // Adjust to match your model
  }
}
```

Common dimensions:
- OpenAI `text-embedding-ada-002`: 1536
- OpenAI `text-embedding-3-small`: 1536
- OpenAI `text-embedding-3-large`: 3072
- Sentence transformers: varies (commonly 384, 768, 1024)

### Fallback to SQLite

If LanceDB fails to initialize, you can fallback:

```python
from pyclaw.config.schema import MemoryConfig, BackendType
from pyclaw.memory.backend import create_default_backend

config = MemoryConfig(backend=BackendType.LANCEDB)
try:
    backend = create_default_backend(config)
    await backend.initialize()
except ImportError:
    # Fallback to SQLite
    config = MemoryConfig(backend=BackendType.SQLITE)
    backend = create_default_backend(config)
    await backend.initialize()
```

## Related Documentation

- [Configuration Guide](../configuration.md)
- [Architecture Overview](../architecture.md)
- [API Reference](../api-reference.md)
