# Multiagent Module Migration Guide

**Version:** 1.0.0  
**Last Updated:** 2026-04-30

This guide helps you migrate from the legacy `orchestration/` and `collaboration/` modules to the unified `multiagent/` module.

---

## Overview

PyClaw has consolidated duplicate multiagent systems into a single `agents/multiagent/` module. The legacy modules (`orchestration/` and `collaboration/`) are now **deprecated** and will emit deprecation warnings when imported.

---

## Quick Reference

| Old Import | New Import |
|------------|------------|
| `pyclaw.agents.orchestration.mode.OrchestrationMode` | `pyclaw.agents.multiagent.types.OrchestrationMode` |
| `pyclaw.agents.orchestration.mode.OrchestrationResult` | `pyclaw.agents.multiagent.types.OrchestrationResult` |
| `pyclaw.agents.orchestration.engine.OrchestrationEngine` | `pyclaw.agents.multiagent.engine.MultiagentEngine` |
| `pyclaw.agents.orchestration.engines.CentralizedEngine` | `pyclaw.agents.multiagent.engines.CentralizedEngine` |
| `pyclaw.agents.orchestration.engines.PipelineEngine` | `pyclaw.agents.multiagent.engines.PipelineEngine` |
| `pyclaw.agents.collaboration.types.CollaborationModeType` | `pyclaw.agents.multiagent.types.CollaborationModeType` |
| `pyclaw.agents.collaboration.types.SubagentResult` | `pyclaw.agents.multiagent.types.SubagentResult` |

---

## Type Migrations

### Orchestration Types

**Before:**
```python
from pyclaw.agents.orchestration.mode import (
    OrchestrationMode,
    OrchestrationResult,
    OrchestrationContext,
    RetryPolicy,
    SubagentResult,
)
```

**After:**
```python
from pyclaw.agents.multiagent.types import (
    OrchestrationMode,
    OrchestrationResult,
    OrchestrationContext,
    RetryPolicy,
    SubagentResult,
)
```

### Collaboration Types

**Before:**
```python
from pyclaw.agents.collaboration.types import (
    CollaborationModeType,
    MultiagentResult,
    SpawnResult,
)
```

**After:**
```python
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    MultiagentResult,
    SpawnResult,
)
```

---

## Engine Migrations

### Using MultiagentEngine

**Before:**
```python
from pyclaw.agents.orchestration.engine import OrchestrationEngine

class MyEngine(OrchestrationEngine):
    ...
```

**After:**
```python
from pyclaw.agents.multiagent.engine import MultiagentEngine

class MyEngine(MultiagentEngine):
    ...
```

### Using Concrete Engines

**Before:**
```python
from pyclaw.agents.orchestration.engines import CentralizedEngine
from pyclaw.agents.orchestration.engines.pipeline import PipelineEngine
```

**After:**
```python
from pyclaw.agents.multiagent.engines import (
    CentralizedEngine,
    PipelineEngine,
    DynamicDecomposeEngine,
    ForkSwarmEngine,
    HybridEngine,
)
```

---

## Registry Migrations

### Using Registry Base Classes

**Before (manual implementation):**
```python
class MyRegistry:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._items = {}
        return cls._instance
```

**After (using base classes):**
```python
from pyclaw.agents.multiagent.registry import SingletonRegistry, Registry

class MyRegistry(SingletonRegistry[str, MyType], Registry):
    _instance: ClassVar[MyRegistry | None] = None
    
    def __init__(self) -> None:
        self._items: dict[str, MyType] = {}
```

### Thread-Safe Registry

**Before:**
```python
import threading

class MyRegistry:
    def __init__(self):
        self._items = {}
        self._lock = threading.RLock()
    
    def get(self, key):
        with self._lock:
            return self._items.get(key)
```

**After:**
```python
from pyclaw.agents.multiagent.registry import ThreadSafeRegistry

class MyRegistry(ThreadSafeRegistry[str, MyType]):
    pass  # Lock handling is built-in
```

---

## Deprecation Timeline

| Version | Status |
|---------|--------|
| 1.0.0 | Deprecation warnings added |
| 1.x.x | Legacy modules maintained as re-export shims |
| 2.0.0 | Legacy modules removed |

---

## Common Issues

### Import deprecation warnings

When you see:
```
DeprecationWarning: pyclaw.agents.orchestration is deprecated since version 1.0.0.
Use pyclaw.agents.multiagent instead.
```

This means you're importing from a deprecated module. Update your imports to use the new paths.

### Type mismatches

`SubagentResult` in `multiagent.types` includes all fields from the orchestration version:
- `agent_type: str`
- `session_id: str`
- `success: bool`
- `output: str`
- `error: str | None`
- `tokens_used: int`
- `duration_seconds: float`
- `started_at: datetime`
- `completed_at: datetime | None`

---

## Testing Your Migration

After updating imports, run the test suite:

```bash
pytest tests/pyclaw/agents/multiagent/ -v
```

All tests should pass without deprecation warnings.

---

## Need Help?

- See `docs/architecture/registry-patterns.md` for registry patterns
- Check `.planning/phases/` for detailed phase documentation
- Open an issue on GitHub if you encounter problems

---

*Migration Guide v1.0 — 2026-04-30*