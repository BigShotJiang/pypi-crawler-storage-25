# 多智能体协作框架设计文档

> **设计日期**: 2026-04-12
> **状态**: 设计评审通过，待实现
> **作者**: Claude + User
> **评审**: 2026-04-12 技术评审通过，已修订

---

## 1. 概述

### 1.1 目标

设计一个灵活的多智能体协作框架，支持：

- **Memory 系统**: 可插拔后端 + 多级作用域 + 插件化注册
- **Context Engineering**: LLM 压缩 + Token 预算 + Prompt 缓存
- **多智能体协作**: 中心化、去中心化、流水线、混合模式

### 1.2 设计原则

1. **能力注册架构**: 参考 openclaw 的 `registerMemoryCapability` 机制
2. **统一 Agent 定义**: 参考 claude-code 的 `AgentDefinition`
3. **插件化扩展**: 支持第三方扩展 Memory Provider、Context Engine
4. **渐进式迁移**: 与现有组件兼容，平滑升级

### 1.3 实现优先级

1. **框架骨架**: 核心抽象层（AgentCapabilityRegistry + AgentDefinition）
2. **Memory/Context**: Memory Provider + Context Engine
3. **协作模式**: Orchestration Engine + Task Decomposer

---

## 2. 核心抽象层

### 2.1 AgentCapabilityRegistry（能力注册中心）

```python
# src/pyclaw/agents/capabilities/registry.py

from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Callable

class CapabilityType(str, Enum):
    """能力类型"""
    MEMORY = "memory"
    CONTEXT = "context"
    ORCHESTRATION = "orchestration"
    KNOWLEDGE = "knowledge"

@dataclass
class AgentCapability:
    """单个能力的定义"""
    capability_type: CapabilityType
    name: str
    description: str
    provider: Callable  # 能力提供者工厂函数
    priority: int = 0   # 多个 provider 时的优先级
    tags: set[str] = field(default_factory=set)  # 灵活查询标签
    metadata: dict[str, Any] = field(default_factory=dict)

class AgentCapabilityRegistry:
    """能力注册中心 - 全局工厂单例
    
    设计说明：
    - 注册表仅作为"工厂"，存储能力定义和工厂函数
    - 实际能力实例由 AgentRuntime 创建并持有（会话级绑定）
    - 支持运行时动态注册，使用线程安全锁
    
    生命周期：
    - 注册表：全局单例，应用生命周期
    - 能力定义：全局，随注册/注销变化
    - 能力实例：由 AgentRuntime 管理，会话级
    """
    
    _instance: 'AgentCapabilityRegistry | None' = None
    _capabilities: dict[CapabilityType, list[AgentCapability]]
    _lock: threading.RLock  # 并发安全锁
    
    def __new__(cls) -> 'AgentCapabilityRegistry':
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._capabilities = {ct: [] for ct in CapabilityType}
            cls._instance._lock = threading.RLock()
        return cls._instance
    
    def register(self, capability: AgentCapability) -> None:
        """注册能力（线程安全）"""
        with self._lock:
            self._capabilities[capability.capability_type].append(capability)
        
    def unregister(self, capability_type: CapabilityType, name: str) -> bool:
        """注销能力（线程安全）"""
        with self._lock:
            caps = self._capabilities[capability_type]
            for i, cap in enumerate(caps):
                if cap.name == name:
                    caps.pop(i)
                    return True
        return False
        
    def get(self, capability_type: CapabilityType, name: str = None) -> AgentCapability | None:
        """获取能力"""
        caps = self._capabilities[capability_type]
        if name:
            for cap in caps:
                if cap.name == name:
                    return cap
            return None
        # 返回最高优先级的能力
        return max(caps, key=lambda c: c.priority) if caps else None
    
    def get_by_metadata(
        self,
        capability_type: CapabilityType,
        **filters,
    ) -> list[AgentCapability]:
        """通过 metadata 字段过滤能力
        
        示例：
            registry.get_by_metadata(CapabilityType.MEMORY, scope="project")
            registry.get_by_metadata(CapabilityType.MEMORY, plugin_id="my_plugin")
        """
        caps = self._capabilities[capability_type]
        result = []
        for cap in caps:
            match = True
            for key, value in filters.items():
                if cap.metadata.get(key) != value:
                    match = False
                    break
            if match:
                result.append(cap)
        return result
    
    def get_by_tags(
        self,
        capability_type: CapabilityType,
        tags: set[str],
        match_all: bool = False,
    ) -> list[AgentCapability]:
        """通过标签查询能力
        
        Args:
            tags: 要匹配的标签集合
            match_all: True 要求所有标签都匹配，False 要求任一标签匹配
        """
        caps = self._capabilities[capability_type]
        result = []
        for cap in caps:
            if match_all:
                if tags.issubset(cap.tags):
                    result.append(cap)
            else:
                if tags & cap.tags:  # 有交集
                    result.append(cap)
        return result
        
    def list_all(self, capability_type: CapabilityType = None) -> list[AgentCapability]:
        """列出所有能力"""
        if capability_type:
            return self._capabilities[capability_type]
        return [cap for caps in self._capabilities.values() for cap in caps]
    
    # 注意：initialize_all 和 shutdown_all 已移除
    # 能力实例的生命周期由 AgentRuntime 管理，而非注册表


def get_capability_registry() -> AgentCapabilityRegistry:
    """获取全局能力注册中心"""
    return AgentCapabilityRegistry()
```

### 2.2 AgentDefinition（统一 Agent 定义）

```python
# src/pyclaw/agents/definition.py

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

class TrustLevel(str, Enum):
    """Agent 信任级别 - 与工具权限控制对齐"""
    UNTRUSTED = "untrusted"  # 最低权限，仅安全工具
    BASIC = "basic"          # 基础权限，常用工具
    TRUSTED = "trusted"      # 高级权限，大部分工具
    FULL = "full"            # 完全信任，所有工具

class MemoryScope(str, Enum):
    """Memory 作用域"""
    USER = "user"        # ~/.pyclaw/memory/
    PROJECT = "project"  # .pyclaw/memory/
    LOCAL = "local"      # .pyclaw/memory-local/
    SESSION = "session"  # 会话级临时存储
    TEAM = "team"        # 团队共享存储

@dataclass
class ContextPolicy:
    """Context 策略配置"""
    compression_strategy: str = "summarize"  # truncate/summarize/dag
    threshold_percent: float = 0.75
    protect_first_n: int = 3
    tail_token_budget: int = 20000
    reserve_tokens_floor: int = 20000
    cache_strategy: str = "system"  # none/system/conversation/full

@dataclass
class OrchestrationConfig:
    """协作配置"""
    mode: str = "none"  # none/centralized/decentralized/pipeline/hybrid
    implementation: str | None = None  # 具体实现模式
    max_parallel: int = 4
    max_depth: int = 5
    timeout_seconds: int = 300

@dataclass
class AgentDefinition:
    """统一 Agent 定义
    
    参考 claude-code 的 AgentDefinition，整合所有配置。
    """
    # 基础信息
    agent_type: str
    display_name: str
    description: str
    
    # 信任级别
    trust_level: TrustLevel = TrustLevel.BASIC
    
    # Memory 配置
    memory_scope: MemoryScope = MemoryScope.PROJECT
    memory_backend: str = "builtin"  # builtin/lancedb/qdrant/...
    memory_enabled: bool = True
    
    # Context 策略
    context_policy: ContextPolicy = field(default_factory=ContextPolicy)
    
    # 协作配置
    orchestration: OrchestrationConfig = field(default_factory=OrchestrationConfig)
    
    # 工具配置
    tools_enabled: list[str] | None = None
    tools_disabled: list[str] | None = None
    
    # 知识库配置
    knowledge_sources: list[str] = field(default_factory=list)
    
    # 系统提示词
    system_prompt: str | None = None
    
    # 元数据
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def get_spawn_config(self, prompt: str, **kwargs) -> dict[str, Any]:
        """生成 spawn 配置"""
        return {
            "agent_type": self.agent_type,
            "prompt": prompt,
            "trust_level": self.trust_level.value,
            "memory_scope": self.memory_scope.value,
            "memory_backend": self.memory_backend,
            "context_policy": self.context_policy.__dict__,
            "orchestration": self.orchestration.__dict__,
            "tools_enabled": self.tools_enabled,
            "tools_disabled": self.tools_disabled,
            **kwargs
        }
```

---

## 3. Memory 系统

### 3.1 MemoryScope（多级作用域）

```python
# src/pyclaw/agents/memory/scope.py

from pathlib import Path
from dataclasses import dataclass
from enum import Enum

class MemoryScope(str, Enum):
    """Memory 作用域"""
    USER = "user"
    PROJECT = "project"
    LOCAL = "local"
    SESSION = "session"
    TEAM = "team"

@dataclass
class MemoryPath:
    """Memory 路径解析"""
    scope: MemoryScope
    base_dir: Path
    agent_type: str | None = None
    
    def resolve(self) -> Path:
        """解析完整路径"""
        if self.scope == MemoryScope.USER:
            return self.base_dir / ".pyclaw" / "memory"
        elif self.scope == MemoryScope.PROJECT:
            return self.base_dir / ".pyclaw" / "memory"
        elif self.scope == MemoryScope.LOCAL:
            return self.base_dir / ".pyclaw" / "memory-local"
        elif self.scope == MemoryScope.SESSION:
            return self.base_dir / ".pyclaw" / "sessions" / (self.agent_type or "default")
        elif self.scope == MemoryScope.TEAM:
            return self.base_dir / ".pyclaw" / "team" / "memory"
        raise ValueError(f"Unknown scope: {self.scope}")
```

### 3.2 MemoryProvider（可插拔后端）

```python
# src/pyclaw/agents/memory/provider.py

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any

@dataclass
class MemoryEntry:
    """记忆条目"""
    id: str
    content: str
    created_at: datetime
    updated_at: datetime
    metadata: dict[str, Any]
    score: float = 0.0

class MemoryProvider(ABC):
    """Memory 提供者抽象基类
    
    参考 hermes-agent 的 MemoryProvider 设计。
    每个 Provider 实例对应一个作用域。
    
    设计要点：
    - 生命周期由 AgentRuntime 管理（会话级）
    - 工具 schema 由 MemoryToolAdapter 生成，而非 Provider 直接提供
    - 向量后端通过 EmbeddingProvider 获取 embedding
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """提供者名称"""
        
    # -- 生命周期 --
    
    async def initialize(self, **kwargs) -> None:
        """初始化（生命周期钩子）"""
        pass
        
    async def shutdown(self) -> None:
        """关闭（生命周期钩子）"""
        pass
    
    # -- CRUD --
    
    @abstractmethod
    async def add(self, content: str, metadata: dict = None) -> str:
        """添加记忆，返回条目 ID"""
        
    @abstractmethod
    async def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        """搜索记忆"""
        
    @abstractmethod
    async def get(self, entry_id: str) -> MemoryEntry | None:
        """获取单条记忆"""
        
    @abstractmethod
    async def update(self, entry_id: str, content: str = None, metadata: dict = None) -> bool:
        """更新记忆"""
        
    @abstractmethod
    async def delete(self, entry_id: str) -> bool:
        """删除记忆"""
    
    # -- 批量操作 --
    
    async def add_batch(self, entries: list[tuple[str, dict]]) -> list[str]:
        """批量添加"""
        return [await self.add(content, metadata) for content, metadata in entries]
    
    # -- 状态 --
    
    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        return {"provider": self.name}
```

### 3.3 EmbeddingProvider（向量嵌入抽象）

```python
# src/pyclaw/agents/memory/embedding.py

from abc import ABC, abstractmethod
from typing import Any

class EmbeddingProvider(ABC):
    """Embedding 提供者抽象基类
    
    向量存储后端通过此接口获取 embedding，实现存储与 embedding 解耦。
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """提供者名称"""
    
    @property
    @abstractmethod
    def dimension(self) -> int:
        """向量维度"""
        
    @abstractmethod
    async def embed(self, texts: list[str]) -> list[list[float]]:
        """生成文本 embedding
        
        Args:
            texts: 文本列表
            
        Returns:
            向量列表，每个向量为 dimension 维
        """
        
    @abstractmethod
    async def embed_query(self, query: str) -> list[float]:
        """生成查询 embedding（可能与文档 embedding 不同）"""


class OpenAIEmbeddingProvider(EmbeddingProvider):
    """OpenAI Embedding 提供者"""
    
    name = "openai"
    
    def __init__(self, model: str = "text-embedding-3-small", api_key: str = None):
        self._model = model
        self._api_key = api_key
        # 维度映射
        self._dimensions = {
            "text-embedding-3-small": 1536,
            "text-embedding-3-large": 3072,
            "text-embedding-ada-002": 1536,
        }
        
    @property
    def dimension(self) -> int:
        return self._dimensions.get(self._model, 1536)
        
    async def embed(self, texts: list[str]) -> list[list[float]]:
        # 调用 OpenAI API
        ...
        
    async def embed_query(self, query: str) -> list[float]:
        return (await self.embed([query]))[0]


class LocalEmbeddingProvider(EmbeddingProvider):
    """本地 Embedding 提供者（sentence-transformers）"""
    
    name = "local"
    
    def __init__(self, model: str = "all-MiniLM-L6-v2"):
        self._model_name = model
        self._model = None  # 延迟加载
        
    @property
    def dimension(self) -> int:
        # 根据 model 返回维度
        return 384  # all-MiniLM-L6-v2
```

### 3.4 内置提供者

```python
# src/pyclaw/agents/memory/providers/builtin.py

from pathlib import Path
import json
import threading
from typing import Any

class BuiltinMemoryProvider(MemoryProvider):
    """内置 JSONL 存储 - 升级现有 MemoryDirectory
    
    设计要点：
    - 内部封装搜索逻辑，不直接依赖外部模块
    - 使用适配器模式隔离现有实现
    """
    
    name = "builtin"
    
    def __init__(self, storage_path: Path) -> None:
        self._storage_path = storage_path
        self._lock = threading.Lock()
        self._cache: dict[str, list[MemoryEntry]] = {}
        self._search_adapter: '_MemorySearchAdapter | None' = None
        
    async def initialize(self, **kwargs) -> None:
        self._storage_path.mkdir(parents=True, exist_ok=True)
        # 延迟初始化搜索适配器
        self._search_adapter = _MemorySearchAdapter(self._storage_path)
        
    async def add(self, content: str, metadata: dict = None) -> str:
        import uuid
        entry_id = str(uuid.uuid4())
        entry = MemoryEntry(
            id=entry_id,
            content=content,
            created_at=datetime.now(),
            updated_at=datetime.now(),
            metadata=metadata or {},
        )
        self._append_entry(entry)
        return entry_id
        
    async def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        # 通过适配器搜索，隔离外部依赖
        if self._search_adapter:
            return self._search_adapter.search(query, limit=limit)
        return []
        
    # ... 其他方法实现


class _MemorySearchAdapter:
    """内部搜索适配器 - 封装 BM25 搜索逻辑
    
    将现有 find_relevant_memories 实现封装为内部类，
    避免直接暴露外部依赖。
    """
    
    def __init__(self, storage_path: Path) -> None:
        self._storage_path = storage_path
        
    def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        """执行 BM25 搜索"""
        # 内部实现，可替换为其他搜索算法
        try:
            from pyclaw.agents.memory_dir.find_relevant_memories import (
                search_all_memory_files,
            )
            return search_all_memory_files(query, [self._storage_path], limit=limit)
        except ImportError:
            # 降级为简单文本匹配
            return self._fallback_search(query, limit)
            
    def _fallback_search(self, query: str, limit: int) -> list[MemoryEntry]:
        """降级搜索：简单文本匹配"""
        # 简单实现
        ...


# src/pyclaw/agents/memory/providers/lancedb.py

class LanceDBMemoryProvider(MemoryProvider):
    """LanceDB 向量存储后端
    
    通过 EmbeddingProvider 接口获取 embedding，实现存储与 embedding 解耦。
    """
    
    name = "lancedb"
    
    def __init__(
        self,
        storage_path: Path,
        embedding_provider: EmbeddingProvider | None = None,
    ) -> None:
        self._storage_path = storage_path
        self._embedding = embedding_provider  # 注入，而非内部创建
        self._table = None
        
    async def initialize(self, **kwargs) -> None:
        import lancedb
        self._db = lancedb.connect(self._storage_path)
        # 如果没有注入 embedding provider，使用默认
        if self._embedding is None:
            from pyclaw.agents.memory.embedding import OpenAIEmbeddingProvider
            self._embedding = OpenAIEmbeddingProvider()
        # 创建或打开表
        ...
        
    async def add(self, content: str, metadata: dict = None) -> str:
        # 通过 embedding provider 获取向量
        embedding = await self._embedding.embed([content])
        # 存储
        ...
        
    async def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        # 通过 embedding provider 获取查询向量
        query_embedding = await self._embedding.embed_query(query)
        # 向量搜索
        ...


# src/pyclaw/agents/memory/providers/qdrant.py

class QdrantMemoryProvider(MemoryProvider):
    """Qdrant 向量数据库后端"""
    
    name = "qdrant"
    ...
```

### 3.4 MemoryCapability 注册

```python
# src/pyclaw/agents/memory/capability.py

from pyclaw.agents.capabilities.registry import (
    AgentCapability,
    CapabilityType,
    get_capability_registry,
)
from pyclaw.agents.memory.provider import MemoryProvider
from pyclaw.agents.memory.scope import MemoryScope

def register_memory_capability(
    plugin_id: str,
    provider: MemoryProvider,
    scope: MemoryScope = MemoryScope.PROJECT,
    priority: int = 0,
) -> None:
    """注册 Memory 能力
    
    参考 openclaw 的 registerMemoryCapability。
    """
    registry = get_capability_registry()
    registry.register(AgentCapability(
        capability_type=CapabilityType.MEMORY,
        name=f"{provider.name}:{scope.value}",
        description=f"Memory provider '{provider.name}' for {scope.value} scope",
        provider=lambda: provider,
        priority=priority,
        metadata={
            "scope": scope,
            "plugin_id": plugin_id,
        },
    ))


def get_memory_provider(
    scope: MemoryScope = MemoryScope.PROJECT,
    backend: str = "builtin",
) -> MemoryProvider | None:
    """获取 Memory Provider"""
    registry = get_capability_registry()
    cap = registry.get(
        CapabilityType.MEMORY,
        name=f"{backend}:{scope.value}",
    )
    return cap.provider() if cap else None
```

---

## 4. Context Engineering

### 4.1 ContextPolicy（策略配置）

```python
# src/pyclaw/agents/context/policy.py

from dataclasses import dataclass
from enum import Enum

class CompressionStrategy(str, Enum):
    """压缩策略"""
    TRUNCATE = "truncate"       # 简单截断
    SUMMARIZE = "summarize"     # LLM 总结压缩
    DAG = "dag"                 # DAG 结构化压缩

class CacheStrategy(str, Enum):
    """缓存策略"""
    NONE = "none"
    SYSTEM = "system"           # 系统提示缓存
    CONVERSATION = "conversation" # 对话历史缓存
    FULL = "full"               # 全量缓存

@dataclass
class ContextPolicy:
    """Context 策略配置"""
    
    # 压缩策略
    compression_strategy: CompressionStrategy = CompressionStrategy.SUMMARIZE
    threshold_percent: float = 0.75      # 触发压缩阈值
    protect_first_n: int = 3             # 保护头部消息数
    tail_token_budget: int = 20000       # 保护尾部 token 数
    
    # Token 预算
    reserve_tokens_floor: int = 20000    # 保留底线
    soft_threshold_tokens: int = 4000    # 软阈值
    
    # 缓存策略
    cache_strategy: CacheStrategy = CacheStrategy.SYSTEM
    cache_ttl_seconds: int = 300         # 缓存 TTL
    
    # LLM 压缩配置
    summary_model: str | None = None     # 专用总结模型
    summary_budget_ratio: float = 0.20   # 总结占压缩内容的比例
```

### 4.2 ContextEngine（抽象引擎）

```python
# src/pyclaw/agents/context/engine.py

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

@dataclass
class CompressionResult:
    """压缩结果"""
    original_messages: int
    compressed_messages: int
    tokens_saved: int
    summary: str | None = None

@dataclass
class MessageContext:
    """增强的消息上下文结构
    
    包含消息的完整元数据，用于压缩时的工具调用配对完整性检查。
    """
    role: str
    content: str
    timestamp: float = 0.0
    tool_call_id: str | None = None  # 工具调用 ID
    tool_calls: list[dict] | None = None  # assistant 的工具调用
    parent_id: str | None = None  # 父消息 ID（用于配对）
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_api_message(self) -> dict[str, Any]:
        """转换为 API 消息格式"""
        msg = {"role": self.role, "content": self.content}
        if self.tool_calls:
            msg["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            msg["tool_call_id"] = self.tool_call_id
        return msg

class ContextEngine(ABC):
    """Context 引擎抽象基类
    
    参考 hermes-agent 的 ContextEngine 设计。
    
    生命周期说明：
    - 每个会话创建一个 Engine 实例（由 AgentRuntime 管理）
    - Token 状态是实例级的，绑定到会话
    - 不支持跨会话共享
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """引擎名称"""
        
    # -- 生命周期 --
    
    def initialize(self, **kwargs) -> None:
        """初始化"""
        if 'context_length' in kwargs:
            self.context_length = kwargs['context_length']
            self.threshold_tokens = int(self.context_length * self.threshold_percent)
        
    def shutdown(self) -> None:
        """关闭"""
        pass
    
    # -- Token 状态（会话级，由 AgentRuntime 传入使用量） --
    
    last_prompt_tokens: int = 0
    last_completion_tokens: int = 0
    last_total_tokens: int = 0
    threshold_tokens: int = 0
    context_length: int = 0
    compression_count: int = 0
    
    # -- 配置参数 --
    
    threshold_percent: float = 0.75
    protect_first_n: int = 3
    protect_last_n: int = 6
    
    # -- 核心接口 --
    
    @abstractmethod
    def update_from_response(self, usage: dict[str, Any]) -> None:
        """从 API 响应更新 token 统计
        
        注意：此方法是会话级的，并发调用由上层 AgentRuntime 保证互斥。
        """
        
    @abstractmethod
    def should_compress(self, prompt_tokens: int = None) -> bool:
        """判断是否需要压缩"""
        
    @abstractmethod
    def compress(
        self,
        messages: list[dict[str, Any]] | list[MessageContext],
        focus_topic: str = None,
    ) -> list[dict[str, Any]]:
        """执行压缩
        
        Args:
            messages: 消息列表（支持简单 dict 或增强的 MessageContext）
            focus_topic: 可选的聚焦主题（引导压缩保留相关内容）
            
        Returns:
            压缩后的 API 消息列表
            
        设计要点：
        - 支持 MessageContext 结构，包含工具调用 ID 等元数据
        - 压缩时保持 tool_use / tool_result 配对完整性
        - 返回的标准 dict 格式可直接传给 API
        """
    
    # -- 预检（可选） --
    
    def should_compress_preflight(self, messages: list[dict[str, Any]]) -> bool:
        """预检是否需要压缩（无真实 token 计数）"""
        return False
    
    # -- 状态 --
    
    def get_status(self) -> dict[str, Any]:
        """获取状态"""
        return {
            "last_prompt_tokens": self.last_prompt_tokens,
            "threshold_tokens": self.threshold_tokens,
            "context_length": self.context_length,
            "usage_percent": (
                min(100, self.last_prompt_tokens / self.context_length * 100)
                if self.context_length else 0
            ),
            "compression_count": self.compression_count,
        }
```

### 4.3 SummarizeEngine（LLM 总结引擎）

```python
# src/pyclaw/agents/context/engines/summarize.py

class SummarizeEngine(ContextEngine):
    """LLM 总结压缩引擎
    
    参考 hermes-agent 的 ContextCompressor 实现。
    核心特性：
    - 结构化总结模板（Goal/Progress/Decisions/Resolved/Pending）
    - 迭代更新支持
    - Tail token budget 保护
    - 工具调用配对完整性
    """
    
    name = "summarize"
    
    # 结构化总结模板
    SUMMARY_TEMPLATE = """## Goal
    [What the user is trying to accomplish]
    
    ## Constraints & Preferences
    [User preferences, coding style, constraints, important decisions]
    
    ## Progress
    ### Done
    [Completed work — include specific file paths, commands run, results obtained]
    ### In Progress
    [Work currently underway]
    ### Blocked
    [Any blockers or issues encountered]
    
    ## Key Decisions
    [Important technical decisions and why they were made]
    
    ## Resolved Questions
    [Questions the user asked that were ALREADY answered]
    
    ## Pending User Asks
    [Questions or requests NOT yet answered]
    
    ## Relevant Files
    [Files read, modified, or created]
    
    ## Remaining Work
    [What remains to be done]
    
    ## Critical Context
    [Specific values, errors, config details to preserve]
    """
    
    def __init__(
        self,
        model: str,
        threshold_percent: float = 0.50,
        summary_model: str | None = None,
        **kwargs,
    ):
        self.model = model
        self.summary_model = summary_model or model
        self._previous_summary: str | None = None
        super().__init__()
        
    def compress(
        self,
        messages: list[dict[str, Any]],
        focus_topic: str = None,
    ) -> list[dict[str, Any]]:
        """执行压缩
        
        算法：
        1. 剪枝旧工具结果
        2. 保护头部消息
        3. Token 预算保护尾部
        4. LLM 总结中间消息
        5. 迭代更新总结
        """
        # ... 实现细节
```

### 4.4 ContextCapability 注册

```python
# src/pyclaw/agents/context/capability.py

from pyclaw.agents.capabilities.registry import (
    AgentCapability,
    CapabilityType,
    get_capability_registry,
)
from pyclaw.agents.context.engine import ContextEngine
from pyclaw.agents.context.policy import ContextPolicy

def register_context_capability(
    plugin_id: str,
    engine: ContextEngine,
    policy: ContextPolicy | None = None,
    priority: int = 0,
) -> None:
    """注册 Context 能力"""
    registry = get_capability_registry()
    registry.register(AgentCapability(
        capability_type=CapabilityType.CONTEXT,
        name=f"{engine.name}:{plugin_id}",
        description=f"Context engine '{engine.name}' from {plugin_id}",
        provider=lambda: engine,
        priority=priority,
        metadata={
            "policy": policy or ContextPolicy(),
            "plugin_id": plugin_id,
        },
    ))


def get_context_engine(name: str = "summarize") -> ContextEngine | None:
    """获取 Context Engine"""
    registry = get_capability_registry()
    cap = registry.get(CapabilityType.CONTEXT, name=name)
    return cap.provider() if cap else None
```

---

## 5. 多智能体协作

### 5.1 OrchestrationMode（协作模式）

```python
# src/pyclaw/agents/orchestration/mode.py

from dataclasses import dataclass, field
from enum import Enum

class OrchestrationMode(str, Enum):
    """协作模式"""
    NONE = "none"                   # 单 Agent
    CENTRALIZED = "centralized"     # 中心化协调
    DECENTRALIZED = "decentralized" # 去中心化网络
    PIPELINE = "pipeline"           # 流水线式
    HYBRID = "hybrid"               # 混合可配置

@dataclass
class RetryPolicy:
    """重试策略"""
    max_retries: int = 2
    retry_delay_seconds: float = 1.0
    backoff_multiplier: float = 2.0

@dataclass
class OrchestrationConfig:
    """协作配置"""
    
    mode: OrchestrationMode = OrchestrationMode.NONE
    implementation: str | None = None  # 具体实现模式
    
    # 中心化配置
    max_parallel: int = 4           # 最大并行数
    max_depth: int = 5              # 最大嵌套深度
    
    # 流水线配置
    pipeline_stages: list[str] = field(default_factory=list)
    
    # 网络配置（去中心化）
    agent_graph: dict[str, list[str]] = field(default_factory=dict)
    
    # 通用配置
    timeout_seconds: int = 300
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
```

### 5.2 OrchestrationEngine（协作引擎）

```python
# src/pyclaw/agents/orchestration/engine.py

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

@dataclass
class OrchestrationContext:
    """协作上下文"""
    session_id: str
    workspace_dir: str
    parent_session_id: str | None = None
    metadata: dict[str, Any] = None

@dataclass
class OrchestrationResult:
    """协作结果"""
    success: bool
    total_subtasks: int
    completed: int
    failed: int
    results: dict[str, Any]
    errors: list[dict[str, Any]]

@dataclass
class SubagentResult:
    """子 Agent 执行结果"""
    session_id: str
    agent_id: str
    state: str  # completed/failed/aborted
    output: str = ""
    error: str | None = None
    tokens_used: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

class OrchestrationEngine(ABC):
    """协作引擎抽象基类"""
    
    @property
    @abstractmethod
    def mode(self) -> OrchestrationMode:
        """协作模式"""
        
    @abstractmethod
    async def execute(
        self,
        goal: str,
        config: OrchestrationConfig,
        context: OrchestrationContext,
    ) -> OrchestrationResult:
        """执行协作任务"""
        
    @abstractmethod
    async def spawn_agent(
        self,
        definition: AgentDefinition,
        prompt: str,
    ) -> 'SubagentResult':
        """生成子 Agent"""
        
    @abstractmethod
    async def kill_agent(self, agent_id: str) -> bool:
        """终止子 Agent"""
    
    @abstractmethod
    async def steer_agent(self, agent_id: str, instruction: str) -> bool:
        """向子 Agent 发送指令"""
```

### 5.3 CentralizedEngine（中心化协调引擎）

```python
# src/pyclaw/agents/orchestration/engines/centralized.py

import asyncio
from dataclasses import dataclass

@dataclass
class Subtask:
    """子任务"""
    id: str
    description: str
    agent_type: str
    priority: int = 5
    dependencies: list[str] = None
    status: str = "pending"
    result: str = ""
    error: str | None = None

class CentralizedEngine(OrchestrationEngine):
    """中心化协调引擎
    
    扩展现有 CoordinatorMode 实现。
    核心特性：
    - 任务分解（规则或 LLM 驱动）
    - 依赖图（DAG）调度
    - 并行执行控制
    - 结果聚合
    """
    
    mode = OrchestrationMode.CENTRALIZED
    
    def __init__(
        self,
        subagent_manager: 'SubagentManager',
        decomposer: 'TaskDecomposer | None' = None,
    ) -> None:
        self._manager = subagent_manager
        self._decomposer = decomposer or RuleBasedDecomposer()
        self._subtasks: dict[str, Subtask] = {}
        self._results: dict[str, Any] = {}
        self._semaphore: asyncio.Semaphore | None = None
        
    async def execute(
        self,
        goal: str,
        config: OrchestrationConfig,
        context: OrchestrationContext,
    ) -> OrchestrationResult:
        """执行中心化协调"""
        # 初始化信号量
        self._semaphore = asyncio.Semaphore(config.max_parallel)
        
        # 1. 分解任务
        subtasks = await self._decomposer.decompose(goal, config)
        self._subtasks = {st.id: st for st in subtasks}
        
        # 2. 按依赖执行
        await self._execute_with_dependencies(config)
        
        # 3. 聚合结果
        return self._aggregate_results()
        
    async def _execute_with_dependencies(
        self,
        config: OrchestrationConfig,
    ) -> None:
        """按依赖关系执行子任务
        
        设计要点：
        - 使用信号量控制并行度
        - 异常时正确释放信号量
        - 支持重试策略
        """
        while True:
            # 找到可执行的任务（依赖已满足）
            ready = [
                st for st in self._subtasks.values()
                if st.status == "pending"
                and all(
                    self._subtasks[dep].status == "completed"
                    for dep in (st.dependencies or [])
                )
            ]
            
            if not ready:
                running = [st for st in self._subtasks.values() if st.status == "running"]
                if not running:
                    break
                await asyncio.sleep(0.5)
                continue
            
            # 按优先级排序
            ready.sort(key=lambda st: st.priority)
            
            # 启动任务
            for subtask in ready:
                asyncio.create_task(self._run_subtask(subtask, config))
            
            await asyncio.sleep(0.5)
            
    async def _run_subtask(
        self,
        subtask: Subtask,
        config: OrchestrationConfig,
    ) -> None:
        """执行单个子任务"""
        async with self._semaphore:
            subtask.status = "running"
            try:
                result = await self.spawn_agent(
                    definition=self._get_agent_definition(subtask.agent_type),
                    prompt=subtask.description,
                )
                if result.state == "completed":
                    subtask.status = "completed"
                    subtask.result = result.output
                    self._results[subtask.id] = result.output
                else:
                    raise Exception(result.error or "Subtask failed")
            except Exception as e:
                subtask.error = str(e)
                if subtask.retry_count < config.retry_policy.max_retries:
                    subtask.retry_count += 1
                    subtask.status = "pending"
                else:
                    subtask.status = "failed"


# ------------------------------------------------------------
# TaskDecomposer（任务分解器）
# ------------------------------------------------------------

class TaskDecomposer(ABC):
    """任务分解器抽象基类"""
    
    @abstractmethod
    async def decompose(
        self,
        goal: str,
        config: OrchestrationConfig,
    ) -> list[Subtask]:
        """将目标分解为子任务"""
        

class RuleBasedDecomposer(TaskDecomposer):
    """基于规则的任务分解器
    
    使用预定义的四阶段分解：explore → plan → execute → verify
    """
    
    async def decompose(
        self,
        goal: str,
        config: OrchestrationConfig,
    ) -> list[Subtask]:
        return [
            Subtask(
                id="explore",
                description=f"Explore and understand: {goal}",
                agent_type="explore",
                priority=1,
            ),
            Subtask(
                id="plan",
                description=f"Create implementation plan for: {goal}",
                agent_type="plan",
                priority=2,
                dependencies=["explore"],
            ),
            Subtask(
                id="execute",
                description=f"Execute the planned implementation for: {goal}",
                agent_type="general_purpose",
                priority=3,
                dependencies=["plan"],
            ),
            Subtask(
                id="verify",
                description=f"Verify the implementation for: {goal}",
                agent_type="verification",
                priority=4,
                dependencies=["execute"],
            ),
        ]


class LLMTaskDecomposer(TaskDecomposer):
    """基于 LLM 的任务分解器
    
    使用 LLM 动态分解复杂任务为结构化任务图。
    """
    
    DECOMPOSE_PROMPT = """You are a task decomposition expert. Break down the following goal into subtasks.

Goal: {goal}

Output a JSON array of subtasks with this structure:
[
  {{
    "id": "unique-id",
    "description": "What this subtask should accomplish",
    "agent_type": "explore|plan|general_purpose|verification",
    "priority": 1-10,
    "dependencies": ["id of subtasks this depends on"]
  }}
]

Rules:
1. Each subtask should be completable by a single agent
2. Dependencies should form a DAG (no cycles)
3. Lower priority = execute first
4. Use appropriate agent types:
   - explore: Research and understand
   - plan: Design and strategize
   - general_purpose: Execute implementation
   - verification: Test and validate

Output ONLY the JSON array, no other text."""

    def __init__(self, model: str, provider: str = "anthropic") -> None:
        self._model = model
        self._provider = provider
        
    async def decompose(
        self,
        goal: str,
        config: OrchestrationConfig,
    ) -> list[Subtask]:
        # 调用 LLM 进行分解
        prompt = self.DECOMPOSE_PROMPT.format(goal=goal)
        response = await self._call_llm(prompt)
        
        # 解析 JSON
        import json
        try:
            subtasks_raw = json.loads(response)
            return [
                Subtask(
                    id=st["id"],
                    description=st["description"],
                    agent_type=st.get("agent_type", "general_purpose"),
                    priority=st.get("priority", 5),
                    dependencies=st.get("dependencies", []),
                )
                for st in subtasks_raw
            ]
        except json.JSONDecodeError:
            # 降级为规则分解
            return await RuleBasedDecomposer().decompose(goal, config)
    
    async def _call_llm(self, prompt: str) -> str:
        """调用 LLM"""
        # 实现细节
        ...
```

### 5.4 OrchestrationCapability 注册

```python
# src/pyclaw/agents/orchestration/capability.py

from pyclaw.agents.capabilities.registry import (
    AgentCapability,
    CapabilityType,
    get_capability_registry,
)
from pyclaw.agents.orchestration.engine import OrchestrationEngine
from pyclaw.agents.orchestration.mode import OrchestrationConfig

def register_orchestration_capability(
    plugin_id: str,
    engine: OrchestrationEngine,
    config: OrchestrationConfig | None = None,
    priority: int = 0,
) -> None:
    """注册协作能力"""
    registry = get_capability_registry()
    registry.register(AgentCapability(
        capability_type=CapabilityType.ORCHESTRATION,
        name=f"{engine.mode.value}:{plugin_id}",
        description=f"Orchestration engine '{engine.mode.value}' from {plugin_id}",
        provider=lambda: engine,
        priority=priority,
        metadata={
            "config": config or OrchestrationConfig(),
            "plugin_id": plugin_id,
        },
    ))
```

---

## 6. 集成方案

### 6.1 AgentRuntime（统一运行时）

```python
# src/pyclaw/agents/runtime.py

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, AsyncGenerator

from pyclaw.agents.definition import AgentDefinition
from pyclaw.agents.memory.provider import MemoryProvider
from pyclaw.agents.context.engine import ContextEngine
from pyclaw.agents.orchestration.engine import OrchestrationEngine

class RuntimeState(str, Enum):
    """运行时状态"""
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class AgentEvent:
    """Agent 事件"""
    type: str
    data: Any = None
    timestamp: float = 0.0

@dataclass
class AgentRuntime:
    """Agent 统一运行时
    
    整合所有能力，提供统一执行接口。
    """
    
    # Agent 定义
    definition: AgentDefinition
    
    # 能力实例（从注册表获取）
    memory_provider: MemoryProvider | None = None
    context_engine: ContextEngine | None = None
    orchestration_engine: OrchestrationEngine | None = None
    
    # 工具注册表
    tool_registry: 'ToolRegistry' = field(default_factory=lambda: ToolRegistry())
    
    # 状态
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    state: RuntimeState = RuntimeState.IDLE
    
    # 内部状态
    _messages: list[dict] = field(default_factory=list)
    _last_response: str = ""
    
    async def initialize(self) -> None:
        """初始化所有能力"""
        # 获取能力实例
        if self.definition.memory_enabled:
            self.memory_provider = get_memory_provider(
                scope=self.definition.memory_scope,
                backend=self.definition.memory_backend,
            )
            if self.memory_provider:
                await self.memory_provider.initialize(session_id=self.session_id)
                
        # Context Engine
        self.context_engine = get_context_engine(
            name=self.definition.context_policy.compression_strategy.value
        )
        if self.context_engine:
            self.context_engine.initialize()
            
        # Orchestration Engine
        if self.definition.orchestration.mode != OrchestrationMode.NONE:
            self.orchestration_engine = get_orchestration_engine(
                mode=self.definition.orchestration.mode
            )
            
    async def shutdown(self) -> None:
        """关闭所有能力"""
        if self.memory_provider:
            await self.memory_provider.shutdown()
            
    async def run(
        self,
        prompt: str,
        **kwargs,
    ) -> AsyncGenerator[AgentEvent, None]:
        """运行 Agent"""
        self.state = RuntimeState.RUNNING
        
        try:
            # 1. 注入 Memory context
            memory_context = ""
            if self.memory_provider:
                memory_context = await self._build_memory_context(prompt)
                
            # 2. 构建消息
            messages = self._build_messages(prompt, memory_context)
            
            # 3. Context 预处理
            if self.context_engine:
                messages = self._preprocess_context(messages)
                
            # 4. 执行主循环
            async for event in self._run_loop(messages, **kwargs):
                yield event
                
            # 5. 后处理
            await self._postprocess(prompt)
            
            self.state = RuntimeState.COMPLETED
            
        except Exception as e:
            self.state = RuntimeState.FAILED
            yield AgentEvent(type="error", data=str(e))
            
    async def _build_memory_context(self, prompt: str) -> str:
        """构建 Memory context"""
        if not self.memory_provider:
            return ""
        entries = await self.memory_provider.search(prompt, limit=20)
        return "\n".join([e.content for e in entries])
        
    def _build_messages(self, prompt: str, memory_context: str) -> list[dict]:
        """构建消息列表"""
        messages = []
        
        # 系统提示
        system_prompt = self.definition.system_prompt or self._default_system_prompt()
        if memory_context:
            system_prompt += f"\n\n<memory-context>\n{memory_context}\n</memory-context>"
        messages.append({"role": "system", "content": system_prompt})
        
        # 历史消息
        messages.extend(self._messages)
        
        # 用户输入
        messages.append({"role": "user", "content": prompt})
        
        return messages
        
    def _preprocess_context(self, messages: list[dict]) -> list[dict]:
        """Context 预处理"""
        if not self.context_engine:
            return messages
            
        if self.context_engine.should_compress_preflight(messages):
            return self.context_engine.compress(messages)
            
        return messages
        
    async def _run_loop(
        self,
        messages: list[dict],
        **kwargs,
    ) -> AsyncGenerator[AgentEvent, None]:
        """主执行循环"""
        from pyclaw.agents.runner import run_agent
        
        async for event in run_agent(
            messages=messages,
            tools=self.tool_registry.all(),
            **kwargs,
        ):
            if event.type == "message_update":
                self._last_response += event.delta or ""
            yield event
            
    async def _postprocess(self, prompt: str) -> None:
        """后处理"""
        # 同步到 Memory
        if self.memory_provider:
            await self.memory_provider.add(
                f"User: {prompt}\nAssistant: {self._last_response}",
                metadata={"type": "conversation"},
            )
```

### 6.2 目录结构

```
src/pyclaw/agents/
├── capabilities/           # 能力注册
│   ├── __init__.py
│   ├── registry.py        # AgentCapabilityRegistry
│   └── types.py           # CapabilityType, AgentCapability
│
├── memory/                 # Memory 系统
│   ├── __init__.py
│   ├── scope.py           # MemoryScope, MemoryPath
│   ├── provider.py        # MemoryProvider ABC
│   ├── providers/         # 内置提供者
│   │   ├── __init__.py
│   │   ├── builtin.py     # JSONL + BM25
│   │   ├── lancedb.py     # LanceDB 向量
│   │   └── qdrant.py      # Qdrant
│   └── capability.py      # register_memory_capability
│
├── context/                # Context Engineering
│   ├── __init__.py
│   ├── policy.py          # ContextPolicy, CompressionStrategy
│   ├── engine.py          # ContextEngine ABC
│   ├── engines/           # 内置引擎
│   │   ├── __init__.py
│   │   ├── summarize.py   # LLM 总结
│   │   ├── truncate.py    # 简单截断
│   │   └── dag.py         # DAG（可选）
│   └── capability.py      # register_context_capability
│
├── orchestration/          # 多智能体协作
│   ├── __init__.py
│   ├── mode.py            # OrchestrationMode, OrchestrationConfig
│   ├── engine.py          # OrchestrationEngine ABC
│   ├── engines/           # 内置引擎
│   │   ├── __init__.py
│   │   ├── centralized.py # 中心化协调
│   │   ├── pipeline.py    # 流水线
│   │   ├── decentralized.py # 去中心化
│   │   └── hybrid.py      # 混合
│   ├── decomposer.py      # TaskDecomposer
│   └── capability.py      # register_orchestration_capability
│
├── definition.py           # AgentDefinition
├── runtime.py              # AgentRuntime
│
├── builtin_agents/         # 内置 Agent 定义（升级）
│   ├── __init__.py
│   ├── base.py            # BuiltinAgent → AgentDefinition
│   ├── registry.py        # BuiltinAgentRegistry
│   ├── explore_agent.py
│   ├── plan_agent.py
│   ├── verification_agent.py
│   └── general_purpose_agent.py
│
└── tools/                  # 工具系统（保持现有）
    ├── __init__.py
    ├── base.py
    └── ...
```

---

## 7. 迁移路径

### 7.1 组件映射

| 现有组件 | 迁移目标 | 说明 |
|----------|----------|------|
| `MemoryDirectory` | `BuiltinMemoryProvider` | 升级为 MemoryProvider 实现 |
| `MemoryPaths` | `MemoryPath` | 整合到 scope.py |
| `ContextManager` | `SummarizeEngine` | 升级为 ContextEngine |
| `ContextCompactor` | `SummarizeEngine` | 整合压缩逻辑 |
| `CoordinatorMode` | `CentralizedEngine` | 升级为 OrchestrationEngine |
| `SubagentManager` | `AgentRuntime` 管理 | 整合到运行时 |
| `BuiltinAgent` | `AgentDefinition` | 统一定义格式 |
| `BuiltinAgentRegistry` | `AgentCapabilityRegistry` | 扩展为能力注册 |

### 7.2 迁移步骤

**阶段 1: 框架骨架**

1. 创建 `capabilities/` 目录和 `AgentCapabilityRegistry`
2. 定义 `AgentDefinition` 统一格式
3. 定义各能力的抽象基类（ABC）

**阶段 2: Memory/Context**

1. 将 `MemoryDirectory` 重构为 `BuiltinMemoryProvider`
2. 实现 `SummarizeEngine`（基于现有 `ContextCompactor`）
3. 实现能力注册函数

**阶段 3: 协作模式**

1. 将 `CoordinatorMode` 升级为 `CentralizedEngine`
2. 实现 `PipelineEngine` 和 `HybridEngine`
3. 实现 `TaskDecomposer`
4. 整合 `AgentRuntime`

---

## 8. 扩展点

### 8.1 自定义 Memory Provider

```python
from pyclaw.agents.memory.provider import MemoryProvider
from pyclaw.agents.memory.capability import register_memory_capability

class MyCustomProvider(MemoryProvider):
    name = "my_custom"
    
    async def add(self, content: str, metadata: dict = None) -> str:
        # 自定义实现
        ...
        
    async def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        # 自定义实现
        ...

# 注册
register_memory_capability(
    plugin_id="my_plugin",
    provider=MyCustomProvider(storage_path=Path("./my_memory")),
    scope=MemoryScope.PROJECT,
)
```

### 8.2 自定义 Context Engine

```python
from pyclaw.agents.context.engine import ContextEngine
from pyclaw.agents.context.capability import register_context_capability

class MyContextEngine(ContextEngine):
    name = "my_engine"
    
    def compress(self, messages, focus_topic=None):
        # 自定义压缩逻辑
        ...

# 注册
register_context_capability(
    plugin_id="my_plugin",
    engine=MyContextEngine(),
    policy=ContextPolicy(compression_strategy="my_engine"),
)
```

### 8.3 自定义协作引擎

```python
from pyclaw.agents.orchestration.engine import OrchestrationEngine
from pyclaw.agents.orchestration.capability import register_orchestration_capability

class MyOrchestrationEngine(OrchestrationEngine):
    mode = OrchestrationMode.HYBRID
    
    async def execute(self, goal, config, context):
        # 自定义协作逻辑
        ...

# 注册
register_orchestration_capability(
    plugin_id="my_plugin",
    engine=MyOrchestrationEngine(),
)
```

---

## 9. 配置示例

### 9.1 Agent 定义配置

```yaml
# .pyclaw/agents/my-agent.yaml

agent_type: my_custom_agent
display_name: "My Custom Agent"
description: "A custom agent for specific tasks"

trust_level: trusted

memory:
  enabled: true
  scope: project
  backend: lancedb

context:
  compression_strategy: summarize
  threshold_percent: 0.75
  cache_strategy: system

orchestration:
  mode: centralized
  max_parallel: 4

tools:
  enabled:
    - read_file
    - write_file
    - execute_command
  disabled:
    - delete_file
```

### 9.2 全局能力配置

```yaml
# .pyclaw/config.yaml

capabilities:
  memory:
    default_backend: builtin
    providers:
      - name: lancedb
        module: pyclaw.agents.memory.providers.lancedb
        config:
          embedding_model: text-embedding-3-small
          
  context:
    default_engine: summarize
    engines:
      - name: summarize
        module: pyclaw.agents.context.engines.summarize
        config:
          summary_model: claude-3-haiku
          
  orchestration:
    default_mode: centralized
```

---

## 10. 后续工作

### 10.1 P0 - 核心抽象层

- [ ] 实现 `AgentCapabilityRegistry` + `AgentDefinition`
- [ ] 确保现有 `MemoryDirectory` 和 `ContextManager` 能通过适配器接入
- [ ] 编写集成测试验证现有功能不受影响

### 10.2 P1 - Memory 系统重构

- [ ] 实现 `BuiltinMemoryProvider` 替换旧 `MemoryDirectory`
- [ ] 实现 `MemoryScope` 路径解析逻辑
- [ ] 实现 `EmbeddingProvider` 抽象

### 10.3 P1 - Context 引擎实现

- [ ] 基于现有 `ContextCompactor` 实现 `SummarizeEngine`
- [ ] 在 `AgentRuntime` 中集成 token 预算管理
- [ ] 实现 `MessageContext` 增强结构

### 10.4 P2 - 协作引擎

- [ ] 实现 `CentralizedEngine`，支持基本子 Agent 生成与结果聚合
- [ ] 暂不实现复杂 DAG 调度，先用线性依赖
- [ ] 实现 `RuleBasedDecomposer`

### 10.5 P3 - 向量后端与高级协作模式

- [ ] 实现 `LanceDBMemoryProvider` / `QdrantMemoryProvider`
- [ ] 实现 `PipelineEngine` / `HybridEngine`
- [ ] 实现 `LLMTaskDecomposer`
- [ ] 实现 `DagEngine`（LCM 风格）
- [ ] 实现 `DecentralizedEngine`
- [ ] 知识库集成

---

## 附录

### A. 风险评估与缓解措施

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| **状态管理混乱**（单例 vs 实例级） | 高 | 明确生命周期归属：`AgentRuntime` 创建并持有实例，注册表仅作为工厂。 |
| **迁移破坏现有功能** | 中 | 保持旧接口兼容层，使用 `@deprecated` 标记逐步移除。增加集成测试验证。 |
| **向量存储依赖外部服务** | 中 | `BuiltinMemoryProvider` 作为 fallback，支持配置降级。 |
| **任务分解的 LLM 成本与质量** | 中 | 提供可配置分解策略（规则/LLM），允许自定义分解提示词模板。 |
| **并发安全问题** | 中 | 注册表使用 `RLock`，AgentRuntime 保证会话级互斥。 |
| **文档中提到的组件（如 DagEngine）未实现** | 低 | 标记为未来迭代内容，初期版本不承诺。 |

### B. 类型定义补充

```python
# src/pyclaw/agents/types.py

from typing import TypedDict

class Message(TypedDict, total=False):
    """API 消息结构"""
    role: str
    content: str
    tool_calls: list['ToolCall']
    tool_call_id: str
    
class ToolCall(TypedDict, total=False):
    """工具调用"""
    id: str
    type: str  # "function"
    function: 'FunctionCall'
    
class FunctionCall(TypedDict):
    """函数调用"""
    name: str
    arguments: str  # JSON string

class Usage(TypedDict, total=False):
    """Token 使用量"""
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
```

### C. 兼容层设计

```python
# src/pyclaw/agents/compat.py

import warnings
from functools import wraps

def deprecated(reason: str, replacement: str = None):
    """标记废弃的函数/类"""
    def decorator(obj):
        @wraps(obj)
        def wrapper(*args, **kwargs):
            msg = f"{obj.__name__} is deprecated: {reason}"
            if replacement:
                msg += f". Use {replacement} instead."
            warnings.warn(msg, DeprecationWarning, stacklevel=2)
            return obj(*args, **kwargs)
        return wrapper
    return decorator


# 示例：旧接口兼容层
@deprecated("Use BuiltinMemoryProvider instead", "BuiltinMemoryProvider")
class MemoryDirectory:
    """兼容层：代理到 BuiltinMemoryProvider"""
    
    def __init__(self, *args, **kwargs):
        from pyclaw.agents.memory.providers.builtin import BuiltinMemoryProvider
        self._impl = BuiltinMemoryProvider(*args, **kwargs)
        
    def __getattr__(self, name):
        return getattr(self._impl, name)
```

### D. 参考项目

- **hermes-agent**: MemoryProvider, ContextEngine, ContextCompressor
- **openclaw**: MemoryPluginCapability, MemoryFlush, registerMemoryCapability
- **claude-code**: AgentDefinition, AgentMemory, builtInAgents

### E. 相关文档

- `docs/architecture.md` - 系统架构
- `docs/plans/openclaw-features-analysis.md` - 上游功能分析
- `MEMORY.md` - 项目记忆
