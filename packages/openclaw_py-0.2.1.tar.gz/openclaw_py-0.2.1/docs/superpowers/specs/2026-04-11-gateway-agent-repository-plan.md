# GatewayAgentRepository 实施计划

> 基于设计文档 `2026-04-11-gateway-agent-repository-design.md` 的详细实施步骤
>
> **版本**: v1.1 (根据审核意见修订)

---

## 审核修订要点

1. **fallback 逻辑**：app.py 根据连接状态选择 Repository
2. **重试机制优化**：仅针对可恢复错误，超时调整为 5 秒
3. **异常处理**：检查 Controller 是否能处理自定义异常
4. **测试补充**：增加边界情况测试用例

---

## 任务清单

### Task 1: 创建 GatewayAgentRepository

**文件**: `src/pyclaw/ui/panels/agents/gateway_repository.py`

**实现内容**:
- [ ] 创建文件并添加模块文档字符串
- [ ] 定义自定义异常类 `GatewayNotConnectedError`, `GatewayCallError`
- [ ] 实现重试配置常量（调整为更快响应）:
  ```python
  _MAX_RETRIES = 2        # 最多 2 次重试
  _RETRY_DELAY = 0.3      # 初始延迟 0.3 秒
  _RETRY_BACKOFF = 2.0    # 指数退避因子
  _DEFAULT_TIMEOUT = 5.0  # 单次调用超时 5 秒（原 10 秒）
  ```
- [ ] 实现 `GatewayAgentRepository` 类
  - [ ] `__init__` 方法
  - [ ] `connected` 属性（保留，仅作快速预检）
  - [ ] `_call_with_retry` 私有方法
    - **仅重试可恢复错误**：超时、连接错误、网络错误
    - **不重试业务错误**：参数错误、权限错误等
    - 返回类型注解: `dict[str, Any]`
  - [ ] `list_agents` 方法
  - [ ] `get_agent` 方法
  - [ ] `get_agent_tools` 方法
  - [ ] `create_agent` 方法（从 Gateway 返回解析）
  - [ ] `delete_agent` 方法
  - [ ] `_parse_agent` 私有方法（防御性解析，处理缺失字段）

**可恢复错误判断**（实现参考）:
```python
_RETRIABLE_ERRORS = (TimeoutError, ConnectionError, OSError)

def _is_retriable(self, error: Exception) -> bool:
    # 超时、连接错误可重试
    if isinstance(error, _RETRIABLE_ERRORS):
        return True
    # Gateway 特定错误码
    if hasattr(error, 'code') and error.code in ('timeout', 'network', 'unavailable'):
        return True
    return False
```

**验收标准**:
- 通过 `ruff check` 和 `mypy` 类型检查
- 所有方法有类型注解和文档字符串
- 重试机制仅针对可恢复错误工作

**依赖**: 无

---

### Task 2: 更新 __init__.py 导出

**文件**: `src/pyclaw/ui/panels/agents/__init__.py`

**实现内容**:
- [ ] 导入 `GatewayAgentRepository`, `GatewayNotConnectedError`, `GatewayCallError`
- [ ] 更新 `__all__` 列表
- [ ] 更新 `build_agents_panel()` 函数
  - 添加 `prefer_gateway: bool = False` 参数（默认 False 保持向后兼容）
  - 实现 Repository 选择逻辑

**Repository 选择逻辑**:
```python
def build_agents_panel(
    *,
    agents_dir: str | Path | None = None,
    gateway_client: Any = None,
    event_bus: EventBus | None = None,
    prefer_gateway: bool = False,  # 默认 False，保持向后兼容
    **kwargs,
) -> Any:
    from pyclaw.config.paths import resolve_agents_dir

    # 选择 Repository：优先 Gateway，fallback 到本地
    use_gateway = (
        prefer_gateway
        and gateway_client is not None
        and getattr(gateway_client, "connected", False)
    )

    if use_gateway:
        from pyclaw.ui.panels.agents.gateway_repository import GatewayAgentRepository
        repo = GatewayAgentRepository(gateway_client)
        logger.debug("Using GatewayAgentRepository")
    else:
        effective_dir = Path(agents_dir) if agents_dir else resolve_agents_dir()
        repo = LocalAgentRepository(effective_dir)
        logger.debug("Using LocalAgentRepository (fallback)")

    controller = AgentsController(repo, event_bus)
    return AgentsView(controller)
```

**循环导入检查**: 确保导入链无循环依赖

**验收标准**:
- `from pyclaw.ui.panels.agents import GatewayAgentRepository` 可正常导入
- `build_agents_panel()` 默认行为不变（使用 LocalRepository）
- `build_agents_panel(prefer_gateway=True)` 正确选择 Repository

**依赖**: Task 1

---

### Task 3: 修改 app.py 初始化

**文件**: `src/pyclaw/ui/app.py`

**实现内容**:
- [ ] 修改导入语句
- [ ] 实现 fallback 逻辑（根据 Gateway 连接状态选择 Repository）
- [ ] 检查 `AgentsController` 异常处理能力

**代码变更（带 fallback）**:
```python
# 修改前 (约 line 179-182)
from pyclaw.ui.panels.agents import AgentsController, AgentsView, LocalAgentRepository

agents_repo = LocalAgentRepository(resolve_agents_dir())
agents_ctrl = AgentsController(agents_repo, self._event_bus)

# 修改后（带 fallback 逻辑）
from pyclaw.ui.panels.agents import AgentsController, AgentsView
from pyclaw.ui.panels.agents.gateway_repository import GatewayAgentRepository
from pyclaw.ui.panels.agents.local_repository import LocalAgentRepository

# 根据 Gateway 连接状态选择 Repository
if self._gw and getattr(self._gw, "connected", False):
    agents_repo: AgentRepository = GatewayAgentRepository(self._gw)
    logger.debug("Agents panel using GatewayAgentRepository")
else:
    agents_repo = LocalAgentRepository(resolve_agents_dir())
    logger.debug("Agents panel using LocalAgentRepository (Gateway not connected)")

agents_ctrl = AgentsController(agents_repo, self._event_bus)
```

**Controller 异常处理检查**:
- 查看 `AgentsController` 是否捕获异常并更新 `state.error`
- 若未处理，需在 View 层显示用户友好提示（非阻塞，可在后续优化）

**验收标准**:
- Gateway 已连接时使用 `GatewayAgentRepository`
- Gateway 未连接时 fallback 到 `LocalAgentRepository`
- UI 启动后 Agent 列表能正常显示

**依赖**: Task 1, Task 2

---

### Task 4: 编写单元测试

**文件**: `tests/pyclaw/ui/panels/agents/test_gateway_repository.py`

**测试用例**:
- [ ] `test_list_agents_success` - 正常获取列表
- [ ] `test_list_agents_not_connected` - 未连接抛出 `GatewayNotConnectedError`
- [ ] `test_list_agents_retry_success` - 第一次失败，重试成功
- [ ] `test_list_agents_retry_failed` - 重试后仍失败抛出 `GatewayCallError`
- [ ] `test_retry_only_retriable_errors` - 业务错误不触发重试
- [ ] `test_create_agent_parses_result` - 从 Gateway 返回解析
- [ ] `test_create_agent_gateway_returns_incomplete_data` - 缺失字段时安全处理
- [ ] `test_get_agent_tools_camel_case` - 参数名 `agentId` 正确
- [ ] `test_get_agent_tools_empty_response` - 空 tools 列表或缺失字段处理
- [ ] `test_delete_agent_snake_case` - 参数名 `agent_id` 正确
- [ ] `test_parse_agent_missing_fields` - `_parse_agent` 防御性解析

**Mock 设置**:
```python
@pytest.fixture
def mock_gateway():
    """创建 Mock Gateway 客户端"""
    gateway = Mock()
    gateway.connected = True
    return gateway

@pytest.fixture
def mock_disconnected_gateway():
    """创建未连接的 Mock Gateway"""
    gateway = Mock()
    gateway.connected = False
    return gateway
```

**验收标准**:
- 覆盖率 > 80%
- `_call_with_retry` 覆盖率 100%
- `pytest tests/pyclaw/ui/panels/agents/` 全部通过

**依赖**: Task 1

---

### Task 5: 集成测试

**测试内容**:
- [ ] 启动 Gateway 服务
- [ ] 启动 UI 应用
- [ ] 验证 Agent 列表显示（从 Gateway 加载）
- [ ] 点击刷新按钮验证 Gateway 调用
- [ ] 创建新 Agent 验证
- [ ] 删除 Agent 验证
- [ ] **网络中断场景**：断开 Gateway，验证 UI 有提示或 fallback
- [ ] **创建/删除后刷新**：验证数据一致性

**验收标准**:
- 所有操作正常执行
- 无异常日志
- 网络中断时 UI 有适当响应（不崩溃）

**依赖**: Task 1, Task 2, Task 3

---

## 文件变更摘要

| 文件 | 操作 | 变更行数估计 |
|------|------|-------------|
| `src/pyclaw/ui/panels/agents/gateway_repository.py` | 新建 | ~150 行 |
| `src/pyclaw/ui/panels/agents/__init__.py` | 修改 | ~30 行 |
| `src/pyclaw/ui/app.py` | 修改 | ~5 行 |
| `tests/pyclaw/ui/panels/agents/test_gateway_repository.py` | 新建 | ~100 行 |

---

## 执行顺序

```
Task 1 (创建 Repository) ──┬── Task 2 (更新导出) ── Task 3 (修改 app.py) ──┐
                           │                                                │
                           └── Task 4 (单元测试) ────────────────────────────┴── Task 5 (集成测试)
```

**建议并行**: Task 1 完成后，Task 2 和 Task 4 可并行执行

---

## 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| Gateway 连接不稳定 | API 调用失败 | 已实现重试机制 + fallback 到 LocalAgentRepository |
| 参数名不一致 | API 调用报错 | 已在设计文档明确 `agent_id` vs `agentId` 差异 |
| 类型检查失败 | CI 不通过 | 使用 `Any` 类型处理动态 Gateway 响应 |
| 重试导致 UI 卡顿 | 用户体验差 | 超时调整为 5 秒，总耗时最多约 15 秒 |
| 并发重复请求 | 资源浪费 | 后续优化：添加 TTL 缓存 |
| Controller 异常未处理 | UI 崩溃 | 检查 Controller 异常处理，View 层显示错误提示 |

---

## 回滚方案

若 Gateway 调用出现问题，可通过以下方式回滚：

### 方式 1：代码回滚（快速）
```python
# app.py 中直接替换
agents_repo = LocalAgentRepository(resolve_agents_dir())
```

### 方式 2：配置开关（推荐）
```python
# 通过环境变量或配置控制
USE_GATEWAY_REPO = os.environ.get("PYCLAW_USE_GATEWAY_REPO", "true").lower() == "true"

if USE_GATEWAY_REPO and self._gw and self._gw.connected:
    agents_repo = GatewayAgentRepository(self._gw)
else:
    agents_repo = LocalAgentRepository(resolve_agents_dir())
```

### 方式 3：build_agents_panel 参数
```python
# 强制使用本地 Repository
build_agents_panel(prefer_gateway=False, gateway_client=None)
```
