# 多智能体协作系统设计规格

> **日期**：2026-04-12
> **状态**：✅ 已实现 (2026-04-13)
> **适用范围**：PyClaw Agent Runtime

---

## 1. 概述

### 1.1 目标

设计灵活的多智能体协作系统，支持以下协作模式：

| 模式 | 描述 |
|------|------|
| **Custom Agent** | 用户预定义 Agent（YAML/Markdown/UI），按需调用 |
| **Dynamic Decompose** | 主 Agent 动态分析任务，自动分解并调度子 Agent |
| **Fork/Swarm** | 主 Agent 创建多个并行子 Agent 执行同类任务 |
| **Coordinator-Worker** | 主 Agent 作为指挥官，Worker 执行具体任务 |

### 1.2 核心决策

| 决策点 | 选择 | 理由 |
|--------|------|------|
| 架构方案 | 统一协作层 | 改动最小，模式可组合，易于测试 |
| 模式切换 | C + D | 显式调用 + 组合使用，引入 suggest_mode 智能建议 |
| Custom Agent 来源 | A + C + D | YAML + Markdown + UI，覆盖不同用户场景 |
| 上下文策略 | B + C + 受限 D | 只读继承 + Scratchpad + 作用域记忆共享 |
| 工具权限 | A + C + D | 白名单继承 + 动态授权 + 分级信任 |

---

## 2. 架构设计

### 2.1 整体架构

```
┌─────────────────────────────────────────────────────────┐
│                  CollaborationEngine                     │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌──────────────┐  │
│  │ Custom  │ │ Dynamic │ │  Fork   │ │ Coordinator  │  │
│  │ Agent   │ │Decompose│ │ Swarm   │ │    Worker    │  │
│  └────┬────┘ └────┬────┘ └────┬────┘ └──────┬───────┘  │
│       └───────────┴──────────┴──────────────┘          │
│                         ↓                                │
│               ModeSelector (suggest_mode)               │
│                         ↓                                │
│              ContextSharingManager                       │
│                         ↓                                │
│              ToolPermissionManager                       │
│                         ↓                                │
│                  SubagentManager (现有)                  │
└─────────────────────────────────────────────────────────┘
```

### 2.2 模块结构

```
src/pyclaw/agents/collaboration/
├── __init__.py                    # 模块入口，导出核心类
├── types.py                       # 核心类型定义
├── engine.py                      # CollaborationEngine - 协作引擎核心
├── selector.py                    # ModeSelector - 模式选择与智能建议
├── tools.py                       # 协作工具集
├── decomposer.py                  # TaskDecomposer - 任务分解器
├── modes/
│   ├── __init__.py
│   ├── base.py                    # CollaborationMode 抽象基类
│   ├── custom_agent.py            # Custom Agent 模式实现
│   ├── dynamic_decompose.py       # 动态分解模式实现
│   ├── fork_swarm.py              # Fork/Swarm 模式实现
│   └── coordinator_worker.py      # Coordinator-Worker 模式实现
├── context/
│   ├── __init__.py
│   ├── sharing.py                 # ContextSharingManager - 上下文共享
│   └── scratchpad.py              # Scratchpad 管理
├── permission/
│   ├── __init__.py
│   └── tool_manager.py            # ToolPermissionManager - 工具权限
└── storage/
    ├── __init__.py
    ├── agent_registry.py          # CustomAgentRegistry
    └── session_state.py           # 协作会话状态持久化
```

---

## 3. 核心数据模型

### 3.1 协作模式枚举

```python
class CollaborationModeType(str, Enum):
    """协作模式类型"""
    CUSTOM_AGENT = "custom_agent"
    DYNAMIC_DECOMPOSE = "dynamic_decompose"
    FORK_SWARM = "fork_swarm"
    COORDINATOR_WORKER = "coordinator_worker"

class TrustLevel(int, Enum):
    """信任等级"""
    FULL = 100       # 完全信任
    STANDARD = 75    # 标准信任
    RESTRICTED = 50  # 受限信任
    SANDBOX = 25     # 沙箱模式

class ModeSwitchTrigger(str, Enum):
    """模式切换触发方式"""
    EXPLICIT = "explicit"      # 用户显式调用
    SUGGESTED = "suggested"    # 系统建议，用户确认
    AUTO = "auto"              # 自动切换
```

### 3.2 Custom Agent 配置

```python
# 当前支持的 Schema 版本
SUPPORTED_SCHEMA_VERSIONS = ["1.0"]

class CustomAgentConfig(BaseModel):
    """Custom Agent 配置定义"""
    
    # 版本管理（可选，默认 "1.0"）
    schema_version: str = Field(
        default="1.0",
        description="配置 Schema 版本，用于兼容性检查",
    )
    
    agent_id: str
    name: str
    description: str = ""
    
    # 核心配置
    system_prompt: str | None = None
    model: str | None = None
    
    # 工具权限
    tools_enabled: list[str] | None = None
    tools_disabled: list[str] | None = None
    trust_level: TrustLevel = TrustLevel.STANDARD
    
    # 记忆作用域
    memory_scope: MemoryScope = MemoryScope.TASK
    
    # 元数据
    tags: list[str] = Field(default_factory=list)
    source: str = "yaml"  # yaml/markdown/ui
    source_path: str | None = None
```

**版本管理规则：**

| 规则 | 说明 |
|------|------|
| 默认版本 | `schema_version` 可选，默认 `"1.0"` |
| 兼容性检查 | Registry 加载时检查版本，不兼容则抛出 `IncompatibleSchemaError` |
| 错误处理 | 检测到不兼容版本时阻止注册，汇总报告所有加载失败 |
| 迁移钩子 | 预留 `_migrate(data, from_version, to_version)` 用于未来升级 |

### 3.3 协作会话状态

```python
class CollaborationSession(BaseModel):
    """协作会话状态"""
    session_id: str
    parent_session_id: str | None = None
    memory_session_id: str | None = None  # 关联 Memory SESSION
    
    active_mode: CollaborationModeType | None = None
    mode_history: list[dict[str, Any]] = Field(default_factory=list)
    
    child_agents: list[str] = Field(default_factory=list)
    max_children: int = 4
    
    scratchpad_dir: str | None = None
    status: str = "active"
```

---

## 4. 核心组件设计

### 4.1 CollaborationEngine

```python
class CollaborationEngine:
    """协作引擎 - 统一管理所有协作模式"""
    
    def __init__(
        self,
        subagent_manager: SubagentManager,
        mode_selector: ModeSelector | None = None,
        context_manager: ContextSharingManager | None = None,
        permission_manager: ToolPermissionManager | None = None,
    ) -> None: ...
    
    # 模式切换
    def switch_mode(self, mode: CollaborationModeType, 
                    trigger: ModeSwitchTrigger) -> ModeSwitchResult: ...
    def suggest_mode(self, task_description: str) -> list[ModeSuggestion]: ...
    
    # 子 Agent 生命周期
    async def spawn_child(self, config, mode_type) -> SpawnResult: ...
    async def kill_child(self, session_id: str) -> bool: ...
    async def steer_child(self, session_id: str, instruction: str) -> bool: ...
    
    # 状态查询
    def get_active_children(self) -> list[CollaborationSession]: ...
    def get_session_state(self, session_id: str) -> CollaborationSession | None: ...
```

### 4.2 CollaborationMode 基类

```python
class CollaborationMode(ABC):
    """协作模式抽象基类"""
    
    mode_type: CollaborationModeType
    
    @abstractmethod
    async def spawn(self, config) -> SpawnResult: ...
    
    @abstractmethod
    def get_tools_for_child(self, config, trust_level) -> list[AgentTool]: ...
    
    @abstractmethod
    def prepare_context(self, parent_session_id, child_config) -> ChildContext: ...
    
    def on_child_complete(self, result: SubagentResult) -> None: ...
```

### 4.3 ModeSelector

```python
class ModeSelector:
    """模式选择器 - 智能建议协作模式"""
    
    def suggest(self, task_description: str) -> list[ModeSuggestion]:
        """分析任务描述，返回模式建议列表"""
        ...
    
    def select_best(self, task_description: str) -> ModeSuggestion: ...
```

**检测规则：**

| 规则 | 触发条件 | 推荐模式 | 置信度 |
|------|----------|----------|--------|
| RulePredefinedAgent | "用 research agent" | CUSTOM_AGENT | 0.95 |
| RuleParallelIndicator | "并行"、"同时"、"fork" | FORK_SWARM | 0.85 |
| RuleDecompositionHint | "分解"、"拆分"、"步骤" | DYNAMIC_DECOMPOSE | 0.80 |
| RuleComplexityIndicator | 高复杂度关键词 ≥ 2 | COORDINATOR_WORKER | 0.75 |
| RuleDefault | 无匹配 | CUSTOM_AGENT | 0.30 |

### 4.4 TaskDecomposer

```python
class TaskDecomposer:
    """任务分解器"""
    
    def __init__(
        self,
        strategy: DecompositionStrategy = DecompositionStrategy.HEURISTIC,
        llm_client: Any = None,
    ) -> None: ...
    
    async def decompose(
        self,
        task: str,
        context: dict | None = None,
    ) -> list[SubtaskDefinition]: ...
```

**分解策略：**
- `HEURISTIC`：基于规则的模式识别（research_and_report、implement_and_test）
- `LLM`：LLM 驱动的智能分解
- `HYBRID`：启发式优先，失败时回退 LLM

### 4.5 ToolPermissionManager

```python
class ToolPermissionManager:
    """工具权限管理器"""
    
    SENSITIVE_TOOLS = {
        "exec": {"risk": "high", ...},
        "shell": {"risk": "high", ...},
        "file_write": {"risk": "medium", ...},
        ...
    }
    
    def filter_tools(self, tools, config) -> list[AgentTool]: ...
    def requires_authorization(self, tool_name: str) -> bool: ...
    async def request_authorization(self, session_id, tool_name, arguments) -> AuthorizationResponse: ...
```

**分级信任策略：**

| 信任等级 | 工具访问 |
|----------|----------|
| FULL | 所有工具，无需授权 |
| STANDARD | 所有工具，敏感操作需授权 |
| RESTRICTED | 移除高风险工具 |
| SANDBOX | 仅只读工具（read, search, web_fetch） |

### 4.6 ContextSharingManager

```python
class ContextSharingManager:
    """上下文共享管理器"""
    
    # B 策略：上下文继承（只读）
    def get_parent_history(self, parent_session_id, mode) -> list[dict]: ...
    
    # C 策略：共享工作区
    def create_scratchpad(self, parent_session_id, scope) -> ScratchpadConfig: ...
    def cleanup_scratchpad(self, scratchpad_id) -> bool: ...
    
    # 受限 D 策略：记忆系统共享
    def get_memory_access(self, session_id, scope) -> MemoryAccessor: ...
```

**历史获取模式：**
- `full`：完整历史
- `summary`：摘要版本（压缩）
- `recent`：最近 N 条消息

**MemoryScope 到 MemoryManager 作用域映射：**

| MemoryScope | MemoryManager Scope | 访问权限 |
|-------------|---------------------|----------|
| `TASK` | `SESSION`（新实例） | 继承父会话摘要，读写独立 |
| `PROJECT` | `PROJECT` | 根据信任等级控制读写 |

**约束：**
- 子 Agent **禁止**访问父 Agent 的 `SESSION` 记忆原始数据，仅通过摘要共享
- `TASK` → `SESSION` 时，`MemoryAccessor` 返回新 SESSION 实例，初始化时注入父会话摘要
- `PROJECT` → `PROJECT` 时，`RESTRICTED` 及以上信任等级允许读取，`STANDARD` 及以上允许写入

---

## 5. Custom Agent 注册表

### 5.1 支持的来源

| 来源 | 格式 | 目录 |
|------|------|------|
| YAML | `.yaml` 文件 | `~/.pyclaw/agents/` |
| Markdown | `.md` 文件 + frontmatter | `.claude/agents/` |
| UI | 通过表单创建 | `~/.pyclaw/agents/ui_created/` |

### 5.2 YAML 配置示例

```yaml
# ~/.pyclaw/agents/researcher.yaml
agent_id: researcher
name: Research Agent
description: 专注信息收集和整理的研究 Agent

system_prompt: |
  You are a research agent specialized in gathering information.
  Focus on accuracy and cite your sources.

tools_enabled: [read, search, web_search, web_fetch]
tools_disabled: [exec, shell, file_write, patch]
trust_level: 50  # RESTRICTED
memory_scope: task
tags: [research, information]
```

### 5.3 Markdown 配置示例

```markdown
<!-- .claude/agents/planner.md -->
---
name: Planner
tools: [read, search, plan]
trust_level: 75
memory_scope: project
tags: [planning, architecture]
---

You are a planning agent specialized in breaking down complex tasks.

Your responsibilities:
1. Analyze the task requirements
2. Identify dependencies and constraints
3. Create a clear implementation plan
```

---

## 6. 协作工具集

| 工具 | 功能 | 参数 |
|------|------|------|
| `spawn_child` | 创建子 Agent | agent_id, prompt, mode, fork_count, system_prompt |
| `mode_switch` | 切换协作模式 | mode, reason |
| `suggest_mode` | 请求模式建议 | task_description |
| `steer_child` | 向子 Agent 发送指令 | session_id, instruction |
| `kill_child` | 终止子 Agent | session_id |
| `list_children` | 列出子 Agent | include_completed |

---

## 7. 与现有系统集成

### 7.1 run_agent 集成

```python
async def run_agent(
    prompt: str,
    session: SessionManager,
    model: ModelConfig,
    tools: list[AgentTool] | None = None,
    system_prompt: str | None = None,
    # 新增参数
    collaboration_engine: CollaborationEngine | None = None,
    collaboration_mode: CollaborationModeType | None = None,
) -> AsyncGenerator[AgentEvent, None]:
    """Agent 主循环 - 支持协作模式"""
    
    if collaboration_engine:
        tools = tools or []
        tools.extend([
            SpawnChildTool(engine=collaboration_engine),
            SteerChildTool(engine=collaboration_engine),
            KillChildTool(engine=collaboration_engine),
            ListChildrenTool(engine=collaboration_engine),
            SuggestModeTool(engine=collaboration_engine),
            ModeSwitchTool(engine=collaboration_engine),
        ])
    
    # Coordinator-Worker 模式过滤工具
    if collaboration_mode == CollaborationModeType.COORDINATOR_WORKER:
        tools = mode_impl.get_coordinator_tools()
    
    # 原有循环...
```

### 7.2 CLI 命令

```bash
# 列出已注册的 Agent
pyclaw agents

# 切换协作模式
pyclaw mode coordinator_worker

# 请求模式建议
pyclaw mode --suggest "同时处理多个文件"
```

---

## 8. 实现优先级

| 阶段 | 内容 | 依赖 |
|------|------|------|
| P0 | types.py, engine.py 骨架 | 无 |
| P1 | storage/agent_registry.py | types.py |
| P1 | permission/tool_manager.py | types.py |
| P1 | context/sharing.py | types.py |
| P2 | modes/*.py | engine.py, permission/, context/ |
| P2 | selector.py | types.py |
| P2 | decomposer.py | types.py |
| P3 | tools.py | engine.py |
| P3 | runner.py 集成 | 全部 |
| P3 | CLI 命令 | 全部 |

---

## 9. 测试策略

| 测试类型 | 覆盖范围 |
|----------|----------|
| 单元测试 | 各组件核心逻辑（模式切换、工具过滤、上下文准备） |
| 集成测试 | Engine 与 SubagentManager 协作 |
| 端到端测试 | 完整协作流程（创建 Agent → 执行 → 收集结果） |
| 契约测试 | Custom Agent 配置 Schema 版本化 |

---

## 10. 待实现细节

- `SubagentConfig` 需增加 `fork_count`、`mode` 字段
- Memory 系统需支持 `summarize` 方法或使用 ContextEngine
- MemoryAccessor 的 scope 路由需与 MemoryManager 对齐
- 规则配置化（关键词、默认模式移至 YAML）
