# GatewayAgentRepository 设计文档

> 解决 UI 按钮点击无法联动后端的问题，为 Agents 模块添加 Gateway 调用能力。
>
> **版本**: v1.1 (2026-04-11 更新，根据审核意见修订)

---

## 审核修订记录

| 版本 | 日期 | 修订内容 |
|------|------|----------|
| v1.0 | 2026-04-11 | 初始设计 |
| v1.1 | 2026-04-11 | 根据审核意见：改进 create_agent 解析、增加重试机制、细化异常类型、补充 build_agents_panel 逻辑 |

---

## 问题背景

### 当前架构问题

PyClaw UI 存在两套架构并存：
- **旧架构**（函数式）：`build_xxx_panel()` 直接调用 `gateway_client.call()`，功能正常
- **新架构**（MVC）：Controller → Repository 模式，但 Repository 缺少 Gateway 实现

**核心问题**：`AgentsController` 使用 `LocalAgentRepository`，只读取本地文件系统，无法调用 Gateway API。

### 数据流断裂

```
AgentsView → AgentsController → LocalAgentRepository → ❌ 本地文件
```

按钮点击事件无法触发后端 API 调用。

---

## 设计方案

### 方案选择

采用 **方案 A：创建独立的 GatewayAgentRepository**

| 方案 | 优点 | 缺点 |
|------|------|------|
| A. 独立 GatewayAgentRepository | 职责单一、易测试、与现有架构一致 | 需修改初始化代码 |
| B. 扩展 LocalAgentRepository | 改动最小 | 混合职责、类名不准确 |
| C. HybridAgentRepository | 自动 fallback | 代码量最多 |

选择方案 A 的理由：
- 与 `GatewaySessionRepository`、`ChannelsRepository` 模式一致
- 单元测试时容易 mock
- 符合单一职责原则

---

## 实现细节

### 1. 新建文件

```
src/pyclaw/ui/panels/agents/
├── __init__.py              # 导出 GatewayAgentRepository
├── controller.py            # 无需修改
├── state.py                 # 无需修改
├── view.py                  # 无需修改
├── local_repository.py      # 保留
└── gateway_repository.py    # 新建
```

### 2. GatewayAgentRepository 实现

```python
# src/pyclaw/ui/panels/agents/gateway_repository.py

from __future__ import annotations

import asyncio
import logging
from typing import Any

from pyclaw.ui.core.repository import AgentRepository
from pyclaw.ui.core.types import Agent, AgentCreate

logger = logging.getLogger(__name__)

# 重试配置
_MAX_RETRIES = 2
_RETRY_DELAY = 0.5  # 秒
_RETRY_BACKOFF = 2.0  # 指数退避因子


class GatewayNotConnectedError(Exception):
    """Gateway 未连接时抛出。"""
    pass


class GatewayCallError(Exception):
    """Gateway 调用失败时抛出。

    Attributes:
        method: 失败的方法名
        original_error: 原始异常
    """
    def __init__(self, method: str, message: str, original_error: Exception | None = None) -> None:
        super().__init__(f"Gateway call '{method}' failed: {message}")
        self.method = method
        self.original_error = original_error


class GatewayAgentRepository(AgentRepository):
    """Agent repository backed by Gateway API.

    Fetches agent configurations from the gateway with automatic
    connection state checking and retry logic.

    Attributes:
        gateway_client: Gateway client for API calls.
    """

    def __init__(self, gateway_client: Any) -> None:
        """Initialize the repository.

        Args:
            gateway_client: Gateway client for API calls.
        """
        self._gateway = gateway_client

    @property
    def connected(self) -> bool:
        """Check if gateway is connected."""
        return self._gateway is not None and getattr(self._gateway, "connected", False)

    async def _call_with_retry(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        timeout: float = 10.0,
    ) -> dict[str, Any]:
        """带重试的 Gateway 调用。

        Args:
            method: Gateway 方法名
            params: 调用参数
            timeout: 超时时间

        Returns:
            Gateway 响应

        Raises:
            GatewayNotConnectedError: Gateway 未连接
            GatewayCallError: 调用失败（重试后仍失败）
        """
        if not self.connected:
            raise GatewayNotConnectedError("Gateway not connected")

        last_error: Exception | None = None
        delay = _RETRY_DELAY

        for attempt in range(_MAX_RETRIES + 1):
            try:
                return await self._gateway.call(method, params, timeout=timeout)
            except Exception as e:
                last_error = e
                if attempt < _MAX_RETRIES:
                    logger.warning(
                        "Gateway call '%s' failed (attempt %d/%d): %s, retrying in %.1fs",
                        method, attempt + 1, _MAX_RETRIES + 1, e, delay
                    )
                    await asyncio.sleep(delay)
                    delay *= _RETRY_BACKOFF

        raise GatewayCallError(method, str(last_error), last_error)

    async def list_agents(self) -> list[Agent]:
        """List all agents from gateway.

        Returns:
            List of Agent instances.

        Raises:
            GatewayNotConnectedError: If gateway is not connected.
            GatewayCallError: If call fails after retries.
        """
        result = await self._call_with_retry("agents.list")
        return [self._parse_agent(a) for a in result.get("agents", [])]

    async def get_agent(self, agent_id: str) -> Agent | None:
        """Get a specific agent by ID.

        Note: Gateway does not provide agents.get, so we use list_agents.
        Future: If Gateway adds agents.get, replace with direct call.

        Args:
            agent_id: The agent's unique identifier.

        Returns:
            Agent instance if found, None otherwise.
        """
        agents = await self.list_agents()
        for agent in agents:
            if agent.id == agent_id:
                return agent
        return None

    async def get_agent_tools(self, agent_id: str) -> list[str]:
        """Get the list of tools for an agent.

        Args:
            agent_id: The agent's unique identifier.

        Returns:
            List of tool names.

        Raises:
            GatewayNotConnectedError: If gateway is not connected.
            GatewayCallError: If call fails after retries.
        """
        # Note: agents.tools 使用 camelCase 参数名 agentId
        result = await self._call_with_retry(
            "agents.tools",
            {"agentId": agent_id},
        )
        tools = result.get("tools") or result.get("names") or []
        return [t if isinstance(t, str) else t.get("name", str(t)) for t in tools]

    async def create_agent(self, agent_data: AgentCreate) -> Agent:
        """Create a new agent via gateway.

        优先从 Gateway 返回值解析 Agent 信息，若不足则 fallback 到本地构造。

        Args:
            agent_data: Data for the new agent.

        Returns:
            The created Agent instance.

        Raises:
            GatewayNotConnectedError: If gateway is not connected.
            GatewayCallError: If call fails after retries.
        """
        agent_id = agent_data.name.strip().lower().replace(" ", "-")

        # Note: agents.add 使用 snake_case 参数名 agent_id
        result = await self._call_with_retry(
            "agents.add",
            {
                "agent_id": agent_id,
                "config": {
                    "name": agent_data.name,
                    "model": agent_data.model,
                    "provider": agent_data.provider,
                    "systemPrompt": agent_data.system_prompt,
                    "tools": agent_data.tools,
                    "skills": agent_data.skills,
                },
            },
        )

        # 优先从 Gateway 返回值解析
        # Gateway 返回: {agent_id, created, config?}
        if result.get("agent_id"):
            # 尝试获取完整配置（如果 Gateway 返回了）
            config = result.get("config", {})
            return Agent(
                id=result.get("agent_id", agent_id),
                name=config.get("name", agent_data.name),
                path=f"agents/{result.get('agent_id', agent_id)}",
                model=config.get("model", agent_data.model),
                provider=config.get("provider", agent_data.provider),
                system_prompt=config.get("systemPrompt") or config.get("system_prompt", agent_data.system_prompt),
                tools=config.get("tools", agent_data.tools),
                skills=config.get("skills", agent_data.skills),
            )

        # Fallback: 使用本地数据构造
        return Agent(
            id=agent_id,
            name=agent_data.name,
            path=f"agents/{agent_id}",
            model=agent_data.model,
            provider=agent_data.provider,
            system_prompt=agent_data.system_prompt,
            tools=agent_data.tools,
            skills=agent_data.skills,
        )

    async def delete_agent(self, agent_id: str) -> None:
        """Delete an agent via gateway.

        Args:
            agent_id: The agent's unique identifier.

        Raises:
            GatewayNotConnectedError: If gateway is not connected.
            GatewayCallError: If call fails after retries.
        """
        # Note: agents.remove 使用 snake_case 参数名 agent_id
        await self._call_with_retry(
            "agents.remove",
            {"agent_id": agent_id},
        )

    def _parse_agent(self, data: dict[str, Any]) -> Agent:
        """Parse gateway response to Agent model.

        Gateway returns: {id, session_count, config}

        Args:
            data: Dictionary from gateway response.

        Returns:
            Agent instance.
        """
        config = data.get("config", {})
        agent_id = data.get("id", "")
        return Agent(
            id=agent_id,
            name=config.get("name", agent_id),
            path=f"agents/{agent_id}",
            model=config.get("model", ""),
            provider=config.get("provider", ""),
            system_prompt=config.get("systemPrompt") or config.get("system_prompt", ""),
            tools=config.get("tools", []),
            skills=config.get("skills", []),
            channels=config.get("channels", []),
            cron=config.get("cron", []),
        )
```

### 3. 修改 app.py 初始化

```python
# src/pyclaw/ui/app.py

# 原来:
# from pyclaw.ui.panels.agents import AgentsController, AgentsView, LocalAgentRepository
# agents_repo = LocalAgentRepository(resolve_agents_dir())

# 改为:
from pyclaw.ui.panels.agents import AgentsController, AgentsView
from pyclaw.ui.panels.agents.gateway_repository import GatewayAgentRepository

# 使用 Gateway Repository（需要 gateway 已连接）
agents_repo = GatewayAgentRepository(self._gw)
agents_ctrl = AgentsController(agents_repo, self._event_bus)
```

### 4. 更新 build_agents_panel() 支持选择 Repository

```python
# src/pyclaw/ui/panels/agents/__init__.py

def build_agents_panel(
    *,
    agents_dir: str | Path | None = None,
    gateway_client: Any = None,
    event_bus: EventBus | None = None,
    prefer_gateway: bool = True,  # 新增：优先使用 Gateway
    **kwargs,
) -> Any:
    """Build the Agents panel with MVC architecture.

    根据连接状态自动选择 Repository:
    - 若 prefer_gateway=True 且 gateway_client 已连接 → GatewayAgentRepository
    - 否则 → LocalAgentRepository (本地 fallback)

    Args:
        agents_dir: 本地 agents 目录（fallback 时使用）
        gateway_client: Gateway client for remote operations
        event_bus: Event bus for cross-panel communication
        prefer_gateway: 是否优先使用 Gateway（默认 True）
        **kwargs: Additional arguments (ignored for compatibility)

    Returns:
        AgentsView instance ready to be added to the page. (Note: This design predates the TypeScript migration; the Flet UI has been retired.)
    """
    from pyclaw.config.paths import resolve_agents_dir

    # 选择 Repository
    if prefer_gateway and gateway_client and getattr(gateway_client, "connected", False):
        from pyclaw.ui.panels.agents.gateway_repository import GatewayAgentRepository
        repo: AgentRepository = GatewayAgentRepository(gateway_client)
        logger.debug("Using GatewayAgentRepository for agents panel")
    else:
        effective_dir = Path(agents_dir) if agents_dir else resolve_agents_dir()
        repo = LocalAgentRepository(effective_dir)
        logger.debug("Using LocalAgentRepository for agents panel (fallback)")

    controller = AgentsController(repo, event_bus)
    return AgentsView(controller)
```

### 4. 更新 __init__.py 导出

```python
# src/pyclaw/ui/panels/agents/__init__.py

from pyclaw.ui.panels.agents.gateway_repository import (
    GatewayAgentRepository,
    GatewayCallError,
    GatewayNotConnectedError,
)

__all__ = [
    # Repository implementations
    "GatewayAgentRepository",  # Gateway 调用实现（优先）
    "LocalAgentRepository",    # 本地文件实现（fallback）
    # Exceptions
    "GatewayNotConnectedError",
    "GatewayCallError",
    # MVC components
    "AgentsController",
    "AgentsState",
    "AgentsView",
    # Factory function
    "build_agents_panel",
]
```

**使用说明**：
- `GatewayAgentRepository`: Gateway 已连接时使用
- `LocalAgentRepository`: 离线模式或 fallback 时使用
- 通过 `build_agents_panel(prefer_gateway=True)` 自动选择

---

## Gateway 协议参考

| 方法 | 参数 | 返回 | 说明 |
|------|------|------|------|
| `agents.list` | 无 | `{agents: [{id, session_count, config}]}` | 列出所有 Agent |
| `agents.add` | `agent_id`, `config` | `{agent_id, created}` | 创建 Agent |
| `agents.remove` | `agent_id` | `{agent_id, removed}` | 删除 Agent |
| `agents.tools` | `agentId` | `{tools: [...]}` | 获取工具列表 |

**注意参数名差异**：
- `agents.add/remove` 使用 `agent_id`（snake_case）
- `agents.tools` 使用 `agentId`（camelCase）

---

## 数据流对比

| 阶段 | 修改前 | 修改后 |
|------|--------|--------|
| View | AgentsView | AgentsView |
| Controller | AgentsController | AgentsController |
| Repository | LocalAgentRepository | GatewayAgentRepository |
| 数据源 | ❌ 本地文件 | ✓ Gateway API |

---

## 实施顺序

1. **创建 gateway_repository.py** — 实现 `GatewayAgentRepository`（含重试机制和自定义异常）
2. **更新 __init__.py** — 导出新类和异常
3. **修改 app.py** — 注入 `GatewayAgentRepository`
4. **更新 build_agents_panel()** — 支持根据连接状态选择 Repository
5. **编写单元测试** — 验证重试、异常类型、数据转换
6. **集成测试** — 运行完整流程验证 Gateway 调用

---

## 测试要点

### 基础测试

1. **连接状态**：未连接 Gateway 时应抛出 `GatewayNotConnectedError`
2. **数据转换**：Gateway 返回格式与 `Agent` 模型字段映射正确
3. **参数名**：`agent_id` vs `agentId` 的正确使用
4. **错误处理**：Gateway 调用失败时的异常传播

### 进阶测试（审核补充）

5. **重试机制**：模拟网络波动，验证重试逻辑（最多 3 次，指数退避）
6. **并发调用**：多个 UI 组件同时调用 `list_agents` 时是否导致重复请求
7. **缓存失效**：创建/删除 Agent 后，后续 `list_agents` 能否立即看到变化
8. **网络中断恢复**：Gateway 断开后重连，Repository 能否自动恢复
9. **异常类型区分**：验证 `GatewayNotConnectedError` 和 `GatewayCallError` 可被正确捕获

---

## 后续优化

1. ~~添加重试逻辑~~ ✓ 已在 v1.1 实现
2. ~~细化异常类型~~ ✓ 已在 v1.1 实现（`GatewayNotConnectedError`, `GatewayCallError`）
3. 缓存 agent 列表减少重复调用（可考虑 TTL 缓存）
4. 添加 `HybridAgentRepository` 支持 Gateway 优先、本地 fallback
5. 考虑在 `connected` 属性中增加心跳检测实际连通性
