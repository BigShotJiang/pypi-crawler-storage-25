# PACS — PyClaw Agentic Capability Stack 设计文档

> 日期: 2026-04-24
> 状态: Draft
> 参考: [awesome-agentic-patterns](https://github.com/nibzard/awesome-agentic-patterns)

---

## 1. 动机与目标

PyClaw 的 Agent Runtime 已具备基础的 `runner loop`、`orchestration engine`、`collaboration engine`、`context manager`、`memory system` 等模块。但当前架构存在以下瓶颈：

1. **能力耦合**：推理、感知、行动、反馈逻辑混在 `_agent_loop` 中，难以独立开关或替换。
2. **扩展成本高**：新增一种推理模式（如 Reflection Loop）需要深入修改 runner 核心循环。
3. **缺乏组合性**：无法按场景灵活拼装"感知用 A + 推理用 B + 反馈用 C"的能力组合。
4. **缺少错误流**：工具失败、LLM 异常等错误路径没有结构化处理机制。

**PACS 的目标**：构建一个事件驱动、分层插件化、可组合的 Agentic 能力堆栈，让每个能力以 `AgenticCapability` 形式注册，通过事件订阅机制组合，而不修改 runner 核心循环。

**设计原则**：
- 效果优先：每个能力直接提升对应阶段的输出质量
- 插件化组合：每个能力是独立 `AgenticCapability` 类，可按需开关
- 事件驱动：能力通过事件订阅声明自己关心什么，而非硬编码到阶段
- 跨层支持：能力可订阅多个 Hook，实现跨层协作（如 PlanExecute）

---

## 2. 核心架构：事件驱动 + 四层能力栈

### 2.1 四层逻辑分组

能力按 OODA 循环分为四层，仅作逻辑分组和 UI 展示，不影响执行：

```
┌─────────────────────────────────────────────┐
│              AgentRuntime (Session)         │
├─────────────────────────────────────────────┤
│  反馈层 (FEEDBACK)    — Loop 后/Tool 后执行  │
│  - SelfCritique, MemorySynthesis            │
│  - OutputGroundingCheck, TraceQualityMonitor│
│  - AutoImprovementLoop                     │
├─────────────────────────────────────────────┤
│  行动层 (ACTION)       — Turn 内执行         │
│  - ModelRouter, CircuitBreaker, DualLLM    │
│  - ParallelToolExecutor, HumanInTheLoopGate │
│  - ActionValidator, ToolRetryBackoff       │
├─────────────────────────────────────────────┤
│  推理层 (REASONING)    — Turn 内执行         │
│  - ReflectionLoop, PlanExecute, ToT        │
│  - PhaseSeparation, ReActController        │
│  - CoTWithVerification                    │
├─────────────────────────────────────────────┤
│  感知层 (PERCEPTION)   — Turn 前/观察后执行   │
│  - ContextWindowManager, SemanticFilter    │
│  - ToolLazyLoader, ToolOutputParser        │
│  - RelevanceScorer, UserIntentClassifier  │
└─────────────────────────────────────────────┘
```

### 2.2 事件驱动模型

能力不绑死在某一层，而是通过事件订阅声明自己关心什么。层次只是逻辑分组。

**核心流程**：

```
AgentRuntime._agent_loop()
  │
  ├─ emit(SESSION_INIT)
  │
  ├─ while turn < max_turns:
  │   ├─ emit(TURN_START)
  │   ├─ emit(PERCEPTION_PRE)         ← 感知预处理
  │   ├─ emit(LLM_PRE_INVOKE)         ← 模型路由、prompt 注入
  │   ├─ stream_llm(...)
  │   ├─ emit(LLM_POST_RESPONSE)      ← 推理决策、Reflection
  │   │   if tool_calls:
  │   │     for each tool_call:
  │   │       emit(TOOL_PRE_EXECUTE)   ← 参数校验、熔断检查
  │   │       emit(TOOL_EXECUTION)     ← 实际执行（被 CircuitBreaker 包裹）
  │   │       emit(TOOL_POST_EXECUTE)  ← 即时纠错、结果过滤
  │   │       emit(PERCEPTION_OBSERVATION) ← 工具结果感知
  │   │   on error:
  │   │     emit(TOOL_ERROR)           ← 重试、熔断计数
  │   │   on LLM error:
  │   │     emit(LLM_ERROR)            ← 模型回退
  │   ├─ emit(TURN_END)               ← Memory Synthesis、质量评分
  │
  └─ emit(SESSION_END)                ← 综合评估、Auto-Improvement
```

---

## 3. Hook 点清单

### 3.1 完整 Hook 定义

```python
class HookPoint(str, Enum):
    """Agent 生命周期的细粒度 Hook 点。"""

    # Session 生命周期
    SESSION_INIT = "session.init"
    SESSION_END = "session.end"

    # Turn 生命周期
    TURN_START = "turn.start"
    TURN_END = "turn.end"

    # 感知阶段
    PERCEPTION_PRE = "perception.pre"
    PERCEPTION_OBSERVATION = "perception.observation"

    # LLM 调用
    LLM_PRE_INVOKE = "llm.pre_invoke"
    LLM_POST_RESPONSE = "llm.post_response"
    LLM_ERROR = "llm.error"

    # 工具执行
    TOOL_PRE_EXECUTE = "tool.pre_execute"
    TOOL_EXECUTION = "tool.execution"
    TOOL_POST_EXECUTE = "tool.post_execute"
    TOOL_ERROR = "tool.error"
```

### 3.2 各 Hook 的触发时机与可用数据

| Hook | 触发时机 | 事件可用数据 |
|------|----------|-------------|
| `session.init` | 会话创建 | session_id, workspace |
| `session.end` | 会话结束 | session_id, turn_count |
| `turn.start` | 每轮开始 | turn, messages |
| `turn.end` | 每轮结束 | turn, usage, tool_results |
| `perception.pre` | LLM 调用前 | messages（可裁剪） |
| `perception.observation` | 工具结果返回后 | tool_result（可精炼） |
| `llm.pre_invoke` | LLM API 调用前 | messages, model_config |
| `llm.post_response` | LLM 响应后 | llm_response, tool_calls |
| `llm.error` | LLM 调用失败 | error, error_type |
| `tool.pre_execute` | 工具执行前 | tool_call（可修正参数） |
| `tool.execution` | 工具执行中 | tool_call（CircuitBreaker 包裹） |
| `tool.post_execute` | 工具执行后 | tool_result（可修改） |
| `tool.error` | 工具执行失败 | error, error_type, tool_call |

---

## 4. 核心数据结构

### 4.1 HookEvent

```python
@dataclass
class HookEvent:
    """能力系统的事件 payload。"""

    hook: HookPoint
    timestamp: float

    # 可变数据包（能力可修改）
    messages: list[dict] | None = None           # LLM 输入消息
    tool_call: ToolCall | None = None            # 待执行的工具调用
    tool_result: ToolResult | None = None        # 工具返回结果
    llm_response: dict | None = None             # LLM 响应
    context_modifications: dict[str, Any] | None = None

    # 只读元数据
    turn: int = 0
    session_id: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    # 错误流专用
    error: Exception | None = None
    error_type: str | None = None  # "timeout" | "rate_limit" | "execution_error"
```

### 4.2 AgentContext

```python
@dataclass
class AgentContext:
    """会话级共享上下文，能力可读写。"""

    session_id: str
    user_id: str | None = None
    workspace: Path | None = None

    # 任务状态（可变）
    task_complexity: float = 0.0        # 由 MetaCognitionMonitor 写入
    current_phase: str = "perception"   # 当前阶段
    active_plan: dict | None = None     # PlanExecute 写入的计划

    # 记忆槽（可变）
    short_term_memory: dict[str, Any] = field(default_factory=dict)
    working_memory: list[dict] = field(default_factory=list)
    long_term_memory_refs: list[str] = field(default_factory=list)

    # 能力间通信槽（可变）
    capability_state: dict[str, Any] = field(default_factory=dict)

    # 只读配置
    agent_definition: Any | None = None
    model_config: MultiModelConfig | None = None

    def apply_modifications(self, modifications: dict[str, Any]) -> None:
        """从 CapabilityResult.context_modifications 应用修改。

        区分属性写入与状态字典写入：
        - 如果 context 有同名可变属性（非 dict/只读），直接 setattr
        - 否则写入 capability_state 字典
        """
        _MUTABLE_ATTRS = {
            "task_complexity", "current_phase", "active_plan",
            "short_term_memory", "working_memory", "long_term_memory_refs",
        }
        for key, value in modifications.items():
            if key in _MUTABLE_ATTRS:
                setattr(self, key, value)
            else:
                self.capability_state[key] = value

    def set(self, key: str, value: Any, slot: str = "capability_state") -> None:
        """显式写入 capability_state，用于能力代码中的状态通信。"""
        getattr(self, slot)[key] = value

    def get(self, key: str, default: Any = None, slot: str = "capability_state") -> Any:
        """统一读取接口。"""
        return getattr(self, slot).get(key, default)
```

### 4.3 CapabilityResult

```python
class CapabilityAction(str, Enum):
    """能力返回的动作信号。"""
    CONTINUE = "continue"  # 正常继续
    SKIP = "skip"          # 跳过后续能力（如熔断器开路）
    RETRY = "retry"        # 重新入队当前事件（重试）
    ABORT = "abort"        # 中止当前 turn


@dataclass
class CapabilityResult:
    """能力执行的返回值。"""

    # 控制流信号
    action: CapabilityAction = CapabilityAction.CONTINUE

    # 数据修改
    event_modifications: dict[str, Any] = field(default_factory=dict)
    context_modifications: dict[str, Any] = field(default_factory=dict)

    # 产出
    output: Any = None
    output_type: str | None = None  # "plan" | "critique" | "filtered_messages" | ...

    # 元数据
    capability_name: str = ""
    duration_ms: float = 0.0
    metrics: dict[str, Any] = field(default_factory=dict)
```

### 4.4 可变性契约

| 字段 | 归属 | 可变性 | 说明 |
|------|------|--------|------|
| `event.messages` | HookEvent | **可变** | 能力可裁剪/重排序消息 |
| `event.tool_call.arguments` | HookEvent | **可变** | 能力可修正不安全参数 |
| `event.tool_result` | HookEvent | **可变** | 能力可精炼工具返回 |
| `event.llm_response` | HookEvent | **可变** | 能力可后处理 LLM 输出 |
| `context.task_complexity` | AgentContext | **可变** | 能力可更新任务复杂度 |
| `context.capability_state` | AgentContext | **可变** | 能力间通信槽 |
| `context.short_term_memory` | AgentContext | **可变** | 短期记忆 |
| `context.working_memory` | AgentContext | **可变** | 工作记忆 |
| `context.active_plan` | AgentContext | **可变** | 当前计划 |
| `event.session_id` | HookEvent | **只读** | 会话标识不可变 |
| `event.turn` | HookEvent | **只读** | 轮次只读 |
| `context.agent_definition` | AgentContext | **只读** | Agent 定义只读 |
| `context.model_config` | AgentContext | **只读** | 模型配置只读 |

---

## 5. AgenticCapability 基类

```python
class AgenticCapability(ABC):
    """所有 Agentic 能力的基类。

    子类必须实现：
    - name: 能力唯一标识
    - layer: 逻辑层归属
    - subscribed_hooks: 订阅的 Hook 列表
    - priority: 执行优先级（0-100，低值先执行）
    - should_activate: 条件激活
    - on_event: 主逻辑
    """

    name: str
    layer: CapabilityLayer
    subscribed_hooks: list[HookPoint]
    priority: int = 50  # 0-100，低值先执行
    critical: bool = False  # 关键能力：失败时触发 ABORT

    @abstractmethod
    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """条件激活——评估是否需要在本次事件中执行。"""
        ...

    @abstractmethod
    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """事件回调——主逻辑。"""
        ...

    async def setup(self, context: AgentContext) -> None:
        """能力初始化（session 级）。"""
        pass

    async def teardown(self, context: AgentContext) -> None:
        """能力清理（session 级）。"""
        pass
```

### 5.1 优先级约定

| 范围 | 用途 | 示例 |
|------|------|------|
| 0-19 | 基础设施/元认知 | MetaCognitionMonitor, PromptTemplateManager |
| 20-39 | 感知/过滤 | SemanticFilter, ContextWindowManager |
| 40-59 | 推理/规划 | ReflectionLoop, PlanExecute |
| 60-79 | 行动/执行 | CircuitBreaker, ActionValidator |
| 80-99 | 反馈/评估 | SelfCritique, MemorySynthesis |

同一 Hook 内，低 priority 值的能力先执行。`MetaCognitionMonitor`(10) 计算的 `task_complexity` 可供 `PlanExecute`(40) 在 `should_activate` 中读取。

---

## 6. EventBus 与调度器

### 6.1 AgentEventBus

```python
class AgentEventBus:
    """事件总线——订阅/发布 + 优先级执行。"""

    def __init__(self) -> None:
        self._subscribers: dict[HookPoint, list[AgenticCapability]] = {}

    def register(self, capability: AgenticCapability) -> None:
        """注册能力到其订阅的所有 Hook。"""
        for hook in capability.subscribed_hooks:
            if hook not in self._subscribers:
                self._subscribers[hook] = []
            self._subscribers[hook].append(capability)
        # 按 priority 排序（升序，低值先执行）
        for hook in self._subscribers:
            self._subscribers[hook].sort(key=lambda c: c.priority)

    def unregister(self, name: str) -> None:
        """移除指定能力。"""
        for hook in self._subscribers:
            self._subscribers[hook] = [
                c for c in self._subscribers[hook] if c.name != name
            ]

    async def emit(
        self,
        hook: HookPoint,
        event: HookEvent,
        context: AgentContext,
    ) -> list[CapabilityResult]:
        """触发事件，按优先级执行所有活跃能力。

        执行规则：
        1. 按 priority 升序执行
        2. 先调用 should_activate，仅活跃能力执行 on_event
        3. 每次执行后应用修改到 event 和 context
        4. 支持 SKIP（跳过后续）、ABORT（中止 turn）、RETRY（重新入队）
        5. 能力错误隔离，不影响其他能力
        """
        results: list[CapabilityResult] = []
        capabilities = self._subscribers.get(hook, [])

        for cap in capabilities:
            try:
                if not await cap.should_activate(event, context):
                    continue

                result = await cap.on_event(event, context)
                results.append(result)

                # 应用修改
                self._apply_modifications(event, context, result)

                # 控制流信号
                if result.action == CapabilityAction.SKIP:
                    break
                if result.action == CapabilityAction.ABORT:
                    return results
                if result.action == CapabilityAction.RETRY:
                    # 重新入队：将当前事件重新调度到同一 Hook
                    retry_results = await self._handle_retry(hook, event, context, cap)
                    results.extend(retry_results)
                    break

            except Exception as e:
                logger.error(f"Capability {cap.name} failed on {hook}: {e}")
                # 错误隔离，继续执行其他能力

        return results

    def _apply_modifications(
        self,
        event: HookEvent,
        context: AgentContext,
        result: CapabilityResult,
    ) -> None:
        """应用能力对事件/上下文的修改。"""
        # 事件修改：仅允许白名单内的可变字段
        _MUTABLE_EVENT_FIELDS = frozenset({
            "messages", "tool_call", "tool_result", "llm_response",
        })
        for key, value in result.event_modifications.items():
            if key in _MUTABLE_EVENT_FIELDS and hasattr(event, key):
                setattr(event, key, value)

        # 上下文修改：区分属性写入与状态字典写入
        context.apply_modifications(result.context_modifications)

    async def _handle_retry(
        self,
        hook: HookPoint,
        event: HookEvent,
        context: AgentContext,
        originator: AgenticCapability,
    ) -> list[CapabilityResult]:
        """处理重试——重新入队当前事件。

        限制最大重试次数，防止无限循环。
        """
        retry_key = f"_retry_count_{originator.name}"
        current = context.get(retry_key, 0)
        max_retries = 3

        if current >= max_retries:
            logger.warning(f"Max retries reached for {originator.name} on {hook}")
            return []

        context.set(retry_key, current + 1)
        # 递归 emit 同一 hook（跳过 originator 之前的重试计数能力）
        return await self.emit(hook, event, context)
```

### 6.2 与 runner.py 的集成

`_agent_loop` 中的关键位置插入 `emit` 调用：

```python
async def _agent_loop(...):
    # Session 初始化
    await event_bus.emit(HookPoint.SESSION_INIT, event, context)

    while turn < max_turns:
        # Turn 开始 + 感知预处理
        await event_bus.emit(HookPoint.TURN_START, event, context)
        await event_bus.emit(HookPoint.PERCEPTION_PRE, event, context)

        # LLM 调用
        await event_bus.emit(HookPoint.LLM_PRE_INVOKE, event, context)
        async for llm_event in stream_llm(model, event.messages, tool_defs):
            ...

        # LLM 响应后
        await event_bus.emit(HookPoint.LLM_POST_RESPONSE, event, context)

        # 工具执行
        for tc in tool_calls:
            await event_bus.emit(HookPoint.TOOL_PRE_EXECUTE, event, context)
            try:
                await event_bus.emit(HookPoint.TOOL_EXECUTION, event, context)
                await event_bus.emit(HookPoint.TOOL_POST_EXECUTE, event, context)
                await event_bus.emit(HookPoint.PERCEPTION_OBSERVATION, event, context)
            except Exception as e:
                event.error = e
                await event_bus.emit(HookPoint.TOOL_ERROR, event, context)

        # Turn 结束
        await event_bus.emit(HookPoint.TURN_END, event, context)

    # Session 结束
    await event_bus.emit(HookPoint.SESSION_END, event, context)
```

---

## 7. 控制流信号运行时契约

### 7.1 信号定义与双层作用域

控制流信号在两个层面产生作用：

| 信号 | Hook 内作用（EventBus） | 驱动层行为（AgentRuntime） |
|------|-------------------------|---------------------------|
| `CONTINUE` | 继续执行后续能力 | 正常进入下一 Hook |
| `SKIP` | 跳过本 Hook 剩余能力 | 跳过当前 Hook 链的后续事件（如 `tool.pre_execute` 的 `SKIP` 阻塞了 `tool.execution` 和 `tool.post_execute`） |
| `ABORT` | 跳过剩余能力并返回 | 中止当前 Turn，不再触发 `turn.end`，直接进入下一 Turn |
| `RETRY` | 跳过剩余能力 | 驱动层重新从 `tool.pre_execute` 开始（或仅重试 `tool.execution`），依据错误类型决定 |

### 7.2 驱动层控制流处理

`AgentRuntime._agent_loop` 在每次 `emit` 后检查返回的动作信号，决定后续流程：

```python
async def _agent_loop(...):
    # ...

    # 工具执行流程
    for tc in tool_calls:
        # 1. tool.pre_execute
        pre_results = await event_bus.emit(HookPoint.TOOL_PRE_EXECUTE, event, context)
        if _has_action(pre_results, CapabilityAction.SKIP):
            # SKIP: 跳过工具执行和后续 hook，进入下一个工具调用
            event.tool_result = _get_skip_result(event)
            continue
        if _has_action(pre_results, CapabilityAction.ABORT):
            # ABORT: 中止当前 turn
            return

        # 2. tool.execution
        try:
            exec_results = await event_bus.emit(HookPoint.TOOL_EXECUTION, event, context)
            if _has_action(exec_results, CapabilityAction.SKIP):
                # 工具被熔断等，跳过实际执行
                continue
        except Exception as e:
            event.error = e
            error_results = await event_bus.emit(HookPoint.TOOL_ERROR, event, context)
            if _has_action(error_results, CapabilityAction.RETRY):
                # RETRY: 重新调度当前工具调用
                tool_calls.insert(0, tc)  # 重新入队
                continue
            # 未重试则继续后续流程

        # 3. tool.post_execute
        await event_bus.emit(HookPoint.TOOL_POST_EXECUTE, event, context)
        await event_bus.emit(HookPoint.PERCEPTION_OBSERVATION, event, context)

    # ...

def _has_action(results: list[CapabilityResult], action: CapabilityAction) -> bool:
    """检查能力结果中是否包含指定动作。"""
    return any(r.action == action for r in results)

def _get_skip_result(event: HookEvent) -> ToolResult:
    """生成 SKIP 情况下的默认结果。"""
    return ToolResult.text(f"Skipped by capability for {event.tool_call.name}", is_error=True)
```

### 7.3 关键安全能力（Critical Capabilities）

对于安全关键能力（如 `ActionValidator`），失败应导致 `ABORT` 而非静默忽略。

`AgenticCapability` 增加 `critical: bool = False` 属性：

```python
class AgenticCapability(ABC):
    name: str
    layer: CapabilityLayer
    subscribed_hooks: list[HookPoint]
    priority: int = 50
    critical: bool = False  # 关键能力：失败时触发 ABORT
```

`EventBus.emit` 对 critical 能力做特殊处理：

```python
async def emit(self, hook, event, context):
    for cap in capabilities:
        try:
            if not await cap.should_activate(event, context):
                continue
            result = await cap.on_event(event, context)
            results.append(result)
            self._apply_modifications(event, context, result)
            # ... 控制流信号处理 ...
        except Exception as e:
            logger.error(f"Capability {cap.name} failed on {hook}: {e}")
            # 关键能力失败 → ABORT
            if cap.critical:
                return [CapabilityResult(action=CapabilityAction.ABORT)]
            # 非关键能力：错误隔离，继续执行其他能力
    return results
```

---

现有 `CapabilityType` 从 4 种扩展为 8 种，与四层架构对齐：

```python
class CapabilityType(str, Enum):
    # 现有
    MEMORY = "memory"
    CONTEXT = "context"
    ORCHESTRATION = "orchestration"
    KNOWLEDGE = "knowledge"
    # 新增——与四层架构对齐
    PERCEPTION = "perception"    # 感知层
    REASONING = "reasoning"      # 推理层
    ACTION = "action"            # 行动层
    FEEDBACK = "feedback"        # 反馈层
```

同时引入 `CapabilityLayer` 作为逻辑分组的独立枚举：

```python
class CapabilityLayer(str, Enum):
    """能力逻辑层归属，用于分组和展示。"""
    PERCEPTION = "perception"
    REASONING = "reasoning"
    ACTION = "action"
    FEEDBACK = "feedback"
    INFRASTRUCTURE = "infrastructure"  # 跨层基础设施
```

---

## 8. 能力模块清单

### 8.1 感知层 (PERCEPTION)

| 能力 | 订阅 Hook | Priority | 效果预期 |
|------|-----------|----------|----------|
| ContextWindowManager | `perception.pre` | 20 | 自动裁剪/摘要历史消息，防上下文溢出 |
| SemanticFilter | `perception.pre`, `perception.observation` | 25 | 过滤低相关内容，减少噪声 |
| ToolLazyLoader | `session.init` | 10 | 按需加载工具定义，减少初始 token 消耗 |
| ToolOutputParser | `perception.observation` | 30 | 解析/精炼工具返回，提取关键结果 |
| RelevanceScorer | `perception.observation` | 35 | 对检索结果打分过滤 |
| UserIntentClassifier | `turn.start` | 15 | 意图识别，预路由到不同子系统 |

### 8.2 推理层 (REASONING)

| 能力 | 订阅 Hook | Priority | 效果预期 |
|------|-----------|----------|----------|
| ReflectionLoop | `llm.post_response` | 40 | 自我评估+修订，2-3 轮迭代 |
| PlanExecute | `llm.post_response`, `tool.pre_execute` | 45 | 生成计划 + 按计划分派工具调用 |
| TreeOfThoughts | `llm.post_response` | 50 | 多路径推理，保留回溯能力 |
| PhaseSeparation | `turn.start` | 40 | 强制分离分析/执行阶段 |
| ReActController | `turn.start` | 42 | Thought-Action-Observation 标准循环 |
| CoTWithVerification | `llm.post_response` | 48 | 推理链自检，生成前验证 |

### 8.3 行动层 (ACTION)

| 能力 | 订阅 Hook | Priority | 效果预期 |
|------|-----------|----------|----------|
| ModelRouter | `llm.pre_invoke` | 60 | 按复杂度/成本路由模型 |
| CircuitBreaker | `tool.pre_execute`, `tool.error`, `tool.post_execute` | 65 | 熔断保护，连续失败时阻断调用 |
| DualLLM | `llm.pre_invoke`, `tool.pre_execute` | 70 | 特权/隔离双模型安全架构 |
| ParallelToolExecutor | `tool.pre_execute` | 60 | DAG 并行执行独立工具调用 |
| HumanInTheLoopGate | `tool.pre_execute` | 80 | 敏感操作人工确认 |
| ActionValidator | `tool.pre_execute` | 62 | 参数安全校验（SQL 注入、路径安全） |
| ToolRetryBackoff | `tool.error` | 70 | 失败重试+指数退避 |

### 8.4 反馈层 (FEEDBACK)

| 能力 | 订阅 Hook | Priority | 效果预期 |
|------|-----------|----------|----------|
| SelfCritique | `tool.post_execute` | 80 | 即时纠错，低于阈值回退推理层 |
| MemorySynthesis | `turn.end` | 85 | 关键发现写入长期记忆 |
| OutputGroundingCheck | `turn.end` | 82 | 验证输出基于事实 |
| TraceQualityMonitor | `turn.end`, `session.end` | 88 | 步骤评分+综合评估 |
| AutoImprovementLoop | `session.end` | 90 | 用户纠正 → 生成修正案例存入记忆 |

### 8.5 跨层基础设施 (INFRASTRUCTURE)

| 能力 | 订阅 Hook | Priority | 说明 |
|------|-----------|----------|------|
| MetaCognitionMonitor | `turn.start`, `turn.end` | 5 | 跨层记录耗时/成功率，动态调整策略 |
| PromptTemplateManager | `llm.pre_invoke` | 10 | 集中管理 prompt 片段 |
| CollaborationBus | `turn.end` | 95 | 多 PACS 实例协作消息队列 |

---

## 9. 跨层能力示例

### 9.1 PlanExecute（推理 + 行动）

```python
class PlanExecuteCapability(AgenticCapability):
    name = "plan_execute"
    layer = CapabilityLayer.REASONING
    subscribed_hooks = [HookPoint.LLM_POST_RESPONSE, HookPoint.TOOL_PRE_EXECUTE]
    priority = 45

    async def should_activate(self, event, context):
        return context.get("task_complexity", 0.0) > 0.6

    async def on_event(self, event, context):
        if event.hook == HookPoint.LLM_POST_RESPONSE:
            # 推理阶段：生成/更新计划
            plan = await self._generate_plan(event, context)
            return CapabilityResult(
                context_modifications={"active_plan": plan},
                output=plan,
                output_type="plan",
            )
        elif event.hook == HookPoint.TOOL_PRE_EXECUTE:
            # 行动阶段：按计划分派工具调用
            return await self._dispatch_by_plan(event, context)
        return CapabilityResult()
```

### 9.2 CircuitBreaker（行动 + 错误流）

```python
class CircuitBreakerCapability(AgenticCapability):
    name = "circuit_breaker"
    layer = CapabilityLayer.ACTION
    subscribed_hooks = [
        HookPoint.TOOL_PRE_EXECUTE,
        HookPoint.TOOL_ERROR,
        HookPoint.TOOL_POST_EXECUTE,
    ]
    priority = 65

    def __init__(self):
        self._states: dict[str, CircuitState] = {}  # per tool

    async def should_activate(self, event, context):
        tool_name = event.tool_call.name if event.tool_call else ""
        return bool(tool_name)  # 有工具调用时激活

    async def on_event(self, event, context):
        tool_name = event.tool_call.name

        if event.hook == HookPoint.TOOL_PRE_EXECUTE:
            state = self._states.get(tool_name, CircuitState.CLOSED)
            if state == CircuitState.OPEN:
                # 熔断：阻止调用
                return CapabilityResult(
                    action=CapabilityAction.SKIP,
                    event_modifications={
                        "tool_result": ToolResult.text(
                            f"Circuit open for {tool_name}", is_error=True
                        ),
                    },
                )

        elif event.hook == HookPoint.TOOL_ERROR:
            # 记录失败
            self._record_failure(tool_name)

        elif event.hook == HookPoint.TOOL_POST_EXECUTE:
            # 记录成功，尝试半开恢复
            self._record_success(tool_name)

        return CapabilityResult()
```

---

## 10. 能力组合 DSL（设计方向）

允许通过配置声明能力组合，无需硬编码：

```yaml
# pyclaw.agents.capabilities config
capabilities:
  perception:
    - context_window_manager
    - semantic_filter
  reasoning:
    - react_controller
    - plan_execute:
        activate_threshold: 0.6
  action:
    - model_router
    - circuit_breaker:
        failure_threshold: 3
        cooldown_seconds: 60
    - action_validator
  feedback:
    - self_critique
    - memory_synthesis
```

预定义组合配方：

| 配方 | 感知 | 推理 | 行动 | 反馈 |
|------|------|------|------|------|
| `ReActAgent` | SemanticFilter | ReActController | CircuitBreaker | SelfCritique |
| `PlannerAgent` | ContextWindowManager | PlanExecute + PhaseSeparation | ModelRouter + ActionValidator | OutputGroundingCheck |
| `ResearchAgent` | RelevanceScorer | ToT + ReflectionLoop | ParallelToolExecutor | MemorySynthesis |
| `SafeAgent` | SemanticFilter | PlanExecute | DualLLM + HumanInTheLoopGate | TraceQualityMonitor |

---

## 11. 与现有模块的兼容性

| 现有模块 | PACS 映射 | 迁移策略 |
|----------|-----------|----------|
| `context/engine.py` | → ContextWindowManager + SemanticFilter | 保留为感知层能力的底层实现 |
| `memory/` | → MemorySynthesis + EpisodicMemory | 保留为反馈层记忆能力的底层实现 |
| `orchestration/engine.py` | → CollaborationBus + PlanExecute | 保留为行动层协作能力的底层实现 |
| `collaboration/` | → CollaborationBus | 保留，作为跨层基础设施的子系统 |
| `model_fallback.py` | → ModelRouter + CircuitBreaker | 保留为行动层能力的底层实现 |
| `intent.py` | → UserIntentClassifier | 迁移为感知层能力 |
| `interrupt.py` | → 在 `tool.pre_execute` 钩子中集成 | 保留中断机制，通过 Hook 触发 |
| `capabilities/registry.py` | → 扩展 CapabilityType + AgentEventBus | 保留注册机制，扩展类型枚举 |

**迁移原则**：现有模块保持不变，PACS 作为上层编排框架。现有模块变成能力的"实现层"，PACS 负责调度和组合。

---

## 12. 测试策略

### 12.1 能力单元测试

每个能力独立测试，Mock `HookEvent` 和 `AgentContext`：

```python
@pytest.mark.asyncio
async def test_circuit_breaker_opens_on_failures():
    cap = CircuitBreakerCapability(failure_threshold=3)
    context = AgentContext(session_id="test")

    # 模拟 3 次失败
    for _ in range(3):
        event = HookEvent(
            hook=HookPoint.TOOL_ERROR,
            tool_call=ToolCall(id="1", name="search", arguments={}),
            error=TimeoutError(),
            error_type="timeout",
            timestamp=0.0,
        )
        await cap.on_event(event, context)

    # 第 4 次应被熔断
    event = HookEvent(
        hook=HookPoint.TOOL_PRE_EXECUTE,
        tool_call=ToolCall(id="2", name="search", arguments={}),
        timestamp=0.0,
    )
    result = await cap.on_event(event, context)
    assert result.action == CapabilityAction.SKIP
```

### 12.2 EventBus 集成测试

```python
@pytest.mark.asyncio
async def test_event_bus_priority_ordering():
    bus = AgentEventBus()
    execution_order = []

    class EarlyCap(AgenticCapability):
        name = "early"
        layer = CapabilityLayer.PERCEPTION
        subscribed_hooks = [HookPoint.PERCEPTION_PRE]
        priority = 10

        async def should_activate(self, event, context): return True
        async def on_event(self, event, context):
            execution_order.append("early")
            return CapabilityResult()

    class LateCap(AgenticCapability):
        name = "late"
        layer = CapabilityLayer.PERCEPTION
        subscribed_hooks = [HookPoint.PERCEPTION_PRE]
        priority = 50

        async def should_activate(self, event, context): return True
        async def on_event(self, event, context):
            execution_order.append("late")
            return CapabilityResult()

    bus.register(EarlyCap())
    bus.register(LateCap())

    await bus.emit(HookPoint.PERCEPTION_PRE, HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0), AgentContext(session_id="test"))

    assert execution_order == ["early", "late"]
```

---

## 13. 实现路径与优先级排序

### 13.1 整体策略

**最小闭环 → 能力增量 → 配方组合**

```
Phase 0: 骨架    — EventBus + 基类 + Hook 定义
Phase 1: MVP     — 3 个核心能力跑通闭环（含错误流）
Phase 2: 扩展    — 按层补齐高价值能力
Phase 3: 组合    — 配方 DSL + 预定义配方
Phase 4: 高级    — 元认知 + 跨层基础设施
```

### 13.2 Phase 0：骨架（1-2 天）

**目标**：EventBus 能跑，基类能注册，Hook 能触发。零业务能力。

| 文件 | 内容 |
|------|------|
| `src/pyclaw/agents/pacs/types.py` | `HookPoint`, `CapabilityLayer`, `CapabilityAction`, `HookEvent`, `AgentContext`, `CapabilityResult` |
| `src/pyclaw/agents/pacs/capability.py` | `AgenticCapability` ABC |
| `src/pyclaw/agents/pacs/bus.py` | `AgentEventBus`（含 `_apply_modifications`, `_handle_retry`, `critical` 处理） |
| `src/pyclaw/agents/pacs/__init__.py` | 包导出 |
| `src/pyclaw/agents/pacs/compat.py` | `CapabilityType` 扩展（+4 枚举值） |

**验收标准**：
- `AgentEventBus` 注册能力 → emit 事件 → 按 priority 顺序执行 → 返回 `CapabilityResult`
- `_apply_modifications` 正确区分属性写入 vs 状态字典写入
- `_MUTABLE_EVENT_FIELDS` 白名单拦截非法事件字段修改
- `critical=True` 能力抛异常时返回 ABORT
- 单元测试覆盖以上 4 个场景

### 13.3 Phase 1：MVP 闭环（3-5 天）

**目标**：接入 3 个核心能力，在 `_agent_loop` 中跑通完整的事件驱动闭环，**包含错误流**。

**选能力原则**：每层一个，覆盖事件流全路径（含错误流），用户可感知效果。

| 能力 | 层 | 为什么是它 |
|------|-----|-----------|
| **SemanticFilter** | 感知 | 最直接的效果：减少 token 消耗，降低噪声。订阅 `perception.pre` + `perception.observation`，验证双 Hook 跨阶段感知 |
| **ReActController** | 推理 | Agent 框架的核心模式。订阅 `turn.start`，注入 Thought-Action-Observation 结构，验证推理层 Hook 链路 |
| **CircuitBreaker** | 行动 | 生产必需的安全网。订阅 `tool.pre_execute` + `tool.error` + `tool.post_execute`，验证跨层 Hook + 错误流 + SKIP 信号 |

**Runner 集成（含错误流 + RETRY 预留）**：

```python
async def _agent_loop(...):
    bus = context.pacs_bus
    event = HookEvent(hook=HookPoint.SESSION_INIT, session_id=session.session_id, timestamp=time.time())

    await bus.emit(HookPoint.SESSION_INIT, event, context)

    while turn < max_turns:
        event.hook = HookPoint.TURN_START
        event.turn = turn
        await bus.emit(HookPoint.TURN_START, event, context)

        event.hook = HookPoint.PERCEPTION_PRE
        await bus.emit(HookPoint.PERCEPTION_PRE, event, context)
        # 使用 event.messages（可能被 SemanticFilter 裁剪）

        # LLM 调用 —— 含错误流
        event.hook = HookPoint.LLM_PRE_INVOKE
        await bus.emit(HookPoint.LLM_PRE_INVOKE, event, context)

        try:
            llm_response = await invoke_llm(event.messages)
            event.llm_response = llm_response
            event.hook = HookPoint.LLM_POST_RESPONSE
            await bus.emit(HookPoint.LLM_POST_RESPONSE, event, context)
        except Exception as e:
            event.error = e
            event.error_type = classify_error(e)
            event.hook = HookPoint.LLM_ERROR
            error_results = await bus.emit(HookPoint.LLM_ERROR, event, context)
            if _has_action(error_results, CapabilityAction.ABORT):
                return
            # LLM 错误通常中止当前 turn，进入下一轮
            continue

        # 工具执行
        tool_calls = event.llm_response.get("tool_calls", [])
        pending_tools = list(tool_calls)  # 支持重试入队

        while pending_tools:
            tc = pending_tools.pop(0)
            event.tool_call = tc
            event.hook = HookPoint.TOOL_PRE_EXECUTE
            pre_results = await bus.emit(HookPoint.TOOL_PRE_EXECUTE, event, context)

            if _has_action(pre_results, CapabilityAction.SKIP):
                # CircuitBreaker 熔断
                continue
            if _has_action(pre_results, CapabilityAction.ABORT):
                return

            # 工具执行 —— 含错误流
            try:
                result = await execute_tool(tc)
                event.tool_result = result
                event.hook = HookPoint.TOOL_POST_EXECUTE
                await bus.emit(HookPoint.TOOL_POST_EXECUTE, event, context)

                event.hook = HookPoint.PERCEPTION_OBSERVATION
                await bus.emit(HookPoint.PERCEPTION_OBSERVATION, event, context)
            except Exception as e:
                event.error = e
                event.error_type = classify_error(e)
                event.hook = HookPoint.TOOL_ERROR
                error_results = await bus.emit(HookPoint.TOOL_ERROR, event, context)

                if _has_action(error_results, CapabilityAction.RETRY):
                    # 重试：重新入队（Phase 1 预留骨架）
                    retry_count = context.get(f"_retry_{tc.id}", 0) + 1
                    if retry_count <= 3:
                        context.set(f"_retry_{tc.id}", retry_count)
                        pending_tools.insert(0, tc)  # 重新入队
                    continue
                if _has_action(error_results, CapabilityAction.ABORT):
                    return
                # 其他情况：跳过当前工具，继续下一个

        event.hook = HookPoint.TURN_END
        await bus.emit(HookPoint.TURN_END, event, context)
        turn += 1

    await bus.emit(HookPoint.SESSION_END, event, context)


def _has_action(results: list[CapabilityResult], action: CapabilityAction) -> bool:
    return any(r.action == action for r in results)

def classify_error(e: Exception) -> str:
    """错误类型分类。"""
    if isinstance(e, asyncio.TimeoutError):
        return "timeout"
    if "rate_limit" in str(e).lower():
        return "rate_limit"
    return "execution_error"
```

**验收标准**：
- SemanticFilter 实际裁剪了传入 LLM 的消息
- ReActController 注入了 Thought-Action-Observation 结构提示
- CircuitBreaker 在 3 次失败后正确 SKIP 后续调用
- **错误流**：模拟工具返回错误 → CircuitBreaker 收到 `TOOL_ERROR` 并计数
- **RETRY 预留**：注册测试能力返回 RETRY → 验证驱动层重新调度工具调用
- 控制流信号在驱动层正确处理

### 13.4 Phase 2：按层扩展（5-7 天）

**目标**：补齐各层高价值能力。

**优先级排序逻辑**：效果优先 → 任务完成率提升最大 → 安全必需优先

| 批次 | 能力 | 层 | 效果预期 | 依赖 |
|------|------|-----|---------|------|
| 2a | **ContextWindowManager** | 感知 | 防上下文溢出，自动裁剪/摘要 | Phase 0 |
| 2a | **ReflectionLoop** | 推理 | 2-3 轮自评修订，提升输出质量 | Phase 0, `working_memory` 结构化历史 |
| 2a | **ActionValidator** | 行动 | 参数安全校验，防 SQL 注入/路径遍历 | Phase 0, `critical=True` |
| 2b | **ToolOutputParser** | 感知 | 精炼工具返回，减少后续 token | Phase 0 |
| 2b | **PlanExecute** | 推理 | 复杂任务分步执行，+40-70% 完成率 | MetaCognitionMonitor(Phase 4) 可选, `active_plan` 结构 |
| 2b | **ModelRouter** | 行动 | 按复杂度路由模型，降成本 | Phase 0 |
| 2c | **UserIntentClassifier** | 感知 | 意图预路由，提升响应速度 | 现有 `intent.py` 迁移 |
| 2c | **PhaseSeparation** | 推理 | 强制分离分析/执行，降低幻觉 | Phase 0 |
| 2c | **ToolRetryBackoff** | 行动 | 失败重试+退避，提升可靠性 | `tool.error` Hook |

**隐藏依赖说明**：
- `ReflectionLoop`：需要读取上一轮思考链和工具结果，依赖 `working_memory` 保留最近 N 个 `(thought, action, observation)` 三元组
- `PlanExecute`：计划存储在 `active_plan`，`ContextWindowManager` 需能解析该结构以便裁切时保留关键步骤

### 13.5 Phase 3：配方组合（3-4 天）

**目标**：YAML 配置化能力组合 + 预定义配方。

| 交付 | 说明 |
|------|------|
| `pacs/config.py` | 从 YAML/AgentDefinition 加载能力配置 |
| `pacs/recipes.py` | 预定义配方注册表 + `CapabilityRegistry` 工厂 |
| 配方: `ReActAgent` | SemanticFilter + ReActController + CircuitBreaker + SelfCritique |
| 配方: `PlannerAgent` | ContextWindowManager + PlanExecute + PhaseSeparation + ModelRouter + ActionValidator + OutputGroundingCheck |
| 配方: `ResearchAgent` | RelevanceScorer + ToT + ReflectionLoop + ParallelToolExecutor + MemorySynthesis |
| 配方: `SafeAgent` | SemanticFilter + PlanExecute + DualLLM + HumanInTheLoopGate + TraceQualityMonitor |

**配方 DSL 扩展要求**：

```yaml
capabilities:
  reasoning:
    - plan_execute:
        priority: 45  # 覆盖默认 priority
        task_complexity_threshold: 0.6  # 条件启用参数
        requires: [context_window_manager]  # 依赖声明
```

### 13.6 Phase 4：高级能力 + 元认知（5-7 天）

| 批次 | 能力 | 说明 |
|------|------|------|
| 4a | **MetaCognitionMonitor** | priority=5，跨层记录耗时/成功率，写入 `task_complexity` 供后续能力决策 |
| 4a | **PromptTemplateManager** | 集中管理 prompt 片段，按能力注入 |
| 4a | **SelfCritique** | 即时纠错，低于阈值回退推理层 |
| 4b | **MemorySynthesis** | 关键发现写入长期记忆，集成现有 `memory/` 模块 |
| 4b | **OutputGroundingCheck** | 验证输出基于事实 |
| 4b | **DualLLM** | 特权/隔离双模型安全架构 |
| 4c | **TreeOfThoughts** | 多路径推理 |
| 4c | **ParallelToolExecutor** | DAG 并行执行 |
| 4c | **CollaborationBus** | 多 PACS 实例协作 |
| 4c | **AutoImprovementLoop** | 用户纠正 → 修正案例 |

### 13.7 总时间线

```
Week 1:  Phase 0 (骨架) + Phase 1 (MVP 闭环，含错误流)
Week 2:  Phase 2a (高价值扩展 #1)
Week 3:  Phase 2b-2c (高价值扩展 #2-3)
Week 4:  Phase 3 (配方组合)
Week 5-6: Phase 4 (高级能力 + 元认知)
```

### 13.8 与现有模块的迁移顺序

| 顺序 | 迁移项 | 方式 |
|------|--------|------|
| 1 | `intent.py` → `UserIntentClassifier` | 包装为 AgenticCapability，原模块保留 |
| 2 | `context/engine.py` → `ContextWindowManager` + `SemanticFilter` | 原模块变为能力底层实现 |
| 3 | `model_fallback.py` → `ModelRouter` | 扩展为 Budget-Aware 路由 |
| 4 | `memory/` → `MemorySynthesis` | 反馈层能力调用现有记忆 API |
| 5 | `orchestration/` → `CollaborationBus` | 跨层基础设施，包装现有引擎 |

---

## 14. 开放问题

1. **重试递归深度**：EventBus `_handle_retry` 的最大递归深度是否需要全局配置？
2. **能力热加载**：是否支持 session 运行中动态注册/注销能力？
3. **能力依赖图**：是否需要声明能力间依赖（`depends_on`），还是 priority 足够？
4. **事件持久化**：是否需要将 HookEvent 流持久化用于审计/回放？
5. **性能开销**：每个 Hook 的 emit 开销基准测量，确保不显著增加延迟。
