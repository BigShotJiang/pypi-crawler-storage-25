# Memory System Enhancement Design

> 文档版本：v1.0
> 最后更新：2026-04-12
> 涉及组件：`memory/dreaming/`、`memory/wiki/`、`agents/memory_dir/`、`memory/active_recall.py`

---

## 1. 系统概述

Memory 系统增强包含三个相互协作的子系统：

- **Active Memory**：在主回复前自动检索相关记忆，注入上下文，让 Agent 更"懂"用户。
- **Dreaming**：基于召回信号的三阶段记忆巩固流水线（Light → Deep → REM），自动将短期高频信息提升为长期记忆。
- **Wiki**：面向人类与 Agent 的结构化知识库，以 Claim/Evidence 模型为核心，支持版本演化、信任评估和 Obsidian 集成。

三者通过 **MemoryDirectory** 和 **MemoryManager** 共享数据，形成"信号收集 → 自动巩固 → 结构化沉淀 → 人工/Agent 协作编辑"的完整记忆生命周期。

### 1.1 与现有系统的关系

```
┌─────────────────────────────────────────────────────────────────────┐
│                         PyClaw Memory System                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐          │
│  │ MemoryManager│───>│MemoryDirectory│<───│  Wiki Vault  │          │
│  │   (统一接口)  │    │  (结构化存储)  │    │ (知识库视图) │          │
│  └──────┬───────┘    └──────┬───────┘    └──────┬───────┘          │
│         │                   │                    │                  │
│         ▼                   ▼                    ▼                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐          │
│  │ActiveRecaller│    │ Dreaming     │    │    Bridge    │          │
│  │  (主动召回)   │    │  (记忆巩固)   │    │   (双向同步)  │          │
│  └──────────────┘    └──────────────┘    └──────────────┘          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 2. Active Memory 子系统

### 2.1 核心类型 (`memory/recall_types.py`)

```python
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

class QueryMode(str, Enum):
    """Active Memory 查询模式"""
    MESSAGE = "message"      # 仅使用最新用户消息
    RECENT = "recent"        # 使用最近几轮对话 + 最新消息
    FULL = "full"            # 使用完整对话上下文

class PromptStyle(str, Enum):
    """召回提示风格"""
    BALANCED = "balanced"
    STRICT = "strict"
    CONTEXTUAL = "contextual"
    RECALL_HEAVY = "recall-heavy"
    PRECISION_HEAVY = "precision-heavy"
    PREFERENCE_ONLY = "preference-only"

@dataclass
class ActiveRecallConfig:
    """Active Memory 配置"""
    enabled: bool = True
    agents: list[str] = field(default_factory=lambda: ["main"])
    model: str | None = None
    model_fallback: str = "openai/gpt-4o-mini"
    timeout_ms: int = 15000
    query_mode: QueryMode = QueryMode.RECENT
    prompt_style: PromptStyle = PromptStyle.BALANCED
    max_summary_chars: int = 220
    recent_user_turns: int = 2
    recent_assistant_turns: int = 1
    allowed_chat_types: list[str] = field(default_factory=lambda: ["direct"])
    cache_ttl_ms: int = 15000
    logging: bool = True

@dataclass
class ActiveRecallResult:
    """Active Memory 召回结果"""
    status: str  # "ok" | "empty" | "timeout" | "unavailable"
    elapsed_ms: int
    summary: str | None = None
    raw_reply: str | None = None
    search_debug: dict[str, Any] | None = None
```

### 2.2 核心类 (`memory/active_recall.py`)

```python
class ActiveMemoryRecaller:
    """主动记忆召回器
    
    在主回复前自动检索相关记忆，注入上下文。
    参考 OpenClaw active-memory 插件实现。
    """
    
    def __init__(
        self,
        memory_manager: MemoryManager,
        config: ActiveRecallConfig,
        model_config: ModelConfig | None = None,
    ): ...
    
    async def recall(
        self,
        latest_message: str,
        recent_turns: list[dict[str, str]] | None = None,
        session_key: str | None = None,
    ) -> ActiveRecallResult:
        """执行记忆召回
        
        1. 构建查询 (根据 query_mode)
        2. 搜索记忆 (memory_manager.search_memory + MemoryDirectory)
        3. 可选：LLM 总结/过滤
        4. 返回结果
        """
        ...
    
    def build_context_message(self, result: ActiveRecallResult) -> dict[str, str]:
        """构建注入到对话的 system message"""
        ...
    
    def is_session_disabled(self, session_key: str) -> bool:
        """检查会话是否禁用 Active Memory"""
        ...
    
    def set_session_disabled(self, session_key: str, disabled: bool) -> None:
        """设置会话禁用状态"""
        ...
```

### 2.3 Hook 集成 (`agents/hooks/pre_reasoning.py`)

在现有 `MemoryPreReasoningHook` 中增强：

```python
class MemoryPreReasoningHook:
    """增强：集成 Active Memory"""
    
    async def __call__(self, event: HookEvent) -> dict[str, Any] | None:
        # 1. Active Memory 召回 (新增)
        if self._config.active_recall.enabled:
            recall_result = await self._active_recall.recall(
                latest_message=event.latest_message,
                recent_turns=event.recent_turns,
                session_key=event.session_key,
            )
            if recall_result.status == "ok":
                context_msg = self._active_recall.build_context_message(recall_result)
                event.messages.insert(1, context_msg)
        
        # 2. 原有逻辑：工具结果压缩 + 上下文压缩
        ...
```

### 2.4 会话级开关

支持 `/active-memory on|off|status` 命令控制会话级别的启用/禁用，状态存储在 `session-toggles.json`。

---

## 3. Dreaming 子系统

### 3.1 核心类型 (`memory/dreaming/types.py`)

```python
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

class DreamingPhase(str, Enum):
    LIGHT = "light"
    DEEP = "deep"
    REM = "rem"

class StorageMode(str, Enum):
    INLINE = "inline"
    SEPARATE = "separate"
    BOTH = "both"

@dataclass
class DreamingConfig:
    enabled: bool = False
    cron: str = "0 3 * * *"
    timezone: str | None = None
    limit: int = 10
    min_score: float = 0.5
    min_recall_count: int = 2
    min_unique_queries: int = 2
    recency_half_life_days: float = 7.0
    max_age_days: int | None = None
    verbose_logging: bool = False
    storage: StorageMode = StorageMode.INLINE

@dataclass
class PromotionCandidate:
    content: str
    source_path: str
    start_line: int
    end_line: int
    score: float
    recall_count: int
    unique_queries: int
    snippet: str
    components: dict[str, float]
    created_at: datetime

@dataclass
class DreamingReport:
    phase: DreamingPhase
    timestamp: datetime
    workspace_dir: str
    candidates_count: int
    promoted_count: int
    report_lines: list[str]
    promoted_snippets: list[str]
```

### 3.2 阶段处理器 (`memory/dreaming/phases.py`)

| 阶段 | 方法 | 职责 | 输出 |
| :--- | :--- | :--- | :--- |
| Light | `run_light_phase()` | 收集短期召回信号、每日记忆、会话摘要；去重并暂存候选 | 不写入长期记忆，仅更新内部状态 |
| Deep | `run_deep_phase()` | 加权评分、阈值过滤、从源文件水合内容、写入 MEMORY.md | `DreamingReport`，追加长期记忆条目 |
| REM | `run_rem_phase()` | 从短期痕迹提取主题与反思信号，生成摘要 | 叙事性报告，不修改长期记忆 |

### 3.3 信号收集 (`memory/dreaming/signals.py`)

```python
@dataclass
class ShortTermSignal:
    """短期记忆信号"""
    content_hash: str              # 内容指纹 (SHA-256 前 16 字符)
    content: str                   # 原始内容
    source_ref: str                # 源文件:行号
    recall_queries: set[str]       # 引起召回的查询集合
    last_recall_at: int            # 最后召回时间戳
    consolidation_count: int       # Agent 主动引用次数
    conceptual_tags: list[str]     # 概念标签
    created_at: int                # 首次出现时间戳

class SignalsStore:
    """信号存储管理器"""
    def add_signal(self, content: str, source_ref: str, query: str, ...) -> ShortTermSignal: ...
    def get_all_signals(self) -> list[ShortTermSignal]: ...
    def record_consolidation(self, content_hash: str) -> None: ...
    def cleanup_old_signals(self, max_age_days: int) -> int: ...
```

### 3.4 评分与提升 (`memory/dreaming/scoring.py`, `promotion.py`)

**评分维度**：
- frequency: 被召回频率 (0-1)
- relevance: 语义相关性 (0-1)
- diversity: 查询多样性 (0-1)
- recency: 新近度衰减 (0-1)
- consolidation: 巩固信号 (0-1)
- conceptual: 概念标签匹配 (0-1)

**提升流程**：
1. `PromotionScorer` 计算分数
2. 阈值过滤 (min_score, min_recall_count, min_unique_queries)
3. `MemoryPromoter` 验证源文件并追加到 `MEMORY.md`
4. 去重合并：基于内容指纹，相似条目更新时间戳而非追加

### 3.5 调度与 Hook 集成 (`memory/dreaming/scheduler.py`)

- 基于 **Cron + Heartbeat** 模式，在 `before_agent_reply` hook 中触发
- 使用 `SYSTEM_EVENT_TEXT = "__pyclaw_memory_dreaming_promotion__"` 标识 dreaming 事件
- **后台异步执行**（`asyncio.create_task`），不阻塞 Agent 回复
- **文件锁**防止并发执行

```python
class DreamingScheduler:
    SYSTEM_EVENT_TEXT = "__pyclaw_memory_dreaming_promotion__"
    LOCK_FILE = ".dreams/locks/promotion.lock"
    
    async def handle_heartbeat(self, event: dict, trigger: str) -> dict | None:
        if trigger != "heartbeat" or not self._is_dreaming_event(event):
            return None
        if not self._config.enabled:
            return {"handled": True, "reason": "dreaming disabled"}
        
        # 后台异步执行
        asyncio.create_task(self._run_dreaming_async())
        return {"handled": True, "reason": "dreaming started in background"}
    
    async def _run_dreaming_async(self) -> DreamingReport:
        with self._acquire_lock():
            return await self._run_dreaming_phases()
```

### 3.6 叙事生成 (`memory/dreaming/narrative.py`)

`DreamNarrativeGenerator` 使用小模型生成 Dream Diary 条目，存入 `DREAMS.md`。

### 3.7 文件结构

```
memory/
├── .dreams/                 # 状态目录
│   ├── recall-store.json    # 信号存储
│   ├── checkpoints/         # 阶段检查点
│   └── locks/               # 提升锁
├── dreaming/
│   ├── deep/                # Deep 报告（如 separate）
│   └── rem/                 # REM 报告
├── DREAMS.md                # Dream Diary（叙事）
└── MEMORY.md                # 长期记忆（Deep 提升）
```

---

## 4. Wiki 子系统

### 4.1 核心类型 (`memory/wiki/types.py`)

```python
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from typing import Any

class VaultMode(str, Enum):
    ISOLATED = "isolated"
    BRIDGE = "bridge"
    UNSAFE_LOCAL = "unsafe-local"

class ClaimStatus(str, Enum):
    ACTIVE = "active"
    SUPERSEDED = "superseded"
    CONTRADICTED = "contradicted"
    UNCERTAIN = "uncertain"

@dataclass
class Evidence:
    source_id: str
    source_path: str
    lines: str               # e.g., "45-52"
    weight: float
    excerpt: str | None = None

@dataclass
class Claim:
    id: str
    text: str
    status: ClaimStatus = ClaimStatus.ACTIVE
    confidence: float = 0.5
    evidence: list[Evidence] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    contradictions: list[str] = field(default_factory=list)
    open_questions: list[str] = field(default_factory=list)
    # 版本演化
    replaces: list[str] = field(default_factory=list)
    replaced_by: str | None = None
    version: int = 1
    previous_versions: list[str] = field(default_factory=list)

@dataclass
class WikiPage:
    path: str
    title: str
    content: str
    claims: list[Claim] = field(default_factory=list)
    source_refs: list[str] = field(default_factory=list)
    last_compiled: datetime | None = None
    provenance: dict[str, Any] = field(default_factory=dict)

@dataclass
class WikiConfig:
    enabled: bool = False
    vault_mode: VaultMode = VaultMode.BRIDGE
    vault_path: str = "wiki"
    search_corpus: str = "wiki"
    auto_compile: bool = True
    render_mode: str = "markdown"
    source_trust_levels: dict[str, float] = field(default_factory=lambda: {
        "memory/": 0.9,
        "sources/official": 0.95,
        "sources/drafts": 0.5,
        "inbox.md": 0.3,
    })
```

### 4.2 模块职责

| 模块 | 类 | 职责 |
| :--- | :--- | :--- |
| `vault.py` | `WikiVault` | 目录初始化、页面读写、统计 |
| `claims.py` | `ClaimsManager` | Claim 增删改查、矛盾检测、导出 |
| `compile.py` | `WikiCompiler` | 从源内容生成结构化页面，集成信任模型与锁 |
| `bridge.py` | `MemoryBridge` | Memory ↔ Wiki 同步，跨库搜索，冲突协调 |
| `lint.py` | `WikiLinter` | 健康检查：低置信度、无证据、矛盾、过期 |
| `markdown.py` | - | 区块标记处理，保留人工编辑区 |
| `watcher.py` | `WikiWatcher` | 监听 `sources/` 变化触发增量编译 |
| `render.py` | `ObsidianRenderer` | 生成 Obsidian 兼容格式 |
| `tools.py` | Agent 工具函数 | `wiki_search`, `wiki_get`, `wiki_add_claim` 等 |

### 4.3 区块标记与人工编辑保护

页面内容由两部分组成，通过 HTML 注释标记隔离：

```markdown
<!-- pyclaw-wiki:human:start -->
[用户自由编辑的内容]
<!-- pyclaw-wiki:human:end -->

<!-- pyclaw-wiki:auto:start -->
[由 WikiCompiler 自动生成的结构化内容]
<!-- pyclaw-wiki:auto:end -->
```

编译器在写入时仅替换自动区块，完整保留人工区块。

### 4.4 编译触发与并发控制

- **监听模式**（`ISOLATED`）：`WikiWatcher` 监听 `vault/sources/` 目录，文件变更触发增量编译
- **调度模式**（`BRIDGE`）：可配合 Cron 定期从 Memory 拉取新内容编译
- **并发锁**：使用 `fcntl.flock`（或跨平台库 `portalocker`）在 `.openclaw-wiki/locks/compile.lock` 上获取排他锁

### 4.5 与 MemoryDirectory 的整合

- **数据流向**：Memory 为 **唯一真相源**，Wiki 为可编辑视图
- **同步策略**：
  - `MemoryBridge.sync_claims_to_memory()` 将 Wiki Claims 转为 `MemoryDecision` 存入 MemoryDirectory
  - `MemoryBridge.sync_from_memory()` 从 Memory 拉取条目生成 Wiki 页面（可选）
  - 冲突协调时，以 Memory 为准，Wiki 差异标记为待审核状态

### 4.6 Agent 工具接口 (`memory/wiki/tools.py`)

```python
async def wiki_search(query: str, corpus: str = "wiki", limit: int = 10) -> list[dict]: ...
async def wiki_get(page_path: str) -> WikiPage | None: ...
async def wiki_append_section(page_path: str, section_title: str, section_content: str) -> WikiPage: ...
async def wiki_update_section(page_path: str, section_title: str, new_content: str) -> WikiPage: ...
async def wiki_add_claim(page_path: str, claim_text: str, evidence: list[dict] | None = None) -> Claim: ...
async def wiki_supersede_claim(old_claim_id: str, new_claim_text: str, rationale: str) -> Claim: ...
async def wiki_find_related(query: str, limit: int = 5) -> list[tuple[WikiPage, list[Claim]]]: ...
```

### 4.7 文件结构

```
wiki/                           # Vault 根目录
├── entities/                   # 实体页面
├── concepts/                   # 概念页面
├── syntheses/                  # 综合页面
├── sources/                    # 源文档（触发编译的输入）
├── reports/                    # 自动生成报告
├── _attachments/               # 附件
├── _views/                     # 视图/查询
├── .openclaw-wiki/             # 元数据目录
│   ├── state.json
│   ├── log.jsonl
│   ├── locks/
│   └── cache/
├── AGENTS.md                   # 面向 Agent 的说明
├── WIKI.md                     # Wiki 系统说明
├── index.md                    # 首页
└── inbox.md                    # 待处理条目
```

---

## 5. 子系统交互流程

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Memory Lifecycle                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  [用户对话] ──(Active Memory)──> [上下文增强] ──> [Agent 回复]           │
│       │                                                                 │
│       ▼                                                                 │
│  [短期会话/召回] ──(Light)──> [短期信号缓冲] ──(Deep)──> MEMORY.md       │
│                                       │                                 │
│                                       ▼                                 │
│                              MemoryDirectory (统一索引)                  │
│                                       │                                 │
│                                       ▼                                 │
│                              WikiCompiler (BRIDGE 模式)                 │
│                                       │                                 │
│                                       ▼                                 │
│                              Wiki Vault (Claims + 人工编辑)             │
│                                       │                                 │
│                                       └──(REM)──> Dream Diary 反思摘要  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 6. 新增模块结构

```
src/pyclaw/
├── memory/
│   ├── __init__.py              # [增强] 统一导出 DreamingManager, WikiManager, ActiveMemoryRecaller
│   ├── manager.py               # [增强] 添加 active_recall() 方法
│   ├── active_recall.py         # [新增] ActiveMemoryRecaller 类
│   ├── recall_types.py          # [新增] Active Memory 类型定义
│   ├── dreaming/                # [新增目录]
│   │   ├── __init__.py          # DreamingManager 入口
│   │   ├── phases.py            # LightPhase, DeepPhase, REMPhase
│   │   ├── promotion.py         # 短期→长期提升逻辑
│   │   ├── scoring.py           # 加权评分算法
│   │   ├── signals.py           # 信号收集与存储
│   │   ├── narrative.py         # Dream Diary 生成
│   │   ├── scheduler.py         # Cron 任务管理 + Hook 触发
│   │   └── types.py             # Dreaming 配置和状态类型
│   └── wiki/                    # [新增目录]
│       ├── __init__.py          # WikiManager 入口
│       ├── vault.py             # Wiki Vault 目录管理
│       ├── claims.py            # Claim/Evidence 结构化存储
│       ├── compile.py           # 编译摘要生成
│       ├── lint.py              # Claim 健康检查/矛盾聚类
│       ├── bridge.py            # 与 MemoryDirectory 桥接
│       ├── markdown.py          # 区块标记处理
│       ├── watcher.py           # 文件监听触发编译
│       ├── render.py            # Obsidian 渲染支持
│       ├── tools.py             # Agent 工具函数
│       └── types.py             # Wiki 配置和类型
│
├── agents/
│   ├── memory_dir/
│   │   ├── memdir.py            # [增强] 添加 claims 支持
│   │   ├── memory_types.py      # [增强] 新增 ClaimEntry, EvidenceEntry
│   │   └── find_relevant_memories.py  # [增强] 支持 corpus=all 搜索
│   └── hooks/
│       └── pre_reasoning.py     # [增强] 集成 Active Memory + Dreaming 触发
│
├── cron/
│   ├── scheduler.py             # [增强] 支持 systemEvent payload
│   └── types.py                 # [新增] CronJobCreate, CronPayload 类型
│
└── config/
    └── schema.py                # [增强] 新增 memory.active_recall/dreaming/wiki 配置
```

---

## 7. 配置示例

```yaml
# pyclaw.yaml
memory:
  # Active Memory 配置
  active_recall:
    enabled: true
    agents: ["main"]
    query_mode: recent
    prompt_style: balanced
    timeout_ms: 15000
    max_summary_chars: 220
    allowed_chat_types: ["direct"]
  
  # Dreaming 配置
  dreaming:
    enabled: true
    cron: "0 3 * * *"
    limit: 10
    min_score: 0.5
    min_recall_count: 2
    min_unique_queries: 2
    recency_half_life_days: 7.0
    storage: inline
  
  # Wiki 配置
  wiki:
    enabled: true
    vault_mode: bridge
    vault_path: "./wiki"
    auto_compile: true
    render_mode: obsidian
    source_trust_levels:
      "memory/": 0.9
      "sources/official": 0.95
      "sources/drafts": 0.5
```

---

## 8. 实施路线图

### Phase 1: Active Memory (1-2 周)

| 任务 | 工作量 | 依赖 |
|------|--------|------|
| 类型定义 (`recall_types.py`) | 0.5d | - |
| `ActiveMemoryRecaller` 核心实现 | 1d | 类型定义 |
| Hook 集成 (`pre_reasoning.py`) | 0.5d | ActiveMemoryRecaller |
| 会话开关命令 | 0.5d | - |
| 单元测试 | 1d | 全部 |
| 文档更新 | 0.5d | 全部 |

### Phase 2: Wiki 增强 (2 周)

| 任务 | 工作量 | 依赖 |
|------|--------|------|
| 类型定义 (`wiki/types.py`) | 0.5d | - |
| `WikiVault` 目录管理 | 1d | 类型定义 |
| 区块标记 (`markdown.py`) | 0.5d | WikiVault |
| `ClaimsManager` 实现 | 1.5d | WikiVault |
| `WikiCompiler` 编译器 | 2d | ClaimsManager |
| `MemoryBridge` 桥接 | 1d | WikiCompiler |
| Agent 工具接口 | 1d | 全部 |
| 单元测试 | 1.5d | 全部 |

### Phase 3: Dreaming (2 周)

| 任务 | 工作量 | 依赖 |
|------|--------|------|
| 类型定义 (`dreaming/types.py`) | 0.5d | - |
| `SignalsStore` 信号存储 | 1d | 类型定义 |
| `PromotionScorer` 评分器 | 1d | SignalsStore |
| `DreamingPhases` 三阶段 | 2d | PromotionScorer |
| `MemoryPromoter` 提升器 | 1d | DreamingPhases |
| `DreamingScheduler` 调度 | 1d | 全部 |
| Hook 集成 | 0.5d | DreamingScheduler |
| 单元测试 | 1.5d | 全部 |
| 集成测试 | 1d | 全部 |

---

## 9. 参考文档

- [OpenClaw Active Memory Plugin](https://github.com/openclaw/openclaw/tree/main/extensions/active-memory)
- [OpenClaw Dreaming System](https://github.com/openclaw/openclaw/tree/main/extensions/memory-core/src)
- [OpenClaw Memory Wiki](https://github.com/openclaw/openclaw/tree/main/extensions/memory-wiki)
- [OpenClaw Active Memory Docs](https://docs.openclaw.ai/concepts/active-memory)
- [OpenClaw Dreaming Docs](https://docs.openclaw.ai/concepts/dreaming)
