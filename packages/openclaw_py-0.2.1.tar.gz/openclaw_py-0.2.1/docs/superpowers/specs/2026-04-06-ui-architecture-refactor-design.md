# UI 架构重构设计规范

> 创建日期：2026-04-06
> 状态：已归档（Flet UI 已迁移至 TypeScript，本文档仅作历史参考）
> 范围：Flet UI 架构重构（已废弃）

---

## 1. 概述

### 1.1 目标

重构 `src/pyclaw/ui/` 目录下的 Flet UI 架构（现已迁移至 TypeScript），解决以下问题：

| 问题 | 现状 |
|------|------|
| 面板代码臃肿 | 单个面板文件 400+ 行，逻辑、状态、UI 混在一起 |
| 状态管理混乱 | 状态用 `list`/`dict` hack 存储，回调通过闭包传递 |
| 组件复用困难 | 每个面板独立实现 `_safe_update`、`_fire_async` |
| Gateway 交互分散 | 每个面板直接持有 `gateway_client`，错误处理不统一 |
| 测试困难 | 面板构建函数返回 UI 控件，无法注入 mock |

### 1.2 设计原则

1. **MVC 分层** — Model（数据）、View（UI）、Controller（逻辑）职责分离
2. **响应式状态** — 状态变化自动通知订阅者，UI 自动更新
3. **依赖注入** — 控制器依赖抽象接口，便于测试和扩展
4. **渐进迁移** — 保留兼容层，旧代码无需立即修改

---

## 2. 目录结构

```text
src/pyclaw/ui/
├── __init__.py
├── app.py                      # 主应用入口（简化后）
├── theme.py                    # 主题系统（保留）
├── i18n.py                     # 国际化（保留）
├── icons.py                    # 图标库（保留）
├── shimmer.py                  # 骨架屏动画（保留）
├── canvas.py                   # 画布组件（保留）
├── canvas_panel.py             # 画布面板（保留）
├── image_canvas.py             # 图片标注（保留）
│
├── core/                       # 基础设施层
│   ├── __init__.py
│   ├── reactive.py             # Reactive[T] 响应式状态
│   ├── base_panel.py           # BasePanel 抽象基类
│   ├── base_controller.py      # BaseController 抽象类
│   ├── gateway_service.py      # GatewayService 统一封装
│   ├── event_bus.py            # 跨面板事件总线
│   ├── repository.py           # Repository 抽象接口
│   ├── types.py                # 公共类型定义
│   └── testing.py              # Mock 工具
│
├── components/                 # 可复用 UI 组件库
│   ├── __init__.py
│   ├── tiles.py                # card_tile, list_tile
│   ├── forms.py                # slider_input, switch_with_info
│   ├── status.py               # status_chip, streaming_indicator
│   ├── empty_state.py          # empty_state, error_state
│   ├── page_header.py          # page_header, expandable_section
│   └── media.py                # 图片/文件预览组件
│
├── panels/                     # 功能面板（MVC 结构）
│   ├── __init__.py
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── model.py            # Agent 数据模型
│   │   ├── state.py            # AgentsState 响应式状态
│   │   ├── controller.py       # AgentsController 业务逻辑
│   │   ├── view.py             # AgentsView UI 渲染
│   │   └── local_repository.py # 本地文件系统实现
│   ├── sessions/
│   │   ├── __init__.py
│   │   ├── model.py
│   │   ├── state.py
│   │   ├── controller.py
│   │   ├── view.py
│   │   └── local_repository.py
│   ├── overview/
│   ├── channels/
│   ├── instances/
│   ├── usage/
│   ├── cron/
│   ├── plans/
│   ├── skills/
│   ├── nodes/
│   ├── logs/
│   ├── debug/
│   ├── config/
│   ├── system/
│   ├── voice/
│   └── quick_actions/
│
├── chat/                       # 聊天功能（复杂模块独立）
│   ├── __init__.py
│   ├── message.py              # ChatMessage 组件
│   ├── tool_call.py            # ToolCallCard 组件
│   ├── markdown.py             # Markdown 渲染
│   ├── chat_view.py            # ChatView 主界面
│   ├── session_sidebar.py      # 会话侧边栏
│   └── toolbar.py              # 聊天工具栏
│
└── platform/                   # 平台适配层
    ├── __init__.py
    ├── desktop.py              # 桌面端（托盘、窗口控制）
    ├── mobile.py               # 移动端（权限、手势）
    └── responsive_shell.py     # 响应式布局 Shell
```

---

## 3. 核心模块设计

### 3.1 `core/reactive.py` — 响应式状态

```python
"""响应式状态管理 — 状态变化自动通知订阅者。"""
from __future__ import annotations
from typing import Generic, TypeVar, Callable

T = TypeVar("T")


class Reactive(Generic[T]):
    """响应式值包装器，支持订阅变化通知。

    使用示例:
        count = Reactive(0)
        unsubscribe = count.subscribe(lambda v: print(f"Count: {v}"))
        count.value = 1  # 触发打印 "Count: 1"
        unsubscribe()    # 取消订阅

    ⚠️ 重要注意事项：
        对于 list/dict 等可变类型，必须采用"替换不可变快照"的方式更新：
        ❌ 错误: state.agents.value.append(agent)  # 不会触发通知
        ✅ 正确: state.agents.value = [*state.agents.value, agent]  # 触发通知
    """

    def __init__(self, initial: T) -> None:
        self._value: T = initial
        self._subscribers: list[Callable[[T], None]] = []

    @property
    def value(self) -> T:
        """获取当前值。"""
        return self._value

    @value.setter
    def value(self, new: T) -> None:
        """设置新值，如果值变化则通知所有订阅者。

        使用 `is` 判断引用是否变化，对于可变类型需替换整个对象。
        """
        if new is self._value:
            return
        self._value = new
        self._notify()

    def subscribe(self, callback: Callable[[T], None]) -> Callable[[], None]:
        """订阅值变化。

        Args:
            callback: 值变化时调用的回调函数

        Returns:
            取消订阅函数，调用后移除该订阅
        """
        self._subscribers.append(callback)

        def unsubscribe() -> None:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

        return unsubscribe

    def _notify(self) -> None:
        """通知所有订阅者，遍历副本防止回调中修改列表。"""
        for callback in self._subscribers.copy():
            try:
                callback(self._value)
            except Exception:
                # 忽略订阅者异常，避免影响其他订阅者
                pass

    # 便捷方法
    def set(self, value: T) -> None:
        """设置值（等同于 value setter）。"""
        self.value = value

    def get(self) -> T:
        """获取值（等同于 value getter）。"""
        return self._value

    def mutate(self, mutator: Callable[[T], None]) -> None:
        """对可变类型进行修改并触发通知。

        自动创建副本后修改，适用于 list/dict 等可变类型。
        使用示例:
            state.agents.mutate(lambda lst: lst.append(new_agent))
        """
        import copy
        self._value = copy.deepcopy(self._value)
        mutator(self._value)
        self._notify()
```

**设计决策**：
- 使用普通列表存储回调，避免 `WeakSet` 对方法对象的弱引用失效问题
- `subscribe` 返回取消函数，支持手动清理
- 暂不实现 `Computed`，等有明确需求再添加
- 使用 `is` 判断引用变化（非 `==`），强制用户采用"替换快照"模式更新可变类型

---

### 3.2 `core/event_bus.py` — 跨面板事件总线

```python
"""事件总线 — 跨面板通信的轻量级发布/订阅系统。"""
from __future__ import annotations
from typing import Any, Callable
from dataclasses import dataclass, field


@dataclass
class EventBus:
    """轻量级事件总线，用于跨面板通信。

    使用示例:
        bus = EventBus()
        unsubscribe = bus.on(AppEvents.AGENTS_DELETED, lambda id: print(f"Deleted: {id}"))
        bus.emit(AppEvents.AGENTS_DELETED, "agent-123")  # 打印 "Deleted: agent-123"
        unsubscribe()
    """

    _handlers: dict[str, list[Callable[[Any], None]]] = field(default_factory=dict)

    def on(self, event: str, handler: Callable[[Any], None]) -> Callable[[], None]:
        """订阅事件。

        Args:
            event: 事件名称
            handler: 事件处理函数

        Returns:
            取消订阅函数
        """
        self._handlers.setdefault(event, []).append(handler)

        def off() -> None:
            if event in self._handlers and handler in self._handlers[event]:
                self._handlers[event].remove(handler)

        return off

    def emit(self, event: str, data: Any = None) -> None:
        """触发事件。

        Args:
            event: 事件名称
            data: 事件数据
        """
        handlers = self._handlers.get(event, [])
        for handler in handlers.copy():
            try:
                handler(data)
            except Exception:
                # 忽略处理异常，避免影响其他订阅者
                pass

    def clear(self, event: str | None = None) -> None:
        """清除事件订阅。

        Args:
            event: 事件名称，为 None 时清除所有
        """
        if event is None:
            self._handlers.clear()
        elif event in self._handlers:
            del self._handlers[event]
```

**预定义事件**：

```python
# core/events.py — 事件常量定义
class AppEvents:
    """预定义事件名称常量，避免字符串拼写错误。"""
    # Agent 事件
    AGENTS_CREATED = "agents.created"
    AGENTS_DELETED = "agents.deleted"
    AGENTS_UPDATED = "agents.updated"
    # Session 事件
    SESSIONS_CREATED = "sessions.created"
    SESSIONS_DELETED = "sessions.deleted"
    SESSIONS_ACTIVATED = "sessions.activated"
    # Gateway 事件
    GATEWAY_CONNECTED = "gateway.connected"
    GATEWAY_DISCONNECTED = "gateway.disconnected"
    # Config 事件
    CONFIG_CHANGED = "config.changed"


# 事件数据类型定义（可选，供类型检查使用）
from dataclasses import dataclass

@dataclass
class AgentEventData:
    agent_id: str
    agent_name: str
    path: str

@dataclass
class GatewayDisconnectedData:
    error: str | None
```

| 事件名 | 数据 | 说明 |
|--------|------|------|
| `AppEvents.AGENTS_CREATED` | `AgentEventData` | Agent 创建 |
| `AppEvents.AGENTS_DELETED` | `str` (agent_id) | Agent 删除 |
| `AppEvents.SESSIONS_CREATED` | `Session` | 会话创建 |
| `AppEvents.SESSIONS_DELETED` | `str` (session_id) | 会话删除 |
| `AppEvents.GATEWAY_CONNECTED` | `None` | Gateway 连接成功 |
| `AppEvents.GATEWAY_DISCONNECTED` | `GatewayDisconnectedData` | Gateway 断开 |

---

### 3.3 `core/repository.py` — 数据仓库抽象

```python
"""数据仓库抽象接口 — 控制器依赖抽象而非具体实现。"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .types import Agent, Session


class AgentRepository(ABC):
    """Agent 数据仓库抽象接口。"""

    @abstractmethod
    async def list_agents(self) -> list[Agent]:
        """获取所有 Agent。"""
        ...

    @abstractmethod
    async def get_agent(self, agent_id: str) -> Agent | None:
        """获取单个 Agent。"""
        ...

    @abstractmethod
    async def get_agent_tools(self, agent_id: str) -> list[str]:
        """获取 Agent 的工具列表。"""
        ...

    @abstractmethod
    async def create_agent(self, agent_data: AgentCreate) -> Agent:
        """创建新 Agent。

        Args:
            agent_data: Agent 创建数据（不含 id/path，由仓库生成）

        Returns:
            创建完成的 Agent（包含 id/path）
        """
        ...

    @abstractmethod
    async def delete_agent(self, agent_id: str) -> None:
        """删除 Agent。"""
        ...


@dataclass
class AgentCreate:
    """Agent 创建数据（不含 id/path）。"""
    name: str
    model: str = ""
    provider: str = ""
    system_prompt: str = ""
    tools: list[str] = field(default_factory=list)
    skills: list[dict[str, Any]] = field(default_factory=list)


class SessionRepository(ABC):
    """Session 数据仓库抽象接口。"""

    @abstractmethod
    async def list_sessions(self, limit: int = 50) -> list[Session]:
        """获取会话列表。"""
        ...

    @abstractmethod
    async def get_session(self, session_id: str) -> Session | None:
        """获取单个会话。"""
        ...

    @abstractmethod
    async def create_session(self, session_data: SessionCreate) -> Session:
        """创建新会话。"""
        ...

    @abstractmethod
    async def update_session(self, session_id: str, updates: dict[str, Any]) -> Session:
        """更新会话。"""
        ...

    @abstractmethod
    async def delete_session(self, session_id: str) -> None:
        """删除会话。"""
        ...

    @abstractmethod
    async def get_session_messages(self, session_id: str) -> list[dict]:
        """获取会话消息。"""
        ...


@dataclass
class SessionCreate:
    """Session 创建数据。"""
    label: str = ""
    agent_id: str = ""
    kind: str = "chat"
```

---

### 3.4 `core/gateway_service.py` — Gateway 服务封装

```python
"""Gateway 服务 — 统一封装 WebSocket 调用，提供类型安全的 API。"""
from __future__ import annotations
from typing import Any

from .reactive import Reactive


class GatewayError(Exception):
    """Gateway 调用错误。"""

    def __init__(self, code: str, message: str, details: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.details = details


class GatewayService:
    """Gateway 调用的统一封装，提供错误处理和连接状态管理。

    使用示例:
        gw = GatewayService(raw_client)
        gw.connected.subscribe(self._on_connection_changed)
        await gw.connect()
        agents = await gw.list_agents()
    """

    def __init__(self, raw_client: Any) -> None:
        """初始化 Gateway 服务。

        Args:
            raw_client: 原始 GatewayClient 实例
        """
        self._raw = raw_client
        self.connected = Reactive(False)
        self.connection_state = Reactive("offline")

        # 绑定原始客户端的状态回调
        if hasattr(raw_client, "on_connection_state"):
            raw_client.on_connection_state(self._on_raw_state_change)

    def _on_raw_state_change(self, state: str, meta: dict[str, Any]) -> None:
        """处理原始客户端的状态变化。"""
        self.connection_state.value = state
        self.connected.value = state == "connected"

    @property
    def raw(self) -> Any:
        """获取原始客户端（用于特殊场景）。"""
        return self._raw

    async def connect(self) -> None:
        """建立连接。"""
        if hasattr(self._raw, "connect"):
            await self._raw.connect()

    async def disconnect(self) -> None:
        """断开连接。"""
        if hasattr(self._raw, "disconnect"):
            await self._raw.disconnect()

    async def wait_connected(self, timeout: float = 10.0) -> bool:
        """等待连接建立。

        Args:
            timeout: 超时时间（秒）

        Returns:
            是否成功连接
        """
        import asyncio

        if self.connected.value:
            return True

        connected_event = asyncio.Event()

        def _on_connected(connected: bool) -> None:
            if connected:
                connected_event.set()

        unsubscribe = self.connected.subscribe(_on_connected)

        try:
            await asyncio.wait_for(connected_event.wait(), timeout=timeout)
            return True
        except asyncio.TimeoutError:
            return False
        finally:
            unsubscribe()

    # ─── 类型安全的 API 方法 ─────────────────────────────

    async def list_agents(self) -> list[dict[str, Any]]:
        """获取 Agent 列表。"""
        result = await self._call("agents.list", {})
        return result.get("agents", [])

    async def get_agent_tools(self, agent_id: str) -> list[str]:
        """获取 Agent 的工具列表。"""
        result = await self._call("agents.tools", {"agentId": agent_id})
        return result.get("tools", [])

    async def list_sessions(self, limit: int = 50) -> list[dict[str, Any]]:
        """获取会话列表。"""
        result = await self._call("sessions.list", {"limit": limit})
        return result.get("sessions", [])

    async def delete_session(self, path: str) -> bool:
        """删除会话。"""
        await self._call("sessions.delete", {"path": path})
        return True

    async def send_chat(self, session_id: str, message: str) -> None:
        """发送聊天消息。"""
        await self._call("chat.send", {"sessionId": session_id, "message": message})

    async def health_check(self) -> dict[str, Any]:
        """健康检查。"""
        return await self._call("health", {})

    async def _call(
        self,
        method: str,
        params: dict,
        *,
        timeout: float = 10.0,
    ) -> dict[str, Any]:
        """底层 RPC 调用，统一错误处理。

        Args:
            method: RPC 方法名
            params: 调用参数
            timeout: 超时时间

        Returns:
            调用结果

        Raises:
            GatewayError: 调用失败
        """
        if not self._raw or not getattr(self._raw, "connected", False):
            raise GatewayError("NOT_CONNECTED", "Gateway not connected")

        try:
            return await self._raw.call(method, params, timeout=timeout)
        except Exception as e:
            raise GatewayError("CALL_FAILED", str(e), {"method": method, "params": params}) from e
```

---

### 3.5 `core/base_controller.py` — 控制器基类

```python
"""控制器基类 — 管理业务逻辑和状态生命周期。"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any

from .event_bus import EventBus


class BaseController(ABC):
    """控制器的抽象基类，管理生命周期和资源清理。

    子类需要实现:
        - _on_initialize(): 初始化逻辑
        - _on_dispose(): 清理逻辑（可选）
    """

    def __init__(self, event_bus: EventBus | None = None) -> None:
        self._event_bus = event_bus
        self._initialized = False
        self._unsubscribes: list[Callable[[], None]] = []

    async def initialize(self) -> None:
        """初始化控制器，加载初始数据。"""
        if self._initialized:
            return
        await self._on_initialize()
        self._initialized = True

    async def dispose(self) -> None:
        """清理资源，取消所有订阅。"""
        # 调用所有取消函数
        for unsubscribe in self._unsubscribes:
            try:
                unsubscribe()
            except Exception:
                pass
        self._unsubscribes.clear()

        await self._on_dispose()
        self._initialized = False

    def _add_unsubscribe(self, fn: Callable[[], None]) -> None:
        """添加取消函数到清理列表。"""
        self._unsubscribes.append(fn)

    @abstractmethod
    async def _on_initialize(self) -> None:
        """子类实现初始化逻辑。"""
        ...

    async def _on_dispose(self) -> None:
        """子类可选实现清理逻辑。"""
        pass
```

---

### 3.6 `core/base_panel.py` — 面板基类

```python
"""面板基类 — 统一 UI 面板的生命周期和通用行为。"""
from __future__ import annotations
import asyncio
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Callable

import flet as ft

if TYPE_CHECKING:
    from .base_controller import BaseController


class BasePanel(ft.Column, ABC):
    """所有功能面板的抽象基类。

    子类需要实现:
        - _build_header(): 构建面板头部
        - _build_content(): 构建面板内容
        - _refresh_data(): 刷新数据（可选）
    """

    def __init__(self, controller: BaseController) -> None:
        super().__init__(expand=True, spacing=0)
        self._controller = controller
        self._mounted = False
        self._unsubscribes: list[Callable[[], None]] = []
        self._build_ui()

    def _build_ui(self) -> None:
        """构建 UI 结构。"""
        self.controls = [
            self._build_header(),
            self._build_content(),
        ]

    @abstractmethod
    def _build_header(self) -> ft.Control:
        """构建面板头部。"""
        ...

    @abstractmethod
    def _build_content(self) -> ft.Control:
        """构建面板内容区域。"""
        ...

    async def on_mount(self) -> None:
        """面板挂载时调用，初始化数据。"""
        self._mounted = True
        await self._controller.initialize()
        await self._refresh_data()

    async def on_unmount(self) -> None:
        """面板卸载时调用，清理资源。"""
        self._mounted = False

        # 取消所有订阅
        for unsubscribe in self._unsubscribes:
            try:
                unsubscribe()
            except Exception:
                pass
        self._unsubscribes.clear()

        await self._controller.dispose()

    async def _refresh_data(self) -> None:
        """刷新面板数据，子类可重写。"""
        pass

    def _add_unsubscribe(self, fn: Callable[[], None]) -> None:
        """添加取消函数到清理列表。"""
        self._unsubscribes.append(fn)

    def _safe_update(self, control: ft.Control | None = None) -> None:
        """安全更新控件，避免页面未挂载时的错误。"""
        import logging
        target = control or self
        try:
            if target.page:
                target.update()
            else:
                logging.debug("Update skipped: control not mounted")
        except RuntimeError:
            pass

    def _show_error(self, message: str) -> None:
        """显示错误提示。"""
        if self.page:
            snack = ft.SnackBar(content=ft.Text(message), bgcolor=ft.Colors.ERROR)
            self.page.overlay.append(snack)
            snack.open = True
            self.page.update()

    def _show_success(self, message: str) -> None:
        """显示成功提示。"""
        if self.page:
            snack = ft.SnackBar(content=ft.Text(message))
            self.page.overlay.append(snack)
            snack.open = True
            self.page.update()

    def _fire_async(
        self,
        coro: Any,
        *,
        on_error: Callable[[Exception], None] | None = None,
        on_success: Callable[[], None] | None = None,
    ) -> None:
        """安全执行异步任务，自动处理异常。

        Args:
            coro: 协程对象
            on_error: 错误回调，默认显示 SnackBar
            on_success: 成功回调
        """
        async def _run() -> None:
            try:
                await coro
                if on_success:
                    on_success()
            except Exception as e:
                if on_error:
                    on_error(e)
                else:
                    self._show_error(str(e))

        # Flet 回调中通常已有运行中的事件循环
        asyncio.create_task(_run())
```

---

### 3.7 `core/types.py` — 公共类型定义

```python
"""公共类型定义。"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Agent:
    """Agent 实体。"""
    id: str
    name: str
    path: str
    model: str = ""
    provider: str = ""
    system_prompt: str = ""
    tools: list[str] = field(default_factory=list)
    skills: list[dict[str, Any]] = field(default_factory=list)
    channels: list[str] = field(default_factory=list)
    cron: list[Any] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Agent:
        """从字典创建 Agent。"""
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            path=data.get("path", ""),
            model=data.get("model", ""),
            provider=data.get("provider", ""),
            system_prompt=data.get("systemPrompt", ""),
            tools=data.get("tools", []),
            skills=data.get("skills", []),
            channels=data.get("channels", []),
            cron=data.get("cron", []),
        )

    def to_dict(self) -> dict[str, Any]:
        """转换为字典。"""
        return {
            "id": self.id,
            "name": self.name,
            "path": self.path,
            "model": self.model,
            "provider": self.provider,
            "systemPrompt": self.system_prompt,
            "tools": self.tools,
            "skills": self.skills,
            "channels": self.channels,
            "cron": self.cron,
        }


@dataclass
class Session:
    """会话实体。"""
    id: str
    path: str
    label: str
    agent_id: str = ""
    kind: str = "chat"
    tokens: int = 0
    size: int = 0
    updated_at: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Session:
        """从字典创建 Session。"""
        return cls(
            id=data.get("id", data.get("key", "")),
            path=data.get("path", ""),
            label=data.get("label", ""),
            agent_id=data.get("agentId", ""),
            kind=data.get("kind", "chat"),
            tokens=data.get("tokens", 0),
            size=data.get("size", 0),
            updated_at=data.get("updated", ""),
        )
```

---

### 3.8 `core/testing.py` — 测试支持

```python
"""测试支持 — Mock 实现和测试工具。"""
from __future__ import annotations
from typing import Any

from .reactive import Reactive
from .types import Agent, Session


class MockGatewayService:
    """Mock Gateway 服务，用于测试。"""

    def __init__(self, responses: dict[str, Any] | None = None) -> None:
        self._responses = responses or {}
        self.connected = Reactive(True)
        self.connection_state = Reactive("connected")

    async def connect(self) -> None:
        self.connected.value = True
        self.connection_state.value = "connected"

    async def disconnect(self) -> None:
        self.connected.value = False
        self.connection_state.value = "offline"

    async def _call(self, method: str, params: dict) -> dict[str, Any]:
        return self._responses.get(method, {})

    # 代理常用方法（返回正确结构）
    async def list_agents(self) -> list[dict[str, Any]]:
        return self._responses.get("agents.list", {}).get("agents", [])

    async def list_sessions(self, limit: int = 50) -> list[dict[str, Any]]:
        return self._responses.get("sessions.list", {}).get("sessions", [])

    async def health_check(self) -> dict[str, Any]:
        return self._responses.get("health", {"version": "mock", "uptime_seconds": 0})


class MockAgentRepository:
    """Mock Agent 仓库，用于测试。"""

    def __init__(self, agents: list[Agent] | None = None) -> None:
        self._agents = agents or []

    async def list_agents(self) -> list[Agent]:
        return self._agents.copy()

    async def get_agent(self, agent_id: str) -> Agent | None:
        for agent in self._agents:
            if agent.id == agent_id:
                return agent
        return None

    async def get_agent_tools(self, agent_id: str) -> list[str]:
        return ["mock_tool_1", "mock_tool_2"]

    async def create_agent(
        self,
        name: str,
        model: str,
        provider: str,
        system_prompt: str,
    ) -> Agent:
        agent = Agent(
            id=name.lower().replace(" ", "-"),
            name=name,
            path=f"/agents/{name}",
            model=model,
            provider=provider,
            system_prompt=system_prompt,
        )
        self._agents.append(agent)
        return agent

    async def delete_agent(self, agent_id: str) -> None:
        self._agents = [a for a in self._agents if a.id != agent_id]


class MockSessionRepository:
    """Mock Session 仓库，用于测试。"""

    def __init__(self, sessions: list[Session] | None = None) -> None:
        self._sessions = sessions or []

    async def list_sessions(self, limit: int = 50) -> list[Session]:
        return self._sessions[:limit]

    async def get_session(self, session_id: str) -> Session | None:
        for session in self._sessions:
            if session.id == session_id:
                return session
        return None

    async def delete_session(self, session_id: str) -> None:
        self._sessions = [s for s in self._sessions if s.id != session_id]

    async def get_session_messages(self, session_id: str) -> list[dict]:
        return []


class MockEventBus:
    """Mock 事件总线，用于测试。"""

    def __init__(self) -> None:
        self.events: list[tuple[str, Any]] = []

    def on(self, event: str, handler: Any) -> Callable[[], None]:
        return lambda: None

    def emit(self, event: str, data: Any = None) -> None:
        self.events.append((event, data))

    def clear(self, event: str | None = None) -> None:
        self.events.clear()


# ─────────────────────────────────────────────────────────────
# 单元测试示例
# ─────────────────────────────────────────────────────────────

"""
# tests/pyclaw/ui/panels/agents/test_controller.py
import pytest
from pyclaw.ui.panels.agents.controller import AgentsController
from pyclaw.ui.panels.agents.state import AgentsState
from pyclaw.ui.core.testing import MockAgentRepository, MockEventBus
from pyclaw.ui.core.types import Agent
from pyclaw.ui.core.events import AppEvents


@pytest.fixture
def mock_repo():
    return MockAgentRepository([
        Agent(id="agent-1", name="Test Agent", path="/agents/test-agent"),
    ])


@pytest.fixture
def mock_event_bus():
    return MockEventBus()


@pytest.fixture
def controller(mock_repo, mock_event_bus):
    return AgentsController(mock_repo, event_bus=mock_event_bus)


@pytest.mark.asyncio
async def test_refresh_loads_agents(controller):
    \"\"\"刷新应加载 Agent 列表。\"\"\"
    await controller.refresh()
    assert len(controller.state.agents.value) == 1
    assert controller.state.agents.value[0].name == "Test Agent"


@pytest.mark.asyncio
async def test_select_agent_updates_state(controller):
    \"\"\"选中 Agent 应更新 selected_id。\"\"\"
    await controller.refresh()
    await controller.select_agent("agent-1")
    assert controller.state.selected_id.value == "agent-1"
    assert controller.state.selected_agent is not None
    assert controller.state.selected_agent.name == "Test Agent"


@pytest.mark.asyncio
async def test_create_agent_adds_to_list(controller, mock_event_bus):
    \"\"\"创建 Agent 应添加到列表并发出事件。\"\"\"
    from pyclaw.ui.core.repository import AgentCreate

    await controller.refresh()
    agent_data = AgentCreate(name="New Agent", model="gpt-4")
    agent = await controller._repo.create_agent(agent_data)

    # 更新状态（模拟 controller.create_agent）
    controller.state.agents.value = [*controller.state.agents.value, agent]

    assert len(controller.state.agents.value) == 2
    # 注意：实际测试应调用 controller.create_agent 并验证事件


@pytest.mark.asyncio
async def test_delete_agent_removes_from_list(controller, mock_event_bus):
    \"\"\"删除 Agent 应从列表移除并发出事件。\"\"\"
    await controller.refresh()
    await controller.delete_agent("agent-1")

    assert len(controller.state.agents.value) == 0
    assert mock_event_bus.events[-1] == (AppEvents.AGENTS_DELETED, "agent-1")


@pytest.mark.asyncio
async def test_initialize_calls_refresh(controller):
    \"\"\"initialize 应调用 refresh 加载数据。\"\"\"
    assert not controller._initialized
    await controller.initialize()
    assert controller._initialized
    assert len(controller.state.agents.value) == 1
"""
```

---

## 4. 面板 MVC 实现示例：Agents Panel

### 4.1 `panels/agents/state.py` — 响应式状态

```python
"""Agents 面板状态。"""
from __future__ import annotations
from dataclasses import dataclass, field

from pyclaw.ui.core.reactive import Reactive
from pyclaw.ui.core.types import Agent


@dataclass
class AgentsState:
    """Agents 面板的响应式状态。"""
    agents: Reactive[list[Agent]] = field(default_factory=lambda: Reactive([]))
    selected_id: Reactive[str] = field(default_factory=lambda: Reactive(""))
    loading: Reactive[bool] = field(default_factory=lambda: Reactive(False))
    error: Reactive[str | None] = field(default_factory=lambda: Reactive(None))

    @property
    def selected_agent(self) -> Agent | None:
        """当前选中的 Agent。"""
        selected = self.selected_id.value
        for agent in self.agents.value:
            if agent.id == selected:
                return agent
        return None
```

### 4.2 `panels/agents/controller.py` — 业务逻辑

```python
"""Agents 控制器 — 处理业务逻辑。"""
from __future__ import annotations

from pyclaw.ui.core.base_controller import BaseController
from pyclaw.ui.core.event_bus import EventBus
from pyclaw.ui.core.repository import AgentRepository
from .state import AgentsState


class AgentsController(BaseController):
    """Agents 面板的业务逻辑控制器。"""

    def __init__(
        self,
        repo: AgentRepository,
        event_bus: EventBus | None = None,
    ) -> None:
        super().__init__(event_bus)
        self._repo = repo
        self.state = AgentsState()

    async def _on_initialize(self) -> None:
        """初始化时加载 Agent 列表。"""
        await self.refresh()

    async def refresh(self) -> None:
        """刷新 Agent 列表。"""
        self.state.loading.value = True
        self.state.error.value = None

        try:
            agents = await self._repo.list_agents()
            self.state.agents.value = agents
        except Exception as e:
            self.state.error.value = str(e)
        finally:
            self.state.loading.value = False

    async def select_agent(self, agent_id: str) -> None:
        """选中一个 Agent。"""
        self.state.selected_id.value = agent_id

    async def create_agent(
        self,
        name: str,
        model: str,
        provider: str,
        system_prompt: str,
    ) -> None:
        """创建新 Agent。"""
        from pyclaw.ui.core.repository import AgentCreate
        from pyclaw.ui.core.events import AppEvents

        self.state.loading.value = True
        try:
            agent_data = AgentCreate(
                name=name,
                model=model,
                provider=provider,
                system_prompt=system_prompt,
            )
            agent = await self._repo.create_agent(agent_data)
            # 更新状态（替换快照）
            self.state.agents.value = [*self.state.agents.value, agent]
            # 发出事件
            if self._event_bus:
                self._event_bus.emit(AppEvents.AGENTS_CREATED, agent)
        finally:
            self.state.loading.value = False

    async def delete_agent(self, agent_id: str) -> None:
        """删除 Agent。"""
        from pyclaw.ui.core.events import AppEvents
        self.state.loading.value = True
        try:
            await self._repo.delete_agent(agent_id)
            # 更新状态（替换快照）
            self.state.agents.value = [a for a in self.state.agents.value if a.id != agent_id]
            # 清除选中
            if self.state.selected_id.value == agent_id:
                self.state.selected_id.value = ""
            # 发出事件
            if self._event_bus:
                self._event_bus.emit(AppEvents.AGENTS_DELETED, agent_id)
        finally:
            self.state.loading.value = False
```

### 4.3 `panels/agents/view.py` — UI 渲染

```python
"""Agents 视图 — UI 渲染层。"""
from __future__ import annotations

import flet as ft

from pyclaw.ui.core.base_panel import BasePanel
from pyclaw.ui.components.tiles import card_tile
from pyclaw.ui.components.page_header import page_header
from pyclaw.ui.components.status import status_chip
from pyclaw.ui.i18n import t
from .controller import AgentsController


class AgentsView(BasePanel):
    """Agents 面板的视图层。"""

    def __init__(self, controller: AgentsController) -> None:
        # 初始化 UI 组件
        self._agent_list = ft.ListView(expand=True, spacing=4, padding=8)
        self._detail_area = ft.Column(expand=True, spacing=8)
        self._loading_indicator = ft.ProgressRing(visible=False)
        self._last_error: str | None = None  # 错误去重

        # 调用父类初始化（会调用 _build_header 和 _build_content）
        super().__init__(controller)

        # 订阅状态变化，保存取消函数
        self._add_unsubscribe(
            controller.state.agents.subscribe(self._on_agents_changed)
        )
        self._add_unsubscribe(
            controller.state.selected_id.subscribe(self._on_selection_changed)
        )
        self._add_unsubscribe(
            controller.state.loading.subscribe(self._on_loading_changed)
        )
        self._add_unsubscribe(
            controller.state.error.subscribe(self._on_error_changed)
        )

    def _build_header(self) -> ft.Control:
        return page_header(
            ft.Icons.SMART_TOY,
            t("agents.title", default="Agents"),
            actions=[
                self._loading_indicator,
                ft.IconButton(
                    icon=ft.Icons.REFRESH,
                    tooltip=t("common.refresh", default="Refresh"),
                    on_click=lambda e: self._fire_async(self._controller.refresh()),
                ),
            ],
        )

    def _build_content(self) -> ft.Control:
        return ft.Row(
            controls=[
                ft.Container(
                    content=self._agent_list,
                    width=260,
                ),
                ft.VerticalDivider(width=1),
                ft.Container(
                    content=self._detail_area,
                    expand=True,
                    padding=12,
                ),
            ],
            expand=True,
        )

    async def _refresh_data(self) -> None:
        """刷新数据。"""
        await self._controller.refresh()

    # ─── 状态变化回调 ─────────────────────────────────────

    def _on_agents_changed(self, agents: list) -> None:
        """Agent 列表变化时刷新 UI。"""
        self._render_agent_list(agents)
        self._safe_update(self._agent_list)

    def _on_selection_changed(self, selected_id: str) -> None:
        """选中项变化时刷新 UI。"""
        self._render_agent_list(self._controller.state.agents.value)
        self._render_detail()
        self._safe_update(self._agent_list)
        self._safe_update(self._detail_area)

    def _on_loading_changed(self, loading: bool) -> None:
        """加载状态变化。"""
        self._loading_indicator.visible = loading
        self._safe_update(self._loading_indicator)

    def _on_error_changed(self, error: str | None) -> None:
        """错误状态变化（去重显示）。"""
        if error and error != self._last_error:
            self._last_error = error
            self._show_error(error)

    # ─── UI 渲染方法 ─────────────────────────────────────
            self._show_error(error)

    # ─── UI 渲染方法 ─────────────────────────────────────

    def _render_agent_list(self, agents: list) -> None:
        """渲染 Agent 列表。"""
        self._agent_list.controls.clear()
        selected_id = self._controller.state.selected_id.value

        if not agents:
            self._agent_list.controls.append(
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Icon(ft.Icons.SMART_TOY_OUTLINED, size=48, color=ft.Colors.OUTLINE),
                            ft.Text(t("agents.empty", default="No agents configured")),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=8,
                    ),
                    alignment=ft.Alignment(0, 0),
                    expand=True,
                )
            )
            return

        for agent in agents:
            is_selected = agent.id == selected_id
            tile = card_tile(
                content=ft.Row(
                    [
                        ft.Icon(
                            ft.Icons.SMART_TOY if is_selected else ft.Icons.SMART_TOY_OUTLINED,
                            color=ft.Colors.PRIMARY if is_selected else ft.Colors.OUTLINE,
                        ),
                        ft.Column(
                            [
                                ft.Text(
                                    agent.name,
                                    weight=ft.FontWeight.BOLD if is_selected else None,
                                ),
                                ft.Text(agent.model or agent.id, size=11, color=ft.Colors.OUTLINE),
                            ],
                            spacing=2,
                            expand=True,
                            tight=True,
                        ),
                    ],
                    spacing=8,
                ),
                on_click=lambda e, aid=agent.id: self._fire_async(
                    self._controller.select_agent(aid)
                ),
            )
            self._agent_list.controls.append(tile)

    def _render_detail(self) -> None:
        """渲染 Agent 详情。"""
        agent = self._controller.state.selected_agent
        if not agent:
            self._detail_area.controls.clear()
            self._detail_area.controls.append(
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Icon(ft.Icons.TOUCH_APP, size=48, color=ft.Colors.OUTLINE),
                            ft.Text(t("agents.select_hint", default="Select an agent to view details")),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=8,
                    ),
                    alignment=ft.Alignment(0, 0),
                    expand=True,
                )
            )
            return

        self._detail_area.controls.clear()
        self._detail_area.controls.append(
            ft.Tabs(
                selected_index=0,
                expand=True,
                tabs=[
                    ft.Tab(text="Overview", content=self._build_overview_tab(agent)),
                    ft.Tab(text="Tools", content=self._build_tools_tab(agent)),
                    ft.Tab(text="Skills", content=self._build_skills_tab(agent)),
                    ft.Tab(text="Files", content=self._build_files_tab(agent)),
                ],
            )
        )

    def _build_overview_tab(self, agent) -> ft.Control:
        """构建概览标签页。"""
        return ft.ListView(
            controls=[
                ft.Text(agent.name, size=24, weight=ft.FontWeight.BOLD),
                ft.Text(agent.path, size=11, color=ft.Colors.OUTLINE),
                ft.Container(height=16),
                ft.Text(f"Model: {agent.model or 'N/A'}", size=14),
                ft.Text(f"Provider: {agent.provider or 'N/A'}", size=14),
                ft.Container(height=16),
                ft.Text("System Prompt", size=14, weight=ft.FontWeight.W_500),
                ft.Container(
                    content=ft.Text(agent.system_prompt or "No system prompt", size=12),
                    bgcolor=ft.Colors.SURFACE_CONTAINER_HIGHEST,
                    border_radius=8,
                    padding=12,
                ),
            ],
            padding=16,
            expand=True,
        )

    def _build_tools_tab(self, agent) -> ft.Control:
        """构建工具标签页。"""
        tools = agent.tools or []
        if not tools:
            return ft.Container(
                content=ft.Text("No tools configured", color=ft.Colors.OUTLINE),
                alignment=ft.Alignment(0, 0),
                padding=16,
            )

        return ft.ListView(
            controls=[
                card_tile(content=ft.Row([ft.Icon(ft.Icons.BUILD), ft.Text(t)]))
                for t in tools
            ],
            padding=16,
            expand=True,
        )

    def _build_skills_tab(self, agent) -> ft.Control:
        """构建技能标签页。"""
        skills = agent.skills or []
        if not skills:
            return ft.Container(
                content=ft.Text("No skills configured", color=ft.Colors.OUTLINE),
                alignment=ft.Alignment(0, 0),
                padding=16,
            )

        controls = []
        for s in skills:
            name = s.get("id") or s.get("name") or str(s)
            enabled = s.get("enabled", True)
            controls.append(
                card_tile(
                    content=ft.Row(
                        [
                            ft.Icon(ft.Icons.AUTO_AWESOME),
                            ft.Text(name, expand=True),
                            status_chip(
                                "enabled" if enabled else "disabled",
                                ft.Colors.GREEN if enabled else ft.Colors.GREY_400,
                            ),
                        ]
                    )
                )
            )

        return ft.ListView(controls=controls, padding=16, expand=True)

    def _build_files_tab(self, agent) -> ft.Control:
        """构建文件标签页。"""
        from pathlib import Path

        agent_path = Path(agent.path) if agent.path else None
        if not agent_path or not agent_path.is_dir():
            return ft.Container(
                content=ft.Text("Agent directory not found", color=ft.Colors.OUTLINE),
                alignment=ft.Alignment(0, 0),
                padding=16,
            )

        files = sorted(agent_path.iterdir())
        if not files:
            return ft.Container(
                content=ft.Text("No files", color=ft.Colors.OUTLINE),
                alignment=ft.Alignment(0, 0),
                padding=16,
            )

        return ft.ListView(
            controls=[
                card_tile(
                    content=ft.Row(
                        [
                            ft.Icon(
                                ft.Icons.INSERT_DRIVE_FILE
                                if f.is_file()
                                else ft.Icons.FOLDER
                            ),
                            ft.Column(
                                [
                                    ft.Text(f.name),
                                    ft.Text(
                                        f"{f.stat().st_size} B" if f.is_file() else "",
                                        size=11,
                                        color=ft.Colors.OUTLINE,
                                    ),
                                ],
                                spacing=2,
                                expand=True,
                            ),
                        ]
                    )
                )
                for f in files
            ],
            padding=16,
            expand=True,
        )
```

### 4.4 `panels/agents/local_repository.py` — 本地实现

```python
"""本地文件系统 Agent 仓库实现。"""
from __future__ import annotations
import json
from pathlib import Path
from typing import TYPE_CHECKING

from pyclaw.ui.core.repository import AgentRepository
from pyclaw.ui.core.types import Agent

if TYPE_CHECKING:
    pass


class LocalAgentRepository(AgentRepository):
    """基于本地文件系统的 Agent 仓库实现。"""

    def __init__(self, agents_dir: Path) -> None:
        self._agents_dir = agents_dir

    async def list_agents(self) -> list[Agent]:
        """扫描本地 Agent 目录。"""
        agents: list[Agent] = []
        if not self._agents_dir.is_dir():
            return agents

        for child in sorted(self._agents_dir.iterdir()):
            if child.is_dir():
                config_file = child / "agent.json"
                agent_md = child / "AGENTS.md"
                if config_file.exists() or agent_md.exists():
                    agent = self._load_agent(child)
                    if agent:
                        agents.append(agent)
        return agents

    async def get_agent(self, agent_id: str) -> Agent | None:
        """获取单个 Agent。"""
        agent_path = self._agents_dir / agent_id
        if agent_path.is_dir():
            return self._load_agent(agent_path)
        return None

    async def get_agent_tools(self, agent_id: str) -> list[str]:
        """本地无工具信息，返回空列表。"""
        return []

    async def create_agent(self, agent_data: AgentCreate) -> Agent:
        """创建新 Agent。"""
        agent_id = agent_data.name.strip().lower().replace(" ", "-")
        agent_path = self._agents_dir / agent_id
        agent_path.mkdir(parents=True, exist_ok=True)

        config = {
            "name": agent_data.name,  # 持久化 name 字段
            "model": agent_data.model,
            "provider": agent_data.provider,
            "systemPrompt": agent_data.system_prompt,
            "tools": agent_data.tools,
            "skills": agent_data.skills,
        }
        (agent_path / "agent.json").write_text(
            json.dumps(config, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

        return Agent(
            id=agent_id,
            name=agent_data.name,
            path=str(agent_path),
            model=agent_data.model,
            provider=agent_data.provider,
            system_prompt=agent_data.system_prompt,
            tools=agent_data.tools,
            skills=agent_data.skills,
        )

    async def delete_agent(self, agent_id: str) -> None:
        """删除 Agent 目录。"""
        import shutil

        agent_path = self._agents_dir / agent_id
        if agent_path.is_dir():
            shutil.rmtree(agent_path)

    def _load_agent(self, agent_path: Path) -> Agent | None:
        """从目录加载 Agent。"""
        config_file = agent_path / "agent.json"
        cfg: dict = {}

        if config_file.exists():
            try:
                cfg = json.loads(config_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass

        # name 优先使用配置中的值，其次使用目录名
        name = cfg.get("name", agent_path.name)

        return Agent.from_dict({
            "id": agent_path.name,
            "name": name,
            "path": str(agent_path),
            **cfg,
        })
```

### 4.5 `panels/agents/__init__.py` — 兼容层

```python
"""Agents 面板模块。"""
from __future__ import annotations
from pathlib import Path
from typing import Any

from pyclaw.ui.core.event_bus import EventBus
from pyclaw.ui.core.gateway_service import GatewayService
from .controller import AgentsController
from .view import AgentsView
from .local_repository import LocalAgentRepository


def build_agents_panel(
    *,
    agents_dir: str | Path | None = None,
    gateway_client: Any = None,
    event_bus: EventBus | None = None,
    **kwargs,
) -> Any:
    """构建 Agents 面板（兼容旧接口）。

    Args:
        agents_dir: Agent 目录路径
        gateway_client: 原始 Gateway 客户端
        event_bus: 事件总线（可选）

    Returns:
        AgentsView 实例
    """
    from pyclaw.config.paths import resolve_agents_dir

    # 解析目录
    effective_dir = Path(agents_dir) if agents_dir else resolve_agents_dir()

    # 创建仓库
    repo = LocalAgentRepository(effective_dir)

    # 创建控制器
    controller = AgentsController(repo, event_bus)

    # 创建视图
    return AgentsView(controller)


__all__ = [
    "AgentsController",
    "AgentsView",
    "AgentsState",
    "LocalAgentRepository",
    "build_agents_panel",
]
```

---

## 5. 组件库抽取

将现有 `components.py` 按职责拆分：

### 5.1 `components/__init__.py`

```python
"""可复用 UI 组件库。"""
from .tiles import card_tile
from .forms import slider_input, switch_with_info
from .status import status_chip, streaming_indicator
from .empty_state import empty_state, error_state, empty_state_simple
from .page_header import page_header, expandable_section

__all__ = [
    "card_tile",
    "slider_input",
    "switch_with_info",
    "status_chip",
    "streaming_indicator",
    "empty_state",
    "error_state",
    "empty_state_simple",
    "page_header",
    "expandable_section",
]
```

### 5.2 文件职责映射

| 文件 | 内容 |
|------|------|
| `tiles.py` | `card_tile`, `list_tile` — 列表项/卡片组件 |
| `forms.py` | `slider_input`, `switch_with_info` — 表单组件 |
| `status.py` | `status_chip`, `streaming_indicator` — 状态指示器 |
| `empty_state.py` | `empty_state`, `error_state`, `empty_state_simple` — 空状态/错误状态 |
| `page_header.py` | `page_header`, `expandable_section` — 页面头部/可折叠区域 |
| `media.py` | 图片/文件预览组件 |

---

## 6. 主应用简化

`app.py` 的职责简化为：

1. 初始化基础设施（EventBus、GatewayService）
2. 创建面板实例
3. 处理全局导航和布局

```python
# app.py 简化后
class PyClawApp:
    def __init__(self) -> None:
        self._event_bus = EventBus()
        self._gateway: GatewayService | None = None
        self._panels: dict[str, BasePanel] = {}
        self._current_panel: BasePanel | None = None

    async def main(self, page: ft.Page) -> None:
        # 初始化基础设施
        await self._init_gateway()
        await self._init_panels()

        # 构建布局
        self._build_shell()
        page.add(self._shell)

    async def _init_panels(self) -> None:
        """创建面板实例。"""
        from pyclaw.ui.panels.agents import AgentsController, AgentsView, LocalAgentRepository
        from pyclaw.config.paths import resolve_agents_dir

        # Agents 面板
        agents_repo = LocalAgentRepository(resolve_agents_dir())
        agents_ctrl = AgentsController(agents_repo, self._event_bus)
        self._panels["agents"] = AgentsView(agents_ctrl)

        # Sessions 面板
        # ...

    async def _navigate_to(self, panel_name: str) -> None:
        """切换面板（正确处理生命周期）。"""
        # 卸载当前面板
        if self._current_panel:
            await self._current_panel.on_unmount()

        # 挂载新面板
        new_panel = self._panels.get(panel_name)
        if new_panel:
            self._content_area.controls = [new_panel]
            self._safe_update(self._content_area)
            await new_panel.on_mount()
            self._current_panel = new_panel
```

---

## 7. 迁移策略

### 7.1 渐进迁移

1. **第一阶段**：创建 `core/` 和 `components/` 目录，实现基础设施
2. **第二阶段**：迁移一个简单面板（如 Overview）作为验证
3. **第三阶段**：迁移剩余面板，保留 `build_xxx_panel` 兼容层
4. **第四阶段**：删除旧代码，清理兼容层

### 7.2 兼容性保证

所有面板保留 `build_xxx_panel()` 函数签名：

```python
def build_xxx_panel(
    *,
    gateway_client: Any = None,
    **kwargs,
) -> ft.Column:
    """兼容旧接口的面板构建函数。"""
    # 内部使用新的 MVC 结构
    controller = XxxController(repo, event_bus)
    return XxxView(controller)
```

### 7.3 测试策略

每个面板迁移后需补充：

1. **Controller 单元测试** — 使用 Mock Repository
2. **View 渲染测试** — 验证 UI 组件正确渲染
3. **集成测试** — 验证面板与 Gateway 交互

---

## 8. 设计决策记录

| 决策点 | 最终选择 | 理由 |
|--------|----------|------|
| Reactive 订阅 | 普通列表 + 返回取消函数 | 避免弱引用失效，支持手动清理 |
| Reactive 值比较 | `is` 而非 `==` | 强制用户采用"替换快照"模式，避免可变类型漏判 |
| Computed | 暂不实现 | 避免过度设计，需要时再加 |
| 数据源抽象 | Repository 接口 | 便于测试和未来扩展（本地/远程切换） |
| create_agent 参数 | `AgentCreate` 数据类 | 解耦参数列表，便于扩展字段 |
| 跨面板通信 | EventBus + AppEvents 常量 | 解决真实场景，避免字符串拼写错误 |
| 事件数据类型 | 可选 `@dataclass` 类型标注 | 保持灵活性，提供可选类型约束 |
| 异步任务执行 | `_fire_async` 方法（简化版） | 回调中已有事件循环，无需复杂处理 |
| 内存泄漏防范 | 在 `on_unmount` 中调用取消函数 | 必须落实 |
| 面板生命周期 | `_navigate_to` 中正确处理 unmount/mount | 避免资源泄漏 |
| 组件库组织 | 按职责分文件 | 避免单文件过大，便于维护 |
| 迁移策略 | 渐进迁移 + 兼容层 | 降低风险，逐步验证 |
| Agent name 持久化 | 写入 `agent.json` | 避免重新加载时 name 退化为目录名 |
| 错误提示去重 | View 中记录 `_last_error` | 避免重复弹出 SnackBar |
| wait_connected | 使用 `asyncio.Event` | 比 sleep 轮询更高效 |

---

## 9. 验收标准

### 9.1 功能验收

- [ ] 所有现有面板功能正常
- [ ] 面板切换流畅，无卡顿
- [ ] 状态变化正确触发 UI 更新
- [ ] 跨面板事件正确传递

### 9.2 代码质量

- [ ] 单个文件不超过 300 行
- [ ] Controller 可独立单元测试
- [ ] View 不包含业务逻辑
- [ ] 无内存泄漏（取消订阅正确执行）

### 9.3 性能指标

- [ ] 面板切换响应时间 < 100ms
- [ ] 列表滚动帧率 > 30fps
- [ ] 内存占用无明显增长

---

## 附录

### A. 预定义事件列表

| 事件常量 | 事件名 | 数据类型 | 触发时机 |
|----------|--------|----------|----------|
| `AppEvents.AGENTS_CREATED` | `agents.created` | `AgentEventData` | Agent 创建成功 |
| `AppEvents.AGENTS_DELETED` | `agents.deleted` | `str` (agent_id) | Agent 删除成功 |
| `AppEvents.AGENTS_UPDATED` | `agents.updated` | `Agent` | Agent 更新成功 |
| `AppEvents.SESSIONS_CREATED` | `sessions.created` | `Session` | 会话创建成功 |
| `AppEvents.SESSIONS_DELETED` | `sessions.deleted` | `str` (session_id) | 会话删除成功 |
| `sessions.activated` | `str` (session_id) | 会话激活 |
| `gateway.connected` | `None` | Gateway 连接成功 |
| `gateway.disconnected` | `str \| None` (error) | Gateway 断开连接 |
| `config.changed` | `dict` | 配置变更 |

### B. 错误码定义

| 错误码 | 说明 | 处理建议 |
|--------|------|----------|
| `NOT_CONNECTED` | Gateway 未连接 | 显示连接提示 |
| `CALL_FAILED` | RPC 调用失败 | 显示错误信息 |
| `TIMEOUT` | 调用超时 | 提示重试 |
| `PERMISSION_DENIED` | 权限不足 | 显示权限说明 |
| `NOT_FOUND` | 资源不存在 | 刷新列表 |

