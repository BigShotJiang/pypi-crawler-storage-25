# PyClaw TypeScript 迁移设计规范

> 创建日期：2026-04-22
> 状态：已审批
> 范围：Python/Flet UI 迁移到 TypeScript 全栈架构

---

## 1. 概述

### 1.1 迁移目标

将 PyClaw 的 Web UI 从 Python/Flet 技术栈迁移到 TypeScript 全栈架构：

| 维度 | 现状 | 目标 |
|------|------|------|
| 语言 | Python 3.10+ | TypeScript 5.x |
| 框架 | Flet (Flutter wrapper) | Next.js 15 (App Router) |
| 样式 | Flet 内置 | Tailwind CSS + shadcn/ui |
| 状态 | Reactive[T] + EventBus | Zustand + TanStack Query |
| 桌面 | Flet Desktop | Tauri 2.x |
| 移动端 | Flet Mobile | Expo (React Native) |

### 1.2 迁移动机

1. **生态对齐** — TypeScript 前端生态更成熟（React/Vue 组件库、工具链）
2. **团队技能** — 团队更熟悉 TypeScript 开发
3. **性能/包体积** — 原生 Web 应用比 Flet 打包产物更小、启动更快
4. **上游对齐** — OpenClaw 上游使用 TypeScript，便于功能同步

### 1.3 设计原则

1. **跨端共享最大化** — 逻辑层（状态、API、类型）三端共用
2. **类型安全桥梁** — OpenAPI 规范自动生成 TypeScript 类型
3. **渐进式增强** — 后端 REST 适配层复用现有 Gateway methods
4. **测试分层覆盖** — 单元测试 + 集成测试 + E2E 测试金字塔

---

## 2. Monorepo 目录结构

### 2.1 整体结构

```
openclaw-py/
├── apps/
│   ├── web/                    # Next.js 15 (App Router)
│   │   ├── app/                # 路由: /chat, /agents, /sessions...
│   │   ├── components/         # Web 专用组件
│   │   ├── hooks/              # Web 专用 hooks
│   │   ├── middleware.ts       # next-themes
│   │   └── next.config.ts      # output: 'export', trailingSlash: true
│   │
│   ├── desktop/                # Tauri 2.x 壳
│   │   ├── src-tauri/          # Rust: 窗口、托盘、文件系统
│   │   ├── tauri.conf.json     # frontendDist: "../web/out"
│   │   └── package.json
│   │
│   └── mobile/                 # Expo (React Native)
│       ├── app/                # Expo Router 文件路由
│       ├── components/         # RN 专用组件
│       ├── metro.config.js     # Monorepo 支持
│       └── ios/ android/
│
├── packages/
│   ├── shared/                 # 跨端共享核心（零框架依赖）
│   │   ├── api/                # OpenAPI 客户端 + WebSocket
│   │   ├── store/              # Zustand stores
│   │   ├── types/              # 手写类型 + 枚举
│   │   ├── utils/              # env 检测、格式化
│   │   ├── i18n/               # 国际化
│   │   ├── hooks/              # useChat 等跨端 hooks
│   │   └── config/             # 导航配置等
│   │
│   ├── ui/                     # shadcn/ui + 跨端适配
│   │   ├── components/ui/      # shadcn 原始组件
│   │   ├── composite/          # 业务无关组合组件
│   │   ├── chat/               # 聊天专用组件
│   │   ├── panels/             # 业务面板
│   │   ├── adapters/rn/        # React Native 适配
│   │   ├── theme/              # 主题 tokens
│   │   └── tailwind-preset.ts
│   │
│   └── eslint-config/          # 共享 ESLint + Prettier
│
├── backend/                    # Python FastAPI
│   ├── src/pyclaw/             # 现有代码整体迁入
│   ├── openapi.json            # 自动生成
│   └── pyproject.toml          # 包名: pyclaw
│
├── turbo.json
├── pnpm-workspace.yaml
├── package.json
├── Makefile
└── README.md
```

### 2.2 关键配置

**Tauri 桌面端复用 Web 产物**：
```json
// apps/desktop/tauri.conf.json
{
  "build": {
    "frontendDist": "../web/out",
    "beforeDevCommand": "pnpm --filter @pyclaw/web dev",
    "beforeBuildCommand": "pnpm --filter @pyclaw/web build"
  }
}
```

**Expo Mobile 端支持 Monorepo**：
```js
// apps/mobile/metro.config.js
const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const config = getDefaultConfig(__dirname);

config.watchFolders = [path.resolve(__dirname, '../..')];
config.resolver.nodeModulesPaths = [
  path.resolve(__dirname, 'node_modules'),
  path.resolve(__dirname, '../../node_modules'),
];

module.exports = config;
```

---

## 3. API 层架构

### 3.1 REST API + WebSocket 双通道

```
┌─────────────────────────────────────────────────────────────┐
│                      Frontend (TS)                           │
├─────────────────────────────────────────────────────────────┤
│  packages/shared/api/                                        │
│  ┌────────────────────┐    ┌───────────────────────────┐   │
│  │  REST Client        │    │  WebSocket Gateway        │   │
│  │  (openapi-fetch)    │    │  (实时推送 + 流式响应)      │   │
│  │                     │    │                           │   │
│  │  • agents.list      │    │  • chat.send (流式)        │   │
│  │  • sessions.list    │    │  • events.subscribe        │   │
│  │  • config.get/patch │    │  • 实时日志推送             │   │
│  └─────────┬──────────┘    └─────────────┬─────────────┘   │
└────────────┼─────────────────────────────────┼──────────────┘
             │ HTTP (REST)                     │ WebSocket
             ▼                                 ▼
┌─────────────────────────────────────────────────────────────┐
│                      Backend (Python)                        │
├─────────────────────────────────────────────────────────────┤
│  FastAPI Router                    Gateway (WebSocket v3)   │
│  /api/v1/...                       ws://gateway:8765       │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 REST 端点映射

| 现有 RPC 方法 | REST 端点 | 方法 |
|--------------|-----------|------|
| `agents.list` | `/api/v1/agents` | GET |
| `agents.get` | `/api/v1/agents/:id` | GET |
| `agents.create` | `/api/v1/agents` | POST |
| `agents.delete` | `/api/v1/agents/:id` | DELETE |
| `sessions.list` | `/api/v1/sessions` | GET |
| `sessions.preview` | `/api/v1/sessions/:id/messages` | GET |
| `config.get` | `/api/v1/config` | GET |
| `config.patch` | `/api/v1/config` | PATCH |
| `channels.list` | `/api/v1/channels` | GET |
| `channels.test` | `/api/v1/channels/:id/test` | POST |
| `skills.list` | `/api/v1/skills` | GET |
| `skills.reload` | `/api/v1/skills/reload` | POST |

### 3.3 WebSocket 保留场景

- 聊天流式响应（`chat.send` + SSE 事件）
- 工具调用通知（`tool.start` / `tool.end`）
- 日志实时推送（`logs.tail`）
- 任务进度（`progress` 事件）

### 3.4 前端 API 客户端

```typescript
// packages/shared/api/client.ts
import createClient from 'openapi-fetch';
import type { paths } from './schema';
import { getApiBaseUrl } from '../utils/env';

export const apiClient = createClient<paths>({
  baseUrl: getApiBaseUrl(),
  headers: { 'Content-Type': 'application/json' },
});

export const agentsApi = {
  list: () => apiClient.GET('/api/v1/agents'),
  get: (id: string) => apiClient.GET('/api/v1/agents/{id}', { params: { path: { id } } }),
  create: (body) => apiClient.POST('/api/v1/agents', { body }),
  delete: (id: string) => apiClient.DELETE('/api/v1/agents/{id}', { params: { path: { id } } }),
};
```

### 3.5 WebSocket 客户端

```typescript
// packages/shared/api/websocket.ts
import { useCallback, useEffect, useRef, useState } from 'react';
import { getWebSocketUrl } from '../utils/env';
import { generateId } from '../utils/uuid';

interface PendingCall {
  resolve: (value: unknown) => void;
  reject: (error: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

interface WebSocketOptions {
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Error) => void;
  onEvent?: (event: string, data: unknown) => void;
  reconnectAttempts?: number;
  reconnectInterval?: number;
  callTimeout?: number;
}

export function useGatewayWebSocket(options: WebSocketOptions = {}) {
  const {
    reconnectAttempts = 5,
    reconnectInterval = 1000,
    callTimeout = 30000,
  } = options;

  const [connected, setConnected] = useState(false);
  const [connectionState, setConnectionState] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectCount = useRef(0);
  const pendingCalls = useRef<Map<string, PendingCall>>(new Map());

  // 中心化消息分发：RPC 响应 + 服务器推送事件
  const handleMessage = useCallback((event: MessageEvent) => {
    const msg = JSON.parse(event.data);
    if (msg.id && pendingCalls.current.has(msg.id)) {
      const { resolve, reject, timer } = pendingCalls.current.get(msg.id)!;
      clearTimeout(timer);
      pendingCalls.current.delete(msg.id);
      if (msg.error) reject(new Error(msg.error.message));
      else resolve(msg.result);
      return;
    }
    if (msg.type === 'event') options.onEvent?.(msg.event, msg.data);
  }, []);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    setConnectionState('connecting');
    const ws = new WebSocket(getWebSocketUrl());
    wsRef.current = ws;

    ws.onopen = () => {
      setConnected(true);
      setConnectionState('connected');
      reconnectCount.current = 0;
      options.onOpen?.();
    };
    ws.onclose = () => {
      setConnected(false);
      setConnectionState('disconnected');
      options.onClose?.();
      if (reconnectCount.current < reconnectAttempts) {
        reconnectCount.current++;
        setTimeout(connect, reconnectInterval * reconnectCount.current);
      }
    };
    ws.onmessage = handleMessage;
  }, [options, reconnectAttempts, reconnectInterval]);

  // RPC 调用（带超时 + 中心化分发）
  const call = useCallback(<T,>(method: string, params: Record<string, unknown>): Promise<T> => {
    return new Promise((resolve, reject) => {
      const ws = wsRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        reject(new Error('WebSocket not connected'));
        return;
      }
      const id = generateId();
      const timer = setTimeout(() => {
        pendingCalls.current.delete(id);
        reject(new Error(`RPC call '${method}' timeout after ${callTimeout}ms`));
      }, callTimeout);
      pendingCalls.current.set(id, { resolve: resolve as (v: unknown) => void, reject, timer });
      ws.send(JSON.stringify({ id, method, params }));
    });
  }, [callTimeout]);

  // 流式聊天（特殊处理，监听 callId 关联的 delta/done/error 事件）
  const streamChat = useCallback((
    sessionId: string,
    message: string,
    onDelta: (delta: string) => void,
    onToolStart?: (name: string, toolId: string) => void,
    onToolEnd?: (name: string, result: unknown, error?: string) => void,
  ): Promise<void> => {
    return new Promise((resolve, reject) => {
      const ws = wsRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        reject(new Error('WebSocket not connected'));
        return;
      }
      const callId = generateId();
      const handler = (event: MessageEvent) => {
        const msg = JSON.parse(event.data);
        if (msg.callId !== callId) return;
        if (msg.type === 'delta') onDelta(msg.delta);
        else if (msg.type === 'tool_start') onToolStart?.(msg.name, msg.toolId);
        else if (msg.type === 'tool_end') onToolEnd?.(msg.name, msg.result, msg.error);
        else if (msg.type === 'done') { ws?.removeEventListener('message', handler); resolve(); }
        else if (msg.type === 'error') { ws?.removeEventListener('message', handler); reject(new Error(msg.error)); }
      };
      ws.addEventListener('message', handler);
      ws.send(JSON.stringify({ id: callId, method: 'chat.send', params: { sessionId, message } }));
    });
  }, []);

  return { connected, connectionState, connect, call, streamChat };
}
```

### 3.6 后端 REST 适配层

```python
# backend/src/pyclaw/gateway/rest/agents.py
from fastapi import APIRouter, HTTPException, status
from typing import List
from .models.agent import AgentResponse, AgentCreate
from ..methods.agents import handle_list, handle_get, handle_create, handle_delete

router = APIRouter()

@router.get("/", response_model=List[AgentResponse])
async def list_agents():
    result = await handle_list({})
    return result.get("agents", [])

@router.get("/{agent_id}", response_model=AgentResponse)
async def get_agent(agent_id: str):
    result = await handle_get({"agentId": agent_id})
    if not result:
        raise HTTPException(status_code=404, detail="Agent not found")
    return result

@router.post("/", response_model=AgentResponse, status_code=201)
async def create_agent(body: AgentCreate):
    return await handle_create(body.model_dump(by_alias=True))
```

---

## 4. 状态管理架构

### 4.1 状态分层

```
Server State (TanStack Query)  →  来自 REST API 的数据，自动缓存、刷新
        ↓
Client State (Zustand)         →  UI 状态、选中项、连接状态
        ↓
Local UI State (useState)      →  表单输入、对话框状态
```

### 4.2 TanStack Query Hooks

```typescript
// packages/shared/api/hooks.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export const queryKeys = {
  agents: {
    all: ['agents'] as const,
    list: () => [...queryKeys.agents.all, 'list'] as const,
    detail: (id: string) => [...queryKeys.agents.all, 'detail', id] as const,
  },
  sessions: {
    all: ['sessions'] as const,
    list: () => [...queryKeys.sessions.all, 'list'] as const,
  },
};

export function useAgentsList() {
  return useQuery({
    queryKey: queryKeys.agents.list(),
    queryFn: async () => {
      const { data, error } = await agentsApi.list();
      if (error) throw new Error(error.message);
      return data;
    },
    staleTime: 30_000,
  });
}

export function useCreateAgent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: agentsApi.create,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.agents.list() }),
  });
}
```

### 4.3 Zustand Stores

```typescript
// packages/shared/store/index.ts
import { create } from 'zustand';

interface AppState {
  gatewayConnected: boolean;
  gatewayState: 'connecting' | 'connected' | 'disconnected';
  setGatewayState: (state: 'connecting' | 'connected' | 'disconnected') => void;
  
  currentSessionId: string | null;
  setCurrentSession: (id: string | null) => void;
  
  selectedAgentId: string | null;
  setSelectedAgent: (id: string | null) => void;
  
  sidebarOpen: boolean;
  toggleSidebar: () => void;
}

export const useAppStore = create<AppState>()((set) => ({
  gatewayConnected: false,
  gatewayState: 'disconnected',
  setGatewayState: (state) => set({ gatewayState: state, gatewayConnected: state === 'connected' }),
  currentSessionId: null,
  setCurrentSession: (id) => set({ currentSessionId: id }),
  selectedAgentId: null,
  setSelectedAgent: (id) => set({ selectedAgentId: id }),
  sidebarOpen: true,
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
}));
```

### 4.4 ChatStore

```typescript
// packages/shared/types/chat.ts
export interface ToolCallInfo {
  id: string;
  name: string;
  status: 'running' | 'completed' | 'error';
  result?: unknown;
  error?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  toolCalls?: ToolCallInfo[];
}

// packages/shared/store/chat.ts
import { create } from 'zustand';
import { generateId } from '../utils/uuid';
import type { ChatMessage, ToolCallInfo } from '../types/chat';

interface ChatState {
  messages: ChatMessage[];
  isStreaming: boolean;
  streamingContent: string;
  streamingToolCalls: ToolCallInfo[];
  
  addUserMessage: (content: string) => void;
  startAssistantStream: () => void;
  appendDelta: (delta: string) => void;
  addToolCall: (toolCall: ToolCallInfo) => void;
  updateToolCall: (id: string, update: Partial<ToolCallInfo>) => void;
  finishStream: () => void;
  finishStreamWithError: (error: string) => void;
  clearMessages: () => void;
}

export const useChatStore = create<ChatState>((set) => ({
  messages: [],
  isStreaming: false,
  streamingContent: '',
  streamingToolCalls: [],
  
  addUserMessage: (content) => set((s) => ({
    messages: [...s.messages, { id: generateId(), role: 'user', content, timestamp: Date.now() }]
  })),
  
  startAssistantStream: () => set({ isStreaming: true, streamingContent: '', streamingToolCalls: [] }),
  appendDelta: (delta) => set((s) => ({ streamingContent: s.streamingContent + delta })),
  
  finishStream: () => set((s) => ({
    isStreaming: false,
    messages: [...s.messages, {
      id: generateId(),
      role: 'assistant',
      content: s.streamingContent,
      timestamp: Date.now(),
      toolCalls: s.streamingToolCalls.length > 0 ? s.streamingToolCalls : undefined,
    }],
    streamingContent: '',
    streamingToolCalls: [],
  })),
  
  clearMessages: () => set({ messages: [], streamingContent: '', streamingToolCalls: [] }),
}));
```

### 4.5 跨端持久化

```typescript
// packages/shared/utils/storage.ts
import { platform } from './env';

interface StorageAdapter {
  getItem: (name: string) => string | null | Promise<string | null>;
  setItem: (name: string, value: string) => void | Promise<void>;
  removeItem: (name: string) => void | Promise<void>;
}

export async function getStorage(): Promise<StorageAdapter> {
  if (platform.isTauri) {
    const { Store } = await import('@tauri-apps/plugin-store');
    const store = await Store.load('pyclaw-state.json');
    return {
      getItem: (name) => store.get(name) as Promise<string | null>,
      setItem: (name, value) => store.set(name, value),
      removeItem: (name) => store.delete(name),
    };
  }
  if (platform.isReactNative) {
    const AsyncStorage = await import('@react-native-async-storage/async-storage');
    return AsyncStorage;
  }
  return {
    getItem: (name) => localStorage.getItem(name),
    setItem: (name, value) => localStorage.setItem(name, value),
    removeItem: (name) => localStorage.removeItem(name),
  };
}

// packages/shared/store/persist.ts
import { getStorage } from '../utils/storage';
import { useAppStore } from './index';

const PERSIST_KEY = 'pyclaw-app-state';

export async function loadPersistedState(): Promise<void> {
  const storage = await getStorage();
  const saved = await storage.getItem(PERSIST_KEY);
  if (saved) {
    useAppStore.setState(JSON.parse(saved));
  }
}

export function setupPersistence(): void {
  useAppStore.subscribe((state) => {
    const partial = { sidebarOpen: state.sidebarOpen };
    getStorage().then(storage => storage.setItem(PERSIST_KEY, JSON.stringify(partial)));
  });
}
```

---

## 5. UI 组件库与面板架构

### 5.1 组件分层

```
页面组件 (apps/web/app/)          → 路由级别
    ↓
业务面板 (packages/ui/panels/)    → 组合基础组件，消费 store
    ↓
基础组件 (packages/ui/components/) → shadcn/ui + 扩展
```

### 5.2 基础组件结构

```typescript
// packages/ui/
├── components/ui/          # shadcn/ui 原始组件
│   ├── button.tsx
│   ├── card.tsx
│   ├── dialog.tsx
│   └── ...
│
├── composite/              # 业务无关组合组件
│   ├── empty-state.tsx
│   ├── error-state.tsx
│   ├── page-header.tsx
│   ├── streaming-text.tsx
│   └── status-chip.tsx
│
├── chat/                   # 聊天专用组件
│   ├── message-bubble.tsx
│   ├── tool-call-card.tsx
│   ├── markdown-renderer.tsx
│   └── chat-input.tsx
│
└── adapters/rn/            # React Native 适配
    ├── button.tsx
    ├── card.tsx
    └── markdown-renderer.tsx
```

### 5.3 面板路由映射（13 个独立路由）

| 面板 | 路由 | 复杂度 |
|------|------|--------|
| ChatPanel | `/chat` | 高 |
| SessionsPanel | `/sessions` | 中 |
| AgentsPanel | `/agents/[id]` | 中 |
| DashboardPanel | `/dashboard` | 中 |
| SettingsPanel | `/settings` | 中 |
| ChannelsPanel | `/channels` | 低 |
| InboxPanel | `/inbox` | 中 |
| InstancesPanel | `/instances` | 低 |
| CronPanel | `/cron` | 低 |
| SkillsPanel | `/skills` | 低 |
| NodesPanel | `/nodes` | 低 |
| VoicePanel | `/voice` | 低 |
| LogsPanel | `/logs` | 中 |

### 5.4 面板示例：AgentsPanel

```typescript
// packages/ui/panels/agents/index.tsx
'use client';

import { useRouter } from 'next/navigation';
import { useAgentsList, useAgentDetail, useDeleteAgent } from '@pyclaw/shared/api/hooks';
import { PageHeader } from '../../composite/page-header';
import { EmptyState } from '../../composite/empty-state';
import { AgentList } from './agent-list';
import { AgentDetail } from './agent-detail';

interface AgentsPanelProps {
  selectedId?: string;
}

export function AgentsPanel({ selectedId }: AgentsPanelProps) {
  const router = useRouter();
  const { data: agents, isLoading, refetch } = useAgentsList();
  const { data: selectedAgent } = useAgentDetail(selectedId ?? '');
  const deleteAgent = useDeleteAgent();

  const handleSelect = (id: string) => router.push(`/agents/${id}`);

  return (
    <div className="flex h-full flex-col">
      <PageHeader title="Agents" /* ... */ />
      <div className="flex flex-1 overflow-hidden">
        <div className="w-64 border-r">
          <AgentList agents={agents} selectedId={selectedId} onSelect={handleSelect} />
        </div>
        <div className="flex-1 overflow-auto">
          {selectedAgent ? <AgentDetail agent={selectedAgent} /> : <EmptyState />}
        </div>
      </div>
    </div>
  );
}
```

### 5.5 主题管理

使用 `next-themes` 管理主题切换，避免 SSR 闪烁：

```typescript
// apps/web/app/layout.tsx
import { ThemeProvider } from 'next-themes';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { loadPersistedState, setupPersistence } from '@pyclaw/shared/store/persist';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 2, refetchOnWindowFocus: false },
    mutations: { onError: (error) => console.error('Mutation error:', error) },
  },
});

export default function RootLayout({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    loadPersistedState().then(() => setupPersistence());
  }, []);

  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <QueryClientProvider client={queryClient}>
          <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
            <Shell>{children}</Shell>
          </ThemeProvider>
        </QueryClientProvider>
      </body>
    </html>
  );
}
```

### 5.6 Tailwind 预设共享

```typescript
// packages/ui/tailwind-preset.ts
import type { Config } from 'tailwindcss';

const preset: Config = {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        border: 'hsl(var(--border))',
        primary: { DEFAULT: 'hsl(var(--primary))', foreground: 'hsl(var(--primary-foreground))' },
        // ...
      },
      borderRadius: { lg: 'var(--radius)', md: 'calc(var(--radius) - 2px)' },
    },
  },
};

export default preset;
```

---

## 6. 测试策略

### 6.1 测试金字塔

```
        E2E Tests (Playwright)
       Integration Tests (MSW)
      Unit Tests (Vitest + pytest)
```

### 6.2 测试目录结构

```
├── backend/tests/
│   ├── unit/
│   ├── integration/
│   └── conftest.py
│
├── packages/shared/__tests__/
│   ├── store/
│   └── api/
│
├── apps/web/__tests__/
│   ├── unit/
│   ├── integration/
│   └── e2e/
│
├── vitest.config.ts
├── vitest.workspace.ts
└── playwright.config.ts
```

### 6.3 前端单元测试

```typescript
// packages/shared/__tests__/store/chatStore.test.ts
import { describe, it, expect, beforeEach } from 'vitest';
import { useChatStore } from '../../src/store';

describe('ChatStore', () => {
  beforeEach(() => {
    useChatStore.setState({ messages: [], isStreaming: false, streamingContent: '' });
  });

  it('should add user message', () => {
    useChatStore.getState().addUserMessage('Hello');
    expect(useChatStore.getState().messages).toHaveLength(1);
  });

  it('should handle streaming', () => {
    const store = useChatStore.getState();
    store.startAssistantStream();
    store.appendDelta('Hi');
    store.finishStream();
    expect(useChatStore.getState().messages[0].content).toBe('Hi');
  });
});
```

### 6.4 API 集成测试

```typescript
// apps/web/__tests__/integration/agents-panel.test.tsx
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AgentsPanel } from '@pyclaw/ui/panels/agents';

const server = setupServer(
  http.get('/api/v1/agents', () => HttpResponse.json([{ id: 'a1', name: 'Test' }])),
);

beforeAll(() => server.listen());
afterAll(() => server.close());

it('renders agent list', async () => {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  render(<QueryClientProvider client={queryClient}><AgentsPanel /></QueryClientProvider>);
  await waitFor(() => expect(screen.getByText('Test')).toBeDefined());
});
```

### 6.5 E2E 测试

```typescript
// apps/web/__tests__/e2e/chat.spec.ts
import { test, expect } from '@playwright/test';

test('should send message and receive response', async ({ page }) => {
  await page.goto('/chat');
  await page.getByPlaceholder(/type a message/i).fill('Hello');
  await page.getByRole('button', { name: /send/i }).click();
  await expect(page.getByText('Hello')).toBeVisible();
});
```

### 6.6 后端测试

```python
# backend/tests/integration/test_rest_api.py
import pytest
from httpx import AsyncClient

@pytest.mark.asyncio
async def test_list_agents(client: AsyncClient):
    response = await client.get("/api/v1/agents")
    assert response.status_code == 200
```

### 6.7 覆盖率目标

| 层级 | 目标 |
|------|------|
| Shared Store | 90%+ |
| Shared Utils | 95%+ |
| UI Components | 70%+ |
| Backend Methods | 85%+ |
| REST API | 90%+ |

---

## 7. 迁移实施计划

### 7.1 阶段划分

| 阶段 | 内容 | 周期 |
|------|------|------|
| **Phase 1** | Monorepo 脚手架 + 后端 REST 适配 + OpenAPI 生成 | 1 周 |
| **Phase 2** | packages/shared（API 客户端、Store、Utils） | 1 周 |
| **Phase 3** | packages/ui（基础组件 + 5 个核心面板） | 2 周 |
| **Phase 4** | apps/web（完整 Next.js 应用 + 剩余面板） | 2 周 |
| **Phase 5** | apps/desktop（Tauri 壳） | 1 周 |
| **Phase 6** | apps/mobile（Expo + RN 适配） | 2 周 |
| **Phase 7** | 测试补全 + CI/CD + 文档 | 1 周 |

### 7.2 里程碑验收标准

- **Phase 3 完成**：Agents/Sessions/Chat/Dashboard/Settings 五个核心面板可正常运行
- **Phase 4 完成**：13 个面板全部迁移，功能对齐原 Flet 版本
- **Phase 6 完成**：Web + Desktop + Mobile 三端可用

---

## 8. 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| WebSocket 流式协议适配复杂 | 高 | 保留现有 Gateway WebSocket 实现，仅前端重写客户端 |
| React Native 组件适配工作量大 | 中 | 按需实现，复杂组件使用条件渲染 |
| 移动端后台 WebSocket 限制 | 中 | 自动重连 + 状态恢复机制 |
| 团队 TypeScript 学习曲线 | 低 | 渐进式迁移，保留 Python 后端 |

### 8.2 实施前需明确的细节风险

#### 8.2.1 WebSocket 协议细节对齐

前端 `streamChat` 方法假设后端推送以下事件格式：

```typescript
{ callId: string, type: 'delta' | 'tool_start' | 'tool_end' | 'done' | 'error', ... }
```

**验证点**：Phase 1 需确认现有 `gateway/methods/chat.py` 是否已支持此事件结构。若不支持，需在 WebSocket handler 中增加事件推送逻辑，并定义明确的 JSON Schema。

**行动项**：
- [ ] 检查 `gateway_client.py` 中 `_handle_event` 的现有事件类型
- [ ] 若缺失，在 `chat.send` RPC 中添加 `delta`/`tool_start`/`tool_end` 事件推送

#### 8.2.2 移动端 Markdown 渲染一致性

Web 端使用 `react-markdown`，RN 需使用 `react-native-markdown-display` 或类似库。

**风险**：代码块语法高亮、表格、流式追加的渲染表现可能不一致。

**缓解策略**：
- `ChatStore` 存储原始 Markdown 字符串，由各端自行渲染
- Phase 6 开始前验证 RN markdown 库对流式追加的支持
- 必要时简化 Markdown 特性（如禁用复杂表格）

#### 8.2.3 Tauri 静态导出兼容性

Next.js `output: 'export'` 禁用动态功能，但客户端路由仍可工作。

**注意**：`trailingSlash` 配置影响刷新后 404 问题。

**配置建议**：
```typescript
// apps/web/next.config.ts
const config = {
  output: 'export',
  trailingSlash: true,  // 确保 /agents/1 刷新后正确解析
  images: { unoptimized: true },  // 静态导出不支持 next/image 优化
};
```

#### 8.2.4 跨端持久化异步初始化闪烁

`loadPersistedState` 在 `useEffect` 中异步加载，可能导致：
- 侧边栏展开状态先显示默认值，随后变为保存值
- 短暂 UI 闪烁

**缓解方案**：
- **Web 端**：利用 `localStorage` 同步特性，在 store 创建时直接读取
- **Tauri/RN 端**：在 splash screen 期间完成加载，或接受轻微闪烁

```typescript
// Web 端同步初始化示例
const savedState = typeof window !== 'undefined'
  ? JSON.parse(localStorage.getItem('pyclaw-app-state') || '{}')
  : {};

export const useAppStore = create<AppState>()((set) => ({
  sidebarOpen: savedState.sidebarOpen ?? true,
  // ...
}));
```

#### 8.2.5 环境变量与构建配置

`getApiBaseUrl()` 和 `getWebSocketUrl()` 的默认值策略：

```typescript
// packages/shared/utils/env.ts
export function getApiBaseUrl(): string {
  // 1. 优先使用环境变量
  if (process.env.NEXT_PUBLIC_API_URL) return process.env.NEXT_PUBLIC_API_URL;

  // 2. 平台默认值
  if (platform.isTauri) return 'http://localhost:8765';  // 本地 Gateway
  if (platform.isReactNative) {
    // Expo 开发环境使用电脑 IP
    return process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8765';
  }

  // 3. Web 端：开发环境用 localhost，生产环境用相对路径（需反向代理）
  return process.env.NODE_ENV === 'development'
    ? 'http://localhost:8765'
    : '';  // 相对路径，由 nginx 代理
}

export function getWebSocketUrl(): string {
  const baseUrl = getApiBaseUrl();
  return baseUrl.replace(/^http/, 'ws') + '/ws';
}
```

**部署配置**：
| 环境 | API URL | 说明 |
|------|---------|------|
| Web (dev) | `http://localhost:8765` | 本地开发 |
| Web (prod) | `/` (相对路径) | Nginx 反向代理 |
| Tauri | `http://localhost:8765` | 本地 Gateway 进程 |
| Expo (dev) | `http://<电脑IP>:8765` | 局域网访问 |
| Expo (prod) | `https://api.pyclaw.com` | 生产域名 |

#### 8.2.6 错误处理与用户反馈

当前 API 客户端错误处理较简略（`onError: console.error`）。

**增强方案**：封装全局错误处理，统一转为 Toast 提示。

```typescript
// packages/shared/api/client.ts
import { toast } from 'sonner';

export const apiClient = createClient<paths>({
  baseUrl: getApiBaseUrl(),
  headers: { 'Content-Type': 'application/json' },
  onError: (error) => {
    const message = error.message || 'Request failed';
    toast.error(message);
    console.error('[API Error]', error);
  },
});
```

**UI 集成**：
```typescript
// apps/web/app/layout.tsx
import { Toaster } from 'sonner';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        {children}
        <Toaster position="bottom-right" richColors />
      </body>
    </html>
  );
}
```

---

## 9. 附录

### A. 技术栈清单

| 类别 | 技术 |
|------|------|
| 前端框架 | Next.js 15 + TypeScript |
| 样式 | Tailwind CSS |
| 组件库 | shadcn/ui |
| 状态管理 | Zustand + TanStack Query |
| 表单 | React Hook Form + Zod |
| 桌面壳 | Tauri 2.x |
| 移动端 | Expo (React Native) |
| 后端 | Python + FastAPI |
| 接口契约 | OpenAPI + TypeScript 类型生成 |
| 测试 | Vitest + Playwright + pytest |
| 工程化 | pnpm + Turborepo |
