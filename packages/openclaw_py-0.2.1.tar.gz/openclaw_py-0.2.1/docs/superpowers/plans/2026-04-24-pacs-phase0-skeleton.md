# PACS Phase 0: 骨架实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 构建 PACS 核心骨架——EventBus + AgenticCapability 基类 + Hook 定义 + 类型系统，使其可注册、可触发、可测试。

**Architecture:** 事件驱动能力系统。`AgentEventBus` 管理能力注册与事件分发，`AgenticCapability` ABC 定义能力契约，`HookPoint` 枚举定义 12 个生命周期钩子，`HookEvent`/`AgentContext`/`CapabilityResult` 定义数据流。

**Tech Stack:** Python 3.10+, asyncio, dataclasses, pytest + pytest-asyncio

---

## File Structure

```
src/pyclaw/agents/pacs/
├── __init__.py          # 包导出
├── types.py             # HookPoint, CapabilityLayer, CapabilityAction, HookEvent, AgentContext, CapabilityResult
├── capability.py        # AgenticCapability ABC
├── bus.py               # AgentEventBus
└── compat.py            # CapabilityType 扩展

tests/pyclaw/agents/pacs/
├── __init__.py
├── test_types.py         # 类型系统测试
├── test_capability.py    # 基类测试
└── test_bus.py           # EventBus 测试
```

---

### Task 1: 创建 pacs 包和类型定义

**Files:**
- Create: `src/pyclaw/agents/pacs/__init__.py`
- Create: `src/pyclaw/agents/pacs/types.py`
- Create: `tests/pyclaw/agents/pacs/__init__.py`
- Create: `tests/pyclaw/agents/pacs/test_types.py`

- [ ] **Step 1: 创建包目录和 `__init__.py` 文件**

```bash
mkdir -p src/pyclaw/agents/pacs
mkdir -p tests/pyclaw/agents/pacs
```

创建 `src/pyclaw/agents/pacs/__init__.py`:
```python
"""PACS — PyClaw Agentic Capability Stack.

Event-driven, plugin-based capability system for agentic patterns.
"""

from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

__all__ = [
    "AgentContext",
    "CapabilityAction",
    "CapabilityLayer",
    "CapabilityResult",
    "HookEvent",
    "HookPoint",
]
```

创建 `tests/pyclaw/agents/pacs/__init__.py`:
```python
```

- [ ] **Step 2: 编写类型系统测试**

创建 `tests/pyclaw/agents/pacs/test_types.py`:
```python
"""Tests for PACS types: HookPoint, CapabilityLayer, CapabilityAction, HookEvent, AgentContext, CapabilityResult."""

from __future__ import annotations

import time

import pytest

from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)
from pyclaw.agents.types import ToolCall, ToolResult


class TestHookPoint:
    def test_all_hooks_defined(self):
        expected = {
            "session.init", "session.end",
            "turn.start", "turn.end",
            "perception.pre", "perception.observation",
            "llm.pre_invoke", "llm.post_response", "llm.error",
            "tool.pre_execute", "tool.execution", "tool.post_execute", "tool.error",
        }
        actual = {h.value for h in HookPoint}
        assert actual == expected

    def test_hook_is_string_enum(self):
        assert HookPoint.SESSION_INIT == "session.init"
        assert isinstance(HookPoint.SESSION_INIT, str)


class TestCapabilityLayer:
    def test_all_layers_defined(self):
        expected = {"perception", "reasoning", "action", "feedback", "infrastructure"}
        actual = {l.value for l in CapabilityLayer}
        assert actual == expected


class TestCapabilityAction:
    def test_all_actions_defined(self):
        expected = {"continue", "skip", "retry", "abort"}
        actual = {a.value for a in CapabilityAction}
        assert actual == expected


class TestHookEvent:
    def test_minimal_event(self):
        event = HookEvent(hook=HookPoint.TURN_START, timestamp=0.0)
        assert event.hook == HookPoint.TURN_START
        assert event.messages is None
        assert event.tool_call is None
        assert event.error is None

    def test_event_with_tool_call(self):
        tc = ToolCall(id="tc1", name="search", arguments={"q": "test"})
        event = HookEvent(
            hook=HookPoint.TOOL_PRE_EXECUTE,
            timestamp=0.0,
            tool_call=tc,
            session_id="sess-1",
            turn=3,
        )
        assert event.tool_call.name == "search"
        assert event.session_id == "sess-1"
        assert event.turn == 3

    def test_error_event(self):
        event = HookEvent(
            hook=HookPoint.TOOL_ERROR,
            timestamp=0.0,
            error=TimeoutError("tool timed out"),
            error_type="timeout",
        )
        assert isinstance(event.error, TimeoutError)
        assert event.error_type == "timeout"


class TestAgentContext:
    def test_default_context(self):
        ctx = AgentContext(session_id="test")
        assert ctx.session_id == "test"
        assert ctx.task_complexity == 0.0
        assert ctx.current_phase == "perception"
        assert ctx.active_plan is None
        assert ctx.capability_state == {}

    def test_set_and_get_capability_state(self):
        ctx = AgentContext(session_id="test")
        ctx.set("key1", "value1")
        assert ctx.get("key1") == "value1"
        assert ctx.get("nonexistent", "default") == "default"

    def test_apply_modifications_writes_mutable_attrs(self):
        ctx = AgentContext(session_id="test")
        ctx.apply_modifications({
            "task_complexity": 0.8,
            "current_phase": "reasoning",
            "active_plan": {"steps": ["a", "b"]},
        })
        assert ctx.task_complexity == 0.8
        assert ctx.current_phase == "reasoning"
        assert ctx.active_plan == {"steps": ["a", "b"]}

    def test_apply_modifications_writes_capability_state(self):
        ctx = AgentContext(session_id="test")
        ctx.apply_modifications({
            "custom_flag": True,
            "retry_count": 2,
        })
        assert ctx.capability_state["custom_flag"] is True
        assert ctx.capability_state["retry_count"] == 2
        # Should NOT create attributes on ctx
        assert not hasattr(ctx, "custom_flag")

    def test_apply_modifications_mixed(self):
        ctx = AgentContext(session_id="test")
        ctx.apply_modifications({
            "task_complexity": 0.5,
            "my_data": [1, 2, 3],
        })
        assert ctx.task_complexity == 0.5
        assert ctx.capability_state["my_data"] == [1, 2, 3]


class TestCapabilityResult:
    def test_default_result(self):
        result = CapabilityResult()
        assert result.action == CapabilityAction.CONTINUE
        assert result.event_modifications == {}
        assert result.context_modifications == {}
        assert result.output is None

    def test_skip_result(self):
        result = CapabilityResult(action=CapabilityAction.SKIP)
        assert result.action == CapabilityAction.SKIP

    def test_result_with_modifications(self):
        result = CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={"task_complexity": 0.9},
            output="plan data",
            output_type="plan",
        )
        assert result.context_modifications["task_complexity"] == 0.9
        assert result.output_type == "plan"
```

- [ ] **Step 3: 运行测试确认失败**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_types.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'pyclaw.agents.pacs'`

- [ ] **Step 4: 实现类型系统**

创建 `src/pyclaw/agents/pacs/types.py`:
```python
"""PACS core types — HookPoint, CapabilityLayer, CapabilityAction, HookEvent, AgentContext, CapabilityResult."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class HookPoint(str, Enum):
    """Agent lifecycle hook points."""

    SESSION_INIT = "session.init"
    SESSION_END = "session.end"

    TURN_START = "turn.start"
    TURN_END = "turn.end"

    PERCEPTION_PRE = "perception.pre"
    PERCEPTION_OBSERVATION = "perception.observation"

    LLM_PRE_INVOKE = "llm.pre_invoke"
    LLM_POST_RESPONSE = "llm.post_response"
    LLM_ERROR = "llm.error"

    TOOL_PRE_EXECUTE = "tool.pre_execute"
    TOOL_EXECUTION = "tool.execution"
    TOOL_POST_EXECUTE = "tool.post_execute"
    TOOL_ERROR = "tool.error"


class CapabilityLayer(str, Enum):
    """Capability logical layer for grouping and display."""

    PERCEPTION = "perception"
    REASONING = "reasoning"
    ACTION = "action"
    FEEDBACK = "feedback"
    INFRASTRUCTURE = "infrastructure"


class CapabilityAction(str, Enum):
    """Capability return action signal."""

    CONTINUE = "continue"
    SKIP = "skip"
    RETRY = "retry"
    ABORT = "abort"


@dataclass
class HookEvent:
    """Event payload for the capability system."""

    hook: HookPoint
    timestamp: float

    # Mutable data — capabilities may modify
    messages: list[dict] | None = None
    tool_call: Any | None = None
    tool_result: Any | None = None
    llm_response: dict | None = None
    context_modifications: dict[str, Any] | None = None

    # Read-only metadata
    turn: int = 0
    session_id: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    # Error flow
    error: Exception | None = None
    error_type: str | None = None


@dataclass
class AgentContext:
    """Session-scoped shared context for capabilities."""

    session_id: str
    user_id: str | None = None
    workspace: Path | None = None

    # Mutable task state
    task_complexity: float = 0.0
    current_phase: str = "perception"
    active_plan: dict | None = None

    # Memory slots
    short_term_memory: dict[str, Any] = field(default_factory=dict)
    working_memory: list[dict] = field(default_factory=list)
    long_term_memory_refs: list[str] = field(default_factory=list)

    # Capability communication slot
    capability_state: dict[str, Any] = field(default_factory=dict)

    # Read-only config
    agent_definition: Any | None = None
    model_config: Any | None = None

    _MUTABLE_ATTRS: ClassVar = frozenset({
        "task_complexity", "current_phase", "active_plan",
        "short_term_memory", "working_memory", "long_term_memory_refs",
    })

    def apply_modifications(self, modifications: dict[str, Any]) -> None:
        """Apply modifications from CapabilityResult.context_modifications.

        Distinguishes attribute writes from state dict writes:
        - Known mutable attrs → setattr
        - Everything else → capability_state dict
        """
        for key, value in modifications.items():
            if key in self._MUTABLE_ATTRS:
                setattr(self, key, value)
            else:
                self.capability_state[key] = value

    def set(self, key: str, value: Any, slot: str = "capability_state") -> None:
        """Explicit write to capability_state for inter-capability communication."""
        getattr(self, slot)[key] = value

    def get(self, key: str, default: Any = None, slot: str = "capability_state") -> Any:
        """Read from a state slot."""
        return getattr(self, slot).get(key, default)


@dataclass
class CapabilityResult:
    """Return value from a capability execution."""

    action: CapabilityAction = CapabilityAction.CONTINUE
    event_modifications: dict[str, Any] = field(default_factory=dict)
    context_modifications: dict[str, Any] = field(default_factory=dict)
    output: Any = None
    output_type: str | None = None
    capability_name: str = ""
    duration_ms: float = 0.0
    metrics: dict[str, Any] = field(default_factory=dict)
```

- [ ] **Step 5: 修复 `ClassVar` 导入问题**

`AgentContext` 使用了 `ClassVar`，需在 `types.py` 顶部添加导入：

在 `from __future__ import annotations` 之后添加：
```python
from typing import Any, ClassVar
```

- [ ] **Step 6: 运行测试确认通过**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_types.py -v`
Expected: All tests PASS

- [ ] **Step 7: 提交**

```bash
git add src/pyclaw/agents/pacs/__init__.py src/pyclaw/agents/pacs/types.py tests/pyclaw/agents/pacs/__init__.py tests/pyclaw/agents/pacs/test_types.py
git commit -m "feat(pacs): add core types — HookPoint, CapabilityLayer, HookEvent, AgentContext, CapabilityResult"
```

---

### Task 2: AgenticCapability 基类

**Files:**
- Create: `src/pyclaw/agents/pacs/capability.py`
- Create: `tests/pyclaw/agents/pacs/test_capability.py`

- [ ] **Step 1: 编写基类测试**

创建 `tests/pyclaw/agents/pacs/test_capability.py`:
```python
"""Tests for AgenticCapability ABC."""

from __future__ import annotations

import pytest

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)


class _StubCapability(AgenticCapability):
    """Concrete stub for testing the ABC."""

    name = "stub"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks = [HookPoint.PERCEPTION_PRE, HookPoint.PERCEPTION_OBSERVATION]
    priority = 25
    critical = False

    def __init__(self) -> None:
        self.activated_count = 0
        self.event_count = 0

    async def should_activate(self, event: HookEvent, context: AgentContext) -> bool:
        self.activated_count += 1
        return True

    async def on_event(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        self.event_count += 1
        return CapabilityResult(capability_name=self.name)


class _ConditionalCapability(AgenticCapability):
    """Capability that only activates on specific hooks."""

    name = "conditional"
    layer = CapabilityLayer.REASONING
    subscribed_hooks = [HookPoint.TOOL_PRE_EXECUTE]
    priority = 40

    async def should_activate(self, event: HookEvent, context: AgentContext) -> bool:
        return event.tool_call is not None

    async def on_event(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        return CapabilityResult(capability_name=self.name)


class TestAgenticCapability:
    @pytest.mark.asyncio
    async def test_stub_capability_attributes(self):
        cap = _StubCapability()
        assert cap.name == "stub"
        assert cap.layer == CapabilityLayer.PERCEPTION
        assert len(cap.subscribed_hooks) == 2
        assert cap.priority == 25
        assert cap.critical is False

    @pytest.mark.asyncio
    async def test_should_activate_called(self):
        cap = _StubCapability()
        ctx = AgentContext(session_id="test")
        event = HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0)
        assert await cap.should_activate(event, ctx) is True
        assert cap.activated_count == 1

    @pytest.mark.asyncio
    async def test_on_event_returns_result(self):
        cap = _StubCapability()
        ctx = AgentContext(session_id="test")
        event = HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0)
        result = await cap.on_event(event, ctx)
        assert isinstance(result, CapabilityResult)
        assert result.capability_name == "stub"

    @pytest.mark.asyncio
    async def test_conditional_activation(self):
        cap = _ConditionalCapability()
        ctx = AgentContext(session_id="test")

        # No tool_call → should not activate
        event_no_tool = HookEvent(hook=HookPoint.TOOL_PRE_EXECUTE, timestamp=0.0)
        assert await cap.should_activate(event_no_tool, ctx) is False

        # With tool_call → should activate
        event_with_tool = HookEvent(
            hook=HookPoint.TOOL_PRE_EXECUTE,
            timestamp=0.0,
            tool_call={"name": "search"},
        )
        assert await cap.should_activate(event_with_tool, ctx) is True

    @pytest.mark.asyncio
    async def test_setup_and_teardown(self):
        cap = _StubCapability()
        ctx = AgentContext(session_id="test")
        # Default implementations should not raise
        await cap.setup(ctx)
        await cap.teardown(ctx)

    @pytest.mark.asyncio
    async def test_cannot_instantiate_abc(self):
        with pytest.raises(TypeError):
            AgenticCapability()  # type: ignore[abstract]
```

- [ ] **Step 2: 运行测试确认失败**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_capability.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'pyclaw.agents.pacs.capability'`

- [ ] **Step 3: 实现 AgenticCapability ABC**

创建 `src/pyclaw/agents/pacs/capability.py`:
```python
"""AgenticCapability — abstract base class for all PACS capabilities."""

from __future__ import annotations

from abc import ABC, abstractmethod

from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)


class AgenticCapability(ABC):
    """Base class for all agentic capabilities.

    Subclasses must define:
    - name: unique identifier
    - layer: logical layer grouping
    - subscribed_hooks: which hook points to subscribe to
    - should_activate: conditional activation logic
    - on_event: main capability logic
    """

    name: str
    layer: CapabilityLayer
    subscribed_hooks: list[HookPoint]
    priority: int = 50
    critical: bool = False

    @abstractmethod
    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Whether this capability should execute for the given event."""
        ...

    @abstractmethod
    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Execute capability logic and return result."""
        ...

    async def setup(self, context: AgentContext) -> None:
        """Initialize capability for a session. Override if needed."""
        pass

    async def teardown(self, context: AgentContext) -> None:
        """Clean up capability after a session. Override if needed."""
        pass
```

- [ ] **Step 4: 更新 `__init__.py` 导出**

在 `src/pyclaw/agents/pacs/__init__.py` 中添加导出：
```python
from pyclaw.agents.pacs.capability import AgenticCapability
```

在 `__all__` 列表中添加 `"AgenticCapability"`。

- [ ] **Step 5: 运行测试确认通过**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_capability.py -v`
Expected: All tests PASS

- [ ] **Step 6: 提交**

```bash
git add src/pyclaw/agents/pacs/capability.py src/pyclaw/agents/pacs/__init__.py tests/pyclaw/agents/pacs/test_capability.py
git commit -m "feat(pacs): add AgenticCapability ABC with should_activate and on_event"
```

---

### Task 3: AgentEventBus — 注册与优先级排序

**Files:**
- Create: `src/pyclaw/agents/pacs/bus.py`
- Create: `tests/pyclaw/agents/pacs/test_bus.py`

- [ ] **Step 1: 编写 EventBus 注册和优先级测试**

创建 `tests/pyclaw/agents/pacs/test_bus.py`:
```python
"""Tests for AgentEventBus — register, emit, priority, modifications, control flow."""

from __future__ import annotations

import asyncio
import logging

import pytest

from pyclaw.agents.pacs.bus import AgentEventBus
from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)


class _OrderedCap(AgenticCapability):
    """Records execution order for priority testing."""

    def __init__(self, name: str, priority: int, order_list: list[str]):
        self._order_list = order_list
        self.name = name
        self.priority = priority
        self.layer = CapabilityLayer.PERCEPTION
        self.subscribed_hooks = [HookPoint.PERCEPTION_PRE]
        self.critical = False

    async def should_activate(self, event, context):
        return True

    async def on_event(self, event, context):
        self._order_list.append(self.name)
        return CapabilityResult(capability_name=self.name)


class TestEventBusRegister:
    def test_register_single_capability(self):
        bus = AgentEventBus()
        order: list[str] = []
        cap = _OrderedCap("cap_a", 50, order)
        bus.register(cap)
        assert HookPoint.PERCEPTION_PRE in bus._subscribers
        assert len(bus._subscribers[HookPoint.PERCEPTION_PRE]) == 1

    def test_register_multiple_capabilities_sorted_by_priority(self):
        bus = AgentEventBus()
        order: list[str] = []
        bus.register(_OrderedCap("late", 80, order))
        bus.register(_OrderedCap("early", 10, order))
        bus.register(_OrderedCap("mid", 50, order))

        subs = bus._subscribers[HookPoint.PERCEPTION_PRE]
        assert [c.name for c in subs] == ["early", "mid", "late"]

    def test_unregister_capability(self):
        bus = AgentEventBus()
        order: list[str] = []
        bus.register(_OrderedCap("cap_a", 50, order))
        bus.register(_OrderedCap("cap_b", 60, order))
        bus.unregister("cap_a")
        subs = bus._subscribers[HookPoint.PERCEPTION_PRE]
        assert len(subs) == 1
        assert subs[0].name == "cap_b"


class TestEventBusEmit:
    @pytest.mark.asyncio
    async def test_emit_executes_in_priority_order(self):
        bus = AgentEventBus()
        order: list[str] = []
        bus.register(_OrderedCap("late", 80, order))
        bus.register(_OrderedCap("early", 10, order))
        bus.register(_OrderedCap("mid", 50, order))

        event = HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        await bus.emit(HookPoint.PERCEPTION_PRE, event, ctx)

        assert order == ["early", "mid", "late"]

    @pytest.mark.asyncio
    async def test_emit_returns_results(self):
        bus = AgentEventBus()
        order: list[str] = []
        bus.register(_OrderedCap("cap_a", 50, order))

        event = HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        results = await bus.emit(HookPoint.PERCEPTION_PRE, event, ctx)

        assert len(results) == 1
        assert results[0].capability_name == "cap_a"

    @pytest.mark.asyncio
    async def test_emit_with_no_subscribers(self):
        bus = AgentEventBus()
        event = HookEvent(hook=HookPoint.SESSION_INIT, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        results = await bus.emit(HookPoint.SESSION_INIT, event, ctx)
        assert results == []

    @pytest.mark.asyncio
    async def test_emit_respects_should_activate(self):
        bus = AgentEventBus()
        executed: list[str] = []

        class SelectiveCap(AgenticCapability):
            name = "selective"
            layer = CapabilityLayer.PERCEPTION
            subscribed_hooks = [HookPoint.PERCEPTION_PRE]
            priority = 50
            critical = False

            async def should_activate(self, event, context):
                return event.session_id == "target"

            async def on_event(self, event, context):
                executed.append(self.name)
                return CapabilityResult(capability_name=self.name)

        bus.register(SelectiveCap())
        event = HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0, session_id="other")
        ctx = AgentContext(session_id="test")
        results = await bus.emit(HookPoint.PERCEPTION_PRE, event, ctx)
        assert len(results) == 0
        assert executed == []
```

- [ ] **Step 2: 运行测试确认失败**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_bus.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'pyclaw.agents.pacs.bus'`

- [ ] **Step 3: 实现 AgentEventBus 基础版（注册 + emit + 优先级）**

创建 `src/pyclaw/agents/pacs/bus.py`:
```python
"""AgentEventBus — event bus with priority-based capability dispatch."""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

_MUTABLE_EVENT_FIELDS: frozenset[str] = frozenset({
    "messages", "tool_call", "tool_result", "llm_response",
})


class AgentEventBus:
    """Event bus — subscribe/publish with priority-based execution."""

    def __init__(self) -> None:
        self._subscribers: dict[HookPoint, list[AgenticCapability]] = {}

    def register(self, capability: AgenticCapability) -> None:
        """Register a capability to all its subscribed hooks."""
        for hook in capability.subscribed_hooks:
            if hook not in self._subscribers:
                self._subscribers[hook] = []
            self._subscribers[hook].append(capability)
        # Sort each affected hook by priority (ascending)
        for hook in capability.subscribed_hooks:
            if hook in self._subscribers:
                self._subscribers[hook].sort(key=lambda c: c.priority)

    def unregister(self, name: str) -> None:
        """Remove a capability by name from all hooks."""
        for hook in self._subscribers:
            self._subscribers[hook] = [
                c for c in self._subscribers[hook] if c.name != name
            ]

    async def emit(
        self,
        hook: HookPoint,
        event: HookEvent,
        context: AgentContext,
    ) -> list[CapabilityResult]:
        """Emit an event, executing all active capabilities by priority.

        Execution rules:
        1. Execute in priority order (ascending)
        2. Call should_activate first; skip inactive capabilities
        3. Apply modifications after each execution
        4. Honor SKIP/ABORT/RETRY control flow signals
        5. Isolate capability errors (unless critical)
        """
        results: list[CapabilityResult] = []
        capabilities = self._subscribers.get(hook, [])

        for cap in capabilities:
            try:
                if not await cap.should_activate(event, context):
                    continue

                result = await cap.on_event(event, context)
                results.append(result)

                self._apply_modifications(event, context, result)

                if result.action == CapabilityAction.SKIP:
                    break
                if result.action == CapabilityAction.ABORT:
                    return results
                if result.action == CapabilityAction.RETRY:
                    retry_results = await self._handle_retry(hook, event, context, cap)
                    results.extend(retry_results)
                    break

            except Exception as e:
                logger.error("Capability %s failed on %s: %s", cap.name, hook, e)
                if cap.critical:
                    return [CapabilityResult(action=CapabilityAction.ABORT)]
                # Non-critical: error isolation, continue

        return results

    def _apply_modifications(
        self,
        event: HookEvent,
        context: AgentContext,
        result: CapabilityResult,
    ) -> None:
        """Apply capability modifications to event and context."""
        # Event modifications: only allow whitelisted mutable fields
        for key, value in result.event_modifications.items():
            if key in _MUTABLE_EVENT_FIELDS and hasattr(event, key):
                setattr(event, key, value)

        # Context modifications: distinguish attrs vs state dict
        context.apply_modifications(result.context_modifications)

    async def _handle_retry(
        self,
        hook: HookPoint,
        event: HookEvent,
        context: AgentContext,
        originator: AgenticCapability,
    ) -> list[CapabilityResult]:
        """Handle RETRY — re-emit with a retry counter."""
        retry_key = f"_retry_count_{originator.name}"
        current = context.get(retry_key, 0)
        max_retries = 3

        if current >= max_retries:
            logger.warning("Max retries reached for %s on %s", originator.name, hook)
            return []

        context.set(retry_key, current + 1)
        return await self.emit(hook, event, context)
```

- [ ] **Step 4: 更新 `__init__.py` 导出**

在 `src/pyclaw/agents/pacs/__init__.py` 中添加：
```python
from pyclaw.agents.pacs.bus import AgentEventBus
```

在 `__all__` 列表中添加 `"AgentEventBus"`。

- [ ] **Step 5: 运行测试确认通过**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_bus.py -v`
Expected: All tests PASS

- [ ] **Step 6: 提交**

```bash
git add src/pyclaw/agents/pacs/bus.py src/pyclaw/agents/pacs/__init__.py tests/pyclaw/agents/pacs/test_bus.py
git commit -m "feat(pacs): add AgentEventBus with register, emit, priority ordering"
```

---

### Task 4: EventBus 控制流信号与修改机制测试

**Files:**
- Modify: `tests/pyclaw/agents/pacs/test_bus.py` (追加测试)

- [ ] **Step 1: 编写控制流信号和修改机制测试**

在 `tests/pyclaw/agents/pacs/test_bus.py` 末尾追加：

```python
class _SkipCap(AgenticCapability):
    name = "skipper"
    layer = CapabilityLayer.ACTION
    subscribed_hooks = [HookPoint.TOOL_PRE_EXECUTE]
    priority = 60
    critical = False

    async def should_activate(self, event, context):
        return True

    async def on_event(self, event, context):
        return CapabilityResult(action=CapabilityAction.SKIP, capability_name=self.name)


class _AbortCap(AgenticCapability):
    name = "aborter"
    layer = CapabilityLayer.ACTION
    subscribed_hooks = [HookPoint.TOOL_PRE_EXECUTE]
    priority = 70
    critical = False

    async def should_activate(self, event, context):
        return True

    async def on_event(self, event, context):
        return CapabilityResult(action=CapabilityAction.ABORT, capability_name=self.name)


class _ContextModifierCap(AgenticCapability):
    name = "ctx_modifier"
    layer = CapabilityLayer.INFRASTRUCTURE
    subscribed_hooks = [HookPoint.TURN_START]
    priority = 5
    critical = False

    async def should_activate(self, event, context):
        return True

    async def on_event(self, event, context):
        return CapabilityResult(
            context_modifications={
                "task_complexity": 0.8,
                "custom_data": "hello",
            },
            capability_name=self.name,
        )


class _EventModifierCap(AgenticCapability):
    name = "event_modifier"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks = [HookPoint.PERCEPTION_PRE]
    priority = 25
    critical = False

    async def should_activate(self, event, context):
        return True

    async def on_event(self, event, context):
        return CapabilityResult(
            event_modifications={
                "messages": [{"role": "user", "content": "filtered"}],
            },
            capability_name=self.name,
        )


class _CriticalFailCap(AgenticCapability):
    name = "critical_fail"
    layer = CapabilityLayer.ACTION
    subscribed_hooks = [HookPoint.TOOL_PRE_EXECUTE]
    priority = 62
    critical = True

    async def should_activate(self, event, context):
        return True

    async def on_event(self, event, context):
        raise RuntimeError("Critical failure!")


class _NonCriticalFailCap(AgenticCapability):
    name = "noncritical_fail"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks = [HookPoint.PERCEPTION_PRE]
    priority = 30
    critical = False

    async def should_activate(self, event, context):
        return True

    async def on_event(self, event, context):
        raise RuntimeError("Non-critical failure!")


class _ReadOnlyFieldCap(AgenticCapability):
    name = "readonly_hack"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks = [HookPoint.PERCEPTION_PRE]
    priority = 20
    critical = False

    async def should_activate(self, event, context):
        return True

    async def on_event(self, event, context):
        return CapabilityResult(
            event_modifications={
                "session_id": "hacked",  # should be blocked
                "messages": [{"role": "user", "content": "ok"}],  # should be allowed
            },
            capability_name=self.name,
        )


class TestEventBusControlFlow:
    @pytest.mark.asyncio
    async def test_skip_stops_remaining_capabilities(self):
        bus = AgentEventBus()
        executed: list[str] = []

        class AfterSkipCap(AgenticCapability):
            name = "after_skip"
            layer = CapabilityLayer.ACTION
            subscribed_hooks = [HookPoint.TOOL_PRE_EXECUTE]
            priority = 80
            critical = False

            async def should_activate(self, event, context):
                return True

            async def on_event(self, event, context):
                executed.append(self.name)
                return CapabilityResult(capability_name=self.name)

        bus.register(_SkipCap())
        bus.register(AfterSkipCap())

        event = HookEvent(hook=HookPoint.TOOL_PRE_EXECUTE, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        results = await bus.emit(HookPoint.TOOL_PRE_EXECUTE, event, ctx)

        assert len(results) == 1
        assert results[0].action == CapabilityAction.SKIP
        assert executed == []  # AfterSkipCap should not have run

    @pytest.mark.asyncio
    async def test_abort_returns_immediately(self):
        bus = AgentEventBus()
        event = HookEvent(hook=HookPoint.TOOL_PRE_EXECUTE, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        results = await bus.emit(HookPoint.TOOL_PRE_EXECUTE, event, ctx)

        assert len(results) == 1
        assert results[0].action == CapabilityAction.ABORT

    @pytest.mark.asyncio
    async def test_continue_proceeds_normally(self):
        bus = AgentEventBus()
        order: list[str] = []
        bus.register(_OrderedCap("a", 10, order))
        bus.register(_OrderedCap("b", 20, order))
        bus.register(_OrderedCap("c", 30, order))

        event = HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        results = await bus.emit(HookPoint.PERCEPTION_PRE, event, ctx)

        assert order == ["a", "b", "c"]
        assert len(results) == 3
        assert all(r.action == CapabilityAction.CONTINUE for r in results)


class TestEventBusModifications:
    @pytest.mark.asyncio
    async def test_context_modifications_applied(self):
        bus = AgentEventBus()
        bus.register(_ContextModifierCap())

        event = HookEvent(hook=HookPoint.TURN_START, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        await bus.emit(HookPoint.TURN_START, event, ctx)

        assert ctx.task_complexity == 0.8  # attribute written
        assert ctx.capability_state.get("custom_data") == "hello"  # state dict written

    @pytest.mark.asyncio
    async def test_event_modifications_applied(self):
        bus = AgentEventBus()
        bus.register(_EventModifierCap())

        event = HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        await bus.emit(HookPoint.PERCEPTION_PRE, event, ctx)

        assert event.messages == [{"role": "user", "content": "filtered"}]

    @pytest.mark.asyncio
    async def test_readonly_fields_blocked(self):
        bus = AgentEventBus()
        bus.register(_ReadOnlyFieldCap())

        event = HookEvent(
            hook=HookPoint.PERCEPTION_PRE,
            timestamp=0.0,
            session_id="original",
        )
        ctx = AgentContext(session_id="test")
        await bus.emit(HookPoint.PERCEPTION_PRE, event, ctx)

        # session_id should NOT have been modified (read-only)
        assert event.session_id == "original"
        # messages SHOULD have been modified (mutable)
        assert event.messages == [{"role": "user", "content": "ok"}]


class TestEventBusErrorHandling:
    @pytest.mark.asyncio
    async def test_critical_failure_returns_abort(self):
        bus = AgentEventBus()
        bus.register(_CriticalFailCap())

        event = HookEvent(hook=HookPoint.TOOL_PRE_EXECUTE, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        results = await bus.emit(HookPoint.TOOL_PRE_EXECUTE, event, ctx)

        assert len(results) == 1
        assert results[0].action == CapabilityAction.ABORT

    @pytest.mark.asyncio
    async def test_noncritical_failure_is_isolated(self):
        bus = AgentEventBus()
        order: list[str] = []
        bus.register(_NonCriticalFailCap())  # priority 30, will fail
        bus.register(_OrderedCap("after_error", 50, order))  # should still run

        event = HookEvent(hook=HookPoint.PERCEPTION_PRE, timestamp=0.0)
        ctx = AgentContext(session_id="test")
        results = await bus.emit(HookPoint.PERCEPTION_PRE, event, ctx)

        # "after_error" should have executed despite non-critical failure
        assert order == ["after_error"]
        assert len(results) == 1  # only the successful result
```

- [ ] **Step 2: 运行测试确认通过**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_bus.py -v`
Expected: All tests PASS (the new test classes may need minor fixes)

- [ ] **Step 3: 提交**

```bash
git add tests/pyclaw/agents/pacs/test_bus.py
git commit -m "test(pacs): add control flow, modifications, and error handling tests"
```

---

### Task 5: CapabilityType 扩展与兼容层

**Files:**
- Create: `src/pyclaw/agents/pacs/compat.py`
- Modify: `src/pyclaw/agents/capabilities/types.py` (扩展 CapabilityType)
- Create: `tests/pyclaw/agents/pacs/test_compat.py`

- [ ] **Step 1: 编写兼容性测试**

创建 `tests/pyclaw/agents/pacs/test_compat.py`:
```python
"""Tests for PACS compatibility layer — CapabilityType extension."""

from __future__ import annotations

from pyclaw.agents.capabilities.types import CapabilityType


class TestCapabilityTypeExtension:
    def test_existing_types_preserved(self):
        assert CapabilityType.MEMORY == "memory"
        assert CapabilityType.CONTEXT == "context"
        assert CapabilityType.ORCHESTRATION == "orchestration"
        assert CapabilityType.KNOWLEDGE == "knowledge"

    def test_new_pacs_types(self):
        assert CapabilityType.PERCEPTION == "perception"
        assert CapabilityType.REASONING == "reasoning"
        assert CapabilityType.ACTION == "action"
        assert CapabilityType.FEEDBACK == "feedback"

    def test_total_type_count(self):
        assert len(CapabilityType) == 8
```

- [ ] **Step 2: 运行测试确认失败**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_compat.py -v`
Expected: FAIL — `AttributeError: PERCEPTION` (enum not yet extended)

- [ ] **Step 3: 扩展 CapabilityType 枚举**

修改 `src/pyclaw/agents/capabilities/types.py`，在 `CapabilityType` 枚举中添加新成员：

```python
class CapabilityType(str, Enum):
    """Types of capabilities that can be registered."""

    MEMORY = "memory"
    CONTEXT = "context"
    ORCHESTRATION = "orchestration"
    KNOWLEDGE = "knowledge"
    # PACS extensions — aligned with four-layer architecture
    PERCEPTION = "perception"
    REASONING = "reasoning"
    ACTION = "action"
    FEEDBACK = "feedback"
```

同时，更新 `AgentCapabilityRegistry.__new__` 中初始化 `_capabilities` 的逻辑，确保新的枚举值被正确初始化。检查 `registry.py` 中：

```python
def __new__(cls) -> AgentCapabilityRegistry:
    if cls._instance is None:
        cls._instance = super().__new__(cls)
        cls._instance._capabilities = {ct: [] for ct in CapabilityType}
        cls._instance._lock = threading.RLock()
    return cls._instance
```

这段代码使用 `{ct: [] for ct in CapabilityType}` 遍历所有枚举值，新增的枚举值会自动被包含，无需额外修改。

- [ ] **Step 4: 创建 compat.py 兼容层**

创建 `src/pyclaw/agents/pacs/compat.py`:
```python
"""PACS compatibility layer — bridges with existing capability registry."""

from __future__ import annotations

from pyclaw.agents.capabilities.types import CapabilityType
from pyclaw.agents.pacs.types import CapabilityLayer

# Mapping from PACS layer to CapabilityType
LAYER_TO_CAPABILITY_TYPE: dict[CapabilityLayer, CapabilityType] = {
    CapabilityLayer.PERCEPTION: CapabilityType.PERCEPTION,
    CapabilityLayer.REASONING: CapabilityType.REASONING,
    CapabilityLayer.ACTION: CapabilityType.ACTION,
    CapabilityLayer.FEEDBACK: CapabilityType.FEEDBACK,
    CapabilityLayer.INFRASTRUCTURE: CapabilityType.ORCHESTRATION,
}


def layer_to_capability_type(layer: CapabilityLayer) -> CapabilityType:
    """Convert a PACS CapabilityLayer to a CapabilityType for the legacy registry."""
    return LAYER_TO_CAPABILITY_TYPE[layer]
```

- [ ] **Step 5: 运行测试确认通过**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/test_compat.py -v`
Expected: All tests PASS

同时运行现有测试确保没有回归：

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/capabilities/ -v`
Expected: All tests PASS

- [ ] **Step 6: 提交**

```bash
git add src/pyclaw/agents/capabilities/types.py src/pyclaw/agents/pacs/compat.py tests/pyclaw/agents/pacs/test_compat.py
git commit -m "feat(pacs): extend CapabilityType with PERCEPTION/REASONING/ACTION/FEEDBACK and add compat layer"
```

---

### Task 6: 全量测试与最终导出

**Files:**
- Modify: `src/pyclaw/agents/pacs/__init__.py` (确保完整导出)

- [ ] **Step 1: 运行全量 PACS 测试**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/ -v`
Expected: All tests PASS

- [ ] **Step 2: 运行现有 agents 测试确保无回归**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/ -v --timeout=60`
Expected: All tests PASS (或至少现有测试不因 PACS 变更而失败)

- [ ] **Step 3: 确认 `__init__.py` 完整导出**

`src/pyclaw/agents/pacs/__init__.py` 应包含：
```python
"""PACS — PyClaw Agentic Capability Stack."""

from pyclaw.agents.pacs.bus import AgentEventBus
from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

__all__ = [
    "AgentContext",
    "AgentEventBus",
    "AgenticCapability",
    "CapabilityAction",
    "CapabilityLayer",
    "CapabilityResult",
    "HookEvent",
    "HookPoint",
]
```

- [ ] **Step 4: 运行 ruff 和 mypy 检查**

Run: `source .venv/bin/activate && ruff check src/pyclaw/agents/pacs/ tests/pyclaw/agents/pacs/ && mypy src/pyclaw/agents/pacs/`
Expected: No errors

- [ ] **Step 5: 最终提交**

```bash
git add src/pyclaw/agents/pacs/ tests/pyclaw/agents/pacs/
git commit -m "feat(pacs): complete Phase 0 skeleton — EventBus, AgenticCapability, types, compat"
```

---

## Self-Review

**1. Spec coverage check:**
- Section 3 (HookPoint): Task 1 ✅
- Section 4 (HookEvent, AgentContext, CapabilityResult): Task 1 ✅
- Section 4.4 (Mutability contract): Task 4 ✅ (readonly field blocking test)
- Section 5 (AgenticCapability ABC): Task 2 ✅
- Section 5.1 (Priority convention): Task 3 ✅
- Section 6 (AgentEventBus): Tasks 3+4 ✅
- Section 6.1 (_apply_modifications with whitelist): Task 4 ✅
- Section 6.1 (_handle_retry): Task 3 ✅ (implementation present, test in Task 4)
- Section 7 (Control flow signals): Task 4 ✅
- Section 7.3 (Critical capabilities): Task 4 ✅
- Section 8 (CapabilityType extension): Task 5 ✅

**2. Placeholder scan:** No TBD/TODO/fill-in-later found.

**3. Type consistency check:**
- `HookPoint` used consistently across types.py, capability.py, bus.py ✅
- `CapabilityResult.action` is `CapabilityAction` in all references ✅
- `AgentContext.apply_modifications` accepts `dict[str, Any]` matching `CapabilityResult.context_modifications` type ✅
- `_MUTABLE_EVENT_FIELDS` in bus.py matches the whitelisted fields in spec Section 4.4 ✅
