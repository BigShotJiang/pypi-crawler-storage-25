# Memory System Enhancement - Implementation Plan

> 基于设计文档: `docs/superpowers/specs/2026-04-12-memory-enhancement-design.md`
> 创建日期: 2026-04-12

---

## 实施策略

### 关键决策

1. **跨平台文件锁**: 使用 `portalocker` 库替代 `fcntl`，确保 Windows/Linux/macOS 兼容
2. **评分器降级**: `PromotionScorer` 的 `relevance` 维度使用 embedding 相似度，而非 LLM 调用
3. **类型扩展**: 为 `MemoryDirectory` 新增 `ClaimEntry` 和 `EvidenceEntry` 类型

### 实施顺序

```
Phase 1: Active Memory ─────────────────────────────────────►
                           │
                           ▼
Phase 2: Wiki 增强 ◄───────┘ (部分依赖 MemoryDirectory 增强)
         │
         ▼
Phase 3: Dreaming ◄────────┘ (依赖 Wiki 的 MemoryBridge)
```

---

## Phase 1: Active Memory

### 1.1 新增文件

#### `src/pyclaw/memory/recall_types.py`

```python
"""Active Memory 类型定义"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, TypedDict


class QueryMode(str, Enum):
    """Active Memory 查询模式"""
    MESSAGE = "message"
    RECENT = "recent"
    FULL = "full"


class PromptStyle(str, Enum):
    """召回提示风格"""
    BALANCED = "balanced"
    STRICT = "strict"
    CONTEXTUAL = "contextual"
    RECALL_HEAVY = "recall-heavy"
    PRECISION_HEAVY = "precision-heavy"
    PREFERENCE_ONLY = "preference-only"


class SearchDebugInfo(TypedDict, total=False):
    """搜索调试信息"""
    backend: str
    configured_mode: str
    effective_mode: str
    fallback: str
    search_ms: int
    hits: int


@dataclass
class ActiveRecallConfig:
    """Active Memory 配置"""
    enabled: bool = True
    agents: list[str] = field(default_factory=lambda: ["main"])
    model: str | None = None
    model_fallback: str = "openai/gpt-4o-mini"
    timeout_ms: int = 15000
    query_mode: QueryMode = QueryMode.RECENT
    prompt_style: PromptStyle = PromptStyle.BALANCED
    max_summary_chars: int = 220
    recent_user_turns: int = 2
    recent_assistant_turns: int = 1
    allowed_chat_types: list[str] = field(default_factory=lambda: ["direct"])
    cache_ttl_ms: int = 15000
    logging: bool = True

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ActiveRecallConfig":
        return cls(
            enabled=d.get("enabled", True),
            agents=d.get("agents", ["main"]),
            model=d.get("model"),
            model_fallback=d.get("model_fallback", "openai/gpt-4o-mini"),
            timeout_ms=d.get("timeout_ms", 15000),
            query_mode=QueryMode(d.get("query_mode", "recent")),
            prompt_style=PromptStyle(d.get("prompt_style", "balanced")),
            max_summary_chars=d.get("max_summary_chars", 220),
            recent_user_turns=d.get("recent_user_turns", 2),
            recent_assistant_turns=d.get("recent_assistant_turns", 1),
            allowed_chat_types=d.get("allowed_chat_types", ["direct"]),
            cache_ttl_ms=d.get("cache_ttl_ms", 15000),
            logging=d.get("logging", True),
        )


@dataclass
class ActiveRecallResult:
    """Active Memory 召回结果"""
    status: str  # "ok" | "empty" | "timeout" | "unavailable"
    elapsed_ms: int
    summary: str | None = None
    raw_reply: str | None = None
    search_debug: SearchDebugInfo | None = None
```

**任务详情**:
- 创建类型定义文件
- 实现 `QueryMode`, `PromptStyle` 枚举
- 实现 `ActiveRecallConfig` 配置类
- 实现 `ActiveRecallResult` 结果类
- 实现 `SearchDebugInfo` TypedDict

---

#### `src/pyclaw/memory/active_recall.py`

```python
"""Active Memory 召回器"""
from __future__ import annotations

import asyncio
import hashlib
import json
import time
from pathlib import Path
from typing import Any

from pyclaw.logging import get_logger
from pyclaw.memory.manager import MemoryManager
from pyclaw.memory.recall_types import (
    ActiveRecallConfig,
    ActiveRecallResult,
    QueryMode,
    SearchDebugInfo,
)

logger = get_logger(__name__)

ACTIVE_MEMORY_PLUGIN_TAG = "active_memory_plugin"
TOGGLE_STATE_FILE = "session-toggles.json"


class ActiveMemoryRecaller:
    """主动记忆召回器"""
    
    def __init__(
        self,
        memory_manager: MemoryManager,
        config: ActiveRecallConfig,
        workspace_dir: Path,
    ) -> None:
        self._memory_manager = memory_manager
        self._config = config
        self._workspace_dir = Path(workspace_dir)
        self._cache: dict[str, tuple[float, ActiveRecallResult]] = {}
        self._toggle_state: dict[str, bool] = {}
        self._load_toggle_state()
    
    # ... 完整实现见设计文档
```

**任务详情**:
- 实现 `ActiveMemoryRecaller` 类
- 实现 `recall()` 方法：构建查询、搜索记忆、可选 LLM 总结
- 实现 `build_context_message()` 方法
- 实现 `_build_query()` 根据模式构建查询
- 实现 `_search_memory()` 调用 MemoryManager 搜索
- 实现缓存机制
- 实现会话开关管理

---

#### `src/pyclaw/memory/session_toggles.py`

```python
"""会话级开关状态管理"""
from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any

import portalocker


class SessionToggleStore:
    """会话开关状态存储"""
    
    def __init__(self, state_path: Path) -> None:
        self._path = Path(state_path)
        self._lock = threading.Lock()
        self._cache: dict[str, dict[str, Any]] = {}
    
    def is_disabled(self, session_key: str) -> bool:
        """检查会话是否禁用"""
        self._ensure_loaded()
        return self._cache.get("sessions", {}).get(session_key, {}).get("disabled", False)
    
    def set_disabled(self, session_key: str, disabled: bool) -> None:
        """设置会话禁用状态"""
        with self._lock:
            self._ensure_loaded()
            sessions = self._cache.setdefault("sessions", {})
            if disabled:
                sessions[session_key] = {"disabled": True, "updatedAt": time.time()}
            else:
                sessions.pop(session_key, None)
            self._save()
    
    def _ensure_loaded(self) -> None:
        """确保状态已加载"""
        if not self._cache and self._path.exists():
            with portalocker.Lock(self._path, "r") as f:
                self._cache = json.load(f)
    
    def _save(self) -> None:
        """保存状态"""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with portalocker.Lock(self._path, "w") as f:
            json.dump(self._cache, f, indent=2)
```

**任务详情**:
- 创建会话开关状态管理类
- 使用 `portalocker` 实现跨平台文件锁
- 实现 `is_disabled()` / `set_disabled()` 方法

---

### 1.2 修改文件

#### `src/pyclaw/memory/manager.py`

**修改内容**:
- 添加 `active_recall` 属性
- 添加 `active_recall()` 方法

```python
# 新增导入
from pyclaw.memory.active_recall import ActiveMemoryRecaller
from pyclaw.memory.recall_types import ActiveRecallConfig

class MemoryManager:
    def __init__(self, ...):
        # ... 现有初始化
        
        # 新增: Active Memory
        self._active_recall: ActiveMemoryRecaller | None = None
    
    @property
    def active_recall(self) -> ActiveMemoryRecaller | None:
        return self._active_recall
    
    def init_active_recall(self, config: ActiveRecallConfig) -> None:
        """初始化 Active Memory"""
        self._active_recall = ActiveMemoryRecaller(
            memory_manager=self,
            config=config,
            workspace_dir=self._workspace_dir,
        )
```

---

#### `src/pyclaw/agents/hooks/pre_reasoning.py`

**修改内容**:
- 在 `MemoryPreReasoningHook.__call__()` 中添加 Active Memory 召回逻辑

```python
async def __call__(self, event: HookEvent) -> dict[str, Any] | None:
    messages = event.messages
    if not messages:
        return None

    # 新增: Active Memory 召回
    if self._config.active_recall.enabled and self._manager.active_recall:
        await self._run_active_recall(event)

    # 原有逻辑...
```

---

#### `src/pyclaw/config/schema.py`

**修改内容**:
- 添加 `active_recall` 配置字段

```python
@dataclass
class MemoryConfig:
    # 现有字段...
    
    # 新增
    active_recall: ActiveRecallConfig = field(default_factory=ActiveRecallConfig)
```

---

### 1.3 测试文件

#### `tests/pyclaw/memory/test_active_recall.py`

```python
"""Active Memory 单元测试"""
import pytest
from pyclaw.memory.active_recall import ActiveMemoryRecaller
from pyclaw.memory.recall_types import ActiveRecallConfig, QueryMode


@pytest.fixture
def config():
    return ActiveRecallConfig(
        enabled=True,
        query_mode=QueryMode.RECENT,
    )


@pytest.mark.asyncio
async def test_recall_returns_result(memory_manager, config, tmp_path):
    recaller = ActiveMemoryRecaller(memory_manager, config, tmp_path)
    result = await recaller.recall("What is my preference?")
    
    assert result.status in ("ok", "empty", "timeout", "unavailable")
    assert result.elapsed_ms >= 0


# ... 更多测试
```

---

### Phase 1 任务清单

| # | 任务 | 文件 | 预计时间 |
|---|------|------|----------|
| 1.1 | 创建 `recall_types.py` 类型定义 | `memory/recall_types.py` | 0.5d |
| 1.2 | 实现 `ActiveMemoryRecaller` 核心类 | `memory/active_recall.py` | 1d |
| 1.3 | 实现会话开关管理 | `memory/session_toggles.py` | 0.25d |
| 1.4 | 增强 `MemoryManager` | `memory/manager.py` | 0.25d |
| 1.5 | 增强 `MemoryPreReasoningHook` | `agents/hooks/pre_reasoning.py` | 0.5d |
| 1.6 | 添加配置支持 | `config/schema.py` | 0.25d |
| 1.7 | 单元测试 | `tests/pyclaw/memory/test_active_recall.py` | 1d |
| 1.8 | 文档更新 | `CHANGELOG.md` | 0.25d |

**总计: 4d**

---

## Phase 2: Wiki 增强

### 2.1 新增文件

#### `src/pyclaw/memory/wiki/types.py`

**任务详情**:
- 实现 `VaultMode`, `ClaimStatus` 枚举
- 实现 `Evidence`, `Claim`, `WikiPage`, `WikiConfig` dataclass
- 移除 `previous_versions` 字段简化模型

---

#### `src/pyclaw/memory/wiki/vault.py`

**任务详情**:
- 实现 `WikiVault` 类
- 实现目录初始化 (`initialize()`)
- 实现页面读写 (`get_page()`, `save_page()`)
- 实现统计 (`get_stats()`)

---

#### `src/pyclaw/memory/wiki/markdown.py`

**任务详情**:
- 实现区块标记常量
- 实现 `extract_auto_block()`, `extract_human_block()`
- 实现 `replace_auto_block()` 保留人工编辑
- 实现 `build_page_template()`

---

#### `src/pyclaw/memory/wiki/claims.py`

**任务详情**:
- 实现 `ClaimsManager` 类
- 实现 Claim CRUD 操作
- 实现矛盾检测 (`find_contradictions()`)
- 实现 JSONL 导出

---

#### `src/pyclaw/memory/wiki/compile.py`

**任务详情**:
- 实现 `WikiCompiler` 类
- 实现从源内容生成 Wiki 页面
- 集成信任模型计算置信度
- 使用 `portalocker` 实现编译锁

---

#### `src/pyclaw/memory/wiki/bridge.py`

**任务详情**:
- 实现 `MemoryBridge` 类
- 实现 `sync_claims_to_memory()` 单向同步
- 实现 `search_corpus_all()` 跨库搜索
- 实现冲突协调

---

#### `src/pyclaw/memory/wiki/tools.py`

**任务详情**:
- 实现 Agent 工具函数:
  - `wiki_search()`
  - `wiki_get()`
  - `wiki_append_section()`
  - `wiki_update_section()`
  - `wiki_add_claim()`
  - `wiki_supersede_claim()`
  - `wiki_find_related()`

---

### 2.2 修改文件

#### `src/pyclaw/agents/memory_dir/memory_types.py`

**修改内容**:
- 新增 `ClaimEntry` 类
- 新增 `EvidenceEntry` 类
- 新增 `WikiRef` 类

```python
@dataclass
class ClaimEntry(MemoryEntry):
    """Claim 条目"""
    claim_id: str
    status: ClaimStatus = ClaimStatus.ACTIVE
    confidence: float = 0.5
    evidence_refs: list[str] = field(default_factory=list)
    replaces: list[str] = field(default_factory=list)
    replaced_by: str | None = None


@dataclass
class EvidenceEntry(MemoryEntry):
    """证据条目"""
    source_path: str
    source_lines: str
    weight: float = 1.0
    excerpt: str | None = None
```

---

#### `src/pyclaw/agents/memory_dir/find_relevant_memories.py`

**修改内容**:
- 支持 `corpus="all"` 搜索模式
- 集成 Wiki 搜索结果

---

### Phase 2 任务清单

| # | 任务 | 文件 | 预计时间 |
|---|------|------|----------|
| 2.1 | 创建 Wiki 类型定义 | `memory/wiki/types.py` | 0.5d |
| 2.2 | 实现 `WikiVault` | `memory/wiki/vault.py` | 1d |
| 2.3 | 实现区块标记处理 | `memory/wiki/markdown.py` | 0.5d |
| 2.4 | 实现 `ClaimsManager` | `memory/wiki/claims.py` | 1.5d |
| 2.5 | 实现 `WikiCompiler` | `memory/wiki/compile.py` | 2d |
| 2.6 | 实现 `MemoryBridge` | `memory/wiki/bridge.py` | 1d |
| 2.7 | 增强 `memory_types.py` | `agents/memory_dir/memory_types.py` | 0.5d |
| 2.8 | 增强搜索支持 corpus=all | `agents/memory_dir/find_relevant_memories.py` | 0.5d |
| 2.9 | 实现 Agent 工具接口 | `memory/wiki/tools.py` | 1d |
| 2.10 | 单元测试 | `tests/pyclaw/memory/wiki/` | 1.5d |

**总计: 10d**

---

## Phase 3: Dreaming

### 3.1 新增文件

#### `src/pyclaw/memory/dreaming/types.py`

**任务详情**:
- 实现 `DreamingPhase`, `StorageMode` 枚举
- 实现 `DreamingConfig`, `PromotionCandidate`, `DreamingReport` dataclass
- 添加 `scoring_weights` 字段

---

#### `src/pyclaw/memory/dreaming/signals.py`

**任务详情**:
- 实现 `ShortTermSignal` dataclass
- 实现 `SignalsStore` 类
- 实现信号存储、查询、清理

---

#### `src/pyclaw/memory/dreaming/scoring.py`

**任务详情**:
- 实现 `PromotionScorer` 类
- **使用 embedding 相似度计算 relevance** (不调用 LLM)
- 实现六维评分算法
- 实现阈值过滤

---

#### `src/pyclaw/memory/dreaming/phases.py`

**任务详情**:
- 实现 `DreamingPhases` 类
- 实现 `run_light_phase()` 收集信号
- 实现 `run_deep_phase()` 评分提升
- 实现 `run_rem_phase()` 反思生成

---

#### `src/pyclaw/memory/dreaming/promotion.py`

**任务详情**:
- 实现 `MemoryPromoter` 类
- 实现内容指纹去重
- 实现合并更新逻辑
- 追加到 `MEMORY.md`

---

#### `src/pyclaw/memory/dreaming/scheduler.py`

**任务详情**:
- 实现 `DreamingScheduler` 类
- 使用 `portalocker` 实现文件锁
- 实现后台异步执行
- 实现 heartbeat 触发检测

---

#### `src/pyclaw/memory/dreaming/narrative.py`

**任务详情**:
- 实现 `DreamNarrativeGenerator` 类
- 使用小模型生成叙事
- 写入 `DREAMS.md`

---

### 3.2 修改文件

#### `src/pyclaw/cron/types.py`

**修改内容**:
- 添加 `CronPayload` 类型
- 添加 `systemEvent` payload 支持

---

#### `src/pyclaw/cron/scheduler.py`

**修改内容**:
- 支持 `wake_mode: "next-heartbeat"`
- 支持 `payload.kind: "systemEvent"`

---

### Phase 3 任务清单

| # | 任务 | 文件 | 预计时间 |
|---|------|------|----------|
| 3.1 | 创建 Dreaming 类型定义 | `memory/dreaming/types.py` | 0.5d |
| 3.2 | 实现信号存储 | `memory/dreaming/signals.py` | 1d |
| 3.3 | 实现评分器 (embedding) | `memory/dreaming/scoring.py` | 1d |
| 3.4 | 实现三阶段处理器 | `memory/dreaming/phases.py` | 2d |
| 3.5 | 实现记忆提升器 | `memory/dreaming/promotion.py` | 1d |
| 3.6 | 实现叙事生成器 | `memory/dreaming/narrative.py` | 0.5d |
| 3.7 | 实现调度器 | `memory/dreaming/scheduler.py` | 1d |
| 3.8 | 增强 Cron 支持 | `cron/types.py`, `cron/scheduler.py` | 0.5d |
| 3.9 | Hook 集成 | `agents/hooks/pre_reasoning.py` | 0.5d |
| 3.10 | 单元测试 | `tests/pyclaw/memory/dreaming/` | 1.5d |
| 3.11 | 集成测试 | `tests/integration/test_dreaming.py` | 1d |

**总计: 10.5d**

---

## 依赖管理

### 新增依赖

```toml
# pyproject.toml
[project.dependencies]
# 现有依赖...

# 新增
portalocker = ">=2.8"      # 跨平台文件锁
watchdog = ">=3.0"         # 文件监听 (Wiki watcher)
```

### 可选依赖

```toml
[project.optional-dependencies]
memory-enhanced = [
    "portalocker>=2.8",
    "watchdog>=3.0",
]
```

---

## 测试策略

### 单元测试覆盖

| 模块 | 测试文件 | 覆盖目标 |
|------|----------|----------|
| Active Memory | `test_active_recall.py` | 80%+ |
| Wiki Vault | `test_vault.py` | 80%+ |
| Wiki Claims | `test_claims.py` | 80%+ |
| Wiki Compiler | `test_compile.py` | 75%+ |
| Dreaming Signals | `test_signals.py` | 80%+ |
| Dreaming Scoring | `test_scoring.py` | 85%+ |
| Dreaming Phases | `test_phases.py` | 75%+ |

### 集成测试

1. **Active Memory + MemoryManager**: 验证召回集成
2. **Wiki + MemoryDirectory**: 验证 Bridge 同步
3. **Dreaming + Cron**: 验证定时触发

---

## 验收标准

### Phase 1 验收

- [ ] `/active-memory on|off|status` 命令可用
- [ ] Active Memory 在 `recent` 模式下正确召回
- [ ] 召回结果正确注入到对话上下文
- [ ] 会话开关状态持久化正确
- [ ] 单元测试覆盖率 ≥ 80%

### Phase 2 验收

- [ ] `wiki init` 命令创建标准 Vault 结构
- [ ] Wiki 页面读写保留人工编辑区块
- [ ] Claim CRUD 操作正确
- [ ] Bridge 同步将 Claims 写入 MemoryDirectory
- [ ] `wiki_search(corpus="all")` 返回合并结果
- [ ] 单元测试覆盖率 ≥ 80%

### Phase 3 验收

- [ ] Cron job 正确注册 Dreaming 任务
- [ ] Heartbeat 触发 Dreaming 执行
- [ ] Deep Phase 正确提升记忆到 `MEMORY.md`
- [ ] 去重合并逻辑正确
- [ ] 文件锁防止并发执行
- [ ] 单元测试覆盖率 ≥ 80%

---

## 风险缓解

| 风险 | 缓解措施 |
|------|----------|
| LLM 成本过高 | 评分器使用 embedding 而非 LLM；Active Memory 支持缓存 |
| 跨平台兼容性 | 使用 `portalocker` 替代 `fcntl` |
| 存储膨胀 | 实现去重合并；配置 `limit` 限制每次提升数量 |
| 信号噪声 | `SignalsStore.add_signal()` 时过滤短内容和停用词 |

---

## 文档更新

完成后需更新:

1. `CHANGELOG.md` - 添加功能变更记录
2. `docs/concepts/memory.md` - 添加新概念说明
3. `docs/api-reference.md` - 添加新 API 文档
4. `README.md` - 更新功能列表
