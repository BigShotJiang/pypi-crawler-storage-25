# UI 架构重构实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 重构 PyClaw UI 为 MVC 架构，实现响应式状态管理、依赖注入和可测试的面板系统。（注：Flet UI 已迁移至 TypeScript，本计划仅作历史参考。）

**Architecture:** 采用 MVC 分层 + Repository 模式。基础设施层（`core/`）提供 Reactive 状态、EventBus、GatewayService 等通用能力；每个面板（`panels/xxx/`）按 model/state/controller/view 分离；组件库（`components/`）抽取可复用 UI 组件。

**Tech Stack:** TypeScript, Next.js, shadcn/ui, Zustand, TanStack Query

**Design Spec:** `docs/superpowers/specs/2026-04-06-ui-architecture-refactor-design.md`

---

## 文件结构映射

### 新建文件

| 文件路径 | 职责 |
|----------|------|
| `src/pyclaw/ui/core/__init__.py` | 核心模块导出 |
| `src/pyclaw/ui/core/reactive.py` | Reactive[T] 响应式状态 |
| `src/pyclaw/ui/core/event_bus.py` | EventBus 跨面板事件总线 |
| `src/pyclaw/ui/core/events.py` | AppEvents 事件常量 |
| `src/pyclaw/ui/core/types.py` | Agent, Session 等数据模型 |
| `src/pyclaw/ui/core/repository.py` | Repository 抽象接口 |
| `src/pyclaw/ui/core/base_controller.py` | BaseController 抽象类 |
| `src/pyclaw/ui/core/base_panel.py` | BasePanel 抽象基类 |
| `src/pyclaw/ui/core/gateway_service.py` | GatewayService 封装 |
| `src/pyclaw/ui/core/testing.py` | Mock 工具 |
| `src/pyclaw/ui/components/__init__.py` | 组件库导出 |
| `src/pyclaw/ui/components/tiles.py` | card_tile 等 |
| `src/pyclaw/ui/components/forms.py` | slider_input 等 |
| `src/pyclaw/ui/components/status.py` | status_chip 等 |
| `src/pyclaw/ui/components/empty_state.py` | empty_state 等 |
| `src/pyclaw/ui/components/page_header.py` | page_header 等 |
| `src/pyclaw/ui/panels/__init__.py` | 面板模块导出 |
| `src/pyclaw/ui/panels/agents/__init__.py` | Agents 面板导出 |
| `src/pyclaw/ui/panels/agents/model.py` | Agent 数据模型 |
| `src/pyclaw/ui/panels/agents/state.py` | AgentsState 响应式状态 |
| `src/pyclaw/ui/panels/agents/controller.py` | AgentsController 业务逻辑 |
| `src/pyclaw/ui/panels/agents/view.py` | AgentsView UI 渲染 |
| `src/pyclaw/ui/panels/agents/local_repository.py` | 本地 Agent 仓库 |
| `tests/pyclaw/ui/core/test_reactive.py` | Reactive 单元测试 |
| `tests/pyclaw/ui/core/test_event_bus.py` | EventBus 单元测试 |
| `tests/pyclaw/ui/panels/agents/test_controller.py` | AgentsController 测试 |

### 修改文件

| 文件路径 | 修改内容 |
|----------|----------|
| `src/pyclaw/ui/__init__.py` | 添加 core/components 导出 |
| `src/pyclaw/ui/components.py` | 删除（拆分到 components/） |

---

## Phase 1: 基础设施层

### Task 1: Reactive 响应式状态

**Files:**
- Create: `src/pyclaw/ui/core/__init__.py`
- Create: `src/pyclaw/ui/core/reactive.py`
- Test: `tests/pyclaw/ui/core/test_reactive.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/pyclaw/ui/core/test_reactive.py
"""Reactive 响应式状态单元测试。"""
from __future__ import annotations

import pytest

from pyclaw.ui.core.reactive import Reactive


class TestReactive:
    """Reactive 类测试。"""

    def test_initial_value(self) -> None:
        """初始值应正确设置。"""
        r = Reactive(42)
        assert r.value == 42

    def test_set_value_triggers_notification(self) -> None:
        """设置新值应触发订阅回调。"""
        r = Reactive(0)
        calls: list[int] = []

        r.subscribe(lambda v: calls.append(v))
        r.value = 10

        assert calls == [10]

    def test_same_value_no_notification(self) -> None:
        """相同值（同一对象）不触发通知。"""
        r = Reactive("hello")
        calls: list[str] = []

        r.subscribe(lambda v: calls.append(v))
        r.value = "hello"  # 相同字符串，同一对象

        assert calls == []

    def test_unsubscribe_stops_notifications(self) -> None:
        """取消订阅后不再接收通知。"""
        r = Reactive(0)
        calls: list[int] = []

        unsubscribe = r.subscribe(lambda v: calls.append(v))
        r.value = 1
        unsubscribe()
        r.value = 2

        assert calls == [1]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_reactive.py -v`
Expected: FAIL with "ModuleNotFoundError: No module named 'pyclaw.ui.core'"

- [ ] **Step 3: Create core module directory**

```bash
mkdir -p src/pyclaw/ui/core
touch src/pyclaw/ui/core/__init__.py
```

- [ ] **Step 4: Write Reactive implementation**

```python
# src/pyclaw/ui/core/reactive.py
"""响应式状态管理 — 状态变化自动通知订阅者。"""
from __future__ import annotations

import copy
from typing import Callable, Generic, TypeVar

T = TypeVar("T")


class Reactive(Generic[T]):
    """响应式值包装器，支持订阅变化通知。

    使用示例:
        count = Reactive(0)
        unsubscribe = count.subscribe(lambda v: print(f"Count: {v}"))
        count.value = 1  # 触发打印 "Count: 1"
        unsubscribe()    # 取消订阅

    ⚠️ 重要注意事项：
        对于 list/dict 等可变类型，必须采用"替换不可变快照"的方式更新：
        ❌ 错误: state.agents.value.append(agent)  # 不会触发通知
        ✅ 正确: state.agents.value = [*state.agents.value, agent]  # 触发通知
    """

    def __init__(self, initial: T) -> None:
        self._value: T = initial
        self._subscribers: list[Callable[[T], None]] = []

    @property
    def value(self) -> T:
        """获取当前值。"""
        return self._value

    @value.setter
    def value(self, new: T) -> None:
        """设置新值，如果值变化则通知所有订阅者。

        使用 `is` 判断引用是否变化，对于可变类型需替换整个对象。
        """
        if new is self._value:
            return
        self._value = new
        self._notify()

    def subscribe(self, callback: Callable[[T], None]) -> Callable[[], None]:
        """订阅值变化。

        Args:
            callback: 值变化时调用的回调函数

        Returns:
            取消订阅函数，调用后移除该订阅
        """
        self._subscribers.append(callback)

        def unsubscribe() -> None:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

        return unsubscribe

    def _notify(self) -> None:
        """通知所有订阅者，遍历副本防止回调中修改列表。"""
        for callback in self._subscribers.copy():
            try:
                callback(self._value)
            except Exception:
                # 忽略订阅者异常，避免影响其他订阅者
                pass

    # 便捷方法
    def set(self, value: T) -> None:
        """设置值（等同于 value setter）。"""
        self.value = value

    def get(self) -> T:
        """获取值（等同于 value getter）。"""
        return self._value

    def mutate(self, mutator: Callable[[T], None]) -> None:
        """对可变类型进行修改并触发通知。

        自动创建副本后修改，适用于 list/dict 等可变类型。
        使用示例:
            state.agents.mutate(lambda lst: lst.append(new_agent))
        """
        self._value = copy.deepcopy(self._value)
        mutator(self._value)
        self._notify()
```

- [ ] **Step 5: Update core __init__.py**

```python
# src/pyclaw/ui/core/__init__.py
"""UI 核心基础设施模块。"""
from .reactive import Reactive

__all__ = ["Reactive"]
```

- [ ] **Step 6: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_reactive.py -v`
Expected: PASS (7 tests)

- [ ] **Step 7: Commit**

```bash
git add src/pyclaw/ui/core/ tests/pyclaw/ui/core/
git commit -m "feat(ui): add Reactive state with subscription support

- Reactive[T] generic class for reactive state management
- subscribe() returns unsubscribe function for cleanup
- mutate() helper for mutable types (creates deep copy)
- Comprehensive unit tests

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

### Task 2: EventBus 事件总线

**Files:**
- Create: `src/pyclaw/ui/core/event_bus.py`
- Create: `src/pyclaw/ui/core/events.py`
- Test: `tests/pyclaw/ui/core/test_event_bus.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/pyclaw/ui/core/test_event_bus.py
"""EventBus 事件总线单元测试。"""
from __future__ import annotations

import pytest

from pyclaw.ui.core.event_bus import EventBus
from pyclaw.ui.core.events import AppEvents


class TestEventBus:
    """EventBus 类测试。"""

    def test_emit_triggers_handler(self) -> None:
        """emit 应触发已注册的处理函数。"""
        bus = EventBus()
        calls: list[str] = []

        bus.on("test.event", lambda data: calls.append(data))
        bus.emit("test.event", "hello")

        assert calls == ["hello"]

    def test_unsubscribe_stops_receiving_events(self) -> None:
        """取消订阅后不再接收事件。"""
        bus = EventBus()
        calls: list[str] = []

        unsubscribe = bus.on("test.event", lambda data: calls.append(data))
        bus.emit("test.event", "first")
        unsubscribe()
        bus.emit("test.event", "second")

        assert calls == ["first"]

    def test_multiple_handlers_same_event(self) -> None:
        """同一事件可以有多个处理函数。"""
        bus = EventBus()
        calls1: list[str] = []
        calls2: list[str] = []

        bus.on("test.event", lambda data: calls1.append(data))
        bus.on("test.event", lambda data: calls2.append(data))
        bus.emit("test.event", "hello")

        assert calls1 == ["hello"]
        assert calls2 == ["hello"]

    def test_handler_exception_does_not_affect_others(self) -> None:
        """处理函数异常不影响其他处理函数。"""
        bus = EventBus()
        calls: list[str] = []

        bus.on("test.event", lambda data: 1 / 0)  # 会抛出异常
        bus.on("test.event", lambda data: calls.append(data))
        bus.emit("test.event", "hello")

        assert calls == ["hello"]

    def test_emit_nonexistent_event_does_nothing(self) -> None:
        """触发未订阅的事件不报错。"""
        bus = EventBus()
        bus.emit("nonexistent.event", "data")  # 不应抛出异常

    def test_clear_specific_event(self) -> None:
        """clear 可以清除特定事件的所有订阅。"""
        bus = EventBus()
        calls: list[str] = []

        bus.on("event.a", lambda data: calls.append(f"a:{data}"))
        bus.on("event.b", lambda data: calls.append(f"b:{data}"))
        bus.clear("event.a")
        bus.emit("event.a", "1")
        bus.emit("event.b", "2")

        assert calls == ["b:2"]

    def test_clear_all_events(self) -> None:
        """clear(None) 清除所有订阅。"""
        bus = EventBus()
        calls: list[str] = []

        bus.on("event.a", lambda data: calls.append(f"a:{data}"))
        bus.on("event.b", lambda data: calls.append(f"b:{data}"))
        bus.clear()
        bus.emit("event.a", "1")
        bus.emit("event.b", "2")

        assert calls == []


class TestAppEvents:
    """AppEvents 事件常量测试。"""

    def test_event_constants_exist(self) -> None:
        """事件常量应存在。"""
        assert hasattr(AppEvents, "AGENTS_CREATED")
        assert hasattr(AppEvents, "AGENTS_DELETED")
        assert hasattr(AppEvents, "SESSIONS_CREATED")

    def test_event_constants_are_strings(self) -> None:
        """事件常量应为字符串。"""
        assert isinstance(AppEvents.AGENTS_CREATED, str)
        assert isinstance(AppEvents.AGENTS_DELETED, str)


    def test_mutate_creates_copy_and_notifies(self) -> None:
        """mutate 应创建副本并触发通知。"""
        r = Reactive([1, 2, 3])
        calls: list[list[int]] = []

        r.subscribe(lambda v: calls.append(v.copy()))
        r.mutate(lambda lst: lst.append(4))

        assert r.value == [1, 2, 3, 4]
        assert calls == [[1, 2, 3, 4]]

    def test_multiple_subscribers(self) -> None:
        """多个订阅者都应收到通知。"""
        r = Reactive(0)
        calls1: list[int] = []
        calls2: list[int] = []

        r.subscribe(lambda v: calls1.append(v))
        r.subscribe(lambda v: calls2.append(v))
        r.value = 5

        assert calls1 == [5]
        assert calls2 == [5]

    def test_subscriber_exception_does_not_affect_others(self) -> None:
        """订阅者异常不影响其他订阅者。"""
        r = Reactive(0)
        calls: list[int] = []

        r.subscribe(lambda v: 1 / 0)  # 会抛出异常
        r.subscribe(lambda v: calls.append(v))
        r.value = 1

        assert calls == [1]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_reactive.py -v`
Expected: FAIL with "ModuleNotFoundError: No module named 'pyclaw.ui.core'"

- [ ] **Step 3: Create core module directory**

```bash
mkdir -p src/pyclaw/ui/core
touch src/pyclaw/ui/core/__init__.py
```

- [ ] **Step 4: Write Reactive implementation**

```python
# src/pyclaw/ui/core/reactive.py
"""响应式状态管理 — 状态变化自动通知订阅者。"""
from __future__ import annotations

import copy
from typing import Callable, Generic, TypeVar

T = TypeVar("T")


class Reactive(Generic[T]):
    """响应式值包装器，支持订阅变化通知。

    使用示例:
        count = Reactive(0)
        unsubscribe = count.subscribe(lambda v: print(f"Count: {v}"))
        count.value = 1  # 触发打印 "Count: 1"
        unsubscribe()    # 取消订阅

    ⚠️ 重要注意事项：
        对于 list/dict 等可变类型，必须采用"替换不可变快照"的方式更新：
        ❌ 错误: state.agents.value.append(agent)  # 不会触发通知
        ✅ 正确: state.agents.value = [*state.agents.value, agent]  # 触发通知
    """

    def __init__(self, initial: T) -> None:
        self._value: T = initial
        self._subscribers: list[Callable[[T], None]] = []

    @property
    def value(self) -> T:
        """获取当前值。"""
        return self._value

    @value.setter
    def value(self, new: T) -> None:
        """设置新值，如果值变化则通知所有订阅者。

        使用 `is` 判断引用是否变化，对于可变类型需替换整个对象。
        """
        if new is self._value:
            return
        self._value = new
        self._notify()

    def subscribe(self, callback: Callable[[T], None]) -> Callable[[], None]:
        """订阅值变化。

        Args:
            callback: 值变化时调用的回调函数

        Returns:
            取消订阅函数，调用后移除该订阅
        """
        self._subscribers.append(callback)

        def unsubscribe() -> None:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

        return unsubscribe

    def _notify(self) -> None:
        """通知所有订阅者，遍历副本防止回调中修改列表。"""
        for callback in self._subscribers.copy():
            try:
                callback(self._value)
            except Exception:
                # 忽略订阅者异常，避免影响其他订阅者
                pass

    # 便捷方法
    def set(self, value: T) -> None:
        """设置值（等同于 value setter）。"""
        self.value = value

    def get(self) -> T:
        """获取值（等同于 value getter）。"""
        return self._value

    def mutate(self, mutator: Callable[[T], None]) -> None:
        """对可变类型进行修改并触发通知。

        自动创建副本后修改，适用于 list/dict 等可变类型。
        使用示例:
            state.agents.mutate(lambda lst: lst.append(new_agent))
        """
        self._value = copy.deepcopy(self._value)
        mutator(self._value)
        self._notify()
```

- [ ] **Step 5: Update core __init__.py**

```python
# src/pyclaw/ui/core/__init__.py
"""UI 核心基础设施模块。"""
from .reactive import Reactive

__all__ = ["Reactive"]
```

- [ ] **Step 6: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_reactive.py -v`
Expected: PASS (7 tests)

- [ ] **Step 7: Commit**

```bash
git add src/pyclaw/ui/core/ tests/pyclaw/ui/core/
git commit -m "feat(ui): add Reactive state with subscription support

- Reactive[T] generic class for reactive state management
- subscribe() returns unsubscribe function for cleanup
- mutate() helper for mutable types (creates deep copy)
- Comprehensive unit tests

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

### Task 2: EventBus 事件总线

**Files:**
- Create: `src/pyclaw/ui/core/event_bus.py`
- Create: `src/pyclaw/ui/core/events.py`
- Test: `tests/pyclaw/ui/core/test_event_bus.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/pyclaw/ui/core/test_event_bus.py
"""EventBus 事件总线单元测试。"""
from __future__ import annotations

import pytest

from pyclaw.ui.core.event_bus import EventBus
from pyclaw.ui.core.events import AppEvents


class TestEventBus:
    """EventBus 类测试。"""

    def test_emit_triggers_handler(self) -> None:
        """emit 应触发已注册的处理函数。"""
        bus = EventBus()
        calls: list[str] = []

        bus.on("test.event", lambda data: calls.append(data))
        bus.emit("test.event", "hello")

        assert calls == ["hello"]

    def test_unsubscribe_stops_receiving_events(self) -> None:
        """取消订阅后不再接收事件。"""
        bus = EventBus()
        calls: list[str] = []

        unsubscribe = bus.on("test.event", lambda data: calls.append(data))
        bus.emit("test.event", "first")
        unsubscribe()
        bus.emit("test.event", "second")

        assert calls == ["first"]

    def test_multiple_handlers_same_event(self) -> None:
        """同一事件可以有多个处理函数。"""
        bus = EventBus()
        calls1: list[str] = []
        calls2: list[str] = []

        bus.on("test.event", lambda data: calls1.append(data))
        bus.on("test.event", lambda data: calls2.append(data))
        bus.emit("test.event", "hello")

        assert calls1 == ["hello"]
        assert calls2 == ["hello"]

    def test_handler_exception_does_not_affect_others(self) -> None:
        """处理函数异常不影响其他处理函数。"""
        bus = EventBus()
        calls: list[str] = []

        bus.on("test.event", lambda data: 1 / 0)  # 会抛出异常
        bus.on("test.event", lambda data: calls.append(data))
        bus.emit("test.event", "hello")

        assert calls == ["hello"]

    def test_emit_nonexistent_event_does_nothing(self) -> None:
        """触发未订阅的事件不报错。"""
        bus = EventBus()
        bus.emit("nonexistent.event", "data")  # 不应抛出异常

    def test_clear_specific_event(self) -> None:
        """clear 可以清除特定事件的所有订阅。"""
        bus = EventBus()
        calls: list[str] = []

        bus.on("event.a", lambda data: calls.append(f"a:{data}"))
        bus.on("event.b", lambda data: calls.append(f"b:{data}"))
        bus.clear("event.a")
        bus.emit("event.a", "1")
        bus.emit("event.b", "2")

        assert calls == ["b:2"]

    def test_clear_all_events(self) -> None:
        """clear(None) 清除所有订阅。"""
        bus = EventBus()
        calls: list[str] = []

        bus.on("event.a", lambda data: calls.append(f"a:{data}"))
        bus.on("event.b", lambda data: calls.append(f"b:{data}"))
        bus.clear()
        bus.emit("event.a", "1")
        bus.emit("event.b", "2")

        assert calls == []


class TestAppEvents:
    """AppEvents 事件常量测试。"""

    def test_event_constants_exist(self) -> None:
        """事件常量应存在。"""
        assert hasattr(AppEvents, "AGENTS_CREATED")
        assert hasattr(AppEvents, "AGENTS_DELETED")
        assert hasattr(AppEvents, "SESSIONS_CREATED")

    def test_event_constants_are_strings(self) -> None:
        """事件常量应为字符串。"""
        assert isinstance(AppEvents.AGENTS_CREATED, str)
        assert isinstance(AppEvents.AGENTS_DELETED, str)

```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_event_bus.py -v`
Expected: FAIL with "ModuleNotFoundError: No module named 'pyclaw.ui.core.event_bus'"

- [ ] **Step 3: Write EventBus implementation**

```python
# src/pyclaw/ui/core/event_bus.py
"""事件总线 — 跨面板通信的轻量级发布/订阅系统。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class EventBus:
    """轻量级事件总线，用于跨面板通信。

    使用示例:
        bus = EventBus()
        unsubscribe = bus.on(AppEvents.AGENTS_DELETED, lambda id: print(f"Deleted: {id}"))
        bus.emit(AppEvents.AGENTS_DELETED, "agent-123")
        unsubscribe()
    """

    _handlers: dict[str, list[Callable[[Any], None]]] = field(default_factory=dict)

    def on(self, event: str, handler: Callable[[Any], None]) -> Callable[[], None]:
        """订阅事件。

        Args:
            event: 事件名称
            handler: 事件处理函数

        Returns:
            取消订阅函数
        """
        self._handlers.setdefault(event, []).append(handler)

        def off() -> None:
            if event in self._handlers and handler in self._handlers[event]:
                self._handlers[event].remove(handler)

        return off

    def emit(self, event: str, data: Any = None) -> None:
        """触发事件。

        Args:
            event: 事件名称
            data: 事件数据
        """
        handlers = self._handlers.get(event, [])
        for handler in handlers.copy():
            try:
                handler(data)
            except Exception:
                # 忽略处理异常，避免影响其他订阅者
                pass

    def clear(self, event: str | None = None) -> None:
        """清除事件订阅。

        Args:
            event: 事件名称，为 None 时清除所有
        """
        if event is None:
            self._handlers.clear()
        elif event in self._handlers:
            del self._handlers[event]
```

- [ ] **Step 4: Write AppEvents constants**

```python
# src/pyclaw/ui/core/events.py
"""预定义事件常量。"""
from __future__ import annotations


class AppEvents:
    """预定义事件名称常量，避免字符串拼写错误。"""

    # Agent 事件
    AGENTS_CREATED = "agents.created"
    AGENTS_DELETED = "agents.deleted"
    AGENTS_UPDATED = "agents.updated"

    # Session 事件
    SESSIONS_CREATED = "sessions.created"
    SESSIONS_DELETED = "sessions.deleted"
    SESSIONS_ACTIVATED = "sessions.activated"

    # Gateway 事件
    GATEWAY_CONNECTED = "gateway.connected"
    GATEWAY_DISCONNECTED = "gateway.disconnected"

    # Config 事件
    CONFIG_CHANGED = "config.changed"
```

- [ ] **Step 5: Update core __init__.py**

```python
# src/pyclaw/ui/core/__init__.py
"""UI 核心基础设施模块。"""
from .event_bus import EventBus
from .events import AppEvents
from .reactive import Reactive

__all__ = ["EventBus", "AppEvents", "Reactive"]
```

- [ ] **Step 6: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_event_bus.py -v`
Expected: PASS (8 tests)

- [ ] **Step 7: Commit**

```bash
git add src/pyclaw/ui/core/ tests/pyclaw/ui/core/
git commit -m "feat(ui): add EventBus and AppEvents constants

- EventBus for cross-panel communication
- AppEvents constants to avoid string typos
- on() returns unsubscribe function
- Comprehensive unit tests

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

### Task 3: Types 和 Repository 接口

**Files:**
- Create: `src/pyclaw/ui/core/types.py`
- Create: `src/pyclaw/ui/core/repository.py`
- Test: `tests/pyclaw/ui/core/test_types.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/pyclaw/ui/core/test_types.py
"""Types 数据模型单元测试。"""
from __future__ import annotations

import pytest

from pyclaw.ui.core.types import Agent, Session


class TestAgent:
    """Agent 数据模型测试。"""

    def test_from_dict_basic(self) -> None:
        """from_dict 应正确解析基本字段。"""
        data = {
            "id": "test-agent",
            "name": "Test Agent",
            "path": "/agents/test-agent",
        }
        agent = Agent.from_dict(data)

        assert agent.id == "test-agent"
        assert agent.name == "Test Agent"
        assert agent.path == "/agents/test-agent"

    def test_from_dict_with_optional_fields(self) -> None:
        """from_dict 应正确解析可选字段。"""
        data = {
            "id": "test-agent",
            "name": "Test Agent",
            "path": "/agents/test-agent",
            "model": "gpt-4",
            "provider": "openai",
            "systemPrompt": "You are helpful.",
            "tools": ["tool1", "tool2"],
        }
        agent = Agent.from_dict(data)

        assert agent.model == "gpt-4"
        assert agent.provider == "openai"
        assert agent.system_prompt == "You are helpful."
        assert agent.tools == ["tool1", "tool2"]

    def test_to_dict(self) -> None:
        """to_dict 应正确序列化。"""
        agent = Agent(
            id="test",
            name="Test",
            path="/test",
            model="gpt-4",
        )
        data = agent.to_dict()

        assert data["id"] == "test"
        assert data["name"] == "Test"
        assert data["model"] == "gpt-4"
        assert data["systemPrompt"] == ""


class TestSession:
    """Session 数据模型测试。"""

    def test_from_dict_basic(self) -> None:
        """from_dict 应正确解析基本字段。"""
        data = {
            "id": "session-1",
            "path": "/sessions/session-1.json",
            "label": "My Session",
        }
        session = Session.from_dict(data)

        assert session.id == "session-1"
        assert session.path == "/sessions/session-1.json"
        assert session.label == "My Session"

    def test_from_dict_with_key_fallback(self) -> None:
        """from_dict 应使用 key 作为 id 的回退。"""
        data = {
            "key": "fallback-id",
            "path": "/sessions/test.json",
            "label": "Test",
        }
        session = Session.from_dict(data)

        assert session.id == "fallback-id"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_types.py -v`
Expected: FAIL with "ModuleNotFoundError: No module named 'pyclaw.ui.core.types'"

- [ ] **Step 3: Write types implementation**

```python
# src/pyclaw/ui/core/types.py
"""公共类型定义。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Agent:
    """Agent 实体。"""
    id: str
    name: str
    path: str
    model: str = ""
    provider: str = ""
    system_prompt: str = ""
    tools: list[str] = field(default_factory=list)
    skills: list[dict[str, Any]] = field(default_factory=list)
    channels: list[str] = field(default_factory=list)
    cron: list[Any] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Agent:
        """从字典创建 Agent。"""
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            path=data.get("path", ""),
            model=data.get("model", ""),
            provider=data.get("provider", ""),
            system_prompt=data.get("systemPrompt", ""),
            tools=data.get("tools", []),
            skills=data.get("skills", []),
            channels=data.get("channels", []),
            cron=data.get("cron", []),
        )

    def to_dict(self) -> dict[str, Any]:
        """转换为字典。"""
        return {
            "id": self.id,
            "name": self.name,
            "path": self.path,
            "model": self.model,
            "provider": self.provider,
            "systemPrompt": self.system_prompt,
            "tools": self.tools,
            "skills": self.skills,
            "channels": self.channels,
            "cron": self.cron,
        }


@dataclass
class Session:
    """会话实体。"""
    id: str
    path: str
    label: str
    agent_id: str = ""
    kind: str = "chat"
    tokens: int = 0
    size: int = 0
    updated_at: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Session:
        """从字典创建 Session。"""
        return cls(
            id=data.get("id", data.get("key", "")),
            path=data.get("path", ""),
            label=data.get("label", ""),
            agent_id=data.get("agentId", ""),
            kind=data.get("kind", "chat"),
            tokens=data.get("tokens", 0),
            size=data.get("size", 0),
            updated_at=data.get("updated", ""),
        )


@dataclass
class AgentCreate:
    """Agent 创建数据（不含 id/path）。"""
    name: str
    model: str = ""
    provider: str = ""
    system_prompt: str = ""
    tools: list[str] = field(default_factory=list)
    skills: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class SessionCreate:
    """Session 创建数据。"""
    label: str = ""
    agent_id: str = ""
    kind: str = "chat"
```

- [ ] **Step 4: Write Repository interfaces**

```python
# src/pyclaw/ui/core/repository.py
"""数据仓库抽象接口。"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .types import Agent, AgentCreate, Session, SessionCreate


class AgentRepository(ABC):
    """Agent 数据仓库抽象接口。"""

    @abstractmethod
    async def list_agents(self) -> list[Agent]:
        """获取所有 Agent。"""
        ...

    @abstractmethod
    async def get_agent(self, agent_id: str) -> Agent | None:
        """获取单个 Agent。"""
        ...

    @abstractmethod
    async def get_agent_tools(self, agent_id: str) -> list[str]:
        """获取 Agent 的工具列表。"""
        ...

    @abstractmethod
    async def create_agent(self, agent_data: AgentCreate) -> Agent:
        """创建新 Agent。"""
        ...

    @abstractmethod
    async def delete_agent(self, agent_id: str) -> None:
        """删除 Agent。"""
        ...


class SessionRepository(ABC):
    """Session 数据仓库抽象接口。"""

    @abstractmethod
    async def list_sessions(self, limit: int = 50) -> list[Session]:
        """获取会话列表。"""
        ...

    @abstractmethod
    async def get_session(self, session_id: str) -> Session | None:
        """获取单个会话。"""
        ...

    @abstractmethod
    async def create_session(self, session_data: SessionCreate) -> Session:
        """创建新会话。"""
        ...

    @abstractmethod
    async def delete_session(self, session_id: str) -> None:
        """删除会话。"""
        ...
```

- [ ] **Step 5: Update core __init__.py**

```python
# src/pyclaw/ui/core/__init__.py
"""UI 核心基础设施模块。"""
from .event_bus import EventBus
from .events import AppEvents
from .reactive import Reactive
from .repository import AgentRepository, SessionRepository
from .types import Agent, AgentCreate, Session, SessionCreate

__all__ = [
    "EventBus",
    "AppEvents",
    "Reactive",
    "AgentRepository",
    "SessionRepository",
    "Agent",
    "AgentCreate",
    "Session",
    "SessionCreate",
]
```

- [ ] **Step 6: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_types.py -v`
Expected: PASS (5 tests)

- [ ] **Step 7: Commit**

```bash
git add src/pyclaw/ui/core/ tests/pyclaw/ui/core/
git commit -m "feat(ui): add types and repository interfaces

- Agent, Session data models with from_dict/to_dict
- AgentCreate, SessionCreate for creation
- AgentRepository, SessionRepository abstract interfaces
- Unit tests for data models

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

### Task 4: BaseController 和 BasePanel

**Files:**
- Create: `src/pyclaw/ui/core/base_controller.py`
- Create: `src/pyclaw/ui/core/base_panel.py`
- Test: `tests/pyclaw/ui/core/test_base_controller.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/pyclaw/ui/core/test_base_controller.py
"""BaseController 单元测试。"""
from __future__ import annotations

import pytest

from pyclaw.ui.core.base_controller import BaseController
from pyclaw.ui.core.event_bus import EventBus


class MockController(BaseController):
    """测试用模拟控制器。"""

    def __init__(self, event_bus: EventBus | None = None) -> None:
        super().__init__(event_bus)
        self.initialized = False
        self.disposed = False

    async def _on_initialize(self) -> None:
        self.initialized = True

    async def _on_dispose(self) -> None:
        self.disposed = True


class TestBaseController:
    """BaseController 测试。"""

    @pytest.mark.asyncio
    async def test_initialize_calls_on_initialize(self) -> None:
        """initialize 应调用 _on_initialize。"""
        ctrl = MockController()
        assert not ctrl.initialized

        await ctrl.initialize()

        assert ctrl.initialized
        assert ctrl._initialized

    @pytest.mark.asyncio
    async def test_initialize_is_idempotent(self) -> None:
        """多次 initialize 只调用一次 _on_initialize。"""
        ctrl = MockController()

        await ctrl.initialize()
        await ctrl.initialize()

        # _on_initialize 只应被调用一次
        assert ctrl.initialized

    @pytest.mark.asyncio
    async def test_dispose_clears_unsubscribes(self) -> None:
        """dispose 应调用所有取消函数。"""
        ctrl = MockController()
        called: list[str] = []

        ctrl._add_unsubscribe(lambda: called.append("first"))
        ctrl._add_unsubscribe(lambda: called.append("second"))

        await ctrl.dispose()

        assert called == ["first", "second"]
        assert not ctrl._initialized
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_base_controller.py -v`
Expected: FAIL with "ModuleNotFoundError: No module named 'pyclaw.ui.core.base_controller'"

- [ ] **Step 3: Write BaseController implementation**

```python
# src/pyclaw/ui/core/base_controller.py
"""控制器基类 — 管理业务逻辑和状态生命周期。"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from .event_bus import EventBus


class BaseController(ABC):
    """控制器的抽象基类，管理生命周期和资源清理。

    子类需要实现:
        - _on_initialize(): 初始化逻辑
        - _on_dispose(): 清理逻辑（可选）
    """

    def __init__(self, event_bus: EventBus | None = None) -> None:
        self._event_bus = event_bus
        self._initialized = False
        self._unsubscribes: list[Callable[[], None]] = []

    async def initialize(self) -> None:
        """初始化控制器，加载初始数据。"""
        if self._initialized:
            return
        await self._on_initialize()
        self._initialized = True

    async def dispose(self) -> None:
        """清理资源，取消所有订阅。"""
        # 调用所有取消函数
        for unsubscribe in self._unsubscribes:
            try:
                unsubscribe()
            except Exception:
                pass
        self._unsubscribes.clear()

        await self._on_dispose()
        self._initialized = False

    def _add_unsubscribe(self, fn: Callable[[], None]) -> None:
        """添加取消函数到清理列表。"""
        self._unsubscribes.append(fn)

    @abstractmethod
    async def _on_initialize(self) -> None:
        """子类实现初始化逻辑。"""
        ...

    async def _on_dispose(self) -> None:
        """子类可选实现清理逻辑。"""
        pass
```

- [ ] **Step 4: Write BasePanel implementation**

```python
# src/pyclaw/ui/core/base_panel.py
"""面板基类 — 统一 UI 面板的生命周期和通用行为。"""
from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Callable

import flet as ft

if TYPE_CHECKING:
    from .base_controller import BaseController

logger = logging.getLogger(__name__)


class BasePanel(ft.Column, ABC):
    """所有功能面板的抽象基类。

    子类需要实现:
        - _build_header(): 构建面板头部
        - _build_content(): 构建面板内容
        - _refresh_data(): 刷新数据（可选）
    """

    def __init__(self, controller: BaseController) -> None:
        super().__init__(expand=True, spacing=0)
        self._controller = controller
        self._mounted = False
        self._unsubscribes: list[Callable[[], None]] = []
        self._last_error: str | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        """构建 UI 结构。"""
        self.controls = [
            self._build_header(),
            self._build_content(),
        ]

    @abstractmethod
    def _build_header(self) -> ft.Control:
        """构建面板头部。"""
        ...

    @abstractmethod
    def _build_content(self) -> ft.Control:
        """构建面板内容区域。"""
        ...

    async def on_mount(self) -> None:
        """面板挂载时调用，初始化数据。"""
        self._mounted = True
        await self._controller.initialize()
        await self._refresh_data()

    async def on_unmount(self) -> None:
        """面板卸载时调用，清理资源。"""
        self._mounted = False

        # 取消所有订阅
        for unsubscribe in self._unsubscribes:
            try:
                unsubscribe()
            except Exception:
                pass
        self._unsubscribes.clear()

        await self._controller.dispose()

    async def _refresh_data(self) -> None:
        """刷新面板数据，子类可重写。"""
        pass

    def _add_unsubscribe(self, fn: Callable[[], None]) -> None:
        """添加取消函数到清理列表。"""
        self._unsubscribes.append(fn)

    def _safe_update(self, control: ft.Control | None = None) -> None:
        """安全更新控件，避免页面未挂载时的错误。"""
        target = control or self
        try:
            if target.page:
                target.update()
            else:
                logger.debug("Update skipped: control not mounted")
        except RuntimeError:
            pass

    def _show_error(self, message: str) -> None:
        """显示错误提示。"""
        if self.page:
            snack = ft.SnackBar(content=ft.Text(message), bgcolor=ft.Colors.ERROR)
            self.page.overlay.append(snack)
            snack.open = True
            self.page.update()

    def _show_success(self, message: str) -> None:
        """显示成功提示。"""
        if self.page:
            snack = ft.SnackBar(content=ft.Text(message))
            self.page.overlay.append(snack)
            snack.open = True
            self.page.update()

    def _fire_async(
        self,
        coro: Any,
        *,
        on_error: Callable[[Exception], None] | None = None,
        on_success: Callable[[], None] | None = None,
    ) -> None:
        """安全执行异步任务，自动处理异常。

        Args:
            coro: 协程对象
            on_error: 错误回调，默认显示 SnackBar
            on_success: 成功回调
        """
        async def _run() -> None:
            try:
                await coro
                if on_success:
                    on_success()
            except Exception as e:
                if on_error:
                    on_error(e)
                else:
                    self._show_error(str(e))

        # Callback 中通常已有运行中的事件循环
        asyncio.create_task(_run())
```

- [ ] **Step 5: Update core __init__.py**

```python
# src/pyclaw/ui/core/__init__.py
"""UI 核心基础设施模块。"""
from .base_controller import BaseController
from .base_panel import BasePanel
from .event_bus import EventBus
from .events import AppEvents
from .reactive import Reactive
from .repository import AgentRepository, SessionRepository
from .types import Agent, AgentCreate, Session, SessionCreate

__all__ = [
    "BaseController",
    "BasePanel",
    "EventBus",
    "AppEvents",
    "Reactive",
    "AgentRepository",
    "SessionRepository",
    "Agent",
    "AgentCreate",
    "Session",
    "SessionCreate",
]
```

- [ ] **Step 6: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_base_controller.py -v`
Expected: PASS (3 tests)

- [ ] **Step 7: Commit**

```bash
git add src/pyclaw/ui/core/ tests/pyclaw/ui/core/
git commit -m "feat(ui): add BaseController and BasePanel

- BaseController with lifecycle management
- BasePanel with safe update and async helpers
- _add_unsubscribe for cleanup tracking
- Unit tests for BaseController

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

### Task 5: GatewayService 和 Testing Mocks

**Files:**
- Create: `src/pyclaw/ui/core/gateway_service.py`
- Create: `src/pyclaw/ui/core/testing.py`
- Test: `tests/pyclaw/ui/core/test_gateway_service.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/pyclaw/ui/core/test_gateway_service.py
"""GatewayService 单元测试。"""
from __future__ import annotations

import pytest

from pyclaw.ui.core.gateway_service import GatewayError, GatewayService
from pyclaw.ui.core.testing import MockGatewayClient


class TestGatewayService:
    """GatewayService 测试。"""

    @pytest.mark.asyncio
    async def test_connected_property(self) -> None:
        """connected 属性应反映连接状态。"""
        mock_client = MockGatewayClient()
        service = GatewayService(mock_client)

        assert not service.connected.value

        await service.connect()

        assert service.connected.value

    @pytest.mark.asyncio
    async def test_list_agents(self) -> None:
        """list_agents 应返回 Agent 列表。"""
        mock_client = MockGatewayClient(
            responses={
                "agents.list": {"agents": [{"id": "a1", "name": "Agent 1"}]},
            }
        )
        service = GatewayService(mock_client)
        await service.connect()

        agents = await service.list_agents()

        assert len(agents) == 1
        assert agents[0]["id"] == "a1"

    @pytest.mark.asyncio
    async def test_call_when_disconnected_raises_error(self) -> None:
        """断开时调用应抛出 GatewayError。"""
        mock_client = MockGatewayClient()
        service = GatewayService(mock_client)
        # 不连接

        with pytest.raises(GatewayError) as exc_info:
            await service.list_agents()

        assert exc_info.value.code == "NOT_CONNECTED"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_gateway_service.py -v`
Expected: FAIL

- [ ] **Step 3: Write GatewayService implementation**

参考设计文档 `docs/superpowers/specs/2026-04-06-ui-architecture-refactor-design.md` 第 3.4 节

- [ ] **Step 4: Write testing mocks**

参考设计文档 `docs/superpowers/specs/2026-04-06-ui-architecture-refactor-design.md` 第 3.8 节

- [ ] **Step 5: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/core/test_gateway_service.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/pyclaw/ui/core/ tests/pyclaw/ui/core/
git commit -m "feat(ui): add GatewayService and testing mocks

- GatewayService wraps raw GatewayClient
- MockGatewayClient for testing
- MockAgentRepository, MockSessionRepository
- wait_connected uses asyncio.Event

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

## Phase 2: 组件库抽取

### Task 6: 拆分 components.py

**Files:**
- Create: `src/pyclaw/ui/components/__init__.py`
- Create: `src/pyclaw/ui/components/tiles.py`
- Create: `src/pyclaw/ui/components/forms.py`
- Create: `src/pyclaw/ui/components/status.py`
- Create: `src/pyclaw/ui/components/empty_state.py`
- Create: `src/pyclaw/ui/components/page_header.py`
- Modify: `src/pyclaw/ui/components.py` (保留兼容导出)

- [ ] **Step 1: Create components directory**

```bash
mkdir -p src/pyclaw/ui/components
```

- [ ] **Step 2: Extract tiles.py**

从 `src/pyclaw/ui/components.py` 提取 `card_tile` 到 `tiles.py`

- [ ] **Step 3: Extract forms.py**

从 `src/pyclaw/ui/components.py` 提取 `slider_input`, `switch_with_info` 到 `forms.py`

- [ ] **Step 4: Extract status.py**

从 `src/pyclaw/ui/components.py` 提取 `status_chip`, `streaming_indicator` 到 `status.py`

- [ ] **Step 5: Extract empty_state.py**

从 `src/pyclaw/ui/components.py` 提取 `empty_state`, `error_state`, `empty_state_simple` 到 `empty_state.py`

- [ ] **Step 6: Extract page_header.py**

从 `src/pyclaw/ui/components.py` 提取 `page_header`, `expandable_section` 到 `page_header.py`

- [ ] **Step 7: Create components __init__.py**

```python
# src/pyclaw/ui/components/__init__.py
"""可复用 UI 组件库。"""
from .empty_state import empty_state, empty_state_simple, error_state
from .forms import slider_input, switch_with_info
from .page_header import expandable_section, page_header
from .status import status_chip, streaming_indicator
from .tiles import card_tile

__all__ = [
    "card_tile",
    "empty_state",
    "empty_state_simple",
    "error_state",
    "expandable_section",
    "page_header",
    "slider_input",
    "status_chip",
    "streaming_indicator",
    "switch_with_info",
]
```

- [ ] **Step 8: Update old components.py for backward compatibility**

```python
# src/pyclaw/ui/components.py
"""向后兼容导出 — 新代码请使用 pyclaw.ui.components 模块。"""
from pyclaw.ui.components import *  # noqa: F401, F403
```

- [ ] **Step 9: Run existing tests**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/ -v -k component`
Expected: PASS

- [ ] **Step 10: Commit**

```bash
git add src/pyclaw/ui/components/
git commit -m "refactor(ui): split components.py into modules

- tiles.py: card_tile
- forms.py: slider_input, switch_with_info
- status.py: status_chip, streaming_indicator
- empty_state.py: empty_state, error_state
- page_header.py: page_header, expandable_section
- Keep backward compatibility in components.py

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

## Phase 3: Agents 面板迁移（首个 MVC 示例）

### Task 7: Agents 面板 MVC 实现

**Files:**
- Create: `src/pyclaw/ui/panels/__init__.py`
- Create: `src/pyclaw/ui/panels/agents/__init__.py`
- Create: `src/pyclaw/ui/panels/agents/model.py`
- Create: `src/pyclaw/ui/panels/agents/state.py`
- Create: `src/pyclaw/ui/panels/agents/controller.py`
- Create: `src/pyclaw/ui/panels/agents/view.py`
- Create: `src/pyclaw/ui/panels/agents/local_repository.py`
- Test: `tests/pyclaw/ui/panels/agents/test_controller.py`

- [ ] **Step 1: Create panels directory structure**

```bash
mkdir -p src/pyclaw/ui/panels/agents
touch src/pyclaw/ui/panels/__init__.py
```

- [ ] **Step 2: Write AgentsState**

参考设计文档第 4.1 节

- [ ] **Step 3: Write AgentsController with tests**

参考设计文档第 4.2 节和测试示例

- [ ] **Step 4: Write LocalAgentRepository**

参考设计文档第 4.4 节

- [ ] **Step 5: Write AgentsView**

参考设计文档第 4.3 节

- [ ] **Step 6: Write __init__.py with backward compatible build function**

参考设计文档第 4.5 节

- [ ] **Step 7: Run tests**

Run: `source .venv/bin/activate && pytest tests/pyclaw/ui/panels/agents/ -v`
Expected: PASS

- [ ] **Step 8: Integration test - verify old imports still work**

Run: `source .venv/bin/activate && python -c "from pyclaw.ui.agents_panel import build_agents_panel; print('OK')"`
Expected: OK (with deprecation warning)

- [ ] **Step 9: Commit**

```bash
git add src/pyclaw/ui/panels/ tests/pyclaw/ui/panels/
git commit -m "feat(ui): migrate Agents panel to MVC architecture

- AgentsState with reactive state
- AgentsController with business logic
- AgentsView with UI rendering
- LocalAgentRepository for file system
- Backward compatible build_agents_panel()

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

## Phase 4: 主应用集成

### Task 8: 更新 PyClawApp 使用新架构

**Files:**
- Modify: `src/pyclaw/ui/app.py`

- [ ] **Step 1: Add EventBus initialization**

在 `PyClawApp.__init__` 中初始化 `EventBus`

- [ ] **Step 2: Update panel creation to use new MVC**

替换 `_agents_panel` 等的创建方式

- [ ] **Step 3: Implement proper lifecycle in _navigate_to**

```python
async def _navigate_to(self, panel_name: str) -> None:
    # 卸载当前面板
    if self._current_panel:
        await self._current_panel.on_unmount()

    # 挂载新面板
    new_panel = self._panels.get(panel_name)
    if new_panel:
        self._content_area.controls = [new_panel]
        self._safe_update(self._content_area)
        await new_panel.on_mount()
        self._current_panel = new_panel
```

- [ ] **Step 4: Run full application test**

Run: `source .venv/bin/activate && python -m pyclaw ui --help`
Expected: Normal help output

- [ ] **Step 5: Commit**

```bash
git add src/pyclaw/ui/app.py
git commit -m "refactor(ui): integrate MVC panels into PyClawApp

- Initialize EventBus in app
- Proper lifecycle management in _navigate_to
- Update panel creation to use new architecture

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
```

---

## Phase 5: 后续面板迁移模板

剩余面板（Sessions, Overview, Channels 等）按照 Agents 面板的模式迁移：

每个面板迁移任务结构相同：

1. 创建 `panels/<name>/` 目录
2. 实现 `state.py` — 响应式状态
3. 实现 `controller.py` — 业务逻辑
4. 实现 `view.py` — UI 渲染
5. 实现 `local_repository.py` — 数据访问（如需要）
6. 添加单元测试
7. 更新 `__init__.py` 提供向后兼容的 `build_<name>_panel()`
8. 提交

### 迁移优先级

| 优先级 | 面板 | 复杂度 | 原因 |
|--------|------|--------|------|
| P0 | Sessions | 中 | 高频使用 |
| P0 | Overview | 低 | 入口面板 |
| P1 | Channels | 中 | 核心功能 |
| P1 | Config | 中 | 配置管理 |
| P2 | Plans | 中 | 计划功能 |
| P2 | Skills | 中 | 技能管理 |
| P3 | 其余面板 | - | 逐步迁移 |

---

## 自检清单

- [ ] 所有新建文件有完整实现（无 TBD/TODO）
- [ ] 所有测试通过
- [ ] 类型注解完整，通过 mypy 检查
- [ ] 向后兼容层正常工作
- [ ] 设计规范中的所有决策已落实

---

## 执行选项

**Plan complete and saved to `docs/superpowers/plans/2026-04-07-ui-architecture-refactor.md`**

**Two execution options:**

1. **Subagent-Driven (recommended)** - I dispatch a fresh subagent per task, review between tasks, fast iteration

2. **Inline Execution** - Execute tasks in this session using executing-plans, batch execution with checkpoints

**Which approach?**
