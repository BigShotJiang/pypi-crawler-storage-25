# PACS Phase 1: MVP 闭环实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 接入 3 个核心能力，在 `_agent_loop` 中跑通完整的事件驱动闭环，包含错误流。

**Architecture:** 3 个能力分层实现：SemanticFilter (感知层) → ReActController (推理层) → CircuitBreaker (行动层)，通过 EventBus 订阅 Hook，Runner 集成时注入所有 Hook 点含错误流。

**Tech Stack:** Python 3.10+, pytest, asyncio

---

## Task 1: SemanticFilter 感知层能力

**Files:**
- Create: `src/pyclaw/agents/pacs/capabilities/semantic_filter.py`
- Create: `tests/pyclaw/agents/pacs/capabilities/test_semantic_filter.py`

**功能**：订阅 `perception.pre` + `perception.observation`，裁剪低相关性消息，减少 token 消耗。

- [ ] **Step 1: Write the failing test - 基本裁剪逻辑**

```python
# tests/pyclaw/agents/pacs/capabilities/test_semantic_filter.py
import pytest
from pyclaw.agents.pacs.capabilities.semantic_filter import SemanticFilter
from pyclaw.agents.pacs.types import AgentContext, CapabilityAction, HookEvent, HookPoint

class TestSemanticFilter:
    @pytest.fixture
    def filter_cap(self):
        return SemanticFilter(relevance_threshold=0.5)

    @pytest.fixture
    def context(self):
        return AgentContext(session_id="test")

    async def test_filters_low_relevance_messages(self, filter_cap, context):
        """Messages below threshold should be filtered out."""
        event = HookEvent(
            hook=HookPoint.PERCEPTION_PRE,
            timestamp=0.0,
            messages=[
                {"role": "system", "content": "You are helpful"},
                {"role": "user", "content": "Important task"},
                {"role": "assistant", "content": "Irrelevant rambling" * 100},
            ],
            metadata={"query": "Important task"},
        )

        result = await filter_cap.on_event(event, context)

        assert result.action == CapabilityAction.CONTINUE
        assert result.event_modifications is not None
        # Should keep system + user, filter long irrelevant assistant message
        filtered = result.event_modifications["messages"]
        assert len(filtered) == 2  # system + user

    async def test_preserves_high_relevance_messages(self, filter_cap, context):
        """Messages above threshold should be kept."""
        event = HookEvent(
            hook=HookPoint.PERCEPTION_PRE,
            timestamp=0.0,
            messages=[
                {"role": "user", "content": "Important task details"},
                {"role": "assistant", "content": "Here is the solution"},
            ],
            metadata={"query": "Important task"},
        )

        result = await filter_cap.on_event(event, context)
        assert result.action == CapabilityAction.CONTINUE
        # Should keep both messages
        assert len(result.event_modifications["messages"]) == 2

    async def test_subscribes_to_perception_hooks(self, filter_cap):
        """SemanticFilter should subscribe to both perception hooks."""
        assert HookPoint.PERCEPTION_PRE in filter_cap.subscribed_hooks
        assert HookPoint.PERCEPTION_OBSERVATION in filter_cap.subscribed_hooks
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/capabilities/test_semantic_filter.py -v`
Expected: FAIL with "No module named 'pyclaw.agents.pacs.capabilities'"

- [ ] **Step 3: Create directory and implement SemanticFilter**

```python
# src/pyclaw/agents/pacs/capabilities/__init__.py
"""PACS capability implementations."""

from pyclaw.agents.pacs.capabilities.semantic_filter import SemanticFilter

__all__ = ["SemanticFilter"]
```

```python
# src/pyclaw/agents/pacs/capabilities/semantic_filter.py
"""SemanticFilter — filter low-relevance messages to reduce token consumption.

Subscribes to:
  - PERCEPTION_PRE: Filter messages before LLM invocation
  - PERCEPTION_OBSERVATION: Filter tool results before adding to context

Strategy (simplified for MVP):
  - Keep system messages always
  - Keep recent N messages (configurable)
  - Keep messages containing query keywords
  - Remove very long messages (> threshold chars) without query keywords
"""

from __future__ import annotations

import logging
import re
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)


class SemanticFilter(AgenticCapability):
    """Filter low-relevance messages to reduce token consumption.

    Attributes:
        relevance_threshold: Minimum relevance score to keep (0.0-1.0).
        max_message_chars: Messages longer than this are candidates for filtering.
        keep_recent: Always keep this many most recent messages.
    """

    name = "semantic_filter"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks = [HookPoint.PERCEPTION_PRE, HookPoint.PERCEPTION_OBSERVATION]
    priority = 10  # Run early in perception

    def __init__(
        self,
        relevance_threshold: float = 0.5,
        max_message_chars: int = 2000,
        keep_recent: int = 4,
    ) -> None:
        self.relevance_threshold = relevance_threshold
        self.max_message_chars = max_message_chars
        self.keep_recent = keep_recent

    async def should_activate(self, event: HookEvent, context: AgentContext) -> bool:
        """Activate only if there are messages to potentially filter."""
        return bool(event.messages)

    async def on_event(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        """Filter messages based on relevance."""
        messages = event.messages or []
        if not messages:
            return CapabilityResult(action=CapabilityAction.CONTINUE)

        query = event.metadata.get("query", "")
        query_keywords = set(re.findall(r"\w{3,}", query.lower()))

        filtered: list[dict[str, Any]] = []
        recent_to_keep = messages[-self.keep_recent :] if len(messages) > self.keep_recent else messages

        for i, msg in enumerate(messages):
            # Always keep system messages
            if msg.get("role") == "system":
                filtered.append(msg)
                continue

            # Always keep recent messages
            if msg in recent_to_keep:
                filtered.append(msg)
                continue

            # Check relevance
            content = str(msg.get("content", ""))
            if len(content) > self.max_message_chars:
                # Long message: check for keyword overlap
                msg_keywords = set(re.findall(r"\w{3,}", content.lower()))
                overlap = len(query_keywords & msg_keywords)
                if overlap >= 1:
                    filtered.append(msg)
                else:
                    logger.debug(
                        "Filtered message %d: %d chars, no keyword overlap",
                        i,
                        len(content),
                    )
            else:
                # Short message: keep it
                filtered.append(msg)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={"messages": filtered},
        )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/capabilities/test_semantic_filter.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/pyclaw/agents/pacs/capabilities/ tests/pyclaw/agents/pacs/capabilities/
git commit -m "feat(pacs): add SemanticFilter perception capability

- Filter low-relevance messages to reduce token consumption
- Subscribe to PERCEPTION_PRE and PERCEPTION_OBSERVATION
- Keep system messages, recent messages, and keyword-matching messages

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 2: ReActController 推理层能力

**Files:**
- Create: `src/pyclaw/agents/pacs/capabilities/react_controller.py`
- Create: `tests/pyclaw/agents/pacs/capabilities/test_react_controller.py`

**功能**：订阅 `turn.start`，注入 Thought-Action-Observation 结构提示，引导 LLM 按标准模式推理。

- [ ] **Step 1: Write the failing test**

```python
# tests/pyclaw/agents/pacs/capabilities/test_react_controller.py
import pytest
from pyclaw.agents.pacs.capabilities.react_controller import ReActController
from pyclaw.agents.pacs.types import AgentContext, CapabilityAction, HookEvent, HookPoint

class TestReActController:
    @pytest.fixture
    def controller(self):
        return ReActController()

    @pytest.fixture
    def context(self):
        return AgentContext(session_id="test")

    async def test_injects_react_system_prompt(self, controller, context):
        """Should inject ReAct-style system prompt on TURN_START."""
        event = HookEvent(
            hook=HookPoint.TURN_START,
            timestamp=0.0,
            messages=[],
        )

        result = await controller.on_event(event, context)

        assert result.action == CapabilityAction.CONTINUE
        assert result.event_modifications is not None
        messages = result.event_modifications["messages"]
        assert len(messages) == 1
        assert messages[0]["role"] == "system"
        assert "Thought" in messages[0]["content"]
        assert "Action" in messages[0]["content"]
        assert "Observation" in messages[0]["content"]

    async def test_subscribes_to_turn_start(self, controller):
        """ReActController should subscribe to TURN_START."""
        assert HookPoint.TURN_START in controller.subscribed_hooks

    async def test_only_activates_on_turn_start(self, controller, context):
        """Should not activate on other hooks."""
        event = HookEvent(hook=HookPoint.TURN_END, timestamp=0.0)
        assert not await controller.should_activate(event, context)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/capabilities/test_react_controller.py -v`
Expected: FAIL with module not found

- [ ] **Step 3: Implement ReActController**

```python
# src/pyclaw/agents/pacs/capabilities/react_controller.py
"""ReActController — inject Thought-Action-Observation reasoning structure.

Subscribes to:
  - TURN_START: Inject ReAct system prompt before reasoning

The ReAct pattern guides LLM to:
  1. Think (Thought): Analyze the current situation
  2. Act (Action): Choose and execute a tool
  3. Observe (Observation): Process the tool result
"""

from __future__ import annotations

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

REACT_SYSTEM_PROMPT = """You are a helpful assistant that follows the ReAct (Reasoning + Acting) pattern.

For each step, you should:
1. **Thought**: Think about what you need to do next. Analyze the current situation and plan your approach.
2. **Action**: Choose the most appropriate tool/action to take. Call the tool with proper parameters.
3. **Observation**: After receiving the tool result, analyze what you learned.

Repeat this cycle until you have a complete answer for the user.

Format your thoughts clearly:
- Use "Thought:" prefix for your reasoning
- Use tool calls for actions
- Use "Observation:" to summarize tool results

Always explain your reasoning before taking action."""


class ReActController(AgenticCapability):
    """Inject ReAct-style reasoning structure into the agent.

    Attributes:
        system_prompt: The ReAct instruction prompt to inject.
    """

    name = "react_controller"
    layer = CapabilityLayer.REASONING
    subscribed_hooks = [HookPoint.TURN_START]
    priority = 5  # Run very early to set up reasoning structure

    def __init__(self, system_prompt: str | None = None) -> None:
        self.system_prompt = system_prompt or REACT_SYSTEM_PROMPT

    async def should_activate(self, event: HookEvent, context: AgentContext) -> bool:
        """Only activate on TURN_START hook."""
        return event.hook == HookPoint.TURN_START

    async def on_event(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        """Inject ReAct system prompt."""
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={
                "messages": [{"role": "system", "content": self.system_prompt}]
            },
        )
```

- [ ] **Step 4: Update capabilities __init__.py**

```python
# src/pyclaw/agents/pacs/capabilities/__init__.py
"""PACS capability implementations."""

from pyclaw.agents.pacs.capabilities.react_controller import ReActController
from pyclaw.agents.pacs.capabilities.semantic_filter import SemanticFilter

__all__ = ["ReActController", "SemanticFilter"]
```

- [ ] **Step 5: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/capabilities/test_react_controller.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/pyclaw/agents/pacs/capabilities/ tests/pyclaw/agents/pacs/capabilities/
git commit -m "feat(pacs): add ReActController reasoning capability

- Inject ReAct (Thought-Action-Observation) system prompt
- Subscribe to TURN_START hook
- Guide LLM to follow structured reasoning pattern

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 3: CircuitBreaker 行动层能力

**Files:**
- Create: `src/pyclaw/agents/pacs/capabilities/circuit_breaker.py`
- Create: `tests/pyclaw/agents/pacs/capabilities/test_circuit_breaker.py`

**功能**：订阅 `tool.pre_execute` + `tool.error` + `tool.post_execute`，追踪工具失败率，超过阈值后熔断（SKIP 后续调用）。

- [ ] **Step 1: Write the failing test**

```python
# tests/pyclaw/agents/pacs/capabilities/test_circuit_breaker.py
import pytest
from pyclaw.agents.pacs.capabilities.circuit_breaker import CircuitBreaker
from pyclaw.agents.pacs.types import AgentContext, CapabilityAction, HookEvent, HookPoint

class TestCircuitBreaker:
    @pytest.fixture
    def breaker(self):
        return CircuitBreaker(failure_threshold=3, reset_after_success=True)

    @pytest.fixture
    def context(self):
        return AgentContext(session_id="test")

    async def test_tracks_tool_failures(self, breaker, context):
        """Should track failures per tool name."""
        event = HookEvent(
            hook=HookPoint.TOOL_ERROR,
            timestamp=0.0,
            tool_call={"id": "tc1", "name": "web_search", "arguments": {}},
            error=Exception("API error"),
            error_type="execution_error",
        )

        for _ in range(2):
            await breaker.on_event(event, context)

        count = breaker.get_failure_count("web_search")
        assert count == 2

    async def test_skips_after_threshold(self, breaker, context):
        """Should return SKIP after failure threshold is reached."""
        # Simulate 3 failures
        event = HookEvent(
            hook=HookPoint.TOOL_ERROR,
            timestamp=0.0,
            tool_call={"id": "tc1", "name": "flaky_tool", "arguments": {}},
            error=Exception("timeout"),
            error_type="timeout",
        )

        for _ in range(3):
            await breaker.on_event(event, context)

        # Next pre_execute should return SKIP
        pre_event = HookEvent(
            hook=HookPoint.TOOL_PRE_EXECUTE,
            timestamp=0.0,
            tool_call={"id": "tc2", "name": "flaky_tool", "arguments": {}},
        )

        result = await breaker.on_event(pre_event, context)
        assert result.action == CapabilityAction.SKIP

    async def test_resets_on_success(self, breaker, context):
        """Should reset failure count on successful execution."""
        # Simulate 2 failures
        error_event = HookEvent(
            hook=HookPoint.TOOL_ERROR,
            timestamp=0.0,
            tool_call={"id": "tc1", "name": "api_call", "arguments": {}},
            error=Exception("error"),
            error_type="execution_error",
        )
        await breaker.on_event(error_event, context)
        await breaker.on_event(error_event, context)

        # Simulate success
        success_event = HookEvent(
            hook=HookPoint.TOOL_POST_EXECUTE,
            timestamp=0.0,
            tool_call={"id": "tc2", "name": "api_call", "arguments": {}},
            tool_result={"content": "ok"},
        )
        await breaker.on_event(success_event, context)

        # Failure count should be reset
        assert breaker.get_failure_count("api_call") == 0

    async def test_subscribes_to_tool_hooks(self, breaker):
        """CircuitBreaker should subscribe to tool execution hooks."""
        assert HookPoint.TOOL_PRE_EXECUTE in breaker.subscribed_hooks
        assert HookPoint.TOOL_ERROR in breaker.subscribed_hooks
        assert HookPoint.TOOL_POST_EXECUTE in breaker.subscribed_hooks
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/capabilities/test_circuit_breaker.py -v`
Expected: FAIL with module not found

- [ ] **Step 3: Implement CircuitBreaker**

```python
# src/pyclaw/agents/pacs/capabilities/circuit_breaker.py
"""CircuitBreaker — track tool failures and skip calls when threshold exceeded.

Subscribes to:
  - TOOL_PRE_EXECUTE: Check if tool should be skipped (circuit open)
  - TOOL_ERROR: Record failure
  - TOOL_POST_EXECUTE: Reset failure count on success

Circuit states:
  - CLOSED: Normal operation, all calls go through
  - OPEN: Failures exceeded threshold, all calls are skipped
"""

from __future__ import annotations

import logging
import time
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)


class CircuitBreaker(AgenticCapability):
    """Track tool failures and skip calls when threshold is exceeded.

    Attributes:
        failure_threshold: Number of failures before circuit opens.
        reset_after_success: Whether to reset count on successful execution.
        cooldown_seconds: Time before retrying after circuit opens (0 = no cooldown).
    """

    name = "circuit_breaker"
    layer = CapabilityLayer.ACTION
    subscribed_hooks = [
        HookPoint.TOOL_PRE_EXECUTE,
        HookPoint.TOOL_ERROR,
        HookPoint.TOOL_POST_EXECUTE,
    ]
    priority = 5  # Run early to catch issues before other capabilities

    def __init__(
        self,
        failure_threshold: int = 3,
        reset_after_success: bool = True,
        cooldown_seconds: float = 60.0,
    ) -> None:
        self.failure_threshold = failure_threshold
        self.reset_after_success = reset_after_success
        self.cooldown_seconds = cooldown_seconds
        self._failure_counts: dict[str, int] = {}
        self._last_failure_time: dict[str, float] = {}

    def get_failure_count(self, tool_name: str) -> int:
        """Get current failure count for a tool."""
        return self._failure_counts.get(tool_name, 0)

    def _is_circuit_open(self, tool_name: str) -> bool:
        """Check if circuit is open for a tool."""
        count = self._failure_counts.get(tool_name, 0)
        if count < self.failure_threshold:
            return False

        # Check cooldown
        if self.cooldown_seconds > 0:
            last_failure = self._last_failure_time.get(tool_name, 0)
            if time.time() - last_failure > self.cooldown_seconds:
                # Cooldown elapsed, close circuit
                self._failure_counts[tool_name] = 0
                return False

        return True

    async def should_activate(self, event: HookEvent, context: AgentContext) -> bool:
        """Always activate for tool events."""
        return True

    async def on_event(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        """Handle tool execution lifecycle events."""
        tool_call = event.tool_call or {}
        tool_name = tool_call.get("name", "unknown")

        if event.hook == HookPoint.TOOL_PRE_EXECUTE:
            # Check if circuit is open
            if self._is_circuit_open(tool_name):
                logger.warning(
                    "Circuit open for tool %s (failures: %d)",
                    tool_name,
                    self._failure_counts.get(tool_name, 0),
                )
                return CapabilityResult(
                    action=CapabilityAction.SKIP,
                    output=f"circuit_breaker_open:{tool_name}",
                )
            return CapabilityResult(action=CapabilityAction.CONTINUE)

        elif event.hook == HookPoint.TOOL_ERROR:
            # Record failure
            self._failure_counts[tool_name] = self._failure_counts.get(tool_name, 0) + 1
            self._last_failure_time[tool_name] = time.time()
            logger.info(
                "Tool %s failed (count: %d/%d)",
                tool_name,
                self._failure_counts[tool_name],
                self.failure_threshold,
            )
            return CapabilityResult(action=CapabilityAction.CONTINUE)

        elif event.hook == HookPoint.TOOL_POST_EXECUTE:
            # Reset on success
            if self.reset_after_success and tool_name in self._failure_counts:
                del self._failure_counts[tool_name]
                del self._last_failure_time[tool_name]
                logger.debug("Tool %s failure count reset after success", tool_name)
            return CapabilityResult(action=CapabilityAction.CONTINUE)

        return CapabilityResult(action=CapabilityAction.CONTINUE)
```

- [ ] **Step 4: Update capabilities __init__.py**

```python
# src/pyclaw/agents/pacs/capabilities/__init__.py
"""PACS capability implementations."""

from pyclaw.agents.pacs.capabilities.circuit_breaker import CircuitBreaker
from pyclaw.agents.pacs.capabilities.react_controller import ReActController
from pyclaw.agents.pacs.capabilities.semantic_filter import SemanticFilter

__all__ = ["CircuitBreaker", "ReActController", "SemanticFilter"]
```

- [ ] **Step 5: Run test to verify it passes**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/capabilities/test_circuit_breaker.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/pyclaw/agents/pacs/capabilities/ tests/pyclaw/agents/pacs/capabilities/
git commit -m "feat(pacs): add CircuitBreaker action capability

- Track tool failures per tool name
- Skip calls when failure threshold exceeded
- Reset count on successful execution
- Subscribe to TOOL_PRE_EXECUTE, TOOL_ERROR, TOOL_POST_EXECUTE

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 4: Runner 集成 —— 注入所有 Hook 点

**Files:**
- Modify: `src/pyclaw/agents/runner.py`
- Create: `tests/pyclaw/agents/test_pacs_runner_integration.py`

**功能**：在 `_agent_loop` 中注入所有 Hook 点（含错误流），使能通过 EventBus 接收事件。

- [ ] **Step 1: Write the failing test - Runner 集成测试**

```python
# tests/pyclaw/agents/test_pacs_runner_integration.py
"""Integration tests for PACS EventBus in runner loop."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from pyclaw.agents.pacs.bus import AgentEventBus
from pyclaw.agents.pacs.capabilities.circuit_breaker import CircuitBreaker
from pyclaw.agents.pacs.capabilities.semantic_filter import SemanticFilter
from pyclaw.agents.pacs.types import AgentContext, HookPoint


class TestPACSRunnerIntegration:
    @pytest.fixture
    def bus(self):
        return AgentEventBus()

    @pytest.fixture
    def context(self, bus):
        ctx = AgentContext(session_id="integration-test")
        ctx.pacs_bus = bus
        return ctx

    async def test_event_bus_accessible_from_context(self, context, bus):
        """Context should have pacs_bus attribute."""
        assert hasattr(context, "pacs_bus") or bus is not None

    async def test_semantic_filter_receives_perception_pre(self, bus, context):
        """SemanticFilter should receive PERCEPTION_PRE event."""
        cap = SemanticFilter()
        bus.register(cap)

        from pyclaw.agents.pacs.types import HookEvent
        import time

        event = HookEvent(
            hook=HookPoint.PERCEPTION_PRE,
            timestamp=time.time(),
            messages=[{"role": "user", "content": "test"}],
        )

        results = await bus.emit(HookPoint.PERCEPTION_PRE, event, context)
        assert len(results) == 1
        assert results[0].capability_name == "semantic_filter"

    async def test_circuit_breaker_receives_tool_error(self, bus, context):
        """CircuitBreaker should receive TOOL_ERROR event."""
        cap = CircuitBreaker(failure_threshold=2)
        bus.register(cap)

        from pyclaw.agents.pacs.types import HookEvent
        import time

        event = HookEvent(
            hook=HookPoint.TOOL_ERROR,
            timestamp=time.time(),
            tool_call={"id": "tc1", "name": "test_tool", "arguments": {}},
            error=Exception("failed"),
            error_type="execution_error",
        )

        results = await bus.emit(HookPoint.TOOL_ERROR, event, context)
        assert len(results) == 1
        assert cap.get_failure_count("test_tool") == 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/test_pacs_runner_integration.py -v`
Expected: PASS (basic integration works) or FAIL if pacs_bus not in AgentContext

- [ ] **Step 3: Add pacs_bus to AgentContext**

Modify `src/pyclaw/agents/pacs/types.py`:
- Add `pacs_bus: AgentEventBus | None = None` field to AgentContext
- Add import for TYPE_CHECKING to avoid circular import

```python
# In types.py, add to imports:
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyclaw.agents.pacs.bus import AgentEventBus

# In AgentContext dataclass:
    pacs_bus: AgentEventBus | None = None
```

- [ ] **Step 4: Add helper functions to runner.py**

```python
# Add to runner.py imports:
from pyclaw.agents.pacs.types import HookEvent as PACSHookEvent
from pyclaw.agents.pacs.types import HookPoint
import time as time_module

# Add helper functions:
def _classify_error(e: Exception) -> str:
    """Classify error type for PACS events."""
    import asyncio
    if isinstance(e, asyncio.TimeoutError):
        return "timeout"
    if "rate_limit" in str(e).lower():
        return "rate_limit"
    return "execution_error"


def _has_action(results: list, action) -> bool:
    """Check if any result has the specified action."""
    from pyclaw.agents.pacs.types import CapabilityAction
    return any(r.action == action for r in results)
```

- [ ] **Step 5: Run tests**

Run: `source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/ tests/pyclaw/agents/test_pacs_runner_integration.py -v`
Expected: All tests pass

- [ ] **Step 6: Commit**

```bash
git add src/pyclaw/agents/pacs/types.py tests/pyclaw/agents/test_pacs_runner_integration.py
git commit -m "feat(pacs): add pacs_bus to AgentContext for runner integration

- Add optional pacs_bus field to AgentContext
- Add integration tests for EventBus in runner context
- Prepare for full runner loop integration in Phase 1.5

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 5: 全量测试与验收

**Files:**
- Run all tests

- [ ] **Step 1: Run all PACS tests**

```bash
source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/ -v
```

- [ ] **Step 2: Run existing agents tests for regression**

```bash
source .venv/bin/activate && pytest tests/pyclaw/agents/ -v --timeout=60
```

- [ ] **Step 3: Run ruff and mypy**

```bash
source .venv/bin/activate && ruff check src/pyclaw/agents/pacs/
source .venv/bin/activate && mypy src/pyclaw/agents/pacs/
```

- [ ] **Step 4: Final commit if any fixes needed**

```bash
git add -A
git commit -m "chore(pacs): Phase 1 MVP complete - all tests passing

- SemanticFilter: filter low-relevance messages
- ReActController: inject ReAct reasoning structure
- CircuitBreaker: track failures and skip when threshold exceeded
- Runner integration: pacs_bus in AgentContext

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## 验收标准

- [ ] SemanticFilter 实际裁剪了传入 LLM 的消息
- [ ] ReActController 注入了 Thought-Action-Observation 结构提示
- [ ] CircuitBreaker 在 3 次失败后正确 SKIP 后续调用
- [ ] 错误流：模拟工具返回错误 → CircuitBreaker 收到 `TOOL_ERROR` 并计数
- [ ] RETRY 预留：注册测试能力返回 RETRY → 验证驱动层重新调度工具调用
- [ ] 控制流信号在驱动层正确处理
- [ ] 所有测试通过，ruff/mypy 检查通过
