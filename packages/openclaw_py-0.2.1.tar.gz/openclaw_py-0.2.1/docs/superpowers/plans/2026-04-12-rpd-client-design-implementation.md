# RPD Client Design Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement UI enhancements from RPD_CLIENT_DESIGN.md, enriching existing panels with new components and improved UX.

**Architecture:** Incremental enhancement approach - add features to existing panels without breaking changes. Use existing component patterns and MVC structure. (Note: This plan predates the TypeScript migration; the Flet UI has been retired.)

**Tech Stack:** TypeScript, Next.js, shadcn/ui, Zustand, TanStack Query

---

## Task 1: Settings Panel Refactoring - Collapsible Sections

**Files:**
- Modify: `src/pyclaw/ui/panels/settings/view.py`
- Test: `tests/pyclaw/ui/panels/test_settings_view.py`

**Context:** The current Settings panel uses a tab-based interface (Assistant, Display, Connection, Advanced tabs). The design document (Section 5.2) specifies using collapsible sections instead for better visual hierarchy and progressive disclosure. The `expandable_section` component already exists in `components/page_header.py`.

- [ ] **Step 1: Write failing test for collapsible section layout**

Create test file `tests/pyclaw/ui/panels/test_settings_view.py`:

```python
"""Tests for Settings panel view with collapsible sections."""
import pytest
import flet as ft
from unittest.mock import MagicMock, patch
from pyclaw.ui.panels.settings.view import SettingsView
from pyclaw.ui.panels.settings.controller import SettingsController
from pyclaw.ui.panels.settings.state import SettingsState
from pyclaw.ui.panels.settings.model import SettingsData


@pytest.fixture
def mock_controller():
    """Create a mock settings controller."""
    controller = MagicMock(spec=SettingsController)
    controller.state = SettingsState()
    controller.state.settings.value = SettingsData()
    controller.state.providers.value = []
    controller.state.models.value = []
    controller.state.loading.value = False
    controller.state.error.value = None
    controller.state.saving.value = False
    return controller


def test_settings_view_has_collapsible_sections(mock_controller):
    """Settings view should use collapsible sections, not tabs."""
    view = SettingsView(mock_controller)
    content = view._build_content()
    
    # Should not have tab bar
    assert not hasattr(view, '_tab_bar') or view._tab_bar is None
    
    # Should have expandable sections
    section_containers = [c for c in content.controls if isinstance(c, ft.Container)]
    assert len(section_containers) >= 4  # At least 4 sections


def test_assistant_section_expands(mock_controller):
    """Assistant settings section should be expandable."""
    view = SettingsView(mock_controller)
    content = view._build_content()
    
    # Find assistant section
    assistant_section = None
    for control in content.controls:
        if hasattr(control, 'content'):
            # Check for assistant icon/label
            pass
    
    # Section should be collapsible
    assert assistant_section is not None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/pyclaw/ui/panels/test_settings_view.py -v`
Expected: FAIL with "Settings view should use collapsible sections"

- [ ] **Step 3: Refactor SettingsView to use collapsible sections**

Modify `src/pyclaw/ui/panels/settings/view.py`:

```python
def _build_content(self) -> ft.Control:
    """Build the main content area with collapsible sections."""
    settings = self._controller.state.settings.value
    providers = self._controller.state.providers.value
    theme = get_theme()

    # Build all controls first
    self._build_assistant_controls(settings, providers)
    self._build_display_controls(settings)
    self._build_connection_controls(settings)
    self._build_advanced_controls()

    # Create expandable sections
    assistant_section = expandable_section(
        title=t("settings.section.assistant", default="Assistant Settings"),
        icon=ft.Icons.SMART_TOY_OUTLINED,
        content=self._build_assistant_section(),
        initially_expanded=True,
    )

    display_section = expandable_section(
        title=t("settings.section.message", default="Message Settings"),
        icon=ft.Icons.MESSAGE_OUTLINED,
        content=self._build_display_section(),
        initially_expanded=False,
    )

    connection_section = expandable_section(
        title=t("settings.section.connection", default="Connection & Auth"),
        icon=ft.Icons.CABLE,
        content=self._build_connection_section(),
        initially_expanded=False,
    )

    advanced_section = expandable_section(
        title=t("settings.section.appearance", default="Appearance & Language"),
        icon=ft.Icons.PALETTE_OUTLINED,
        content=self._build_advanced_section(),
        initially_expanded=False,
    )

    return ft.Column(
        controls=[
            assistant_section,
            ft.Container(height=8),
            display_section,
            ft.Container(height=8),
            connection_section,
            ft.Container(height=8),
            advanced_section,
        ],
        spacing=0,
        scroll=ft.ScrollMode.AUTO,
        expand=True,
        padding=ft.Padding.all(16),
    )
```

- [ ] **Step 4: Implement individual section builders**

Add the following methods to `SettingsView`:

```python
def _build_assistant_section(self) -> ft.Column:
    """Build assistant settings section content."""
    return ft.Column(
        [
            self._provider,
            self._model_stack,
            self._api_key,
            self._base_url,
            slider_input(
                t("settings.temperature", default="Temperature"),
                0.0, 2.0,
                float(self._temperature.value or 0.7),
                step=0.1,
                tooltip=t("settings.temperature_tooltip"),
                on_change=lambda v: self._update_setting("temperature", round(v, 2)),
            ),
            slider_input(
                t("settings.context_turns", default="Context turns"),
                1.0, 50.0,
                float(self._context_turns.value or 12),
                step=1.0,
                tooltip=t("settings.context_turns_tooltip"),
                on_change=lambda v: self._update_setting("context_turns", int(v)),
            ),
            switch_with_info(
                t("settings.stream_output", default="Streaming output"),
                self._stream_output.value if self._stream_output else True,
                tooltip=t("settings.stream_output_tooltip"),
                on_change=lambda v: self._update_setting("stream_output", v),
            ),
            switch_with_info(
                t("settings.max_tokens_enabled", default="Enable max tokens"),
                self._max_tokens_enabled.value if self._max_tokens_enabled else False,
                tooltip=t("settings.max_tokens_tooltip"),
                on_change=lambda v: self._handle_max_tokens_toggle(v),
            ),
            self._max_tokens,
        ],
        spacing=12,
    )

def _build_display_section(self) -> ft.Column:
    """Build display settings section content."""
    return ft.Column(
        [
            switch_with_info(
                t("settings.show_prompt", default="Show prompts"),
                self._show_prompt.value if self._show_prompt else False,
                tooltip=t("settings.show_prompt_tooltip"),
                on_change=lambda v: self._update_setting("show_prompt", v),
            ),
            switch_with_info(
                t("settings.serif_font", default="Use serif font"),
                self._serif_font.value if self._serif_font else False,
                tooltip=t("settings.serif_font_tooltip"),
                on_change=lambda v: self._update_setting("serif_font", v),
            ),
            switch_with_info(
                t("settings.collapse_thinking", default="Auto-collapse thinking"),
                self._collapse_thinking.value if self._collapse_thinking else True,
                tooltip=t("settings.collapse_thinking_tooltip"),
                on_change=lambda v: self._update_setting("collapse_thinking", v),
            ),
            switch_with_info(
                t("settings.message_outline", default="Show message outline"),
                self._message_outline.value if self._message_outline else False,
                tooltip=t("settings.message_outline_tooltip"),
                on_change=lambda v: self._update_setting("message_outline", v),
            ),
            self._message_style,
        ],
        spacing=12,
    )

def _build_connection_section(self) -> ft.Column:
    """Build connection settings section content."""
    return ft.Column(
        [
            self._gateway_url,
            self._auth_token,
        ],
        spacing=12,
    )

def _build_advanced_section(self) -> ft.Column:
    """Build advanced settings section content."""
    theme = get_theme()
    return ft.Column(
        [
            ft.Row([self._theme_toggle, self._locale_dropdown], spacing=16),
            self._ui_scale_dropdown,
            self._seed_color_field,
            self._color_swatches,
        ],
        spacing=12,
    )
```

- [ ] **Step 5: Remove tab-related code**

Remove the following from `SettingsView`:
- `_tab_bar` attribute
- `_tab_content` attribute
- `_current_tab` attribute
- `_switch_tab` method
- `_build_assistant_tab`, `_build_display_tab`, `_build_connection_tab`, `_build_advanced_tab` methods

- [ ] **Step 6: Run test to verify it passes**

Run: `pytest tests/pyclaw/ui/panels/test_settings_view.py -v`
Expected: PASS

- [ ] **Step 7: Commit**

```bash
git add src/pyclaw/ui/panels/settings/view.py tests/pyclaw/ui/panels/test_settings_view.py
git commit -m "refactor(ui): use collapsible sections in Settings panel

Replace tab-based interface with expandable sections for better
visual hierarchy and progressive disclosure as per RPD design.

- Replace tabs with expandable_section components
- Add section builders for each settings category
- Remove tab-related state and methods"
```

---

## Task 2: Enhanced Empty States for Panels

**Files:**
- Modify: `src/pyclaw/ui/cron_panel.py`
- Modify: `src/pyclaw/ui/skills_panel.py`
- Modify: `src/pyclaw/ui/panels/sessions/view.py`
- Test: `tests/pyclaw/ui/test_empty_states.py`

**Context:** The design document (Section 4.4) specifies enhanced empty states with icons, hints, and CTAs. The `empty_state_enhanced` component exists but some panels use simpler empty states or basic text.

- [ ] **Step 1: Write failing test for enhanced empty states**

Create test file `tests/pyclaw/ui/test_empty_states.py`:

```python
"""Tests for enhanced empty states across panels."""
import pytest
import flet as ft
from unittest.mock import MagicMock, patch
from pyclaw.ui.cron_panel import build_cron_panel
from pyclaw.ui.skills_panel import build_skills_panel


def test_cron_panel_empty_state_has_cta():
    """Cron panel should show enhanced empty state with action button."""
    mock_gateway = MagicMock()
    mock_gateway.connected = False
    
    panel = build_cron_panel(gateway_client=mock_gateway)
    
    # Find empty state in controls
    empty_found = False
    has_action = False
    
    def find_empty_state(controls):
        nonlocal empty_found, has_action
        for control in controls:
            if hasattr(control, 'controls'):
                find_empty_state(control.controls)
            if hasattr(control, 'content') and hasattr(control.content, 'controls'):
                find_empty_state(control.content.controls)
            # Check for empty state indicators
            if isinstance(control, ft.Column):
                texts = [c for c in control.controls if isinstance(c, ft.Text)]
                for t in texts:
                    if "No Scheduled Tasks" in str(t.value) or "暂无" in str(t.value):
                        empty_found = True
    
    find_empty_state(panel.controls)
    assert empty_found, "Cron panel should show empty state when offline"


def test_skills_panel_empty_state():
    """Skills panel should show enhanced empty state."""
    mock_gateway = MagicMock()
    mock_gateway.connected = False
    
    panel = build_skills_panel(gateway_client=mock_gateway)
    assert panel is not None
```

- [ ] **Step 2: Run test to verify current behavior**

Run: `pytest tests/pyclaw/ui/test_empty_states.py -v`

- [ ] **Step 3: Enhance Cron panel empty state**

Modify `src/pyclaw/ui/cron_panel.py`:

Locate the `_refresh` function and update the empty state section:

```python
if not filtered_jobs:
    cron_list.controls.append(
        empty_state_enhanced(
            icon=ft.Icons.SCHEDULE,
            title=t("cron.empty_title", default="No Scheduled Tasks"),
            hint=t("cron.empty_hint", default="Create scheduled tasks to automate repetitive work"),
            action_label=t("cron.empty_action", default="Create Task"),
            on_action=_show_add_form,
        )
    )
```

- [ ] **Step 4: Enhance Sessions panel empty state**

Modify `src/pyclaw/ui/panels/sessions/view.py` to use `empty_state_enhanced`:

```python
from pyclaw.ui.components import empty_state_enhanced

# In _build_content method, when sessions list is empty:
if not self._controller.state.sessions.value:
    return ft.Container(
        content=empty_state_enhanced(
            icon=ft.Icons.FORUM_OUTLINED,
            title=t("sessions.empty_title", default="No Sessions"),
            hint=t("sessions.empty_hint", default="Send a message to create your first session"),
            action_label=t("sessions.empty_action", default="Start Chat"),
            on_action=self._handle_new_session,
        ),
        expand=True,
        alignment=ft.alignment.center,
    )
```

- [ ] **Step 5: Enhance Skills panel empty state**

Modify `src/pyclaw/ui/skills_panel.py`:

```python
from pyclaw.ui.components import empty_state_enhanced

# In the skills list empty case:
if not skills:
    skills_list.controls.append(
        empty_state_enhanced(
            icon=ft.Icons.AUTO_AWESOME,
            title=t("skills.empty_title", default="No Skills"),
            hint=t("skills.empty_hint", default="Enable skills from the marketplace to extend agent capabilities"),
            action_label=t("skills.empty_action", default="Browse Skills"),
            on_action=lambda e: None,  # TODO: Open marketplace
        )
    )
```

- [ ] **Step 6: Run tests to verify**

Run: `pytest tests/pyclaw/ui/test_empty_states.py -v`
Expected: PASS

- [ ] **Step 7: Commit**

```bash
git add src/pyclaw/ui/cron_panel.py src/pyclaw/ui/skills_panel.py src/pyclaw/ui/panels/sessions/view.py tests/pyclaw/ui/test_empty_states.py
git commit -m "feat(ui): enhance empty states with icons, hints, and CTAs

Update Cron, Sessions, and Skills panels to use empty_state_enhanced
component for better user guidance when no data is available."
```

---

## Task 3: Inbox Panel Channel Switcher

**Files:**
- Modify: `src/pyclaw/ui/panels/inbox/view.py`
- Modify: `src/pyclaw/ui/panels/inbox/state.py`
- Test: `tests/pyclaw/ui/panels/inbox/test_view.py`

**Context:** The design document (Section 3.0) specifies a channel switcher in the Inbox panel. Currently the Inbox panel exists but lacks the channel filtering UI.

- [ ] **Step 1: Write failing test for channel switcher**

Create test file `tests/pyclaw/ui/panels/inbox/test_view.py`:

```python
"""Tests for Inbox panel view with channel switcher."""
import pytest
import flet as ft
from unittest.mock import MagicMock
from pyclaw.ui.panels.inbox.view import InboxView
from pyclaw.ui.panels.inbox.controller import InboxController
from pyclaw.ui.panels.inbox.state import InboxState, ChannelInfo


@pytest.fixture
def mock_controller():
    """Create a mock inbox controller with sample channels."""
    controller = MagicMock(spec=InboxController)
    controller.state = InboxState()
    controller.state.channels.value = [
        ChannelInfo(id="telegram", name="Telegram", icon=ft.Icons.TELEGRAM, unread_count=5, status="running"),
        ChannelInfo(id="whatsapp", name="WhatsApp", icon=ft.Icons.PHONE_ANDROID, unread_count=3, status="running"),
    ]
    controller.state.messages.value = []
    controller.state.selected_channel.value = None
    controller.state.loading.value = False
    return controller


def test_inbox_view_has_channel_switcher(mock_controller):
    """Inbox view should display a channel switcher list."""
    view = InboxView(mock_controller)
    content = view._build_content()
    
    # Should have channel list/switcher
    channel_switcher_found = False
    def find_channels(controls):
        nonlocal channel_switcher_found
        for control in controls:
            if hasattr(control, 'controls'):
                find_channels(control.controls)
            if isinstance(control, ft.ListView) or isinstance(control, ft.Column):
                # Look for channel indicators
                pass
    
    find_channels(content.controls)
    assert True  # Placeholder


def test_channel_selection_filters_messages(mock_controller):
    """Selecting a channel should filter the message list."""
    view = InboxView(mock_controller)
    
    # Select telegram channel
    view._handle_channel_select("telegram")
    
    # Should update selected_channel state
    mock_controller.select_channel.assert_called_once_with("telegram")
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/pyclaw/ui/panels/inbox/test_view.py -v`

- [ ] **Step 3: Add channel switcher to InboxView**

Modify `src/pyclaw/ui/panels/inbox/view.py`:

```python
from pyclaw.ui.components import status_chip

def _build_channel_switcher(self) -> ft.Control:
    """Build the channel selection list."""
    theme = get_theme()
    channels = self._controller.state.channels.value
    
    if not channels:
        return ft.Container()
    
    channel_items = []
    
    # All channels option
    all_selected = self._controller.state.selected_channel.value is None
    total_unread = sum(c.unread_count for c in channels)
    
    channel_items.append(
        ft.ListTile(
            leading=ft.Icon(ft.Icons.FORUM, color=theme.colors.primary),
            title=ft.Text(t("inbox.all_channels", default="All Channels")),
            trailing=ft.Container(
                content=ft.Text(str(total_unread), size=theme.typography.size_xs),
                bgcolor=theme.colors.primary if total_unread > 0 else theme.colors.surface_container,
                border_radius=10,
                padding=ft.Padding.symmetric(horizontal=8, vertical=4),
            ),
            selected=all_selected,
            on_click=lambda e: self._handle_channel_select(None),
        )
    )
    
    # Individual channels
    for channel in channels:
        is_selected = self._controller.state.selected_channel.value == channel.id
        channel_items.append(
            ft.ListTile(
                leading=ft.Icon(channel.icon, color=theme.colors.primary),
                title=ft.Text(channel.name),
                trailing=ft.Container(
                    content=ft.Text(str(channel.unread_count), size=theme.typography.size_xs),
                    bgcolor=theme.colors.primary if channel.unread_count > 0 else theme.colors.surface_container,
                    border_radius=10,
                    padding=ft.Padding.symmetric(horizontal=8, vertical=4),
                    visible=channel.unread_count > 0,
                ),
                selected=is_selected,
                on_click=lambda e, cid=channel.id: self._handle_channel_select(cid),
            )
        )
    
    return ft.Container(
        content=ft.Column(
            channel_items,
            spacing=0,
            tight=True,
        ),
        border=ft.Border.only(bottom=ft.BorderSide(0.5, theme.colors.border)),
    )

def _handle_channel_select(self, channel_id: str | None) -> None:
    """Handle channel selection."""
    self._fire_async(self._controller.select_channel(channel_id))
```

- [ ] **Step 4: Add select_channel method to controller**

Modify `src/pyclaw/ui/panels/inbox/controller.py`:

```python
async def select_channel(self, channel_id: str | None) -> None:
    """Select a channel to filter messages.
    
    Args:
        channel_id: Channel ID or None for all channels.
    """
    self.state.selected_channel.value = channel_id
    await self.refresh()
```

- [ ] **Step 5: Add selected_channel to state**

Modify `src/pyclaw/ui/panels/inbox/state.py`:

```python
from pyclaw.ui.core.reactive import Reactive

class InboxState:
    """State for Inbox panel."""
    
    def __init__(self) -> None:
        self.channels: Reactive[list[ChannelInfo]] = Reactive([])
        self.messages: Reactive[list[InboxMessage]] = Reactive([])
        self.selected_channel: Reactive[str | None] = Reactive(None)
        self.loading: Reactive[bool] = Reactive(False)
        self.error: Reactive[str | None] = Reactive(None)
```

- [ ] **Step 6: Update _build_content to include channel switcher**

Modify the `_build_content` method in `InboxView`:

```python
def _build_content(self) -> ft.Control:
    """Build the main content area."""
    theme = get_theme()
    
    return ft.Column(
        [
            self._build_channel_switcher(),
            ft.Divider(height=1),
            self._messages_list,
            self._build_input_area(),
        ],
        spacing=0,
        expand=True,
    )
```

- [ ] **Step 7: Run tests to verify**

Run: `pytest tests/pyclaw/ui/panels/inbox/test_view.py -v`
Expected: PASS

- [ ] **Step 8: Commit**

```bash
git add src/pyclaw/ui/panels/inbox/view.py src/pyclaw/ui/panels/inbox/controller.py src/pyclaw/ui/panels/inbox/state.py tests/pyclaw/ui/panels/inbox/test_view.py
git commit -m "feat(ui): add channel switcher to Inbox panel

Implement channel filtering UI as specified in RPD design:
- Add channel selection list with unread counts
- Filter messages by selected channel
- Update state and controller to support channel selection"
```

---

## Task 4: Inbox Message Filter and Search

**Files:**
- Modify: `src/pyclaw/ui/panels/inbox/view.py`
- Modify: `src/pyclaw/ui/panels/inbox/repository.py`
- Test: `tests/pyclaw/ui/panels/inbox/test_filter.py`

**Context:** The design document (Section 3.0.3) specifies filter and search capabilities for the Inbox.

- [ ] **Step 1: Write failing test for filter functionality**

Create test file `tests/pyclaw/ui/panels/inbox/test_filter.py`:

```python
"""Tests for Inbox panel filter and search functionality."""
import pytest
from unittest.mock import MagicMock
from pyclaw.ui.panels.inbox.controller import InboxController


@pytest.fixture
def mock_gateway():
    """Create a mock gateway client."""
    gateway = MagicMock()
    gateway.connected = True
    return gateway


@pytest.mark.asyncio
async def test_filter_by_status():
    """Should filter messages by read/unread status."""
    controller = InboxController(gateway_client=None)
    
    # Set filter
    controller.state.filter_status.value = "unread"
    
    # Verify filter is applied
    assert controller.state.filter_status.value == "unread"


@pytest.mark.asyncio
async def test_search_by_keyword():
    """Should search messages by keyword."""
    controller = InboxController(gateway_client=None)
    
    # Set search query
    controller.state.search_query.value = "test keyword"
    
    # Verify search is active
    assert controller.state.search_query.value == "test keyword"
```

- [ ] **Step 2: Add filter state properties**

Modify `src/pyclaw/ui/panels/inbox/state.py`:

```python
class InboxState:
    """State for Inbox panel."""
    
    def __init__(self) -> None:
        self.channels: Reactive[list[ChannelInfo]] = Reactive([])
        self.messages: Reactive[list[InboxMessage]] = Reactive([])
        self.selected_channel: Reactive[str | None] = Reactive(None)
        self.filter_status: Reactive[str] = Reactive("all")  # all, read, unread
        self.search_query: Reactive[str] = Reactive("")
        self.loading: Reactive[bool] = Reactive(False)
        self.error: Reactive[str | None] = Reactive(None)
```

- [ ] **Step 3: Add filter UI to InboxView**

Modify `src/pyclaw/ui/panels/inbox/view.py`:

```python
def _build_filter_bar(self) -> ft.Control:
    """Build the filter and search bar."""
    theme = get_theme()
    
    self._search_field = ft.TextField(
        hint_text=t("inbox.search_placeholder", default="Search messages..."),
        prefix_icon=ft.Icons.SEARCH,
        dense=True,
        expand=True,
        on_change=lambda e: self._handle_search(e.control.value),
    )
    
    self._filter_dropdown = ft.Dropdown(
        label=t("inbox.filter", default="Filter"),
        value="all",
        options=[
            ft.dropdown.Option("all", t("inbox.filter_all", default="All")),
            ft.dropdown.Option("unread", t("inbox.filter_unread", default="Unread")),
            ft.dropdown.Option("read", t("inbox.filter_read", default="Read")),
        ],
        width=120,
        dense=True,
        on_change=lambda e: self._handle_filter_change(e.control.value),
    )
    
    return ft.Container(
        content=ft.Row(
            [self._search_field, self._filter_dropdown],
            spacing=8,
        ),
        padding=ft.Padding.symmetric(horizontal=16, vertical=8),
    )

def _handle_search(self, query: str) -> None:
    """Handle search query change."""
    self._controller.state.search_query.value = query
    self._fire_async(self._controller.refresh())

def _handle_filter_change(self, status: str) -> None:
    """Handle filter status change."""
    self._controller.state.filter_status.value = status
    self._fire_async(self._controller.refresh())
```

- [ ] **Step 4: Update repository to support filtering**

Modify `src/pyclaw/ui/panels/inbox/repository.py`:

```python
async def get_messages(
    self,
    channel_id: str | None = None,
    filter_status: str = "all",
    search_query: str = "",
    limit: int = 50,
    offset: int = 0,
) -> list[InboxMessage]:
    """Get messages from inbox with filtering.
    
    Args:
        channel_id: Optional channel filter.
        filter_status: Filter by status (all, read, unread).
        search_query: Search query string.
        limit: Maximum number of messages.
        offset: Offset for pagination.
    
    Returns:
        List of InboxMessage objects.
    """
    if self.connected:
        return await self._get_messages_from_gateway(
            channel_id, filter_status, search_query, limit, offset
        )
    return await self._get_mock_messages(channel_id, limit)
```

- [ ] **Step 5: Run tests to verify**

Run: `pytest tests/pyclaw/ui/panels/inbox/test_filter.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/pyclaw/ui/panels/inbox/view.py src/pyclaw/ui/panels/inbox/state.py src/pyclaw/ui/panels/inbox/repository.py tests/pyclaw/ui/panels/inbox/test_filter.py
git commit -m "feat(ui): add filter and search to Inbox panel

Implement message filtering as specified in RPD design:
- Add search field for keyword search
- Add filter dropdown for read/unread status
- Update state and repository to support filtering"
```

---

## Task 5: Translation Updates

**Files:**
- Modify: `src/pyclaw/ui/locales/en.json`
- Modify: `src/pyclaw/ui/locales/zh-CN.json`

**Context:** Add new translation keys for the enhanced UI components as specified in the design document (Section 9.3).

- [ ] **Step 1: Add new English translations**

Append to `src/pyclaw/ui/locales/en.json`:

```json
{
  "inbox.filter_all": "All",
  "inbox.filter_unread": "Unread", 
  "inbox.filter_read": "Read",
  "inbox.presence_online": "Online",
  "inbox.presence_away": "Away",
  "inbox.presence_offline": "Offline",
  "inbox.presence_unknown": "Unknown",
  "inbox.typing": "typing...",
  "inbox.recording": "recording...",
  "inbox.thinking": "Agent thinking...",
  "settings.section.assistant": "Assistant Settings",
  "settings.section.message": "Message Settings",
  "settings.section.connection": "Connection & Auth",
  "settings.section.appearance": "Appearance & Language",
  "settings.temperature_tooltip": "Controls response creativity. 0 = deterministic, 2 = random.",
  "settings.context_turns_tooltip": "How many recent turns are kept in context.",
  "settings.stream_output_tooltip": "Show reply token-by-token while generating.",
  "settings.max_tokens_tooltip": "Limit maximum tokens generated per response.",
  "settings.show_prompt_tooltip": "Display system prompts used by the current agent.",
  "settings.serif_font_tooltip": "Improves long-form reading comfort.",
  "settings.collapse_thinking_tooltip": "Collapse assistant reasoning blocks by default.",
  "settings.message_outline_tooltip": "Show an outline navigation for long messages.",
  "overview.quick_actions": "Quick Actions",
  "overview.publish_wizard": "Publish Wizard",
  "overview.publish_wizard_desc": "Quickly publish content to platforms",
  "overview.new_agent": "New Agent",
  "overview.new_agent_desc": "Create an intelligent assistant",
  "overview.new_cron": "New Scheduled Task",
  "overview.new_cron_desc": "Set up automated tasks",
  "quick_actions.wechat_publish": "WeChat",
  "quick_actions.redbook_publish": "RedBook"
}
```

- [ ] **Step 2: Add new Chinese translations**

Append to `src/pyclaw/ui/locales/zh-CN.json`:

```json
{
  "inbox.filter_all": "全部",
  "inbox.filter_unread": "未读",
  "inbox.filter_read": "已读",
  "inbox.presence_online": "在线",
  "inbox.presence_away": "离开",
  "inbox.presence_offline": "离线",
  "inbox.presence_unknown": "未知",
  "inbox.typing": "正在输入...",
  "inbox.recording": "正在录制...",
  "inbox.thinking": "Agent 思考中...",
  "settings.section.assistant": "助手设置",
  "settings.section.message": "消息设置",
  "settings.section.connection": "连接与认证",
  "settings.section.appearance": "外观与语言",
  "settings.temperature_tooltip": "控制回复的创造性。0 = 确定性，2 = 随机性",
  "settings.context_turns_tooltip": "保留在上下文中的历史消息数量",
  "settings.stream_output_tooltip": "逐 token 显示回复内容",
  "settings.max_tokens_tooltip": "单次回复的最大 token 数量",
  "settings.show_prompt_tooltip": "在对话中显示 Agent 的系统提示词",
  "settings.serif_font_tooltip": "使用更适合长文本阅读的字体",
  "settings.collapse_thinking_tooltip": "自动折叠 Agent 的思考过程",
  "settings.message_outline_tooltip": "在长消息顶部显示目录导航",
  "overview.quick_actions": "快速操作",
  "overview.publish_wizard": "发布向导",
  "overview.publish_wizard_desc": "快速发布内容到各平台",
  "overview.new_agent": "新建 Agent",
  "overview.new_agent_desc": "创建智能助手",
  "overview.new_cron": "新建定时任务",
  "overview.new_cron_desc": "设置自动化任务",
  "quick_actions.wechat_publish": "微信发布",
  "quick_actions.redbook_publish": "小红书发布"
}
```

- [ ] **Step 3: Verify JSON is valid**

Run: `python -c "import json; json.load(open('src/pyclaw/ui/locales/en.json'))"`

- [ ] **Step 4: Commit**

```bash
git add src/pyclaw/ui/locales/en.json src/pyclaw/ui/locales/zh-CN.json
git commit -m "feat(i18n): add translations for enhanced UI components

Add translation keys for:
- Inbox filter and presence indicators
- Settings section headers and tooltips
- Quick actions labels"
```

---

## Task 6: Presence and Typing Indicators Enhancement

**Files:**
- Modify: `src/pyclaw/ui/components/presence_indicator.py`
- Modify: `src/pyclaw/ui/panels/inbox/view.py`
- Test: `tests/pyclaw/ui/components/test_presence.py`

**Context:** The design document (Section 3.0.2) specifies detailed presence and typing indicators. The component exists but needs integration into the Inbox message display.

- [ ] **Step 1: Write test for presence display**

Create test file `tests/pyclaw/ui/components/test_presence.py`:

```python
"""Tests for presence indicator components."""
import pytest
import flet as ft
from pyclaw.ui.components.presence_indicator import (
    PresenceStatus,
    presence_dot,
    presence_label,
    typing_indicator,
)


def test_presence_dot_colors():
    """Presence dot should use correct colors for each status."""
    online_dot = presence_dot(PresenceStatus.ONLINE)
    assert online_dot.bgcolor is not None
    
    offline_dot = presence_dot(PresenceStatus.OFFLINE)
    assert offline_dot.bgcolor is not None


def test_presence_label_text():
    """Presence label should show status text."""
    label = presence_label(PresenceStatus.ONLINE)
    assert isinstance(label, ft.Text)


def test_typing_indicator_animates():
    """Typing indicator should have animation."""
    indicator = typing_indicator("typing...")
    assert indicator is not None
```

- [ ] **Step 2: Enhance presence indicator component**

Modify `src/pyclaw/ui/components/presence_indicator.py`:

```python
from pyclaw.ui.i18n import t
from pyclaw.ui.theme import get_theme

class PresenceStatus:
    """Presence status enumeration."""
    ONLINE = "online"
    AWAY = "away"
    OFFLINE = "offline"
    UNKNOWN = "unknown"


def presence_dot(status: str, size: int = 10) -> ft.Container:
    """Create a presence indicator dot.
    
    Args:
        status: Presence status string.
        size: Dot size in pixels.
    
    Returns:
        Container with colored dot.
    """
    theme = get_theme()
    
    color_map = {
        PresenceStatus.ONLINE: theme.colors.success,
        PresenceStatus.AWAY: theme.colors.warning,
        PresenceStatus.OFFLINE: theme.colors.error,
        PresenceStatus.UNKNOWN: theme.colors.muted,
    }
    
    return ft.Container(
        width=size,
        height=size,
        border_radius=size // 2,
        bgcolor=color_map.get(status, theme.colors.muted),
        animate=ft.Animation(200, ft.AnimationCurve.EASE_IN_OUT),
    )


def presence_label(status: str) -> ft.Text:
    """Create a presence status label.
    
    Args:
        status: Presence status string.
    
    Returns:
        Text label for the status.
    """
    theme = get_theme()
    
    label_map = {
        PresenceStatus.ONLINE: t("inbox.presence_online", default="Online"),
        PresenceStatus.AWAY: t("inbox.presence_away", default="Away"),
        PresenceStatus.OFFLINE: t("inbox.presence_offline", default="Offline"),
        PresenceStatus.UNKNOWN: t("inbox.presence_unknown", default="Unknown"),
    }
    
    return ft.Text(
        label_map.get(status, status),
        size=theme.typography.size_xs,
        color=theme.colors.muted,
    )


def typing_indicator(text: str | None = None) -> ft.Row:
    """Create a typing indicator with animated dots.
    
    Args:
        text: Optional custom text. Uses i18n default if None.
    
    Returns:
        Row with typing text and animated dots.
    """
    theme = get_theme()
    
    if text is None:
        text = t("inbox.typing", default="typing...")
    
    return ft.Row(
        [
            ft.Text(text, size=theme.typography.size_xs, color=theme.colors.muted),
            ft.Container(
                content=ft.Row(
                    [
                        ft.Container(width=4, height=4, border_radius=2, bgcolor=theme.colors.muted),
                        ft.Container(width=4, height=4, border_radius=2, bgcolor=theme.colors.muted),
                        ft.Container(width=4, height=4, border_radius=2, bgcolor=theme.colors.muted),
                    ],
                    spacing=4,
                ),
                animate=ft.Animation(500, ft.AnimationCurve.EASE_IN_OUT),
            ),
        ],
        spacing=8,
    )
```

- [ ] **Step 3: Integrate presence into Inbox message display**

Modify `src/pyclaw/ui/panels/inbox/view.py`:

```python
from pyclaw.ui.components.presence_indicator import presence_dot, PresenceStatus

def _build_message_tile(self, message: InboxMessage) -> ft.Control:
    """Build a message tile with presence indicator."""
    theme = get_theme()
    
    # Map message presence to status
    status_map = {
        "online": PresenceStatus.ONLINE,
        "away": PresenceStatus.AWAY,
        "offline": PresenceStatus.OFFLINE,
    }
    presence_status = status_map.get(message.presence, PresenceStatus.UNKNOWN)
    
    return ft.Container(
        content=ft.Row(
            [
                presence_dot(presence_status),
                ft.Column(
                    [
                        ft.Row(
                            [
                                ft.Icon(message.channel_icon, size=theme.sizing.icon_sm),
                                ft.Text(message.sender, weight=ft.FontWeight.W_500),
                                presence_label(presence_status),
                            ],
                            spacing=8,
                        ),
                        ft.Text(message.content, max_lines=3, overflow=ft.TextOverflow.ELLIPSIS),
                        typing_indicator() if message.is_typing else ft.Container(),
                    ],
                    spacing=4,
                    expand=True,
                ),
            ],
            spacing=12,
        ),
        padding=ft.Padding.all(12),
        border=ft.Border.all(0.5, theme.colors.border),
        border_radius=8,
    )
```

- [ ] **Step 4: Run tests to verify**

Run: `pytest tests/pyclaw/ui/components/test_presence.py -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/pyclaw/ui/components/presence_indicator.py src/pyclaw/ui/panels/inbox/view.py tests/pyclaw/ui/components/test_presence.py
git commit -m "feat(ui): enhance presence and typing indicators

Improve presence display with:
- Color-coded status dots
- i18n labels for status text
- Animated typing indicator
- Integration into Inbox message tiles"
```

---

## Verification

After completing all tasks, verify the implementation:

- [ ] Run all tests: `pytest tests/pyclaw/ui/ -v`
- [ ] Run linting: `ruff check src/pyclaw/ui/`
- [ ] Run type checking: `mypy src/pyclaw/ui/`
- [ ] Start the UI and manually test:
  - Settings panel collapsible sections
  - Inbox channel switcher
  - Empty states on each panel
  - Presence indicators in messages

---

## Summary

This plan implements the key UI enhancements from RPD_CLIENT_DESIGN.md:

1. **Settings Refactoring** - Convert tabs to collapsible sections
2. **Empty States** - Add enhanced empty states with CTAs
3. **Inbox Enhancements** - Channel switcher, filters, search
4. **Translations** - Complete i18n coverage
5. **Presence Indicators** - Real-time status display

The implementation follows the existing patterns in the codebase and maintains backward compatibility while adding new features.
