# RPD Client Features Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement the detailed UI/UX features designed in `docs/RPD_CLIENT_DESIGN.md` to enrich the PyClaw client experience.

**Architecture:** Enhance existing panels with missing features, add new Inbox panel for multi-channel messaging, and unify empty states across all panels. Follow existing MVC patterns with BasePanel, Reactive state, and i18n support. (Note: This plan predates the TypeScript migration; the Flet UI has been retired.)

**Tech Stack:** TypeScript, Next.js, shadcn/ui, Zustand, TanStack Query

---

## File Structure

### New Files to Create
- `src/pyclaw/ui/inbox_panel.py` - Multi-channel inbox panel
- `src/pyclaw/ui/panels/inbox/` - Inbox MVC components
  - `__init__.py`
  - `controller.py`
  - `view.py`
  - `state.py`
  - `repository.py`
- `src/pyclaw/ui/components/presence_indicator.py` - Presence & typing indicators
- `src/pyclaw/ui/components/inbox_channel_selector.py` - Channel selector component

### Files to Modify
- `src/pyclaw/ui/chat_view.py` - Enhance welcome state, input area
- `src/pyclaw/ui/panels/overview/view.py` - Add quick actions, stats cards
- `src/pyclaw/ui/panels/settings/view.py` - Reorganize with expandable sections
- `src/pyclaw/ui/panels/sessions/view.py` - Add enhanced empty state
- `src/pyclaw/ui/skills_panel.py` - Add enhanced empty state
- `src/pyclaw/ui/cron_panel.py` - Add enhanced empty state
- `src/pyclaw/ui/app.py` - Add Inbox to navigation
- `src/pyclaw/ui/i18n.py` - Add new translation keys
- `src/pyclaw/ui/locales/en.json` - English translations
- `src/pyclaw/ui/locales/zh-CN.json` - Chinese translations

---

## Task 1: Add Translation Keys for New Features

**Files:**
- Modify: `src/pyclaw/ui/locales/en.json`
- Modify: `src/pyclaw/ui/locales/zh-CN.json`

- [ ] **Step 1: Add Inbox translations to en.json**

Add the following keys to `src/pyclaw/ui/locales/en.json`:

```json
{
  "inbox": {
    "title": "Inbox",
    "all_channels": "All Channels",
    "new_messages": "new messages",
    "filter": "Filter",
    "search_placeholder": "Search messages...",
    "empty_title": "No Messages",
    "empty_hint": "Messages from connected channels will appear here",
    "empty_action": "Add Channel",
    "time_today": "Today",
    "time_yesterday": "Yesterday",
    "time_earlier": "Earlier",
    "reply": "Reply",
    "dismiss": "Dismiss",
    "presence_online": "Online",
    "presence_away": "Away",
    "presence_offline": "Offline",
    "presence_unknown": "Unknown",
    "typing": "typing...",
    "recording": "recording...",
    "thinking": "Agent thinking..."
  },
  "overview": {
    "title": "Overview",
    "connection_status": "Connection Status",
    "gateway": "Gateway",
    "provider": "Provider",
    "sessions_active": "Sessions Active",
    "agents_running": "Agents Running",
    "quick_actions": "Quick Actions",
    "publish_wizard": "Publish Wizard",
    "publish_wizard_desc": "Quickly publish content to platforms",
    "new_agent": "New Agent",
    "new_agent_desc": "Create an intelligent assistant",
    "new_cron": "New Scheduled Task",
    "new_cron_desc": "Set up automated tasks",
    "usage_today": "Usage (Today)",
    "messages": "Messages",
    "tokens": "Tokens",
    "cost": "Cost",
    "recent_activity": "Recent Activity"
  },
  "sessions": {
    "empty_title": "No Sessions",
    "empty_hint": "Sending a message will automatically create a new session",
    "empty_action": "Start Chat",
    "search_placeholder": "Search sessions...",
    "new_session": "New Session",
    "today": "Today",
    "yesterday": "Yesterday",
    "earlier": "Earlier",
    "last_message": "Last message"
  },
  "skills": {
    "empty_title": "No Skills",
    "empty_hint": "Enable skills from the marketplace to extend agent capabilities",
    "empty_action": "Browse Skills"
  },
  "cron": {
    "empty_title": "No Scheduled Tasks",
    "empty_hint": "Create scheduled tasks to automate repetitive work",
    "empty_action": "Create Task"
  },
  "channels": {
    "empty_title": "No Channels",
    "empty_hint": "Add channel configurations in Settings",
    "empty_action": "Go to Settings"
  }
}
```

- [ ] **Step 2: Add Chinese translations to zh-CN.json**

Add the corresponding Chinese translations:

```json
{
  "inbox": {
    "title": "收件箱",
    "all_channels": "全部频道",
    "new_messages": "条新消息",
    "filter": "筛选",
    "search_placeholder": "搜索消息...",
    "empty_title": "暂无消息",
    "empty_hint": "来自已连接频道的消息将显示在这里",
    "empty_action": "添加频道",
    "time_today": "今天",
    "time_yesterday": "昨天",
    "time_earlier": "更早",
    "reply": "回复",
    "dismiss": "忽略",
    "presence_online": "在线",
    "presence_away": "离开",
    "presence_offline": "离线",
    "presence_unknown": "未知",
    "typing": "正在输入...",
    "recording": "正在录制...",
    "thinking": "Agent 思考中..."
  },
  "overview": {
    "title": "概览",
    "connection_status": "连接状态",
    "gateway": "Gateway",
    "provider": "提供商",
    "sessions_active": "活跃会话",
    "agents_running": "运行中 Agent",
    "quick_actions": "快速操作",
    "publish_wizard": "发布向导",
    "publish_wizard_desc": "快速发布内容到各大平台",
    "new_agent": "新建 Agent",
    "new_agent_desc": "创建智能助手",
    "new_cron": "新建定时任务",
    "new_cron_desc": "设置自动任务",
    "usage_today": "今日使用",
    "messages": "消息数",
    "tokens": "Tokens",
    "cost": "成本",
    "recent_activity": "近期活动"
  },
  "sessions": {
    "empty_title": "暂无会话",
    "empty_hint": "发送消息将自动创建新会话",
    "empty_action": "开始聊天",
    "search_placeholder": "搜索会话...",
    "new_session": "新建会话",
    "today": "今天",
    "yesterday": "昨天",
    "earlier": "更早",
    "last_message": "最后消息"
  },
  "skills": {
    "empty_title": "暂无技能",
    "empty_hint": "从技能市场启用技能以扩展 Agent 能力",
    "empty_action": "浏览技能"
  },
  "cron": {
    "empty_title": "暂无定时任务",
    "empty_hint": "创建定时任务以自动化重复工作",
    "empty_action": "创建任务"
  },
  "channels": {
    "empty_title": "暂无频道",
    "empty_hint": "在设置中添加频道配置",
    "empty_action": "前往设置"
  }
}
```

- [ ] **Step 3: Commit translations**

```bash
git add src/pyclaw/ui/locales/en.json src/pyclaw/ui/locales/zh-CN.json
git commit -m "feat(ui): add i18n keys for inbox and enhanced empty states"
```

---

## Task 2: Create Presence Indicator Component

**Files:**
- Create: `src/pyclaw/ui/components/presence_indicator.py`

- [ ] **Step 1: Write the presence indicator component**

Create `src/pyclaw/ui/components/presence_indicator.py`:

```python
"""Presence indicator components — online status and typing indicators."""

from __future__ import annotations

import flet as ft

from pyclaw.ui.i18n import t
from pyclaw.ui.theme import get_theme


class PresenceStatus:
    """Presence status enumeration."""
    ONLINE = "online"
    AWAY = "away"
    OFFLINE = "offline"
    UNKNOWN = "unknown"


def presence_dot(status: str = PresenceStatus.UNKNOWN, size: int = 8) -> ft.Container:
    """Create a presence status dot indicator.

    Args:
        status: One of 'online', 'away', 'offline', 'unknown'
        size: Dot size in pixels

    Returns:
        Container with colored dot indicating presence status
    """
    theme = get_theme()

    color_map = {
        PresenceStatus.ONLINE: theme.colors.success,
        PresenceStatus.AWAY: theme.colors.warning,
        PresenceStatus.OFFLINE: theme.colors.error,
        PresenceStatus.UNKNOWN: theme.colors.muted,
    }

    return ft.Container(
        width=size,
        height=size,
        border_radius=size // 2,
        bgcolor=color_map.get(status, theme.colors.muted),
        tooltip=t(f"inbox.presence_{status}", default=status.title()),
    )


def typing_indicator(text: str = "") -> ft.Row:
    """Create a typing indicator with animated dots.

    Args:
        text: Optional text to show (e.g., "typing...", "recording...")

    Returns:
        Row with animated dots and optional text
    """
    theme = get_theme()

    if not text:
        text = t("inbox.typing", default="typing...")

    # Animated dots using text with animation
    dots = ft.Text(
        "●●●",
        size=10,
        color=theme.colors.muted,
        opacity=0.5,
        animate_opacity=ft.Animation(600, ft.AnimationCurve.EASE_IN_OUT),
    )

    return ft.Row(
        controls=[
            dots,
            ft.Text(text, size=12, color=theme.colors.muted, italic=True),
        ],
        spacing=4,
        alignment=ft.MainAxisAlignment.START,
    )


def presence_label(status: str = PresenceStatus.UNKNOWN, show_dot: bool = True) -> ft.Row:
    """Create a presence status label with optional dot.

    Args:
        status: One of 'online', 'away', 'offline', 'unknown'
        show_dot: Whether to show the colored dot

    Returns:
        Row with dot and status text
    """
    theme = get_theme()
    controls: list[ft.Control] = []

    if show_dot:
        controls.append(presence_dot(status))
        controls.append(ft.Container(width=4))

    controls.append(
        ft.Text(
            t(f"inbox.presence_{status}", default=status.title()),
            size=12,
            color=theme.colors.muted,
        )
    )

    return ft.Row(controls=controls, spacing=0, tight=True)
```

- [ ] **Step 2: Update components __init__.py**

Add to `src/pyclaw/ui/components/__init__.py`:

```python
from pyclaw.ui.components.presence_indicator import (
    PresenceStatus,
    presence_dot,
    presence_label,
    typing_indicator,
)

# Add to __all__ list:
    "PresenceStatus",
    "presence_dot",
    "presence_label",
    "typing_indicator",
```

- [ ] **Step 3: Commit presence indicator**

```bash
git add src/pyclaw/ui/components/presence_indicator.py src/pyclaw/ui/components/__init__.py
git commit -m "feat(ui): add presence indicator components"
```

---

## Task 3: Enhance Empty State Components

**Files:**
- Modify: `src/pyclaw/ui/components/empty_state.py`

- [ ] **Step 1: Add enhanced empty state with illustration**

Add new function to `src/pyclaw/ui/components/empty_state.py`:

```python
def empty_state_enhanced(
    icon: str,
    title: str,
    hint: str = "",
    *,
    action_label: str = "",
    on_action: Callable[[ft.ControlEvent], None] | None = None,
    secondary_actions: list[dict[str, Any]] | None = None,
) -> ft.Container:
    """Enhanced empty state with title, hint, and multiple action buttons.

    Args:
        icon: Icon name (ft.Icons.*)
        title: Main title text
        hint: Secondary hint text
        action_label: Primary action button label
        on_action: Primary action callback
        secondary_actions: List of {"label": str, "on_click": Callable} for secondary buttons

    Returns:
        Container with centered empty state content
    """
    theme = get_theme()

    children: list[ft.Control] = [
        ft.Icon(icon, size=64, color=ft.Colors.with_opacity(0.3, theme.colors.primary)),
        ft.Container(height=16),
        ft.Text(
            title,
            size=18,
            weight=ft.FontWeight.W_500,
            color=theme.colors.on_surface,
            text_align=ft.TextAlign.CENTER,
        ),
    ]

    if hint:
        children.append(ft.Container(height=4))
        children.append(
            ft.Text(
                hint,
                size=13,
                color=theme.colors.muted,
                text_align=ft.TextAlign.CENTER,
            )
        )

    if action_label and on_action:
        children.append(ft.Container(height=16))
        children.append(
            ft.FilledButton(action_label, on_click=on_action),
        )

    if secondary_actions:
        secondary_buttons = [
            ft.OutlinedButton(
                action["label"],
                on_click=action.get("on_click"),
            )
            for action in secondary_actions
        ]
        children.append(ft.Container(height=8))
        children.append(
            ft.Row(
                secondary_buttons,
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=8,
                wrap=True,
            )
        )

    return ft.Container(
        content=ft.Column(
            children,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
        ),
        expand=True,
        alignment=ft.Alignment(0, 0),
        padding=ft.Padding.all(32),
    )
```

- [ ] **Step 2: Update components __init__.py**

Add to `__all__` in `src/pyclaw/ui/components/__init__.py`:

```python
from pyclaw.ui.components.empty_state import empty_state_enhanced

# Add to __all__:
    "empty_state_enhanced",
```

- [ ] **Step 3: Commit enhanced empty state**

```bash
git add src/pyclaw/ui/components/empty_state.py src/pyclaw/ui/components/__init__.py
git commit -m "feat(ui): add enhanced empty state with multiple actions"
```

---

## Task 4: Enhance Sessions Panel Empty State

**Files:**
- Modify: `src/pyclaw/ui/panels/sessions/view.py`

- [ ] **Step 1: Read current sessions view implementation**

Read the current `src/pyclaw/ui/panels/sessions/view.py` to understand its structure.

- [ ] **Step 2: Add enhanced empty state to SessionsView**

Locate where the empty state is rendered and replace with:

```python
# In the appropriate location in SessionsView._build_content():
from pyclaw.ui.components import empty_state_enhanced

# When session list is empty:
return empty_state_enhanced(
    icon=ft.Icons.CHAT_BUBBLE_OUTLINE,
    title=t("sessions.empty_title", default="No Sessions"),
    hint=t("sessions.empty_hint", default="Sending a message will automatically create a new session"),
    action_label=t("sessions.empty_action", default="Start Chat"),
    on_action=lambda e: self._handle_new_session(),
)
```

- [ ] **Step 3: Add _handle_new_session method if missing**

```python
def _handle_new_session(self) -> None:
    """Handle the 'Start Chat' action from empty state."""
    # Navigate to chat panel
    if hasattr(self.page, "set_selected_nav") and callable(self.page.set_selected_nav):
        self.page.set_selected_nav(0)  # Chat is index 0
```

- [ ] **Step 4: Commit sessions empty state**

```bash
git add src/pyclaw/ui/panels/sessions/view.py
git commit -m "feat(ui): enhance sessions panel empty state"
```

---

## Task 5: Enhance Skills Panel Empty State

**Files:**
- Modify: `src/pyclaw/ui/skills_panel.py`

- [ ] **Step 1: Read current skills panel implementation**

Read `src/pyclaw/ui/skills_panel.py` to find the empty state rendering.

- [ ] **Step 2: Add enhanced empty state**

```python
from pyclaw.ui.components import empty_state_enhanced
from pyclaw.ui.i18n import t

# When skills list is empty:
return empty_state_enhanced(
    icon=ft.Icons.EXTENSION_OUTLINED,
    title=t("skills.empty_title", default="No Skills"),
    hint=t("skills.empty_hint", default="Enable skills from the marketplace to extend agent capabilities"),
    action_label=t("skills.empty_action", default="Browse Skills"),
    on_action=lambda e: self._handle_browse_skills(),
)
```

- [ ] **Step 3: Commit skills empty state**

```bash
git add src/pyclaw/ui/skills_panel.py
git commit -m "feat(ui): enhance skills panel empty state"
```

---

## Task 6: Enhance Cron Panel Empty State

**Files:**
- Modify: `src/pyclaw/ui/cron_panel.py`

- [ ] **Step 1: Read current cron panel implementation**

Read `src/pyclaw/ui/cron_panel.py` to find the empty state rendering.

- [ ] **Step 2: Add enhanced empty state**

```python
from pyclaw.ui.components import empty_state_enhanced
from pyclaw.ui.i18n import t

# When cron jobs list is empty:
return empty_state_enhanced(
    icon=ft.Icons.SCHEDULE,
    title=t("cron.empty_title", default="No Scheduled Tasks"),
    hint=t("cron.empty_hint", default="Create scheduled tasks to automate repetitive work"),
    action_label=t("cron.empty_action", default="Create Task"),
    on_action=lambda e: self._handle_create_task(),
)
```

- [ ] **Step 3: Commit cron empty state**

```bash
git add src/pyclaw/ui/cron_panel.py
git commit -m "feat(ui): enhance cron panel empty state"
```

---

## Task 7: Enhance Channels Panel Empty State

**Files:**
- Modify: `src/pyclaw/ui/panels/channels/view.py`

- [ ] **Step 1: Read current channels view implementation**

Read `src/pyclaw/ui/panels/channels/view.py` to find the empty state.

- [ ] **Step 2: Add enhanced empty state**

```python
from pyclaw.ui.components import empty_state_enhanced
from pyclaw.ui.i18n import t

# When channels list is empty:
return empty_state_enhanced(
    icon=ft.Icons.LINK,
    title=t("channels.empty_title", default="No Channels"),
    hint=t("channels.empty_hint", default="Add channel configurations in Settings"),
    action_label=t("channels.empty_action", default="Go to Settings"),
    on_action=lambda e: self._handle_go_to_settings(),
)
```

- [ ] **Step 3: Commit channels empty state**

```bash
git add src/pyclaw/ui/panels/channels/view.py
git commit -m "feat(ui): enhance channels panel empty state"
```

---

## Task 8: Enhance Chat View Welcome State

**Files:**
- Modify: `src/pyclaw/ui/chat_view.py`

- [ ] **Step 1: Enhance the welcome state UI**

The welcome state already exists. Enhance it with better styling per the design doc:

```python
# In ChatView.__init__, enhance _welcome_state:
self._welcome_state = ft.Container(
    content=ft.Column(
        [
            ft.Icon(ft.Icons.CHAT_BUBBLE_OUTLINE, size=72, color=theme.colors.muted),
            ft.Container(height=16),
            ft.Text(
                t("chat.welcome_title", default="Start a new chat"),
                size=theme.typography.size_xl,
                weight=ft.FontWeight.W_600,
            ),
            ft.Container(height=8),
            ft.Text(
                t("chat.welcome_hint1", default="• Ask any question to begin"),
                size=theme.typography.size_base,
                color=theme.colors.muted,
                text_align=ft.TextAlign.CENTER,
            ),
            ft.Text(
                t("chat.welcome_hint2", default="• Use quick actions for common tasks"),
                size=theme.typography.size_base,
                color=theme.colors.muted,
                text_align=ft.TextAlign.CENTER,
            ),
            ft.Text(
                t("chat.welcome_hint3", default="• Pick a previous session from the left"),
                size=theme.typography.size_base,
                color=theme.colors.muted,
                text_align=ft.TextAlign.CENTER,
            ),
            ft.Container(height=24),
            ft.Row(
                [
                    ft.FilledTonalButton(
                        t("chat.welcome_action_publish", default="Publish Wizard"),
                        icon=ft.Icons.EDIT_NOTE,
                        on_click=lambda e: self._prefill_input("/skills run "),
                    ),
                    ft.FilledTonalButton(
                        t("chat.welcome_action_agent", default="Select Agent"),
                        icon=ft.Icons.SMART_TOY_OUTLINED,
                        on_click=lambda e: self._prefill_input("@main "),
                    ),
                    ft.OutlinedButton(
                        t("chat.welcome_action_settings", default="Settings"),
                        icon=ft.Icons.SETTINGS_OUTLINED,
                        on_click=lambda e: self._prefill_input("/settings "),
                    ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                wrap=True,
                spacing=12,
            ),
            ft.Container(height=24),
            ft.Container(
                content=ft.Row(
                    [
                        ft.Icon(ft.Icons.LIGHTBULB_OUTLINE, size=16, color=theme.colors.primary),
                        ft.Text(
                            t("chat.welcome_tip", default="Tip: Press Ctrl+K to open command palette"),
                            size=theme.typography.size_sm,
                            color=theme.colors.on_surface_variant,
                        ),
                    ],
                    spacing=8,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                padding=ft.Padding.symmetric(horizontal=16, vertical=10),
                bgcolor=theme.colors.primary_container,
                border_radius=12,
            ),
        ],
        spacing=4,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    ),
    alignment=ft.Alignment(0, 0),
    expand=True,
    visible=True,
)
```

- [ ] **Step 2: Commit chat view welcome state**

```bash
git add src/pyclaw/ui/chat_view.py
git commit -m "feat(ui): enhance chat welcome state with better styling"
```

---

## Task 9: Add Quick Action Cards to Overview Panel

**Files:**
- Modify: `src/pyclaw/ui/panels/overview/view.py`
- Modify: `src/pyclaw/ui/dashboard_panel.py` (if it's the main overview)

- [ ] **Step 1: Read current overview/dashboard implementation**

Read `src/pyclaw/ui/panels/overview/view.py` and `src/pyclaw/ui/dashboard_panel.py`.

- [ ] **Step 2: Add quick action cards section**

Add quick action cards using the existing `quick_action_card` component:

```python
from pyclaw.ui.components import quick_action_card

def _build_quick_actions(self) -> ft.Control:
    """Build quick actions section."""
    theme = get_theme()

    return ft.Column(
        [
            ft.Text(
                t("overview.quick_actions", default="Quick Actions"),
                size=16,
                weight=ft.FontWeight.W_600,
            ),
            ft.Container(height=12),
            ft.Row(
                [
                    quick_action_card(
                        icon=ft.Icons.EDIT_NOTE,
                        title=t("overview.publish_wizard", default="Publish Wizard"),
                        description=t("overview.publish_wizard_desc", default="Quickly publish content to platforms"),
                        actions=[
                            {"label": t("quick_actions.wechat_publish", default="WeChat"), "icon": ft.Icons.CHAT},
                            {"label": t("quick_actions.redbook_publish", default="RedBook"), "icon": ft.Icons.BOOK},
                        ],
                        on_click=lambda e: self._handle_publish_wizard(),
                    ),
                    quick_action_card(
                        icon=ft.Icons.ADD_CIRCLE_OUTLINE,
                        title=t("overview.new_agent", default="New Agent"),
                        description=t("overview.new_agent_desc", default="Create an intelligent assistant"),
                        actions=[
                            {"label": t("common.create", default="Create"), "icon": ft.Icons.ADD},
                        ],
                        on_click=lambda e: self._handle_new_agent(),
                    ),
                    quick_action_card(
                        icon=ft.Icons.SCHEDULE,
                        title=t("overview.new_cron", default="New Scheduled Task"),
                        description=t("overview.new_cron_desc", default="Set up automated tasks"),
                        actions=[
                            {"label": t("common.create", default="Create"), "icon": ft.Icons.ADD},
                        ],
                        on_click=lambda e: self._handle_new_cron(),
                    ),
                ],
                spacing=12,
                wrap=True,
                expand=True,
            ),
        ],
        spacing=8,
    )
```

- [ ] **Step 3: Add usage stats section**

```python
def _build_usage_stats(self) -> ft.Control:
    """Build usage statistics section."""
    theme = get_theme()

    return ft.Column(
        [
            ft.Text(
                t("overview.usage_today", default="Usage (Today)"),
                size=16,
                weight=ft.FontWeight.W_600,
            ),
            ft.Container(height=12),
            ft.Row(
                [
                    self._build_stat_card(
                        icon=ft.Icons.MESSAGE_OUTLINED,
                        label=t("overview.messages", default="Messages"),
                        value=str(self._controller.state.messages_today.value),
                    ),
                    self._build_stat_card(
                        icon=ft.Icons.TOKEN_OUTLINED,
                        label=t("overview.tokens", default="Tokens"),
                        value=f"{self._controller.state.tokens_today.value:,}",
                    ),
                    self._build_stat_card(
                        icon=ft.Icons.ATTACH_MONEY,
                        label=t("overview.cost", default="Cost"),
                        value=f"${self._controller.state.cost_today.value:.2f}",
                    ),
                ],
                spacing=12,
            ),
        ],
        spacing=8,
    )

def _build_stat_card(self, icon: str, label: str, value: str) -> ft.Container:
    """Build a single stat card."""
    theme = get_theme()
    return ft.Container(
        content=ft.Column(
            [
                ft.Icon(icon, size=24, color=theme.colors.primary),
                ft.Text(value, size=20, weight=ft.FontWeight.BOLD),
                ft.Text(label, size=12, color=theme.colors.muted),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=4,
        ),
        padding=ft.Padding.all(16),
        bgcolor=theme.colors.surface_container,
        border_radius=12,
        expand=True,
    )
```

- [ ] **Step 4: Commit overview enhancements**

```bash
git add src/pyclaw/ui/panels/overview/view.py src/pyclaw/ui/dashboard_panel.py
git commit -m "feat(ui): add quick action cards and usage stats to overview"
```

---

## Task 10: Create Inbox Panel Infrastructure

**Files:**
- Create: `src/pyclaw/ui/panels/inbox/__init__.py`
- Create: `src/pyclaw/ui/panels/inbox/state.py`
- Create: `src/pyclaw/ui/panels/inbox/repository.py`
- Create: `src/pyclaw/ui/panels/inbox/controller.py`
- Create: `src/pyclaw/ui/panels/inbox/view.py`

- [ ] **Step 1: Create inbox package __init__.py**

Create `src/pyclaw/ui/panels/inbox/__init__.py`:

```python
"""Inbox panel — multi-channel unified inbox."""

from pyclaw.ui.panels.inbox.controller import InboxController
from pyclaw.ui.panels.inbox.view import InboxView

__all__ = ["InboxController", "InboxView"]
```

- [ ] **Step 2: Create state.py**

Create `src/pyclaw/ui/panels/inbox/state.py`:

```python
"""Inbox panel state management."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from pyclaw.ui.core.reactive import Reactive


@dataclass
class ChannelInfo:
    """Information about a connected channel."""
    id: str
    name: str
    icon: str
    unread_count: int = 0
    status: str = "offline"  # online, away, offline


@dataclass
class InboxMessage:
    """A message in the inbox."""
    id: str
    channel_id: str
    channel_name: str
    sender: str
    content: str
    timestamp: datetime
    is_read: bool = False
    presence_status: str = "unknown"
    is_typing: bool = False


@dataclass
class InboxState:
    """State for the Inbox panel."""
    channels: Reactive[list[ChannelInfo]] = field(default_factory=lambda: Reactive(list))
    messages: Reactive[list[InboxMessage]] = field(default_factory=lambda: Reactive(list))
    selected_channel: Reactive[str | None] = field(default_factory=lambda: Reactive(str | None))
    loading: Reactive[bool] = field(default_factory=lambda: Reactive(False))
    error: Reactive[str | None] = field(default_factory=lambda: Reactive(str | None))
    filter_text: Reactive[str] = field(default_factory=lambda: Reactive(""))
```

- [ ] **Step 3: Create repository.py**

Create `src/pyclaw/ui/panels/inbox/repository.py`:

```python
"""Inbox panel data repository."""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.ui.panels.inbox.state import ChannelInfo, InboxMessage

logger = logging.getLogger(__name__)


class InboxRepository:
    """Repository for fetching inbox data from Gateway."""

    def __init__(self, gateway_client: Any) -> None:
        """Initialize repository with Gateway client."""
        self._gw = gateway_client

    async def get_channels(self) -> list[ChannelInfo]:
        """Fetch list of configured channels."""
        if not self._gw or not getattr(self._gw, "connected", False):
            return []

        try:
            result = await self._gw.call("channels.list", timeout=10.0)
            channels_data = result.get("channels", [])
            return [
                ChannelInfo(
                    id=ch.get("id", ""),
                    name=ch.get("name", ch.get("id", "")),
                    icon=ch.get("icon", "chat"),
                    unread_count=ch.get("unread_count", 0),
                    status=ch.get("status", "offline"),
                )
                for ch in channels_data
            ]
        except Exception as e:
            logger.warning(f"Failed to fetch channels: {e}")
            return []

    async def get_messages(
        self,
        channel_id: str | None = None,
        limit: int = 50,
    ) -> list[InboxMessage]:
        """Fetch messages, optionally filtered by channel."""
        if not self._gw or not getattr(self._gw, "connected", False):
            return []

        try:
            params = {"limit": limit}
            if channel_id:
                params["channel_id"] = channel_id

            result = await self._gw.call("inbox.get_messages", params, timeout=10.0)
            messages_data = result.get("messages", [])

            from datetime import datetime
            return [
                InboxMessage(
                    id=msg.get("id", ""),
                    channel_id=msg.get("channel_id", ""),
                    channel_name=msg.get("channel_name", ""),
                    sender=msg.get("sender", "Unknown"),
                    content=msg.get("content", ""),
                    timestamp=datetime.fromisoformat(msg["timestamp"]) if "timestamp" in msg else datetime.now(),
                    is_read=msg.get("is_read", False),
                    presence_status=msg.get("presence_status", "unknown"),
                )
                for msg in messages_data
            ]
        except Exception as e:
            logger.warning(f"Failed to fetch messages: {e}")
            return []

    async def send_reply(self, message_id: str, reply: str) -> bool:
        """Send a reply to a message."""
        if not self._gw or not getattr(self._gw, "connected", False):
            return False

        try:
            await self._gw.call(
                "inbox.reply",
                {"message_id": message_id, "reply": reply},
                timeout=10.0,
            )
            return True
        except Exception as e:
            logger.warning(f"Failed to send reply: {e}")
            return False

    async def dismiss_message(self, message_id: str) -> bool:
        """Dismiss a message."""
        if not self._gw or not getattr(self._gw, "connected", False):
            return False

        try:
            await self._gw.call(
                "inbox.dismiss",
                {"message_id": message_id},
                timeout=10.0,
            )
            return True
        except Exception as e:
            logger.warning(f"Failed to dismiss message: {e}")
            return False
```

- [ ] **Step 4: Create controller.py**

Create `src/pyclaw/ui/panels/inbox/controller.py`:

```python
"""Inbox panel controller."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from pyclaw.ui.core.base_controller import BaseController
from pyclaw.ui.core.event_bus import EventBus
from pyclaw.ui.panels.inbox.repository import InboxRepository
from pyclaw.ui.panels.inbox.state import InboxState

logger = logging.getLogger(__name__)


class InboxController(BaseController[InboxState]):
    """Controller for the Inbox panel."""

    def __init__(self, repository: InboxRepository, event_bus: EventBus) -> None:
        """Initialize controller."""
        self._repository = repository
        self._event_bus = event_bus
        self._state = InboxState()
        super().__init__(self._state)

    @property
    def state(self) -> InboxState:
        """Get the panel state."""
        return self._state

    async def refresh(self) -> None:
        """Refresh channels and messages."""
        self._state.loading.value = True
        self._state.error.value = None

        try:
            # Fetch channels and messages in parallel
            channels, messages = await asyncio.gather(
                self._repository.get_channels(),
                self._repository.get_messages(self._state.selected_channel.value),
            )
            self._state.channels.value = channels
            self._state.messages.value = messages
        except Exception as e:
            logger.error(f"Failed to refresh inbox: {e}")
            self._state.error.value = str(e)
        finally:
            self._state.loading.value = False

    async def select_channel(self, channel_id: str | None) -> None:
        """Select a channel and filter messages."""
        self._state.selected_channel.value = channel_id
        await self.refresh()

    async def send_reply(self, message_id: str, reply: str) -> bool:
        """Send a reply to a message."""
        success = await self._repository.send_reply(message_id, reply)
        if success:
            await self.refresh()
        return success

    async def dismiss_message(self, message_id: str) -> bool:
        """Dismiss a message."""
        success = await self._repository.dismiss_message(message_id)
        if success:
            await self.refresh()
        return success

    def set_filter(self, text: str) -> None:
        """Set filter text for messages."""
        self._state.filter_text.value = text
```

- [ ] **Step 5: Create view.py**

Create `src/pyclaw/ui/panels/inbox/view.py`:

```python
"""Inbox panel view — multi-channel unified inbox UI."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import flet as ft

from pyclaw.ui.components import empty_state_enhanced, page_header, presence_dot, typing_indicator
from pyclaw.ui.core.base_panel import BasePanel
from pyclaw.ui.i18n import t
from pyclaw.ui.panels.inbox.controller import InboxController
from pyclaw.ui.panels.inbox.state import InboxMessage
from pyclaw.ui.theme import get_theme

logger = logging.getLogger(__name__)


class InboxView(BasePanel):
    """Multi-channel unified inbox view."""

    def __init__(self, controller: InboxController) -> None:
        """Initialize view with controller."""
        self._channel_list: ft.ListView | None = None
        self._message_list: ft.ListView | None = None
        self._reply_input: ft.TextField | None = None

        super().__init__(controller)

        # Subscribe to state changes
        self._add_unsubscribe(controller.state.channels.subscribe(self._on_channels_changed))
        self._add_unsubscribe(controller.state.messages.subscribe(self._on_messages_changed))
        self._add_unsubscribe(controller.state.loading.subscribe(self._on_loading_changed))

    @property
    def _controller(self) -> InboxController:
        return self._controller_ref  # type: ignore

    def _build_header(self) -> ft.Control:
        """Build panel header."""
        return page_header(
            ft.Icons.INBOX,
            t("inbox.title", default="Inbox"),
            actions=[
                ft.IconButton(
                    icon=ft.Icons.FILTER_LIST,
                    tooltip=t("inbox.filter", default="Filter"),
                    on_click=lambda e: self._toggle_filter(),
                ),
                ft.IconButton(
                    icon=ft.Icons.REFRESH,
                    tooltip=t("common.refresh", default="Refresh"),
                    on_click=lambda e: self._fire_async(self._controller.refresh()),
                ),
            ],
        )

    def _build_content(self) -> ft.Control:
        """Build main content area."""
        theme = get_theme()

        # Channel selector (left side)
        self._channel_list = ft.ListView(
            spacing=4,
            padding=ft.Padding.all(8),
            width=200,
            expand=True,
        )

        # Message list (right side)
        self._message_list = ft.ListView(
            spacing=8,
            padding=ft.Padding.all(16),
            expand=True,
        )

        # Reply input
        self._reply_input = ft.TextField(
            hint_text=t("chat.placeholder", default="Type a reply..."),
            expand=True,
            border_radius=24,
        )

        # Layout
        return ft.Row(
            [
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(
                                t("inbox.all_channels", default="All Channels"),
                                size=12,
                                weight=ft.FontWeight.W_500,
                                color=theme.colors.muted,
                            ),
                            self._channel_list,
                        ],
                        spacing=8,
                    ),
                    width=200,
                    border=ft.Border.only(right=ft.BorderSide(0.5, theme.colors.border)),
                ),
                ft.Column(
                    [
                        self._message_list,
                        ft.Container(
                            content=ft.Row(
                                [self._reply_input],
                                spacing=8,
                            ),
                            padding=ft.Padding.all(8),
                        ),
                    ],
                    expand=True,
                ),
            ],
            expand=True,
            spacing=0,
        )

    def _build_channel_item(self, channel: Any) -> ft.Container:
        """Build a channel list item."""
        theme = get_theme()
        is_selected = self._controller.state.selected_channel.value == channel.id

        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.CHAT, size=18, color=theme.colors.primary),
                    ft.Text(channel.name, size=13, expand=True),
                    ft.Container(
                        content=ft.Text(
                            str(channel.unread_count),
                            size=11,
                            color=ft.Colors.WHITE if channel.unread_count > 0 else theme.colors.muted,
                        ),
                        bgcolor=theme.colors.primary if channel.unread_count > 0 else ft.Colors.TRANSPARENT,
                        border_radius=10,
                        padding=ft.Padding.symmetric(horizontal=6, vertical=2),
                        visible=channel.unread_count > 0,
                    ),
                ],
                spacing=8,
            ),
            padding=ft.Padding.symmetric(horizontal=8, vertical=6),
            border_radius=8,
            bgcolor=theme.colors.primary_container if is_selected else ft.Colors.TRANSPARENT,
            on_click=lambda e, cid=channel.id: self._fire_async(
                self._controller.select_channel(cid)
            ),
        )

    def _build_message_card(self, msg: InboxMessage) -> ft.Container:
        """Build a message card."""
        theme = get_theme()

        # Header with channel info and presence
        header = ft.Row(
            [
                ft.Icon(ft.Icons.CHAT, size=14, color=theme.colors.primary),
                ft.Text(msg.channel_name, size=12, weight=ft.FontWeight.W_500),
                ft.Text("•", size=12, color=theme.colors.muted),
                ft.Text(msg.sender, size=12, color=theme.colors.muted),
                presence_dot(msg.presence_status, size=6),
            ],
            spacing=4,
        )

        # Content
        content_col = ft.Column(
            [
                ft.Text(msg.content, size=14, max_lines=5, overflow=ft.TextOverflow.ELLIPSIS),
            ],
            spacing=4,
        )

        # Typing indicator (if applicable)
        if msg.is_typing:
            content_col.controls.append(typing_indicator())

        # Actions
        actions = ft.Row(
            [
                ft.TextButton(
                    t("inbox.reply", default="Reply"),
                    icon=ft.Icons.REPLY,
                    on_click=lambda e, mid=msg.id: self._handle_reply(mid),
                ),
                ft.TextButton(
                    t("inbox.dismiss", default="Dismiss"),
                    icon=ft.Icons.CLOSE,
                    on_click=lambda e, mid=msg.id: self._fire_async(
                        self._controller.dismiss_message(mid)
                    ),
                ),
            ],
            spacing=8,
        )

        # Timestamp
        timestamp = ft.Text(
            self._format_timestamp(msg.timestamp),
            size=11,
            color=theme.colors.muted,
        )

        return ft.Container(
            content=ft.Column(
                [
                    ft.Row([header, timestamp], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    content_col,
                    actions,
                ],
                spacing=8,
            ),
            padding=ft.Padding.all(12),
            bgcolor=theme.colors.surface_container,
            border_radius=12,
            border=ft.Border.all(0.5, theme.colors.border),
        )

    def _format_timestamp(self, ts: datetime) -> str:
        """Format timestamp for display."""
        now = datetime.now()
        diff = now - ts

        if diff.days == 0:
            if diff.seconds < 3600:
                return f"{diff.seconds // 60}m ago"
            return ts.strftime("%H:%M")
        elif diff.days == 1:
            return t("inbox.time_yesterday", default="Yesterday")
        elif diff.days < 7:
            return ts.strftime("%A")
        else:
            return ts.strftime("%Y-%m-%d")

    def _toggle_filter(self) -> None:
        """Toggle filter panel."""
        # TODO: Implement filter dialog
        pass

    def _handle_reply(self, message_id: str) -> None:
        """Handle reply to a message."""
        if self._reply_input and self._reply_input.value:
            self._fire_async(
                self._controller.send_reply(message_id, self._reply_input.value)
            )
            self._reply_input.value = ""
            self._safe_update(self._reply_input)

    def _on_channels_changed(self, channels: list) -> None:
        """Handle channels state change."""
        if not self._channel_list:
            return

        # Add "All Channels" option
        all_item = ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.FOLDER_OUTLINED, size=18),
                    ft.Text(t("inbox.all_channels", default="All Channels"), size=13),
                ],
                spacing=8,
            ),
            padding=ft.Padding.symmetric(horizontal=8, vertical=6),
            border_radius=8,
            on_click=lambda e: self._fire_async(self._controller.select_channel(None)),
        )

        self._channel_list.controls = [
            all_item,
            ft.Divider(height=1),
            *[self._build_channel_item(ch) for ch in channels],
        ]
        self._safe_update(self._channel_list)

    def _on_messages_changed(self, messages: list[InboxMessage]) -> None:
        """Handle messages state change."""
        if not self._message_list:
            return

        if not messages:
            self._message_list.controls = [
                empty_state_enhanced(
                    icon=ft.Icons.INBOX,
                    title=t("inbox.empty_title", default="No Messages"),
                    hint=t("inbox.empty_hint", default="Messages from connected channels will appear here"),
                    action_label=t("inbox.empty_action", default="Add Channel"),
                    on_action=lambda e: self._handle_add_channel(),
                )
            ]
        else:
            self._message_list.controls = [
                self._build_message_card(msg) for msg in messages
            ]
        self._safe_update(self._message_list)

    def _on_loading_changed(self, loading: bool) -> None:
        """Handle loading state change."""
        # TODO: Show loading indicator
        pass

    def _handle_add_channel(self) -> None:
        """Navigate to channel settings."""
        # TODO: Navigate to channel configuration
        pass

    async def _refresh_data(self) -> None:
        """Refresh panel data."""
        await self._controller.refresh()
```

- [ ] **Step 6: Commit inbox panel**

```bash
git add src/pyclaw/ui/panels/inbox/
git commit -m "feat(ui): add multi-channel inbox panel infrastructure"
```

---

## Task 11: Add Inbox to Navigation

**Files:**
- Modify: `src/pyclaw/ui/app.py`

- [ ] **Step 1: Add Inbox to navigation items**

In `src/pyclaw/ui/app.py`, add Inbox to the `nav_items` list:

```python
nav_items = [
    (ft.Icons.INBOX_OUTLINED, ft.Icons.INBOX, "Inbox"),  # Add Inbox first
    (ft.Icons.CHAT_BUBBLE_OUTLINE, ft.Icons.CHAT_BUBBLE, "Chat"),
    (ft.Icons.HISTORY_OUTLINED, ft.Icons.HISTORY, "Sessions"),
    # ... rest of items
]
```

- [ ] **Step 2: Create Inbox panel instance**

Add Inbox panel initialization in `main` method:

```python
from pyclaw.ui.panels.inbox import InboxController, InboxView
from pyclaw.ui.panels.inbox.repository import InboxRepository

inbox_repo = InboxRepository(self._gw)
inbox_ctrl = InboxController(inbox_repo, self._event_bus)
self._inbox_panel = InboxView(inbox_ctrl)
self._panels["inbox"] = self._inbox_panel
```

- [ ] **Step 3: Add to content area switch**

In the navigation handler, add case for Inbox:

```python
if idx == 0:  # Inbox
    self._content_area.controls = [self._inbox_panel]
elif idx == 1:  # Chat
    self._content_area.controls = [self._chat_view]
# ... etc
```

- [ ] **Step 4: Commit navigation update**

```bash
git add src/pyclaw/ui/app.py
git commit -m "feat(ui): add Inbox to main navigation"
```

---

## Task 12: Enhance Input Area with Quick Actions

**Files:**
- Modify: `src/pyclaw/ui/chat_view.py`

- [ ] **Step 1: Enhance quick action bar with better icons**

Update `_quick_action_bar` in `ChatView`:

```python
self._quick_action_bar = ft.Row(
    controls=[
        ft.IconButton(
            icon=ft.Icons.ATTACH_FILE,
            icon_size=18,
            tooltip=t("toolbar.attach", default="Attach file"),
            on_click=lambda e: self._handle_attach(),
            style=ft.ButtonStyle(
                color=theme.colors.on_surface_variant,
            ),
        ),
        ft.IconButton(
            icon=ft.Icons.MIC_NONE,
            icon_size=18,
            tooltip=t("toolbar.voice", default="Voice input"),
            on_click=lambda e: self._handle_voice(),
            style=ft.ButtonStyle(
                color=theme.colors.on_surface_variant,
            ),
        ),
        ft.IconButton(
            icon=ft.Icons.ALTERNATE_EMAIL,
            icon_size=18,
            tooltip=t("chat.quick_mention", default="Mention"),
            on_click=lambda e: self._prefill_input("@"),
            style=ft.ButtonStyle(
                color=theme.colors.on_surface_variant,
            ),
        ),
        ft.IconButton(
            icon=ft.Icons.HISTORY,
            icon_size=18,
            tooltip=t("chat.search_history", default="Search history"),
            on_click=lambda e: _fire_async(self._toggle_search, e),
            style=ft.ButtonStyle(
                color=theme.colors.on_surface_variant,
            ),
        ),
        ft.Container(expand=True),  # Spacer
        ft.IconButton(
            icon=ft.Icons.KEYBOARD_COMMAND_KEY,
            icon_size=18,
            tooltip=t("chat.shortcuts", default="Keyboard shortcuts"),
            on_click=lambda e: self._show_shortcuts_dialog(),
            style=ft.ButtonStyle(
                color=theme.colors.muted,
            ),
        ),
    ],
    spacing=4,
    alignment=ft.MainAxisAlignment.START,
)
```

- [ ] **Step 2: Add helper methods**

```python
def _handle_attach(self) -> None:
    """Handle file attachment."""
    self._prefill_input("/attach ")

def _handle_voice(self) -> None:
    """Handle voice input."""
    self._prefill_input("/voice ")

def _show_shortcuts_dialog(self) -> None:
    """Show keyboard shortcuts dialog."""
    # TODO: Implement shortcuts dialog
    pass
```

- [ ] **Step 3: Commit input area enhancements**

```bash
git add src/pyclaw/ui/chat_view.py
git commit -m "feat(ui): enhance input area quick actions"
```

---

## Task 13: Final Integration and Testing

**Files:**
- Test: Run existing tests
- Test: Manual UI verification

- [ ] **Step 1: Run existing tests**

```bash
cd /mnt/g/chensai/openclaw-py
source .venv/bin/activate
pytest tests/ -v --tb=short
```

- [ ] **Step 2: Verify UI renders correctly**

```bash
pnpm --filter @pyclaw/web dev
```

- [ ] **Step 3: Check i18n keys**

Verify all translation keys are present in both locales.

- [ ] **Step 4: Create integration test**

Create `tests/pyclaw/ui/test_inbox_panel.py`:

```python
"""Tests for Inbox panel."""

import pytest

from pyclaw.ui.panels.inbox.controller import InboxController
from pyclaw.ui.panels.inbox.state import ChannelInfo, InboxMessage
from pyclaw.ui.panels.inbox.repository import InboxRepository


class MockGatewayClient:
    """Mock Gateway client for testing."""

    def __init__(self, connected: bool = True) -> None:
        self.connected = connected

    async def call(self, method: str, params: dict | None = None, **kwargs) -> dict:
        if method == "channels.list":
            return {"channels": [
                {"id": "telegram", "name": "Telegram", "unread_count": 5, "status": "online"},
                {"id": "whatsapp", "name": "WhatsApp", "unread_count": 0, "status": "offline"},
            ]}
        elif method == "inbox.get_messages":
            return {"messages": []}
        return {}


@pytest.fixture
def controller():
    from pyclaw.ui.core import EventBus
    repo = InboxRepository(MockGatewayClient())
    return InboxController(repo, EventBus())


@pytest.mark.asyncio
async def test_refresh_channels(controller):
    """Test that refresh loads channels."""
    await controller.refresh()
    assert len(controller.state.channels.value) == 2
    assert controller.state.channels.value[0].name == "Telegram"


@pytest.mark.asyncio
async def test_select_channel(controller):
    """Test selecting a channel."""
    await controller.select_channel("telegram")
    assert controller.state.selected_channel.value == "telegram"
```

- [ ] **Step 5: Commit tests**

```bash
git add tests/pyclaw/ui/test_inbox_panel.py
git commit -m "test(ui): add inbox panel tests"
```

---

## Verification Checklist

| Check | Description | Pass Criteria |
|-------|-------------|---------------|
| TC1 | Inbox panel renders | Inbox tab shows channel selector and message list |
| TC2 | Empty states enhanced | All panels show improved empty states with actions |
| TC3 | Welcome state improved | Chat welcome shows styled tips and action buttons |
| TC4 | Quick actions in overview | Dashboard shows action cards for common tasks |
| TC5 | Presence indicators work | Online/offline/typing states display correctly |
| TC6 | i18n keys complete | All new strings have translations in both locales |
| TC7 | Tests pass | `pytest tests/` passes without errors |
| TC8 | No regressions | Existing UI functionality unchanged |

---

## Summary

This plan implements the key UI/UX enhancements from `docs/RPD_CLIENT_DESIGN.md`:

1. **Translation Keys** - Add all new i18n keys for inbox and empty states
2. **Presence Indicators** - New components for online/typing status
3. **Enhanced Empty States** - Unified empty state across all panels
4. **Inbox Panel** - New multi-channel unified inbox (MVC architecture)
5. **Chat Enhancements** - Improved welcome state and input area
6. **Overview Enhancements** - Quick action cards and usage stats

All tasks follow TDD principles where applicable, maintain the existing code patterns, and integrate with the existing Gateway RPC architecture.
