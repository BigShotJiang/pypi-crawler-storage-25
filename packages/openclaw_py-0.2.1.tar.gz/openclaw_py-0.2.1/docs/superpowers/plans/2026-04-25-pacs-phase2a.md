# PACS Phase 2a: 按层扩展第一批实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task.

**Goal:** 补齐各层高价值能力——感知层、推理层、行动层各一个。

**Architecture:** 三个独立能力，各自订阅对应 Hook，互不依赖但可与 Phase 1 能力组合使用。

**Tech Stack:** Python 3.10+, pytest, asyncio

---

## Task 1: ContextWindowManager 感知层能力

**Files:**
- Create: `src/pyclaw/agents/pacs/capabilities/context_window_manager.py`
- Create: `tests/pyclaw/agents/pacs/capabilities/test_context_window_manager.py`

**功能**：订阅 `perception.pre` + `llm.pre_invoke`，防止上下文溢出，自动裁剪/摘要超长消息。

**核心逻辑**：
- 检测输入消息总 token 数是否接近模型上下文窗口限制
- 超过阈值时，按策略裁剪：保留 system + 最近 N 条 + 关键摘要
- 可配置裁剪策略：truncate（截断）、summarize（摘要）、selective（选择性保留）

- [ ] **Step 1: 创建测试文件**

```python
# tests/pyclaw/agents/pacs/capabilities/test_context_window_manager.py
import pytest
from pyclaw.agents.pacs.capabilities.context_window_manager import ContextWindowManager
from pyclaw.agents.pacs.types import AgentContext, CapabilityAction, HookEvent, HookPoint

class TestContextWindowManager:
    @pytest.fixture
    def manager(self):
        return ContextWindowManager(max_tokens=1000, reserve_ratio=0.3)

    @pytest.fixture
    def context(self):
        return AgentContext(session_id="test")

    async def test_subscribes_to_perception_and_llm_hooks(self, manager):
        """Should subscribe to PERCEPTION_PRE and LLM_PRE_INVOKE."""
        assert HookPoint.PERCEPTION_PRE in manager.subscribed_hooks
        assert HookPoint.LLM_PRE_INVOKE in manager.subscribed_hooks

    async def test_no_action_when_under_limit(self, manager, context):
        """Should not modify messages when under token limit."""
        event = HookEvent(
            hook=HookPoint.LLM_PRE_INVOKE,
            timestamp=0.0,
            messages=[{"role": "user", "content": "short"}],
        )
        result = await manager.on_event(event, context)
        assert result.action == CapabilityAction.CONTINUE
        assert result.event_modifications == {} or "messages" not in result.event_modifications

    async def test_truncates_when_over_limit(self, manager, context):
        """Should truncate messages when over token limit."""
        # Create very long message
        long_content = "word " * 500  # ~250 tokens worth
        event = HookEvent(
            hook=HookPoint.LLM_PRE_INVOKE,
            timestamp=0.0,
            messages=[
                {"role": "system", "content": "You are helpful"},
                {"role": "user", "content": long_content},
            ],
        )
        result = await manager.on_event(event, context)
        assert result.action == CapabilityAction.CONTINUE
        # Messages should be truncated
        if result.event_modifications.get("messages"):
            assert len(result.event_modifications["messages"]) <= 2

    async def test_preserves_system_messages(self, manager, context):
        """System messages should always be preserved."""
        event = HookEvent(
            hook=HookPoint.LLM_PRE_INVOKE,
            timestamp=0.0,
            messages=[
                {"role": "system", "content": "Important instruction"},
                {"role": "user", "content": "query"},
            ],
        )
        result = await manager.on_event(event, context)
        # System message should be in result
        messages = result.event_modifications.get("messages", event.messages)
        system_msgs = [m for m in messages if m.get("role") == "system"]
        assert len(system_msgs) >= 1

    async def test_belongs_to_perception_layer(self, manager):
        """ContextWindowManager should be in perception layer."""
        from pyclaw.agents.pacs.types import CapabilityLayer
        assert manager.layer == CapabilityLayer.PERCEPTION
```

- [ ] **Step 2: 实现 ContextWindowManager**

```python
# src/pyclaw/agents/pacs/capabilities/context_window_manager.py
"""ContextWindowManager — prevent context overflow with auto-trimming.

Subscribes to:
  - PERCEPTION_PRE: Pre-check context length
  - LLM_PRE_INVOKE: Final check before LLM call

Strategies:
  - truncate: Remove oldest non-system messages
  - summarize: Replace old messages with summary (requires LLM)
  - selective: Keep important messages based on metadata
"""

from __future__ import annotations

import logging
import re
from typing import Any, Literal

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)


class ContextWindowManager(AgenticCapability):
    """Manage context window to prevent overflow.

    Attributes:
        max_tokens: Maximum tokens allowed (approximate).
        reserve_ratio: Ratio of context to reserve for response.
        strategy: Truncation strategy (truncate/summarize/selective).
        keep_recent: Always keep this many recent message pairs.
    """

    name = "context_window_manager"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks = [HookPoint.PERCEPTION_PRE, HookPoint.LLM_PRE_INVOKE]
    priority = 15  # Run after SemanticFilter

    def __init__(
        self,
        max_tokens: int = 128000,
        reserve_ratio: float = 0.3,
        strategy: Literal["truncate", "summarize", "selective"] = "truncate",
        keep_recent: int = 4,
        chars_per_token: float = 4.0,
    ) -> None:
        self.max_tokens = max_tokens
        self.reserve_ratio = reserve_ratio
        self.strategy = strategy
        self.keep_recent = keep_recent
        self.chars_per_token = chars_per_token

    def _estimate_tokens(self, messages: list[dict]) -> int:
        """Estimate token count from messages (rough approximation)."""
        total_chars = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total_chars += len(content)
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and "text" in block:
                        total_chars += len(block["text"])
        return int(total_chars / self.chars_per_token)

    async def should_activate(self, event: HookEvent, context: AgentContext) -> bool:
        """Activate only if there are messages."""
        return bool(event.messages)

    async def on_event(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        """Check and trim context if needed."""
        messages = event.messages or []
        if not messages:
            return CapabilityResult(action=CapabilityAction.CONTINUE)

        current_tokens = self._estimate_tokens(messages)
        target_tokens = int(self.max_tokens * (1 - self.reserve_ratio))

        if current_tokens <= target_tokens:
            return CapabilityResult(action=CapabilityAction.CONTINUE)

        logger.info(
            "Context overflow: %d tokens > %d target, applying %s strategy",
            current_tokens,
            target_tokens,
            self.strategy,
        )

        # Apply truncation strategy
        trimmed = self._truncate_messages(messages, target_tokens)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={"messages": trimmed},
        )

    def _truncate_messages(self, messages: list[dict], target_tokens: int) -> list[dict]:
        """Truncate messages to fit target token budget."""
        result: list[dict] = []
        system_msgs = [m for m in messages if m.get("role") == "system"]
        non_system = [m for m in messages if m.get("role") != "system"]

        # Always keep system messages
        result.extend(system_msgs)
        current_tokens = self._estimate_tokens(result)

        # Keep recent messages
        recent_to_keep = non_system[-self.keep_recent * 2 :] if len(non_system) > self.keep_recent * 2 else non_system

        for msg in reversed(recent_to_keep):
            msg_tokens = self._estimate_tokens([msg])
            if current_tokens + msg_tokens <= target_tokens:
                result.insert(len(system_msgs), msg)
                current_tokens += msg_tokens

        return result
```

- [ ] **Step 3: 运行测试**

```bash
source .venv/bin/activate && pytest tests/pyclaw/agents/pacs/capabilities/test_context_window_manager.py -v
```

- [ ] **Step 4: 提交**

---

## Task 2: ReflectionLoop 推理层能力

**Files:**
- Create: `src/pyclaw/agents/pacs/capabilities/reflection_loop.py`
- Create: `tests/pyclaw/agents/pacs/capabilities/test_reflection_loop.py`

**功能**：订阅 `turn.end`，2-3 轮自评修订，提升输出质量。

**核心逻辑**：
- 在 turn 结束时检查是否需要反思
- 如果质量不达标，触发额外推理轮次进行改进
- 使用 `working_memory` 存储反思历史

- [ ] **Step 1: 创建测试文件**

```python
# tests/pyclaw/agents/pacs/capabilities/test_reflection_loop.py
import pytest
from pyclaw.agents.pacs.capabilities.reflection_loop import ReflectionLoop
from pyclaw.agents.pacs.types import AgentContext, CapabilityAction, HookEvent, HookPoint

class TestReflectionLoop:
    @pytest.fixture
    def loop(self):
        return ReflectionLoop(max_reflections=2)

    @pytest.fixture
    def context(self):
        ctx = AgentContext(session_id="test")
        ctx.working_memory = []
        return ctx

    async def test_subscribes_to_turn_end(self, loop):
        """Should subscribe to TURN_END."""
        assert HookPoint.TURN_END in loop.subscribed_hooks

    async def test_first_reflection_starts_loop(self, loop, context):
        """First reflection should start reflection process."""
        event = HookEvent(hook=HookPoint.TURN_END, timestamp=0.0)
        context.set("reflection_count", 0)
        
        result = await loop.on_event(event, context)
        assert result.action == CapabilityAction.CONTINUE

    async def test_stops_after_max_reflections(self, loop, context):
        """Should stop after max reflections reached."""
        context.set("reflection_count", 3)  # Already at max
        
        event = HookEvent(hook=HookPoint.TURN_END, timestamp=0.0)
        result = await loop.on_event(event, context)
        # Should continue without requesting more reflections
        assert result.action == CapabilityAction.CONTINUE

    async def test_belongs_to_reasoning_layer(self, loop):
        """ReflectionLoop should be in reasoning layer."""
        from pyclaw.agents.pacs.types import CapabilityLayer
        assert loop.layer == CapabilityLayer.REASONING

    async def test_quality_check_determines_reflection(self, loop, context):
        """Low quality should trigger reflection."""
        # This test verifies the quality check logic exists
        context.set("reflection_count", 0)
        context.set("last_output_quality", 0.3)  # Low quality
        
        event = HookEvent(hook=HookPoint.TURN_END, timestamp=0.0)
        result = await loop.on_event(event, context)
        assert result.action == CapabilityAction.CONTINUE
```

- [ ] **Step 2: 实现 ReflectionLoop**

```python
# src/pyclaw/agents/pacs/capabilities/reflection_loop.py
"""ReflectionLoop — 2-3 round self-critique for output improvement.

Subscribes to:
  - TURN_END: Check output quality, trigger reflections if needed

Reflection cycle:
  1. Evaluate output quality (heuristic or LLM-assisted)
  2. If below threshold, add reflection prompt to working_memory
  3. Agent runs additional turn with reflection context
  4. Repeat until quality OK or max reflections reached
"""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

REFLECTION_PROMPT = """Review your previous response and improve it:

1. Identify any errors, omissions, or unclear parts
2. Consider alternative approaches
3. Provide an improved, more comprehensive response

Focus on accuracy and completeness."""


class ReflectionLoop(AgenticCapability):
    """Run 2-3 rounds of self-critique to improve output quality.

    Attributes:
        max_reflections: Maximum reflection rounds per turn.
        quality_threshold: Minimum quality score to stop reflecting.
    """

    name = "reflection_loop"
    layer = CapabilityLayer.REASONING
    subscribed_hooks = [HookPoint.TURN_END]
    priority = 50  # After other turn-end processing

    def __init__(
        self,
        max_reflections: int = 2,
        quality_threshold: float = 0.7,
    ) -> None:
        self.max_reflections = max_reflections
        self.quality_threshold = quality_threshold

    async def should_activate(self, event: HookEvent, context: AgentContext) -> bool:
        """Only activate on TURN_END."""
        return event.hook == HookPoint.TURN_END

    async def on_event(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        """Check quality and potentially trigger reflection."""
        reflection_count = context.get("reflection_count", 0)

        if reflection_count >= self.max_reflections:
            logger.debug("Max reflections reached: %d", reflection_count)
            return CapabilityResult(action=CapabilityAction.CONTINUE)

        # Check output quality
        quality = self._estimate_quality(event, context)
        context.set("last_output_quality", quality)

        if quality >= self.quality_threshold:
            logger.debug("Quality sufficient: %.2f >= %.2f", quality, self.quality_threshold)
            return CapabilityResult(action=CapabilityAction.CONTINUE)

        # Need reflection
        reflection_count += 1
        context.set("reflection_count", reflection_count)
        logger.info(
            "Triggering reflection %d/%d (quality: %.2f)",
            reflection_count,
            self.max_reflections,
            quality,
        )

        # Add reflection context to working memory
        context.working_memory.append({
            "type": "reflection_request",
            "round": reflection_count,
            "prompt": REFLECTION_PROMPT,
            "previous_quality": quality,
        })

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={"current_phase": "reflecting"},
        )

    def _estimate_quality(self, event: HookEvent, context: AgentContext) -> float:
        """Estimate output quality (heuristic for MVP)."""
        # Simple heuristic: check if response exists and is substantial
        messages = event.messages or []
        assistant_msgs = [m for m in messages if m.get("role") == "assistant"]
        
        if not assistant_msgs:
            return 0.0

        last_assistant = assistant_msgs[-1]
        content = last_assistant.get("content", "")
        
        if not content:
            return 0.0

        # Length-based heuristic
        if len(content) < 50:
            return 0.3
        elif len(content) < 200:
            return 0.5
        else:
            return 0.8  # Placeholder - in real implementation, use LLM evaluation
```

- [ ] **Step 3: 运行测试并提交**

---

## Task 3: ActionValidator 行动层能力

**Files:**
- Create: `src/pyclaw/agents/pacs/capabilities/action_validator.py`
- Create: `tests/pyclaw/agents/pacs/capabilities/test_action_validator.py`

**功能**：订阅 `tool.pre_execute`，参数安全校验，防 SQL 注入/路径遍历，`critical=True`。

**核心逻辑**：
- 检查工具参数中的危险模式
- 阻止危险操作（路径遍历、SQL 注入、命令注入）
- 返回 ABORT 阻止执行

- [ ] **Step 1: 创建测试文件**

```python
# tests/pyclaw/agents/pacs/capabilities/test_action_validator.py
import pytest
from pyclaw.agents.pacs.capabilities.action_validator import ActionValidator
from pyclaw.agents.pacs.types import AgentContext, CapabilityAction, HookEvent, HookPoint

class TestActionValidator:
    @pytest.fixture
    def validator(self):
        return ActionValidator()

    @pytest.fixture
    def context(self):
        return AgentContext(session_id="test")

    async def test_subscribes_to_tool_pre_execute(self, validator):
        """Should subscribe to TOOL_PRE_EXECUTE."""
        assert HookPoint.TOOL_PRE_EXECUTE in validator.subscribed_hooks

    async def test_passes_safe_arguments(self, validator, context):
        """Safe arguments should pass through."""
        event = HookEvent(
            hook=HookPoint.TOOL_PRE_EXECUTE,
            timestamp=0.0,
            tool_call={"id": "tc1", "name": "search", "arguments": {"query": "hello world"}},
        )
        result = await validator.on_event(event, context)
        assert result.action == CapabilityAction.CONTINUE

    async def test_blocks_path_traversal(self, validator, context):
        """Path traversal attempts should be blocked."""
        event = HookEvent(
            hook=HookPoint.TOOL_PRE_EXECUTE,
            timestamp=0.0,
            tool_call={
                "id": "tc1",
                "name": "read_file",
                "arguments": {"path": "../../../etc/passwd"},
            },
        )
        result = await validator.on_event(event, context)
        assert result.action == CapabilityAction.ABORT

    async def test_blocks_sql_injection(self, validator, context):
        """SQL injection attempts should be blocked."""
        event = HookEvent(
            hook=HookPoint.TOOL_PRE_EXECUTE,
            timestamp=0.0,
            tool_call={
                "id": "tc1",
                "name": "query_db",
                "arguments": {"sql": "SELECT * FROM users; DROP TABLE users;--"},
            },
        )
        result = await validator.on_event(event, context)
        assert result.action == CapabilityAction.ABORT

    async def test_blocks_command_injection(self, validator, context):
        """Command injection attempts should be blocked."""
        event = HookEvent(
            hook=HookPoint.TOOL_PRE_EXECUTE,
            timestamp=0.0,
            tool_call={
                "id": "tc1",
                "name": "execute",
                "arguments": {"cmd": "ls; rm -rf /"},
            },
        )
        result = await validator.on_event(event, context)
        assert result.action == CapabilityAction.ABORT

    async def test_is_critical(self, validator):
        """ActionValidator should be marked critical."""
        assert validator.critical is True

    async def test_belongs_to_action_layer(self, validator):
        """ActionValidator should be in action layer."""
        from pyclaw.agents.pacs.types import CapabilityLayer
        assert validator.layer == CapabilityLayer.ACTION
```

- [ ] **Step 2: 实现 ActionValidator**

```python
# src/pyclaw/agents/pacs/capabilities/action_validator.py
"""ActionValidator — validate tool arguments for security risks.

Subscribes to:
  - TOOL_PRE_EXECUTE: Check arguments before execution

Safety checks:
  - Path traversal: ../, absolute paths outside workspace
  - SQL injection: suspect SQL patterns in arguments
  - Command injection: shell metacharacters in commands
  - Sensitive data exposure: API keys, passwords in args

This is a critical capability - failures will ABORT execution.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Dangerous patterns
PATH_TRAVERSAL_PATTERN = re.compile(r"\.\.[\\/]|^/etc/|^/passwd|^/shadow")
SQL_INJECTION_PATTERN = re.compile(
    r"(;|\b)(DROP|DELETE|TRUNCATE|UPDATE|INSERT)\s|"
    r"--\s*$|"
    r"'\s*OR\s+.*=|"
    r";\s*DROP",
    re.IGNORECASE,
)
COMMAND_INJECTION_PATTERN = re.compile(r"[;&|`]|\$\(|\|\|")

SENSITIVE_KEY_PATTERNS = [
    r"password",
    r"api[_-]?key",
    r"secret",
    r"token",
    r"credential",
]


class ActionValidator(AgenticCapability):
    """Validate tool arguments for security risks.

    Attributes:
        critical: Always True - security failures abort execution.
    """

    name = "action_validator"
    layer = CapabilityLayer.ACTION
    subscribed_hooks = [HookPoint.TOOL_PRE_EXECUTE]
    priority = 1  # Run first before any other capability
    critical = True  # Fail-closed for security

    def __init__(self, workspace_path: str | None = None) -> None:
        self.workspace_path = workspace_path

    async def should_activate(self, event: HookEvent, context: AgentContext) -> bool:
        """Always activate for tool calls."""
        return bool(event.tool_call)

    async def on_event(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        """Validate tool arguments."""
        tool_call = event.tool_call or {}
        tool_name = tool_call.get("name", "unknown")
        arguments = tool_call.get("arguments", {})

        # Check each argument
        for key, value in arguments.items():
            if not isinstance(value, str):
                continue

            # Path traversal
            if self._has_path_traversal(value):
                logger.warning(
                    "Path traversal blocked in tool %s, arg %s: %s",
                    tool_name,
                    key,
                    value[:50],
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:path_traversal:{key}",
                )

            # SQL injection
            if self._has_sql_injection(value):
                logger.warning(
                    "SQL injection blocked in tool %s, arg %s",
                    tool_name,
                    key,
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:sql_injection:{key}",
                )

            # Command injection (for exec tools)
            if tool_name in ("execute", "exec", "shell", "run_command"):
                if self._has_command_injection(value):
                    logger.warning(
                        "Command injection blocked in tool %s",
                        tool_name,
                    )
                    return CapabilityResult(
                        action=CapabilityAction.ABORT,
                        output=f"security_violation:command_injection",
                    )

        return CapabilityResult(action=CapabilityAction.CONTINUE)

    def _has_path_traversal(self, value: str) -> bool:
        return bool(PATH_TRAVERSAL_PATTERN.search(value))

    def _has_sql_injection(self, value: str) -> bool:
        return bool(SQL_INJECTION_PATTERN.search(value))

    def _has_command_injection(self, value: str) -> bool:
        return bool(COMMAND_INJECTION_PATTERN.search(value))
```

- [ ] **Step 3: 运行测试并提交**

---

## Task 4: 更新 __init__.py 导出

- [ ] **更新 `src/pyclaw/agents/pacs/capabilities/__init__.py`**

```python
"""PACS capability implementations."""

from pyclaw.agents.pacs.capabilities.action_validator import ActionValidator
from pyclaw.agents.pacs.capabilities.circuit_breaker import CircuitBreaker
from pyclaw.agents.pacs.capabilities.context_window_manager import ContextWindowManager
from pyclaw.agents.pacs.capabilities.react_controller import ReActController
from pyclaw.agents.pacs.capabilities.reflection_loop import ReflectionLoop
from pyclaw.agents.pacs.capabilities.semantic_filter import SemanticFilter

__all__ = [
    "ActionValidator",
    "CircuitBreaker",
    "ContextWindowManager",
    "ReActController",
    "ReflectionLoop",
    "SemanticFilter",
]
```

---

## Task 5: 全量测试

- [ ] 运行 `pytest tests/pyclaw/agents/pacs/ -v`
- [ ] 运行 `ruff check` + `mypy`
- [ ] 提交最终更改

---

## 验收标准

- [ ] ContextWindowManager 能检测并裁剪超长上下文
- [ ] ReflectionLoop 能触发反思循环（质量检查逻辑存在）
- [ ] ActionValidator 能阻止路径遍历、SQL 注入、命令注入
- [ ] ActionValidator 的 critical=True 生效（异常时 ABORT）
- [ ] 所有测试通过，代码质量检查通过
