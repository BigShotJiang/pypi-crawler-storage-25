# PyClaw TypeScript 迁移实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 PyClaw 的 Web UI 从 Python/Flet 技术栈完整迁移到 TypeScript 全栈架构（Next.js + Tauri + Expo）。

**Architecture:** Monorepo 结构（Turborepo + pnpm），共享包（packages/shared）包含 API 客户端、状态管理和工具函数；UI 组件库（packages/ui）基于 shadcn/ui；后端保持 Python/FastAPI，新增 REST 适配层复用现有 Gateway methods。

**Tech Stack:** Next.js 15, TypeScript 5.x, Tailwind CSS, shadcn/ui, Zustand, TanStack Query, Tauri 2.x, Expo, FastAPI

---

## 文件结构总览

```
openclaw-py/
├── apps/
│   ├── web/                          # Task 5-6 创建
│   │   ├── app/                      # Next.js App Router
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── lib/
│   │   ├── next.config.ts
│   │   ├── tailwind.config.ts
│   │   ├── postcss.config.js
│   │   └── package.json
│   │
│   ├── desktop/                      # Task 7 创建
│   │   ├── src-tauri/
│   │   ├── tauri.conf.json
│   │   └── package.json
│   │
│   └── mobile/                       # Task 8 创建
│       ├── app/
│       ├── components/
│       ├── metro.config.js
│       └── package.json
│
├── packages/
│   ├── shared/                       # Task 3-4 创建
│   │   ├── api/
│   │   ├── store/
│   │   ├── types/
│   │   ├── utils/
│   │   ├── i18n/
│   │   └── package.json
│   │
│   ├── ui/                           # Task 5 创建基础，Task 6 扩展
│   │   ├── components/ui/
│   │   ├── composite/
│   │   ├── chat/
│   │   ├── panels/
│   │   ├── lib/
│   │   ├── tailwind-preset.ts
│   │   └── package.json
│   │
│   └── eslint-config/                # Task 1 创建
│       ├── index.js
│       └── package.json
│
├── backend/                          # Task 2 创建 REST 适配
│   └── src/pyclaw/gateway/rest/
│
├── turbo.json                        # Task 1 创建
├── pnpm-workspace.yaml               # Task 1 创建
├── package.json                       # Task 1 创建
└── vitest.workspace.ts               # Task 1 创建
```

---

## Phase 1: Monorepo 脚手架 + 后端 REST 适配

### Task 1: Monorepo 初始化

**Files:**
- Create: `package.json`
- Create: `pnpm-workspace.yaml`
- Create: `turbo.json`
- Create: `vitest.workspace.ts`
- Create: `.npmrc`
- Create: `packages/eslint-config/package.json`
- Create: `packages/eslint-config/index.js`

- [ ] **Step 1: 创建根 package.json**

```json
{
  "name": "pyclaw-monorepo",
  "version": "0.1.0",
  "private": true,
  "packageManager": "pnpm@9.15.0",
  "scripts": {
    "dev": "turbo run dev",
    "build": "turbo run build",
    "lint": "turbo run lint",
    "test": "turbo run test",
    "test:e2e": "turbo run test:e2e",
    "clean": "turbo run clean && rm -rf node_modules"
  },
  "devDependencies": {
    "turbo": "^2.4.0",
    "typescript": "^5.7.0",
    "@types/node": "^22.0.0"
  }
}
```

- [ ] **Step 2: 创建 pnpm-workspace.yaml**

```yaml
packages:
  - "apps/*"
  - "packages/*"
```

- [ ] **Step 3: 创建 turbo.json**

```json
{
  "$schema": "https://turbo.build/schema.json",
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**", ".next/**", "!.next/cache/**", "out/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    },
    "lint": {
      "dependsOn": ["^build"]
    },
    "test": {
      "dependsOn": ["^build"]
    },
    "test:e2e": {
      "dependsOn": ["^build"]
    },
    "clean": {
      "cache": false
    }
  }
}
```

- [ ] **Step 4: 创建 .npmrc**

```
shamefully-hoist=true
strict-peer-dependencies=false
```

- [ ] **Step 5: 创建 vitest.workspace.ts**

```typescript
import { defineWorkspace } from 'vitest/config';

export default defineWorkspace([
  'packages/shared/vitest.config.ts',
  'packages/ui/vitest.config.ts',
  'apps/web/vitest.config.ts',
]);
```

- [ ] **Step 6: 创建 packages/eslint-config/package.json**

```json
{
  "name": "@pyclaw/eslint-config",
  "version": "0.1.0",
  "main": "index.js",
  "dependencies": {
    "eslint": "^9.0.0",
    "typescript-eslint": "^8.0.0",
    "eslint-plugin-react-hooks": "^5.0.0",
    "@typescript-eslint/parser": "^8.0.0",
    "@typescript-eslint/eslint-plugin": "^8.0.0"
  }
}
```

- [ ] **Step 7: 创建 packages/eslint-config/index.js**

```javascript
module.exports = {
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:react-hooks/recommended',
  ],
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 2024,
    sourceType: 'module',
  },
  rules: {
    '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
    '@typescript-eslint/explicit-function-return-type': 'off',
    'react-hooks/rules-of-hooks': 'error',
    'react-hooks/exhaustive-deps': 'warn',
  },
};
```

- [ ] **Step 8: 验证 monorepo 结构**

```bash
mkdir -p packages apps
pnpm install
ls -la node_modules/.bin/turbo
```

Expected: turbo 命令可用

- [ ] **Step 9: Commit**

```bash
git add package.json pnpm-workspace.yaml turbo.json vitest.workspace.ts .npmrc packages/eslint-config
git commit -m "$(cat <<'EOF'
feat: initialize monorepo with Turborepo + pnpm

- Add root package.json with turborepo scripts
- Configure pnpm workspace
- Add ESLint shared config package
- Setup vitest workspace for testing

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

### Task 2: 后端 REST 适配层

**Files:**
- Create: `backend/src/pyclaw/gateway/rest/__init__.py`
- Create: `backend/src/pyclaw/gateway/rest/router.py`
- Create: `backend/src/pyclaw/gateway/rest/agents.py`
- Create: `backend/src/pyclaw/gateway/rest/sessions.py`
- Create: `backend/src/pyclaw/gateway/rest/config.py`
- Create: `backend/src/pyclaw/gateway/rest/channels.py`
- Create: `backend/src/pyclaw/gateway/rest/models/__init__.py`
- Create: `backend/src/pyclaw/gateway/rest/models/agent.py`
- Create: `backend/src/pyclaw/gateway/rest/models/session.py`
- Create: `backend/src/pyclaw/gateway/rest/models/config.py`
- Modify: `backend/src/pyclaw/gateway/server.py` (挂载 REST router)

- [ ] **Step 1: 创建 REST models - agent.py**

```python
# backend/src/pyclaw/gateway/rest/models/agent.py
from __future__ import annotations

from pydantic import BaseModel


class AgentResponse(BaseModel):
    id: str
    session_count: int
    config: dict


class AgentCreate(BaseModel):
    agent_id: str
    config: dict | None = None


class AgentListResponse(BaseModel):
    agents: list[AgentResponse]
```

- [ ] **Step 2: 创建 REST models - session.py**

```python
# backend/src/pyclaw/gateway/rest/models/session.py
from __future__ import annotations

from pydantic import BaseModel


class SessionInfo(BaseModel):
    agentId: str
    file: str
    path: str
    size: int


class SessionListResponse(BaseModel):
    sessions: list[SessionInfo]


class MessagePreview(BaseModel):
    role: str
    content: str


class SessionPreviewResponse(BaseModel):
    messages: list[MessagePreview]


class SessionCreateRequest(BaseModel):
    agentId: str = "main"
    title: str | None = None


class SessionCreateResponse(BaseModel):
    id: str
    title: str | None = None
```

- [ ] **Step 3: 创建 REST models - config.py**

```python
# backend/src/pyclaw/gateway/rest/models/config.py
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ConfigResponse(BaseModel):
    config: dict[str, Any]


class ConfigPatchRequest(BaseModel):
    patch: dict[str, Any]
```

- [ ] **Step 4: 创建 REST models __init__.py**

```python
# backend/src/pyclaw/gateway/rest/models/__init__.py
from .agent import AgentResponse, AgentCreate, AgentListResponse
from .session import (
    SessionInfo,
    SessionListResponse,
    SessionPreviewResponse,
    SessionCreateRequest,
    SessionCreateResponse,
)
from .config import ConfigResponse, ConfigPatchRequest

__all__ = [
    "AgentResponse",
    "AgentCreate",
    "AgentListResponse",
    "SessionInfo",
    "SessionListResponse",
    "SessionPreviewResponse",
    "SessionCreateRequest",
    "SessionCreateResponse",
    "ConfigResponse",
    "ConfigPatchRequest",
]
```

- [ ] **Step 5: 创建 agents.py REST handler**

```python
# backend/src/pyclaw/gateway/rest/agents.py
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from .models.agent import AgentResponse, AgentCreate, AgentListResponse
from ..methods.agents import create_agents_handlers

router = APIRouter(prefix="/agents", tags=["agents"])

# 复用现有 WebSocket handlers 的逻辑核心
_handlers = None


def _get_handlers():
    global _handlers
    if _handlers is None:
        _handlers = create_agents_handlers()
    return _handlers


class _MockConn:
    """模拟 GatewayConnection 用于复用 handler 逻辑"""

    def __init__(self):
        self.result = None
        self.error = None

    async def send_ok(self, method: str, payload: dict):
        self.result = payload

    async def send_error(self, method: str, code: str, message: str, **kwargs):
        self.error = {"code": code, "message": message}


@router.get("", response_model=AgentListResponse)
async def list_agents():
    conn = _MockConn()
    await _get_handlers()["agents.list"](None, conn)
    if conn.error:
        raise HTTPException(status_code=500, detail=conn.error["message"])
    return AgentListResponse(
        agents=[AgentResponse(**a) for a in conn.result.get("agents", [])]
    )


@router.get("/{agent_id}", response_model=AgentResponse)
async def get_agent(agent_id: str):
    conn = _MockConn()
    await _get_handlers()["agents.list"](None, conn)
    if conn.error:
        raise HTTPException(status_code=500, detail=conn.error["message"])
    for agent in conn.result.get("agents", []):
        if agent["id"] == agent_id:
            return AgentResponse(**agent)
    raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")


@router.post("", response_model=AgentResponse, status_code=201)
async def create_agent(body: AgentCreate):
    conn = _MockConn()
    await _get_handlers()["agents.add"](
        {"agent_id": body.agent_id, "config": body.config},
        conn,
    )
    if conn.error:
        raise HTTPException(status_code=400, detail=conn.error["message"])
    # 返回新创建的 agent
    return AgentResponse(id=body.agent_id, session_count=0, config=body.config or {})


@router.delete("/{agent_id}", status_code=204)
async def delete_agent(agent_id: str):
    conn = _MockConn()
    await _get_handlers()["agents.remove"]({"agent_id": agent_id}, conn)
    if conn.error:
        raise HTTPException(status_code=404, detail=conn.error["message"])
    return None
```

- [ ] **Step 6: 创建 sessions.py REST handler**

```python
# backend/src/pyclaw/gateway/rest/sessions.py
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from .models.session import (
    SessionListResponse,
    SessionPreviewResponse,
    SessionCreateRequest,
    SessionCreateResponse,
)
from ..methods.sessions import create_session_handlers

router = APIRouter(prefix="/sessions", tags=["sessions"])

_handlers = None


def _get_handlers():
    global _handlers
    if _handlers is None:
        _handlers = create_session_handlers()
    return _handlers


class _MockConn:
    def __init__(self):
        self.result = None
        self.error = None

    async def send_ok(self, method: str, payload: dict):
        self.result = payload

    async def send_error(self, method: str, code: str, message: str, **kwargs):
        self.error = {"code": code, "message": message}


@router.get("", response_model=SessionListResponse)
async def list_sessions():
    conn = _MockConn()
    await _get_handlers()["sessions.list"](None, conn)
    if conn.error:
        raise HTTPException(status_code=500, detail=conn.error["message"])
    return SessionListResponse(sessions=conn.result.get("sessions", []))


@router.get("/{session_id:path}/messages", response_model=SessionPreviewResponse)
async def get_session_messages(session_id: str, limit: int = 50):
    conn = _MockConn()
    await _get_handlers()["sessions.preview"]({"path": session_id, "limit": limit}, conn)
    if conn.error:
        raise HTTPException(status_code=404, detail=conn.error["message"])
    return SessionPreviewResponse(messages=conn.result.get("messages", []))


@router.post("", response_model=SessionCreateResponse, status_code=201)
async def create_session(body: SessionCreateRequest):
    conn = _MockConn()
    await _get_handlers()["sessions.create"](body.model_dump(), conn)
    if conn.error:
        raise HTTPException(status_code=500, detail=conn.error["message"])
    return SessionCreateResponse(**conn.result)


@router.delete("/{session_id:path}", status_code=204)
async def delete_session(session_id: str):
    conn = _MockConn()
    await _get_handlers()["sessions.delete"]({"path": session_id}, conn)
    if conn.error:
        raise HTTPException(status_code=404, detail=conn.error["message"])
    return None
```

- [ ] **Step 7: 创建 config.py REST handler**

```python
# backend/src/pyclaw/gateway/rest/config.py
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from .models.config import ConfigResponse, ConfigPatchRequest
from ..methods.config_methods import create_config_handlers

router = APIRouter(prefix="/config", tags=["config"])

_handlers = None


def _get_handlers():
    global _handlers
    if _handlers is None:
        _handlers = create_config_handlers()
    return _handlers


class _MockConn:
    def __init__(self):
        self.result = None
        self.error = None

    async def send_ok(self, method: str, payload: dict):
        self.result = payload

    async def send_error(self, method: str, code: str, message: str, **kwargs):
        self.error = {"code": code, "message": message}


@router.get("", response_model=ConfigResponse)
async def get_config():
    conn = _MockConn()
    await _get_handlers()["config.get"](None, conn)
    if conn.error:
        raise HTTPException(status_code=500, detail=conn.error["message"])
    return ConfigResponse(config=conn.result.get("config", {}))


@router.patch("", response_model=ConfigResponse)
async def patch_config(body: ConfigPatchRequest):
    conn = _MockConn()
    await _get_handlers()["config.patch"]({"patch": body.patch}, conn)
    if conn.error:
        raise HTTPException(status_code=400, detail=conn.error["message"])
    return ConfigResponse(config=conn.result.get("config", {}))
```

- [ ] **Step 8: 创建 channels.py REST handler**

```python
# backend/src/pyclaw/gateway/rest/channels.py
from __future__ import annotations

from fastapi import APIRouter

from ..methods.channels import create_channels_handlers

router = APIRouter(prefix="/channels", tags=["channels"])

_handlers = None


def _get_handlers():
    global _handlers
    if _handlers is None:
        _handlers = create_channels_handlers()
    return _handlers


class _MockConn:
    def __init__(self):
        self.result = None
        self.error = None

    async def send_ok(self, method: str, payload: dict):
        self.result = payload

    async def send_error(self, method: str, code: str, message: str, **kwargs):
        self.error = {"code": code, "message": message}


@router.get("")
async def list_channels():
    conn = _MockConn()
    await _get_handlers()["channels.list"](None, conn)
    return conn.result


@router.get("/{channel_id}")
async def get_channel_status(channel_id: str):
    conn = _MockConn()
    await _get_handlers()["channels.status"]({"channel_id": channel_id}, conn)
    if conn.error:
        return {"error": conn.error["message"]}
    return conn.result
```

- [ ] **Step 9: 创建 rest/__init__.py**

```python
# backend/src/pyclaw/gateway/rest/__init__.py
from .router import create_rest_router

__all__ = ["create_rest_router"]
```

- [ ] **Step 10: 创建 rest/router.py**

```python
# backend/src/pyclaw/gateway/rest/router.py
from __future__ import annotations

from fastapi import APIRouter

from .agents import router as agents_router
from .sessions import router as sessions_router
from .config import router as config_router
from .channels import router as channels_router


def create_rest_router() -> APIRouter:
    """Create the main REST API router."""
    router = APIRouter(prefix="/api/v1")
    router.include_router(agents_router)
    router.include_router(sessions_router)
    router.include_router(config_router)
    router.include_router(channels_router)
    return router
```

- [ ] **Step 11: 修改 server.py 挂载 REST router**

在 `GatewayServer.__init__` 中添加：

```python
# backend/src/pyclaw/gateway/server.py
# 在 __init__ 方法的 self._setup_routes() 之前添加：

# REST API router
from pyclaw.gateway.rest import create_rest_router
rest_router = create_rest_router()
self.app.include_router(rest_router)
```

- [ ] **Step 12: 运行后端测试验证**

```bash
cd /mnt/g/chensai/openclaw-py
source .venv/bin/activate
python -c "from pyclaw.gateway.rest import create_rest_router; print('REST router imported successfully')"
pytest tests/gateway/ -v -k "rest" 2>/dev/null || echo "No REST tests yet (expected)"
```

Expected: REST router 导入成功

- [ ] **Step 13: Commit**

```bash
git add backend/src/pyclaw/gateway/rest/ backend/src/pyclaw/gateway/server.py
git commit -m "$(cat <<'EOF'
feat(gateway): add REST API adapter layer

- Create REST endpoints for agents, sessions, config, channels
- Reuse existing WebSocket method handlers via MockConn adapter
- Add Pydantic models for request/response validation
- Mount REST router at /api/v1 prefix

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Phase 2: packages/shared 核心包

### Task 3: 共享类型定义

**Files:**
- Create: `packages/shared/package.json`
- Create: `packages/shared/tsconfig.json`
- Create: `packages/shared/types/index.ts`
- Create: `packages/shared/types/agent.ts`
- Create: `packages/shared/types/session.ts`
- Create: `packages/shared/types/chat.ts`
- Create: `packages/shared/types/config.ts`
- Create: `packages/shared/types/events.ts`

- [ ] **Step 1: 创建 packages/shared/package.json**

```json
{
  "name": "@pyclaw/shared",
  "version": "0.1.0",
  "type": "module",
  "exports": {
    ".": "./src/index.ts",
    "./types": "./src/types/index.ts",
    "./api": "./src/api/index.ts",
    "./store": "./src/store/index.ts",
    "./utils": "./src/utils/index.ts"
  },
  "scripts": {
    "typecheck": "tsc --noEmit",
    "test": "vitest run",
    "test:watch": "vitest"
  },
  "dependencies": {
    "zustand": "^5.0.0",
    "@tanstack/react-query": "^5.60.0",
    "uuid": "^11.0.0"
  },
  "devDependencies": {
    "typescript": "^5.7.0",
    "vitest": "^2.1.0",
    "@types/uuid": "^10.0.0"
  }
}
```

- [ ] **Step 2: 创建 packages/shared/tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "lib": ["ES2022", "DOM"],
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "outDir": "./dist",
    "rootDir": "./src",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "__tests__"]
}
```

- [ ] **Step 3: 创建 packages/shared/types/agent.ts**

```typescript
// packages/shared/types/agent.ts
export interface Agent {
  id: string;
  sessionCount: number;
  config: AgentConfig;
}

export interface AgentConfig {
  name?: string;
  model?: string;
  provider?: string;
  systemPrompt?: string;
  tools?: string[];
  [key: string]: unknown;
}

export interface AgentCreateRequest {
  agentId: string;
  config?: AgentConfig;
}

export interface AgentListResponse {
  agents: Agent[];
}
```

- [ ] **Step 4: 创建 packages/shared/types/session.ts**

```typescript
// packages/shared/types/session.ts
export interface SessionInfo {
  agentId: string;
  file: string;
  path: string;
  size: number;
}

export interface SessionListResponse {
  sessions: SessionInfo[];
}

export interface MessagePreview {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface SessionPreviewResponse {
  messages: MessagePreview[];
}

export interface SessionCreateRequest {
  agentId?: string;
  title?: string;
}

export interface SessionCreateResponse {
  id: string;
  title?: string;
}
```

- [ ] **Step 5: 创建 packages/shared/types/chat.ts**

```typescript
// packages/shared/types/chat.ts
export interface ToolCallInfo {
  id: string;
  name: string;
  status: 'running' | 'completed' | 'error';
  result?: unknown;
  error?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  toolCalls?: ToolCallInfo[];
}

export interface ChatSendParams {
  message: string;
  agentId?: string;
  sessionId?: string;
  provider?: string;
  model?: string;
  apiKey?: string;
  baseUrl?: string;
  systemPrompt?: string;
}
```

- [ ] **Step 6: 创建 packages/shared/types/config.ts**

```typescript
// packages/shared/types/config.ts
export interface PyClawConfig {
  models?: {
    providers?: Record<string, ProviderConfig>;
  };
  agents?: {
    defaults?: AgentDefaults;
  };
  channels?: Record<string, ChannelConfig>;
  security?: SecurityConfig;
  [key: string]: unknown;
}

export interface ProviderConfig {
  apiKey?: string;
  baseUrl?: string;
  models?: string[];
}

export interface AgentDefaults {
  provider?: string;
  model?: string;
}

export interface ChannelConfig {
  enabled?: boolean;
  [key: string]: unknown;
}

export interface SecurityConfig {
  execApproval?: {
    mode?: 'allow' | 'ask' | 'deny';
    allowlist?: string[];
  };
}
```

- [ ] **Step 7: 创建 packages/shared/types/events.ts**

```typescript
// packages/shared/types/events.ts
export type WebSocketEventType =
  | 'chat.delta'
  | 'chat.complete'
  | 'chat.error'
  | 'chat.toolCall'
  | 'chat.toolResult'
  | 'agent.state'
  | 'agent.started'
  | 'agent.stopped'
  | 'presence'
  | 'heartbeat'
  | 'shutdown'
  | 'progress';

export interface WebSocketEvent {
  type: string;
  event?: string;
  payload?: unknown;
  seq?: number;
}

export interface ChatDeltaEvent {
  type: 'chat.delta';
  delta: string;
}

export interface ChatCompleteEvent {
  type: 'chat.complete';
  completed: boolean;
}

export interface ChatErrorEvent {
  type: 'chat.error';
  error: string;
}

export interface ToolCallEvent {
  type: 'chat.toolCall';
  name: string;
  toolCallId: string;
}

export interface ToolResultEvent {
  type: 'chat.toolResult';
  name: string;
  toolCallId: string;
  result?: unknown;
  error?: string;
}
```

- [ ] **Step 8: 创建 packages/shared/types/index.ts**

```typescript
// packages/shared/types/index.ts
export * from './agent';
export * from './session';
export * from './chat';
export * from './config';
export * from './events';
```

- [ ] **Step 9: 创建目录结构**

```bash
mkdir -p packages/shared/src/types
mkdir -p packages/shared/__tests__
```

- [ ] **Step 10: 验证 TypeScript 编译**

```bash
cd packages/shared
pnpm install
pnpm typecheck
```

Expected: 类型编译通过

- [ ] **Step 11: Commit**

```bash
git add packages/shared
git commit -m "$(cat <<'EOF'
feat(shared): add TypeScript type definitions

- Add agent, session, chat, config, events types
- Configure TypeScript and package.json exports
- Align types with Python backend models

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

### Task 4: API 客户端与工具函数

**Files:**
- Create: `packages/shared/src/index.ts`
- Create: `packages/shared/src/utils/env.ts`
- Create: `packages/shared/src/utils/uuid.ts`
- Create: `packages/shared/src/utils/storage.ts`
- Create: `packages/shared/src/api/client.ts`
- Create: `packages/shared/src/api/websocket.ts`
- Create: `packages/shared/src/api/hooks.ts`
- Create: `packages/shared/src/store/index.ts`
- Create: `packages/shared/src/store/chat.ts`
- Create: `packages/shared/src/store/persist.ts`
- Create: `packages/shared/src/i18n/index.ts`
- Create: `packages/shared/__tests__/store/chatStore.test.ts`
- Create: `packages/shared/vitest.config.ts`

- [ ] **Step 1: 创建 src/utils/env.ts**

```typescript
// packages/shared/src/utils/env.ts

export const platform = {
  isTauri: typeof window !== 'undefined' && '__TAURI__' in window,
  isReactNative: typeof navigator !== 'undefined' && navigator.product === 'ReactNative',
  isBrowser: typeof window !== 'undefined' && !('__TAURI__' in window),
  isWeb: typeof window !== 'undefined',
};

export function getApiBaseUrl(): string {
  if (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_API_URL) {
    return process.env.NEXT_PUBLIC_API_URL;
  }

  if (platform.isTauri) {
    return 'http://localhost:8765';
  }

  if (platform.isReactNative) {
    return (typeof process !== 'undefined' && process.env?.EXPO_PUBLIC_API_URL) || 'http://localhost:8765';
  }

  if (typeof process !== 'undefined' && process.env?.NODE_ENV === 'development') {
    return 'http://localhost:8765';
  }

  return '';
}

export function getWebSocketUrl(): string {
  const baseUrl = getApiBaseUrl();
  if (!baseUrl) return 'ws://localhost:8765/ws';
  return baseUrl.replace(/^http/, 'ws') + '/ws';
}
```

- [ ] **Step 2: 创建 src/utils/uuid.ts**

```typescript
// packages/shared/src/utils/uuid.ts
import { v4 as uuidv4 } from 'uuid';

export function generateId(): string {
  return uuidv4().replace(/-/g, '').slice(0, 12);
}

export function generateFullId(): string {
  return uuidv4();
}
```

- [ ] **Step 3: 创建 src/utils/storage.ts**

```typescript
// packages/shared/src/utils/storage.ts
import { platform } from './env';

export interface StorageAdapter {
  getItem: (name: string) => string | null | Promise<string | null>;
  setItem: (name: string, value: string) => void | Promise<void>;
  removeItem: (name: string) => void | Promise<void>;
}

export async function getStorage(): Promise<StorageAdapter> {
  if (platform.isTauri) {
    const { Store } = await import('@tauri-apps/plugin-store');
    const store = await Store.load('pyclaw-state.json');
    return {
      getItem: (name) => store.get(name) as Promise<string | null>,
      setItem: (name, value) => store.set(name, value),
      removeItem: (name) => store.delete(name),
    };
  }

  if (platform.isReactNative) {
    const AsyncStorage = await import('@react-native-async-storage/async-storage');
    return AsyncStorage;
  }

  return {
    getItem: (name: string) => {
      if (typeof localStorage === 'undefined') return null;
      return localStorage.getItem(name);
    },
    setItem: (name: string, value: string) => {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(name, value);
      }
    },
    removeItem: (name: string) => {
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(name);
      }
    },
  };
}
```

- [ ] **Step 4: 创建 src/utils/index.ts**

```typescript
// packages/shared/src/utils/index.ts
export * from './env';
export * from './uuid';
export * from './storage';
```

- [ ] **Step 5: 创建 src/api/client.ts**

```typescript
// packages/shared/src/api/client.ts
import { getApiBaseUrl } from '../utils/env';

interface ApiError {
  message: string;
  code?: string;
}

interface ApiResponse<T> {
  data: T | null;
  error: ApiError | null;
}

class ApiClient {
  private baseUrl: string;

  constructor() {
    this.baseUrl = getApiBaseUrl();
  }

  private async request<T>(
    path: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(`${this.baseUrl}/api/v1${path}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        return {
          data: null,
          error: {
            message: errorData.detail || `HTTP ${response.status}`,
            code: response.status.toString(),
          },
        };
      }

      const data = await response.json();
      return { data, error: null };
    } catch (err) {
      return {
        data: null,
        error: {
          message: err instanceof Error ? err.message : 'Unknown error',
        },
      };
    }
  }

  async get<T>(path: string): Promise<ApiResponse<T>> {
    return this.request<T>(path, { method: 'GET' });
  }

  async post<T>(path: string, body: unknown): Promise<ApiResponse<T>> {
    return this.request<T>(path, {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  async patch<T>(path: string, body: unknown): Promise<ApiResponse<T>> {
    return this.request<T>(path, {
      method: 'PATCH',
      body: JSON.stringify(body),
    });
  }

  async delete<T>(path: string): Promise<ApiResponse<T>> {
    return this.request<T>(path, { method: 'DELETE' });
  }
}

export const apiClient = new ApiClient();

export const agentsApi = {
  list: () => apiClient.get<{ agents: Array<{ id: string; session_count: number; config: Record<string, unknown> }> }>('/agents'),
  get: (id: string) => apiClient.get<{ id: string; session_count: number; config: Record<string, unknown> }>(`/agents/${id}`),
  create: (agentId: string, config?: Record<string, unknown>) =>
    apiClient.post<{ id: string; session_count: number; config: Record<string, unknown> }>('/agents', { agent_id: agentId, config }),
  delete: (id: string) => apiClient.delete<void>(`/agents/${id}`),
};

export const sessionsApi = {
  list: () => apiClient.get<{ sessions: Array<{ agentId: string; file: string; path: string; size: number }> }>('/sessions'),
  preview: (path: string, limit = 50) =>
    apiClient.get<{ messages: Array<{ role: string; content: string }> }>(`/sessions/${encodeURIComponent(path)}/messages?limit=${limit}`),
  create: (agentId = 'main', title?: string) =>
    apiClient.post<{ id: string; title?: string }>('/sessions', { agentId, title }),
  delete: (path: string) => apiClient.delete<void>(`/sessions/${encodeURIComponent(path)}`),
};

export const configApi = {
  get: () => apiClient.get<{ config: Record<string, unknown> }>('/config'),
  patch: (patch: Record<string, unknown>) =>
    apiClient.patch<{ config: Record<string, unknown> }>('/config', { patch }),
};
```

- [ ] **Step 6: 创建 src/api/websocket.ts**

```typescript
// packages/shared/src/api/websocket.ts
import { useCallback, useEffect, useRef, useState } from 'react';
import { getWebSocketUrl } from '../utils/env';
import { generateId } from '../utils/uuid';

interface PendingCall {
  resolve: (value: unknown) => void;
  reject: (error: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

export interface WebSocketOptions {
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Error) => void;
  onEvent?: (event: string, data: unknown) => void;
  reconnectAttempts?: number;
  reconnectInterval?: number;
  callTimeout?: number;
}

export function useGatewayWebSocket(options: WebSocketOptions = {}) {
  const {
    reconnectAttempts = 5,
    reconnectInterval = 1000,
    callTimeout = 30000,
  } = options;

  const [connected, setConnected] = useState(false);
  const [connectionState, setConnectionState] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectCount = useRef(0);
  const pendingCalls = useRef<Map<string, PendingCall>>(new Map());
  const messageHandlers = useRef<Map<string, (event: MessageEvent) => void>>(new Map());

  const handleMessage = useCallback((event: MessageEvent) => {
    try {
      const msg = JSON.parse(event.data);

      if (msg.id && pendingCalls.current.has(msg.id)) {
        const { resolve, reject, timer } = pendingCalls.current.get(msg.id)!;
        clearTimeout(timer);
        pendingCalls.current.delete(msg.id);
        if (msg.error) {
          reject(new Error(msg.error.message || 'Unknown error'));
        } else {
          resolve(msg.result || msg.payload);
        }
        return;
      }

      if (msg.type === 'event' || msg.event) {
        const eventName = msg.event || msg.type;
        const eventData = msg.payload || msg.data;
        options.onEvent?.(eventName, eventData);
      }

      const handler = messageHandlers.current.get(msg.callId);
      if (handler) {
        handler(event);
      }
    } catch {
      console.warn('[WebSocket] Failed to parse message:', event.data?.slice(0, 100));
    }
  }, [options]);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    setConnectionState('connecting');
    const wsUrl = getWebSocketUrl();
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setConnected(true);
      setConnectionState('connected');
      reconnectCount.current = 0;
      options.onOpen?.();
    };

    ws.onclose = () => {
      setConnected(false);
      setConnectionState('disconnected');
      options.onClose?.();
      if (reconnectCount.current < reconnectAttempts) {
        reconnectCount.current++;
        setTimeout(connect, reconnectInterval * reconnectCount.current);
      }
    };

    ws.onerror = () => {
      options.onError?.(new Error('WebSocket error'));
    };

    ws.onmessage = handleMessage;
  }, [options, reconnectAttempts, reconnectInterval, handleMessage]);

  const disconnect = useCallback(() => {
    reconnectCount.current = reconnectAttempts;
    wsRef.current?.close();
  }, [reconnectAttempts]);

  const call = useCallback(<T,>(method: string, params: Record<string, unknown>): Promise<T> => {
    return new Promise((resolve, reject) => {
      const ws = wsRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        reject(new Error('WebSocket not connected'));
        return;
      }

      const id = generateId();
      const timer = setTimeout(() => {
        pendingCalls.current.delete(id);
        reject(new Error(`RPC call '${method}' timeout after ${callTimeout}ms`));
      }, callTimeout);

      pendingCalls.current.set(id, {
        resolve: resolve as (v: unknown) => void,
        reject,
        timer,
      });

      ws.send(JSON.stringify({ id, method, params }));
    });
  }, [callTimeout]);

  const streamChat = useCallback((
    sessionId: string,
    message: string,
    onDelta: (delta: string) => void,
    onToolStart?: (name: string, toolId: string) => void,
    onToolEnd?: (name: string, result: unknown, error?: string) => void,
  ): Promise<void> => {
    return new Promise((resolve, reject) => {
      const ws = wsRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        reject(new Error('WebSocket not connected'));
        return;
      }

      const callId = generateId();

      const handler = (event: MessageEvent) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.id !== callId && msg.callId !== callId) return;

          const msgType = msg.type || msg.event;
          if (msgType === 'chat.delta' || msgType === 'delta') {
            onDelta(msg.delta || msg.payload?.delta || '');
          } else if (msgType === 'chat.toolCall' || msgType === 'tool_start') {
            onToolStart?.(msg.name || msg.payload?.name, msg.toolCallId || msg.payload?.toolCallId || '');
          } else if (msgType === 'chat.toolResult' || msgType === 'tool_end') {
            onToolEnd?.(
              msg.name || msg.payload?.name || '',
              msg.result || msg.payload?.result,
              msg.error || msg.payload?.error,
            );
          } else if (msgType === 'chat.complete' || msgType === 'done') {
            messageHandlers.current.delete(callId);
            resolve();
          } else if (msgType === 'chat.error' || msgType === 'error') {
            messageHandlers.current.delete(callId);
            reject(new Error(msg.error || msg.payload?.error || 'Unknown error'));
          }
        } catch {
          console.warn('[streamChat] Failed to parse message');
        }
      };

      messageHandlers.current.set(callId, handler);
      ws.send(JSON.stringify({ id: callId, method: 'chat.send', params: { sessionId, message } }));
    });
  }, []);

  useEffect(() => {
    return () => {
      wsRef.current?.close();
      pendingCalls.current.forEach(({ timer }) => clearTimeout(timer));
      pendingCalls.current.clear();
    };
  }, []);

  return {
    connected,
    connectionState,
    connect,
    disconnect,
    call,
    streamChat,
  };
}
```

- [ ] **Step 7: 创建 src/api/hooks.ts**

```typescript
// packages/shared/src/api/hooks.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { agentsApi, sessionsApi, configApi } from './client';

export const queryKeys = {
  agents: {
    all: ['agents'] as const,
    list: () => [...queryKeys.agents.all, 'list'] as const,
    detail: (id: string) => [...queryKeys.agents.all, 'detail', id] as const,
  },
  sessions: {
    all: ['sessions'] as const,
    list: () => [...queryKeys.sessions.all, 'list'] as const,
  },
  config: {
    all: ['config'] as const,
  },
};

export function useAgentsList() {
  return useQuery({
    queryKey: queryKeys.agents.list(),
    queryFn: async () => {
      const { data, error } = await agentsApi.list();
      if (error) throw new Error(error.message);
      return data?.agents ?? [];
    },
    staleTime: 30_000,
  });
}

export function useAgentDetail(id: string) {
  return useQuery({
    queryKey: queryKeys.agents.detail(id),
    queryFn: async () => {
      const { data, error } = await agentsApi.get(id);
      if (error) throw new Error(error.message);
      return data;
    },
    enabled: !!id,
  });
}

export function useCreateAgent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ agentId, config }: { agentId: string; config?: Record<string, unknown> }) =>
      agentsApi.create(agentId, config),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.agents.list() });
    },
  });
}

export function useDeleteAgent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => agentsApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.agents.list() });
    },
  });
}

export function useSessionsList() {
  return useQuery({
    queryKey: queryKeys.sessions.list(),
    queryFn: async () => {
      const { data, error } = await sessionsApi.list();
      if (error) throw new Error(error.message);
      return data?.sessions ?? [];
    },
    staleTime: 10_000,
  });
}

export function useConfig() {
  return useQuery({
    queryKey: queryKeys.config.all,
    queryFn: async () => {
      const { data, error } = await configApi.get();
      if (error) throw new Error(error.message);
      return data?.config ?? {};
    },
    staleTime: 60_000,
  });
}

export function usePatchConfig() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (patch: Record<string, unknown>) => configApi.patch(patch),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.config.all });
    },
  });
}
```

- [ ] **Step 8: 创建 src/api/index.ts**

```typescript
// packages/shared/src/api/index.ts
export * from './client';
export * from './websocket';
export * from './hooks';
```

- [ ] **Step 9: 创建 src/store/index.ts**

```typescript
// packages/shared/src/store/index.ts
import { create } from 'zustand';

interface AppState {
  gatewayConnected: boolean;
  gatewayState: 'connecting' | 'connected' | 'disconnected';
  setGatewayState: (state: 'connecting' | 'connected' | 'disconnected') => void;

  currentSessionId: string | null;
  setCurrentSession: (id: string | null) => void;

  selectedAgentId: string | null;
  setSelectedAgent: (id: string | null) => void;

  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
}

export const useAppStore = create<AppState>()((set) => ({
  gatewayConnected: false,
  gatewayState: 'disconnected',
  setGatewayState: (state) => set({ gatewayState: state, gatewayConnected: state === 'connected' }),

  currentSessionId: null,
  setCurrentSession: (id) => set({ currentSessionId: id }),

  selectedAgentId: null,
  setSelectedAgent: (id) => set({ selectedAgentId: id }),

  sidebarOpen: true,
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));
```

- [ ] **Step 10: 创建 src/store/chat.ts**

```typescript
// packages/shared/src/store/chat.ts
import { create } from 'zustand';
import { generateId } from '../utils/uuid';
import type { ChatMessage, ToolCallInfo } from '../types/chat';

interface ChatState {
  messages: ChatMessage[];
  isStreaming: boolean;
  streamingContent: string;
  streamingToolCalls: ToolCallInfo[];

  addUserMessage: (content: string) => void;
  startAssistantStream: () => void;
  appendDelta: (delta: string) => void;
  addToolCall: (toolCall: ToolCallInfo) => void;
  updateToolCall: (id: string, update: Partial<ToolCallInfo>) => void;
  finishStream: () => void;
  finishStreamWithError: (error: string) => void;
  clearMessages: () => void;
  loadMessages: (messages: ChatMessage[]) => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  isStreaming: false,
  streamingContent: '',
  streamingToolCalls: [],

  addUserMessage: (content) =>
    set((state) => ({
      messages: [
        ...state.messages,
        {
          id: generateId(),
          role: 'user' as const,
          content,
          timestamp: Date.now(),
        },
      ],
    })),

  startAssistantStream: () =>
    set({
      isStreaming: true,
      streamingContent: '',
      streamingToolCalls: [],
    }),

  appendDelta: (delta) =>
    set((state) => ({
      streamingContent: state.streamingContent + delta,
    })),

  addToolCall: (toolCall) =>
    set((state) => ({
      streamingToolCalls: [...state.streamingToolCalls, toolCall],
    })),

  updateToolCall: (id, update) =>
    set((state) => ({
      streamingToolCalls: state.streamingToolCalls.map((tc) =>
        tc.id === id ? { ...tc, ...update } : tc
      ),
    })),

  finishStream: () =>
    set((state) => ({
      isStreaming: false,
      messages: [
        ...state.messages,
        {
          id: generateId(),
          role: 'assistant' as const,
          content: state.streamingContent,
          timestamp: Date.now(),
          toolCalls: state.streamingToolCalls.length > 0 ? state.streamingToolCalls : undefined,
        },
      ],
      streamingContent: '',
      streamingToolCalls: [],
    })),

  finishStreamWithError: (error) =>
    set((state) => ({
      isStreaming: false,
      messages: [
        ...state.messages,
        {
          id: generateId(),
          role: 'assistant' as const,
          content: `Error: ${error}`,
          timestamp: Date.now(),
        },
      ],
      streamingContent: '',
      streamingToolCalls: [],
    })),

  clearMessages: () =>
    set({
      messages: [],
      streamingContent: '',
      streamingToolCalls: [],
    }),

  loadMessages: (messages) => set({ messages }),
}));
```

- [ ] **Step 11: 创建 src/store/persist.ts**

```typescript
// packages/shared/src/store/persist.ts
import { getStorage } from '../utils/storage';
import { useAppStore } from './index';

const PERSIST_KEY = 'pyclaw-app-state';

export async function loadPersistedState(): Promise<void> {
  const storage = await getStorage();
  const saved = await storage.getItem(PERSIST_KEY);
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      useAppStore.setState(parsed);
    } catch {
      console.warn('Failed to parse persisted state');
    }
  }
}

export function setupPersistence(): void {
  useAppStore.subscribe((state) => {
    const partial = { sidebarOpen: state.sidebarOpen };
    getStorage()
      .then((storage) => storage.setItem(PERSIST_KEY, JSON.stringify(partial)))
      .catch(() => {});
  });
}
```

- [ ] **Step 12: 创建 src/i18n/index.ts**

```typescript
// packages/shared/src/i18n/index.ts
type TranslationDict = Record<string, string | TranslationDict>;

const translations: Record<string, TranslationDict> = {
  en: {
    'app.name': 'PyClaw',
    'nav.dashboard': 'Dashboard',
    'nav.agents': 'Agents',
    'nav.sessions': 'Sessions',
    'nav.settings': 'Settings',
    'nav.channels': 'Channels',
    'nav.logs': 'Logs',
    'chat.placeholder': 'Type a message...',
    'chat.send': 'Send',
    'chat.loading': 'Thinking...',
    'agent.select': 'Select an agent',
    'agent.noAgents': 'No agents configured',
    'session.new': 'New Session',
    'session.delete': 'Delete Session',
    'settings.title': 'Settings',
    'settings.theme': 'Theme',
    'settings.language': 'Language',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.delete': 'Delete',
    'common.confirm': 'Confirm',
    'error.connection': 'Connection lost. Reconnecting...',
    'error.unknown': 'An unknown error occurred',
  },
  'zh-CN': {
    'app.name': 'PyClaw',
    'nav.dashboard': '仪表盘',
    'nav.agents': '智能体',
    'nav.sessions': '会话',
    'nav.settings': '设置',
    'nav.channels': '通道',
    'nav.logs': '日志',
    'chat.placeholder': '输入消息...',
    'chat.send': '发送',
    'chat.loading': '思考中...',
    'agent.select': '选择智能体',
    'agent.noAgents': '未配置智能体',
    'session.new': '新建会话',
    'session.delete': '删除会话',
    'settings.title': '设置',
    'settings.theme': '主题',
    'settings.language': '语言',
    'common.save': '保存',
    'common.cancel': '取消',
    'common.delete': '删除',
    'common.confirm': '确认',
    'error.connection': '连接断开，正在重连...',
    'error.unknown': '发生未知错误',
  },
};

let currentLocale = 'en';

export function setLocale(locale: string): void {
  currentLocale = locale;
}

export function getLocale(): string {
  return currentLocale;
}

export function t(key: string, params?: Record<string, string>): string {
  const keys = key.split('.');
  let value: string | TranslationDict | undefined = translations[currentLocale];

  for (const k of keys) {
    if (value && typeof value === 'object') {
      value = value[k] as TranslationDict;
    } else {
      value = undefined;
      break;
    }
  }

  if (value === undefined && currentLocale !== 'en') {
    value = getTranslationRecursive(translations['en'], keys);
  }

  if (typeof value !== 'string') {
    return key;
  }

  if (params) {
    return value.replace(/\{(\w+)\}/g, (_, name) => params[name] ?? `{${name}}`);
  }

  return value;
}

function getTranslationRecursive(dict: TranslationDict, keys: string[]): string | undefined {
  let current: TranslationDict | string | undefined = dict;
  for (const k of keys) {
    if (current && typeof current === 'object') {
      current = current[k];
    } else {
      return undefined;
    }
  }
  return typeof current === 'string' ? current : undefined;
}

export function getAvailableLocales(): string[] {
  return Object.keys(translations);
}
```

- [ ] **Step 13: 创建 src/index.ts**

```typescript
// packages/shared/src/index.ts
export * from './types/index';
export * from './api/index';
export * from './store/index';
export * from './utils/index';
export { useChatStore } from './store/chat';
export { loadPersistedState, setupPersistence } from './store/persist';
export { t, setLocale, getLocale, getAvailableLocales } from './i18n';
```

- [ ] **Step 14: 创建测试 vitest.config.ts**

```typescript
// packages/shared/vitest.config.ts
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    include: ['__tests__/**/*.test.ts'],
  },
});
```

- [ ] **Step 15: 创建测试 __tests__/store/chatStore.test.ts**

```typescript
// packages/shared/__tests__/store/chatStore.test.ts
import { describe, it, expect, beforeEach } from 'vitest';
import { useChatStore } from '../../src/store/chat';

describe('ChatStore', () => {
  beforeEach(() => {
    useChatStore.setState({
      messages: [],
      isStreaming: false,
      streamingContent: '',
      streamingToolCalls: [],
    });
  });

  it('should add user message', () => {
    useChatStore.getState().addUserMessage('Hello');
    const messages = useChatStore.getState().messages;
    expect(messages).toHaveLength(1);
    expect(messages[0].role).toBe('user');
    expect(messages[0].content).toBe('Hello');
  });

  it('should handle streaming', () => {
    const store = useChatStore.getState();
    store.startAssistantStream();
    expect(useChatStore.getState().isStreaming).toBe(true);

    store.appendDelta('Hi');
    expect(useChatStore.getState().streamingContent).toBe('Hi');

    store.appendDelta(' there');
    expect(useChatStore.getState().streamingContent).toBe('Hi there');

    store.finishStream();
    expect(useChatStore.getState().isStreaming).toBe(false);
    expect(useChatStore.getState().messages).toHaveLength(1);
    expect(useChatStore.getState().messages[0].content).toBe('Hi there');
  });

  it('should handle tool calls during streaming', () => {
    const store = useChatStore.getState();
    store.startAssistantStream();
    store.addToolCall({ id: 'tc1', name: 'read_file', status: 'running' });
    store.updateToolCall('tc1', { status: 'completed', result: 'file content' });
    store.finishStream();

    const lastMessage = useChatStore.getState().messages[0];
    expect(lastMessage.toolCalls).toHaveLength(1);
    expect(lastMessage.toolCalls?.[0].status).toBe('completed');
  });

  it('should handle stream errors', () => {
    const store = useChatStore.getState();
    store.startAssistantStream();
    store.appendDelta('Partial');
    store.finishStreamWithError('API error');

    const messages = useChatStore.getState().messages;
    expect(messages).toHaveLength(1);
    expect(messages[0].content).toBe('Error: API error');
  });

  it('should clear messages', () => {
    const store = useChatStore.getState();
    store.addUserMessage('Test 1');
    store.addUserMessage('Test 2');
    store.clearMessages();
    expect(useChatStore.getState().messages).toHaveLength(0);
  });
});
```

- [ ] **Step 16: 运行测试**

```bash
cd packages/shared
pnpm install
pnpm test
```

Expected: 所有 6 个测试通过

- [ ] **Step 17: Commit**

```bash
git add packages/shared
git commit -m "$(cat <<'EOF'
feat(shared): implement API client, stores, and utilities

- Add REST API client with typed methods
- Implement WebSocket hook with streaming support
- Create Zustand stores (AppStore, ChatStore)
- Add cross-platform storage adapter
- Implement i18n with en/zh-CN locales
- Add unit tests for ChatStore

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Phase 3: packages/ui 基础组件

### Task 5: UI 组件库基础

**Files:**
- Create: `packages/ui/package.json`
- Create: `packages/ui/tsconfig.json`
- Create: `packages/ui/tailwind.config.ts`
- Create: `packages/ui/postcss.config.js`
- Create: `packages/ui/tailwind-preset.ts`
- Create: `packages/ui/src/index.ts`
- Create: `packages/ui/src/lib/utils.ts`
- Create: `packages/ui/src/components/ui/button.tsx`
- Create: `packages/ui/src/components/ui/card.tsx`
- Create: `packages/ui/src/components/ui/input.tsx`
- Create: `packages/ui/src/components/ui/dialog.tsx`
- Create: `packages/ui/src/composite/page-header.tsx`
- Create: `packages/ui/src/composite/empty-state.tsx`
- Create: `packages/ui/src/composite/status-chip.tsx`
- Create: `packages/ui/src/composite/streaming-text.tsx`
- Create: `packages/ui/src/chat/message-bubble.tsx`
- Create: `packages/ui/src/chat/chat-input.tsx`
- Create: `packages/ui/src/chat/tool-call-card.tsx`

- [ ] **Step 1: 创建 packages/ui/package.json**

```json
{
  "name": "@pyclaw/ui",
  "version": "0.1.0",
  "type": "module",
  "exports": {
    ".": "./src/index.ts",
    "./components/*": "./src/components/*",
    "./composite/*": "./src/composite/*",
    "./chat/*": "./src/chat/*"
  },
  "scripts": {
    "typecheck": "tsc --noEmit",
    "test": "vitest run"
  },
  "dependencies": {
    "@pyclaw/shared": "workspace:*",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.1.0",
    "tailwind-merge": "^2.5.0",
    "lucide-react": "^0.460.0",
    "react-markdown": "^9.0.0",
    "remark-gfm": "^4.0.0",
    "sonner": "^1.5.0"
  },
  "peerDependencies": {
    "react": "^18.0.0 || ^19.0.0",
    "react-dom": "^18.0.0 || ^19.0.0"
  },
  "devDependencies": {
    "@types/react": "^18.3.0",
    "@types/react-dom": "^18.3.0",
    "autoprefixer": "^10.4.0",
    "postcss": "^8.4.0",
    "tailwindcss": "^3.4.0",
    "typescript": "^5.7.0",
    "vitest": "^2.1.0"
  }
}
```

- [ ] **Step 2: 创建 packages/ui/tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "jsx": "react-jsx",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "outDir": "./dist",
    "rootDir": "./src",
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "__tests__"]
}
```

- [ ] **Step 3: 创建 packages/ui/tailwind.config.ts**

```typescript
// packages/ui/tailwind.config.ts
import type { Config } from 'tailwindcss';
import preset from './tailwind-preset';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  presets: [preset],
};

export default config;
```

- [ ] **Step 4: 创建 packages/ui/postcss.config.js**

```javascript
// packages/ui/postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
```

- [ ] **Step 5: 创建 packages/ui/tailwind-preset.ts**

```typescript
// packages/ui/tailwind-preset.ts
import type { Config } from 'tailwindcss';

const preset: Config = {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
    },
  },
};

export default preset;
```

- [ ] **Step 6: 创建 packages/ui/src/lib/utils.ts**

```typescript
// packages/ui/src/lib/utils.ts
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

- [ ] **Step 7: 创建 packages/ui/src/components/ui/button.tsx**

```tsx
// packages/ui/src/components/ui/button.tsx
import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../../lib/utils';

const buttonVariants = cva(
  'inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50',
  {
    variants: {
      variant: {
        default: 'bg-primary text-primary-foreground shadow hover:bg-primary/90',
        destructive: 'bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90',
        outline: 'border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground',
        secondary: 'bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80',
        ghost: 'hover:bg-accent hover:text-accent-foreground',
        link: 'text-primary underline-offset-4 hover:underline',
      },
      size: {
        default: 'h-9 px-4 py-2',
        sm: 'h-8 rounded-md px-3 text-xs',
        lg: 'h-10 rounded-md px-8',
        icon: 'h-9 w-9',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, ...props }, ref) => {
    return (
      <button
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = 'Button';

export { Button, buttonVariants };
```

- [ ] **Step 8: 创建 packages/ui/src/components/ui/card.tsx**

```tsx
// packages/ui/src/components/ui/card.tsx
import * as React from 'react';
import { cn } from '../../lib/utils';

const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        'rounded-xl border bg-card text-card-foreground shadow',
        className
      )}
      {...props}
    />
  )
);
Card.displayName = 'Card';

const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn('flex flex-col space-y-1.5 p-6', className)} {...props} />
  )
);
CardHeader.displayName = 'CardHeader';

const CardTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3 ref={ref} className={cn('font-semibold leading-none tracking-tight', className)} {...props} />
  )
);
CardTitle.displayName = 'CardTitle';

const CardDescription = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, ...props }, ref) => (
    <p ref={ref} className={cn('text-sm text-muted-foreground', className)} {...props} />
  )
);
CardDescription.displayName = 'CardDescription';

const CardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn('p-6 pt-0', className)} {...props} />
  )
);
CardContent.displayName = 'CardContent';

const CardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn('flex items-center p-6 pt-0', className)} {...props} />
  )
);
CardFooter.displayName = 'CardFooter';

export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent };
```

- [ ] **Step 9: 创建 packages/ui/src/components/ui/input.tsx**

```tsx
// packages/ui/src/components/ui/input.tsx
import * as React from 'react';
import { cn } from '../../lib/utils';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          'flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50',
          className
        )}
        ref={ref}
        {...props}
      />
    );
  }
);
Input.displayName = 'Input';

export { Input };
```

- [ ] **Step 10: 创建 packages/ui/src/composite/page-header.tsx**

```tsx
// packages/ui/src/composite/page-header.tsx
import * as React from 'react';
import { cn } from '../lib/utils';

interface PageHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}

export function PageHeader({ title, description, actions, className, ...props }: PageHeaderProps) {
  return (
    <div className={cn('flex items-center justify-between border-b px-6 py-4', className)} {...props}>
      <div className="space-y-1">
        <h1 className="text-lg font-semibold">{title}</h1>
        {description && <p className="text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}
```

- [ ] **Step 11: 创建 packages/ui/src/composite/empty-state.tsx**

```tsx
// packages/ui/src/composite/empty-state.tsx
import { cn } from '../lib/utils';

interface EmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}

export function EmptyState({ title, description, icon, action, className, ...props }: EmptyStateProps) {
  return (
    <div className={cn('flex flex-col items-center justify-center py-12 text-center', className)} {...props}>
      {icon && <div className="mb-4 text-muted-foreground">{icon}</div>}
      <h3 className="text-lg font-medium">{title}</h3>
      {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
```

- [ ] **Step 12: 创建 packages/ui/src/composite/status-chip.tsx**

```tsx
// packages/ui/src/composite/status-chip.tsx
import { cn } from '../lib/utils';

type StatusVariant = 'success' | 'warning' | 'error' | 'info' | 'default';

interface StatusChipProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: StatusVariant;
}

const variantStyles: Record<StatusVariant, string> = {
  success: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  warning: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
  error: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
  info: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  default: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200',
};

export function StatusChip({ variant = 'default', className, children, ...props }: StatusChipProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
        variantStyles[variant],
        className
      )}
      {...props}
    >
      {children}
    </span>
  );
}
```

- [ ] **Step 13: 创建 packages/ui/src/composite/streaming-text.tsx**

```tsx
// packages/ui/src/composite/streaming-text.tsx
import { cn } from '../lib/utils';

interface StreamingTextProps extends React.HTMLAttributes<HTMLSpanElement> {
  text: string;
  isStreaming?: boolean;
}

export function StreamingText({ text, isStreaming, className, ...props }: StreamingTextProps) {
  return (
    <span className={cn('whitespace-pre-wrap', className)} {...props}>
      {text}
      {isStreaming && (
        <span className="ml-0.5 inline-block h-4 w-1 animate-pulse bg-foreground" />
      )}
    </span>
  );
}
```

- [ ] **Step 14: 创建 packages/ui/src/chat/message-bubble.tsx**

```tsx
// packages/ui/src/chat/message-bubble.tsx
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { cn } from '../lib/utils';
import type { ChatMessage } from '@pyclaw/shared/types';

interface MessageBubbleProps {
  message: ChatMessage;
  isStreaming?: boolean;
  streamingContent?: string;
}

export function MessageBubble({ message, isStreaming, streamingContent }: MessageBubbleProps) {
  const isUser = message.role === 'user';
  const content = isStreaming ? streamingContent : message.content;

  return (
    <div className={cn('flex', isUser ? 'justify-end' : 'justify-start')}>
      <div
        className={cn(
          'max-w-[80%] rounded-lg px-4 py-2',
          isUser
            ? 'bg-primary text-primary-foreground'
            : 'bg-muted text-muted-foreground'
        )}
      >
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {content || ''}
          </ReactMarkdown>
          {isStreaming && (
            <span className="ml-0.5 inline-block h-4 w-1 animate-pulse bg-current" />
          )}
        </div>
      </div>
    </div>
  );
}
```

- [ ] **Step 15: 创建 packages/ui/src/chat/chat-input.tsx**

```tsx
// packages/ui/src/chat/chat-input.tsx
import { useState, useRef, useEffect } from 'react';
import { Send } from 'lucide-react';
import { Button } from '../components/ui/button';
import { cn } from '../lib/utils';

interface ChatInputProps {
  onSubmit: (message: string) => void;
  disabled?: boolean;
  placeholder?: string;
  className?: string;
}

export function ChatInput({ onSubmit, disabled, placeholder = 'Type a message...', className }: ChatInputProps) {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [input]);

  const handleSubmit = () => {
    const trimmed = input.trim();
    if (!trimmed || disabled) return;
    onSubmit(trimmed);
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className={cn('flex items-end gap-2 rounded-lg border bg-background p-2', className)}>
      <textarea
        ref={textareaRef}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        disabled={disabled}
        rows={1}
        className="flex-1 resize-none bg-transparent px-2 py-1.5 text-sm outline-none placeholder:text-muted-foreground disabled:opacity-50"
      />
      <Button size="icon" onClick={handleSubmit} disabled={disabled || !input.trim()}>
        <Send className="h-4 w-4" />
      </Button>
    </div>
  );
}
```

- [ ] **Step 16: 创建 packages/ui/src/chat/tool-call-card.tsx**

```tsx
// packages/ui/src/chat/tool-call-card.tsx
import { Loader2, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/card';
import { StatusChip } from '../composite/status-chip';
import { cn } from '../lib/utils';
import type { ToolCallInfo } from '@pyclaw/shared/types';

interface ToolCallCardProps {
  toolCall: ToolCallInfo;
  isExpanded?: boolean;
}

export function ToolCallCard({ toolCall, isExpanded = false }: ToolCallCardProps) {
  const statusIcon = {
    running: <Loader2 className="h-4 w-4 animate-spin text-blue-500" />,
    completed: <CheckCircle className="h-4 w-4 text-green-500" />,
    error: <XCircle className="h-4 w-4 text-red-500" />,
  };

  return (
    <Card className={cn('my-2', isExpanded && 'border-l-4 border-l-primary')}>
      <CardHeader className="py-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          {statusIcon[toolCall.status]}
          <code className="rounded bg-muted px-1.5 py-0.5">{toolCall.name}</code>
          <StatusChip variant={toolCall.status === 'completed' ? 'success' : toolCall.status === 'error' ? 'error' : 'info'}>
            {toolCall.status}
          </StatusChip>
        </CardTitle>
      </CardHeader>
      {(toolCall.result !== undefined || toolCall.error) && isExpanded && (
        <CardContent className="py-2">
          {toolCall.error ? (
            <pre className="overflow-auto rounded bg-destructive/10 p-2 text-xs text-destructive">
              {toolCall.error}
            </pre>
          ) : (
            <pre className="overflow-auto rounded bg-muted p-2 text-xs">
              {typeof toolCall.result === 'string' ? toolCall.result : JSON.stringify(toolCall.result, null, 2)}
            </pre>
          )}
        </CardContent>
      )}
    </Card>
  );
}
```

- [ ] **Step 17: 创建 packages/ui/src/index.ts**

```typescript
// packages/ui/src/index.ts
// UI Components
export * from './components/ui/button';
export * from './components/ui/card';
export * from './components/ui/input';

// Composite Components
export * from './composite/page-header';
export * from './composite/empty-state';
export * from './composite/status-chip';
export * from './composite/streaming-text';

// Chat Components
export * from './chat/message-bubble';
export * from './chat/chat-input';
export * from './chat/tool-call-card';

// Utils
export { cn } from './lib/utils';

// Tailwind
export { default as tailwindPreset } from '../tailwind-preset';
```

- [ ] **Step 18: 创建目录结构**

```bash
mkdir -p packages/ui/src/{components/ui,composite,chat,lib}
```

- [ ] **Step 19: 验证 TypeScript 编译**

```bash
cd packages/ui
pnpm install
pnpm typecheck
```

Expected: 类型编译通过

- [ ] **Step 20: Commit**

```bash
git add packages/ui
git commit -m "$(cat <<'EOF'
feat(ui): add base UI component library

- Create shadcn-style Button, Card, Input components
- Add composite components (PageHeader, EmptyState, StatusChip)
- Implement chat components (MessageBubble, ChatInput, ToolCallCard)
- Configure Tailwind preset with theme tokens
- Add cn utility for class merging

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Phase 4: Next.js Web 应用

### Task 6: Next.js 应用框架

**Files:**
- Create: `apps/web/package.json`
- Create: `apps/web/tsconfig.json`
- Create: `apps/web/next.config.ts`
- Create: `apps/web/tailwind.config.ts`
- Create: `apps/web/postcss.config.js`
- Create: `apps/web/app/layout.tsx`
- Create: `apps/web/app/globals.css`
- Create: `apps/web/app/page.tsx`
- Create: `apps/web/app/chat/page.tsx`
- Create: `apps/web/app/agents/page.tsx`
- Create: `apps/web/app/agents/[id]/page.tsx`
- Create: `apps/web/app/sessions/page.tsx`
- Create: `apps/web/app/settings/page.tsx`
- Create: `apps/web/components/shell.tsx`
- Create: `apps/web/components/sidebar.tsx`
- Create: `apps/web/providers.tsx`

- [ ] **Step 1: 创建 apps/web/package.json**

```json
{
  "name": "@pyclaw/web",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "typecheck": "tsc --noEmit"
  },
  "dependencies": {
    "@pyclaw/shared": "workspace:*",
    "@pyclaw/ui": "workspace:*",
    "next": "^15.0.0",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "next-themes": "^0.4.0",
    "@tanstack/react-query": "^5.60.0"
  },
  "devDependencies": {
    "@types/react": "^19.0.0",
    "@types/react-dom": "^19.0.0",
    "typescript": "^5.7.0",
    "tailwindcss": "^3.4.0",
    "autoprefixer": "^10.4.0",
    "postcss": "^8.4.0",
    "eslint": "^9.0.0",
    "eslint-config-next": "^15.0.0"
  }
}
```

- [ ] **Step 2: 创建 apps/web/tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["dom", "dom.iterable", "ES2022"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [{ "name": "next" }],
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```

- [ ] **Step 3: 创建 apps/web/next.config.ts**

```typescript
// apps/web/next.config.ts
import type { NextConfig } from 'next';

const config: NextConfig = {
  output: 'export',
  trailingSlash: true,
  images: {
    unoptimized: true,
  },
  transpilePackages: ['@pyclaw/shared', '@pyclaw/ui'],
};

export default config;
```

- [ ] **Step 4: 创建 apps/web/tailwind.config.ts**

```typescript
// apps/web/tailwind.config.ts
import type { Config } from 'tailwindcss';
import tailwindPreset from '@pyclaw/ui/tailwind-preset';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
    '../../packages/ui/src/**/*.{js,ts,jsx,tsx}',
  ],
  presets: [tailwindPreset],
};

export default config;
```

- [ ] **Step 5: 创建 apps/web/postcss.config.js**

```javascript
// apps/web/postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
```

- [ ] **Step 6: 创建 apps/web/app/globals.css**

```css
/* apps/web/app/globals.css */
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 222.2 84% 4.9%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 84% 4.9%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 84% 4.9%;
    --primary: 239 84% 67%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96.1%;
    --secondary-foreground: 222.2 47.4% 11.2%;
    --muted: 210 40% 96.1%;
    --muted-foreground: 215.4 16.3% 46.9%;
    --accent: 210 40% 96.1%;
    --accent-foreground: 222.2 47.4% 11.2%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 210 40% 98%;
    --border: 214.3 31.8% 91.4%;
    --input: 214.3 31.8% 91.4%;
    --ring: 239 84% 67%;
    --radius: 0.5rem;
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 239 84% 67%;
    --primary-foreground: 210 40% 98%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 239 84% 67%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}
```

- [ ] **Step 7: 创建 apps/web/providers.tsx**

```tsx
// apps/web/providers.tsx
'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from 'next-themes';
import { useState, useEffect } from 'react';
import { loadPersistedState, setupPersistence } from '@pyclaw/shared';

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        retry: 2,
        refetchOnWindowFocus: false,
        staleTime: 30_000,
      },
    },
  }));

  useEffect(() => {
    loadPersistedState().then(() => setupPersistence());
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        {children}
      </ThemeProvider>
    </QueryClientProvider>
  );
}
```

- [ ] **Step 8: 创建 apps/web/components/sidebar.tsx**

```tsx
// apps/web/components/sidebar.tsx
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@pyclaw/ui';
import { useAppStore } from '@pyclaw/shared';
import {
  LayoutDashboard,
  Bot,
  MessageSquare,
  Settings,
  Radio,
  FileText,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

const navItems = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/chat', icon: MessageSquare, label: 'Chat' },
  { href: '/agents', icon: Bot, label: 'Agents' },
  { href: '/sessions', icon: FileText, label: 'Sessions' },
  { href: '/channels', icon: Radio, label: 'Channels' },
  { href: '/settings', icon: Settings, label: 'Settings' },
];

export function Sidebar() {
  const pathname = usePathname();
  const { sidebarOpen, toggleSidebar } = useAppStore();

  return (
    <aside
      className={cn(
        'flex h-screen flex-col border-r bg-card transition-all duration-300',
        sidebarOpen ? 'w-64' : 'w-16'
      )}
    >
      <div className="flex items-center justify-between border-b p-4">
        {sidebarOpen && <span className="font-semibold">PyClaw</span>}
        <button
          onClick={toggleSidebar}
          className="rounded p-1 hover:bg-accent"
          aria-label={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
        >
          {sidebarOpen ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </button>
      </div>

      <nav className="flex-1 space-y-1 p-2">
        {navItems.map((item) => {
          const isActive = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
              )}
            >
              <item.icon className="h-4 w-4 flex-shrink-0" />
              {sidebarOpen && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
```

- [ ] **Step 9: 创建 apps/web/components/shell.tsx**

```tsx
// apps/web/components/shell.tsx
'use client';

import { Sidebar } from './sidebar';
import { Toaster } from 'sonner';

export function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-auto">{children}</main>
      <Toaster position="bottom-right" richColors />
    </div>
  );
}
```

- [ ] **Step 10: 创建 apps/web/app/layout.tsx**

```tsx
// apps/web/app/layout.tsx
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from '../providers';
import { Shell } from '../components/shell';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'PyClaw',
  description: 'Multi-channel AI Gateway',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <Providers>
          <Shell>{children}</Shell>
        </Providers>
      </body>
    </html>
  );
}
```

- [ ] **Step 11: 创建 apps/web/app/page.tsx**

```tsx
// apps/web/app/page.tsx
import { redirect } from 'next/navigation';

export default function Home() {
  redirect('/dashboard');
}
```

- [ ] **Step 12: 创建 apps/web/app/dashboard/page.tsx**

```tsx
// apps/web/app/dashboard/page.tsx
'use client';

import { PageHeader } from '@pyclaw/ui';
import { useGatewayWebSocket } from '@pyclaw/shared';
import { useEffect } from 'react';
import { StatusChip } from '@pyclaw/ui';

export default function DashboardPage() {
  const { connected, connectionState, connect } = useGatewayWebSocket();

  useEffect(() => {
    connect();
  }, [connect]);

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Dashboard"
        description="PyClaw Gateway Status"
        actions={
          <StatusChip variant={connected ? 'success' : 'error'}>
            {connected ? 'Connected' : 'Disconnected'}
          </StatusChip>
        }
      />
      <div className="flex-1 p-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">Connection</div>
            <div className="text-2xl font-bold capitalize">{connectionState}</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">Active Agents</div>
            <div className="text-2xl font-bold">-</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">Sessions</div>
            <div className="text-2xl font-bold">-</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">Messages Today</div>
            <div className="text-2xl font-bold">-</div>
          </div>
        </div>
      </div>
    </div>
  );
}
```

- [ ] **Step 13: 创建 apps/web/app/chat/page.tsx**

```tsx
// apps/web/app/chat/page.tsx
'use client';

import { useState, useEffect, useRef } from 'react';
import { PageHeader, ChatInput, MessageBubble, ToolCallCard, EmptyState } from '@pyclaw/ui';
import { useChatStore, useGatewayWebSocket } from '@pyclaw/shared';
import { MessageSquare } from 'lucide-react';

export default function ChatPage() {
  const { connect, connected, streamChat } = useGatewayWebSocket();
  const { messages, isStreaming, streamingContent, streamingToolCalls, addUserMessage, startAssistantStream, appendDelta, addToolCall, finishStream, finishStreamWithError, clearMessages } = useChatStore();
  const [sessionId] = useState('default');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    connect();
  }, [connect]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingContent]);

  const handleSubmit = async (message: string) => {
    addUserMessage(message);
    startAssistantStream();

    try {
      await streamChat(
        sessionId,
        message,
        (delta) => appendDelta(delta),
        (name, toolId) => addToolCall({ id: toolId, name, status: 'running' }),
        (name, result, error) => {
          const toolCalls = useChatStore.getState().streamingToolCalls;
          const tc = toolCalls.find(t => t.name === name);
          if (tc) {
            useChatStore.getState().updateToolCall(tc.id, {
              status: error ? 'error' : 'completed',
              result,
              error,
            });
          }
        }
      );
      finishStream();
    } catch (err) {
      finishStreamWithError(err instanceof Error ? err.message : 'Unknown error');
    }
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Chat"
        description="Chat with your AI assistant"
        actions={
          <button
            onClick={clearMessages}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            Clear
          </button>
        }
      />
      <div className="flex-1 overflow-y-auto p-4">
        {messages.length === 0 && !isStreaming ? (
          <EmptyState
            title="No messages yet"
            description="Start a conversation by typing a message below"
            icon={<MessageSquare className="h-12 w-12" />}
          />
        ) : (
          <div className="space-y-4">
            {messages.map((msg) => (
              <MessageBubble key={msg.id} message={msg} />
            ))}
            {isStreaming && (
              <MessageBubble
                message={{ id: 'streaming', role: 'assistant', content: '', timestamp: Date.now() }}
                isStreaming
                streamingContent={streamingContent}
              />
            )}
            {streamingToolCalls.map((tc) => (
              <ToolCallCard key={tc.id} toolCall={tc} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>
      <div className="border-t p-4">
        <ChatInput onSubmit={handleSubmit} disabled={!connected || isStreaming} />
      </div>
    </div>
  );
}
```

- [ ] **Step 14: 创建 apps/web/app/agents/page.tsx**

```tsx
// apps/web/app/agents/page.tsx
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader, Button, EmptyState, StatusChip } from '@pyclaw/ui';
import { useAgentsList, useGatewayWebSocket } from '@pyclaw/shared';
import { Bot, Plus, Loader2 } from 'lucide-react';

export default function AgentsPage() {
  const router = useRouter();
  const { connect, connected } = useGatewayWebSocket();
  const { data: agents, isLoading, error } = useAgentsList();

  useEffect(() => {
    connect();
  }, [connect]);

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Agents"
        description="Manage your AI agents"
        actions={
          <Button size="sm">
            <Plus className="mr-1 h-4 w-4" />
            New Agent
          </Button>
        }
      />
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            title="Error loading agents"
            description={error.message}
            icon={<Bot className="h-12 w-12" />}
          />
        ) : agents && agents.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {agents.map((agent) => (
              <button
                key={agent.id}
                onClick={() => router.push(`/agents/${agent.id}`)}
                className="rounded-lg border bg-card p-4 text-left transition-colors hover:bg-accent"
              >
                <div className="flex items-center justify-between">
                  <div className="font-medium">{agent.id}</div>
                  <StatusChip variant="success">{agent.session_count} sessions</StatusChip>
                </div>
                {agent.config?.name && (
                  <div className="mt-1 text-sm text-muted-foreground">{agent.config.name}</div>
                )}
              </button>
            ))}
          </div>
        ) : (
          <EmptyState
            title="No agents"
            description="Create your first agent to get started"
            icon={<Bot className="h-12 w-12" />}
            action={<Button><Plus className="mr-1 h-4 w-4" />Create Agent</Button>}
          />
        )}
      </div>
    </div>
  );
}
```

- [ ] **Step 15: 创建 apps/web/app/agents/[id]/page.tsx**

```tsx
// apps/web/app/agents/[id]/page.tsx
'use client';

import { use } from 'react';
import { PageHeader, Card, CardHeader, CardTitle, CardContent, StatusChip } from '@pyclaw/ui';
import { useAgentDetail, useGatewayWebSocket } from '@pyclaw/shared';
import { Loader2, Bot } from 'lucide-react';

export default function AgentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { connect } = useGatewayWebSocket();
  const { data: agent, isLoading, error } = useAgentDetail(id);

  // 使用 React 19 的 use() hook 解包 params

  return (
    <div className="flex h-full flex-col">
      <PageHeader title={agent?.id || id} description="Agent details" />
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <Card>
            <CardContent className="py-8">
              <div className="text-center text-muted-foreground">Error: {error.message}</div>
            </CardContent>
          </Card>
        ) : agent ? (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">ID</div>
                    <div className="font-medium">{agent.id}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Sessions</div>
                    <StatusChip variant="success">{agent.session_count}</StatusChip>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="overflow-auto rounded-lg bg-muted p-4 text-xs">
                  {JSON.stringify(agent.config, null, 2)}
                </pre>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Card>
            <CardContent className="py-8">
              <div className="text-center text-muted-foreground">Agent not found</div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
```

- [ ] **Step 16: 创建 apps/web/app/sessions/page.tsx**

```tsx
// apps/web/app/sessions/page.tsx
'use client';

import { PageHeader, EmptyState, Button } from '@pyclaw/ui';
import { useSessionsList, useGatewayWebSocket } from '@pyclaw/shared';
import { FileText, Plus, Loader2 } from 'lucide-react';

export default function SessionsPage() {
  const { connect } = useGatewayWebSocket();
  const { data: sessions, isLoading, error } = useSessionsList();

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Sessions"
        description="Manage conversation sessions"
        actions={<Button size="sm"><Plus className="mr-1 h-4 w-4" />New Session</Button>}
      />
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            title="Error loading sessions"
            description={error.message}
            icon={<FileText className="h-12 w-12" />}
          />
        ) : sessions && sessions.length > 0 ? (
          <div className="space-y-2">
            {sessions.map((session) => (
              <div
                key={session.path}
                className="flex items-center justify-between rounded-lg border bg-card p-4"
              >
                <div>
                  <div className="font-medium">{session.file}</div>
                  <div className="text-sm text-muted-foreground">{session.agentId}</div>
                </div>
                <div className="text-sm text-muted-foreground">{(session.size / 1024).toFixed(1)} KB</div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title="No sessions"
            description="Start a conversation to create sessions"
            icon={<FileText className="h-12 w-12" />}
          />
        )}
      </div>
    </div>
  );
}
```

- [ ] **Step 17: 创建 apps/web/app/settings/page.tsx**

```tsx
// apps/web/app/settings/page.tsx
'use client';

import { PageHeader, Card, CardHeader, CardTitle, CardContent } from '@pyclaw/ui';
import { useConfig, useGatewayWebSocket } from '@pyclaw/shared';

export default function SettingsPage() {
  const { connect } = useGatewayWebSocket();
  const { data: config, isLoading } = useConfig();

  return (
    <div className="flex h-full flex-col">
      <PageHeader title="Settings" description="Configure PyClaw" />
      <div className="flex-1 overflow-auto p-4">
        <Card>
          <CardHeader>
            <CardTitle>Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-muted-foreground">Loading...</div>
            ) : (
              <pre className="overflow-auto rounded-lg bg-muted p-4 text-xs">
                {JSON.stringify(config, null, 2)}
              </pre>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
```

- [ ] **Step 18: 创建 apps/web/app/channels/page.tsx**

```tsx
// apps/web/app/channels/page.tsx
'use client';

import { PageHeader, EmptyState, StatusChip } from '@pyclaw/ui';
import { useGatewayWebSocket } from '@pyclaw/shared';
import { Radio } from 'lucide-react';

export default function ChannelsPage() {
  const { connected, connectionState } = useGatewayWebSocket();

  return (
    <div className="flex h-full flex-col">
      <PageHeader title="Channels" description="Connected message channels" />
      <div className="flex-1 overflow-auto p-4">
        <EmptyState
          title="Channel Status"
          description="Channel management coming soon"
          icon={<Radio className="h-12 w-12" />}
        />
      </div>
    </div>
  );
}
```

- [ ] **Step 19: 创建 apps/web/next-env.d.ts**

```typescript
// apps/web/next-env.d.ts
/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited
// see https://nextjs.org/docs/app/api-reference/config/typescript for more information.
```

- [ ] **Step 20: 创建目录结构并安装依赖**

```bash
mkdir -p apps/web/app/{agents,id} apps/web/components
cd apps/web
pnpm install
```

- [ ] **Step 21: 运行开发服务器验证**

```bash
cd apps/web
pnpm dev
```

Expected: Next.js 开发服务器启动，访问 http://localhost:3000 显示页面

- [ ] **Step 22: Commit**

```bash
git add apps/web
git commit -m "$(cat <<'EOF'
feat(web): implement Next.js application with core pages

- Configure Next.js 15 with static export for Tauri compatibility
- Create layout with sidebar navigation
- Implement Dashboard, Chat, Agents, Sessions, Settings pages
- Add providers for React Query and theme
- Connect to Gateway WebSocket for real-time features

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Phase 5: Tauri Desktop 壳

### Task 7: Tauri 桌面应用

**Files:**
- Create: `apps/desktop/package.json`
- Create: `apps/desktop/src-tauri/Cargo.toml`
- Create: `apps/desktop/src-tauri/tauri.conf.json`
- Create: `apps/desktop/src-tauri/src/main.rs`
- Create: `apps/desktop/src-tauri/src/lib.rs`
- Create: `apps/desktop/src-tauri/build.rs`

- [ ] **Step 1: 创建 apps/desktop/package.json**

```json
{
  "name": "@pyclaw/desktop",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "tauri dev",
    "build": "tauri build"
  },
  "devDependencies": {
    "@tauri-apps/cli": "^2.0.0"
  }
}
```

- [ ] **Step 2: 创建 apps/desktop/src-tauri/Cargo.toml**

```toml
[package]
name = "pyclaw-desktop"
version = "0.1.0"
edition = "2021"
description = "PyClaw Desktop Application"
authors = ["PyClaw Team"]

[build-dependencies]
tauri-build = { version = "2", features = [] }

[dependencies]
tauri = { version = "2", features = ["devtools"] }
tauri-plugin-shell = "2"
tauri-plugin-store = "2"
serde = { version = "1", features = ["derive"] }
serde_json = "1"

[features]
default = ["custom-protocol"]
custom-protocol = ["tauri/custom-protocol"]
```

- [ ] **Step 3: 创建 apps/desktop/src-tauri/tauri.conf.json**

```json
{
  "$schema": "https://schema.tauri.app/config/2",
  "productName": "PyClaw",
  "version": "0.1.0",
  "identifier": "com.pyclaw.desktop",
  "build": {
    "frontendDist": "../web/out",
    "beforeDevCommand": "pnpm --filter @pyclaw/web dev",
    "beforeBuildCommand": "pnpm --filter @pyclaw/web build",
    "devUrl": "http://localhost:3000"
  },
  "app": {
    "withGlobalTauri": true,
    "windows": [
      {
        "title": "PyClaw",
        "width": 1200,
        "height": 800,
        "center": true,
        "resizable": true,
        "fullscreen": false
      }
    ],
    "security": {
      "csp": null
    }
  },
  "bundle": {
    "active": true,
    "targets": "all",
    "icon": [
      "icons/32x32.png",
      "icons/128x128.png",
      "icons/128x128@2x.png",
      "icons/icon.icns",
      "icons/icon.ico"
    ]
  },
  "plugins": {
    "shell": {
      "open": true
    }
  }
}
```

- [ ] **Step 4: 创建 apps/desktop/src-tauri/build.rs**

```rust
fn main() {
    tauri_build::build()
}
```

- [ ] **Step 5: 创建 apps/desktop/src-tauri/src/lib.rs**

```rust
#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_store::Builder::default().build())
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

- [ ] **Step 6: 创建 apps/desktop/src-tauri/src/main.rs**

```rust
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    pyclaw_desktop_lib::run()
}
```

- [ ] **Step 7: 创建图标目录**

```bash
mkdir -p apps/desktop/src-tauri/icons
# 需要后续添加实际图标文件
```

- [ ] **Step 8: Commit**

```bash
git add apps/desktop
git commit -m "$(cat <<'EOF'
feat(desktop): add Tauri 2.x desktop application

- Configure Tauri to reuse Next.js static export
- Add shell and store plugins
- Set up build configuration for multi-platform builds

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Phase 6: Expo Mobile 应用

### Task 8: Expo 移动端初始化

**Files:**
- Create: `apps/mobile/package.json`
- Create: `apps/mobile/app.json`
- Create: `apps/metro.config.js`
- Create: `apps/mobile/app/index.tsx`
- Create: `apps/mobile/app/_layout.tsx`
- Create: `apps/mobile/app/(tabs)/_layout.tsx`
- Create: `apps/mobile/app/(tabs)/index.tsx`
- Create: `apps/mobile/app/(tabs)/chat.tsx`
- Create: `apps/mobile/components/StatusChip.tsx`

- [ ] **Step 1: 创建 apps/mobile/package.json**

```json
{
  "name": "@pyclaw/mobile",
  "version": "0.1.0",
  "private": true,
  "main": "expo-router/entry",
  "scripts": {
    "dev": "expo start",
    "ios": "expo run:ios",
    "android": "expo run:android",
    "web": "expo start --web"
  },
  "dependencies": {
    "@pyclaw/shared": "workspace:*",
    "expo": "~52.0.0",
    "expo-router": "~4.0.0",
    "react": "^18.3.0",
    "react-native": "0.76.0",
    "react-native-safe-area-context": "4.12.0",
    "react-native-screens": "~4.0.0",
    "@react-native-async-storage/async-storage": "^2.0.0"
  },
  "devDependencies": {
    "@types/react": "^18.3.0",
    "typescript": "^5.7.0"
  }
}
```

- [ ] **Step 2: 创建 apps/mobile/app.json**

```json
{
  "expo": {
    "name": "PyClaw",
    "slug": "pyclaw",
    "version": "0.1.0",
    "orientation": "portrait",
    "scheme": "pyclaw",
    "newArchEnabled": true,
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.pyclaw.mobile"
    },
    "android": {
      "package": "com.pyclaw.mobile"
    },
    "web": {
      "output": "static",
      "favicon": "./assets/favicon.png"
    },
    "plugins": [],
    "experiments": {
      "typedRoutes": true
    }
  }
}
```

- [ ] **Step 3: 创建 apps/mobile/metro.config.js（Monorepo 支持）**

```javascript
// apps/mobile/metro.config.js
const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const projectRoot = __dirname;
const workspaceRoot = path.resolve(projectRoot, '../..');

const config = getDefaultConfig(projectRoot);

// Watch the monorepo root
config.watchFolders = [workspaceRoot];

// Resolve modules from both locations
config.resolver.nodeModulesPaths = [
  path.resolve(projectRoot, 'node_modules'),
  path.resolve(workspaceRoot, 'node_modules'),
];

// Handle workspace: protocol
config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (moduleName.startsWith('@pyclaw/')) {
    const pkgName = moduleName.replace('@pyclaw/', '');
    const wsPath = path.resolve(workspaceRoot, 'packages', pkgName);
    context.originModulePath = path.resolve(wsPath, 'src', 'index.ts');
    return context.resolveModule(context, wsPath, platform);
  }
  return context.resolveModule(context, moduleName, platform);
};

module.exports = config;
```

- [ ] **Step 4: 创建 apps/mobile/app/_layout.tsx**

```tsx
// apps/mobile/app/_layout.tsx
import { Stack } from 'expo-router';

export default function RootLayout() {
  return (
    <Stack>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
    </Stack>
  );
}
```

- [ ] **Step 5: 创建 apps/mobile/app/(tabs)/_layout.tsx**

```tsx
// apps/mobile/app/(tabs)/_layout.tsx
import { Tabs } from 'expo-router';

export default function TabsLayout() {
  return (
    <Tabs>
      <Tabs.Screen name="index" options={{ title: 'Dashboard' }} />
      <Tabs.Screen name="chat" options={{ title: 'Chat' }} />
      <Tabs.Screen name="agents" options={{ title: 'Agents' }} />
      <Tabs.Screen name="settings" options={{ title: 'Settings' }} />
    </Tabs>
  );
}
```

- [ ] **Step 6: 创建 apps/mobile/app/(tabs)/index.tsx**

```tsx
// apps/mobile/app/(tabs)/index.tsx
import { View, Text, StyleSheet } from 'react-native';

export default function DashboardScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>PyClaw Dashboard</Text>
      <Text style={styles.subtitle}>Mobile client coming soon</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
});
```

- [ ] **Step 7: 创建 apps/mobile/app/(tabs)/chat.tsx**

```tsx
// apps/mobile/app/(tabs)/chat.tsx
import { View, Text, StyleSheet } from 'react-native';

export default function ChatScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Chat</Text>
      <Text style={styles.subtitle}>Chat functionality coming soon</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
});
```

- [ ] **Step 8: 创建 apps/mobile/app/(tabs)/agents.tsx**

```tsx
// apps/mobile/app/(tabs)/agents.tsx
import { View, Text, StyleSheet } from 'react-native';

export default function AgentsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Agents</Text>
      <Text style={styles.subtitle}>Agent management coming soon</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
});
```

- [ ] **Step 9: 创建 apps/mobile/app/(tabs)/settings.tsx**

```tsx
// apps/mobile/app/(tabs)/settings.tsx
import { View, Text, StyleSheet } from 'react-native';

export default function SettingsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>
      <Text style={styles.subtitle}>Configuration coming soon</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
});
```

- [ ] **Step 10: 创建 apps/mobile/tsconfig.json**

```json
{
  "extends": "expo/tsconfig.base",
  "compilerOptions": {
    "strict": true,
    "paths": {
      "@pyclaw/shared/*": ["../../packages/shared/src/*"]
    }
  },
  "include": ["**/*.ts", "**/*.tsx"]
}
```

- [ ] **Step 11: 创建目录结构**

```bash
mkdir -p apps/mobile/app/tabs apps/mobile/components apps/mobile/assets
```

- [ ] **Step 12: Commit**

```bash
git add apps/mobile
git commit -m "$(cat <<'EOF'
feat(mobile): add Expo React Native application

- Configure Expo Router with tabs navigation
- Set up metro config for monorepo support
- Create basic Dashboard, Chat, Agents, Settings screens
- Configure workspace: protocol resolution

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Phase 7: 测试与 CI/CD

### Task 9: 测试基础设施

**Files:**
- Create: `vitest.config.ts` (根目录)
- Create: `playwright.config.ts`
- Create: `apps/web/vitest.config.ts`
- Create: `apps/web/__tests__/integration/agents.test.tsx`
- Create: `apps/web/e2e/chat.spec.ts`
- Create: `.github/workflows/test.yml`

- [ ] **Step 1: 创建根目录 vitest.config.ts**

```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: ['packages/**/__tests__/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: ['node_modules/**', '__tests__/**'],
    },
  },
});
```

- [ ] **Step 2: 创建 apps/web/vitest.config.ts**

```typescript
// apps/web/vitest.config.ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./__tests__/setup.ts'],
    include: ['__tests__/**/*.test.{ts,tsx}'],
  },
});
```

- [ ] **Step 3: 创建 apps/web/__tests__/setup.ts**

```typescript
// apps/web/__tests__/setup.ts
import '@testing-library/jest-dom/vitest';
```

- [ ] **Step 4: 创建 apps/web/__tests__/integration/agents.test.tsx**

```tsx
// apps/web/__tests__/integration/agents.test.tsx
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';
import AgentsPage from '../../app/agents/page';

const server = setupServer(
  http.get('http://localhost:8765/api/v1/agents', () =>
    HttpResponse.json({
      agents: [
        { id: 'test-agent', session_count: 5, config: { name: 'Test Agent' } },
      ],
    })
  )
);

beforeAll(() => server.listen());
afterAll(() => server.close());

describe('AgentsPage', () => {
  it('renders agent list', async () => {
    const queryClient = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });

    render(
      <QueryClientProvider client={queryClient}>
        <AgentsPage />
      </QueryClientProvider>
    );

    await waitFor(() => {
      expect(screen.getByText('test-agent')).toBeDefined();
    });
  });
});
```

- [ ] **Step 5: 创建 playwright.config.ts**

```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './apps/web/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  webServer: {
    command: 'pnpm --filter @pyclaw/web dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
```

- [ ] **Step 6: 创建 apps/web/e2e/chat.spec.ts**

```typescript
// apps/web/e2e/chat.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Chat Page', () => {
  test('should display chat interface', async ({ page }) => {
    await page.goto('/chat');
    await expect(page.getByRole('heading', { name: 'Chat' })).toBeVisible();
    await expect(page.getByPlaceholder('Type a message...')).toBeVisible();
  });

  test('should show empty state when no messages', async ({ page }) => {
    await page.goto('/chat');
    await expect(page.getByText('No messages yet')).toBeVisible();
  });
});
```

- [ ] **Step 7: 创建 .github/workflows/test.yml**

```yaml
# .github/workflows/test.yml
name: Test

on:
  push:
    branches: [main, master, dev]
  pull_request:
    branches: [main, master]

jobs:
  test-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: pnpm/action-setup@v4
        with:
          version: 9

      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'pnpm'

      - name: Install dependencies
        run: pnpm install

      - name: Run unit tests
        run: pnpm test

      - name: Build packages
        run: pnpm build

      - name: Install Playwright browsers
        run: pnpm exec playwright install --with-deps chromium

      - name: Run E2E tests
        run: pnpm exec playwright test

      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 30

  test-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: '3.10'
          cache: 'pip'

      - name: Install dependencies
        run: |
          python -m venv .venv
          source .venv/bin/activate
          pip install -e ".[dev]"

      - name: Run backend tests
        run: |
          source .venv/bin/activate
          pytest backend/tests/ -v --cov=pyclaw.gateway.rest --cov-report=term-missing
```

- [ ] **Step 8: Commit**

```bash
git add vitest.config.ts playwright.config.ts apps/web/__tests__ apps/web/e2e apps/web/vitest.config.ts .github/workflows/test.yml
git commit -m "$(cat <<'EOF'
test: add testing infrastructure

- Configure Vitest for unit tests
- Set up MSW for API mocking
- Add Playwright E2E tests
- Create CI workflow for frontend and backend tests

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## 验收标准

**Phase 3 完成验收：**
- [ ] 运行 `pnpm --filter @pyclaw/web dev` 启动成功
- [ ] 访问 `/dashboard` 显示连接状态
- [ ] 访问 `/chat` 能发送消息并收到流式响应
- [ ] 访问 `/agents` 显示 agent 列表
- [ ] 访问 `/sessions` 显示 session 列表
- [ ] 单元测试全部通过：`pnpm test`

**Phase 4 完成验收：**
- [ ] 所有 13 个路由页面可访问
- [ ] 主题切换（亮/暗模式）正常
- [ ] 侧边栏展开/收起状态持久化

**Phase 6 完成验收：**
- [ ] Web 端可部署静态产物
- [ ] Tauri 桌面端可构建运行
- [ ] Expo 移动端可在 iOS/Android 模拟器运行

---

## Self-Review Checklist

完成计划后，我进行了以下检查：

1. **Spec 覆盖检查**：
   - ✅ Monorepo 结构 → Task 1
   - ✅ REST 适配层 → Task 2
   - ✅ 类型定义 → Task 3
   - ✅ API 客户端 → Task 4
   - ✅ WebSocket → Task 4
   - ✅ 状态管理 → Task 4
   - ✅ UI 组件 → Task 5
   - ✅ 面板页面 → Task 6
   - ✅ Tauri → Task 7
   - ✅ Expo → Task 8
   - ✅ 测试 → Task 9

2. **Placeholder 扫描**：无 TBD、TODO、TODO comment

3. **类型一致性**：
   - ✅ `ChatMessage`, `ToolCallInfo`, `Agent`, `SessionInfo` 类型在 types/ 中统一定义
   - ✅ API 客户端返回类型与 store 使用一致
   - ✅ WebSocket `streamChat` 参数签名与 ChatStore 方法匹配

---

**Plan complete and saved to `docs/superpowers/plans/2026-04-22-typescript-migration.md`.**

**Two execution options:**

**1. Subagent-Driven (recommended)** - 我逐任务派发独立的子智能体执行，任务间有审查点，快速迭代

**2. Inline Execution** - 在当前会话中使用 executing-plans 逐批执行任务

**请选择执行方式？**
