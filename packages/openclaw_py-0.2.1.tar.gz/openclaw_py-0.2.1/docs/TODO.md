
1. 参考/mnt/g/chensai/examples_claw/hermes-agent 这个本地项目，挖掘在智能体方面的特点。和本项目做各方面的对比。文件夹下面的 website/docs 目录下有相关的文档。你要思考如何借鉴到我们的项目中。


