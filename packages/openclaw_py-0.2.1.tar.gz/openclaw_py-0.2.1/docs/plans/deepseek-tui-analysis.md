# DeepSeek-TUI 功能分析报告

> 分析日期: 2026-05-06
> 分析目标: https://github.com/Hmbown/DeepSeek-TUI
> 对标项目: PyClaw (openclaw-py)

---

## 一、项目概述

### DeepSeek-TUI 定位

DeepSeek-TUI 是一个终端 UI 编码代理，运行 DeepSeek V4 模型，支持：
- 终端 TUI 交互 (ratatui)
- 流式推理块 (Thinking Blocks)
- 本地工作区编辑 + 审批门控
- 自动模式选择模型和思考级别

### 技术栈对比

| 维度 | DeepSeek-TUI | PyClaw |
|------|--------------|--------|
| 语言 | Rust | Python (FastAPI) + TypeScript |
| UI | TUI (ratatui) | Web (Next.js) + Desktop (Tauri) |
| 模型 | DeepSeek V4 | 多模型支持 |
| 协议 | MCP + HTTP/SSE API | MCP + Gateway RPC |
| 存储 | SQLite + JSON | SQLite + LanceDB |

---

## 二、核心可借鉴特性

### 🎯 优先级 P0：强烈推荐借鉴

#### 1. 三模式系统 (Plan / Agent / YOLO)

**DeepSeek-TUI 实现：**
```
Plan 🔍   → 只读探索，规划先行
Agent 🤖  → 交互模式，工具审批
YOLO ⚡   → 自动审批，信任环境
```

**PyClaw 现状：**
- 有 `plan` 模块但未系统化
- 无 YOLO 快速模式
- 审批机制分散在 `execpolicy`

**借鉴建议：**
```python
# src/pyclaw/agents/modes.py
from enum import Enum

class AgentMode(Enum):
    PLAN = "plan"       # 只读探索 + 规划
    AGENT = "agent"     # 交互 + 审批
    YOLO = "yolo"       # 自动审批
    
    def allows_write(self) -> bool:
        return self != AgentMode.PLAN
    
    def requires_approval(self) -> bool:
        return self == AgentMode.AGENT
```

**配置示例：**
```toml
# config.toml
[agent]
default_mode = "agent"
auto_approve_commands = ["git status", "ls", "cat"]
```

---

#### 2. Auto Mode (模型 + 思考级别自动选择)

**DeepSeek-TUI 实现：**
- 每轮请求前，用 `deepseek-v4-flash` 路由
- 根据任务复杂度选择模型和思考深度
- 短任务 → Flash + thinking off
- 编码/调试/架构 → Pro + thinking high/max

**PyClaw 现状：**
- 有 `model_catalog.py` 管理模型
- 无自动路由机制
- 无思考级别控制

**借鉴建议：**
```python
# src/pyclaw/agents/auto_router.py
from dataclasses import dataclass
from enum import Enum

class ThinkingLevel(Enum):
    OFF = "off"
    LOW = "low"
    HIGH = "high"
    MAX = "max"

@dataclass
class RouterDecision:
    model: str
    thinking: ThinkingLevel
    reason: str

async def auto_route(
    prompt: str,
    context_tokens: int,
    task_type: str
) -> RouterDecision:
    """根据任务特征自动选择模型和思考级别"""
    # 简单规则路由
    if len(prompt) < 100 and task_type in ["lookup", "read"]:
        return RouterDecision("flash", ThinkingLevel.OFF, "simple lookup")
    
    if task_type in ["code", "debug", "architecture", "security"]:
        return RouterDecision("pro", ThinkingLevel.HIGH, "complex task")
    
    # 默认
    return RouterDecision("flash", ThinkingLevel.LOW, "default")
```

---

#### 3. User Memory (跨会话持久化记忆)

**DeepSeek-TUI 实现：**
- `~/.deepseek/memory.md` 存储用户偏好
- 系统提示中注入 `<user_memory>` 块
- `# remember that...` 快速添加记忆
- `remember` 工具让模型自动追加

**PyClaw 现状：**
- 有 `memory/` 模块但聚焦对话记忆
- 无跨会话用户偏好持久化
- 无快速记忆注入机制

**借鉴建议：**
```python
# src/pyclaw/memory/user_memory.py
from pathlib import Path
from datetime import datetime

class UserMemory:
    """跨会话用户偏好记忆"""
    
    def __init__(self, path: Path = None):
        self.path = path or Path.home() / ".pyclaw" / "memory.md"
        self.path.parent.mkdir(parents=True, exist_ok=True)
    
    def load(self) -> str:
        if not self.path.exists():
            return ""
        return self.path.read_text()
    
    def append(self, note: str) -> None:
        """追加时间戳记忆条目"""
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
        entry = f"- ({timestamp}) {note}\n"
        with open(self.path, "a") as f:
            f.write(entry)
    
    def inject_to_prompt(self, system_prompt: str) -> str:
        """将记忆注入系统提示"""
        memory = self.load()
        if not memory:
            return system_prompt
        
        return f"""<user_memory source="{self.path}">
{memory}
</user_memory>

{system_prompt}"""

# 快速记忆命令
# CLI: pyclaw memory add "prefer pytest over unittest"
# 或在对话中: # remember that we use 4-space indentation
```

---

#### 4. Sub-Agent 角色分类系统

**DeepSeek-TUI 实现：**
```
general     → 灵活执行
explore     → 只读探索
plan        → 分析规划
review      → 代码审查
implementer → 最小修改实现
verifier    → 测试验证
custom      → 自定义工具列表
```

每个角色有独立的系统提示词，明确职责边界。

**PyClaw 现状：**
- 有子代理概念但无角色分类
- 无明确的职责边界定义
- 输出格式不统一

**借鉴建议：**
```python
# src/pyclaw/agents/roles.py
from enum import Enum
from typing import List, Optional

class AgentRole(Enum):
    GENERAL = "general"           # 灵活执行
    EXPLORE = "explore"           # 只读探索
    PLAN = "plan"                 # 分析规划
    REVIEW = "review"             # 代码审查
    IMPLEMENTER = "implementer"   # 最小修改
    VERIFIER = "verifier"         # 测试验证
    CUSTOM = "custom"             # 自定义
    
    @property
    def allows_write(self) -> bool:
        return self in [AgentRole.GENERAL, AgentRole.IMPLEMENTER]
    
    @property
    def allows_shell(self) -> bool:
        return self not in [AgentRole.REVIEW]
    
    def get_system_prompt(self) -> str:
        prompts = {
            AgentRole.EXPLORE: """你是探索代理，只读遍历代码库。
            
职责：快速定位相关代码，返回结构化发现。
禁止：写入文件、执行有副作用的命令。
输出格式：
- SUMMARY: 一段总结
- EVIDENCE: path:line-range 引用
- RISKS: 潜在风险点""",
            
            AgentRole.REVIEW: """你是审查代理，评估代码质量。
            
职责：审查变更，输出严重性评分。
输出格式：
- SUMMARY: 总体评价
- FINDINGS: [severity] 描述
- RECOMMENDATIONS: 修复建议""",
            # ... 其他角色
        }
        return prompts.get(self, "")

# 统一输出格式
SUBAGENT_OUTPUT_FORMAT = """
SUMMARY:    一段话总结做了什么
CHANGES:    修改的文件列表
EVIDENCE:   path:line-range 引用
RISKS:      可能的风险
BLOCKERS:   阻塞问题，若无则写 "None."
"""
```

---

### 🎯 优先级 P1：推荐借鉴

#### 5. Workspace Snapshots (工作区快照)

**DeepSeek-TUI 实现：**
- 每轮前后自动快照工作区
- 存储在 `~/.deepseek/snapshots/` 
- 使用独立 git 仓库，不影响用户的 `.git`
- `/restore N` 恢复到第 N 轮

**PyClaw 现状：**
- 无快照机制
- 依赖用户手动 git commit

**借鉴建议：**
```python
# src/pyclaw/sessions/snapshots.py
import hashlib
from pathlib import Path
import subprocess

class WorkspaceSnapshot:
    """工作区快照管理"""
    
    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.snapshot_dir = Path.home() / ".pyclaw" / "snapshots"
        self.project_hash = hashlib.md5(str(workspace).encode()).hexdigest()[:8]
    
    def take_snapshot(self, turn_id: str, phase: str) -> str:
        """创建快照
        
        Args:
            turn_id: 会话轮次 ID
            phase: "pre" 或 "post"
        """
        snapshot_path = self.snapshot_dir / self.project_hash / f"{phase}-{turn_id}"
        snapshot_path.mkdir(parents=True, exist_ok=True)
        
        # 使用独立 git 仓库快照
        subprocess.run([
            "git", "--git-dir", str(snapshot_path / ".git"),
            "--work-tree", str(self.workspace),
            "add", "-A"
        ], check=False)
        subprocess.run([
            "git", "--git-dir", str(snapshot_path / ".git"),
            "--work-tree", str(self.workspace),
            "commit", "-m", f"Snapshot {phase}-{turn_id}"
        ], check=False)
        
        return str(snapshot_path)
    
    def restore(self, turn_id: str) -> None:
        """恢复到指定轮次"""
        snapshot_path = self.snapshot_dir / self.project_hash / f"pre-{turn_id}"
        subprocess.run([
            "git", "--git-dir", str(snapshot_path / ".git"),
            "--work-tree", str(self.workspace),
            "checkout", "-f", "HEAD"
        ], check=True)
```

---

#### 6. LSP Diagnostics Hook (编辑后诊断)

**DeepSeek-TUI 实现：**
- 每次文件编辑后自动运行 LSP 诊断
- 将诊断结果注入下一轮上下文
- 支持多种语言服务器

**PyClaw 现状：**
- 无 LSP 集成
- 无编辑后诊断

**借鉴建议：**
```python
# src/pyclaw/tools/lsp_hook.py
from typing import Dict, List, Optional
from dataclasses import dataclass
import subprocess

@dataclass
class Diagnostic:
    file: str
    line: int
    column: int
    severity: str  # "error" | "warning" | "info"
    message: str

class LSPManager:
    """LSP 诊断管理"""
    
    DEFAULT_SERVERS = {
        "python": ["pyright-langserver", "--stdio"],
        "typescript": ["typescript-language-server", "--stdio"],
        "rust": ["rust-analyzer"],
        "go": ["gopls", "serve"],
    }
    
    async def get_diagnostics(
        self, 
        file_path: str,
        language: str
    ) -> List[Diagnostic]:
        """获取文件诊断"""
        # 实现 LSP 通信
        pass
    
    def format_for_context(self, diagnostics: List[Diagnostic]) -> str:
        """格式化为上下文注入"""
        if not diagnostics:
            return ""
        
        lines = ["<lsp_diagnostics>"]
        for d in diagnostics:
            lines.append(f"  [{d.severity}] {d.file}:{d.line}:{d.column}")
            lines.append(f"    {d.message}")
        lines.append("</lsp_diagnostics>")
        
        return "\n".join(lines)

# 编辑后钩子
async def post_edit_lsp_hook(file_path: str, language: str) -> None:
    """编辑后运行 LSP 诊断"""
    manager = LSPManager()
    diagnostics = await manager.get_diagnostics(file_path, language)
    
    if diagnostics:
        # 注入到下一轮上下文
        context = manager.format_for_context(diagnostics)
        # 保存到会话上下文...
```

---

#### 7. Durable Task Queue (持久化任务队列)

**DeepSeek-TUI 实现：**
- 后台任务持久化到 `~/.deepseek/tasks/`
- 支持重启恢复
- 任务状态机：pending → running → completed/failed/canceled

**PyClaw 现状：**
- 有 `daemon/` 模块但无持久化
- 无重启恢复机制

**借鉴建议：**
```python
# src/pyclaw/tasks/queue.py
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional
import json
from pathlib import Path

class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"

@dataclass
class DurableTask:
    id: str
    name: str
    payload: dict
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    
    SCHEMA_VERSION = 1

class DurableTaskQueue:
    """持久化任务队列"""
    
    def __init__(self, storage_dir: Path = None):
        self.storage_dir = storage_dir or Path.home() / ".pyclaw" / "tasks"
        self.storage_dir.mkdir(parents=True, exist_ok=True)
    
    def enqueue(self, task: DurableTask) -> None:
        """入队并持久化"""
        task.status = TaskStatus.PENDING
        self._persist(task)
    
    def _persist(self, task: DurableTask) -> None:
        """持久化任务状态"""
        data = {
            "schema_version": task.SCHEMA_VERSION,
            "id": task.id,
            "name": task.name,
            "payload": task.payload,
            "status": task.status.value,
            "created_at": task.created_at.isoformat(),
            "started_at": task.started_at.isoformat() if task.started_at else None,
            "completed_at": task.completed_at.isoformat() if task.completed_at else None,
            "result": task.result,
            "error": task.error,
        }
        
        path = self.storage_dir / f"{task.id}.json"
        path.write_text(json.dumps(data, indent=2))
    
    def recover(self) -> List[DurableTask]:
        """重启时恢复未完成任务"""
        tasks = []
        for path in self.storage_dir.glob("*.json"):
            data = json.loads(path.read_text())
            if data["status"] in ["pending", "running"]:
                # 标记为中断，等待重新执行
                data["status"] = "interrupted"
                # ... 恢复逻辑
        return tasks
```

---

#### 8. HTTP/SSE Runtime API

**DeepSeek-TUI 实现：**
- `deepseek serve --http` 暴露本地 HTTP/SSE API
- 线程/轮次/事件持久化
- SSE 实时推送事件流

**关键端点：**
```
GET  /v1/threads
POST /v1/threads
GET  /v1/threads/{id}/events?since_seq=<n>
POST /v1/threads/{id}/turns
POST /v1/threads/{id}/turns/{turn_id}/steer
POST /v1/threads/{id}/turns/{turn_id}/interrupt
```

**PyClaw 现状：**
- Gateway 有 RPC 但无 SSE 事件流
- 无线程持久化模型

**借鉴建议：**
```python
# src/pyclaw/gateway/runtime_api.py
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from typing import Optional
import asyncio

router = APIRouter(prefix="/v1")

@router.get("/threads")
async def list_threads(
    limit: int = 50,
    include_archived: bool = False
):
    """列出线程"""
    pass

@router.post("/threads")
async def create_thread():
    """创建线程"""
    pass

@router.get("/threads/{thread_id}/events")
async def stream_events(
    thread_id: str,
    since_seq: int = 0
):
    """SSE 事件流"""
    async def event_generator():
        while True:
            events = await get_events_since(thread_id, since_seq)
            for event in events:
                yield f"data: {event.json()}\n\n"
            await asyncio.sleep(0.1)
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream"
    )

@router.post("/threads/{thread_id}/turns/{turn_id}/steer")
async def steer_turn(thread_id: str, turn_id: str, prompt: str):
    """转向干预"""
    pass

@router.post("/threads/{thread_id}/turns/{turn_id}/interrupt")
async def interrupt_turn(thread_id: str, turn_id: str):
    """中断执行"""
    pass
```

---

### 🎯 优先级 P2：可选借鉴

#### 9. Skills System (技能系统)

**DeepSeek-TUI 实现：**
- 从 `~/.deepseek/skills/` 加载
- `SKILL.md` 定义技能指令
- `/skill install github:owner/repo` 安装社区技能
- 无后端服务，纯本地

**PyClaw 现状：**
- 有 `skills/` 目录但功能不完整
- 无安装机制

**借鉴建议：**
```python
# src/pyclaw/skills/loader.py
from pathlib import Path
from typing import List, Optional
import yaml

@dataclass
class Skill:
    name: str
    description: str
    content: str
    path: Path
    
    @classmethod
    def from_directory(cls, skill_dir: Path) -> Optional[Skill]:
        """从目录加载技能"""
        skill_file = skill_dir / "SKILL.md"
        if not skill_file.exists():
            return None
        
        content = skill_file.read_text()
        
        # 解析 frontmatter
        if content.startswith("---"):
            _, frontmatter, body = content.split("---", 2)
            meta = yaml.safe_load(frontmatter)
        else:
            meta = {}
        
        return cls(
            name=meta.get("name", skill_dir.name),
            description=meta.get("description", ""),
            content=body.strip(),
            path=skill_dir
        )

class SkillManager:
    """技能管理器"""
    
    SEARCH_PATHS = [
        ".agents/skills",
        "skills", 
        ".pyclaw/skills",
        Path.home() / ".pyclaw" / "skills",
    ]
    
    def discover_all(self) -> List[Skill]:
        """发现所有技能"""
        skills = []
        for path in self.SEARCH_PATHS:
            if isinstance(path, str):
                path = Path.cwd() / path
            if path.exists():
                for skill_dir in path.iterdir():
                    if skill_dir.is_dir():
                        skill = Skill.from_directory(skill_dir)
                        if skill:
                            skills.append(skill)
        return skills
    
    async def install(self, spec: str) -> Skill:
        """安装技能
        
        spec 格式: github:owner/repo 或本地路径
        """
        if spec.startswith("github:"):
            _, owner_repo = spec.split(":", 1)
            # 从 GitHub 下载...
            pass
        # ...
```

---

#### 10. Hooks System (生命周期钩子)

**DeepSeek-TUI 实现：**
```toml
[[hooks]]
event = "tool_call_before"
command = "echo 'Running tool: $TOOL_NAME'"

[[hooks]]
event = "shell_env"
command = "aws-vault export my-profile --format=env"
```

支持事件：`session_start`, `session_end`, `tool_call_before`, `tool_call_after`, `mode_change`, `shell_env`

**PyClaw 现状：**
- 有 `hooks/` 模块但功能有限
- 无 `shell_env` 注入机制

**借鉴建议：**
```python
# src/pyclaw/hooks/manager.py
from enum import Enum
from typing import Callable, Dict, List
import subprocess

class HookEvent(Enum):
    SESSION_START = "session_start"
    SESSION_END = "session_end"
    TOOL_CALL_BEFORE = "tool_call_before"
    TOOL_CALL_AFTER = "tool_call_after"
    MODE_CHANGE = "mode_change"
    SHELL_ENV = "shell_env"  # 特殊：注入环境变量

@dataclass
class Hook:
    event: HookEvent
    command: str
    timeout: int = 30
    name: Optional[str] = None

class HookManager:
    """钩子管理器"""
    
    def __init__(self):
        self.hooks: Dict[HookEvent, List[Hook]] = defaultdict(list)
    
    def register(self, hook: Hook) -> None:
        self.hooks[hook.event].append(hook)
    
    async def run(self, event: HookEvent, context: dict = None) -> dict:
        """运行钩子"""
        results = {}
        for hook in self.hooks[event]:
            result = await self._execute_hook(hook, context or {})
            results[hook.name or hook.command] = result
        return results
    
    async def _execute_hook(self, hook: Hook, context: dict) -> dict:
        """执行钩子命令"""
        # 替换环境变量
        env = os.environ.copy()
        env.update({f"TOOL_{k.upper()}": str(v) for k, v in context.items()})
        
        proc = await asyncio.create_subprocess_shell(
            hook.command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env
        )
        
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(),
            timeout=hook.timeout
        )
        
        return {
            "exit_code": proc.returncode,
            "stdout": stdout.decode(),
            "stderr": stderr.decode(),
        }
    
    async def inject_shell_env(self) -> Dict[str, str]:
        """SHELL_ENV 钩子：注入环境变量"""
        env_vars = {}
        for hook in self.hooks[HookEvent.SHELL_ENV]:
            result = await self._execute_hook(hook, {})
            if result["exit_code"] == 0:
                # 解析 KEY=VALUE 格式
                for line in result["stdout"].strip().split("\n"):
                    if "=" in line:
                        key, _, value = line.partition("=")
                        env_vars[key.strip()] = value.strip()
        return env_vars
```

---

## 三、功能对比矩阵

| 功能 | DeepSeek-TUI | PyClaw | 借鉴优先级 |
|------|:------------:|:------:|:----------:|
| 三模式系统 | ✅ | ⚠️ 部分 | P0 |
| Auto Mode | ✅ | ❌ | P0 |
| User Memory | ✅ | ❌ | P0 |
| Sub-Agent 角色 | ✅ | ❌ | P0 |
| 工作区快照 | ✅ | ❌ | P1 |
| LSP 诊断 | ✅ | ❌ | P1 |
| 持久化任务队列 | ✅ | ⚠️ 部分 | P1 |
| Runtime API (SSE) | ✅ | ❌ | P1 |
| Skills 系统 | ✅ | ⚠️ 部分 | P2 |
| Hooks 系统 | ✅ | ⚠️ 部分 | P2 |
| MCP 支持 | ✅ | ✅ | - |
| Web Search | ✅ | ✅ | - |
| 多 Provider | ✅ | ⚠️ 部分 | P1 |
| 国际化 UI | ✅ | ❌ | P2 |
| 桌面通知 | ✅ | ❌ | P2 |

---

## 四、实施路线建议

### Phase 1: 核心增强 (2-3 周)

1. **实现三模式系统**
   - 创建 `AgentMode` 枚举
   - 重构审批逻辑
   - 添加模式切换 API

2. **User Memory 模块**
   - 创建 `UserMemory` 类
   - 实现快速记忆注入
   - 集成到系统提示

3. **Sub-Agent 角色系统**
   - 定义角色枚举和提示词
   - 统一输出格式
   - 重构子代理管理

### Phase 2: 可靠性增强 (2-3 周)

4. **工作区快照**
   - 实现 git 侧车快照
   - 添加恢复命令

5. **持久化任务队列**
   - 实现任务持久化
   - 添加重启恢复

6. **Runtime API (SSE)**
   - 添加 SSE 端点
   - 实现事件流

### Phase 3: 开发体验 (1-2 周)

7. **Auto Mode 路由**
   - 实现简单路由规则
   - 集成思考级别控制

8. **LSP 诊断钩子**
   - 实现 LSP 管理器
   - 集成编辑后诊断

9. **Hooks 增强**
   - 添加 shell_env 支持
   - 重构钩子配置

---

## 五、关键代码参考

### DeepSeek-TUI 关键文件

| 功能 | 文件路径 |
|------|----------|
| 模式定义 | `crates/tui/src/modes.rs` |
| 子代理 | `crates/tui/src/tools/subagent/mod.rs` |
| 用户记忆 | `crates/tui/src/memory.rs` |
| 快照 | `crates/tui/src/snapshots.rs` |
| 任务队列 | `crates/tui/src/task_manager.rs` |
| Runtime API | `crates/app-server/src/runtime_api.rs` |
| LSP | `crates/tui/src/lsp/` |
| 技能 | `crates/tui/src/skills.rs` |
| 钩子 | `crates/hooks/src/lib.rs` |

---

## 六、总结

DeepSeek-TUI 在以下方面提供了优秀的参考实现：

1. **模式系统** - 清晰的职责划分，从规划到执行
2. **记忆系统** - 跨会话持久化用户偏好
3. **子代理架构** - 角色分类 + 统一输出格式
4. **可靠性机制** - 快照 + 持久化队列
5. **开发体验** - LSP 诊断 + Hooks 系统

PyClaw 作为多通道 AI 网关，可以借鉴这些特性来增强 Agent 的可靠性和开发体验，同时保持自己的多通道优势。

建议按优先级分阶段实施，优先完成 P0 级特性以提升核心能力。
