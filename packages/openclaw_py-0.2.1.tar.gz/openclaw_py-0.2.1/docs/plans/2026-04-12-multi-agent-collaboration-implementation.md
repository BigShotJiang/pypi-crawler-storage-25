# 多智能体协作系统实现计划

> **状态:** ✅ 已完成
> **完成日期:** 2026-04-13
> **创建日期:** 2026-04-12

**设计规格:** `docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md`

**目标:** 实现灵活的多智能体协作系统，支持四种协作模式

**架构:** 统一协作层 `CollaborationEngine`，增量扩展现有 `SubagentManager`

**技术栈:** Python 3.10+, asyncio, Pydantic v2, pytest

---

## Milestone 1: 基础框架 (P0-P1)

### Task 1.1: 核心类型定义

**Files:**
- Create: `src/pyclaw/agents/collaboration/__init__.py`
- Create: `src/pyclaw/agents/collaboration/types.py`

- [x] **Step 1: 创建模块目录结构**

```bash
mkdir -p src/pyclaw/agents/collaboration/{modes,context,permission,storage}
```

- [x] **Step 2: 定义枚举类型**

```python
# src/pyclaw/agents/collaboration/types.py
from enum import Enum

class CollaborationModeType(str, Enum):
    """协作模式类型"""
    CUSTOM_AGENT = "custom_agent"
    DYNAMIC_DECOMPOSE = "dynamic_decompose"
    FORK_SWARM = "fork_swarm"
    COORDINATOR_WORKER = "coordinator_worker"

class TrustLevel(int, Enum):
    """信任等级"""
    FULL = 100
    STANDARD = 75
    RESTRICTED = 50
    SANDBOX = 25

class ModeSwitchTrigger(str, Enum):
    """模式切换触发方式"""
    EXPLICIT = "explicit"
    SUGGESTED = "suggested"
    AUTO = "auto"

class MemoryScope(str, Enum):
    """记忆作用域"""
    TASK = "task"
    PROJECT = "project"
```

- [x] **Step 3: 定义配置模型**

```python
from pydantic import BaseModel, Field

SUPPORTED_SCHEMA_VERSIONS = ["1.0"]

class CustomAgentConfig(BaseModel):
    """Custom Agent 配置定义"""
    schema_version: str = Field(default="1.0")
    agent_id: str
    name: str
    description: str = ""
    system_prompt: str | None = None
    model: str | None = None
    tools_enabled: list[str] | None = None
    tools_disabled: list[str] | None = None
    trust_level: TrustLevel = TrustLevel.STANDARD
    memory_scope: MemoryScope = MemoryScope.TASK
    tags: list[str] = Field(default_factory=list)
    source: str = "yaml"
    source_path: str | None = None
```

- [x] **Step 4: 定义结果类型**

```python
class ModeSuggestion(BaseModel):
    mode: CollaborationModeType
    confidence: float = Field(ge=0.0, le=1.0)
    reason: str
    requires_confirmation: bool = True

class SpawnResult(BaseModel):
    session_id: str
    status: str
    children: list[str] = Field(default_factory=list)
    child_context: dict[str, Any] | None = None

class ChildContext(BaseModel):
    session_id: str
    parent_session_id: str
    history_snapshot: list[dict[str, Any]]
    scratchpad_dir: str | None = None
    memory_scope: MemoryScope
    task_prompt: str

class ModeSwitchResult(BaseModel):
    success: bool
    mode: CollaborationModeType | None = None
    message: str = ""
    requires_confirmation: bool = False
```

- [x] **Step 5: 编写单元测试**

```python
# tests/collaboration/test_types.py
def test_trust_level_ordering():
    assert TrustLevel.FULL > TrustLevel.STANDARD
    assert TrustLevel.RESTRICTED < TrustLevel.STANDARD

def test_custom_agent_config_defaults():
    config = CustomAgentConfig(agent_id="test", name="Test")
    assert config.schema_version == "1.0"
    assert config.trust_level == TrustLevel.STANDARD
```

- [x] **Step 6: 运行测试验证**

```bash
pytest tests/collaboration/test_types.py -v
```

---

### Task 1.2: 协作引擎骨架

**Files:**
- Create: `src/pyclaw/agents/collaboration/engine.py`

- [x] **Step 1: 创建引擎类骨架**

```python
# src/pyclaw/agents/collaboration/engine.py
from __future__ import annotations

import asyncio
from typing import Any, TYPE_CHECKING

from pyclaw.agents.collaboration.types import (
    ChildContext,
    CollaborationModeType,
    CollaborationSession,
    CustomAgentConfig,
    ModeSuggestion,
    ModeSwitchResult,
    SpawnResult,
)
from pyclaw.agents.subagents.manager import SubagentManager
from pyclaw.agents.subagents.types import SubagentConfig

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.modes.base import CollaborationMode

class CollaborationEngine:
    """协作引擎 - 统一管理所有协作模式"""
    
    MAX_CHILDREN = 4
    MAX_DEPTH = 5
    
    def __init__(
        self,
        subagent_manager: SubagentManager,
        session_id: str = "",
        mode_selector: Any = None,
        context_manager: Any = None,
        permission_manager: Any = None,
        depth: int = 0,
    ) -> None:
        self._subagent_manager = subagent_manager
        self._session_id = session_id
        self._mode_selector = mode_selector
        self._context_manager = context_manager
        self._permission_manager = permission_manager
        self._depth = depth  # 当前层级深度
        
        self._active_mode: CollaborationModeType | None = None
        self._modes: dict[CollaborationModeType, CollaborationMode] = {}
        self._sessions: dict[str, CollaborationSession] = {}
    
    @property
    def active_mode(self) -> CollaborationModeType | None:
        return self._active_mode
    
    @property
    def session_id(self) -> str:
        return self._session_id
    
    @property
    def depth(self) -> int:
        return self._depth
    
    def register_mode(self, mode_type: CollaborationModeType, mode_impl: CollaborationMode) -> None:
        """注册协作模式实现"""
        self._modes[mode_type] = mode_impl
    
    def switch_mode(
        self,
        mode: CollaborationModeType,
        trigger: str = "explicit",
        context: dict[str, Any] | None = None,
    ) -> ModeSwitchResult:
        """切换协作模式"""
        if mode not in self._modes:
            return ModeSwitchResult(
                success=False,
                message=f"Unknown mode: {mode}",
            )
        
        self._active_mode = mode
        return ModeSwitchResult(
            success=True,
            mode=mode,
            message=f"Switched to {mode.value} mode",
        )
    
    def suggest_mode(self, task_description: str) -> list[ModeSuggestion]:
        """根据任务特征建议合适的模式"""
        if self._mode_selector:
            return self._mode_selector.suggest(task_description)
        return []
    
    async def spawn_child(
        self,
        config: CustomAgentConfig | SubagentConfig,
        mode_type: CollaborationModeType | None = None,
    ) -> SpawnResult:
        """创建子 Agent"""
        if self._depth >= self.MAX_DEPTH:
            return SpawnResult(
                session_id="",
                status="failed",
            )
        
        mode = self._modes.get(mode_type or self._active_mode)
        if not mode:
            raise ValueError(f"Unknown mode: {mode_type or self._active_mode}")
        
        return await mode.spawn(config)
    
    async def kill_child(self, session_id: str) -> bool:
        """终止子 Agent"""
        return await self._subagent_manager.kill(session_id)
    
    async def steer_child(self, session_id: str, instruction: str) -> bool:
        """向子 Agent 发送指令"""
        return await self._subagent_manager.steer(session_id, instruction)
    
    def get_active_children(self) -> list[CollaborationSession]:
        """获取当前活跃的子 Agent"""
        return [s for s in self._sessions.values() if s.status == "active"]
```

- [x] **Step 2: 编写引擎测试**

```python
# tests/collaboration/test_engine.py
import pytest
from unittest.mock import Mock

def test_engine_initialization():
    manager = Mock(spec=SubagentManager)
    engine = CollaborationEngine(subagent_manager=manager)
    assert engine.active_mode is None

def test_switch_mode():
    manager = Mock(spec=SubagentManager)
    engine = CollaborationEngine(subagent_manager=manager)
    engine.register_mode(CollaborationModeType.CUSTOM_AGENT, Mock())
    
    result = engine.switch_mode(CollaborationModeType.CUSTOM_AGENT)
    assert result.success
    assert result.mode == CollaborationModeType.CUSTOM_AGENT
```

- [x] **Step 3: 运行测试验证**

```bash
pytest tests/collaboration/test_engine.py -v
```

---

### Task 1.3: Custom Agent 注册表

**Files:**
- Create: `src/pyclaw/agents/collaboration/storage/__init__.py`
- Create: `src/pyclaw/agents/collaboration/storage/agent_registry.py`

- [x] **Step 1: 实现 Agent 注册表**

```python
# src/pyclaw/agents/collaboration/storage/agent_registry.py
from pathlib import Path
from typing import Any
import yaml

from pyclaw.agents.collaboration.types import (
    CustomAgentConfig,
    TrustLevel,
    SUPPORTED_SCHEMA_VERSIONS,
)
from pyclaw.logging import get_logger

logger = get_logger(__name__)

class IncompatibleSchemaError(Exception):
    """Schema 版本不兼容"""
    pass

class CustomAgentRegistry:
    """Custom Agent 注册表"""
    
    DEFAULT_YAML_DIR = Path.home() / ".pyclaw" / "agents"
    DEFAULT_MD_DIR = Path(".claude/agents")
    
    def __init__(
        self,
        yaml_dirs: list[Path] | None = None,
        markdown_dirs: list[Path] | None = None,
    ) -> None:
        self._yaml_dirs = yaml_dirs or [self.DEFAULT_YAML_DIR]
        self._markdown_dirs = markdown_dirs or [self.DEFAULT_MD_DIR]
        self._agents: dict[str, CustomAgentConfig] = {}
        self._load_errors: list[dict[str, Any]] = []
        self._scan_all_sources()
    
    def _scan_all_sources(self) -> None:
        """扫描所有来源"""
        for yaml_dir in self._yaml_dirs:
            self._scan_yaml_dir(yaml_dir)
        for md_dir in self._markdown_dirs:
            self._scan_markdown_dir(md_dir)
    
    def _scan_yaml_dir(self, directory: Path) -> None:
        """扫描 YAML 配置文件"""
        if not directory.exists():
            return
        for yaml_file in directory.glob("*.yaml"):
            try:
                config = self._load_yaml_agent(yaml_file)
                self._agents[config.agent_id] = config
            except Exception as e:
                self._load_errors.append({
                    "path": str(yaml_file),
                    "error": str(e),
                })
                logger.warning(f"Failed to load agent from {yaml_file}: {e}")
    
    def _load_yaml_agent(self, path: Path) -> CustomAgentConfig:
        """加载 YAML 格式的 Agent 配置"""
        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        
        version = data.get("schema_version", "1.0")
        if version not in SUPPORTED_SCHEMA_VERSIONS:
            raise IncompatibleSchemaError(
                f"Unsupported schema version: {version}. "
                f"Supported: {SUPPORTED_SCHEMA_VERSIONS}"
            )
        
        return CustomAgentConfig(
            schema_version=version,
            agent_id=data.get("agent_id", path.stem),
            name=data.get("name", path.stem),
            description=data.get("description", ""),
            system_prompt=data.get("system_prompt"),
            model=data.get("model"),
            tools_enabled=data.get("tools_enabled"),
            tools_disabled=data.get("tools_disabled"),
            trust_level=TrustLevel(data.get("trust_level", 75)),
            memory_scope=data.get("memory_scope", "task"),
            tags=data.get("tags", []),
            source="yaml",
            source_path=str(path),
        )
    
    def _scan_markdown_dir(self, directory: Path) -> None:
        """扫描 Markdown 目录"""
        # TODO: 实现 Markdown 解析
        pass
    
    def get(self, agent_id: str) -> CustomAgentConfig | None:
        """获取 Agent 配置"""
        return self._agents.get(agent_id)
    
    def list_all(self) -> list[CustomAgentConfig]:
        """列出所有已注册的 Agent"""
        return list(self._agents.values())
    
    def register(self, config: CustomAgentConfig) -> None:
        """注册新 Agent"""
        self._agents[config.agent_id] = config
    
    def unregister(self, agent_id: str) -> bool:
        """注销 Agent"""
        if agent_id in self._agents:
            del self._agents[agent_id]
            return True
        return False
    
    def get_load_errors(self) -> list[dict[str, Any]]:
        """获取加载错误列表"""
        return self._load_errors
```

- [x] **Step 2: 编写注册表测试**

```python
# tests/collaboration/test_registry.py
import pytest
from pathlib import Path
import tempfile
import yaml

def test_registry_loads_yaml():
    with tempfile.TemporaryDirectory() as tmpdir:
        agent_dir = Path(tmpdir) / "agents"
        agent_dir.mkdir()
        
        config_data = {
            "agent_id": "test-agent",
            "name": "Test Agent",
            "description": "A test agent",
            "trust_level": 50,
        }
        
        config_file = agent_dir / "test-agent.yaml"
        with open(config_file, "w") as f:
            yaml.safe_dump(config_data, f)
        
        registry = CustomAgentRegistry(yaml_dirs=[agent_dir])
        
        agent = registry.get("test-agent")
        assert agent is not None
        assert agent.name == "Test Agent"
        assert agent.trust_level == TrustLevel.RESTRICTED

def test_registry_rejects_incompatible_version():
    with tempfile.TemporaryDirectory() as tmpdir:
        agent_dir = Path(tmpdir) / "agents"
        agent_dir.mkdir()
        
        config_data = {
            "agent_id": "bad-agent",
            "schema_version": "99.0",
        }
        
        config_file = agent_dir / "bad-agent.yaml"
        with open(config_file, "w") as f:
            yaml.safe_dump(config_data, f)
        
        registry = CustomAgentRegistry(yaml_dirs=[agent_dir])
        
        # 应该加载失败
        assert registry.get("bad-agent") is None
        assert len(registry.get_load_errors()) == 1
```

- [x] **Step 3: 运行测试验证**

```bash
pytest tests/collaboration/test_registry.py -v
```

---

## Milestone 2: 核心协作流程 (P1-P2)

### Task 2.1: 工具权限管理器

**Files:**
- Create: `src/pyclaw/agents/collaboration/permission/__init__.py`
- Create: `src/pyclaw/agents/collaboration/permission/tool_manager.py`

- [x] **Step 1: 实现权限管理器**

```python
# src/pyclaw/agents/collaboration/permission/tool_manager.py
from __future__ import annotations

import uuid
from collections.abc import Awaitable, Callable
from typing import Any

from pydantic import BaseModel, Field

from pyclaw.agents.collaboration.types import CustomAgentConfig, TrustLevel
from pyclaw.agents.types import AgentTool

class AuthorizationRequest(BaseModel):
    request_id: str
    session_id: str
    tool_name: str
    arguments: dict[str, Any]
    reason: str
    risk_level: str

class AuthorizationResponse(BaseModel):
    request_id: str
    approved: bool
    session_id: str
    message: str | None = None

class ToolPermissionManager:
    """工具权限管理器"""
    
    SENSITIVE_TOOLS = {
        "exec": {"risk": "high", "description": "执行 Shell 命令"},
        "shell": {"risk": "high", "description": "Shell 命令执行"},
        "file_write": {"risk": "medium", "description": "写入文件"},
        "file_delete": {"risk": "high", "description": "删除文件"},
        "patch": {"risk": "medium", "description": "修补文件"},
    }
    
    SAFE_TOOLS = {"read", "search", "web_fetch", "web_search", "list"}
    
    def __init__(
        self,
        trust_level: TrustLevel = TrustLevel.STANDARD,
        authorization_handler: Callable[[AuthorizationRequest], Awaitable[AuthorizationResponse]] | None = None,
    ) -> None:
        self._trust_level = trust_level
        self._authorization_handler = authorization_handler
    
    def filter_tools(
        self,
        tools: list[AgentTool],
        config: CustomAgentConfig,
    ) -> list[AgentTool]:
        """根据配置过滤工具"""
        # 白名单过滤
        if config.tools_enabled:
            tools = [t for t in tools if t.name in config.tools_enabled]
        
        # 黑名单过滤
        if config.tools_disabled:
            tools = [t for t in tools if t.name not in config.tools_disabled]
        
        # 信任等级过滤
        tools = self._apply_trust_level(tools, config.trust_level or self._trust_level)
        
        return tools
    
    def _apply_trust_level(
        self,
        tools: list[AgentTool],
        level: TrustLevel,
    ) -> list[AgentTool]:
        """应用信任等级"""
        if level == TrustLevel.FULL:
            return tools
        
        if level == TrustLevel.SANDBOX:
            return [t for t in tools if t.name in self.SAFE_TOOLS]
        
        if level == TrustLevel.RESTRICTED:
            high_risk = {n for n, i in self.SENSITIVE_TOOLS.items() if i["risk"] == "high"}
            return [t for t in tools if t.name not in high_risk]
        
        return tools
    
    def requires_authorization(self, tool_name: str) -> bool:
        """检查工具是否需要授权"""
        if self._trust_level == TrustLevel.FULL:
            return False
        if self._trust_level == TrustLevel.SANDBOX:
            return False
        
        tool_info = self.SENSITIVE_TOOLS.get(tool_name)
        if not tool_info:
            return False
        
        if self._trust_level == TrustLevel.STANDARD:
            return tool_info["risk"] in ("medium", "high")
        
        return True
    
    async def request_authorization(
        self,
        session_id: str,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> AuthorizationResponse:
        """请求工具使用授权"""
        tool_info = self.SENSITIVE_TOOLS.get(tool_name, {"risk": "unknown", "description": tool_name})
        
        request = AuthorizationRequest(
            request_id=str(uuid.uuid4()),
            session_id=session_id,
            tool_name=tool_name,
            arguments=arguments,
            reason=tool_info["description"],
            risk_level=tool_info["risk"],
        )
        
        if self._authorization_handler:
            return await self._authorization_handler(request)
        
        return AuthorizationResponse(
            request_id=request.request_id,
            approved=tool_info["risk"] != "high",
            session_id=session_id,
        )
```

- [x] **Step 2: 编写权限管理器测试**

```python
# tests/collaboration/test_permission.py
from unittest.mock import Mock

def test_filter_tools_whitelist():
    manager = ToolPermissionManager(trust_level=TrustLevel.FULL)
    tools = [Mock(name="read"), Mock(name="exec"), Mock(name="write")]
    
    config = CustomAgentConfig(
        agent_id="test",
        name="Test",
        tools_enabled=["read"],
    )
    
    filtered = manager.filter_tools(tools, config)
    assert len(filtered) == 1
    assert filtered[0].name == "read"

def test_sandbox_mode():
    manager = ToolPermissionManager(trust_level=TrustLevel.SANDBOX)
    tools = [Mock(name="read"), Mock(name="exec"), Mock(name="web_fetch")]
    
    config = CustomAgentConfig(agent_id="test", name="Test")
    filtered = manager.filter_tools(tools, config)
    
    assert len(filtered) == 2
    assert all(t.name in manager.SAFE_TOOLS for t in filtered)
```

- [x] **Step 3: 运行测试验证**

```bash
pytest tests/collaboration/test_permission.py -v
```

---

### Task 2.2: 上下文共享管理器

**Files:**
- Create: `src/pyclaw/agents/collaboration/context/__init__.py`
- Create: `src/pyclaw/agents/collaboration/context/sharing.py`

- [x] **Step 1: 实现上下文管理器**

```python
# src/pyclaw/agents/collaboration/context/sharing.py
from __future__ import annotations

import json
import shutil
import uuid
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from pyclaw.agents.collaboration.types import ChildContext, MemoryScope

class ScratchpadConfig(BaseModel):
    path: Path
    scope: MemoryScope
    max_size_mb: int = 100
    auto_cleanup: bool = True

class ContextSharingManager:
    """上下文共享管理器"""
    
    MEMORY_SCOPE_MAPPING = {
        MemoryScope.TASK: "session",
        MemoryScope.PROJECT: "project",
    }
    
    def __init__(
        self,
        session_manager: Any = None,
        memory_manager: Any = None,
        base_scratchpad_dir: Path | None = None,
    ) -> None:
        self._session_manager = session_manager
        self._memory_manager = memory_manager
        self._scratchpad_dir = base_scratchpad_dir or Path.home() / ".pyclaw" / "scratchpad"
        self._active_scratchpads: dict[str, ScratchpadConfig] = {}
    
    def get_parent_history(
        self,
        parent_session_id: str,
        mode: str = "summary",
        recent_count: int = 10,
    ) -> list[dict[str, Any]]:
        """获取父会话历史（只读）"""
        if not self._session_manager:
            return []
        
        history = self._session_manager.get_history(parent_session_id)
        
        if mode == "full":
            return self._deep_copy(history)
        elif mode == "recent":
            return self._deep_copy(history[-recent_count:])
        else:  # summary
            return self._summarize_history(history)
    
    def _summarize_history(self, history: list[dict]) -> list[dict]:
        """压缩历史为摘要"""
        if len(history) <= 6:
            return self._deep_copy(history)
        
        return [
            *history[:3],
            {"role": "system", "content": f"[... {len(history) - 6} messages omitted ...]"},
            *history[-3:],
        ]
    
    def create_scratchpad(
        self,
        parent_session_id: str,
        scope: MemoryScope = MemoryScope.TASK,
    ) -> ScratchpadConfig:
        """创建共享工作区"""
        scratchpad_id = f"{parent_session_id}_{uuid.uuid4().hex[:8]}"
        path = self._scratchpad_dir / scratchpad_id
        path.mkdir(parents=True, exist_ok=True)
        
        config = ScratchpadConfig(path=path, scope=scope)
        self._active_scratchpads[scratchpad_id] = config
        
        return config
    
    def cleanup_scratchpad(self, scratchpad_id: str) -> bool:
        """清理 Scratchpad"""
        config = self._active_scratchpads.pop(scratchpad_id, None)
        if config and config.auto_cleanup and config.path.exists():
            shutil.rmtree(config.path)
            return True
        return False
    
    def prepare_child_context(
        self,
        parent_session_id: str,
        task_prompt: str,
        memory_scope: MemoryScope = MemoryScope.TASK,
    ) -> ChildContext:
        """准备子 Agent 上下文"""
        history = self.get_parent_history(parent_session_id)
        scratchpad = self.create_scratchpad(parent_session_id, memory_scope)
        
        return ChildContext(
            session_id=str(uuid.uuid4()),
            parent_session_id=parent_session_id,
            history_snapshot=history,
            scratchpad_dir=str(scratchpad.path),
            memory_scope=memory_scope,
            task_prompt=task_prompt,
        )
    
    def _deep_copy(self, data: list[dict]) -> list[dict]:
        """深拷贝"""
        return json.loads(json.dumps(data))
```

- [x] **Step 2: 编写上下文管理器测试**

```python
# tests/collaboration/test_context.py
import pytest
from pathlib import Path
import tempfile

def test_create_scratchpad():
    with tempfile.TemporaryDirectory() as tmpdir:
        manager = ContextSharingManager(base_scratchpad_dir=Path(tmpdir))
        
        config = manager.create_scratchpad("parent-123", MemoryScope.TASK)
        
        assert config.path.exists()
        assert config.scope == MemoryScope.TASK

def test_cleanup_scratchpad():
    with tempfile.TemporaryDirectory() as tmpdir:
        manager = ContextSharingManager(base_scratchpad_dir=Path(tmpdir))
        
        config = manager.create_scratchpad("parent-123")
        assert config.path.exists()
        
        manager.cleanup_scratchpad(config.path.name)
        assert not config.path.exists()
```

- [x] **Step 3: 运行测试验证**

```bash
pytest tests/collaboration/test_context.py -v
```

---

### Task 2.3: Custom Agent 模式实现

**Files:**
- Create: `src/pyclaw/agents/collaboration/modes/__init__.py`
- Create: `src/pyclaw/agents/collaboration/modes/base.py`
- Create: `src/pyclaw/agents/collaboration/modes/custom_agent.py`

- [x] **Step 1: 定义模式基类**

```python
# src/pyclaw/agents/collaboration/modes/base.py
from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

from pyclaw.agents.collaboration.types import (
    ChildContext,
    CollaborationModeType,
    CustomAgentConfig,
    SpawnResult,
    TrustLevel,
)
from pyclaw.agents.types import AgentTool

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.engine import CollaborationEngine

class CollaborationMode(ABC):
    """协作模式抽象基类"""
    
    mode_type: CollaborationModeType
    
    def __init__(self, engine: CollaborationEngine) -> None:
        self._engine = engine
    
    @abstractmethod
    async def spawn(
        self,
        config: CustomAgentConfig | Any,
    ) -> SpawnResult:
        """创建子 Agent"""
        ...
    
    @abstractmethod
    def get_tools_for_child(
        self,
        config: CustomAgentConfig,
        trust_level: TrustLevel,
    ) -> list[AgentTool]:
        """获取子 Agent 可用工具"""
        ...
    
    def prepare_context(
        self,
        parent_session_id: str,
        child_config: CustomAgentConfig,
    ) -> ChildContext:
        """准备子 Agent 上下文"""
        if self._engine._context_manager:
            return self._engine._context_manager.prepare_child_context(
                parent_session_id=parent_session_id,
                task_prompt=child_config.description,
                memory_scope=child_config.memory_scope,
            )
        return ChildContext(
            session_id="",
            parent_session_id=parent_session_id,
            history_snapshot=[],
            memory_scope=child_config.memory_scope,
            task_prompt=child_config.description,
        )
    
    def on_child_complete(self, result: Any) -> None:
        """子 Agent 完成回调"""
        pass
```

- [x] **Step 2: 实现 Custom Agent 模式**

```python
# src/pyclaw/agents/collaboration/modes/custom_agent.py
from __future__ import annotations

import uuid
from typing import Any

from pyclaw.agents.collaboration.modes.base import CollaborationMode
from pyclaw.agents.collaboration.storage.agent_registry import CustomAgentRegistry
from pyclaw.agents.collaboration.types import (
    ChildContext,
    CollaborationModeType,
    CustomAgentConfig,
    SpawnResult,
    TrustLevel,
)
from pyclaw.agents.subagents.types import SubagentConfig

class CustomAgentMode(CollaborationMode):
    """Custom Agent 模式"""
    
    mode_type = CollaborationModeType.CUSTOM_AGENT
    
    def __init__(self, engine: Any) -> None:
        super().__init__(engine)
        self._registry = CustomAgentRegistry()
    
    async def spawn(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> SpawnResult:
        """创建 Custom Agent 子会话"""
        
        if isinstance(config, SubagentConfig):
            agent_config = self._registry.get(config.agent_id)
            if not agent_config:
                raise ValueError(f"Unknown agent: {config.agent_id}")
        else:
            agent_config = config
        
        child_context = self.prepare_context(
            parent_session_id=self._engine.session_id,
            child_config=agent_config,
        )
        
        subagent_config = SubagentConfig(
            session_id=str(uuid.uuid4()),
            agent_id=agent_config.agent_id,
            prompt=child_context.task_prompt,
            system_prompt=agent_config.system_prompt,
            tools_enabled=agent_config.tools_enabled or [],
            tools_disabled=agent_config.tools_disabled or [],
            current_depth=getattr(self._engine, '_depth', 0) + 1,
            parent_session_id=self._engine.session_id,
        )
        
        # 调用底层 SubagentManager
        result = await self._engine._subagent_manager.spawn(subagent_config)
        
        return SpawnResult(
            session_id=subagent_config.session_id,
            status="spawned",
            child_context=child_context.model_dump(),
        )
    
    def get_tools_for_child(
        self,
        config: CustomAgentConfig,
        trust_level: TrustLevel,
    ) -> list[Any]:
        """获取过滤后的工具集"""
        if self._engine._permission_manager:
            all_tools = getattr(self._engine, '_tool_registry', [])
            return self._engine._permission_manager.filter_tools(all_tools, config)
        return []
```

- [x] **Step 3: 编写模式测试**

```python
# tests/collaboration/test_modes.py
import pytest
from unittest.mock import Mock, AsyncMock

@pytest.mark.asyncio
async def test_custom_agent_mode_spawn():
    subagent_manager = Mock()
    subagent_manager.spawn = AsyncMock(return_value=Mock(state="completed"))
    
    engine = Mock()
    engine._subagent_manager = subagent_manager
    engine.session_id = "parent-123"
    engine._context_manager = None
    
    mode = CustomAgentMode(engine)
    
    config = CustomAgentConfig(
        agent_id="test-agent",
        name="Test Agent",
        system_prompt="You are a test agent.",
    )
    
    result = await mode.spawn(config)
    
    assert result.status == "spawned"
    assert result.session_id is not None
```

- [x] **Step 4: 运行测试验证**

```bash
pytest tests/collaboration/test_modes.py -v
```

- [x] **Step 5: 编写 M2 集成测试**

```python
# tests/integration/test_collaboration_m2.py
"""M2 里程碑集成测试：验证核心协作流程"""
import pytest
from unittest.mock import Mock, AsyncMock, patch
from pathlib import Path
import tempfile

from pyclaw.agents.collaboration import CollaborationEngine
from pyclaw.agents.collaboration.modes.custom_agent import CustomAgentMode
from pyclaw.agents.collaboration.types import CollaborationModeType, CustomAgentConfig

@pytest.mark.asyncio
async def test_end_to_end_custom_agent_spawn():
    """端到端测试：Custom Agent 创建子 Agent"""
    from pyclaw.agents.subagents.manager import SubagentManager
    
    # 1. 初始化引擎
    subagent_manager = SubagentManager()
    engine = CollaborationEngine(
        subagent_manager=subagent_manager,
        session_id="test-parent-session",
    )
    
    # 2. 注册模式
    custom_mode = CustomAgentMode(engine)
    engine.register_mode(CollaborationModeType.CUSTOM_AGENT, custom_mode)
    
    # 3. 切换模式
    result = engine.switch_mode(CollaborationModeType.CUSTOM_AGENT)
    assert result.success
    
    # 4. 创建 Custom Agent 配置
    config = CustomAgentConfig(
        agent_id="test-researcher",
        name="Researcher",
        system_prompt="You are a researcher.",
        tools_enabled=["read", "search"],
    )
    
    # 5. 尝试 spawn（需要 mock 实际执行）
    # 注：此测试验证流程可达，不实际执行 LLM 调用
    assert engine.active_mode == CollaborationModeType.CUSTOM_AGENT
    assert engine.depth == 0
```

- [x] **Step 6: 运行集成测试**

```bash
pytest tests/integration/test_collaboration_m2.py -v
```

---

## Milestone 3: 智能与集成 (P2-P3)

### Task 3.1: 模式选择器

**Files:**
- Create: `src/pyclaw/agents/collaboration/selector.py`

- [x] **实现 ModeSelector（详见设计规格 4.3）**

---

### Task 3.2: 任务分解器

**Files:**
- Create: `src/pyclaw/agents/collaboration/decomposer.py`

- [x] **实现 TaskDecomposer（详见设计规格 4.4）**

---

### Task 3.3: 协作工具集

**Files:**
- Create: `src/pyclaw/agents/collaboration/tools.py`

- [x] **实现 6 个协作工具（详见设计规格 6）**

---

### Task 3.4: run_agent 集成

**Files:**
- Modify: `src/pyclaw/agents/runner.py`

- [x] **Step 1: 添加协作引擎参数**

```python
# src/pyclaw/agents/runner.py
from pyclaw.agents.collaboration import CollaborationEngine, CollaborationModeType

async def run_agent(
    prompt: str,
    session: SessionManager,
    model: ModelConfig,
    tools: list[AgentTool] | None = None,
    system_prompt: str | None = None,
    # 新增参数
    collaboration_engine: CollaborationEngine | None = None,
    collaboration_mode: CollaborationModeType | None = None,
    **kwargs,
) -> AsyncGenerator[AgentEvent, None]:
    """Agent 主循环 - 支持协作模式"""
```

- [x] **Step 2: 注册协作工具**

```python
    # 如果有协作引擎，注册协作工具
    if collaboration_engine:
        from pyclaw.agents.collaboration.tools import (
            SpawnChildTool,
            SteerChildTool,
            KillChildTool,
            ListChildrenTool,
            SuggestModeTool,
            ModeSwitchTool,
        )
        
        tools = tools or []
        tools.extend([
            SpawnChildTool(engine=collaboration_engine),
            SteerChildTool(engine=collaboration_engine),
            KillChildTool(engine=collaboration_engine),
            ListChildrenTool(engine=collaboration_engine),
            SuggestModeTool(engine=collaboration_engine),
            ModeSwitchTool(engine=collaboration_engine),
        ])
```

- [x] **Step 3: Coordinator-Worker 模式工具过滤**

```python
    # Coordinator-Worker 模式过滤工具
    if collaboration_mode == CollaborationModeType.COORDINATOR_WORKER:
        mode_impl = collaboration_engine._modes.get(collaboration_mode)
        if mode_impl:
            tools = mode_impl.get_coordinator_tools()
```

- [x] **Step 4: 编写集成测试**

```python
# tests/integration/test_collaboration_flow.py
import pytest
from unittest.mock import Mock, AsyncMock, patch

@pytest.mark.asyncio
async def test_run_agent_with_collaboration():
    """测试 run_agent 集成协作引擎"""
    from pyclaw.agents.runner import run_agent
    from pyclaw.agents.collaboration import CollaborationEngine
    from pyclaw.agents.subagents.manager import SubagentManager
    
    subagent_manager = Mock(spec=SubagentManager)
    subagent_manager.spawn = AsyncMock()
    
    engine = CollaborationEngine(subagent_manager=subagent_manager)
    
    # 验证协作工具被注册
    tools = []
    async for event in run_agent(
        prompt="test",
        session=Mock(),
        model=Mock(),
        tools=tools,
        collaboration_engine=engine,
    ):
        break  # 只验证初始化
    
    tool_names = [t.name for t in tools]
    assert "spawn_child" in tool_names
    assert "suggest_mode" in tool_names
```

- [x] **Step 5: 运行集成测试**

```bash
pytest tests/integration/test_collaboration_flow.py -v
```

---

### Task 3.5: CLI 命令

**Files:**
- Create: `src/pyclaw/cli/commands/collaboration_cmd.py`

- [x] **实现 agents 和 mode 命令**

---

## Milestone 4: 高级模式与稳定化

### Task 4.1: Fork/Swarm 模式

- [x] **实现 ForkSwarmMode**

### Task 4.2: Coordinator-Worker 模式

- [x] **实现 CoordinatorWorkerMode**

### Task 4.3: Dynamic Decompose 模式

- [x] **实现 DynamicDecomposeMode**

### Task 4.4: Markdown 配置解析

- [x] **完善 Markdown frontmatter 解析**

### Task 4.5: 端到端测试

- [x] **编写完整协作流程测试**

---

## 验收标准

| 里程碑 | 验收标准 |
|--------|----------|
| M1 | types.py, engine.py, agent_registry.py 单元测试通过 |
| M2 | permission/, context/, custom_agent.py 单元测试通过；**集成测试**验证 CustomAgentMode.spawn 与 SubagentManager 交互正常 |
| M3 | selector.py, decomposer.py, tools.py 完成，run_agent 集成测试通过 |
| M4 | 四种模式全部实现，端到端测试通过，CLI 命令可用 |

---

## 风险与缓解

| 风险 | 缓解措施 |
|------|----------|
| SubagentConfig 字段不足 | 已有 tools_enabled/disabled，按需扩展 |
| Memory 系统接口变化 | ContextSharingManager 封装适配 |
| 并发安全问题 | 实现 SwitchPolicy，加锁保护 |
| 子 Agent 失控消耗资源 | SubagentManager 全局并发限制 + 超时机制 + kill_all_children |
