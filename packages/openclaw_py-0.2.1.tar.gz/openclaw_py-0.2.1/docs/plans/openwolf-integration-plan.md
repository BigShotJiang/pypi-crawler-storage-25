# OpenWolf Token 节省技术集成计划

> 分析 OpenWolf 项目核心技术，审慎集成到 PyClaw 项目中。

## 一、OpenWolf 核心技术分析

### 1.1 Token 节省机制概览

OpenWolf 通过 6 个 Claude Code 生命周期 hooks 实现约 **80%** 的 token 节省：

| 机制 | 功能 | 节省原理 |
|------|------|----------|
| **anatomy.md** | 项目文件索引 | 避免读取完整文件，用描述+token估算代替 |
| **cerebrum.md** | 学习记忆 | 避免重复犯错，记录用户偏好 |
| **token-ledger.json** | Token 追踪 | 监控浪费模式，优化使用 |
| **重复读取警告** | Session 内追踪 | 阻止重复读取同一文件 |
| **buglog.json** | Bug 修复记忆 | 避免重复调试相同问题 |
| **memory.md** | 会话日志 | 保持上下文连续性 |

### 1.2 核心文件结构

```
.wolf/
├── anatomy.md          # 文件索引 (~每个文件 1 行描述 + token 估算)
├── cerebrum.md         # 学习记忆 (Do-Not-Repeat, Preferences, Learnings)
├── memory.md           # 会话日志
├── buglog.json         # Bug 修复记录
├── token-ledger.json   # Token 使用统计
├── config.json         # 配置
├── identity.md         # Agent 身份
├── OPENWOLF.md         # Claude 指令文件
└── hooks/              # Claude Code hooks
    ├── session-start.ts
    ├── pre-read.ts
    ├── post-read.ts
    ├── pre-write.ts
    ├── post-write.ts
    └── stop.ts
```

### 1.3 关键技术点

#### 1.3.1 Token 估算算法

```typescript
// 简单但有效的 token 估算
function estimateTokens(text: string, type: "code" | "prose" | "mixed"): number {
  const ratio = type === "code" ? 3.5 : type === "prose" ? 4.0 : 3.75;
  return Math.ceil(text.length / ratio);
}
```

#### 1.3.2 文件描述提取

OpenWolf 的 `extractDescription()` 函数支持 **20+ 种编程语言** 的智能描述提取：
- Python: docstring、class/function 定义、FastAPI/Flask 路由
- TypeScript: JSDoc、React 组件、Next.js 路由
- Go: package 注释、struct/interface 定义
- Rust: doc comments、struct/trait/enum 定义
- 等等...

#### 1.3.3 重复读取检测

```typescript
// 在 pre-read hook 中检查
if (session.files_read[normalizedFile]) {
  process.stderr.write(
    `⚡ OpenWolf: ${path.basename(normalizedFile)} was already read this session (~${prev.tokens} tokens)`
  );
  session.repeated_reads_warned++;
  return; // 不阻止读取，只是警告
}
```

## 二、PyClaw 现有架构对比

### 2.1 PyClaw Memory 系统现状

PyClaw 已有完整的记忆系统：

```
src/pyclaw/memory/
├── backend.py          # 抽象后端接口
├── store.py            # SQLite + FTS5 存储
├── lancedb_backend.py  # LanceDB 向量存储
├── manager.py          # 记忆管理器
├── embeddings.py       # 向量嵌入
├── active_recall.py    # 主动召回
├── wiki/               # Wiki Vault 知识库
└── ...
```

### 2.2 功能对比

| 功能 | OpenWolf | PyClaw | 差异 |
|------|----------|--------|------|
| 文件索引 | anatomy.md | ❌ 无 | **需要添加** |
| 学习记忆 | cerebrum.md | 部分支持 | 需增强结构化 |
| Token 追踪 | token-ledger.json | ❌ 无 | **需要添加** |
| Bug 记忆 | buglog.json | ❌ 无 | **需要添加** |
| 会话日志 | memory.md | DialogStore | 已有类似功能 |
| 重复读取警告 | hooks | ❌ 无 | **需要添加** |

### 2.3 集成挑战

1. **语言差异**: OpenWolf 是 TypeScript，PyClaw 是 Python
2. **Hook 机制**: Claude Code hooks 是 Node.js，需要 Python 等效实现
3. **架构差异**: OpenWolf 是独立工具，PyClaw 是 AI 网关平台

## 三、集成方案

### 3.1 设计原则

1. **不破坏现有系统**: 新功能作为独立模块添加
2. **选择性集成**: 只集成核心 token 节省功能
3. **Python 原生实现**: 用 Python 重写核心逻辑
4. **可选启用**: 通过 CLI 命令和配置开关控制

### 3.2 模块设计

```
src/pyclaw/token_aware/
├── __init__.py
├── anatomy.py          # 文件索引 (对应 anatomy.md)
├── cerebrum.py         # 学习记忆 (对应 cerebrum.md)
├── buglog.py           # Bug 记忆 (对应 buglog.json)
├── ledger.py           # Token 追踪 (对应 token-ledger.json)
├── session.py          # 会话状态追踪
├── scanner.py          # 项目扫描器
├── description.py      # 文件描述提取 (移植 extractDescription)
├── estimator.py        # Token 估算
└── commands.py         # CLI 命令
```

### 3.3 数据存储位置

```
~/.pyclaw/
├── pyclaw.json         # 现有配置
└── token_aware/        # 新增目录
    ├── anatomy.json    # 文件索引 (JSON 更适合 Python)
    ├── cerebrum.json   # 学习记忆
    ├── buglog.json     # Bug 记忆
    ├── ledger.json     # Token 追踪
    └── sessions/       # 会话状态
        └── {session_id}.json
```

### 3.4 CLI 命令设计

```bash
# 初始化 token-aware 功能
pyclaw token-aware init

# 扫描项目生成 anatomy
pyclaw token-aware scan

# 查看状态
pyclaw token-aware status

# 查看学习记忆
pyclaw token-aware cerebrum list
pyclaw token-aware cerebrum add "Always use async for I/O"

# 查看 bug 记忆
pyclaw token-aware buglog list
pyclaw token-aware buglog search "TypeError"

# Token 统计
pyclaw token-aware stats
```

## 四、实现计划

### Phase 1: 核心模块 (P0)

1. **Token 估算器** (`estimator.py`)
   - 移植 OpenWolf 的 token 估算算法
   - 支持代码/文本/混合模式

2. **文件描述提取** (`description.py`)
   - 移植 `extractDescription()` 函数
   - 支持 Python、TypeScript、Go、Rust 等主流语言

3. **项目扫描器** (`scanner.py`)
   - 扫描项目目录
   - 生成文件索引 (anatomy)

### Phase 2: 记忆系统 (P0)

4. **学习记忆** (`cerebrum.py`)
   - Do-Not-Repeat 列表
   - User Preferences
   - Key Learnings
   - Decision Log

5. **Bug 记忆** (`buglog.py`)
   - Bug 记录结构
   - 搜索功能
   - 自动检测模式 (可选)

### Phase 3: 追踪系统 (P1)

6. **Token 追踪** (`ledger.py`)
   - 会话级追踪
   - 累计统计
   - 浪费检测

7. **会话状态** (`session.py`)
   - 文件读取追踪
   - 重复读取检测
   - 编辑计数

### Phase 4: CLI 集成 (P1)

8. **CLI 命令** (`commands.py`)
   - `pyclaw token-aware init`
   - `pyclaw token-aware scan`
   - `pyclaw token-aware status`
   - 其他命令

### Phase 5: Gateway 集成 (P2)

9. **Gateway Hook 集成**
   - 在 Chat 方法中注入提示
   - 读取前检查 anatomy
   - 写入后更新索引

## 五、集成到 Gateway

### 5.1 系统提示注入

在 Gateway 的 Chat 流程中注入 token-aware 提示：

```python
# src/pyclaw/gateway/methods/chat.py

async def chat_completion(...):
    # 注入 token-aware 提示
    if token_aware_enabled:
        anatomy = await get_anatomy_summary()
        cerebrum = await get_cerebrum_summary()
        system_prompt += f"\n\n{anatomy}\n{cerebrum}"
```

### 5.2 工具调用追踪

在 Gateway 的工具调用流程中添加追踪：

```python
# src/pyclaw/gateway/methods/tools.py

async def handle_tool_call(tool_name, tool_input):
    if tool_name == "Read":
        # 检查是否已读取
        if await session.has_read(tool_input["file_path"]):
            logger.warning(f"重复读取: {tool_input['file_path']}")
        await session.record_read(tool_input["file_path"], estimated_tokens)
    
    elif tool_name in ("Write", "Edit"):
        await session.record_write(tool_input["file_path"], estimated_tokens)
        # 更新 anatomy
        await anatomy.update_entry(tool_input["file_path"])
```

## 六、与现有 Memory 系统集成

### 6.1 复用现有组件

- **MemoryStore**: 用于存储 cerebrum 和 buglog
- **EmbeddingProvider**: 用于语义搜索 bug 记录
- **DialogStore**: 复用会话日志功能

### 6.2 扩展 MemoryConfig

```python
# src/pyclaw/config/schema.py

class TokenAwareConfig(_CamelModel):
    enabled: bool = True
    anatomy_scan_on_start: bool = True
    warn_repeated_reads: bool = True
    track_tokens: bool = True
    auto_bug_detect: bool = False

class MemoryConfig(_CamelModel):
    # ... 现有字段 ...
    token_aware: TokenAwareConfig = Field(default_factory=TokenAwareConfig)
```

## 七、测试计划

### 7.1 单元测试

- `test_estimator.py`: Token 估算准确性
- `test_description.py`: 各语言描述提取
- `test_scanner.py`: 项目扫描功能
- `test_cerebrum.py`: 学习记忆 CRUD
- `test_buglog.py`: Bug 记忆功能
- `test_ledger.py`: Token 追踪准确性

### 7.2 集成测试

- `test_gateway_integration.py`: Gateway 集成
- `test_memory_integration.py`: 与现有 Memory 系统集成

### 7.3 性能测试

- 扫描大型项目的时间
- Token 估算的性能影响

## 八、风险评估

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| 性能影响 | 低 | Token 估算是 O(1) 操作 |
| 准确性 | 中 | Token 估算基于字符数，足够准确 |
| 兼容性 | 低 | 作为可选模块，不影响现有功能 |
| 维护成本 | 中 | 需要持续更新语言描述提取规则 |

## 九、预期收益

1. **Token 节省**: 预计 50-70% 的读取 token 节省
2. **开发效率**: 减少重复犯错，提高一次性正确率
3. **可观测性**: Token 使用情况透明化
4. **知识积累**: 项目知识持久化，跨会话复用

## 十、时间估算

| Phase | 工作量 | 优先级 |
|-------|--------|--------|
| Phase 1 | 2-3 天 | P0 |
| Phase 2 | 2 天 | P0 |
| Phase 3 | 1-2 天 | P1 |
| Phase 4 | 1 天 | P1 |
| Phase 5 | 2 天 | P2 |

**总计**: 约 8-10 天

## 十一、实施建议

1. **先实现 Phase 1-2**: 核心功能即可带来主要收益
2. **渐进式集成**: 不一次性集成所有功能
3. **用户反馈驱动**: 根据实际使用反馈调整优先级
4. **保持简单**: 避免过度设计，聚焦核心价值
