# 多智能体协作框架实现计划

> **创建日期**: 2026-04-12
> **完成日期**: 2026-04-13
> **设计文档**: [2026-04-12-multi-agent-collaboration-framework-design.md](../superpowers/specs/2026-04-12-multi-agent-collaboration-framework-design.md)
> **状态**: 已完成 ✅

---

## 实现概述

本计划将设计文档转化为可执行的开发任务，按优先级分为 5 个阶段。

### 实现原则

1. **渐进式迁移**: 保持现有功能正常，通过适配器模式接入新架构
2. **测试先行**: 每个模块完成后立即编写单元测试
3. **向后兼容**: 使用 `@deprecated` 标记旧接口，逐步迁移

### 依赖关系

```
P0 (核心抽象层) ✅
  ├──→ P1-Memory (Memory 系统重构) ✅
  └──→ P1-Context (Context 引擎实现) ✅
         └──→ P2 (协作引擎) ✅
                └──→ P3 (AgentRuntime 集成) ✅
                       └──→ P4 (高级特性) ✅
```

---

## Phase 0: 核心抽象层 ✅

**目标**: 建立能力注册中心和统一 Agent 定义

**预计工作量**: 2-3 天

**完成日期**: 2026-04-12

### Task 0.1: 创建能力注册中心 ✅

**文件**: `src/pyclaw/agents/capabilities/`

```
capabilities/
├── __init__.py
├── types.py      # CapabilityType, AgentCapability
└── registry.py   # AgentCapabilityRegistry
```

**实现要点**:

- [x] 定义 `CapabilityType` 枚举
- [x] 定义 `AgentCapability` dataclass（含 tags 字段）
- [x] 实现 `AgentCapabilityRegistry` 单例
  - [x] `register()` - 线程安全注册
  - [x] `unregister()` - 注销能力
  - [x] `get()` - 按名称获取
  - [x] `get_by_metadata()` - 按 metadata 过滤
  - [x] `get_by_tags()` - 按标签查询
  - [x] `list_all()` - 列出所有能力
- [x] 实现 `get_capability_registry()` 工厂函数

**测试**: `tests/pyclaw/agents/capabilities/test_registry.py`

---

### Task 0.2: 定义统一 Agent 定义 ✅

**文件**: `src/pyclaw/agents/definition.py`

**实现要点**:

- [x] 定义 `TrustLevel` 枚举
- [x] 定义 `MemoryScope` 枚举
- [x] 定义 `ContextPolicy` dataclass
- [x] 定义 `OrchestrationConfig` dataclass
- [x] 定义 `AgentDefinition` dataclass
  - [x] 基础信息字段
  - [x] 配置字段（trust_level, memory, context, orchestration）
  - [x] `get_spawn_config()` 方法

**测试**: `tests/pyclaw/agents/test_definition.py`

---

### Task 0.3: 定义能力抽象基类 ✅

**文件**: 
- `src/pyclaw/agents/memory/provider.py` (MemoryProvider ABC)
- `src/pyclaw/agents/context/engine.py` (ContextEngine ABC)
- `src/pyclaw/agents/orchestration/engine.py` (OrchestrationEngine ABC)

**实现要点**:

- [x] `MemoryProvider` ABC
  - [x] `name` 属性
  - [x] `initialize()`, `shutdown()` 生命周期钩子
  - [x] CRUD 方法: `add()`, `search()`, `get()`, `update()`, `delete()`
  - [x] `get_stats()` 状态方法

- [x] `ContextEngine` ABC
  - [x] `name` 属性
  - [x] Token 状态字段
  - [x] `update_from_response()`, `should_compress()`, `compress()`
  - [x] `get_status()` 状态方法

- [x] `OrchestrationEngine` ABC
  - [x] `mode` 属性
  - [x] `execute()`, `spawn_agent()`, `kill_agent()`, `steer_agent()`

---

### Task 0.4: 升级 BuiltinAgent 为 AgentDefinition ✅

**文件**: `src/pyclaw/agents/builtin_agents/`

**实现要点**:

- [x] 更新 `base.py` 中的 `BuiltinAgent` 使用 `AgentDefinition`
- [x] 更新 `explore_agent.py`
- [x] 更新 `plan_agent.py`
- [x] 更新 `verification_agent.py`
- [x] 更新 `general_purpose_agent.py`
- [x] 更新 `registry.py` 使用新定义

**验证**: 运行现有测试确保向后兼容

---

### Phase 0 验收标准

- [x] 所有新模块通过 `ruff check` 和 `mypy`
- [x] 单元测试覆盖率 > 80%
- [x] 现有 CLI 功能正常
- [x] 现有测试通过

---

## Phase 1-M: Memory 系统重构 ✅

**目标**: 实现可插拔 Memory 后端

**预计工作量**: 3-4 天

**前置条件**: Phase 0 完成

**完成日期**: 2026-04-12

### Task 1M.1: 定义 Memory 作用域和路径 ✅

**文件**: `src/pyclaw/agents/memory/`

```
memory/
├── __init__.py
├── scope.py       # MemoryScope, MemoryPath
├── provider.py    # MemoryProvider ABC, MemoryEntry
└── embedding.py   # EmbeddingProvider ABC
```

**实现要点**:

- [x] `MemoryScope` 枚举
- [x] `MemoryPath` dataclass
  - [x] `resolve()` 方法解析路径
- [x] `MemoryEntry` dataclass
- [x] `EmbeddingProvider` ABC
  - [x] `name`, `dimension` 属性
  - [x] `embed()`, `embed_query()` 方法

---

### Task 1M.2: 实现 BuiltinMemoryProvider ✅

**文件**: `src/pyclaw/agents/memory/providers/`

```
providers/
├── __init__.py
└── builtin.py     # BuiltinMemoryProvider
```

**实现要点**:

- [x] 实现 `_MemorySearchAdapter` 封装 BM25 搜索
- [x] 实现 `BuiltinMemoryProvider`
  - [x] 使用现有 `MemoryDirectory` 的存储逻辑
  - [x] 通过适配器调用 `search_all_memory_files`
  - [x] 实现降级搜索（ImportError 时）

**测试**: `tests/pyclaw/agents/memory/providers/test_builtin.py`

---

### Task 1M.3: 实现 Memory 能力注册 ✅

**文件**: `src/pyclaw/agents/memory/capability.py`

**实现要点**:

- [x] `register_memory_capability()` 函数
- [x] `get_memory_provider()` 函数
- [x] 注册默认 builtin provider

---

### Task 1M.4: 实现兼容层 ✅

**文件**: `src/pyclaw/agents/compat.py`

**实现要点**:

- [x] `@deprecated` 装饰器
- [x] `MemoryDirectory` 兼容层（代理到 `BuiltinMemoryProvider`）

---

### Task 1M.5: 更新 memory_integration.py ✅

**文件**: `src/pyclaw/agents/memory_integration.py`

**实现要点**:

- [x] 使用新的 `BuiltinMemoryProvider`
- [x] 保持现有 API 兼容

---

### Phase 1-M 验收标准

- [x] Memory 系统测试通过
- [x] 现有 memory 工具正常工作
- [x] 兼容层测试通过

---

## Phase 1-C: Context 引擎实现 ✅

**目标**: 实现 LLM 压缩引擎

**预计工作量**: 3-4 天

**前置条件**: Phase 0 完成

**完成日期**: 2026-04-12

### Task 1C.1: 定义 Context Policy 和 MessageContext ✅

**文件**: `src/pyclaw/agents/context/policy.py`

**实现要点**:

- [x] `CompressionStrategy` 枚举
- [x] `CacheStrategy` 枚举
- [x] `ContextPolicy` dataclass（已在 Phase 0 定义）
- [x] `MessageContext` dataclass
  - [x] role, content, timestamp
  - [x] tool_call_id, tool_calls, parent_id
  - [x] `to_api_message()` 方法

---

### Task 1C.2: 实现 SummarizeEngine ✅

**文件**: `src/pyclaw/agents/context/engines/`

```
engines/
├── __init__.py
├── truncate.py    # TruncateEngine (简单)
└── summarize.py   # SummarizeEngine
```

**实现要点**:

- [x] 基于 `ContextCompactor` 重构
- [x] 结构化总结模板（Goal/Progress/Decisions/Resolved/Pending）
- [x] 迭代更新支持（`_previous_summary`）
- [x] Tail token budget 保护
- [x] 工具调用配对完整性检查

**测试**: `tests/pyclaw/agents/context/engines/test_summarize.py`

---

### Task 1C.3: 实现 Context 能力注册 ✅

**文件**: `src/pyclaw/agents/context/capability.py`

**实现要点**:

- [x] `register_context_capability()` 函数
- [x] `get_context_engine()` 函数

---

### Task 1C.4: 更新 ContextManager ✅

**文件**: `src/pyclaw/agents/context/manager.py`

**实现要点**:

- [x] 使用 `SummarizeEngine` 替换直接压缩
- [x] 保持现有 API

---

### Phase 1-C 验收标准

- [x] Context 压缩测试通过
- [x] 工具调用配对完整性测试通过
- [x] 现有 context 功能正常

---

## Phase 2: 协作引擎 ✅

**目标**: 实现中心化协调引擎

**预计工作量**: 3-4 天

**前置条件**: Phase 1 完成

**完成日期**: 2026-04-12

### Task 2.1: 定义协作模式和配置 ✅

**文件**: `src/pyclaw/agents/orchestration/mode.py`

**实现要点**:

- [x] `OrchestrationMode` 枚举
- [x] `RetryPolicy` dataclass
- [x] `OrchestrationConfig` dataclass（已在 Phase 0 定义）
- [x] `OrchestrationContext` dataclass
- [x] `OrchestrationResult` dataclass
- [x] `SubagentResult` dataclass
- [x] `Subtask` dataclass

---

### Task 2.2: 实现 CentralizedEngine ✅

**文件**: `src/pyclaw/agents/orchestration/engines/centralized.py`

**实现要点**:

- [x] 基于 `CoordinatorMode` 重构
- [x] `_decompose_goal()` 方法
- [x] `_execute_with_dependencies()` 方法
  - [x] 信号量控制并行度
  - [x] 异常处理和重试
- [x] `_aggregate_results()` 方法

**测试**: `tests/pyclaw/agents/orchestration/engines/test_centralized.py`

---

### Task 2.3: 实现 TaskDecomposer ✅

**文件**: `src/pyclaw/agents/orchestration/decomposer.py`

**实现要点**:

- [x] `TaskDecomposer` ABC
- [x] `RuleBasedDecomposer` 实现
  - [x] 四阶段分解：explore → plan → execute → verify
- [x] （可选）`LLMTaskDecomposer` 占位

---

### Task 2.4: 实现协作能力注册 ✅

**文件**: `src/pyclaw/agents/orchestration/capability.py`

**实现要点**:

- [x] `register_orchestration_capability()` 函数
- [x] `get_orchestration_engine()` 函数

---

### Phase 2 验收标准

- [x] 协作引擎测试通过
- [x] 子 Agent 生成和结果聚合正常
- [x] 现有 coordinator 功能正常

---

## Phase 3: AgentRuntime 集成 ✅

**目标**: 实现统一运行时

**预计工作量**: 2-3 天

**前置条件**: Phase 1-2 完成

**完成日期**: 2026-04-12

### Task 3.1: 实现 AgentRuntime ✅

**文件**: `src/pyclaw/agents/runtime.py`

**实现要点**:

- [x] `RuntimeState` 枚举
- [x] `AgentEvent` dataclass（已有，复用）
- [x] `AgentRuntime` dataclass
  - [x] `initialize()` - 初始化所有能力
  - [x] `shutdown()` - 关闭所有能力
  - [x] `run()` - 主执行循环
  - [x] `_build_memory_context()`
  - [x] `_build_messages()`
  - [x] `_preprocess_context()`
  - [x] `_run_loop()`
  - [x] `_postprocess()`

**测试**: `tests/pyclaw/agents/test_runtime.py`

---

### Task 3.2: 集成测试 ✅

**文件**: `tests/pyclaw/agents/test_runtime.py`

**测试场景**:

- [x] 单 Agent 执行
- [x] Memory 注入
- [x] Context 压缩

---

### Task 3.3: CLI 集成 (待后续)

**文件**: `src/pyclaw/cli/agent.py`

**实现要点**:

- [ ] 更新 CLI 使用 `AgentRuntime`
- [ ] 支持新配置格式

---

### Phase 3 验收标准

- [x] Runtime 测试通过
- [x] 能力集成正常
- [ ] CLI 功能正常（待后续）

---

## Phase 4: 高级特性 ✅

**目标**: 向量后端和高级协作模式

**预计工作量**: 5-7 天

**前置条件**: Phase 3 完成

**完成日期**: 2026-04-13

### Task 4.1: 实现 OpenAIEmbeddingProvider ✅

**文件**: `src/pyclaw/agents/memory/embeddings/__init__.py`

**实现要点**:

- [x] OpenAIEmbeddingProviderAdapter 适配器
- [x] 支持 text-embedding-3-small/large 模型
- [x] 支持自定义 dimension（截断嵌入）
- [x] L2 归一化

---

### Task 4.2: 实现 LocalEmbeddingProvider ✅

**文件**: `src/pyclaw/agents/memory/embeddings/local.py`

**实现要点**:

- [x] LocalEmbeddingProvider 使用 sentence-transformers
- [x] 支持多种本地模型（all-MiniLM-L6-v2, all-mpnet-base-v2 等）
- [x] 自动检测嵌入维度
- [x] GPU/CPU 设备选择

---

### Task 4.3: 实现 LanceDBMemoryProvider ✅

**文件**: `src/pyclaw/agents/memory/providers/lancedb.py`

**实现要点**:

- [x] 实现 MemoryProvider ABC
- [x] 向量语义搜索
- [x] 全文搜索回退
- [x] 嵌入生成集成

---

### Task 4.4: 实现 PipelineEngine ✅

**文件**: `src/pyclaw/agents/orchestration/engines/pipeline.py`

**实现要点**:

- [x] 顺序阶段执行
- [x] PipelineStage 配置
- [x] 阶段间数据传递
- [x] 可选阶段支持

---

### Task 4.5: 实现 HybridEngine ✅

**文件**: `src/pyclaw/agents/orchestration/engines/hybrid.py`

**实现要点**:

- [x] 动态模式选择
- [x] 集成 CentralizedEngine 和 PipelineEngine
- [x] 基于任务特征的模式路由

---

### Task 4.6: 实现 LLMTaskDecomposer ✅

**文件**: `src/pyclaw/agents/orchestration/decomposer.py`

**实现要点**:

- [x] TaskDecomposer ABC
- [x] LLMTaskDecomposer 实现
- [x] 结构化 JSON 输出解析
- [x] 缓存支持

---

## 测试策略

### 单元测试

- 每个模块完成后立即编写单元测试
- 使用 `pytest-asyncio` 处理异步测试
- Mock 外部依赖（LLM API、文件系统）

### 集成测试

- Phase 3 进行完整集成测试
- 使用内存存储替代文件系统
- 测试向后兼容性

### 性能测试

- Memory 搜索性能
- Context 压缩延迟
- 协作引擎吞吐量

---

## 风险与缓解

| 风险 | 缓解措施 |
|------|----------|
| 迁移破坏现有功能 | 保持兼容层，逐步迁移 |
| 测试覆盖不足 | 每个 Task 必须有对应测试 |
| 性能回退 | 性能基准测试 |
| API 不兼容 | 使用 `@deprecated` 标记 |

---

## 里程碑

| 阶段 | 预计完成 | 关键交付物 |
|------|----------|------------|
| Phase 0 | 第 3 天 | 能力注册中心、AgentDefinition |
| Phase 1 | 第 7 天 | MemoryProvider、ContextEngine |
| Phase 2 | 第 11 天 | CentralizedEngine、TaskDecomposer |
| Phase 3 | 第 14 天 | AgentRuntime、集成测试 |
| Phase 4 | 第 21 天 | 向量后端、高级模式 |

---

## 附录

### 相关文件清单

**新增文件**:
- `src/pyclaw/agents/capabilities/__init__.py`
- `src/pyclaw/agents/capabilities/types.py`
- `src/pyclaw/agents/capabilities/registry.py`
- `src/pyclaw/agents/definition.py`
- `src/pyclaw/agents/memory/__init__.py`
- `src/pyclaw/agents/memory/scope.py`
- `src/pyclaw/agents/memory/provider.py`
- `src/pyclaw/agents/memory/embedding.py`
- `src/pyclaw/agents/memory/capability.py`
- `src/pyclaw/agents/memory/providers/__init__.py`
- `src/pyclaw/agents/memory/providers/builtin.py`
- `src/pyclaw/agents/context/policy.py`
- `src/pyclaw/agents/context/capability.py`
- `src/pyclaw/agents/context/engines/__init__.py`
- `src/pyclaw/agents/context/engines/summarize.py`
- `src/pyclaw/agents/orchestration/mode.py`
- `src/pyclaw/agents/orchestration/engine.py`
- `src/pyclaw/agents/orchestration/capability.py`
- `src/pyclaw/agents/orchestration/engines/__init__.py`
- `src/pyclaw/agents/orchestration/engines/centralized.py`
- `src/pyclaw/agents/runtime.py`
- `src/pyclaw/agents/compat.py`

**修改文件**:
- `src/pyclaw/agents/builtin_agents/base.py`
- `src/pyclaw/agents/builtin_agents/registry.py`
- `src/pyclaw/agents/context/manager.py`
- `src/pyclaw/agents/memory_integration.py`
- `src/pyclaw/agents/orchestration/decomposer.py`
