# PyClaw 网站优化计划

> **目标**: 优化 https://www.pyclaw.cn/ 网站的视觉样式和内容结构，参考 docs.openclaw.ai 的设计
> **日期**: 2026-03-24
> **分支策略**: 保持现状（文档源码在 master，自动部署到 gh-pages）

---

## 一、现状分析

### 当前配置

| 项目 | 当前值 |
|------|--------|
| 主题 | MkDocs Material |
| 配色 | indigo (primary) + amber (accent) |
| 字体 | Noto Sans SC (文本) + JetBrains Mono (代码) |
| 域名 | www.pyclaw.cn |
| 部署 | GitHub Actions → gh-pages 分支 |
| Logo/Favicon | 未配置 |
| 自定义 CSS | 未启用（模板文件存在但注释） |

### 当前导航结构

```
首页
├── 入门
│   ├── 快速开始
│   ├── 安装指南
│   └── 配置说明
├── 核心概念
│   ├── 概念总览
│   └── 架构设计
├── API
│   └── API 参考
└── 帮助
    ├── 故障排除
    ├── 发布流程
    └── 本地与 CI 校验一致
```

---

## 二、优化目标

### 2.1 视觉样式优化

1. **配色方案调整**
   - 评估 docs.openclaw.ai 的配色风格
   - 调整 primary/accent 颜色
   - 优化暗色模式配色

2. **品牌元素**
   - 添加项目 Logo（SVG 格式）
   - 添加 Favicon
   - 添加社交卡片（Open Graph）

3. **自定义样式**
   - 启用 extra.css
   - 调整页面布局宽度
   - 优化代码块样式
   - 添加自定义组件样式（徽章、卡片等）

### 2.2 内容结构优化

1. **首页改进**
   - 设计引人注目的 Hero 区域
   - 添加特性亮点展示
   - 添加快速入门卡片
   - 添加统计数据展示

2. **导航重组**
   - 按用户旅程重新组织
   - 添加"教程"分类
   - 添加"高级主题"分类
   - 添加版本说明入口

3. **内容增强**
   - 添加代码示例
   - 添加架构图
   - 添加常见问题 FAQ
   - 添加变更日志页面

---

## 三、实施步骤

### Phase 1: 基础视觉优化

**步骤 1.1: 配置品牌资源**

```yaml
# docs/mkdocs.yml
theme:
  name: material
  logo: assets/logo.svg
  favicon: assets/favicon.png
  # ...
```

任务:
- [ ] 创建 `docs/assets/` 目录
- [ ] 设计或获取 Logo（SVG）
- [ ] 创建 Favicon（多尺寸 PNG + ICO）
- [ ] 更新 mkdocs.yml 配置

**步骤 1.2: 优化配色方案**

```yaml
# docs/mkdocs.yml
theme:
  palette:
    # 亮色模式
    - scheme: default
      primary: deep purple  # 或参考目标站点
      accent: cyan
      toggle:
        icon: material/brightness-7
        name: 切换到暗色模式
    # 暗色模式
    - scheme: slate
      primary: deep purple
      accent: cyan
      toggle:
        icon: material/brightness-4
        name: 切换到亮色模式
```

任务:
- [ ] 分析目标网站配色
- [ ] 选择合适的 Material 颜色
- [ ] 更新配色配置
- [ ] 测试暗色/亮色模式切换

**步骤 1.3: 启用自定义样式**

```css
/* docs/stylesheets/extra.css */

/* 页面布局 */
.md-content__inner {
  max-width: 1000px;
}

/* Hero 区域 */
.md-typeset .hero {
  margin: -1.5rem -1.5rem 1.5rem;
  padding: 3rem 1.5rem;
  background: linear-gradient(135deg, var(--md-primary-fg-color), var(--md-accent-fg-color));
  color: white;
}

/* 特性卡片 */
.feature-card {
  border: 1px solid var(--md-default-fg-color--lightest);
  border-radius: 8px;
  padding: 1rem;
  margin: 1rem 0;
}
```

任务:
- [ ] 编写自定义 CSS 样式
- [ ] 添加 Hero 区域样式
- [ ] 添加卡片组件样式
- [ ] 优化代码块样式

### Phase 2: 首页重新设计

**步骤 2.1: 创建首页 Hero 区域**

```markdown
<!-- docs/README.md 开头 -->

<style>
.hero { ... }
</style>

<div class="hero">
  <h1>PyClaw</h1>
  <p>多通道 AI 网关 — 将 AI Agent 连接到 25+ 消息平台</p>
  <a href="quickstart.md" class="md-button md-button--primary">
    快速开始
  </a>
  <a href="https://github.com/chensaics/openclaw-py" class="md-button">
    GitHub
  </a>
</div>
```

任务:
- [ ] 设计首页 Hero 布局
- [ ] 添加行动号召按钮
- [ ] 添加特性亮点网格

**步骤 2.2: 添加特性展示**

```markdown
## 特性

<div class="grid cards" markdown>

- :material-robot: **Agent Runtime**
  ---
  多提供商 LLM 流式输出、20+ 内置工具、MCP 支持

- :material-message: **25+ 消息通道**
  ---
  Telegram、Discord、Slack、WhatsApp、钉钉、飞书...

- :material-brain: **记忆系统**
  ---
  上下文压缩、对话持久化、向量搜索

</div>
```

任务:
- [ ] 创建特性卡片组件
- [ ] 添加图标和描述
- [ ] 设计响应式网格布局

**步骤 2.3: 添加快速入门指引**

```markdown
## 快速入门

```bash
# 一键安装
curl -fsSL https://raw.githubusercontent.com/chensaics/openclaw-py/master/scripts/install.sh | bash

# 配置
pyclaw setup --wizard

# 开始对话
pyclaw agent "Hello!"
\```
```

任务:
- [ ] 添加简化的安装指引
- [ ] 添加最小配置示例
- [ ] 添加下一步链接

### Phase 3: 导航重组

**步骤 3.1: 重新组织导航结构**

```yaml
# docs/mkdocs.yml
nav:
  - 首页: README.md
  - 入门:
      - 快速开始: quickstart.md
      - 安装指南: install.md
      - 配置说明: configuration.md
  - 教程:
      - 基础对话: tutorials/basic-chat.md
      - 添加通道: tutorials/add-channel.md
      - 使用工具: tutorials/use-tools.md
  - 核心概念:
      - 概念总览: concepts.md
      - 架构设计: architecture.md
  - API 参考:
      - API 总览: api-reference.md
      - WebSocket RPC: api/websocket.md
      - HTTP API: api/http.md
  - 高级主题:
      - 插件开发: plugin-development.md
      - 部署指南: deployment.md
      - 安全配置: security.md
  - 帮助:
      - 故障排除: troubleshooting.md
      - FAQ: faq.md
      - 变更日志: changelog.md
```

任务:
- [ ] 创建新的导航结构
- [ ] 创建缺失的页面文件
- [ ] 更新现有页面内容

**步骤 3.2: 添加社交链接和元数据**

```yaml
# docs/mkdocs.yml
extra:
  social:
    - icon: fontawesome/brands/github
      link: https://github.com/chensaics/openclaw-py
      name: GitHub
    - icon: fontawesome/brands/discord
      link: https://discord.gg/xxx
      name: Discord
  analytics:
    feedback:
      title: 这篇文档有帮助吗？
      ratings:
        - icon: material/thumb-up-outline
          name: 有帮助
          data: 1
          note: 感谢反馈！
        - icon: material/thumb-down-outline
          name: 没帮助
          data: 0
          note: 感谢反馈，我们会改进！
```

任务:
- [ ] 配置社交链接
- [ ] 启用反馈功能
- [ ] 配置 Open Graph 元数据

### Phase 4: 内容增强

**步骤 4.1: 创建 FAQ 页面**

```markdown
# 常见问题

## 安装问题

### 安装失败怎么办？
...

## 配置问题

### 如何配置多个 LLM 提供商？
...
```

任务:
- [ ] 收集常见问题
- [ ] 创建 FAQ 页面
- [ ] 添加交叉引用链接

**步骤 4.2: 创建变更日志页面**

```markdown
# 变更日志

所有重要变更都记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)。

## [0.1.4] - 2026-03-22

### 新增
- ...

### 变更
- ...

### 修复
- ...
```

任务:
- [ ] 创建 CHANGELOG.md
- [ ] 整合 release_notes 内容
- [ ] 添加版本链接

---

## 四、文件变更清单

### 新增文件

```
docs/
├── assets/
│   ├── logo.svg
│   ├── favicon.png
│   └── favicon.ico
├── tutorials/
│   ├── basic-chat.md
│   ├── add-channel.md
│   └── use-tools.md
├── api/
│   ├── websocket.md
│   └── http.md
├── faq.md
├── changelog.md
└── security.md
```

### 修改文件

| 文件 | 变更内容 |
|------|----------|
| `docs/mkdocs.yml` | 配置优化（配色、logo、导航、插件） |
| `docs/stylesheets/extra.css` | 自定义样式 |
| `docs/README.md` | 首页重新设计 |

---

## 五、验收标准

### 视觉验收

- [ ] Logo 和 Favicon 正确显示
- [ ] 亮色/暗色模式切换流畅
- [ ] 配色与目标风格一致
- [ ] 响应式布局在移动端正常
- [ ] 代码块语法高亮正确

### 内容验收

- [ ] 导航结构清晰
- [ ] 所有链接有效
- [ ] 首页突出核心价值
- [ ] 快速入门路径明确
- [ ] FAQ 覆盖常见问题

### 技术验收

- [ ] `mkdocs build --strict` 通过
- [ ] 无控制台错误
- [ ] 页面加载速度正常
- [ ] SEO 元数据正确

---

## 六、时间估算

| Phase | 预计工作量 |
|-------|-----------|
| Phase 1: 基础视觉优化 | 中等 |
| Phase 2: 首页重新设计 | 中等 |
| Phase 3: 导航重组 | 较小 |
| Phase 4: 内容增强 | 较大 |

建议按 Phase 顺序实施，每个 Phase 完成后验证部署效果。

---

## 七、风险与缓解

| 风险 | 缓解措施 |
|------|----------|
| Logo 设计资源不足 | 可先使用文字 Logo，后续替换 |
| 内容迁移工作量大 | 分阶段进行，保持向后兼容 |
| 构建失败 | 本地测试 `mkdocs build --strict` |
| 部署延迟 | GitHub Actions 通常 1-2 分钟完成 |
