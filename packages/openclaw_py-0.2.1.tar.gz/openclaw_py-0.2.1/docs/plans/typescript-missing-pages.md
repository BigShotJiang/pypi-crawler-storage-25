# TypeScript 客户端缺失页面设计

> 创建时间：2026-04-23
> 状态：规划中
> 关联：TypeScript 迁移计划

---

## 1. 背景

迁移到 TypeScript 客户端后，CLI 保留运维/开发工具，TypeScript 客户端负责用户交互界面。已有页面：Dashboard、Chat、Agents、Sessions、Channels、Settings。

需补充 5 个页面：**Models、Auth、Devices、Skills、MCP**。

---

## 2. 页面规划

### 2.1 Models 页面

| 属性 | 值 |
|------|-----|
| 路由 | `/models` |
| 复杂度 | 低 |
| 数据来源 | `models.list` / `models.status` RPC |

**功能：**
- 展示可用模型列表（名称、provider、别名）
- 显示模型状态（在线/离线/错误）
- 显示费用估算（如有）
- 能力标签（vision、tools、streaming 等）

**UI 组件：**
- 复用 `PageHeader`、`EmptyState`、`StatusChip`
- 新增 `ModelCard` 组件

**REST 端点需求：**
```
GET  /api/v1/models          → ModelListResponse
GET  /api/v1/models/:id      → ModelResponse
```

---

### 2.2 Auth 页面

| 属性 | 值 |
|------|-----|
| 路由 | 集成到 `/settings` 作为子标签页 |
| 复杂度 | 中 |
| 数据来源 | `auth.status` / `auth.login` / `auth.logout` RPC |

**功能：**
- 展示当前认证状态（已登录 provider）
- API Key 管理（查看、添加、删除）
- 多账号切换（如有）

**UI 组件：**
- 在 Settings 页面使用 Tabs 组件
- 新增 `AuthSettingsPanel` 子组件
- 新增 `ApiKeyCard` 组件

**REST 端点需求：**
```
GET    /api/v1/auth/status     → AuthStatusResponse
POST   /api/v1/auth/login      → { provider, api_key }
POST   /api/v1/auth/logout     → { provider }
```

---

### 2.3 Devices 页面

| 属性 | 值 |
|------|-----|
| 路由 | `/devices` |
| 复杂度 | 低 |
| 数据来源 | `devices.list` / `devices.approve` / `devices.remove` RPC |

**功能：**
- 展示已配对设备列表
- 显示待批准设备（需审批状态）
- 批准/移除设备操作

**UI 组件：**
- 复用 `PageHeader`、`EmptyState`
- 新增 `DeviceCard` 组件（含状态徽章）
- 新增 `ApprovalDialog` 组件

**REST 端点需求：**
```
GET    /api/v1/devices           → DeviceListResponse
POST   /api/v1/devices/:id/approve → void
DELETE /api/v1/devices/:id         → void
```

---

### 2.4 Skills 页面

| 属性 | 值 |
|------|-----|
| 路由 | `/skills` |
| 复杂度 | 中 |
| 数据来源 | `skills.list` / `skills.install` / `skills.run` RPC |

**功能：**
- 展示已安装技能列表
- 技能搜索/浏览（ClawHub）
- 技能安装/卸载
- 技能执行触发

**UI 组件：**
- 复用 `PageHeader`、`EmptyState`
- 新增 `SkillCard` 组件（含版本、状态）
- 新增 `SkillSearchModal` 组件
- 新增 `SkillDetailSheet` 组件

**REST 端点需求：**
```
GET    /api/v1/skills              → SkillListResponse
GET    /api/v1/skills/search       → SkillSearchResponse
POST   /api/v1/skills/install      → { skill_id }
DELETE /api/v1/skills/:id          → void
POST   /api/v1/skills/:id/run      → SkillRunResponse
```

---

### 2.5 MCP 页面

| 属性 | 值 |
|------|-----|
| 路由 | `/mcp` |
| 复杂度 | 中 |
| 数据来源 | `mcp.status` / `mcp.listTools` RPC |

**功能：**
- 展示已连接 MCP 服务器列表
- 显示各服务器提供的工具
- 工具详情查看（输入 schema）
- 服务器状态（连接/断开）

**UI 组件：**
- 复用 `PageHeader`、`EmptyState`、`StatusChip`
- 新增 `McpServerCard` 组件
- 新增 `ToolList` 组件（可折叠）
- 新增 `ToolDetailSheet` 组件

**REST 端点需求：**
```
GET /api/v1/mcp               → McpStatusResponse
GET /api/v1/mcp/:server/tools → ToolListResponse
```

---

## 3. 路由映射总表

| 路由 | 页面组件 | 数据来源 | 状态 |
|------|----------|----------|------|
| `/` | 重定向到 `/dashboard` | - | ✅ 已实现 |
| `/dashboard` | `DashboardPage` | 多源汇总 | ✅ 已实现 |
| `/chat` | `ChatPage` | WebSocket | ✅ 已实现 |
| `/agents` | `AgentsPage` | `agents.list` | ✅ 已实现 |
| `/agents/[id]` | `AgentDetailPage` | `agents.get` | ✅ 已实现 |
| `/sessions` | `SessionsPage` | `sessions.list` | ✅ 已实现 |
| `/channels` | `ChannelsPage` | `channels.list` | ✅ 已实现 |
| `/settings` | `SettingsPage` | `config.get` | ✅ 已实现 |
| `/models` | `ModelsPage` | `models.list` | 📋 待实现 |
| `/devices` | `DevicesPage` | `devices.list` | 📋 待实现 |
| `/skills` | `SkillsPage` | `skills.list` | 📋 待实现 |
| `/mcp` | `McpPage` | `mcp.status` | 📋 待实现 |
| `/settings` Auth Tab | `AuthSettingsPanel` | `auth.status` | 📋 待实现 |

---

## 4. 侧边栏导航更新

更新 `apps/web/components/sidebar.tsx`：

```typescript
const navItems = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/chat', icon: MessageSquare, label: 'Chat' },
  { href: '/agents', icon: Bot, label: 'Agents' },
  { href: '/sessions', icon: FileText, label: 'Sessions' },
  { href: '/channels', icon: Radio, label: 'Channels' },
  { href: '/skills', icon: Sparkles, label: 'Skills' },        // 新增
  { href: '/models', icon: Cpu, label: 'Models' },            // 新增
  { href: '/mcp', icon: Puzzle, label: 'MCP' },               // 新增
  { href: '/devices', icon: Smartphone, label: 'Devices' },   // 新增
  { href: '/settings', icon: Settings, label: 'Settings' },
];
```

---

## 5. 实现优先级

### Phase 1：基础设施（低复杂度）
1. **Models** — 类型已存在于 `config.ts`，只需新增页面和 REST 端点
2. **Devices** — 简单 CRUD，复用现有组件

### Phase 2：中等复杂度
3. **Skills** — 需要搜索功能和详细视图
4. **MCP** — 需要工具列表展示

### Phase 3：集成到现有页面
5. **Auth** — 作为 Settings 子标签页实现

---

## 6. 后端 REST 端点任务

| 端点 | 方法 | 对应 RPC | 状态 |
|------|------|----------|------|
| `/api/v1/models` | GET | `models.list` | 📋 待实现 |
| `/api/v1/models/:id` | GET | `models.status` | 📋 待实现 |
| `/api/v1/auth/status` | GET | `auth.status` | 📋 待实现 |
| `/api/v1/auth/login` | POST | `auth.login` | 📋 待实现 |
| `/api/v1/auth/logout` | POST | `auth.logout` | 📋 待实现 |
| `/api/v1/devices` | GET | `devices.list` | 📋 待实现 |
| `/api/v1/devices/:id/approve` | POST | `devices.approve` | 📋 待实现 |
| `/api/v1/devices/:id` | DELETE | `devices.remove` | 📋 待实现 |
| `/api/v1/skills` | GET | `skills.list` | 📋 待实现 |
| `/api/v1/skills/search` | GET | `skills.search` | 📋 待实现 |
| `/api/v1/skills/install` | POST | `skills.install` | 📋 待实现 |
| `/api/v1/skills/:id` | DELETE | `skills.remove` | 📋 待实现 |
| `/api/v1/skills/:id/run` | POST | `skills.run` | 📋 待实现 |
| `/api/v1/mcp` | GET | `mcp.status` | 📋 待实现 |
| `/api/v1/mcp/:server/tools` | GET | `mcp.listTools` | 📋 待实现 |

---

## 7. 类型定义任务

在 `packages/shared/src/types/` 新增：

- `model.ts` — Model、ModelListResponse、ModelResponse
- `auth.ts` — AuthStatus、AuthProvider
- `device.ts` — Device、DeviceListResponse
- `skill.ts` — Skill、SkillListResponse、SkillSearchResponse
- `mcp.ts` — McpServer、Tool、ToolListResponse

---

## 8. 文件结构

### 前端新增文件

```
apps/web/app/models/page.tsx
apps/web/app/devices/page.tsx
apps/web/app/skills/page.tsx
apps/web/app/mcp/page.tsx
apps/web/components/auth-settings-panel.tsx

packages/shared/src/types/model.ts
packages/shared/src/types/auth.ts
packages/shared/src/types/device.ts
packages/shared/src/types/skill.ts
packages/shared/src/types/mcp.ts

packages/ui/src/components/model-card.tsx
packages/ui/src/components/device-card.tsx
packages/ui/src/components/skill-card.tsx
packages/ui/src/components/mcp-server-card.tsx
packages/ui/src/components/tool-list.tsx
```

### 后端新增文件

```
src/pyclaw/gateway/rest/models.py      # 模型 REST 端点
src/pyclaw/gateway/rest/auth.py        # 认证 REST 端点
src/pyclaw/gateway/rest/devices.py      # 设备 REST 端点
src/pyclaw/gateway/rest/skills.py       # 技能 REST 端点
src/pyclaw/gateway/rest/mcp.py          # MCP REST 端点
src/pyclaw/gateway/rest/models/model.py # Pydantic 模型
src/pyclaw/gateway/rest/models/auth.py
src/pyclaw/gateway/rest/models/device.py
src/pyclaw/gateway/rest/models/skill.py
src/pyclaw/gateway/rest/models/mcp.py
```
