# PyClaw 智能体能力增强方案

> 分析日期: 2026-05-07
> 目标: 聚焦具体功能增强，提升智能体协作和约束能力

---

## 一、现有能力盘点

### 1.1 已具备的核心模块

| 模块 | 路径 | 功能 | 成熟度 |
|------|------|------|:------:|
| Runner | `agents/runner.py` | 核心执行循环 | ⭐⭐⭐⭐ |
| Runtime | `agents/runtime.py` | 统一运行时 | ⭐⭐⭐⭐ |
| SubagentManager | `agents/subagents/manager.py` | 子代理管理 | ⭐⭐⭐⭐ |
| CollaborationEngine | `agents/collaboration/` | 多代理协作 | ⭐⭐⭐ |
| OrchestrationEngine | `agents/orchestration/` | 编排引擎 | ⭐⭐⭐ |
| SessionManager | `agents/session.py` | 会话管理 | ⭐⭐⭐⭐ |
| Planner | `agents/planner.py` | 任务规划 | ⭐⭐⭐ |

### 1.2 已支持的协作模式

```python
# 来自 multiagent/types.py
class CollaborationModeType(str, Enum):
    CUSTOM_AGENT = "custom_agent"
    DYNAMIC_DECOMPOSE = "dynamic_decompose"
    FORK_SWARM = "fork_swarm"
    COORDINATOR_WORKER = "coordinator_worker"
    PIPELINE = "pipeline"
    HYBRID = "hybrid"
```

---

## 二、需要增强的功能能力

### 🎯 P0: 核心执行能力增强

#### 2.1 Agent 模式系统（借鉴 DeepSeek-TUI）

**现状分析:**
- PyClaw 有 `TrustLevel` 枚举（FULL/STANDARD/RESTRICTED/SANDBOX）
- 但缺少**执行模式**的概念
- 审批逻辑分散，不够系统

**增强方案:**

```python
# src/pyclaw/agents/modes.py (新增)
from enum import Enum
from dataclasses import dataclass
from typing import List, Optional

class ExecutionMode(str, Enum):
    """智能体执行模式"""
    
    PLAN = "plan"       # 只读探索，规划先行
    AGENT = "agent"     # 交互模式，工具审批
    YOLO = "yolo"       # 自动审批，信任环境
    
    def allows_write(self) -> bool:
        """是否允许写入操作"""
        return self != ExecutionMode.PLAN
    
    def allows_shell(self) -> bool:
        """是否允许 Shell 执行"""
        return self == ExecutionMode.YOLO or self == ExecutionMode.AGENT
    
    def requires_approval(self) -> bool:
        """是否需要审批"""
        return self == ExecutionMode.AGENT
    
    def get_allowed_tool_categories(self) -> List[str]:
        """获取允许的工具类别"""
        if self == ExecutionMode.PLAN:
            return ["read", "search", "analyze"]
        elif self == ExecutionMode.AGENT:
            return ["read", "search", "analyze", "write", "shell"]
        else:  # YOLO
            return ["read", "search", "analyze", "write", "shell", "system"]

@dataclass
class ModeConfig:
    """模式配置"""
    mode: ExecutionMode = ExecutionMode.AGENT
    auto_approve_commands: List[str] = None  # 自动审批的命令列表
    auto_approve_tools: List[str] = None      # 自动审批的工具列表
    trust_workspace: bool = False             # 是否信任工作区
    
    def should_auto_approve(self, tool_name: str, action: str) -> bool:
        """判断是否自动审批"""
        if self.mode == ExecutionMode.YOLO:
            return True
        
        if self.auto_approve_tools and tool_name in self.auto_approve_tools:
            return True
        
        if self.auto_approve_commands and action in self.auto_approve_commands:
            return True
        
        return False
```

**集成位置:** `runner.py` 的工具执行逻辑

---

#### 2.2 User Memory 系统（借鉴 DeepSeek-TUI）

**现状分析:**
- PyClaw 有 `MemoryProvider` 但聚焦对话记忆
- 缺少**跨会话用户偏好**持久化
- 无快速记忆注入机制

**增强方案:**

```python
# src/pyclaw/agents/memory/user_memory.py (新增)
from pathlib import Path
from datetime import datetime
from typing import Optional
from dataclasses import dataclass

@dataclass
class UserMemoryConfig:
    enabled: bool = False
    path: Path = None
    max_size_kb: int = 100

class UserMemory:
    """跨会话用户偏好记忆"""
    
    def __init__(self, config: UserMemoryConfig = None):
        self.config = config or UserMemoryConfig()
        self.path = self.config.path or Path.home() / ".pyclaw" / "memory.md"
        self._ensure_exists()
    
    def _ensure_exists(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("# User Memory\n\n")
    
    def load(self) -> str:
        """加载记忆内容"""
        if not self.config.enabled:
            return ""
        
        if not self.path.exists():
            return ""
        
        content = self.path.read_text()
        
        # 大小限制
        if len(content) > self.config.max_size_kb * 1024:
            content = content[:self.config.max_size_kb * 1024]
            content += "\n\n[... truncated ...]"
        
        return content
    
    def append(self, note: str) -> None:
        """追加记忆条目"""
        if not self.config.enabled:
            return
        
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
        entry = f"- ({timestamp}) {note}\n"
        
        with open(self.path, "a") as f:
            f.write(entry)
    
    def inject_to_prompt(self, system_prompt: str) -> str:
        """将记忆注入系统提示"""
        memory = self.load()
        if not memory:
            return system_prompt
        
        memory_block = f"""<user_memory source="{self.path}">
{memory}
</user_memory>"""
        
        if system_prompt:
            return f"{memory_block}\n\n{system_prompt}"
        return memory_block

# 快速记忆命令处理
def handle_quick_memory(text: str, memory: UserMemory) -> bool:
    """处理 # remember that... 格式的快速记忆"""
    if text.startswith("# ") and not text.startswith("## "):
        note = text[2:].strip()
        if note.lower().startswith("remember"):
            note = note[8:].strip()  # 去掉 "remember" 前缀
        memory.append(note)
        return True
    return False
```

**集成位置:** `runtime.py` 的消息预处理

---

#### 2.3 Sub-Agent 角色分类（借鉴 DeepSeek-TUI）

**现状分析:**
- PyClaw 有 `SubagentManager` 但无角色分类
- 子代理使用通用提示词
- 输出格式不统一

**增强方案:**

```python
# src/pyclaw/agents/subagents/roles.py (新增)
from enum import Enum
from typing import List, Optional
from dataclasses import dataclass

class SubagentRole(str, Enum):
    """子代理角色分类"""
    
    GENERAL = "general"           # 灵活执行
    EXPLORE = "explore"           # 只读探索
    PLAN = "plan"                 # 分析规划
    REVIEW = "review"             # 代码审查
    IMPLEMENTER = "implementer"   # 最小修改实现
    VERIFIER = "verifier"         # 测试验证
    
    @property
    def allows_write(self) -> bool:
        return self in [SubagentRole.GENERAL, SubagentRole.IMPLEMENTER]
    
    @property
    def allows_shell(self) -> bool:
        return self not in [SubagentRole.REVIEW]
    
    def get_system_prompt(self) -> str:
        """获取角色专用系统提示"""
        prompts = {
            SubagentRole.EXPLORE: """你是探索代理，负责只读遍历代码库。

职责：
- 快速定位相关代码
- 返回结构化发现
- 不执行写入操作

输出格式：
SUMMARY: 一段总结
EVIDENCE: path:line-range 引用
RISKS: 潜在风险点
BLOCKERS: 阻塞问题""",

            SubagentRole.REVIEW: """你是审查代理，负责评估代码质量。

职责：
- 审查变更
- 输出严重性评分
- 提供修复建议

输出格式：
SUMMARY: 总体评价
FINDINGS: [severity] 描述
RECOMMENDATIONS: 修复建议""",

            SubagentRole.IMPLEMENTER: """你是实现代理，负责最小修改实现。

职责：
- 执行已规划的变更
- 最小化改动范围
- 验证基本功能

输出格式：
SUMMARY: 做了什么
CHANGES: 文件列表
VERIFICATION: 验证结果""",

            SubagentRole.VERIFIER: """你是验证代理，负责测试验证。

职责：
- 运行测试
- 报告结果
- 标识失败原因

输出格式：
SUMMARY: 测试结果摘要
PASSED: 通过的测试
FAILED: 失败的测试及原因
BLOCKERS: 阻塞问题""",
        }
        return prompts.get(self, "你是一个通用子代理。")

@dataclass
class RoleConfig:
    """角色配置"""
    role: SubagentRole = SubagentRole.GENERAL
    tools_enabled: List[str] = None
    tools_disabled: List[str] = None
    max_turns: int = 20
    timeout_seconds: int = 120

def get_tools_for_role(role: SubagentRole, all_tools: List) -> List:
    """根据角色过滤工具"""
    if role == SubagentRole.EXPLORE:
        # 只保留只读工具
        return [t for t in all_tools if t.name in [
            "read_file", "search_files", "grep", "list_directory",
            "web_search", "fetch_url", "analyze"
        ]]
    
    elif role == SubagentRole.REVIEW:
        return [t for t in all_tools if t.name in [
            "read_file", "search_files", "grep", "analyze"
        ]]
    
    elif role == SubagentRole.VERIFIER:
        return [t for t in all_tools if t.name in [
            "exec_shell", "read_file", "grep"
        ]]
    
    # GENERAL 和 IMPLEMENTER 使用全部工具
    return all_tools
```

**集成位置:** `subagents/manager.py` 的 `_filter_tools` 方法

---

### 🎯 P1: 协作能力增强

#### 2.4 工作区快照（借鉴 DeepSeek-TUI）

**现状分析:**
- PyClaw 有 `SessionCheckpoint` 但聚焦会话状态
- 缺少工作区文件快照
- 无 `/restore` 恢复能力

**增强方案:**

```python
# src/pyclaw/agents/snapshots.py (新增)
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Optional
import subprocess
import shutil

class WorkspaceSnapshot:
    """工作区快照管理"""
    
    def __init__(self, workspace: Path, storage_dir: Path = None):
        self.workspace = workspace
        self.storage_dir = storage_dir or Path.home() / ".pyclaw" / "snapshots"
        self.project_hash = hashlib.md5(str(workspace).encode()).hexdigest()[:8]
        self.snapshot_dir = self.storage_dir / self.project_hash
    
    def take_snapshot(self, turn_id: str, phase: str) -> str:
        """创建快照
        
        Args:
            turn_id: 会话轮次 ID
            phase: "pre" 或 "post"
        """
        snapshot_path = self.snapshot_dir / f"{phase}-{turn_id}"
        snapshot_path.mkdir(parents=True, exist_ok=True)
        
        # 初始化 git 仓库（如果不存在）
        git_dir = snapshot_path / ".git"
        if not git_dir.exists():
            subprocess.run(
                ["git", "init"],
                cwd=str(snapshot_path),
                capture_output=True
            )
            subprocess.run(
                ["git", "config", "user.email", "pyclaw@local"],
                cwd=str(snapshot_path),
                capture_output=True
            )
            subprocess.run(
                ["git", "config", "user.name", "PyClaw"],
                cwd=str(snapshot_path),
                capture_output=True
            )
        
        # 复制工作区文件
        for item in self.workspace.iterdir():
            if item.name.startswith('.'):
                continue
            dest = snapshot_path / item.name
            if item.is_dir():
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(item, dest)
            else:
                shutil.copy2(item, dest)
        
        # Git 提交
        subprocess.run(
            ["git", "add", "-A"],
            cwd=str(snapshot_path),
            capture_output=True
        )
        subprocess.run(
            ["git", "commit", "-m", f"Snapshot {phase}-{turn_id}"],
            cwd=str(snapshot_path),
            capture_output=True
        )
        
        return str(snapshot_path)
    
    def restore(self, turn_id: str, phase: str = "pre") -> bool:
        """恢复到指定快照"""
        snapshot_path = self.snapshot_dir / f"{phase}-{turn_id}"
        
        if not snapshot_path.exists():
            return False
        
        # 检出快照版本
        subprocess.run(
            ["git", "checkout", "-f", "HEAD"],
            cwd=str(snapshot_path),
            capture_output=True
        )
        
        # 复制回工作区
        for item in snapshot_path.iterdir():
            if item.name == ".git":
                continue
            dest = self.workspace / item.name
            if item.is_dir():
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(item, dest)
            else:
                shutil.copy2(item, dest)
        
        return True
    
    def list_snapshots(self) -> list:
        """列出所有快照"""
        if not self.snapshot_dir.exists():
            return []
        
        snapshots = []
        for path in sorted(self.snapshot_dir.iterdir()):
            if path.is_dir() and '-' in path.name:
                phase, turn_id = path.name.split('-', 1)
                snapshots.append({
                    'turn_id': turn_id,
                    'phase': phase,
                    'path': str(path),
                    'created': datetime.fromtimestamp(path.stat().st_mtime)
                })
        
        return snapshots
    
    def prune_old_snapshots(self, max_age_days: int = 7) -> int:
        """清理过期快照"""
        from datetime import timedelta
        
        cutoff = datetime.now() - timedelta(days=max_age_days)
        pruned = 0
        
        for snapshot in self.list_snapshots():
            if snapshot['created'] < cutoff:
                shutil.rmtree(snapshot['path'])
                pruned += 1
        
        return pruned
```

**集成位置:** `runner.py` 的 `_agent_loop` 方法前后调用

---

#### 2.5 LSP 诊断钩子（借鉴 DeepSeek-TUI）

**现状分析:**
- PyClaw 无 LSP 集成
- 编辑后无自动诊断
- 需要用户手动验证

**增强方案:**

```python
# src/pyclaw/agents/lsp/manager.py (新增)
from typing import Dict, List, Optional
from dataclasses import dataclass
from pathlib import Path
import asyncio
import subprocess

@dataclass
class Diagnostic:
    file: str
    line: int
    column: int
    severity: str  # "error" | "warning" | "info"
    message: str

class LSPManager:
    """LSP 诊断管理"""
    
    DEFAULT_SERVERS = {
        "python": ["pyright-langserver", "--stdio"],
        "typescript": ["typescript-language-server", "--stdio"],
        "rust": ["rust-analyzer"],
        "go": ["gopls", "serve"],
        "java": ["jdtls"],
    }
    
    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.servers: Dict[str, subprocess.Process] = {}
    
    async def get_diagnostics(
        self, 
        file_path: str, 
        language: str
    ) -> List[Diagnostic]:
        """获取文件诊断"""
        if not self.enabled:
            return []
        
        # 简化实现：直接运行 linter
        diagnostics = []
        
        if language == "python":
            result = await self._run_command(
                ["ruff", "check", "--output-format=json", file_path]
            )
            if result:
                diagnostics.extend(self._parse_ruff_output(result, file_path))
        
        elif language in ["typescript", "javascript"]:
            result = await self._run_command(
                ["npx", "eslint", "--format=json", file_path]
            )
            if result:
                diagnostics.extend(self._parse_eslint_output(result, file_path))
        
        return diagnostics
    
    async def _run_command(self, cmd: List[str]) -> Optional[str]:
        """运行命令"""
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL
            )
            stdout, _ = await asyncio.wait_for(
                proc.communicate(),
                timeout=10
            )
            return stdout.decode() if stdout else None
        except Exception:
            return None
    
    def _parse_ruff_output(self, output: str, file_path: str) -> List[Diagnostic]:
        """解析 ruff 输出"""
        import json
        
        diagnostics = []
        try:
            for item in json.loads(output):
                diagnostics.append(Diagnostic(
                    file=file_path,
                    line=item.get('location', {}).get('row', 1),
                    column=item.get('location', {}).get('column', 1),
                    severity='error' if item.get('fix') else 'warning',
                    message=item.get('message', '')
                ))
        except Exception:
            pass
        
        return diagnostics
    
    def _parse_eslint_output(self, output: str, file_path: str) -> List[Diagnostic]:
        """解析 eslint 输出"""
        import json
        
        diagnostics = []
        try:
            data = json.loads(output)
            for result in data:
                for msg in result.get('messages', []):
                    diagnostics.append(Diagnostic(
                        file=file_path,
                        line=msg.get('line', 1),
                        column=msg.get('column', 1),
                        severity=msg.get('severity', 1) == 2 and 'error' or 'warning',
                        message=msg.get('message', '')
                    ))
        except Exception:
            pass
        
        return diagnostics
    
    def format_for_context(self, diagnostics: List[Diagnostic]) -> str:
        """格式化为上下文注入"""
        if not diagnostics:
            return ""
        
        lines = ["<lsp_diagnostics>"]
        for d in diagnostics:
            lines.append(f"  [{d.severity}] {d.file}:{d.line}:{d.column}")
            lines.append(f"    {d.message}")
        lines.append("</lsp_diagnostics>")
        
        return "\n".join(lines)

# 编辑后钩子
async def post_edit_lsp_hook(
    file_path: str, 
    lsp_manager: LSPManager
) -> str:
    """编辑后运行 LSP 诊断"""
    
    # 检测语言
    suffix = Path(file_path).suffix.lower()
    language_map = {
        '.py': 'python',
        '.ts': 'typescript',
        '.tsx': 'typescript',
        '.js': 'javascript',
        '.jsx': 'javascript',
        '.rs': 'rust',
        '.go': 'go',
    }
    
    language = language_map.get(suffix)
    if not language:
        return ""
    
    diagnostics = await lsp_manager.get_diagnostics(file_path, language)
    return lsp_manager.format_for_context(diagnostics)
```

**集成位置:** `runner.py` 的工具执行后

---

#### 2.6 持久化任务队列（借鉴 DeepSeek-TUI）

**现状分析:**
- PyClaw 有 `SessionRecovery` 但功能有限
- 缺少后台任务持久化
- 无重启恢复机制

**增强方案:**

```python
# src/pyclaw/agents/tasks/queue.py (新增)
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional, List
from pathlib import Path
import json
import asyncio

class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"
    INTERRUPTED = "interrupted"

@dataclass
class DurableTask:
    id: str
    name: str
    prompt: str
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 3
    
    SCHEMA_VERSION = 1
    
    def to_dict(self) -> dict:
        return {
            "schema_version": self.SCHEMA_VERSION,
            "id": self.id,
            "name": self.name,
            "prompt": self.prompt,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result": self.result,
            "error": self.error,
            "retry_count": self.retry_count,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'DurableTask':
        return cls(
            id=data['id'],
            name=data['name'],
            prompt=data['prompt'],
            status=TaskStatus(data['status']),
            created_at=datetime.fromisoformat(data['created_at']),
            started_at=datetime.fromisoformat(data['started_at']) if data.get('started_at') else None,
            completed_at=datetime.fromisoformat(data['completed_at']) if data.get('completed_at') else None,
            result=data.get('result'),
            error=data.get('error'),
            retry_count=data.get('retry_count', 0),
        )

class DurableTaskQueue:
    """持久化任务队列"""
    
    def __init__(self, storage_dir: Path = None):
        self.storage_dir = storage_dir or Path.home() / ".pyclaw" / "tasks"
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.queue_file = self.storage_dir / "queue.json"
        self._lock = asyncio.Lock()
    
    async def enqueue(self, task: DurableTask) -> None:
        """入队并持久化"""
        async with self._lock:
            task.status = TaskStatus.PENDING
            self._persist(task)
    
    async def mark_running(self, task_id: str) -> bool:
        """标记为运行中"""
        async with self._lock:
            task = self._load(task_id)
            if not task or task.status not in [TaskStatus.PENDING, TaskStatus.INTERRUPTED]:
                return False
            
            task.status = TaskStatus.RUNNING
            task.started_at = datetime.utcnow()
            self._persist(task)
            return True
    
    async def mark_completed(self, task_id: str, result: Any = None) -> bool:
        """标记为完成"""
        async with self._lock:
            task = self._load(task_id)
            if not task:
                return False
            
            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()
            task.result = result
            self._persist(task)
            return True
    
    async def mark_failed(self, task_id: str, error: str) -> bool:
        """标记为失败"""
        async with self._lock:
            task = self._load(task_id)
            if not task:
                return False
            
            task.status = TaskStatus.FAILED
            task.completed_at = datetime.utcnow()
            task.error = error
            self._persist(task)
            return True
    
    async def recover_interrupted(self) -> List[DurableTask]:
        """恢复被中断的任务"""
        interrupted = []
        
        for task_file in self.storage_dir.glob("task-*.json"):
            try:
                data = json.loads(task_file.read_text())
                task = DurableTask.from_dict(data)
                
                if task.status == TaskStatus.RUNNING:
                    task.status = TaskStatus.INTERRUPTED
                    self._persist(task)
                    interrupted.append(task)
            except Exception:
                continue
        
        return interrupted
    
    def _persist(self, task: DurableTask) -> None:
        """持久化任务"""
        task_file = self.storage_dir / f"task-{task.id}.json"
        task_file.write_text(json.dumps(task.to_dict(), indent=2))
    
    def _load(self, task_id: str) -> Optional[DurableTask]:
        """加载任务"""
        task_file = self.storage_dir / f"task-{task_id}.json"
        if not task_file.exists():
            return None
        
        try:
            data = json.loads(task_file.read_text())
            return DurableTask.from_dict(data)
        except Exception:
            return None
    
    def list_pending(self) -> List[DurableTask]:
        """列出待处理任务"""
        tasks = []
        for task_file in self.storage_dir.glob("task-*.json"):
            try:
                data = json.loads(task_file.read_text())
                task = DurableTask.from_dict(data)
                if task.status == TaskStatus.PENDING:
                    tasks.append(task)
            except Exception:
                continue
        return tasks
```

**集成位置:** `session_recovery.py` 扩展

---

### 🎯 P2: 约束与安全增强

#### 2.7 执行策略引擎

**现状分析:**
- PyClaw 有 `TrustLevel` 但粒度不够
- 缺少细粒度权限控制
- 无策略配置文件

**增强方案:**

```python
# src/pyclaw/agents/policy/engine.py (新增)
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Callable
from enum import Enum
from pathlib import Path
import re

class PermissionAction(Enum):
    ALLOW = "allow"
    DENY = "deny"
    ASK = "ask"  # 需要用户确认

@dataclass
class ToolPolicy:
    """工具策略"""
    tool_name: str
    action: PermissionAction = PermissionAction.ASK
    conditions: Dict = field(default_factory=dict)
    
    def evaluate(self, context: dict) -> PermissionAction:
        """评估策略"""
        if self.action == PermissionAction.ALLOW:
            return PermissionAction.ALLOW
        
        if self.action == PermissionAction.DENY:
            return PermissionAction.DENY
        
        # 检查条件
        if self.conditions:
            for key, pattern in self.conditions.items():
                value = context.get(key, "")
                if isinstance(pattern, str) and not re.match(pattern, str(value)):
                    return PermissionAction.DENY
        
        return self.action

@dataclass
class ExecutionPolicy:
    """执行策略"""
    
    # Shell 命令策略
    shell_mode: str = "approval"  # "approval" | "auto" | "disabled"
    auto_approve_commands: List[str] = field(default_factory=lambda: [
        "ls", "cat", "head", "tail", "grep", "find",
        "git status", "git log", "git diff",
        "npm list", "pip list"
    ])
    deny_commands: List[str] = field(default_factory=lambda: [
        "rm -rf /", "sudo rm", "mkfs",
        "dd if=", "> /dev/sd"
    ])
    
    # 文件操作策略
    file_write_mode: str = "approval"  # "approval" | "auto"
    protected_paths: List[str] = field(default_factory=lambda: [
        "/etc", "/System", "~/.ssh", "~/.gnupg"
    ])
    
    # 网络策略
    network_mode: str = "approval"  # "approval" | "auto" | "disabled"
    allowed_domains: List[str] = field(default_factory=list)
    blocked_domains: List[str] = field(default_factory=list)
    
    # 工具策略
    tool_policies: Dict[str, ToolPolicy] = field(default_factory=dict)
    
    def check_shell_command(self, command: str) -> PermissionAction:
        """检查 Shell 命令"""
        if self.shell_mode == "disabled":
            return PermissionAction.DENY
        
        if self.shell_mode == "auto":
            return PermissionAction.ALLOW
        
        # 检查拒绝列表
        for deny in self.deny_commands:
            if deny in command:
                return PermissionAction.DENY
        
        # 检查自动审批列表
        for approve in self.auto_approve_commands:
            if command.startswith(approve):
                return PermissionAction.ALLOW
        
        return PermissionAction.ASK
    
    def check_file_access(self, path: str, operation: str) -> PermissionAction:
        """检查文件访问"""
        from pathlib import Path
        
        resolved = str(Path(path).resolve())
        
        # 检查保护路径
        for protected in self.protected_paths:
            protected_resolved = str(Path(protected).expanduser().resolve())
            if resolved.startswith(protected_resolved):
                return PermissionAction.DENY
        
        if operation == "read":
            return PermissionAction.ALLOW
        
        if self.file_write_mode == "auto":
            return PermissionAction.ALLOW
        
        return PermissionAction.ASK
    
    def check_network_access(self, url: str) -> PermissionAction:
        """检查网络访问"""
        if self.network_mode == "disabled":
            return PermissionAction.DENY
        
        if self.network_mode == "auto":
            return PermissionAction.ALLOW
        
        # 解析域名
        from urllib.parse import urlparse
        domain = urlparse(url).netloc
        
        # 检查阻止列表
        for blocked in self.blocked_domains:
            if domain.endswith(blocked):
                return PermissionAction.DENY
        
        # 检查允许列表
        if self.allowed_domains:
            for allowed in self.allowed_domains:
                if domain.endswith(allowed):
                    return PermissionAction.ALLOW
            return PermissionAction.ASK
        
        return PermissionAction.ASK

class PolicyEngine:
    """策略引擎"""
    
    def __init__(self, policy: ExecutionPolicy = None):
        self.policy = policy or ExecutionPolicy()
        self._approval_handlers: Dict[str, Callable] = {}
    
    def register_approval_handler(self, category: str, handler: Callable):
        """注册审批处理器"""
        self._approval_handlers[category] = handler
    
    async def check_and_execute(
        self,
        category: str,
        action: str,
        context: dict,
        executor: Callable
    ) -> Any:
        """检查策略并执行"""
        
        # 获取策略判断
        if category == "shell":
            permission = self.policy.check_shell_command(action)
        elif category == "file":
            permission = self.policy.check_file_access(
                context.get("path", ""), 
                context.get("operation", "read")
            )
        elif category == "network":
            permission = self.policy.check_network_access(action)
        else:
            permission = PermissionAction.ASK
        
        # 根据策略执行
        if permission == PermissionAction.DENY:
            raise PermissionError(f"Action denied by policy: {action}")
        
        if permission == PermissionAction.ASK:
            handler = self._approval_handlers.get(category)
            if handler:
                approved = await handler(action, context)
                if not approved:
                    raise PermissionError(f"User denied: {action}")
        
        # 执行
        return await executor()
```

**集成位置:** 新增模块，被 `runner.py` 调用

---

## 三、实施优先级

| 优先级 | 功能 | 预估工作量 | 依赖 |
|:------:|------|:----------:|------|
| P0 | Agent 模式系统 | 2-3 天 | 无 |
| P0 | User Memory | 1-2 天 | 无 |
| P0 | Sub-Agent 角色 | 2-3 天 | 无 |
| P1 | 工作区快照 | 2-3 天 | 无 |
| P1 | LSP 诊断钩子 | 2-3 天 | 需要测试语言服务器 |
| P1 | 持久化任务队列 | 1-2 天 | 无 |
| P2 | 执行策略引擎 | 3-4 天 | 模式系统 |

---

## 四、实施路线

### Week 1: 核心模式与记忆

```
Day 1-2: Agent 模式系统
├── 新增 agents/modes.py
├── 修改 runner.py 集成模式检查
└── 添加模式切换命令

Day 3-4: User Memory
├── 新增 agents/memory/user_memory.py
├── 修改 runtime.py 注入记忆
└── 添加 CLI 命令 (pyclaw memory add/show)

Day 5: Sub-Agent 角色
├── 新增 agents/subagents/roles.py
├── 修改 SubagentManager 支持角色
└── 添加测试用例
```

### Week 2: 可靠性增强

```
Day 1-2: 工作区快照
├── 新增 agents/snapshots.py
├── 集成到 runner.py
└── 添加 /restore 命令

Day 3-4: LSP 诊断
├── 新增 agents/lsp/manager.py
├── 添加编辑后钩子
└── 测试 Python/TypeScript

Day 5: 持久化任务队列
├── 新增 agents/tasks/queue.py
├── 集成到会话恢复
└── 添加重启恢复测试
```

### Week 3: 安全与约束

```
Day 1-3: 执行策略引擎
├── 新增 agents/policy/engine.py
├── 添加策略配置文件
└── 集成到工具执行

Day 4-5: 集成测试
├── 端到端测试
├── 文档更新
└── 示例代码
```

---

## 五、关键文件变更

### 新增文件

```
src/pyclaw/agents/
├── modes.py              # Agent 模式系统
├── snapshots.py          # 工作区快照
├── policy/
│   └── engine.py         # 执行策略引擎
├── memory/
│   └── user_memory.py    # 用户记忆
├── subagents/
│   └── roles.py          # 子代理角色
├── tasks/
│   └── queue.py          # 持久化任务队列
└── lsp/
    └── manager.py        # LSP 诊断管理
```

### 修改文件

```
src/pyclaw/agents/
├── runner.py             # 集成模式/快照/LSP
├── runtime.py            # 集成用户记忆
├── subagents/manager.py  # 支持角色过滤
└── session_recovery.py   # 集成任务队列
```

---

## 六、总结

本方案聚焦于 **PyClaw 现有 Agent 架构的功能增强**，而非引入外部框架：

1. **执行能力**: 模式系统 + 用户记忆 + 角色分类
2. **可靠性**: 工作区快照 + LSP 诊断 + 任务持久化
3. **安全性**: 执行策略引擎 + 细粒度权限控制

这些增强将使 PyClaw 智能体具备：
- 更清晰的执行边界（模式系统）
- 更持久的上下文记忆（User Memory）
- 更专业的协作分工（Sub-Agent 角色）
- 更可靠的执行保障（快照 + 持久化）
- 更安全的操作约束（策略引擎）
