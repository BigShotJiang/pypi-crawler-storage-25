# Claw Memory 记忆管理系统实施计划

## 1. 概述

基于对参考项目的研究和当前项目已有组件的分析，设计一套完整的记忆管理系统，包含：
- 长对话上下文自动压缩
- 用户偏好持久化
- 知识库积累
- 对话历史完整保存

## 2. 架构设计

### 2.1 模块结构

```
src/pyclaw/memory/
├── __init__.py              # 模块入口
├── store.py                 # SQLite 存储 (已有)
├── embeddings.py            # 向量嵌入 (已有)
├── hybrid.py                # 混合检索 (已有)
├── mmr.py                   # MMR 重排序 (已有)
├── temporal_decay.py        # 时间衰减 (已有)
├── file_manager.py          # Markdown 文件管理 (已有)
├── extended.py              # 扩展嵌入提供者 (已有)
│
├── compaction/              # 🆕 上下文压缩模块
│   ├── __init__.py
│   ├── context_checker.py   # Token 计数与压缩判断
│   ├── summarizer.py        # 结构化摘要生成
│   └── tool_compactor.py    # 工具输出压缩
│
├── persistence/             # 🆕 持久化模块
│   ├── __init__.py
│   ├── dialog_store.py      # JSONL 对话存储
│   ├── long_term.py         # 长期记忆 (MEMORY.md)
│   └── daily_log.py         # 每日日志
│
├── hooks/                   # 🆕 记忆钩子
│   ├── __init__.py
│   ├── pre_reasoning.py     # 推理前钩子
│   └── post_session.py      # 会话结束钩子
│
└── types.py                 # 🆕 类型定义
```

### 2.2 数据流

```
┌─────────────────────────────────────────────────────────────────┐
│                        Agent 推理循环                            │
└─────────────────────────────────────────────────────────────────┘
         │                                    ▲
         ▼                                    │
┌─────────────────────────────────────────────────────────────────┐
│                    pre_reasoning_hook                            │
│  1. 检查上下文大小                                               │
│  2. 压缩工具输出结果                                             │
│  3. 触发异步摘要生成                                             │
└─────────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Memory Manager                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐           │
│  │ Context      │  │  Dialog      │  │  Long-term   │           │
│  │ Compactor    │  │  Store       │  │  Memory      │           │
│  └──────────────┘  └──────────────┘  └──────────────┘           │
│         │                 │                 │                    │
│         ▼                 ▼                 ▼                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐           │
│  │ Structured   │  │  JSONL       │  │  MEMORY.md   │           │
│  │ Summary      │  │  Files       │  │  + SQLite    │           │
│  └──────────────┘  └──────────────┘  └──────────────┘           │
└─────────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Memory Search                               │
│  向量检索 (0.7) + BM25 关键词 (0.3) → 混合结果                   │
└─────────────────────────────────────────────────────────────────┘
```

## 3. 核心组件设计

### 3.1 Context Checker (上下文检查器)

```python
@dataclass
class ContextCheckResult:
    needs_compaction: bool
    current_tokens: int
    reserve_tokens: int
    messages_to_compact: list[dict]  # 待压缩的消息
    preserved_messages: list[dict]   # 保留的消息

class ContextChecker:
    def __init__(self, *, max_tokens: int = 128000, reserve_ratio: float = 0.3):
        self._max_tokens = max_tokens
        self._reserve_ratio = reserve_ratio

    def check(self, messages: list[dict]) -> ContextCheckResult:
        """检查上下文是否需要压缩"""
        ...

    def estimate_tokens(self, messages: list[dict]) -> int:
        """估算消息的 token 数量"""
        ...
```

### 3.2 Summarizer (摘要生成器)

```python
@dataclass
class StructuredSummary:
    goals: list[str]           # 当前目标
    constraints: list[str]     # 约束条件
    progress: str              # 已完成进度
    decisions: list[str]       # 关键决策
    next_steps: list[str]      # 下一步行动
    key_context: list[str]     # 关键上下文

class MemorySummarizer:
    """使用 LLM 生成结构化摘要"""

    def __init__(self, model: ModelConfig, *, prompt_template: str | None = None):
        self._model = model
        self._prompt_template = prompt_template or DEFAULT_SUMMARY_PROMPT

    async def summarize(self, messages: list[dict]) -> StructuredSummary:
        """生成结构化摘要"""
        ...

    async def summarize_async(self, messages: list[dict]) -> None:
        """异步生成摘要，不阻塞主流程"""
        ...
```

### 3.3 Dialog Store (对话存储)

```python
@dataclass
class DialogEntry:
    timestamp: float
    role: str
    content: str
    tool_calls: list[dict] | None
    metadata: dict | None

class DialogStore:
    """JSONL 格式的对话持久化存储"""

    def __init__(self, workspace_dir: Path):
        self._dialog_dir = workspace_dir / "dialog"

    def append(self, entry: DialogEntry) -> None:
        """追加对话条目"""
        ...

    def read_day(self, date: date) -> list[DialogEntry]:
        """读取指定日期的对话"""
        ...

    def search(self, query: str, *, limit: int = 10) -> list[DialogEntry]:
        """在对话历史中搜索"""
        ...
```

### 3.4 Long-term Memory (长期记忆)

```python
class LongTermMemory:
    """持久化的长期记忆 (MEMORY.md + SQLite 索引)"""

    def __init__(self, workspace_dir: Path, store: MemoryStore):
        self._memory_file = workspace_dir / "MEMORY.md"
        self._store = store

    def add(self, content: str, *, category: str = "general") -> None:
        """添加长期记忆，同时更新 Markdown 和索引"""
        ...

    def search(self, query: str, *, limit: int = 10) -> list[MemoryEntry]:
        """混合检索长期记忆"""
        ...

    def update_preference(self, key: str, value: str) -> None:
        """更新用户偏好"""
        ...
```

### 3.5 Pre-reasoning Hook (推理前钩子)

```python
class MemoryPreReasoningHook:
    """在每次推理前执行的内存管理钩子"""

    def __init__(
        self,
        *,
        context_checker: ContextChecker,
        summarizer: MemorySummarizer,
        tool_compactor: ToolResultCompactor,
        dialog_store: DialogStore,
    ):
        ...

    async def __call__(self, event: HookEvent) -> None:
        """
        钩子入口点:
        1. 压缩工具输出结果
        2. 检查上下文大小
        3. 如需压缩，生成摘要并替换消息
        4. 持久化对话记录
        """
        ...
```

## 4. 文件存储布局

```
workspace/
├── MEMORY.md                    # 长期记忆：用户偏好、重要决策
├── memory/
│   ├── 2026-03-24.md           # 每日摘要日志
│   ├── 2026-03-23.md
│   └── ...
├── dialog/
│   ├── 2026-03-24.jsonl        # 原始对话记录
│   ├── 2026-03-23.jsonl
│   └── ...
├── tool_result/
│   ├── <uuid>.txt              # 长工具输出缓存
│   └── ...
└── memory.db                   # SQLite 索引数据库
```

### MEMORY.md 格式示例

```markdown
# Long-term Memory

## User Preferences

- **Language**: 中文
- **Code Style**: Google Python Style Guide
- **Preferred Framework**: FastAPI

## Key Decisions

### 2026-03-24: 使用混合存储架构
决定采用 Markdown + SQLite 混合存储，兼顾可读性和查询性能。

## Important Context

- 项目名: openclaw-py
- 主要技术栈: Python, SQLite, FTS5
```

## 5. 实施阶段

### Phase 1: 基础设施 (预计 3-4 个文件)

| 任务 | 文件 | 依赖 |
|------|------|------|
| 类型定义 | `types.py` | 无 |
| Context Checker | `compaction/context_checker.py` | types.py |
| Dialog Store | `persistence/dialog_store.py` | types.py |
| 单元测试 | `tests/pyclaw/memory/test_*.py` | 以上文件 |

### Phase 2: 核心功能 (预计 4-5 个文件)

| 任务 | 文件 | 依赖 |
|------|------|------|
| Summarizer | `compaction/summarizer.py` | Phase 1 |
| Tool Compactor | `compaction/tool_compactor.py` | Phase 1 |
| Long-term Memory | `persistence/long_term.py` | Phase 1 |
| Daily Log | `persistence/daily_log.py` | Phase 1 |
| 单元测试 | `tests/pyclaw/memory/test_*.py` | 以上文件 |

### Phase 3: 钩子集成 (预计 2-3 个文件)

| 任务 | 文件 | 依赖 |
|------|------|------|
| Pre-reasoning Hook | `hooks/pre_reasoning.py` | Phase 1-2 |
| Post-session Hook | `hooks/post_session.py` | Phase 1-2 |
| 钩子注册 | 更新 `hooks/registry.py` | 以上文件 |

### Phase 4: Agent 集成 (预计 2-3 个文件)

| 任务 | 文件 | 依赖 |
|------|------|------|
| Memory Manager | `memory/manager.py` | Phase 1-3 |
| 更新 Agent | `agents/*.py` | manager.py |
| 更新 Tools | `agents/tools/memory_tools.py` | manager.py |

### Phase 5: 测试与文档

| 任务 | 文件 |
|------|------|
| 集成测试 | `tests/integration/test_memory.py` |
| API 文档 | `docs/api-reference.md` |
| 使用指南 | `docs/memory-guide.md` |

## 6. 配置项

```yaml
# config.yaml
memory:
  # 上下文压缩
  compaction:
    enabled: true
    max_tokens: 128000
    reserve_ratio: 0.3
    min_messages_to_compact: 10

  # 摘要生成
  summary:
    enabled: true
    model: "gpt-4o-mini"  # 使用较小的模型生成摘要
    async_mode: true      # 异步生成，不阻塞主流程

  # 对话持久化
  dialog:
    enabled: true
    format: "jsonl"
    retention_days: 30

  # 长期记忆
  long_term:
    enabled: true
    file: "MEMORY.md"

  # 工具输出压缩
  tool_result:
    enabled: true
    max_length: 2000
    cache_dir: "tool_result"
```

## 7. API 设计

### Python API

```python
from pyclaw.memory import MemoryManager

# 初始化
manager = MemoryManager(
    workspace_dir=Path("./workspace"),
    config=MemoryConfig.from_yaml("config.yaml"),
)

# 添加记忆
manager.add_memory("用户偏好使用中文交流", category="preference")

# 搜索记忆
results = manager.search("用户偏好", limit=5)

# 手动触发压缩
await manager.compact_context(messages)

# 获取摘要
summary = await manager.get_session_summary()
```

### Agent Tools API

```python
# 扩展现有的 memory_tools.py

class MemoryAddTool(BaseTool):
    """手动添加一条记忆"""
    name = "memory_add"
    description = "Store an important fact, preference, or decision in long-term memory."

class MemoryUpdateTool(BaseTool):
    """更新现有记忆"""
    name = "memory_update"

class MemoryForgetTool(BaseTool):
    """遗忘/删除记忆"""
    name = "memory_forget"
```

## 8. 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| 摘要质量不高 | 信息丢失 | 使用结构化提示词 + 保留原始对话 |
| 压缩时机不当 | 上下文断裂 | 可配置的阈值 + 用户确认选项 |
| 存储空间增长 | 磁盘占用 | 自动清理过期数据 + 压缩策略 |
| 异步任务失败 | 数据不一致 | 重试机制 + 错误日志 |

## 9. 验收标准

- [ ] 长对话 (>100 条消息) 能自动压缩并保留关键信息
- [ ] 用户偏好能跨会话持久化
- [ ] 对话历史能完整保存并可检索
- [ ] 记忆搜索结果准确率 > 80%
- [ ] 压缩操作不阻塞主对话流程 (异步)
- [ ] 所有新代码有单元测试覆盖
- [ ] API 文档完整

---

**创建时间**: 2026-03-24
**预计工期**: 5-7 个工作日
**依赖**: 无外部依赖，基于现有组件扩展
