# PyClaw Prioritization Framework Recommendation

> Generated: 2026-04-17
> Method: Prioritization Advisor (Product Manager Skills)

---

## Your Context

| Dimension | Your Answer |
|-----------|-------------|
| **Product Stage** | Pre-PMF — Searching for users, experimenting |
| **Team** | Small aligned team (3-5 people) |
| **Challenge** | Build quality — Features incomplete or buggy |
| **Data** | Minimal — Few users, no structured feedback |

---

## Recommended Framework: ICE Scoring

**ICE = Impact × Confidence × Ease**

### Why ICE Fits Your Situation

| Factor | Rationale |
|--------|-----------|
| Pre-PMF stage | Need speed, not heavy scoring processes |
| Small aligned team | Can score collaboratively in one session |
| Build quality focus | Simple triage: fix vs. defer |
| Minimal data | Gut-based scoring is appropriate |

### When to Use ICE

- Weekly prioritization sessions
- Backlog triage (fix vs. defer)
- Quick consensus building

### When NOT to Use ICE

- Require rigorous justification to stakeholders
- Have rich usage data (switch to RICE)
- Need audit trail of decisions

---

## How to Implement

### Step 1: Define Scoring Criteria

| Criterion | Scale | Description |
|-----------|-------|-------------|
| **Impact** | 1-10 | How much does this improve user experience? |
| **Confidence** | 1-10 | How sure are you about the impact? |
| **Ease** | 1-10 | How easy is this to implement? (10 = easiest) |

### Step 2: Score Items Collaboratively

Gather team (even if just 2-3 people). Score each item together.

```
ICE Score = Impact × Confidence × Ease
```

**Higher score = Higher priority**

### Step 3: Triage by Score

| Score Range | Action |
|-------------|--------|
| 200-1000 | Do now (this week) |
| 50-199 | Do soon (this month) |
| <50 | Defer or drop |

---

## Applied to PyClaw: Current Priorities

Based on your status documents, here's an ICE scoring of open items:

| Item | Impact | Confidence | Ease | ICE Score | Priority |
|------|--------|------------|------|-----------|----------|
| TypeScript client recovery (core pages runnable) | 8 | 7 | 4 | 224 | 🔴 Do now |
| iOS/macOS build signing | 7 | 6 | 3 | 126 | 🟡 Do soon |
| ClawHub marketplace integration | 6 | 5 | 2 | 60 | 🟡 Do soon |
| Skill discovery TUI (`pyclaw skills browse`) | 7 | 8 | 5 | 280 | 🔴 Do now |
| Onboarding wizard improvement | 8 | 7 | 6 | 336 | 🔴 Do now |
| Channel capability matrix docs | 5 | 9 | 7 | 315 | 🔴 Do now |
| Multi-tenant isolation | 4 | 4 | 2 | 32 | ⚪ Defer |
| SSO integration | 3 | 3 | 1 | 9 | ⚪ Defer |

---

## Recommended Action Plan

### This Week (High Priority)

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Onboarding wizard improvement (ICE: 336)                 │
│    - Add guided setup flow for new users                    │
│    - Detect missing config and prompt                       │
│                                                             │
│ 2. Channel capability matrix (ICE: 315)                     │
│    - Document what each channel supports                    │
│    - Set user expectations                                  │
│                                                             │
│ 3. Skill discovery TUI (ICE: 280)                           │
│    - `pyclaw skills browse` command                         │
│    - Help users find what exists                            │
│                                                             │
│ 4. TypeScript client recovery (ICE: 224)                    │
│    - Core pages runnable                                    │
│    - Gateway API sync                                       │
└─────────────────────────────────────────────────────────────┘
```

### This Month (Medium Priority)

```
┌─────────────────────────────────────────────────────────────┐
│ 1. iOS/macOS build signing (ICE: 126)                       │
│    - Complete CI/CD pipeline                                │
│                                                             │
│ 2. ClawHub marketplace (ICE: 60)                            │
│    - Integrate with skills framework                        │
└─────────────────────────────────────────────────────────────┘
```

### Defer (Wait for More Data)

```
┌─────────────────────────────────────────────────────────────┐
│ • Multi-tenant isolation (ICE: 32)                          │
│ • SSO integration (ICE: 9)                                  │
│   → Reassess after user feedback                            │
└─────────────────────────────────────────────────────────────┘
```

---

## Focus Principle

> **Pre-PMF + Build Quality Gap = Stabilize before you scale**

Your priority order:

```
1. FIX (make existing features work reliably)
2. POLISH (improve user onboarding & discovery)
3. BUILD (complete in-progress features)
4. ADD (new features only after stability)
```

---

## Reassess When

- [ ] Product stage changes (find PMF)
- [ ] Team grows beyond 5 people
- [ ] Get structured user feedback (switch to RICE)
- [ ] Build quality gap closes (shift to growth)

---

## Alternative Framework

If ICE feels too simple, consider **Value/Effort Matrix**:

```
         HIGH VALUE
              │
   ┌──────────┼──────────┐
   │  Strategic Bets     │  Quick Wins ★
   │  (do quarterly)     │  (do now)
E  │                      │
F  ├──────────┼──────────┤
F  │  Avoid               │  Fill-ins
O  │  (don't do)          │  (if time)
R  │                      │
T   └──────────┼──────────┘
              │
         LOW VALUE
     HIGH EFFORT ←→ LOW EFFORT
```

**For PyClaw**, most items fall into:

- **Quick Wins**: Onboarding, skill discovery, docs
- **Strategic Bets**: TypeScript client, ClawHub
- **Avoid**: SSO, multi-tenant (for now)

---

## Next Steps

1. **Weekly ICE session** — 30 min to score new items
2. **Track scores** — Add to `docs/status/priorities.md`
3. **Reassess monthly** — Update as context changes

---

**Remember:** Pre-PMF means you're learning. Speed > perfection. Focus on making existing users successful before chasing new ones.
