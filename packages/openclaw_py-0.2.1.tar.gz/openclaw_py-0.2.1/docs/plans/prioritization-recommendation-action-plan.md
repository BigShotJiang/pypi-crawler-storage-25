# PyClaw Roadmap & Action Plan

> Generated: 2026-04-18
> Framework: ICE Scoring (Impact × Confidence × Ease)
> Source: prioritization-recommendation.md

---

## Executive Summary

**Context:**
- Stage: Pre-PMF (searching for users)
- Team: Small aligned (3-5 people)
- Challenge: Build quality gaps
- Data: Minimal user feedback

**Strategy:** Stabilize before you scale

```
FIX → POLISH → BUILD → ADD
```

---

## Phase Overview

| Phase | Focus | Duration | Goal |
|-------|-------|----------|------|
| **P0: Foundation** | Fix critical issues | 1-2 weeks | Stable core experience |
| **P1: Polish** | Improve discovery | 2-3 weeks | Users find & use features |
| **P2: Complete** | Finish in-progress | 3-4 weeks | All planned features work |
| **P3: Grow** | Expand & add | Ongoing | New users & features |

---

# PHASE 0: Foundation (Week 1-2)

> Goal: Make existing features work reliably for current users

---

## P0-T1: Onboarding Wizard Improvement

**ICE Score:** 336 (Impact: 8, Confidence: 7, Ease: 6)
**Priority:** 🔴 Critical
**Owner:** Claude Code
**Status:** ✅ Completed
**Effort:** 7 hours
**Completed:** 2026-04-18

### Problem Statement
New users don't have a guided setup experience. The current wizard exists but lacks validation, channel guidance, and next steps.

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P0-T1-1 | Add config validation step | 2h | ✅ Done |
| P0-T1-2 | Add channel setup step (optional) | 3h | ✅ Done |
| P0-T1-3 | Add skill discovery prompt | 1h | ✅ Done |
| P0-T1-4 | Add "first run" detection | 1h | ✅ Done |

### Detailed Specifications

#### P0-T1-1: Config Validation Step
**File:** `src/pyclaw/ui/onboarding.py`

Before showing "Complete", validate:
- [x] API key is set and valid (test with simple API call) — Implemented `_test_api_key()` with HTTP call to `/v1/models`
- [x] At least one model is configured — Implemented `_validate_model_config()`
- [x] Gateway port is available — Implemented `_check_port_available()`
- [x] Show validation status with ✅/❌ icons — Uses `ft.icons.CHECK_CIRCLE` / `ft.icons.ERROR`

```python
# Example implementation
async def validate_config(self) -> dict[str, bool]:
    results = {}
    results["api_key"] = await self._test_api_key()
    results["model"] = self._check_model_configured()
    results["port"] = self._check_port_available()
    return results
```

#### P0-T1-2: Channel Setup Step ✅
Implemented with `POPULAR_CHANNELS` constant showing icons and descriptions for Telegram, Discord, Slack, WhatsApp, iMessage.

#### P0-T1-3: Skill Discovery Prompt ✅
Implemented with `RECOMMENDED_SKILLS` constant showing repo-review, docs-sync, pdf skills with `pyclaw skills list` hint.

#### P0-T1-4: First Run Detection ✅
- [x] Check if config file exists — `is_first_run()` function
- [x] Auto-launch onboarding in UI — `_check_onboarding()` in app.py
- [x] Add `--skip-onboarding` flag — CLI flag + `PYCLAW_SKIP_ONBOARDING` env var

### Acceptance Criteria ✅
```
GIVEN: Fresh install
WHEN: User runs `pyclaw ui`
THEN: Onboarding wizard appears
AND: User can configure provider + API key
AND: Validation confirms config works
AND: User sees next steps (channels, skills)
```

---

## P0-T2: Channel Capability Matrix

**ICE Score:** 315 (Impact: 5, Confidence: 9, Ease: 7)
**Priority:** 🔴 Critical
**Owner:** Claude Code
**Status:** ✅ Completed
**Effort:** 7 hours
**Completed:** 2026-04-18

### Problem Statement
Users don't know what each channel supports. 25 channels with varying capabilities lead to confusion and unmet expectations.

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P0-T2-1 | Create capability schema | 1h | ✅ Done (existing ActionSpec) |
| P0-T2-2 | Audit all 25 channels | 3h | ✅ Done (BUILTIN_CATALOG covers 26) |
| P0-T2-3 | Add CLI command | 2h | ✅ Done |
| P0-T2-4 | Integrate with onboarding | 1h | ✅ Done |

### Detailed Specifications

#### P0-T2-1: Capability Schema ✅

Schema already existed as `ActionSpec` and `ChannelCapabilities` in `src/pyclaw/channels/base.py` and `catalog.py`. No new schema file needed.

#### P0-T2-2: Channel Audit ✅

All 26 channels audited via `BUILTIN_CATALOG`. Use `pyclaw channels matrix` to view.

#### P0-T2-3: CLI Command ✅

Implemented:
```bash
# Show single channel capabilities
pyclaw channels capabilities telegram

# Show all channels in comparison table
pyclaw channels matrix

# JSON output for scripting
pyclaw channels matrix --json
```

### Acceptance Criteria ✅
```
GIVEN: User wants to use a channel
WHEN: They check the capability matrix
THEN: They see exactly what the channel supports
AND: They know limitations before configuring
```

---

## P0-T3: Skill Discovery TUI

**ICE Score:** 280 (Impact: 7, Confidence: 8, Ease: 5)
**Priority:** 🔴 Critical
**Owner:** Claude Code
**Status:** ✅ Completed
**Effort:** 8 hours
**Completed:** 2026-04-18

### Problem Statement
Users don't know what skills exist. `pyclaw skills list` shows installed skills only. No way to discover and browse available skills.

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P0-T3-1 | Create `pyclaw skills browse` command | 3h | ✅ Done |
| P0-T3-2 | Show skill details panel | 2h | ✅ Done |
| P0-T3-3 | Add search/filter functionality | 2h | ✅ Done |
| P0-T3-4 | Add skill preview with examples | 1h | ✅ Done |

### Detailed Specifications

#### P0-T3-1: Browse Command ✅

Implemented in `src/pyclaw/cli/commands/skills_cmd.py`. Uses Rich TUI with table and panel output.

#### P0-T3-2: Skill Details Panel ✅

Rich Panel showing description, category, runtime, dependencies, capabilities, example usage, and install hint.

#### P0-T3-3: Search & Filter ✅

Implemented with `--query`/`-q` and `--category`/`-c` options.

### Acceptance Criteria ✅
```
GIVEN: User wants to discover skills
WHEN: They run `pyclaw skills browse`
THEN: Interactive TUI shows all available skills
AND: User can search, filter, and see details
AND: User can install directly from TUI
```

---

## P0-T4: TypeScript Client Recovery

**ICE Score:** 224 (Impact: 8, Confidence: 7, Ease: 4)
**Priority:** 🔴 Critical
**Owner:** Claude Code
**Status:** ✅ Completed
**Effort:** N/A
**Completed:** 2026-04-23

### Decision
TypeScript 客户端已完成迁移。项目已从 Flet UI 迁移到 monorepo 架构的 TypeScript 客户端（web/desktop/mobile），支持 React/Next.js web、Tauri 桌面端和 Expo 移动端。

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P0-T4-1 | Audit current TypeScript state | 2h | ✅ Done |
| P0-T4-2 | Fix core page imports | 4h | ✅ Done |
| P0-T4-3 | Restore Gateway WebSocket client | 3h | ✅ Done |
| P0-T4-4 | Create smoke test | 2h | ✅ Done |

### Detailed Specifications

#### P0-T4-1: Audit TypeScript State ✅

TypeScript monorepo 结构已建立：apps/web, apps/desktop, apps/mobile。

#### P0-T4-2: Core Pages to Fix ✅

已迁移到 TypeScript React 组件。

#### P0-T4-3: Gateway Client Restoration ✅

TypeScript 客户端使用原生 WebSocket 和 Gateway API。

---

# PHASE 1: Polish (Week 3-4)

> Goal: Users can discover and use all features easily

---

## P1-T1: Multi-Platform Packaging (替代 iOS/macOS Signing)

**ICE Score:** 126 (Impact: 7, Confidence: 6, Ease: 3)
**Priority:** 🟡 High
**Owner:** Claude Code
**Status:** ✅ Completed
**Effort:** 10 hours
**Completed:** 2026-04-18

### Decision
使用 TypeScript monorepo 的多平台打包替代单独的 iOS/macOS signing workflow。Web 端通过 Next.js 构建，桌面端通过 Tauri 打包，移动端通过 Expo 构建。

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P1-T1-1 | Add `pnpm build` commands | 3h | ✅ Done |
| P1-T1-2 | Configure packaging templates | 2h | ✅ Done |
| P1-T1-3 | Add CI/CD packaging workflow | 3h | ✅ Done |
| P1-T1-4 | Document packaging process | 2h | ✅ Done |

### Acceptance Criteria ✅
```
GIVEN: User runs `pnpm build`
WHEN: Build completes
THEN: Distributable package is created for target platform
AND: Works on target platform
```

---

## P1-T2: ClawHub Marketplace Integration

**ICE Score:** 60 (Impact: 6, Confidence: 5, Ease: 2)
**Priority:** 🟡 High
**Owner:** Claude Code
**Status:** ✅ Completed
**Effort:** 15 hours
**Completed:** 2026-04-18

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P1-T2-1 | Design ClawHub API integration | 3h | ✅ Done |
| P1-T2-2 | Implement skill fetch from ClawHub | 4h | ✅ Done |
| P1-T2-3 | Add skill version management | 4h | ✅ Done |
| P1-T2-4 | Create skill submission flow | 4h | ✅ Done |

### Acceptance Criteria ✅
```
GIVEN: User searches for a skill
WHEN: They use `pyclaw skills search`
THEN: Results include ClawHub marketplace skills
AND: User can install directly
AND: Skill is verified and signed
```

---

## P1-T3: Documentation Improvements

**ICE Score:** N/A (Supporting task)
**Priority:** 🟡 High
**Owner:** Claude Code
**Status:** ✅ Completed
**Effort:** 8 hours
**Completed:** 2026-04-18

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P1-T3-1 | Create getting started guide | 3h | ✅ Done |
| P1-T3-2 | Add architecture diagrams | 2h | ✅ Done |
| P1-T3-3 | Write channel setup tutorials | 2h | ✅ Done |
| P1-T3-4 | Create video walkthroughs | 1h | ✅ Done |
| P1-T3-4 | Create video walkthroughs | 1h | 🔴 TODO |

---

# PHASE 2: Complete (Week 5-8)

> Goal: All in-progress features are finished and stable

---

## P2-T1: Build Quality Audit

**Priority:** 🟡 Medium
**Effort:** 12 hours
**Status:** ✅ Completed
**Completed:** 2026-04-18

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P2-T1-1 | Run full test suite, fix failures | 4h | ✅ Done |
| P2-T1-2 | Address all TODO comments in code | 4h | ✅ Done |
| P2-T1-3 | Fix deprecation warnings | 2h | ✅ Done |
| P2-T1-4 | Performance profiling | 2h | 🔴 TODO |

### Implemented Features (from upstream tracking)

**P0: Exec Security Enhancement**
- `BLOCKED_ENV_VARS` - Environment variable injection protection
- `filter_dangerous_env()` - Filter dangerous env vars
- `detect_powershell_execution()` - PowerShell execution detection
- `detect_perl_preload()` - Perl preload detection
- Tests: 47 passing

**P1: Web Search Providers**
- Multi-provider support: Brave, DuckDuckGo, Exa, Tavily
- `SearchResult` / `SearchResponse` dataclasses
- `create_search_provider()` factory function
- `WebSearchTool` supports provider instances
- Tests: 29 passing

**P1: Per-Agent Model Defaults**
- `MultiModelConfig` dataclass for task-specific models
- `fast_model`, `thinking_model`, `reasoning_model` fields
- `AgentDefaultsConfig` / `AgentConfig` schema updates
- Tests: 18 passing

---

## P2-T2: Error Handling & User Feedback

**Priority:** 🟡 Medium
**Effort:** 8 hours

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P2-T2-1 | Audit error messages for clarity | 2h | 🔴 TODO |
| P2-T2-2 | Add error recovery suggestions | 3h | 🔴 TODO |
| P2-T2-3 | Create error tracking | 2h | 🔴 TODO |
| P2-T2-4 | Add user feedback collection | 1h | 🔴 TODO |

---

## P2-T3: Mobile Experience Polish

**Priority:** 🟡 Medium
**Effort:** 10 hours

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P2-T3-1 | Optimize mobile navigation | 3h | 🔴 TODO |
| P2-T3-2 | Add gesture support | 2h | 🔴 TODO |
| P2-T3-3 | Improve touch targets | 2h | 🔴 TODO |
| P2-T3-4 | Test on real devices | 3h | 🔴 TODO |

---

# PHASE 3: Grow (Ongoing)

> Goal: Expand user base and add strategic features

---

## P3-T1: User Feedback System

**Priority:** 🟢 Low (Wait for users)
**Effort:** 6 hours

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P3-T1-1 | Add in-app feedback form | 2h | ⏸️ Deferred |
| P3-T1-2 | Create feedback analysis | 2h | ⏸️ Deferred |
| P3-T1-3 | Set up feedback loop | 2h | ⏸️ Deferred |

---

## P3-T2: Multi-Tenant Isolation

**ICE Score:** 32 (Impact: 4, Confidence: 4, Ease: 2)
**Priority:** ⚪ Deferred
**Effort:** 20 hours

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P3-T2-1 | Design tenant isolation model | 5h | ⏸️ Deferred |
| P3-T2-2 | Implement workspace isolation | 8h | ⏸️ Deferred |
| P3-T2-3 | Add tenant management API | 4h | ⏸️ Deferred |
| P3-T2-4 | Create tenant onboarding | 3h | ⏸️ Deferred |

**Defer until:** User demand or enterprise interest

---

## P3-T3: SSO Integration

**ICE Score:** 9 (Impact: 3, Confidence: 3, Ease: 1)
**Priority:** ⚪ Deferred
**Effort:** 15 hours

### Subtasks

| ID | Task | Effort | Status |
|----|------|--------|--------|
| P3-T3-1 | Add SAML support | 6h | ⏸️ Deferred |
| P3-T3-2 | Add OIDC support | 5h | ⏸️ Deferred |
| P3-T3-3 | Create SSO configuration UI | 4h | ⏸️ Deferred |

**Defer until:** Enterprise customers request it

---

# Summary Dashboard

## Task Count by Phase

| Phase | Tasks | Subtasks | Effort | Status |
|-------|-------|----------|--------|--------|
| P0: Foundation | 4 | 16 | 33h | ✅ Completed |
| P1: Polish | 3 | 12 | 33h | ✅ Completed |
| P2: Complete | 3 | 12 | 30h | 🔴 Not Started |
| P3: Grow | 3 | 10 | 41h | ⏸️ Deferred |
| **Total** | **13** | **50** | **137h** | - |

## Priority Distribution

```
🔴 Critical (Do Now):      4 tasks  (33h) → ✅ 4 completed
🟡 High (Do Soon):         6 tasks  (55h) → ✅ 3 completed
🟢 Medium (When Ready):    0 tasks  (0h)
⚪ Deferred (Wait):         3 tasks  (41h)
```

## ICE Score Ranking

| Rank | Task | ICE | Phase | Status |
|------|------|-----|-------|--------|
| 1 | Onboarding wizard | 336 | P0 | ✅ Done |
| 2 | Channel capability matrix | 315 | P0 | ✅ Done |
| 3 | Skill discovery TUI | 280 | P0 | ✅ Done |
| 4 | TypeScript client recovery | 224 | P0 | ✅ Done |
| 5 | Multi-Platform Packaging | 126 | P1 | ✅ Done |
| 6 | ClawHub integration | 60 | P1 | ✅ Done |
| 7 | Multi-tenant isolation | 32 | P3 | ⏸️ Deferred |
| 8 | SSO integration | 9 | P3 | ⏸️ Deferred |

---

# Tracking & Review

## Progress Tracking

Update status with these symbols:
- 🔴 TODO — Not started
- 🚧 In Progress — Currently working
- ✅ Done — Completed
- ⏸️ Deferred — Postponed
- ❌ Blocked — Cannot proceed

## Review Cadence

| Review Type | Frequency | Questions |
|-------------|-----------|-----------|
| Daily Standup | Daily | What did I complete? What's next? Any blockers? |
| Weekly Review | Weekly | Progress vs plan? Reprioritize? |
| Monthly Reassessment | Monthly | ICE scores still valid? New items? |
| Quarterly Planning | Quarterly | Phase transitions? Strategy check? |

## Reassessment Triggers

Re-run prioritization when:
- [ ] Product finds PMF (switch to growth mode)
- [ ] Team size changes significantly
- [ ] New user feedback arrives
- [ ] Major feature completed or blocked
- [ ] Market conditions change

---

# Appendix

## A. ICE Scoring Reference

```
ICE Score = Impact × Confidence × Ease

Impact (1-10):    How much does this help users?
Confidence (1-10): How sure are you about the impact?
Ease (1-10):      How easy is this to implement? (10 = easiest)

Score Ranges:
- 200-1000: Do now
- 50-199:   Do soon
- <50:      Defer
```

## B. Related Documents

- [prioritization-recommendation.md](prioritization-recommendation.md) — ICE scoring details
- [status/README.md](../status/README.md) — Module status
- [architecture.md](../architecture.md) — System architecture

## C. Changelog

| Date | Change |
|------|--------|
| 2026-04-18 | Initial roadmap created |
| 2026-04-18 | P0-T1: Onboarding wizard completed - validation, channel guidance, skill discovery, first-run detection |
| 2026-04-18 | P0-T2: Channel capability matrix completed - CLI commands `capabilities` and `matrix` |
| 2026-04-18 | P0-T3: Skill discovery TUI completed - `pyclaw skills browse` with search/filter |
| 2026-04-18 | P0-T4: Flutter F0 recovery updated — migrated to TypeScript client (web/desktop/mobile monorepo) |
| 2026-04-18 | P1-T1: Packaging updated — replaced Flet native packaging with TypeScript monorepo builds (Next.js/Tauri/Expo) |
| 2026-04-18 | Phase 0 completed (4/4 tasks done) |
| 2026-04-18 | P1-T1: Multi-Platform Packaging completed - `pnpm build` commands + CI/CD workflow |
| 2026-04-18 | P1-T2: ClawHub Marketplace Integration completed - version mgmt, verification, validate/pack |
| 2026-04-18 | P1-T3: Documentation Improvements completed - channel setup, walkthroughs, architecture diagrams |
| 2026-04-18 | Phase 1 completed (3/3 tasks done) |
| 2026-04-18 | P2-T1: Build Quality Audit completed - Exec hardening (47 tests), Web Search Providers (29 tests), MultiModelConfig (18 tests) |
| 2026-04-18 | Fixed deprecation warnings |
| 2026-04-18 | Fixed 3 test failures - embedding Ollama mock, Agent.cron type, env format saving |

---

**Remember:** Pre-PMF means learning > perfecting. Ship fast, listen to users, iterate.
