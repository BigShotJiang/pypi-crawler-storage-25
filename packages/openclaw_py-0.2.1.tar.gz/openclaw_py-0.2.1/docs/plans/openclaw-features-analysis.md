# OpenClaw 功能分析与借鉴计划

> 基于 OpenClaw 最近 10 个 Release (v2026.4.12-beta.1 ~ v2026.3.13) 的功能分析
>
> **最后更新**: 2026-04-13

---

## 一、核心功能借鉴建议

### 0. 🆕 最新版本亮点 (v2026.4.x)

#### v2026.4.12-beta.1 (2026-04-12)

**新增功能**:
- **Plugins 按需加载**: 只加载 manifest 声明需要的 CLI、provider、channel，减少启动时间
- **Memory/Active Memory 默认 QMD Recall**: 改进记忆召回的搜索路径和遥测
- **Memory-wiki 文档增强**: 更丰富的 provider 文档和 bridge-mode 配方

**修复**:
- CLI update 自更新后的插件刷新问题
- Dreaming 心跳事件处理和 narrative 清理
- Unicode 文件名在 wiki slugs 中的支持
- WhatsApp outbound media 发送修复

#### v2026.4.11 (2026-04-12)

**新增功能**:
- **ChatGPT Import Ingestion**: Dreaming/memory-wiki 支持导入 ChatGPT 对话历史
- **Control UI Webchat 增强**: 助手 media/reply/voice 指令渲染为聊天气泡，新增 `[embed ...]` 富输出标签
- **video_generate 工具增强**: URL-only 资产交付、typed providerOptions、reference audio 输入
- **Feishu 文档评论增强**: 更丰富的上下文解析、评论反应、打字反馈
- **Microsoft Teams 反应支持**: 反应、反应列表、Graph 分页
- **Plugin Manifest Activation**: 插件可声明 activation 和 setup descriptors

**修复**:
- OpenAI/Codex OAuth scope 重写问题
- Audio transcription DNS 处理
- macOS Talk Mode 麦克风权限后继续启动

#### v2026.4.10 (2026-04-11) ⭐ 重要版本

**新增功能**:
- **🧠 Active Memory Plugin**: 专用的记忆子代理，在主回复前自动拉取相关偏好、上下文和历史细节
  - 可配置 message/recent/full context 模式
  - 实时 `/verbose` 检查
  - 高级 prompt/thinking 覆盖
  - 可选 transcript 持久化
  - 文档: https://docs.openclaw.ai/concepts/active-memory
- **Codex Provider**: 独立的 Codex provider，使用 Codex 管理的 auth、native threads、model discovery
- **macOS MLX Speech**: 实验性本地 MLX 语音 provider，支持 Talk Mode
- **CLI exec-policy 命令**: `openclaw exec-policy show|preset|set` 管理执行审批策略
- **Gateway commands.list RPC**: 远程客户端可发现运行时命令

**安全修复**:
- Browser SSRF 检查增强
- dotenv 不信任变量阻止
- Gateway node exec 事件清理

#### v2026.4.9 (2026-04-09)

**新增功能**:
- **Memory/Dreaming REM Backfill**: 历史日志回填到 Dreams 和 durable memory
- **Control UI Diary View**: 结构化日记视图，时间线导航，backfill/reset 控制
- **QA Lab**: character-vibes 评估报告，模型选择和并行运行
- **Provider Auth Aliases**: provider 变体可共享 env vars 和 auth profiles

**安全修复**:
- Browser blocked-destination SSRF 增强
- dotenv 运行时控制变量阻止
- Gateway node exec 事件清理
- dependency audit: basic-ftp CRLF 修复

---

### 1. 🔥 高优先级 - 立即可借鉴

#### 1.1 ClawHub Skills Marketplace (v2026.3.22)

**原功能**:
- `openclaw skills search|install|update` 命令
- Skills 市场集成，支持搜索、安装、更新
- `plugins install clawhub:<package>` 格式

**PyClaw 借鉴**:
```python
# 新增 CLI 命令
pyclaw skills search <query>
pyclaw skills install <skill-id>
pyclaw skills update [--all]
pyclaw skills list
```

**实现要点**:
- 创建 `src/pyclaw/skills/` 模块
- 实现 Skill Registry API 客户端
- 支持本地 skill 缓存和版本管理

---

#### 1.2 `/btw` Side Questions (v2026.3.22)

**原功能**:
- 快速问答，不改变会话上下文
- 可忽略的 TUI 答案
- 外部通道显式 BTW 回复

**PyClaw 借鉴**:
```python
# 在 agents/tools/ 中添加 btw_tool.py
async def btw(question: str) -> str:
    """Quick side question without context pollution."""
    # 使用独立的小模型快速回答
    # 不写入会话历史
    return answer
```

**实现要点**:
- 轻量级问答工具
- 不污染主会话记忆
- 支持 TypeScript 客户端临时弹窗显示

---

#### 1.3 Sandbox Backends (v2026.3.22)

**原功能**:
- 可插拔的沙箱后端
- OpenShell (mirror/remote workspace)
- SSH 沙箱后端

**PyClaw 借鉴**:
```python
# src/pyclaw/sandbox/base.py
class SandboxBackend(ABC):
    @abstractmethod
    async def execute(self, command: str) -> Result: ...

    @abstractmethod
    async def upload(self, local_path: Path, remote_path: str): ...

# src/pyclaw/sandbox/docker.py
class DockerSandbox(SandboxBackend): ...

# src/pyclaw/sandbox/ssh.py
class SSHSandbox(SandboxBackend): ...
```

**实现要点**:
- 抽象 SandboxBackend 接口
- 实现 Docker 沙箱（已有基础）
- 新增 SSH 远程沙箱
- 支持本地 mirror 模式

---

### 2. 📊 中优先级 - 短期可借鉴

#### 2.1 Web Search Providers (v2026.3.22)

**原功能**:
- Exa 神经搜索集成
- Tavily 搜索和提取
- Firecrawl 搜索和抓取

**PyClaw 借鉴**:
```python
# src/pyclaw/tools/web_search.py
class WebSearchProvider(ABC):
    @abstractmethod
    async def search(self, query: str) -> list[SearchResult]: ...

# 插件式注册
WEB_SEARCH_PROVIDERS = {
    "exa": ExaSearchProvider,
    "tavily": TavilySearchProvider,
    "firecrawl": FirecrawlProvider,
    "duckduckgo": DuckDuckGoProvider,  # 免费 fallback
}
```

**实现要点**:
- 统一的 WebSearchProvider 接口
- 配置化选择默认搜索引擎
- 支持环境变量 API Key

---

#### 2.2 Per-Agent Model Defaults (v2026.3.22)

**原功能**:
- 每个 Agent 独立的 thinking/reasoning/fast 默认模型
- 自动回退不允许的模型覆盖

**PyClaw 借鉴**:
```python
# config/schema.py
class AgentConfig(BaseModel):
    name: str
    model: str = "openai/gpt-4o"
    thinking_model: str | None = None  # 深度思考模型
    fast_model: str | None = None      # 快速响应模型
    reasoning_model: str | None = None # 推理模型

    model_config = ConfigDict(extra="forbid")
```

**实现要点**:
- 扩展 AgentConfig 支持多模型
- 路由器根据任务复杂度选择模型
- 自动验证模型可用性

---

#### 2.3 UI/Accessibility Improvements (v2026.3.23)

**原功能**:
- WCAG 2.1 AA 对比度标准
- aria-labels 无障碍标签
- 统一的按钮原语 (`btn--icon`, `btn--ghost`)

**PyClaw 借鉴**:
```python
# src/pyclaw/ui/components/button.py
class ButtonPrimitive:
    """统一的按钮原语组件"""
    ICON = "btn--icon"
    GHOST = "btn--ghost"
    XS = "btn--xs"

def create_button(
    text: str,
    variant: str = "primary",
    icon: str | None = None,
    aria_label: str | None = None,
) -> ft.Control:
    ...
```

**实现要点**:
- TypeScript 客户端组件无障碍支持
- WCAG 2.1 AA 颜色对比度
- 统一的组件设计语言

---

#### 2.4 CSP Security (v2026.3.23)

**原功能**:
- 计算内联脚本的 SHA-256 哈希
- 动态添加到 CSP `script-src` 指令
- 保持默认阻止内联脚本

**PyClaw 借鉴**:
```python
# src/pyclaw/gateway/security/csp.py
def compute_script_hash(script: str) -> str:
    """计算脚本内容的 SHA-256 哈希"""
    return "sha256-" + base64.b64encode(
        hashlib.sha256(script.encode()).digest()
    ).decode()

def build_csp_header(script_hashes: list[str]) -> str:
    """构建 CSP 头"""
    return "; ".join([
        "default-src 'self'",
        f"script-src 'self' {' '.join(script_hashes)}",
        "style-src 'self' 'unsafe-inline'",
    ])
```

**实现要点**:
- Gateway 服务 CSP 中间件
- 动态脚本哈希计算
- 安全头配置

---

### 3. 🔮 低优先级 - 长期考虑

#### 3.1 Plugin Marketplace Integration (v2026.3.22)

**原功能**:
- Claude marketplace registry 解析
- `plugin@marketplace` 安装格式
- Codex、Claude、Cursor bundle 兼容

**PyClaw 借鉴**:
- 长期规划插件市场
- 支持 MCP 服务器发现和安装
- 需要完善的插件生态

---

#### 3.2 Browser Automation (v2026.3.13-beta.1)

**原功能**:
- Browser act 自动化：批量操作、选择器定位
- Chrome DevTools MCP 集成
- 现有会话附加模式

**PyClaw 借鉴**:
- 已有 MCP 集成基础
- 可通过 MCP 工具扩展浏览器能力
- Playwright 集成已存在

---

## 二、安全功能借鉴

### 2.1 Exec Approval Hardening (v2026.3.22)

**原功能**:
- `time` 作为透明包装器处理
- Perl `-M`、`-I` 预加载阻止
- PowerShell `-File`、`-f` 识别

**PyClaw 借鉴**:
```python
# src/pyclaw/security/exec_approval.py
TRANSPARENT_WRAPPERS = {"time", "nice", "ionice"}
BLOCKED_ENV_VARS = {
    "MAVEN_OPTS", "SBT_OPTS", "GRADLE_OPTS",
    "GLIBC_TUNABLES", "DOTNET_ADDITIONAL_DEPS",
}

def normalize_command(cmd: str) -> str:
    """展开透明包装器，获取真实命令"""
    parts = shlex.split(cmd)
    while parts[0] in TRANSPARENT_WRAPPERS:
        parts.pop(0)
    return " ".join(parts)
```

---

### 2.2 Webhook Security (v2026.3.22)

**原功能**:
- 预认证请求体限制 64KB / 5s
- 按源 IP 限制并发预认证请求
- 签名头验证在 body 读取前

**PyClaw 借鉴**:
```python
# src/pyclaw/gateway/middleware/webhook_security.py
class WebhookSecurityMiddleware:
    MAX_PREAUTH_BODY = 64 * 1024  # 64 KB
    MAX_PREAUTH_TIME = 5.0  # 5 seconds
    MAX_CONCURRENT_PREAUTH = 10  # per IP

    async def __call__(self, request: Request) -> Response:
        ip = request.client.host
        # 限流检查
        # 签名验证
        # Body 大小限制
        ...
```

---

## 三、实施路线图

### Phase 1: 基础增强 (1-2 周)

| 任务 | 优先级 | 工作量 |
|------|--------|--------|
| `/btw` 工具实现 | P0 | 1d |
| Exec 安全增强 | P0 | 1d |
| WCAG 无障碍改进 | P1 | 2d |
| CSP 安全头 | P1 | 1d |

### Phase 2: 功能扩展 (2-4 周)

| 任务 | 优先级 | 工作量 |
|------|--------|--------|
| Web Search Providers | P1 | 3d |
| Per-Agent 模型默认 | P1 | 2d |
| Sandbox Backends 抽象 | P2 | 5d |

### Phase 3: 生态建设 (长期)

| 任务 | 优先级 | 工作量 |
|------|--------|--------|
| Skills Marketplace | P2 | 2w |
| Plugin Marketplace | P3 | 3w |
| Browser Automation | P3 | 2w |

---

## 四、技术决策

### 采用标准

1. **与现有架构兼容** - 不破坏现有接口
2. **渐进式引入** - 可独立启用/禁用
3. **配置驱动** - 通过配置控制功能开关
4. **测试覆盖** - 80%+ 测试覆盖率

### 排除的功能

以下功能因架构差异或复杂度不纳入：

- **Matrix Plugin 重写** - Python 有 matrix-nio，但需要大量工作
- **Voice-call Webhook** - 暂无语音通话需求
- **Android/iOS Mobile** - Expo/React Native 已支持跨平台，暂不需要原生应用

---

## 五、参考资料

- [OpenClaw Releases](https://github.com/openclaw/openclaw/releases)
- [ClawHub Documentation](https://docs.openclaw.ai/tools/clawhub)
- [Plugin SDK Migration](https://docs.openclaw.ai/plugins/sdk-migration)
- [Browser Tool Documentation](https://docs.openclaw.ai/tools/browser)
