# Channels 模块实施状态

> 最后更新：2026-05-05
> 关联里程碑：核心基础设施

---

## 1. 模块概览

通道模块是连接外部消息平台的插件系统，每个通道实现统一的 `ChannelPlugin` 接口。内置 **27 通道**，涵盖主流消息平台。

---

## 2. ChannelPlugin 接口

| 方法 | 状态 | 说明 |
|------|------|------|
| `start()` | ✅ 完成 | 启动通道 |
| `stop()` | ✅ 完成 | 停止通道 |
| `send_reply()` | ✅ 完成 | 发送回复 |
| `on_message()` | ✅ 完成 | 注册消息回调 |

---

## 3. 通道实现状态

### 3.1 即时通讯平台

| 通道 | 目录 | 状态 | 说明 |
|------|------|------|------|
| Telegram | `telegram/` | ✅ 完成 | Bot API |
| Discord | `discord/` | ✅ 完成 | Bot |
| Slack | `slack/` | ✅ 完成 | Bot/App |
| WhatsApp | `whatsapp/` | ✅ 完成 | Business API |
| Signal | `signal/` | ✅ 完成 | |
| Matrix | `matrix/` | ✅ 完成 | |
| IRC | `irc/` | ✅ 完成 | |
| LINE | `line/` | ✅ 完成 | |

### 3.2 国内平台

| 通道 | 目录 | 状态 | 说明 |
|------|------|------|------|
| 钉钉 DingTalk | `dingtalk/` | ✅ 完成 | 企业机器人 |
| 飞书 Feishu | `feishu/` | ✅ 完成 | 企业机器人 |
| QQ | `qq/` | ✅ 完成 | |
| 微信 WeChat | - | 🚧 部分 | 需公众号/企业微信 |
| Zalo | `zalo/` | ✅ 完成 | |
| ZaloUser | `zalouser/` | ✅ 完成 | |

### 3.3 企业平台

| 通道 | 目录 | 状态 | 说明 |
|------|------|------|------|
| Microsoft Teams | `msteams/` | ✅ 完成 | |
| Google Chat | `googlechat/` | ✅ 完成 | |
| Mattermost | `mattermost/` | ✅ 完成 | |
| Nextcloud | `nextcloud/` | ✅ 完成 | |

### 3.4 其他平台

| 通道 | 目录 | 状态 | 说明 |
|------|------|------|------|
| Twitch | `twitch/` | ✅ 完成 | |
| Nostr | `nostr/` | ✅ 完成 | |
| Tlon | `tlon/` | ✅ 完成 | |
| iMessage | `imessage/` | ✅ 完成 | macOS |
| BlueBubbles | `bluebubbles/` | ✅ 完成 | |
| Synology | `synology/` | ✅ 完成 | |
| Voice Call | `voice_call/` | ✅ 完成 | 语音通话 |

---

## 4. Plugin SDK（20个Protocol接口）

| Protocol | 状态 | 用途 |
|----------|------|------|
| `ConfigAdapter` | ✅ 完成 | 配置schema + 验证 |
| `AuthAdapter` | ✅ 完成 | 认证 |
| `OutboundAdapter` | ✅ 完成 | 消息发送 |
| `ActionsAdapter` | ✅ 完成 | 反应、置顶 |
| `StreamingAdapter` | ✅ 完成 | 草稿/流式消息 |
| `HeartbeatAdapter` | ✅ 完成 | 连接心跳 |
| `DirectoryAdapter` | ✅ 完成 | 用户目录 |
| `MediaAdapter` | ✅ 完成 | 媒体处理 |
| `ReactionAdapter` | ✅ 完成 | 消息反应 |
| `ThreadAdapter` | ✅ 完成 | 线程支持 |
| `ReplyAdapter` | ✅ 完成 | 回复引用 |
| `EditAdapter` | ✅ 完成 | 消息编辑 |
| `DeleteAdapter` | ✅ 完成 | 消息删除 |
| `PinAdapter` | ✅ 完成 | 消息置顶 |
| `TypingAdapter` | ✅ 完成 | 输入状态 |
| `ReadAdapter` | ✅ 完成 | 已读状态 |
| `MentionAdapter` | ✅ 完成 | @提及 |
| `FileAdapter` | ✅ 完成 | 文件传输 |
| `StickerAdapter` | ✅ 完成 | 贴纸表情 |
| `LocationAdapter` | ✅ 完成 | 位置分享 |

**能力探测**：`detect_capabilities(plugin)` 自动探测通道支持的能力。

---

## 5. 通道策略

### 5.1 DM策略（dmPolicy）

| 策略 | 说明 |
|------|------|
| `pairing` | 未知发送者需通过配对码验证 |
| `allowlist` | 仅允许列表中的用户 |
| `open` | 允许所有人 |
| `disabled` | 禁用 |

### 5.2 群组策略（groupPolicy）

| 策略 | 说明 |
|------|------|
| `mention` | @mention 才触发（默认） |
| `all` | 所有消息都触发 |
| `disabled` | 禁用 |

---

## 6. 通道管理

| 组件 | 文件 | 状态 | 说明 |
|------|------|------|------|
| 基类 | `base.py` | ✅ 完成 | ChannelPlugin ABC |
| 管理器 | `manager.py` | ✅ 完成 | 统一生命周期管理 |
| 插件SDK | `plugin_sdk/` | ✅ 完成 | 20个Protocol接口 |
| 增强插件 | `plugins/` | ✅ 完成 | onboarding/outbound/actions/normalize |

---

## 7. 通道能力DoD（待完善）

| 检查项 | 状态 | 说明 |
|--------|------|------|
| 基础发送 | ✅ 完成 | 文本消息发送 |
| 媒体支持 | 🚧 部分 | 图片/文件/语音 |
| 流式输出 | 🚧 部分 | 打字中效果 |
| 反应支持 | 🚧 部分 | emoji反应 |
| 能力探测 | ✅ 完成 | 自动探测支持能力 |

详见：`reference/ops/P1_CHANNEL_CAPABILITY_DOD.md`

---

## 8. 关键文件索引

| 文件 | 职责 |
|------|------|
| `src/pyclaw/channels/base.py` | ChannelPlugin基类 |
| `src/pyclaw/channels/manager.py` | 通道管理器 |
| `src/pyclaw/channels/plugin_sdk/` | Protocol接口定义 |
| `src/pyclaw/channels/plugins/` | 通道增强插件 |
| `src/pyclaw/channels/<channel>/` | 各通道实现 |

---

## 9. 待办事项

- [ ] 通道能力矩阵完善
- [ ] 各通道能力探测测试
- [ ] 统一通道健康检查
- [ ] 通道配置验证器
