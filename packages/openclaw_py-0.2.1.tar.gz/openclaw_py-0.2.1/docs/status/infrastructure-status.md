# 基础设施实施状态

> 最后更新：2026-04-23
> 关联里程碑：M3 发布工程化

---

## 1. 模块概览

基础设施模块涵盖：
- CI/CD 流水线
- 发布工程化
- 配置系统
- 安全模型
- 密钥管理

---

## 2. CI/CD 状态

### 2.1 GitHub Actions

| 作业 | 状态 | 说明 |
|------|------|------|
| Lint (Ruff) | ✅ 完成 | 代码检查 |
| Test | ✅ 完成 | 单元测试 |
| Type Check | ✅ 完成 | 类型检查 |
| ui-smoke | ✅ 完成 | UI变更触发 |
| ui-e2e-nightly | ✅ 完成 | 夜间E2E测试 |

### 2.2 本地CI

详见：`docs/ci-local.md`

---

## 3. 发布工程化（M3）

### 3.1 TypeScript 客户端构建

| 平台 | 命令 | 状态 | 说明 |
|------|------|------|------|
| Web (Next.js) | `pnpm build` | ✅ 完成 | GitHub Pages / Self-hosting |
| Desktop (Tauri) Linux | `pnpm tauri build` | 🚧 进行中 | Linux deps/runner环境 |
| Desktop (Tauri) macOS | `pnpm tauri build` | 🚧 进行中 | Xcode/CocoaPods/签名 |
| Desktop (Tauri) Windows | `pnpm tauri build` | ✅ 完成 | VS C++ workload |
| Mobile (Expo) Android | `eas build --platform android` | 🚧 进行中 | JDK/SDK/签名 |
| Mobile (Expo) iOS | `eas build --platform ios` | 📋 待开始 | macOS + 证书 + profile |

### 3.2 发布Gate（M3）

| 门禁项 | 状态 | 说明 |
|--------|------|------|
| 版本一致性 | ✅ 完成 | 代码版本、构建版本、发布说明一致 |
| 签名与证书 | 🚧 进行中 | Android keystore / iOS provisioning / macOS entitlement |
| 权限声明 | ✅ 完成 | Android Manifest / iOS Info.plist / macOS entitlements |
| 构建可复现 | ✅ 完成 | CI可从干净环境复现 |
| 回归通过 | ✅ 完成 | 核心RPC、聊天链路、会话与配置管理 |
| 产物归档 | ✅ 完成 | hash、artifact、changelog、回滚包 |
| 发布后监控 | 📋 待开始 | 失败率、崩溃率、关键事件告警 |

### 3.3 发布Gate命令

```bash
pyclaw ops release-gate
```

功能：版本一致性、产物命名规则、`SHA256SUMS` 生成、报告落盘。

---

## 4. 配置系统

| 组件 | 文件 | 状态 | 说明 |
|------|------|------|------|
| Schema | `config/schema.py` | ✅ 完成 | Pydantic v2强类型，30+配置节 |
| JSON5解析 | `config/` | ✅ 完成 | 支持注释和尾逗号 |
| 环境变量替换 | `config/env_substitution.py` | ✅ 完成 | `${VAR}` / `${VAR:-default}` |
| $include分拆 | `config/includes.py` | ✅ 完成 | 大配置文件可拆分 |
| 版本迁移 | `config/migrations.py` | ✅ 完成 | v1 → v2 → v3自动迁移 |
| 热重载 | `config/runtime_overrides.py` | ✅ 完成 | 后台轮询检测文件变更 |
| 原子写入 | `config/backup.py` | ✅ 完成 | 先写临时文件再原子重命名 |

### 4.1 路径兼容

| 环境变量 | 配置目录 | 说明 |
|----------|----------|------|
| `PYCLAW_*` | `.pyclaw/` | 主路径 |
| `OPENCLAW_*` | `.openclaw/` | 兼容路径 |

---

## 5. 安全模型

### 5.1 安全层面

| 层面 | 机制 | 状态 |
|------|------|------|
| 命令执行 | allowlist / denylist + 用户审批 | ✅ 完成 |
| 文件访问 | 工作区目录沙箱 | ✅ 完成 |
| 网络 | SSRF防护（内网IP / DNS重绑定拦截） | ✅ 完成 |
| 配置 | 明文密钥扫描与警告 | ✅ 完成 |
| Gateway | 默认绑定 `127.0.0.1`，支持Token认证 | ✅ 完成 |

### 5.2 安全命令

```bash
pyclaw security audit [--deep] [--fix]
```

### 5.3 安全审计模板

`reference/ops/P0_SECURITY_WEEKLY_CHECKLIST.md`
`reference/ops/P1_SECRETS_AUDIT_TEMPLATE.md`

---

## 6. 密钥管理

| 组件 | 文件 | 状态 | 说明 |
|------|------|------|------|
| SecretRef | `secrets/` | ✅ 完成 | 密钥引用机制 |
| 明文扫描 | `security/` | ✅ 完成 | 检测配置中的明文密钥 |

---

## 7. Hook 系统

| 组件 | 文件 | 状态 | 说明 |
|------|------|------|------|
| 事件钩子 | `hooks/` | ✅ 完成 | HOOK.md定义 |
| 内置钩子 | `hooks/bundled/` | ✅ 完成 | 内置钩子实现 |

支持生命周期：`before_send` / `after_send` / `on_error` 等

---

## 8. MCP 客户端

| 组件 | 文件 | 状态 | 说明 |
|------|------|------|------|
| stdio transport | `mcp/` | ✅ 完成 | 启动子进程，stdin/stdout通信 |
| HTTP transport | `mcp/` | ✅ 完成 | 连接远程MCP服务器 |
| 工具注册表 | `mcp/` | ✅ 完成 | 将发现的工具映射为Agent可用tool schema |
| 热重载 | `mcp/` | ✅ 完成 | 配置变更自动重连 |

配置格式兼容 Claude Desktop 和 Cursor。

---

## 9. 关键文件索引

| 文件 | 职责 |
|------|------|
| `src/pyclaw/config/schema.py` | 配置Schema定义 |
| `src/pyclaw/config/runtime_overrides.py` | 热重载 |
| `src/pyclaw/security/` | 安全策略 |
| `src/pyclaw/secrets/` | 密钥管理 |
| `src/pyclaw/mcp/` | MCP客户端 |
| `src/pyclaw/hooks/` | 事件钩子 |
| `reference/ops/M3_RELEASE_GATE_V1.md` | 发布Gate v1 |
| `reference/ops/P0_SECURITY_WEEKLY_CHECKLIST.md` | 安全周检清单 |

---

## 10. 待办事项

- [ ] iOS/macOS签名流程完善
- [ ] 发布后监控告警
- [ ] 安全周检自动化
- [ ] 备份恢复演练门禁
