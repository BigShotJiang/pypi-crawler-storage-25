## 1. Memory Directory System

- [x] 1.1 Create `src/pyclaw/agents/memory_dir/` module with `__init__.py`
- [x] 1.2 Implement `paths.py` with `MemoryPaths` class for directory structure
- [x] 1.3 Implement `memoryTypes.py` with `MemoryEntry`, `MemoryType` dataclasses
- [x] 1.4 Implement `memoryAge.py` with temporal decay calculation
- [x] 1.5 Implement `findRelevantMemories.py` with relevance scoring
- [x] 1.6 Implement `memdir.py` with `MemoryDirectory` class for CRUD operations
- [x] 1.7 Implement `teamMemPaths.py` for team memory path resolution
- [x] 1.8 Implement `teamMemPrompts.py` for team memory prompt generation
- [x] 1.9 Add migration script from SQLite to directory structure
- [x] 1.10 Update `MemoryManager` to use new `MemoryDirectory`
- [x] 1.11 Add tests for memory directory operations

## 2. Context Manager System

- [x] 2.1 Create `src/pyclaw/agents/context/` module with `__init__.py`
- [x] 2.2 Implement `compaction.py` with `ContextCompactor` class
- [x] 2.3 Implement `injector.py` with `ContextInjector` class
- [x] 2.4 Implement `persistor.py` with `ContextPersistor` class
- [x] 2.5 Implement `manager.py` with `ContextManager` coordinating all components
- [x] 2.6 Implement `hooks.py` with `pre_reasoning_hook`, `post_turn_hook`
- [x] 2.7 Integrate `ContextManager` into `runner.py`
- [x] 2.8 Add context hook registration to session initialization
- [x] 2.9 Add tests for context compaction scenarios
- [x] 2.10 Add tests for cross-session context persistence

## 3. Unified Tool Registry

- [x] 3.1 Create `UnifiedToolRegistry` class in `tools/registry.py`
- [x] 3.2 Implement tool source tracking (builtin, skill, mcp, plugin)
- [x] 3.3 Implement namespaced tool lookup (`skill:`, `mcp:` prefixes)
- [x] 3.4 Implement tool name collision resolution with priority
- [x] 3.5 Implement dynamic tool registration/unregistration
- [x] 3.6 Add `to_skill_tool()` converter in skills module
- [x] 3.7 Add `to_mcp_tool()` wrapper in MCP module
- [x] 3.8 Update `create_default_tools()` to use `UnifiedToolRegistry`
- [x] 3.9 Add tests for unified registry operations
- [x] 3.10 Add tests for collision resolution

## 4. Skill System Enhancement

- [x] 4.1 Create `src/pyclaw/agents/skills/bundled/` directory
- [x] 4.2 Implement bundled skill `debug.py`
- [x] 4.3 Implement bundled skill `verify.py`
- [x] 4.4 Implement bundled skill `simplify.py`
- [x] 4.5 Implement bundled skill `loop.py`
- [x] 4.6 Implement bundled skill `batch.py`
- [x] 4.7 Implement `mcpSkillBuilders.py` for MCP-to-skill bridge
- [x] 4.8 Update `loadSkillsDir.py` for workspace skill discovery
- [x] 4.9 Implement skill dependency checking
- [x] 4.10 Add tests for bundled skills

## 5. Built-in Agent Types

- [x] 5.1 Create `src/pyclaw/agents/builtin_agents/` module
- [x] 5.2 Implement `base.py` with `BuiltinAgent` base class
- [x] 5.3 Implement `explore_agent.py` with exploration configuration
- [x] 5.4 Implement `plan_agent.py` with planning configuration
- [x] 5.5 Implement `verification_agent.py` with verification configuration
- [x] 5.6 Implement `general_purpose_agent.py` as default
- [x] 5.7 Create `BuiltinAgentRegistry` for agent type lookup
- [x] 5.8 Add tests for each built-in agent type

## 6. Agent Forking

- [x] 6.1 Implement `fork_subagent()` function in `subagents/runner.py`
- [x] 6.2 Add `inherit_memory` parameter to spawn configuration
- [x] 6.3 Implement shallow copy of parent messages on fork
- [x] 6.4 Implement tool filter on forked agents
- [x] 6.5 Add fork depth tracking to `SubagentManager`
- [x] 6.6 Add tests for fork scenarios

## 7. Coordinator Mode

- [x] 7.1 Create `src/pyclaw/agents/coordinator/` module
- [x] 7.2 Implement `coordinator_mode.py` with `CoordinatorMode` class
- [x] 7.3 Implement task decomposition logic
- [x] 7.4 Implement agent assignment based on subtask type
- [x] 7.5 Implement progress aggregation
- [x] 7.6 Implement error recovery and retry logic
- [x] 7.7 Add `CoordinatorTool` for invoking coordinator from agent
- [x] 7.8 Add tests for coordinator scenarios

## 8. Agent Memory Snapshot

- [x] 8.1 Create `AgentMemorySnapshot` dataclass in `subagents/types.py`
- [x] 8.2 Implement `create_memory_snapshot()` function
- [x] 8.3 Implement `restore_memory_snapshot()` function
- [x] 8.4 Implement snapshot persistence to disk
- [x] 8.5 Implement snapshot pruning with age/count limits
- [x] 8.6 Implement `inspect_snapshot()` for debugging
- [x] 8.7 Implement `diff_snapshots()` for comparison
- [x] 8.8 Add tests for snapshot operations

## 9. Subagent Manager Enhancement

- [x] 9.1 Update `SubagentConfig` with `agent_type` field
- [x] 9.2 Update `SubagentConfig` with `inherit_memory` field
- [x] 9.3 Update `spawn()` to use built-in agent registry
- [x] 9.4 Implement memory inheritance on spawn
- [x] 9.5 Update `steer()` to handle multiple instructions
- [x] 9.6 Add result metadata with agent type info
- [x] 9.7 Add tests for enhanced subagent scenarios

## 10. Orchestration Enhancement

- [x] 10.1 Update `OrchestrationManifest` with team support
- [x] 10.2 Add dependency ordering to manifest processing
- [x] 10.3 Implement parallel execution of independent subtasks
- [x] 10.4 Add progress tracking to manifest storage
- [x] 10.5 Update `OrchestrateTool` with new features
- [x] 10.6 Add tests for orchestration scenarios

## 11. Integration & Documentation

- [x] 11.1 Update `agents/__init__.py` to export new modules
- [x] 11.2 Update CLAUDE.md with new architecture notes
- [x] 11.3 Add API documentation for new classes
- [x] 11.4 Create migration guide for existing users
- [x] 11.5 Run full test suite and fix issues
- [x] 11.6 Add integration tests for multi-agent scenarios
