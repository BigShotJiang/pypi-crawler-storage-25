## ADDED Requirements

### Requirement: Skill Discovery
The system SHALL discover skills from workspace `.claude/skills/` directory.

#### Scenario: Discover workspace skills
- **WHEN** the skill system initializes
- **THEN** all skill directories under `.claude/skills/` are discovered

#### Scenario: Parse skill metadata
- **WHEN** a skill is discovered
- **THEN** its `SKILL.md` frontmatter is parsed for metadata

#### Scenario: Validate skill structure
- **WHEN** a skill is loaded
- **THEN** the system validates required files exist

### Requirement: Bundled Skills
The system SHALL provide bundled skills that ship with the application.

#### Scenario: Load bundled skills
- **WHEN** the skill system initializes
- **THEN** bundled skills are loaded from `pyclaw/agents/skills/bundled/`

#### Scenario: Bundled skill priority
- **WHEN** a workspace skill has the same name as bundled
- **THEN** the workspace skill takes priority

### Requirement: Skill Loading
The system SHALL load skill content and prepare it for execution.

#### Scenario: Load skill prompt
- **WHEN** a skill is invoked
- **THEN** the skill's prompt content is loaded

#### Scenario: Handle skill dependencies
- **WHEN** a skill has dependencies
- **THEN** dependencies are checked before execution

### Requirement: Skill Execution
The system SHALL execute skills with proper isolation and context.

#### Scenario: Execute skill
- **WHEN** a skill is invoked via `/skill-name`
- **THEN** the skill's prompt is executed in agent context

#### Scenario: Skill with arguments
- **WHEN** a skill is invoked with arguments
- **THEN** arguments are passed to the skill template

#### Scenario: Skill execution error
- **WHEN** a skill execution fails
- **THEN** a clear error message is returned

### Requirement: MCP Skill Bridge
The system SHALL expose MCP tools as invocable skills.

#### Scenario: MCP tool as skill
- **WHEN** an MCP server provides a tool
- **THEN** it is exposed as a skill with `mcp:` prefix

#### Scenario: MCP skill invocation
- **WHEN** an MCP skill is invoked
- **THEN** the tool call is routed to the MCP server

### Requirement: Skill Metadata
The system SHALL support skill metadata fields: `always`, `primary_env`, `emoji`, `homepage`, `os_filter`, `requires`, `install`.

#### Scenario: Parse skill metadata
- **WHEN** loading a skill
- **THEN** all metadata fields are parsed from frontmatter

#### Scenario: OS filter enforcement
- **WHEN** a skill has `os_filter: [linux]`
- **THEN** the skill is only available on Linux systems

#### Scenario: Dependency check
- **WHEN** a skill has `requires: [node]`
- **THEN** the system verifies Node.js is installed
