## ADDED Requirements

### Requirement: Memory Directory Structure
The system SHALL maintain a structured memory directory at `.claude/memory/` with separate subdirectories for project, session, team, and user memories.

#### Scenario: Memory directory initialization
- **WHEN** a new project is initialized
- **THEN** the system creates `.claude/memory/` with subdirectories `project/`, `session/`, `team/`, and `user/`

#### Scenario: Memory directory detection
- **WHEN** the memory system starts
- **THEN** it detects and uses existing `.claude/memory/` directory if present

### Requirement: Project-Level Memory
The system SHALL store project-level decisions and context in `.claude/memory/project/` directory.

#### Scenario: Store project decision
- **WHEN** an agent makes a significant project decision
- **THEN** the system appends the decision to `project/decisions.jsonl`

#### Scenario: Load project decisions
- **WHEN** a new agent session starts
- **THEN** the system loads all project decisions for context injection

### Requirement: Session-Level Memory
The system SHALL store session-specific memories in `.claude/memory/session/{session_id}.jsonl`.

#### Scenario: Create session memory file
- **WHEN** a new agent session begins
- **THEN** the system creates `session/{session_id}.jsonl`

#### Scenario: Isolate session memories
- **WHEN** multiple sessions run concurrently
- **THEN** each session's memories are isolated in separate files

### Requirement: Team Memory Support
The system SHALL support shared team memories in `.claude/memory/team/` for multi-agent collaboration.

#### Scenario: Shared team memory
- **WHEN** agents are configured as a team
- **THEN** they share access to `team/shared.jsonl`

#### Scenario: Team memory isolation
- **WHEN** agents not on the same team access memory
- **THEN** team memories are not accessible

### Requirement: Memory Types
The system SHALL support structured memory types: user preferences, project decisions, feedback records, and reference links.

#### Scenario: User preference memory
- **WHEN** a user preference is recorded
- **THEN** it is stored with type `user_preference` and key-value structure

#### Scenario: Project decision memory
- **WHEN** a project decision is recorded
- **THEN** it is stored with type `project_decision`, rationale, and timestamp

### Requirement: Memory Age and Relevance
The system SHALL compute memory age and relevance scores for retrieval prioritization.

#### Scenario: Memory age calculation
- **WHEN** memories are retrieved
- **THEN** each memory has an `age_days` field calculated from creation timestamp

#### Scenario: Relevance scoring
- **WHEN** a query searches memories
- **THEN** results are ranked by relevance score combining text match and recency
