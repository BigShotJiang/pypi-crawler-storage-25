## MODIFIED Requirements

### Requirement: Subagent Spawning
The system SHALL spawn subagents with configurable agent types and memory inheritance.

#### Scenario: Spawn with built-in agent type
- **WHEN** spawning a subagent with `agent_type="explore"`
- **THEN** the Explore agent configuration is used

#### Scenario: Spawn with memory inheritance
- **WHEN** spawning a subagent with `inherit_memory=True`
- **THEN** the subagent receives a copy of parent's memory snapshot

#### Scenario: Spawn with depth tracking
- **WHEN** spawning a subagent
- **THEN** the depth is tracked and enforced against MAX_DEPTH

### Requirement: Subagent Lifecycle Management
The system SHALL manage the full lifecycle of subagents including spawn, steer, kill, and completion.

#### Scenario: List active subagents
- **WHEN** `list_active()` is called
- **THEN** all running subagents with their status are returned

#### Scenario: Kill subagent
- **WHEN** `kill(session_id)` is called on a running subagent
- **THEN** the subagent is aborted and cleaned up

#### Scenario: Steer subagent
- **WHEN** `steer(session_id, instruction)` is called
- **THEN** the instruction is injected into the subagent's context

### Requirement: Subagent Result Aggregation
The system SHALL aggregate results from completed subagents.

#### Scenario: Collect subagent results
- **WHEN** multiple subagents complete
- **THEN** their results are available via `list_completed()`

#### Scenario: Result metadata
- **WHEN** a subagent completes
- **THEN** result includes `session_id`, `state`, `output`, and `meta` fields
