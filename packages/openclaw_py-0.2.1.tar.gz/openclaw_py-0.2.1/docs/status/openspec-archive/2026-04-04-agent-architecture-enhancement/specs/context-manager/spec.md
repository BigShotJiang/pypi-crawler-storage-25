## ADDED Requirements

### Requirement: Context Compaction
The system SHALL automatically compact conversation context when it exceeds configured limits.

#### Scenario: Trigger compaction on token limit
- **WHEN** conversation token count exceeds `max_context_tokens`
- **THEN** the system compacts older messages into a summary

#### Scenario: Preserve recent context
- **WHEN** compaction occurs
- **THEN** the most recent N messages are preserved unmodified

#### Scenario: Tool result compaction
- **WHEN** a tool result exceeds `max_tool_result_tokens`
- **THEN** the system truncates or summarizes the result

### Requirement: Context Injection
The system SHALL inject relevant memory context before agent reasoning.

#### Scenario: Inject user preferences
- **WHEN** an agent starts reasoning
- **THEN** user preferences are injected into the system prompt

#### Scenario: Inject project decisions
- **WHEN** an agent starts reasoning
- **THEN** recent project decisions are injected as context

#### Scenario: Skip injection if no relevant memories
- **WHEN** no relevant memories exist
- **THEN** no memory context is added to the prompt

### Requirement: Cross-Session Context Persistence
The system SHALL persist and restore context across agent sessions.

#### Scenario: Save context on session end
- **WHEN** an agent session ends normally
- **THEN** the context state is saved to `.claude/sessions/{session_id}/context.json`

#### Scenario: Restore context on session resume
- **WHEN** an agent session is resumed
- **THEN** the previous context state is restored

#### Scenario: Handle corrupted context
- **WHEN** saved context file is corrupted
- **THEN** the system logs a warning and starts with fresh context

### Requirement: Context Hooks
The system SHALL provide hook points for context manipulation.

#### Scenario: Pre-reasoning hook
- **WHEN** a pre-reasoning hook is registered
- **THEN** it is called with messages before LLM invocation

#### Scenario: Post-turn hook
- **WHEN** a post-turn hook is registered
- **THEN** it is called after each agent turn completes

#### Scenario: On-compaction hook
- **WHEN** a compaction hook is registered
- **THEN** it is called when context is compacted

### Requirement: Context Summary Generation
The system SHALL generate summaries of compacted context using LLM.

#### Scenario: Generate summary with LLM
- **WHEN** compaction requires a summary
- **THEN** the system uses configured LLM to generate a concise summary

#### Scenario: Include summary in context
- **WHEN** compaction completes
- **THEN** the summary is included as a system message
