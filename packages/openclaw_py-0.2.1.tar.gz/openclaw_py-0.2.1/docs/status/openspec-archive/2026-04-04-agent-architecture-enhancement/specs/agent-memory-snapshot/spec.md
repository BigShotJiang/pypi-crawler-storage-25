## ADDED Requirements

### Requirement: Memory Snapshot Creation
The system SHALL capture agent memory state into a snapshot structure.

#### Scenario: Create snapshot
- **WHEN** `create_memory_snapshot(session_id)` is called
- **THEN** a snapshot containing messages, tool results, and preferences is created

#### Scenario: Snapshot format
- **WHEN** a snapshot is created
- **THEN** it contains `session_id`, `messages`, `tool_results`, `preferences`, `decisions`, `created_at` fields

### Requirement: Memory Snapshot Restoration
The system SHALL restore agent state from a memory snapshot.

#### Scenario: Restore from snapshot
- **WHEN** `restore_memory_snapshot(snapshot)` is called
- **THEN** the session state is reconstructed from the snapshot

#### Scenario: Validate snapshot before restore
- **WHEN** a corrupted snapshot is provided
- **THEN** an error is raised without partial restoration

### Requirement: Snapshot Inheritance
The system SHALL support inheriting snapshots when forking agents.

#### Scenario: Fork with snapshot
- **WHEN** forking an agent with `inherit_memory=True`
- **THEN** the forked agent receives a copy of the parent's snapshot

#### Scenario: Snapshot isolation
- **WHEN** a forked agent modifies its memory
- **THEN** the parent's snapshot is not affected

### Requirement: Snapshot Persistence
The system SHALL persist snapshots to disk for later restoration.

#### Scenario: Save snapshot to disk
- **WHEN** `save_snapshot(snapshot, path)` is called
- **THEN** the snapshot is written as JSON to the specified path

#### Scenario: Load snapshot from disk
- **WHEN** `load_snapshot(path)` is called
- **THEN** the snapshot is loaded from the JSON file

#### Scenario: Handle missing snapshot file
- **WHEN** loading a snapshot from a non-existent path
- **THEN** None is returned

### Requirement: Snapshot Pruning
The system SHALL prune old snapshots to manage storage.

#### Scenario: Auto-prune old snapshots
- **WHEN** snapshot count exceeds `max_snapshots`
- **THEN** oldest snapshots are deleted

#### Scenario: Snapshot age limit
- **WHEN** snapshots exceed `max_snapshot_age_days`
- **THEN** they are automatically pruned

### Requirement: Snapshot for Debugging
The system SHALL provide snapshot inspection for debugging.

#### Scenario: Inspect snapshot
- **WHEN** `inspect_snapshot(snapshot_id)` is called
- **THEN** a summary of snapshot contents is returned

#### Scenario: Diff snapshots
- **WHEN** `diff_snapshots(snap1, snap2)` is called
- **THEN** differences between snapshots are highlighted
