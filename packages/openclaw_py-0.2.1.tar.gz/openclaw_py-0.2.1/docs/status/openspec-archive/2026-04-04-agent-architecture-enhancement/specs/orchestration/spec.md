## MODIFIED Requirements

### Requirement: Orchestration Manifest
The system SHALL create orchestration manifests with team support and dependency ordering.

#### Scenario: Create manifest with roles
- **WHEN** `orchestrate_manifest` is called with goal and subtasks
- **THEN** a manifest with roles for each subtask is created

#### Scenario: Manifest with dependencies
- **WHEN** subtasks have dependencies on each other
- **THEN** dependencies are encoded in the manifest

#### Scenario: Manifest with team configuration
- **WHEN** creating a manifest for a team
- **THEN** team member assignments are included

### Requirement: Spawn Policy Enforcement
The system SHALL enforce spawn policy limits on parallelism and depth.

#### Scenario: Max parallel enforcement
- **WHEN** concurrent subagents reach `max_parallel`
- **THEN** new spawns wait until a slot is available

#### Scenario: Max depth enforcement
- **WHEN** spawn depth reaches `max_depth`
- **THEN** further spawns are rejected

### Requirement: Task Decomposition
The system SHALL decompose complex goals into subtasks.

#### Scenario: Decompose goal
- **WHEN** `decompose_task(goal)` is called
- **THEN** the goal is broken into prioritized subtasks

#### Scenario: Subtask priority
- **WHEN** subtasks are generated
- **THEN** each has a priority level (CRITICAL, HIGH, MEDIUM, LOW, BACKGROUND)

### Requirement: Orchestration Progress Tracking
The system SHALL track progress of orchestrated tasks.

#### Scenario: Track role status
- **WHEN** a role completes its work
- **THEN** its status is updated to COMPLETED

#### Scenario: Track overall progress
- **WHEN** querying manifest status
- **THEN** overall completion percentage is returned
