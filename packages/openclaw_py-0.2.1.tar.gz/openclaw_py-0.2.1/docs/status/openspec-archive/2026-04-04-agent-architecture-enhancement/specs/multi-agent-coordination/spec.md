## ADDED Requirements

### Requirement: Built-in Agent Types
The system SHALL provide four built-in agent types: Explore, Plan, Verification, and GeneralPurpose.

#### Scenario: List built-in agents
- **WHEN** querying available agent types
- **THEN** Explore, Plan, Verification, GeneralPurpose are listed

#### Scenario: Select agent by type
- **WHEN** spawning a subagent with type "explore"
- **THEN** the Explore agent configuration is used

### Requirement: Explore Agent
The system SHALL provide an Explore agent specialized for codebase navigation.

#### Scenario: Explore agent tools
- **WHEN** an Explore agent is spawned
- **THEN** it has access to Glob, Grep, Read tools

#### Scenario: Explore agent system prompt
- **WHEN** an Explore agent runs
- **THEN** it uses a system prompt optimized for codebase exploration

### Requirement: Plan Agent
The system SHALL provide a Plan agent specialized for task decomposition.

#### Scenario: Plan agent tools
- **WHEN** a Plan agent is spawned
- **THEN** it has access to Todo, Read, Bash tools

#### Scenario: Plan agent output
- **WHEN** a Plan agent completes
- **THEN** it outputs a structured plan with steps

### Requirement: Verification Agent
The system SHALL provide a Verification agent for result validation.

#### Scenario: Verification agent tools
- **WHEN** a Verification agent is spawned
- **THEN** it has access to Bash, Read, and test tools

#### Scenario: Verification agent output
- **WHEN** a Verification agent completes
- **THEN** it outputs pass/fail status with evidence

### Requirement: Agent Forking
The system SHALL support forking agents with inherited context.

#### Scenario: Fork from parent session
- **WHEN** `fork_subagent()` is called
- **THEN** a new subagent is created with shallow copy of parent messages

#### Scenario: Tool filter on fork
- **WHEN** forking with `tools_filter=["read", "grep"]`
- **THEN** the forked agent only has access to specified tools

#### Scenario: Fork depth limit
- **WHEN** fork depth exceeds MAX_DEPTH
- **THEN** an error is returned

### Requirement: Coordinator Mode
The system SHALL provide coordinator mode for multi-agent task orchestration.

#### Scenario: Start coordinator mode
- **WHEN** `CoordinatorMode` is activated
- **THEN** the system accepts high-level goals for decomposition

#### Scenario: Task decomposition
- **WHEN** a goal is submitted to coordinator
- **THEN** it is decomposed into subtasks with agent assignments

#### Scenario: Parallel execution
- **WHEN** multiple subtasks are independent
- **THEN** they are executed in parallel by different agents

### Requirement: Agent Teams
The system SHALL support team-based agent collaboration with shared state.

#### Scenario: Create agent team
- **WHEN** a team is created with multiple agents
- **THEN** agents share access to team memory

#### Scenario: Team coordination
- **WHEN** agents in a team complete subtasks
- **THEN** results are aggregated by the coordinator

### Requirement: Agent Steering
The system SHALL support steering running agents with new instructions.

#### Scenario: Send steering instruction
- **WHEN** `steer(session_id, instruction)` is called
- **THEN** the instruction is appended to the agent's context

#### Scenario: Steering for stuck agents
- **WHEN** an agent is stuck or looping
- **THEN** steering can redirect its approach
