## ADDED Requirements

### Requirement: Unified Tool Registry
The system SHALL provide a single registry for all tools from built-in, skills, plugins, and MCP sources.

#### Scenario: Register built-in tool
- **WHEN** a built-in tool is registered
- **THEN** it is available via the unified registry

#### Scenario: Register skill as tool
- **WHEN** a skill is loaded
- **THEN** it is converted to an AgentTool and registered

#### Scenario: Register MCP tool
- **WHEN** an MCP server provides tools
- **THEN** they are registered as AgentTool instances

### Requirement: Tool Lookup
The system SHALL provide unified tool lookup by name with namespace support.

#### Scenario: Lookup by simple name
- **WHEN** looking up "read_file"
- **THEN** the built-in ReadTool is returned

#### Scenario: Lookup by namespaced name
- **WHEN** looking up "skill:debug"
- **THEN** the debug skill tool is returned

#### Scenario: Lookup non-existent tool
- **WHEN** looking up a tool that doesn't exist
- **THEN** None is returned

### Requirement: Tool Enumeration
The system SHALL enumerate all available tools with source metadata.

#### Scenario: List all tools
- **WHEN** `all_tools()` is called
- **THEN** a list of all registered tools is returned with source info

#### Scenario: Filter by source
- **WHEN** filtering tools by source "mcp"
- **THEN** only MCP-sourced tools are returned

### Requirement: Tool Name Collision Resolution
The system SHALL resolve tool name collisions with priority-based resolution.

#### Scenario: Built-in tool priority
- **WHEN** a skill has the same name as a built-in tool
- **THEN** the built-in tool takes priority

#### Scenario: MCP tool namespace prefix
- **WHEN** an MCP tool has a name collision
- **THEN** it is prefixed with "mcp:" to disambiguate

### Requirement: Dynamic Tool Loading
The system SHALL support dynamic loading and unloading of tools at runtime.

#### Scenario: Load skill tools dynamically
- **WHEN** a new skill is installed
- **THEN** its tools are registered without restart

#### Scenario: Unload tools on plugin disable
- **WHEN** a plugin is disabled
- **THEN** its tools are unregistered from the registry
