## Why

Current PyClaw Agent architecture lacks several advanced capabilities present in the reference claw-code-parity design, particularly in **Memory orchestration**, **Context management**, **Skills/Plugins/MCP/Tools unified management**, and **Multi-agent coordination**. These gaps limit the system's ability to handle complex multi-step tasks, maintain rich conversational context, and coordinate multiple specialized agents working in parallel.

The reference project reveals structured subsystems for `memdir` (8 modules for memory management), `skills` (20 modules for skill loading/management), `coordinator` (multi-agent orchestration), and comprehensive `AgentTool` infrastructure with built-in agents for exploration, planning, and verification. PyClaw needs to evolve its architecture to match these capabilities while maintaining Python idioms.

## What Changes

### Memory System Enhancements
- **Memory Directory Structure**: Implement `.claude/memory/` hierarchy with project-level vs session-level memories (matching `memdir/` subsystem)
- **Team Memory Paths**: Support shared memory across agent teams with `teamMemPaths` and `teamMemPrompts`
- **Memory Age & Relevance**: Add temporal decay and relevance scoring for memory retrieval (`memoryAge.ts`, `findRelevantMemories.ts`)
- **Memory Types**: Define structured memory types (user preferences, project decisions, feedback records, reference links)

### Context Manager Improvements
- **Context Compaction Policy**: Implement intelligent context truncation with summary preservation
- **Cross-Session Context**: Persist and restore context across agent sessions
- **Context Injection Hooks**: Pre/post reasoning hooks for dynamic context enrichment

### Skills/Plugins/MCP/Tools Management
- **Unified Tool Registry**: Create single source of truth for all tools (built-in, skills, plugins, MCP)
- **Skill Discovery & Loading**: Implement `loadSkillsDir` functionality with skill metadata parsing
- **Bundled Skills**: Port essential bundled skills (`batch`, `debug`, `verify`, `simplify`, `loop`, `scheduleRemoteAgents`)
- **MCP Skill Builders**: Bridge MCP tools as invocable skills
- **Plugin Lifecycle**: Full plugin install/enable/disable/uninstall flow

### SubAgent & Multi-Agent Coordination
- **Built-in Agent Types**: Add specialized agents (Explore, Plan, Verification, GeneralPurpose)
- **Fork Subagent**: Implement agent forking with context inheritance
- **Coordinator Mode**: Add coordinator orchestration for multi-agent task decomposition
- **Agent Teams**: Support team-based agent collaboration with shared state
- **Agent Memory Snapshot**: Capture and restore agent memory state

## Capabilities

### New Capabilities
- `memory-directory`: Structured memory directory with project/session levels, team memory support, and temporal relevance scoring
- `context-manager`: Intelligent context compaction, cross-session persistence, and context injection hooks
- `unified-tool-registry`: Single registry for built-in tools, skills, plugins, and MCP tools with dynamic loading
- `skill-system`: Skill discovery, loading, metadata parsing, and bundled skill execution
- `multi-agent-coordination`: Built-in agent types, fork/steer/kill operations, coordinator mode, and team collaboration
- `agent-memory-snapshot`: Memory state capture, restore, and inheritance for subagents

### Modified Capabilities
- `subagents`: Enhanced SubagentManager with fork capability, built-in agent types, and memory inheritance
- `orchestration`: Enhanced manifest with team support, dependency ordering, and agent lifecycle

## Impact

### Core Changes
- `src/pyclaw/agents/runner.py` — Add context manager integration, memory hooks
- `src/pyclaw/agents/subagents/` — Major enhancement for fork, built-in agents, memory snapshot
- `src/pyclaw/agents/orchestration/` — Add coordinator mode, team support
- `src/pyclaw/agents/skills/` — Add skill discovery, bundled skills, MCP bridge
- `src/pyclaw/agents/tools/` — Unified tool registry refactoring

### New Modules
- `src/pyclaw/agents/context/` — Context manager, compaction policy
- `src/pyclaw/agents/memory_dir/` — Memory directory management
- `src/pyclaw/agents/coordinator/` — Multi-agent coordinator
- `src/pyclaw/agents/builtin_agents/` — Built-in agent implementations

### Breaking Changes
- **BREAKING**: Tool registry interface changes — tools must implement `AgentTool` protocol
- **BREAKING**: Session manager API extended — requires context manager integration

### Dependencies
- No new external dependencies required
- Internal refactoring to maintain backward compatibility where possible
