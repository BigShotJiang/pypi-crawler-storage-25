## Context

PyClaw is a multi-channel AI gateway that connects AI Agents to 25+ messaging platforms. The current Agent architecture provides basic agent loop functionality (`runner.py`), subagent management (`subagents/manager.py`), and simple orchestration (`orchestration/`). However, comparing against the reference claw-code-parity project reveals significant gaps in:

1. **Memory Architecture**: Current memory system is basic SQLite + LanceDB without structured memory directories, team memory support, or temporal relevance scoring
2. **Context Management**: No intelligent context compaction, cross-session context persistence, or context injection hooks
3. **Tool/Skill/Plugin/MCP Unification**: Separate registries and loading mechanisms without unified management
4. **Multi-Agent Coordination**: Basic subagent spawning without built-in agent types, forking, or coordinator mode

The reference project shows structured subsystems:
- `memdir/` (8 modules) — memory directory, team memory, relevance scoring
- `skills/` (20 modules) — skill discovery, bundled skills, MCP bridge
- `coordinator/` — multi-agent orchestration
- `AgentTool/` (15+ modules) — built-in agents, forking, memory snapshots

### Constraints
- Must maintain backward compatibility with existing `AgentTool` protocol
- Must work with existing SessionManager and Gateway infrastructure
- Must be Python-native (no Node.js dependency for skills)
- Must support both CLI and UI modes

### Stakeholders
- Agent developers (API users)
- Skill/plugin authors
- End users (via improved agent capabilities)

## Goals / Non-Goals

**Goals:**
1. Implement structured memory directory with project/session levels and team memory support
2. Create intelligent context manager with compaction and cross-session persistence
3. Unify tool/skill/plugin/MCP management into single registry
4. Add built-in agent types (Explore, Plan, Verification, GeneralPurpose)
5. Implement agent forking with context inheritance
6. Add coordinator mode for multi-agent task decomposition
7. Support agent memory snapshots for state capture/restore

**Non-Goals:**
- Full TypeScript API compatibility (Python idioms preferred)
- Real-time collaborative editing (out of scope)
- Distributed agent execution across machines (future work)
- Visual agent flow builder (UI feature, separate effort)

## Decisions

### D1: Memory Directory Structure

**Decision**: Implement `.claude/memory/` hierarchy with typed memory entries.

**Rationale**: Reference project uses `memdir/` with structured paths for different memory types (user, project, session, team). This provides better organization than a single SQLite store.

**Alternatives Considered**:
- Single SQLite table with tags — rejected: less navigable, harder to manage
- Pure vector store — rejected: loses structure, harder to debug

**Structure**:
```
.claude/memory/
├── project/          # Project-level decisions
│   └── decisions.jsonl
├── session/          # Session-specific memories
│   └── {session_id}.jsonl
├── team/             # Shared team memories
│   └── shared.jsonl
└── user/             # User preferences
    └── preferences.jsonl
```

### D2: Context Manager Implementation

**Decision**: Create `ContextManager` class with hook-based preprocessing.

**Rationale**: Reference project has sophisticated context compaction (`ContextChecker`, `MemorySummarizer`). Python implementation should use composition with hooks.

**Key Components**:
- `ContextCompactor` — truncates large tool outputs, summarizes old messages
- `ContextInjector` — injects memory context before reasoning
- `ContextPersistor` — saves/restores context across sessions

**Hook Points**:
- `pre_reasoning` — context compaction, memory injection
- `post_turn` — context persistence
- `on_compaction` — summary generation

### D3: Unified Tool Registry

**Decision**: Create `UnifiedToolRegistry` that aggregates tools from multiple sources.

**Rationale**: Current `ToolRegistry` only handles built-in tools. Need to unify:
- Built-in tools (`tools/*.py`)
- Skills (`skills/` directory)
- MCP tools (from MCP servers)
- Plugins (future)

**Implementation**:
```python
class UnifiedToolRegistry:
    def __init__(self):
        self._builtins: dict[str, AgentTool]
        self._skills: dict[str, SkillTool]
        self._mcp: dict[str, MCPTool]
        self._plugins: dict[str, PluginTool]

    def all_tools(self) -> list[AgentTool]: ...
    def get_tool(self, name: str) -> AgentTool | None: ...
    def register_skill(self, skill: SkillEntry) -> None: ...
    def register_mcp_tool(self, tool: MCPTool) -> None: ...
```

### D4: Built-in Agent Types

**Decision**: Implement 4 built-in agent types as Python classes.

**Rationale**: Reference project has `built-in/` agents (explore, plan, verification, general). These provide specialized behavior for common tasks.

**Agent Types**:
| Type | Purpose | Tools | System Prompt |
|------|---------|-------|---------------|
| Explore | Codebase exploration | Glob, Grep, Read | "Navigate and understand code..." |
| Plan | Task decomposition | Todo, Read, Bash | "Break down tasks..." |
| Verification | Result validation | Bash, Read, Test | "Verify correctness..." |
| GeneralPurpose | Default | All tools | "Complete the task..." |

### D5: Agent Forking

**Decision**: Implement `fork_subagent()` with shallow copy of parent context.

**Rationale**: Reference project has `forkSubagent.ts` for spawning agents that inherit parent context. This enables parallel exploration while maintaining context.

**Implementation**:
```python
async def fork_subagent(
    parent_session: SessionManager,
    prompt: str,
    tools_filter: list[str] | None = None,
) -> SubagentResult:
    # Shallow copy parent messages
    # Apply tool filter
    # Run with inherited context
```

### D6: Coordinator Mode

**Decision**: Implement `CoordinatorMode` class for multi-agent orchestration.

**Rationale**: Reference project has `coordinatorMode.ts` for coordinating multiple agents on complex tasks. This is essential for large-scale automation.

**Key Features**:
- Task decomposition into subtasks
- Agent assignment based on specialization
- Progress tracking and aggregation
- Error recovery and retry

### D7: Memory Snapshot

**Decision**: Implement `AgentMemorySnapshot` for state capture/restore.

**Rationale**: Reference project has `agentMemorySnapshot.ts` for capturing agent state. Useful for:
- Checkpointing long-running tasks
- Transferring context between agents
- Debugging and introspection

**Format**:
```python
@dataclass
class AgentMemorySnapshot:
    session_id: str
    messages: list[dict]
    tool_results: dict[str, Any]
    preferences: dict[str, str]
    decisions: list[dict]
    created_at: datetime
```

## Risks / Trade-offs

### Risk 1: Memory Consistency
- **Risk**: Concurrent access to memory directory could cause corruption
- **Mitigation**: Use file locking (`.lock` files) for concurrent access; SQLite WAL mode for database

### Risk 2: Context Explosion
- **Risk**: Memory snapshots could grow unbounded
- **Mitigation**: Implement size limits and automatic pruning; use compression for old snapshots

### Risk 3: Tool Name Collisions
- **Risk**: Skills/MCP tools might have same name as built-in tools
- **Mitigation**: Namespace prefixing (`skill:`, `mcp:`) or priority-based resolution

### Risk 4: Breaking Changes
- **Risk**: New tool registry interface breaks existing code
- **Mitigation**: Provide compatibility layer; deprecate gradually with warnings

### Trade-off: Complexity vs Flexibility
- **Trade-off**: Unified registry adds complexity but enables powerful tool composition
- **Acceptance**: Flexibility is worth the complexity for multi-agent scenarios

## Migration Plan

### Phase 1: Memory Directory (Week 1)
1. Create `memory_dir/` module with path management
2. Implement `MemoryDirectory` class
3. Add migration script from existing SQLite to directory structure
4. Update `MemoryManager` to use new structure

### Phase 2: Context Manager (Week 1-2)
1. Create `context/` module with `ContextManager`
2. Implement compaction algorithms
3. Add hook integration
4. Update `runner.py` to use context manager

### Phase 3: Unified Registry (Week 2-3)
1. Create `UnifiedToolRegistry` class
2. Migrate skill loading to unified registry
3. Integrate MCP tools
4. Update all tool consumers

### Phase 4: Built-in Agents (Week 3-4)
1. Implement `BuiltinAgentRegistry`
2. Create Explore, Plan, Verification agents
3. Add agent type selection to `SubagentManager`

### Phase 5: Forking & Coordinator (Week 4-5)
1. Implement `fork_subagent()` function
2. Create `CoordinatorMode` class
3. Add to orchestration tools

### Phase 6: Memory Snapshot (Week 5-6)
1. Create `AgentMemorySnapshot` dataclass
2. Implement capture/restore functions
3. Add to agent API

### Rollback Strategy
- All new modules are additive; can disable features via config flags
- Memory directory has fallback to SQLite
- Old tool registry API remains available with deprecation warnings

## Open Questions

1. **Memory Priority**: Should team memory override session memory or vice versa?
   - **Current Assumption**: Session > Team > Project > User (most specific wins)

2. **Skill Sandbox**: How to isolate skill execution for security?
   - **Options**: Restricted Python (`__import__` filtering), subprocess, or WASM
   - **Need**: Security review before production

3. **Coordinator Strategy**: Should coordinator use polling or event-driven orchestration?
   - **Current Assumption**: Polling with configurable interval (simpler, more predictable)

4. **Fork Depth Limits**: What's the maximum fork depth?
   - **Current Assumption**: Match `MAX_DEPTH = 5` from current subagent limits

5. **Memory Indexing**: Should memory files be indexed for fast search?
   - **Options**: SQLite FTS5 (current), LanceDB, or Whoosh
   - **Need**: Performance benchmarking
