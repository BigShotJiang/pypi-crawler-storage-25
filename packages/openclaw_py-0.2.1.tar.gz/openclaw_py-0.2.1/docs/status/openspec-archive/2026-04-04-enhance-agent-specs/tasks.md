## 1. Memory Scan Implementation

- [x] 1.1 Add `scan_memory_directory()` function to discover JSONL files
- [x] 1.2 Add `parse_memory_entry()` function to parse individual entries
- [x] 1.3 Add `MemoryScanner` class with error handling for corrupted entries
- [x] 1.4 Add inverted index builder for term-based searching
- [x] 1.5 Add incremental index update support
- [x] 1.6 Add index persistence to `.claude/memory/index.json`
- [x] 1.7 Add unit tests for memory scanning

## 2. BM25 Relevance Scoring

- [x] 2.1 Add `BM25Scorer` class with configurable parameters (k1=1.5, b=0.75)
- [x] 2.2 Implement term frequency normalization
- [x] 2.3 Add `calculate_relevance_score()` combining BM25 and decay
- [x] 2.4 Add unit tests for BM25 scoring

## 3. Temporal Decay Implementation

- [x] 3.1 Add `TemporalDecayCalculator` class
- [x] 3.2 Implement decay formula: `exp(-decay_rate * age_days)`
- [x] 3.3 Add configurable decay_rate parameter
- [x] \1 Add unit tests for temporal decay

## 4. Memory Migration

- [x] 4.1 Add `detect_sqlite_database()` function
- [x] 4.2 Add `migrate_sqlite_to_jsonl()` function
- [x] 4.3 Preserve entry IDs during migration
- [x] 4.4 Add migration CLI command
- [x] 4.5 Add integration tests for migration

## 5. Token Estimation Enhancement

- [x] 5.1 Add `TokenEstimator` class using tiktoken cl100k_base
- [x] 5.2 Add `estimate_tokens()` for message lists
- [x] 5.3 Add `get_token_breakdown()` by role and content type
- [x] 5.4 Add token budget tracking and warning threshold
- [x] \1 Add unit tests for token estimation

## 6. Compression Priority Strategy

- [x] 6.1 Add `CompressionPriority` enum (SYSTEM, RECENT, TOOL_RESULT, HISTORY)
- [x] 6.2 Implement priority-based message sorting
- [x] 6.3 Add system message preservation logic
- [x] 6.4 Add configurable `preserve_recent_count` parameter
- [x] \1 Add unit tests for compression priority

## 7. LLM Summary Generation

- [x] 7.1 Add `ContextSummarizer` class
- [x] 7.2 Design structured summary prompt template
- [x] 7.3 Add model selection (default to Haiku)
- [x] 7.4 Include summary format: key decisions, current state, pending tasks
- [x] \1 Add unit tests for summary generation

## 8. Context Checkpoint

- [x] 8.1 Add `create_checkpoint()` method to ContextPersistor
- [x] 8.2 Add `restore_checkpoint()` method
- [x] 8.3 Add automatic checkpoint creation on significant turns
- [x] 8.4 Add checkpoint cleanup for old checkpoints
- [x] \1 Add unit tests for checkpoint functionality

## 9. Subagent State Machine

- [x] 9.1 Add `SubagentState` enum with five states
- [x] 9.2 Implement state transition validation
- [x] 9.3 Add state persistence for restart recovery
- [x] 9.4 Add `StateMachine` class with transition logging
- [x] \1 Add unit tests for state machine

## 10. Subagent Timeout Handling

- [x] 10.1 Add timeout enforcement in `SubagentManager`
- [x] 10.2 Add `timed_out` state and cleanup logic
- [x] 10.3 Add timeout notification to parent agent
- [x] 10.4 Add configurable timeout per agent type
- [x] \1 Add unit tests for timeout handling

## 11. Subagent Error Recovery

- [x] 11.1 Add automatic retry logic with `max_retries`
- [x] 11.2 Add fallback strategies: skip, continue, abort
- [x] 11.3 Add error context preservation
- [x] 11.4 Add error recovery CLI commands
- [x] \1 Add unit tests for error recovery

## 12. Steering Protocol Enhancement

- [x] 12.1 Add `steer()` method with message injection
- [x] 12.2 Add steering message format (role="user")
- [x] 12.3 Add stuck agent detection (no progress for N turns)
- [x] 12.4 Add automatic steering for stuck agents
- [x] \1 Add unit tests for steering protocol

## 13. DAG Dependency Resolution

- [x] 13.1 Add `DAGBuilder` class to construct dependency graph
- [x] 13.2 Add circular dependency detection with cycle path reporting
- [x] 13.3 Add topological sort implementation
- [x] 13.4 Add dependency validation on manifest creation
- [x] \1 Add unit tests for DAG resolution

## 14. Parallel Execution Strategy

- [x] 14.1 Add `ParallelExecutor` class
- [x] 14.2 Identify parallel candidates from DAG
- [x] 14.3 Implement concurrent execution with asyncio
- [x] 14.4 Add resource affinity scheduling
- [x] \1 Add unit tests for parallel execution

## 15. Failure Propagation

- [x] 15.1 Add `mark_dependents_blocked()` on task failure
- [x] 15.2 Add partial result collection
- [x] 15.3 Add failure report generation
- [x] \1 Add unit tests for failure propagation

## 16. Manifest Serialization

- [x] 16.1 Add `ManifestSerializer` class
- [x] 16.2 Add JSON serialization with schema validation
- [x] 16.3 Add version compatibility check
- [x] 16.4 Add manifest upgrade migration
- [x] \1 Add unit tests for serialization

## 17. Namespace Prefix Resolution

- [x] 17.1 Add explicit prefix parsing (skill:, mcp:, plugin:)
- [x] 17.2 Update `get()` to handle prefixed names
- [x] 17.3 Add `get_by_prefix()` method
- [x] \1 Add unit tests for namespace resolution

## 18. MCP Bridge Enhancement

- [x] 18.1 Add MCP tool schema to AgentTool conversion
- [x] 18.2 Add tool call routing to MCP server
- [x] 18.3 Add disconnect detection and tool unavailability
- [x] 18.4 Add reconnection handling
- [x] 18.5 Add integration tests for MCP bridge

## 19. Tool Permission Filtering

- [x] 19.1 Add `filter_by_permission()` method
- [x] 19.2 Add permission mode filtering (read-only, workspace-write)
- [x] 19.3 Add allowed/denied list filtering
- [x] \1 Add unit tests for permission filtering

## 20. Tool Metadata Enrichment

- [x] 20.1 Add metadata merge from skill definitions
- [x] 20.2 Add source information to tool metadata
- [x] 20.3 Add metadata caching
- [x] 20.4 Add `get_tool_info()` method with enriched metadata
- [x] \1 Add unit tests for metadata enrichment

## 21. Integration Tests

- [x] 21.1 Add end-to-end test for memory scan → relevance scoring flow
- [x] 21.2 Add end-to-end test for context compaction with LLM summary
- [x] 21.3 Add end-to-end test for subagent lifecycle with timeout
- [x] 21.4 Add end-to-end test for DAG orchestration with failure
- [x] 21.5 Add end-to-end test for tool registry with MCP bridge

## 22. Documentation

- [x] 22.1 Update architecture.md with new components
- [x] 22.2 Add API reference for new public interfaces
- [x] 22.3 Add configuration guide for new parameters
- [x] 22.4 Add troubleshooting guide for common issues
