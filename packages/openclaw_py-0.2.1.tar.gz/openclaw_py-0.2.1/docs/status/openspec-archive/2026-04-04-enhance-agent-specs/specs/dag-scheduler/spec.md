## ADDED Requirements

### Requirement: DAG Dependency Resolution
The system SHALL resolve task dependencies into a directed acyclic graph.

#### Scenario: Parse task dependencies
- **WHEN** tasks with dependencies are submitted
- **THEN** a DAG is constructed from dependency relationships

#### Scenario: Detect circular dependencies
- **WHEN** circular dependencies are detected
- **THEN** an error is raised with the cycle path

#### Scenario: Topological sort
- **WHEN** DAG is constructed
- **THEN** tasks are ordered by topological sort

### Requirement: Parallel Execution
The system SHALL execute independent tasks in parallel.

#### Scenario: Execute parallel tasks
- **WHEN** multiple tasks have no unmet dependencies
- **THEN** they are executed concurrently up to max_parallel limit

#### Scenario: Respect max_parallel limit
- **WHEN** running tasks reach max_parallel
- **THEN** new tasks wait until a slot is available

#### Scenario: Resource affinity
- **WHEN** tasks specify resource requirements
- **THEN** tasks are scheduled respecting resource constraints

### Requirement: Failure Propagation
The system SHALL propagate failures to dependent tasks.

#### Scenario: Fail dependent tasks
- **WHEN** a task fails
- **THEN** all tasks depending on it are marked as blocked

#### Scenario: Partial completion
- **WHEN** some tasks fail but others succeed
- **THEN** successful task results are preserved

#### Scenario: Retry failed tasks
- **WHEN** retry is enabled
- **THEN** failed tasks are retried up to max_retries

### Requirement: Progress Tracking
The system SHALL track execution progress of the DAG.

#### Scenario: Track task status
- **WHEN** a task status changes
- **THEN** overall progress percentage is updated

#### Scenario: Progress callback
- **WHEN** a progress callback is registered
- **THEN** it is called on each status change

#### Scenario: Progress report
- **WHEN** progress is queried
- **THEN** completed/total count and percentage are returned
