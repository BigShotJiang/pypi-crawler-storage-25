## ADDED Requirements

### Requirement: Memory Scan Algorithm
The system SHALL scan memory directory to discover and parse memory entries.

#### Scenario: Scan memory directory
- **WHEN** `scan_memory_directory(path)` is called
- **THEN** all JSONL files in the directory are discovered

#### Scenario: Parse memory entries
- **WHEN** memory files are discovered
- **THEN** each line is parsed as a MemoryEntry object

#### Scenario: Handle corrupted entries
- **WHEN** a line cannot be parsed as valid JSON
- **THEN** the entry is logged as warning and skipped

### Requirement: Memory Entry Extraction
The system SHALL extract structured fields from raw memory entries.

#### Scenario: Extract entry fields
- **WHEN** parsing a memory entry
- **THEN** `id`, `type`, `content`, `created_at`, `priority` fields are extracted

#### Scenario: Validate required fields
- **WHEN** an entry is missing required fields
- **THEN** a warning is logged and the entry is skipped

#### Scenario: Parse entry metadata
- **WHEN** an entry has a `metadata` field
- **THEN** metadata is parsed as a dictionary

### Requirement: Memory Index Building
The system SHALL build an inverted index for efficient searching.

#### Scenario: Build term index
- **WHEN** memory entries are scanned
- **THEN** an inverted index mapping terms to entry IDs is built

#### Scenario: Update index incrementally
- **WHEN** new entries are added
- **THEN** the index is updated without full rebuild

#### Scenario: Index persistence
- **WHEN** index is built
- **THEN** it is persisted to `.claude/memory/index.json`
