## MODIFIED Requirements

### Requirement: Unified Tool Registry
The system SHALL provide a single registry for all tools from built-in, skills, plugins, and MCP sources.

#### Scenario: Register built-in tool
- **WHEN** a built-in tool is registered
- **THEN** it is available via the unified registry

#### Scenario: Register skill as tool
- **WHEN** a skill is loaded
- **THEN** it is converted to an AgentTool and registered

#### Scenario: Register MCP tool
- **WHEN** an MCP server provides tools
- **THEN** they are registered as AgentTool instances

### Requirement: Tool Lookup
The system SHALL provide unified tool lookup by name with namespace support.

#### Scenario: Lookup by simple name
- **WHEN** looking up "read_file"
- **THEN** the built-in ReadTool is returned

#### Scenario: Lookup by namespaced name
- **WHEN** looking up "skill:debug"
- **THEN** the debug skill tool is returned

#### Scenario: Lookup non-existent tool
- **WHEN** looking up a tool that doesn't exist
- **THEN** None is returned

### Requirement: Tool Enumeration
The system SHALL enumerate all available tools with source metadata.

#### Scenario: List all tools
- **WHEN** `all_tools()` is called
- **THEN** a list of all registered tools is returned with source info

#### Scenario: Filter by source
- **WHEN** filtering tools by source "mcp"
- **THEN** only MCP-sourced tools are returned

### Requirement: Tool Name Collision Resolution
The system SHALL resolve tool name collisions with priority-based resolution.

#### Scenario: Built-in tool priority
- **WHEN** a skill has the same name as a built-in tool
- **THEN** the built-in tool takes priority

#### Scenario: MCP tool namespace prefix
- **WHEN** an MCP tool has a name collision
- **THEN** it is prefixed with "mcp:" to disambiguate

### Requirement: Dynamic Tool Loading
The system SHALL support dynamic loading and unloading of tools at runtime.

#### Scenario: Load skill tools dynamically
- **WHEN** a new skill is installed
- **THEN** its tools are registered without restart

#### Scenario: Unload tools on plugin disable
- **WHEN** a plugin is disabled
- **THEN** its tools are unregistered from the registry

## ADDED Requirements

### Requirement: Namespace Prefix Resolution
The system SHALL support explicit namespace prefixes for tool lookup.

#### Scenario: skill: prefix
- **WHEN** looking up "skill:debug"
- **THEN** only skill-sourced tools are searched

#### Scenario: mcp: prefix
- **WHEN** looking up "mcp:filesystem"
- **THEN** only MCP-sourced tools are searched

#### Scenario: plugin: prefix
- **WHEN** looking up "plugin:custom"
- **THEN** only plugin-sourced tools are searched

### Requirement: MCP Bridge Protocol
The system SHALL bridge MCP tools with unified tool interface.

#### Scenario: Convert MCP tool schema
- **WHEN** an MCP tool is registered
- **THEN** its JSON schema is converted to AgentTool format

#### Scenario: Route tool calls to MCP
- **WHEN** an MCP tool is invoked
- **THEN** the call is routed to the MCP server

#### Scenario: Handle MCP server disconnect
- **WHEN** an MCP server disconnects
- **THEN** its tools are marked as unavailable

### Requirement: Tool Permission Filtering
The system SHALL filter tools based on permission context.

#### Scenario: Filter by permission mode
- **WHEN** permission mode is "read-only"
- **THEN** only read-only tools are available

#### Scenario: Filter by allowed list
- **WHEN** an allowed list is configured
- **THEN** only tools in the list are available

#### Scenario: Block denied tools
- **WHEN** a denied list is configured
- **THEN** tools in the list are not available

### Requirement: Tool Metadata Enrichment
The system SHALL enrich tool metadata from multiple sources.

#### Scenario: Merge skill metadata
- **WHEN** a skill tool is registered
- **THEN** skill metadata (description, tags) is merged

#### Scenario: Add source information
- **WHEN** a tool is queried
- **THEN** source information (builtin/skill/mcp/plugin) is included

#### Scenario: Cache metadata
- **WHEN** tool metadata is accessed frequently
- **THEN** it is cached for performance
