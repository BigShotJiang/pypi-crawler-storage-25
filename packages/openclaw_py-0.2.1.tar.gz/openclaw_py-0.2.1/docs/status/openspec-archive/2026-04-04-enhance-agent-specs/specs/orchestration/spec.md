## MODIFIED Requirements

### Requirement: Orchestration Manifest
The system SHALL create orchestration manifests with team support and dependency ordering.

#### Scenario: Create manifest with roles
- **WHEN** `orchestrate_manifest` is called with goal and subtasks
- **THEN** a manifest with roles for each subtask is created

#### Scenario: Manifest with dependencies
- **WHEN** subtasks have dependencies on each other
- **THEN** dependencies are encoded in the manifest

#### Scenario: Manifest with team configuration
- **WHEN** creating a manifest for a team
- **THEN** team member assignments are included

### Requirement: Spawn Policy Enforcement
The system SHALL enforce spawn policy limits on parallelism and depth.

#### Scenario: Max parallel enforcement
- **WHEN** concurrent subagents reach `max_parallel`
- **THEN** new spawns wait until a slot is available

#### Scenario: Max depth enforcement
- **WHEN** spawn depth reaches `max_depth`
- **THEN** further spawns are rejected

### Requirement: Task Decomposition
The system SHALL decompose complex goals into subtasks.

#### Scenario: Decompose goal
- **WHEN** `decompose_task(goal)` is called
- **THEN** the goal is broken into prioritized subtasks

#### Scenario: Subtask priority
- **WHEN** subtasks are generated
- **THEN** each has a priority level (CRITICAL, HIGH, MEDIUM, LOW, BACKGROUND)

### Requirement: Orchestration Progress Tracking
The system SHALL track progress of orchestrated tasks.

#### Scenario: Track role status
- **WHEN** a role completes its work
- **THEN** its status is updated to COMPLETED

#### Scenario: Track overall progress
- **WHEN** querying manifest status
- **THEN** overall completion percentage is returned

## ADDED Requirements

### Requirement: DAG Dependency Resolution
The system SHALL resolve task dependencies using DAG algorithms.

#### Scenario: Build dependency graph
- **WHEN** tasks with dependencies are submitted
- **THEN** a directed acyclic graph is constructed

#### Scenario: Detect circular dependencies
- **WHEN** circular dependencies exist
- **THEN** an error is raised identifying the cycle

#### Scenario: Topological execution order
- **WHEN** DAG is constructed
- **THEN** tasks are ordered for sequential execution respecting dependencies

### Requirement: Parallel Execution Strategy
The system SHALL execute independent tasks in parallel.

#### Scenario: Identify parallel candidates
- **WHEN** DAG is analyzed
- **THEN** tasks with no unmet dependencies are identified for parallel execution

#### Scenario: Respect concurrency limit
- **WHEN** executing tasks in parallel
- **THEN** no more than `max_parallel` tasks run concurrently

#### Scenario: Resource affinity scheduling
- **WHEN** tasks specify resource requirements
- **THEN** scheduler respects resource constraints

### Requirement: Failure Propagation
The system SHALL propagate failures to dependent tasks.

#### Scenario: Block dependent tasks
- **WHEN** a task fails
- **THEN** all downstream dependent tasks are marked as blocked

#### Scenario: Continue independent tasks
- **WHEN** a task fails
- **THEN** tasks not depending on it continue execution

#### Scenario: Partial result collection
- **WHEN** orchestration completes with failures
- **THEN** successful results are collected and returned

### Requirement: Manifest Serialization
The system SHALL serialize manifests for persistence and transmission.

#### Scenario: Serialize to JSON
- **WHEN** manifest is serialized
- **THEN** it is converted to JSON format

#### Scenario: Deserialize from JSON
- **WHEN** manifest is loaded from JSON
- **THEN** all fields are restored correctly

#### Scenario: Manifest version compatibility
- **WHEN** deserializing manifest
- **THEN** version compatibility is checked
