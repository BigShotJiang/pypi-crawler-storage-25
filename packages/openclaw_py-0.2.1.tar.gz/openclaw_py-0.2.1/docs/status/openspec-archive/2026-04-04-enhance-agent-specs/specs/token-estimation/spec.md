## ADDED Requirements

### Requirement: Token Estimation
The system SHALL estimate token count for messages using configured encoding.

#### Scenario: Estimate message tokens
- **WHEN** `estimate_tokens(messages)` is called
- **THEN** total token count is returned

#### Scenario: Use tiktoken encoding
- **WHEN** estimating tokens
- **THEN** tiktoken cl100k_base encoding is used for GPT-4/claude compatibility

#### Scenario: Handle encoding errors
- **WHEN** text contains characters not in vocabulary
- **THEN** characters are handled gracefully without errors

### Requirement: Message Token Breakdown
The system SHALL provide token breakdown by message component.

#### Scenario: Breakdown by role
- **WHEN** token breakdown is requested
- **THEN** tokens are grouped by message role (system, user, assistant)

#### Scenario: Breakdown by content type
- **WHEN** messages contain multimodal content
- **THEN** tokens are grouped by content type (text, image, tool_result)

### Requirement: Token Budget Management
The system SHALL track token budget consumption.

#### Scenario: Track budget usage
- **WHEN** messages are processed
- **THEN** cumulative token usage is tracked

#### Scenario: Budget warning threshold
- **WHEN** token usage exceeds warning threshold (80% of max)
- **THEN** a warning is logged

#### Scenario: Budget exceeded
- **WHEN** token usage exceeds max_context_tokens
- **THEN** compaction is triggered
