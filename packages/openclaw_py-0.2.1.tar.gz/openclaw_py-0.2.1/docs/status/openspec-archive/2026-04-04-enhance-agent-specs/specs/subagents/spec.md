## MODIFIED Requirements

### Requirement: Subagent Spawning
The system SHALL spawn subagents with configurable agent types and memory inheritance.

#### Scenario: Spawn with built-in agent type
- **WHEN** spawning a subagent with `agent_type="explore"`
- **THEN** the Explore agent configuration is used

#### Scenario: Spawn with memory inheritance
- **WHEN** spawning a subagent with `inherit_memory=True`
- **THEN** the subagent receives a copy of parent's memory snapshot

#### Scenario: Spawn with depth tracking
- **WHEN** spawning a subagent
- **THEN** the depth is tracked and enforced against MAX_DEPTH

### Requirement: Subagent Lifecycle Management
The system SHALL manage the full lifecycle of subagents including spawn, steer, kill, and completion.

#### Scenario: List active subagents
- **WHEN** `list_active()` is called
- **THEN** all running subagents with their status are returned

#### Scenario: Kill subagent
- **WHEN** `kill(session_id)` is called on a running subagent
- **THEN** the subagent is aborted and cleaned up

#### Scenario: Steer subagent
- **WHEN** `steer(session_id, instruction)` is called
- **THEN** the instruction is injected into the subagent's context

### Requirement: Subagent Result Aggregation
The system SHALL aggregate results from completed subagents.

#### Scenario: Collect subagent results
- **WHEN** multiple subagents complete
- **THEN** their results are available via `list_completed()`

#### Scenario: Result metadata
- **WHEN** a subagent completes
- **THEN** result includes `session_id`, `state`, `output`, and `meta` fields

## ADDED Requirements

### Requirement: Subagent State Machine
The system SHALL implement a complete five-state lifecycle.

#### Scenario: State transitions
- **WHEN** a subagent transitions between states
- **THEN** valid transitions follow: pending→running→paused→completed/failed/cancelled

#### Scenario: Invalid transition rejection
- **WHEN** an invalid state transition is requested
- **THEN** an error is raised

#### Scenario: State persistence
- **WHEN** state changes
- **THEN** it is persisted to survive restarts

### Requirement: Subagent Timeout Handling
The system SHALL enforce timeout limits on subagent execution.

#### Scenario: Enforce timeout
- **WHEN** subagent execution exceeds timeout_seconds
- **THEN** the subagent is terminated and marked as timed_out

#### Scenario: Timeout cleanup
- **WHEN** a subagent times out
- **THEN** all resources are cleaned up

#### Scenario: Timeout notification
- **WHEN** a subagent times out
- **THEN** the parent agent is notified

### Requirement: Subagent Error Recovery
The system SHALL support error recovery for failed subagents.

#### Scenario: Automatic retry
- **WHEN** a subagent fails and retry_count < max_retries
- **THEN** the subagent is restarted with the same prompt

#### Scenario: Fallback strategy
- **WHEN** all retries are exhausted
- **THEN** a fallback strategy (skip, continue, abort) is applied

#### Scenario: Error context preservation
- **WHEN** a subagent fails
- **THEN** error context is preserved for debugging

### Requirement: Steering Protocol
The system SHALL support steering running subagents with new instructions.

#### Scenario: Inject steering message
- **WHEN** steering message is sent
- **THEN** it is appended to the subagent's message list

#### Scenario: Steering message format
- **WHEN** a steering message is injected
- **THEN** it uses role="user" with steering content

#### Scenario: Steering for stuck agents
- **WHEN** a subagent is detected as stuck (no progress for N turns)
- **THEN** an automatic steering message may be injected
