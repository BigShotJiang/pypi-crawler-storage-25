## Why

当前项目的 Agent 架构 Specs 已有基础定义，但缺乏深度的行为描述和边缘场景覆盖。参考 claw-code-parity 项目中的工具清单和架构模式，我们需要增强以下领域的规格说明：

1. **Memory Directory** — 缺少记忆扫描、相关性评分、时效衰减的详细算法描述
2. **Context Manager** — 缺少压缩策略、优先级保留、LLM摘要生成的详细流程
3. **Subagent Delegation** — 缺少生命周期管理、超时处理、错误恢复的完整流程
4. **Task Orchestration** — 缺少依赖解析、并行执行策略、进度跟踪的详细规范
5. **Tool Registry** — 缺少动态加载、命名空间冲突解决、MCP桥接的详细行为

## What Changes

### Memory Directory 增强
- 添加记忆扫描算法规范（扫描目录、解析文件、提取条目）
- 添加相关性评分函数规范（文本匹配 + 时效衰减 + 优先级权重）
- 添加记忆迁移规范（从 SQLite 迁移到 JSONL 格式）

### Context Manager 增强
- 添加 Token 估算算法规范
- 添加压缩优先级策略（系统消息 > 最近消息 > 工具结果 > 历史对话）
- 添加 LLM 摘要生成的输入/输出格式规范
- 添加 Checkpoint 创建和恢复规范

### Subagent Delegation 增强
- 添加完整的生命周期状态机（pending → running → paused → completed/failed）
- 添加超时处理和取消机制规范
- 添加错误恢复策略（重试、降级、回退）
- 添加 Steering 指令注入规范

### Task Orchestration 增强
- 添加 DAG 依赖解析算法规范
- 添加并行执行策略（最大并发、资源限制）
- 添加进度跟踪和报告规范
- 添加 Manifest 序列化格式规范

### Tool Registry 增强
- 添加动态加载/卸载规范
- 添加命名空间前缀解析规则（skill:, mcp:, plugin:）
- 添加 MCP 桥接协议规范
- 添加工具权限过滤规范

## Capabilities

### New Capabilities
- `memory-scan`: 记忆扫描和解析算法规范
- `token-estimation`: Token 估算算法规范
- `dag-scheduler`: DAG 依赖解析和调度规范

### Modified Capabilities
- `memory-directory`: 增加相关性评分算法、迁移流程的详细描述
- `context-manager`: 增加压缩策略、摘要生成、Checkpoint 的详细规范
- `subagents`: 增加生命周期状态机、超时处理、错误恢复规范
- `orchestration`: 增加 DAG 解析、并行执行策略规范
- `unified-tool-registry`: 增加动态加载、命名空间解析、MCP桥接规范

## Impact

**受影响的代码模块:**
- `src/pyclaw/agents/memory_dir/` — 增强扫描和评分逻辑
- `src/pyclaw/agents/context/` — 增强压缩和摘要生成
- `src/pyclaw/agents/subagents/` — 增强生命周期管理
- `src/pyclaw/agents/orchestration/` — 增强 DAG 调度
- `src/pyclaw/agents/tools/registry.py` — 增强命名空间解析

**受影响的测试:**
- `tests/pyclaw/agents/memory_dir/` — 新增测试
- `tests/pyclaw/agents/context/` — 新增测试
- `tests/integration/` — 新增集成测试

**向后兼容性:**
- 所有变更向后兼容，仅添加新功能
- 现有 API 接口不变
