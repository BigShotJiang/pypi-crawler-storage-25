# CLI 模块实施状态

> 最后更新：2026-04-23
> 关联里程碑：M1 Skills, M2 TypeScript 客户端迁移, M3 发布工程化

---

## 1. 模块概览

CLI 模块基于 **Typer + Rich** 构建，提供命令行交互入口，主命令为 `pyclaw`。

---

## 2. 命令实现状态

### 2.1 核心命令

| 命令 | 文件 | 状态 | 完成度 | 功能说明 |
|------|------|------|--------|----------|
| `pyclaw gateway` | `commands/` | ✅ 完成 | 100% | 启动Gateway服务 |
| `pyclaw chat` | `commands/` | ✅ 完成 | 100% | 命令行聊天 |
| `pyclaw config` | `commands/` | ✅ 完成 | 100% | 配置管理 |
| `pyclaw mcp` | `commands/` | ✅ 完成 | 100% | MCP服务管理 |

### 2.2 技能命令

| 命令 | 文件 | 状态 | 完成度 | 功能说明 |
|------|------|------|--------|----------|
| `pyclaw skills list` | `commands/` | ✅ 完成 | 100% | 列出可用技能 |
| `pyclaw skills search` | `commands/` | ✅ 完成 | 100% | 搜索技能 |
| `pyclaw skills install` | `commands/` | ✅ 完成 | 100% | 安装技能 |
| `pyclaw skills run <skill_key>` | `commands/` | ✅ 完成 | 100% | 执行技能（含契约门禁） |

### 2.3 Ops 自动化命令（M2/M3/M4）

| 命令 | 文件 | 状态 | 完成度 | 功能说明 |
|------|------|------|--------|----------|
| `pyclaw ops m2-baseline` | `commands/ops_cmd.py` | ✅ 完成 | 100% | M2基线自动化检查 |
| `pyclaw ops release-gate` | `commands/ops_cmd.py` | ✅ 完成 | 100% | M3发布Gate自动化 |
| `pyclaw ops m4-snapshot` | `commands/ops_cmd.py` | ✅ 完成 | 100% | M4周期巡检快照 |

### 2.4 浏览器审计命令

| 命令 | 文件 | 状态 | 完成度 | 功能说明 |
|------|------|------|--------|----------|
| `pyclaw browser audit` | `commands/` | ✅ 完成 | 100% | 浏览器生命周期审计 |
| `pyclaw provider capability` | `commands/` | ✅ 完成 | 100% | Provider能力注册表 |

### 2.5 安全命令

| 命令 | 文件 | 状态 | 完成度 | 功能说明 |
|------|------|------|--------|----------|
| `pyclaw security audit` | `commands/` | ✅ 完成 | 100% | 安全审计 |
| `pyclaw security audit --deep` | `commands/` | ✅ 完成 | 100% | 深度审计 |
| `pyclaw security audit --fix` | `commands/` | ✅ 完成 | 100% | 自动修复 |

---

## 3. Skills Run 契约门禁

### 3.1 阻断规则

| 阻断条件 | 返回状态 | 说明 |
|----------|----------|------|
| 缺失依赖 | `needs_attention` | `missing_dep:*` |
| `userInvocable: false` | `invalid` | 非用户可调用技能 |
| 诊断模式 | 正常执行 | `ignore_runtime_contract=true` |

### 3.2 探测型技能豁免

| 技能 | 豁免原因 |
|------|----------|
| `mcp-admin` | 依赖缺失仍可运行并给出诊断 |
| `node-toolchain` | 探测型，保留故障态可执行 |

---

## 4. 测试覆盖

| 测试文件 | 状态 | 覆盖范围 |
|----------|------|----------|
| `tests/pyclaw/cli/test_skills_run.py` | ✅ 完成 | skills run命令 + 契约阻断 |
| `tests/pyclaw/cli/test_ops_cmd.py` | ✅ 完成 | ops自动化命令 |
| `tests/pyclaw/cli/test_browser_audit.py` | ✅ 完成 | 浏览器审计命令 |

---

## 5. 关键文件索引

| 文件 | 职责 |
|------|------|
| `src/pyclaw/cli/__init__.py` | CLI入口 |
| `src/pyclaw/cli/commands/__init__.py` | 命令注册 |
| `src/pyclaw/cli/commands/ops_cmd.py` | Ops自动化命令 |
| `src/pyclaw/cli/commands/skills_cmd.py` | 技能命令 |
| `tests/pyclaw/cli/` | CLI测试 |

---

## 6. 待办事项

- [ ] CLI命令文档完善
- [ ] 更多Ops命令扩展
- [ ] 交互式配置向导
