# PyClaw Documentation

<div class="hero">
  <h1>PyClaw</h1>
  <p>🚀 **多通道 AI 网关** — 一行代码连接 27+ 消息平台，让你的 AI Agent 无处不在</p>
  <a href="quickstart/" class="md-button md-button--primary">⚡ 5分钟快速开始</a>
  <a href="https://github.com/chensaics/openclaw-py" class="md-button">📦 GitHub 仓库</a>
</div>

---

## ✨ 为什么选择 PyClaw？

<div class="grid cards" markdown>

<div markdown>

### 🤖 强大的 Agent 运行时

**智能对话引擎** — 支持 25+ LLM 提供商流式输出、20+ 内置工具、MCP 扩展协议、任务规划器、子 Agent 协作。让你的 AI 真正"懂你"。

</div>

<div markdown>

### 💬 27+ 消息通道，一个 Gateway

**全平台覆盖** — Telegram、Discord、Slack、WhatsApp、钉钉、飞书、QQ、微信... 一个 API 接入所有平台，无需重复开发。

</div>

<div markdown>

### 🧠 智能记忆系统

**永不遗忘** — 上下文智能压缩、向量语义检索、对话持久化、每日摘要、长期记忆。让 AI 拥有"大脑"，跨会话记住一切。

</div>

<div markdown>

### 🛡️ 企业级安全防护

**安心可靠** — 命令执行审批、沙箱边界隔离、SSRF 攻击防护、密钥审计、配置安全检查。企业部署无忧。

</div>

</div>

---

## 🚀 快速开始

**一分钟安装，五分钟上手：**

```bash
# 一键安装 (macOS / Linux)
curl -fsSL https://raw.githubusercontent.com/chensaics/openclaw-py/master/scripts/install.sh | bash

# 交互式配置向导
pyclaw setup --wizard

# 开始你的第一次对话！
pyclaw agent "你好，请介绍一下你自己"
```

??? tip "📦 更多安装方式"

    === "pip"
    
        ```bash
        pip install openclaw-py
        ```

    === "pipx (推荐)"
    
        ```bash
        pipx install openclaw-py
        ```

    === "Homebrew"
    
        ```bash
        brew install chensaics/tap/pyclaw
        ```

    === "Docker"
    
        ```bash
        docker run -it --rm \
          -e OPENAI_API_KEY="sk-..." \
          ghcr.io/chensaics/openclaw-py:latest \
          pyclaw agent "Hello"
        ```

---

## 📊 项目实力

<div class="stats">
  <div class="stat">
    <div class="stat-number">27+</div>
    <div class="stat-label">消息通道</div>
  </div>
  <div class="stat">
    <div class="stat-number">25+</div>
    <div class="stat-label">LLM 提供商</div>
  </div>
  <div class="stat">
    <div class="stat-number">20+</div>
    <div class="stat-label">内置工具</div>
  </div>
  <div class="stat">
    <div class="stat-number">658</div>
    <div class="stat-label">源码文件</div>
  </div>
  <div class="stat">
    <div class="stat-number">297</div>
    <div class="stat-label">测试文件</div>
  </div>
</div>

---

## 📖 文档导航

### 入门指南

- [⚡ 快速开始](quickstart.md) — 5 分钟从零到第一次对话
- [🎯 实战演练](walkthrough.md) — 完整使用流程演示
- [📦 安装指南](install.md) — 所有安装方式和可选依赖
- [⚙️ 配置说明](configuration.md) — 配置文件详解与热重载

### 核心概念

- [💡 概念总览](concepts.md) — Gateway、Agent、Session、Memory、Tools、Channels、Security
- [🏗️ 架设计](architecture.md) — 组件详解与设计决策（开发者必读）

### API 与集成

- [🔌 API 参考](api-reference.md) — Gateway WebSocket RPC + OpenAI 兼容 HTTP + MCP + Memory API
- [📱 通道设置](channel-setup.md) — 各平台通道配置教程
- [📋 通道配置参考](channels-reference.md) — 所有通道的完整配置参数

### 开发者指南

- [🔧 插件开发](plugin-development.md) — 开发自定义插件
- [🚢 部署指南](deployment.md) — Docker、系统服务、生产部署
- [🧪 本地 CI 测试](ci-local.md) — 本地运行完整 CI 检查

### 帮助与反馈

- [🔍 故障排除](troubleshooting.md) — 常见问题与诊断命令
- [📈 项目状态](status/README.md) — 里程碑进度、模块状态、风险矩阵
- [📝 变更日志](release_notes/release-notes.md) — 版本更新记录

---

## 🔗 更多资源

| 资源 | 说明 |
|------|------|
| [GitHub 仓库](https://github.com/chensaics/openclaw-py) | 源码、Issue、PR |
| [CLI 命令参考](https://github.com/chensaics/openclaw-py#cli-reference) | 完整 CLI 命令文档 |
| [支持的消息通道](https://github.com/chensaics/openclaw-py#supported-channels) | 27+ 平台完整列表 |
| [支持的 LLM 提供商](https://github.com/chensaics/openclaw-py#supported-llm-providers) | 核心提供商 + OpenAI 兼容 + 国内提供商 |
| [MCP 工具集成](https://github.com/chensaics/openclaw-py#mcp-model-context-protocol) | 外部工具服务器接入 |

---

## 🇨🇳 中文文档

### 简介

**PyClaw** 是一个多通道 AI 网关，通过统一的 Gateway 将 AI Agent 连接到 **27+ 消息平台**。

一句话概括：**一个 API，全平台覆盖**。

### 快速开始

```bash
# 一键安装 (macOS / Linux)
curl -fsSL https://raw.githubusercontent.com/chensaics/openclaw-py/master/scripts/install.sh | bash

# 交互式配置向导
pyclaw setup --wizard

# 开始对话
pyclaw agent "你好，介绍一下你自己"
```

### 核心特性

| 特性 | 说明 |
|------|------|
| 🤖 Agent 运行时 | 多提供商 LLM 流式输出、20+ 内置工具、MCP 支持、任务规划器 |
| 💬 27+ 消息通道 | Telegram、Discord、Slack、WhatsApp、钉钉、飞书、QQ 等 |
| 🧠 记忆系统 | 上下文压缩、向量搜索、每日摘要、长期记忆 |
| 🖥️ 跨平台 UI | Next.js 15 Web、Tauri 桌面、Expo 移动端 |
| 🛡️ 安全性 | 命令审批、沙箱边界、密钥审计 |

### 文档导航

| 文档 | 说明 |
|------|------|
| [快速开始](quickstart.md) | 5 分钟上手指南 |
| [安装指南](install.md) | 所有安装方式 |
| [配置说明](configuration.md) | 配置文件详解 |
| [概念总览](concepts.md) | Gateway、Agent、会话等概念 |
| [架构设计](architecture.md) | 组件详解与设计决策 |
| [API 参考](api-reference.md) | WebSocket RPC + HTTP API |
| [故障排除](troubleshooting.md) | 常见问题与诊断 |

### 项目统计

| 指标 | 数值 |
|------|------|
| Python 源文件 | 658 |
| 测试文件 | 297 |
| 消息通道 | 27+ |
| LLM 提供商 | 25+ |
| 内置工具 | 20+ |