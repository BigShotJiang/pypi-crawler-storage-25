# Registry Patterns in PyClaw

This document describes the unified registry pattern used throughout PyClaw's agent system.

## Overview

PyClaw uses a unified registry pattern to manage collections of related objects (tools, capabilities, agents, providers). The pattern provides:

- **Consistent interface** across all registries
- **Thread-safe operations** where needed
- **Test isolation** via reset capabilities
- **Singleton management** for global registries

As of Phase 03, 22+ registries have been consolidated to use these base classes.

## Registry Types

### Registry[K, V] - Base Abstract Class

The minimal interface all registries implement.

```python
from pyclaw.agents.multiagent.registry import Registry

class MyRegistry(Registry[str, MyType]):
    def register(self, key: str, value: MyType) -> None:
        ...

    def get(self, key: str) -> MyType | None:
        ...

    # Optional methods with default implementations:
    # - unregister(key) -> bool
    # - list_all() -> list[V]
    # - list_keys() -> list[K]
    # - clear() -> None
    # - __contains__(key) -> bool
    # - __len__() -> int
```

**When to use:**
- Simple registries that don't need singleton behavior
- Per-session or per-context registries
- When you want to enforce interface consistency

### SingletonRegistry - Global Singletons

Thread-safe singleton pattern with reset capability.

```python
from pyclaw.agents.multiagent.registry import SingletonRegistry

class CapabilityRegistry(SingletonRegistry[str, type[AgenticCapability]]):
    # Required: re-declare _instance for this subclass
    _instance: ClassVar[CapabilityRegistry | None] = None

    def __init__(self) -> None:
        self._registry: dict[str, type[AgenticCapability]] = {}
        ...

# Usage:
registry = CapabilityRegistry.get_instance()
CapabilityRegistry.reset()  # For testing
```

**When to use:**
- Global registries that should exist once per process
- When you need reset capability for tests
- When multiple code paths need to access the same registry

**Important:** Subclasses must re-declare `_instance: ClassVar[MyRegistry | None] = None`

### ThreadSafeRegistry - Concurrent Access

Registry with RLock protection for thread-safe operations.

```python
from pyclaw.agents.multiagent.registry import ThreadSafeRegistry

class MyThreadSafeRegistry(ThreadSafeRegistry[str, MyType]):
    def __init__(self) -> None:
        super().__init__()  # Creates self._items and self._lock

    def batch_update(self, items: dict[str, MyType]) -> None:
        with self.locked():
            for key, value in items.items():
                self._items[key] = value
```

**When to use:**
- Registries accessed from multiple threads
- When operations need atomic updates
- When you need the `locked()` context manager

## Migration Guide

### From Module-Level Dicts

The most common legacy pattern:

**Before:**
```python
# Anti-pattern: module-level dict
_items: dict[str, MyType] = {}

def register(key: str, value: MyType) -> None:
    _items[key] = value

def get(key: str) -> MyType | None:
    return _items.get(key)
```

**After:**
```python
from pyclaw.agents.multiagent.registry import ThreadSafeRegistry

class MyRegistry(ThreadSafeRegistry[str, MyType]):
    pass

# Or for singleton:
class MyRegistry(SingletonRegistry[str, MyType], Registry):
    _instance: ClassVar[MyRegistry | None] = None
```

**Benefits:**
- Thread-safe by default
- Test isolation via reset()
- Consistent interface

### From __new__ Singletons

Manual singleton implementations:

**Before:**
```python
class MyRegistry:
    _instance: MyRegistry | None = None

    def __new__(cls) -> MyRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._items = {}
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        cls._instance = None
```

**After:**
```python
from pyclaw.agents.multiagent.registry import SingletonRegistry, Registry

class MyRegistry(SingletonRegistry[str, MyType], Registry):
    _instance: ClassVar[MyRegistry | None] = None

    def __init__(self) -> None:
        self._items: dict[str, MyType] = {}
```

**Benefits:**
- Less boilerplate
- Thread-safe initialization
- Consistent reset() behavior

### Best Practices for Testing

Use fixtures to reset singletons before each test:

```python
import pytest
from pyclaw.agents.pacs.registry import CapabilityRegistry

@pytest.fixture(autouse=True)
def reset_singletons():
    """Reset all singletons before each test."""
    CapabilityRegistry.reset()
    # Add other singletons as needed
    yield
    CapabilityRegistry.reset()  # Clean up after test

def test_capability_registration():
    registry = CapabilityRegistry.get_instance()
    registry.clear()
    # Now test is isolated
```

## Domain-Specific Extensions

### When to Add Custom Methods

Registries often have domain-specific methods beyond the base interface:

```python
class CapabilityRegistry(SingletonRegistry[str, type[AgenticCapability]]):
    # Standard interface
    def register(self, name: str, cls: type[AgenticCapability]) -> None: ...
    def get(self, name: str) -> type[AgenticCapability]: ...
    def list_all(self) -> list[type[AgenticCapability]]: ...

    # Domain-specific
    def create(self, name: str, **kwargs) -> AgenticCapability:
        """Create an instance of a registered capability."""
        cls = self.get(name)
        return cls(**kwargs)
```

This is perfectly valid - the base interface provides consistency while domain methods add functionality.

### Preserving Backward Compatibility

When migrating existing registries, use `@overload` for method signatures:

```python
from typing import overload

class ToolRegistry(Registry[str, AgentTool]):
    @overload
    def register(self, tool: AgentTool) -> None: ...  # Legacy style

    @overload
    def register(self, key: str, value: AgentTool) -> None: ...  # Registry style

    def register(self, key: Any, value: AgentTool | None = None) -> None:
        if value is None:
            # Legacy: register(tool)
            self._tools[key.name] = key
        else:
            # Registry: register(name, tool)
            self._tools[key] = value
```

## Special Cases

### Composite Registry Pattern

Some registries aggregate multiple internal dictionaries:

```python
class UnifiedToolRegistry:
    """Composite registry with multiple sources and priority resolution."""

    def __init__(self) -> None:
        self._builtins: dict[str, AgentTool] = {}
        self._skills: dict[str, AgentTool] = {}
        self._mcp: dict[str, AgentTool] = {}
        self._plugins: dict[str, AgentTool] = {}

    def get(self, name: str) -> AgentTool | None:
        """Priority order: builtins > skills > mcp > plugins."""
        ...
```

This pattern is documented but not forced into the simple `Registry[K, V]` interface.

### Module-Level Singleton Pattern

Some registries need multiple variants (v1, v2):

```python
# Module-level singleton with dual variants
_registry: BuiltinAgentRegistry | None = None
_registry_v2: BuiltinAgentRegistry | None = None

def get_registry(use_v2: bool = False) -> BuiltinAgentRegistry:
    global _registry, _registry_v2
    if use_v2:
        if _registry_v2 is None:
            _registry_v2 = BuiltinAgentRegistry(use_v2=True)
        return _registry_v2
    ...
```

This cannot use `SingletonRegistry` mixin due to the dual-registry requirement.

## Registry Inventory

| Registry | Type | Notes |
|----------|------|-------|
| `CapabilityRegistry` | SingletonRegistry | PACS capabilities |
| `ProviderRegistry` | Interface-aligned | Two-dict pattern |
| `AgentCapabilityRegistry` | Thread-safe | Composite keys |
| `ToolRegistry` | Registry ABC | Agent tools |
| `UnifiedToolRegistry` | Composite pattern | Multi-source aggregation |
| `BuiltinAgentRegistry` | Module singleton | Dual v1/v2 variants |
| `CustomAgentRegistry` | Interface-aligned | File-based loading |

## Performance Considerations

- **O(1)** for get/register operations (dict-based)
- **Thread-safe** registries have minimal overhead from RLock
- **Reset** clears all items but doesn't destroy singleton instances

## Future Work

1. Migrate `HookRegistry` from module-level globals to `ThreadSafeRegistry`
2. Consider `Resettable` protocol for non-singleton registries
3. Add metrics collection for registry operations

---

*Document created: 2026-04-29*
*Phase: 03-unified-registry-base-class*