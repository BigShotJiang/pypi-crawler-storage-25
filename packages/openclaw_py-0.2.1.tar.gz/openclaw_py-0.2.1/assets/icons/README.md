# PyClaw Application Icons

Place platform-specific icon files here for packaging:

| File | Platform | Format | Recommended Size |
|------|----------|--------|------------------|
| `icon.ico` | Windows | ICO | 256x256 |
| `icon.icns` | macOS | ICNS | 512x512 |
| `icon.png` | Linux / Android / iOS | PNG | 512x512 |

Usage with TypeScript client builds:

```bash
# Desktop (Tauri)
pnpm --filter @pyclaw/desktop tauri build -- --icon assets/icons/icon.png

# Mobile (Expo)
eas build --platform android -- --icon assets/icons/icon.png
eas build --platform ios -- --icon assets/icons/icon.png
```
