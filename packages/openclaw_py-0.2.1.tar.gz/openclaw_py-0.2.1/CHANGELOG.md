# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.1] - 2026-05-09

### Added
- **Version Management System** — Unified version sync across Python and TypeScript packages
  - `scripts/sync-version.ts` — Sync version from `pyproject.toml` to all `package.json` files
  - `scripts/check-version-sync.py` — CI-ready version consistency checker
  - `pnpm version:sync` / `pnpm version:check` commands
  - Documentation at `docs/reference/version-management.md`
- **Sidebar Cleanup** — Removed unused Plans and Models navigation items

### Fixed
- Move `aiosqlite` to optional perf dependencies (Pyodide compatibility)
- GitHub Actions test failures
- CSS priority issues with `!important` declarations

### Changed
- Homepage styling improvements

## [Unreleased]

### Added
  - `pyclaw.token_aware` — New module with 6 core components:
    - `estimator.py` — Fast token estimation without tokenizer (code/prose/mixed)
    - `description.py` — Intelligent file description extraction for 20+ languages
    - `anatomy.py` — Project file index with descriptions and token estimates
    - `cerebrum.py` — Learning memory (Do-Not-Repeat, Preferences, Learnings, Decisions)
    - `buglog.py` — Bug fix memory with auto-detection patterns
    - `ledger.py` — Token usage tracking and waste detection
    - `session.py` — In-memory session state for repeat detection
  - CLI commands: `pyclaw token-aware init|scan|status|stats|cerebrum|buglog`
  - Estimated token savings: 50-70% on file reads via anatomy descriptions
  - Integration plan documented at `docs/plans/openwolf-integration-plan.md`
- **Channel Configuration Documentation** — Comprehensive channel setup reference
  - Added `docs/channels-reference.md` with detailed config for 24+ channels
  - Updated `docs/configuration.md` with expanded channel section
  - Created `pyclaw.example.json5` with complete config template
  - Covers Telegram, Discord, Slack, Feishu/Lark, DingTalk, MS Teams, and more
  - Added `wecom` (企业微信) channel type to schema
- **Multiagent Module Unification** — Consolidated duplicate multiagent systems into `agents/multiagent/`
  - Unified `MultiagentEngine` ABC with 5 concrete implementations:
    - `CentralizedEngine` — Coordinator-worker pattern
    - `DynamicDecomposeEngine` — Runtime task decomposition
    - `ForkSwarmEngine` — Parallel execution with voting
    - `PipelineEngine` — Sequential stage processing
    - `HybridEngine` — Dynamic mode selection
  - `TaskDecomposer` system — Heuristic and LLM-based decomposition
  - Unified types: `CollaborationModeType`, `MultiagentMode`, `OrchestrationMode`, `SubagentResult`
  - Registry base classes: `Registry[K, V]`, `SingletonRegistry`, `ThreadSafeRegistry`
  - 103 integration tests for unified registry system
  - Migration documentation at `docs/architecture/registry-patterns.md`

### Changed
- **Registry Consolidation** — 22 registries aligned with unified interface
  - `CapabilityRegistry` extends `SingletonRegistry`
  - `ToolRegistry` extends `Registry[str, AgentTool]`
  - `ProviderRegistry` interface aligned
  - CustomAgentRegistry interface updated
- **Module Deprecations** — Legacy modules emit deprecation warnings
  - `pyclaw.agents.orchestration` → Use `pyclaw.agents.multiagent`
  - `pyclaw.agents.collaboration` → Use `pyclaw.agents.multiagent`
  - Both modules remain as re-export shims for backward compatibility
  - Planned removal: version 2.0.0

### Migration Guide
- Types: Use `from pyclaw.agents.multiagent.types import CollaborationModeType, OrchestrationMode, etc.`
- Engines: Use `from pyclaw.agents.multiagent.engines import CentralizedEngine, PipelineEngine, etc.`
- Registry: Use `from pyclaw.agents.multiagent.registry import Registry, SingletonRegistry, ThreadSafeRegistry`
- See `docs/architecture/registry-patterns.md` for detailed migration instructions

### Added
- **PACS — PyClaw Agentic Capability Stack** — Event-driven plugin system for agentic patterns
  - `AgentEventBus` — Priority-sorted hook dispatch with control flow (CONTINUE/SKIP/ABORT/RETRY)
  - `AgenticCapability` ABC — Base class with layer, hooks, priority, should_activate/on_event
  - `CapabilityRegistry` — Singleton factory for capability instantiation by name
  - `Recipe` system — Preset capability configurations (react_agent, planner_agent, research_agent, safe_agent, full_stack_agent)
  - Config DSL — Recipe-based, direct-list, overrides, excludes, extras
  - 21 built-in capabilities across 5 layers:
    - Perception (5): SemanticFilter, ContextWindowManager, ToolOutputParser, UserIntentClassifier, PhaseSeparation
    - Reasoning (5): ReActController, PlanExecute, ReflectionLoop, SelfCritique, DualLLM
    - Action (5): CircuitBreaker, ActionValidator, ModelRouter, ToolRetryBackoff, ParallelToolExecutor
    - Feedback (4): MemorySynthesis, OutputGroundingCheck, TraceQualityMonitor, AutoImprovementLoop
    - Infrastructure (2): MetaCognitionMonitor, CollaborationBus
  - Full test coverage (328 tests passing)
- **Multi-Agent Collaboration System** — Four collaboration modes for agent orchestration
  - `CollaborationEngine` — Unified orchestration layer for all modes
  - **Custom Agent Mode** — Predefined agents from YAML/Markdown configs
  - **Fork/Swarm Mode** — Parallel child agents for same task
  - **Coordinator-Worker Mode** — Task distribution pattern
  - **Dynamic Decompose Mode** — Automatic task decomposition with dependency handling
  - `ModeSelector` — Intelligent mode suggestion based on task analysis
  - `TaskDecomposer` — Heuristic and LLM-based task decomposition
  - `ToolPermissionManager` — Trust-level based tool access control
  - `ContextSharingManager` — Parent-child context inheritance and scratchpad
  - `CustomAgentRegistry` — YAML and Markdown agent configuration loading
  - 6 collaboration tools: spawn_child, kill_child, steer_child, list_children, suggest_mode, mode_switch
  - CLI commands: `pyclaw agents custom`, `pyclaw mode status|switch|--suggest`
- **Active Memory** — Automatic memory retrieval before responses
  - Multiple query modes: MESSAGE (latest only), RECENT (recent turns), FULL (full context)
  - Six prompt styles: BALANCED, STRICT, CONTEXTUAL, RECALL_HEAVY, PRECISION_HEAVY, PREFERENCE_ONLY
  - Per-session toggle control via CLI (`pyclaw active-memory on|off|status`)
  - Result caching with configurable TTL
  - `ActiveMemoryRecaller` class in `memory/active_recall.py`
- **Wiki System** — Structured knowledge base for humans and agents
  - Claim/Evidence model with contradiction detection
  - Block markers to protect human edits during compilation
  - MemoryBridge for syncing with MemoryDirectory
  - `pyclaw wiki init` CLI command for initialization
  - `WikiVault`, `ClaimsManager`, `MemoryBridge` classes in `memory/wiki/`
- **Dreaming System** — Three-phase memory consolidation
  - LIGHT phase: Signal collection, no long-term writes
  - DEEP phase: Scoring and promotion to long-term memory
  - REM phase: Reflection and narrative generation
  - Six-dimensional scoring algorithm (frequency, relevance, diversity, recency, consolidation, conceptual)
  - Automatic promotion to MEMORY.md
  - `SignalsStore`, `PromotionScorer`, `DreamingPhases` classes in `memory/dreaming/`

### Changed
- (none yet)

### Fixed
- (none yet)

## [0.1.8] - 2026-04-11

### Added
- **UI MVC Architecture** — BasePanel, BaseController, Reactive state management
- **Agent Extensions** — Extensible agent runtime with tools and session management
- **Memory System** — SQLite + LanceDB hybrid search with MMR reranking
- **GatewayService** — Mock service for UI testing
- **EventBus** — Decoupled event-driven communication

### Changed
- Refactored UI panels to MVC pattern (Agents panel migrated)
- Split `components.py` into modular components
- Improved type annotations across codebase

### Fixed
- Agent import, parameter, and cache issues
- Lint and type annotation warnings

## [0.1.4] - 2026-03-15

### Added
- Versioned pre-push hook: `scripts/githooks/pre-push`（推送 tag 时跳过测试，由 release workflow 执行）
- `scripts/githooks/README.md` — 安装说明

### Changed
- pre-push：仅对分支推送跑全量 pytest，推送 tag 时跳过，避免与 release 重复
- ci-local.sh：不再跑 pytest，只做 ruff + mypy，pytest 由 pre-push 统一执行
- commit.sh：文案改为“本地检查（ruff + mypy）”

### Fixed
- 测试耗时：`test_infra_misc.test_with_timeout_expired`、`test_cron_tts_logging.test_timeout` 中 `asyncio.sleep(10)` 改为最小必要时长（0.1s / 0.2s），pre-push 全量测试减少约 20 秒

## [0.1.3] - 2026-03-14

### Added
- Responsive shell module (`ui/responsive_shell.py`) — breakpoint-based layout management
- External locale JSON files (`ui/locales/*.json`) — i18n data no longer hardcoded
- Desktop tray quick actions — new chat, toggle theme, mute notifications
- PWA support — manifest, service worker, offline caching for web builds
- Provider/model configuration linkage — switching provider auto-updates model list, base URL, API key hint
- CJK font fallback chain for proper Chinese/Japanese display
- Shimmer loading animation, message fade-in, send button scale animation
- Chat export to Markdown, file attachment support
- Keyboard shortcuts (Cmd/Ctrl+K search, +N new session, +E export)
- Streaming typing indicator with animated dots
- Scroll-to-bottom floating button
- Reusable UI components (`ui/components.py`): page_header, empty_state, card_tile, status_chip
- New UI panels: config, cron, debug, instances, logs, nodes, overview, plans, sessions, skills, system, usage
- Docs site (MkDocs) and GitHub Pages deploy workflow
- Reference docs restructure: PROGRESS.md + REFERENCE_TABLES.md milestone-driven layout

### Changed
- Provider defaults consolidated into single source of truth (`model_catalog._KNOWN_PROVIDERS`)
- Toolbar refactored to `ChatToolbar` class with dynamic model updates
- Chat bubble design enhanced — asymmetric border radius, role-colored avatars, improved shadows
- Provider names use English-first format with CJK in parentheses
- Dependencies reorganized — heavy channel SDKs moved to optional `[channels]` extra
- Reference and docs layout: legacy plans moved/archived, single source in `reference/`

### Fixed
- ChatMessage search: `_message_content` initialized in constructor
- Tool display metadata: correct nested key access with fallback

## [0.1.0] - 2026-03-04

### Added
- Initial release
- Multi-channel AI gateway (Telegram, Discord, Slack, WeChat, WhatsApp, Matrix, and more)
- 20+ LLM provider support (OpenAI, Anthropic, Google, DeepSeek, Qwen, GLM, MiniMax, etc.)
- WebSocket v3 protocol for UI-gateway communication
- TypeScript cross-platform UI (Web, Desktop, Mobile)
- Agent system with tool calling, planning, and memory
- CLI with interactive setup wizard
- Docker support with multi-stage build
- Cron job scheduling
- Voice interaction (TTS via edge-tts, STT via Whisper API)

[Unreleased]: https://github.com/chensaics/openclaw-py/compare/v0.2.1...HEAD
[0.2.1]: https://github.com/chensaics/openclaw-py/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/chensaics/openclaw-py/releases/tag/v0.2.0
[0.1.9]: https://github.com/chensaics/openclaw-py/compare/v0.1.8...v0.1.9
