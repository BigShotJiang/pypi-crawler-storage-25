<#
.SYNOPSIS
    Build OpenClaw TypeScript clients for Web, Desktop, and Mobile platforms.

.DESCRIPTION
    Builds the TypeScript client applications using pnpm monorepo.
    Web (Next.js), Desktop (Tauri), Mobile (Expo).

.PARAMETER Targets
    Comma-separated build targets. Default: "web,desktop"
    Available: web, desktop, mobile

.EXAMPLE
    .\scripts\build-all.ps1
    .\scripts\build-all.ps1 -Targets "web,desktop"
#>

param(
    [string]$Targets = "web,desktop"
)

$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $ProjectDir

$TargetList = $Targets -split ","
$Succeeded = @()
$Failed = @()

foreach ($target in $TargetList) {
    $target = $target.Trim()
    Write-Host ""
    Write-Host "========================================"
    Write-Host "  Building: $target"
    Write-Host "========================================"
    Write-Host ""

    try {
        switch ($target) {
            "web" {
                & pnpm --filter @pyclaw/web build
            }
            "desktop" {
                & pnpm --filter @pyclaw/desktop tauri build
            }
            "mobile" {
                & pnpm --filter @pyclaw/mobile build
            }
            default {
                Write-Host "[SKIP] Unknown target: $target"
                continue
            }
        }
        if ($LASTEXITCODE -eq 0) {
            $Succeeded += $target
            Write-Host "[OK] $target build succeeded"
        } else {
            $Failed += $target
            Write-Host "[FAIL] $target build FAILED"
        }
    }
    catch {
        $Failed += $target
        Write-Host "[FAIL] $target build FAILED: $_"
    }
}

Write-Host ""
Write-Host "========================================"
Write-Host "  Build Summary"
Write-Host "========================================"

if ($Succeeded.Count -gt 0) {
    Write-Host "  Succeeded: $($Succeeded -join ', ')"
}
if ($Failed.Count -gt 0) {
    Write-Host "  Failed:    $($Failed -join ', ')"
    exit 1
}

Write-Host ""
Write-Host "All builds completed."
