#!/usr/bin/env npx tsx
/**
 * 同步版本号到所有 package.json 文件
 *
 * 用法:
 *   pnpm version:sync
 *   npx tsx scripts/sync-version.ts
 *
 * 从 pyproject.toml 读取版本号，同步到:
 *   - apps/web/package.json
 *   - packages/shared/package.json
 *   - packages/ui/package.json
 */
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = join(__dirname, '..');

interface PackageJson {
  name: string;
  version: string;
  [key: string]: unknown;
}

// 目标 package.json 文件列表
const packageFiles = [
  'apps/web/package.json',
  'packages/shared/package.json',
  'packages/ui/package.json',
];

/**
 * 从 pyproject.toml 提取版本号
 */
function getPyprojectVersion(): string | null {
  const pyprojectPath = join(rootDir, 'pyproject.toml');
  const content = readFileSync(pyprojectPath, 'utf-8');
  const match = content.match(/^version\s*=\s*"([^"]+)"/m);
  return match ? match[1] : null;
}

/**
 * 读取 package.json
 */
function readPackageJson(path: string): PackageJson {
  return JSON.parse(readFileSync(path, 'utf-8'));
}

/**
 * 写入 package.json (保持格式)
 */
function writePackageJson(path: string, pkg: PackageJson): void {
  writeFileSync(path, JSON.stringify(pkg, null, 2) + '\n');
}

/**
 * 主函数
 */
function main(): void {
  console.log('🔄 PyClaw Version Sync Tool\n');

  // 1. 从 pyproject.toml 获取版本号
  const version = getPyprojectVersion();
  if (!version) {
    console.error('❌ Cannot find version in pyproject.toml');
    process.exit(1);
  }
  console.log(`📦 Source version from pyproject.toml: ${version}\n`);

  // 2. 同步到所有 package.json
  let synced = 0;
  let skipped = 0;

  for (const file of packageFiles) {
    const fullPath = join(rootDir, file);

    if (!existsSync(fullPath)) {
      console.log(`⏭️  Skipped (not found): ${file}`);
      skipped++;
      continue;
    }

    const pkg = readPackageJson(fullPath);

    if (pkg.version === version) {
      console.log(`✓  Already synced: ${file}`);
      continue;
    }

    pkg.version = version;
    writePackageJson(fullPath, pkg);
    console.log(`✅ Synced: ${file}`);
    synced++;
  }

  // 3. 输出结果
  console.log(`\n${'─'.repeat(40)}`);
  console.log(`📊 Summary:`);
  console.log(`   Version: ${version}`);
  console.log(`   Synced:  ${synced} files`);
  console.log(`   Skipped: ${skipped} files (not found)`);
  console.log(`${'─'.repeat(40)}`);

  if (synced > 0) {
    console.log('\n💡 Next steps:');
    console.log('   1. Update CHANGELOG.md');
    console.log('   2. git add . && git commit -m "chore: sync version to ' + version + '"');
  }
}

main();
