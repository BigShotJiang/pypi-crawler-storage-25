#!/usr/bin/env python
"""Run UI E2E tests with comprehensive log collection and error analysis.

Usage:
    # Run all E2E tests
    python scripts/run_e2e_tests.py

    # Run specific test file
    python scripts/run_e2e_tests.py tests/e2e/

    # Run with visible browser (for debugging)
    python scripts/run_e2e_tests.py --no-headless

    # Run with verbose output
    python scripts/run_e2e_tests.py -v

    # Run specific test
    python scripts/run_e2e_tests.py -k test_chat

    # Generate HTML report
    python scripts/run_e2e_tests.py --html

    # Clean up old test results
    python scripts/run_e2e_tests.py --clean
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

# Project root
PROJECT_ROOT = Path(__file__).parent.parent
TEST_RESULTS_DIR = PROJECT_ROOT / "test-results"
LOG_DIR = TEST_RESULTS_DIR / "e2e-logs"
SCREENSHOT_DIR = TEST_RESULTS_DIR / "screenshots"


def ensure_dependencies() -> bool:
    """Ensure Playwright is installed."""
    try:
        import playwright  # noqa: F401

        return True
    except ImportError:
        print("Playwright not found. Installing...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "playwright"],
            check=True,
        )
        # Install browser
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            check=True,
        )
        return True


def clean_results() -> None:
    """Clean up old test results."""
    if TEST_RESULTS_DIR.exists():
        print(f"Cleaning up {TEST_RESULTS_DIR}...")
        shutil.rmtree(TEST_RESULTS_DIR)
    print("Done.")


def run_tests(
    test_path: str | None = None,
    verbose: bool = False,
    headless: bool = True,
    html_report: bool = False,
    keyword: str | None = None,
    extra_args: list[str] | None = None,
) -> int:
    """Run E2E tests with the specified options."""
    # Set environment variables
    env = os.environ.copy()
    env["PYCLAW_RUN_UI_E2E"] = "true"
    env["PYCLAW_E2E_HEADLESS"] = "true" if headless else "false"
    env["PYCLAW_E2E_LOG_DIR"] = str(LOG_DIR)
    env["PYCLAW_E2E_SCREENSHOT_DIR"] = str(SCREENSHOT_DIR)

    # Create output directories
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

    # Build pytest command
    cmd = [sys.executable, "-m", "pytest"]

    # Test path
    if test_path:
        cmd.append(test_path)
    else:
        cmd.append(str(PROJECT_ROOT / "tests" / "pyclaw" / "ui" / "e2e"))

    # Verbose
    if verbose:
        cmd.append("-v")

    # Keyword filter
    if keyword:
        cmd.extend(["-k", keyword])

    # HTML report
    if html_report:
        html_path = TEST_RESULTS_DIR / "e2e_report.html"
        cmd.extend(["--html", str(html_path), "--self-contained-html"])

    # Log output
    cmd.extend(["--log-cli-level=INFO", "--log-file-level=DEBUG"])
    log_file = LOG_DIR / "pytest.log"
    cmd.extend(["--log-file", str(log_file)])

    # Extra args
    if extra_args:
        cmd.extend(extra_args)

    # Markers
    cmd.extend(["-m", "e2e"])

    print(f"\n{'=' * 60}")
    print("Running UI E2E Tests")
    print(f"{'=' * 60}")
    print(f"Headless: {headless}")
    print(f"Log dir: {LOG_DIR}")
    print(f"Screenshot dir: {SCREENSHOT_DIR}")
    print(f"Command: {' '.join(cmd)}")
    print(f"{'=' * 60}\n")

    # Run tests
    result = subprocess.run(cmd, env=env, cwd=PROJECT_ROOT)

    print(f"\n{'=' * 60}")
    print("E2E Test Complete")
    print(f"{'=' * 60}")
    print(f"Exit code: {result.returncode}")
    print(f"Logs: {LOG_DIR}")
    print(f"Screenshots: {SCREENSHOT_DIR}")
    if html_report:
        print(f"HTML report: {TEST_RESULTS_DIR / 'e2e_report.html'}")
    print(f"{'=' * 60}\n")

    return result.returncode


def analyze_errors() -> None:
    """Analyze collected errors and print fix suggestions."""
    errors_file = LOG_DIR / "errors.json"
    if not errors_file.exists():
        print("No errors file found. Run tests first.")
        return

    import json

    with open(errors_file, encoding="utf-8") as f:
        errors = json.load(f)

    if not errors:
        print("No errors found in the test run.")
        return

    print(f"\n{'=' * 60}")
    print(f"Error Analysis ({len(errors)} errors)")
    print(f"{'=' * 60}\n")

    for i, error in enumerate(errors, 1):
        print(f"Error {i}:")
        print(f"  Type: {error.get('type', 'unknown')}")
        print(f"  Source: {error.get('source', 'unknown')}")
        print(f"  Message: {error.get('message', 'N/A')[:200]}")
        print(f"  Fix: {error.get('fix_suggestion', 'N/A')}")
        print()

    print(f"{'=' * 60}\n")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run UI E2E tests with log collection",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "test_path",
        nargs="?",
        help="Path to test file or directory",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Verbose output",
    )
    parser.add_argument(
        "--no-headless",
        action="store_true",
        help="Run with visible browser (for debugging)",
    )
    parser.add_argument(
        "--html",
        action="store_true",
        help="Generate HTML report",
    )
    parser.add_argument(
        "-k",
        "--keyword",
        help="Run tests matching keyword",
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="Clean up old test results",
    )
    parser.add_argument(
        "--analyze",
        action="store_true",
        help="Analyze collected errors",
    )
    parser.add_argument(
        "--install-deps",
        action="store_true",
        help="Install Playwright dependencies",
    )
    parser.add_argument(
        "extra_args",
        nargs="*",
        help="Extra arguments passed to pytest",
    )

    args = parser.parse_args()

    # Handle clean
    if args.clean:
        clean_results()
        return 0

    # Handle analyze
    if args.analyze:
        analyze_errors()
        return 0

    # Handle install deps
    if args.install_deps:
        ensure_dependencies()
        return 0

    # Ensure dependencies
    ensure_dependencies()

    # Run tests
    return run_tests(
        test_path=args.test_path,
        verbose=args.verbose,
        headless=not args.no_headless,
        html_report=args.html,
        keyword=args.keyword,
        extra_args=args.extra_args,
    )


if __name__ == "__main__":
    sys.exit(main())
