#!/usr/bin/env python3
"""
检查所有包版本是否一致

用法:
    python scripts/check-version-sync.py
    pnpm version:check

退出码:
    0 - 所有版本一致
    1 - 版本不一致或出错
"""

import json
import re
import sys
from pathlib import Path


def get_pyproject_version() -> str | None:
    """从 pyproject.toml 提取版本号"""
    pyproject_path = Path("pyproject.toml")
    if not pyproject_path.exists():
        return None

    content = pyproject_path.read_text(encoding="utf-8")
    match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
    return match.group(1) if match else None


def get_package_version(path: str) -> str | None:
    """从 package.json 提取版本号"""
    pkg_path = Path(path)
    if not pkg_path.exists():
        return None

    pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
    return pkg.get("version")


def main() -> int:
    print("🔍 PyClaw Version Consistency Check\n")

    # 1. 获取 pyproject.toml 版本
    pyproject_version = get_pyproject_version()
    if not pyproject_version:
        print("❌ Cannot find version in pyproject.toml")
        return 1

    print(f"📦 Source version (pyproject.toml): {pyproject_version}\n")

    # 2. 检查所有 package.json
    package_files = [
        "apps/web/package.json",
        "packages/shared/package.json",
        "packages/ui/package.json",
    ]

    errors = []
    checked = 0

    for file in package_files:
        pkg_path = Path(file)
        if not pkg_path.exists():
            print(f"⏭️  Skipped (not found): {file}")
            continue

        pkg_version = get_package_version(file)
        checked += 1

        if pkg_version != pyproject_version:
            errors.append((file, pkg_version))
            print(f"❌ Mismatch: {file}")
            print(f"   Expected: {pyproject_version}")
            print(f"   Actual:   {pkg_version}")
        else:
            print(f"✅ OK: {file}")

    # 3. 输出结果
    print(f"\n{'─' * 40}")

    if errors:
        print("❌ Version mismatch detected!")
        print(f"   Checked:  {checked} files")
        print(f"   Mismatch: {len(errors)} files")
        print("\n💡 Run: pnpm version:sync")
        return 1

    print(f"✅ All {checked} packages are synced to version {pyproject_version}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
