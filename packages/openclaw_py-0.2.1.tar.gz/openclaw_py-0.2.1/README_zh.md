# PyClaw

[![PyPI version](https://img.shields.io/pypi/v/openclaw-py.svg)](https://pypi.org/project/openclaw-py/)
[![Python](https://img.shields.io/pypi/pyversions/openclaw-py.svg)](https://pypi.org/project/openclaw-py/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://github.com/chensaics/openclaw-py/actions/workflows/test.yml/badge.svg)](https://github.com/chensaics/openclaw-py/actions)

**多通道 AI 网关** — 通过统一网关将 AI Agent 连接到 27+ 消息平台。

PyClaw 是 [openclaw/openclaw](https://github.com/openclaw/openclaw) 的 Python 重写版本，支持 MCP 工具集成、20+ 内置工具、跨平台 UI（Web/Desktop/Mobile）以及 OpenAI 兼容的 HTTP API。

> **[完整文档](docs/README.md)** — 快速开始、安装指南、配置详解、概念总览、故障排除等。

---

## 核心特性

### 🤖 Agent 运行时
- 多提供商 LLM 流式输出（OpenAI、Anthropic、Google Gemini、Ollama 等 25+）
- 20+ 内置工具：文件读写、grep、find、exec、网络搜索、浏览器、记忆、定时任务、TTS 等
- MCP（模型上下文协议）支持 — 连接任意 stdio 或 HTTP MCP 服务器
- 任务规划器，支持多步骤 Plan/Step 分解
- 用户中断系统（生成过程中取消/追加）
- 子代理编排（spawn、steer、kill）
- 基于 SKILL.md 的技能注入

### 🧠 记忆系统
- 上下文自动压缩（LLM 驱动的摘要）
- 对话持久化（JSONL 格式，按日期分片）
- 混合搜索：SQLite FTS5 + LanceDB 向量搜索
- 每日摘要服务，自动会话整合
- 活跃记忆，多查询模式
- Wiki 系统，结构化知识库

### 💬 27+ 消息通道
Telegram、Discord、Slack、WhatsApp、Signal、iMessage、飞书、钉钉、QQ、MS Teams、Matrix、IRC、LINE、Twitch、Nostr 等。

统一的 `ChannelPlugin` 接口 — 每个通道都是自包含模块，支持 DM/group 策略、allowFrom 白名单、mention 门控。

### 🚪 Gateway
- FastAPI + WebSocket v3 双向协议
- OpenAI 兼容 HTTP API（`/v1/chat/completions`、`/v1/responses`、`/v1/models`）
- 25+ RPC 方法：chat、sessions、agents、channels、config、models、browser、cron、plan、backup、tools 等
- 配置热重载、通道健康监控

### 🖥️ 跨平台 UI
- **Next.js 15** Web 应用
- **Tauri 2.x** 桌面应用（macOS, Linux, Windows）
- **Expo React Native** 移动应用（iOS, Android）
- 17+ 页面：Chat、Agents、Channels、Sessions、Usage、Cron、Plans、Skills、Nodes、Voice、Logs、Debug、Config、System、Settings 等

### 🛡️ 安全性
- 命令执行审批规则
- 工作区沙箱边界
- SSRF 防护
- 明文密钥扫描
- 配置安全审计

---

## 快速开始

### 环境要求
- Python >= 3.10
- LLM API 密钥（OpenAI、Anthropic、Google Gemini、Ollama 或任意 OpenAI 兼容提供商）

### 安装

```bash
# 一键安装 (macOS / Linux)
curl -fsSL https://raw.githubusercontent.com/chensaics/openclaw-py/master/scripts/install.sh | bash

# 本地模型支持
curl -fsSL https://raw.githubusercontent.com/chensaics/openclaw-py/master/scripts/install.sh | bash -s -- --extras llamacpp
curl -fsSL https://raw.githubusercontent.com/chensaics/openclaw-py/master/scripts/install.sh | bash -s -- --extras mlx   # Apple Silicon only

# Windows (PowerShell)
irm https://raw.githubusercontent.com/chensaics/openclaw-py/master/scripts/install.ps1 | iex

# 从 PyPI 安装
pip install openclaw-py

# 通过 pipx 安装（隔离环境，推荐）
pipx install openclaw-py

# macOS 通过 Homebrew
brew install chensaics/tap/pyclaw

# 从源码安装（开发）
pip install -e ".[dev,ui]"

# Docker
docker run -it --rm -e OPENAI_API_KEY="sk-..." ghcr.io/chensaics/openclaw-py:latest pyclaw agent "你好"
```

### 可选依赖

| Extra | 功能 |
|-------|------|
| `ui` | TypeScript 客户端（Web/Desktop/Mobile） |
| `matrix` | Matrix 通道（matrix-nio） |
| `whatsapp` | WhatsApp 通道（neonize） |
| `voice` | 语音 TTS（edge-tts） |
| `dev` | 测试 + 代码检查（pytest, ruff, mypy） |
| `all` | ui + matrix + voice + 更多 |

### 首次运行

```bash
# 1. 交互式配置
pyclaw setup --wizard

# 2. 与 Agent 对话
pyclaw agent "东京今天天气怎么样？"

# 3. 启动 Gateway
pyclaw gateway

# 4. 启动桌面 UI
pyclaw ui

# 5. 或启动 Web 应用
pyclaw ui --web --port 18776
```

---

## CLI 命令速查

### 核心命令

| 命令 | 说明 |
|------|------|
| `pyclaw setup --wizard` | 交互式配置向导 |
| `pyclaw setup --non-interactive` | 无交互设置（环境变量） |
| `pyclaw agent <message>` | 运行单轮 Agent 对话 |
| `pyclaw gateway` | 启动 Gateway 服务器 |
| `pyclaw ui` | 启动桌面 UI |
| `pyclaw ui --web` | 启动 Web UI |
| `pyclaw status [--deep]` | 查看状态 / 探测健康 |
| `pyclaw doctor` | 运行诊断 |

### 配置命令

| 命令 | 说明 |
|------|------|
| `pyclaw config list` | 显示所有配置 |
| `pyclaw config get <key>` | 获取配置值 |
| `pyclaw config set <key> <value>` | 设置配置值 |

### Agent 与通道

| 命令 | 说明 |
|------|------|
| `pyclaw agents list` | 列出所有 Agent |
| `pyclaw agents add <name> --model <model>` | 添加 Agent |
| `pyclaw agents bindings list` | 显示路由规则 |
| `pyclaw channels list` | 列出所有通道 |
| `pyclaw channels status` | 查看连接状态 |

### 认证与 MCP

| 命令 | 说明 |
|------|------|
| `pyclaw auth login --provider <name>` | 添加 API 密钥配置 |
| `pyclaw auth status` | 显示认证配置 |
| `pyclaw mcp status` | 显示 MCP 服务器和工具 |
| `pyclaw mcp list-tools` | 列出可用的 MCP 工具 |

### 运维命令

| 命令 | 说明 |
|------|------|
| `pyclaw service install` | 安装为系统服务 |
| `pyclaw secrets audit` | 扫描明文密钥 |
| `pyclaw security audit` | 安全审计 |
| `pyclaw logs [--follow]` | 实时查看日志 |
| `pyclaw backup export` | 导出配置和会话 |

---

## 支持的通道

| 通道 | 库 | 类型 |
|------|---|------|
| Telegram | aiogram | 核心 |
| Discord | discord.py | 核心 |
| Slack | slack-bolt (Socket Mode) | 核心 |
| WhatsApp | neonize (Baileys) | 核心 |
| Signal | signal-cli JSON-RPC | 核心 |
| iMessage | imsg JSON-RPC | 核心 |
| Web | 内置 | 核心 |
| 飞书 | Open Platform API | 扩展 |
| 钉钉 | Stream Mode (WebSocket) | 扩展 |
| QQ | QQ Bot (WebSocket) | 扩展 |
| MS Teams | Bot Framework + Graph API | 扩展 |
| Matrix | matrix-nio | 扩展 |
| IRC | Native TCP/TLS | 扩展 |
| LINE | Messaging API | 扩展 |
| Twitch | IRC/TLS | 扩展 |
| Nostr | NIP-04 relay | 扩展 |
| BlueBubbles | REST webhook | 扩展 |
| Google Chat | OAuth webhook | 扩展 |
| Mattermost | REST + WebSocket | 扩展 |
| Nextcloud Talk | REST webhook | 扩展 |
| Synology Chat | Incoming webhook | 扩展 |
| Tlon / Urbit | HTTP API | 扩展 |
| Zalo | Official API | 扩展 |
| Voice Call | Twilio | 扩展 |

---

## 支持的 LLM 提供商

### 核心提供商

| 提供商 | 模型 |
|--------|------|
| OpenAI | GPT-4o, GPT-4o-mini, o1, o3-mini |
| Anthropic | Claude Opus, Claude Sonnet, Claude Haiku |
| Google Gemini | Gemini 2.0 Flash, Gemini Pro |
| Ollama | 任意本地模型 |

### OpenAI 兼容提供商

| 提供商 | 说明 |
|--------|------|
| OpenRouter | 访问所有模型 |
| Together AI | 开源模型 |
| Groq | 快速推理 |
| Fireworks AI | 快速推理 |
| Perplexity | 搜索增强 |

### 中国提供商

| 提供商 | 说明 |
|--------|------|
| DeepSeek | DeepSeek-V2 / DeepSeek-Coder |
| Moonshot / Kimi | 128k 上下文 |
| 智谱 / GLM | GLM-4 系列 |
| 通义千问 | Qwen 系列 |
| 火山引擎 | Doubao 模型 |
| MiniMax | MiniMax 模型 |
| 千帆 / 百度 | ERNIE 系列 |

---

## MCP（模型上下文协议）

通过 [MCP](https://modelcontextprotocol.io) 连接外部工具服务器。配置格式与 Claude Desktop 和 Cursor 兼容。

添加到 `~/.pyclaw/pyclaw.json`：

```json
{
  "tools": {
    "mcpServers": {
      "filesystem": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/dir"]
      },
      "remote-api": {
        "url": "https://example.com/mcp/",
        "headers": { "Authorization": "Bearer xxx" }
      }
    }
  }
}
```

| 模式 | 配置 | 用途 |
|------|------|------|
| **Stdio** | `command` + `args` | 本地进程（npx, uvx, python） |
| **HTTP** | `url` + `headers` | 远程 MCP 端点 |

---

## 配置

PyClaw 将状态存储在 `~/.pyclaw/` 目录：

```
~/.pyclaw/
├── pyclaw.json          # 主配置（JSON5 格式，支持注释）
├── auth-profiles.json   # API 密钥和 OAuth 凭证
├── credentials/         # Web 提供商凭证文件
├── sessions/            # Agent 会话记录（JSONL）
└── workspace/           # 工作区文件（AGENTS.md, HEARTBEAT.md 等）
```

### 示例配置

```json
{
  "models": {
    "providers": {
      "openai": { "apiKey": "sk-..." },
      "anthropic": { "apiKey": "sk-ant-..." }
    }
  },
  "agents": {
    "defaults": {
      "model": "gpt-4o",
      "provider": "openai"
    }
  },
  "channels": {
    "telegram": {
      "enabled": true,
      "token": "123456:ABC-DEF",
      "allowFrom": ["your_user_id"]
    },
    "dingtalk": {
      "enabled": true,
      "clientId": "your_app_key",
      "clientSecret": "your_app_secret"
    }
  },
  "tools": {
    "mcpServers": {
      "fs": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"]
      }
    }
  }
}
```

### 环境变量

| 变量 | 说明 |
|------|------|
| `OPENAI_API_KEY` | OpenAI API 密钥 |
| `ANTHROPIC_API_KEY` | Anthropic API 密钥 |
| `GOOGLE_API_KEY` | Google AI API 密钥 |
| `TELEGRAM_BOT_TOKEN` | Telegram Bot Token |
| `PYCLAW_GATEWAY_PORT` | Gateway 端口（默认: 18777） |

---

## Gateway API

### WebSocket（端口 18777）

完整双向协议，支持实时 Agent 交互。25+ RPC 方法：

- `connect`、`health`、`status`
- `chat.send`、`chat.abort`
- `sessions.list`、`sessions.get`
- `config.get`、`config.set`
- `agents.list`、`agents.bindings`
- `channels.list`、`channels.status`
- `models.list`、`models.probe`
- `browser.*`、`cron.*`、`tools.*`
- `plan.list`、`plan.resume`
- `backup.export`、`backup.import`

### HTTP（OpenAI 兼容）

| 端点 | 说明 |
|------|------|
| `POST /v1/chat/completions` | 聊天补全（流式 SSE） |
| `POST /v1/responses` | Responses API（流式 SSE） |
| `GET /v1/models` | 列出可用模型 |

---

## Docker

### Docker Compose（推荐）

```bash
# 首次设置
docker compose run --rm pyclaw-cli setup --non-interactive --accept-risk

# 编辑配置
vim ~/.pyclaw/pyclaw.json

# 启动 Gateway
docker compose up -d pyclaw-gateway

# 查看 logs
docker compose logs -f pyclaw-gateway

# 停止
docker compose down
```

### Docker

```bash
# 构建
docker build -t pyclaw .

# 初始化配置
docker run -v ~/.pyclaw:/root/.pyclaw --rm pyclaw setup --non-interactive --accept-risk

# 运行 Gateway
docker run -v ~/.pyclaw:/root/.pyclaw -p 18777:18777 -p 18778:18778 pyclaw gateway

# 运行 CLI
docker run -v ~/.pyclaw:/root/.pyclaw --rm pyclaw agent "你好！"
```

---

## 架构

```
openclaw-py/
├── src/pyclaw/           # Python 后端（658 文件）
│   ├── agents/           # Agent 运行时
│   │   ├── runner.py     # 核心循环
│   │   ├── stream.py     # 多提供商流式输出
│   │   ├── session.py    # JSONL DAG 会话存储
│   │   ├── planner.py    # 任务 Plan/Step 分解
│   │   ├── providers/    # 25+ LLM 提供商适配器
│   │   ├── skills/       # SKILL.md 发现
│   │   └── tools/        # 20+ 内置工具 + MCP 桥接
│   │
│   ├── gateway/          # Gateway 服务器
│   │   ├── server.py     # FastAPI + WebSocket v3
│   │   ├── openai_compat.py  # /v1/chat/completions
│   │   └── methods/      # 25+ RPC 处理器
│   │
│   ├── channels/         # 27 消息通道
│   │   ├── base.py       # ChannelPlugin 接口
│   │   ├── telegram/     # aiogram
│   │   ├── discord/      # discord.py
│   │   ├── slack/        # slack-bolt
│   │   └── ...           # + 24 更多
│   │
│   ├── config/           # 配置（Pydantic + JSON5）
│   ├── memory/           # 记忆（SQLite + LanceDB）
│   ├── mcp/              # MCP 客户端
│   ├── security/         # 安全模块
│   ├── cron/             # APScheduler 任务
│   └── cli/              # Typer CLI（25+ 命令）
│
├── apps/                 # TypeScript 客户端
│   ├── web/              # Next.js 15 Web 应用
│   ├── desktop/          # Tauri 2.x 桌面应用
│   └── mobile/           # Expo React Native 移动应用
│
├── packages/             # 共享包
│   ├── shared/           # 类型、API 客户端、Store
│   └── ui/               # UI 组件库
│
├── tests/                # 297 测试文件
└── docs/                 # 文档
```

### 技术栈

| 层级 | 技术 |
|------|------|
| 语言 | Python 3.10+ |
| Web 框架 | FastAPI + Uvicorn |
| WebSocket | websockets |
| HTTP 客户端 | httpx |
| CLI | Typer + Rich |
| 数据验证 | Pydantic v2 |
| 配置格式 | JSON5 |
| 数据库 | SQLite + FTS5 |
| 向量搜索 | LanceDB |
| UI (Web) | Next.js 15 |
| UI (Desktop) | Tauri 2.x |
| UI (Mobile) | Expo React Native |
| 测试 | pytest, pytest-asyncio |
| 代码检查 | ruff |
| 类型检查 | mypy |
| 构建 | Hatch |

---

## 项目统计

| 指标 | 数值 |
|------|------|
| Python 源文件 | 658 |
| 测试文件 | 297 |
| 消息通道 | 27 |
| LLM 提供商 | 25+ |
| 内置工具 | 20+ |
| RPC 方法 | 25+ |
| CLI 命令 | 25+ 组 |
| UI 页面 | 17+ |

---

## 开发

```bash
# 安装开发依赖
pip install -e ".[dev,ui]"

# 运行测试
pytest

# 运行测试并生成覆盖率
pytest --cov=pyclaw --cov-report=term-missing

# 代码检查
ruff check src/ tests/

# 格式化
ruff format src/ tests/

# 类型检查
mypy src/pyclaw/
```

---

## 贡献

欢迎提交 Pull Request。项目遵循标准 Python 规范：

- 代码风格：`ruff`
- 类型注解：`mypy`
- 新功能需包含测试
- 全异步优先架构

---

## 致谢

本项目灵感来源于 [OpenClaw](https://github.com/openclaw/openclaw)（最初使用 TypeScript 构建）。PyClaw 使用 Python + TypeScript 完全重写，增加了更多功能。

感谢以下项目和社区：

- [OpenClaw](https://github.com/openclaw/openclaw) — 原项目灵感
- [Next.js](https://nextjs.org) — React 生产框架
- [Tauri](https://tauri.app) — 构建更小、更快、更安全的桌面应用
- [Expo](https://expo.dev) — 构建通用原生应用的平台

---

## 许可证

[MIT](LICENSE) — Copyright (c) 2026 CHEN SAI

---

**[English README](README.md)**
