use tauri::{
    menu::{Menu, MenuItem},
    tray::TrayIconBuilder,
    Manager,
};
use tauri_plugin_autostart::MacosLauncher;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_store::Builder::default().build())
        .plugin(tauri_plugin_autostart::init(
            MacosLauncher::LaunchAgent,
            Some(vec![]),
        ))
        .setup(|app| {
            // --- System Tray ---
            let new_chat = MenuItem::with_id(app, "new_chat", "New Chat", true, None::<&str>)?;
            let toggle_theme =
                MenuItem::with_id(app, "toggle_theme", "Toggle Theme", true, None::<&str>)?;
            let quit = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>)?;

            let menu = Menu::with_items(app, &[&new_chat, &toggle_theme, &quit])?;

            TrayIconBuilder::new()
                .icon(app.default_window_icon().cloned().unwrap())
                .menu(&menu)
                .tooltip("PyClaw")
                .on_menu_event(|app, event| match event.id().as_ref() {
                    "new_chat" => {
                        if let Some(window) = app.get_webview_window("main") {
                            let _ = window.eval("window.location.href = '/chat'");
                            let _ = window.show();
                            let _ = window.set_focus();
                        }
                    }
                    "toggle_theme" => {
                        if let Some(window) = app.get_webview_window("main") {
                            let _ = window.eval(
                                r#"
                                (function() {
                                    var html = document.documentElement;
                                    var isDark = html.classList.contains('dark');
                                    if (isDark) {
                                        html.classList.remove('dark');
                                        html.classList.add('light');
                                        localStorage.setItem('theme', 'light');
                                    } else {
                                        html.classList.remove('light');
                                        html.classList.add('dark');
                                        localStorage.setItem('theme', 'dark');
                                    }
                                })();
                                "#,
                            );
                        }
                    }
                    "quit" => {
                        app.exit(0);
                    }
                    _ => {}
                })
                .build(app)?;

            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
