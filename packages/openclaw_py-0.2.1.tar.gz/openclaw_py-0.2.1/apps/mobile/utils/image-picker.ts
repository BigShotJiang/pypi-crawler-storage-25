import * as ImagePicker from 'expo-image-picker';
import * as Sharing from 'expo-sharing';

/** Common options for image selection */
export interface ImagePickerOptions {
  /** Whether to allow video selection (default: false) */
  allowsEditing?: boolean;
  /** Image quality from 0 to 1 (default: 0.8) */
  quality?: number;
  /** Maximum width for the returned image */
  maxWidth?: number;
  /** Maximum height for the returned image */
  maxHeight?: number;
}

/** Normalized result from image selection */
export interface SelectedImage {
  /** Local URI of the selected image */
  uri: string;
  /** MIME type (e.g. 'image/jpeg') */
  mimeType: string;
  /** Width in pixels */
  width: number;
  /** Height in pixels */
  height: number;
  /** File size in bytes, if available */
  fileSize: number | null;
}

/** Request camera roll / media library permission. Returns granted status. */
export async function requestMediaLibraryPermission(): Promise<boolean> {
  const { status: existingStatus } =
    await ImagePicker.getMediaLibraryPermissionsAsync();
  if (existingStatus === 'granted') {
    return true;
  }

  const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  return status === 'granted';
}

/** Request camera permission. Returns granted status. */
export async function requestCameraPermission(): Promise<boolean> {
  const { status: existingStatus } =
    await ImagePicker.getCameraPermissionsAsync();
  if (existingStatus === 'granted') {
    return true;
  }

  const { status } = await ImagePicker.requestCameraPermissionsAsync();
  return status === 'granted';
}

/** Pick an image from the device photo library. Returns null if cancelled. */
export async function pickImageFromLibrary(
  options: ImagePickerOptions = {},
): Promise<SelectedImage | null> {
  const hasPermission = await requestMediaLibraryPermission();
  if (!hasPermission) {
    return null;
  }

  const {
    allowsEditing = false,
    quality = 0.8,
    maxWidth = 1920,
    maxHeight = 1920,
  } = options;

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsEditing,
    quality,
    allowsMultipleSelection: false,
  });

  if (result.canceled || !result.assets?.length) {
    return null;
  }

  const asset = result.assets[0];
  return normalizeAsset(asset);
}

/** Take a photo with the device camera. Returns null if cancelled. */
export async function pickImageFromCamera(
  options: ImagePickerOptions = {},
): Promise<SelectedImage | null> {
  const hasPermission = await requestCameraPermission();
  if (!hasPermission) {
    return null;
  }

  const {
    allowsEditing = true,
    quality = 0.8,
    maxWidth = 1920,
    maxHeight = 1920,
  } = options;

  const result = await ImagePicker.launchCameraAsync({
    allowsEditing,
    quality,
  });

  if (result.canceled || !result.assets?.length) {
    return null;
  }

  const asset = result.assets[0];
  return normalizeAsset(asset);
}

/** Share an image URI via the system share sheet. */
export async function shareImage(uri: string): Promise<void> {
  const isAvailable = await Sharing.isAvailableAsync();
  if (!isAvailable) {
    return;
  }

  await Sharing.shareAsync(uri, {
    mimeType: 'image/jpeg',
    dialogTitle: 'Share image',
  });
}

/** Normalize an ImagePicker asset into a consistent SelectedImage type. */
function normalizeAsset(
  asset: ImagePicker.ImagePickerAsset,
): SelectedImage {
  const mimeType = inferMimeType(asset.uri);
  return {
    uri: asset.uri,
    mimeType,
    width: asset.width,
    height: asset.height,
    fileSize: asset.fileSize ?? null,
  };
}

/** Infer MIME type from URI extension. */
function inferMimeType(uri: string): string {
  const lower = uri.toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.gif')) return 'image/gif';
  if (lower.endsWith('.webp')) return 'image/webp';
  return 'image/jpeg';
}
