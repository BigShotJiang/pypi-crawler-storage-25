import * as LocalAuthentication from 'expo-local-authentication';

/** Result of biometric availability check */
export interface BiometricAvailability {
  /** Whether biometric hardware is present on the device */
  available: boolean;
  /** Supported biometric types */
  biometryTypes: LocalAuthentication.AuthenticationType[];
  /** Whether the user has enrolled biometric credentials */
  enrolled: boolean;
}

/** Check if biometric authentication is available and enrolled. */
export async function checkBiometricAvailability(): Promise<BiometricAvailability> {
  const compatible = await LocalAuthentication.hasHardwareAsync();
  const enrolled = await LocalAuthentication.isEnrolledAsync();
  const supportedTypes =
    await LocalAuthentication.supportedAuthenticationTypesAsync();

  return {
    available: compatible,
    biometryTypes: supportedTypes,
    enrolled,
  };
}

/** Options for biometric authentication prompt */
export interface AuthenticateOptions {
  /** Prompt message shown to the user */
  promptMessage?: string;
  /** Fallback message when biometric auth fails */
  fallbackLabel?: string;
  /** Whether to cancel authentication and fall back to passcode */
  cancelLabel?: string;
  /** Whether to disable device passcode fallback (default: false) */
  disableDeviceFallback?: boolean;
}

/** Result of a biometric authentication attempt */
export interface AuthenticateResult {
  /** Whether authentication succeeded */
  success: boolean;
  /** Error message if authentication failed */
  error: string | null;
}

/** Authenticate the user with biometrics. */
export async function authenticateWithBiometrics(
  options: AuthenticateOptions = {},
): Promise<AuthenticateResult> {
  const {
    promptMessage = 'Authenticate to continue',
    fallbackLabel = 'Use passcode',
    cancelLabel = 'Cancel',
    disableDeviceFallback = false,
  } = options;

  const availability = await checkBiometricAvailability();

  if (!availability.available) {
    return {
      success: false,
      error: 'Biometric hardware not available on this device',
    };
  }

  if (!availability.enrolled) {
    return {
      success: false,
      error: 'No biometric credentials enrolled. Set up biometrics in device settings',
    };
  }

  try {
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage,
      fallbackLabel,
      cancelLabel,
      disableDeviceFallback,
    });

    return {
      success: result.success,
      error: result.success ? null : 'Authentication failed or was cancelled',
    };
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Unknown authentication error';
    return { success: false, error: message };
  }
}

/** Get a human-readable label for the primary biometric type. */
export function getBiometricTypeName(
  types: LocalAuthentication.AuthenticationType[],
): string {
  if (types.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION)) {
    return 'Face ID';
  }
  if (types.includes(LocalAuthentication.AuthenticationType.FINGERPRINT)) {
    return 'Touch ID';
  }
  if (types.includes(LocalAuthentication.AuthenticationType.IRIS)) {
    return 'Iris';
  }
  return 'Biometrics';
}
