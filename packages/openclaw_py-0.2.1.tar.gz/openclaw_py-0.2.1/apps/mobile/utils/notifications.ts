import * as Notifications from 'expo-notifications';
import type { EventSubscription } from 'expo-modules-core';
import { Platform } from 'react-native';

/** Configure notification behavior when app is in foreground */
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

/** Request notification permissions. Returns granted status. */
export async function requestNotificationPermission(): Promise<boolean> {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  if (existingStatus === 'granted') {
    return true;
  }

  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

/** Register for push notifications and return the push token. Returns null on failure. */
export async function registerPushToken(): Promise<string | null> {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#6366f1',
    });
  }

  const hasPermission = await requestNotificationPermission();
  if (!hasPermission) {
    return null;
  }

  try {
    const { data: token } = await Notifications.getExpoPushTokenAsync();
    return token ?? null;
  } catch {
    return null;
  }
}

/** Schedule a local notification. Returns the notification identifier. */
export async function scheduleLocalNotification(
  title: string,
  body: string,
  seconds: number = 0,
): Promise<string> {
  const trigger: Notifications.NotificationTriggerInput | null =
    seconds > 0
      ? { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds }
      : null;

  return Notifications.scheduleNotificationAsync({
    content: { title, body },
    trigger,
  });
}

/** Cancel a scheduled notification by identifier. */
export async function cancelScheduledNotification(
  identifier: string,
): Promise<void> {
  await Notifications.cancelScheduledNotificationAsync(identifier);
}

/** Cancel all scheduled notifications. */
export async function cancelAllScheduledNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

/** Subscribe to notifications received while the app is in the foreground. */
export function addNotificationReceivedListener(
  listener: (notification: Notifications.Notification) => void,
): EventSubscription {
  return Notifications.addNotificationReceivedListener(listener);
}

/** Subscribe to notification tap responses. */
export function addNotificationResponseReceivedListener(
  listener: (response: Notifications.NotificationResponse) => void,
): EventSubscription {
  return Notifications.addNotificationResponseReceivedListener(listener);
}

/** Remove a notification subscription. */
export function removeNotificationSubscription(
  subscription: EventSubscription,
): void {
  subscription.remove();
}
