/**
 * Mobile utility modules for Expo native integrations.
 * Each module is independently exported for optimal tree-shaking.
 */

export {
  requestNotificationPermission,
  registerPushToken,
  scheduleLocalNotification,
  cancelScheduledNotification,
  cancelAllScheduledNotifications,
  addNotificationReceivedListener,
  addNotificationResponseReceivedListener,
  removeNotificationSubscription,
} from './notifications';

export type { BiometricAvailability, AuthenticateOptions, AuthenticateResult } from './biometric';
export {
  checkBiometricAvailability,
  authenticateWithBiometrics,
  getBiometricTypeName,
} from './biometric';

export type { ImagePickerOptions, SelectedImage } from './image-picker';
export {
  requestMediaLibraryPermission,
  requestCameraPermission,
  pickImageFromLibrary,
  pickImageFromCamera,
  shareImage,
} from './image-picker';
