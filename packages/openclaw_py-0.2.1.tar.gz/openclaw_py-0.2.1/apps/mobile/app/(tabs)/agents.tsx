import { View, Text, StyleSheet } from 'react-native';

export default function AgentsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Agents</Text>
      <Text style={styles.subtitle}>Agent management coming soon</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
});
