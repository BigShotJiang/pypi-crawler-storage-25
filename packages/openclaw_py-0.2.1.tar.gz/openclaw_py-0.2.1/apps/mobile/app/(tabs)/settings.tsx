import { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  Switch,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import {
  requestNotificationPermission,
  registerPushToken,
  addNotificationReceivedListener,
  addNotificationResponseReceivedListener,
  removeNotificationSubscription,
} from '../../utils/notifications';
import {
  checkBiometricAvailability,
  authenticateWithBiometrics,
  getBiometricTypeName,
  type BiometricAvailability,
} from '../../utils/biometric';

export default function SettingsScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [biometricInfo, setBiometricInfo] =
    useState<BiometricAvailability | null>(null);

  useEffect(() => {
    checkBiometricAvailability().then(setBiometricInfo);
  }, []);

  useEffect(() => {
    if (!notificationsEnabled) return;

    const receivedSub = addNotificationReceivedListener((notification) => {
      console.log('Notification received:', notification.request.content.title);
    });

    const responseSub = addNotificationResponseReceivedListener((response) => {
      console.log('Notification tapped:', response.notification.request.content.title);
    });

    return () => {
      removeNotificationSubscription(receivedSub);
      removeNotificationSubscription(responseSub);
    };
  }, [notificationsEnabled]);

  const handleToggleNotifications = useCallback(
    async (value: boolean) => {
      if (value) {
        const granted = await requestNotificationPermission();
        if (!granted) {
          Alert.alert(
            'Permission Denied',
            'Enable notifications in device settings to receive alerts.',
          );
          return;
        }

        const token = await registerPushToken();
        if (token) {
          console.log('Push token registered:', token);
        }

        setNotificationsEnabled(true);
      } else {
        setNotificationsEnabled(false);
      }
    },
    [],
  );

  const handleBiometricAuth = useCallback(async () => {
    const result = await authenticateWithBiometrics({
      promptMessage: 'Verify your identity',
    });

    if (result.success) {
      Alert.alert('Authenticated', 'Biometric verification succeeded');
    } else if (result.error) {
      Alert.alert('Authentication Failed', result.error);
    }
  }, []);

  return (
    <ScrollView style={styles.scrollView} contentContainerStyle={styles.container}>
      <Text style={styles.title}>Settings</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Notifications</Text>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Push Notifications</Text>
          <Switch
            value={notificationsEnabled}
            onValueChange={handleToggleNotifications}
            trackColor={{ false: '#d1d5db', true: '#6366f1' }}
            thumbColor={notificationsEnabled ? '#fff' : '#f3f4f6'}
            accessibilityLabel="Toggle push notifications"
          />
        </View>
        <Text style={styles.hint}>
          {notificationsEnabled
            ? 'You will receive push notifications'
            : 'Enable to receive push notifications'}
        </Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Security</Text>
        {biometricInfo ? (
          <>
            <View style={styles.row}>
              <Text style={styles.rowLabel}>
                {getBiometricTypeName(biometricInfo.biometryTypes)}
              </Text>
              <Text style={styles.statusChip}>
                {biometricInfo.enrolled ? 'Enrolled' : 'Not Set Up'}
              </Text>
            </View>
            {biometricInfo.enrolled && (
              <Text style={styles.link} onPress={handleBiometricAuth}>
                Test Authentication
              </Text>
            )}
          </>
        ) : (
          <Text style={styles.hint}>Checking biometric availability...</Text>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>About</Text>
        <Text style={styles.hint}>PyClaw Mobile v0.1.0</Text>
        <Text style={styles.hint}>Gateway: Not connected</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  container: {
    padding: 20,
    paddingBottom: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 24,
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6b7280',
    textTransform: 'uppercase',
    letterSpacing: 0.05,
    marginBottom: 12,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  rowLabel: {
    fontSize: 16,
    color: '#111827',
  },
  statusChip: {
    fontSize: 13,
    fontWeight: '500',
    color: '#6366f1',
    backgroundColor: '#eef2ff',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    overflow: 'hidden',
  },
  hint: {
    fontSize: 13,
    color: '#9ca3af',
    marginTop: 6,
  },
  link: {
    fontSize: 14,
    color: '#6366f1',
    marginTop: 12,
  },
});
