import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./__tests__/setup.tsx'],
    include: ['__tests__/**/*.test.{ts,tsx}'],
  },
  resolve: {
    alias: {
      // Mock platform-specific modules that don't exist in jsdom
      '@tauri-apps/plugin-store': path.resolve(
        __dirname,
        '__tests__/__mocks__/tauri-plugin-store.ts'
      ),
      '@react-native-async-storage/async-storage': path.resolve(
        __dirname,
        '__tests__/__mocks__/async-storage.ts'
      ),
      // Handle @/ path aliases
      '@': path.resolve(__dirname, '.'),
    },
  },
});
