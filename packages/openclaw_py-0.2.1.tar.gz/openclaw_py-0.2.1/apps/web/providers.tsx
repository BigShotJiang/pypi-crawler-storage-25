'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from 'next-themes';
import { useState, useEffect } from 'react';
import { loadPersistedState, setupPersistence, GatewayProvider } from '@pyclaw/shared';

// Create a singleton QueryClient to avoid SSR issues
let queryClient: QueryClient | undefined;

function getQueryClient() {
  if (!queryClient) {
    queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: 2,
          refetchOnWindowFocus: false,
          staleTime: 30_000,
        },
      },
    });
  }
  return queryClient;
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [client] = useState(() => getQueryClient());
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    loadPersistedState().catch(() => {}).then(() => setupPersistence());
  }, []);

  // Don't render GatewayProvider until mounted (client-side only)
  // This ensures useEffect runs properly in the browser
  if (!mounted) {
    return (
      <QueryClientProvider client={client}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          {children}
        </ThemeProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={client}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <GatewayProvider>
          {children}
        </GatewayProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
