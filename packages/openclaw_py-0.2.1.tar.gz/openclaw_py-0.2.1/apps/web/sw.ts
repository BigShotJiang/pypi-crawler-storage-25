import type { PrecacheEntry, SerwistGlobalConfig } from "serwist";
import { Serwist, CacheFirst, NetworkOnly } from "serwist";

declare global {
  interface WorkerGlobalScope extends SerwistGlobalConfig {
    __SW_MANIFEST: (string | PrecacheEntry)[];
  }
}

declare const self: WorkerGlobalScope;

const serwist = new Serwist({
  precacheEntries: self.__SW_MANIFEST,
  skipWaiting: true,
  clientsClaim: true,
  runtimeCaching: [
    // API requests: network-only — always hit the server for fresh data
    {
      matcher: ({ url }) => url.pathname.startsWith("/api/") || url.pathname.startsWith("/v1/"),
      handler: new NetworkOnly(),
    },
    // Static JS/CSS: cache-first for speed
    {
      matcher: ({ request }) => request.destination === "script" || request.destination === "style",
      handler: new CacheFirst({
        cacheName: "static-assets",
      }),
    },
    // Images and fonts: cache-first
    {
      matcher: ({ request }) => request.destination === "image" || request.destination === "font",
      handler: new CacheFirst({
        cacheName: "media-assets",
      }),
    },
    // Navigation requests: network-only
    {
      matcher: ({ request }) => request.mode === "navigate",
      handler: new NetworkOnly(),
    },
  ],
});

serwist.addEventListeners();
