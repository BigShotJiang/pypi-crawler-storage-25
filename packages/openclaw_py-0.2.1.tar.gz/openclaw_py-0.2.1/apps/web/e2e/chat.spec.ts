import { test, expect } from '@playwright/test';

test.describe('Chat Page', () => {
  test('should display chat interface', async ({ page }) => {
    await page.goto('/chat');
    await expect(page.getByRole('heading', { name: 'Chat' })).toBeVisible();
  });

  test('should show empty state when no messages', async ({ page }) => {
    await page.goto('/chat');
    await expect(page.getByText('No messages yet')).toBeVisible();
  });
});
