import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import ChatPage from '../../app/chat/page';

// Mock the WebSocket and stores
vi.mock('@pyclaw/shared', async () => {
  const actual = await vi.importActual('@pyclaw/shared');

  // Create a controlled mock for chat store
  const mockChatStore = {
    messages: [],
    isStreaming: false,
    streamingContent: '',
    streamingToolCalls: [],
    addUserMessage: vi.fn(),
    startAssistantStream: vi.fn(),
    appendDelta: vi.fn(),
    addToolCall: vi.fn(),
    updateToolCall: vi.fn(),
    finishStream: vi.fn(),
    finishStreamWithError: vi.fn(),
    clearMessages: vi.fn(),
    loadMessages: vi.fn(),
    getState: () => mockChatStore,
  };

  return {
    ...actual,
    useGatewayWebSocket: () => ({
      connect: vi.fn(),
      connected: true,
      connectionState: 'connected' as const,
      streamChat: vi.fn().mockResolvedValue(undefined),
    }),
    useChatStore: vi.fn(() => mockChatStore),
    getApiBaseUrl: () => 'http://localhost:8765',
  };
});

describe('ChatPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders chat page with header', () => {
    render(<ChatPage />);

    expect(screen.getByText('Chat')).toBeDefined();
  });

  it('shows empty state when no messages', () => {
    render(<ChatPage />);

    expect(screen.getByText('No messages yet')).toBeDefined();
  });

  it('renders chat input', () => {
    render(<ChatPage />);

    expect(screen.getByPlaceholderText('Type a message...')).toBeDefined();
  });

  it('shows clear button in header', () => {
    render(<ChatPage />);

    expect(screen.getByText('Clear')).toBeDefined();
  });
});
