/**
 * Mock for @react-native-async-storage/async-storage (not available in test environment)
 */
import { vi } from 'vitest';

const AsyncStorage = {
  getItem: vi.fn().mockResolvedValue(null),
  setItem: vi.fn().mockResolvedValue(undefined),
  removeItem: vi.fn().mockResolvedValue(undefined),
  clear: vi.fn().mockResolvedValue(undefined),
  getAllKeys: vi.fn().mockResolvedValue([]),
  multiGet: vi.fn().mockResolvedValue([]),
  multiSet: vi.fn().mockResolvedValue(undefined),
  multiRemove: vi.fn().mockResolvedValue(undefined),
};

export default AsyncStorage;
