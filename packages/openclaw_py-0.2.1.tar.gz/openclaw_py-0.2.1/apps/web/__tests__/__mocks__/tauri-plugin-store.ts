/**
 * Mock for @tauri-apps/plugin-store (not available in test environment)
 */
import { vi } from 'vitest';

export const Store = vi.fn().mockImplementation(() => ({
  get: vi.fn().mockResolvedValue(null),
  set: vi.fn().mockResolvedValue(undefined),
  save: vi.fn().mockResolvedValue(undefined),
  delete: vi.fn().mockResolvedValue(false),
}));

export const load = vi.fn().mockResolvedValue({
  get: vi.fn().mockResolvedValue(null),
  set: vi.fn().mockResolvedValue(undefined),
  save: vi.fn().mockResolvedValue(undefined),
  delete: vi.fn().mockResolvedValue(false),
});
