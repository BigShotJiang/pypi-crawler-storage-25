import '@testing-library/jest-dom/vitest';
import { vi } from 'vitest';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactElement } from 'react';

// Create a new query client for each test
export function createTestQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
        staleTime: 0,
      },
      mutations: {
        retry: false,
      },
    },
  });
}

// Wrapper for tests that need React Query
export function createTestWrapper() {
  const queryClient = createTestQueryClient();
  return function TestWrapper({ children }: { children: React.ReactNode }) {
    return (
      <QueryClientProvider client={queryClient}>
        {children}
      </QueryClientProvider>
    );
  };
}

// Mock @tanstack/react-query to use test wrapper
vi.mock('@tanstack/react-query', async () => {
  const actual = await vi.importActual('@tanstack/react-query');
  return {
    ...actual,
    useQueryClient: () => createTestQueryClient(),
  };
});

// Mock Next.js router
vi.mock('next/navigation', () => ({
  useRouter: vi.fn(() => ({
    push: vi.fn(),
    replace: vi.fn(),
    back: vi.fn(),
  })),
  usePathname: vi.fn(() => '/agents'),
  useSearchParams: vi.fn(() => new URLSearchParams()),
}));

// Mock Next.js dynamic import
vi.mock('next/dynamic', () => ({
  __esModule: true,
  default: (fn: () => Promise<{ default: React.ComponentType }>) => {
    const component = fn();
    return component;
  },
}));

// Mock the export-chat module
vi.mock('@/lib/export-chat', () => ({
  downloadChatAsMarkdown: vi.fn(),
}));

// Mock the hooks module — matches actual return types
vi.mock('@/hooks', () => ({
  useScrollToBottom: vi.fn(() => ({
    scrollRef: { current: null },
    scrollToBottom: vi.fn(),
  })),
  useVoiceInput: vi.fn(() => ({
    isListening: false,
    transcript: '',
    error: null,
    isSupported: { supported: false, reason: 'not-supported' as const },
    startListening: vi.fn(),
    stopListening: vi.fn(),
  })),
  useVoiceOutput: vi.fn(() => ({
    isSpeaking: false,
    speak: vi.fn(),
    stop: vi.fn(),
  })),
  useKeyboardShortcuts: vi.fn(),
  useTranslation: vi.fn(() => ({
    t: (key: string) => key,
    locale: 'en',
    setLocale: vi.fn(),
  })),
}));

// Mock animations module
vi.mock('@/components/animations', () => ({
  FadeIn: ({ children }: { children: React.ReactNode }) => children,
  ScaleIn: ({ children }: { children: React.ReactNode }) => children,
  AnimatePresence: ({ children }: { children: React.ReactNode }) => children,
}));
