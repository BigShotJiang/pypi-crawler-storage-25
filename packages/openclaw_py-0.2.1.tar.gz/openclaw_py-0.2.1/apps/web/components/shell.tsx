'use client';

import { Sidebar } from './sidebar';
import { CommandPalette } from './command-palette';
import { Toaster } from 'sonner';
import { Menu } from 'lucide-react';
import { useAppStore } from '@pyclaw/shared';
import { cn } from '@pyclaw/ui';
import { useKeyboardShortcuts } from '../hooks';

export function Shell({ children }: { children: React.ReactNode }) {
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);

  // Initialize global keyboard shortcuts
  useKeyboardShortcuts();

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Mobile header bar */}
        <header
          className={cn(
            'flex h-14 items-center border-b bg-card px-4 md:hidden',
            sidebarOpen && 'hidden'
          )}
        >
          <button
            onClick={toggleSidebar}
            className="rounded p-2 hover:bg-accent"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <span className="ml-2 font-semibold">PyClaw</span>
        </header>
        <main className="flex-1 overflow-auto">{children}</main>
      </div>
      <Toaster position="bottom-right" richColors />
      <CommandPalette />
    </div>
  );
}
