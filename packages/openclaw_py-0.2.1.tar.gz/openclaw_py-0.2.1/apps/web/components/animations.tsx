'use client';

import { ReactNode } from 'react';
import { motion, Variants, AnimatePresence } from 'framer-motion';

/**
 * Animation configuration constants
 * Duration: 200-300ms with ease-out for smooth, performant animations
 */
const ANIMATION_CONFIG = {
  duration: 0.25,
  ease: [0, 0, 0.2, 1] as const, // ease-out curve
} as const;

/**
 * FadeIn - Smooth opacity transition for message bubbles
 * Used for: Message bubbles, notifications, toast messages
 */
interface FadeInProps {
  children: ReactNode;
  className?: string;
  delay?: number;
}

const fadeVariants: Variants = {
  initial: { opacity: 0, y: 8 },
  animate: {
    opacity: 1,
    y: 0,
    transition: ANIMATION_CONFIG,
  },
  exit: {
    opacity: 0,
    transition: { duration: 0.15 },
  },
};

export function FadeIn({ children, className, delay = 0 }: FadeInProps) {
  return (
    <motion.div
      initial="initial"
      animate="animate"
      exit="exit"
      variants={fadeVariants}
      transition={{ delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/**
 * ScaleIn - Scale and fade animation for buttons
 * Used for: Send button, action buttons, modal triggers
 */
interface ScaleInProps {
  children: ReactNode;
  className?: string;
  delay?: number;
}

const scaleVariants: Variants = {
  initial: { opacity: 0, scale: 0.9 },
  animate: {
    opacity: 1,
    scale: 1,
    transition: ANIMATION_CONFIG,
  },
  exit: {
    opacity: 0,
    scale: 0.9,
    transition: { duration: 0.15 },
  },
};

export function ScaleIn({ children, className, delay = 0 }: ScaleInProps) {
  return (
    <motion.div
      initial="initial"
      animate="animate"
      exit="exit"
      variants={scaleVariants}
      transition={{ delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/**
 * ScaleButton - Interactive button with scale animation on hover/tap
 * Used for: Buttons that need tactile feedback
 */
interface ScaleButtonProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  'aria-label'?: string;
}

export function ScaleButton({
  children,
  className,
  onClick,
  disabled = false,
  type = 'button',
  'aria-label': ariaLabel,
}: ScaleButtonProps) {
  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      className={className}
      whileHover={{ scale: disabled ? 1 : 1.05 }}
      whileTap={{ scale: disabled ? 1 : 0.95 }}
      transition={{ duration: 0.15 }}
    >
      {children}
    </motion.button>
  );
}

/**
 * SlideIn - Slide animation for sidebars and panels
 * Used for: Sidebars, slide-out panels, drawers
 */
interface SlideInProps {
  children: ReactNode;
  className?: string;
  direction?: 'left' | 'right' | 'up' | 'down';
  delay?: number;
}

const slideVariants: Record<'left' | 'right' | 'up' | 'down', Variants> = {
  left: {
    initial: { opacity: 0, x: -20 },
    animate: {
      opacity: 1,
      x: 0,
      transition: ANIMATION_CONFIG,
    },
    exit: {
      opacity: 0,
      x: -20,
      transition: { duration: 0.15 },
    },
  },
  right: {
    initial: { opacity: 0, x: 20 },
    animate: {
      opacity: 1,
      x: 0,
      transition: ANIMATION_CONFIG,
    },
    exit: {
      opacity: 0,
      x: 20,
      transition: { duration: 0.15 },
    },
  },
  up: {
    initial: { opacity: 0, y: 20 },
    animate: {
      opacity: 1,
      y: 0,
      transition: ANIMATION_CONFIG,
    },
    exit: {
      opacity: 0,
      y: 20,
      transition: { duration: 0.15 },
    },
  },
  down: {
    initial: { opacity: 0, y: -20 },
    animate: {
      opacity: 1,
      y: 0,
      transition: ANIMATION_CONFIG,
    },
    exit: {
      opacity: 0,
      y: -20,
      transition: { duration: 0.15 },
    },
  },
};

export function SlideIn({
  children,
  className,
  direction = 'left',
  delay = 0,
}: SlideInProps) {
  return (
    <motion.div
      initial="initial"
      animate="animate"
      exit="exit"
      variants={slideVariants[direction]}
      transition={{ delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/**
 * AnimatePresence wrapper for conditional rendering with animations
 */
export { AnimatePresence };

/**
 * Motion components for direct use
 */
export { motion };
