'use client';

import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Command } from 'cmdk';
import {
  MessageSquare,
  FileText,
  PanelLeftClose,
  LayoutDashboard,
  Settings,
  Search,
} from 'lucide-react';
import { useAppStore } from '@pyclaw/shared';
import { cn } from '@pyclaw/ui';

interface CommandItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  shortcut: string;
  action: () => void;
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  const setCurrentSession = useAppStore((s) => s.setCurrentSession);

  // Define commands
  const commands: CommandItem[] = [
    {
      id: 'new-chat',
      label: 'New Chat',
      icon: MessageSquare,
      shortcut: '⌘N',
      action: useCallback(() => {
        setCurrentSession(null);
        router.push('/chat');
        setOpen(false);
      }, [router, setCurrentSession]),
    },
    {
      id: 'new-session',
      label: 'New Session',
      icon: FileText,
      shortcut: '⌘⇧N',
      action: useCallback(() => {
        router.push('/sessions');
        setOpen(false);
      }, [router]),
    },
    {
      id: 'toggle-sidebar',
      label: 'Toggle Sidebar',
      icon: PanelLeftClose,
      shortcut: '⌘B',
      action: useCallback(() => {
        toggleSidebar();
        setOpen(false);
      }, [toggleSidebar]),
    },
    {
      id: 'go-dashboard',
      label: 'Go to Dashboard',
      icon: LayoutDashboard,
      shortcut: '⌘D',
      action: useCallback(() => {
        router.push('/dashboard');
        setOpen(false);
      }, [router]),
    },
    {
      id: 'go-settings',
      label: 'Go to Settings',
      icon: Settings,
      shortcut: '⌘,',
      action: useCallback(() => {
        router.push('/settings');
        setOpen(false);
      }, [router]),
    },
  ];

  // Toggle command palette with Cmd+K
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);

  // Execute command with its shortcut
  useEffect(() => {
    if (!open) return;

    const handleShortcut = (e: KeyboardEvent) => {
      const isMac = typeof window !== 'undefined' && navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const cmdKey = isMac ? e.metaKey : e.ctrlKey;

      if (cmdKey && e.key === 'n' && !e.shiftKey) {
        e.preventDefault();
        const cmd = commands.find((c) => c.id === 'new-chat');
        cmd?.action();
      } else if (cmdKey && e.shiftKey && e.key === 'N') {
        e.preventDefault();
        const cmd = commands.find((c) => c.id === 'new-session');
        cmd?.action();
      } else if (cmdKey && e.key === 'b') {
        e.preventDefault();
        const cmd = commands.find((c) => c.id === 'toggle-sidebar');
        cmd?.action();
      } else if (cmdKey && e.key === 'd') {
        e.preventDefault();
        const cmd = commands.find((c) => c.id === 'go-dashboard');
        cmd?.action();
      }
    };

    document.addEventListener('keydown', handleShortcut);
    return () => document.removeEventListener('keydown', handleShortcut);
  }, [open, commands]);

  return (
    <Command.Dialog
      open={open}
      onOpenChange={setOpen}
      className={cn(
        'fixed inset-0 z-50',
        'data-[state=open]:animate-in data-[state=closed]:animate-out',
        'data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0'
      )}
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm"
        onClick={() => setOpen(false)}
      />

      {/* Dialog */}
      <div className="fixed left-1/2 top-[20%] z-50 w-full max-w-lg -translate-x-1/2">
        <Command
          className={cn(
            'rounded-xl border bg-card shadow-2xl',
            'overflow-hidden'
          )}
        >
          {/* Search input */}
          <div className="flex items-center border-b px-3">
            <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
            <Command.Input
              autoFocus
              placeholder="Type a command or search..."
              className="flex h-12 w-full bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>

          {/* Command list */}
          <Command.List className="max-h-[300px] overflow-y-auto p-2">
            <Command.Empty className="py-6 text-center text-sm text-muted-foreground">
              No results found.
            </Command.Empty>

            <Command.Group heading="Actions">
              {commands.map((command) => (
                <Command.Item
                  key={command.id}
                  value={command.label}
                  onSelect={command.action}
                  className={cn(
                    'flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2.5',
                    'aria-selected:bg-accent aria-selected:text-accent-foreground',
                    'transition-colors'
                  )}
                >
                  <command.icon className="h-4 w-4 text-muted-foreground" />
                  <span className="flex-1">{command.label}</span>
                  <kbd className="pointer-events-none ml-auto hidden h-5 items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium sm:flex">
                    {command.shortcut}
                  </kbd>
                </Command.Item>
              ))}
            </Command.Group>
          </Command.List>

          {/* Footer hint */}
          <div className="flex items-center justify-between border-t px-4 py-2 text-xs text-muted-foreground">
            <span>Use arrow keys to navigate</span>
            <span>ESC to close</span>
          </div>
        </Command>
      </div>
    </Command.Dialog>
  );
}
