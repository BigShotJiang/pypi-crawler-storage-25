'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, useEffect, useCallback, useRef } from 'react';
import { cn } from '@pyclaw/ui';
import {
  LayoutDashboard,
  Bot,
  MessageSquare,
  Settings,
  Radio,
  Info,
  FileText,
  ChevronLeft,
  ChevronRight,
  Smartphone,
  Sparkles,
  Puzzle,
  BarChart3,
  Clock,
} from 'lucide-react';
import { useAppStore } from '@pyclaw/shared';
import { useTranslation } from '../hooks/useTranslation';

const navItems = [
  { href: '/dashboard', icon: LayoutDashboard, labelKey: 'dashboard' as const },
  { href: '/chat', icon: MessageSquare, labelKey: 'chat' as const },
  { href: '/agents', icon: Bot, labelKey: 'agents' as const },
  { href: '/sessions', icon: FileText, labelKey: 'sessions' as const },
  { href: '/cron', icon: Clock, labelKey: 'cron' as const },
  { href: '/usage', icon: BarChart3, labelKey: 'usage' as const },
  { href: '/channels', icon: Radio, labelKey: 'channels' as const },
  { href: '/skills', icon: Sparkles, labelKey: 'skills' as const },
  { href: '/mcp', icon: Puzzle, labelKey: 'mcp' as const },
  { href: '/devices', icon: Smartphone, labelKey: 'devices' as const },
  { href: '/settings', icon: Settings, labelKey: 'settings' as const },
  { href: '/system', icon: Info, labelKey: 'system' as const },
];

const MOBILE_BREAKPOINT = 768;

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    function check() {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    }
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  return isMobile;
}

export function Sidebar() {
  const pathname = usePathname();
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);
  const isMobile = useIsMobile();
  const prevIsMobile = useRef<boolean | null>(null);
  const { t } = useTranslation('nav');
  const { t: tSidebar } = useTranslation('sidebar');
  const { t: tApp } = useTranslation('app');

  // Handle viewport changes for sidebar state
  useEffect(() => {
    // On initial mount (prevIsMobile.current is never set), sync with current viewport
    // On subsequent viewport changes (crossing breakpoint), auto-adjust
    const isFirstRender = prevIsMobile.current === null;
    const viewportChanged = prevIsMobile.current !== isMobile;

    if (isFirstRender || viewportChanged) {
      setSidebarOpen(!isMobile);
      prevIsMobile.current = isMobile;
    }
  }, [isMobile, setSidebarOpen]);

  // Close sidebar on mobile when navigating
  const handleNavClick = useCallback(() => {
    if (isMobile) {
      setSidebarOpen(false);
    }
  }, [isMobile, setSidebarOpen]);

  return (
    <>
      {/* Mobile overlay backdrop */}
      {isMobile && sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 transition-opacity"
          onClick={toggleSidebar}
          aria-hidden="true"
        />
      )}

      <aside
        className={cn(
          'flex h-screen flex-col border-r bg-card transition-all duration-300',
          // Mobile: overlay style with slide animation
          isMobile && 'fixed inset-y-0 left-0 z-40 w-64',
          isMobile && !sidebarOpen && '-translate-x-full',
          // Desktop: inline style with width transition
          !isMobile && (sidebarOpen ? 'w-64' : 'w-16')
        )}
      >
        {/* Header */}
        <div className="flex h-14 items-center border-b px-2">
          {sidebarOpen ? (
            <div className="flex w-full items-center justify-between px-2">
              <span className="font-semibold">{tApp('name')}</span>
              <button
                onClick={toggleSidebar}
                className="rounded p-1.5 hover:bg-accent"
                aria-label={tSidebar('collapse')}
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="flex w-full justify-center">
              <button
                onClick={toggleSidebar}
                className="flex h-8 w-8 items-center justify-center rounded hover:bg-accent"
                aria-label={tSidebar('expand')}
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 p-2">
          {navItems.map((item) => {
            const isActive = pathname.startsWith(item.href);
            const label = t(item.labelKey);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={handleNavClick}
                className={cn(
                  'flex items-center rounded-lg py-2 text-sm transition-colors',
                  sidebarOpen ? 'gap-3 px-3' : 'justify-center px-0',
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                )}
                title={!sidebarOpen ? label : undefined}
              >
                <item.icon className="h-4 w-4 flex-shrink-0" />
                {sidebarOpen && <span>{label}</span>}
              </Link>
            );
          })}
        </nav>
      </aside>
    </>
  );
}
