import type { Config } from 'tailwindcss';
import tailwindPreset from '../../packages/ui/tailwind-preset';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
    '../../packages/ui/src/**/*.{js,ts,jsx,tsx}',
  ],
  presets: [tailwindPreset],
};

export default config;
