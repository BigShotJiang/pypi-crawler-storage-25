/**
 * Ambient type stubs for optional platform-specific dependencies.
 *
 * These modules are dynamically imported at runtime only on their
 * respective platforms (Tauri, React Native). Since they are not
 * installed in the web app, we provide type declarations here to
 * satisfy TypeScript when it resolves through the shared package.
 */
declare module "@tauri-apps/plugin-store" {
  export class Store {
    static load(path: string): Promise<Store>;
    get(key: string): Promise<unknown>;
    set(key: string, value: string): Promise<void>;
    delete(key: string): Promise<boolean>;
  }
}

declare module "@react-native-async-storage/async-storage" {
  const AsyncStorage: {
    getItem: (key: string) => Promise<string | null>;
    setItem: (key: string, value: string) => Promise<void>;
    removeItem: (key: string) => Promise<void>;
  };
  export default AsyncStorage;
}
