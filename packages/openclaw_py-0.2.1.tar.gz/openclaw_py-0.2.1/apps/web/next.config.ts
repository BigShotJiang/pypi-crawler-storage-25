import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

// Check if we're building for Tauri (static export needed)
const isTauriBuild = process.env.TAURI_BUILD === "1";

// Log for debugging
console.log("[next.config.ts] TAURI_BUILD:", process.env.TAURI_BUILD);
console.log("[next.config.ts] isTauriBuild:", isTauriBuild);

// next-intl plugin is needed for NextIntlClientProvider to work
const withNextIntl = createNextIntlPlugin("./i18n/request.ts");

const baseConfig: NextConfig = {
  trailingSlash: true,
  images: {
    unoptimized: true,
  },
  transpilePackages: ["@pyclaw/shared", "@pyclaw/ui"],
  turbopack: {},
  webpack: (config, { isServer }) => {
    // Platform-specific modules are dynamically imported at runtime only on
    // their respective platforms (Tauri / React Native).  They are never
    // available in the web build, so we tell webpack to provide empty stubs.
    const externals = [
      "@tauri-apps/plugin-store",
      "@react-native-async-storage/async-storage",
    ];
    for (const mod of externals) {
      config.resolve.alias[mod] = false;
    }

    // Konva uses browser APIs and cannot be bundled for server
    if (isServer) {
      config.externals = config.externals || [];
      if (Array.isArray(config.externals)) {
        config.externals.push('konva');
      }
    }

    return config;
  },
};

// Apply next-intl plugin first
const configWithIntl = withNextIntl(baseConfig);

// For Tauri builds: static export, skip serwist
// For web builds: apply serwist
let finalConfig: NextConfig;

if (isTauriBuild) {
  finalConfig = {
    ...configWithIntl,
    output: "export" as const,
  };
} else {
  // Web build: apply serwist
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const withSerwistInit = require("@serwist/next").default;

  const withSerwist = withSerwistInit({
    swSrc: "sw.ts",
    swDest: "public/sw.js",
    disable: process.env.NODE_ENV === "development",
  });

  finalConfig = withSerwist(configWithIntl);
}

console.log("[next.config.ts] Final config output:", (finalConfig as any).output);

export default finalConfig;
