/**
 * Chat export utility — converts chat messages to Markdown and triggers download.
 *
 * Uses native Web APIs (Blob + URL.createObjectURL) so no external
 * dependencies like file-saver are required.
 */

import type { ChatMessage, ToolCallInfo } from "@pyclaw/shared";

// ---------------------------------------------------------------------------
// Markdown generation
// ---------------------------------------------------------------------------

/** Format a Unix-ms timestamp as a human-readable date string. */
function formatDate(timestamp: number): string {
  return new Date(timestamp).toLocaleString();
}

/** Render a single ToolCallInfo as a Markdown details block. */
function renderToolCall(tc: ToolCallInfo): string {
  const statusLabel =
    tc.status === "completed"
      ? "completed"
      : tc.status === "error"
        ? "error"
        : "running";

  let block = `- **${tc.name}** \`${statusLabel}\``;

  if (tc.result !== undefined) {
    const resultStr =
      typeof tc.result === "string" ? tc.result : JSON.stringify(tc.result, null, 2);
    block += `\n  \`\`\`\n  ${resultStr.split("\n").join("\n  ")}\n  \`\`\``;
  }

  if (tc.error) {
    block += `\n  Error: ${tc.error}`;
  }

  return block;
}

/** Role display labels with emoji prefixes. */
const ROLE_LABELS: Record<ChatMessage["role"], string> = {
  user: "\uD83D\uDC64 User",
  assistant: "\uD83E\uDD16 Assistant",
  system: "\u2699\uFE0F System",
};

/**
 * Convert an array of ChatMessage objects into a formatted Markdown string.
 *
 * @param messages - The chat messages to export.
 * @param title    - Optional session title (defaults to "PyClaw Chat").
 * @returns A complete Markdown document as a string.
 */
export function exportChatToMarkdown(
  messages: ChatMessage[],
  title?: string,
): string {
  const exportDate = new Date().toLocaleString();
  const lines: string[] = [
    `# Chat: ${title ?? "PyClaw Chat"}`,
    `> Exported from PyClaw on ${exportDate}`,
    "",
    "---",
    "",
  ];

  for (const msg of messages) {
    const roleLabel = ROLE_LABELS[msg.role] ?? msg.role;
    lines.push(`## ${roleLabel}`);
    lines.push("");
    lines.push(msg.content);
    lines.push("");

    if (msg.toolCalls && msg.toolCalls.length > 0) {
      lines.push("**Tool Calls:**");
      lines.push("");
      for (const tc of msg.toolCalls) {
        lines.push(renderToolCall(tc));
      }
      lines.push("");
    }

    lines.push("---");
    lines.push("");
  }

  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// Download trigger
// ---------------------------------------------------------------------------

/**
 * Export chat messages as a Markdown file download.
 *
 * Creates an in-memory Blob, constructs an object URL, programmatically
 * clicks a temporary anchor element, then revokes the URL to free memory.
 *
 * @param messages - The chat messages to export.
 * @param title    - Optional session title (used in filename and heading).
 */
export function downloadChatAsMarkdown(
  messages: ChatMessage[],
  title?: string,
): void {
  const markdown = exportChatToMarkdown(messages, title);
  const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);

  const safeName = (title ?? "pyclaw-chat")
    .replace(/[^a-zA-Z0-9_-]/g, "-")
    .replace(/--+/g, "-")
    .replace(/^-|-$/g, "");
  const timestamp = new Date().toISOString().slice(0, 10);
  const filename = `${safeName}-${timestamp}.md`;

  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();

  // Cleanup
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
