'use client';

import { useHotkeys } from 'react-hotkeys-hook';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@pyclaw/shared';

/**
 * Global keyboard shortcuts for the PyClaw web application.
 *
 * Shortcuts:
 * - Cmd/Ctrl+N: New chat session (clears current session, navigates to /chat)
 * - Cmd/Ctrl+B: Toggle sidebar visibility
 *
 * These shortcuts work globally across the application.
 * The Command Palette (Cmd+K) handles its own shortcut internally.
 */
export function useKeyboardShortcuts() {
  const router = useRouter();
  const setCurrentSession = useAppStore((s) => s.setCurrentSession);
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);

  // Cmd+N: Create new chat session
  useHotkeys(
    'mod+n',
    (e) => {
      e.preventDefault();
      setCurrentSession(null);
      router.push('/chat');
    },
    { preventDefault: true },
    [router, setCurrentSession]
  );

  // Cmd+B: Toggle sidebar
  useHotkeys(
    'mod+b',
    (e) => {
      e.preventDefault();
      toggleSidebar();
    },
    { preventDefault: true },
    [toggleSidebar]
  );
}
