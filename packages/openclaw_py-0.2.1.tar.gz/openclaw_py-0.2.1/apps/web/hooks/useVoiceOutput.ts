'use client';

import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * Browser compatibility status for Web Speech API
 */
export type SpeechSynthesisSupport = {
  supported: boolean;
  reason: 'supported' | 'not-supported';
};

/**
 * Return type for useVoiceOutput hook
 */
interface UseVoiceOutputReturn {
  /** Whether the browser supports speech synthesis */
  isSupported: SpeechSynthesisSupport;
  /** Whether currently speaking */
  isSpeaking: boolean;
  /** Whether speech is paused */
  isPaused: boolean;
  /** Speak the given text */
  speak: (text: string) => void;
  /** Stop speaking */
  stop: () => void;
  /** Pause speaking */
  pause: () => void;
  /** Resume speaking */
  resume: () => void;
  /** Get available voices */
  voices: SpeechSynthesisVoice[];
  /** Set the voice by name */
  setVoice: (voiceName: string) => void;
  /** Currently selected voice name */
  selectedVoice: string | null;
}

/**
 * Custom hook for voice output using Web Speech API (SpeechSynthesis).
 *
 * Provides text-to-speech functionality with browser compatibility detection.
 *
 * @example
 * ```tsx
 * const { speak, stop, isSpeaking, isSupported } = useVoiceOutput();
 *
 * <button onClick={() => speak('Hello world')} disabled={!isSupported.supported}>
 *   Speak
 * </button>
 *
 * {isSpeaking && <button onClick={stop}>Stop</button>}
 * ```
 */
export function useVoiceOutput(): UseVoiceOutputReturn {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Check browser support
  const checkSupport = useCallback((): SpeechSynthesisSupport => {
    if (typeof window === 'undefined') {
      return { supported: false, reason: 'not-supported' };
    }

    if (!window.speechSynthesis) {
      return { supported: false, reason: 'not-supported' };
    }

    return { supported: true, reason: 'supported' };
  }, []);

  const [isSupported, setIsSupported] = useState<SpeechSynthesisSupport>({
    supported: false,
    reason: 'not-supported',
  });

  // Initialize support check on mount
  useEffect(() => {
    setIsSupported(checkSupport());
  }, [checkSupport]);

  // Load available voices
  useEffect(() => {
    if (!isSupported.supported || !window.speechSynthesis) return;

    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      setVoices(availableVoices);

      // Set default voice (prefer English)
      if (availableVoices.length > 0 && !selectedVoice) {
        const englishVoice = availableVoices.find(
          (v) => v.lang.startsWith('en') && v.default
        ) || availableVoices.find((v) => v.lang.startsWith('en')) ||
        availableVoices.find((v) => v.default) ||
        availableVoices[0];

        if (englishVoice) {
          setSelectedVoice(englishVoice.name);
        }
      }
    };

    // Load voices immediately if available
    loadVoices();

    // Chrome loads voices asynchronously
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, [isSupported.supported, selectedVoice]);

  // Track speaking state
  useEffect(() => {
    if (!isSupported.supported || !window.speechSynthesis) return;

    const checkSpeaking = () => {
      setIsSpeaking(window.speechSynthesis.speaking);
      setIsPaused(window.speechSynthesis.paused);
    };

    // Poll for speaking state (some browsers don't fire events reliably)
    const interval = setInterval(checkSpeaking, 100);

    return () => {
      clearInterval(interval);
    };
  }, [isSupported.supported]);

  const speak = useCallback((text: string) => {
    if (!isSupported.supported || !window.speechSynthesis) return;

    // Stop any current speech
    window.speechSynthesis.cancel();

    // Clean the text (remove markdown formatting, etc.)
    const cleanText = text
      .replace(/```[\s\S]*?```/g, '') // Remove code blocks
      .replace(/`[^`]+`/g, '') // Remove inline code
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // Replace links with just the text
      .replace(/[#*_~`]/g, '') // Remove markdown formatting
      .replace(/\n+/g, '. ') // Replace newlines with periods
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);

    // Set voice if selected
    if (selectedVoice) {
      const voice = voices.find((v) => v.name === selectedVoice);
      if (voice) {
        utterance.voice = voice;
      }
    }

    // Set speech parameters
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    utterance.onstart = () => {
      setIsSpeaking(true);
    };

    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [isSupported.supported, selectedVoice, voices]);

  const stop = useCallback(() => {
    if (!isSupported.supported || !window.speechSynthesis) return;

    window.speechSynthesis.cancel();
    setIsSpeaking(false);
    setIsPaused(false);
  }, [isSupported.supported]);

  const pause = useCallback(() => {
    if (!isSupported.supported || !window.speechSynthesis) return;

    window.speechSynthesis.pause();
    setIsPaused(true);
  }, [isSupported.supported]);

  const resume = useCallback(() => {
    if (!isSupported.supported || !window.speechSynthesis) return;

    window.speechSynthesis.resume();
    setIsPaused(false);
  }, [isSupported.supported]);

  const setVoice = useCallback((voiceName: string) => {
    setSelectedVoice(voiceName);
  }, []);

  return {
    isSupported,
    isSpeaking,
    isPaused,
    speak,
    stop,
    pause,
    resume,
    voices,
    setVoice,
    selectedVoice,
  };
}
