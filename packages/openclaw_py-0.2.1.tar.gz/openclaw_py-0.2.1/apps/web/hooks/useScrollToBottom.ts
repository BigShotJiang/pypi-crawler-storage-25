'use client';

import { useState, useEffect, useCallback, useRef } from 'react';

interface UseScrollToBottomOptions {
  /** Distance from bottom (in px) to consider "at bottom". Default: 100 */
  threshold?: number;
}

interface UseScrollToBottomReturn {
  /** Whether the scroll position is near the bottom */
  isAtBottom: boolean;
  /** Smoothly scroll to the bottom of the container */
  scrollToBottom: () => void;
  /** Ref to attach to the scrollable container */
  scrollRef: (el: HTMLDivElement | null) => void;
}

export function useScrollToBottom(
  deps: unknown[] = [],
  options: UseScrollToBottomOptions = {}
): UseScrollToBottomReturn {
  const { threshold = 100 } = options;
  const [isAtBottom, setIsAtBottom] = useState(true);
  const elementRef = useRef<HTMLDivElement | null>(null);

  const checkIfAtBottom = useCallback(() => {
    const el = elementRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setIsAtBottom(distanceFromBottom < threshold);
  }, [threshold]);

  const scrollToBottom = useCallback(() => {
    const el = elementRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, []);

  // Callback ref to capture the DOM element and attach scroll listener
  const scrollRef = useCallback(
    (el: HTMLDivElement | null) => {
      // Clean up previous element
      if (elementRef.current) {
        elementRef.current.removeEventListener('scroll', checkIfAtBottom);
      }

      elementRef.current = el;

      // Attach listener to new element
      if (el) {
        el.addEventListener('scroll', checkIfAtBottom, { passive: true });
        // Check initial position
        checkIfAtBottom();
      }
    },
    [checkIfAtBottom]
  );

  // Auto-scroll when new content arrives if user was at bottom
  useEffect(() => {
    if (isAtBottom) {
      scrollToBottom();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return { isAtBottom, scrollToBottom, scrollRef };
}
