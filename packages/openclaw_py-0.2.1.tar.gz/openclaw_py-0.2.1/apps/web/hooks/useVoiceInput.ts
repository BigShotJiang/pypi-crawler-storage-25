'use client';

import { useState, useEffect, useCallback, useRef } from 'react';

// Web Speech API type declarations
interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
}

interface SpeechRecognitionErrorEvent extends Event {
  readonly error: string;
  readonly message: string;
}

interface SpeechRecognitionInstance extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}

export type SpeechRecognitionSupport = {
  supported: boolean;
  reason: 'supported' | 'not-supported' | 'no-https';
};

interface UseVoiceInputReturn {
  isSupported: SpeechRecognitionSupport;
  isListening: boolean;
  transcript: string;
  error: string | null;
  startListening: () => void;
  stopListening: () => void;
  clearTranscript: () => void;
}

export function useVoiceInput(): UseVoiceInputReturn {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);

  const checkSupport = useCallback((): SpeechRecognitionSupport => {
    if (typeof window === 'undefined') {
      return { supported: false, reason: 'not-supported' };
    }

    const isLocalhost = window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1';
    const isHttps = window.location.protocol === 'https:';

    if (!isLocalhost && !isHttps) {
      return { supported: false, reason: 'no-https' };
    }

    const SR = (window as unknown as Record<string, unknown>).SpeechRecognition ||
      (window as unknown as Record<string, unknown>).webkitSpeechRecognition;
    if (!SR) {
      return { supported: false, reason: 'not-supported' };
    }

    return { supported: true, reason: 'supported' };
  }, []);

  const [isSupported, setIsSupported] = useState<SpeechRecognitionSupport>({
    supported: false,
    reason: 'not-supported',
  });

  useEffect(() => {
    setIsSupported(checkSupport());
  }, [checkSupport]);

  useEffect(() => {
    if (!isSupported.supported) return;

    const win = window as unknown as Record<string, unknown>;
    const SR = (win.SpeechRecognition || win.webkitSpeechRecognition) as new () => SpeechRecognitionInstance;
    const recognition = new SR();

    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          finalTranscript += result[0].transcript;
        } else {
          interimTranscript += result[0].transcript;
        }
      }

      setTranscript(finalTranscript || interimTranscript);
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      const messages: Record<string, string> = {
        'no-speech': 'No speech detected. Please try again.',
        'audio-capture': 'No microphone found or access denied.',
        'not-allowed': 'Microphone access denied.',
        'network': 'Network error during speech recognition.',
        'aborted': 'Speech recognition was aborted.',
      };
      setError(messages[event.error] || `Speech recognition error: ${event.error}`);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      recognition.abort();
      recognitionRef.current = null;
    };
  }, [isSupported.supported]);

  const startListening = useCallback(() => {
    if (!isSupported.supported || !recognitionRef.current || isListening) return;

    setError(null);
    setTranscript('');

    try {
      recognitionRef.current.start();
      setIsListening(true);
    } catch (err) {
      if (err instanceof Error && err.message.includes('already started')) {
        return;
      }
      setError('Failed to start speech recognition');
      setIsListening(false);
    }
  }, [isSupported.supported, isListening]);

  const stopListening = useCallback(() => {
    if (!recognitionRef.current || !isListening) return;

    try {
      recognitionRef.current.stop();
    } catch {
      // Ignore errors when stopping
    }
    setIsListening(false);
  }, [isListening]);

  const clearTranscript = useCallback(() => {
    setTranscript('');
    setError(null);
  }, []);

  return {
    isSupported,
    isListening,
    transcript,
    error,
    startListening,
    stopListening,
    clearTranscript,
  };
}
