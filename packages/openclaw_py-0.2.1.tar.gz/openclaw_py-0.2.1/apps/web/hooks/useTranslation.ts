"use client";

import { useTranslations } from "next-intl";

/**
 * Custom hook for translations.
 * Wraps next-intl's useTranslations with a simpler API.
 *
 * @param namespace - Optional namespace (e.g., "nav", "common"). Defaults to empty string for root.
 * @returns A translation function `t(key, params?)` that resolves keys within the namespace.
 *
 * @example
 * // In a component
 * const { t } = useTranslation("nav");
 * <span>{t("dashboard")}</span>  // Resolves to "nav.dashboard"
 */
export function useTranslation(namespace?: string) {
  const t = useTranslations(namespace);

  return {
    t,
  };
}
