import { use } from 'react';
import { AgentDetail } from './agent-detail-client';

// For static export, we need to provide all possible paths
// Since agent IDs are dynamic, we provide a placeholder that will be handled client-side
// The "new" path is always valid (creates new agent)
// Other agent pages will be handled by client-side routing fallback
export function generateStaticParams() {
  // Include common agent IDs that might be accessed
  // In a real app, you'd fetch these from your backend at build time
  return [
    { id: 'new' },
    { id: 'default' },
  ];
}

export default function AgentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return <AgentDetail id={id} />;
}
