'use client';

import { PageHeader, Card, CardHeader, CardTitle, CardContent, StatusChip } from '@pyclaw/ui';
import { useAgentDetail } from '@pyclaw/shared';
import { Loader2 } from 'lucide-react';

export function AgentDetail({ id }: { id: string }) {
  const { data: agent, isLoading, error } = useAgentDetail(id);

  return (
    <div className="flex h-full flex-col">
      <PageHeader title={agent?.id || id} description="Agent details" />
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <Card>
            <CardContent className="py-8">
              <div className="text-center text-muted-foreground">Error: {error.message}</div>
            </CardContent>
          </Card>
        ) : agent ? (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">ID</div>
                    <div className="font-medium">{agent.id}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Sessions</div>
                    <StatusChip status="success">{agent.session_count ?? 0}</StatusChip>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="overflow-auto rounded-lg bg-muted p-4 text-xs">
                  {JSON.stringify(agent.config, null, 2)}
                </pre>
              </CardContent>
            </Card>
          </div>
        ) : (
          <Card>
            <CardContent className="py-8">
              <div className="text-center text-muted-foreground">Agent not found</div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
