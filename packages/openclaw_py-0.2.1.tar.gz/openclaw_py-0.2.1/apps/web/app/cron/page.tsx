'use client';

import { useState } from 'react';
import { PageHeader, EmptyState, Button, Card } from '@pyclaw/ui';
import {
  useCronList,
  useCreateCronJob,
  useToggleCronJob,
  useDeleteCronJob,
  type CronJob,
} from '@pyclaw/shared';
import {
  Clock,
  Plus,
  Play,
  Pause,
  Trash2,
  Loader2,
  X,
} from 'lucide-react';

function StatusBadge({ enabled }: { enabled: boolean }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
        enabled
          ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
          : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
      }`}
    >
      {enabled ? (
        <>
          <Play className="h-3 w-3" />
          Active
        </>
      ) : (
        <>
          <Pause className="h-3 w-3" />
          Paused
        </>
      )}
    </span>
  );
}

function ScheduleTypeBadge({ type }: { type: CronJob['schedule_type'] }) {
  const colors = {
    cron: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
    interval: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
    once: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
  };
  return (
    <span
      className={`rounded px-1.5 py-0.5 text-xs font-medium ${colors[type]}`}
    >
      {type}
    </span>
  );
}

interface CreateJobDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (job: {
    name: string;
    schedule: string;
    message: string;
    agent_id?: string;
  }) => void;
  isPending: boolean;
}

function CreateJobDialog({ open, onClose, onSubmit, isPending }: CreateJobDialogProps) {
  const [name, setName] = useState('');
  const [schedule, setSchedule] = useState('');
  const [message, setMessage] = useState('');
  const [agentId, setAgentId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, schedule, message, agent_id: agentId || undefined });
    setName('');
    setSchedule('');
    setMessage('');
    setAgentId('');
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="fixed inset-0 bg-black/50"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="relative z-50 w-full max-w-md rounded-lg border bg-card p-6 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Create Cron Job</h2>
          <button
            onClick={onClose}
            className="rounded p-1 hover:bg-accent"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              placeholder="My scheduled task"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Schedule</label>
            <input
              type="text"
              value={schedule}
              onChange={(e) => setSchedule(e.target.value)}
              className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              placeholder="0 * * * *"
              required
            />
            <p className="mt-1 text-xs text-muted-foreground">
              Cron expression (e.g., &quot;0 * * * *&quot; for hourly)
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Message</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="flex min-h-[80px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              placeholder="Task message to send"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Agent ID (optional)</label>
            <input
              type="text"
              value={agentId}
              onChange={(e) => setAgentId(e.target.value)}
              className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              placeholder="main"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? (
                <Loader2 className="mr-1 h-4 w-4 animate-spin" />
              ) : (
                <Plus className="mr-1 h-4 w-4" />
              )}
              Create
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function CronPage() {
  const { data: jobs, isLoading, error } = useCronList();
  const createJob = useCreateCronJob();
  const toggleJob = useToggleCronJob();
  const deleteJob = useDeleteCronJob();
  const [dialogOpen, setDialogOpen] = useState(false);

  const handleCreate = (job: {
    name: string;
    schedule: string;
    message: string;
    agent_id?: string;
  }) => {
    createJob.mutate({
      name: job.name || undefined,
      schedule: job.schedule,
      message: job.message,
      agent_id: job.agent_id,
    });
  };

  const handleToggle = (id: string, enabled: boolean) => {
    toggleJob.mutate({ id, enabled: !enabled });
  };

  const handleDelete = (id: string) => {
    deleteJob.mutate(id);
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Cron Jobs"
        description="Manage scheduled tasks"
        icon={<Clock className="h-5 w-5" />}
        actions={
          <Button size="sm" onClick={() => setDialogOpen(true)}>
            <Plus className="mr-1 h-4 w-4" />
            New Job
          </Button>
        }
      />
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            title="Error loading cron jobs"
            description={error.message}
            icon={<Clock className="h-12 w-12" />}
          />
        ) : jobs && jobs.length > 0 ? (
          <div className="space-y-3">
            {jobs.map((job) => (
              <Card key={job.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium truncate">
                        {job.name || job.id}
                      </span>
                      <StatusBadge enabled={job.enabled} />
                      <ScheduleTypeBadge type={job.schedule_type} />
                    </div>
                    <div className="mt-1 text-sm text-muted-foreground">
                      <code className="rounded bg-muted px-1.5 py-0.5 font-mono">
                        {job.schedule}
                      </code>
                    </div>
                    <p className="mt-2 text-sm line-clamp-2">{job.message}</p>
                    {job.agent_id && (
                      <p className="mt-1 text-xs text-muted-foreground">
                        Agent: {job.agent_id}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    <button
                      onClick={() => handleToggle(job.id, job.enabled)}
                      disabled={toggleJob.isPending}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 ${
                        job.enabled ? 'bg-primary' : 'bg-input'
                      }`}
                      aria-label={job.enabled ? 'Disable job' : 'Enable job'}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-background shadow transition-transform ${
                          job.enabled ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleDelete(job.id)}
                      disabled={deleteJob.isPending}
                      className="text-destructive hover:text-destructive"
                      aria-label="Delete job"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <EmptyState
            title="No cron jobs"
            description="Create a scheduled task to automate your workflow"
            icon={<Clock className="h-12 w-12" />}
            action={
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="mr-1 h-4 w-4" />
                Create Job
              </Button>
            }
          />
        )}
      </div>
      <CreateJobDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onSubmit={handleCreate}
        isPending={createJob.isPending}
      />
    </div>
  );
}
