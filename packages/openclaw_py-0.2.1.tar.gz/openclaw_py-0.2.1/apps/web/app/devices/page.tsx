'use client';

import { useState, useEffect } from 'react';
import { Smartphone, RefreshCw, AlertTriangle } from 'lucide-react';
import { PageHeader, EmptyState, DeviceCard } from '@pyclaw/ui';
import { devicesApi } from '@pyclaw/shared';
import type { Device } from '@pyclaw/shared/types';

export default function DevicesPage() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [pendingCount, setPendingCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadDevices();
  }, []);

  async function loadDevices() {
    setLoading(true);
    setError(null);
    const result = await devicesApi.list();
    if (result.data) {
      setDevices(result.data.devices);
      setPendingCount(result.data.pending_count);
    } else {
      setError(result.error?.message || 'Failed to load devices');
    }
    setLoading(false);
  }

  async function handleApprove(device: Device) {
    const result = await devicesApi.approve(device.id);
    if (result.error) {
      alert(result.error.message);
    } else {
      loadDevices();
    }
  }

  async function handleRemove(device: Device) {
    if (!confirm(`Remove device "${device.name || device.id}"?`)) return;
    const result = await devicesApi.remove(device.id);
    if (result.error) {
      alert(result.error.message);
    } else {
      loadDevices();
    }
  }

  const pendingDevices = devices.filter((d) => d.status === 'pending');
  const approvedDevices = devices.filter((d) => d.status === 'approved');
  const otherDevices = devices.filter((d) => d.status !== 'pending' && d.status !== 'approved');

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Devices"
        description="Manage paired devices"
        icon={<Smartphone />}
        actions={
          <button
            onClick={loadDevices}
            disabled={loading}
            className="flex items-center gap-1 rounded border px-3 py-1 text-sm hover:bg-muted disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        }
      />

      {pendingCount > 0 && (
        <div className="border-b bg-yellow-50 p-3 dark:bg-yellow-950">
          <div className="flex items-center gap-2 text-yellow-800 dark:text-yellow-200">
            <AlertTriangle className="h-4 w-4" />
            <span className="text-sm font-medium">
              {pendingCount} device{pendingCount > 1 ? 's' : ''} awaiting approval
            </span>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-auto p-4">
        {loading ? (
          <div className="flex h-32 items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            icon={<Smartphone />}
            title="Failed to load devices"
            description={error}
          />
        ) : devices.length === 0 ? (
          <EmptyState
            icon={<Smartphone />}
            title="No devices paired"
            description="Pair devices to access your gateway from multiple platforms"
          />
        ) : (
          <div className="space-y-6">
            {pendingDevices.length > 0 && (
              <section>
                <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold">
                  <span className="rounded-full bg-yellow-500 px-2 py-0.5 text-xs text-white">
                    {pendingDevices.length}
                  </span>
                  Pending Approval
                </h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {pendingDevices.map((device) => (
                    <DeviceCard
                      key={device.id}
                      device={device}
                      onApprove={() => handleApprove(device)}
                      onRemove={() => handleRemove(device)}
                    />
                  ))}
                </div>
              </section>
            )}

            {approvedDevices.length > 0 && (
              <section>
                <h2 className="mb-3 text-lg font-semibold">Approved Devices</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {approvedDevices.map((device) => (
                    <DeviceCard
                      key={device.id}
                      device={device}
                      onRemove={() => handleRemove(device)}
                    />
                  ))}
                </div>
              </section>
            )}

            {otherDevices.length > 0 && (
              <section>
                <h2 className="mb-3 text-lg font-semibold text-muted-foreground">Other</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {otherDevices.map((device) => (
                    <DeviceCard key={device.id} device={device} />
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
