'use client';

import { PageHeader, EmptyState, Button, StatusChip } from '@pyclaw/ui';
import {
  usePlansList,
  useResumePlan,
  useDeletePlan,
  type Plan,
  type PlanStep,
} from '@pyclaw/shared';
import {
  List,
  Play,
  Trash2,
  CheckCircle,
  PauseCircle,
  XCircle,
  Loader2,
} from 'lucide-react';

type PlanStatus = Plan['status'];

function getStatusVariant(status: PlanStatus): 'info' | 'warning' | 'success' | 'error' {
  switch (status) {
    case 'running':
      return 'info';
    case 'paused':
      return 'warning';
    case 'completed':
      return 'success';
    case 'failed':
      return 'error';
    default:
      return 'info';
  }
}

function getStatusIcon(status: PlanStatus) {
  switch (status) {
    case 'running':
      return <Loader2 className="h-3.5 w-3.5 animate-spin" />;
    case 'paused':
      return <PauseCircle className="h-3.5 w-3.5" />;
    case 'completed':
      return <CheckCircle className="h-3.5 w-3.5" />;
    case 'failed':
      return <XCircle className="h-3.5 w-3.5" />;
    default:
      return null;
  }
}

function getStepProgress(steps: PlanStep[]): string {
  if (!steps || steps.length === 0) return '0/0';
  const completed = steps.filter(
    (s) => s.status === 'completed' || s.status === 'failed'
  ).length;
  return `${completed}/${steps.length}`;
}

export default function PlansPage() {
  const { data: plans, isLoading, error } = usePlansList();
  const resumePlan = useResumePlan();
  const deletePlan = useDeletePlan();

  const handleResume = (id: string) => {
    resumePlan.mutate(id);
  };

  const handleDelete = (id: string) => {
    deletePlan.mutate(id);
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Plans"
        description="Track and manage execution plans"
        icon={<List className="h-5 w-5" />}
      />
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            title="Error loading plans"
            description={error.message}
            icon={<List className="h-12 w-12" />}
          />
        ) : plans && plans.length > 0 ? (
          <div className="space-y-2">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className="flex items-center justify-between rounded-lg border bg-card p-4"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium truncate">{plan.name}</span>
                    <StatusChip status={getStatusVariant(plan.status)}>
                      <span className="flex items-center gap-1">
                        {getStatusIcon(plan.status)}
                        {plan.status}
                      </span>
                    </StatusChip>
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    <span className="mr-3">ID: {plan.id}</span>
                    <span>Steps: {getStepProgress(plan.steps)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 ml-4">
                  {plan.status === 'paused' && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleResume(plan.id)}
                      disabled={resumePlan.isPending}
                    >
                      <Play className="mr-1 h-4 w-4" />
                      Resume
                    </Button>
                  )}
                  {(plan.status === 'completed' || plan.status === 'failed') && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(plan.id)}
                      disabled={deletePlan.isPending}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="mr-1 h-4 w-4" />
                      Delete
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title="No plans"
            description="Execution plans will appear here when created"
            icon={<List className="h-12 w-12" />}
          />
        )}
      </div>
    </div>
  );
}
