'use client';

import { useState, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  Button,
  Input,
  Label,
  Switch,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@pyclaw/ui';
import {
  Check,
  X,
  Loader2,
  ExternalLink,
  Info,
  AlertTriangle,
} from 'lucide-react';
import { configApi } from '@pyclaw/shared/api';
import type { ChannelResponse } from '@pyclaw/shared/types';

interface ChannelConfigSheetProps {
  channel: ChannelResponse | null;
  open: boolean;
  onClose: () => void;
  onUpdated: () => void;
}

// 通道配置字段定义
const CHANNEL_CONFIG_FIELDS: Record<string, ConfigField[]> = {
  telegram: [
    { key: 'botToken', label: 'Bot Token', type: 'password', required: true,
      description: '从 @BotFather 获取' },
    { key: 'dmPolicy', label: 'DM 策略', type: 'select', options: [
      { value: 'pairing', label: '配对模式' },
      { value: 'allowlist', label: '白名单' },
      { value: 'open', label: '公开' },
      { value: 'disabled', label: '禁用' },
    ]},
    { key: 'groupPolicy', label: '群组策略', type: 'select', options: [
      { value: 'allowlist', label: '白名单' },
      { value: 'open', label: '公开' },
      { value: 'disabled', label: '禁用' },
    ]},
    { key: 'requireMention', label: '群组需 @提及', type: 'boolean' },
  ],
  discord: [
    { key: 'token', label: 'Bot Token', type: 'password', required: true,
      description: '从 Discord Developer Portal 获取' },
    { key: 'applicationId', label: 'Application ID', type: 'text',
      description: '可选，用于跳过启动时 REST 查询' },
    { key: 'dmPolicy', label: 'DM 策略', type: 'select', options: [
      { value: 'pairing', label: '配对模式' },
      { value: 'allowlist', label: '白名单' },
      { value: 'open', label: '公开' },
      { value: 'disabled', label: '禁用' },
    ]},
  ],
  slack: [
    { key: 'appToken', label: 'App Token', type: 'password', required: true,
      description: 'App-Level Token (xapp-...)' },
    { key: 'botToken', label: 'Bot Token', type: 'password', required: true,
      description: 'Bot Token (xoxb-...)' },
    { key: 'mode', label: '连接模式', type: 'select', options: [
      { value: 'socket', label: 'Socket Mode（推荐）' },
      { value: 'http', label: 'HTTP Webhook' },
    ]},
  ],
  feishu: [
    { key: 'appId', label: 'App ID', type: 'text', required: true,
      description: '格式：cli_xxx' },
    { key: 'appSecret', label: 'App Secret', type: 'password', required: true },
    { key: 'domain', label: '域名', type: 'select', options: [
      { value: 'feishu', label: '飞书（国内）' },
      { value: 'lark', label: 'Lark（国际）' },
    ]},
    { key: 'connectionMode', label: '连接模式', type: 'select', options: [
      { value: 'websocket', label: 'WebSocket（推荐）' },
      { value: 'webhook', label: 'Webhook' },
    ]},
    { key: 'dmPolicy', label: 'DM 策略', type: 'select', options: [
      { value: 'allowlist', label: '白名单' },
      { value: 'pairing', label: '配对模式' },
      { value: 'open', label: '公开' },
      { value: 'disabled', label: '禁用' },
    ]},
    { key: 'groupPolicy', label: '群组策略', type: 'select', options: [
      { value: 'allowlist', label: '白名单' },
      { value: 'open', label: '公开' },
      { value: 'disabled', label: '禁用' },
    ]},
    { key: 'requireMention', label: '群组需 @提及', type: 'boolean' },
    { key: 'streaming', label: '流式回复', type: 'boolean' },
  ],
  dingtalk: [
    { key: 'appKey', label: 'App Key', type: 'text', required: true },
    { key: 'appSecret', label: 'App Secret', type: 'password', required: true },
  ],
  msteams: [
    { key: 'appId', label: 'App ID', type: 'text', required: true },
    { key: 'appPassword', label: 'App Password', type: 'password', required: true },
    { key: 'tenantId', label: 'Tenant ID', type: 'text', required: true },
  ],
};

// 通道文档链接
const CHANNEL_DOCS: Record<string, string> = {
  telegram: 'https://core.telegram.org/bots/api',
  discord: 'https://discord.com/developers/docs',
  slack: 'https://api.slack.com/',
  feishu: 'https://open.feishu.cn/document',
  dingtalk: 'https://open.dingtalk.com/document/',
};

interface ConfigField {
  key: string;
  label: string;
  type: 'text' | 'password' | 'select' | 'boolean';
  required?: boolean;
  description?: string;
  options?: { value: string; label: string }[];
}

export function ChannelConfigSheet({
  channel,
  open,
  onClose,
  onUpdated,
}: ChannelConfigSheetProps) {
  const queryClient = useQueryClient();
  const [config, setConfig] = useState<Record<string, unknown>>({});
  const [enabled, setEnabled] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const fields = channel ? CHANNEL_CONFIG_FIELDS[channel.id] || [] : [];
  const docUrl = channel ? CHANNEL_DOCS[channel.id] : null;

  // 加载当前配置
  useEffect(() => {
    if (channel && open) {
      // 从 configApi 获取当前配置
      configApi.get().then((result) => {
        if (result.data?.config?.channels) {
          const channelConfig = result.data.config.channels[channel.id] || {};
          setConfig(channelConfig as Record<string, unknown>);
          setEnabled((channelConfig as Record<string, unknown>).enabled !== false);
        }
      });
      setSaveError(null);
      setSaveSuccess(false);
    }
  }, [channel, open]);

  const handleSave = async () => {
    if (!channel) return;

    setIsSaving(true);
    setSaveError(null);
    setSaveSuccess(false);

    try {
      // 构建配置补丁
      const patch = {
        channels: {
          [channel.id]: {
            ...config,
            enabled,
          },
        },
      };

      const result = await configApi.patch(patch);

      if (result.error) {
        setSaveError(result.error.message);
      } else {
        setSaveSuccess(true);
        onUpdated();
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : '保存失败');
    } finally {
      setIsSaving(false);
    }
  };

  const updateConfig = (key: string, value: unknown) => {
    setConfig((prev) => ({ ...prev, [key]: value }));
    setSaveSuccess(false);
  };

  if (!channel) return null;

  return (
    <Sheet open={open} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader>
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center text-xl"
              style={{ backgroundColor: channel.color || '#6366f1' + '20' }}
            >
              {channel.icon || '📡'}
            </div>
            <div>
              <SheetTitle>{channel.display_name || channel.name}</SheetTitle>
              <SheetDescription>
                {channel.category} · {channel.supports_dm ? '支持 DM' : ''} {channel.supports_groups ? '支持群组' : ''}
              </SheetDescription>
            </div>
          </div>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* 启用开关 */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <Label className="text-base font-medium">启用通道</Label>
              <p className="text-sm text-gray-500 mt-1">
                启用后 Gateway 将连接此通道
              </p>
            </div>
            <Switch checked={enabled} onCheckedChange={setEnabled} />
          </div>

          {/* 配置字段 */}
          {fields.length > 0 ? (
            <Tabs defaultValue="basic">
              <TabsList className="w-full">
                <TabsTrigger value="basic" className="flex-1">基本配置</TabsTrigger>
                <TabsTrigger value="advanced" className="flex-1">高级选项</TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4 mt-4">
                {fields.filter(f => f.required || ['enabled', 'dmPolicy', 'groupPolicy'].includes(f.key)).map((field) => (
                  <ConfigFieldInput
                    key={field.key}
                    field={field}
                    value={config[field.key]}
                    onChange={(v) => updateConfig(field.key, v)}
                  />
                ))}
              </TabsContent>

              <TabsContent value="advanced" className="space-y-4 mt-4">
                {fields.filter(f => !f.required && !['enabled', 'dmPolicy', 'groupPolicy'].includes(f.key)).map((field) => (
                  <ConfigFieldInput
                    key={field.key}
                    field={field}
                    value={config[field.key]}
                    onChange={(v) => updateConfig(field.key, v)}
                  />
                ))}
              </TabsContent>
            </Tabs>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <Info className="h-8 w-8 mx-auto mb-2" />
              <p>此通道需要在配置文件中手动配置</p>
              <p className="text-sm mt-1">请参考 pyclaw.example.json5</p>
            </div>
          )}

          {/* 能力信息 */}
          {channel.capabilities && (
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-sm mb-2">支持的功能</h4>
              <div className="flex flex-wrap gap-2">
                {Object.entries(channel.capabilities).map(([key, value]) => (
                  value && (
                    <span key={key} className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded">
                      {key}
                    </span>
                  )
                ))}
              </div>
            </div>
          )}

          {/* 错误提示 */}
          {saveError && (
            <div className="flex items-center gap-2 p-3 bg-red-50 text-red-700 rounded-lg">
              <AlertTriangle className="h-4 w-4" />
              <span className="text-sm">{saveError}</span>
            </div>
          )}

          {/* 成功提示 */}
          {saveSuccess && (
            <div className="flex items-center gap-2 p-3 bg-green-50 text-green-700 rounded-lg">
              <Check className="h-4 w-4" />
              <span className="text-sm">配置已保存</span>
            </div>
          )}

          {/* 操作按钮 */}
          <div className="flex gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} className="flex-1">
              取消
            </Button>
            <Button onClick={handleSave} disabled={isSaving} className="flex-1">
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  保存中...
                </>
              ) : (
                '保存配置'
              )}
            </Button>
          </div>

          {/* 文档链接 */}
          {docUrl && (
            <a
              href={docUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-blue-600 hover:underline mt-4"
            >
              <ExternalLink className="h-4 w-4" />
              查看官方文档
            </a>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

// 配置字段输入组件
function ConfigFieldInput({
  field,
  value,
  onChange,
}: {
  field: ConfigField;
  value: unknown;
  onChange: (value: unknown) => void;
}) {
  if (field.type === 'boolean') {
    return (
      <div className="flex items-center justify-between">
        <div>
          <Label>{field.label}</Label>
          {field.description && (
            <p className="text-xs text-gray-500 mt-0.5">{field.description}</p>
          )}
        </div>
        <Switch
          checked={value === true}
          onCheckedChange={onChange}
        />
      </div>
    );
  }

  if (field.type === 'select') {
    return (
      <div className="space-y-2">
        <Label>{field.label}</Label>
        <Select
          value={value as string || field.options?.[0]?.value}
          onValueChange={onChange}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {field.options?.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <Label>
        {field.label}
        {field.required && <span className="text-red-500 ml-1">*</span>}
      </Label>
      <Input
        type={field.type === 'password' ? 'password' : 'text'}
        value={(value as string) || ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder={field.description}
      />
      {field.description && field.type !== 'password' && (
        <p className="text-xs text-gray-500">{field.description}</p>
      )}
    </div>
  );
}
