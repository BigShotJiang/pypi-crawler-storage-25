import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { NextIntlClientProvider } from 'next-intl';
import './globals.css';
import { Providers } from '../providers';
import { Shell } from '../components/shell';

// Static messages for Tauri builds (no server-side API needed)
import enMessages from '../messages/en.json';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'PyClaw',
  description: 'Multi-channel AI Gateway',
  manifest: '/manifest.json',
  icons: {
    icon: '/favicon.svg',
    shortcut: '/favicon.ico',
    apple: '/icons/icon-192x192.png',
  },
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // For static export (Tauri), use static locale and messages
  // This avoids the need for next-intl/server which requires Node.js runtime
  const locale = 'en';
  const messages = enMessages;

  return (
    <html lang={locale} suppressHydrationWarning>
      <body className={inter.className} suppressHydrationWarning>
        <NextIntlClientProvider messages={messages}>
          <Providers>
            <Shell>{children}</Shell>
          </Providers>
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
