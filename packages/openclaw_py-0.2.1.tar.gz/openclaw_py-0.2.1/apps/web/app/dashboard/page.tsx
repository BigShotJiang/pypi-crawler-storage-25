'use client';

import { PageHeader, StatusChip } from '@pyclaw/ui';
import { useGatewayWebSocket, useAgentsList, useSessionsList } from '@pyclaw/shared';

export default function DashboardPage() {
  const { connected, connectionState } = useGatewayWebSocket();
  const { data: agents } = useAgentsList();
  const { data: sessions } = useSessionsList();

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Dashboard"
        description="PyClaw Gateway Status"
        actions={
          <StatusChip status={connected ? 'success' : 'error'}>
            {connected ? 'Connected' : 'Disconnected'}
          </StatusChip>
        }
      />
      <div className="flex-1 p-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">Connection</div>
            <div className="text-2xl font-bold capitalize">{connectionState}</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">Active Agents</div>
            <div className="text-2xl font-bold">{agents?.length ?? '-'}</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">Sessions</div>
            <div className="text-2xl font-bold">{sessions?.length ?? '-'}</div>
          </div>
          <div className="rounded-lg border bg-card p-4">
            <div className="text-sm text-muted-foreground">Messages Today</div>
            <div className="text-2xl font-bold">-</div>
          </div>
        </div>
      </div>
    </div>
  );
}
