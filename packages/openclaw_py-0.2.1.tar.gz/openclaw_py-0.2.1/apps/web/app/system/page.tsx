'use client';

import { useState } from 'react';
import {
  PageHeader,
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  Button,
  StatusChip,
} from '@pyclaw/ui';
import {
  useBackupStatus,
  useExportBackup,
  useConfig,
  useGatewayWebSocket,
  useAppStore,
} from '@pyclaw/shared';
import { Info, Download, AlertTriangle, Archive } from 'lucide-react';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  const value = bytes / Math.pow(1024, i);
  return `${value.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function formatFileSize(size: number): string {
  return formatBytes(size);
}

function formatDate(path: string): string {
  // Backup filenames typically embed a timestamp, e.g. pyclaw-backup-20260423-153000.zip
  const match = path.match(/(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})/);
  if (match) {
    const [, y, m, d, hh, mm, ss] = match;
    return `${y}-${m}-${d} ${hh}:${mm}:${ss}`;
  }
  // Fallback: try to extract any plausible date-like segment
  const dateMatch = path.match(/(\d{4}-\d{2}-\d{2})/);
  return dateMatch ? dateMatch[1] : '-';
}

function filenameFromPath(path: string): string {
  const segments = path.split('/');
  return segments[segments.length - 1] || path;
}

// ---------------------------------------------------------------------------
// System Info Card
// ---------------------------------------------------------------------------

function SystemInfoCard() {
  const { connected, connectionState, connect } = useGatewayWebSocket();
  const { data: config } = useConfig();
  const gatewayConnected = useAppStore((s) => s.gatewayConnected);

  // Derive version from config if available, otherwise fallback
  const version =
    (config as Record<string, unknown> & { version?: string })?.version ??
    '0.1.0';

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Info className="h-5 w-5 text-primary" />
          <CardTitle>System Information</CardTitle>
        </div>
        <CardDescription>PyClaw Gateway runtime details</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <div className="text-sm text-muted-foreground">PyClaw Version</div>
              <div className="font-mono text-sm font-medium">{version}</div>
            </div>
            <span className="rounded-md bg-muted px-2 py-1 text-xs text-muted-foreground">
              Web Client
            </span>
          </div>

          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <div className="text-sm text-muted-foreground">Gateway Status</div>
              <div className="text-sm font-medium capitalize">{connectionState}</div>
            </div>
            <StatusChip
              status={connected || gatewayConnected ? 'success' : 'error'}
            >
              {connected || gatewayConnected ? 'Connected' : 'Disconnected'}
            </StatusChip>
          </div>

          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <div className="text-sm text-muted-foreground">Uptime</div>
              <div className="font-mono text-sm font-medium">
                {connected ? 'Available' : 'N/A'}
              </div>
            </div>
            <span className="text-xs text-muted-foreground">
              Reported by gateway
            </span>
          </div>
        </div>
      </CardContent>
      {!connected && (
        <CardFooter>
          <Button variant="outline" size="sm" onClick={() => connect()}>
            Reconnect
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Backup Management Card
// ---------------------------------------------------------------------------

function BackupCard() {
  const { data: backupStatus, isLoading } = useBackupStatus();
  const exportBackup = useExportBackup();
  const [exporting, setExporting] = useState(false);

  const backups = backupStatus?.backups ?? [];

  async function handleExport() {
    setExporting(true);
    try {
      await exportBackup.mutateAsync();
    } catch {
      // Error is handled by react-query / toast integration
    } finally {
      setExporting(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Archive className="h-5 w-5 text-primary" />
          <CardTitle>Backup Management</CardTitle>
        </div>
        <CardDescription>Export and download configuration backups</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-sm text-muted-foreground">Loading backups...</div>
        ) : backups.length === 0 ? (
          <div className="rounded-lg border border-dashed p-6 text-center">
            <p className="text-sm text-muted-foreground">No backups found</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Create a backup to save the current configuration
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {backups.map((backup, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between rounded-lg border p-3"
              >
                <div className="min-w-0 flex-1">
                  <div className="truncate font-mono text-sm font-medium">
                    {filenameFromPath(backup.path)}
                  </div>
                  <div className="mt-0.5 flex gap-3 text-xs text-muted-foreground">
                    <span>{formatFileSize(backup.size)}</span>
                    <span>{formatDate(backup.path)}</span>
                  </div>
                </div>
                <a
                  href={`/api/v1/backup/download/${encodeURIComponent(filenameFromPath(backup.path))}`}
                  className="ml-3 inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-primary hover:bg-accent"
                >
                  <Download className="h-3.5 w-3.5" />
                  Download
                </a>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={handleExport} disabled={exporting} size="sm">
          {exporting ? 'Creating...' : 'Create Backup'}
        </Button>
        {backupStatus && (
          <span className="ml-3 text-xs text-muted-foreground">
            {backupStatus.count} backup{backupStatus.count !== 1 ? 's' : ''}
          </span>
        )}
      </CardFooter>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Danger Zone Card
// ---------------------------------------------------------------------------

function DangerZoneCard() {
  const [confirmOpen, setConfirmOpen] = useState(false);

  return (
    <Card className="border-destructive/50">
      <CardHeader>
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-destructive" />
          <CardTitle className="text-destructive">Danger Zone</CardTitle>
        </div>
        <CardDescription>
          Irreversible actions — proceed with caution
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between rounded-lg border border-destructive/30 bg-destructive/5 p-4">
          <div>
            <div className="text-sm font-medium">Clear All Data</div>
            <div className="mt-0.5 text-xs text-muted-foreground">
              Remove all sessions, configurations, and stored data
            </div>
          </div>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => setConfirmOpen(true)}
          >
            Clear All Data
          </Button>
        </div>
      </CardContent>

      {/* Confirmation dialog */}
      {confirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="mx-4 w-full max-w-md rounded-xl border bg-background p-6 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-destructive/10 p-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <h3 className="font-semibold">Confirm Data Deletion</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  This will permanently delete all data. This action cannot be
                  undone.
                </p>
              </div>
            </div>
            <div className="mt-2 rounded-lg border border-dashed p-3 text-center text-sm text-muted-foreground">
              Work in Progress — this action is not yet implemented
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setConfirmOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                size="sm"
                disabled
                onClick={() => setConfirmOpen(false)}
              >
                Confirm (WIP)
              </Button>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function SystemPage() {
  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="System"
        description="Gateway information, backups, and maintenance"
        icon={<Info className="h-5 w-5" />}
      />
      <div className="flex-1 overflow-auto p-4">
        <div className="mx-auto max-w-3xl space-y-6">
          <SystemInfoCard />
          <BackupCard />
          <DangerZoneCard />
        </div>
      </div>
    </div>
  );
}
