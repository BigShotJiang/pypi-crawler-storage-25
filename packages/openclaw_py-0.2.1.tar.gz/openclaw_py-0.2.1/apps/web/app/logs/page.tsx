'use client';

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { PageHeader, Button, EmptyState } from '@pyclaw/ui';
import { useLogsTail } from '@pyclaw/shared';
import { FileText, Search, RefreshCw, Loader2, Pause, Play } from 'lucide-react';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type LogLevel = 'ERROR' | 'WARN' | 'INFO' | 'DEBUG' | 'ALL';

interface ParsedLogLine {
  raw: string;
  level: LogLevel;
  timestamp?: string;
  message: string;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function parseLogLevel(line: string): LogLevel {
  const upperLine = line.toUpperCase();
  if (upperLine.includes('ERROR') || upperLine.includes('CRITICAL') || upperLine.includes('FATAL')) {
    return 'ERROR';
  }
  if (upperLine.includes('WARN') || upperLine.includes('WARNING')) {
    return 'WARN';
  }
  if (upperLine.includes('DEBUG') || upperLine.includes('TRACE')) {
    return 'DEBUG';
  }
  return 'INFO';
}

function parseLogLine(line: string): ParsedLogLine {
  const level = parseLogLevel(line);

  // Try to extract timestamp (common formats: ISO, HH:MM:SS, etc.)
  const timestampMatch = line.match(/^(\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?|\d{2}:\d{2}:\d{2})/);
  const timestamp = timestampMatch?.[1];

  // Message is everything after timestamp if found
  const message = timestamp ? line.slice(timestamp.length).trim() : line;

  return { raw: line, level, timestamp, message };
}

function getLevelColor(level: LogLevel): string {
  switch (level) {
    case 'ERROR':
      return 'text-red-500';
    case 'WARN':
      return 'text-yellow-500';
    case 'DEBUG':
      return 'text-gray-400';
    default:
      return 'text-foreground';
  }
}

function getLevelBgColor(level: LogLevel): string {
  switch (level) {
    case 'ERROR':
      return 'bg-red-500/10';
    case 'WARN':
      return 'bg-yellow-500/10';
    case 'DEBUG':
      return 'bg-gray-500/10';
    default:
      return 'bg-transparent';
  }
}

// ---------------------------------------------------------------------------
// Log Level Filter Button
// ---------------------------------------------------------------------------

interface LevelFilterProps {
  selected: LogLevel;
  onChange: (level: LogLevel) => void;
}

function LevelFilter({ selected, onChange }: LevelFilterProps) {
  const levels: LogLevel[] = ['ALL', 'ERROR', 'WARN', 'INFO', 'DEBUG'];

  return (
    <div className="flex gap-1 rounded-lg border p-1">
      {levels.map((level) => (
        <button
          key={level}
          onClick={() => onChange(level)}
          className={`rounded px-2 py-1 text-xs font-medium transition-colors ${
            selected === level
              ? 'bg-primary text-primary-foreground'
              : 'hover:bg-accent text-muted-foreground'
          }`}
        >
          {level}
        </button>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Log Line Component
// ---------------------------------------------------------------------------

interface LogLineProps {
  line: ParsedLogLine;
}

function LogLine({ line }: LogLineProps) {
  const levelColor = getLevelColor(line.level);
  const levelBgColor = getLevelBgColor(line.level);

  return (
    <div className={`flex gap-2 px-3 py-1 font-mono text-xs hover:bg-accent/50 ${levelBgColor}`}>
      {line.timestamp && (
        <span className="text-muted-foreground shrink-0">{line.timestamp}</span>
      )}
      <span className={`shrink-0 font-semibold ${levelColor}`}>
        [{line.level}]
      </span>
      <span className={`${levelColor} break-all`}>{line.message}</span>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main Page
// ---------------------------------------------------------------------------

export default function LogsPage() {
  const { data, isLoading, error, refetch, isFetching } = useLogsTail(500);

  const [searchQuery, setSearchQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<LogLevel>('ALL');
  const [follow, setFollow] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Parse and filter log lines
  const logLines = useMemo(() => {
    if (!data?.lines) return [];

    const parsed = data.lines.map((line) =>
      parseLogLine(typeof line === 'string' ? line : (line as { line: string }).line)
    );

    return parsed.filter((line) => {
      // Level filter
      if (levelFilter !== 'ALL' && line.level !== levelFilter) {
        return false;
      }

      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return line.raw.toLowerCase().includes(query);
      }

      return true;
    });
  }, [data, levelFilter, searchQuery]);

  // Auto-scroll to bottom when following
  useEffect(() => {
    if (follow && containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [logLines, follow]);

  // Handle scroll to disable follow when user scrolls up
  const handleScroll = useCallback(() => {
    if (!containerRef.current) return;

    const { scrollTop, scrollHeight, clientHeight } = containerRef.current;
    const isAtBottom = scrollHeight - scrollTop - clientHeight < 50;

    if (!isAtBottom && follow) {
      setFollow(false);
    }
  }, [follow]);

  // Keyboard shortcut for search
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  const toggleFollow = useCallback(() => {
    setFollow((prev) => !prev);
    if (!follow && containerRef.current) {
      // When re-enabling follow, scroll to bottom
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [follow]);

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Logs"
        description="Real-time gateway logs"
        icon={<FileText className="h-5 w-5" />}
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant={follow ? 'default' : 'outline'}
              size="sm"
              onClick={toggleFollow}
            >
              {follow ? (
                <>
                  <Pause className="mr-1 h-4 w-4" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="mr-1 h-4 w-4" />
                  Follow
                </>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={isFetching}
            >
              <RefreshCw className={`mr-1 h-4 w-4 ${isFetching ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        }
      />

      {/* Toolbar */}
      <div className="flex items-center gap-3 border-b px-4 py-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            ref={searchInputRef}
            type="text"
            placeholder="Search logs... (Cmd+K)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-md border bg-background py-1.5 pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <LevelFilter selected={levelFilter} onChange={setLevelFilter} />
        <div className="text-xs text-muted-foreground">
          {logLines.length} {logLines.length === 1 ? 'line' : 'lines'}
        </div>
      </div>

      {/* Log content */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-auto"
      >
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            title="Error loading logs"
            description={error.message}
            icon={<FileText className="h-12 w-12" />}
          />
        ) : logLines.length > 0 ? (
          <div className="divide-y divide-border/50">
            {logLines.map((line, index) => (
              <LogLine key={index} line={line} />
            ))}
          </div>
        ) : (
          <EmptyState
            title="No logs found"
            description={
              searchQuery || levelFilter !== 'ALL'
                ? 'Try adjusting your filters'
                : 'Waiting for logs...'
            }
            icon={<FileText className="h-12 w-12" />}
          />
        )}
      </div>
    </div>
  );
}
