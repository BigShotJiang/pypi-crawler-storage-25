'use client';

import { useState, useEffect } from 'react';
import { Search, Sparkles, RefreshCw, Download } from 'lucide-react';
import { PageHeader, EmptyState, SkillCard } from '@pyclaw/ui';
import { skillsApi } from '@pyclaw/shared';
import type { Skill } from '@pyclaw/shared/types';

export default function SkillsPage() {
  const [skills, setSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<Skill[]>([]);
  const [searching, setSearching] = useState(false);
  const [tab, setTab] = useState<'installed' | 'browse'>('installed');

  useEffect(() => {
    loadSkills();
  }, []);

  async function loadSkills() {
    setLoading(true);
    setError(null);
    const result = await skillsApi.list();
    if (result.data) {
      setSkills(result.data.skills);
    } else {
      setError(result.error?.message || 'Failed to load skills');
    }
    setLoading(false);
  }

  async function handleSearch(query: string) {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }
    setSearching(true);
    const result = await skillsApi.search(query);
    if (result.data) {
      setSearchResults(result.data.results);
    }
    setSearching(false);
  }

  async function handleInstall(skillId: string) {
    const result = await skillsApi.install(skillId);
    if (result.error) {
      alert(result.error.message);
    } else {
      loadSkills();
      if (search) handleSearch(search);
    }
  }

  async function handleRemove(skill: Skill) {
    if (!confirm(`Uninstall "${skill.name}"?`)) return;
    const result = await skillsApi.remove(skill.id);
    if (result.error) {
      alert(result.error.message);
    } else {
      loadSkills();
    }
  }

  async function handleRun(skill: Skill) {
    const result = await skillsApi.run(skill.id);
    if (result.error) {
      alert(result.error.message);
    } else if (result.data?.error) {
      alert(result.data.error);
    }
  }

  const filteredSkills = skills.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Skills"
        description="Manage and install AI skills"
        icon={<Sparkles />}
        actions={
          <button
            onClick={loadSkills}
            disabled={loading}
            className="flex items-center gap-1 rounded border px-3 py-1 text-sm hover:bg-muted disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        }
      />

      <div className="border-b p-4">
        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search skills..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                if (tab === 'browse') handleSearch(e.target.value);
              }}
              className="w-full rounded-lg border py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div className="flex rounded-lg border">
            <button
              onClick={() => setTab('installed')}
              className={`px-4 py-2 text-sm ${tab === 'installed' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}
            >
              Installed
            </button>
            <button
              onClick={() => {
                setTab('browse');
                if (search) handleSearch(search);
              }}
              className={`px-4 py-2 text-sm ${tab === 'browse' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}
            >
              Browse
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {loading ? (
          <div className="flex h-32 items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            icon={<Sparkles />}
            title="Failed to load skills"
            description={error}
          />
        ) : tab === 'installed' ? (
          filteredSkills.length === 0 ? (
            <EmptyState
              icon={<Sparkles />}
              title="No skills installed"
              description="Browse and install skills to extend your agents' capabilities"
            />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filteredSkills.map((skill) => (
                <SkillCard
                  key={skill.id}
                  skill={skill}
                  onRun={() => handleRun(skill)}
                  onRemove={() => handleRemove(skill)}
                />
              ))}
            </div>
          )
        ) : (
          searching ? (
            <div className="flex h-32 items-center justify-center">
              <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : searchResults.length === 0 ? (
            <EmptyState
              icon={<Download />}
              title={search ? 'No results found' : 'Search for skills'}
              description={search ? 'Try a different search term' : 'Type to search the skill registry'}
            />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {searchResults.map((skill) => (
                <SkillCard
                  key={skill.id}
                  skill={skill}
                  onRemove={() => handleRemove(skill)}
                />
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
}
