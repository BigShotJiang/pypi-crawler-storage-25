'use client';

import { PageHeader, EmptyState, Button } from '@pyclaw/ui';
import { useSessionsList } from '@pyclaw/shared';
import { FileText, Plus, Loader2 } from 'lucide-react';

export default function SessionsPage() {
  const { data: sessions, isLoading, error } = useSessionsList();

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Sessions"
        description="Manage conversation sessions"
        actions={<Button size="sm"><Plus className="mr-1 h-4 w-4" />New Session</Button>}
      />
      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <EmptyState
            title="Error loading sessions"
            description={error.message}
            icon={<FileText className="h-12 w-12" />}
          />
        ) : sessions && sessions.length > 0 ? (
          <div className="space-y-2">
            {sessions.map((session) => (
              <div
                key={session.path}
                className="flex items-center justify-between rounded-lg border bg-card p-4"
              >
                <div>
                  <div className="font-medium">{session.file}</div>
                  <div className="text-sm text-muted-foreground">{session.agentId}</div>
                </div>
                <div className="text-sm text-muted-foreground">{(session.size / 1024).toFixed(1)} KB</div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title="No sessions"
            description="Start a conversation to create sessions"
            icon={<FileText className="h-12 w-12" />}
          />
        )}
      </div>
    </div>
  );
}
