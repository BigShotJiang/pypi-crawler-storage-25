'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  PageHeader,
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  Button,
} from '@pyclaw/ui';
import { useGatewayWebSocket, useAppStore } from '@pyclaw/shared';
import { Terminal, Send, Eraser, Circle, CircleDot } from 'lucide-react';

// ---------------------------------------------------------------------------
// RPC Methods - List of available WebSocket RPC methods
// ---------------------------------------------------------------------------

const RPC_METHODS = [
  { group: 'Chat', methods: ['chat.send', 'chat.abort', 'chat.history', 'chat.edit'] },
  { group: 'Agents', methods: ['agents.list', 'agents.add', 'agents.remove'] },
  { group: 'Sessions', methods: ['sessions.list', 'sessions.preview', 'sessions.create', 'sessions.delete', 'sessions.get'] },
  { group: 'Config', methods: ['config.get', 'config.set', 'config.patch'] },
  { group: 'Channels', methods: ['channels.list', 'channels.status'] },
  { group: 'Models', methods: ['models.list', 'models.get'] },
  { group: 'Tools', methods: ['tools.list', 'tools.catalog'] },
  { group: 'Logs', methods: ['logs.tail'] },
  { group: 'Backup', methods: ['backup.export', 'backup.status'] },
  { group: 'Secrets', methods: ['secrets.reload'] },
  { group: 'Health', methods: ['health.check', 'health.ping'] },
  { group: 'Plans', methods: ['plans.list', 'plans.resume'] },
  { group: 'Cron', methods: ['cron.list', 'cron.history'] },
  { group: 'Nodes', methods: ['nodes.paired', 'nodes.revoke'] },
];

// Default params for common methods
const DEFAULT_PARAMS: Record<string, string> = {
  'chat.send': '{\n  "sessionId": "test-session",\n  "message": "Hello"\n}',
  'sessions.list': '{}',
  'sessions.preview': '{\n  "path": "/path/to/session.jsonl",\n  "limit": 50\n}',
  'sessions.create': '{\n  "agentId": "main",\n  "title": "Test Session"\n}',
  'agents.list': '{}',
  'agents.add': '{\n  "agent_id": "new-agent"\n}',
  'agents.remove': '{\n  "agent_id": "agent-name"\n}',
  'config.get': '{}',
  'config.patch': '{\n  "patch": {\n    "models": {\n      "default": "claude-sonnet-4"\n    }\n  }\n}',
  'channels.list': '{}',
  'models.list': '{}',
  'tools.list': '{}',
  'logs.tail': '{\n  "limit": 50\n}',
  'backup.status': '{}',
  'secrets.reload': '{}',
  'health.check': '{}',
  'health.ping': '{}',
  'plans.list': '{}',
  'cron.list': '{}',
  'nodes.paired': '{}',
};

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface EventLog {
  id: string;
  timestamp: Date;
  type: 'sent' | 'received' | 'error' | 'info';
  method?: string;
  data: unknown;
}

// ---------------------------------------------------------------------------
// Page Component
// ---------------------------------------------------------------------------

export default function DebugPage() {
  const { connect, disconnect, call, connected, connectionState } = useGatewayWebSocket();
  const { gatewayState, setGatewayState } = useAppStore();

  const [selectedMethod, setSelectedMethod] = useState('sessions.list');
  const [params, setParams] = useState(DEFAULT_PARAMS['sessions.list'] || '{}');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Event log state
  const [eventLogs, setEventLogs] = useState<EventLog[]>([]);
  const logContainerRef = useRef<HTMLDivElement>(null);
  const maxLogs = 100;

  // Add log entry
  const addLog = useCallback((log: Omit<EventLog, 'id' | 'timestamp'>) => {
    const entry: EventLog = {
      ...log,
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: new Date(),
    };
    setEventLogs((prev) => {
      const newLogs = [...prev, entry];
      if (newLogs.length > maxLogs) {
        return newLogs.slice(-maxLogs);
      }
      return newLogs;
    });
  }, []);

  // Handle connection state changes
  useEffect(() => {
    setGatewayState(connectionState);
  }, [connectionState, setGatewayState]);

  // Auto-scroll to bottom of logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [eventLogs]);

  // Update params when method changes
  const handleMethodChange = (method: string) => {
    setSelectedMethod(method);
    setParams(DEFAULT_PARAMS[method] || '{}');
    setResponse(null);
  };

  // Execute RPC call
  const handleExecute = async () => {
    if (!connected) {
      addLog({ type: 'error', data: 'WebSocket not connected' });
      return;
    }

    let parsedParams: Record<string, unknown>;
    try {
      parsedParams = JSON.parse(params);
    } catch (e) {
      addLog({ type: 'error', method: selectedMethod, data: `Invalid JSON: ${e}` });
      return;
    }

    setIsLoading(true);
    addLog({ type: 'sent', method: selectedMethod, data: parsedParams });

    try {
      const result = await call<unknown>(selectedMethod, parsedParams);
      const formattedResponse = JSON.stringify(result, null, 2);
      setResponse(formattedResponse);
      addLog({ type: 'received', method: selectedMethod, data: result });
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : String(e);
      setResponse(`Error: ${errorMessage}`);
      addLog({ type: 'error', method: selectedMethod, data: errorMessage });
    } finally {
      setIsLoading(false);
    }
  };

  // Clear event logs
  const handleClearLogs = () => {
    setEventLogs([]);
  };

  // Clear response
  const handleClearResponse = () => {
    setResponse(null);
  };

  // Connect/Disconnect handler
  const handleToggleConnection = () => {
    if (connected) {
      disconnect();
      addLog({ type: 'info', data: 'Disconnected from Gateway' });
    } else {
      connect();
      addLog({ type: 'info', data: 'Connecting to Gateway...' });
    }
  };

  // Get log type styling
  const getLogTypeStyle = (type: EventLog['type']) => {
    switch (type) {
      case 'sent':
        return 'text-blue-500';
      case 'received':
        return 'text-green-500';
      case 'error':
        return 'text-red-500';
      case 'info':
        return 'text-yellow-500';
      default:
        return 'text-muted-foreground';
    }
  };

  // Get log type label
  const getLogTypeLabel = (type: EventLog['type']) => {
    switch (type) {
      case 'sent':
        return '>';
      case 'received':
        return '<';
      case 'error':
        return '!';
      case 'info':
        return '*';
      default:
        return '-';
    }
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Debug Panel"
        description="WebSocket RPC console and event monitor"
        actions={
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-sm">
              {connected ? (
                <CircleDot className="h-4 w-4 text-green-500" />
              ) : (
                <Circle className="h-4 w-4 text-muted-foreground" />
              )}
              <span className={connected ? 'text-green-500' : 'text-muted-foreground'}>
                {connectionState}
              </span>
            </div>
            <Button
              size="sm"
              variant={connected ? 'destructive' : 'default'}
              onClick={handleToggleConnection}
            >
              {connected ? 'Disconnect' : 'Connect'}
            </Button>
          </div>
        }
      />
      <div className="flex-1 overflow-auto p-4">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* RPC Executor Panel */}
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="h-5 w-5" />
                RPC Executor
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 space-y-4">
              {/* Method Selector */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Method</label>
                <select
                  value={selectedMethod}
                  onChange={(e) => handleMethodChange(e.target.value)}
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  {RPC_METHODS.map((group) => (
                    <optgroup key={group.group} label={group.group}>
                      {group.methods.map((method) => (
                        <option key={method} value={method}>
                          {method}
                        </option>
                      ))}
                    </optgroup>
                  ))}
                </select>
              </div>

              {/* Params Editor */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Parameters (JSON)</label>
                <textarea
                  value={params}
                  onChange={(e) => setParams(e.target.value)}
                  rows={8}
                  className="flex w-full rounded-md border border-input bg-muted/50 p-3 text-sm font-mono shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                  placeholder="{}"
                  spellCheck={false}
                />
              </div>

              {/* Execute Button */}
              <div className="flex gap-2">
                <Button
                  onClick={handleExecute}
                  disabled={!connected || isLoading}
                  className="flex-1"
                >
                  <Send className="mr-2 h-4 w-4" />
                  {isLoading ? 'Executing...' : 'Execute'}
                </Button>
                <Button variant="outline" onClick={handleClearResponse}>
                  <Eraser className="mr-2 h-4 w-4" />
                  Clear
                </Button>
              </div>

              {/* Response Display */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Response</label>
                <div className="min-h-[200px] rounded-md border bg-muted/30 p-3">
                  {response ? (
                    <pre className="overflow-auto text-xs font-mono whitespace-pre-wrap">
                      {response}
                    </pre>
                  ) : (
                    <span className="text-sm text-muted-foreground">
                      Response will appear here
                    </span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Event Log Panel */}
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Terminal className="h-5 w-5" />
                  Event Log
                </span>
                <Button variant="ghost" size="sm" onClick={handleClearLogs}>
                  <Eraser className="mr-1 h-3 w-3" />
                  Clear
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1">
              <div
                ref={logContainerRef}
                className="h-[500px] overflow-auto rounded-md border bg-muted/30 p-3 font-mono text-xs"
              >
                {eventLogs.length === 0 ? (
                  <span className="text-muted-foreground">
                    Waiting for events...
                  </span>
                ) : (
                  <div className="space-y-1">
                    {eventLogs.map((log) => (
                      <div key={log.id} className="flex gap-2">
                        <span className="text-muted-foreground shrink-0">
                          {log.timestamp.toLocaleTimeString()}
                        </span>
                        <span className={`shrink-0 ${getLogTypeStyle(log.type)}`}>
                          {getLogTypeLabel(log.type)}
                        </span>
                        {log.method && (
                          <span className="text-purple-400 shrink-0">
                            [{log.method}]
                          </span>
                        )}
                        <span className="break-all text-foreground/80">
                          {typeof log.data === 'string'
                            ? log.data
                            : JSON.stringify(log.data)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
