'use client';

import { useEffect, useState } from 'react';
import { PageHeader, Card, CardHeader, CardTitle, CardContent } from '@pyclaw/ui';
import { useConfig } from '@pyclaw/shared';
import { platform } from '@pyclaw/shared';

export default function SettingsPage() {
  const { data: config, isLoading, error } = useConfig();
  const [autostartEnabled, setAutostartEnabled] = useState<boolean | null>(null);
  const [autostartLoading, setAutostartLoading] = useState(false);
  const [autostartError, setAutostartError] = useState<string | null>(null);

  // Check autostart status on mount (Tauri desktop only)
  useEffect(() => {
    if (!platform.isTauri) return;

    const checkAutostart = async () => {
      try {
        const { isEnabled } = await import('@tauri-apps/plugin-autostart');
        const enabled = await isEnabled();
        setAutostartEnabled(enabled);
      } catch (err) {
        console.error('Failed to check autostart status:', err);
        setAutostartError('Failed to check autostart status');
      }
    };

    checkAutostart();
  }, []);

  const handleAutostartToggle = async (checked: boolean) => {
    if (!platform.isTauri || autostartLoading) return;

    setAutostartLoading(true);
    setAutostartError(null);

    try {
      const { enable, disable } = await import('@tauri-apps/plugin-autostart');
      if (checked) {
        await enable();
      } else {
        await disable();
      }
      setAutostartEnabled(checked);
    } catch (err) {
      console.error('Failed to update autostart:', err);
      setAutostartError('Failed to update autostart setting');
    } finally {
      setAutostartLoading(false);
    }
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader title="Settings" description="Configure PyClaw" />
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* Autostart section - Tauri desktop only */}
        {platform.isTauri && (
          <Card>
            <CardHeader>
              <CardTitle>Startup</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <label
                    htmlFor="autostart-toggle"
                    className="text-sm font-medium cursor-pointer"
                  >
                    Launch at login
                  </label>
                  <p className="text-xs text-muted-foreground mt-1">
                    Automatically start PyClaw when you log in to your computer.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {autostartLoading && (
                    <span className="text-xs text-muted-foreground">
                      Saving...
                    </span>
                  )}
                  <button
                    type="button"
                    role="switch"
                    id="autostart-toggle"
                    aria-checked={autostartEnabled ?? false}
                    disabled={autostartLoading || autostartEnabled === null}
                    onClick={() =>
                      handleAutostartToggle(!(autostartEnabled ?? false))
                    }
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed ${
                      autostartEnabled
                        ? 'bg-primary'
                        : 'bg-muted'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-background shadow ring-0 transition duration-200 ease-in-out ${
                        autostartEnabled ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
              {autostartError && (
                <p className="text-xs text-destructive mt-2">
                  {autostartError}
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Configuration display */}
        <Card>
          <CardHeader>
            <CardTitle>Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-muted-foreground">Loading...</div>
            ) : error ? (
              <div className="text-destructive">Failed to load configuration: {error.message}</div>
            ) : (
              <pre className="overflow-auto rounded-lg bg-muted p-4 text-xs">
                {JSON.stringify(config, null, 2)}
              </pre>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
