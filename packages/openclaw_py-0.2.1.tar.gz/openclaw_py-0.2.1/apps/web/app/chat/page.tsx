'use client';

import { useState, useEffect, useCallback } from 'react';
import { PageHeader, ChatInput, MessageBubble, ToolCallCard, EmptyState, cn } from '@pyclaw/ui';
import { useChatStore, useGatewayWebSocket } from '@pyclaw/shared';
import { MessageSquare, Download, ArrowDown, Mic, MicOff, Volume2, VolumeX } from 'lucide-react';
import { downloadChatAsMarkdown } from '@/lib/export-chat';
import { useScrollToBottom, useVoiceInput, useVoiceOutput } from '@/hooks';
import { FadeIn, ScaleIn, AnimatePresence } from '@/components/animations';

export default function ChatPage() {
  const { connected, streamChat } = useGatewayWebSocket();
  const {
    messages,
    isStreaming,
    streamingContent,
    streamingToolCalls,
    addUserMessage,
    startAssistantStream,
    appendDelta,
    addToolCall,
    updateToolCall,
    finishStream,
    finishStreamWithError,
    clearMessages,
  } = useChatStore();
  const [sessionId] = useState('default');
  const [inputValue, setInputValue] = useState('');

  // Voice input hook
  const {
    isSupported: voiceInputSupport,
    isListening,
    transcript,
    error: voiceError,
    startListening,
    stopListening,
    clearTranscript,
  } = useVoiceInput();

  // Voice output hook
  const {
    isSupported: voiceOutputSupport,
    isSpeaking,
    speak,
    stop: stopSpeaking,
  } = useVoiceOutput();

  // Scroll to bottom hook - auto-scroll when messages/streaming content changes
  const { isAtBottom, scrollToBottom, scrollRef } = useScrollToBottom(
    [messages, streamingContent],
    { threshold: 100 }
  );

  // When voice transcript arrives, fill it into the input field
  useEffect(() => {
    if (transcript && !isListening) {
      setInputValue((prev) => {
        const separator = prev.trim() ? ' ' : '';
        return prev.trim() + separator + transcript;
      });
      clearTranscript();
    }
  }, [transcript, isListening, clearTranscript]);

  // Toggle voice input
  const handleVoiceToggle = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening]);

  // Speak an assistant message aloud
  const handleSpeak = useCallback((text: string) => {
    if (isSpeaking) {
      stopSpeaking();
    } else {
      speak(text);
    }
  }, [isSpeaking, speak, stopSpeaking]);

  const handleSubmit = async () => {
    const message = inputValue.trim();
    if (!message) return;

    setInputValue('');
    addUserMessage(message);
    startAssistantStream();

    try {
      await streamChat(
        sessionId,
        message,
        (delta) => appendDelta(delta),
        (name, toolId) => {
          addToolCall({ id: toolId || name, name, status: 'running' });
        },
        (name, result, error) => {
          const toolCalls = useChatStore.getState().streamingToolCalls;
          const tc = toolCalls.find(t => t.name === name);
          if (tc) {
            updateToolCall(tc.id, {
              status: error ? 'error' : 'completed',
              result,
              error,
            });
          }
        }
      );
      finishStream();
    } catch (err) {
      finishStreamWithError(err instanceof Error ? err.message : 'Unknown error');
    }
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title="Chat"
        description="Chat with your AI assistant"
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={() => downloadChatAsMarkdown(messages)}
              disabled={messages.length === 0}
              className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed"
              title="Export chat as Markdown"
            >
              <Download className="h-4 w-4" />
              Export
            </button>
            <button
              onClick={clearMessages}
              className="text-sm text-muted-foreground hover:text-foreground"
            >
              Clear
            </button>
          </div>
        }
      />
      <div ref={scrollRef} className="relative flex-1 overflow-y-auto p-4">
        {messages.length === 0 && !isStreaming ? (
          <EmptyState
            title="No messages yet"
            description="Start a conversation by typing a message below"
            icon={<MessageSquare className="h-12 w-12" />}
          />
        ) : (
          <div className="space-y-4">
            <AnimatePresence mode="popLayout">
              {messages.map((msg) => (
                <FadeIn key={msg.id}>
                  <MessageBubble
                    role={msg.role}
                    content={msg.content}
                    actions={
                      msg.role === 'assistant' && voiceOutputSupport.supported ? (
                        <button
                          onClick={() => handleSpeak(msg.content)}
                          className={cn(
                            'inline-flex items-center justify-center rounded-md p-1',
                            'text-muted-foreground/60 hover:text-muted-foreground',
                            'transition-colors duration-150',
                            isSpeaking ? 'text-primary' : ''
                          )}
                          aria-label={isSpeaking ? 'Stop speaking' : 'Read aloud'}
                          title={isSpeaking ? 'Stop speaking' : 'Read aloud'}
                        >
                          {isSpeaking ? (
                            <VolumeX className="h-3.5 w-3.5" />
                          ) : (
                            <Volume2 className="h-3.5 w-3.5" />
                          )}
                        </button>
                      ) : undefined
                    }
                  />
                </FadeIn>
              ))}
              {isStreaming && (
                <FadeIn key="streaming">
                  <MessageBubble
                    role="assistant"
                    content={streamingContent}
                    isStreaming
                  />
                </FadeIn>
              )}
              {streamingToolCalls.map((tc) => (
                <ScaleIn key={tc.id}>
                  <ToolCallCard
                    name={tc.name}
                    status={tc.status === 'completed' ? 'success' : tc.status === 'error' ? 'error' : 'running'}
                    result={tc.result ? String(tc.result) : undefined}
                    error={tc.error}
                  />
                </ScaleIn>
              ))}
            </AnimatePresence>
          </div>
        )}
        {/* Scroll to bottom button */}
        <button
          onClick={scrollToBottom}
          className={`
            absolute bottom-4 right-4 z-10
            flex h-10 w-10 items-center justify-center
            rounded-full bg-background/80 backdrop-blur-sm border shadow-lg
            text-muted-foreground hover:text-foreground hover:bg-background
            transition-all duration-200
            ${!isAtBottom ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none'}
          `}
          aria-label="Scroll to bottom"
          title="Scroll to bottom"
        >
          <ArrowDown className="h-5 w-5" />
        </button>
      </div>
      {/* Voice error toast */}
      {voiceError && (
        <div className="mx-4 mb-2 rounded-lg bg-destructive/10 px-3 py-2 text-xs text-destructive">
          {voiceError}
        </div>
      )}
      <ScaleIn className="border-t p-4">
        <ChatInput
          value={inputValue}
          onChange={setInputValue}
          onSubmit={handleSubmit}
          disabled={!connected || isStreaming}
          actions={
            voiceInputSupport.supported ? (
              <button
                type="button"
                onClick={handleVoiceToggle}
                className={cn(
                  'inline-flex h-9 w-9 items-center justify-center rounded-md',
                  'transition-colors duration-150',
                  isListening
                    ? 'text-primary bg-primary/10 hover:bg-primary/20'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                )}
                aria-label={isListening ? 'Stop voice input' : 'Start voice input'}
                title={isListening ? 'Stop voice input' : 'Start voice input'}
              >
                {isListening ? (
                  <MicOff className="h-4 w-4" />
                ) : (
                  <Mic className="h-4 w-4" />
                )}
              </button>
            ) : undefined
          }
        />
      </ScaleIn>
    </div>
  );
}
