import { describe, expect, it } from "vitest";

import { generateFullId, generateId } from "../../src/utils/uuid";

describe("uuid utils", () => {
  describe("generateId", () => {
    it("should return a 12-character hex string", () => {
      const id = generateId();
      expect(id).toHaveLength(12);
      expect(id).toMatch(/^[0-9a-f]{12}$/);
    });

    it("should return unique ids on successive calls", () => {
      const id1 = generateId();
      const id2 = generateId();
      expect(id1).not.toBe(id2);
    });

    it("should contain only lowercase hex characters", () => {
      const id = generateId();
      // Hex chars: 0-9 and a-f
      expect(id).toMatch(/^[0-9a-f]+$/);
    });
  });

  describe("generateFullId", () => {
    it("should return a full UUID format string", () => {
      const id = generateFullId();
      // RFC 4122 v4 UUID format: xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
      expect(id).toMatch(
        /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/,
      );
    });

    it("should return unique ids on successive calls", () => {
      const id1 = generateFullId();
      const id2 = generateFullId();
      expect(id1).not.toBe(id2);
    });

    it("should be 36 characters long (32 hex + 4 dashes)", () => {
      const id = generateFullId();
      expect(id).toHaveLength(36);
    });
  });
});
