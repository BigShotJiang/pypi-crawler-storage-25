import { beforeEach, describe, expect, it, vi } from "vitest";

import {
  getApiBaseUrl,
  getWebSocketUrl,
  platform,
} from "../../src/utils/env";

describe("env utils", () => {
  const originalProcess = process;
  const originalWindow = globalThis.window;
  const originalNavigator = globalThis.navigator;

  beforeEach(() => {
    // Reset env vars before each test
    delete process.env.NEXT_PUBLIC_API_URL;
    delete process.env.EXPO_PUBLIC_API_URL;
    delete process.env.NODE_ENV;
    // Remove platform cache by re-importing if needed
    vi.restoreAllMocks();
  });

  describe("platform", () => {
    it("should have platform detection properties", () => {
      expect(platform).toHaveProperty("isTauri");
      expect(platform).toHaveProperty("isReactNative");
      expect(platform).toHaveProperty("isBrowser");
      expect(platform).toHaveProperty("isWeb");
    });

    it("should detect Node.js environment (not browser)", () => {
      // In Node test env, isWeb should be false since window is undefined
      expect(typeof platform.isTauri).toBe("boolean");
      expect(typeof platform.isReactNative).toBe("boolean");
      expect(typeof platform.isBrowser).toBe("boolean");
      expect(typeof platform.isWeb).toBe("boolean");
    });
  });

  describe("getApiBaseUrl", () => {
    it("should return NEXT_PUBLIC_API_URL when set", () => {
      process.env.NEXT_PUBLIC_API_URL = "https://api.example.com";
      expect(getApiBaseUrl()).toBe("https://api.example.com");
    });

    it("should return localhost in development mode", () => {
      process.env.NODE_ENV = "development";
      expect(getApiBaseUrl()).toBe("http://localhost:8765");
    });

    it("should return empty string in production with no env var", () => {
      process.env.NODE_ENV = "production";
      // No NEXT_PUBLIC_API_URL, not Tauri, not ReactNative
      expect(getApiBaseUrl()).toBe("");
    });

    it("should prioritize NEXT_PUBLIC_API_URL over NODE_ENV", () => {
      process.env.NEXT_PUBLIC_API_URL = "https://custom.api.com";
      process.env.NODE_ENV = "development";
      expect(getApiBaseUrl()).toBe("https://custom.api.com");
    });
  });

  describe("getWebSocketUrl", () => {
    it("should convert http to ws without appending /ws (gateway ws endpoint is at /)", () => {
      process.env.NEXT_PUBLIC_API_URL = "http://localhost:18777";
      expect(getWebSocketUrl()).toBe("ws://localhost:18777");
    });

    it("should convert https to wss without appending /ws", () => {
      process.env.NEXT_PUBLIC_API_URL = "https://api.example.com";
      expect(getWebSocketUrl()).toBe("wss://api.example.com");
    });

    it("should return default ws URL when no base URL is set", () => {
      process.env.NODE_ENV = "production";
      expect(getWebSocketUrl()).toBe("ws://localhost:8765");
    });

    it("should handle development mode localhost", () => {
      process.env.NODE_ENV = "development";
      expect(getWebSocketUrl()).toBe("ws://localhost:8765");
    });
  });
});
