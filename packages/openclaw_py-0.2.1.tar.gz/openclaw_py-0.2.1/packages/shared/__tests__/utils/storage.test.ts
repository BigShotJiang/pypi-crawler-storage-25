import { beforeEach, describe, expect, it, vi } from "vitest";

import { getStorage } from "../../src/utils/storage";
import type { StorageAdapter } from "../../src/utils/storage";

describe("storage utils", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  describe("getStorage", () => {
    it("should return a storage adapter with required methods", async () => {
      const storage = await getStorage();
      expect(storage).toBeDefined();
      expect(typeof storage.getItem).toBe("function");
      expect(typeof storage.setItem).toBe("function");
      expect(typeof storage.removeItem).toBe("function");
    });

    it("should return a working localStorage adapter in Node env", async () => {
      // In Node.js without Tauri/RN, falls back to localStorage-like adapter
      const storage = await getStorage();

      // In Node, localStorage is undefined, so getItem returns null
      const result = await storage.getItem("test-key");
      expect(result).toBeNull();
    });

    it("should handle setItem and getItem with localStorage mock", async () => {
      // Mock localStorage for Node environment
      const store: Record<string, string> = {};
      const localStorageMock = {
        getItem: (key: string) => store[key] ?? null,
        setItem: (key: string, value: string) => {
          store[key] = value;
        },
        removeItem: (key: string) => {
          delete store[key];
        },
      };

      // Since getStorage() checks for localStorage at runtime,
      // we test the adapter interface directly
      const adapter: StorageAdapter = localStorageMock;

      adapter.setItem("test-key", "test-value");
      expect(adapter.getItem("test-key")).toBe("test-value");

      adapter.removeItem("test-key");
      expect(adapter.getItem("test-key")).toBeNull();
    });

    it("should handle async storage adapter interface", async () => {
      // Simulate an async storage adapter (like AsyncStorage)
      const asyncStore: Record<string, string> = {};
      const asyncAdapter: StorageAdapter = {
        getItem: async (key: string) => asyncStore[key] ?? null,
        setItem: async (key: string, value: string) => {
          asyncStore[key] = value;
        },
        removeItem: async (key: string) => {
          delete asyncStore[key];
        },
      };

      await asyncAdapter.setItem("async-key", "async-value");
      const value = await asyncAdapter.getItem("async-key");
      expect(value).toBe("async-value");

      await asyncAdapter.removeItem("async-key");
      const removed = await asyncAdapter.getItem("async-key");
      expect(removed).toBeNull();
    });
  });
});
