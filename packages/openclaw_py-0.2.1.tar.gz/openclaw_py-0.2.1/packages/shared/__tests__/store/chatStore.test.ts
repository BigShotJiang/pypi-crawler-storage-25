import { beforeEach, describe, expect, it } from "vitest";

import { useChatStore } from "../../src/store/chat";

describe("ChatStore", () => {
  beforeEach(() => {
    useChatStore.setState({
      messages: [],
      isStreaming: false,
      streamingContent: "",
      streamingToolCalls: [],
    });
  });

  it("should add user message", () => {
    useChatStore.getState().addUserMessage("Hello");
    expect(useChatStore.getState().messages).toHaveLength(1);
    expect(useChatStore.getState().messages[0].role).toBe(
      "user",
    );
    expect(
      useChatStore.getState().messages[0].content,
    ).toBe("Hello");
  });

  it("should handle streaming", () => {
    const store = useChatStore.getState();
    store.startAssistantStream();
    store.appendDelta("Hi");
    store.appendDelta(" there");
    store.finishStream();

    expect(useChatStore.getState().messages).toHaveLength(1);
    expect(
      useChatStore.getState().messages[0].content,
    ).toBe("Hi there");
    expect(
      useChatStore.getState().messages[0].role,
    ).toBe("assistant");
  });

  it("should handle tool calls", () => {
    const store = useChatStore.getState();
    store.startAssistantStream();
    store.addToolCall({
      id: "t1",
      name: "read_file",
      status: "running",
    });
    store.updateToolCall("t1", {
      status: "completed",
      result: "file contents",
    });
    store.finishStream();

    expect(
      useChatStore.getState().messages[0].toolCalls,
    ).toHaveLength(1);
    expect(
      useChatStore.getState().messages[0].toolCalls?.[0]
        .status,
    ).toBe("completed");
  });

  it("should handle streaming errors", () => {
    const store = useChatStore.getState();
    store.startAssistantStream();
    store.appendDelta("Partial");
    store.finishStreamWithError("Network error");

    expect(useChatStore.getState().messages).toHaveLength(1);
    expect(
      useChatStore.getState().messages[0].content,
    ).toBe("Error: Network error");
  });

  it("should clear messages", () => {
    useChatStore.getState().addUserMessage("Test");
    useChatStore.getState().clearMessages();
    expect(useChatStore.getState().messages).toHaveLength(0);
  });

  it("should load messages", () => {
    const messages = [
      {
        id: "m1",
        role: "user" as const,
        content: "Hello",
        timestamp: Date.now(),
      },
    ];
    useChatStore.getState().loadMessages(messages);
    expect(useChatStore.getState().messages).toHaveLength(1);
    expect(
      useChatStore.getState().messages[0].content,
    ).toBe("Hello");
  });
});
