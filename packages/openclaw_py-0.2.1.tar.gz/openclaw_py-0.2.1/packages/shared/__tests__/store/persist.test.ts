import { beforeEach, describe, expect, it, vi } from "vitest";

import { loadPersistedState, setupPersistence } from "../../src/store/persist";
import { useAppStore } from "../../src/store/index";

// Mock the storage module
vi.mock("../../src/utils/storage", () => ({
  getStorage: vi.fn(),
}));

import { getStorage } from "../../src/utils/storage";
import type { StorageAdapter } from "../../src/utils/storage";

const mockGetStorage = vi.mocked(getStorage);

describe("persist", () => {
  beforeEach(() => {
    // Reset store to initial state
    useAppStore.setState({
      gatewayConnected: false,
      gatewayState: "disconnected",
      currentSessionId: null,
      selectedAgentId: null,
      sidebarOpen: true,
    });
    vi.clearAllMocks();
  });

  describe("loadPersistedState", () => {
    it("should load persisted state into the store", async () => {
      const mockStorage: StorageAdapter = {
        getItem: vi.fn().mockResolvedValue(
          JSON.stringify({ sidebarOpen: false }),
        ),
        setItem: vi.fn(),
        removeItem: vi.fn(),
      };
      mockGetStorage.mockResolvedValue(mockStorage);

      await loadPersistedState();

      expect(useAppStore.getState().sidebarOpen).toBe(false);
      expect(mockStorage.getItem).toHaveBeenCalledWith("pyclaw-app-state");
    });

    it("should not modify store when no persisted state exists", async () => {
      const mockStorage: StorageAdapter = {
        getItem: vi.fn().mockResolvedValue(null),
        setItem: vi.fn(),
        removeItem: vi.fn(),
      };
      mockGetStorage.mockResolvedValue(mockStorage);

      await loadPersistedState();

      expect(useAppStore.getState().sidebarOpen).toBe(true);
    });

    it("should handle invalid JSON gracefully", async () => {
      const consoleWarnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
      const mockStorage: StorageAdapter = {
        getItem: vi.fn().mockResolvedValue("not-valid-json{{{"),
        setItem: vi.fn(),
        removeItem: vi.fn(),
      };
      mockGetStorage.mockResolvedValue(mockStorage);

      // Should not throw
      await loadPersistedState();

      // Store should remain unchanged
      expect(useAppStore.getState().sidebarOpen).toBe(true);
      expect(consoleWarnSpy).toHaveBeenCalledWith("Failed to parse persisted state");

      consoleWarnSpy.mockRestore();
    });

    it("should handle storage errors gracefully", async () => {
      const mockStorage: StorageAdapter = {
        getItem: vi.fn().mockRejectedValue(new Error("Storage error")),
        setItem: vi.fn(),
        removeItem: vi.fn(),
      };
      mockGetStorage.mockResolvedValue(mockStorage);

      // Should not throw
      await expect(loadPersistedState()).rejects.toThrow("Storage error");
    });
  });

  describe("setupPersistence", () => {
    it("should subscribe to store changes and persist sidebarOpen", async () => {
      const mockSetItem = vi.fn().mockResolvedValue(undefined);
      const mockStorage: StorageAdapter = {
        getItem: vi.fn(),
        setItem: mockSetItem,
        removeItem: vi.fn(),
      };
      mockGetStorage.mockResolvedValue(mockStorage);

      setupPersistence();

      // Trigger a state change
      useAppStore.getState().setSidebarOpen(false);

      // Wait for async persistence to complete
      await vi.waitFor(() => {
        expect(mockGetStorage).toHaveBeenCalled();
      });

      // Verify setItem was called with the partial state
      expect(mockSetItem).toHaveBeenCalledWith(
        "pyclaw-app-state",
        JSON.stringify({ sidebarOpen: false }),
      );
    });

    it("should persist sidebarOpen toggle", async () => {
      const mockSetItem = vi.fn().mockResolvedValue(undefined);
      const mockStorage: StorageAdapter = {
        getItem: vi.fn(),
        setItem: mockSetItem,
        removeItem: vi.fn(),
      };
      mockGetStorage.mockResolvedValue(mockStorage);

      setupPersistence();

      useAppStore.getState().toggleSidebar();

      await vi.waitFor(() => {
        expect(mockSetItem).toHaveBeenCalled();
      });

      expect(mockSetItem).toHaveBeenCalledWith(
        "pyclaw-app-state",
        JSON.stringify({ sidebarOpen: false }),
      );
    });

    it("should silently ignore persistence errors", async () => {
      const mockSetItem = vi.fn().mockRejectedValue(new Error("Write failed"));
      const mockStorage: StorageAdapter = {
        getItem: vi.fn(),
        setItem: mockSetItem,
        removeItem: vi.fn(),
      };
      mockGetStorage.mockResolvedValue(mockStorage);

      setupPersistence();

      // Should not throw even when storage fails
      useAppStore.getState().setSidebarOpen(false);

      // Give time for the async operation
      await new Promise((resolve) => setTimeout(resolve, 50));

      // No error should have been thrown
      expect(mockSetItem).toHaveBeenCalled();
    });
  });
});
