import { beforeEach, describe, expect, it } from "vitest";

import { useAppStore } from "../../src/store/index";

describe("AppStore", () => {
  beforeEach(() => {
    // Reset store to initial state
    useAppStore.setState({
      gatewayConnected: false,
      gatewayState: "disconnected",
      currentSessionId: null,
      selectedAgentId: null,
      sidebarOpen: true,
    });
  });

  describe("initial state", () => {
    it("should have correct default values", () => {
      const state = useAppStore.getState();
      expect(state.gatewayConnected).toBe(false);
      expect(state.gatewayState).toBe("disconnected");
      expect(state.currentSessionId).toBeNull();
      expect(state.selectedAgentId).toBeNull();
      expect(state.sidebarOpen).toBe(true);
    });
  });

  describe("setGatewayState", () => {
    it("should set gateway state to connecting", () => {
      useAppStore.getState().setGatewayState("connecting");
      const state = useAppStore.getState();
      expect(state.gatewayState).toBe("connecting");
      expect(state.gatewayConnected).toBe(false);
    });

    it("should set gateway state to connected and update gatewayConnected", () => {
      useAppStore.getState().setGatewayState("connected");
      const state = useAppStore.getState();
      expect(state.gatewayState).toBe("connected");
      expect(state.gatewayConnected).toBe(true);
    });

    it("should set gateway state to disconnected and update gatewayConnected", () => {
      // First connect
      useAppStore.getState().setGatewayState("connected");
      expect(useAppStore.getState().gatewayConnected).toBe(true);

      // Then disconnect
      useAppStore.getState().setGatewayState("disconnected");
      expect(useAppStore.getState().gatewayState).toBe("disconnected");
      expect(useAppStore.getState().gatewayConnected).toBe(false);
    });

    it("should transition through states correctly", () => {
      const store = useAppStore.getState();

      store.setGatewayState("connecting");
      expect(useAppStore.getState().gatewayState).toBe("connecting");
      expect(useAppStore.getState().gatewayConnected).toBe(false);

      useAppStore.getState().setGatewayState("connected");
      expect(useAppStore.getState().gatewayState).toBe("connected");
      expect(useAppStore.getState().gatewayConnected).toBe(true);

      useAppStore.getState().setGatewayState("disconnected");
      expect(useAppStore.getState().gatewayState).toBe("disconnected");
      expect(useAppStore.getState().gatewayConnected).toBe(false);
    });
  });

  describe("setCurrentSession", () => {
    it("should set current session id", () => {
      useAppStore.getState().setCurrentSession("session-123");
      expect(useAppStore.getState().currentSessionId).toBe("session-123");
    });

    it("should clear current session id with null", () => {
      useAppStore.getState().setCurrentSession("session-123");
      expect(useAppStore.getState().currentSessionId).toBe("session-123");

      useAppStore.getState().setCurrentSession(null);
      expect(useAppStore.getState().currentSessionId).toBeNull();
    });
  });

  describe("setSelectedAgent", () => {
    it("should set selected agent id", () => {
      useAppStore.getState().setSelectedAgent("agent-456");
      expect(useAppStore.getState().selectedAgentId).toBe("agent-456");
    });

    it("should clear selected agent id with null", () => {
      useAppStore.getState().setSelectedAgent("agent-456");
      expect(useAppStore.getState().selectedAgentId).toBe("agent-456");

      useAppStore.getState().setSelectedAgent(null);
      expect(useAppStore.getState().selectedAgentId).toBeNull();
    });

    it("should replace selected agent id", () => {
      useAppStore.getState().setSelectedAgent("agent-1");
      useAppStore.getState().setSelectedAgent("agent-2");
      expect(useAppStore.getState().selectedAgentId).toBe("agent-2");
    });
  });

  describe("toggleSidebar", () => {
    it("should toggle sidebar from open to closed", () => {
      expect(useAppStore.getState().sidebarOpen).toBe(true);
      useAppStore.getState().toggleSidebar();
      expect(useAppStore.getState().sidebarOpen).toBe(false);
    });

    it("should toggle sidebar from closed to open", () => {
      useAppStore.getState().setSidebarOpen(false);
      expect(useAppStore.getState().sidebarOpen).toBe(false);

      useAppStore.getState().toggleSidebar();
      expect(useAppStore.getState().sidebarOpen).toBe(true);
    });

    it("should toggle sidebar back and forth", () => {
      expect(useAppStore.getState().sidebarOpen).toBe(true);

      useAppStore.getState().toggleSidebar();
      expect(useAppStore.getState().sidebarOpen).toBe(false);

      useAppStore.getState().toggleSidebar();
      expect(useAppStore.getState().sidebarOpen).toBe(true);
    });
  });

  describe("setSidebarOpen", () => {
    it("should set sidebar to open", () => {
      useAppStore.getState().setSidebarOpen(false);
      useAppStore.getState().setSidebarOpen(true);
      expect(useAppStore.getState().sidebarOpen).toBe(true);
    });

    it("should set sidebar to closed", () => {
      useAppStore.getState().setSidebarOpen(false);
      expect(useAppStore.getState().sidebarOpen).toBe(false);
    });

    it("should not change value when setting to same value", () => {
      useAppStore.getState().setSidebarOpen(true);
      expect(useAppStore.getState().sidebarOpen).toBe(true);
    });
  });
});
