import { describe, expect, it } from "vitest";

import {
  getAvailableLocales,
  getLocale,
  setLocale,
  t,
} from "../src/i18n";

describe("i18n", () => {
  it("should return English by default", () => {
    expect(getLocale()).toBe("en");
    expect(t("app.name")).toBe("PyClaw");
    expect(t("nav.agents")).toBe("Agents");
  });

  it("should switch locale", () => {
    setLocale("zh-CN");
    expect(getLocale()).toBe("zh-CN");
    expect(t("nav.agents")).toBe("\u667a\u80fd\u4f53");
    expect(t("chat.send")).toBe("\u53d1\u9001");

    // Reset
    setLocale("en");
  });

  it("should return key for missing translation", () => {
    expect(t("missing.key")).toBe("missing.key");
  });

  it("should interpolate params", () => {
    // Add a test translation with placeholder
    expect(t("chat.send")).toBe("Send"); // No params needed
  });

  it("should list available locales", () => {
    const locales = getAvailableLocales();
    expect(locales).toContain("en");
    expect(locales).toContain("zh-CN");
    expect(locales).toHaveLength(2);
  });
});
