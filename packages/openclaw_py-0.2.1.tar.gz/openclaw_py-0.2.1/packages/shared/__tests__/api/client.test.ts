import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Mock fetch before importing client
const fetchSpy = vi.fn();

describe("ApiClient", () => {
  beforeEach(async () => {
    vi.resetModules();
    vi.stubGlobal("fetch", fetchSpy);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.clearAllMocks();
  });

  describe("request - success", () => {
    it("should make a GET request and return data on success", async () => {
      const mockData = { agents: [{ id: "agent-1" }] };
      fetchSpy.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockData),
      });

      // Import after mocking fetch
      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.get("/agents");

      expect(fetchSpy).toHaveBeenCalledWith(
        expect.stringContaining("/api/v1/agents"),
        expect.objectContaining({
          method: "GET",
          headers: expect.objectContaining({
            "Content-Type": "application/json",
          }),
        }),
      );
      expect(result.data).toEqual(mockData);
      expect(result.error).toBeNull();
    });

    it("should make a POST request with JSON body", async () => {
      const mockData = { session_id: "sess-1" };
      fetchSpy.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockData),
      });

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.post("/sessions", {
        agent_id: "main",
      });

      expect(fetchSpy).toHaveBeenCalledWith(
        expect.stringContaining("/api/v1/sessions"),
        expect.objectContaining({
          method: "POST",
          body: JSON.stringify({ agent_id: "main" }),
        }),
      );
      expect(result.data).toEqual(mockData);
      expect(result.error).toBeNull();
    });

    it("should make a PATCH request with JSON body", async () => {
      const mockData = { updated: true };
      fetchSpy.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockData),
      });

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.patch("/config", {
        patch: { models: { default: "gpt-4" } },
      });

      expect(fetchSpy).toHaveBeenCalledWith(
        expect.stringContaining("/api/v1/config"),
        expect.objectContaining({
          method: "PATCH",
        }),
      );
      expect(result.data).toEqual(mockData);
    });

    it("should make a DELETE request", async () => {
      fetchSpy.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(null),
      });

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.delete("/agents/agent-1");

      expect(fetchSpy).toHaveBeenCalledWith(
        expect.stringContaining("/api/v1/agents/agent-1"),
        expect.objectContaining({
          method: "DELETE",
        }),
      );
      expect(result.data).toBeNull();
      expect(result.error).toBeNull();
    });
  });

  describe("request - HTTP error", () => {
    it("should return error with status code on HTTP error", async () => {
      fetchSpy.mockResolvedValue({
        ok: false,
        status: 404,
        json: () =>
          Promise.resolve({ detail: "Agent not found" }),
      });

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.get("/agents/missing");

      expect(result.data).toBeNull();
      expect(result.error).toEqual({
        message: "Agent not found",
        code: "404",
      });
    });

    it("should return generic error message when response body is not JSON", async () => {
      fetchSpy.mockResolvedValue({
        ok: false,
        status: 500,
        json: () => Promise.reject(new Error("Not JSON")),
      });

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.get("/agents");

      expect(result.data).toBeNull();
      expect(result.error).toEqual({
        message: "HTTP 500",
        code: "500",
      });
    });

    it("should return error with detail from 400 response", async () => {
      fetchSpy.mockResolvedValue({
        ok: false,
        status: 400,
        json: () =>
          Promise.resolve({ detail: "Invalid request body" }),
      });

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.post("/sessions", {});

      expect(result.error?.message).toBe("Invalid request body");
      expect(result.error?.code).toBe("400");
    });
  });

  describe("request - network error", () => {
    it("should return error message on network failure", async () => {
      fetchSpy.mockRejectedValue(
        new TypeError("Failed to fetch"),
      );

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.get("/agents");

      expect(result.data).toBeNull();
      expect(result.error).toEqual({
        message: "Failed to fetch",
      });
      expect(result.error?.code).toBeUndefined();
    });

    it("should return 'Unknown error' for non-Error exceptions", async () => {
      fetchSpy.mockRejectedValue("string error");

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.get("/agents");

      expect(result.data).toBeNull();
      expect(result.error).toEqual({
        message: "Unknown error",
      });
    });

    it("should handle connection refused errors", async () => {
      fetchSpy.mockRejectedValue(
        new Error("ECONNREFUSED"),
      );

      const { apiClient } = await import("../../src/api/client");
      const result = await apiClient.get("/agents");

      expect(result.data).toBeNull();
      expect(result.error?.message).toBe("ECONNREFUSED");
    });
  });

  describe("resource APIs", () => {
    it("should have agentsApi with list, get, create, delete methods", async () => {
      fetchSpy.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ agents: [] }),
      });

      const { agentsApi } = await import("../../src/api/client");
      expect(agentsApi.list).toBeTypeOf("function");
      expect(agentsApi.get).toBeTypeOf("function");
      expect(agentsApi.create).toBeTypeOf("function");
      expect(agentsApi.delete).toBeTypeOf("function");

      await agentsApi.list();
      expect(fetchSpy).toHaveBeenCalledWith(
        expect.stringContaining("/api/v1/agents"),
        expect.any(Object),
      );
    });

    it("should have sessionsApi with list, create, delete methods", async () => {
      fetchSpy.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ sessions: [] }),
      });

      const { sessionsApi } = await import("../../src/api/client");
      expect(sessionsApi.list).toBeTypeOf("function");
      expect(sessionsApi.create).toBeTypeOf("function");
      expect(sessionsApi.delete).toBeTypeOf("function");

      await sessionsApi.list();
      expect(fetchSpy).toHaveBeenCalledWith(
        expect.stringContaining("/api/v1/sessions"),
        expect.any(Object),
      );
    });

    it("should have configApi with get and patch methods", async () => {
      fetchSpy.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({}),
      });

      const { configApi } = await import("../../src/api/client");
      expect(configApi.get).toBeTypeOf("function");
      expect(configApi.patch).toBeTypeOf("function");

      await configApi.get();
      expect(fetchSpy).toHaveBeenCalledWith(
        expect.stringContaining("/api/v1/config"),
        expect.any(Object),
      );
    });

    it("should encode paths with special characters", async () => {
      fetchSpy.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(null),
      });

      const { sessionsApi } = await import("../../src/api/client");
      await sessionsApi.preview("sessions/2024/04/my session.jsonl");

      expect(fetchSpy).toHaveBeenCalledWith(
        expect.stringContaining(encodeURIComponent("sessions/2024/04/my session.jsonl")),
        expect.any(Object),
      );
    });
  });
});
