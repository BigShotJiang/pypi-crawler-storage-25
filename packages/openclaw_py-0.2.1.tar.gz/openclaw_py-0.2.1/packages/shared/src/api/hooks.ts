/**
 * React Query hooks for the PyClaw Gateway API.
 *
 * Provides data-fetching hooks with automatic caching and
 * mutation hooks with cache invalidation.
 */

import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";

import {
  agentsApi,
  configApi,
  sessionsApi,
  cronApi,
  plansApi,
  usageApi,
  backupApi,
  logsApi,
  skillsApi,
  modelsApi,
  mcpApi,
  devicesApi,
} from "./client";

// ---------------------------------------------------------------------------
// Query keys
// ---------------------------------------------------------------------------

export const queryKeys = {
  agents: {
    all: ["agents"] as const,
    list: () =>
      [...queryKeys.agents.all, "list"] as const,
    detail: (id: string) =>
      [...queryKeys.agents.all, "detail", id] as const,
  },
  sessions: {
    all: ["sessions"] as const,
    list: () =>
      [...queryKeys.sessions.all, "list"] as const,
    preview: (path: string) =>
      [
        ...queryKeys.sessions.all,
        "preview",
        path,
      ] as const,
  },
  config: {
    all: ["config"] as const,
  },
  channels: {
    all: ["channels"] as const,
  },
  cron: {
    all: ["cron"] as const,
    list: () => [...queryKeys.cron.all, "list"] as const,
  },
  plans: {
    all: ["plans"] as const,
    list: () => [...queryKeys.plans.all, "list"] as const,
    detail: (id: string) =>
      [...queryKeys.plans.all, "detail", id] as const,
  },
  usage: {
    all: ["usage"] as const,
    stats: (range: string) =>
      [...queryKeys.usage.all, "stats", range] as const,
    daily: (range: string) =>
      [...queryKeys.usage.all, "daily", range] as const,
    hourly: (range: string) =>
      [...queryKeys.usage.all, "hourly", range] as const,
  },
  backup: {
    all: ["backup"] as const,
  },
  logs: {
    all: ["logs"] as const,
    tail: (limit: number) =>
      [...queryKeys.logs.all, "tail", limit] as const,
  },
  skills: {
    all: ["skills"] as const,
    list: () => [...queryKeys.skills.all, "list"] as const,
  },
  models: {
    all: ["models"] as const,
    list: () => [...queryKeys.models.all, "list"] as const,
    detail: (id: string) =>
      [...queryKeys.models.all, "detail", id] as const,
  },
  mcp: {
    all: ["mcp"] as const,
    status: () => [...queryKeys.mcp.all, "status"] as const,
    tools: (serverId: string) =>
      [...queryKeys.mcp.all, "tools", serverId] as const,
  },
  devices: {
    all: ["devices"] as const,
    list: () => [...queryKeys.devices.all, "list"] as const,
  },
} as const;

// ---------------------------------------------------------------------------
// Agent hooks
// ---------------------------------------------------------------------------

export function useAgentsList() {
  return useQuery({
    queryKey: queryKeys.agents.list(),
    queryFn: async () => {
      const { data, error } = await agentsApi.list();
      if (error) throw new Error(error.message);
      return data?.agents ?? [];
    },
    staleTime: 30_000,
  });
}

export function useAgentDetail(id: string) {
  return useQuery({
    queryKey: queryKeys.agents.detail(id),
    queryFn: async () => {
      const { data, error } = await agentsApi.get(id);
      if (error) throw new Error(error.message);
      return data;
    },
    enabled: !!id,
  });
}

export function useCreateAgent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      agent_id,
      config,
    }: {
      agent_id: string;
      config?: Record<string, unknown>;
    }) => agentsApi.create(agent_id, config),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.agents.list(),
      }),
  });
}

export function useDeleteAgent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => agentsApi.delete(id),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.agents.list(),
      }),
  });
}

// ---------------------------------------------------------------------------
// Session hooks
// ---------------------------------------------------------------------------

export function useSessionsList() {
  return useQuery({
    queryKey: queryKeys.sessions.list(),
    queryFn: async () => {
      const { data, error } = await sessionsApi.list();
      if (error) throw new Error(error.message);
      return data?.sessions ?? [];
    },
    staleTime: 10_000,
  });
}

export function useSessionPreview(
  path: string,
  limit = 50,
) {
  return useQuery({
    queryKey: queryKeys.sessions.preview(path),
    queryFn: async () => {
      const { data, error } =
        await sessionsApi.preview(path, limit);
      if (error) throw new Error(error.message);
      return data?.messages ?? [];
    },
    enabled: !!path,
  });
}

export function useCreateSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: sessionsApi.create,
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.sessions.list(),
      }),
  });
}

export function useDeleteSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (path: string) =>
      sessionsApi.delete(path),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.sessions.list(),
      }),
  });
}

// ---------------------------------------------------------------------------
// Config hooks
// ---------------------------------------------------------------------------

export function useConfig() {
  return useQuery({
    queryKey: queryKeys.config.all,
    queryFn: async () => {
      const { data, error } = await configApi.get();
      if (error) throw new Error(error.message);
      return data?.config ?? {};
    },
    staleTime: 60_000,
  });
}

export function usePatchConfig() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (patch: Record<string, unknown>) =>
      configApi.patch(patch),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.config.all,
      }),
  });
}

// ---------------------------------------------------------------------------
// Cron hooks
// ---------------------------------------------------------------------------

export function useCronList() {
  return useQuery({
    queryKey: queryKeys.cron.list(),
    queryFn: async () => {
      const { data, error } = await cronApi.list();
      if (error) throw new Error(error.message);
      return data?.jobs ?? [];
    },
    staleTime: 30_000,
  });
}

export function useCreateCronJob() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: cronApi.create,
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.cron.list(),
      }),
  });
}

export function useToggleCronJob() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, enabled }: { id: string; enabled: boolean }) =>
      cronApi.toggle(id, enabled),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.cron.list(),
      }),
  });
}

export function useDeleteCronJob() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => cronApi.remove(id),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.cron.list(),
      }),
  });
}

// ---------------------------------------------------------------------------
// Plan hooks
// ---------------------------------------------------------------------------

export function usePlansList() {
  return useQuery({
    queryKey: queryKeys.plans.list(),
    queryFn: async () => {
      const { data, error } = await plansApi.list();
      if (error) throw new Error(error.message);
      return data?.plans ?? [];
    },
    staleTime: 10_000,
  });
}

export function usePlanDetail(id: string) {
  return useQuery({
    queryKey: queryKeys.plans.detail(id),
    queryFn: async () => {
      const { data, error } = await plansApi.get(id);
      if (error) throw new Error(error.message);
      return data;
    },
    enabled: !!id,
  });
}

export function useResumePlan() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => plansApi.resume(id),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.plans.list(),
      }),
  });
}

export function useDeletePlan() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => plansApi.remove(id),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.plans.list(),
      }),
  });
}

// ---------------------------------------------------------------------------
// Usage hooks
// ---------------------------------------------------------------------------

export function useUsageStats(range = "7d") {
  return useQuery({
    queryKey: queryKeys.usage.stats(range),
    queryFn: async () => {
      const { data, error } = await usageApi.stats(range);
      if (error) throw new Error(error.message);
      return data;
    },
    staleTime: 60_000,
  });
}

export function useUsageDaily(range = "7d") {
  return useQuery({
    queryKey: queryKeys.usage.daily(range),
    queryFn: async () => {
      const { data, error } = await usageApi.daily(range);
      if (error) throw new Error(error.message);
      return data?.data ?? [];
    },
    staleTime: 60_000,
  });
}

export function useUsageHourly(range = "7d") {
  return useQuery({
    queryKey: queryKeys.usage.hourly(range),
    queryFn: async () => {
      const { data, error } = await usageApi.hourly(range);
      if (error) throw new Error(error.message);
      return data?.data ?? [];
    },
    staleTime: 60_000,
  });
}

export function useTokenSavings() {
  return useQuery({
    queryKey: ["token-savings"] as const,
    queryFn: async () => {
      const { data, error } = await usageApi.savings();
      if (error) throw new Error(error.message);
      return data;
    },
    staleTime: 60_000,
  });
}

// ---------------------------------------------------------------------------
// Backup hooks
// ---------------------------------------------------------------------------

export function useBackupStatus() {
  return useQuery({
    queryKey: queryKeys.backup.all,
    queryFn: async () => {
      const { data, error } = await backupApi.status();
      if (error) throw new Error(error.message);
      return data;
    },
    staleTime: 60_000,
  });
}

export function useExportBackup() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: backupApi.export,
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.backup.all,
      }),
  });
}

// ---------------------------------------------------------------------------
// Logs hooks
// ---------------------------------------------------------------------------

export function useLogsTail(limit = 200) {
  return useQuery({
    queryKey: queryKeys.logs.tail(limit),
    queryFn: async () => {
      const { data, error } = await logsApi.tail(limit);
      if (error) throw new Error(error.message);
      return data;
    },
    staleTime: 5_000,
  });
}

// ---------------------------------------------------------------------------
// Skills hooks
// ---------------------------------------------------------------------------

export function useSkillsList() {
  return useQuery({
    queryKey: queryKeys.skills.list(),
    queryFn: async () => {
      const { data, error } = await skillsApi.list();
      if (error) throw new Error(error.message);
      return data?.skills ?? [];
    },
    staleTime: 30_000,
  });
}

// ---------------------------------------------------------------------------
// Models hooks
// ---------------------------------------------------------------------------

export function useModelsList() {
  return useQuery({
    queryKey: queryKeys.models.list(),
    queryFn: async () => {
      const { data, error } = await modelsApi.list();
      if (error) throw new Error(error.message);
      return data?.models ?? [];
    },
    staleTime: 30_000,
  });
}

export function useModelDetail(id: string) {
  return useQuery({
    queryKey: queryKeys.models.detail(id),
    queryFn: async () => {
      const { data, error } = await modelsApi.get(id);
      if (error) throw new Error(error.message);
      return data;
    },
    enabled: !!id,
  });
}

// ---------------------------------------------------------------------------
// MCP hooks
// ---------------------------------------------------------------------------

export function useMcpStatus() {
  return useQuery({
    queryKey: queryKeys.mcp.status(),
    queryFn: async () => {
      const { data, error } = await mcpApi.status();
      if (error) throw new Error(error.message);
      return data;
    },
    staleTime: 30_000,
  });
}

export function useMcpTools(serverId: string) {
  return useQuery({
    queryKey: queryKeys.mcp.tools(serverId),
    queryFn: async () => {
      const { data, error } = await mcpApi.tools(serverId);
      if (error) throw new Error(error.message);
      return data?.tools ?? [];
    },
    enabled: !!serverId,
  });
}

// ---------------------------------------------------------------------------
// Devices hooks
// ---------------------------------------------------------------------------

export function useDevicesList() {
  return useQuery({
    queryKey: queryKeys.devices.list(),
    queryFn: async () => {
      const { data, error } = await devicesApi.list();
      if (error) throw new Error(error.message);
      return data?.devices ?? [];
    },
    staleTime: 30_000,
  });
}
