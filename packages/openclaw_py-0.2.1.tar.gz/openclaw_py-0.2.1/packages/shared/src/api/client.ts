/**
 * REST API client for the PyClaw Gateway.
 *
 * Wraps fetch with typed request helpers and resource-specific APIs
 * aligned with the Python backend endpoints.
 */

import type {
  Agent,
  AgentListResponse,
  ChannelListResponse,
  ChannelResponse,
  ChannelCatalogEntry,
  ConfigResponse,
  SessionCreateRequest,
  SessionCreateResponse,
  SessionInfo,
  SessionListResponse,
  SessionPreviewResponse,
  Model,
  ModelListResponse,
  ModelResponse,
  Device,
  DeviceListResponse,
  DeviceApproveRequest,
  Skill,
  SkillListResponse,
  SkillSearchResponse,
  SkillRunResponse,
  McpStatusResponse,
  ToolListResponse,
  AuthProviderStatus,
  AuthStatusResponse,
  AuthLoginRequest,
  AuthLogoutRequest,
  // New types for P1 endpoints
  CronJob,
  CronJobCreate,
  CronListResponse,
  CronCreateResponse,
  Plan,
  PlanListResponse,
  PlanResumeResponse,
  PlanDeleteResponse,
  UsageStats,
  UsageDailyResponse,
  UsageHourlyResponse,
  TokenSavingsResponse,
  BackupExportResponse,
  BackupStatusResponse,
  LogsTailResponse,
} from "../types";
import { getApiBaseUrl } from "../utils/env";

// ---------------------------------------------------------------------------
// Low-level client
// ---------------------------------------------------------------------------

export interface ApiError {
  message: string;
  code?: string;
}

export interface ApiResponse<T> {
  data: T | null;
  error: ApiError | null;
}

class ApiClient {
  private baseUrl: string;

  constructor() {
    this.baseUrl = getApiBaseUrl();
  }

  private async request<T>(
    path: string,
    options: RequestInit = {},
  ): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(`${this.baseUrl}/api/v1${path}`, {
        ...options,
        headers: {
          "Content-Type": "application/json",
          ...options.headers,
        },
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        return {
          data: null,
          error: {
            message:
              errorData.detail || `HTTP ${response.status}`,
            code: response.status.toString(),
          },
        };
      }
      const data = (await response.json()) as T;
      return { data, error: null };
    } catch (err) {
      return {
        data: null,
        error: {
          message:
            err instanceof Error ? err.message : "Unknown error",
        },
      };
    }
  }

  async get<T>(path: string): Promise<ApiResponse<T>> {
    return this.request<T>(path, { method: "GET" });
  }

  async post<T>(
    path: string,
    body: unknown,
  ): Promise<ApiResponse<T>> {
    return this.request<T>(path, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  async patch<T>(
    path: string,
    body: unknown,
  ): Promise<ApiResponse<T>> {
    return this.request<T>(path, {
      method: "PATCH",
      body: JSON.stringify(body),
    });
  }

  async delete<T>(path: string): Promise<ApiResponse<T>> {
    return this.request<T>(path, { method: "DELETE" });
  }
}

export const apiClient = new ApiClient();

// ---------------------------------------------------------------------------
// Resource APIs
// ---------------------------------------------------------------------------

export const agentsApi = {
  list: () => apiClient.get<AgentListResponse>("/agents"),
  get: (id: string) => apiClient.get<Agent>(`/agents/${id}`),
  create: (
    agent_id: string,
    config?: Record<string, unknown>,
  ) => apiClient.post<Agent>("/agents", { agent_id, config }),
  delete: (id: string) =>
    apiClient.delete<void>(`/agents/${id}`),
};

export const sessionsApi = {
  list: () => apiClient.get<SessionListResponse>("/sessions"),
  preview: (path: string, limit = 50) =>
    apiClient.get<SessionPreviewResponse>(
      `/sessions/${encodeURIComponent(path)}/messages?limit=${limit}`,
    ),
  create: (req: SessionCreateRequest) =>
    apiClient.post<SessionCreateResponse>("/sessions", req),
  delete: (path: string) =>
    apiClient.delete<void>(
      `/sessions/${encodeURIComponent(path)}`,
    ),
};

export const configApi = {
  get: () => apiClient.get<ConfigResponse>("/config"),
  patch: (patch: Record<string, unknown>) =>
    apiClient.patch<ConfigResponse>("/config", { patch }),
};

export const channelsApi = {
  list: () => apiClient.get<ChannelListResponse>("/channels"),
  get: (id: string) =>
    apiClient.get<ChannelResponse>(`/channels/${id}`),
  catalog: () => apiClient.get<ChannelCatalogEntry[]>("/channels/catalog"),
};

export const modelsApi = {
  list: () => apiClient.get<ModelListResponse>("/models"),
  get: (id: string) =>
    apiClient.get<ModelResponse>(`/models/${encodeURIComponent(id)}`),
};

export const devicesApi = {
  list: () => apiClient.get<DeviceListResponse>("/devices"),
  approve: (id: string, req?: DeviceApproveRequest) =>
    apiClient.post<void>(`/devices/${encodeURIComponent(id)}/approve`, req ?? {}),
  remove: (id: string) =>
    apiClient.delete<void>(`/devices/${encodeURIComponent(id)}`),
};

export const skillsApi = {
  list: () => apiClient.get<SkillListResponse>("/skills"),
  search: (query: string) =>
    apiClient.get<SkillSearchResponse>(`/skills/search?q=${encodeURIComponent(query)}`),
  install: (skillId: string) =>
    apiClient.post<Skill>("/skills/install", { skill_id: skillId }),
  remove: (id: string) =>
    apiClient.delete<void>(`/skills/${encodeURIComponent(id)}`),
  run: (id: string, args?: Record<string, unknown>) =>
    apiClient.post<SkillRunResponse>(`/skills/${encodeURIComponent(id)}/run`, { args }),
};

export const mcpApi = {
  status: () => apiClient.get<McpStatusResponse>("/mcp"),
  tools: (serverId: string) =>
    apiClient.get<ToolListResponse>(`/mcp/${encodeURIComponent(serverId)}/tools`),
};

export const authApi = {
  status: () => apiClient.get<AuthStatusResponse>("/auth/status"),
  login: (req: AuthLoginRequest) =>
    apiClient.post<AuthProviderStatus>("/auth/login", req),
  logout: (req: AuthLogoutRequest) =>
    apiClient.post<void>("/auth/logout", req),
};

// ---------------------------------------------------------------------------
// New P1 endpoints
// ---------------------------------------------------------------------------

export const cronApi = {
  list: () => apiClient.get<CronListResponse>("/cron"),
  create: (job: CronJobCreate) =>
    apiClient.post<CronCreateResponse>("/cron", job),
  toggle: (id: string, enabled: boolean) =>
    apiClient.patch<{ ok: boolean; enabled: boolean }>(`/cron/${id}`, { enabled }),
  remove: (id: string) =>
    apiClient.delete<void>(`/cron/${id}`),
};

export const plansApi = {
  list: () => apiClient.get<PlanListResponse>("/plans"),
  get: (id: string) =>
    apiClient.get<Plan>(`/plans/${id}`),
  resume: (id: string) =>
    apiClient.post<PlanResumeResponse>(`/plans/${id}/resume`, {}),
  remove: (id: string) =>
    apiClient.delete<PlanDeleteResponse>(`/plans/${id}`),
};

export const usageApi = {
  stats: (range = "7d") =>
    apiClient.get<UsageStats>(`/usage/stats?range=${range}`),
  daily: (range = "7d") =>
    apiClient.get<UsageDailyResponse>(`/usage/daily?range=${range}`),
  hourly: (range = "7d") =>
    apiClient.get<UsageHourlyResponse>(`/usage/hourly?range=${range}`),
  savings: () =>
    apiClient.get<TokenSavingsResponse>("/usage/savings"),
};

export const backupApi = {
  export: () =>
    apiClient.post<BackupExportResponse>("/backup/export", {}),
  status: () =>
    apiClient.get<BackupStatusResponse>("/backup/status"),
};

export const logsApi = {
  tail: (limit = 200, json = false) =>
    apiClient.get<LogsTailResponse>(`/logs/tail?limit=${limit}&json=${json}`),
};
