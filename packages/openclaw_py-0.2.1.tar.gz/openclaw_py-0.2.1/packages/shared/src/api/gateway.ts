/**
 * Singleton WebSocket manager for the PyClaw Gateway.
 *
 * Single shared connection shared across all pages via the Zustand store.
 * Previous architecture had each page calling useGatewayWebSocket() which
 * created independent connections and reconnection loops — causing 50+
 * parallel reconnection attempts when the gateway is down.
 */

import { generateId } from "../utils/uuid";
import { getWebSocketUrl } from "../utils/env";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface PendingCall {
  resolve: (value: unknown) => void;
  reject: (error: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

export interface StreamCallbacks {
  onDelta: (delta: string) => void;
  onToolStart?: (name: string, toolId: string) => void;
  onToolEnd?: (
    name: string,
    result: unknown,
    error?: string,
  ) => void;
}

export type ConnectionState =
  | "connecting"
  | "connected"
  | "disconnected";

export interface GatewayActions {
  connect: () => void;
  disconnect: () => void;
  call: <T>(
    method: string,
    params: Record<string, unknown>,
  ) => Promise<T>;
  streamChat: (
    sessionId: string,
    message: string,
    callbacks: StreamCallbacks,
  ) => Promise<void>;
}

// ---------------------------------------------------------------------------
// State change callback (wired to Zustand store)
// ---------------------------------------------------------------------------

let onStateChange:
  | ((state: ConnectionState) => void)
  | null = null;

export function setOnStateChange(
  cb: (state: ConnectionState) => void,
): void {
  onStateChange = cb;
}

// ---------------------------------------------------------------------------
// Singleton instance
// ---------------------------------------------------------------------------

let ws: WebSocket | null = null;
let reconnectCount = 0;
const pendingCalls = new Map<string, PendingCall>();
const streamHandlers = new Map<string, (event: MessageEvent) => void>();

const RECONNECT_ATTEMPTS = 5;
const RECONNECT_INTERVAL = 1000;
const CALL_TIMEOUT = 30_000;

// ---------------------------------------------------------------------------
// Message router
// ---------------------------------------------------------------------------

function handleMessage(event: MessageEvent): void {
  try {
    const msg = JSON.parse(event.data);

    // RPC response matching
    if (msg.id && pendingCalls.has(msg.id)) {
      const { resolve, reject, timer } = pendingCalls.get(msg.id)!;
      clearTimeout(timer);
      pendingCalls.delete(msg.id);
      if (msg.error) {
        reject(new Error(msg.error.message || "Unknown error"));
      } else {
        resolve(msg.result || msg.payload);
      }
      return;
    }

    // Stream handler (e.g. chat)
    const handlerKey = msg.callId || msg.id;
    const streamHandler = streamHandlers.get(handlerKey);
    if (streamHandler) {
      streamHandler(event);
      return;
    }
  } catch {
    // Invalid JSON, ignore
  }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export const gateway: GatewayActions = {
  connect(): void {
    // Don't create a new connection if one is already open or connecting
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
      // Re-attach message handler in case it was cleared (React Strict Mode)
      ws.onmessage = handleMessage;
      return;
    }
    onStateChange?.("connecting");

    // Clean up any existing closed connection
    if (ws) {
      ws.onopen = null;
      ws.onclose = null;
      ws.onerror = null;
      ws.onmessage = null;
      ws = null;
    }

    const wsUrl = getWebSocketUrl();
    ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      reconnectCount = 0;
      // Send connect message for authentication (required by gateway protocol v3)
      const connectId = generateId();
      ws?.send(
        JSON.stringify({
          type: "req",
          id: connectId,
          method: "connect",
          params: {
            minProtocol: 3,
            maxProtocol: 3,
            clientName: "pyclaw-web",
          },
        }),
      );
      onStateChange?.("connected");
    };

    ws.onclose = () => {
      onStateChange?.("disconnected");

      if (reconnectCount < RECONNECT_ATTEMPTS) {
        reconnectCount++;
        setTimeout(
          gateway.connect,
          RECONNECT_INTERVAL * reconnectCount,
        );
      }
    };

    ws.onerror = () => {
      // onclose will fire after this
    };

    ws.onmessage = handleMessage;
  },

  disconnect(): void {
    reconnectCount = RECONNECT_ATTEMPTS; // prevent reconnect
    ws?.close();
    ws = null;
  },

  call<T>(
    method: string,
    params: Record<string, unknown>,
  ): Promise<T> {
    return new Promise((resolve, reject) => {
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        reject(new Error("WebSocket not connected"));
        return;
      }

      const id = generateId();
      const timer = setTimeout(() => {
        pendingCalls.delete(id);
        reject(new Error(`RPC call '${method}' timeout`));
      }, CALL_TIMEOUT);

      pendingCalls.set(id, {
        resolve: resolve as (v: unknown) => void,
        reject,
        timer,
      });
      ws.send(JSON.stringify({ type: "req", id, method, params }));
    });
  },

  streamChat(
    sessionId: string,
    message: string,
    callbacks: StreamCallbacks,
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        reject(new Error("WebSocket not connected"));
        return;
      }

      const callId = generateId();

      const handler = (event: MessageEvent) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.id !== callId && msg.callId !== callId) return;

          // Backend sends: { type: "event", event: "chat.message_update", payload: {...} }
          // So we prefer msg.event over msg.type when type is "event"
          const msgType = msg.type === "event" ? msg.event : (msg.type || msg.event);

          // Handle both old and new event naming conventions
          if (msgType === "chat.delta" || msgType === "delta" || msgType === "chat.message_update") {
            const deltaContent = msg.delta || msg.payload?.delta || "";
            callbacks.onDelta(deltaContent);
          } else if (
            msgType === "chat.toolCall" ||
            msgType === "tool_start" ||
            msgType === "chat.tool_start"
          ) {
            callbacks.onToolStart?.(
              msg.name || msg.payload?.name,
              msg.toolCallId || msg.payload?.toolCallId || "",
            );
          } else if (
            msgType === "chat.toolResult" ||
            msgType === "tool_end"
          ) {
            callbacks.onToolEnd?.(
              msg.name || msg.payload?.name || "",
              msg.result || msg.payload?.result,
              msg.error || msg.payload?.error,
            );
          } else if (
            msgType === "chat.complete" ||
            msgType === "done" ||
            msgType === "chat.agent_end"
          ) {
            streamHandlers.delete(callId);
            resolve();
          } else if (
            msgType === "chat.error" ||
            msgType === "error"
          ) {
            streamHandlers.delete(callId);
            reject(
              new Error(
                msg.error ||
                  msg.payload?.error ||
                  "Unknown error",
              ),
            );
          }
        } catch {
          // Invalid message, ignore
        }
      };

      streamHandlers.set(callId, handler);
      ws.send(
        JSON.stringify({
          type: "req",
          id: callId,
          method: "chat.send",
          params: { sessionId, message },
        }),
      );
    });
  },
};
