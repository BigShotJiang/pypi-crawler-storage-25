/**
 * React hook that exposes the shared Gateway WebSocket connection.
 *
 * IMPORTANT: This hook does NOT create a new connection — it reads state
 * from the Zustand store (fed by the singleton GatewayProvider) and
 * delegates operations to the module-level `gateway` singleton.
 *
 * Pages should no longer call `useEffect(() => connect(), [])`.
 * The connection is established once by GatewayProvider in the app root.
 */

import { useAppStore } from "../store";
import { gateway } from "./gateway";

export interface UseGatewayWebSocketResult {
  connected: boolean;
  connectionState: "connecting" | "connected" | "disconnected";
  connect: () => void;
  disconnect: () => void;
  call: <T>(
    method: string,
    params: Record<string, unknown>,
  ) => Promise<T>;
  streamChat: (
    sessionId: string,
    message: string,
    onDelta: (delta: string) => void,
    onToolStart?: (name: string, toolId: string) => void,
    onToolEnd?: (
      name: string,
      result: unknown,
      error?: string,
    ) => void,
  ) => Promise<void>;
}

export function useGatewayWebSocket(): UseGatewayWebSocketResult {
  const connected = useAppStore((s) => s.gatewayConnected);
  const connectionState = useAppStore((s) => s.gatewayState);

  return {
    connected,
    connectionState,
    connect: gateway.connect,
    disconnect: gateway.disconnect,
    call: gateway.call,
    streamChat(sessionId, message, onDelta, onToolStart, onToolEnd) {
      return gateway.streamChat(sessionId, message, {
        onDelta,
        onToolStart,
        onToolEnd,
      });
    },
  };
}
