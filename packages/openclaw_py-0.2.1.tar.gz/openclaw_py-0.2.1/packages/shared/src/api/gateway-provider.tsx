/**
 * GatewayProvider — initialises the singleton WebSocket connection once
 * at app mount and keeps the Zustand store in sync.
 *
 * Place inside <Providers> so every page shares one connection.
 */

"use client";

import { useEffect, useRef } from "react";

import {
  gateway,
  setOnStateChange,
} from "./gateway";
import { useAppStore } from "../store";

export function GatewayProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const setGatewayState = useAppStore((s) => s.setGatewayState);
  const isConnectedRef = useRef(false);

  useEffect(() => {
    // Wire state changes from the singleton → Zustand store
    setOnStateChange(setGatewayState);

    // Connect on mount
    gateway.connect();

    // Don't disconnect on cleanup - let the connection persist
    // React Strict Mode will call cleanup then re-run effect
    // gateway.connect() handles re-attaching handlers correctly
  }, [setGatewayState]);

  return <>{children}</>;
}
