/**
 * Type declarations for optional platform-specific dependencies.
 *
 * These modules are dynamically imported and may not be installed
 * in all environments (web, desktop, mobile). We declare them
 * here so TypeScript doesn't error during compilation.
 */

declare module "@tauri-apps/plugin-store" {
  export class Store {
    static load(path: string): Promise<Store>;
    get<T = unknown>(key: string): Promise<T | undefined>;
    set(key: string, value: unknown): Promise<void>;
    delete(key: string): Promise<boolean>;
  }
}

declare module "@react-native-async-storage/async-storage" {
  const AsyncStorage: {
    getItem(key: string): Promise<string | null>;
    setItem(key: string, value: string): Promise<void>;
    removeItem(key: string): Promise<void>;
  };
  export default AsyncStorage;
}
