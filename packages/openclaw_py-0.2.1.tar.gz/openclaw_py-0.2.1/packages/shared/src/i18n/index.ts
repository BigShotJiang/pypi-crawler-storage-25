/**
 * Basic i18n with en / zh-CN locales.
 *
 * Usage:
 *   import { t } from "@pyclaw/shared";
 *   t("nav.agents")          // "Agents" (en)
 *   t("chat.send")           // "Send" (en)
 *   t("greeting", { name })  // "Hello, {name}"
 */

interface TranslationDict {
  [key: string]: string | TranslationDict;
}

const translations: Record<string, TranslationDict> = {
  en: {
    "app.name": "PyClaw",
    "nav.dashboard": "Dashboard",
    "nav.agents": "Agents",
    "nav.sessions": "Sessions",
    "nav.settings": "Settings",
    "chat.placeholder": "Type a message...",
    "chat.send": "Send",
    "common.save": "Save",
    "common.cancel": "Cancel",
    "error.connection": "Connection lost",
  },
  "zh-CN": {
    "app.name": "PyClaw",
    "nav.dashboard": "\u4eea\u8868\u76d8",
    "nav.agents": "\u667a\u80fd\u4f53",
    "nav.sessions": "\u4f1a\u8bdd",
    "nav.settings": "\u8bbe\u7f6e",
    "chat.placeholder": "\u8f93\u5165\u6d88\u606f...",
    "chat.send": "\u53d1\u9001",
    "common.save": "\u4fdd\u5b58",
    "common.cancel": "\u53d6\u6d88",
    "error.connection": "\u8fde\u63a5\u65ad\u5f00",
  },
};

let currentLocale = "en";

/** Set the active locale (e.g. "en" or "zh-CN"). */
export function setLocale(locale: string): void {
  currentLocale = locale;
}

/** Get the currently active locale. */
export function getLocale(): string {
  return currentLocale;
}

/**
 * Translate a dot-separated key, with optional interpolation.
 *
 * First tries a direct (flat) key match, then falls back to
 * nested dot-path lookup for hierarchical translations.
 *
 * @param key  - Dot-separated path, e.g. "nav.agents"
 * @param params - Optional `{ name }` for `{name}` placeholders
 * @returns Translated string, or the raw key if not found
 */
export function t(
  key: string,
  params?: Record<string, string>,
): string {
  const dict = translations[currentLocale];

  // Try direct key first (flat keys like "app.name")
  if (dict && key in dict && typeof dict[key] === "string") {
    const value = dict[key] as string;
    if (params) {
      return value.replace(
        /\{(\w+)\}/g,
        (_: string, name: string) =>
          params[name] ?? `{${name}}`,
      );
    }
    return value;
  }

  // Fallback: nested dot-path lookup
  const keys = key.split(".");
  let result: unknown = dict;

  for (const k of keys) {
    if (
      result &&
      typeof result === "object" &&
      k in result
    ) {
      result = (result as Record<string, unknown>)[k];
    } else {
      result = undefined;
      break;
    }
  }

  if (typeof result !== "string") return key;

  if (params) {
    return result.replace(
      /\{(\w+)\}/g,
      (_: string, name: string) =>
        params[name] ?? `{${name}}`,
    );
  }
  return result;
}

/** List all available locale codes. */
export function getAvailableLocales(): string[] {
  return Object.keys(translations);
}
