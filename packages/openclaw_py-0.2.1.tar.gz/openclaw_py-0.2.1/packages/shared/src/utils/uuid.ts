/**
 * UUID generation helpers.
 *
 * Uses the `uuid` package for RFC 4122 v4 UUIDs.
 */

import { v4 as uuidv4 } from "uuid";

/** Generate a short 12-char hex ID (no dashes). */
export function generateId(): string {
  return uuidv4().replace(/-/g, "").slice(0, 12);
}

/** Generate a full RFC 4122 v4 UUID. */
export function generateFullId(): string {
  return uuidv4();
}
