/**
 * Platform detection and API URL helpers.
 *
 * Supports Tauri (desktop), React Native (mobile), and browser (web).
 */

export const platform = {
  isTauri:
    typeof window !== "undefined" && "__TAURI__" in window,
  isReactNative:
    typeof navigator !== "undefined" &&
    navigator.product === "ReactNative",
  isBrowser:
    typeof window !== "undefined" && !("__TAURI__" in window),
  isWeb: typeof window !== "undefined",
};

/** Resolve the REST API base URL based on runtime environment. */
export function getApiBaseUrl(): string {
  if (
    typeof process !== "undefined" &&
    process.env?.NEXT_PUBLIC_API_URL
  ) {
    return process.env.NEXT_PUBLIC_API_URL;
  }
  if (platform.isTauri) return "http://localhost:8765";
  if (platform.isReactNative) {
    return (
      (typeof process !== "undefined" &&
        process.env?.EXPO_PUBLIC_API_URL) ||
      "http://localhost:8765"
    );
  }
  if (
    typeof process !== "undefined" &&
    process.env?.NODE_ENV === "development"
  ) {
    return "http://localhost:8765";
  }
  return "";
}

/** Resolve the WebSocket URL from the API base URL. */
export function getWebSocketUrl(): string {
  const baseUrl = getApiBaseUrl();
  if (!baseUrl) return "ws://localhost:8765";
  return baseUrl.replace(/^http/, "ws");
}
