/**
 * State persistence for AppStore.
 *
 * Persists a subset of UI state (sidebar open/close, etc.) to
 * the cross-platform storage adapter so it survives app restarts.
 */

import { getStorage } from "../utils/storage";
import { useAppStore } from "./index";

const PERSIST_KEY = "pyclaw-app-state";

/** Load persisted state from storage into the store. */
export async function loadPersistedState(): Promise<void> {
  const storage = await getStorage();
  const saved = await storage.getItem(PERSIST_KEY);
  if (saved) {
    try {
      useAppStore.setState(JSON.parse(saved));
    } catch {
      console.warn("Failed to parse persisted state");
    }
  }
}

/** Subscribe to store changes and persist selected fields. */
export function setupPersistence(): void {
  useAppStore.subscribe((state) => {
    const partial = { sidebarOpen: state.sidebarOpen };
    getStorage()
      .then((storage) =>
        storage.setItem(PERSIST_KEY, JSON.stringify(partial)),
      )
      .catch(() => {
        /* silently ignore persistence errors */
      });
  });
}
