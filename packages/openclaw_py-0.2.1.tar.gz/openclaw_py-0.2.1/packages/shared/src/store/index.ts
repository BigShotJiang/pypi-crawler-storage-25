/**
 * AppStore — global UI state managed via Zustand.
 */

import { create } from "zustand";

interface AppState {
  gatewayConnected: boolean;
  gatewayState: "connecting" | "connected" | "disconnected";
  setGatewayState: (
    state: "connecting" | "connected" | "disconnected",
  ) => void;

  currentSessionId: string | null;
  setCurrentSession: (id: string | null) => void;

  selectedAgentId: string | null;
  setSelectedAgent: (id: string | null) => void;

  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
}

export const useAppStore = create<AppState>()((set) => ({
  gatewayConnected: false,
  gatewayState: "disconnected",
  setGatewayState: (state) =>
    set({
      gatewayState: state,
      gatewayConnected: state === "connected",
    }),

  currentSessionId: null,
  setCurrentSession: (id) =>
    set({ currentSessionId: id }),

  selectedAgentId: null,
  setSelectedAgent: (id) =>
    set({ selectedAgentId: id }),

  sidebarOpen: true,
  toggleSidebar: () =>
    set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));
