/**
 * ChatStore — message state for the active chat session.
 *
 * Manages streaming content accumulation, tool-call tracking,
 * and message history for the current conversation.
 */

import { create } from "zustand";

import { generateId } from "../utils/uuid";
import type { ChatMessage, ToolCallInfo } from "../types/chat";

interface ChatState {
  messages: ChatMessage[];
  isStreaming: boolean;
  streamingContent: string;
  streamingToolCalls: ToolCallInfo[];

  addUserMessage: (content: string) => void;
  startAssistantStream: () => void;
  appendDelta: (delta: string) => void;
  addToolCall: (toolCall: ToolCallInfo) => void;
  updateToolCall: (
    id: string,
    update: Partial<ToolCallInfo>,
  ) => void;
  finishStream: () => void;
  finishStreamWithError: (error: string) => void;
  clearMessages: () => void;
  loadMessages: (messages: ChatMessage[]) => void;
}

export const useChatStore = create<ChatState>(
  (set, _get) => ({
    messages: [],
    isStreaming: false,
    streamingContent: "",
    streamingToolCalls: [],

    addUserMessage: (content) =>
      set((state) => ({
        messages: [
          ...state.messages,
          {
            id: generateId(),
            role: "user",
            content,
            timestamp: Date.now(),
          },
        ],
      })),

    startAssistantStream: () =>
      set({
        isStreaming: true,
        streamingContent: "",
        streamingToolCalls: [],
      }),

    appendDelta: (delta) =>
      set((state) => ({
        streamingContent: state.streamingContent + delta,
      })),

    addToolCall: (toolCall) =>
      set((state) => ({
        streamingToolCalls: [
          ...state.streamingToolCalls,
          toolCall,
        ],
      })),

    updateToolCall: (id, update) =>
      set((state) => ({
        streamingToolCalls: state.streamingToolCalls.map(
          (tc) => (tc.id === id ? { ...tc, ...update } : tc),
        ),
      })),

    finishStream: () =>
      set((state) => ({
        isStreaming: false,
        messages: [
          ...state.messages,
          {
            id: generateId(),
            role: "assistant",
            content: state.streamingContent,
            timestamp: Date.now(),
            toolCalls:
              state.streamingToolCalls.length > 0
                ? state.streamingToolCalls
                : undefined,
          },
        ],
        streamingContent: "",
        streamingToolCalls: [],
      })),

    finishStreamWithError: (error) =>
      set((state) => ({
        isStreaming: false,
        messages: [
          ...state.messages,
          {
            id: generateId(),
            role: "assistant",
            content: `Error: ${error}`,
            timestamp: Date.now(),
          },
        ],
        streamingContent: "",
        streamingToolCalls: [],
      })),

    clearMessages: () =>
      set({
        messages: [],
        streamingContent: "",
        streamingToolCalls: [],
      }),

    loadMessages: (messages) => set({ messages }),
  }),
);
