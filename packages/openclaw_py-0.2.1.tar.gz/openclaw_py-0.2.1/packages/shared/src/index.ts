/**
 * @pyclaw/shared — Shared types, API client, stores, and utilities.
 *
 * This package contains:
 * - Type definitions aligned with the Python backend REST and WebSocket APIs
 * - REST API client with typed resource methods
 * - WebSocket hook with streaming chat support
 * - React Query hooks for data fetching
 * - Zustand stores (AppStore, ChatStore)
 * - Cross-platform utilities (env, UUID, storage)
 * - i18n with en / zh-CN locales
 *
 * Usage:
 *   import { Agent, useAgentsList, useAppStore, t } from "@pyclaw/shared";
 *   import type { EventFrame } from "@pyclaw/shared/types";
 */

export * from "./types/index";
export * from "./api/index";
export * from "./store/index";
export * from "./utils/index";
export { useChatStore } from "./store/chat";
export {
  loadPersistedState,
  setupPersistence,
} from "./store/persist";
export {
  t,
  setLocale,
  getLocale,
  getAvailableLocales,
} from "./i18n";
