/**
 * Auth type definitions.
 *
 * Aligned with Python backend: src/pyclaw/gateway/rest/models/auth.py
 */

/** Auth provider status. */
export interface AuthProviderStatus {
  provider: string;
  authenticated: boolean;
  has_api_key: boolean;
  base_url: string | null;
  models_count: number;
  label: string | null;
}

/** Response for auth status. */
export interface AuthStatusResponse {
  providers: AuthProviderStatus[];
  default_provider: string | null;
}

/** Request for login. */
export interface AuthLoginRequest {
  provider: string;
  api_key: string;
  base_url?: string;
}

/** Request for logout. */
export interface AuthLogoutRequest {
  provider: string;
}
