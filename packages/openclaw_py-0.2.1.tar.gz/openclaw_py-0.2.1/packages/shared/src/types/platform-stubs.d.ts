/**
 * Ambient type stubs for optional platform-specific dependencies.
 *
 * These modules are dynamically imported at runtime only on their
 * respective platforms, but TypeScript still needs type declarations
 * to resolve the imports during type-checking.
 */

declare module "@tauri-apps/plugin-store" {
  export class Store {
    static load(path: string): Promise<Store>;
    get(key: string): Promise<unknown>;
    set(key: string, value: string): Promise<void>;
    delete(key: string): Promise<boolean>;
  }
}

declare module "@react-native-async-storage/async-storage" {
  const AsyncStorage: {
    getItem: (key: string) => Promise<string | null>;
    setItem: (key: string, value: string) => Promise<void>;
    removeItem: (key: string) => Promise<void>;
  };
  export default AsyncStorage;
}
