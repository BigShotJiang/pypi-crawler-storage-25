/**
 * Model type definitions.
 *
 * Aligned with Python backend: src/pyclaw/gateway/rest/models/model.py
 */

/** Model capabilities. */
export interface ModelCapabilities {
  vision: boolean;
  tools: boolean;
  streaming: boolean;
  reasoning: boolean;
  audio: boolean;
}

/** Model pricing info. */
export interface ModelPricing {
  input_per_million: number | null;
  output_per_million: number | null;
  currency: string;
}

/** A single model. */
export interface Model {
  id: string;
  name: string;
  provider: string;
  aliases: string[];
  capabilities: ModelCapabilities | null;
  pricing: ModelPricing | null;
  context_window: number | null;
  max_output: number | null;
  status: "available" | "unavailable" | "deprecated";
  owned_by: string | null;
}

/** Response for listing models. */
export interface ModelListResponse {
  models: Model[];
  default_model: string | null;
}

/** Response for single model. */
export interface ModelResponse {
  model: Model;
}
