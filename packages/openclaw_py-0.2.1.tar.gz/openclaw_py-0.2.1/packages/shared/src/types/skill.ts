/**
 * Skill type definitions.
 *
 * Aligned with Python backend: src/pyclaw/gateway/rest/models/skill.py
 */

/** Skill status. */
export type SkillStatus = "installed" | "available" | "updating" | "error";

/** Skill metadata. */
export interface SkillMeta {
  version: string;
  author: string | null;
  description: string | null;
  homepage: string | null;
  license: string | null;
  tags: string[];
}

/** A single skill. */
export interface Skill {
  id: string;
  name: string;
  status: SkillStatus;
  meta: SkillMeta | null;
  installed_at: string | null;
  last_updated: string | null;
  dependencies: string[];
  tools: string[];
  config_schema: Record<string, unknown> | null;
}

/** Response for listing skills. */
export interface SkillListResponse {
  skills: Skill[];
  updates_available: number;
}

/** Response for searching skills. */
export interface SkillSearchResponse {
  results: Skill[];
  total: number;
  query: string;
}

/** Response for running a skill. */
export interface SkillRunResponse {
  success: boolean;
  output: string | null;
  error: string | null;
}
