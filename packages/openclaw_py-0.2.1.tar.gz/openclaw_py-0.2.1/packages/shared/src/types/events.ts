/**
 * WebSocket event type definitions.
 *
 * Aligned with Python backend:
 * - Event names: src/pyclaw/gateway/events.py
 * - Protocol frames: src/pyclaw/gateway/protocol/frames.py
 *
 * The Python gateway uses protocol v3 frames:
 *   event → { type: "event", event: "<name>", payload?, seq?, stateVersion? }
 *
 * Event names follow the pattern: `<domain>.<action>` (e.g. "chat.delta").
 */

// ---------------------------------------------------------------------------
// Protocol frame types
// ---------------------------------------------------------------------------

/** Error shape in response frames. Matches Python ErrorShape. */
export interface ErrorShape {
  code: string;
  message: string;
  details?: unknown;
  retryable?: boolean | null;
  retryAfterMs?: number | null;
}

/** WebSocket request frame. Matches Python RequestFrame. */
export interface RequestFrame {
  type: "req";
  id: string;
  method: string;
  params?: Record<string, unknown>;
}

/** WebSocket response frame. Matches Python ResponseFrame. */
export interface ResponseFrame {
  type: "res";
  id: string;
  ok: boolean;
  payload?: unknown;
  error?: ErrorShape;
}

/** WebSocket event frame. Matches Python EventFrame. */
export interface EventFrame {
  type: "event";
  event: string;
  payload?: unknown;
  seq?: number;
  stateVersion?: number;
}

// ---------------------------------------------------------------------------
// Event name constants — from events.py
// ---------------------------------------------------------------------------

export type WebSocketEventType =
  // Chat / agent
  | "chat.message"
  | "chat.delta"
  | "chat.toolCall"
  | "chat.toolResult"
  | "chat.complete"
  | "chat.error"
  | "chat.abort"
  // Agent state
  | "agent.state"
  | "agent.started"
  | "agent.stopped"
  | "agent.error"
  // Presence
  | "presence"
  // Health / heartbeat
  | "health"
  | "heartbeat"
  // Shutdown
  | "shutdown"
  // Cron
  | "cron.fired"
  | "cron.updated"
  // Device pairing
  | "node.pair.request"
  | "node.pair.complete"
  | "node.pair.rejected"
  | "device.pair.request"
  | "device.pair.complete"
  // Exec approval
  | "exec.approval.request"
  | "exec.approval.granted"
  | "exec.approval.denied"
  // Progress
  | "progress"
  // Updates
  | "update_available"
  // Session
  | "session.created"
  | "session.deleted";

// ---------------------------------------------------------------------------
// Event payload types — from events.py payload builders
// ---------------------------------------------------------------------------

/** Chat streaming delta. */
export interface ChatDeltaEvent {
  type: "chat.delta";
  delta: string;
  /** Which runner produced this event. */
  runner?: "embedded" | "legacy";
}

/** Chat completion. */
export interface ChatCompleteEvent {
  type: "chat.complete";
  completed: boolean;
}

/** Chat error. */
export interface ChatErrorEvent {
  type: "chat.error";
  error: string;
}

/** Tool call started. */
export interface ToolCallEvent {
  type: "chat.toolCall";
  name: string;
  toolCallId: string;
  runner?: "embedded" | "legacy";
}

/** Tool call result. */
export interface ToolResultEvent {
  type: "chat.toolResult";
  name: string;
  toolCallId: string;
  result?: unknown;
  error?: string;
  runner?: "embedded" | "legacy";
}

/** Agent state change. Matches agent_state_payload(). */
export interface AgentStateEvent {
  type: "agent.state";
  agentId: string;
  state: string;
  sessionId?: string;
  model?: string;
}

/** Agent started. */
export interface AgentStartedEvent {
  type: "agent.started";
  agentId: string;
}

/** Agent stopped. */
export interface AgentStoppedEvent {
  type: "agent.stopped";
  agentId: string;
}

/** Agent error. */
export interface AgentErrorEvent {
  type: "agent.error";
  agentId: string;
  error: string;
}

/** Presence update. Matches presence_payload(). */
export interface PresenceEvent {
  type: "presence";
  online: boolean;
  channels?: string[];
  uptimeSeconds?: number;
}

/** Shutdown notification. Matches shutdown_payload(). */
export interface ShutdownEvent {
  type: "shutdown";
  reason: string;
  graceSeconds: number;
  timestamp: number;
}

/** Health status. Matches health_payload(). */
export interface HealthEvent {
  type: "health";
  status: string;
  uptimeSeconds: number;
  connections: number;
  agentsActive: number;
}

/** Heartbeat. Matches heartbeat_payload(). */
export interface HeartbeatEvent {
  type: "heartbeat";
  seq: number;
  timestamp: number;
}

/** Cron job fired. Matches cron_fired_payload(). */
export interface CronFiredEvent {
  type: "cron.fired";
  jobName: string;
  systemEvent: string;
  firedAt: number;
}

/** Exec approval request. Matches exec_approval_payload(). */
export interface ExecApprovalRequestEvent {
  type: "exec.approval.request";
  approvalId: string;
  command: string;
  agentId: string;
  sessionId: string;
  requestedAt: number;
}

/** Exec approval granted. */
export interface ExecApprovalGrantedEvent {
  type: "exec.approval.granted";
  approvalId: string;
}

/** Exec approval denied. */
export interface ExecApprovalDeniedEvent {
  type: "exec.approval.denied";
  approvalId: string;
}

/** Update available. Matches update_available_payload(). */
export interface UpdateAvailableEvent {
  type: "update_available";
  currentVersion: string;
  latestVersion: string;
  url: string;
}

/** Session created event. */
export interface SessionCreatedEvent {
  type: "session.created";
  id: string;
}

/** Session deleted event. */
export interface SessionDeletedEvent {
  type: "session.deleted";
  id: string;
}

/** Progress event — opaque payload forwarded by the gateway. */
export interface ProgressEvent {
  type: "progress";
  [key: string]: unknown;
}
