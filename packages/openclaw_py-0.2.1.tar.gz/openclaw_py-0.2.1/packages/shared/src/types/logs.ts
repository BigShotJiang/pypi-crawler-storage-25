/**
 * Logs types for the REST API.
 */

export interface LogLine {
  time: string;
  line: string;
}

export interface LogsTailResponse {
  lines: string[] | LogLine[];
  count: number;
  path: string;
}
