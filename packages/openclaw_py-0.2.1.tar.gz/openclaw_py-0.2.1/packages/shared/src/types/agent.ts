/**
 * Agent type definitions.
 *
 * Aligned with Python backend: src/pyclaw/gateway/rest/models/agent.py
 * - AgentResponse → Agent
 * - AgentCreate → AgentCreateRequest
 * - AgentListResponse → AgentListResponse
 */

/** Agent configuration — matches Python dict field. */
export interface AgentConfig {
  name?: string;
  model?: string;
  provider?: string;
  system_prompt?: string;
  tools?: string[];
  [key: string]: unknown;
}

/** A single agent. Matches Python AgentResponse. */
export interface Agent {
  id: string;
  session_count: number;
  config: AgentConfig;
}

/** Request body for creating an agent. Matches Python AgentCreate. */
export interface AgentCreateRequest {
  agent_id: string;
  config?: AgentConfig | null;
}

/** Response for listing agents. Matches Python AgentListResponse. */
export interface AgentListResponse {
  agents: Agent[];
}
