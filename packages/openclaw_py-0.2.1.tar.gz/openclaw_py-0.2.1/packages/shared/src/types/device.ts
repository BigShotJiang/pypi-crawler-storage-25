/**
 * Device type definitions.
 *
 * Aligned with Python backend: src/pyclaw/gateway/rest/models/device.py
 */

/** Device status. */
export type DeviceStatus = "pending" | "approved" | "rejected" | "expired";

/** A paired device. */
export interface Device {
  id: string;
  name: string | null;
  device_type: "desktop" | "mobile" | "web" | "cli";
  status: DeviceStatus;
  last_seen: string | null;
  created_at: string;
  approved_at: string | null;
  ip_address: string | null;
  user_agent: string | null;
  metadata: Record<string, unknown> | null;
}

/** Response for listing devices. */
export interface DeviceListResponse {
  devices: Device[];
  pending_count: number;
}

/** Request for approving a device. */
export interface DeviceApproveRequest {
  name?: string;
}
