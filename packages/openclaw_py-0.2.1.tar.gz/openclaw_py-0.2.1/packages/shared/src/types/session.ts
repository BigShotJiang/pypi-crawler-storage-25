/**
 * Session type definitions.
 *
 * Aligned with Python backend: src/pyclaw/gateway/rest/models/session.py
 * - SessionInfo → SessionInfo  (uses camelCase in Python: agentId)
 * - MessagePreview → MessagePreview
 * - SessionPreviewResponse → SessionPreviewResponse
 * - SessionCreateRequest → SessionCreateRequest
 * - SessionCreateResponse → SessionCreateResponse
 */

/** Session metadata. Matches Python SessionInfo (already camelCase). */
export interface SessionInfo {
  agentId: string;
  file: string;
  path: string;
  size: number;
}

/** Response for listing sessions. Matches Python SessionListResponse. */
export interface SessionListResponse {
  sessions: SessionInfo[];
}

/** A preview message. Matches Python MessagePreview. */
export interface MessagePreview {
  role: string;
  content: string;
}

/** Response for session message preview. Matches Python SessionPreviewResponse. */
export interface SessionPreviewResponse {
  messages: MessagePreview[];
}

/** Request to create a new session. Matches Python SessionCreateRequest. */
export interface SessionCreateRequest {
  agentId: string;
  title?: string | null;
}

/** Response after creating a session. Matches Python SessionCreateResponse. */
export interface SessionCreateResponse {
  id: string;
  title?: string | null;
}
