/**
 * Plan types for the REST API.
 */

export interface PlanStep {
  id: string;
  description: string;
  status: "pending" | "running" | "completed" | "failed";
  result?: unknown;
}

export interface Plan {
  id: string;
  name: string;
  status: "running" | "paused" | "completed" | "failed";
  created_at: string;
  updated_at: string;
  steps: PlanStep[];
}

export interface PlanListResponse {
  plans: Plan[];
  count: number;
}

export interface PlanResumeResponse {
  resumed: boolean;
  reason?: string;
}

export interface PlanDeleteResponse {
  deleted: boolean;
}
