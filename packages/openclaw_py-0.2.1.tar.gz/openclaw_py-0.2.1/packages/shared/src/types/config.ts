/**
 * Config type definitions.
 *
 * Aligned with Python backend:
 * - ConfigResponse: src/pyclaw/gateway/rest/models/config.py
 * - ChannelResponse: src/pyclaw/gateway/rest/models/channel.py
 *
 * The Python ConfigResponse.config is `dict[str, Any]`, so we model the
 * known sub-structures and allow arbitrary additional keys.
 */

/** Provider configuration within models.providers. */
export interface ProviderConfig {
  apiKey?: string;
  baseUrl?: string;
  models?: string[];
  [key: string]: unknown;
}

/** Agent defaults within agents.defaults. */
export interface AgentDefaults {
  provider?: string;
  model?: string;
  [key: string]: unknown;
}

/** Security / exec-approval configuration. */
export interface SecurityConfig {
  execApproval?: {
    mode?: "allow" | "ask" | "deny";
    allowlist?: string[];
  };
  [key: string]: unknown;
}

/** Top-level PyClaw configuration object. */
export interface PyClawConfig {
  models?: {
    providers?: Record<string, ProviderConfig>;
    [key: string]: unknown;
  };
  agents?: {
    defaults?: AgentDefaults;
    [key: string]: unknown;
  };
  channels?: Record<string, ChannelConfig>;
  security?: SecurityConfig;
  [key: string]: unknown;
}

/** Channel entry in config — lightweight vs. ChannelResponse. */
export interface ChannelConfig {
  enabled?: boolean;
  [key: string]: unknown;
}

/** Response for GET /config. Matches Python ConfigResponse. */
export interface ConfigResponse {
  config: PyClawConfig;
}

/** Request for PATCH /config. Matches Python ConfigPatchRequest. */
export interface ConfigPatchRequest {
  patch: Record<string, unknown>;
}

// ---------------------------------------------------------------------------
// Channel REST types — from channel.py
// ---------------------------------------------------------------------------

/** Channel capabilities. Matches Python ChannelCapabilities. */
export interface ChannelCapabilities {
  typing: boolean;
  reactions: boolean;
  threads: boolean;
  editing: boolean;
  deletion: boolean;
  buttons: boolean;
  pins: boolean;
  read_receipts: boolean;
}

/** Channel media limits. Matches Python ChannelMediaLimits. */
export interface ChannelMediaLimits {
  max_message_length: number | null;
  max_file_size_mb: number | null;
}

/** A single channel. Matches Python ChannelResponse. */
export interface ChannelResponse {
  id: string;
  name: string;
  running: boolean;
  enabled: boolean;
  status: string;
  source: string;
  display_name: string | null;
  category: string | null;
  color: string | null;
  icon: string | null;
  capabilities: ChannelCapabilities | null;
  media_limits: ChannelMediaLimits | null;
  supports_dm: boolean | null;
  supports_groups: boolean | null;
  metrics: Record<string, unknown> | null;
}

/** Response for listing channels. Matches Python ChannelListResponse. */
export interface ChannelListResponse {
  channels: ChannelResponse[];
}

/** Catalog entry for an available channel type. */
export interface ChannelCatalogEntry {
  type: string;
  name: string;
  category: string;
  dm: boolean;
  groups: boolean;
  reactions: boolean;
  threads: boolean;
}
