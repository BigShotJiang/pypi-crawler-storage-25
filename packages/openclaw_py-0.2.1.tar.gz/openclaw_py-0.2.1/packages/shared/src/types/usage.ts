/**
 * Usage statistics types for the REST API.
 */

export interface SessionUsage {
  id: string;
  name: string;
  tokens: number;
  input_tokens: number;
  output_tokens: number;
  calls: number;
  updated_at: string;
}

export interface UsageStats {
  total_tokens: number;
  sessions_count: number;
  cost_estimate: number;
  sessions: SessionUsage[];
  window_days: number;
}

export interface UsageDailyPoint {
  date: string;
  tokens: number;
  calls: number;
}

export interface UsageDailyResponse {
  data: UsageDailyPoint[];
}

export interface UsageHourlyPoint {
  hour: number;
  tokens: number;
  calls: number;
}

export interface UsageHourlyResponse {
  data: UsageHourlyPoint[];
}

/**
 * Token savings from token-aware features.
 */
export interface TokenSavingsLifetimeStats {
  total_sessions: number;
  total_reads: number;
  total_writes: number;
  anatomy_hits: number;
  repeated_reads_blocked: number;
}

export interface TokenSavingsResponse {
  anatomy_savings: number;
  repeat_savings: number;
  total_savings: number;
  lifetime_stats: TokenSavingsLifetimeStats;
}
