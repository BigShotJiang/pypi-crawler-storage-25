/**
 * MCP (Model Context Protocol) type definitions.
 *
 * Aligned with Python backend: src/pyclaw/gateway/rest/models/mcp.py
 */

/** MCP server status. */
export type McpServerStatus = "connected" | "disconnected" | "error" | "connecting";

/** Tool input schema (JSON Schema). */
export interface ToolSchema {
  type: string;
  properties: Record<string, unknown>;
  required?: string[];
  [key: string]: unknown;
}

/** An MCP tool. */
export interface McpTool {
  name: string;
  description: string | null;
  input_schema: ToolSchema | null;
  server_id: string;
}

/** An MCP server. */
export interface McpServer {
  id: string;
  name: string;
  status: McpServerStatus;
  transport: "stdio" | "sse" | "streamable-http";
  command: string | null;
  url: string | null;
  tool_count: number;
  error: string | null;
  connected_at: string | null;
  metadata: Record<string, unknown> | null;
}

/** Response for MCP status. */
export interface McpStatusResponse {
  servers: McpServer[];
  total_tools: number;
}

/** Response for listing tools of a server. */
export interface ToolListResponse {
  server_id: string;
  tools: McpTool[];
}
