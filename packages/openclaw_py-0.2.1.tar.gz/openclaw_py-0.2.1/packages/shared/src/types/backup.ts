/**
 * Backup types for the REST API.
 */

export interface BackupInfo {
  path: string;
  size: number;
}

export interface BackupExportResponse {
  path: string;
  files: number;
}

export interface BackupStatusResponse {
  backups: BackupInfo[];
  count: number;
}
