/**
 * Chat type definitions.
 *
 * Aligned with Python backend:
 * - Chat params: src/pyclaw/gateway/methods/chat_advanced.py (ChatParams, ChatAttachment)
 * - Chat events: src/pyclaw/gateway/methods/chat.py (event payloads)
 * - Chat history: chat.history returns { messages: [...] }
 */

/** An attachment in a chat message. Matches Python ChatAttachment. */
export interface ChatAttachment {
  filename: string;
  mime_type: string;
  size_bytes: number;
  url: string;
  base64_data: string;
  attachment_type: "file" | "image" | "audio" | "video";
}

/** Tool call information streamed during agent execution. */
export interface ToolCallInfo {
  id: string;
  name: string;
  status: "running" | "completed" | "error";
  result?: unknown;
  error?: string;
}

/** A chat message in history or stream. */
export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: number;
  toolCalls?: ToolCallInfo[];
}

/** Parameters for chat.send — matches Python ChatParams (camelCase keys in WS protocol). */
export interface ChatSendParams {
  message: string;
  agentId?: string;
  sessionId?: string;
  provider?: string;
  model?: string;
  apiKey?: string;
  baseUrl?: string;
  systemPrompt?: string;
  thinking?: string;
  abortPrevious?: boolean;
  temperature?: number | null;
  attachments?: ChatAttachment[];
}

/** Response from chat.abort. */
export interface ChatAbortResponse {
  aborted: boolean;
}

/** Response from chat.history. */
export interface ChatHistoryResponse {
  messages: Record<string, unknown>[];
}

/** Response from chat.edit / chat.resend completion. */
export interface ChatCompleteResponse {
  completed: boolean;
}
