/**
 * Cron job types for the REST API.
 */

export interface CronJob {
  id: string;
  name: string;
  schedule: string;
  schedule_type: "cron" | "interval" | "once";
  message: string;
  enabled: boolean;
  agent_id: string;
}

export interface CronJobCreate {
  name?: string;
  schedule: string;
  message: string;
  schedule_type?: "cron" | "interval" | "once";
  every_seconds?: number;
  at?: string;
  enabled?: boolean;
  agent_id?: string;
}

export interface CronListResponse {
  jobs: CronJob[];
  count: number;
}

export interface CronCreateResponse {
  job_id: string;
  ok: boolean;
}
