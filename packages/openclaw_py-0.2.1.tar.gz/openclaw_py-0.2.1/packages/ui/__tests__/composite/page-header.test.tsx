import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { PageHeader } from '../../src/composite/page-header';

describe('PageHeader', () => {
  it('renders title', () => {
    render(<PageHeader title="Dashboard" />);
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
  });

  it('renders title as h1', () => {
    render(<PageHeader title="Settings" />);
    const heading = screen.getByRole('heading', { level: 1, name: 'Settings' });
    expect(heading).toBeInTheDocument();
  });

  it('renders description when provided', () => {
    render(<PageHeader title="Agents" description="Manage your agents" />);
    expect(screen.getByText('Manage your agents')).toBeInTheDocument();
  });

  it('does not render description when not provided', () => {
    const { container } = render(<PageHeader title="Agents" />);
    const desc = container.querySelector('p');
    expect(desc).toBeNull();
  });

  it('renders icon when provided', () => {
    const icon = <svg data-testid="test-icon" />;
    render(<PageHeader title="Test" icon={icon} />);
    expect(screen.getByTestId('test-icon')).toBeInTheDocument();
  });

  it('does not render icon element when not provided', () => {
    const { container } = render(<PageHeader title="Test" />);
    // The icon wrapper div should not exist
    const iconWrapper = container.querySelector('[class*="rounded-lg"]');
    expect(iconWrapper).toBeNull();
  });

  it('renders actions when provided', () => {
    render(<PageHeader title="Test" actions={<button>Add New</button>} />);
    expect(screen.getByRole('button', { name: 'Add New' })).toBeInTheDocument();
  });

  it('does not render actions wrapper when not provided', () => {
    const { container } = render(<PageHeader title="Test" />);
    // The actions wrapper should not exist when no actions prop
    const allDivs = container.querySelectorAll('div');
    let actionsDivFound = false;
    allDivs.forEach((div) => {
      if (div.className.includes('gap-2') && div.textContent === '') {
        actionsDivFound = true;
      }
    });
    expect(actionsDivFound).toBe(false);
  });

  it('applies custom className', () => {
    const { container } = render(<PageHeader title="Test" className="extra" />);
    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper.className).toContain('extra');
  });
});
