import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { EmptyState } from '../../src/composite/empty-state';

describe('EmptyState', () => {
  it('renders title', () => {
    render(<EmptyState title="No items found" />);
    expect(screen.getByText('No items found')).toBeInTheDocument();
  });

  it('renders title as h3', () => {
    render(<EmptyState title="No data" />);
    const heading = screen.getByRole('heading', { level: 3, name: 'No data' });
    expect(heading).toBeInTheDocument();
  });

  it('renders description when provided', () => {
    render(<EmptyState title="No items" description="Add one to get started" />);
    expect(screen.getByText('Add one to get started')).toBeInTheDocument();
  });

  it('does not render description when not provided', () => {
    const { container } = render(<EmptyState title="No items" />);
    const desc = container.querySelector('p');
    expect(desc).toBeNull();
  });

  it('renders icon when provided', () => {
    const icon = <svg data-testid="test-icon" />;
    render(<EmptyState title="Empty" icon={icon} />);
    expect(screen.getByTestId('test-icon')).toBeInTheDocument();
  });

  it('does not render icon wrapper when not provided', () => {
    const { container } = render(<EmptyState title="Empty" />);
    const iconWrapper = container.querySelector('[class*="rounded-full"]');
    expect(iconWrapper).toBeNull();
  });

  it('renders action when provided', () => {
    render(<EmptyState title="Empty" action={<button>Create Item</button>} />);
    expect(screen.getByRole('button', { name: 'Create Item' })).toBeInTheDocument();
  });

  it('does not render action wrapper when not provided', () => {
    const { container } = render(<EmptyState title="Empty" />);
    const actionDiv = container.querySelector('[class*="mt-4"]');
    expect(actionDiv).toBeNull();
  });

  it('applies custom className', () => {
    const { container } = render(<EmptyState title="Empty" className="extra" />);
    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper.className).toContain('extra');
  });
});
