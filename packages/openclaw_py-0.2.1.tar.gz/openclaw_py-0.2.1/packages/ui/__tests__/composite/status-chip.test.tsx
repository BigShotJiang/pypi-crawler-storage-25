import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { StatusChip } from '../../src/composite/status-chip';

describe('StatusChip', () => {
  it('renders with default variant', () => {
    const { container } = render(<StatusChip>Default</StatusChip>);
    const chip = container.firstChild as HTMLElement;
    expect(chip.textContent).toBe('Default');
    expect(chip.className).toContain('bg-secondary');
  });

  it('renders with success variant', () => {
    const { container } = render(<StatusChip status="success">Active</StatusChip>);
    const chip = container.firstChild as HTMLElement;
    expect(chip.className).toContain('bg-green-100');
    expect(chip.className).toContain('text-green-800');
  });

  it('renders with warning variant', () => {
    const { container } = render(<StatusChip status="warning">Pending</StatusChip>);
    const chip = container.firstChild as HTMLElement;
    expect(chip.className).toContain('bg-yellow-100');
    expect(chip.className).toContain('text-yellow-800');
  });

  it('renders with error variant', () => {
    const { container } = render(<StatusChip status="error">Failed</StatusChip>);
    const chip = container.firstChild as HTMLElement;
    expect(chip.className).toContain('bg-red-100');
    expect(chip.className).toContain('text-red-800');
  });

  it('renders with info variant', () => {
    const { container } = render(<StatusChip status="info">Info</StatusChip>);
    const chip = container.firstChild as HTMLElement;
    expect(chip.className).toContain('bg-blue-100');
    expect(chip.className).toContain('text-blue-800');
  });

  it('renders as a span element', () => {
    const { container } = render(<StatusChip>Label</StatusChip>);
    const chip = container.firstChild as HTMLElement;
    expect(chip.tagName).toBe('SPAN');
  });

  it('applies custom className', () => {
    const { container } = render(<StatusChip className="extra">Custom</StatusChip>);
    const chip = container.firstChild as HTMLElement;
    expect(chip.className).toContain('extra');
  });

  it('applies base chip classes', () => {
    const { container } = render(<StatusChip>Chip</StatusChip>);
    const chip = container.firstChild as HTMLElement;
    expect(chip.className).toContain('inline-flex');
    expect(chip.className).toContain('rounded-full');
    expect(chip.className).toContain('text-xs');
  });
});
