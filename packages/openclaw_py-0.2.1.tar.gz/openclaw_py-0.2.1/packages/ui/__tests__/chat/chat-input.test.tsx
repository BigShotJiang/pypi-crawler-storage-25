import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, it, expect, vi } from 'vitest';
import { ChatInput } from '../../src/chat/chat-input';

describe('ChatInput', () => {
  it('renders with placeholder', () => {
    render(
      <ChatInput
        value=""
        onChange={() => {}}
        onSubmit={() => {}}
        placeholder="Type here..."
      />
    );
    expect(screen.getByPlaceholderText('Type here...')).toBeInTheDocument();
  });

  it('renders with default placeholder', () => {
    render(<ChatInput value="" onChange={() => {}} onSubmit={() => {}} />);
    expect(screen.getByPlaceholderText('Type a message...')).toBeInTheDocument();
  });

  it('renders the send button', () => {
    render(<ChatInput value="" onChange={() => {}} onSubmit={() => {}} />);
    expect(screen.getByRole('button', { name: 'Send message' })).toBeInTheDocument();
  });

  it('calls onChange when input changes', async () => {
    const handleChange = vi.fn();
    render(<ChatInput value="" onChange={handleChange} onSubmit={() => {}} />);
    const textarea = screen.getByPlaceholderText('Type a message...');
    await userEvent.type(textarea, 'H');
    expect(handleChange).toHaveBeenCalledWith('H');
  });

  it('calls onSubmit on Enter key', async () => {
    const handleSubmit = vi.fn();
    render(
      <ChatInput value="Hello" onChange={() => {}} onSubmit={handleSubmit} />
    );
    const textarea = screen.getByPlaceholderText('Type a message...');
    await userEvent.type(textarea, '{Enter}');
    expect(handleSubmit).toHaveBeenCalled();
  });

  it('does not submit on Shift+Enter', async () => {
    const handleSubmit = vi.fn();
    render(
      <ChatInput value="Hello" onChange={() => {}} onSubmit={handleSubmit} />
    );
    const textarea = screen.getByPlaceholderText('Type a message...');
    await userEvent.type(textarea, '{Shift>}{Enter}{/Shift}');
    expect(handleSubmit).not.toHaveBeenCalled();
  });

  it('disables textarea and button when disabled prop is set', () => {
    render(<ChatInput value="" onChange={() => {}} onSubmit={() => {}} disabled />);
    const textarea = screen.getByPlaceholderText('Type a message...');
    const button = screen.getByRole('button', { name: 'Send message' });
    expect(textarea).toBeDisabled();
    expect(button).toBeDisabled();
  });

  it('disables send button when value is empty or whitespace', () => {
    const { rerender } = render(
      <ChatInput value="" onChange={() => {}} onSubmit={() => {}} />
    );
    expect(screen.getByRole('button', { name: 'Send message' })).toBeDisabled();

    rerender(<ChatInput value="   " onChange={() => {}} onSubmit={() => {}} />);
    expect(screen.getByRole('button', { name: 'Send message' })).toBeDisabled();
  });

  it('enables send button when value has content', () => {
    render(<ChatInput value="Hello" onChange={() => {}} onSubmit={() => {}} />);
    expect(screen.getByRole('button', { name: 'Send message' })).toBeEnabled();
  });

  it('renders custom send button text', () => {
    render(
      <ChatInput
        value="Hello"
        onChange={() => {}}
        onSubmit={() => {}}
        sendButtonText="Send"
      />
    );
    expect(screen.getByRole('button', { name: 'Send message' })).toHaveTextContent('Send');
  });

  it('calls onSubmit when send button is clicked', async () => {
    const handleSubmit = vi.fn();
    render(
      <ChatInput value="Hello" onChange={() => {}} onSubmit={handleSubmit} />
    );
    await userEvent.click(screen.getByRole('button', { name: 'Send message' }));
    expect(handleSubmit).toHaveBeenCalledTimes(1);
  });

  it('renders actions when provided', () => {
    render(
      <ChatInput
        value=""
        onChange={() => {}}
        onSubmit={() => {}}
        actions={<button>Attach</button>}
      />
    );
    expect(screen.getByRole('button', { name: 'Attach' })).toBeInTheDocument();
  });
});
