import type { Config } from 'tailwindcss';
import preset from './tailwind-preset';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  presets: [preset],
};

export default config;
