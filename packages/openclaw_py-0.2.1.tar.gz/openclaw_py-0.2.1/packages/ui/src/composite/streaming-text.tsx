import * as React from 'react';
import { cn } from '../lib/utils';

interface StreamingTextProps extends React.HTMLAttributes<HTMLSpanElement> {
  children: React.ReactNode;
  isStreaming?: boolean;
}

export function StreamingText({
  children,
  isStreaming = false,
  className,
  ...props
}: StreamingTextProps) {
  return (
    <span className={cn('relative', className)} {...props}>
      {children}
      {isStreaming && (
        <span className="ml-0.5 inline-block h-4 w-0.5 animate-pulse bg-foreground align-text-bottom" />
      )}
    </span>
  );
}
