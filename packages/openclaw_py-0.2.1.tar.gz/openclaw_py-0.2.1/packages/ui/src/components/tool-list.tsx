'use client';

import { cn } from '@pyclaw/ui';
import { Wrench, ChevronRight } from 'lucide-react';
import type { McpTool } from '@pyclaw/shared/types';

interface ToolListProps {
  tools: McpTool[];
  onSelect?: (tool: McpTool) => void;
}

export function ToolList({ tools, onSelect }: ToolListProps) {
  if (tools.length === 0) {
    return (
      <div className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">
        No tools available
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {tools.map((tool) => (
        <div
          key={`${tool.server_id}-${tool.name}`}
          onClick={() => onSelect?.(tool)}
          className={cn(
            'rounded-lg border bg-card p-3',
            onSelect && 'cursor-pointer hover:bg-accent'
          )}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wrench className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium text-sm">{tool.name}</span>
            </div>
            {onSelect && <ChevronRight className="h-4 w-4 text-muted-foreground" />}
          </div>
          {tool.description && (
            <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
              {tool.description}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}
