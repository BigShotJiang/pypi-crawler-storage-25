'use client';

import { cn } from '@pyclaw/ui';
import { Monitor, Smartphone, Globe, Terminal, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import type { Device } from '@pyclaw/shared/types';

interface DeviceCardProps {
  device: Device;
  onApprove?: () => void;
  onRemove?: () => void;
}

export function DeviceCard({ device, onApprove, onRemove }: DeviceCardProps) {
  const TypeIcon = {
    desktop: Monitor,
    mobile: Smartphone,
    web: Globe,
    cli: Terminal,
  }[device.device_type];

  const StatusIcon = {
    pending: AlertCircle,
    approved: CheckCircle,
    rejected: XCircle,
    expired: Clock,
  }[device.status];

  const statusColor = {
    pending: 'text-yellow-500',
    approved: 'text-green-500',
    rejected: 'text-red-500',
    expired: 'text-gray-500',
  }[device.status];

  return (
    <div className="rounded-lg border bg-card p-4">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-lg bg-muted p-2">
            <TypeIcon className="h-5 w-5 text-muted-foreground" />
          </div>
          <div>
            <h3 className="font-medium">{device.name || device.id.slice(0, 8)}</h3>
            <p className="text-sm text-muted-foreground capitalize">{device.device_type}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <StatusIcon className={cn('h-5 w-5', statusColor)} />
        </div>
      </div>

      {device.ip_address && (
        <p className="mt-2 text-xs text-muted-foreground">IP: {device.ip_address}</p>
      )}

      <div className="mt-2 text-xs text-muted-foreground">
        Created: {new Date(device.created_at).toLocaleDateString()}
        {device.last_seen && (
          <> · Last seen: {new Date(device.last_seen).toLocaleDateString()}</>
        )}
      </div>

      {device.status === 'pending' && onApprove && (
        <div className="mt-3 flex gap-2">
          <button
            onClick={onApprove}
            className="rounded bg-primary px-3 py-1 text-sm text-primary-foreground hover:bg-primary/90"
          >
            Approve
          </button>
          {onRemove && (
            <button
              onClick={onRemove}
              className="rounded border px-3 py-1 text-sm hover:bg-muted"
            >
              Reject
            </button>
          )}
        </div>
      )}

      {device.status === 'approved' && onRemove && (
        <button
          onClick={onRemove}
          className="mt-3 text-sm text-red-500 hover:text-red-600"
        >
          Remove device
        </button>
      )}
    </div>
  );
}
