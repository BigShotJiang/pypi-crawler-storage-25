'use client';

import { cn } from '@pyclaw/ui';
import { Sparkles, ExternalLink, Play, Trash2, AlertCircle } from 'lucide-react';
import type { Skill } from '@pyclaw/shared/types';

interface SkillCardProps {
  skill: Skill;
  onRun?: () => void;
  onRemove?: () => void;
}

export function SkillCard({ skill, onRun, onRemove }: SkillCardProps) {
  const statusColor = {
    installed: 'bg-green-500',
    available: 'bg-blue-500',
    updating: 'bg-yellow-500',
    error: 'bg-red-500',
  }[skill.status];

  const statusLabel = {
    installed: 'Installed',
    available: 'Available',
    updating: 'Updating',
    error: 'Error',
  }[skill.status];

  return (
    <div className="rounded-lg border bg-card p-4">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-lg bg-primary/10 p-2">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="font-medium">{skill.name}</h3>
            {skill.meta?.version && (
              <p className="text-xs text-muted-foreground">v{skill.meta.version}</p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={cn('h-2 w-2 rounded-full', statusColor)} />
          <span className="text-xs text-muted-foreground">{statusLabel}</span>
        </div>
      </div>

      {skill.meta?.description && (
        <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
          {skill.meta.description}
        </p>
      )}

      {skill.meta?.tags && skill.meta.tags.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {skill.meta.tags.slice(0, 4).map((tag) => (
            <span key={tag} className="rounded bg-muted px-1.5 py-0.5 text-xs">
              {tag}
            </span>
          ))}
        </div>
      )}

      {skill.tools.length > 0 && (
        <p className="mt-2 text-xs text-muted-foreground">
          {skill.tools.length} tool{skill.tools.length > 1 ? 's' : ''}
        </p>
      )}

      {skill.status === 'error' && (
        <p className="mt-2 flex items-center gap-1 text-xs text-red-500">
          <AlertCircle className="h-3 w-3" /> Installation failed
        </p>
      )}

      <div className="mt-3 flex gap-2">
        {skill.status === 'installed' && onRun && (
          <button
            onClick={onRun}
            className="flex items-center gap-1 rounded bg-primary px-3 py-1 text-sm text-primary-foreground hover:bg-primary/90"
          >
            <Play className="h-3 w-3" /> Run
          </button>
        )}
        {skill.status === 'installed' && onRemove && (
          <button
            onClick={onRemove}
            className="flex items-center gap-1 rounded border px-3 py-1 text-sm text-red-500 hover:bg-red-50"
          >
            <Trash2 className="h-3 w-3" />
          </button>
        )}
        {skill.meta?.homepage && (
          <a
            href={skill.meta.homepage}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
          >
            <ExternalLink className="h-3 w-3" /> Docs
          </a>
        )}
      </div>
    </div>
  );
}
