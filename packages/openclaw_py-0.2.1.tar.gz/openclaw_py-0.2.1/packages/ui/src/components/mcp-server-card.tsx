'use client';

import { cn } from '@pyclaw/ui';
import { Server, CheckCircle, XCircle, Loader2, Puzzle } from 'lucide-react';
import type { McpServer } from '@pyclaw/shared/types';

interface McpServerCardProps {
  server: McpServer;
  onExpand?: () => void;
}

export function McpServerCard({ server, onExpand }: McpServerCardProps) {
  const StatusIcon = {
    connected: CheckCircle,
    disconnected: XCircle,
    error: XCircle,
    connecting: Loader2,
  }[server.status];

  const statusColor = {
    connected: 'text-green-500',
    disconnected: 'text-gray-500',
    error: 'text-red-500',
    connecting: 'text-yellow-500',
  }[server.status];

  const bgColor = {
    connected: 'bg-green-500/10',
    disconnected: 'bg-gray-500/10',
    error: 'bg-red-500/10',
    connecting: 'bg-yellow-500/10',
  }[server.status];

  return (
    <div
      onClick={onExpand}
      className={cn(
        'rounded-lg border bg-card p-4',
        onExpand && 'cursor-pointer hover:bg-accent'
      )}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className={cn('rounded-lg p-2', bgColor)}>
            <Server className={cn('h-5 w-5', statusColor)} />
          </div>
          <div>
            <h3 className="font-medium">{server.name}</h3>
            <p className="text-xs text-muted-foreground capitalize">{server.transport}</p>
          </div>
        </div>
        <StatusIcon className={cn('h-5 w-5', statusColor, server.status === 'connecting' && 'animate-spin')} />
      </div>

      <div className="mt-3 flex items-center gap-4">
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Puzzle className="h-4 w-4" />
          <span>{server.tool_count} tools</span>
        </div>
      </div>

      {server.error && (
        <p className="mt-2 text-xs text-red-500 line-clamp-1">{server.error}</p>
      )}

      {server.connected_at && (
        <p className="mt-2 text-xs text-muted-foreground">
          Connected: {new Date(server.connected_at).toLocaleDateString()}
        </p>
      )}
    </div>
  );
}
