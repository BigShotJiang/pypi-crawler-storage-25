'use client';

import { cn } from '@pyclaw/ui';
import { Cpu, Eye, Wrench, AudioWaveform, Zap, AlertCircle } from 'lucide-react';
import type { Model } from '@pyclaw/shared/types';

interface ModelCardProps {
  model: Model;
  isDefault?: boolean;
  onClick?: () => void;
}

export function ModelCard({ model, isDefault, onClick }: ModelCardProps) {
  const statusColor = {
    available: 'bg-green-500',
    unavailable: 'bg-yellow-500',
    deprecated: 'bg-red-500',
  }[model.status];

  const statusLabel = {
    available: 'Available',
    unavailable: 'Unavailable',
    deprecated: 'Deprecated',
  }[model.status];

  return (
    <div
      onClick={onClick}
      className={cn(
        'rounded-lg border bg-card p-4 transition-colors',
        onClick && 'cursor-pointer hover:bg-accent',
        isDefault && 'ring-2 ring-primary'
      )}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="font-medium">{model.name}</h3>
            {isDefault && (
              <span className="rounded bg-primary px-1.5 py-0.5 text-xs text-primary-foreground">
                Default
              </span>
            )}
          </div>
          <p className="text-sm text-muted-foreground">{model.provider}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={cn('h-2 w-2 rounded-full', statusColor)} />
          <span className="text-xs text-muted-foreground">{statusLabel}</span>
        </div>
      </div>

      {model.aliases.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {model.aliases.map((alias) => (
            <span key={alias} className="rounded bg-muted px-1.5 py-0.5 text-xs">
              {alias}
            </span>
          ))}
        </div>
      )}

      {model.capabilities && (
        <div className="mt-3 flex flex-wrap gap-2">
          {model.capabilities.vision && (
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Eye className="h-3 w-3" /> Vision
            </span>
          )}
          {model.capabilities.tools && (
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Wrench className="h-3 w-3" /> Tools
            </span>
          )}
          {model.capabilities.streaming && (
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Zap className="h-3 w-3" /> Stream
            </span>
          )}
          {model.capabilities.audio && (
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <AudioWaveform className="h-3 w-3" /> Audio
            </span>
          )}
          {model.capabilities.reasoning && (
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Cpu className="h-3 w-3" /> Reason
            </span>
          )}
        </div>
      )}

      {model.context_window && (
        <p className="mt-2 text-xs text-muted-foreground">
          Context: {formatTokens(model.context_window)} tokens
        </p>
      )}

      {model.pricing && model.pricing.input_per_million !== null && (
        <p className="mt-1 text-xs text-muted-foreground">
          ${model.pricing.input_per_million}/1M input · $
          {model.pricing.output_per_million}/1M output
        </p>
      )}
    </div>
  );
}

function formatTokens(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
  return String(n);
}
