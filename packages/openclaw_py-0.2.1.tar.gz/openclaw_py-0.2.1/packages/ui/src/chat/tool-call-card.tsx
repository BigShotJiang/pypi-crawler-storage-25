import * as React from 'react';
import { Check, Loader2, X, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '../lib/utils';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/card';
import { StatusChip } from '../composite/status-chip';

interface ToolCallCardProps extends React.HTMLAttributes<HTMLDivElement> {
  name: string;
  status: 'pending' | 'running' | 'success' | 'error';
  input?: string;
  result?: string;
  error?: string;
  defaultExpanded?: boolean;
}

function StatusIcon({ status, className }: { status: ToolCallCardProps['status']; className?: string }) {
  const iconProps = { className };
  switch (status) {
    case 'running':
      return <Loader2 {...iconProps} />;
    case 'success':
      return <Check {...iconProps} />;
    case 'error':
      return <X {...iconProps} />;
    default:
      return <Loader2 {...iconProps} />;
  }
}

export function ToolCallCard({
  name,
  status,
  input,
  result,
  error,
  defaultExpanded = false,
  className,
  ...props
}: ToolCallCardProps) {
  const [expanded, setExpanded] = React.useState(defaultExpanded);

  const statusChipStatus = {
    pending: 'default' as const,
    running: 'info' as const,
    success: 'success' as const,
    error: 'error' as const,
  }[status];

  const hasContent = input || result || error;

  return (
    <Card
      className={cn('overflow-hidden', className)}
      {...props}
    >
      <CardHeader
        className={cn(
          'cursor-pointer select-none',
          hasContent && 'hover:bg-muted/50'
        )}
        role={hasContent ? 'button' : undefined}
        aria-expanded={hasContent ? expanded : undefined}
        tabIndex={hasContent ? 0 : undefined}
        onClick={() => hasContent && setExpanded(!expanded)}
        onKeyDown={(e: React.KeyboardEvent) => {
          if (hasContent && (e.key === 'Enter' || e.key === ' ')) {
            e.preventDefault();
            setExpanded(!expanded);
          }
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <StatusIcon
              status={status}
              className={cn(
                'h-4 w-4',
                status === 'running' && 'animate-spin',
                status === 'success' && 'text-green-500',
                status === 'error' && 'text-red-500'
              )}
            />
            <CardTitle className="text-sm font-medium">{name}</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <StatusChip status={statusChipStatus}>
              {status}
            </StatusChip>
            {hasContent && (
              expanded ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )
            )}
          </div>
        </div>
      </CardHeader>
      {expanded && hasContent && (
        <CardContent className="border-t bg-muted/30 space-y-3">
          {input && (
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-1">Input</div>
              <pre className="overflow-auto text-sm whitespace-pre-wrap bg-muted/50 rounded-md p-2">
                {input}
              </pre>
            </div>
          )}
          {error ? (
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-1">Error</div>
              <pre className="overflow-auto text-sm text-red-600 dark:text-red-400 whitespace-pre-wrap bg-red-50 dark:bg-red-950/50 rounded-md p-2">
                {error}
              </pre>
            </div>
          ) : result ? (
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-1">Output</div>
              <pre className="overflow-auto text-sm whitespace-pre-wrap bg-muted/50 rounded-md p-2">
                {result}
              </pre>
            </div>
          ) : null}
        </CardContent>
      )}
    </Card>
  );
}
