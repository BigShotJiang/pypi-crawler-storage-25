import * as React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import 'highlight.js/styles/github-dark.css';
import { cn } from '../lib/utils';
import { StreamingText } from '../composite/streaming-text';

interface MessageBubbleProps extends React.HTMLAttributes<HTMLDivElement> {
  role: 'user' | 'assistant' | 'system';
  content: string;
  isStreaming?: boolean;
  /** Render additional action buttons inside the bubble */
  actions?: React.ReactNode;
}

export function MessageBubble({
  role,
  content,
  isStreaming = false,
  actions,
  className,
  ...props
}: MessageBubbleProps) {
  const isUser = role === 'user';
  const isSystem = role === 'system';

  return (
    <div
      className={cn(
        'flex w-full',
        isSystem ? 'justify-center' : isUser ? 'justify-end' : 'justify-start',
        className
      )}
      {...props}
    >
      <div
        className={cn(
          'max-w-[80%] rounded-2xl px-4 py-2.5',
          isSystem
            ? 'bg-muted/50 text-muted-foreground italic text-center'
            : isUser
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-muted-foreground'
        )}
      >
        {isSystem ? (
          <p className="text-sm whitespace-pre-wrap">{content}</p>
        ) : isUser ? (
          <p className="text-sm whitespace-pre-wrap">{content}</p>
        ) : (
          <div>
            <div className="prose prose-sm dark:prose-invert max-w-none">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                rehypePlugins={[rehypeHighlight]}
                components={{
                  pre: ({ children }) => (
                    <pre className="overflow-auto rounded-md bg-zinc-900 p-4 text-sm">
                      {children}
                    </pre>
                  ),
                  code: ({ className, children, ...codeProps }) => {
                    const isInline = !className;
                    return isInline ? (
                      <code
                        className="rounded bg-muted px-1.5 py-0.5 text-sm"
                        {...codeProps}
                      >
                        {children}
                      </code>
                    ) : (
                      <code className={className} {...codeProps}>
                        {children}
                      </code>
                    );
                  },
                }}
              >
                {content}
              </ReactMarkdown>
              {isStreaming && (
                <StreamingText isStreaming={true} className="text-foreground">
                  {''}
                </StreamingText>
              )}
            </div>
            {actions && !isStreaming && (
              <div className="mt-2 flex items-center gap-1">
                {actions}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
