"""Session checkpoint management — snapshot creation and rotation."""

from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import aiofiles
import aiofiles.os

from pyclaw.agents.session import AgentMessage, SessionManager


@dataclass
class CheckpointMetadata:
    """Metadata for a session checkpoint."""

    checkpoint_id: str
    session_id: str
    message_count: int
    created_at: float
    checksum: str  # SHA-256 hash of content (first 16 chars)

    def to_dict(self) -> dict[str, Any]:
        return {
            "checkpoint_id": self.checkpoint_id,
            "session_id": self.session_id,
            "message_count": self.message_count,
            "created_at": self.created_at,
            "checksum": self.checksum,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CheckpointMetadata:
        return cls(
            checkpoint_id=data["checkpoint_id"],
            session_id=data["session_id"],
            message_count=data["message_count"],
            created_at=data["created_at"],
            checksum=data["checksum"],
        )


class CheckpointManager:
    """Manages session checkpoint lifecycle: creation, rotation, restoration.

    Checkpoints are full session snapshots stored in a checkpoints directory.
    Rotation keeps only the last N checkpoints (default 3).
    """

    def __init__(
        self,
        session: SessionManager,
        checkpoints_dir: Path,
        max_checkpoints: int = 3,
    ):
        self.session = session
        self.checkpoints_dir = checkpoints_dir
        self.max_checkpoints = max_checkpoints
        self._message_counter = 0
        self._checkpoint_interval = 10  # Every 10 messages (per CONTEXT.md)

    async def maybe_checkpoint(self) -> CheckpointMetadata | None:
        """Create checkpoint if message count threshold reached.

        Call this after each message append.
        Returns None if no checkpoint created.
        """
        self._message_counter += 1
        if self._message_counter >= self._checkpoint_interval:
            self._message_counter = 0
            return await self.create_checkpoint()
        return None

    async def create_checkpoint(self) -> CheckpointMetadata:
        """Create a checkpoint snapshot of current session state."""
        self.checkpoints_dir.mkdir(parents=True, exist_ok=True)

        # Serialize session state
        entries: list[dict[str, Any]] = []
        entries.append(
            {
                "type": "session",
                "version": 3,
                "id": self.session.session_id,
            }
        )

        for msg in self.session.messages:
            entries.append(
                {
                    "type": "message",
                    "id": self._gen_id(),
                    "message": msg.to_dict(),
                }
            )

        # Compute checksum
        content = "\n".join(json.dumps(e, ensure_ascii=False) for e in entries)
        checksum = hashlib.sha256(content.encode()).hexdigest()[:16]

        # Generate timestamp-based checkpoint ID with random suffix for uniqueness
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        random_suffix = uuid.uuid4().hex[:4]
        checkpoint_id = f"ckpt-{timestamp}-{random_suffix}"
        checkpoint_path = self.checkpoints_dir / f"{checkpoint_id}.jsonl"

        # Atomic write
        tmp_path = checkpoint_path.with_suffix(".tmp")
        async with aiofiles.open(tmp_path, "w", encoding="utf-8") as f:
            for entry in entries:
                await f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        await aiofiles.os.replace(str(tmp_path), str(checkpoint_path))

        metadata = CheckpointMetadata(
            checkpoint_id=checkpoint_id,
            session_id=self.session.session_id,
            message_count=len(self.session.messages),
            created_at=time.time(),
            checksum=checksum,
        )

        # Rotation
        await self._rotate_checkpoints()

        return metadata

    async def _rotate_checkpoints(self) -> None:
        """Remove old checkpoints, keeping only last max_checkpoints."""
        if not self.checkpoints_dir.exists():
            return

        checkpoints = sorted(
            self.checkpoints_dir.glob("ckpt-*.jsonl"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        # Remove excess checkpoints
        for old_ckpt in checkpoints[self.max_checkpoints :]:
            old_ckpt.unlink(missing_ok=True)

    async def restore_from_checkpoint(self, checkpoint_id: str) -> bool:
        """Restore session from a checkpoint.

        Returns True if restoration successful, False otherwise.
        """
        checkpoint_path = self.checkpoints_dir / f"{checkpoint_id}.jsonl"
        if not checkpoint_path.exists():
            return False

        # Clear current state
        self.session.messages.clear()
        self.session.custom_entries.clear()

        # Load checkpoint synchronously (simpler and more reliable)
        with open(checkpoint_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if entry.get("type") == "session":
                    self.session.session_id = entry.get("id", self.session.session_id)
                elif entry.get("type") == "message":
                    msg_data = entry.get("message", {})
                    self.session.messages.append(AgentMessage.from_dict(msg_data))

        return True

    def get_checkpoints(self) -> list[CheckpointMetadata]:
        """List available checkpoints sorted by timestamp (newest first)."""
        if not self.checkpoints_dir.exists():
            return []

        checkpoints: list[CheckpointMetadata] = []
        for ckpt_file in self.checkpoints_dir.glob("ckpt-*.jsonl"):
            try:
                stat = ckpt_file.stat()
                checkpoint_id = ckpt_file.stem
                checkpoints.append(
                    CheckpointMetadata(
                        checkpoint_id=checkpoint_id,
                        session_id=self.session.session_id,
                        message_count=0,  # Would need to read file for exact count
                        created_at=stat.st_mtime,
                        checksum="",  # Would need to read file
                    )
                )
            except OSError:
                continue

        return sorted(checkpoints, key=lambda c: c.created_at, reverse=True)

    def _gen_id(self) -> str:
        return uuid.uuid4().hex[:12]
