"""Builtin memory provider using MemoryDirectory.

This module implements the MemoryProvider ABC using the existing
MemoryDirectory for file-based storage and BM25 search for retrieval.

Design notes:
- Wraps MemoryDirectory for CRUD operations
- Uses search_all_memory_files for BM25 search
- Handles ImportError gracefully when memory_dir is unavailable
- Converts between provider.MemoryEntry and memory_dir.MemoryEntry types
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

from pyclaw.agents.memory.provider import MemoryEntry, MemoryProvider
from pyclaw.agents.memory.scope import MemoryPath

logger = logging.getLogger(__name__)

# Type alias for memory_dir.MemoryEntry to avoid confusion
MemoryDirEntry = Any  # Would be memory_dir.MemoryEntry if imported


class _MemorySearchAdapter:
    """Adapter wrapping BM25 search for memory entries.

    This class encapsulates the search logic from memory_dir module,
    providing a simple interface for searching memory entries.

    Attributes:
        memory_root: Root directory for memory files.
    """

    def __init__(self, memory_root: Path) -> None:
        """Initialize the search adapter.

        Args:
            memory_root: Root directory containing memory files.
        """
        self.memory_root = memory_root
        self._search_available = False
        self._search_config = None

        # Try to import search functionality
        try:
            from pyclaw.agents.memory_dir.find_relevant_memories import (
                SearchConfig,
                search_all_memory_files,
            )

            self._search_all_memory_files = search_all_memory_files
            self._search_config_class = SearchConfig
            self._search_available = True
        except ImportError:
            logger.warning("memory_dir search module not available, search will return empty results")
            self._search_available = False

    def search(
        self,
        query: str,
        limit: int = 10,
        min_relevance: float = 0.2,
    ) -> list[MemoryDirEntry]:
        """Search for relevant memory entries.

        Args:
            query: Search query string.
            limit: Maximum number of results.
            min_relevance: Minimum relevance score threshold.

        Returns:
            List of matching memory_dir.MemoryEntry objects.
        """
        if not self._search_available:
            return []

        # Collect memory files
        memory_files = self._collect_memory_files()
        if not memory_files:
            return []

        # Create search config
        config = self._search_config_class(
            max_results=limit,
            min_relevance=min_relevance,
        )

        # Execute search
        return self._search_all_memory_files(query, memory_files, config)

    def _collect_memory_files(self) -> list[Path]:
        """Collect all memory file paths.

        Returns:
            List of paths to memory JSONL files.
        """
        files: list[Path] = []

        # Standard memory directory structure
        memory_dirs = [
            self.memory_root / "project",
            self.memory_root / "session",
            self.memory_root / "team",
            self.memory_root / "user",
        ]

        for directory in memory_dirs:
            if directory.exists():
                files.extend(directory.glob("*.jsonl"))

        return files


def _convert_to_provider_entry(
    memdir_entry: MemoryDirEntry,
    score: float = 0.0,
) -> MemoryEntry:
    """Convert a memory_dir.MemoryEntry to provider.MemoryEntry.

    Args:
        memdir_entry: Entry from memory_dir module.
        score: Search relevance score.

    Returns:
        Provider MemoryEntry instance.
    """
    return MemoryEntry(
        id=memdir_entry.key,
        content=memdir_entry.content,
        created_at=memdir_entry.created_at,
        updated_at=memdir_entry.updated_at,
        metadata={
            "memory_type": memdir_entry.memory_type.value
            if hasattr(memdir_entry.memory_type, "value")
            else str(memdir_entry.memory_type),
            "priority": memdir_entry.priority.value
            if hasattr(memdir_entry.priority, "value")
            else str(memdir_entry.priority),
            "tags": memdir_entry.tags,
            **memdir_entry.metadata,
        },
        score=score,
    )


class BuiltinMemoryProvider(MemoryProvider):
    """File-based memory provider using MemoryDirectory.

    This provider uses the existing MemoryDirectory implementation
    for storing memories in JSONL files and BM25 for search.

    Attributes:
        name: Provider identifier ("builtin").
    """

    def __init__(self) -> None:
        """Initialize the builtin memory provider."""
        self._memory_dir: Any = None  # MemoryDirectory when available
        self._search_adapter: _MemorySearchAdapter | None = None
        self._initialized = False
        self._memory_root: Path | None = None

        # Track whether memory_dir is available
        self._memory_dir_available = False
        self._entries: dict[str, MemoryEntry] = {}  # Fallback in-memory store

    @property
    def name(self) -> str:
        """Provider name for identification."""
        return "builtin"

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the provider.

        Args:
            **kwargs: Configuration parameters:
                - memory_path: MemoryPath instance (preferred)
                - memory_root: Path to memory root directory
                - project_root: Path to project root (for MemoryPath)
        """
        if self._initialized:
            return

        # Resolve memory root path
        memory_path = kwargs.get("memory_path")
        if memory_path and isinstance(memory_path, MemoryPath):
            self._memory_root = memory_path.resolve()
        elif "memory_root" in kwargs:
            self._memory_root = Path(kwargs["memory_root"])
        elif "project_root" in kwargs:
            self._memory_root = Path(kwargs["project_root"]) / ".claude" / "memory"
        else:
            # Default to current directory
            self._memory_root = Path.cwd() / ".claude" / "memory"

        # Ensure memory root exists (self._memory_root is now guaranteed to be set)
        assert self._memory_root is not None
        self._memory_root.mkdir(parents=True, exist_ok=True)

        # Initialize search adapter
        self._search_adapter = _MemorySearchAdapter(self._memory_root)

        # Try to initialize MemoryDirectory
        try:
            from pyclaw.agents.memory_dir import MemoryDirectory, MemoryPaths

            paths = MemoryPaths(base_dir=self._memory_root.parent.parent)
            self._memory_dir = MemoryDirectory(paths=paths)
            self._memory_dir_available = True
            logger.info("BuiltinMemoryProvider initialized with MemoryDirectory")
        except ImportError:
            logger.warning("MemoryDirectory not available, using in-memory fallback")
            self._memory_dir_available = False

        self._initialized = True

    async def shutdown(self) -> None:
        """Shut down the provider.

        Flushes any pending data and releases resources.
        """
        # MemoryDirectory doesn't require explicit shutdown
        self._initialized = False
        logger.debug("BuiltinMemoryProvider shut down")

    async def add(self, content: str, metadata: dict[str, Any] | None = None) -> str:
        """Add a memory entry.

        Args:
            content: The memory content text.
            metadata: Optional metadata dict.

        Returns:
            The ID of the created entry.
        """
        metadata = metadata or {}
        entry_id = str(uuid4())[:8]

        if self._memory_dir_available and self._memory_dir:
            # Use MemoryDirectory for storage
            from pyclaw.agents.memory_dir import MemoryType

            # Determine memory type from metadata
            mem_type_str = metadata.get("memory_type", "session_context")
            try:
                memory_type = MemoryType(mem_type_str)
            except ValueError:
                memory_type = MemoryType.SESSION_CONTEXT

            # Determine priority from metadata (for future use)
            _ = metadata.get("priority", "medium")  # noqa: F841

            # Append to session memory file
            # Note: MemoryDirectory.add_session_memory creates its own entry
            session_id = metadata.get("session_id", "default")
            self._memory_dir.add_session_memory(
                session_id=session_id,
                content=content,
                memory_type=memory_type,
                tags=metadata.get("tags", []),
            )
        else:
            # Fallback to in-memory storage
            now = datetime.now()
            self._entries[entry_id] = MemoryEntry(
                id=entry_id,
                content=content,
                created_at=now,
                updated_at=now,
                metadata=metadata,
            )

        return entry_id

    async def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        """Search memory entries.

        Args:
            query: Search query string.
            limit: Maximum number of results.

        Returns:
            List of matching MemoryEntry objects.
        """
        results: list[MemoryEntry] = []

        if self._search_adapter:
            # Use BM25 search
            memdir_entries = self._search_adapter.search(query, limit)
            for entry in memdir_entries:
                # Calculate approximate score from relevance_score
                score = getattr(entry, "relevance_score", 0.0)
                results.append(_convert_to_provider_entry(entry, score))

            # Limit results
            results = results[:limit]

        if not results:
            # Fallback to simple text matching on in-memory entries
            query_lower = query.lower()
            for entry in self._entries.values():
                if query_lower in entry.content.lower():
                    results.append(entry)
                    if len(results) >= limit:
                        break

        return results

    async def get(self, entry_id: str) -> MemoryEntry | None:
        """Get a single memory entry by ID.

        Args:
            entry_id: The entry ID.

        Returns:
            MemoryEntry if found, None otherwise.
        """
        # First check in-memory entries
        if entry_id in self._entries:
            return self._entries[entry_id]

        # Search through memory files
        if self._search_adapter and self._memory_root:
            # Load all entries and find by key
            try:
                from pyclaw.agents.memory_dir.find_relevant_memories import (
                    load_memories_from_jsonl,
                )

                memory_files = self._search_adapter._collect_memory_files()
                for file_path in memory_files:
                    entries = load_memories_from_jsonl(file_path)
                    for entry in entries:
                        if entry.key == entry_id:
                            return _convert_to_provider_entry(entry)
            except (ImportError, Exception) as e:
                logger.debug(f"Error loading memory entry: {e}")

        return None

    async def update(
        self,
        entry_id: str,
        content: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """Update a memory entry.

        Note: MemoryDirectory uses append-only storage, so updates
        create new entries. This implementation updates in-memory
        entries only for the fallback case.

        Args:
            entry_id: The entry ID.
            content: Optional new content.
            metadata: Optional new/updated metadata.

        Returns:
            True if updated, False if not found.
        """
        # In-memory update for fallback
        if entry_id in self._entries:
            entry = self._entries[entry_id]
            if content is not None:
                # Create updated entry
                self._entries[entry_id] = MemoryEntry(
                    id=entry.id,
                    content=content,
                    created_at=entry.created_at,
                    updated_at=datetime.now(),
                    metadata=metadata if metadata is not None else entry.metadata,
                    score=entry.score,
                )
            return True

        # For MemoryDirectory, we'd need to rewrite files
        # This is a limitation of the append-only storage
        logger.warning(f"Update not fully supported for entry {entry_id} (MemoryDirectory uses append-only storage)")
        return False

    async def delete(self, entry_id: str) -> bool:
        """Delete a memory entry.

        Note: MemoryDirectory uses append-only storage, so deletes
        are soft deletes (entry remains in file but is marked).

        Args:
            entry_id: The entry ID.

        Returns:
            True if deleted, False if not found.
        """
        # In-memory delete for fallback
        if entry_id in self._entries:
            del self._entries[entry_id]
            return True

        # For MemoryDirectory, deletion would require file rewrite
        logger.warning(f"Delete not fully supported for entry {entry_id} (MemoryDirectory uses append-only storage)")
        return False

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics.

        Returns:
            Dict with provider status and metrics.
        """
        stats = {
            "provider": self.name,
            "initialized": self._initialized,
            "memory_dir_available": self._memory_dir_available,
            "memory_root": str(self._memory_root) if self._memory_root else None,
            "in_memory_entries": len(self._entries),
        }

        if self._memory_dir_available and self._memory_dir:
            try:
                dir_stats = self._memory_dir.stats()
                stats["memory_directory"] = dir_stats
            except Exception as e:
                stats["memory_directory_error"] = str(e)

        return stats
