"""LanceDB memory provider — vector-native storage with hybrid search.

Optional dependency: ``lancedb`` + ``pyarrow``. If not installed,
``LanceDBMemoryProvider`` raises ``ImportError`` at initialization.

This provider implements the new MemoryProvider ABC from agents/memory/provider.py,
providing vector-based semantic search capabilities.

Example:
    from pyclaw.agents.memory.providers import LanceDBMemoryProvider
    from pyclaw.agents.memory.embeddings import create_embedding_provider

    embedding = await create_embedding_provider("openai")
    provider = LanceDBMemoryProvider(
        db_path="~/.pyclaw/agent-memory",
        embedding_provider=embedding,
    )
    await provider.initialize()

    # Add memory
    entry_id = await provider.add("Important decision: use PostgreSQL for primary DB")

    # Search
    results = await provider.search("database choice")
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from datetime import datetime
from typing import Any

from pyclaw.agents.memory.embedding import EmbeddingProvider
from pyclaw.agents.memory.provider import MemoryEntry, MemoryProvider

logger = logging.getLogger(__name__)

COLLECTION_NAME = "agent_memories"
DEFAULT_EMBEDDING_DIM = 1536


class LanceDBMemoryProvider(MemoryProvider):
    """LanceDB-based memory provider with vector search.

    Features:
    - Vector similarity search using embeddings
    - Full-text search fallback
    - Persistent storage (disk-based)
    - Efficient ANN (approximate nearest neighbor) search
    - TTL support for memory expiration

    Requirements:
    - lancedb package
    - pyarrow package
    - An EmbeddingProvider for vector generation
    """

    def __init__(
        self,
        *,
        db_path: str = "~/.pyclaw/agent-memory",
        embedding_provider: EmbeddingProvider | None = None,
        collection_name: str = COLLECTION_NAME,
        embedding_dim: int | None = None,
    ) -> None:
        """Initialize LanceDB memory provider.

        Args:
            db_path: Path to LanceDB database (default: ~/.pyclaw/agent-memory).
            embedding_provider: Provider for generating embeddings.
                If None, search will use FTS only.
            collection_name: Table/collection name (default: agent_memories).
            embedding_dim: Embedding dimension. If None, uses provider's dimension
                or defaults to 1536.
        """
        self._db_path = db_path
        self._embedding_provider = embedding_provider
        self._collection_name = collection_name
        self._embedding_dim = embedding_dim or (
            embedding_provider.dimension if embedding_provider else DEFAULT_EMBEDDING_DIM
        )
        self._db: Any = None
        self._table: Any = None

    @property
    def name(self) -> str:
        return "lancedb"

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize LanceDB connection and create table if needed."""
        try:
            import lancedb as ldb
        except ImportError as exc:
            raise ImportError(
                "lancedb is required for LanceDBMemoryProvider. Install with: pip install lancedb pyarrow"
            ) from exc

        # Initialize embedding provider if provided
        if self._embedding_provider:
            await self._embedding_provider.initialize()
            self._embedding_dim = self._embedding_provider.dimension

        self._db = ldb.connect(self._db_path)

        try:
            self._table = self._db.open_table(self._collection_name)
            logger.info("Opened existing LanceDB table: %s", self._collection_name)
        except Exception:
            import pyarrow as pa

            schema = pa.schema(
                [
                    pa.field("id", pa.string()),
                    pa.field("content", pa.string()),
                    pa.field("scope", pa.string()),
                    pa.field("tags", pa.string()),
                    pa.field("metadata", pa.string()),
                    pa.field("created_at", pa.float64()),
                    pa.field("updated_at", pa.float64()),
                    pa.field("vector", pa.list_(pa.float32(), self._embedding_dim)),
                ]
            )
            self._table = self._db.create_table(self._collection_name, schema=schema)
            logger.info("Created new LanceDB table: %s", self._collection_name)

        logger.info(
            "LanceDB memory provider initialized: path=%s, dimension=%d",
            self._db_path,
            self._embedding_dim,
        )

    async def shutdown(self) -> None:
        """Close LanceDB connection."""
        self._table = None
        self._db = None

        if self._embedding_provider:
            await self._embedding_provider.shutdown()

        logger.info("LanceDB memory provider shutdown")

    async def add(self, content: str, metadata: dict[str, Any] | None = None) -> str:
        """Add a memory entry.

        Args:
            content: The memory content text.
            metadata: Optional metadata (source, tags, scope, etc.).

        Returns:
            The ID of the created entry.
        """
        if not self._table:
            raise RuntimeError("LanceDB provider not initialized")

        metadata = metadata or {}
        record_id = str(uuid.uuid4())
        now = time.time()

        # Generate embedding if provider available
        vector: list[float] = []
        if self._embedding_provider:
            try:
                vector = await self._embedding_provider.embed_query(content)
            except Exception as e:
                logger.warning("Failed to generate embedding: %s", e)
                vector = [0.0] * self._embedding_dim

        # Extract scope/tags from metadata
        scope = metadata.pop("scope", "session")
        tags = metadata.pop("tags", [])

        row = {
            "id": record_id,
            "content": content,
            "scope": scope,
            "tags": json.dumps(tags),
            "metadata": json.dumps(metadata),
            "created_at": now,
            "updated_at": now,
            "vector": vector,
        }

        self._table.add([row])
        logger.debug("Added memory %s to LanceDB", record_id)

        return record_id

    async def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        """Search memory entries.

        Uses vector search if embedding provider is available,
        otherwise falls back to full-text search.

        Args:
            query: Search query string.
            limit: Maximum number of results.

        Returns:
            List of matching MemoryEntry objects.
        """
        if not self._table:
            raise RuntimeError("LanceDB provider not initialized")

        results: list[dict[str, Any]] = []

        # Try vector search first
        if self._embedding_provider:
            try:
                query_vector = await self._embedding_provider.embed_query(query)
                search_results = self._table.search(query_vector).limit(limit).to_list()

                for row in search_results:
                    distance = row.get("_distance", 0.0)
                    score = 1.0 / (1.0 + distance) if distance >= 0 else 0.0
                    results.append({**row, "score": score})

                logger.debug("Vector search returned %d results", len(results))
                return [self._row_to_entry(r) for r in results]
            except Exception as e:
                logger.warning("Vector search failed, falling back to FTS: %s", e)

        # Fallback to full-text search
        try:
            fts_results = self._table.search(query, query_type="fts").limit(limit).to_list()
            for row in fts_results:
                results.append({**row, "score": 0.5})  # Default score for FTS
        except Exception as e:
            logger.warning("FTS search failed: %s", e)
            # Last resort: return recent memories
            df = self._table.to_pandas().sort_values("created_at", ascending=False).head(limit)
            for row in df.to_dict("records"):
                results.append({**row, "score": 0.3})

        return [self._row_to_entry(r) for r in results]

    async def get(self, entry_id: str) -> MemoryEntry | None:
        """Get a single memory entry by ID.

        Args:
            entry_id: The entry ID.

        Returns:
            MemoryEntry if found, None otherwise.
        """
        if not self._table:
            raise RuntimeError("LanceDB provider not initialized")

        try:
            df = self._table.to_pandas()
            row = df[df["id"] == entry_id]
            if row.empty:
                return None

            return self._row_to_entry(row.iloc[0].to_dict())
        except Exception as e:
            logger.warning("Failed to get memory %s: %s", entry_id, e)
            return None

    async def update(
        self,
        entry_id: str,
        content: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """Update a memory entry.

        Args:
            entry_id: The entry ID.
            content: Optional new content.
            metadata: Optional new/updated metadata.

        Returns:
            True if updated, False if not found.
        """
        if not self._table:
            raise RuntimeError("LanceDB provider not initialized")

        # Get existing entry
        existing = await self.get(entry_id)
        if not existing:
            return False

        # Prepare update
        new_content = content or existing.content
        new_metadata = {**(existing.metadata), **(metadata or {})}
        now = time.time()

        # Generate new embedding if content changed
        vector: list[float] = []
        if content and self._embedding_provider:
            try:
                vector = await self._embedding_provider.embed_query(content)
            except Exception as e:
                logger.warning("Failed to generate embedding: %s", e)

        # Delete and re-add (LanceDB doesn't support in-place updates)
        self._table.delete(f"id = '{entry_id}'")

        new_row = {
            "id": entry_id,
            "content": new_content,
            "scope": existing.metadata.get("scope", "session"),
            "tags": json.dumps(existing.metadata.get("tags", [])),
            "metadata": json.dumps(new_metadata),
            "created_at": existing.created_at.timestamp(),
            "updated_at": now,
            "vector": vector or [0.0] * self._embedding_dim,
        }

        self._table.add([new_row])
        logger.debug("Updated memory %s in LanceDB", entry_id)

        return True

    async def delete(self, entry_id: str) -> bool:
        """Delete a memory entry.

        Args:
            entry_id: The entry ID.

        Returns:
            True if deleted, False if not found.
        """
        if not self._table:
            raise RuntimeError("LanceDB provider not initialized")

        try:
            self._table.delete(f"id = '{entry_id}'")
            logger.debug("Deleted memory %s from LanceDB", entry_id)
            return True
        except Exception as e:
            logger.warning("Failed to delete memory %s: %s", entry_id, e)
            return False

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        stats = super().get_stats()

        if self._table:
            try:
                count = self._table.count_rows()
                stats["total_entries"] = count
            except Exception:
                pass

        stats["embedding_dim"] = self._embedding_dim
        stats["embedding_provider"] = self._embedding_provider.name if self._embedding_provider else None
        stats["db_path"] = self._db_path

        return stats

    def _row_to_entry(self, row: dict[str, Any]) -> MemoryEntry:
        """Convert a database row to MemoryEntry."""
        # Parse JSON fields
        try:
            tags = json.loads(row.get("tags", "[]"))
        except (json.JSONDecodeError, TypeError):
            tags = []

        try:
            metadata = json.loads(row.get("metadata", "{}"))
        except (json.JSONDecodeError, TypeError):
            metadata = {}

        # Add tags back to metadata
        if tags:
            metadata["tags"] = tags

        return MemoryEntry(
            id=row["id"],
            content=row["content"],
            created_at=datetime.fromtimestamp(row.get("created_at", 0.0)),
            updated_at=datetime.fromtimestamp(row.get("updated_at", row.get("created_at", 0.0))),
            metadata=metadata,
            score=row.get("score", 1.0),
        )
