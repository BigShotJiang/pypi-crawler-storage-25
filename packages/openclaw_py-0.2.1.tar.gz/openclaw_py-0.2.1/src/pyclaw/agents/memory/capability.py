"""Memory capability registration and provider access.

This module provides functions to register and retrieve memory providers
through the capability registry system.

Design notes:
- register_memory_capability() registers a provider with the global registry
- get_memory_provider() retrieves a provider by name or highest priority
- Default builtin provider is auto-registered on module import
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pyclaw.agents.capabilities import AgentCapability, CapabilityType, get_capability_registry
from pyclaw.agents.memory.provider import MemoryProvider
from pyclaw.agents.memory.providers.builtin import BuiltinMemoryProvider

# Track if default provider has been registered
_default_registered = False


def _default_builtin_provider() -> MemoryProvider:
    """Factory function for default BuiltinMemoryProvider."""
    return BuiltinMemoryProvider()


def register_memory_capability(
    name: str = "builtin",
    provider_factory: Callable[[], MemoryProvider] | None = None,
    priority: int = 0,
    tags: set[str] | None = None,
    metadata: dict[str, Any] | None = None,
    *,
    allow_replace: bool = True,
) -> None:
    """Register a memory capability provider.

    Args:
        name: Provider name (default: "builtin").
        provider_factory: Factory function that creates provider instance.
            If None, uses BuiltinMemoryProvider.
        priority: Priority for selection (higher wins, default: 0).
        tags: Query tags for filtering capabilities.
        metadata: Additional metadata for the capability.
        allow_replace: If True, replaces existing capability with same name
            (default: True). Set to False for strict registration.

    Raises:
        ValueError: If capability already exists and allow_replace is False.
    """
    if provider_factory is None:
        provider_factory = _default_builtin_provider

    capability = AgentCapability(
        capability_type=CapabilityType.MEMORY,
        name=name,
        description=f"Memory provider: {name}",
        provider=provider_factory,
        priority=priority,
        tags=tags or set(),
        metadata=metadata or {},
    )

    registry = get_capability_registry()

    if not allow_replace:
        existing = registry.get(CapabilityType.MEMORY, name)
        if existing is not None:
            raise ValueError(f"Memory capability '{name}' already registered")

    registry.register(capability)


def get_memory_provider(name: str | None = None) -> MemoryProvider | None:
    """Get a memory provider by name or highest priority.

    Args:
        name: Provider name. If None, returns the highest priority provider.

    Returns:
        MemoryProvider instance or None if not found.
    """
    registry = get_capability_registry()
    capability = registry.get(CapabilityType.MEMORY, name)
    if capability is None:
        return None

    provider = capability.provider()
    # Type check to ensure we return a MemoryProvider
    if not isinstance(provider, MemoryProvider):
        return None

    return provider


def unregister_memory_capability(name: str) -> bool:
    """Unregister a memory capability by name.

    Args:
        name: Provider name to unregister.

    Returns:
        True if the capability was removed, False if not found.
    """
    registry = get_capability_registry()
    return registry.unregister(CapabilityType.MEMORY, name)


def list_memory_capabilities() -> list[AgentCapability]:
    """List all registered memory capabilities.

    Returns:
        List of all memory capability definitions.
    """
    registry = get_capability_registry()
    return registry.list_all(CapabilityType.MEMORY)


def _register_default_provider() -> None:
    """Register the default builtin memory provider.

    This is called on module import to ensure a default provider is available.
    """
    global _default_registered
    if _default_registered:
        return

    register_memory_capability(
        name="builtin",
        provider_factory=_default_builtin_provider,
        priority=0,
        tags={"default", "file-based"},
        metadata={"storage": "jsonl", "search": "bm25"},
    )
    _default_registered = True


# Auto-register default builtin provider on module import
_register_default_provider()
