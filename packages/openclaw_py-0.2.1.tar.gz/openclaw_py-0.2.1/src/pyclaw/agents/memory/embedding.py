"""Embedding provider abstract base class.

This module defines the EmbeddingProvider ABC that vector-based memory
backends use to generate embeddings for content and queries.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class EmbeddingProvider(ABC):
    """Abstract base class for embedding providers.

    Embedding providers generate vector embeddings for text content,
    enabling semantic search in vector-based memory backends.

    Design notes:
    - Each provider has a fixed dimension (vector size)
    - embed() is for content (documents, memories)
    - embed_query() is for search queries (may differ for some models)
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider name for identification.

        Used for logging, configuration, and debugging.
        """

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Embedding dimension (vector size).

        Must match the dimension expected by the vector backend.
        Common dimensions:
        - OpenAI text-embedding-3-small: 1536
        - OpenAI text-embedding-3-large: 3072
        - sentence-transformers: varies by model
        """

    # -- Embedding methods --

    @abstractmethod
    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts.

        Used for indexing content into vector storage.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of embedding vectors (each is a list of floats).

        Raises:
            EmbeddingError: If embedding generation fails.
        """

    @abstractmethod
    async def embed_query(self, query: str) -> list[float]:
        """Generate embedding for a search query.

        Used for similarity search. Some embedding models recommend
        different processing for queries vs. documents.

        Args:
            query: The search query string.

        Returns:
            Embedding vector for the query.

        Raises:
            EmbeddingError: If embedding generation fails.
        """

    # -- Lifecycle --

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the provider (lifecycle hook).

        Override to set up connections, load models, etc.

        Args:
            **kwargs: Configuration parameters.
        """
        pass

    async def shutdown(self) -> None:
        """Shut down the provider (lifecycle hook).

        Override to close connections, unload models, etc.
        """
        pass

    # -- Utility --

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics.

        Returns:
            Dict with provider status and metrics.
        """
        return {
            "provider": self.name,
            "dimension": self.dimension,
        }


class EmbeddingError(Exception):
    """Exception raised when embedding generation fails."""

    def __init__(self, message: str, provider: str | None = None) -> None:
        """Initialize embedding error.

        Args:
            message: Error description.
            provider: Optional provider name that caused the error.
        """
        super().__init__(message)
        self.provider = provider
