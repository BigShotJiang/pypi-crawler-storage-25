"""Memory scope and path definitions.

This module provides MemoryPath for resolving memory storage locations
based on scope. MemoryScope is imported from definition.py for consistency.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from pyclaw.agents.definition import MemoryScope


@dataclass
class MemoryPath:
    """Memory path resolver.

    Resolves the storage path for a given memory scope.

    Attributes:
        scope: The memory scope (user, project, local, session, team).
        base_dir: The base directory for path resolution.
            - For USER scope: typically user home directory
            - For PROJECT/LOCAL/SESSION/TEAM: typically project root
        agent_type: Optional agent type for SESSION scope.
    """

    scope: MemoryScope
    base_dir: Path
    agent_type: str | None = None

    def resolve(self) -> Path:
        """Resolve the complete memory path.

        Returns:
            The resolved Path for memory storage.

        Raises:
            ValueError: If scope is unknown.
        """
        if self.scope == MemoryScope.USER:
            # User-global memory: ~/.pyclaw/memory/
            return self.base_dir / ".pyclaw" / "memory"
        elif self.scope == MemoryScope.PROJECT:
            # Project-specific memory: .pyclaw/memory/
            return self.base_dir / ".pyclaw" / "memory"
        elif self.scope == MemoryScope.LOCAL:
            # Local overrides: .pyclaw/memory-local/
            return self.base_dir / ".pyclaw" / "memory-local"
        elif self.scope == MemoryScope.SESSION:
            # Session-scoped storage: .pyclaw/sessions/{agent_type}/
            session_name = self.agent_type or "default"
            return self.base_dir / ".pyclaw" / "sessions" / session_name
        elif self.scope == MemoryScope.TEAM:
            # Team shared storage: .pyclaw/team/memory/
            return self.base_dir / ".pyclaw" / "team" / "memory"

        raise ValueError(f"Unknown scope: {self.scope}")

    def __str__(self) -> str:
        """Return string representation of the resolved path."""
        return str(self.resolve())
