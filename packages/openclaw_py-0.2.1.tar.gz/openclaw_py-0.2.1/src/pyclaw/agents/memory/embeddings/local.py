"""Local embedding provider using sentence-transformers.

This module provides a local embedding provider that runs entirely
on the local machine without external API calls.

Requirements:
    pip install sentence-transformers

Example:
    provider = LocalEmbeddingProvider(model="all-MiniLM-L6-v2")
    vectors = await provider.embed(["Hello", "World"])
"""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.memory.embedding import EmbeddingError, EmbeddingProvider

logger = logging.getLogger(__name__)

# Common sentence-transformer models and their dimensions
LOCAL_MODEL_DIMENSIONS: dict[str, int] = {
    # Fast and lightweight
    "all-MiniLM-L6-v2": 384,
    "paraphrase-MiniLM-L6-v2": 384,
    "all-MiniLM-L12-v2": 384,
    # Better quality
    "all-mpnet-base-v2": 768,
    "paraphrase-mpnet-base-v2": 768,
    "multi-qa-mpnet-base-dot-v1": 768,
    # Multilingual
    "paraphrase-multilingual-MiniLM-L12-v2": 384,
    "paraphrase-multilingual-mpnet-base-v2": 768,
    "distiluse-base-multilingual-cased-v2": 512,
    # Domain-specific
    "allenai/specter": 768,
    "sentence-t5-base": 768,
    "sentence-t5-large": 768,
    # Code-specific
    "codet5-base": 768,
}


class LocalEmbeddingProvider(EmbeddingProvider):
    """Local embedding provider using sentence-transformers.

    Runs embedding models locally without external API calls.
    Uses the sentence-transformers library for model loading and inference.

    Advantages:
    - No API costs
    - Privacy (data stays local)
    - Low latency (no network)
    - Offline capable

    Disadvantages:
    - Requires local compute resources
    - Model download on first use (~100MB-1GB)
    - May be slower for large batches without GPU

    Example:
        provider = LocalEmbeddingProvider(model="all-MiniLM-L6-v2")
        await provider.initialize()
        vectors = await provider.embed(["Hello", "World"])
    """

    def __init__(
        self,
        *,
        model: str = "all-MiniLM-L6-v2",
        device: str | None = None,
        cache_folder: str | None = None,
    ) -> None:
        """Initialize local embedding provider.

        Args:
            model: Model name from sentence-transformers (default: all-MiniLM-L6-v2).
                See https://www.sbert.net/docs/pretrained_models.html for options.
            device: Device to use (e.g., "cuda", "cpu", "mps"). Auto-detected if None.
            cache_folder: Folder to cache downloaded models.
        """
        self._model_name = model
        self._device = device
        self._cache_folder = cache_folder
        self._dimension = LOCAL_MODEL_DIMENSIONS.get(model, 384)  # Default to 384
        self._model: Any = None

    @property
    def name(self) -> str:
        return f"local:{self._model_name}"

    @property
    def dimension(self) -> int:
        return self._dimension

    async def initialize(self, **kwargs: Any) -> None:
        """Load the embedding model.

        Downloads the model on first use if not cached.
        """
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise EmbeddingError(
                "sentence-transformers is required for LocalEmbeddingProvider. "
                "Install it with: pip install sentence-transformers",
                provider=self.name,
            ) from e

        logger.info("Loading local embedding model: %s", self._model_name)

        # Load model in thread pool to avoid blocking
        import asyncio

        loop = asyncio.get_event_loop()
        self._model = await loop.run_in_executor(
            None,
            lambda: SentenceTransformer(
                self._model_name,
                device=self._device,
                cache_folder=self._cache_folder,
            ),
        )

        # Update dimension from model
        self._dimension = self._model.get_sentence_embedding_dimension()
        logger.info(
            "Local embedding provider initialized: model=%s, dimension=%d, device=%s",
            self._model_name,
            self._dimension,
            self._device or "auto",
        )

    async def shutdown(self) -> None:
        """Unload the model to free memory."""
        if self._model is not None:
            # Move model to CPU first if on GPU
            try:
                if hasattr(self._model, "to"):
                    self._model.to("cpu")
            except Exception:
                pass
            self._model = None
            logger.info("Local embedding provider shutdown: model unloaded")

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of embedding vectors.
        """
        if self._model is None:
            raise EmbeddingError(
                "Model not initialized. Call initialize() first.",
                provider=self.name,
            )

        import asyncio

        loop = asyncio.get_event_loop()

        # Run encoding in thread pool to avoid blocking
        embeddings = await loop.run_in_executor(
            None,
            lambda: self._model.encode(
                texts,
                convert_to_numpy=True,
                normalize_embeddings=True,  # L2 normalize
                show_progress_bar=False,
            ),
        )

        # Convert to list of lists
        return embeddings.tolist()

    async def embed_query(self, query: str) -> list[float]:
        """Generate embedding for a search query.

        Args:
            query: The search query string.

        Returns:
            Embedding vector for the query.
        """
        results = await self.embed([query])
        return results[0]

    def get_stats(self) -> dict[str, Any]:
        """Get provider statistics."""
        stats = super().get_stats()
        stats.update(
            {
                "model": self._model_name,
                "device": self._device or "auto",
                "dimension": self._dimension,
                "loaded": self._model is not None,
            }
        )
        return stats
