"""Embedding provider implementations.

This module provides concrete implementations of EmbeddingProvider ABC
that wrap the existing providers from pyclaw.memory.embeddings.

Design notes:
- Uses adapter pattern to bridge old and new architecture
- Providers are configurable via constructor or environment variables
- All embeddings are L2-normalized for consistency
"""

from __future__ import annotations

import logging
import os
from typing import Any, Literal

from pyclaw.agents.memory.embedding import EmbeddingError, EmbeddingProvider

logger = logging.getLogger(__name__)

# Model dimension mapping
OPENAI_DIMENSIONS: dict[str, int] = {
    "text-embedding-3-small": 1536,
    "text-embedding-3-large": 3072,
    "text-embedding-ada-002": 1536,
}

GEMINI_DIMENSIONS: dict[str, int] = {
    "text-embedding-004": 768,
    "embedding-001": 768,
}

VOYAGE_DIMENSIONS: dict[str, int] = {
    "voyage-3": 1024,
    "voyage-3-lite": 512,
    "voyage-2": 1024,
    "voyage-large-2": 1536,
}

MISTRAL_DIMENSIONS: dict[str, int] = {
    "mistral-embed": 1024,
}


class OpenAIEmbeddingProviderAdapter(EmbeddingProvider):
    """OpenAI embedding provider using text-embedding-3-* models.

    Wraps the existing OpenAI embedding implementation from
    pyclaw.memory.embeddings to conform to the new EmbeddingProvider ABC.

    Example:
        provider = OpenAIEmbeddingProviderAdapter(
            api_key="sk-...",
            model="text-embedding-3-small"
        )
        vectors = await provider.embed(["Hello", "World"])
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str = "text-embedding-3-small",
        base_url: str | None = None,
        dimension: int | None = None,
    ) -> None:
        """Initialize OpenAI embedding provider.

        Args:
            api_key: OpenAI API key. If None, reads from OPENAI_API_KEY env var.
            model: Model name (default: text-embedding-3-small).
            base_url: Optional base URL for API proxy.
            dimension: Optional dimension override (for truncated embeddings).
        """
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self._model = model
        self._base_url = base_url
        self._dimension = dimension or OPENAI_DIMENSIONS.get(model, 1536)
        self._client: Any = None

    @property
    def name(self) -> str:
        return f"openai:{self._model}"

    @property
    def dimension(self) -> int:
        return self._dimension

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the provider."""
        if not self._api_key:
            raise EmbeddingError(
                "OpenAI API key not provided. Set OPENAI_API_KEY or pass api_key parameter.",
                provider=self.name,
            )
        logger.info("OpenAI embedding provider initialized: model=%s, dimension=%d", self._model, self._dimension)

    async def shutdown(self) -> None:
        """Shutdown the provider."""
        self._client = None

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts."""
        import aiohttp

        if not self._api_key:
            raise EmbeddingError("API key not configured", provider=self.name)

        url = (self._base_url or "https://api.openai.com") + "/v1/embeddings"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        payload: dict[str, Any] = {"input": texts, "model": self._model}

        # Add dimension parameter if using truncated embeddings
        if self._dimension != OPENAI_DIMENSIONS.get(self._model, self._dimension):
            payload["dimensions"] = self._dimension

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, headers=headers) as resp:
                    data = await resp.json()
                    if "error" in data:
                        raise EmbeddingError(
                            f"OpenAI embedding error: {data['error']}",
                            provider=self.name,
                        )
                    # Sort by index to ensure order
                    embeddings = sorted(data["data"], key=lambda x: x["index"])
                    return [self._normalize(e["embedding"]) for e in embeddings]
        except aiohttp.ClientError as e:
            raise EmbeddingError(f"HTTP error: {e}", provider=self.name) from e

    async def embed_query(self, query: str) -> list[float]:
        """Generate embedding for a search query."""
        results = await self.embed([query])
        return results[0]

    def _normalize(self, vec: list[float]) -> list[float]:
        """L2-normalize a vector."""
        import math

        clean = [v if math.isfinite(v) else 0.0 for v in vec]
        norm = math.sqrt(sum(v * v for v in clean))
        if norm > 0:
            return [v / norm for v in clean]
        return clean


class GeminiEmbeddingProviderAdapter(EmbeddingProvider):
    """Google Gemini embedding provider.

    Wraps the existing Gemini embedding implementation from
    pyclaw.memory.embeddings to conform to the new EmbeddingProvider ABC.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str = "text-embedding-004",
    ) -> None:
        """Initialize Gemini embedding provider.

        Args:
            api_key: Google API key. If None, reads from GOOGLE_API_KEY env var.
            model: Model name (default: text-embedding-004).
        """
        self._api_key = api_key or os.environ.get("GOOGLE_API_KEY")
        self._model = model
        self._dimension = GEMINI_DIMENSIONS.get(model, 768)

    @property
    def name(self) -> str:
        return f"gemini:{self._model}"

    @property
    def dimension(self) -> int:
        return self._dimension

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the provider."""
        if not self._api_key:
            raise EmbeddingError(
                "Google API key not provided. Set GOOGLE_API_KEY or pass api_key parameter.",
                provider=self.name,
            )
        logger.info("Gemini embedding provider initialized: model=%s", self._model)

    async def shutdown(self) -> None:
        """Shutdown the provider."""
        pass

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts."""
        # Gemini API processes one text at a time
        return [await self.embed_query(t) for t in texts]

    async def embed_query(self, query: str) -> list[float]:
        """Generate embedding for a search query."""
        import math

        import aiohttp

        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self._model}:embedContent"
        params = {"key": self._api_key}
        payload = {
            "model": f"models/{self._model}",
            "content": {"parts": [{"text": query}]},
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, params=params) as resp:
                    data = await resp.json()
                    if "error" in data:
                        raise EmbeddingError(
                            f"Gemini embedding error: {data['error']}",
                            provider=self.name,
                        )
                    vec = data["embedding"]["values"]
                    # Normalize
                    norm = math.sqrt(sum(v * v for v in vec))
                    if norm > 0:
                        return [v / norm for v in vec]
                    return vec
        except aiohttp.ClientError as e:
            raise EmbeddingError(f"HTTP error: {e}", provider=self.name) from e


class OllamaEmbeddingProviderAdapter(EmbeddingProvider):
    """Ollama local embedding provider.

    Wraps the existing Ollama embedding implementation from
    pyclaw.memory.embeddings to conform to the new EmbeddingProvider ABC.
    """

    def __init__(
        self,
        *,
        base_url: str | None = None,
        model: str = "nomic-embed-text",
    ) -> None:
        """Initialize Ollama embedding provider.

        Args:
            base_url: Ollama API URL. If None, reads from OLLAMA_HOST env var
                or defaults to http://localhost:11434.
            model: Model name (default: nomic-embed-text).
        """
        ollama_host = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
        self._base_url = (base_url or ollama_host).rstrip("/")
        self._model = model
        self._dimension: int | None = None

    @property
    def name(self) -> str:
        return f"ollama:{self._model}"

    @property
    def dimension(self) -> int:
        return self._dimension or 768  # Default, will be set on first embed

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the provider and detect dimension."""
        # Try to detect dimension from model info
        try:
            import aiohttp

            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self._base_url}/api/show", params={"name": self._model}) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        # Try to extract embedding dimension from model info
                        if "model_info" in data:
                            # Different models store this differently
                            pass
        except Exception as e:
            logger.debug("Could not detect Ollama model dimension: %s", e)

        logger.info("Ollama embedding provider initialized: model=%s, base_url=%s", self._model, self._base_url)

    async def shutdown(self) -> None:
        """Shutdown the provider."""
        pass

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts."""
        import math

        import aiohttp

        url = f"{self._base_url}/api/embed"
        payload = {"model": self._model, "input": texts}

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload) as resp:
                    data = await resp.json()
                    if "error" in data:
                        raise EmbeddingError(
                            f"Ollama embedding error: {data['error']}",
                            provider=self.name,
                        )
                    embeddings = data.get("embeddings", [])
                    # Normalize and set dimension
                    result = []
                    for vec in embeddings:
                        norm = math.sqrt(sum(v * v for v in vec))
                        if norm > 0:
                            result.append([v / norm for v in vec])
                        else:
                            result.append(vec)
                        if self._dimension is None:
                            self._dimension = len(vec)
                    return result
        except aiohttp.ClientError as e:
            raise EmbeddingError(f"HTTP error: {e}", provider=self.name) from e

    async def embed_query(self, query: str) -> list[float]:
        """Generate embedding for a search query."""
        results = await self.embed([query])
        return results[0]


class VoyageEmbeddingProviderAdapter(EmbeddingProvider):
    """Voyage AI embedding provider.

    Wraps the existing Voyage embedding implementation from
    pyclaw.memory.embeddings to conform to the new EmbeddingProvider ABC.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str = "voyage-3",
    ) -> None:
        """Initialize Voyage embedding provider.

        Args:
            api_key: Voyage API key. If None, reads from VOYAGE_API_KEY env var.
            model: Model name (default: voyage-3).
        """
        self._api_key = api_key or os.environ.get("VOYAGE_API_KEY")
        self._model = model
        self._dimension = VOYAGE_DIMENSIONS.get(model, 1024)

    @property
    def name(self) -> str:
        return f"voyage:{self._model}"

    @property
    def dimension(self) -> int:
        return self._dimension

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the provider."""
        if not self._api_key:
            raise EmbeddingError(
                "Voyage API key not provided. Set VOYAGE_API_KEY or pass api_key parameter.",
                provider=self.name,
            )
        logger.info("Voyage embedding provider initialized: model=%s", self._model)

    async def shutdown(self) -> None:
        """Shutdown the provider."""
        pass

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts."""
        import aiohttp

        url = "https://api.voyageai.com/v1/embeddings"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        payload = {"input": texts, "model": self._model}

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, headers=headers) as resp:
                    data = await resp.json()
                    if "error" in data:
                        raise EmbeddingError(
                            f"Voyage embedding error: {data['error']}",
                            provider=self.name,
                        )
                    embeddings = sorted(data["data"], key=lambda x: x["index"])
                    return [self._normalize(e["embedding"]) for e in embeddings]
        except aiohttp.ClientError as e:
            raise EmbeddingError(f"HTTP error: {e}", provider=self.name) from e

    async def embed_query(self, query: str) -> list[float]:
        """Generate embedding for a search query."""
        results = await self.embed([query])
        return results[0]

    def _normalize(self, vec: list[float]) -> list[float]:
        """L2-normalize a vector."""
        import math

        norm = math.sqrt(sum(v * v for v in vec))
        if norm > 0:
            return [v / norm for v in vec]
        return vec


class MistralEmbeddingProviderAdapter(EmbeddingProvider):
    """Mistral embedding provider.

    Wraps the existing Mistral embedding implementation from
    pyclaw.memory.embeddings to conform to the new EmbeddingProvider ABC.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str = "mistral-embed",
    ) -> None:
        """Initialize Mistral embedding provider.

        Args:
            api_key: Mistral API key. If None, reads from MISTRAL_API_KEY env var.
            model: Model name (default: mistral-embed).
        """
        self._api_key = api_key or os.environ.get("MISTRAL_API_KEY")
        self._model = model
        self._dimension = MISTRAL_DIMENSIONS.get(model, 1024)

    @property
    def name(self) -> str:
        return f"mistral:{self._model}"

    @property
    def dimension(self) -> int:
        return self._dimension

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the provider."""
        if not self._api_key:
            raise EmbeddingError(
                "Mistral API key not provided. Set MISTRAL_API_KEY or pass api_key parameter.",
                provider=self.name,
            )
        logger.info("Mistral embedding provider initialized: model=%s", self._model)

    async def shutdown(self) -> None:
        """Shutdown the provider."""
        pass

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts."""
        import aiohttp

        url = "https://api.mistral.ai/v1/embeddings"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        payload = {"input": texts, "model": self._model}

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, headers=headers) as resp:
                    data = await resp.json()
                    if "error" in data:
                        raise EmbeddingError(
                            f"Mistral embedding error: {data['error']}",
                            provider=self.name,
                        )
                    embeddings = sorted(data["data"], key=lambda x: x["index"])
                    return [self._normalize(e["embedding"]) for e in embeddings]
        except aiohttp.ClientError as e:
            raise EmbeddingError(f"HTTP error: {e}", provider=self.name) from e

    async def embed_query(self, query: str) -> list[float]:
        """Generate embedding for a search query."""
        results = await self.embed([query])
        return results[0]

    def _normalize(self, vec: list[float]) -> list[float]:
        """L2-normalize a vector."""
        import math

        norm = math.sqrt(sum(v * v for v in vec))
        if norm > 0:
            return [v / norm for v in vec]
        return vec


# Type alias for provider selection
EmbeddingProviderType = Literal["openai", "gemini", "voyage", "mistral", "ollama", "auto"]


async def create_embedding_provider(
    provider: EmbeddingProviderType = "auto",
    *,
    model: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    config: dict[str, Any] | None = None,
) -> EmbeddingProvider:
    """Create an embedding provider.

    Factory function that creates the appropriate embedding provider
    based on configuration and available credentials.

    Args:
        provider: Provider type. "auto" tries providers in order.
        model: Optional model name override.
        api_key: Optional API key override.
        base_url: Optional base URL override.
        config: Optional configuration dict.

    Returns:
        EmbeddingProvider instance.

    Raises:
        EmbeddingError: If no provider can be created.
    """
    config = config or {}

    def _try_openai() -> EmbeddingProvider | None:
        key = api_key or os.environ.get("OPENAI_API_KEY")
        if key:
            return OpenAIEmbeddingProviderAdapter(
                api_key=key,
                model=model or "text-embedding-3-small",
                base_url=base_url,
            )
        return None

    def _try_gemini() -> EmbeddingProvider | None:
        key = api_key or os.environ.get("GOOGLE_API_KEY")
        if key:
            return GeminiEmbeddingProviderAdapter(
                api_key=key,
                model=model or "text-embedding-004",
            )
        return None

    def _try_voyage() -> EmbeddingProvider | None:
        key = api_key or os.environ.get("VOYAGE_API_KEY")
        if key:
            return VoyageEmbeddingProviderAdapter(
                api_key=key,
                model=model or "voyage-3",
            )
        return None

    def _try_mistral() -> EmbeddingProvider | None:
        key = api_key or os.environ.get("MISTRAL_API_KEY")
        if key:
            return MistralEmbeddingProviderAdapter(
                api_key=key,
                model=model or "mistral-embed",
            )
        return None

    def _try_ollama() -> EmbeddingProvider | None:
        ollama_host = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
        url = base_url if base_url is not None else ollama_host
        # Try to connect
        try:
            import urllib.request

            req = urllib.request.Request(f"{url}/api/tags")
            with urllib.request.urlopen(req, timeout=2) as resp:
                if resp.status < 500:
                    return OllamaEmbeddingProviderAdapter(
                        base_url=url,
                        model=model or "nomic-embed-text",
                    )
        except Exception:
            pass
        return None

    factories = {
        "openai": _try_openai,
        "gemini": _try_gemini,
        "voyage": _try_voyage,
        "mistral": _try_mistral,
        "ollama": _try_ollama,
    }

    if provider != "auto":
        p = factories.get(provider, lambda: None)()
        if p:
            await p.initialize()
            return p
        raise EmbeddingError(f"Could not create {provider} embedding provider")

    # Auto: try providers in preference order
    for pid in ("openai", "gemini", "voyage", "mistral", "ollama"):
        p = factories[pid]()
        if p:
            await p.initialize()
            logger.info("Auto-selected embedding provider: %s", p.name)
            return p

    raise EmbeddingError(
        "No embedding provider available. Set an API key for OpenAI, Google, Voyage, or Mistral, or run Ollama locally."
    )
