"""Memory system for agent context persistence.

This package provides the memory provider system for storing and
retrieving agent context across sessions.

Key components:
- MemoryScope: Enum for memory storage scopes
- MemoryPath: Path resolver for memory locations
- MemoryProvider: ABC for memory backends
- MemoryEntry: Single memory entry dataclass
- EmbeddingProvider: ABC for embedding providers
- Capability registration: register_memory_capability, get_memory_provider
"""

from pyclaw.agents.definition import MemoryScope
from pyclaw.agents.memory.capability import (
    get_memory_provider,
    list_memory_capabilities,
    register_memory_capability,
    unregister_memory_capability,
)
from pyclaw.agents.memory.embedding import EmbeddingError, EmbeddingProvider
from pyclaw.agents.memory.provider import MemoryEntry, MemoryProvider
from pyclaw.agents.memory.scope import MemoryPath

__all__ = [
    # Scope and path
    "MemoryScope",
    "MemoryPath",
    # Provider
    "MemoryProvider",
    "MemoryEntry",
    # Embedding
    "EmbeddingProvider",
    "EmbeddingError",
    # Capability registration
    "register_memory_capability",
    "get_memory_provider",
    "unregister_memory_capability",
    "list_memory_capabilities",
]
