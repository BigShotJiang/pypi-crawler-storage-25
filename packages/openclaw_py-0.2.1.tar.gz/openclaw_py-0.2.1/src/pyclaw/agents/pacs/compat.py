"""PACS compatibility layer — bridges with existing capability registry."""

from __future__ import annotations

from pyclaw.agents.capabilities.types import CapabilityType
from pyclaw.agents.pacs.types import CapabilityLayer

LAYER_TO_CAPABILITY_TYPE: dict[CapabilityLayer, CapabilityType] = {
    CapabilityLayer.PERCEPTION: CapabilityType.PERCEPTION,
    CapabilityLayer.REASONING: CapabilityType.REASONING,
    CapabilityLayer.ACTION: CapabilityType.ACTION,
    CapabilityLayer.FEEDBACK: CapabilityType.FEEDBACK,
    CapabilityLayer.INFRASTRUCTURE: CapabilityType.ORCHESTRATION,
}


def layer_to_capability_type(layer: CapabilityLayer) -> CapabilityType:
    """Convert a PACS CapabilityLayer to a CapabilityType for the legacy registry."""
    return LAYER_TO_CAPABILITY_TYPE[layer]
