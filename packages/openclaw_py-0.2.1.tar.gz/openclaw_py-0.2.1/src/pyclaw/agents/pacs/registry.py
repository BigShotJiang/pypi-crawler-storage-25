"""CapabilityRegistry — singleton factory for PACS capability classes.

Migrated to use SingletonRegistry mixin from multiagent.registry (Phase 03).
"""

from __future__ import annotations

import logging
from typing import Any, ClassVar

from pyclaw.agents.multiagent.registry import SingletonRegistry
from pyclaw.agents.pacs.capability import AgenticCapability

logger = logging.getLogger(__name__)


class CapabilityRegistry(SingletonRegistry[str, type[AgenticCapability]]):
    """Registry for capability classes with factory method.

    Maps capability names to their classes, allowing instantiation
    from configuration dicts.

    Extends SingletonRegistry for global singleton behavior.

    Note:
        Key type is `str` (capability name).
        Value type is `type[AgenticCapability]` (the class, not instance).

    Example:
        >>> registry = CapabilityRegistry.get_instance()
        >>> cap = registry.create("circuit_breaker", failure_threshold=5)
    """

    # Required: re-declare _instance for this subclass
    _instance: ClassVar[CapabilityRegistry | None] = None

    def __init__(self) -> None:
        self._registry: dict[str, type[AgenticCapability]] = {}
        self._register_builtins()

    def register(self, name: str, capability_class: type[AgenticCapability]) -> None:
        """Register a capability class by name."""
        self._registry[name] = capability_class
        logger.debug("Registered capability: %s -> %s", name, capability_class.__name__)

    def get(self, name: str) -> type[AgenticCapability]:
        """Get the capability class by name.

        Raises:
            KeyError: If name is not registered.
        """
        return self._registry[name]

    def create(self, name: str, **kwargs: Any) -> AgenticCapability:
        """Create a capability instance by name with optional kwargs.

        This is a domain-specific method not in the base Registry.

        Args:
            name: Registered capability name.
            **kwargs: Override constructor parameters.

        Returns:
            Instantiated capability.

        Raises:
            KeyError: If name is not registered.
        """
        cls = self._registry.get(name)
        if cls is None:
            raise KeyError(f"Unknown capability: {name}. Registered: {list(self._registry.keys())}")
        return cls(**kwargs)

    def list_all(self) -> list[type[AgenticCapability]]:
        """List all registered capability classes."""
        return list(self._registry.values())

    def list_keys(self) -> list[str]:
        """List all registered capability names."""
        return sorted(self._registry.keys())

    # Backward-compatible alias
    list_capabilities = list_keys

    def clear(self) -> None:
        """Clear all registered capabilities."""
        self._registry.clear()

    def __contains__(self, name: str) -> bool:
        """Check if a capability is registered."""
        return name in self._registry

    def __len__(self) -> int:
        """Return the number of registered capabilities."""
        return len(self._registry)

    def _register_builtins(self) -> None:
        """Register all built-in PACS capabilities."""
        from pyclaw.agents.pacs.capabilities import (
            ActionValidator,
            AutoImprovementLoop,
            CircuitBreaker,
            CollaborationBus,
            ContextWindowManager,
            DualLLM,
            MemorySynthesis,
            MetaCognitionMonitor,
            ModelRouter,
            OutputGroundingCheck,
            ParallelToolExecutor,
            PhaseSeparation,
            PlanExecute,
            PromptTemplateManager,
            ReActController,
            ReflectionLoop,
            SelfCritique,
            SemanticFilter,
            ToolOutputParser,
            ToolRetryBackoff,
            TraceQualityMonitor,
            UserIntentClassifier,
        )

        builtin_classes: list[type[AgenticCapability]] = [
            ActionValidator,
            AutoImprovementLoop,
            CircuitBreaker,
            CollaborationBus,
            ContextWindowManager,
            DualLLM,
            MemorySynthesis,
            MetaCognitionMonitor,
            ModelRouter,
            OutputGroundingCheck,
            ParallelToolExecutor,
            PhaseSeparation,
            PlanExecute,
            PromptTemplateManager,
            ReActController,
            ReflectionLoop,
            SelfCritique,
            SemanticFilter,
            ToolOutputParser,
            ToolRetryBackoff,
            TraceQualityMonitor,
            UserIntentClassifier,
        ]
        for cap_cls in builtin_classes:
            instance = cap_cls()
            self.register(instance.name, cap_cls)
