"""AgentEventBus — capability registration and event dispatch with priority ordering."""

from __future__ import annotations

import logging
from collections import defaultdict
from copy import deepcopy

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Fields on HookEvent that capabilities are allowed to modify directly.
# Anything not in this list is silently ignored by _apply_modifications.
# Note: context_modifications is intentionally NOT mutable - it's a control
# directive, not data, and allowing modification would let capabilities
# interfere with each other's context modification requests.
_MUTABLE_EVENT_FIELDS: frozenset[str] = frozenset(
    {
        "messages",
        "tool_call",
        "tool_result",
        "llm_response",
    },
)

# Retry budget per (hook, originator) pair to prevent infinite retry loops.
_MAX_RETRIES: int = 3


class AgentEventBus:
    """Event bus managing capability registration and event dispatch.

    Capabilities register for specific HookPoints. When an event is emitted,
    all subscribed capabilities are invoked in priority order (lower = earlier).
    Control flow signals (SKIP, ABORT, RETRY) affect dispatch behavior.
    """

    def __init__(self) -> None:
        self._subscribers: dict[HookPoint, list[AgenticCapability]] = defaultdict(list)
        self._retry_counts: dict[tuple[HookPoint, str], int] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, capability: AgenticCapability) -> None:
        """Register a capability for all its subscribed hooks.

        The capability is inserted in priority-sorted order within each hook
        list (lower priority value runs first).

        Args:
            capability: The capability instance to register.
        """
        for hook in capability.subscribed_hooks:
            subs = self._subscribers[hook]
            subs.append(capability)
            subs.sort(key=lambda c: c.priority)

    def unregister(self, name: str) -> None:
        """Remove a capability by name from all hooks.

        Args:
            name: The unique name of the capability to remove.
        """
        for hook, subs in self._subscribers.items():
            self._subscribers[hook] = [c for c in subs if c.name != name]

    # ------------------------------------------------------------------
    # Event dispatch
    # ------------------------------------------------------------------

    async def emit(
        self,
        hook: HookPoint,
        event: HookEvent,
        context: AgentContext,
    ) -> list[CapabilityResult]:
        """Dispatch an event to all capabilities subscribed to *hook*.

        Capabilities are invoked in priority order. Each capability's
        ``should_activate`` is checked; if False, the capability is skipped.
        Otherwise ``on_event`` is called and the result is processed:

        - CONTINUE: apply modifications, continue to next capability.
        - SKIP: apply modifications, stop dispatching further capabilities.
        - ABORT: apply modifications, stop dispatching and return.
        - RETRY: delegate to ``_handle_retry``.

        If a capability raises an exception:
        - If ``critical=True``, an ABORT result is appended.
        - Otherwise, a CONTINUE result (with error info) is appended and
          dispatch continues.

        Args:
            hook: The hook point to emit.
            event: The event payload (may be mutated by capabilities).
            context: Session-scoped shared context (may be mutated).

        Returns:
            List of CapabilityResult from executed capabilities.
        """
        results: list[CapabilityResult] = []
        subs = self._subscribers.get(hook, [])

        for cap in subs:
            # --- should_activate gate ---
            try:
                active = await cap.should_activate(event, context)
            except Exception:
                logger.exception(
                    "should_activate raised for %s on %s",
                    cap.name,
                    hook.value,
                )
                continue

            if not active:
                continue

            # --- on_event execution ---
            try:
                result = await cap.on_event(event, context)
            except Exception as exc:
                logger.exception(
                    "on_event raised for %s on %s",
                    cap.name,
                    hook.value,
                )
                if cap.critical:
                    results.append(
                        CapabilityResult(
                            action=CapabilityAction.ABORT,
                            capability_name=cap.name,
                            output=str(exc),
                        ),
                    )
                    return results
                else:
                    results.append(
                        CapabilityResult(
                            action=CapabilityAction.CONTINUE,
                            capability_name=cap.name,
                            output=f"error: {exc}",
                        ),
                    )
                    continue

            result.capability_name = cap.name
            results.append(result)

            # --- apply modifications ---
            self._apply_modifications(event, context, result)

            # --- control flow ---
            if result.action == CapabilityAction.SKIP:
                break
            elif result.action == CapabilityAction.ABORT:
                return results
            elif result.action == CapabilityAction.RETRY:
                retry_results = await self._handle_retry(hook, event, context, cap)
                results.extend(retry_results)
                break

        return results

    # ------------------------------------------------------------------
    # Modification application
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_modifications(
        event: HookEvent,
        context: AgentContext,
        result: CapabilityResult,
    ) -> None:
        """Apply event and context modifications from a CapabilityResult.

        Event modifications are filtered by the _MUTABLE_EVENT_FIELDS whitelist.
        Context modifications are delegated to AgentContext.apply_modifications.

        Args:
            event: The event to potentially mutate.
            context: The context to potentially mutate.
            result: The result containing modification dicts.
        """
        # Apply event modifications (whitelist filter)
        if result.event_modifications:
            for key, value in result.event_modifications.items():
                if key in _MUTABLE_EVENT_FIELDS:
                    setattr(event, key, value)

        # Apply context modifications
        if result.context_modifications:
            context.apply_modifications(result.context_modifications)

    # ------------------------------------------------------------------
    # Retry handling
    # ------------------------------------------------------------------

    async def _handle_retry(
        self,
        hook: HookPoint,
        event: HookEvent,
        context: AgentContext,
        originator: AgenticCapability,
    ) -> list[CapabilityResult]:
        """Handle a RETRY action by incrementing a counter and re-emitting.

        If the retry budget is exhausted, returns an ABORT result instead.

        Args:
            hook: The original hook point.
            event: The event (may have been modified).
            context: The session context.
            originator: The capability that requested the retry.

        Returns:
            Results from the re-emission, or an ABORT result if budget exceeded.
        """
        key = (hook, originator.name)
        count = self._retry_counts.get(key, 0) + 1
        self._retry_counts[key] = count

        if count > _MAX_RETRIES:
            logger.warning(
                "Retry budget exhausted for %s on %s (%d attempts)",
                originator.name,
                hook.value,
                count,
            )
            return [
                CapabilityResult(
                    action=CapabilityAction.ABORT,
                    capability_name=originator.name,
                    output="retry_budget_exhausted",
                ),
            ]

        # Re-emit with a copy of the event to avoid double-mutation issues
        retry_event = deepcopy(event)
        return await self.emit(hook, retry_event, context)
