"""PACS — PyClaw Agentic Capability Stack.

Event-driven, plugin-based capability system for agentic patterns.
"""

from pyclaw.agents.pacs.bus import AgentEventBus
from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.compat import LAYER_TO_CAPABILITY_TYPE, layer_to_capability_type
from pyclaw.agents.pacs.config import load_and_setup, load_capabilities, setup_bus
from pyclaw.agents.pacs.recipes import (
    Recipe,
    build_recipe,
    get_recipe,
    list_recipes,
    register_recipe,
)
from pyclaw.agents.pacs.registry import CapabilityRegistry
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

__all__ = [
    "AgentContext",
    "AgentEventBus",
    "AgenticCapability",
    "CapabilityAction",
    "CapabilityRegistry",
    "CapabilityLayer",
    "CapabilityResult",
    "HookEvent",
    "HookPoint",
    "LAYER_TO_CAPABILITY_TYPE",
    "Recipe",
    "build_recipe",
    "get_recipe",
    "layer_to_capability_type",
    "list_recipes",
    "load_and_setup",
    "load_capabilities",
    "register_recipe",
    "setup_bus",
]
