"""PACS core types — HookPoint, CapabilityLayer, CapabilityAction, HookEvent, AgentContext, CapabilityResult."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar

if TYPE_CHECKING:
    from pyclaw.agents.pacs.bus import AgentEventBus


class HookPoint(str, Enum):
    """Agent lifecycle hook points."""

    SESSION_INIT = "session.init"
    SESSION_END = "session.end"

    TURN_START = "turn.start"
    TURN_END = "turn.end"

    PERCEPTION_PRE = "perception.pre"
    PERCEPTION_OBSERVATION = "perception.observation"

    LLM_PRE_INVOKE = "llm.pre_invoke"
    LLM_POST_RESPONSE = "llm.post_response"
    LLM_ERROR = "llm.error"

    TOOL_PRE_EXECUTE = "tool.pre_execute"
    TOOL_EXECUTION = "tool.execution"
    TOOL_POST_EXECUTE = "tool.post_execute"
    TOOL_ERROR = "tool.error"

    # Subagent lifecycle hooks (multiagent coordination)
    SUBAGENT_SPAWN = "subagent.spawn"
    SUBAGENT_PROGRESS = "subagent.progress"
    SUBAGENT_COMPLETE = "subagent.complete"
    SUBAGENT_ERROR = "subagent.error"
    MODE_SWITCH = "mode.switch"


class CapabilityLayer(str, Enum):
    """Capability logical layer for grouping and display."""

    PERCEPTION = "perception"
    REASONING = "reasoning"
    ACTION = "action"
    FEEDBACK = "feedback"
    INFRASTRUCTURE = "infrastructure"


class CapabilityAction(str, Enum):
    """Capability return action signal."""

    CONTINUE = "continue"
    SKIP = "skip"
    RETRY = "retry"
    ABORT = "abort"


@dataclass
class HookEvent:
    """Event payload for the capability system."""

    hook: HookPoint
    timestamp: float

    # Mutable data — capabilities may modify
    messages: list[dict] | None = None
    tool_call: Any | None = None
    tool_result: Any | None = None
    llm_response: dict | None = None
    context_modifications: dict[str, Any] | None = None

    # Read-only metadata
    turn: int = 0
    session_id: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    # Error flow
    error: Exception | None = None
    error_type: str | None = None


@dataclass
class AgentContext:
    """Session-scoped shared context for capabilities."""

    session_id: str
    user_id: str | None = None
    workspace: Path | None = None

    # Mutable task state
    task_complexity: float = 0.0
    current_phase: str = "perception"
    active_plan: dict | None = None

    # Memory slots
    short_term_memory: dict[str, Any] = field(default_factory=dict)
    working_memory: list[dict] = field(default_factory=list)
    long_term_memory_refs: list[str] = field(default_factory=list)

    # Capability communication slot
    capability_state: dict[str, Any] = field(default_factory=dict)

    # Read-only config
    agent_definition: Any | None = None
    model_config: Any | None = None

    # EventBus reference for runner integration
    pacs_bus: AgentEventBus | None = None

    _MUTABLE_ATTRS: ClassVar = frozenset(
        {
            "task_complexity",
            "current_phase",
            "active_plan",
            "short_term_memory",
            "working_memory",
            "long_term_memory_refs",
        }
    )

    def apply_modifications(self, modifications: dict[str, Any]) -> None:
        """Apply modifications from CapabilityResult.context_modifications.

        Distinguishes attribute writes from state dict writes:
        - Known mutable attrs → setattr
        - Everything else → capability_state dict
        """
        for key, value in modifications.items():
            if key in self._MUTABLE_ATTRS:
                setattr(self, key, value)
            else:
                self.capability_state[key] = value

    def set(self, key: str, value: Any, slot: str = "capability_state") -> None:
        """Explicit write to capability_state for inter-capability communication."""
        getattr(self, slot)[key] = value

    def get(self, key: str, default: Any = None, slot: str = "capability_state") -> Any:
        """Read from a state slot."""
        return getattr(self, slot).get(key, default)


@dataclass
class CapabilityResult:
    """Return value from a capability execution."""

    action: CapabilityAction = CapabilityAction.CONTINUE
    event_modifications: dict[str, Any] = field(default_factory=dict)
    context_modifications: dict[str, Any] = field(default_factory=dict)
    output: Any = None
    output_type: str | None = None
    capability_name: str = ""
    duration_ms: float = 0.0
    metrics: dict[str, Any] = field(default_factory=dict)
