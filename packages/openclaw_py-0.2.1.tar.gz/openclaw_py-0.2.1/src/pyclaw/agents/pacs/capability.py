"""AgenticCapability — abstract base class for all PACS capabilities."""

from __future__ import annotations

from abc import ABC, abstractmethod

from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)


class AgenticCapability(ABC):
    """Base class for all agentic capabilities.

    Subclasses must define:
    - name: unique identifier
    - layer: logical layer grouping
    - subscribed_hooks: which hook points to subscribe to
    - should_activate: conditional activation logic
    - on_event: main capability logic

    Optional overrides:
    - priority: execution order (higher = later, default 50)
    - critical: if True, failure aborts the turn
    - setup: session initialization
    - teardown: session cleanup
    """

    name: str
    layer: CapabilityLayer
    subscribed_hooks: list[HookPoint]
    priority: int = 50
    critical: bool = False

    @abstractmethod
    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Whether this capability should execute for the given event.

        Args:
            event: The hook event with payload data
            context: Session-scoped shared context

        Returns:
            True if the capability should run, False to skip
        """
        ...

    @abstractmethod
    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Execute capability logic and return result.

        This method is called only if should_activate returned True.

        Args:
            event: The hook event with payload data (can be modified)
            context: Session-scoped shared context (can be modified)

        Returns:
            CapabilityResult with action signal and optional modifications
        """
        ...

    async def setup(self, context: AgentContext) -> None:
        """Initialize capability for a session. Override if needed.

        Called once per session before any hooks fire.

        Args:
            context: Session-scoped shared context, can store setup state
        """
        pass

    async def teardown(self, context: AgentContext) -> None:
        """Clean up capability after a session. Override if needed.

        Called once per session after all hooks complete.

        Args:
            context: Session-scoped shared context, can read and clear state
        """
        pass
