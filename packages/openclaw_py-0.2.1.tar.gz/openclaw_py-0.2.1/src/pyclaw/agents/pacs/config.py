"""Configuration loader for PACS capabilities.

Supports loading capabilities from dict configs (YAML/JSON-friendly):
- Recipe-based: reference a predefined recipe by name
- Direct list: specify individual capabilities
- Parameter overrides on recipe capabilities
- Exclude capabilities from a recipe
- Add extra capabilities on top of a recipe (hybrid mode)
"""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.pacs.bus import AgentEventBus
from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.recipes import build_recipe
from pyclaw.agents.pacs.registry import CapabilityRegistry

logger = logging.getLogger(__name__)


def load_capabilities(config: dict[str, Any]) -> list[AgenticCapability]:
    """Load capabilities from a configuration dict.

    Config format::

        {
            "recipe": "react_agent",           # Optional: use predefined recipe
            "overrides": {                      # Optional: override recipe params
                "circuit_breaker": {"failure_threshold": 5}
            },
            "extra_capabilities": [             # Optional: add more capabilities
                {"name": "tool_output_parser", "params": {"max_length": 5000}}
            ],
            "exclude": ["semantic_filter"],     # Optional: remove capabilities
        }

    Or direct list::

        {
            "capabilities": [
                {"name": "semantic_filter"},
                {"name": "react_controller", "params": {"system_prompt": "..."}},
            ]
        }

    Args:
        config: Configuration dictionary.

    Returns:
        List of instantiated capabilities.
    """
    registry = CapabilityRegistry.get_instance()
    capabilities: list[AgenticCapability] = []

    # Mode 1: Recipe-based
    if "recipe" in config:
        recipe_name = config["recipe"]
        capabilities = build_recipe(recipe_name)

        # Apply overrides
        overrides = config.get("overrides", {})
        for cap in capabilities:
            if cap.name in overrides:
                _apply_overrides(cap, overrides[cap.name])

        # Exclude
        excludes = set(config.get("exclude", []))
        if excludes:
            capabilities = [c for c in capabilities if c.name not in excludes]

    # Mode 2: Direct list
    elif "capabilities" in config:
        for cap_config in config["capabilities"]:
            name = cap_config["name"]
            params = cap_config.get("params", {})
            cap = registry.create(name, **params)
            capabilities.append(cap)

    # Add extra capabilities (works in both modes)
    for extra in config.get("extra_capabilities", []):
        name = extra["name"]
        params = extra.get("params", {})
        cap = registry.create(name, **params)
        capabilities.append(cap)

    logger.info("Loaded %d capabilities from config", len(capabilities))
    return capabilities


def setup_bus(capabilities: list[AgenticCapability]) -> AgentEventBus:
    """Create a bus and register all capabilities.

    Args:
        capabilities: List of capabilities to register.

    Returns:
        Configured AgentEventBus.
    """
    bus = AgentEventBus()
    for cap in capabilities:
        bus.register(cap)
    logger.info("Registered %d capabilities on EventBus", len(capabilities))
    return bus


def load_and_setup(config: dict[str, Any]) -> tuple[AgentEventBus, list[AgenticCapability]]:
    """Load capabilities and setup bus in one call.

    Args:
        config: Configuration dictionary.

    Returns:
        Tuple of (EventBus, capabilities list).
    """
    capabilities = load_capabilities(config)
    bus = setup_bus(capabilities)
    return bus, capabilities


def _apply_overrides(capability: AgenticCapability, overrides: dict[str, Any]) -> None:
    """Apply parameter overrides to an already-instantiated capability.

    Only attributes that already exist on the capability are modified.
    Unknown keys are logged as warnings and silently skipped.

    Args:
        capability: The capability instance to modify.
        overrides: Dict of attribute-name -> new-value pairs.
    """
    for key, value in overrides.items():
        if hasattr(capability, key):
            setattr(capability, key, value)
        else:
            logger.warning(
                "Override key '%s' not found on capability '%s'",
                key,
                capability.name,
            )
