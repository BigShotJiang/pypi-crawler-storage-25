"""MemorySynthesis -- feedback-layer capability for extracting key findings.

Extracts key findings from assistant messages at the end of each turn and
stores them as structured records in long-term memory. The extraction uses
heuristic sentence classification to identify factual claims, decisions, and
insights.

Classification rules (heuristic MVP):
  - Sentences containing "is" / "are" / "means" / "defined" / "refers to"
    are classified as "fact".
  - Sentences containing "should" / "recommend" / "best" / "suggest"
    are classified as "decision".
  - Remaining sentences longer than ``min_sentence_length`` characters
    are classified as "insight".

Args:
    max_findings_per_turn: Maximum number of findings extracted per turn.
        Default 5.
    min_sentence_length: Minimum character length for a sentence to be
        considered as an insight. Default 20.
"""

from __future__ import annotations

import json
import logging
import re
import time

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Key used in context.capability_state for the accumulated log
_KEY_LOG = "_memory_synthesis_log"

# Sentence-ending punctuation used for splitting
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")

# Classification keyword sets (lowercased)
_FACT_KEYWORDS: frozenset[str] = frozenset(
    {"is", "are", "means", "defined", "refers to"},
)
_DECISION_KEYWORDS: frozenset[str] = frozenset(
    {"should", "recommend", "best", "suggest"},
)


class MemorySynthesis(AgenticCapability):
    """Feedback-layer capability that extracts key findings from turns.

    Subscribes to TURN_END at priority 85 (after most feedback processing)
    so it can observe the final state of each turn's messages.

    Extracted findings are stored in:
      - ``context.long_term_memory_refs`` as JSON strings
      - ``context.capability_state["_memory_synthesis_log"]`` as dicts
    """

    name = "memory_synthesis"
    layer = CapabilityLayer.FEEDBACK
    subscribed_hooks: list[HookPoint] = [HookPoint.TURN_END]
    priority = 85  # after most feedback
    critical = False

    def __init__(
        self,
        max_findings_per_turn: int = 5,
        min_sentence_length: int = 20,
    ) -> None:
        self.max_findings_per_turn = max_findings_per_turn
        self.min_sentence_length = min_sentence_length

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """MemorySynthesis is always active on TURN_END."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Extract findings from the last assistant message and store them."""
        text = self._extract_last_assistant_text(event)
        if not text:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={"findings_count": 0},
            )

        sentences = _split_sentences(text)
        findings = self._classify_sentences(
            sentences,
            turn=event.turn,
            source=_infer_source(event),
        )

        if not findings:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={"findings_count": 0},
            )

        # Store in capability_state log
        log: list[dict] = list(context.get(_KEY_LOG, []))
        log.extend(findings)

        # Build context modifications
        # long_term_memory_refs is list[str], so serialize findings as JSON
        memory_refs: list[str] = list(context.long_term_memory_refs)
        memory_refs.extend(json.dumps(f, ensure_ascii=False) for f in findings)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={
                "long_term_memory_refs": memory_refs,
                _KEY_LOG: log,
            },
            metrics={"findings_count": len(findings)},
        )

    # ------------------------------------------------------------------
    # Extraction helpers (public for testability)
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_last_assistant_text(event: HookEvent) -> str:
        """Extract text from the last assistant message in the event.

        Args:
            event: The TURN_END hook event.

        Returns:
            The assistant message content, or empty string if none found.
        """
        messages = event.messages or []
        # Iterate in reverse to find the last assistant message
        for msg in reversed(messages):
            if msg.get("role") != "assistant":
                continue
            content = msg.get("content", "")
            return _content_to_text(content)
        return ""

    def _classify_sentences(
        self,
        sentences: list[str],
        turn: int,
        source: str,
    ) -> list[dict]:
        """Classify sentences into findings up to max_findings_per_turn.

        Args:
            sentences: List of sentence strings.
            turn: Current turn number.
            source: Source label (e.g. "assistant" or "tool:api_docs").

        Returns:
            List of finding dicts with turn, type, content, source, timestamp.
        """
        findings: list[dict] = []
        now = time.time()

        for sentence in sentences:
            if len(findings) >= self.max_findings_per_turn:
                break

            finding_type = _classify_sentence(sentence, self.min_sentence_length)
            if finding_type is None:
                continue

            findings.append(
                {
                    "turn": turn,
                    "type": finding_type,
                    "content": sentence.strip(),
                    "source": source,
                    "timestamp": now,
                }
            )

        return findings


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------


def _split_sentences(text: str) -> list[str]:
    """Split text into sentences using punctuation boundaries.

    Args:
        text: The full text to split.

    Returns:
        List of sentence strings (non-empty after stripping).
    """
    parts = _SENTENCE_SPLIT_RE.split(text)
    return [p.strip() for p in parts if p.strip()]


def _classify_sentence(
    sentence: str,
    min_length: int,
) -> str | None:
    """Classify a single sentence into a finding type.

    Args:
        sentence: The sentence to classify.
        min_length: Minimum length for "insight" classification.

    Returns:
        "fact", "decision", "insight", or None if the sentence should be skipped.
    """
    text_lower = sentence.lower()

    # Check for fact keywords
    for keyword in _FACT_KEYWORDS:
        # Use word-boundary check for single-word keywords
        if keyword in text_lower:
            return "fact"

    # Check for decision keywords
    for keyword in _DECISION_KEYWORDS:
        if keyword in text_lower:
            return "decision"

    # Check for insight (long enough but no specific keywords)
    if len(sentence.strip()) > min_length:
        return "insight"

    return None


def _content_to_text(content: object) -> str:
    """Extract plain text from message content.

    Content may be a plain string or a list of content blocks.

    Args:
        content: The raw message content value.

    Returns:
        Extracted text, or empty string.
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        return " ".join(parts)
    return str(content)


def _infer_source(event: HookEvent) -> str:
    """Infer the source label from the event payload.

    Args:
        event: The hook event.

    Returns:
        A source string like "tool:api_docs" or "assistant".
    """
    if event.tool_call is not None:
        tool_name = ""
        if isinstance(event.tool_call, dict):
            tool_name = event.tool_call.get("name", "")
        return f"tool:{tool_name}" if tool_name else "tool:unknown"
    return "assistant"
