"""PhaseSeparation -- reasoning-layer capability that enforces analysis-before-execution.

At TURN_START, sets the current phase to "analysis" and injects a system prompt
encouraging the agent to analyze before acting. At LLM_PRE_INVOKE, injects
phase-specific prompts: analysis prompts guide structured thinking, while
execution prompts encourage step-by-step implementation.
"""

from __future__ import annotations

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

ANALYSIS_PROMPT = """\
先分析问题，不要急于执行操作。考虑：
1) 问题是什么
2) 有哪些可能的解决方案
3) 推荐方案及理由"""

EXECUTION_PROMPT = "现在可以执行操作。按照分析结论逐步实现。"

PHASE_SEPARATION_META_PROMPT = """\
You are operating in a two-phase mode:
1. **Analysis phase**: Think through the problem thoroughly before taking any action.
2. **Execution phase**: Implement the solution step by step based on your analysis.

Always complete the analysis phase before moving to execution."""


class PhaseSeparation(AgenticCapability):
    """Reasoning-layer capability that enforces analysis-before-execution.

    Subscribes to two hook points:
    - TURN_START: sets current_phase to "analysis" and injects a meta prompt.
    - LLM_PRE_INVOKE: injects phase-specific prompts depending on the
      current phase tracked in context.

    Args:
        analysis_turns: Number of turns the analysis phase should last.
            Default 1.
    """

    name = "phase_separation"
    layer = CapabilityLayer.REASONING
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TURN_START,
        HookPoint.LLM_PRE_INVOKE,
    ]
    priority = 10

    def __init__(self, analysis_turns: int = 1) -> None:
        self.analysis_turns = analysis_turns

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Always activate -- PhaseSeparation runs on every subscribed hook."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Dispatch to hook-specific handler."""
        if event.hook == HookPoint.TURN_START:
            return await self._on_turn_start(event, context)
        if event.hook == HookPoint.LLM_PRE_INVOKE:
            return await self._on_llm_pre_invoke(event, context)

        # Should not happen, but be safe
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # TURN_START
    # ------------------------------------------------------------------

    async def _on_turn_start(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Set phase to analysis and inject meta prompt at turn start."""
        system_message: dict[str, str] = {
            "role": "system",
            "content": PHASE_SEPARATION_META_PROMPT,
        }

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={"current_phase": "analysis"},
            event_modifications={"messages": [system_message]},
            output={"phase_set": "analysis"},
            output_type="phase_set",
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # LLM_PRE_INVOKE
    # ------------------------------------------------------------------

    async def _on_llm_pre_invoke(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Inject phase-specific prompt before LLM invocation.

        Checks context.current_phase to determine which prompt to inject:
        - "analysis" -> ANALYSIS_PROMPT
        - "execution" (or any other) -> EXECUTION_PROMPT
        """
        current_phase = context.current_phase
        prompt_content = ANALYSIS_PROMPT if current_phase == "analysis" else EXECUTION_PROMPT

        system_message: dict[str, str] = {
            "role": "system",
            "content": prompt_content,
        }

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={"messages": [system_message]},
            capability_name=self.name,
            metrics={"current_phase": current_phase},
        )
