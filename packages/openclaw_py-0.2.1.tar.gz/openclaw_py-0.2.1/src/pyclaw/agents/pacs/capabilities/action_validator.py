"""ActionValidator — action-layer capability for security validation.

Validates tool_call arguments before execution, blocking dangerous patterns:
- Path traversal: ../, ..\\, /etc/, /passwd, /shadow
- SQL injection: DROP, DELETE, TRUNCATE, --, OR.*=
- Command injection (exec tools): ;, &, |, $(), `

This capability runs at priority 1 (earliest) and is critical=True,
meaning any violation aborts the tool execution immediately.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Security patterns (constant, pre-compiled)
# ---------------------------------------------------------------------------

# Path traversal: ../, ..\, /etc/, /passwd, /shadow
PATH_TRAVERSAL_PATTERN = re.compile(r"\.\.[\\/]|^/etc/|^/passwd|^/shadow")

# SQL injection: DROP, DELETE, TRUNCATE, UPDATE, INSERT, --, OR.*=
SQL_INJECTION_PATTERN = re.compile(
    r"(;|\b)(DROP|DELETE|TRUNCATE|UPDATE|INSERT)\s|"
    r"--\s*$|"
    r"'\s*OR\s+.*=|"
    r";\s*DROP",
    re.IGNORECASE,
)

# Command injection: ;, &, |, $(), ||, ` backticks
COMMAND_INJECTION_PATTERN = re.compile(r"[;&|`]|\$\(|\|\|")


class ActionValidator(AgenticCapability):
    """Action-layer capability for security validation of tool arguments.

    Validates string arguments in tool calls against dangerous patterns.
    Runs at priority 1 to execute before any other capability.

    Args:
        workspace_path: Optional whitelist path for file operations.
    """

    name = "action_validator"
    layer = CapabilityLayer.ACTION
    subscribed_hooks: list[HookPoint] = [HookPoint.TOOL_PRE_EXECUTE]
    priority = 1
    critical = True

    def __init__(self, workspace_path: str | None = None) -> None:
        self.workspace_path = workspace_path

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only when there is a tool_call to validate."""
        return event.tool_call is not None

    # ------------------------------------------------------------------
    # Core validation logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Validate tool_call arguments for security violations.

        Checks each string argument against dangerous patterns:
        - Path traversal
        - SQL injection
        - Command injection (for exec-type tools)

        Returns:
            ABORT with security_violation output if violation found.
            CONTINUE if all arguments pass validation.
        """
        tool_call = event.tool_call
        if not tool_call:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Extract arguments from tool_call
        arguments = self._extract_arguments(tool_call)
        if not arguments:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Determine if this is an exec-type tool for command injection check
        tool_name = self._get_tool_name(tool_call)
        is_exec_tool = tool_name and self._is_exec_tool(tool_name)

        # Check each string argument
        for arg_key, arg_value in arguments.items():
            if not isinstance(arg_value, str):
                continue

            # Check path traversal
            if self._has_path_traversal(arg_value):
                logger.warning(
                    "Path traversal detected in %s: %s",
                    arg_key,
                    arg_value[:50],
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:path_traversal:{arg_key}",
                    capability_name=self.name,
                )

            # Check SQL injection
            if self._has_sql_injection(arg_value):
                logger.warning(
                    "SQL injection detected in %s: %s",
                    arg_key,
                    arg_value[:50],
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:sql_injection:{arg_key}",
                    capability_name=self.name,
                )

            # Check command injection only for exec-type tools
            if is_exec_tool and self._has_command_injection(arg_value):
                logger.warning(
                    "Command injection detected in %s: %s",
                    arg_key,
                    arg_value[:50],
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:command_injection:{arg_key}",
                    capability_name=self.name,
                )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Pattern check helpers
    # ------------------------------------------------------------------

    def _has_path_traversal(self, value: str) -> bool:
        """Check if value contains path traversal patterns."""
        return bool(PATH_TRAVERSAL_PATTERN.search(value))

    def _has_sql_injection(self, value: str) -> bool:
        """Check if value contains SQL injection patterns."""
        return bool(SQL_INJECTION_PATTERN.search(value))

    def _has_command_injection(self, value: str) -> bool:
        """Check if value contains command injection patterns."""
        return bool(COMMAND_INJECTION_PATTERN.search(value))

    # ------------------------------------------------------------------
    # Tool call helpers
    # ------------------------------------------------------------------

    def _extract_arguments(self, tool_call: Any) -> dict[str, Any]:
        """Extract arguments dict from tool_call object.

        Handles various tool_call formats:
        - Direct .arguments dict
        - .function.arguments (JSON string or dict)
        - kwargs-style args
        """
        # Try direct arguments attribute
        if hasattr(tool_call, "arguments"):
            args = tool_call.arguments
            if isinstance(args, dict):
                return args

        # Try function.arguments (OpenAI-style)
        if hasattr(tool_call, "function"):
            func = tool_call.function
            if hasattr(func, "arguments"):
                args = func.arguments
                if isinstance(args, dict):
                    return args
                # Arguments might be a JSON string
                if isinstance(args, str):
                    import json

                    try:
                        parsed = json.loads(args)
                        if isinstance(parsed, dict):
                            return parsed
                    except json.JSONDecodeError:
                        pass

        # Try kwargs
        if hasattr(tool_call, "__dict__"):
            return {k: v for k, v in tool_call.__dict__.items() if not k.startswith("_") and k not in {"name", "id"}}

        return {}

    def _get_tool_name(self, tool_call: Any) -> str | None:
        """Extract tool name from tool_call object."""
        # Try direct name attribute
        if hasattr(tool_call, "name"):
            return tool_call.name

        # Try function.name (OpenAI-style)
        if hasattr(tool_call, "function"):
            func = tool_call.function
            if hasattr(func, "name"):
                return func.name

        # Try kwargs
        if hasattr(tool_call, "__dict__") and "name" in tool_call.__dict__:
            return tool_call.__dict__["name"]

        return None

    def _is_exec_tool(self, tool_name: str) -> bool:
        """Check if the tool is an exec-type tool requiring command injection checks."""
        exec_tools = {
            "exec",
            "shell",
            "bash",
            "terminal",
            "run",
            "execute",
            "command",
            "process",
            "subprocess",
        }
        # Match if tool name contains any exec keyword
        tool_lower = tool_name.lower()
        return any(keyword in tool_lower for keyword in exec_tools)
