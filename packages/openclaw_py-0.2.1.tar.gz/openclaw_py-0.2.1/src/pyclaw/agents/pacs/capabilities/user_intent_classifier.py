"""UserIntentClassifier — perception-layer capability that classifies user intent.

Classifies the last user message into one of several intent categories:
- search: user wants to find something
- create: user wants to create/make/build/write something
- analyze: user wants to understand/explain something
- edit: user wants to modify/update/change something
- delete: user wants to remove/clear something
- general: default intent for other cases

The classified intent is stored in context_modifications for use by downstream
capabilities (e.g., model routing, action planning).
"""

from __future__ import annotations

import re
from enum import Enum
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)


class UserIntent(str, Enum):
    """User intent categories for message classification."""

    SEARCH = "search"
    CREATE = "create"
    ANALYZE = "analyze"
    EDIT = "edit"
    DELETE = "delete"
    GENERAL = "general"


# Intent patterns: keywords mapped to intent
_INTENT_PATTERNS: dict[UserIntent, list[str]] = {
    UserIntent.SEARCH: ["search", "find", "look for"],
    UserIntent.CREATE: ["create", "make", "build", "write"],
    UserIntent.ANALYZE: ["analyze", "explain", "why", "how"],
    UserIntent.EDIT: ["edit", "update", "modify", "change"],
    UserIntent.DELETE: ["delete", "remove", "clear"],
}


class UserIntentClassifier(AgenticCapability):
    """Perception-layer capability that classifies user intent from messages.

    Analyzes the last user message and classifies it into an intent category.
    This enables downstream capabilities to adapt their behavior based on
    user intent (e.g., use a stronger model for analysis tasks).

    Attributes:
        name: "user_intent_classifier"
        layer: PERCEPTION
        subscribed_hooks: [PERCEPTION_PRE]
        priority: 5 (runs early, before other perception processing)
    """

    name = "user_intent_classifier"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks: list[HookPoint] = [HookPoint.PERCEPTION_PRE]
    priority = 5  # Run early, before other perception processing

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only at PERCEPTION_PRE with messages present."""
        if event.hook != HookPoint.PERCEPTION_PRE:
            return False
        return event.messages is not None and len(event.messages) > 0

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Classify user intent from the last user message."""
        messages = event.messages
        if not messages:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                context_modifications={"user_intent": UserIntent.GENERAL.value},
                capability_name=self.name,
            )

        # Extract the last user message
        user_message = self._extract_last_user_message(messages)

        # Classify intent
        intent = self._classify_intent(user_message)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={"user_intent": intent.value},
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _extract_last_user_message(self, messages: list[dict[str, Any]]) -> str:
        """Extract text content from the last user message."""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                if isinstance(content, str):
                    return content
                # content may be a list of content blocks
                if isinstance(content, list):
                    text_parts = [
                        block.get("text", "")
                        for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    ]
                    return " ".join(text_parts)
        return ""

    def _classify_intent(self, text: str) -> UserIntent:
        """Classify intent based on keyword matching."""
        text_lower = text.lower()

        for intent, keywords in _INTENT_PATTERNS.items():
            for keyword in keywords:
                # Use word boundary matching to avoid partial matches
                pattern = r"\b" + re.escape(keyword) + r"\b"
                if re.search(pattern, text_lower):
                    return intent

        return UserIntent.GENERAL
