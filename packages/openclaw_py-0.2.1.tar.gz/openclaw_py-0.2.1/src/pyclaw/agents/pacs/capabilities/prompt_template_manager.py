"""PromptTemplateManager — infrastructure-layer capability for prompt template management.

Centrally manages prompt templates and injects them into the message list
before LLM calls. Supports template variables with ``{{variable}}`` syntax
that get replaced from the agent context.

Hooks:
    SESSION_INIT — register templates from config into context
    LLM_PRE_INVOKE — inject active templates as system messages

Priority: 3 (runs before UserIntentClassifier at 5, so templates are in place)
"""

from __future__ import annotations

import re

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

# Pattern to match {{variable_name}} or {{context.attribute}}
_TEMPLATE_VAR_PATTERN = re.compile(r"\{\{(\w[\w.]*)\}\}")


class PromptTemplateManager(AgenticCapability):
    """Infrastructure-layer capability for prompt template management.

    Registers prompt templates from configuration on SESSION_INIT and
    injects active templates as system messages before LLM calls.

    Template variables use ``{{variable}}`` syntax:
    - ``{{variable_name}}`` resolved from ``context.capability_state["template_var_" + variable_name]``
    - ``{{context.attribute}}`` resolved from the corresponding AgentContext attribute

    Attributes:
        name: "prompt_template_manager"
        layer: INFRASTRUCTURE
        subscribed_hooks: [SESSION_INIT, LLM_PRE_INVOKE]
        priority: 3
        templates: Mapping of template name to content string
        active_templates: Ordered list of template names to inject
        position: "prepend" or "append" for injection order
    """

    name = "prompt_template_manager"
    layer = CapabilityLayer.INFRASTRUCTURE
    subscribed_hooks: list[HookPoint] = [
        HookPoint.SESSION_INIT,
        HookPoint.LLM_PRE_INVOKE,
    ]
    priority = 3

    def __init__(
        self,
        templates: dict[str, str] | None = None,
        active_templates: list[str] | None = None,
        position: str = "prepend",
    ) -> None:
        self.templates: dict[str, str] = dict(templates) if templates else {}
        self.active_templates: list[str] = list(active_templates) if active_templates else []
        self.position = position

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate on SESSION_INIT always, and on LLM_PRE_INVOKE when there
        are active templates and messages present.
        """
        if event.hook == HookPoint.SESSION_INIT:
            return True
        if event.hook == HookPoint.LLM_PRE_INVOKE:
            return bool(self.active_templates) and event.messages is not None
        return False

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Handle SESSION_INIT or LLM_PRE_INVOKE events."""
        if event.hook == HookPoint.SESSION_INIT:
            return self._handle_session_init(event, context)
        if event.hook == HookPoint.LLM_PRE_INVOKE:
            return self._handle_llm_pre_invoke(event, context)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # SESSION_INIT handler
    # ------------------------------------------------------------------

    def _handle_session_init(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Register templates from config into the session context."""
        context.capability_state["prompt_templates_registered"] = True

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={
                "prompt_templates_registered": True,
            },
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # LLM_PRE_INVOKE handler
    # ------------------------------------------------------------------

    def _handle_llm_pre_invoke(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Inject active templates as system messages."""
        if not self.active_templates or event.messages is None:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Render each active template
        system_messages: list[dict[str, str]] = []
        for template_name in self.active_templates:
            content = self.templates.get(template_name, "")
            if not content:
                continue
            rendered = self._render(content, context)
            system_messages.append({"role": "system", "content": rendered})

        if not system_messages:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Build the modified messages list
        existing_messages = list(event.messages)
        if self.position == "append":
            modified_messages = existing_messages + system_messages
        else:  # prepend (default)
            modified_messages = system_messages + existing_messages

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={"messages": modified_messages},
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Template management API
    # ------------------------------------------------------------------

    def register_template(self, name: str, content: str) -> None:
        """Register a prompt template.

        Args:
            name: Unique template identifier.
            content: Template content with optional ``{{variable}}`` placeholders.
        """
        self.templates[name] = content

    def activate_template(self, name: str) -> None:
        """Mark a template as active so it gets injected on LLM calls.

        Args:
            name: Template name to activate.
        """
        if name not in self.active_templates:
            self.active_templates.append(name)

    def deactivate_template(self, name: str) -> None:
        """Mark a template as inactive so it no longer gets injected.

        Args:
            name: Template name to deactivate.
        """
        if name in self.active_templates:
            self.active_templates.remove(name)

    def render_template(self, name: str, context: AgentContext) -> str:
        """Render a named template with variables resolved from context.

        Args:
            name: Template name to render.
            context: Agent context providing variable values.

        Returns:
            Rendered template string with variables replaced.
        """
        content = self.templates.get(name, "")
        return self._render(content, context)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _render(self, content: str, context: AgentContext) -> str:
        """Replace template variables in content using context.

        Variable resolution order:
        1. ``{{context.attribute}}`` — resolved from AgentContext attributes
        2. ``{{variable_name}}`` — resolved from
           ``context.capability_state["template_var_" + variable_name]``

        Missing variables resolve to empty string.
        """

        def _replacer(match: re.Match[str]) -> str:
            var_path = match.group(1)

            # Handle context.attribute access
            if var_path.startswith("context."):
                attr_name = var_path[len("context.") :]
                value = getattr(context, attr_name, "")
                return str(value) if value is not None else ""

            # Handle template_var_ lookup in capability_state
            state_key = f"template_var_{var_path}"
            value = context.capability_state.get(state_key, "")
            return str(value) if value is not None else ""

        return _TEMPLATE_VAR_PATTERN.sub(_replacer, content)
