"""ParallelToolExecutor -- action-layer capability for dependency analysis.

Analyses multiple tool calls for dependency relationships and marks
independent tools as candidates for parallel execution.

Dependency analysis rules (MVP heuristic):
- Same-name tools -> serial (potential state dependency)
- Different-name tools with no parameter overlap -> parallel
- Read after write -> serial (stale-read risk)
- Tools in SERIAL_TOOLS always execute serially
- Tools in READ_TOOLS can run in parallel when no serial tool is pending
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Heuristic tool classification
# ---------------------------------------------------------------------------

SERIAL_TOOLS: frozenset[str] = frozenset(
    {
        "write_file",
        "edit_file",
        "delete_file",
        "execute",
        "sql_execute",
    },
)

READ_TOOLS: frozenset[str] = frozenset(
    {
        "search",
        "read",
        "list",
        "get",
        "fetch",
    },
)


def _is_serial_tool(tool_name: str) -> bool:
    """Return True if *tool_name* is in the SERIAL_TOOLS set."""
    return tool_name in SERIAL_TOOLS


def _is_read_tool(tool_name: str) -> bool:
    """Return True if *tool_name* is in the READ_TOOLS set (prefix match)."""
    return any(tool_name.startswith(prefix) for prefix in READ_TOOLS)


# ---------------------------------------------------------------------------
# Tool call wrapper for uniform access
# ---------------------------------------------------------------------------


@dataclass
class ToolCallInfo:
    """Lightweight wrapper that normalises different tool_call shapes."""

    name: str
    arguments: dict[str, Any]
    id: str = ""

    @classmethod
    def from_raw(cls, raw: Any) -> ToolCallInfo:
        """Build a ToolCallInfo from a raw tool_call object."""
        name = ""
        arguments: dict[str, Any] = {}
        call_id = ""

        if hasattr(raw, "name"):
            name = raw.name
        elif hasattr(raw, "function") and hasattr(raw.function, "name"):
            name = raw.function.name

        if hasattr(raw, "arguments"):
            args = raw.arguments
            if isinstance(args, dict):
                arguments = args
            elif isinstance(args, str):
                import json

                try:
                    parsed = json.loads(args)
                    if isinstance(parsed, dict):
                        arguments = parsed
                except json.JSONDecodeError:
                    pass
        elif hasattr(raw, "function") and hasattr(raw.function, "arguments"):
            args = raw.function.arguments
            if isinstance(args, dict):
                arguments = args
            elif isinstance(args, str):
                import json

                try:
                    parsed = json.loads(args)
                    if isinstance(parsed, dict):
                        arguments = parsed
                except json.JSONDecodeError:
                    pass

        if hasattr(raw, "id"):
            call_id = raw.id or ""

        return cls(name=name, arguments=arguments, id=call_id)


# ---------------------------------------------------------------------------
# Capability
# ---------------------------------------------------------------------------


class ParallelToolExecutor(AgenticCapability):
    """Action-layer capability that analyses tool-call dependencies.

    Inspects the current tool call against pending tool calls to determine
    whether it can safely execute in parallel with others.

    Args:
        max_parallel: Maximum number of tools allowed to run in parallel.
            Defaults to 5.
    """

    name = "parallel_tool_executor"
    layer = CapabilityLayer.ACTION
    subscribed_hooks: list[HookPoint] = [HookPoint.TOOL_PRE_EXECUTE]
    priority = 60

    def __init__(self, max_parallel: int = 5) -> None:
        self.max_parallel = max_parallel

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only when a tool_call is present."""
        return event.tool_call is not None

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Analyse the current tool call and store dependency results.

        Checks the current tool call against other pending tool calls
        (available via ``event.metadata``) and determines execution mode.
        Results are stored in ``context_modifications`` under the
        ``_parallel_analysis`` key.
        """
        tool_call = event.tool_call
        if not tool_call:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        current = ToolCallInfo.from_raw(tool_call)

        # Gather pending tool calls from event metadata (if provided by runner)
        pending_raw: list[Any] = event.metadata.get("pending_tool_calls", [])
        pending = [ToolCallInfo.from_raw(tc) for tc in pending_raw]

        all_tools = [current] + pending

        # Run dependency analysis
        analysis = self.analyze_dependencies(
            [{"name": tc.name, "arguments": tc.arguments, "id": tc.id} for tc in all_tools],
        )

        # Enforce max_parallel limit
        analysis = self._enforce_max_parallel(analysis)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={"_parallel_analysis": analysis},
            capability_name=self.name,
            metrics={
                "tool_name": current.name,
                "total_tools": len(all_tools),
                "parallel_groups": sum(1 for g in analysis["tool_groups"] if g["mode"] == "parallel"),
                "serial_groups": sum(1 for g in analysis["tool_groups"] if g["mode"] == "serial"),
            },
        )

    # ------------------------------------------------------------------
    # Static dependency analysis (public API)
    # ------------------------------------------------------------------

    @staticmethod
    def analyze_dependencies(tool_calls: list[dict]) -> dict:
        """Perform static dependency analysis on a list of tool calls.

        Each item in *tool_calls* must be a dict with at least ``"name"``.
        Optional keys: ``"arguments"``, ``"id"``.

        Returns a dependency graph with the following structure::

            {
                "tool_groups": [
                    {"mode": "parallel", "tools": ["search_web", "read_file"]},
                    {"mode": "serial",   "tools": ["write_file"]},
                ],
                "dependencies": [
                    {"from": "write_file", "to": "read_file",
                     "type": "write_after_read"},
                ],
            }
        """
        if not tool_calls:
            return {"tool_groups": [], "dependencies": []}

        tool_groups: list[dict[str, Any]] = []
        dependencies: list[dict[str, str]] = []

        parallel_pool: list[str] = []
        serial_pool: list[str] = []
        seen_serial = False  # Track whether a serial tool has been seen

        for tc in tool_calls:
            tool_name: str = tc.get("name", "")
            if not tool_name:
                continue

            if _is_serial_tool(tool_name):
                # Flush any accumulated parallel tools first
                if parallel_pool:
                    tool_groups.append({"mode": "parallel", "tools": list(parallel_pool)})
                    parallel_pool = []

                serial_pool.append(tool_name)
                seen_serial = True
            elif _is_read_tool(tool_name) and not seen_serial:
                # Read tool before any serial tool -> parallel candidate
                parallel_pool.append(tool_name)
            else:
                # Either non-classified tool, or read after a serial tool
                # Flush parallel pool if present
                if parallel_pool:
                    tool_groups.append({"mode": "parallel", "tools": list(parallel_pool)})
                    parallel_pool = []

                serial_pool.append(tool_name)

                # Record dependency if read-after-write
                if seen_serial and _is_read_tool(tool_name):
                    for prev in serial_pool[:-1]:
                        if _is_serial_tool(prev):
                            dependencies.append(
                                {
                                    "from": prev,
                                    "to": tool_name,
                                    "type": "write_after_read",
                                },
                            )

        # Flush remaining pools
        if parallel_pool:
            tool_groups.append({"mode": "parallel", "tools": list(parallel_pool)})
        if serial_pool:
            tool_groups.append({"mode": "serial", "tools": list(serial_pool)})

        # Merge adjacent serial groups and adjacent parallel groups
        merged = _merge_adjacent_groups(tool_groups)

        return {"tool_groups": merged, "dependencies": dependencies}

    # ------------------------------------------------------------------
    # Max parallel enforcement
    # ------------------------------------------------------------------

    def _enforce_max_parallel(self, analysis: dict) -> dict:
        """Split parallel groups that exceed *max_parallel* into smaller groups."""
        new_groups: list[dict[str, Any]] = []
        for group in analysis.get("tool_groups", []):
            if group["mode"] == "parallel" and len(group["tools"]) > self.max_parallel:
                tools = group["tools"]
                for i in range(0, len(tools), self.max_parallel):
                    chunk = tools[i : i + self.max_parallel]
                    new_groups.append({"mode": "parallel", "tools": chunk})
            else:
                new_groups.append(group)
        analysis["tool_groups"] = new_groups
        return analysis


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _merge_adjacent_groups(
    groups: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Merge consecutive groups of the same mode."""
    if not groups:
        return []

    merged: list[dict[str, Any]] = [groups[0]]
    for group in groups[1:]:
        last = merged[-1]
        if last["mode"] == group["mode"]:
            last["tools"] = last["tools"] + group["tools"]
        else:
            merged.append(group)
    return merged
