"""MetaCognitionMonitor — infrastructure-layer capability for cross-layer metadata tracking.

Records turn-level timing and tool success/failure statistics, then adjusts
``context.task_complexity`` dynamically based on observed tool success rate.

Stats structure (stored in ``context.capability_state["_meta_stats"]``)::

    {
        "total_turns": 0,
        "total_time_ms": 0.0,
        "avg_turn_time_ms": 0.0,
        "tool_successes": 0,
        "tool_failures": 0,
        "tool_success_rate": 1.0,
    }

Complexity adjustment rules (applied at TURN_END):
  - success_rate > 0.80 -> complexity -= 0.1
  - success_rate < 0.40 -> complexity += 0.2
"""

from __future__ import annotations

import logging
import time

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Keys used in context.capability_state
_KEY_TURN_START = "_meta_turn_start_time"
_KEY_STATS = "_meta_stats"


class MetaCognitionMonitor(AgenticCapability):
    """Infrastructure-layer capability that monitors agent performance metadata.

    Subscribes to TURN_START, TURN_END, TOOL_POST_EXECUTE, and TOOL_ERROR.
    Runs at priority 5 (earliest) so other capabilities can read its stats.

    Public helper:
        get_stats(context) -> dict:  retrieve current statistics.
    """

    name = "meta_cognition_monitor"
    layer = CapabilityLayer.INFRASTRUCTURE
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TURN_START,
        HookPoint.TURN_END,
        HookPoint.TOOL_POST_EXECUTE,
        HookPoint.TOOL_ERROR,
    ]
    priority = 5  # earliest — other capabilities consume our metadata
    critical = False

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    @staticmethod
    def get_stats(context: AgentContext) -> dict:
        """Return the current meta-cognition statistics from *context*.

        Args:
            context: Session-scoped agent context.

        Returns:
            A dict with keys: total_turns, total_time_ms, avg_turn_time_ms,
            tool_successes, tool_failures, tool_success_rate.
        """
        return context.get(_KEY_STATS, _default_stats())

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """MetaCognitionMonitor is always active."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Dispatch to the appropriate handler based on hook point."""
        if event.hook == HookPoint.TURN_START:
            return self._handle_turn_start(event, context)
        if event.hook == HookPoint.TURN_END:
            return self._handle_turn_end(event, context)
        if event.hook == HookPoint.TOOL_POST_EXECUTE:
            return self._handle_tool_post_execute(event, context)
        if event.hook == HookPoint.TOOL_ERROR:
            return self._handle_tool_error(event, context)

        # Fallback — should never happen given should_activate is True
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Hook handlers
    # ------------------------------------------------------------------

    def _handle_turn_start(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Record the turn start timestamp."""
        now_ms = time.monotonic() * 1000.0

        # Ensure stats dict exists
        stats = context.get(_KEY_STATS)
        if stats is None:
            stats = _default_stats()
            context.set(_KEY_STATS, stats)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={_KEY_TURN_START: now_ms},
        )

    def _handle_turn_end(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Calculate turn duration and update stats; adjust complexity."""
        now_ms = time.monotonic() * 1000.0
        start_ms: float | None = context.get(_KEY_TURN_START)

        stats = context.get(_KEY_STATS, _default_stats())
        stats = dict(stats)  # shallow copy to avoid mutating in-place

        # Duration
        duration_ms = 0.0
        if start_ms is not None:
            duration_ms = now_ms - start_ms

        # Update turn counters
        stats["total_turns"] = stats.get("total_turns", 0) + 1
        stats["total_time_ms"] = stats.get("total_time_ms", 0.0) + duration_ms
        total_turns = stats["total_turns"]
        stats["avg_turn_time_ms"] = stats["total_time_ms"] / total_turns if total_turns > 0 else 0.0

        # Update tool success rate
        successes = stats.get("tool_successes", 0)
        failures = stats.get("tool_failures", 0)
        total_tools = successes + failures
        stats["tool_success_rate"] = successes / total_tools if total_tools > 0 else 1.0

        # Dynamic complexity adjustment
        context_modifications: dict[str, object] = {_KEY_STATS: stats}

        success_rate = stats["tool_success_rate"]
        new_complexity: float | None = None

        if success_rate > 0.80 and context.task_complexity > 0.0:
            new_complexity = max(0.0, context.task_complexity - 0.1)
        elif success_rate < 0.40:
            new_complexity = context.task_complexity + 0.2

        if new_complexity is not None:
            context_modifications["task_complexity"] = new_complexity
            logger.debug(
                "Adjusting task_complexity %.2f -> %.2f (success_rate=%.2f)",
                context.task_complexity,
                new_complexity,
                success_rate,
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications=context_modifications,
            metrics={
                "total_turns": stats["total_turns"],
                "duration_ms": duration_ms,
                "tool_success_rate": stats["tool_success_rate"],
            },
        )

    def _handle_tool_post_execute(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Record a successful tool execution."""
        stats = context.get(_KEY_STATS, _default_stats())
        stats = dict(stats)
        stats["tool_successes"] = stats.get("tool_successes", 0) + 1

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={_KEY_STATS: stats},
        )

    def _handle_tool_error(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Record a failed tool execution."""
        stats = context.get(_KEY_STATS, _default_stats())
        stats = dict(stats)
        stats["tool_failures"] = stats.get("tool_failures", 0) + 1

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={_KEY_STATS: stats},
        )


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------


def _default_stats() -> dict:
    """Return a fresh stats dict with default values."""
    return {
        "total_turns": 0,
        "total_time_ms": 0.0,
        "avg_turn_time_ms": 0.0,
        "tool_successes": 0,
        "tool_failures": 0,
        "tool_success_rate": 1.0,
    }
