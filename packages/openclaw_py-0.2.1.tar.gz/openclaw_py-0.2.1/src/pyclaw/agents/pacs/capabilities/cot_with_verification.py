"""CoTWithVerification -- reasoning-layer capability for verifying chain-of-thought structure.

Analyzes LLM responses for structured reasoning patterns and scores them
on reasoning quality. When the score falls below a configurable threshold,
flags the failure in ``context.capability_state["cot_verification_failed"]``.

Scoring breakdown (0.0 -- 1.0):
  - Has explicit reasoning steps (numbered, first/then/finally): +0.3
  - Uses logical connectors (because, therefore, so):            +0.2
  - Has conclusion / summary:                                     +0.2
  - Response length adequate:                                     +0.1

Args:
    verification_threshold: Score below which verification is flagged as failed.
        Default 0.5.
    min_response_length: Minimum character length for the length-adequate bonus.
        Default 50.
    required_patterns: Regex patterns used to detect reasoning structure.
        Defaults to a built-in set covering numbered steps, sequencing words,
        logical connectors, and conclusion markers.
"""

from __future__ import annotations

import logging
import re

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Default regex patterns for reasoning detection
_DEFAULT_REASONING_STEP_PATTERNS: list[str] = [
    r"(?:^|\n)\s*\d+\.\s",  # numbered steps: "1. ", "2. "
    r"(?:^|\n)\s*[-*]\s",  # bullet steps: "- ", "* "
    r"\b(?:first|second|third|fourth|fifth)\b",
    r"\b(?:firstly|secondly|thirdly|finally|lastly)\b",
]

_DEFAULT_LOGICAL_CONNECTOR_PATTERNS: list[str] = [
    r"\bbecause\b",
    r"\btherefore\b",
    r"\bso\b",
    r"\bthus\b",
    r"\bhence\b",
    r"\bconsequently\b",
    r"\bas a result\b",
    r"\bsince\b",
]

_DEFAULT_CONCLUSION_PATTERNS: list[str] = [
    r"\b(?:in\s+)?conclu(?:de|sion)\b",
    r"\b(?:in\s+)?summary\b",
    r"\bto summarize\b",
    r"\bto sum up\b",
    r"\boverall\b",
    r"\bin short\b",
    r"\bin brief\b",
]

# Composite default required patterns (for custom override)
DEFAULT_REQUIRED_PATTERNS: list[str] = (
    _DEFAULT_REASONING_STEP_PATTERNS + _DEFAULT_LOGICAL_CONNECTOR_PATTERNS + _DEFAULT_CONCLUSION_PATTERNS
)

# Score weights
_SCORE_REASONING_STEPS = 0.3
_SCORE_LOGICAL_CONNECTORS = 0.2
_SCORE_CONCLUSION = 0.2
_SCORE_LENGTH_ADEQUATE = 0.1


def _compile_patterns(patterns: list[str]) -> list[re.Pattern[str]]:
    """Compile a list of regex patterns (case-insensitive)."""
    return [re.compile(p, re.IGNORECASE) for p in patterns]


class CoTWithVerification(AgenticCapability):
    """Reasoning-layer capability that verifies chain-of-thought structure in LLM responses.

    Subscribes to LLM_POST_RESPONSE at priority 45 (between PlanExecute at 40
    and ReflectionLoop at 50).
    """

    name = "cot_with_verification"
    layer = CapabilityLayer.REASONING
    subscribed_hooks: list[HookPoint] = [HookPoint.LLM_POST_RESPONSE]
    priority = 45
    critical = False

    def __init__(
        self,
        verification_threshold: float = 0.5,
        min_response_length: int = 50,
        required_patterns: list[str] | None = None,
    ) -> None:
        self.verification_threshold = verification_threshold
        self.min_response_length = min_response_length

        # Compile regex patterns for each category
        patterns = required_patterns if required_patterns is not None else DEFAULT_REQUIRED_PATTERNS
        self._patterns = _compile_patterns(patterns)

        # Split compiled patterns into categories based on defaults
        n_steps = len(_DEFAULT_REASONING_STEP_PATTERNS)
        n_connectors = len(_DEFAULT_LOGICAL_CONNECTOR_PATTERNS)

        if required_patterns is None:
            # Use default category split
            self._step_patterns = _compile_patterns(_DEFAULT_REASONING_STEP_PATTERNS)
            self._connector_patterns = _compile_patterns(_DEFAULT_LOGICAL_CONNECTOR_PATTERNS)
            self._conclusion_patterns = _compile_patterns(_DEFAULT_CONCLUSION_PATTERNS)
        else:
            # Custom patterns: treat all as generic reasoning patterns
            self._step_patterns = self._patterns[:n_steps] if len(self._patterns) > n_steps else []
            self._connector_patterns = (
                self._patterns[n_steps : n_steps + n_connectors] if len(self._patterns) > n_steps else []
            )
            self._conclusion_patterns = (
                self._patterns[n_steps + n_connectors :] if len(self._patterns) > n_steps + n_connectors else []
            )

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only when llm_response is present."""
        return event.llm_response is not None

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Analyze LLM response for chain-of-thought reasoning quality."""
        response_text = self._extract_response_text(event.llm_response)

        # Score the response
        score, breakdown = self._score_response(response_text)

        # Check against threshold
        failed = score < self.verification_threshold

        if failed:
            logger.info(
                "CoT verification failed (score=%.2f, threshold=%.2f)",
                score,
                self.verification_threshold,
            )
            context.capability_state["cot_verification_failed"] = True

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications=({"cot_verification_failed": True} if failed else {}),
            metrics={
                "score": score,
                **breakdown,
            },
        )

    # ------------------------------------------------------------------
    # Scoring helpers (public for testability)
    # ------------------------------------------------------------------

    def _score_response(self, text: str) -> tuple[float, dict[str, bool | float]]:
        """Score a response on reasoning quality.

        Args:
            text: The extracted response text.

        Returns:
            A tuple of (score, breakdown_dict).
        """
        breakdown: dict[str, bool | float] = {}
        score = 0.0

        if not text or not text.strip():
            breakdown["score"] = 0.0
            breakdown["has_reasoning_steps"] = False
            breakdown["has_logical_connectors"] = False
            breakdown["has_conclusion"] = False
            breakdown["length_adequate"] = False
            return 0.0, breakdown

        # Check reasoning steps (+0.3)
        has_steps = self._matches_any(text, self._step_patterns)
        if has_steps:
            score += _SCORE_REASONING_STEPS
        breakdown["has_reasoning_steps"] = has_steps

        # Check logical connectors (+0.2)
        has_connectors = self._matches_any(text, self._connector_patterns)
        if has_connectors:
            score += _SCORE_LOGICAL_CONNECTORS
        breakdown["has_logical_connectors"] = has_connectors

        # Check conclusion/summary (+0.2)
        has_conclusion = self._matches_any(text, self._conclusion_patterns)
        if has_conclusion:
            score += _SCORE_CONCLUSION
        breakdown["has_conclusion"] = has_conclusion

        # Check response length (+0.1)
        length_adequate = len(text) >= self.min_response_length
        if length_adequate:
            score += _SCORE_LENGTH_ADEQUATE
        breakdown["length_adequate"] = length_adequate

        breakdown["score"] = score
        return score, breakdown

    @staticmethod
    def _matches_any(text: str, patterns: list[re.Pattern[str]]) -> bool:
        """Check if text matches any of the given compiled patterns."""
        return any(p.search(text) for p in patterns)

    @staticmethod
    def _extract_response_text(llm_response: dict | None) -> str:
        """Extract the text content from an LLM response payload.

        The response dict may have ``content`` as a string or as a list of
        content blocks (``{"type": "text", "text": "..."}``).

        Args:
            llm_response: The LLM response dict, or None.

        Returns:
            Extracted text, or empty string if unavailable.
        """
        if llm_response is None:
            return ""

        content = llm_response.get("content", "")
        if isinstance(content, str):
            return content

        # List of content blocks
        if isinstance(content, list):
            parts: list[str] = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
            return " ".join(parts)

        return str(content)
