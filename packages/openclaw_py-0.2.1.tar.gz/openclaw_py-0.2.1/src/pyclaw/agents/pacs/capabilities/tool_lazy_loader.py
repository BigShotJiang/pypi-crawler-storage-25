"""ToolLazyLoader — infrastructure-layer capability for deferred tool loading.

Defers tool definition loading until actually needed, reducing initial token
consumption. Only a minimal "starter" set of tools is loaded at session init;
the rest are loaded on-demand when a TOOL_PRE_EXECUTE hook fires for a tool
that is available but not yet loaded.

This capability runs at priority 2 (after ActionValidator at 1) on the
INFRASTRUCTURE layer.
"""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Heuristic: ~4 characters per token for estimating tool definition size.
CHARS_PER_TOKEN = 4.0


class ToolLazyLoader(AgenticCapability):
    """Infrastructure-layer capability that defers tool loading to reduce token usage.

    On SESSION_INIT, only the tools listed in *starter_tools* are loaded.
    On TOOL_PRE_EXECUTE, if the requested tool is available but not yet loaded,
    it is loaded on-demand before execution proceeds.

    Args:
        starter_tools: Tool names to load immediately at session init.
            Default: ``["search", "read"]``.
        available_tools: Full set of known tool definitions, keyed by name.
            Default: ``{}`` (empty — no tools available).
    """

    name = "tool_lazy_loader"
    layer = CapabilityLayer.INFRASTRUCTURE
    subscribed_hooks: list[HookPoint] = [
        HookPoint.SESSION_INIT,
        HookPoint.TOOL_PRE_EXECUTE,
    ]
    priority = 2
    critical = False

    def __init__(
        self,
        starter_tools: list[str] | None = None,
        available_tools: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        self.starter_tools: list[str] = starter_tools if starter_tools is not None else ["search", "read"]
        self.available_tools: dict[str, dict[str, Any]] = available_tools if available_tools is not None else {}
        self._loaded_tools: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def load_tool(self, name: str) -> dict[str, Any] | None:
        """Load a tool definition by name.

        If the tool is in *available_tools* and not already loaded, it is
        moved into the loaded set and its definition is returned.

        Args:
            name: Tool name to load.

        Returns:
            The tool definition dict, or ``None`` if not available.
        """
        if name in self._loaded_tools:
            return self._loaded_tools[name]
        if name not in self.available_tools:
            return None
        definition = self.available_tools[name]
        self._loaded_tools[name] = definition
        logger.debug("Lazy-loaded tool: %s", name)
        return definition

    def is_loaded(self, name: str) -> bool:
        """Check whether a tool has been loaded.

        Args:
            name: Tool name to check.

        Returns:
            ``True`` if the tool is in the loaded set.
        """
        return name in self._loaded_tools

    def get_loaded_tools(self) -> list[str]:
        """Return a sorted list of currently loaded tool names."""
        return sorted(self._loaded_tools.keys())

    # ------------------------------------------------------------------
    # Token estimation
    # ------------------------------------------------------------------

    def _estimate_tool_tokens(self, definition: dict[str, Any]) -> int:
        """Estimate token count for a single tool definition.

        Uses a simple heuristic based on the total character length of the
        serialized definition divided by *CHARS_PER_TOKEN*.

        Args:
            definition: Tool definition dict.

        Returns:
            Estimated token count.
        """
        total_chars = len(str(definition))
        return int(total_chars / CHARS_PER_TOKEN)

    def _compute_tokens_saved(self) -> int:
        """Compute approximate tokens saved by tools that are available but not loaded."""
        saved = 0
        for name, definition in self.available_tools.items():
            if name not in self._loaded_tools:
                saved += self._estimate_tool_tokens(definition)
        return saved

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Always activate for subscribed hooks."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Handle SESSION_INIT and TOOL_PRE_EXECUTE events.

        - SESSION_INIT: Load starter tools and report initial token savings.
        - TOOL_PRE_EXECUTE: If the tool is available but not loaded, load it
          on-demand.  If the tool is unavailable, return CONTINUE and let the
          runner handle it.

        Returns:
            CONTINUE with context_modifications tracking loaded tools and
            estimated token savings.
        """
        if event.hook == HookPoint.SESSION_INIT:
            return self._handle_session_init(event, context)

        if event.hook == HookPoint.TOOL_PRE_EXECUTE:
            return self._handle_tool_pre_execute(event, context)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _handle_session_init(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Load starter tools on session initialisation."""
        for tool_name in self.starter_tools:
            if tool_name in self.available_tools:
                self._loaded_tools[tool_name] = self.available_tools[tool_name]
                logger.debug("Loaded starter tool: %s", tool_name)

        tokens_saved = self._compute_tokens_saved()

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={
                "loaded_tools": self.get_loaded_tools(),
                "tool_tokens_saved": tokens_saved,
            },
        )

    def _handle_tool_pre_execute(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Lazy-load a tool on demand during execution."""
        tool_call = event.tool_call
        if tool_call is None:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                context_modifications={
                    "loaded_tools": self.get_loaded_tools(),
                    "tool_tokens_saved": self._compute_tokens_saved(),
                },
            )

        # Extract tool name from tool_call
        tool_name = self._get_tool_name(tool_call)
        if tool_name is None:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                context_modifications={
                    "loaded_tools": self.get_loaded_tools(),
                    "tool_tokens_saved": self._compute_tokens_saved(),
                },
            )

        # Already loaded — nothing to do
        if self.is_loaded(tool_name):
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                context_modifications={
                    "loaded_tools": self.get_loaded_tools(),
                    "tool_tokens_saved": self._compute_tokens_saved(),
                },
            )

        # Try to load on demand
        loaded = self.load_tool(tool_name)
        if loaded is not None:
            logger.info("Lazy-loaded tool on demand: %s", tool_name)

        tokens_saved = self._compute_tokens_saved()

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={
                "loaded_tools": self.get_loaded_tools(),
                "tool_tokens_saved": tokens_saved,
            },
        )

    # ------------------------------------------------------------------
    # Tool call helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_tool_name(tool_call: Any) -> str | None:
        """Extract tool name from a tool_call object.

        Handles both direct ``.name`` attribute and OpenAI-style
        ``.function.name`` access.

        Args:
            tool_call: Tool call object.

        Returns:
            Tool name string, or ``None`` if not found.
        """
        if hasattr(tool_call, "name"):
            return tool_call.name
        if hasattr(tool_call, "function") and hasattr(tool_call.function, "name"):
            return tool_call.function.name
        return None
