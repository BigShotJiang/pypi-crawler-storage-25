"""TraceQualityMonitor -- feedback-layer capability for turn-level quality tracing.

Evaluates each turn's interaction quality using heuristic scoring (0.0 - 1.0),
accumulates scores across turns, and produces a session-level summary at
SESSION_END.

Scoring factors (TURN_END):
  - Has assistant message and non-empty      -> +0.3
  - Has tool calls                           -> +0.2
  - Has tool results                         -> +0.2
  - Total message length > 100 characters    -> +0.3

Session summary (SESSION_END):
  - avg_score:   mean of all turn scores
  - min_score:   lowest turn score
  - consistency: inverse of score standard deviation (1 / (1 + std))
  - scores:      raw list of per-turn scores

Args:
    warn_threshold: Score threshold below which a warning is logged.
        Default 0.3.
"""

from __future__ import annotations

import logging
import math

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Keys used in context.capability_state
_KEY_SCORES = "_trace_scores"
_KEY_SUMMARY = "_trace_summary"


class TraceQualityMonitor(AgenticCapability):
    """Feedback-layer capability that monitors turn and session quality.

    Subscribes to TURN_END and SESSION_END. Runs at priority 88 (after most
    feedback processing) so it can observe the full state of each turn.

    Public helper:
        get_trace_summary(context) -> dict: retrieve session-level quality summary.
    """

    name = "trace_quality_monitor"
    layer = CapabilityLayer.FEEDBACK
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TURN_END,
        HookPoint.SESSION_END,
    ]
    priority = 88
    critical = False

    def __init__(self, warn_threshold: float = 0.3) -> None:
        self.warn_threshold = warn_threshold

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    @staticmethod
    def get_trace_summary(context: AgentContext) -> dict:
        """Return the session-level quality summary from *context*.

        Args:
            context: Session-scoped agent context.

        Returns:
            A dict with keys: total_turns, avg_score, min_score,
            consistency, scores.  Returns an empty summary if no turns
            have been evaluated yet.
        """
        return context.get(_KEY_SUMMARY, _empty_summary())

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """TraceQualityMonitor is always active."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Dispatch to the appropriate handler based on hook point."""
        if event.hook == HookPoint.TURN_END:
            return self._handle_turn_end(event, context)
        if event.hook == HookPoint.SESSION_END:
            return self._handle_session_end(event, context)

        # Fallback -- should never happen given should_activate is True
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Hook handlers
    # ------------------------------------------------------------------

    def _handle_turn_end(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Score the current turn and append to the accumulated trace."""
        score, factors = self._score_turn(event)

        # Load or initialise the scores list
        scores_list: list[dict] = list(context.get(_KEY_SCORES, []))

        turn_record: dict = {
            "turn": event.turn,
            "score": score,
            "factors": factors,
        }
        scores_list.append(turn_record)

        # Warn on low quality
        if score < self.warn_threshold:
            logger.warning(
                "Turn %d quality low (score=%.2f, threshold=%.2f, factors=%s)",
                event.turn,
                score,
                self.warn_threshold,
                factors,
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={_KEY_SCORES: scores_list},
            metrics={
                "turn": event.turn,
                "score": score,
                "factors": factors,
            },
        )

    def _handle_session_end(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Compute the session-level quality summary."""
        scores_list: list[dict] = list(context.get(_KEY_SCORES, []))
        raw_scores = [entry["score"] for entry in scores_list]

        summary = _compute_summary(raw_scores)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={_KEY_SUMMARY: summary},
            metrics=summary,
        )

    # ------------------------------------------------------------------
    # Scoring helpers (public for testability)
    # ------------------------------------------------------------------

    @staticmethod
    def _score_turn(event: HookEvent) -> tuple[float, dict[str, bool]]:
        """Score a single turn from 0.0 (poor) to 1.0 (good).

        Scoring factors (additive):
          - has_response:  assistant message exists and is non-empty  -> +0.3
          - has_tools:     tool calls present                         -> +0.2
          - has_results:   tool results present                       -> +0.2
          - has_length:    total message content > 100 chars          -> +0.3

        Args:
            event: The TURN_END hook event.

        Returns:
            A tuple of (score, factors_dict).
        """
        factors: dict[str, bool] = {
            "has_response": False,
            "has_tools": False,
            "has_results": False,
            "has_length": False,
        }
        score = 0.0
        total_length = 0

        messages = event.messages or []

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")

            # Content may be a string or a list of content blocks
            content_text = _extract_text(content)
            total_length += len(content_text)

            if role == "assistant" and content_text.strip():
                factors["has_response"] = True

            # Tool calls are usually on assistant messages
            if msg.get("tool_calls"):
                factors["has_tools"] = True

            # Tool results are usually role == "tool"
            if role == "tool":
                factors["has_results"] = True

        # Also check event-level tool fields
        if event.tool_call is not None:
            factors["has_tools"] = True
        if event.tool_result is not None:
            factors["has_results"] = True

        # Compute score from factors
        if factors["has_response"]:
            score += 0.3
        if factors["has_tools"]:
            score += 0.2
        if factors["has_results"]:
            score += 0.2
        if total_length > 100:
            factors["has_length"] = True
            score += 0.3

        return score, factors


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------


def _extract_text(content: object) -> str:
    """Extract plain text from message content.

    Content may be a plain string or a list of content blocks
    (``{"type": "text", "text": "..."}``).

    Args:
        content: The raw message content value.

    Returns:
        Extracted text, or empty string.
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        return " ".join(parts)
    return str(content)


def _compute_summary(raw_scores: list[float]) -> dict:
    """Compute session-level quality summary from per-turn scores.

    Args:
        raw_scores: List of per-turn quality scores.

    Returns:
        Summary dict with total_turns, avg_score, min_score, consistency, scores.
    """
    total_turns = len(raw_scores)

    if total_turns == 0:
        return _empty_summary()

    avg_score = sum(raw_scores) / total_turns
    min_score = min(raw_scores)

    # Consistency: inverse of standard deviation.
    # Use 1 / (1 + std) so it's always in [0, 1].
    if total_turns > 1:
        variance = sum((s - avg_score) ** 2 for s in raw_scores) / total_turns
        std = math.sqrt(variance)
        consistency = 1.0 / (1.0 + std)
    else:
        consistency = 1.0

    return {
        "total_turns": total_turns,
        "avg_score": round(avg_score, 4),
        "min_score": round(min_score, 4),
        "consistency": round(consistency, 4),
        "scores": raw_scores,
    }


def _empty_summary() -> dict:
    """Return an empty session summary with default values."""
    return {
        "total_turns": 0,
        "avg_score": 0.0,
        "min_score": 0.0,
        "consistency": 1.0,
        "scores": [],
    }
