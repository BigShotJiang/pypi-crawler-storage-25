"""ReflectionLoop — reasoning-layer capability that triggers iterative self-improvement.

When the agent's output quality is below threshold, this capability triggers
a reflection loop to improve the response. It tracks reflection count in
the session context and stops after max_reflections iterations.
"""

from __future__ import annotations

from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

REFLECTION_PROMPT = """\
Review your previous response critically:
1. Identify any inaccuracies, missing information, or unclear explanations.
2. Consider if the response fully addresses the user's request.
3. Think about how you could improve the clarity, completeness, or usefulness.

Then provide an improved version of your response."""


class ReflectionLoop(AgenticCapability):
    """Reasoning-layer capability that triggers iterative self-improvement.

    At TURN_END, evaluates the quality of the assistant's output. If quality
    is below threshold and reflection count hasn't reached max_reflections,
    triggers a reflection loop by setting current_phase to "reflecting" and
    adding a reflection request to working_memory.

    Args:
        max_reflections: Maximum number of reflection iterations per session.
            Default 2.
        quality_threshold: Minimum quality score (0.0-1.0) to skip reflection.
            Default 0.7.
    """

    name = "reflection_loop"
    layer = CapabilityLayer.REASONING
    subscribed_hooks: list[HookPoint] = [HookPoint.TURN_END]
    priority = 50

    def __init__(
        self,
        max_reflections: int = 2,
        quality_threshold: float = 0.7,
    ) -> None:
        self.max_reflections = max_reflections
        self.quality_threshold = quality_threshold

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only on TURN_END."""
        return event.hook == HookPoint.TURN_END

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Evaluate output quality and trigger reflection if needed."""
        # Get current reflection count from context
        reflection_count = context.get("reflection_count", 0)

        # Check if we've reached max reflections
        if reflection_count >= self.max_reflections:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={"reflection_count": reflection_count, "max_reached": True},
            )

        # Estimate output quality
        quality = self._estimate_quality(event, context)

        # High quality — no reflection needed
        if quality >= self.quality_threshold:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={
                    "quality": quality,
                    "threshold": self.quality_threshold,
                    "reflection_triggered": False,
                },
            )

        # Low quality — trigger reflection
        new_count = reflection_count + 1

        # Create reflection request for working memory
        reflection_request: dict[str, Any] = {
            "type": "reflection_request",
            "prompt": REFLECTION_PROMPT,
            "iteration": new_count,
            "previous_quality": quality,
        }

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={
                "current_phase": "reflecting",
                "reflection_count": new_count,
            },
            output={
                "reflection_request": reflection_request,
                "add_to_working_memory": True,
            },
            output_type="reflection_request",
            capability_name=self.name,
            metrics={
                "quality": quality,
                "threshold": self.quality_threshold,
                "reflection_triggered": True,
                "reflection_count": new_count,
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _estimate_quality(self, event: HookEvent, context: AgentContext) -> float:
        """Estimate output quality using simple heuristics.

        Currently uses message length as a proxy for quality:
        - Empty content: 0.0
        - Length < 50 chars: 0.3
        - Length < 200 chars: 0.5
        - Otherwise: 0.8

        Args:
            event: The hook event containing messages.
            context: Session context (unused in current implementation).

        Returns:
            Quality score between 0.0 and 1.0.
        """
        messages = event.messages
        if not messages:
            return 0.0

        # Find the last assistant message
        last_assistant_content = ""
        for msg in reversed(messages):
            if msg.get("role") == "assistant":
                content = msg.get("content", "")
                if isinstance(content, str):
                    last_assistant_content = content
                elif isinstance(content, list):
                    # Handle content blocks
                    text_parts = []
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "text":
                            text_parts.append(block.get("text", ""))
                    last_assistant_content = " ".join(text_parts)
                break

        # Empty content
        if not last_assistant_content:
            return 0.0

        length = len(last_assistant_content)

        if length < 50:
            return 0.3
        elif length < 200:
            return 0.5
        else:
            return 0.8
