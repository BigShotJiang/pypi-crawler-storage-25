"""SelfCritique -- feedback-layer capability for heuristic quality evaluation.

Evaluates tool execution results and LLM responses using heuristic quality
checks. When quality falls below a configurable threshold, the capability
records a critique entry in working memory and sets context modifications
to signal that re-evaluation may be needed.

Heuristic checks for tool results:
  - Presence of error indicators ("error", "failed", "exception")
  - Result length below a minimum threshold (< 20 characters)
  - Empty / null results

Heuristic checks for LLM responses:
  - Presence of uncertainty markers ("maybe", "i think", "not sure")
  - Response length below a minimum threshold (< 50 characters)
  - Excessive contradiction markers ("but", "however", "on the other hand")

Args:
    quality_threshold: Score threshold below which a critique is triggered.
        Default 0.5.
    enable_auto_retry: Whether to automatically retry on low-quality results.
        Default False (MVP: log only, do not auto-retry).
"""

from __future__ import annotations

import logging
import time

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

CRITIQUE_PROMPT = "Review the previous result critically. Identify issues and suggest improvements."

# Minimum character lengths
_MIN_TOOL_RESULT_LENGTH = 20
_MIN_LLM_RESPONSE_LENGTH = 50

# Error indicator substrings (case-insensitive)
_ERROR_INDICATORS: frozenset[str] = frozenset({"error", "failed", "exception"})

# Uncertainty marker substrings (case-insensitive)
_UNCERTAINTY_MARKERS: frozenset[str] = frozenset(
    {"maybe", "i think", "not sure"},
)

# Contradiction marker substrings (case-insensitive)
_CONTRADICTION_MARKERS: frozenset[str] = frozenset(
    {"but", "however", "on the other hand"},
)
_MAX_CONTRADICTION_COUNT = 2


class SelfCritique(AgenticCapability):
    """Feedback-layer capability that evaluates output quality heuristically.

    Subscribes to TOOL_POST_EXECUTE and LLM_POST_RESPONSE. Runs at priority 80
    (after most capabilities) so it can assess results produced by earlier
    layers.

    Public helpers:
        _evaluate_tool_result(tool_result) -> float
        _evaluate_llm_response(response) -> float
    """

    name = "self_critique"
    layer = CapabilityLayer.FEEDBACK
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TOOL_POST_EXECUTE,
        HookPoint.LLM_POST_RESPONSE,
    ]
    priority = 80  # after most capabilities
    critical = False

    def __init__(
        self,
        quality_threshold: float = 0.5,
        enable_auto_retry: bool = False,
    ) -> None:
        self.quality_threshold = quality_threshold
        self.enable_auto_retry = enable_auto_retry

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """SelfCritique is always active on its subscribed hooks."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Dispatch to the appropriate handler based on hook point."""
        if event.hook == HookPoint.TOOL_POST_EXECUTE:
            return self._handle_tool_post_execute(event, context)
        if event.hook == HookPoint.LLM_POST_RESPONSE:
            return self._handle_llm_post_response(event, context)

        # Fallback -- should never happen given should_activate is True
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Hook handlers
    # ------------------------------------------------------------------

    def _handle_tool_post_execute(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Evaluate tool result quality and record critiques when low."""
        tool_result = event.tool_result
        score = self._evaluate_tool_result(tool_result)

        if score < self.quality_threshold:
            logger.info(
                "Tool result quality low (score=%.2f, threshold=%.2f)",
                score,
                self.quality_threshold,
            )

            # Build critique record for working memory
            critique_record = self._make_critique_record(
                source="tool_result",
                score=score,
                details=_describe_tool_issues(tool_result),
            )
            context.working_memory.append(critique_record)

            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                context_modifications={"current_phase": "re_evaluating"},
                metrics={
                    "source": "tool_result",
                    "quality_score": score,
                    "threshold": self.quality_threshold,
                    "critiqued": True,
                },
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            metrics={
                "source": "tool_result",
                "quality_score": score,
                "critiqued": False,
            },
        )

    def _handle_llm_post_response(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Evaluate LLM response quality and record critiques when low."""
        response_text = self._extract_response_text(event.llm_response)
        score = self._evaluate_llm_response(response_text)

        if score < self.quality_threshold:
            logger.info(
                "LLM response quality low (score=%.2f, threshold=%.2f)",
                score,
                self.quality_threshold,
            )

            critique_record = self._make_critique_record(
                source="llm_response",
                score=score,
                details=_describe_llm_issues(response_text),
            )
            context.working_memory.append(critique_record)

            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                context_modifications={"current_phase": "re_evaluating"},
                metrics={
                    "source": "llm_response",
                    "quality_score": score,
                    "threshold": self.quality_threshold,
                    "critiqued": True,
                },
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            metrics={
                "source": "llm_response",
                "quality_score": score,
                "critiqued": False,
            },
        )

    # ------------------------------------------------------------------
    # Evaluation helpers (public for testability)
    # ------------------------------------------------------------------

    def _evaluate_tool_result(self, tool_result: object) -> float:
        """Score a tool result from 0.0 (poor) to 1.0 (good).

        Deductions:
          - Contains error indicators: -0.4
          - Result length < 20 chars: -0.3
          - Result is empty / None: -0.5

        Args:
            tool_result: The raw tool execution result.

        Returns:
            Quality score between 0.0 and 1.0.
        """
        score = 1.0

        if tool_result is None:
            return 0.0

        text = str(tool_result)
        text_lower = text.lower()

        # Check for empty result
        if not text.strip():
            return 0.0

        # Check for error indicators
        for indicator in _ERROR_INDICATORS:
            if indicator in text_lower:
                score -= 0.4
                break  # one deduction is enough

        # Check for short result
        if len(text) < _MIN_TOOL_RESULT_LENGTH:
            score -= 0.3

        return max(0.0, score)

    def _evaluate_llm_response(self, response: str) -> float:
        """Score an LLM response from 0.0 (poor) to 1.0 (good).

        Deductions:
          - Contains uncertainty markers: -0.3
          - Response length < 50 chars: -0.3
          - Contradiction marker count > 2: -0.3

        Args:
            response: The LLM response text.

        Returns:
            Quality score between 0.0 and 1.0.
        """
        score = 1.0

        if not response:
            return 0.0

        text_lower = response.lower()

        # Check for uncertainty markers
        for marker in _UNCERTAINTY_MARKERS:
            if marker in text_lower:
                score -= 0.3
                break

        # Check for short response
        if len(response) < _MIN_LLM_RESPONSE_LENGTH:
            score -= 0.3

        # Check for excessive contradictions
        contradiction_count = 0
        for marker in _CONTRADICTION_MARKERS:
            contradiction_count += text_lower.count(marker)
        if contradiction_count > _MAX_CONTRADICTION_COUNT:
            score -= 0.3

        return max(0.0, score)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_response_text(llm_response: dict | None) -> str:
        """Extract the text content from an LLM response payload.

        The response dict may have ``content`` as a string or as a list of
        content blocks (``{"type": "text", "text": "..."}``).

        Args:
            llm_response: The LLM response dict, or None.

        Returns:
            Extracted text, or empty string if unavailable.
        """
        if llm_response is None:
            return ""

        content = llm_response.get("content", "")
        if isinstance(content, str):
            return content

        # List of content blocks
        if isinstance(content, list):
            parts: list[str] = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
            return " ".join(parts)

        return str(content)

    @staticmethod
    def _make_critique_record(
        source: str,
        score: float,
        details: str,
    ) -> dict:
        """Create a structured critique record for working memory.

        Args:
            source: "tool_result" or "llm_response".
            score: The computed quality score.
            details: Human-readable description of detected issues.

        Returns:
            A dict suitable for appending to ``context.working_memory``.
        """
        return {
            "type": "self_critique",
            "source": source,
            "quality_score": score,
            "details": details,
            "prompt": CRITIQUE_PROMPT,
            "timestamp": time.time(),
        }


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------


def _describe_tool_issues(tool_result: object) -> str:
    """Return a human-readable summary of quality issues in a tool result."""
    if tool_result is None:
        return "Tool result is None"

    text = str(tool_result)
    if not text.strip():
        return "Tool result is empty"

    issues: list[str] = []
    text_lower = text.lower()

    for indicator in _ERROR_INDICATORS:
        if indicator in text_lower:
            issues.append(f"contains error indicator ({indicator!r})")
            break

    if len(text) < _MIN_TOOL_RESULT_LENGTH:
        issues.append(f"result too short ({len(text)} chars)")

    return "; ".join(issues) if issues else "no issues"


def _describe_llm_issues(response: str) -> str:
    """Return a human-readable summary of quality issues in an LLM response."""
    if not response:
        return "LLM response is empty"

    issues: list[str] = []
    text_lower = response.lower()

    for marker in _UNCERTAINTY_MARKERS:
        if marker in text_lower:
            issues.append(f"contains uncertainty ({marker!r})")
            break

    if len(response) < _MIN_LLM_RESPONSE_LENGTH:
        issues.append(f"response too short ({len(response)} chars)")

    contradiction_count = 0
    for marker in _CONTRADICTION_MARKERS:
        contradiction_count += text_lower.count(marker)
    if contradiction_count > _MAX_CONTRADICTION_COUNT:
        issues.append(f"excessive contradictions ({contradiction_count})")

    return "; ".join(issues) if issues else "no issues"
