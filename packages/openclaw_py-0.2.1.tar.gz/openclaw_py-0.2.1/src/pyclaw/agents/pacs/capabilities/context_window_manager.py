"""ContextWindowManager — perception-layer capability that manages context window size.

Strategy:
1. Estimate total tokens in the current message list (chars / chars_per_token).
2. If current_tokens <= target_tokens (max_tokens * (1 - reserve_ratio)), return
   CONTINUE with no modifications.
3. When over limit, apply truncation:
   - Preserve all system-role messages.
   - From the most recent non-system messages, keep as many as fit within the
     token budget.
   - Always keep at least *keep_recent* non-system messages.
"""

from __future__ import annotations

from typing import Any, Literal

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)


class ContextWindowManager(AgenticCapability):
    """Perception-layer capability that trims messages to fit the context window.

    Ensures the total estimated token count stays within
    ``max_tokens * (1 - reserve_ratio)`` by truncating older non-system
    messages when the budget is exceeded.

    Args:
        max_tokens: Maximum context window size in tokens. Default 128000.
        reserve_ratio: Fraction of the window to reserve for model output.
            Default 0.3.
        strategy: Truncation strategy. Only "truncate" is implemented;
            "summarize" and "selective" are reserved for future use.
        keep_recent: Minimum number of non-system messages to always preserve
            from the tail. Default 4.
        chars_per_token: Rough character-to-token ratio for estimation.
            Default 4.0.
    """

    name = "context_window_manager"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks: list[HookPoint] = [
        HookPoint.PERCEPTION_PRE,
        HookPoint.LLM_PRE_INVOKE,
    ]
    priority = 15

    def __init__(
        self,
        max_tokens: int = 128000,
        reserve_ratio: float = 0.3,
        strategy: Literal["truncate", "summarize", "selective"] = "truncate",
        keep_recent: int = 4,
        chars_per_token: float = 4.0,
    ) -> None:
        self.max_tokens = max_tokens
        self.reserve_ratio = reserve_ratio
        self.strategy = strategy
        self.keep_recent = keep_recent
        self.chars_per_token = chars_per_token

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def target_tokens(self) -> int:
        """Maximum tokens available for messages after reserving output budget."""
        return int(self.max_tokens * (1 - self.reserve_ratio))

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only when there are messages to manage."""
        return event.messages is not None and len(event.messages) > 0

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Check context window usage and truncate if over limit."""
        messages = event.messages
        if not messages:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        current_tokens = self._estimate_tokens(messages)

        # Under budget — no action needed.
        if current_tokens <= self.target_tokens:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={
                    "current_tokens": current_tokens,
                    "target_tokens": self.target_tokens,
                    "truncated": False,
                },
            )

        # Over budget — apply truncation.
        truncated = self._truncate_messages(messages, self.target_tokens)
        truncated_tokens = self._estimate_tokens(truncated)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={"messages": truncated},
            capability_name=self.name,
            metrics={
                "current_tokens": current_tokens,
                "target_tokens": self.target_tokens,
                "truncated_tokens": truncated_tokens,
                "truncated": True,
                "messages_before": len(messages),
                "messages_after": len(truncated),
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _estimate_tokens(self, messages: list[dict[str, Any]]) -> int:
        """Estimate total token count for a message list.

        Uses a simple heuristic: sum all character content and divide by
        *chars_per_token*.

        Args:
            messages: List of message dicts with ``role`` and ``content`` keys.

        Returns:
            Estimated token count.
        """
        total_chars = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total_chars += len(content)
            elif isinstance(content, list):
                # Content blocks (e.g. [{"type": "text", "text": "..."}])
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        total_chars += len(block.get("text", ""))
                    else:
                        total_chars += len(str(block))
            else:
                total_chars += len(str(content))
        return int(total_chars / self.chars_per_token)

    def _truncate_messages(
        self,
        messages: list[dict[str, Any]],
        target_tokens: int,
    ) -> list[dict[str, Any]]:
        """Truncate messages to fit within *target_tokens*.

        Strategy:
        1. Collect all system messages (preserved in order).
        2. From the non-system messages, keep the most recent ones that fit
           within the remaining token budget, ensuring at least *keep_recent*
           messages are retained.

        Args:
            messages: Original message list.
            target_tokens: Token budget for the truncated result.

        Returns:
            Truncated list of messages.
        """
        system_messages: list[dict[str, Any]] = []
        non_system: list[dict[str, Any]] = []

        for msg in messages:
            if msg.get("role") == "system":
                system_messages.append(msg)
            else:
                non_system.append(msg)

        # Token budget remaining after system messages.
        system_tokens = self._estimate_tokens(system_messages)
        remaining_budget = max(0, target_tokens - system_tokens)

        # Always keep at least keep_recent non-system messages from the tail.
        guaranteed = non_system[-self.keep_recent :] if non_system else []
        guaranteed_tokens = self._estimate_tokens(guaranteed)

        # If even the guaranteed messages exceed the remaining budget, just
        # return system + guaranteed (best effort).
        if guaranteed_tokens >= remaining_budget:
            return system_messages + guaranteed

        # Walk backwards through older non-system messages and include those
        # that fit within the budget.
        older = non_system[: -self.keep_recent] if self.keep_recent <= len(non_system) else []
        included_older: list[dict[str, Any]] = []
        budget_left = remaining_budget - guaranteed_tokens

        for msg in reversed(older):
            msg_tokens = self._estimate_tokens([msg])
            if msg_tokens <= budget_left:
                included_older.insert(0, msg)
                budget_left -= msg_tokens
            else:
                # Stop once we can't fit an older message.
                break

        return system_messages + included_older + guaranteed
