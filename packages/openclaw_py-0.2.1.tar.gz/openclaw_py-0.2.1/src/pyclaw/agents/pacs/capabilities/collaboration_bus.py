"""CollaborationBus -- infrastructure-layer capability for cross-instance message passing.

Enables multiple PACS agent instances to collaborate by broadcasting turn reports
and session summaries through a shared channel stored in
``context.capability_state["_collab_channel"]``.

Shared channel structure::

    {
        "messages": [...],        # list of message dicts
        "subscribers": [...],     # registered agent ids
    }

Message structure::

    {
        "type": "turn_report" | "session_summary",
        "source_agent": "agent_id",
        "turn": 3,
        "tools_used": ["search", "read_file"],
        "output_summary": "Found the API documentation...",
        "errors": ["timeout on search"],
        "timestamp": 1234567890.0,
    }

Args:
    agent_id: Identifier for this agent instance. Default "default".
    max_channel_size: Maximum number of messages retained in the channel. Default 100.
"""

from __future__ import annotations

import logging
import time

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

_CHANNEL_KEY = "_collab_channel"


class CollaborationBus(AgenticCapability):
    """Infrastructure-layer capability for cross-instance collaboration.

    Broadcasts turn reports and session summaries to a shared channel so
    that multiple agent instances can coordinate their work.

    Args:
        agent_id: Identifier for this agent instance.
        max_channel_size: Maximum number of messages retained in the channel.
    """

    name = "collaboration_bus"
    layer = CapabilityLayer.INFRASTRUCTURE
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TURN_END,
        HookPoint.SESSION_END,
    ]
    priority = 95  # runs last

    def __init__(
        self,
        agent_id: str = "default",
        max_channel_size: int = 100,
    ) -> None:
        self.agent_id = agent_id
        self.max_channel_size = max_channel_size

    # ------------------------------------------------------------------
    # Channel helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _ensure_channel(context: AgentContext) -> dict:
        """Return the shared channel dict, creating it if absent."""
        channel = context.capability_state.get(_CHANNEL_KEY)
        if isinstance(channel, dict):
            return channel
        new_channel: dict = {"messages": [], "subscribers": []}
        context.capability_state[_CHANNEL_KEY] = new_channel
        return new_channel

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def publish(self, context: AgentContext, message: dict) -> None:
        """Publish a message to the shared channel.

        If the channel exceeds *max_channel_size*, the oldest messages are
        trimmed.

        Args:
            context: Session-scoped shared context.
            message: Arbitrary message dict to broadcast.
        """
        channel = self._ensure_channel(context)
        channel["messages"].append(message)

        # Enforce max channel size
        if len(channel["messages"]) > self.max_channel_size:
            channel["messages"] = channel["messages"][-self.max_channel_size :]

        logger.debug(
            "CollaborationBus [%s] published %s message",
            self.agent_id,
            message.get("type", "unknown"),
        )

    def read_messages(self, context: AgentContext, since_index: int = 0) -> list[dict]:
        """Read messages from the shared channel starting at *since_index*.

        Args:
            context: Session-scoped shared context.
            since_index: Return messages from this index onward.

        Returns:
            List of message dicts.
        """
        channel = self._ensure_channel(context)
        return channel["messages"][since_index:]

    def subscribe(self, context: AgentContext, agent_id: str) -> None:
        """Register an agent as a subscriber to the shared channel.

        Args:
            context: Session-scoped shared context.
            agent_id: The agent id to register.
        """
        channel = self._ensure_channel(context)
        if agent_id not in channel["subscribers"]:
            channel["subscribers"].append(agent_id)
            logger.debug("CollaborationBus: agent '%s' subscribed", agent_id)

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """CollaborationBus is always active on its subscribed hooks."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Dispatch to the appropriate handler based on hook point."""
        if event.hook == HookPoint.TURN_END:
            return await self._handle_turn_end(event, context)
        if event.hook == HookPoint.SESSION_END:
            return await self._handle_session_end(event, context)

        # Fallback
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Hook handlers
    # ------------------------------------------------------------------

    async def _handle_turn_end(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Collect turn info and broadcast a turn report.

        1. Collects tool usage, output summary, and errors from the event.
        2. Publishes a turn_report message to the shared channel.
        3. Checks for messages from other instances.
        """
        # Auto-subscribe this agent
        self.subscribe(context, self.agent_id)

        # Collect tool usage
        tools_used = self._collect_tool_usage(event, context)

        # Collect output summary (last 100 chars of the last assistant message)
        output_summary = self._extract_output_summary(event)

        # Collect errors
        errors = self._collect_errors(event)

        message = {
            "type": "turn_report",
            "source_agent": self.agent_id,
            "turn": event.turn,
            "tools_used": tools_used,
            "output_summary": output_summary,
            "errors": errors,
            "timestamp": time.time(),
        }

        self.publish(context, message)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={
                _CHANNEL_KEY: self._ensure_channel(context),
            },
            metrics={
                "tools_used_count": len(tools_used),
                "has_errors": len(errors) > 0,
            },
        )

    async def _handle_session_end(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Generate and broadcast a session summary.

        Aggregates turn reports from the shared channel into a final summary.
        """
        self.subscribe(context, self.agent_id)

        channel = self._ensure_channel(context)
        messages = channel.get("messages", [])

        # Aggregate turn reports
        turn_reports = [m for m in messages if m.get("type") == "turn_report"]
        all_tools_used: list[str] = []
        all_errors: list[str] = []
        for report in turn_reports:
            all_tools_used.extend(report.get("tools_used", []))
            all_errors.extend(report.get("errors", []))

        summary = {
            "type": "session_summary",
            "source_agent": self.agent_id,
            "turn": event.turn,
            "tools_used": sorted(set(all_tools_used)),
            "output_summary": f"Session completed with {len(turn_reports)} turns",
            "errors": all_errors,
            "timestamp": time.time(),
        }

        self.publish(context, summary)

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={
                _CHANNEL_KEY: channel,
            },
            metrics={
                "total_turns": len(turn_reports),
                "unique_tools": len(set(all_tools_used)),
                "total_errors": len(all_errors),
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _collect_tool_usage(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> list[str]:
        """Collect the list of tools used in this turn.

        Checks the event metadata and context for tool call information.

        Args:
            event: The hook event.
            context: Session-scoped shared context.

        Returns:
            List of tool name strings.
        """
        tools: list[str] = []

        # Check event metadata for tool calls
        metadata_tools = event.metadata.get("tools_used", [])
        if isinstance(metadata_tools, list):
            tools.extend(str(t) for t in metadata_tools)

        # Check tool_call in the event
        if isinstance(event.tool_call, dict):
            tool_name = event.tool_call.get("name")
            if tool_name and str(tool_name) not in tools:
                tools.append(str(tool_name))

        # Check context working_memory for tool records
        for entry in context.working_memory:
            if isinstance(entry, dict) and entry.get("role") == "tool":
                tool_name = entry.get("name")
                if tool_name and str(tool_name) not in tools:
                    tools.append(str(tool_name))

        return tools

    @staticmethod
    def _extract_output_summary(event: HookEvent) -> str:
        """Extract the last 100 characters of the last assistant message.

        Args:
            event: The hook event.

        Returns:
            Truncated output summary string.
        """
        messages = event.messages
        if not messages:
            return ""

        # Find the last assistant message
        for msg in reversed(messages):
            if isinstance(msg, dict) and msg.get("role") == "assistant":
                content = msg.get("content", "")
                if isinstance(content, str):
                    return content[-100:]
                break

        return ""

    @staticmethod
    def _collect_errors(event: HookEvent) -> list[str]:
        """Collect error descriptions from the event.

        Args:
            event: The hook event.

        Returns:
            List of error description strings.
        """
        errors: list[str] = []

        if event.error is not None:
            errors.append(str(event.error))

        if event.error_type:
            errors.append(event.error_type)

        # Check metadata for accumulated errors
        metadata_errors = event.metadata.get("errors", [])
        if isinstance(metadata_errors, list):
            errors.extend(str(e) for e in metadata_errors)

        return errors
