"""ReActController — reasoning-layer capability that injects the ReAct system prompt.

Injects a structured ReAct (Reasoning + Acting) system prompt at TURN_START,
guiding the LLM to follow a Thought → Action → Observation cycle for each step.
"""

from __future__ import annotations

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

REACT_SYSTEM_PROMPT = """\
You are a helpful assistant that follows the ReAct (Reasoning + Acting) pattern.

For each step, you should:
1. **Thought**: Think about what you need to do next. Analyze the current situation and plan your approach.
2. **Action**: Choose the most appropriate tool/action to take. Call the tool with proper parameters.
3. **Observation**: After receiving the tool result, analyze what you learned.

Repeat this cycle until you have a complete answer for the user.

Format your thoughts clearly:
- Use "Thought:" prefix for your reasoning
- Use tool calls for actions
- Use "Observation:" to summarize tool results

Always explain your reasoning before taking action."""


class ReActController(AgenticCapability):
    """Reasoning-layer capability that injects the ReAct system prompt.

    At the start of each turn, prepends a system message describing the
    ReAct (Reasoning + Acting) pattern so the LLM follows a structured
    Thought → Action → Observation cycle.

    Args:
        system_prompt: Custom system prompt. If None, uses the default
            REACT_SYSTEM_PROMPT.
    """

    name = "react_controller"
    layer = CapabilityLayer.REASONING
    subscribed_hooks: list[HookPoint] = [HookPoint.TURN_START]
    priority = 5

    def __init__(self, system_prompt: str | None = None) -> None:
        self.system_prompt = system_prompt or REACT_SYSTEM_PROMPT

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only on TURN_START."""
        return event.hook == HookPoint.TURN_START

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Inject the ReAct system prompt as the first system message."""
        system_message: dict[str, str] = {
            "role": "system",
            "content": self.system_prompt,
        }

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={"messages": [system_message]},
            capability_name=self.name,
        )
