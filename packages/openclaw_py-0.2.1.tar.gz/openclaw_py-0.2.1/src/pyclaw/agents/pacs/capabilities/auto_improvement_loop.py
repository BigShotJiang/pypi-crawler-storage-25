"""AutoImprovementLoop -- feedback-layer capability for correction-pattern analysis.

At SESSION_END, scans the conversation for user-correction patterns:
  - Signals like "not right" / "wrong" / "incorrect" / "no" / "false"
  - Fix phrases like "should be" / "actually" / "correct is"
Extracts correction cases (original error + user fix + tools involved),
classifies the error category, and stores structured records in long-term memory.

Error categories (heuristic):
  - ``factual_error`` -- content contains digits but was corrected
  - ``procedural_error`` -- content contains step/instruction words
  - ``code_error`` -- content contains code indicators (``def``, ``return``, braces)
  - ``general_correction`` -- everything else

Args:
    min_corrections_for_pattern: Minimum corrections needed to generate
        an improvement-pattern suggestion. Default 2.
    max_cases_per_session: Maximum correction cases extracted per session.
        Default 10.
"""

from __future__ import annotations

import json
import logging
import re
import time

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Key used in context.capability_state for the accumulated cases
_KEY_CASES = "_auto_improvement_cases"
_KEY_PATTERNS = "_auto_improvement_patterns"

# Correction-signal patterns (user says "you are wrong")
_CORRECTION_SIGNAL_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b(not right|wrong|incorrect|that'?s wrong|that'?s not right)\b", re.I),
    re.compile(r"(不对|错了|不正确|有误|错误)", re.I),
]

# Correction-fix patterns (user says "it should be X")
_CORRECTION_FIX_PATTERNS: list[re.Pattern[str]] = [
    re.compile(
        r"\b(should be|actually|correct (?:answer|value|one) is|the (?:right|correct) (?:answer|value) is)\b", re.I
    ),
    re.compile(r"(应该是|实际上是|正确的是|应该是|才对)", re.I),
]

# Code indicators for error classification
_CODE_INDICATORS: frozenset[str] = frozenset(
    {"def ", "class ", "return ", "import ", "function ", "=>", "&&", "||", "{", "}", ";"},
)

# Procedural words for error classification
_PROCEDURAL_WORDS: frozenset[str] = frozenset(
    {"step", "first", "then", "next", "finally", "after", "before", "follow"},
)

# Digit pattern for factual-error detection
_HAS_DIGIT_RE = re.compile(r"\d")


class AutoImprovementLoop(AgenticCapability):
    """Feedback-layer capability that extracts user-correction cases at SESSION_END.

    Subscribes to SESSION_END at priority 90 (last to run) so it can observe
    the complete conversation history before extracting correction patterns.

    Correction cases are stored in:
      - ``context.long_term_memory_refs`` as JSON strings
      - ``context.capability_state["_auto_improvement_cases"]`` as dicts

    If enough corrections accumulate (>= min_corrections_for_pattern), an
    improvement-pattern suggestion is also stored.
    """

    name = "auto_improvement_loop"
    layer = CapabilityLayer.FEEDBACK
    subscribed_hooks: list[HookPoint] = [HookPoint.SESSION_END]
    priority = 90  # last to run
    critical = False

    def __init__(
        self,
        min_corrections_for_pattern: int = 2,
        max_cases_per_session: int = 10,
    ) -> None:
        self.min_corrections_for_pattern = min_corrections_for_pattern
        self.max_cases_per_session = max_cases_per_session

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """AutoImprovementLoop is always active on SESSION_END."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Scan messages for correction patterns and store cases."""
        messages = event.messages or []
        cases = self.extract_corrections(messages)

        if not cases:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={"correction_count": 0},
            )

        # Enforce the per-session cap
        cases = cases[: self.max_cases_per_session]

        # Store in capability_state
        existing_cases: list[dict] = list(context.get(_KEY_CASES, []))
        existing_cases.extend(cases)

        # Build long_term_memory_refs entries
        memory_refs: list[str] = list(context.long_term_memory_refs)
        memory_refs.extend(json.dumps(c, ensure_ascii=False) for c in cases)

        # Generate improvement pattern if enough cases
        context_mods: dict = {
            "long_term_memory_refs": memory_refs,
            _KEY_CASES: existing_cases,
        }

        pattern_metrics: dict = {"correction_count": len(cases)}

        if len(existing_cases) >= self.min_corrections_for_pattern:
            pattern = _generate_improvement_pattern(existing_cases)
            context_mods[_KEY_PATTERNS] = pattern
            pattern_metrics["pattern_generated"] = True
            pattern_metrics["pattern_summary"] = pattern.get("summary", "")
        else:
            pattern_metrics["pattern_generated"] = False

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications=context_mods,
            metrics=pattern_metrics,
        )

    # ------------------------------------------------------------------
    # Public extraction method (testable)
    # ------------------------------------------------------------------

    def extract_corrections(self, messages: list[dict]) -> list[dict]:
        """Extract correction cases from a list of chat messages.

        Walks through messages looking for user messages that contain
        correction signals or fix phrases. When found, pairs them with
        the preceding assistant message to build a correction case.

        Args:
            messages: List of message dicts with "role" and "content" keys.

        Returns:
            List of correction-case dicts with keys: type, original_error,
            correction, tools_involved, error_category, timestamp.
        """
        cases: list[dict] = []
        now = time.time()
        i = 0

        while i < len(messages):
            msg = messages[i]
            if msg.get("role") != "user":
                i += 1
                continue

            text = _content_to_text(msg.get("content", ""))
            if not _is_correction(text):
                i += 1
                continue

            # Found a correction -- look back for the assistant message
            original_error = ""
            tools_involved: list[str] = []

            for j in range(i - 1, -1, -1):
                prev = messages[j]
                if prev.get("role") == "assistant":
                    original_error = _content_to_text(prev.get("content", ""))
                    tools_involved = _extract_tool_names(prev)
                    break

            case: dict = {
                "type": "correction_case",
                "original_error": original_error,
                "correction": text,
                "tools_involved": tools_involved,
                "error_category": _classify_error(original_error),
                "timestamp": now,
            }
            cases.append(case)

            # Enforce per-session limit early
            if len(cases) >= self.max_cases_per_session:
                break

            i += 1

        return cases


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------


def _content_to_text(content: object) -> str:
    """Extract plain text from message content.

    Content may be a plain string or a list of content blocks.

    Args:
        content: The raw message content value.

    Returns:
        Extracted text, or empty string.
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        return " ".join(parts)
    return str(content)


def _is_correction(text: str) -> bool:
    """Check whether a user message text contains correction signals.

    Args:
        text: The user message content.

    Returns:
        True if the text matches any correction-signal or fix pattern.
    """
    return any(pattern.search(text) for pattern in _CORRECTION_SIGNAL_PATTERNS) or any(
        pattern.search(text) for pattern in _CORRECTION_FIX_PATTERNS
    )


def _extract_tool_names(msg: dict) -> list[str]:
    """Extract tool names from tool_calls on an assistant message.

    Args:
        msg: An assistant message dict.

    Returns:
        List of tool name strings.
    """
    tool_calls = msg.get("tool_calls", [])
    if not tool_calls:
        return []
    names: list[str] = []
    for tc in tool_calls:
        if isinstance(tc, dict):
            name = tc.get("name", "")
            if name:
                names.append(name)
    return names


def _classify_error(text: str) -> str:
    """Classify the original error text into a heuristic category.

    Args:
        text: The assistant message content that was corrected.

    Returns:
        One of: "factual_error", "code_error", "procedural_error",
        "general_correction".
    """
    if not text:
        return "general_correction"

    text_lower = text.lower()

    # Code error: contains code indicators
    for indicator in _CODE_INDICATORS:
        if indicator in text_lower:
            return "code_error"

    # Factual error: contains digits
    if _HAS_DIGIT_RE.search(text):
        return "factual_error"

    # Procedural error: contains step/instruction words
    for word in _PROCEDURAL_WORDS:
        if word in text_lower:
            return "procedural_error"

    return "general_correction"


def _generate_improvement_pattern(cases: list[dict]) -> dict:
    """Generate an improvement-pattern suggestion from accumulated cases.

    Aggregates error categories and tool involvement to suggest areas
    where the agent can improve.

    Args:
        cases: List of correction-case dicts.

    Returns:
        A pattern dict with summary, category_counts, and tools_histogram.
    """
    category_counts: dict[str, int] = {}
    tools_histogram: dict[str, int] = {}

    for case in cases:
        cat = case.get("error_category", "unknown")
        category_counts[cat] = category_counts.get(cat, 0) + 1
        for tool in case.get("tools_involved", []):
            tools_histogram[tool] = tools_histogram.get(tool, 0) + 1

    # Build a human-readable summary
    top_category = max(category_counts, key=lambda k: category_counts[k]) if category_counts else "unknown"
    count = len(cases)
    summary = f"{count} corrections observed; most common: {top_category}"

    if tools_histogram:
        top_tool = max(tools_histogram, key=lambda k: tools_histogram[k])
        summary += f"; most involved tool: {top_tool}"

    return {
        "type": "improvement_pattern",
        "summary": summary,
        "category_counts": category_counts,
        "tools_histogram": tools_histogram,
        "total_corrections": count,
        "timestamp": time.time(),
    }
