"""SemanticFilter — perception-layer capability that trims irrelevant long messages.

Strategy:
1. Always preserve system-role messages.
2. Always preserve the most recent *keep_recent* messages.
3. Short messages (below *max_message_chars*) are always kept.
4. Long messages are kept only if they share keyword overlap with the
   current user query (last user message); otherwise they are filtered out.

This reduces context noise for the LLM while preserving the most relevant
information for the current turn.
"""

from __future__ import annotations

import re
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

# Minimal stop-word set for keyword extraction.
_STOP_WORDS: frozenset[str] = frozenset(
    {
        "a",
        "an",
        "the",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "shall",
        "can",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "as",
        "into",
        "through",
        "during",
        "before",
        "after",
        "above",
        "below",
        "between",
        "and",
        "but",
        "or",
        "not",
        "no",
        "nor",
        "so",
        "if",
        "then",
        "than",
        "too",
        "very",
        "just",
        "that",
        "this",
        "these",
        "those",
        "it",
        "its",
        "i",
        "me",
        "my",
        "we",
        "our",
        "you",
        "your",
        "he",
        "him",
        "his",
        "she",
        "her",
        "they",
        "them",
        "their",
        "what",
        "which",
        "who",
        "whom",
        "how",
        "when",
        "where",
        "why",
        "all",
        "each",
        "every",
        "both",
        "few",
        "more",
        "most",
        "other",
        "some",
        "such",
        "only",
        "own",
        "same",
        "also",
        "about",
        "up",
        "out",
        "here",
        "there",
    },
)

_WORD_RE = re.compile(r"[a-zA-Z\u4e00-\u9fff]{2,}")


def _extract_keywords(text: str) -> set[str]:
    """Extract meaningful keywords from text, dropping stop-words."""
    words = _WORD_RE.findall(text.lower())
    return {w for w in words if w not in _STOP_WORDS}


def _keyword_overlap(keywords_a: set[str], keywords_b: set[str]) -> float:
    """Compute Jaccard-like overlap ratio of *keywords_a* in *keywords_b*.

    Returns the fraction of keywords_a that appear in keywords_b.
    If keywords_a is empty, returns 0.0 (nothing to overlap with).
    """
    if not keywords_a:
        return 0.0
    overlap = keywords_a & keywords_b
    return len(overlap) / len(keywords_a)


class SemanticFilter(AgenticCapability):
    """Perception-layer capability that filters irrelevant long messages.

    Keeps the conversation context focused on the current query by removing
    old, long messages that share no keyword overlap with the latest user
    message.

    Args:
        relevance_threshold: Minimum keyword-overlap ratio (0-1) for a long
            message to be considered relevant. Default 0.5.
        max_message_chars: Messages longer than this are candidates for
            filtering. Default 2000.
        keep_recent: Number of most-recent messages to always preserve.
            Default 4.
    """

    name = "semantic_filter"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks: list[HookPoint] = [
        HookPoint.PERCEPTION_PRE,
        HookPoint.PERCEPTION_OBSERVATION,
    ]
    priority = 10

    def __init__(
        self,
        relevance_threshold: float = 0.5,
        max_message_chars: int = 2000,
        keep_recent: int = 4,
    ) -> None:
        self.relevance_threshold = relevance_threshold
        self.max_message_chars = max_message_chars
        self.keep_recent = keep_recent

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only when there are messages to filter."""
        return event.messages is not None and len(event.messages) > 0

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Filter messages based on relevance to the current query."""
        messages = event.messages
        if not messages:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Identify the latest user message as the "query".
        query_keywords = self._extract_query_keywords(messages)

        # Indices that are always preserved.
        recent_start = max(0, len(messages) - self.keep_recent)
        recent_indices = set(range(recent_start, len(messages)))

        filtered: list[dict[str, Any]] = []
        kept_count = 0
        dropped_count = 0

        for idx, msg in enumerate(messages):
            if self._should_keep(msg, idx, recent_indices, query_keywords):
                filtered.append(msg)
                kept_count += 1
            else:
                dropped_count += 1

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={"messages": filtered},
            capability_name=self.name,
            metrics={
                "messages_kept": kept_count,
                "messages_dropped": dropped_count,
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _extract_query_keywords(self, messages: list[dict[str, Any]]) -> set[str]:
        """Extract keywords from the last user message."""
        for msg in reversed(messages):
            role = msg.get("role", "")
            if role == "user":
                content = msg.get("content", "")
                if isinstance(content, str):
                    return _extract_keywords(content)
                # content may be a list of content blocks
                if isinstance(content, list):
                    text_parts = [
                        block.get("text", "")
                        for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    ]
                    return _extract_keywords(" ".join(text_parts))
        return set()

    def _should_keep(
        self,
        msg: dict[str, Any],
        idx: int,
        recent_indices: set[int],
        query_keywords: set[str],
    ) -> bool:
        """Decide whether a single message should be kept."""
        # Rule 1: Always keep system messages.
        if msg.get("role") == "system":
            return True

        # Rule 2: Always keep recent messages.
        if idx in recent_indices:
            return True

        # Rule 3: Short messages are always kept.
        content = msg.get("content", "")
        text = content if isinstance(content, str) else str(content)
        if len(text) < self.max_message_chars:
            return True

        # Rule 4: Long messages — check keyword overlap with query.
        msg_keywords = _extract_keywords(text)
        overlap = _keyword_overlap(msg_keywords, query_keywords)
        return overlap >= self.relevance_threshold
