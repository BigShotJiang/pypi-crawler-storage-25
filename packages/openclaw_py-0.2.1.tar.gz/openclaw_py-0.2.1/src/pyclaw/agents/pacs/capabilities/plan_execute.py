"""PlanExecute -- reasoning-layer capability that drives plan-then-execute behavior.

At TURN_START, evaluates whether the user request requires multi-step
execution. If so, creates a structured plan and guides the agent through
each step. Tracks step completion via TOOL_POST_EXECUTE and finalizes
the plan at TURN_END.
"""

from __future__ import annotations

import time
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

PLANNING_PROMPT = """\
You are following a structured plan-and-execute approach.

Current plan:
{plan_summary}

Execute each step one at a time. After completing a step, move on to the next.
When all steps are complete, summarize the results for the user.

Guidelines:
- Focus on the current step; do not skip ahead.
- Use available tools to accomplish each step.
- If a step cannot be completed, note the issue and proceed if possible.
- After all steps are done, provide a clear summary."""


class PlanExecute(AgenticCapability):
    """Reasoning-layer capability that drives plan-then-execute behavior.

    Subscribes to three hook points:
    - TURN_START: creates a plan when the task is complex enough.
    - TOOL_POST_EXECUTE: marks the current step as completed.
    - TURN_END: checks if all steps are done and sets phase to "completed".

    Args:
        auto_plan_threshold: Number of turns before automatically suggesting
            a plan. Default 3.
    """

    name = "plan_execute"
    layer = CapabilityLayer.REASONING
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TURN_START,
        HookPoint.TOOL_POST_EXECUTE,
        HookPoint.TURN_END,
    ]
    priority = 8

    def __init__(self, auto_plan_threshold: int = 3) -> None:
        self.auto_plan_threshold = auto_plan_threshold

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Always activate -- PlanExecute runs on every subscribed hook."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Dispatch to hook-specific handler."""
        if event.hook == HookPoint.TURN_START:
            return await self._on_turn_start(event, context)
        if event.hook == HookPoint.TOOL_POST_EXECUTE:
            return await self._on_tool_post_execute(event, context)
        if event.hook == HookPoint.TURN_END:
            return await self._on_turn_end(event, context)

        # Should not happen, but be safe
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # TURN_START
    # ------------------------------------------------------------------

    async def _on_turn_start(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """At turn start, create a plan if none exists and the task is complex."""
        # Skip if a plan already exists
        if context.active_plan is not None:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={"plan_already_exists": True},
            )

        # Determine if planning is needed based on turn count / complexity
        needs_plan = self._should_create_plan(event, context)

        if not needs_plan:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={"needs_plan": False},
            )

        # Create a placeholder plan structure.
        # In production the LLM would populate actual steps;
        # here we create the scaffolding so the tracking loop works.
        plan = self._create_plan(event, context)

        # Build system prompt with plan summary
        plan_summary = self._format_plan_summary(plan)
        system_message: dict[str, str] = {
            "role": "system",
            "content": PLANNING_PROMPT.format(plan_summary=plan_summary),
        }

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={
                "current_phase": "planning",
                "active_plan": plan,
            },
            event_modifications={"messages": [system_message]},
            output={"plan_created": True},
            output_type="plan_created",
            capability_name=self.name,
            metrics={"needs_plan": True, "plan_steps": len(plan["steps"])},
        )

    # ------------------------------------------------------------------
    # TOOL_POST_EXECUTE
    # ------------------------------------------------------------------

    async def _on_tool_post_execute(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Mark the current plan step as completed after a tool executes."""
        plan = context.active_plan
        if plan is None:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={"no_active_plan": True},
            )

        # Mark current step as completed and advance
        current_idx = plan["current_step_index"]
        steps = plan["steps"]

        if current_idx < len(steps):
            steps[current_idx]["status"] = "completed"
            plan["current_step_index"] = current_idx + 1

            # Move to next step if available
            if plan["current_step_index"] < len(steps):
                steps[plan["current_step_index"]]["status"] = "in_progress"

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={"active_plan": plan},
            capability_name=self.name,
            metrics={
                "step_completed": current_idx,
                "next_step": plan["current_step_index"],
            },
        )

    # ------------------------------------------------------------------
    # TURN_END
    # ------------------------------------------------------------------

    async def _on_turn_end(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Check if the plan is completed and set phase accordingly."""
        plan = context.active_plan
        if plan is None:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                metrics={"no_active_plan": True},
            )

        all_completed = all(step["status"] == "completed" for step in plan["steps"])

        if all_completed:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                context_modifications={"current_phase": "completed"},
                output={"plan_completed": True},
                output_type="plan_completed",
                capability_name=self.name,
                metrics={"plan_fully_completed": True},
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            metrics={
                "plan_fully_completed": False,
                "remaining_steps": sum(1 for s in plan["steps"] if s["status"] != "completed"),
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _should_create_plan(self, event: HookEvent, context: AgentContext) -> bool:
        """Decide whether a plan should be created.

        Uses turn count and task complexity as signals:
        - If turn >= auto_plan_threshold, suggest planning.
        - If task_complexity > 0.5, suggest planning.

        Args:
            event: The hook event (used for turn count).
            context: Session context (used for task_complexity).

        Returns:
            True if a plan should be created.
        """
        if event.turn >= self.auto_plan_threshold:
            return True
        return context.task_complexity > 0.5

    def _create_plan(self, event: HookEvent, context: AgentContext) -> dict[str, Any]:
        """Create a plan structure with placeholder steps.

        The number of steps is derived from task_complexity (clamped 2-6).
        In a production system the LLM would generate real step descriptions.

        Args:
            event: The hook event.
            context: Session context.

        Returns:
            Plan dict with steps list and metadata.
        """
        # Derive step count from complexity (2-6 steps)
        num_steps = max(2, min(6, int(context.task_complexity * 6) + 2))

        steps: list[dict[str, Any]] = []
        for i in range(num_steps):
            steps.append(
                {
                    "id": i + 1,
                    "description": f"Step {i + 1}",
                    "status": "pending" if i > 0 else "in_progress",
                }
            )

        return {
            "steps": steps,
            "current_step_index": 0,
            "created_at": time.time(),
        }

    def _format_plan_summary(self, plan: dict[str, Any]) -> str:
        """Render plan steps as a human-readable summary.

        Args:
            plan: The plan dict.

        Returns:
            Multi-line string describing each step and its status.
        """
        lines: list[str] = []
        for step in plan["steps"]:
            status_marker = {
                "pending": "[ ]",
                "in_progress": "[>]",
                "completed": "[x]",
            }.get(step["status"], "[ ]")
            lines.append(f"  {status_marker} Step {step['id']}: {step['description']}")

        return "\n".join(lines)
