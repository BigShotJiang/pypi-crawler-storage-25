"""ToolRetryBackoff — action-layer capability for exponential backoff on tool failures.

Provides retry logic with exponential backoff for tool execution failures. When a
tool fails with a retriable error (timeout, rate_limit), the capability tracks the
failure and calculates an appropriate backoff delay. Subsequent calls to the same
tool during the backoff period are skipped.

Per-tool tracking:
- _retry_counts: dict[str, int] — retry attempts per tool
- _last_retry_time: dict[str, float] — epoch timestamp of most recent failure
- _backoff_until: dict[str, float] — epoch timestamp until backoff expires

Args:
    base_delay: Base delay in seconds for exponential backoff. Default 1.0.
    max_delay: Maximum delay in seconds. Default 30.0.
    max_retries: Maximum retry attempts before giving up. Default 3.
"""

from __future__ import annotations

import logging
import time

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Error types that are considered retriable
RETRIABLE_ERROR_TYPES: frozenset[str] = frozenset(
    {
        "timeout",
        "rate_limit",
        "rate_limited",
        "connection_error",
        "service_unavailable",
        "internal_error",
        "temporary_failure",
    }
)


class ToolRetryBackoff(AgenticCapability):
    """Action-layer capability that provides exponential backoff for tool retries.

    When a tool fails with a retriable error type, this capability:
    1. Tracks the retry count for that tool
    2. Calculates an exponential backoff delay
    3. Skips subsequent calls during the backoff period
    4. Returns RETRY signal when appropriate

    The backoff formula is: base_delay * (2 ^ retry_count), capped at max_delay.

    Args:
        base_delay: Base delay in seconds for exponential backoff.
        max_delay: Maximum delay in seconds.
        max_retries: Maximum retry attempts before giving up.
    """

    name = "tool_retry_backoff"
    layer = CapabilityLayer.ACTION
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TOOL_ERROR,
        HookPoint.TOOL_PRE_EXECUTE,
    ]
    priority = 25  # After CircuitBreaker (priority 5)

    def __init__(
        self,
        base_delay: float = 1.0,
        max_delay: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.max_retries = max_retries

        # Per-tool tracking
        self._retry_counts: dict[str, int] = {}
        self._last_retry_time: dict[str, float] = {}
        self._backoff_until: dict[str, float] = {}

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def get_retry_count(self, tool_name: str) -> int:
        """Return the current retry count for *tool_name*."""
        return self._retry_counts.get(tool_name, 0)

    def get_backoff_remaining(self, tool_name: str) -> float:
        """Return remaining backoff time in seconds for *tool_name*."""
        backoff_until = self._backoff_until.get(tool_name, 0.0)
        remaining = backoff_until - time.monotonic()
        return max(0.0, remaining)

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """ToolRetryBackoff is always active on its subscribed hooks."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Dispatch to the appropriate handler based on hook point."""
        if event.hook == HookPoint.TOOL_ERROR:
            return self._handle_error(event)
        if event.hook == HookPoint.TOOL_PRE_EXECUTE:
            return self._handle_pre_execute(event, context)

        # Fallback — should never happen given should_activate is True
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Hook handlers
    # ------------------------------------------------------------------

    def _handle_error(self, event: HookEvent) -> CapabilityResult:
        """Record a tool failure and calculate backoff when appropriate.

        Only tracks failures for retriable error types. Non-retriable errors
        are ignored and pass through with CONTINUE.
        """
        tool_name = self._extract_tool_name(event)
        if not tool_name:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Check if error type is retriable
        error_type = event.error_type or ""
        if not self._is_retriable(error_type):
            logger.debug(
                "Tool %s error type '%s' is not retriable, skipping backoff",
                tool_name,
                error_type,
            )
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Increment retry count
        self._retry_counts[tool_name] = self._retry_counts.get(tool_name, 0) + 1
        self._last_retry_time[tool_name] = time.monotonic()

        retry_count = self._retry_counts[tool_name]

        # Calculate backoff delay
        backoff_delay = self._calculate_backoff(retry_count)

        # Set backoff expiration
        self._backoff_until[tool_name] = time.monotonic() + backoff_delay

        logger.info(
            "Tool %s failed with retriable error (retry=%d, backoff=%.1fs)",
            tool_name,
            retry_count,
            backoff_delay,
        )

        # Store backoff info in context for inter-capability communication
        context_modifications = {
            f"_retry_backoff_{tool_name}": {
                "retry_count": retry_count,
                "backoff_delay": backoff_delay,
                "backoff_until": self._backoff_until[tool_name],
            }
        }

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications=context_modifications,
            metrics={
                "tool": tool_name,
                "retry_count": retry_count,
                "backoff_delay": backoff_delay,
                "error_type": error_type,
            },
        )

    def _handle_pre_execute(self, event: HookEvent, context: AgentContext) -> CapabilityResult:
        """Check backoff state before a tool runs.

        If the tool is in a backoff period, return SKIP.
        If max retries exceeded, return SKIP (let CircuitBreaker handle it).
        Otherwise, allow the call through with CONTINUE.

        Returns RETRY if:
        - Retries not exhausted
        - Error was retriable
        - We're signaling a retry should occur
        """
        tool_name = self._extract_tool_name(event)
        if not tool_name:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        retry_count = self._retry_counts.get(tool_name, 0)

        # Check if max retries exceeded
        if retry_count >= self.max_retries:
            logger.info(
                "Tool %s exceeded max retries (%d >= %d), skipping",
                tool_name,
                retry_count,
                self.max_retries,
            )
            return CapabilityResult(
                action=CapabilityAction.SKIP,
                output=f"max_retries_exceeded:{tool_name}",
                capability_name=self.name,
                metrics={
                    "tool": tool_name,
                    "retry_count": retry_count,
                    "max_retries": self.max_retries,
                },
            )

        # Check if in backoff period
        backoff_remaining = self.get_backoff_remaining(tool_name)
        if backoff_remaining > 0:
            logger.info(
                "Tool %s in backoff period (%.1fs remaining), skipping",
                tool_name,
                backoff_remaining,
            )
            return CapabilityResult(
                action=CapabilityAction.SKIP,
                output=f"backoff_active:{tool_name}",
                capability_name=self.name,
                metrics={
                    "tool": tool_name,
                    "backoff_remaining": backoff_remaining,
                },
            )

        # Not in backoff, retries available — allow the call
        # If this is a retry (retry_count > 0), signal RETRY
        if retry_count > 0:
            return CapabilityResult(
                action=CapabilityAction.RETRY,
                capability_name=self.name,
                metrics={
                    "tool": tool_name,
                    "retry_count": retry_count,
                },
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _calculate_backoff(self, retry_count: int) -> float:
        """Calculate exponential backoff delay.

        Formula: base_delay * (2 ^ retry_count), capped at max_delay.

        Args:
            retry_count: The current retry attempt number.

        Returns:
            Delay in seconds.
        """
        delay = self.base_delay * (2 ** (retry_count - 1))
        return min(delay, self.max_delay)

    def _is_retriable(self, error_type: str) -> bool:
        """Check if an error type is retriable.

        Args:
            error_type: The error type string to check.

        Returns:
            True if the error type is retriable.
        """
        return error_type.lower() in RETRIABLE_ERROR_TYPES

    @staticmethod
    def _extract_tool_name(event: HookEvent) -> str:
        """Extract the tool name from the event's tool_call payload.

        tool_call is expected to be ``{"id": "...", "name": "...",
        "arguments": {...}}``.
        """
        tool_call = event.tool_call
        if isinstance(tool_call, dict):
            return str(tool_call.get("name", ""))
        return ""
