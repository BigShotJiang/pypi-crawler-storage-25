"""ToolOutputParser — perception-layer capability that processes tool outputs.

This capability normalizes and truncates tool outputs to ensure they are
readable and fit within context limits. It operates on TOOL_POST_EXECUTE
and PERCEPTION_OBSERVATION hooks.

Processing rules:
1. String outputs exceeding max_length are truncated with a suffix.
2. Dict/JSON outputs have key fields extracted (content, result, output, data).
3. Large binary/base64 data is filtered out.
4. Nested structures are flattened to extract readable text.

Args:
    max_length: Maximum length for text output before truncation. Default 2000.
    truncate_suffix: Suffix template for truncated output. Supports {omitted}
        placeholder for the number of bytes omitted.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# Key fields to extract from dict outputs, in priority order
_KEY_FIELDS = ("content", "result", "output", "data", "message", "text", "response")

# Pattern to detect embedded base64 data blocks within text.
# Requires mixed characters to avoid false positives on repeated-char strings.
# Matches 100+ chars of base64 alphabet with at least some variety.
_BASE64_PATTERN = re.compile(r"[A-Za-z0-9+/]{100,}={0,2}")


class ToolOutputParser(AgenticCapability):
    """Perception-layer capability that parses and truncates tool outputs.

    This capability processes tool results to:
    - Extract readable text from structured outputs
    - Truncate excessively long outputs
    - Filter out binary/base64 data

    Args:
        max_length: Maximum length for text output before truncation.
        truncate_suffix: Suffix template for truncated output.
    """

    name = "tool_output_parser"
    layer = CapabilityLayer.PERCEPTION
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TOOL_POST_EXECUTE,
        HookPoint.PERCEPTION_OBSERVATION,
    ]
    priority = 20

    def __init__(
        self,
        max_length: int = 2000,
        truncate_suffix: str = "...[truncated, {omitted} bytes omitted]",
    ) -> None:
        self.max_length = max_length
        self.truncate_suffix = truncate_suffix

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only when tool_result exists in the event."""
        return event.tool_result is not None

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Process the tool_result and return modified output."""
        result = event.tool_result
        if result is None:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Parse and extract readable text
        parsed = self._parse_tool_result(result)

        # Truncate if necessary
        truncated = self._truncate(parsed, self.max_length)

        # Return modified event
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            event_modifications={"tool_result": truncated},
            capability_name=self.name,
            metrics={
                "original_type": type(result).__name__,
                "original_length": len(parsed) if parsed else 0,
                "was_truncated": len(parsed) > self.max_length if parsed else False,
            },
        )

    # ------------------------------------------------------------------
    # Helper methods
    # ------------------------------------------------------------------

    def _parse_tool_result(self, result: Any) -> str:
        """Extract readable text from a tool result.

        Handles strings, dicts, and nested structures.

        Args:
            result: The raw tool result.

        Returns:
            Extracted readable text, or stringified result.
        """
        if result is None:
            return ""

        # Handle string directly
        if isinstance(result, str):
            return self._filter_base64(result)

        # Handle dict/JSON
        if isinstance(result, dict):
            return self._extract_from_dict(result)

        # Handle lists
        if isinstance(result, list):
            return self._extract_from_list(result)

        # Fallback: stringify
        try:
            text = str(result)
            return self._filter_base64(text)
        except Exception:
            return "<unparseable result>"

    def _extract_from_dict(self, data: dict[str, Any]) -> str:
        """Extract readable text from a dictionary.

        Prioritizes key fields like 'content', 'result', 'output', 'data'.
        Falls back to JSON representation with binary data filtered.

        Args:
            data: Dictionary to extract from.

        Returns:
            Extracted text.
        """
        # Try key fields first
        for key in _KEY_FIELDS:
            if key in data:
                value = data[key]
                if isinstance(value, str) and value:
                    return self._filter_base64(value)
                if isinstance(value, dict | list):
                    extracted = self._parse_tool_result(value)
                    if extracted and extracted != "{}" and extracted != "[]":
                        return extracted

        # Filter out large/binary fields and serialize
        filtered = self._filter_dict(data)
        try:
            return json.dumps(filtered, ensure_ascii=False, indent=2)
        except (TypeError, ValueError):
            return str(filtered)

    def _extract_from_list(self, data: list[Any]) -> str:
        """Extract readable text from a list.

        Args:
            data: List to extract from.

        Returns:
            Extracted text.
        """
        if not data:
            return "[]"

        # Process each item
        items: list[str] = []
        for item in data[:10]:  # Limit to first 10 items
            text = self._parse_tool_result(item)
            if text:
                items.append(text)

        if not items:
            return "[]"

        result = "\n".join(items)

        # Truncate if too long
        if len(result) > self.max_length:
            result = self._truncate(result, self.max_length)

        return result

    def _filter_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        """Filter out binary/large fields from a dictionary.

        Args:
            data: Dictionary to filter.

        Returns:
            Filtered dictionary.
        """
        result: dict[str, Any] = {}
        for key, value in data.items():
            # Skip keys that typically contain binary data
            if key.lower() in (
                "image",
                "images",
                "file",
                "files",
                "blob",
                "blob_url",
                "base64",
                "data_url",
                "thumbnail",
            ):
                result[key] = f"<{key} omitted>"
                continue

            # Check for base64 strings (must be varied)
            if isinstance(value, str) and self._looks_like_base64(value):
                result[key] = "<base64 data omitted>"
                continue

            # Check for very long strings
            if isinstance(value, str) and len(value) > 10000:
                result[key] = f"<long string, {len(value)} chars>"
                continue

            # Recurse into nested dicts
            if isinstance(value, dict):
                result[key] = self._filter_dict(value)
                continue

            # Keep other values
            result[key] = value

        return result

    def _filter_base64(self, text: str) -> str:
        """Filter out base64-like content from text.

        Only replaces embedded base64 blocks, not the entire string if it's
        just regular text that happens to be long.

        Args:
            text: Text to filter.

        Returns:
            Filtered text.
        """
        # Don't process if the entire string is just repeated characters
        # (e.g., "AAAAAA" for test padding)
        if len(set(text)) <= 2:
            return text

        # Replace embedded base64-like strings with placeholder
        def replace_base64(match: re.Match[str]) -> str:
            matched = match.group(0)
            # Check if this look like real base64 (has variety of chars)
            if len(set(matched)) < 10:
                return matched  # Not varied enough, likely not base64
            return f"<base64 data, {len(matched)} bytes>"

        return _BASE64_PATTERN.sub(replace_base64, text)

    def _looks_like_base64(self, value: str) -> bool:
        """Check if a string looks like base64 encoded data.

        Args:
            value: String to check.

        Returns:
            True if the string appears to be base64 data.
        """
        if len(value) < 100:
            return False
        # Must have variety of characters
        if len(set(value.strip("="))) < 10:
            return False
        # Must only contain base64 alphabet
        return bool(_BASE64_PATTERN.fullmatch(value))

    def _truncate(self, text: str, max_length: int) -> str:
        """Truncate text to max_length with suffix.

        Args:
            text: Text to truncate.
            max_length: Maximum length.

        Returns:
            Truncated text with suffix, or original if under limit.
        """
        if not text or len(text) <= max_length:
            return text

        omitted = len(text) - max_length
        suffix = self.truncate_suffix.format(omitted=omitted)

        # Account for suffix length
        truncate_at = max_length - len(suffix)
        if truncate_at < 0:
            truncate_at = max_length // 2

        return text[:truncate_at] + suffix
