"""ModelRouter — action-layer capability that selects models based on task complexity.

Strategy:
1. Read task_complexity from the session context (default 0.0).
2. Route to the appropriate model tier:
   - complexity < low_threshold  -> fast_model      (lightweight)
   - complexity < high_threshold -> default_model    (standard)
   - complexity >= high_threshold -> reasoning_model  (advanced)
3. Write selected_model into context_modifications so downstream consumers
   (e.g. the LLM invocation layer) can pick it up.

Model configuration resolution (highest priority wins):
1. Constructor arguments (per-instance overrides)
2. context.model_config dict
3. Built-in defaults
"""

from __future__ import annotations

from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)


class ModelRouter(AgenticCapability):
    """Action-layer capability that routes to the best model for task complexity.

    Args:
        fast_model: Model identifier for simple tasks. Default ``"gpt-4o-mini"``.
        default_model: Model identifier for medium-complexity tasks.
            Default ``"gpt-4o"``.
        reasoning_model: Model identifier for complex tasks. Default ``"o1"``.
        complexity_thresholds: ``(low, high)`` thresholds that partition
            complexity into three tiers. Default ``(0.3, 0.7)``.
    """

    name = "model_router"
    layer = CapabilityLayer.ACTION
    subscribed_hooks: list[HookPoint] = [HookPoint.LLM_PRE_INVOKE]
    priority = 30

    def __init__(
        self,
        fast_model: str | None = "gpt-4o-mini",
        default_model: str = "gpt-4o",
        reasoning_model: str | None = "o1",
        complexity_thresholds: tuple[float, float] = (0.3, 0.7),
    ) -> None:
        self.fast_model = fast_model
        self.default_model = default_model
        self.reasoning_model = reasoning_model
        self.complexity_thresholds = complexity_thresholds

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only when model routing config is available.

        Returns True if either the constructor config or
        ``context.model_config`` provides routing information.
        """
        if context.model_config is not None:
            return True
        # Constructor always carries defaults, so we always activate when
        # model_config is present. If model_config is None we still activate
        # because the constructor provides defaults.
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Select the appropriate model based on task complexity.

        Reads ``context.task_complexity`` and writes ``selected_model``
        into ``context_modifications``.
        """
        complexity = context.task_complexity

        # Resolve model names with priority: constructor > model_config > default
        fast, default, reasoning = self._resolve_models(context)
        low, high = self.complexity_thresholds

        if complexity < low:
            selected = fast
        elif complexity < high:
            selected = default
        else:
            selected = reasoning

        # Fallback: if the selected tier is None, use default_model
        if selected is None:
            selected = default

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            context_modifications={"selected_model": selected},
            capability_name=self.name,
            metrics={
                "task_complexity": complexity,
                "selected_model": selected,
                "threshold_low": low,
                "threshold_high": high,
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_models(
        self,
        context: AgentContext,
    ) -> tuple[str | None, str, str | None]:
        """Resolve model identifiers from constructor and context.

        Priority: constructor args > context.model_config > defaults.

        Args:
            context: Session-scoped context, may carry ``model_config`` dict.

        Returns:
            ``(fast_model, default_model, reasoning_model)`` tuple.
        """
        mc: dict[str, Any] = {}
        if isinstance(context.model_config, dict):
            mc = context.model_config

        fast = mc.get("fast_model", self.fast_model)
        default = mc.get("default_model", self.default_model)
        reasoning = mc.get("reasoning_model", self.reasoning_model)

        return fast, default, reasoning
