"""DualLLM -- action-layer capability for privileged-model security review.

Uses a separate (privileged) model to review tool-call safety before
execution.  In this MVP the "model" is a fast heuristic rule engine;
the ``privileged_model`` constructor parameter is reserved for a future
LLM-based auditor.

Security review rules (MVP heuristics):
- Write operations targeting paths outside the workspace
- Dangerous shell commands (rm -rf, format, mkfs, etc.)
- HTTP requests to untrusted / internal URLs
- SQL statements that modify data (INSERT, UPDATE, DELETE, DROP)

Runs at priority 15 (after ActionValidator at priority 1) and is
marked ``critical=True`` so any flagged violation aborts the tool call.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SENSITIVE_TOOLS: frozenset[str] = frozenset(
    {
        "execute",
        "exec",
        "shell",
        "run_command",
        "write_file",
        "edit_file",
        "delete_file",
        "database_query",
        "sql_execute",
        "http_request",
        "fetch_url",
    }
)

# Dangerous shell commands
_DANGEROUS_COMMAND_RE = re.compile(
    r"\b(rm\s+-rf|rmdir\s+/|format\s+[a-zA-Z]:|mkfs|dd\s+if=|"
    r":\(\)\{.*;\}|chmod\s+-R\s+777|chown\s+-R)",
    re.IGNORECASE,
)

# Data-modifying SQL keywords
_DATA_MODIFYING_SQL_RE = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER)\b",
    re.IGNORECASE,
)

# Untrusted / internal URL patterns
_UNTRUSTED_URL_RE = re.compile(
    r"(?:^|://)"
    r"(?:"
    r"localhost|127\.0\.0\.1|0\.0\.0\.0|"
    r"10\.\d{1,3}\.\d{1,3}\.\d{1,3}|"
    r"172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|"
    r"192\.168\.\d{1,3}\.\d{1,3}|"
    r"\[::1\]|"
    r"metadata\.google\.internal|"
    r"169\.254\.169\.254"
    r")"
    r"(?::\d+)?(?:/|$)",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Capability
# ---------------------------------------------------------------------------


class DualLLM(AgenticCapability):
    """Action-layer capability that reviews sensitive tool calls for safety.

    Uses heuristic rules (MVP) with a reserved slot for a privileged LLM
    auditor in a future iteration.

    Args:
        privileged_model: Reserved for future LLM-based review.
            Pass ``None`` (default) to use heuristic rules only.
        sensitivity_threshold: Confidence threshold for flagging a tool
            call as unsafe.  Currently informational; reserved for the
            LLM auditor.
    """

    name = "dual_llm"
    layer = CapabilityLayer.ACTION
    subscribed_hooks: list[HookPoint] = [HookPoint.TOOL_PRE_EXECUTE]
    priority = 15
    critical = True  # safety capability -- abort on violation

    def __init__(
        self,
        privileged_model: str | None = None,
        sensitivity_threshold: float = 0.7,
    ) -> None:
        self.privileged_model = privileged_model
        self.sensitivity_threshold = sensitivity_threshold

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """Activate only when a tool_call is present."""
        return event.tool_call is not None

    # ------------------------------------------------------------------
    # Core review logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Review tool-call safety using heuristic rules.

        Non-sensitive tools pass through immediately.  For sensitive
        tools the arguments are checked against security rules.

        Returns:
            ABORT with a ``security_violation:...`` output if a rule
            fires.  CONTINUE otherwise.
        """
        tool_call = event.tool_call
        if not tool_call:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        tool_name = self._get_tool_name(tool_call)
        if not tool_name or tool_name not in SENSITIVE_TOOLS:
            # Non-sensitive tool -- pass through
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        arguments = self._extract_arguments(tool_call)

        # --- Check 1: dangerous commands (exec / shell tools) ---
        if tool_name in {"execute", "exec", "shell", "run_command"}:
            violation = self._check_dangerous_commands(arguments)
            if violation:
                logger.warning(
                    "DualLLM blocked dangerous command: %s",
                    violation,
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:dangerous_command:{violation}",
                    capability_name=self.name,
                )

        # --- Check 2: writes outside workspace ---
        if tool_name in {"write_file", "edit_file", "delete_file"}:
            violation = self._check_workspace_escape(arguments, context)
            if violation:
                logger.warning(
                    "DualLLM blocked out-of-workspace write: %s",
                    violation,
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:workspace_escape:{violation}",
                    capability_name=self.name,
                )

        # --- Check 3: data-modifying SQL ---
        if tool_name in {"database_query", "sql_execute"}:
            violation = self._check_data_modifying_sql(arguments)
            if violation:
                logger.warning(
                    "DualLLM blocked data-modifying SQL: %s",
                    violation,
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:data_modifying_sql:{violation}",
                    capability_name=self.name,
                )

        # --- Check 4: untrusted URLs ---
        if tool_name in {"http_request", "fetch_url"}:
            violation = self._check_untrusted_url(arguments)
            if violation:
                logger.warning(
                    "DualLLM blocked untrusted URL: %s",
                    violation,
                )
                return CapabilityResult(
                    action=CapabilityAction.ABORT,
                    output=f"security_violation:untrusted_url:{violation}",
                    capability_name=self.name,
                )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Security rule helpers
    # ------------------------------------------------------------------

    def _check_dangerous_commands(self, arguments: dict[str, Any]) -> str | None:
        """Return a description if a dangerous command pattern is found."""
        for _key, value in arguments.items():
            if isinstance(value, str) and _DANGEROUS_COMMAND_RE.search(value):
                return value[:80]
        return None

    def _check_workspace_escape(
        self,
        arguments: dict[str, Any],
        context: AgentContext,
    ) -> str | None:
        """Return a description if a write targets outside the workspace."""
        workspace = context.workspace
        path_keys = {"path", "file_path", "filename", "destination", "target"}

        for key in path_keys:
            value = arguments.get(key)
            if not isinstance(value, str) or not value:
                continue

            # Absolute path that is not under the workspace
            if value.startswith("/"):
                if workspace and not value.startswith(str(workspace)):
                    return f"{key}={value}"
                if not workspace:
                    # No workspace configured -- any absolute path is suspect
                    return f"{key}={value}"

            # Relative path with traversal
            if ".." in value:
                return f"{key}={value}"

        return None

    def _check_data_modifying_sql(self, arguments: dict[str, Any]) -> str | None:
        """Return a description if SQL modifies data."""
        sql_keys = {"query", "sql", "statement", "command"}
        for key in sql_keys:
            value = arguments.get(key)
            if isinstance(value, str) and _DATA_MODIFYING_SQL_RE.search(value):
                return f"{key}={value[:80]}"
        return None

    def _check_untrusted_url(self, arguments: dict[str, Any]) -> str | None:
        """Return a description if an HTTP target is an untrusted URL."""
        url_keys = {"url", "endpoint", "uri", "address", "target"}
        for key in url_keys:
            value = arguments.get(key)
            if isinstance(value, str) and _UNTRUSTED_URL_RE.search(value):
                return f"{key}={value[:80]}"
        return None

    # ------------------------------------------------------------------
    # Tool call helpers (same extraction pattern as ActionValidator)
    # ------------------------------------------------------------------

    def _extract_arguments(self, tool_call: Any) -> dict[str, Any]:
        """Extract arguments dict from a tool_call object.

        Handles various formats:
        - Direct ``.arguments`` dict
        - ``.function.arguments`` (OpenAI-style JSON string or dict)
        - kwargs-style ``__dict__``
        """
        if hasattr(tool_call, "arguments"):
            args = tool_call.arguments
            if isinstance(args, dict):
                return args

        if hasattr(tool_call, "function"):
            func = tool_call.function
            if hasattr(func, "arguments"):
                args = func.arguments
                if isinstance(args, dict):
                    return args
                if isinstance(args, str):
                    import json

                    try:
                        parsed = json.loads(args)
                        if isinstance(parsed, dict):
                            return parsed
                    except json.JSONDecodeError:
                        pass

        if hasattr(tool_call, "__dict__"):
            return {k: v for k, v in tool_call.__dict__.items() if not k.startswith("_") and k not in {"name", "id"}}

        return {}

    @staticmethod
    def _get_tool_name(tool_call: Any) -> str | None:
        """Extract the tool name from a tool_call object."""
        if hasattr(tool_call, "name"):
            return tool_call.name

        if hasattr(tool_call, "function") and hasattr(tool_call.function, "name"):
            return tool_call.function.name

        if hasattr(tool_call, "__dict__") and "name" in tool_call.__dict__:
            return tool_call.__dict__["name"]

        return None
