"""OutputGroundingCheck -- feedback-layer capability for verifying output grounding.

Checks whether the assistant's claims in the final turn response are grounded
in tool execution results.  Extracts "claims" (numbers, URLs, quoted strings)
from the last assistant message and searches for each claim in the available
tool results.  A grounding score (0.0 - 1.0) is computed as the ratio of
grounded claims to total claims.

When the score falls below a configurable threshold the capability:
  - Appends a grounding-warning record to ``context.working_memory``
  - Returns the ungrounded claims in ``context_modifications`` so downstream
    capabilities can act on them

Claim extraction patterns (heuristic MVP):
  - Numbers:  ``\\d+(?:\\.\\d+)?``
  - URLs:     ``https?://\\S+``
  - Quoted:   ``"[^"]+"``

Args:
    grounding_threshold: Score below which a warning is issued. Default 0.5.
    strict_mode: When True, *any* ungrounded claim triggers a warning
        regardless of the overall score. Default False.
"""

from __future__ import annotations

import logging
import re
import time

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Claim-extraction patterns
# ---------------------------------------------------------------------------

_NUMBER_RE = re.compile(r"\d+(?:\.\d+)?")
_URL_RE = re.compile(r"https?://\S+")
_QUOTED_RE = re.compile(r'"[^"]+"')

# Context key for inter-capability communication
_KEY_GROUNDING = "grounding_result"


class OutputGroundingCheck(AgenticCapability):
    """Feedback-layer capability that verifies assistant claims are grounded.

    Subscribes to TURN_END.  Runs at priority 82 (after SelfCritique at 80)
    so it can inspect the full turn output.

    Public helpers:
        extract_claims(text) -> list[str]
        check_grounding(claims, tool_results) -> tuple[list[str], list[str]]
    """

    name = "output_grounding_check"
    layer = CapabilityLayer.FEEDBACK
    subscribed_hooks: list[HookPoint] = [HookPoint.TURN_END]
    priority = 82  # after SelfCritique (80)
    critical = False

    def __init__(
        self,
        grounding_threshold: float = 0.5,
        strict_mode: bool = False,
    ) -> None:
        self.grounding_threshold = grounding_threshold
        self.strict_mode = strict_mode

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """OutputGroundingCheck is always active on TURN_END."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Check grounding of the last assistant message against tool results."""
        assistant_text = self._extract_last_assistant_text(event)
        if not assistant_text:
            return self._pass_result(grounding_score=1.0)

        claims = self.extract_claims(assistant_text)
        if not claims:
            return self._pass_result(grounding_score=1.0)

        tool_results = self._collect_tool_results(event, context)
        grounded, ungrounded = self.check_grounding(claims, tool_results)

        total = len(claims)
        grounded_count = len(grounded)
        ungrounded_count = len(ungrounded)
        grounding_score = grounded_count / total if total else 1.0

        grounding_result: dict = {
            "grounding_score": round(grounding_score, 4),
            "total_claims": total,
            "grounded_claims": grounded_count,
            "ungrounded_claims": ungrounded,
        }

        needs_warning = grounding_score < self.grounding_threshold or (self.strict_mode and ungrounded_count > 0)

        if needs_warning:
            logger.info(
                "Low grounding score %.2f (threshold=%.2f, claims=%d, ungrounded=%d)",
                grounding_score,
                self.grounding_threshold,
                total,
                ungrounded_count,
            )

            # Append warning to working memory
            warning_record = self._make_warning_record(
                grounding_result=grounding_result,
                assistant_text=assistant_text,
            )
            context.working_memory.append(warning_record)

            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
                context_modifications={_KEY_GROUNDING: grounding_result},
                metrics={
                    "grounding_score": grounding_score,
                    "total_claims": total,
                    "grounded_claims": grounded_count,
                    "warned": True,
                },
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={_KEY_GROUNDING: grounding_result},
            metrics={
                "grounding_score": grounding_score,
                "total_claims": total,
                "grounded_claims": grounded_count,
                "warned": False,
            },
        )

    # ------------------------------------------------------------------
    # Claim extraction (public for testability)
    # ------------------------------------------------------------------

    @staticmethod
    def extract_claims(text: str) -> list[str]:
        """Extract verifiable claims from assistant text.

        Extracts numbers, URLs, and quoted strings.  De-duplicates while
        preserving first-occurrence order.

        Args:
            text: The assistant message text.

        Returns:
            A list of unique claim strings.
        """
        if not text:
            return []

        claims: list[str] = []
        seen: set[str] = set()

        for pattern in (_NUMBER_RE, _URL_RE, _QUOTED_RE):
            for match in pattern.finditer(text):
                claim = match.group(0)
                if claim not in seen:
                    seen.add(claim)
                    claims.append(claim)

        return claims

    # ------------------------------------------------------------------
    # Grounding check (public for testability)
    # ------------------------------------------------------------------

    @staticmethod
    def check_grounding(
        claims: list[str],
        tool_results: list[str],
    ) -> tuple[list[str], list[str]]:
        """Partition claims into grounded and ungrounded lists.

        A claim is considered grounded if it appears (case-insensitive
        substring match) in any tool result text.

        Args:
            claims: List of extracted claim strings.
            tool_results: List of tool result text strings.

        Returns:
            A tuple of (grounded_claims, ungrounded_claims).
        """
        if not tool_results:
            return [], list(claims)

        combined_results = " ".join(tool_results).lower()

        grounded: list[str] = []
        ungrounded: list[str] = []

        for claim in claims:
            if claim.lower() in combined_results:
                grounded.append(claim)
            else:
                ungrounded.append(claim)

        return grounded, ungrounded

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_last_assistant_text(event: HookEvent) -> str:
        """Extract text from the last assistant message in the event.

        The event.messages list may contain multiple messages.  This method
        finds the last one with ``role == "assistant"`` and returns its text
        content.

        Args:
            event: The TURN_END hook event.

        Returns:
            Extracted text, or empty string.
        """
        messages = event.messages or []

        # Walk backwards to find the last assistant message
        for msg in reversed(messages):
            if msg.get("role") != "assistant":
                continue
            content = msg.get("content", "")
            return _extract_text(content)

        return ""

    @staticmethod
    def _collect_tool_results(
        event: HookEvent,
        context: AgentContext,
    ) -> list[str]:
        """Collect all available tool result texts for grounding checks.

        Sources:
          1. Messages with ``role == "tool"`` in the event
          2. Records in ``context.working_memory`` that have ``type ==
             "tool_result"``
          3. The event-level ``tool_result`` field (single result)

        Args:
            event: The TURN_END hook event.
            context: Session-scoped agent context.

        Returns:
            A list of tool result text strings.
        """
        results: list[str] = []

        # From messages
        for msg in event.messages or []:
            if msg.get("role") == "tool":
                text = _extract_text(msg.get("content", ""))
                if text.strip():
                    results.append(text)

        # From working memory
        for record in context.working_memory:
            if isinstance(record, dict) and record.get("type") == "tool_result":
                text = str(record.get("content", ""))
                if text.strip():
                    results.append(text)

        # From event-level field
        if event.tool_result is not None:
            text = str(event.tool_result)
            if text.strip():
                results.append(text)

        return results

    @staticmethod
    def _make_warning_record(
        grounding_result: dict,
        assistant_text: str,
    ) -> dict:
        """Create a structured grounding-warning record for working memory.

        Args:
            grounding_result: The grounding analysis result dict.
            assistant_text: The assistant message that was checked.

        Returns:
            A dict suitable for appending to ``context.working_memory``.
        """
        return {
            "type": "grounding_warning",
            "grounding_score": grounding_result["grounding_score"],
            "total_claims": grounding_result["total_claims"],
            "grounded_claims": grounding_result["grounded_claims"],
            "ungrounded_claims": grounding_result["ungrounded_claims"],
            "source_text_preview": assistant_text[:200],
            "timestamp": time.time(),
        }

    def _pass_result(self, grounding_score: float) -> CapabilityResult:
        """Build a CONTINUE result for the pass-through case."""
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            context_modifications={
                _KEY_GROUNDING: {
                    "grounding_score": grounding_score,
                    "total_claims": 0,
                    "grounded_claims": 0,
                    "ungrounded_claims": [],
                },
            },
            metrics={
                "grounding_score": grounding_score,
                "total_claims": 0,
                "grounded_claims": 0,
                "warned": False,
            },
        )


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------


def _extract_text(content: object) -> str:
    """Extract plain text from message content.

    Content may be a plain string or a list of content blocks
    (``{"type": "text", "text": "..."}``).

    Args:
        content: The raw message content value.

    Returns:
        Extracted text, or empty string.
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif isinstance(block, str):
                parts.append(block)
        return " ".join(parts)
    return str(content)
