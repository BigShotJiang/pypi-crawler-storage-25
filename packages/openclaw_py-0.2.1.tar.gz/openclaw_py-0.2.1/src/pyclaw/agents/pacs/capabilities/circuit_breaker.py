"""CircuitBreaker — action-layer capability that prevents repeated tool failures.

Protects the system from hammering a failing tool by opening the circuit after
a configurable number of consecutive failures.  Once open, the tool call is
skipped (SKIP action) until a cooldown period elapses, at which point the
circuit transitions to half-open and allows one retry.

Per-tool tracking:
- _failure_counts: dict[str, int] — consecutive failures per tool
- _last_failure_time: dict[str, float] — epoch timestamp of most recent failure

Args:
    failure_threshold: Consecutive failures before the circuit opens. Default 3.
    reset_after_success: Whether a successful execution resets the failure
        counter. Default True.
    cooldown_seconds: Seconds to wait before allowing a retry after the
        circuit opens. Default 60.0.
"""

from __future__ import annotations

import logging
import time

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.types import (
    AgentContext,
    CapabilityAction,
    CapabilityLayer,
    CapabilityResult,
    HookEvent,
    HookPoint,
)

logger = logging.getLogger(__name__)


class CircuitBreaker(AgenticCapability):
    """Action-layer capability that opens a circuit on repeated tool failures.

    When a tool fails *failure_threshold* times in a row, subsequent calls to
    that tool are skipped until the *cooldown_seconds* window expires.  This
    prevents the agent from wasting turns on a broken dependency.

    Args:
        failure_threshold: Consecutive failures before the circuit opens.
        reset_after_success: Reset the failure counter on success.
        cooldown_seconds: Seconds before a half-open retry is allowed.
    """

    name = "circuit_breaker"
    layer = CapabilityLayer.ACTION
    subscribed_hooks: list[HookPoint] = [
        HookPoint.TOOL_PRE_EXECUTE,
        HookPoint.TOOL_ERROR,
        HookPoint.TOOL_POST_EXECUTE,
    ]
    priority = 5

    def __init__(
        self,
        failure_threshold: int = 3,
        reset_after_success: bool = True,
        cooldown_seconds: float = 60.0,
    ) -> None:
        self.failure_threshold = failure_threshold
        self.reset_after_success = reset_after_success
        self.cooldown_seconds = cooldown_seconds

        # Per-tool failure tracking
        self._failure_counts: dict[str, int] = {}
        self._last_failure_time: dict[str, float] = {}

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def get_failure_count(self, tool_name: str) -> int:
        """Return the current consecutive failure count for *tool_name*."""
        return self._failure_counts.get(tool_name, 0)

    # ------------------------------------------------------------------
    # Activation gate
    # ------------------------------------------------------------------

    async def should_activate(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> bool:
        """CircuitBreaker is always active on its subscribed hooks."""
        return True

    # ------------------------------------------------------------------
    # Core logic
    # ------------------------------------------------------------------

    async def on_event(
        self,
        event: HookEvent,
        context: AgentContext,
    ) -> CapabilityResult:
        """Dispatch to the appropriate handler based on hook point."""
        if event.hook == HookPoint.TOOL_PRE_EXECUTE:
            return self._handle_pre_execute(event)
        if event.hook == HookPoint.TOOL_ERROR:
            return self._handle_error(event)
        if event.hook == HookPoint.TOOL_POST_EXECUTE:
            return self._handle_post_execute(event)

        # Fallback — should never happen given should_activate is True
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    # ------------------------------------------------------------------
    # Hook handlers
    # ------------------------------------------------------------------

    def _handle_pre_execute(self, event: HookEvent) -> CapabilityResult:
        """Check circuit state before a tool runs.

        If the circuit is open and cooldown has not elapsed, return SKIP.
        If cooldown has elapsed (half-open), allow the call through.
        """
        tool_name = self._extract_tool_name(event)
        if not tool_name:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        failure_count = self._failure_counts.get(tool_name, 0)

        if failure_count < self.failure_threshold:
            # Circuit is closed — allow the call.
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        # Circuit is open — check cooldown.
        last_failure = self._last_failure_time.get(tool_name, 0.0)
        elapsed = time.monotonic() - last_failure

        if elapsed < self.cooldown_seconds:
            # Still in cooldown — skip the call.
            logger.info(
                "Circuit open for tool %s (failures=%d, elapsed=%.1fs < cooldown=%.1fs)",
                tool_name,
                failure_count,
                elapsed,
                self.cooldown_seconds,
            )
            return CapabilityResult(
                action=CapabilityAction.SKIP,
                output=f"circuit_breaker_open:{tool_name}",
                capability_name=self.name,
                metrics={
                    "tool": tool_name,
                    "failure_count": failure_count,
                    "cooldown_remaining": self.cooldown_seconds - elapsed,
                },
            )

        # Cooldown elapsed — half-open state, allow one retry.
        logger.info(
            "Circuit half-open for tool %s (cooldown elapsed, allowing retry)",
            tool_name,
        )
        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
        )

    def _handle_error(self, event: HookEvent) -> CapabilityResult:
        """Record a tool failure when TOOL_ERROR fires."""
        tool_name = self._extract_tool_name(event)
        if not tool_name:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        self._failure_counts[tool_name] = self._failure_counts.get(tool_name, 0) + 1
        self._last_failure_time[tool_name] = time.monotonic()

        failure_count = self._failure_counts[tool_name]
        logger.info(
            "Tool %s failed (consecutive failures=%d, threshold=%d)",
            tool_name,
            failure_count,
            self.failure_threshold,
        )

        if failure_count >= self.failure_threshold:
            logger.warning(
                "Circuit opened for tool %s after %d consecutive failures",
                tool_name,
                failure_count,
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            metrics={
                "tool": tool_name,
                "failure_count": failure_count,
                "circuit_open": failure_count >= self.failure_threshold,
            },
        )

    def _handle_post_execute(self, event: HookEvent) -> CapabilityResult:
        """Reset failure counter on successful execution if configured."""
        tool_name = self._extract_tool_name(event)
        if not tool_name or not self.reset_after_success:
            return CapabilityResult(
                action=CapabilityAction.CONTINUE,
                capability_name=self.name,
            )

        previous_count = self._failure_counts.pop(tool_name, 0)
        self._last_failure_time.pop(tool_name, None)

        if previous_count > 0:
            logger.info(
                "Tool %s succeeded, reset failure count from %d to 0",
                tool_name,
                previous_count,
            )

        return CapabilityResult(
            action=CapabilityAction.CONTINUE,
            capability_name=self.name,
            metrics={
                "tool": tool_name,
                "previous_failure_count": previous_count,
                "reset": True,
            },
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_tool_name(event: HookEvent) -> str:
        """Extract the tool name from the event's tool_call payload.

        tool_call is expected to be ``{"id": "...", "name": "...",
        "arguments": {...}}``.
        """
        tool_call = event.tool_call
        if isinstance(tool_call, dict):
            return str(tool_call.get("name", ""))
        return ""
