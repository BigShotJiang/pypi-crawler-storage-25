"""Predefined recipe registry for PACS agent types.

A Recipe is a named set of capability configurations representing an agent
type. Recipes are built on top of CapabilityRegistry and provide a higher-level
abstraction for assembling common agent configurations.

Default recipes:
- react_agent:    ReAct agent with semantic filtering and circuit breaker
- planner_agent:  Planning agent with phase separation and safety validation
- research_agent: Research agent with reflection and output parsing
- safe_agent:     Safety-first agent with validation and retry
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from pyclaw.agents.pacs.capability import AgenticCapability
from pyclaw.agents.pacs.registry import CapabilityRegistry

logger = logging.getLogger(__name__)


@dataclass
class CapabilityConfig:
    """Configuration for a single capability in a recipe.

    Args:
        name: Registered capability name in CapabilityRegistry.
        params: Override parameters forwarded to the constructor.
    """

    name: str
    params: dict[str, Any] = field(default_factory=dict)

    def create(self, registry: CapabilityRegistry | None = None) -> AgenticCapability:
        """Instantiate this capability using the registry.

        Args:
            registry: Optional registry instance; defaults to the singleton.

        Returns:
            Instantiated capability with params applied.
        """
        reg = registry or CapabilityRegistry.get_instance()
        return reg.create(self.name, **self.params)


@dataclass
class Recipe:
    """A named set of capability configurations representing an Agent type.

    Args:
        name: Unique recipe identifier.
        description: Human-readable summary.
        capabilities: Ordered list of capability configs.
    """

    name: str
    description: str
    capabilities: list[CapabilityConfig] = field(default_factory=list)

    def build(self, registry: CapabilityRegistry | None = None) -> list[AgenticCapability]:
        """Instantiate all capabilities in this recipe.

        Args:
            registry: Optional registry instance; defaults to the singleton.

        Returns:
            List of instantiated capabilities in recipe order.
        """
        return [cfg.create(registry) for cfg in self.capabilities]


# --- Global recipe store ---

RECIPES: dict[str, Recipe] = {}


def register_recipe(recipe: Recipe) -> None:
    """Register a recipe by name.

    Args:
        recipe: The recipe to register.
    """
    RECIPES[recipe.name] = recipe
    logger.debug("Registered recipe: %s", recipe.name)


def get_recipe(name: str) -> Recipe:
    """Get a recipe by name.

    Args:
        name: Recipe identifier.

    Returns:
        The matching Recipe.

    Raises:
        KeyError: If the recipe name is not registered.
    """
    if name not in RECIPES:
        raise KeyError(f"Unknown recipe: {name}. Available: {list(RECIPES.keys())}")
    return RECIPES[name]


def list_recipes() -> list[str]:
    """List all available recipe names in sorted order.

    Returns:
        Sorted list of recipe names.
    """
    return sorted(RECIPES.keys())


def build_recipe(name: str, registry: CapabilityRegistry | None = None) -> list[AgenticCapability]:
    """Build all capabilities for a named recipe.

    Args:
        name: Recipe identifier.
        registry: Optional registry instance; defaults to the singleton.

    Returns:
        List of instantiated capabilities.

    Raises:
        KeyError: If the recipe name is not registered.
    """
    return get_recipe(name).build(registry)


def _init_default_recipes() -> None:
    """Register the built-in default recipes."""
    register_recipe(
        Recipe(
            name="react_agent",
            description="ReAct agent with semantic filtering and circuit breaker",
            capabilities=[
                CapabilityConfig("semantic_filter"),
                CapabilityConfig("react_controller"),
                CapabilityConfig("circuit_breaker", {"failure_threshold": 3}),
            ],
        )
    )

    register_recipe(
        Recipe(
            name="planner_agent",
            description="Planning agent with phase separation and safety validation",
            capabilities=[
                CapabilityConfig("context_window_manager"),
                CapabilityConfig("plan_execute"),
                CapabilityConfig("phase_separation"),
                CapabilityConfig("model_router"),
                CapabilityConfig("action_validator"),
            ],
        )
    )

    register_recipe(
        Recipe(
            name="research_agent",
            description="Research agent with reflection and output parsing",
            capabilities=[
                CapabilityConfig("semantic_filter"),
                CapabilityConfig("reflection_loop", {"max_reflections": 3}),
                CapabilityConfig("tool_output_parser"),
                CapabilityConfig("tool_retry_backoff"),
            ],
        )
    )

    register_recipe(
        Recipe(
            name="safe_agent",
            description="Safety-first agent with validation and retry",
            capabilities=[
                CapabilityConfig("semantic_filter"),
                CapabilityConfig("action_validator"),
                CapabilityConfig("circuit_breaker", {"failure_threshold": 2}),
                CapabilityConfig("tool_retry_backoff"),
            ],
        )
    )

    register_recipe(
        Recipe(
            name="full_stack_agent",
            description="Full-stack agent with all layers: perception, reasoning, action, feedback, infrastructure",
            capabilities=[
                CapabilityConfig("meta_cognition_monitor"),
                CapabilityConfig("semantic_filter"),
                CapabilityConfig("context_window_manager"),
                CapabilityConfig("user_intent_classifier"),
                CapabilityConfig("react_controller"),
                CapabilityConfig("plan_execute"),
                CapabilityConfig("phase_separation"),
                CapabilityConfig("model_router"),
                CapabilityConfig("action_validator"),
                CapabilityConfig("dual_llm"),
                CapabilityConfig("circuit_breaker"),
                CapabilityConfig("tool_retry_backoff"),
                CapabilityConfig("tool_output_parser"),
                CapabilityConfig("self_critique"),
                CapabilityConfig("reflection_loop"),
                CapabilityConfig("memory_synthesis"),
                CapabilityConfig("output_grounding_check"),
                CapabilityConfig("trace_quality_monitor"),
                CapabilityConfig("parallel_tool_executor"),
                CapabilityConfig("collaboration_bus"),
                CapabilityConfig("auto_improvement_loop"),
            ],
        )
    )


# Auto-initialize on import
_init_default_recipes()
