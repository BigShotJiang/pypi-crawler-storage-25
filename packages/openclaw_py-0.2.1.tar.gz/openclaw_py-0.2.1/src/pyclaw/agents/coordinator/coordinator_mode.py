"""Coordinator mode — orchestrates multiple agents for complex tasks."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class SubtaskStatus(str, Enum):
    """Status of a subtask."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"


@dataclass
class Subtask:
    """A decomposed subtask."""

    id: str
    description: str
    agent_type: str = "general_purpose"
    priority: int = 5
    dependencies: list[str] = field(default_factory=list)
    status: SubtaskStatus = SubtaskStatus.PENDING
    result: str = ""
    error: str | None = None
    retry_count: int = 0
    max_retries: int = 2


@dataclass
class CoordinatorConfig:
    """Configuration for coordinator mode."""

    max_parallel: int = 4
    max_retries: int = 2
    retry_delay_seconds: float = 1.0
    timeout_seconds: int = 300
    polling_interval: float = 0.5


class CoordinatorMode:
    """Orchestrates multiple agents for complex task execution.

    Usage:
        coordinator = CoordinatorMode(subagent_manager)
        result = await coordinator.execute("Build a REST API for user management")
    """

    def __init__(
        self,
        subagent_manager: Any,
        config: CoordinatorConfig | None = None,
    ) -> None:
        self._manager = subagent_manager
        self._config = config or CoordinatorConfig()
        self._subtasks: dict[str, Subtask] = {}
        self._results: dict[str, Any] = {}
        self._active_tasks: dict[str, asyncio.Task] = {}

    async def execute(
        self,
        goal: str,
        subtasks: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Execute a complex goal by coordinating multiple agents.

        Args:
            goal: The high-level goal to achieve.
            subtasks: Optional pre-defined subtasks. If None, will decompose.

        Returns:
            Dict with execution results.
        """
        logger.info("Coordinator starting: %s", goal)

        # Decompose or use provided subtasks
        if subtasks:
            self._subtasks = {
                f"subtask-{i}": Subtask(
                    id=f"subtask-{i}",
                    description=st.get("description", str(st)),
                    agent_type=st.get("agent_type", "general_purpose"),
                    priority=st.get("priority", 5),
                    dependencies=st.get("dependencies", []),
                )
                for i, st in enumerate(subtasks)
            }
        else:
            self._subtasks = self._decompose_goal(goal)

        # Execute with dependency resolution
        await self._execute_subtasks()

        # Aggregate results
        return self._aggregate_results()

    def _decompose_goal(self, goal: str) -> dict[str, Subtask]:
        """Decompose a goal into subtasks.

        This is a simple heuristic decomposition.
        For better decomposition, use an LLM.
        """
        # Simple split by common delimiters
        import re

        sentences = re.split(r"[.;]", goal)
        sentences = [s.strip() for s in sentences if s.strip()]

        if len(sentences) <= 1:
            # Single goal, create exploration and execution phases
            return {
                "explore": Subtask(
                    id="explore",
                    description=f"Explore and understand: {goal}",
                    agent_type="explore",
                    priority=1,
                ),
                "plan": Subtask(
                    id="plan",
                    description=f"Create implementation plan for: {goal}",
                    agent_type="plan",
                    priority=2,
                    dependencies=["explore"],
                ),
                "execute": Subtask(
                    id="execute",
                    description=f"Execute the planned implementation for: {goal}",
                    agent_type="general_purpose",
                    priority=3,
                    dependencies=["plan"],
                ),
                "verify": Subtask(
                    id="verify",
                    description=f"Verify the implementation for: {goal}",
                    agent_type="verification",
                    priority=4,
                    dependencies=["execute"],
                ),
            }

        # Multiple sentences, create subtasks for each
        return {
            f"subtask-{i}": Subtask(
                id=f"subtask-{i}",
                description=s,
                agent_type="general_purpose",
                priority=i + 1,
            )
            for i, s in enumerate(sentences)
        }

    async def _execute_subtasks(self) -> None:
        """Execute all subtasks respecting dependencies."""
        while True:
            # Find ready subtasks (pending with no unmet dependencies)
            ready = [
                st
                for st in self._subtasks.values()
                if st.status == SubtaskStatus.PENDING
                and all(self._subtasks[dep].status == SubtaskStatus.COMPLETED for dep in st.dependencies)
            ]

            if not ready:
                # Check if we're done or stuck
                running = [st for st in self._subtasks.values() if st.status == SubtaskStatus.RUNNING]
                if not running:
                    break
                # Wait for running tasks
                await asyncio.sleep(self._config.polling_interval)
                continue

            # Sort by priority
            ready.sort(key=lambda st: st.priority)

            # Launch up to max_parallel
            to_launch = ready[: self._config.max_parallel - len(self._active_tasks)]

            for subtask in to_launch:
                task = asyncio.create_task(self._run_subtask(subtask))
                self._active_tasks[subtask.id] = task

            # Wait a bit
            await asyncio.sleep(self._config.polling_interval)

            # Clean up completed tasks
            done_ids = [sid for sid, task in self._active_tasks.items() if task.done()]
            for sid in done_ids:
                del self._active_tasks[sid]

    async def _run_subtask(self, subtask: Subtask) -> None:
        """Run a single subtask."""
        subtask.status = SubtaskStatus.RUNNING

        try:
            # Spawn agent
            result = await self._manager.spawn(
                self._manager._create_config(
                    prompt=subtask.description,
                    agent_type=subtask.agent_type,
                )
            )

            if result.state.value == "completed":
                subtask.status = SubtaskStatus.COMPLETED
                subtask.result = result.output or ""
                self._results[subtask.id] = result.output
                logger.info("Subtask %s completed", subtask.id)
            else:
                raise Exception(result.error or "Subtask failed")

        except Exception as e:
            logger.warning("Subtask %s failed: %s", subtask.id, e)

            if subtask.retry_count < subtask.max_retries:
                subtask.retry_count += 1
                subtask.status = SubtaskStatus.RETRYING
                await asyncio.sleep(self._config.retry_delay_seconds)
                subtask.status = SubtaskStatus.PENDING
            else:
                subtask.status = SubtaskStatus.FAILED
                subtask.error = str(e)

    def _aggregate_results(self) -> dict[str, Any]:
        """Aggregate all results into a final response."""
        completed = [st for st in self._subtasks.values() if st.status == SubtaskStatus.COMPLETED]
        failed = [st for st in self._subtasks.values() if st.status == SubtaskStatus.FAILED]

        return {
            "success": len(failed) == 0,
            "total_subtasks": len(self._subtasks),
            "completed": len(completed),
            "failed": len(failed),
            "results": self._results,
            "failed_subtasks": [{"id": st.id, "description": st.description, "error": st.error} for st in failed],
        }
