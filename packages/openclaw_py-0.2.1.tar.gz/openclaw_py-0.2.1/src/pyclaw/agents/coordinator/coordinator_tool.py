"""Coordinator tool — agent tool for invoking coordinator mode."""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.tools.base import BaseTool
from pyclaw.agents.types import ToolResult

logger = logging.getLogger(__name__)


class CoordinatorTool(BaseTool):
    """Tool for invoking coordinator mode from an agent.

    Allows agents to delegate complex tasks to a coordinated team of subagents.
    """

    def __init__(
        self,
        subagent_manager: Any | None = None,
    ) -> None:
        self._manager = subagent_manager

    @property
    def name(self) -> str:
        return "coordinate"

    @property
    def description(self) -> str:
        return (
            "Coordinate multiple agents to accomplish a complex goal. "
            "Use this for multi-step tasks that benefit from parallel execution "
            "or specialized agent types."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "goal": {
                    "type": "string",
                    "description": "The high-level goal to accomplish",
                },
                "subtasks": {
                    "type": "array",
                    "description": "Optional list of subtasks with agent_type assignments",
                    "items": {
                        "type": "object",
                        "properties": {
                            "description": {"type": "string"},
                            "agent_type": {
                                "type": "string",
                                "enum": ["explore", "plan", "verification", "general_purpose"],
                            },
                            "priority": {"type": "integer"},
                            "dependencies": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                },
                "max_parallel": {
                    "type": "integer",
                    "description": "Maximum parallel agents (default: 4)",
                },
            },
            "required": ["goal"],
        }

    async def execute(
        self,
        tool_call_id: str,
        arguments: dict[str, Any],
    ) -> ToolResult:
        """Execute coordination.

        Args:
            tool_call_id: Tool call identifier.
            arguments: Tool arguments.

        Returns:
            ToolResult with coordination results.
        """

        goal = arguments.get("goal", "")
        subtasks = arguments.get("subtasks")
        max_parallel = arguments.get("max_parallel", 4)

        if not goal:
            return ToolResult.text("Error: goal is required", is_error=True)

        if not self._manager:
            return ToolResult.text(
                "Coordinator not available: no subagent manager configured",
                is_error=True,
            )

        try:
            from pyclaw.agents.coordinator.coordinator_mode import CoordinatorConfig, CoordinatorMode

            config = CoordinatorConfig(max_parallel=max_parallel)
            coordinator = CoordinatorMode(self._manager, config)

            result = await coordinator.execute(goal, subtasks)

            # Format result
            output_lines = [
                "## Coordination Result",
                "",
                f"**Goal**: {goal}",
                f"**Status**: {'Success' if result['success'] else 'Partial/Failed'}",
                f"**Completed**: {result['completed']}/{result['total_subtasks']}",
                "",
            ]

            if result["results"]:
                output_lines.append("### Results")
                for st_id, st_result in result["results"].items():
                    preview = st_result[:200] + "..." if len(st_result) > 200 else st_result
                    output_lines.append(f"- **{st_id}**: {preview}")

            if result["failed_subtasks"]:
                output_lines.append("")
                output_lines.append("### Failed Subtasks")
                for st in result["failed_subtasks"]:
                    output_lines.append(f"- **{st['id']}**: {st['error']}")

            return ToolResult.text("\n".join(output_lines))

        except Exception as e:
            logger.error("Coordination failed: %s", e)
            return ToolResult.text(f"Coordination failed: {e}", is_error=True)
