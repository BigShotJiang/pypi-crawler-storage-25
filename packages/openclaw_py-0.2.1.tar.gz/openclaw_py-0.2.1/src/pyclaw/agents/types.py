"""Agent runtime types."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@dataclass
class AgentEvent:
    """An event emitted during an agent run."""

    type: str
    # "agent_start" | "agent_end"
    # "message_start" | "message_update" | "message_end"
    # "tool_start" | "tool_update" | "tool_end"
    # "error"
    delta: str | None = None
    name: str | None = None
    result: dict[str, Any] | None = None
    error: str | None = None
    tool_call_id: str | None = None
    usage: dict[str, int] | None = None


@dataclass
class ToolCall:
    """A tool call extracted from an LLM response."""

    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ToolResult:
    """Result of executing a tool."""

    content: list[dict[str, Any]]
    is_error: bool = False

    @classmethod
    def text(cls, text: str, is_error: bool = False) -> ToolResult:
        return cls(content=[{"type": "text", "text": text}], is_error=is_error)

    @classmethod
    def json(cls, data: dict[str, Any], is_error: bool = False) -> ToolResult:
        return cls(content=[{"type": "json", "json": data}], is_error=is_error)


@dataclass
class ModelConfig:
    """Configuration for a specific LLM model."""

    provider: str  # "openai" | "anthropic" | "google" | "ollama" | ...
    model_id: str
    api_key: str | None = None
    base_url: str | None = None
    max_tokens: int | None = None
    temperature: float | None = None


@dataclass
class MultiModelConfig:
    """Per-agent model configuration with support for task-specific models.

    Enables agents to use different models for different tasks:
    - model: Default model for general tasks
    - fast_model: Fast/cheap model for simple tasks
    - thinking_model: Model optimized for chain-of-thought
    - reasoning_model: Model optimized for complex reasoning
    """

    model: str
    provider: str = "openai"
    fast_model: str | None = None
    thinking_model: str | None = None
    reasoning_model: str | None = None
    api_key: str | None = None
    base_url: str | None = None

    @classmethod
    def from_agent_config(
        cls,
        defaults: Any,
        overrides: Any | None = None,
    ) -> MultiModelConfig:
        """Create MultiModelConfig from AgentDefaultsConfig and optional per-agent overrides.

        Args:
            defaults: AgentDefaultsConfig with default model settings
            overrides: Optional AgentConfig with per-agent overrides

        Returns:
            MultiModelConfig instance
        """
        # Get model string, preferring overrides
        model_raw = getattr(overrides, "model", None) or getattr(defaults, "model", "gpt-4o")
        if model_raw is None:
            model_raw = "gpt-4o"

        # Parse provider/model format (e.g., "openai/gpt-4o")
        if "/" in model_raw:
            provider, model = model_raw.split("/", 1)
        else:
            provider = getattr(defaults, "provider", "openai") or "openai"
            model = model_raw

        # Get task-specific models, handling legacy field names
        fast_model = getattr(overrides, "fast_model", None) or getattr(defaults, "fast_model", None)
        thinking_model = (
            getattr(overrides, "thinking_model", None)
            or getattr(overrides, "thinking", None)  # Legacy field
            or getattr(defaults, "thinking_model", None)
            or getattr(defaults, "thinking", None)  # Legacy field
        )
        reasoning_model = (
            getattr(overrides, "reasoning_model", None)
            or getattr(overrides, "reasoning", None)  # Legacy field
            or getattr(defaults, "reasoning_model", None)
            or getattr(defaults, "reasoning", None)  # Legacy field
        )

        return cls(
            model=model,
            provider=provider,
            fast_model=fast_model,
            thinking_model=thinking_model,
            reasoning_model=reasoning_model,
        )

    def get_model_for_task(self, task_type: str) -> str:
        """Get the appropriate model for a task type.

        Args:
            task_type: Task type ("default", "fast", "thinking", "reasoning")

        Returns:
            Model ID to use for this task
        """
        if task_type == "fast" and self.fast_model:
            return self.fast_model
        if task_type == "thinking" and self.thinking_model:
            return self.thinking_model
        if task_type == "reasoning" and self.reasoning_model:
            return self.reasoning_model
        return self.model

    def to_model_config(self, task_type: str = "default") -> ModelConfig:
        """Convert to ModelConfig for a specific task.

        Args:
            task_type: Task type to get model for

        Returns:
            ModelConfig instance
        """
        model_id = self.get_model_for_task(task_type)
        return ModelConfig(
            provider=self.provider,
            model_id=model_id,
            api_key=self.api_key,
            base_url=self.base_url,
        )


@runtime_checkable
class AgentTool(Protocol):
    """Interface for agent tools."""

    @property
    def name(self) -> str: ...

    @property
    def description(self) -> str: ...

    @property
    def parameters(self) -> dict[str, Any]: ...

    async def execute(self, tool_call_id: str, arguments: dict[str, Any]) -> ToolResult: ...
