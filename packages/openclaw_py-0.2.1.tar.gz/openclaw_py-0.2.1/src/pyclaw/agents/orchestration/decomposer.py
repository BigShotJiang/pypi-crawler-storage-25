"""Task decomposition interface for breaking down complex tasks into subtasks."""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Protocol

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class TaskPriority(int, Enum):
    """Priority levels for tasks."""

    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4
    BACKGROUND = 5


class Subtask(BaseModel):
    """A single executable subtask in a decomposition."""

    id: str = Field(...)
    description: str = Field(...)
    priority: TaskPriority = TaskPriority.MEDIUM
    estimated_duration_seconds: int = 60
    required_role: str | None = Field(None)
    dependencies: list[str] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)


class TaskDecomposer(ABC):
    """Abstract base class for task decomposition.

    Task decomposers break down high-level goals into executable subtasks
    with dependencies and role assignments.
    """

    @abstractmethod
    def decompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[Subtask]:
        """Decompose a goal into subtasks.

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of Subtask objects.
        """
        ...


class LLMClient(Protocol):
    """Protocol for LLM client used by LLMTaskDecomposer."""

    async def generate(
        self,
        prompt: str,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> str:
        """Generate a response from the LLM.

        Args:
            prompt: The user prompt.
            system_prompt: Optional system prompt.
            **kwargs: Additional parameters.

        Returns:
            Generated text.
        """
        ...


DECOMPOSITION_SYSTEM_PROMPT = """You are a task decomposition expert. Your job is to break down complex goals into smaller, executable subtasks.

When decomposing a goal:
1. Identify the main phases or steps needed
2. Determine which steps can run in parallel vs. must be sequential
3. Assign appropriate roles (researcher, analyst, planner, executor, verifier, generalist) to each subtask
4. Set realistic time estimates
5. Define dependencies between subtasks

Output format: JSON array of subtasks with the following schema:
[
  {
    "id": "unique-task-id",
    "description": "What this task should accomplish",
    "priority": 1-5 (1=Critical, 5=Background),
    "estimated_duration_seconds": 60,
    "required_role": "role-name",
    "dependencies": ["list", "of", "task-ids"],
    "context": {}
  }
]

Guidelines:
- Each subtask should be completable by a single agent
- Keep descriptions clear and actionable
- Minimize dependencies where possible
- Use "generalist" role when no specialization is needed
- Maximum 10 subtasks per decomposition
"""


class LLMTaskDecomposer(TaskDecomposer):
    """LLM-powered task decomposition.

    Uses an LLM to intelligently break down complex goals into
    structured subtasks with appropriate dependencies.

    Example:
        from pyclaw.agents.stream import StreamRunner

        llm_client = StreamRunner(model="gpt-4o-mini")
        decomposer = LLMTaskDecomposer(llm_client=llm_client)

        subtasks = await decomposer.decompose(
            "Build a REST API with authentication and database"
        )
    """

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        *,
        max_subtasks: int = 10,
        default_timeout: int = 300,
        use_cache: bool = True,
    ) -> None:
        """Initialize the LLM task decomposer.

        Args:
            llm_client: LLM client for generation. If None, must be set later.
            max_subtasks: Maximum number of subtasks to generate.
            default_timeout: Default timeout for subtasks without estimates.
            use_cache: Whether to cache decomposition results.
        """
        self._llm_client = llm_client
        self._max_subtasks = max_subtasks
        self._default_timeout = default_timeout
        self._use_cache = use_cache
        self._cache: dict[str, list[Subtask]] = {}

    def set_llm_client(self, client: LLMClient) -> None:
        """Set the LLM client.

        Args:
            client: LLM client instance.
        """
        self._llm_client = client

    async def adecompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[Subtask]:
        """Asynchronously decompose a goal into subtasks.

        This is the async version of decompose().

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of Subtask objects.
        """
        # Check cache
        cache_key = self._make_cache_key(goal, context)
        if self._use_cache and cache_key in self._cache:
            logger.debug("Using cached decomposition for: %s", goal[:50])
            return self._cache[cache_key]

        if not self._llm_client:
            logger.warning("No LLM client, falling back to rule-based decomposition")
            return decompose_task(goal, context)

        # Build prompt
        prompt = self._build_decomposition_prompt(goal, context)

        try:
            # Generate decomposition
            response = await self._llm_client.generate(
                prompt=prompt,
                system_prompt=DECOMPOSITION_SYSTEM_PROMPT,
                temperature=0.3,  # Lower temperature for more deterministic output
            )

            # Parse response
            subtasks = self._parse_llm_response(response, goal)

            # Cache result
            if self._use_cache:
                self._cache[cache_key] = subtasks

            logger.info("LLM decomposition produced %d subtasks for: %s", len(subtasks), goal[:50])
            return subtasks

        except Exception as e:
            logger.error("LLM decomposition failed: %s", e)
            # Fallback to rule-based
            return decompose_task(goal, context)

    def decompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[Subtask]:
        """Decompose a goal into subtasks (sync wrapper).

        Note: This is a synchronous wrapper that may block. For async usage,
        use adecompose() directly.

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of Subtask objects.
        """
        import asyncio

        try:
            asyncio.get_running_loop()
            # We're in an async context, create a task
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(
                    asyncio.run,
                    self.adecompose(goal, context),
                )
                return future.result()
        except RuntimeError:
            # No running loop, we can use asyncio.run
            return asyncio.run(self.adecompose(goal, context))

    def _build_decomposition_prompt(
        self,
        goal: str,
        context: dict[str, Any] | None,
    ) -> str:
        """Build the prompt for LLM decomposition.

        Args:
            goal: The goal to decompose.
            context: Optional context.

        Returns:
            Prompt string.
        """
        parts = [f"Goal: {goal}"]

        if context:
            # Add relevant context
            if "domain" in context:
                parts.append(f"Domain: {context['domain']}")
            if "constraints" in context:
                parts.append(f"Constraints: {context['constraints']}")
            if "available_roles" in context:
                parts.append(f"Available roles: {', '.join(context['available_roles'])}")
            if "deadline" in context:
                parts.append(f"Deadline: {context['deadline']}")

        parts.append(f"\nMaximum subtasks: {self._max_subtasks}")
        parts.append("\nDecompose this goal into subtasks:")

        return "\n".join(parts)

    def _parse_llm_response(
        self,
        response: str,
        goal: str,
    ) -> list[Subtask]:
        """Parse LLM response into Subtask objects.

        Args:
            response: Raw LLM response.
            goal: Original goal (for fallback).

        Returns:
            List of Subtask objects.
        """
        try:
            # Try to extract JSON from response
            json_str = self._extract_json(response)
            if not json_str:
                raise ValueError("No JSON found in response")

            data = json.loads(json_str)

            if not isinstance(data, list):
                raise ValueError("Response is not a JSON array")

            subtasks = []
            for i, item in enumerate(data[: self._max_subtasks]):
                try:
                    # Map priority (1-5) to TaskPriority enum
                    priority_val = item.get("priority", 3)
                    priority = TaskPriority(priority_val) if isinstance(priority_val, int) else TaskPriority.MEDIUM

                    subtask = Subtask(
                        id=item.get("id", f"task-{i + 1}"),
                        description=item.get("description", ""),
                        priority=priority,
                        estimated_duration_seconds=item.get("estimated_duration_seconds", self._default_timeout),
                        required_role=item.get("required_role", "generalist"),
                        dependencies=item.get("dependencies", []),
                        context=item.get("context", {}),
                    )
                    subtasks.append(subtask)
                except Exception as e:
                    logger.warning("Failed to parse subtask %d: %s", i, e)
                    continue

            if not subtasks:
                raise ValueError("No valid subtasks parsed")

            return subtasks

        except Exception as e:
            logger.warning("Failed to parse LLM response: %s", e)
            # Fallback to rule-based
            return decompose_task(goal)

    def _extract_json(self, text: str) -> str | None:
        """Extract JSON array from text.

        Args:
            text: Text that may contain JSON.

        Returns:
            JSON string or None.
        """
        # Try to find JSON array in text

        # Look for balanced array pattern - find opening [ and matching ]
        start = text.find("[")
        if start == -1:
            return None

        # Count brackets to find matching end
        depth = 0
        for i in range(start, len(text)):
            if text[i] == "[":
                depth += 1
            elif text[i] == "]":
                depth -= 1
                if depth == 0:
                    return text[start : i + 1]

        return None

    def _make_cache_key(self, goal: str, context: dict[str, Any] | None) -> str:
        """Create a cache key for decomposition.

        Args:
            goal: The goal.
            context: Optional context.

        Returns:
            Cache key string.
        """
        import hashlib

        key_parts = [goal]
        if context:
            # Sort context keys for consistent hashing
            for k in sorted(context.keys()):
                key_parts.append(f"{k}={context[k]}")

        key_str = "|".join(key_parts)
        return hashlib.md5(key_str.encode()).hexdigest()

    def clear_cache(self) -> None:
        """Clear the decomposition cache."""
        self._cache.clear()


def decompose_task(
    task_description: str,
    context: dict[str, Any] | None = None,
    manifest: Any = None,
) -> list[Subtask]:
    """Decompose a complex task into executable subtasks.

    This is a keyword-based decomposition implementation. Future versions
    may use LLM-based decomposition or pattern matching for more
    intelligent breakdown.

    Args:
        task_description: The main task to decompose.
        context: Additional context for decomposition (e.g., domain, constraints).
        manifest: Optional orchestration manifest for role-based decomposition.

    Returns:
        List of Subtask objects with dependencies and priorities.
    """
    subtasks: list[Subtask] = []

    # Extract action verbs and entities
    task_lower = task_description.lower()

    # Track which tasks are added for proper dependency linking
    has_search = "search" in task_lower or "find" in task_lower
    has_analyze = "analyze" in task_lower or "review" in task_lower
    has_report = "report" in task_lower or "document" in task_lower

    # Search-related tasks
    if has_search:
        subtasks.append(
            Subtask(
                id="search-info",
                description=f"Search for information about {task_description}",
                priority=TaskPriority.HIGH,
                required_role="researcher",
            )
        )

    # Analysis-related tasks
    if has_analyze:
        # Only add search dependency if search task exists
        dependencies = ["search-info"] if has_search else []
        subtasks.append(
            Subtask(
                id="analyze-data",
                description="Analyze found data",
                priority=TaskPriority.MEDIUM,
                required_role="analyst",
                dependencies=dependencies,
            )
        )

    # Documentation-related tasks
    if has_report:
        # Build dependencies based on existing tasks
        report_deps = []
        if has_analyze:
            report_deps.append("analyze-data")
        elif has_search:
            report_deps.append("search-info")
        subtasks.append(
            Subtask(
                id="create-report",
                description="Create a report with findings",
                priority=TaskPriority.MEDIUM,
                required_role="writer",
                dependencies=report_deps,
            )
        )

    # Default: single task if no patterns matched
    if not subtasks:
        subtasks.append(
            Subtask(
                id="execute-task",
                description=task_description,
                priority=TaskPriority.MEDIUM,
                required_role="generalist",
            )
        )

    return subtasks
