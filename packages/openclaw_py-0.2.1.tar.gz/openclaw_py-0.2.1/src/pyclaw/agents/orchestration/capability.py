"""Orchestration capability registration and engine access.

This module provides functions to register and retrieve orchestration engines
through the capability registry system.

Design notes:
- register_orchestration_capability() registers an engine with the global registry
- get_orchestration_engine() retrieves an engine by name or highest priority
- Default centralized engine is auto-registered on module import
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pyclaw.agents.capabilities import AgentCapability, CapabilityType, get_capability_registry
from pyclaw.agents.orchestration.engine import OrchestrationEngine
from pyclaw.agents.orchestration.engines.centralized import CentralizedEngine

# Track if default provider has been registered
_default_registered = False


def _default_centralized_engine() -> OrchestrationEngine:
    """Factory function for default CentralizedEngine."""
    return CentralizedEngine()


def register_orchestration_capability(
    name: str = "centralized",
    provider_factory: Callable[[], OrchestrationEngine] | None = None,
    priority: int = 0,
    tags: set[str] | None = None,
    metadata: dict[str, Any] | None = None,
    *,
    allow_replace: bool = True,
) -> None:
    """Register an orchestration engine capability.

    Args:
        name: Engine name (default: "centralized").
        provider_factory: Factory function that creates engine instance.
            If None, uses CentralizedEngine.
        priority: Priority for selection (higher wins, default: 0).
        tags: Query tags for filtering capabilities.
        metadata: Additional metadata for the capability.
        allow_replace: If True, replaces existing capability with same name
            (default: True). Set to False for strict registration.

    Raises:
        ValueError: If capability already exists and allow_replace is False.
    """
    if provider_factory is None:
        provider_factory = _default_centralized_engine

    capability = AgentCapability(
        capability_type=CapabilityType.ORCHESTRATION,
        name=name,
        description=f"Orchestration engine: {name}",
        provider=provider_factory,
        priority=priority,
        tags=tags or set(),
        metadata=metadata or {},
    )

    registry = get_capability_registry()

    if not allow_replace:
        existing = registry.get(CapabilityType.ORCHESTRATION, name)
        if existing is not None:
            raise ValueError(f"Orchestration capability '{name}' already registered")

    registry.register(capability)


def get_orchestration_engine(name: str | None = None) -> OrchestrationEngine | None:
    """Get an orchestration engine by name or highest priority.

    Args:
        name: Engine name. If None, returns the highest priority engine.

    Returns:
        OrchestrationEngine instance or None if not found.
    """
    registry = get_capability_registry()
    capability = registry.get(CapabilityType.ORCHESTRATION, name)
    if capability is None:
        return None

    provider = capability.provider()
    # Type check to ensure we return a OrchestrationEngine
    if not isinstance(provider, OrchestrationEngine):
        return None

    return provider


def unregister_orchestration_capability(name: str) -> bool:
    """Unregister an orchestration capability by name.

    Args:
        name: Engine name to unregister.

    Returns:
        True if the capability was removed, False if not found.
    """
    registry = get_capability_registry()
    return registry.unregister(CapabilityType.ORCHESTRATION, name)


def list_orchestration_capabilities() -> list[AgentCapability]:
    """List all registered orchestration capabilities.

    Returns:
        List of all orchestration capability definitions.
    """
    registry = get_capability_registry()
    return registry.list_all(CapabilityType.ORCHESTRATION)


def _register_default_provider() -> None:
    """Register the default centralized orchestration engine.

    This is called on module import to ensure a default engine is available.
    """
    global _default_registered
    if _default_registered:
        return

    register_orchestration_capability(
        name="centralized",
        provider_factory=_default_centralized_engine,
        priority=0,
        tags={"default", "coordinator"},
        metadata={"mode": "centralized", "features": ["parallel_execution", "retry_policy"]},
    )
    _default_registered = True


# Auto-register default centralized engine on module import
_register_default_provider()
