"""Orchestration mode and configuration types.

.. deprecated:: 1.0.0
    Use `pyclaw.agents.multiagent.types` instead.
    This module will be removed in version 2.0.0.

This module re-exports types from multiagent.types for backward compatibility.
"""

from __future__ import annotations

# Re-export from unified types module
from pyclaw.agents.multiagent.types import (
    OrchestrationContext,
    OrchestrationMode,
    OrchestrationResult,
    RetryPolicy,
    SubagentResult,
)

__all__ = [
    "OrchestrationMode",
    "RetryPolicy",
    "OrchestrationContext",
    "SubagentResult",
    "OrchestrationResult",
]
