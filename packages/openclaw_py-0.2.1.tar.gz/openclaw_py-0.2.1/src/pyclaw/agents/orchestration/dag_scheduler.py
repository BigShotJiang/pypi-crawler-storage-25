"""DAG scheduler — dependency resolution and parallel execution.

Implements:
- DAG construction from task dependencies
- Circular dependency detection
- Topological sort
- Parallel execution strategy
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class TaskStatus(str, Enum):
    """Status of a task in the DAG."""

    PENDING = "pending"
    READY = "ready"  # Dependencies met, ready to run
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"  # Dependency failed


@dataclass
class DAGNode:
    """A node in the DAG."""

    id: str
    name: str
    description: str = ""
    dependencies: list[str] = field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    priority: int = 5
    metadata: dict[str, Any] = field(default_factory=dict)
    result: Any = None
    error: str | None = None


@dataclass
class CycleError(Exception):
    """Raised when circular dependency is detected."""

    cycle_path: list[str]

    def __str__(self) -> str:
        return f"Circular dependency detected: {' -> '.join(self.cycle_path)}"


@dataclass
class DAGConfig:
    """Configuration for DAG execution."""

    max_parallel: int = 4
    retry_failed: bool = True
    max_retries: int = 2
    fail_fast: bool = False  # Stop all on first failure


class DAGBuilder:
    """Builds and validates DAG from task definitions."""

    def __init__(self) -> None:
        self._nodes: dict[str, DAGNode] = {}

    def add_node(self, node: DAGNode) -> None:
        """Add a node to the DAG.

        Args:
            node: Node to add.
        """
        self._nodes[node.id] = node

    def add_nodes_from_dict(self, tasks: dict[str, dict[str, Any]]) -> None:
        """Add nodes from a dictionary.

        Args:
            tasks: Dict mapping task ID to task definition.
        """
        for task_id, task_def in tasks.items():
            node = DAGNode(
                id=task_id,
                name=task_def.get("name", task_id),
                description=task_def.get("description", ""),
                dependencies=task_def.get("dependencies", []),
                priority=task_def.get("priority", 5),
                metadata=task_def.get("metadata", {}),
            )
            self.add_node(node)

    def validate(self) -> list[str]:
        """Validate the DAG.

        Returns:
            List of validation errors (empty if valid).
        """
        errors = []

        # Check for missing dependencies
        all_ids = set(self._nodes.keys())
        for node in self._nodes.values():
            for dep in node.dependencies:
                if dep not in all_ids:
                    errors.append(f"Task {node.id} depends on non-existent task {dep}")

        # Check for cycles
        try:
            self._detect_cycles()
        except CycleError as e:
            errors.append(str(e))

        return errors

    def _detect_cycles(self) -> None:
        """Detect cycles in the DAG.

        Raises:
            CycleError: If cycle is detected.
        """
        # DFS-based cycle detection
        WHITE, GRAY, BLACK = 0, 1, 2
        color = {node_id: WHITE for node_id in self._nodes}

        def dfs(node_id: str, path: list[str]) -> None:
            if color[node_id] == GRAY:
                # Found cycle
                cycle_start = path.index(node_id)
                raise CycleError(cycle_path=path[cycle_start:] + [node_id])

            if color[node_id] == BLACK:
                return

            color[node_id] = GRAY
            path.append(node_id)

            node = self._nodes[node_id]
            for dep in node.dependencies:
                if dep in self._nodes:
                    dfs(dep, path)

            path.pop()
            color[node_id] = BLACK

        for node_id in self._nodes:
            if color[node_id] == WHITE:
                dfs(node_id, [])

    def topological_sort(self) -> list[str]:
        """Get topological order of nodes.

        Returns:
            List of node IDs in topological order.
        """
        # Kahn's algorithm
        in_degree = {node_id: 0 for node_id in self._nodes}
        dependents: dict[str, list[str]] = {node_id: [] for node_id in self._nodes}

        for node in self._nodes.values():
            for dep in node.dependencies:
                if dep in self._nodes:
                    in_degree[node.id] += 1
                    dependents[dep].append(node.id)

        # Start with nodes that have no dependencies
        queue = [node_id for node_id, deg in in_degree.items() if deg == 0]
        result = []

        while queue:
            # Sort for deterministic order
            queue.sort(key=lambda x: (self._nodes[x].priority, x))
            node_id = queue.pop(0)
            result.append(node_id)

            for dependent in dependents[node_id]:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        return result

    def get_execution_levels(self) -> list[list[str]]:
        """Get nodes grouped by execution level (parallelizable groups).

        Returns:
            List of lists, each containing nodes that can run in parallel.
        """
        levels: list[list[str]] = []
        completed: set[str] = set()
        remaining = set(self._nodes.keys())

        while remaining:
            # Find nodes whose dependencies are all completed
            ready = []
            for node_id in list(remaining):
                node = self._nodes[node_id]
                if all(dep in completed for dep in node.dependencies if dep in self._nodes):
                    ready.append(node_id)

            if not ready:
                # Should not happen if DAG is valid
                break

            # Sort by priority
            ready.sort(key=lambda x: self._nodes[x].priority)
            levels.append(ready)

            completed.update(ready)
            remaining -= set(ready)

        return levels

    def build(self) -> DAG:
        """Build the DAG structure.

        Returns:
            DAG ready for execution.
        """
        errors = self.validate()
        if errors:
            raise ValueError(f"Invalid DAG: {'; '.join(errors)}")

        return DAG(nodes=self._nodes, order=self.topological_sort())


class DAG:
    """Executable DAG structure."""

    def __init__(
        self,
        nodes: dict[str, DAGNode],
        order: list[str],
        config: DAGConfig | None = None,
    ) -> None:
        self._nodes = nodes
        self._order = order
        self._config = config or DAGConfig()
        self._execution_levels: list[list[str]] | None = None

    @property
    def nodes(self) -> dict[str, DAGNode]:
        return self._nodes

    @property
    def order(self) -> list[str]:
        return self._order

    def get_execution_levels(self) -> list[list[str]]:
        """Get parallelizable execution groups."""
        if self._execution_levels is None:
            builder = DAGBuilder()
            builder._nodes = self._nodes
            self._execution_levels = builder.get_execution_levels()
        return self._execution_levels

    def get_ready_tasks(self) -> list[str]:
        """Get tasks that are ready to run.

        Returns:
            List of task IDs ready for execution.
        """
        ready = []
        for node_id in self._order:
            node = self._nodes[node_id]
            if node.status != TaskStatus.PENDING:
                continue

            # Check dependencies
            deps_met = all(
                self._nodes[dep].status == TaskStatus.COMPLETED for dep in node.dependencies if dep in self._nodes
            )

            if deps_met:
                ready.append(node_id)

        return ready

    def mark_running(self, task_id: str) -> None:
        """Mark a task as running."""
        self._nodes[task_id].status = TaskStatus.RUNNING

    def mark_completed(self, task_id: str, result: Any = None) -> None:
        """Mark a task as completed."""
        node = self._nodes[task_id]
        node.status = TaskStatus.COMPLETED
        node.result = result

    def mark_failed(
        self,
        task_id: str,
        error: str,
        block_dependents: bool = True,
    ) -> None:
        """Mark a task as failed.

        Args:
            task_id: Failed task.
            error: Error message.
            block_dependents: If True, mark all dependents as blocked.
        """
        node = self._nodes[task_id]
        node.status = TaskStatus.FAILED
        node.error = error

        if block_dependents:
            self._block_dependents(task_id)

    def _block_dependents(self, failed_id: str) -> None:
        """Block all tasks that depend on a failed task."""
        for node in self._nodes.values():
            if failed_id in node.dependencies and node.status == TaskStatus.PENDING:
                node.status = TaskStatus.BLOCKED
                node.error = f"Dependency {failed_id} failed"

    def get_progress(self) -> dict[str, Any]:
        """Get execution progress.

        Returns:
            Dict with progress statistics.
        """
        status_counts: dict[TaskStatus, int] = {}
        for node in self._nodes.values():
            status_counts[node.status] = status_counts.get(node.status, 0) + 1

        total = len(self._nodes)
        completed = status_counts.get(TaskStatus.COMPLETED, 0)
        failed = status_counts.get(TaskStatus.FAILED, 0)
        blocked = status_counts.get(TaskStatus.BLOCKED, 0)

        return {
            "total": total,
            "completed": completed,
            "failed": failed,
            "blocked": blocked,
            "pending": status_counts.get(TaskStatus.PENDING, 0),
            "running": status_counts.get(TaskStatus.RUNNING, 0),
            "progress_percent": (completed / total * 100) if total > 0 else 0,
        }


class ParallelExecutor:
    """Executes DAG tasks in parallel."""

    def __init__(
        self,
        dag: DAG,
        executor: Callable[[str, DAGNode], Any] | None = None,
    ) -> None:
        self._dag = dag
        self._executor = executor
        self._running: dict[str, asyncio.Task] = {}
        self._lock = asyncio.Lock()

    async def execute(self) -> dict[str, Any]:
        """Execute the DAG.

        Returns:
            Dict mapping task IDs to results.
        """
        results: dict[str, Any] = {}

        while True:
            # Get ready tasks
            ready = self._dag.get_ready_tasks()

            # Check if we're done
            progress = self._dag.get_progress()
            if progress["pending"] == 0 and progress["running"] == 0:
                break

            # Launch tasks up to max_parallel
            slots = self._dag._config.max_parallel - len(self._running)
            for task_id in ready[:slots]:
                await self._launch_task(task_id)

            # Wait for any task to complete
            if self._running:
                done, _ = await asyncio.wait(
                    self._running.values(),
                    return_when=asyncio.FIRST_COMPLETED,
                )

                # Process completed tasks
                for task in done:
                    await self._process_completed_task(task)

            await asyncio.sleep(0.1)  # Small delay to prevent busy loop

        # Collect results
        for node in self._dag.nodes.values():
            if node.status == TaskStatus.COMPLETED:
                results[node.id] = node.result

        return results

    async def _launch_task(self, task_id: str) -> None:
        """Launch a task."""
        self._dag.mark_running(task_id)

        async def run():
            try:
                if self._executor:
                    result = await self._executor(task_id, self._dag.nodes[task_id])
                else:
                    # Default: just mark complete
                    result = {"status": "completed"}

                async with self._lock:
                    self._dag.mark_completed(task_id, result)
                return result
            except Exception as e:
                async with self._lock:
                    self._dag.mark_failed(task_id, str(e))
                raise

        self._running[task_id] = asyncio.create_task(run())

    async def _process_completed_task(self, task: asyncio.Task) -> None:
        """Process a completed task."""
        # Find task ID
        task_id = None
        for tid, t in self._running.items():
            if t is task:
                task_id = tid
                break

        if task_id:
            del self._running[task_id]

            # Get result/error
            try:
                task.result()
            except Exception as e:
                logger.error("Task %s failed: %s", task_id, e)
