"""Orchestration engine abstract base class.

This module defines the OrchestrationEngine ABC that all orchestration
implementations must implement.

Orchestration engines control how multiple agents collaborate:
- Centralized: One coordinator delegates tasks to subagents
- Decentralized: Agents negotiate and collaborate peer-to-peer
- Pipeline: Sequential processing through agent stages
- Hybrid: Combination of patterns
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pyclaw.agents.orchestration.mode import (
    OrchestrationMode,
    OrchestrationResult,
)


class OrchestrationEngine(ABC):
    """Abstract base class for orchestration engines.

    All orchestration engines must implement this interface.
    """

    @property
    @abstractmethod
    def mode(self) -> OrchestrationMode:
        """The orchestration mode this engine implements."""

    @abstractmethod
    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> OrchestrationResult:
        """Execute a goal using orchestrated agents.

        This is the main entry point for orchestration.

        Args:
            goal: The high-level goal to accomplish.
            context: Optional context for execution.
            **kwargs: Additional parameters.

        Returns:
            OrchestrationResult with final output and subagent results.
        """

    @abstractmethod
    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new subagent.

        Args:
            agent_type: Type of agent to spawn.
            prompt: Task prompt for the agent.
            **kwargs: Additional spawn parameters.

        Returns:
            Session ID of the spawned agent.
        """

    @abstractmethod
    async def kill_agent(self, session_id: str) -> bool:
        """Kill a running subagent.

        Args:
            session_id: Session ID of the agent to kill.

        Returns:
            True if killed, False if not found.
        """

    @abstractmethod
    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send a steering instruction to a running agent.

        Args:
            session_id: Session ID of the agent.
            instruction: Steering instruction.

        Returns:
            True if instruction sent, False if not found.
        """

    # -- Optional: lifecycle --

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine (lifecycle hook).

        Args:
            **kwargs: Configuration parameters.
        """
        pass

    async def shutdown(self) -> None:
        """Shut down the engine (lifecycle hook)."""
        pass

    # -- Optional: status --

    def get_status(self) -> dict[str, Any]:
        """Get engine status.

        Returns:
            Status dict with engine state.
        """
        return {"mode": self.mode.value}
