"""Hybrid orchestration engine.

This engine combines multiple orchestration patterns:
1. Can switch between CENTRALIZED and PIPELINE modes
2. Supports dynamic mode selection based on task characteristics
3. Allows nested orchestration (pipeline within centralized, etc.)

Design notes:
- Mode selection based on task type and complexity
- Delegates to appropriate sub-engine
- Provides unified interface for complex workflows
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Protocol

from pyclaw.agents.orchestration.engine import OrchestrationEngine
from pyclaw.agents.orchestration.engines.centralized import CentralizedEngine, CentralizedEngineConfig
from pyclaw.agents.orchestration.engines.pipeline import PipelineEngine, PipelineEngineConfig, PipelineStage
from pyclaw.agents.orchestration.mode import (
    OrchestrationContext,
    OrchestrationMode,
    OrchestrationResult,
)

logger = logging.getLogger(__name__)


class SubagentSpawner(Protocol):
    """Protocol for spawning subagents."""

    async def spawn(self, agent_type: str, prompt: str, **kwargs: Any) -> str: ...
    async def poll(self, session_id: str) -> tuple[bool, str, str | None]: ...
    async def kill(self, session_id: str) -> bool: ...
    async def steer(self, session_id: str, instruction: str) -> bool: ...


@dataclass
class ModeSelectionRule:
    """Rule for selecting orchestration mode.

    Attributes:
        task_patterns: Patterns that trigger this mode.
        mode: Orchestration mode to use.
        priority: Higher priority rules are checked first.
    """

    task_patterns: list[str]
    mode: OrchestrationMode
    priority: int = 0


@dataclass
class HybridEngineConfig:
    """Configuration for HybridEngine."""

    default_mode: OrchestrationMode = OrchestrationMode.CENTRALIZED
    centralized_config: CentralizedEngineConfig = field(default_factory=CentralizedEngineConfig)
    pipeline_config: PipelineEngineConfig = field(default_factory=PipelineEngineConfig)
    mode_selection_rules: list[ModeSelectionRule] = field(default_factory=list)
    auto_select_mode: bool = True


# Default mode selection rules
DEFAULT_MODE_RULES = [
    ModeSelectionRule(
        task_patterns=["analyze and report", "process and verify", "transform"],
        mode=OrchestrationMode.PIPELINE,
        priority=10,
    ),
    ModeSelectionRule(
        task_patterns=["coordinate", "delegate", "distribute"],
        mode=OrchestrationMode.CENTRALIZED,
        priority=10,
    ),
    ModeSelectionRule(
        task_patterns=["step by step", "stages", "phases"],
        mode=OrchestrationMode.PIPELINE,
        priority=5,
    ),
]


class HybridEngine(OrchestrationEngine):
    """Hybrid orchestration engine combining multiple patterns.

    Dynamically selects and uses the appropriate orchestration mode
    based on task characteristics.

    Example:
        engine = HybridEngine(spawner=my_spawner)
        result = await engine.execute("Analyze the data and generate a report")
        # Automatically selects PIPELINE mode

        result = await engine.execute("Coordinate a team to research multiple topics")
        # Automatically selects CENTRALIZED mode
    """

    @property
    def mode(self) -> OrchestrationMode:
        """Return orchestration mode (HYBRID)."""
        return OrchestrationMode.HYBRID

    def __init__(
        self,
        spawner: SubagentSpawner | None = None,
        config: HybridEngineConfig | None = None,
    ) -> None:
        """Initialize the hybrid engine.

        Args:
            spawner: Subagent spawner instance.
            config: Engine configuration.
        """
        self._spawner = spawner
        self._config = config or HybridEngineConfig(
            mode_selection_rules=DEFAULT_MODE_RULES,
        )
        self._context: OrchestrationContext | None = None
        self._active_agents: dict[str, str] = {}

        # Sub-engines
        self._centralized_engine: CentralizedEngine | None = None
        self._pipeline_engine: PipelineEngine | None = None

    def set_spawner(self, spawner: SubagentSpawner) -> None:
        """Set the subagent spawner."""
        self._spawner = spawner
        if self._centralized_engine:
            self._centralized_engine.set_spawner(spawner)
        if self._pipeline_engine:
            self._pipeline_engine.set_spawner(spawner)

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine and sub-engines."""
        if "spawner" in kwargs:
            self._spawner = kwargs["spawner"]

        # Initialize sub-engines
        if self._spawner:
            self._centralized_engine = CentralizedEngine(
                spawner=self._spawner,
                config=self._config.centralized_config,
            )
            self._pipeline_engine = PipelineEngine(
                spawner=self._spawner,
                config=self._config.pipeline_config,
            )

    async def shutdown(self) -> None:
        """Shut down the engine and sub-engines."""
        if self._centralized_engine:
            await self._centralized_engine.shutdown()
        if self._pipeline_engine:
            await self._pipeline_engine.shutdown()
        self._active_agents.clear()

    def _select_mode(self, goal: str) -> OrchestrationMode:
        """Select orchestration mode based on goal.

        Args:
            goal: The goal to accomplish.

        Returns:
            Selected OrchestrationMode.
        """
        if not self._config.auto_select_mode:
            return self._config.default_mode

        goal_lower = goal.lower()

        # Check rules in priority order
        sorted_rules = sorted(
            self._config.mode_selection_rules,
            key=lambda r: r.priority,
            reverse=True,
        )

        for rule in sorted_rules:
            if any(pattern in goal_lower for pattern in rule.task_patterns):
                logger.debug("Mode rule matched: %s -> %s", rule.task_patterns, rule.mode)
                return rule.mode

        # Default based on complexity estimation
        word_count = len(goal.split())
        if word_count < 10:
            # Short goal: simple centralized
            return OrchestrationMode.CENTRALIZED
        elif "and" in goal_lower or "then" in goal_lower:
            # Multi-step: pipeline
            return OrchestrationMode.PIPELINE
        else:
            return self._config.default_mode

    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> OrchestrationResult:
        """Execute a goal using the appropriate mode.

        Args:
            goal: The high-level goal to accomplish.
            context: Optional context for execution.
            **kwargs: Additional parameters:
                - mode: Override mode selection.

        Returns:
            OrchestrationResult with final output.
        """
        if not self._spawner:
            return OrchestrationResult(
                success=False,
                output="",
                error="No subagent spawner configured",
                mode=self.mode,
            )

        start_time = time.time()
        context = context or {}

        # Select mode (allow override)
        selected_mode = kwargs.get("mode", self._select_mode(goal))
        logger.info("Hybrid engine selected mode: %s for goal: %s", selected_mode.value, goal[:50])

        # Create orchestration context
        orch_context = OrchestrationContext(
            session_id=str(uuid.uuid4())[:8],
            workspace_dir=context.get("workspace_dir", "."),
            goal=goal,
            metadata={**context, "selected_mode": selected_mode.value},
        )
        self._context = orch_context

        # Delegate to appropriate sub-engine
        result = await self._execute_with_mode(selected_mode, goal, context, kwargs)

        # Update result with hybrid mode info
        result.mode = self.mode
        result.context = orch_context
        result.total_duration = time.time() - start_time

        return result

    async def _execute_with_mode(
        self,
        mode: OrchestrationMode,
        goal: str,
        context: dict[str, Any],
        kwargs: dict[str, Any],
    ) -> OrchestrationResult:
        """Execute with a specific mode.

        Args:
            mode: Orchestration mode to use.
            goal: The goal to accomplish.
            context: Execution context.
            kwargs: Additional parameters.

        Returns:
            OrchestrationResult.
        """
        if mode == OrchestrationMode.CENTRALIZED:
            if not self._centralized_engine:
                return OrchestrationResult(
                    success=False,
                    output="",
                    error="Centralized engine not initialized",
                    mode=mode,
                )
            return await self._centralized_engine.execute(goal, context, **kwargs)

        elif mode == OrchestrationMode.PIPELINE:
            if not self._pipeline_engine:
                return OrchestrationResult(
                    success=False,
                    output="",
                    error="Pipeline engine not initialized",
                    mode=mode,
                )

            # Build default pipeline stages if not configured
            if not self._pipeline_engine._stages:
                self._pipeline_engine._stages = self._build_default_stages(goal)

            return await self._pipeline_engine.execute(goal, context, **kwargs)

        else:
            return OrchestrationResult(
                success=False,
                output="",
                error=f"Unsupported mode in hybrid engine: {mode}",
                mode=mode,
            )

    def _build_default_stages(self, goal: str) -> list[PipelineStage]:
        """Build default pipeline stages based on goal.

        Args:
            goal: The goal to accomplish.

        Returns:
            List of PipelineStage objects.
        """
        from pyclaw.agents.orchestration.engines.pipeline import PipelineStage

        # Default 4-stage pipeline: explore -> plan -> execute -> verify
        return [
            PipelineStage(
                name="explore",
                agent_type="explore",
                prompt_template="Explore and gather information about: {input}",
            ),
            PipelineStage(
                name="plan",
                agent_type="plan",
                prompt_template="Create a plan based on the exploration: {input}",
            ),
            PipelineStage(
                name="execute",
                agent_type="generalist",
                prompt_template="Execute the plan: {input}",
            ),
            PipelineStage(
                name="verify",
                agent_type="verification",
                prompt_template="Verify the execution result: {input}",
                optional=True,
            ),
        ]

    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new subagent directly."""
        if not self._spawner:
            raise RuntimeError("No subagent spawner configured")

        session_id = await self._spawner.spawn(agent_type, prompt, **kwargs)
        self._active_agents[session_id] = "direct"
        return session_id

    async def kill_agent(self, session_id: str) -> bool:
        """Kill a running subagent."""
        if not self._spawner:
            return False

        if session_id in self._active_agents:
            result = await self._spawner.kill(session_id)
            if result:
                del self._active_agents[session_id]
            return result

        return False

    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send steering instruction to a running agent."""
        if not self._spawner:
            return False

        if session_id in self._active_agents:
            return await self._spawner.steer(session_id, instruction)

        return False

    def get_status(self) -> dict[str, Any]:
        """Get engine status."""
        status = super().get_status()
        status.update(
            {
                "active_agents": len(self._active_agents),
                "centralized_available": self._centralized_engine is not None,
                "pipeline_available": self._pipeline_engine is not None,
                "auto_select_mode": self._config.auto_select_mode,
                "default_mode": self._config.default_mode.value,
            }
        )
        return status
