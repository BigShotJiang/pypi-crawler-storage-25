"""Pipeline orchestration engine.

This engine implements a sequential pipeline pattern where:
1. Input is processed through a series of stages
2. Each stage is handled by a specialized agent
3. Output from one stage becomes input to the next

Design notes:
- Stages are defined as ordered list of agent types
- Each stage can transform or augment the data
- Supports early termination on stage failure
- Optional stage-level timeout and retry
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol

from pyclaw.agents.orchestration.engine import OrchestrationEngine
from pyclaw.agents.orchestration.mode import (
    OrchestrationContext,
    OrchestrationMode,
    OrchestrationResult,
    RetryPolicy,
    SubagentResult,
)

logger = logging.getLogger(__name__)


class SubagentSpawner(Protocol):
    """Protocol for spawning subagents."""

    async def spawn(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a subagent and return its session ID."""
        ...

    async def poll(self, session_id: str) -> tuple[bool, str, str | None]:
        """Poll a subagent for status."""
        ...

    async def kill(self, session_id: str) -> bool:
        """Kill a subagent."""
        ...

    async def steer(self, session_id: str, instruction: str) -> bool:
        """Send steering instruction to a subagent."""
        ...


@dataclass
class PipelineStage:
    """A single stage in the pipeline.

    Attributes:
        name: Stage name for logging and debugging.
        agent_type: Type of agent to handle this stage.
        prompt_template: Template for constructing stage prompt.
            Can use {input} and {context} placeholders.
        timeout_seconds: Stage-specific timeout override.
        retry_policy: Stage-specific retry policy override.
        optional: If True, failure doesn't stop pipeline.
    """

    name: str
    agent_type: str
    prompt_template: str = "{input}"
    timeout_seconds: int | None = None
    retry_policy: RetryPolicy | None = None
    optional: bool = False


@dataclass
class PipelineEngineConfig:
    """Configuration for PipelineEngine."""

    stages: list[PipelineStage] = field(default_factory=list)
    default_timeout_seconds: int = 300
    default_retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    poll_interval_seconds: float = 1.0
    pass_context: bool = True  # Pass accumulated context between stages


class PipelineEngine(OrchestrationEngine):
    """Pipeline orchestration engine.

    Executes tasks through a sequential pipeline of agent stages.
    Each stage transforms the input and passes it to the next stage.

    Example:
        stages = [
            PipelineStage("analyze", "analyzer", "Analyze: {input}"),
            PipelineStage("plan", "planner", "Create a plan based on: {input}"),
            PipelineStage("execute", "executor", "Execute the plan: {input}"),
            PipelineStage("verify", "verifier", "Verify the result: {input}"),
        ]
        engine = PipelineEngine(stages=stages, spawner=my_spawner)
        result = await engine.execute("Build a REST API")
    """

    @property
    def mode(self) -> OrchestrationMode:
        """Return orchestration mode."""
        return OrchestrationMode.PIPELINE

    def __init__(
        self,
        stages: list[PipelineStage] | None = None,
        spawner: SubagentSpawner | None = None,
        config: PipelineEngineConfig | None = None,
    ) -> None:
        """Initialize the pipeline engine.

        Args:
            stages: List of pipeline stages (can be set via config).
            spawner: Subagent spawner instance.
            config: Engine configuration.
        """
        self._spawner = spawner
        if config:
            self._config = config
            self._stages = stages or config.stages
        else:
            self._config = PipelineEngineConfig(stages=stages or [])
            self._stages = stages or []

        self._context: OrchestrationContext | None = None
        self._active_agents: dict[str, str] = {}  # session_id -> stage_name

    def set_spawner(self, spawner: SubagentSpawner) -> None:
        """Set the subagent spawner."""
        self._spawner = spawner

    def add_stage(self, stage: PipelineStage) -> None:
        """Add a stage to the pipeline.

        Args:
            stage: Pipeline stage to add.
        """
        self._stages.append(stage)

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine."""
        if "spawner" in kwargs:
            self._spawner = kwargs["spawner"]
        if "stages" in kwargs:
            self._stages = kwargs["stages"]

    async def shutdown(self) -> None:
        """Shut down the engine."""
        if self._spawner:
            for session_id in list(self._active_agents.keys()):
                try:
                    await self._spawner.kill(session_id)
                except Exception as e:
                    logger.warning("Failed to kill agent %s: %s", session_id, e)
        self._active_agents.clear()

    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> OrchestrationResult:
        """Execute a goal through the pipeline.

        Args:
            goal: The input to process through the pipeline.
            context: Optional context for execution.
            **kwargs: Additional parameters.

        Returns:
            OrchestrationResult with final output.
        """
        if not self._spawner:
            return OrchestrationResult(
                success=False,
                output="",
                error="No subagent spawner configured",
                mode=self.mode,
            )

        if not self._stages:
            return OrchestrationResult(
                success=False,
                output="",
                error="No pipeline stages defined",
                mode=self.mode,
            )

        start_time = time.time()
        context = context or {}

        # Create orchestration context
        orch_context = OrchestrationContext(
            session_id=str(uuid.uuid4())[:8],
            workspace_dir=context.get("workspace_dir", "."),
            goal=goal,
            metadata=context,
        )
        self._context = orch_context

        logger.info("Starting pipeline execution with %d stages: %s", len(self._stages), goal)

        # Execute stages sequentially
        current_input = goal
        accumulated_context: dict[str, Any] = {"original_goal": goal}
        subagent_results: list[SubagentResult] = []

        for stage_idx, stage in enumerate(self._stages):
            logger.info("Executing stage %d/%d: %s", stage_idx + 1, len(self._stages), stage.name)

            result = await self._execute_stage(
                stage=stage,
                input_data=current_input,
                context={**context, **accumulated_context},
            )

            subagent_results.append(result)

            if result.success:
                # Update input for next stage
                current_input = result.output
                accumulated_context[f"stage_{stage.name}"] = result.output
                logger.debug("Stage %s completed: output length=%d", stage.name, len(result.output))
            elif not stage.optional:
                # Stage failed and is not optional
                logger.error("Stage %s failed: %s", stage.name, result.error)
                return OrchestrationResult(
                    success=False,
                    output=current_input,  # Return last successful output
                    error=f"Pipeline failed at stage '{stage.name}': {result.error}",
                    subagent_results=subagent_results,
                    total_duration=time.time() - start_time,
                    mode=self.mode,
                    context=orch_context,
                )
            else:
                # Optional stage failed, continue with current input
                logger.warning("Optional stage %s failed, continuing: %s", stage.name, result.error)
                accumulated_context[f"stage_{stage.name}_error"] = result.error

        logger.info(
            "Pipeline completed: success=True, duration=%.2fs",
            time.time() - start_time,
        )

        return OrchestrationResult(
            success=True,
            output=current_input,
            subagent_results=subagent_results,
            total_duration=time.time() - start_time,
            mode=self.mode,
            context=orch_context,
        )

    async def _execute_stage(
        self,
        stage: PipelineStage,
        input_data: str,
        context: dict[str, Any],
    ) -> SubagentResult:
        """Execute a single pipeline stage.

        Args:
            stage: The stage to execute.
            input_data: Input data for the stage.
            context: Execution context.

        Returns:
            SubagentResult with stage outcome.
        """
        if not self._spawner:
            return SubagentResult(
                agent_type=stage.agent_type,
                session_id="",
                success=False,
                output="",
                error="No spawner configured",
            )

        # Build prompt from template
        prompt = stage.prompt_template.format(input=input_data, context=context)

        started_at = datetime.now()
        timeout = stage.timeout_seconds or self._config.default_timeout_seconds
        retry_policy = stage.retry_policy or self._config.default_retry_policy
        retries = 0
        last_error: str | None = None

        while retries <= retry_policy.max_retries:
            try:
                # Spawn subagent for this stage
                session_id = await self._spawner.spawn(
                    agent_type=stage.agent_type,
                    prompt=prompt,
                    **context,
                )
                self._active_agents[session_id] = stage.name

                # Wait for completion
                completed = False
                output = ""
                error = None

                start_wait = time.time()
                while time.time() - start_wait < timeout:
                    completed, output, error = await self._spawner.poll(session_id)
                    if completed:
                        break
                    await asyncio.sleep(self._config.poll_interval_seconds)

                if not completed:
                    await self._spawner.kill(session_id)
                    raise TimeoutError(f"Stage {stage.name} timed out after {timeout}s")

                # Clean up
                del self._active_agents[session_id]

                if error:
                    raise RuntimeError(error)

                return SubagentResult(
                    agent_type=stage.agent_type,
                    session_id=session_id,
                    success=True,
                    output=output,
                    duration_seconds=time.time() - start_wait,
                    started_at=started_at,
                    completed_at=datetime.now(),
                )

            except Exception as e:
                last_error = str(e)
                retries += 1

                if retries <= retry_policy.max_retries:
                    delay = retry_policy.retry_delay_seconds * (retry_policy.backoff_multiplier ** (retries - 1))
                    delay = min(delay, retry_policy.max_delay_seconds)
                    logger.warning(
                        "Stage %s failed, retrying in %.1fs (attempt %d/%d): %s",
                        stage.name,
                        delay,
                        retries,
                        retry_policy.max_retries,
                        last_error,
                    )
                    await asyncio.sleep(delay)

        return SubagentResult(
            agent_type=stage.agent_type,
            session_id="",
            success=False,
            output="",
            error=last_error,
            started_at=started_at,
        )

    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new subagent directly."""
        if not self._spawner:
            raise RuntimeError("No subagent spawner configured")

        session_id = await self._spawner.spawn(agent_type, prompt, **kwargs)
        self._active_agents[session_id] = "direct"
        return session_id

    async def kill_agent(self, session_id: str) -> bool:
        """Kill a running subagent."""
        if not self._spawner:
            return False

        if session_id in self._active_agents:
            result = await self._spawner.kill(session_id)
            if result:
                del self._active_agents[session_id]
            return result

        return False

    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send steering instruction to a running agent."""
        if not self._spawner:
            return False

        if session_id in self._active_agents:
            return await self._spawner.steer(session_id, instruction)

        return False

    def get_status(self) -> dict[str, Any]:
        """Get engine status."""
        status = super().get_status()
        status.update(
            {
                "stage_count": len(self._stages),
                "stage_names": [s.name for s in self._stages],
                "active_agents": len(self._active_agents),
            }
        )
        return status
