"""Orchestration engines — concrete implementations of OrchestrationEngine.

.. deprecated:: 1.0.0
    This module is deprecated. Use :mod:`pyclaw.agents.multiagent.engines` instead.
    This module will be removed in version 2.0.0.
"""

import warnings

from pyclaw.agents.orchestration.engines.centralized import CentralizedEngine
from pyclaw.agents.orchestration.engines.hybrid import HybridEngine
from pyclaw.agents.orchestration.engines.pipeline import PipelineEngine, PipelineStage

# Emit deprecation warning on import
warnings.warn(
    "pyclaw.agents.orchestration.engines is deprecated since version 1.0.0. "
    "Use pyclaw.agents.multiagent.engines instead. "
    "This module will be removed in version 2.0.0.",
    DeprecationWarning,
    stacklevel=2,
)

__all__ = [
    "CentralizedEngine",
    "HybridEngine",
    "PipelineEngine",
    "PipelineStage",
]
