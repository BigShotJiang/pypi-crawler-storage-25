"""Centralized orchestration engine.

This engine implements a coordinator pattern where:
1. A main coordinator decomposes a goal into subtasks
2. Subtasks are assigned to specialized subagents
3. Results are aggregated into a final output

Design notes:
- Uses DAG scheduler for dependency management
- Supports parallel execution with semaphore
- Implements retry policy for failed subagents
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol

from pyclaw.agents.orchestration.dag_scheduler import (
    DAGBuilder,
    DAGNode,
    TaskStatus,
)
from pyclaw.agents.orchestration.decomposer import Subtask, decompose_task
from pyclaw.agents.orchestration.engine import OrchestrationEngine
from pyclaw.agents.orchestration.mode import (
    OrchestrationContext,
    OrchestrationMode,
    OrchestrationResult,
    RetryPolicy,
    SubagentResult,
)

logger = logging.getLogger(__name__)


class SubagentSpawner(Protocol):
    """Protocol for spawning subagents."""

    async def spawn(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a subagent and return its session ID."""
        ...

    async def poll(self, session_id: str) -> tuple[bool, str, str | None]:
        """Poll a subagent for status.

        Returns:
            Tuple of (completed, output, error).
        """
        ...

    async def kill(self, session_id: str) -> bool:
        """Kill a subagent."""
        ...

    async def steer(self, session_id: str, instruction: str) -> bool:
        """Send steering instruction to a subagent."""
        ...


@dataclass
class CentralizedEngineConfig:
    """Configuration for CentralizedEngine."""

    max_parallel: int = 4
    max_depth: int = 5
    timeout_seconds: int = 300
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    poll_interval_seconds: float = 1.0


class CentralizedEngine(OrchestrationEngine):
    """Centralized orchestration engine.

    This engine implements a coordinator pattern for multi-agent collaboration.
    The coordinator decomposes a high-level goal into subtasks and delegates
    them to specialized subagents.

    Example:
        engine = CentralizedEngine(spawner=my_spawner)
        result = await engine.execute("Research and summarize the latest AI trends")
    """

    @property
    def mode(self) -> OrchestrationMode:
        """Return orchestration mode."""
        return OrchestrationMode.CENTRALIZED

    def __init__(
        self,
        spawner: SubagentSpawner | None = None,
        config: CentralizedEngineConfig | None = None,
    ) -> None:
        """Initialize the centralized engine.

        Args:
            spawner: Subagent spawner instance (can be set later via set_spawner).
            config: Engine configuration.
        """
        self._spawner = spawner
        self._config = config or CentralizedEngineConfig()
        self._context: OrchestrationContext | None = None
        self._active_agents: dict[str, str] = {}  # session_id -> agent_type

    def set_spawner(self, spawner: SubagentSpawner) -> None:
        """Set the subagent spawner.

        Args:
            spawner: Subagent spawner instance.
        """
        self._spawner = spawner

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine.

        Args:
            **kwargs: Configuration parameters.
        """
        if "spawner" in kwargs:
            self._spawner = kwargs["spawner"]

    async def shutdown(self) -> None:
        """Shut down the engine and kill all active agents."""
        if self._spawner:
            for session_id in list(self._active_agents.keys()):
                try:
                    await self._spawner.kill(session_id)
                except Exception as e:
                    logger.warning("Failed to kill agent %s: %s", session_id, e)
        self._active_agents.clear()

    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> OrchestrationResult:
        """Execute a goal using orchestrated agents.

        Args:
            goal: The high-level goal to accomplish.
            context: Optional context for execution.
            **kwargs: Additional parameters.

        Returns:
            OrchestrationResult with final output and subagent results.
        """
        if not self._spawner:
            return OrchestrationResult(
                success=False,
                output="",
                error="No subagent spawner configured",
                mode=self.mode,
            )

        start_time = time.time()
        context = context or {}

        # Create orchestration context
        orch_context = OrchestrationContext(
            session_id=str(uuid.uuid4())[:8],
            workspace_dir=context.get("workspace_dir", "."),
            goal=goal,
            metadata=context,
        )
        self._context = orch_context

        logger.info("Starting centralized orchestration: %s", goal)

        # 1. Decompose goal into subtasks
        subtasks = await self._decompose_goal(goal, context)
        if not subtasks:
            return OrchestrationResult(
                success=False,
                output="Failed to decompose goal into subtasks",
                mode=self.mode,
                context=orch_context,
            )

        logger.info("Decomposed into %d subtasks", len(subtasks))

        # 2. Build DAG from subtasks
        dag = self._build_dag(subtasks)

        # 3. Execute subtasks with dependency management
        subagent_results = await self._execute_with_dependencies(dag, context)

        # 4. Aggregate results
        result = self._aggregate_results(subagent_results, orch_context, start_time)

        logger.info(
            "Orchestration completed: success=%s, duration=%.2fs",
            result.success,
            result.total_duration,
        )

        return result

    async def _decompose_goal(
        self,
        goal: str,
        context: dict[str, Any],
    ) -> list[Subtask]:
        """Decompose a goal into subtasks.

        Args:
            goal: The goal to decompose.
            context: Execution context.

        Returns:
            List of Subtask objects.
        """
        # Use existing decompose_task function
        return decompose_task(goal, context)

    def _build_dag(self, subtasks: list[Subtask]) -> Any:
        """Build a DAG from subtasks.

        Args:
            subtasks: List of subtasks.

        Returns:
            DAG structure for execution.
        """
        builder = DAGBuilder()

        for task in subtasks:
            node = DAGNode(
                id=task.id,
                name=task.id,
                description=task.description,
                dependencies=task.dependencies,
                priority=task.priority.value,
                metadata={
                    "required_role": task.required_role,
                    "context": task.context,
                },
            )
            builder.add_node(node)

        # Validate and build
        errors = builder.validate()
        if errors:
            logger.warning("DAG validation errors: %s", errors)

        return builder.build()

    async def _execute_with_dependencies(
        self,
        dag: Any,
        context: dict[str, Any],
    ) -> list[SubagentResult]:
        """Execute DAG with dependency management.

        Args:
            dag: The DAG to execute.
            context: Execution context.

        Returns:
            List of subagent results.
        """
        results: list[SubagentResult] = []
        semaphore = asyncio.Semaphore(self._config.max_parallel)

        # Get execution levels (parallelizable groups)
        levels = dag.get_execution_levels()

        async def execute_task(task_id: str) -> SubagentResult:
            """Execute a single task."""
            node = dag.nodes[task_id]
            agent_type = node.metadata.get("required_role", "generalist")
            task_context = node.metadata.get("context", {})

            async with semaphore:
                return await self._execute_single_task(
                    task_id=task_id,
                    agent_type=agent_type,
                    description=node.description,
                    context={**context, **task_context},
                )

        # Execute level by level
        for level_idx, level in enumerate(levels):
            logger.info("Executing level %d with %d tasks", level_idx, len(level))

            # Mark tasks as ready
            for task_id in level:
                dag.nodes[task_id].status = TaskStatus.READY

            # Execute level in parallel
            level_results = await asyncio.gather(
                *[execute_task(task_id) for task_id in level],
                return_exceptions=True,
            )

            # Process results
            for task_id, result in zip(level, level_results, strict=True):
                if isinstance(result, Exception):
                    logger.error("Task %s failed with exception: %s", task_id, result)
                    dag.nodes[task_id].status = TaskStatus.FAILED
                    dag.nodes[task_id].error = str(result)
                    results.append(
                        SubagentResult(
                            agent_type="unknown",
                            session_id="",
                            success=False,
                            output="",
                            error=str(result),
                        )
                    )
                elif isinstance(result, SubagentResult):
                    dag.nodes[task_id].status = TaskStatus.COMPLETED if result.success else TaskStatus.FAILED
                    results.append(result)

        return results

    async def _execute_single_task(
        self,
        task_id: str,
        agent_type: str,
        description: str,
        context: dict[str, Any],
    ) -> SubagentResult:
        """Execute a single subtask with retry logic.

        Args:
            task_id: Task identifier.
            agent_type: Type of agent to spawn.
            description: Task description.
            context: Task context.

        Returns:
            SubagentResult with execution outcome.
        """
        if not self._spawner:
            return SubagentResult(
                agent_type=agent_type,
                session_id="",
                success=False,
                output="",
                error="No spawner configured",
            )

        started_at = datetime.now()
        retries = 0
        last_error: str | None = None

        while retries <= self._config.retry_policy.max_retries:
            try:
                # Spawn subagent
                session_id = await self._spawner.spawn(
                    agent_type=agent_type,
                    prompt=description,
                    **context,
                )
                self._active_agents[session_id] = agent_type

                # Wait for completion
                completed = False
                output = ""
                error = None

                start_wait = time.time()
                while time.time() - start_wait < self._config.timeout_seconds:
                    completed, output, error = await self._spawner.poll(session_id)
                    if completed:
                        break
                    await asyncio.sleep(self._config.poll_interval_seconds)

                if not completed:
                    # Timeout
                    await self._spawner.kill(session_id)
                    raise TimeoutError(f"Task {task_id} timed out")

                # Clean up
                del self._active_agents[session_id]

                if error and self._should_retry(error, retries):
                    raise RuntimeError(error)

                completed_at = datetime.now()
                return SubagentResult(
                    agent_type=agent_type,
                    session_id=session_id,
                    success=error is None,
                    output=output,
                    error=error,
                    duration_seconds=time.time() - start_wait,
                    started_at=started_at,
                    completed_at=completed_at,
                )

            except Exception as e:
                last_error = str(e)
                retries += 1

                if retries <= self._config.retry_policy.max_retries:
                    delay = self._get_retry_delay(retries)
                    logger.warning(
                        "Task %s failed, retrying in %.1fs (attempt %d/%d): %s",
                        task_id,
                        delay,
                        retries,
                        self._config.retry_policy.max_retries,
                        last_error,
                    )
                    await asyncio.sleep(delay)

        return SubagentResult(
            agent_type=agent_type,
            session_id="",
            success=False,
            output="",
            error=last_error,
            duration_seconds=0,
            started_at=started_at,
        )

    def _should_retry(self, error: str, retries: int) -> bool:
        """Check if error should trigger a retry.

        Args:
            error: Error message.
            retries: Current retry count.

        Returns:
            True if should retry.
        """
        if retries >= self._config.retry_policy.max_retries:
            return False

        error_lower = error.lower()
        return any(pattern.lower() in error_lower for pattern in self._config.retry_policy.retry_on_errors)

    def _get_retry_delay(self, retries: int) -> float:
        """Calculate retry delay with exponential backoff.

        Args:
            retries: Current retry count.

        Returns:
            Delay in seconds.
        """
        delay = self._config.retry_policy.retry_delay_seconds * (
            self._config.retry_policy.backoff_multiplier ** (retries - 1)
        )
        return min(delay, self._config.retry_policy.max_delay_seconds)

    def _aggregate_results(
        self,
        subagent_results: list[SubagentResult],
        context: OrchestrationContext,
        start_time: float,
    ) -> OrchestrationResult:
        """Aggregate subagent results into final output.

        Args:
            subagent_results: Results from all subagents.
            context: Orchestration context.
            start_time: Start timestamp.

        Returns:
            Aggregated OrchestrationResult.
        """
        # Check overall success
        all_success = all(r.success for r in subagent_results)
        total_tokens = sum(r.tokens_used for r in subagent_results)

        # Build aggregate output
        if all_success:
            outputs = [r.output for r in subagent_results if r.output]
            output = "\n\n".join(outputs) if outputs else "Tasks completed successfully"
        else:
            # Include error information
            failed = [r for r in subagent_results if not r.success]
            errors = [f"{r.agent_type}: {r.error}" for r in failed if r.error]
            output = f"Orchestration failed with {len(failed)} error(s):\n" + "\n".join(errors)

        return OrchestrationResult(
            success=all_success,
            output=output,
            subagent_results=subagent_results,
            total_tokens=total_tokens,
            total_duration=time.time() - start_time,
            mode=self.mode,
            context=context,
        )

    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new subagent directly.

        Args:
            agent_type: Type of agent to spawn.
            prompt: Task prompt.
            **kwargs: Additional spawn parameters.

        Returns:
            Session ID of the spawned agent.
        """
        if not self._spawner:
            raise RuntimeError("No subagent spawner configured")

        session_id = await self._spawner.spawn(agent_type, prompt, **kwargs)
        self._active_agents[session_id] = agent_type
        return session_id

    async def kill_agent(self, session_id: str) -> bool:
        """Kill a running subagent.

        Args:
            session_id: Session ID of the agent to kill.

        Returns:
            True if killed, False if not found.
        """
        if not self._spawner:
            return False

        if session_id in self._active_agents:
            result = await self._spawner.kill(session_id)
            if result:
                del self._active_agents[session_id]
            return result

        return False

    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send steering instruction to a running agent.

        Args:
            session_id: Session ID of the agent.
            instruction: Steering instruction.

        Returns:
            True if instruction sent, False if not found.
        """
        if not self._spawner:
            return False

        if session_id in self._active_agents:
            return await self._spawner.steer(session_id, instruction)

        return False

    def get_status(self) -> dict[str, Any]:
        """Get engine status.

        Returns:
            Status dict with engine state.
        """
        status = super().get_status()
        status.update(
            {
                "active_agents": len(self._active_agents),
                "config": {
                    "max_parallel": self._config.max_parallel,
                    "max_depth": self._config.max_depth,
                    "timeout_seconds": self._config.timeout_seconds,
                },
            }
        )
        return status
