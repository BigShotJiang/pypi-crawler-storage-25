"""Orchestration module for flexible agent management.

.. deprecated:: 1.0.0
    Use `pyclaw.agents.multiagent` instead. This module will be removed in version 2.0.0.

    Migration guide:
    - OrchestrationMode → pyclaw.agents.multiagent.types.OrchestrationMode
    - OrchestrationResult → pyclaw.agents.multiagent.types.OrchestrationResult
    - OrchestrationEngine → pyclaw.agents.multiagent.engine.MultiagentEngine
    - CentralizedEngine → pyclaw.agents.multiagent.engines.CentralizedEngine
    - PipelineEngine → pyclaw.agents.multiagent.engines.PipelineEngine

    See docs/architecture/registry-patterns.md for detailed migration instructions.
"""

from __future__ import annotations

import warnings

from pyclaw.agents.orchestration.capability import (
    get_orchestration_engine,
    list_orchestration_capabilities,
    register_orchestration_capability,
    unregister_orchestration_capability,
)
from pyclaw.agents.orchestration.dag_scheduler import (
    DAG,
    CycleError,
    DAGBuilder,
    DAGConfig,
    DAGNode,
    ParallelExecutor,
    TaskStatus,
)
from pyclaw.agents.orchestration.decomposer import (
    Subtask,
    TaskPriority,
    decompose_task,
)
from pyclaw.agents.orchestration.engine import OrchestrationEngine
from pyclaw.agents.orchestration.engines import CentralizedEngine
from pyclaw.agents.orchestration.manifest import (
    OrchestrationManifest,
    RoleConfig,
    RoleStatus,
    SpawnPolicy,
    ToolPolicy,
)
from pyclaw.agents.orchestration.mode import (
    OrchestrationContext,
    OrchestrationMode,
    OrchestrationResult,
    RetryPolicy,
    SubagentResult,
)
from pyclaw.agents.orchestration.orchestrator_tools import OrchestrateTool
from pyclaw.agents.orchestration.polling import (
    SubagentJoinTool,
    SubagentPollTool,
)
from pyclaw.agents.orchestration.storage import (
    load_manifest,
    save_manifest,
    update_manifest_status,
)

# Emit deprecation warning on import
warnings.warn(
    "pyclaw.agents.orchestration is deprecated since version 1.0.0. "
    "Use pyclaw.agents.multiagent instead. This module will be removed in version 2.0.0.",
    DeprecationWarning,
    stacklevel=2,
)

__all__ = [
    # Engine
    "OrchestrationEngine",
    "CentralizedEngine",
    # Mode types
    "OrchestrationMode",
    "OrchestrationContext",
    "OrchestrationResult",
    "SubagentResult",
    "RetryPolicy",
    # Capability registration
    "register_orchestration_capability",
    "get_orchestration_engine",
    "unregister_orchestration_capability",
    "list_orchestration_capabilities",
    # Manifest
    "OrchestrationManifest",
    "RoleConfig",
    "RoleStatus",
    "SpawnPolicy",
    "ToolPolicy",
    # Storage
    "save_manifest",
    "load_manifest",
    "update_manifest_status",
    # Decomposer
    "decompose_task",
    "TaskPriority",
    "Subtask",
    # Polling
    "SubagentPollTool",
    "SubagentJoinTool",
    "OrchestrateTool",
    # DAG Scheduler
    "CycleError",
    "DAG",
    "DAGBuilder",
    "DAGConfig",
    "DAGNode",
    "ParallelExecutor",
    "TaskStatus",
]
