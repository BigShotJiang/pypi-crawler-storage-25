"""Unified multi-agent module.

This module consolidates all multi-agent coordination patterns from:
- pyclaw.agents.orchestration (DAG scheduling, centralized coordination)
- pyclaw.agents.collaboration (collaboration modes, task decomposition)

Key components:
- MultiagentEngine: Abstract base class for coordination engines
- CollaborationMode: Base class for collaboration patterns
- TaskDecomposer: Task decomposition with heuristic/LLM strategies
- DAGScheduler: Dependency-aware parallel execution
- ModeSelector: Intelligent mode recommendation

Available modes:
- centralized: Coordinator delegates to subagents (merged Centralized + CoordinatorWorker)
- custom_agent: Predefined agents from YAML/Markdown configurations
- dynamic_decompose: Runtime task decomposition with dependencies
- fork_swarm: Parallel execution of same task across multiple agents
- pipeline: Sequential processing through stages
- hybrid: Dynamic pattern selection based on task characteristics

Example:
    >>> from pyclaw.agents.multiagent import MultiagentEngine, ModeSelector
    >>> selector = ModeSelector()
    >>> suggestions = selector.suggest("Analyze sales data and generate report")
    >>> print(suggestions[0].mode)  # CollaborationModeType.DYNAMIC_DECOMPOSE
"""

from pyclaw.agents.multiagent.engine import MultiagentEngine
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    MemoryScope,
    ModeSuggestion,
    MultiagentMode,
    MultiagentResult,
    SpawnResult,
    TrustLevel,
)

__all__ = [
    # Types
    "CollaborationModeType",
    "MultiagentMode",
    "MultiagentResult",
    "SpawnResult",
    "ModeSuggestion",
    "TrustLevel",
    "MemoryScope",
    # Engine
    "MultiagentEngine",
]
