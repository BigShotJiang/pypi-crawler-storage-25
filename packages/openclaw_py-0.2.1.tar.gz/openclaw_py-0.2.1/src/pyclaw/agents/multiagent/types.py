"""Unified type definitions for multi-agent coordination.

This module consolidates types from:
- pyclaw.agents.orchestration.mode
- pyclaw.agents.collaboration.types

Design notes:
- CollaborationModeType: Primary mode enum (from collaboration)
- MultiagentMode: Extended mode enum including orchestration patterns
- Unified result types for all modes
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class CollaborationModeType(str, Enum):
    """Collaboration modes for multi-agent coordination.

    Each mode defines a different pattern of agent cooperation:
    - CUSTOM_AGENT: Use predefined agent configurations
    - DYNAMIC_DECOMPOSE: Decompose task at runtime into subtasks
    - FORK_SWARM: Execute same task in parallel across agents
    - COORDINATOR_WORKER: Coordinator manages worker agents
    - PIPELINE: Sequential processing through stages
    - HYBRID: Dynamic mode selection based on task
    """

    CUSTOM_AGENT = "custom_agent"
    DYNAMIC_DECOMPOSE = "dynamic_decompose"
    FORK_SWARM = "fork_swarm"
    COORDINATOR_WORKER = "coordinator_worker"
    PIPELINE = "pipeline"
    HYBRID = "hybrid"


class MultiagentMode(str, Enum):
    """Extended mode enum for internal use.

    Includes additional modes that may not be directly user-selectable
    but are used internally for coordination patterns.
    """

    NONE = "none"
    CUSTOM_AGENT = "custom_agent"
    DYNAMIC_DECOMPOSE = "dynamic_decompose"
    FORK_SWARM = "fork_swarm"
    COORDINATOR_WORKER = "coordinator_worker"
    CENTRALIZED = "centralized"  # Merged from orchestration
    PIPELINE = "pipeline"
    HYBRID = "hybrid"


class TrustLevel(int, Enum):
    """Trust levels for child agent permissions.

    Controls what tools and operations a child agent can access.
    """

    FULL = 100  # All tools, no authorization required
    STANDARD = 75  # All tools, sensitive ops need authorization
    RESTRICTED = 50  # Remove high-risk tools
    SANDBOX = 25  # Read-only tools only


class MemoryScope(str, Enum):
    """Memory sharing scope for child agents.

    - TASK: Session-scoped memory, inherits parent summary
    - PROJECT: Project-wide shared memory
    """

    TASK = "task"
    PROJECT = "project"


class TaskStatus(str, Enum):
    """Status of a task or subtask."""

    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass
class SpawnResult:
    """Result of spawning a child agent.

    Attributes:
        session_id: Unique identifier for the spawned session
        status: Spawn status (spawned, failed, rate_limited)
        message: Optional status message
        config: Configuration used for spawning
    """

    session_id: str = ""
    status: str = "pending"
    message: str = ""
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class ModeSuggestion:
    """Suggestion for which collaboration mode to use.

    Attributes:
        mode: The suggested collaboration mode
        confidence: Confidence score (0.0 to 1.0)
        reason: Human-readable explanation
        alternatives: Other potentially suitable modes
    """

    mode: CollaborationModeType
    confidence: float = 0.0
    reason: str = ""
    alternatives: list[CollaborationModeType] = field(default_factory=list)


@dataclass
class ModeSwitchResult:
    """Result of switching collaboration modes.

    Attributes:
        success: Whether the switch was successful
        mode: The new mode (if successful)
        message: Status message
    """

    success: bool = False
    mode: CollaborationModeType | None = None
    message: str = ""


@dataclass
class SubagentResult:
    """Result from a single subagent execution.

    Attributes:
        agent_type: Type of the subagent.
        session_id: The subagent's session ID
        success: Whether the execution succeeded
        output: The output from the subagent
        error: Error message if failed
        tokens_used: Total tokens used.
        duration_seconds: Execution duration
        started_at: When the subagent started.
        completed_at: When the subagent completed.
    """

    agent_type: str = ""
    session_id: str = ""
    success: bool = False
    output: str = ""
    error: str | None = None
    tokens_used: int = 0
    duration_seconds: float = 0.0
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: datetime | None = None


@dataclass
class MultiagentResult:
    """Result from multi-agent coordination.

    Attributes:
        success: Whether the overall coordination succeeded
        output: The final output
        subagent_results: Results from individual subagents
        mode: The collaboration mode used
        total_duration_seconds: Total execution time
        error: Error message if failed
    """

    success: bool = False
    output: str = ""
    subagent_results: list[SubagentResult] = field(default_factory=list)
    mode: CollaborationModeType | None = None
    total_duration_seconds: float = 0.0
    error: str | None = None


@dataclass
class ChildContext:
    """Context prepared for a child agent.

    Attributes:
        session_id: Unique session identifier
        parent_session_id: Parent's session ID
        task_prompt: The task for the child agent
        memory_scope: Memory sharing scope
        trust_level: Permission level
        inherited_context: Context inherited from parent
    """

    session_id: str = ""
    parent_session_id: str = ""
    task_prompt: str = ""
    memory_scope: MemoryScope = MemoryScope.TASK
    trust_level: TrustLevel = TrustLevel.STANDARD
    inherited_context: dict[str, Any] = field(default_factory=dict)


@dataclass
class CollaborationSession:
    """Represents an active collaboration session.

    Attributes:
        session_id: Unique identifier
        parent_session_id: Parent session (if spawned)
        mode: Active collaboration mode
        status: Current status
        created_at: Creation timestamp
        config: Session configuration
    """

    session_id: str = ""
    parent_session_id: str | None = None
    mode: CollaborationModeType | None = None
    status: str = "active"
    created_at: str = ""
    config: dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Orchestration Types (migrated from orchestration/mode.py)
# =============================================================================


class OrchestrationMode(str, Enum):
    """Orchestration mode for multi-agent collaboration.

    Each mode represents a different collaboration pattern:
    - NONE: Single agent, no subagent spawning
    - CENTRALIZED: Coordinator delegates tasks to specialized subagents
    - DECENTRALIZED: Agents negotiate and collaborate peer-to-peer
    - PIPELINE: Sequential processing through agent stages
    - HYBRID: Combination of multiple patterns
    """

    NONE = "none"  # Single agent, no orchestration
    CENTRALIZED = "centralized"  # Coordinator delegates to subagents
    DECENTRALIZED = "decentralized"  # Peer-to-peer agent collaboration
    PIPELINE = "pipeline"  # Sequential processing stages
    HYBRID = "hybrid"  # Combination of patterns


@dataclass
class RetryPolicy:
    """Retry policy for subagent failures.

    Controls how orchestration engines handle failures when
    executing subagent tasks.

    Attributes:
        max_retries: Maximum number of retry attempts.
        retry_delay_seconds: Initial delay between retries.
        backoff_multiplier: Multiplier for exponential backoff.
        max_delay_seconds: Maximum delay cap.
        retry_on_errors: List of error patterns to retry on.
    """

    max_retries: int = 2
    retry_delay_seconds: float = 1.0
    backoff_multiplier: float = 2.0
    max_delay_seconds: float = 30.0
    retry_on_errors: list[str] = field(default_factory=lambda: ["timeout", "rate_limit"])


@dataclass
class OrchestrationContext:
    """Execution context for orchestration.

    Provides context information for the orchestration engine
    during execution.

    Attributes:
        session_id: Current orchestration session ID.
        workspace_dir: Working directory for the orchestration.
        parent_session_id: Parent session ID (if spawned from another agent).
        goal: The high-level goal being orchestrated.
        metadata: Additional context metadata.
        started_at: When the orchestration started.
    """

    session_id: str = ""
    workspace_dir: str = ""
    parent_session_id: str | None = None
    goal: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    started_at: datetime = field(default_factory=datetime.now)


@dataclass
class OrchestrationResult:
    """Result from orchestration execution.

    Aggregates results from all subagents and provides
    the final orchestration outcome.

    Attributes:
        success: Whether orchestration succeeded overall.
        output: Final output from orchestration.
        error: Error message if orchestration failed.
        subagent_results: Results from all subagents.
        total_tokens: Total tokens used across all agents.
        total_duration: Total execution duration.
        mode: Orchestration mode used.
        context: Original orchestration context.
    """

    success: bool
    output: str
    error: str | None = None
    subagent_results: list[SubagentResult] = field(default_factory=list)
    total_tokens: int = 0
    total_duration: float = 0.0
    mode: OrchestrationMode = OrchestrationMode.NONE
    context: OrchestrationContext | None = None
