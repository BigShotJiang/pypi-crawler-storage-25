"""Registry[K, V] - Abstract base class for all registry implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Generic, TypeVar

K = TypeVar("K")
V = TypeVar("V")


class Registry(ABC, Generic[K, V]):
    """Abstract base registry with minimal interface.

    All domain-specific registries should extend this class and
    implement at minimum the register() and get() methods.

    Type Parameters:
        K: Key type for registry lookups
        V: Value type being registered

    Example:
        >>> class ToolRegistry(Registry[str, AgentTool]):
        ...     def __init__(self) -> None:
        ...         self._tools: dict[str, AgentTool] = {}
        ...     def register(self, name: str, tool: AgentTool) -> None:
        ...         self._tools[name] = tool
        ...     def get(self, name: str) -> AgentTool | None:
        ...         return self._tools.get(name)
    """

    @abstractmethod
    def register(self, key: K, value: V) -> None:
        """Register a value under the given key.

        Args:
            key: The lookup key.
            value: The value to register.
        """
        ...

    @abstractmethod
    def get(self, key: K) -> V | None:
        """Get a value by key.

        Args:
            key: The lookup key.

        Returns:
            The registered value, or None if not found.
        """
        ...

    def unregister(self, key: K) -> bool:
        """Unregister a value by key.

        Args:
            key: The key to remove.

        Returns:
            True if the value was removed, False if not found.

        Note:
            Subclasses may override for custom cleanup logic.
            Default implementation returns False (not supported).
        """
        return False  # Default: not supported

    def list_all(self) -> list[V]:
        """List all registered values.

        Returns:
            List of all registered values.
            Default implementation returns empty list.
        """
        return []  # Default: empty

    def list_keys(self) -> list[K]:
        """List all registered keys.

        Returns:
            List of all registered keys.
            Default implementation returns empty list.
        """
        return []  # Default: empty

    def clear(self) -> None:
        """Clear all registered values.

        Note:
            Subclasses should override if they need to clean up resources.
            Default implementation is a no-op.
        """
        pass  # Default: no-op

    def __contains__(self, key: K) -> bool:
        """Check if a key is registered."""
        return self.get(key) is not None

    def __len__(self) -> int:
        """Return the number of registered items."""
        return len(self.list_all())
