"""ThreadSafeRegistry - Registry with thread-safe operations."""

from __future__ import annotations

import threading
from collections.abc import Generator
from contextlib import contextmanager
from typing import Generic, TypeVar

from .base import Registry

K = TypeVar("K")
V = TypeVar("V")


class ThreadSafeRegistry(Registry[K, V], Generic[K, V]):
    """Registry wrapper that adds thread-safe locking.

    All operations are protected by a reentrant lock.

    Example:
        >>> registry = ThreadSafeRegistry[str, AgentTool]()
        >>> registry.register("read", ReadTool())
        >>> with registry.lock:
        ...     # Batch operations under single lock
        ...     for tool in tools:
        ...         registry.register(tool.name, tool)
    """

    def __init__(self) -> None:
        self._items: dict[K, V] = {}
        self._lock = threading.RLock()

    @property
    def lock(self) -> threading.RLock:
        """Access the internal lock for batch operations."""
        return self._lock

    @contextmanager
    def locked(self) -> Generator[None, None, None]:
        """Context manager for holding the lock."""
        with self._lock:
            yield

    def register(self, key: K, value: V) -> None:
        with self._lock:
            self._items[key] = value

    def get(self, key: K) -> V | None:
        with self._lock:
            return self._items.get(key)

    def unregister(self, key: K) -> bool:
        with self._lock:
            if key in self._items:
                del self._items[key]
                return True
            return False

    def list_all(self) -> list[V]:
        with self._lock:
            return list(self._items.values())

    def list_keys(self) -> list[K]:
        with self._lock:
            return list(self._items.keys())

    def clear(self) -> None:
        with self._lock:
            self._items.clear()
