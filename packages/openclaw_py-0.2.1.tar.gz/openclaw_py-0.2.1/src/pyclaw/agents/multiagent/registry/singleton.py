"""SingletonRegistry - Mixin for singleton registry behavior."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, ClassVar, Generic, TypeVar

if TYPE_CHECKING:
    pass

K = TypeVar("K")
V = TypeVar("V")
R = TypeVar("R", bound="SingletonRegistry")


class SingletonRegistry(Generic[K, V]):
    """Mixin that provides singleton behavior for registries.

    Usage:
        class MyRegistry(SingletonRegistry[str, MyType], Registry[str, MyType]):
            _instance: ClassVar[MyRegistry | None] = None
            ...
            def register(self, key: str, value: MyType) -> None: ...
            def get(self, key: str) -> MyType | None: ...

    Note:
        This uses a class variable for storage, so each concrete subclass
        gets its own singleton instance. Subclasses MUST re-declare
        `_instance: ClassVar[MyRegistry | None] = None` to ensure
        independent singleton storage.

    Example:
        >>> class CapabilityRegistry(SingletonRegistry[str, type], Registry[str, type]):
        ...     _instance: ClassVar[CapabilityRegistry | None] = None
        ...     def register(self, name: str, cls: type) -> None: ...
        ...     def get(self, name: str) -> type | None: ...
        >>> registry = CapabilityRegistry.get_instance()
    """

    _instance: ClassVar[SingletonRegistry[K, V] | None] = None
    _lock: ClassVar[threading.RLock] = threading.RLock()

    def __new__(cls, *args: object, **kwargs: object) -> SingletonRegistry[K, V]:
        """Create or return the singleton instance."""
        with cls._lock:
            if cls._instance is None:
                instance = super().__new__(cls)
                cls._instance = instance
            return cls._instance  # type: ignore[return-value]

    @classmethod
    def get_instance(cls: type[R]) -> R:
        """Get the singleton instance, creating if necessary.

        Returns:
            The singleton instance of this registry class.
        """
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()  # type: ignore[assignment]
            return cls._instance  # type: ignore[return-value]

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton instance (for testing).

        This will call clear() on the existing instance before
        removing the reference, allowing for proper cleanup.
        """
        with cls._lock:
            if cls._instance is not None:
                # Call clear if available for cleanup
                if hasattr(cls._instance, "clear"):
                    cls._instance.clear()
                cls._instance = None
