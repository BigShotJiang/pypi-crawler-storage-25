"""PipelineEngine - Sequential processing facade.

Wraps orchestration/engines/pipeline.py with MultiagentEngine interface.
Executes tasks through a sequential pipeline of agent stages.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from pyclaw.agents.multiagent.engine import MultiagentEngine
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    MultiagentResult,
    OrchestrationResult,
    SubagentResult,
)
from pyclaw.agents.orchestration.engines.pipeline import (
    PipelineEngine as LegacyPipelineEngine,
)
from pyclaw.agents.orchestration.engines.pipeline import (
    PipelineEngineConfig,
    PipelineStage,
)
from pyclaw.agents.pacs.types import AgentContext, HookPoint

logger = logging.getLogger(__name__)


@dataclass
class PipelineStageConfig:
    """Configuration for a single pipeline stage.

    Simplified config for the facade that maps to PipelineStage.

    Attributes:
        name: Stage name for logging and debugging.
        agent_type: Type of agent to handle this stage.
        prompt_template: Template for constructing stage prompt.
        optional: If True, failure doesn't stop pipeline.
    """

    name: str
    agent_type: str
    prompt_template: str = "{input}"
    optional: bool = False


class PipelineEngine(MultiagentEngine):
    """Facade wrapping orchestration PipelineEngine.

    Executes tasks through a sequential pipeline of agent stages.
    Each stage transforms the input and passes it to the next stage.

    Key features:
    - Sequential execution (stage output -> next stage input)
    - Stage-level timeout and retry (via legacy engine)
    - Optional stages for fault tolerance
    - PACS hooks at each stage start/end (D-04)

    Example:
        stages = [
            PipelineStageConfig("analyze", "analyzer", "Analyze: {input}"),
            PipelineStageConfig("plan", "planner", "Plan: {input}"),
            PipelineStageConfig("execute", "executor", "Execute: {input}"),
        ]
        engine = PipelineEngine(stages=stages, spawner=my_spawner)
        result = await engine.execute("Build a REST API")
    """

    def __init__(
        self,
        stages: list[PipelineStageConfig] | list[PipelineStage] | None = None,
        spawner: Any = None,
        config: PipelineEngineConfig | None = None,
        pacs_context: AgentContext | None = None,
    ) -> None:
        """Initialize the pipeline engine facade.

        Args:
            stages: List of pipeline stages.
            spawner: Subagent spawner instance.
            config: Engine configuration.
            pacs_context: PACS context for hook integration.
        """
        # Convert PipelineStageConfig to PipelineStage if needed
        converted_stages: list[PipelineStage] | None = None
        if stages:
            converted_stages = []
            for stage in stages:
                if isinstance(stage, PipelineStageConfig):
                    converted_stages.append(
                        PipelineStage(
                            name=stage.name,
                            agent_type=stage.agent_type,
                            prompt_template=stage.prompt_template,
                            optional=stage.optional,
                        )
                    )
                else:
                    converted_stages.append(stage)

        self._inner = LegacyPipelineEngine(
            stages=converted_stages,
            spawner=spawner,
            config=config,
        )
        self._pacs_context = pacs_context
        self._stage_results: dict[str, dict[str, Any]] = {}

    @property
    def mode(self) -> CollaborationModeType:
        """Return the collaboration mode.

        Returns:
            CollaborationModeType.PIPELINE
        """
        return CollaborationModeType.PIPELINE

    def add_stage(self, stage: PipelineStageConfig | PipelineStage) -> None:
        """Add a stage to the pipeline.

        Args:
            stage: Pipeline stage to add.
        """
        if isinstance(stage, PipelineStageConfig):
            stage = PipelineStage(
                name=stage.name,
                agent_type=stage.agent_type,
                prompt_template=stage.prompt_template,
                optional=stage.optional,
            )
        self._inner.add_stage(stage)

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine.

        Args:
            **kwargs: Configuration parameters.
        """
        await self._inner.initialize(**kwargs)

    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiagentResult:
        """Execute a goal through the pipeline.

        Triggers PACS hooks at each stage boundary.

        Args:
            goal: The input to process through the pipeline.
            context: Optional context for execution.
            **kwargs: Additional parameters.

        Returns:
            MultiagentResult with final output and all stage results.
        """
        self._trigger_hook(HookPoint.SESSION_INIT, {"goal": goal, "stages": len(self._inner._stages)})

        if not self._inner._spawner:
            logger.warning("No subagent spawner configured")
            return MultiagentResult(
                success=False,
                output="",
                error="No subagent spawner configured",
                mode=self.mode,
            )

        if not self._inner._stages:
            logger.warning("No pipeline stages defined")
            return MultiagentResult(
                success=False,
                output="",
                error="No pipeline stages defined",
                mode=self.mode,
            )

        # Track stage execution for hooks
        self._stage_results.clear()

        try:
            # Delegate to inner engine
            orch_result = await self._inner.execute(goal, context, **kwargs)

            # Emit stage hooks based on results
            for i, stage_result in enumerate(orch_result.subagent_results):
                stage_name = self._inner._stages[i].name if i < len(self._inner._stages) else f"stage-{i}"

                if stage_result.success:
                    self._trigger_hook(
                        HookPoint.SUBAGENT_COMPLETE,
                        {
                            "stage_name": stage_name,
                            "stage_index": i,
                            "output_length": (len(stage_result.output) if stage_result.output else 0),
                        },
                    )
                else:
                    self._trigger_hook(
                        HookPoint.SUBAGENT_ERROR,
                        {
                            "stage_name": stage_name,
                            "stage_index": i,
                            "error": stage_result.error,
                        },
                    )

            self._trigger_hook(
                HookPoint.SESSION_END,
                {
                    "success": orch_result.success,
                    "stage_count": len(orch_result.subagent_results),
                },
            )

            return self._convert_result(orch_result)

        except Exception as e:
            logger.exception("Pipeline execution failed: %s", e)
            self._trigger_hook(
                HookPoint.SUBAGENT_ERROR,
                {"stage_name": "unknown", "error": str(e)},
            )
            return MultiagentResult(
                success=False,
                output="",
                error=str(e),
                mode=self.mode,
            )

    def _convert_result(self, orch_result: OrchestrationResult) -> MultiagentResult:
        """Convert OrchestrationResult to MultiagentResult.

        Maps all fields from the legacy result type to the unified type.

        Args:
            orch_result: The orchestration result to convert.

        Returns:
            MultiagentResult with mapped fields.
        """
        return MultiagentResult(
            success=orch_result.success,
            output=orch_result.output,
            subagent_results=[
                SubagentResult(
                    session_id=r.session_id,
                    success=r.success,
                    output=r.output,
                    error=r.error,
                    duration_seconds=r.duration_seconds,
                )
                for r in orch_result.subagent_results
            ],
            mode=self.mode,
            total_duration_seconds=orch_result.total_duration,
            error=orch_result.error,
        )

    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new child agent.

        Triggers SUBAGENT_SPAWN hook before spawning.

        Args:
            agent_type: Type or configuration name for the agent.
            prompt: Task prompt for the agent.
            **kwargs: Additional spawn parameters.

        Returns:
            Session ID of the spawned agent.
        """
        self._trigger_hook(
            HookPoint.SUBAGENT_SPAWN,
            {"agent_type": agent_type, "prompt": prompt[:100]},
        )

        session_id = await self._inner.spawn_agent(agent_type, prompt, **kwargs)

        self._trigger_hook(
            HookPoint.SUBAGENT_COMPLETE,
            {"session_id": session_id},
        )

        return session_id

    async def kill_agent(self, session_id: str) -> bool:
        """Terminate a running child agent.

        Triggers SESSION_END hook for the agent.

        Args:
            session_id: Session ID of the agent to kill.

        Returns:
            True if killed, False if not found.
        """
        result = await self._inner.kill_agent(session_id)

        if result:
            self._trigger_hook(
                HookPoint.SESSION_END,
                {"session_id": session_id, "reason": "killed"},
            )

        return result

    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send a steering instruction to a running agent.

        Triggers SUBAGENT_PROGRESS hook.

        Args:
            session_id: Session ID of the agent.
            instruction: The instruction to send.

        Returns:
            True if instruction sent, False if not found.
        """
        self._trigger_hook(
            HookPoint.SUBAGENT_PROGRESS,
            {"session_id": session_id, "instruction": instruction[:50]},
        )

        return await self._inner.steer_agent(session_id, instruction)

    def _trigger_hook(self, hook_point: HookPoint, data: dict[str, Any]) -> None:
        """Trigger a PACS hook if context is available.

        Args:
            hook_point: The hook point to emit.
            data: Data to include with the hook.
        """
        if self._pacs_context and self._pacs_context.pacs_bus:
            try:
                logger.debug("Hook emitted: %s with data %s", hook_point.value, data)
            except Exception:
                logger.exception("Failed to emit hook %s", hook_point.value)

    async def shutdown(self) -> None:
        """Shut down the engine and clean up resources."""
        await self._inner.shutdown()

    def get_status(self) -> dict[str, Any]:
        """Get engine status.

        Returns:
            Status dict with engine state.
        """
        status = self._inner.get_status()
        status["mode"] = self.mode.value
        return status

    def get_active_children(self) -> list[dict[str, Any]]:
        """Get list of active child agents.

        Returns:
            List of child agent status dicts.
        """
        # Legacy PipelineEngine tracks active agents in _active_agents dict
        # Convert to list of dicts for interface compatibility
        return [{"session_id": sid, "stage": stage} for sid, stage in self._inner._active_agents.items()]

    def get_stage_names(self) -> list[str]:
        """Get the names of all stages in the pipeline.

        Returns:
            List of stage names.
        """
        return [s.name for s in self._inner._stages]
