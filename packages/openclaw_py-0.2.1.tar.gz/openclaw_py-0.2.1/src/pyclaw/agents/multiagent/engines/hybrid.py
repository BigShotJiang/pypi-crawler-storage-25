"""HybridEngine - Dynamic mode selection facade.

Analyzes task characteristics and routes to the most appropriate engine.
Implements intelligent mode selection per D-02.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from pyclaw.agents.multiagent.engine import MultiagentEngine
from pyclaw.agents.multiagent.engines.centralized import CentralizedEngine
from pyclaw.agents.multiagent.engines.dynamic_decompose import DynamicDecomposeEngine
from pyclaw.agents.multiagent.engines.fork_swarm import ForkSwarmEngine
from pyclaw.agents.multiagent.engines.pipeline import PipelineEngine
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    ModeSuggestion,
    MultiagentResult,
)
from pyclaw.agents.pacs.types import AgentContext, HookPoint
from pyclaw.agents.subagents.manager import SubagentManager

logger = logging.getLogger(__name__)


@dataclass
class ModeSelectionRule:
    """Rule for selecting coordination mode.

    Attributes:
        task_patterns: Patterns that trigger this mode (case-insensitive substring match).
        mode: Collaboration mode to use when matched.
        priority: Higher priority rules are checked first.
    """

    task_patterns: list[str] = field(default_factory=list)
    mode: CollaborationModeType = CollaborationModeType.COORDINATOR_WORKER
    priority: int = 0


# Default mode selection rules per D-02
DEFAULT_MODE_RULES: list[ModeSelectionRule] = [
    # Pipeline patterns - sequential processing
    ModeSelectionRule(
        task_patterns=["analyze and report", "process and verify", "transform"],
        mode=CollaborationModeType.PIPELINE,
        priority=10,
    ),
    # Centralized patterns - coordination/delegation
    ModeSelectionRule(
        task_patterns=["coordinate", "delegate", "distribute"],
        mode=CollaborationModeType.COORDINATOR_WORKER,
        priority=10,
    ),
    # DynamicDecompose patterns - task splitting
    ModeSelectionRule(
        task_patterns=["research", "investigate", "explore", "decompose"],
        mode=CollaborationModeType.DYNAMIC_DECOMPOSE,
        priority=8,
    ),
    # ForkSwarm patterns - parallel/diverse perspectives
    ModeSelectionRule(
        task_patterns=["compare", "evaluate", "multiple", "diverse"],
        mode=CollaborationModeType.FORK_SWARM,
        priority=8,
    ),
    # Step-by-step pipeline
    ModeSelectionRule(
        task_patterns=["step by step", "stages", "phases", "sequentially"],
        mode=CollaborationModeType.PIPELINE,
        priority=5,
    ),
]


class HybridEngine(MultiagentEngine):
    """Facade for dynamic mode selection.

    Analyzes task characteristics and routes to the appropriate engine.
    Uses rule-based matching by default, with optional LLM analysis.

    Key features:
    - Rule-based mode selection (D-02)
    - Delegates to sub-engines based on selection
    - PACS hooks at mode switch points (D-04)
    - Prevents recursive Hybrid selection (max 2 levels)

    Example:
        engine = HybridEngine(subagent_manager=manager)
        result = await engine.execute("Analyze the data and generate a report")
        # Automatically selects PIPELINE mode
    """

    # Maximum recursion depth for Hybrid selecting Hybrid
    MAX_HYBRID_DEPTH = 2

    def __init__(
        self,
        subagent_manager: SubagentManager | None = None,
        mode_selection_rules: list[ModeSelectionRule] | None = None,
        default_mode: CollaborationModeType = CollaborationModeType.COORDINATOR_WORKER,
        auto_select_mode: bool = True,
        pacs_context: AgentContext | None = None,
        hybrid_depth: int = 0,
    ) -> None:
        """Initialize the hybrid engine.

        Args:
            subagent_manager: Manager for spawning subagents.
            mode_selection_rules: Custom rules (defaults to DEFAULT_MODE_RULES).
            default_mode: Fallback mode when no rules match.
            auto_select_mode: If True, use rules; if False, always use default.
            pacs_context: PACS context for hook integration.
            hybrid_depth: Current recursion depth (internal use).
        """
        self._subagent_manager = subagent_manager
        self._mode_selection_rules = mode_selection_rules or DEFAULT_MODE_RULES
        self._default_mode = default_mode
        self._auto_select_mode = auto_select_mode
        self._pacs_context = pacs_context
        self._hybrid_depth = hybrid_depth

        # Lazy-initialized sub-engines
        self._sub_engines: dict[CollaborationModeType, MultiagentEngine] = {}
        self._active_mode: CollaborationModeType | None = None

    @property
    def mode(self) -> CollaborationModeType:
        """Return the collaboration mode.

        Returns:
            CollaborationModeType.HYBRID
        """
        return CollaborationModeType.HYBRID

    def set_subagent_manager(self, manager: SubagentManager) -> None:
        """Set the subagent manager.

        Args:
            manager: SubagentManager instance.
        """
        self._subagent_manager = manager
        # Clear cached sub-engines so they're reinitialized with new manager
        self._sub_engines.clear()

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine and sub-engines.

        Args:
            **kwargs: Configuration parameters.
        """
        if "subagent_manager" in kwargs:
            self._subagent_manager = kwargs["subagent_manager"]
        if "mode_selection_rules" in kwargs:
            self._mode_selection_rules = kwargs["mode_selection_rules"]
        if "default_mode" in kwargs:
            self._default_mode = kwargs["default_mode"]

    def _get_sub_engine(self, mode: CollaborationModeType) -> MultiagentEngine:
        """Get or create sub-engine for the given mode.

        Args:
            mode: The collaboration mode.

        Returns:
            The sub-engine instance.
        """
        if mode not in self._sub_engines:
            self._sub_engines[mode] = self._create_sub_engine(mode)
        return self._sub_engines[mode]

    def _create_sub_engine(self, mode: CollaborationModeType) -> MultiagentEngine:
        """Create a new sub-engine for the given mode.

        Args:
            mode: The collaboration mode.

        Returns:
            A new engine instance.

        Raises:
            ValueError: If mode is unknown.
        """
        if not self._subagent_manager:
            raise RuntimeError("No subagent manager configured")

        # Prevent infinite recursion
        if mode == CollaborationModeType.HYBRID:
            if self._hybrid_depth >= self.MAX_HYBRID_DEPTH:
                logger.warning("Max Hybrid recursion depth reached, falling back to CENTRALIZED")
                return CentralizedEngine(spawner=self._subagent_manager, pacs_context=self._pacs_context)
            # Create nested Hybrid with incremented depth
            return HybridEngine(
                subagent_manager=self._subagent_manager,
                mode_selection_rules=self._mode_selection_rules,
                default_mode=self._default_mode,
                pacs_context=self._pacs_context,
                hybrid_depth=self._hybrid_depth + 1,
            )

        # Engine map with concrete types - different constructors per engine
        # mypy doesn't support different constructor signatures in a dict
        engine_map: dict[CollaborationModeType, type[Any]] = {  # type: ignore[assignment]
            CollaborationModeType.COORDINATOR_WORKER: CentralizedEngine,
            CollaborationModeType.DYNAMIC_DECOMPOSE: DynamicDecomposeEngine,
            CollaborationModeType.FORK_SWARM: ForkSwarmEngine,
            CollaborationModeType.PIPELINE: PipelineEngine,
            CollaborationModeType.CUSTOM_AGENT: CentralizedEngine,  # Single agent
        }

        engine_class = engine_map.get(mode)
        if not engine_class:
            raise ValueError(f"Unknown mode: {mode}")

        # Create engine with appropriate constructor args
        if mode in (
            CollaborationModeType.COORDINATOR_WORKER,
            CollaborationModeType.CUSTOM_AGENT,
        ):
            return engine_class(spawner=self._subagent_manager, pacs_context=self._pacs_context)
        elif mode == CollaborationModeType.DYNAMIC_DECOMPOSE or mode == CollaborationModeType.FORK_SWARM:
            return engine_class(subagent_manager=self._subagent_manager, pacs_context=self._pacs_context)
        elif mode == CollaborationModeType.PIPELINE:
            return engine_class(spawner=self._subagent_manager, pacs_context=self._pacs_context)
        else:
            # Fallback
            return CentralizedEngine(spawner=self._subagent_manager)

    def _select_mode(self, goal: str) -> CollaborationModeType:
        """Select collaboration mode based on goal analysis (D-02).

        Selection logic:
        1. If auto_select_mode is False, return default_mode
        2. Check rules in priority order (higher priority first)
        3. If no rule matches, use heuristics based on complexity
        4. Fallback to default_mode

        Args:
            goal: The goal to analyze.

        Returns:
            Selected CollaborationModeType.
        """
        if not self._auto_select_mode:
            return self._default_mode

        goal_lower = goal.lower()

        # Check rules in priority order
        sorted_rules = sorted(
            self._mode_selection_rules,
            key=lambda r: r.priority,
            reverse=True,
        )

        for rule in sorted_rules:
            if any(pattern in goal_lower for pattern in rule.task_patterns):
                logger.debug(
                    "Mode rule matched: patterns=%s -> %s",
                    rule.task_patterns,
                    rule.mode.value,
                )
                return rule.mode

        # Default based on complexity estimation (D-02)
        word_count = len(goal.split())

        # Short goals -> single task, no dependencies (D-02)
        if word_count < 10:
            return CollaborationModeType.COORDINATOR_WORKER

        # Goals with "and" or "then" -> sequential dependencies (D-02)
        if "and" in goal_lower or "then" in goal_lower:
            return CollaborationModeType.PIPELINE

        # Goals mentioning multiple/comparison -> needs diversity (D-02)
        if "multiple" in goal_lower or "compare" in goal_lower or "evaluate" in goal_lower:
            return CollaborationModeType.FORK_SWARM

        # Goals mentioning research/investigation -> decomposable (D-02)
        if "research" in goal_lower or "investigate" in goal_lower:
            return CollaborationModeType.DYNAMIC_DECOMPOSE

        # Default fallback
        return self._default_mode

    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiagentResult:
        """Execute a goal using the automatically selected mode.

        Triggers MODE_SWITCH hook before delegating.

        Args:
            goal: The high-level goal to accomplish.
            context: Optional execution context.
            **kwargs: Additional parameters (may include mode override).

        Returns:
            MultiagentResult from the delegated engine.
        """
        self._trigger_hook(HookPoint.SESSION_INIT, {"goal": goal})

        if not self._subagent_manager:
            logger.warning("No subagent manager configured")
            return MultiagentResult(
                success=False,
                output="",
                error="No subagent manager configured",
                mode=self.mode,
            )

        # Select mode (allow override via kwargs)
        selected_mode = kwargs.pop("mode", self._select_mode(goal))
        self._active_mode = selected_mode

        logger.info("Hybrid engine selected mode: %s for goal: %s", selected_mode.value, goal[:50])

        # Trigger mode switch hook
        self._trigger_hook(
            HookPoint.MODE_SWITCH,
            {
                "from_mode": self.mode.value,
                "to_mode": selected_mode.value,
                "goal": goal[:100],
            },
        )

        try:
            # Get sub-engine and delegate
            sub_engine = self._get_sub_engine(selected_mode)
            result = await sub_engine.execute(goal, context, **kwargs)

            # Update result to reflect hybrid routing
            # Keep subagent_results from sub-engine but mark as HYBRID
            result.mode = self.mode  # Report HYBRID as outer mode

            self._trigger_hook(
                HookPoint.SESSION_END,
                {
                    "success": result.success,
                    "selected_mode": selected_mode.value,
                },
            )

            return result

        except Exception as e:
            logger.exception("Hybrid execution failed: %s", e)
            self._trigger_hook(
                HookPoint.SUBAGENT_ERROR,
                {
                    "error": str(e),
                    "selected_mode": selected_mode.value,
                },
            )
            return MultiagentResult(
                success=False,
                output="",
                error=str(e),
                mode=self.mode,
            )

    def suggest_mode(self, task_description: str) -> list[ModeSuggestion]:
        """Suggest appropriate modes for a task.

        Args:
            task_description: Description of the task to analyze.

        Returns:
            List of mode suggestions with confidence scores.
        """
        selected = self._select_mode(task_description)
        suggestions: list[ModeSuggestion] = []

        # Primary suggestion
        suggestions.append(
            ModeSuggestion(
                mode=selected,
                confidence=0.8,
                reason="Pattern matched in task description",
            )
        )

        # Add alternatives based on analysis
        goal_lower = task_description.lower()

        if "and" in goal_lower or "then" in goal_lower:
            suggestions.append(
                ModeSuggestion(
                    mode=CollaborationModeType.PIPELINE,
                    confidence=0.7,
                    reason="Task contains sequential keywords",
                    alternatives=[CollaborationModeType.COORDINATOR_WORKER],
                )
            )

        if len(task_description.split()) > 50:
            suggestions.append(
                ModeSuggestion(
                    mode=CollaborationModeType.DYNAMIC_DECOMPOSE,
                    confidence=0.6,
                    reason="Complex task may benefit from decomposition",
                    alternatives=[CollaborationModeType.COORDINATOR_WORKER],
                )
            )

        return suggestions

    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new child agent.

        Delegates to default sub-engine.

        Args:
            agent_type: Type or configuration name for the agent.
            prompt: Task prompt for the agent.
            **kwargs: Additional spawn parameters.

        Returns:
            Session ID of the spawned agent.
        """
        if not self._subagent_manager:
            raise RuntimeError("No subagent manager configured")

        # Use default engine for direct spawns
        default_engine = self._get_sub_engine(self._default_mode)
        return await default_engine.spawn_agent(agent_type, prompt, **kwargs)

    async def kill_agent(self, session_id: str) -> bool:
        """Terminate a running child agent.

        Delegates to appropriate sub-engine.

        Args:
            session_id: Session ID of the agent to kill.

        Returns:
            True if killed, False if not found.
        """
        if not self._subagent_manager:
            return False

        # Try default engine first, then all cached engines
        default_engine = self._get_sub_engine(self._default_mode)
        if await default_engine.kill_agent(session_id):
            return True

        for engine in self._sub_engines.values():
            if await engine.kill_agent(session_id):
                return True

        return False

    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send a steering instruction to a running agent.

        Delegates to appropriate sub-engine.

        Args:
            session_id: Session ID of the agent.
            instruction: The instruction to send.

        Returns:
            True if instruction sent, False if not found.
        """
        if not self._subagent_manager:
            return False

        self._trigger_hook(
            HookPoint.SUBAGENT_PROGRESS,
            {
                "session_id": session_id,
                "instruction": instruction[:50],
            },
        )

        # Try default engine first, then all cached engines
        default_engine = self._get_sub_engine(self._default_mode)
        if await default_engine.steer_agent(session_id, instruction):
            return True

        for engine in self._sub_engines.values():
            if await engine.steer_agent(session_id, instruction):
                return True

        return False

    def _trigger_hook(self, hook_point: HookPoint, data: dict[str, Any]) -> None:
        """Trigger a PACS hook if context is available.

        Args:
            hook_point: The hook point to emit.
            data: Data to include with the hook.
        """
        if self._pacs_context and self._pacs_context.pacs_bus:
            try:
                logger.debug("Hook emitted: %s with data %s", hook_point.value, data)
            except Exception:
                logger.exception("Failed to emit hook %s", hook_point.value)

    async def shutdown(self) -> None:
        """Shut down the engine and all sub-engines."""
        for engine in self._sub_engines.values():
            try:
                await engine.shutdown()
            except Exception as e:
                logger.warning("Failed to shutdown sub-engine: %s", e)

    def get_status(self) -> dict[str, Any]:
        """Get engine status.

        Returns:
            Status dict with engine state.
        """
        return {
            "mode": self.mode.value,
            "active_mode": self._active_mode.value if self._active_mode else None,
            "default_mode": self._default_mode.value,
            "auto_select": self._auto_select_mode,
            "hybrid_depth": self._hybrid_depth,
            "rule_count": len(self._mode_selection_rules),
        }

    def get_active_children(self) -> list[dict[str, Any]]:
        """Get list of active child agents across all sub-engines.

        Returns:
            List of child agent status dicts.
        """
        children: list[dict[str, Any]] = []
        for sub_mode, engine in self._sub_engines.items():
            for child in engine.get_active_children():
                child["sub_engine_mode"] = sub_mode.value
                children.append(child)
        return children
