"""ForkSwarmEngine - Parallel execution facade.

Wraps collaboration/modes/fork_swarm.py with MultiagentEngine interface.
Spawns multiple parallel child agents to execute the same task concurrently.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 2.1
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from typing import Any

from pyclaw.agents.multiagent.engine import MultiagentEngine
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    MultiagentResult,
    SubagentResult,
)
from pyclaw.agents.pacs.types import AgentContext, HookPoint
from pyclaw.agents.subagents.manager import SubagentManager
from pyclaw.agents.subagents.types import SubagentConfig, SubagentState
from pyclaw.agents.subagents.types import SubagentResult as SubagentExecResult

logger = logging.getLogger(__name__)


class ForkSwarmEngine(MultiagentEngine):
    """Facade for parallel task execution (fork/swarm) mode.

    Spawns multiple child agents (forks) to execute the same task in parallel.
    All forks receive identical prompts and context, but operate independently.

    Key features:
    - Creates multiple parallel child agents with fork_count parameter
    - All forks share the same prompt
    - Each fork has independent session_id
    - Results aggregated through MultiagentResult
    - Enforces max_fork_count limit (MAX_CHILDREN=4)
    - PACS hooks at each fork spawn/complete (D-04)
    """

    # Default fork count
    DEFAULT_FORK_COUNT = 3
    # Maximum parallel forks (from CollaborationEngine.MAX_CHILDREN)
    MAX_CHILDREN = 4
    # Maximum nesting depth
    MAX_DEPTH = 5

    def __init__(
        self,
        subagent_manager: SubagentManager | None = None,
        fork_count: int = DEFAULT_FORK_COUNT,
        pacs_context: AgentContext | None = None,
    ) -> None:
        """Initialize the fork/swarm engine.

        Args:
            subagent_manager: Manager for spawning subagents.
            fork_count: Number of parallel forks (default 3, max MAX_CHILDREN).
            pacs_context: PACS context for hook integration.
        """
        self._subagent_manager = subagent_manager
        self._fork_count = min(fork_count, self.MAX_CHILDREN)
        self._pacs_context = pacs_context
        self._active_agents: dict[str, str] = {}  # session_id -> fork_index
        self._current_depth = 0

    @property
    def mode(self) -> CollaborationModeType:
        """Return the collaboration mode.

        Returns:
            CollaborationModeType.FORK_SWARM
        """
        return CollaborationModeType.FORK_SWARM

    @property
    def max_fork_count(self) -> int:
        """Get the maximum allowed fork count.

        Returns:
            Maximum number of parallel forks allowed (MAX_CHILDREN).
        """
        return self.MAX_CHILDREN

    def set_subagent_manager(self, manager: SubagentManager) -> None:
        """Set the subagent manager.

        Args:
            manager: SubagentManager instance.
        """
        self._subagent_manager = manager

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine.

        Args:
            **kwargs: Configuration parameters.
        """
        if "subagent_manager" in kwargs:
            self._subagent_manager = kwargs["subagent_manager"]
        if "fork_count" in kwargs:
            self._fork_count = min(kwargs["fork_count"], self.MAX_CHILDREN)

    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiagentResult:
        """Execute a goal by spawning parallel child agents.

        Triggers PACS hooks at each fork spawn/complete.

        Args:
            goal: The task prompt for all forks.
            context: Optional execution context (may contain fork_count override).
            **kwargs: Additional parameters.

        Returns:
            MultiagentResult with aggregated outputs from all forks.
        """
        self._trigger_hook(HookPoint.SESSION_INIT, {"goal": goal, "fork_count": self._fork_count})

        if not self._subagent_manager:
            logger.warning("No subagent manager configured")
            return MultiagentResult(
                success=False,
                output="",
                error="No subagent manager configured",
                mode=self.mode,
            )

        # Check depth limit
        if self._current_depth >= self.MAX_DEPTH:
            logger.warning("Max depth exceeded: %d >= %d", self._current_depth, self.MAX_DEPTH)
            return MultiagentResult(
                success=False,
                output="",
                error="Maximum nesting depth exceeded",
                mode=self.mode,
            )

        # Get fork count from context or use default
        fork_count = context.get("fork_count", self._fork_count) if context else self._fork_count
        fork_count = min(fork_count, self.MAX_CHILDREN)

        logger.info("Spawning %d parallel forks for goal: %s", fork_count, goal[:50])

        try:
            # Spawn all forks in parallel
            spawn_tasks = [self._spawn_single_fork(goal, i, context or {}) for i in range(fork_count)]

            results = await asyncio.gather(*spawn_tasks, return_exceptions=True)

            # Collect and aggregate results
            subagent_results: list[SubagentResult] = []
            success_count = 0

            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error("Fork %d failed with exception: %s", i, result)
                    subagent_results.append(
                        SubagentResult(
                            session_id=f"fork-{i}-error",
                            success=False,
                            output="",
                            error=str(result),
                        )
                    )
                    self._trigger_hook(
                        HookPoint.SUBAGENT_ERROR,
                        {
                            "fork_index": i,
                            "error": str(result),
                        },
                    )
                elif isinstance(result, SubagentResult):
                    subagent_results.append(result)
                    if result.success:
                        success_count += 1
                        self._trigger_hook(
                            HookPoint.SUBAGENT_COMPLETE,
                            {
                                "fork_index": i,
                                "session_id": result.session_id,
                            },
                        )
                    else:
                        self._trigger_hook(
                            HookPoint.SUBAGENT_ERROR,
                            {
                                "fork_index": i,
                                "error": result.error,
                            },
                        )

            # Determine overall status
            all_success = success_count == fork_count
            partial_success = success_count > 0

            # Aggregate outputs
            successful_outputs = [r.output for r in subagent_results if r.success and r.output]
            aggregate_output = "\n\n---\n\n".join(successful_outputs) if successful_outputs else ""

            self._trigger_hook(
                HookPoint.SESSION_END,
                {
                    "success": all_success,
                    "partial": partial_success,
                    "success_count": success_count,
                    "total_forks": fork_count,
                },
            )

            return MultiagentResult(
                success=all_success or partial_success,  # Success if any fork succeeded
                output=aggregate_output,
                subagent_results=subagent_results,
                mode=self.mode,
                error=None if partial_success else "All forks failed",
            )

        except Exception as e:
            logger.exception("Fork swarm execution failed: %s", e)
            return MultiagentResult(
                success=False,
                output="",
                error=str(e),
                mode=self.mode,
            )

    async def _spawn_single_fork(
        self,
        goal: str,
        fork_index: int,
        context: dict[str, Any],
    ) -> SubagentResult:
        """Spawn and execute a single fork.

        Args:
            goal: The task prompt for this fork.
            fork_index: Index of this fork (for tracking).
            context: Execution context.

        Returns:
            SubagentResult with fork execution outcome.
        """
        session_id = f"fork-{fork_index}-{uuid.uuid4().hex[:8]}"

        self._trigger_hook(
            HookPoint.SUBAGENT_SPAWN,
            {
                "fork_index": fork_index,
                "session_id": session_id,
            },
        )

        try:
            config = SubagentConfig(
                session_id=session_id,
                agent_id=f"fork-{fork_index}",
                prompt=goal,
                current_depth=self._current_depth + 1,
                metadata={"fork_index": fork_index},
                system_prompt=None,
            )

            # Already checked for None above
            assert self._subagent_manager is not None
            result: SubagentExecResult = await self._subagent_manager.spawn(config)
            self._active_agents[session_id] = str(fork_index)

            if result.state == SubagentState.COMPLETED:
                return SubagentResult(
                    session_id=result.meta.session_id or session_id,
                    success=True,
                    output=result.output or "",
                )
            else:
                return SubagentResult(
                    session_id=result.meta.session_id or session_id,
                    success=False,
                    output="",
                    error=result.error or "Unknown error",
                )

        except Exception as e:
            logger.error("Fork %d spawn failed: %s", fork_index, e)
            return SubagentResult(
                session_id=session_id,
                success=False,
                output="",
                error=str(e),
            )

    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new child agent.

        Args:
            agent_type: Type or configuration name for the agent.
            prompt: Task prompt for the agent.
            **kwargs: Additional spawn parameters.

        Returns:
            Session ID of the spawned agent.
        """
        if not self._subagent_manager:
            raise RuntimeError("No subagent manager configured")

        session_id = f"agent-{uuid.uuid4().hex[:12]}"

        self._trigger_hook(
            HookPoint.SUBAGENT_SPAWN,
            {
                "agent_type": agent_type,
                "session_id": session_id,
            },
        )

        config = SubagentConfig(
            session_id=session_id,
            agent_id=agent_type,
            prompt=prompt,
            current_depth=self._current_depth + 1,
            **kwargs,
        )

        result = await self._subagent_manager.spawn(config)
        self._active_agents[session_id] = agent_type

        self._trigger_hook(
            HookPoint.SUBAGENT_COMPLETE,
            {
                "session_id": session_id,
            },
        )

        return result.meta.session_id or session_id

    async def kill_agent(self, session_id: str) -> bool:
        """Terminate a running child agent.

        Args:
            session_id: Session ID of the agent to kill.

        Returns:
            True if killed, False if not found.
        """
        if not self._subagent_manager:
            return False

        result = await self._subagent_manager.kill(session_id)

        if result and session_id in self._active_agents:
            del self._active_agents[session_id]
            self._trigger_hook(
                HookPoint.SESSION_END,
                {
                    "session_id": session_id,
                    "reason": "killed",
                },
            )

        return result

    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send a steering instruction to a running agent.

        Args:
            session_id: Session ID of the agent.
            instruction: The instruction to send.

        Returns:
            True if instruction sent, False if not found.
        """
        if not self._subagent_manager:
            return False

        self._trigger_hook(
            HookPoint.SUBAGENT_PROGRESS,
            {
                "session_id": session_id,
                "instruction": instruction[:50],
            },
        )

        return await self._subagent_manager.steer(session_id, instruction)

    def _trigger_hook(self, hook_point: HookPoint, data: dict[str, Any]) -> None:
        """Trigger a PACS hook if context is available.

        Args:
            hook_point: The hook point to emit.
            data: Data to include with the hook.
        """
        if self._pacs_context and hasattr(self._pacs_context, "emit_hook"):
            try:
                self._pacs_context.emit_hook(hook_point, data)
                logger.debug("Hook emitted: %s with data %s", hook_point.value, data)
            except Exception:
                logger.exception("Failed to emit hook %s", hook_point.value)

    async def shutdown(self) -> None:
        """Shut down the engine and clean up resources."""
        for session_id in list(self._active_agents.keys()):
            try:
                await self.kill_agent(session_id)
            except Exception as e:
                logger.warning("Failed to kill agent %s: %s", session_id, e)

    def get_status(self) -> dict[str, Any]:
        """Get engine status.

        Returns:
            Status dict with engine state.
        """
        return {
            "mode": self.mode.value,
            "fork_count": self._fork_count,
            "max_fork_count": self.MAX_CHILDREN,
            "active_agents": len(self._active_agents),
        }

    def get_active_children(self) -> list[dict[str, Any]]:
        """Get list of active child agents.

        Returns:
            List of child agent status dicts.
        """
        return [{"session_id": sid, "fork_index": fidx} for sid, fidx in self._active_agents.items()]
