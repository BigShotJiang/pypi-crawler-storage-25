"""Multiagent engine implementations.

This module provides concrete implementations of MultiagentEngine ABC.
Each engine implements a different coordination pattern.
"""

from pyclaw.agents.multiagent.engines.centralized import CentralizedEngine
from pyclaw.agents.multiagent.engines.dynamic_decompose import DynamicDecomposeEngine
from pyclaw.agents.multiagent.engines.fork_swarm import ForkSwarmEngine
from pyclaw.agents.multiagent.engines.hybrid import HybridEngine, ModeSelectionRule
from pyclaw.agents.multiagent.engines.pipeline import PipelineEngine

__all__ = [
    "CentralizedEngine",
    "DynamicDecomposeEngine",
    "ForkSwarmEngine",
    "HybridEngine",
    "ModeSelectionRule",
    "PipelineEngine",
]
