"""DynamicDecomposeEngine - Task decomposition facade.

Wraps collaboration/modes/dynamic_decompose.py with MultiagentEngine interface.
Uses TaskDecomposer for intelligent task splitting with fallback strategy.
"""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.multiagent.decomposer import HeuristicDecomposer, LLMDecomposer, TaskDecomposer
from pyclaw.agents.multiagent.engine import MultiagentEngine
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    MultiagentResult,
    SubagentResult,
)
from pyclaw.agents.pacs.types import AgentContext, HookPoint
from pyclaw.agents.subagents.manager import SubagentManager
from pyclaw.agents.subagents.types import SubagentConfig, SubagentState
from pyclaw.agents.subagents.types import SubagentResult as SubagentExecResult

logger = logging.getLogger(__name__)


class DynamicDecomposeEngine(MultiagentEngine):
    """Facade for dynamic task decomposition mode.

    Decomposes complex tasks into smaller subtasks using TaskDecomposer,
    then spawns child agents to execute them in dependency order.

    Key features:
    - Uses HeuristicDecomposer by default (D-03)
    - Falls back to LLMDecomposer for complex tasks
    - Tracks subtask dependencies and execution order
    - Spawns child agents when dependencies are satisfied
    - PACS hooks at spawn/complete/error points (D-04)
    """

    # Thresholds for LLM decomposer fallback (D-03)
    COMPLEXITY_THRESHOLD_CHARS = 500
    COMPLEXITY_THRESHOLD_SUBTASKS = 3

    def __init__(
        self,
        subagent_manager: SubagentManager | None = None,
        decomposer: TaskDecomposer | None = None,
        pacs_context: AgentContext | None = None,
        max_depth: int = 5,
    ) -> None:
        """Initialize the dynamic decompose engine.

        Args:
            subagent_manager: Manager for spawning subagents.
            decomposer: Task decomposer (defaults to HeuristicDecomposer per D-03).
            pacs_context: PACS context for hook integration.
            max_depth: Maximum nesting depth for child agents.
        """
        self._subagent_manager = subagent_manager
        # D-03: Default to HeuristicDecomposer
        self._decomposer = decomposer or HeuristicDecomposer()
        self._llm_decomposer: LLMDecomposer | None = None
        self._pacs_context = pacs_context
        self._max_depth = max_depth
        self._current_depth = 0
        self._active_agents: dict[str, str] = {}  # session_id -> task_id

    @property
    def mode(self) -> CollaborationModeType:
        """Return the collaboration mode.

        Returns:
            CollaborationModeType.DYNAMIC_DECOMPOSE
        """
        return CollaborationModeType.DYNAMIC_DECOMPOSE

    def set_subagent_manager(self, manager: SubagentManager) -> None:
        """Set the subagent manager.

        Args:
            manager: SubagentManager instance.
        """
        self._subagent_manager = manager

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine and internal collaboration engine.

        Args:
            **kwargs: Configuration parameters.
        """
        if "subagent_manager" in kwargs:
            self._subagent_manager = kwargs["subagent_manager"]
        if "decomposer" in kwargs:
            self._decomposer = kwargs["decomposer"]

    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiagentResult:
        """Execute a goal by decomposing into subtasks.

        Triggers PACS hooks at decomposition and subagent lifecycle points.

        Args:
            goal: The high-level goal to decompose and execute.
            context: Optional execution context.
            **kwargs: Additional parameters.

        Returns:
            MultiagentResult with aggregated outputs from all subtasks.
        """
        self._trigger_hook(HookPoint.SESSION_INIT, {"goal": goal})

        if not self._subagent_manager:
            logger.warning("No subagent manager configured")
            return MultiagentResult(
                success=False,
                output="",
                error="No subagent manager configured",
                mode=self.mode,
            )

        # Check depth limit
        if self._current_depth >= self._max_depth:
            logger.warning("Max depth exceeded: %d >= %d", self._current_depth, self._max_depth)
            return MultiagentResult(
                success=False,
                output="",
                error="Maximum nesting depth exceeded",
                mode=self.mode,
            )

        try:
            # Decompose the task
            subtask_definitions = await self._decompose_with_fallback(goal, context or {})

            if not subtask_definitions:
                logger.warning("Task decomposition returned no subtasks")
                return MultiagentResult(
                    success=False,
                    output="",
                    error="Task decomposition returned no subtasks",
                    mode=self.mode,
                )

            logger.info("Decomposed into %d subtasks", len(subtask_definitions))

            # Create subagent configs for each subtask
            subagent_results: list[SubagentResult] = []

            # Simple sequential execution for now (full implementation would use DAG)
            for subtask in subtask_definitions:
                self._trigger_hook(
                    HookPoint.SUBAGENT_SPAWN,
                    {
                        "task_id": subtask.task_id,
                        "description": subtask.description[:100],
                    },
                )

                try:
                    # Spawn and execute subtask
                    config = SubagentConfig(
                        agent_id=subtask.task_id,
                        prompt=subtask.description,
                        current_depth=self._current_depth + 1,
                        system_prompt=None,
                    )

                    result: SubagentExecResult = await self._subagent_manager.spawn(config)

                    session_id = result.meta.session_id or subtask.task_id
                    if result.state == SubagentState.COMPLETED:
                        subagent_results.append(
                            SubagentResult(
                                session_id=session_id,
                                success=True,
                                output=result.output or "",
                            )
                        )
                        self._trigger_hook(
                            HookPoint.SUBAGENT_COMPLETE,
                            {
                                "task_id": subtask.task_id,
                                "success": True,
                            },
                        )
                    else:
                        subagent_results.append(
                            SubagentResult(
                                session_id=session_id,
                                success=False,
                                output="",
                                error=result.error,
                            )
                        )
                        self._trigger_hook(
                            HookPoint.SUBAGENT_ERROR,
                            {
                                "task_id": subtask.task_id,
                                "error": result.error,
                            },
                        )

                except Exception as e:
                    logger.error("Subtask %s failed: %s", subtask.task_id, e)
                    subagent_results.append(
                        SubagentResult(
                            session_id=subtask.task_id,
                            success=False,
                            output="",
                            error=str(e),
                        )
                    )
                    self._trigger_hook(
                        HookPoint.SUBAGENT_ERROR,
                        {
                            "task_id": subtask.task_id,
                            "error": str(e),
                        },
                    )

            # Aggregate results
            all_success = all(r.success for r in subagent_results)
            outputs = [r.output for r in subagent_results if r.output]
            aggregate_output = "\n\n".join(outputs) if outputs else ""

            self._trigger_hook(
                HookPoint.SESSION_END,
                {
                    "success": all_success,
                    "subtask_count": len(subagent_results),
                },
            )

            return MultiagentResult(
                success=all_success,
                output=aggregate_output,
                subagent_results=subagent_results,
                mode=self.mode,
            )

        except Exception as e:
            logger.exception("Dynamic decomposition failed: %s", e)
            return MultiagentResult(
                success=False,
                output="",
                error=str(e),
                mode=self.mode,
            )

    async def _decompose_with_fallback(
        self,
        goal: str,
        context: dict[str, Any],
    ) -> list[Any]:
        """Decompose with LLM fallback for complex tasks (D-03).

        Args:
            goal: The goal to decompose.
            context: Decomposition context.

        Returns:
            List of SubtaskDefinition objects.
        """
        # Try heuristic first (fast, no API cost)
        subtasks = self._decomposer.decompose(goal, context)

        # Check complexity threshold for LLM fallback (D-03)
        is_complex = len(goal) > self.COMPLEXITY_THRESHOLD_CHARS or len(subtasks) > self.COMPLEXITY_THRESHOLD_SUBTASKS

        if is_complex:
            logger.info("Complex task detected, attempting LLM decomposition")
            try:
                # Lazy initialize LLM decomposer
                if not self._llm_decomposer:
                    self._llm_decomposer = LLMDecomposer()

                llm_subtasks = await self._llm_decomposer.adecompose(goal, context)
                if llm_subtasks:
                    return llm_subtasks
            except Exception as e:
                logger.warning("LLM decomposition failed, using heuristic: %s", e)

        return subtasks

    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new child agent.

        Args:
            agent_type: Type or configuration name for the agent.
            prompt: Task prompt for the agent.
            **kwargs: Additional spawn parameters.

        Returns:
            Session ID of the spawned agent.
        """
        if not self._subagent_manager:
            raise RuntimeError("No subagent manager configured")

        self._trigger_hook(
            HookPoint.SUBAGENT_SPAWN,
            {
                "agent_type": agent_type,
                "prompt": prompt[:100],
            },
        )

        config = SubagentConfig(
            agent_id=agent_type,
            prompt=prompt,
            current_depth=self._current_depth + 1,
            **kwargs,
        )

        result = await self._subagent_manager.spawn(config)
        session_id = result.meta.session_id or ""
        self._active_agents[session_id] = agent_type

        return session_id

    async def kill_agent(self, session_id: str) -> bool:
        """Terminate a running child agent.

        Args:
            session_id: Session ID of the agent to kill.

        Returns:
            True if killed, False if not found.
        """
        if not self._subagent_manager:
            return False

        result = await self._subagent_manager.kill(session_id)

        if result and session_id in self._active_agents:
            del self._active_agents[session_id]
            self._trigger_hook(
                HookPoint.SESSION_END,
                {
                    "session_id": session_id,
                    "reason": "killed",
                },
            )

        return result

    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send a steering instruction to a running agent.

        Args:
            session_id: Session ID of the agent.
            instruction: The instruction to send.

        Returns:
            True if instruction sent, False if not found.
        """
        if not self._subagent_manager:
            return False

        self._trigger_hook(
            HookPoint.SUBAGENT_PROGRESS,
            {
                "session_id": session_id,
                "instruction": instruction[:50],
            },
        )

        return await self._subagent_manager.steer(session_id, instruction)

    def _trigger_hook(self, hook_point: HookPoint, data: dict[str, Any]) -> None:
        """Trigger a PACS hook if context is available.

        Args:
            hook_point: The hook point to emit.
            data: Data to include with the hook.
        """
        if self._pacs_context is not None:
            if hasattr(self._pacs_context, "emit_hook"):
                self._pacs_context.emit_hook(hook_point, data)
            try:
                logger.debug("Hook emitted: %s with data %s", hook_point.value, data)
            except Exception:
                logger.exception("Failed to emit hook %s", hook_point.value)

    async def shutdown(self) -> None:
        """Shut down the engine and clean up resources."""
        for session_id in list(self._active_agents.keys()):
            try:
                await self.kill_agent(session_id)
            except Exception as e:
                logger.warning("Failed to kill agent %s: %s", session_id, e)

    def get_status(self) -> dict[str, Any]:
        """Get engine status.

        Returns:
            Status dict with engine state.
        """
        return {
            "mode": self.mode.value,
            "current_depth": self._current_depth,
            "max_depth": self._max_depth,
            "active_agents": len(self._active_agents),
        }

    def get_active_children(self) -> list[dict[str, Any]]:
        """Get list of active child agents.

        Returns:
            List of child agent status dicts.
        """
        return [{"session_id": sid, "agent_type": atype} for sid, atype in self._active_agents.items()]
