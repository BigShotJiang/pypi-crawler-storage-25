"""CentralizedEngine - Coordinator-worker pattern facade.

Wraps orchestration/engines/centralized.py with MultiagentEngine interface
and PACS hook integration.
"""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.multiagent.engine import MultiagentEngine
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    MultiagentResult,
    OrchestrationResult,
    SubagentResult,
)
from pyclaw.agents.orchestration.engines.centralized import (
    CentralizedEngine as LegacyCentralizedEngine,
)
from pyclaw.agents.orchestration.engines.centralized import (
    CentralizedEngineConfig,
)
from pyclaw.agents.pacs.types import AgentContext, HookPoint

logger = logging.getLogger(__name__)


class CentralizedEngine(MultiagentEngine):
    """Facade wrapping orchestration CentralizedEngine.

    Implements Coordinator-Worker pattern:
    - Coordinator decomposes goal into subtasks
    - Workers execute subtasks (potentially in parallel)
    - Results aggregated at coordinator

    This class delegates all operations to the legacy CentralizedEngine
    implementation while providing PACS hook integration points.
    """

    def __init__(
        self,
        spawner: Any = None,
        config: CentralizedEngineConfig | None = None,
        pacs_context: AgentContext | None = None,
    ) -> None:
        """Initialize the centralized engine facade.

        Args:
            spawner: Subagent spawner instance (can be set later).
            config: Engine configuration.
            pacs_context: PACS context for hook integration.
        """
        self._inner = LegacyCentralizedEngine(spawner=spawner, config=config)
        self._pacs_context = pacs_context

    @property
    def mode(self) -> CollaborationModeType:
        """Return the collaboration mode.

        Returns:
            CollaborationModeType.COORDINATOR_WORKER
        """
        return CollaborationModeType.COORDINATOR_WORKER

    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiagentResult:
        """Execute a goal using orchestrated agents.

        Triggers PACS hooks before and after execution.

        Args:
            goal: The high-level goal to accomplish.
            context: Optional execution context.
            **kwargs: Additional parameters.

        Returns:
            MultiagentResult with final output and subagent results.
        """
        # Trigger pre-execution hook
        self._trigger_hook(HookPoint.SESSION_INIT, {"goal": goal})

        if not self._inner._spawner:
            logger.warning("No subagent spawner configured")
            return MultiagentResult(
                success=False,
                output="",
                error="No subagent spawner configured",
                mode=self.mode,
            )

        # Delegate to inner engine
        orch_result = await self._inner.execute(goal, context, **kwargs)

        # Trigger post-execution hook
        self._trigger_hook(
            HookPoint.SESSION_END,
            {
                "success": orch_result.success,
                "duration": orch_result.total_duration,
            },
        )

        # Convert and return
        return self._convert_result(orch_result)

    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new child agent.

        Triggers SUBAGENT_SPAWN hook before spawning.

        Args:
            agent_type: Type or configuration name for the agent.
            prompt: Task prompt for the agent.
            **kwargs: Additional spawn parameters.

        Returns:
            Session ID of the spawned agent.
        """
        self._trigger_hook(
            HookPoint.SUBAGENT_SPAWN,
            {
                "agent_type": agent_type,
                "prompt": prompt[:100],  # Truncate for logging
            },
        )

        session_id = await self._inner.spawn_agent(agent_type, prompt, **kwargs)

        self._trigger_hook(
            HookPoint.SUBAGENT_COMPLETE,
            {
                "session_id": session_id,
            },
        )

        return session_id

    async def kill_agent(self, session_id: str) -> bool:
        """Terminate a running child agent.

        Triggers SESSION_END hook for the agent.

        Args:
            session_id: Session ID of the agent to kill.

        Returns:
            True if killed, False if not found.
        """
        result = await self._inner.kill_agent(session_id)

        if result:
            self._trigger_hook(
                HookPoint.SESSION_END,
                {
                    "session_id": session_id,
                    "reason": "killed",
                },
            )

        return result

    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send a steering instruction to a running agent.

        Triggers SUBAGENT_PROGRESS hook.

        Args:
            session_id: Session ID of the agent.
            instruction: The instruction to send.

        Returns:
            True if instruction sent, False if not found.
        """
        self._trigger_hook(
            HookPoint.SUBAGENT_PROGRESS,
            {
                "session_id": session_id,
                "instruction": instruction[:50],  # Truncate for logging
            },
        )

        return await self._inner.steer_agent(session_id, instruction)

    def _convert_result(self, orch_result: OrchestrationResult) -> MultiagentResult:
        """Convert OrchestrationResult to MultiagentResult.

        Maps all fields from the legacy result type to the unified type.

        Args:
            orch_result: The orchestration result to convert.

        Returns:
            MultiagentResult with mapped fields.
        """
        return MultiagentResult(
            success=orch_result.success,
            output=orch_result.output,
            subagent_results=[
                SubagentResult(
                    session_id=r.session_id,
                    success=r.success,
                    output=r.output,
                    error=r.error,
                    duration_seconds=r.duration_seconds,
                )
                for r in orch_result.subagent_results
            ],
            mode=self.mode,
            total_duration_seconds=orch_result.total_duration,
            error=orch_result.error,
        )

    def _trigger_hook(self, hook_point: HookPoint, data: dict[str, Any]) -> None:
        """Trigger a PACS hook if context is available.

        Args:
            hook_point: The hook point to emit.
            data: Data to include with the hook.
        """
        if self._pacs_context and self._pacs_context.pacs_bus:
            # PACS bus handles hook emission
            try:
                # Note: In full implementation, this would call pacs_bus.emit
                # For now, we just log it
                logger.debug("Hook emitted: %s with data %s", hook_point.value, data)
            except Exception:
                logger.exception("Failed to emit hook %s", hook_point.value)

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine.

        Args:
            **kwargs: Configuration parameters.
        """
        await self._inner.initialize(**kwargs)

    async def shutdown(self) -> None:
        """Shut down the engine and clean up resources."""
        await self._inner.shutdown()

    def get_status(self) -> dict[str, Any]:
        """Get engine status.

        Returns:
            Status dict with engine state.
        """
        status = self._inner.get_status()
        status["mode"] = self.mode.value
        return status

    def get_active_children(self) -> list[dict[str, Any]]:
        """Get list of active child agents.

        Returns:
            List of child agent status dicts.
        """
        # Build list from inner engine's active agents
        return [{"session_id": sid, "agent_type": atype} for sid, atype in self._inner._active_agents.items()]
