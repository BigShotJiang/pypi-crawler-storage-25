"""Heuristic task decomposition.

Pattern-based task decomposition using predefined rules.
Migrated from orchestration/decomposer.py and collaboration/decomposer.py.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

from pyclaw.agents.multiagent.decomposer.base import (
    SubtaskDefinition,
    TaskDecomposer,
    TaskPriority,
)
from pyclaw.agents.multiagent.types import CollaborationModeType


@dataclass
class DecompositionPattern:
    """Predefined decomposition pattern.

    Patterns define common task decomposition templates that can be
    applied based on task characteristics.

    Attributes:
        name: Pattern name
        keywords: Keywords that trigger this pattern (English and Chinese)
        subtasks: Template for subtask generation
    """

    name: str
    keywords: list[str]
    subtasks: list[dict[str, Any]] = field(default_factory=list)


# Predefined patterns (from collaboration/decomposer.py)
PATTERNS: list[DecompositionPattern] = [
    DecompositionPattern(
        name="implement_and_test",
        keywords=[
            "implement",
            "develop",
            "build",
            "create",
            "code",
            "实现",
            "开发",
            "构建",
            "创建",
            "编写代码",
        ],
        subtasks=[
            {"description": "Analyze requirements and create implementation plan", "priority": 90},
            {"description": "Implement the core functionality", "priority": 70, "dependencies": ["${prev}"]},
            {"description": "Write tests for the implementation", "priority": 50, "dependencies": ["${prev}"]},
        ],
    ),
    DecompositionPattern(
        name="analyze_and_fix",
        keywords=[
            "debug",
            "fix",
            "resolve",
            "troubleshoot",
            "bug",
            "调试",
            "修复",
            "解决",
            "排查",
            "bug",
        ],
        subtasks=[
            {"description": "Investigate and identify the root cause", "priority": 90},
            {"description": "Implement the fix", "priority": 70, "dependencies": ["${prev}"]},
            {"description": "Verify the fix resolves the issue", "priority": 50, "dependencies": ["${prev}"]},
        ],
    ),
    DecompositionPattern(
        name="research_and_report",
        keywords=[
            "research",
            "investigate",
            "analyze",
            "explore",
            "研究",
            "调查",
            "分析",
            "探索",
        ],
        subtasks=[
            {"description": "Research and gather information", "priority": 80},
            {"description": "Synthesize findings into a report", "priority": 60, "dependencies": ["${prev}"]},
        ],
    ),
    DecompositionPattern(
        name="explore_and_summarize",
        keywords=[
            "explore",
            "learn",
            "understand",
            "summarize",
            "探索",
            "学习",
            "理解",
            "总结",
        ],
        subtasks=[
            {"description": "Explore the topic thoroughly", "priority": 80},
            {"description": "Summarize key findings", "priority": 60, "dependencies": ["${prev}"]},
        ],
    ),
]


def decompose_task(
    goal: str,
    context: dict[str, Any] | None = None,
) -> list[SubtaskDefinition]:
    """Decompose a task using heuristic rules.

    This function provides backward compatibility with orchestration/decomposer.py.

    Args:
        goal: The high-level goal to decompose.
        context: Optional context for decomposition.

    Returns:
        List of SubtaskDefinition objects.
    """
    context = context or {}
    goal_lower = goal.lower()

    # Find matching pattern
    for pattern in PATTERNS:
        if any(kw in goal_lower for kw in pattern.keywords):
            return _create_subtasks_from_pattern(goal, pattern)

    # Fallback: single task
    return [
        SubtaskDefinition(
            task_id=f"task-{uuid.uuid4().hex[:8]}",
            description=goal,
            assigned_mode=CollaborationModeType.CUSTOM_AGENT,
            priority=TaskPriority.MEDIUM.value,
        )
    ]


def _create_subtasks_from_pattern(
    goal: str,
    pattern: DecompositionPattern,
) -> list[SubtaskDefinition]:
    """Create subtasks from a pattern template."""
    subtasks: list[SubtaskDefinition] = []
    prev_id = ""

    for i, template in enumerate(pattern.subtasks):
        task_id = f"{pattern.name}-{i + 1}-{uuid.uuid4().hex[:6]}"
        dependencies = []

        # Resolve dependency references
        for dep in template.get("dependencies", []):
            if dep == "${prev}":
                if prev_id:
                    dependencies.append(prev_id)

        subtask = SubtaskDefinition(
            task_id=task_id,
            description=template["description"],
            assigned_mode=CollaborationModeType.CUSTOM_AGENT,
            priority=template.get("priority", TaskPriority.MEDIUM.value),
            dependencies=dependencies,
        )
        subtasks.append(subtask)
        prev_id = task_id

    return subtasks


class HeuristicDecomposer(TaskDecomposer):
    """Pattern-based task decomposer.

    Uses predefined patterns for common task types.

    Example:
        >>> decomposer = HeuristicDecomposer()
        >>> subtasks = decomposer.decompose("Implement user authentication")
        >>> print(len(subtasks))  # 3 (plan, implement, test)
    """

    def __init__(
        self,
        patterns: list[DecompositionPattern] | None = None,
        max_subtasks: int = 10,
    ) -> None:
        """Initialize the heuristic decomposer.

        Args:
            patterns: Custom patterns (default: use PATTERNS)
            max_subtasks: Maximum number of subtasks to generate
        """
        self._patterns = patterns or PATTERNS
        self._max_subtasks = max_subtasks

    def decompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition]:
        """Decompose a goal into subtasks using patterns.

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of SubtaskDefinition objects.
        """
        return decompose_task(goal, context)

    async def adecompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition]:
        """Async version of decompose (calls sync version).

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of SubtaskDefinition objects.
        """
        return self.decompose(goal, context)
