"""LLM-powered task decomposition.

Uses LLM for intelligent task decomposition.
Migrated from orchestration/decomposer.py (LLMTaskDecomposer).
"""

from __future__ import annotations

import json
import logging
from typing import Any

from pyclaw.agents.multiagent.decomposer.base import (
    LLMClient,
    SubtaskDefinition,
    TaskDecomposer,
)
from pyclaw.agents.multiagent.decomposer.heuristic import decompose_task

logger = logging.getLogger(__name__)

DECOMPOSITION_PROMPT = """Decompose the following task into subtasks.

Task: {goal}

Context: {context}

Return a JSON array of subtasks with this structure:
[
  {{
    "task_id": "unique-id",
    "description": "What this subtask does",
    "dependencies": ["task-id-of-dependency"],
    "priority": 0-100,
    "assigned_mode": "custom_agent|dynamic_decompose|fork_swarm|coordinator_worker|pipeline"
  }}
]

Rules:
- Each subtask should be atomic and independently executable
- Use dependencies to indicate order (task_id of previous step)
- Higher priority = more important
- Maximum {max_subtasks} subtasks
- Respond with ONLY the JSON array, no other text
"""


class LLMDecomposer(TaskDecomposer):
    """LLM-powered task decomposer.

    Uses an LLM to intelligently decompose complex tasks.

    Example:
        >>> async def my_llm_generate(prompt, **kwargs):
        ...     return '[{"task_id": "t1", "description": "..."}]'
        >>> decomposer = LLMDecomposer(llm_client=my_llm_generate)
        >>> subtasks = await decomposer.adecompose("Build a REST API")
    """

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        max_subtasks: int = 10,
        fallback_to_heuristic: bool = True,
    ) -> None:
        """Initialize the LLM decomposer.

        Args:
            llm_client: LLM client for generation
            max_subtasks: Maximum number of subtasks
            fallback_to_heuristic: Fall back to heuristic on failure
        """
        self._llm_client = llm_client
        self._max_subtasks = max_subtasks
        self._fallback_to_heuristic = fallback_to_heuristic
        self._cache: dict[str, list[SubtaskDefinition]] = {}

    def decompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition]:
        """Sync decomposition (uses heuristic fallback).

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of SubtaskDefinition objects.
        """
        return decompose_task(goal, context)

    async def adecompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition]:
        """Async decompose using LLM.

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of SubtaskDefinition objects.
        """
        if not self._llm_client:
            return self.decompose(goal, context)

        # Check cache
        cache_key = f"{goal}:{hash(str(context))}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        try:
            prompt = DECOMPOSITION_PROMPT.format(
                goal=goal,
                context=json.dumps(context or {}),
                max_subtasks=self._max_subtasks,
            )
            response = await self._llm_client.generate(prompt)
            subtasks = self._parse_response(response)

            if subtasks:
                self._cache[cache_key] = subtasks
                return subtasks

        except Exception as e:
            logger.warning(f"LLM decomposition failed: {e}")

        # Fallback
        if self._fallback_to_heuristic:
            return self.decompose(goal, context)

        return []

    def _parse_response(self, response: str) -> list[SubtaskDefinition]:
        """Parse LLM response into subtasks."""
        # Extract JSON from response
        response = response.strip()
        if response.startswith("```"):
            response = response.split("```")[1]
            if response.startswith("json"):
                response = response[4:]

        try:
            data = json.loads(response)
            if not isinstance(data, list):
                return []

            subtasks: list[SubtaskDefinition] = []
            for item in data[: self._max_subtasks]:
                subtask = SubtaskDefinition(
                    task_id=item.get("task_id", f"task-{len(subtasks)}"),
                    description=item.get("description", ""),
                    dependencies=item.get("dependencies", []),
                    priority=item.get("priority", 50),
                    assigned_mode=item.get("assigned_mode", "custom_agent"),
                )
                subtasks.append(subtask)

            return subtasks

        except json.JSONDecodeError:
            return []
