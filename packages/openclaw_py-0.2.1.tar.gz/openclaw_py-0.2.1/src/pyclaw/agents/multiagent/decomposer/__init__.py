"""Unified task decomposition module.

Consolidates:
- pyclaw.agents.orchestration.decomposer (Subtask, TaskPriority, decompose_task)
- pyclaw.agents.collaboration.decomposer (SubtaskDefinition, TaskDecomposer, DecompositionStrategy)
"""

from pyclaw.agents.multiagent.decomposer.base import (
    DecompositionStrategy,
    SubtaskDefinition,
    TaskDecomposer,
    TaskPriority,
)
from pyclaw.agents.multiagent.decomposer.heuristic import (
    DecompositionPattern,
    HeuristicDecomposer,
    decompose_task,
)
from pyclaw.agents.multiagent.decomposer.llm import LLMDecomposer

__all__ = [
    # Base
    "TaskDecomposer",
    "SubtaskDefinition",
    "DecompositionStrategy",
    "TaskPriority",
    # Heuristic
    "HeuristicDecomposer",
    "DecompositionPattern",
    "decompose_task",
    # LLM
    "LLMDecomposer",
]
