"""TaskDecomposer base class and types.

Merged from:
- orchestration/decomposer.py: TaskPriority, Subtask
- collaboration/decomposer.py: SubtaskDefinition, TaskDecomposer ABC, DecompositionStrategy
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Protocol

from pydantic import BaseModel, Field

from pyclaw.agents.multiagent.types import CollaborationModeType


class TaskPriority(int, Enum):
    """Priority levels for tasks."""

    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4
    BACKGROUND = 5


class DecompositionStrategy(str, Enum):
    """Strategy for task decomposition.

    - HEURISTIC: Rule-based pattern matching (fast, deterministic)
    - LLM: LLM-driven intelligent decomposition (flexible, context-aware)
    - HYBRID: Heuristic first, fallback to LLM on failure
    """

    HEURISTIC = "heuristic"
    LLM = "llm"
    HYBRID = "hybrid"


class SubtaskDefinition(BaseModel):
    """Definition of a decomposed subtask.

    Unified model combining Subtask (orchestration) and SubtaskDefinition (collaboration).

    Attributes:
        task_id: Unique identifier
        description: Human-readable description
        dependencies: List of task IDs this depends on
        assigned_mode: Recommended collaboration mode
        priority: Execution priority (higher = more important)
        estimated_duration_seconds: Estimated execution time
        required_role: Optional role requirement
        context: Additional execution context
    """

    task_id: str = Field(..., description="Unique identifier")
    description: str = Field(..., description="Task description")
    dependencies: list[str] = Field(
        default_factory=list,
        description="List of task IDs this depends on",
    )
    assigned_mode: CollaborationModeType = Field(
        default=CollaborationModeType.CUSTOM_AGENT,
        description="Recommended collaboration mode",
    )
    priority: int = Field(
        default=0,
        ge=0,
        le=100,
        description="Execution priority (higher = more important)",
    )
    estimated_duration_seconds: int = Field(
        default=60,
        ge=1,
        description="Estimated execution time",
    )
    required_role: str | None = Field(
        default=None,
        description="Optional role requirement",
    )
    context: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional execution context",
    )


class TaskDecomposer(ABC):
    """Abstract base class for task decomposition.

    Subclasses implement different decomposition strategies:
    - HeuristicDecomposer: Pattern-based rules
    - LLMDecomposer: AI-driven decomposition
    """

    @abstractmethod
    def decompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition]:
        """Decompose a goal into subtasks.

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of SubtaskDefinition objects.
        """
        ...

    @abstractmethod
    async def adecompose(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition]:
        """Async decompose a goal into subtasks.

        Args:
            goal: The high-level goal to decompose.
            context: Optional context for decomposition.

        Returns:
            List of SubtaskDefinition objects.
        """
        ...


class LLMClient(Protocol):
    """Protocol for LLM client used by LLMDecomposer."""

    async def generate(
        self,
        prompt: str,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> str:
        """Generate a response from the LLM.

        Args:
            prompt: The user prompt.
            system_prompt: Optional system prompt.
            **kwargs: Additional parameters.

        Returns:
            Generated text.
        """
        ...
