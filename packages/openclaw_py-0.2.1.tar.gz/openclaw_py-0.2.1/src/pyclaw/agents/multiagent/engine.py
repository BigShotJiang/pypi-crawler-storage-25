"""MultiagentEngine — abstract base class for all coordination engines.

This module consolidates the engine interfaces from:
- pyclaw.agents.orchestration.engine.OrchestrationEngine
- pyclaw.agents.collaboration.engine.CollaborationEngine

The unified interface supports:
- Mode-based coordination patterns
- Child agent lifecycle (spawn/kill/steer)
- DAG-based task scheduling
- Context sharing between agents
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    ModeSuggestion,
    ModeSwitchResult,
    MultiagentResult,
)


class MultiagentEngine(ABC):
    """Abstract base class for multi-agent coordination engines.

    All coordination engines must implement this interface, supporting:
    - Goal execution with orchestrated agents
    - Child agent lifecycle management
    - Mode switching and suggestions
    """

    @property
    @abstractmethod
    def mode(self) -> CollaborationModeType:
        """The collaboration mode this engine implements."""

    @abstractmethod
    async def execute(
        self,
        goal: str,
        context: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> MultiagentResult:
        """Execute a goal using orchestrated agents.

        This is the main entry point for multi-agent coordination.

        Args:
            goal: The high-level goal to accomplish.
            context: Optional execution context.
            **kwargs: Additional parameters.

        Returns:
            MultiagentResult with final output and subagent results.
        """

    @abstractmethod
    async def spawn_agent(
        self,
        agent_type: str,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Spawn a new child agent.

        Args:
            agent_type: Type or configuration name for the agent.
            prompt: Task prompt for the agent.
            **kwargs: Additional spawn parameters.

        Returns:
            Session ID of the spawned agent.
        """

    @abstractmethod
    async def kill_agent(self, session_id: str) -> bool:
        """Terminate a running child agent.

        Args:
            session_id: Session ID of the agent to kill.

        Returns:
            True if killed, False if not found.
        """

    @abstractmethod
    async def steer_agent(
        self,
        session_id: str,
        instruction: str,
    ) -> bool:
        """Send a steering instruction to a running agent.

        Args:
            session_id: Session ID of the agent.
            instruction: The instruction to send.

        Returns:
            True if instruction sent, False if not found.
        """

    # -- Lifecycle hooks --

    async def initialize(self, **kwargs: Any) -> None:
        """Initialize the engine.

        Args:
            **kwargs: Configuration parameters.
        """
        pass

    async def shutdown(self) -> None:
        """Shut down the engine and clean up resources."""
        pass

    # -- Mode management --

    def switch_mode(
        self,
        mode: CollaborationModeType,
        trigger: str = "explicit",
        context: dict[str, Any] | None = None,
    ) -> ModeSwitchResult:
        """Switch to a different collaboration mode.

        Args:
            mode: The target collaboration mode.
            trigger: How the switch was initiated (explicit/suggested/auto).
            context: Optional context for the mode switch.

        Returns:
            ModeSwitchResult indicating success or failure.
        """
        # Default implementation: engines may override
        return ModeSwitchResult(
            success=False,
            message=f"Mode switching not supported by {self.__class__.__name__}",
        )

    def suggest_mode(self, task_description: str) -> list[ModeSuggestion]:
        """Suggest appropriate collaboration modes for a task.

        Args:
            task_description: Description of the task to analyze.

        Returns:
            List of mode suggestions with confidence scores.
        """
        # Default: return current mode with low confidence
        return [
            ModeSuggestion(
                mode=self.mode,
                confidence=0.5,
                reason=f"Default mode for {self.__class__.__name__}",
            )
        ]

    # -- Status --

    def get_status(self) -> dict[str, Any]:
        """Get engine status.

        Returns:
            Status dict with engine state.
        """
        return {"mode": self.mode.value}

    def get_active_children(self) -> list[dict[str, Any]]:
        """Get list of active child agents.

        Returns:
            List of child agent status dicts.
        """
        return []
