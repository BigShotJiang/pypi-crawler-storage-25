"""Context persistor — saves and restores context across sessions.

Provides:
- Session context persistence
- Cross-session context restoration
- Context checkpointing
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PersistedContext:
    """Structure for persisted context."""

    session_id: str
    created_at: str = ""
    updated_at: str = ""
    messages: list[dict[str, Any]] = field(default_factory=list)
    summary: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "messages": self.messages,
            "summary": self.summary,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PersistedContext:
        """Deserialize from dictionary."""
        return cls(
            session_id=data.get("session_id", ""),
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
            messages=data.get("messages", []),
            summary=data.get("summary", ""),
            metadata=data.get("metadata", {}),
        )


@dataclass
class PersistorConfig:
    """Configuration for context persistence."""

    max_stored_sessions: int = 100
    retention_days: int = 30
    compress_old_sessions: bool = True
    auto_checkpoint: bool = True
    checkpoint_interval_turns: int = 5


class ContextPersistor:
    """Persists and restores session context."""

    def __init__(
        self,
        workspace_dir: Path,
        config: PersistorConfig | None = None,
    ) -> None:
        self._workspace_dir = Path(workspace_dir)
        self._config = config or PersistorConfig()
        self._context_dir = self._workspace_dir / ".claude" / "sessions"
        self._turn_counter = 0

    def _session_path(self, session_id: str) -> Path:
        """Get path for a session context file."""
        return self._context_dir / f"{session_id}.json"

    def _checkpoint_path(self, session_id: str, checkpoint_id: str) -> Path:
        """Get path for a checkpoint file."""
        return self._context_dir / "checkpoints" / f"{session_id}_{checkpoint_id}.json"

    def save_context(
        self,
        session_id: str,
        messages: list[dict[str, Any]],
        summary: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """Save session context to disk.

        Args:
            session_id: Session identifier.
            messages: Message list to save.
            summary: Optional conversation summary.
            metadata: Optional metadata.

        Returns:
            True if save successful.
        """
        self._context_dir.mkdir(parents=True, exist_ok=True)

        path = self._session_path(session_id)
        now = datetime.now().isoformat()

        # Check for existing context
        existing: PersistedContext | None = None
        if path.exists():
            try:
                existing = PersistedContext.from_dict(json.loads(path.read_text()))
            except Exception:
                pass

        context = PersistedContext(
            session_id=session_id,
            created_at=existing.created_at if existing else now,
            updated_at=now,
            messages=messages,
            summary=summary or (existing.summary if existing else ""),
            metadata=metadata or (existing.metadata if existing else {}),
        )

        try:
            path.write_text(json.dumps(context.to_dict(), indent=2))
            logger.debug("Saved context for session %s: %d messages", session_id, len(messages))
            return True
        except Exception as e:
            logger.error("Failed to save context: %s", e)
            return False

    def load_context(self, session_id: str) -> PersistedContext | None:
        """Load session context from disk.

        Args:
            session_id: Session identifier.

        Returns:
            PersistedContext or None if not found.
        """
        path = self._session_path(session_id)

        if not path.exists():
            return None

        try:
            data = json.loads(path.read_text())
            return PersistedContext.from_dict(data)
        except Exception as e:
            logger.warning("Failed to load context for %s: %s", session_id, e)
            return None

    def delete_context(self, session_id: str) -> bool:
        """Delete a session context.

        Args:
            session_id: Session identifier.

        Returns:
            True if deleted.
        """
        path = self._session_path(session_id)
        if path.exists():
            path.unlink()
            logger.debug("Deleted context for session %s", session_id)
            return True
        return False

    def list_sessions(self) -> list[dict[str, Any]]:
        """List all stored sessions.

        Returns:
            List of session info dicts.
        """
        sessions: list[dict[str, Any]] = []

        if not self._context_dir.exists():
            return sessions

        for path in self._context_dir.glob("*.json"):
            try:
                data = json.loads(path.read_text())
                sessions.append(
                    {
                        "session_id": data.get("session_id", path.stem),
                        "created_at": data.get("created_at", ""),
                        "updated_at": data.get("updated_at", ""),
                        "message_count": len(data.get("messages", [])),
                    }
                )
            except Exception:
                continue

        return sorted(sessions, key=lambda s: s.get("updated_at", ""), reverse=True)

    def create_checkpoint(
        self,
        session_id: str,
        checkpoint_id: str,
        messages: list[dict[str, Any]],
    ) -> bool:
        """Create a checkpoint for recovery.

        Args:
            session_id: Session identifier.
            checkpoint_id: Checkpoint identifier.
            messages: Messages to checkpoint.

        Returns:
            True if successful.
        """
        checkpoint_dir = self._context_dir / "checkpoints"
        checkpoint_dir.mkdir(parents=True, exist_ok=True)

        path = self._checkpoint_path(session_id, checkpoint_id)

        try:
            checkpoint = {
                "session_id": session_id,
                "checkpoint_id": checkpoint_id,
                "created_at": datetime.now().isoformat(),
                "messages": messages,
            }
            path.write_text(json.dumps(checkpoint, indent=2))
            logger.debug("Created checkpoint %s for session %s", checkpoint_id, session_id)
            return True
        except Exception as e:
            logger.error("Failed to create checkpoint: %s", e)
            return False

    def restore_checkpoint(
        self,
        session_id: str,
        checkpoint_id: str,
    ) -> list[dict[str, Any]] | None:
        """Restore from a checkpoint.

        Args:
            session_id: Session identifier.
            checkpoint_id: Checkpoint identifier.

        Returns:
            Messages from checkpoint or None.
        """
        path = self._checkpoint_path(session_id, checkpoint_id)

        if not path.exists():
            return None

        try:
            data = json.loads(path.read_text())
            return data.get("messages", [])
        except Exception as e:
            logger.warning("Failed to restore checkpoint: %s", e)
            return None

    def cleanup_old_sessions(self) -> int:
        """Remove sessions older than retention period.

        Returns:
            Number of sessions removed.
        """
        import time

        removed = 0
        cutoff = time.time() - (self._config.retention_days * 86400)

        if not self._context_dir.exists():
            return removed

        for path in self._context_dir.glob("*.json"):
            if path.stat().st_mtime < cutoff:
                path.unlink()
                removed += 1

        # Also cleanup old checkpoints
        checkpoint_dir = self._context_dir / "checkpoints"
        if checkpoint_dir.exists():
            for path in checkpoint_dir.glob("*.json"):
                if path.stat().st_mtime < cutoff:
                    path.unlink()

        logger.info("Cleaned up %d old sessions", removed)
        return removed

    def increment_turn(self) -> bool:
        """Increment turn counter and check if checkpoint needed.

        Returns:
            True if checkpoint should be created.
        """
        self._turn_counter += 1

        if self._config.auto_checkpoint:
            return self._turn_counter % self._config.checkpoint_interval_turns == 0

        return False
