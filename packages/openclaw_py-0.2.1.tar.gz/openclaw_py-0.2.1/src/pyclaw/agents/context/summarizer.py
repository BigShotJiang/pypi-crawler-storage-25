"""Context summarizer — LLM-powered context summarization.

Implements summarization of conversation context:
- Structured summary prompt
- Model selection (default Haiku)
- Key decisions, current state, pending tasks
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SummaryConfig:
    """Configuration for context summarization."""

    model: str = "claude-haiku-4-5-20251001"
    max_summary_tokens: int = 500
    include_key_decisions: bool = True
    include_current_state: bool = True
    include_pending_tasks: bool = True
    include_tool_calls: bool = True


@dataclass
class ContextSummary:
    """Generated context summary."""

    key_decisions: list[str] = field(default_factory=list)
    current_state: str = ""
    pending_tasks: list[str] = field(default_factory=list)
    tool_calls_summary: str = ""
    raw_summary: str = ""
    token_count: int = 0


SUMMARY_PROMPT_TEMPLATE = """Summarize the following conversation history into a concise context summary.

Focus on:
1. **Key Decisions**: Important choices made or conclusions reached
2. **Current State**: Where we are in the conversation/task
3. **Pending Tasks**: What remains to be done
4. **Tool Calls**: Summary of tools used and their results

Format your response as:
## Key Decisions
- [list each decision]

## Current State
[brief description of current state]

## Pending Tasks
- [list remaining tasks]

## Tool Calls Summary
[brief summary of tool usage]

Conversation to summarize:
{conversation}
"""


class ContextSummarizer:
    """Summarizes conversation context using LLM."""

    def __init__(
        self,
        config: SummaryConfig | None = None,
        llm_client: Any = None,
    ) -> None:
        self._config = config or SummaryConfig()
        self._llm_client = llm_client

    @property
    def config(self) -> SummaryConfig:
        return self._config

    def format_messages_for_summary(
        self,
        messages: list[dict[str, Any]],
        max_messages: int = 50,
    ) -> str:
        """Format messages into text for summarization.

        Args:
            messages: Messages to format.
            max_messages: Maximum messages to include.

        Returns:
            Formatted text.
        """
        lines = []
        for _i, msg in enumerate(messages[-max_messages:]):
            role = msg.get("role", "unknown")
            content = msg.get("content", "")

            # Handle different content types
            if isinstance(content, str):
                text = content[:500]  # Truncate long content
            elif isinstance(content, list):
                parts = []
                for part in content:
                    if isinstance(part, dict):
                        if part.get("type") == "text":
                            parts.append(part.get("text", "")[:200])
                        elif part.get("type") == "tool_use":
                            parts.append(f"[Tool: {part.get('name', 'unknown')}]")
                        elif part.get("type") == "tool_result":
                            parts.append("[Tool Result]")
                text = " | ".join(parts)
            else:
                text = str(content)[:200]

            # Include tool calls
            tool_calls = msg.get("tool_calls", [])
            if tool_calls:
                tools = [tc.get("function", {}).get("name", "unknown") for tc in tool_calls]
                text += f" [Called: {', '.join(tools)}]"

            lines.append(f"[{role}]: {text}")

        return "\n".join(lines)

    def build_summary_prompt(
        self,
        messages: list[dict[str, Any]],
    ) -> str:
        """Build the prompt for summary generation.

        Args:
            messages: Messages to summarize.

        Returns:
            Formatted prompt string.
        """
        conversation = self.format_messages_for_summary(messages)
        return SUMMARY_PROMPT_TEMPLATE.format(conversation=conversation)

    async def summarize_async(
        self,
        messages: list[dict[str, Any]],
    ) -> ContextSummary:
        """Generate summary asynchronously.

        Args:
            messages: Messages to summarize.

        Returns:
            ContextSummary.
        """
        if not self._llm_client:
            return self._create_fallback_summary(messages)

        try:
            prompt = self.build_summary_prompt(messages)

            # Call LLM
            response = await self._llm_client.chat.completions.create(
                model=self._config.model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=self._config.max_summary_tokens,
            )

            raw_summary = response.choices[0].message.content or ""
            return self._parse_summary(raw_summary)

        except Exception as e:
            logger.error("Failed to generate summary: %s", e)
            return self._create_fallback_summary(messages)

    def summarize_sync(
        self,
        messages: list[dict[str, Any]],
    ) -> ContextSummary:
        """Generate summary synchronously (fallback).

        Args:
            messages: Messages to summarize.

        Returns:
            ContextSummary.
        """
        return self._create_fallback_summary(messages)

    def _parse_summary(self, raw_summary: str) -> ContextSummary:
        """Parse structured summary from LLM response.

        Args:
            raw_summary: Raw text from LLM.

        Returns:
            Parsed ContextSummary.
        """
        summary = ContextSummary(raw_summary=raw_summary)

        lines = raw_summary.split("\n")
        current_section = ""

        for line in lines:
            line = line.strip()
            if line.startswith("## Key Decisions"):
                current_section = "decisions"
            elif line.startswith("## Current State"):
                current_section = "state"
            elif line.startswith("## Pending Tasks"):
                current_section = "tasks"
            elif line.startswith("## Tool Calls"):
                current_section = "tools"
            elif line.startswith("- "):
                item = line[2:]
                if current_section == "decisions":
                    summary.key_decisions.append(item)
                elif current_section == "tasks":
                    summary.pending_tasks.append(item)
            elif line and current_section == "state":
                summary.current_state += line + " "
            elif line and current_section == "tools":
                summary.tool_calls_summary += line + " "

        summary.token_count = len(raw_summary) // 4  # Rough estimate
        return summary

    def _create_fallback_summary(
        self,
        messages: list[dict[str, Any]],
    ) -> ContextSummary:
        """Create a basic summary without LLM.

        Args:
            messages: Messages to summarize.

        Returns:
            Basic ContextSummary.
        """
        summary = ContextSummary()

        # Count roles
        role_counts: dict[str, int] = {}
        tool_names: set[str] = set()

        for msg in messages:
            role = msg.get("role", "unknown")
            role_counts[role] = role_counts.get(role, 0) + 1

            # Extract tool calls
            tool_calls = msg.get("tool_calls", [])
            for tc in tool_calls:
                name = tc.get("function", {}).get("name", "")
                if name:
                    tool_names.add(name)

        summary.key_decisions = [f"Conversation had {len(messages)} messages"]
        summary.current_state = ", ".join(f"{r}: {c}" for r, c in role_counts.items())
        summary.tool_calls_summary = f"Tools used: {', '.join(tool_names) or 'none'}"
        summary.token_count = 50  # Rough estimate

        return summary


async def generate_summary(
    messages: list[dict[str, Any]],
    config: SummaryConfig | None = None,
    llm_client: Any = None,
) -> ContextSummary:
    """Generate a context summary.

    Convenience function for summary generation.

    Args:
        messages: Messages to summarize.
        config: Summary configuration.
        llm_client: LLM client for generation.

    Returns:
        ContextSummary.
    """
    summarizer = ContextSummarizer(config, llm_client)
    return await summarizer.summarize_async(messages)
