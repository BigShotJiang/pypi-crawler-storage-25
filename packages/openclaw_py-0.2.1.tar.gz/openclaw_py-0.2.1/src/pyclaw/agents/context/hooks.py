"""Context hooks — pre/post reasoning hooks for context management.

Provides hook functions that can be registered with the hook system
for automatic context management.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


async def pre_reasoning_hook(
    event: Any,
    context_manager: Any | None = None,
) -> dict[str, Any] | None:
    """Hook handler for pre-reasoning context management.

    This hook:
    1. Injects memory context
    2. Compacts if needed
    3. Returns modified messages

    Args:
        event: Hook event with messages and context.
        context_manager: Optional pre-configured ContextManager.

    Returns:
        Optional modifications to apply to messages.
    """
    messages = getattr(event, "messages", None) or event.get("messages") if isinstance(event, dict) else None
    if not messages:
        return None

    # Get workspace dir from event context
    context = getattr(event, "context", None) or event.get("context", {}) if isinstance(event, dict) else {}

    workspace_dir = context.get("workspace_dir")
    if not workspace_dir:
        return None

    session_id = context.get("session_id")

    # Create or use context manager
    if context_manager is None:
        from pyclaw.agents.context.manager import ContextManager

        memory_dir = context.get("memory_dir")
        context_manager = ContextManager(
            workspace_dir=Path(workspace_dir),
            memory_dir=memory_dir,
        )

    # Process messages
    processed = context_manager.preprocess(
        messages,
        session_id=session_id,
        inject_context=True,
        compact=True,
    )

    if len(processed) != len(messages):
        return {"messages": processed}

    # Check if content was modified
    for _i, (orig, proc) in enumerate(zip(messages, processed, strict=False)):
        if orig != proc:
            return {"messages": processed}

    return None


async def post_turn_hook(
    event: Any,
    context_manager: Any | None = None,
) -> None:
    """Hook handler for post-turn context persistence.

    This hook:
    1. Saves context to disk
    2. Creates checkpoint if needed

    Args:
        event: Hook event with messages and session info.
        context_manager: Optional pre-configured ContextManager.
    """
    messages = getattr(event, "messages", None) or event.get("messages") if isinstance(event, dict) else None
    if not messages:
        return

    context = getattr(event, "context", None) or event.get("context", {}) if isinstance(event, dict) else {}

    workspace_dir = context.get("workspace_dir")
    session_id = context.get("session_id")

    if not workspace_dir or not session_id:
        return

    # Create or use context manager
    if context_manager is None:
        from pyclaw.agents.context.manager import ContextManager

        memory_dir = context.get("memory_dir")
        context_manager = ContextManager(
            workspace_dir=Path(workspace_dir),
            memory_dir=memory_dir,
        )

    # Postprocess (save and checkpoint)
    context_manager.postprocess(
        messages,
        session_id=session_id,
        persist=True,
        checkpoint=True,
    )


def register_context_hooks(
    hook_registry: Any,
    workspace_dir: Path,
    memory_dir: Any | None = None,
) -> Any:
    """Register context hooks with the hook system.

    Args:
        hook_registry: The hook registry to register with.
        workspace_dir: Workspace directory.
        memory_dir: Optional memory directory.

    Returns:
        ContextManager instance.
    """
    from pyclaw.agents.context.manager import ContextManager

    # Create context manager
    context_manager = ContextManager(
        workspace_dir=workspace_dir,
        memory_dir=memory_dir,
    )

    # Register hooks
    if hasattr(hook_registry, "register"):
        hook_registry.register(
            "pre_reasoning",
            lambda e: pre_reasoning_hook(e, context_manager),
        )
        hook_registry.register(
            "post_turn",
            lambda e: post_turn_hook(e, context_manager),
        )
    elif hasattr(hook_registry, "on"):
        hook_registry.on("pre_reasoning")(lambda e: pre_reasoning_hook(e, context_manager))
        hook_registry.on("post_turn")(lambda e: post_turn_hook(e, context_manager))

    logger.info("Registered context hooks for %s", workspace_dir)
    return context_manager


# Convenience functions for manual hook setup


def create_pre_reasoning_hook(
    workspace_dir: Path,
    memory_dir: Any | None = None,
) -> Any:
    """Create a pre-reasoning hook with configured context manager.

    Args:
        workspace_dir: Workspace directory.
        memory_dir: Optional memory directory.

    Returns:
        Async hook function.
    """
    from pyclaw.agents.context.manager import ContextManager

    context_manager = ContextManager(
        workspace_dir=workspace_dir,
        memory_dir=memory_dir,
    )

    async def hook(event: Any) -> dict[str, Any] | None:
        return await pre_reasoning_hook(event, context_manager)

    return hook


def create_post_turn_hook(
    workspace_dir: Path,
    memory_dir: Any | None = None,
) -> Any:
    """Create a post-turn hook with configured context manager.

    Args:
        workspace_dir: Workspace directory.
        memory_dir: Optional memory directory.

    Returns:
        Async hook function.
    """
    from pyclaw.agents.context.manager import ContextManager

    context_manager = ContextManager(
        workspace_dir=workspace_dir,
        memory_dir=memory_dir,
    )

    async def hook(event: Any) -> None:
        await post_turn_hook(event, context_manager)

    return hook


# -------------------------------------------------------------------------
# Active Memory Hook
# -------------------------------------------------------------------------


async def active_memory_pre_reasoning_hook(
    event: Any,
    recaller: Any | None = None,
) -> dict[str, Any] | None:
    """Hook handler for Active Memory context injection.

    This hook:
    1. Queries ActiveMemoryRecaller for relevant memories
    2. Injects context as system message if found

    Args:
        event: Hook event with messages and context.
        recaller: Optional pre-configured ActiveMemoryRecaller.

    Returns:
        Optional modifications with injected context message.
    """
    messages = getattr(event, "messages", None) or event.get("messages") if isinstance(event, dict) else None
    if not messages:
        return None

    context = getattr(event, "context", None) or event.get("context", {}) if isinstance(event, dict) else {}

    workspace_dir = context.get("workspace_dir")
    session_id = context.get("session_id")

    if not workspace_dir:
        return None

    # Get or create recaller
    if recaller is None:
        from pyclaw.memory.active_recall import ActiveMemoryRecaller
        from pyclaw.memory.manager import MemoryManager
        from pyclaw.memory.recall_types import ActiveRecallConfig

        memory_manager = MemoryManager(Path(workspace_dir))
        memory_manager.open()

        config = ActiveRecallConfig()
        recaller = ActiveMemoryRecaller(
            memory_manager=memory_manager,
            config=config,
            workspace_dir=Path(workspace_dir),
        )

    # Build query from latest message
    latest_message = ""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str) and content:
                latest_message = content
                break

    if not latest_message:
        return None

    # Recall memories
    try:
        result = await recaller.recall(
            latest_message=latest_message,
            recent_turns=messages[-10:],  # Last 10 messages for context
            session_key=session_id,
        )

        if result.is_success and result.summary:
            context_msg = recaller.build_context_message(result)
            if context_msg:
                # Insert as system message
                return {"messages": [context_msg] + messages}
    except Exception as e:
        logger.warning("Active Memory recall failed: %s", e)

    return None


def create_active_memory_hook(
    workspace_dir: Path,
    config: Any | None = None,
) -> Any:
    """Create an Active Memory hook with configured recaller.

    Args:
        workspace_dir: Workspace directory.
        config: Optional ActiveRecallConfig.

    Returns:
        Async hook function.
    """
    from pyclaw.memory.active_recall import ActiveMemoryRecaller
    from pyclaw.memory.manager import MemoryManager
    from pyclaw.memory.recall_types import ActiveRecallConfig

    memory_manager = MemoryManager(workspace_dir)
    memory_manager.open()

    if config is None:
        config = ActiveRecallConfig()

    recaller = ActiveMemoryRecaller(
        memory_manager=memory_manager,
        config=config,
        workspace_dir=workspace_dir,
    )

    async def hook(event: Any) -> dict[str, Any] | None:
        return await active_memory_pre_reasoning_hook(event, recaller)

    return hook


def register_active_memory_hooks(
    hook_registry: Any,
    workspace_dir: Path,
    config: Any | None = None,
) -> Any:
    """Register Active Memory hooks with the hook system.

    Args:
        hook_registry: The hook registry to register with.
        workspace_dir: Workspace directory.
        config: Optional ActiveRecallConfig.

    Returns:
        ActiveMemoryRecaller instance.
    """
    hook = create_active_memory_hook(workspace_dir, config)

    if hasattr(hook_registry, "register"):
        hook_registry.register("pre_reasoning", hook)
    elif hasattr(hook_registry, "on"):
        hook_registry.on("pre_reasoning")(hook)

    logger.info("Registered Active Memory hooks for %s", workspace_dir)
    return hook
