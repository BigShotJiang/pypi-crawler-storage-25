"""Context policy and message context definitions.

This module defines:
- CompressionStrategy: Enum for compression strategy types
- CacheStrategy: Enum for caching strategies
- MessageContext: Dataclass for individual message representation

Note: ContextPolicy is defined in pyclaw.agents.definition to avoid
circular imports with AgentDefinition.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class CompressionStrategyType(str, Enum):
    """Compression strategy types for context management.

    Determines how the context engine handles token limits when
    approaching the model's context window.
    """

    TRUNCATE = "truncate"  # Simple truncation of old messages
    SUMMARIZE = "summarize"  # Summarize old messages into a summary
    DAG = "dag"  # DAG-based compression (preserves relationships)


class CacheStrategy(str, Enum):
    """Caching strategy for context messages.

    Controls which messages are eligible for caching with the
    model provider's prompt caching feature.
    """

    NONE = "none"  # No caching
    SYSTEM = "system"  # Cache system messages only
    CONVERSATION = "conversation"  # Cache system + recent messages
    FULL = "full"  # Cache everything possible


@dataclass
class MessageContext:
    """Individual message context representation.

    Represents a single message in the conversation with its metadata.
    Used by context engines for tracking message relationships and
    converting to API format.

    Attributes:
        role: Message role (user, assistant, system, tool).
        content: Message content (text or structured content).
        timestamp: When the message was created.
        tool_call_id: For tool messages, the ID of the tool call.
        tool_calls: For assistant messages, list of tool calls made.
        parent_id: Parent message ID (for DAG structure support).
        message_id: Unique identifier for this message.
        metadata: Additional metadata (token count, etc.).
    """

    role: str  # user, assistant, system, tool
    content: str | list[dict[str, Any]]
    timestamp: datetime
    tool_call_id: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    parent_id: str | None = None  # Parent message ID (for DAG structure)
    message_id: str | None = None  # Unique message identifier
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_api_message(self) -> dict[str, Any]:
        """Convert to OpenAI API format message.

        Returns:
            Dict in OpenAI message format.
        """
        msg: dict[str, Any] = {"role": self.role}

        # Handle content
        if self.content:
            msg["content"] = self.content

        # Add tool_call_id for tool messages
        if self.tool_call_id:
            msg["tool_call_id"] = self.tool_call_id

        # Add tool_calls for assistant messages
        if self.tool_calls:
            msg["tool_calls"] = self.tool_calls

        return msg

    def to_anthropic_message(self) -> dict[str, Any]:
        """Convert to Anthropic API format message.

        Returns:
            Dict in Anthropic message format.
        """
        msg: dict[str, Any] = {"role": self.role}

        # Anthropic uses 'content' as a list of content blocks
        if isinstance(self.content, str):
            msg["content"] = [{"type": "text", "text": self.content}]
        elif isinstance(self.content, list):
            msg["content"] = self.content

        # Tool use in Anthropic format
        if self.tool_calls:
            msg["content"] = msg.get("content", [])
            for tc in self.tool_calls:
                msg["content"].append(
                    {
                        "type": "tool_use",
                        "id": tc.get("id", ""),
                        "name": tc.get("function", {}).get("name", ""),
                        "input": tc.get("function", {}).get("arguments", {}),
                    }
                )

        return msg

    @property
    def is_system(self) -> bool:
        """Check if this is a system message."""
        return self.role == "system"

    @property
    def is_user(self) -> bool:
        """Check if this is a user message."""
        return self.role == "user"

    @property
    def is_assistant(self) -> bool:
        """Check if this is an assistant message."""
        return self.role == "assistant"

    @property
    def is_tool(self) -> bool:
        """Check if this is a tool message."""
        return self.role == "tool"

    @property
    def has_tool_calls(self) -> bool:
        """Check if this message contains tool calls."""
        return bool(self.tool_calls)

    @classmethod
    def from_api_message(
        cls,
        message: dict[str, Any],
        timestamp: datetime | None = None,
        message_id: str | None = None,
    ) -> MessageContext:
        """Create MessageContext from OpenAI API format message.

        Args:
            message: Message dict in OpenAI format.
            timestamp: Optional timestamp (defaults to now).
            message_id: Optional message ID.

        Returns:
            MessageContext instance.
        """
        return cls(
            role=message.get("role", "user"),
            content=message.get("content", ""),
            timestamp=timestamp or datetime.now(),
            tool_call_id=message.get("tool_call_id"),
            tool_calls=message.get("tool_calls"),
            message_id=message_id,
        )

    def get_token_estimate(self, chars_per_token: int = 4) -> int:
        """Get estimated token count for this message.

        Args:
            chars_per_token: Characters per token ratio.

        Returns:
            Estimated token count.
        """
        # Estimate from content
        content_text = ""
        if isinstance(self.content, str):
            content_text = self.content
        elif isinstance(self.content, list):
            for block in self.content:
                if isinstance(block, dict):
                    if "text" in block:
                        content_text += block["text"]
                    elif "content" in block:
                        content_text += str(block["content"])

        base_tokens = len(content_text) // chars_per_token if content_text else 0

        # Add tokens for tool calls
        if self.tool_calls:
            import json

            tool_json = json.dumps(self.tool_calls)
            base_tokens += len(tool_json) // chars_per_token

        # Add overhead for message structure (role, etc.)
        return base_tokens + 4
