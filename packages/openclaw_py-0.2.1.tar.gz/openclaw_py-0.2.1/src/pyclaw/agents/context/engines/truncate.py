"""Truncate engine — simple message truncation for context management.

This engine implements a basic truncation strategy that removes older
messages when approaching token limits while preserving system messages
and recent context.
"""

from __future__ import annotations

import logging
from typing import Any

from pyclaw.agents.context.engine import ContextEngine
from pyclaw.agents.context.token_estimation import TokenEstimator

logger = logging.getLogger(__name__)


class TruncateEngine(ContextEngine):
    """Simple truncation-based context engine.

    This engine removes older messages when the context approaches
    the token limit. It preserves:
    - All system messages
    - The last N messages (tail protection)

    Example:
        engine = TruncateEngine()
        engine.update_model("gpt-4", 128000)
        engine.update_from_response({"prompt_tokens": 100000})

        if engine.should_compress():
            messages = engine.compress(messages)
    """

    @property
    def name(self) -> str:
        """Return engine name."""
        return "truncate"

    def __init__(
        self,
        threshold_percent: float = 0.75,
        protect_first_n: int = 3,
        protect_last_n: int = 6,
    ) -> None:
        """Initialize truncate engine.

        Args:
            threshold_percent: Percentage of context_length to trigger compression.
            protect_first_n: Number of leading messages to preserve (system messages).
            protect_last_n: Number of trailing messages to preserve (recent context).
        """
        self.threshold_percent = threshold_percent
        self.protect_first_n = protect_first_n
        self.protect_last_n = protect_last_n

        # Token state
        self.last_prompt_tokens = 0
        self.last_completion_tokens = 0
        self.last_total_tokens = 0
        self.threshold_tokens = 0
        self.context_length = 0
        self.compression_count = 0

        # Token estimator
        self._estimator = TokenEstimator()

    def update_from_response(self, usage: dict[str, Any]) -> None:
        """Update token tracking from API response.

        Args:
            usage: Usage dict from API response with prompt_tokens, completion_tokens.
        """
        self.last_prompt_tokens = usage.get("prompt_tokens", 0)
        self.last_completion_tokens = usage.get("completion_tokens", 0)
        self.last_total_tokens = self.last_prompt_tokens + self.last_completion_tokens

    def should_compress(self, prompt_tokens: int | None = None) -> bool:
        """Check if compression is needed.

        Args:
            prompt_tokens: Current prompt tokens (uses tracked value if not provided).

        Returns:
            True if prompt tokens exceed threshold.
        """
        tokens = prompt_tokens or self.last_prompt_tokens
        if self.threshold_tokens <= 0:
            return False
        return tokens > self.threshold_tokens

    def compress(
        self,
        messages: list[dict[str, Any]],
        current_tokens: int | None = None,
    ) -> list[dict[str, Any]]:
        """Compress messages by truncating older non-essential messages.

        Strategy:
        1. Preserve all system messages
        2. Preserve recent messages (protect_last_n)
        3. Remove older messages between system and recent

        Args:
            messages: Full message list.
            current_tokens: Current token count (optional, estimated if not provided).

        Returns:
            Truncated message list.
        """
        if len(messages) <= self.protect_first_n + self.protect_last_n:
            # Not enough messages to truncate
            return messages

        # Identify system messages at the start
        system_messages: list[dict[str, Any]] = []
        conversation_start = 0

        for i, msg in enumerate(messages):
            if msg.get("role") == "system":
                system_messages.append(msg)
                conversation_start = i + 1
            else:
                break

        # Get recent messages (tail)
        recent_messages = messages[-self.protect_last_n :]

        # Get middle messages that can be truncated
        middle_messages = messages[conversation_start : -self.protect_last_n or None]

        if not middle_messages:
            # Nothing to truncate
            return messages

        # Calculate how many middle messages to keep
        current_tokens = current_tokens or self._estimator.estimate_messages(messages)
        target_tokens = int(self.threshold_tokens * 0.6)  # Compress to 60% of threshold

        if current_tokens <= target_tokens:
            return messages

        # Calculate tokens per message (rough estimate)
        middle_tokens = self._estimator.estimate_messages(middle_messages)
        if middle_tokens == 0:
            return messages

        tokens_per_msg = middle_tokens / len(middle_messages)
        tokens_to_remove = current_tokens - target_tokens
        msgs_to_remove = int(tokens_to_remove / tokens_per_msg) if tokens_per_msg > 0 else 0

        # Ensure we don't remove all middle messages
        msgs_to_remove = min(msgs_to_remove, len(middle_messages) - 2)
        msgs_to_remove = max(0, msgs_to_remove)

        if msgs_to_remove == 0:
            return messages

        # Truncate from the beginning of middle messages (oldest first)
        truncated_middle = middle_messages[msgs_to_remove:]

        # Build result
        result = [*system_messages, *truncated_middle, *recent_messages]

        self.compression_count += 1

        new_tokens = self._estimator.estimate_messages(result)
        logger.info(
            "Truncated messages: %d -> %d (tokens: %d -> %d)",
            len(messages),
            len(result),
            current_tokens,
            new_tokens,
        )

        return result

    def should_compress_preflight(self, messages: list[dict[str, Any]]) -> bool:
        """Quick check before API call using token estimation.

        Args:
            messages: Current message list.

        Returns:
            True if estimated tokens exceed threshold.
        """
        if self.threshold_tokens <= 0:
            return False

        estimated = self._estimator.estimate_messages(messages)
        return estimated > self.threshold_tokens

    def on_session_reset(self) -> None:
        """Reset session state."""
        self.last_prompt_tokens = 0
        self.last_completion_tokens = 0
        self.last_total_tokens = 0
        self.compression_count = 0

    def update_model(
        self,
        model: str,
        context_length: int,
        base_url: str = "",
        api_key: str = "",
        provider: str = "",
    ) -> None:
        """Update model settings.

        Args:
            model: Model name.
            context_length: Maximum context length.
            base_url: API base URL (unused).
            api_key: API key (unused).
            provider: Provider name (unused).
        """
        self.context_length = context_length
        self.threshold_tokens = int(context_length * self.threshold_percent)
