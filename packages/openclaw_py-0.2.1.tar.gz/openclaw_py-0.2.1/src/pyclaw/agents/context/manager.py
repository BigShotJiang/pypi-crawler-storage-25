"""Context manager — coordinates all context handling components.

Orchestrates:
- ContextCompactor: Truncation and summarization
- ContextInjector: Memory context injection
- ContextPersistor: Cross-session persistence
- ContextEngine: SummarizeEngine for intelligent compression
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pyclaw.agents.context.compaction import (
    CompactionConfig,
    ContextCompactor,
)
from pyclaw.agents.context.engine import ContextEngine
from pyclaw.agents.context.injector import (
    ContextInjector,
    InjectionConfig,
)
from pyclaw.agents.context.persistor import (
    ContextPersistor,
    PersistedContext,
    PersistorConfig,
)

logger = logging.getLogger(__name__)


@dataclass
class ContextManagerConfig:
    """Combined configuration for ContextManager."""

    compaction: CompactionConfig = None  # type: ignore
    injection: InjectionConfig = None  # type: ignore
    persistor: PersistorConfig = None  # type: ignore
    use_engine: bool = True  # Use SummarizeEngine instead of basic compaction

    def __post_init__(self) -> None:
        if self.compaction is None:
            self.compaction = CompactionConfig()
        if self.injection is None:
            self.injection = InjectionConfig()
        if self.persistor is None:
            self.persistor = PersistorConfig()


class ContextManager:
    """Unified context management for agent sessions.

    Usage:
        manager = ContextManager(workspace_dir=Path("./workspace"))

        # Before reasoning
        messages = manager.preprocess(messages, session_id="session-123")

        # After turn
        manager.postprocess(messages, session_id="session-123")

        # Restore previous session
        context = manager.restore_session("session-123")
    """

    def __init__(
        self,
        workspace_dir: Path,
        config: ContextManagerConfig | None = None,
        memory_dir: Any | None = None,
        context_engine: ContextEngine | None = None,
    ) -> None:
        self._workspace_dir = Path(workspace_dir)
        self._config = config or ContextManagerConfig()
        self._memory_dir = memory_dir

        # Initialize components
        self._compactor = ContextCompactor(
            config=self._config.compaction,
            workspace_dir=self._workspace_dir,
        )
        self._injector = ContextInjector(
            config=self._config.injection,
            memory_dir=self._memory_dir,
        )
        self._persistor = ContextPersistor(
            workspace_dir=self._workspace_dir,
            config=self._config.persistor,
        )

        # Context engine (optional, uses registry if not provided)
        self._engine: ContextEngine | None = context_engine
        self._engine_initialized = False

        # Hook callbacks
        self._pre_hooks: list[Callable[..., Any]] = []
        self._post_hooks: list[Callable[..., Any]] = []

    def _get_engine(self) -> ContextEngine | None:
        """Get or create context engine from registry."""
        if self._engine is not None:
            return self._engine

        if not self._config.use_engine:
            return None

        # Lazy load from capability registry
        try:
            from pyclaw.agents.context.capability import get_context_engine

            engine = get_context_engine()
            if engine is not None:
                self._engine = engine
                return engine
        except Exception as e:
            logger.warning("Failed to get context engine from registry: %s", e)

        return None

    # -------------------------------------------------------------------------
    # Properties
    # -------------------------------------------------------------------------

    @property
    def compactor(self) -> ContextCompactor:
        return self._compactor

    @property
    def injector(self) -> ContextInjector:
        return self._injector

    @property
    def persistor(self) -> ContextPersistor:
        return self._persistor

    @property
    def engine(self) -> ContextEngine | None:
        return self._get_engine()

    # -------------------------------------------------------------------------
    # Hook Registration
    # -------------------------------------------------------------------------

    def register_pre_hook(self, hook: Callable[..., Any]) -> None:
        """Register a pre-processing hook.

        Hooks are called with (messages, session_id) and can return modified messages.
        """
        self._pre_hooks.append(hook)

    def register_post_hook(self, hook: Callable[..., Any]) -> None:
        """Register a post-processing hook."""
        self._post_hooks.append(hook)

    # -------------------------------------------------------------------------
    # Main Processing Methods
    # -------------------------------------------------------------------------

    def preprocess(
        self,
        messages: list[dict[str, Any]],
        session_id: str | None = None,
        *,
        inject_context: bool = True,
        compact: bool = True,
    ) -> list[dict[str, Any]]:
        """Preprocess messages before sending to LLM.

        Steps:
        1. Run pre-hooks
        2. Inject memory context
        3. Compact if needed (using engine or compactor)

        Args:
            messages: Current message list.
            session_id: Optional session identifier.
            inject_context: Whether to inject memory context.
            compact: Whether to compact if needed.

        Returns:
            Processed message list.
        """
        # Make a copy
        processed = list(messages)

        # Run pre-hooks
        for hook in self._pre_hooks:
            try:
                result = hook(processed, session_id)
                if result is not None:
                    processed = result
            except Exception as e:
                logger.warning("Pre-hook failed: %s", e)

        # Inject context
        if inject_context:
            injection_result = self._injector.inject_into_messages(processed)
            if injection_result.injected:
                logger.debug(
                    "Injected context: %d chars, sections: %s",
                    injection_result.context_length,
                    injection_result.sections_injected,
                )

        # Compact if needed
        if compact:
            processed = self._compact_messages(processed, session_id)

        return processed

    def _compact_messages(
        self,
        messages: list[dict[str, Any]],
        session_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Compact messages using engine or fallback compactor.

        Priority:
        1. Use ContextEngine if available and should_compress
        2. Fall back to ContextCompactor

        Args:
            messages: Message list to compact.
            session_id: Optional session identifier.

        Returns:
            Compacted message list.
        """
        engine = self._get_engine()

        if engine is not None:
            # Use engine for compression decision
            if engine.should_compress_preflight(messages):
                logger.info("Context engine recommends compression")
                compacted = engine.compress(messages)
                if len(compacted) < len(messages):
                    logger.info(
                        "Engine compressed: %d -> %d messages",
                        len(messages),
                        len(compacted),
                    )
                return compacted

            # Engine available but no compression needed
            return messages

        # Fallback to legacy compactor
        if self._compactor.check_needs_compaction(messages):
            compaction_result = self._compactor.compact_messages(messages)
            processed = messages[: compaction_result.compacted_messages]
            logger.info(
                "Compacted context: %d -> %d messages, saved %d tokens",
                compaction_result.original_messages,
                compaction_result.compacted_messages,
                compaction_result.tokens_saved,
            )
            return processed

        return messages

    def postprocess(
        self,
        messages: list[dict[str, Any]],
        session_id: str | None = None,
        *,
        persist: bool = True,
        checkpoint: bool = True,
    ) -> None:
        """Postprocess after a reasoning turn.

        Steps:
        1. Save context
        2. Create checkpoint if needed
        3. Run post-hooks

        Args:
            messages: Current message list.
            session_id: Session identifier.
            persist: Whether to save context.
            checkpoint: Whether to create checkpoint.
        """
        if not session_id:
            return

        # Persist context
        if persist:
            self._persistor.save_context(session_id, messages)

        # Checkpoint if needed
        if checkpoint and self._persistor.increment_turn():
            self._persistor.create_checkpoint(
                session_id,
                f"turn_{self._persistor._turn_counter}",
                messages,
            )

        # Run post-hooks
        for hook in self._post_hooks:
            try:
                hook(messages, session_id)
            except Exception as e:
                logger.warning("Post-hook failed: %s", e)

    # -------------------------------------------------------------------------
    # Session Management
    # -------------------------------------------------------------------------

    def on_session_start(
        self,
        session_id: str,
        model: str = "",
        context_length: int = 128000,
        **kwargs: Any,
    ) -> None:
        """Initialize session state.

        Args:
            session_id: Session identifier.
            model: Model name.
            context_length: Model context length.
            **kwargs: Additional context.
        """
        engine = self._get_engine()
        if engine is not None:
            engine.on_session_start(session_id, **kwargs)
            if model and context_length:
                engine.update_model(model, context_length)
        self._engine_initialized = True

    def on_session_end(
        self,
        session_id: str,
        messages: list[dict[str, Any]],
    ) -> None:
        """Clean up session state.

        Args:
            session_id: Session identifier.
            messages: Final message list.
        """
        engine = self._get_engine()
        if engine is not None:
            engine.on_session_end(session_id, messages)
        self._engine_initialized = False

    def update_from_response(self, usage: dict[str, Any]) -> None:
        """Update token tracking from API response.

        Args:
            usage: Usage dict from API response.
        """
        engine = self._get_engine()
        if engine is not None:
            engine.update_from_response(usage)

    def restore_session(self, session_id: str) -> PersistedContext | None:
        """Restore a previous session's context.

        Args:
            session_id: Session identifier.

        Returns:
            PersistedContext or None.
        """
        return self._persistor.load_context(session_id)

    def save_session(
        self,
        session_id: str,
        messages: list[dict[str, Any]],
        summary: str | None = None,
    ) -> bool:
        """Save session context.

        Args:
            session_id: Session identifier.
            messages: Message list.
            summary: Optional summary.

        Returns:
            True if successful.
        """
        return self._persistor.save_context(session_id, messages, summary)

    def delete_session(self, session_id: str) -> bool:
        """Delete a session's context.

        Args:
            session_id: Session identifier.

        Returns:
            True if deleted.
        """
        return self._persistor.delete_context(session_id)

    def list_sessions(self) -> list[dict[str, Any]]:
        """List all stored sessions.

        Returns:
            List of session info.
        """
        return self._persistor.list_sessions()

    # -------------------------------------------------------------------------
    # Utility Methods
    # -------------------------------------------------------------------------

    def get_context_for_prompt(self) -> str:
        """Get memory context for prompt injection.

        Returns:
            Formatted context string.
        """
        return self._injector.build_context_string()

    def estimate_tokens(self, messages: list[dict[str, Any]]) -> int:
        """Estimate token count for messages.

        Args:
            messages: Message list.

        Returns:
            Estimated tokens.
        """
        return self._compactor.estimate_tokens(messages)

    def get_engine_status(self) -> dict[str, Any] | None:
        """Get context engine status.

        Returns:
            Engine status dict or None if no engine.
        """
        engine = self._get_engine()
        if engine is not None:
            return engine.get_status()
        return None

    def cleanup(self) -> dict[str, int]:
        """Clean up old sessions.

        Returns:
            Cleanup statistics.
        """
        return {
            "sessions_removed": self._persistor.cleanup_old_sessions(),
        }
