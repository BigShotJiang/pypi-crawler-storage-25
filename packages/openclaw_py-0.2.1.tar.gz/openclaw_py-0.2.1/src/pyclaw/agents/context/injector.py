"""Context injector — injects memory context into prompts.

Injects relevant context from memory before reasoning:
- User preferences
- Project decisions
- Team context
- Reference information
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class InjectionConfig:
    """Configuration for context injection."""

    max_preferences: int = 5
    max_decisions: int = 5
    max_team_context: int = 10
    max_references: int = 3
    inject_into_system_prompt: bool = True
    inject_as_user_message: bool = False


@dataclass
class InjectionResult:
    """Result of context injection."""

    injected: bool
    context_length: int
    sections_injected: list[str] = field(default_factory=list)


class ContextInjector:
    """Injects memory context into messages before reasoning."""

    def __init__(
        self,
        config: InjectionConfig | None = None,
        memory_dir: Any | None = None,
    ) -> None:
        self._config = config or InjectionConfig()
        self._memory_dir = memory_dir
        self._context_providers: dict[str, Callable[[], str]] = {}

    def register_context_provider(
        self,
        name: str,
        provider: Callable[[], str],
    ) -> None:
        """Register a custom context provider.

        Args:
            name: Provider name.
            provider: Function that returns context string.
        """
        self._context_providers[name] = provider

    def gather_context(self) -> dict[str, str]:
        """Gather context from all sources.

        Returns:
            Dict of section name -> context content.
        """
        context: dict[str, str] = {}

        # Built-in context sources
        if self._memory_dir:
            # User preferences
            prefs = list(self._memory_dir.get_preferences())[: self._config.max_preferences]
            if prefs:
                lines = ["## User Preferences"]
                for p in prefs:
                    lines.append(f"- **{p.key}**: {p.content}")
                context["preferences"] = "\n".join(lines) + "\n"

            # Project decisions
            decisions = list(self._memory_dir.get_decisions())[: self._config.max_decisions]
            if decisions:
                lines = ["## Project Decisions"]
                for d in decisions:
                    lines.append(f"- {d.content}")
                context["decisions"] = "\n".join(lines) + "\n"

            # Team context
            team_memories = list(self._memory_dir.get_team_memories())[: self._config.max_team_context]
            if team_memories:
                lines = ["## Team Context"]
                for t in team_memories:
                    content = t.content[:200]
                    if len(t.content) > 200:
                        content += "..."
                    lines.append(f"- {content}")
                context["team"] = "\n".join(lines) + "\n"

        # Custom context providers
        for name, provider in self._context_providers.items():
            try:
                custom_context = provider()
                if custom_context:
                    context[name] = custom_context
            except Exception as e:
                logger.warning("Context provider %s failed: %s", name, e)

        return context

    def build_context_string(self) -> str:
        """Build the full context string for injection.

        Returns:
            Formatted context string.
        """
        context = self.gather_context()

        if not context:
            return ""

        parts = ["# Memory Context\n"]

        # Order sections
        order = ["preferences", "decisions", "team", "references"]
        for section in order:
            if section in context:
                parts.append(context[section])

        # Add remaining sections
        for name, content in context.items():
            if name not in order:
                parts.append(content)

        return "\n".join(parts)

    def inject_into_messages(
        self,
        messages: list[dict[str, Any]],
    ) -> InjectionResult:
        """Inject context into message list.

        Args:
            messages: Current message list.

        Returns:
            InjectionResult with details.
        """
        context_str = self.build_context_string()

        if not context_str:
            return InjectionResult(
                injected=False,
                context_length=0,
                sections_injected=[],
            )

        context_sections = list(self.gather_context().keys())

        if self._config.inject_into_system_prompt:
            # Find system message and append
            for msg in messages:
                if msg.get("role") == "system":
                    existing = msg.get("content", "")
                    msg["content"] = f"{existing}\n\n{context_str}"
                    break
            else:
                # No system message, prepend one
                messages.insert(0, {"role": "system", "content": context_str})

        elif self._config.inject_as_user_message:
            # Insert as user message after system messages
            system_count = sum(1 for m in messages if m.get("role") == "system")
            messages.insert(system_count, {"role": "user", "content": context_str})

        logger.debug(
            "Injected context: %d sections, %d chars",
            len(context_sections),
            len(context_str),
        )

        return InjectionResult(
            injected=True,
            context_length=len(context_str),
            sections_injected=context_sections,
        )

    def inject_for_subagent(
        self,
        messages: list[dict[str, Any]],
        parent_context: str,
    ) -> list[dict[str, Any]]:
        """Inject parent context for a subagent.

        Args:
            messages: Subagent message list.
            parent_context: Context from parent agent.

        Returns:
            Messages with parent context injected.
        """
        if not parent_context:
            return messages

        # Add parent context as a system message
        context_msg = {
            "role": "system",
            "content": f"# Inherited Context from Parent\n\n{parent_context}",
        }

        # Insert after existing system messages
        system_count = sum(1 for m in messages if m.get("role") == "system")
        messages = list(messages)  # Copy
        messages.insert(system_count, context_msg)

        return messages
