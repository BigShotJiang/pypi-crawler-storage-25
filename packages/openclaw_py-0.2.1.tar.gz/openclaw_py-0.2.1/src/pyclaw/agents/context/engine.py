"""Context engine abstract base class.

This module defines the ContextEngine ABC that all context management
implementations must implement. Reference: hermes-agent's ContextEngine design.

A context engine controls how conversation context is managed when
approaching the model's token limit. Implementations can use
summarization, DAG construction, or other strategies.

Lifecycle:
1. Engine is instantiated and registered
2. on_session_start() called when a conversation begins
3. update_from_response() called after each API response with usage data
4. should_compress() checked after each turn
5. compress() called when should_compress() returns True
6. on_session_end() called at real session boundaries
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class ContextEngine(ABC):
    """Abstract base class for context engines.

    All context engines must implement this interface. The engine
    is responsible for deciding when and how to compact context.
    """

    # -- Identity --

    @property
    @abstractmethod
    def name(self) -> str:
        """Short identifier (e.g., 'compressor', 'lcm')."""

    # -- Token state (read by runner for display/logging) --

    # These MUST be maintained by implementations
    last_prompt_tokens: int = 0
    last_completion_tokens: int = 0
    last_total_tokens: int = 0
    threshold_tokens: int = 0
    context_length: int = 0
    compression_count: int = 0

    # -- Compaction parameters (read by runner for preflight) --

    threshold_percent: float = 0.75
    protect_first_n: int = 3
    protect_last_n: int = 6

    # -- Core interface --

    @abstractmethod
    def update_from_response(self, usage: dict[str, Any]) -> None:
        """Update tracked token usage from an API response.

        Called after every LLM call with the usage dict from the response.

        Args:
            usage: Usage dict from API response (prompt_tokens, completion_tokens, etc.).
        """

    @abstractmethod
    def should_compress(self, prompt_tokens: int | None = None) -> bool:
        """Return True if compaction should fire this turn.

        Args:
            prompt_tokens: Current prompt token count (optional, use tracked if not provided).

        Returns:
            True if compression is needed.
        """

    @abstractmethod
    def compress(
        self,
        messages: list[dict[str, Any]],
        current_tokens: int | None = None,
    ) -> list[dict[str, Any]]:
        """Compact the message list.

        This is the main entry point. The engine receives the full message
        list and returns a (possibly shorter) list that fits within the
        context budget.

        Args:
            messages: Full message list.
            current_tokens: Current token count (optional).

        Returns:
            Compacted message list (valid OpenAI-format sequence).
        """

    # -- Optional: pre-flight check --

    def should_compress_preflight(self, messages: list[dict[str, Any]]) -> bool:
        """Quick rough check before the API call (no real token count yet).

        Default returns False (skip pre-flight). Override if your engine
        can do a cheap estimate.

        Args:
            messages: Current message list.

        Returns:
            True if compression should be done before the API call.
        """
        return False

    # -- Optional: session lifecycle --

    def on_session_start(self, session_id: str, **kwargs: Any) -> None:
        """Called when a new conversation session begins.

        Use this to load persisted state (DAG, store) for the session.

        Args:
            session_id: The session identifier.
            **kwargs: Additional context (hermes_home, platform, model, etc.).
        """
        pass

    def on_session_end(self, session_id: str, messages: list[dict[str, Any]]) -> None:
        """Called at real session boundaries (CLI exit, /reset, gateway expiry).

        Use this to flush state, close DB connections, etc.
        NOT called per-turn — only when the session truly ends.

        Args:
            session_id: The session identifier.
            messages: Final message list.
        """
        pass

    def on_session_reset(self) -> None:
        """Called on /new or /reset. Reset per-session state."""
        self.last_prompt_tokens = 0
        self.last_completion_tokens = 0
        self.last_total_tokens = 0
        self.compression_count = 0

    # -- Optional: tools --

    def get_tool_schemas(self) -> list[dict[str, Any]]:
        """Return tool schemas this engine provides to the agent.

        Default returns empty list (no tools). LCM would return schemas
        for lcm_grep, lcm_describe, lcm_expand here.

        Returns:
            List of tool schemas.
        """
        return []

    def handle_tool_call(self, name: str, args: dict[str, Any], **kwargs: Any) -> str:
        """Handle a tool call from the agent.

        Only called for tool names returned by get_tool_schemas().

        Args:
            name: Tool name.
            args: Tool arguments.
            **kwargs: Additional context.

        Returns:
            JSON string result.
        """
        import json

        return json.dumps({"error": f"Unknown context engine tool: {name}"})

    # -- Optional: status / display --

    def get_status(self) -> dict[str, Any]:
        """Return status dict for display/logging.

        Returns:
            Status dict with standard fields.
        """
        return {
            "last_prompt_tokens": self.last_prompt_tokens,
            "threshold_tokens": self.threshold_tokens,
            "context_length": self.context_length,
            "usage_percent": (
                min(100, self.last_prompt_tokens / self.context_length * 100) if self.context_length else 0
            ),
            "compression_count": self.compression_count,
        }

    # -- Optional: model switch support --

    def update_model(
        self,
        model: str,
        context_length: int,
        base_url: str = "",
        api_key: str = "",
        provider: str = "",
    ) -> None:
        """Called when the user switches models or on fallback activation.

        Default updates context_length and recalculates threshold_tokens
        from threshold_percent.

        Args:
            model: New model name.
            context_length: New context length.
            base_url: API base URL.
            api_key: API key.
            provider: Provider name.
        """
        self.context_length = context_length
        self.threshold_tokens = int(context_length * self.threshold_percent)
