"""Compression strategy — priority-based message compression.

Implements multi-level compression priority:
- System messages: Always preserved
- Recent messages: Preserved within window
- Tool results: Can be truncated
- History: Can be summarized
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class CompressionPriority(str, Enum):
    """Priority levels for message preservation during compression."""

    SYSTEM = "system"  # Always preserved
    RECENT = "recent"  # Preserved within window
    TOOL_RESULT = "tool_result"  # Can be truncated
    HISTORY = "history"  # Can be summarized


@dataclass
class CompressionConfig:
    """Configuration for compression strategy."""

    preserve_system: bool = True
    preserve_recent_count: int = 10
    max_tool_result_tokens: int = 5000
    max_history_summary_tokens: int = 500
    enable_truncation: bool = True
    enable_summarization: bool = True


@dataclass
class PrioritizedMessage:
    """Message with compression priority."""

    message: dict[str, Any]
    priority: CompressionPriority
    original_index: int
    token_count: int = 0


class CompressionStrategy:
    """Implements priority-based message compression."""

    def __init__(
        self,
        config: CompressionConfig | None = None,
    ) -> None:
        self._config = config or CompressionConfig()

    def prioritize_messages(
        self,
        messages: list[dict[str, Any]],
        token_estimator: Any = None,
    ) -> list[PrioritizedMessage]:
        """Assign compression priorities to messages.

        Args:
            messages: List of message dicts.
            token_estimator: Optional token estimator for accurate counts.

        Returns:
            List of PrioritizedMessage.
        """
        total = len(messages)
        prioritized: list[PrioritizedMessage] = []

        for i, msg in enumerate(messages):
            # Determine priority
            if msg.get("role") == "system":
                priority = CompressionPriority.SYSTEM
            elif i >= total - self._config.preserve_recent_count:
                priority = CompressionPriority.RECENT
            elif msg.get("role") == "tool":
                priority = CompressionPriority.TOOL_RESULT
            else:
                priority = CompressionPriority.HISTORY

            # Estimate tokens
            token_count = 0
            if token_estimator:
                token_count = token_estimator.estimate_message(msg)
            else:
                # Simple estimation
                content = msg.get("content", "")
                token_count = len(str(content)) // 4 if content else 0

            prioritized.append(
                PrioritizedMessage(
                    message=msg,
                    priority=priority,
                    original_index=i,
                    token_count=token_count,
                )
            )

        return prioritized

    def get_compression_order(
        self,
        prioritized: list[PrioritizedMessage],
    ) -> list[CompressionPriority]:
        """Get the order in which message types should be compressed.

        Args:
            prioritized: Prioritized messages.

        Returns:
            List of priorities in compression order.
        """
        return [
            CompressionPriority.HISTORY,
            CompressionPriority.TOOL_RESULT,
            # RECENT and SYSTEM are never compressed
        ]

    def should_preserve(self, prioritized: PrioritizedMessage) -> bool:
        """Check if a message should be preserved.

        Args:
            prioritized: Prioritized message.

        Returns:
            True if should be preserved.
        """
        if self._config.preserve_system and prioritized.priority == CompressionPriority.SYSTEM:
            return True

        return prioritized.priority == CompressionPriority.RECENT

    def truncate_tool_result(
        self,
        message: dict[str, Any],
        max_tokens: int,
    ) -> dict[str, Any]:
        """Truncate a tool result message.

        Args:
            message: Tool result message.
            max_tokens: Maximum tokens to keep.

        Returns:
            Truncated message.
        """
        if not self._config.enable_truncation:
            return message

        content = message.get("content", "")
        if isinstance(content, str):
            # Estimate character limit from tokens
            char_limit = max_tokens * 4
            if len(content) > char_limit:
                truncated = content[:char_limit]
                truncated += f"\n\n... [Truncated {len(content) - char_limit} characters]"
                return {**message, "content": truncated}

        return message

    def select_for_summarization(
        self,
        prioritized: list[PrioritizedMessage],
    ) -> list[PrioritizedMessage]:
        """Select messages that should be summarized.

        Args:
            prioritized: Prioritized messages.

        Returns:
            List of messages to summarize.
        """
        return [p for p in prioritized if p.priority == CompressionPriority.HISTORY]

    def calculate_potential_savings(
        self,
        prioritized: list[PrioritizedMessage],
    ) -> dict[CompressionPriority, int]:
        """Calculate potential token savings per priority.

        Args:
            prioritized: Prioritized messages.

        Returns:
            Dict of priority -> potential token savings.
        """
        savings: dict[CompressionPriority, int] = {}

        for p in prioritized:
            if p.priority == CompressionPriority.TOOL_RESULT:
                # Potential savings from truncation
                over_limit = max(0, p.token_count - self._config.max_tool_result_tokens)
                savings[p.priority] = savings.get(p.priority, 0) + over_limit
            elif p.priority == CompressionPriority.HISTORY:
                # Potential savings from summarization
                # Assume summary is ~10% of original
                savings[p.priority] = savings.get(p.priority, 0) + int(p.token_count * 0.9)

        return savings


def create_compression_plan(
    messages: list[dict[str, Any]],
    target_tokens: int,
    current_tokens: int,
    config: CompressionConfig | None = None,
) -> dict[str, Any]:
    """Create a compression plan to reach target token count.

    Args:
        messages: Messages to compress.
        target_tokens: Target token count.
        current_tokens: Current token count.
        config: Compression configuration.

    Returns:
        Dict with compression plan details.
    """
    config = config or CompressionConfig()
    strategy = CompressionStrategy(config)

    prioritized = strategy.prioritize_messages(messages)
    savings = strategy.calculate_potential_savings(prioritized)

    needed_savings = current_tokens - target_tokens

    plan: dict[str, Any] = {
        "current_tokens": current_tokens,
        "target_tokens": target_tokens,
        "needed_savings": needed_savings,
        "available_savings": sum(savings.values()),
        "can_achieve": sum(savings.values()) >= needed_savings,
        "actions": [],
    }

    # Plan actions
    remaining_needed = needed_savings

    # Action 1: Truncate tool results
    tool_savings = savings.get(CompressionPriority.TOOL_RESULT, 0)
    if tool_savings > 0 and remaining_needed > 0:
        plan["actions"].append(
            {
                "type": "truncate_tool_results",
                "potential_savings": min(tool_savings, remaining_needed),
            }
        )
        remaining_needed -= tool_savings

    # Action 2: Summarize history
    history_savings = savings.get(CompressionPriority.HISTORY, 0)
    if history_savings > 0 and remaining_needed > 0:
        plan["actions"].append(
            {
                "type": "summarize_history",
                "potential_savings": min(history_savings, remaining_needed),
            }
        )

    return plan
