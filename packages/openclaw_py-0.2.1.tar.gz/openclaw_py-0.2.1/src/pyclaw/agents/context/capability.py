"""Context capability registration and engine access.

This module provides functions to register and retrieve context engines
through the capability registry system.

Design notes:
- register_context_capability() registers an engine with the global registry
- get_context_engine() retrieves an engine by name or highest priority
- Default summarize engine is auto-registered on module import
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pyclaw.agents.capabilities import AgentCapability, CapabilityType, get_capability_registry
from pyclaw.agents.context.engine import ContextEngine
from pyclaw.agents.context.engines import SummarizeEngine

# Track if default provider has been registered
_default_registered = False


def _default_summarize_engine() -> ContextEngine:
    """Factory function for default SummarizeEngine."""
    return SummarizeEngine()


def register_context_capability(
    name: str = "summarize",
    provider_factory: Callable[[], ContextEngine] | None = None,
    priority: int = 0,
    tags: set[str] | None = None,
    metadata: dict[str, Any] | None = None,
    *,
    allow_replace: bool = True,
) -> None:
    """Register a context engine capability.

    Args:
        name: Engine name (default: "summarize").
        provider_factory: Factory function that creates engine instance.
            If None, uses SummarizeEngine.
        priority: Priority for selection (higher wins, default: 0).
        tags: Query tags for filtering capabilities.
        metadata: Additional metadata for the capability.
        allow_replace: If True, replaces existing capability with same name
            (default: True). Set to False for strict registration.

    Raises:
        ValueError: If capability already exists and allow_replace is False.
    """
    if provider_factory is None:
        provider_factory = _default_summarize_engine

    capability = AgentCapability(
        capability_type=CapabilityType.CONTEXT,
        name=name,
        description=f"Context engine: {name}",
        provider=provider_factory,
        priority=priority,
        tags=tags or set(),
        metadata=metadata or {},
    )

    registry = get_capability_registry()

    if not allow_replace:
        existing = registry.get(CapabilityType.CONTEXT, name)
        if existing is not None:
            raise ValueError(f"Context capability '{name}' already registered")

    registry.register(capability)


def get_context_engine(name: str | None = None) -> ContextEngine | None:
    """Get a context engine by name or highest priority.

    Args:
        name: Engine name. If None, returns the highest priority engine.

    Returns:
        ContextEngine instance or None if not found.
    """
    registry = get_capability_registry()
    capability = registry.get(CapabilityType.CONTEXT, name)
    if capability is None:
        return None

    provider = capability.provider()
    # Type check to ensure we return a ContextEngine
    if not isinstance(provider, ContextEngine):
        return None

    return provider


def unregister_context_capability(name: str) -> bool:
    """Unregister a context capability by name.

    Args:
        name: Engine name to unregister.

    Returns:
        True if the capability was removed, False if not found.
    """
    registry = get_capability_registry()
    return registry.unregister(CapabilityType.CONTEXT, name)


def list_context_capabilities() -> list[AgentCapability]:
    """List all registered context capabilities.

    Returns:
        List of all context capability definitions.
    """
    registry = get_capability_registry()
    return registry.list_all(CapabilityType.CONTEXT)


def _register_default_provider() -> None:
    """Register the default summarize context engine.

    This is called on module import to ensure a default engine is available.
    """
    global _default_registered
    if _default_registered:
        return

    register_context_capability(
        name="summarize",
        provider_factory=_default_summarize_engine,
        priority=0,
        tags={"default", "llm-powered"},
        metadata={"strategy": "summarize", "features": ["structured_summary", "tool_pairing"]},
    )
    _default_registered = True


# Auto-register default summarize engine on module import
_register_default_provider()
