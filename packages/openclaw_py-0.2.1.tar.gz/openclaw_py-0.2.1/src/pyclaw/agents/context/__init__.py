"""Context manager module — intelligent context handling for agent reasoning.

This module provides:
- Context engines (truncate, summarize)
- Context compaction (truncation + summarization)
- Context injection (memory context for prompts)
- Context persistence (cross-session state)
- Pre/post reasoning hooks
- Token estimation
- Compression strategy
- Message context representation
- Capability registration (register_context_capability, get_context_engine)
"""

from pyclaw.agents.context.capability import (
    get_context_engine,
    list_context_capabilities,
    register_context_capability,
    unregister_context_capability,
)
from pyclaw.agents.context.compaction import ContextCompactor
from pyclaw.agents.context.compression import (
    CompressionConfig,
    CompressionPriority,
    CompressionStrategy,
    create_compression_plan,
)
from pyclaw.agents.context.engine import ContextEngine
from pyclaw.agents.context.engines import SummarizeEngine, TruncateEngine
from pyclaw.agents.context.hooks import (
    post_turn_hook,
    pre_reasoning_hook,
)
from pyclaw.agents.context.injector import ContextInjector
from pyclaw.agents.context.manager import ContextManager
from pyclaw.agents.context.persistor import ContextPersistor
from pyclaw.agents.context.policy import (
    CacheStrategy,
    CompressionStrategyType,
    MessageContext,
)
from pyclaw.agents.context.summarizer import (
    ContextSummarizer,
    ContextSummary,
    SummaryConfig,
    generate_summary,
)
from pyclaw.agents.context.token_estimation import (
    TokenBreakdown,
    TokenBudgetTracker,
    TokenEstimator,
    estimate_tokens,
    get_token_breakdown,
)

__all__ = [
    # Core
    "ContextCompactor",
    "ContextEngine",
    "ContextInjector",
    "ContextManager",
    "ContextPersistor",
    # Engines
    "TruncateEngine",
    "SummarizeEngine",
    # Hooks
    "post_turn_hook",
    "pre_reasoning_hook",
    # Token estimation
    "TokenBreakdown",
    "TokenBudgetTracker",
    "TokenEstimator",
    "estimate_tokens",
    "get_token_breakdown",
    # Compression
    "CompressionConfig",
    "CompressionPriority",
    "CompressionStrategy",
    "create_compression_plan",
    # Policy
    "CacheStrategy",
    "CompressionStrategyType",
    "MessageContext",
    # Summarization
    "ContextSummary",
    "ContextSummarizer",
    "SummaryConfig",
    "generate_summary",
    # Capability registration
    "register_context_capability",
    "get_context_engine",
    "unregister_context_capability",
    "list_context_capabilities",
]
