"""Context compaction — truncates and summarizes context.

Implements intelligent compaction strategies:
- Token-based truncation
- Tool result compaction
- Message summarization
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class CompactionConfig:
    """Configuration for context compaction."""

    max_context_tokens: int = 128000
    max_tool_result_tokens: int = 10000
    preserve_recent_messages: int = 10
    min_messages_to_compact: int = 5
    summary_max_tokens: int = 500


@dataclass
class CompactionResult:
    """Result of a compaction operation."""

    original_messages: int
    compacted_messages: int
    tokens_saved: int
    summary: str | None = None
    compacted_indices: list[int] = field(default_factory=list)


class ContextCompactor:
    """Compacts conversation context to fit within token limits."""

    def __init__(
        self,
        config: CompactionConfig | None = None,
        workspace_dir: Path | None = None,
    ) -> None:
        self._config = config or CompactionConfig()
        self._workspace_dir = workspace_dir or Path(".")
        self._tool_result_cache: dict[str, str] = {}

    def estimate_tokens(self, messages: list[dict[str, Any]]) -> int:
        """Estimate token count for messages.

        Uses a simple heuristic: ~4 characters per token.

        Args:
            messages: List of message dicts.

        Returns:
            Estimated token count.
        """
        total = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total += len(content) // 4
            elif isinstance(content, list):
                # Handle multi-part content
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        total += len(part.get("text", "")) // 4
            # Add overhead for role and structure
            total += 10
        return total

    def check_needs_compaction(self, messages: list[dict[str, Any]]) -> bool:
        """Check if messages need compaction.

        Args:
            messages: Message list.

        Returns:
            True if compaction is needed.
        """
        tokens = self.estimate_tokens(messages)
        return tokens > self._config.max_context_tokens

    def compact_tool_results(
        self,
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Compact large tool results in messages.

        Args:
            messages: Message list.

        Returns:
            Messages with compacted tool results.
        """
        compacted = []
        for msg in messages:
            if msg.get("role") == "tool":
                content = msg.get("content", "")
                if isinstance(content, str) and len(content) > self._config.max_tool_result_tokens * 4:
                    # Truncate with notice
                    truncated = content[: self._config.max_tool_result_tokens * 4]
                    truncated += f"\n\n... [Truncated {len(content) - len(truncated)} characters]"
                    msg = {**msg, "content": truncated}
                    logger.debug("Compacted tool result: %d -> %d chars", len(content), len(truncated))
            compacted.append(msg)
        return compacted

    def compact_messages(
        self,
        messages: list[dict[str, Any]],
        summary: str | None = None,
    ) -> CompactionResult:
        """Compact messages to fit within limits.

        Strategy:
        1. Preserve recent messages
        2. Preserve system messages
        3. Compact older messages into summary

        Args:
            messages: Message list.
            summary: Optional pre-generated summary.

        Returns:
            CompactionResult with details.
        """
        original_count = len(messages)
        original_tokens = self.estimate_tokens(messages)

        if not self.check_needs_compaction(messages):
            return CompactionResult(
                original_messages=original_count,
                compacted_messages=original_count,
                tokens_saved=0,
            )

        # First compact tool results
        messages = self.compact_tool_results(messages)

        # Preserve system messages and recent messages
        system_messages = [m for m in messages if m.get("role") == "system"]
        recent_messages = messages[-self._config.preserve_recent_messages :]
        older_messages = messages[len(system_messages) : -self._config.preserve_recent_messages or None]

        if len(older_messages) < self._config.min_messages_to_compact:
            # Not enough to compact
            return CompactionResult(
                original_messages=original_count,
                compacted_messages=len(messages),
                tokens_saved=original_tokens - self.estimate_tokens(messages),
            )

        # Create summary message
        summary_content = summary or self._generate_summary(older_messages)
        summary_msg = {
            "role": "user",
            "content": f"[Context Summary]\n{summary_content}",
        }

        # Build compacted list
        compacted = [*system_messages, summary_msg, *recent_messages]

        new_tokens = self.estimate_tokens(compacted)

        return CompactionResult(
            original_messages=original_count,
            compacted_messages=len(compacted),
            tokens_saved=original_tokens - new_tokens,
            summary=summary_content,
            compacted_indices=list(range(len(system_messages), len(messages) - len(recent_messages))),
        )

    def _generate_summary(self, messages: list[dict[str, Any]]) -> str:
        """Generate a simple summary of messages.

        This is a basic implementation. For better summaries,
        use the MemorySummarizer with an LLM.

        Args:
            messages: Messages to summarize.

        Returns:
            Summary text.
        """
        # Count by role
        roles: dict[str, int] = {}
        topics: set[str] = set()

        for msg in messages:
            role = msg.get("role", "unknown")
            roles[role] = roles.get(role, 0) + 1

            # Extract key terms
            content = str(msg.get("content", ""))
            # Look for quoted strings and capitalized terms
            terms = re.findall(r'"([^"]+)"|([A-Z][a-z]{3,})', content)
            for t in terms:
                term = t[0] or t[1]
                if term and len(term) > 3:
                    topics.add(term.lower())

        summary_parts = [
            f"Conversation history: {len(messages)} messages",
            ", ".join(f"{r}: {c}" for r, c in roles.items()),
        ]

        if topics:
            top_topics = sorted(topics)[:10]
            summary_parts.append(f"Key topics: {', '.join(top_topics)}")

        return ". ".join(summary_parts) + "."

    def compact_for_model(
        self,
        messages: list[dict[str, Any]],
        model_limit: int,
    ) -> list[dict[str, Any]]:
        """Compact messages to fit a specific model's context limit.

        Args:
            messages: Message list.
            model_limit: Model's context token limit.

        Returns:
            Compacted message list.
        """
        config = CompactionConfig(max_context_tokens=model_limit)
        compactor = ContextCompactor(config, self._workspace_dir)
        result = compactor.compact_messages(messages)
        return messages if result.compacted_messages == result.original_messages else messages
