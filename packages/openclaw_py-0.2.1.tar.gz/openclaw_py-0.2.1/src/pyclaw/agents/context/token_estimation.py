"""Token estimation — accurate token counting for messages.

Implements token estimation using tiktoken for accurate counts:
- cl100k_base encoding (GPT-4/Claude compatible)
- Message breakdown by role and content type
- Budget tracking and warnings
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)

# Try to import tiktoken, fall back to approximation
try:
    import tiktoken

    TIKTOKEN_AVAILABLE = True
except ImportError:
    TIKTOKEN_AVAILABLE = False
    # Use debug level to avoid noise when tiktoken is optional
    logger.debug("tiktoken not available, using character-based estimation")


class ContentType(str, Enum):
    """Content type for token breakdown."""

    TEXT = "text"
    IMAGE = "image"
    TOOL_RESULT = "tool_result"
    TOOL_CALL = "tool_call"


@dataclass
class TokenBreakdown:
    """Breakdown of tokens by category."""

    by_role: dict[str, int] = field(default_factory=dict)
    by_content_type: dict[ContentType, int] = field(default_factory=dict)
    total: int = 0
    overhead: int = 0

    def add(self, role: str, content_type: ContentType, count: int) -> None:
        """Add tokens to the breakdown."""
        self.by_role[role] = self.by_role.get(role, 0) + count
        self.by_content_type[content_type] = self.by_content_type.get(content_type, 0) + count
        self.total += count


@dataclass
class BudgetStatus:
    """Status of token budget consumption."""

    used: int
    limit: int
    warning_threshold: float = 0.8

    @property
    def remaining(self) -> int:
        return max(0, self.limit - self.used)

    @property
    def percentage(self) -> float:
        return (self.used / self.limit) * 100 if self.limit > 0 else 0

    @property
    def is_warning(self) -> bool:
        return self.percentage >= self.warning_threshold * 100

    @property
    def is_exceeded(self) -> bool:
        return self.used >= self.limit


class TokenEstimator:
    """Estimates token count for messages.

    Uses tiktoken when available for accurate counting,
    falls back to character-based approximation.
    """

    def __init__(
        self,
        encoding_name: str = "cl100k_base",
        tokens_per_char: float = 0.25,  # Approximation ratio
    ) -> None:
        self._encoding_name = encoding_name
        self._tokens_per_char = tokens_per_char
        self._encoding = None

        if TIKTOKEN_AVAILABLE:
            try:
                self._encoding = tiktoken.get_encoding(encoding_name)
            except Exception as e:
                logger.warning("Failed to load tiktoken encoding: %s", e)

    def estimate_text(self, text: str) -> int:
        """Estimate token count for a text string.

        Args:
            text: Text to estimate.

        Returns:
            Estimated token count.
        """
        if not text:
            return 0

        if self._encoding:
            try:
                return len(self._encoding.encode(text))
            except Exception:
                pass

        # Fall back to character-based estimation
        return int(len(text) * self._tokens_per_char)

    def estimate_message(self, message: dict[str, Any]) -> int:
        """Estimate token count for a single message.

        Args:
            message: Message dict with 'role' and 'content'.

        Returns:
            Estimated token count including overhead.
        """
        total = 0

        # Role overhead
        total += 4  # Approximate tokens for role formatting

        # Content
        content = message.get("content")
        if isinstance(content, str):
            total += self.estimate_text(content)
        elif isinstance(content, list):
            # Multi-part content
            for part in content:
                if isinstance(part, dict):
                    if part.get("type") == "text":
                        total += self.estimate_text(part.get("text", ""))
                    elif part.get("type") == "image_url":
                        # Images use tokens based on detail level
                        detail = part.get("image_url", {}).get("detail", "auto")
                        if detail == "low":
                            total += 85  # Low detail images
                        else:
                            total += 765  # High detail base + tiles
                    elif part.get("type") == "tool_use":
                        total += self.estimate_text(str(part))
                    elif part.get("type") == "tool_result":
                        total += self.estimate_text(part.get("content", ""))

        # Tool calls
        tool_calls = message.get("tool_calls", [])
        for tc in tool_calls:
            total += self.estimate_text(tc.get("function", {}).get("name", ""))
            total += self.estimate_text(tc.get("function", {}).get("arguments", ""))

        # Name field
        name = message.get("name")
        if name:
            total += self.estimate_text(name) + 2

        return total

    def estimate_messages(self, messages: list[dict[str, Any]]) -> int:
        """Estimate total token count for messages.

        Args:
            messages: List of message dicts.

        Returns:
            Total estimated token count.
        """
        return sum(self.estimate_message(m) for m in messages)

    def get_breakdown(self, messages: list[dict[str, Any]]) -> TokenBreakdown:
        """Get detailed token breakdown by role and content type.

        Args:
            messages: List of message dicts.

        Returns:
            TokenBreakdown with details.
        """
        breakdown = TokenBreakdown()

        for msg in messages:
            role = msg.get("role", "unknown")
            content = msg.get("content")

            if isinstance(content, str):
                count = self.estimate_text(content)
                breakdown.add(role, ContentType.TEXT, count)
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict):
                        if part.get("type") == "text":
                            count = self.estimate_text(part.get("text", ""))
                            breakdown.add(role, ContentType.TEXT, count)
                        elif part.get("type") == "image_url":
                            breakdown.add(role, ContentType.IMAGE, 765)
                        elif part.get("type") == "tool_result":
                            count = self.estimate_text(part.get("content", ""))
                            breakdown.add(role, ContentType.TOOL_RESULT, count)

            # Tool calls
            tool_calls = msg.get("tool_calls", [])
            for tc in tool_calls:
                count = self.estimate_text(str(tc))
                breakdown.add(role, ContentType.TOOL_CALL, count)

            # Overhead for message structure
            breakdown.overhead += 4

        return breakdown


class TokenBudgetTracker:
    """Tracks token budget consumption."""

    def __init__(
        self,
        limit: int = 128000,
        warning_threshold: float = 0.8,
    ) -> None:
        self._limit = limit
        self._warning_threshold = warning_threshold
        self._used = 0
        self._estimator = TokenEstimator()

    @property
    def status(self) -> BudgetStatus:
        return BudgetStatus(
            used=self._used,
            limit=self._limit,
            warning_threshold=self._warning_threshold,
        )

    def add_messages(self, messages: list[dict[str, Any]]) -> BudgetStatus:
        """Add messages to the budget.

        Args:
            messages: Messages to add.

        Returns:
            Current BudgetStatus.
        """
        self._used += self._estimator.estimate_messages(messages)
        return self.status

    def reset(self) -> None:
        """Reset the budget tracker."""
        self._used = 0

    def set_limit(self, limit: int) -> None:
        """Set a new token limit."""
        self._limit = limit


def estimate_tokens(
    messages: list[dict[str, Any]],
    encoding: str = "cl100k_base",
) -> int:
    """Estimate token count for messages.

    Convenience function for quick estimation.

    Args:
        messages: List of message dicts.
        encoding: Encoding name for tiktoken.

    Returns:
        Estimated token count.
    """
    estimator = TokenEstimator(encoding)
    return estimator.estimate_messages(messages)


def get_token_breakdown(
    messages: list[dict[str, Any]],
) -> TokenBreakdown:
    """Get token breakdown for messages.

    Args:
        messages: List of message dicts.

    Returns:
        TokenBreakdown with details.
    """
    estimator = TokenEstimator()
    return estimator.get_breakdown(messages)
