"""Agent runtime — unified runtime for agent execution.

This module provides AgentRuntime, a unified runtime that integrates:
- MemoryProvider for persistent memory
- ContextEngine for context compression
- OrchestrationEngine for multi-agent collaboration

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-framework-design.md
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from pyclaw.agents.capabilities import CapabilityType, get_capability_registry
from pyclaw.agents.context.manager import ContextManager
from pyclaw.agents.definition import AgentDefinition
from pyclaw.agents.memory.provider import MemoryProvider
from pyclaw.agents.orchestration.engine import OrchestrationEngine
from pyclaw.agents.session import SessionManager
from pyclaw.agents.stream import build_tool_definitions, stream_llm
from pyclaw.agents.types import AgentEvent, AgentTool, ModelConfig, ToolCall, ToolResult

logger = logging.getLogger(__name__)


class RuntimeState(str, Enum):
    """Runtime state for an agent."""

    IDLE = "idle"  # Not running
    INITIALIZING = "initializing"  # Setting up capabilities
    RUNNING = "running"  # Active in agent loop
    PAUSED = "paused"  # Paused (e.g., waiting for steering)
    STOPPING = "stopping"  # Shutting down
    STOPPED = "stopped"  # Fully stopped
    ERROR = "error"  # Error state


@dataclass
class RuntimeConfig:
    """Configuration for AgentRuntime."""

    max_turns: int = 50
    timeout_seconds: int = 300
    enable_memory: bool = True
    enable_context_compression: bool = True


@dataclass
class RuntimeMetrics:
    """Metrics collected during runtime execution."""

    turns_completed: int = 0
    tokens_input: int = 0
    tokens_output: int = 0
    tools_called: int = 0
    errors: int = 0
    started_at: datetime | None = None
    completed_at: datetime | None = None


class AgentRuntime:
    """Unified agent runtime integrating all capabilities.

    This class provides a unified interface for running agents with:
    - Memory integration (MemoryProvider)
    - Context management (ContextEngine)
    - Orchestration support (OrchestrationEngine)

    Example:
        runtime = AgentRuntime(
            definition=my_agent_def,
            model=ModelConfig(provider="openai", model_id="gpt-4o"),
        )
        await runtime.initialize()

        async for event in runtime.run("Hello!"):
            print(event)

        await runtime.shutdown()
    """

    def __init__(
        self,
        definition: AgentDefinition,
        model: ModelConfig,
        session: SessionManager | None = None,
        workspace_dir: Path | None = None,
        config: RuntimeConfig | None = None,
    ) -> None:
        """Initialize the agent runtime.

        Args:
            definition: Agent definition with configuration.
            model: Model configuration.
            session: Optional session manager (created if not provided).
            workspace_dir: Optional workspace directory.
            config: Optional runtime configuration.
        """
        self._definition = definition
        self._model = model
        self._config = config or RuntimeConfig()
        self._workspace_dir = workspace_dir or Path.cwd()
        self._state = RuntimeState.IDLE
        self._metrics = RuntimeMetrics()

        # Session management
        self._session = session

        # Capabilities (lazy loaded)
        self._memory_provider: MemoryProvider | None = None
        self._context_manager: ContextManager | None = None
        self._orchestration_engine: OrchestrationEngine | None = None

        # Tool registry
        self._tools: dict[str, AgentTool] = {}

        # Abort control
        self._abort_event: asyncio.Event | None = None

    @property
    def state(self) -> RuntimeState:
        """Current runtime state."""
        return self._state

    @property
    def metrics(self) -> RuntimeMetrics:
        """Runtime metrics."""
        return self._metrics

    @property
    def definition(self) -> AgentDefinition:
        """Agent definition."""
        return self._definition

    @property
    def model(self) -> ModelConfig:
        """Model configuration."""
        return self._model

    # -------------------------------------------------------------------------
    # Capability Accessors
    # -------------------------------------------------------------------------

    @property
    def memory_provider(self) -> MemoryProvider | None:
        """Get memory provider."""
        return self._memory_provider

    @property
    def context_manager(self) -> ContextManager | None:
        """Get context manager."""
        return self._context_manager

    @property
    def orchestration_engine(self) -> OrchestrationEngine | None:
        """Get orchestration engine."""
        return self._orchestration_engine

    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------

    async def initialize(self) -> None:
        """Initialize all capabilities.

        This method:
        1. Creates session if needed
        2. Loads memory provider from registry
        3. Loads context engine from registry
        4. Loads orchestration engine if configured
        """
        self._state = RuntimeState.INITIALIZING
        logger.info("Initializing runtime for agent: %s", self._definition.agent_type)

        # Create session if needed
        if self._session is None:
            session_path = self._workspace_dir / ".pyclaw" / "sessions" / f"{self._definition.agent_type}.json"
            self._session = SessionManager(path=session_path)

        # Initialize memory provider
        if self._config.enable_memory:
            await self._initialize_memory()

        # Initialize context manager
        if self._config.enable_context_compression:
            await self._initialize_context()

        # Initialize orchestration if configured
        if self._definition.orchestration.mode != "none":
            await self._initialize_orchestration()

        self._state = RuntimeState.IDLE
        logger.info("Runtime initialized successfully")

    async def _initialize_memory(self) -> None:
        """Initialize memory provider from registry."""
        registry = get_capability_registry()
        cap = registry.get(CapabilityType.MEMORY, self._definition.memory_backend)

        if cap is None:
            logger.warning("Memory capability '%s' not found", self._definition.memory_backend)
            return

        try:
            provider = cap.provider()
            if isinstance(provider, MemoryProvider):
                await provider.initialize(
                    memory_scope=self._definition.memory_scope.value,
                    project_root=str(self._workspace_dir),
                )
                self._memory_provider = provider
                logger.debug("Memory provider initialized: %s", provider.name)
        except Exception as e:
            logger.warning("Failed to initialize memory provider: %s", e)

    async def _initialize_context(self) -> None:
        """Initialize context manager."""
        self._context_manager = ContextManager(
            workspace_dir=self._workspace_dir,
        )
        logger.debug("Context manager initialized")

    async def _initialize_orchestration(self) -> None:
        """Initialize orchestration engine from registry."""
        registry = get_capability_registry()
        cap = registry.get(CapabilityType.ORCHESTRATION)

        if cap is None:
            logger.warning("Orchestration capability not found")
            return

        try:
            engine = cap.provider()
            if isinstance(engine, OrchestrationEngine):
                await engine.initialize()
                self._orchestration_engine = engine
                logger.debug("Orchestration engine initialized: %s", engine.mode.value)
        except Exception as e:
            logger.warning("Failed to initialize orchestration engine: %s", e)

    async def shutdown(self) -> None:
        """Shutdown all capabilities."""
        self._state = RuntimeState.STOPPING
        logger.info("Shutting down runtime")

        # Shutdown memory provider
        if self._memory_provider:
            try:
                await self._memory_provider.shutdown()
            except Exception as e:
                logger.warning("Memory provider shutdown error: %s", e)

        # Shutdown orchestration engine
        if self._orchestration_engine:
            try:
                await self._orchestration_engine.shutdown()
            except Exception as e:
                logger.warning("Orchestration shutdown error: %s", e)

        self._state = RuntimeState.STOPPED
        logger.info("Runtime shutdown complete")

    # -------------------------------------------------------------------------
    # Tool Registration
    # -------------------------------------------------------------------------

    def register_tool(self, tool: AgentTool) -> None:
        """Register a tool with the runtime.

        Args:
            tool: Tool to register.
        """
        self._tools[tool.name] = tool
        logger.debug("Tool registered: %s", tool.name)

    def unregister_tool(self, name: str) -> bool:
        """Unregister a tool.

        Args:
            name: Tool name.

        Returns:
            True if tool was removed.
        """
        if name in self._tools:
            del self._tools[name]
            return True
        return False

    def get_tools(self) -> list[AgentTool]:
        """Get all registered tools.

        Returns:
            List of registered tools.
        """
        return list(self._tools.values())

    # -------------------------------------------------------------------------
    # Execution
    # -------------------------------------------------------------------------

    async def run(
        self,
        prompt: str,
        system_prompt: str | None = None,
        *,
        max_turns: int | None = None,
        abort_event: asyncio.Event | None = None,
    ) -> AsyncIterator[AgentEvent]:
        """Run the agent loop.

        Args:
            prompt: User prompt.
            system_prompt: Optional system prompt override.
            max_turns: Optional max turns override.
            abort_event: Optional abort event.

        Yields:
            AgentEvent instances.
        """
        if self._state == RuntimeState.STOPPED:
            raise RuntimeError("Runtime is stopped")

        self._state = RuntimeState.RUNNING
        self._abort_event = abort_event
        self._metrics = RuntimeMetrics(started_at=datetime.now())

        try:
            async for event in self._run_loop(
                prompt=prompt,
                system_prompt=system_prompt,
                max_turns=max_turns or self._config.max_turns,
            ):
                yield event

                # Track metrics
                if event.type == "message_end" and event.usage:
                    self._metrics.tokens_input += event.usage.get("input_tokens", 0)
                    self._metrics.tokens_output += event.usage.get("output_tokens", 0)
                elif event.type == "tool_start":
                    self._metrics.tools_called += 1
                elif event.type == "error":
                    self._metrics.errors += 1

        except Exception as e:
            self._state = RuntimeState.ERROR
            logger.error("Runtime error: %s", e, exc_info=True)
            yield AgentEvent(type="error", error=str(e))
        finally:
            self._metrics.completed_at = datetime.now()
            self._state = RuntimeState.IDLE

    async def _run_loop(
        self,
        prompt: str,
        system_prompt: str | None,
        max_turns: int,
    ) -> AsyncIterator[AgentEvent]:
        """Main agent loop.

        Args:
            prompt: User prompt.
            system_prompt: System prompt.
            max_turns: Maximum turns.

        Yields:
            AgentEvent instances.
        """
        yield AgentEvent(type="agent_start")

        # Build messages
        messages = self._build_messages(prompt, system_prompt)

        # Preprocess context
        messages = await self._preprocess_context(messages)

        # Build tool definitions
        tools = self.get_tools()
        tool_defs = build_tool_definitions(tools) if tools else None
        tools_by_name = {t.name: t for t in tools}

        turn = 0
        while turn < max_turns:
            # Check abort
            if self._abort_event and self._abort_event.is_set():
                yield AgentEvent(type="error", error="aborted")
                break

            turn += 1
            self._metrics.turns_completed = turn
            logger.debug("Turn %d/%d", turn, max_turns)

            yield AgentEvent(type="message_start")

            # Stream LLM response
            completion_text = ""
            completion_tool_calls: list[ToolCall] = []
            usage: dict[str, int] | None = None

            async for event in stream_llm(self._model, messages, tool_defs):
                if self._abort_event and self._abort_event.is_set():
                    break

                if event.type == "message_update":
                    yield event
                    if event.delta:
                        completion_text += event.delta
                elif event.type == "message_end":
                    usage = event.usage
                elif event.type == "_completion" and event.result:
                    completion_text = event.result.get("text", "")
                    for tc_data in event.result.get("tool_calls", []):
                        completion_tool_calls.append(
                            ToolCall(
                                id=tc_data["id"],
                                name=tc_data["name"],
                                arguments=tc_data["arguments"],
                            )
                        )

            # Record assistant message
            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": completion_text,
            }
            if completion_tool_calls:
                assistant_msg["tool_calls"] = [
                    {"id": tc.id, "type": "function", "function": {"name": tc.name, "arguments": tc.arguments}}
                    for tc in completion_tool_calls
                ]
            messages.append(assistant_msg)

            # Update context manager with usage
            if usage and self._context_manager:
                self._context_manager.update_from_response(usage)

            yield AgentEvent(type="message_end", usage=usage)

            # No tool calls = done
            if not completion_tool_calls:
                logger.debug("Agent finished after turn %d", turn)
                break

            # Execute tool calls
            for tc in completion_tool_calls:
                yield AgentEvent(type="tool_start", name=tc.name, tool_call_id=tc.id)

                tool = tools_by_name.get(tc.name)
                if tool:
                    try:
                        result = await tool.execute(tc.id, tc.arguments)
                    except Exception as e:
                        logger.error("Tool %s failed: %s", tc.name, e)
                        result = ToolResult.text(f"Error: {e}", is_error=True)
                else:
                    result = ToolResult.text(f"Unknown tool: {tc.name}", is_error=True)

                yield AgentEvent(
                    type="tool_end",
                    name=tc.name,
                    tool_call_id=tc.id,
                    result={"content": result.content, "is_error": result.is_error},
                )

                # Add tool result to messages
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result.content[0].get("text", "") if result.content else "",
                    }
                )

            # Postprocess context
            await self._postprocess(messages)

        yield AgentEvent(type="agent_end")

    def _build_messages(
        self,
        prompt: str,
        system_prompt: str | None,
    ) -> list[dict[str, Any]]:
        """Build initial message list.

        Args:
            prompt: User prompt.
            system_prompt: System prompt.

        Returns:
            Message list.
        """
        messages: list[dict[str, Any]] = []

        # Add system prompt
        effective_system = system_prompt or self._definition.system_prompt or ""
        if effective_system:
            messages.append({"role": "system", "content": effective_system})

        # Add session history
        if self._session:
            for msg in self._session.get_messages_as_dicts():
                messages.append(msg)

        # Add user prompt
        messages.append({"role": "user", "content": prompt})

        return messages

    async def _preprocess_context(
        self,
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Preprocess messages before sending to LLM.

        Args:
            messages: Message list.

        Returns:
            Processed message list.
        """
        if self._context_manager is None:
            return messages

        # Apply context manager preprocessing
        session_id = self._session.session_id if self._session else None
        return self._context_manager.preprocess(messages, session_id=session_id)

    async def _postprocess(self, messages: list[dict[str, Any]]) -> None:
        """Postprocess after a turn.

        Args:
            messages: Current message list.
        """
        if self._context_manager is None:
            return

        session_id = self._session.session_id if self._session else None
        self._context_manager.postprocess(messages, session_id=session_id)

    async def _build_memory_context(self) -> str:
        """Build memory context for injection.

        Returns:
            Formatted memory context string.
        """
        if self._memory_provider is None:
            return ""

        try:
            entries = await self._memory_provider.search("", limit=10)
            if not entries:
                return ""

            lines = ["## Relevant Memory"]
            for entry in entries:
                lines.append(f"- {entry.content[:200]}")

            return "\n".join(lines)
        except Exception as e:
            logger.warning("Memory context build failed: %s", e)
            return ""

    # -------------------------------------------------------------------------
    # Control
    # -------------------------------------------------------------------------

    def abort(self) -> None:
        """Abort the current run."""
        if self._abort_event:
            self._abort_event.set()

    def get_status(self) -> dict[str, Any]:
        """Get runtime status.

        Returns:
            Status dict.
        """
        return {
            "state": self._state.value,
            "agent_type": self._definition.agent_type,
            "model": self._model.model_id,
            "metrics": {
                "turns_completed": self._metrics.turns_completed,
                "tokens_input": self._metrics.tokens_input,
                "tokens_output": self._metrics.tokens_output,
                "tools_called": self._metrics.tools_called,
                "errors": self._metrics.errors,
            },
            "capabilities": {
                "memory": self._memory_provider is not None,
                "context": self._context_manager is not None,
                "orchestration": self._orchestration_engine is not None,
            },
        }
