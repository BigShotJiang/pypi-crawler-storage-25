"""Memory paths — directory structure for memory storage.

Provides path management for the structured memory directory:
.claude/memory/
├── project/          # Project-level decisions
│   └── decisions.jsonl
├── session/          # Session-specific memories
│   └── {session_id}.jsonl
├── team/             # Shared team memories
│   └── shared.jsonl
└── user/             # User preferences
    └── preferences.jsonl
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar


@dataclass
class MemoryPaths:
    """Manages paths for memory directory structure."""

    base_dir: Path
    project_dir: Path = None  # type: ignore
    session_dir: Path = None  # type: ignore
    team_dir: Path = None  # type: ignore
    user_dir: Path = None  # type: ignore

    DEFAULT_BASE_NAME: ClassVar[str] = ".claude"
    MEMORY_DIR_NAME: ClassVar[str] = "memory"

    def __post_init__(self) -> None:
        """Initialize derived paths."""
        memory_root = self.base_dir / self.DEFAULT_BASE_NAME / self.MEMORY_DIR_NAME
        self.project_dir = memory_root / "project"
        self.session_dir = memory_root / "session"
        self.team_dir = memory_root / "team"
        self.user_dir = memory_root / "user"

    @classmethod
    def from_project_root(cls, project_root: Path | str) -> MemoryPaths:
        """Create MemoryPaths from a project root directory.

        Args:
            project_root: The root directory of the project.

        Returns:
            MemoryPaths instance with all paths configured.
        """
        return cls(base_dir=Path(project_root))

    @property
    def memory_root(self) -> Path:
        """Get the root of the memory directory."""
        return self.base_dir / self.DEFAULT_BASE_NAME / self.MEMORY_DIR_NAME

    @property
    def decisions_path(self) -> Path:
        """Get the path to project decisions file."""
        return self.project_dir / "decisions.jsonl"

    @property
    def preferences_path(self) -> Path:
        """Get the path to user preferences file."""
        return self.user_dir / "preferences.jsonl"

    @property
    def team_shared_path(self) -> Path:
        """Get the path to shared team memory file."""
        return self.team_dir / "shared.jsonl"

    def session_path(self, session_id: str) -> Path:
        """Get the path to a session-specific memory file.

        Args:
            session_id: Unique identifier for the session.

        Returns:
            Path to the session memory file.
        """
        return self.session_dir / f"{session_id}.jsonl"

    def ensure_directories(self) -> None:
        """Create all memory directories if they don't exist."""
        self.project_dir.mkdir(parents=True, exist_ok=True)
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self.team_dir.mkdir(parents=True, exist_ok=True)
        self.user_dir.mkdir(parents=True, exist_ok=True)

    def exists(self) -> bool:
        """Check if the memory directory structure exists."""
        return self.memory_root.exists()

    def list_sessions(self) -> list[Path]:
        """List all session memory files.

        Returns:
            List of paths to session memory files.
        """
        if not self.session_dir.exists():
            return []
        return sorted(self.session_dir.glob("*.jsonl"))

    def cleanup_old_sessions(self, max_age_days: int = 30) -> int:
        """Remove session files older than max_age_days.

        Args:
            max_age_days: Maximum age in days for session files.

        Returns:
            Number of files removed.
        """
        import time

        removed = 0
        cutoff = time.time() - (max_age_days * 86400)

        for session_file in self.list_sessions():
            if session_file.stat().st_mtime < cutoff:
                session_file.unlink()
                removed += 1

        return removed
