"""Memory directory — CRUD operations for structured memory storage.

Implements the MemoryDirectory class for managing memory entries
across project, session, team, and user levels.
"""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

from pyclaw.agents.memory_dir.find_relevant_memories import (
    SearchConfig,
    load_memories_from_jsonl,
    save_memories_to_jsonl,
    search_all_memory_files,
)
from pyclaw.agents.memory_dir.memory_age import DecayConfig
from pyclaw.agents.memory_dir.memory_types import (
    FeedbackRecord,
    MemoryEntry,
    MemoryPriority,
    MemoryType,
    ProjectDecision,
    ReferenceLink,
    UserPreference,
)
from pyclaw.agents.memory_dir.paths import MemoryPaths


@dataclass
class MemoryDirectory:
    """Manages memory entries in a structured directory hierarchy.

    Provides CRUD operations for memory entries across:
    - project/ : Project-level decisions
    - session/{id}.jsonl : Session-specific memories
    - team/shared.jsonl : Shared team memories
    - user/preferences.jsonl : User preferences
    """

    paths: MemoryPaths
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)
    _cache: dict[str, list[MemoryEntry]] = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        """Ensure directories exist."""
        self.paths.ensure_directories()

    @classmethod
    def from_project_root(cls, project_root: Path | str) -> MemoryDirectory:
        """Create MemoryDirectory from project root.

        Args:
            project_root: Root directory of the project.

        Returns:
            MemoryDirectory instance.
        """
        return cls(paths=MemoryPaths.from_project_root(project_root))

    # --- Project Decisions ---

    def add_decision(
        self,
        decision: str,
        rationale: str,
        priority: MemoryPriority = MemoryPriority.HIGH,
        tags: list[str] | None = None,
    ) -> ProjectDecision:
        """Add a project decision.

        Args:
            decision: The decision text.
            rationale: Why this decision was made.
            priority: Priority level.
            tags: Optional tags.

        Returns:
            The created ProjectDecision.
        """
        entry = ProjectDecision.create(
            decision=decision,
            rationale=rationale,
            priority=priority,
            tags=tags or [],
        )
        self._append_entry(self.paths.decisions_path, entry)
        self._invalidate_cache("project")
        return entry

    def get_decisions(self) -> list[ProjectDecision]:
        """Get all project decisions.

        Returns:
            List of ProjectDecision entries.
        """
        entries = self._load_entries(self.paths.decisions_path)
        return [ProjectDecision.from_dict(e.to_dict()) for e in entries]

    # --- User Preferences ---

    def set_preference(
        self,
        key: str,
        value: str,
        priority: MemoryPriority = MemoryPriority.HIGH,
    ) -> UserPreference:
        """Set a user preference.

        Args:
            key: Preference key.
            value: Preference value.
            priority: Priority level.

        Returns:
            The created/updated UserPreference.
        """
        # Check for existing preference
        prefs = self.get_preferences()
        existing_idx = None
        for i, pref in enumerate(prefs):
            if pref.key == key:
                existing_idx = i
                break

        if existing_idx is not None:
            # Update existing preference
            prefs[existing_idx].content = value
            prefs[existing_idx].updated_at = prefs[existing_idx].created_at.__class__.now()
            with self._lock:
                save_memories_to_jsonl(cast(list[MemoryEntry], prefs), self.paths.preferences_path, append=False)
            self._invalidate_cache("user")
            return prefs[existing_idx]

        entry = UserPreference.create(key=key, value=value, priority=priority)
        self._append_entry(self.paths.preferences_path, entry)
        self._invalidate_cache("user")
        return entry

    def get_preference(self, key: str) -> UserPreference | None:
        """Get a specific user preference.

        Args:
            key: Preference key.

        Returns:
            UserPreference or None.
        """
        for pref in self.get_preferences():
            if pref.key == key:
                return pref
        return None

    def get_preferences(self) -> list[UserPreference]:
        """Get all user preferences.

        Returns:
            List of UserPreference entries.
        """
        entries = self._load_entries(self.paths.preferences_path)
        return [UserPreference.from_dict(e.to_dict()) for e in entries]

    def _rewrite_preferences(self) -> None:
        """Rewrite the preferences file with current state."""
        prefs = self.get_preferences()
        with self._lock:
            save_memories_to_jsonl(cast(list[MemoryEntry], prefs), self.paths.preferences_path, append=False)

    # --- Session Memories ---

    def add_session_memory(
        self,
        session_id: str,
        content: str,
        memory_type: MemoryType = MemoryType.SESSION_CONTEXT,
        tags: list[str] | None = None,
    ) -> MemoryEntry:
        """Add a session-specific memory.

        Args:
            session_id: Session identifier.
            content: Memory content.
            memory_type: Type of memory.
            tags: Optional tags.

        Returns:
            The created MemoryEntry.
        """
        entry = MemoryEntry(
            content=content,
            memory_type=memory_type,
            tags=tags or [],
        )
        path = self.paths.session_path(session_id)
        self._append_entry(path, entry)
        self._invalidate_cache(f"session:{session_id}")
        return entry

    def get_session_memories(self, session_id: str) -> list[MemoryEntry]:
        """Get all memories for a session.

        Args:
            session_id: Session identifier.

        Returns:
            List of MemoryEntry.
        """
        path = self.paths.session_path(session_id)
        return self._load_entries(path)

    def clear_session(self, session_id: str) -> None:
        """Clear all memories for a session.

        Args:
            session_id: Session identifier.
        """
        path = self.paths.session_path(session_id)
        if path.exists():
            path.unlink()
        # Invalidate cache using the actual file path
        cache_key = str(path)
        if cache_key in self._cache:
            del self._cache[cache_key]

    # --- Team Memories ---

    def add_team_memory(
        self,
        content: str,
        member: str | None = None,
        tags: list[str] | None = None,
    ) -> MemoryEntry:
        """Add a team shared memory.

        Args:
            content: Memory content.
            member: Optional member who contributed.
            tags: Optional tags.

        Returns:
            The created MemoryEntry.
        """
        entry = MemoryEntry(
            content=content,
            memory_type=MemoryType.TEAM_SHARED,
            tags=tags or [],
            metadata={"member": member} if member else {},
        )
        self._append_entry(self.paths.team_shared_path, entry)
        self._invalidate_cache("team")
        return entry

    def get_team_memories(self) -> list[MemoryEntry]:
        """Get all team shared memories.

        Returns:
            List of MemoryEntry.
        """
        return self._load_entries(self.paths.team_shared_path)

    # --- Feedback Records ---

    def add_feedback(
        self,
        feedback: str,
        feedback_type: str,
        context: str = "",
        tags: list[str] | None = None,
    ) -> FeedbackRecord:
        """Add a feedback record.

        Args:
            feedback: The feedback content.
            feedback_type: Type of feedback (correction, preference, warning).
            context: Context where feedback was given.
            tags: Optional tags.

        Returns:
            The created FeedbackRecord.
        """
        entry = FeedbackRecord.create(
            feedback=feedback,
            feedback_type=feedback_type,
            context=context,
            tags=tags or [],
        )
        # Store in project directory
        path = self.paths.project_dir / "feedback.jsonl"
        self._append_entry(path, entry)
        self._invalidate_cache("feedback")
        return entry

    def get_feedback(self) -> list[FeedbackRecord]:
        """Get all feedback records.

        Returns:
            List of FeedbackRecord.
        """
        path = self.paths.project_dir / "feedback.jsonl"
        entries = self._load_entries(path)
        return [FeedbackRecord.from_dict(e.to_dict()) for e in entries]

    # --- Reference Links ---

    def add_reference(
        self,
        url: str,
        description: str,
        tags: list[str] | None = None,
    ) -> ReferenceLink:
        """Add a reference link.

        Args:
            url: The URL.
            description: Description of the resource.
            tags: Optional tags.

        Returns:
            The created ReferenceLink.
        """
        entry = ReferenceLink.create(url=url, description=description, tags=tags or [])
        path = self.paths.project_dir / "references.jsonl"
        self._append_entry(path, entry)
        self._invalidate_cache("references")
        return entry

    def get_references(self) -> list[ReferenceLink]:
        """Get all reference links.

        Returns:
            List of ReferenceLink.
        """
        path = self.paths.project_dir / "references.jsonl"
        entries = self._load_entries(path)
        return [ReferenceLink.from_dict(e.to_dict()) for e in entries]

    # --- Search Operations ---

    def search(
        self,
        query: str,
        config: SearchConfig | None = None,
        decay_config: DecayConfig | None = None,
    ) -> list[MemoryEntry]:
        """Search all memories for relevant entries.

        Args:
            query: Search query.
            config: Search configuration.
            decay_config: Decay configuration.

        Returns:
            Ranked list of relevant memories.
        """
        # Collect all memory files
        memory_files = [
            self.paths.decisions_path,
            self.paths.preferences_path,
            self.paths.team_shared_path,
            *self.paths.list_sessions(),
            self.paths.project_dir / "feedback.jsonl",
            self.paths.project_dir / "references.jsonl",
        ]

        # Filter to existing files
        memory_files = [f for f in memory_files if f.exists()]

        return search_all_memory_files(query, memory_files, config)

    def get_context_for_prompt(
        self,
        max_entries: int = 20,
        max_tokens: int = 2000,
    ) -> str:
        """Get formatted context from memories for prompt injection.

        Args:
            max_entries: Maximum entries to include.
            max_tokens: Approximate token limit.

        Returns:
            Formatted context string.
        """
        lines: list[str] = []

        # Preferences
        prefs = self.get_preferences()[:5]
        if prefs:
            lines.append("## User Preferences")
            for p in prefs:
                lines.append(f"- **{p.key}**: {p.content}")
            lines.append("")

        # Recent decisions
        decisions = self.get_decisions()[:5]
        if decisions:
            lines.append("## Recent Decisions")
            for d in decisions:
                lines.append(f"- {d.content}")
            lines.append("")

        # Team context
        team = self.get_team_memories()[:5]
        if team:
            lines.append("## Team Context")
            for t in team:
                lines.append(f"- {t.content[:100]}")
            lines.append("")

        return "\n".join(lines)

    # --- Internal Methods ---

    def _load_entries(self, path: Path) -> list[MemoryEntry]:
        """Load entries from a JSONL file with caching."""
        cache_key = str(path)
        if cache_key in self._cache:
            return self._cache[cache_key]

        entries = load_memories_from_jsonl(path)
        self._cache[cache_key] = entries
        return entries

    def _append_entry(self, path: Path, entry: MemoryEntry) -> None:
        """Append an entry to a JSONL file."""
        with self._lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry.to_dict()) + "\n")

    def _invalidate_cache(self, key: str | None = None) -> None:
        """Invalidate cache for a specific key or all."""
        if key is None:
            self._cache.clear()
        else:
            # Remove all cache entries matching the key pattern
            to_remove = [k for k in self._cache if key in k]
            for k in to_remove:
                del self._cache[k]

    def cleanup_old_sessions(self, max_age_days: int = 30) -> int:
        """Clean up old session files.

        Args:
            max_age_days: Maximum age in days.

        Returns:
            Number of files removed.
        """
        return self.paths.cleanup_old_sessions(max_age_days)

    def stats(self) -> dict[str, Any]:
        """Get statistics about the memory directory.

        Returns:
            Dict with counts and sizes.
        """
        return {
            "decisions": len(self.get_decisions()),
            "preferences": len(self.get_preferences()),
            "team_memories": len(self.get_team_memories()),
            "sessions": len(self.paths.list_sessions()),
            "feedback": len(self.get_feedback()),
            "references": len(self.get_references()),
        }
