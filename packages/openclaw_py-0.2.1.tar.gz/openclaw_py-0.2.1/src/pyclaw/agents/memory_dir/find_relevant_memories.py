"""Find relevant memories — relevance scoring and retrieval.

Implements memory retrieval with:
- Text matching (FTS-style)
- Semantic similarity (if embeddings available)
- Temporal relevance decay
- Combined ranking with MMR-like diversification
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from pyclaw.agents.memory_dir.memory_age import (
    DecayConfig,
    PriorityWeights,
    calculate_relevance_score,
    rank_memories_by_relevance,
)
from pyclaw.agents.memory_dir.memory_types import MemoryEntry, MemoryType


@dataclass
class SearchConfig:
    """Configuration for memory search."""

    max_results: int = 20
    min_relevance: float = 0.2
    text_match_weight: float = 0.4
    relevance_weight: float = 0.6
    include_expired: bool = False


def extract_keywords(query: str) -> list[str]:
    """Extract keywords from a query string.

    Args:
        query: The search query.

    Returns:
        List of lowercase keywords.
    """
    # Remove common stop words
    stop_words = {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "must",
        "shall",
        "can",
        "need",
        "dare",
        "ought",
        "used",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "as",
        "into",
        "through",
        "during",
        "before",
        "after",
        "above",
        "below",
        "between",
        "under",
        "again",
        "further",
        "then",
        "once",
        "and",
        "but",
        "or",
        "nor",
        "so",
        "yet",
        "both",
        "either",
        "neither",
        "not",
        "only",
        "own",
        "same",
        "than",
        "too",
        "very",
        "just",
    }

    # Tokenize and filter
    words = re.findall(r"\b\w+\b", query.lower())
    return [w for w in words if w not in stop_words and len(w) > 2]


def calculate_text_match_score(
    entry: MemoryEntry,
    keywords: list[str],
) -> float:
    """Calculate text match score for an entry.

    Args:
        entry: Memory entry to score.
        keywords: Search keywords.

    Returns:
        Match score between 0 and 1.
    """
    if not keywords:
        return 0.0

    content_lower = entry.content.lower()
    key_lower = entry.key.lower()

    matches: float = 0
    for keyword in keywords:
        if keyword in content_lower or keyword in key_lower:
            matches += 1
        # Also check tags
        for tag in entry.tags:
            if keyword in tag.lower():
                matches += 0.5
                break

    return min(1.0, matches / len(keywords))


def find_relevant_memories(
    query: str,
    entries: list[MemoryEntry],
    config: SearchConfig | None = None,
    decay_config: DecayConfig | None = None,
    priority_weights: PriorityWeights | None = None,
) -> list[MemoryEntry]:
    """Find memories relevant to a query.

    Combines text matching with temporal relevance scoring.

    Args:
        query: The search query.
        entries: All memory entries to search.
        config: Search configuration.
        decay_config: Decay configuration.
        priority_weights: Priority weight configuration.

    Returns:
        Ranked list of relevant memories.
    """
    config = config or SearchConfig()
    keywords = extract_keywords(query)

    # Filter expired entries
    if not config.include_expired:
        entries = [e for e in entries if not e.is_expired()]

    # Score each entry
    scored_entries: list[tuple[MemoryEntry, float]] = []

    for entry in entries:
        # Calculate relevance score (temporal)
        relevance_score = calculate_relevance_score(entry, decay_config, priority_weights)

        # Calculate text match score
        text_score = calculate_text_match_score(entry, keywords)

        # Skip entries with no text match
        if text_score == 0:
            continue

        # Combine scores
        combined = config.text_match_weight * text_score + config.relevance_weight * relevance_score

        # Only include if above minimum
        if combined >= config.min_relevance:
            scored_entries.append((entry, combined))

    # Sort by combined score
    scored_entries.sort(key=lambda x: x[1], reverse=True)

    # Return top results
    return [e for e, _ in scored_entries[: config.max_results]]


def find_memories_by_type(
    memory_type: MemoryType,
    entries: list[MemoryEntry],
    config: SearchConfig | None = None,
) -> list[MemoryEntry]:
    """Find memories of a specific type.

    Args:
        memory_type: Type of memories to find.
        entries: All memory entries.
        config: Search configuration.

    Returns:
        Filtered and ranked memories.
    """
    config = config or SearchConfig()

    # Filter by type
    filtered = [e for e in entries if e.memory_type == memory_type]

    # Filter expired
    if not config.include_expired:
        filtered = [e for e in filtered if not e.is_expired()]

    # Rank by relevance
    return rank_memories_by_relevance(filtered)[: config.max_results]


def find_memories_by_tags(
    tags: list[str],
    entries: list[MemoryEntry],
    match_all: bool = False,
    config: SearchConfig | None = None,
) -> list[MemoryEntry]:
    """Find memories matching tags.

    Args:
        tags: Tags to match.
        entries: All memory entries.
        match_all: If True, all tags must match. If False, any tag matches.
        config: Search configuration.

    Returns:
        Filtered and ranked memories.
    """
    config = config or SearchConfig()
    tags_lower = [t.lower() for t in tags]

    def matches(entry: MemoryEntry) -> bool:
        entry_tags = [t.lower() for t in entry.tags]
        if match_all:
            return all(t in entry_tags for t in tags_lower)
        else:
            return any(t in entry_tags for t in tags_lower)

    filtered = [e for e in entries if matches(e)]

    if not config.include_expired:
        filtered = [e for e in filtered if not e.is_expired()]

    return rank_memories_by_relevance(filtered)[: config.max_results]


def load_memories_from_jsonl(path: Path) -> list[MemoryEntry]:
    """Load memories from a JSONL file.

    Args:
        path: Path to the JSONL file.

    Returns:
        List of memory entries.
    """
    if not path.exists():
        return []

    entries = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    data = json.loads(line)
                    entries.append(MemoryEntry.from_dict(data))
                except json.JSONDecodeError:
                    continue

    return entries


def save_memories_to_jsonl(
    entries: list[MemoryEntry],
    path: Path,
    append: bool = False,
) -> None:
    """Save memories to a JSONL file.

    Args:
        entries: Memory entries to save.
        path: Path to the JSONL file.
        append: If True, append to existing file.
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    mode = "a" if append else "w"
    with open(path, mode, encoding="utf-8") as f:
        for entry in entries:
            f.write(json.dumps(entry.to_dict()) + "\n")


def search_all_memory_files(
    query: str,
    memory_files: list[Path],
    config: SearchConfig | None = None,
) -> list[MemoryEntry]:
    """Search across multiple memory files.

    Args:
        query: Search query.
        memory_files: List of JSONL paths to search.
        config: Search configuration.

    Returns:
        Ranked list of relevant memories from all files.
    """
    all_entries: list[MemoryEntry] = []

    for path in memory_files:
        all_entries.extend(load_memories_from_jsonl(path))

    return find_relevant_memories(query, all_entries, config)
