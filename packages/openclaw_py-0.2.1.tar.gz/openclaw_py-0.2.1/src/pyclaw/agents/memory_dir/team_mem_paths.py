"""Team memory paths — path resolution for team-based memory sharing.

Provides path management for team memories, supporting:
- Multiple teams with isolated memory spaces
- Team member identification
- Cross-team memory access control
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar


@dataclass
class TeamConfig:
    """Configuration for a team's memory access."""

    team_id: str
    team_name: str = ""
    members: list[str] = field(default_factory=list)
    created_at: str = ""

    def to_dict(self) -> dict[str, str | list[str]]:
        """Serialize to dictionary."""
        return {
            "team_id": self.team_id,
            "team_name": self.team_name,
            "members": self.members,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, str | list[str]]) -> TeamConfig:
        """Deserialize from dictionary."""
        return cls(
            team_id=str(data.get("team_id", "")),
            team_name=str(data.get("team_name", "")),
            members=list(data.get("members", [])),
            created_at=str(data.get("created_at", "")),
        )


@dataclass
class TeamMemPaths:
    """Manages paths for team-based memory sharing.

    Directory structure:
    .claude/memory/teams/
    ├── {team_id}/
    │   ├── shared.jsonl      # Shared team memories
    │   ├── config.json       # Team configuration
    │   └── members/
    │       └── {member_id}.jsonl  # Member-specific memories
    """

    base_dir: Path
    TEAMS_DIR_NAME: ClassVar[str] = "teams"

    @classmethod
    def from_memory_root(cls, memory_root: Path) -> TeamMemPaths:
        """Create from memory root directory.

        Args:
            memory_root: The .claude/memory directory.

        Returns:
            TeamMemPaths instance.
        """
        return cls(base_dir=memory_root)

    @property
    def teams_dir(self) -> Path:
        """Get the teams directory."""
        return self.base_dir / self.TEAMS_DIR_NAME

    def team_dir(self, team_id: str) -> Path:
        """Get directory for a specific team.

        Args:
            team_id: Team identifier.

        Returns:
            Path to team directory.
        """
        return self.teams_dir / team_id

    def team_shared_path(self, team_id: str) -> Path:
        """Get the shared memory file for a team.

        Args:
            team_id: Team identifier.

        Returns:
            Path to shared.jsonl.
        """
        return self.team_dir(team_id) / "shared.jsonl"

    def team_config_path(self, team_id: str) -> Path:
        """Get the config file for a team.

        Args:
            team_id: Team identifier.

        Returns:
            Path to config.json.
        """
        return self.team_dir(team_id) / "config.json"

    def member_path(self, team_id: str, member_id: str) -> Path:
        """Get the memory file for a team member.

        Args:
            team_id: Team identifier.
            member_id: Member identifier.

        Returns:
            Path to member's memory file.
        """
        return self.team_dir(team_id) / "members" / f"{member_id}.jsonl"

    def list_teams(self) -> list[str]:
        """List all team IDs.

        Returns:
            List of team identifiers.
        """
        if not self.teams_dir.exists():
            return []
        return [d.name for d in self.teams_dir.iterdir() if d.is_dir()]

    def ensure_team_dir(self, team_id: str) -> Path:
        """Create team directory structure if needed.

        Args:
            team_id: Team identifier.

        Returns:
            Path to team directory.
        """
        team_dir = self.team_dir(team_id)
        team_dir.mkdir(parents=True, exist_ok=True)
        (team_dir / "members").mkdir(exist_ok=True)
        return team_dir

    def team_exists(self, team_id: str) -> bool:
        """Check if a team directory exists.

        Args:
            team_id: Team identifier.

        Returns:
            True if team exists.
        """
        return self.team_dir(team_id).exists()
