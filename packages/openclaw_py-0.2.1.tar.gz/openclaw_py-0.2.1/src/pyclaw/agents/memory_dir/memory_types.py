"""Memory types — data structures for memory entries.

Defines the core types for memory entries:
- MemoryType: Classification of memory content
- MemoryPriority: Importance level for retrieval
- MemoryEntry: Individual memory record
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any
from uuid import uuid4


class MemoryType(str, Enum):
    """Classification of memory content."""

    USER_PREFERENCE = "user_preference"
    PROJECT_DECISION = "project_decision"
    FEEDBACK_RECORD = "feedback_record"
    REFERENCE_LINK = "reference_link"
    SESSION_CONTEXT = "session_context"
    TEAM_SHARED = "team_shared"


class MemoryPriority(str, Enum):
    """Importance level for memory retrieval."""

    CRITICAL = "critical"  # Always include in context
    HIGH = "high"  # Include unless context is very tight
    MEDIUM = "medium"  # Include if relevant
    LOW = "low"  # Include only if directly relevant
    BACKGROUND = "background"  # Rarely included


@dataclass
class MemoryEntry:
    """Individual memory record with metadata."""

    content: str
    memory_type: MemoryType
    key: str = field(default_factory=lambda: str(uuid4())[:8])
    priority: MemoryPriority = MemoryPriority.MEDIUM
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    expires_at: datetime | None = None
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    # Relevance scoring (computed on retrieval)
    relevance_score: float = 0.0
    age_days: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary for JSON storage."""
        return {
            "key": self.key,
            "content": self.content,
            "memory_type": self.memory_type.value,
            "priority": self.priority.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "tags": self.tags,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryEntry:
        """Deserialize from dictionary."""
        return cls(
            key=data.get("key", str(uuid4())[:8]),
            content=data["content"],
            memory_type=MemoryType(data["memory_type"]),
            priority=MemoryPriority(data.get("priority", "medium")),
            created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else datetime.now(),
            expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
            tags=data.get("tags", []),
            metadata=data.get("metadata", {}),
        )

    def is_expired(self) -> bool:
        """Check if this memory entry has expired."""
        if self.expires_at is None:
            return False
        return datetime.now() > self.expires_at

    def update_age(self) -> float:
        """Update and return the age in days."""
        self.age_days = (datetime.now() - self.created_at).total_seconds() / 86400
        return self.age_days

    def __str__(self) -> str:
        """Human-readable representation."""
        return f"[{self.memory_type.value}] {self.content[:50]}..."


@dataclass
class UserPreference(MemoryEntry):
    """User preference memory entry."""

    memory_type: MemoryType = MemoryType.USER_PREFERENCE

    @classmethod
    def create(cls, key: str, value: str, **kwargs: Any) -> UserPreference:
        """Create a user preference entry."""
        priority = kwargs.pop("priority", MemoryPriority.HIGH)
        return cls(
            key=key,
            content=value,
            memory_type=MemoryType.USER_PREFERENCE,
            priority=priority,
            **kwargs,
        )


@dataclass
class ProjectDecision(MemoryEntry):
    """Project decision memory entry."""

    memory_type: MemoryType = MemoryType.PROJECT_DECISION
    rationale: str = ""

    @classmethod
    def create(
        cls,
        decision: str,
        rationale: str,
        **kwargs: Any,
    ) -> ProjectDecision:
        """Create a project decision entry."""
        # Use provided priority or default to HIGH
        priority = kwargs.pop("priority", MemoryPriority.HIGH)
        return cls(
            content=decision,
            rationale=rationale,
            memory_type=MemoryType.PROJECT_DECISION,
            priority=priority,
            **kwargs,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize with rationale."""
        data = super().to_dict()
        data["rationale"] = self.rationale
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProjectDecision:
        """Deserialize with rationale."""
        entry = super().from_dict(data)
        # Cast to ProjectDecision and add rationale
        decision = cls(
            key=entry.key,
            content=entry.content,
            memory_type=entry.memory_type,
            priority=entry.priority,
            created_at=entry.created_at,
            updated_at=entry.updated_at,
            expires_at=entry.expires_at,
            tags=entry.tags,
            metadata=entry.metadata,
            rationale=data.get("rationale", ""),
        )
        return decision


@dataclass
class FeedbackRecord(MemoryEntry):
    """Feedback record for learning from past interactions."""

    memory_type: MemoryType = MemoryType.FEEDBACK_RECORD
    feedback_type: str = "correction"  # correction, preference, warning
    context: str = ""

    @classmethod
    def create(
        cls,
        feedback: str,
        feedback_type: str,
        context: str = "",
        **kwargs: Any,
    ) -> FeedbackRecord:
        """Create a feedback record."""
        priority = kwargs.pop("priority", MemoryPriority.HIGH)
        return cls(
            content=feedback,
            feedback_type=feedback_type,
            context=context,
            memory_type=MemoryType.FEEDBACK_RECORD,
            priority=priority,
            **kwargs,
        )


@dataclass
class ReferenceLink(MemoryEntry):
    """Reference link to external resources."""

    memory_type: MemoryType = MemoryType.REFERENCE_LINK
    url: str = ""
    description: str = ""

    @classmethod
    def create(
        cls,
        url: str,
        description: str,
        **kwargs: Any,
    ) -> ReferenceLink:
        """Create a reference link."""
        return cls(
            key=kwargs.pop("key", url[:50]),
            content=description,
            url=url,
            description=description,
            memory_type=MemoryType.REFERENCE_LINK,
            **kwargs,
        )
