"""Memory age — temporal decay and relevance calculations.

Implements temporal decay for memory relevance scoring:
- Newer memories have higher relevance
- Different memory types have different decay rates
- Priority affects base relevance score
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

from pyclaw.agents.memory_dir.memory_types import MemoryEntry, MemoryPriority, MemoryType


class DecayStrategy(str, Enum):
    """Decay strategy for memory relevance."""

    EXPONENTIAL = "exponential"  # Fast decay, good for time-sensitive info
    LINEAR = "linear"  # Constant decay rate
    LOGARITHMIC = "logarithmic"  # Slow decay, good for stable knowledge
    STEP = "step"  # Sudden drop after threshold


@dataclass
class DecayConfig:
    """Configuration for memory decay calculation."""

    strategy: DecayStrategy = DecayStrategy.EXPONENTIAL
    half_life_days: float = 30.0  # Time for relevance to drop by half
    minimum_relevance: float = 0.1  # Floor for relevance score

    # Type-specific half-lives (override default)
    type_half_lives: dict[MemoryType, float] = None  # type: ignore

    def __post_init__(self) -> None:
        if self.type_half_lives is None:
            self.type_half_lives = {
                MemoryType.USER_PREFERENCE: 365.0,  # Preferences persist long
                MemoryType.PROJECT_DECISION: 180.0,  # Decisions are important
                MemoryType.FEEDBACK_RECORD: 90.0,  # Feedback decays faster
                MemoryType.REFERENCE_LINK: 120.0,  # References are stable
                MemoryType.SESSION_CONTEXT: 7.0,  # Session context decays fast
                MemoryType.TEAM_SHARED: 90.0,  # Team knowledge is moderate
            }


@dataclass
class PriorityWeights:
    """Base relevance weights by priority."""

    CRITICAL: float = 1.0
    HIGH: float = 0.8
    MEDIUM: float = 0.5
    LOW: float = 0.3
    BACKGROUND: float = 0.1

    def get_weight(self, priority: MemoryPriority) -> float:
        """Get weight for a priority level."""
        return getattr(self, priority.name, 0.5)


def calculate_age_days(entry: MemoryEntry) -> float:
    """Calculate the age of a memory entry in days.

    Args:
        entry: The memory entry.

    Returns:
        Age in days as a float.
    """
    delta = datetime.now() - entry.created_at
    return delta.total_seconds() / 86400


def calculate_decay_factor(
    age_days: float,
    half_life: float,
    strategy: DecayStrategy,
) -> float:
    """Calculate the decay factor based on age and strategy.

    Args:
        age_days: Age of the memory in days.
        half_life: Half-life for decay calculation.
        strategy: Decay strategy to use.

    Returns:
        Decay factor between 0 and 1.
    """
    if age_days <= 0:
        return 1.0

    if strategy == DecayStrategy.EXPONENTIAL:
        # e^(-ln(2) * age / half_life)
        return math.exp(-0.693 * age_days / half_life)

    elif strategy == DecayStrategy.LINEAR:
        # 1 - (age / (2 * half_life))
        return max(0.0, 1.0 - (age_days / (2 * half_life)))

    elif strategy == DecayStrategy.LOGARITHMIC:
        # 1 / (1 + ln(1 + age / half_life))
        return 1.0 / (1.0 + math.log(1.0 + age_days / half_life))

    elif strategy == DecayStrategy.STEP:
        # 1.0 if age < half_life, 0.5 if age < 2*half_life, else 0.1
        if age_days < half_life:
            return 1.0
        elif age_days < 2 * half_life:
            return 0.5
        else:
            return 0.1

    return 1.0


def calculate_relevance_score(
    entry: MemoryEntry,
    config: DecayConfig | None = None,
    priority_weights: PriorityWeights | None = None,
) -> float:
    """Calculate the relevance score for a memory entry.

    The relevance score combines:
    1. Base priority weight
    2. Temporal decay factor
    3. Minimum relevance floor

    Args:
        entry: The memory entry to score.
        config: Decay configuration.
        priority_weights: Priority weight configuration.

    Returns:
        Relevance score between 0 and 1.
    """
    config = config or DecayConfig()
    priority_weights = priority_weights or PriorityWeights()

    # Update age
    entry.update_age()

    # Get base weight from priority
    base_weight = priority_weights.get_weight(entry.priority)

    # Get type-specific half-life
    half_life = config.type_half_lives.get(entry.memory_type, config.half_life_days)

    # Calculate decay factor
    decay = calculate_decay_factor(entry.age_days, half_life, config.strategy)

    # Combine for final score
    score = base_weight * decay

    # Apply floor
    score = max(score, config.minimum_relevance)

    entry.relevance_score = score
    return score


def rank_memories_by_relevance(
    entries: list[MemoryEntry],
    config: DecayConfig | None = None,
    priority_weights: PriorityWeights | None = None,
) -> list[MemoryEntry]:
    """Rank memory entries by relevance score.

    Args:
        entries: Memory entries to rank.
        config: Decay configuration.
        priority_weights: Priority weight configuration.

    Returns:
        Entries sorted by relevance score (highest first).
    """
    # Calculate scores
    for entry in entries:
        calculate_relevance_score(entry, config, priority_weights)

    # Sort by score descending
    return sorted(entries, key=lambda e: e.relevance_score, reverse=True)


def filter_by_relevance_threshold(
    entries: list[MemoryEntry],
    threshold: float = 0.3,
) -> list[MemoryEntry]:
    """Filter entries by minimum relevance score.

    Args:
        entries: Memory entries to filter.
        threshold: Minimum relevance score.

    Returns:
        Entries with relevance >= threshold.
    """
    return [e for e in entries if e.relevance_score >= threshold]
