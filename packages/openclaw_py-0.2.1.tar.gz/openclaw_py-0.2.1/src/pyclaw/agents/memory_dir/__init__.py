"""Memory directory module — structured memory storage with project/session/team levels.

This module provides a structured memory directory hierarchy:
.claude/memory/
├── project/          # Project-level decisions
├── session/          # Session-specific memories
├── team/             # Shared team memories
└── user/             # User preferences
"""

from pyclaw.agents.memory_dir.bm25 import (
    BM25Config,
    BM25Scorer,
    calculate_bm25_score,
    combine_relevance_score,
)
from pyclaw.agents.memory_dir.find_relevant_memories import (
    SearchConfig,
    find_memories_by_tags,
    find_memories_by_type,
    find_relevant_memories,
)
from pyclaw.agents.memory_dir.memdir import MemoryDirectory
from pyclaw.agents.memory_dir.memory_age import (
    DecayConfig,
    DecayStrategy,
    PriorityWeights,
    calculate_relevance_score,
)
from pyclaw.agents.memory_dir.memory_types import (
    FeedbackRecord,
    MemoryEntry,
    MemoryPriority,
    MemoryType,
    ProjectDecision,
    ReferenceLink,
    UserPreference,
)
from pyclaw.agents.memory_dir.paths import MemoryPaths
from pyclaw.agents.memory_dir.scanner import (
    InvertedIndex,
    MemoryScanner,
    ScanResult,
    scan_memory_directory,
)
from pyclaw.agents.memory_dir.team_mem_paths import TeamConfig, TeamMemPaths
from pyclaw.agents.memory_dir.team_mem_prompts import (
    TeamPromptConfig,
    build_full_team_prompt,
    build_team_context_prompt,
)

__all__ = [
    # Core classes
    "MemoryDirectory",
    "MemoryEntry",
    "MemoryPaths",
    "MemoryPriority",
    "MemoryType",
    # Memory types
    "FeedbackRecord",
    "ProjectDecision",
    "ReferenceLink",
    "UserPreference",
    # Age and relevance
    "DecayConfig",
    "DecayStrategy",
    "PriorityWeights",
    "calculate_relevance_score",
    # Search
    "SearchConfig",
    "find_memories_by_tags",
    "find_memories_by_type",
    "find_relevant_memories",
    # Team memory
    "TeamConfig",
    "TeamMemPaths",
    "TeamPromptConfig",
    "build_full_team_prompt",
    "build_team_context_prompt",
    # Scanner
    "InvertedIndex",
    "MemoryScanner",
    "ScanResult",
    "scan_memory_directory",
    # BM25
    "BM25Config",
    "BM25Scorer",
    "calculate_bm25_score",
    "combine_relevance_score",
]
