"""BM25 scorer — text relevance scoring using BM25 algorithm.

Implements BM25 (Best Matching 25) algorithm for text relevance:
- Probabilistic ranking function
- Document length normalization
- Configurable parameters (k1, b)
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass

from pyclaw.agents.memory_dir.memory_types import MemoryEntry


@dataclass
class BM25Config:
    """Configuration for BM25 scoring."""

    k1: float = 1.5  # Term frequency saturation parameter
    b: float = 0.75  # Document length normalization
    min_score: float = 0.0  # Minimum score to include in results


@dataclass
class DocumentStats:
    """Statistics for a single document."""

    doc_id: str
    terms: dict[str, int]  # term -> frequency
    length: int
    entry: MemoryEntry | None = None


class BM25Scorer:
    """BM25 relevance scorer.

    Usage:
        scorer = BM25Scorer()
        scorer.index_documents(entries)
        scores = scorer.score(query_terms)
    """

    def __init__(self, config: BM25Config | None = None) -> None:
        self._config = config or BM25Config()
        self._documents: dict[str, DocumentStats] = {}
        self._doc_freq: dict[str, int] = {}  # term -> document count
        self._total_docs = 0
        self._avg_doc_length = 0.0
        self._total_length = 0

    @property
    def config(self) -> BM25Config:
        return self._config

    @property
    def document_count(self) -> int:
        return self._total_docs

    @property
    def avg_doc_length(self) -> float:
        return self._avg_doc_length

    def tokenize(self, text: str) -> list[str]:
        """Tokenize text into terms.

        Args:
            text: Text to tokenize.

        Returns:
            List of lowercase terms.
        """
        words = re.findall(r"\b\w+\b", text.lower())
        return [w for w in words if len(w) > 2]

    def index_documents(self, entries: list[MemoryEntry]) -> None:
        """Index a list of documents.

        Args:
            entries: Memory entries to index.
        """
        for entry in entries:
            self.add_document(entry)

        # Calculate average document length
        if self._total_docs > 0:
            self._avg_doc_length = self._total_length / self._total_docs

    def add_document(self, entry: MemoryEntry) -> None:
        """Add a single document to the index.

        Args:
            entry: Memory entry to add.
        """
        # Combine content and key for indexing
        text = f"{entry.content} {entry.key}"
        terms = self.tokenize(text)

        # Count term frequencies
        term_freqs: dict[str, int] = {}
        for term in terms:
            term_freqs[term] = term_freqs.get(term, 0) + 1

        # Create document stats - use key as doc_id
        doc_key = entry.key
        doc_stats = DocumentStats(
            doc_id=doc_key,
            terms=term_freqs,
            length=len(terms),
            entry=entry,
        )

        # Update document frequency
        for term in term_freqs:
            self._doc_freq[term] = self._doc_freq.get(term, 0) + 1

        # Update stats
        self._documents[doc_key] = doc_stats
        self._total_docs = len(self._documents)
        self._total_length += len(terms)

        # Update average document length
        if self._total_docs > 0:
            self._avg_doc_length = self._total_length / self._total_docs

    def remove_document(self, doc_id: str) -> None:
        """Remove a document from the index.

        Args:
            doc_id: Document ID to remove.
        """
        if doc_id not in self._documents:
            return

        doc = self._documents[doc_id]

        # Update document frequency
        for term in doc.terms:
            if term in self._doc_freq:
                self._doc_freq[term] -= 1
                if self._doc_freq[term] <= 0:
                    del self._doc_freq[term]

        # Update stats
        self._total_length -= doc.length
        del self._documents[doc_id]
        self._total_docs = len(self._documents)

        if self._total_docs > 0:
            self._avg_doc_length = self._total_length / self._total_docs

    def score(
        self,
        query: str,
        entries: list[MemoryEntry] | None = None,
    ) -> list[tuple[MemoryEntry, float]]:
        """Score documents against a query.

        Args:
            query: Search query.
            entries: Optional list of entries to score. If None, scores all indexed.

        Returns:
            List of (entry, score) tuples sorted by score descending.
        """
        query_terms = self.tokenize(query)
        if not query_terms:
            return []

        # Determine which documents to score
        if entries:
            docs_to_score = [self._documents.get(e.key) for e in entries if e.key in self._documents]
            docs_to_score = [d for d in docs_to_score if d is not None]
        else:
            docs_to_score = list(self._documents.values())

        # Score each document
        scored: list[tuple[DocumentStats, float]] = []
        for doc in docs_to_score:
            # Type narrowing: doc is guaranteed non-None after filtering
            if doc is None:
                continue
            score = self._score_document(doc, query_terms)
            if score > self._config.min_score and doc.entry:
                scored.append((doc, score))

        # Sort by score descending
        scored.sort(key=lambda x: x[1], reverse=True)

        return [(doc.entry, score) for doc, score in scored]

    def _score_document(
        self,
        doc: DocumentStats,
        query_terms: list[str],
    ) -> float:
        """Calculate BM25 score for a document.

        Args:
            doc: Document to score.
            query_terms: Query terms.

        Returns:
            BM25 score.
        """
        if self._total_docs == 0 or self._avg_doc_length == 0:
            return 0.0

        score = 0.0
        k1 = self._config.k1
        b = self._config.b

        for term in query_terms:
            if term not in doc.terms:
                continue

            # IDF calculation
            df = self._doc_freq.get(term, 0)
            if df == 0:
                continue

            idf = math.log((self._total_docs - df + 0.5) / (df + 0.5) + 1)

            # TF calculation with saturation
            tf = doc.terms[term]
            tf_component = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * (doc.length / self._avg_doc_length)))

            score += idf * tf_component

        return score

    def get_term_doc_freq(self, term: str) -> int:
        """Get document frequency for a term.

        Args:
            term: Term to look up.

        Returns:
            Number of documents containing the term.
        """
        return self._doc_freq.get(term, 0)


def calculate_bm25_score(
    entry: MemoryEntry,
    query: str,
    scorer: BM25Scorer | None = None,
    config: BM25Config | None = None,
) -> float:
    """Calculate BM25 score for a single entry.

    Convenience function for single-entry scoring.

    Args:
        entry: Memory entry to score.
        query: Search query.
        scorer: Optional pre-built scorer. If None, creates temporary.
        config: BM25 configuration.

    Returns:
        BM25 score.
    """
    if scorer is None:
        scorer = BM25Scorer(config)
        scorer.add_document(entry)

    results = scorer.score(query, [entry])
    if results:
        return results[0][1]
    return 0.0


def combine_relevance_score(
    entry: MemoryEntry,
    query: str,
    bm25_weight: float = 0.5,
    decay_weight: float = 0.5,
    decay_score: float | None = None,
    scorer: BM25Scorer | None = None,
) -> float:
    """Combine BM25 text score with temporal decay score.

    Args:
        entry: Memory entry to score.
        query: Search query.
        bm25_weight: Weight for BM25 component.
        decay_weight: Weight for decay component.
        decay_score: Pre-calculated decay score. If None, uses entry.relevance_score.
        scorer: Optional pre-built BM25 scorer.

    Returns:
        Combined relevance score.
    """
    # Get BM25 score
    bm25_score = calculate_bm25_score(entry, query, scorer)

    # Get decay score
    if decay_score is None:
        decay_score = entry.relevance_score or 0.5

    # Normalize BM25 score to 0-1 range (using sigmoid)
    normalized_bm25 = 1.0 / (1.0 + math.exp(-bm25_score / 10))

    # Combine weighted scores
    total_weight = bm25_weight + decay_weight
    return (bm25_weight * normalized_bm25 + decay_weight * decay_score) / total_weight
