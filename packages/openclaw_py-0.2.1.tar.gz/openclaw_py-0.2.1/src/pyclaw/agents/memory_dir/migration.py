"""Migration script — migrate from SQLite to memory directory structure.

Provides migration utilities to move from the existing SQLite-based
memory storage to the new structured memory directory.

Usage:
    from pyclaw.agents.memory_dir.migration import migrate_to_directory

    migrate_to_directory(
        workspace_dir=Path("./workspace"),
        dry_run=True,  # Preview changes
    )
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class MigrationStats:
    """Statistics from migration."""

    preferences_migrated: int = 0
    decisions_migrated: int = 0
    sessions_migrated: int = 0
    general_memories_migrated: int = 0
    errors: list[str] = None  # type: ignore

    def __post_init__(self) -> None:
        if self.errors is None:
            self.errors = []

    @property
    def total(self) -> int:
        return (
            self.preferences_migrated
            + self.decisions_migrated
            + self.sessions_migrated
            + self.general_memories_migrated
        )

    @property
    def success(self) -> bool:
        return len(self.errors) == 0


def migrate_to_directory(
    workspace_dir: Path,
    *,
    dry_run: bool = False,
    backup: bool = True,
) -> MigrationStats:
    """Migrate from SQLite to memory directory structure.

    Args:
        workspace_dir: The workspace directory.
        dry_run: If True, don't write files, just report what would be done.
        backup: If True, create backup of SQLite before migration.

    Returns:
        MigrationStats with counts and any errors.
    """
    from pyclaw.agents.memory_dir import MemoryDirectory, MemoryPaths
    from pyclaw.memory.store import MemoryStore

    stats = MigrationStats()

    # Locate SQLite database
    db_path = workspace_dir / "memory.db"
    if not db_path.exists():
        logger.info("No SQLite database found at %s, nothing to migrate", db_path)
        return stats

    # Create backup if requested
    if backup and not dry_run:
        backup_path = workspace_dir / f"memory.db.backup.{datetime.now().strftime('%Y%m%d%H%M%S')}"
        db_path.rename(backup_path)
        # Copy back for reading
        import shutil

        shutil.copy(backup_path, db_path)
        logger.info("Created backup at %s", backup_path)

    # Open SQLite store
    store = MemoryStore(db_path)
    store.open()

    try:
        # Create memory directory
        paths = MemoryPaths.from_project_root(workspace_dir)
        memdir = MemoryDirectory(paths=paths)

        if dry_run:
            logger.info("DRY RUN: Would create memory directory at %s", paths.memory_root)

        # Migrate preferences
        prefs = _migrate_preferences(store, memdir, dry_run)
        stats.preferences_migrated = prefs

        # Migrate decisions
        decisions = _migrate_decisions(store, memdir, dry_run)
        stats.decisions_migrated = decisions

        # Migrate general memories
        general = _migrate_general_memories(store, memdir, dry_run)
        stats.general_memories_migrated = general

        logger.info(
            "Migration %s: %d preferences, %d decisions, %d general",
            "preview" if dry_run else "complete",
            stats.preferences_migrated,
            stats.decisions_migrated,
            stats.general_memories_migrated,
        )

    except Exception as e:
        stats.errors.append(str(e))
        logger.error("Migration failed: %s", e)

    finally:
        store.close()

    return stats


def _migrate_preferences(
    store: Any,
    memdir: Any,
    dry_run: bool,
) -> int:
    """Migrate user preferences."""
    count = 0

    try:
        # Try to get preferences from long-term memory if available
        from pyclaw.memory.persistence import LongTermMemory

        ltm_path = memdir.paths.base_dir / memdir.paths.DEFAULT_BASE_NAME / "long_term_memory.json"
        if ltm_path.exists():
            ltm = LongTermMemory(memdir.paths.base_dir, store)
            prefs = ltm.get_all_preferences()

            for key, value in prefs.items():
                if not dry_run:
                    memdir.set_preference(key, value)
                count += 1
                logger.debug("Migrated preference: %s", key)

    except Exception as e:
        logger.warning("Failed to migrate preferences: %s", e)

    return count


def _migrate_decisions(
    store: Any,
    memdir: Any,
    dry_run: bool,
) -> int:
    """Migrate project decisions."""
    count = 0

    try:
        from pyclaw.memory.persistence import LongTermMemory

        ltm_path = memdir.paths.base_dir / memdir.paths.DEFAULT_BASE_NAME / "long_term_memory.json"
        if ltm_path.exists():
            ltm = LongTermMemory(memdir.paths.base_dir, store)
            decisions = ltm.get_all_decisions()

            for decision in decisions:
                if not dry_run:
                    memdir.add_decision(
                        decision=decision.get("content", str(decision)),
                        rationale=decision.get("rationale", ""),
                    )
                count += 1
                logger.debug("Migrated decision: %s", decision.get("content", "")[:50])

    except Exception as e:
        logger.warning("Failed to migrate decisions: %s", e)

    return count


def _migrate_general_memories(
    store: Any,
    memdir: Any,
    dry_run: bool,
) -> int:
    """Migrate general memories from SQLite."""
    count = 0

    try:
        # Get all memories from SQLite
        memories = store.get_all() if hasattr(store, "get_all") else []

        for mem in memories:
            if not dry_run:
                from pyclaw.agents.memory_dir import MemoryEntry, MemoryType

                entry = MemoryEntry(
                    content=mem.get("content", ""),
                    memory_type=MemoryType.SESSION_CONTEXT,
                    tags=mem.get("tags", []),
                )
                memdir._append_entry(memdir.paths.project_dir / "migrated.jsonl", entry)

            count += 1

    except Exception as e:
        logger.warning("Failed to migrate general memories: %s", e)

    return count


def verify_migration(
    workspace_dir: Path,
) -> dict[str, Any]:
    """Verify migration was successful.

    Args:
        workspace_dir: The workspace directory.

    Returns:
        Dict with verification results.
    """
    from pyclaw.agents.memory_dir import MemoryDirectory, MemoryPaths
    from pyclaw.memory.store import MemoryStore

    results: dict[str, Any] = {
        "sqlite_count": 0,
        "directory_count": 0,
        "match": False,
        "errors": [],
    }

    # Count SQLite records
    db_path = workspace_dir / "memory.db"
    if db_path.exists():
        try:
            store = MemoryStore(db_path)
            store.open()
            results["sqlite_count"] = store.count()
            store.close()
        except Exception as e:
            results["errors"].append(f"SQLite error: {e}")

    # Count directory records
    try:
        paths = MemoryPaths.from_project_root(workspace_dir)
        memdir = MemoryDirectory(paths=paths)
        stats = memdir.stats()
        results["directory_count"] = sum(
            [
                stats.get("decisions", 0),
                stats.get("preferences", 0),
                stats.get("team_memories", 0),
            ]
        )
    except Exception as e:
        results["errors"].append(f"Directory error: {e}")

    results["match"] = results["sqlite_count"] <= results["directory_count"]

    return results
