"""Memory scanner — scan and index memory entries.

Implements memory scanning with:
- Directory scanning for JSONL files
- Entry parsing and validation
- Inverted index building for fast text search
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pyclaw.agents.memory_dir.memory_types import MemoryEntry

logger = logging.getLogger(__name__)


@dataclass
class ScanResult:
    """Result of scanning a memory directory."""

    files_scanned: int = 0
    entries_found: int = 0
    entries_parsed: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return len(self.errors) == 0


@dataclass
class InvertedIndex:
    """Inverted index for fast term-based searching."""

    # term -> set of entry IDs
    index: dict[str, set[str]] = field(default_factory=dict)
    # entry_id -> entry data
    entries: dict[str, MemoryEntry] = field(default_factory=dict)
    # term -> document frequency
    doc_freq: dict[str, int] = field(default_factory=dict)
    # total documents
    total_docs: int = 0

    def add_entry(self, entry: MemoryEntry) -> None:
        """Add an entry to the index."""
        entry_key = entry.key
        if entry_key in self.entries:
            # Remove old terms first
            self._remove_entry_terms(entry_key)

        self.entries[entry_key] = entry
        self.total_docs = len(self.entries)

        # Extract terms from content
        terms = self._tokenize(entry.content)
        terms.extend(self._tokenize(entry.key))

        # Update index
        entry_terms: set[str] = set()
        for term in terms:
            if term not in self.index:
                self.index[term] = set()
            self.index[term].add(entry_key)
            entry_terms.add(term)

        # Update document frequency
        for term in entry_terms:
            self.doc_freq[term] = self.doc_freq.get(term, 0) + 1

    def remove_entry(self, entry_key: str) -> None:
        """Remove an entry from the index."""
        if entry_key not in self.entries:
            return

        self._remove_entry_terms(entry_key)
        del self.entries[entry_key]
        self.total_docs = len(self.entries)

    def _remove_entry_terms(self, entry_key: str) -> None:
        """Remove terms associated with an entry."""
        if entry_key not in self.entries:
            return

        old_entry = self.entries[entry_key]
        old_terms = self._tokenize(old_entry.content)
        old_terms.extend(self._tokenize(old_entry.key))

        for term in set(old_terms):
            if term in self.index:
                self.index[term].discard(entry_key)
                if not self.index[term]:
                    del self.index[term]
                    self.doc_freq.pop(term, None)

    def search(self, query: str) -> set[str]:
        """Search for entries matching query terms."""
        terms = self._tokenize(query)
        if not terms:
            return set()

        result: set[str] | None = None
        for term in terms:
            if term in self.index:
                if result is None:
                    result = self.index[term].copy()
                else:
                    result &= self.index[term]

        return result or set()

    def _tokenize(self, text: str) -> list[str]:
        """Tokenize text into terms."""
        words = re.findall(r"\b\w+\b", text.lower())
        return [w for w in words if len(w) > 2]

    def to_dict(self) -> dict[str, Any]:
        """Serialize index to dict."""
        return {
            "index": {k: list(v) for k, v in self.index.items()},
            "entries": {k: v.to_dict() for k, v in self.entries.items()},
            "doc_freq": self.doc_freq,
            "total_docs": self.total_docs,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> InvertedIndex:
        """Deserialize index from dict."""
        idx = cls()
        idx.index = {k: set(v) for k, v in data.get("index", {}).items()}
        idx.entries = {k: MemoryEntry.from_dict(v) for k, v in data.get("entries", {}).items()}
        idx.doc_freq = data.get("doc_freq", {})
        idx.total_docs = data.get("total_docs", 0)
        return idx


class MemoryScanner:
    """Scans memory directories and builds search index."""

    def __init__(
        self,
        memory_root: Path,
        index_path: Path | None = None,
    ) -> None:
        self._root = Path(memory_root)
        self._index_path = index_path or (self._root / "index.json")
        self._index = InvertedIndex()

    @property
    def index(self) -> InvertedIndex:
        return self._index

    def scan_directory(
        self,
        directory: Path | None = None,
        pattern: str = "*.jsonl",
    ) -> ScanResult:
        """Scan a directory for memory files.

        Args:
            directory: Directory to scan. Defaults to memory root.
            pattern: File pattern to match.

        Returns:
            ScanResult with statistics.
        """
        target = directory or self._root
        result = ScanResult()

        for file_path in target.rglob(pattern):
            result.files_scanned += 1
            file_result = self.scan_file(file_path)
            result.entries_found += file_result.entries_found
            result.entries_parsed += file_result.entries_parsed
            result.errors.extend(file_result.errors)

        return result

    def scan_file(self, file_path: Path) -> ScanResult:
        """Scan a single JSONL file.

        Args:
            file_path: Path to the JSONL file.

        Returns:
            ScanResult with statistics.
        """
        result = ScanResult(files_scanned=1)

        if not file_path.exists():
            result.errors.append(f"File not found: {file_path}")
            return result

        try:
            with open(file_path, encoding="utf-8") as f:
                for line_no, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue

                    result.entries_found += 1
                    entry = self.parse_memory_entry(line)

                    if entry:
                        result.entries_parsed += 1
                        self._index.add_entry(entry)
                    else:
                        result.errors.append(f"Failed to parse line {line_no} in {file_path}")

        except Exception as e:
            result.errors.append(f"Error reading {file_path}: {e}")

        return result

    def parse_memory_entry(self, line: str) -> MemoryEntry | None:
        """Parse a JSONL line into a MemoryEntry.

        Args:
            line: JSON line to parse.

        Returns:
            MemoryEntry or None if parsing fails.
        """
        try:
            data = json.loads(line)
            return MemoryEntry.from_dict(data)
        except json.JSONDecodeError as e:
            logger.warning("Failed to parse entry: %s", e)
            return None
        except (KeyError, TypeError) as e:
            logger.warning("Invalid entry format: %s", e)
            return None

    def build_index(self, incremental: bool = False) -> ScanResult:
        """Build or rebuild the inverted index.

        Args:
            incremental: If True, only add new entries.

        Returns:
            ScanResult with statistics.
        """
        if not incremental:
            self._index = InvertedIndex()

        return self.scan_directory()

    def save_index(self) -> bool:
        """Save the index to disk.

        Returns:
            True if successful.
        """
        try:
            self._index_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._index_path, "w", encoding="utf-8") as f:
                json.dump(self._index.to_dict(), f)
            return True
        except Exception as e:
            logger.error("Failed to save index: %s", e)
            return False

    def load_index(self) -> bool:
        """Load the index from disk.

        Returns:
            True if successful.
        """
        if not self._index_path.exists():
            return False

        try:
            with open(self._index_path, encoding="utf-8") as f:
                data = json.load(f)
            self._index = InvertedIndex.from_dict(data)
            return True
        except Exception as e:
            logger.error("Failed to load index: %s", e)
            return False


def scan_memory_directory(
    memory_root: Path,
    index_path: Path | None = None,
    incremental: bool = False,
) -> tuple[ScanResult, InvertedIndex]:
    """Scan a memory directory and return results.

    Args:
        memory_root: Root directory of memory storage.
        index_path: Optional path for index persistence.
        incremental: If True, only add new entries.

    Returns:
        Tuple of (ScanResult, InvertedIndex).
    """
    scanner = MemoryScanner(memory_root, index_path)

    if incremental and scanner.load_index():
        # Only scan files modified since last index
        pass  # For now, just rebuild

    result = scanner.build_index(incremental)
    return result, scanner.index
