"""Team memory prompts — prompt generation for team-based memory context.

Generates formatted prompts from team memories for:
- Team context injection
- Member-specific context
- Cross-team collaboration
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pyclaw.agents.memory_dir.find_relevant_memories import load_memories_from_jsonl
from pyclaw.agents.memory_dir.team_mem_paths import TeamMemPaths


@dataclass
class TeamPromptConfig:
    """Configuration for team prompt generation."""

    max_entries: int = 10
    max_content_length: int = 200
    include_member_info: bool = True
    include_timestamps: bool = False


def build_team_context_prompt(
    team_id: str,
    paths: TeamMemPaths,
    config: TeamPromptConfig | None = None,
) -> str:
    """Build a context prompt from team memories.

    Args:
        team_id: Team identifier.
        paths: Team memory paths.
        config: Prompt configuration.

    Returns:
        Formatted context string.
    """
    config = config or TeamPromptConfig()

    if not paths.team_exists(team_id):
        return ""

    shared_path = paths.team_shared_path(team_id)
    entries = load_memories_from_jsonl(shared_path)[: config.max_entries]

    if not entries:
        return ""

    lines = [
        "## Team Context",
        "",
        "The following context is shared by your team:",
        "",
    ]

    for entry in entries:
        content = entry.content[: config.max_content_length]
        if len(entry.content) > config.max_content_length:
            content += "..."

        if config.include_member_info and entry.metadata.get("member"):
            lines.append(f"- [{entry.metadata['member']}] {content}")
        else:
            lines.append(f"- {content}")

    lines.append("")
    return "\n".join(lines)


def build_member_context_prompt(
    team_id: str,
    member_id: str,
    paths: TeamMemPaths,
    config: TeamPromptConfig | None = None,
) -> str:
    """Build a context prompt from a team member's memories.

    Args:
        team_id: Team identifier.
        member_id: Member identifier.
        paths: Team memory paths.
        config: Prompt configuration.

    Returns:
        Formatted context string.
    """
    config = config or TeamPromptConfig()

    if not paths.team_exists(team_id):
        return ""

    member_path = paths.member_path(team_id, member_id)
    entries = load_memories_from_jsonl(member_path)[: config.max_entries]

    if not entries:
        return ""

    lines = [
        f"## Your Context ({member_id})",
        "",
        "Your personal context within the team:",
        "",
    ]

    for entry in entries:
        content = entry.content[: config.max_content_length]
        lines.append(f"- {content}")

    lines.append("")
    return "\n".join(lines)


def build_full_team_prompt(
    team_id: str,
    member_id: str | None = None,
    paths: TeamMemPaths | None = None,
    memory_root: Path | None = None,
    config: TeamPromptConfig | None = None,
) -> str:
    """Build a complete team context prompt.

    Combines:
    - Team shared context
    - Member-specific context (if member_id provided)

    Args:
        team_id: Team identifier.
        member_id: Optional member identifier.
        paths: Team memory paths (or use memory_root).
        memory_root: Root of memory directory.
        config: Prompt configuration.

    Returns:
        Formatted context string.
    """
    if paths is None:
        if memory_root is None:
            return ""
        paths = TeamMemPaths.from_memory_root(memory_root)

    config = config or TeamPromptConfig()

    parts = []

    # Team context
    team_context = build_team_context_prompt(team_id, paths, config)
    if team_context:
        parts.append(team_context)

    # Member context
    if member_id:
        member_context = build_member_context_prompt(team_id, member_id, paths, config)
        if member_context:
            parts.append(member_context)

    return "\n".join(parts)


def build_team_coordination_prompt(
    team_id: str,
    paths: TeamMemPaths,
    active_members: list[str] | None = None,
) -> str:
    """Build a prompt for team coordination.

    Used when multiple agents are collaborating on a team.

    Args:
        team_id: Team identifier.
        paths: Team memory paths.
        active_members: List of active member IDs.

    Returns:
        Formatted coordination prompt.
    """
    if not paths.team_exists(team_id):
        return ""

    lines = [
        "## Team Coordination",
        "",
        f"**Team ID**: {team_id}",
    ]

    if active_members:
        lines.append(f"**Active Members**: {', '.join(active_members)}")

    lines.append("")
    lines.append("### Collaboration Guidelines")
    lines.append("- Check shared memory before starting tasks")
    lines.append("- Update shared memory with progress")
    lines.append("- Coordinate with other members to avoid conflicts")
    lines.append("")

    return "\n".join(lines)


def format_memory_for_sharing(
    content: str,
    member_id: str,
    memory_type: str = "progress",
) -> dict[str, Any]:
    """Format a memory entry for sharing with the team.

    Args:
        content: Memory content.
        member_id: ID of the sharing member.
        memory_type: Type of memory (progress, decision, finding).

    Returns:
        Dict ready for MemoryEntry creation.
    """
    from datetime import datetime

    return {
        "content": content,
        "memory_type": memory_type,
        "member": member_id,
        "timestamp": datetime.now().isoformat(),
    }
