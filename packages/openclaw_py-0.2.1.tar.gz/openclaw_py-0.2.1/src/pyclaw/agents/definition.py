"""Unified agent definition.

This module defines AgentDefinition, a comprehensive configuration class
that consolidates all agent settings including trust level, memory,
context, and orchestration configuration.

Reference: claude-code's AgentDefinition design.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TrustLevel(str, Enum):
    """Agent trust level - aligned with tool permission control.

    Trust levels determine which tools an agent can access.
    Higher levels grant access to more powerful/dangerous tools.
    """

    UNTRUSTED = "untrusted"  # Minimum permissions, safe tools only
    BASIC = "basic"  # Basic permissions, common tools
    TRUSTED = "trusted"  # Advanced permissions, most tools
    FULL = "full"  # Full trust, all tools


class MemoryScope(str, Enum):
    """Memory scope for agent storage.

    Defines where agent memory is stored and its visibility.
    """

    USER = "user"  # ~/.pyclaw/memory/ - user-global
    PROJECT = "project"  # .pyclaw/memory/ - project-specific
    LOCAL = "local"  # .pyclaw/memory-local/ - local overrides
    SESSION = "session"  # Session-scoped temporary storage
    TEAM = "team"  # Team shared storage


@dataclass
class ContextPolicy:
    """Context management policy.

    Controls how the context engine handles token limits and
    conversation compression.
    """

    compression_strategy: str = "summarize"  # truncate/summarize/dag
    threshold_percent: float = 0.75  # Trigger compression at 75% of context
    protect_first_n: int = 3  # Always keep first N messages
    tail_token_budget: int = 20000  # Reserve tokens for tail messages
    reserve_tokens_floor: int = 20000  # Minimum reserved tokens
    cache_strategy: str = "system"  # none/system/conversation/full


@dataclass
class OrchestrationConfig:
    """Multi-agent orchestration configuration.

    Controls how agents collaborate and delegate tasks.
    """

    mode: str = "none"  # none/centralized/decentralized/pipeline/hybrid
    implementation: str | None = None  # Specific implementation pattern
    max_parallel: int = 4  # Maximum parallel subagents
    max_depth: int = 5  # Maximum delegation depth
    timeout_seconds: int = 300  # Default subagent timeout


@dataclass
class AgentDefinition:
    """Unified agent definition.

    Consolidates all agent configuration into a single class.
    This design is inspired by claude-code's AgentDefinition.

    Attributes:
        agent_type: Unique identifier for this agent type.
        display_name: Human-readable name for display.
        description: Description of what this agent does.
        trust_level: Trust level for tool access control.
        memory_scope: Default memory storage scope.
        memory_backend: Memory backend provider name.
        memory_enabled: Whether memory is enabled.
        context_policy: Context management policy.
        orchestration: Multi-agent orchestration config.
        tools_enabled: Whitelist of enabled tools (None = all).
        tools_disabled: Blacklist of disabled tools.
        knowledge_sources: List of knowledge source IDs.
        system_prompt: Agent system prompt template.
        metadata: Additional metadata.
    """

    # Basic info
    agent_type: str
    display_name: str
    description: str

    # Trust level
    trust_level: TrustLevel = TrustLevel.BASIC

    # Memory config
    memory_scope: MemoryScope = MemoryScope.PROJECT
    memory_backend: str = "builtin"  # builtin/lancedb/qdrant/...
    memory_enabled: bool = True

    # Context policy
    context_policy: ContextPolicy = field(default_factory=ContextPolicy)

    # Orchestration config
    orchestration: OrchestrationConfig = field(default_factory=OrchestrationConfig)

    # Tool config
    tools_enabled: list[str] | None = None
    tools_disabled: list[str] | None = None

    # Knowledge config
    knowledge_sources: list[str] = field(default_factory=list)

    # System prompt
    system_prompt: str | None = None

    # Metadata
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate agent definition after initialization."""
        if not self.agent_type:
            raise ValueError("agent_type cannot be empty")
        if not self.display_name:
            raise ValueError("display_name cannot be empty")
        if not self.description:
            raise ValueError("description cannot be empty")

    def get_spawn_config(self, prompt: str, **kwargs: Any) -> dict[str, Any]:
        """Generate spawn configuration for this agent.

        Creates a configuration dict suitable for SubagentManager.spawn().

        Args:
            prompt: The task prompt for the agent.
            **kwargs: Additional configuration overrides.

        Returns:
            Configuration dict for spawning.
        """
        return {
            "agent_type": self.agent_type,
            "prompt": prompt,
            "trust_level": self.trust_level.value,
            "memory_scope": self.memory_scope.value,
            "memory_backend": self.memory_backend,
            "memory_enabled": self.memory_enabled,
            "context_policy": {
                "compression_strategy": self.context_policy.compression_strategy,
                "threshold_percent": self.context_policy.threshold_percent,
                "protect_first_n": self.context_policy.protect_first_n,
                "tail_token_budget": self.context_policy.tail_token_budget,
                "reserve_tokens_floor": self.context_policy.reserve_tokens_floor,
                "cache_strategy": self.context_policy.cache_strategy,
            },
            "orchestration": {
                "mode": self.orchestration.mode,
                "implementation": self.orchestration.implementation,
                "max_parallel": self.orchestration.max_parallel,
                "max_depth": self.orchestration.max_depth,
                "timeout_seconds": self.orchestration.timeout_seconds,
            },
            "tools_enabled": self.tools_enabled,
            "tools_disabled": self.tools_disabled,
            "knowledge_sources": self.knowledge_sources,
            "system_prompt": self.system_prompt,
            **kwargs,
        }

    def filter_tools(self, tools: list[Any]) -> list[Any]:
        """Filter a tool list based on this agent's configuration.

        Args:
            tools: List of tools to filter.

        Returns:
            Filtered list of tools.
        """
        filtered = list(tools)

        # Apply whitelist if specified
        if self.tools_enabled:
            filtered = [t for t in filtered if t.name in self.tools_enabled]

        # Apply blacklist
        if self.tools_disabled:
            filtered = [t for t in filtered if t.name not in self.tools_disabled]

        return filtered
