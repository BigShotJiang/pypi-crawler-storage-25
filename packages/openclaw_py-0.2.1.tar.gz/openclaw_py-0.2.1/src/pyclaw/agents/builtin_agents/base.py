"""Base class for built-in agents."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyclaw.agents.definition import AgentDefinition


class AgentType(str, Enum):
    """Types of built-in agents."""

    EXPLORE = "explore"
    PLAN = "plan"
    VERIFICATION = "verification"
    GENERAL_PURPOSE = "general_purpose"


@dataclass
class AgentConfig:
    """Configuration for a built-in agent."""

    name: str
    agent_type: AgentType
    description: str = ""
    system_prompt: str = ""
    allowed_tools: list[str] = field(default_factory=list)
    denied_tools: list[str] = field(default_factory=list)
    max_turns: int = 50
    max_depth: int = 3
    model_preference: str | None = None
    timeout_seconds: int = 300
    metadata: dict[str, Any] = field(default_factory=dict)


class BuiltinAgent:
    """Base class for built-in agent configurations.

    Provides a standardized interface for configuring specialized agents.
    Supports both legacy AgentConfig and new AgentDefinition.
    """

    def __init__(
        self,
        config: AgentConfig | None = None,
        definition: AgentDefinition | None = None,
    ) -> None:
        """Initialize a builtin agent.

        Args:
            config: Legacy AgentConfig (for backward compatibility).
            definition: New AgentDefinition (preferred).

        Note: Either config or definition must be provided, but not both.
        """
        self._definition: AgentDefinition | None = definition
        if definition is not None:
            self._config = self._config_from_definition(definition)
        elif config is not None:
            self._config = config
        else:
            raise ValueError("Either config or definition must be provided")

    def _config_from_definition(self, definition: AgentDefinition) -> AgentConfig:
        """Convert AgentDefinition to AgentConfig for compatibility.

        Args:
            definition: The AgentDefinition to convert.

        Returns:
            AgentConfig with mapped values.
        """
        # Map agent_type string to AgentType enum
        agent_type_str = definition.agent_type
        try:
            agent_type = AgentType(agent_type_str)
        except ValueError:
            # Default to GENERAL_PURPOSE for unknown types
            agent_type = AgentType.GENERAL_PURPOSE

        return AgentConfig(
            name=definition.display_name,
            agent_type=agent_type,
            description=definition.description,
            system_prompt=definition.system_prompt or "",
            allowed_tools=definition.tools_enabled or [],
            denied_tools=definition.tools_disabled or [],
            max_turns=definition.orchestration.max_depth * 10,  # Approximate
            max_depth=definition.orchestration.max_depth,
            timeout_seconds=definition.orchestration.timeout_seconds,
            metadata=definition.metadata,
        )

    @property
    def name(self) -> str:
        return self._config.name

    @property
    def agent_type(self) -> AgentType:
        return self._config.agent_type

    @property
    def description(self) -> str:
        return self._config.description

    @property
    def system_prompt(self) -> str:
        return self._config.system_prompt

    @property
    def allowed_tools(self) -> list[str]:
        return self._config.allowed_tools

    @property
    def denied_tools(self) -> list[str]:
        return self._config.denied_tools

    @property
    def config(self) -> AgentConfig:
        return self._config

    @property
    def definition(self) -> AgentDefinition | None:
        """Get the AgentDefinition if this agent was created from one."""
        return self._definition

    def filter_tools(self, tools: list[Any]) -> list[Any]:
        """Filter a tool list based on this agent's configuration.

        Args:
            tools: List of tools to filter.

        Returns:
            Filtered list of tools.
        """
        filtered = list(tools)

        # Apply whitelist if specified
        if self._config.allowed_tools:
            filtered = [t for t in filtered if t.name in self._config.allowed_tools]

        # Apply blacklist
        if self._config.denied_tools:
            filtered = [t for t in filtered if t.name not in self._config.denied_tools]

        return filtered

    def get_spawn_config(
        self,
        prompt: str,
        session_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get configuration dict for spawning this agent.

        Args:
            prompt: The prompt for the agent.
            session_id: Optional session ID.
            **kwargs: Additional configuration overrides.

        Returns:
            Configuration dict for SubagentManager.spawn().
        """
        # Use AgentDefinition's get_spawn_config if available
        if self._definition is not None:
            return self._definition.get_spawn_config(prompt, **kwargs)

        return {
            "prompt": prompt,
            "session_id": session_id,
            "agent_type": self._config.agent_type.value,
            "system_prompt": self._config.system_prompt,
            "tools_enabled": self._config.allowed_tools or None,
            "tools_disabled": self._config.denied_tools or None,
            "max_turns": kwargs.get("max_turns", self._config.max_turns),
            "timeout": self._config.timeout_seconds,
            **{k: v for k, v in kwargs.items() if k not in {"prompt", "session_id", "max_turns"}},
        }

    def __repr__(self) -> str:
        return f"BuiltinAgent({self.name}, type={self.agent_type.value})"
