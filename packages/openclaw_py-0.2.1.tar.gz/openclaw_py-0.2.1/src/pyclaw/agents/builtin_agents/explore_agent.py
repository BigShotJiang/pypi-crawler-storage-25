"""Explore agent — specialized for codebase navigation and understanding."""

from pyclaw.agents.builtin_agents.base import (
    AgentConfig,
    AgentType,
    BuiltinAgent,
)
from pyclaw.agents.definition import (
    AgentDefinition,
    ContextPolicy,
    MemoryScope,
    OrchestrationConfig,
    TrustLevel,
)

EXPLORE_SYSTEM_PROMPT = """You are an exploration agent specialized in navigating and understanding codebases.

## Your Mission
Efficiently explore the codebase to answer questions about structure, implementation, and relationships.

## Tools Available
- `read_file`: Read file contents
- `glob_search`: Find files by pattern
- `grep_search`: Search file contents
- `ls`: List directory contents

## Exploration Strategy
1. Start broad, then narrow down
2. Use glob to find relevant files
3. Use grep to find relevant code
4. Read key files to understand implementation
5. Summarize findings concisely

## Output Format
- Start with a brief answer to the question
- Provide supporting evidence (file paths, line numbers)
- Include relevant code snippets when helpful
- Suggest related areas if applicable

## Constraints
- Focus on understanding, not modifying
- Be thorough but efficient
- Report file paths relative to project root
"""

EXPLORE_CONFIG = AgentConfig(
    name="Explore",
    agent_type=AgentType.EXPLORE,
    description="Navigate and understand codebase structure",
    system_prompt=EXPLORE_SYSTEM_PROMPT,
    allowed_tools=[
        "read_file",
        "glob_search",
        "grep_search",
        "ls",
        "find",
    ],
    denied_tools=[
        "write_file",
        "edit_file",
        "bash",
        "exec",
    ],
    max_turns=20,
    max_depth=3,
    metadata={
        "emoji": "🔍",
        "category": "analysis",
    },
)

# New AgentDefinition-based configuration
EXPLORE_DEFINITION = AgentDefinition(
    agent_type="explore",
    display_name="Explore",
    description="Navigate and understand codebase structure",
    trust_level=TrustLevel.BASIC,
    memory_scope=MemoryScope.PROJECT,
    memory_enabled=True,
    context_policy=ContextPolicy(
        compression_strategy="summarize",
        threshold_percent=0.75,
        protect_first_n=3,
    ),
    orchestration=OrchestrationConfig(
        mode="none",
        max_depth=3,
        timeout_seconds=300,
    ),
    tools_enabled=[
        "read_file",
        "glob_search",
        "grep_search",
        "ls",
        "find",
    ],
    tools_disabled=[
        "write_file",
        "edit_file",
        "bash",
        "exec",
    ],
    system_prompt=EXPLORE_SYSTEM_PROMPT,
    metadata={
        "emoji": "🔍",
        "category": "analysis",
    },
)

# Legacy agent (for backward compatibility)
EXPLORE_AGENT = BuiltinAgent(EXPLORE_CONFIG)

# New agent using AgentDefinition
EXPLORE_AGENT_V2 = BuiltinAgent(definition=EXPLORE_DEFINITION)
