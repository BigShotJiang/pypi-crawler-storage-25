"""Plan agent — specialized for task decomposition and planning."""

from pyclaw.agents.builtin_agents.base import (
    AgentConfig,
    AgentType,
    BuiltinAgent,
)
from pyclaw.agents.definition import (
    AgentDefinition,
    ContextPolicy,
    MemoryScope,
    OrchestrationConfig,
    TrustLevel,
)

PLAN_SYSTEM_PROMPT = """You are a planning agent specialized in breaking down tasks into actionable steps.

## Your Mission
Analyze requirements and create detailed, actionable plans for implementation.

## Tools Available
- `read_file`: Read existing code
- `glob_search`: Find relevant files
- `grep_search`: Search for patterns
- `bash`: Run commands for exploration (read-only preferred)
- `todo_write`: Track planning steps

## Planning Process
1. Understand the goal
2. Analyze existing codebase structure
3. Identify required changes
4. Break down into ordered steps
5. Consider dependencies between steps
6. Identify potential risks

## Output Format
Provide a structured plan:

```
## Goal
[Clear statement of what needs to be achieved]

## Analysis
[Current state and required changes]

## Plan
1. [Step 1]
   - Files: [list affected files]
   - Actions: [specific actions]
   - Dependencies: [none / step X]

2. [Step 2]
   ...

## Risks
- [Risk 1]: [Mitigation]
- [Risk 2]: [Mitigation]

## Estimated Effort
[Small/Medium/Large with reasoning]
```

## Constraints
- Plans should be actionable and specific
- Include file paths when relevant
- Consider backward compatibility
- Note breaking changes explicitly
"""

PLAN_CONFIG = AgentConfig(
    name="Plan",
    agent_type=AgentType.PLAN,
    description="Decompose tasks into actionable implementation steps",
    system_prompt=PLAN_SYSTEM_PROMPT,
    allowed_tools=[
        "read_file",
        "glob_search",
        "grep_search",
        "bash",
        "ls",
        "find",
    ],
    denied_tools=[
        "write_file",
        "edit_file",
    ],
    max_turns=30,
    max_depth=3,
    metadata={
        "emoji": "📋",
        "category": "planning",
    },
)

# New AgentDefinition-based configuration
PLAN_DEFINITION = AgentDefinition(
    agent_type="plan",
    display_name="Plan",
    description="Decompose tasks into actionable implementation steps",
    trust_level=TrustLevel.BASIC,
    memory_scope=MemoryScope.PROJECT,
    memory_enabled=True,
    context_policy=ContextPolicy(
        compression_strategy="summarize",
        threshold_percent=0.75,
        protect_first_n=3,
    ),
    orchestration=OrchestrationConfig(
        mode="none",
        max_depth=3,
        timeout_seconds=300,
    ),
    tools_enabled=[
        "read_file",
        "glob_search",
        "grep_search",
        "bash",
        "ls",
        "find",
    ],
    tools_disabled=[
        "write_file",
        "edit_file",
    ],
    system_prompt=PLAN_SYSTEM_PROMPT,
    metadata={
        "emoji": "📋",
        "category": "planning",
    },
)

# Legacy agent (for backward compatibility)
PLAN_AGENT = BuiltinAgent(PLAN_CONFIG)

# New agent using AgentDefinition
PLAN_AGENT_V2 = BuiltinAgent(definition=PLAN_DEFINITION)
