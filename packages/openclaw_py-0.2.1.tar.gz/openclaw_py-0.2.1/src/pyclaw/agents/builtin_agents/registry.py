"""Builtin agent registry — lookup for agent types.

Refactored to align with Registry interface pattern (Phase 03).
Uses module-level singleton pattern (dual v1/v2 registries).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pyclaw.agents.builtin_agents.base import AgentType, BuiltinAgent
from pyclaw.agents.builtin_agents.explore_agent import EXPLORE_AGENT, EXPLORE_AGENT_V2
from pyclaw.agents.builtin_agents.general_purpose_agent import (
    GENERAL_PURPOSE_AGENT,
    GENERAL_PURPOSE_AGENT_V2,
)
from pyclaw.agents.builtin_agents.plan_agent import PLAN_AGENT, PLAN_AGENT_V2
from pyclaw.agents.builtin_agents.verification_agent import (
    VERIFICATION_AGENT,
    VERIFICATION_AGENT_V2,
)
from pyclaw.logging import get_logger

if TYPE_CHECKING:
    from pyclaw.agents.definition import AgentDefinition

logger = get_logger(__name__)


class BuiltinAgentRegistry:
    """Registry for built-in agent configurations.

    Provides lookup by agent type string.
    Supports both legacy AgentConfig and new AgentDefinition-based agents.

    Note:
        This registry uses module-level singleton pattern with TWO variants
        (v1 and v2). Cannot use SingletonRegistry mixin due to this dual-registry
        requirement.

    Interface aligned with Registry pattern:
    - register(key, value) - uses agent.agent_type.value as key
    - get(key) -> value | None
    - list_types() -> list[key] (alias for list_keys)
    - list_agents() -> list[value] (alias for list_all)
    - __contains__, __len__
    """

    def __init__(self, use_v2: bool = False) -> None:
        """Initialize the registry.

        Args:
            use_v2: If True, use AgentDefinition-based agents (EXPLORE_AGENT_V2, etc.).
        """
        self._agents: dict[str, BuiltinAgent] = {}
        self._use_v2 = use_v2
        self._register_defaults()

    def _register_defaults(self) -> None:
        """Register all default built-in agents."""
        if self._use_v2:
            self.register(EXPLORE_AGENT_V2)
            self.register(PLAN_AGENT_V2)
            self.register(VERIFICATION_AGENT_V2)
            self.register(GENERAL_PURPOSE_AGENT_V2)
        else:
            self.register(EXPLORE_AGENT)
            self.register(PLAN_AGENT)
            self.register(VERIFICATION_AGENT)
            self.register(GENERAL_PURPOSE_AGENT)

    def register(self, agent: BuiltinAgent) -> None:
        """Register a built-in agent.

        Args:
            agent: The agent to register.
        """
        key = agent.agent_type.value
        self._agents[key] = agent
        logger.debug("Registered builtin agent: %s", key)

    def register_definition(self, definition: AgentDefinition) -> None:
        """Register an agent from an AgentDefinition.

        Args:
            definition: The AgentDefinition to register.
        """
        agent = BuiltinAgent(definition=definition)
        self.register(agent)

    def get(self, agent_type: str | AgentType) -> BuiltinAgent | None:
        """Get a built-in agent by type.

        Args:
            agent_type: Agent type string or enum.

        Returns:
            BuiltinAgent or None if not found.
        """
        key = agent_type.value if isinstance(agent_type, AgentType) else agent_type
        return self._agents.get(key)

    def get_default(self) -> BuiltinAgent:
        """Get the default agent (GeneralPurpose).

        Returns:
            The default BuiltinAgent.
        """
        return self._agents.get(AgentType.GENERAL_PURPOSE.value, GENERAL_PURPOSE_AGENT)

    def list_types(self) -> list[str]:
        """List all registered agent types.

        Returns:
            List of agent type strings.
        """
        return list(self._agents.keys())

    def list_agents(self) -> list[BuiltinAgent]:
        """List all registered agents.

        Returns:
            List of BuiltinAgent instances.
        """
        return list(self._agents.values())

    # Registry interface aliases
    list_keys = list_types
    list_all = list_agents

    def get_spawn_config(
        self,
        agent_type: str | AgentType,
        prompt: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get spawn configuration for an agent type.

        Args:
            agent_type: The agent type.
            prompt: The prompt for the agent.
            **kwargs: Additional configuration overrides.

        Returns:
            Configuration dict for spawning.
        """
        agent = self.get(agent_type)
        if agent:
            return agent.get_spawn_config(prompt, **kwargs)

        # Fall back to default
        return self.get_default().get_spawn_config(prompt, **kwargs)

    def __contains__(self, agent_type: str | AgentType) -> bool:
        """Check if agent type is registered."""
        key = agent_type.value if isinstance(agent_type, AgentType) else agent_type
        return key in self._agents

    def __len__(self) -> int:
        """Return number of registered agents."""
        return len(self._agents)


# Global registry instance (module-level singleton pattern)
_registry: BuiltinAgentRegistry | None = None
_registry_v2: BuiltinAgentRegistry | None = None


def get_registry(use_v2: bool = False) -> BuiltinAgentRegistry:
    """Get the global agent registry.

    Args:
        use_v2: If True, return registry with AgentDefinition-based agents.

    Returns:
        BuiltinAgentRegistry instance.
    """
    global _registry, _registry_v2
    if use_v2:
        if _registry_v2 is None:
            _registry_v2 = BuiltinAgentRegistry(use_v2=True)
        return _registry_v2
    else:
        if _registry is None:
            _registry = BuiltinAgentRegistry(use_v2=False)
        return _registry


def reset() -> None:
    """Reset both registry instances (for testing).

    This clears both v1 and v2 singleton instances.
    """
    global _registry, _registry_v2
    _registry = None
    _registry_v2 = None


def get_agent(agent_type: str | AgentType, use_v2: bool = False) -> BuiltinAgent:
    """Get a built-in agent by type.

    Args:
        agent_type: Agent type string or enum.
        use_v2: If True, use AgentDefinition-based agents.

    Returns:
        BuiltinAgent instance.
    """
    return get_registry(use_v2).get(agent_type) or get_registry(use_v2).get_default()
