"""Built-in agents — specialized agent configurations.

This module provides pre-configured agent types for common tasks:
- Explore: Codebase navigation and understanding
- Plan: Task decomposition and planning
- Verification: Result validation and testing
- GeneralPurpose: Default multi-purpose agent
"""

from pyclaw.agents.builtin_agents.base import AgentConfig, AgentType, BuiltinAgent
from pyclaw.agents.builtin_agents.explore_agent import EXPLORE_AGENT
from pyclaw.agents.builtin_agents.general_purpose_agent import GENERAL_PURPOSE_AGENT
from pyclaw.agents.builtin_agents.plan_agent import PLAN_AGENT
from pyclaw.agents.builtin_agents.registry import BuiltinAgentRegistry, get_agent, get_registry
from pyclaw.agents.builtin_agents.verification_agent import VERIFICATION_AGENT

__all__ = [
    "BuiltinAgent",
    "AgentConfig",
    "AgentType",
    "BuiltinAgentRegistry",
    "EXPLORE_AGENT",
    "PLAN_AGENT",
    "VERIFICATION_AGENT",
    "GENERAL_PURPOSE_AGENT",
    "get_agent",
    "get_registry",
]
