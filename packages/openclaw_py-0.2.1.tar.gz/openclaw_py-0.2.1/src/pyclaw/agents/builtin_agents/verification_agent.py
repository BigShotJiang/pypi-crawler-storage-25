"""Verification agent — specialized for result validation and testing."""

from pyclaw.agents.builtin_agents.base import (
    AgentConfig,
    AgentType,
    BuiltinAgent,
)
from pyclaw.agents.definition import (
    AgentDefinition,
    ContextPolicy,
    MemoryScope,
    OrchestrationConfig,
    TrustLevel,
)

VERIFICATION_SYSTEM_PROMPT = """You are a verification agent specialized in validating results and ensuring correctness.

## Your Mission
Verify that implementations meet requirements and pass all tests.

## Tools Available
- `read_file`: Read code files
- `grep_search`: Search for patterns
- `bash`: Run tests and commands
- `glob_search`: Find test files

## Verification Process
1. Understand what needs verification
2. Identify test requirements
3. Run existing tests
4. Check for edge cases
5. Verify integration
6. Report results

## Verification Checklist
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Edge cases covered
- [ ] No regressions
- [ ] Documentation updated
- [ ] Type checking passes
- [ ] Linting passes

## Output Format
Provide a verification report:

```
## Verification Report

### Tests Run
- [test name]: PASS/FAIL
- [test name]: PASS/FAIL

### Issues Found
1. [Issue]: [Details]
   - Location: [file:line]
   - Severity: [Critical/High/Medium/Low]

### Summary
[PASS/FAIL] - X/Y tests passed

### Recommendations
- [Recommendation 1]
- [Recommendation 2]
```

## Constraints
- Run actual tests when possible
- Don't modify code unless critical fix
- Report all failures clearly
- Distinguish between errors and warnings
"""

VERIFICATION_CONFIG = AgentConfig(
    name="Verification",
    agent_type=AgentType.VERIFICATION,
    description="Validate results and ensure correctness",
    system_prompt=VERIFICATION_SYSTEM_PROMPT,
    allowed_tools=[
        "read_file",
        "glob_search",
        "grep_search",
        "bash",
        "ls",
    ],
    denied_tools=[
        "write_file",
        "edit_file",
    ],
    max_turns=25,
    max_depth=3,
    metadata={
        "emoji": "✅",
        "category": "verification",
    },
)

# New AgentDefinition-based configuration
VERIFICATION_DEFINITION = AgentDefinition(
    agent_type="verification",
    display_name="Verification",
    description="Validate results and ensure correctness",
    trust_level=TrustLevel.BASIC,
    memory_scope=MemoryScope.PROJECT,
    memory_enabled=True,
    context_policy=ContextPolicy(
        compression_strategy="summarize",
        threshold_percent=0.75,
        protect_first_n=3,
    ),
    orchestration=OrchestrationConfig(
        mode="none",
        max_depth=3,
        timeout_seconds=300,
    ),
    tools_enabled=[
        "read_file",
        "glob_search",
        "grep_search",
        "bash",
        "ls",
    ],
    tools_disabled=[
        "write_file",
        "edit_file",
    ],
    system_prompt=VERIFICATION_SYSTEM_PROMPT,
    metadata={
        "emoji": "✅",
        "category": "verification",
    },
)

# Legacy agent (for backward compatibility)
VERIFICATION_AGENT = BuiltinAgent(VERIFICATION_CONFIG)

# New agent using AgentDefinition
VERIFICATION_AGENT_V2 = BuiltinAgent(definition=VERIFICATION_DEFINITION)
