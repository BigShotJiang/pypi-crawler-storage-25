"""General purpose agent — default multi-purpose agent configuration."""

from pyclaw.agents.builtin_agents.base import (
    AgentConfig,
    AgentType,
    BuiltinAgent,
)
from pyclaw.agents.definition import (
    AgentDefinition,
    ContextPolicy,
    MemoryScope,
    OrchestrationConfig,
    TrustLevel,
)

GENERAL_PURPOSE_SYSTEM_PROMPT = """You are a general-purpose agent capable of handling a wide variety of tasks.

## Your Mission
Complete the assigned task efficiently and correctly, using all available tools.

## Capabilities
You have access to all tools and can:
- Read and write files
- Execute commands
- Search the codebase
- Make network requests
- Manage tasks and todos

## Approach
1. Understand the task requirements
2. Plan your approach
3. Execute systematically
4. Verify results
5. Clean up and summarize

## Best Practices
- Write clean, maintainable code
- Follow existing project conventions
- Add appropriate error handling
- Document complex logic
- Test your changes when possible

## Constraints
- Ask for clarification if requirements are unclear
- Report progress on long-running tasks
- Handle errors gracefully
- Don't make assumptions about user intent
"""

GENERAL_PURPOSE_CONFIG = AgentConfig(
    name="GeneralPurpose",
    agent_type=AgentType.GENERAL_PURPOSE,
    description="Default multi-purpose agent for general tasks",
    system_prompt=GENERAL_PURPOSE_SYSTEM_PROMPT,
    allowed_tools=[],  # Empty = all tools allowed
    denied_tools=[],
    max_turns=50,
    max_depth=5,
    metadata={
        "emoji": "🤖",
        "category": "general",
    },
)

# New AgentDefinition-based configuration
GENERAL_PURPOSE_DEFINITION = AgentDefinition(
    agent_type="general_purpose",
    display_name="General Purpose",
    description="Default multi-purpose agent for general tasks",
    trust_level=TrustLevel.TRUSTED,
    memory_scope=MemoryScope.PROJECT,
    memory_enabled=True,
    context_policy=ContextPolicy(
        compression_strategy="summarize",
        threshold_percent=0.75,
        protect_first_n=3,
    ),
    orchestration=OrchestrationConfig(
        mode="none",
        max_depth=5,
        timeout_seconds=300,
    ),
    tools_enabled=None,  # None = all tools allowed
    tools_disabled=None,
    system_prompt=GENERAL_PURPOSE_SYSTEM_PROMPT,
    metadata={
        "emoji": "🤖",
        "category": "general",
    },
)

# Legacy agent (for backward compatibility)
GENERAL_PURPOSE_AGENT = BuiltinAgent(GENERAL_PURPOSE_CONFIG)

# New agent using AgentDefinition
GENERAL_PURPOSE_AGENT_V2 = BuiltinAgent(definition=GENERAL_PURPOSE_DEFINITION)
