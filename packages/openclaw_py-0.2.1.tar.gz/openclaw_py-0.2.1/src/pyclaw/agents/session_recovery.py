"""Session recovery — auto-recovery on gateway startup."""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path

import aiofiles
import aiofiles.os

logger = logging.getLogger("pyclaw.agents.recovery")


@dataclass
class RecoveryReport:
    """Report of session recovery operations."""

    valid_sessions: int = 0
    recovered_from_checkpoint: int = 0
    quarantined: int = 0
    stale_locks_cleaned: int = 0
    partial_writes_fixed: int = 0

    def to_dict(self) -> dict[str, int]:
        return {
            "valid_sessions": self.valid_sessions,
            "recovered_from_checkpoint": self.recovered_from_checkpoint,
            "quarantined": self.quarantined,
            "stale_locks_cleaned": self.stale_locks_cleaned,
            "partial_writes_fixed": self.partial_writes_fixed,
        }


@dataclass
class ValidationResult:
    """Result of validating a session file."""

    is_valid: bool
    has_partial_write: bool = False
    error_message: str = ""


async def validate_session_file(session_path: Path) -> ValidationResult:
    """Validate a session JSONL file for integrity.

    Checks:
    - All lines are valid JSON
    - Has session header
    - No truncated last line (partial write detection)
    """
    if not session_path.exists():
        return ValidationResult(is_valid=True, error_message="File does not exist")

    try:
        has_header = False
        line_count = 0
        last_line_complete = True

        async with aiofiles.open(session_path, encoding="utf-8") as f:
            async for line in f:
                line_count += 1
                line = line.strip()
                if not line:
                    continue

                try:
                    entry = json.loads(line)
                    if entry.get("type") == "session":
                        has_header = True
                    last_line_complete = True
                except json.JSONDecodeError:
                    # Partial write: last line is incomplete
                    last_line_complete = False

        if not has_header and line_count > 0:
            return ValidationResult(
                is_valid=False,
                error_message="Missing session header",
            )

        if not last_line_complete:
            return ValidationResult(
                is_valid=False,
                has_partial_write=True,
                error_message="Partial write detected (incomplete last line)",
            )

        return ValidationResult(is_valid=True)

    except Exception as e:
        return ValidationResult(is_valid=False, error_message=str(e))


async def recover_sessions_on_startup(
    sessions_dir: Path,
    *,
    quarantine_dir: Path | None = None,
) -> RecoveryReport:
    """Scan sessions directory and recover any with issues.

    Called automatically on gateway startup.
    """
    report = RecoveryReport()

    if not sessions_dir.exists():
        logger.debug("Sessions directory does not exist: %s", sessions_dir)
        return report

    quarantine = quarantine_dir or sessions_dir.parent / "quarantine"

    for session_file in sessions_dir.glob("*.jsonl"):
        # Skip lock files
        if session_file.suffix == ".lock":
            continue

        lock_path = session_file.with_suffix(".jsonl.lock")

        # Check for stale locks
        if lock_path.exists():
            if await _is_stale_lock(lock_path):
                lock_path.unlink(missing_ok=True)
                report.stale_locks_cleaned += 1
                logger.info("Cleaned stale lock: %s", lock_path)

        # Validate session integrity
        validation = await validate_session_file(session_file)

        if validation.is_valid:
            report.valid_sessions += 1
        elif validation.has_partial_write:
            # Rollback to last checkpoint
            recovered = await _recover_from_checkpoint(session_file)
            if recovered:
                report.recovered_from_checkpoint += 1
                report.partial_writes_fixed += 1
                logger.info("Recovered from checkpoint: %s", session_file)
            else:
                # Move to quarantine
                await _quarantine_session(session_file, quarantine)
                report.quarantined += 1
                logger.warning("Quarantined session: %s", session_file)
        else:
            # Corrupted session, quarantine it
            await _quarantine_session(session_file, quarantine)
            report.quarantined += 1
            logger.warning(
                "Quarantined corrupted session: %s - %s",
                session_file,
                validation.error_message,
            )

    if report.stale_locks_cleaned > 0 or report.quarantined > 0:
        logger.info(
            "Session recovery complete: valid=%d, recovered=%d, quarantined=%d, locks_cleaned=%d",
            report.valid_sessions,
            report.recovered_from_checkpoint,
            report.quarantined,
            report.stale_locks_cleaned,
        )

    return report


async def _is_stale_lock(lock_path: Path) -> bool:
    """Check if a lock file is stale (older than 30 minutes or dead process)."""
    try:
        content = lock_path.read_text(encoding="utf-8")
        lock_data = json.loads(content)
        created_at = lock_data.get("createdAt", 0)
        lock_pid = lock_data.get("pid", -1)

        # 30 minutes stale threshold
        is_stale = (time.time() * 1000 - created_at) > 30 * 60 * 1000

        # Check if process is dead
        is_dead = not _is_process_alive(lock_pid)

        return is_stale or is_dead
    except (json.JSONDecodeError, OSError):
        return True  # Corrupt lock is stale


def _is_process_alive(pid: int) -> bool:
    """Check if a process with given PID is alive."""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


async def _recover_from_checkpoint(session_path: Path) -> bool:
    """Attempt to recover session from most recent checkpoint.

    Returns True if recovery successful, False otherwise.
    """
    from pyclaw.agents.session import SessionManager
    from pyclaw.agents.session_checkpoint import CheckpointManager

    # Check both possible checkpoint locations
    checkpoints_dir = session_path.parent / "checkpoints"
    if not checkpoints_dir.exists():
        checkpoints_dir = session_path.parent.parent / "checkpoints"
    if not checkpoints_dir.exists():
        return False

    # Find most recent checkpoint
    checkpoints = sorted(
        checkpoints_dir.glob("ckpt-*.jsonl"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if not checkpoints:
        return False

    # Create a fresh session for restoration
    session_path.parent.mkdir(parents=True, exist_ok=True)
    session = SessionManager(path=session_path)
    ckpt_manager = CheckpointManager(session, checkpoints_dir)

    # Remove corrupt session file
    session_path.unlink(missing_ok=True)

    # Restore from checkpoint (async)
    checkpoint_id = checkpoints[0].stem
    restored = await ckpt_manager.restore_from_checkpoint(checkpoint_id)
    if not restored:
        return False

    # Write restored session to file (sync - simpler and safer)
    session.write_header()
    for msg in session.messages:
        session.append_message(msg)

    return True


async def _quarantine_session(session_path: Path, quarantine_dir: Path) -> None:
    """Move a corrupted session to quarantine directory."""
    quarantine_dir.mkdir(parents=True, exist_ok=True)

    timestamp = time.strftime("%Y%m%d-%H%M%S")
    quarantine_name = f"{session_path.stem}-{timestamp}.jsonl.quarantine"
    quarantine_path = quarantine_dir / quarantine_name

    await aiofiles.os.rename(str(session_path), str(quarantine_path))
