"""MCP skill builders — bridge MCP tools as invocable skills.

Provides utilities to expose MCP server tools as skills that can be
invoked via the skill system.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from pyclaw.agents.skills.types import (
    SkillEntry,
    SkillInvocationPolicy,
    SkillMetadata,
    SkillRuntimeContract,
)

logger = logging.getLogger(__name__)


@dataclass
class MCPSkillConfig:
    """Configuration for MCP-to-skill bridging."""

    prefix: str = "mcp"
    include_server_name: bool = True
    group_by_server: bool = False
    auto_discover: bool = True


def mcp_tool_to_skill(
    tool_name: str,
    tool_definition: dict[str, Any],
    server_name: str,
) -> SkillEntry:
    """Convert an MCP tool definition to a SkillEntry.

    Args:
        tool_name: Name of the MCP tool.
        tool_definition: MCP tool definition dict.
        server_name: Name of the MCP server.

    Returns:
        SkillEntry for the MCP tool.
    """
    # Build skill content from tool definition
    description = tool_definition.get("description", "")
    input_schema = tool_definition.get("inputSchema", {})

    content = f"""# MCP Tool: {tool_name}

**Server:** {server_name}

{description}

## Parameters

"""
    # Add parameter documentation
    properties = input_schema.get("properties", {})
    required = input_schema.get("required", [])

    for param_name, param_def in properties.items():
        param_type = param_def.get("type", "any")
        param_desc = param_def.get("description", "")
        is_required = param_name in required
        req_marker = " (required)" if is_required else " (optional)"
        content += f"- **{param_name}** `{param_type}`{req_marker}: {param_desc}\n"

    skill_name = f"mcp-{server_name}-{tool_name}" if server_name else f"mcp-{tool_name}"

    return SkillEntry(
        path=f"mcp/{server_name}/{tool_name}",
        name=skill_name,
        content=content,
        metadata=SkillMetadata(
            skill_key=skill_name,
            always=False,
        ),
        invocation=SkillInvocationPolicy(
            user_invocable=True,
            disable_model_invocation=False,
        ),
        runtime_contract=SkillRuntimeContract(
            runtime="mcp-bridge",
            launcher="mcp",
        ),
        source="mcp",
    )


def mcp_tools_to_skills(
    tools: list[dict[str, Any]],
    server_name: str,
) -> list[SkillEntry]:
    """Convert multiple MCP tools to skills.

    Args:
        tools: List of MCP tool definitions.
        server_name: Name of the MCP server.

    Returns:
        List of SkillEntry instances.
    """
    return [
        mcp_tool_to_skill(
            tool_name=t.get("name", f"unknown_{i}"),
            tool_definition=t,
            server_name=server_name,
        )
        for i, t in enumerate(tools)
    ]


async def load_mcp_skills(
    mcp_client: Any,
    server_names: list[str] | None = None,
) -> list[SkillEntry]:
    """Load skills from MCP servers.

    Args:
        mcp_client: MCP client instance.
        server_names: Specific servers to load from. If None, load from all.

    Returns:
        List of SkillEntry instances from all MCP tools.
    """
    skills: list[SkillEntry] = []

    if not hasattr(mcp_client, "list_servers"):
        logger.warning("MCP client does not support list_servers")
        return skills

    try:
        servers = await mcp_client.list_servers()

        for server in servers:
            if server_names and server not in server_names:
                continue

            try:
                tools = await mcp_client.list_tools(server)
                server_skills = mcp_tools_to_skills(tools, server)
                skills.extend(server_skills)
                logger.debug(
                    "Loaded %d skills from MCP server %s",
                    len(server_skills),
                    server,
                )
            except Exception as e:
                logger.warning("Failed to load tools from MCP server %s: %s", server, e)

    except Exception as e:
        logger.error("Failed to list MCP servers: %s", e)

    return skills


def create_mcp_skill_registry(
    mcp_client: Any,
    server_names: list[str] | None = None,
) -> dict[str, SkillEntry]:
    """Create a registry of MCP skills.

    This is a synchronous wrapper that creates the registry structure
    without actually loading from the server.

    Args:
        mcp_client: MCP client instance.
        server_names: Expected server names.

    Returns:
        Dict of skill name to SkillEntry.
    """
    # Return empty dict - actual loading is async
    # This is used for type hints and structure
    return {}


class MCPSkillBuilder:
    """Builder for creating MCP-backed skills."""

    def __init__(
        self,
        mcp_client: Any,
        config: MCPSkillConfig | None = None,
    ) -> None:
        self._client = mcp_client
        self._config = config or MCPSkillConfig()
        self._cache: dict[str, SkillEntry] = {}

    async def discover_skills(self) -> list[SkillEntry]:
        """Discover all MCP skills from connected servers."""
        return await load_mcp_skills(self._client)

    def get_skill(self, skill_name: str) -> SkillEntry | None:
        """Get a cached MCP skill by name."""
        return self._cache.get(skill_name)

    def clear_cache(self) -> None:
        """Clear the skill cache."""
        self._cache.clear()

    async def refresh(self) -> int:
        """Refresh the skill cache from MCP servers.

        Returns:
            Number of skills loaded.
        """
        skills = await self.discover_skills()
        self._cache = {s.name: s for s in skills}
        return len(skills)
