"""Skill tool converter — converts skills to AgentTool instances.

Provides utilities to convert SkillEntry objects to AgentTool instances
that can be registered with the unified tool registry.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from pyclaw.agents.skills.types import SkillEntry
from pyclaw.agents.tools.base import BaseTool
from pyclaw.agents.types import ToolResult

logger = logging.getLogger(__name__)


class SkillTool(BaseTool):
    """AgentTool wrapper for a skill.

    Allows skills to be invoked as tools by the agent.
    """

    def __init__(
        self,
        skill: SkillEntry,
        skill_runner: Any | None = None,
    ) -> None:
        self._skill = skill
        self._runner = skill_runner

    @property
    def name(self) -> str:
        return self._skill.name

    @property
    def description(self) -> str:
        # Use skill content as description, truncated
        content = self._skill.content
        if len(content) > 200:
            return content[:197] + "..."
        return content or f"Execute skill: {self._skill.name}"

    @property
    def parameters(self) -> dict[str, Any]:
        # Skills typically don't have structured parameters
        # Allow optional payload string
        return {
            "type": "object",
            "properties": {
                "payload": {
                    "type": "string",
                    "description": "Optional payload to pass to the skill",
                },
            },
        }

    async def execute(
        self,
        tool_call_id: str,
        arguments: dict[str, Any],
    ) -> ToolResult:
        """Execute the skill.

        Args:
            tool_call_id: Tool call identifier.
            arguments: Arguments passed to the tool.

        Returns:
            ToolResult with skill execution result.
        """
        payload = arguments.get("payload", "")

        if self._runner:
            try:
                result = await self._runner(self._skill, payload)
                return ToolResult.text(str(result))
            except Exception as e:
                logger.error("Skill execution failed: %s", e)
                return ToolResult.text(f"Skill execution failed: {e}", is_error=True)

        # Default: return skill content
        return ToolResult.text(f"Skill '{self._skill.name}' ready. Content:\n{self._skill.content}")


def to_skill_tool(
    skill: SkillEntry,
    runner: Any | None = None,
) -> SkillTool:
    """Convert a SkillEntry to an AgentTool.

    Args:
        skill: The skill entry.
        runner: Optional skill runner function.

    Returns:
        SkillTool instance.
    """
    return SkillTool(skill, runner)


def skills_to_tools(
    skills: list[SkillEntry],
    runner: Any | None = None,
) -> list[SkillTool]:
    """Convert multiple skills to tools.

    Args:
        skills: List of skill entries.
        runner: Optional skill runner function.

    Returns:
        List of SkillTool instances.
    """
    return [to_skill_tool(skill, runner) for skill in skills]


@dataclass
class SkillToolConfig:
    """Configuration for skill tool conversion."""

    include_content_in_description: bool = True
    max_description_length: int = 200
    allow_user_invocation: bool = True


def create_skill_tool_with_config(
    skill: SkillEntry,
    config: SkillToolConfig,
    runner: Any | None = None,
) -> SkillTool | None:
    """Create a skill tool with configuration checks.

    Args:
        skill: The skill entry.
        config: Conversion configuration.
        runner: Optional skill runner.

    Returns:
        SkillTool or None if skill should not be converted.
    """
    # Check invocation policy
    if not skill.invocation.user_invocable and not config.allow_user_invocation:
        return None

    return to_skill_tool(skill, runner)
