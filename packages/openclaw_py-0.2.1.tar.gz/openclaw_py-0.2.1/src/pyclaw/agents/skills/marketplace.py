"""Skills marketplace — search/install/manage skills from GitHub and ClawHub."""

from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import shutil
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

CLAWHUB_API = "https://api.github.com"
CLAWHUB_REPO = "openclaw/clawhub"
CLAWHUB_SKILLS_PATH = "skills"

# Default skill version when not specified
DEFAULT_SKILL_VERSION = "0.1.0"


@dataclass
class MarketplaceSkill:
    """A skill available in the marketplace."""

    name: str
    description: str = ""
    url: str = ""
    download_url: str = ""
    homepage: str = ""
    tags: list[str] = field(default_factory=list)
    category: str = ""
    runtime: str = ""
    dependencies: list[str] = field(default_factory=list)
    size: int = 0
    is_installed: bool = False
    content: str = ""
    # Version management fields
    version: str = ""
    installed_version: str = ""
    author: str = ""
    license: str = ""
    checksum: str = ""
    changelog: list[str] = field(default_factory=list)
    updated_at: str = ""
    min_pyclaw_version: str = ""
    # Signature verification
    signature_verified: bool = False


@dataclass
class SkillVersionInfo:
    """Version comparison result for an installed skill."""

    name: str
    installed_version: str
    available_version: str
    has_update: bool
    changelog: list[str] = field(default_factory=list)
    checksum_match: bool = True


def _run_clawhub(*args: str, timeout_s: float = 20.0) -> tuple[bool, str]:
    if shutil.which("clawhub") is None:
        return False, ""
    try:
        proc = subprocess.run(
            ["clawhub", *args],
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout_s,
        )
    except Exception:
        logger.exception("Failed to run clawhub command: %s", " ".join(args))
        return False, ""
    if proc.returncode != 0:
        return False, (proc.stderr or proc.stdout or "").strip()
    return True, (proc.stdout or "").strip()


def _extract_skill_name(raw: str) -> str:
    candidate = raw.strip()
    if not candidate:
        return ""
    for sep in ("@", " "):
        if sep in candidate:
            candidate = candidate.split(sep, 1)[0].strip()
    return candidate.strip("./")


def _is_blocked_host(hostname: str) -> bool:
    host = (hostname or "").strip().lower()
    if not host:
        return True
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return bool(
        ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified
    )


def _parse_clawhub_search_output(text: str) -> list[MarketplaceSkill]:
    parsed: list[MarketplaceSkill] = []
    if not text:
        return parsed
    try:
        obj = json.loads(text)
        if isinstance(obj, list):
            for item in obj:
                if not isinstance(item, dict):
                    continue
                name = str(item.get("slug") or item.get("name") or "").strip()
                if not name:
                    continue
                parsed.append(
                    MarketplaceSkill(
                        name=name,
                        description=str(item.get("description", "")).strip(),
                        url=str(item.get("url") or item.get("homepage") or "").strip(),
                        category=str(item.get("category", "")).strip(),
                        runtime=str(item.get("runtime", "")).strip(),
                        tags=item.get("tags", []) if isinstance(item.get("tags"), list) else [],
                    )
                )
            return parsed
    except Exception:
        pass
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(("Search", "Found", "-")):
            continue
        name = _extract_skill_name(line)
        if name:
            parsed.append(MarketplaceSkill(name=name, description=f"Skill: {name}"))
    return parsed


async def _search_skills_from_github(query: str) -> list[MarketplaceSkill]:
    import httpx

    url = f"{CLAWHUB_API}/repos/{CLAWHUB_REPO}/contents/{CLAWHUB_SKILLS_PATH}"
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, headers={"Accept": "application/vnd.github.v3+json"})
            if resp.status_code == 404:
                logger.debug("ClawHub skills directory not found")
                return []
            resp.raise_for_status()
            items = resp.json()
    except Exception:
        logger.exception("Failed to fetch GitHub skills index")
        return []

    if not isinstance(items, list):
        return []
    query_lower = query.lower()
    results: list[MarketplaceSkill] = []
    for item in items:
        if item.get("type") != "dir":
            continue
        name = str(item.get("name", "")).strip()
        if query_lower in name.lower():
            results.append(MarketplaceSkill(name=name, url=item.get("html_url", ""), description=f"Skill: {name}"))
    return results


async def search_skills(query: str) -> list[MarketplaceSkill]:
    """Search for skills with clawhub CLI first, then GitHub fallback."""
    ok, out = _run_clawhub("search", query, "--json")
    if ok:
        parsed = _parse_clawhub_search_output(out)
        if parsed:
            return parsed
    ok2, out2 = _run_clawhub("search", query)
    if ok2:
        parsed = _parse_clawhub_search_output(out2)
        if parsed:
            return parsed
    return await _search_skills_from_github(query)


async def fetch_skill_content(name: str) -> str | None:
    """Fetch SKILL.md for a named skill (GitHub fallback)."""
    import httpx

    url = f"{CLAWHUB_API}/repos/{CLAWHUB_REPO}/contents/{CLAWHUB_SKILLS_PATH}/{name}/SKILL.md"
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, headers={"Accept": "application/vnd.github.v3.raw"})
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            return resp.text
    except Exception:
        logger.exception("Failed to fetch skill '%s' from GitHub fallback", name)
        return None


def guess_skill_name_from_url(url: str) -> str:
    parsed = urlparse(url)
    path = parsed.path.rstrip("/")
    if not path:
        return "skill"
    name = path.rsplit("/", 1)[-1]
    if name.lower() == "skill.md":
        name = path.rsplit("/", 2)[-2] if "/" in path else "skill"
    if name in {"tree", "blob"}:
        return "skill"
    return _extract_skill_name(name) or "skill"


async def _fetch_text(url: str) -> str | None:
    import httpx

    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        logger.warning("Rejected non-http(s) skill URL: %s", url)
        return None
    if _is_blocked_host(parsed.hostname or ""):
        logger.warning("Rejected blocked host for skill URL: %s", url)
        return None
    try:
        async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as client:
            resp = await client.get(url)
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            text = resp.text
            if len(text) > 512_000:
                logger.warning("Rejected oversized skill URL response: %s", url)
                return None
            return text
    except Exception:
        logger.exception("Failed to fetch URL: %s", url)
        return None


async def fetch_skill_from_url(url: str) -> str | None:
    """Fetch SKILL.md from a URL."""
    target = url.rstrip("/")
    if not target.endswith("SKILL.md"):
        target += "/SKILL.md"
    return await _fetch_text(target)


async def _fetch_github_tree_bundle(
    owner: str,
    repo: str,
    ref: str,
    base_path: str,
) -> dict[str, str] | None:
    import httpx

    headers = {"Accept": "application/vnd.github.v3+json"}
    files: dict[str, str] = {}
    max_files = 80
    max_total_chars = 800_000
    total_chars = 0

    async def walk(path: str) -> None:
        nonlocal total_chars
        if len(files) >= max_files:
            return
        list_url = f"{CLAWHUB_API}/repos/{owner}/{repo}/contents/{path}?ref={ref}"
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.get(list_url, headers=headers)
            if resp.status_code == 404:
                return
            resp.raise_for_status()
            items = resp.json()
            if isinstance(items, dict):
                items = [items]
            if not isinstance(items, list):
                return
            for item in items:
                if len(files) >= max_files or total_chars >= max_total_chars:
                    return
                if not isinstance(item, dict):
                    continue
                item_type = item.get("type")
                item_path = str(item.get("path", "")).strip()
                if not item_path:
                    continue
                if item_type == "dir":
                    await walk(item_path)
                    continue
                if item_type != "file":
                    continue
                download_url = str(item.get("download_url", "")).strip()
                if not download_url:
                    continue
                file_resp = await client.get(download_url)
                if file_resp.status_code != 200:
                    continue
                text = file_resp.text
                rel = item_path[len(base_path) :].lstrip("/")
                if not rel:
                    rel = Path(item_path).name
                files[rel] = text
                total_chars += len(text)

    try:
        await walk(base_path)
    except Exception:
        logger.exception("Failed to fetch GitHub tree bundle: %s/%s %s %s", owner, repo, ref, base_path)
        return None
    if "SKILL.md" not in files:
        return None
    return files


async def fetch_skill_bundle_from_url(url: str) -> tuple[str, dict[str, str]] | None:
    """Fetch skill bundle from URL (GitHub tree/root or direct SKILL.md URL)."""
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    path = parsed.path.rstrip("/")
    if host in {"github.com", "www.github.com"}:
        parts = [p for p in path.split("/") if p]
        if len(parts) >= 4 and parts[2] == "tree":
            owner, repo, _, ref = parts[:4]
            base_path = "/".join(parts[4:]) if len(parts) > 4 else ""
            if not base_path:
                base_path = ""
            name = _extract_skill_name(parts[-1]) if len(parts) > 4 else _extract_skill_name(repo)
            if not name:
                name = "skill"
            bundle = await _fetch_github_tree_bundle(owner, repo, ref, base_path)
            if bundle:
                return name, bundle
        if len(parts) >= 2:
            owner, repo = parts[0], parts[1]
            name = _extract_skill_name(repo)
            for ref in ("main", "master"):
                raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/{ref}/SKILL.md"
                text = await _fetch_text(raw_url)
                if text:
                    return name or "skill", {"SKILL.md": text}
    text = await fetch_skill_from_url(url)
    if not text:
        return None
    return guess_skill_name_from_url(url), {"SKILL.md": text}


def _is_safe_relpath(relpath: str) -> bool:
    p = Path(relpath)
    cleaned = relpath.strip()
    if not cleaned:
        return False
    if p.is_absolute() or ".." in p.parts:
        return False
    if any(part in {"", ".", ".."} for part in p.parts):
        return False
    return not len(cleaned) > 240


def install_skill_bundle(
    name: str,
    files: dict[str, str],
    workspace_dir: str | Path | None = None,
    *,
    force: bool = False,
    expected_checksum: str | None = None,
) -> Path:
    """Install a complete skill bundle (SKILL.md + supporting files).

    Args:
        name: Skill name (used as directory name).
        files: Mapping of relative paths to file contents. Must include "SKILL.md".
        workspace_dir: Target workspace directory. Defaults to ~/.pyclaw/workspace.
        force: Overwrite existing installation if True.
        expected_checksum: If provided, verify SKILL.md content checksum matches
            before writing. Raises ValueError on mismatch.

    Returns:
        Path to the installed SKILL.md file.

    Raises:
        FileExistsError: Skill already installed and force is False.
        ValueError: Bundle missing SKILL.md, unsafe path, or checksum mismatch.
    """
    from pyclaw.agents.progress import ProgressEvent, ProgressStatus, emit_progress

    if workspace_dir is None:
        workspace_dir = Path.home() / ".pyclaw" / "workspace"
    workspace_dir = Path(workspace_dir)
    task_id = f"install-skill-{name}"
    emit_progress(
        ProgressEvent(task_id=task_id, status=ProgressStatus.STARTED, message=f"Installing skill '{name}'...")
    )
    skill_root = workspace_dir / ".skills" / name
    skill_file = skill_root / "SKILL.md"
    if skill_file.exists() and not force:
        emit_progress(
            ProgressEvent(task_id=task_id, status=ProgressStatus.FAILED, message=f"Skill '{name}' already installed")
        )
        raise FileExistsError(f"Skill '{name}' already installed at {skill_file}. Use --force to overwrite.")
    if force and skill_root.exists():
        shutil.rmtree(skill_root, ignore_errors=True)
    skill_root.mkdir(parents=True, exist_ok=True)
    if "SKILL.md" not in files:
        raise ValueError("Skill bundle missing SKILL.md")
    # Verify checksum before writing any files
    if expected_checksum:
        actual = compute_skill_checksum(files.get("SKILL.md", ""))
        if actual != expected_checksum:
            emit_progress(
                ProgressEvent(task_id=task_id, status=ProgressStatus.FAILED, message=f"Checksum mismatch for '{name}'")
            )
            raise ValueError(f"Checksum mismatch for '{name}': expected {expected_checksum}, got {actual}")
    for relpath, content in files.items():
        if not _is_safe_relpath(relpath):
            raise ValueError(f"Unsafe path in bundle: {relpath}")
        out = skill_root / relpath
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(content, encoding="utf-8")
    emit_progress(
        ProgressEvent(
            task_id=task_id, status=ProgressStatus.COMPLETED, progress=1.0, message=f"Skill '{name}' installed"
        )
    )
    return skill_file


def install_skill(
    name: str,
    content: str,
    workspace_dir: str | Path | None = None,
    *,
    force: bool = False,
    expected_checksum: str | None = None,
) -> Path:
    """Install one-file skill content.

    Args:
        name: Skill name (used as directory name).
        content: SKILL.md content string.
        workspace_dir: Target workspace directory. Defaults to ~/.pyclaw/workspace.
        force: Overwrite existing installation if True.
        expected_checksum: If provided, verify content checksum matches before writing.

    Returns:
        Path to the installed SKILL.md file.
    """
    return install_skill_bundle(
        name=name,
        files={"SKILL.md": content},
        workspace_dir=workspace_dir,
        force=force,
        expected_checksum=expected_checksum,
    )


def install_skill_via_clawhub(name: str) -> tuple[bool, str]:
    """Install a skill with local clawhub CLI if available."""
    return _run_clawhub("install", name, timeout_s=60.0)


def remove_skill(name: str, workspace_dir: str | Path | None = None) -> bool:
    """Remove an installed skill (local pyclaw workspace first, then clawhub fallback)."""
    if workspace_dir is None:
        workspace_dir = Path.home() / ".pyclaw" / "workspace"
    workspace_dir = Path(workspace_dir)
    skills_dir = workspace_dir / ".skills" / name
    if skills_dir.exists():
        shutil.rmtree(skills_dir)
        return True
    ok, _ = _run_clawhub("uninstall", name)
    return ok


def clawhub_sync() -> tuple[bool, str]:
    return _run_clawhub("sync", timeout_s=60.0)


def clawhub_update_all() -> tuple[bool, str]:
    return _run_clawhub("update", "--all", timeout_s=60.0)


def clawhub_inspect(name: str) -> tuple[bool, str]:
    ok, out = _run_clawhub("inspect", name, "--json")
    if ok:
        return ok, out
    return _run_clawhub("inspect", name)


def _parse_clawhub_list_output(text: str) -> list[dict[str, str]]:
    parsed: list[dict[str, str]] = []
    if not text:
        return parsed
    try:
        obj = json.loads(text)
        if isinstance(obj, list):
            for item in obj:
                if isinstance(item, dict):
                    name = str(item.get("slug") or item.get("name") or "").strip()
                    if name:
                        parsed.append({"name": name, "path": str(item.get("path", "")), "source": "clawhub"})
            return parsed
    except Exception:
        pass
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(("Installed", "-")):
            continue
        name = _extract_skill_name(line)
        if name:
            parsed.append({"name": name, "path": "", "source": "clawhub"})
    return parsed


def list_installed_skills(workspace_dir: str | Path | None = None) -> list[dict[str, str]]:
    """List installed skills in pyclaw workspace and clawhub (if available)."""
    if workspace_dir is None:
        workspace_dir = Path.home() / ".pyclaw" / "workspace"
    workspace_dir = Path(workspace_dir)
    results: list[dict[str, str]] = []
    for src_dir_name, source in [
        (".skills", "workspace"),
        (".cursor/skills", "cursor"),
        (".agents/skills", "agents"),
    ]:
        src_dir = workspace_dir / src_dir_name
        if not src_dir.is_dir():
            continue
        for child in sorted(src_dir.iterdir()):
            skill_file = child / "SKILL.md"
            if child.is_dir() and skill_file.exists():
                results.append({"name": child.name, "path": str(skill_file), "source": source})

    ok, out = _run_clawhub("list", "--json")
    if ok:
        results.extend(_parse_clawhub_list_output(out))
    else:
        ok2, out2 = _run_clawhub("list")
        if ok2:
            results.extend(_parse_clawhub_list_output(out2))
    dedup: dict[tuple[str, str], dict[str, str]] = {}
    for item in results:
        key = (item.get("name", ""), item.get("source", ""))
        dedup[key] = item
    return [dedup[k] for k in sorted(dedup.keys())]


def _derive_category(skill_name: str, content: str) -> str:
    """Derive a category label from skill metadata or naming convention."""
    name_lower = skill_name.lower()
    # Check content for capability or category hints
    for line in content.splitlines()[:20]:
        stripped = line.strip().lower()
        if stripped.startswith("capability:"):
            caps = stripped.split(":", 1)[1].strip()
            if caps:
                # Use first capability token as category hint
                first_cap = caps.split(",")[0].split("-")[0].strip()
                if first_cap:
                    return first_cap.title()
        if stripped.startswith("category:"):
            cat = stripped.split(":", 1)[1].strip()
            if cat:
                return cat.title()

    # Fallback: infer from name
    name_categories: dict[str, str] = {
        "pdf": "Office",
        "docx": "Office",
        "xlsx": "Office",
        "pptx": "Office",
        "release": "DevOps",
        "repo": "Development",
        "docs": "Documentation",
        "mcp": "Infrastructure",
        "node": "Infrastructure",
        "channel": "Channels",
        "browser": "Automation",
        "lightpanda": "Automation",
        "social": "Marketing",
        "wechat": "Marketing",
        "xiaohongshu": "Marketing",
        "incident": "Operations",
        "tracker": "Development",
        "health": "Operations",
    }
    for key, category in name_categories.items():
        if key in name_lower:
            return category
    return "General"


def _extract_example_usage(content: str) -> list[str]:
    """Extract example usage lines from skill content."""
    examples: list[str] = []
    in_usage = False
    for line in content.splitlines():
        stripped = line.strip()
        # Detect usage section headers
        if stripped.lower().startswith(("## usage", "## example", "## how to")):
            in_usage = True
            continue
        if in_usage and stripped.startswith("## ") and not stripped.lower().startswith(("## usage", "## example")):
            in_usage = False
            continue
        if in_usage and stripped.startswith("> "):
            examples.append(stripped[2:].strip())
        if len(examples) >= 4:
            break
    return examples


async def fetch_all_skills(
    *,
    workspace_dir: Path | None = None,
    category: str | None = None,
    query: str | None = None,
) -> list[MarketplaceSkill]:
    """Fetch all available skills (installed + remote), with optional filtering.

    Combines locally loaded skills with ClawHub marketplace results.
    Marks installed skills and deduplicates by name.
    """
    from pyclaw.agents.skills.loader import load_workspace_skill_entries

    if workspace_dir is None:
        workspace_dir = Path.cwd()
    workspace_dir = Path(workspace_dir)

    # Build installed skill names set
    installed = list_installed_skills(workspace_dir=workspace_dir)
    installed_names = {s["name"] for s in installed}

    # Load local skills with full metadata
    local_entries = load_workspace_skill_entries(workspace_dir)
    all_skills: list[MarketplaceSkill] = []

    for entry in local_entries:
        category_label = _derive_category(entry.name, entry.content)
        deps = entry.runtime_contract.deps if entry.runtime_contract else []
        all_skills.append(
            MarketplaceSkill(
                name=entry.name,
                description=entry.frontmatter.get("description", ""),
                url=entry.metadata.homepage or "",
                category=category_label,
                runtime=entry.runtime_contract.runtime if entry.runtime_contract else "python-native",
                dependencies=deps,
                is_installed=True,
                content=entry.content,
            )
        )

    # Fetch remote skills from ClawHub
    try:
        remote_skills = await search_skills(query or "")
    except Exception:
        logger.debug("Failed to fetch remote skills", exc_info=True)
        remote_skills = []

    # Merge remote skills, skip duplicates
    seen_names = {s.name for s in all_skills}
    for remote in remote_skills:
        if remote.name in seen_names:
            continue
        seen_names.add(remote.name)
        remote.is_installed = remote.name in installed_names
        if not remote.category:
            remote.category = _derive_category(remote.name, remote.description)
        all_skills.append(remote)

    # Apply filters
    if category:
        cat_lower = category.lower()
        all_skills = [s for s in all_skills if s.category.lower() == cat_lower or cat_lower in s.category.lower()]

    if query:
        q_lower = query.lower()
        all_skills = [
            s
            for s in all_skills
            if q_lower in s.name.lower()
            or q_lower in s.description.lower()
            or q_lower in s.category.lower()
            or any(q_lower in t.lower() for t in s.tags)
        ]

    # Sort: installed first, then alphabetically
    all_skills.sort(key=lambda s: (not s.is_installed, s.name.lower()))
    return all_skills


# ─── Version Management ────────────────────────────────────────────────────


def _parse_version(version_str: str) -> tuple[int, ...]:
    """Parse a semver-like version string into a comparable tuple.

    Handles versions like '1.2.3', '0.1.0', '2.0.0-beta.1'.
    Pre-release versions sort lower than their release counterparts.
    """
    if not version_str:
        return (0, 0, 0)
    # Strip leading 'v' if present
    v = version_str.lstrip("v").strip()
    # Split off pre-release suffix
    base = v.split("-", 1)[0]
    parts: list[int] = []
    for part in base.split("."):
        try:
            parts.append(int(part))
        except ValueError:
            parts.append(0)
    # Pad to at least 3 parts
    while len(parts) < 3:
        parts.append(0)
    # Pre-release indicator: 0 for release, -1 for pre-release
    pre = -1 if "-" in v else 0
    return tuple(parts[:3]) + (pre,)


def _version_gte(a: str, b: str) -> bool:
    """Return True if version a >= version b."""
    return _parse_version(a) >= _parse_version(b)


def compute_skill_checksum(content: str) -> str:
    """Compute SHA-256 checksum of skill content for integrity verification.

    Returns the full 64-character hexadecimal digest for strong collision resistance.
    """
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


# ─── Signature Verification ────────────────────────────────────────────────────

# Known public keys for ClawHub maintainers (for future signature verification)
KNOWN_SIGNATURE_KEYS: set[str] = set()


def verify_skill_signature(
    name: str,
    files: dict[str, str],
) -> tuple[bool, str]:
    """Verify skill bundle signature if present.

    Checks for a .signature or SIGNATURE file in the bundle. If present,
    attempts to verify against known public keys. If absent, logs a warning
    but returns (False, "no signature") to allow installation.

    This is a foundation for future signing infrastructure. ClawHub does not
    yet have a complete signing system, so signatures are optional.

    Args:
        name: Skill name for logging purposes.
        files: Skill bundle files mapping (relative path -> content).

    Returns:
        Tuple of (verified: bool, reason: str).
        - (True, "...") if signature verified successfully.
        - (False, "no signature") if no signature file present.
        - (False, "invalid: ...") if signature present but verification failed.
    """
    # Check for signature files
    signature_content: str | None = None
    for sig_file in (".signature", "SIGNATURE"):
        if sig_file in files:
            signature_content = files[sig_file]
            break

    if signature_content is None:
        logger.debug("No signature file found for skill '%s' (optional)", name)
        return False, "no signature"

    signature_content = signature_content.strip()
    if not signature_content:
        logger.warning("Empty signature file for skill '%s'", name)
        return False, "invalid: empty signature"

    # Extract signed content (SKILL.md checksum or full manifest)
    skill_md = files.get("SKILL.md", "")
    if not skill_md:
        return False, "invalid: missing SKILL.md"

    checksum = compute_skill_checksum(skill_md)

    # For now, we support a simple signature format:
    # SHA256:<checksum>
    # This is a placeholder for future GPG/Ed25519 signatures.
    # When ClawHub has a signing infrastructure, this will be enhanced.
    expected_prefix = f"SHA256:{checksum}"

    if signature_content.startswith(expected_prefix):
        logger.info("Skill '%s' signature verified (checksum match)", name)
        return True, "checksum verified"

    # Check if signature looks like a key-based signature (future)
    # Format: "KEY:<key_id>:<signature_hex>"
    if signature_content.startswith("KEY:"):
        parts = signature_content.split(":", 2)
        if len(parts) >= 3:
            key_id = parts[1]
            # For future: verify against known public keys
            if key_id in KNOWN_SIGNATURE_KEYS:
                logger.info("Skill '%s' signature verified with key %s", name, key_id)
                return True, f"key {key_id} verified"
            logger.warning(
                "Skill '%s' has signature with unknown key %s. Add key to KNOWN_SIGNATURE_KEYS to verify.",
                name,
                key_id,
            )
            return False, f"unknown key: {key_id}"

    logger.warning(
        "Skill '%s' has unrecognized signature format: %s...",
        name,
        signature_content[:50],
    )
    return False, "invalid: unrecognized format"


def _read_installed_skill_metadata(
    name: str,
    workspace_dir: Path,
) -> dict[str, str]:
    """Read installed skill metadata from the skill directory.

    Returns a dict with keys like 'version', 'author', 'checksum', etc.
    """
    meta: dict[str, str] = {}
    skill_dir = workspace_dir / ".skills" / name
    meta_file = skill_dir / ".clawhub-meta.json"

    if meta_file.exists():
        try:
            data = json.loads(meta_file.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for key in (
                    "version",
                    "author",
                    "license",
                    "checksum",
                    "installed_version",
                    "installed_at",
                    "source_url",
                ):
                    if key in data:
                        meta[key] = str(data[key])
        except (json.JSONDecodeError, OSError):
            logger.debug("Failed to read skill metadata for %s", name)

    # Also parse frontmatter from SKILL.md for version/author
    skill_file = skill_dir / "SKILL.md"
    if skill_file.exists():
        try:
            content = skill_file.read_text(encoding="utf-8")
            from pyclaw.agents.skills.loader import _parse_frontmatter

            fm, _ = _parse_frontmatter(content)
            for key in ("version", "author", "license"):
                if key in fm and key not in meta:
                    meta[key] = fm[key]
        except (OSError, UnicodeDecodeError):
            pass

    return meta


def _write_installed_skill_metadata(
    name: str,
    workspace_dir: Path,
    metadata: dict[str, str],
) -> None:
    """Write or merge skill metadata into the .clawhub-meta.json file."""
    skill_dir = workspace_dir / ".skills" / name
    meta_file = skill_dir / ".clawhub-meta.json"

    existing: dict[str, str] = {}
    if meta_file.exists():
        try:
            data = json.loads(meta_file.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                existing = {str(k): str(v) for k, v in data.items()}
        except (json.JSONDecodeError, OSError):
            pass

    existing.update(metadata)
    skill_dir.mkdir(parents=True, exist_ok=True)
    meta_file.write_text(json.dumps(existing, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


async def fetch_skill_metadata(name: str) -> dict[str, str]:
    """Fetch full metadata for a skill from ClawHub (GitHub fallback).

    Returns a dict with available metadata fields:
    version, author, license, checksum, changelog, updated_at, etc.
    """
    import httpx

    metadata: dict[str, str] = {}

    # Try ClawHub CLI first
    ok, out = _run_clawhub("inspect", name, "--json")
    if ok and out:
        try:
            data = json.loads(out)
            if isinstance(data, dict):
                for key in ("version", "author", "license", "checksum", "updated_at", "min_pyclaw_version"):
                    if key in data:
                        metadata[key] = str(data[key])
                if "changelog" in data and isinstance(data["changelog"], list):
                    metadata["changelog"] = json.dumps(data["changelog"])
        except json.JSONDecodeError:
            pass

    if metadata:
        return metadata

    # GitHub fallback: fetch SKILL.md and parse frontmatter
    content = await fetch_skill_content(name)
    if content:
        from pyclaw.agents.skills.loader import _parse_frontmatter

        fm, _ = _parse_frontmatter(content)
        for key in ("version", "author", "license", "min_pyclaw_version"):
            if key in fm:
                metadata[key] = fm[key]

        # Compute checksum from content
        metadata["checksum"] = compute_skill_checksum(content)

    # Fetch commit info for updated_at
    try:
        url = f"{CLAWHUB_API}/repos/{CLAWHUB_REPO}/commits?path={CLAWHUB_SKILLS_PATH}/{name}/SKILL.md&per_page=1"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers={"Accept": "application/vnd.github.v3+json"})
            if resp.status_code == 200:
                commits = resp.json()
                if isinstance(commits, list) and commits:
                    commit = commits[0].get("commit", {})
                    date = commit.get("committer", {}).get("date", "")
                    if date:
                        metadata["updated_at"] = date
    except Exception:
        logger.debug("Failed to fetch commit info for skill %s", name)

    return metadata


async def check_skill_updates(
    *,
    workspace_dir: Path | None = None,
) -> list[SkillVersionInfo]:
    """Check all installed skills for available updates.

    Compares installed version against the latest available version
    from ClawHub/GitHub.
    """
    if workspace_dir is None:
        workspace_dir = Path.cwd()
    workspace_dir = Path(workspace_dir)

    installed = list_installed_skills(workspace_dir=workspace_dir)
    if not installed:
        return []

    results: list[SkillVersionInfo] = []
    for skill_info in installed:
        name = skill_info["name"]
        source = skill_info.get("source", "")

        # Only check workspace-installed skills (not clawhub-managed)
        if source == "clawhub":
            # clawhub-managed skills use their own update mechanism
            continue

        # Read installed metadata
        installed_meta = _read_installed_skill_metadata(name, workspace_dir)
        installed_version = installed_meta.get("version", installed_meta.get("installed_version", ""))

        # Fetch remote metadata
        try:
            remote_meta = await fetch_skill_metadata(name)
        except Exception:
            logger.debug("Failed to fetch remote metadata for %s", name)
            remote_meta = {}

        available_version = remote_meta.get("version", "")
        remote_checksum = remote_meta.get("checksum", "")
        installed_checksum = installed_meta.get("checksum", "")

        # Determine if update is available
        has_update = False
        if available_version and installed_version:
            has_update = _parse_version(available_version) > _parse_version(installed_version)
        elif available_version and not installed_version:
            # No version tracked locally, assume update available
            has_update = True

        # Checksum mismatch indicates content changed
        checksum_match = True
        if remote_checksum and installed_checksum:
            checksum_match = remote_checksum == installed_checksum
            if not checksum_match and not has_update:
                has_update = True

        # Parse changelog
        changelog: list[str] = []
        if "changelog" in remote_meta:
            try:
                parsed = json.loads(remote_meta["changelog"])
                if isinstance(parsed, list):
                    changelog = [str(c) for c in parsed]
            except json.JSONDecodeError:
                changelog = [remote_meta["changelog"]]

        results.append(
            SkillVersionInfo(
                name=name,
                installed_version=installed_version or DEFAULT_SKILL_VERSION,
                available_version=available_version or installed_version or DEFAULT_SKILL_VERSION,
                has_update=has_update,
                changelog=changelog,
                checksum_match=checksum_match,
            )
        )

    return results


async def upgrade_skill(
    name: str,
    *,
    workspace_dir: Path | None = None,
    force: bool = False,
) -> Path:
    """Upgrade a skill to its latest available version.

    Fetches the latest version from ClawHub/GitHub and reinstalls.
    Verifies content checksum against remote metadata before installing.
    Records the new version in metadata.

    Raises:
        ValueError: Skill not found or checksum mismatch with remote metadata.
    """
    if workspace_dir is None:
        workspace_dir = Path.cwd()
    workspace_dir = Path(workspace_dir)

    # Try clawhub CLI first
    ok, out = install_skill_via_clawhub(name)
    if ok:
        # Record metadata
        _write_installed_skill_metadata(
            name,
            workspace_dir,
            {"installed_at": datetime.now().isoformat(), "source": "clawhub"},
        )
        skill_dir = workspace_dir / ".skills" / name / "SKILL.md"
        if not skill_dir.exists():
            # clawhub may install elsewhere; return a plausible path
            return skill_dir
        return skill_dir

    # GitHub fallback: fetch content and install
    content = await fetch_skill_content(name)
    if content is None:
        raise ValueError(f"Skill '{name}' not found on ClawHub or GitHub.")

    checksum = compute_skill_checksum(content)

    # Verify checksum against remote metadata before installing
    try:
        remote_meta = await fetch_skill_metadata(name)
        remote_checksum = remote_meta.get("checksum", "")
        if remote_checksum and checksum != remote_checksum:
            raise ValueError(
                f"Checksum mismatch for skill '{name}': "
                f"content checksum {checksum} != remote metadata checksum {remote_checksum}. "
                f"This may indicate a tampered or corrupted download."
            )
    except ValueError:
        raise
    except Exception:
        logger.debug("Could not verify remote checksum for skill '%s'", name, exc_info=True)

    path = install_skill(name, content, workspace_dir=workspace_dir, force=True)

    # Extract version from frontmatter
    from pyclaw.agents.skills.loader import _parse_frontmatter

    fm, _ = _parse_frontmatter(content)
    version = fm.get("version", DEFAULT_SKILL_VERSION)
    author = fm.get("author", "")

    # Record metadata
    _write_installed_skill_metadata(
        name,
        workspace_dir,
        {
            "version": version,
            "installed_version": version,
            "author": author,
            "checksum": checksum,
            "installed_at": datetime.now().isoformat(),
            "source": "github",
        },
    )

    return path


# ─── Skill Validation and Packaging ────────────────────────────────────────


def validate_skill(skill_dir: str | Path) -> list[str]:
    """Validate a skill directory for ClawHub submission readiness.

    Returns a list of validation issues. Empty list means valid.
    """
    skill_dir = Path(skill_dir)
    issues: list[str] = []

    if not skill_dir.is_dir():
        return [f"Skill directory does not exist: {skill_dir}"]

    # Must have SKILL.md
    skill_file = skill_dir / "SKILL.md"
    if not skill_file.exists():
        issues.append("Missing required file: SKILL.md")
    else:
        try:
            content = skill_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            issues.append(f"Cannot read SKILL.md: {exc}")
            return issues

        # Parse frontmatter
        from pyclaw.agents.skills.loader import _parse_frontmatter

        fm, body = _parse_frontmatter(content)

        # Check required frontmatter fields
        if not fm.get("skill_key") and not fm.get("skillKey"):
            # Derive from directory name
            pass  # Not strictly required, but recommended

        # Check version format
        version = fm.get("version", "")
        if version and not _is_valid_version(version):
            issues.append(f"Invalid version format: '{version}'. Expected semver (e.g. '1.0.0').")

        # Check body is non-empty
        if not body.strip():
            issues.append("SKILL.md body is empty — skill must contain instructions.")

        # Check body length
        if len(body.strip()) < 50:
            issues.append("SKILL.md body is too short — skill should have meaningful instructions (>= 50 chars).")

        # Check for security-sensitive patterns
        security_patterns = [
            ("os.system(", "Use subprocess or async httpx instead of os.system()"),
            ("eval(", "Avoid eval() in skills — use ast.literal_eval() for safe parsing"),
            ("exec(", "Avoid exec() in skills"),
            ("subprocess.call(", "Use subprocess.run() with explicit arguments instead of call()"),
        ]
        for pattern, msg in security_patterns:
            if pattern in content:
                issues.append(f"Security concern: {msg}")

    # Check for oversized files
    max_file_bytes = 32_768
    for f in skill_dir.rglob("*"):
        if f.is_file():
            try:
                size = f.stat().st_size
                if size > max_file_bytes:
                    issues.append(f"File too large: {f.relative_to(skill_dir)} ({size} bytes, max {max_file_bytes})")
            except OSError:
                pass

    # Check for forbidden files
    forbidden_names = {".env", "credentials", "secrets", ".git", "__pycache__"}
    for f in skill_dir.iterdir():
        if f.name in forbidden_names:
            issues.append(f"Forbidden file/directory: {f.name}")

    # Check for unsafe file types (binary executables and script files)
    unsafe_extensions = {
        # Binary executables
        ".exe",
        ".dll",
        ".so",
        ".dylib",
        # Executable scripts (potentially dangerous)
        ".sh",
        ".bat",
        ".ps1",
        ".cmd",
    }
    for f in skill_dir.rglob("*"):
        if f.is_file():
            ext = f.suffix.lower()
            if ext in unsafe_extensions:
                issues.append(f"Unsafe file type: {f.relative_to(skill_dir)} ({ext} files are not allowed in skills)")

    # Check for safe relative paths (no symlinks escaping)
    for f in skill_dir.rglob("*"):
        try:
            resolved = f.resolve()
            if not str(resolved).startswith(str(skill_dir.resolve())):
                issues.append(f"Symlink escapes skill directory: {f.relative_to(skill_dir)}")
                break
        except (OSError, ValueError):
            pass

    return issues


def _is_valid_version(version: str) -> bool:
    """Check if a version string follows semver-like format."""
    import re

    # Matches: 1.0.0, 0.1.0, 2.0.0-beta.1, v1.0.0
    pattern = r"^v?\d+\.\d+\.\d+([+-][\w.]+)?$"
    return bool(re.match(pattern, version))


def pack_skill(skill_dir: str | Path) -> dict[str, str]:
    """Pack a skill directory into a dict suitable for ClawHub submission.

    Returns a dict mapping relative file paths to file contents.
    Includes SKILL.md and any supporting files.
    """
    skill_dir = Path(skill_dir)
    if not skill_dir.is_dir():
        raise ValueError(f"Skill directory does not exist: {skill_dir}")

    skill_file = skill_dir / "SKILL.md"
    if not skill_file.exists():
        raise ValueError(f"Missing required file: SKILL.md in {skill_dir}")

    # Validate before packing
    issues = validate_skill(skill_dir)
    critical_issues = [i for i in issues if "Missing required" in i or "Security concern" in i]
    if critical_issues:
        raise ValueError("Skill validation failed:\n" + "\n".join(f"  - {i}" for i in critical_issues))

    # Collect files
    skip_dirs = {".git", "node_modules", "__pycache__", ".venv", "venv", ".mypy_cache"}
    skip_names = {".clawhub-meta.json", ".DS_Store", "Thumbs.db"}
    max_files = 80
    max_total_chars = 800_000
    total_chars = 0
    files: dict[str, str] = {}

    for f in sorted(skill_dir.rglob("*")):
        if len(files) >= max_files or total_chars >= max_total_chars:
            break
        if not f.is_file():
            continue
        # Skip unwanted directories
        if any(part in skip_dirs for part in f.relative_to(skill_dir).parts):
            continue
        # Skip unwanted files
        if f.name in skip_names or f.name.endswith(".pyc"):
            continue
        try:
            content = f.read_text(encoding="utf-8")
            rel = str(f.relative_to(skill_dir))
            files[rel] = content
            total_chars += len(content)
        except (OSError, UnicodeDecodeError):
            # Skip binary/unreadable files
            continue

    if "SKILL.md" not in files:
        raise ValueError("SKILL.md missing after packing — internal error")

    return files
