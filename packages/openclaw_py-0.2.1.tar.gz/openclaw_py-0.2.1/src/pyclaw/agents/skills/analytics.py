"""Skill analytics module — track usage, errors, and performance metrics."""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock
from typing import Any

logger = logging.getLogger(__name__)

# Default storage path
DEFAULT_USAGE_FILE = "skill_usage.json"


@dataclass
class SkillUsageStats:
    """Usage statistics for a single skill."""

    skill_key: str
    invoke_count: int = 0
    success_count: int = 0
    error_count: int = 0
    last_invoked: datetime | None = None
    last_status: str = "unknown"  # success, error, unknown
    avg_duration_ms: float = 0.0
    total_duration_ms: float = 0.0
    first_invoked: datetime | None = None
    last_error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "skill_key": self.skill_key,
            "invoke_count": self.invoke_count,
            "success_count": self.success_count,
            "error_count": self.error_count,
            "last_invoked": self.last_invoked.isoformat() if self.last_invoked else None,
            "last_status": self.last_status,
            "avg_duration_ms": round(self.avg_duration_ms, 2),
            "total_duration_ms": round(self.total_duration_ms, 2),
            "first_invoked": self.first_invoked.isoformat() if self.first_invoked else None,
            "last_error": self.last_error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SkillUsageStats:
        """Create from dictionary."""
        stats = cls(skill_key=data.get("skill_key", "unknown"))
        stats.invoke_count = data.get("invoke_count", 0)
        stats.success_count = data.get("success_count", 0)
        stats.error_count = data.get("error_count", 0)
        stats.last_status = data.get("last_status", "unknown")
        stats.avg_duration_ms = data.get("avg_duration_ms", 0.0)
        stats.total_duration_ms = data.get("total_duration_ms", 0.0)
        stats.last_error = data.get("last_error")

        # Parse timestamps
        if data.get("last_invoked"):
            try:
                stats.last_invoked = datetime.fromisoformat(data["last_invoked"])
            except (ValueError, TypeError):
                pass
        if data.get("first_invoked"):
            try:
                stats.first_invoked = datetime.fromisoformat(data["first_invoked"])
            except (ValueError, TypeError):
                pass

        return stats


@dataclass
class SkillAnalyticsReport:
    """Aggregated analytics report."""

    total_skills: int
    total_invocations: int
    total_successes: int
    total_errors: int
    top_skills: list[SkillUsageStats] = field(default_factory=list)
    recent_errors: list[dict[str, Any]] = field(default_factory=list)
    generated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "total_skills": self.total_skills,
            "total_invocations": self.total_invocations,
            "total_successes": self.total_successes,
            "total_errors": self.total_errors,
            "success_rate": (
                round(self.total_successes / self.total_invocations * 100, 2) if self.total_invocations > 0 else 0.0
            ),
            "top_skills": [s.to_dict() for s in self.top_skills],
            "recent_errors": self.recent_errors,
            "generated_at": self.generated_at.isoformat(),
        }


class SkillAnalyticsManager:
    """Manager for skill usage analytics.

    Thread-safe implementation that persists usage data to JSON file.
    """

    _instance: SkillAnalyticsManager | None = None
    _lock = Lock()

    def __init__(self, storage_path: Path | None = None) -> None:
        """Initialize analytics manager.

        Args:
            storage_path: Path to the usage data JSON file
        """
        self._storage_path = storage_path
        self._data: dict[str, SkillUsageStats] = {}
        self._loaded = False

    @classmethod
    def get_instance(cls, storage_path: Path | None = None) -> SkillAnalyticsManager:
        """Get singleton instance."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls(storage_path)
        return cls._instance

    @property
    def storage_path(self) -> Path:
        """Get the storage path, resolving default if not set."""
        if self._storage_path:
            return self._storage_path
        # Default to ~/.pyclaw/skill_usage.json
        state_dir = os.environ.get("PYCLAW_STATE_DIR", "")
        if state_dir:
            return Path(state_dir) / DEFAULT_USAGE_FILE
        return Path.home() / ".pyclaw" / DEFAULT_USAGE_FILE

    def _load(self) -> None:
        """Load usage data from storage."""
        if self._loaded:
            return

        try:
            if self.storage_path.exists():
                content = self.storage_path.read_text(encoding="utf-8")
                raw_data = json.loads(content)
                if isinstance(raw_data, dict):
                    for key, value in raw_data.items():
                        if isinstance(value, dict):
                            self._data[key] = SkillUsageStats.from_dict(value)
        except (json.JSONDecodeError, OSError) as e:
            logger.debug("Failed to load usage data: %s", e)

        self._loaded = True

    def _save(self) -> None:
        """Save usage data to storage."""
        try:
            self.storage_path.parent.mkdir(parents=True, exist_ok=True)
            content = json.dumps(
                {k: v.to_dict() for k, v in self._data.items()},
                ensure_ascii=False,
                indent=2,
            )
            self.storage_path.write_text(content, encoding="utf-8")
        except OSError as e:
            logger.warning("Failed to save usage data: %s", e)

    def record_invocation(
        self,
        skill_key: str,
        *,
        success: bool,
        duration_ms: float = 0.0,
        error: str | None = None,
    ) -> SkillUsageStats:
        """Record a skill invocation.

        Args:
            skill_key: The skill identifier
            success: Whether the invocation succeeded
            duration_ms: Execution duration in milliseconds
            error: Error message if failed

        Returns:
            Updated usage statistics
        """
        with self._lock:
            self._load()

            now = datetime.now(timezone.utc)

            if skill_key not in self._data:
                self._data[skill_key] = SkillUsageStats(skill_key=skill_key)
                self._data[skill_key].first_invoked = now

            stats = self._data[skill_key]
            stats.invoke_count += 1
            stats.last_invoked = now

            if success:
                stats.success_count += 1
                stats.last_status = "success"
            else:
                stats.error_count += 1
                stats.last_status = "error"
                stats.last_error = error

            # Update duration stats
            if duration_ms > 0:
                stats.total_duration_ms += duration_ms
                stats.avg_duration_ms = stats.total_duration_ms / stats.invoke_count

            self._save()
            return stats

    def get_stats(self, skill_key: str) -> SkillUsageStats | None:
        """Get usage statistics for a skill.

        Args:
            skill_key: The skill identifier

        Returns:
            Usage statistics or None if not found
        """
        with self._lock:
            self._load()
            return self._data.get(skill_key)

    def get_all_stats(self) -> dict[str, SkillUsageStats]:
        """Get usage statistics for all skills."""
        with self._lock:
            self._load()
            return dict(self._data)

    def get_report(self, *, top_n: int = 10) -> SkillAnalyticsReport:
        """Generate an analytics report.

        Args:
            top_n: Number of top skills to include

        Returns:
            Aggregated analytics report
        """
        with self._lock:
            self._load()

            stats_list = list(self._data.values())

            # Calculate totals
            total_invocations = sum(s.invoke_count for s in stats_list)
            total_successes = sum(s.success_count for s in stats_list)
            total_errors = sum(s.error_count for s in stats_list)

            # Get top skills by invocation count
            top_skills = sorted(
                stats_list,
                key=lambda s: s.invoke_count,
                reverse=True,
            )[:top_n]

            # Get recent errors
            recent_errors: list[dict[str, Any]] = []
            for stats in stats_list:
                if stats.error_count > 0 and stats.last_error:
                    recent_errors.append(
                        {
                            "skill": stats.skill_key,
                            "error_count": stats.error_count,
                            "last_error": stats.last_error,
                            "last_invoked": stats.last_invoked.isoformat() if stats.last_invoked else None,
                        }
                    )
            recent_errors.sort(
                key=lambda e: e.get("last_invoked") or "",
                reverse=True,
            )
            recent_errors = recent_errors[:top_n]

            return SkillAnalyticsReport(
                total_skills=len(stats_list),
                total_invocations=total_invocations,
                total_successes=total_successes,
                total_errors=total_errors,
                top_skills=top_skills,
                recent_errors=recent_errors,
            )

    def reset_stats(self, skill_key: str | None = None) -> int:
        """Reset usage statistics.

        Args:
            skill_key: If provided, reset only this skill. Otherwise reset all.

        Returns:
            Number of skills reset
        """
        with self._lock:
            self._load()

            if skill_key:
                if skill_key in self._data:
                    del self._data[skill_key]
                    self._save()
                    return 1
                return 0

            count = len(self._data)
            self._data.clear()
            self._save()
            return count


# Module-level convenience functions
_analytics_manager: SkillAnalyticsManager | None = None


def get_analytics_manager(storage_path: Path | None = None) -> SkillAnalyticsManager:
    """Get the global analytics manager instance."""
    global _analytics_manager
    if _analytics_manager is None:
        _analytics_manager = SkillAnalyticsManager(storage_path)
    return _analytics_manager


def record_skill_invocation(
    skill_key: str,
    *,
    success: bool,
    duration_ms: float = 0.0,
    error: str | None = None,
) -> SkillUsageStats:
    """Record a skill invocation (convenience function)."""
    return get_analytics_manager().record_invocation(
        skill_key,
        success=success,
        duration_ms=duration_ms,
        error=error,
    )


def get_skill_stats(skill_key: str) -> SkillUsageStats | None:
    """Get usage statistics for a skill."""
    return get_analytics_manager().get_stats(skill_key)


def get_analytics_report(*, top_n: int = 10) -> SkillAnalyticsReport:
    """Generate an analytics report."""
    return get_analytics_manager().get_report(top_n=top_n)
