"""Skill health check module — diagnose skill runtime status and dependencies."""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from pyclaw.agents.skills.loader import load_workspace_skill_entries
from pyclaw.agents.skills.types import SkillEntry, SkillRuntimeContract

logger = logging.getLogger(__name__)

# Status constants
HEALTHY = "healthy"
DEGRADED = "degraded"
UNHEALTHY = "unhealthy"

# Check names
CHECK_RUNTIME_AVAILABLE = "runtime_available"
CHECK_DEPENDENCIES_MET = "dependencies_met"
CHECK_SCRIPTS_VALID = "scripts_valid"
CHECK_CONFIG_VALID = "config_valid"
CHECK_LAST_RUN_OK = "last_run_ok"


@dataclass
class HealthCheck:
    """Individual health check result."""

    name: str
    passed: bool
    detail: str = ""
    severity: str = "error"  # error, warning, info


@dataclass
class SkillHealthReport:
    """Complete health report for a skill."""

    skill: str
    status: str  # healthy, degraded, unhealthy
    checks: list[HealthCheck] = field(default_factory=list)
    last_run: datetime | None = None
    error_count: int = 0
    success_count: int = 0
    runtime_contract: SkillRuntimeContract | None = None
    recommendations: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "skill": self.skill,
            "status": self.status,
            "checks": [
                {"name": c.name, "passed": c.passed, "detail": c.detail, "severity": c.severity} for c in self.checks
            ],
            "last_run": self.last_run.isoformat() if self.last_run else None,
            "error_count": self.error_count,
            "success_count": self.success_count,
            "runtime_contract": {
                "runtime": self.runtime_contract.runtime,
                "security_level": self.runtime_contract.security_level,
                "is_compatible": self.runtime_contract.is_compatible,
                "missing_deps": list(self.runtime_contract.missing_deps),
            }
            if self.runtime_contract
            else None,
            "recommendations": self.recommendations,
        }


def check_skill_health(
    skill_key: str,
    *,
    workspace_dir: str | Path | None = None,
    config: dict[str, Any] | None = None,
    usage_data: dict[str, Any] | None = None,
) -> SkillHealthReport:
    """Check health status of a skill.

    Performs multiple checks:
    1. Runtime availability (Node.js, Python, MCP server)
    2. Dependency resolution
    3. Script validity (if skill has scripts/runtime.py)
    4. Configuration validity
    5. Recent execution status

    Args:
        skill_key: The skill identifier to check
        workspace_dir: Working directory for skill discovery
        config: Configuration dict for MCP dependency checks
        usage_data: Optional usage statistics for last run info

    Returns:
        SkillHealthReport with status and detailed checks
    """
    workspace = Path(workspace_dir or Path.cwd())
    entries = load_workspace_skill_entries(workspace, config=config)

    entry = _find_skill_entry(entries, skill_key)
    if entry is None:
        return SkillHealthReport(
            skill=skill_key,
            status=UNHEALTHY,
            checks=[
                HealthCheck(
                    name=CHECK_RUNTIME_AVAILABLE,
                    passed=False,
                    detail=f"Skill '{skill_key}' not found",
                    severity="error",
                )
            ],
            recommendations=[f"Install skill '{skill_key}' or check skill_key spelling"],
        )

    report = SkillHealthReport(
        skill=skill_key,
        status=HEALTHY,
        runtime_contract=entry.runtime_contract,
    )

    # Run all checks
    report.checks.append(_check_runtime_available(entry))
    report.checks.append(_check_dependencies_met(entry))
    report.checks.append(_check_scripts_valid(entry))
    report.checks.append(_check_config_valid(entry))
    report.checks.append(_check_last_run_ok(entry, usage_data))

    # Calculate overall status
    has_errors = any(not c.passed and c.severity == "error" for c in report.checks)
    has_warnings = any(not c.passed and c.severity == "warning" for c in report.checks)

    if has_errors:
        report.status = UNHEALTHY
    elif has_warnings:
        report.status = DEGRADED

    # Generate recommendations
    report.recommendations = _generate_recommendations(report)

    # Add usage data if available
    if usage_data:
        report.error_count = usage_data.get("error_count", 0)
        report.success_count = usage_data.get("success_count", 0)
        last_run_ts = usage_data.get("last_invoked")
        if last_run_ts:
            try:
                report.last_run = datetime.fromisoformat(last_run_ts)
            except (ValueError, TypeError):
                pass

    return report


def check_all_skills_health(
    *,
    workspace_dir: str | Path | None = None,
    config: dict[str, Any] | None = None,
) -> list[SkillHealthReport]:
    """Check health of all discovered skills.

    Args:
        workspace_dir: Working directory for skill discovery
        config: Configuration dict for MCP dependency checks

    Returns:
        List of SkillHealthReport for all skills
    """
    workspace = Path(workspace_dir or Path.cwd())
    entries = load_workspace_skill_entries(workspace, config=config)

    # Load usage data for all skills
    usage_data = _load_usage_data(workspace)

    reports: list[SkillHealthReport] = []
    for entry in entries:
        skill_usage = usage_data.get(entry.name, {})
        report = check_skill_health(
            entry.name,
            workspace_dir=workspace,
            config=config,
            usage_data=skill_usage,
        )
        reports.append(report)

    return reports


def _find_skill_entry(entries: list[SkillEntry], skill_key: str) -> SkillEntry | None:
    """Find skill entry by key (case-insensitive)."""
    key_lower = skill_key.strip().lower()
    for entry in entries:
        if entry.name.lower() == key_lower:
            return entry
    return None


def _check_runtime_available(entry: SkillEntry) -> HealthCheck:
    """Check if the required runtime is available."""
    contract = entry.runtime_contract
    runtime = contract.runtime

    if runtime == "python-native":
        # Python is always available if we're running this code
        return HealthCheck(
            name=CHECK_RUNTIME_AVAILABLE,
            passed=True,
            detail="Python runtime available",
            severity="info",
        )

    if runtime == "node-wrapper":
        node_path = shutil.which("node")
        if node_path:
            return HealthCheck(
                name=CHECK_RUNTIME_AVAILABLE,
                passed=True,
                detail=f"Node.js runtime found at {node_path}",
                severity="info",
            )
        return HealthCheck(
            name=CHECK_RUNTIME_AVAILABLE,
            passed=False,
            detail="Node.js runtime not found. Install Node.js to use this skill.",
            severity="error",
        )

    if runtime == "mcp-bridge":
        # MCP availability depends on the configured server
        mcp_deps = [d for d in contract.deps if d.startswith("mcp:")]
        if not mcp_deps:
            return HealthCheck(
                name=CHECK_RUNTIME_AVAILABLE,
                passed=True,
                detail="MCP bridge runtime available (no specific server required)",
                severity="info",
            )
        # Check if MCP servers are configured
        return HealthCheck(
            name=CHECK_RUNTIME_AVAILABLE,
            passed=True,
            detail=f"MCP bridge runtime available (servers: {', '.join(mcp_deps)})",
            severity="info",
        )

    return HealthCheck(
        name=CHECK_RUNTIME_AVAILABLE,
        passed=False,
        detail=f"Unknown runtime type: {runtime}",
        severity="error",
    )


def _check_dependencies_met(entry: SkillEntry) -> HealthCheck:
    """Check if all dependencies are satisfied."""
    contract = entry.runtime_contract
    missing = contract.missing_deps

    if not missing:
        return HealthCheck(
            name=CHECK_DEPENDENCIES_MET,
            passed=True,
            detail="All dependencies satisfied",
            severity="info",
        )

    # Categorize missing deps
    missing_cmds = [d for d in missing if d.startswith("cmd:")]
    missing_envs = [d for d in missing if d.startswith("env:")]
    missing_pys = [d for d in missing if d.startswith("py:")]
    missing_mcps = [d for d in missing if d.startswith("mcp:")]

    details: list[str] = []
    if missing_cmds:
        details.append(f"commands: {', '.join(d[4:] for d in missing_cmds)}")
    if missing_envs:
        details.append(f"env vars: {', '.join(d[4:] for d in missing_envs)}")
    if missing_pys:
        details.append(f"Python modules: {', '.join(d[3:] for d in missing_pys)}")
    if missing_mcps:
        details.append(f"MCP servers: {', '.join(d[4:] for d in missing_mcps)}")

    return HealthCheck(
        name=CHECK_DEPENDENCIES_MET,
        passed=False,
        detail=f"Missing dependencies: {'; '.join(details)}",
        severity="error",
    )


def _check_scripts_valid(entry: SkillEntry) -> HealthCheck:
    """Check if skill has valid runtime scripts."""
    skill_path = Path(entry.path)
    runtime_script = skill_path.parent / "scripts" / "runtime.py"

    if not runtime_script.exists():
        # No script is not an error, just means it uses bundled implementation
        return HealthCheck(
            name=CHECK_SCRIPTS_VALID,
            passed=True,
            detail="No custom runtime script (uses bundled implementation)",
            severity="info",
        )

    # Check if script is valid Python
    try:
        content = runtime_script.read_text(encoding="utf-8")
        compile(content, str(runtime_script), "exec")

        # Check for run() function
        if "def run(" in content or "async def run(" in content:
            return HealthCheck(
                name=CHECK_SCRIPTS_VALID,
                passed=True,
                detail=f"Valid runtime script at {runtime_script.relative_to(skill_path.parent.parent)}",
                severity="info",
            )
        return HealthCheck(
            name=CHECK_SCRIPTS_VALID,
            passed=False,
            detail="Runtime script missing run() function",
            severity="warning",
        )
    except SyntaxError as e:
        return HealthCheck(
            name=CHECK_SCRIPTS_VALID,
            passed=False,
            detail=f"Syntax error in runtime script: {e}",
            severity="error",
        )
    except Exception as e:
        return HealthCheck(
            name=CHECK_SCRIPTS_VALID,
            passed=False,
            detail=f"Error reading runtime script: {e}",
            severity="warning",
        )


def _check_config_valid(entry: SkillEntry) -> HealthCheck:
    """Check if skill configuration is valid."""
    # Check frontmatter parsing
    if not entry.frontmatter:
        return HealthCheck(
            name=CHECK_CONFIG_VALID,
            passed=True,
            detail="No frontmatter (uses defaults)",
            severity="info",
        )

    # Check required fields
    issues: list[str] = []

    if not entry.name:
        issues.append("missing skill_key")

    if entry.runtime_contract.security_level not in {"standard", "elevated", "restricted"}:
        issues.append(f"invalid security_level: {entry.runtime_contract.security_level}")

    if issues:
        return HealthCheck(
            name=CHECK_CONFIG_VALID,
            passed=False,
            detail=f"Config issues: {', '.join(issues)}",
            severity="warning",
        )

    return HealthCheck(
        name=CHECK_CONFIG_VALID,
        passed=True,
        detail="Configuration valid",
        severity="info",
    )


def _check_last_run_ok(entry: SkillEntry, usage_data: dict[str, Any] | None) -> HealthCheck:
    """Check if the last execution was successful."""
    if not usage_data:
        return HealthCheck(
            name=CHECK_LAST_RUN_OK,
            passed=True,
            detail="No execution history",
            severity="info",
        )

    error_count = usage_data.get("error_count", 0)
    success_count = usage_data.get("success_count", 0)
    last_status = usage_data.get("last_status")

    if error_count > 0 and success_count == 0:
        return HealthCheck(
            name=CHECK_LAST_RUN_OK,
            passed=False,
            detail=f"All {error_count} execution(s) failed",
            severity="error",
        )

    if last_status == "error":
        return HealthCheck(
            name=CHECK_LAST_RUN_OK,
            passed=False,
            detail="Last execution failed",
            severity="warning",
        )

    return HealthCheck(
        name=CHECK_LAST_RUN_OK,
        passed=True,
        detail=f"Executions: {success_count} success, {error_count} errors",
        severity="info",
    )


def _generate_recommendations(report: SkillHealthReport) -> list[str]:
    """Generate actionable recommendations based on health checks."""
    recommendations: list[str] = []

    for check in report.checks:
        if check.passed:
            continue

        if check.name == CHECK_RUNTIME_AVAILABLE:
            if "node" in check.detail.lower():
                recommendations.append("Install Node.js: https://nodejs.org/")
            elif "not found" in check.detail.lower():
                recommendations.append(f"Install skill '{report.skill}' or check spelling")

        elif check.name == CHECK_DEPENDENCIES_MET:
            if "cmd:" in check.detail:
                recommendations.append("Install required command-line tools")
            if "env:" in check.detail:
                recommendations.append("Set required environment variables")
            if "py:" in check.detail:
                recommendations.append("pip install required Python packages")
            if "mcp:" in check.detail:
                recommendations.append("Configure MCP servers in pyclaw.yaml")

        elif check.name == CHECK_SCRIPTS_VALID:
            if "Syntax error" in check.detail:
                recommendations.append("Fix syntax errors in scripts/runtime.py")
            elif "missing run()" in check.detail:
                recommendations.append("Add run() function to scripts/runtime.py")

        elif check.name == CHECK_LAST_RUN_OK:
            if "failed" in check.detail.lower():
                recommendations.append("Check skill execution logs for errors")

    return recommendations


def _load_usage_data(workspace: Path) -> dict[str, dict[str, Any]]:
    """Load usage statistics for all skills."""
    usage_file = workspace / ".pyclaw" / "skill_usage.json"
    if not usage_file.exists():
        return {}

    try:
        content = usage_file.read_text(encoding="utf-8")
        data = json.loads(content)
        if isinstance(data, dict):
            return data
    except (json.JSONDecodeError, OSError) as e:
        logger.debug("Failed to load usage data: %s", e)

    return {}
