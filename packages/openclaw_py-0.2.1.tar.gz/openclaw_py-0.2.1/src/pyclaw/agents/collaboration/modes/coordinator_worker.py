"""Coordinator-Worker collaboration mode implementation.

This module implements the CoordinatorWorkerMode which handles spawning
a coordinator agent that manages worker agents for task delegation.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 2.1
"""

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING, Any

from pyclaw.agents.collaboration.modes.base import CollaborationMode
from pyclaw.agents.collaboration.types import (
    CollaborationModeType,
    CustomAgentConfig,
    SpawnResult,
    TrustLevel,
)
from pyclaw.agents.subagents.types import SubagentConfig
from pyclaw.agents.types import AgentTool

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.engine import CollaborationEngine

logger = logging.getLogger(__name__)


# Coordinator-specific tool names
COORDINATOR_TOOLS = frozenset(
    [
        "spawn_worker",
        "assign_task",
        "collect_results",
        "list_workers",
        "kill_worker",
    ]
)

# Worker tool names (execution tools, not coordination)
WORKER_TOOLS = frozenset(
    [
        "read",
        "write",
        "edit",
        "search",
        "exec",
        "shell",
        "web_search",
        "web_fetch",
        "memory_add",
        "memory_search",
    ]
)


class CoordinatorWorkerMode(CollaborationMode):
    """Collaboration mode for coordinator-worker task delegation.

    This mode spawns a Coordinator agent that manages Worker agents.
    The Coordinator has special tools for task distribution and result
    collection, while Workers execute the actual tasks.

    .. deprecated:: 1.0.0
        Use :class:`pyclaw.agents.multiagent.engines.CentralizedEngine` instead.
        This class will be removed in version 2.0.0.

    Key features:
    - Coordinator agent with elevated trust_level for spawning workers
    - Coordinator-specific tools: spawn_worker, assign_task, collect_results
    - Worker agents inherit or have reduced trust_level
    - Tool filtering: Coordinator gets coordination tools, Workers get execution tools

    Example:
        >>> engine = CollaborationEngine(subagent_manager=manager)
        >>> mode = CoordinatorWorkerMode(engine)
        >>> engine.register_mode(CollaborationModeType.COORDINATOR_WORKER, mode)
        >>> config = SubagentConfig(prompt="Coordinate this task", ...)
        >>> result = await mode.spawn(config)
    """

    # Default trust level for coordinators
    DEFAULT_COORDINATOR_TRUST: TrustLevel = TrustLevel.STANDARD
    # Default trust level for workers (typically lower than coordinator)
    DEFAULT_WORKER_TRUST: TrustLevel = TrustLevel.RESTRICTED

    def __init__(self, engine: CollaborationEngine) -> None:
        """Initialize the Coordinator-Worker mode.

        Args:
            engine: The collaboration engine that owns this mode
        """
        super().__init__(engine)
        # Track spawned workers by coordinator session ID
        self._workers_by_coordinator: dict[str, list[str]] = {}
        warnings.warn(
            "CoordinatorWorkerMode is deprecated since version 1.0.0. "
            "Use pyclaw.agents.multiagent.engines.CentralizedEngine instead. "
            "This class will be removed in version 2.0.0.",
            DeprecationWarning,
            stacklevel=2,
        )

    @property
    def mode_type(self) -> CollaborationModeType:
        """Return the mode type.

        Returns:
            CollaborationModeType.COORDINATOR_WORKER
        """
        return CollaborationModeType.COORDINATOR_WORKER

    async def spawn(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> SpawnResult:
        """Spawn a coordinator agent.

        This method creates a Coordinator agent that can spawn and manage
        Worker agents. The Coordinator gets special tools for coordination.

        Args:
            config: Agent configuration for the coordinator

        Returns:
            SpawnResult with the coordinator's session ID
        """
        # Check depth limit
        if self._engine.depth >= self._engine.MAX_DEPTH:
            logger.warning(
                "Max depth exceeded: current=%d, max=%d",
                self._engine.depth,
                self._engine.MAX_DEPTH,
            )
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        # Convert CustomAgentConfig to SubagentConfig if needed
        subagent_config = (
            self._convert_to_subagent_config(config) if isinstance(config, CustomAgentConfig) else config.model_copy()
        )

        # Mark this as a coordinator agent in metadata
        if not subagent_config.metadata:
            subagent_config.metadata = {}
        subagent_config.metadata["is_coordinator"] = True
        subagent_config.metadata["role"] = "coordinator"

        # Prepare context for the coordinator
        parent_session_id = self._engine.session_id
        child_context = self.prepare_context(parent_session_id, subagent_config)

        # Update subagent config with context
        subagent_config.session_id = child_context.session_id
        subagent_config.parent_session_id = parent_session_id
        subagent_config.current_depth = self._engine.depth + 1
        subagent_config.workspace_dir = child_context.scratchpad_dir or ""

        # Set the prompt from the task_prompt if not already set
        if not subagent_config.prompt and child_context.task_prompt:
            subagent_config.prompt = child_context.task_prompt

        # Store the context in the result
        context_dict = child_context.model_dump()

        try:
            # Spawn the coordinator via SubagentManager
            result = await self._engine._subagent_manager.spawn(subagent_config)

            if result.state.value == "completed":
                # Initialize worker tracking for this coordinator
                self._workers_by_coordinator[child_context.session_id] = []

                return SpawnResult(
                    session_id=child_context.session_id,
                    status="success",
                    children=[child_context.session_id],
                    child_context=context_dict,
                )
            else:
                return SpawnResult(
                    session_id=child_context.session_id,
                    status="failed",
                    children=[],
                    child_context=context_dict,
                )

        except Exception as e:
            logger.error(
                "Failed to spawn coordinator agent %s: %s",
                config.agent_id if hasattr(config, "agent_id") else "unknown",
                e,
                exc_info=True,
            )
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

    def get_tools_for_child(
        self,
        config: CustomAgentConfig | SubagentConfig,
        trust_level: TrustLevel,
    ) -> list[AgentTool]:
        """Get filtered tools for a child agent.

        For Coordinator-Worker mode:
        - Coordinator gets coordination tools (spawn_worker, assign_task, etc.)
        - Workers get execution tools (read, write, etc.)

        Args:
            config: Agent configuration
            trust_level: Trust level for tool filtering

        Returns:
            Filtered list of AgentTool objects
        """
        permission_manager = self._engine._permission_manager

        if permission_manager is None:
            logger.warning("No permission manager available, returning empty tools")
            return []

        # Determine if this is a coordinator or worker based on metadata
        is_coordinator = False
        if isinstance(config, SubagentConfig):
            is_coordinator = config.metadata.get("is_coordinator", False)
        else:
            is_coordinator = config.model_dump().get("is_coordinator", False)

        # TODO(#collaboration): Once ToolRegistry is implemented, fetch actual tools
        # For now, return empty list - actual tools will be determined by
        # SubagentManager during spawn based on tools_enabled/tools_disabled
        _ = is_coordinator  # Will be used when ToolRegistry is available
        _ = trust_level
        return []

    def get_coordinator_tools(self) -> list[str]:
        """Get the list of tools available to coordinator agents.

        Returns:
            List of coordinator tool names
        """
        return list(COORDINATOR_TOOLS)

    def get_worker_tools(self) -> list[str]:
        """Get the list of tools available to worker agents.

        Returns:
            List of worker tool names
        """
        return list(WORKER_TOOLS)

    def get_coordinator_trust_level(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> TrustLevel:
        """Get the trust level for a coordinator agent.

        Coordinators typically have elevated trust to spawn workers.

        Args:
            config: Agent configuration

        Returns:
            TrustLevel for the coordinator
        """
        if isinstance(config, CustomAgentConfig):
            # Use configured trust level or default
            return config.trust_level or self.DEFAULT_COORDINATOR_TRUST
        else:
            # SubagentConfig: extract from metadata or use default
            trust_value = config.metadata.get("trust_level")
            if trust_value is not None:
                return TrustLevel(trust_value)
            return self.DEFAULT_COORDINATOR_TRUST

    def get_worker_trust_level(
        self,
        coordinator_trust: TrustLevel,
    ) -> TrustLevel:
        """Get the trust level for worker agents.

        Workers typically have trust level equal to or lower than the coordinator.

        Args:
            coordinator_trust: The coordinator's trust level

        Returns:
            TrustLevel for workers (lower or equal to coordinator)
        """
        # Workers get at most RESTRICTED trust, or lower if coordinator has less
        return TrustLevel(min(coordinator_trust.value, self.DEFAULT_WORKER_TRUST.value))

    def register_worker(
        self,
        coordinator_session_id: str,
        worker_session_id: str,
    ) -> None:
        """Register a worker agent under a coordinator.

        Args:
            coordinator_session_id: The coordinator's session ID
            worker_session_id: The worker's session ID
        """
        if coordinator_session_id not in self._workers_by_coordinator:
            self._workers_by_coordinator[coordinator_session_id] = []
        self._workers_by_coordinator[coordinator_session_id].append(worker_session_id)
        logger.debug(
            "Registered worker %s under coordinator %s",
            worker_session_id,
            coordinator_session_id,
        )

    def unregister_worker(
        self,
        coordinator_session_id: str,
        worker_session_id: str,
    ) -> bool:
        """Unregister a worker agent from a coordinator.

        Args:
            coordinator_session_id: The coordinator's session ID
            worker_session_id: The worker's session ID

        Returns:
            True if the worker was found and removed, False otherwise
        """
        if coordinator_session_id in self._workers_by_coordinator:
            workers = self._workers_by_coordinator[coordinator_session_id]
            if worker_session_id in workers:
                workers.remove(worker_session_id)
                logger.debug(
                    "Unregistered worker %s from coordinator %s",
                    worker_session_id,
                    coordinator_session_id,
                )
                return True
        return False

    def get_workers(self, coordinator_session_id: str) -> list[str]:
        """Get the list of workers for a coordinator.

        Args:
            coordinator_session_id: The coordinator's session ID

        Returns:
            List of worker session IDs
        """
        return self._workers_by_coordinator.get(coordinator_session_id, [])

    def _convert_to_subagent_config(
        self,
        custom_config: CustomAgentConfig,
    ) -> SubagentConfig:
        """Convert CustomAgentConfig to SubagentConfig.

        Args:
            custom_config: The custom agent configuration

        Returns:
            SubagentConfig for spawning the coordinator
        """
        return SubagentConfig(
            session_id="",  # Will be set during spawn
            parent_session_id="",  # Will be set during spawn
            agent_id=custom_config.agent_id,
            prompt="",  # Will be set from task_prompt during spawn
            model=custom_config.model or "",
            provider="",  # Use default provider
            tools_enabled=custom_config.tools_enabled or [],
            tools_disabled=custom_config.tools_disabled or [],
            system_prompt=custom_config.system_prompt,
            current_depth=0,  # Will be set during spawn
            max_depth=self._engine.MAX_DEPTH,
            metadata={
                "name": custom_config.name,
                "description": custom_config.description,
                "tags": custom_config.tags,
                "source": custom_config.source,
                "source_path": custom_config.source_path,
                "memory_scope": custom_config.memory_scope.value,
                "trust_level": custom_config.trust_level.value,
                "is_coordinator": True,
                "role": "coordinator",
            },
        )

    def on_child_complete(self, result: Any) -> None:
        """Handle coordinator or worker completion.

        This callback cleans up worker tracking when a coordinator completes.

        Args:
            result: The result from the child agent execution
        """
        logger.info("Coordinator-Worker child completed: %s", result)

        # Could clean up workers if coordinator completes
        # For now, just log the completion
