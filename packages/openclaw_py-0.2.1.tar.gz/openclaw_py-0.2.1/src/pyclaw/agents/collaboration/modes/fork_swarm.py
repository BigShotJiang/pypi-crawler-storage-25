"""Fork/Swarm collaboration mode implementation.

This module implements the ForkSwarmMode which handles spawning multiple
parallel child agents to execute the same task concurrently.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 2.1
"""

from __future__ import annotations

import asyncio
import logging
import uuid
import warnings
from typing import TYPE_CHECKING, Any

from pyclaw.agents.collaboration.modes.base import CollaborationMode
from pyclaw.agents.collaboration.types import (
    ChildContext,
    CollaborationModeType,
    CustomAgentConfig,
    SpawnResult,
    TrustLevel,
)
from pyclaw.agents.subagents.types import SubagentConfig, SubagentResult, SubagentState
from pyclaw.agents.types import AgentTool

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.engine import CollaborationEngine

logger = logging.getLogger(__name__)


class ForkSwarmMode(CollaborationMode):
    """Collaboration mode for parallel task execution.

    This mode spawns multiple child agents (forks) to execute the same
    task in parallel. All forks receive identical prompts and context,
    but operate independently with separate session IDs.

    .. deprecated:: 1.0.0
        Use :class:`pyclaw.agents.multiagent.engines.ForkSwarmEngine` instead.
        This class will be removed in version 2.0.0.

    Key features:
    - Creates multiple parallel child agents with fork_count parameter
    - All forks share the same prompt and system_prompt
    - Each fork has independent session_id and workspace
    - Results aggregated through SpawnResult.children
    - Enforces max_fork_count limit (engine's MAX_CHILDREN)

    Example:
        >>> engine = CollaborationEngine(subagent_manager=manager)
        >>> mode = ForkSwarmMode(engine)
        >>> engine.register_mode(CollaborationModeType.FORK_SWARM, mode)
        >>> config = SubagentConfig(prompt="Analyze this data", fork_count=3)
        >>> result = await mode.spawn(config)
        >>> len(result.children)  # 3 parallel agents
        3
    """

    # Default fork count if not specified
    DEFAULT_FORK_COUNT: int = 1

    def __init__(self, engine: CollaborationEngine) -> None:
        """Initialize the Fork/Swarm mode.

        Args:
            engine: The collaboration engine that owns this mode
        """
        super().__init__(engine)
        warnings.warn(
            "ForkSwarmMode is deprecated since version 1.0.0. "
            "Use pyclaw.agents.multiagent.engines.ForkSwarmEngine instead. "
            "This class will be removed in version 2.0.0.",
            DeprecationWarning,
            stacklevel=2,
        )

    @property
    def mode_type(self) -> CollaborationModeType:
        """Return the mode type.

        Returns:
            CollaborationModeType.FORK_SWARM
        """
        return CollaborationModeType.FORK_SWARM

    @property
    def max_fork_count(self) -> int:
        """Get the maximum allowed fork count.

        Inherits from engine's MAX_CHILDREN constant.

        Returns:
            Maximum number of parallel forks allowed
        """
        return self._engine.MAX_CHILDREN

    def _get_fork_count(self, config: CustomAgentConfig | SubagentConfig) -> int:
        """Extract fork_count from configuration.

        Args:
            config: Agent configuration

        Returns:
            Validated fork count within bounds [1, max_fork_count]
        """
        # Try to get fork_count from metadata (SubagentConfig) or direct attribute
        fork_count = None

        if isinstance(config, SubagentConfig):
            fork_count = config.metadata.get("fork_count")
        else:
            # CustomAgentConfig could have fork_count in metadata too
            fork_count = config.model_dump().get("fork_count")

        # Default to DEFAULT_FORK_COUNT if not specified
        if fork_count is None:
            fork_count = self.DEFAULT_FORK_COUNT

        # Ensure fork_count is within valid bounds
        return max(1, min(int(fork_count), self.max_fork_count))

    async def spawn(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> SpawnResult:
        """Spawn multiple parallel child agents.

        This method:
        1. Extracts fork_count from config (default: 1, max: engine.MAX_CHILDREN)
        2. Creates fork_count independent child contexts
        3. Spawns all children in parallel using asyncio.gather
        4. Returns aggregated results with all child session IDs

        Args:
            config: Agent configuration with optional fork_count parameter

        Returns:
            SpawnResult with:
                - session_id: Empty string (no single primary child)
                - status: "success" if all forks succeeded, "partial" if some failed
                - children: List of all fork session IDs
                - child_context: None (use children list instead)
        """
        # Check depth limit first
        if self._engine.depth >= self._engine.MAX_DEPTH:
            logger.warning(
                "Max depth exceeded: current=%d, max=%d",
                self._engine.depth,
                self._engine.MAX_DEPTH,
            )
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        # Get fork count
        fork_count = self._get_fork_count(config)

        # Check against max children
        if fork_count > self.max_fork_count:
            logger.warning(
                "fork_count %d exceeds max_fork_count %d, capping",
                fork_count,
                self.max_fork_count,
            )
            fork_count = self.max_fork_count

        logger.info("Spawning %d parallel forks", fork_count)

        # Convert CustomAgentConfig to SubagentConfig if needed
        subagent_config = (
            self._convert_to_subagent_config(config) if isinstance(config, CustomAgentConfig) else config.model_copy()
        )

        # Prepare contexts for all forks
        parent_session_id = self._engine.session_id
        fork_contexts: list[ChildContext] = []

        for _ in range(fork_count):
            child_context = self.prepare_context(parent_session_id, subagent_config)
            fork_contexts.append(child_context)

        # Spawn all children in parallel
        spawn_tasks = [
            self._spawn_single_fork(subagent_config, context, parent_session_id) for context in fork_contexts
        ]

        try:
            results = await asyncio.gather(*spawn_tasks, return_exceptions=True)
        except Exception as e:
            logger.error("Failed to spawn forks: %s", e, exc_info=True)
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        # Collect results
        child_session_ids: list[str] = []
        success_count = 0
        failure_count = 0

        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error("Fork %d failed with exception: %s", i, result)
                failure_count += 1
            elif isinstance(result, SpawnResult):
                if result.status == "success":
                    child_session_ids.extend(result.children)
                    success_count += 1
                else:
                    failure_count += 1
            else:
                logger.warning("Unexpected result type for fork %d: %s", i, type(result))
                failure_count += 1

        # Determine overall status
        if success_count == fork_count:
            overall_status = "success"
        elif success_count > 0:
            overall_status = "partial"
        else:
            overall_status = "failed"

        logger.info(
            "Fork spawn complete: %d success, %d failure, status=%s",
            success_count,
            failure_count,
            overall_status,
        )

        return SpawnResult(
            session_id="",  # No single primary session for fork mode
            status=overall_status,
            children=child_session_ids,
            child_context=None,
        )

    async def _spawn_single_fork(
        self,
        base_config: SubagentConfig,
        child_context: ChildContext,
        parent_session_id: str,
    ) -> SpawnResult:
        """Spawn a single fork with the given context.

        Args:
            base_config: Base configuration for the fork
            child_context: Context for this specific fork
            parent_session_id: Parent session ID

        Returns:
            SpawnResult for this individual fork
        """
        # Create a copy of config with context-specific values
        fork_config = base_config.model_copy()
        fork_config.session_id = child_context.session_id
        fork_config.parent_session_id = parent_session_id
        fork_config.current_depth = self._engine.depth + 1
        fork_config.workspace_dir = child_context.scratchpad_dir or ""

        # Set prompt from context if not already set
        if not fork_config.prompt and child_context.task_prompt:
            fork_config.prompt = child_context.task_prompt

        try:
            # Spawn via SubagentManager
            result: SubagentResult = await self._engine._subagent_manager.spawn(fork_config)

            if result.state == SubagentState.COMPLETED:
                return SpawnResult(
                    session_id=child_context.session_id,
                    status="success",
                    children=[child_context.session_id],
                    child_context=child_context.model_dump(),
                )
            else:
                logger.warning(
                    "Fork spawn returned non-completed state: %s",
                    result.state,
                )
                return SpawnResult(
                    session_id=child_context.session_id,
                    status="failed",
                    children=[],
                    child_context=child_context.model_dump(),
                )

        except Exception as e:
            logger.error(
                "Failed to spawn fork %s: %s",
                child_context.session_id,
                e,
                exc_info=True,
            )
            return SpawnResult(
                session_id=child_context.session_id,
                status="failed",
                children=[],
                child_context=None,
            )

    def _convert_to_subagent_config(
        self,
        custom_config: CustomAgentConfig,
    ) -> SubagentConfig:
        """Convert CustomAgentConfig to SubagentConfig.

        Args:
            custom_config: The custom agent configuration

        Returns:
            SubagentConfig for spawning the fork
        """
        return SubagentConfig(
            session_id="",  # Will be set during spawn
            parent_session_id="",  # Will be set during spawn
            agent_id=custom_config.agent_id,
            prompt="",  # Will be set from task_prompt during spawn
            model=custom_config.model or "",
            provider="",  # Use default provider
            tools_enabled=custom_config.tools_enabled or [],
            tools_disabled=custom_config.tools_disabled or [],
            system_prompt=custom_config.system_prompt,
            current_depth=0,  # Will be set during spawn
            max_depth=self._engine.MAX_DEPTH,
            metadata={
                "name": custom_config.name,
                "description": custom_config.description,
                "tags": custom_config.tags,
                "source": custom_config.source,
                "source_path": custom_config.source_path,
                "memory_scope": custom_config.memory_scope.value,
                "trust_level": custom_config.trust_level.value,
                "fork_count": custom_config.model_dump().get("fork_count", self.DEFAULT_FORK_COUNT),
            },
        )

    def get_tools_for_child(
        self,
        config: CustomAgentConfig | SubagentConfig,
        trust_level: TrustLevel,
    ) -> list[AgentTool]:
        """Get filtered tools for a child agent.

        In Fork/Swarm mode, each fork gets the same tool set based on
        trust level and configuration. Tool filtering is delegated to
        the permission manager.

        Args:
            config: Agent configuration
            trust_level: Trust level for tool filtering

        Returns:
            Filtered list of AgentTool objects
        """
        permission_manager = self._engine._permission_manager

        if permission_manager is None:
            logger.warning("No permission manager available, returning empty tools")
            return []

        # TODO(#collaboration): Implement tool filtering once ToolRegistry is available
        # For now, return empty list - actual tools will be determined by
        # SubagentManager during spawn based on tools_enabled/tools_disabled
        _ = config  # Acknowledge for future use
        return []

    def prepare_context(
        self,
        parent_session_id: str,
        child_config: CustomAgentConfig | SubagentConfig,
    ) -> ChildContext:
        """Prepare the context for a child agent fork.

        In Fork/Swarm mode, each fork receives the same context (identical
        prompt, system_prompt, memory scope). Each fork has a unique session_id.

        Args:
            parent_session_id: Parent session ID
            child_config: Child agent configuration

        Returns:
            ChildContext with all needed context
        """
        context_manager = self._engine._context_manager

        # Generate unique session ID for this fork
        child_session_id = str(uuid.uuid4())[:12]

        if context_manager is None:
            # Return minimal context if no context manager
            task_prompt = self._extract_task_prompt(child_config)
            return ChildContext(
                session_id=child_session_id,
                parent_session_id=parent_session_id,
                task_prompt=task_prompt,
                memory_scope=self._extract_memory_scope(child_config),
            )

        # Extract configuration from child_config
        task_prompt = self._extract_task_prompt(child_config)
        memory_scope = self._extract_memory_scope(child_config)
        trust_level = self._extract_trust_level(child_config)

        return context_manager.prepare_child_context(
            parent_session_id=parent_session_id,
            task_prompt=task_prompt,
            memory_scope=memory_scope,
            trust_level=trust_level,
        )

    def on_child_complete(self, result: Any) -> None:
        """Handle completion of a fork child agent.

        This callback logs the completion and can be extended to
        aggregate results from multiple forks.

        Args:
            result: The result from the fork child agent execution
        """
        logger.info("Fork child completed: %s", result)
