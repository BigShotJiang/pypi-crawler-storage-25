"""Custom Agent collaboration mode implementation.

This module implements the CustomAgentMode which handles spawning
predefined custom agents loaded from YAML, Markdown, or UI configurations.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 4.1
"""

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING, Any

from pyclaw.agents.collaboration.modes.base import CollaborationMode
from pyclaw.agents.collaboration.types import (
    CollaborationModeType,
    CustomAgentConfig,
    MemoryScope,
    SpawnResult,
    TrustLevel,
)
from pyclaw.agents.subagents.types import SubagentConfig
from pyclaw.agents.types import AgentTool

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.engine import CollaborationEngine
    from pyclaw.agents.collaboration.storage.agent_registry import CustomAgentRegistry

logger = logging.getLogger(__name__)


class CustomAgentMode(CollaborationMode):
    """Collaboration mode for predefined custom agents.

    This mode handles spawning child agents based on predefined
    configurations (CustomAgentConfig) loaded from YAML, Markdown,
    or UI configurations.

    .. deprecated:: 1.0.0
        Use :class:`pyclaw.agents.multiagent.engines.CentralizedEngine` instead.
        This class will be removed in version 2.0.0.

    Key features:
    - Looks up agent configuration from CustomAgentRegistry
    - Transforms CustomAgentConfig to SubagentConfig
    - Applies tool filtering based on trust level and configuration
    - Prepares context using ContextSharingManager

    Example:
        >>> engine = CollaborationEngine(subagent_manager=manager)
        >>> mode = CustomAgentMode(engine)
        >>> engine.register_mode(CollaborationModeType.CUSTOM_AGENT, mode)
        >>> result = await mode.spawn(custom_config)
    """

    def __init__(
        self,
        engine: CollaborationEngine,
        registry: CustomAgentRegistry | None = None,
    ) -> None:
        """Initialize the Custom Agent mode.

        Args:
            engine: The collaboration engine that owns this mode
            registry: Optional custom agent registry (will be created if not provided)
        """
        super().__init__(engine)
        self._registry = registry
        warnings.warn(
            "CustomAgentMode is deprecated since version 1.0.0. "
            "Use pyclaw.agents.multiagent.engines.CentralizedEngine instead. "
            "This class will be removed in version 2.0.0.",
            DeprecationWarning,
            stacklevel=2,
        )

    @property
    def mode_type(self) -> CollaborationModeType:
        """Return the mode type.

        Returns:
            CollaborationModeType.CUSTOM_AGENT
        """
        return CollaborationModeType.CUSTOM_AGENT

    @property
    def registry(self) -> CustomAgentRegistry:
        """Get the custom agent registry, creating one if needed.

        Returns:
            CustomAgentRegistry instance
        """
        if self._registry is None:
            from pyclaw.agents.collaboration.storage.agent_registry import CustomAgentRegistry

            self._registry = CustomAgentRegistry()
        return self._registry

    async def spawn(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> SpawnResult:
        """Spawn a custom agent child session.

        This method:
        1. Transforms CustomAgentConfig to SubagentConfig if needed
        2. Prepares the child context
        3. Gets filtered tools for the child
        4. Calls SubagentManager.spawn() to create the child

        Args:
            config: Agent configuration (CustomAgentConfig or SubagentConfig)

        Returns:
            SpawnResult with session ID and status
        """
        # Convert CustomAgentConfig to SubagentConfig if needed
        subagent_config = self._convert_to_subagent_config(config) if isinstance(config, CustomAgentConfig) else config

        # Check depth limit
        if self._engine.depth >= self._engine.MAX_DEPTH:
            logger.warning(
                "Max depth exceeded: current=%d, max=%d",
                self._engine.depth,
                self._engine.MAX_DEPTH,
            )
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        # Prepare context for the child
        parent_session_id = self._engine.session_id
        child_context = self.prepare_context(parent_session_id, subagent_config)

        # Update subagent config with context
        subagent_config.session_id = child_context.session_id
        subagent_config.parent_session_id = parent_session_id
        subagent_config.current_depth = self._engine.depth + 1
        subagent_config.workspace_dir = child_context.scratchpad_dir or ""

        # Set the prompt from the task_prompt if not already set
        if not subagent_config.prompt and child_context.task_prompt:
            subagent_config.prompt = child_context.task_prompt

        # Store the context in the result
        context_dict = child_context.model_dump()

        try:
            # Spawn via SubagentManager
            result = await self._engine._subagent_manager.spawn(subagent_config)

            if result.state.value == "completed":
                return SpawnResult(
                    session_id=child_context.session_id,
                    status="success",
                    children=[child_context.session_id],
                    child_context=context_dict,
                )
            else:
                return SpawnResult(
                    session_id=child_context.session_id,
                    status="failed",
                    children=[],
                    child_context=context_dict,
                )

        except Exception as e:
            logger.error(
                "Failed to spawn custom agent %s: %s",
                config.agent_id if hasattr(config, "agent_id") else "unknown",
                e,
                exc_info=True,
            )
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

    def _convert_to_subagent_config(
        self,
        custom_config: CustomAgentConfig,
    ) -> SubagentConfig:
        """Convert CustomAgentConfig to SubagentConfig.

        This method transforms the user-facing CustomAgentConfig
        into the internal SubagentConfig used by SubagentManager.

        Args:
            custom_config: The custom agent configuration

        Returns:
            SubagentConfig for spawning the child agent
        """
        return SubagentConfig(
            session_id="",  # Will be set during spawn
            parent_session_id="",  # Will be set during spawn
            agent_id=custom_config.agent_id,
            prompt="",  # Will be set from task_prompt during spawn
            model=custom_config.model or "",
            provider="",  # Use default provider
            tools_enabled=custom_config.tools_enabled or [],
            tools_disabled=custom_config.tools_disabled or [],
            system_prompt=custom_config.system_prompt,
            current_depth=0,  # Will be set during spawn
            max_depth=self._engine.MAX_DEPTH,
            metadata={
                "name": custom_config.name,
                "description": custom_config.description,
                "tags": custom_config.tags,
                "source": custom_config.source,
                "source_path": custom_config.source_path,
                "memory_scope": custom_config.memory_scope.value,
                "trust_level": custom_config.trust_level.value,
            },
        )

    def get_tools_for_child(
        self,
        config: CustomAgentConfig | SubagentConfig,
        trust_level: TrustLevel,
    ) -> list[AgentTool]:
        """Get filtered tools for a child agent.

        This method uses the ToolPermissionManager to filter tools
        based on trust level and the agent configuration.

        Args:
            config: Agent configuration
            trust_level: Trust level for tool filtering

        Returns:
            Filtered list of AgentTool objects
        """
        permission_manager = self._engine._permission_manager

        if permission_manager is None:
            # Return empty list if no permission manager
            logger.warning("No permission manager available, returning empty tools")
            return []

        # Convert SubagentConfig to CustomAgentConfig for filtering
        custom_config = (
            self._convert_to_custom_config(config, trust_level) if isinstance(config, SubagentConfig) else config
        )

        # Get all available tools (would normally come from a tool registry)
        # The permission manager would filter these based on the custom_config
        #
        # TODO(#collaboration): Tool filtering is currently delegated to SubagentManager._filter_tools
        # because the engine doesn't expose a tool registry. Once ToolRegistry is implemented,
        # this method should fetch tools from the registry and filter them here.
        #
        # For now, return empty list - the actual tool set will be determined by
        # SubagentManager during spawn based on tools_enabled/tools_disabled in config.
        _ = custom_config  # Acknowledge variable for future use
        return []

    def _convert_to_custom_config(
        self,
        subagent_config: SubagentConfig,
        trust_level: TrustLevel,
    ) -> CustomAgentConfig:
        """Convert SubagentConfig to CustomAgentConfig for tool filtering.

        Args:
            subagent_config: Subagent configuration
            trust_level: Trust level for the configuration

        Returns:
            CustomAgentConfig for tool filtering
        """
        metadata = subagent_config.metadata

        return CustomAgentConfig(
            agent_id=subagent_config.agent_id,
            name=metadata.get("name", subagent_config.agent_id),
            description=metadata.get("description", ""),
            system_prompt=subagent_config.system_prompt,
            model=subagent_config.model or None,
            tools_enabled=subagent_config.tools_enabled or None,
            tools_disabled=subagent_config.tools_disabled or None,
            trust_level=trust_level,
            memory_scope=MemoryScope(metadata.get("memory_scope", "task")),
            tags=metadata.get("tags", []),
            source=metadata.get("source", "subagent"),
            source_path=metadata.get("source_path"),
        )

    def get_agent_config(self, agent_id: str) -> CustomAgentConfig | None:
        """Look up an agent configuration by ID.

        Args:
            agent_id: The unique identifier of the agent

        Returns:
            CustomAgentConfig if found, None otherwise
        """
        return self.registry.get(agent_id)

    def list_available_agents(self) -> list[CustomAgentConfig]:
        """List all available custom agent configurations.

        Returns:
            List of CustomAgentConfig objects
        """
        return self.registry.list_all()

    def on_child_complete(self, result: Any) -> None:
        """Handle child agent completion.

        This callback logs the completion and can be extended to
        handle results, update state, or trigger follow-up actions.

        Args:
            result: The result from the child agent execution
        """
        logger.info("Custom agent child completed: %s", result)
