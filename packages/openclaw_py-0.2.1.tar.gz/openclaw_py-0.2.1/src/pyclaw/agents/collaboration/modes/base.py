"""Abstract base class for collaboration modes.

This module defines the CollaborationMode ABC that all collaboration modes
must implement. Each mode defines a different pattern of agent cooperation.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 4.2
"""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from pyclaw.agents.collaboration.types import (
    ChildContext,
    CollaborationModeType,
    CustomAgentConfig,
    MemoryScope,
    SpawnResult,
    TrustLevel,
)
from pyclaw.agents.subagents.types import SubagentConfig
from pyclaw.agents.types import AgentTool

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.engine import CollaborationEngine


class CollaborationMode(ABC):
    """Abstract base class for collaboration modes.

    Each collaboration mode defines how a parent agent spawns and manages
    child agents. Modes handle:
    - Configuration transformation
    - Tool filtering
    - Context preparation
    - Child lifecycle callbacks

    Subclasses must implement:
        - mode_type: Return the mode type enum value
        - spawn(): Create and spawn child agents
        - get_tools_for_child(): Return filtered tool set for child

    Example:
        >>> class MyMode(CollaborationMode):
        ...     @property
        ...     def mode_type(self) -> CollaborationModeType:
        ...         return CollaborationModeType.CUSTOM_AGENT
        ...
        ...     async def spawn(self, config) -> SpawnResult:
        ...         # Implementation
        ...         pass
    """

    def __init__(self, engine: CollaborationEngine) -> None:
        """Initialize the collaboration mode.

        Args:
            engine: The collaboration engine that owns this mode
        """
        self._engine = engine

    @property
    @abstractmethod
    def mode_type(self) -> CollaborationModeType:
        """Return the mode type enum value.

        Returns:
            The CollaborationModeType for this mode
        """
        ...

    @abstractmethod
    async def spawn(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> SpawnResult:
        """Spawn a child agent with the given configuration.

        This method creates a new child agent session and returns
        the spawn result with session ID and status.

        Args:
            config: Agent configuration (CustomAgentConfig or SubagentConfig)

        Returns:
            SpawnResult with session ID and status
        """
        ...

    @abstractmethod
    def get_tools_for_child(
        self,
        config: CustomAgentConfig | SubagentConfig,
        trust_level: TrustLevel,
    ) -> list[AgentTool]:
        """Get the filtered set of tools available to a child agent.

        This method returns a list of tools that the child agent is
        permitted to use based on trust level and configuration.

        Args:
            config: Agent configuration
            trust_level: Trust level for tool filtering

        Returns:
            Filtered list of AgentTool objects
        """
        ...

    def prepare_context(
        self,
        parent_session_id: str,
        child_config: CustomAgentConfig | SubagentConfig,
    ) -> ChildContext:
        """Prepare the context for a child agent.

        This method uses the engine's context manager to prepare
        the complete context needed for spawning a child agent.

        Args:
            parent_session_id: Parent session ID
            child_config: Child agent configuration

        Returns:
            ChildContext with all needed context
        """
        context_manager = self._engine._context_manager

        # Generate child session ID upfront
        child_session_id = str(uuid.uuid4())[:12]

        if context_manager is None:
            # Return minimal context if no context manager
            task_prompt = self._extract_task_prompt(child_config)
            return ChildContext(
                session_id=child_session_id,
                parent_session_id=parent_session_id,
                task_prompt=task_prompt,
                memory_scope=self._extract_memory_scope(child_config),
            )

        # Extract configuration from child_config
        task_prompt = self._extract_task_prompt(child_config)
        memory_scope = self._extract_memory_scope(child_config)
        trust_level = self._extract_trust_level(child_config)

        return context_manager.prepare_child_context(
            parent_session_id=parent_session_id,
            task_prompt=task_prompt,
            memory_scope=memory_scope,
            trust_level=trust_level,
        )

    def _extract_task_prompt(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> str:
        """Extract task prompt from configuration.

        Args:
            config: Agent configuration

        Returns:
            Task prompt string
        """
        if isinstance(config, CustomAgentConfig):
            # CustomAgentConfig doesn't have a prompt field
            # Use system_prompt or description
            return config.system_prompt or config.description or ""
        else:
            return config.prompt

    def _extract_memory_scope(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> MemoryScope:
        """Extract memory scope from configuration.

        Args:
            config: Agent configuration

        Returns:
            MemoryScope enum value
        """
        if isinstance(config, CustomAgentConfig):
            return config.memory_scope
        else:
            # SubagentConfig doesn't have memory_scope, use default
            return MemoryScope.TASK

    def _extract_trust_level(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> TrustLevel:
        """Extract trust level from configuration.

        Args:
            config: Agent configuration

        Returns:
            TrustLevel enum value
        """
        if isinstance(config, CustomAgentConfig):
            return config.trust_level
        else:
            # SubagentConfig doesn't have trust_level, use default
            return TrustLevel.STANDARD

    def on_child_complete(self, result: Any) -> None:
        """Callback when a child agent completes.

        This method is called when a spawned child agent finishes
        execution. Subclasses can override to handle completion events.

        Args:
            result: The result from the child agent execution
        """
        # Default implementation does nothing
        pass
