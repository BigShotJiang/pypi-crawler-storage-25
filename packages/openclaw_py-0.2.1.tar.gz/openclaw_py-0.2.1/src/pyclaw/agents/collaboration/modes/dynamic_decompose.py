"""Dynamic Decompose collaboration mode implementation.

This module implements the DynamicDecomposeMode which handles task
decomposition and spawning child agents to execute subtasks.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 2.1
"""

from __future__ import annotations

import asyncio
import logging
import warnings
from enum import Enum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field

from pyclaw.agents.collaboration.decomposer import (
    DecompositionStrategy,
    SubtaskDefinition,
    TaskDecomposer,
)
from pyclaw.agents.collaboration.modes.base import CollaborationMode
from pyclaw.agents.collaboration.types import (
    CollaborationModeType,
    CustomAgentConfig,
    SpawnResult,
    TrustLevel,
)
from pyclaw.agents.subagents.types import SubagentConfig, SubagentResult, SubagentState
from pyclaw.agents.types import AgentTool

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.engine import CollaborationEngine

logger = logging.getLogger(__name__)


class SubtaskStatus(str, Enum):
    """Status of a subtask in the decomposition."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class SubtaskState(BaseModel):
    """Runtime state of a subtask.

    Attributes:
        definition: The original subtask definition
        status: Current execution status
        session_id: Session ID of the child agent (if spawned)
        result: Result from child agent execution (if completed)
        error: Error message if failed
        retry_count: Number of retry attempts
    """

    definition: SubtaskDefinition = Field(..., description="Original subtask definition")
    status: SubtaskStatus = Field(default=SubtaskStatus.PENDING, description="Current status")
    session_id: str | None = Field(default=None, description="Child agent session ID")
    result: Any = Field(default=None, description="Execution result")
    error: str | None = Field(default=None, description="Error message if failed")
    retry_count: int = Field(default=0, description="Number of retry attempts")


class DecompositionState(BaseModel):
    """State of a task decomposition.

    Tracks all subtasks and their dependencies.

    Attributes:
        decomposition_id: Unique identifier for this decomposition
        original_task: The original task description
        subtasks: Map of task_id to SubtaskState
        max_retries: Maximum retry attempts per subtask
    """

    decomposition_id: str = Field(..., description="Unique decomposition ID")
    original_task: str = Field(..., description="Original task description")
    subtasks: dict[str, SubtaskState] = Field(default_factory=dict, description="Subtask states")
    max_retries: int = Field(default=0, description="Maximum retry attempts")


class DynamicDecomposeMode(CollaborationMode):
    """Collaboration mode for dynamic task decomposition.

    This mode decomposes a complex task into smaller subtasks using
    TaskDecomposer, then spawns child agents to execute them in
    dependency order.

    .. deprecated:: 1.0.0
        Use :class:`pyclaw.agents.multiagent.engines.DynamicDecomposeEngine` instead.
        This class will be removed in version 2.0.0.

    Key features:
    - Uses TaskDecomposer for intelligent task decomposition
    - Tracks subtask dependencies and execution order
    - Spawns child agents for subtasks when dependencies are satisfied
    - Supports parallel execution of independent subtasks
    - Handles subtask completion and triggers subsequent tasks

    Example:
        >>> engine = CollaborationEngine(subagent_manager=manager)
        >>> mode = DynamicDecomposeMode(engine)
        >>> engine.register_mode(CollaborationModeType.DYNAMIC_DECOMPOSE, mode)
        >>> config = SubagentConfig(prompt="Research and report on AI trends")
        >>> result = await mode.spawn(config)
    """

    # Default decomposition strategy
    DEFAULT_STRATEGY: DecompositionStrategy = DecompositionStrategy.HYBRID
    # Default maximum retry attempts
    DEFAULT_MAX_RETRIES: int = 0

    def __init__(
        self,
        engine: CollaborationEngine,
        decomposer: TaskDecomposer | None = None,
    ) -> None:
        """Initialize the Dynamic Decompose mode.

        Args:
            engine: The collaboration engine that owns this mode
            decomposer: Optional TaskDecomposer instance (creates default if None)
        """
        super().__init__(engine)
        self._decomposer = decomposer or TaskDecomposer(strategy=self.DEFAULT_STRATEGY)
        # Track active decompositions by parent session ID
        self._decompositions: dict[str, DecompositionState] = {}
        warnings.warn(
            "DynamicDecomposeMode is deprecated since version 1.0.0. "
            "Use pyclaw.agents.multiagent.engines.DynamicDecomposeEngine instead. "
            "This class will be removed in version 2.0.0.",
            DeprecationWarning,
            stacklevel=2,
        )

    @property
    def mode_type(self) -> CollaborationModeType:
        """Return the mode type.

        Returns:
            CollaborationModeType.DYNAMIC_DECOMPOSE
        """
        return CollaborationModeType.DYNAMIC_DECOMPOSE

    @property
    def decomposer(self) -> TaskDecomposer:
        """Get the task decomposer.

        Returns:
            TaskDecomposer instance
        """
        return self._decomposer

    async def spawn(
        self,
        config: CustomAgentConfig | SubagentConfig,
    ) -> SpawnResult:
        """Decompose task and spawn initial child agents.

        This method:
        1. Decomposes the task using TaskDecomposer
        2. Creates a DecompositionState to track subtasks
        3. Identifies subtasks with no dependencies (ready to run)
        4. Spawns child agents for ready subtasks in parallel

        Args:
            config: Agent configuration containing the task prompt

        Returns:
            SpawnResult with the decomposition status
        """
        # Check depth limit
        if self._engine.depth >= self._engine.MAX_DEPTH:
            logger.warning(
                "Max depth exceeded: current=%d, max=%d",
                self._engine.depth,
                self._engine.MAX_DEPTH,
            )
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        # Extract task prompt
        task_prompt = self._extract_task_prompt(config)

        if not task_prompt:
            logger.warning("No task prompt provided for decomposition")
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        # Decompose the task
        try:
            import uuid

            decomposition_id = str(uuid.uuid4())[:8]
            subtask_definitions = await self._decomposer.decompose(
                task=task_prompt,
                context={"base_id": decomposition_id},
            )
        except Exception as e:
            logger.error("Task decomposition failed: %s", e, exc_info=True)
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        if not subtask_definitions:
            logger.warning("Task decomposition returned no subtasks")
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        logger.info(
            "Decomposed task into %d subtasks: %s",
            len(subtask_definitions),
            [st.task_id for st in subtask_definitions],
        )

        # Create decomposition state
        decomposition_state = DecompositionState(
            decomposition_id=decomposition_id,
            original_task=task_prompt,
            subtasks={st.task_id: SubtaskState(definition=st) for st in subtask_definitions},
            max_retries=self.DEFAULT_MAX_RETRIES,
        )

        # Store decomposition state
        parent_session_id = self._engine.session_id
        self._decompositions[parent_session_id] = decomposition_state

        # Find subtasks ready to run (no dependencies)
        ready_subtasks = self._get_ready_subtasks(decomposition_state)

        if not ready_subtasks:
            logger.warning("No subtasks ready to run (circular dependency?)")
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context=None,
            )

        logger.info("Spawning %d initial subtasks: %s", len(ready_subtasks), ready_subtasks)

        # Convert config if needed
        base_config = (
            self._convert_to_subagent_config(config) if isinstance(config, CustomAgentConfig) else config.model_copy()
        )

        # Spawn child agents for ready subtasks
        spawn_results = await self._spawn_subtasks(
            base_config=base_config,
            subtask_ids=ready_subtasks,
            decomposition_state=decomposition_state,
            parent_session_id=parent_session_id,
        )

        # Determine overall status
        successful_results = [r for r in spawn_results if r.status == "success"]
        if successful_results:
            # At least one subtask spawned successfully
            return SpawnResult(
                session_id=decomposition_id,
                status="success",
                children=[r.session_id for r in successful_results],
                child_context={
                    "decomposition_id": decomposition_id,
                    "total_subtasks": len(subtask_definitions),
                    "initial_subtasks": ready_subtasks,
                },
            )
        else:
            return SpawnResult(
                session_id=decomposition_id,
                status="failed",
                children=[],
                child_context=None,
            )

    def get_tools_for_child(
        self,
        config: CustomAgentConfig | SubagentConfig,
        trust_level: TrustLevel,
    ) -> list[AgentTool]:
        """Get filtered tools for a child agent.

        In Dynamic Decompose mode, child agents get tools based on
        their assigned_mode from the SubtaskDefinition.

        Args:
            config: Agent configuration
            trust_level: Trust level for tool filtering

        Returns:
            Filtered list of AgentTool objects
        """
        permission_manager = self._engine._permission_manager

        if permission_manager is None:
            logger.warning("No permission manager available, returning empty tools")
            return []

        # TODO(#collaboration): Once ToolRegistry is implemented, fetch actual tools
        # For now, return empty list - actual tools will be determined by
        # SubagentManager during spawn based on tools_enabled/tools_disabled
        _ = config  # Acknowledge for future use
        _ = trust_level
        return []

    def on_child_complete(self, result: Any) -> None:
        """Handle child agent completion.

        This callback:
        1. Updates the subtask state based on result
        2. Checks for newly ready subtasks
        3. Triggers spawning of next subtasks

        Args:
            result: The result from the child agent execution
        """
        if not isinstance(result, dict):
            logger.warning("Unexpected result type: %s", type(result))
            return

        session_id = result.get("session_id")
        success = result.get("success", False)

        if not session_id:
            logger.warning("No session_id in child completion result")
            return

        # Find the subtask by session_id
        for parent_session_id, decomposition_state in self._decompositions.items():
            for task_id, subtask_state in decomposition_state.subtasks.items():
                if subtask_state.session_id == session_id:
                    # Update subtask state
                    if success:
                        subtask_state.status = SubtaskStatus.COMPLETED
                        subtask_state.result = result.get("output")
                        logger.info("Subtask %s completed successfully", task_id)
                    else:
                        subtask_state.status = SubtaskStatus.FAILED
                        subtask_state.error = result.get("error", "Unknown error")
                        logger.warning("Subtask %s failed: %s", task_id, subtask_state.error)

                    # Trigger next subtasks
                    self._trigger_next_subtasks(
                        parent_session_id=parent_session_id,
                        completed_task_id=task_id,
                    )
                    return

        logger.warning("No matching subtask found for session %s", session_id)

    def _get_ready_subtasks(
        self,
        decomposition_state: DecompositionState,
    ) -> list[str]:
        """Get task IDs of subtasks ready to execute.

        A subtask is ready when:
        - Its status is PENDING
        - All its dependencies are COMPLETED

        Args:
            decomposition_state: The decomposition state

        Returns:
            List of task IDs ready to execute
        """
        ready = []
        for task_id, subtask_state in decomposition_state.subtasks.items():
            if subtask_state.status != SubtaskStatus.PENDING:
                continue

            # Check if all dependencies are completed
            dependencies = subtask_state.definition.dependencies
            all_deps_completed = all(
                decomposition_state.subtasks.get(
                    dep, SubtaskState(definition=SubtaskDefinition(task_id=dep, description=""))
                ).status
                == SubtaskStatus.COMPLETED
                for dep in dependencies
            )

            if all_deps_completed:
                ready.append(task_id)

        # Sort by priority (higher priority first)
        ready.sort(
            key=lambda tid: decomposition_state.subtasks[tid].definition.priority,
            reverse=True,
        )

        return ready

    async def _spawn_subtasks(
        self,
        base_config: SubagentConfig,
        subtask_ids: list[str],
        decomposition_state: DecompositionState,
        parent_session_id: str,
    ) -> list[SpawnResult]:
        """Spawn child agents for multiple subtasks in parallel.

        Args:
            base_config: Base configuration for all subtasks
            subtask_ids: List of subtask task IDs to spawn
            decomposition_state: The decomposition state
            parent_session_id: Parent session ID

        Returns:
            List of SpawnResult for each spawned subtask
        """
        spawn_tasks = [
            self._spawn_single_subtask(
                base_config=base_config,
                task_id=task_id,
                decomposition_state=decomposition_state,
                parent_session_id=parent_session_id,
            )
            for task_id in subtask_ids
        ]

        try:
            results = await asyncio.gather(*spawn_tasks, return_exceptions=True)
        except Exception as e:
            logger.error("Failed to spawn subtasks: %s", e, exc_info=True)
            return []

        # Filter out exceptions and return valid results
        spawn_results: list[SpawnResult] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error("Subtask %s spawn failed: %s", subtask_ids[i], result)
                # Mark as failed in state
                if subtask_ids[i] in decomposition_state.subtasks:
                    decomposition_state.subtasks[subtask_ids[i]].status = SubtaskStatus.FAILED
                    decomposition_state.subtasks[subtask_ids[i]].error = str(result)
            elif isinstance(result, SpawnResult):
                spawn_results.append(result)

        return spawn_results

    async def _spawn_single_subtask(
        self,
        base_config: SubagentConfig,
        task_id: str,
        decomposition_state: DecompositionState,
        parent_session_id: str,
    ) -> SpawnResult:
        """Spawn a child agent for a single subtask.

        Args:
            base_config: Base configuration
            task_id: The subtask task ID
            decomposition_state: The decomposition state
            parent_session_id: Parent session ID

        Returns:
            SpawnResult for this subtask
        """
        subtask_state = decomposition_state.subtasks[task_id]
        subtask_def = subtask_state.definition

        # Mark as running
        subtask_state.status = SubtaskStatus.RUNNING

        # Prepare context
        child_context = self.prepare_context(parent_session_id, base_config)

        # Create subtask-specific config
        subtask_config = base_config.model_copy()
        subtask_config.session_id = child_context.session_id
        subtask_config.parent_session_id = parent_session_id
        subtask_config.current_depth = self._engine.depth + 1
        subtask_config.workspace_dir = child_context.scratchpad_dir or ""
        subtask_config.prompt = subtask_def.description

        # Store session ID in state
        subtask_state.session_id = child_context.session_id

        try:
            # Spawn via SubagentManager
            result: SubagentResult = await self._engine._subagent_manager.spawn(subtask_config)

            if result.state == SubagentState.COMPLETED:
                subtask_state.status = SubtaskStatus.COMPLETED
                subtask_state.result = result.output
                return SpawnResult(
                    session_id=child_context.session_id,
                    status="success",
                    children=[child_context.session_id],
                    child_context={"task_id": task_id, "output": result.output},
                )
            else:
                subtask_state.status = SubtaskStatus.FAILED
                subtask_state.error = result.error or "Unknown error"
                return SpawnResult(
                    session_id=child_context.session_id,
                    status="failed",
                    children=[],
                    child_context={"task_id": task_id, "error": subtask_state.error},
                )

        except Exception as e:
            logger.error("Failed to spawn subtask %s: %s", task_id, e, exc_info=True)
            subtask_state.status = SubtaskStatus.FAILED
            subtask_state.error = str(e)
            return SpawnResult(
                session_id="",
                status="failed",
                children=[],
                child_context={"task_id": task_id, "error": str(e)},
            )

    def _trigger_next_subtasks(
        self,
        parent_session_id: str,
        completed_task_id: str,
    ) -> None:
        """Trigger spawning of newly ready subtasks after a subtask completes.

        Note: This method schedules the spawning asynchronously to avoid
        blocking the completion callback. If no event loop is running,
        the spawning will be skipped (can be called manually later).

        Args:
            parent_session_id: Parent session ID
            completed_task_id: The task ID that just completed
        """
        decomposition_state = self._decompositions.get(parent_session_id)
        if decomposition_state is None:
            return

        # Find newly ready subtasks
        ready_subtasks = self._get_ready_subtasks(decomposition_state)

        # Filter out already running/completed tasks
        newly_ready = [
            tid for tid in ready_subtasks if decomposition_state.subtasks[tid].status == SubtaskStatus.PENDING
        ]

        if not newly_ready:
            logger.debug("No new subtasks ready after %s completion", completed_task_id)
            return

        logger.info(
            "Triggering %d next subtasks after %s: %s",
            len(newly_ready),
            completed_task_id,
            newly_ready,
        )

        # Schedule async spawning if there's a running event loop
        try:
            asyncio.get_running_loop()  # Check if event loop is running
            asyncio.create_task(
                self._spawn_next_subtasks(
                    parent_session_id=parent_session_id,
                    subtask_ids=newly_ready,
                )
            )
        except RuntimeError:
            # No running event loop - this can happen in synchronous tests
            # or when called from a non-async context
            logger.debug("No running event loop, cannot schedule next subtasks automatically")

    async def _spawn_next_subtasks(
        self,
        parent_session_id: str,
        subtask_ids: list[str],
    ) -> None:
        """Spawn the next set of ready subtasks.

        Args:
            parent_session_id: Parent session ID
            subtask_ids: List of subtask task IDs to spawn
        """
        decomposition_state = self._decompositions.get(parent_session_id)
        if decomposition_state is None:
            return

        # Create a base config (would normally come from the decomposition)
        base_config = SubagentConfig(
            agent_id="subtask-worker",
            prompt="",
            current_depth=self._engine.depth + 1,
            system_prompt=None,
        )

        await self._spawn_subtasks(
            base_config=base_config,
            subtask_ids=subtask_ids,
            decomposition_state=decomposition_state,
            parent_session_id=parent_session_id,
        )

    def get_decomposition_state(
        self,
        parent_session_id: str,
    ) -> DecompositionState | None:
        """Get the decomposition state for a parent session.

        Args:
            parent_session_id: Parent session ID

        Returns:
            DecompositionState if found, None otherwise
        """
        return self._decompositions.get(parent_session_id)

    def get_subtask_status(
        self,
        parent_session_id: str,
        task_id: str,
    ) -> SubtaskStatus | None:
        """Get the status of a specific subtask.

        Args:
            parent_session_id: Parent session ID
            task_id: Subtask task ID

        Returns:
            SubtaskStatus if found, None otherwise
        """
        state = self._decompositions.get(parent_session_id)
        if state is None:
            return None

        subtask = state.subtasks.get(task_id)
        if subtask is None:
            return None

        return subtask.status

    def _convert_to_subagent_config(
        self,
        custom_config: CustomAgentConfig,
    ) -> SubagentConfig:
        """Convert CustomAgentConfig to SubagentConfig.

        Args:
            custom_config: The custom agent configuration

        Returns:
            SubagentConfig for spawning the child
        """
        return SubagentConfig(
            session_id="",  # Will be set during spawn
            parent_session_id="",  # Will be set during spawn
            agent_id=custom_config.agent_id,
            prompt="",  # Will be set from subtask description
            model=custom_config.model or "",
            provider="",  # Use default provider
            tools_enabled=custom_config.tools_enabled or [],
            tools_disabled=custom_config.tools_disabled or [],
            system_prompt=custom_config.system_prompt,
            current_depth=0,  # Will be set during spawn
            max_depth=self._engine.MAX_DEPTH,
            metadata={
                "name": custom_config.name,
                "description": custom_config.description,
                "tags": custom_config.tags,
                "source": custom_config.source,
                "source_path": custom_config.source_path,
                "memory_scope": custom_config.memory_scope.value,
                "trust_level": custom_config.trust_level.value,
            },
        )
