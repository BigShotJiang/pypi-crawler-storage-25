"""Collaboration mode implementations.

.. deprecated:: 1.0.0
    This module is deprecated. Use :mod:`pyclaw.agents.multiagent.engines` instead.
    This module will be removed in version 2.0.0.

This package contains the different collaboration mode implementations:
- base: Abstract base class for all modes
- custom_agent: Predefined agent mode
- fork_swarm: Parallel execution mode
- coordinator_worker: Coordinator-worker mode
- dynamic_decompose: Dynamic task decomposition mode

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 4
"""

import warnings

from pyclaw.agents.collaboration.modes.base import CollaborationMode
from pyclaw.agents.collaboration.modes.coordinator_worker import CoordinatorWorkerMode
from pyclaw.agents.collaboration.modes.custom_agent import CustomAgentMode
from pyclaw.agents.collaboration.modes.dynamic_decompose import DynamicDecomposeMode
from pyclaw.agents.collaboration.modes.fork_swarm import ForkSwarmMode

# Re-export from unified multiagent module for backward compatibility
from pyclaw.agents.multiagent.types import CollaborationModeType, MemoryScope, TrustLevel

# Emit deprecation warning on import
warnings.warn(
    "pyclaw.agents.collaboration.modes is deprecated since version 1.0.0. "
    "Use pyclaw.agents.multiagent.engines instead. "
    "This module will be removed in version 2.0.0.",
    DeprecationWarning,
    stacklevel=2,
)

__all__ = [
    "CollaborationMode",
    "CoordinatorWorkerMode",
    "CustomAgentMode",
    "DynamicDecomposeMode",
    "ForkSwarmMode",
    # Re-exported types from multiagent.types
    "CollaborationModeType",
    "TrustLevel",
    "MemoryScope",
]
