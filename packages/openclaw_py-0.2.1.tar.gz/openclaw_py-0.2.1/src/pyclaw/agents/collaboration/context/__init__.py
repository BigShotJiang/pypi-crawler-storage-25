"""Context sharing and management.

This package handles context inheritance, scratchpad management,
and memory scope configuration for child agents.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 4.6
"""

from pyclaw.agents.collaboration.context.sharing import (
    ContextSharingManager,
    HistoryMode,
    MemoryAccessor,
    ScratchpadConfig,
    ScratchpadScope,
)

__all__ = [
    "ContextSharingManager",
    "HistoryMode",
    "MemoryAccessor",
    "ScratchpadConfig",
    "ScratchpadScope",
]
