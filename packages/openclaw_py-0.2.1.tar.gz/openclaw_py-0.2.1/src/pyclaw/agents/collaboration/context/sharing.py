"""Context sharing and management for multi-agent collaboration.

This module provides the ContextSharingManager class which handles:
- B Strategy: Context inheritance (read-only history access)
- C Strategy: Shared workspace (Scratchpad)
- Restricted D Strategy: Memory system sharing with scope control

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 4.6
"""

from __future__ import annotations

import logging
import shutil
import tempfile
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field

from pyclaw.agents.collaboration.types import ChildContext, MemoryScope, TrustLevel

if TYPE_CHECKING:
    from pyclaw.agents.session import SessionManager
    from pyclaw.memory.manager import MemoryManager

logger = logging.getLogger(__name__)


# ============================================================================
# Enums
# ============================================================================


class HistoryMode(str, Enum):
    """History retrieval mode for parent context.

    - FULL: Complete conversation history
    - SUMMARY: Compressed summary version
    - RECENT: Last N messages only
    """

    FULL = "full"
    SUMMARY = "summary"
    RECENT = "recent"


class ScratchpadScope(str, Enum):
    """Scope for scratchpad visibility.

    - SESSION: Only visible to the session and its children
    - PROJECT: Visible across the project
    - GLOBAL: Shared globally (not implemented yet)
    """

    SESSION = "session"
    PROJECT = "project"
    GLOBAL = "global"


# ============================================================================
# Models
# ============================================================================


class ScratchpadConfig(BaseModel):
    """Configuration for a shared scratchpad workspace.

    A scratchpad is a temporary shared directory where parent and child
    agents can exchange files and data during collaboration.

    Attributes:
        scratchpad_id: Unique identifier for this scratchpad
        path: Filesystem path to the scratchpad directory
        scope: Visibility scope (session/project/global)
        parent_session_id: Session ID of the parent agent
        created_at: Creation timestamp
        max_size_mb: Maximum allowed size in megabytes
        ttl_seconds: Time-to-live in seconds (0 = no expiry)
    """

    scratchpad_id: str = Field(
        default_factory=lambda: str(uuid.uuid4())[:12],
        description="Unique identifier for this scratchpad",
    )
    path: str = Field(..., description="Filesystem path to the scratchpad directory")
    scope: ScratchpadScope = Field(
        default=ScratchpadScope.SESSION,
        description="Visibility scope",
    )
    parent_session_id: str = Field(..., description="Parent session ID")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Creation timestamp",
    )
    max_size_mb: int = Field(default=100, description="Maximum size in MB")
    ttl_seconds: int = Field(default=3600, description="Time-to-live in seconds")


# ============================================================================
# Memory Accessor
# ============================================================================


@dataclass
class MemoryAccessor:
    """Provides controlled access to memory for child agents.

    This class wraps the MemoryManager and enforces access control based
    on the memory scope and trust level.

    Attributes:
        memory_manager: The underlying MemoryManager instance
        scope: Memory scope (TASK or PROJECT)
        session_id: Session ID for this accessor
        parent_session_id: Parent session ID
        trust_level: Trust level for access control
        can_read: Whether read access is allowed
        can_write: Whether write access is allowed
    """

    memory_manager: MemoryManager | None
    scope: MemoryScope
    session_id: str
    parent_session_id: str
    trust_level: TrustLevel
    can_read: bool = field(default=False)
    can_write: bool = field(default=False)

    def __post_init__(self) -> None:
        """Compute read/write permissions based on scope and trust level."""
        if self.scope == MemoryScope.TASK:
            # TASK scope: Independent SESSION memory
            # Child gets new session, inherits parent summary on init
            self.can_read = True
            self.can_write = True
        elif self.scope == MemoryScope.PROJECT:
            # PROJECT scope: Shared project memory with access control
            # RESTRICTED (50) and above: can read
            # STANDARD (75) and above: can write
            self.can_read = self.trust_level >= TrustLevel.RESTRICTED
            self.can_write = self.trust_level >= TrustLevel.STANDARD

    async def search(self, query: str, limit: int = 10) -> list[dict[str, Any]]:
        """Search memories with access control.

        Args:
            query: Search query
            limit: Maximum number of results

        Returns:
            List of matching memory entries
        """
        if not self.can_read:
            logger.warning(
                "Memory read denied: session=%s scope=%s trust=%s",
                self.session_id,
                self.scope,
                self.trust_level,
            )
            return []

        if self.memory_manager is None:
            return []

        try:
            results = self.memory_manager.search_memory(query, limit=limit)
            return results
        except Exception as e:
            logger.error("Memory search failed: %s", e)
            return []

    async def add(self, content: str, category: str = "general") -> bool:
        """Add a memory entry with access control.

        Args:
            content: Memory content to add
            category: Memory category

        Returns:
            True if successful, False otherwise
        """
        if not self.can_write:
            logger.warning(
                "Memory write denied: session=%s scope=%s trust=%s",
                self.session_id,
                self.scope,
                self.trust_level,
            )
            return False

        if self.memory_manager is None:
            return False

        try:
            self.memory_manager.add_memory(content, category=category)
            return True
        except Exception as e:
            logger.error("Memory add failed: %s", e)
            return False

    def get_preferences(self) -> dict[str, str]:
        """Get all preferences with read access control.

        Returns:
            Dictionary of preferences
        """
        if not self.can_read or self.memory_manager is None:
            return {}

        try:
            return self.memory_manager.get_all_preferences()
        except Exception as e:
            logger.error("Get preferences failed: %s", e)
            return {}

    def set_preference(self, key: str, value: str) -> bool:
        """Set a preference with write access control.

        Args:
            key: Preference key
            value: Preference value

        Returns:
            True if successful
        """
        if not self.can_write or self.memory_manager is None:
            return False

        try:
            self.memory_manager.set_preference(key, value)
            return True
        except Exception as e:
            logger.error("Set preference failed: %s", e)
            return False


# ============================================================================
# Context Sharing Manager
# ============================================================================


class ContextSharingManager:
    """Manages context sharing between parent and child agents.

    This class implements three context sharing strategies:
    - B Strategy: Context inheritance (read-only history)
    - C Strategy: Shared workspace (Scratchpad)
    - Restricted D Strategy: Memory system sharing

    Key constraints:
    - Child agents CANNOT access parent SESSION memory raw data
    - Only summary is shared for SESSION memory
    - PROJECT memory access is controlled by trust level

    Example:
        >>> manager = ContextSharingManager(workspace_dir=Path("./workspace"))
        >>> history = manager.get_parent_history("parent-123", HistoryMode.RECENT, 10)
        >>> scratchpad = manager.create_scratchpad("parent-123", ScratchpadScope.SESSION)
        >>> context = manager.prepare_child_context("parent-123", "Analyze this", MemoryScope.TASK)
    """

    DEFAULT_SUMMARY_MESSAGES = 50
    DEFAULT_RECENT_COUNT = 10

    def __init__(
        self,
        workspace_dir: Path | None = None,
        memory_manager: MemoryManager | None = None,
        session_managers: dict[str, SessionManager] | None = None,
    ) -> None:
        """Initialize the context sharing manager.

        Args:
            workspace_dir: Base directory for scratchpads
            memory_manager: Optional MemoryManager for D strategy
            session_managers: Optional dict of session_id -> SessionManager
        """
        self._workspace_dir = workspace_dir or Path(tempfile.gettempdir()) / "pyclaw_scratchpads"
        self._memory_manager = memory_manager
        self._session_managers: dict[str, SessionManager] = session_managers or {}
        self._scratchpads: dict[str, ScratchpadConfig] = {}
        self._memory_accessors: dict[str, MemoryAccessor] = {}

    # -------------------------------------------------------------------------
    # Properties
    # -------------------------------------------------------------------------

    @property
    def workspace_dir(self) -> Path:
        """Get the workspace directory."""
        return self._workspace_dir

    # -------------------------------------------------------------------------
    # Session Manager Registry
    # -------------------------------------------------------------------------

    def register_session_manager(self, session_id: str, manager: SessionManager) -> None:
        """Register a session manager for a session.

        Args:
            session_id: Session identifier
            manager: SessionManager instance
        """
        self._session_managers[session_id] = manager
        logger.debug("Registered session manager: %s", session_id)

    def unregister_session_manager(self, session_id: str) -> None:
        """Unregister a session manager.

        Args:
            session_id: Session identifier
        """
        self._session_managers.pop(session_id, None)
        logger.debug("Unregistered session manager: %s", session_id)

    # -------------------------------------------------------------------------
    # B Strategy: Context Inheritance (Read-Only)
    # -------------------------------------------------------------------------

    def get_parent_history(
        self,
        parent_session_id: str,
        mode: HistoryMode = HistoryMode.RECENT,
        recent_count: int = DEFAULT_RECENT_COUNT,
    ) -> list[dict[str, Any]]:
        """Get parent session history in the specified mode.

        This implements the B Strategy for context inheritance.
        Child agents receive a read-only snapshot of parent history.

        Args:
            parent_session_id: Parent session ID
            mode: History retrieval mode (full/summary/recent)
            recent_count: Number of recent messages (for RECENT mode)

        Returns:
            List of message dictionaries (read-only snapshot)

        Note:
            - FULL: Returns complete history (may be large)
            - SUMMARY: Returns compressed summary + recent messages
            - RECENT: Returns last N messages
        """
        session_manager = self._session_managers.get(parent_session_id)
        if session_manager is None:
            logger.warning(
                "Session manager not found for parent: %s",
                parent_session_id,
            )
            return []

        # Get raw messages
        messages = session_manager.get_messages_as_dicts()

        if mode == HistoryMode.FULL:
            # Return complete history (read-only copy)
            return list(messages)

        if mode == HistoryMode.SUMMARY:
            # Compress history to summary
            return self._summarize_history(messages)

        # RECENT mode: return last N messages
        return messages[-recent_count:] if len(messages) > recent_count else list(messages)

    def _summarize_history(self, history: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Compress history into a summary format.

        Creates a compressed representation of the conversation history
        that preserves key information while reducing token count.

        Args:
            history: Full conversation history

        Returns:
            Compressed history with summary message
        """
        if not history:
            return []

        # Simple summarization: extract key points
        # In production, this would use LLM-based summarization
        user_messages = [m for m in history if m.get("role") == "user"]
        assistant_messages = [m for m in history if m.get("role") == "assistant"]

        summary_parts = [
            f"Conversation summary ({len(user_messages)} user messages, {len(assistant_messages)} assistant messages):",
        ]

        # Extract key content from recent messages
        recent_user = user_messages[-3:] if len(user_messages) > 3 else user_messages
        for msg in recent_user:
            content = msg.get("content", "")
            if isinstance(content, str):
                # Truncate long messages
                preview = content[:200] + "..." if len(content) > 200 else content
                summary_parts.append(f"- User: {preview}")

        # Create summary message
        summary_message = {
            "role": "system",
            "content": "\n".join(summary_parts),
        }

        # Keep last few messages for context
        keep_count = 4
        recent_messages = history[-keep_count:] if len(history) > keep_count else history

        return [summary_message] + list(recent_messages)

    # -------------------------------------------------------------------------
    # C Strategy: Shared Workspace (Scratchpad)
    # -------------------------------------------------------------------------

    def create_scratchpad(
        self,
        parent_session_id: str,
        scope: ScratchpadScope = ScratchpadScope.SESSION,
    ) -> ScratchpadConfig:
        """Create a shared scratchpad workspace.

        This implements the C Strategy for shared workspace.
        The scratchpad is a temporary directory for file exchange.

        Args:
            parent_session_id: Parent session ID
            scope: Visibility scope

        Returns:
            ScratchpadConfig with path and metadata
        """
        scratchpad_id = str(uuid.uuid4())[:12]

        # Create scratchpad directory
        scratchpad_path = self._workspace_dir / "scratchpads" / scratchpad_id
        scratchpad_path.mkdir(parents=True, exist_ok=True)

        config = ScratchpadConfig(
            scratchpad_id=scratchpad_id,
            path=str(scratchpad_path),
            scope=scope,
            parent_session_id=parent_session_id,
        )

        self._scratchpads[scratchpad_id] = config
        logger.info(
            "Created scratchpad: id=%s path=%s scope=%s",
            scratchpad_id,
            scratchpad_path,
            scope,
        )

        return config

    def get_scratchpad(self, scratchpad_id: str) -> ScratchpadConfig | None:
        """Get a scratchpad configuration by ID.

        Args:
            scratchpad_id: Scratchpad identifier

        Returns:
            ScratchpadConfig if found, None otherwise
        """
        return self._scratchpads.get(scratchpad_id)

    def cleanup_scratchpad(self, scratchpad_id: str) -> bool:
        """Clean up a scratchpad workspace.

        Removes the scratchpad directory and its contents.

        Args:
            scratchpad_id: Scratchpad identifier

        Returns:
            True if cleanup was successful
        """
        config = self._scratchpads.get(scratchpad_id)
        if config is None:
            logger.warning("Scratchpad not found for cleanup: %s", scratchpad_id)
            return False

        scratchpad_path = Path(config.path)

        try:
            if scratchpad_path.exists():
                shutil.rmtree(scratchpad_path)
                logger.info("Cleaned up scratchpad: %s", scratchpad_id)

            del self._scratchpads[scratchpad_id]
            return True
        except Exception as e:
            logger.error("Failed to cleanup scratchpad %s: %s", scratchpad_id, e)
            return False

    def list_scratchpads(self, parent_session_id: str | None = None) -> list[ScratchpadConfig]:
        """List all scratchpads, optionally filtered by parent session.

        Args:
            parent_session_id: Optional parent session filter

        Returns:
            List of ScratchpadConfig objects
        """
        if parent_session_id is None:
            return list(self._scratchpads.values())

        return [config for config in self._scratchpads.values() if config.parent_session_id == parent_session_id]

    # -------------------------------------------------------------------------
    # Restricted D Strategy: Memory System Sharing
    # -------------------------------------------------------------------------

    def get_memory_access(
        self,
        session_id: str,
        parent_session_id: str,
        scope: MemoryScope,
        trust_level: TrustLevel = TrustLevel.STANDARD,
    ) -> MemoryAccessor:
        """Get controlled memory access for a session.

        This implements the Restricted D Strategy for memory sharing.
        Access is controlled by scope and trust level.

        Args:
            session_id: Child session ID
            parent_session_id: Parent session ID
            scope: Memory scope (TASK or PROJECT)
            trust_level: Trust level for access control

        Returns:
            MemoryAccessor with controlled access
        """
        accessor = MemoryAccessor(
            memory_manager=self._memory_manager,
            scope=scope,
            session_id=session_id,
            parent_session_id=parent_session_id,
            trust_level=trust_level,
        )

        self._memory_accessors[session_id] = accessor
        logger.debug(
            "Created memory accessor: session=%s scope=%s trust=%s read=%s write=%s",
            session_id,
            scope,
            trust_level,
            accessor.can_read,
            accessor.can_write,
        )

        return accessor

    # -------------------------------------------------------------------------
    # Child Context Preparation
    # -------------------------------------------------------------------------

    def prepare_child_context(
        self,
        parent_session_id: str,
        task_prompt: str,
        memory_scope: MemoryScope = MemoryScope.TASK,
        history_mode: HistoryMode = HistoryMode.RECENT,
        recent_count: int = DEFAULT_RECENT_COUNT,
        trust_level: TrustLevel = TrustLevel.STANDARD,
        scratchpad_scope: ScratchpadScope = ScratchpadScope.SESSION,
    ) -> ChildContext:
        """Prepare complete context for spawning a child agent.

        This method combines all three strategies to prepare the
        complete context needed for a child agent.

        Args:
            parent_session_id: Parent session ID
            task_prompt: Task prompt for the child agent
            memory_scope: Memory storage scope
            history_mode: History retrieval mode
            recent_count: Number of recent messages
            trust_level: Trust level for memory access
            scratchpad_scope: Scope for shared workspace

        Returns:
            ChildContext with all needed context
        """
        # Generate child session ID
        child_session_id = str(uuid.uuid4())[:12]

        # B Strategy: Get parent history snapshot
        history_snapshot = self.get_parent_history(
            parent_session_id,
            mode=history_mode,
            recent_count=recent_count,
        )

        # C Strategy: Create scratchpad
        scratchpad = self.create_scratchpad(parent_session_id, scope=scratchpad_scope)

        # D Strategy: Create memory accessor (registers in _memory_accessors)
        self.get_memory_access(
            session_id=child_session_id,
            parent_session_id=parent_session_id,
            scope=memory_scope,
            trust_level=trust_level,
        )

        # For TASK scope, inject parent summary into new session
        memory_session_id = None
        if memory_scope == MemoryScope.TASK:
            # TASK scope creates a new session instance
            memory_session_id = child_session_id
            # The accessor will handle injecting parent summary on first access
        elif memory_scope == MemoryScope.PROJECT:
            # PROJECT scope uses project-level memory
            memory_session_id = f"project-{parent_session_id.split('-')[0]}"

        context = ChildContext(
            session_id=child_session_id,
            parent_session_id=parent_session_id,
            history_snapshot=history_snapshot,
            scratchpad_dir=scratchpad.path,
            memory_scope=memory_scope,
            memory_session_id=memory_session_id,
            task_prompt=task_prompt,
        )

        logger.info(
            "Prepared child context: child=%s parent=%s scope=%s",
            child_session_id,
            parent_session_id,
            memory_scope,
        )

        return context

    # -------------------------------------------------------------------------
    # Cleanup
    # -------------------------------------------------------------------------

    def cleanup_session(self, session_id: str) -> dict[str, Any]:
        """Clean up all resources associated with a session.

        Args:
            session_id: Session to clean up

        Returns:
            Dict with cleanup statistics
        """
        stats: dict[str, Any] = {
            "scratchpads_removed": 0,
            "memory_accessors_removed": 0,
        }

        # Clean up scratchpads
        for scratchpad_id, config in list(self._scratchpads.items()):
            if config.parent_session_id == session_id:
                if self.cleanup_scratchpad(scratchpad_id):
                    stats["scratchpads_removed"] += 1

        # Remove memory accessor
        if session_id in self._memory_accessors:
            del self._memory_accessors[session_id]
            stats["memory_accessors_removed"] += 1

        # Unregister session manager
        self.unregister_session_manager(session_id)

        logger.info("Cleaned up session %s: %s", session_id, stats)
        return stats

    def cleanup_all(self) -> dict[str, Any]:
        """Clean up all scratchpads and accessors.

        Returns:
            Dict with cleanup statistics
        """
        stats: dict[str, Any] = {
            "scratchpads_removed": 0,
            "memory_accessors_removed": 0,
        }

        # Clean up all scratchpads
        for scratchpad_id in list(self._scratchpads.keys()):
            if self.cleanup_scratchpad(scratchpad_id):
                stats["scratchpads_removed"] += 1

        # Clear memory accessors
        stats["memory_accessors_removed"] = len(self._memory_accessors)
        self._memory_accessors.clear()

        logger.info("Cleaned up all: %s", stats)
        return stats
