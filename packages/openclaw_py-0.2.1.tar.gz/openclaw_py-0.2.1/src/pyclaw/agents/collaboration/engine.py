"""Collaboration engine - orchestrates multi-agent collaboration modes.

The CollaborationEngine is the central coordinator for all collaboration patterns.
It manages mode switching, child agent lifecycle, and delegates to SubagentManager
for actual agent execution.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pyclaw.agents.collaboration.types import (
    CollaborationModeType,
    CollaborationSession,
    CustomAgentConfig,
    ModeSuggestion,
    ModeSwitchResult,
    SpawnResult,
)
from pyclaw.agents.subagents.manager import SubagentManager
from pyclaw.agents.subagents.types import SubagentConfig

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.modes.base import CollaborationMode


class CollaborationEngine:
    """Collaboration engine - unified coordinator for all collaboration modes.

    This engine manages:
    - Mode registration and switching
    - Child agent spawning with depth limits
    - Delegation to SubagentManager for lifecycle management
    - Session state tracking

    Attributes:
        MAX_CHILDREN: Maximum concurrent child agents
        MAX_DEPTH: Maximum nesting depth for child agents
    """

    MAX_CHILDREN = 4
    MAX_DEPTH = 5

    def __init__(
        self,
        subagent_manager: SubagentManager,
        session_id: str = "",
        mode_selector: Any = None,
        context_manager: Any = None,
        permission_manager: Any = None,
        depth: int = 0,
    ) -> None:
        """Initialize the collaboration engine.

        Args:
            subagent_manager: Manager for spawning and tracking subagents
            session_id: Current session identifier
            mode_selector: Optional mode selector for automatic suggestions
            context_manager: Optional context manager for shared state
            permission_manager: Optional permission manager for tool filtering
            depth: Current nesting depth (0 for root engine)
        """
        self._subagent_manager = subagent_manager
        self._session_id = session_id
        self._mode_selector = mode_selector
        self._context_manager = context_manager
        self._permission_manager = permission_manager
        self._depth = depth  # Current nesting depth

        self._active_mode: CollaborationModeType | None = None
        self._modes: dict[CollaborationModeType, CollaborationMode] = {}
        self._sessions: dict[str, CollaborationSession] = {}

    @property
    def active_mode(self) -> CollaborationModeType | None:
        """Get the currently active collaboration mode."""
        return self._active_mode

    @property
    def session_id(self) -> str:
        """Get the current session identifier."""
        return self._session_id

    @property
    def depth(self) -> int:
        """Get the current nesting depth."""
        return self._depth

    def register_mode(self, mode_type: CollaborationModeType, mode_impl: CollaborationMode) -> None:
        """Register a collaboration mode implementation.

        Args:
            mode_type: The mode type enum value
            mode_impl: The mode implementation instance
        """
        self._modes[mode_type] = mode_impl

    def switch_mode(
        self,
        mode: CollaborationModeType,
        trigger: str = "explicit",
        context: dict[str, Any] | None = None,
    ) -> ModeSwitchResult:
        """Switch to a different collaboration mode.

        Args:
            mode: The target collaboration mode
            trigger: How the switch was initiated (explicit/suggested/auto)
            context: Optional context for the mode switch

        Returns:
            ModeSwitchResult indicating success or failure
        """
        if mode not in self._modes:
            return ModeSwitchResult(
                success=False,
                message=f"Unknown mode: {mode}",
            )

        self._active_mode = mode
        return ModeSwitchResult(
            success=True,
            mode=mode,
            message=f"Switched to {mode.value} mode",
        )

    def suggest_mode(self, task_description: str) -> list[ModeSuggestion]:
        """Suggest appropriate collaboration modes based on task description.

        Args:
            task_description: Description of the task to analyze

        Returns:
            List of mode suggestions with confidence scores
        """
        if self._mode_selector:
            return self._mode_selector.suggest(task_description)
        return []

    async def spawn_child(
        self,
        config: CustomAgentConfig | SubagentConfig,
        mode_type: CollaborationModeType | None = None,
    ) -> SpawnResult:
        """Spawn a child agent with the given configuration.

        Args:
            config: Agent configuration (CustomAgentConfig or SubagentConfig)
            mode_type: Optional mode type override

        Returns:
            SpawnResult with session ID and status

        Raises:
            ValueError: If the mode is unknown or not registered
        """
        if self._depth >= self.MAX_DEPTH:
            return SpawnResult(
                session_id="",
                status="failed",
            )

        effective_mode = mode_type or self._active_mode
        if not effective_mode:
            raise ValueError("No collaboration mode specified or active")

        mode = self._modes.get(effective_mode)
        if not mode:
            raise ValueError(f"Unknown mode: {effective_mode}")

        return await mode.spawn(config)

    async def kill_child(self, session_id: str) -> bool:
        """Terminate a child agent session.

        Args:
            session_id: The session ID of the child to terminate

        Returns:
            True if the child was successfully killed, False otherwise
        """
        return await self._subagent_manager.kill(session_id)

    async def steer_child(self, session_id: str, instruction: str) -> bool:
        """Send a steering instruction to a running child agent.

        Args:
            session_id: The session ID of the child agent
            instruction: The instruction to send

        Returns:
            True if the instruction was sent, False otherwise
        """
        return await self._subagent_manager.steer(session_id, instruction)

    def get_active_children(self) -> list[CollaborationSession]:
        """Get list of currently active child agent sessions.

        Returns:
            List of CollaborationSession objects with status "active"
        """
        return [s for s in self._sessions.values() if s.status == "active"]

    def get_session_state(self, session_id: str) -> CollaborationSession | None:
        """Get the state of a specific collaboration session.

        Args:
            session_id: The session ID to look up

        Returns:
            CollaborationSession if found, None otherwise
        """
        return self._sessions.get(session_id)
