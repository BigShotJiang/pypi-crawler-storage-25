"""Collaboration tools for multi-agent orchestration.

This module provides 6 tools for the collaboration system:
- spawn_child: Create a child agent
- mode_switch: Switch collaboration mode
- suggest_mode: Request mode suggestions
- steer_child: Send instruction to child agent
- kill_child: Terminate a child agent
- list_children: List child agents

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pyclaw.agents.collaboration.types import (
    CollaborationModeType,
    CustomAgentConfig,
)
from pyclaw.agents.subagents.types import SubagentConfig
from pyclaw.agents.tools.base import BaseTool
from pyclaw.agents.types import ToolResult

if TYPE_CHECKING:
    from pyclaw.agents.collaboration.engine import CollaborationEngine


class SpawnChildTool(BaseTool):
    """Tool to spawn a child agent with specified configuration.

    Creates a new child agent session for task delegation. Supports:
    - Predefined agent selection via agent_id
    - Custom prompts and system prompts
    - Collaboration mode specification
    - Fork count for parallel execution (Fork/Swarm mode)
    """

    def __init__(self, *, engine: CollaborationEngine) -> None:
        """Initialize the spawn_child tool.

        Args:
            engine: The collaboration engine to use for spawning.
        """
        self._engine = engine

    @property
    def name(self) -> str:
        return "spawn_child"

    @property
    def description(self) -> str:
        return (
            "Spawn a child agent to perform a subtask. The child agent runs "
            "independently and can be managed with steer_child and kill_child tools."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "agent_id": {
                    "type": "string",
                    "description": "ID of a predefined agent to use (optional, uses default if not specified).",
                },
                "prompt": {
                    "type": "string",
                    "description": "The task prompt for the child agent.",
                },
                "mode": {
                    "type": "string",
                    "description": "Collaboration mode override (custom_agent, dynamic_decompose, fork_swarm, coordinator_worker).",
                    "enum": [m.value for m in CollaborationModeType],
                },
                "fork_count": {
                    "type": "integer",
                    "description": "Number of parallel children for fork_swarm mode (default: 1).",
                    "minimum": 1,
                    "maximum": 4,
                },
                "system_prompt": {
                    "type": "string",
                    "description": "Custom system prompt for the child agent (optional).",
                },
            },
            "required": ["prompt"],
        }

    async def execute(self, tool_call_id: str, arguments: dict[str, Any]) -> ToolResult:
        prompt = arguments.get("prompt", "")
        if not prompt:
            return ToolResult.text("Error: prompt is required.", is_error=True)

        agent_id = arguments.get("agent_id")
        mode_str = arguments.get("mode")
        system_prompt = arguments.get("system_prompt")

        # Parse mode if provided
        mode_type: CollaborationModeType | None = None
        if mode_str:
            try:
                mode_type = CollaborationModeType(mode_str)
            except ValueError:
                valid_modes = [m.value for m in CollaborationModeType]
                return ToolResult.text(
                    f"Error: Invalid mode '{mode_str}'. Valid modes: {valid_modes}",
                    is_error=True,
                )

        # Build configuration
        if agent_id:
            config: CustomAgentConfig | SubagentConfig = CustomAgentConfig(
                agent_id=agent_id,
                name=agent_id,
                system_prompt=system_prompt,
            )
        else:
            config = SubagentConfig(
                prompt=prompt,
                system_prompt=system_prompt,
            )

        try:
            result = await self._engine.spawn_child(config, mode_type)

            if result.status == "failed":
                return ToolResult.text(
                    f"Failed to spawn child agent: {result.session_id or 'max depth exceeded'}",
                    is_error=True,
                )

            # Build response message
            lines = ["Child agent spawned successfully."]
            lines.append(f"  Session ID: {result.session_id}")
            lines.append(f"  Status: {result.status}")

            if result.children:
                lines.append(f"  Children: {len(result.children)} parallel agents")
                for i, child_id in enumerate(result.children[:4]):
                    lines.append(f"    [{i + 1}] {child_id}")

            if result.child_context:
                lines.append("  Context: Provided to child agent")

            return ToolResult.text("\n".join(lines))

        except ValueError as e:
            return ToolResult.text(f"Error: {e}", is_error=True)
        except Exception as e:
            return ToolResult.text(f"Unexpected error: {e}", is_error=True)


class ModeSwitchTool(BaseTool):
    """Tool to switch the collaboration mode.

    Changes the active collaboration mode for the current session.
    Validates the mode and records the switch reason.
    """

    def __init__(self, *, engine: CollaborationEngine) -> None:
        """Initialize the mode_switch tool.

        Args:
            engine: The collaboration engine managing modes.
        """
        self._engine = engine

    @property
    def name(self) -> str:
        return "mode_switch"

    @property
    def description(self) -> str:
        return (
            "Switch to a different collaboration mode. "
            "Modes: custom_agent (predefined), dynamic_decompose (task breakdown), "
            "fork_swarm (parallel execution), coordinator_worker (complex orchestration)."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "mode": {
                    "type": "string",
                    "description": "Target collaboration mode.",
                    "enum": [m.value for m in CollaborationModeType],
                },
                "reason": {
                    "type": "string",
                    "description": "Reason for the mode switch (for logging and context).",
                },
            },
            "required": ["mode"],
        }

    async def execute(self, tool_call_id: str, arguments: dict[str, Any]) -> ToolResult:
        mode_str = arguments.get("mode", "")
        reason = arguments.get("reason", "")

        if not mode_str:
            return ToolResult.text("Error: mode is required.", is_error=True)

        # Validate mode
        try:
            mode = CollaborationModeType(mode_str)
        except ValueError:
            valid_modes = [m.value for m in CollaborationModeType]
            return ToolResult.text(
                f"Error: Invalid mode '{mode_str}'. Valid modes: {valid_modes}",
                is_error=True,
            )

        # Switch mode
        result = self._engine.switch_mode(mode)

        if not result.success:
            return ToolResult.text(f"Failed to switch mode: {result.message}", is_error=True)

        # Build response
        lines = [f"Switched to {mode.value} mode."]
        if reason:
            lines.append(f"  Reason: {reason}")
        if result.message:
            lines.append(f"  Status: {result.message}")

        return ToolResult.text("\n".join(lines))


class SuggestModeTool(BaseTool):
    """Tool to request collaboration mode suggestions.

    Analyzes the task description and returns suggested modes
    with confidence scores and reasoning.
    """

    def __init__(self, *, engine: CollaborationEngine) -> None:
        """Initialize the suggest_mode tool.

        Args:
            engine: The collaboration engine with mode selector.
        """
        self._engine = engine

    @property
    def name(self) -> str:
        return "suggest_mode"

    @property
    def description(self) -> str:
        return (
            "Analyze a task description and get suggestions for the most appropriate "
            "collaboration mode. Returns ranked suggestions with confidence scores."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_description": {
                    "type": "string",
                    "description": "Description of the task to analyze for mode suggestions.",
                },
            },
            "required": ["task_description"],
        }

    async def execute(self, tool_call_id: str, arguments: dict[str, Any]) -> ToolResult:
        task_description = arguments.get("task_description", "")

        if not task_description:
            return ToolResult.text("Error: task_description is required.", is_error=True)

        suggestions = self._engine.suggest_mode(task_description)

        if not suggestions:
            return ToolResult.text("No mode suggestions available. Consider using 'custom_agent' mode.")

        # Build response
        lines = ["Mode suggestions (ranked by confidence):"]
        lines.append("")

        for i, suggestion in enumerate(suggestions, 1):
            confidence_pct = int(suggestion.confidence * 100)
            lines.append(f"{i}. {suggestion.mode.value} ({confidence_pct}% confidence)")
            lines.append(f"   Reason: {suggestion.reason}")
            if suggestion.requires_confirmation:
                lines.append("   Note: Requires user confirmation")
            lines.append("")

        best = suggestions[0]
        lines.append(f"Recommendation: Use '{best.mode.value}' mode")

        return ToolResult.text("\n".join(lines))


class SteerChildTool(BaseTool):
    """Tool to send steering instructions to a running child agent.

    Allows the parent agent to guide or redirect a child agent's
    execution without terminating it.
    """

    def __init__(self, *, engine: CollaborationEngine) -> None:
        """Initialize the steer_child tool.

        Args:
            engine: The collaboration engine managing child agents.
        """
        self._engine = engine

    @property
    def name(self) -> str:
        return "steer_child"

    @property
    def description(self) -> str:
        return (
            "Send a steering instruction to a running child agent. "
            "Useful for redirecting or guiding the child agent's work."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Session ID of the child agent to steer.",
                },
                "instruction": {
                    "type": "string",
                    "description": "The steering instruction to send to the child agent.",
                },
            },
            "required": ["session_id", "instruction"],
        }

    async def execute(self, tool_call_id: str, arguments: dict[str, Any]) -> ToolResult:
        session_id = arguments.get("session_id", "")
        instruction = arguments.get("instruction", "")

        if not session_id:
            return ToolResult.text("Error: session_id is required.", is_error=True)

        if not instruction:
            return ToolResult.text("Error: instruction is required.", is_error=True)

        # Verify session exists
        session = self._engine.get_session_state(session_id)
        if not session:
            return ToolResult.text(
                f"Error: Session '{session_id}' not found.",
                is_error=True,
            )

        # Send steering instruction
        success = await self._engine.steer_child(session_id, instruction)

        if success:
            return ToolResult.text(
                f"Steering instruction sent to child agent.\n"
                f"  Session: {session_id}\n"
                f"  Instruction: {instruction[:100]}{'...' if len(instruction) > 100 else ''}"
            )
        else:
            return ToolResult.text(
                f"Failed to steer child agent. The session may not be in a running state.\n  Session: {session_id}",
                is_error=True,
            )


class KillChildTool(BaseTool):
    """Tool to terminate a child agent session.

    Aborts a running child agent. Use with caution as any
    in-progress work will be lost.
    """

    def __init__(self, *, engine: CollaborationEngine) -> None:
        """Initialize the kill_child tool.

        Args:
            engine: The collaboration engine managing child agents.
        """
        self._engine = engine

    @property
    def name(self) -> str:
        return "kill_child"

    @property
    def description(self) -> str:
        return "Terminate a running child agent session. WARNING: Any in-progress work will be lost."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Session ID of the child agent to terminate.",
                },
            },
            "required": ["session_id"],
        }

    async def execute(self, tool_call_id: str, arguments: dict[str, Any]) -> ToolResult:
        session_id = arguments.get("session_id", "")

        if not session_id:
            return ToolResult.text("Error: session_id is required.", is_error=True)

        # Verify session exists
        session = self._engine.get_session_state(session_id)
        if not session:
            return ToolResult.text(
                f"Error: Session '{session_id}' not found.",
                is_error=True,
            )

        # Kill the child
        success = await self._engine.kill_child(session_id)

        if success:
            return ToolResult.text(f"Child agent terminated.\n  Session: {session_id}\n  Status: aborted")
        else:
            return ToolResult.text(
                f"Failed to terminate child agent.\n  Session: {session_id}",
                is_error=True,
            )


class ListChildrenTool(BaseTool):
    """Tool to list child agent sessions.

    Shows active child agents and optionally completed ones.
    """

    def __init__(self, *, engine: CollaborationEngine) -> None:
        """Initialize the list_children tool.

        Args:
            engine: The collaboration engine managing child agents.
        """
        self._engine = engine

    @property
    def name(self) -> str:
        return "list_children"

    @property
    def description(self) -> str:
        return (
            "List child agent sessions. Shows active children by default. "
            "Set include_completed=true to also show recently completed sessions."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "include_completed": {
                    "type": "boolean",
                    "description": "Include completed/aborted sessions in the list.",
                },
            },
        }

    async def execute(self, tool_call_id: str, arguments: dict[str, Any]) -> ToolResult:
        include_completed = arguments.get("include_completed", False)

        # Get active children
        active_children = self._engine.get_active_children()

        # Build response
        lines = []

        if active_children:
            lines.append(f"Active child agents ({len(active_children)}):")
            for child in active_children:
                lines.append(f"  [{child.status}] {child.session_id}")
                if child.active_mode:
                    lines.append(f"    Mode: {child.active_mode.value}")
                if child.child_agents:
                    lines.append(f"    Sub-children: {len(child.child_agents)}")
        else:
            lines.append("No active child agents.")

        if include_completed:
            # Get all sessions (including non-active)
            all_sessions = list(self._engine._sessions.values())
            completed = [s for s in all_sessions if s.status != "active"]

            if completed:
                lines.append("")
                lines.append(f"Completed/other sessions ({len(completed)}):")
                for session in completed[:10]:  # Limit to 10
                    lines.append(f"  [{session.status}] {session.session_id}")
            else:
                lines.append("")
                lines.append("No completed sessions to display.")

        return ToolResult.text("\n".join(lines))


def get_collaboration_tools(engine: CollaborationEngine) -> list[BaseTool]:
    """Get all collaboration tools for the given engine.

    Args:
        engine: The collaboration engine instance.

    Returns:
        List of collaboration tool instances.
    """
    return [
        SpawnChildTool(engine=engine),
        ModeSwitchTool(engine=engine),
        SuggestModeTool(engine=engine),
        SteerChildTool(engine=engine),
        KillChildTool(engine=engine),
        ListChildrenTool(engine=engine),
    ]
