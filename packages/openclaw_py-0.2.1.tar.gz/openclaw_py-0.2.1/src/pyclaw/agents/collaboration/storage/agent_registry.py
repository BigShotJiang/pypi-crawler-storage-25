"""Custom Agent Registry for loading and managing agent configurations.

This module provides:
- CustomAgentRegistry: Registry for loading, storing, and querying agent configs
- IncompatibleSchemaError: Exception for schema version mismatches
- LoadError: Dataclass for tracking load errors

The registry supports loading agent configurations from:
- YAML files in ~/.pyclaw/agents/ (default)
- Markdown files with YAML frontmatter in .claude/agents/ (default)
- Manual registration via API

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 5
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from pyclaw.agents.collaboration.types import (
    SUPPORTED_SCHEMA_VERSIONS,
    CustomAgentConfig,
    MemoryScope,
    TrustLevel,
)


class IncompatibleSchemaError(Exception):
    """Raised when a configuration has an incompatible schema version.

    Attributes:
        version: The incompatible version found
        supported: List of supported versions
    """

    def __init__(self, version: str, supported: list[str]) -> None:
        """Initialize the error.

        Args:
            version: The incompatible schema version
            supported: List of supported schema versions
        """
        self.version = version
        self.supported = supported
        super().__init__(f"Incompatible schema version {version}. Supported versions: {', '.join(supported)}")


@dataclass
class LoadError:
    """Represents an error that occurred during agent configuration loading.

    Attributes:
        path: Path to the file that caused the error
        error: The exception that was raised
        message: Human-readable error message
    """

    path: str
    error: Exception
    message: str = field(default_factory=str)

    def __post_init__(self) -> None:
        """Set default message if not provided."""
        if not self.message:
            self.message = str(self.error)


class CustomAgentRegistry:
    """Registry for custom agent configurations.

    Loads agent configurations from YAML files and provides query/update operations.
    Supports schema version compatibility checking and aggregates load errors.

    Default paths:
        - YAML configs: ~/.pyclaw/agents/
        - Markdown configs: .claude/agents/

    Example:
        >>> registry = CustomAgentRegistry()
        >>> config = registry.get("researcher")
        >>> if config:
        ...     print(f"Found agent: {config.name}")
        >>> for agent in registry.list_all():
        ...     print(f"- {agent.agent_id}: {agent.name}")
    """

    def __init__(
        self,
        yaml_dirs: list[Path] | None = None,
        markdown_dirs: list[Path] | None = None,
    ) -> None:
        """Initialize the registry and scan for agent configurations.

        Args:
            yaml_dirs: Custom YAML directories to scan (overrides default)
            markdown_dirs: Custom Markdown directories to scan (overrides default)
        """
        # Use custom dirs or compute defaults lazily
        if yaml_dirs is not None:
            self._yaml_dirs: list[Path] = yaml_dirs
        else:
            self._yaml_dirs = [Path.home() / ".pyclaw" / "agents"]

        if markdown_dirs is not None:
            self._markdown_dirs: list[Path] = markdown_dirs
        else:
            self._markdown_dirs = [Path(".claude") / "agents"]

        # Internal storage
        self._agents: dict[str, CustomAgentConfig] = {}
        self._load_errors: list[LoadError] = []

        # Scan all sources on init
        self._scan_all_sources()

    def _scan_all_sources(self) -> None:
        """Scan all configured sources for agent configurations."""
        # Clear previous state
        self._agents.clear()
        self._load_errors.clear()

        # Scan YAML directories
        for yaml_dir in self._yaml_dirs:
            self._scan_yaml_dir(yaml_dir)

        # Scan Markdown directories
        for md_dir in self._markdown_dirs:
            self._scan_markdown_dir(md_dir)

    def _scan_yaml_dir(self, directory: Path) -> None:
        """Scan a directory for YAML agent configuration files.

        Args:
            directory: Directory path to scan
        """
        if not directory.exists():
            return

        for file_path in directory.iterdir():
            if not file_path.is_file():
                continue
            if file_path.suffix.lower() not in (".yaml", ".yml"):
                continue

            self._load_yaml_agent(file_path)

    def _load_yaml_agent(self, path: Path) -> None:
        """Load an agent configuration from a YAML file.

        Args:
            path: Path to the YAML file
        """
        try:
            with open(path, encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not isinstance(data, dict):
                raise ValueError(f"Invalid YAML structure: expected dict, got {type(data).__name__}")

            # Check schema version compatibility
            schema_version = data.get("schema_version", "1.0")
            if schema_version not in SUPPORTED_SCHEMA_VERSIONS:
                raise IncompatibleSchemaError(schema_version, SUPPORTED_SCHEMA_VERSIONS)

            # Add source metadata
            data["source"] = "yaml"
            data["source_path"] = str(path)

            # Create and store the config
            config = CustomAgentConfig.model_validate(data)
            self._agents[config.agent_id] = config

        except Exception as e:
            self._load_errors.append(LoadError(path=str(path), error=e))

    def _scan_markdown_dir(self, directory: Path) -> None:
        """Scan a directory for Markdown agent configuration files.

        Loads agent configurations from Markdown files with YAML frontmatter.
        Supports .md and .markdown extensions.

        Args:
            directory: Directory path to scan
        """
        if not directory.exists():
            return

        for file_path in directory.iterdir():
            if not file_path.is_file():
                continue
            if file_path.suffix.lower() not in (".md", ".markdown"):
                continue

            self._load_markdown_agent(file_path)

    def _load_markdown_agent(self, path: Path) -> None:
        """Load an agent configuration from a Markdown file with YAML frontmatter.

        Parses Markdown files with YAML frontmatter (enclosed by --- delimiters).
        The frontmatter contains agent configuration fields, and content after
        the frontmatter becomes the system_prompt.

        Expected format:
            ---
            agent_id: planner
            name: Planner
            tools: [read, search, plan]
            trust_level: 75
            memory_scope: project
            tags: [planning, architecture]
            ---

            You are a planning agent specialized in breaking down complex tasks.

        Args:
            path: Path to the Markdown file
        """
        try:
            content = path.read_text(encoding="utf-8")

            # Parse frontmatter
            frontmatter, body = self._parse_frontmatter(content)

            if frontmatter is None:
                # No valid frontmatter - skip this file
                return

            # Build config dict from frontmatter
            data = self._map_frontmatter_to_config(frontmatter, body, path)

            # Add source metadata
            data["source"] = "markdown"
            data["source_path"] = str(path)

            # Create and store the config
            config = CustomAgentConfig.model_validate(data)
            self._agents[config.agent_id] = config

        except Exception as e:
            self._load_errors.append(LoadError(path=str(path), error=e))

    def _parse_frontmatter(self, content: str) -> tuple[dict | None, str]:
        """Parse YAML frontmatter from Markdown content.

        Frontmatter is expected to be at the start of the file, enclosed by
        --- delimiters. Returns (frontmatter_dict, body_content).

        Args:
            content: Full Markdown file content

        Returns:
            Tuple of (frontmatter dict or None, body string)
        """
        # Match frontmatter pattern: ---\n...\n---
        pattern = r"^---\s*\n(.*?)\n---\s*\n?(.*)$"
        match = re.match(pattern, content, re.DOTALL)

        if not match:
            return None, content

        frontmatter_yaml = match.group(1)
        body = match.group(2).strip()

        try:
            frontmatter = yaml.safe_load(frontmatter_yaml)
            if not isinstance(frontmatter, dict):
                return None, content
            return frontmatter, body
        except yaml.YAMLError:
            return None, content

    def _map_frontmatter_to_config(self, frontmatter: dict, body: str, path: Path) -> dict:
        """Map frontmatter fields to CustomAgentConfig fields.

        Performs field transformations:
        - tools -> tools_enabled
        - trust_level (int) -> TrustLevel enum
        - memory_scope (str) -> MemoryScope enum
        - body -> system_prompt

        Args:
            frontmatter: Parsed YAML frontmatter dict
            body: Markdown body content
            path: Source file path (for deriving agent_id if missing)

        Returns:
            Dict ready for CustomAgentConfig validation
        """
        data = dict(frontmatter)

        # Derive agent_id from filename if not specified
        if "agent_id" not in data:
            data["agent_id"] = path.stem

        # Map 'tools' to 'tools_enabled'
        if "tools" in data:
            data["tools_enabled"] = data.pop("tools")

        # Convert trust_level int to TrustLevel enum
        if "trust_level" in data:
            trust_value = data["trust_level"]
            if isinstance(trust_value, int):
                # Map int value to closest TrustLevel
                data["trust_level"] = self._int_to_trust_level(trust_value)
            elif isinstance(trust_value, str):
                # Handle string values like "standard", "full"
                data["trust_level"] = self._str_to_trust_level(trust_value)

        # Convert memory_scope string to MemoryScope enum
        if "memory_scope" in data:
            scope = data["memory_scope"]
            if isinstance(scope, str):
                data["memory_scope"] = MemoryScope(scope.lower())

        # Use body content as system_prompt if present
        if body:
            data["system_prompt"] = body

        return data

    def _int_to_trust_level(self, value: int) -> TrustLevel:
        """Convert integer trust value to TrustLevel enum.

        Maps numeric values to the closest defined TrustLevel:
        - 100: FULL
        - 75: STANDARD
        - 50: RESTRICTED
        - 25: SANDBOX

        Args:
            value: Integer trust value (typically 25, 50, 75, or 100)

        Returns:
            Corresponding TrustLevel enum value
        """
        trust_map = {
            100: TrustLevel.FULL,
            75: TrustLevel.STANDARD,
            50: TrustLevel.RESTRICTED,
            25: TrustLevel.SANDBOX,
        }

        if value in trust_map:
            return trust_map[value]

        # Find closest match for non-standard values
        if value >= 88:
            return TrustLevel.FULL
        elif value >= 63:
            return TrustLevel.STANDARD
        elif value >= 38:
            return TrustLevel.RESTRICTED
        else:
            return TrustLevel.SANDBOX

    def _str_to_trust_level(self, value: str) -> TrustLevel:
        """Convert string trust level to TrustLevel enum.

        Args:
            value: String trust level (e.g., "full", "standard", "restricted", "sandbox")

        Returns:
            Corresponding TrustLevel enum value
        """
        value_lower = value.lower()
        str_map = {
            "full": TrustLevel.FULL,
            "standard": TrustLevel.STANDARD,
            "restricted": TrustLevel.RESTRICTED,
            "sandbox": TrustLevel.SANDBOX,
        }
        return str_map.get(value_lower, TrustLevel.STANDARD)

    def get(self, agent_id: str) -> CustomAgentConfig | None:
        """Get an agent configuration by ID.

        Args:
            agent_id: The unique identifier of the agent

        Returns:
            CustomAgentConfig if found, None otherwise
        """
        return self._agents.get(agent_id)

    def list_all(self) -> list[CustomAgentConfig]:
        """List all registered agent configurations.

        Returns:
            List of all registered CustomAgentConfig objects
        """
        return list(self._agents.values())

    def register(self, config: CustomAgentConfig) -> None:
        """Register a new agent configuration.

        Validates schema version before registration.

        Args:
            config: The agent configuration to register

        Raises:
            IncompatibleSchemaError: If the schema version is not supported
        """
        # Validate schema version
        if config.schema_version not in SUPPORTED_SCHEMA_VERSIONS:
            raise IncompatibleSchemaError(config.schema_version, SUPPORTED_SCHEMA_VERSIONS)

        self._agents[config.agent_id] = config

    def unregister(self, agent_id: str) -> bool:
        """Unregister an agent configuration.

        Args:
            agent_id: The ID of the agent to unregister

        Returns:
            True if the agent was unregistered, False if not found
        """
        if agent_id in self._agents:
            del self._agents[agent_id]
            return True
        return False

    def list_keys(self) -> list[str]:
        """List all registered agent IDs.

        Returns:
            List of agent ID strings.
        """
        return list(self._agents.keys())

    def clear(self) -> None:
        """Clear all registered agents and load errors."""
        self._agents.clear()
        self._load_errors.clear()

    def get_load_errors(self) -> list[LoadError]:
        """Get all errors that occurred during loading.

        Returns:
            List of LoadError objects
        """
        return list(self._load_errors)

    def reload(self) -> None:
        """Reload all agent configurations from sources.

        Clears all cached agents and errors, then rescans all directories.
        """
        self._scan_all_sources()

    def __contains__(self, agent_id: str) -> bool:
        """Check if an agent is registered."""
        return agent_id in self._agents

    def __len__(self) -> int:
        """Return the number of registered agents."""
        return len(self._agents)
