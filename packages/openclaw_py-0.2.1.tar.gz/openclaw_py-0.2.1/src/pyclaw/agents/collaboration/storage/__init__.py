"""Storage backends for collaboration state.

This package contains:
- agent_registry: CustomAgentRegistry for loading and managing agent configs
- session_state: Persistence for collaboration session state
"""

from pyclaw.agents.collaboration.storage.agent_registry import (
    CustomAgentRegistry,
    IncompatibleSchemaError,
    LoadError,
)

__all__ = [
    "CustomAgentRegistry",
    "IncompatibleSchemaError",
    "LoadError",
]
