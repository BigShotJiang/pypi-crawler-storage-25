"""Tool permission management for multi-agent collaboration.

This module provides the ToolPermissionManager class which handles:
- Tool filtering based on trust levels
- Dynamic authorization for sensitive operations
- Permission policies for child agents

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md Section 4.5
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field

from pyclaw.agents.collaboration.types import CustomAgentConfig, TrustLevel

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    pass


# ============================================================================
# Constants
# ============================================================================

SENSITIVE_TOOLS: dict[str, dict[str, str]] = {
    "exec": {"risk": "high", "description": "Execute Shell commands"},
    "shell": {"risk": "high", "description": "Shell command execution"},
    "file_write": {"risk": "medium", "description": "Write to file"},
    "file_delete": {"risk": "high", "description": "Delete file"},
    "patch": {"risk": "medium", "description": "Patch file"},
    "bash": {"risk": "high", "description": "Execute Bash commands"},
    "write_file": {"risk": "medium", "description": "Write to file"},
    "edit_file": {"risk": "medium", "description": "Edit file"},
}

SAFE_TOOLS: set[str] = {
    "read",
    "search",
    "web_fetch",
    "web_search",
    "list",
    "glob",
    "grep",
    "head",
    "ls",
    "cat",
}


class RiskLevel(str, Enum):
    """Risk level for tools."""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


# ============================================================================
# Authorization Models
# ============================================================================


class AuthorizationStatus(str, Enum):
    """Status of authorization request."""

    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"


class AuthorizationRequest(BaseModel):
    """Request for tool usage authorization.

    When a sensitive tool is invoked by a child agent, this request
    is sent to the parent agent or user for approval.

    Attributes:
        request_id: Unique identifier for this request
        session_id: Child agent session ID
        tool_name: Name of the tool being invoked
        arguments: Arguments passed to the tool
        risk_level: Risk level of the tool
        description: Human-readable description
        created_at: Timestamp when request was created
        status: Current status of the request
        reason: Optional reason for the tool call
    """

    request_id: str = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description="Unique identifier for this request",
    )
    session_id: str = Field(..., description="Child agent session ID")
    tool_name: str = Field(..., description="Name of the tool being invoked")
    arguments: dict[str, Any] = Field(
        default_factory=dict,
        description="Arguments passed to the tool",
    )
    risk_level: str = Field(..., description="Risk level of the tool")
    description: str = Field(default="", description="Human-readable description")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Timestamp when request was created",
    )
    status: AuthorizationStatus = Field(
        default=AuthorizationStatus.PENDING,
        description="Current status of the request",
    )
    reason: str | None = Field(default=None, description="Optional reason for the tool call")


class AuthorizationResponse(BaseModel):
    """Response to an authorization request.

    Returned by the authorization handler (parent agent or user)
    indicating whether the tool use is permitted.

    Attributes:
        request_id: ID of the original request
        status: Approval status
        reason: Optional reason for the decision
        approved_by: Identifier of who approved (user/agent)
        modified_arguments: Optionally modified arguments (for safety)
    """

    request_id: str = Field(..., description="ID of the original request")
    status: AuthorizationStatus = Field(..., description="Approval status")
    reason: str | None = Field(default=None, description="Reason for the decision")
    approved_by: str | None = Field(default=None, description="Who approved (user/agent)")
    modified_arguments: dict[str, Any] | None = Field(
        default=None,
        description="Optionally modified arguments for safety",
    )


# ============================================================================
# Tool Definition
# ============================================================================


@dataclass
class AgentTool:
    """Represents a tool available to an agent.

    Attributes:
        name: Tool name
        description: Human-readable description
        parameters: Tool parameter schema (JSON Schema)
        handler: Optional callable for tool execution
    """

    name: str
    description: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)
    handler: Any = None


# ============================================================================
# Tool Permission Manager
# ============================================================================


class ToolPermissionManager:
    """Manages tool permissions for child agents.

    This class implements the tool permission strategy defined in the
    multi-agent collaboration design:

    - Filters tools based on trust level (FULL/STANDARD/RESTRICTED/SANDBOX)
    - Enforces whitelist/blacklist from CustomAgentConfig
    - Manages authorization for sensitive tools
    - Provides approval workflow for high-risk operations

    Example:
        >>> manager = ToolPermissionManager()
        >>> tools = [AgentTool("read"), AgentTool("exec")]
        >>> config = CustomAgentConfig(trust_level=TrustLevel.SANDBOX)
        >>> filtered = manager.filter_tools(tools, config)
        >>> [t.name for t in filtered]
        ['read']
    """

    def __init__(
        self,
        authorization_handler: Any = None,
    ) -> None:
        """Initialize the permission manager.

        Args:
            authorization_handler: Optional handler for authorization requests.
                Should be a callable that takes AuthorizationRequest and returns
                AuthorizationResponse.
        """
        self._pending_requests: dict[str, AuthorizationRequest] = {}
        self._authorization_handler = authorization_handler

    def filter_tools(
        self,
        tools: list[AgentTool],
        config: CustomAgentConfig,
    ) -> list[AgentTool]:
        """Filter tools based on configuration and trust level.

        Applies filtering in the following order:
        1. Apply trust level restrictions
        2. Apply whitelist (tools_enabled) if specified
        3. Apply blacklist (tools_disabled) if specified

        Args:
            tools: List of available tools
            config: Agent configuration with permission settings

        Returns:
            Filtered list of tools that the agent is allowed to use
        """
        filtered = list(tools)

        # Step 1: Apply trust level restrictions
        filtered = self._apply_trust_level(filtered, config.trust_level)

        # Step 2: Apply whitelist if specified
        if config.tools_enabled is not None:
            allowed_names = set(config.tools_enabled)
            filtered = [t for t in filtered if t.name in allowed_names]

        # Step 3: Apply blacklist if specified
        if config.tools_disabled is not None:
            disabled_names = set(config.tools_disabled)
            filtered = [t for t in filtered if t.name not in disabled_names]

        return filtered

    def _apply_trust_level(
        self,
        tools: list[AgentTool],
        level: TrustLevel,
    ) -> list[AgentTool]:
        """Apply trust level filtering to tools.

        Trust Level Policies:
        - FULL (100): All tools available, no authorization required
        - STANDARD (75): All tools, sensitive operations need authorization
        - RESTRICTED (50): Remove high-risk tools
        - SANDBOX (25): Only read-only safe tools

        Args:
            tools: List of tools to filter
            level: Trust level to apply

        Returns:
            Filtered list of tools based on trust level
        """
        if level == TrustLevel.FULL:
            # All tools available
            return list(tools)

        if level == TrustLevel.STANDARD:
            # All tools available, but sensitive ones need authorization
            return list(tools)

        if level == TrustLevel.RESTRICTED:
            # Remove high-risk tools
            return [t for t in tools if not self._is_high_risk_tool(t.name)]

        # SANDBOX: Only safe tools
        return [t for t in tools if t.name in SAFE_TOOLS]

    def _is_high_risk_tool(self, tool_name: str) -> bool:
        """Check if a tool is high-risk.

        Args:
            tool_name: Name of the tool

        Returns:
            True if the tool is high-risk
        """
        tool_info = SENSITIVE_TOOLS.get(tool_name, {})
        return tool_info.get("risk") == "high"

    def _get_tool_risk_level(self, tool_name: str) -> RiskLevel:
        """Get the risk level for a tool.

        Args:
            tool_name: Name of the tool

        Returns:
            Risk level of the tool
        """
        tool_info = SENSITIVE_TOOLS.get(tool_name, {})
        risk = tool_info.get("risk", "low")
        try:
            return RiskLevel(risk)
        except ValueError:
            return RiskLevel.LOW

    def requires_authorization(self, tool_name: str) -> bool:
        """Check if a tool requires authorization.

        A tool requires authorization if:
        1. It is in the SENSITIVE_TOOLS list
        2. It has medium or high risk level

        Args:
            tool_name: Name of the tool

        Returns:
            True if the tool requires authorization
        """
        return tool_name in SENSITIVE_TOOLS

    async def request_authorization(
        self,
        session_id: str,
        tool_name: str,
        arguments: dict[str, Any],
        reason: str | None = None,
    ) -> AuthorizationResponse:
        """Request authorization for tool usage.

        Creates an authorization request and either:
        1. Uses the registered handler to get approval
        2. Returns a pending response (caller must poll)

        Args:
            session_id: Child agent session ID
            tool_name: Name of the tool to invoke
            arguments: Arguments for the tool
            reason: Optional reason for the tool call

        Returns:
            Authorization response indicating approval status

        Raises:
            ValueError: If tool is not in SENSITIVE_TOOLS
        """
        if tool_name not in SENSITIVE_TOOLS:
            raise ValueError(f"Tool '{tool_name}' does not require authorization")

        tool_info = SENSITIVE_TOOLS[tool_name]
        request = AuthorizationRequest(
            session_id=session_id,
            tool_name=tool_name,
            arguments=arguments,
            risk_level=tool_info.get("risk", "unknown"),
            description=tool_info.get("description", ""),
            reason=reason,
        )

        # Store pending request
        self._pending_requests[request.request_id] = request

        # Use handler if available
        if self._authorization_handler is not None:
            try:
                response = await self._authorization_handler(request)
                request.status = response.status
                return response
            except Exception as e:
                logger.warning(f"Authorization handler failed: {e}")
                # Return pending - caller must check status later

        # Return pending response - caller must check status later
        return AuthorizationResponse(
            request_id=request.request_id,
            status=AuthorizationStatus.PENDING,
            reason="Authorization pending - awaiting approval",
        )

    def get_pending_requests(self) -> list[AuthorizationRequest]:
        """Get all pending authorization requests.

        Returns:
            List of requests with PENDING status
        """
        return [r for r in self._pending_requests.values() if r.status == AuthorizationStatus.PENDING]

    def get_request(self, request_id: str) -> AuthorizationRequest | None:
        """Get an authorization request by ID.

        Args:
            request_id: The request ID

        Returns:
            The request if found, None otherwise
        """
        return self._pending_requests.get(request_id)

    def respond_to_request(
        self,
        request_id: str,
        approved: bool,
        reason: str | None = None,
        approved_by: str | None = None,
        modified_arguments: dict[str, Any] | None = None,
    ) -> AuthorizationResponse | None:
        """Respond to a pending authorization request.

        Args:
            request_id: The request ID
            approved: Whether to approve the request
            reason: Optional reason for the decision
            approved_by: Who made the decision
            modified_arguments: Optionally modified arguments

        Returns:
            The response if request was found, None otherwise
        """
        request = self._pending_requests.get(request_id)
        if request is None:
            return None

        status = AuthorizationStatus.APPROVED if approved else AuthorizationStatus.DENIED
        request.status = status

        response = AuthorizationResponse(
            request_id=request_id,
            status=status,
            reason=reason,
            approved_by=approved_by,
            modified_arguments=modified_arguments,
        )

        return response

    def clear_completed_requests(self, max_age_seconds: int = 3600) -> int:
        """Clear completed requests from memory.

        Args:
            max_age_seconds: Maximum age for completed requests.
                Set to 0 to clear all completed requests immediately.

        Returns:
            Number of requests cleared
        """
        if max_age_seconds <= 0:
            # Clear all completed requests immediately
            to_remove = [
                rid for rid, req in self._pending_requests.items() if req.status != AuthorizationStatus.PENDING
            ]
        else:
            now = datetime.now(timezone.utc)
            to_remove = []
            for rid, req in self._pending_requests.items():
                if req.status != AuthorizationStatus.PENDING:
                    age = (now - req.created_at).total_seconds()
                    if age >= max_age_seconds:
                        to_remove.append(rid)
        for rid in to_remove:
            del self._pending_requests[rid]
        return len(to_remove)

    def get_tool_description(self, tool_name: str) -> str:
        """Get the description for a tool.

        Args:
            tool_name: Name of the tool

        Returns:
            Tool description or empty string if not found
        """
        return SENSITIVE_TOOLS.get(tool_name, {}).get("description", "")

    def get_all_sensitive_tools(self) -> dict[str, dict[str, str]]:
        """Get all sensitive tool definitions.

        Returns:
            Dictionary of sensitive tool definitions
        """
        return dict(SENSITIVE_TOOLS)

    def get_safe_tools(self) -> set[str]:
        """Get all safe tool names.

        Returns:
            Set of safe tool names
        """
        return set(SAFE_TOOLS)
