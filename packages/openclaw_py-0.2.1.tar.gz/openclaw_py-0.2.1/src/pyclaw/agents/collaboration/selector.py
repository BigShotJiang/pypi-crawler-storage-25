"""Mode selector for collaboration patterns.

This module provides intelligent mode selection based on task descriptions,
using rule-based pattern matching to suggest appropriate collaboration modes.

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from typing import Protocol

from pyclaw.agents.collaboration.types import CollaborationModeType, ModeSuggestion


class SelectionRule(Protocol):
    """Protocol for selection rules.

    Each rule analyzes a task description and optionally returns a suggestion.
    """

    def match(self, task_description: str) -> ModeSuggestion | None:
        """Check if rule matches and return suggestion.

        Args:
            task_description: The task description to analyze

        Returns:
            ModeSuggestion if rule matches, None otherwise
        """
        ...


class BaseSelectionRule(ABC):
    """Base class for selection rules with common utilities."""

    mode: CollaborationModeType
    confidence: float
    reason: str
    requires_confirmation: bool = True

    @abstractmethod
    def match(self, task_description: str) -> ModeSuggestion | None:
        """Check if rule matches and return suggestion.

        Args:
            task_description: The task description to analyze

        Returns:
            ModeSuggestion if rule matches, None otherwise
        """
        ...

    def create_suggestion(self) -> ModeSuggestion:
        """Create a suggestion with this rule's parameters."""
        return ModeSuggestion(
            mode=self.mode,
            confidence=self.confidence,
            reason=self.reason,
            requires_confirmation=self.requires_confirmation,
        )


class RulePredefinedAgent(BaseSelectionRule):
    """Rule that detects explicit agent references.

    Triggers when user explicitly mentions using a specific predefined agent.
    Examples: "用 research agent", "使用 xxx agent", "use planner agent"
    """

    mode = CollaborationModeType.CUSTOM_AGENT
    confidence = 0.95
    reason = "Task explicitly references a predefined agent"
    requires_confirmation = False

    # Pattern to match "用/使用/use xxx agent" in Chinese and English
    AGENT_PATTERNS = [
        r"用\s+\w+\s+agent",  # Chinese: 用 xxx agent
        r"使用\s+\w+\s+agent",  # Chinese: 使用 xxx agent
        r"use\s+(?:the\s+)?\w+\s+agent",  # English: use xxx agent
        r"with\s+(?:the\s+)?\w+\s+agent",  # English: with xxx agent
        r"调用\s+\w+\s+agent",  # Chinese: 调用 xxx agent
    ]

    def match(self, task_description: str) -> ModeSuggestion | None:
        """Check for explicit agent references.

        Args:
            task_description: The task description to analyze

        Returns:
            ModeSuggestion if agent reference found, None otherwise
        """
        desc_lower = task_description.lower()
        for pattern in self.AGENT_PATTERNS:
            if re.search(pattern, desc_lower, re.IGNORECASE):
                return self.create_suggestion()
        return None


class RuleParallelIndicator(BaseSelectionRule):
    """Rule that detects parallel execution indicators.

    Triggers when user mentions parallel execution or simultaneous tasks.
    Keywords: "并行", "同时", "fork", "多个一起", "parallel", "concurrent"
    """

    mode = CollaborationModeType.FORK_SWARM
    confidence = 0.85
    reason = "Task indicates parallel execution requirements"
    requires_confirmation = True

    PARALLEL_KEYWORDS = [
        "并行",
        "同时",
        "fork",
        "多个一起",
        "parallel",
        "concurrent",
        "simultaneously",
        "同时执行",
        "并行处理",
        "一起处理",
        "并发",
    ]

    def match(self, task_description: str) -> ModeSuggestion | None:
        """Check for parallel execution indicators.

        Args:
            task_description: The task description to analyze

        Returns:
            ModeSuggestion if parallel indicators found, None otherwise
        """
        desc_lower = task_description.lower()
        for keyword in self.PARALLEL_KEYWORDS:
            if keyword.lower() in desc_lower:
                return self.create_suggestion()
        return None


class RuleDecompositionHint(BaseSelectionRule):
    """Rule that detects task decomposition indicators.

    Triggers when user mentions task decomposition or breaking down work.
    Keywords: "分解", "拆分", "步骤", "阶段", "decompose", "break down", "step"
    """

    mode = CollaborationModeType.DYNAMIC_DECOMPOSE
    confidence = 0.80
    reason = "Task indicates decomposition or multi-step requirements"
    requires_confirmation = True

    DECOMPOSITION_KEYWORDS = [
        "分解",
        "拆分",
        "步骤",
        "阶段",
        "decompose",
        "break down",
        "breakdown",
        "split",
        "divide",
        "step-by-step",
        "分步骤",
        "分阶段",
        "任务分解",
        "任务拆分",
    ]

    def match(self, task_description: str) -> ModeSuggestion | None:
        """Check for decomposition indicators.

        Args:
            task_description: The task description to analyze

        Returns:
            ModeSuggestion if decomposition indicators found, None otherwise
        """
        desc_lower = task_description.lower()
        for keyword in self.DECOMPOSITION_KEYWORDS:
            if keyword.lower() in desc_lower:
                return self.create_suggestion()
        return None


class RuleComplexityIndicator(BaseSelectionRule):
    """Rule that detects high complexity indicators.

    Triggers when task has multiple complexity indicators.
    Keywords: "复杂", "困难", "挑战", "大型", "架构", "重构", "端到端", "全栈",
              "complex", "difficult", "challenging", "large", "architecture", "refactor"
    """

    mode = CollaborationModeType.COORDINATOR_WORKER
    confidence = 0.75
    reason = "Task complexity suggests coordinator-worker pattern"
    requires_confirmation = True

    COMPLEXITY_KEYWORDS = [
        "复杂",
        "困难",
        "挑战",
        "大型",
        "架构",
        "重构",
        "端到端",
        "全栈",
        "complex",
        "difficult",
        "challenging",
        "large",
        "architecture",
        "refactor",
        "end-to-end",
        "full-stack",
        "fullstack",
        "high complexity",
        "complicated",
    ]

    MIN_KEYWORD_COUNT = 2  # Minimum keywords to trigger

    def match(self, task_description: str) -> ModeSuggestion | None:
        """Check for complexity indicators (requires at least MIN_KEYWORD_COUNT matches).

        Args:
            task_description: The task description to analyze

        Returns:
            ModeSuggestion if enough complexity indicators found, None otherwise
        """
        desc_lower = task_description.lower()
        keyword_count = sum(1 for kw in self.COMPLEXITY_KEYWORDS if kw.lower() in desc_lower)
        if keyword_count >= self.MIN_KEYWORD_COUNT:
            return self.create_suggestion()
        return None


class RuleDefault(BaseSelectionRule):
    """Default fallback rule when no other rules match.

    Returns CUSTOM_AGENT with low confidence.
    """

    mode = CollaborationModeType.CUSTOM_AGENT
    confidence = 0.30
    reason = "Default mode: Using predefined agent or single agent approach"
    requires_confirmation = True

    def match(self, task_description: str) -> ModeSuggestion | None:
        """Always returns a suggestion (fallback rule).

        This rule always matches as the default.

        Args:
            task_description: The task description (unused)

        Returns:
            ModeSuggestion as default fallback
        """
        return self.create_suggestion()


class ModeSelector:
    """Mode selector for collaboration patterns.

    Analyzes task descriptions and suggests appropriate collaboration modes
    using a rule-based approach. Returns suggestions sorted by confidence.

    Example:
        >>> selector = ModeSelector()
        >>> suggestions = selector.suggest("并行处理这批文件")
        >>> print(suggestions[0].mode)
        CollaborationModeType.FORK_SWARM
    """

    def __init__(
        self,
        rules: list[SelectionRule] | None = None,
    ) -> None:
        """Initialize the mode selector.

        Args:
            rules: Custom rules (if None, uses default rules)
        """
        if rules is None:
            # Default rules in priority order
            self._rules: list[SelectionRule] = [
                RulePredefinedAgent(),
                RuleParallelIndicator(),
                RuleDecompositionHint(),
                RuleComplexityIndicator(),
            ]
        else:
            self._rules = rules

        self._default_rule = RuleDefault()

    def suggest(self, task_description: str) -> list[ModeSuggestion]:
        """Analyze task description and return mode suggestions.

        Returns suggestions sorted by confidence (highest first).
        Always includes at least one suggestion (the default).

        Args:
            task_description: The task description to analyze

        Returns:
            List of ModeSuggestion sorted by confidence (descending)
        """
        suggestions: list[ModeSuggestion] = []

        # Collect all matching rule suggestions
        for rule in self._rules:
            suggestion = rule.match(task_description)
            if suggestion is not None:
                suggestions.append(suggestion)

        # Add default if no rules matched
        if not suggestions:
            default_suggestion = self._default_rule.match(task_description)
            if default_suggestion is not None:
                suggestions.append(default_suggestion)

        # Sort by confidence descending
        suggestions.sort(key=lambda s: s.confidence, reverse=True)

        return suggestions

    def select_best(self, task_description: str) -> ModeSuggestion:
        """Return the best mode suggestion for the given task.

        Args:
            task_description: The task description to analyze

        Returns:
            The best ModeSuggestion (highest confidence)
        """
        suggestions = self.suggest(task_description)
        return suggestions[0]


# Convenience function for quick mode selection
def suggest_mode(task_description: str) -> ModeSuggestion:
    """Quick helper to get best mode suggestion.

    Args:
        task_description: The task description to analyze

    Returns:
        Best mode suggestion
    """
    return ModeSelector().select_best(task_description)
