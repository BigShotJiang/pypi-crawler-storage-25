"""Multi-agent collaboration module.

.. deprecated:: 1.0.0
    Use :mod:`pyclaw.agents.multiagent` instead.
    This module will be removed in version 2.0.0.

This module provides collaboration primitives for multi-agent orchestration:
- CollaborationEngine: Unified orchestration engine
- CollaborationMode: Mode implementations (custom_agent, fork_swarm, etc.)
- CustomAgentRegistry: Agent configuration registry
- ToolPermissionManager: Tool access control
- ContextSharingManager: Context and memory sharing
- ModeSelector: Intelligent mode selection based on task description
- TaskDecomposer: Task decomposition for dynamic_decompose mode

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md
"""

from __future__ import annotations

import warnings

# Expose storage module for direct access
from pyclaw.agents.collaboration import storage
from pyclaw.agents.collaboration.decomposer import (
    ANALYZE_AND_FIX,
    EXPLORE_AND_SUMMARIZE,
    IMPLEMENT_AND_TEST,
    RESEARCH_AND_REPORT,
    DecompositionPattern,
    DecompositionStrategy,
    HeuristicDecomposer,
    LLMDecomposer,
    SubtaskDefinition,
    TaskDecomposer,
    decompose_task_heuristic,
)
from pyclaw.agents.collaboration.selector import ModeSelector, suggest_mode
from pyclaw.agents.collaboration.storage import (
    CustomAgentRegistry,
    IncompatibleSchemaError,
    LoadError,
)
from pyclaw.agents.collaboration.types import (
    SUPPORTED_SCHEMA_VERSIONS,
    ChildContext,
    CollaborationSession,
    CustomAgentConfig,
    ModeSuggestion,
    ModeSwitchResult,
    ModeSwitchTrigger,
    SpawnResult,
)
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    MemoryScope,
    TaskStatus,
    TrustLevel,
)

# Emit deprecation warning after imports
warnings.warn(  # noqa: E402
    "pyclaw.agents.collaboration is deprecated since version 1.0.0. "
    "Use pyclaw.agents.multiagent instead. "
    "This module will be removed in version 2.0.0.",
    DeprecationWarning,
    stacklevel=2,
)

__all__ = [
    # Enums (re-exported from multiagent)
    "CollaborationModeType",
    "TrustLevel",
    "ModeSwitchTrigger",
    "MemoryScope",
    "TaskStatus",
    "DecompositionStrategy",
    # Constants
    "SUPPORTED_SCHEMA_VERSIONS",
    # Models
    "CustomAgentConfig",
    "CollaborationSession",
    "ModeSuggestion",
    "SpawnResult",
    "ChildContext",
    "ModeSwitchResult",
    "SubtaskDefinition",
    "DecompositionPattern",
    # Selector
    "ModeSelector",
    "suggest_mode",
    # Decomposer
    "TaskDecomposer",
    "HeuristicDecomposer",
    "LLMDecomposer",
    "decompose_task_heuristic",
    # Predefined patterns
    "RESEARCH_AND_REPORT",
    "IMPLEMENT_AND_TEST",
    "ANALYZE_AND_FIX",
    "EXPLORE_AND_SUMMARIZE",
    # Storage module and classes
    "storage",
    "CustomAgentRegistry",
    "IncompatibleSchemaError",
    "LoadError",
]
