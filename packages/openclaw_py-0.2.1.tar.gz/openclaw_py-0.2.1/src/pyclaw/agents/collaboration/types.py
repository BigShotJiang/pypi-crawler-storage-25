"""Core type definitions for multi-agent collaboration.

.. deprecated:: 1.0.0
    This module is deprecated. Use :mod:`pyclaw.agents.multiagent.types` instead.
    This module will be removed in version 2.0.0.

This module defines the fundamental types used across the collaboration system:
- Enums: CollaborationModeType, TrustLevel, ModeSwitchTrigger, MemoryScope
- Models: CustomAgentConfig, CollaborationSession, and result types

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

# Re-export from unified multiagent module for backward compatibility
from pyclaw.agents.multiagent.types import (
    CollaborationModeType,
    MemoryScope,
    TaskStatus,
    TrustLevel,
)

# ============================================================================
# Enums (local to collaboration module)
# ============================================================================


class ModeSwitchTrigger(str, Enum):
    """Trigger type for mode switching.

    Determines how a collaboration mode change was initiated:
    - EXPLICIT: User explicitly requested the mode change
    - SUGGESTED: System suggested, user confirmed
    - AUTO: Automatic switch based on task analysis
    """

    EXPLICIT = "explicit"
    SUGGESTED = "suggested"
    AUTO = "auto"


# ============================================================================
# Constants
# ============================================================================

SUPPORTED_SCHEMA_VERSIONS = ["1.0"]

# ============================================================================
# Configuration Models
# ============================================================================


class CustomAgentConfig(BaseModel):
    """Configuration definition for a Custom Agent.

    Custom Agents are predefined agents loaded from YAML, Markdown, or UI.
    This configuration defines their behavior, permissions, and metadata.

    Attributes:
        schema_version: Configuration schema version for compatibility checks
        agent_id: Unique identifier for this agent
        name: Human-readable display name
        description: Description of what this agent does
        system_prompt: Agent system prompt template
        model: Preferred model identifier (optional)
        tools_enabled: Whitelist of enabled tools (None = all allowed)
        tools_disabled: Blacklist of disabled tools
        trust_level: Permission level for tool access
        memory_scope: Memory storage scope
        tags: Classification tags for filtering
        source: Origin of this configuration (yaml/markdown/ui)
        source_path: File path if loaded from filesystem
    """

    schema_version: str = Field(
        default="1.0",
        description="Configuration schema version for compatibility checks",
    )
    agent_id: str = Field(..., description="Unique identifier for this agent")
    name: str = Field(..., description="Human-readable display name")
    description: str = Field(default="", description="What this agent does")

    # Core configuration
    system_prompt: str | None = Field(default=None, description="Agent system prompt template")
    model: str | None = Field(default=None, description="Preferred model identifier")

    # Tool permissions
    tools_enabled: list[str] | None = Field(default=None, description="Whitelist of enabled tools")
    tools_disabled: list[str] | None = Field(default=None, description="Blacklist of disabled tools")
    trust_level: TrustLevel = Field(default=TrustLevel.STANDARD, description="Permission level for tool access")

    # Memory scope
    memory_scope: MemoryScope = Field(default=MemoryScope.TASK, description="Memory storage scope")

    # Metadata
    tags: list[str] = Field(default_factory=list, description="Classification tags")
    source: str = Field(default="yaml", description="Origin (yaml/markdown/ui)")
    source_path: str | None = Field(default=None, description="File path if loaded from filesystem")


class CollaborationSession(BaseModel):
    """Collaboration session state.

    Tracks the state of an active collaboration session, including
    active mode, child agents, and mode history.

    Attributes:
        session_id: Unique session identifier
        parent_session_id: Parent session if this is a child
        memory_session_id: Associated memory session for context
        active_mode: Currently active collaboration mode
        mode_history: History of mode switches
        child_agents: List of child agent session IDs
        max_children: Maximum allowed child agents
        scratchpad_dir: Shared workspace directory
        status: Session status (active/paused/completed)
    """

    session_id: str = Field(..., description="Unique session identifier")
    parent_session_id: str | None = Field(default=None, description="Parent session if this is a child")
    memory_session_id: str | None = Field(default=None, description="Associated memory session for context")

    active_mode: CollaborationModeType | None = Field(default=None, description="Currently active collaboration mode")
    mode_history: list[dict[str, Any]] = Field(default_factory=list, description="History of mode switches")

    child_agents: list[str] = Field(default_factory=list, description="Child agent session IDs")
    max_children: int = Field(default=4, description="Maximum allowed child agents")

    scratchpad_dir: str | None = Field(default=None, description="Shared workspace directory")
    status: str = Field(default="active", description="Session status")


# ============================================================================
# Result Types
# ============================================================================


class ModeSuggestion(BaseModel):
    """Suggestion for collaboration mode selection.

    Returned by ModeSelector.suggest() when analyzing task descriptions.

    Attributes:
        mode: Suggested collaboration mode
        confidence: Confidence score (0.0 to 1.0)
        reason: Explanation for the suggestion
        requires_confirmation: Whether user confirmation is needed
    """

    mode: CollaborationModeType = Field(..., description="Suggested collaboration mode")
    confidence: float = Field(default=0.0, ge=0.0, le=1.0, description="Confidence score")
    reason: str = Field(default="", description="Explanation for the suggestion")
    requires_confirmation: bool = Field(default=True, description="Whether user confirmation is needed")


class SpawnResult(BaseModel):
    """Result of spawning a child agent.

    Returned by CollaborationEngine.spawn_child() after creating a child agent.

    Attributes:
        session_id: Session ID of the spawned child (or parent for multi-spawn)
        status: Spawn status (success/failed/partial)
        children: List of child session IDs (for fork_swarm mode)
        child_context: Context passed to the child agent
    """

    session_id: str = Field(..., description="Session ID of the spawned child")
    status: str = Field(..., description="Spawn status")
    children: list[str] = Field(default_factory=list, description="Child session IDs for multi-spawn")
    child_context: dict[str, Any] | None = Field(default=None, description="Context passed to child agent")


class ChildContext(BaseModel):
    """Context passed to a child agent on spawn.

    Contains all information needed for a child agent to start working,
    including history snapshot, workspace, and memory configuration.

    Attributes:
        session_id: Child session ID
        parent_session_id: Parent session ID
        history_snapshot: Snapshot of parent conversation history
        scratchpad_dir: Shared workspace directory path
        memory_scope: Memory storage scope for this child
        memory_session_id: Associated memory session ID
        task_prompt: The task prompt for the child agent
    """

    session_id: str = Field(..., description="Child session ID")
    parent_session_id: str = Field(..., description="Parent session ID")
    history_snapshot: list[dict[str, Any]] = Field(
        default_factory=list, description="Parent conversation history snapshot"
    )
    scratchpad_dir: str | None = Field(default=None, description="Shared workspace directory")
    memory_scope: MemoryScope = Field(..., description="Memory storage scope")
    memory_session_id: str | None = Field(default=None, description="Associated memory session")
    task_prompt: str = Field(..., description="Task prompt for child agent")


class ModeSwitchResult(BaseModel):
    """Result of a collaboration mode switch.

    Returned by CollaborationEngine.switch_mode().

    Attributes:
        success: Whether the switch was successful
        mode: The new mode (if successful)
        message: Status or error message
        requires_confirmation: Whether additional confirmation is needed
    """

    success: bool = Field(..., description="Whether the switch was successful")
    mode: CollaborationModeType | None = Field(default=None, description="The new mode if successful")
    message: str = Field(default="", description="Status or error message")
    requires_confirmation: bool = Field(default=False, description="Whether confirmation is needed")


__all__ = [
    # Re-exported from multiagent.types
    "CollaborationModeType",
    "TrustLevel",
    "MemoryScope",
    "TaskStatus",
    # Local enums
    "ModeSwitchTrigger",
    # Local models
    "CustomAgentConfig",
    "CollaborationSession",
    "ModeSuggestion",
    "SpawnResult",
    "ChildContext",
    "ModeSwitchResult",
]
