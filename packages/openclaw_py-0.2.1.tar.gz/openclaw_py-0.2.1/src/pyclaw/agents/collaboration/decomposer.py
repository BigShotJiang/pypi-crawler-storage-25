"""Task decomposer for multi-agent collaboration.

This module provides task decomposition capabilities for the dynamic_decompose
collaboration mode. It supports three strategies:
- HEURISTIC: Rule-based pattern matching
- LLM: LLM-driven intelligent decomposition
- HYBRID: Heuristic first, fallback to LLM on failure

Reference: docs/superpowers/specs/2026-04-12-multi-agent-collaboration-design.md
"""

from __future__ import annotations

import uuid
from enum import Enum
from typing import TYPE_CHECKING, Any, Protocol

from pydantic import BaseModel, Field

from pyclaw.agents.collaboration.types import CollaborationModeType

if TYPE_CHECKING:
    pass  # Protocol is used instead of concrete types


class DecompositionStrategy(str, Enum):
    """Strategy for task decomposition.

    - HEURISTIC: Rule-based pattern recognition (fast, deterministic)
    - LLM: LLM-driven intelligent decomposition (flexible, context-aware)
    - HYBRID: Heuristic first, fallback to LLM on failure
    """

    HEURISTIC = "heuristic"
    LLM = "llm"
    HYBRID = "hybrid"


class SubtaskDefinition(BaseModel):
    """Definition of a decomposed subtask.

    Attributes:
        task_id: Unique identifier for this subtask
        description: Human-readable description of the subtask
        dependencies: List of task IDs this subtask depends on
        assigned_mode: Recommended collaboration mode for this subtask
        priority: Execution priority (higher = more important)
    """

    task_id: str = Field(..., description="Unique identifier for this subtask")
    description: str = Field(..., description="Description of the subtask")
    dependencies: list[str] = Field(
        default_factory=list,
        description="List of task IDs this subtask depends on",
    )
    assigned_mode: CollaborationModeType = Field(
        default=CollaborationModeType.CUSTOM_AGENT,
        description="Recommended collaboration mode",
    )
    priority: int = Field(
        default=0,
        ge=0,
        le=100,
        description="Execution priority (higher = more important)",
    )


class DecompositionPattern(BaseModel):
    """Predefined decomposition pattern.

    Patterns define common task decomposition templates that can be
    applied based on task characteristics.

    Attributes:
        name: Pattern name
        keywords: Keywords that trigger this pattern
        subtasks: Template for subtask generation
    """

    name: str = Field(..., description="Pattern name")
    keywords: list[str] = Field(default_factory=list, description="Trigger keywords")
    subtasks: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Subtask templates",
    )


class LLMClientProtocol(Protocol):
    """Protocol for LLM client used in decomposition."""

    async def messages_create(
        self,
        model: str,
        max_tokens: int,
        system: str,
        messages: list[dict[str, Any]],
    ) -> Any:
        """Create a message completion.

        Args:
            model: Model identifier
            max_tokens: Maximum tokens to generate
            system: System prompt
            messages: Conversation messages

        Returns:
            Message response
        """
        ...


# ============================================================================
# Predefined Decomposition Patterns
# ============================================================================

# Pattern: Research and Report
# For tasks involving investigation, analysis, or information gathering
RESEARCH_AND_REPORT = DecompositionPattern(
    name="research_and_report",
    keywords=[
        "研究",
        "调查",
        "分析",
        "调研",
        "research",
        "investigate",
        "analyze",
        "explore",
        "study",
        "survey",
        "分析报告",
        "调研报告",
    ],
    subtasks=[
        {
            "description_template": "Research and gather information: {task}",
            "dependencies": [],
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 10,
        },
        {
            "description_template": "Synthesize findings and create report: {task}",
            "dependencies": ["{task_id}_0"],  # Depends on research subtask
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 5,
        },
    ],
)

# Pattern: Implement and Test
# For tasks involving development, coding, or building
IMPLEMENT_AND_TEST = DecompositionPattern(
    name="implement_and_test",
    keywords=[
        "实现",
        "开发",
        "构建",
        "编写",
        "implement",
        "develop",
        "build",
        "create",
        "code",
        "开发功能",
        "实现功能",
    ],
    subtasks=[
        {
            "description_template": "Plan implementation approach: {task}",
            "dependencies": [],
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 15,
        },
        {
            "description_template": "Implement core functionality: {task}",
            "dependencies": ["{task_id}_0"],  # Depends on planning
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 10,
        },
        {
            "description_template": "Verify implementation with tests: {task}",
            "dependencies": ["{task_id}_1"],  # Depends on implementation
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 5,
        },
    ],
)

# Pattern: Analyze and Fix
# For tasks involving debugging, fixing, or resolving issues
ANALYZE_AND_FIX = DecompositionPattern(
    name="analyze_and_fix",
    keywords=[
        "修复",
        "解决",
        "调试",
        "debug",
        "fix",
        "resolve",
        "solve",
        "troubleshoot",
        "修复问题",
        "解决问题",
        "bug",
        "错误",
    ],
    subtasks=[
        {
            "description_template": "Investigate the issue: {task}",
            "dependencies": [],
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 15,
        },
        {
            "description_template": "Implement fix: {task}",
            "dependencies": ["{task_id}_0"],  # Depends on investigation
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 10,
        },
        {
            "description_template": "Verify fix resolves the issue: {task}",
            "dependencies": ["{task_id}_1"],  # Depends on fix
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 5,
        },
    ],
)

# Pattern: Explore and Summarize
# For tasks involving exploration, learning, or summarization
EXPLORE_AND_SUMMARIZE = DecompositionPattern(
    name="explore_and_summarize",
    keywords=[
        "探索",
        "了解",
        "学习",
        "总结",
        "explore",
        "learn",
        "understand",
        "summarize",
        "overview",
        "熟悉",
        "概览",
    ],
    subtasks=[
        {
            "description_template": "Explore and gather information: {task}",
            "dependencies": [],
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 10,
        },
        {
            "description_template": "Summarize findings: {task}",
            "dependencies": ["{task_id}_0"],  # Depends on exploration
            "assigned_mode": CollaborationModeType.CUSTOM_AGENT,
            "priority": 5,
        },
    ],
)

# All predefined patterns in priority order
DEFAULT_PATTERNS = [
    IMPLEMENT_AND_TEST,
    ANALYZE_AND_FIX,
    RESEARCH_AND_REPORT,
    EXPLORE_AND_SUMMARIZE,
]


# ============================================================================
# Heuristic Decomposer
# ============================================================================


class HeuristicDecomposer:
    """Rule-based task decomposition using pattern matching.

    This decomposer uses predefined patterns to decompose tasks based on
    keyword matching. It's fast and deterministic but may not handle
    complex or ambiguous tasks well.
    """

    def __init__(self, patterns: list[DecompositionPattern] | None = None) -> None:
        """Initialize the heuristic decomposer.

        Args:
            patterns: Custom decomposition patterns (uses defaults if None)
        """
        self._patterns = patterns or DEFAULT_PATTERNS

    def can_decompose(self, task: str) -> bool:
        """Check if this decomposer can handle the given task.

        Args:
            task: Task description to check

        Returns:
            True if a matching pattern is found
        """
        return self._find_pattern(task) is not None

    def decompose(
        self,
        task: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition] | None:
        """Decompose a task using pattern matching.

        Args:
            task: Task description to decompose
            context: Optional context for decomposition

        Returns:
            List of SubtaskDefinition if pattern matches, None otherwise
        """
        pattern = self._find_pattern(task)
        if pattern is None:
            return None

        return self._apply_pattern(pattern, task, context)

    def _find_pattern(self, task: str) -> DecompositionPattern | None:
        """Find the best matching pattern for a task.

        Args:
            task: Task description

        Returns:
            Best matching pattern, or None if no match
        """
        task_lower = task.lower()

        for pattern in self._patterns:
            for keyword in pattern.keywords:
                if keyword.lower() in task_lower:
                    return pattern

        return None

    def _apply_pattern(
        self,
        pattern: DecompositionPattern,
        task: str,
        context: dict[str, Any] | None,
    ) -> list[SubtaskDefinition]:
        """Apply a decomposition pattern to a task.

        Args:
            pattern: Pattern to apply
            task: Task description
            context: Optional context

        Returns:
            List of generated subtasks
        """
        base_id = context.get("base_id") if context else None
        if base_id is None:
            base_id = str(uuid.uuid4())[:8]

        subtasks: list[SubtaskDefinition] = []

        for idx, template in enumerate(pattern.subtasks):
            task_id = f"{base_id}_{idx}"
            description = template["description_template"].format(task=task)

            # Resolve dependencies (replace placeholders)
            dependencies = []
            for dep in template.get("dependencies", []):
                resolved_dep = dep.format(task_id=base_id)
                dependencies.append(resolved_dep)

            subtask = SubtaskDefinition(
                task_id=task_id,
                description=description,
                dependencies=dependencies,
                assigned_mode=template.get(
                    "assigned_mode",
                    CollaborationModeType.CUSTOM_AGENT,
                ),
                priority=template.get("priority", 0),
            )
            subtasks.append(subtask)

        return subtasks


# ============================================================================
# LLM Decomposer
# ============================================================================

SYSTEM_PROMPT_DECOMPOSITION = """You are a task decomposition expert. Your job is to break down complex tasks into smaller, manageable subtasks.

Given a task description, decompose it into a list of subtasks in JSON format.

Output format:
{
    "subtasks": [
        {
            "description": "Description of subtask 1",
            "dependencies": [],
            "assigned_mode": "custom_agent",
            "priority": 10
        },
        {
            "description": "Description of subtask 2",
            "dependencies": ["<task_id_of_subtask_1>"],
            "assigned_mode": "custom_agent",
            "priority": 5
        }
    ]
}

Guidelines:
1. Each subtask should be atomic and independently executable
2. Set dependencies to indicate which subtasks must complete first
3. Use "custom_agent" as the default assigned_mode
4. Higher priority means more important (range: 0-100)
5. Keep subtask descriptions clear and actionable
6. Aim for 2-5 subtasks for most tasks

The user will provide task IDs for you to use in dependencies.
"""

USER_PROMPT_TEMPLATE = """Decompose the following task into subtasks.

Task: {task}

Base task ID to use: {base_id}

Context (if any):
{context}

Output the decomposition as JSON:"""


class LLMDecomposer:
    """LLM-driven task decomposition.

    This decomposer uses an LLM to intelligently decompose tasks,
    handling complex or ambiguous tasks that heuristic methods can't.
    """

    def __init__(
        self,
        client: LLMClientProtocol | None = None,
        model: str = "claude-3-haiku-20240307",
    ) -> None:
        """Initialize the LLM decomposer.

        Args:
            client: LLM client (e.g., Anthropic AsyncAnthropic)
            model: Model to use for decomposition
        """
        self._client = client
        self._model = model

    async def decompose(
        self,
        task: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition] | None:
        """Decompose a task using LLM.

        Args:
            task: Task description to decompose
            context: Optional context for decomposition

        Returns:
            List of SubtaskDefinition, or None if decomposition fails
        """
        if self._client is None:
            return None

        import json

        base_id = context.get("base_id") if context else str(uuid.uuid4())[:8]
        context_str = json.dumps(context, ensure_ascii=False, indent=2) if context else "None"

        user_prompt = USER_PROMPT_TEMPLATE.format(
            task=task,
            base_id=base_id,
            context=context_str,
        )

        try:
            response = await self._client.messages_create(
                model=self._model,
                max_tokens=1024,
                system=SYSTEM_PROMPT_DECOMPOSITION,
                messages=[{"role": "user", "content": user_prompt}],
            )

            # Extract text from response
            content = response.content[0]
            text = content.text if hasattr(content, "text") else str(content)

            # Parse JSON response
            # Handle markdown code blocks if present
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0]
            elif "```" in text:
                text = text.split("```")[1].split("```")[0]

            data = json.loads(text.strip())
            subtasks_data = data.get("subtasks", [])

            subtasks: list[SubtaskDefinition] = []
            for idx, st_data in enumerate(subtasks_data):
                subtask = SubtaskDefinition(
                    task_id=f"{base_id}_{idx}",
                    description=st_data.get("description", f"Subtask {idx + 1}"),
                    dependencies=st_data.get("dependencies", []),
                    assigned_mode=CollaborationModeType(
                        st_data.get("assigned_mode", "custom_agent"),
                    ),
                    priority=st_data.get("priority", 0),
                )
                subtasks.append(subtask)

            return subtasks

        except (json.JSONDecodeError, KeyError, ValueError, AttributeError):
            return None


# ============================================================================
# Main Task Decomposer
# ============================================================================


class TaskDecomposer:
    """Main task decomposer supporting multiple strategies.

    This class provides a unified interface for task decomposition,
    supporting heuristic, LLM, and hybrid strategies.

    Example:
        >>> decomposer = TaskDecomposer()
        >>> subtasks = decomposer.decompose("研究并分析这个系统的架构")
        >>> for st in subtasks:
        ...     print(f"{st.task_id}: {st.description}")
    """

    def __init__(
        self,
        strategy: DecompositionStrategy = DecompositionStrategy.HEURISTIC,
        llm_client: LLMClientProtocol | None = None,
        llm_model: str = "claude-3-haiku-20240307",
        patterns: list[DecompositionPattern] | None = None,
    ) -> None:
        """Initialize the task decomposer.

        Args:
            strategy: Decomposition strategy to use
            llm_client: LLM client for LLM/HYBRID strategies
            llm_model: Model to use for LLM decomposition
            patterns: Custom patterns for heuristic decomposition
        """
        self._strategy = strategy
        self._heuristic = HeuristicDecomposer(patterns)
        self._llm = LLMDecomposer(llm_client, llm_model)

    async def decompose(
        self,
        task: str,
        context: dict[str, Any] | None = None,
    ) -> list[SubtaskDefinition]:
        """Decompose a task into subtasks.

        The decomposition strategy determines how the task is processed:
        - HEURISTIC: Uses pattern matching only
        - LLM: Uses LLM only
        - HYBRID: Tries heuristic first, falls back to LLM

        Args:
            task: Task description to decompose
            context: Optional context for decomposition (can include base_id)

        Returns:
            List of SubtaskDefinition (may be empty if decomposition fails)
        """
        if self._strategy == DecompositionStrategy.HEURISTIC:
            result = self._heuristic.decompose(task, context)
            return result if result is not None else []

        if self._strategy == DecompositionStrategy.LLM:
            result = await self._llm.decompose(task, context)
            return result if result is not None else []

        # HYBRID: Try heuristic first, fallback to LLM
        heuristic_result = self._heuristic.decompose(task, context)
        if heuristic_result is not None:
            return heuristic_result

        llm_result = await self._llm.decompose(task, context)
        return llm_result if llm_result is not None else []

    def set_strategy(self, strategy: DecompositionStrategy) -> None:
        """Change the decomposition strategy.

        Args:
            strategy: New strategy to use
        """
        self._strategy = strategy

    def can_decompose_heuristic(self, task: str) -> bool:
        """Check if the heuristic can handle the given task.

        Args:
            task: Task description to check

        Returns:
            True if heuristic decomposition is possible
        """
        return self._heuristic.can_decompose(task)


# ============================================================================
# Convenience Functions
# ============================================================================


def decompose_task_heuristic(
    task: str,
    context: dict[str, Any] | None = None,
    patterns: list[DecompositionPattern] | None = None,
) -> list[SubtaskDefinition]:
    """Convenience function for heuristic decomposition.

    Args:
        task: Task description to decompose
        context: Optional context for decomposition
        patterns: Custom decomposition patterns

    Returns:
        List of SubtaskDefinition (may be empty)
    """
    decomposer = HeuristicDecomposer(patterns)
    result = decomposer.decompose(task, context)
    return result if result is not None else []
