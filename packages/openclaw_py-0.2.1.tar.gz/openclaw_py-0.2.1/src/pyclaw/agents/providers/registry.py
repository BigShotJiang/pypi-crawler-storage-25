"""Provider registry — unified provider registration, discovery, config parsing.

Ported from ``src/agents/providers/provider-registry.ts``.

Provides:
- Provider registration and lookup
- Configuration parsing from user config
- Provider builder protocol
- Discovery of available providers

Migrated to align with Registry interface pattern (Phase 03).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Protocol

from pyclaw.constants.runtime import STATUS_INACTIVE, STATUS_MISSING, STATUS_OK

from .cn_providers import ALL_CN_PROVIDERS, build_cn_config
from .openai_compat import (
    PRECONFIGURED_PROVIDERS,
    OpenAICompatProvider,
)

logger = logging.getLogger(__name__)


class ProviderBuilder(Protocol):
    """Protocol for constructing a provider from config."""

    def build(self, config: dict[str, Any]) -> OpenAICompatProvider: ...


@dataclass
class ProviderInfo:
    """Metadata about a registered provider."""

    name: str
    display_name: str = ""
    category: str = "generic"  # "generic" | "cn" | "cloud" | "oauth"
    requires_api_key: bool = True
    requires_oauth: bool = False
    docs_url: str = ""
    models: list[str] = field(default_factory=list)


class ProviderRegistry:
    """Central registry for all LLM providers.

    Aligned with Registry interface pattern but NOT extending Registry ABC
    due to the unique two-dict storage pattern (_providers, _info).

    Methods align with Registry[K, V] interface:
    - register(key, value)
    - get(key) -> value | None
    - unregister(key) -> bool
    - list_all() -> list[value]
    - list_keys() -> list[key]
    - clear()

    Domain-specific methods preserved:
    - get_info(), list_providers(), health_probe(), resolve_model(), build_from_config()
    """

    def __init__(self) -> None:
        self._providers: dict[str, OpenAICompatProvider] = {}
        self._info: dict[str, ProviderInfo] = {}
        self._builders: dict[str, ProviderBuilder] = {}

    def register(
        self,
        provider: OpenAICompatProvider,
        info: ProviderInfo | None = None,
    ) -> None:
        """Register a provider with optional metadata.

        Args:
            provider: The provider instance to register.
            info: Optional metadata about the provider.
        """
        name = provider.name
        self._providers[name] = provider
        if info:
            self._info[name] = info
        else:
            self._info[name] = ProviderInfo(
                name=name,
                models=provider.list_models(),
            )

    def register_builder(self, name: str, builder: ProviderBuilder) -> None:
        """Register a builder for lazy provider construction."""
        self._builders[name] = builder

    def get(self, name: str) -> OpenAICompatProvider | None:
        """Get a provider by name.

        Args:
            name: Provider name.

        Returns:
            Provider instance or None.
        """
        return self._providers.get(name)

    def get_info(self, name: str) -> ProviderInfo | None:
        """Get provider metadata by name."""
        return self._info.get(name)

    def unregister(self, name: str) -> bool:
        """Unregister a provider.

        Args:
            name: Provider name to remove.

        Returns:
            True if provider was removed.
        """
        removed = self._providers.pop(name, None) is not None
        self._info.pop(name, None)
        return removed

    def list_all(self) -> list[OpenAICompatProvider]:
        """List all registered providers."""
        return list(self._providers.values())

    def list_keys(self) -> list[str]:
        """List all registered provider names."""
        return sorted(self._providers.keys())

    def clear(self) -> None:
        """Clear all registered providers."""
        self._providers.clear()
        self._info.clear()
        self._builders.clear()

    def list_providers(self, *, category: str = "") -> list[ProviderInfo]:
        """List provider info entries, optionally filtered by category."""
        infos = list(self._info.values())
        if category:
            infos = [i for i in infos if i.category == category]
        return sorted(infos, key=lambda i: i.name)

    def list_all_models(self) -> dict[str, list[str]]:
        """Return all available models grouped by provider."""
        result: dict[str, list[str]] = {}
        for name, provider in self._providers.items():
            result[name] = provider.list_models()
        return result

    def capability_registry(self) -> dict[str, dict[str, Any]]:
        """Return a capability snapshot for provider governance checks."""
        snapshot: dict[str, dict[str, Any]] = {}
        for name, info in self._info.items():
            snapshot[name] = {
                "category": info.category,
                "requires_api_key": info.requires_api_key,
                "requires_oauth": info.requires_oauth,
                "model_count": len(info.models),
                "has_active_client": name in self._providers,
            }
        return snapshot

    def health_probe(self, name: str) -> dict[str, Any]:
        """Provide a lightweight provider health probe result."""
        info = self._info.get(name)
        active = self._providers.get(name)
        if info is None:
            return {"provider": name, "status": STATUS_MISSING, "active": False, "models": 0}
        return {
            "provider": name,
            "status": STATUS_OK if active is not None else STATUS_INACTIVE,
            "active": active is not None,
            "models": len(info.models),
            "category": info.category,
        }

    def resolve_model(self, qualified_name: str) -> tuple[str, str]:
        """Resolve ``provider/model`` to (provider_name, model_id).

        If no ``/`` separator, search all providers for the model alias.
        """
        if "/" in qualified_name:
            parts = qualified_name.split("/", 1)
            provider_name = parts[0]
            model = parts[1]
            provider = self._providers.get(provider_name)
            if provider:
                return provider_name, provider.resolve_model(model)
            return provider_name, model

        for name, provider in self._providers.items():
            if qualified_name in [m.alias for m in (provider._config.models or [])]:
                return name, provider.resolve_model(qualified_name)

        return "", qualified_name

    def build_from_config(self, name: str, config: dict[str, Any]) -> OpenAICompatProvider | None:
        """Build and register a provider from user configuration."""
        builder = self._builders.get(name)
        if builder:
            provider = builder.build(config)
            self.register(provider)
            return provider

        return None

    @property
    def provider_count(self) -> int:
        """Return the number of registered providers."""
        return len(self._providers)

    def __contains__(self, name: str) -> bool:
        """Check if provider is registered."""
        return name in self._providers

    def __len__(self) -> int:
        """Return provider count."""
        return len(self._providers)


def create_default_registry() -> ProviderRegistry:
    """Create a registry with all known providers (requires API keys to activate)."""
    registry = ProviderRegistry()

    # Register preconfigured OpenAI-compat providers as info entries
    for name, builder_fn in PRECONFIGURED_PROVIDERS.items():
        config = builder_fn("__placeholder__")
        registry._info[name] = ProviderInfo(
            name=name,
            category="generic",
            models=[m.alias for m in config.models],
        )

    # Register Chinese providers as info entries
    for name, spec in ALL_CN_PROVIDERS.items():
        registry._info[name] = ProviderInfo(
            name=name,
            display_name=spec.display_name,
            category="cn",
            docs_url=spec.docs_url,
            models=[m.alias for m in spec.models],
        )

    # Add OAuth-based providers
    for name in ("copilot", "minimax-portal", "qwen-portal"):
        registry._info[name] = ProviderInfo(
            name=name,
            category="oauth",
            requires_api_key=False,
            requires_oauth=True,
        )

    # Add cloud providers
    registry._info["bedrock"] = ProviderInfo(
        name="bedrock",
        display_name="Amazon Bedrock",
        category="cloud",
        requires_api_key=False,
        docs_url="https://docs.aws.amazon.com/bedrock",
    )

    return registry


def activate_provider(
    registry: ProviderRegistry,
    name: str,
    api_key: str,
) -> OpenAICompatProvider | None:
    """Activate a provider by supplying its API key."""
    # Preconfigured OpenAI-compat
    if name in PRECONFIGURED_PROVIDERS:
        config = PRECONFIGURED_PROVIDERS[name](api_key)
        provider = OpenAICompatProvider(config)
        registry.register(provider)
        return provider

    # Chinese providers
    if name in ALL_CN_PROVIDERS:
        spec = ALL_CN_PROVIDERS[name]
        config = build_cn_config(spec, api_key)
        provider = OpenAICompatProvider(config)
        info = ProviderInfo(
            name=name,
            display_name=spec.display_name,
            category="cn",
            docs_url=spec.docs_url,
            models=[m.alias for m in spec.models],
        )
        registry.register(provider, info)
        return provider

    return None
