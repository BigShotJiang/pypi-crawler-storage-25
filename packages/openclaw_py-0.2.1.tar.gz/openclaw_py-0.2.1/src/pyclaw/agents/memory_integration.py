"""Memory integration with Agent runtime.

Provides integration between the MemoryManager and the agent execution loop:
- Memory-aware runner that handles context compaction
- Hook registration for automatic memory management
- Tool registration for memory tools

Note: This module provides a backward-compatible API using the new
BuiltinMemoryProvider internally. For new code, prefer using
BuiltinMemoryProvider directly from pyclaw.agents.memory.providers.builtin.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from pyclaw.agents.definition import MemoryScope
from pyclaw.agents.memory.providers.builtin import BuiltinMemoryProvider
from pyclaw.agents.memory.scope import MemoryPath
from pyclaw.agents.tools.memory_tools import create_memory_tools
from pyclaw.agents.types import ModelConfig
from pyclaw.memory import MemoryManager
from pyclaw.memory.types import MemoryConfig

logger = logging.getLogger(__name__)


class MemoryAwareRunner:
    """Runner wrapper that integrates memory management.

    This wraps the agent runner to provide:
    1. Automatic context compaction before reasoning
    2. Dialog persistence after each turn
    3. Memory tools for the agent to use

    Note: This class uses MemoryManager internally. For new code,
    consider using BuiltinMemoryProvider directly for a cleaner API.

    Usage:
        from pyclaw.agents.memory_integration import MemoryAwareRunner

        runner = MemoryAwareRunner(
            workspace_dir=Path("./workspace"),
            model=ModelConfig(provider="openai", model_id="gpt-4o"),
        )

        # Get tools to register with the agent
        tools = runner.get_tools()

        # Run with automatic memory management
        result = await runner.run(messages)
    """

    def __init__(
        self,
        workspace_dir: Path,
        model: ModelConfig | None = None,
        config: MemoryConfig | None = None,
    ) -> None:
        self._workspace_dir = Path(workspace_dir)
        self._model = model
        self._config = config or MemoryConfig()
        self._manager: MemoryManager | None = None
        self._provider: BuiltinMemoryProvider | None = None

    @property
    def manager(self) -> MemoryManager:
        """Get or create the MemoryManager.

        Returns:
            MemoryManager instance for backward compatibility.
        """
        if self._manager is None:
            self._manager = MemoryManager(
                self._workspace_dir,
                self._config,
                self._model,
            )
            self._manager.open()
        return self._manager

    @property
    def provider(self) -> BuiltinMemoryProvider:
        """Get or create the BuiltinMemoryProvider.

        This is the preferred way to access memory for new code.

        Returns:
            BuiltinMemoryProvider instance.
        """
        if self._provider is None:
            self._provider = BuiltinMemoryProvider()
            # Create MemoryPath with PROJECT scope
            memory_path = MemoryPath(
                scope=MemoryScope.PROJECT,
                base_dir=self._workspace_dir,
            )
            # Initialize synchronously (runs async in background if needed)
            try:
                loop = asyncio.get_running_loop()
                # We're in an async context, schedule initialization
                loop.create_task(self._provider.initialize(memory_path=memory_path))
            except RuntimeError:
                # No running loop, initialize synchronously
                asyncio.run(self._provider.initialize(memory_path=memory_path))
        return self._provider

    def get_tools(self) -> list[Any]:
        """Get memory tools to register with the agent.

        Returns:
            List of tool instances for memory operations
        """
        return create_memory_tools(memory_manager=self.manager)

    async def preprocess_messages(
        self,
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Preprocess messages before sending to LLM.

        This includes:
        1. Compacting long tool outputs
        2. Checking if context compaction is needed
        3. Applying compaction if necessary

        Args:
            messages: Current conversation messages

        Returns:
            Processed messages ready for LLM
        """
        # Step 1: Compact tool results
        processed = self.manager.compact_tool_results(messages)

        # Step 2: Check context
        check_result = self.manager.check_context(processed)

        # Step 3: Apply compaction if needed
        if check_result.needs_compaction:
            try:
                summary = await self.manager.generate_summary(
                    check_result.messages_to_compact,
                )
                processed = self.manager.apply_compaction(
                    processed,
                    summary,
                    check_result,
                )
                logger.info(
                    "Applied context compaction: %d -> %d messages",
                    len(messages),
                    len(processed),
                )
            except Exception as e:
                logger.error("Context compaction failed: %s", e)
                # Return original messages if compaction fails
                return messages

        return processed

    async def postprocess_turn(
        self,
        messages: list[dict[str, Any]],
        session_key: str | None = None,
    ) -> None:
        """Postprocess after a reasoning turn.

        This includes:
        1. Persisting dialog history
        2. Saving summary to daily log

        Args:
            messages: Messages from the turn
            session_key: Optional session identifier
        """
        # Persist dialog
        if self._config.dialog.enabled:
            try:
                self.manager.persist_dialog(messages)
            except Exception as e:
                logger.warning("Failed to persist dialog: %s", e)

    def get_context_for_prompt(self) -> str:
        """Get memory context to inject into system prompt.

        Returns:
            Formatted context string from long-term memory
        """
        try:
            prefs = self.manager.get_all_preferences()
            decisions = self.manager.get_all_decisions()

            lines: list[str] = []

            if prefs:
                lines.append("## User Preferences")
                for key, value in prefs.items():
                    lines.append(f"- **{key}**: {value}")
                lines.append("")

            if decisions:
                lines.append("## Recent Decisions")
                for d in decisions[-5:]:  # Last 5 decisions
                    lines.append(f"- [{d['date']}] {d['content']}")
                lines.append("")

            return "\n".join(lines) if lines else ""

        except Exception as e:
            logger.warning("Failed to get memory context: %s", e)
            return ""

    def close(self) -> None:
        """Close the memory manager."""
        if self._manager:
            self._manager.close()
            self._manager = None
        if self._provider:
            # Provider cleanup is async, schedule it
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._provider.shutdown())
            except RuntimeError:
                asyncio.run(self._provider.shutdown())
            self._provider = None

    def __enter__(self) -> MemoryAwareRunner:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


def setup_memory_for_agent(
    workspace_dir: Path,
    model: ModelConfig | None = None,
    config: MemoryConfig | None = None,
) -> dict[str, Any]:
    """Set up memory integration for an agent.

    This is a convenience function that creates all necessary components
    and returns them for integration.

    Note: For new code, prefer using get_memory_provider() from
    pyclaw.agents.memory.capability for a more modular approach.

    Args:
        workspace_dir: Workspace directory for memory storage
        model: Model configuration for summarization
        config: Memory configuration

    Returns:
        Dict with 'manager', 'tools', and 'context' keys
    """
    manager = MemoryManager(workspace_dir, config, model)
    manager.open()

    tools = create_memory_tools(memory_manager=manager)

    # Get context for prompt injection
    context = ""
    try:
        prefs = manager.get_all_preferences()
        if prefs:
            context = "User preferences:\n" + "\n".join(f"- {k}: {v}" for k, v in prefs.items())
    except Exception:
        pass

    return {
        "manager": manager,
        "tools": tools,
        "context": context,
    }


# Example integration with hooks
async def pre_reasoning_hook_handler(event: Any) -> dict[str, Any] | None:
    """Hook handler for pre-reasoning memory management.

    Register this with the hook system to enable automatic memory management.

    Args:
        event: Hook event with messages and context

    Returns:
        Optional modifications to apply to messages
    """
    workspace_dir = event.context.get("workspace_dir")
    if not workspace_dir:
        return None

    messages = event.messages
    if not messages:
        return None

    # Get or create memory runner
    memory_runner = event.context.get("_memory_runner")
    if not memory_runner:
        model_config = event.context.get("model_config")
        memory_config = event.context.get("memory_config")

        memory_runner = MemoryAwareRunner(
            Path(workspace_dir),
            model_config,
            memory_config,
        )

    # Process messages
    processed = await memory_runner.preprocess_messages(messages)

    if len(processed) != len(messages):
        return {"messages": processed}

    return None


async def post_session_hook_handler(event: Any) -> None:
    """Hook handler for post-session memory cleanup.

    Args:
        event: Hook event with session information
    """
    workspace_dir = event.context.get("workspace_dir")
    if not workspace_dir:
        return

    messages = event.messages
    if not messages:
        return

    try:
        manager = MemoryManager(Path(workspace_dir))
        manager.open()

        # Persist final dialog
        manager.persist_dialog(messages)

        # Clean up old files
        manager.cleanup()

        manager.close()

    except Exception as e:
        logger.warning("Post-session memory handling failed: %s", e)


# ---------------------------------------------------------------------------
# New API: Direct provider access
# ---------------------------------------------------------------------------


def get_builtin_memory_provider(
    project_root: Path | None = None,
    **kwargs: Any,
) -> BuiltinMemoryProvider:
    """Get a BuiltinMemoryProvider instance.

    This is the recommended way to get a memory provider for new code.
    The provider uses MemoryDirectory for file-based storage and BM25
    for search.

    Args:
        project_root: Project root directory. If None, uses current directory.
        **kwargs: Additional arguments passed to provider.initialize().

    Returns:
        Initialized BuiltinMemoryProvider instance.

    Example:
        from pyclaw.agents.memory_integration import get_builtin_memory_provider

        provider = get_builtin_memory_provider(Path("./my_project"))
        results = await provider.search("preferences", limit=5)
    """
    provider = BuiltinMemoryProvider()

    # Determine memory root
    if project_root is None:
        project_root = Path.cwd()

    memory_path = MemoryPath(
        scope=MemoryScope.PROJECT,
        base_dir=project_root,
    )

    # Initialize synchronously
    try:
        loop = asyncio.get_running_loop()
        # We're in an async context
        loop.create_task(provider.initialize(memory_path=memory_path, **kwargs))
    except RuntimeError:
        # No running loop
        asyncio.run(provider.initialize(memory_path=memory_path, **kwargs))

    return provider


__all__ = [
    # Legacy API (backward compatible)
    "MemoryAwareRunner",
    "setup_memory_for_agent",
    "pre_reasoning_hook_handler",
    "post_session_hook_handler",
    # New API
    "get_builtin_memory_provider",
]
