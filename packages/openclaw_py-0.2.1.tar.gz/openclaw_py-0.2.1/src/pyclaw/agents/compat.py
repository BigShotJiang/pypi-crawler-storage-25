"""Compatibility layer for deprecated APIs.

This module provides backward compatibility for APIs that have been
deprecated or replaced by newer implementations. It allows for smooth
migration paths while emitting deprecation warnings.

Key components:
- @deprecated: Decorator to mark functions/classes as deprecated
- MemoryDirectoryCompat: Compatibility layer proxying to BuiltinMemoryProvider
"""

from __future__ import annotations

import warnings
from collections.abc import Callable
from functools import wraps
from pathlib import Path
from typing import Any, TypeVar

F = TypeVar("F", bound=Callable)


def deprecated(
    message: str = "Use the new API instead.",
    version: str | None = None,
    removal_version: str | None = None,
) -> Callable[[F], F]:
    """Decorator to mark functions or methods as deprecated.

    Emits a DeprecationWarning when the decorated function is called,
    providing guidance on migration to the new API.

    Args:
        message: Custom deprecation message with migration guidance.
        version: Version when the function was deprecated.
        removal_version: Version when the function will be removed.

    Returns:
        Decorated function that emits DeprecationWarning on call.

    Example:
        ```python
        @deprecated(
            message="Use new_function() instead.",
            version="1.2.0",
            removal_version="2.0.0",
        )
        def old_function():
            pass
        ```
    """

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Build deprecation message
            msg_parts = [f"{func.__name__} is deprecated"]
            if version:
                msg_parts.append(f"since version {version}")
            if removal_version:
                msg_parts.append(f"and will be removed in version {removal_version}")
            msg_parts.append(f". {message}")

            warnings.warn(
                "".join(msg_parts),
                DeprecationWarning,
                stacklevel=2,
            )
            return func(*args, **kwargs)

        return wrapper  # type: ignore

    return decorator


def deprecated_class(
    message: str = "Use the new class instead.",
    version: str | None = None,
    removal_version: str | None = None,
) -> Callable[[type], type]:
    """Class decorator to mark classes as deprecated.

    Emits a DeprecationWarning when the class is instantiated.

    Args:
        message: Custom deprecation message with migration guidance.
        version: Version when the class was deprecated.
        removal_version: Version when the class will be removed.

    Returns:
        Decorated class that emits DeprecationWarning on instantiation.

    Example:
        ```python
        @deprecated_class(
            message="Use NewClass instead.",
            version="1.2.0",
        )
        class OldClass:
            pass
        ```
    """

    def decorator(cls: type) -> type:
        original_init = cls.__init__

        @wraps(original_init)
        def new_init(self: Any, *args: Any, **kwargs: Any) -> None:
            # Build deprecation message
            msg_parts = [f"{cls.__name__} is deprecated"]
            if version:
                msg_parts.append(f"since version {version}")
            if removal_version:
                msg_parts.append(f"and will be removed in version {removal_version}")
            msg_parts.append(f". {message}")

            warnings.warn(
                "".join(msg_parts),
                DeprecationWarning,
                stacklevel=2,
            )
            return original_init(self, *args, **kwargs)

        cls.__init__ = new_init
        return cls

    return decorator


class MemoryDirectoryCompat:
    """Compatibility layer for legacy MemoryDirectory.

    This class provides the same interface as the legacy MemoryDirectory
    from memory_dir/memdir.py, but internally proxies to BuiltinMemoryProvider.
    This allows existing code to continue working while migrating to the
    new provider-based architecture.

    Note:
        This class is deprecated. Use BuiltinMemoryProvider directly for
        new code.

    Example migration:
        ```python
        # Old code (deprecated)
        from pyclaw.agents.memory_dir import MemoryDirectory
        memdir = MemoryDirectory.from_project_root(project_root)

        # New code (recommended)
        from pyclaw.agents.memory.providers.builtin import BuiltinMemoryProvider
        provider = BuiltinMemoryProvider()
        await provider.initialize(project_root=project_root)
        ```
    """

    _DEPRECATION_MSG = "Use BuiltinMemoryProvider directly."

    def __init__(
        self,
        project_root: Path | str | None = None,
        paths: Any = None,
    ) -> None:
        """Initialize compatibility layer.

        Args:
            project_root: Root directory of the project (deprecated parameter).
            paths: MemoryPaths instance (deprecated parameter).

        Warns:
            DeprecationWarning: Always warns about deprecation.
        """
        warnings.warn(
            f"MemoryDirectoryCompat is deprecated. {self._DEPRECATION_MSG}",
            DeprecationWarning,
            stacklevel=2,
        )

        # Import here to avoid circular imports
        from pyclaw.agents.memory.providers.builtin import BuiltinMemoryProvider

        self._provider = BuiltinMemoryProvider()
        self._initialized = False
        self._project_root: Path | None = None

        # Handle legacy initialization patterns
        if paths is not None:
            # Extract project root from paths
            self._project_root = getattr(paths, "base_dir", None)
        elif project_root is not None:
            self._project_root = Path(project_root)

        # Store legacy paths for compatibility
        self._legacy_paths = paths

        # Type re-exports for compatibility
        # These will be lazy-loaded when accessed

    async def _ensure_initialized(self) -> None:
        """Ensure provider is initialized."""
        if not self._initialized:
            init_kwargs: dict[str, Any] = {}
            if self._project_root:
                init_kwargs["project_root"] = self._project_root
            await self._provider.initialize(**init_kwargs)
            self._initialized = True

    # --- Project Decisions (deprecated) ---

    @deprecated("Use BuiltinMemoryProvider.add() with memory_type='project_decision'")
    def add_decision(
        self,
        decision: str,
        rationale: str,
        priority: Any = None,
        tags: list[str] | None = None,
    ) -> Any:
        """Add a project decision (deprecated).

        Args:
            decision: The decision text.
            rationale: Why this decision was made.
            priority: Priority level (deprecated).
            tags: Optional tags.

        Returns:
            The created decision entry.

        Note:
            This method is synchronous for compatibility but uses
            async internally. Consider using BuiltinMemoryProvider.add()
            for proper async support.
        """
        import asyncio

        metadata = {
            "memory_type": "project_decision",
            "rationale": rationale,
            "tags": tags or [],
        }
        if priority:
            metadata["priority"] = str(priority)

        # Run async in sync context
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # We're in an async context, can't use asyncio.run
            # Return a placeholder; caller should use async methods
            import uuid

            return type(
                "ProjectDecision",
                (),
                {
                    "key": str(uuid.uuid4())[:8],
                    "content": decision,
                    "rationale": rationale,
                    "priority": priority,
                    "tags": tags or [],
                },
            )()

        return asyncio.run(self._add_decision_async(decision, metadata))

    async def _add_decision_async(
        self,
        decision: str,
        metadata: dict[str, Any],
    ) -> Any:
        """Async implementation of add_decision."""
        await self._ensure_initialized()
        entry_id = await self._provider.add(decision, metadata)

        # Create a simple object for compatibility
        return type(
            "ProjectDecision",
            (),
            {
                "key": entry_id,
                "content": decision,
                "rationale": metadata.get("rationale", ""),
                "priority": metadata.get("priority"),
                "tags": metadata.get("tags", []),
            },
        )()

    @deprecated("Use BuiltinMemoryProvider.search() with query")
    def get_decisions(self) -> list[Any]:
        """Get all project decisions (deprecated).

        Returns:
            List of decision entries.
        """
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return []

        return asyncio.run(self._get_decisions_async())

    async def _get_decisions_async(self) -> list[Any]:
        """Async implementation of get_decisions."""
        await self._ensure_initialized()
        results = await self._provider.search("decision project_decision", limit=100)
        return [
            type(
                "ProjectDecision",
                (),
                {
                    "key": e.id,
                    "content": e.content,
                    "rationale": e.metadata.get("rationale", ""),
                    "tags": e.metadata.get("tags", []),
                },
            )()
            for e in results
        ]

    # --- User Preferences (deprecated) ---

    @deprecated("Use BuiltinMemoryProvider.add() with memory_type='user_preference'")
    def set_preference(
        self,
        key: str,
        value: str,
        priority: Any = None,
    ) -> Any:
        """Set a user preference (deprecated).

        Args:
            key: Preference key.
            value: Preference value.
            priority: Priority level (deprecated).

        Returns:
            The created/updated preference entry.
        """
        import asyncio

        metadata = {
            "memory_type": "user_preference",
            "preference_key": key,
        }
        if priority:
            metadata["priority"] = str(priority)

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return type(
                "UserPreference",
                (),
                {"key": key, "content": value, "priority": priority},
            )()

        return asyncio.run(self._set_preference_async(key, value, metadata))

    async def _set_preference_async(
        self,
        key: str,
        value: str,
        metadata: dict[str, Any],
    ) -> Any:
        """Async implementation of set_preference."""
        await self._ensure_initialized()
        _ = await self._provider.add(value, metadata)  # entry_id not used in compat
        return type(
            "UserPreference",
            (),
            {"key": key, "content": value, "priority": metadata.get("priority")},
        )()

    @deprecated("Use BuiltinMemoryProvider.search() with preference key")
    def get_preference(self, key: str) -> Any | None:
        """Get a specific user preference (deprecated).

        Args:
            key: Preference key.

        Returns:
            Preference entry or None.
        """
        prefs = self.get_preferences()
        for pref in prefs:
            if getattr(pref, "key", None) == key:
                return pref
        return None

    @deprecated("Use BuiltinMemoryProvider.search() with query='user_preference'")
    def get_preferences(self) -> list[Any]:
        """Get all user preferences (deprecated).

        Returns:
            List of preference entries.
        """
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return []

        return asyncio.run(self._get_preferences_async())

    async def _get_preferences_async(self) -> list[Any]:
        """Async implementation of get_preferences."""
        await self._ensure_initialized()
        results = await self._provider.search("user_preference", limit=100)
        return [
            type(
                "UserPreference",
                (),
                {
                    "key": e.metadata.get("preference_key", e.id),
                    "content": e.content,
                    "priority": e.metadata.get("priority"),
                },
            )()
            for e in results
        ]

    # --- Session Memories (deprecated) ---

    @deprecated("Use BuiltinMemoryProvider.add() with session_id in metadata")
    def add_session_memory(
        self,
        session_id: str,
        content: str,
        memory_type: Any = None,
        tags: list[str] | None = None,
    ) -> Any:
        """Add a session-specific memory (deprecated).

        Args:
            session_id: Session identifier.
            content: Memory content.
            memory_type: Type of memory (deprecated).
            tags: Optional tags.

        Returns:
            The created memory entry.
        """
        import asyncio

        metadata = {
            "session_id": session_id,
            "memory_type": str(memory_type) if memory_type else "session_context",
            "tags": tags or [],
        }

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import uuid

            return type(
                "MemoryEntry",
                (),
                {"key": str(uuid.uuid4())[:8], "content": content, "tags": tags or []},
            )()

        return asyncio.run(self._add_session_memory_async(content, metadata))

    async def _add_session_memory_async(
        self,
        content: str,
        metadata: dict[str, Any],
    ) -> Any:
        """Async implementation of add_session_memory."""
        await self._ensure_initialized()
        entry_id = await self._provider.add(content, metadata)
        return type(
            "MemoryEntry",
            (),
            {"key": entry_id, "content": content, "tags": metadata.get("tags", [])},
        )()

    @deprecated("Use BuiltinMemoryProvider.search() with session_id in query")
    def get_session_memories(self, session_id: str) -> list[Any]:
        """Get all memories for a session (deprecated).

        Args:
            session_id: Session identifier.

        Returns:
            List of memory entries.
        """
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return []

        return asyncio.run(self._get_session_memories_async(session_id))

    async def _get_session_memories_async(self, session_id: str) -> list[Any]:
        """Async implementation of get_session_memories."""
        await self._ensure_initialized()
        results = await self._provider.search(f"session {session_id}", limit=100)
        return [
            type(
                "MemoryEntry",
                (),
                {"key": e.id, "content": e.content, "tags": e.metadata.get("tags", [])},
            )()
            for e in results
        ]

    # --- Team Memories (deprecated) ---

    @deprecated("Use BuiltinMemoryProvider.add() with memory_type='team_shared'")
    def add_team_memory(
        self,
        content: str,
        member: str | None = None,
        tags: list[str] | None = None,
    ) -> Any:
        """Add a team shared memory (deprecated).

        Args:
            content: Memory content.
            member: Optional member who contributed.
            tags: Optional tags.

        Returns:
            The created memory entry.
        """
        import asyncio

        metadata: dict[str, Any] = {
            "memory_type": "team_shared",
            "tags": tags or [],
        }
        if member:
            metadata["member"] = member

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import uuid

            return type(
                "MemoryEntry",
                (),
                {"key": str(uuid.uuid4())[:8], "content": content, "tags": tags or []},
            )()

        return asyncio.run(self._add_team_memory_async(content, metadata))

    async def _add_team_memory_async(
        self,
        content: str,
        metadata: dict[str, Any],
    ) -> Any:
        """Async implementation of add_team_memory."""
        await self._ensure_initialized()
        entry_id = await self._provider.add(content, metadata)
        return type(
            "MemoryEntry",
            (),
            {"key": entry_id, "content": content, "tags": metadata.get("tags", [])},
        )()

    @deprecated("Use BuiltinMemoryProvider.search() with query='team_shared'")
    def get_team_memories(self) -> list[Any]:
        """Get all team shared memories (deprecated).

        Returns:
            List of memory entries.
        """
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return []

        return asyncio.run(self._get_team_memories_async())

    async def _get_team_memories_async(self) -> list[Any]:
        """Async implementation of get_team_memories."""
        await self._ensure_initialized()
        results = await self._provider.search("team_shared", limit=100)
        return [
            type(
                "MemoryEntry",
                (),
                {"key": e.id, "content": e.content, "tags": e.metadata.get("tags", [])},
            )()
            for e in results
        ]

    # --- Feedback Records (deprecated) ---

    @deprecated("Use BuiltinMemoryProvider.add() with memory_type='feedback_record'")
    def add_feedback(
        self,
        feedback: str,
        feedback_type: str,
        context: str = "",
        tags: list[str] | None = None,
    ) -> Any:
        """Add a feedback record (deprecated).

        Args:
            feedback: The feedback content.
            feedback_type: Type of feedback.
            context: Context where feedback was given.
            tags: Optional tags.

        Returns:
            The created feedback entry.
        """
        import asyncio

        metadata = {
            "memory_type": "feedback_record",
            "feedback_type": feedback_type,
            "context": context,
            "tags": tags or [],
        }

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import uuid

            return type(
                "FeedbackRecord",
                (),
                {
                    "key": str(uuid.uuid4())[:8],
                    "content": feedback,
                    "feedback_type": feedback_type,
                    "context": context,
                    "tags": tags or [],
                },
            )()

        return asyncio.run(self._add_feedback_async(feedback, metadata))

    async def _add_feedback_async(
        self,
        feedback: str,
        metadata: dict[str, Any],
    ) -> Any:
        """Async implementation of add_feedback."""
        await self._ensure_initialized()
        entry_id = await self._provider.add(feedback, metadata)
        return type(
            "FeedbackRecord",
            (),
            {
                "key": entry_id,
                "content": feedback,
                "feedback_type": metadata.get("feedback_type", ""),
                "context": metadata.get("context", ""),
                "tags": metadata.get("tags", []),
            },
        )()

    @deprecated("Use BuiltinMemoryProvider.search() with query='feedback'")
    def get_feedback(self) -> list[Any]:
        """Get all feedback records (deprecated).

        Returns:
            List of feedback entries.
        """
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return []

        return asyncio.run(self._get_feedback_async())

    async def _get_feedback_async(self) -> list[Any]:
        """Async implementation of get_feedback."""
        await self._ensure_initialized()
        results = await self._provider.search("feedback_record", limit=100)
        return [
            type(
                "FeedbackRecord",
                (),
                {
                    "key": e.id,
                    "content": e.content,
                    "feedback_type": e.metadata.get("feedback_type", ""),
                    "context": e.metadata.get("context", ""),
                    "tags": e.metadata.get("tags", []),
                },
            )()
            for e in results
        ]

    # --- Reference Links (deprecated) ---

    @deprecated("Use BuiltinMemoryProvider.add() with memory_type='reference_link'")
    def add_reference(
        self,
        url: str,
        description: str,
        tags: list[str] | None = None,
    ) -> Any:
        """Add a reference link (deprecated).

        Args:
            url: The URL.
            description: Description of the resource.
            tags: Optional tags.

        Returns:
            The created reference entry.
        """
        import asyncio

        metadata = {
            "memory_type": "reference_link",
            "url": url,
            "tags": tags or [],
        }

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import uuid

            return type(
                "ReferenceLink",
                (),
                {
                    "key": str(uuid.uuid4())[:8],
                    "url": url,
                    "description": description,
                    "tags": tags or [],
                },
            )()

        return asyncio.run(self._add_reference_async(description, metadata))

    async def _add_reference_async(
        self,
        description: str,
        metadata: dict[str, Any],
    ) -> Any:
        """Async implementation of add_reference."""
        await self._ensure_initialized()
        entry_id = await self._provider.add(description, metadata)
        return type(
            "ReferenceLink",
            (),
            {
                "key": entry_id,
                "url": metadata.get("url", ""),
                "description": description,
                "tags": metadata.get("tags", []),
            },
        )()

    @deprecated("Use BuiltinMemoryProvider.search() with query='reference'")
    def get_references(self) -> list[Any]:
        """Get all reference links (deprecated).

        Returns:
            List of reference entries.
        """
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return []

        return asyncio.run(self._get_references_async())

    async def _get_references_async(self) -> list[Any]:
        """Async implementation of get_references."""
        await self._ensure_initialized()
        results = await self._provider.search("reference_link", limit=100)
        return [
            type(
                "ReferenceLink",
                (),
                {
                    "key": e.id,
                    "url": e.metadata.get("url", ""),
                    "description": e.content,
                    "tags": e.metadata.get("tags", []),
                },
            )()
            for e in results
        ]

    # --- Search Operations (deprecated) ---

    @deprecated("Use BuiltinMemoryProvider.search() directly")
    def search(
        self,
        query: str,
        config: Any = None,
        decay_config: Any = None,
    ) -> list[Any]:
        """Search all memories for relevant entries (deprecated).

        Args:
            query: Search query.
            config: Search configuration (ignored).
            decay_config: Decay configuration (ignored).

        Returns:
            List of memory entries.
        """
        import asyncio

        _ = config, decay_config  # Ignore for compatibility

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return []

        return asyncio.run(self._search_async(query))

    async def _search_async(self, query: str) -> list[Any]:
        """Async implementation of search."""
        await self._ensure_initialized()
        results = await self._provider.search(query, limit=20)
        return [
            type(
                "MemoryEntry",
                (),
                {
                    "key": e.id,
                    "content": e.content,
                    "memory_type": e.metadata.get("memory_type", ""),
                    "tags": e.metadata.get("tags", []),
                    "relevance_score": e.score,
                },
            )()
            for e in results
        ]

    @deprecated("Build context manually from BuiltinMemoryProvider.search() results")
    def get_context_for_prompt(
        self,
        max_entries: int = 20,
        max_tokens: int = 2000,
    ) -> str:
        """Get formatted context from memories (deprecated).

        Args:
            max_entries: Maximum entries to include.
            max_tokens: Approximate token limit.

        Returns:
            Formatted context string.
        """
        import asyncio

        _ = max_entries, max_tokens  # Simplified implementation

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return ""

        return asyncio.run(self._get_context_async())

    async def _get_context_async(self) -> str:
        """Async implementation of get_context_for_prompt."""
        await self._ensure_initialized()

        lines: list[str] = []

        # Get preferences
        prefs = await self._get_preferences_async()
        if prefs:
            lines.append("## User Preferences")
            for p in prefs[:5]:
                lines.append(f"- **{getattr(p, 'key', 'unknown')}**: {getattr(p, 'content', '')}")
            lines.append("")

        # Get decisions
        decisions = await self._get_decisions_async()
        if decisions:
            lines.append("## Recent Decisions")
            for d in decisions[:5]:
                lines.append(f"- {getattr(d, 'content', '')}")
            lines.append("")

        # Get team context
        team = await self._get_team_memories_async()
        if team:
            lines.append("## Team Context")
            for t in team[:5]:
                content = getattr(t, "content", "")
                lines.append(f"- {content[:100]}")
            lines.append("")

        return "\n".join(lines)

    # --- Utility Methods (deprecated) ---

    @deprecated("Clean up sessions manually or use a scheduled task")
    def cleanup_old_sessions(self, max_age_days: int = 30) -> int:
        """Clean up old session files (deprecated).

        Args:
            max_age_days: Maximum age in days.

        Returns:
            Number of files removed (always 0 in compat layer).
        """
        _ = max_age_days
        return 0

    @deprecated("Use BuiltinMemoryProvider.get_stats() instead")
    def stats(self) -> dict[str, Any]:
        """Get statistics about the memory directory (deprecated).

        Returns:
            Dict with counts and sizes.
        """
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return self._empty_stats()

        return asyncio.run(self._stats_async())

    async def _stats_async(self) -> dict[str, Any]:
        """Async implementation of stats."""
        await self._ensure_initialized()
        provider_stats = self._provider.get_stats()

        # Transform to legacy format
        return {
            "decisions": provider_stats.get("in_memory_entries", 0),
            "preferences": 0,
            "team_memories": 0,
            "sessions": 0,
            "feedback": 0,
            "references": 0,
            "provider_stats": provider_stats,
        }

    def _empty_stats(self) -> dict[str, Any]:
        """Return empty stats when in async context."""
        return {
            "decisions": 0,
            "preferences": 0,
            "team_memories": 0,
            "sessions": 0,
            "feedback": 0,
            "references": 0,
        }

    @classmethod
    @deprecated("Use BuiltinMemoryProvider with initialize(project_root=...) instead")
    def from_project_root(cls, project_root: Path | str) -> MemoryDirectoryCompat:
        """Create MemoryDirectoryCompat from project root (deprecated).

        Args:
            project_root: Root directory of the project.

        Returns:
            MemoryDirectoryCompat instance.
        """
        return cls(project_root=project_root)

    # --- Session Management (deprecated) ---

    @deprecated("Sessions are managed automatically by BuiltinMemoryProvider")
    def clear_session(self, session_id: str) -> None:
        """Clear all memories for a session (deprecated).

        Args:
            session_id: Session identifier.
        """
        _ = session_id
        # No-op in compat layer
        pass

    # --- Properties for compatibility ---

    @property
    def paths(self) -> Any:
        """Get legacy paths object (deprecated)."""
        return self._legacy_paths
