"""Agent capabilities system.

This package provides the capability registry for managing pluggable
agent capabilities like memory providers, context engines, and
orchestration engines.

Key components:
- CapabilityType: Enum of capability categories
- AgentCapability: Single capability definition
- AgentCapabilityRegistry: Global singleton registry
- get_capability_registry: Factory function for the registry
"""

from pyclaw.agents.capabilities.registry import AgentCapabilityRegistry, get_capability_registry
from pyclaw.agents.capabilities.types import AgentCapability, CapabilityType

__all__ = [
    "AgentCapability",
    "AgentCapabilityRegistry",
    "CapabilityType",
    "get_capability_registry",
]
