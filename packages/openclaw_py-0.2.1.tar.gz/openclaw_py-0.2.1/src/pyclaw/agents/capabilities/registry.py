"""Agent capability registry - global singleton for capability management.

This module provides the AgentCapabilityRegistry, a thread-safe singleton
that manages capability definitions and their providers.

Design notes:
- The registry acts as a "factory", storing capability definitions and factory functions
- Actual capability instances are created and held by AgentRuntime (session-scoped)
- Supports runtime dynamic registration with thread-safe locking

Lifecycle:
- Registry: Global singleton, application lifecycle
- Capability definitions: Global, change with register/unregister
- Capability instances: Managed by AgentRuntime, session-scoped
"""

from __future__ import annotations

import threading
from typing import Any

from pyclaw.agents.capabilities.types import AgentCapability, CapabilityType


class AgentCapabilityRegistry:
    """Global singleton registry for agent capabilities.

    Thread-safe registry that stores capability definitions and their
    factory functions. Supports registration, unregistration, and
    various query methods.

    Example:
        >>> registry = get_capability_registry()
        >>> registry.register(AgentCapability(
        ...     capability_type=CapabilityType.MEMORY,
        ...     name="builtin",
        ...     description="Built-in memory provider",
        ...     provider=lambda: BuiltinMemoryProvider(),
        ... ))
        >>> cap = registry.get(CapabilityType.MEMORY)
    """

    _instance: AgentCapabilityRegistry | None = None
    _capabilities: dict[CapabilityType, list[AgentCapability]]
    _lock: threading.RLock

    def __new__(cls) -> AgentCapabilityRegistry:
        """Create or return the singleton instance."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._capabilities = {ct: [] for ct in CapabilityType}
            cls._instance._lock = threading.RLock()
        return cls._instance

    def register(self, capability: AgentCapability) -> None:
        """Register a capability (thread-safe).

        Args:
            capability: The capability to register.
        """
        with self._lock:
            # Check for duplicate name within same type
            existing = self.get(capability.capability_type, capability.name)
            if existing:
                # Update existing capability
                caps = self._capabilities[capability.capability_type]
                for i, cap in enumerate(caps):
                    if cap.name == capability.name:
                        caps[i] = capability
                        return
            self._capabilities[capability.capability_type].append(capability)

    def unregister(self, capability_type: CapabilityType, name: str) -> bool:
        """Unregister a capability (thread-safe).

        Args:
            capability_type: The type of capability to unregister.
            name: The name of the capability to unregister.

        Returns:
            True if the capability was found and removed, False otherwise.
        """
        with self._lock:
            caps = self._capabilities[capability_type]
            for i, cap in enumerate(caps):
                if cap.name == name:
                    caps.pop(i)
                    return True
        return False

    def get(self, capability_type: CapabilityType, name: str | None = None) -> AgentCapability | None:
        """Get a capability by type and optionally by name.

        If name is not provided, returns the highest priority capability
        of the given type.

        Args:
            capability_type: The type of capability to get.
            name: Optional specific capability name.

        Returns:
            The matching capability, or None if not found.
        """
        caps = self._capabilities[capability_type]
        if name:
            for cap in caps:
                if cap.name == name:
                    return cap
            return None
        # Return highest priority capability
        return max(caps, key=lambda c: c.priority) if caps else None

    def get_by_metadata(
        self,
        capability_type: CapabilityType,
        **filters: Any,
    ) -> list[AgentCapability]:
        """Filter capabilities by metadata fields.

        Args:
            capability_type: The type of capability to filter.
            **filters: Metadata key-value pairs to match.

        Returns:
            List of matching capabilities.

        Example:
            >>> registry.get_by_metadata(CapabilityType.MEMORY, scope="project")
            >>> registry.get_by_metadata(CapabilityType.MEMORY, plugin_id="my_plugin")
        """
        caps = self._capabilities[capability_type]
        result = []
        for cap in caps:
            match = True
            for key, value in filters.items():
                if cap.metadata.get(key) != value:
                    match = False
                    break
            if match:
                result.append(cap)
        return result

    def get_by_tags(
        self,
        capability_type: CapabilityType,
        tags: set[str],
        match_all: bool = False,
    ) -> list[AgentCapability]:
        """Query capabilities by tags.

        Args:
            capability_type: The type of capability to query.
            tags: Set of tags to match.
            match_all: If True, all tags must match; if False, any tag matches.

        Returns:
            List of matching capabilities.
        """
        caps = self._capabilities[capability_type]
        result = []
        for cap in caps:
            if match_all:
                if tags.issubset(cap.tags):
                    result.append(cap)
            else:
                if tags & cap.tags:  # Has intersection
                    result.append(cap)
        return result

    def list_all(self, capability_type: CapabilityType | None = None) -> list[AgentCapability]:
        """List all capabilities, optionally filtered by type.

        Args:
            capability_type: Optional type to filter by.

        Returns:
            List of all capabilities (of the given type if specified).
        """
        if capability_type:
            return list(self._capabilities[capability_type])
        return [cap for caps in self._capabilities.values() for cap in caps]

    def clear(self) -> None:
        """Clear all registered capabilities (for testing)."""
        with self._lock:
            for ct in CapabilityType:
                self._capabilities[ct] = []


def get_capability_registry() -> AgentCapabilityRegistry:
    """Get the global capability registry singleton.

    Returns:
        AgentCapabilityRegistry instance.
    """
    return AgentCapabilityRegistry()
