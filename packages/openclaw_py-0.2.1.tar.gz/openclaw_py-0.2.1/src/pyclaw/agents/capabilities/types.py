"""Capability types for the agent capability registry.

This module defines the core types for the capability system:
- CapabilityType: Enum of capability categories
- AgentCapability: Single capability definition
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class CapabilityType(str, Enum):
    """Types of capabilities that can be registered.

    Each type represents a distinct category of agent functionality
    that can be provided by different implementations.
    """

    # Legacy types
    MEMORY = "memory"
    CONTEXT = "context"
    ORCHESTRATION = "orchestration"
    KNOWLEDGE = "knowledge"

    # PACS types
    PERCEPTION = "perception"
    REASONING = "reasoning"
    ACTION = "action"
    FEEDBACK = "feedback"


@dataclass
class AgentCapability:
    """Definition of a single capability.

    A capability represents a specific functionality that an agent can use.
    Multiple providers can register capabilities of the same type, with
    priority determining which one is used by default.

    Attributes:
        capability_type: The category of this capability.
        name: Unique identifier for this capability provider.
        description: Human-readable description.
        provider: Factory function that creates the capability instance.
        priority: Priority for selecting among multiple providers (higher wins).
        tags: Flexible query tags for filtering capabilities.
        metadata: Additional metadata for filtering and configuration.
    """

    capability_type: CapabilityType
    name: str
    description: str
    provider: Callable[[], Any]
    priority: int = 0
    tags: set[str] = field(default_factory=set)
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate capability after initialization."""
        if not self.name:
            raise ValueError("Capability name cannot be empty")
        if not self.description:
            raise ValueError("Capability description cannot be empty")
