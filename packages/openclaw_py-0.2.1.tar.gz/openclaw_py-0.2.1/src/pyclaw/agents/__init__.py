"""Agents module — core agent runtime and management components.

This module provides:
- Agent runner and streaming
- Session management
- Subagent management and forking
- Built-in agent types
- Context management
- Memory directory
- Skills system
- Tool registry
- Orchestration
- Coordinator mode
"""

from pyclaw.agents.builtin_agents import (
    EXPLORE_AGENT,
    GENERAL_PURPOSE_AGENT,
    PLAN_AGENT,
    VERIFICATION_AGENT,
    BuiltinAgent,
    BuiltinAgentRegistry,
)
from pyclaw.agents.context import (
    ContextManager,
)
from pyclaw.agents.coordinator import (
    CoordinatorMode,
    CoordinatorTool,
)
from pyclaw.agents.memory_dir import (
    MemoryDirectory,
    MemoryPaths,
)
from pyclaw.agents.runner import run_agent
from pyclaw.agents.session import SessionManager
from pyclaw.agents.skills import (
    SkillEntry,
    load_workspace_skill_entries,
)
from pyclaw.agents.subagents import (
    AgentMemorySnapshot,
    SubagentConfig,
    SubagentManager,
    SubagentResult,
    create_memory_snapshot,
    fork_subagent,
    restore_memory_snapshot,
)
from pyclaw.agents.tools.registry import (
    ToolRegistry,
    UnifiedToolRegistry,
    create_default_tools,
)

__all__ = [
    # Runner
    "run_agent",
    # Session
    "SessionManager",
    # Subagents
    "SubagentManager",
    "SubagentConfig",
    "SubagentResult",
    "fork_subagent",
    "AgentMemorySnapshot",
    "create_memory_snapshot",
    "restore_memory_snapshot",
    # Built-in agents
    "BuiltinAgent",
    "BuiltinAgentRegistry",
    "EXPLORE_AGENT",
    "PLAN_AGENT",
    "VERIFICATION_AGENT",
    "GENERAL_PURPOSE_AGENT",
    # Context
    "ContextManager",
    # Memory directory
    "MemoryDirectory",
    "MemoryPaths",
    # Skills
    "SkillEntry",
    "load_workspace_skill_entries",
    # Tools
    "ToolRegistry",
    "UnifiedToolRegistry",
    "create_default_tools",
    # Coordinator
    "CoordinatorMode",
    "CoordinatorTool",
]
