---
skill_key: openclaw-tracker
description: Track OpenClaw upstream releases and identify features to port to PyClaw.
version: 1.0.0
runtime: python-native
launcher: python-native
security-level: standard
deps: cmd:curl
install: pip install -e ".[dev]"
capability: release-tracking, feature-analysis, porting-guide
healthcheck: curl --version
rollback: Manual tracking via GitHub releases page.
---

# OpenClaw Upstream Tracker

Track OpenClaw (TypeScript/Node.js) releases and identify features worth porting to PyClaw (Python).

## Triggers

Use this skill when:
- User mentions "openclaw", "upstream", "release tracking", "port features"
- User asks to "check OpenClaw releases", "sync from upstream", "what's new in OpenClaw"
- User mentions "借鉴", "同步", "上游更新", "openclaw新功能"

## Quick Reference

| OpenClaw | PyClaw Equivalent | Status |
|----------|-------------------|--------|
| `openclaw skills search/install/update` | `pyclaw skills ...` | Planned |
| `/btw` side questions | `btw_tool.py` | Planned |
| Sandbox backends (OpenShell/SSH) | `src/pyclaw/sandbox/` | Planned |
| Web search (Exa/Tavily/Firecrawl) | `WebSearchProvider` | Planned |
| Per-agent model defaults | `AgentConfig.model/thinking_model/fast_model` | Planned |
| WCAG 2.1 AA accessibility | UI components | Planned |
| CSP script hashing | Gateway middleware | Planned |

## Workflow

### 1. Fetch Latest Releases

```bash
curl -s "https://api.github.com/repos/openclaw/openclaw/releases?per_page=5" | \
python3 -c "
import sys, json
data = json.load(sys.stdin)
for r in data:
    print(f'## {r[\"tag_name\"]} ({r[\"published_at\"][:10]})')
    print(r['body'][:2000])  # Truncate for readability
"
```

### 2. Analyze Features

For each release, identify:

1. **Breaking Changes** → Check if PyClaw has equivalent to migrate
2. **New Features** → Evaluate porting priority
3. **Security Fixes** → Always port to PyClaw
4. **Bug Fixes** → Check if PyClaw has same issue

### 3. Prioritization Matrix

| Priority | Criteria | Examples |
|----------|----------|----------|
| **P0 Critical** | Security fixes, breaking changes affecting users | Webhook security, exec approval hardening |
| **P1 High** | New features with clear value, minimal complexity | `/btw` tool, web search providers |
| **P2 Medium** | Useful but requires significant work | Skills marketplace, sandbox backends |
| **P3 Low** | Nice to have, long-term consideration | Plugin marketplace, native mobile apps |

### 4. Create Porting Plan

Document in `docs/plans/openclaw-features-analysis.md`:

```markdown
### Feature: [Name]
**Source**: v2026.x.x
**Priority**: P0/P1/P2/P3
**PyClaw Target**: [module/path]

**Implementation**:
1. [Step 1]
2. [Step 2]

**Dependencies**:
- [Dep 1]
- [Dep 2]
```

## Key Files

| File | Purpose |
|------|---------|
| `docs/plans/openclaw-features-analysis.md` | Full analysis document |
| `src/pyclaw/skills/` | Skills marketplace implementation |
| `src/pyclaw/sandbox/` | Sandbox backends |
| `src/pyclaw/tools/web_search.py` | Web search providers |
| `src/pyclaw/security/exec_approval.py` | Exec security |

## Architecture Mapping

| OpenClaw (TypeScript) | PyClaw (Python) |
|-----------------------|-----------------|
| `src/agents/` | `src/pyclaw/agents/` |
| `src/gateway/` | `src/pyclaw/gateway/` |
| `src/plugins/` | `src/pyclaw/channels/` + MCP servers |
| `src/channels/` | `src/pyclaw/channels/` |
| `src/cli/` | `src/pyclaw/cli/` |
| `src/ui/` | `apps/web/` + `apps/desktop/` + `apps/mobile/` (TypeScript) |
| `src/config/` | `src/pyclaw/config/` |
| `src/security/` | `src/pyclaw/security/` |

## Notable Features Already Analyzed

### v2026.3.23 (2026-03-23)
- ModelStudio/Qwen: DashScope endpoints for China/global
- UI/clarity: Button primitives, Knot theme, WCAG 2.1 AA
- CSP/Control UI: SHA-256 script hashing
- CLI/channel auth: Auto-select single channel
- Auth/OpenAI tokens: Fix credential revert bug

### v2026.3.22 (2026-03-23)
- **ClawHub Skills**: Native `skills search/install/update`
- **Plugins Marketplace**: Claude/Codex/Cursor bundle support
- **`/btw` Command**: Side questions without context pollution
- **Sandbox Backends**: OpenShell, SSH remote execution
- **Web Search**: Exa, Tavily, Firecrawl providers
- **Per-Agent Models**: thinking_model, fast_model, reasoning_model

### v2026.3.13 (2026-03-14)
- Browser act automation: batched actions, selector targeting
- Docker timezone: OPENCLAW_TZ support
- Security: Device pairing single-use codes
- Security: Webhook pre-auth limits (64KB/5s)

## Security Focus Areas

Always port these from OpenClaw releases:

1. **Exec Approval**
   - Transparent wrapper handling (`time`, `nice`)
   - Blocked env vars (`MAVEN_OPTS`, `GLIBC_TUNABLES`)
   - PowerShell `-File` recognition

2. **Webhook Security**
   - Pre-auth body limit: 64 KB
   - Pre-auth timeout: 5 seconds
   - Per-IP concurrent request limits
   - Signature validation before body read

3. **Content Security**
   - CSP headers with script hashing
   - Zero-width character stripping
   - External content markers

## Quick Commands

```bash
# Check latest 5 releases
curl -s "https://api.github.com/repos/openclaw/openclaw/releases?per_page=5" | python3 -m json.tool

# View specific release
curl -s "https://api.github.com/repos/openclaw/openclaw/releases/tags/v2026.3.22" | python3 -m json.tool

# Check unreleased changes
curl -s "https://api.github.com/repos/openclaw/openclaw/releases" | python3 -c "
import sys, json
data = json.load(sys.stdin)
print('Latest:', data[0]['tag_name'])
print('Published:', data[0]['published_at'])
"
```

## Output Template

When analyzing releases, output:

```markdown
## OpenClaw vX.Y.Z Analysis

### Breaking Changes
- [Change 1] → PyClaw action: [migrate/ignore/NA]

### New Features
- [Feature 1] → Priority: P[0-3], Target: [module]

### Security Fixes
- [Fix 1] → **PORT IMMEDIATELY**

### Recommended Actions
1. [Action 1]
2. [Action 2]
```
