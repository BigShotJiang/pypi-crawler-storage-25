#!/usr/bin/env python3
"""Generate daily session summary — runnable by cron scheduler.

Usage:
    python scripts/daily_summary_job.py [--date YYYY-MM-DD]

This script is designed to be invoked by the cron scheduler at 8 AM daily.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def get_state_dir() -> Path:
    """Get the pyclaw state directory."""
    state_dir = Path.home() / ".pyclaw"
    state_dir.mkdir(parents=True, exist_ok=True)
    return state_dir


def get_sessions_dir() -> Path:
    """Get the sessions directory."""
    return get_state_dir() / "sessions"


def find_session_files(target_date: str) -> list[Path]:
    """Find all session files for the target date.

    Sessions are stored as JSONL files with date-based sharding.
    File naming: sessions_YYYY-MM-DD.jsonl or similar patterns.
    """
    sessions_dir = get_sessions_dir()
    if not sessions_dir.exists():
        return []

    session_files = []

    # Pattern 1: Date-sharded files (sessions_2026-04-17.jsonl)
    for f in sessions_dir.glob(f"*{target_date}*.jsonl"):
        session_files.append(f)

    # Pattern 2: All session files, filter by date in content
    if not session_files:
        for f in sessions_dir.glob("*.jsonl"):
            session_files.append(f)

    return session_files


def parse_session_file(file_path: Path, target_date: str | None = None) -> dict:
    """Parse a session file and extract relevant data."""
    messages = []
    metadata = {"file": str(file_path), "session_id": file_path.stem}

    try:
        with open(file_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    # Filter by date if specified
                    if target_date:
                        ts = entry.get("timestamp", "")
                        if target_date not in ts:
                            continue
                    messages.append(entry)
                except json.JSONDecodeError:
                    continue
    except Exception as e:
        logger.warning("Failed to parse %s: %s", file_path, e)

    return {"metadata": metadata, "messages": messages}


def extract_highlights(messages: list[dict]) -> dict:
    """Extract key information from messages."""
    user_messages = []
    assistant_messages = []
    tool_calls = []
    topics = set()

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")

        if role == "user" and content:
            user_messages.append(content[:200])  # Truncate long messages
        elif role == "assistant" and content:
            assistant_messages.append(content[:200])
        elif role == "tool" or msg.get("tool_call_id"):
            tool_name = msg.get("name", "unknown")
            tool_calls.append(tool_name)

        # Extract potential topics (keywords)
        content_lower = content.lower()
        topic_keywords = [
            "roadmap",
            "plan",
            "task",
            "feature",
            "bug",
            "fix",
            "implement",
            "design",
            "review",
            "deploy",
            "test",
            "error",
            "issue",
            "problem",
            "solution",
            "idea",
        ]
        for kw in topic_keywords:
            if kw in content_lower:
                topics.add(kw)

    return {
        "user_messages": user_messages,
        "assistant_messages": assistant_messages,
        "tool_calls": list(set(tool_calls)),
        "topics": list(topics),
        "total_messages": len(messages),
    }


def generate_summary(target_date: str) -> dict:
    """Generate a complete daily summary."""
    logger.info("Generating summary for %s", target_date)

    session_files = find_session_files(target_date)
    logger.info("Found %d session file(s)", len(session_files))

    all_sessions = []
    all_highlights = {
        "user_messages": [],
        "assistant_messages": [],
        "tool_calls": [],
        "topics": set(),
        "total_messages": 0,
    }

    for sf in session_files:
        session_data = parse_session_file(sf, target_date)
        if session_data["messages"]:
            all_sessions.append(session_data["metadata"]["session_id"])
            highlights = extract_highlights(session_data["messages"])
            all_highlights["user_messages"].extend(highlights["user_messages"])
            all_highlights["assistant_messages"].extend(highlights["assistant_messages"])
            all_highlights["tool_calls"].extend(highlights["tool_calls"])
            all_highlights["topics"].update(highlights["topics"])
            all_highlights["total_messages"] += highlights["total_messages"]

    summary = {
        "date": target_date,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "sessions": {
            "count": len(all_sessions),
            "ids": all_sessions[:20],  # Limit to 20
        },
        "messages": {
            "total": all_highlights["total_messages"],
            "user_count": len(all_highlights["user_messages"]),
            "assistant_count": len(all_highlights["assistant_messages"]),
        },
        "tools_used": list(set(all_highlights["tool_calls"]))[:10],
        "topics": list(all_highlights["topics"]),
        "sample_user_messages": all_highlights["user_messages"][:5],
        "sample_assistant_messages": all_highlights["assistant_messages"][:5],
    }

    return summary


def format_summary_markdown(summary: dict) -> str:
    """Format summary as markdown."""
    lines = [
        f"# Daily Session Summary: {summary['date']}",
        "",
        f"**Generated:** {summary['generated_at']}",
        "",
        "## 📊 Overview",
        "",
        f"- **Sessions:** {summary['sessions']['count']}",
        f"- **Messages:** {summary['messages']['total']}",
        f"- **User messages:** {summary['messages']['user_count']}",
        f"- **Assistant messages:** {summary['messages']['assistant_count']}",
        "",
    ]

    if summary["tools_used"]:
        lines.extend(
            [
                "## 🔧 Tools Used",
                "",
            ]
        )
        for tool in summary["tools_used"][:10]:
            lines.append(f"- `{tool}`")
        lines.append("")

    if summary["topics"]:
        lines.extend(
            [
                "## 📝 Topics",
                "",
            ]
        )
        for topic in sorted(summary["topics"])[:10]:
            lines.append(f"- {topic}")
        lines.append("")

    if summary["sample_user_messages"]:
        lines.extend(
            [
                "## 💬 Sample Messages",
                "",
                "### User:",
                "",
            ]
        )
        for msg in summary["sample_user_messages"][:3]:
            lines.append(f"> {msg[:100]}...")
        lines.append("")

    return "\n".join(lines)


def save_summary_to_memory(summary: dict) -> None:
    """Save summary to memory store."""
    state_dir = get_state_dir()
    memory_dir = state_dir / "memory"
    memory_dir.mkdir(parents=True, exist_ok=True)

    # Save as JSON
    summary_file = memory_dir / f"daily_summary_{summary['date']}.json"
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    logger.info("Saved summary to %s", summary_file)

    # Save as markdown
    md_file = memory_dir / f"daily_summary_{summary['date']}.md"
    md_content = format_summary_markdown(summary)
    with open(md_file, "w", encoding="utf-8") as f:
        f.write(md_content)

    logger.info("Saved markdown to %s", md_file)


async def run_job(target_date: str | None = None) -> dict:
    """Main job entry point for cron scheduler."""
    if not target_date:
        # Default to yesterday
        yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%d")
        target_date = yesterday

    summary = generate_summary(target_date)
    save_summary_to_memory(summary)

    return {
        "status": "ok",
        "date": target_date,
        "sessions": summary["sessions"]["count"],
        "messages": summary["messages"]["total"],
    }


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="Generate daily session summary")
    parser.add_argument(
        "--date",
        help="Target date (YYYY-MM-DD), defaults to yesterday",
        default=None,
    )
    parser.add_argument(
        "--output",
        choices=["json", "markdown", "both"],
        default="both",
        help="Output format",
    )
    args = parser.parse_args()

    target_date = args.date
    if not target_date:
        target_date = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%d")

    result = asyncio.run(run_job(target_date))

    if args.output in ("json", "both"):
        print(json.dumps(result, indent=2))

    logger.info("Summary complete: %d sessions, %d messages", result["sessions"], result["messages"])


if __name__ == "__main__":
    main()
