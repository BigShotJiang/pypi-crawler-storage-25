---
skill_key: daily-session-summary
description: Generate a daily summary of all chat sessions and store in memory.
version: 1.0.0
emoji: 📊
homepage: https://github.com/chensaics/openclaw-py
runtime: python-native
launcher: python-native
security-level: standard
deps: none
userInvocable: true
disableModelInvocation: false
capability: session-analysis, memory, cron
install: none
healthcheck: python -c "from pyclaw.memory.daily_summary import DailySummaryService; print('ok')"
---

# Daily Session Summary Skill

Generate a daily summary of all chat sessions and store in memory.

## What This Skill Does

- Scans all session files from the previous day (or specified date)
- Extracts highlights: key topics, decisions, and actions
- Consolidates into a structured summary
- Stores in memory for later retrieval

## Available Tools

- **daily_summary_generate** — Generate summary for a specific date
- **daily_summary_list** — List available daily summaries

## Usage

> "Generate a summary of yesterday's sessions"
> "Summarize all sessions from 2026-04-15"
> "What did I work on last week?"

## Cron Integration

This skill can be scheduled as a cron job:

```bash
# Add daily 8 AM summary task
pyclaw cron add \
  --name "Daily Session Summary" \
  --schedule "0 8 * * *" \
  --handler daily-session-summary \
  --message "Summarize yesterday's sessions"
```

## Example Output

```markdown
# Daily Summary: 2026-04-17

## Sessions: 5
- session-abc123
- session-def456
- ...

## Key Topics
- PyClaw roadmap planning
- Onboarding wizard improvements
- Skill discovery TUI design

## Decisions Made
- Use ICE scoring for prioritization
- Defer SSO and multi-tenant features
- Focus on TypeScript client development

## Actions Taken
- Created prioritization-recommendation.md
- Created roadmap-action-plan.md
- Installed jobs-to-be-done skill
```

## Configuration

Add to `pyclaw.json`:

```json
{
  "cron": {
    "jobs": [
      {
        "id": "daily-summary",
        "name": "Daily Session Summary",
        "schedule": "0 8 * * *",
        "handlerId": "daily-session-summary",
        "enabled": true
      }
    ]
  }
}
```
