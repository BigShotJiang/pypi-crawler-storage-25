# How to Add Daily Session Summary Cron Task

## Quick Setup

### Option 1: Add to Config File

Add to `~/.pyclaw/pyclaw.json`:

```json
{
  "cron": {
    "jobs": [
      {
        "id": "daily-summary-8am",
        "name": "Daily Session Summary",
        "schedule": "0 8 * * *",
        "scheduleType": "cron",
        "handlerId": "daily-session-summary",
        "message": "Generate daily summary of all sessions",
        "enabled": true
      }
    ]
  }
}
```

### Option 2: Via CLI

```bash
pyclaw cron add \
  --id daily-summary-8am \
  --name "Daily Session Summary" \
  --schedule "0 8 * * *" \
  --handler daily-session-summary \
  --enabled
```

### Option 3: Via Gateway RPC

Using WebSocket connection:

```json
{
  "type": "request",
  "id": "req-001",
  "method": "cron.add",
  "params": {
    "name": "Daily Session Summary",
    "schedule": "0 8 * * *",
    "scheduleType": "cron",
    "handlerId": "daily-session-summary",
    "enabled": true
  }
}
```

---

## Cron Schedule Reference

| Schedule | Meaning |
|----------|---------|
| `0 8 * * *` | Every day at 8:00 AM UTC |
| `0 8 * * 1-5` | Weekdays at 8:00 AM UTC |
| `30 9 * * *` | Every day at 9:30 AM UTC |

Format: `minute hour day month weekday`

---

## Manual Test

Run the summary job manually:

```bash
# Summarize yesterday
python skills/daily-session-summary/scripts/daily_summary_job.py

# Summarize a specific date
python skills/daily-session-summary/scripts/daily_summary_job.py --date 2026-04-15
```

---

## Output Location

Summaries are saved to:

```
~/.pyclaw/memory/
├── daily_summary_2026-04-17.json
├── daily_summary_2026-04-17.md
├── daily_summary_2026-04-18.json
└── ...
```

---

## View Cron Jobs

```bash
# List all cron jobs
pyclaw cron list

# Check job status
pyclaw cron history --job daily-summary-8am
```

---

## Integration with Memory

The summary is stored in memory and can be queried:

```python
from pyclaw.memory.store import MemoryStore

store = MemoryStore()
summary = store.get_daily_summary("2026-04-17")
```

Or via the agent:

> "What did I work on yesterday?"
> "Show me the summary for 2026-04-15"
