# Lightpanda Browser Automation

> Ultra-fast headless browser for AI agents, web scraping, and automation testing

---

## Overview

**Lightpanda** is a headless browser built from scratch in Zig, designed specifically for AI agents and automation. Unlike Chromium-based browsers, it's optimized for performance:

| Metric | Lightpanda vs Chrome |
|--------|---------------------|
| Memory | **9x less** than Chrome |
| Speed | **11x faster** than Chrome |
| Startup | Instant |

### Key Features

- JavaScript execution (V8 engine)
- Web APIs (partial, WIP)
- CDP (Chrome DevTools Protocol) support
- Compatible with **Puppeteer**, **Playwright**, **chromedp**
- HTTP/HTTPS loading (Libcurl)
- HTML5 parsing (html5ever)
- DOM APIs, Ajax (XHR + Fetch)
- Cookies, Custom headers, Proxy support
- Network interception
- `robots.txt` support

### Status

Lightpanda is in **Beta** - stability and coverage are improving. Some websites may still have issues.

---

## When to Use

TRIGGER this skill when:
- Web automation testing is needed
- Web scraping with JavaScript rendering
- AI agent web browsing tasks
- Headless browser testing
- Performance-critical browser automation
- User mentions: `lightpanda`, `headless browser`, `web automation`, `browser testing`, `scraping`

DO NOT trigger for:
- Full browser UI testing (use Chrome/Firefox)
- Visual rendering verification
- Advanced CSS/layout testing

---

## Installation

### Option 1: Binary (Recommended)

**Linux x86_64:**
```bash
curl -L -o lightpanda https://github.com/lightpanda-io/browser/releases/download/nightly/lightpanda-x86_64-linux && \
chmod a+x ./lightpanda
```

**macOS aarch64:**
```bash
curl -L -o lightpanda https://github.com/lightpanda-io/browser/releases/download/nightly/lightpanda-aarch64-macos && \
chmod a+x ./lightpanda
```

**Windows + WSL2:**
Run inside WSL following Linux instructions.

### Option 2: Docker

```bash
docker run -d --name lightpanda -p 9222:9222 lightpanda/browser:nightly
```

### Option 3: Build from Source

Prerequisites:
- Zig 0.15.2
- Rust (for html5ever)
- Build tools (cmake, clang, make)

```bash
# Debian/Ubuntu
sudo apt install xz-utils ca-certificates pkg-config libglib2.0-dev clang make curl git

# Clone and build
git clone https://github.com/lightpanda-io/browser.git
cd browser
make build
```

---

## Usage Patterns

### 1. Dump a URL (CLI)

```bash
./lightpanda fetch --obey-robots --log-format pretty --log-level info https://example.com
```

### 2. Start CDP Server

```bash
./lightpanda serve --obey-robots --host 127.0.0.1 --port 9222
```

### 3. Puppeteer Integration

```javascript
import puppeteer from 'puppeteer-core';

const browser = await puppeteer.connect({
    browserWSEndpoint: "ws://127.0.0.1:9222",
});

const context = await browser.createBrowserContext();
const page = await context.newPage();

await page.goto('https://example.com', {waitUntil: 'networkidle0'});

// Extract data
const links = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('a')).map(a => a.href);
});

console.log(links);

await page.close();
await context.close();
await browser.disconnect();
```

### 4. Playwright Integration

```javascript
import { chromium } from 'playwright-core';

const browser = await chromium.connectOverCDP('ws://127.0.0.1:9222');
const context = await browser.newContext();
const page = await context.newPage();

await page.goto('https://example.com');

// Take actions
await page.click('button.submit');
await page.fill('input[name="email"]', 'test@example.com');

await context.close();
await browser.close();
```

### 5. Python with Pyppeteer

```python
import asyncio
from pyppeteer import connect

async def main():
    browser = await connect(browserWSEndpoint='ws://127.0.0.1:9222')
    page = await browser.newPage()

    await page.goto('https://example.com')
    content = await page.content()

    print(content)

    await browser.disconnect()

asyncio.run(main())
```

---

## Common Automation Tasks

### Form Handling

```javascript
// Fill and submit form
await page.goto('https://example.com/form');
await page.type('#username', 'user123');
await page.type('#password', 'pass456');
await page.click('button[type="submit"]');

// Wait for navigation
await page.waitForNavigation({ waitUntil: 'networkidle0' });
```

### Extract Page Content

```javascript
// Get all text
const text = await page.evaluate(() => document.body.innerText);

// Get specific elements
const data = await page.evaluate(() => {
    return {
        title: document.querySelector('h1')?.textContent,
        links: Array.from(document.querySelectorAll('a')).map(a => ({
            text: a.textContent,
            href: a.href
        }))
    };
});
```

### Handle Dynamic Content

```javascript
// Wait for element
await page.waitForSelector('.dynamic-content', { timeout: 5000 });

// Wait for network idle
await page.goto(url, { waitUntil: 'networkidle0' });

// Wait for function
await page.waitForFunction(
    () => document.querySelector('.status')?.textContent === 'Ready'
);
```

### Cookie Management

```javascript
// Get cookies
const cookies = await page.cookies();

// Set cookies
await page.setCookie({
    name: 'session',
    value: 'abc123',
    domain: 'example.com'
});
```

### Request Interception

```javascript
await page.setRequestInterception(true);

page.on('request', request => {
    if (request.url().includes('analytics')) {
        request.abort();  // Block tracking
    } else {
        request.continue();
    }
});
```

### Screenshot (if supported)

```javascript
await page.screenshot({ path: 'screenshot.png' });
```

---

## Python Project Integration

### With Pyppeteer

```python
# requirements.txt
pyppeteer>=1.0.0

# automation.py
import asyncio
from pyppeteer import connect

class LightpandaClient:
    def __init__(self, endpoint='ws://127.0.0.1:9222'):
        self.endpoint = endpoint
        self.browser = None

    async def connect(self):
        self.browser = await connect(browserWSEndpoint=self.endpoint)

    async def close(self):
        if self.browser:
            await self.browser.disconnect()

    async def fetch_page(self, url: str) -> str:
        page = await self.browser.newPage()
        await page.goto(url, waitUntil='networkidle0')
        content = await page.content()
        await page.close()
        return content

    async def extract_links(self, url: str) -> list[str]:
        page = await self.browser.newPage()
        await page.goto(url)
        links = await page.evaluate('''
            () => Array.from(document.querySelectorAll('a'))
                .map(a => a.href)
        ''')
        await page.close()
        return links

# Usage
async def main():
    client = LightpandaClient()
    await client.connect()

    content = await client.fetch_page('https://example.com')
    print(content)

    await client.close()

asyncio.run(main())
```

### With Selenium (via CDP)

```python
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_experimental_option('debuggerAddress', '127.0.0.1:9222')

driver = webdriver.Chrome(options=options)
driver.get('https://example.com')
```

---

## CLI Commands Reference

| Command | Description |
|---------|-------------|
| `./lightpanda fetch <url>` | Fetch and dump page content |
| `./lightpanda serve` | Start CDP server |
| `./lightpanda --help` | Show help |

### Common Flags

| Flag | Description |
|------|-------------|
| `--host <ip>` | CDP server host (default: 127.0.0.1) |
| `--port <port>` | CDP server port (default: 9222) |
| `--obey-robots` | Respect robots.txt |
| `--log-format <format>` | Log format: pretty, json |
| `--log-level <level>` | Log level: info, debug, warn, error |
| `--proxy <url>` | Proxy server URL |
| `--insecure-disable-tls-host-verification` | Skip TLS verification |

---

## Telemetry

By default, Lightpanda collects usage telemetry. Disable with:

```bash
export LIGHTPANDA_DISABLE_TELEMETRY=true
```

---

## Limitations & Workarounds

### Not Yet Supported

- Full visual rendering
- Complex CSS layouts
- All Web APIs (coverage improving)
- Screenshots (partial support)

### Playwright Compatibility

Playwright scripts may need adjustment as Lightpanda adds new Web APIs. If a script breaks:
1. Check GitHub issues for known problems
2. Try a different wait strategy
3. Use `waitForFunction` instead of `waitForSelector`

### Debugging Tips

1. Enable verbose logging:
   ```bash
   ./lightpanda serve --log-level debug --log-format pretty
   ```

2. Check CDP connection:
   ```bash
   curl http://127.0.0.1:9222/json/version
   ```

3. Inspect pages:
   ```bash
   curl http://127.0.0.1:9222/json/list
   ```

---

## Resources

- **GitHub**: https://github.com/lightpanda-io/browser
- **Website**: https://lightpanda.io
- **Demos**: https://github.com/lightpanda-io/demo
- **Discord**: https://discord.gg/K63XeymfB5
- **Twitter**: https://twitter.com/lightpanda_io

---

## Comparison: Lightpanda vs Chrome vs Playwright

| Feature | Lightpanda | Chrome | Playwright |
|---------|------------|--------|------------|
| Memory | ~50MB | ~450MB | ~500MB |
| Startup | < 100ms | ~1s | ~1.5s |
| JS Execution | ✅ | ✅ | ✅ |
| Visual Rendering | ❌ | ✅ | ✅ |
| Screenshots | ⚠️ Partial | ✅ | ✅ |
| All Web APIs | ⚠️ WIP | ✅ | ✅ |
| AI/Scraping | ✅ Best | ⚠️ Heavy | ⚠️ Heavy |

**Recommendation**: Use Lightpanda for AI agents, scraping, and headless automation. Use Chrome/Playwright for visual testing.
