#!/usr/bin/env node

/**
 * OpenClaw Task Runner
 * 基于 clicking 执行 ADB/HDC/WEB 设备自动化任务
 * 以流式输出每步执行结果，供 Agent 读取并呈现给用户
 *
 * Usage:
 *   node run-task.mjs --type adb --device-id emulator-5554 --instruction "打开设置"
 *   node run-task.mjs --type hdc --device-id FMR0223C13000649 --instruction "打开设置"
 *   node run-task.mjs --type web --instruction "打开淘宝搜索 apple"
 */

import { spawn as cpSpawn, execSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SKILL_ROOT = path.resolve(__dirname, "..");

/**
 * 尝试从本地或全局加载 clicking
 */
async function tryImport() {
	try {
		return await import("clicking");
	} catch {
		const globalRoot = execSync("npm root -g", { encoding: "utf-8" }).trim();
		const globalPath = path.join(globalRoot, "clicking", "dist", "index.js");
		return await import(globalPath);
	}
}

/**
 * 加载 clicking：加载失败时自动安装，安装后重新加载
 * 加载成功后后台检查更新（不阻塞）
 */
async function loadClicking() {
	try {
		const mod = await tryImport();
		// 加载成功，后台静默更新到最新版
		try {
			const child = cpSpawn("npm", ["install", "-g", "clicking@latest", "--registry=https://registry.anpm.example.com"], {
				stdio: "ignore",
				detached: true,
				shell: true,
			});
			child.unref();
		} catch {}
		return mod;
	} catch {
		// 首次缺失，同步安装
		console.log("[SETUP] clicking 未安装，正在自动安装...");
		try {
			execSync("npm install -g clicking --registry=https://registry.anpm.example.com", { stdio: "inherit", timeout: 60000 });
			console.log("[SETUP] 安装完成");
			return await tryImport();
		} catch (e) {
			console.error(`[ERROR] clicking 安装失败: ${e.message}`);
			process.exit(100);
		}
	}
}

const { TaskEngine, EVENTS } = await loadClicking();

// 静默 npm 包内部日志，只保留 out() 的结构化输出以减少 token 消耗
const _noop = () => {};
console.log = _noop;
console.debug = _noop;
console.info = _noop;
console.warn = _noop;
// 保留 console.error 用于致命错误

// ===================== Arg Parsing =====================

function parseArgs(argv) {
	const args = {};
	for (let i = 0; i < argv.length; i++) {
		if (argv[i].startsWith("--")) {
			const key = argv[i].slice(2);
			const next = argv[i + 1];
			if (next && !next.startsWith("--")) {
				args[key] = next;
				i++;
			} else {
				args[key] = true;
			}
		}
	}
	return args;
}

const args = parseArgs(process.argv.slice(2));
const deviceType = args.type;
const deviceId = args["device-id"];
const instruction = args.instruction;
const loginHost = args["login-host"] || "login.example.com";
const defaultUrl = args["default-url"];
const taskTimeout = parseInt(args.timeout || "600000", 10);

if (!deviceType || !instruction) {
	console.error(
		'Usage: node run-task.mjs --type <adb|hdc|web> --instruction "<指令>" [--device-id <id>]',
	);
	process.exit(1);
}

if (!["adb", "hdc", "web"].includes(deviceType)) {
	console.error(`Error: 不支持的设备类型 "${deviceType}"，可选: adb, hdc, web`);
	process.exit(1);
}

if ((deviceType === "adb" || deviceType === "hdc") && !deviceId) {
	console.error(`Error: --device-id is required for ${deviceType} tasks`);
	process.exit(1);
}

// ===================== Output Helpers =====================

function out(line) {
	process.stdout.write(line + "\n");
}

function formatDuration(ms) {
	if (!ms) return "0ms";
	if (ms < 1000) return `${ms}ms`;
	if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
	const min = Math.floor(ms / 60000);
	const sec = Math.floor((ms % 60000) / 1000);
	return `${min}m ${sec}s`;
}

function extractSummary(response) {
	if (!response) return "(no response)";
	const match = response.match(/Summary:\s*([\s\S]*?)(?:\n\n|$)/i);
	if (match) return match[1].trim();
	const lines = response.split("\n").filter((l) => l.trim());
	return lines[lines.length - 1]?.trim() || response.substring(0, 200);
}

function formatActions(actions) {
	if (!actions || actions.length === 0) return "    (no actions)";
	return actions
		.map((a) => {
			const type = a.action_type || "unknown";
			const params = a.action_param || {};
			const paramStr =
				Object.keys(params).length > 0 ? " " + JSON.stringify(params) : "";
			return `    - ${type}${paramStr}`;
		})
		.join("\n");
}

// ===================== Async Iterable Channel =====================

class StepChannel {
	constructor() {
		this._queue = [];
		this._resolve = null;
		this._done = false;
	}

	push(item) {
		if (this._done) return;
		if (this._resolve) {
			const r = this._resolve;
			this._resolve = null;
			r({ value: item, done: false });
		} else {
			this._queue.push(item);
		}
	}

	end() {
		this._done = true;
		if (this._resolve) {
			const r = this._resolve;
			this._resolve = null;
			r({ value: undefined, done: true });
		}
	}

	[Symbol.asyncIterator]() {
		return {
			next: () => {
				if (this._queue.length > 0) {
					return Promise.resolve({ value: this._queue.shift(), done: false });
				}
				if (this._done) {
					return Promise.resolve({ value: undefined, done: true });
				}
				return new Promise((resolve) => {
					this._resolve = resolve;
				});
			},
		};
	}
}

// ===================== Web Device Setup =====================

async function setupWebDevice(engine) {
	const chromeCheck = await engine.webDeviceService.checkChrome();
	if (!chromeCheck.installed) {
		console.error(`[ERROR] Chrome 未安装: ${chromeCheck.error}`);
		process.exit(1);
	}

	const devices = await engine.webDeviceService.getDevices();

	let targetDevice;
	if (devices.length > 0) {
		targetDevice = devices[0];
	} else {
		const createResult = await engine.webDeviceService.createDevice(
			"__NEW__",
			"点点助手 自动设备",
		);
		if (!createResult.success) {
			console.error(`[ERROR] 创建设备失败: ${createResult.error}`);
			process.exit(1);
		}
		targetDevice = createResult.device;
	}

	const status = await engine.webDeviceService.getBrowserStatus(
		targetDevice.deviceCode,
	);
	if (!status?.running) {
		const launchResult = await engine.webDeviceService.launchBrowser(
			targetDevice.deviceCode,
			{
				url: defaultUrl,
			},
		);
		if (!launchResult.success) {
			console.error(`[ERROR] 浏览器启动失败: ${launchResult.error}`);
			process.exit(1);
		}
	}

	return targetDevice.deviceCode;
}

// ===================== Main =====================

async function main() {
	const engineConfig = {
		web: { loginHost, defaultUrl },
		report: {
			templatePath: path.join(SKILL_ROOT, "templates", "report-template.html"),
		},
	};

	const engine = new TaskEngine(engineConfig);
	engine.webExecutor.loginWaitTimeout = 300000;

	const channel = new StepChannel();

	engine.on(
		EVENTS.TASK.STEP_COMPLETE,
		({ stepNumber, response }) => {
			out(`[STEP ${stepNumber}] ${extractSummary(response)}`);
		},
	);

	engine.on(EVENTS.TASK.LOG, ({ message }) => {
		if (message?.includes("登录过期") || message?.includes("登录页")) {
			out(`\n⚠️ [LOGIN REQUIRED] ${message}`);
			out(
				"⚠️ [LOGIN REQUIRED] 请在弹出的浏览器窗口中完成登录，脚本将自动等待...",
			);
		}
		if (message?.includes("登录成功")) {
			out(`✅ [LOGIN OK] ${message}`);
		}
	});

	engine.on(EVENTS.TASK.STATUS_CHANGED, (ev) => {
		if (["completed", "failed", "stopped"].includes(ev.status)) {
			channel.push({
				status: ev.status,
				success: ev.data?.success,
				message: ev.data?.message,
				reportUrl: ev.data?.reportUrl,
				duration: ev.data?.duration,
				totalSteps: ev.data?.totalSteps,
			});
			channel.end();
		}
	});

	// Resolve device
	let resolvedDeviceId = deviceId;
	let engineDeviceType = deviceType;

	if (deviceType === "adb") {
		engineDeviceType = "android";
	} else if (deviceType === "hdc") {
		engineDeviceType = "harmony";
	} else if (deviceType === "web") {
		resolvedDeviceId = await setupWebDevice(engine);
	}

	const startResult = await engine.startTask(
		resolvedDeviceId,
		instruction,
		engineDeviceType,
	);
	if (!startResult.success) {
		out(`[ERROR] 任务启动失败: ${startResult.error}`);
		engine.destroy();
		process.exit(1);
	}

	const timeoutTimer = setTimeout(() => {
		out(`\n[TIMEOUT] 任务执行超时 (${formatDuration(taskTimeout)})`);
		engine.stopTask(resolvedDeviceId);
	}, taskTimeout);

	for await (const result of channel) {
		clearTimeout(timeoutTimer);

		const isSuccess = result.status === "completed" && result.success;
		const header = isSuccess ? "[TASK COMPLETE]" : "[TASK FAILED]";

		out(`\n${header} ======================================`);
		out(
			`  Status: ${result.status}${result.success != null ? ` (success=${result.success})` : ""}`,
		);
		out(`  Message: ${result.message || "-"}`);
		out(`  Total Steps: ${result.totalSteps || 0}`);
		out(`  Duration: ${formatDuration(result.duration)}`);
		if (result.reportUrl) {
			out(`  Report: ${result.reportUrl}`);
		}
	}

	if (deviceType === "web" && resolvedDeviceId) {
		try {
			await engine.webDeviceService.closeBrowser(resolvedDeviceId);
		} catch {}
	}

	engine.destroy();
	process.exit(0);
}

main().catch((err) => {
	console.error(`[FATAL] ${err.message}`);
	console.error(err.stack);
	process.exit(1);
});
