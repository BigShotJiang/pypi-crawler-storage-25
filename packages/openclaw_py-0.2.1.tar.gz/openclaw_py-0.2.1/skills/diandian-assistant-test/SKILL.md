---
name: diandian-assistant
description: 自动化操作浏览器、手机、鸿蒙设备。支持 WEB (Chrome)、ADB (Android)、HDC (HarmonyOS)。当用户要求浏览器操作、手机操作、查询网页信息、自动化任务时使用此 skill。
---

# 点点助手 设备自动化任务

执行 ADB / HDC / WEB 三种设备的自动化任务。

## 约定

本文档中 **skill 根目录**指 SKILL.md 所在目录；平台若下发 **绝对路径**（如 `.../.skills/<uuid>`），则以其为命令的 **工作目录**（与 `$SKILL_DIR` 等价）。

---

## ADB 任务工作流

### 1. 检测 ADB

```bash
adb version 2>&1
```

**如果 adb 不可用**：使用 AskQuestion 询问用户：

- 选项 A：自动下载安装 ADB（推荐）
- 选项 B：取消

用户选 A 时执行（macOS）：

```bash
curl -L -o /tmp/platform-tools.zip https://dl.google.com/android/repository/platform-tools-latest-darwin.zip
unzip -o /tmp/platform-tools.zip -d /usr/local/share/ && rm /tmp/platform-tools.zip
export PATH="/usr/local/share/platform-tools:$PATH"
adb version
```

Windows 替换 URL 为 `platform-tools-latest-windows.zip`，Linux 为 `platform-tools-latest-linux.zip`。

### 2. 检测设备

```bash
adb devices
```

解析输出，取状态为 `device` 的第一个设备 ID。若无设备，提示用户：

> 未检测到已连接的 Android 设备。请通过 USB 连接设备并开启 USB 调试，然后重试。

### 3. 检测/安装 ADB Keyboard

```bash
adb -s <DEVICE_ID> shell pm list packages | grep adbkeyboard
```

若未安装：

```bash
curl -o /tmp/ADBKeyboard.apk 'http://imqafile.oss-cn-hangzhou-zmf.aliyuncs.com/DianDianPlugin/ADBKeyboard.apk'
adb -s <DEVICE_ID> install /tmp/ADBKeyboard.apk
```

安装后使用 AskQuestion 引导用户：

> ADBKeyboard 已推送到手机，请在手机弹窗中点击「确认安装」。安装完成后点击继续。

选项：继续 / 取消

### 4. 执行任务

完成前置检查后，按 **下方「执行任务」** 前台运行脚本。传入参数：

- `--type adb`
- `--device-id "<DEVICE_ID>"`
- `--instruction "<用户的任务指令>"`

npm 包内部会在任务启动前自动执行 `ime enable` + `ime set` 切换到 ADB Keyboard，无需手动切换。

---

## HDC 任务工作流

### 1. 检测 HDC

```bash
hdc version 2>&1
```

**如果 hdc 不可用**：告知用户：

> HDC 未安装。请前往 https://developer.huawei.com/consumer/cn/download/ 下载 HarmonyOS SDK 并安装 HDC 工具。

终止流程。

### 2. 检测设备

```bash
hdc list targets
```

若输出为空或包含 `[Empty]`，提示用户连接鸿蒙设备并终止流程。

### 3. 执行任务

取第一个设备 ID，按 **下方「执行任务」** 前台运行脚本。传入参数：

- `--type hdc`
- `--device-id "<DEVICE_ID>"`
- `--instruction "<用户的任务指令>"`

---

## WEB 任务工作流

### 1. 执行任务

WEB 任务的设备创建/启动/Chrome 检测都由脚本自动完成，按 **下方「执行任务」** 前台运行脚本。传入参数：

- `--type web`
- `--instruction "<用户的任务指令>"`

### 2. 登录检测

**重要**：WEB 任务内置登录页检测。如果脚本输出 `⚠️ [LOGIN REQUIRED]`：

1. 浏览器会自动弹到前台显示登录页
2. 立即告知用户：请在弹出的浏览器窗口中完成登录，最多等待 5 分钟
3. 脚本在**同一前台进程内**等待登录完成后再继续（Agent **无需**再调 `view_output` 等轮询）

---

## 执行任务（核心：后台执行，轮询任务状态）

在 **skill 根目录**下后台运行 `run-task.mjs`，并轮询任务状态，从 `stdout` 获取步骤信息。

### 调用方式

| 字段            | 说明                                                                            |
| --------------- | ------------------------------------------------------------------------------- |
| `absolute_path` | skill 根目录绝对路径，作为 **工作目录**                                         |
| `command`       | 见下表                                                                          |
| 超时            | 任务可能持续数分钟，平台命令/Shell 超时建议 **≥ 600 秒**，或与 `--timeout` 一致 |

**命令示例**：

- **WEB**：`node scripts/run-task.mjs --type web --instruction "<用户的任务指令>"`
- **ADB**：`node scripts/run-task.mjs --type adb --device-id "<DEVICE_ID>" --instruction "<用户的任务指令>"`
- **HDC**：`node scripts/run-task.mjs --type hdc --device-id "<DEVICE_ID>" --instruction "<用户的任务指令>"`

**JSON 示例**（字段名以平台为准）：

```json
{
	"absolute_path": "/path/to/.skills/<uuid>",
	"command": "node scripts/run-task.mjs --type web --instruction \"<用户任务原文>\""
}
```

### 过程处理

1. 使用view_output获取后台任务状态，从`stdout`（如有）中获取任务进度信息。
2. 若任务仍处于运行中，sleep 10 等待任务运行。
3. 重复上述过程，直到后台任务运行结束。

### 结果处理

1. **向用户总结**：用自然语言概括任务结果；优先引用 `stdout` 中 `[TASK COMPLETE]` 块的 **Status、Total Steps、Duration、Report URL**，以及各 `[STEP N]` 行或 `finished(...)` 中的结果摘要。
2. **失败**：含 `[TASK FAILED]`、`[ERROR]`、`[TIMEOUT]` 或非零 `exitCode` 时说明原因并附相关 `stdout` 片段。

WEB 执行过程中若需登录，脚本会在 `stdout` 输出 `⚠️ [LOGIN REQUIRED]`；**执行时进程不会结束**，用户在浏览器完成登录后任务会继续。

---

## 脚本输出格式

脚本 `run-task.mjs` 输出格式如下。**每个 `[STEP N]` 占一行**（summary 内的换行已合并为空格），便于阅读与从最终 `stdout` 中解析。

```
[STEP 1] 打开目标页面 https://example.com
[STEP 2] 点击搜索框,准备输入关键词 - click()
[STEP 3] 输入"hello world" - type(content="hello world")
[STEP 4] 点击搜索按钮 - click()
[STEP 5] finished(result='success', content='搜索完成', data={...})

⚠️ [LOGIN REQUIRED] 检测到登录页面，请在浏览器中完成登录...

[TASK COMPLETE] ======================================
  Status: completed (success=true)
  Message: 任务正常完成
  Total Steps: 5
  Duration: 45.3s
  Report: https://...
```

## 参数

| 参数            | 说明                          | 默认值   |
| --------------- | ----------------------------- | -------- |
| `--type`        | 设备类型: `adb`, `hdc`, `web` | 必填     |
| `--device-id`   | 设备ID（web 类型可省略）      | -        |
| `--instruction` | 任务指令                      | 必填     |
| `--timeout`     | 任务超时(ms)                  | `600000` |
