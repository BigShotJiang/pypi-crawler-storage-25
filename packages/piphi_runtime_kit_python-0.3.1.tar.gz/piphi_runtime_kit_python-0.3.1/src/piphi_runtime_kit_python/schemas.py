from __future__ import annotations

"""Framework-agnostic schema models shared by PiPhi runtime integrations."""

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class RuntimeConfig(BaseModel):
    """Base runtime config model with a required config id and extensible fields."""
    id: str
    model_config = ConfigDict(extra="allow")


class RuntimeConfigSnapshot(BaseModel):
    """Snapshot payload sent from PiPhi Core to an integration runtime."""
    container_id: str
    integration_id: str | None = None
    driver_pid: int | None = None
    reason: str | None = None
    generation: int | None = None
    configs: list[RuntimeConfig] = Field(default_factory=list)


class RuntimeConfigSyncResponse(BaseModel):
    """Standard response body returned by runtime config sync endpoints."""
    status: str
    container_id: str
    reason: str | None = None
    generation: int | None = None
    applied: list[str] = Field(default_factory=list)
    removed: list[str] = Field(default_factory=list)
    active_config_ids: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class RuntimeConfigApplyResponse(BaseModel):
    """Standard response body returned after one config is applied."""
    status: str = "configured"
    config_id: str
    container_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class RuntimeConfigRemoveResponse(BaseModel):
    """Standard response body returned after one config is removed."""
    status: str = "deconfigured"
    config_id: str
    removed: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)


class IntegrationDiscoveryRequest(BaseModel):
    """Standard discovery request sent from PiPhi Core to a runtime."""
    container_id: str | None = None
    driver_pid: int | None = None
    inputs: dict[str, Any] = Field(default_factory=dict)


class IntegrationDiscoveryResponse(BaseModel):
    """Standard discovery response returned by a runtime."""
    devices: list[dict[str, Any]] = Field(default_factory=list)


class IntegrationCommandRequest(BaseModel):
    """Standard command payload forwarded from PiPhi Core to a runtime."""
    command: str
    capability_id: str | None = None
    device_id: str | None = None
    entity_id: str | None = None
    args: dict[str, Any] = Field(default_factory=dict)


class IntegrationEventRequest(BaseModel):
    """Generic event payload emitted by a runtime integration."""
    event_type: str
    source: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class IntegrationEventListResponse(BaseModel):
    """Standard response body for listing previously captured runtime events."""
    events: list[dict[str, Any]] = Field(default_factory=list)


class IntegrationEventIngestResponse(BaseModel):
    """Standard response body returned after a runtime ingests an event."""
    status: str = "accepted"
    event: dict[str, Any] = Field(default_factory=dict)


class EventSeverity(str, Enum):
    """Supported severity values for events sent back to PiPhi Core."""
    info = "info"
    warning = "warning"
    error = "error"
    critical = "critical"


class EventTransport(str, Enum):
    """Supported transport labels for events sent back to PiPhi Core."""
    rest = "rest"
    mqtt = "mqtt"


class CoreEventPayload(BaseModel):
    """Canonical event payload posted from a runtime back to PiPhi Core."""
    event_id: str
    type: str
    ts: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    integration_id: str | None = None
    config_id: str | None = None
    container_id: str | None = None
    device_id: str | None = None
    severity: EventSeverity = Field(default=EventSeverity.info)
    transport: EventTransport = Field(default=EventTransport.rest)
    topic: str | None = None
    data: dict[str, Any] = Field(default_factory=dict)
    received_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class RuntimeHealthResponse(BaseModel):
    """Standard health response body returned by runtime integrations."""
    status: str = "ok"
    integration: dict[str, Any] = Field(default_factory=dict)
    runtime: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class RuntimeDiagnosticsResponse(BaseModel):
    """Standard diagnostics response body returned by runtime integrations."""
    status: str = "ok"
    integration: dict[str, Any] = Field(default_factory=dict)
    diagnostics: dict[str, Any] = Field(default_factory=dict)


class TelemetryPayload(BaseModel):
    """Standard telemetry request body posted back to PiPhi Core."""
    device_id: str
    metrics: dict[str, Any] = Field(default_factory=dict)
    timestamp: str
    units: dict[str, Any] = Field(default_factory=dict)
