from __future__ import annotations

"""Helpers for resolving PiPhi runtime auth across requests and background work."""

import os
from dataclasses import dataclass
from typing import Any, Mapping


DEFAULT_INTERNAL_TOKEN_ENV_NAME = "PIPHI_INTEGRATION_INTERNAL_TOKEN"
RUNTIME_CONTAINER_ID_HEADER_NAME = "X-Container-Id"
RUNTIME_INTERNAL_TOKEN_HEADER_NAME = "X-PiPhi-Integration-Token"


def mask_token(token: str | None) -> str:
    """Return a log-safe representation of an internal runtime token."""
    normalized = (token or "").strip()
    if not normalized:
        return "missing"
    if len(normalized) <= 10:
        return "present"
    return f"{normalized[:6]}...{normalized[-4:]}"


def _get_header_value(headers: Mapping[str, Any], name: str) -> str:
    for key, value in headers.items():
        if str(key).lower() == name.lower():
            return str(value or "").strip()
    return ""


@dataclass(slots=True, frozen=True)
class RuntimeAuthHeaders:
    """Normalized PiPhi runtime auth values extracted from request headers."""
    container_id: str = ""
    internal_token: str = ""


def extract_runtime_auth_headers(headers: Mapping[str, Any]) -> RuntimeAuthHeaders:
    """Extract PiPhi runtime auth headers from any case-insensitive header mapping."""
    return RuntimeAuthHeaders(
        container_id=_get_header_value(headers, RUNTIME_CONTAINER_ID_HEADER_NAME),
        internal_token=_get_header_value(headers, RUNTIME_INTERNAL_TOKEN_HEADER_NAME),
    )


def build_runtime_auth_headers(
    *,
    container_id: str,
    internal_token: str | None,
) -> dict[str, str]:
    """Build the standard PiPhi runtime auth headers for outbound Core calls."""
    headers = {RUNTIME_CONTAINER_ID_HEADER_NAME: container_id}
    if internal_token:
        headers[RUNTIME_INTERNAL_TOKEN_HEADER_NAME] = internal_token
    return headers


def format_runtime_auth_sync_log(
    parsed_headers: RuntimeAuthHeaders,
    *,
    payload_container_id: str | None = None,
) -> str:
    """Build a consistent log message for request-scoped runtime auth sync.

    This keeps token masking and field naming consistent across integrations
    that want to log the incoming runtime auth context for debugging.
    """
    return (
        "runtime_internal_auth "
        f"header_container_id={parsed_headers.container_id or 'missing'} "
        f"payload_container_id={payload_container_id or 'missing'} "
        f"token={mask_token(parsed_headers.internal_token)}"
    )


@dataclass(slots=True)
class RuntimeAuthContext:
    """In-memory auth context shared by a runtime process.

    Integrations can keep the most recent container scope and internal token here,
    then reuse it for outbound telemetry or config sync calls.
    """
    container_id: str = ""
    internal_token: str = ""

    def update(
        self,
        *,
        container_id: str | None = None,
        internal_token: str | None = None,
    ) -> None:
        """Update the stored auth context with any non-empty incoming values."""
        if container_id is not None:
            resolved_container_id = str(container_id).strip()
            if resolved_container_id:
                self.container_id = resolved_container_id

        if internal_token is not None:
            resolved_internal_token = str(internal_token).strip()
            if resolved_internal_token:
                self.internal_token = resolved_internal_token

    def sync_from_headers(
        self,
        headers: Mapping[str, Any],
        *,
        payload_container_id: str | None = None,
    ) -> RuntimeAuthHeaders:
        """Update the context from request headers and return the parsed values.

        Typical usage:
            parsed = runtime_context.auth.sync_from_headers(
                request.headers,
                payload_container_id=payload.container_id,
            )
        """
        parsed_headers = extract_runtime_auth_headers(headers)
        self.update(
            container_id=parsed_headers.container_id or payload_container_id,
            internal_token=parsed_headers.internal_token,
        )
        return parsed_headers

    def resolve(
        self,
        *,
        container_id: str | None = None,
        token_env_name: str = DEFAULT_INTERNAL_TOKEN_ENV_NAME,
    ) -> tuple[str, str]:
        """Resolve the effective container scope and internal token for a request."""
        resolved_container_id = str(container_id or "").strip() or self.container_id
        resolved_internal_token = self.internal_token or (os.getenv(token_env_name) or "").strip()
        return resolved_container_id, resolved_internal_token
