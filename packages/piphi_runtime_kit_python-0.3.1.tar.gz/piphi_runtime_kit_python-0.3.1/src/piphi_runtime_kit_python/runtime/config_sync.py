from __future__ import annotations

"""Helpers for basic config-sync orchestration and generation tracking."""

from dataclasses import dataclass
from typing import Awaitable, Callable, TypeVar

from ..schemas import RuntimeConfig, RuntimeConfigSnapshot, RuntimeConfigSyncResponse
from .state import RuntimeProcessState

TConfig = TypeVar("TConfig", bound=RuntimeConfig)


def reconcile_config_ids(
    *,
    active_ids: list[str],
    incoming_ids: list[str],
) -> tuple[list[str], list[str]]:
    """Return removed ids and unchanged ids from two config-id lists."""
    active_set = set(active_ids)
    incoming_set = set(incoming_ids)
    removed_ids = sorted(active_set - incoming_set)
    unchanged_ids = sorted(active_set & incoming_set)
    return removed_ids, unchanged_ids


def build_sync_response(
    *,
    status: str,
    container_id: str,
    reason: str | None = None,
    generation: int | None = None,
    applied: list[str] | None = None,
    removed: list[str] | None = None,
    active_config_ids: list[str] | None = None,
    metadata: dict | None = None,
) -> RuntimeConfigSyncResponse:
    """Build a standard PiPhi config-sync response payload."""
    return RuntimeConfigSyncResponse(
        status=status,
        container_id=container_id,
        reason=reason,
        generation=generation,
        applied=applied or [],
        removed=removed or [],
        active_config_ids=active_config_ids or [],
        metadata=metadata or {},
    )


@dataclass(slots=True)
class ConfigSyncCoordinator:
    """Track config generations and common sync response patterns.

    This class intentionally stays small. It helps integrations decide whether
    an incoming snapshot is stale and keeps generation tracking in one place.
    """
    process_state: RuntimeProcessState

    def get_current_generation(self) -> int | None:
        """Return the latest applied config generation for the process."""
        return self.process_state.current_generation

    def mark_generation(self, generation: int | None) -> int | None:
        """Persist a new generation and return the effective stored value."""
        if generation is not None:
            self.process_state.current_generation = int(generation)
        return self.process_state.current_generation

    def is_stale(self, snapshot: RuntimeConfigSnapshot) -> bool:
        """Return whether an incoming snapshot is older than the current state."""
        incoming_generation = snapshot.generation
        current_generation = self.process_state.current_generation
        return bool(
            incoming_generation is not None
            and current_generation is not None
            and int(incoming_generation) < int(current_generation)
        )

    def build_stale_response(
        self,
        *,
        snapshot: RuntimeConfigSnapshot,
        active_config_ids: list[str],
    ) -> RuntimeConfigSyncResponse:
        """Build the standard response for an ignored stale snapshot."""
        return build_sync_response(
            status="stale_ignored",
            container_id=snapshot.container_id,
            reason=snapshot.reason,
            generation=self.process_state.current_generation,
            active_config_ids=active_config_ids,
            metadata={
                "stale_generation_ignored": True,
                "incoming_generation": snapshot.generation,
                "current_generation": self.process_state.current_generation,
            },
        )

    async def apply_snapshot(
        self,
        *,
        snapshot: RuntimeConfigSnapshot,
        active_config_ids: list[str],
        apply_config: Callable[[RuntimeConfig], Awaitable[None]],
        remove_config: Callable[[str], Awaitable[bool]],
        get_active_config_ids: Callable[[], list[str]] | None = None,
    ) -> RuntimeConfigSyncResponse:
        """Apply a config snapshot using caller-provided apply/remove callbacks.

        This keeps the integration-specific logic in the callbacks while the SDK
        handles the generic PiPhi sync flow: stale detection, diffing, generation
        tracking, and standard response payloads.
        """
        if self.is_stale(snapshot):
            return self.build_stale_response(
                snapshot=snapshot,
                active_config_ids=active_config_ids,
            )

        incoming_ids = [config.id for config in snapshot.configs]
        removed_ids, _unchanged_ids = reconcile_config_ids(
            active_ids=active_config_ids,
            incoming_ids=incoming_ids,
        )

        removed: list[str] = []
        applied: list[str] = []

        for config_id in removed_ids:
            was_removed = await remove_config(config_id)
            if was_removed:
                removed.append(config_id)

        for config in snapshot.configs:
            await apply_config(config)
            applied.append(config.id)

        current_generation = self.mark_generation(snapshot.generation)
        next_active_config_ids = (
            get_active_config_ids() if get_active_config_ids is not None else incoming_ids
        )

        return build_sync_response(
            status="synced",
            container_id=snapshot.container_id,
            reason=snapshot.reason,
            generation=current_generation,
            applied=applied,
            removed=removed,
            active_config_ids=next_active_config_ids,
            metadata={
                "applied_count": len(applied),
                "removed_count": len(removed),
                "current_generation": current_generation,
            },
        )
