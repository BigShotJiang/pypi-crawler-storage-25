from __future__ import annotations

"""Helpers for creating and shutting down tracked background tasks."""

import asyncio
import contextlib
from typing import Any

from .state import RuntimeProcessState


def track_background_task(
    task: asyncio.Task[Any],
    *,
    process_state: RuntimeProcessState,
) -> asyncio.Task[Any]:
    """Register an already-created task so it can be cleaned up later."""
    process_state.background_tasks.add(task)
    task.add_done_callback(process_state.background_tasks.discard)
    return task


def create_tracked_task(
    coro,
    *,
    process_state: RuntimeProcessState,
) -> asyncio.Task[Any]:
    """Create a task and automatically register it with the process state."""
    return track_background_task(
        asyncio.create_task(coro),
        process_state=process_state,
    )


async def shutdown_background_tasks(process_state: RuntimeProcessState) -> None:
    """Cancel and await all tracked background tasks still running."""
    pending_tasks = [task for task in process_state.background_tasks if not task.done()]
    for task in pending_tasks:
        task.cancel()
    for task in pending_tasks:
        with contextlib.suppress(asyncio.CancelledError):
            await task
