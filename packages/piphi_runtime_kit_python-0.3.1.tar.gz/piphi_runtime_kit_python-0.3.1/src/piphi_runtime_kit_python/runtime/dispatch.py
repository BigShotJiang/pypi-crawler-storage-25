from __future__ import annotations

"""Helpers for background dispatch of telemetry and event delivery."""

from typing import Any, Callable, Mapping

from .events import EventClient
from .tasks import create_tracked_task
from .telemetry import TelemetryClient
from .auth import RuntimeAuthContext
from .state import RuntimeProcessState

EventRecorder = Callable[[dict[str, Any]], Any]
SkipHandler = Callable[[str, dict[str, Any]], Any]
ErrorHandler = Callable[[Exception, dict[str, Any]], Any]


def build_local_event_record(
    *,
    event_type: str,
    device: Mapping[str, Any],
    payload: Mapping[str, Any] | None = None,
    source: str,
    severity: str,
) -> dict[str, Any]:
    """Build the canonical local runtime event record shape."""
    return {
        "event_type": event_type,
        "source": source,
        "payload": dict(payload or {}),
        "device_id": device.get("device_id"),
        "container_id": device.get("container_id"),
        "integration_id": device.get("integration_id"),
        "config_id": device.get("config_id"),
        "severity": severity,
    }


async def dispatch_telemetry_delivery(
    *,
    telemetry_client: TelemetryClient,
    auth_context: RuntimeAuthContext,
    device_id: str,
    metrics: dict[str, Any],
    container_id: str | None = None,
    units: dict[str, Any] | None = None,
    timestamp: str | None = None,
    on_skipped: SkipHandler | None = None,
    on_error: ErrorHandler | None = None,
) -> bool:
    """Send telemetry and return whether a delivery attempt succeeded."""
    resolved_container_id, _ = auth_context.resolve(container_id=container_id)
    if not resolved_container_id:
        if on_skipped is not None:
            on_skipped(
                "missing_container_id",
                {"device_id": device_id, "container_id": container_id},
            )
        return False

    try:
        await telemetry_client.send_metrics(
            device_id=device_id,
            metrics=metrics,
            auth_context=auth_context,
            container_id=resolved_container_id,
            units=units,
            timestamp=timestamp,
        )
        return True
    except Exception as exc:
        if on_error is not None:
            on_error(exc, {"device_id": device_id, "container_id": resolved_container_id})
            return False
        raise


def schedule_telemetry_delivery(
    *,
    process_state: RuntimeProcessState,
    telemetry_client: TelemetryClient,
    auth_context: RuntimeAuthContext,
    device_id: str,
    metrics: dict[str, Any],
    container_id: str | None = None,
    units: dict[str, Any] | None = None,
    timestamp: str | None = None,
    on_skipped: SkipHandler | None = None,
    on_error: ErrorHandler | None = None,
):
    """Schedule background telemetry delivery on the tracked runtime task set."""
    return create_tracked_task(
        dispatch_telemetry_delivery(
            telemetry_client=telemetry_client,
            auth_context=auth_context,
            device_id=device_id,
            metrics=metrics,
            container_id=container_id,
            units=units,
            timestamp=timestamp,
            on_skipped=on_skipped,
            on_error=on_error,
        ),
        process_state=process_state,
    )


async def dispatch_event_delivery(
    *,
    event_client: EventClient,
    auth_context: RuntimeAuthContext,
    event_type: str,
    device: Mapping[str, Any],
    payload: Mapping[str, Any] | None = None,
    source: str,
    severity: str = "info",
    on_skipped: SkipHandler | None = None,
    on_error: ErrorHandler | None = None,
) -> bool:
    """Send one event to Core and return whether delivery succeeded."""
    try:
        event_sent = await event_client.send_event(
            event_type=event_type,
            integration_id=device.get("integration_id"),
            config_id=device.get("config_id") or device.get("device_id"),
            auth_context=auth_context,
            container_id=device.get("container_id"),
            device_id=device.get("device_id"),
            payload=payload,
            source=source,
            severity=severity,
        )
        if not event_sent and on_skipped is not None:
            on_skipped(
                "missing_event_scope",
                {
                    "event_type": event_type,
                    "device_id": device.get("device_id"),
                    "container_id": device.get("container_id"),
                    "integration_id": device.get("integration_id"),
                    "config_id": device.get("config_id"),
                },
            )
        return event_sent
    except Exception as exc:
        if on_error is not None:
            on_error(
                exc,
                {
                    "event_type": event_type,
                    "device_id": device.get("device_id"),
                    "container_id": device.get("container_id"),
                },
            )
            return False
        raise


def schedule_event_delivery(
    *,
    process_state: RuntimeProcessState,
    event_client: EventClient,
    auth_context: RuntimeAuthContext,
    event_type: str,
    device: Mapping[str, Any],
    payload: Mapping[str, Any] | None = None,
    source: str,
    severity: str = "info",
    record_event: EventRecorder | None = None,
    on_skipped: SkipHandler | None = None,
    on_error: ErrorHandler | None = None,
):
    """Record an optional local event and schedule delivery to Core."""
    if record_event is not None:
        record_event(
            build_local_event_record(
                event_type=event_type,
                device=device,
                payload=payload,
                source=source,
                severity=severity,
            )
        )
    return create_tracked_task(
        dispatch_event_delivery(
            event_client=event_client,
            auth_context=auth_context,
            event_type=event_type,
            device=device,
            payload=payload,
            source=source,
            severity=severity,
            on_skipped=on_skipped,
            on_error=on_error,
        ),
        process_state=process_state,
    )
