from __future__ import annotations

"""Typed in-memory registry helpers for runtime-managed device/config state."""

import datetime as dt
from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar

TEntry = TypeVar("TEntry", bound=dict[str, Any])
TState = TypeVar("TState", bound=dict[str, Any])
TEvent = TypeVar("TEvent", bound=dict[str, Any])


@dataclass(slots=True)
class RuntimeRegistry(Generic[TEntry, TState, TEvent]):
    """Small in-memory registry for runtime-managed entries, state, and events.

    Core remains the source of truth for configs. This registry only tracks the
    runtime working set currently loaded in memory.
    """

    entries: dict[str, TEntry] = field(default_factory=dict)
    state_snapshots: dict[str, dict[str, Any]] = field(default_factory=dict)
    recent_events: list[TEvent] = field(default_factory=list)
    max_recent_events: int = 100

    def get(self, entry_id: str) -> TEntry | None:
        """Return one active entry by id when present."""
        return self.entries.get(entry_id)

    def set(self, entry_id: str, entry: TEntry) -> TEntry:
        """Upsert one active entry and return the stored value."""
        self.entries[entry_id] = entry
        return entry

    def remove(self, entry_id: str) -> TEntry | None:
        """Remove one active entry and return the removed value when present."""
        removed = self.entries.pop(entry_id, None)
        self.state_snapshots.pop(entry_id, None)
        return removed

    def ids(self) -> list[str]:
        """Return the active entry ids in insertion order."""
        return list(self.entries.keys())

    def primary_entry(self) -> TEntry | None:
        """Return the first active entry when one exists."""
        if not self.entries:
            return None
        first_entry_id = next(iter(self.entries))
        return self.entries[first_entry_id]

    def update_state(self, entry_id: str, state: dict[str, Any]) -> dict[str, Any]:
        """Store the latest state snapshot and mirror it onto the active entry."""
        timestamp = dt.datetime.now(dt.timezone.utc).isoformat()
        latest_state = {
            "device_id": entry_id,
            "state": state,
            "last_updated": timestamp,
        }
        self.state_snapshots[entry_id] = latest_state
        if entry_id in self.entries:
            self.entries[entry_id]["latest_state"] = state
            self.entries[entry_id]["last_updated"] = timestamp
        return latest_state

    def append_event(self, event: TEvent) -> TEvent:
        """Append one local event record and keep the recent-event window bounded."""
        record = {
            "received_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            **event,
        }
        typed_record = record  # satisfy generic return without runtime coercion
        self.recent_events.append(typed_record)  # type: ignore[arg-type]
        if len(self.recent_events) > self.max_recent_events:
            del self.recent_events[:-self.max_recent_events]
        return typed_record  # type: ignore[return-value]
