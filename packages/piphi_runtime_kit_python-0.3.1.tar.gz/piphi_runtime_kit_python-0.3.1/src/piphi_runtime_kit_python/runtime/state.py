from __future__ import annotations

"""Shared mutable runtime state used by the thin PiPhi runtime helpers."""

import asyncio
from dataclasses import dataclass, field
from typing import Any

import httpx


@dataclass(slots=True)
class RuntimeProcessState:
    """Process-scoped runtime state.

    This keeps non-device-specific runtime concerns in one place:
    the active Core HTTP client, the latest config generation, and tracked
    background tasks that should be cleaned up on shutdown.
    """
    current_generation: int | None = None
    core_http_client: httpx.AsyncClient | None = None
    background_tasks: set[asyncio.Task[Any]] = field(default_factory=set)
