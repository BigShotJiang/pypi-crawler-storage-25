from __future__ import annotations

"""Typed delivery errors for PiPhi runtime-to-Core communication."""

from dataclasses import dataclass

import httpx


@dataclass(eq=False)
class CoreDeliveryError(Exception):
    """Base error for failed runtime delivery attempts to PiPhi Core."""

    operation: str
    url: str
    message: str
    retryable: bool
    status_code: int | None = None
    timeout_seconds: float | None = None

    def __str__(self) -> str:
        details = [self.message, f"operation={self.operation}", f"url={self.url}"]
        if self.status_code is not None:
            details.append(f"status_code={self.status_code}")
        if self.timeout_seconds is not None:
            details.append(f"timeout_seconds={self.timeout_seconds}")
        details.append(f"retryable={self.retryable}")
        return " ".join(details)


@dataclass(eq=False)
class CoreUnavailableError(CoreDeliveryError):
    """Raised when PiPhi Core cannot be reached over the network."""


@dataclass(eq=False)
class CoreTimeoutError(CoreDeliveryError):
    """Raised when PiPhi Core does not respond before the configured timeout."""


@dataclass(eq=False)
class CoreRouteNotFoundError(CoreDeliveryError):
    """Raised when the expected PiPhi Core route does not exist."""


@dataclass(eq=False)
class CoreAuthError(CoreDeliveryError):
    """Raised when PiPhi Core rejects runtime authentication."""


@dataclass(eq=False)
class CoreServerError(CoreDeliveryError):
    """Raised when PiPhi Core returns a 5xx response."""


@dataclass(eq=False)
class CoreUnexpectedResponseError(CoreDeliveryError):
    """Raised when PiPhi Core returns an unexpected non-success response."""


def classify_core_delivery_error(
    *,
    exc: Exception,
    operation: str,
    url: str,
    timeout_seconds: float | None,
) -> CoreDeliveryError:
    """Convert raw HTTP client exceptions into stable PiPhi delivery errors."""
    if isinstance(exc, httpx.ReadTimeout):
        return CoreTimeoutError(
            operation=operation,
            url=url,
            message="PiPhi Core did not respond before the request timeout",
            retryable=True,
            timeout_seconds=timeout_seconds,
        )

    if isinstance(exc, httpx.ConnectError):
        return CoreUnavailableError(
            operation=operation,
            url=url,
            message="PiPhi Core is unreachable",
            retryable=True,
            timeout_seconds=timeout_seconds,
        )

    if isinstance(exc, httpx.HTTPStatusError):
        status_code = exc.response.status_code
        if status_code == 404:
            return CoreRouteNotFoundError(
                operation=operation,
                url=url,
                message="PiPhi Core route is not available",
                retryable=False,
                status_code=status_code,
                timeout_seconds=timeout_seconds,
            )
        if status_code in {401, 403}:
            return CoreAuthError(
                operation=operation,
                url=url,
                message="PiPhi Core rejected the runtime authentication headers",
                retryable=False,
                status_code=status_code,
                timeout_seconds=timeout_seconds,
            )
        if 500 <= status_code <= 599:
            return CoreServerError(
                operation=operation,
                url=url,
                message="PiPhi Core failed while processing the delivery request",
                retryable=True,
                status_code=status_code,
                timeout_seconds=timeout_seconds,
            )
        return CoreUnexpectedResponseError(
            operation=operation,
            url=url,
            message="PiPhi Core returned an unexpected non-success response",
            retryable=False,
            status_code=status_code,
            timeout_seconds=timeout_seconds,
        )

    return CoreUnexpectedResponseError(
        operation=operation,
        url=url,
        message=str(exc) or exc.__class__.__name__,
        retryable=False,
        timeout_seconds=timeout_seconds,
    )
