from __future__ import annotations

"""Helpers for sending PiPhi telemetry back to Core."""

import datetime as dt
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any

import httpx

from ..schemas import TelemetryPayload
from .auth import RuntimeAuthContext, build_runtime_auth_headers
from .errors import classify_core_delivery_error
from .state import RuntimeProcessState


DEFAULT_CORE_BASE_URL = "http://127.0.0.1:31419"
DEFAULT_TELEMETRY_PATH = "/api/v2/integrations/telemetry"
DEFAULT_TIMEOUT_SECONDS = 3.0

def build_core_auth_headers(
    *,
    container_id: str,
    internal_token: str | None,
) -> dict[str, str]:
    """Build outbound Core auth headers using the standard PiPhi header names."""
    return build_runtime_auth_headers(
        container_id=container_id,
        internal_token=internal_token,
    )


def build_telemetry_payload(
    *,
    device_id: str,
    metrics: dict[str, Any],
    units: dict[str, Any] | None = None,
    timestamp: str | None = None,
) -> TelemetryPayload:
    """Build the standard telemetry payload expected by PiPhi Core."""
    return TelemetryPayload(
        device_id=device_id,
        metrics=metrics,
        timestamp=timestamp or dt.datetime.now(dt.timezone.utc).isoformat(),
        units=units or {},
    )


@dataclass(slots=True)
class TelemetryClient:
    """Thin Core telemetry client for runtime integrations.

    This helper reuses a shared Core HTTP client when one is available and
    otherwise creates a short-lived client with the configured timeout.
    """
    process_state: RuntimeProcessState
    core_base_url: str = DEFAULT_CORE_BASE_URL
    telemetry_path: str = DEFAULT_TELEMETRY_PATH
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS

    @property
    def telemetry_url(self) -> str:
        """Return the fully qualified Core telemetry endpoint URL."""
        return f"{self.core_base_url.rstrip('/')}{self.telemetry_path}"

    @asynccontextmanager
    async def borrow_http_client(self):
        """Yield a shared Core client when present, otherwise a temporary client."""
        if self.process_state.core_http_client is not None:
            yield self.process_state.core_http_client
            return

        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            yield client

    async def send_metrics(
        self,
        *,
        device_id: str,
        metrics: dict[str, Any],
        auth_context: RuntimeAuthContext,
        container_id: str | None = None,
        units: dict[str, Any] | None = None,
        timestamp: str | None = None,
    ) -> None:
        """Send a telemetry payload for one device to PiPhi Core.

        Typical usage:
            await telemetry_client.send_metrics(
                device_id="plug-1",
                metrics={"is_on": True, "current_power_w": 12.4},
                units={"current_power_w": "W"},
                auth_context=runtime_context.auth,
                container_id="runtime-123",
            )
        """
        resolved_container_id, resolved_internal_token = auth_context.resolve(
            container_id=container_id,
        )
        if not resolved_container_id:
            return

        payload = build_telemetry_payload(
            device_id=device_id,
            metrics=metrics,
            units=units,
            timestamp=timestamp,
        )
        headers = build_core_auth_headers(
            container_id=resolved_container_id,
            internal_token=resolved_internal_token,
        )

        async with self.borrow_http_client() as client:
            try:
                response = await client.post(
                    self.telemetry_url,
                    json=payload.model_dump(),
                    headers=headers,
                    timeout=self.timeout_seconds,
                )
                response.raise_for_status()
            except (httpx.HTTPStatusError, httpx.ConnectError, httpx.ReadTimeout) as exc:
                raise classify_core_delivery_error(
                    exc=exc,
                    operation="telemetry_delivery",
                    url=self.telemetry_url,
                    timeout_seconds=self.timeout_seconds,
                ) from exc
