from __future__ import annotations

"""Helpers for bootstrapping runtime auth, shared clients, and shutdown cleanup."""

import os
from contextlib import asynccontextmanager
from typing import AsyncIterator, Awaitable, Callable

import httpx

from .context import RuntimeContext
from .tasks import shutdown_background_tasks


DEFAULT_RUNTIME_CONTAINER_ID_ENV_NAME = "PIPHI_CONTAINER_ID"
DEFAULT_RUNTIME_INTERNAL_TOKEN_ENV_NAME = "PIPHI_INTEGRATION_INTERNAL_TOKEN"
DEFAULT_CORE_CLIENT_TIMEOUT_SECONDS = 10.0


def bootstrap_runtime_auth_from_env(
    runtime_context: RuntimeContext,
    *,
    container_env_name: str = DEFAULT_RUNTIME_CONTAINER_ID_ENV_NAME,
    token_env_name: str = DEFAULT_RUNTIME_INTERNAL_TOKEN_ENV_NAME,
) -> tuple[str, str]:
    """Load runtime auth values from environment variables into the context."""
    container_id = (os.getenv(container_env_name) or "").strip()
    internal_token = (os.getenv(token_env_name) or "").strip()
    runtime_context.auth.update(
        container_id=container_id,
        internal_token=internal_token,
    )
    return container_id, internal_token


@asynccontextmanager
async def bind_core_http_client(
    runtime_context: RuntimeContext,
    *,
    timeout_seconds: float = DEFAULT_CORE_CLIENT_TIMEOUT_SECONDS,
) -> AsyncIterator[httpx.AsyncClient]:
    """Bind a shared Core HTTP client to the runtime context for the duration of the scope."""
    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        runtime_context.set_core_http_client(client)
        try:
            yield client
        finally:
            runtime_context.set_core_http_client(None)


@asynccontextmanager
async def runtime_lifespan(
    runtime_context: RuntimeContext,
    *,
    on_startup: Callable[[RuntimeContext, httpx.AsyncClient], Awaitable[None]] | None = None,
    on_shutdown: Callable[[RuntimeContext], Awaitable[None]] | None = None,
    container_env_name: str = DEFAULT_RUNTIME_CONTAINER_ID_ENV_NAME,
    token_env_name: str = DEFAULT_RUNTIME_INTERNAL_TOKEN_ENV_NAME,
    core_client_timeout_seconds: float = DEFAULT_CORE_CLIENT_TIMEOUT_SECONDS,
) -> AsyncIterator[RuntimeContext]:
    """Manage a runtime's shared Core client, env auth bootstrap, and task cleanup."""
    bootstrap_runtime_auth_from_env(
        runtime_context,
        container_env_name=container_env_name,
        token_env_name=token_env_name,
    )

    async with bind_core_http_client(
        runtime_context,
        timeout_seconds=core_client_timeout_seconds,
    ) as client:
        if on_startup is not None:
            await on_startup(runtime_context, client)
        try:
            yield runtime_context
        finally:
            await shutdown_background_tasks(runtime_context.process_state)
            if on_shutdown is not None:
                await on_shutdown(runtime_context)
