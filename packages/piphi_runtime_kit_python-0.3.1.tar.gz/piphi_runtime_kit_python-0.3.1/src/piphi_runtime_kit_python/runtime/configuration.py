from __future__ import annotations

"""Helpers for typed runtime config handling, safe logging, and responses."""

from typing import Any, Mapping, TypeVar

from ..schemas import RuntimeConfig, RuntimeConfigApplyResponse, RuntimeConfigRemoveResponse

TConfig = TypeVar("TConfig", bound=RuntimeConfig)

DEFAULT_CONFIG_SECRET_KEYS = (
    "password",
    "token",
    "secret",
    "api_key",
    "access_token",
    "refresh_token",
)


def redact_config_secrets(
    payload: Mapping[str, Any] | None,
    *,
    secret_keys: tuple[str, ...] = DEFAULT_CONFIG_SECRET_KEYS,
) -> dict[str, Any]:
    """Return a copy of a config payload with secret-looking values redacted."""
    if not payload:
        return {}

    normalized_secret_keys = {key.lower() for key in secret_keys}
    redacted: dict[str, Any] = {}
    for key, value in payload.items():
        if key.lower() in normalized_secret_keys and value not in (None, ""):
            redacted[key] = "***"
        elif isinstance(value, Mapping):
            redacted[key] = redact_config_secrets(value, secret_keys=secret_keys)
        elif isinstance(value, list):
            redacted[key] = [
                redact_config_secrets(item, secret_keys=secret_keys)
                if isinstance(item, Mapping)
                else item
                for item in value
            ]
        else:
            redacted[key] = value
    return redacted


def format_config_apply_log(
    payload: RuntimeConfig | Mapping[str, Any],
    *,
    action: str = "config_apply",
    secret_keys: tuple[str, ...] = DEFAULT_CONFIG_SECRET_KEYS,
) -> str:
    """Build a consistent config lifecycle log message with redacted values."""
    raw_payload = payload.model_dump() if isinstance(payload, RuntimeConfig) else dict(payload)
    config_id = str(raw_payload.get("id") or "missing")
    container_id = str(raw_payload.get("container_id") or "missing")
    redacted_payload = redact_config_secrets(raw_payload, secret_keys=secret_keys)
    return (
        f"{action} "
        f"config_id={config_id} "
        f"container_id={container_id} "
        f"payload={redacted_payload}"
    )


def build_config_apply_response(
    *,
    config_id: str,
    container_id: str | None = None,
    status: str = "configured",
    metadata: dict[str, Any] | None = None,
) -> RuntimeConfigApplyResponse:
    """Build the standard response returned after a config is applied."""
    return RuntimeConfigApplyResponse(
        status=status,
        config_id=config_id,
        container_id=container_id,
        metadata=metadata or {},
    )


def build_config_remove_response(
    *,
    config_id: str,
    removed: bool,
    status: str = "deconfigured",
    metadata: dict[str, Any] | None = None,
) -> RuntimeConfigRemoveResponse:
    """Build the standard response returned after a config removal attempt."""
    return RuntimeConfigRemoveResponse(
        status=status,
        config_id=config_id,
        removed=removed,
        metadata=metadata or {},
    )


def validate_typed_config(payload: TConfig | Mapping[str, Any], config_model: type[TConfig]) -> TConfig:
    """Validate one config payload against an integration-specific RuntimeConfig subclass."""
    if isinstance(payload, config_model):
        return payload
    return config_model.model_validate(payload)


def validate_typed_configs(
    payloads: list[TConfig] | list[Mapping[str, Any]],
    config_model: type[TConfig],
) -> list[TConfig]:
    """Validate many config payloads into one typed integration config model."""
    return [validate_typed_config(payload, config_model) for payload in payloads]
