from __future__ import annotations

"""Optional MQTT helpers for shared source-oriented data streams."""

import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import logging
from typing import Any, AsyncIterator, Awaitable, Callable, Iterable

logger = logging.getLogger("piphi_runtime_kit_python.mqtt")

DEFAULT_SOURCE_TOPIC_PREFIX = "piphi/sources"


@dataclass(slots=True, frozen=True)
class MqttBrokerConfig:
    hostname: str
    port: int = 1883
    username: str | None = None
    password: str | None = None
    client_id: str | None = None
    keepalive: int = 60
    transport: str = "tcp"
    qos: int = 0


def build_source_topic_root(
    source: str,
    *,
    prefix: str = DEFAULT_SOURCE_TOPIC_PREFIX,
) -> str:
    return f"{prefix.rstrip('/')}/{_sanitize_topic_segment(source)}"


def build_source_packets_topic(
    source: str,
    *,
    prefix: str = DEFAULT_SOURCE_TOPIC_PREFIX,
) -> str:
    return f"{build_source_topic_root(source, prefix=prefix)}/packets"


def build_source_model_packets_topic(
    source: str,
    model: str,
    *,
    prefix: str = DEFAULT_SOURCE_TOPIC_PREFIX,
) -> str:
    return (
        f"{build_source_topic_root(source, prefix=prefix)}"
        f"/models/{_sanitize_topic_segment(model)}/packets"
    )


def build_source_status_topic(
    source: str,
    *,
    prefix: str = DEFAULT_SOURCE_TOPIC_PREFIX,
) -> str:
    return f"{build_source_topic_root(source, prefix=prefix)}/status"


def build_source_errors_topic(
    source: str,
    *,
    prefix: str = DEFAULT_SOURCE_TOPIC_PREFIX,
) -> str:
    return f"{build_source_topic_root(source, prefix=prefix)}/errors"


def build_source_packet_envelope(
    *,
    source: str,
    packet: dict[str, Any],
    received_at: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    model = _coerce_optional_string(packet.get("model"))
    device_hint = {
        "model": model,
        "id": _coerce_optional_string(_first_present(packet, ("id", "device_id", "device", "sid", "unit"))),
        "channel": _coerce_optional_string(_first_present(packet, ("channel", "subtype"))),
    }
    return {
        "source": source,
        "received_at": received_at or datetime.now(timezone.utc).isoformat(),
        "model": model,
        "device_hint": device_hint,
        "packet": dict(packet),
        "metadata": dict(metadata or {}),
    }


class MqttJsonClient:
    """Thin JSON-oriented MQTT helper around aiomqtt."""

    def __init__(self, config: MqttBrokerConfig):
        self.config = config

    @asynccontextmanager
    async def session(self) -> AsyncIterator["_MqttJsonSession"]:
        aiomqtt = _load_aiomqtt()
        async with aiomqtt.Client(
            hostname=self.config.hostname,
            port=self.config.port,
            username=self.config.username,
            password=self.config.password,
            identifier=self.config.client_id,
            keepalive=self.config.keepalive,
            transport=self.config.transport,
        ) as client:
            yield _MqttJsonSession(client=client, config=self.config)

    async def run_subscription_forever(
        self,
        *,
        topics: Iterable[str],
        handler: Callable[[str, dict[str, Any]], Awaitable[None]],
        retry_delay_seconds: float = 5.0,
    ) -> None:
        while True:
            try:
                async with self.session() as session:
                    await session.consume_json(topics=topics, handler=handler)
            except Exception as exc:
                logger.warning(
                    "mqtt_subscription_failed error=%s retrying_in=%ss",
                    exc,
                    retry_delay_seconds,
                )
            await asyncio.sleep(retry_delay_seconds)


class _MqttJsonSession:
    def __init__(self, *, client: Any, config: MqttBrokerConfig):
        self.client = client
        self.config = config

    async def publish_json(
        self,
        topic: str,
        payload: dict[str, Any],
        *,
        retain: bool = False,
        qos: int | None = None,
    ) -> None:
        await self.client.publish(
            topic,
            payload=json.dumps(payload),
            retain=retain,
            qos=self.config.qos if qos is None else qos,
        )

    async def consume_json(
        self,
        *,
        topics: Iterable[str],
        handler: Callable[[str, dict[str, Any]], Awaitable[None]],
    ) -> None:
        topic_list = list(topics)
        for topic in topic_list:
            await self.client.subscribe(topic, qos=self.config.qos)
        async for message in self.client.messages:
            payload = _decode_json_payload(message.payload)
            if payload is None:
                logger.debug("mqtt_message_skipped topic=%s", message.topic)
                continue
            await handler(str(message.topic), payload)


def _decode_json_payload(payload: bytes | str | Any) -> dict[str, Any] | None:
    if isinstance(payload, bytes):
        text = payload.decode("utf-8", errors="replace")
    else:
        text = str(payload)
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return None
    if not isinstance(parsed, dict):
        return None
    return parsed


def _sanitize_topic_segment(value: str) -> str:
    return str(value).strip().replace("/", "_").replace(" ", "_")


def _coerce_optional_string(value: Any) -> str | None:
    if value in (None, ""):
        return None
    return str(value)


def _first_present(payload: dict[str, Any], keys: tuple[str, ...]) -> Any:
    for key in keys:
        value = payload.get(key)
        if value not in (None, ""):
            return value
    return None


def _load_aiomqtt() -> Any:
    try:
        import aiomqtt
    except ImportError as exc:
        raise RuntimeError(
            "aiomqtt is not installed. Install piphi-runtime-kit-python with the 'mqtt' extra."
        ) from exc
    return aiomqtt
