from __future__ import annotations

"""Helpers for thin, framework-agnostic discovery request/response handling."""

from typing import Any, Iterable, Mapping

from ..schemas import IntegrationDiscoveryResponse

DEFAULT_DISCOVERY_SECRET_KEYS = ("password", "token", "secret", "api_key")


def normalize_discovery_inputs(
    inputs: Mapping[str, Any] | None,
    *,
    drop_empty: bool = True,
) -> dict[str, Any]:
    """Normalize discovery inputs by trimming strings and dropping blank values.

    This keeps runtime discovery handlers from repeating the same request-shape
    cleanup for optional fields such as usernames, passwords, hostnames, or
    discovery hints.
    """
    if not inputs:
        return {}

    normalized: dict[str, Any] = {}
    for key, value in inputs.items():
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped and drop_empty:
                continue
            normalized[key] = stripped
            continue

        if value is None and drop_empty:
            continue

        normalized[key] = value

    return normalized


def build_discovery_response(
    devices: Iterable[Mapping[str, Any] | dict[str, Any]],
) -> IntegrationDiscoveryResponse:
    """Build a standard discovery response from any iterable of device mappings."""
    return IntegrationDiscoveryResponse(devices=[dict(device) for device in devices])


def format_discovery_attempt_log(
    *,
    inputs: Mapping[str, Any] | None = None,
    secret_keys: Iterable[str] = DEFAULT_DISCOVERY_SECRET_KEYS,
) -> str:
    """Build a safe log message describing a discovery attempt.

    Values for secret-looking fields are never logged. Instead, the message
    records which inputs were provided and whether any secret fields were used.
    """
    normalized_inputs = normalize_discovery_inputs(inputs)
    normalized_secret_keys = {key.lower() for key in secret_keys}
    provided_keys = sorted(normalized_inputs.keys())
    used_secret_keys = sorted(
        key for key in provided_keys if key.lower() in normalized_secret_keys
    )
    return (
        "discovery_attempt "
        f"input_keys={provided_keys} "
        f"uses_secrets={bool(used_secret_keys)} "
        f"secret_keys={used_secret_keys}"
    )
