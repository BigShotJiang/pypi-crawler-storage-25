from __future__ import annotations

"""Helpers for standardizing PiPhi runtime event payload handling."""

import datetime as dt
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, Iterable, Mapping
from uuid import uuid4

import httpx

from ..schemas import (
    CoreEventPayload,
    EventSeverity,
    EventTransport,
    IntegrationEventIngestResponse,
    IntegrationEventListResponse,
    IntegrationEventRequest,
)
from .auth import RuntimeAuthContext, build_runtime_auth_headers
from .errors import classify_core_delivery_error
from .state import RuntimeProcessState

DEFAULT_CORE_BASE_URL = "http://127.0.0.1:31419"
DEFAULT_EVENTS_INGEST_PATH = "/api/v2/events/ingest"
DEFAULT_TIMEOUT_SECONDS = 3.0


def normalize_event_payload(
    payload: IntegrationEventRequest | Mapping[str, Any],
) -> IntegrationEventRequest:
    """Return a validated event payload regardless of input representation."""
    if isinstance(payload, IntegrationEventRequest):
        return payload
    return IntegrationEventRequest.model_validate(payload)


def build_event_list_response(
    events: Iterable[Mapping[str, Any] | dict[str, Any]],
) -> IntegrationEventListResponse:
    """Build a standard event list response from stored runtime events."""
    return IntegrationEventListResponse(events=[dict(event) for event in events])


def build_event_ingest_response(
    event: Mapping[str, Any] | dict[str, Any],
    *,
    status: str = "accepted",
) -> IntegrationEventIngestResponse:
    """Build the standard response returned after an event is ingested."""
    return IntegrationEventIngestResponse(status=status, event=dict(event))


def format_event_log(payload: IntegrationEventRequest | Mapping[str, Any]) -> str:
    """Build a compact, consistent log message for ingested runtime events."""
    event = normalize_event_payload(payload)
    return (
        "event_ingested "
        f"event_type={event.event_type} "
        f"source={event.source or 'unknown'}"
    )


def build_core_event_payload(
    *,
    event_type: str,
    integration_id: str,
    config_id: str,
    container_id: str,
    device_id: str | None = None,
    payload: Mapping[str, Any] | None = None,
    source: str | None = None,
    severity: EventSeverity | str = EventSeverity.info,
    topic: str | None = None,
    transport: EventTransport | str = EventTransport.rest,
    event_id: str | None = None,
    ts: str | dt.datetime | None = None,
) -> CoreEventPayload:
    """Build the canonical Core event payload from runtime event details."""
    event_data = dict(payload or {})
    if source:
        event_data.setdefault("source", source)

    if isinstance(ts, str):
        parsed_ts = dt.datetime.fromisoformat(ts.replace("Z", "+00:00"))
    else:
        parsed_ts = ts

    return CoreEventPayload(
        event_id=event_id or uuid4().hex,
        type=event_type,
        ts=parsed_ts or dt.datetime.now(dt.timezone.utc),
        integration_id=integration_id,
        config_id=config_id,
        container_id=container_id,
        device_id=device_id,
        severity=severity,
        transport=transport,
        topic=topic,
        data=event_data,
    )


@dataclass(slots=True)
class EventClient:
    """Thin Core events client for runtime integrations.

    This mirrors the telemetry client pattern so integrations can post discrete
    events back to Core using the same shared runtime auth and HTTP client flow.
    """

    process_state: RuntimeProcessState
    core_base_url: str = DEFAULT_CORE_BASE_URL
    events_ingest_path: str = DEFAULT_EVENTS_INGEST_PATH
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS

    @property
    def events_ingest_url(self) -> str:
        """Return the fully qualified Core event ingest endpoint URL."""
        return f"{self.core_base_url.rstrip('/')}{self.events_ingest_path}"

    @asynccontextmanager
    async def borrow_http_client(self):
        """Yield a shared Core client when present, otherwise a temporary client."""
        if self.process_state.core_http_client is not None:
            yield self.process_state.core_http_client
            return

        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            yield client

    async def send_event(
        self,
        *,
        event_type: str,
        integration_id: str | None,
        config_id: str | None,
        auth_context: RuntimeAuthContext,
        container_id: str | None = None,
        device_id: str | None = None,
        payload: Mapping[str, Any] | None = None,
        source: str | None = None,
        severity: EventSeverity | str = EventSeverity.info,
        topic: str | None = None,
        event_id: str | None = None,
        ts: str | dt.datetime | None = None,
    ) -> bool:
        """Send one runtime event to PiPhi Core.

        Returns `False` when the runtime does not yet have enough scope
        information to publish a canonical Core event.
        """
        resolved_container_id, resolved_internal_token = auth_context.resolve(
            container_id=container_id,
        )
        if not resolved_container_id or not integration_id or not config_id:
            return False

        event = build_core_event_payload(
            event_type=event_type,
            integration_id=integration_id,
            config_id=config_id,
            container_id=resolved_container_id,
            device_id=device_id,
            payload=payload,
            source=source,
            severity=severity,
            topic=topic,
            event_id=event_id,
            ts=ts,
        )
        headers = build_runtime_auth_headers(
            container_id=resolved_container_id,
            internal_token=resolved_internal_token,
        )

        async with self.borrow_http_client() as client:
            try:
                response = await client.post(
                    self.events_ingest_url,
                    json=event.model_dump(mode="json"),
                    headers=headers,
                    timeout=self.timeout_seconds,
                )
                response.raise_for_status()
                return True
            except (httpx.HTTPStatusError, httpx.ConnectError, httpx.ReadTimeout) as exc:
                raise classify_core_delivery_error(
                    exc=exc,
                    operation="event_delivery",
                    url=self.events_ingest_url,
                    timeout_seconds=self.timeout_seconds,
                ) from exc
