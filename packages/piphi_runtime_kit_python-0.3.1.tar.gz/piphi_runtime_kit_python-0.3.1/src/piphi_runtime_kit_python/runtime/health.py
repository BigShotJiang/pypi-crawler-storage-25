from __future__ import annotations

"""Helpers for standard runtime health and diagnostics responses."""

from typing import Any, Mapping

from ..schemas import RuntimeDiagnosticsResponse, RuntimeHealthResponse
from .context import RuntimeContext


def _build_runtime_snapshot(runtime_context: RuntimeContext) -> dict[str, Any]:
    process_state = runtime_context.process_state
    return {
        "container_id": runtime_context.auth.container_id or None,
        "core_auth_present": bool(runtime_context.auth.internal_token),
        "core_http_client_bound": process_state.core_http_client is not None,
        "current_generation": process_state.current_generation,
        "pending_task_count": len(
            [task for task in process_state.background_tasks if not task.done()]
        ),
    }


def build_runtime_health_response(
    runtime_context: RuntimeContext,
    *,
    integration: Mapping[str, Any] | None = None,
    metadata: Mapping[str, Any] | None = None,
    status: str = "ok",
) -> RuntimeHealthResponse:
    """Build a compact health response for a PiPhi runtime integration."""
    return RuntimeHealthResponse(
        status=status,
        integration=dict(integration or {}),
        runtime=_build_runtime_snapshot(runtime_context),
        metadata=dict(metadata or {}),
    )


def build_runtime_diagnostics_response(
    runtime_context: RuntimeContext,
    *,
    integration: Mapping[str, Any] | None = None,
    diagnostics: Mapping[str, Any] | None = None,
    status: str = "ok",
) -> RuntimeDiagnosticsResponse:
    """Build a more detailed diagnostics response for support and debugging."""
    payload = _build_runtime_snapshot(runtime_context)
    payload.update(dict(diagnostics or {}))
    return RuntimeDiagnosticsResponse(
        status=status,
        integration=dict(integration or {}),
        diagnostics=payload,
    )
