from __future__ import annotations

"""Opinionated beginner-friendly starter helpers for PiPhi runtimes."""

from dataclasses import dataclass, field
from typing import Any

from .config_sync import ConfigSyncCoordinator
from .context import RuntimeContext
from .events import DEFAULT_CORE_BASE_URL as DEFAULT_EVENTS_CORE_BASE_URL, EventClient
from .health import build_runtime_diagnostics_response, build_runtime_health_response
from .registry import RuntimeRegistry
from .telemetry import DEFAULT_CORE_BASE_URL as DEFAULT_TELEMETRY_CORE_BASE_URL, TelemetryClient


@dataclass(slots=True)
class RuntimeStarter:
    """Small “golden path” object for beginner-friendly runtime setup.

    This intentionally bundles the runtime context, in-memory registry, config
    sync coordinator, and Core delivery clients into one obvious object so new
    integration authors have fewer moving parts to assemble by hand.
    """

    integration_id: str
    integration_name: str
    version: str = "0.1.0"
    core_base_url: str = DEFAULT_TELEMETRY_CORE_BASE_URL
    max_recent_events: int = 100
    runtime: RuntimeContext = field(init=False)
    registry: RuntimeRegistry[dict[str, Any], dict[str, Any], dict[str, Any]] = field(init=False)
    telemetry_client: TelemetryClient = field(init=False)
    event_client: EventClient = field(init=False)
    config_sync: ConfigSyncCoordinator = field(init=False)

    def __post_init__(self) -> None:
        self.runtime = RuntimeContext()
        self.registry = RuntimeRegistry(
            max_recent_events=self.max_recent_events
        )
        self.telemetry_client = TelemetryClient(
            process_state=self.runtime.process_state,
            core_base_url=self.core_base_url or DEFAULT_TELEMETRY_CORE_BASE_URL,
        )
        self.event_client = EventClient(
            process_state=self.runtime.process_state,
            core_base_url=self.core_base_url or DEFAULT_EVENTS_CORE_BASE_URL,
        )
        self.config_sync = ConfigSyncCoordinator(process_state=self.runtime.process_state)

    @property
    def integration_metadata(self) -> dict[str, Any]:
        """Return the standard integration metadata shape used in responses."""
        return {
            "id": self.integration_id,
            "name": self.integration_name,
            "version": self.version,
        }

    def health_response(self, *, metadata: dict[str, Any] | None = None):
        """Build a health response using the starter's shared runtime state."""
        return build_runtime_health_response(
            self.runtime,
            integration=self.integration_metadata,
            metadata=metadata or {"active_configs": len(self.registry.ids())},
        )

    def diagnostics_response(self, *, diagnostics: dict[str, Any] | None = None):
        """Build a diagnostics response using the starter's shared runtime state."""
        return build_runtime_diagnostics_response(
            self.runtime,
            integration=self.integration_metadata,
            diagnostics=diagnostics
            or {
                "active_config_ids": self.registry.ids(),
                "recent_event_count": len(self.registry.recent_events),
            },
        )


def create_runtime_starter(
    *,
    integration_id: str,
    integration_name: str,
    version: str = "0.1.0",
    core_base_url: str = DEFAULT_TELEMETRY_CORE_BASE_URL,
    max_recent_events: int = 100,
) -> RuntimeStarter:
    """Return the recommended beginner-friendly runtime starter object."""
    return RuntimeStarter(
        integration_id=integration_id,
        integration_name=integration_name,
        version=version,
        core_base_url=core_base_url,
        max_recent_events=max_recent_events,
    )
