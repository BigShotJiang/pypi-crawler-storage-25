from __future__ import annotations

"""Higher-level runtime context that bundles auth and process state together."""

from dataclasses import dataclass, field

import httpx

from .auth import RuntimeAuthContext
from .state import RuntimeProcessState


@dataclass(slots=True)
class RuntimeContext:
    """Top-level runtime helper container for simple integrations.

    This is the easiest entry point when an integration wants one object that
    carries both request/runtime auth state and process-scoped helper state.
    """
    auth: RuntimeAuthContext = field(default_factory=RuntimeAuthContext)
    process_state: RuntimeProcessState = field(default_factory=RuntimeProcessState)

    def set_core_http_client(self, client: httpx.AsyncClient | None) -> None:
        """Attach or clear a shared HTTP client used for Core-bound requests."""
        self.process_state.core_http_client = client

    def set_current_generation(self, generation: int | None) -> None:
        """Record the latest applied config generation for config sync flows."""
        self.process_state.current_generation = generation
