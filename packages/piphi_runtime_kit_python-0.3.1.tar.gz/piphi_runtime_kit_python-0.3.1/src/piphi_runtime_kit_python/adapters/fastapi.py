from __future__ import annotations

"""Optional FastAPI-facing helpers for common PiPhi runtime patterns."""

from typing import TYPE_CHECKING, Any, Mapping

from ..runtime.auth import RuntimeAuthHeaders
from ..runtime.context import RuntimeContext

if TYPE_CHECKING:
    from fastapi import Request


def get_payload_container_id(
    payload: object | Mapping[str, Any] | None,
    *,
    attribute_name: str = "container_id",
) -> str | None:
    """Return a normalized container id from a payload object or mapping.

    This lets integrations share one helper across Pydantic models, dataclasses,
    or plain dictionaries when wiring request auth to PiPhi container scope.
    """
    if payload is None:
        return None

    value: Any
    if isinstance(payload, Mapping):
        value = payload.get(attribute_name)
    else:
        value = getattr(payload, attribute_name, None)

    normalized = str(value or "").strip()
    return normalized or None


def sync_runtime_auth_from_fastapi_request(
    runtime_context: RuntimeContext,
    request: "Request",
    *,
    payload_container_id: str | None = None,
) -> RuntimeAuthHeaders:
    """Sync runtime auth from a FastAPI request's headers into the context.

    Typical usage:
        parsed = sync_runtime_auth_from_fastapi_request(
            runtime_context,
            request,
            payload_container_id=payload.container_id,
        )
    """
    return runtime_context.auth.sync_from_headers(
        request.headers,
        payload_container_id=payload_container_id,
    )


def sync_runtime_auth_from_fastapi_payload(
    runtime_context: RuntimeContext,
    request: "Request",
    payload: object | Mapping[str, Any] | None,
    *,
    attribute_name: str = "container_id",
) -> RuntimeAuthHeaders:
    """Sync request auth using a payload object that carries container scope."""
    return sync_runtime_auth_from_fastapi_request(
        runtime_context,
        request,
        payload_container_id=get_payload_container_id(
            payload,
            attribute_name=attribute_name,
        ),
    )
