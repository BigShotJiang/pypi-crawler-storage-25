import pytest

from piphi_runtime_kit_python.runtime.discovery import (
    DEFAULT_DISCOVERY_SECRET_KEYS,
    build_discovery_response,
    format_discovery_attempt_log,
    normalize_discovery_inputs,
)


@pytest.mark.parametrize(
    ("inputs", "drop_empty", "expected"),
    [
        (None, True, {}),
        ({}, True, {}),
        ({"host": " 10.0.0.1 "}, True, {"host": "10.0.0.1"}),
        ({"host": "   "}, True, {}),
        ({"host": "   "}, False, {"host": ""}),
        ({"port": 1883, "enabled": False}, True, {"port": 1883, "enabled": False}),
        ({"password": None}, False, {"password": None}),
    ],
)
def test_normalize_discovery_inputs_handles_edges(
    inputs,
    drop_empty: bool,
    expected: dict,
) -> None:
    assert normalize_discovery_inputs(inputs, drop_empty=drop_empty) == expected


def test_build_discovery_response_consumes_iterables() -> None:
    response = build_discovery_response(device for device in [{"id": "a"}, {"id": "b"}])
    assert response.devices == [{"id": "a"}, {"id": "b"}]


def test_format_discovery_attempt_log_marks_secret_usage() -> None:
    message = format_discovery_attempt_log(inputs={"host": "10.0.0.2", "password": "pw"})

    assert "input_keys=['host', 'password']" in message
    assert "uses_secrets=True" in message
    assert "secret_keys=['password']" in message


def test_format_discovery_attempt_log_supports_custom_secret_keys() -> None:
    message = format_discovery_attempt_log(
        inputs={"host": "10.0.0.2", "api_token": "pw"},
        secret_keys=("api_token",),
    )

    assert "uses_secrets=True" in message
    assert "secret_keys=['api_token']" in message


def test_default_discovery_secret_keys_include_expected_values() -> None:
    assert DEFAULT_DISCOVERY_SECRET_KEYS == ("password", "token", "secret", "api_key")

