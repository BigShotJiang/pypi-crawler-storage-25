from piphi_runtime_kit_python import RuntimeConfig
from piphi_runtime_kit_python.runtime.configuration import (
    build_config_apply_response,
    build_config_remove_response,
    format_config_apply_log,
    redact_config_secrets,
    validate_typed_config,
    validate_typed_configs,
)


class DemoConfig(RuntimeConfig):
    host: str
    password: str | None = None


def test_redact_config_secrets_masks_secret_values() -> None:
    redacted = redact_config_secrets(
        {
            "id": "device-1",
            "host": "10.0.0.2",
            "password": "super-secret",
        }
    )

    assert redacted["password"] == "***"
    assert redacted["host"] == "10.0.0.2"


def test_format_config_apply_log_redacts_payload() -> None:
    payload = DemoConfig(id="device-1", host="10.0.0.2", password="super-secret")

    message = format_config_apply_log(payload)

    assert "config_id=device-1" in message
    assert "super-secret" not in message
    assert "'password': '***'" in message


def test_build_config_apply_and_remove_responses_return_typed_models() -> None:
    apply_response = build_config_apply_response(config_id="device-1")
    remove_response = build_config_remove_response(config_id="device-1", removed=True)

    assert apply_response.status == "configured"
    assert apply_response.config_id == "device-1"
    assert remove_response.status == "deconfigured"
    assert remove_response.removed is True


def test_validate_typed_config_and_configs_return_typed_models() -> None:
    payload = {"id": "device-1", "host": "10.0.0.2", "password": "secret"}

    config = validate_typed_config(payload, DemoConfig)
    configs = validate_typed_configs([payload], DemoConfig)

    assert isinstance(config, DemoConfig)
    assert isinstance(configs[0], DemoConfig)
    assert config.host == "10.0.0.2"
