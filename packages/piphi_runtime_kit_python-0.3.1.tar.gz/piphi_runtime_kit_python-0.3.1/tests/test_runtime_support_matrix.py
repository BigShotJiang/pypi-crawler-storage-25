from types import SimpleNamespace

import httpx
import pytest

from piphi_runtime_kit_python import RuntimeContext, RuntimeStarter, create_runtime_starter
from piphi_runtime_kit_python.fastapi import get_payload_container_id
from piphi_runtime_kit_python.runtime.health import (
    build_runtime_diagnostics_response,
    build_runtime_health_response,
)
from piphi_runtime_kit_python.runtime.lifespan import (
    bind_core_http_client,
    bootstrap_runtime_auth_from_env,
    runtime_lifespan,
)
from piphi_runtime_kit_python.runtime.state import RuntimeProcessState


def test_runtime_process_state_defaults_are_empty() -> None:
    state = RuntimeProcessState()
    assert state.current_generation is None
    assert state.core_http_client is None
    assert state.background_tasks == set()


def test_runtime_context_setters_update_process_state() -> None:
    runtime = RuntimeContext()
    runtime.set_current_generation(22)
    assert runtime.process_state.current_generation == 22


def test_runtime_context_set_core_http_client_can_clear_binding() -> None:
    runtime = RuntimeContext()
    client = httpx.AsyncClient()
    runtime.set_core_http_client(client)
    assert runtime.process_state.core_http_client is client
    runtime.set_core_http_client(None)
    assert runtime.process_state.core_http_client is None


def test_build_runtime_health_response_supports_custom_status() -> None:
    runtime = RuntimeContext()
    response = build_runtime_health_response(runtime, status="degraded")
    assert response.status == "degraded"


def test_build_runtime_diagnostics_response_merges_diagnostics_into_snapshot() -> None:
    runtime = RuntimeContext()
    runtime.auth.container_id = "container-1"
    response = build_runtime_diagnostics_response(
        runtime,
        diagnostics={"recent_event_count": 3},
    )

    assert response.diagnostics["container_id"] == "container-1"
    assert response.diagnostics["recent_event_count"] == 3


def test_build_runtime_health_response_counts_only_pending_tasks() -> None:
    runtime = RuntimeContext()
    done_task = _done_task()
    runtime.process_state.background_tasks.add(done_task)

    response = build_runtime_health_response(runtime)

    assert response.runtime["pending_task_count"] == 0


def test_bootstrap_runtime_auth_from_env_supports_custom_names(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime = RuntimeContext()
    monkeypatch.setenv("CUSTOM_CONTAINER", "container-custom")
    monkeypatch.setenv("CUSTOM_TOKEN", "token-custom")

    container_id, token = bootstrap_runtime_auth_from_env(
        runtime,
        container_env_name="CUSTOM_CONTAINER",
        token_env_name="CUSTOM_TOKEN",
    )

    assert container_id == "container-custom"
    assert token == "token-custom"
    assert runtime.auth.container_id == "container-custom"
    assert runtime.auth.internal_token == "token-custom"


@pytest.mark.asyncio
async def test_bind_core_http_client_binds_and_clears_runtime_client() -> None:
    runtime = RuntimeContext()

    async with bind_core_http_client(runtime, timeout_seconds=4.5) as client:
        assert runtime.process_state.core_http_client is client
        assert client.timeout.connect == 4.5

    assert runtime.process_state.core_http_client is None


@pytest.mark.asyncio
async def test_runtime_lifespan_calls_shutdown_callback(monkeypatch: pytest.MonkeyPatch) -> None:
    runtime = RuntimeContext()
    monkeypatch.setenv("PIPHI_CONTAINER_ID", "container-lifespan")
    monkeypatch.setenv("PIPHI_INTEGRATION_INTERNAL_TOKEN", "token-lifespan")
    shutdown_calls: list[str] = []

    async def on_shutdown(context: RuntimeContext) -> None:
        shutdown_calls.append(context.auth.container_id)

    async with runtime_lifespan(runtime, on_shutdown=on_shutdown):
        assert runtime.process_state.core_http_client is not None

    assert shutdown_calls == ["container-lifespan"]


@pytest.mark.asyncio
async def test_runtime_lifespan_uses_custom_env_names(monkeypatch: pytest.MonkeyPatch) -> None:
    runtime = RuntimeContext()
    monkeypatch.setenv("APP_CONTAINER", "container-custom-env")
    monkeypatch.setenv("APP_TOKEN", "token-custom-env")

    async with runtime_lifespan(
        runtime,
        container_env_name="APP_CONTAINER",
        token_env_name="APP_TOKEN",
    ):
        assert runtime.auth.container_id == "container-custom-env"
        assert runtime.auth.internal_token == "token-custom-env"


def test_get_payload_container_id_returns_none_for_blank_values() -> None:
    assert get_payload_container_id({"container_id": "   "}) is None
    assert get_payload_container_id(SimpleNamespace(container_id="")) is None


def test_get_payload_container_id_supports_custom_attribute_name() -> None:
    payload = {"scope_id": "container-attr"}
    assert get_payload_container_id(payload, attribute_name="scope_id") == "container-attr"


def test_runtime_starter_health_response_uses_default_active_config_metadata() -> None:
    starter = create_runtime_starter(
        integration_id="demo-runtime",
        integration_name="Demo Runtime",
    )
    starter.registry.set("device-1", {"device_id": "device-1"})

    response = starter.health_response()

    assert response.metadata == {"active_configs": 1}


def test_runtime_starter_diagnostics_response_uses_default_runtime_data() -> None:
    starter = RuntimeStarter(integration_id="demo-2", integration_name="Demo Two")
    starter.registry.set("device-2", {"device_id": "device-2"})
    starter.registry.append_event({"event_type": "device.updated"})

    response = starter.diagnostics_response()

    assert response.diagnostics["active_config_ids"] == ["device-2"]
    assert response.diagnostics["recent_event_count"] == 1


def test_runtime_starter_passes_core_base_url_to_clients() -> None:
    starter = RuntimeStarter(
        integration_id="demo-3",
        integration_name="Demo Three",
        core_base_url="http://core.example",
    )

    assert starter.telemetry_client.core_base_url == "http://core.example"
    assert starter.event_client.core_base_url == "http://core.example"


def _done_task():
    import asyncio

    async def worker() -> None:
        return None

    loop = asyncio.new_event_loop()
    try:
        task = loop.create_task(worker())
        loop.run_until_complete(task)
        return task
    finally:
        loop.close()

