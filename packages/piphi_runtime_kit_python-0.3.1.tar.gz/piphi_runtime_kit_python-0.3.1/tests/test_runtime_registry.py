from piphi_runtime_kit_python import RuntimeRegistry


def test_runtime_registry_set_get_and_ids() -> None:
    registry = RuntimeRegistry()
    registry.set("device-1", {"device_id": "device-1", "host": "10.0.0.2"})

    assert registry.get("device-1") == {"device_id": "device-1", "host": "10.0.0.2"}
    assert registry.ids() == ["device-1"]
    assert registry.primary_entry() == {"device_id": "device-1", "host": "10.0.0.2"}


def test_runtime_registry_update_state_mirrors_latest_state_to_entry() -> None:
    registry = RuntimeRegistry()
    registry.set("device-1", {"device_id": "device-1"})

    latest_state = registry.update_state("device-1", {"is_on": True})

    assert latest_state["device_id"] == "device-1"
    assert registry.state_snapshots["device-1"]["state"] == {"is_on": True}
    assert registry.entries["device-1"]["latest_state"] == {"is_on": True}


def test_runtime_registry_append_event_bounds_recent_event_window() -> None:
    registry = RuntimeRegistry(max_recent_events=2)

    registry.append_event({"event_type": "one"})
    registry.append_event({"event_type": "two"})
    registry.append_event({"event_type": "three"})

    assert [event["event_type"] for event in registry.recent_events] == ["two", "three"]


def test_runtime_registry_remove_clears_entry_and_state() -> None:
    registry = RuntimeRegistry()
    registry.set("device-1", {"device_id": "device-1"})
    registry.update_state("device-1", {"is_on": True})

    removed = registry.remove("device-1")

    assert removed is not None
    assert removed["device_id"] == "device-1"
    assert removed["latest_state"] == {"is_on": True}
    assert "last_updated" in removed
    assert registry.get("device-1") is None
    assert "device-1" not in registry.state_snapshots
