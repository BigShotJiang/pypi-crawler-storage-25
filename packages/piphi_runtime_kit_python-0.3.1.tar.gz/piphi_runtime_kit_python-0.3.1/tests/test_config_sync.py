import pytest

from piphi_runtime_kit_python import (
    ConfigSyncCoordinator,
    RuntimeConfig,
    RuntimeConfigSnapshot,
    RuntimeProcessState,
    reconcile_config_ids,
)


def test_reconcile_config_ids_returns_removed_and_unchanged_ids() -> None:
    removed_ids, unchanged_ids = reconcile_config_ids(
        active_ids=["a", "b", "c"],
        incoming_ids=["b", "c", "d"],
    )

    assert removed_ids == ["a"]
    assert unchanged_ids == ["b", "c"]


def test_config_sync_coordinator_detects_stale_snapshot() -> None:
    state = RuntimeProcessState(current_generation=10)
    coordinator = ConfigSyncCoordinator(process_state=state)
    snapshot = RuntimeConfigSnapshot(
        container_id="container-1",
        generation=9,
        configs=[RuntimeConfig(id="device-1")],
    )

    assert coordinator.is_stale(snapshot) is True


def test_config_sync_coordinator_updates_generation() -> None:
    state = RuntimeProcessState()
    coordinator = ConfigSyncCoordinator(process_state=state)

    assert coordinator.mark_generation(42) == 42
    assert state.current_generation == 42


@pytest.mark.asyncio
async def test_config_sync_coordinator_apply_snapshot_orchestrates_callbacks() -> None:
    state = RuntimeProcessState(current_generation=1)
    coordinator = ConfigSyncCoordinator(process_state=state)
    snapshot = RuntimeConfigSnapshot(
        container_id="container-1",
        generation=2,
        configs=[RuntimeConfig(id="device-2"), RuntimeConfig(id="device-3")],
    )
    active_ids = ["device-1", "device-2"]
    applied: list[str] = []
    removed: list[str] = []

    async def apply_config(config: RuntimeConfig) -> None:
        applied.append(config.id)

    async def remove_config(config_id: str) -> bool:
        removed.append(config_id)
        return True

    response = await coordinator.apply_snapshot(
        snapshot=snapshot,
        active_config_ids=active_ids,
        apply_config=apply_config,
        remove_config=remove_config,
        get_active_config_ids=lambda: ["device-2", "device-3"],
    )

    assert applied == ["device-2", "device-3"]
    assert removed == ["device-1"]
    assert response.status == "synced"
    assert response.generation == 2
    assert response.active_config_ids == ["device-2", "device-3"]
