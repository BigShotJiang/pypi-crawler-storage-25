from piphi_runtime_kit_python import RuntimeRegistry


def test_runtime_registry_get_returns_none_for_missing_entry() -> None:
    assert RuntimeRegistry().get("missing") is None


def test_runtime_registry_remove_returns_none_for_missing_entry() -> None:
    assert RuntimeRegistry().remove("missing") is None


def test_runtime_registry_primary_entry_returns_none_when_empty() -> None:
    assert RuntimeRegistry().primary_entry() is None


def test_runtime_registry_ids_preserve_insertion_order() -> None:
    registry = RuntimeRegistry()
    registry.set("device-1", {"device_id": "device-1"})
    registry.set("device-2", {"device_id": "device-2"})

    assert registry.ids() == ["device-1", "device-2"]


def test_runtime_registry_set_overwrites_existing_entry() -> None:
    registry = RuntimeRegistry()
    registry.set("device-1", {"device_id": "device-1", "value": 1})
    registry.set("device-1", {"device_id": "device-1", "value": 2})

    assert registry.get("device-1") == {"device_id": "device-1", "value": 2}


def test_runtime_registry_update_state_creates_snapshot_without_entry() -> None:
    registry = RuntimeRegistry()

    latest_state = registry.update_state("device-3", {"humidity": 50})

    assert latest_state["device_id"] == "device-3"
    assert registry.entries == {}
    assert registry.state_snapshots["device-3"]["state"] == {"humidity": 50}


def test_runtime_registry_update_state_sets_last_updated_on_entry() -> None:
    registry = RuntimeRegistry()
    registry.set("device-4", {"device_id": "device-4"})

    latest_state = registry.update_state("device-4", {"temperature": 20})

    assert registry.entries["device-4"]["last_updated"] == latest_state["last_updated"]


def test_runtime_registry_append_event_adds_received_at() -> None:
    registry = RuntimeRegistry()

    event = registry.append_event({"event_type": "device.updated"})

    assert event["event_type"] == "device.updated"
    assert "received_at" in event


def test_runtime_registry_remove_leaves_recent_events_untouched() -> None:
    registry = RuntimeRegistry()
    registry.set("device-5", {"device_id": "device-5"})
    registry.append_event({"event_type": "device.updated"})

    registry.remove("device-5")

    assert len(registry.recent_events) == 1

