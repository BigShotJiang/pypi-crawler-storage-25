from piphi_runtime_kit_python import RuntimeContext
from piphi_runtime_kit_python.runtime.health import (
    build_runtime_diagnostics_response,
    build_runtime_health_response,
)


def test_build_runtime_health_response_includes_runtime_state() -> None:
    runtime = RuntimeContext()
    runtime.auth.update(container_id="container-1", internal_token="token-1")
    runtime.set_current_generation(5)

    response = build_runtime_health_response(
        runtime,
        integration={"id": "demo", "version": "0.2.0"},
        metadata={"configured_devices": 2},
    )

    assert response.status == "ok"
    assert response.integration["id"] == "demo"
    assert response.runtime["container_id"] == "container-1"
    assert response.runtime["current_generation"] == 5
    assert response.metadata["configured_devices"] == 2


def test_build_runtime_diagnostics_response_includes_extra_details() -> None:
    runtime = RuntimeContext()

    response = build_runtime_diagnostics_response(
        runtime,
        integration={"id": "demo", "version": "0.2.0"},
        diagnostics={"configured_device_ids": ["plug-1"]},
    )

    assert response.status == "ok"
    assert response.integration["version"] == "0.2.0"
    assert response.diagnostics["configured_device_ids"] == ["plug-1"]
    assert "pending_task_count" in response.diagnostics
