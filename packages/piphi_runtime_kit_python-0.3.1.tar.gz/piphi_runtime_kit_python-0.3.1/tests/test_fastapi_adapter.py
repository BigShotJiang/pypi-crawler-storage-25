from types import SimpleNamespace

from piphi_runtime_kit_python import RuntimeContext
from piphi_runtime_kit_python.fastapi import (
    get_payload_container_id,
    sync_runtime_auth_from_fastapi_payload,
    sync_runtime_auth_from_fastapi_request,
)


class DummyRequest:
    def __init__(self, headers: dict[str, str]) -> None:
        self.headers = headers


def test_get_payload_container_id_supports_objects_and_mappings() -> None:
    object_payload = SimpleNamespace(container_id="container-1")
    mapping_payload = {"container_id": "container-2"}

    assert get_payload_container_id(object_payload) == "container-1"
    assert get_payload_container_id(mapping_payload) == "container-2"


def test_sync_runtime_auth_from_fastapi_request_updates_context() -> None:
    runtime = RuntimeContext()
    request = DummyRequest(
        {
            "X-Container-Id": "container-1",
            "X-PiPhi-Integration-Token": "token-1",
        }
    )

    parsed = sync_runtime_auth_from_fastapi_request(runtime, request)

    assert parsed.container_id == "container-1"
    assert parsed.internal_token == "token-1"
    assert runtime.auth.container_id == "container-1"
    assert runtime.auth.internal_token == "token-1"


def test_sync_runtime_auth_from_fastapi_payload_uses_payload_fallback() -> None:
    runtime = RuntimeContext()
    request = DummyRequest({"X-PiPhi-Integration-Token": "token-1"})
    payload = SimpleNamespace(container_id="container-9")

    parsed = sync_runtime_auth_from_fastapi_payload(runtime, request, payload)

    assert parsed.container_id == ""
    assert runtime.auth.container_id == "container-9"
    assert runtime.auth.internal_token == "token-1"
