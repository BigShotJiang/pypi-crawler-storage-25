import httpx
import pytest

from piphi_runtime_kit_python import (
    EventClient,
    RuntimeAuthContext,
    RuntimeProcessState,
    TelemetryClient,
)
from piphi_runtime_kit_python.runtime.dispatch import (
    build_local_event_record,
    dispatch_telemetry_delivery,
    schedule_event_delivery,
)


def test_build_local_event_record_returns_expected_shape() -> None:
    record = build_local_event_record(
        event_type="device.turned_on",
        device={
            "device_id": "plug-1",
            "container_id": "container-1",
            "integration_id": "tp-link-kasa",
            "config_id": "plug-1",
        },
        payload={"host": "10.0.0.227"},
        source="tp_link_kasa_runtime",
        severity="info",
    )

    assert record["event_type"] == "device.turned_on"
    assert record["device_id"] == "plug-1"
    assert record["payload"]["host"] == "10.0.0.227"


@pytest.mark.asyncio
async def test_dispatch_telemetry_delivery_calls_skip_handler_when_scope_missing() -> None:
    skipped: list[tuple[str, dict]] = []
    client = TelemetryClient(process_state=RuntimeProcessState())

    delivered = await dispatch_telemetry_delivery(
        telemetry_client=client,
        auth_context=RuntimeAuthContext(),
        device_id="plug-1",
        metrics={"is_on": True},
        on_skipped=lambda reason, details: skipped.append((reason, details)),
    )

    assert delivered is False
    assert skipped[0][0] == "missing_container_id"


@pytest.mark.asyncio
async def test_schedule_event_delivery_records_local_event_and_posts_to_core() -> None:
    requests: list[httpx.Request] = []
    local_events: list[dict] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"accepted": True})

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    event_client = EventClient(process_state=process_state, core_base_url="http://core.test")
    auth_context = RuntimeAuthContext(container_id="container-1", internal_token="secret-token")

    try:
        task = schedule_event_delivery(
            process_state=process_state,
            event_client=event_client,
            auth_context=auth_context,
            event_type="device.turned_on",
            device={
                "device_id": "plug-1",
                "container_id": "container-1",
                "integration_id": "tp-link-kasa",
                "config_id": "plug-1",
            },
            payload={"host": "10.0.0.227"},
            source="tp_link_kasa_runtime",
            record_event=local_events.append,
        )
        await task
    finally:
        await process_state.core_http_client.aclose()

    assert len(local_events) == 1
    assert local_events[0]["event_type"] == "device.turned_on"
    assert len(requests) == 1
    assert str(requests[0].url) == "http://core.test/api/v2/events/ingest"
