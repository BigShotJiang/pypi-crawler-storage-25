import asyncio
import json
import sys
from types import ModuleType, SimpleNamespace

import pytest

from piphi_runtime_kit_python.runtime.mqtt import (
    DEFAULT_SOURCE_TOPIC_PREFIX,
    MqttBrokerConfig,
    _MqttJsonSession,
    _coerce_optional_string,
    _decode_json_payload,
    _first_present,
    _load_aiomqtt,
    _sanitize_topic_segment,
    build_source_errors_topic,
    build_source_model_packets_topic,
    build_source_packet_envelope,
    build_source_packets_topic,
    build_source_status_topic,
    build_source_topic_root,
)


def test_source_topic_builders_support_custom_prefixes() -> None:
    assert build_source_topic_root("rtl 433", prefix="custom/prefix") == "custom/prefix/rtl_433"
    assert build_source_packets_topic("rtl/433", prefix="custom") == "custom/rtl_433/packets"
    assert (
        build_source_model_packets_topic("rtl433", "Nexus TH", prefix="custom")
        == "custom/rtl433/models/Nexus_TH/packets"
    )
    assert build_source_status_topic("rtl433", prefix="custom") == "custom/rtl433/status"
    assert build_source_errors_topic("rtl433", prefix="custom") == "custom/rtl433/errors"


@pytest.mark.parametrize(
    ("packet", "expected_id", "expected_channel"),
    [
        ({"id": 1, "channel": 2}, "1", "2"),
        ({"device_id": "dev-1", "subtype": "A"}, "dev-1", "A"),
        ({"device": "dev-2"}, "dev-2", None),
        ({"sid": "sensor-7"}, "sensor-7", None),
        ({"unit": 9}, "9", None),
    ],
)
def test_build_source_packet_envelope_uses_supported_device_hint_keys(
    packet: dict,
    expected_id: str | None,
    expected_channel: str | None,
) -> None:
    envelope = build_source_packet_envelope(source="rtl433", packet=packet)

    assert envelope["device_hint"]["id"] == expected_id
    assert envelope["device_hint"]["channel"] == expected_channel


def test_build_source_packet_envelope_preserves_metadata_and_received_at() -> None:
    envelope = build_source_packet_envelope(
        source="rtl433",
        packet={"model": "Nexus"},
        received_at="2026-04-10T00:00:00Z",
        metadata={"driver": "rtl_433"},
    )

    assert envelope["received_at"] == "2026-04-10T00:00:00Z"
    assert envelope["metadata"] == {"driver": "rtl_433"}


@pytest.mark.parametrize(
    ("payload", "expected"),
    [
        (b'{"temperature_C": 22.1}', {"temperature_C": 22.1}),
        ('{"humidity": 55}', {"humidity": 55}),
        ("not-json", None),
        ('["not", "a", "dict"]', None),
    ],
)
def test_decode_json_payload_handles_valid_and_invalid_input(payload, expected) -> None:
    assert _decode_json_payload(payload) == expected


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("rtl 433", "rtl_433"),
        ("rtl/433", "rtl_433"),
        (" rtl433 ", "rtl433"),
    ],
)
def test_sanitize_topic_segment_normalizes_values(value: str, expected: str) -> None:
    assert _sanitize_topic_segment(value) == expected


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (None, None),
        ("", None),
        ("ok", "ok"),
        (42, "42"),
    ],
)
def test_coerce_optional_string_handles_expected_values(value, expected: str | None) -> None:
    assert _coerce_optional_string(value) == expected


def test_first_present_returns_first_non_empty_key() -> None:
    payload = {"id": "", "device_id": None, "sid": "sensor-1", "unit": "sensor-2"}
    assert _first_present(payload, ("id", "device_id", "sid", "unit")) == "sensor-1"


def test_first_present_returns_none_when_all_candidates_are_empty() -> None:
    assert _first_present({"id": "", "device_id": None}, ("id", "device_id")) is None


def test_load_aiomqtt_raises_runtime_error_when_module_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "aiomqtt", None)
    real_import = __import__

    def fake_import(name, *args, **kwargs):
        if name == "aiomqtt":
            raise ImportError("missing")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", fake_import)

    with pytest.raises(RuntimeError):
        _load_aiomqtt()


@pytest.mark.asyncio
async def test_mqtt_json_session_publish_json_uses_default_qos() -> None:
    published: list[tuple] = []

    class FakeClient:
        async def publish(self, topic, payload, retain, qos):
            published.append((topic, payload, retain, qos))

    session = _MqttJsonSession(client=FakeClient(), config=MqttBrokerConfig(hostname="mqtt.test", qos=1))

    await session.publish_json("topic/one", {"value": 1}, retain=True)

    assert published == [("topic/one", json.dumps({"value": 1}), True, 1)]


@pytest.mark.asyncio
async def test_mqtt_json_session_publish_json_supports_qos_override() -> None:
    published: list[int] = []

    class FakeClient:
        async def publish(self, topic, payload, retain, qos):
            published.append(qos)

    session = _MqttJsonSession(client=FakeClient(), config=MqttBrokerConfig(hostname="mqtt.test", qos=0))

    await session.publish_json("topic/two", {"value": 2}, qos=2)

    assert published == [2]


@pytest.mark.asyncio
async def test_mqtt_json_session_consume_json_subscribes_and_handles_valid_messages() -> None:
    subscribed: list[tuple[str, int]] = []
    handled: list[tuple[str, dict]] = []

    class FakeClient:
        def __init__(self) -> None:
            self.messages = self._messages()

        async def subscribe(self, topic, qos):
            subscribed.append((topic, qos))

        async def _messages(self):
            yield SimpleNamespace(topic="topic/a", payload=b'{"value": 1}')
            yield SimpleNamespace(topic="topic/b", payload=b"not-json")

    async def handler(topic: str, payload: dict) -> None:
        handled.append((topic, payload))

    session = _MqttJsonSession(client=FakeClient(), config=MqttBrokerConfig(hostname="mqtt.test", qos=1))
    await session.consume_json(topics=["topic/a", "topic/b"], handler=handler)

    assert subscribed == [("topic/a", 1), ("topic/b", 1)]
    assert handled == [("topic/a", {"value": 1})]


def test_mqtt_module_default_source_prefix_is_stable() -> None:
    assert DEFAULT_SOURCE_TOPIC_PREFIX == "piphi/sources"

