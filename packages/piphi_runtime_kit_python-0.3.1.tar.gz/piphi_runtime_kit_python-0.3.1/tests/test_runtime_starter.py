from piphi_runtime_kit_python import RuntimeStarter, create_runtime_starter


def test_create_runtime_starter_bundles_common_runtime_parts() -> None:
    starter = create_runtime_starter(
        integration_id="demo-runtime",
        integration_name="Demo Runtime",
        version="0.1.0",
        max_recent_events=25,
    )

    assert isinstance(starter, RuntimeStarter)
    assert starter.integration_metadata == {
        "id": "demo-runtime",
        "name": "Demo Runtime",
        "version": "0.1.0",
    }
    assert starter.registry.max_recent_events == 25
    assert starter.telemetry_client.process_state is starter.runtime.process_state
    assert starter.event_client.process_state is starter.runtime.process_state
    assert starter.config_sync.process_state is starter.runtime.process_state
