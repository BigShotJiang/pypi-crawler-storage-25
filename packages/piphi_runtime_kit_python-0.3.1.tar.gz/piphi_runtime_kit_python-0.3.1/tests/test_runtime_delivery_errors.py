import httpx
import pytest

from piphi_runtime_kit_python import (
    CoreRouteNotFoundError,
    CoreTimeoutError,
    CoreUnavailableError,
    EventClient,
    RuntimeAuthContext,
    RuntimeProcessState,
    TelemetryClient,
)


@pytest.mark.asyncio
async def test_telemetry_client_raises_core_unavailable_error() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom", request=request)

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = TelemetryClient(process_state=process_state, core_base_url="http://core.test")
    auth_context = RuntimeAuthContext(container_id="container-1", internal_token="secret-token")

    try:
        with pytest.raises(CoreUnavailableError) as exc_info:
            await client.send_metrics(
                device_id="plug-1",
                metrics={"is_on": True},
                auth_context=auth_context,
            )
    finally:
        await process_state.core_http_client.aclose()

    assert exc_info.value.operation == "telemetry_delivery"
    assert exc_info.value.retryable is True
    assert "PiPhi Core is unreachable" in str(exc_info.value)


@pytest.mark.asyncio
async def test_telemetry_client_raises_core_timeout_error() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("slow", request=request)

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = TelemetryClient(
        process_state=process_state,
        core_base_url="http://core.test",
        timeout_seconds=8.0,
    )
    auth_context = RuntimeAuthContext(container_id="container-1", internal_token="secret-token")

    try:
        with pytest.raises(CoreTimeoutError) as exc_info:
            await client.send_metrics(
                device_id="plug-1",
                metrics={"current_power_w": 12.4},
                auth_context=auth_context,
            )
    finally:
        await process_state.core_http_client.aclose()

    assert exc_info.value.timeout_seconds == 8.0
    assert "did not respond before the request timeout" in str(exc_info.value)


@pytest.mark.asyncio
async def test_event_client_raises_route_not_found_error() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "Not Found"}, request=request)

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = EventClient(process_state=process_state, core_base_url="http://core.test")
    auth_context = RuntimeAuthContext(container_id="container-1", internal_token="secret-token")

    try:
        with pytest.raises(CoreRouteNotFoundError) as exc_info:
            await client.send_event(
                event_type="device.turned_on",
                integration_id="tp-link-kasa",
                config_id="plug-1",
                auth_context=auth_context,
                device_id="plug-1",
            )
    finally:
        await process_state.core_http_client.aclose()

    assert exc_info.value.status_code == 404
    assert exc_info.value.operation == "event_delivery"
    assert "route is not available" in str(exc_info.value)
