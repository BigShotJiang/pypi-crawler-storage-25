from datetime import datetime, timezone

from piphi_runtime_kit_python import (
    CoreEventPayload,
    EventSeverity,
    EventTransport,
    IntegrationCommandRequest,
    IntegrationDiscoveryRequest,
    IntegrationDiscoveryResponse,
    IntegrationEventIngestResponse,
    IntegrationEventListResponse,
    IntegrationEventRequest,
    RuntimeConfig,
    RuntimeConfigApplyResponse,
    RuntimeConfigRemoveResponse,
    RuntimeConfigSnapshot,
    RuntimeConfigSyncResponse,
    RuntimeDiagnosticsResponse,
    RuntimeHealthResponse,
    TelemetryPayload,
)


def test_runtime_config_allows_extra_fields() -> None:
    config = RuntimeConfig(id="device-1", host="10.0.0.1")
    assert config.model_dump()["host"] == "10.0.0.1"


def test_runtime_config_snapshot_defaults_configs_to_empty_list() -> None:
    snapshot = RuntimeConfigSnapshot(container_id="container-1")
    assert snapshot.configs == []


def test_runtime_config_sync_response_defaults_collections() -> None:
    response = RuntimeConfigSyncResponse(status="ok", container_id="container-1")
    assert response.applied == []
    assert response.removed == []
    assert response.active_config_ids == []
    assert response.metadata == {}


def test_runtime_config_apply_response_defaults_metadata() -> None:
    response = RuntimeConfigApplyResponse(config_id="device-2")
    assert response.status == "configured"
    assert response.metadata == {}


def test_runtime_config_remove_response_defaults_removed_and_metadata() -> None:
    response = RuntimeConfigRemoveResponse(config_id="device-3")
    assert response.status == "deconfigured"
    assert response.removed is True
    assert response.metadata == {}


def test_integration_discovery_request_defaults_inputs() -> None:
    request = IntegrationDiscoveryRequest()
    assert request.inputs == {}


def test_integration_discovery_response_defaults_devices() -> None:
    response = IntegrationDiscoveryResponse()
    assert response.devices == []


def test_integration_command_request_defaults_args() -> None:
    request = IntegrationCommandRequest(command="refresh")
    assert request.args == {}


def test_integration_event_request_defaults_payload() -> None:
    request = IntegrationEventRequest(event_type="device.updated")
    assert request.payload == {}


def test_event_list_and_ingest_responses_default_cleanly() -> None:
    assert IntegrationEventListResponse().events == []
    assert IntegrationEventIngestResponse().status == "accepted"
    assert IntegrationEventIngestResponse().event == {}


def test_event_severity_and_transport_values_are_stable() -> None:
    assert EventSeverity.info.value == "info"
    assert EventSeverity.warning.value == "warning"
    assert EventTransport.rest.value == "rest"
    assert EventTransport.mqtt.value == "mqtt"


def test_core_event_payload_defaults_runtime_fields() -> None:
    payload = CoreEventPayload(event_id="event-1", type="device.updated")
    assert payload.severity == EventSeverity.info
    assert payload.transport == EventTransport.rest
    assert isinstance(payload.ts, datetime)
    assert payload.ts.tzinfo == timezone.utc
    assert payload.received_at.tzinfo == timezone.utc
    assert payload.data == {}


def test_runtime_health_and_diagnostics_response_defaults() -> None:
    assert RuntimeHealthResponse().status == "ok"
    assert RuntimeHealthResponse().integration == {}
    assert RuntimeDiagnosticsResponse().diagnostics == {}


def test_telemetry_payload_defaults_units() -> None:
    payload = TelemetryPayload(
        device_id="device-4",
        metrics={"temperature": 21.5},
        timestamp="2026-04-10T00:00:00Z",
    )
    assert payload.units == {}


def test_core_event_payload_model_dump_json_serializes_enums_and_datetimes() -> None:
    payload = CoreEventPayload(
        event_id="event-2",
        type="device.updated",
        severity=EventSeverity.error,
        transport=EventTransport.mqtt,
    )
    dumped = payload.model_dump(mode="json")
    assert dumped["severity"] == "error"
    assert dumped["transport"] == "mqtt"
    assert dumped["ts"].endswith("Z")

