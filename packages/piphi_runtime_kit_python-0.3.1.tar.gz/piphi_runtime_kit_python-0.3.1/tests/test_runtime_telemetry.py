from piphi_runtime_kit_python import TelemetryPayload
from piphi_runtime_kit_python.runtime.telemetry import build_telemetry_payload


def test_build_telemetry_payload_returns_typed_model() -> None:
    payload = build_telemetry_payload(
        device_id="device-1",
        metrics={"is_on": True},
        units={"is_on": "bool"},
        timestamp="2026-04-05T00:00:00Z",
    )

    assert isinstance(payload, TelemetryPayload)
    assert payload.device_id == "device-1"
    assert payload.metrics == {"is_on": True}
    assert payload.units == {"is_on": "bool"}
    assert payload.timestamp == "2026-04-05T00:00:00Z"
