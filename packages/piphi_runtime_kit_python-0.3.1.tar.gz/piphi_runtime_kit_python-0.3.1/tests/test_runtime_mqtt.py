from piphi_runtime_kit_python import (
    build_source_errors_topic,
    build_source_model_packets_topic,
    build_source_packet_envelope,
    build_source_packets_topic,
    build_source_status_topic,
    build_source_topic_root,
)


def test_build_source_topics_returns_clean_paths() -> None:
    assert build_source_topic_root("rtl433") == "piphi/sources/rtl433"
    assert build_source_packets_topic("rtl433") == "piphi/sources/rtl433/packets"
    assert (
        build_source_model_packets_topic("rtl433", "Nexus TH")
        == "piphi/sources/rtl433/models/Nexus_TH/packets"
    )
    assert build_source_status_topic("rtl433") == "piphi/sources/rtl433/status"
    assert build_source_errors_topic("rtl433") == "piphi/sources/rtl433/errors"


def test_build_source_packet_envelope_includes_device_hint() -> None:
    envelope = build_source_packet_envelope(
        source="rtl433",
        packet={
            "model": "Nexus-TH",
            "id": 42,
            "channel": 1,
            "temperature_C": 22.1,
        },
    )

    assert envelope["source"] == "rtl433"
    assert envelope["model"] == "Nexus-TH"
    assert envelope["device_hint"]["id"] == "42"
    assert envelope["device_hint"]["channel"] == "1"
    assert envelope["packet"]["temperature_C"] == 22.1
