import pytest

from piphi_runtime_kit_python import RuntimeConfig, RuntimeConfigSnapshot, RuntimeProcessState
from piphi_runtime_kit_python.runtime.config_sync import (
    ConfigSyncCoordinator,
    build_sync_response,
    reconcile_config_ids,
)


@pytest.mark.parametrize(
    ("active_ids", "incoming_ids", "removed_ids", "unchanged_ids"),
    [
        ([], [], [], []),
        (["a"], ["a"], [], ["a"]),
        (["a", "b"], ["b", "c"], ["a"], ["b"]),
        (["c", "a", "b"], ["b", "a"], ["c"], ["a", "b"]),
    ],
)
def test_reconcile_config_ids_returns_sorted_buckets(
    active_ids: list[str],
    incoming_ids: list[str],
    removed_ids: list[str],
    unchanged_ids: list[str],
) -> None:
    assert reconcile_config_ids(active_ids=active_ids, incoming_ids=incoming_ids) == (
        removed_ids,
        unchanged_ids,
    )


def test_build_sync_response_populates_defaults() -> None:
    response = build_sync_response(status="synced", container_id="container-1")

    assert response.status == "synced"
    assert response.reason is None
    assert response.applied == []
    assert response.removed == []
    assert response.active_config_ids == []
    assert response.metadata == {}


def test_build_sync_response_preserves_explicit_values() -> None:
    response = build_sync_response(
        status="synced",
        container_id="container-2",
        reason="startup",
        generation=7,
        applied=["a"],
        removed=["b"],
        active_config_ids=["a"],
        metadata={"count": 1},
    )

    assert response.reason == "startup"
    assert response.generation == 7
    assert response.applied == ["a"]
    assert response.removed == ["b"]
    assert response.active_config_ids == ["a"]
    assert response.metadata == {"count": 1}


@pytest.mark.parametrize(
    ("current_generation", "incoming_generation", "expected"),
    [
        (None, 1, False),
        (1, None, False),
        (5, 5, False),
        (5, 6, False),
        (6, 5, True),
    ],
)
def test_config_sync_coordinator_is_stale_handles_generation_edges(
    current_generation: int | None,
    incoming_generation: int | None,
    expected: bool,
) -> None:
    coordinator = ConfigSyncCoordinator(
        process_state=RuntimeProcessState(current_generation=current_generation)
    )
    snapshot = RuntimeConfigSnapshot(container_id="container-3", generation=incoming_generation)

    assert coordinator.is_stale(snapshot) is expected


def test_config_sync_coordinator_get_current_generation_returns_state_value() -> None:
    coordinator = ConfigSyncCoordinator(process_state=RuntimeProcessState(current_generation=11))
    assert coordinator.get_current_generation() == 11


def test_config_sync_coordinator_mark_generation_keeps_existing_when_none() -> None:
    state = RuntimeProcessState(current_generation=9)
    coordinator = ConfigSyncCoordinator(process_state=state)

    assert coordinator.mark_generation(None) == 9
    assert state.current_generation == 9


def test_config_sync_coordinator_build_stale_response_marks_metadata() -> None:
    state = RuntimeProcessState(current_generation=15)
    coordinator = ConfigSyncCoordinator(process_state=state)
    snapshot = RuntimeConfigSnapshot(container_id="container-4", generation=14, reason="resync")

    response = coordinator.build_stale_response(
        snapshot=snapshot,
        active_config_ids=["device-1"],
    )

    assert response.status == "stale_ignored"
    assert response.generation == 15
    assert response.active_config_ids == ["device-1"]
    assert response.metadata["stale_generation_ignored"] is True
    assert response.metadata["incoming_generation"] == 14
    assert response.metadata["current_generation"] == 15


@pytest.mark.asyncio
async def test_apply_snapshot_returns_stale_response_without_callbacks() -> None:
    state = RuntimeProcessState(current_generation=10)
    coordinator = ConfigSyncCoordinator(process_state=state)
    snapshot = RuntimeConfigSnapshot(
        container_id="container-5",
        generation=9,
        configs=[RuntimeConfig(id="device-1")],
    )
    applied: list[str] = []
    removed: list[str] = []

    response = await coordinator.apply_snapshot(
        snapshot=snapshot,
        active_config_ids=["device-1"],
        apply_config=lambda config: _append_async(applied, config.id),
        remove_config=lambda config_id: _append_bool_async(removed, config_id, True),
    )

    assert response.status == "stale_ignored"
    assert applied == []
    assert removed == []


@pytest.mark.asyncio
async def test_apply_snapshot_uses_incoming_ids_when_active_callback_is_missing() -> None:
    coordinator = ConfigSyncCoordinator(process_state=RuntimeProcessState())
    snapshot = RuntimeConfigSnapshot(
        container_id="container-6",
        generation=2,
        configs=[RuntimeConfig(id="device-2"), RuntimeConfig(id="device-3")],
    )

    response = await coordinator.apply_snapshot(
        snapshot=snapshot,
        active_config_ids=["device-1"],
        apply_config=lambda config: _noop_async(config),
        remove_config=lambda config_id: _return_async(True),
    )

    assert response.active_config_ids == ["device-2", "device-3"]
    assert response.metadata["applied_count"] == 2
    assert response.metadata["removed_count"] == 1


@pytest.mark.asyncio
async def test_apply_snapshot_only_reports_removed_configs_when_callback_returns_true() -> None:
    coordinator = ConfigSyncCoordinator(process_state=RuntimeProcessState())
    snapshot = RuntimeConfigSnapshot(container_id="container-7", generation=3, configs=[])

    response = await coordinator.apply_snapshot(
        snapshot=snapshot,
        active_config_ids=["device-7"],
        apply_config=lambda config: _noop_async(config),
        remove_config=lambda config_id: _return_async(False),
    )

    assert response.removed == []
    assert response.metadata["removed_count"] == 0


async def _append_async(items: list[str], value: str) -> None:
    items.append(value)


async def _append_bool_async(items: list[str], value: str, result: bool) -> bool:
    items.append(value)
    return result


async def _noop_async(_value) -> None:
    return None


async def _return_async(result: bool) -> bool:
    return result

