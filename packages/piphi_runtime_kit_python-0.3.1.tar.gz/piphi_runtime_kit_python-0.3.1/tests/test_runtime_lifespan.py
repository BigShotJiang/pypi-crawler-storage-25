import pytest

from piphi_runtime_kit_python import RuntimeContext, runtime_lifespan


@pytest.mark.asyncio
async def test_runtime_lifespan_bootstraps_auth_and_cleans_client(monkeypatch) -> None:
    monkeypatch.setenv("PIPHI_CONTAINER_ID", "container-1")
    monkeypatch.setenv("PIPHI_INTEGRATION_INTERNAL_TOKEN", "token-1")
    runtime = RuntimeContext()
    startup_calls: list[tuple[str, str]] = []

    async def on_startup(context, _client) -> None:
        startup_calls.append((context.auth.container_id, context.auth.internal_token))
        assert context.process_state.core_http_client is not None

    async with runtime_lifespan(runtime, on_startup=on_startup):
        assert runtime.auth.container_id == "container-1"
        assert runtime.auth.internal_token == "token-1"
        assert runtime.process_state.core_http_client is not None

    assert startup_calls == [("container-1", "token-1")]
    assert runtime.process_state.core_http_client is None
