from piphi_runtime_kit_python import IntegrationDiscoveryResponse
from piphi_runtime_kit_python.runtime.discovery import (
    build_discovery_response,
    format_discovery_attempt_log,
    normalize_discovery_inputs,
)


def test_normalize_discovery_inputs_trims_and_drops_blank_values() -> None:
    normalized = normalize_discovery_inputs(
        {
            "username": " user@example.com ",
            "password": "   ",
            "host": None,
            "timeout": 10,
        }
    )

    assert normalized == {
        "username": "user@example.com",
        "timeout": 10,
    }


def test_build_discovery_response_returns_typed_model() -> None:
    response = build_discovery_response(
        [
            {"id": "device-1", "host": "10.0.0.2"},
            {"id": "device-2", "host": "10.0.0.3"},
        ]
    )

    assert isinstance(response, IntegrationDiscoveryResponse)
    assert response.devices[0]["id"] == "device-1"
    assert response.devices[1]["host"] == "10.0.0.3"


def test_format_discovery_attempt_log_masks_secret_values() -> None:
    message = format_discovery_attempt_log(
        inputs={
            "username": "user@example.com",
            "password": "super-secret",
        }
    )

    assert "input_keys=['password', 'username']" in message
    assert "uses_secrets=True" in message
    assert "super-secret" not in message
