import datetime as dt

import httpx
import pytest

from piphi_runtime_kit_python import EventSeverity, EventTransport, RuntimeAuthContext, RuntimeProcessState
from piphi_runtime_kit_python.runtime.errors import (
    CoreAuthError,
    CoreServerError,
    CoreTimeoutError,
)
from piphi_runtime_kit_python.runtime.events import (
    DEFAULT_EVENTS_INGEST_PATH,
    EventClient,
    build_core_event_payload,
    build_event_ingest_response,
    build_event_list_response,
    format_event_log,
    normalize_event_payload,
)


def test_normalize_event_payload_returns_existing_model_instance() -> None:
    payload = normalize_event_payload({"event_type": "device.updated"})
    assert normalize_event_payload(payload) is payload


def test_build_event_list_response_copies_event_mappings() -> None:
    events = [{"event_type": "one"}, {"event_type": "two"}]
    response = build_event_list_response(events)
    assert response.events == events
    assert response.events is not events


def test_build_event_ingest_response_supports_custom_status() -> None:
    response = build_event_ingest_response({"event_type": "one"}, status="stored")
    assert response.status == "stored"


def test_format_event_log_uses_unknown_for_missing_source() -> None:
    assert (
        format_event_log({"event_type": "device.updated", "payload": {}})
        == "event_ingested event_type=device.updated source=unknown"
    )


def test_build_core_event_payload_uses_defaults_and_source_fallback() -> None:
    payload = build_core_event_payload(
        event_type="device.updated",
        integration_id="integration-1",
        config_id="config-1",
        container_id="container-1",
        source="runtime-source",
    )

    assert payload.severity == EventSeverity.info
    assert payload.transport == EventTransport.rest
    assert payload.data["source"] == "runtime-source"
    assert isinstance(payload.ts, dt.datetime)
    assert isinstance(payload.received_at, dt.datetime)


def test_build_core_event_payload_preserves_existing_payload_source() -> None:
    payload = build_core_event_payload(
        event_type="device.updated",
        integration_id="integration-2",
        config_id="config-2",
        container_id="container-2",
        payload={"source": "payload-source"},
        source="runtime-source",
    )

    assert payload.data["source"] == "payload-source"


def test_build_core_event_payload_parses_iso_timestamp_string() -> None:
    payload = build_core_event_payload(
        event_type="device.updated",
        integration_id="integration-3",
        config_id="config-3",
        container_id="container-3",
        ts="2026-04-10T00:00:00Z",
    )

    assert payload.ts == dt.datetime(2026, 4, 10, 0, 0, tzinfo=dt.timezone.utc)


def test_event_client_events_ingest_url_is_stable() -> None:
    client = EventClient(process_state=RuntimeProcessState(), core_base_url="http://core.test/")
    assert client.events_ingest_url == "http://core.test/api/v2/events/ingest"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("integration_id", "config_id", "container_id"),
    [
        (None, "config-1", "container-1"),
        ("integration-1", None, "container-1"),
        ("integration-1", "config-1", None),
    ],
)
async def test_send_event_returns_false_when_required_scope_is_missing(
    integration_id: str | None,
    config_id: str | None,
    container_id: str | None,
) -> None:
    auth_context = RuntimeAuthContext(container_id=container_id or "")
    client = EventClient(process_state=RuntimeProcessState())

    sent = await client.send_event(
        event_type="device.updated",
        integration_id=integration_id,
        config_id=config_id,
        auth_context=auth_context,
    )

    assert sent is False


@pytest.mark.asyncio
async def test_send_event_posts_expected_payload() -> None:
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, request=request, json={"accepted": True})

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = EventClient(process_state=process_state, core_base_url="http://core.test")
    auth_context = RuntimeAuthContext(container_id="container-4", internal_token="token-4")

    try:
        sent = await client.send_event(
            event_type="device.turned_on",
            integration_id="integration-4",
            config_id="config-4",
            auth_context=auth_context,
            device_id="device-4",
            payload={"host": "10.0.0.4"},
            source="runtime-4",
            severity=EventSeverity.warning,
            topic="events/device",
            event_id="event-4",
            ts="2026-04-10T00:00:00Z",
        )
    finally:
        await process_state.core_http_client.aclose()

    assert sent is True
    assert requests[0].headers["X-Container-Id"] == "container-4"
    body = requests[0].read().decode()
    assert '"event_id":"event-4"' in body
    assert '"type":"device.turned_on"' in body
    assert '"severity":"warning"' in body
    assert '"topic":"events/device"' in body


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("exception_factory", "expected_type"),
    [
        (
            lambda request: httpx.HTTPStatusError(
                "bad auth",
                request=request,
                response=httpx.Response(401, request=request),
            ),
            CoreAuthError,
        ),
        (
            lambda request: httpx.HTTPStatusError(
                "server error",
                request=request,
                response=httpx.Response(500, request=request),
            ),
            CoreServerError,
        ),
        (
            lambda request: httpx.ReadTimeout("slow", request=request),
            CoreTimeoutError,
        ),
    ],
)
async def test_send_event_classifies_delivery_failures(exception_factory, expected_type) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        exc = exception_factory(request)
        if isinstance(exc, httpx.HTTPStatusError):
            return exc.response
        raise exc

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = EventClient(process_state=process_state)
    auth_context = RuntimeAuthContext(container_id="container-5", internal_token="token-5")

    try:
        with pytest.raises(expected_type):
            await client.send_event(
                event_type="device.updated",
                integration_id="integration-5",
                config_id="config-5",
                auth_context=auth_context,
            )
    finally:
        await process_state.core_http_client.aclose()


def test_events_module_default_path_is_stable() -> None:
    assert DEFAULT_EVENTS_INGEST_PATH == "/api/v2/events/ingest"

