import pytest

from piphi_runtime_kit_python import RuntimeConfig
from piphi_runtime_kit_python.runtime.configuration import (
    DEFAULT_CONFIG_SECRET_KEYS,
    build_config_apply_response,
    build_config_remove_response,
    format_config_apply_log,
    redact_config_secrets,
    validate_typed_config,
    validate_typed_configs,
)


class AdvancedDemoConfig(RuntimeConfig):
    host: str
    username: str | None = None
    password: str | None = None


def test_redact_config_secrets_handles_none_payload() -> None:
    assert redact_config_secrets(None) == {}


def test_redact_config_secrets_redacts_nested_mappings_and_lists() -> None:
    payload = {
        "id": "device-1",
        "token": "top-secret",
        "nested": {"password": "p4ss", "host": "10.0.0.1"},
        "items": [{"api_key": "abc123"}, {"label": "ok"}],
    }

    redacted = redact_config_secrets(payload)

    assert redacted["token"] == "***"
    assert redacted["nested"]["password"] == "***"
    assert redacted["nested"]["host"] == "10.0.0.1"
    assert redacted["items"][0]["api_key"] == "***"
    assert redacted["items"][1]["label"] == "ok"


def test_redact_config_secrets_keeps_blank_secret_values() -> None:
    payload = {"password": "", "token": None}
    assert redact_config_secrets(payload) == {"password": "", "token": None}


def test_format_config_apply_log_accepts_mapping_payload() -> None:
    message = format_config_apply_log({"id": "device-2", "container_id": "container-1"})
    assert message.startswith("config_apply ")
    assert "config_id=device-2" in message
    assert "container_id=container-1" in message


def test_format_config_apply_log_accepts_custom_action() -> None:
    message = format_config_apply_log({"id": "device-3"}, action="config_remove")
    assert message.startswith("config_remove ")


def test_format_config_apply_log_uses_custom_secret_keys() -> None:
    payload = {"id": "device-4", "private": "secret"}

    message = format_config_apply_log(payload, secret_keys=("private",))

    assert "secret" not in message
    assert "'private': '***'" in message


def test_build_config_apply_response_supports_custom_status_and_metadata() -> None:
    response = build_config_apply_response(
        config_id="device-5",
        container_id="container-5",
        status="updated",
        metadata={"changed": True},
    )

    assert response.status == "updated"
    assert response.container_id == "container-5"
    assert response.metadata == {"changed": True}


def test_build_config_remove_response_supports_custom_status_and_metadata() -> None:
    response = build_config_remove_response(
        config_id="device-6",
        removed=False,
        status="ignored",
        metadata={"reason": "not_found"},
    )

    assert response.status == "ignored"
    assert response.removed is False
    assert response.metadata == {"reason": "not_found"}


def test_validate_typed_config_returns_existing_model_instance() -> None:
    config = AdvancedDemoConfig(id="device-7", host="10.0.0.7")
    assert validate_typed_config(config, AdvancedDemoConfig) is config


def test_validate_typed_configs_validates_many_payloads() -> None:
    payloads = [
        {"id": "device-8", "host": "10.0.0.8"},
        {"id": "device-9", "host": "10.0.0.9", "username": "kelvin"},
    ]

    configs = validate_typed_configs(payloads, AdvancedDemoConfig)

    assert [config.id for config in configs] == ["device-8", "device-9"]
    assert configs[1].username == "kelvin"


def test_default_config_secret_keys_include_expected_values() -> None:
    assert "password" in DEFAULT_CONFIG_SECRET_KEYS
    assert "refresh_token" in DEFAULT_CONFIG_SECRET_KEYS

