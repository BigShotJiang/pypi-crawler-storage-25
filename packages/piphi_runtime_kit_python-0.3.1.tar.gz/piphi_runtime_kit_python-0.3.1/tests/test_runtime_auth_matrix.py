import pytest

from piphi_runtime_kit_python.runtime.auth import (
    DEFAULT_INTERNAL_TOKEN_ENV_NAME,
    RUNTIME_CONTAINER_ID_HEADER_NAME,
    RUNTIME_INTERNAL_TOKEN_HEADER_NAME,
    RuntimeAuthContext,
    build_runtime_auth_headers,
    extract_runtime_auth_headers,
    format_runtime_auth_sync_log,
    mask_token,
)


@pytest.mark.parametrize(
    ("token", "expected"),
    [
        (None, "missing"),
        ("", "missing"),
        ("   ", "missing"),
        ("short", "present"),
        ("1234567890", "present"),
        ("abcdef1234567890", "abcdef...7890"),
    ],
)
def test_mask_token_handles_expected_shapes(token: str | None, expected: str) -> None:
    assert mask_token(token) == expected


@pytest.mark.parametrize(
    ("headers", "container_id", "internal_token"),
    [
        ({}, "", ""),
        ({RUNTIME_CONTAINER_ID_HEADER_NAME: "container-1"}, "container-1", ""),
        ({RUNTIME_INTERNAL_TOKEN_HEADER_NAME: "token-1"}, "", "token-1"),
        (
            {
                RUNTIME_CONTAINER_ID_HEADER_NAME.lower(): "container-2",
                RUNTIME_INTERNAL_TOKEN_HEADER_NAME.lower(): "token-2",
            },
            "container-2",
            "token-2",
        ),
        (
            {
                "x-container-id": "  container-3  ",
                "x-piphi-integration-token": "  token-3  ",
            },
            "container-3",
            "token-3",
        ),
    ],
)
def test_extract_runtime_auth_headers_normalizes_headers(
    headers: dict[str, str],
    container_id: str,
    internal_token: str,
) -> None:
    parsed = extract_runtime_auth_headers(headers)
    assert parsed.container_id == container_id
    assert parsed.internal_token == internal_token


@pytest.mark.parametrize(
    ("container_id", "internal_token", "expected"),
    [
        ("container-1", "token-1", {
            RUNTIME_CONTAINER_ID_HEADER_NAME: "container-1",
            RUNTIME_INTERNAL_TOKEN_HEADER_NAME: "token-1",
        }),
        ("container-2", None, {RUNTIME_CONTAINER_ID_HEADER_NAME: "container-2"}),
        ("container-3", "", {RUNTIME_CONTAINER_ID_HEADER_NAME: "container-3"}),
    ],
)
def test_build_runtime_auth_headers_handles_optional_token(
    container_id: str,
    internal_token: str | None,
    expected: dict[str, str],
) -> None:
    assert build_runtime_auth_headers(
        container_id=container_id,
        internal_token=internal_token,
    ) == expected


def test_runtime_auth_context_update_ignores_blank_values() -> None:
    context = RuntimeAuthContext(container_id="container-1", internal_token="token-1")

    context.update(container_id="   ", internal_token="  ")

    assert context.container_id == "container-1"
    assert context.internal_token == "token-1"


def test_runtime_auth_context_sync_from_headers_prefers_header_container_over_payload() -> None:
    context = RuntimeAuthContext()

    parsed = context.sync_from_headers(
        {
            RUNTIME_CONTAINER_ID_HEADER_NAME: "container-1",
            RUNTIME_INTERNAL_TOKEN_HEADER_NAME: "token-1",
        },
        payload_container_id="payload-container",
    )

    assert parsed.container_id == "container-1"
    assert context.container_id == "container-1"
    assert context.internal_token == "token-1"


def test_runtime_auth_context_sync_from_headers_uses_payload_fallback() -> None:
    context = RuntimeAuthContext()

    parsed = context.sync_from_headers(
        {RUNTIME_INTERNAL_TOKEN_HEADER_NAME: "token-2"},
        payload_container_id="payload-container-2",
    )

    assert parsed.container_id == ""
    assert context.container_id == "payload-container-2"
    assert context.internal_token == "token-2"


def test_runtime_auth_context_resolve_supports_custom_env_name(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CUSTOM_RUNTIME_TOKEN", "env-token")
    context = RuntimeAuthContext(container_id="container-3")

    container_id, token = context.resolve(token_env_name="CUSTOM_RUNTIME_TOKEN")

    assert container_id == "container-3"
    assert token == "env-token"


def test_runtime_auth_context_resolve_prefers_explicit_context_token_over_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(DEFAULT_INTERNAL_TOKEN_ENV_NAME, "env-token")
    context = RuntimeAuthContext(container_id="container-4", internal_token="context-token")

    container_id, token = context.resolve()

    assert container_id == "container-4"
    assert token == "context-token"


def test_format_runtime_auth_sync_log_handles_missing_values() -> None:
    message = format_runtime_auth_sync_log(
        extract_runtime_auth_headers({}),
        payload_container_id=None,
    )

    assert message == (
        "runtime_internal_auth "
        "header_container_id=missing "
        "payload_container_id=missing "
        "token=missing"
    )


def test_format_runtime_auth_sync_log_masks_present_token() -> None:
    parsed = extract_runtime_auth_headers(
        {
            RUNTIME_CONTAINER_ID_HEADER_NAME: "container-5",
            RUNTIME_INTERNAL_TOKEN_HEADER_NAME: "abcdef1234567890",
        }
    )

    message = format_runtime_auth_sync_log(parsed, payload_container_id="container-6")

    assert "abcdef1234567890" not in message
    assert "token=abcdef...7890" in message

