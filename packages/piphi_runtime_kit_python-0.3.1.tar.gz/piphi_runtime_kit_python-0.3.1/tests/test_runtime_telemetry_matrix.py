import datetime as dt

import httpx
import pytest

from piphi_runtime_kit_python import RuntimeAuthContext, RuntimeProcessState
from piphi_runtime_kit_python.runtime.errors import (
    CoreAuthError,
    CoreServerError,
    CoreUnexpectedResponseError,
)
from piphi_runtime_kit_python.runtime.telemetry import (
    DEFAULT_CORE_BASE_URL,
    DEFAULT_TELEMETRY_PATH,
    TelemetryClient,
    build_core_auth_headers,
    build_telemetry_payload,
)


def test_build_core_auth_headers_delegates_standard_names() -> None:
    assert build_core_auth_headers(
        container_id="container-1",
        internal_token="token-1",
    ) == {
        "X-Container-Id": "container-1",
        "X-PiPhi-Integration-Token": "token-1",
    }


def test_build_telemetry_payload_uses_default_timestamp_when_missing() -> None:
    before = dt.datetime.now(dt.timezone.utc)
    payload = build_telemetry_payload(device_id="device-1", metrics={"voc": 10})
    after = dt.datetime.now(dt.timezone.utc)

    parsed = dt.datetime.fromisoformat(payload.timestamp)

    assert payload.units == {}
    assert before <= parsed <= after


def test_telemetry_client_telemetry_url_joins_base_and_path() -> None:
    client = TelemetryClient(process_state=RuntimeProcessState(), core_base_url="http://core.test/")
    assert client.telemetry_url == "http://core.test/api/v2/integrations/telemetry"


@pytest.mark.asyncio
async def test_borrow_http_client_uses_shared_process_client() -> None:
    shared_client = httpx.AsyncClient()
    process_state = RuntimeProcessState(core_http_client=shared_client)
    client = TelemetryClient(process_state=process_state)

    try:
        async with client.borrow_http_client() as borrowed:
            assert borrowed is shared_client
    finally:
        await shared_client.aclose()


@pytest.mark.asyncio
async def test_send_metrics_returns_early_without_container_scope() -> None:
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"ok": True})

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = TelemetryClient(process_state=process_state)

    try:
        await client.send_metrics(
            device_id="device-2",
            metrics={"voc": 11},
            auth_context=RuntimeAuthContext(),
        )
    finally:
        await process_state.core_http_client.aclose()

    assert requests == []


@pytest.mark.asyncio
async def test_send_metrics_posts_expected_headers_and_payload() -> None:
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"accepted": True})

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = TelemetryClient(process_state=process_state, core_base_url="http://core.test")
    auth_context = RuntimeAuthContext(container_id="container-3", internal_token="token-3")

    try:
        await client.send_metrics(
            device_id="device-3",
            metrics={"is_on": True},
            units={"is_on": "bool"},
            timestamp="2026-04-10T00:00:00Z",
            auth_context=auth_context,
        )
    finally:
        await process_state.core_http_client.aclose()

    assert len(requests) == 1
    assert str(requests[0].url) == "http://core.test/api/v2/integrations/telemetry"
    assert requests[0].headers["X-Container-Id"] == "container-3"
    assert requests[0].headers["X-PiPhi-Integration-Token"] == "token-3"
    assert requests[0].read() == (
        b'{"device_id":"device-3","metrics":{"is_on":true},'
        b'"timestamp":"2026-04-10T00:00:00Z","units":{"is_on":"bool"}}'
    )


@pytest.mark.asyncio
async def test_send_metrics_uses_explicit_container_id_override() -> None:
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"accepted": True})

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = TelemetryClient(process_state=process_state)
    auth_context = RuntimeAuthContext(container_id="container-auth", internal_token="token-4")

    try:
        await client.send_metrics(
            device_id="device-4",
            metrics={"voc": 4},
            container_id="container-explicit",
            auth_context=auth_context,
        )
    finally:
        await process_state.core_http_client.aclose()

    assert requests[0].headers["X-Container-Id"] == "container-explicit"


@pytest.mark.asyncio
async def test_send_metrics_uses_env_token_when_context_token_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"accepted": True})

    monkeypatch.setenv("PIPHI_INTEGRATION_INTERNAL_TOKEN", "env-token")
    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = TelemetryClient(process_state=process_state)
    auth_context = RuntimeAuthContext(container_id="container-5")

    try:
        await client.send_metrics(
            device_id="device-5",
            metrics={"voc": 5},
            auth_context=auth_context,
        )
    finally:
        await process_state.core_http_client.aclose()

    assert requests[0].headers["X-PiPhi-Integration-Token"] == "env-token"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("status_code", "expected_type"),
    [
        (401, CoreAuthError),
        (500, CoreServerError),
        (422, CoreUnexpectedResponseError),
    ],
)
async def test_send_metrics_classifies_non_success_responses(
    status_code: int,
    expected_type: type[Exception],
) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code, request=request, json={"detail": "bad"})

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = TelemetryClient(process_state=process_state)
    auth_context = RuntimeAuthContext(container_id="container-6", internal_token="token-6")

    try:
        with pytest.raises(expected_type):
            await client.send_metrics(
                device_id="device-6",
                metrics={"voc": 6},
                auth_context=auth_context,
            )
    finally:
        await process_state.core_http_client.aclose()


def test_telemetry_module_defaults_are_stable() -> None:
    assert DEFAULT_CORE_BASE_URL == "http://127.0.0.1:31419"
    assert DEFAULT_TELEMETRY_PATH == "/api/v2/integrations/telemetry"

