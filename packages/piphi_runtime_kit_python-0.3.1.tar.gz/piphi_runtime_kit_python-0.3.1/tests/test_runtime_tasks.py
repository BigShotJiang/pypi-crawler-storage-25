import asyncio

import pytest

from piphi_runtime_kit_python import RuntimeProcessState, create_tracked_task, shutdown_background_tasks


@pytest.mark.asyncio
async def test_create_tracked_task_registers_and_cleans_up() -> None:
    state = RuntimeProcessState()
    release = asyncio.Event()

    async def worker() -> None:
        await release.wait()

    task = create_tracked_task(worker(), process_state=state)

    assert task in state.background_tasks

    release.set()
    await task

    await asyncio.sleep(0)
    assert task not in state.background_tasks


@pytest.mark.asyncio
async def test_shutdown_background_tasks_cancels_pending_tasks() -> None:
    state = RuntimeProcessState()

    async def worker() -> None:
        while True:
            await asyncio.sleep(0.1)

    task = create_tracked_task(worker(), process_state=state)

    await shutdown_background_tasks(state)

    assert task.cancelled()
