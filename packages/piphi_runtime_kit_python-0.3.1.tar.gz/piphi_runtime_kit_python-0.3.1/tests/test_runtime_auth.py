from piphi_runtime_kit_python import (
    RUNTIME_CONTAINER_ID_HEADER_NAME,
    RUNTIME_INTERNAL_TOKEN_HEADER_NAME,
    RuntimeAuthContext,
    build_runtime_auth_headers,
    extract_runtime_auth_headers,
    format_runtime_auth_sync_log,
)


def test_runtime_auth_context_prefers_explicit_values(monkeypatch) -> None:
    monkeypatch.setenv("PIPHI_INTEGRATION_INTERNAL_TOKEN", "env-token")

    context = RuntimeAuthContext()
    context.update(container_id="container-1", internal_token="token-1")

    resolved_container_id, resolved_token = context.resolve(container_id="container-2")

    assert resolved_container_id == "container-2"
    assert resolved_token == "token-1"


def test_runtime_auth_context_falls_back_to_environment(monkeypatch) -> None:
    monkeypatch.setenv("PIPHI_INTEGRATION_INTERNAL_TOKEN", "env-token")

    context = RuntimeAuthContext()
    context.update(container_id="container-1")

    resolved_container_id, resolved_token = context.resolve()

    assert resolved_container_id == "container-1"
    assert resolved_token == "env-token"


def test_extract_runtime_auth_headers_is_case_insensitive() -> None:
    parsed = extract_runtime_auth_headers(
        {
            "x-container-id": "container-1",
            "x-piphi-integration-token": "token-1",
        }
    )

    assert parsed.container_id == "container-1"
    assert parsed.internal_token == "token-1"


def test_runtime_auth_context_syncs_from_headers() -> None:
    context = RuntimeAuthContext()

    parsed = context.sync_from_headers(
        {
            RUNTIME_CONTAINER_ID_HEADER_NAME: "container-1",
            RUNTIME_INTERNAL_TOKEN_HEADER_NAME: "token-1",
        }
    )

    assert parsed.container_id == "container-1"
    assert parsed.internal_token == "token-1"
    assert context.container_id == "container-1"
    assert context.internal_token == "token-1"


def test_build_runtime_auth_headers_returns_expected_names() -> None:
    headers = build_runtime_auth_headers(
        container_id="container-1",
        internal_token="token-1",
    )

    assert headers == {
        RUNTIME_CONTAINER_ID_HEADER_NAME: "container-1",
        RUNTIME_INTERNAL_TOKEN_HEADER_NAME: "token-1",
    }


def test_format_runtime_auth_sync_log_masks_token() -> None:
    parsed = extract_runtime_auth_headers(
        {
            RUNTIME_CONTAINER_ID_HEADER_NAME: "container-1",
            RUNTIME_INTERNAL_TOKEN_HEADER_NAME: "very-secret-token",
        }
    )

    message = format_runtime_auth_sync_log(
        parsed,
        payload_container_id="container-2",
    )

    assert "header_container_id=container-1" in message
    assert "payload_container_id=container-2" in message
    assert "very-secret-token" not in message
    assert "token=very-s...oken" in message
