import httpx
import pytest

from piphi_runtime_kit_python.runtime.errors import (
    CoreAuthError,
    CoreDeliveryError,
    CoreRouteNotFoundError,
    CoreServerError,
    CoreTimeoutError,
    CoreUnavailableError,
    CoreUnexpectedResponseError,
    classify_core_delivery_error,
)


def test_core_delivery_error_string_includes_optional_fields() -> None:
    error = CoreDeliveryError(
        operation="telemetry_delivery",
        url="http://core.test/telemetry",
        message="boom",
        retryable=True,
        status_code=500,
        timeout_seconds=8.0,
    )

    assert str(error) == (
        "boom operation=telemetry_delivery "
        "url=http://core.test/telemetry "
        "status_code=500 timeout_seconds=8.0 retryable=True"
    )


def test_core_delivery_error_string_omits_optional_fields_when_absent() -> None:
    error = CoreDeliveryError(
        operation="event_delivery",
        url="http://core.test/events",
        message="boom",
        retryable=False,
    )

    assert str(error) == (
        "boom operation=event_delivery url=http://core.test/events retryable=False"
    )


@pytest.mark.parametrize(
    ("status_code", "expected_type", "retryable"),
    [
        (404, CoreRouteNotFoundError, False),
        (401, CoreAuthError, False),
        (403, CoreAuthError, False),
        (500, CoreServerError, True),
        (503, CoreServerError, True),
        (422, CoreUnexpectedResponseError, False),
    ],
)
def test_classify_core_delivery_error_from_http_status(
    status_code: int,
    expected_type: type[CoreDeliveryError],
    retryable: bool,
) -> None:
    request = httpx.Request("POST", "http://core.test/endpoint")
    response = httpx.Response(status_code, request=request)
    exc = httpx.HTTPStatusError("bad status", request=request, response=response)

    error = classify_core_delivery_error(
        exc=exc,
        operation="telemetry_delivery",
        url="http://core.test/endpoint",
        timeout_seconds=3.0,
    )

    assert isinstance(error, expected_type)
    assert error.status_code == status_code
    assert error.retryable is retryable
    assert error.timeout_seconds == 3.0


def test_classify_core_delivery_error_maps_connect_error() -> None:
    request = httpx.Request("POST", "http://core.test/endpoint")
    exc = httpx.ConnectError("cannot connect", request=request)

    error = classify_core_delivery_error(
        exc=exc,
        operation="telemetry_delivery",
        url="http://core.test/endpoint",
        timeout_seconds=5.0,
    )

    assert isinstance(error, CoreUnavailableError)
    assert error.retryable is True
    assert error.message == "PiPhi Core is unreachable"


def test_classify_core_delivery_error_maps_read_timeout() -> None:
    request = httpx.Request("POST", "http://core.test/endpoint")
    exc = httpx.ReadTimeout("too slow", request=request)

    error = classify_core_delivery_error(
        exc=exc,
        operation="event_delivery",
        url="http://core.test/endpoint",
        timeout_seconds=9.0,
    )

    assert isinstance(error, CoreTimeoutError)
    assert error.retryable is True
    assert error.timeout_seconds == 9.0


def test_classify_core_delivery_error_uses_generic_exception_message() -> None:
    error = classify_core_delivery_error(
        exc=RuntimeError("custom boom"),
        operation="event_delivery",
        url="http://core.test/endpoint",
        timeout_seconds=4.0,
    )

    assert isinstance(error, CoreUnexpectedResponseError)
    assert error.retryable is False
    assert error.message == "custom boom"


def test_classify_core_delivery_error_uses_exception_class_name_when_message_is_blank() -> None:
    class BlankException(Exception):
        def __str__(self) -> str:
            return ""

    error = classify_core_delivery_error(
        exc=BlankException(),
        operation="event_delivery",
        url="http://core.test/endpoint",
        timeout_seconds=4.0,
    )

    assert isinstance(error, CoreUnexpectedResponseError)
    assert error.message == "BlankException"

