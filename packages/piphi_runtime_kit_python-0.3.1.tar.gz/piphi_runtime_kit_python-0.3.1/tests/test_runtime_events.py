import httpx
import pytest

from piphi_runtime_kit_python import (
    CoreEventPayload,
    EventClient,
    IntegrationEventIngestResponse,
    IntegrationEventListResponse,
    IntegrationEventRequest,
    RuntimeAuthContext,
    RuntimeProcessState,
)
from piphi_runtime_kit_python.runtime.events import (
    build_core_event_payload,
    build_event_ingest_response,
    build_event_list_response,
    format_event_log,
    normalize_event_payload,
)


def test_normalize_event_payload_accepts_mapping() -> None:
    event = normalize_event_payload(
        {
            "event_type": "device.updated",
            "source": "kasa",
            "payload": {"device_id": "plug-1"},
        }
    )

    assert isinstance(event, IntegrationEventRequest)
    assert event.event_type == "device.updated"
    assert event.payload["device_id"] == "plug-1"


def test_build_event_list_response_returns_typed_model() -> None:
    response = build_event_list_response(
        [
            {"event_type": "device.updated", "source": "kasa", "payload": {}},
        ]
    )

    assert isinstance(response, IntegrationEventListResponse)
    assert response.events[0]["event_type"] == "device.updated"


def test_build_event_ingest_response_returns_typed_model() -> None:
    response = build_event_ingest_response(
        {"event_type": "device.updated", "source": "kasa", "payload": {}}
    )

    assert isinstance(response, IntegrationEventIngestResponse)
    assert response.status == "accepted"
    assert response.event["source"] == "kasa"


def test_format_event_log_uses_standard_fields() -> None:
    message = format_event_log(
        {
            "event_type": "device.updated",
            "source": "kasa",
            "payload": {},
        }
    )

    assert message == "event_ingested event_type=device.updated source=kasa"


def test_build_core_event_payload_returns_typed_model() -> None:
    payload = build_core_event_payload(
        event_type="device.turned_on",
        integration_id="tp-link-kasa-local-api",
        config_id="plug-1",
        container_id="container-1",
        device_id="plug-1",
        payload={"host": "10.0.0.227"},
        source="tp_link_kasa_runtime",
    )

    assert isinstance(payload, CoreEventPayload)
    assert payload.type == "device.turned_on"
    assert payload.integration_id == "tp-link-kasa-local-api"
    assert payload.data["host"] == "10.0.0.227"
    assert payload.data["source"] == "tp_link_kasa_runtime"


@pytest.mark.asyncio
async def test_event_client_send_event_posts_to_core() -> None:
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"accepted": True})

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = EventClient(process_state=process_state, core_base_url="http://core.test")
    auth_context = RuntimeAuthContext(container_id="container-1", internal_token="secret-token")

    try:
        sent = await client.send_event(
            event_type="device.turned_on",
            integration_id="tp-link-kasa-local-api",
            config_id="plug-1",
            auth_context=auth_context,
            device_id="plug-1",
            payload={"host": "10.0.0.227"},
            source="tp_link_kasa_runtime",
        )
    finally:
        await process_state.core_http_client.aclose()

    assert sent is True
    assert len(requests) == 1
    assert str(requests[0].url) == "http://core.test/api/v2/events/ingest"


@pytest.mark.asyncio
async def test_event_client_send_event_returns_false_without_required_scope() -> None:
    client = EventClient(process_state=RuntimeProcessState())
    auth_context = RuntimeAuthContext()

    sent = await client.send_event(
        event_type="device.turned_on",
        integration_id=None,
        config_id="plug-1",
        auth_context=auth_context,
    )

    assert sent is False
