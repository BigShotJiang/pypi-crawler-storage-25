import httpx
import pytest

from piphi_runtime_kit_python import EventClient, RuntimeAuthContext, RuntimeProcessState, TelemetryClient
from piphi_runtime_kit_python.runtime.dispatch import (
    build_local_event_record,
    dispatch_event_delivery,
    dispatch_telemetry_delivery,
    schedule_event_delivery,
    schedule_telemetry_delivery,
)


def test_build_local_event_record_defaults_empty_payload() -> None:
    record = build_local_event_record(
        event_type="device.updated",
        device={"device_id": "device-1"},
        source="runtime",
        severity="warning",
    )

    assert record["payload"] == {}
    assert record["severity"] == "warning"


@pytest.mark.asyncio
async def test_dispatch_telemetry_delivery_returns_true_on_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    process_state = RuntimeProcessState()
    client = TelemetryClient(process_state=process_state)
    auth_context = RuntimeAuthContext(container_id="container-1", internal_token="token-1")
    called: list[tuple[str, str]] = []

    async def fake_send_metrics(self, **kwargs) -> None:  # noqa: ARG001
        called.append((kwargs["device_id"], kwargs["container_id"]))

    monkeypatch.setattr(TelemetryClient, "send_metrics", fake_send_metrics)

    delivered = await dispatch_telemetry_delivery(
        telemetry_client=client,
        auth_context=auth_context,
        device_id="device-1",
        metrics={"is_on": True},
    )

    assert delivered is True
    assert called == [("device-1", "container-1")]


@pytest.mark.asyncio
async def test_dispatch_telemetry_delivery_calls_error_handler_and_returns_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    process_state = RuntimeProcessState()
    client = TelemetryClient(process_state=process_state)
    auth_context = RuntimeAuthContext(container_id="container-2", internal_token="token-2")
    errors: list[tuple[Exception, dict]] = []

    async def fake_send_metrics(self, **_kwargs) -> None:  # noqa: ARG001
        raise RuntimeError("boom")

    monkeypatch.setattr(TelemetryClient, "send_metrics", fake_send_metrics)

    delivered = await dispatch_telemetry_delivery(
        telemetry_client=client,
        auth_context=auth_context,
        device_id="device-2",
        metrics={"is_on": False},
        on_error=lambda exc, details: errors.append((exc, details)),
    )

    assert delivered is False
    assert str(errors[0][0]) == "boom"
    assert errors[0][1]["device_id"] == "device-2"


@pytest.mark.asyncio
async def test_dispatch_event_delivery_returns_true_on_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    process_state = RuntimeProcessState()
    client = EventClient(process_state=process_state)
    auth_context = RuntimeAuthContext(container_id="container-3", internal_token="token-3")
    called: list[str] = []

    async def fake_send_event(self, **kwargs) -> bool:  # noqa: ARG001
        called.append(kwargs["event_type"])
        return True

    monkeypatch.setattr(EventClient, "send_event", fake_send_event)

    delivered = await dispatch_event_delivery(
        event_client=client,
        auth_context=auth_context,
        event_type="device.updated",
        device={
            "device_id": "device-3",
            "container_id": "container-3",
            "integration_id": "integration-3",
            "config_id": "config-3",
        },
        source="runtime-3",
    )

    assert delivered is True
    assert called == ["device.updated"]


@pytest.mark.asyncio
async def test_dispatch_event_delivery_calls_skip_handler_when_client_returns_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    process_state = RuntimeProcessState()
    client = EventClient(process_state=process_state)
    skipped: list[tuple[str, dict]] = []

    async def fake_send_event(self, **_kwargs) -> bool:  # noqa: ARG001
        return False

    monkeypatch.setattr(EventClient, "send_event", fake_send_event)

    delivered = await dispatch_event_delivery(
        event_client=client,
        auth_context=RuntimeAuthContext(container_id="container-4"),
        event_type="device.updated",
        device={"device_id": "device-4"},
        source="runtime-4",
        on_skipped=lambda reason, details: skipped.append((reason, details)),
    )

    assert delivered is False
    assert skipped[0][0] == "missing_event_scope"


@pytest.mark.asyncio
async def test_dispatch_event_delivery_calls_error_handler_and_returns_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    process_state = RuntimeProcessState()
    client = EventClient(process_state=process_state)
    errors: list[tuple[Exception, dict]] = []

    async def fake_send_event(self, **_kwargs) -> bool:  # noqa: ARG001
        raise RuntimeError("event boom")

    monkeypatch.setattr(EventClient, "send_event", fake_send_event)

    delivered = await dispatch_event_delivery(
        event_client=client,
        auth_context=RuntimeAuthContext(container_id="container-5"),
        event_type="device.updated",
        device={"device_id": "device-5"},
        source="runtime-5",
        on_error=lambda exc, details: errors.append((exc, details)),
    )

    assert delivered is False
    assert str(errors[0][0]) == "event boom"


@pytest.mark.asyncio
async def test_schedule_telemetry_delivery_registers_background_task() -> None:
    process_state = RuntimeProcessState()

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, request=request, json={"ok": True})

    process_state.core_http_client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    client = TelemetryClient(process_state=process_state, core_base_url="http://core.test")

    try:
        task = schedule_telemetry_delivery(
            process_state=process_state,
            telemetry_client=client,
            auth_context=RuntimeAuthContext(container_id="container-6", internal_token="token-6"),
            device_id="device-6",
            metrics={"voc": 6},
        )
        assert task in process_state.background_tasks
        await task
    finally:
        await process_state.core_http_client.aclose()


@pytest.mark.asyncio
async def test_schedule_event_delivery_without_recorder_still_posts_to_core() -> None:
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, request=request, json={"ok": True})

    process_state = RuntimeProcessState(
        core_http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))
    )
    client = EventClient(process_state=process_state, core_base_url="http://core.test")

    try:
        task = schedule_event_delivery(
            process_state=process_state,
            event_client=client,
            auth_context=RuntimeAuthContext(container_id="container-7", internal_token="token-7"),
            event_type="device.updated",
            device={
                "device_id": "device-7",
                "container_id": "container-7",
                "integration_id": "integration-7",
                "config_id": "config-7",
            },
            source="runtime-7",
        )
        await task
    finally:
        await process_state.core_http_client.aclose()

    assert len(requests) == 1
