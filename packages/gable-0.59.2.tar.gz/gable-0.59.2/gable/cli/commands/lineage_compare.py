import click
from click.core import Context as ClickContext

from gable.cli.helpers.lineage_compare import (
    compare_lineage_results,
    render_lineage_compare,
    render_lineage_compare_json,
)
from gable.cli.options import global_options


@click.command(
    add_help_option=False,
    name="compare",
    epilog="""Example:
    gable lineage compare --left ./old-results.json --right ./new-results.json""",
)
@global_options(add_endpoint_options=False)
@click.option(
    "--left",
    "left_file",
    help="The baseline lineage results file.",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
)
@click.option(
    "--right",
    "right_file",
    help="The updated lineage results file.",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json"]),
    default="text",
    show_default=True,
    help="Output format for the compare.",
)
@click.pass_context
def lineage_compare(
    ctx: ClickContext,
    left_file: str,
    right_file: str,
    output_format: str,
):
    """
    Compare two lineage result files and print a diff.
    """
    compare_result = compare_lineage_results(left_file, right_file)
    if output_format == "json":
        click.echo(render_lineage_compare_json(compare_result))
    else:
        click.echo(render_lineage_compare(compare_result))
    if compare_result.has_differences:
        ctx.exit(1)
