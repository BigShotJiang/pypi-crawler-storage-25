import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any, Optional

import click
from pydantic import ValidationError

from gable.common_types import LineageDataFile
from gable.openapi import (
    GableSchemaStruct,
    StaticAnalysisCodeAnchor,
    StaticAnalysisCodeURI,
    StaticAnalysisCompleteness,
    StaticAnalysisDataFlowPath,
    StaticAnalysisDataFlowPathEnds,
    StaticAnalysisTabularLineageFieldMapping,
)

PATH_COMPARE_FIELDS = (
    "ingress.schema",
    "egress.schema",
    "field_mappings",
    "code_anchors",
    "transformation_summary",
    "transformation_summary_detailed",
    "completeness",
)


@dataclass(frozen=True)
class NormalizedLineagePath:
    key: tuple[Any, ...]
    label: str
    comparison_data: dict[str, Any]
    sort_key: str


@dataclass(frozen=True)
class ChangedLineagePath:
    label: str
    changed_fields: list[str]
    left: NormalizedLineagePath
    right: NormalizedLineagePath


@dataclass(frozen=True)
class LineageCompareResult:
    left_file: str
    right_file: str
    added: list[NormalizedLineagePath]
    removed: list[NormalizedLineagePath]
    changed: list[ChangedLineagePath]
    unchanged_count: int

    @property
    def has_differences(self) -> bool:
        return bool(self.added or self.removed or self.changed)


def load_lineage_results(results_file: str) -> LineageDataFile:
    try:
        with open(results_file, "r", encoding="utf-8") as file_handle:
            results = json.load(file_handle)
    except OSError as exc:
        raise click.ClickException(
            f"Error reading results file '{results_file}': {exc}"
        ) from exc
    except json.JSONDecodeError as exc:
        raise click.ClickException(
            f"Invalid JSON in results file '{results_file}': {exc}"
        ) from exc

    try:
        return LineageDataFile.model_validate(results)
    except ValidationError as exc:
        raise click.ClickException(
            f"Invalid results file '{results_file}': {exc}"
        ) from exc


def compare_lineage_results(left_file: str, right_file: str) -> LineageCompareResult:
    left_results = load_lineage_results(left_file)
    right_results = load_lineage_results(right_file)

    left_records = _bucketize_paths(left_results.paths)
    right_records = _bucketize_paths(right_results.paths)

    added: list[NormalizedLineagePath] = []
    removed: list[NormalizedLineagePath] = []
    changed: list[ChangedLineagePath] = []
    unchanged_count = 0

    for key in sorted(set(left_records) | set(right_records), key=_sort_bucket_key):
        left_bucket = sorted(left_records.get(key, []), key=_sort_path_record)
        right_bucket = sorted(right_records.get(key, []), key=_sort_path_record)

        overlap = min(len(left_bucket), len(right_bucket))
        for idx in range(overlap):
            left_record = left_bucket[idx]
            right_record = right_bucket[idx]
            changed_fields = _get_changed_fields(
                left_record.comparison_data, right_record.comparison_data
            )
            if changed_fields:
                changed.append(
                    ChangedLineagePath(
                        label=left_record.label,
                        changed_fields=changed_fields,
                        left=left_record,
                        right=right_record,
                    )
                )
            else:
                unchanged_count += 1

        removed.extend(left_bucket[overlap:])
        added.extend(right_bucket[overlap:])

    return LineageCompareResult(
        left_file=left_file,
        right_file=right_file,
        added=sorted(added, key=_sort_path_record),
        removed=sorted(removed, key=_sort_path_record),
        changed=sorted(changed, key=lambda item: (item.label, item.left.sort_key)),
        unchanged_count=unchanged_count,
    )


def render_lineage_compare(compare_result: LineageCompareResult) -> str:
    lines = [
        "Lineage differences:",
        f"left: {compare_result.left_file}",
        f"right: {compare_result.right_file}",
        "",
        f"Added paths: {len(compare_result.added)}",
        f"Removed paths: {len(compare_result.removed)}",
        f"Changed paths: {len(compare_result.changed)}",
        f"Unchanged paths: {compare_result.unchanged_count}",
    ]

    lines.extend(
        _render_added_or_removed_section("Added paths", "+", compare_result.added)
    )
    lines.extend(
        _render_added_or_removed_section("Removed paths", "-", compare_result.removed)
    )
    lines.extend(_render_changed_section(compare_result.changed))

    return "\n".join(lines)


def render_lineage_compare_json(compare_result: LineageCompareResult) -> str:
    return json.dumps(
        lineage_compare_result_to_dict(compare_result), indent=2, sort_keys=True
    )


def lineage_compare_result_to_dict(
    compare_result: LineageCompareResult,
) -> dict[str, Any]:
    return {
        "left_file": compare_result.left_file,
        "right_file": compare_result.right_file,
        "summary": {
            "added_paths": len(compare_result.added),
            "removed_paths": len(compare_result.removed),
            "changed_paths": len(compare_result.changed),
            "unchanged_paths": compare_result.unchanged_count,
            "has_differences": compare_result.has_differences,
        },
        "added": [_path_to_summary_dict(path) for path in compare_result.added],
        "removed": [_path_to_summary_dict(path) for path in compare_result.removed],
        "changed": [
            {
                "label": changed_path.label,
                "changed_fields": changed_path.changed_fields,
                "left": _path_to_summary_dict(changed_path.left),
                "right": _path_to_summary_dict(changed_path.right),
                "field_diffs": {
                    field_name: {
                        "left": changed_path.left.comparison_data[field_name],
                        "right": changed_path.right.comparison_data[field_name],
                    }
                    for field_name in changed_path.changed_fields
                },
            }
            for changed_path in compare_result.changed
        ],
    }


def _render_added_or_removed_section(
    title: str,
    prefix: str,
    paths: list[NormalizedLineagePath],
) -> list[str]:
    lines = ["", title]
    if not paths:
        lines.append("  (none)")
        return lines

    for path in paths:
        lines.append(f"{prefix} {path.label}")
        lines.extend(_summarize_path(path))

    return lines


def _render_changed_section(changed_paths: list[ChangedLineagePath]) -> list[str]:
    lines = ["", "Changed paths"]
    if not changed_paths:
        lines.append("  (none)")
        return lines

    for changed_path in changed_paths:
        lines.append(f"~ {changed_path.label}")
        for field_name in changed_path.changed_fields:
            lines.extend(
                _render_changed_field_summary(
                    field_name,
                    changed_path.left.comparison_data[field_name],
                    changed_path.right.comparison_data[field_name],
                )
            )

    return lines


def _format_json(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True)


def _render_changed_field_summary(
    field_name: str, left_value: Any, right_value: Any
) -> list[str]:
    if field_name in ("ingress.schema", "egress.schema"):
        return _render_schema_diff(field_name, left_value, right_value)
    if field_name == "field_mappings":
        return _render_field_mapping_diff(left_value, right_value)
    if field_name == "code_anchors":
        return _render_code_anchor_diff(left_value, right_value)
    if field_name == "completeness":
        return _render_completeness_diff(left_value, right_value)
    if field_name in ("transformation_summary", "transformation_summary_detailed"):
        return _render_text_diff(field_name, left_value, right_value)

    return [
        f"  {field_name}:",
        f"    - {_truncate_text(_format_json(left_value), 160)}",
        f"    + {_truncate_text(_format_json(right_value), 160)}",
    ]


def _render_schema_diff(
    field_name: str,
    left_schema: dict[str, Any],
    right_schema: dict[str, Any],
) -> list[str]:
    left_name = _summarize_schema(left_schema)
    right_name = _summarize_schema(right_schema)
    lines = [f"  {field_name}: {left_name} -> {right_name}"]

    left_fields = [field["name"] for field in left_schema.get("fields") or []]
    right_fields = [field["name"] for field in right_schema.get("fields") or []]
    added_fields, removed_fields = _counter_diff(
        Counter(left_fields), Counter(right_fields)
    )

    if added_fields:
        lines.append(f"    + fields: {', '.join(added_fields)}")
    if removed_fields:
        lines.append(f"    - fields: {', '.join(removed_fields)}")
    if not added_fields and not removed_fields and left_schema != right_schema:
        lines.append("    schema details changed")

    return lines


def _render_field_mapping_diff(
    left_mappings: list[dict[str, Any]],
    right_mappings: list[dict[str, Any]],
) -> list[str]:
    lines = [
        "  field_mappings: "
        f"{len(left_mappings)} mapping(s) -> {len(right_mappings)} mapping(s)"
    ]

    left_pairs = Counter(_mapping_label(mapping) for mapping in left_mappings)
    right_pairs = Counter(_mapping_label(mapping) for mapping in right_mappings)
    added_pairs, removed_pairs = _counter_diff(left_pairs, right_pairs)

    if added_pairs:
        lines.append(f"    + mappings: {', '.join(added_pairs)}")
    if removed_pairs:
        lines.append(f"    - mappings: {', '.join(removed_pairs)}")

    if not added_pairs and not removed_pairs and left_mappings != right_mappings:
        lines.append("    mapping details changed")

    return lines


def _render_code_anchor_diff(
    left_anchors: list[dict[str, Any]],
    right_anchors: list[dict[str, Any]],
) -> list[str]:
    lines = [
        f"  code_anchors: {len(left_anchors)} anchor(s) -> {len(right_anchors)} anchor(s)"
    ]

    left_locations = Counter(_anchor_label(anchor) for anchor in left_anchors)
    right_locations = Counter(_anchor_label(anchor) for anchor in right_anchors)
    added_locations, removed_locations = _counter_diff(left_locations, right_locations)

    if added_locations:
        lines.append(f"    + anchors: {', '.join(added_locations)}")
    if removed_locations:
        lines.append(f"    - anchors: {', '.join(removed_locations)}")
    if not added_locations and not removed_locations and left_anchors != right_anchors:
        lines.append("    anchor details changed")

    return lines


def _render_completeness_diff(
    left_completeness: dict[str, Any],
    right_completeness: dict[str, Any],
) -> list[str]:
    lines = ["  completeness:"]
    for key in left_completeness.keys() | right_completeness.keys():
        left_value = left_completeness.get(key)
        right_value = right_completeness.get(key)
        if left_value != right_value:
            lines.append(f"    {key}: {left_value} -> {right_value}")
    return lines


def _render_text_diff(field_name: str, left_value: str, right_value: str) -> list[str]:
    return [
        f"  {field_name}:",
        f"    - {_truncate_text(left_value or '', 160)}",
        f"    + {_truncate_text(right_value or '', 160)}",
    ]


def _summarize_path(path: NormalizedLineagePath) -> list[str]:
    summary = _path_summary(path)
    lines = [
        f"  ingress schema: {summary['ingress_schema']}",
        f"  egress schema: {summary['egress_schema']}",
    ]

    if summary["field_mappings_count"] > 0:
        lines.append(f"  field mappings: {summary['field_mappings_count']} mapping(s)")
    if summary["code_anchors_count"] > 0:
        lines.append(f"  code anchors: {summary['code_anchors_count']} anchor(s)")
    if summary["transformation_summary"]:
        lines.append(f"  summary: {summary['transformation_summary']}")
    if summary["completeness"]:
        lines.append(f"  completeness: {summary['completeness']}")

    return lines


def _path_to_summary_dict(path: NormalizedLineagePath) -> dict[str, Any]:
    return {
        "label": path.label,
        "summary": _path_summary(path),
    }


def _path_summary(path: NormalizedLineagePath) -> dict[str, Any]:
    ingress_schema = path.comparison_data["ingress.schema"]
    egress_schema = path.comparison_data["egress.schema"]
    field_mappings = path.comparison_data["field_mappings"]
    code_anchors = path.comparison_data["code_anchors"]
    transformation_summary = path.comparison_data["transformation_summary"]
    completeness = path.comparison_data["completeness"]

    return {
        "ingress_schema": _summarize_schema(ingress_schema),
        "egress_schema": _summarize_schema(egress_schema),
        "field_mappings_count": len(field_mappings),
        "code_anchors_count": len(code_anchors),
        "transformation_summary": (
            _truncate_text(transformation_summary) if transformation_summary else None
        ),
        "completeness": (
            _summarize_completeness(completeness) if completeness else None
        ),
    }


def _summarize_schema(schema: dict[str, Any]) -> str:
    schema_name = schema.get("name") or schema.get("type") or "unknown"
    fields = schema.get("fields") or []
    return f"{schema_name} ({len(fields)} field(s))"


def _summarize_completeness(completeness: dict[str, Any]) -> str:
    ordered_items = [f"{key}={value}" for key, value in completeness.items()]
    return ", ".join(ordered_items)


def _truncate_text(value: str, max_length: int = 120) -> str:
    single_line = " ".join(value.split())
    if len(single_line) <= max_length:
        return single_line
    return f"{single_line[: max_length - 3]}..."


def _mapping_label(mapping: dict[str, Any]) -> str:
    return f"{mapping['ingress_field']} -> {mapping['egress_field']}"


def _anchor_label(anchor: dict[str, Any]) -> str:
    code_uri = anchor.get("code_uri")
    if not code_uri:
        return "unknown"
    return _format_code_uri_dict(code_uri)


def _format_code_uri_dict(code_uri: dict[str, Any]) -> str:
    location = code_uri["file"]

    line_start = code_uri.get("line_start")
    line_end = code_uri.get("line_end")
    if line_start is not None and line_start > 0:
        line_range = str(line_start)
        if line_end is not None and line_end > 0 and line_end != line_start:
            line_range = f"{line_range}-{line_end}"
        location = f"{location}:{line_range}"

    column_start = code_uri.get("column_start")
    column_end = code_uri.get("column_end")
    if column_start is not None and column_start >= 0:
        column_range = str(column_start)
        if column_end is not None and column_end >= 0 and column_end != column_start:
            column_range = f"{column_range}-{column_end}"
        location = f"{location}:{column_range}"

    return location


def _counter_diff(
    left_counter: Counter[str], right_counter: Counter[str]
) -> tuple[list[str], list[str]]:
    added = sorted((right_counter - left_counter).elements())
    removed = sorted((left_counter - right_counter).elements())
    return (_limit_list(added), _limit_list(removed))


def _limit_list(items: list[str], max_items: int = 8) -> list[str]:
    if len(items) <= max_items:
        return items
    remaining = len(items) - max_items
    return items[:max_items] + [f"... and {remaining} more"]


def _bucketize_paths(
    paths: list[StaticAnalysisDataFlowPath],
) -> dict[tuple[Any, ...], list[NormalizedLineagePath]]:
    buckets: dict[tuple[Any, ...], list[NormalizedLineagePath]] = defaultdict(list)
    for path in paths:
        normalized_path = _normalize_path(path)
        buckets[normalized_path.key].append(normalized_path)
    return buckets


def _normalize_path(path: StaticAnalysisDataFlowPath) -> NormalizedLineagePath:
    key = (
        path.ingress.signature_name,
        _code_uri_identity(
            None
            if path.ingress.code_anchor is None
            else path.ingress.code_anchor.code_uri
        ),
        path.egress.signature_name,
        _code_uri_identity(
            None
            if path.egress.code_anchor is None
            else path.egress.code_anchor.code_uri
        ),
    )
    comparison_data = {
        "ingress.schema": _normalize_schema(path.ingress.schema_),
        "egress.schema": _normalize_schema(path.egress.schema_),
        "field_mappings": _normalize_field_mappings(path.field_mappings),
        "code_anchors": _normalize_code_anchors(path.code_anchors),
        "transformation_summary": path.transformation_summary,
        "transformation_summary_detailed": path.transformation_summary_detailed,
        "completeness": _normalize_completeness(path.completeness),
    }
    sort_key = _format_json(comparison_data)
    return NormalizedLineagePath(
        key=key,
        label=_format_path_label(path.ingress, path.egress),
        comparison_data=comparison_data,
        sort_key=sort_key,
    )


def _normalize_schema(schema: GableSchemaStruct) -> dict[str, Any]:
    return schema.model_dump(by_alias=True, exclude_none=True)


def _normalize_field_mappings(
    field_mappings: Optional[list[StaticAnalysisTabularLineageFieldMapping]],
) -> list[dict[str, Any]]:
    if not field_mappings:
        return []

    normalized = [
        {
            "ingress_field": mapping.ingress_field,
            "egress_field": mapping.egress_field,
            "notes": mapping.notes,
            "field_data_flow_path": _normalize_code_anchors(
                mapping.field_data_flow_path
            ),
        }
        for mapping in field_mappings
    ]
    return sorted(normalized, key=_format_json)


def _normalize_code_anchors(
    code_anchors: Optional[list[StaticAnalysisCodeAnchor]],
) -> list[dict[str, Any]]:
    if not code_anchors:
        return []
    return [_normalize_code_anchor(code_anchor) for code_anchor in code_anchors]


def _normalize_code_anchor(code_anchor: StaticAnalysisCodeAnchor) -> dict[str, Any]:
    return {"code_uri": _normalize_code_uri(code_anchor.code_uri)}


def _normalize_code_uri(
    code_uri: Optional[StaticAnalysisCodeURI],
) -> Optional[dict[str, Any]]:
    if code_uri is None:
        return None
    return {
        "file": code_uri.file,
        "line_start": code_uri.line_start,
        "line_end": code_uri.line_end,
        "column_start": code_uri.column_start,
        "column_end": code_uri.column_end,
    }


def _code_uri_identity(
    code_uri: Optional[StaticAnalysisCodeURI],
) -> Optional[tuple[Any, ...]]:
    if code_uri is None:
        return None
    return (
        code_uri.file,
        code_uri.line_start,
        code_uri.line_end,
        code_uri.column_start,
        code_uri.column_end,
    )


def _normalize_completeness(
    completeness: Optional[StaticAnalysisCompleteness],
) -> Optional[dict[str, Any]]:
    if completeness is None:
        return None
    return completeness.model_dump(by_alias=True, exclude_none=True)


def _format_path_label(
    ingress: StaticAnalysisDataFlowPathEnds,
    egress: StaticAnalysisDataFlowPathEnds,
) -> str:
    return f"{_format_path_end_label(ingress)} -> {_format_path_end_label(egress)}"


def _format_path_end_label(path_end: StaticAnalysisDataFlowPathEnds) -> str:
    location = _format_code_uri(
        None if path_end.code_anchor is None else path_end.code_anchor.code_uri
    )
    if location is None:
        return path_end.signature_name
    return f"{path_end.signature_name} ({location})"


def _format_code_uri(code_uri: Optional[StaticAnalysisCodeURI]) -> Optional[str]:
    if code_uri is None:
        return None

    location = code_uri.file

    if code_uri.line_start and code_uri.line_start > 0:
        line_range = str(code_uri.line_start)
        if (
            code_uri.line_end
            and code_uri.line_end > 0
            and code_uri.line_end != code_uri.line_start
        ):
            line_range = f"{line_range}-{code_uri.line_end}"
        location = f"{location}:{line_range}"

    if code_uri.column_start is not None and code_uri.column_start >= 0:
        column_range = str(code_uri.column_start)
        if (
            code_uri.column_end is not None
            and code_uri.column_end >= 0
            and code_uri.column_end != code_uri.column_start
        ):
            column_range = f"{column_range}-{code_uri.column_end}"
        location = f"{location}:{column_range}"

    return location


def _get_changed_fields(
    left_data: dict[str, Any], right_data: dict[str, Any]
) -> list[str]:
    return [
        field_name
        for field_name in PATH_COMPARE_FIELDS
        if left_data[field_name] != right_data[field_name]
    ]


def _sort_path_record(path: NormalizedLineagePath) -> tuple[str, str]:
    return (path.label, path.sort_key)


def _sort_bucket_key(bucket_key: tuple[Any, ...]) -> str:
    return _format_json(bucket_key)
