"""capsule bootstrap — scaffold a new Capsule project."""

from __future__ import annotations

import platform
import re
import shutil
import subprocess
from pathlib import Path

import click
from rich.console import Console
from rich.prompt import Prompt

from .. import terminal

_console = Console()

BAML_VERSION = "0.220.0"

# ---------------------------------------------------------------------------
# Template content
# ---------------------------------------------------------------------------

_CHATBOT_APP = """\
import cpsl

from baml_client import b

app = cpsl.App(
    name="__NAME__",
    image=cpsl.Image(python_packages=["baml-py==__BAML_VERSION__", "pydantic>=2.13.2"]),
    channels=[cpsl.Chat()],
    secrets=["ANTHROPIC_API_KEY"],
)

SYSTEM_PROMPT = "You are a helpful assistant."


@app.boot()
async def on_boot():
    print("[__NAME__] booted")


@app.message()
async def handle(session: cpsl.Session, msg: cpsl.Message):
    messages = [m.text for m in session.history]

    stream = b.stream.Chat(
        messages=messages,
        system_prompt=SYSTEM_PROMPT,
    )

    async with session.stream_reply() as reply:
        async for partial in stream:
            if partial is not None:
                reply.write(partial)
"""

_DASHBOARD_APP = """\
import cpsl

from baml_client import b

app = cpsl.App(
    name="__NAME__",
    image=cpsl.Image(python_packages=["baml-py==__BAML_VERSION__", "pydantic>=2.13.2"]),
    channels=[cpsl.Chat()],
    secrets=["ANTHROPIC_API_KEY"],
)

app.theme(preset="dark")

app.add_page("Dashboard", icon="layout-dashboard", component="pages/dashboard.tsx")

SYSTEM_PROMPT = "You are a helpful assistant."


@app.data("stats")
def get_stats():
    return {
        "total_conversations": 0,
        "messages_today": 0,
        "avg_response_time": "1.2s",
        "status": "online",
    }


@app.boot()
async def on_boot():
    print("[__NAME__] booted")


@app.message()
async def handle(session: cpsl.Session, msg: cpsl.Message):
    messages = [m.text for m in session.history]

    stream = b.stream.Chat(
        messages=messages,
        system_prompt=SYSTEM_PROMPT,
    )

    async with session.stream_reply() as reply:
        async for partial in stream:
            if partial is not None:
                reply.write(partial)
"""

_MINIMAL_APP = """\
import cpsl

app = cpsl.App(
    name="__NAME__",
    image=cpsl.Image(),
    channels=[cpsl.Chat()],
)


@app.message()
async def handle(session: cpsl.Session, msg: cpsl.Message):
    await session.reply(f"Echo: {msg.text}")
"""

_BAML_MAIN = """\
generator target {
  output_type "python/pydantic"
  output_dir ".."
  version "__BAML_VERSION__"
}
"""

_BAML_CLIENTS = """\
client<llm> Anthropic {
  provider anthropic
  options {
    model claude-sonnet-4-20250514
    api_key env.ANTHROPIC_API_KEY
  }
}
"""

_BAML_CHAT = """\
function Chat(messages: string[], system_prompt: string) -> string {
  client Anthropic

  prompt #"
    {{ _.role("system") }}
    {{ system_prompt }}

    {% for msg in messages %}
    {{ _.role("user") if loop.index is odd else _.role("assistant") }}
    {{ msg }}
    {% endfor %}

    {{ _.role("assistant") }}
  "#
}
"""

_PYPROJECT_BAML = """\
[project]
name = "__NAME__"
version = "0.1.0"
description = ""
requires-python = ">=3.13"
dependencies = [
    "baml-py==__BAML_VERSION__",
    "cpsl>=0.3.3",
    "pydantic>=2.13.2",
    "requests>=2.33.1",
]
"""

_PYPROJECT_MINIMAL = """\
[project]
name = "__NAME__"
version = "0.1.0"
description = ""
requires-python = ">=3.13"
dependencies = [
    "cpsl>=0.3.3",
]
"""

_MAKEFILE_BAML = """\
BAML_SRC := baml_src

.PHONY: baml

baml:
\tuv run baml-cli generate --from $(BAML_SRC)
"""

_MAKEFILE_MINIMAL = """\
.PHONY: serve deploy

serve:
\tcapsule serve app:app

deploy:
\tcapsule deploy app:app
"""

_PYTHON_VERSION = "3.13\n"

_GITIGNORE = """\
.venv/
__pycache__/
*.pyc
dist/
*.egg-info/
"""

_DASHBOARD_TSX = """\
import { useData, useTheme } from "@capsule/page"

interface Stats {
  total_conversations: number
  messages_today: number
  avg_response_time: string
  status: string
}

export default function Dashboard() {
  const theme = useTheme()
  const { data, loading } = useData<Stats>("stats")

  if (loading || !data) {
    return (
      <div style={{
        padding: 40,
        textAlign: "center",
        color: theme.muted,
        fontFamily: theme.font_mono,
        fontSize: 13,
      }}>
        Loading\u2026
      </div>
    )
  }

  const metrics = [
    { label: "Conversations", value: data.total_conversations },
    { label: "Messages Today", value: data.messages_today },
    { label: "Avg Response", value: data.avg_response_time },
    { label: "Status", value: data.status },
  ]

  return (
    <div style={{ fontFamily: theme.font_sans, maxWidth: 800 }}>
      <h2 style={{
        fontSize: 20,
        fontWeight: 600,
        color: theme.foreground,
        marginBottom: 24,
      }}>
        Dashboard
      </h2>
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
        gap: 16,
      }}>
        {metrics.map(m => (
          <div key={m.label} style={{
            padding: 20,
            borderRadius: 8,
            border: `1px solid ${theme.border}`,
            background: theme.surface,
          }}>
            <div style={{
              fontFamily: theme.font_mono,
              fontSize: 24,
              fontWeight: 600,
              color: theme.foreground,
            }}>
              {String(m.value)}
            </div>
            <div style={{
              fontSize: 12,
              color: theme.muted,
              marginTop: 4,
            }}>
              {m.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
"""

# ---------------------------------------------------------------------------
# Template registry
# ---------------------------------------------------------------------------

_TEMPLATES: dict[str, dict[str, str]] = {
    "chatbot": {
        "app.py": _CHATBOT_APP,
        "baml_src/main.baml": _BAML_MAIN,
        "baml_src/clients.baml": _BAML_CLIENTS,
        "baml_src/chat.baml": _BAML_CHAT,
        "pyproject.toml": _PYPROJECT_BAML,
        "Makefile": _MAKEFILE_BAML,
        ".python-version": _PYTHON_VERSION,
        ".gitignore": _GITIGNORE,
    },
    "dashboard": {
        "app.py": _DASHBOARD_APP,
        "baml_src/main.baml": _BAML_MAIN,
        "baml_src/clients.baml": _BAML_CLIENTS,
        "baml_src/chat.baml": _BAML_CHAT,
        "pages/dashboard.tsx": _DASHBOARD_TSX,
        "pyproject.toml": _PYPROJECT_BAML,
        "Makefile": _MAKEFILE_BAML,
        ".python-version": _PYTHON_VERSION,
        ".gitignore": _GITIGNORE,
    },
    "minimal": {
        "app.py": _MINIMAL_APP,
        "pyproject.toml": _PYPROJECT_MINIMAL,
        "Makefile": _MAKEFILE_MINIMAL,
        ".python-version": _PYTHON_VERSION,
        ".gitignore": _GITIGNORE,
    },
}

_TEMPLATE_META = [
    ("chatbot", "BAML streaming chatbot with Claude"),
    ("dashboard", "Chatbot + custom TSX data page"),
    ("minimal", "Simple message handler, no BAML"),
]

_HAS_BAML = {"chatbot", "dashboard"}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9_-]", "-", name.lower().strip()).strip("-")


def _apply(content: str, name: str) -> str:
    return content.replace("__NAME__", name).replace("__BAML_VERSION__", BAML_VERSION)


def _scaffold(project_dir: Path, template_name: str, name: str) -> list[str]:
    created: list[str] = []
    for rel, content in _TEMPLATES[template_name].items():
        dest = project_dir / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(_apply(content, name))
        created.append(rel)
    return created


def _ensure_uv() -> str | None:
    uv = shutil.which("uv")
    if uv:
        terminal.status_ok("uv detected")
        return uv

    terminal.detail("  installing uv...")
    try:
        if platform.system() == "Windows":
            subprocess.run(
                ["powershell", "-c", "irm https://astral.sh/uv/install.ps1 | iex"],
                check=True,
                capture_output=True,
            )
        else:
            subprocess.run(
                ["sh", "-c", "curl -LsSf https://astral.sh/uv/install.sh | sh"],
                check=True,
                capture_output=True,
            )
    except (subprocess.CalledProcessError, FileNotFoundError):
        terminal.status_fail("could not install uv automatically")
        terminal.detail(
            "  install manually: https://docs.astral.sh/uv/getting-started/installation/"
        )
        return None

    uv = shutil.which("uv")
    if not uv:
        for candidate in [
            Path.home() / ".local" / "bin" / "uv",
            Path.home() / ".cargo" / "bin" / "uv",
        ]:
            if candidate.is_file():
                uv = str(candidate)
                break

    if uv:
        terminal.status_ok("uv installed")
    else:
        terminal.status_fail("uv installed but not on PATH — restart your shell")
    return uv


def _run(cmd: list[str], cwd: Path) -> bool:
    try:
        subprocess.run(cmd, cwd=cwd, check=True, capture_output=True)
        return True
    except subprocess.CalledProcessError as e:
        terminal.status_fail(f"{' '.join(cmd[:3])} failed")
        stderr = (e.stderr or b"").decode(errors="replace").strip()
        if stderr:
            for line in stderr.splitlines()[:5]:
                terminal.detail(f"    {line}")
        return False


def _setup_env(project_dir: Path, template_name: str, uv: str) -> None:
    if not _run([uv, "sync"], project_dir):
        return
    terminal.status_ok("dependencies installed")

    if template_name in _HAS_BAML:
        if _run([uv, "run", "baml-cli", "generate", "--from", "baml_src"], project_dir):
            terminal.status_ok("BAML client generated")


def _prompt_template() -> str:
    _console.print()
    _console.print("  [bold]Templates:[/bold]")
    _console.print()
    for i, (key, desc) in enumerate(_TEMPLATE_META, 1):
        _console.print(f"    [bold #4CCACC][{i}][/bold #4CCACC] {key:<14}[dim]{desc}[/dim]")
    _console.print()
    choice = Prompt.ask(
        "  Template",
        choices=["1", "2", "3"],
        default="1",
        console=_console,
    )
    return _TEMPLATE_META[int(choice) - 1][0]


# ---------------------------------------------------------------------------
# CLI command
# ---------------------------------------------------------------------------


@click.command("bootstrap")
@click.argument("name", required=False)
@click.option(
    "--template",
    "-t",
    type=click.Choice(["chatbot", "dashboard", "minimal"]),
    default=None,
    help="Project template (chatbot, dashboard, minimal).",
)
def bootstrap(name: str | None, template: str | None) -> None:
    """Create a new Capsule project."""
    terminal.header("capsule bootstrap")

    if not name:
        _console.print()
        name = Prompt.ask("  [bold]Project name[/bold]", console=_console)
    if not name or not name.strip():
        terminal.error("Project name is required.")
        return

    name = _slugify(name)
    project_dir = Path.cwd() / name

    if project_dir.exists():
        terminal.error(f"Directory already exists: {name}")
        return

    if not template:
        template = _prompt_template()

    _console.print()
    terminal.header(f"Scaffolding {name}...")
    created = _scaffold(project_dir, template, name)
    for rel in created:
        terminal.detail(f"    . {rel}")

    _console.print()
    terminal.header("Setting up environment...")
    uv = _ensure_uv()
    if uv:
        _setup_env(project_dir, template, uv)

    _console.print()
    terminal.success("Project ready!")
    _console.print()
    _console.print(f"    [dim]cd {name}[/dim]")
    _console.print("    [dim]capsule serve app:app[/dim]")
    _console.print()
