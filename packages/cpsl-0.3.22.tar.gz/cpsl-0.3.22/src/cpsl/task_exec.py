"""Subprocess task execution for ``process=True`` tasks.

Extracted from runner.py to keep that module focused on the gRPC
connection loop and message dispatch. Everything here is internal —
the public API lives in task_types.py (TaskDescriptor, TaskHandle).
"""

from __future__ import annotations

import asyncio
import importlib
import json
import multiprocessing
import multiprocessing.connection
import os
import time
import traceback
import uuid
from typing import Any, Type

from .clients.capsule import (
    DataServiceStub,
    GetSessionRequest,
    RunnerServiceStub,
    SaveSessionDataRequest,
    SessionServiceStub,
    SubmitResultRequest,
)
from .constants import DEFAULT_CHANNEL_TYPE, HISTORY_FETCH_COUNT
from .db import ScopedDatabaseProxy
from .msg import Message
from .task_types import TaskDescriptor


def _retry_on_errors(retry_for: list[Type[Exception]], exc: BaseException) -> bool:
    """True when *exc* is an exact-type match for any entry in *retry_for*."""
    if not retry_for:
        return False
    return any(type(exc) is err for err in retry_for)


def _parse_integration_credential(ic: Any) -> Any:
    """Re-import helper to avoid circular dep on runner.py at module level."""
    from .integration import IntegrationCredentials, KNOWN_SECRET_INTEGRATIONS

    is_secret = ic.type in KNOWN_SECRET_INTEGRATIONS
    secret_fields: dict[str, str] = {}
    if is_secret and ic.access_token:
        try:
            parsed = json.loads(ic.access_token)
            if isinstance(parsed, dict):
                secret_fields = parsed
        except (json.JSONDecodeError, TypeError):
            pass

    return IntegrationCredentials(
        access_token="" if secret_fields else ic.access_token,
        token_type=ic.token_type or "bearer",
        scopes=list(ic.scopes),
        expires_at=ic.expires_at,
        fields=secret_fields,
    )


# ---------------------------------------------------------------------------
# Child process entrypoint
# ---------------------------------------------------------------------------

def _subprocess_entry(
    module_path: str,
    target_name: str,
    task_name: str,
    session_id: str,
    kwargs_json: str,
    result_conn: multiprocessing.connection.Connection,
) -> None:
    """Child process entrypoint for ``process=True`` tasks.

    Runs in a fresh Python interpreter (``spawn`` context). Creates its own
    gRPC channel, re-imports the user module, hydrates the session from the
    gateway, and executes the task function. The result — ``("ok", None)``
    or ``("error", "<traceback>")`` — is sent back to the parent via *pipe*.
    """
    try:
        from .app import App
        from .channel import Channel as _GrpcChannel
        from .session import Session, SessionChannel, UserInfo

        gw = os.environ.get("CAPSULE_GATEWAY_HOST", "localhost:1980")
        token = os.environ.get("CAPSULE_RUNNER_TOKEN") or None
        version_type = os.environ.get("CAPSULE_VERSION_TYPE", "")
        env_type = os.environ.get("CAPSULE_ENV_TYPE", "")
        app_id = os.environ.get("CAPSULE_APP_ID", "")
        user_id = os.environ.get("CAPSULE_USER_ID", "")
        canonical_type = env_type or version_type

        extra_md = []
        if canonical_type:
            extra_md.append(("x-version-type", canonical_type))
        ch = _GrpcChannel(addr=gw, token=token, extra_metadata=extra_md or None)

        runner_stub = RunnerServiceStub(ch)
        session_stub = SessionServiceStub(ch)
        data_stub = DataServiceStub(ch)

        # Expose stubs to session methods (prompt_file, prompt_integration,
        # show_image) which locate them via Runner._instance_ref.
        from .runner import Runner
        _shim = object.__new__(Runner)
        _shim._runner_stub = runner_stub
        _shim._session_stub = session_stub
        _shim._app_id = app_id
        Runner._instance_ref = _shim

        data_app_id = f"{app_id}_dev" if canonical_type == "serve" else app_id

        mod = importlib.import_module(module_path)
        obj = getattr(mod, target_name)
        instance = None

        if isinstance(obj, App):
            desc = getattr(obj, task_name, None)
        else:
            instance = obj()
            desc = None
            for name in dir(instance):
                attr = getattr(instance, name, None)
                if isinstance(attr, TaskDescriptor) and attr._name == task_name:
                    desc = attr
                    break

        if desc is None:
            result_conn.send(("error", f"task '{task_name}' not found on {target_name}"))
            return

        kwargs = json.loads(kwargs_json) if kwargs_json else {}

        async def _run() -> None:
            session = None
            if session_id:
                session = Session(
                    id=session_id,
                    user=UserInfo(id=user_id, email=None),
                    channel=SessionChannel(type=DEFAULT_CHANNEL_TYPE),
                    history=[],
                    data={},
                )

                resp = session_stub.get_session(
                    GetSessionRequest(
                        session_id=session_id,
                        history_count=HISTORY_FETCH_COUNT,
                    )
                )
                if resp.user_id:
                    session.user = UserInfo(
                        id=resp.user_id,
                        email=resp.user_email or None,
                        org_id=resp.org_id or None,
                    )
                if resp.channel_type:
                    session.channel = SessionChannel(type=resp.channel_type)
                if resp.data_json:
                    session.data = json.loads(resp.data_json)

                raw = [
                    Message(text=e.text, sender=e.sender, channel_type=e.channel_type)
                    for e in resp.history
                ]
                history: list[Message] = []
                for m in raw:
                    if history and history[-1].sender == m.sender:
                        history[-1] = Message(
                            text=history[-1].text + m.text,
                            sender=m.sender,
                            channel_type=m.channel_type,
                        )
                    else:
                        history.append(m)
                session.history = history

                if resp.integrations:
                    session.integrations = {
                        ic.type: _parse_integration_credential(ic)
                        for ic in resp.integrations
                    }

                async def _task_reply(msg: Message) -> None:
                    rid = str(uuid.uuid4())
                    runner_stub.submit_result(
                        SubmitResultRequest(
                            request_id=rid, text=msg.text, done=True,
                            session_id=session_id,
                        )
                    )

                async def _task_block(block_json: str) -> None:
                    rid = str(uuid.uuid4())
                    runner_stub.submit_result(
                        SubmitResultRequest(
                            request_id=rid, text="", done=True,
                            session_id=session_id, block_json=block_json,
                        )
                    )

                session._reply_callback = _task_reply
                session._block_callback = _task_block
                session._runner_stub = runner_stub
                session._session_stub = session_stub
                session._app_id = app_id

                if data_stub:
                    session._db_proxy = ScopedDatabaseProxy(
                        data_stub,
                        data_app_id,
                        user_id=session.user.id,
                        team_id=session.user.owner_id,
                        session_id=session.id,
                        collection_scopes={},
                    )

            fn = desc._fn
            is_async = desc._is_async
            is_functional = desc._functional

            if is_functional:
                result = fn(session, **kwargs) if session else fn(**kwargs)
            else:
                inst = getattr(desc, "_instance", None) or instance
                result = fn(inst, session, **kwargs) if session else fn(inst, **kwargs)

            if is_async:
                await result

            if session:
                session_stub.save_session_data(
                    SaveSessionDataRequest(
                        session_id=session.id,
                        data_json=json.dumps(session.data),
                    )
                )

        asyncio.run(_run())
        result_conn.send(("ok", None))

    except BaseException:
        result_conn.send(("error", traceback.format_exc()))
    finally:
        result_conn.close()


# ---------------------------------------------------------------------------
# Parent-side subprocess driver
# ---------------------------------------------------------------------------

async def run_task_subprocess(
    module_path: str,
    target_name: str,
    task_name: str,
    session_id: str,
    kwargs_json: str,
    timeout: int,
) -> tuple[str, str]:
    """Spawn the task in a child process and wait for it to finish.

    Returns ``(status, error_msg)`` where *status* is one of
    ``"ok"``, ``"error"``, ``"timeout"``, or ``"killed"``.
    """
    ctx = multiprocessing.get_context("spawn")
    parent_conn, child_conn = ctx.Pipe(duplex=False)

    proc = ctx.Process(
        target=_subprocess_entry,
        args=(module_path, target_name, task_name, session_id, kwargs_json, child_conn),
        daemon=True,
    )
    proc.start()
    child_conn.close()

    deadline = (time.time() + timeout) if timeout > 0 else None

    while proc.is_alive():
        if deadline and time.time() > deadline:
            proc.kill()
            proc.join(timeout=5)
            return "timeout", f"process killed after {timeout}s timeout"
        await asyncio.sleep(1)

    proc.join(timeout=5)

    if parent_conn.poll(timeout=1):
        status, detail = parent_conn.recv()
    else:
        status, detail = "error", "no result from child process"
    parent_conn.close()

    exit_code = proc.exitcode
    if exit_code is not None and exit_code < 0:
        sig_num = -exit_code
        return "killed", f"process killed by signal {sig_num}"
    if exit_code is not None and exit_code != 0 and status == "ok":
        return "error", f"process exited with code {exit_code}"

    return status, detail or ""
