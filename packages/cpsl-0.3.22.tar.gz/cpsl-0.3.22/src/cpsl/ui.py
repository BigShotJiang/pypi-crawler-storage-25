"""Declarative widget primitives for Python DSL pages.

Each widget serializes to a JSON dict via ``to_dict()``. The frontend
``<WidgetRenderer>`` component recursively renders the tree.
"""

from __future__ import annotations

from typing import Any, Literal, TYPE_CHECKING

ChartType = Literal["line", "bar", "pie", "scatter", "area"]
"""Supported chart visualisation types."""

MetricFormat = Literal["number", "currency", "percent"]
"""Display format for a ``Metric`` widget's value."""

if TYPE_CHECKING:
    from .db import CollectionRef


class _Widget:
    _type: str = ""

    def to_dict(self) -> dict[str, Any]:
        raise NotImplementedError


class Page(_Widget):
    _type = "page"

    def __init__(self, children: list[_Widget]) -> None:
        self.children = children

    def to_dict(self) -> dict[str, Any]:
        return {"type": self._type, "children": [c.to_dict() for c in self.children]}


class Row(_Widget):
    _type = "row"

    def __init__(self, children: list[_Widget]) -> None:
        self.children = children

    def to_dict(self) -> dict[str, Any]:
        return {"type": self._type, "children": [c.to_dict() for c in self.children]}


class Column(_Widget):
    _type = "column"

    def __init__(self, children: list[_Widget]) -> None:
        self.children = children

    def to_dict(self) -> dict[str, Any]:
        return {"type": self._type, "children": [c.to_dict() for c in self.children]}


class Card(_Widget):
    _type = "card"

    def __init__(
        self,
        title: str | None = None,
        children: list[_Widget] | None = None,
    ) -> None:
        self.title = title
        self.children = children or []

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self._type}
        if self.title is not None:
            d["title"] = self.title
        if self.children:
            d["children"] = [c.to_dict() for c in self.children]
        return d


class Metric(_Widget):
    """Single KPI / stat card.

    Provide a static ``value`` directly, or bind to a collection with
    ``data`` + ``field`` to compute the metric from stored data.

    Args:
        label: Display label shown above the value.
        data: Name of a collection to pull data from.
        field: Column in the collection to aggregate.
        value: Static value to display (used when ``data`` is ``None``).
        format: Display format — ``"number"``, ``"currency"``, or
            ``"percent"``.
    """

    _type = "metric"

    def __init__(
        self,
        label: str,
        *,
        data: str | None = None,
        field: str | None = None,
        value: Any = None,
        format: MetricFormat | None = None,
    ) -> None:
        self.label = label
        self.data = data
        self.field = field
        self.value = value
        self.format = format

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self._type, "label": self.label}
        if self.data is not None:
            d["data"] = self.data
        if self.field is not None:
            d["field"] = self.field
        if self.value is not None:
            d["value"] = self.value
        if self.format is not None:
            d["format"] = self.format
        return d


class Table(_Widget):
    """Data table backed by a collection or inline rows.

    Pass a ``CollectionRef`` (from ``self.db.collection``) to bind the table
    to a stored collection — column order, sort, filter, and pagination
    settings are inherited from the collection declaration.  Alternatively
    pass ``rows`` for a static inline table.

    Args:
        collection: Collection name (``str``) or a ``CollectionRef``.
            When a ``CollectionRef`` is used, column/sort/filter/paginate
            defaults are pulled from its declaration automatically.
        data: Named data source (alternative to ``collection``).
        rows: Inline list of ``{"col": value}`` dicts.
        columns: Column names to display (and their order).
        sortable: Enable column sorting in the UI.
        filterable: Show a filter bar above the table.
        paginate: Rows per page (``0`` disables pagination).
    """

    _type = "table"

    def __init__(
        self,
        collection: str | CollectionRef | None = None,
        *,
        data: str | None = None,
        rows: list[dict[str, Any]] | None = None,
        columns: list[str] | None = None,
        sortable: bool = False,
        filterable: bool = False,
        paginate: int = 0,
    ) -> None:
        from .db import CollectionRef as _Ref
        if isinstance(collection, _Ref):
            decl = collection._decl
            self.collection = collection.name
            if columns is None and decl.columns:
                columns = list(decl.columns)
            if not sortable and decl.sortable:
                sortable = decl.sortable
            if not filterable and decl.filterable:
                filterable = decl.filterable
            if not paginate and decl.paginate:
                paginate = decl.paginate
        else:
            self.collection = collection
        self.data = data
        self.rows = rows
        self.columns = columns
        self.sortable = sortable
        self.filterable = filterable
        self.paginate = paginate

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self._type}
        if self.collection is not None:
            has_overrides = self.columns or self.sortable or self.filterable or self.paginate
            if has_overrides:
                d["collection"] = self.collection
                if self.columns:
                    d["columns"] = self.columns
                if self.sortable:
                    d["sortable"] = True
                if self.filterable:
                    d["filterable"] = True
                if self.paginate > 0:
                    d["paginate"] = self.paginate
            else:
                d["collection_ref"] = self.collection
            return d
        if self.data is not None:
            d["data"] = self.data
        if self.rows is not None:
            d["rows"] = self.rows
        if self.columns is not None:
            d["columns"] = self.columns
        if self.sortable:
            d["sortable"] = True
        if self.filterable:
            d["filterable"] = True
        if self.paginate > 0:
            d["paginate"] = self.paginate
        return d


class Chart(_Widget):
    """Chart widget backed by a named data source.

    Args:
        data: Name of the data source to visualise.
        chart_type: Visualisation style — ``"line"``, ``"bar"``,
            ``"pie"``, ``"scatter"``, or ``"area"``.
        x: Column to use for the x-axis.
        y: Column to use for the y-axis.
    """

    _type = "chart"

    def __init__(
        self,
        *,
        data: str | None = None,
        chart_type: ChartType = "line",
        x: str | None = None,
        y: str | None = None,
    ) -> None:
        self.data = data
        self.chart_type = chart_type
        self.x = x
        self.y = y

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self._type, "chart_type": self.chart_type}
        if self.data is not None:
            d["data"] = self.data
        if self.x is not None:
            d["x"] = self.x
        if self.y is not None:
            d["y"] = self.y
        return d


class Text(_Widget):
    _type = "text"

    def __init__(self, content: str, *, style: str | None = None) -> None:
        self.content = content
        self.style = style

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self._type, "content": self.content}
        if self.style is not None:
            d["style"] = self.style
        return d


class Divider(_Widget):
    _type = "divider"

    def to_dict(self) -> dict[str, Any]:
        return {"type": self._type}


class TaskBoardColumn:
    """A single column in a TaskBoard, grouping tasks by status."""

    def __init__(self, label: str, statuses: list[str]) -> None:
        self.label = label
        self.statuses = statuses

    def to_dict(self) -> dict[str, Any]:
        return {"label": self.label, "statuses": list(self.statuses)}


class TaskBoard(_Widget):
    """Kanban board of tasks for the current app.

    Tasks are fetched from the gateway's task API and bucketed into columns
    by status. Defaults to Pending / Running / Completed / Failed columns;
    pass ``columns`` to override.

    ``filter`` is forwarded as query parameters to the tasks endpoint, so
    keys like ``task_name``, ``session_id``, or ``status`` all work.
    """

    _type = "task_board"

    def __init__(
        self,
        *,
        title: str | None = None,
        filter: dict[str, Any] | None = None,
        columns: list[TaskBoardColumn] | None = None,
        refresh_ms: int = 5000,
    ) -> None:
        self.title = title
        self.filter = filter
        self.columns = columns
        self.refresh_ms = refresh_ms

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self._type, "refresh_ms": self.refresh_ms}
        if self.title is not None:
            d["title"] = self.title
        if self.filter:
            d["filter"] = dict(self.filter)
        if self.columns:
            d["columns"] = [c.to_dict() for c in self.columns]
        return d
