"""Entry point for running the Komodo MCP server as a module.

Usage:
    python -m kom_mcp
"""

from .server import run_server

if __name__ == "__main__":
    run_server()
