from __future__ import annotations

import time
import webbrowser

import httpx
import typer
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.spinner import Spinner
from rich.text import Text

from .util import ENVIRONMENT_OPTION, get_environment, get_headers, get_session_and_settings, handle_api_error

POLL_INTERVAL_SECONDS = 2.0
POLL_TIMEOUT_SECONDS = 300.0
PROCESSING_STATUSES = {"triggering_next_turn", "processing_llm", "processing_tool"}


def _open_url_in_browser(url: str, message: str):
    """Helper to open a URL in the browser and print a message."""
    console = Console()
    try:
        success = webbrowser.open(url)
        if success:
            console.print(Text(message, style="bold green"))
        else:
            console.print(Text("Failed to open browser: Unable to launch browser", style="bold red"))
            raise typer.Exit(code=1)
    except Exception as e:
        console.print(Text(f"Failed to open browser: {e}", style="bold red"))
        raise typer.Exit(code=1) from e


def _fetch_csrf_token(base_url: str, headers: dict, console: Console) -> str:
    """Fetch a CSRF token from the Marmot API."""
    url = f"{base_url}/auth/csrf-token"

    with httpx.Client(timeout=10.0) as client:
        try:
            response = client.get(url, headers=headers)
        except httpx.RequestError as e:
            console.print(Text(f"Network error fetching CSRF token: {e}", style="bold red"))
            raise typer.Exit(code=1) from e

    if response.status_code == 200:
        return response.json()["csrf_token"]

    handle_api_error(response, console, "fetch CSRF token")
    return ""  # unreachable; handle_api_error always raises


def _create_chat(base_url: str, headers: dict, message_text: str, console: Console) -> dict:
    """Create a Marmot chat with an initial message. Returns the API response."""
    csrf_token = _fetch_csrf_token(base_url, headers, console)
    headers = {**headers, "X-CSRF-Token": csrf_token}

    url = f"{base_url}/api/chat/chats"
    payload = {"initial_message": {"text": message_text}}

    with httpx.Client(timeout=30.0) as client:
        try:
            response = client.post(url, headers=headers, json=payload)
        except httpx.RequestError as e:
            console.print(Text(f"Network error creating chat: {e}", style="bold red"))
            raise typer.Exit(code=1) from e

    if response.status_code == 201:
        return response.json()

    handle_api_error(response, console, "create chat")
    return {}  # unreachable; handle_api_error always raises


def _poll_chat_status(base_url: str, chat_id: str, headers: dict, console: Console) -> str:
    """Poll chat status until processing completes. Returns final status."""
    url = f"{base_url}/api/chat/chats/{chat_id}/status"
    deadline = time.monotonic() + POLL_TIMEOUT_SECONDS

    last_error: str | None = None

    with httpx.Client(timeout=10.0) as client:
        while time.monotonic() < deadline:
            time.sleep(POLL_INTERVAL_SECONDS)

            try:
                response = client.get(url, headers=headers)
            except httpx.RequestError as e:
                last_error = str(e)
                continue

            if response.status_code == 200:
                data = response.json()
                status = data.get("status", "")
                if status not in PROCESSING_STATUSES:
                    return status
                last_error = None
            elif 400 <= response.status_code < 500:
                handle_api_error(response, console, "poll chat status")
            else:
                last_error = f"HTTP {response.status_code}"

    msg = "Timed out waiting for Marmot response."
    if last_error:
        msg = f"{msg} Last error: {last_error}"
    console.print(Text(msg, style="bold red"))
    raise typer.Exit(code=1)


def _fetch_assistant_messages(base_url: str, chat_id: str, headers: dict, console: Console) -> list[dict]:
    """Fetch all messages for a chat and return assistant messages."""
    url = f"{base_url}/api/chat/chats/{chat_id}/messages"

    with httpx.Client(timeout=10.0) as client:
        try:
            response = client.get(url, headers=headers)
        except httpx.RequestError as e:
            console.print(Text(f"Network error fetching messages: {e}", style="bold red"))
            raise typer.Exit(code=1) from e

    if response.status_code != 200:
        handle_api_error(response, console, "fetch messages")

    data = response.json()
    return [m for m in data.get("messages", []) if m.get("role") == "assistant"]


def _extract_text_from_message(message: dict) -> str:
    """Extract readable text from a Marmot message content list.

    Content blocks can be either {"text": "..."} (TextContent) or
    {"type": "text", "text": "..."} style dicts.
    """
    parts = [block["text"] for block in message.get("content", []) if isinstance(block, dict) and "text" in block]
    return "\n".join(parts) if parts else "(no text content)"


def _run_chat(message_text: str, environment: str, url_override: str | None = None):
    """Send a message to Marmot and display the response in the terminal."""
    env = get_environment(environment)
    _session, settings, console, credentials = get_session_and_settings(env)
    headers = get_headers(credentials.access_token, str(credentials.account_id))
    base_url = (url_override or settings.marmot_url).rstrip("/")

    console.print(Text(f'Sending to Marmot: "{message_text}"', style="bold cyan"))
    console.print()

    chat_response = _create_chat(base_url, headers, message_text, console)
    chat_id = chat_response["chat_id"]

    with Live(Spinner("dots", text="Marmot is thinking..."), console=console, transient=True):
        final_status = _poll_chat_status(base_url, chat_id, headers, console)

    if final_status == "error":
        console.print(Text("Marmot encountered an error processing your request.", style="bold red"))
        raise typer.Exit(code=1)

    assistant_messages = _fetch_assistant_messages(base_url, chat_id, headers, console)
    if not assistant_messages:
        console.print(Text("No response received from Marmot.", style="bold yellow"))
        raise typer.Exit(code=1)

    last_message = assistant_messages[-1]
    response_text = _extract_text_from_message(last_message)
    console.print(Panel(Markdown(response_text), title="Marmot", border_style="green"))

    chat_url = f"{base_url}/chat/{chat_id}"
    console.print()
    console.print(Text(f"Continue this conversation: {chat_url}", style="dim"))


def marmot(
    chat: str | None = typer.Option(None, "--chat", "-c", help="Send a message to Marmot and get the response in the terminal."),
    url: str | None = typer.Option(None, "--url", help="Override the Marmot URL (e.g. https://marmot-staging.komodohealth.com)."),
    environment: str = ENVIRONMENT_OPTION,
):
    """Open Marmot or send a chat message."""
    if chat is not None:
        if not chat.strip():
            Console().print(Text("Chat message cannot be empty.", style="bold red"))
            raise typer.Exit(code=1)
        _run_chat(chat, environment, url_override=url)
    else:
        from komodo.config import SDKSettings  # noqa: PLC0415

        env = get_environment(environment)
        settings = SDKSettings(environment=env)
        target_url = (url or settings.marmot_url).rstrip("/")
        _open_url_in_browser(target_url, f"Opening Marmot: {target_url}")


def docs():
    """Open documentation website in default browser."""
    url = "https://docs.komodohealth.com"
    message = f"Opening Documentation: {url}"
    _open_url_in_browser(url, message)
