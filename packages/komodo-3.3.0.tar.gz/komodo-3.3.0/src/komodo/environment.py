"""Logical Komodo environments and internal-plugin detection.

The ``development`` environment is only valid when ``komodo-internal-tools``
is installed; using it without the package raises an error.
"""

from __future__ import annotations

import importlib.util
from typing import Final

DEVELOPMENT_ENV: Final = "development"

DEVELOPMENT_REQUIRES_PLUGIN_MSG: Final = "KOMODO_ENVIRONMENT=development requires the komodo-internal-tools package. " "Install it or use 'integration' or 'production'."


class DevelopmentEnvironmentRequiresPluginError(ValueError):
    """Raised when ``development`` is requested without ``komodo-internal-tools``."""

    def __init__(self, message: str = DEVELOPMENT_REQUIRES_PLUGIN_MSG) -> None:
        super().__init__(message)


def is_internal_plugin_installed() -> bool:
    """True if the internal connector plugin package is importable."""
    return importlib.util.find_spec("komodo_internal_tools") is not None


def ensure_development_plugin_installed(normalized_environment: str) -> None:
    """Raise if *normalized_environment* is ``development`` but the internal plugin is absent."""
    if normalized_environment.strip().lower() == DEVELOPMENT_ENV and not is_internal_plugin_installed():
        raise DevelopmentEnvironmentRequiresPluginError()


def effective_credentials_environment(environment: str) -> str:
    """INI section name for storing and loading OAuth tokens (matches logical environment)."""
    key = environment.strip().lower()
    ensure_development_plugin_installed(key)
    return key


def persisted_komodo_environment(login_environment: str) -> str:
    """Value for ``[session] komodo_environment`` after a credential write."""
    key = login_environment.strip().lower()
    ensure_development_plugin_installed(key)
    return key
