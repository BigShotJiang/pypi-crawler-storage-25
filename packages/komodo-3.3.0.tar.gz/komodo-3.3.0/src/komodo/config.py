import logging.config
import os
from uuid import UUID
from typing import Optional

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from komodo.environment import DEVELOPMENT_ENV, ensure_development_plugin_installed


logger = logging.getLogger(__name__)


class SDKSettings(BaseSettings):
    # All environment variables related to the komodo platform should start with the prefix "KOMODO_"
    model_config = SettingsConfigDict(env_prefix="KOMODO_")

    environment: str = Field(default="production", env="ENVIRONMENT")

    @field_validator("environment", mode="before")
    @classmethod
    def _validate_environment(cls, v):
        if v is None:
            return v
        key = str(v).strip().lower()
        ensure_development_plugin_installed(key)
        return key

    access_token: Optional[SecretStr] = Field(default=None, env="ACCESS_TOKEN")
    refresh_token: Optional[SecretStr] = Field(default=None, env="REFRESH_TOKEN")
    token_expiration: Optional[int] = Field(default=None, env="TOKEN_EXPIRATION")
    client_id: Optional[str] = Field(default=None, env="CLIENT_ID")
    client_secret: Optional[SecretStr] = Field(default=None, env="CLIENT_SECRET")
    account_id: Optional[UUID] = Field(default=None, env="ACCOUNT_ID")
    account_slug: Optional[str] = Field(default=None, env="ACCOUNT_SLUG")
    credentials_path: Optional[str] = Field(default=None, env="CREDENTIALS_PATH")

    @property
    def resolved_credentials_path(self) -> str:
        """Return the credentials file path: KOMODO_CREDENTIALS_PATH if set, otherwise ~/.komodo/credentials."""
        return os.path.expanduser(self.credentials_path) if self.credentials_path else os.path.expanduser("~/.komodo/credentials")

    @property
    def _env_key(self) -> str:
        return self.environment.strip().lower()

    @property
    def komodo_external(self) -> str:
        return "https://api.komodohealth.com" if self._env_key == "production" else "https://dev-api.khinternal.net"

    @property
    def proxy_domain(self) -> str:
        return "https://connector-gateway.onkomodo.com" if self._env_key == "production" else "https://connector-gateway.staging.onkomodo.com"

    @property
    def komodo_rbac_me(self) -> str:
        return f"{self.komodo_external}/platform-rbac-prod/v1/iam/users/me" if self._env_key == "production" else f"{self.komodo_external}/platform-rbac-stage/v1/iam/users/me"

    @property
    def secrets_service_host(self) -> str:
        if self._env_key == "production":
            return "https://secrets-service.internal.onkomodo.com"
        if self._env_key == DEVELOPMENT_ENV:
            return "https://secrets-service.internal.dev.onkomodo.com"
        return "https://secrets-service.internal.staging.onkomodo.com"

    @property
    def komodo_idp_domain(self) -> str:
        return "auth.komodohealth.com" if self._env_key == "production" else "auth-staging.komodohealth.com"

    @property
    def komodo_client_id(self) -> str:
        return "mkxXDmAae54idV6TIpviUfq2ySuRdC9Y" if self._env_key == "production" else "O69UYSTsC6Tz2jBgzSC30odgX5fmu0xh"

    @property
    def komodo_idp_audience(self) -> str:
        return "https://komodohealth-platform.us.auth0.com/api/v2/" if self._env_key == "production" else "https://komodohealth-platform-staging.us.auth0.com/api/v2/"

    @property
    def komodo_subscription_url(self) -> str:
        return "https://api.khinternal.net/platform-subscription-prod/graphql" if self._env_key == "production" else "https://dev-api.khinternal.net/platform-subscription-integration/graphql"

    @property
    def marmot_url(self) -> str:
        if self._env_key == "production":
            return "https://marmot.komodohealth.com"
        if self._env_key == DEVELOPMENT_ENV:
            return "https://marmot-dev.komodohealth.com"
        return "https://marmot-staging.komodohealth.com"
