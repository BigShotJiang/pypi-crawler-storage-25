# Komodo Development Kit

The **`komodo`** PyPI package is the **Python SDK and CLI** component of the **Komodo Development Kit** for the Komodo Health platform. It ships three main surfaces:

| Surface | What you get |
|--------|----------------|
| **SDK** | Python APIs for OAuth-backed sessions, account context, and Snowflake access via a DB-API 2.0 connection |
| **CLI** | The `komodo` command-line tool for login, account selection, ad hoc SQL, running the MCP server, and more |
| **MCP tools** | A [Model Context Protocol](https://modelcontextprotocol.io/) server you can attach to compatible AI clients so assistants can call Komodo-backed tools (see the docs for configuration) |

Together they cover authentication, querying your Komodo data warehouse, and optional assistant-driven workflows.

## Features

- **OAuth 2.0 device flow** — browser-based login and persisted credentials
- **Snowflake access** — query your warehouse through the platform proxy (SDK or CLI)
- **Sync and async queries** — blocking execution and async submit/poll helpers in Python
- **Automatic token refresh**
- **Environments** — `integration` or `production` via `KOMODO_ENVIRONMENT`

## Prerequisites

- Python 3.11 or higher (see `requires-python` in this package)
- [uv](https://docs.astral.sh/uv/getting-started/installation/) (recommended)

## Installation

From a new directory, initialize a uv project and add the package:

```bash
uv init
uv add komodo
```

Confirm the CLI:

```bash
uv run komodo --version
```

## Quick start

1. Log in (opens a browser):

   ```bash
   uv run komodo login
   ```

2. Choose your Komodo account:

   ```bash
   uv run komodo account set
   ```

3. Use the **SDK** from Python — create `first_query.py`:

   ```python
   from komodo import get_snowflake_connection

   conn = get_snowflake_connection()
   cursor = conn.cursor()
   cursor.execute("SELECT 1")
   print(cursor.fetchone())
   conn.close()
   ```

   ```bash
   uv run first_query.py
   ```

## Documentation

Full guides for the Komodo Development Kit—SDK, CLI, MCP setup, authentication (including machine-to-machine), pandas, and API reference:

**https://docs.komodohealth.com**
