import io
import os

import pandas as pd
import sqlalchemy
from azure.storage.blob import BlobClient, BlobServiceClient

from ..common.jragbeer_common_data_eng import dagster_logger, data_path


def adls_upload_folder(directory: str = data_path, file_search_string: str | None = None) -> None:
    """Upload each file in a directory to Azure Data Lake Storage (blob).

    Args:
        directory: Root directory whose files are listed and uploaded.
        file_search_string: If set, only filenames containing this substring are
            uploaded; otherwise all files in ``directory`` are uploaded.

    Returns:
        None
    """
    if file_search_string:
        file_list = [i for i in os.listdir(directory) if file_search_string in i]
    else:
        file_list = [i for i in os.listdir(directory)]

    for each_file in file_list:
        adls_upload_file(directory + each_file, each_file)


def adls_upload_file(file_path: str, blob_name: str = "blob_path_or_name") -> None:
    """Upload a local file to blob storage as a block blob (overwrite).

    Args:
        file_path: Path to the file on disk.
        blob_name: Blob path/name inside the configured container.

    Returns:
        None
    """
    with open(file_path, "rb") as file_to_upload:
        blob_service_client = BlobServiceClient.from_connection_string(os.getenv("adls_connection_string") or "")
        # Instantiate a new ContainerClient
        container_client = blob_service_client.get_container_client(os.getenv("adls_container_name"))
        # Instantiate a new BlobClient
        blob_client = container_client.get_blob_client(blob_name)
        # upload data
        blob_client.upload_blob(file_to_upload, blob_type="BlockBlob", overwrite=True)
        dagster_logger.info(
            f"""{blob_name} is uploaded to BLOB storage (container: {os.getenv("adls_container_name")})"""
        )


def adls_upload_sql_table(
    engine: sqlalchemy.engine.base.Engine,
    table_name: str = "name_of_sql_table",
) -> None:
    """Read an entire SQL table and upload it as Parquet to blob storage.

    Args:
        engine: SQLAlchemy engine connected to the source database.
        table_name: Table to ``SELECT *`` from; also used as the blob name.

    Returns:
        None
    """
    adls_connection_string = os.getenv("adls_connection_string") or ""
    adls_container_name = os.getenv("adls_container_name") or ""
    df = pd.read_sql(f"select * from {table_name} ", engine)
    output = df.to_parquet()
    blob = BlobClient.from_connection_string(
        adls_connection_string, container_name=adls_container_name, blob_name=table_name
    )
    blob.upload_blob(
        output,
        overwrite=True,
    )
    dagster_logger.info(
        f"""Latest {table_name} is uploaded to BLOB storage (container: {os.getenv("adls_container_name")})"""
    )


def adls_upload_df(
    idf_: pd.DataFrame,
    blob_name: str = "name_of_blob",
    container_name: str = os.getenv("adls_container_name", "adls_container_name"),
) -> None:
    """Upload a DataFrame as Parquet after normalizing object columns for blob storage.

    Object columns are cast to string and truncated; duplicates are dropped and
    ``\"nan\"`` strings are replaced with ``None`` before upload.

    Args:
        idf_: DataFrame to serialize and upload.
        blob_name: Destination blob name.
        container_name: Target container; defaults to ``adls_container_name`` env
            or placeholder string.

    Returns:
        None
    """
    adls_connection_string = os.getenv("adls_connection_string") or ""
    for col_type, col_name in zip(idf_.dtypes, idf_.columns):
        if col_type == "object":
            idf_[col_name] = idf_[col_name].astype(str)
            idf_[col_name] = [i[:4000] for i in idf_[col_name]]
    output = idf_.reset_index(drop=True).drop_duplicates().replace({"nan": None}).to_parquet(index=False)
    blob = BlobClient.from_connection_string(
        adls_connection_string,
        container_name=str(container_name).lower(),
        blob_name=blob_name,
    )
    blob.upload_blob(
        output,
        overwrite=True,
        timeout=14400,
        connection_timeout=14400,
    )
    dagster_logger.info(f"Latest {blob_name} is uploaded to BLOB storage (container: {container_name})")


def adls_download_parquet_file(
    blob_name: str, input_container_name: str = os.getenv("adls_container_name", "adls_container_name")
) -> pd.DataFrame | None:
    """Download a Parquet blob and load it as a pandas DataFrame.

    Args:
        blob_name: Blob path/name in the container.
        input_container_name: Container to read from.

    Returns:
        DataFrame parsed from Parquet, or ``None`` if the blob is missing or
        parsing fails (failures are logged).
    """
    adls_connection_string = os.getenv("adls_connection_string") or ""
    blob = BlobClient.from_connection_string(
        adls_connection_string, container_name=input_container_name, blob_name=blob_name
    )
    # if there's a file that exists in the BLOB
    if blob.exists():
        # Download blob as StorageStreamDownloader object (stored in memory)
        downloaded_blob = blob.download_blob()
        # check if we can read the parquet file, if we can't probably not a parquet file
        bytes_data = downloaded_blob.readall()
        try:
            bytes_io = io.BytesIO(bytes_data)  # type: ignore
            idf = pd.read_parquet(bytes_io)
            return idf
        except Exception:
            dagster_logger.info("Reading BLOB did not work.")


def adls_download_text_file(
    blob_name: str,
    input_container_name: str = os.getenv("adls_container_name", "adls_container_name"),
    save_file: str | None = None,
) -> str | None:
    """Download a blob as UTF-8 text, optionally writing it to disk.

    Args:
        blob_name: Blob path/name in the container.
        input_container_name: Container to read from.
        save_file: If set, decoded text is written to this path.

    Returns:
        File contents as a string, or ``None`` if the blob is missing or read
        fails after logging.
    """
    blob = BlobClient.from_connection_string(
        os.getenv("adls_connection_string", "adls_connection_string"),
        container_name=input_container_name,
        blob_name=blob_name,
    )
    # if there's a file that exists in the BLOB
    text_data = None
    if blob.exists():
        # Download blob as StorageStreamDownloader object (stored in memory)
        downloaded_blob = blob.download_blob()
        # check if we can read the parquet file, if we can't probably not a parquet file
        try:
            text_data = downloaded_blob.readall().decode("utf-8")  # type: ignore
            if save_file:
                with open(save_file, "w") as f:
                    f.write(text_data)
            return text_data
        except Exception:
            dagster_logger.info("Reading BLOB did not work.")
            return text_data
    return text_data


def adls_replace_nans_with_nulls_in_dfs() -> None:
    """Re-process every ``.parquet`` blob: replace NaN-like values and re-upload.

    Iterates blobs in the default container, downloads each Parquet via
    ``adls_download_parquet_file``, then uploads via ``adls_upload_df``. Logs
    and skips blobs that fail.

    Returns:
        None
    """
    adls_connection_string = os.getenv("adls_connection_string") or ""
    blob_svc = BlobServiceClient.from_connection_string(conn_str=adls_connection_string)
    dagster_logger.info("\nList blobs in the container")
    container_client = blob_svc.get_container_client(os.getenv("adls_container_name"))
    blob_list = container_client.list_blobs()
    for blob in blob_list:
        if blob.name.endswith(".parquet"):
            try:
                dagster_logger.info(blob.name)
                pdf = adls_download_parquet_file(blob.name)
                if pdf is None:
                    raise ValueError("Failed to download parquet file")
                adls_upload_df(pdf, blob.name)
            except Exception as ee:
                dagster_logger.info(ee)
