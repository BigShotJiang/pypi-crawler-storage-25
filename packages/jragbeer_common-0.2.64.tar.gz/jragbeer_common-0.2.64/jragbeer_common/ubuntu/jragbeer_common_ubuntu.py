import datetime
import io
import json
import math
import os
import platform
import re
import socket
import subprocess
import time
from typing import Any, Callable, Iterable, Union

import numpy as np
import paramiko
import psutil
import yaml

from ..common.jragbeer_common_data_eng import dagster_logger, error_handling

# One definition for local ``subprocess`` and remote shell so query fields stay in sync.
_NVIDIA_SMI_GPU_CSV_ARGV: tuple[str, ...] = (
    "nvidia-smi",
    "--query-gpu=index,name,utilization.gpu,memory.used,memory.total,temperature.gpu",
    "--format=csv,noheader,nounits",
)


class SshClient:
    """Thin wrapper around ``paramiko.SSHClient`` for remote shell commands."""

    TIMEOUT = 4

    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        key: str | None = None,
        passphrase: str | None = None,
    ) -> None:
        """Connect to a host over SSH.

        Args:
            host: Remote hostname or IP address.
            port: SSH port (typically 22).
            username: SSH username.
            password: SSH password (also used for ``sudo -S`` when applicable).
            key: Optional PEM private key material as a string.
            passphrase: Optional passphrase for the private key.

        Returns:
            None
        """
        self.username = username
        self.password = password
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        pkey: paramiko.PKey | None = None
        if key is not None:
            pkey = paramiko.RSAKey.from_private_key(io.StringIO(key), password=passphrase)
        self.client.connect(host, port, username=username, password=password, pkey=pkey, timeout=self.TIMEOUT)

    def close(self) -> None:
        """Close the SSH session and release the client.

        Returns:
            None
        """
        if self.client is not None:
            self.client.close()
            self.client = None

    def execute(self, command: str, sudo: bool = False) -> dict[str, Any]:
        """Run a command on the remote host.

        Args:
            command: Shell command string to execute.
            sudo: If True, run via ``sudo``; password is fed on stdin when the
                user is not root and a password is set.

        Returns:
            dict: Keys ``out`` (stdout lines), ``err`` (stderr lines), and
            ``retval`` (integer exit status).
        """
        feed_password = False
        if sudo and self.username != "root":
            command = "sudo -S -p '' %s" % command
            feed_password = self.password is not None and len(self.password) > 0
        if self.client is None:
            raise ValueError("Failed to connect to the remote host")
        stdin, stdout, stderr = self.client.exec_command(command)
        if feed_password:
            stdin.write(self.password + "\n")
            stdin.flush()
        return {"out": stdout.readlines(), "err": stderr.readlines(), "retval": stdout.channel.recv_exit_status()}


def _open_ssh(hostname: str, username: str, password: str) -> paramiko.SSHClient:
    """Return a connected client using the same policy and connect pattern as other module call sites."""
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname, username=username, password=password)
    return ssh


def _ssh_exec_read(ssh: paramiko.SSHClient, command: str) -> tuple[str, int]:
    """Run ``command`` on an open session; return stripped decoded stdout and exit status."""
    _, stdout, _ = ssh.exec_command(command)
    text = stdout.read().decode()
    return text.strip(), stdout.channel.recv_exit_status()


def _first_192_168_ip_from_ip_addr_text(ip_addr_stdout: str) -> str:
    """Pick the first ``192.168.*`` IPv4 from ``ip addr``-style lines; empty string if none (avoids ``IndexError``)."""
    matches = re.findall(r"inet\s(192.168.\d+.\d+)", ip_addr_stdout)
    return matches[0] if matches else ""


def _ssh_ps_aux_rss_kb_sum(ssh: paramiko.SSHClient, name_substring: str) -> int:
    """Sum RSS (kB) from ``ps aux`` lines containing ``name_substring`` (fixed tokens such as ``python`` / ``sql`` only)."""
    out, _ = _ssh_exec_read(ssh, f"ps aux | grep '{name_substring}' | awk '{{print $6}}'")
    if not out:
        return 0
    return sum(int(x) for x in out.split())


def execute_confirm_wait(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorate a callable so it is invoked, then sleeps briefly.

    If the call raises ``TypeError`` (e.g. wrong arity), retries with no
    arguments.

    Args:
        func: Callable to wrap.

    Returns:
        The inner wrapper; calling it returns ``func`` after execution.
    """

    def inner(*args: Any, **kwargs: Any) -> Callable[..., Any]:
        """Invoke the wrapped ``func`` with optional ``*args`` and ``**kwargs``.

        Args:
            *args: Positional arguments forwarded to ``func``.
            **kwargs: Keyword arguments forwarded to ``func``.

        Returns:
            The wrapped ``func`` object after execution (not its return value).
        """
        try:
            func(*args, **kwargs)
            # dagster_logger.info(f"{args}, {kwargs} is done! ({func.__name__})")
        except TypeError:
            func()
            # dagster_logger.info(f"it's done! ({func.__name__})")
        time.sleep(0.05)
        return func

    return inner


def execute_script_with_cmd(script_name: str) -> str:
    """Execute a Python file like a script and log the result.

    Args:
        script_name: Path to the ``.py`` file to run via :func:`execfile`.

    Returns:
        String representation of the script's evaluated result (often
        uninformative; see :func:`execfile`).
    """
    output = execfile(script_name)
    dagster_logger.info(str(output))
    return str(output)


def execute_cmd_ubuntu_sudo(commands: list[str] | str) -> str | None:
    """Run a command with ``sudo -S`` using the cluster password from the environment.

    Uses ``cluster_server_0_password`` for sudo authentication.

    Args:
        commands: argv tokens as a list, or a single string split on whitespace.

    Returns:
        Standard output on success, or ``None`` on failure or if an exception
        is swallowed after logging.

    Raises:
        ValueError: If ``cluster_server_0_password`` is unset.
    """
    try:
        if isinstance(commands, str):
            commands = commands.split()

        password = os.getenv("cluster_server_0_password")
        if not password:
            raise ValueError("cluster_server_0_password environment variable must be set")

        result = subprocess.run(
            ["sudo", "-S"] + commands,
            input=password + "\n",
            capture_output=True,
            text=True,
            check=False,  # Don't raise on non-zero exit
        )

        if result.returncode == 0:
            if result.stdout:
                dagster_logger.info(f"Command output: {result.stdout}")
            return result.stdout
        else:
            dagster_logger.warning(f"Command failed: {result.stderr}")
            return None

    except Exception:
        dagster_logger.info(error_handling())
    return None


def execute_cmd_ubuntu_normal(commands: list[str] | str) -> str | None:
    """Run a shell command locally (``shell=True``) without sudo.

    Args:
        commands: Passed to ``subprocess.run``; may be a list or string.

    Returns:
        Captured stdout as a string on success, or ``None`` if the command
        failed or an exception occurred (errors are logged).
    """
    output_str = None
    try:
        output = subprocess.run(commands, shell=True, check=True, capture_output=True, text=True)

        # Decode the output and error from bytes to string
        # Print the output and error
        if output.stdout:
            output_str = output.stdout
            dagster_logger.info(f"Command output: {output_str}")
        if output.stderr:
            dagster_logger.warning(f"Command stderr: {output.stderr}")
    except Exception:
        dagster_logger.info(error_handling())
    return output_str


def execfile(
    filepath: str,
    globals: dict[str, Any] | None = None,
    locals: dict[str, Any] | None = None,
) -> None:
    """Execute a Python file in the given namespace (similar to historical Python 2 ``execfile``).

    Sets ``__file__`` and ``__name__`` in ``globals`` before execution.

    Args:
        filepath: Path to the Python source file.
        globals: Optional globals dict (defaults to ``{}``).
        locals: Optional locals dict passed to ``exec`` (defaults to same as
            ``globals`` when omitted at call site behavior matches ``exec``).

    Returns:
        None. Side effects occur in ``globals`` / ``locals``.
    """
    if globals is None:
        globals = {}
    if locals is None:
        locals = globals
    globals.update(
        {
            "__file__": filepath,
            "__name__": "__main__",
        }
    )
    with open(filepath, "rb") as file:
        exec(compile(file.read(), filepath, "exec"), globals, locals)
    return None


def kill_remote_ubuntu_process_ids(hostname: str, username: str, password: str, pid: Union[str, Iterable[str]]) -> None:
    """Force-kill remote processes by PID over SSH (``kill -9``).

    Args:
        hostname: Remote host.
        username: SSH user.
        password: SSH password.
        pid: One PID as string, whitespace-separated PIDs as string, or iterable
            of PID strings.

    Returns:
        None: Output is printed; SSH connection is not explicitly closed.
    """
    if isinstance(pid, str):
        pid = pid.split()
    ssh = _open_ssh(hostname, username, password)
    try:
        python_command = "sudo kill -9 " + " ".join(pid)
        print(python_command)
        py_output, _ = _ssh_exec_read(ssh, python_command)
        print(py_output)
        print("remote killing of pids done")
    finally:
        ssh.close()


def get_remote_process_ids_ubuntu(hostname: str, username: str, password: str, search_string: str = "") -> list[str]:
    """List PIDs on a remote host whose ``ps aux`` line matches ``search_string``.

    Args:
        hostname: Remote host.
        username: SSH user.
        password: SSH password.
        search_string: Substring matched in ``ps aux`` (excludes defunct and
            the ``grep`` process itself).

    Returns:
        List of PID strings for matching processes.
    """
    ssh = _open_ssh(hostname, username, password)
    try:
        list_command = f"ps aux | grep '{search_string}' | grep -v '<defunct>' | grep -v 'grep'"
        process_output, _ = _ssh_exec_read(ssh, list_command)
        print(process_output)

        pid_command = f"ps aux | grep '{search_string}' | grep -v '<defunct>' | grep -v 'grep' | awk '{{print $2}}'"
        pid_output, _ = _ssh_exec_read(ssh, pid_command)
        return pid_output.split()
    finally:
        ssh.close()


def _gpu_metrics_unavailable() -> dict[str, Any]:
    """Return one consistent "no GPU data" row for DB alignment.

    Needed so :func:`_nvidia_gpu_summary`, :func:`_nvidia_gpu_summary_from_csv_text`, and remote collection
    all emit identical keys and sentinel values without duplicating seven literals.
    """
    return {
        "gpu_present": False,
        "gpu_count": 0,
        "gpu_utilization_max_pct": float("nan"),
        "gpu_mem_used_total_MB": float("nan"),
        "gpu_mem_total_MB": float("nan"),
        "gpu_temp_max_C": float("nan"),
        "gpu_names_json": "[]",
    }


def _safe_float_metric(value: str) -> float | None:
    """Parse a single ``nvidia-smi`` CSV field; ``None`` means skip or treat as missing (N/A, unsupported, NaN).

    Centralizes driver quirks so :func:`_nvidia_gpu_summary_from_csv_text` stays linear and testable.
    """
    s = value.strip()
    if not s or s.upper() in ("N/A", "[N/A]", "[NOT SUPPORTED]"):
        return None
    try:
        x = float(s)
        if math.isnan(x):
            return None
        return x
    except ValueError:
        return None


def _nvidia_gpu_summary_from_csv_text(csv_text: str) -> dict[str, Any]:
    """Turn raw ``nvidia-smi`` CSV into aggregated metrics.

    Needed because both local :func:`_nvidia_gpu_summary` and :func:`get_remote_stats_ubuntu` must parse the
    same format; a single parser avoids drift between hosts.
    """
    rows: list[dict[str, Any]] = []
    for line in csv_text.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 6:
            continue
        idx_s, name, util_s, mem_used_s, mem_total_s, temp_s = parts[:6]
        try:
            index = int(float(idx_s.strip()))
        except ValueError:
            continue
        util = _safe_float_metric(util_s)
        mem_used = _safe_float_metric(mem_used_s)
        mem_total = _safe_float_metric(mem_total_s)
        temp = _safe_float_metric(temp_s)
        if util is None or mem_used is None or mem_total is None:
            continue
        rows.append(
            {
                "index": index,
                "name": name,
                "utilization_pct": util,
                "memory_used_MB": mem_used,
                "memory_total_MB": mem_total,
                "temperature_C": temp,
            }
        )
    if not rows:
        return _gpu_metrics_unavailable()
    utils = [r["utilization_pct"] for r in rows]
    mem_used_sum = sum(r["memory_used_MB"] for r in rows)
    mem_total_sum = sum(r["memory_total_MB"] for r in rows)
    temps = [r["temperature_C"] for r in rows if r["temperature_C"] is not None]
    return {
        "gpu_present": True,
        "gpu_count": len(rows),
        "gpu_utilization_max_pct": max(utils),
        "gpu_mem_used_total_MB": round(mem_used_sum, 2),
        "gpu_mem_total_MB": round(mem_total_sum, 2),
        "gpu_temp_max_C": max(temps) if temps else float("nan"),
        "gpu_names_json": json.dumps([r["name"] for r in rows]),
    }


def _nvidia_gpu_summary() -> dict[str, Any]:
    """Run ``nvidia-smi`` locally and return the same flat dict as remote stats (timeouts / errors → unavailable row)."""
    try:
        out = subprocess.check_output(
            list(_NVIDIA_SMI_GPU_CSV_ARGV),
            text=True,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return _gpu_metrics_unavailable()
    return _nvidia_gpu_summary_from_csv_text(out)


def _sum_rss_mb_by_name_substrings(substrings: tuple[str, ...]) -> float:
    """Sum RSS in MB for processes matching substrings (used only by :func:`pc_usage`; remote still uses ``ps aux``).

    ``psutil`` avoids a shell and matches the intent of the remote ``grep``/``awk`` sums for comparable keys.
    """
    total_bytes = 0
    subs_l = tuple(s.lower() for s in substrings)
    for proc in psutil.process_iter(["pid", "name", "memory_info", "cmdline"]):
        try:
            info = proc.info
            name = (info.get("name") or "").lower()
            cmdline = info.get("cmdline") or []
            cmd_joined = " ".join(str(c) for c in cmdline).lower()
            if not any(s in name or s in cmd_joined for s in subs_l):
                continue
            mi = info.get("memory_info")
            if mi is None:
                continue
            total_bytes += int(mi.rss)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return total_bytes / (1024.0**2)


def _pc_network_address_preferred() -> str:
    """Pick a stable LAN-style IPv4 for ``pc_network_address`` without shelling out to ``ip``.

    Mirrors the remote preference for ``192.168.*`` first so local and remote rows stay comparable when possible.
    """
    candidates: list[str] = []
    try:
        for _iface, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family != socket.AF_INET:
                    continue
                ip = addr.address
                if ip.startswith("127."):
                    continue
                if ip.startswith("192.168."):
                    return ip
                candidates.append(ip)
    except OSError:
        return ""
    return candidates[0] if candidates else ""


def _pc_os_description() -> str:
    """Human-readable OS string for locals (``/etc/os-release`` via :func:`platform.freedesktop_os_release`)."""
    try:
        rel = platform.freedesktop_os_release()
        return str(rel.get("PRETTY_NAME") or rel.get("NAME") or platform.platform())
    except (OSError, AttributeError):
        return platform.platform()


def pc_usage() -> dict[str, Any]:
    """Collect local CPU, memory, OS, network, and optional NVIDIA GPU stats (``nvidia-smi``).

    Exists as the local counterpart to :func:`get_remote_stats_ubuntu` so callers can ``to_sql`` one schema from
    either path without branching on column names.

    Returns:
        Flat dict aligned with :func:`get_remote_stats_ubuntu` (same keys for shared DB rows), plus any
        ``memory_*_MB`` fields produced from :func:`psutil.virtual_memory`.
    """
    vm = psutil.virtual_memory()
    vm_map = vm._asdict()
    output_dict: dict[str, Any] = {}
    for key, val in vm_map.items():
        if val is None:
            continue
        if key == "percent":
            output_dict["memory_percent_MB"] = float(val)
            continue
        if isinstance(val, (int, float)):
            output_dict["memory_" + key + "_MB"] = round(float(val) / (1024.0**2), 4)

    cpu_pct = float(psutil.cpu_percent(interval=0.1))
    cpu_cores = int(psutil.cpu_count(logical=True) or 0)
    freq = psutil.cpu_freq()
    cpu_freq = int(freq.current) if freq and freq.current else 0

    model = ""
    try:
        with open("/proc/cpuinfo", encoding="utf-8") as f:
            for line in f:
                if line.lower().startswith("model name"):
                    model = line.split(":", 1)[1].strip()
                    break
    except OSError:
        model = platform.processor() or ""

    python_mb = _sum_rss_mb_by_name_substrings(("python",))
    sql_mb = _sum_rss_mb_by_name_substrings(("sql",))

    output_dict.update(
        {
            "cpu_pct": cpu_pct,
            "cpu_cores": cpu_cores,
            "cpu_freq": cpu_freq,
            "pc_network_address": _pc_network_address_preferred(),
            "pc_os": _pc_os_description(),
            "pc_cpu": model,
            "python_memory_usage_GB": float(np.round(python_mb / 1024.0, 2)),
            "sql_memory_usage_GB": float(np.round(sql_mb / 1024.0, 2)),
            "query_time": str(datetime.datetime.now()),
        }
    )
    output_dict.update(_nvidia_gpu_summary())
    return output_dict


def get_remote_stats_ubuntu(hostname: str, username: str, password: str) -> dict[str, Any]:
    """Collect CPU, memory, OS, network, and optional NVIDIA GPU stats from a remote Ubuntu host via SSH.

    Args:
        hostname: Remote host.
        username: SSH user.
        password: SSH password.

    Returns:
        Flat dict of metrics (memory fields, ``cpu_pct``, ``python_memory_usage_GB``,
        ``sql_memory_usage_GB``, ``query_time``, and the same GPU keys as :func:`pc_usage`, etc.).
    """
    ssh = _open_ssh(hostname, username, password)
    try:
        memory_command = "free -m | awk 'NR==2{print $2,$3,$4,$5,$6,$7}'"
        mem_output, _ = _ssh_exec_read(ssh, memory_command)
        total, used, free, shared, buff_cache, available = mem_output.split()

        cpu_command = "top -bn1 | grep '%Cpu(s)' | awk '{print $2 + $4}'"
        cpu_out, _ = _ssh_exec_read(ssh, cpu_command)
        cpu_usage = float(cpu_out)

        mem = {
            "Total": int(total),
            "Used": int(used),
            "Free": int(free),
            "Available": int(available),
            "Percent": int(int(used) / int(total)),
        }

        python_memory_usage_kB = _ssh_ps_aux_rss_kb_sum(ssh, "python")
        sql_memory_usage_kB = _ssh_ps_aux_rss_kb_sum(ssh, "sql")

        cpu_cores_out, _ = _ssh_exec_read(ssh, "nproc")
        cpu_cores_output = int(cpu_cores_out)

        cpu_freq_command = """ lscpu | grep "MHz" """
        cpu_freq_raw, _ = _ssh_exec_read(ssh, cpu_freq_command)
        cpu_freq_output = int(re.findall(r"(\d+)(CPU)?", cpu_freq_raw)[0][0])

        os_command = """lsb_release -a | grep "Description" """
        os_raw, _ = _ssh_exec_read(ssh, os_command)
        os_output = str(os_raw).split(":")[1].strip()

        cpu_model_raw, _ = _ssh_exec_read(ssh, "lscpu | grep 'Model name'")
        cpu_model_output = cpu_model_raw.split(":")[1].strip()

        ip_raw, _ = _ssh_exec_read(ssh, "ip addr show | grep 'inet '")
        ip_output = _first_192_168_ip_from_ip_addr_text(ip_raw)

        nv_text, nv_exit = _ssh_exec_read(ssh, " ".join(_NVIDIA_SMI_GPU_CSV_ARGV))
    finally:
        ssh.close()
    output_dict: dict[str, Any] = {"memory_" + k.lower() + "_MB": v for k, v in mem.items()}
    output_dict.update(
        {
            "cpu_pct": cpu_usage,  # gives a single float value
            "cpu_cores": cpu_cores_output,
            "cpu_freq": cpu_freq_output,
            "pc_network_address": ip_output,
            "pc_os": os_output,
            "pc_cpu": cpu_model_output,
            "python_memory_usage_GB": float(np.round(python_memory_usage_kB / 1024**2, 2)),
            "sql_memory_usage_GB": float(np.round(sql_memory_usage_kB / 1024**2, 2)),
            "query_time": str(datetime.datetime.now()),
        }
    )
    if nv_exit == 0 and nv_text.strip():
        output_dict.update(_nvidia_gpu_summary_from_csv_text(nv_text))
    else:
        output_dict.update(_gpu_metrics_unavailable())
    return output_dict


def move_file_to_remote_pc(
    hostname: str,
    username: str,
    password: str,
    local_path: str = "/etc/dask/dask.yaml",
    remote_path: str = "/home/jay/PycharmProjects/home/dask.yaml",
) -> None:
    """Upload a local file to a remote path via SFTP; optionally configure ``/etc/dask``.

    When ``local_path`` is the default dask config path, also runs remote
    ``sudo`` commands to prepare ``/etc/dask/`` via :class:`SshClient`.

    Args:
        hostname: Remote host.
        username: SSH user.
        password: SSH password.
        local_path: Local file to upload.
        remote_path: Destination path on the remote host.

    Returns:
        None
    """
    ssh = _open_ssh(hostname, username, password)
    try:
        sftp = ssh.open_sftp()
        try:
            sftp.put(localpath=local_path, remotepath=remote_path)
            # check that file is there
            sftp.stat(remote_path)
            print("File upload complete.")
        except Exception as e:
            print(f"Upload failed: {e}")
        finally:
            sftp.close()
    finally:
        ssh.close()
    if local_path == "/etc/dask/dask.yaml":
        client = SshClient(host=hostname, port=22, username=username, password=password)
        try:
            ret = client.execute(command="""sudo mkdir /etc/dask/""", sudo=True)
            print("  ".join(ret["out"]), "  E ".join(ret["err"]), ret["retval"])
            ret = client.execute(command="""sudo chmod -R 777 /etc/dask/""", sudo=True)
            print("  ".join(ret["out"]), "  E ".join(ret["err"]), ret["retval"])
            ret = client.execute(
                command="""sudo mv /home/jay/PycharmProjects/jragbeer_home/dask.yaml /etc/dask/dask.yaml""", sudo=True
            )
            print("  ".join(ret["out"]), "  E ".join(ret["err"]), ret["retval"])

        finally:
            client.close()
            dagster_logger.info("Done")


def give_write_permission_to_folder(folder_path: str) -> None:
    """Recursively grant world read/write/execute on a path via sudo.

    Args:
        folder_path: Directory (or path) passed to ``chmod -R 777``.

    Returns:
        None
    """
    execute_cmd_ubuntu_sudo(f"sudo chmod -R 777 {folder_path}")


def create_yaml_from_dict(input_dict: dict[Any, Any], name_of_yaml: str | None = None) -> str:
    """Serialize ``input_dict`` to YAML, optionally writing to a file.

    Args:
        input_dict: Mapping to dump.
        name_of_yaml: If set, YAML is written to this path; otherwise only the
            string is built.

    Returns:
        YAML document as a string.
    """
    yamll = yaml.dump(input_dict, allow_unicode=True)
    if name_of_yaml:
        with open(name_of_yaml, "w", encoding="utf-8") as ff:
            ff.write(yamll)
    if yamll is None:
        raise ValueError("Failed to dump YAML")
    return yamll


def update_repo_on_remote_machine(hostname: str, username: str, password: str, repo: str) -> None:
    """SSH to a host and run ``git restore .`` and ``git pull`` in a project directory.

    Args:
        hostname: Remote host address.
        username: SSH user.
        password: SSH password.
        repo: Repository folder name under ``/home/jay/PycharmProjects/``.

    Returns:
        None
    """
    client = SshClient(host=hostname, port=22, username=username, password=password)
    try:
        cmd = f"""cd /home/jay/PycharmProjects/{repo}/; git restore . ; git pull"""
        ret = client.execute(
            command=cmd,
        )
        print("  ".join(ret["out"]), "  E ".join(ret["err"]), ret["retval"])
    finally:
        client.close()
