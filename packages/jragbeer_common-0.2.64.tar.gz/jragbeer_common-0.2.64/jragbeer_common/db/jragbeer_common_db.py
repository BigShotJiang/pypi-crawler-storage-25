import datetime
import os
import subprocess

import sqlalchemy
from sqlalchemy import inspect, text
from tqdm import tqdm

from ..azure.jragbeer_common_azure import adls_upload_file
from ..common.jragbeer_common_data_eng import dagster_logger, data_path, error_handling, today
from ..dask.jragbeer_common_dask import process_list_with_dask
from ..ubuntu.jragbeer_common_ubuntu import execute_cmd_ubuntu_normal, execute_cmd_ubuntu_sudo


# MYSQL
def mysql_create_database(
    host: str,
    port: int,
    username: str | None,
    password: str | None,
    database_name: str,
) -> bool:
    """Create a MySQL database using the ``mysqladmin`` command.

    Args:
        host: MySQL server hostname or IP address.
        port: MySQL server port.
        username: MySQL username for authentication.
        password: MySQL password for authentication.
        database_name: Name of the database to create.

    Returns:
        ``True`` if the database is created successfully, ``False`` otherwise.
    """
    try:
        # Construct the mysqladmin command to create the database
        cmd = [
            "/bin/mysqladmin",
            f"--host={host}",
            f"--port={port}",
            f"--user={username}",
            f"--password={password}",
            "create",
            database_name,
        ]

        # Use subprocess.Popen to execute the command
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()

        if process.returncode == 0:
            print(f"Database '{database_name}' created successfully.")
            return True
        else:
            print(f"Error creating database '{database_name}': {stderr.decode()}")
            return False
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return False


def mysql_backup_database(database_name: str) -> None:
    """Dump a MySQL database to SQL under the configured ``data_path``.

    Uses credentials from ``local_db_address``, ``local_db_username``, and
    ``local_db_password`` environment variables and runs the dump via
    :func:`~jragbeer_common.ubuntu.jragbeer_common_ubuntu.execute_cmd_ubuntu_sudo`.

    Args:
        database_name: Database to back up.

    Returns:
        None
    """
    dagster_logger.info(f"{database_name} dump starting now")
    t = [
        r"mysqldump",
        rf"-h{os.getenv('local_db_address')}",
        rf"-u{os.getenv('local_db_username')}",
        rf"-p{os.getenv('local_db_password')}",
        rf"{database_name}",
        rf"--result-file={data_path + database_name}_dump_latest.sql",
    ]
    print(t)
    execute_cmd_ubuntu_sudo(t)
    dagster_logger.info(f"{database_name} complete in {datetime.datetime.now() - today} ")


def mysql_import_dump(
    host: str,
    port: int,
    username: str | None,
    password: str | None,
    database_name: str,
    dump_file_path: str,
) -> bool:
    """Import a MySQL dump file into an existing database.

    Args:
        host: MySQL server hostname or IP address.
        port: MySQL server port.
        username: MySQL username for authentication.
        password: MySQL password for authentication.
        database_name: Target database name.
        dump_file_path: Path to the ``.sql`` dump file to import.

    Returns:
        ``True`` if the import succeeds, ``False`` on subprocess failure.
    """
    try:
        # Construct the MySQL command to import the dump
        cmd = [
            "/bin/mysql",
            f"--host={host}",
            f"--port={port}",
            f"--user={username}",
            f"--password={password}",
            f"--database={database_name}",
            "--execute=source " + dump_file_path,
        ]

        # Execute the command
        subprocess.run(cmd, check=True, shell=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error importing MySQL dump: {e}")
        return False


def mysql_restore_databases() -> None:
    """Create and import a fixed set of finance-related MySQL databases from latest dumps.

    Iterates over predefined database names, attempts ``mysql_create_database`` and
    ``mysql_import_dump`` for each, and logs progress. Failures for individual
    databases are swallowed per inner ``try``/``except`` blocks.

    Returns:
        None
    """
    for finance_db in [
        "finance_1mins",
        "finance_5mins",
        "finance_daily",
        "finance_fundamental_data",
        "finance_standard",
        "gov",
        "home",
    ]:
        try:
            success = mysql_create_database(
                host="localhost",
                port=3306,
                username=os.getenv("local_db_username"),
                password=os.getenv("local_db_password"),
                database_name=finance_db,
            )
            if success:
                print(f"Database '{finance_db}' created successfully.")
            else:
                print(f"Failed to create database '{finance_db}'.")
        except Exception:
            pass
        try:
            dagster_logger.info(f"{finance_db} restore starting now")
            success = mysql_import_dump(
                host="localhost",
                port=3306,
                username=os.getenv("local_db_username"),
                password=os.getenv("local_db_password"),
                database_name=finance_db,
                dump_file_path=f"{data_path.replace('/', '//') + finance_db}_dump_latest.sql",
            )
            dagster_logger.info(f"{finance_db} complete in {datetime.datetime.now() - today} ")
            if success:
                print(f"Database '{finance_db}' successfully imported.")
            else:
                print(f"Failed to import database '{finance_db}'.")
        except Exception:
            pass


# POSTGRES
def postgres_query_to_remove_duplicate_rows(table_name: str, conn_string: str) -> None:
    """Build and print a PostgreSQL CTE query to delete duplicate rows (not executed here).

    Args:
        table_name: Table whose duplicates should be removed (embedded in SQL).
        conn_string: Connection string printed alongside the query for debugging.

    Returns:
        None: Only prints ``sql_query`` and ``conn_string``.
    """
    sql_query = f"""
            WITH cte AS (
            SELECT
                ctid,  -- PostgreSQL's unique row identifier
                ROW_NUMBER() OVER (PARTITION BY * ORDER BY ctid) AS rn
            FROM {table_name}
        )
        DELETE FROM {table_name}
        WHERE ctid IN (
            SELECT ctid FROM cte WHERE rn > 1
        );
    """
    print(sql_query)
    print(conn_string)


def pg_restore_database(sql_file_path: str, database_name: str) -> None:
    """Load a ``.sql`` file into PostgreSQL using ``psql`` via sudo.

    Raises if the SQL file path does not exist. Uses ``local_db_username``,
    ``local_db_password``, ``local_db_address``, and ``local_db_port`` from the
    environment (with fallbacks for user/host/port).

    Args:
        sql_file_path: Path to the SQL script on disk.
        database_name: PostgreSQL database name to connect to.

    Returns:
        None

    Raises:
        FileNotFoundError: If ``sql_file_path`` does not exist.
    """
    if not os.path.exists(sql_file_path):
        raise FileNotFoundError(f"SQL file not found: {sql_file_path}")

    user = os.getenv("local_db_username") or "username"
    password = os.getenv("local_db_password") or "password"
    host = os.getenv("local_db_address") or "localhost"
    port = os.getenv("local_db_port") or "5432"
    print(host)

    # Step 1: Load the SQL file
    print(f"Running SQL file '{sql_file_path}' into database '{database_name}'...")
    run_sql_cmd = [
        rf"PGPASSWORD={password}",
        "psql",
        "-U",
        user,
        "-h",
        host,
        "-p",
        str(port),
        "-d",
        database_name,
        "-f",
        sql_file_path,
    ]
    execute_cmd_ubuntu_sudo(run_sql_cmd)
    print("SQL file executed successfully.")


def pg_backup_database(
    database_name: str,
    host: str,
    password: str,
    user: str,
    port: str,
    file_location: str = "/home/jay/PycharmProjects/jragbeer_home/data/",
) -> None:
    """Create a PostgreSQL SQL dump with ``pg_dump`` (sudo, then normal shell fallback).

    Output path is ``{file_location}pg_{database_name}_dump_latest.sql``. Start
    and completion are logged via ``dagster_logger``.

    Args:
        database_name: Database to dump.
        host: PostgreSQL server host.
        password: Password for ``PGPASSWORD`` when invoking ``pg_dump``.
        user: PostgreSQL role name.
        port: Server port as string.
        file_location: Directory prefix for the dump file.

    Returns:
        None
    """
    dagster_logger.info(f"{database_name} dump starting now")

    t = [
        rf"PGPASSWORD={password}",
        "pg_dump",
        rf"-h{host}",
        rf"-U{user}",
        rf"-d{database_name}",
        rf"-p{port}",
        rf"-f{file_location}pg_{database_name}_dump_latest.sql",
    ]
    dagster_logger.info(t)
    output = execute_cmd_ubuntu_sudo(t)
    if not output:
        dagster_logger.info(f"{database_name} dump failed with SUDO.")
        dagster_logger.info(error_handling())
        execute_cmd_ubuntu_normal(t)
    dagster_logger.info(f"{database_name} completed in {datetime.datetime.now() - today} ")


def sql_table_drop_duplicates_single(new_engine: sqlalchemy.Engine, table_name: str, exclude: str = "") -> None:
    """Deduplicate rows in one table using heuristics for date/volume/sort columns.

    Inspects columns, builds a ``ROW_NUMBER()`` delete statement, and runs it
    in a transaction on ``new_engine``.

    Args:
        new_engine: Connected SQLAlchemy engine for the target database.
        table_name: Table to deduplicate.
        exclude: Optional column name used in ``ORDER BY`` when present.

    Returns:
        None
    """
    # Inspect table columns
    inspector = inspect(new_engine)
    columns = [col["name"] for col in inspector.get_columns(table_name)]

    # Detect date and volume columns
    date_col = next((c for c in ["datetime", "Datetime", "date", "Date"] if c in columns), None)
    vol_col = "volume" if "volume" in columns else None

    # Build ORDER BY clause
    order_cols = []
    if date_col:
        order_cols.append(f"{date_col} DESC")
    if vol_col:
        order_cols.append(f"{vol_col} DESC")
    if exclude and exclude in columns:
        order_cols.append(f"{exclude} DESC")
    order_by = ", ".join(order_cols) if order_cols else ""

    # Build PARTITION BY columns (all columns except sorting columns)
    partition_cols = [
        col
        for col in columns
        if col
        not in (
            [date_col, vol_col, exclude]
            if date_col and vol_col and exclude
            else [date_col]
            if date_col
            else [vol_col]
            if vol_col
            else [exclude]
            if exclude
            else []
        )
    ]
    partition_by = ", ".join(partition_cols) if partition_cols else "1"

    dialect_name = new_engine.dialect.name
    if dialect_name == "sqlite":
        phys_select = f"{table_name}.rowid AS __jrc_dedupe_phys"
        phys_match = f"r.__jrc_dedupe_phys = {table_name}.rowid"
    elif dialect_name == "postgresql":
        phys_select = f"{table_name}.ctid AS __jrc_dedupe_phys"
        phys_match = f"r.__jrc_dedupe_phys = {table_name}.ctid"
    else:
        raise NotImplementedError(
            f"sql_table_drop_duplicates_single only supports sqlite and postgresql (got {dialect_name!r})."
        )

    # Use ROW_NUMBER() for deduplication; physical row id must appear in the CTE
    # (SQLite ``SELECT *`` does not expose ``rowid``; PostgreSQL uses ``ctid``).
    sql = f"""
    WITH ranked AS (
        SELECT {table_name}.*, {phys_select},
               ROW_NUMBER() OVER (PARTITION BY {partition_by} ORDER BY {order_by}) AS rn
        FROM {table_name}
    )
    DELETE FROM {table_name}
    WHERE EXISTS (
        SELECT 1
        FROM ranked r
        WHERE r.rn > 1
          AND {phys_match}
    );
    """

    # Execute in a transaction (atomic)
    with new_engine.begin() as conn:
        conn.execute(text(sql))

    print(f"{table_name} deduplicated. Sorted by: {order_by if order_by else 'none'}")


def sql_table_drop_duplicates(
    list_of_table_names: list[str],
    connection_string: str | None = None,
    database: str | None = None,
) -> None:
    """Run :func:`sql_table_drop_duplicates_single` for each table name.

    Args:
        list_of_table_names: Tables to deduplicate, in order.
        connection_string: Full SQLAlchemy URL. If omitted, ``database`` must
            be set to build a URL from environment variables.
        database: PostgreSQL database name when ``connection_string`` is omitted.

    Returns:
        None

    Raises:
        ValueError: If neither ``connection_string`` nor ``database`` is provided.
    """
    if connection_string:
        db_url = connection_string
    else:
        if not database:
            raise ValueError("either connection_string or database must be provided.")
        db_url = f"postgresql://{os.getenv('local_db_username')}:{os.getenv('local_db_password')}@{os.getenv('local_db_address')}:{os.getenv('local_db_port')}/{database}"
    new_engine = sqlalchemy.create_engine(db_url)
    print(new_engine)
    for ii, table_name in enumerate(tqdm(list_of_table_names)):
        print(ii, table_name)
        if ii % 25 == 0:
            dagster_logger.info(f"Dropping Duplicates on {table_name}")
        try:
            sql_table_drop_duplicates_single(new_engine, table_name)
        except Exception:
            dagster_logger.info(error_handling())


def db_drop_duplicates(database: str = "5mins", num_splits: int = 4) -> None:
    """Deduplicate all tables in a database using Dask-distributed work.

    Args:
        database: PostgreSQL database name.
        num_splits: Number of partitions passed to ``process_list_with_dask``.

    Returns:
        None
    """
    # print time this function starts
    now = datetime.datetime.now()
    dagster_logger.info(now)
    db_url = f"postgresql://{os.getenv('local_db_username')}:{os.getenv('local_db_password')}@{os.getenv('local_db_address')}:{os.getenv('local_db_port')}/{database}"
    # flatten list of tables
    list_of_tables = get_all_sql_table_names(connection_string=db_url)
    process_list_with_dask(
        list_of_tables, sql_table_drop_duplicates, num_splits, "DISTRIBUTED", priority=2, kwargs={"database": database}
    )


def copy_backup_to_cloud(database_name: str, local_backup_folder: str) -> None:
    """Upload a PostgreSQL dump file for ``database_name`` to Azure Blob Storage.

    Wraps ``adls_upload_file`` with
    a conventional blob path under ``database_backups/``.

    Args:
        database_name: Logical database name used in blob key construction.
        local_backup_folder: Directory containing ``pg_{database_name}_dump_latest.sql``.

    Returns:
        None
    """
    dagster_logger.info(f"{database_name} migrating to BLOB")
    adls_upload_file(
        local_backup_folder + f"pg_{database_name}_dump_latest.sql", f"database_backups/{database_name}_dump_latest.sql"
    )
    dagster_logger.info(f"{database_name} migration to BLOB complete.")


def backup_databases(
    databases: list[str],
    local_backup_folder: str,
    db: str = "postgres",
    host: str | None = None,
    port: int | str | None = None,
) -> None:
    """Back up each named database, then upload the dump to Azure.

    For ``mysql``, calls :func:`mysql_backup_database`; otherwise uses
    :func:`pg_backup_database` and :func:`copy_backup_to_cloud`.

    Args:
        databases: Database names to back up.
        local_backup_folder: Output directory for dump files.
        db: ``'mysql'`` or ``'postgres'`` (default).
        host: PostgreSQL host; defaults from ``local_db_address`` or ``localhost``.
        port: PostgreSQL port; defaults from ``local_db_port`` or ``5432``.

    Returns:
        None
    """
    if not host:
        host = os.getenv("local_db_address") or "localhost"
    password = os.getenv("local_db_password") or "password"
    user = os.getenv("local_db_username") or "username"
    if not port:
        port = os.getenv("local_db_port") or "5432"
    else:
        port = str(port)

    for db_name in databases:
        if db == "mysql":
            mysql_backup_database(db_name)
        else:
            pg_backup_database(
                db_name, host=host, password=password, user=user, port=port, file_location=local_backup_folder
            )
        copy_backup_to_cloud(db_name, local_backup_folder)


def get_all_sql_table_names(
    user: str | None = None,
    hostname: str | None = None,
    password: str | None = None,
    port: str | int | None = None,
    database: str | None = None,
    connection_string: str | None = None,
) -> list[str]:
    """Return all table names visible to SQLAlchemy reflection for a database.

    Args:
        user: PostgreSQL username (required with hostname/password/port/database
            when ``connection_string`` is omitted).
        hostname: Database host.
        password: Database password.
        port: Database port.
        database: Database name.
        connection_string: Full SQLAlchemy URL; if set, other connection args
            are ignored.

    Returns:
        Sorted list of reflected table name strings.

    Raises:
        ValueError: If ``connection_string`` is omitted and any of user, hostname,
            password, port, or database is missing.
    """
    if connection_string:
        db_url = connection_string
    else:
        # Build the database URL
        if not all([user, hostname, password, port, database]):
            raise ValueError(
                f"Not all of user={user}, hostname={hostname}, password={password}, port={port}, database={database} are filled."
            )
        db_url = f"postgresql://{user}:{password}@{hostname}:{port}/{database}"

    # Create a SQLAlchemy engine
    engine = sqlalchemy.create_engine(db_url)

    # Reflect the tables
    metadata = sqlalchemy.MetaData()
    metadata.reflect(bind=engine)

    # Get the table names
    table_names = list(metadata.tables.keys())

    # Close the engine connection
    engine.dispose()
    return table_names
