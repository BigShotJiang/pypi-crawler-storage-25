"""Lightweight checks that optional container tooling is usable (integration only)."""

from __future__ import annotations

import docker
import pytest

from .fixtures.postgresql import PostgreSQLContainer


@pytest.mark.integration
def test_docker_daemon_ping() -> None:
    client = docker.from_env()
    client.ping()


def test_postgresql_container_is_running(postgresql_container: PostgreSQLContainer):
    """Test that PostgreSQL container is properly running.

    Verifies the container is up, has correct connection details, and is
    accessible on the expected port.

    Args:
        postgresql_container: PostgreSQL container fixture.
    """
    assert postgresql_container is not None
    assert postgresql_container["host"] == "127.0.0.1"
    assert isinstance(postgresql_container["port"], int)
    assert postgresql_container["username"] == "devuser"
    assert postgresql_container["password"] is not None  # pragma: allowlist secret

    # Verify container is actually running
    client = docker.from_env()
    container_name = f"jragbeer-common-test-postgresql-{postgresql_container['port']}"
    container = client.containers.get(container_name)
    assert container.status == "running"
