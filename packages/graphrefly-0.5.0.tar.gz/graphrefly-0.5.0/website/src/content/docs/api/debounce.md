---
title: 'debounce'
description: 'Emit the latest upstream ``DATA`` only after ``seconds`` of silence; flush on ``COMPLETE``.'
---

Emit the latest upstream ``DATA`` only after ``seconds`` of silence; flush on ``COMPLETE``.

Timer is cancelled on upstream ``ERROR`` or unsubscribe.

## Signature

```python
def debounce(seconds: float) -> PipeOperator
```

## Parameters

| Parameter | Description |
|-----------|-------------|
| `seconds` | Silence window in seconds; timer resets on each upstream ``DATA``. |

## Returns

A unary pipe operator ``(Node) -&gt; Node``.

## Basic Usage

```python
from graphrefly import state, pipe
from graphrefly.extra.tier2 import debounce
src = state(0)
out = pipe(src, debounce(0.05))
```
