def example_utility() -> str:
    """Example utility function.
    
    Returns:
        A greeting string.
    """
    return "Hello from prototype utils v2!"
