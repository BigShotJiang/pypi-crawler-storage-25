import json
from collections.abc import Collection
from urllib.parse import urlencode

from django.http import (
    HttpResponseBadRequest,
    HttpResponseForbidden,
    HttpResponseNotAllowed,
    StreamingHttpResponse,
)
from django.middleware.csrf import get_token
from django.shortcuts import render

from .events import iter_eval_events

EVAL_PARAM = "eval_path"
ARGS_PARAM = "eval_args"


def generate_eval_url(eval_path: str, *args: dict) -> str:
    """Generate a query-string URL for one eval path and argument sets."""
    pairs = [(EVAL_PARAM, eval_path)]
    for kwargs in args:
        # Callers may pass malformed arguments; only dict kwargs can be encoded.
        if not isinstance(kwargs, dict):
            raise TypeError("eval arguments must be a dictionary")
        pairs.append((
            ARGS_PARAM,
            json.dumps(kwargs, sort_keys=True, separators=(",", ":")),
        ))
    return "?" + urlencode(pairs)


def _input_value(value) -> str:
    # Strings should stay unquoted in text inputs.
    if isinstance(value, str):
        return value
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _value_type(value) -> str:
    # Strings should stay strings, even when they look like JSON values.
    if isinstance(value, str):
        return "string"

    # Bool must be checked before number because bool subclasses int.
    if isinstance(value, bool):
        return "boolean"

    # Number inputs should post numbers back after edits.
    if isinstance(value, int | float):
        return "number"

    return "json"


async def handle_eval_request(request, *, allowed_paths: Collection[str]):
    """Render the eval runner page on GET or publish one eval run on POST.

    Use this from a host Django view::

        return await handle_eval_request(
            request,
            allowed_paths={"myapp.evals.some_eval"},
        )

    The request should include an ``eval_path`` query parameter. It must match
    one of the dotted paths in ``allowed_paths``. Use ``generate_eval_url`` to
    create URLs.

    All eval arguments are passed to the eval function as keyword arguments.
    Multiple argument sets create separate SSE-backed panels.

    GET renders an HTML page. Browser JavaScript starts each eval run with a
    POST request, and that POST response streams SSE events directly.

    Args:
        request: Django request with the eval query params.
        allowed_paths: Whitelist of eval dotted paths that can be run.

    Returns:
        ``HttpResponse`` for the outer page or run trigger.
    """
    if request.method == "GET":
        return _render_eval_page(request, allowed_paths)
    if request.method == "POST":
        return await _run_eval(request, allowed_paths)
    return HttpResponseNotAllowed(["GET", "POST"])


def _render_eval_page(request, allowed_paths: Collection[str]):
    try:
        eval_path, eval_arguments = _parse_eval_request(request, allowed_paths)
    except PermissionError as exc:
        return HttpResponseForbidden(str(exc))
    except (TypeError, ValueError) as exc:
        return HttpResponseBadRequest(str(exc))

    runs = []
    for kwargs in eval_arguments:
        query = generate_eval_url(eval_path, kwargs)
        runs.append({
            "arguments": [
                {
                    "key": key,
                    "value": _input_value(value),
                    "value_type": _value_type(value),
                }
                for key, value in kwargs.items()
            ],
            "start_url": request.path + query,
        })

    return render(request, "dj_evals/run_page.html", {
        "csrf_token": get_token(request),
        "eval_path": eval_path,
        "runs": runs,
    })


async def _run_eval(request, allowed_paths: Collection[str]):
    try:
        eval_path, eval_arguments = _parse_eval_request(request, allowed_paths)
    except PermissionError as exc:
        return HttpResponseForbidden(str(exc))
    except (TypeError, ValueError) as exc:
        return HttpResponseBadRequest(str(exc))

    async def stream_events():
        async for event in iter_eval_events(
            eval_path=eval_path,
            kwargs=eval_arguments[0],
        ):
            payload = json.dumps({"event": event}, separators=(",", ":"))
            yield f"event: eval-event\ndata: {payload}\n\n"

        yield "event: done\ndata: {}\n\n"

    response = StreamingHttpResponse(
        stream_events(),
        content_type="text/event-stream",
    )
    response["Cache-Control"] = "no-cache"
    response["X-Accel-Buffering"] = "no"
    return response


def _parse_eval_request(
    request,
    allowed_paths: Collection[str],
) -> tuple[str, list[dict]]:
    eval_path = request.GET.get(EVAL_PARAM, "")
    # Reject missing or unapproved eval paths before importing host code.
    if eval_path not in allowed_paths:
        raise PermissionError("eval_path is not allowed")

    eval_arguments = []
    for value in request.GET.getlist(ARGS_PARAM):
        try:
            kwargs = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ValueError("eval_args must be valid JSON") from exc

        # Users can edit eval_args by hand, so validate before use.
        if not isinstance(kwargs, dict):
            raise TypeError("eval arguments must be a dictionary")
        eval_arguments.append(kwargs)

    # No eval_args means run the eval once with no kwargs.
    if not eval_arguments:
        eval_arguments.append({})
    return eval_path, eval_arguments
