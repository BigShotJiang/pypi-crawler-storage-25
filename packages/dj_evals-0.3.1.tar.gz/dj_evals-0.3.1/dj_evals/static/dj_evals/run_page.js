(function () {
  var MARKDOWN_URL = document.currentScript.dataset.markdownUrl;
  var markdownParser = null;

  async function loadMarkdown() {
    // Markdown loading can fail, so keep plain-text rendering as fallback.
    try {
      markdownParser = await import(MARKDOWN_URL);
      await markdownParser.ready();
    } catch (error) {
      markdownParser = null;
    }
  }

  function stringify(value) {
    if (typeof value === "string") {
      return value;
    }
    try {
      return JSON.stringify(value, null, 2);
    } catch (error) {
      return String(value);
    }
  }

  function markdownOptions() {
    var flags = markdownParser.ParseFlags;
    return {
      parseFlags: flags.COLLAPSE_WHITESPACE |
        flags.PERMISSIVE_URL_AUTO_LINKS |
        flags.NO_HTML |
        flags.TABLES
    };
  }

  function eventClass(eventType) {
    return String(eventType || "event").replace(/\s+/g, "-");
  }

  function renderPlainText(block, text) {
    block.classList.add("plain-text");
    block.textContent = String(text);
  }

  function renderMarkdown(block, text) {
    // Markdown is optional; render plain text when loading fails.
    if (!markdownParser) {
      renderPlainText(block, text);
      return;
    }
    try {
      block.classList.remove("plain-text");
      block.innerHTML = markdownParser.parse(String(text), markdownOptions());
    } catch (error) {
      renderPlainText(block, text);
    }
  }

  function appendBlock(outputEl, eventType, text) {
    var block = document.createElement("div");
    block.className = eventClass(eventType);
    renderMarkdown(block, text);
    outputEl.appendChild(block);
    return block;
  }

  function appendTextDelta(outputEl, state, eventType, text) {
    // Consecutive text deltas should update one markdown block.
    if (!state.textBlock) {
      state.textBlock = appendBlock(outputEl, eventType, "");
      state.text = "";
    }
    state.text += String(text);
    renderMarkdown(state.textBlock, state.text);
  }

  function closeTextDelta(state) {
    state.textBlock = null;
    state.text = "";
  }

  function appendEvent(outputEl, event) {
    appendBlock(outputEl, event.type || "event", "\n" + stringify(event) + "\n");
  }

  function appendEvalEvent(outputEl, state, event) {
    if (typeof event === "string") {
      appendTextDelta(outputEl, state, "message", event);
      return;
    }

    if (!event || typeof event !== "object") {
      closeTextDelta(state);
      appendBlock(outputEl, "event", stringify(event));
      return;
    }

    if (event.type === "response.output_text.delta") {
      appendTextDelta(outputEl, state, event.type, event.delta || event.text || "");
      return;
    }

    if (["response.completed", "response.output_text.done"].includes(event.type)) {
      closeTextDelta(state);
      appendBlock(outputEl, event.type, "");
      return;
    }

    if (event.type === "error") {
      closeTextDelta(state);
      appendBlock(outputEl, event.type, event.message || "Unknown error");
      return;
    }

    if (event.choices) {
      event.choices.forEach(function (choice) {
        appendTextDelta(outputEl, state, "choices", (choice.delta || {}).content || "");
      });
      return;
    }

    if (event.content) {
      appendTextDelta(outputEl, state, "content", event.content);
      return;
    }

    closeTextDelta(state);
    appendEvent(outputEl, event);
  }

  function formatSeconds(ms) {
    return (ms / 1000).toFixed(1) + "s";
  }

  function startTimer(timerEl, state) {
    state.startTime = performance.now();
    timerEl.textContent = "0.0s";
    state.timerId = setInterval(function () {
      timerEl.textContent = formatSeconds(performance.now() - state.startTime);
    }, 100);
  }

  function stopTimer(timerEl, state) {
    // A re-run may stop an already completed or failed timer.
    if (!state.timerId) {
      return;
    }
    clearInterval(state.timerId);
    state.timerId = null;
    timerEl.textContent = formatSeconds(performance.now() - state.startTime);
  }

  function readArguments(form) {
    var kwargs = {};
    form.querySelectorAll("input[name]").forEach(function (input) {
      // String args should stay strings, even when they look like JSON.
      if (input.dataset.valueType === "string") {
        kwargs[input.name] = input.value;
        return;
      }

      try {
        kwargs[input.name] = JSON.parse(input.value);
      } catch (error) {
        kwargs[input.name] = input.value;
      }
    });
    return kwargs;
  }

  function getCsrfToken() {
    return document.querySelector('meta[name="csrf-token"]').content;
  }

  function parseSseBlock(block) {
    var eventType = "message";
    var data = [];
    block.replace(/\r/g, "").split("\n").forEach(function (line) {
      if (line.indexOf("event:") === 0) {
        eventType = line.slice(6).trim();
      }
      if (line.indexOf("data:") === 0) {
        data.push(line.slice(5).trimStart());
      }
    });
    return {type: eventType, data: data.join("\n")};
  }

  function readSse(text, outputEl, state) {
    var blocks = (state.pendingSseText + text).split("\n\n");
    state.pendingSseText = blocks.pop();

    blocks.forEach(function (block) {
      var message = parseSseBlock(block);
      if (message.type === "done") {
        closeTextDelta(state);
        appendBlock(outputEl, message.type, "");
        return;
      }

      // Keep-alive or malformed SSE blocks may have no data.
      if (!message.data) {
        return;
      }

      if (message.type === "eval-event") {
        appendEvalEvent(outputEl, state, JSON.parse(message.data).event);
        return;
      }

      closeTextDelta(state);
      appendEvent(outputEl, message);
    });
  }

  async function startRun(section) {
    var outputEl = section.querySelector(".events");
    var timerEl = section.querySelector("[data-timer]");
    var form = section.querySelector(".eval-args");

    // The user can re-run a panel while the previous stream is active.
    if (section.djEvalsAbortController) {
      section.djEvalsAbortController.abort();
      stopTimer(timerEl, section.djEvalsState);
    }

    var startUrl = new URL(section.dataset.startUrl, window.location.href);
    var state = {
      // Stream chunks can split one SSE message, so keep the unfinished tail.
      pendingSseText: "",
      startTime: 0,
      text: "",
      textBlock: null,
      timerId: null
    };
    var abortController = new AbortController();
    section.djEvalsAbortController = abortController;
    section.djEvalsState = state;
    startUrl.searchParams.set("eval_args", JSON.stringify(readArguments(form)));
    outputEl.textContent = "";
    startTimer(timerEl, state);

    try {
      var response = await fetch(startUrl.toString(), {
        method: "POST",
        credentials: "same-origin",
        headers: {"X-CSRFToken": getCsrfToken()},
        signal: abortController.signal
      });

      // Validation and permission errors return normal HTTP failures.
      if (!response.ok) {
        stopTimer(timerEl, state);
        appendBlock(outputEl, "error", "Eval request failed: " + response.status);
        return;
      }

      var reader = response.body.getReader();
      var decoder = new TextDecoder();
      while (true) {
        var result = await reader.read();
        if (result.done) {
          readSse(decoder.decode(), outputEl, state);
          stopTimer(timerEl, state);
          return;
        }
        readSse(decoder.decode(result.value, {stream: true}), outputEl, state);
      }
    } catch (error) {
      // Re-running a panel aborts the previous request intentionally.
      if (error.name === "AbortError") {
        return;
      }
      stopTimer(timerEl, state);
      appendBlock(outputEl, "error", String(error));
    }
  }

  async function main() {
    await loadMarkdown();
    document.querySelectorAll("[data-eval-run]").forEach(function (section) {
      var form = section.querySelector(".eval-args");
      form.addEventListener("submit", function (event) {
        event.preventDefault();
        startRun(section);
      });
      startRun(section);
    });
  }

  main();
}());
