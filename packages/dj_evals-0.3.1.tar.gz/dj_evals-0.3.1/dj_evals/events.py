import importlib
import inspect
import json
import traceback


async def iter_eval_events(*, eval_path, kwargs):
    """Yield eval events as JSON-safe values.

    The eval function is imported from ``eval_path`` and called with ``kwargs``.
    Async generators produce multiple events. Sync and async functions return one event.
    """
    try:
        eval_func = _import_from_dotted_path(eval_path)
        async for event in _iter_eval_result(eval_func(**kwargs)):
            yield _json_safe_event(event)
    except Exception as exc:
        yield {"type": "error", "message": f"{exc}\n{traceback.format_exc()}"}


def _event_to_dict(event):
    """Return SDK model events as plain dictionaries when possible."""
    if isinstance(event, dict):
        return event
    if not hasattr(event, "to_dict"):
        return event

    try:
        return event.to_dict(mode="json", warnings=False)
    except TypeError:
        return event.to_dict()


def _json_safe_event(event):
    event = _event_to_dict(event)
    try:
        json.dumps(event)
    except TypeError:
        return str(event)
    return event


async def _iter_eval_result(result):
    # Async generators produce stream events one by one.
    if inspect.isasyncgen(result):
        async for event in result:
            yield event
        return

    # Async functions return an awaitable that resolves to one event.
    if inspect.isawaitable(result):
        yield await result
        return

    yield result


def _import_from_dotted_path(eval_path):
    """Import and validate an eval function by dotted path."""
    module_path, _, function_name = eval_path.rpartition(".")
    if not module_path or not function_name:
        raise ImportError(f"Invalid eval_path: {eval_path}")
    module = importlib.import_module(module_path)
    eval_func = getattr(module, function_name)
    if not callable(eval_func):
        raise TypeError(f"{eval_path} is not callable")
    return eval_func
