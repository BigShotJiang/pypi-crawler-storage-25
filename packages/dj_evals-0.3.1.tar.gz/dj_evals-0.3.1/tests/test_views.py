from pathlib import Path

import pytest
from django.contrib.staticfiles import finders
from django.test import RequestFactory

from dj_evals import generate_eval_url, handle_eval_request


def test_handle_eval_request_is_importable():
    assert callable(handle_eval_request)


def test_handle_eval_request_requires_named_allowed_paths():
    request = RequestFactory().get(
        "/evals/run/",
        {"eval_path": "tests.fake_evals.echo_eval"},
    )

    with pytest.raises(TypeError):
        handle_eval_request(request, {"tests.fake_evals.echo_eval"})


def test_generate_eval_url_encodes_eval_arguments():
    url = generate_eval_url(
        "tests.fake_evals.echo_eval",
        {"model": "gpt-4.1", "temperature": 0.2},
    )

    assert "eval_path=tests.fake_evals.echo_eval" in url
    assert "eval_args=" in url
    assert "temperature" in url


def test_generate_eval_url_rejects_non_dict_arguments():
    with pytest.raises(TypeError, match="dictionary"):
        generate_eval_url("tests.fake_evals.echo_eval", ["not", "a", "dict"])


def test_bundled_markdown_asset_is_available_without_sourcemap():
    path = finders.find("dj_evals/markdown.es.js")

    assert path
    assert "sourceMappingURL" not in Path(path).read_text()


@pytest.mark.asyncio
async def test_handle_eval_request_renders_sse_panels_for_each_argument_set():
    request = RequestFactory().get(
        "/evals/run/"
        + generate_eval_url(
            "tests.fake_evals.echo_eval",
            {"model": "gpt-4.1", "text": "hello"},
            {"model": "openrouter/openai/gpt-4.1", "text": "hello"},
        ),
    )

    response = await handle_eval_request(
        request,
        allowed_paths={"tests.fake_evals.echo_eval"},
    )
    html = response.content.decode()

    assert response.status_code == 200
    assert html.count("<section data-eval-run") == 2
    assert '<script src="/static/dj_evals/run_page.js" data-markdown-url="/static/dj_evals/markdown.es.js"></script>' in html
    assert '<meta name="csrf-token"' in html
    assert "/events/" not in html
    assert "data-channel" not in html
    assert "<h1>tests.fake_evals.echo_eval</h1>" in html
    assert 'input name="model" value="gpt-4.1"' in html
    assert 'input name="text" value="hello"' in html
    assert 'input name="model" value="openrouter/openai/gpt-4.1"' in html
    assert '<button type="submit">Run eval</button>' in html
    assert '<div class="timer" data-timer>0.0s</div>' in html
    assert '<div class="events"></div>' in html
    assert "overflow-x: hidden" in html
    assert "flex-wrap: wrap" in html
    assert "calc((100% - 32px) / 3)" in html
    assert "<iframe" not in html
    assert "<pre" not in html


@pytest.mark.asyncio
async def test_handle_eval_request_renders_argument_type_metadata():
    request = RequestFactory().get(
        "/evals/run/"
        + generate_eval_url(
            "tests.fake_evals.echo_eval",
            {
                "count": 3,
                "enabled": True,
                "label": "true",
                "items": [1, 2],
                "options": {"a": 1},
                "empty": None,
            },
        ),
    )

    response = await handle_eval_request(
        request,
        allowed_paths={"tests.fake_evals.echo_eval"},
    )
    html = response.content.decode()

    assert 'input name="count" value="3" data-value-type="number"' in html
    assert 'input name="enabled" value="true" data-value-type="boolean"' in html
    assert 'input name="label" value="true" data-value-type="string"' in html
    assert 'input name="items" value="[1,2]" data-value-type="json"' in html
    assert 'input name="options" value="{&quot;a&quot;:1}" data-value-type="json"' in html
    assert 'input name="empty" value="null" data-value-type="json"' in html


@pytest.mark.asyncio
async def test_handle_eval_request_defaults_to_one_empty_argument_set():
    request = RequestFactory().get(
        "/evals/run/" + generate_eval_url("tests.fake_evals.echo_eval"),
    )

    response = await handle_eval_request(
        request,
        allowed_paths={"tests.fake_evals.echo_eval"},
    )
    html = response.content.decode()

    assert response.status_code == 200
    assert html.count("<section data-eval-run") == 1


@pytest.mark.asyncio
async def test_handle_eval_request_post_streams_eval_events_as_sse():
    request = RequestFactory().post(
        "/evals/run/"
        + generate_eval_url(
            "tests.fake_evals.echo_eval",
            {"model": "gpt-4.1", "text": "hello"},
        ),
    )

    response = await handle_eval_request(
        request,
        allowed_paths={"tests.fake_evals.echo_eval"},
    )

    chunks = []
    async for chunk in response.streaming_content:
        chunks.append(chunk.decode() if isinstance(chunk, bytes) else chunk)
    body = "".join(chunks)

    assert response.status_code == 200
    assert response["Content-Type"] == "text/event-stream"
    assert "event: eval-event" in body
    assert "gpt-4.1:hello" in body
    assert "event: done" in body


@pytest.mark.asyncio
async def test_handle_eval_request_rejects_disallowed_eval_path():
    request = RequestFactory().get(
        "/evals/run/",
        {"eval_path": "tests.fake_evals.echo_eval"},
    )

    response = await handle_eval_request(
        request,
        allowed_paths={"tests.fake_evals.other_eval"},
    )

    assert response.status_code == 403
    assert b"eval_path is not allowed" in response.content


@pytest.mark.asyncio
async def test_handle_eval_request_rejects_disallowed_post_eval_path():
    request = RequestFactory().post(
        "/evals/run/"
        + generate_eval_url(
            "tests.fake_evals.echo_eval",
            {},
        ),
    )

    response = await handle_eval_request(
        request,
        allowed_paths={"tests.fake_evals.other_eval"},
    )

    assert response.status_code == 403


@pytest.mark.asyncio
async def test_handle_eval_request_rejects_unsupported_methods():
    request = RequestFactory().put(
        "/evals/run/",
        QUERY_STRING="eval_path=tests.fake_evals.echo_eval",
    )

    response = await handle_eval_request(
        request,
        allowed_paths={"tests.fake_evals.echo_eval"},
    )

    assert response.status_code == 405
