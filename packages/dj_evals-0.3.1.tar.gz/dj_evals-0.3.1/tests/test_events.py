import pytest

from dj_evals.events import iter_eval_events


@pytest.mark.asyncio
async def test_iter_eval_events_yields_raw_eval_events():
    events = [
        event
        async for event in iter_eval_events(
            eval_path="tests.fake_evals.echo_eval",
            kwargs={"text": "from url", "model": "model-a"},
        )
    ]

    assert events == [
        {"type": "response.output_text.delta", "delta": "model-a:from url"},
        {
            "type": "response.completed",
            "response": {
                "usage": {"input_tokens": 3, "output_tokens": 4},
                "cost": 0.01,
            },
        },
    ]


@pytest.mark.asyncio
async def test_iter_eval_events_yields_failures_as_error_events():
    events = [
        event
        async for event in iter_eval_events(
            eval_path="tests.fake_evals.missing_eval",
            kwargs={},
        )
    ]

    assert events[0]["type"] == "error"
    assert "missing_eval" in events[0]["message"]


@pytest.mark.asyncio
async def test_iter_eval_events_serializes_sdk_events_without_pydantic_warnings():
    events = [
        event
        async for event in iter_eval_events(
            eval_path="tests.fake_evals.sdk_eval",
            kwargs={},
        )
    ]

    assert events == [
        {"type": "response.output_text.delta", "delta": "quiet sdk event"}
    ]


@pytest.mark.asyncio
async def test_iter_eval_events_stringifies_non_json_events():
    events = [
        event
        async for event in iter_eval_events(
            eval_path="tests.fake_evals.object_eval",
            kwargs={},
        )
    ]

    assert events[0].startswith("<object object at")


@pytest.mark.asyncio
async def test_iter_eval_events_supports_async_functions():
    events = [
        event
        async for event in iter_eval_events(
            eval_path="tests.fake_evals.async_eval",
            kwargs={"text": "from async"},
        )
    ]

    assert events == [{"type": "response.output_text.delta", "delta": "from async"}]


@pytest.mark.asyncio
async def test_iter_eval_events_supports_sync_functions():
    events = [
        event
        async for event in iter_eval_events(
            eval_path="tests.fake_evals.sync_eval",
            kwargs={},
        )
    ]

    assert events == [{"type": "response.output_text.delta", "delta": "sync"}]
