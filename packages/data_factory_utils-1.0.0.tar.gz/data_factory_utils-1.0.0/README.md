# data-factory-utils
A package for random utils for data factories.

## Installation
This is a published package. Install using your favourite installation method.

```bash
uv add data-factory-utils
pip install data-factory-utils
```

## Usage
### Environment functions
This set of functions reads from your data factory dynamically. It should infer the environment you are in as well.

No matter how many times you initiate the class, it will re-use old variables. To do so...
```python
from data_factory_utils.environment import Environment
env = Environment()
```

To return information about the environment (if we are in development with account number 0101010101):
```python
env.account_no
# 0101010101
env.environment_name
# dev
env.is_prod
# False
```

To get an S3 bucket name (outputted as `cloudpathlib`'s `S3Path`) (let us imagine here that the name is `emds-dev-random-name-202512161154001309058001`):

```python
s3_random_name_bucket = env.get_full_bucket_url("random-name", full_prefix=True)
print(str(s3_random_name_bucket.bucket))
# emds-dev-random-name-202512161154001309058001
```
