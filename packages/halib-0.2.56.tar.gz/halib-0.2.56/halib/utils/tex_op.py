from __future__ import annotations
import re
import shutil
from pathlib import Path
from typing import Optional
from tap import Tap
from ..common.common import *


# ── CLI Args ──────────────────────────────────────────────────────────────────


class TexOpArgs(Tap):
    main_tex: str
    base_dir: str = ""
    out_dir:  str = ""

    def configure(self):
        self.add_argument("-m", "--main-tex",  required=True,
                          help="Path to main .tex file")
        self.add_argument("-b", "--base-dir",
                          help="Root dir for resolving relative paths "
                               "(default: same folder as main tex)")
        self.add_argument("-o", "--out-dir",
                          help="Parent dir for output folder "
                               "(default: same folder as main tex)")


# ── TexOp ─────────────────────────────────────────────────────────────────────


class TexOp:
    """Produces a self-contained {stem}_standalone/ folder.

    Dissolved (inlined, no file copy):
      \\input{*.tex}   → inlined recursively into the main tex

    Copied (raw resources, ONE level deep: {top_folder}/{filename}):
      \\includegraphics / \\includesvg          → image files
      \\bibliography   / \\addbibresource       → .bib files
      \\csvreader / \\csvautotabular / …        → CSV files (csvsimple-l3)
      \\lstinputlisting / \\inputminted          → code listing files

    Collision handling (two different files flatten to the same name):
      first file  → top_folder/name.ext          (unchanged)
      second file → top_folder/name_2.ext
      third file  → top_folder/name_3.ext   …and so on

    Paths in the output .tex are rewritten to match exactly.
    """

    # ── Raw resource patterns ─────────────────────────────────────────────────
    # Each tuple: (compiled regex, prefix_group, path_group)
    # Reconstruction: m.group(prefix_group) + '{' + resolved_flat_path + '}'
    _RAW_PATTERNS: list[tuple[re.Pattern, int, int]] = [
        # \includegraphics[opts]{path}
        (re.compile(r'(\\includegraphics(?:\[[\s\S]*?\])?)\{([^}]+)\}'),           1, 2),
        # \includesvg[opts]{path}
        (re.compile(r'(\\includesvg(?:\[[\s\S]*?\])?)\{([^}]+)\}'),                1, 2),
        # \bibliography{name}
        (re.compile(r'(\\bibliography)\{([^}]+)\}'),                                1, 2),
        # \addbibresource{file.bib}
        (re.compile(r'(\\addbibresource)\{([^}]+)\}'),                             1, 2),
        # csvsimple-l3: \csvreader[opts]{file}{...}  \csvautotabular[opts]{file} etc.
        (re.compile(r'(\\(?:csvreader|csvautotabular|csvautolongtable'
                    r'|csvsimplereader)(?:\[[\s\S]*?\])?)\{([^}]+)\}'),            1, 2),
        # \lstinputlisting[opts]{path}
        (re.compile(r'(\\lstinputlisting(?:\[[\s\S]*?\])?)\{([^}]+)\}'),           1, 2),
        # \inputminted[opts]{lang}{path}
        (re.compile(r'(\\inputminted(?:\[[\s\S]*?\])?\{[^}]+\})\{([^}]+)\}'),     1, 2),
    ]

    # Extensions to probe when a path has no extension (e.g. \includegraphics{fig})
    _PROBE_EXTS = ('', '.pdf', '.png', '.jpg', '.jpeg',
                   '.PNG', '.JPG', '.eps', '.svg', '.bib', '.csv')

    # ── Init ──────────────────────────────────────────────────────────────────

    def __init__(self, main_tex: str, base_dir: str = "", out_dir: str = ""):
        self.main_tex = Path(main_tex).resolve()
        self.base_dir = Path(base_dir).resolve() if base_dir else self.main_tex.parent
        parent_out    = Path(out_dir).resolve()   if out_dir   else self.main_tex.parent
        self.out_dir  = parent_out / f"{self.main_tex.stem}_standalone"
        # assigned_flat_posix → abs_path  (populated during run)
        self._resources: dict[str, Path] = {}

    # ── Path helpers ──────────────────────────────────────────────────────────

    def _resolve(self, rel: str, tex_dir: Path) -> Optional[tuple[str, Path]]:
        """Find a file; return (base_dir-relative posix path, abs Path)."""
        for base in (tex_dir, self.base_dir):
            for ext in self._PROBE_EXTS:
                candidate = (base / (rel + ext)).resolve()
                if candidate.is_file():
                    try:
                        key = candidate.relative_to(self.base_dir).as_posix()
                    except ValueError:
                        key = candidate.name
                    return key, candidate
        return None

    @staticmethod
    def _one_level(rel_posix: str) -> str:
        """Strip intermediate subdirs, keep only top_folder/filename.

        3.fig/sub/fig1.png  →  3.fig/fig1.png
        4.table/tb.csv      →  4.table/tb.csv   (already one level)
        standalone.png      →  standalone.png   (no folder)
        """
        parts = Path(rel_posix).parts
        if len(parts) <= 2:
            return rel_posix
        return f"{parts[0]}/{parts[-1]}"

    def _unique_flat(self, flat_rel: str, abs_path: Path) -> str:
        """Return a collision-free flat key for abs_path.

        - Same physical file already registered → return its existing key (no dup).
        - New file, name not taken             → use flat_rel as-is.
        - New file, name already taken         → append _2, _3, … until free.

        Example:
          plot.png  (first)   → 3.fig/plot.png
          plot.png  (second)  → 3.fig/plot_2.png
          plot.png  (third)   → 3.fig/plot_3.png
        """
        # Same file already seen → reuse the key we assigned it before
        for existing_key, existing_path in self._resources.items():
            if existing_path == abs_path:
                return existing_key

        # Brand-new file, no name conflict
        if flat_rel not in self._resources:
            return flat_rel

        # Name conflict with a *different* file → find next free _N suffix
        p = Path(flat_rel)
        n = 2
        while True:
            candidate = (p.parent / f"{p.stem}_{n}{p.suffix}").as_posix()
            if candidate not in self._resources:
                return candidate
            n += 1

    # ── Per-file text transformation ──────────────────────────────────────────

    def _rewrite_resources(self, text: str, tex_dir: Path) -> str:
        """Rewrite resource paths to unique one-level flat posix; record for copy."""
        for pattern, pre_grp, path_grp in self._RAW_PATTERNS:
            def _sub(m: re.Match, _pg=path_grp, _prg=pre_grp) -> str:
                result = self._resolve(m.group(_pg).strip(), tex_dir)
                if result is None:
                    return m.group(0)
                base_rel, abs_path = result
                flat_rel   = self._one_level(base_rel)
                unique_rel = self._unique_flat(flat_rel, abs_path)
                self._resources[unique_rel] = abs_path
                return f'{m.group(_prg)}{{{unique_rel}}}'
            text = pattern.sub(_sub, text)
        return text

    # ── Recursive flattener ───────────────────────────────────────────────────

    def _flatten(self, tex_path: Path) -> str:
        """Inline \\input{*.tex} and rewrite resource paths — recursively."""
        text    = tex_path.read_text(encoding='utf-8')
        tex_dir = tex_path.parent

        text = self._rewrite_resources(text, tex_dir)

        def _replace_input(m: re.Match) -> str:
            rel = m.group(1).strip()
            if not rel.endswith('.tex'):
                rel += '.tex'
            for base in (tex_dir, self.base_dir):
                child = (base / rel).resolve()
                if child.exists():
                    return self._flatten(child)
            return m.group(0)

        return re.sub(r'\\input\{([^}]+)\}', _replace_input, text)

    # ── Public entry ──────────────────────────────────────────────────────────

    def run(self) -> str:
        """Build the standalone folder. Returns the output directory path."""
        self._resources = {}

        flat = self._flatten(self.main_tex)

        self.out_dir.mkdir(parents=True, exist_ok=True)
        (self.out_dir / self.main_tex.name).write_text(flat, encoding='utf-8')

        for flat_rel, abs_path in self._resources.items():
            dest = self.out_dir / flat_rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(abs_path, dest)

        return str(self.out_dir)


# ── Entry point ───────────────────────────────────────────────────────────────


if __name__ == "__main__":
    args = TexOpArgs().parse_args()

    op = TexOp(
        main_tex=args.main_tex,
        base_dir=args.base_dir,
        out_dir=args.out_dir,
    )

    with ConsoleLog("Tex Standalone Builder..."):
        pprint_box({
            "Main TeX":   str(op.main_tex),
            "Base Dir":   str(op.base_dir),
            "Output Dir": str(op.out_dir),
        })
    try:
        outdir = op.run()
        pprint_local_path(
            outdir, tag_or_box_title="✅ Standalone folder saved to", get_wins_path=True
        )
    except Exception as e:
        pprint_stack_trace(msg="[TexOp] Error occurred while processing TeX", e=e)
