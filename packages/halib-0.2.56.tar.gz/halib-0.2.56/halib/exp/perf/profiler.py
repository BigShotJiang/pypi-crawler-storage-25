import os
import time
import json
from pprint import pprint
from threading import Lock
from functools import wraps
from loguru import logger

from plotly.subplots import make_subplots
import plotly.graph_objects as go
import plotly.express as px

from contextlib import contextmanager
from typing import Dict

from ...common.common import ConsoleLog
from ...system.path import *


# ==========================================
# 1. The Decorator
# ==========================================
def check_enabled(func):
    """
    Decorator to skip method execution if the profiler is disabled.

    This acts as a 'guard clause' for the entire function. If the profiler
    instance has 'enabled=False', the decorated function is not executed at all,
    saving processing time and avoiding side effects.
    """

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if not getattr(self, "enabled", True):
            return
        return func(self, *args, **kwargs)

    return wrapper


# ==========================================
# 2. The Class
# ==========================================
class ContextScope:
    """Helper to remember the current context name so you don't have to repeat it."""

    def __init__(self, profiler, ctx_name):
        self.profiler = profiler
        self.ctx_name = ctx_name

    @contextmanager
    def step(self, step_name, pre_calc_time=None):
        with self.profiler.measure(
            self.ctx_name, step_name, pre_calc_time=pre_calc_time
        ):
            yield


class zProfiler:
    """A singleton profiler to measure execution time of contexts and steps.

    Example (using context manager):
        prof = zProfiler()
        with prof.measure("my_context") as ctx:
            with ctx.step("step1"):
                time.sleep(0.1)
            with ctx.step("step2"):
                time.sleep(0.2)

    Example (using raw methods):
        prof = zProfiler()
        prof.ctx_start("my_context")
        prof.step_start("my_context", "step1")
        time.sleep(0.1)
        prof.step_end("my_context", "step1")
        prof.ctx_end("my_context")

    Example (using pre_calc_time to inject a known duration):
        prof = zProfiler()
        with prof.measure("my_context") as ctx:
            with ctx.step("cached_step", pre_calc_time=0.050):
                result = cached_result   # body still runs, timing is injected
    """

    _instance = None
    _lock = Lock()

    def __new__(cls, *args, **kwargs):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
            return cls._instance

    def __init__(self, enabled=None):
        """
        Args:
            enabled (bool, optional):
                - If True/False: Updates the enabled state immediately.
                - If None: Keeps the current state (defaults to True on first init).
        """
        if not hasattr(self, "_initialized"):
            self.enabled = enabled if enabled is not None else True
            self.time_dict = {}
            self._initialized = True
        elif enabled is not None:
            self.enabled = enabled

    @check_enabled
    def ctx_start(self, ctx_name="ctx_default"):
        if not isinstance(ctx_name, str) or not ctx_name:
            raise ValueError("ctx_name must be a non-empty string")
        if ctx_name not in self.time_dict:
            self.time_dict[ctx_name] = {
                "start": time.perf_counter(),
                "step_dict": {},
                "report_count": 0,
            }
        else:
            # FIX BUG-1 + BUG-2: Reset start time and injected accumulator on
            # every re-entry. Without this, ctx duration grows unboundedly across
            # iterations and _injected_step_time accumulates across all calls.
            self.time_dict[ctx_name]["start"] = time.perf_counter()
            self.time_dict[ctx_name]["_injected_step_time"] = 0.0
            self.time_dict[ctx_name].pop("_duration_locked", None)
        self.time_dict[ctx_name]["report_count"] += 1

    @check_enabled
    def ctx_end(self, ctx_name="ctx_default"):
        if ctx_name not in self.time_dict:
            return
        if self.time_dict[ctx_name].get("_duration_locked", False):
            return
        self.time_dict[ctx_name]["end"] = time.perf_counter()
        wall_clock = self.time_dict[ctx_name]["end"] - self.time_dict[ctx_name]["start"]
        # Accumulate injected step time into ctx duration
        injected = self.time_dict[ctx_name].get("_injected_step_time", 0.0)
        current = wall_clock + injected
        self.time_dict[ctx_name]["duration"] = (
            self.time_dict[ctx_name].get("duration", 0.0) + current  # ACCUMULATES
        )

    @check_enabled
    def step_start(self, ctx_name, step_name):
        if not isinstance(step_name, str) or not step_name:
            raise ValueError("step_name must be a non-empty string")
        if ctx_name not in self.time_dict:
            return
        if step_name not in self.time_dict[ctx_name]["step_dict"]:
            self.time_dict[ctx_name]["step_dict"][step_name] = []
        self.time_dict[ctx_name]["step_dict"][step_name].append([time.perf_counter()])

    @check_enabled
    def step_end(self, ctx_name, step_name):
        if (
            ctx_name not in self.time_dict
            or step_name not in self.time_dict[ctx_name]["step_dict"]
        ):
            return
        self.time_dict[ctx_name]["step_dict"][step_name][-1].append(time.perf_counter())

    @contextmanager
    def measure(self, ctx_name, step_name=None, pre_calc_time=None):
        if step_name is None:
            # --- Context Mode ---
            self.ctx_start(ctx_name)
            try:
                yield ContextScope(self, ctx_name)
            finally:
                # FIX BUG-3: Guard with self.enabled before writing to time_dict
                # directly — the original code bypassed the @check_enabled guard.
                if pre_calc_time is not None and self.enabled:
                    # FIX: Accumulate instead of overwriting
                    self.time_dict[ctx_name]["duration"] = (
                        self.time_dict[ctx_name].get("duration", 0.0) + pre_calc_time
                    )
                    self.time_dict[ctx_name]["_duration_locked"] = True
                self.ctx_end(ctx_name)
        else:
            # --- Step Mode ---
            if pre_calc_time is not None:
                t_start = time.perf_counter()
                if ctx_name in self.time_dict:
                    step_dict = self.time_dict[ctx_name]["step_dict"]
                    if step_name not in step_dict:
                        step_dict[step_name] = []
                    step_dict[step_name].append([t_start, t_start + pre_calc_time])
                try:
                    yield
                finally:
                    if ctx_name in self.time_dict:
                        real_time = time.perf_counter() - t_start
                        if real_time > pre_calc_time:
                            logger.warning(
                                f"Step '{step_name}' in ctx '{ctx_name}': real body time ({real_time*1000:.2f}ms) "
                                f"exceeded pre_calc_time ({pre_calc_time*1000:.2f}ms). "
                                f"Injected timing may be inaccurate."
                            )
                        net_injected = max(0.0, pre_calc_time - real_time)

                        self.time_dict[ctx_name]["_injected_step_time"] = (
                            self.time_dict[ctx_name].get("_injected_step_time", 0.0)
                            + net_injected
                        )
            else:
                self.step_start(ctx_name, step_name)
                try:
                    yield
                finally:
                    self.step_end(ctx_name, step_name)

    def merge_data(self, other_time_dict: Dict):
        """
        Aggregates profiling data from an external dictionary into the current instance.

        Designed for multiprocessing scenarios where worker processes collect data
        in isolated memory spaces.

        Args:
            other_time_dict (Dict): The `time_dict` from a worker process
                (usually via `future.result()`).

        Example:
            >>> with ProcessPoolExecutor() as executor:
            >>>     futures = [executor.submit(worker_task, args) for args in task_args]
            >>>     for future in as_completed(futures):
            >>>         main_profiler.merge_data(future.result())
        """
        with self._lock:
            for ctx_name, other_ctx_data in other_time_dict.items():
                # 1. New context: copy entire structure
                if ctx_name not in self.time_dict:
                    self.time_dict[ctx_name] = other_ctx_data
                    continue

                # 2. Existing context: merge steps
                local_step_dict = self.time_dict[ctx_name]["step_dict"]
                other_step_dict = other_ctx_data["step_dict"]

                for step_name, other_timings in other_step_dict.items():
                    if step_name not in local_step_dict:
                        local_step_dict[step_name] = other_timings
                    else:
                        local_step_dict[step_name].extend(other_timings)

                # 3. Aggregate report_count
                if "report_count" in other_ctx_data:
                    self.time_dict[ctx_name]["report_count"] += other_ctx_data[
                        "report_count"
                    ]

                # FIX BUG-6: Merge _injected_step_time from worker processes.
                # Without this, injected durations from workers are silently lost.
                if "_injected_step_time" in other_ctx_data:
                    self.time_dict[ctx_name]["_injected_step_time"] = (
                        self.time_dict[ctx_name].get("_injected_step_time", 0.0)
                        + other_ctx_data["_injected_step_time"]
                    )
                # Missing — duration from workers is silently lost:
                if "duration" in other_ctx_data:
                    self.time_dict[ctx_name]["duration"] = (
                        self.time_dict[ctx_name].get("duration", 0.0)
                        + other_ctx_data["duration"]
                    )

    def _step_dict_to_detail(self, ctx_step_dict):
        """
        Converts raw step timing lists into indexed (idx, duration) tuples.

        Input format:
            {
                'preprocess': [[start, end], [start, end], ...],
                'infer':      [[start, end], [start, end], ...],
            }
        """
        # FIX BUG-5: Corrected assert message — accepts any number of steps,
        # not "only one key" as the old message incorrectly stated.
        assert (
            len(ctx_step_dict.keys()) > 0
        ), "step_dict must have at least one step to generate detail."

        normed_ctx_step_dict = {}
        for step_name, time_list in ctx_step_dict.items():
            if not isinstance(time_list, list):
                raise ValueError(f"Step data for {step_name} must be a list")
            normed_time_ls = []
            for idx, time_data in enumerate(time_list):
                elapsed_time = -1
                if len(time_data) == 2:
                    elapsed_time = time_data[1] - time_data[0]
                normed_time_ls.append((idx, elapsed_time))
            normed_ctx_step_dict[step_name] = normed_time_ls
        return normed_ctx_step_dict

    def get_report_dict(self, min_avg_time=1e-5, with_detail=False):
        report_dict = {}
        for ctx_name, ctx_dict in self.time_dict.items():
            report_dict[ctx_name] = {
                "duration": ctx_dict.get("duration", 0.0),
                "step_dict": {
                    "summary": {"avg_time": {}, "percent_time": {}},
                    "detail": {},
                },
            }

            if with_detail:
                report_dict[ctx_name]["step_dict"]["detail"] = (
                    self._step_dict_to_detail(ctx_dict["step_dict"])
                )

            avg_time_list = []
            for step_name, step_list in ctx_dict["step_dict"].items():
                durations = []
                try:
                    for time_data in step_list:
                        if len(time_data) != 2:
                            continue
                        start, end = time_data
                        durations.append(end - start)
                except Exception as e:
                    logger.error(
                        f"Error processing step {step_name} in context {ctx_name}: {e}"
                    )
                    continue
                if not durations:
                    continue
                avg_time = sum(durations) / len(durations)
                if avg_time < min_avg_time:
                    continue
                avg_time_list.append((step_name, avg_time))

            total_avg_time = sum(t for _, t in avg_time_list) or 1e-10
            for step_name, avg_time in avg_time_list:
                report_dict[ctx_name]["step_dict"]["summary"]["percent_time"][
                    f"per_{step_name}"
                ] = (avg_time / total_avg_time) * 100.0
                report_dict[ctx_name]["step_dict"]["summary"]["avg_time"][
                    f"avg_{step_name}"
                ] = avg_time
            report_dict[ctx_name]["step_dict"]["summary"][
                "total_avg_time"
            ] = total_avg_time
            report_dict[ctx_name]["step_dict"]["summary"] = dict(
                sorted(report_dict[ctx_name]["step_dict"]["summary"].items())
            )
        return report_dict

    def get_report_dataframes(self, min_avg_time=1e-5):
        """
        Returns two pandas DataFrames containing profiling data.

        Returns:
            tuple: (df_summary, df_detail)
                - df_summary: Aggregated stats (Context, Step, Avg, %, Count)
                - df_detail: Raw duration for every single iteration
        """
        try:
            import pandas as pd
        except ImportError:
            logger.error(
                "Pandas is required for get_report_dataframes(). Please pip install pandas."
            )
            return None, None

        data = self.get_report_dict(with_detail=True, min_avg_time=min_avg_time)
        summary_rows = []
        detail_rows = []

        for ctx_name, ctx_data in data.items():
            summary = ctx_data["step_dict"]["summary"]
            detail_dict = ctx_data["step_dict"]["detail"]

            for avg_key, avg_val in summary["avg_time"].items():
                step_name = avg_key.replace("avg_", "")
                percent_val = summary["percent_time"].get(f"per_{step_name}", 0.0)
                count = len(detail_dict.get(step_name, []))
                summary_rows.append(
                    {
                        "context_name": ctx_name,
                        "step_name": step_name,
                        "avg_time_sec": avg_val,
                        "percent_total": percent_val,
                        "sample_count": count,
                    }
                )

            for step_name, time_list in detail_dict.items():
                for item in time_list:
                    if len(item) == 2:
                        idx, duration = item
                        detail_rows.append(
                            {
                                "context_name": ctx_name,
                                "step_name": step_name,
                                "iteration_idx": idx,
                                "duration_sec": duration,
                            }
                        )

        df_summary = pd.DataFrame(summary_rows)
        df_detail = pd.DataFrame(detail_rows)

        if not df_summary.empty:
            df_summary = df_summary[
                [
                    "context_name",
                    "step_name",
                    "avg_time_sec",
                    "percent_total",
                    "sample_count",
                ]
            ]

        if not df_detail.empty:
            df_detail = df_detail[
                ["context_name", "step_name", "iteration_idx", "duration_sec"]
            ]

        return df_summary, df_detail

    def get_report_csv_files(self, outdir, tag="profiler", min_avg_time=1e-5):
        """
        Exports profiling data to two CSV files:
            1. {tag}_summary.csv       — aggregated stats (avg time, %)
            2. {tag}_detailed_logs.csv — raw duration per iteration

        Args:
            outdir (str): Directory to save files.
            tag (str): Optional prefix for filenames.
            min_avg_time (float): Minimum average time threshold for including steps in the report.
        """
        if not os.path.exists(outdir):
            os.makedirs(outdir)
        tag_str = f"{tag}_" if tag else ""
        summary_file = os.path.join(outdir, f"{tag_str}summary.csv")
        detail_file = os.path.join(outdir, f"{tag_str}detailed_logs.csv")

        df_summary, df_detail = self.get_report_dataframes(min_avg_time=min_avg_time)
        if df_summary is not None:
            df_summary.to_csv(summary_file, index=False, sep=";", encoding="utf-8")
            logger.info(f"Saved summary CSV to: {summary_file}")
        if df_detail is not None:
            df_detail.to_csv(detail_file, index=False, sep=";", encoding="utf-8")
            logger.info(f"Saved detailed logs CSV to: {detail_file}")

    @classmethod
    def plot_formatted_data(
        cls, profiler_data, outdir=None, file_format="png", do_show=False, tag=""
    ):
        """
        Plot each context in a separate figure with bar + pie charts.
        Save each figure in the specified format (png or svg).
        """
        if outdir is not None:
            os.makedirs(outdir, exist_ok=True)

        if file_format.lower() not in ["png", "svg"]:
            raise ValueError("file_format must be 'png' or 'svg'")

        results = {}

        for ctx, ctx_data in profiler_data.items():
            summary = ctx_data["step_dict"]["summary"]
            avg_times = summary["avg_time"]
            percent_times = summary["percent_time"]

            step_names = [s.replace("avg_", "") for s in avg_times.keys()]
            n_steps = len(step_names)

            assert n_steps > 0, "No steps found for context: {}".format(ctx)

            colors = (
                px.colors.sample_colorscale(
                    "Viridis", [i / (n_steps - 1) for i in range(n_steps)]
                )
                if n_steps > 1
                else [px.colors.sample_colorscale("Viridis", [0])[0]]
            )
            color_map = dict(zip(step_names, colors))

            fig = make_subplots(
                rows=1,
                cols=2,
                subplot_titles=["Avg Time", "% Time"],
                specs=[[{"type": "bar"}, {"type": "pie"}]],
            )

            fig.add_trace(
                go.Bar(
                    x=step_names,
                    y=list(avg_times.values()),
                    text=[f"{v * 1000:.2f} ms" for v in avg_times.values()],
                    textposition="outside",
                    marker=dict(color=[color_map[s] for s in step_names]),
                    name="",
                    showlegend=False,
                ),
                row=1,
                col=1,
            )

            fig.add_trace(
                go.Pie(
                    labels=step_names,
                    values=list(percent_times.values()),
                    marker=dict(colors=[color_map[s] for s in step_names]),
                    hole=0.4,
                    name="",
                    showlegend=True,
                ),
                row=1,
                col=2,
            )

            tag_str = tag if tag and len(tag) > 0 else ""
            fig.update_layout(
                title_text=f"[{tag_str}] Context Profiler: {ctx}",
                width=1000,
                height=400,
                showlegend=True,
                legend=dict(title="Steps", x=1.05, y=0.5, traceorder="normal"),
                hovermode="x unified",
            )
            fig.update_xaxes(title_text="Steps", row=1, col=1)
            fig.update_yaxes(title_text="Avg Time (ms)", row=1, col=1)

            if do_show:
                fig.show()

            if outdir is not None:
                file_prefix = ctx if len(tag_str) == 0 else f"{tag_str}_{ctx}"
                file_path = os.path.join(
                    outdir, f"{file_prefix}_summary.{file_format.lower()}"
                )
                fig.write_image(file_path)
                pprint(f"Saved figure to: 🔽")
                pprint_local_path(file_path)

            results[ctx] = fig

        return results

    def report_and_plot(
        self, outdir=None, file_format="png", do_show=False, tag="", min_avg_time=1e-5
    ):
        """
        Generate the profiling report and plot the formatted data.

        Args:
            outdir (str): Directory to save figures. If None, figures are only shown.
            file_format (str): "png" or "svg". Default is "png".
            do_show (bool): Whether to display the plots interactively.
            tag (str): Optional tag prefix for filenames.
            min_avg_time (float): Minimum average time threshold for including steps in the report.
        """
        # FIX BUG-4: Removed redundant second get_report_dict() call whose
        # result was silently discarded.
        report = self.get_report_dict(min_avg_time=min_avg_time)
        return self.plot_formatted_data(
            report, outdir=outdir, file_format=file_format, do_show=do_show, tag=tag
        )

    def meta_info(self):
        """
        Print the structure of the profiler's time dictionary.
        Useful for debugging and understanding the profiler's internal state.
        """
        for ctx_name, ctx_dict in self.time_dict.items():
            with ConsoleLog(f"Context: {ctx_name}"):
                for step_name in ctx_dict["step_dict"].keys():
                    pprint(f"Step: {step_name}")

    def save_report_dict(self, output_file, with_detail=False):
        try:
            report = self.get_report_dict(with_detail=with_detail)
            with open(output_file, "w") as f:
                json.dump(report, f, indent=4)
        except Exception as e:
            logger.error(f"Failed to save report to {output_file}: {e}")
