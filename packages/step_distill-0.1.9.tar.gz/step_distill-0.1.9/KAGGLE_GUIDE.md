# 🧠 NanoReason — Hướng Dẫn Chạy Trên Kaggle (Full Opensource)

> **Package:** [`step-distill`](https://pypi.org/project/step-distill/) trên PyPI  
> **Model:** [`ductaiphan/NanoReason-3B`](https://huggingface.co/ductaiphan/NanoReason-3B) trên HuggingFace  
> **Yêu cầu:** Kaggle Notebook với **GPU T4 x2**

---

## Bước 1: Tạo Kaggle Notebook

1. Đăng nhập [kaggle.com](https://www.kaggle.com)
2. Bấm **+ New Notebook**
3. Bấm bánh răng ⚙️ (Settings) bên phải → **Accelerator** → chọn **GPU T4 x2**
4. Chạy các cell theo thứ tự dưới đây

---

## Bước 2: Cài đặt (Cell 1)

```python
# Cell 1: Install step-distill từ PyPI
!pip install "step-distill[all]" -q

import step_distill
print(f"✅ step-distill v{step_distill.__version__} installed!")
```

---

## Bước 3: Patch môi trường Kaggle (Cell 2)

```python
# Cell 2: Fix xung đột bitsandbytes/triton trên Kaggle
import peft.import_utils
peft.import_utils._bitsandbytes_available = False
import peft.tuners.lora.model as _lora
_lora.is_bnb_available = lambda: False
print("✅ PEFT patched")
```

---

## Bước 4: Import & Verify (Cell 3)

```python
# Cell 3: Verify tất cả module
from step_distill import (
    NanoReason, ReasoningResult,
    StepAwareLoss, StepAwareTrainer, StepDistillConfig,
    Evaluator, AccuracyMetric, RFSMetric, SVRMetric,
    TeacherPipeline, GSM8KSource, MATHSource, VNHSGESource,
)
print("✅ All 11 core classes imported!")
```

---

## Bước 5: Test CLI (Cell 4)

```python
# Cell 4: CLI smoke test
!step-distill --help
!step-distill generate --list-teachers
!step-distill train --list-students
```

---

## Bước 6: Load Model (Cell 5)

```python
# Cell 5: Load NanoReason-3B (tải ~6GB lần đầu)
import torch

print(f"GPU count: {torch.cuda.device_count()}")
for i in range(torch.cuda.device_count()):
    print(f"  GPU {i}: {torch.cuda.get_device_name(i)} - {torch.cuda.get_device_properties(i).total_memory / 1e9:.1f} GB")

print("\n⏳ Loading NanoReason-3B...")
model = NanoReason.from_pretrained("ductaiphan/NanoReason-3B", device="auto")
print("✅ Model loaded!")
```

---

## Bước 7: Giải Toán (Cell 6)

```python
# Cell 6: Quick inference
question = (
    "Janet's ducks lay 16 eggs per day. She eats 3 for breakfast "
    "and bakes muffins with 4. She sells the rest at $2/egg. "
    "How much does she make daily?"
)

result = model.solve(question)
print(repr(result))  # In 4 boxes đẹp

print(f"\n🎯 Answer: {result.answer}")
print(f"📊 RFS:    {result.rfs:.0%}")
print(f"⏱️  Time:   {result.generation_time_s:.2f}s")
```

---

## Bước 8: Batch Inference (Cell 7)

```python
# Cell 7: Giải hàng loạt
problems = [
    "If 2x + 5 = 11, what is x?",
    "A train travels at 60 km/h for 2.5 hours. How far does it travel?",
    "A rectangle has perimeter 28 cm. Its length is 3 cm more than its width. Find its area.",
    "Tom has 5 apples. He gives 2 to his sister and buys 3 more. How many?",
    "Tính giá trị của biểu thức A = 3x² + 2x - 1 khi x = 2.",
]

for i, q in enumerate(problems, 1):
    result = model.solve(q)
    print(f"🔢 Problem {i}: {q[:60]}...")
    print(f"   Answer: {result.answer}  |  RFS: {result.rfs:.0%}  |  Time: {result.generation_time_s:.2f}s\n")
```

---

## Bước 9: Test Metrics (Cell 8)

```python
# Cell 8: Accuracy, RFS, SVR metrics
acc = AccuracyMetric()

# Accuracy normalization test
test_pairs = [("18", "18"), ("$18", "18"), ("\\boxed{18}", "18"), ("18.0", "18"), ("1,234", "1234")]
print("📏 Accuracy Metric:")
for pred, gold in test_pairs:
    score = acc.compute([pred], [gold])
    print(f"  {'✅' if score == 1.0 else '❌'} '{pred}' vs '{gold}' → {score:.0%}")

# RFS metric
rfs = RFSMetric()
response = """#### UNDERSTAND ####
Given eggs and sales info.
#### PLAN ####
Calculate remaining then multiply.
#### EXECUTE ####
16 - 3 - 4 = 9, 9 * 2 = 18.
#### VERIFY ####
Check: 9 eggs at $2 = $18. Correct."""

rfs_result = rfs.compute([response])
print(f"\n📐 RFS: rfs_mean={rfs_result['rfs_mean']:.0%}, rfs_full={rfs_result['rfs_full']:.0%}")
```

---

## Bước 10: Launch Web Demo (Cell 9)

```python
# Cell 9: Khởi động giao diện web xịn
import threading, os, time

os.environ["NANOREASON_MODEL_PATH"] = "ductaiphan/NanoReason-3B"

def run_server():
    import uvicorn
    uvicorn.run("step_distill.app.server:app", host="0.0.0.0", port=8000, log_level="info")

threading.Thread(target=run_server, daemon=True).start()
time.sleep(3)
print("✅ Server đang chạy port 8000")

# Tạo public URL (Cloudflare Tunnel - miễn phí, không cần tài khoản)
!wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O /tmp/cloudflared
!chmod +x /tmp/cloudflared

import subprocess, re
proc = subprocess.Popen(
    ["/tmp/cloudflared", "tunnel", "--url", "http://localhost:8000"],
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
)
time.sleep(5)

for line in proc.stderr:
    m = re.search(r"(https://[a-z0-9-]+\.trycloudflare\.com)", line)
    if m:
        print(f"\n🌐 LINK DEMO (share cho ai cũng mở được):\n   {m.group(1)}")
        break
```

---

## Các tính năng khi mở Web Demo

| Tính năng | Mô tả |
|---|---|
| 🎨 **Dark Theme** | Nền #0f0f13, glassmorphism cards |
| 📝 **Textarea** | Nhập câu hỏi toán bất kỳ |
| 🔄 **WebSocket Streaming** | Token chạy real-time từng ký tự |
| 📊 **4-Stage Cards** | UNDERSTAND (xanh) → PLAN (tím) → EXECUTE (vàng) → VERIFY (xanh lá) |
| ✨ **Glow Effect** | Card đang active có viền sáng |
| 📚 **Problem Bank** | 15 bài mẫu (Easy / Medium / Vietnamese) |
| 🔀 **Mode Toggle** | "Show Steps" vs "Answer Only" |

---

## Cấu trúc Package

```
step-distill/
├── step_distill/
│   ├── core/
│   │   ├── inference.py    # NanoReason class (solve, solve_stream)
│   │   ├── trainer.py      # StepAwareTrainer (LoRA fine-tuning)
│   │   ├── loss.py         # StepAwareLoss (5 thành phần α,β,γ,δ,ε)
│   │   ├── parser.py       # LabelMatrixParser (4-stage extraction)
│   │   └── metrics.py      # Accuracy, RFS, SVR metrics
│   ├── app/
│   │   ├── server.py       # FastAPI backend + WebSocket
│   │   └── static/         # Frontend (HTML/CSS/JS)
│   ├── data/
│   │   ├── sources.py      # GSM8K, MATH, VNHSGE data loaders
│   │   └── pipeline.py     # TeacherPipeline (trace generation)
│   ├── cli/main.py         # CLI: generate, train, eval, demo, solve
│   └── config/config.py    # Pydantic config (from paper)
├── tests/                  # Unit + Integration tests
├── docs/                   # MkDocs documentation site
└── examples/               # 4 runnable example scripts
```

---

## Lệnh CLI

```bash
# Giải 1 bài toán
step-distill solve "2x + 5 = 11"

# Xem model khuyến nghị
step-distill generate --list-teachers
step-distill train --list-students

# Generate traces từ teacher
step-distill generate --teacher Qwen/Qwen2.5-7B-Instruct --sources gsm8k --max-samples 100

# Train student model
step-distill train --config config.yaml --data traces.jsonl

# Evaluate
step-distill eval --model ./my-model --benchmarks gsm8k math

# Launch web demo
step-distill demo --port 8000
```

---

## Citation

```bibtex
@inproceedings{phan2026nanoreason,
    title     = {NanoReason: Distilling Verifiable Chain-of-Thought Reasoning via Step-Aware LoRA},
    author    = {Phan, Duc Tai},
    year      = {2026},
    publisher = {Springer LNCS}
}
```

---

**License:** MIT  
**PyPI:** [pypi.org/project/step-distill](https://pypi.org/project/step-distill/)  
**Model:** [huggingface.co/ductaiphan/NanoReason-3B](https://huggingface.co/ductaiphan/NanoReason-3B)
