"""
NanoReason Inference Wrapper — Phase 9.

Provides:
- ``NanoReason.from_pretrained`` (auto-detects LoRA adapter vs merged)
- ``NanoReason.solve`` (single question → ``ReasoningResult``)
- ``NanoReason.solve_stream`` (async token-by-token with stage labels)
- ``NanoReason.solve_batch`` (batch inference)
"""

from __future__ import annotations

import os
import re
import time
import warnings
import asyncio
from threading import Thread
from dataclasses import dataclass, field
from typing import AsyncGenerator, Dict, List, Tuple, Any

import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TextIteratorStreamer,
    StoppingCriteria,
    StoppingCriteriaList,
)

from step_distill.core.parser import LabelMatrixParser, StepType


# ── Prompt template ─────────────────────────────────────────────────────
# Must match training format exactly: plain Question/Solution, no ChatML.
# The model was trained with this format and will auto-generate
# #### UNDERSTAND #### tags on its own — do NOT prepend them.

def _build_prompt(question: str) -> str:
    return f"Question: {question}\n\nSolution:\n"


class _StopOnBoxed(StoppingCriteria):
    """Stop generation once a complete \\boxed{...} is detected."""

    def __init__(self, tokenizer, input_len: int):
        self.tokenizer = tokenizer
        self.input_len = input_len
        self._stopped = False

    def __call__(self, input_ids, scores, **kwargs):
        if self._stopped:
            return True
        new_ids = input_ids[0][self.input_len:]
        text = self.tokenizer.decode(new_ids, skip_special_tokens=True)
        if "\\boxed{" in text:
            start = text.find("\\boxed{")
            depth = 0
            for i in range(start + 7, len(text)):
                if text[i] == "{":
                    depth += 1
                elif text[i] == "}":
                    if depth == 0:
                        self._stopped = True
                        return True
                    depth -= 1
        return False


class _StopOnFinalAnswer(StoppingCriteria):
    """Stop after the first complete 'Final Answer: <value>' line."""

    def __init__(self, tokenizer, input_len: int):
        self.tokenizer = tokenizer
        self.input_len = input_len
        self._stopped = False

    def __call__(self, input_ids, scores, **kwargs):
        if self._stopped:
            return True
        new_ids = input_ids[0][self.input_len:]
        text = self.tokenizer.decode(new_ids, skip_special_tokens=True)
        # Wait for COMPLETE answer line: "Final Answer: <value>\n"
        # The newline ensures the full value (e.g. "18" not just "1") has been generated
        m = re.search(r'(?i)final\s*answer\s*[:\-=]\s*.+\n', text)
        if m:
            self._stopped = True
            return True
        return False


def _get_eos_ids(tokenizer) -> list[int]:
    """Collect all valid EOS token IDs including <|im_end|>."""
    eos_ids = [tokenizer.eos_token_id]
    try:
        im_end_id = tokenizer.convert_tokens_to_ids("<|im_end|>")
        if im_end_id != tokenizer.unk_token_id and im_end_id not in eos_ids:
            eos_ids.append(im_end_id)
    except Exception:
        pass
    return eos_ids

# ── Output cleaning ──────────────────────────────────────────────────────
def _clean_raw_output(text: str) -> str:
    """Truncate output after the first complete answer marker.
    
    Handles two patterns:
    - ``\\boxed{...}`` — keep everything up to and including the closing brace
    - ``Final Answer: X`` — keep the first occurrence, discard repeats
    """
    # Case 1: If \boxed{} exists, truncate after the last complete \boxed{}
    if "\\boxed{" in text:
        idx = text.rfind("\\boxed{")
        i = idx + 7
        depth = 1
        while i < len(text) and depth > 0:
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
            i += 1
        return text[:i].strip()

    # Case 2: If "Final Answer:" exists, keep up to end of first answer line
    match = re.search(r"(?i)(final\s*answer\s*[:\-=]\s*\S.*)", text)
    if match:
        before = text[:match.end()]
        # Trim to just the first line of the answer
        answer_line = match.group(1).split("\n")[0].strip()
        pre_answer = text[:match.start()].strip()
        return f"{pre_answer}\n\n{answer_line}"

    return text.strip()


# ── Answer extraction helpers ───────────────────────────────────────────
def _extract_boxed_answer(text: str) -> str:
    """Extract the last ``\\boxed{...}`` answer, handling nested braces."""
    if not text:
        return ""
    tail = text[-800:]
    if "\\boxed{" in tail:
        idx = tail.rfind("\\boxed{")
        i = idx + 7
        stack = 1
        content: list[str] = []
        while i < len(tail) and stack > 0:
            if tail[i] == "{":
                stack += 1
            elif tail[i] == "}":
                stack -= 1
            if stack > 0:
                content.append(tail[i])
            i += 1
        return "".join(content).strip()
    # Fallback: "Final Answer: X" or "the answer is X"
    m = re.search(
        r"(?:final\s*answer|the\s+answer\s+is)\s*[:\-=]?\s*(.+?)(?:\.|$)",
        text, re.IGNORECASE | re.MULTILINE,
    )
    if m:
        ans = m.group(1).strip()
        if ans:
            return ans
    # Fallback: "#### N" (GSM8K format) — only match digits/math, NOT stage headers
    m = re.search(
        r"####\s*([-+]?[\d.,/]+(?:\s*%)?)",
        text,
    )
    if m:
        return m.group(1).strip()
    # Fallback: last number in text
    nums = re.findall(r"[-+]?\d*\.?\d+", text)
    return nums[-1] if nums else ""


# ── ReasoningResult ─────────────────────────────────────────────────────
@dataclass
class ReasoningResult:
    """Result container for a single NanoReason inference."""
    answer: str
    steps: Dict[str, str]       # {"understand": "...", "plan": "...", ...}
    rfs: float                  # 0.0 – 1.0
    raw_output: str = ""
    generation_time_s: float = 0.0

    def __repr__(self) -> str:
        width = 60
        lines: list[str] = []
        for stage in ("understand", "plan", "execute", "verify"):
            content = self.steps.get(stage, "")
            header = f" {stage.upper()} "
            top = f"┌─{header:─<{width - 3}}┐"
            bot = f"└{'─' * (width - 2)}┘"
            lines.append(top)
            for line in (content or "(empty)").split("\n"):
                truncated = line[: width - 4]
                lines.append(f"│ {truncated:<{width - 4}} │")
            lines.append(bot)
        lines.append(f"Answer: {self.answer}")
        lines.append(f"RFS: {self.rfs:.0%}  |  Time: {self.generation_time_s:.2f}s")
        return "\n".join(lines)


# ── Attention implementation auto-detection ──────────────────────────────
def _detect_attn_implementation() -> str:
    """Pick the fastest attention backend for the current hardware.

    Hierarchy (safest first):
    1. ``flash_attention_2`` — Ampere+ GPUs (A100/A10/H100) + ``flash-attn`` installed
    2. ``sdpa``              — PyTorch ≥ 2.0, works on ALL GPUs including T4
    3. ``eager``             — fallback
    """
    # Try Flash Attention 2 (Ampere+ only, compute capability >= 8.0)
    if torch.cuda.is_available():
        try:
            major, _ = torch.cuda.get_device_capability()
            if major >= 8:
                import flash_attn  # noqa: F401
                return "flash_attention_2"
        except (ImportError, Exception):
            pass

    # Try SDPA (built into PyTorch 2.0+, works on ALL GPUs including T4)
    if hasattr(torch.nn.functional, "scaled_dot_product_attention"):
        return "sdpa"

    # Fallback
    return "eager"


# ── NanoReason ──────────────────────────────────────────────────────────
class NanoReason:
    """Inference wrapper for NanoReason models.

    Auto-detects LoRA adapter vs merged checkpoint.
    """

    def __init__(self, model: Any, tokenizer: Any):
        self.model = model
        self.tokenizer = tokenizer

    # ── Factory ──────────────────────────────────────────────────────
    @classmethod
    def from_pretrained(
        cls,
        model_id: str,
        device: str = "auto",
        load_in_8bit: bool = False,
        **kwargs,
    ) -> "NanoReason":
        """Load model — auto-detects LoRA adapter vs merged weights.

        Parameters
        ----------
        model_id : str
            HuggingFace repo ID or local path.
        device : str
            ``"auto"`` (default), ``"cpu"``, or ``"cuda:0"``.
        load_in_8bit : bool
            If *True*, quantize to 8-bit via bitsandbytes.
        """
        tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)

        # Detect PEFT adapter — works for both local paths AND HuggingFace Hub IDs
        is_peft = False
        # Check local path first
        local_adapter = os.path.join(model_id, "adapter_config.json")
        if os.path.exists(local_adapter):
            is_peft = True
        else:
            # Check HuggingFace Hub
            try:
                from huggingface_hub import file_exists
                is_peft = file_exists(model_id, "adapter_config.json")
            except Exception:
                # If huggingface_hub is old or network fails, try PeftConfig
                try:
                    from peft import PeftConfig
                    PeftConfig.from_pretrained(model_id)
                    is_peft = True
                except Exception:
                    is_peft = False

        # Auto-detect best attention implementation for speed
        attn_impl = _detect_attn_implementation()
        print(f"⚡ Attention backend: {attn_impl}")

        load_kwargs: dict[str, Any] = {
            "device_map": device,
            "torch_dtype": torch.float16,
            "trust_remote_code": True,
            "attn_implementation": attn_impl,
        }
        if load_in_8bit:
            load_kwargs["load_in_8bit"] = True

        if is_peft:
            from peft import PeftConfig, PeftModel

            config = PeftConfig.from_pretrained(model_id)
            base_model = AutoModelForCausalLM.from_pretrained(
                config.base_model_name_or_path, **load_kwargs, **kwargs,
            )
            model = PeftModel.from_pretrained(base_model, model_id)
        else:
            model = AutoModelForCausalLM.from_pretrained(
                model_id, **load_kwargs, **kwargs,
            )

        model.eval()
        return cls(model, tokenizer)

    # ── Step extraction ──────────────────────────────────────────────
    def _extract_steps(self, text: str) -> Dict[str, str]:
        """Parse 4-stage tags from raw model output."""
        tags = {s.value: s.tag for s in StepType if s != StepType.IGNORE}
        steps: Dict[str, str] = {}
        current_stage: str | None = None
        current_content: list[str] = []

        pattern = r"(#### (?:UNDERSTAND|PLAN|EXECUTE|VERIFY) ####)"
        parts = re.split(pattern, text)

        for part in parts:
            part_stripped = part.strip()
            if not part_stripped:
                continue

            tag_matched = False
            for stage_name, tag in tags.items():
                if part_stripped == tag.strip():
                    if current_stage and current_content:
                        steps[current_stage] = "".join(current_content).strip()
                    current_stage = stage_name
                    current_content = []
                    tag_matched = True
                    break

            if not tag_matched and current_stage:
                current_content.append(part)

        if current_stage and current_content:
            steps[current_stage] = "".join(current_content).strip()

        return steps

    # ── Single inference ─────────────────────────────────────────────
    def solve(
        self,
        question: str,
        max_new_tokens: int = 512,
        repetition_penalty: float = 1.1,
        temperature: float = 0.1,
        do_sample: bool = True,
        **gen_kwargs,
    ) -> ReasoningResult:
        """Run single inference and return structured result."""
        prompt = _build_prompt(question)
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        input_len = inputs["input_ids"].shape[1]

        gen_config = {
            "max_new_tokens": max_new_tokens,
            "repetition_penalty": repetition_penalty,
            "temperature": temperature,
            "do_sample": do_sample,
            "pad_token_id": self.tokenizer.eos_token_id,
            "eos_token_id": _get_eos_ids(self.tokenizer),
            "stopping_criteria": StoppingCriteriaList([
                _StopOnBoxed(self.tokenizer, input_len),
                _StopOnFinalAnswer(self.tokenizer, input_len),
            ]),
        }
        gen_config.update(gen_kwargs)

        t0 = time.perf_counter()
        with torch.no_grad():
            outputs = self.model.generate(**inputs, **gen_config)
        generation_time = time.perf_counter() - t0

        generated_tokens = outputs[0][input_len:]
        raw_output = self.tokenizer.decode(generated_tokens, skip_special_tokens=True)

        # Post-process: truncate after first Final Answer or \boxed{}
        raw_output = _clean_raw_output(raw_output)

        steps = self._extract_steps(raw_output)

        # RFS: fraction of stages present with >=10 chars content (0.0–1.0)
        expected = {"understand", "plan", "execute", "verify"}
        present = {k for k in expected if len(steps.get(k, "").strip()) >= 10}
        rfs = len(present) / 4.0

        answer = _extract_boxed_answer(raw_output)

        return ReasoningResult(
            answer=answer,
            steps=steps,
            rfs=rfs,
            raw_output=raw_output,
            generation_time_s=generation_time,
        )

    # ── Streaming inference ──────────────────────────────────────────
    async def solve_stream(
        self,
        question: str,
        **gen_kwargs,
    ) -> AsyncGenerator[Tuple[str, str], None]:
        """Yield ``(token_text, stage_name)`` pairs.

        ``stage_name`` is one of:
        ``"understand"``, ``"plan"``, ``"execute"``, ``"verify"``,
        ``"answer"``, ``"other"``.
        """
        prompt = _build_prompt(question)
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        input_len = inputs["input_ids"].shape[1]

        streamer = TextIteratorStreamer(
            self.tokenizer, skip_prompt=True, skip_special_tokens=True,
        )

        generation_kwargs = dict(
            **inputs,
            streamer=streamer,
            max_new_tokens=gen_kwargs.pop("max_new_tokens", 512),
            repetition_penalty=gen_kwargs.pop("repetition_penalty", 1.1),
            temperature=gen_kwargs.pop("temperature", 0.1),
            do_sample=gen_kwargs.pop("do_sample", True),
            pad_token_id=self.tokenizer.eos_token_id,
            eos_token_id=_get_eos_ids(self.tokenizer),
            stopping_criteria=StoppingCriteriaList([
                _StopOnBoxed(self.tokenizer, input_len),
                _StopOnFinalAnswer(self.tokenizer, input_len),
            ]),
            **gen_kwargs,
        )

        thread = Thread(target=self.model.generate, kwargs=generation_kwargs)
        thread.start()

        tags = {s.value: s.tag for s in StepType if s != StepType.IGNORE}
        current_stage = "other"
        buffer = ""
        full_text = ""  # track everything for early stop detection
        stopped = False

        for new_text in streamer:
            if stopped:
                break

            buffer += new_text
            full_text += new_text

            # Early stop: if "Final Answer: <value>\n" detected in full stream
            fa_match = re.search(r'(?i)final\s*answer\s*[:\-=]\s*.+\n', full_text)
            if fa_match:
                # Emit everything up to and including the answer line, then stop
                remaining = buffer
                if remaining:
                    yield (remaining, current_stage)
                    await asyncio.sleep(0.0)
                stopped = True
                break

            # Early stop: if complete \boxed{} detected
            if "\\boxed{" in full_text:
                idx = full_text.find("\\boxed{")
                depth = 0
                for ci in range(idx + 7, len(full_text)):
                    if full_text[ci] == "{":
                        depth += 1
                    elif full_text[ci] == "}":
                        if depth == 0:
                            # Complete boxed answer found
                            if buffer:
                                yield (buffer, current_stage)
                                await asyncio.sleep(0.0)
                            stopped = True
                            break
                        depth -= 1
                if stopped:
                    break

            tag_found = False
            for stage_name, tag in tags.items():
                if tag in buffer:
                    parts = buffer.split(tag, 1)
                    if parts[0]:
                        yield (parts[0], current_stage)
                        await asyncio.sleep(0.0)

                    current_stage = stage_name
                    buffer = parts[1]
                    yield ("", current_stage)   # signal stage change
                    await asyncio.sleep(0.0)
                    tag_found = True
                    break

            if not tag_found and len(buffer) > 20:
                safe_len = len(buffer) - 20
                chunk = buffer[:safe_len]
                buffer = buffer[safe_len:]
                yield (chunk, current_stage)
                await asyncio.sleep(0.0)

        if buffer and not stopped:
            yield (buffer, current_stage)
            await asyncio.sleep(0.0)

        thread.join()

    # ── Batch inference ──────────────────────────────────────────────
    def solve_batch(
        self,
        questions: List[str],
        **kwargs,
    ) -> List[ReasoningResult]:
        """Run inference on a list of questions sequentially."""
        return [self.solve(q, **kwargs) for q in questions]
