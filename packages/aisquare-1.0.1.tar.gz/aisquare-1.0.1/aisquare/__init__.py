"""AISquare – namespace root for all AISquare packages.

Install extras for specific capabilities::

    pip install aisquare[explainability]
"""
