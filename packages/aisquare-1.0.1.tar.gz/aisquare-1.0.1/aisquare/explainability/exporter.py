"""
Custom OpenTelemetry SpanExporter that writes span batches to a local SQLite
inbox, grouped by trace_id.

This runs inside the BatchSpanProcessor's background thread, so all I/O in the
export path must remain synchronous. A small internal flush thread waits for a
trace to become idle before persisting it, which prevents common trace
fragmentation cases where the root span is exported before some child spans.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from collections import defaultdict
from typing import Sequence

from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

from aisquare.explainability.inbox import InboxWriter
from aisquare.explainability.serialisation import span_to_dict

logger = logging.getLogger(__name__)


class ExplainabilityExporter(SpanExporter):
    """
    Batches spans by ``trace_id`` and persists each batch to the local SQLite
    inbox.

    A trace is flushed when either:
    - the root span has been seen and the trace has been idle for
      ``idle_flush_seconds``; or
    - the trace has been buffered for longer than ``force_flush_seconds``.

    This reduces the risk of splitting one trace into multiple batches when the
    exporter receives the root span before late-arriving children.
    """

    def __init__(
        self,
        inbox: InboxWriter,
        *,
        idle_flush_seconds: float = 2.0,
        force_flush_seconds: float = 30.0,
        flush_interval_seconds: float = 0.5,
    ) -> None:
        self._inbox = inbox
        # Buffer: trace_id → list of span dicts
        self._buffer: dict[str, list[dict]] = defaultdict(list)
        # Track whether we've seen the root span per trace
        self._root_seen: set[str] = set()
        self._first_seen_at: dict[str, float] = {}
        self._last_seen_at: dict[str, float] = {}
        self._idle_flush_seconds = idle_flush_seconds
        self._force_flush_seconds = force_flush_seconds
        self._flush_interval_seconds = flush_interval_seconds
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._run_flush_loop,
            daemon=True,
            name="explainability-exporter-flush",
        )
        self._thread.start()

    # ------------------------------------------------------------------
    # SpanExporter interface
    # ------------------------------------------------------------------

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        try:
            now = time.monotonic()
            with self._lock:
                for span in spans:
                    ctx = span.get_span_context()
                    if ctx is None:
                        continue
                    trace_id = format(ctx.trace_id, "032x")
                    self._buffer[trace_id].append(span_to_dict(span))
                    self._first_seen_at.setdefault(trace_id, now)
                    self._last_seen_at[trace_id] = now

                    if span.parent is None:
                        self._root_seen.add(trace_id)

                self._flush_ready_locked(now)

            return SpanExportResult.SUCCESS
        except Exception:
            logger.exception("ExplainabilityExporter.export failed")
            return SpanExportResult.FAILURE

    def shutdown(self) -> None:
        self._stop.set()
        if self._thread.is_alive():
            self._thread.join(timeout=5)
        with self._lock:
            for tid in list(self._buffer.keys()):
                self._flush_locked(tid)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        with self._lock:
            for tid in list(self._buffer.keys()):
                self._flush_locked(tid)
        return True

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_flush_loop(self) -> None:
        while not self._stop.wait(self._flush_interval_seconds):
            try:
                now = time.monotonic()
                with self._lock:
                    self._flush_ready_locked(now)
            except Exception:
                logger.exception("ExplainabilityExporter background flush failed")

    def _flush_ready_locked(self, now: float) -> None:
        for trace_id in list(self._buffer.keys()):
            first_seen = self._first_seen_at.get(trace_id, now)
            last_seen = self._last_seen_at.get(trace_id, now)
            trace_age = now - first_seen
            idle_for = now - last_seen

            if trace_age >= self._force_flush_seconds or (
                trace_id in self._root_seen and idle_for >= self._idle_flush_seconds
            ):
                self._flush_locked(trace_id)

    def _flush(self, trace_id: str) -> None:
        with self._lock:
            self._flush_locked(trace_id)

    def _flush_locked(self, trace_id: str) -> None:
        spans = self._buffer.pop(trace_id, [])
        self._root_seen.discard(trace_id)
        self._first_seen_at.pop(trace_id, None)
        self._last_seen_at.pop(trace_id, None)
        if not spans:
            return
        payload = json.dumps({"trace_id": trace_id, "spans": spans})
        self._inbox.insert(trace_id, payload)
        logger.debug("Flushed %d spans for trace %s to inbox", len(spans), trace_id)
