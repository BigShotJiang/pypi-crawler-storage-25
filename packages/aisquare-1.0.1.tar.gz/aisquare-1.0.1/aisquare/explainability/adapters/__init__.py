"""
Adapter registry — maps platform names to adapter classes.

Built-in adapters are auto-registered on import.  Third-party adapters
can be added via ``register()``.

Usage::

    from aisquare.explainability.adapters import available_adapters, get_adapter

    # List platforms whose packages are installed
    available_adapters()   # e.g. ["agno", "langchain"]

    # Get an adapter instance
    adapter = get_adapter("agno")
    adapter.instrument(tracer)
"""

from __future__ import annotations

import logging
from typing import Dict, List, Type

from aisquare.explainability.adapters.base import BaseAdapter

logger = logging.getLogger(__name__)

_REGISTRY: Dict[str, Type[BaseAdapter]] = {}


def register(name: str, cls: Type[BaseAdapter]) -> None:
    """Register an adapter class under a platform name."""
    _REGISTRY[name] = cls


def get_adapter(name: str) -> BaseAdapter:
    """Instantiate and return the adapter for *name*."""
    cls = _REGISTRY.get(name)
    if cls is None:
        known = ", ".join(sorted(_REGISTRY.keys())) or "(none)"
        raise ValueError(
            f"Unknown adapter: {name!r}. Registered adapters: {known}"
        )
    return cls()


def available_adapters() -> List[str]:
    """Return names of adapters whose platform packages are importable."""
    result: List[str] = []
    for name, cls in _REGISTRY.items():
        try:
            if cls().is_available():
                result.append(name)
        except Exception:
            logger.debug("Error checking availability of adapter %s", name, exc_info=True)
    return result


def all_adapters() -> List[str]:
    """Return all registered adapter names (installed or not)."""
    return sorted(_REGISTRY.keys())


# ------------------------------------------------------------------
# Auto-register built-in adapters
# ------------------------------------------------------------------

from aisquare.explainability.adapters.agno import AgnoAdapter  # noqa: E402

register("agno", AgnoAdapter)

# LangChain and CrewAI adapters will be registered here once implemented:
#
# try:
#     from aisquare.explainability.adapters.langchain import LangChainAdapter
#     register("langchain", LangChainAdapter)
# except ImportError:
#     pass
#
# try:
#     from aisquare.explainability.adapters.crewai import CrewAIAdapter
#     register("crewai", CrewAIAdapter)
# except ImportError:
#     pass
