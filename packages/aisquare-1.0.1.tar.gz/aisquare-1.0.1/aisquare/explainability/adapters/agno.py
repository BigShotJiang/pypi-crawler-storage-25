"""
Agno platform adapter.

Installs the OpenInference Agno instrumentor (if available) which
automatically captures Agno agent runs, LLM calls, and tool invocations
as OpenTelemetry spans.

This is the adapter extracted from the original ``hooks.py``.
"""

from __future__ import annotations

import logging
from importlib.util import find_spec

from opentelemetry import trace

from aisquare.explainability.adapters.base import BaseAdapter

logger = logging.getLogger(__name__)


class AgnoAdapter(BaseAdapter):
    """
    Instruments `agno <https://github.com/agno-agi/agno>`_ agents.

    Uses the ``openinference-instrumentation-agno`` package for automatic
    span emission.  Falls back gracefully when the package is not installed
    — manual tracers still work.
    """

    name = "agno"

    def __init__(self) -> None:
        self._instrumented = False

    def is_available(self) -> bool:
        return find_spec("agno") is not None

    def instrument(self, tracer: trace.Tracer) -> None:
        if self._instrumented:
            return

        # Best-effort OpenInference auto-instrumentation
        try:
            if find_spec("openinference.instrumentation.agno") is None:
                logger.info(
                    "openinference-instrumentation-agno not installed; "
                    "Agno spans will only appear via manual tracers."
                )
                return

            from openinference.instrumentation.agno import AgnoInstrumentor

            instrumentor = AgnoInstrumentor()
            if not instrumentor.is_instrumented_by_opentelemetry:
                instrumentor.instrument()
                logger.info("OpenInference Agno instrumentation installed")
        except Exception:
            logger.exception("Failed to auto-instrument Agno")
            return

        self._instrumented = True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from openinference.instrumentation.agno import AgnoInstrumentor

            instrumentor = AgnoInstrumentor()
            if instrumentor.is_instrumented_by_opentelemetry:
                instrumentor.uninstrument()
        except Exception:
            logger.exception("Failed to uninstrument Agno")

        self._instrumented = False
