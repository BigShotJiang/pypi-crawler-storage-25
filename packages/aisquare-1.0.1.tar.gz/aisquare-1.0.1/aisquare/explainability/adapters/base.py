"""
Base class for all platform adapters.

Every adapter translates a specific framework's execution events into
OpenTelemetry spans with OpenInference semantic conventions.  The gateway
processes these spans identically regardless of which adapter produced them.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from opentelemetry import trace


class BaseAdapter(ABC):
    """
    Abstract base for platform adapters.

    Subclasses must implement:

    - ``name`` — short identifier (``"agno"``, ``"langchain"``, ``"crewai"``)
    - ``is_available()`` — whether the platform's packages are importable
    - ``instrument(tracer)`` — hook into the platform and emit OTel spans
    - ``uninstrument()`` — restore original behaviour

    The gateway expects spans with these OpenInference attributes:

    - ``openinference.span.kind`` = ``AGENT | LLM | TOOL | CHAIN | RETRIEVER``
    - ``input.value`` / ``llm.input_messages``
    - ``output.value`` / ``llm.output_messages``
    - ``agent.name``, ``llm.model_name``, ``tool.name``
    - ``llm.token_count.prompt``, ``llm.token_count.completion``, ``llm.token_count.total``
    """

    name: str = "unknown"

    @abstractmethod
    def is_available(self) -> bool:
        """Return ``True`` if the platform's packages are importable."""
        ...

    @abstractmethod
    def instrument(self, tracer: trace.Tracer) -> None:
        """Activate instrumentation.  Called once during ``sdk.init()``."""
        ...

    @abstractmethod
    def uninstrument(self) -> None:
        """Deactivate instrumentation and restore original behaviour."""
        ...

    @property
    def is_instrumented(self) -> bool:
        """Whether ``instrument()`` has been called successfully."""
        return getattr(self, "_instrumented", False)
