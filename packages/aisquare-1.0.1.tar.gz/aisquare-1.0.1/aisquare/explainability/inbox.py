"""
SQLite durability inbox — synchronous writes only.

The OTel ``BatchSpanProcessor`` calls ``export()`` from a dedicated background
thread that has **no** async event loop. All persistence inside that call-path
must be plain synchronous SQLite.

The sweeper reads rows asynchronously via ``aiosqlite`` and uses the inbox as
its source of truth for retries, backoff, and dead-letter handling.
"""

from __future__ import annotations

import logging
import sqlite3
import threading
from typing import Optional

logger = logging.getLogger(__name__)


class InboxWriter:
    """
    Synchronous SQLite writer used by the exporter.

    Thread-safe — a single ``sqlite3.Connection`` is protected by a lock.
    """

    TABLE_DDL = """
    CREATE TABLE IF NOT EXISTS inbox (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        trace_id         TEXT    NOT NULL,
        payload          TEXT    NOT NULL,
        status           TEXT    NOT NULL DEFAULT 'pending',
        retries          INTEGER NOT NULL DEFAULT 0,
        next_attempt_at  TEXT    NOT NULL DEFAULT (datetime('now')),
        last_error       TEXT,
        created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
        updated_at       TEXT    NOT NULL DEFAULT (datetime('now'))
    );
    """

    INDEX_DDL = """
    CREATE INDEX IF NOT EXISTS idx_inbox_status ON inbox (status);
    CREATE INDEX IF NOT EXISTS idx_inbox_status_next_attempt
        ON inbox (status, next_attempt_at);
    """

    def __init__(self, db_path: str = "explainability_inbox.db") -> None:
        self._db_path = db_path
        self._lock = threading.Lock()
        self._conn: Optional[sqlite3.Connection] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def ensure_schema(self) -> None:
        """Create the inbox table if it does not exist (idempotent)."""
        conn = self._get_conn()
        with self._lock:
            conn.executescript(self.TABLE_DDL)
            self._migrate_schema(conn)
            conn.executescript(self.INDEX_DDL)
            conn.commit()

    def insert(self, trace_id: str, payload: str) -> None:
        """Insert a pending row (synchronous, called from OTel thread)."""
        conn = self._get_conn()
        with self._lock:
            conn.execute(
                """
                INSERT INTO inbox (trace_id, payload, status, next_attempt_at)
                VALUES (?, ?, 'pending', datetime('now'))
                """,
                (trace_id, payload),
            )
            conn.commit()
        logger.debug("Inbox: inserted trace %s", trace_id)

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
        return self._conn

    def _migrate_schema(self, conn: sqlite3.Connection) -> None:
        """Best-effort schema migration for older local inbox databases."""
        columns = {row[1] for row in conn.execute("PRAGMA table_info(inbox)").fetchall()}

        if "next_attempt_at" not in columns:
            conn.execute("ALTER TABLE inbox ADD COLUMN next_attempt_at TEXT")
            conn.execute(
                "UPDATE inbox SET next_attempt_at = datetime('now') WHERE next_attempt_at IS NULL"
            )

        if "last_error" not in columns:
            conn.execute("ALTER TABLE inbox ADD COLUMN last_error TEXT")
