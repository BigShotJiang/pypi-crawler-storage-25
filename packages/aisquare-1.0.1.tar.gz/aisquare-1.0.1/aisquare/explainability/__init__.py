"""
AISquare Explainability SDK.

Captures execution traces via OpenTelemetry, buffers them durably in a local
SQLite inbox, and dispatches them to the Explainability Gateway for structural
graph loading and RML extraction.

Quick start::

    import aisquare.explainability as sdk
    sdk.init_from_env()

Manual instrumentation (works with any Python code — no framework required)::

    from aisquare.explainability import AgentRunTracer, LLMCallTracer

    with AgentRunTracer(agent_name="MyAgent", run_id="abc") as run:
        run.set_input("User query")
        with LLMCallTracer(model="gpt-4o-mini") as llm:
            ...
        run.set_output("Agent response")

Auto-instrumentation (adapters detect and hook into frameworks)::

    # Auto-detect installed platforms (Agno, LangChain, CrewAI, …)
    sdk.init_from_env()  # auto_instrument=True by default

    # Or specify explicitly
    sdk.init_from_env(auto_instrument=["agno", "langchain"])
"""

__version__ = "1.0.0"

# --- Core init ---
# --- Adapter access (advanced) ---
from aisquare.explainability.adapters import (  # noqa: F401
    all_adapters,
    available_adapters,
    get_adapter,
)

# --- Decorators (platform-agnostic) ---
from aisquare.explainability.decorators import (  # noqa: F401
    trace_retrieval,
    trace_tool,
)
from aisquare.explainability.main import flush, init, init_from_env  # noqa: F401

# --- Manual tracers (platform-agnostic) ---
from aisquare.explainability.tracers import (  # noqa: F401
    AgentRunTracer,
    HumanInterventionTracer,
    LLMCallTracer,
    MemoryTracer,
    RetrievalTracer,
    RoutingTracer,
    ToolCallTracer,
    artifact_id,
    get_tracer,
)

__all__ = [
    # Init
    "init",
    "init_from_env",
    "flush",
    # Tracers
    "AgentRunTracer",
    "LLMCallTracer",
    "ToolCallTracer",
    "RetrievalTracer",
    "HumanInterventionTracer",
    "RoutingTracer",
    "MemoryTracer",
    "artifact_id",
    "get_tracer",
    # Decorators
    "trace_tool",
    "trace_retrieval",
    # Adapters
    "available_adapters",
    "all_adapters",
    "get_adapter",
    # Meta
    "__version__",
]
