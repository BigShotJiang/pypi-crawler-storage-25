"""
Platform-agnostic manual tracers for the Explainability SDK.

These work with ANY Python code — no framework required.  They emit
OpenTelemetry spans using the OpenInference semantic conventions that
the Explainability Gateway processes.

Usage::

    import aisquare.explainability as sdk
    sdk.init_from_env()

    with sdk.AgentRunTracer(agent_name="MyAgent", run_id="abc") as run:
        run.set_input("User query")
        with sdk.LLMCallTracer(model="gpt-4o-mini") as llm:
            ...
        run.set_output("Agent response")
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict, List, Optional

from opentelemetry import context as context_api
from opentelemetry import trace

logger = logging.getLogger(__name__)


# =====================================================================
# Tracer accessor — platform-agnostic
# =====================================================================


def get_tracer(name: str = "explainability-sdk") -> trace.Tracer:
    """
    Return a tracer bound to the global OTel ``TracerProvider``.

    Works regardless of which platform adapter (Agno, LangChain, CrewAI …)
    was installed — or none at all.  Raises ``RuntimeError`` if the SDK
    has not been initialised yet (no ``TracerProvider`` configured).
    """
    provider = trace.get_tracer_provider()
    # The default NoOpTracerProvider is returned when no real provider is set.
    # We still return a tracer — it will simply produce no-op spans, which is
    # the correct degraded behaviour before init() is called.
    return provider.get_tracer(name, "0.1.0")


# =====================================================================
# Helper — content-addressed artifact ID
# =====================================================================


def artifact_id(content: str) -> str:
    """SHA-256 first 16 hex chars — deterministic, deduplicating."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]


# =====================================================================
# 1.  Agent Run tracer
# =====================================================================


class AgentRunTracer:
    """
    Context manager that wraps an entire agent run.

    Usage::

        with AgentRunTracer(agent_name="ResearchAgent", run_id="abc") as run:
            run.set_input("User query")
            # ... agent execution ...
            run.set_output("Agent response")
            run.set_status("completed")
    """

    def __init__(
        self,
        agent_name: str,
        run_id: str,
        *,
        model: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.agent_name = agent_name
        self.run_id = run_id
        self.model = model
        self.metadata = metadata or {}
        self._span: Optional[trace.Span] = None
        self._token: Optional[Any] = None

    def __enter__(self) -> "AgentRunTracer":
        tracer = get_tracer()
        ctx = trace.set_span_in_context(trace.INVALID_SPAN)
        self._span = tracer.start_span(
            name=f"AgentRun:{self.agent_name}",
            context=ctx,
            attributes={
                "openinference.span.kind": "AGENT",
                "agent.name": self.agent_name,
                "agent.run_id": self.run_id,
                **({"llm.model_name": self.model} if self.model else {}),
                **{f"agent.metadata.{k}": str(v) for k, v in self.metadata.items()},
            },
        )
        self._token = context_api.attach(trace.set_span_in_context(self._span))
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._span is None:
            return
        if exc_type is not None:
            self._span.set_status(trace.StatusCode.ERROR, str(exc_val))
            self._span.record_exception(exc_val)
        else:
            self._span.set_status(trace.StatusCode.OK)
        self._span.end()
        if self._token:
            context_api.detach(self._token)

    def set_status(self, status: str) -> None:
        if self._span:
            self._span.set_attribute("agent.run.status", status)

    def set_output(self, output: str) -> None:
        if self._span:
            self._span.set_attribute("output.value", output)

    def set_input(self, input_text: str) -> None:
        if self._span:
            self._span.set_attribute("input.value", input_text)

    @property
    def span(self) -> Optional[trace.Span]:
        return self._span

    def __repr__(self) -> str:
        return f"AgentRunTracer(agent_name={self.agent_name!r}, run_id={self.run_id!r})"


# =====================================================================
# 2.  LLM Call tracer
# =====================================================================


class LLMCallTracer:
    """
    Wraps a single LLM inference call.

    Usage::

        with LLMCallTracer(model="claude-3-haiku", provider="anthropic") as llm:
            llm.set_input_messages([{"role": "user", "content": "Hello"}])
            result = call_llm(...)
            llm.set_output_messages([{"role": "assistant", "content": result}])
            llm.set_token_counts(prompt=100, completion=50)
    """

    def __init__(
        self,
        model: str,
        *,
        provider: Optional[str] = None,
        temperature: Optional[float] = None,
    ) -> None:
        self.model = model
        self.provider = provider
        self.temperature = temperature
        self._span: Optional[trace.Span] = None

    def __enter__(self) -> "LLMCallTracer":
        tracer = get_tracer()
        attrs: Dict[str, Any] = {
            "openinference.span.kind": "LLM",
            "llm.model_name": self.model,
        }
        if self.provider:
            attrs["llm.provider"] = self.provider
        if self.temperature is not None:
            attrs["llm.temperature"] = self.temperature

        self._span = tracer.start_span(name=f"LLM:{self.model}", attributes=attrs)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._span is None:
            return
        if exc_type is not None:
            self._span.set_status(trace.StatusCode.ERROR, str(exc_val))
            self._span.record_exception(exc_val)
        else:
            self._span.set_status(trace.StatusCode.OK)
        self._span.end()

    def set_input_messages(self, messages: List[Dict[str, Any]]) -> None:
        if self._span:
            self._span.set_attribute("llm.input_messages", json.dumps(messages))

    def set_output_messages(self, messages: List[Dict[str, Any]]) -> None:
        if self._span:
            self._span.set_attribute("llm.output_messages", json.dumps(messages))

    def set_token_counts(
        self,
        prompt: int = 0,
        completion: int = 0,
        total: Optional[int] = None,
    ) -> None:
        if self._span:
            self._span.set_attribute("llm.token_count.prompt", prompt)
            self._span.set_attribute("llm.token_count.completion", completion)
            self._span.set_attribute("llm.token_count.total", total or (prompt + completion))

    def __repr__(self) -> str:
        return f"LLMCallTracer(model={self.model!r}, provider={self.provider!r})"


# =====================================================================
# 3.  Tool Call tracer
# =====================================================================


class ToolCallTracer:
    """
    Wraps a single tool invocation (function call, API call, etc.).

    Usage::

        with ToolCallTracer(tool_name="web_search", tool_version="1.0") as tool:
            tool.set_parameters({"query": "latest AI papers"})
            result = web_search(query="latest AI papers")
            tool.set_result(result)
    """

    def __init__(
        self,
        tool_name: str,
        *,
        tool_version: Optional[str] = None,
    ) -> None:
        self.tool_name = tool_name
        self.tool_version = tool_version
        self._span: Optional[trace.Span] = None

    def __enter__(self) -> "ToolCallTracer":
        tracer = get_tracer()
        attrs: Dict[str, Any] = {
            "openinference.span.kind": "TOOL",
            "tool.name": self.tool_name,
        }
        if self.tool_version:
            attrs["tool.version"] = self.tool_version
        self._span = tracer.start_span(name=f"Tool:{self.tool_name}", attributes=attrs)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._span is None:
            return
        if exc_type is not None:
            self._span.set_status(trace.StatusCode.ERROR, str(exc_val))
            self._span.record_exception(exc_val)
        else:
            self._span.set_status(trace.StatusCode.OK)
        self._span.end()

    def set_parameters(self, params: Dict[str, Any]) -> None:
        if self._span:
            self._span.set_attribute("tool.parameters", json.dumps(params))

    def set_result(self, result: Any) -> None:
        if self._span:
            self._span.set_attribute("output.value", str(result))

    def set_error(self, error: str) -> None:
        if self._span:
            self._span.set_attribute("tool.error", error)

    def __repr__(self) -> str:
        return f"ToolCallTracer(tool_name={self.tool_name!r})"


# =====================================================================
# 4.  RAG / Retrieval tracer
# =====================================================================


class RetrievalTracer:
    """
    Wraps a retrieval / RAG operation (vector search, document fetch, etc.).

    Usage::

        with RetrievalTracer(source="pinecone", query="climate change") as ret:
            docs = vector_search(query="climate change")
            ret.set_documents(docs)
    """

    def __init__(
        self,
        source: str,
        *,
        query: Optional[str] = None,
    ) -> None:
        self.source = source
        self.query = query
        self._span: Optional[trace.Span] = None

    def __enter__(self) -> "RetrievalTracer":
        tracer = get_tracer()
        attrs: Dict[str, Any] = {
            "openinference.span.kind": "RETRIEVER",
            "retrieval.source": self.source,
        }
        if self.query:
            attrs["input.value"] = self.query
        self._span = tracer.start_span(name=f"Retrieval:{self.source}", attributes=attrs)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._span is None:
            return
        if exc_type is not None:
            self._span.set_status(trace.StatusCode.ERROR, str(exc_val))
            self._span.record_exception(exc_val)
        else:
            self._span.set_status(trace.StatusCode.OK)
        self._span.end()

    def set_documents(self, documents: List[Dict[str, Any]]) -> None:
        """Record retrieved documents with their metadata and scores."""
        if self._span:
            self._span.set_attribute("retrieval.documents", json.dumps(documents))
            self._span.set_attribute("retrieval.document_count", len(documents))

    def set_query_embedding(self, embedding_model: str) -> None:
        if self._span:
            self._span.set_attribute("retrieval.embedding_model", embedding_model)

    def set_top_k(self, k: int) -> None:
        if self._span:
            self._span.set_attribute("retrieval.top_k", k)

    def set_filter(self, filter_expr: str) -> None:
        if self._span:
            self._span.set_attribute("retrieval.filter", filter_expr)

    def __repr__(self) -> str:
        return f"RetrievalTracer(source={self.source!r}, query={self.query!r})"


# =====================================================================
# 5.  Human-in-the-Loop tracer
# =====================================================================


class HumanInterventionTracer:
    """
    Records a human-in-the-loop intervention (approval, rejection, edit, etc.).

    Usage::

        with HumanInterventionTracer(
            human_id="user@example.com",
            action="approve",
            reason="Output looks correct",
        ) as hit:
            hit.set_original_output("The capital of France is Berlin.")
            hit.set_corrected_output("The capital of France is Paris.")
    """

    def __init__(
        self,
        human_id: str,
        *,
        action: str = "intervene",
        reason: Optional[str] = None,
        role: Optional[str] = None,
    ) -> None:
        self.human_id = human_id
        self.action = action
        self.reason = reason
        self.role = role
        self._span: Optional[trace.Span] = None

    def __enter__(self) -> "HumanInterventionTracer":
        tracer = get_tracer()
        attrs: Dict[str, Any] = {
            "openinference.span.kind": "CHAIN",
            "human.id": self.human_id,
            "human.action": self.action,
            "intervention": "true",
        }
        if self.reason:
            attrs["human.reason"] = self.reason
        if self.role:
            attrs["human.role"] = self.role
        self._span = tracer.start_span(
            name=f"HumanIntervention:{self.action}",
            attributes=attrs,
        )
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._span is None:
            return
        if exc_type is not None:
            self._span.set_status(trace.StatusCode.ERROR, str(exc_val))
            self._span.record_exception(exc_val)
        else:
            self._span.set_status(trace.StatusCode.OK)
        self._span.end()

    def set_original_output(self, output: str) -> None:
        if self._span:
            self._span.set_attribute("human.original_output", output)

    def set_corrected_output(self, output: str) -> None:
        if self._span:
            self._span.set_attribute("human.corrected_output", output)
            self._span.set_attribute("output.value", output)

    def __repr__(self) -> str:
        return f"HumanInterventionTracer(human_id={self.human_id!r}, action={self.action!r})"


# =====================================================================
# 6.  Routing / Delegation tracer
# =====================================================================


class RoutingTracer:
    """
    Records a routing or delegation decision (agent choosing which sub-agent
    or tool to use, path selection, etc.).

    Usage::

        with RoutingTracer(decision_type="agent_delegation") as rt:
            rt.set_selected("SummaryAgent", reason="User asked for summary")
            rt.set_rejected([
                {"name": "SearchAgent", "reason": "Not a search query"},
            ])
    """

    def __init__(
        self,
        decision_type: str = "routing",
    ) -> None:
        self.decision_type = decision_type
        self._span: Optional[trace.Span] = None

    def __enter__(self) -> "RoutingTracer":
        tracer = get_tracer()
        self._span = tracer.start_span(
            name=f"Routing:{self.decision_type}",
            attributes={
                "openinference.span.kind": "CHAIN",
                "routing.decision_type": self.decision_type,
            },
        )
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._span is None:
            return
        if exc_type is not None:
            self._span.set_status(trace.StatusCode.ERROR, str(exc_val))
            self._span.record_exception(exc_val)
        else:
            self._span.set_status(trace.StatusCode.OK)
        self._span.end()

    def set_selected(self, target: str, *, reason: Optional[str] = None) -> None:
        if self._span:
            self._span.set_attribute("routing.selected", target)
            if reason:
                self._span.set_attribute("routing.selected_reason", reason)
            self._span.set_attribute(
                "routing.selected_json",
                json.dumps({"target": target, "reason": reason}),
            )

    def set_rejected(self, alternatives: List[Dict[str, str]]) -> None:
        if self._span:
            self._span.set_attribute("routing.rejected", json.dumps(alternatives))

    def __repr__(self) -> str:
        return f"RoutingTracer(decision_type={self.decision_type!r})"


# =====================================================================
# 7.  Memory Read / Write tracer
# =====================================================================


class MemoryTracer:
    """
    Records memory operations — reads from and writes to agent memory
    (short-term, long-term, episodic, etc.).

    Usage::

        with MemoryTracer(operation="read", memory_type="long_term") as mem:
            mem.set_query("previous conversation about project X")
            results = memory_store.search(...)
            mem.set_results(results)
    """

    def __init__(
        self,
        operation: str,
        *,
        memory_type: str = "default",
    ) -> None:
        self.operation = operation
        self.memory_type = memory_type
        self._span: Optional[trace.Span] = None

    def __enter__(self) -> "MemoryTracer":
        tracer = get_tracer()
        self._span = tracer.start_span(
            name=f"Memory:{self.operation}:{self.memory_type}",
            attributes={
                "openinference.span.kind": "CHAIN",
                "memory.operation": self.operation,
                "memory.type": self.memory_type,
            },
        )
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._span is None:
            return
        if exc_type is not None:
            self._span.set_status(trace.StatusCode.ERROR, str(exc_val))
            self._span.record_exception(exc_val)
        else:
            self._span.set_status(trace.StatusCode.OK)
        self._span.end()

    def set_query(self, query: str) -> None:
        if self._span:
            self._span.set_attribute("memory.query", query)

    def set_results(self, results: List[Dict[str, Any]]) -> None:
        if self._span:
            self._span.set_attribute("memory.results", json.dumps(results))
            self._span.set_attribute("memory.result_count", len(results))

    def set_content(self, content: str) -> None:
        """For write operations — the content being stored."""
        if self._span:
            self._span.set_attribute("memory.content", content)

    def set_key(self, key: str) -> None:
        if self._span:
            self._span.set_attribute("memory.key", key)

    def __repr__(self) -> str:
        return f"MemoryTracer(operation={self.operation!r}, memory_type={self.memory_type!r})"
