"""
SDK entry point — wires OTel instrumentation, inbox, sweeper, and platform
adapters.

Platform-agnostic: the ``auto_instrument`` parameter controls which adapters
are activated.  Manual tracers (``AgentRunTracer``, ``LLMCallTracer``, …)
work regardless of which adapter (or none) is installed.
"""

from __future__ import annotations

import atexit
import logging
import os
import threading
import warnings
from typing import List, Optional, Union

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from aisquare.explainability.exporter import ExplainabilityExporter
from aisquare.explainability.inbox import InboxWriter
from aisquare.explainability.sweeper import InboxSweeper

logger = logging.getLogger(__name__)

_INIT_LOCK = threading.Lock()
_INITIALIZED = False
_sweeper: Optional[InboxSweeper] = None
_exporter: Optional[ExplainabilityExporter] = None
_provider: Optional[TracerProvider] = None
_inbox: Optional[InboxWriter] = None

DEFAULT_GATEWAY_ENV = "EXPLAINABILITY_GATEWAY_URL"
DEFAULT_API_KEY_ENV = "EXPLAINABILITY_API_KEY"
DEFAULT_INBOX_ENV = "EXPLAINABILITY_INBOX_PATH"
DEFAULT_GATEWAY_URL = "https://dev-explainability.api.aisquare.studio"


def _shutdown() -> None:
    """Invoked on interpreter exit to ensure the sweeper drops its final batch."""
    global _sweeper, _exporter, _provider, _inbox
    if _provider is not None:
        try:
            _provider.force_flush()
        except Exception:
            logger.exception("Failed to force flush tracer provider during shutdown")

    if _exporter is not None:
        try:
            _exporter.shutdown()
        except Exception:
            logger.exception("Failed to shut down exporter cleanly")
        finally:
            _exporter = None

    if _sweeper is not None:
        logger.info("Explainability SDK shutting down -> flushing traces...")
        _sweeper.stop()
        _sweeper = None

    if _inbox is not None:
        try:
            _inbox.close()
        except Exception:
            logger.exception("Failed to close SDK inbox cleanly")
        finally:
            _inbox = None

    _provider = None


def _resolve_platforms(
    auto_instrument: Union[bool, str, List[str]],
) -> List[str]:
    """
    Normalise the ``auto_instrument`` parameter into a list of adapter names.

    * ``True``  → auto-detect every installed platform
    * ``False`` → empty list (no auto-instrumentation)
    * ``"agno"`` → ``["agno"]``
    * ``["agno", "langchain"]`` → pass-through
    """
    if auto_instrument is False:
        return []

    if auto_instrument is True:
        from aisquare.explainability.adapters import available_adapters

        return available_adapters()

    if isinstance(auto_instrument, str):
        return [auto_instrument]

    return list(auto_instrument)


def _instrument_platforms(platforms: List[str], service_name: str) -> None:
    """Instantiate and activate adapters for each requested platform."""
    if not platforms:
        return

    from aisquare.explainability.adapters import get_adapter

    tracer = trace.get_tracer(service_name, "0.1.0")

    for platform in platforms:
        try:
            adapter = get_adapter(platform)
            adapter.instrument(tracer)
            logger.info("Auto-instrumented platform: %s", platform)
        except ValueError:
            logger.warning(
                "Adapter %r is not registered — skipping.  "
                "Available adapters can be listed with "
                "aisquare.explainability.adapters.all_adapters().",
                platform,
            )
        except Exception:
            logger.exception("Failed to auto-instrument platform %s", platform)


def init(
    gateway_url: str = DEFAULT_GATEWAY_URL,
    api_key: str = "",
    *,
    inbox_path: str = "explainability_inbox.db",
    sweep_interval: float = 5.0,
    max_retry: int = 5,
    auto_instrument: Union[bool, str, List[str]] = True,
    service_name: str = "explainability-agent",
    # ------------------------------------------------------------------
    # Backward-compat: ``install_hooks`` still accepted but deprecated.
    # ------------------------------------------------------------------
    install_hooks: Optional[bool] = None,
) -> None:
    """
    Initialise the Explainability SDK.  Idempotent — second call is a no-op.

    1. Creates / opens the local SQLite inbox for durability.
    2. Registers a custom OTel SpanExporter that writes to the inbox.
    3. Starts a background sweeper that dispatches buffered traces to the
       gateway.
    4. Optionally auto-instruments detected platforms (Agno, LangChain, …).

    Parameters
    ----------
    gateway_url : str
        Base URL of the Explainability Gateway.  Defaults to
        ``https://dev-explainability.api.aisquare.studio``.
    api_key : str
        Bearer token sent with every ingest request.
    inbox_path : str
        File path for the SQLite inbox database.
    sweep_interval : float
        Seconds between sweeper runs.
    max_retry : int
        Maximum retry attempts per inbox row before marking it as dead-letter.
    auto_instrument : bool | str | list[str]
        Controls which platform adapters are activated:

        * ``True`` *(default)* — auto-detect installed platforms and instrument
          all of them.
        * ``False`` — skip auto-instrumentation; manual tracers still work.
        * ``"agno"`` or ``["agno", "langchain"]`` — instrument only the listed
          platforms.
    service_name : str
        OTel service name attribute.
    install_hooks : bool | None
        **Deprecated** — use ``auto_instrument`` instead.  Kept for backward
        compatibility: ``True`` maps to ``auto_instrument=True``, ``False``
        maps to ``auto_instrument=False``.
    """
    global _INITIALIZED, _sweeper, _exporter, _provider, _inbox

    # Handle deprecated install_hooks parameter
    if install_hooks is not None:
        warnings.warn(
            "install_hooks is deprecated — use auto_instrument instead.  "
            "install_hooks=True → auto_instrument=True, "
            "install_hooks=False → auto_instrument=False.",
            DeprecationWarning,
            stacklevel=2,
        )
        auto_instrument = install_hooks

    with _INIT_LOCK:
        if _INITIALIZED:
            logger.debug("Explainability SDK already initialised - skipping.")
            return

        # --- OTel pipeline (platform-agnostic) ---

        inbox = InboxWriter(inbox_path)
        inbox.ensure_schema()
        _inbox = inbox

        exporter = ExplainabilityExporter(inbox=inbox)
        resource = Resource.create(
            {
                "service.name": service_name,
                "telemetry.sdk.name": "aisquare-explainability",
                "deployment.environment": os.getenv("EXPLAINABILITY_ENV", "development"),
            }
        )
        existing_provider = trace.get_tracer_provider()
        if isinstance(existing_provider, TracerProvider):
            provider = existing_provider
        else:
            provider = TracerProvider(resource=resource)
            trace.set_tracer_provider(provider)

        provider.add_span_processor(BatchSpanProcessor(exporter))
        _exporter = exporter
        _provider = provider

        # --- Inbox sweeper (platform-agnostic) ---

        _sweeper = InboxSweeper(
            inbox_path=inbox_path,
            gateway_url=gateway_url,
            api_key=api_key,
            interval=sweep_interval,
            max_retry=max_retry,
        )
        _sweeper.start()
        atexit.register(_shutdown)

        # --- Platform auto-instrumentation ---

        platforms = _resolve_platforms(auto_instrument)
        _instrument_platforms(platforms, service_name)

        _INITIALIZED = True
        logger.info(
            "Explainability SDK initialised (gateway=%s, inbox=%s, platforms=%s)",
            gateway_url,
            inbox_path,
            platforms or "(manual only)",
        )


def flush(timeout: float = 15.0) -> None:
    """
    Force-flush all buffered traces to the gateway synchronously.

    Short-lived scripts (one-off CLI tools, test harnesses, Jupyter notebooks)
    should call this before exiting to guarantee every trace is dispatched::

        import aisquare.explainability as sdk

        sdk.init_from_env()
        agent.run(...)
        sdk.flush()          # blocks until traces reach the gateway

    Long-running services (FastAPI, Django, daemons) do **not** need this — the
    background sweeper dispatches traces automatically every ``sweep_interval``
    seconds.

    Parameters
    ----------
    timeout : float
        Maximum seconds to wait for the gateway to acknowledge all pending
        traces. Defaults to 15 seconds.
    """
    import time as _time

    global _provider, _exporter, _sweeper

    deadline = _time.monotonic() + timeout

    # 1. Force OTel BatchSpanProcessor to export all spans it has buffered
    if _provider is not None:
        remaining_ms = max(1000, int((deadline - _time.monotonic()) * 1000))
        try:
            _provider.force_flush(timeout_millis=remaining_ms)
        except Exception:
            logger.exception("flush: force_flush on provider failed")

    # 2. Flush the ExplainabilityExporter's in-memory buffer to SQLite
    if _exporter is not None:
        try:
            _exporter.force_flush()
        except Exception:
            logger.exception("flush: force_flush on exporter failed")

    # 3. Trigger an immediate sweeper dispatch and wait for it to complete
    if _sweeper is not None:
        remaining = max(1.0, deadline - _time.monotonic())
        dispatched = _sweeper.flush(timeout=remaining)
        if not dispatched:
            logger.warning(
                "flush: sweeper did not complete within %.1f seconds — "
                "traces may still be pending in the inbox and will be sent on the next run.",
                remaining,
            )
    else:
        logger.debug("flush: sweeper not running — traces are in the inbox only.")


def init_from_env(
    *,
    gateway_env: str = DEFAULT_GATEWAY_ENV,
    api_key_env: str = DEFAULT_API_KEY_ENV,
    inbox_env: str = DEFAULT_INBOX_ENV,
    sweep_interval: float = 5.0,
    max_retry: int = 5,
    auto_instrument: Union[bool, str, List[str]] = True,
    service_name: str = "explainability-agent",
    # Backward compat
    install_hooks: Optional[bool] = None,
) -> None:
    """
    Initialise the SDK from environment variables.

    Required:
    - ``EXPLAINABILITY_API_KEY``

    Optional (has default):
    - ``EXPLAINABILITY_GATEWAY_URL`` (defaults to
      ``https://dev-explainability.api.aisquare.studio``)
    """
    gateway_url = os.getenv(gateway_env, DEFAULT_GATEWAY_URL)
    api_key = os.getenv(api_key_env)
    inbox_path = os.getenv(inbox_env, "explainability_inbox.db")

    required_values = (
        (api_key_env, api_key),
    )
    missing = [name for name, value in required_values if not value]
    if missing:
        joined = ", ".join(missing)
        raise RuntimeError(
            f"Missing required SDK environment variables: {joined}. "
            f"Set them in your .env file or shell. "
            f"See: https://github.com/AiSquare/Explainability-SDK/blob/main/docs/getting-started.md"
        )

    init(
        gateway_url=gateway_url,  # type: ignore[arg-type]
        api_key=api_key,  # type: ignore[arg-type]
        inbox_path=inbox_path,
        sweep_interval=sweep_interval,
        max_retry=max_retry,
        auto_instrument=auto_instrument,
        service_name=service_name,
        install_hooks=install_hooks,
    )
