"""
Background sweeper — reads pending rows from the SQLite inbox and dispatches
them to the Explainability Gateway via HTTP.

Runs in its own ``threading.Thread`` with an ``asyncio`` event loop so that
``httpx.AsyncClient`` and ``aiosqlite`` can be used. Retry scheduling is driven
by per-row backoff stored in SQLite, which survives process restarts.

Shutdown design
---------------
``stop()`` sets a ``threading.Event`` *and* signals the asyncio event loop via
``loop.call_soon_threadsafe`` so the in-progress ``asyncio.sleep`` is woken
immediately rather than waiting for the full interval to elapse.  This is
critical for short-lived scripts: the process writes traces to SQLite during
``atexit``, then calls ``sweeper.stop()`` — without the wakeup the sweeper
would not dispatch those rows before the daemon thread was killed.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from datetime import datetime, timedelta, timezone
from typing import List, Optional

import aiosqlite
import httpx

logger = logging.getLogger(__name__)


class InboxSweeper:
    """
    Periodically reads due ``pending`` rows from the inbox and POSTs them to the
    gateway ingest endpoint. Uses exponential back-off per row on transient
    failures. Rows that exceed ``max_retry`` are moved to ``dead_letter``
    status so they don't block the queue.
    """

    def __init__(
        self,
        inbox_path: str,
        gateway_url: str,
        api_key: str,
        *,
        interval: float = 5.0,
        max_retry: int = 5,
    ) -> None:
        self._inbox_path = inbox_path
        self._gateway_url = gateway_url.rstrip("/")
        self._api_key = api_key
        self._interval = interval
        self._max_retry = max_retry
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        # Asyncio state — set once the event loop is running inside _run()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._async_wakeup: Optional[asyncio.Event] = None
        # Waiters registered via flush() — signalled after each sweep completes
        self._flush_waiters: List[threading.Event] = []
        self._flush_waiters_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="inbox-sweeper")
        self._thread.start()
        logger.info("Inbox sweeper started (interval=%.1fs)", self._interval)

    def stop(self) -> None:
        """Signal the sweeper to stop and wait for it to finish."""
        self._stop.set()
        # Wake the asyncio sleep immediately so the final sweep runs ASAP
        self._signal_wakeup()
        if self._thread is not None:
            # Timeout covers: remaining sleep (≤ interval) + one HTTP call (≤ 15s) + buffer
            self._thread.join(timeout=max(self._interval + 20, 30))
            self._thread = None

    def flush(self, timeout: float = 10.0) -> bool:
        """
        Trigger an immediate sweep and block until it completes (or times out).

        Call this at the end of short-lived scripts to ensure traces written to
        the inbox during shutdown are dispatched before the process exits::

            sdk.flush()   # waits up to 10 s

        Returns ``True`` if the sweep completed within *timeout* seconds.
        """
        done = threading.Event()
        with self._flush_waiters_lock:
            self._flush_waiters.append(done)
        self._signal_wakeup()
        return done.wait(timeout=timeout)

    # ------------------------------------------------------------------
    # Internal — wakeup helpers
    # ------------------------------------------------------------------

    def _signal_wakeup(self) -> None:
        """Schedule ``_async_wakeup.set()`` inside the sweeper's event loop."""
        loop = self._loop
        if loop is not None and not loop.is_closed():
            try:
                loop.call_soon_threadsafe(self._set_async_wakeup)
            except RuntimeError:
                pass

    def _set_async_wakeup(self) -> None:
        """Called *inside* the asyncio event loop to set the wakeup event."""
        if self._async_wakeup is not None:
            self._async_wakeup.set()

    # ------------------------------------------------------------------
    # Internal — thread entry
    # ------------------------------------------------------------------

    def _run(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._sweep_loop())
        finally:
            self._loop.close()
            self._loop = None

    async def _sweep_loop(self) -> None:
        self._async_wakeup = asyncio.Event()
        async with httpx.AsyncClient(timeout=15.0) as client:
            while not self._stop.is_set():
                try:
                    await self._sweep_once(client)
                except Exception:
                    logger.exception("Sweeper iteration failed")
                finally:
                    self._notify_flush_waiters()

                # Interruptible sleep: returns early if _async_wakeup is set
                self._async_wakeup.clear()
                try:
                    await asyncio.wait_for(
                        self._async_wakeup.wait(),
                        timeout=self._interval,
                    )
                    # Woken early — loop around immediately to check _stop and sweep
                except asyncio.TimeoutError:
                    pass  # Normal interval elapsed

            # Final sweep after stop — dispatches anything written during atexit
            try:
                await self._sweep_once(client)
            except Exception:
                logger.exception("Sweeper final sweep failed")
            finally:
                self._notify_flush_waiters()

    def _notify_flush_waiters(self) -> None:
        with self._flush_waiters_lock:
            for waiter in self._flush_waiters:
                waiter.set()
            self._flush_waiters.clear()

    async def _sweep_once(self, client: httpx.AsyncClient) -> None:
        async with aiosqlite.connect(self._inbox_path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                """
                SELECT id, trace_id, payload, retries
                FROM inbox
                WHERE status = 'pending'
                  AND datetime(coalesce(next_attempt_at, datetime('now'))) <= datetime('now')
                ORDER BY id
                LIMIT 50
                """
            )
            rows = await cursor.fetchall()

        for row in rows:
            row_id = row[0]
            trace_id = row[1]
            payload = row[2]
            retries = row[3]

            try:
                resp = await client.post(
                    f"{self._gateway_url}/v1/traces/ingest",
                    content=payload,
                    headers={
                        "Content-Type": "application/json",
                        "X-API-KEY": self._api_key,
                    },
                )
                if resp.status_code in (200, 202):
                    await self._mark(row_id, "dispatched")
                    logger.debug("Dispatched trace %s (row %d)", trace_id, row_id)
                elif resp.status_code == 401:
                    await self._mark(row_id, "auth_failed", last_error="unauthorized")
                    logger.warning("Auth failed for trace %s", trace_id)
                else:
                    await self._retry_or_dead_letter(
                        row_id,
                        retries,
                        trace_id,
                        f"gateway_status:{resp.status_code}",
                    )
            except httpx.HTTPError as exc:
                await self._retry_or_dead_letter(row_id, retries, trace_id, str(exc))

    async def _retry_or_dead_letter(
        self,
        row_id: int,
        current_retries: int,
        trace_id: str,
        last_error: str,
    ) -> None:
        new_retries = current_retries + 1
        if new_retries >= self._max_retry:
            await self._mark(row_id, "dead_letter", last_error=last_error)
            logger.error(
                "Trace %s (row %d) moved to dead_letter after %d retries",
                trace_id,
                row_id,
                new_retries,
            )
        else:
            delay_seconds = min(self._compute_backoff_seconds(new_retries), 3600)
            next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)
            async with aiosqlite.connect(self._inbox_path) as db:
                await db.execute(
                    """
                    UPDATE inbox
                    SET retries = ?,
                        next_attempt_at = ?,
                        last_error = ?,
                        updated_at = datetime('now')
                    WHERE id = ?
                    """,
                    (new_retries, next_attempt_at.isoformat(), last_error, row_id),
                )
                await db.commit()
            logger.debug(
                "Trace %s (row %d) retry %d/%d in %ds",
                trace_id,
                row_id,
                new_retries,
                self._max_retry,
                delay_seconds,
            )

    async def _mark(self, row_id: int, status: str, last_error: Optional[str] = None) -> None:
        async with aiosqlite.connect(self._inbox_path) as db:
            await db.execute(
                """
                UPDATE inbox
                SET status = ?,
                    last_error = ?,
                    next_attempt_at = COALESCE(next_attempt_at, datetime('now')),
                    updated_at = datetime('now')
                WHERE id = ?
                """,
                (status, last_error, row_id),
            )
            await db.commit()

    @staticmethod
    def _compute_backoff_seconds(retry_count: int) -> int:
        return min(2 ** max(retry_count - 1, 0), 300)
