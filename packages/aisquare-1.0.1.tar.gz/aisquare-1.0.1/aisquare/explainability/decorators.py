"""
Decorator helpers for automatic tracing.

Platform-agnostic — these use the manual tracers from ``tracers.py``
and work with any Python function regardless of the agentic framework.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from aisquare.explainability.tracers import RetrievalTracer, ToolCallTracer


def trace_tool(
    name: Optional[str] = None,
    version: Optional[str] = None,
) -> Callable:
    """
    Decorator that wraps a function as a traced tool call.

    Usage::

        @trace_tool(name="web_search")
        def web_search(query: str) -> str:
            ...
    """

    def decorator(func: Callable) -> Callable:
        tool_name = name or func.__name__

        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with ToolCallTracer(tool_name=tool_name, tool_version=version) as t:
                t.set_parameters({"args": str(args), "kwargs": str(kwargs)})
                try:
                    result = func(*args, **kwargs)
                    t.set_result(str(result))
                    return result
                except Exception as e:
                    t.set_error(str(e))
                    raise

        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper

    return decorator


def trace_retrieval(
    source: Optional[str] = None,
) -> Callable:
    """
    Decorator that wraps a retrieval function.

    Usage::

        @trace_retrieval(source="pinecone")
        def search_docs(query: str) -> list:
            ...
    """

    def decorator(func: Callable) -> Callable:
        src = source or func.__name__

        def wrapper(*args: Any, **kwargs: Any) -> Any:
            query = kwargs.get("query", str(args[0]) if args else "")
            with RetrievalTracer(source=src, query=query) as r:
                try:
                    result = func(*args, **kwargs)
                    if isinstance(result, list):
                        r.set_documents(
                            [{"content": str(d)} if not isinstance(d, dict) else d for d in result]
                        )
                    return result
                except Exception:
                    raise

        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper

    return decorator
