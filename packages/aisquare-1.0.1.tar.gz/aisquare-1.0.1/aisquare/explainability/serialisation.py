"""
Serialisation helpers — convert OTel ``ReadableSpan`` objects into plain
dictionaries suitable for JSON serialisation and inbox storage.
"""

from __future__ import annotations

from typing import Any, Dict

from opentelemetry.sdk.trace import ReadableSpan


def _format_id(val: int) -> str:
    """Format an OTel 128-bit trace_id or 64-bit span_id to hex."""
    if val == 0:
        return "0" * 32
    return format(val, "032x") if val > 0xFFFFFFFFFFFFFFFF else format(val, "016x")


def span_to_dict(span: ReadableSpan) -> Dict[str, Any]:
    """
    Convert a ``ReadableSpan`` into a JSON-serialisable dictionary that
    preserves the full span context, attributes, events, and links.
    """
    ctx = span.get_span_context()
    parent = span.parent

    result: Dict[str, Any] = {
        "trace_id": format(ctx.trace_id, "032x"),
        "span_id": format(ctx.span_id, "016x"),
        "parent_span_id": format(parent.span_id, "016x") if parent else None,
        "name": span.name,
        "kind": span.kind.name if span.kind else "INTERNAL",
        "start_time": span.start_time,
        "end_time": span.end_time,
        "status": {
            "status_code": span.status.status_code.name if span.status else "UNSET",
            "description": span.status.description if span.status else None,
        },
        "attributes": dict(span.attributes) if span.attributes else {},
        "events": [
            {
                "name": e.name,
                "timestamp": e.timestamp,
                "attributes": dict(e.attributes) if e.attributes else {},
            }
            for e in (span.events or [])
        ],
        "links": [
            {
                "trace_id": format(link.context.trace_id, "032x"),
                "span_id": format(link.context.span_id, "016x"),
                "attributes": dict(link.attributes) if link.attributes else {},
            }
            for link in (span.links or [])
        ],
    }

    # Compute duration in milliseconds
    if span.end_time and span.start_time:
        result["duration_ms"] = (span.end_time - span.start_time) / 1_000_000

    return result
