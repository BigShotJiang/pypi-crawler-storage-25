"""
Developer-friendly SDK environment checks.

Run with:
    python -m aisquare.explainability.doctor
"""

from __future__ import annotations

import importlib.util
import os
from typing import List, Tuple

import httpx


def run_doctor() -> List[Tuple[str, str, str]]:
    results: List[Tuple[str, str, str]] = []

    # SDK version
    try:
        from aisquare.explainability import __version__
        results.append(("sdk_version", "ok", __version__))
    except ImportError:
        results.append(("sdk_version", "error", "Cannot import SDK"))

    gateway_url = os.getenv("EXPLAINABILITY_GATEWAY_URL")
    api_key = os.getenv("EXPLAINABILITY_API_KEY")
    openai_key = os.getenv("OPENAI_API_KEY")

    agno_installed = importlib.util.find_spec("agno") is not None
    openinference_agno_installed = (
        importlib.util.find_spec("openinference.instrumentation.agno") is not None
    )

    results.append(
        (
            "gateway_url",
            "ok" if gateway_url else "missing",
            gateway_url or "Set EXPLAINABILITY_GATEWAY_URL",
        )
    )
    results.append(
        (
            "api_key",
            "ok" if api_key else "missing",
            "[present]" if api_key else "Set EXPLAINABILITY_API_KEY",
        )
    )
    results.append(
        (
            "openai_api_key",
            "ok" if openai_key else "warning",
            "[present]" if openai_key else "Set OPENAI_API_KEY (required for RML extraction)",
        )
    )
    results.append(
        (
            "agno",
            "ok" if agno_installed else "missing",
            "Installed" if agno_installed else "Install optional dependency: .[agno]",
        )
    )
    results.append(
        (
            "openinference_agno",
            "ok" if openinference_agno_installed else "missing",
            (
                "Installed"
                if openinference_agno_installed
                else "Install optional dependency: .[agno]"
            ),
        )
    )

    if gateway_url:
        try:
            response = httpx.get(f"{gateway_url.rstrip('/')}/live", timeout=3.0)
            status = "ok" if response.status_code == 200 else "error"
            detail = "Alive" if response.status_code == 200 else f"{response.status_code} {response.text[:120]}"
        except Exception as exc:
            status = "error"
            detail = str(exc)
        results.append(("gateway_live", status, detail))

        try:
            response = httpx.get(f"{gateway_url.rstrip('/')}/ready", timeout=3.0)
            status = "ok" if response.status_code == 200 else "error"
            detail = "Ready" if response.status_code == 200 else f"{response.status_code} {response.text[:120]}"
            results.append(("gateway_ready", status, detail))
        except Exception as exc:
            results.append(("gateway_ready", "error", str(exc)))

    return results

def main() -> None:
    print("AISquare Explainability SDK Doctor")
    print("=" * 40)
    results = run_doctor()
    width = max(len(name) for name, _, _ in results) + 2
    for name, status, detail in results:
        color = "\033[92m" if status == "ok" else "\033[93m" if status == "warning" else "\033[91m"
        reset = "\033[0m"
        print(f"{name.ljust(width)} [{color}{status.upper():^7}{reset}] {detail}")
    print("=" * 40)


if __name__ == "__main__":
    main()
