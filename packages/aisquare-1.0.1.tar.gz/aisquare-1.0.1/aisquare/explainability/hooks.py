"""
Backward-compatibility shim.

All symbols that used to live in this module have been moved to
``tracers.py``, ``decorators.py``, and ``adapters/agno.py``.

Existing code that imports from ``hooks`` continues to work::

    from aisquare.explainability.hooks import AgentRunTracer  # still works

New code should import from the canonical locations::

    from aisquare.explainability.tracers import AgentRunTracer
    from aisquare.explainability.decorators import trace_tool
"""

from __future__ import annotations

from aisquare.explainability.decorators import (  # noqa: F401
    trace_retrieval,
    trace_tool,
)

# Re-export everything so existing imports don't break
from aisquare.explainability.tracers import (  # noqa: F401
    AgentRunTracer,
    HumanInterventionTracer,
    LLMCallTracer,
    MemoryTracer,
    RetrievalTracer,
    RoutingTracer,
    ToolCallTracer,
    artifact_id,
    get_tracer,
)


def install_agno_hooks(*, service_name: str = "agno-agent") -> None:
    """
    **Deprecated** — Agno instrumentation is now handled by the adapter
    system.  Use ``sdk.init(auto_instrument="agno")`` or
    ``sdk.init(auto_instrument=True)`` instead.

    This shim instantiates the Agno adapter for callers that rely on the
    old function signature.
    """
    from opentelemetry import trace

    from aisquare.explainability.adapters.agno import AgnoAdapter

    adapter = AgnoAdapter()
    tracer = trace.get_tracer(service_name, "0.1.0")
    adapter.instrument(tracer)
