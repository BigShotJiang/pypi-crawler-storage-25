"""
Tests for the structural graph loader.

Since these tests require Neo4j and Postgres, they use mocks for the
database drivers and focus on verifying the correct Cypher queries
and Postgres operations are called.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tests.fixtures.sample_traces import (
    multi_tool_trace,
    rag_agent_trace,
    simple_agent_trace,
)


@pytest.fixture
def mock_neo4j_session():
    """Create a mock Neo4j async session."""
    session = AsyncMock()
    session.run = AsyncMock()
    return session


@pytest.fixture
def mock_neo4j_driver(mock_neo4j_session):
    """Create a mock Neo4j driver that yields the mock session."""
    driver = AsyncMock()

    # session() must return a context manager, not a coroutine
    ctx = AsyncMock()
    ctx.__aenter__ = AsyncMock(return_value=mock_neo4j_session)
    ctx.__aexit__ = AsyncMock(return_value=False)
    driver.session = MagicMock(return_value=ctx)
    return driver


@pytest.fixture
def mock_pg_pool():
    """Create a mock Postgres pool."""
    conn = AsyncMock()
    conn.execute = AsyncMock()

    ctx = AsyncMock()
    ctx.__aenter__ = AsyncMock(return_value=conn)
    ctx.__aexit__ = AsyncMock(return_value=False)

    pool = AsyncMock()
    pool.acquire = MagicMock(return_value=ctx)
    return pool


@pytest.mark.asyncio
class TestStructuralLoader:
    async def test_simple_trace_creates_run(
        self, mock_neo4j_driver, mock_pg_pool, mock_neo4j_session
    ):
        """Verify a simple trace creates the run node and span nodes."""
        trace_data = simple_agent_trace()

        with (
            patch("gateway.worker.structural.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.structural.pg_db.get_pool", return_value=mock_pg_pool),
        ):
            from gateway.worker.structural import process_trace

            await process_trace(
                trace_id=trace_data["trace_id"],
                spans=trace_data["spans"],
                studio_id="studio-1",
            )

        # Verify session.run was called (Studio, Run, HOSTS, Span*3, etc.)
        assert mock_neo4j_session.run.call_count > 0

        # Check that MERGE_STUDIO was called
        calls = [str(c) for c in mock_neo4j_session.run.call_args_list]
        studio_calls = [c for c in calls if "Studio" in c]
        assert len(studio_calls) >= 1

    async def test_rag_trace_creates_human_node(
        self, mock_neo4j_driver, mock_pg_pool, mock_neo4j_session
    ):
        """Verify RAG trace with human intervention creates Human node."""
        trace_data = rag_agent_trace()

        with (
            patch("gateway.worker.structural.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.structural.pg_db.get_pool", return_value=mock_pg_pool),
        ):
            from gateway.worker.structural import process_trace

            await process_trace(
                trace_id=trace_data["trace_id"],
                spans=trace_data["spans"],
                studio_id="studio-1",
            )

        calls_str = " ".join(str(c) for c in mock_neo4j_session.run.call_args_list)
        assert "Human" in calls_str
        assert "INTERVENED" in calls_str

    async def test_multi_tool_trace_creates_artifacts(
        self, mock_neo4j_driver, mock_pg_pool, mock_neo4j_session
    ):
        """Verify multi-tool trace creates artifact nodes and Postgres content."""
        trace_data = multi_tool_trace()

        with (
            patch("gateway.worker.structural.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.structural.pg_db.get_pool", return_value=mock_pg_pool),
        ):
            from gateway.worker.structural import process_trace

            await process_trace(
                trace_id=trace_data["trace_id"],
                spans=trace_data["spans"],
                studio_id="studio-1",
            )

        calls_str = " ".join(str(c) for c in mock_neo4j_session.run.call_args_list)

        # Verify artifact creation
        assert "Artifact" in calls_str
        assert "CONSUMED" in calls_str
        assert "PRODUCED" in calls_str

    async def test_routing_trace_creates_selected_and_rejected_edges(
        self, mock_neo4j_driver, mock_pg_pool, mock_neo4j_session
    ):
        trace_data = {
            "trace_id": "trace-routing",
            "spans": [
                {
                    "trace_id": "trace-routing",
                    "span_id": "span-1",
                    "parent_span_id": None,
                    "name": "Routing:agent_delegation",
                    "kind": "INTERNAL",
                    "start_time": 1,
                    "end_time": 2,
                    "duration_ms": 1.0,
                    "status": {"status_code": "OK", "description": None},
                    "attributes": {
                        "openinference.span.kind": "CHAIN",
                        "routing.selected_json": '{"target":"SummaryAgent","reason":"best fit"}',
                        "routing.rejected": '[{"name":"SearchAgent","reason":"not needed"}]',
                    },
                    "events": [],
                    "links": [],
                }
            ],
        }

        with (
            patch("gateway.worker.structural.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.structural.pg_db.get_pool", return_value=mock_pg_pool),
        ):
            from gateway.worker.structural import process_trace

            await process_trace(
                trace_id=trace_data["trace_id"],
                spans=trace_data["spans"],
                studio_id="studio-1",
            )

        calls_str = " ".join(str(c) for c in mock_neo4j_session.run.call_args_list)
        assert "SELECTED" in calls_str
        assert "REJECTED" in calls_str

    async def test_span_events_are_materialized(
        self, mock_neo4j_driver, mock_pg_pool, mock_neo4j_session
    ):
        trace_data = simple_agent_trace()
        trace_data["spans"][0]["events"] = [
            {
                "name": "agent.started",
                "timestamp": trace_data["spans"][0]["start_time"] + 1,
                "attributes": {},
            },
            {
                "name": "agent.finished",
                "timestamp": trace_data["spans"][0]["end_time"] - 1,
                "attributes": {},
            },
        ]

        with (
            patch("gateway.worker.structural.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.structural.pg_db.get_pool", return_value=mock_pg_pool),
        ):
            from gateway.worker.structural import process_trace

            await process_trace(
                trace_id=trace_data["trace_id"],
                spans=trace_data["spans"],
                studio_id="studio-1",
            )

        calls_str = " ".join(str(c) for c in mock_neo4j_session.run.call_args_list)
        assert "Event" in calls_str
        assert "span.start" in calls_str
        assert "agent.started" in calls_str
        assert "NEXT" in calls_str

    async def test_otel_links_are_preserved(
        self, mock_neo4j_driver, mock_pg_pool, mock_neo4j_session
    ):
        trace_data = simple_agent_trace()
        trace_data["spans"][1]["links"] = [
            {
                "trace_id": trace_data["trace_id"],
                "span_id": trace_data["spans"][2]["span_id"],
                "attributes": {"reason": "dependency"},
            }
        ]

        with (
            patch("gateway.worker.structural.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.structural.pg_db.get_pool", return_value=mock_pg_pool),
        ):
            from gateway.worker.structural import process_trace

            await process_trace(
                trace_id=trace_data["trace_id"],
                spans=trace_data["spans"],
                studio_id="studio-1",
            )

        calls_str = " ".join(str(c) for c in mock_neo4j_session.run.call_args_list)
        assert "REFERENCES" in calls_str

    async def test_span_types_resolved(self):
        """Verify span types are correctly resolved from attributes."""
        trace_data = simple_agent_trace()

        from gateway.worker.structural import _resolve_span_type

        root_span = trace_data["spans"][0]
        assert _resolve_span_type(root_span) == "AGENT"

        llm_span = trace_data["spans"][1]
        assert _resolve_span_type(llm_span) == "LLM"

        tool_span = trace_data["spans"][2]
        assert _resolve_span_type(tool_span) == "TOOL"

    async def test_fallback_span_type_heuristics(self):
        """Verify span type fallback heuristics."""
        from gateway.worker.structural import _resolve_span_type

        assert _resolve_span_type({"name": "my-agent-step", "attributes": {}}) == "AGENT"
        assert _resolve_span_type({"name": "call-gpt-4", "attributes": {}}) == "LLM"
        assert _resolve_span_type({"name": "use-tool-x", "attributes": {}}) == "TOOL"
        assert _resolve_span_type({"name": "rag-search", "attributes": {}}) == "RETRIEVER"
        assert _resolve_span_type({"name": "random", "attributes": {}}) == "CHAIN"
