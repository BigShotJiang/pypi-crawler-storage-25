from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, patch

import pytest

from gateway.models import UISummaryCounts
from gateway.ui import (
    _build_ui_run_summary,
    _format_timestamp,
    _normalise_ui_status,
    _poll_after_ms,
    _summary_from_spans,
    build_ui_agents_response,
    build_ui_graph_response,
    build_ui_node_detail_response,
    build_ui_policies_response,
    build_ui_runs_response,
    build_ui_setup_response,
    build_ui_trace_rml_response,
    build_ui_xtrace_response,
)


class TestUIHelpers:
    def test_normalise_ui_status(self):
        assert _normalise_ui_status("received") == "received"
        assert _normalise_ui_status("processing") == "processing"
        assert _normalise_ui_status("failed") == "failed"
        assert _normalise_ui_status("processed") == "ready"
        assert _normalise_ui_status(None, run_exists=True) == "ready"

    def test_poll_intervals(self):
        assert _poll_after_ms("processing", view="list") == 10_000
        assert _poll_after_ms("processing", view="graph") == 3_000
        assert _poll_after_ms("ready", view="graph") is None

    def test_format_timestamp_handles_datetime(self):
        value = datetime(2026, 3, 18, tzinfo=timezone.utc)
        assert _format_timestamp(value) == "2026-03-18T00:00:00+00:00"

    def test_summary_from_spans(self):
        summary = _summary_from_spans(
            [
                {"start_time": 1_000, "end_time": 2_000, "events": [{"name": "a"}]},
                {"start_time": 3_000, "end_time": 4_000, "events": []},
            ]
        )
        assert summary["summary_counts"] == UISummaryCounts(
            spans=2,
            events=1,
            artifacts=0,
            policies=0,
        )


@pytest.mark.asyncio
async def test_build_ui_run_summary_uses_graph_metadata_when_ready():
    trace_state = {
        "status": "processed",
        "updated_at": datetime(2026, 3, 18, tzinfo=timezone.utc),
        "last_error": None,
    }
    graph_metadata = {
        "start_time": 1_742_256_000_000_000_000,
        "end_time": 1_742_256_001_000_000_000,
        "summary_counts": UISummaryCounts(spans=2, events=4, artifacts=1, policies=1),
    }

    with (
        patch("gateway.ui._fetch_run_graph_metadata", new=AsyncMock(return_value=graph_metadata)),
        patch("gateway.ui._load_canonical_trace_snapshot", new=AsyncMock(return_value=[])),
    ):
        summary = await _build_ui_run_summary(
            studio_id="studio-1",
            run_id="trace-1",
            trace_state=trace_state,
            session=object(),
        )

    assert summary is not None
    assert summary["status"] == "ready"
    assert summary["graph_available"] is True
    assert summary["summary_counts"].artifacts == 1


@pytest.mark.asyncio
async def test_build_ui_run_summary_loads_root_io_for_processed_runs_when_requested():
    trace_state = {
        "status": "processed",
        "updated_at": datetime(2026, 3, 18, tzinfo=timezone.utc),
        "last_error": None,
    }
    graph_metadata = {
        "start_time": 1_742_256_000_000_000_000,
        "end_time": 1_742_256_001_000_000_000,
        "summary_counts": UISummaryCounts(spans=1, events=0, artifacts=0, policies=0),
    }
    spans = [
        {
            "span_id": "root",
            "parent_span_id": None,
            "attributes": {
                "input.value": '{"query":"hello"}',
                "output.value": '{"answer":"world"}',
            },
            "events": [],
        }
    ]

    with (
        patch("gateway.ui._fetch_run_graph_metadata", new=AsyncMock(return_value=graph_metadata)),
        patch("gateway.ui._load_canonical_trace_snapshot", new=AsyncMock(return_value=spans)),
    ):
        summary = await _build_ui_run_summary(
            studio_id="studio-1",
            run_id="trace-1",
            trace_state=trace_state,
            session=object(),
            include_root_io=True,
        )

    assert summary is not None
    assert summary["root_input"] == {"query": "hello"}
    assert summary["root_output"] == {"answer": "world"}


@pytest.mark.asyncio
async def test_build_ui_run_summary_falls_back_to_canonical_trace():
    trace_state = {
        "status": "processing",
        "updated_at": datetime(2026, 3, 18, tzinfo=timezone.utc),
        "last_error": None,
    }
    spans = [
        {"start_time": 1_000, "end_time": 2_000, "events": []},
        {"start_time": 3_000, "end_time": 4_000, "events": [{"name": "x"}]},
    ]

    with (
        patch("gateway.ui._fetch_run_graph_metadata", new=AsyncMock(return_value=None)),
        patch("gateway.ui._load_canonical_trace_snapshot", new=AsyncMock(return_value=spans)),
    ):
        summary = await _build_ui_run_summary(
            studio_id="studio-1",
            run_id="trace-1",
            trace_state=trace_state,
            session=object(),
        )

    assert summary is not None
    assert summary["status"] == "processing"
    assert summary["graph_available"] is False
    assert summary["summary_counts"].spans == 2


@pytest.mark.asyncio
async def test_ui_graph_response_returns_processing_state_without_graph():
    with patch(
        "gateway.ui._build_ui_run_summary",
        new=AsyncMock(
            return_value={
                "run_id": "trace-1",
                "status": "processing",
                "started_at": None,
                "ended_at": None,
                "updated_at": "2026-03-18T00:00:00+00:00",
                "last_error": None,
                "graph_available": False,
                "summary_counts": UISummaryCounts(),
            }
        ),
    ):
        response = await build_ui_graph_response(
            studio_id="studio-1",
            run_id="trace-1",
            mode="span",
        )

    assert response.status == "processing"
    assert response.graph is None
    assert response.poll_after_ms == 3_000


@pytest.mark.asyncio
async def test_ui_node_detail_response_returns_processing_state_without_node():
    with patch(
        "gateway.ui._build_ui_run_summary",
        new=AsyncMock(
            return_value={
                "run_id": "trace-1",
                "status": "processing",
                "started_at": None,
                "ended_at": None,
                "updated_at": "2026-03-18T00:00:00+00:00",
                "last_error": None,
                "graph_available": False,
                "summary_counts": UISummaryCounts(),
            }
        ),
    ):
        response = await build_ui_node_detail_response(
            studio_id="studio-1",
            run_id="trace-1",
            node_id="trace-1:span-1",
        )

    assert response.status == "processing"
    assert response.node is None


@pytest.mark.asyncio
async def test_ui_policies_response_normalises_candidates():
    with patch(
        "gateway.ui.list_policy_candidates",
        new=AsyncMock(
            return_value=[
                {
                    "candidate_key": "studio-1:abc",
                    "fingerprint": "abc",
                    "normalized_text": "always respond in english",
                    "status": "proposed",
                    "occurrence_count": 3,
                    "threshold": 3,
                    "raw_text_sample": "Always respond in English",
                    "first_seen": "2026-03-18T00:00:00+00:00",
                    "last_seen": "2026-03-18T01:00:00+00:00",
                }
            ]
        ),
    ):
        response = await build_ui_policies_response(studio_id="studio-1", status="proposed")

    assert response.status == "ok"
    assert len(response.policies) == 1
    assert response.policies[0].label == "always respond in english"


@pytest.mark.asyncio
async def test_ui_runs_response_passes_through_enriched_metrics():
    with patch(
        "gateway.ui._collect_ui_run_summaries",
        new=AsyncMock(
            return_value=[
                {
                    "run_id": "trace-1",
                    "status": "ready",
                    "agent_name": "ResearchAgent",
                    "started_at": "2026-03-18T00:00:00+00:00",
                    "ended_at": "2026-03-18T00:00:02+00:00",
                    "updated_at": "2026-03-18T00:00:02+00:00",
                    "duration_ms": 2000.0,
                    "node_count": 12,
                    "token_count": 321,
                    "cost_usd": 0.12,
                    "error_count": 1,
                    "flagged_count": 2,
                    "last_error": None,
                    "graph_available": True,
                    "summary_counts": UISummaryCounts(spans=4, events=8, artifacts=2, policies=2),
                }
            ]
        ),
    ):
        response = await build_ui_runs_response(studio_id="studio-1", limit=20, offset=0)

    assert response.total_count == 1
    assert response.runs[0].agent_name == "ResearchAgent"
    assert response.runs[0].error_count == 1


@pytest.mark.asyncio
async def test_ui_agents_response_aggregates_facets():
    with patch(
        "gateway.ui._collect_ui_run_summaries",
        new=AsyncMock(
            return_value=[
                {"run_id": "trace-1", "agent_name": "AgentA"},
                {"run_id": "trace-2", "agent_name": "AgentA"},
                {"run_id": "trace-3", "agent_name": "AgentB"},
            ]
        ),
    ):
        response = await build_ui_agents_response(studio_id="studio-1")

    assert len(response.agents) == 2
    assert response.agents[0].name == "AgentA"
    assert response.agents[0].count == 2


@pytest.mark.asyncio
async def test_ui_xtrace_response_formats_trace_payload():
    with (
        patch(
            "gateway.ui._build_ui_run_summary",
            new=AsyncMock(
                return_value={
                    "run_id": "trace-1",
                    "status": "ready",
                    "updated_at": "2026-03-18T00:00:00+00:00",
                }
            ),
        ),
        patch(
            "gateway.ui._load_canonical_trace_snapshot",
            new=AsyncMock(return_value=[{"span_id": "s1", "events": []}]),
        ),
        patch("gateway.ui._fetch_trace_payload_mode", new=AsyncMock(return_value="full")),
    ):
        response = await build_ui_xtrace_response(studio_id="studio-1", run_id="trace-1")

    assert response.status == "ready"
    assert response.span_count == 1
    assert '"trace_id": "trace-1"' in response.formatted_text


@pytest.mark.asyncio
async def test_ui_setup_response_exposes_quickstart_commands():
    with patch.dict(
        "os.environ",
        {"ALLOW_TEST_AUTH_BYPASS": "true", "EXPLAINABILITY_GATEWAY_URL": "http://localhost:8000"},
        clear=False,
    ):
        response = await build_ui_setup_response(studio_id="test_studio")

    assert response.local_bypass_enabled is True
    assert response.default_api_key == "test-key"
    assert len(response.commands) >= 3


@pytest.mark.asyncio
async def test_ui_trace_rml_response_formats_all_rows():
    conn = AsyncMock()
    conn.fetch = AsyncMock(
        return_value=[
            {
                "analysis_id": "analysis-1",
                "span_id": "span-1",
                "rml_version": "1.0",
                "extracted_at": datetime(2026, 3, 18, tzinfo=timezone.utc),
                "extractor_model": "gpt-4o-mini",
                "extraction_confidence": 0.42,
                "low_confidence": None,
                "claims": '["claim"]',
                "assumptions": '["assumption"]',
                "evidence_attribution": (
                    '[{"input_chunk":"in","output_chunk":"out",'
                    '"attribution_type":"evidence_used","confidence":0.9}]'
                ),
                "inference_chain": '[{"step_number":1,"reasoning":"because","conclusion":"done"}]',
                "policy_triggers": (
                    '[{"raw_text":"Always cite","normalized_text":"always cite",'
                    '"instruction_type":"constraint"}]'
                ),
            }
        ]
    )
    ctx = AsyncMock()
    ctx.__aenter__ = AsyncMock(return_value=conn)
    ctx.__aexit__ = AsyncMock(return_value=False)
    pool = AsyncMock()
    pool.acquire = lambda: ctx

    with patch("gateway.ui.pg_db.get_pool", new=AsyncMock(return_value=pool)):
        response = await build_ui_trace_rml_response(studio_id="studio-1", run_id="trace-1")

    assert len(response.rml) == 1
    assert response.rml[0].analysis_id == "analysis-1"
    assert response.rml[0].claims == ["claim"]
    assert response.rml[0].low_confidence is True
