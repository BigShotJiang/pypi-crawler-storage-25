"""
Tests for the RML extraction worker (Phase 4).

Uses mocks for the LLM client, Neo4j, and Postgres since the tests
must run without external services.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from gateway.models import RMLSpanOutput
from gateway.worker.extractor import (
    EXTRACTABLE_SPAN_TYPES,
    HydratedSpan,
    _call_llm,
    _hydrate_span,
    _resolve_span_type,
    build_extraction_prompt,
    extract_semantic_rml,
    run_rml_extraction,
)
from tests.fixtures.sample_traces import simple_agent_trace


class TestHydratedSpan:
    def test_hydrate_agent_span(self):
        trace = simple_agent_trace()
        root_span = trace["spans"][0]  # AGENT span
        hydrated = _hydrate_span(root_span)
        assert hydrated.span_id == "0000000000000001"
        assert hydrated.span_type == "AGENT"
        assert "capital of France" in hydrated.input_text
        assert "Paris" in hydrated.output_text

    def test_hydrate_llm_span(self):
        trace = simple_agent_trace()
        llm_span = trace["spans"][1]  # LLM span
        hydrated = _hydrate_span(llm_span)
        assert hydrated.span_type == "LLM"
        assert hydrated.model_name == "claude-3-haiku"
        # LLM spans prefer llm.input_messages over input.value
        assert "capital of France" in hydrated.input_text

    def test_hydrate_tool_span(self):
        trace = simple_agent_trace()
        tool_span = trace["spans"][2]  # TOOL span
        hydrated = _hydrate_span(tool_span)
        assert hydrated.span_type == "TOOL"


class TestExtractableSpanTypes:
    def test_agent_is_extractable(self):
        assert "AGENT" in EXTRACTABLE_SPAN_TYPES

    def test_llm_is_extractable(self):
        assert "LLM" in EXTRACTABLE_SPAN_TYPES

    def test_tool_not_extractable(self):
        assert "TOOL" not in EXTRACTABLE_SPAN_TYPES

    def test_chain_not_extractable(self):
        assert "CHAIN" not in EXTRACTABLE_SPAN_TYPES


class TestBuildExtractionPrompt:
    def test_prompt_contains_span_info(self):
        hydrated = HydratedSpan(
            span_id="s1",
            span_name="AgentRun:Research",
            span_type="AGENT",
            input_text="What is AI?",
            output_text="AI is artificial intelligence.",
            model_name="claude-3-haiku",
        )
        prompt = build_extraction_prompt(hydrated)
        assert "AgentRun:Research" in prompt
        assert "AGENT" in prompt
        assert "claude-3-haiku" in prompt
        assert "What is AI?" in prompt
        assert "AI is artificial intelligence" in prompt

    def test_prompt_without_model(self):
        hydrated = HydratedSpan(
            span_id="s1",
            span_name="AgentRun:Test",
            span_type="AGENT",
            input_text="Hello",
            output_text="World",
        )
        prompt = build_extraction_prompt(hydrated)
        assert "Model:" not in prompt


@pytest.fixture
def valid_rml_json():
    """A valid RML JSON string as an LLM would produce."""
    return json.dumps(
        {
            "claims": ["The capital of France is Paris"],
            "assumptions": ["The user wants a factual answer"],
            "evidence_attribution": [
                {
                    "input_chunk": "capital of France",
                    "output_chunk": "Paris",
                    "attribution_type": "evidence_used",
                    "confidence": 0.95,
                }
            ],
            "inference_chain": [
                {
                    "step_number": 1,
                    "reasoning": "User asked about France's capital",
                    "conclusion": "Paris is the capital",
                }
            ],
            "policy_triggers": [
                {
                    "raw_text": "Always respond in English",
                    "normalized_text": "always respond in english",
                    "instruction_type": "constraint",
                }
            ],
            "extraction_confidence": 0.92,
        }
    )


@pytest.fixture
def mock_neo4j_session():
    session = AsyncMock()
    session.run = AsyncMock()
    return session


@pytest.fixture
def mock_neo4j_driver(mock_neo4j_session):
    driver = AsyncMock()
    ctx = AsyncMock()
    ctx.__aenter__ = AsyncMock(return_value=mock_neo4j_session)
    ctx.__aexit__ = AsyncMock(return_value=False)
    driver.session = MagicMock(return_value=ctx)
    return driver


@pytest.fixture
def mock_pg_pool():
    conn = AsyncMock()
    conn.execute = AsyncMock()
    conn.fetch = AsyncMock(return_value=[])

    ctx = AsyncMock()
    ctx.__aenter__ = AsyncMock(return_value=conn)
    ctx.__aexit__ = AsyncMock(return_value=False)

    pool = AsyncMock()
    pool.acquire = MagicMock(return_value=ctx)
    return pool


@pytest.mark.asyncio
class TestExtractSemanticRml:
    async def test_successful_extraction(self, valid_rml_json):
        """Valid LLM output is parsed into RMLSpanOutput."""
        hydrated = HydratedSpan(
            span_id="s1",
            span_name="Test",
            span_type="AGENT",
            input_text="What is AI?",
            output_text="AI is intelligence.",
        )

        with patch(
            "gateway.worker.extractor._call_llm",
            return_value=valid_rml_json,
        ):
            result = await extract_semantic_rml(hydrated)

        assert result is not None
        assert isinstance(result, RMLSpanOutput)
        assert len(result.claims) == 1
        assert result.extraction_confidence == 0.92
        assert len(result.policy_triggers) == 1

    async def test_markdown_fences_stripped(self, valid_rml_json):
        """LLM output with markdown fences is handled gracefully."""
        fenced = f"```json\n{valid_rml_json}\n```"
        hydrated = HydratedSpan(
            span_id="s1",
            span_name="Test",
            span_type="AGENT",
            input_text="x",
            output_text="y",
        )

        with patch(
            "gateway.worker.extractor._call_llm",
            return_value=fenced,
        ):
            result = await extract_semantic_rml(hydrated)

        assert result is not None
        assert result.extraction_confidence == 0.92

    async def test_llm_returns_none(self):
        """No API key / empty response → returns None."""
        hydrated = HydratedSpan(
            span_id="s1",
            span_name="Test",
            span_type="AGENT",
            input_text="x",
            output_text="y",
        )

        with (
            patch("gateway.worker.extractor._call_llm", return_value=None),
            patch("gateway.worker.extractor._log_extraction_failure", new_callable=AsyncMock),
        ):
            result = await extract_semantic_rml(hydrated)

        assert result is None

    async def test_invalid_json_returns_none(self):
        """Malformed LLM output → returns None, logs failure."""
        hydrated = HydratedSpan(
            span_id="s1",
            span_name="Test",
            span_type="AGENT",
            input_text="x",
            output_text="y",
        )

        mock_llm = patch(
            "gateway.worker.extractor._call_llm",
            return_value="not json at all",
        )
        mock_fail = patch(
            "gateway.worker.extractor._log_extraction_failure",
            new_callable=AsyncMock,
        )
        with mock_llm, mock_fail as mock_log:
            result = await extract_semantic_rml(hydrated)

        assert result is None
        mock_log.assert_called_once()


@pytest.mark.asyncio
class TestOpenAiCallPath:
    async def test_call_llm_skips_without_openai_key(self):
        with patch.dict("os.environ", {}, clear=False):
            with patch(
                "gateway.worker.extractor.os.getenv",
                side_effect=lambda key, default=None: None if key == "OPENAI_API_KEY" else default,
            ):
                result = await _call_llm("sys", "user", "gpt-4o-mini")
        assert result is None

    async def test_call_llm_uses_openai_chat_completion(self):
        mock_response = MagicMock()
        mock_response.choices = [
            MagicMock(
                message=MagicMock(
                    content='{"claims":[],"assumptions":[],"evidence_attribution":[],"inference_chain":[],"policy_triggers":[],"extraction_confidence":0.9}'
                )
            )
        ]

        mock_client = MagicMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)

        with (
            patch(
                "gateway.worker.extractor.os.getenv",
                side_effect=lambda key, default=None: (
                    "sk-test" if key == "OPENAI_API_KEY" else default
                ),
            ),
            patch("gateway.worker.extractor.AsyncOpenAI", return_value=mock_client),
        ):
            result = await _call_llm("sys", "user", "gpt-4o-mini")

        assert result is not None
        mock_client.chat.completions.create.assert_awaited_once()


@pytest.mark.asyncio
class TestRunRmlExtraction:
    async def test_skips_tool_spans(self, mock_neo4j_driver, mock_pg_pool):
        """TOOL spans are skipped (not extractable)."""
        trace = simple_agent_trace()
        tool_span = trace["spans"][2]  # TOOL span

        with (
            patch("gateway.worker.extractor.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.extractor.pg_db.get_pool", return_value=mock_pg_pool),
            patch("gateway.worker.extractor._call_llm") as mock_llm,
        ):
            await run_rml_extraction(
                trace_id="t1",
                spans=[tool_span],
                studio_id="studio-1",
            )

        # LLM should not have been called for a TOOL span
        mock_llm.assert_not_called()

    async def test_extracts_agent_and_llm_spans(
        self, mock_neo4j_driver, mock_pg_pool, valid_rml_json, mock_neo4j_session
    ):
        """AGENT and LLM spans are processed; RML is written to Postgres and Neo4j updated."""
        trace = simple_agent_trace()

        with (
            patch("gateway.worker.extractor.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.extractor.pg_db.get_pool", return_value=mock_pg_pool),
            patch("gateway.worker.extractor._call_llm", return_value=valid_rml_json),
        ):
            await run_rml_extraction(
                trace_id="t1",
                spans=trace["spans"],
                studio_id="studio-1",
            )

        # Should have written to Postgres (via pool.acquire().execute) for AGENT + LLM spans
        pg_conn = mock_pg_pool.acquire().__aenter__.return_value
        # The execute calls include RML inserts
        assert pg_conn.execute.call_count >= 2

        # Should have updated Neo4j Span nodes with rml_analysis_id
        calls_str = " ".join(str(c) for c in mock_neo4j_session.run.call_args_list)
        assert "rml_analysis_id" in calls_str

    async def test_graceful_on_llm_failure(self, mock_neo4j_driver, mock_pg_pool):
        """LLM failure doesn't crash — structural graph is unaffected."""
        trace = simple_agent_trace()

        with (
            patch("gateway.worker.extractor.neo4j_db.get_driver", return_value=mock_neo4j_driver),
            patch("gateway.worker.extractor.pg_db.get_pool", return_value=mock_pg_pool),
            patch("gateway.worker.extractor._call_llm", return_value=None),
            patch("gateway.worker.extractor._log_extraction_failure", new_callable=AsyncMock),
        ):
            # Should not raise
            await run_rml_extraction(
                trace_id="t1",
                spans=trace["spans"],
                studio_id="studio-1",
            )


class TestResolveSpanType:
    def test_agent_from_attribute(self):
        span = {"attributes": {"openinference.span.kind": "AGENT"}, "name": "test"}
        assert _resolve_span_type(span) == "AGENT"

    def test_llm_from_attribute(self):
        span = {"attributes": {"openinference.span.kind": "LLM"}, "name": "test"}
        assert _resolve_span_type(span) == "LLM"

    def test_fallback_to_name(self):
        span = {"attributes": {}, "name": "my-agent-step"}
        assert _resolve_span_type(span) == "AGENT"
