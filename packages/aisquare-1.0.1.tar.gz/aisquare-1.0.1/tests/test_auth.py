from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from gateway.auth import AuthServiceUnavailable, validate_api_key


def _request(token: str) -> Request:
    return Request(
        {
            "type": "http",
            "headers": [(b"authorization", f"Bearer {token}".encode("utf-8"))],
        }
    )


@pytest.mark.asyncio
async def test_validate_api_key_returns_cached_value():
    redis = AsyncMock()
    redis.get = AsyncMock(return_value="studio-1")

    with patch("gateway.auth.get_client", return_value=redis):
        studio_id = await validate_api_key(_request("cached-token"))

    assert studio_id == "studio-1"


@pytest.mark.asyncio
async def test_validate_api_key_invalid_key_is_401():
    redis = AsyncMock()
    redis.get = AsyncMock(return_value=None)
    redis.setex = AsyncMock()

    with (
        patch("gateway.auth.get_client", return_value=redis),
        patch("gateway.auth._call_django_auth", new=AsyncMock(return_value=None)),
    ):
        with pytest.raises(HTTPException) as exc:
            await validate_api_key(_request("bad-token"))

    assert exc.value.status_code == 401


@pytest.mark.asyncio
async def test_validate_api_key_outage_is_503():
    redis = AsyncMock()
    redis.get = AsyncMock(return_value=None)

    with (
        patch("gateway.auth.get_client", return_value=redis),
        patch(
            "gateway.auth._call_django_auth",
            new=AsyncMock(side_effect=AuthServiceUnavailable("Authentication service unavailable")),
        ),
    ):
        with pytest.raises(HTTPException) as exc:
            await validate_api_key(_request("retry-token"))

    assert exc.value.status_code == 503
