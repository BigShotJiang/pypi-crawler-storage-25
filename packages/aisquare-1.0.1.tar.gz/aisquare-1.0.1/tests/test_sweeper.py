from __future__ import annotations

import sqlite3
import tempfile

import pytest

from aisquare.explainability.inbox import InboxWriter
from aisquare.explainability.sweeper import InboxSweeper


@pytest.mark.asyncio
async def test_retry_sets_backoff_and_error():
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()

    writer = InboxWriter(tmp.name)
    writer.ensure_schema()
    writer.insert("trace-1", '{"trace_id": "trace-1", "spans": []}')

    sweeper = InboxSweeper(tmp.name, "http://localhost:8000", "key")
    await sweeper._retry_or_dead_letter(1, 0, "trace-1", "boom")

    conn = sqlite3.connect(tmp.name)
    row = conn.execute(
        "SELECT retries, next_attempt_at, last_error, status FROM inbox WHERE id = 1"
    ).fetchone()
    conn.close()
    writer.close()

    assert row[0] == 1
    assert row[1] is not None
    assert row[2] == "boom"
    assert row[3] == "pending"


@pytest.mark.asyncio
async def test_mark_dispatched_keeps_next_attempt_non_null():
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()

    writer = InboxWriter(tmp.name)
    writer.ensure_schema()
    writer.insert("trace-1", '{"trace_id": "trace-1", "spans": []}')

    sweeper = InboxSweeper(tmp.name, "http://localhost:8000", "key")
    await sweeper._mark(1, "dispatched")

    conn = sqlite3.connect(tmp.name)
    row = conn.execute(
        "SELECT status, next_attempt_at, last_error FROM inbox WHERE id = 1"
    ).fetchone()
    conn.close()
    writer.close()

    assert row[0] == "dispatched"
    assert row[1] is not None
    assert row[2] is None


def test_backoff_is_exponential_with_cap():
    assert InboxSweeper._compute_backoff_seconds(1) == 1
    assert InboxSweeper._compute_backoff_seconds(2) == 2
    assert InboxSweeper._compute_backoff_seconds(3) == 4
    assert InboxSweeper._compute_backoff_seconds(10) == 300
