"""
Tests for the React Flow graph builder.
"""

from __future__ import annotations

from graph.react_flow import build_react_flow_graph


class TestReactFlowBuilder:
    def test_empty_graph(self):
        graph = build_react_flow_graph([], [])
        assert len(graph.nodes) == 0
        assert len(graph.edges) == 0

    def test_run_only_is_hidden_from_visible_graph(self):
        graph = build_react_flow_graph(
            [{"id": "r1", "label": "Run", "properties": {"run_id": "r1", "status": "completed"}}],
            [],
        )
        assert len(graph.nodes) == 0
        assert graph.meta.visible_node_count == 0

    def test_run_with_spans(self):
        graph = build_react_flow_graph(
            [
                {"id": "r1", "label": "Run", "properties": {"run_id": "r1", "status": "completed"}},
                {
                    "id": "trace:s1",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:s1",
                        "span_id": "s1",
                        "name": "AgentRun",
                        "type": "AGENT",
                        "duration_ms": 100,
                    },
                },
                {
                    "id": "trace:s2",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:s2",
                        "span_id": "s2",
                        "name": "LLM:claude",
                        "type": "LLM",
                        "duration_ms": 50,
                    },
                },
            ],
            [],
        )
        assert len(graph.nodes) == 2
        assert graph.meta.counts.spans == 2

    def test_relationships_as_edges(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "trace:s1",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:s1",
                        "span_id": "s1",
                        "name": "Agent",
                        "type": "AGENT",
                    },
                },
                {
                    "id": "trace:s2",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:s2",
                        "span_id": "s2",
                        "name": "Tool",
                        "type": "TOOL",
                    },
                },
            ],
            [
                {
                    "source": "trace:s1",
                    "target": "trace:s2",
                    "type": "NEXT",
                    "properties": {"seq": 0},
                }
            ],
        )
        assert len(graph.edges) == 1
        assert graph.edges[0].label == "NEXT"
        assert graph.edges[0].animated is True

    def test_span_type_mapping(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "s1",
                    "label": "Span",
                    "properties": {"span_key": "s1", "name": "A", "type": "AGENT"},
                },
                {
                    "id": "s2",
                    "label": "Span",
                    "properties": {"span_key": "s2", "name": "B", "type": "LLM"},
                },
                {
                    "id": "s3",
                    "label": "Span",
                    "properties": {"span_key": "s3", "name": "C", "type": "TOOL"},
                },
                {
                    "id": "s4",
                    "label": "Span",
                    "properties": {"span_key": "s4", "name": "D", "type": "RETRIEVER"},
                },
                {
                    "id": "s5",
                    "label": "Span",
                    "properties": {"span_key": "s5", "name": "E", "type": "CHAIN"},
                },
            ],
            [],
        )
        types = {n.id: n.type for n in graph.nodes}
        assert types["s1"] == "agentNode"
        assert types["s2"] == "llmNode"
        assert types["s3"] == "toolNode"
        assert types["s4"] == "retrieverNode"
        assert types["s5"] == "chainNode"

    def test_no_duplicate_nodes(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "s1",
                    "label": "Span",
                    "properties": {"span_key": "s1", "name": "A", "type": "AGENT"},
                },
                {
                    "id": "s1",
                    "label": "Span",
                    "properties": {"span_key": "s1", "name": "A", "type": "AGENT"},
                },
            ],
            [],
        )
        assert len(graph.nodes) == 1

    def test_artifact_and_agent_nodes_render(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "trace:s1",
                    "label": "Span",
                    "properties": {"span_key": "trace:s1", "name": "AgentRun", "type": "AGENT"},
                },
                {
                    "id": "studio:artifact",
                    "label": "Artifact",
                    "properties": {"artifact_key": "studio:artifact", "artifact_id": "artifact"},
                },
                {
                    "id": "agent:research",
                    "label": "Agent",
                    "properties": {"agent_id": "agent:research", "name": "ResearchAgent"},
                },
            ],
            [
                {
                    "source": "agent:research",
                    "target": "trace:s1",
                    "type": "EXECUTED",
                    "properties": {},
                },
                {
                    "source": "trace:s1",
                    "target": "studio:artifact",
                    "type": "PRODUCED",
                    "properties": {},
                },
            ],
        )
        assert len(graph.nodes) == 3
        assert len(graph.edges) == 2

    def test_event_nodes_render(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "trace:s1:event:tool_call",
                    "label": "Event",
                    "properties": {
                        "event_key": "trace:s1:event:tool_call",
                        "event_id": "tool_call",
                        "name": "tool.call",
                        "type": "ACTION",
                        "source": "otel",
                    },
                }
            ],
            [],
            mode="event",
        )
        assert len(graph.nodes) == 1
        assert graph.nodes[0].type == "eventNode"
        assert graph.meta.counts.events == 1

    def test_duplicate_edges_are_deduplicated(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "a",
                    "label": "Span",
                    "properties": {"span_key": "a", "name": "A", "type": "CHAIN"},
                },
                {
                    "id": "b",
                    "label": "Span",
                    "properties": {"span_key": "b", "name": "B", "type": "CHAIN"},
                },
            ],
            [
                {"source": "a", "target": "b", "type": "CONTAINS", "properties": {}},
                {"source": "a", "target": "b", "type": "CONTAINS", "properties": {}},
            ],
        )
        assert len(graph.edges) == 1

    def test_policy_nodes_are_not_treated_as_errors(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "trace:s1",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:s1",
                        "span_id": "s1",
                        "name": "Agent",
                        "type": "AGENT",
                        "status": "OK",
                    },
                },
                {
                    "id": "studio:policy-1",
                    "label": "PolicyCandidate",
                    "properties": {
                        "candidate_key": "policy-1",
                        "status": "activated",
                        "normalized_text": "never invent facts",
                    },
                },
            ],
            [
                {
                    "source": "trace:s1",
                    "target": "studio:policy-1",
                    "type": "FLAGGED_AS",
                    "properties": {},
                }
            ],
        )

        assert graph.meta.error_node_ids == []
        assert graph.edges[0].label == "Policy"

    def test_same_source_target_type_different_props_kept(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "a",
                    "label": "Span",
                    "properties": {"span_key": "a", "name": "A", "type": "CHAIN"},
                },
                {
                    "id": "b",
                    "label": "Span",
                    "properties": {"span_key": "b", "name": "B", "type": "CHAIN"},
                },
            ],
            [
                {"source": "a", "target": "b", "type": "CONTAINS", "properties": {"seq": 1}},
                {"source": "a", "target": "b", "type": "CONTAINS", "properties": {"seq": 2}},
            ],
        )
        assert len(graph.edges) == 2

    def test_edges_with_same_props_different_key_order_deduplicated(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "agent:1",
                    "label": "Agent",
                    "properties": {"agent_id": "agent:1", "name": "Agent"},
                },
                {
                    "id": "b",
                    "label": "Span",
                    "properties": {"span_key": "b", "name": "B", "type": "CHAIN"},
                },
            ],
            [
                {
                    "source": "agent:1",
                    "target": "b",
                    "type": "REFERENCES",
                    "properties": {"reason": "fallback", "seq": 1},
                },
                {
                    "source": "agent:1",
                    "target": "b",
                    "type": "REFERENCES",
                    "properties": {"seq": 1, "reason": "fallback"},
                },
            ],
        )
        assert len(graph.edges) == 1

    def test_span_node_exposes_token_breakdown_and_policy_details(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "trace:s1",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:s1",
                        "span_id": "s1",
                        "name": "LLM Step",
                        "type": "LLM",
                        "tokens_in": 120,
                        "tokens_out": 48,
                    },
                },
                {
                    "id": "studio:policy",
                    "label": "PolicyCandidate",
                    "properties": {
                        "candidate_key": "studio:policy",
                        "normalized_text": "always cite sources",
                        "raw_text_sample": "Always cite sources in the final answer.",
                    },
                },
            ],
            [
                {
                    "source": "trace:s1",
                    "target": "studio:policy",
                    "type": "FLAGGED_AS",
                    "properties": {},
                }
            ],
        )

        data = graph.nodes[0].data
        assert data["tokens_in"] == 120
        assert data["tokens_out"] == 48
        assert data["policy_count"] == 1
        assert data["policies"] == [
            {
                "name": "always cite sources",
                "passed": False,
                "detail": "Always cite sources in the final answer.",
            }
        ]

    def test_event_mode_filters_boundary_nodes_and_contains_edges(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "trace:span",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:span",
                        "span_id": "span",
                        "name": "Agent",
                        "type": "AGENT",
                    },
                },
                {
                    "id": "trace:span:event:start",
                    "label": "Event",
                    "properties": {
                        "event_key": "trace:span:event:start",
                        "event_id": "start",
                        "span_id": "span",
                        "name": "span.start",
                        "source": "derived",
                    },
                },
                {
                    "id": "trace:span:event:otel",
                    "label": "Event",
                    "properties": {
                        "event_key": "trace:span:event:otel",
                        "event_id": "otel",
                        "span_id": "span",
                        "name": "tool.call",
                        "source": "otel",
                    },
                },
            ],
            [
                {
                    "source": "trace:span",
                    "target": "trace:span:event:start",
                    "type": "CONTAINS",
                    "properties": {},
                },
                {
                    "source": "trace:span",
                    "target": "trace:span:event:otel",
                    "type": "CONTAINS",
                    "properties": {},
                },
            ],
            mode="event",
        )

        assert [node.id for node in graph.nodes] == ["trace:span:event:otel"]
        assert graph.meta.counts.events == 1
        assert graph.meta.visible_edge_count == 0

    def test_graph_meta_marks_start_terminal_and_error_nodes(self):
        graph = build_react_flow_graph(
            [
                {
                    "id": "trace:s1",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:s1",
                        "span_id": "s1",
                        "name": "Start",
                        "type": "CHAIN",
                        "status_code": "OK",
                    },
                },
                {
                    "id": "trace:s2",
                    "label": "Span",
                    "properties": {
                        "span_key": "trace:s2",
                        "span_id": "s2",
                        "name": "End",
                        "type": "CHAIN",
                        "status_code": "ERROR",
                    },
                },
            ],
            [
                {
                    "source": "trace:s1",
                    "target": "trace:s2",
                    "type": "NEXT",
                    "properties": {"seq": 0},
                }
            ],
        )

        assert graph.meta.start_node_ids == ["trace:s1"]
        assert graph.meta.terminal_node_ids == ["trace:s2"]
        assert graph.meta.error_node_ids == ["trace:s2"]
        assert graph.edges[0].data["role"] == "timeline"
