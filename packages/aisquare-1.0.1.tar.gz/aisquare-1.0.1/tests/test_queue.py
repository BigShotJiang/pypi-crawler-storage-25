from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from gateway.worker.queue import cleanup_expired_payloads, store_ingest_batch


@pytest.fixture
def mock_pg_pool():
    conn = AsyncMock()
    conn.fetchrow = AsyncMock()
    conn.execute = AsyncMock()

    tx = AsyncMock()
    tx.__aenter__ = AsyncMock(return_value=None)
    tx.__aexit__ = AsyncMock(return_value=False)
    conn.transaction = MagicMock(return_value=tx)

    ctx = AsyncMock()
    ctx.__aenter__ = AsyncMock(return_value=conn)
    ctx.__aexit__ = AsyncMock(return_value=False)

    pool = AsyncMock()
    pool.acquire = MagicMock(return_value=ctx)
    return pool


@pytest.mark.asyncio
async def test_store_ingest_batch_enqueues_new_trace(mock_pg_pool):
    conn = mock_pg_pool.acquire().__aenter__.return_value
    conn.fetchrow.return_value = {
        "batch_id": "batch-1",
        "status": "received",
        "created_at": None,
        "inserted": True,
    }

    with (
        patch("gateway.worker.queue.pg_db.get_pool", return_value=mock_pg_pool),
        patch("gateway.worker.queue.enqueue_trace", new=AsyncMock()) as enqueue_trace,
    ):
        result = await store_ingest_batch(
            trace_id="trace-1",
            studio_id="studio-1",
            spans=[{"trace_id": "trace-1", "span_id": "span-1", "name": "root"}],
        )

    assert result["batch_id"] == "batch-1"
    assert result["duplicate"] is False
    enqueue_trace.assert_awaited_once_with(trace_id="trace-1", studio_id="studio-1")


@pytest.mark.asyncio
async def test_store_ingest_batch_duplicate_is_not_enqueued(mock_pg_pool):
    conn = mock_pg_pool.acquire().__aenter__.return_value
    conn.fetchrow.return_value = {
        "batch_id": "batch-1",
        "status": "processed",
        "created_at": None,
        "inserted": False,
    }

    with (
        patch("gateway.worker.queue.pg_db.get_pool", return_value=mock_pg_pool),
        patch("gateway.worker.queue.enqueue_trace", new=AsyncMock()) as enqueue_trace,
    ):
        result = await store_ingest_batch(
            trace_id="trace-1",
            studio_id="studio-1",
            spans=[{"trace_id": "trace-1", "span_id": "span-1", "name": "root"}],
        )

    assert result["duplicate"] is True
    enqueue_trace.assert_not_awaited()


@pytest.mark.asyncio
async def test_store_ingest_batch_can_store_sanitized_payloads(mock_pg_pool):
    conn = mock_pg_pool.acquire().__aenter__.return_value
    conn.fetchrow.return_value = {
        "batch_id": "batch-2",
        "status": "received",
        "created_at": None,
        "inserted": True,
    }

    with (
        patch("gateway.worker.queue.pg_db.get_pool", return_value=mock_pg_pool),
        patch("gateway.worker.queue.enqueue_trace", new=AsyncMock()),
        patch("gateway.worker.queue.RAW_PAYLOAD_MODE", "sanitized"),
    ):
        await store_ingest_batch(
            trace_id="trace-2",
            studio_id="studio-1",
            spans=[
                {
                    "trace_id": "trace-2",
                    "span_id": "span-1",
                    "name": "root",
                    "attributes": {"api_key": "sk-abcdefghijklmnop"},
                }
            ],
        )

    fetch_args = conn.fetchrow.await_args.args
    assert "REDACTED" in fetch_args[4]


@pytest.mark.asyncio
async def test_cleanup_expired_payloads_returns_delete_counts(mock_pg_pool):
    conn = mock_pg_pool.acquire().__aenter__.return_value
    conn.fetchval = AsyncMock(side_effect=[2, 3])

    with patch("gateway.worker.queue.pg_db.get_pool", return_value=mock_pg_pool):
        result = await cleanup_expired_payloads()

    assert result == {"ingest_batches": 2, "processed_traces": 3}
