"""
Tests for the custom OTel SpanExporter.
"""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
from unittest.mock import MagicMock

from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExportResult
from opentelemetry.trace import SpanContext, TraceFlags

import aisquare.explainability.main as sdk_main
from aisquare.explainability.exporter import ExplainabilityExporter
from aisquare.explainability.inbox import InboxWriter


def _make_mock_span(
    trace_id: int = 1,
    span_id: int = 1,
    parent_span_id: int | None = None,
    name: str = "test",
    attributes: dict | None = None,
) -> MagicMock:
    """Create a mock ReadableSpan."""
    ctx = SpanContext(
        trace_id=trace_id,
        span_id=span_id,
        is_remote=False,
        trace_flags=TraceFlags(1),
    )
    span = MagicMock(spec=ReadableSpan)
    span.get_span_context.return_value = ctx
    span.name = name
    span.kind = MagicMock()
    span.kind.name = "INTERNAL"
    span.start_time = 1000000000
    span.end_time = 2000000000
    span.status = MagicMock()
    span.status.status_code = MagicMock()
    span.status.status_code.name = "OK"
    span.status.description = None
    span.attributes = attributes or {}
    span.events = []
    span.links = []

    if parent_span_id is not None:
        parent_ctx = SpanContext(
            trace_id=trace_id,
            span_id=parent_span_id,
            is_remote=False,
            trace_flags=TraceFlags(1),
        )
        span.parent = parent_ctx
    else:
        span.parent = None

    return span


class TestExplainabilityExporter:
    def setup_method(self):
        self._tmpfile = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self._tmpfile.close()
        self.db_path = self._tmpfile.name
        self.inbox = InboxWriter(self.db_path)
        self.inbox.ensure_schema()
        self.exporter = ExplainabilityExporter(
            inbox=self.inbox,
            idle_flush_seconds=0.01,
            force_flush_seconds=0.05,
            flush_interval_seconds=0.01,
        )

    def teardown_method(self):
        self.exporter.shutdown()
        self.inbox.close()
        os.unlink(self.db_path)

    def test_export_single_root_span(self):
        """Root span triggers immediate flush."""
        root = _make_mock_span(trace_id=1, span_id=1, name="root")
        result = self.exporter.export([root])
        assert result == SpanExportResult.SUCCESS

        import time

        time.sleep(0.06)

        conn = sqlite3.connect(self.db_path)
        rows = conn.execute("SELECT * FROM inbox WHERE status = 'pending'").fetchall()
        assert len(rows) == 1

        payload = json.loads(rows[0][2])
        assert payload["trace_id"] == format(1, "032x")
        assert len(payload["spans"]) == 1
        conn.close()

    def test_export_batches_by_trace(self):
        """Child spans are buffered until root arrives."""
        child = _make_mock_span(trace_id=1, span_id=2, parent_span_id=1, name="child")
        result1 = self.exporter.export([child])
        assert result1 == SpanExportResult.SUCCESS

        # No flush yet — child has a parent but root hasn't arrived
        conn = sqlite3.connect(self.db_path)
        rows = conn.execute("SELECT * FROM inbox").fetchall()
        assert len(rows) == 0
        conn.close()

        # Now send the root
        root = _make_mock_span(trace_id=1, span_id=1, name="root")
        result2 = self.exporter.export([root])
        assert result2 == SpanExportResult.SUCCESS

        import time

        # Windows timer resolution can make 30ms borderline for the idle flush thread.
        time.sleep(0.06)

        conn = sqlite3.connect(self.db_path)
        rows = conn.execute("SELECT * FROM inbox").fetchall()
        assert len(rows) == 1

        payload = json.loads(rows[0][2])
        assert len(payload["spans"]) == 2
        conn.close()

    def test_shutdown_flushes_remaining(self):
        """Shutdown flushes any buffered spans regardless of root."""
        child = _make_mock_span(trace_id=1, span_id=2, parent_span_id=1, name="child")
        self.exporter.export([child])

        conn = sqlite3.connect(self.db_path)
        assert conn.execute("SELECT COUNT(*) FROM inbox").fetchone()[0] == 0
        conn.close()

        self.exporter.shutdown()

        conn = sqlite3.connect(self.db_path)
        assert conn.execute("SELECT COUNT(*) FROM inbox").fetchone()[0] == 1
        conn.close()

    def test_multiple_traces_separate(self):
        """Spans from different traces are stored separately."""
        root1 = _make_mock_span(trace_id=1, span_id=1, name="root1")
        root2 = _make_mock_span(trace_id=2, span_id=3, name="root2")
        child2 = _make_mock_span(trace_id=2, span_id=4, parent_span_id=3, name="child2")

        self.exporter.export([root1, child2, root2])

        import time

        time.sleep(0.03)

        conn = sqlite3.connect(self.db_path)
        rows = conn.execute("SELECT * FROM inbox ORDER BY id").fetchall()
        assert len(rows) == 2

        payloads = [json.loads(r[2]) for r in rows]
        span_counts = sorted([len(p["spans"]) for p in payloads])
        assert span_counts == [1, 2]  # one trace has 1 span, the other has 2
        conn.close()

    def test_root_then_child_still_single_batch_after_idle_flush(self):
        root = _make_mock_span(trace_id=9, span_id=1, name="root")
        child = _make_mock_span(trace_id=9, span_id=2, parent_span_id=1, name="child")

        self.exporter.export([root])
        self.exporter.export([child])

        import time

        time.sleep(0.06)

        conn = sqlite3.connect(self.db_path)
        rows = conn.execute("SELECT * FROM inbox ORDER BY id").fetchall()
        assert len(rows) == 1
        payload = json.loads(rows[0][2])
        assert len(payload["spans"]) == 2
        conn.close()


class TestSdkInitReuse:
    def teardown_method(self):
        sdk_main._shutdown()
        sdk_main._INITIALIZED = False

    def test_init_reuses_existing_provider(self, monkeypatch, tmp_path):
        monkeypatch.setattr(sdk_main, "_install_agno_instrumentation", lambda: None)
        monkeypatch.setattr(sdk_main, "install_agno_hooks", lambda service_name: None)
        existing_provider = sdk_main.trace.get_tracer_provider()

        sdk_main.init(
            gateway_url="http://localhost:8000",
            api_key="test-key",
            inbox_path=str(tmp_path / "inbox.db"),
        )

        assert sdk_main._provider is existing_provider
