from __future__ import annotations

from gateway.db.schema import POSTGRES_DDL


def test_postgres_schema_enables_pgcrypto_before_uuid_defaults():
    ddl = POSTGRES_DDL.strip()
    assert ddl.startswith("CREATE EXTENSION IF NOT EXISTS pgcrypto;")
    assert "gen_random_uuid()" in ddl
