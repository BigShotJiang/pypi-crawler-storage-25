"""
Tests for security utilities including secret detection and sanitization.
"""

from gateway.security import (
    detect_secrets,
    redact_secrets,
    sanitize_html,
    sanitize_span_attributes,
)


def test_detect_openai_key():
    text = "My API key is sk-proj-abc123def456ghi789"
    secrets = detect_secrets(text)
    assert len(secrets) > 0
    assert any("OPENAI" in secret_type for _, secret_type in secrets)


def test_detect_anthropic_key():
    text = "Authorization: Bearer sk-ant-" + "a" * 95
    secrets = detect_secrets(text)
    assert len(secrets) > 0
    assert any("ANTHROPIC" in secret_type for _, secret_type in secrets)


def test_detect_bearer_token():
    text = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
    secrets = detect_secrets(text)
    assert len(secrets) > 0


def test_detect_aws_key():
    text = "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE"
    secrets = detect_secrets(text)
    assert len(secrets) > 0
    assert any("AWS" in secret_type for _, secret_type in secrets)


def test_detect_github_token():
    text = "ghp_1234567890abcdefghijklmnopqrstuvwxyz"
    secrets = detect_secrets(text)
    assert len(secrets) > 0
    assert any("GITHUB" in secret_type for _, secret_type in secrets)


def test_detect_password():
    text = 'password: "SuperSecret123!"'
    secrets = detect_secrets(text)
    assert len(secrets) > 0
    assert any("PASSWORD" in secret_type for _, secret_type in secrets)


def test_detect_private_key():
    text = "-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEA..."
    secrets = detect_secrets(text)
    assert len(secrets) > 0
    assert any("PRIVATE_KEY" in secret_type for _, secret_type in secrets)


def test_redact_secrets():
    text = "My key is sk-proj-abc123 and password is secret123"
    redacted = redact_secrets(text)
    assert "sk-proj-abc123" not in redacted
    assert "secret123" not in redacted
    assert "[REDACTED_" in redacted


def test_sanitize_span_attributes_with_secret():
    attrs = {
        "api_key": "sk-proj-abc123def456",
        "user_id": "user_123",
        "safe_value": 42,
    }
    sanitized = sanitize_span_attributes(attrs)
    assert "[REDACTED_" in sanitized["api_key"]
    assert sanitized["api_key._redacted"] is True
    assert sanitized["user_id"] == "user_123"
    assert sanitized["safe_value"] == 42


def test_sanitize_span_attributes_truncates_long_strings():
    attrs = {
        "very_long": "a" * 15000,
    }
    sanitized = sanitize_span_attributes(attrs)
    assert len(sanitized["very_long"]) == 10000


def test_sanitize_span_attributes_handles_complex_types():
    attrs = {
        "list_value": [1, 2, 3],
        "dict_value": {"key": "value"},
        "bool_value": True,
        "none_value": None,
    }
    sanitized = sanitize_span_attributes(attrs)
    assert sanitized["list_value"] == [1, 2, 3]
    assert sanitized["dict_value"] == {"key": "value"}
    assert sanitized["bool_value"] is True
    assert sanitized["none_value"] is None


def test_sanitize_html():
    html = '<script>alert("XSS")</script>'
    sanitized = sanitize_html(html)
    assert "<script>" not in sanitized
    assert "&lt;script&gt;" in sanitized


def test_sanitize_html_all_entities():
    text = '<>"&\'/test'
    sanitized = sanitize_html(text)
    assert "<" not in sanitized
    assert ">" not in sanitized
    assert '"' not in sanitized
    assert "&" not in sanitized or "&amp;" in sanitized
    assert "'" not in sanitized or "&#x27;" in sanitized
