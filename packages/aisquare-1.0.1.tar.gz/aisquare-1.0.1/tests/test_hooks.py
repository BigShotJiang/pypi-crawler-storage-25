"""
Tests for Agno hooks — verifies that each hook type creates proper OTel spans.
"""

from __future__ import annotations

import pytest
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor, SpanExporter, SpanExportResult

from aisquare.explainability.hooks import (
    AgentRunTracer,
    HumanInterventionTracer,
    LLMCallTracer,
    MemoryTracer,
    RetrievalTracer,
    RoutingTracer,
    ToolCallTracer,
    artifact_id,
    install_agno_hooks,
    trace_retrieval,
    trace_tool,
)


class SpanCollector(SpanExporter):
    """In-memory span collector for testing."""

    def __init__(self):
        super().__init__()
        self.spans = []

    def export(self, spans):
        self.spans.extend(spans)
        return SpanExportResult.SUCCESS

    def shutdown(self):
        pass

    def force_flush(self, timeout_millis=30000):
        return True


# Set up once for the module since TracerProvider can only be set once
_collector = SpanCollector()
_provider = TracerProvider()
_provider.add_span_processor(SimpleSpanProcessor(_collector))
trace.set_tracer_provider(_provider)


@pytest.fixture(autouse=True)
def setup_tracer():
    """Clear the collector and re-install hooks before each test."""
    _collector.spans.clear()

    import aisquare.explainability.hooks as hooks_module

    hooks_module._TRACER = None
    install_agno_hooks(service_name="test-agent")

    yield _collector


class TestAgentRunTracer:
    def test_creates_agent_span(self, setup_tracer):
        with AgentRunTracer(agent_name="TestAgent", run_id="run-1") as run:
            run.set_input("Hello")
            run.set_output("World")

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.name == "AgentRun:TestAgent"
        assert span.attributes["openinference.span.kind"] == "AGENT"
        assert span.attributes["agent.name"] == "TestAgent"

    def test_records_error(self, setup_tracer):
        try:
            with AgentRunTracer(agent_name="ErrorAgent", run_id="run-2"):
                raise ValueError("test error")
        except ValueError:
            pass

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.status.status_code.name == "ERROR"


class TestLLMCallTracer:
    def test_creates_llm_span(self, setup_tracer):
        with LLMCallTracer(model="claude-3-haiku", provider="anthropic") as llm:
            llm.set_input_messages([{"role": "user", "content": "Hi"}])
            llm.set_output_messages([{"role": "assistant", "content": "Hello!"}])
            llm.set_token_counts(prompt=10, completion=5)

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.name == "LLM:claude-3-haiku"
        assert span.attributes["openinference.span.kind"] == "LLM"
        assert span.attributes["llm.token_count.total"] == 15


class TestToolCallTracer:
    def test_creates_tool_span(self, setup_tracer):
        with ToolCallTracer(tool_name="web_search") as tool:
            tool.set_parameters({"query": "test"})
            tool.set_result("found it")

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.name == "Tool:web_search"
        assert span.attributes["openinference.span.kind"] == "TOOL"


class TestRetrievalTracer:
    def test_creates_retrieval_span(self, setup_tracer):
        with RetrievalTracer(source="pinecone", query="test query") as ret:
            ret.set_documents([{"content": "doc1", "score": 0.9}])
            ret.set_top_k(5)

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.name == "Retrieval:pinecone"
        assert span.attributes["openinference.span.kind"] == "RETRIEVER"
        assert span.attributes["retrieval.document_count"] == 1


class TestHumanInterventionTracer:
    def test_creates_intervention_span(self, setup_tracer):
        with HumanInterventionTracer(
            human_id="user@test.com",
            action="approve",
            reason="Looks good",
            role="reviewer",
        ) as hit:
            hit.set_original_output("original")
            hit.set_corrected_output("corrected")

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.name == "HumanIntervention:approve"
        assert span.attributes["intervention"] == "true"
        assert span.attributes["human.id"] == "user@test.com"


class TestRoutingTracer:
    def test_creates_routing_span(self, setup_tracer):
        with RoutingTracer(decision_type="agent_delegation") as rt:
            rt.set_selected("SummaryAgent", reason="User asked for summary")
            rt.set_rejected([{"name": "SearchAgent", "reason": "Not a search query"}])

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.name == "Routing:agent_delegation"
        assert span.attributes["routing.selected"] == "SummaryAgent"
        assert "routing.selected_json" in span.attributes


class TestMemoryTracer:
    def test_creates_memory_read_span(self, setup_tracer):
        with MemoryTracer(operation="read", memory_type="long_term") as mem:
            mem.set_query("previous conversation")
            mem.set_results([{"key": "conv1", "value": "Hello"}])

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.name == "Memory:read:long_term"
        assert span.attributes["memory.operation"] == "read"

    def test_creates_memory_write_span(self, setup_tracer):
        with MemoryTracer(operation="write", memory_type="short_term") as mem:
            mem.set_content("Important fact")
            mem.set_key("fact_1")

        assert len(setup_tracer.spans) == 1
        span = setup_tracer.spans[0]
        assert span.attributes["memory.content"] == "Important fact"


class TestDecorators:
    def test_trace_tool_decorator(self, setup_tracer):
        @trace_tool(name="my_tool")
        def my_func(x: int) -> int:
            return x * 2

        result = my_func(5)
        assert result == 10
        assert len(setup_tracer.spans) == 1
        assert setup_tracer.spans[0].name == "Tool:my_tool"

    def test_trace_retrieval_decorator(self, setup_tracer):
        @trace_retrieval(source="test_db")
        def search(query: str) -> list:
            return [{"content": "result1"}]

        results = search(query="test")
        assert len(results) == 1
        assert len(setup_tracer.spans) == 1
        assert setup_tracer.spans[0].name == "Retrieval:test_db"


class TestArtifactId:
    def test_deterministic(self):
        assert artifact_id("hello") == artifact_id("hello")

    def test_different_content(self):
        assert artifact_id("hello") != artifact_id("world")

    def test_length(self):
        assert len(artifact_id("test")) == 16
