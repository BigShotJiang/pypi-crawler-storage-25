from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from fastapi import Response

from gateway.main import CORS_ORIGINS, _initialise_runtime, app, ready


@pytest.mark.asyncio
async def test_ready_returns_200_when_dependencies_are_healthy():
    response = Response()

    with (
        patch("gateway.main.neo4j_db.check_health", new=AsyncMock(return_value=True)),
        patch("gateway.main.pg_db.check_health", new=AsyncMock(return_value=True)),
        patch("gateway.main.redis_db.check_health", new=AsyncMock(return_value=True)),
    ):
        payload = await ready(response)

    assert response.status_code == 200
    assert payload.neo4j == "ok"
    assert payload.postgres == "ok"
    assert payload.redis == "ok"


@pytest.mark.asyncio
async def test_ready_returns_503_when_any_dependency_is_unhealthy():
    response = Response()

    with (
        patch("gateway.main.neo4j_db.check_health", new=AsyncMock(return_value=True)),
        patch("gateway.main.pg_db.check_health", new=AsyncMock(return_value=False)),
        patch("gateway.main.redis_db.check_health", new=AsyncMock(return_value=True)),
    ):
        payload = await ready(response)

    assert response.status_code == 503
    assert payload.neo4j == "ok"
    assert payload.postgres == "error"
    assert payload.redis == "ok"


@pytest.mark.asyncio
async def test_initialise_runtime_retries_before_succeeding():
    init_all = AsyncMock(side_effect=[RuntimeError("db not ready"), None])
    start_worker = AsyncMock()
    cleanup = AsyncMock()
    recover = AsyncMock()
    sleep = AsyncMock()

    with (
        patch("gateway.main.STARTUP_RETRIES", 2),
        patch("gateway.main.STARTUP_RETRY_SECONDS", 0),
        patch("gateway.main.init_all", init_all),
        patch("gateway.main.start_worker", start_worker),
        patch("gateway.main.cleanup_expired_payloads", cleanup),
        patch("gateway.main.recover_pending_traces", recover),
        patch("gateway.main.asyncio.sleep", sleep),
    ):
        await _initialise_runtime()

    assert init_all.await_count == 2
    sleep.assert_awaited_once()
    start_worker.assert_awaited_once()
    cleanup.assert_awaited_once()
    recover.assert_awaited_once_with(limit=50)


def test_openapi_includes_frontend_ui_paths():
    schema = app.openapi()
    paths = schema["paths"]

    assert "/v1/studios/{studio_id}/ui/runs" in paths
    assert "/v1/studios/{studio_id}/ui/agents" in paths
    assert "/v1/studios/{studio_id}/ui/runs/{run_id}" in paths
    assert "/v1/studios/{studio_id}/ui/runs/{run_id}/xtrace" in paths
    assert "/v1/studios/{studio_id}/ui/runs/{run_id}/graph" in paths
    assert "/v1/studios/{studio_id}/ui/runs/{run_id}/nodes/{node_id}" in paths
    assert "/v1/studios/{studio_id}/ui/policies" in paths
    assert "/v1/studios/{studio_id}/ui/setup" in paths


def test_default_cors_origins_include_localdev_frontend():
    assert "http://localhost:3001" in CORS_ORIGINS
    assert "http://127.0.0.1:3001" in CORS_ORIGINS
