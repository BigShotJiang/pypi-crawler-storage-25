from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

import httpx
import pytest

pytestmark = pytest.mark.integration


TRACE_TEMPLATE = {
    "spans": [
        {
            "trace_id": "",
            "span_id": "00000000000000a1",
            "parent_span_id": None,
            "name": "AgentRun:IntegrationAgent",
            "kind": "INTERNAL",
            "start_time": 1000,
            "end_time": 2000,
            "duration_ms": 1.0,
            "status": {"status_code": "OK", "description": None},
            "attributes": {
                "openinference.span.kind": "AGENT",
                "agent.name": "IntegrationAgent",
                "input.value": "Always respond in English. What is the capital of France?",
                "output.value": "The capital of France is Paris.",
            },
            "events": [
                {
                    "name": "agent.started",
                    "timestamp": 1001,
                    "attributes": {"phase": "start"},
                }
            ],
            "links": [],
        },
        {
            "trace_id": "",
            "span_id": "00000000000000a2",
            "parent_span_id": "00000000000000a1",
            "name": "LLM:integration-model",
            "kind": "INTERNAL",
            "start_time": 1100,
            "end_time": 1500,
            "duration_ms": 0.4,
            "status": {"status_code": "OK", "description": None},
            "attributes": {
                "openinference.span.kind": "LLM",
                "llm.model_name": "integration-model",
                "llm.input_messages": (
                    '[{"role":"user","content":"Always respond in English. '
                    'What is the capital of France?"}]'
                ),
                "llm.output_messages": (
                    '[{"role":"assistant","content":"The capital of France is Paris."}]'
                ),
            },
            "events": [],
            "links": [],
        },
    ]
}


INTEGRATION_SKIP_REASON = "Set RUN_DOCKER_INTEGRATION=1 and install docker"


def _integration_enabled() -> bool:
    return os.getenv("RUN_DOCKER_INTEGRATION") == "1" and shutil.which("docker") is not None


@pytest.mark.skipif(not _integration_enabled(), reason=INTEGRATION_SKIP_REASON)
def test_docker_stack_end_to_end():
    repo_root = Path(__file__).resolve().parents[1]
    gateway_port = "8010"
    env = os.environ.copy()
    env.update(
        {
            "ALLOW_TEST_AUTH_BYPASS": "true",
            "EXPLAINABILITY_ADMIN_API_KEYS": "local-admin-key",
            "POSTGRES_DSN": "postgresql://postgres:postgres@localhost:5433/explainability",
            "REDIS_URL": "redis://localhost:6379/0",
            "NEO4J_URI": "bolt://localhost:7687",
            "NEO4J_USER": "neo4j",
            "NEO4J_PASSWORD": "password",
            "EXPLAINABILITY_TRACE_IDLE_SECONDS": "1",
            "EXPLAINABILITY_QUEUE_POLL_SECONDS": "1",
        }
    )

    gateway_proc: subprocess.Popen[str] | None = None
    try:
        subprocess.run(
            ["docker", "compose", "up", "-d", "postgres", "redis", "neo4j"],
            cwd=repo_root,
            check=True,
        )
        time.sleep(15)

        gateway_proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "gateway.main:app",
                "--host",
                "127.0.0.1",
                "--port",
                gateway_port,
            ],
            cwd=repo_root,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )

        base_url = f"http://127.0.0.1:{gateway_port}"
        with httpx.Client(timeout=30.0) as client:
            for _ in range(60):
                try:
                    live = client.get(f"{base_url}/live")
                    if live.status_code == 200:
                        break
                except Exception:
                    pass
                time.sleep(1)
            else:
                raise AssertionError("Gateway failed to start")

            trace_id = uuid.uuid4().hex
            trace = {"trace_id": trace_id, "spans": []}
            for span in TRACE_TEMPLATE["spans"]:
                span_copy = dict(span)
                span_copy["trace_id"] = trace_id
                trace["spans"].append(span_copy)

            headers = {"Authorization": "Bearer test-key"}
            admin_headers = {"Authorization": "Bearer local-admin-key"}

            ingest = client.post(f"{base_url}/v1/traces/ingest", headers=headers, json=trace)
            assert ingest.status_code == 202

            ui_runs_payload = None
            for _ in range(20):
                ui_runs = client.get(
                    f"{base_url}/v1/studios/test_studio/ui/runs?limit=20&offset=0",
                    headers=headers,
                )
                assert ui_runs.status_code == 200
                ui_runs_payload = ui_runs.json()
                matching = next(
                    (item for item in ui_runs_payload["runs"] if item["run_id"] == trace_id),
                    None,
                )
                if matching and matching["status"] == "ready":
                    break
                time.sleep(1)
            else:
                raise AssertionError("UI run never became ready")

            runs = client.get(f"{base_url}/v1/studios/test_studio/runs", headers=headers)
            assert runs.status_code == 200
            assert any(item["run_id"] == trace_id for item in runs.json())

            ui_run = client.get(
                f"{base_url}/v1/studios/test_studio/ui/runs/{trace_id}",
                headers=headers,
            )
            assert ui_run.status_code == 200
            assert ui_run.json()["status"] == "ready"

            ui_runs_filtered = client.get(
                (
                    f"{base_url}/v1/studios/test_studio/ui/runs"
                    "?q=IntegrationAgent&agent=IntegrationAgent&status=ready&has_errors=false"
                ),
                headers=headers,
            )
            assert ui_runs_filtered.status_code == 200
            assert any(item["run_id"] == trace_id for item in ui_runs_filtered.json()["runs"])

            ui_agents = client.get(
                f"{base_url}/v1/studios/test_studio/ui/agents",
                headers=headers,
            )
            assert ui_agents.status_code == 200
            assert any(item["name"] == "IntegrationAgent" for item in ui_agents.json()["agents"])

            ui_xtrace = client.get(
                f"{base_url}/v1/studios/test_studio/ui/runs/{trace_id}/xtrace",
                headers=headers,
            )
            assert ui_xtrace.status_code == 200
            assert ui_xtrace.json()["span_count"] == 2

            ui_graph_span = client.get(
                f"{base_url}/v1/studios/test_studio/ui/runs/{trace_id}/graph?mode=span",
                headers=headers,
            )
            assert ui_graph_span.status_code == 200
            ui_graph_span_payload = ui_graph_span.json()
            assert ui_graph_span_payload["status"] == "ready"
            assert ui_graph_span_payload["graph"]["nodes"]

            ui_graph_event = client.get(
                f"{base_url}/v1/studios/test_studio/ui/runs/{trace_id}/graph?mode=event",
                headers=headers,
            )
            assert ui_graph_event.status_code == 200
            ui_graph_event_payload = ui_graph_event.json()
            assert ui_graph_event_payload["status"] == "ready"
            assert ui_graph_event_payload["graph"]["nodes"]

            graph = client.get(
                f"{base_url}/v1/studios/test_studio/runs/{trace_id}/graph?include_events=true",
                headers=headers,
            )
            assert graph.status_code == 200
            payload = graph.json()
            assert payload["nodes"]
            assert payload["edges"]

            policies = client.get(f"{base_url}/v1/studios/test_studio/policies", headers=headers)
            assert policies.status_code == 200

            ui_policies = client.get(
                f"{base_url}/v1/studios/test_studio/ui/policies",
                headers=headers,
            )
            assert ui_policies.status_code == 200

            ui_setup = client.get(
                f"{base_url}/v1/studios/test_studio/ui/setup",
                headers=headers,
            )
            assert ui_setup.status_code == 200
            assert ui_setup.json()["auth_mode"] == "dev-bypass"

            span_detail = client.get(
                f"{base_url}/v1/studios/test_studio/ui/runs/{trace_id}/nodes/{trace_id}:00000000000000a1",
                headers=headers,
            )
            assert span_detail.status_code == 200
            assert span_detail.json()["node"]["kind"] == "Span"

            event_detail = client.get(
                f"{base_url}/v1/studios/test_studio/ui/runs/{trace_id}/nodes/{trace_id}:00000000000000a1:event:start",
                headers=headers,
            )
            assert event_detail.status_code == 200
            assert event_detail.json()["node"]["kind"] == "Event"

            recover = client.post(f"{base_url}/v1/admin/recover", headers=admin_headers)
            assert recover.status_code == 200
    finally:
        if gateway_proc is not None:
            gateway_proc.terminate()
            gateway_proc.wait(timeout=20)
        subprocess.run(["docker", "compose", "down", "-v"], cwd=repo_root, check=False)
