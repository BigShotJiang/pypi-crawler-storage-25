"""
Tests for the Pydantic models used in the gateway.
"""

from __future__ import annotations

import pytest

from gateway.models import (
    AttributionRecord,
    HealthStatus,
    InferenceStep,
    IngestResponse,
    PolicyTrigger,
    ReactFlowEdge,
    ReactFlowGraph,
    ReactFlowNode,
    RMLSpanOutput,
    SpanPayload,
    TraceBatch,
    UIAgentsResponse,
    UIGraphResponse,
    UINodeDetail,
    UINodeDetailResponse,
    UINodeLink,
    UIPoliciesResponse,
    UIPolicySummary,
    UIRunDetailResponse,
    UIRunsResponse,
    UISetupResponse,
    UIXTraceResponse,
)


class TestSpanPayload:
    def test_minimal_span(self):
        sp = SpanPayload(
            trace_id="abc",
            span_id="def",
            name="test",
        )
        assert sp.trace_id == "abc"
        assert sp.parent_span_id is None
        assert sp.attributes == {}

    def test_full_span(self):
        sp = SpanPayload(
            trace_id="abc",
            span_id="def",
            parent_span_id="ghi",
            name="LLM:claude",
            kind="INTERNAL",
            start_time=100,
            end_time=200,
            duration_ms=100.0,
            status={"status_code": "OK"},
            attributes={"llm.model_name": "claude-3"},
        )
        assert sp.duration_ms == 100.0
        assert sp.attributes["llm.model_name"] == "claude-3"


class TestTraceBatch:
    def test_batch_with_spans(self):
        batch = TraceBatch(
            trace_id="trace-1",
            spans=[
                SpanPayload(trace_id="trace-1", span_id="s1", name="root"),
                SpanPayload(trace_id="trace-1", span_id="s2", name="child", parent_span_id="s1"),
            ],
        )
        assert len(batch.spans) == 2
        assert batch.trace_id == "trace-1"


class TestRMLModels:
    def test_attribution_record(self):
        ar = AttributionRecord(
            input_chunk="France capital",
            output_chunk="Paris",
            attribution_type="evidence_used",
            confidence=0.95,
        )
        assert ar.confidence == 0.95

    def test_attribution_record_invalid_confidence(self):
        with pytest.raises(Exception):
            AttributionRecord(
                input_chunk="a",
                output_chunk="b",
                attribution_type="evidence_used",
                confidence=1.5,  # out of range
            )

    def test_inference_step(self):
        step = InferenceStep(step_number=1, reasoning="Given X", conclusion="Therefore Y")
        assert step.step_number == 1

    def test_policy_trigger(self):
        pt = PolicyTrigger(
            raw_text="Always respond in JSON",
            normalized_text="always respond in json",
            instruction_type="format",
        )
        assert pt.instruction_type == "format"

    def test_rml_span_output(self):
        rml = RMLSpanOutput(
            claims=["Paris is the capital"],
            assumptions=[],
            extraction_confidence=0.9,
        )
        assert len(rml.claims) == 1
        assert rml.extraction_confidence == 0.9


class TestReactFlowModels:
    def test_node(self):
        node = ReactFlowNode(
            id="n1",
            type="agentNode",
            data={"label": "Agent"},
        )
        assert node.id == "n1"
        assert node.position == {"x": 0, "y": 0}

    def test_edge(self):
        edge = ReactFlowEdge(
            id="e1",
            source="n1",
            target="n2",
            label="CONTAINS",
        )
        assert edge.animated is False

    def test_graph(self):
        graph = ReactFlowGraph(
            nodes=[ReactFlowNode(id="n1", data={"label": "A"})],
            edges=[ReactFlowEdge(id="e1", source="n1", target="n2")],
        )
        assert len(graph.nodes) == 1
        assert len(graph.edges) == 1


class TestHealthStatus:
    def test_defaults(self):
        h = HealthStatus()
        assert h.neo4j == "unknown"

    def test_all_ok(self):
        h = HealthStatus(neo4j="ok", postgres="ok", redis="ok")
        assert h.postgres == "ok"


class TestIngestResponse:
    def test_response(self):
        r = IngestResponse(trace_id="t1", span_count=5)
        assert r.status == "accepted"
        assert r.span_count == 5


class TestUIModels:
    def test_ui_runs_response(self):
        response = UIRunsResponse()
        assert response.status == "ok"
        assert response.runs == []

    def test_ui_run_detail_response(self):
        response = UIRunDetailResponse(status="processing")
        assert response.status == "processing"
        assert response.run is None

    def test_ui_node_detail_response(self):
        detail = UINodeDetail(
            id="trace:span-1",
            kind="Span",
            label="AgentRun",
        )
        response = UINodeDetailResponse(status="ready", node=detail)
        assert response.node is not None
        assert response.node.kind == "Span"

    def test_ui_node_link(self):
        link = UINodeLink(id="artifact-1", kind="Artifact", label="Artifact")
        assert link.label == "Artifact"

    def test_ui_graph_response(self):
        response = UIGraphResponse(status="processing")
        assert response.status == "processing"
        assert response.graph is None

    def test_ui_policy_response(self):
        response = UIPoliciesResponse(
            policies=[
                UIPolicySummary(
                    id="policy-1",
                    fingerprint="abc",
                    label="Always respond in English",
                    status="proposed",
                )
            ]
        )
        assert len(response.policies) == 1

    def test_ui_agents_response(self):
        response = UIAgentsResponse()
        assert response.status == "ok"
        assert response.agents == []

    def test_ui_xtrace_response(self):
        response = UIXTraceResponse(status="processing", trace_id="trace-1")
        assert response.trace_id == "trace-1"
        assert response.trace_json == {}

    def test_ui_setup_response(self):
        response = UISetupResponse(
            docs_url="http://localhost:8000/docs",
            auth_mode="dev-bypass",
            install_command="pip install -e \".[dev,agno]\"",
            env_snippet="EXPLAINABILITY_GATEWAY_URL=http://localhost:8000",
            quickstart_snippet="import aisquare.explainability as sdk",
        )
        assert response.docs_url.endswith("/docs")
