"""
Tests for the SQLite inbox writer and serialisation helpers.
"""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile

from aisquare.explainability.inbox import InboxWriter


class TestInboxWriter:
    def setup_method(self):
        self._tmpfile = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self._tmpfile.close()
        self.db_path = self._tmpfile.name
        self.writer = InboxWriter(self.db_path)
        self.writer.ensure_schema()

    def teardown_method(self):
        self.writer.close()
        os.unlink(self.db_path)

    def test_schema_created(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='inbox'"
        )
        assert cursor.fetchone() is not None
        conn.close()

    def test_insert_and_read(self):
        payload = json.dumps({"trace_id": "t1", "spans": []})
        self.writer.insert("t1", payload)

        conn = sqlite3.connect(self.db_path)
        rows = conn.execute("SELECT * FROM inbox WHERE trace_id = 't1'").fetchall()
        assert len(rows) == 1
        assert rows[0][1] == "t1"  # trace_id column
        assert rows[0][3] == "pending"  # status column
        conn.close()

    def test_multiple_inserts(self):
        for i in range(5):
            self.writer.insert(f"t{i}", f'{{"trace_id": "t{i}"}}')

        conn = sqlite3.connect(self.db_path)
        count = conn.execute("SELECT COUNT(*) FROM inbox").fetchone()[0]
        assert count == 5
        conn.close()

    def test_ensure_schema_idempotent(self):
        # Calling ensure_schema twice should not fail
        self.writer.ensure_schema()
        self.writer.ensure_schema()

        conn = sqlite3.connect(self.db_path)
        count = conn.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='inbox'"
        ).fetchone()[0]
        assert count == 1
        conn.close()

    def test_ensure_schema_migrates_legacy_inbox(self):
        self.writer.close()

        conn = sqlite3.connect(self.db_path)
        conn.execute("DROP TABLE IF EXISTS inbox")
        conn.execute(
            """
            CREATE TABLE inbox (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                trace_id    TEXT NOT NULL,
                payload     TEXT NOT NULL,
                status      TEXT NOT NULL DEFAULT 'pending',
                retries     INTEGER NOT NULL DEFAULT 0,
                created_at  TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
            )
            """
        )
        conn.commit()
        conn.close()

        self.writer = InboxWriter(self.db_path)
        self.writer.ensure_schema()
        self.writer.insert("legacy-trace", '{"trace_id":"legacy-trace","spans":[]}')

        conn = sqlite3.connect(self.db_path)
        columns = {row[1] for row in conn.execute("PRAGMA table_info(inbox)").fetchall()}
        assert "next_attempt_at" in columns
        assert "last_error" in columns
        rows = conn.execute(
            "SELECT trace_id, status FROM inbox WHERE trace_id = 'legacy-trace'"
        ).fetchall()
        assert rows == [("legacy-trace", "pending")]
        conn.close()
