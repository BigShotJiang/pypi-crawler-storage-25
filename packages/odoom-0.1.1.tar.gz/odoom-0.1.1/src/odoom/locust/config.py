# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: config.py — odoom/locust/config.py

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class OdooLocustConfig:
    url: str
    db: str
    username: str
    password: str
    dataset_root: str
    timeout: float = 60.0


def _pick(
    parsed_options: Any, attr_name: str, env_name: str, default: Any = None
) -> Any:
    value = (
        getattr(parsed_options, attr_name, None) if parsed_options is not None else None
    )
    if value not in (None, ""):
        return value
    env_value = os.getenv(env_name)
    if env_value not in (None, ""):
        return env_value
    return default


def load_config(
    environment: Any, default_dataset_root: str | None = None
) -> OdooLocustConfig:
    options = getattr(environment, "parsed_options", None)
    cfg = OdooLocustConfig(
        url=_pick(options, "odoo_url", "LOCUST_ODOO_URL"),
        db=_pick(options, "odoo_db", "LOCUST_ODOO_DB"),
        username=_pick(options, "odoo_username", "LOCUST_ODOO_USERNAME"),
        password=_pick(options, "odoo_password", "LOCUST_ODOO_PASSWORD"),
        dataset_root=_pick(
            options, "odoo_dataset_root", "LOCUST_ODOO_DATASET_ROOT", default_dataset_root
        ),
        timeout=float(_pick(options, "odoo_timeout", "LOCUST_ODOO_TIMEOUT", 60.0)),
    )
    missing = [
        name
        for name, value in {
            "odoo_url": cfg.url,
            "odoo_db": cfg.db,
            "odoo_username": cfg.username,
            "odoo_password": cfg.password,
            "odoo_dataset_root": cfg.dataset_root,
        }.items()
        if value in (None, "")
    ]
    if missing:
        raise RuntimeError("Missing Odoo/Locust configuration: " + ", ".join(missing))
    return cfg
