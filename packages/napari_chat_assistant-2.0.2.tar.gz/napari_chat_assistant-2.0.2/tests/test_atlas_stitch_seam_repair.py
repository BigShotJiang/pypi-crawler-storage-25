from __future__ import annotations

import numpy as np
import zarr
from tifffile import imwrite

from napari_chat_assistant.atlas_stitch.models import AtlasMetadata, AtlasProject, TileRecord, TileTransform
from napari_chat_assistant.atlas_stitch.ome_zarr_export import export_nominal_layout_to_omezarr
from napari_chat_assistant.atlas_stitch.project_state import load_atlas_project, save_atlas_project
from napari_chat_assistant.atlas_stitch.seam_repair import (
    BLEND_MODE_HARD_REPLACE,
    REPAIR_MODE_FULL_OVERLAP,
    REPAIR_MODE_ROI_GUIDED,
    RepairDonorSpec,
    TileRepairRequest,
    reconstruct_tile_from_donors,
    save_repair_outputs,
)


def test_reconstruct_tile_from_donors_preserves_shape_and_uses_priority(tmp_path):
    target_path = tmp_path / "target.tif"
    donor_a_path = tmp_path / "donor_a.tif"
    donor_b_path = tmp_path / "donor_b.tif"
    imwrite(target_path, np.full((6, 6), 10, dtype=np.uint16))
    imwrite(donor_a_path, np.full((6, 6), 50, dtype=np.uint16))
    imwrite(donor_b_path, np.full((6, 6), 90, dtype=np.uint16))

    project = AtlasProject(
        metadata=AtlasMetadata(atlas_name="atlas"),
        tiles=[
            _tile_record("target", target_path, nominal_x=0.0, nominal_y=0.0, width=6, height=6),
            _tile_record("donor_a", donor_a_path, nominal_x=0.0, nominal_y=0.0, width=6, height=6),
            _tile_record("donor_b", donor_b_path, nominal_x=0.0, nominal_y=0.0, width=6, height=6),
        ],
    )
    request = TileRepairRequest(
        target_tile_id="target",
        donors=[
            RepairDonorSpec(tile_id="donor_a", direction="right", priority=0),
            RepairDonorSpec(tile_id="donor_b", direction="right", priority=1),
        ],
        overlap_width=2,
        repair_mode=REPAIR_MODE_ROI_GUIDED,
        blend_mode=BLEND_MODE_HARD_REPLACE,
        roi_bounds=(1, 1, 5, 5),
    )

    result = reconstruct_tile_from_donors(project, request)

    assert result.repaired_tile.shape == (6, 6)
    assert np.all(result.repaired_tile[1:5, 1:5] == 50)
    assert np.all(result.repaired_tile[:, 0] == 10)
    assert np.all(result.attribution_map[1:5, 1:5] == 1)
    assert np.all(result.confidence_map[1:5, 1:5] == 1.0)
    assert np.all(result.confidence_map[0, :] == 0.5)


def test_reconstruct_tile_from_donors_limits_full_overlap_to_requested_strip(tmp_path):
    target_path = tmp_path / "target.tif"
    donor_path = tmp_path / "donor_right.tif"
    imwrite(target_path, np.full((6, 6), 10, dtype=np.uint16))
    imwrite(donor_path, np.full((6, 6), 80, dtype=np.uint16))

    project = AtlasProject(
        metadata=AtlasMetadata(atlas_name="atlas"),
        tiles=[
            _tile_record("target", target_path, nominal_x=0.0, nominal_y=0.0, width=6, height=6),
            _tile_record("donor_right", donor_path, nominal_x=4.0, nominal_y=0.0, width=6, height=6),
        ],
    )
    request = TileRepairRequest(
        target_tile_id="target",
        donors=[RepairDonorSpec(tile_id="donor_right", direction="right", priority=0)],
        overlap_width=2,
        repair_mode=REPAIR_MODE_FULL_OVERLAP,
        blend_mode=BLEND_MODE_HARD_REPLACE,
    )

    result = reconstruct_tile_from_donors(project, request)

    assert np.all(result.repaired_tile[:, :4] == 10)
    assert np.all(result.repaired_tile[:, 4:] == 80)
    assert np.all(result.attribution_map[:, :4] == 0)
    assert np.all(result.attribution_map[:, 4:] == 1)


def test_reconstruct_tile_from_donors_marks_unresolved_regions_with_zero_confidence(tmp_path):
    target_path = tmp_path / "target.tif"
    donor_path = tmp_path / "donor_far.tif"
    imwrite(target_path, np.full((6, 6), 10, dtype=np.uint16))
    imwrite(donor_path, np.full((6, 6), 80, dtype=np.uint16))

    project = AtlasProject(
        metadata=AtlasMetadata(atlas_name="atlas"),
        tiles=[
            _tile_record("target", target_path, nominal_x=0.0, nominal_y=0.0, width=6, height=6),
            _tile_record("donor_far", donor_path, nominal_x=20.0, nominal_y=0.0, width=6, height=6),
        ],
    )
    request = TileRepairRequest(
        target_tile_id="target",
        donors=[RepairDonorSpec(tile_id="donor_far", direction="right", priority=0)],
        overlap_width=2,
        repair_mode=REPAIR_MODE_ROI_GUIDED,
        blend_mode=BLEND_MODE_HARD_REPLACE,
        roi_bounds=(2, 2, 4, 4),
    )

    result = reconstruct_tile_from_donors(project, request)

    assert np.all(result.repaired_tile == 10)
    assert np.all(result.confidence_map[2:4, 2:4] == 0.0)
    assert np.all(result.attribution_map[2:4, 2:4] == 0)


def test_save_load_project_preserves_repair_paths_and_history(tmp_path):
    target_path = tmp_path / "target.tif"
    imwrite(target_path, np.full((4, 4), 7, dtype=np.uint16))
    tile = _tile_record("target", target_path, nominal_x=0.0, nominal_y=0.0, width=4, height=4)
    tile.repaired_path = str(tmp_path / "target_repaired.tif")
    tile.repair_confidence_path = str(tmp_path / "target_confidence.tif")
    tile.repair_attribution_path = str(tmp_path / "target_attribution.tif")
    tile.repair_history.append({"target_tile_id": "target", "repair_mode": "roi_guided"})
    project = AtlasProject(metadata=AtlasMetadata(atlas_name="atlas"), tiles=[tile])

    destination = tmp_path / "atlas_project.json"
    save_atlas_project(project, str(destination))
    restored = load_atlas_project(str(destination))

    restored_tile = restored.tiles[0]
    assert restored_tile.repaired_path == tile.repaired_path
    assert restored_tile.repair_confidence_path == tile.repair_confidence_path
    assert restored_tile.repair_attribution_path == tile.repair_attribution_path
    assert restored_tile.repair_history == tile.repair_history


def test_save_repair_outputs_and_export_prefer_repaired_tile_content(tmp_path):
    target_path = tmp_path / "target.tif"
    donor_path = tmp_path / "donor.tif"
    imwrite(target_path, np.full((4, 4), 1, dtype=np.uint16))
    imwrite(donor_path, np.full((4, 4), 9, dtype=np.uint16))

    tile = _tile_record("target", target_path, nominal_x=0.0, nominal_y=0.0, width=4, height=4)
    project = AtlasProject(
        metadata=AtlasMetadata(atlas_name="atlas"),
        tiles=[tile, _tile_record("donor", donor_path, nominal_x=0.0, nominal_y=0.0, width=4, height=4)],
    )
    request = TileRepairRequest(
        target_tile_id="target",
        donors=[RepairDonorSpec(tile_id="donor", direction="right", priority=0)],
        overlap_width=2,
        repair_mode=REPAIR_MODE_ROI_GUIDED,
        blend_mode=BLEND_MODE_HARD_REPLACE,
        roi_bounds=(0, 0, 4, 4),
    )
    result = reconstruct_tile_from_donors(project, request)
    saved = save_repair_outputs(
        tile,
        result,
        str(tmp_path / "repairs"),
        repair_mode=request.repair_mode,
        blend_mode=request.blend_mode,
        overlap_width=request.overlap_width,
    )
    tile.repaired_path = saved["repaired_path"]
    tile.repair_confidence_path = saved["confidence_path"]
    tile.repair_attribution_path = saved["attribution_path"]
    tile.repair_history.append(saved["history_entry"])

    exported = export_nominal_layout_to_omezarr(project, str(tmp_path / "atlas_export"))
    root = zarr.open_group(str(exported), mode="r")
    exported_pixels = np.asarray(root["0"])

    assert np.all(exported_pixels == 9)


def _tile_record(tile_id: str, path, *, nominal_x: float, nominal_y: float, width: int, height: int) -> TileRecord:
    return TileRecord(
        tile_id=tile_id,
        resolved_path=str(path),
        start_x=nominal_x,
        start_y=nominal_y,
        width=width,
        height=height,
        exists=True,
        transform=TileTransform(nominal_x=nominal_x, nominal_y=nominal_y),
    )
