"""Unit tests for the local harness — mocks the provider send() with
canned responses so the harness logic, SDKMessage shapes, tool dispatch,
and compaction trigger can be tested deterministically.
"""
from __future__ import annotations

import asyncio
import json
import os
import tempfile
from pathlib import Path

import pytest

from polarity_keystone import (
    LocalAgent, LocalAgentOptions, LocalSendOptions,
    ProviderRequest, ProviderResponse, ProviderToolCall, ProviderUsage,
    ProviderMessage,
    ToolDefinition,
    CompactionOptions, should_compact,
    unprefix_model, is_reasoning_model,
    create_local_agent, prompt_local_agent,
)
from polarity_keystone.harness import providers as harness_providers


@pytest.fixture
def tmp_workdir(tmp_path):
    return str(tmp_path)


def _mock_send(responses):
    """Build an async mock for harness.providers.send that returns
    canned responses in order. Each entry is a dict with optional
    'text' and 'tool_calls' ([{name, input}, ...])."""
    queue = list(responses)
    captured = []

    async def fake_send(req: ProviderRequest) -> ProviderResponse:
        captured.append(req)
        if not queue:
            return ProviderResponse(text="[mock exhausted]")
        canned = queue.pop(0)
        tool_calls = [
            ProviderToolCall(id=f"call_{i}", name=tc["name"], input=tc["input"])
            for i, tc in enumerate(canned.get("tool_calls", []))
        ]
        return ProviderResponse(
            text=canned.get("text", ""),
            tool_calls=tool_calls,
            finish_reason="tool_calls" if tool_calls else "stop",
            usage=ProviderUsage(prompt_tokens=100, completion_tokens=50, total_tokens=150),
        )
    return fake_send, captured


@pytest.mark.asyncio
async def test_no_tool_send_emits_full_taxonomy(tmp_workdir, monkeypatch):
    fake, _ = _mock_send([{"text": "the answer is 4"}])
    monkeypatch.setattr(harness_providers, "send", fake)
    # Also patch the one re-exported into harness.harness
    import polarity_keystone.harness.harness as harness_mod
    monkeypatch.setattr(harness_mod, "send", fake)

    agent = create_local_agent(LocalAgentOptions(
        model="openai/gpt-4o-mini", api_key="sk-test", working_dir=tmp_workdir,
    ))
    try:
        run = agent.send("what is 2+2?")
        types = []
        async for msg in run.stream():
            types.append(msg["type"])
        result = await run.wait()
    finally:
        await agent.close()

    assert "status" in types
    assert "system" in types
    assert "user" in types
    assert "assistant" in types
    assert result["status"] == "finished"
    assert "4" in (result.get("result") or "")


@pytest.mark.asyncio
async def test_dispatches_builtin_write_then_read(tmp_workdir, monkeypatch):
    fake, captured = _mock_send([
        {"tool_calls": [{"name": "write", "input": {"path": "note.txt", "content": "hello keystone"}}]},
        {"tool_calls": [{"name": "read", "input": {"path": "note.txt"}}]},
        {"text": "the file contains: hello keystone"},
    ])
    import polarity_keystone.harness.harness as harness_mod
    monkeypatch.setattr(harness_mod, "send", fake)

    agent = create_local_agent(LocalAgentOptions(
        model="openai/gpt-4o-mini", api_key="sk-test", working_dir=tmp_workdir,
    ))
    try:
        run = agent.send("write note.txt then read it")
        tool_events = []
        async for msg in run.stream():
            if msg["type"] == "tool_call":
                tool_events.append((msg["name"], msg["status"]))
        result = await run.wait()
    finally:
        await agent.close()

    assert tool_events == [
        ("write", "running"), ("write", "completed"),
        ("read", "running"), ("read", "completed"),
    ]
    assert (Path(tmp_workdir) / "note.txt").read_text() == "hello keystone"
    assert result["status"] == "finished"
    assert len(captured) == 3


@pytest.mark.asyncio
async def test_dispatches_custom_tool(tmp_workdir, monkeypatch):
    fake, _ = _mock_send([
        {"tool_calls": [{"name": "lookup_order", "input": {"orderId": "ord-42"}}]},
        {"text": "order ord-42 is shipped"},
    ])
    import polarity_keystone.harness.harness as harness_mod
    monkeypatch.setattr(harness_mod, "send", fake)

    handler_called = {"v": False, "args": None}

    async def lookup_order(args, _ctx):
        handler_called["v"] = True
        handler_called["args"] = args
        return {"success": {"status": "shipped"}}

    custom = ToolDefinition(
        name="lookup_order",
        description="Fetch order status",
        input_schema={"type": "object", "properties": {"orderId": {"type": "string"}}, "required": ["orderId"]},
        handler=lookup_order,
    )
    result = await prompt_local_agent("look up ord-42", LocalAgentOptions(
        model="openai/gpt-4o-mini", api_key="sk-test", working_dir=tmp_workdir,
        custom_tools=[custom],
    ))

    assert handler_called["v"] is True
    assert handler_called["args"] == {"orderId": "ord-42"}
    assert result["status"] == "finished"
    assert "shipped" in result["result"].lower()


@pytest.mark.asyncio
async def test_unknown_tool_emits_error_event(tmp_workdir, monkeypatch):
    fake, _ = _mock_send([
        {"tool_calls": [{"name": "nonexistent_tool", "input": {}}]},
        {"text": "done"},
    ])
    import polarity_keystone.harness.harness as harness_mod
    monkeypatch.setattr(harness_mod, "send", fake)

    agent = create_local_agent(LocalAgentOptions(
        model="openai/gpt-4o-mini", api_key="sk-test", working_dir=tmp_workdir,
    ))
    try:
        run = agent.send("call something bogus")
        error_msg = None
        async for msg in run.stream():
            if msg["type"] == "tool_call" and msg["status"] == "error":
                error_msg = msg
        await run.wait()
    finally:
        await agent.close()
    assert error_msg is not None
    assert "unknown tool" in json.dumps(error_msg["result"]).lower()


def test_unprefix_model():
    assert unprefix_model("openai/gpt-4o-mini") == {"provider": "openai", "model": "gpt-4o-mini"}
    assert unprefix_model("anthropic/claude-opus-4-7") == {"provider": "anthropic", "model": "claude-opus-4-7"}
    assert unprefix_model("xai/grok-4") == {"provider": "xai", "model": "grok-4"}
    # No prefix → openai default
    assert unprefix_model("gpt-4o-mini") == {"provider": "openai", "model": "gpt-4o-mini"}


def test_unprefix_model_unknown_raises():
    with pytest.raises(ValueError, match="Unknown provider prefix"):
        unprefix_model("weirdprovider/foo")


def test_is_reasoning_model():
    assert is_reasoning_model("gpt-5.5-2026-04-23") is True
    assert is_reasoning_model("o1-preview") is True
    assert is_reasoning_model("o3") is True
    assert is_reasoning_model("o4-mini") is True
    assert is_reasoning_model("gpt-4o-mini") is False
    assert is_reasoning_model("claude-opus-4-7") is False


@pytest.mark.asyncio
async def test_artifacts_tracked_for_writes(tmp_workdir, monkeypatch):
    fake, _ = _mock_send([
        {"tool_calls": [{"name": "write", "input": {"path": "out.txt", "content": "hello world"}}]},
        {"tool_calls": [{"name": "edit", "input": {"path": "out.txt", "oldString": "world", "newString": "keystone"}}]},
        {"text": "done"},
    ])
    import polarity_keystone.harness.harness as harness_mod
    monkeypatch.setattr(harness_mod, "send", fake)

    agent = create_local_agent(LocalAgentOptions(
        model="openai/gpt-4o-mini", api_key="sk-test", working_dir=tmp_workdir,
    ))
    try:
        run = agent.send("write then edit")
        run_paths_during = []
        async for msg in run.stream():
            if msg["type"] == "task" and msg.get("status") == "artifact":
                run_paths_during.append(msg["text"])
        await run.wait()

        agent_arts = await agent.list_artifacts()
        assert len(agent_arts) == 1
        assert agent_arts[0].path == "out.txt"
        assert agent_arts[0].size_bytes == len("hello keystone")
        bytes_out = await agent.download_artifact("out.txt")
        assert bytes_out == b"hello keystone"

        run_arts = await run.list_artifacts()
        assert len(run_arts) == 1
        assert run_arts[0].path == "out.txt"
        assert run_paths_during == ["out.txt", "out.txt"]
    finally:
        await agent.close()


@pytest.mark.asyncio
async def test_artifacts_unrecorded_on_delete(tmp_workdir, monkeypatch):
    fake, _ = _mock_send([
        {"tool_calls": [{"name": "write", "input": {"path": "tmp.txt", "content": "transient"}}]},
        {"tool_calls": [{"name": "delete", "input": {"path": "tmp.txt"}}]},
        {"text": "deleted"},
    ])
    import polarity_keystone.harness.harness as harness_mod
    monkeypatch.setattr(harness_mod, "send", fake)

    agent = create_local_agent(LocalAgentOptions(
        model="openai/gpt-4o-mini", api_key="sk-test", working_dir=tmp_workdir,
    ))
    try:
        await agent.send("write then delete").wait()
        arts = await agent.list_artifacts()
        assert arts == []
    finally:
        await agent.close()


def test_should_compact_below_threshold():
    decision = should_compact(
        [ProviderMessage(role="user", content="hi")],
        "openai/gpt-4o-mini",
    )
    assert decision.should_compact is False


def test_should_compact_triggers_when_over():
    big = "x" * 500_000  # ~125k tokens at 4 chars/token > 70% of 128k window
    decision = should_compact(
        [
            ProviderMessage(role="system", content="sys"),
            ProviderMessage(role="user", content=big),
            ProviderMessage(role="assistant", content="ok"),
            ProviderMessage(role="user", content="now what"),
        ],
        "openai/gpt-4o-mini",
        CompactionOptions(keep_recent_turns=1),
    )
    assert decision.should_compact is True
    assert decision.used_tokens > 80_000
