"""Unit tests for DatasetService.from_traces()."""

from __future__ import annotations

from tests.conftest import Response


def test_from_traces_creates_dataset_and_adds_records(mock_server, ks):
    """Three traces → three dataset records, filter passes through."""

    pages = [
        {
            "items": [
                {"span_id": "a", "metadata": {"input": "q1", "output": "o1"}},
                {"span_id": "b", "metadata": {"input": "q2", "output": "o2"}},
            ],
            "next_cursor": "c2",
            "count": 2,
        },
        {
            "items": [{"span_id": "c", "metadata": {"input": "q3", "output": "o3"}}],
            "next_cursor": None,
            "count": 1,
        },
    ]
    page_idx = {"i": 0}

    @mock_server.route("GET", "/v1/traces")
    def _traces(req):
        i = page_idx["i"]
        page_idx["i"] += 1
        return Response(body=pages[i])

    @mock_server.route("GET", "/v1/datasets")
    def _list_ds(req):
        return Response(body=[])

    @mock_server.route("POST", "/v1/datasets")
    def _create_ds(req):
        return Response(body={"id": "ds_1", "user_id": "u", "name": "summarize", "version": 0, "created_at": "t"})

    @mock_server.route("POST", "/v1/datasets/ds_1/records")
    def _add(req):
        body = req.json()
        return Response(body={"added": len(body["records"])})

    result = ks.datasets.from_traces(filter={"tool": "summarize"}, name="summarize")

    assert result["dataset_id"] == "ds_1"
    assert result["rows_added"] == 3
    assert result["skipped"]["count"] == 0
    assert len(result["sample_rows"]) == 3
    assert result["sample_rows"][0]["input"] == {"value": "q1"}

    # Filter pass-through: at least one /v1/traces call has tool=summarize.
    traces_queries = [r.query for r in mock_server.captured if r.path == "/v1/traces"]
    assert any("tool=summarize" in q for q in traces_queries)


def test_from_traces_dry_run_returns_rows_without_post(mock_server, ks):
    """dry_run=True returns mapped rows, no dataset POSTs."""

    @mock_server.route("GET", "/v1/traces")
    def _traces(req):
        return Response(body={
            "items": [{"span_id": "a", "metadata": {"input": "q", "output": "o"}}],
            "next_cursor": None,
            "count": 1,
        })

    result = ks.datasets.from_traces(filter={}, name="x", dry_run=True)
    assert result["rows_added"] == 1
    assert result["dataset_id"] == ""
    posts = [r for r in mock_server.captured if r.method == "POST"]
    assert posts == []


def test_from_traces_skips_missing_keys(mock_server, ks):
    """Events without input or output are skipped and counted."""

    @mock_server.route("GET", "/v1/traces")
    def _traces(req):
        return Response(body={
            "items": [
                {"span_id": "a", "metadata": {"input": "q1", "output": "o1"}},
                {"span_id": "b", "metadata": {"input": "q2"}},      # no output
                {"span_id": "c", "metadata": {"output": "o3"}},     # no input
            ],
            "next_cursor": None,
            "count": 3,
        })

    @mock_server.route("GET", "/v1/datasets")
    def _list(req):
        return Response(body=[])

    @mock_server.route("POST", "/v1/datasets")
    def _create(req):
        return Response(body={"id": "ds_2", "user_id": "u", "name": "n", "version": 0, "created_at": "t"})

    @mock_server.route("POST", "/v1/datasets/ds_2/records")
    def _add(req):
        body = req.json()
        return Response(body={"added": len(body["records"])})

    result = ks.datasets.from_traces(filter={}, name="n")
    assert result["rows_added"] == 1
    assert result["skipped"]["count"] == 2
    assert result["skipped"]["reasons"]["missing-expected"] == 1
    assert result["skipped"]["reasons"]["missing-input"] == 1
