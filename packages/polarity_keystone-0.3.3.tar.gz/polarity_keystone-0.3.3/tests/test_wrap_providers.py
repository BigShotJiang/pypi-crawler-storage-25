"""Unit tests for the per-provider wrappers.

We feed fake response objects shaped like Mistral / Google / Claude-Agent
through the patcher and assert ``_build_events`` is called with the right
extracted fields. No actual provider SDK is required.
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest

from polarity_keystone import wrap as _wrap_mod
from polarity_keystone.wrap import (
    _extract_anthropic,
    _extract_claude_agent_messages,
    _extract_google_genai,
    _extract_mistral,
    _extract_openai,
    _is_claude_agent_sdk_module,
    _is_google_genai_client,
    _is_mistral_client,
)


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------


def test_detects_mistral_vs_openai_shape():
    mistral_like = SimpleNamespace(chat=SimpleNamespace(complete=lambda **k: None))
    openai_like = SimpleNamespace(
        chat=SimpleNamespace(completions=SimpleNamespace(create=lambda **k: None))
    )
    assert _is_mistral_client(mistral_like) is True
    assert _is_mistral_client(openai_like) is False


def test_detects_google_genai():
    g = SimpleNamespace(models=SimpleNamespace(generate_content=lambda **k: None))
    assert _is_google_genai_client(g) is True
    assert _is_google_genai_client(object()) is False


def test_detects_claude_agent_sdk_module():
    fake_module = SimpleNamespace(query=lambda **k: None, __name__="claude_agent_sdk")
    assert _is_claude_agent_sdk_module(fake_module) is True
    assert _is_claude_agent_sdk_module(object()) is False


# ---------------------------------------------------------------------------
# Extractors
# ---------------------------------------------------------------------------


def test_extract_mistral_extracts_tool_calls_and_usage():
    response = SimpleNamespace(
        model="mistral-large-latest",
        usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5,
                              prompt_tokens_details=None, completion_tokens_details=None),
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(
                    content="hi there",
                    tool_calls=[
                        SimpleNamespace(
                            id="t1",
                            function=SimpleNamespace(name="run", arguments='{"x":1}'),
                        ),
                    ],
                )
            )
        ],
    )
    info = _extract_mistral(response)
    assert info["provider"] == "mistral"
    assert info["model"] == "mistral-large-latest"
    assert info["input_tokens"] == 10
    assert info["output_tokens"] == 5
    assert info["output_text"] == "hi there"
    assert len(info["tool_calls"]) == 1
    assert info["tool_calls"][0]["name"] == "run"
    assert info["tool_calls"][0]["arguments"] == '{"x":1}'


def test_extract_google_genai_extracts_tool_calls_and_usage():
    response = SimpleNamespace(
        model="gemini-2.5-pro",
        usage_metadata=SimpleNamespace(
            prompt_token_count=100,
            candidates_token_count=50,
            cached_content_token_count=20,
        ),
        function_calls=[
            SimpleNamespace(name="lookup", id="fc1", args={"q": "weather"}),
        ],
        text="the weather is sunny",
        candidates=[],
    )
    info = _extract_google_genai(response)
    assert info["provider"] == "google"
    assert info["model"] == "gemini-2.5-pro"
    assert info["input_tokens"] == 100
    assert info["output_tokens"] == 50
    assert info["cache_tokens"] == 20
    assert info["output_text"] == "the weather is sunny"
    assert len(info["tool_calls"]) == 1
    assert info["tool_calls"][0]["name"] == "lookup"
    assert '"q":' in info["tool_calls"][0]["arguments"].replace(" ", "")


def test_extract_google_genai_walks_candidates_when_top_level_missing():
    """Older Google GenAI SDKs don't expose .function_calls directly — the
    extractor must walk candidates → content → parts as fallback."""
    response = SimpleNamespace(
        model="gemini-1.5-pro",
        usage_metadata=SimpleNamespace(
            prompt_token_count=10, candidates_token_count=3, cached_content_token_count=0
        ),
        function_calls=None,
        text=None,
        candidates=[
            SimpleNamespace(
                content=SimpleNamespace(
                    parts=[
                        SimpleNamespace(text="hi", function_call=None),
                        SimpleNamespace(
                            text=None,
                            function_call=SimpleNamespace(name="legacy_tool", args={"a": 1}),
                        ),
                    ]
                )
            )
        ],
    )
    info = _extract_google_genai(response)
    assert info["output_text"] == "hi"
    assert info["tool_calls"][0]["name"] == "legacy_tool"


def test_extract_claude_agent_messages_aggregates_tool_uses_and_usage():
    msg1 = SimpleNamespace(
        model="claude-sonnet-4-6",
        content=[
            SimpleNamespace(type="text", text="thinking..."),
            SimpleNamespace(type="tool_use", name="bash", id="tu1", input={"cmd": "ls"}),
        ],
        usage=SimpleNamespace(input_tokens=200, output_tokens=10),
    )
    msg2 = SimpleNamespace(
        model="claude-sonnet-4-6",
        content=[
            SimpleNamespace(type="text", text="done"),
        ],
        usage=SimpleNamespace(input_tokens=200, output_tokens=25),
    )
    info = _extract_claude_agent_messages([msg1, msg2])
    assert info["model"] == "claude-sonnet-4-6"
    assert info["input_tokens"] == 200
    assert info["output_tokens"] == 25
    assert "thinking" in info["output_text"]
    assert info["tool_calls"][0]["name"] == "bash"


# ---------------------------------------------------------------------------
# Patch — assert _post_trace_fire_and_forget is invoked with built events.
# ---------------------------------------------------------------------------


class _StubHTTP:
    def __init__(self):
        self.posted = []

    def post(self, path, body):
        self.posted.append((path, body))
        return {}


def test_patch_mistral_invokes_trace_post_with_extracted_fields():
    http = _StubHTTP()
    response = SimpleNamespace(
        model="mistral-large-latest",
        usage=SimpleNamespace(prompt_tokens=4, completion_tokens=2,
                              prompt_tokens_details=None, completion_tokens_details=None),
        choices=[SimpleNamespace(message=SimpleNamespace(content="ok", tool_calls=None))],
    )

    client = SimpleNamespace(chat=SimpleNamespace(complete=lambda **kwargs: response))
    _wrap_mod._patch_mistral(client, http, "sb-test")

    # Replace the fire-and-forget posting helper with a synchronous variant
    # so the assertion is deterministic.
    with patch("polarity_keystone.wrap._post_trace_fire_and_forget") as fake_post:
        client.chat.complete(messages=[{"role": "user", "content": "hi"}])
        assert fake_post.called
        _http_arg, sb_arg, events = fake_post.call_args.args
        assert sb_arg == "sb-test"
        assert events[0]["event_type"] == "llm_call"
        assert events[0]["cost"]["model"] == "mistral-large-latest"
        assert events[0]["metadata"]["gen_ai.system"] == "mistral"


def test_patch_google_genai_invokes_trace_post_with_extracted_fields():
    http = _StubHTTP()
    response = SimpleNamespace(
        model="gemini-2.5-pro",
        usage_metadata=SimpleNamespace(
            prompt_token_count=8, candidates_token_count=4, cached_content_token_count=0
        ),
        function_calls=[],
        text="hi",
        candidates=[],
    )
    client = SimpleNamespace(models=SimpleNamespace(generate_content=lambda **kwargs: response))
    _wrap_mod._patch_google_genai(client, http, "sb-google")

    with patch("polarity_keystone.wrap._post_trace_fire_and_forget") as fake_post:
        client.models.generate_content(model="gemini-2.5-pro", contents="hello")
        assert fake_post.called
        _http_arg, sb_arg, events = fake_post.call_args.args
        assert sb_arg == "sb-google"
        assert events[0]["metadata"]["gen_ai.system"] == "google"
        assert events[0]["cost"]["input_tokens"] == 8


def test_named_aliases_exist():
    """Ensure ``wrap_*`` aliases match the Braintrust naming convention."""
    from polarity_keystone import (
        wrap_anthropic, wrap_openai, wrap_mistral,
        wrap_google_genai, wrap_claude_agent_sdk,
    )
    assert callable(wrap_anthropic)
    assert callable(wrap_openai)
    assert callable(wrap_mistral)
    assert callable(wrap_google_genai)
    assert callable(wrap_claude_agent_sdk)


# Smoke: existing extractors still work — no regressions.

def test_existing_anthropic_openai_extractors_still_work():
    a = SimpleNamespace(
        model="claude-sonnet-4-6",
        usage=SimpleNamespace(input_tokens=10, output_tokens=5),
        content=[SimpleNamespace(type="text", text="hi")],
    )
    info = _extract_anthropic(a)
    assert info["provider"] == "anthropic"
    assert info["output_text"] == "hi"

    o = SimpleNamespace(
        model="gpt-4o",
        usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5,
                              prompt_tokens_details=None, completion_tokens_details=None),
        choices=[SimpleNamespace(message=SimpleNamespace(content="yo", tool_calls=None))],
    )
    info = _extract_openai(o)
    assert info["provider"] == "openai"
    assert info["output_text"] == "yo"
