"""Drive the sample_eval suite via pytester to verify the plugin contract."""

from __future__ import annotations


pytest_plugins = ["pytester"]


def test_min_violation_fails_test(pytester):
    pytester.makepyfile(test_x="""
        from polarity_keystone.scorers import ExactMatch

        def test_pass(keystone_score):
            keystone_score(ExactMatch(expected="hi"), input="x", output="hi")

        def test_fail(keystone_score):
            keystone_score(ExactMatch(expected="match"), input="x", output="nope", min=0.5)
    """)
    res = pytester.runpytest("-v", "--keystone-no-flush")
    res.assert_outcomes(passed=1, failed=1)


def test_no_min_does_not_fail(pytester):
    pytester.makepyfile(test_x="""
        from polarity_keystone.scorers import ExactMatch

        def test_low_score_no_min(keystone_score):
            # Score is 0.0 but min not set, so test passes.
            keystone_score(ExactMatch(expected="match"), input="x", output="nope")
    """)
    res = pytester.runpytest("-v", "--keystone-no-flush")
    res.assert_outcomes(passed=1)


def test_session_prints_local_summary_without_api_key(pytester, monkeypatch):
    """Without KEYSTONE_API_KEY, plugin prints a per-module summary and skips POST."""
    monkeypatch.delenv("KEYSTONE_API_KEY", raising=False)
    pytester.makepyfile(test_a="""
        from polarity_keystone.scorers import ExactMatch
        def test_one(keystone_score):
            keystone_score(ExactMatch(expected="hi"), input="x", output="hi")
        def test_two(keystone_score):
            keystone_score(ExactMatch(expected="hi"), input="x", output="hi")
    """)
    res = pytester.runpytest("-v")
    res.assert_outcomes(passed=2)
    # Plugin emits a `keystone:` summary line per module on session end.
    res.stdout.fnmatch_lines(["*keystone:*test_a*scored rows*"])
