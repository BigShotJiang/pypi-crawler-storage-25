"""Unit tests for the ``Eval()`` ergonomic primitive."""

from __future__ import annotations

import asyncio

import pytest

from polarity_keystone import (
    Contains,
    Eval,
    EvalResult,
    ExactMatch,
    Levenshtein,
    Scorer,
)


def test_eval_basic_runs_each_row_and_aggregates():
    rows = [
        {"input": "2+2?", "expected": "4"},
        {"input": "3+3?", "expected": "6"},
        {"input": "5+5?", "expected": "10"},
    ]

    answers = {"2+2?": "4", "3+3?": "6", "5+5?": "10"}
    result = Eval(
        "math",
        data=rows,
        task=lambda x: answers[x],
        scores=[ExactMatch()],
    )

    assert isinstance(result, EvalResult)
    assert result.name == "math"
    assert len(result.rows) == 3
    for row in result.rows:
        assert row["scores"]["exact_match"] == 1.0

    summary = result.summary["exact_match"]
    assert summary["mean"] == 1.0
    assert summary["p50"] == 1.0
    assert summary["p95"] == 1.0
    assert summary["count"] == 3.0


def test_eval_partial_failure_preserved_per_row():
    rows = [
        {"input": "ok", "expected": "yes"},
        {"input": "bad", "expected": "yes"},
    ]

    def task(x):
        if x == "bad":
            raise RuntimeError("boom")
        return "yes"

    result = Eval("err", data=rows, task=task, scores=[ExactMatch()])

    assert "error" not in result.rows[0] or result.rows[0]["error"] is None
    assert "RuntimeError" in result.rows[1]["error"]
    # Successful row still scored.
    assert result.rows[0]["scores"]["exact_match"] == 1.0
    # Failed row has no scores (output never set).
    assert result.rows[1]["scores"] == {}


def test_eval_async_task():
    async def task(x):
        await asyncio.sleep(0)
        return x.upper()

    result = Eval(
        "async",
        data=[{"input": "abc", "expected": "ABC"}],
        task=task,
        scores=[ExactMatch()],
        # Force serial execution — running asyncio.run() per row in parallel
        # threads is supported but we want a deterministic single-row test.
        max_concurrency=1,
    )
    assert result.rows[0]["output"] == "ABC"
    assert result.rows[0]["scores"]["exact_match"] == 1.0


def test_eval_summary_percentiles_with_mixed_scores():
    """Ten rows, half passing, half failing. Mean=0.5, p50=0.5, p95=1.0."""
    rows = [{"input": str(i), "expected": "1" if i % 2 == 0 else "9"} for i in range(10)]
    result = Eval(
        "halves",
        data=rows,
        task=lambda x: "1",  # only even-indexed rows match.
        scores=[ExactMatch()],
        max_concurrency=1,
    )

    summary = result.summary["exact_match"]
    assert summary["count"] == 10.0
    assert summary["mean"] == 0.5
    # Sorted scores: [0,0,0,0,0,1,1,1,1,1] → p50 = 0.5 (linear interp).
    assert summary["p50"] == 0.5
    # p95 = 9.5 → 0*0.5 + 1*0.5 ... but rank=9*0.95=8.55 → values[8]=1, values[9]=1 → 1.0.
    assert summary["p95"] == 1.0


def test_eval_with_contains_scorer():
    result = Eval(
        "contains",
        data=[
            {"input": "hello", "expected": None},
            {"input": "world", "expected": None},
        ],
        task=lambda x: f"the word is {x}",
        scores=[Contains("the")],
        max_concurrency=1,
    )
    for row in result.rows:
        assert row["scores"]["contains"] == 1.0


def test_eval_no_keystone_api_key_no_experiment_id(monkeypatch):
    monkeypatch.delenv("KEYSTONE_API_KEY", raising=False)
    result = Eval(
        "no-key",
        data=[{"input": "x", "expected": "x"}],
        task=lambda x: x,
        scores=[ExactMatch()],
    )
    assert result.experiment_id is None


def test_eval_with_custom_scorer():
    @Scorer
    def length_match(scenario):
        # Output must equal expected length-wise.
        actual = scenario.agent_output
        expected = scenario.parameters.get("expected", "")
        return 1.0 if len(actual) == len(expected) else 0.0

    result = Eval(
        "custom",
        data=[
            {"input": "abc", "expected": "xyz"},
            {"input": "ab", "expected": "xyzz"},
        ],
        task=lambda x: x,
        scores=[length_match],
        max_concurrency=1,
    )
    assert result.rows[0]["scores"]["length_match"] == 1.0
    assert result.rows[1]["scores"]["length_match"] == 0.0
    assert result.summary["length_match"]["mean"] == 0.5


def test_eval_concurrency_runs_all_rows():
    """Sanity: with concurrency >1, all rows still execute exactly once."""
    counter = {"calls": 0}
    lock = __import__("threading").Lock()

    def task(x):
        with lock:
            counter["calls"] += 1
        return str(x)

    rows = [{"input": i, "expected": str(i)} for i in range(20)]
    result = Eval("conc", data=rows, task=task, scores=[ExactMatch()], max_concurrency=8)
    assert counter["calls"] == 20
    assert all(r["scores"]["exact_match"] == 1.0 for r in result.rows)
