"""Braintrust-parity ``Eval()`` ergonomic primitive.

Mirrors Braintrust's headline ``Eval(name, {data, task, scores})`` API. Thin
orchestrator over the existing experiment + scorer infrastructure: each row's
``task`` callable runs (in parallel by default), each scorer evaluates the
output, and aggregate stats (mean, p50, p95, count) are computed per scorer.

If ``KEYSTONE_API_KEY`` is set, an experiment row is also created on the
server so results land in the dashboard. Otherwise this runs purely locally
and still returns an :class:`EvalResult`.

Example::

    from polarity_keystone import Eval, ExactMatch

    result = Eval(
        "my-agent-eval",
        data=[
            {"input": "what is 2+2?", "expected": "4"},
            {"input": "capital of france?", "expected": "Paris"},
        ],
        task=lambda input: my_agent(input),
        scores=[ExactMatch()],
    )

    print(result.summary)         # {'exact_match': {'mean': ..., ...}}
    for row in result.rows:
        print(row['scores'])      # {'exact_match': 1.0}
"""

from __future__ import annotations

import asyncio
import inspect
import os
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Union

from .scorers.base import BaseScorer
from .tracing import _TracedContextManager


# ---------------------------------------------------------------------------
# Result shapes
# ---------------------------------------------------------------------------


@dataclass
class EvalRow:
    """Per-row result. Stored as a dict on :class:`EvalResult`; this dataclass
    is only used internally to aid readability."""

    input: Any
    expected: Any
    output: Any
    scores: Dict[str, float] = field(default_factory=dict)
    duration_ms: int = 0
    error: Optional[str] = None


@dataclass
class EvalSummary:
    mean: float
    p50: float
    p95: float
    count: int

    def to_dict(self) -> Dict[str, float]:
        return {"mean": self.mean, "p50": self.p50, "p95": self.p95, "count": float(self.count)}


@dataclass
class EvalResult:
    """Result returned from :func:`Eval`."""

    name: str
    rows: List[Dict[str, Any]] = field(default_factory=list)
    summary: Dict[str, Dict[str, float]] = field(default_factory=dict)
    experiment_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Aggregate helpers
# ---------------------------------------------------------------------------


def _percentile(sorted_values: List[float], pct: float) -> float:
    """Linear-interpolated percentile. ``pct`` in [0, 1]."""
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    rank = pct * (len(sorted_values) - 1)
    lo = int(rank)
    hi = min(lo + 1, len(sorted_values) - 1)
    frac = rank - lo
    return float(sorted_values[lo]) * (1 - frac) + float(sorted_values[hi]) * frac


def _aggregate(values: List[float]) -> Dict[str, float]:
    """Compute mean/p50/p95/count for a list of scorer values."""
    if not values:
        return {"mean": 0.0, "p50": 0.0, "p95": 0.0, "count": 0.0}
    sorted_vals = sorted(values)
    return {
        "mean": float(statistics.fmean(sorted_vals)),
        "p50": _percentile(sorted_vals, 0.5),
        "p95": _percentile(sorted_vals, 0.95),
        "count": float(len(sorted_vals)),
    }


# ---------------------------------------------------------------------------
# Task invocation
# ---------------------------------------------------------------------------


def _run_task(task: Callable[..., Any], input_value: Any) -> Any:
    """Run ``task(input)`` regardless of whether it's sync or async.

    Async tasks are scheduled on the event loop; this helper blocks until
    completion. Mirrors Braintrust's behavior: async tasks are first-class
    but the public surface is sync from the caller's perspective.
    """
    if inspect.iscoroutinefunction(task):
        return asyncio.run(task(input_value))  # type: ignore[arg-type]
    out = task(input_value)
    if inspect.iscoroutine(out):
        return asyncio.run(out)
    return out


# ---------------------------------------------------------------------------
# Scorer adaptation
# ---------------------------------------------------------------------------


def _make_scenario(input_value: Any, output: Any, expected: Any) -> Any:
    """Build a minimal scenario-shaped object compatible with built-in scorers.

    Built-in :class:`BaseScorer` subclasses read ``scenario.agent_output`` and
    ``scenario.parameters``. We expose ``input`` and ``expected`` under
    ``parameters`` so scorers configured with ``expected_key="expected"`` work
    without modification.
    """
    return SimpleNamespace(
        agent_output=str(output) if output is not None else "",
        parameters={"input": input_value, "expected": expected},
        # Surface raw values so callers can build custom scorers that read them
        # directly rather than going through `parameters`.
        input=input_value,
        expected=expected,
        output=output,
    )


def _score_one(scorer: BaseScorer, scenario: Any, expected: Any) -> Optional[float]:
    """Run a single scorer against the synthetic scenario.

    If the scorer has no explicit ``expected``/``expected_key`` configured,
    we briefly poke ``expected`` into a known attribute so common scorers
    like :class:`ExactMatch` succeed on the row's ``expected`` field. We
    restore the original after — never mutate the caller's scorer object
    permanently.
    """
    # Direct expected propagation — only if the scorer accepts it and
    # didn't explicitly configure one.
    saved: Dict[str, Any] = {}
    if expected is not None and hasattr(scorer, "expected") and getattr(scorer, "expected", None) is None:
        if not getattr(scorer, "expected_key", None):
            saved["expected"] = scorer.expected
            scorer.expected = expected  # type: ignore[attr-defined]
    try:
        result = scorer.score_result(scenario)
    finally:
        for k, v in saved.items():
            setattr(scorer, k, v)
    if result is None:
        return None
    return float(result.score)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


DataSource = Union[Sequence[Dict[str, Any]], Iterable[Dict[str, Any]]]


def Eval(
    name: str,
    *,
    data: DataSource,
    task: Callable[..., Any],
    scores: Optional[Sequence[BaseScorer]] = None,
    max_concurrency: int = 4,
    keystone: Any = None,
) -> EvalResult:
    """Run an evaluation: invoke ``task`` per row, score, aggregate.

    Args:
        name: Eval name (used for the optional Keystone experiment row).
        data: List of dicts containing ``input`` and (optionally) ``expected``.
        task: Callable that takes ``input`` and returns ``output``. Async OK.
        scores: List of scorer objects (built-in or custom).
        max_concurrency: Parallel row workers. Default 4.
        keystone: Optional :class:`Keystone` client. If set (or
            ``KEYSTONE_API_KEY`` is present) results post to the dashboard.

    Returns:
        :class:`EvalResult` with ``rows``, ``summary``, ``experiment_id``.
    """
    rows = list(data)
    scorers: List[BaseScorer] = list(scores or [])

    # Per-row execution — wrapped in a traced span so individual task runs
    # show up in the trace UI, mirroring Braintrust's dashboard behavior.
    def execute_row(row: Dict[str, Any]) -> Dict[str, Any]:
        input_value = row.get("input")
        expected = row.get("expected")

        out_row: Dict[str, Any] = {
            "input": input_value,
            "expected": expected,
            "output": None,
            "scores": {},
            "duration_ms": 0,
        }

        start = time.monotonic()
        with _TracedContextManager(f"eval:{name}") as span:
            try:
                output = _run_task(task, input_value)
                out_row["output"] = output
                span.set_output(output)
            except Exception as exc:  # noqa: BLE001
                out_row["error"] = f"{type(exc).__name__}: {exc}"
                output = None

        out_row["duration_ms"] = int((time.monotonic() - start) * 1000)

        if output is not None:
            scenario = _make_scenario(input_value, output, expected)
            for scorer in scorers:
                try:
                    val = _score_one(scorer, scenario, expected)
                    if val is not None:
                        out_row["scores"][scorer.name] = val
                except Exception as exc:  # noqa: BLE001
                    out_row["scores"][scorer.name] = 0.0
                    # Surface scorer errors but never crash the eval.
                    err_msg = f"scorer {scorer.name}: {type(exc).__name__}: {exc}"
                    out_row.setdefault("scorer_errors", []).append(err_msg)
        return out_row

    # Run rows in parallel — default of 4 mirrors Braintrust's `maxConcurrency`.
    out_rows: List[Dict[str, Any]] = [None] * len(rows)  # type: ignore[list-item]
    if max_concurrency <= 1 or len(rows) <= 1:
        for i, row in enumerate(rows):
            out_rows[i] = execute_row(row)
    else:
        with ThreadPoolExecutor(max_workers=max_concurrency) as pool:
            future_to_idx = {pool.submit(execute_row, row): i for i, row in enumerate(rows)}
            for fut in as_completed(future_to_idx):
                idx = future_to_idx[fut]
                out_rows[idx] = fut.result()

    # Aggregate per scorer.
    summary: Dict[str, Dict[str, float]] = {}
    if scorers:
        for scorer in scorers:
            values = [
                row["scores"][scorer.name]
                for row in out_rows
                if row and scorer.name in row.get("scores", {})
            ]
            summary[scorer.name] = _aggregate(values)

    # Optional dashboard write — only when we have an API key. We post the
    # eval as a lightweight trace event to /v1/traces so the rows appear in
    # the dashboard's trace explorer. Doing this via the existing
    # /v1/experiments path requires a server-side spec, which is heavier
    # than what an `Eval()` call should imply.
    experiment_id: Optional[str] = None
    from ._compat import get_env
    api_key = (
        (getattr(getattr(keystone, "_http", None), "api_key", "") if keystone else "")
        or get_env("POLARITY_API_KEY", "KEYSTONE_API_KEY")
    )
    if api_key:
        try:
            experiment_id = _post_eval_to_dashboard(name, out_rows, summary, keystone)
        except Exception:
            # Dashboard reporting is fire-and-forget — never block the local eval.
            pass

    return EvalResult(name=name, rows=out_rows, summary=summary, experiment_id=experiment_id)


def _post_eval_to_dashboard(
    name: str,
    rows: List[Dict[str, Any]],
    summary: Dict[str, Dict[str, float]],
    keystone: Any,
) -> Optional[str]:
    """Post the eval as a single trace event so the dashboard shows it.

    Uses the existing ``/v1/traces`` endpoint (agent mode) to keep payload
    handling identical to wrapped LLM calls. Returns the trace's span_id as
    the surrogate ``experiment_id`` so callers can dedupe runs.
    """
    from .client import Keystone
    from datetime import datetime, timezone
    import uuid as _uuid

    ks = keystone or Keystone()
    span_id = f"span_eval_{_uuid.uuid4().hex[:12]}"
    event = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "event_type": "eval",
        "tool": f"Eval:{name}",
        "phase": "complete",
        "span_id": span_id,
        "status": "ok",
        "duration_ms": sum(r.get("duration_ms", 0) for r in rows),
        "metadata": {
            "eval.name": name,
            "eval.rows": len(rows),
            "eval.summary": summary,
        },
    }
    try:
        ks._http.post("/v1/traces", {"events": [event]})
    except Exception:
        return None
    return span_id
