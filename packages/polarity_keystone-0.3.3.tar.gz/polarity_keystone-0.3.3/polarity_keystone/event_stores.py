"""Run/event store interfaces + in-memory implementations, mirroring
@cursor/sdk's pluggable persistence surface. Keystone has its own
Supabase-backed storage server-side; these are here for SDK consumers
writing a local harness who want to checkpoint, resume, or fan out
run events using the same interfaces Cursor exposes.
"""
from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import (
    Any,
    AsyncIterator,
    Callable,
    Dict,
    List,
    Literal,
    Optional,
    Set,
)

from .local_run_stream import LocalRunStreamEvent


# ─── Stored shapes ───────────────────────────────────────────────────

@dataclass
class AgentCheckpoint:
    agent_id: str
    cursor: str  # opaque resume token
    updated_at: str  # ISO-8601
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class StoredRun:
    run_id: str
    agent_id: str
    status: Literal["running", "completed", "errored", "cancelled"]
    started_at: str
    ended_at: Optional[str] = None
    exit_reason: Optional[str] = None
    error: Optional[Dict[str, Any]] = None


# ─── Abstract stores ─────────────────────────────────────────────────

class AgentCheckpointStore(ABC):
    @abstractmethod
    async def get(self, agent_id: str) -> Optional[AgentCheckpoint]: ...
    @abstractmethod
    async def set(self, checkpoint: AgentCheckpoint) -> None: ...
    @abstractmethod
    async def delete(self, agent_id: str) -> None: ...


class AgentRunStore(ABC):
    @abstractmethod
    async def create(self, run: StoredRun) -> None: ...
    @abstractmethod
    async def update(self, run_id: str, patch: Dict[str, Any]) -> None: ...
    @abstractmethod
    async def get(self, run_id: str) -> Optional[StoredRun]: ...
    @abstractmethod
    async def list(self, agent_id: str, limit: Optional[int] = None) -> List[StoredRun]: ...


class RunEventStore(ABC):
    @abstractmethod
    async def append(self, run_id: str, event: LocalRunStreamEvent) -> None: ...
    @abstractmethod
    async def read(
        self, run_id: str, from_index: int = 0, limit: Optional[int] = None
    ) -> List[LocalRunStreamEvent]: ...


class RunEventNotifier(ABC):
    @abstractmethod
    def emit(self, run_id: str, event: LocalRunStreamEvent) -> None: ...
    @abstractmethod
    def subscribe(self, run_id: str, listener: Callable[[LocalRunStreamEvent], None]) -> Callable[[], None]: ...


class WatchableRunEventStore(RunEventStore):
    @abstractmethod
    def watch(self, run_id: str, listener: Callable[[LocalRunStreamEvent], None]) -> Callable[[], None]: ...


class RunEventStreamStore(WatchableRunEventStore):
    @abstractmethod
    async def stream(
        self,
        run_id: str,
        from_index: int = 0,
        include_historical: bool = True,
    ) -> AsyncIterator[LocalRunStreamEvent]: ...


# ─── In-memory implementations ───────────────────────────────────────

class InMemoryAgentCheckpointStore(AgentCheckpointStore):
    def __init__(self) -> None:
        self._by_agent: Dict[str, AgentCheckpoint] = {}

    async def get(self, agent_id: str) -> Optional[AgentCheckpoint]:
        return self._by_agent.get(agent_id)

    async def set(self, checkpoint: AgentCheckpoint) -> None:
        self._by_agent[checkpoint.agent_id] = checkpoint

    async def delete(self, agent_id: str) -> None:
        self._by_agent.pop(agent_id, None)


class InMemoryAgentRunStore(AgentRunStore):
    def __init__(self) -> None:
        self._by_run: Dict[str, StoredRun] = {}

    async def create(self, run: StoredRun) -> None:
        self._by_run[run.run_id] = run

    async def update(self, run_id: str, patch: Dict[str, Any]) -> None:
        existing = self._by_run.get(run_id)
        if existing is None:
            return
        for k, v in patch.items():
            if hasattr(existing, k):
                setattr(existing, k, v)

    async def get(self, run_id: str) -> Optional[StoredRun]:
        return self._by_run.get(run_id)

    async def list(self, agent_id: str, limit: Optional[int] = None) -> List[StoredRun]:
        rows = [r for r in self._by_run.values() if r.agent_id == agent_id]
        rows.sort(key=lambda r: r.started_at, reverse=True)
        return rows[:limit] if limit else rows


class InMemoryRunEventNotifier(RunEventNotifier):
    def __init__(self) -> None:
        self._listeners: Dict[str, Set[Callable[[LocalRunStreamEvent], None]]] = {}

    def emit(self, run_id: str, event: LocalRunStreamEvent) -> None:
        for fn in list(self._listeners.get(run_id, set())):
            fn(event)

    def subscribe(self, run_id: str, listener: Callable[[LocalRunStreamEvent], None]) -> Callable[[], None]:
        self._listeners.setdefault(run_id, set()).add(listener)
        return lambda: self._listeners.get(run_id, set()).discard(listener)


class InMemoryRunEventStore(RunEventStreamStore):
    def __init__(self) -> None:
        self._by_run: Dict[str, List[LocalRunStreamEvent]] = {}
        self._watchers: Dict[str, Set[Callable[[LocalRunStreamEvent], None]]] = {}

    async def append(self, run_id: str, event: LocalRunStreamEvent) -> None:
        self._by_run.setdefault(run_id, []).append(event)
        for fn in list(self._watchers.get(run_id, set())):
            fn(event)

    async def read(
        self, run_id: str, from_index: int = 0, limit: Optional[int] = None
    ) -> List[LocalRunStreamEvent]:
        all_events = self._by_run.get(run_id, [])
        sliced = all_events[from_index:]
        return sliced[:limit] if limit else sliced

    def watch(
        self, run_id: str, listener: Callable[[LocalRunStreamEvent], None]
    ) -> Callable[[], None]:
        self._watchers.setdefault(run_id, set()).add(listener)
        return lambda: self._watchers.get(run_id, set()).discard(listener)

    async def stream(
        self,
        run_id: str,
        from_index: int = 0,
        include_historical: bool = True,
    ) -> AsyncIterator[LocalRunStreamEvent]:
        if include_historical:
            for ev in await self.read(run_id, from_index=from_index):
                yield ev

        queue: asyncio.Queue[LocalRunStreamEvent] = asyncio.Queue()
        loop = asyncio.get_event_loop()

        def listener(e: LocalRunStreamEvent) -> None:
            loop.call_soon_threadsafe(queue.put_nowait, e)

        unsub = self.watch(run_id, listener)
        try:
            while True:
                event = await queue.get()
                yield event
                if event.type == "done":
                    return
        finally:
            unsub()


@dataclass
class MessageBookkeeping:
    """Combined log of SDKMessages + their corresponding stream events.
    Useful for reconstruction or replaying a run from disk."""
    messages: List[Dict[str, Any]] = field(default_factory=list)
    events: List[LocalRunStreamEvent] = field(default_factory=list)


__all__ = [
    "AgentCheckpoint",
    "StoredRun",
    "AgentCheckpointStore",
    "AgentRunStore",
    "RunEventStore",
    "RunEventNotifier",
    "WatchableRunEventStore",
    "RunEventStreamStore",
    "InMemoryAgentCheckpointStore",
    "InMemoryAgentRunStore",
    "InMemoryRunEventNotifier",
    "InMemoryRunEventStore",
    "MessageBookkeeping",
]
