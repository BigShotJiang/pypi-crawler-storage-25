"""LLM client wrapping for automatic tool-call tracing.

Monkey-patches Anthropic and OpenAI client methods so that every LLM call
automatically reports trace events to Keystone.  Zero external dependencies
-- uses only :mod:`urllib`, :mod:`json`, :mod:`time`, and :mod:`threading`
from the standard library.

Usage::

    from polarity_keystone import Keystone
    from anthropic import Anthropic

    ks = Keystone(api_key="ks_live_...")
    anthropic = ks.wrap(Anthropic(), sandbox_id="sb-xxx")
    # Every anthropic.messages.create() now auto-reports to Keystone.
"""

from __future__ import annotations

import asyncio
import copy
import json
import time
import threading
import urllib.error
import urllib.request
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from ._http import HTTPClient

if TYPE_CHECKING:
    pass


# ---------------------------------------------------------------------------
# Fire-and-forget trace reporting
# ---------------------------------------------------------------------------

def _post_trace_fire_and_forget(http: "HTTPClient", sandbox_id: str, events: list) -> None:
    """Send trace events synchronously. Failures are logged but never break the caller.

    When ``sandbox_id`` is empty, posts to ``/v1/traces`` (agent mode — server
    scopes the rows to the caller's API key). Otherwise posts to
    ``/v1/sandboxes/:id/trace`` (sandbox mode — rows nest under the run).
    """
    try:
        path = f"/v1/sandboxes/{sandbox_id}/trace" if sandbox_id else "/v1/traces"
        http.post(path, {"events": events})
    except Exception as e:
        import sys
        print(f"[polarity-sdk] trace post failed: {e}", file=sys.stderr)


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Response extraction helpers
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Model pricing (USD per 1M tokens) — covers all upstream + alias names
# ---------------------------------------------------------------------------

_MODEL_PRICING: dict = {
    # ══════════════════════════════════════════════════════════════════
    # Anthropic — https://anthropic.com/pricing
    # ══════════════════════════════════════════════════════════════════
    "claude-opus-4-6":              {"input": 15.00, "output": 75.00},
    "claude-opus-4-5":              {"input": 15.00, "output": 75.00},
    "claude-opus-4-20250514":       {"input": 15.00, "output": 75.00},
    "claude-sonnet-4-6":            {"input": 3.00,  "output": 15.00},
    "claude-sonnet-4-5-20250514":   {"input": 3.00,  "output": 15.00},
    "claude-sonnet-4-5-20250929":   {"input": 3.00,  "output": 15.00},
    "claude-sonnet-4-20250514":     {"input": 3.00,  "output": 15.00},
    "claude-haiku-4-5-20251001":    {"input": 1.00,  "output": 5.00},
    "claude-3-5-sonnet-20241022":   {"input": 3.00,  "output": 15.00},
    "claude-3-5-sonnet-20240620":   {"input": 3.00,  "output": 15.00},
    "claude-3-5-haiku-20241022":    {"input": 0.80,  "output": 4.00},
    "claude-3-opus-20240229":       {"input": 15.00, "output": 75.00},
    "claude-3-sonnet-20240229":     {"input": 3.00,  "output": 15.00},
    "claude-3-haiku-20240307":      {"input": 0.25,  "output": 1.25},

    # ══════════════════════════════════════════════════════════════════
    # OpenAI — https://openai.com/pricing
    # ══════════════════════════════════════════════════════════════════
    "gpt-5.3-codex":                {"input": 1.75,  "output": 14.00},
    "gpt-4.1":                      {"input": 2.00,  "output": 8.00},
    "gpt-4.1-mini":                 {"input": 0.40,  "output": 1.60},
    "gpt-4.1-nano":                 {"input": 0.10,  "output": 0.40},
    "gpt-4o":                       {"input": 2.50,  "output": 10.00},
    "gpt-4o-2024-11-20":            {"input": 2.50,  "output": 10.00},
    "gpt-4o-2024-08-06":            {"input": 2.50,  "output": 10.00},
    "gpt-4o-mini":                  {"input": 0.15,  "output": 0.60},
    "gpt-4o-mini-2024-07-18":       {"input": 0.15,  "output": 0.60},
    "gpt-4-turbo":                  {"input": 10.00, "output": 30.00},
    "gpt-4-turbo-2024-04-09":       {"input": 10.00, "output": 30.00},
    "gpt-4":                        {"input": 30.00, "output": 60.00},
    "gpt-3.5-turbo":                {"input": 0.50,  "output": 1.50},
    "o1":                           {"input": 15.00, "output": 60.00},
    "o1-2024-12-17":                {"input": 15.00, "output": 60.00},
    "o1-mini":                      {"input": 3.00,  "output": 12.00},
    "o1-mini-2024-09-12":           {"input": 3.00,  "output": 12.00},
    "o3":                           {"input": 10.00, "output": 40.00},
    "o3-mini":                      {"input": 1.10,  "output": 4.40},
    "o3-mini-2025-01-31":           {"input": 1.10,  "output": 4.40},
    "o4-mini":                      {"input": 1.10,  "output": 4.40},

    # ══════════════════════════════════════════════════════════════════
    # Google Gemini — https://ai.google.dev/pricing
    # ══════════════════════════════════════════════════════════════════
    "gemini-3.1-pro-preview":       {"input": 2.00,  "output": 12.00},
    "gemini-3-flash-preview":       {"input": 0.50,  "output": 3.00},
    "gemini-2.5-pro":               {"input": 1.25,  "output": 10.00},
    "gemini-2.5-flash":             {"input": 0.15,  "output": 0.60},
    "gemini-2.0-flash":             {"input": 0.10,  "output": 0.40},
    "gemini-1.5-pro":               {"input": 1.25,  "output": 5.00},
    "gemini-1.5-flash":             {"input": 0.075, "output": 0.30},

    # ══════════════════════════════════════════════════════════════════
    # Meta Llama (via API providers)
    # ══════════════════════════════════════════════════════════════════
    "meta-llama/llama-4-maverick":  {"input": 0.20,  "output": 0.85},
    "meta-llama/llama-4-scout":     {"input": 0.15,  "output": 0.55},
    "meta-llama/llama-3.3-70b":     {"input": 0.40,  "output": 0.40},
    "meta-llama/llama-3.1-405b":    {"input": 2.00,  "output": 2.00},
    "meta-llama/llama-3.1-70b":     {"input": 0.40,  "output": 0.40},
    "meta-llama/llama-3.1-8b":      {"input": 0.05,  "output": 0.08},

    # ══════════════════════════════════════════════════════════════════
    # Mistral — https://mistral.ai/pricing
    # ══════════════════════════════════════════════════════════════════
    "mistral-large-latest":         {"input": 2.00,  "output": 6.00},
    "mistral-medium-latest":        {"input": 2.75,  "output": 8.10},
    "mistral-small-latest":         {"input": 0.20,  "output": 0.60},
    "codestral-latest":             {"input": 0.30,  "output": 0.90},
    "pixtral-large-latest":         {"input": 2.00,  "output": 6.00},

    # ══════════════════════════════════════════════════════════════════
    # DeepSeek — https://platform.deepseek.com/api-docs/pricing
    # ══════════════════════════════════════════════════════════════════
    "deepseek-chat":                {"input": 0.27,  "output": 1.10},
    "deepseek-reasoner":            {"input": 0.55,  "output": 2.19},
    "deepseek/deepseek-chat-v3":    {"input": 0.27,  "output": 1.10},
    "deepseek/deepseek-r1":         {"input": 0.55,  "output": 2.19},

    # ══════════════════════════════════════════════════════════════════
    # Cohere — https://cohere.com/pricing
    # ══════════════════════════════════════════════════════════════════
    "command-r-plus":               {"input": 2.50,  "output": 10.00},
    "command-r":                    {"input": 0.15,  "output": 0.60},
    "command-a":                    {"input": 2.50,  "output": 10.00},

    # ══════════════════════════════════════════════════════════════════
    # xAI Grok — https://x.ai/pricing
    # ══════════════════════════════════════════════════════════════════
    "grok-3":                       {"input": 3.00,  "output": 15.00},
    "grok-3-mini":                  {"input": 0.30,  "output": 0.50},
    "grok-2":                       {"input": 2.00,  "output": 10.00},

    # ══════════════════════════════════════════════════════════════════
    # OpenRouter models used by paragon proxy
    # ══════════════════════════════════════════════════════════════════
    "z-ai/glm-5.1":                 {"input": 0.95,  "output": 3.15},
    "z-ai/glm-5":                   {"input": 0.72,  "output": 2.30},
    "moonshotai/kimi-k2-thinking":  {"input": 0.60,  "output": 2.50},
    "openai/gpt-5.4-mini":          {"input": 0.75,  "output": 4.50},
    "minimax/minimax-m2.5":         {"input": 0.12,  "output": 0.99},

    # ══════════════════════════════════════════════════════════════════
    # Amazon Bedrock / AWS models
    # ══════════════════════════════════════════════════════════════════
    "amazon.nova-pro":              {"input": 0.80,  "output": 3.20},
    "amazon.nova-lite":             {"input": 0.06,  "output": 0.24},
    "amazon.nova-micro":            {"input": 0.035, "output": 0.14},

    # ══════════════════════════════════════════════════════════════════
    # Groq (hosted Llama/Mixtral) — https://groq.com/pricing
    # ══════════════════════════════════════════════════════════════════
    "llama-3.3-70b-versatile":      {"input": 0.59,  "output": 0.79},
    "llama-3.1-8b-instant":         {"input": 0.05,  "output": 0.08},
    "mixtral-8x7b-32768":           {"input": 0.24,  "output": 0.24},
    "gemma2-9b-it":                 {"input": 0.20,  "output": 0.20},

    # ══════════════════════════════════════════════════════════════════
    # Together AI — https://www.together.ai/pricing
    # ══════════════════════════════════════════════════════════════════
    "together/llama-3.1-405b":      {"input": 3.50,  "output": 3.50},
    "together/llama-3.1-70b":       {"input": 0.88,  "output": 0.88},
    "together/qwen-2.5-72b":        {"input": 0.60,  "output": 0.60},

    # ══════════════════════════════════════════════════════════════════
    # Qwen — https://help.aliyun.com/zh/model-studio/developer-reference/billing
    # ══════════════════════════════════════════════════════════════════
    "qwen-max":                     {"input": 1.60,  "output": 6.40},
    "qwen-plus":                    {"input": 0.40,  "output": 1.20},
    "qwen-turbo":                   {"input": 0.20,  "output": 0.60},
    "qwen3-235b-a22b":              {"input": 0.40,  "output": 1.20},
}


def _estimate_cost(model: str, input_tokens: int, output_tokens: int, cache_tokens: int = 0) -> float:
    """Calculate USD cost from model + token counts.

    Tries exact match first, then partial match on the model name.
    Cache tokens get a 90% discount on input pricing (Anthropic/OpenAI standard).
    """
    pricing = _MODEL_PRICING.get(model)
    if not pricing:
        # Try partial match — handles versioned names like "z-ai/glm-5.1-20260406"
        lower = model.lower()
        for key, p in _MODEL_PRICING.items():
            if key in lower or lower.startswith(key):
                pricing = p
                break
    if not pricing:
        return 0.0
    input_cost = input_tokens * pricing["input"] / 1_000_000
    output_cost = output_tokens * pricing["output"] / 1_000_000
    cache_discount = cache_tokens * pricing["input"] * 0.9 / 1_000_000 if cache_tokens > 0 else 0
    return round(input_cost + output_cost - cache_discount, 6)


def _extract_anthropic(response: Any) -> dict:
    """Extract tool calls, usage, model, and output from an Anthropic Messages response."""
    info: dict = {
        "provider": "anthropic", "tool_calls": [], "model": "",
        "input_tokens": 0, "output_tokens": 0, "cache_tokens": 0, "reasoning_tokens": 0,
        "output_text": "",
    }

    model = getattr(response, "model", None)
    if model:
        info["model"] = str(model)

    usage = getattr(response, "usage", None)
    if usage:
        info["input_tokens"] = getattr(usage, "input_tokens", 0) or 0
        info["output_tokens"] = getattr(usage, "output_tokens", 0) or 0
        info["cache_tokens"] = getattr(usage, "cache_read_input_tokens", 0) or getattr(usage, "cache_creation_input_tokens", 0) or 0

    content = getattr(response, "content", None)
    if content and isinstance(content, list):
        for block in content:
            block_type = getattr(block, "type", None)
            if block_type == "text":
                info["output_text"] += getattr(block, "text", "")
            elif block_type == "tool_use":
                tool_input = getattr(block, "input", None)
                info["tool_calls"].append({
                    "name": getattr(block, "name", ""),
                    "id": getattr(block, "id", ""),
                    "arguments": json.dumps(tool_input) if tool_input else "",
                })

    return info


def _extract_openai(response: Any) -> dict:
    """Extract tool calls, usage, model, and output from an OpenAI ChatCompletion response."""
    info: dict = {
        "provider": "openai", "tool_calls": [], "model": "",
        "input_tokens": 0, "output_tokens": 0, "cache_tokens": 0, "reasoning_tokens": 0,
        "output_text": "",
    }

    model = getattr(response, "model", None)
    if model:
        info["model"] = str(model)

    usage = getattr(response, "usage", None)
    if usage:
        info["input_tokens"] = getattr(usage, "prompt_tokens", 0) or 0
        info["output_tokens"] = getattr(usage, "completion_tokens", 0) or 0
        details = getattr(usage, "prompt_tokens_details", None)
        if details:
            info["cache_tokens"] = getattr(details, "cached_tokens", 0) or 0
        comp_details = getattr(usage, "completion_tokens_details", None)
        if comp_details:
            info["reasoning_tokens"] = getattr(comp_details, "reasoning_tokens", 0) or 0

    choices = getattr(response, "choices", None)
    if choices and len(choices) > 0:
        message = getattr(choices[0], "message", None)
        if message:
            content = getattr(message, "content", None)
            if content:
                info["output_text"] = str(content)
            tool_calls = getattr(message, "tool_calls", None)
            if tool_calls:
                for tc in tool_calls:
                    fn = getattr(tc, "function", None)
                    info["tool_calls"].append({
                        "name": getattr(fn, "name", "") if fn else "",
                        "id": getattr(tc, "id", ""),
                        "arguments": getattr(fn, "arguments", "") if fn else "",
                    })

    return info


# ---------------------------------------------------------------------------
# Streaming wrappers
# ---------------------------------------------------------------------------

class _AnthropicStreamWrapper:
    """Wraps an Anthropic streaming response to capture events on completion."""

    def __init__(self, stream: Any, http: "HTTPClient", sandbox_id: str, start_time: float) -> None:
        self._stream = stream
        self._http = http
        self._sandbox_id = sandbox_id
        self._start_time = start_time
        # Accumulate data from stream events
        self._tool_calls: list = []
        self._model: str = ""
        self._input_tokens: int = 0
        self._output_tokens: int = 0

    def __iter__(self):
        return self

    def __next__(self):
        try:
            event = next(self._stream)
            self._process_event(event)
            return event
        except StopIteration:
            self._report()
            raise

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        self._report()
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
        return False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_event(self, event: Any) -> None:
        event_type = getattr(event, "type", "")

        if event_type == "message_start":
            msg = getattr(event, "message", None)
            if msg:
                self._model = getattr(msg, "model", "") or ""
                usage = getattr(msg, "usage", None)
                if usage:
                    self._input_tokens = getattr(usage, "input_tokens", 0) or 0

        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage:
                self._output_tokens = getattr(usage, "output_tokens", 0) or 0

        elif event_type == "content_block_start":
            block = getattr(event, "content_block", None)
            if block and getattr(block, "type", "") == "tool_use":
                self._tool_calls.append({
                    "name": getattr(block, "name", ""),
                    "id": getattr(block, "id", ""),
                })

    def _report(self) -> None:
        duration_ms = int((time.monotonic() - self._start_time) * 1000)
        events = _build_events(
            provider="anthropic",
            model=self._model,
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            tool_calls=self._tool_calls,
            duration_ms=duration_ms,
            cache_tokens=getattr(self, "_cache_tokens", 0),
            reasoning_tokens=getattr(self, "_reasoning_tokens", 0),
        )
        if events:
            _post_trace_fire_and_forget(self._http, self._sandbox_id, events)


class _AnthropicAsyncStreamWrapper:
    """Async variant of the Anthropic stream wrapper."""

    def __init__(self, stream: Any, http: "HTTPClient", sandbox_id: str, start_time: float) -> None:
        self._stream = stream
        self._http = http
        self._sandbox_id = sandbox_id
        self._start_time = start_time
        self._tool_calls: list = []
        self._model: str = ""
        self._input_tokens: int = 0
        self._output_tokens: int = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            event = await self._stream.__anext__()
            self._process_event(event)
            return event
        except StopAsyncIteration:
            self._report()
            raise

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        self._report()
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*args)
        return False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_event(self, event: Any) -> None:
        # Same logic as the sync wrapper
        event_type = getattr(event, "type", "")

        if event_type == "message_start":
            msg = getattr(event, "message", None)
            if msg:
                self._model = getattr(msg, "model", "") or ""
                usage = getattr(msg, "usage", None)
                if usage:
                    self._input_tokens = getattr(usage, "input_tokens", 0) or 0
        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage:
                self._output_tokens = getattr(usage, "output_tokens", 0) or 0
        elif event_type == "content_block_start":
            block = getattr(event, "content_block", None)
            if block and getattr(block, "type", "") == "tool_use":
                self._tool_calls.append({
                    "name": getattr(block, "name", ""),
                    "id": getattr(block, "id", ""),
                })

    def _report(self) -> None:
        duration_ms = int((time.monotonic() - self._start_time) * 1000)
        events = _build_events(
            provider="anthropic",
            model=self._model,
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            tool_calls=self._tool_calls,
            duration_ms=duration_ms,
            cache_tokens=getattr(self, "_cache_tokens", 0),
            reasoning_tokens=getattr(self, "_reasoning_tokens", 0),
        )
        if events:
            _post_trace_fire_and_forget(self._http, self._sandbox_id, events)


class _OpenAIStreamWrapper:
    """Wraps an OpenAI streaming response to capture tool calls on completion."""

    def __init__(self, stream: Any, http: "HTTPClient", sandbox_id: str, start_time: float) -> None:
        self._stream = stream
        self._http = http
        self._sandbox_id = sandbox_id
        self._start_time = start_time
        self._model: str = ""
        self._tool_calls_acc: dict = {}  # index -> {id, name}
        self._input_tokens: int = 0
        self._output_tokens: int = 0

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            self._process_chunk(chunk)
            return chunk
        except StopIteration:
            self._report()
            raise

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        self._report()
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
        return False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_chunk(self, chunk: Any) -> None:
        model = getattr(chunk, "model", None)
        if model:
            self._model = str(model)

        # Usage in the final chunk (stream_options={"include_usage": True})
        usage = getattr(chunk, "usage", None)
        if usage:
            self._input_tokens = getattr(usage, "prompt_tokens", 0) or 0
            self._output_tokens = getattr(usage, "completion_tokens", 0) or 0

        choices = getattr(chunk, "choices", None)
        if not choices:
            return
        for choice in choices:
            delta = getattr(choice, "delta", None)
            if not delta:
                continue
            tool_calls = getattr(delta, "tool_calls", None)
            if not tool_calls:
                continue
            for tc in tool_calls:
                idx = getattr(tc, "index", 0)
                if idx not in self._tool_calls_acc:
                    self._tool_calls_acc[idx] = {"id": "", "name": ""}
                tc_id = getattr(tc, "id", None)
                if tc_id:
                    self._tool_calls_acc[idx]["id"] = tc_id
                fn = getattr(tc, "function", None)
                if fn:
                    fn_name = getattr(fn, "name", None)
                    if fn_name:
                        self._tool_calls_acc[idx]["name"] = fn_name

    def _report(self) -> None:
        duration_ms = int((time.monotonic() - self._start_time) * 1000)
        tool_calls = list(self._tool_calls_acc.values())
        events = _build_events(
            provider="openai",
            model=self._model,
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            tool_calls=tool_calls,
            duration_ms=duration_ms,
            cache_tokens=getattr(self, "_cache_tokens", 0),
            reasoning_tokens=getattr(self, "_reasoning_tokens", 0),
        )
        if events:
            _post_trace_fire_and_forget(self._http, self._sandbox_id, events)


class _OpenAIAsyncStreamWrapper:
    """Async variant of the OpenAI stream wrapper."""

    def __init__(self, stream: Any, http: "HTTPClient", sandbox_id: str, start_time: float) -> None:
        self._stream = stream
        self._http = http
        self._sandbox_id = sandbox_id
        self._start_time = start_time
        self._model: str = ""
        self._tool_calls_acc: dict = {}
        self._input_tokens: int = 0
        self._output_tokens: int = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
            self._process_chunk(chunk)
            return chunk
        except StopAsyncIteration:
            self._report()
            raise

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args):
        self._report()
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*args)
        return False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _process_chunk(self, chunk: Any) -> None:
        # Identical to sync version
        model = getattr(chunk, "model", None)
        if model:
            self._model = str(model)
        usage = getattr(chunk, "usage", None)
        if usage:
            self._input_tokens = getattr(usage, "prompt_tokens", 0) or 0
            self._output_tokens = getattr(usage, "completion_tokens", 0) or 0
        choices = getattr(chunk, "choices", None)
        if not choices:
            return
        for choice in choices:
            delta = getattr(choice, "delta", None)
            if not delta:
                continue
            tool_calls = getattr(delta, "tool_calls", None)
            if not tool_calls:
                continue
            for tc in tool_calls:
                idx = getattr(tc, "index", 0)
                if idx not in self._tool_calls_acc:
                    self._tool_calls_acc[idx] = {"id": "", "name": ""}
                tc_id = getattr(tc, "id", None)
                if tc_id:
                    self._tool_calls_acc[idx]["id"] = tc_id
                fn = getattr(tc, "function", None)
                if fn:
                    fn_name = getattr(fn, "name", None)
                    if fn_name:
                        self._tool_calls_acc[idx]["name"] = fn_name

    def _report(self) -> None:
        duration_ms = int((time.monotonic() - self._start_time) * 1000)
        tool_calls = list(self._tool_calls_acc.values())
        events = _build_events(
            provider="openai",
            model=self._model,
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            tool_calls=tool_calls,
            duration_ms=duration_ms,
            cache_tokens=getattr(self, "_cache_tokens", 0),
            reasoning_tokens=getattr(self, "_reasoning_tokens", 0),
        )
        if events:
            _post_trace_fire_and_forget(self._http, self._sandbox_id, events)


# ---------------------------------------------------------------------------
# Trace event construction
# ---------------------------------------------------------------------------

def _build_events(
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    tool_calls: list,
    duration_ms: int,
    cache_tokens: int = 0,
    reasoning_tokens: int = 0,
    output_text: str = "",
    input_messages: str = "",
    span_id: str = "",
    parent_span_id: str = "",
    root_span_id: str = "",
    status: str = "ok",
    error_type: str = "",
    extra_metadata: Optional[Dict[str, Any]] = None,
    requested_model: str = "",
) -> list:
    """Build trace events for one LLM call and its child tool calls.

    LLM call event columns:
      - input_tokens, output_tokens, cache_tokens, reason_tokens  (accurate from API)
      - model, cost_usd  (model name + calculated cost)
      - input   = the messages/prompt sent to the LLM (JSON)
      - output  = the LLM's text reply + list of tool calls requested
      - span_id = unique ID, parent of all tool_use children

    Tool use event columns:
      - tool_name  = function name (write_file, run_command, etc.)
      - input      = the arguments/parameters (JSON: {"path":"hello.py","content":"..."})
      - parent_span_id = links back to the LLM call that requested this tool
      - NO tokens, NO cost (tools don't consume tokens)
    """
    import uuid as _uuid

    ts = _iso_now()
    llm_span_id = span_id or f"span_{_uuid.uuid4().hex[:12]}"
    cost_usd = _estimate_cost(model, input_tokens, output_tokens, cache_tokens)

    # Build the output field: LLM text + tool call summary
    output_parts = []
    if output_text:
        output_parts.append(output_text)
    if tool_calls:
        tool_summary = [{"tool": tc.get("name", "?"), "args": tc.get("arguments", "")} for tc in tool_calls]
        output_parts.append(json.dumps({"tool_calls": tool_summary}))
    output_field = "\n".join(output_parts) if output_parts else ""

    events: list = []

    # LLM call — accurate tokens, cost, input/output.
    # The ``metadata`` block mirrors OpenTelemetry GenAI semantic conventions
    # (``gen_ai.*``) so traces exported via the server's /otel/v1/traces
    # round-trip cleanly into OTel-native backends (Honeycomb, Tempo, etc.).
    metadata = {
        "gen_ai.system": provider,
        "gen_ai.request.model": requested_model or model,
        "gen_ai.response.model": model,
        "gen_ai.usage.input_tokens": input_tokens,
        "gen_ai.usage.output_tokens": output_tokens,
        "gen_ai.operation.name": "chat",
    }
    if extra_metadata:
        metadata.update(extra_metadata)

    llm_event = {
        "ts": ts,
        "event_type": "llm_call",
        "tool": f"{provider}.create",
        "phase": "complete",
        "duration_ms": duration_ms,
        "status": status,
        "span_id": llm_span_id,
        "input": input_messages,
        "output": output_field,
        "cost": {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_read_tokens": cache_tokens,
            "reasoning_tokens": reasoning_tokens,
            "model": model,
            "estimated_usd": cost_usd,
        },
        "metadata": metadata,
    }
    # Fall back to thread-local @traced context if the caller didn't pass
    # explicit parent/root. This is the wiring that makes wrapped LLM calls
    # appear as children of the outer @traced(span_type="agent") function
    # instead of as flat orphans.
    if not parent_span_id or not root_span_id:
        try:
            from . import tracing as _tracing
            if not parent_span_id:
                parent_span_id = _tracing._get_parent_span() or ""
            if not root_span_id:
                root_span_id = _tracing._get_root_span() or ""
        except Exception:
            pass

    if parent_span_id:
        llm_event["parent_span_id"] = parent_span_id
    if root_span_id:
        llm_event["root_span_id"] = root_span_id
    if error_type:
        llm_event["error_type"] = error_type
    events.append(llm_event)

    # Tool calls — linked to parent, with full arguments, no cost.
    # They inherit root_span_id from the LLM call so they hang off the same
    # workflow tree.
    for tc in tool_calls:
        tool_event = {
            "ts": ts,
            "event_type": "tool_use",
            "tool": tc.get("name", "unknown"),
            "phase": "invoked",
            "duration_ms": 0,
            "status": "ok",
            "span_id": f"span_{_uuid.uuid4().hex[:12]}",
            "parent_span_id": llm_span_id,
            "input": tc.get("arguments", ""),
        }
        if root_span_id:
            tool_event["root_span_id"] = root_span_id
        events.append(tool_event)

    return events


# ---------------------------------------------------------------------------
# Patching logic
# ---------------------------------------------------------------------------

def _is_anthropic_client(client: Any) -> bool:
    """Detect Anthropic client: has client.messages.create."""
    try:
        messages = getattr(client, "messages", None)
        if messages is None:
            return False
        create = getattr(messages, "create", None)
        return callable(create)
    except Exception:
        return False


def _is_openai_client(client: Any) -> bool:
    """Detect OpenAI client: has client.chat.completions.create."""
    try:
        chat = getattr(client, "chat", None)
        if chat is None:
            return False
        completions = getattr(chat, "completions", None)
        if completions is None:
            return False
        create = getattr(completions, "create", None)
        return callable(create)
    except Exception:
        return False


def _is_async_callable(fn: Any) -> bool:
    """Check if a function is a coroutine function."""
    import inspect
    return inspect.iscoroutinefunction(fn)


def _patch_anthropic(client: Any, http: "HTTPClient", sandbox_id: str) -> Any:
    """Monkey-patch client.messages.create (sync and/or async)."""
    messages = client.messages
    original_create = messages.create

    if _is_async_callable(original_create):
        async def patched_create(*args: Any, **kwargs: Any) -> Any:
            stream = kwargs.get("stream", False)
            start = time.monotonic()
            try:
                response = await original_create(*args, **kwargs)
            except Exception:
                raise

            if stream:
                return _AnthropicAsyncStreamWrapper(response, http, sandbox_id, start)

            duration_ms = int((time.monotonic() - start) * 1000)
            try:
                info = _extract_anthropic(response)
                # Capture input messages from the call args
                _input_msgs = ""
                try:
                    _msgs = kwargs.get("messages") or (args[0] if args else None)
                    if _msgs:
                        _input_msgs = json.dumps(_msgs, default=str)[:4000]
                except Exception:
                    pass
                events = _build_events(
                    provider=info["provider"],
                    model=info["model"],
                    input_tokens=info["input_tokens"],
                    output_tokens=info["output_tokens"],
                    tool_calls=info["tool_calls"],
                    duration_ms=duration_ms,
                    cache_tokens=info.get("cache_tokens", 0),
                    reasoning_tokens=info.get("reasoning_tokens", 0),
                    output_text=info.get("output_text", ""),
                    input_messages=_input_msgs,
                )
                if events:
                    _post_trace_fire_and_forget(http, sandbox_id, events)
            except Exception:
                pass
            return response
    else:
        def patched_create(*args: Any, **kwargs: Any) -> Any:
            stream = kwargs.get("stream", False)
            start = time.monotonic()
            try:
                response = original_create(*args, **kwargs)
            except Exception:
                raise

            if stream:
                return _AnthropicStreamWrapper(response, http, sandbox_id, start)

            duration_ms = int((time.monotonic() - start) * 1000)
            try:
                info = _extract_anthropic(response)
                # Capture input messages from the call args
                _input_msgs = ""
                try:
                    _msgs = kwargs.get("messages") or (args[0] if args else None)
                    if _msgs:
                        _input_msgs = json.dumps(_msgs, default=str)[:4000]
                except Exception:
                    pass
                events = _build_events(
                    provider=info["provider"],
                    model=info["model"],
                    input_tokens=info["input_tokens"],
                    output_tokens=info["output_tokens"],
                    tool_calls=info["tool_calls"],
                    duration_ms=duration_ms,
                    cache_tokens=info.get("cache_tokens", 0),
                    reasoning_tokens=info.get("reasoning_tokens", 0),
                    output_text=info.get("output_text", ""),
                    input_messages=_input_msgs,
                )
                if events:
                    _post_trace_fire_and_forget(http, sandbox_id, events)
            except Exception:
                pass
            return response

    messages.create = patched_create
    return client


def _patch_openai(client: Any, http: "HTTPClient", sandbox_id: str) -> Any:
    """Monkey-patch client.chat.completions.create (sync and/or async)."""
    completions = client.chat.completions
    original_create = completions.create

    if _is_async_callable(original_create):
        async def patched_create(*args: Any, **kwargs: Any) -> Any:
            stream = kwargs.get("stream", False)
            start = time.monotonic()
            try:
                response = await original_create(*args, **kwargs)
            except Exception:
                raise

            if stream:
                return _OpenAIAsyncStreamWrapper(response, http, sandbox_id, start)

            duration_ms = int((time.monotonic() - start) * 1000)
            try:
                info = _extract_openai(response)
                # Capture input messages from the call args
                _input_msgs = ""
                try:
                    _msgs = kwargs.get("messages") or (args[0] if args else None)
                    if _msgs:
                        _input_msgs = json.dumps(_msgs, default=str)[:4000]
                except Exception:
                    pass
                events = _build_events(
                    provider=info["provider"],
                    model=info["model"],
                    input_tokens=info["input_tokens"],
                    output_tokens=info["output_tokens"],
                    tool_calls=info["tool_calls"],
                    duration_ms=duration_ms,
                    cache_tokens=info.get("cache_tokens", 0),
                    reasoning_tokens=info.get("reasoning_tokens", 0),
                    output_text=info.get("output_text", ""),
                    input_messages=_input_msgs,
                )
                if events:
                    _post_trace_fire_and_forget(http, sandbox_id, events)
            except Exception:
                pass
            return response
    else:
        def patched_create(*args: Any, **kwargs: Any) -> Any:
            stream = kwargs.get("stream", False)
            start = time.monotonic()
            try:
                response = original_create(*args, **kwargs)
            except Exception:
                raise

            if stream:
                return _OpenAIStreamWrapper(response, http, sandbox_id, start)

            duration_ms = int((time.monotonic() - start) * 1000)
            try:
                info = _extract_openai(response)
                # Capture input messages from the call args
                _input_msgs = ""
                try:
                    _msgs = kwargs.get("messages") or (args[0] if args else None)
                    if _msgs:
                        _input_msgs = json.dumps(_msgs, default=str)[:4000]
                except Exception:
                    pass
                events = _build_events(
                    provider=info["provider"],
                    model=info["model"],
                    input_tokens=info["input_tokens"],
                    output_tokens=info["output_tokens"],
                    tool_calls=info["tool_calls"],
                    duration_ms=duration_ms,
                    cache_tokens=info.get("cache_tokens", 0),
                    reasoning_tokens=info.get("reasoning_tokens", 0),
                    output_text=info.get("output_text", ""),
                    input_messages=_input_msgs,
                )
                if events:
                    _post_trace_fire_and_forget(http, sandbox_id, events)
            except Exception:
                pass
            return response

    completions.create = patched_create
    return client


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def wrap_client(client: Any, sandbox_id: str, http: "HTTPClient") -> Any:
    """Wrap an LLM client to auto-report tool calls to Keystone.

    Detects the client type and monkey-patches the relevant ``create()``
    method. Supports Anthropic, OpenAI, Mistral, Google GenAI, and Claude
    Agent SDK. The original client is returned (mutated in place).

    Args:
        client: An LLM client instance.
        sandbox_id: The Keystone sandbox to report traces to.
        http: The SDK's internal HTTP client (used for fire-and-forget POSTs).

    Returns:
        The same *client* object, now patched.

    Raises:
        TypeError: If the client is not a recognized LLM client.
    """
    if _is_anthropic_client(client):
        return _patch_anthropic(client, http, sandbox_id)
    if _is_openai_client(client):
        return _patch_openai(client, http, sandbox_id)
    if _is_mistral_client(client):
        return _patch_mistral(client, http, sandbox_id)
    if _is_google_genai_client(client):
        return _patch_google_genai(client, http, sandbox_id)
    if _is_claude_agent_sdk_module(client):
        return _patch_claude_agent_sdk(client, http, sandbox_id)
    raise TypeError(
        f"Unsupported client type: {type(client).__name__}. "
        "Expected an Anthropic / OpenAI / Mistral / Google GenAI / Claude Agent SDK client."
    )


# ---------------------------------------------------------------------------
# Provider-specific helpers — Mistral, Google GenAI, Claude Agent SDK
# ---------------------------------------------------------------------------


def _is_mistral_client(client: Any) -> bool:
    """Mistral SDK exposes ``client.chat.complete`` (note: not ``.completions``)."""
    try:
        chat = getattr(client, "chat", None)
        if chat is None:
            return False
        complete = getattr(chat, "complete", None)
        return callable(complete) and not _is_openai_client(client)
    except Exception:
        return False


def _is_google_genai_client(client: Any) -> bool:
    """Google GenAI SDK exposes ``client.models.generate_content``."""
    try:
        models = getattr(client, "models", None)
        if models is None:
            return False
        gen = getattr(models, "generate_content", None)
        return callable(gen)
    except Exception:
        return False


def _is_claude_agent_sdk_module(obj: Any) -> bool:
    """Claude Agent SDK is module-level — has a ``query`` async-iter function."""
    try:
        q = getattr(obj, "query", None)
        return callable(q) and getattr(obj, "__name__", "") in ("claude_agent_sdk",)
    except Exception:
        return False


def _extract_mistral(response: Any) -> dict:
    """Extract Mistral's OpenAI-shaped response. Tool calls live under
    ``response.choices[0].message.tool_calls`` just like OpenAI."""
    info = _extract_openai(response)
    info["provider"] = "mistral"
    return info


def _extract_google_genai(response: Any) -> dict:
    """Extract Google GenAI ``GenerateContentResponse`` shape.

    Tool calls under ``response.function_calls`` (or per-candidate). Token
    usage on ``response.usage_metadata.{prompt_token_count, candidates_token_count}``.
    """
    info: dict = {
        "provider": "google", "tool_calls": [], "model": "",
        "input_tokens": 0, "output_tokens": 0, "cache_tokens": 0, "reasoning_tokens": 0,
        "output_text": "",
    }

    model = getattr(response, "model", None) or getattr(response, "model_version", None)
    if model:
        info["model"] = str(model)

    usage = getattr(response, "usage_metadata", None)
    if usage:
        info["input_tokens"] = getattr(usage, "prompt_token_count", 0) or 0
        info["output_tokens"] = getattr(usage, "candidates_token_count", 0) or 0
        info["cache_tokens"] = getattr(usage, "cached_content_token_count", 0) or 0

    # Direct ``function_calls`` accessor (newer SDK).
    fcs = getattr(response, "function_calls", None) or []
    for fc in fcs:
        info["tool_calls"].append({
            "name": getattr(fc, "name", ""),
            "id": getattr(fc, "id", "") or "",
            "arguments": json.dumps(getattr(fc, "args", None) or {}),
        })

    # Direct text accessor.
    text = getattr(response, "text", None)
    if isinstance(text, str):
        info["output_text"] = text

    # Walk candidates for older SDK shapes.
    if not info["tool_calls"] or not info["output_text"]:
        for cand in getattr(response, "candidates", None) or []:
            content = getattr(cand, "content", None)
            for part in getattr(content, "parts", None) or []:
                fc = getattr(part, "function_call", None)
                if fc:
                    info["tool_calls"].append({
                        "name": getattr(fc, "name", ""),
                        "id": "",
                        "arguments": json.dumps(getattr(fc, "args", None) or {}),
                    })
                t = getattr(part, "text", None)
                if isinstance(t, str):
                    info["output_text"] += t

    return info


def _extract_claude_agent_messages(messages: list) -> dict:
    """Extract usage + tool_use blocks from a list of Claude Agent SDK messages.

    The SDK emits a stream of ``Message`` objects (Anthropic-shaped). Tool
    calls live as ``tool_use`` content blocks; usage rolls up on ``message_stop``
    or in the final ``Result`` message.
    """
    info: dict = {
        "provider": "anthropic", "tool_calls": [], "model": "",
        "input_tokens": 0, "output_tokens": 0, "cache_tokens": 0, "reasoning_tokens": 0,
        "output_text": "",
    }
    for msg in messages:
        # Many SDK versions emit dataclasses with `.content` and `.usage`.
        content = getattr(msg, "content", None)
        if isinstance(content, list):
            for block in content:
                btype = getattr(block, "type", None) or (block.get("type") if isinstance(block, dict) else None)
                if btype == "tool_use":
                    name = getattr(block, "name", None) or (block.get("name") if isinstance(block, dict) else "")
                    bid = getattr(block, "id", None) or (block.get("id") if isinstance(block, dict) else "")
                    binp = getattr(block, "input", None) or (block.get("input") if isinstance(block, dict) else None)
                    info["tool_calls"].append({
                        "name": name or "",
                        "id": bid or "",
                        "arguments": json.dumps(binp) if binp else "",
                    })
                elif btype == "text":
                    txt = getattr(block, "text", None) or (block.get("text") if isinstance(block, dict) else "")
                    if txt:
                        info["output_text"] += txt
        usage = getattr(msg, "usage", None)
        if usage:
            info["input_tokens"] = max(info["input_tokens"], getattr(usage, "input_tokens", 0) or 0)
            info["output_tokens"] = max(info["output_tokens"], getattr(usage, "output_tokens", 0) or 0)
        model = getattr(msg, "model", None)
        if model and not info["model"]:
            info["model"] = str(model)
    return info


def _patch_mistral(client: Any, http: "HTTPClient", sandbox_id: str) -> Any:
    """Monkey-patch Mistral's ``client.chat.complete`` (sync + stream)."""
    chat = client.chat
    original_complete = chat.complete

    def _wrapped(*args: Any, **kwargs: Any) -> Any:
        start = time.monotonic()
        response = original_complete(*args, **kwargs)
        try:
            duration_ms = int((time.monotonic() - start) * 1000)
            info = _extract_mistral(response)
            _msgs = kwargs.get("messages") or (args[0] if args else None)
            _input = json.dumps(_msgs, default=str)[:4000] if _msgs else ""
            events = _build_events(
                provider=info["provider"],
                model=info["model"],
                input_tokens=info["input_tokens"],
                output_tokens=info["output_tokens"],
                tool_calls=info["tool_calls"],
                duration_ms=duration_ms,
                cache_tokens=info.get("cache_tokens", 0),
                reasoning_tokens=info.get("reasoning_tokens", 0),
                output_text=info.get("output_text", ""),
                input_messages=_input,
            )
            if events:
                _post_trace_fire_and_forget(http, sandbox_id, events)
        except Exception:
            pass
        return response

    chat.complete = _wrapped
    return client


def _patch_google_genai(client: Any, http: "HTTPClient", sandbox_id: str) -> Any:
    """Monkey-patch Google GenAI's ``client.models.generate_content``."""
    models = client.models
    original_gen = models.generate_content

    def _wrapped(*args: Any, **kwargs: Any) -> Any:
        start = time.monotonic()
        response = original_gen(*args, **kwargs)
        try:
            duration_ms = int((time.monotonic() - start) * 1000)
            info = _extract_google_genai(response)
            # Best-effort input capture — SDK passes ``contents`` kwarg.
            contents = kwargs.get("contents") or (args[1] if len(args) > 1 else None)
            _input = json.dumps(contents, default=str)[:4000] if contents else ""
            events = _build_events(
                provider=info["provider"],
                model=info["model"],
                input_tokens=info["input_tokens"],
                output_tokens=info["output_tokens"],
                tool_calls=info["tool_calls"],
                duration_ms=duration_ms,
                cache_tokens=info.get("cache_tokens", 0),
                reasoning_tokens=info.get("reasoning_tokens", 0),
                output_text=info.get("output_text", ""),
                input_messages=_input,
            )
            if events:
                _post_trace_fire_and_forget(http, sandbox_id, events)
        except Exception:
            pass
        return response

    models.generate_content = _wrapped
    return client


def _patch_claude_agent_sdk(module: Any, http: "HTTPClient", sandbox_id: str) -> Any:
    """Patch ``claude_agent_sdk.query`` to capture tool_use blocks.

    The SDK's ``query()`` returns an async iterator of messages. We wrap
    the async generator so each yielded message is observed and a single
    trace batch is emitted on completion.
    """
    original_query = module.query

    def _wrapped(*args: Any, **kwargs: Any) -> Any:
        start = time.monotonic()
        async_iter = original_query(*args, **kwargs)
        collected: list = []

        # Wrap the underlying async iterator so we can both forward messages
        # to the caller and emit a single trace event when the stream ends.
        class _AsyncWrapper:
            def __aiter__(self):
                return self

            async def __anext__(self):
                try:
                    msg = await async_iter.__anext__()
                except StopAsyncIteration:
                    duration_ms = int((time.monotonic() - start) * 1000)
                    try:
                        info = _extract_claude_agent_messages(collected)
                        prompt = kwargs.get("prompt") or (args[0] if args else None)
                        _input = json.dumps(prompt, default=str)[:4000] if prompt else ""
                        events = _build_events(
                            provider="anthropic",
                            model=info["model"],
                            input_tokens=info["input_tokens"],
                            output_tokens=info["output_tokens"],
                            tool_calls=info["tool_calls"],
                            duration_ms=duration_ms,
                            cache_tokens=info.get("cache_tokens", 0),
                            reasoning_tokens=info.get("reasoning_tokens", 0),
                            output_text=info.get("output_text", ""),
                            input_messages=_input,
                        )
                        if events:
                            _post_trace_fire_and_forget(http, sandbox_id, events)
                    except Exception:
                        pass
                    raise
                collected.append(msg)
                return msg

        return _AsyncWrapper()

    module.query = _wrapped
    return module


# ---------------------------------------------------------------------------
# Named convenience aliases — Braintrust-parity API
# ---------------------------------------------------------------------------


def _http_for(client_or_keystone: Any) -> "HTTPClient":
    """Return the underlying ``HTTPClient`` from a Keystone client (or
    fall back to a fresh, env-configured one). Used by the named wrap_*
    helpers so callers can pass a Keystone instance instead of an HTTPClient.
    """
    http = getattr(client_or_keystone, "_http", None)
    if http is not None:
        return http
    if isinstance(client_or_keystone, HTTPClient):  # type: ignore[arg-type]
        return client_or_keystone  # type: ignore[return-value]
    # Lazily build a default HTTPClient using env config.
    from ._compat import DEFAULT_BASE_URL, get_env
    return HTTPClient(
        get_env("POLARITY_BASE_URL", "KEYSTONE_BASE_URL", DEFAULT_BASE_URL),
        get_env("POLARITY_API_KEY", "KEYSTONE_API_KEY"),
        30,
    )


def _resolved_sandbox(sandbox_id: str) -> str:
    if sandbox_id:
        return sandbox_id
    from ._compat import get_env
    return get_env("POLARITY_SANDBOX_ID", "KEYSTONE_SANDBOX_ID") or ""


def wrap_anthropic(client: Any, *, keystone: Any = None, sandbox_id: str = "") -> Any:
    """Wrap an Anthropic client. Braintrust-parity name."""
    sb = _resolved_sandbox(sandbox_id)
    return _patch_anthropic(client, _http_for(keystone), sb)


def wrap_openai(client: Any, *, keystone: Any = None, sandbox_id: str = "") -> Any:
    """Wrap an OpenAI client. Braintrust-parity name."""
    sb = _resolved_sandbox(sandbox_id)
    return _patch_openai(client, _http_for(keystone), sb)


def wrap_mistral(client: Any, *, keystone: Any = None, sandbox_id: str = "") -> Any:
    """Wrap a Mistral client. Patches ``client.chat.complete``."""
    sb = _resolved_sandbox(sandbox_id)
    if not _is_mistral_client(client):
        raise TypeError("expected a Mistral client with .chat.complete")
    return _patch_mistral(client, _http_for(keystone), sb)


def wrap_google_genai(client: Any, *, keystone: Any = None, sandbox_id: str = "") -> Any:
    """Wrap a Google GenAI client. Patches ``client.models.generate_content``."""
    sb = _resolved_sandbox(sandbox_id)
    if not _is_google_genai_client(client):
        raise TypeError("expected a google.genai client with .models.generate_content")
    return _patch_google_genai(client, _http_for(keystone), sb)


def wrap_claude_agent_sdk(module: Any, *, keystone: Any = None, sandbox_id: str = "") -> Any:
    """Wrap the ``claude_agent_sdk`` module. Patches its top-level ``query``."""
    sb = _resolved_sandbox(sandbox_id)
    if not callable(getattr(module, "query", None)):
        raise TypeError("expected the claude_agent_sdk module (with a query() function)")
    return _patch_claude_agent_sdk(module, _http_for(keystone), sb)


# ---------------------------------------------------------------------------
# record_llm_call — public manual emission for gateways / proxies / custom
# routing layers that don't have an SDK client object to wrap()
# ---------------------------------------------------------------------------


def record_llm_call(
    http: "HTTPClient",
    default_sandbox_id: str,
    *,
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    duration_ms: int,
    requested_model: Optional[str] = None,
    cache_tokens: int = 0,
    reasoning_tokens: int = 0,
    input_messages: Any = None,
    output_text: str = "",
    tool_calls: Optional[List[Dict[str, str]]] = None,
    status: str = "ok",
    error_type: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    span_id: Optional[str] = None,
    parent_span_id: Optional[str] = None,
    root_span_id: Optional[str] = None,
    sandbox_id: Optional[str] = None,
) -> None:
    """Emit an ``llm_call`` event (plus child ``tool_use`` events) with the
    same shape :func:`wrap_client` produces internally.

    Public entry point for callers that don't hold an Anthropic / OpenAI
    SDK *object* whose ``create()`` could be patched — multi-provider
    gateways, raw ``urllib`` / ``httpx`` flows, custom routing layers — but
    already extract the same fields :func:`wrap_client` would.

    Most callers should use :meth:`Keystone.record_llm_call` instead. This
    function is the underlying implementation, exposed for advanced cases
    where you hold the ``HTTPClient`` directly.

    Fire-and-forget — never raises, posts on a background thread. See
    :meth:`Keystone.record_llm_call` for argument docs.
    """
    try:
        # Truncate inputs to ~4KB on the wire — same cap wrap_client uses.
        if input_messages is None:
            input_str = ""
        elif isinstance(input_messages, str):
            input_str = input_messages
        else:
            try:
                input_str = json.dumps(input_messages)
            except (TypeError, ValueError):
                input_str = ""
        if len(input_str) > 4000:
            input_str = input_str[:4000]

        events = _build_events(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            tool_calls=list(tool_calls or []),
            duration_ms=duration_ms,
            cache_tokens=cache_tokens,
            reasoning_tokens=reasoning_tokens,
            output_text=output_text,
            input_messages=input_str,
            span_id=span_id or "",
            parent_span_id=parent_span_id or "",
            root_span_id=root_span_id or "",
            status=status,
            error_type=error_type or "",
            extra_metadata=metadata,
            requested_model=requested_model or "",
        )
        resolved_sandbox = (
            sandbox_id if sandbox_id is not None else default_sandbox_id
        )
        _post_trace_fire_and_forget(http, resolved_sandbox, events)
    except Exception:
        # Trace emission must never break the caller.
        pass
