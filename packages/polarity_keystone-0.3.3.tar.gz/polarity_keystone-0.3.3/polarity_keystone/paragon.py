"""Paragon — agent runtime + harness for the Keystone copilot.

Mirrors the @cursor/sdk surface so consumers familiar with Cursor's
agent SDK can use Keystone's Paragon agent with zero translation::

    from polarity_keystone import Agent

    async def main():
        agent = await Agent.create(api_key=..., model={'id': 'anthropic/claude-sonnet-4-5'})
        run = await agent.send('Find traces with high latency')
        async for event in run.stream():
            print(event)
        await agent.close()

Backing transport is the existing SSE /v1/paragon/chat endpoint.

This file deliberately matches the @cursor/sdk Python-shaped API
(`Agent.create`, `agent.send`, `run.stream`, the `SDKMessage` taxonomy,
the error class hierarchy) so the same usage idioms apply.
"""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional, Union

import urllib.request

from ._http import HTTPClient


# ─── Errors — mirrors @cursor/sdk errors ─────────────────────────────


class KeystoneSdkError(Exception):
    """Base error for all Keystone SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        code: Optional[str] = None,
        status: Optional[int] = None,
        is_retryable: bool = False,
        cause: Optional[BaseException] = None,
        endpoint: Optional[str] = None,
        request_id: Optional[str] = None,
        operation: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status = status
        self.is_retryable = is_retryable
        self.cause = cause
        self.endpoint = endpoint
        self.request_id = request_id
        self.operation = operation


class KeystoneAgentError(KeystoneSdkError):
    """Agent SDK error root."""


class AuthenticationError(KeystoneAgentError):
    """401 — invalid API key / not logged in."""


class RateLimitError(KeystoneAgentError):
    """429 — rate limited / usage exceeded."""


class ConfigurationError(KeystoneAgentError):
    """400 / 404 — invalid model, bad parameters, unsupported operation."""


class AgentBusyError(KeystoneAgentError):
    """409 — another run is already active on this agent."""


class NetworkError(KeystoneAgentError):
    """5xx — service unavailable, timeout, etc. Retryable."""


class UnknownAgentError(KeystoneAgentError):
    """Catch-all for unclassified failures."""


class UnsupportedRunOperationError(ConfigurationError):
    """Raised when calling a Run method the run doesn't support."""


def wrap_sdk_error(err: BaseException, **context: Any) -> KeystoneSdkError:
    if isinstance(err, KeystoneSdkError):
        return err
    return KeystoneSdkError(str(err), cause=err, **context)


# ─── Options — mirrors @cursor/sdk options ───────────────────────────


@dataclass
class ModelParameterValue:
    id: str
    value: str


@dataclass
class ModelSelection:
    """A BYOK model selection. `id` is a provider-prefixed string
    (e.g. 'anthropic/claude-sonnet-4-5') discoverable via Keystone.models.list()."""
    id: str
    params: Optional[List[ModelParameterValue]] = None


@dataclass
class ModelListItem:
    id: str
    display_name: str
    provider: Optional[str] = None
    configured: Optional[bool] = None
    description: Optional[str] = None
    aliases: Optional[List[str]] = None


@dataclass
class LocalAgentOptions:
    """Recognized for API parity with @cursor/sdk; not implemented in Keystone yet."""
    cwd: Optional[Union[str, List[str]]] = None
    setting_sources: Optional[List[str]] = None


@dataclass
class CloudAgentOptions:
    """Cloud agent options. `agent_kind` is the Paragon-specific extension."""
    agent_kind: str = "global_copilot"


@dataclass
class AgentOptions:
    """Args for Agent.create()."""
    model: Optional[ModelSelection] = None
    api_key: Optional[str] = None
    name: Optional[str] = None
    local: Optional[LocalAgentOptions] = None
    cloud: Optional[CloudAgentOptions] = None
    agent_id: Optional[str] = None
    base_url: Optional[str] = None
    idempotency_key: Optional[str] = None


@dataclass
class SendOptions:
    model: Optional[ModelSelection] = None
    idempotency_key: Optional[str] = None


# ─── Messages — mirrors @cursor/sdk messages ─────────────────────────


@dataclass
class TextBlock:
    text: str
    type: str = "text"


@dataclass
class ToolUseBlock:
    id: str
    name: str
    input: Any
    type: str = "tool_use"


@dataclass
class SDKMessage:
    """Base class for all stream events. Use `.type` to discriminate."""
    type: str
    agent_id: str
    run_id: str
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SDKSystemMessage(SDKMessage):
    subtype: Optional[str] = None
    model: Optional[ModelSelection] = None
    tools: Optional[List[str]] = None


@dataclass
class SDKAssistantMessage(SDKMessage):
    content: List[Union[TextBlock, ToolUseBlock]] = field(default_factory=list)


@dataclass
class SDKUserMessageEvent(SDKMessage):
    content: List[TextBlock] = field(default_factory=list)


@dataclass
class SDKToolUseMessage(SDKMessage):
    call_id: str = ""
    name: str = ""
    status: str = "running"
    args: Any = None
    result: Any = None


@dataclass
class SDKThinkingMessage(SDKMessage):
    text: str = ""
    thinking_duration_ms: Optional[int] = None


@dataclass
class SDKStatusMessage(SDKMessage):
    status: str = ""
    message: Optional[str] = None


@dataclass
class SDKTableMessage(SDKMessage):
    """Keystone-specific. The Paragon agent streams `table` blocks
    that carry trace search results — we surface them as a dedicated
    message type so consumers can branch on `type == 'table'`."""
    title: str = ""
    rows: List[Dict[str, Any]] = field(default_factory=list)


# ─── Run + Agent — mirrors @cursor/sdk run + stubs ───────────────────


@dataclass
class RunResult:
    id: str
    status: str
    result: Optional[str] = None
    model: Optional[ModelSelection] = None
    duration_ms: Optional[int] = None


class Run:
    """One agent prompt → response stream. Iterate `run.stream()` to receive events."""

    def __init__(self, run_id: str, agent_id: str, ctx: "_ParagonContext", message: str, options: SendOptions) -> None:
        self.id = run_id
        self.agent_id = agent_id
        self._ctx = ctx
        self._message = message
        self._options = options
        self._status = "running"
        self._result: Optional[str] = None
        self._duration_ms: Optional[int] = None
        self._started = False
        self._queue: asyncio.Queue[Optional[SDKMessage]] = asyncio.Queue()
        self._error: Optional[BaseException] = None
        self._listeners: List[Any] = []
        self._task: Optional[asyncio.Task[None]] = None

    @property
    def status(self) -> str:
        return self._status

    @property
    def result(self) -> Optional[str]:
        return self._result

    @property
    def duration_ms(self) -> Optional[int]:
        return self._duration_ms

    def supports(self, operation: str) -> bool:
        return operation in ("stream", "wait", "cancel", "conversation")

    def on_did_change_status(self, listener: Any) -> Any:
        self._listeners.append(listener)
        return lambda: self._listeners.remove(listener) if listener in self._listeners else None

    def _set_status(self, s: str) -> None:
        self._status = s
        for l in self._listeners:
            try:
                l(s)
            except Exception:
                pass

    async def stream(self) -> AsyncIterator[SDKMessage]:
        if not self._started:
            self._started = True
            self._task = asyncio.create_task(self._run_stream())
        while True:
            ev = await self._queue.get()
            if ev is None:
                if self._error:
                    raise self._error
                return
            yield ev

    async def wait(self) -> RunResult:
        async for _ in self.stream():
            pass
        return RunResult(
            id=self.id,
            status="finished" if self._status == "running" else self._status,
            result=self._result,
            duration_ms=self._duration_ms,
        )

    async def cancel(self) -> None:
        if self._task:
            self._task.cancel()
        self._set_status("cancelled")

    async def conversation(self) -> List[Dict[str, Any]]:
        return [{"role": "user", "text": self._message}]

    async def _run_stream(self) -> None:
        try:
            await self._queue.put(SDKSystemMessage(
                type="system", agent_id=self.agent_id, run_id=self.id,
                subtype="init", tools=["search_traces", "get_judge", "get_behavior"],
            ))
            async for ev in _stream_sse(self._ctx, self._message):
                msg = _to_sdk_message(ev, self.agent_id, self.id)
                if msg is not None:
                    await self._queue.put(msg)
            await self._queue.put(SDKStatusMessage(
                type="status", agent_id=self.agent_id, run_id=self.id, status="FINISHED",
            ))
            self._set_status("finished")
        except BaseException as e:
            wrapped = e if isinstance(e, KeystoneSdkError) else UnknownAgentError(str(e), cause=e)
            self._error = wrapped
            self._set_status("error")
        finally:
            await self._queue.put(None)


class SDKAgent:
    """Stateful conversation container. Keep alive across multiple sends."""

    def __init__(self, agent_id: str, ctx: "_ParagonContext", model: Optional[ModelSelection] = None) -> None:
        self.agent_id = agent_id
        self._ctx = ctx
        self.model = model

    async def send(self, message: str, options: Optional[SendOptions] = None) -> Run:
        opts = options or SendOptions()
        if opts.model:
            self.model = opts.model
        run_id = f"run-{os.urandom(6).hex()}"
        return Run(run_id, self.agent_id, self._ctx, message, opts)

    def close(self) -> None:
        """No-op — Paragon threads persist server-side."""

    async def reload(self) -> None:
        """No-op for now."""


class Agent:
    """Factory for SDKAgent. Mirrors `Agent.create()` from @cursor/sdk."""

    @staticmethod
    async def create(
        api_key: Optional[str] = None,
        *,
        model: Optional[Union[ModelSelection, Dict[str, str]]] = None,
        base_url: Optional[str] = None,
        name: Optional[str] = None,
        agent_id: Optional[str] = None,
        mcp_servers: Optional[Dict[str, Dict[str, Any]]] = None,
    ) -> SDKAgent:
        ctx = _build_context(api_key=api_key, base_url=base_url, thread_id=agent_id, mcp_servers=mcp_servers)
        sel = _coerce_model(model)
        # Synthesize a temp id; the SSE 'thread' event will update us.
        thread_id = agent_id or f"thr-pending-{os.urandom(7).hex()}"
        return SDKAgent(thread_id, ctx, sel)

    @staticmethod
    async def resume(agent_id: str, api_key: Optional[str] = None, base_url: Optional[str] = None) -> SDKAgent:
        ctx = _build_context(api_key=api_key, base_url=base_url, thread_id=agent_id)
        return SDKAgent(agent_id, ctx)

    @staticmethod
    async def prompt(message: str, **kwargs: Any) -> RunResult:
        """Convenience: create agent, send once, await, close."""
        agent = await Agent.create(**kwargs)
        try:
            run = await agent.send(message)
            return await run.wait()
        finally:
            agent.close()


class Keystone:
    """Account / catalog operations. Mirrors the `Cursor` class in @cursor/sdk."""

    class models:
        @staticmethod
        async def list(api_key: Optional[str] = None, base_url: Optional[str] = None) -> List[ModelListItem]:
            ctx = _build_context(api_key=api_key, base_url=base_url)
            req = urllib.request.Request(
                f"{ctx.base_url}/v1/models",
                headers={"Authorization": f"Bearer {ctx.api_key}"},
            )

            def _do() -> bytes:
                with urllib.request.urlopen(req) as resp:
                    return resp.read()

            body = await asyncio.to_thread(_do)
            payload = json.loads(body)
            return [
                ModelListItem(
                    id=m["id"],
                    display_name=m.get("display_name", m["id"]),
                    provider=m.get("provider"),
                    configured=m.get("configured"),
                )
                for m in payload.get("models", [])
            ]


# ─── Internals ───────────────────────────────────────────────────────


@dataclass
class _ParagonContext:
    base_url: str
    api_key: str
    thread_id: Optional[str] = None
    mcp_servers: Optional[Dict[str, Dict[str, Any]]] = None


def _build_context(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    thread_id: Optional[str] = None,
    mcp_servers: Optional[Dict[str, Dict[str, Any]]] = None,
) -> _ParagonContext:
    key = api_key or os.environ.get("KEYSTONE_API_KEY")
    if not key:
        raise AuthenticationError("No API key. Pass api_key or set KEYSTONE_API_KEY.")
    url = base_url or os.environ.get("POLARITY_BASE_URL") or os.environ.get("KEYSTONE_BASE_URL") or "https://api.plr.sh"
    return _ParagonContext(
        base_url=url.rstrip("/"), api_key=key, thread_id=thread_id, mcp_servers=mcp_servers,
    )


def _coerce_model(model: Optional[Union[ModelSelection, Dict[str, str]]]) -> Optional[ModelSelection]:
    if model is None:
        return None
    if isinstance(model, ModelSelection):
        return model
    if isinstance(model, dict):
        return ModelSelection(id=model["id"], params=None)
    raise ConfigurationError(f"model must be ModelSelection or dict with 'id'; got {type(model).__name__}")


async def _stream_sse(ctx: _ParagonContext, message: str) -> AsyncIterator[Dict[str, Any]]:
    """Streams SSE events from /v1/paragon/chat. Yields raw parsed events."""
    body = json.dumps({
        "message": message,
        "mode": "normal",
        **({"thread_id": ctx.thread_id} if ctx.thread_id else {}),
        **({"mcp_servers": ctx.mcp_servers} if ctx.mcp_servers else {}),
    }).encode()
    req = urllib.request.Request(
        f"{ctx.base_url}/v1/paragon/chat",
        data=body,
        headers={
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Authorization": f"Bearer {ctx.api_key}",
        },
        method="POST",
    )

    def _open() -> Any:
        return urllib.request.urlopen(req)

    resp = await asyncio.to_thread(_open)
    try:
        loop = asyncio.get_event_loop()
        buf = ""
        while True:
            raw = await loop.run_in_executor(None, resp.readline)
            if not raw:
                break
            buf += raw.decode("utf-8")
            while "\n\n" in buf:
                block, buf = buf.split("\n\n", 1)
                ev = _parse_sse_block(block)
                if ev:
                    yield ev
    finally:
        resp.close()


def _parse_sse_block(raw: str) -> Optional[Dict[str, str]]:
    event = "message"
    data_lines: List[str] = []
    for line in raw.splitlines():
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].strip())
    if not data_lines:
        return None
    try:
        data = json.loads("\n".join(data_lines))
    except json.JSONDecodeError:
        return None
    return {"event": event, "data": data}


def _to_sdk_message(ev: Dict[str, Any], agent_id: str, run_id: str) -> Optional[SDKMessage]:
    name = ev.get("event")
    data = ev.get("data") or {}
    if name == "block":
        kind = data.get("kind")
        if kind == "text":
            return SDKAssistantMessage(
                type="assistant", agent_id=agent_id, run_id=run_id, raw=data,
                content=[TextBlock(text=data.get("body", ""))],
            )
        if kind == "thought":
            return SDKThinkingMessage(
                type="thinking", agent_id=agent_id, run_id=run_id, raw=data,
                text=data.get("body", ""),
            )
        if kind == "table":
            return SDKTableMessage(
                type="table", agent_id=agent_id, run_id=run_id, raw=data,
                title=data.get("title", ""), rows=data.get("rows", []),
            )
    elif name == "error":
        raise UnknownAgentError(str(data.get("error", "stream error")))
    return None


# ─── Low-level shortcut (back-compat) ────────────────────────────────


class ParagonService:
    """Low-level streaming chat. For the ergonomic API, use Agent.create()."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http
        self._base = http.base_url
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        if http.api_key:
            self._headers["Authorization"] = f"Bearer {http.api_key}"
            self._headers["X-API-Key"] = http.api_key

    def chat(
        self,
        message: str,
        *,
        mode: str = "normal",
        thread_id: Optional[str] = None,
        agent_kind: str = "global_copilot",
    ) -> Any:
        body = json.dumps({
            "message": message,
            "mode": mode,
            "agent_kind": agent_kind,
            **({"thread_id": thread_id} if thread_id else {}),
        }).encode()
        req = urllib.request.Request(
            f"{self._base}/v1/paragon/chat",
            data=body,
            headers=self._headers,
            method="POST",
        )
        with urllib.request.urlopen(req) as resp:
            buf = ""
            for raw in iter(lambda: resp.readline().decode("utf-8"), ""):
                buf += raw
                while "\n\n" in buf:
                    block, buf = buf.split("\n\n", 1)
                    ev = _parse_sse_block(block)
                    if not ev:
                        continue
                    if ev["event"] == "thread":
                        yield {"kind": "meta", "thread_id": ev["data"].get("thread_id")}
                    elif ev["event"] == "block":
                        yield ev["data"]
                    elif ev["event"] == "error":
                        raise UnknownAgentError(ev["data"].get("error") or "stream error")

    @property
    def threads(self) -> "_ThreadService":
        return _ThreadService(self._http)


class _ThreadService:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self) -> List[Dict[str, Any]]:
        return self._http.get("/v1/paragon/threads") or []

    def get(self, thread_id: str) -> Dict[str, Any]:
        return self._http.get(f"/v1/paragon/threads/{thread_id}")

    def delete(self, thread_id: str) -> None:
        self._http.delete(f"/v1/paragon/threads/{thread_id}")
