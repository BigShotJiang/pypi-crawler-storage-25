"""Lightweight runtime validators + type guards mirroring the
@cursor/sdk schema surface, without pulling in pydantic. Each `*Schema`
exposes a `.parse(input)` that returns the typed value or raises.

Keystone consumers typically don't need to validate at the wire
boundary — the Service classes already do — but these are here so SDK
code that mirrors Cursor's validator-driven flow has drop-in
replacements.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Tuple, Type, Union


# ─── Models ───────────────────────────────────────────────────────────

@dataclass
class Image:
    url: str
    alt_text: Optional[str] = None
    kind: Literal["image"] = "image"


@dataclass
class UserMessage:
    content: Any  # str | list[{"type":"text","text":str} | Image]
    role: Literal["user"] = "user"
    id: Optional[str] = None
    created_at: Optional[str] = None


@dataclass
class AssistantMessage:
    content: str
    role: Literal["assistant"] = "assistant"
    id: Optional[str] = None
    created_at: Optional[str] = None


Message = Union[UserMessage, AssistantMessage]


# ─── Type guards ──────────────────────────────────────────────────────

def is_image(value: Any) -> bool:
    if isinstance(value, Image):
        return True
    return (
        isinstance(value, dict)
        and value.get("kind") == "image"
        and isinstance(value.get("url"), str)
    )


def is_user_message(value: Any) -> bool:
    if isinstance(value, UserMessage):
        return True
    return (
        isinstance(value, dict)
        and value.get("role") == "user"
        and "content" in value
    )


def is_assistant_message(value: Any) -> bool:
    if isinstance(value, AssistantMessage):
        return True
    return (
        isinstance(value, dict)
        and value.get("role") == "assistant"
        and isinstance(value.get("content"), str)
    )


def is_message(value: Any) -> bool:
    return is_user_message(value) or is_assistant_message(value)


_KNOWN_SDK_MESSAGE_TYPES = {
    "system", "assistant", "user", "tool_call",
    "thinking", "status", "request", "task", "table",
}


def is_sdk_message(value: Any) -> bool:
    if not isinstance(value, dict):
        return False
    t = value.get("type")
    return isinstance(t, str) and t in _KNOWN_SDK_MESSAGE_TYPES


# ─── Schemas (parse → typed, raises on bad input) ────────────────────

class _SchemaBase:
    """Common .safe_parse around .parse for ergonomic ``try/except``."""

    def safe_parse(self, value: Any) -> Tuple[bool, Any]:
        try:
            return True, self.parse(value)
        except Exception as e:  # noqa: BLE001 — user code may pass anything
            return False, e

    def parse(self, value: Any) -> Any:  # pragma: no cover - subclass
        raise NotImplementedError


def _fail(name: str, value: Any) -> None:
    try:
        preview = json.dumps(value)[:120]
    except Exception:
        preview = repr(value)[:120]
    raise ValueError(f"invalid {name}: {preview}")


class _ImageSchema(_SchemaBase):
    def parse(self, value: Any) -> Image:
        if isinstance(value, Image):
            return value
        if not is_image(value):
            _fail("Image", value)
        return Image(url=value["url"], alt_text=value.get("alt_text"))


class _UserMessageSchema(_SchemaBase):
    def parse(self, value: Any) -> UserMessage:
        if isinstance(value, UserMessage):
            return value
        if not is_user_message(value):
            _fail("UserMessage", value)
        return UserMessage(
            content=value["content"],
            id=value.get("id"),
            created_at=value.get("created_at"),
        )


class _AssistantMessageSchema(_SchemaBase):
    def parse(self, value: Any) -> AssistantMessage:
        if isinstance(value, AssistantMessage):
            return value
        if not is_assistant_message(value):
            _fail("AssistantMessage", value)
        return AssistantMessage(
            content=value["content"],
            id=value.get("id"),
            created_at=value.get("created_at"),
        )


class _MessageSchema(_SchemaBase):
    def parse(self, value: Any) -> Message:
        if is_user_message(value):
            return _UserMessageSchema().parse(value)
        if is_assistant_message(value):
            return _AssistantMessageSchema().parse(value)
        _fail("Message", value)


class _SDKMessageSchema(_SchemaBase):
    def parse(self, value: Any) -> Dict[str, Any]:
        if not is_sdk_message(value):
            _fail("SDKMessage", value)
        return value


ImageSchema = _ImageSchema()
UserMessageSchema = _UserMessageSchema()
AssistantMessageSchema = _AssistantMessageSchema()
MessageSchema = _MessageSchema()
SDKMessageSchema = _SDKMessageSchema()


__all__ = [
    "Image",
    "UserMessage",
    "AssistantMessage",
    "Message",
    "is_image",
    "is_user_message",
    "is_assistant_message",
    "is_message",
    "is_sdk_message",
    "ImageSchema",
    "UserMessageSchema",
    "AssistantMessageSchema",
    "MessageSchema",
    "SDKMessageSchema",
]
