"""Workspaces ("projects" in JudgmentLabs lingo) — outermost scope.

Every owner-scoped resource (judges, behaviors, traces, experiments,
sandboxes, ...) lives in exactly one workspace. The SDK pins requests
to a workspace via the ``X-Polarity-Workspace`` header populated from
``Polarity(workspace=...)``; this service manages the workspaces
themselves.

Mirrors ``judgment projects`` 1:1 — list / get / create / update /
delete plus ``favorite`` / ``unfavorite`` for sidebar pinning.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ._http import HTTPClient


class WorkspacesService:
    """CRUD + favorite toggle for workspaces."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self) -> List[Dict[str, Any]]:
        """List every workspace under the caller's owner.

        Server orders favorites first, then default, then by recent
        activity — same ordering the dashboard sidebar uses.
        """
        return self._http.get("/v1/workspaces") or []

    def get(self, workspace_id: str) -> Dict[str, Any]:
        """Fetch a single workspace by id."""
        return self._http.get(f"/v1/workspaces/{workspace_id}")

    def create(self, name: str, *, description: str = "") -> Dict[str, Any]:
        """Create a new workspace under the caller's owner."""
        return self._http.post("/v1/workspaces", {"name": name, "description": description})

    def update(
        self,
        workspace_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Partial-update a workspace's name and/or description.

        The default workspace cannot be renamed (server returns 400).
        """
        patch: Dict[str, Any] = {}
        if name is not None:
            patch["name"] = name
        if description is not None:
            patch["description"] = description
        return self._http._request("PUT", f"/v1/workspaces/{workspace_id}", body=patch)

    def delete(self, workspace_id: str) -> None:
        """Delete a workspace. Default workspaces cannot be deleted;
        workspaces with resources still attached return 409."""
        self._http.delete(f"/v1/workspaces/{workspace_id}")

    def favorite(self, workspace_id: str) -> None:
        """Pin a workspace in the dashboard sidebar."""
        self._http.post(f"/v1/workspaces/{workspace_id}/favorite")

    def unfavorite(self, workspace_id: str) -> None:
        """Remove the pin."""
        self._http.delete(f"/v1/workspaces/{workspace_id}/favorite")
