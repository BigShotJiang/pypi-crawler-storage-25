"""Cursor.* namespace + Agent CRUD methods, mirroring the @cursor/sdk
top-level client. Keystone keeps its own ``KeystoneAccount`` as the
primary surface; this module adds a Cursor-shaped façade so consumers
porting from @cursor/sdk can swap imports with minimal churn.
"""
from __future__ import annotations

import os
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Literal, Optional

from .paragon import (
    Agent,
    AgentOptions,
    Run,
    SDKAgent,
    SendOptions,
)


# ─── Errors ──────────────────────────────────────────────────────────

class IntegrationNotConnectedError(Exception):
    """Raised when a Cursor.* method depends on a 3rd-party integration
    (GitHub, etc.) that hasn't been linked to this Keystone account."""

    def __init__(self, integration: str, message: Optional[str] = None) -> None:
        super().__init__(message or f'Integration "{integration}" is not connected for this account.')
        self.integration = integration


# ─── Platform stub ───────────────────────────────────────────────────

@dataclass
class CursorAgentPlatform:
    """Stub matching @cursor/sdk's CursorAgentPlatform. Keystone runs
    agents server-side via /v1/paragon, so most of the local-harness
    hooks are no-ops; this exists so consumers porting Cursor code can
    keep their type annotations and inject a real implementation if
    they bring their own harness."""

    resolve_working_dir: Optional[Callable[[], str]] = None
    spawn_process: Optional[Callable[[str, List[str]], Dict[str, Any]]] = None
    read_file: Optional[Callable[[str], str]] = None
    write_file: Optional[Callable[[str, str], None]] = None


NoopCursorAgentPlatform = CursorAgentPlatform()


# ─── Account / repos models ──────────────────────────────────────────

@dataclass
class CursorAccount:
    id: str
    email: Optional[str] = None
    team_id: Optional[str] = None
    name: Optional[str] = None


@dataclass
class CursorRepository:
    id: str
    full_name: str
    default_branch: str
    private: Optional[bool] = None


@dataclass
class CursorAgentRecord:
    id: str
    name: Optional[str] = None
    archived: Optional[bool] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class CursorAgentMessage:
    id: str
    agent_id: str
    role: Literal["user", "assistant", "system"]
    content: str
    created_at: str


@dataclass
class CursorRunSummary:
    run_id: str
    agent_id: str
    status: Literal["running", "completed", "errored", "cancelled"]
    started_at: str
    ended_at: Optional[str] = None


@dataclass
class CursorAgentArtifact:
    id: str
    name: str
    content_type: str
    size_bytes: Optional[int] = None
    download_url: Optional[str] = None


# ─── Cursor client ───────────────────────────────────────────────────

class Cursor:
    """Cursor-shaped façade over the Keystone API."""

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        platform: Optional[CursorAgentPlatform] = None,
    ) -> None:
        self.base_url = (base_url or os.environ.get("KEYSTONE_API_URL", "http://localhost:8012")).rstrip("/")
        self.api_key = api_key or os.environ.get("KEYSTONE_API_KEY")
        self.platform = platform or NoopCursorAgentPlatform

        # Nested .agents and .repositories provide CRUD that mirrors
        # @cursor/sdk's `client.agents.*` / `client.repositories.*`.
        self.agents = _AgentsNamespace(self)
        self.repositories = _RepositoriesNamespace(self)

    # ── http helpers ───────────────────────────────────────────────

    def _headers(self) -> Dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["X-API-Key"] = self.api_key
        return h

    def _req(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Any:
        import json as _json

        req = urllib.request.Request(
            f"{self.base_url}{path}",
            data=_json.dumps(body).encode() if body is not None else None,
            method=method,
            headers=self._headers(),
        )
        with urllib.request.urlopen(req) as res:
            data = res.read()
            if not data:
                return None
            return _json.loads(data)

    # ── account ────────────────────────────────────────────────────

    def me(self) -> CursorAccount:
        d = self._req("GET", "/v1/account") or {}
        return CursorAccount(
            id=d.get("id", ""),
            email=d.get("email"),
            team_id=d.get("team_id"),
            name=d.get("name"),
        )

    # ── one-shot helpers ───────────────────────────────────────────

    def agent_create(self, name: Optional[str] = None, options: Optional[AgentOptions] = None) -> SDKAgent:
        opts = options or AgentOptions()
        opts.api_key = opts.api_key or self.api_key
        opts.base_url = opts.base_url or self.base_url
        opts.name = name or opts.name
        return Agent.create(opts)

    def run_once(
        self,
        prompt: str,
        options: Optional[AgentOptions] = None,
        send_opts: Optional[SendOptions] = None,
    ) -> Run:
        agent = self.agent_create((options.name if options else None), options)
        return agent.send(prompt, send_opts or SendOptions())


class _RepositoriesNamespace:
    def __init__(self, cursor: Cursor) -> None:
        self._cursor = cursor

    def list(self) -> List[CursorRepository]:
        out = self._cursor._req("GET", "/v1/repositories") or {}
        rows = out.get("repositories", [])
        return [
            CursorRepository(
                id=r["id"],
                full_name=r.get("full_name", ""),
                default_branch=r.get("default_branch", "main"),
                private=r.get("private"),
            )
            for r in rows
        ]


class _AgentMessagesNamespace:
    def __init__(self, cursor: Cursor) -> None:
        self._cursor = cursor

    def list(
        self,
        agent_id: str,
        *,
        limit: Optional[int] = None,
        before: Optional[str] = None,
    ) -> List[CursorAgentMessage]:
        params: List[str] = []
        if limit:
            params.append(f"limit={limit}")
        if before:
            params.append(f"before={before}")
        q = "?" + "&".join(params) if params else ""
        out = self._cursor._req("GET", f"/v1/agents/{agent_id}/messages{q}") or {}
        rows = out.get("messages", [])
        return [
            CursorAgentMessage(
                id=r["id"],
                agent_id=r.get("agent_id", agent_id),
                role=r.get("role", "assistant"),
                content=r.get("content", ""),
                created_at=r.get("created_at", ""),
            )
            for r in rows
        ]


class _AgentsNamespace:
    def __init__(self, cursor: Cursor) -> None:
        self._cursor = cursor
        self.messages = _AgentMessagesNamespace(cursor)

    def list(
        self,
        *,
        limit: Optional[int] = None,
        include_archived: bool = False,
    ) -> List[CursorAgentRecord]:
        params: List[str] = []
        if limit:
            params.append(f"limit={limit}")
        if include_archived:
            params.append("include_archived=true")
        q = "?" + "&".join(params) if params else ""
        out = self._cursor._req("GET", f"/v1/agents{q}") or {}
        rows = out.get("agents", [])
        return [
            CursorAgentRecord(
                id=r["id"],
                name=r.get("name"),
                archived=r.get("archived"),
                created_at=r.get("created_at"),
                updated_at=r.get("updated_at"),
                metadata=r.get("metadata"),
            )
            for r in rows
        ]

    def get(self, agent_id: str) -> CursorAgentRecord:
        d = self._cursor._req("GET", f"/v1/agents/{agent_id}") or {}
        return CursorAgentRecord(
            id=d.get("id", agent_id),
            name=d.get("name"),
            archived=d.get("archived"),
            created_at=d.get("created_at"),
            updated_at=d.get("updated_at"),
            metadata=d.get("metadata"),
        )

    def archive(self, agent_id: str) -> None:
        self._cursor._req("POST", f"/v1/agents/{agent_id}/archive")

    def unarchive(self, agent_id: str) -> None:
        self._cursor._req("POST", f"/v1/agents/{agent_id}/unarchive")

    def delete(self, agent_id: str) -> None:
        self._cursor._req("DELETE", f"/v1/agents/{agent_id}")

    def list_runs(self, agent_id: str, *, limit: Optional[int] = None) -> List[CursorRunSummary]:
        q = f"?limit={limit}" if limit else ""
        out = self._cursor._req("GET", f"/v1/agents/{agent_id}/runs{q}") or {}
        rows = out.get("runs", [])
        return [
            CursorRunSummary(
                run_id=r["run_id"],
                agent_id=r.get("agent_id", agent_id),
                status=r.get("status", "running"),
                started_at=r.get("started_at", ""),
                ended_at=r.get("ended_at"),
            )
            for r in rows
        ]

    def get_run(self, agent_id: str, run_id: str) -> CursorRunSummary:
        r = self._cursor._req("GET", f"/v1/agents/{agent_id}/runs/{run_id}") or {}
        return CursorRunSummary(
            run_id=r.get("run_id", run_id),
            agent_id=r.get("agent_id", agent_id),
            status=r.get("status", "running"),
            started_at=r.get("started_at", ""),
            ended_at=r.get("ended_at"),
        )

    def cancel_run(self, agent_id: str, run_id: str) -> None:
        self._cursor._req("POST", f"/v1/agents/{agent_id}/runs/{run_id}/cancel")

    def list_artifacts(self, agent_id: str, run_id: str) -> List[CursorAgentArtifact]:
        out = self._cursor._req("GET", f"/v1/agents/{agent_id}/runs/{run_id}/artifacts") or {}
        rows = out.get("artifacts", [])
        return [
            CursorAgentArtifact(
                id=r["id"],
                name=r.get("name", ""),
                content_type=r.get("content_type", "application/octet-stream"),
                size_bytes=r.get("size_bytes"),
                download_url=r.get("download_url"),
            )
            for r in rows
        ]

    def download_artifact(self, agent_id: str, run_id: str, artifact_id: str) -> bytes:
        req = urllib.request.Request(
            f"{self._cursor.base_url}/v1/agents/{agent_id}/runs/{run_id}/artifacts/{artifact_id}",
            headers=self._cursor._headers(),
        )
        with urllib.request.urlopen(req) as res:
            return res.read()


__all__ = [
    "Cursor",
    "CursorAgentPlatform",
    "NoopCursorAgentPlatform",
    "CursorAccount",
    "CursorRepository",
    "CursorAgentRecord",
    "CursorAgentMessage",
    "CursorRunSummary",
    "CursorAgentArtifact",
    "IntegrationNotConnectedError",
]
