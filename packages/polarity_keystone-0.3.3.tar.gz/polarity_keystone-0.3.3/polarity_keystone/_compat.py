"""Cross-name compatibility helpers.

The SDK is rebranding from "Keystone" to "Polarity". Every client-facing
env var, default URL, and import name has a new "Polarity" form while the
legacy "Keystone" form continues to work indefinitely.

Call sites should route env-var reads through :func:`get_env` so both
names resolve, with the new name winning when both are set.
"""

from __future__ import annotations

import os
from typing import Optional


DEFAULT_BASE_URL = "https://api.plr.sh"
LEGACY_BASE_URL = "https://keystone.polarity.so"


def get_env(new_name: str, old_name: str, default: Optional[str] = None) -> Optional[str]:
    """Read an env var, preferring the new Polarity-branded name.

    Falls back to the legacy Keystone-branded name. Returns ``default``
    if neither is set.

    Example::

        api_key = get_env("POLARITY_API_KEY", "KEYSTONE_API_KEY")
    """
    return os.environ.get(new_name) or os.environ.get(old_name) or default
