"""Local agent harness — full Cursor-style loop in async Python.

Mirrors ``apps/keystone/sdks/typescript/src/harness/harness.ts``. Runs
in the consumer's process: BYOK LLM call, 14 built-ins + custom tools,
MCP servers, compaction. Emits SDKMessage-shaped dicts over an asyncio
queue that callers can consume via ``async for msg in run.stream()``.
"""
from __future__ import annotations

import asyncio
import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set

from .providers import (
    ProviderMessage, ProviderRequest, ProviderToolSpec, send, unprefix_model,
)
from .builtin_tools import (
    ToolDefinition, ToolContext, new_tool_context, default_tools,
    summarize_tool_result,
)
from .compaction import CompactionOptions, should_compact, compact_conversation
from .mcp_client import (
    MCPClient, create_mcp_clients, close_mcp_clients, resolve_mcp_tool_ref,
)


@dataclass
class SDKArtifact:
    """A file created or modified by an agent run."""
    path: str
    size_bytes: int
    updated_at: str  # ISO-8601


@dataclass
class LocalAgentOptions:
    model: str
    api_key: str
    base_url: Optional[str] = None
    working_dir: Optional[str] = None
    mcp_servers: Optional[Dict[str, Dict[str, Any]]] = None
    custom_tools: Optional[List[ToolDefinition]] = None
    enabled_builtins: Optional[List[str]] = None
    override_tools: Optional[List[ToolDefinition]] = None
    compaction: Optional[CompactionOptions] = None
    system_prompt: Optional[str] = None
    max_tool_rounds: int = 20
    max_tokens: int = 8192
    temperature: float = 0.4
    name: Optional[str] = None
    agent_id: Optional[str] = None


@dataclass
class LocalSendOptions:
    model: Optional[str] = None
    mcp_servers: Optional[Dict[str, Dict[str, Any]]] = None
    custom_tools: Optional[List[ToolDefinition]] = None
    cancel_event: Optional[asyncio.Event] = None
    idempotency_key: Optional[str] = None


class LocalRun:
    def __init__(self, run_id: str, agent_id: str, model_id: str, agent: "LocalAgent") -> None:
        self.id = run_id
        self.agent_id = agent_id
        self.model_id = model_id
        self.status = "running"
        self.result: Optional[Dict[str, Any]] = None
        self._events: List[Dict[str, Any]] = []
        self._listeners: List[asyncio.Future] = []
        self._done_event = asyncio.Event()
        self._cancel_event = asyncio.Event()
        self._task: Optional[asyncio.Task] = None
        self._agent = agent
        self._artifact_paths: Set[str] = set()

    def _emit(self, msg: Dict[str, Any]) -> None:
        self._events.append(msg)
        for fut in self._listeners:
            if not fut.done():
                fut.set_result(None)
        self._listeners.clear()

    def _mark_done(self, status: str, result: Optional[Dict[str, Any]]) -> None:
        self.status = status
        self.result = result
        self._done_event.set()

    async def stream(self):
        """Async iterator over SDKMessage events emitted by this run."""
        idx = 0
        while True:
            while idx < len(self._events):
                yield self._events[idx]
                idx += 1
            if self.status != "running":
                return
            fut: asyncio.Future = asyncio.get_event_loop().create_future()
            self._listeners.append(fut)
            try:
                await asyncio.wait_for(fut, timeout=60.0)
            except asyncio.TimeoutError:
                continue

    async def wait(self) -> Dict[str, Any]:
        await self._done_event.wait()
        if self._task:
            try:
                await self._task
            except Exception:
                pass
        if self.result:
            return self.result
        return {"id": self.id, "status": self.status, "model": {"id": self.model_id}}

    async def cancel(self) -> None:
        self._cancel_event.set()

    async def list_artifacts(self) -> List[SDKArtifact]:
        """Return file artifacts this run wrote/edited (deletes excluded)."""
        return await self._agent._stat_artifacts(self._artifact_paths)

    async def download_artifact(self, path: str) -> bytes:
        """Read the bytes of an artifact this run produced."""
        if path not in self._artifact_paths:
            known = ", ".join(sorted(self._artifact_paths)) or "(none)"
            raise FileNotFoundError(f'No artifact at path {path!r} for this run. Known: {known}')
        return await self._agent._read_artifact(path)


class LocalAgent:
    def __init__(self, options: LocalAgentOptions) -> None:
        self.options = options
        self.agent_id = options.agent_id or f"la-{uuid.uuid4()}"
        self.model = {"id": options.model}
        self._history: List[ProviderMessage] = []
        self._mcp_clients: Dict[str, MCPClient] = {}
        self._mcp_lock = asyncio.Lock()
        self._tool_ctx: ToolContext = new_tool_context(options.working_dir)
        if options.system_prompt:
            self._history.append(ProviderMessage(role="system", content=options.system_prompt))
        self._closed = False
        self._artifact_paths: Set[str] = set()

    def _resolve_artifact_path(self, rel: str) -> str:
        return rel if os.path.isabs(rel) else os.path.join(self._tool_ctx.working_dir, rel)

    async def _stat_artifacts(self, paths) -> List[SDKArtifact]:
        out: List[SDKArtifact] = []
        for rel in paths:
            full = self._resolve_artifact_path(rel)
            try:
                st = os.stat(full)
                if not os.path.isfile(full):
                    continue
                out.append(SDKArtifact(
                    path=rel,
                    size_bytes=st.st_size,
                    updated_at=datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
                ))
            except FileNotFoundError:
                continue
        out.sort(key=lambda a: a.path)
        return out

    async def _read_artifact(self, rel: str) -> bytes:
        with open(self._resolve_artifact_path(rel), "rb") as f:
            return f.read()

    async def list_artifacts(self) -> List[SDKArtifact]:
        """Cumulative artifacts across all runs of this agent."""
        return await self._stat_artifacts(self._artifact_paths)

    async def download_artifact(self, path: str) -> bytes:
        if path not in self._artifact_paths:
            known = ", ".join(sorted(self._artifact_paths)) or "(none)"
            raise FileNotFoundError(f'No artifact at path {path!r} for this agent. Known: {known}')
        return await self._read_artifact(path)

    def _record_artifact(self, tool_name: str, args: Any, ok: bool, run: LocalRun) -> Optional[str]:
        if not ok or not isinstance(args, dict):
            return None
        rel = args.get("path")
        if not isinstance(rel, str):
            return None
        if tool_name in ("write", "edit"):
            self._artifact_paths.add(rel)
            run._artifact_paths.add(rel)
            return rel
        if tool_name == "delete":
            self._artifact_paths.discard(rel)
            run._artifact_paths.discard(rel)
            return rel
        return None

    async def _ensure_mcp(self, extra: Optional[Dict[str, Dict[str, Any]]]) -> Dict[str, MCPClient]:
        merged = {**(self.options.mcp_servers or {}), **(extra or {})}
        if not merged:
            return {}
        async with self._mcp_lock:
            if not self._mcp_clients:
                self._mcp_clients = await create_mcp_clients(merged)
                clients = self._mcp_clients

                async def dispatch(alias: str, tool: str, args: Dict[str, Any]) -> Any:
                    c = clients.get(alias)
                    if not c:
                        raise RuntimeError(f'MCP server "{alias}" not initialized')
                    return await c.call_tool(tool, args)

                self._tool_ctx.mcp_dispatch = dispatch
        return self._mcp_clients

    def _build_tools(self, opts: LocalSendOptions, mcp: Dict[str, MCPClient]):
        overrides = list(self.options.override_tools or [])
        override_names = {t.name for t in overrides}
        builtins = []
        for t in default_tools():
            if self.options.enabled_builtins and t.name not in self.options.enabled_builtins:
                continue
            if t.name in override_names:
                continue
            builtins.append(t)
        custom = list((self.options.custom_tools or []) + (opts.custom_tools or []))
        custom_names = {t.name for t in custom}
        tools = [
            *overrides,
            *[t for t in builtins if t.name not in custom_names],
            *custom,
        ]
        specs = [ProviderToolSpec(t.name, t.description, t.input_schema) for t in tools]
        for client in mcp.values():
            for t in client.tools():
                specs.append(ProviderToolSpec(
                    name=f"{client.alias}__{t.name}",
                    description=t.description or f"(MCP tool from {client.alias})",
                    input_schema=t.input_schema or {"type": "object"},
                ))
        return tools, specs

    def send(self, message, options: Optional[LocalSendOptions] = None) -> LocalRun:
        """Send a user turn. `message` may be a plain string OR a dict
        shaped like Cursor's SDKUserMessage:
            {"text": "...", "images": [{"data": "<base64>", "mimeType": "image/png"}]}
        """
        opts = options or LocalSendOptions()
        run_id = f"lr-{uuid.uuid4()}"
        model_id = opts.model or self.options.model
        run = LocalRun(run_id, self.agent_id, model_id, self)

        # Normalize the user-turn content. Plain string → text. SDKUserMessage
        # with images → multimodal parts so vision-capable models see them.
        user_parts = []
        user_text = ""
        if isinstance(message, str):
            user_text = message
            user_parts.append({"type": "text", "text": message})
        elif isinstance(message, dict):
            user_text = message.get("text", "")
            if user_text:
                user_parts.append({"type": "text", "text": user_text})
            for img in message.get("images", []) or []:
                if isinstance(img, dict) and img.get("data") and img.get("mimeType"):
                    user_parts.append({"type": "image", "mimeType": img["mimeType"], "data": img["data"]})
                elif isinstance(img, dict) and isinstance(img.get("url"), str):
                    import re as _re
                    m = _re.match(r"^data:([^;]+);base64,(.*)$", img["url"])
                    if m:
                        user_parts.append({"type": "image", "mimeType": m.group(1), "data": m.group(2)})
        else:
            user_text = str(message)
            user_parts.append({"type": "text", "text": user_text})

        if len(user_parts) > 1 or any(p["type"] == "image" for p in user_parts):
            self._history.append(ProviderMessage(role="user", content=user_parts))
        else:
            self._history.append(ProviderMessage(role="user", content=user_text))

        async def loop() -> None:
            try:
                run._emit({"type": "status", "agent_id": self.agent_id, "run_id": run_id, "status": "CREATING"})
                mcp = await self._ensure_mcp(opts.mcp_servers)
                tools, specs = self._build_tools(opts, mcp)
                run._emit({"type": "system", "subtype": "init", "agent_id": self.agent_id, "run_id": run_id, "model": {"id": model_id}, "tools": [s.name for s in specs]})
                run._emit({"type": "status", "agent_id": self.agent_id, "run_id": run_id, "status": "RUNNING"})
                run._emit({"type": "user", "agent_id": self.agent_id, "run_id": run_id, "message": {"role": "user", "content": [{"type": "text", "text": user_text}]}})

                compaction_opts = self.options.compaction
                compaction_enabled = compaction_opts is not None and getattr(compaction_opts, "enabled", True)

                for _ in range(self.options.max_tool_rounds):
                    if run._cancel_event.is_set():
                        raise asyncio.CancelledError()

                    if compaction_enabled:
                        decision = should_compact(self._history, model_id, compaction_opts)
                        if decision.should_compact:
                            run._emit({"type": "task", "agent_id": self.agent_id, "run_id": run_id, "status": "compacting", "text": f"compacting older context ({decision.used_tokens}/{decision.context_window} tokens)"})
                            new_msgs, _, saved = await compact_conversation(self._history, model_id, self.options.api_key, compaction_opts)
                            self._history = new_msgs
                            run._emit({"type": "task", "agent_id": self.agent_id, "run_id": run_id, "status": "compacted", "text": f"saved ~{saved} tokens"})

                    response = await send(ProviderRequest(
                        model=model_id,
                        api_key=self.options.api_key,
                        base_url=self.options.base_url,
                        messages=self._history,
                        tools=specs,
                        max_tokens=self.options.max_tokens,
                        temperature=self.options.temperature,
                    ))

                    content: List[Dict[str, Any]] = []
                    if response.text:
                        content.append({"type": "text", "text": response.text})
                    for tc in response.tool_calls:
                        content.append({"type": "tool_use", "id": tc.id, "name": tc.name, "input": tc.input})
                    run._emit({"type": "assistant", "agent_id": self.agent_id, "run_id": run_id, "message": {"role": "assistant", "content": content}})

                    self._history.append(ProviderMessage(
                        role="assistant",
                        content=response.text,
                        tool_calls=[{"id": tc.id, "name": tc.name, "input": tc.input} for tc in response.tool_calls],
                    ))

                    if not response.tool_calls:
                        run._mark_done("finished", {
                            "id": run_id, "status": "finished",
                            "result": response.text, "model": {"id": model_id},
                        })
                        run._emit({"type": "status", "agent_id": self.agent_id, "run_id": run_id, "status": "FINISHED"})
                        return

                    for call in response.tool_calls:
                        run._emit({"type": "tool_call", "agent_id": self.agent_id, "run_id": run_id, "call_id": call.id, "name": call.name, "status": "running", "args": call.input})
                        try:
                            mcp_ref = resolve_mcp_tool_ref(mcp, call.name)
                            if mcp_ref:
                                client: MCPClient = mcp_ref["client"]
                                bare = mcp_ref["tool"]
                                out = await client.call_tool(bare, dict(call.input or {}))
                                tool_output: Any = {"content": out.content, "structuredContent": out.structured_content, "isError": out.is_error}
                            else:
                                tool_def = next((t for t in tools if t.name == call.name), None)
                                if not tool_def:
                                    raise RuntimeError(f"unknown tool: {call.name}")
                                tool_output = await tool_def.handler(dict(call.input or {}), self._tool_ctx)
                            run._emit({"type": "tool_call", "agent_id": self.agent_id, "run_id": run_id, "call_id": call.id, "name": call.name, "status": "completed", "args": call.input, "result": tool_output})
                            successful = isinstance(tool_output, dict) and "success" in tool_output
                            rel = self._record_artifact(call.name, call.input, successful, run)
                            if rel and call.name in ("write", "edit"):
                                run._emit({"type": "task", "agent_id": self.agent_id, "run_id": run_id, "status": "artifact", "text": rel})
                        except Exception as e:
                            tool_output = {"error": {"message": str(e)}}
                            run._emit({"type": "tool_call", "agent_id": self.agent_id, "run_id": run_id, "call_id": call.id, "name": call.name, "status": "error", "args": call.input, "result": tool_output})
                        # If the tool returned an image (read on a PNG/JPG),
                        # feed it back to the model as multimodal parts so
                        # vision-capable models can actually see it.
                        image_part = _extract_image_from_tool_output(tool_output)
                        if image_part is not None:
                            self._history.append(ProviderMessage(
                                role="tool",
                                content=[
                                    {"type": "text", "text": f"[image: {image_part['mimeType']}]"},
                                    image_part,
                                ],
                                tool_call_id=call.id,
                            ))
                        else:
                            self._history.append(ProviderMessage(
                                role="tool",
                                content=summarize_tool_result(call.name, tool_output),
                                tool_call_id=call.id,
                            ))

                # Loop exhausted
                run._mark_done("finished", {
                    "id": run_id, "status": "finished",
                    "result": self._history[-1].content if self._history else None,
                    "model": {"id": model_id},
                })
                run._emit({"type": "status", "agent_id": self.agent_id, "run_id": run_id, "status": "FINISHED", "message": "max tool rounds reached"})

            except asyncio.CancelledError:
                run._mark_done("cancelled", {"id": run_id, "status": "cancelled", "model": {"id": model_id}})
                run._emit({"type": "status", "agent_id": self.agent_id, "run_id": run_id, "status": "CANCELLED"})
            except Exception as e:
                run._mark_done("error", {"id": run_id, "status": "error", "result": str(e), "model": {"id": model_id}})
                run._emit({"type": "status", "agent_id": self.agent_id, "run_id": run_id, "status": "ERROR", "message": str(e)})

        run._task = asyncio.create_task(loop())
        return run

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        await close_mcp_clients(self._mcp_clients)


def create_local_agent(options: LocalAgentOptions) -> LocalAgent:
    return LocalAgent(options)


async def prompt_local_agent(message, options: LocalAgentOptions) -> Dict[str, Any]:
    """One-shot convenience: create + send + wait + close. `message`
    can be a string or an SDKUserMessage-shaped dict."""
    agent = create_local_agent(options)
    try:
        run = agent.send(message)
        return await run.wait()
    finally:
        await agent.close()


def _extract_image_from_tool_output(out: Any) -> Optional[Dict[str, Any]]:
    """If the tool returned an image (read on a PNG/JPG/etc.), return
    the corresponding ContentPart so the harness can feed it back to
    the model as multimodal content. Otherwise None."""
    if not isinstance(out, dict):
        return None
    success = out.get("success")
    if not isinstance(success, dict):
        return None
    if success.get("kind") != "image":
        return None
    mime = success.get("mimeType")
    data = success.get("data")
    if not isinstance(mime, str) or not isinstance(data, str):
        return None
    return {"type": "image", "mimeType": mime, "data": data}
