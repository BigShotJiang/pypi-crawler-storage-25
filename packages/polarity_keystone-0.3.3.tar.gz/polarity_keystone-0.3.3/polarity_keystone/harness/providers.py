"""BYOK provider adapter for the Python harness.

Single send() interface that routes prefixed model ids to 15 providers
via their native wire protocols. Mirrors the TypeScript SDK's
``harness/providers.ts``.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Literal, Optional

try:
    import httpx
except ImportError as _httpx_err:  # pragma: no cover
    httpx = None  # type: ignore[assignment]
    _HTTPX_ERR = _httpx_err
else:
    _HTTPX_ERR = None


def _require_httpx() -> None:
    if httpx is None:
        raise RuntimeError(
            "The polarity-keystone harness needs httpx — install with "
            "`pip install httpx` (or `pip install polarity-keystone[harness]`)."
        )


ProviderKind = Literal[
    "openai", "anthropic", "gemini", "groq", "together_ai",
    "openrouter", "mistral", "deepseek", "xai", "ollama",
    "huggingface", "bedrock", "vertex_ai", "cohere", "perplexity",
]


ContentPart = Dict[str, Any]
"""A single content part within a message. Either {'type':'text','text': str}
or {'type':'image','mimeType': str,'data': str (base64)}."""


@dataclass
class ProviderMessage:
    role: Literal["system", "user", "assistant", "tool"]
    content: Any  # str | List[ContentPart]
    tool_calls: Optional[List[Dict[str, Any]]] = None  # [{id, name, input}]
    tool_call_id: Optional[str] = None


def _parts(content: Any) -> List[ContentPart]:
    if isinstance(content, str):
        return [{"type": "text", "text": content}] if content else []
    return content or []


def _parts_to_text(parts: List[ContentPart]) -> str:
    return "".join(p.get("text", "") for p in parts if p.get("type") == "text")


def detect_image_mime(path: str) -> Optional[str]:
    """Return MIME type for image files by extension, or None."""
    ext = path.lower().rsplit(".", 1)[-1] if "." in path else ""
    return {
        "png": "image/png",
        "jpg": "image/jpeg", "jpeg": "image/jpeg",
        "gif": "image/gif", "webp": "image/webp", "bmp": "image/bmp",
    }.get(ext)


@dataclass
class ProviderToolSpec:
    name: str
    description: str
    input_schema: Dict[str, Any]


@dataclass
class ProviderToolCall:
    id: str
    name: str
    input: Any


@dataclass
class ProviderUsage:
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    total_tokens: Optional[int] = None


@dataclass
class ProviderRequest:
    model: str
    api_key: str
    messages: List[ProviderMessage]
    tools: Optional[List[ProviderToolSpec]] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    stream: bool = False
    base_url: Optional[str] = None
    headers: Optional[Dict[str, str]] = None


@dataclass
class ProviderResponse:
    text: str = ""
    tool_calls: List[ProviderToolCall] = field(default_factory=list)
    finish_reason: Optional[str] = None
    usage: Optional[ProviderUsage] = None
    raw: Any = None


@dataclass
class ProviderStreamEvent:
    text_delta: Optional[str] = None
    tool_call_delta: Optional[Dict[str, Any]] = None
    thinking_delta: Optional[str] = None
    finish_reason: Optional[str] = None
    usage: Optional[ProviderUsage] = None


# ─── Provider catalog ──────────────────────────────────────────────

@dataclass
class _Cfg:
    kind: ProviderKind
    protocol: Literal["openai", "anthropic", "gemini", "cohere"]
    default_base_url: str
    auth_header: str
    auth_prefix: str = ""
    default_headers: Optional[Dict[str, str]] = None


_PROVIDERS: Dict[ProviderKind, _Cfg] = {
    "openai": _Cfg("openai", "openai", "https://api.openai.com/v1", "Authorization", "Bearer "),
    "anthropic": _Cfg("anthropic", "anthropic", "https://api.anthropic.com/v1", "x-api-key", "", {"anthropic-version": "2023-06-01"}),
    "gemini": _Cfg("gemini", "gemini", "https://generativelanguage.googleapis.com/v1beta", "x-goog-api-key"),
    "groq": _Cfg("groq", "openai", "https://api.groq.com/openai/v1", "Authorization", "Bearer "),
    "together_ai": _Cfg("together_ai", "openai", "https://api.together.xyz/v1", "Authorization", "Bearer "),
    "openrouter": _Cfg("openrouter", "openai", "https://openrouter.ai/api/v1", "Authorization", "Bearer ",
                       {"HTTP-Referer": "https://polarity.so", "X-Title": "Polarity Keystone"}),
    "mistral": _Cfg("mistral", "openai", "https://api.mistral.ai/v1", "Authorization", "Bearer "),
    "deepseek": _Cfg("deepseek", "openai", "https://api.deepseek.com/v1", "Authorization", "Bearer "),
    "xai": _Cfg("xai", "openai", "https://api.x.ai/v1", "Authorization", "Bearer "),
    "ollama": _Cfg("ollama", "openai", "http://localhost:11434/v1", "Authorization", "Bearer "),
    "huggingface": _Cfg("huggingface", "openai", "https://api-inference.huggingface.co/v1", "Authorization", "Bearer "),
    "bedrock": _Cfg("bedrock", "openai", "https://bedrock-runtime.us-east-1.amazonaws.com", "Authorization", "Bearer "),
    "vertex_ai": _Cfg("vertex_ai", "gemini", "https://us-central1-aiplatform.googleapis.com/v1", "Authorization", "Bearer "),
    "cohere": _Cfg("cohere", "cohere", "https://api.cohere.com/v2", "Authorization", "Bearer "),
    "perplexity": _Cfg("perplexity", "openai", "https://api.perplexity.ai", "Authorization", "Bearer "),
}


def unprefix_model(model_id: str) -> Dict[str, str]:
    """Return {'provider': ..., 'model': ...} from a prefixed model id."""
    if "/" not in model_id:
        return {"provider": "openai", "model": model_id}
    prefix, tail = model_id.split("/", 1)
    if prefix not in _PROVIDERS:
        raise ValueError(f'Unknown provider prefix "{prefix}" in model id "{model_id}". '
                         f'Known: {", ".join(_PROVIDERS.keys())}')
    return {"provider": prefix, "model": tail}


_REASONING_RE = re.compile(r"^(gpt-5|o[1-9](?:-|$)|o-mini|o3|o4-)", re.IGNORECASE)


def is_reasoning_model(model: str) -> bool:
    return bool(_REASONING_RE.match(model))


# ─── Dispatch ──────────────────────────────────────────────────────

async def send(req: ProviderRequest) -> ProviderResponse:
    parsed = unprefix_model(req.model)
    cfg = _PROVIDERS[parsed["provider"]]  # type: ignore[index]
    model = parsed["model"]
    if cfg.protocol == "openai":
        return await _send_openai(cfg, model, req)
    if cfg.protocol == "anthropic":
        return await _send_anthropic(cfg, model, req)
    if cfg.protocol == "gemini":
        return await _send_gemini(cfg, model, req, vertex=parsed["provider"] == "vertex_ai")
    if cfg.protocol == "cohere":
        return await _send_cohere(cfg, model, req)
    raise RuntimeError(f"unknown protocol {cfg.protocol}")


async def send_stream(req: ProviderRequest) -> AsyncIterator[ProviderStreamEvent]:
    parsed = unprefix_model(req.model)
    cfg = _PROVIDERS[parsed["provider"]]  # type: ignore[index]
    model = parsed["model"]
    if cfg.protocol == "openai":
        async for ev in _send_openai_stream(cfg, model, req):
            yield ev
    elif cfg.protocol == "anthropic":
        async for ev in _send_anthropic_stream(cfg, model, req):
            yield ev
    elif cfg.protocol == "gemini":
        async for ev in _send_gemini_stream(cfg, model, req, vertex=parsed["provider"] == "vertex_ai"):
            yield ev
    elif cfg.protocol == "cohere":
        resp = await _send_cohere(cfg, model, req)
        if resp.text:
            yield ProviderStreamEvent(text_delta=resp.text)


def _headers(cfg: _Cfg, api_key: str, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    out = {"Content-Type": "application/json", cfg.auth_header: f"{cfg.auth_prefix}{api_key}"}
    if cfg.default_headers:
        out.update(cfg.default_headers)
    if extra:
        out.update(extra)
    return out


def _openai_tools(tools: Optional[List[ProviderToolSpec]]):
    if not tools:
        return None
    return [{"type": "function", "function": {"name": t.name, "description": t.description, "parameters": t.input_schema}} for t in tools]


def _openai_content(content: Any) -> Any:
    if isinstance(content, str):
        return content
    parts_out = []
    for p in content or []:
        if p.get("type") == "text":
            parts_out.append({"type": "text", "text": p["text"]})
        else:
            parts_out.append({
                "type": "image_url",
                "image_url": {"url": f"data:{p['mimeType']};base64,{p['data']}"},
            })
    return parts_out


def _openai_messages(messages: List[ProviderMessage]):
    out = []
    for m in messages:
        if m.role == "tool":
            body = m.content if isinstance(m.content, str) else (_parts_to_text(m.content) or "[tool returned non-text content]")
            out.append({"role": "tool", "tool_call_id": m.tool_call_id, "content": body})
            continue
        if m.tool_calls:
            content_out = (m.content or None) if isinstance(m.content, str) else _openai_content(m.content)
            out.append({
                "role": m.role,
                "content": content_out,
                "tool_calls": [{
                    "id": c["id"], "type": "function",
                    "function": {"name": c["name"], "arguments": json.dumps(c.get("input") or {})},
                } for c in m.tool_calls],
            })
            continue
        out.append({"role": m.role, "content": _openai_content(m.content)})
    return out


# ─── OpenAI-compatible ─────────────────────────────────────────────

async def _send_openai(cfg: _Cfg, model: str, req: ProviderRequest) -> ProviderResponse:
    base = (req.base_url or cfg.default_base_url).rstrip("/")
    reasoning = is_reasoning_model(model)
    body: Dict[str, Any] = {
        "model": model,
        "messages": _openai_messages(req.messages),
        "tools": _openai_tools(req.tools),
    }
    if reasoning:
        if req.max_tokens:
            body["max_completion_tokens"] = req.max_tokens
    else:
        if req.max_tokens:
            body["max_tokens"] = req.max_tokens
        if req.temperature is not None:
            body["temperature"] = req.temperature
    _require_httpx()
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as cli:
        res = await cli.post(f"{base}/chat/completions", headers=_headers(cfg, req.api_key, req.headers), json=body)
    if res.status_code >= 400:
        raise RuntimeError(f"{cfg.kind} chat → {res.status_code}: {res.text[:400]}")
    data = res.json()
    choice = data["choices"][0]
    msg = choice["message"]
    tool_calls = []
    for c in msg.get("tool_calls") or []:
        try:
            inp = json.loads(c["function"]["arguments"] or "{}")
        except Exception:
            inp = {}
        tool_calls.append(ProviderToolCall(id=c["id"], name=c["function"]["name"], input=inp))
    usage = data.get("usage") or {}
    return ProviderResponse(
        text=msg.get("content") or "",
        tool_calls=tool_calls,
        finish_reason=choice.get("finish_reason"),
        usage=ProviderUsage(
            prompt_tokens=usage.get("prompt_tokens"),
            completion_tokens=usage.get("completion_tokens"),
            total_tokens=usage.get("total_tokens"),
        ) if usage else None,
        raw=data,
    )


async def _send_openai_stream(cfg: _Cfg, model: str, req: ProviderRequest) -> AsyncIterator[ProviderStreamEvent]:
    base = (req.base_url or cfg.default_base_url).rstrip("/")
    reasoning = is_reasoning_model(model)
    body: Dict[str, Any] = {
        "model": model,
        "messages": _openai_messages(req.messages),
        "tools": _openai_tools(req.tools),
        "stream": True,
    }
    if reasoning:
        if req.max_tokens:
            body["max_completion_tokens"] = req.max_tokens
    else:
        if req.max_tokens:
            body["max_tokens"] = req.max_tokens
        if req.temperature is not None:
            body["temperature"] = req.temperature
    _require_httpx()
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as cli:
        async with cli.stream("POST", f"{base}/chat/completions",
                              headers=_headers(cfg, req.api_key, req.headers), json=body) as res:
            if res.status_code >= 400:
                text = await res.aread()
                raise RuntimeError(f"{cfg.kind} chat stream → {res.status_code}: {text[:400].decode('utf-8', errors='replace')}")
            async for line in res.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    return
                try:
                    evt = json.loads(payload)
                except Exception:
                    continue
                delta = (evt.get("choices") or [{}])[0].get("delta") or {}
                if delta.get("content"):
                    yield ProviderStreamEvent(text_delta=delta["content"])
                if delta.get("reasoning_content"):
                    yield ProviderStreamEvent(thinking_delta=delta["reasoning_content"])
                for tc in delta.get("tool_calls") or []:
                    yield ProviderStreamEvent(tool_call_delta={
                        "id": tc.get("id") or f"tc-{tc.get('index', 0)}",
                        "name": (tc.get("function") or {}).get("name"),
                        "input_json_delta": (tc.get("function") or {}).get("arguments"),
                    })
                if (evt.get("choices") or [{}])[0].get("finish_reason"):
                    yield ProviderStreamEvent(finish_reason=evt["choices"][0]["finish_reason"])


# ─── Anthropic ─────────────────────────────────────────────────────

def _anthropic_content(content: Any) -> List[Dict[str, Any]]:
    if isinstance(content, str):
        return [{"type": "text", "text": content}] if content else []
    out = []
    for p in content or []:
        if p.get("type") == "text":
            out.append({"type": "text", "text": p["text"]})
        else:
            out.append({
                "type": "image",
                "source": {"type": "base64", "media_type": p["mimeType"], "data": p["data"]},
            })
    return out


def _anthropic_messages(messages: List[ProviderMessage]):
    system: Optional[str] = None
    msgs: List[Dict[str, Any]] = []
    for m in messages:
        if m.role == "system":
            sys_text = m.content if isinstance(m.content, str) else _parts_to_text(m.content)
            if sys_text:
                system = (system + "\n\n" if system else "") + sys_text
            continue
        if m.role == "tool":
            inner = m.content if isinstance(m.content, str) else _anthropic_content(m.content)
            msgs.append({"role": "user", "content": [{"type": "tool_result", "tool_use_id": m.tool_call_id, "content": inner}]})
            continue
        if m.role == "assistant" and m.tool_calls:
            content = list(_anthropic_content(m.content))
            for c in m.tool_calls:
                content.append({"type": "tool_use", "id": c["id"], "name": c["name"], "input": c.get("input") or {}})
            msgs.append({"role": "assistant", "content": content})
            continue
        msgs.append({"role": m.role, "content": _anthropic_content(m.content)})
    return system, msgs


async def _send_anthropic(cfg: _Cfg, model: str, req: ProviderRequest) -> ProviderResponse:
    base = (req.base_url or cfg.default_base_url).rstrip("/")
    system, msgs = _anthropic_messages(req.messages)
    body: Dict[str, Any] = {"model": model, "max_tokens": req.max_tokens or 4096, "messages": msgs}
    if system:
        body["system"] = system
    if req.temperature is not None:
        body["temperature"] = req.temperature
    if req.tools:
        body["tools"] = [{"name": t.name, "description": t.description, "input_schema": t.input_schema} for t in req.tools]
    _require_httpx()
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as cli:
        res = await cli.post(f"{base}/messages", headers=_headers(cfg, req.api_key, req.headers), json=body)
    if res.status_code >= 400:
        raise RuntimeError(f"anthropic messages → {res.status_code}: {res.text[:400]}")
    data = res.json()
    text = ""
    tool_calls = []
    for block in data.get("content") or []:
        if block.get("type") == "text":
            text += block.get("text", "")
        elif block.get("type") == "tool_use":
            tool_calls.append(ProviderToolCall(id=block["id"], name=block["name"], input=block.get("input") or {}))
    usage = data.get("usage") or {}
    return ProviderResponse(
        text=text,
        tool_calls=tool_calls,
        finish_reason=data.get("stop_reason"),
        usage=ProviderUsage(
            prompt_tokens=usage.get("input_tokens"),
            completion_tokens=usage.get("output_tokens"),
            total_tokens=(usage.get("input_tokens") or 0) + (usage.get("output_tokens") or 0),
        ) if usage else None,
        raw=data,
    )


async def _send_anthropic_stream(cfg: _Cfg, model: str, req: ProviderRequest) -> AsyncIterator[ProviderStreamEvent]:
    base = (req.base_url or cfg.default_base_url).rstrip("/")
    system, msgs = _anthropic_messages(req.messages)
    body: Dict[str, Any] = {"model": model, "max_tokens": req.max_tokens or 4096, "messages": msgs, "stream": True}
    if system:
        body["system"] = system
    if req.temperature is not None:
        body["temperature"] = req.temperature
    if req.tools:
        body["tools"] = [{"name": t.name, "description": t.description, "input_schema": t.input_schema} for t in req.tools]
    _require_httpx()
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as cli:
        async with cli.stream("POST", f"{base}/messages",
                              headers=_headers(cfg, req.api_key, req.headers), json=body) as res:
            if res.status_code >= 400:
                text = await res.aread()
                raise RuntimeError(f"anthropic stream → {res.status_code}: {text[:400].decode('utf-8', errors='replace')}")
            tool_bufs: Dict[int, Dict[str, str]] = {}
            async for line in res.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if not payload:
                    continue
                try:
                    evt = json.loads(payload)
                except Exception:
                    continue
                t = evt.get("type")
                if t == "content_block_start" and (evt.get("content_block") or {}).get("type") == "tool_use":
                    cb = evt["content_block"]
                    idx = evt.get("index", 0)
                    tool_bufs[idx] = {"id": cb["id"], "name": cb["name"]}
                    yield ProviderStreamEvent(tool_call_delta={"id": cb["id"], "name": cb["name"]})
                elif t == "content_block_delta":
                    d = evt.get("delta") or {}
                    if d.get("type") == "text_delta":
                        yield ProviderStreamEvent(text_delta=d.get("text", ""))
                    elif d.get("type") == "thinking_delta":
                        yield ProviderStreamEvent(thinking_delta=d.get("thinking", ""))
                    elif d.get("type") == "input_json_delta":
                        buf = tool_bufs.get(evt.get("index", 0))
                        if buf:
                            yield ProviderStreamEvent(tool_call_delta={"id": buf["id"], "input_json_delta": d.get("partial_json", "")})
                elif t == "message_delta" and evt.get("usage"):
                    u = evt["usage"]
                    yield ProviderStreamEvent(usage=ProviderUsage(
                        prompt_tokens=u.get("input_tokens"),
                        completion_tokens=u.get("output_tokens"),
                        total_tokens=(u.get("input_tokens") or 0) + (u.get("output_tokens") or 0),
                    ))
                elif t == "message_stop":
                    yield ProviderStreamEvent(finish_reason="stop")


# ─── Gemini / Vertex ────────────────────────────────────────────────

def _gemini_parts(content: Any) -> List[Dict[str, Any]]:
    if isinstance(content, str):
        return [{"text": content}] if content else []
    out = []
    for p in content or []:
        if p.get("type") == "text":
            out.append({"text": p["text"]})
        else:
            out.append({"inlineData": {"mimeType": p["mimeType"], "data": p["data"]}})
    return out


def _gemini_contents(messages: List[ProviderMessage]):
    system: Optional[str] = None
    contents: List[Dict[str, Any]] = []
    for m in messages:
        if m.role == "system":
            sys_text = m.content if isinstance(m.content, str) else _parts_to_text(m.content)
            if sys_text:
                system = (system + "\n\n" if system else "") + sys_text
            continue
        if m.role == "tool":
            result_text = m.content if isinstance(m.content, str) else _parts_to_text(m.content)
            contents.append({"role": "user", "parts": [{"functionResponse": {"name": m.tool_call_id or "tool", "response": {"result": result_text}}}]})
            continue
        role = "model" if m.role == "assistant" else "user"
        parts = _gemini_parts(m.content)
        for c in m.tool_calls or []:
            parts.append({"functionCall": {"name": c["name"], "args": c.get("input") or {}}})
        contents.append({"role": role, "parts": parts})
    sys_inst = {"parts": [{"text": system}]} if system else None
    return sys_inst, contents


async def _send_gemini(cfg: _Cfg, model: str, req: ProviderRequest, *, vertex: bool) -> ProviderResponse:
    base = (req.base_url or cfg.default_base_url).rstrip("/")
    sys_inst, contents = _gemini_contents(req.messages)
    body: Dict[str, Any] = {"contents": contents, "generationConfig": {}}
    if sys_inst:
        body["systemInstruction"] = sys_inst
    if req.max_tokens:
        body["generationConfig"]["maxOutputTokens"] = req.max_tokens
    if req.temperature is not None:
        body["generationConfig"]["temperature"] = req.temperature
    if req.tools:
        body["tools"] = [{"functionDeclarations": [
            {"name": t.name, "description": t.description, "parameters": t.input_schema} for t in req.tools
        ]}]
    if vertex:
        url = f"{base}/projects/-/locations/-/publishers/google/models/{model}:generateContent"
    else:
        url = f"{base}/models/{model}:generateContent"
    _require_httpx()
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as cli:
        res = await cli.post(url, headers=_headers(cfg, req.api_key, req.headers), json=body)
    if res.status_code >= 400:
        raise RuntimeError(f"gemini → {res.status_code}: {res.text[:400]}")
    data = res.json()
    text = ""
    tool_calls = []
    for part in (data.get("candidates") or [{}])[0].get("content", {}).get("parts", []):
        if "text" in part:
            text += part["text"]
        if "functionCall" in part:
            fc = part["functionCall"]
            tool_calls.append(ProviderToolCall(id=f"gem-{len(tool_calls)}", name=fc["name"], input=fc.get("args") or {}))
    usage_meta = data.get("usageMetadata") or {}
    return ProviderResponse(
        text=text,
        tool_calls=tool_calls,
        finish_reason=(data.get("candidates") or [{}])[0].get("finishReason"),
        usage=ProviderUsage(
            prompt_tokens=usage_meta.get("promptTokenCount"),
            completion_tokens=usage_meta.get("candidatesTokenCount"),
            total_tokens=usage_meta.get("totalTokenCount"),
        ) if usage_meta else None,
        raw=data,
    )


async def _send_gemini_stream(cfg: _Cfg, model: str, req: ProviderRequest, *, vertex: bool) -> AsyncIterator[ProviderStreamEvent]:
    base = (req.base_url or cfg.default_base_url).rstrip("/")
    sys_inst, contents = _gemini_contents(req.messages)
    body: Dict[str, Any] = {"contents": contents, "generationConfig": {}}
    if sys_inst:
        body["systemInstruction"] = sys_inst
    if req.max_tokens:
        body["generationConfig"]["maxOutputTokens"] = req.max_tokens
    if req.temperature is not None:
        body["generationConfig"]["temperature"] = req.temperature
    if req.tools:
        body["tools"] = [{"functionDeclarations": [
            {"name": t.name, "description": t.description, "parameters": t.input_schema} for t in req.tools
        ]}]
    url = f"{base}/models/{model}:streamGenerateContent?alt=sse"
    if vertex:
        url = f"{base}/projects/-/locations/-/publishers/google/models/{model}:streamGenerateContent?alt=sse"
    _require_httpx()
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as cli:
        async with cli.stream("POST", url, headers=_headers(cfg, req.api_key, req.headers), json=body) as res:
            if res.status_code >= 400:
                text = await res.aread()
                raise RuntimeError(f"gemini stream → {res.status_code}: {text[:400].decode('utf-8', errors='replace')}")
            async for line in res.aiter_lines():
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                try:
                    evt = json.loads(payload)
                except Exception:
                    continue
                for part in (evt.get("candidates") or [{}])[0].get("content", {}).get("parts", []):
                    if "text" in part:
                        yield ProviderStreamEvent(text_delta=part["text"])
                    if "functionCall" in part:
                        fc = part["functionCall"]
                        yield ProviderStreamEvent(tool_call_delta={
                            "id": f"gem-{fc['name']}", "name": fc["name"],
                            "input_json_delta": json.dumps(fc.get("args") or {}),
                        })


# ─── Cohere v2 ─────────────────────────────────────────────────────

async def _send_cohere(cfg: _Cfg, model: str, req: ProviderRequest) -> ProviderResponse:
    base = (req.base_url or cfg.default_base_url).rstrip("/")
    body: Dict[str, Any] = {
        "model": model,
        "messages": _openai_messages(req.messages),
        "tools": _openai_tools(req.tools),
    }
    if req.max_tokens:
        body["max_tokens"] = req.max_tokens
    if req.temperature is not None:
        body["temperature"] = req.temperature
    _require_httpx()
    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as cli:
        res = await cli.post(f"{base}/chat", headers=_headers(cfg, req.api_key, req.headers), json=body)
    if res.status_code >= 400:
        raise RuntimeError(f"cohere chat → {res.status_code}: {res.text[:400]}")
    data = res.json()
    msg = data.get("message") or {}
    text = "".join(c.get("text", "") for c in msg.get("content") or [])
    tool_calls = []
    for c in msg.get("tool_calls") or []:
        try:
            inp = json.loads(c["function"]["arguments"] or "{}")
        except Exception:
            inp = {}
        tool_calls.append(ProviderToolCall(id=c["id"], name=c["function"]["name"], input=inp))
    u = (data.get("usage") or {}).get("tokens") or {}
    return ProviderResponse(
        text=text, tool_calls=tool_calls,
        finish_reason=data.get("finish_reason"),
        usage=ProviderUsage(
            prompt_tokens=u.get("input_tokens"),
            completion_tokens=u.get("output_tokens"),
            total_tokens=(u.get("input_tokens") or 0) + (u.get("output_tokens") or 0),
        ) if u else None,
        raw=data,
    )
