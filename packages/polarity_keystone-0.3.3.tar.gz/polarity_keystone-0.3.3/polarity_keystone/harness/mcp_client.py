"""MCP client (JSON-RPC 2.0 stdio + Streamable HTTP) for the Python harness."""
from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

try:
    import httpx
except ImportError:  # pragma: no cover
    httpx = None  # type: ignore[assignment]


PROTOCOL_VERSION = "2025-11-25"


@dataclass
class MCPTool:
    name: str
    description: Optional[str] = None
    input_schema: Optional[Dict[str, Any]] = None


@dataclass
class MCPToolResult:
    content: List[Dict[str, Any]]
    structured_content: Optional[Dict[str, Any]] = None
    is_error: Optional[bool] = None


class MCPClient:
    """Single-server JSON-RPC 2.0 MCP client (stdio + HTTP)."""

    def __init__(self, alias: str, config: Dict[str, Any]) -> None:
        self.alias = alias
        self.config = config
        self._next_id = 1
        self._pending: Dict[int, asyncio.Future] = {}
        self._proc: Optional[asyncio.subprocess.Process] = None
        self._reader_task: Optional[asyncio.Task] = None
        self._http_session_id: Optional[str] = None
        self._tools: List[MCPTool] = []
        self._initialized = False
        self._closed = False

    def tools(self) -> List[MCPTool]:
        return self._tools

    @property
    def is_http(self) -> bool:
        return "url" in self.config

    async def initialize(self) -> None:
        if self._initialized:
            return
        if not self.is_http:
            await self._start_stdio()
        await self._request("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "clientInfo": {"name": "polarity-keystone", "version": "1.0.0"},
        })
        await self._notify("notifications/initialized", {})
        list_result = await self._request("tools/list", {}) or {}
        self._tools = [MCPTool(name=t["name"], description=t.get("description"), input_schema=t.get("inputSchema")) for t in list_result.get("tools", [])]
        self._initialized = True

    async def call_tool(self, name: str, args: Dict[str, Any]) -> MCPToolResult:
        out = await self._request("tools/call", {"name": name, "arguments": args}) or {}
        return MCPToolResult(
            content=out.get("content") or [],
            structured_content=out.get("structuredContent"),
            is_error=out.get("isError"),
        )

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        for fut in self._pending.values():
            if not fut.done():
                fut.set_exception(RuntimeError("MCP client closed"))
        self._pending.clear()
        if self._proc:
            try:
                self._proc.terminate()
            except Exception:
                pass
        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()

    # ── stdio ──────────────────────────────────────────────────

    async def _start_stdio(self) -> None:
        env = {**os.environ, **(self.config.get("env") or {})}
        self._proc = await asyncio.create_subprocess_exec(
            self.config["command"],
            *(self.config.get("args") or []),
            cwd=self.config.get("cwd"),
            env=env,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        self._reader_task = asyncio.create_task(self._read_stdout())

    async def _read_stdout(self) -> None:
        assert self._proc and self._proc.stdout
        try:
            while True:
                line = await self._proc.stdout.readline()
                if not line:
                    return
                self._handle_message(line.decode("utf-8", errors="replace").strip())
        except asyncio.CancelledError:
            return

    def _handle_message(self, line: str) -> None:
        if not line:
            return
        try:
            msg = json.loads(line)
        except Exception:
            return
        if "id" not in msg or not isinstance(msg["id"], int):
            return
        fut = self._pending.pop(msg["id"], None)
        if not fut or fut.done():
            return
        if "error" in msg:
            fut.set_exception(RuntimeError(f"MCP error {msg['error'].get('code')}: {msg['error'].get('message')}"))
        else:
            fut.set_result(msg.get("result"))

    # ── http ───────────────────────────────────────────────────

    async def _http_request(self, envelope: Dict[str, Any]) -> Any:
        if httpx is None:
            raise RuntimeError("MCP HTTP transport needs httpx — install with `pip install httpx`.")
        url = self.config["url"]
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            **(self.config.get("headers") or {}),
        }
        if self._http_session_id:
            headers["MCP-Session-Id"] = self._http_session_id
        async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as cli:
            res = await cli.post(url, headers=headers, content=json.dumps(envelope))
            if res.status_code >= 400:
                raise RuntimeError(f"MCP HTTP → {res.status_code}: {res.text[:200]}")
            sid = res.headers.get("MCP-Session-Id")
            if sid and not self._http_session_id:
                self._http_session_id = sid
            ct = res.headers.get("content-type", "")
            if "text/event-stream" in ct:
                # Streamable HTTP — parse SSE for the matching response
                async with cli.stream("POST", url, headers=headers, content=json.dumps(envelope)) as stream:
                    async for line in stream.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        payload = line[5:].strip()
                        try:
                            parsed = json.loads(payload)
                        except Exception:
                            continue
                        if "id" in envelope and parsed.get("id") == envelope["id"]:
                            if "error" in parsed:
                                raise RuntimeError(f"MCP error {parsed['error'].get('code')}: {parsed['error'].get('message')}")
                            return parsed.get("result")
                return None
            if res.status_code == 202 or res.headers.get("content-length") == "0":
                return None
            body = res.json()
            arr = body if isinstance(body, list) else [body]
            for r in arr:
                if "id" in envelope and r.get("id") == envelope["id"]:
                    if "error" in r:
                        raise RuntimeError(f"MCP error {r['error'].get('code')}: {r['error'].get('message')}")
                    return r.get("result")
            return None

    # ── transport-agnostic ─────────────────────────────────────

    async def _request(self, method: str, params: Any) -> Any:
        rid = self._next_id
        self._next_id += 1
        env = {"jsonrpc": "2.0", "id": rid, "method": method, "params": params}
        if self.is_http:
            return await self._http_request(env)
        fut: asyncio.Future = asyncio.get_event_loop().create_future()
        self._pending[rid] = fut
        assert self._proc and self._proc.stdin
        self._proc.stdin.write((json.dumps(env) + "\n").encode("utf-8"))
        await self._proc.stdin.drain()
        return await fut

    async def _notify(self, method: str, params: Any) -> None:
        env = {"jsonrpc": "2.0", "method": method, "params": params}
        if self.is_http:
            await self._http_request(env)
            return
        assert self._proc and self._proc.stdin
        self._proc.stdin.write((json.dumps(env) + "\n").encode("utf-8"))
        await self._proc.stdin.drain()


async def create_mcp_clients(servers: Dict[str, Dict[str, Any]]) -> Dict[str, MCPClient]:
    out: Dict[str, MCPClient] = {}
    async def _init(alias: str, cfg: Dict[str, Any]) -> None:
        client = MCPClient(alias, cfg)
        try:
            await client.initialize()
            out[alias] = client
        except Exception as e:
            if os.environ.get("KEYSTONE_MCP_DEBUG"):
                print(f"[mcp:{alias}] init failed: {e}")
    await asyncio.gather(*(_init(a, c) for a, c in servers.items()), return_exceptions=True)
    return out


async def close_mcp_clients(clients: Dict[str, MCPClient]) -> None:
    await asyncio.gather(*(c.close() for c in clients.values()), return_exceptions=True)


def resolve_mcp_tool_ref(clients: Dict[str, MCPClient], prefixed: str):
    if "__" not in prefixed:
        return None
    alias, tool = prefixed.split("__", 1)
    client = clients.get(alias)
    if not client:
        return None
    return {"client": client, "tool": tool}
