"""Local agent harness — in-process Cursor-style agent SDK for Python.

Public surface:

    from polarity_keystone.harness import create_local_agent, prompt_local_agent
    from polarity_keystone.harness import builtin_tools, ToolDefinition
    from polarity_keystone.harness import send_provider, send_provider_stream

Mirrors the TypeScript SDK's harness module: 15 BYOK providers, 14
built-in tools, custom tools, MCP (stdio + http/sse), context compaction.
"""
from .providers import (
    ProviderMessage,
    ProviderToolSpec,
    ProviderToolCall,
    ProviderRequest,
    ProviderResponse,
    ProviderStreamEvent,
    ProviderUsage,
    ProviderKind,
    send as send_provider,
    send_stream as send_provider_stream,
    unprefix_model,
    is_reasoning_model,
)
from .compaction import (
    CompactionOptions,
    CompactionDecision,
    should_compact,
    compact_conversation,
    compact_if_needed,
    count_message_tokens,
)
from .builtin_tools import (
    ToolDefinition,
    ToolContext,
    new_tool_context,
    BUILTIN_TOOLS,
    default_tools,
    summarize_tool_result,
)
from .mcp_client import (
    MCPClient,
    MCPTool,
    MCPToolResult,
    create_mcp_clients,
    close_mcp_clients,
    resolve_mcp_tool_ref,
)
from .harness import (
    LocalAgentOptions,
    LocalSendOptions,
    LocalAgent,
    LocalRun,
    SDKArtifact,
    create_local_agent,
    prompt_local_agent,
)

__all__ = [
    # Providers
    "ProviderMessage", "ProviderToolSpec", "ProviderToolCall",
    "ProviderRequest", "ProviderResponse", "ProviderStreamEvent",
    "ProviderUsage", "ProviderKind",
    "send_provider", "send_provider_stream",
    "unprefix_model", "is_reasoning_model",
    # Compaction
    "CompactionOptions", "CompactionDecision",
    "should_compact", "compact_conversation", "compact_if_needed",
    "count_message_tokens",
    # Tools
    "ToolDefinition", "ToolContext", "new_tool_context",
    "BUILTIN_TOOLS", "default_tools", "summarize_tool_result",
    # MCP
    "MCPClient", "MCPTool", "MCPToolResult",
    "create_mcp_clients", "close_mcp_clients", "resolve_mcp_tool_ref",
    # Harness
    "LocalAgentOptions", "LocalSendOptions", "LocalAgent", "LocalRun",
    "SDKArtifact",
    "create_local_agent", "prompt_local_agent",
]
