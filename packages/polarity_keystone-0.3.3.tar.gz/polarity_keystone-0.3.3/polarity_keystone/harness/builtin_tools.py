"""Built-in tools for the Python harness — implements Cursor's 14 tool
catalog (Read/Write/Edit/Delete/Glob/Ls/Grep/Shell/Task/CreatePlan/
UpdateTodos/SemSearch/Mcp/ReadLints) using Python stdlib primitives.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Iterable, List, Optional


@dataclass
class ToolDefinition:
    name: str
    description: str
    input_schema: Dict[str, Any]
    handler: Callable[[Dict[str, Any], "ToolContext"], Awaitable[Dict[str, Any]]]


@dataclass
class ToolContext:
    working_dir: str
    todos: List[Dict[str, Any]] = field(default_factory=list)
    plans: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    mcp_dispatch: Optional[Callable[[str, str, Dict[str, Any]], Awaitable[Any]]] = None
    cancel_event: Optional[asyncio.Event] = None


def new_tool_context(working_dir: Optional[str] = None) -> ToolContext:
    return ToolContext(working_dir=working_dir or os.getcwd())


def _resolve(ctx: ToolContext, p: str) -> str:
    return p if os.path.isabs(p) else os.path.normpath(os.path.join(ctx.working_dir, p))


def _err(msg: str, code: str) -> Dict[str, Any]:
    return {"error": {"message": msg, "code": code}}


# ─── read ──────────────────────────────────────────────────────────

_IMAGE_MIME = {
    "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
    "gif": "image/gif", "webp": "image/webp", "bmp": "image/bmp",
}


def _detect_image_mime(path: str) -> Optional[str]:
    ext = path.lower().rsplit(".", 1)[-1] if "." in path else ""
    return _IMAGE_MIME.get(ext)


async def _read(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    try:
        import base64
        full = _resolve(ctx, args["path"])
        mime = _detect_image_mime(full)
        if mime:
            data = Path(full).read_bytes()
            return {"success": {
                "kind": "image",
                "mimeType": mime,
                "data": base64.b64encode(data).decode("ascii"),
                "sizeBytes": len(data),
            }}
        text = Path(full).read_text(encoding="utf-8")
        lines = text.split("\n")
        if args.get("startLine") or args.get("endLine"):
            start = (args.get("startLine") or 1) - 1
            end = args.get("endLine") or len(lines)
            return {"success": {"content": "\n".join(lines[start:end]), "totalLines": len(lines), "truncated": end < len(lines)}}
        return {"success": {"content": text, "totalLines": len(lines)}}
    except Exception as e:
        return _err(str(e), "READ_FAILED")


read_tool = ToolDefinition(
    name="read",
    description="Read the contents of a file from disk. Optional line range.",
    input_schema={
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "startLine": {"type": "integer", "minimum": 1},
            "endLine": {"type": "integer", "minimum": 1},
        },
        "required": ["path"],
    },
    handler=_read,
)


# ─── write ─────────────────────────────────────────────────────────

async def _write(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    try:
        full = _resolve(ctx, args["path"])
        Path(full).parent.mkdir(parents=True, exist_ok=True)
        created = not os.path.exists(full)
        Path(full).write_text(args["content"], encoding="utf-8")
        return {"success": {"bytesWritten": len(args["content"].encode("utf-8")), "created": created}}
    except Exception as e:
        return _err(str(e), "WRITE_FAILED")


write_tool = ToolDefinition(
    name="write",
    description="Write content to a file. Creates parent dirs. Overwrites existing.",
    input_schema={
        "type": "object",
        "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
        "required": ["path", "content"],
    },
    handler=_write,
)


# ─── edit ──────────────────────────────────────────────────────────

async def _edit(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    try:
        full = _resolve(ctx, args["path"])
        text = Path(full).read_text(encoding="utf-8")
        old = args["oldString"]
        new = args["newString"]
        occ = text.count(old)
        if occ == 0:
            return _err(f"oldString not found in {args['path']}", "EDIT_NOT_FOUND")
        if occ > 1 and not args.get("replaceAll"):
            return _err(f"oldString matches {occ} times — pass replaceAll=true or use a more unique snippet", "EDIT_AMBIGUOUS")
        next_text = text.replace(old, new) if args.get("replaceAll") else text.replace(old, new, 1)
        Path(full).write_text(next_text, encoding="utf-8")
        return {"success": {"edits": occ, "preview": next_text[:400]}}
    except Exception as e:
        return _err(str(e), "EDIT_FAILED")


edit_tool = ToolDefinition(
    name="edit",
    description="Replace exact string in a file. Fails if oldString is not unique unless replaceAll=true.",
    input_schema={
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "oldString": {"type": "string"},
            "newString": {"type": "string"},
            "replaceAll": {"type": "boolean"},
        },
        "required": ["path", "oldString", "newString"],
    },
    handler=_edit,
)


# ─── delete ────────────────────────────────────────────────────────

async def _delete(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    try:
        full = _resolve(ctx, args["path"])
        if os.path.isdir(full):
            if not args.get("recursive"):
                return _err(f"{args['path']} is a directory — pass recursive=true", "DELETE_DIR_REQUIRES_RECURSIVE")
            shutil.rmtree(full, ignore_errors=False)
        else:
            os.unlink(full)
        return {"success": {"removed": [full]}}
    except Exception as e:
        return _err(str(e), "DELETE_FAILED")


delete_tool = ToolDefinition(
    name="delete",
    description="Delete a file or directory. recursive=true required for non-empty dirs.",
    input_schema={"type": "object", "properties": {"path": {"type": "string"}, "recursive": {"type": "boolean"}}, "required": ["path"]},
    handler=_delete,
)


# ─── glob / ls / grep ──────────────────────────────────────────────

_SKIP_DIRS = {"node_modules", ".git", "dist", ".next", "target", "venv", "__pycache__"}


def _walk(root: str) -> Iterable[str]:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        for f in filenames:
            yield os.path.join(dirpath, f)


def _glob_to_regex(pattern: str) -> re.Pattern:
    esc = re.escape(pattern).replace(r"\*\*", "__DOUBLESTAR__").replace(r"\*", "[^/]*").replace("__DOUBLESTAR__", ".*").replace(r"\?", ".")
    return re.compile("^" + esc + "$")


async def _glob(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    root = _resolve(ctx, args.get("cwd") or "")
    if not args.get("cwd"):
        root = ctx.working_dir
    rx = _glob_to_regex(args["pattern"])
    limit = args.get("limit", 1000)
    paths: List[str] = []
    truncated = False
    for p in _walk(root):
        rel = os.path.relpath(p, root)
        if rx.match(rel):
            paths.append(rel)
            if len(paths) >= limit:
                truncated = True
                break
    return {"success": {"paths": paths, "truncated": truncated}}


glob_tool = ToolDefinition(
    name="glob",
    description="Find files matching a glob pattern. Supports **, *, ?.",
    input_schema={"type": "object", "properties": {"pattern": {"type": "string"}, "cwd": {"type": "string"}, "limit": {"type": "integer"}}, "required": ["pattern"]},
    handler=_glob,
)


async def _ls(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    try:
        full = _resolve(ctx, args["path"])
        out = []
        for name in os.listdir(full):
            if not args.get("showHidden") and name.startswith("."):
                continue
            ep = os.path.join(full, name)
            try:
                st = os.stat(ep)
                out.append({"name": name, "isDir": os.path.isdir(ep), "size": st.st_size})
            except OSError:
                out.append({"name": name, "isDir": os.path.isdir(ep)})
        return {"success": {"entries": out}}
    except Exception as e:
        return _err(str(e), "LS_FAILED")


ls_tool = ToolDefinition(
    name="ls",
    description="List entries in a directory.",
    input_schema={"type": "object", "properties": {"path": {"type": "string"}, "showHidden": {"type": "boolean"}}, "required": ["path"]},
    handler=_ls,
)


async def _grep(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    try:
        root = _resolve(ctx, args.get("path") or "") if args.get("path") else ctx.working_dir
        flags = re.IGNORECASE if args.get("caseInsensitive") else 0
        rx = re.compile(args["pattern"], flags)
        limit = args.get("limit", 100)
        mode = args.get("outputMode", "content")
        before = args.get("contextBefore", 0)
        after = args.get("contextAfter", 0)
        glob_rx = _glob_to_regex(args["glob"]) if args.get("glob") else None

        files: List[str]
        if os.path.isfile(root):
            files = [root]
        else:
            files = list(_walk(root))

        if mode == "files":
            paths = []
            for f in files:
                rel = os.path.relpath(f, root) if os.path.isdir(root) else os.path.basename(f)
                if glob_rx and not glob_rx.match(rel):
                    continue
                try:
                    if rx.search(Path(f).read_text(encoding="utf-8", errors="ignore")):
                        paths.append(rel)
                        if len(paths) >= limit:
                            break
                except Exception:
                    continue
            return {"success": {"mode": "files", "paths": paths}}

        if mode == "count":
            counts = []
            for f in files:
                rel = os.path.relpath(f, root) if os.path.isdir(root) else os.path.basename(f)
                if glob_rx and not glob_rx.match(rel):
                    continue
                try:
                    text = Path(f).read_text(encoding="utf-8", errors="ignore")
                    c = len(rx.findall(text))
                    if c > 0:
                        counts.append({"path": rel, "count": c})
                except Exception:
                    continue
            return {"success": {"mode": "count", "counts": counts}}

        matches = []
        for f in files:
            rel = os.path.relpath(f, root) if os.path.isdir(root) else os.path.basename(f)
            if glob_rx and not glob_rx.match(rel):
                continue
            try:
                text = Path(f).read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            lines = text.split("\n")
            for i, line in enumerate(lines):
                if rx.search(line):
                    matches.append({
                        "path": rel, "lineNumber": i + 1, "line": line,
                        "beforeContext": lines[max(0, i - before): i] if before else None,
                        "afterContext": lines[i + 1: i + 1 + after] if after else None,
                    })
                    if len(matches) >= limit:
                        return {"success": {"mode": "content", "matches": matches}}
        return {"success": {"mode": "content", "matches": matches}}
    except Exception as e:
        return _err(str(e), "GREP_FAILED")


grep_tool = ToolDefinition(
    name="grep",
    description="Search file contents for a regex. Returns matches, counts, or files.",
    input_schema={
        "type": "object",
        "properties": {
            "pattern": {"type": "string"}, "path": {"type": "string"}, "glob": {"type": "string"},
            "outputMode": {"type": "string", "enum": ["content", "count", "files"]},
            "caseInsensitive": {"type": "boolean"},
            "contextBefore": {"type": "integer"}, "contextAfter": {"type": "integer"},
            "limit": {"type": "integer"},
        },
        "required": ["pattern"],
    },
    handler=_grep,
)


# ─── shell ─────────────────────────────────────────────────────────

async def _shell(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    start = time.time()
    try:
        proc = await asyncio.create_subprocess_shell(
            args["command"],
            cwd=_resolve(ctx, args.get("cwd") or "") if args.get("cwd") else ctx.working_dir,
            env={**os.environ, **(args.get("env") or {})},
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            timeout_s = (args.get("timeoutMs") or 0) / 1000 or None
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
        except asyncio.TimeoutError:
            proc.kill()
            return _err(f"shell command timed out after {args['timeoutMs']}ms", "SHELL_TIMEOUT")
        return {"success": {
            "exitCode": proc.returncode if proc.returncode is not None else -1,
            "stdout": stdout.decode("utf-8", errors="replace"),
            "stderr": stderr.decode("utf-8", errors="replace"),
            "durationMs": int((time.time() - start) * 1000),
        }}
    except Exception as e:
        return _err(str(e), "SHELL_SPAWN_FAILED")


shell_tool = ToolDefinition(
    name="shell",
    description="Execute a shell command. Returns stdout, stderr, exit code.",
    input_schema={
        "type": "object",
        "properties": {
            "command": {"type": "string"}, "cwd": {"type": "string"},
            "env": {"type": "object", "additionalProperties": {"type": "string"}},
            "timeoutMs": {"type": "integer"},
        },
        "required": ["command"],
    },
    handler=_shell,
)


# ─── task / create_plan / update_todos / sem_search / mcp / read_lints ─

async def _task(args: Dict[str, Any], _ctx: ToolContext) -> Dict[str, Any]:
    return {"success": {"task_id": f"task-{int(time.time()*1000)}", "result": f"[task tool stub] {args.get('prompt', '')[:80]}..."}}


task_tool = ToolDefinition(
    name="task",
    description="Spawn a subagent for a focused subtask.",
    input_schema={
        "type": "object",
        "properties": {
            "prompt": {"type": "string"},
            "subagent": {"type": "string", "enum": ["planner", "editor", "researcher", "custom"]},
            "mode": {"type": "string", "enum": ["foreground", "background"]},
            "context": {"type": "string"},
        },
        "required": ["prompt"],
    },
    handler=_task,
)


async def _create_plan(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    plan_id = f"plan-{int(time.time()*1000)}"
    ctx.plans[plan_id] = {"steps": args.get("steps", [])}
    return {"success": {"plan_id": plan_id}}


create_plan_tool = ToolDefinition(
    name="create_plan",
    description="Record a stepwise plan. Returns a plan id.",
    input_schema={
        "type": "object",
        "properties": {
            "steps": {"type": "array", "items": {
                "type": "object",
                "properties": {"description": {"type": "string"}, "status": {"type": "string", "enum": ["pending", "in_progress", "completed"]}},
                "required": ["description"],
            }},
        },
        "required": ["steps"],
    },
    handler=_create_plan,
)


async def _update_todos(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    ctx.todos = args.get("todos", [])
    return {"success": {"updated": len(ctx.todos)}}


update_todos_tool = ToolDefinition(
    name="update_todos",
    description="Update the session's persistent todo list.",
    input_schema={
        "type": "object",
        "properties": {
            "todos": {"type": "array", "items": {
                "type": "object",
                "properties": {"id": {"type": "string"}, "content": {"type": "string"}, "status": {"type": "string", "enum": ["pending", "in_progress", "completed"]}},
                "required": ["id", "content", "status"],
            }},
        },
        "required": ["todos"],
    },
    handler=_update_todos,
)


async def _sem_search(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    try:
        limit = args.get("limit", 20)
        tokens = [t for t in args["query"].lower().split() if t]
        roots = [_resolve(ctx, p) for p in args.get("paths", [])] or [ctx.working_dir]
        hits = []
        for root in roots:
            files = [root] if os.path.isfile(root) else list(_walk(root))
            for f in files:
                try:
                    text = Path(f).read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    continue
                lower = text.lower()
                score = sum(1 for t in tokens if t in lower) / len(tokens)
                if score > 0:
                    idx = lower.find(tokens[0])
                    preview = text[max(0, idx - 40): idx + 120]
                    hits.append({"path": os.path.relpath(f, ctx.working_dir), "score": score, "preview": preview})
        hits.sort(key=lambda h: h["score"], reverse=True)
        return {"success": {"hits": hits[:limit]}}
    except Exception as e:
        return _err(str(e), "SEM_SEARCH_FAILED")


sem_search_tool = ToolDefinition(
    name="sem_search",
    description="Semantic-ish code search (token-frequency fallback).",
    input_schema={"type": "object", "properties": {"query": {"type": "string"}, "paths": {"type": "array", "items": {"type": "string"}}, "limit": {"type": "integer"}}, "required": ["query"]},
    handler=_sem_search,
)


async def _mcp(args: Dict[str, Any], ctx: ToolContext) -> Dict[str, Any]:
    if not ctx.mcp_dispatch:
        return _err("no MCP servers configured for this agent", "MCP_NOT_CONFIGURED")
    try:
        result = await ctx.mcp_dispatch(args["provider"], args["tool"], args.get("arguments", {}))
        if isinstance(result, dict) and isinstance(result.get("content"), list):
            return {"success": result}
        return {"success": {"content": [{"type": "text", "text": json.dumps(result)}]}}
    except Exception as e:
        return _err(str(e), "MCP_CALL_FAILED")


mcp_tool = ToolDefinition(
    name="mcp",
    description="Call a tool exposed by a configured MCP server. provider=alias, tool=bare name.",
    input_schema={"type": "object", "properties": {"provider": {"type": "string"}, "tool": {"type": "string"}, "arguments": {"type": "object", "additionalProperties": True}}, "required": ["provider", "tool", "arguments"]},
    handler=_mcp,
)


async def _read_lints(_args: Dict[str, Any], _ctx: ToolContext) -> Dict[str, Any]:
    return {"success": {"issues": []}}


read_lints_tool = ToolDefinition(
    name="read_lints",
    description="Read lint diagnostics for one or more files. Empty by default (no linter wired in).",
    input_schema={"type": "object", "properties": {"paths": {"type": "array", "items": {"type": "string"}}}, "required": ["paths"]},
    handler=_read_lints,
)


BUILTIN_TOOLS: List[ToolDefinition] = [
    read_tool, write_tool, edit_tool, delete_tool,
    glob_tool, ls_tool, grep_tool, shell_tool,
    task_tool, create_plan_tool, update_todos_tool,
    sem_search_tool, mcp_tool, read_lints_tool,
]


def default_tools() -> List[ToolDefinition]:
    return list(BUILTIN_TOOLS)


def summarize_tool_result(tool_name: str, result: Any) -> str:
    if not isinstance(result, dict):
        return str(result)
    if "error" in result:
        e = result["error"]
        msg = e.get("message", "")
        code = e.get("code")
        return f"Error from {tool_name}: {msg}" + (f" ({code})" if code else "")
    if "success" in result:
        s = result["success"]
        if isinstance(s, str):
            return s
        return json.dumps(s)[:4000]
    return json.dumps(result)[:4000]
