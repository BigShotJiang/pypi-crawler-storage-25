"""Context compaction for the Python harness — token budget-aware
auto-summarization. Mirrors the TS ``harness/compaction.ts``.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, List, Optional

from .providers import ProviderMessage, ProviderRequest, send, unprefix_model


@dataclass
class CompactionOptions:
    threshold_ratio: float = 0.7
    keep_recent_turns: int = 6
    summarizer_model: str = "openai/gpt-4o-mini"
    summarizer_api_key: Optional[str] = None
    min_context_tokens: int = 4000
    count_tokens: Optional[Callable[[str], int]] = None
    enabled: bool = True


@dataclass
class CompactionDecision:
    should_compact: bool
    used_tokens: int
    context_window: int
    compact_through_index: int


_CONTEXT_WINDOWS = {
    # OpenAI
    "gpt-5.5-2026-04-23": 400_000, "gpt-5": 400_000,
    "gpt-4o": 128_000, "gpt-4o-mini": 128_000, "gpt-4-turbo": 128_000,
    "o1": 200_000, "o3": 200_000, "o4-mini": 200_000,
    # Anthropic
    "claude-opus-4-7": 1_000_000, "claude-opus-4-6": 1_000_000,
    "claude-opus-4-5": 200_000, "claude-sonnet-4-6": 1_000_000,
    "claude-haiku-4-5": 200_000, "claude-3-5-sonnet": 200_000,
    # Gemini
    "gemini-2.5-pro": 2_000_000, "gemini-2.5-flash": 1_000_000,
    "gemini-1.5-pro": 2_000_000,
    # Others
    "llama-3.3-70b-versatile": 131_072,
    "mistral-large-latest": 128_000,
    "deepseek-chat": 64_000,
    "grok-4": 256_000,
}


def _context_window(model_id: str) -> int:
    bare = unprefix_model(model_id)["model"]
    if bare in _CONTEXT_WINDOWS:
        return _CONTEXT_WINDOWS[bare]
    for k, v in _CONTEXT_WINDOWS.items():
        if bare.startswith(k):
            return v
    return 32_000


def _default_count_tokens(text: str) -> int:
    if not text:
        return 0
    return math.ceil(len(text) / 4)


def count_message_tokens(messages: List[ProviderMessage], count_tokens: Optional[Callable[[str], int]] = None) -> int:
    counter = count_tokens or _default_count_tokens
    total = 0
    for m in messages:
        total += counter(m.content or "")
        for c in m.tool_calls or []:
            import json as _json
            total += counter(c.get("name", "")) + counter(_json.dumps(c.get("input") or {}))
        total += 4
    return total


def should_compact(messages: List[ProviderMessage], model_id: str, options: Optional[CompactionOptions] = None) -> CompactionDecision:
    opts = options or CompactionOptions()
    used = count_message_tokens(messages, opts.count_tokens)
    window = max(_context_window(model_id), opts.min_context_tokens)
    trigger = int(window * opts.threshold_ratio)
    if used < trigger:
        return CompactionDecision(False, used, window, 0)
    system_count = sum(1 for m in messages if m.role == "system")
    first_non_system = system_count
    last_to_keep = len(messages) - opts.keep_recent_turns
    cutoff = max(first_non_system + 1, last_to_keep)
    return CompactionDecision(cutoff > first_non_system, used, window, cutoff)


async def compact_conversation(
    messages: List[ProviderMessage],
    model_id: str,
    api_key: str,
    options: Optional[CompactionOptions] = None,
):
    opts = options or CompactionOptions()
    decision = should_compact(messages, model_id, opts)
    if not decision.should_compact:
        return messages, "", 0
    summarizer_key = opts.summarizer_api_key or api_key
    leading_system = [m for i, m in enumerate(messages) if m.role == "system" and i < decision.compact_through_index]
    to_compact = messages[len(leading_system): decision.compact_through_index]
    tail = messages[decision.compact_through_index:]
    transcript_parts = []
    for m in to_compact:
        body = m.content
        if m.tool_calls:
            body += "\n" + "\n".join(f"[tool_call {c['name']}({c.get('input', {})})]" for c in m.tool_calls)
        transcript_parts.append(f"{m.role}: {body}")
    transcript = "\n\n".join(transcript_parts)
    prompt = (
        "Summarize this conversation history into a brief running context note that preserves: "
        "(1) what the user has asked, (2) key facts the assistant has established, "
        "(3) any unresolved tasks, (4) decisions made. Be specific — include file names, "
        "function names, identifiers exactly as they appeared. No fluff. Output ~200-400 words.\n\n"
        f"HISTORY:\n{transcript}"
    )
    summary_resp = await send(ProviderRequest(
        model=opts.summarizer_model,
        api_key=summarizer_key,
        messages=[ProviderMessage(role="user", content=prompt)],
        max_tokens=800,
        temperature=0.2,
    ))
    summary_msg = ProviderMessage(
        role="system",
        content=f"[Compacted context — older history summarized]\n\n{summary_resp.text}",
    )
    new_messages = [*leading_system, summary_msg, *tail]
    before = count_message_tokens(messages, opts.count_tokens)
    after = count_message_tokens(new_messages, opts.count_tokens)
    return new_messages, summary_resp.text, max(0, before - after)


async def compact_if_needed(
    messages: List[ProviderMessage],
    model_id: str,
    api_key: str,
    options: Optional[CompactionOptions] = None,
) -> List[ProviderMessage]:
    new_msgs, _, _ = await compact_conversation(messages, model_id, api_key, options)
    return new_msgs
