"""Judges (PromptScorer) operations.

Mirrors Judgment Labs' ``PromptScorer`` surface — three score types
(binary / classification / score, with ``categorical`` and ``numeric``
accepted as aliases), mustache ``{{var}}`` prompts, and an
``evaluate()`` method that runs the judge against a set of inputs and
returns the typed verdict.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ._http import HTTPClient


# Mapping of caller-facing names → canonical server type. Judgment Labs
# SDK code can pass ``categorical`` / ``numeric`` and get the right shape.
_TYPE_ALIASES = {
    "binary": "binary",
    "classification": "classification",
    "categorical": "classification",
    "score": "score",
    "numeric": "score",
}


def _canon(score_type: str) -> str:
    canon = _TYPE_ALIASES.get(score_type.strip().lower())
    if not canon:
        raise ValueError(
            f"invalid score_type {score_type!r} — "
            "must be one of binary, classification (categorical), score (numeric)"
        )
    return canon


class JudgesService:
    """CRUD + playground evaluate for judges."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(
        self,
        name: str,
        score_type: str,
        prompt: str = "",
        *,
        description: str = "",
        method: str = "agent",
        notes: str = "",
        categories: Optional[List[Dict[str, str]]] = None,
        score_min: Optional[float] = None,
        score_max: Optional[float] = None,
        model: str = "polarity/paragon-fast",
        version: str = "v0.0",
        evaluation_settings: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create a judge.

        Example::

            relevancy = ks.judges.create(
                name="Relevancy",
                score_type="classification",  # or "categorical"
                prompt="Is {{request}} relevant to {{response}}?",
                categories=[{"name": "relevant"}, {"name": "irrelevant"}],
            )
        """
        body = {
            "name": name,
            "type": _canon(score_type),
            "prompt": prompt,
            "description": description,
            "method": method,
            "notes": notes,
            "model": model,
            "version": version,
        }
        if categories is not None:
            body["categories"] = categories
        if score_min is not None:
            body["score_min"] = score_min
        if score_max is not None:
            body["score_max"] = score_max
        if evaluation_settings is not None:
            body["evaluation_settings"] = evaluation_settings
        return self._http.post("/v1/judges", body)

    def list(self) -> List[Dict[str, Any]]:
        """List judges for the current owner."""
        return self._http.get("/v1/judges") or []

    def get(self, judge_id: str) -> Dict[str, Any]:
        """Fetch a single judge by id."""
        return self._http.get(f"/v1/judges/{judge_id}")

    def update(self, judge_id: str, **patch: Any) -> Dict[str, Any]:
        """Partial-update a judge. Pass only the fields you want changed."""
        if "score_type" in patch and "type" not in patch:
            patch["type"] = _canon(patch.pop("score_type"))
        elif "type" in patch:
            patch["type"] = _canon(patch["type"])
        return self._http.request("PUT", f"/v1/judges/{judge_id}", patch)

    def delete(self, judge_id: str) -> None:
        """Delete a judge."""
        self._http.delete(f"/v1/judges/{judge_id}")

    def evaluate(self, judge_id: str, inputs: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Run the judge against a set of variable inputs.

        Returns a verdict whose shape depends on the judge's type:

            binary         → ``{"type":"binary","passed":bool,"reason":...}``
            classification → ``{"type":"classification","category":str,"reason":...}``
            score          → ``{"type":"score","score":float,"reason":...}``

        All shapes carry ``latency_ms`` and ``cost_usd``.
        """
        return self._http.post(
            f"/v1/judges/{judge_id}/evaluate",
            {"inputs": inputs or {}},
        )
