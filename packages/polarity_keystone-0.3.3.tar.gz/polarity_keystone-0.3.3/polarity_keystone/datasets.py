"""Dataset operations for the Keystone SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Tuple

from ._http import HTTPClient


class DatasetInfo(Mapping):
    """A dataset row returned by the API.

    Supports both attribute access (``ds.id``, TS-parity) and dict access
    (``ds["id"]``, backwards-compat with existing callers). Behaves like a
    read-only mapping so ``dict(ds)`` / iteration work as expected.
    """

    __slots__ = ("_data",)

    def __init__(self, data: Optional[Mapping[str, Any]]) -> None:
        self._data: Dict[str, Any] = dict(data or {})

    def __getattr__(self, key: str) -> Any:
        if key.startswith("_"):
            raise AttributeError(key)
        try:
            return self._data[key]
        except KeyError:
            raise AttributeError(key) from None

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __iter__(self):
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"DatasetInfo({self._data!r})"

    def to_dict(self) -> Dict[str, Any]:
        return dict(self._data)


class DatasetService:
    """CRUD and record management for Keystone datasets."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(self, name: str, description: str = "") -> DatasetInfo:
        """Create a new dataset. Returns a :class:`DatasetInfo`."""
        raw = self._http.post("/v1/datasets", {"name": name, "description": description})
        return DatasetInfo(raw if isinstance(raw, Mapping) else {})

    def list(self) -> List[DatasetInfo]:
        """List all datasets as :class:`DatasetInfo` objects."""
        raw = self._http.get("/v1/datasets") or []
        return [DatasetInfo(r) for r in raw]

    def get(self, dataset_id: str) -> DatasetInfo:
        """Get a dataset by ID. Returns a :class:`DatasetInfo`."""
        raw = self._http.get(f"/v1/datasets/{dataset_id}")
        return DatasetInfo(raw if isinstance(raw, Mapping) else {})

    def delete(self, dataset_id: str) -> None:
        """Delete a dataset and all its records."""
        self._http.delete(f"/v1/datasets/{dataset_id}")

    def add_records(
        self,
        dataset_id: str,
        records: List[Dict[str, Any]],
    ) -> Dict[str, int]:
        """Add records to a dataset. Auto-increments the dataset version.

        Each record should have ``input`` (required) and optionally
        ``expected``, ``metadata``, and ``tags``.

        Args:
            dataset_id: Target dataset ID.
            records: List of record dicts.

        Returns:
            Dict with ``added`` count.

        Example::

            ks.datasets.add_records(ds["id"], [
                {"input": {"prompt": "fix the bug"}, "expected": {"file": "fixed.py"}},
                {"input": {"prompt": "add tests"}, "tags": ["testing"]},
            ])
        """
        return self._http.post(f"/v1/datasets/{dataset_id}/records", {"records": records})

    def get_records(
        self,
        dataset_id: str,
        *,
        version: Optional[int] = None,
        tags: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Get records from a dataset.

        Args:
            dataset_id: Target dataset ID.
            version: Specific version (default: all versions).
            tags: Filter by tags.

        Returns:
            List of record dicts.
        """
        path = f"/v1/datasets/{dataset_id}/records"
        params = []
        if version is not None:
            params.append(f"version={version}")
        if tags:
            params.append(f"tags={','.join(tags)}")
        if params:
            path += "?" + "&".join(params)
        return self._http.get(path) or []

    def from_traces(
        self,
        *,
        name: str,
        filter: Optional[Dict[str, Any]] = None,
        input_from: Any = None,
        expected_from: Any = None,
        mode: str = "append",
        dry_run: bool = False,
        description: str = "",
    ) -> Dict[str, Any]:
        """Build a dataset from production trace events.

        Composes ``/v1/traces`` (paginated) with dataset create + add_records,
        mapping each event's input/expected via configurable key paths. Skips
        events missing input or expected, reporting counts. Idempotent on
        ``span_id`` within a single call: re-running with ``mode='append'``
        won't double-write rows for events seen earlier in the same iteration.

        Args:
            name: Dataset name. Reused when mode='append' if it exists.
            filter: Trace filter (passes through to /v1/traces).
            input_from: Either a dot-path (str) or a callable(event) -> value.
                Falls through ``metadata.input`` → ``metadata.llm.prompt`` →
                ``metadata.gen_ai.prompt`` when not provided.
            expected_from: Same shape as ``input_from`` but for the expected
                output.
            mode: 'append' (default) or 'replace'. 'replace' creates a new
                dataset row regardless of existing ones with the same name.
            dry_run: If True, return the mapped rows without POSTing.
            description: Optional description if creating the dataset.

        Returns:
            Dict with ``dataset_id``, ``name``, ``rows_added``,
            ``sample_rows`` (first 3), ``skipped`` ({count, reasons}).
        """
        flt = dict(filter or {})
        skipped_reasons: Dict[str, int] = {}
        skipped_count = 0
        records: List[Dict[str, Any]] = []
        seen_span_ids: set = set()

        for event in self._iter_traces(flt):
            span_id = event.get("span_id") or ""
            if span_id and span_id in seen_span_ids:
                continue
            if span_id:
                seen_span_ids.add(span_id)

            input_value = _pluck(event, input_from, _DEFAULT_INPUT_KEYS)
            expected_value = _pluck(event, expected_from, _DEFAULT_EXPECTED_KEYS)

            if input_value is None:
                skipped_count += 1
                skipped_reasons["missing-input"] = skipped_reasons.get("missing-input", 0) + 1
                continue
            if expected_value is None:
                skipped_count += 1
                skipped_reasons["missing-expected"] = skipped_reasons.get("missing-expected", 0) + 1
                continue

            record: Dict[str, Any] = {
                "input": _to_record_value(input_value),
                "expected": _to_record_value(expected_value),
            }
            if span_id:
                record["metadata"] = {"span_id": span_id}
            records.append(record)

        sample_rows = records[:3]

        if dry_run:
            return {
                "dataset_id": "",
                "name": name,
                "rows_added": len(records),
                "sample_rows": sample_rows,
                "skipped": {"count": skipped_count, "reasons": skipped_reasons},
            }

        ds: Optional[DatasetInfo] = None
        if mode == "append":
            for d in self.list():
                if d["name"] == name:
                    ds = d
                    break
        if ds is None:
            ds = self.create(name, description)

        rows_added = 0
        if records:
            r = self.add_records(ds["id"], records)
            if isinstance(r, Mapping) and "added" in r:
                rows_added = int(r["added"])
            else:
                rows_added = len(records)

        return {
            "dataset_id": ds["id"],
            "name": ds["name"],
            "rows_added": rows_added,
            "sample_rows": sample_rows,
            "skipped": {"count": skipped_count, "reasons": skipped_reasons},
        }

    def _iter_traces(self, filter: Dict[str, Any]):
        """Yield every /v1/traces row matching ``filter``, draining all pages."""
        cursor: Optional[str] = None
        while True:
            params = ["limit=100"]
            if cursor:
                params.append(f"cursor={cursor}")
            for k, v in filter.items():
                if v is None:
                    continue
                params.append(f"{k}={v}")
            path = "/v1/traces?" + "&".join(params)
            page = self._http.get(path) or {}
            for item in page.get("items") or []:
                yield item
            cursor = page.get("next_cursor")
            if not cursor:
                return


_DEFAULT_INPUT_KEYS = ["metadata.input", "metadata.llm.prompt", "metadata.gen_ai.prompt"]
_DEFAULT_EXPECTED_KEYS = ["metadata.output", "metadata.llm.completion", "metadata.gen_ai.completion"]


def _read_path(obj: Any, path: str) -> Any:
    """Read ``a.b.c`` style path from a nested dict. Returns None if any segment missing."""
    cur: Any = obj
    for part in path.split("."):
        if isinstance(cur, Mapping) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def _pluck(event: Dict[str, Any], src: Any, fallbacks: List[str]) -> Any:
    """Resolve a value from an event using either a callable, a dot path, or fallbacks."""
    if callable(src):
        return src(event)
    candidates = [src, *fallbacks] if isinstance(src, str) else list(fallbacks)
    for path in candidates:
        v = _read_path(event, path)
        if v is not None:
            return v
    return None


def _to_record_value(v: Any) -> Dict[str, Any]:
    """Wrap scalars in ``{value: ...}`` so DatasetRecord.input/expected stay dict-shaped."""
    if isinstance(v, Mapping):
        return dict(v)
    return {"value": v}
