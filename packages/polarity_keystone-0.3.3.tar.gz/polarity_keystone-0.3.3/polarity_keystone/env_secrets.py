"""Resolve spec-declared secrets with per-secret source selection.

The spec's ``secrets:`` block names each secret AND declares where its value
comes from via ``source:``. Parity with the TypeScript and Go SDKs.

Recognized sources:
    env                (default)    → os.environ[NAME]
    env:OTHER_NAME                  → os.environ[OTHER_NAME]    (rename)
    file:path                        → stripped contents of the file
    command:<shell>                  → exec shell, capture stdout (stripped)
    dashboard                        → server-side only; SDK does NOT forward

For sources other than ``dashboard``, the SDK resolves locally and forwards
the ``{name: value}`` map in the create request. The server then merges
with Dashboard-stored secrets (local wins), so ``dashboard`` effectively
means "don't override me locally — always use what's in Keystone."

Precedence (highest wins): spec literal (``from: static://…``) > SDK-
forwarded source value > Dashboard.
"""

from __future__ import annotations

import os
import re
import shlex
import subprocess
from pathlib import Path
from typing import Any, Dict, Mapping, Optional


def collect_declared_secrets(
    spec: Mapping[str, Any],
    env: Optional[Mapping[str, str]] = None,
) -> Dict[str, str]:
    """Resolve a spec dict's declared secrets into ``{name: value}``."""
    env = env if env is not None else os.environ
    out: Dict[str, str] = {}
    for entry in spec.get("secrets") or []:
        if isinstance(entry, str):
            name, has_from, source = entry, False, "env"
        elif isinstance(entry, Mapping):
            name = entry.get("name")
            has_from = bool(entry.get("from"))
            source = entry.get("source") or "env"
        else:
            continue
        if not name or has_from:
            continue
        if source == "dashboard":
            continue
        value = resolve_source(name, source, env)
        if value:
            out[name] = value
    return out


def collect_declared_secrets_from_file(
    spec_path: str,
    env: Optional[Mapping[str, str]] = None,
) -> Dict[str, str]:
    """Parse a spec at *spec_path* and resolve declared secrets."""
    with open(spec_path, "r", encoding="utf-8") as f:
        raw = f.read()
    spec = _parse_spec_secrets(raw)
    return collect_declared_secrets(spec, env)


def resolve_source(
    name: str,
    source: str,
    env: Optional[Mapping[str, str]] = None,
) -> Optional[str]:
    """Dispatch a single source descriptor to its resolver."""
    env = env if env is not None else os.environ
    if source == "env":
        return env.get(name)
    if source.startswith("env:"):
        return env.get(source[4:])
    if source.startswith("file:"):
        path = Path(source[5:]).expanduser()
        try:
            return path.read_text(encoding="utf-8").strip()
        except OSError:
            return None
    if source.startswith("command:"):
        cmd = source[8:]
        try:
            # shell=True so users can pipe / quote naturally
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, check=True
            )
            return result.stdout.strip()
        except (OSError, subprocess.CalledProcessError):
            return None
    raise ValueError(f'unknown secret source "{source}" for {name}')


# ── Minimal spec parser ─────────────────────────────────────────────────────

_INLINE_ARRAY_RE = re.compile(r"^secrets:\s*\[([^\]]*)\]\s*$")
_NAME_INLINE_RE = re.compile(r"name:\s*['\"]?([A-Z0-9_]+)['\"]?")
_FROM_INLINE_RE = re.compile(r"from:\s*['\"]?([^'\"\s]+)['\"]?")
_SRC_INLINE_RE  = re.compile(r"source:\s*['\"]?([^'\"]+?)['\"]?\s*$")
_LIST_ITEM_RE = re.compile(r"^\s*-\s*(.*)$")
_NAME_KEY_RE = re.compile(r"^\s+name:\s*['\"]?([A-Z0-9_]+)['\"]?")
_FROM_KEY_RE = re.compile(r"^\s+from:\s*['\"]?([^'\"\s]+)['\"]?")
_SRC_KEY_RE  = re.compile(r"^\s+source:\s*['\"]?([^'\"]+?)['\"]?\s*$")


def _parse_spec_secrets(yaml_text: str) -> Dict[str, Any]:
    lines = yaml_text.split("\n")
    spec: Dict[str, Any] = {"secrets": []}

    i = 0
    while i < len(lines):
        line = lines[i]
        inline = _INLINE_ARRAY_RE.match(line)
        if inline:
            inner = inline.group(1).strip()
            if inner:
                spec["secrets"] = [
                    s.strip().strip("'\"") for s in inner.split(",") if s.strip()
                ]
            return spec

        if line.rstrip() == "secrets:":
            i += 1
            current: Optional[Dict[str, Any]] = None
            while i < len(lines):
                l = lines[i]
                if l and not l[0].isspace():
                    break
                item = _LIST_ITEM_RE.match(l)
                if item:
                    if current is not None:
                        spec["secrets"].append(current)
                    current = {}
                    inline_rest = item.group(1)
                    nm = _NAME_INLINE_RE.search(inline_rest)
                    fr = _FROM_INLINE_RE.search(inline_rest)
                    sr = _SRC_INLINE_RE.search(inline_rest)
                    if nm:
                        current["name"] = nm.group(1)
                    if fr:
                        current["from"] = fr.group(1)
                    if sr:
                        current["source"] = sr.group(1)
                elif current is not None:
                    nm = _NAME_KEY_RE.match(l)
                    fr = _FROM_KEY_RE.match(l)
                    sr = _SRC_KEY_RE.match(l)
                    if nm:
                        current["name"] = nm.group(1)
                    if fr:
                        current["from"] = fr.group(1)
                    if sr:
                        current["source"] = sr.group(1)
                i += 1
            if current is not None:
                spec["secrets"].append(current)
            break
        i += 1

    return spec
