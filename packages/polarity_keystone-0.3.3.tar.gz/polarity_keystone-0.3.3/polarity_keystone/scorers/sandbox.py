"""Sandbox-oriented scorers — the original Keystone invariants.

These five scorers are *server-side invariants*: they describe a check that
Keystone's sandbox evaluator runs after the agent terminates. They don't
execute locally; ``to_invariant()`` returns the spec dict and
``score_result`` is a no-op.

Brought forward from the original ``polarity_keystone.scores`` module with
the same semantics, now part of the unified scorer hierarchy.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from .base import BaseScorer


class FileExists(BaseScorer):
    """Check that a file exists in the workspace."""

    rule_type = "file_exists"

    def __init__(self, path: str, *, weight: float = 1.0, gate: bool = False) -> None:
        self.name = f"file_exists:{path}"
        self.path = path
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        return {
            "description": f"{self.path} exists",
            "weight": self.weight,
            "gate": self.gate,
            "check": {"type": "file_exists", "path": self.path},
        }

    def _rule_config(self) -> Dict[str, Any]:
        return {"path": self.path}


class FileContains(BaseScorer):
    """Check that a file contains a string or matches a pattern."""

    rule_type = "file_content"

    def __init__(
        self,
        path: str,
        *,
        contains: Optional[str] = None,
        not_contains: Optional[str] = None,
        pattern: Optional[str] = None,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self.name = f"file_content:{path}"
        self.path = path
        self.contains = contains
        self.not_contains = not_contains
        self.pattern = pattern
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        check: Dict[str, Any] = {"type": "file_content", "path": self.path}
        if self.contains:
            check["contains"] = self.contains
        if self.not_contains:
            check["not_contains"] = self.not_contains
        if self.pattern:
            check["pattern"] = self.pattern
        return {
            "description": f"{self.path} content check",
            "weight": self.weight,
            "gate": self.gate,
            "check": check,
        }

    def _rule_config(self) -> Dict[str, Any]:
        return {
            "path": self.path,
            "contains": self.contains,
            "not_contains": self.not_contains,
            "pattern": self.pattern,
        }


class CommandExits(BaseScorer):
    """Check that a command exits with a specific code."""

    rule_type = "command_exit"

    def __init__(
        self,
        command: str,
        *,
        exit_code: int = 0,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self.name = f"command:{command[:30]}"
        self.command = command
        self.exit_code = exit_code
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        return {
            "description": f"command exits {self.exit_code}",
            "weight": self.weight,
            "gate": self.gate,
            "check": {
                "type": "command_exit",
                "command": self.command,
                "exit_code": self.exit_code,
            },
        }

    def _rule_config(self) -> Dict[str, Any]:
        return {"command": self.command, "exit_code": self.exit_code}


class SQLEquals(BaseScorer):
    """Check that a SQL query returns an expected value."""

    rule_type = "sql"

    def __init__(
        self,
        *,
        service: str,
        query: str,
        equals: Any = None,
        expected: Any = None,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        # Accept either `equals=` (legacy Python name) or `expected=` (TS
        # parity). Raise only if both are set AND disagree — consistent with
        # how strict kwargs usually behave.
        if equals is None and expected is None:
            raise TypeError("SQLEquals requires `expected=` (or legacy `equals=`)")
        if equals is not None and expected is not None and equals != expected:
            raise TypeError("SQLEquals: pass either `expected=` or `equals=`, not both")
        resolved = expected if expected is not None else equals
        self.name = f"sql:{service}"
        self.service = service
        self.query = query
        self.equals = resolved
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        return {
            "description": f"SQL check on {self.service}",
            "weight": self.weight,
            "gate": self.gate,
            "check": {
                "type": "sql",
                "service": self.service,
                "query": self.query,
                "equals": self.equals,
            },
        }

    def _rule_config(self) -> Dict[str, Any]:
        return {"service": self.service, "query": self.query, "equals": self.equals}


class LLMJudge(BaseScorer):
    """Use an LLM to judge the agent's output.

    Kept as a generic spec-level invariant for back-compat. For domain-
    specific scoring (factuality, faithfulness, summarization, etc.) prefer
    the dedicated judges in :mod:`polarity_keystone.scorers.llm_judge` —
    they share the same server-side execution model but ship with tuned
    prompts and parsers.
    """

    rule_type = "llm_as_judge"

    def __init__(
        self,
        criteria: str,
        *,
        model: str = "paragon-fast",
        input_from: str = "workspace",
        rubric: Optional[Dict[str, str]] = None,
        temperature: float = 0.0,
        weight: float = 1.0,
        gate: bool = False,
    ) -> None:
        self.name = "llm_judge"
        self.criteria = criteria
        self.model = model
        self.input_from = input_from
        self.rubric = rubric
        self.temperature = temperature
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        check: Dict[str, Any] = {
            "type": "llm_as_judge",
            "model": self.model,
            "criteria": self.criteria,
            "input_from": self.input_from,
            "temperature": self.temperature,
        }
        if self.rubric:
            check["rubric"] = self.rubric
        return {
            "description": self.criteria[:80],
            "weight": self.weight,
            "gate": self.gate,
            "check": check,
        }

    def _rule_config(self) -> Dict[str, Any]:
        return {
            "criteria": self.criteria,
            "model": self.model,
            "input_from": self.input_from,
            "rubric": self.rubric,
            "temperature": self.temperature,
        }
