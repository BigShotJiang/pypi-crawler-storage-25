"""Curated scorer presets for common agent shapes.

The 28 built-in scorers are organised across 5 families. Picking the
right ones for your eval is a paradox-of-choice problem on day one —
these presets are opinionated bundles that match the most common agent
shapes. They return plain lists, so you can `+` an extra scorer or two.

Usage::

    from polarity_keystone.scorers import presets

    results = ks.experiments.run_and_wait(exp.id, scores=presets.chat())

Three presets:

* :func:`chat` — general conversational quality (factuality, relevancy,
  moderation).
* :func:`rag` — retrieval-augmented generation (context precision/recall,
  faithfulness, answer relevancy).
* :func:`agent_with_tools` — agent that calls tools (JSON validity on
  tool args, factuality, answer relevancy).

Every preset accepts a ``model`` kwarg that's threaded into the
LLM-judge scorers; defaults to ``paragon-fast``.
"""

from __future__ import annotations

from typing import List

from .base import Scorer
from .heuristics import JSONValidity
from .llm_judge import Factuality, Moderation
from .rag import (
    AnswerRelevancy,
    ContextPrecision,
    ContextRecall,
    Faithfulness,
)


_DEFAULT_MODEL = "paragon-fast"


def chat(model: str = _DEFAULT_MODEL) -> List[Scorer]:
    """Scorers for general chat agents.

    * ``Factuality`` — does the answer match the ground truth?
    * ``AnswerRelevancy`` — does the answer address the question?
    * ``Moderation`` — is the response free of harmful content?

    Args:
        model: Judge model. Defaults to ``paragon-fast``.
    """
    return [
        Factuality(model=model),
        AnswerRelevancy(model=model),
        Moderation(model=model),
    ]


def rag(model: str = _DEFAULT_MODEL) -> List[Scorer]:
    """Scorers for retrieval-augmented generation pipelines.

    * ``ContextPrecision`` — are the retrieved chunks relevant?
    * ``ContextRecall`` — do the retrieved chunks contain enough info?
    * ``Faithfulness`` — is the answer grounded in the retrieved context?
    * ``AnswerRelevancy`` — does the answer address the question?

    Args:
        model: Judge model. Defaults to ``paragon-fast``.
    """
    return [
        ContextPrecision(model=model),
        ContextRecall(model=model),
        Faithfulness(model=model),
        AnswerRelevancy(model=model),
    ]


def agent_with_tools(model: str = _DEFAULT_MODEL) -> List[Scorer]:
    """Scorers for agents that call tools.

    * ``JSONValidity`` — every tool-call argument blob parses as JSON.
    * ``Factuality`` — does the final answer match the ground truth?
    * ``AnswerRelevancy`` — does the final answer address the user's
      request?

    Args:
        model: Judge model. Defaults to ``paragon-fast``.
    """
    return [
        JSONValidity(),
        Factuality(model=model),
        AnswerRelevancy(model=model),
    ]


__all__ = ["chat", "rag", "agent_with_tools"]
