"""Pricing helpers — parity with the TypeScript and Go SDKs.

Reads the per-model USD pricing table from the generated
:mod:`polarity_keystone.pricing_data` module (synced from
``sdk/pricing.json`` via ``sdk/scripts/sync-pricing.mjs``).
"""

from __future__ import annotations

from typing import Mapping

from .pricing_data import DEFAULT_CACHE_DISCOUNT, PRICING_DATA, PricingEntry


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_tokens: int = 0,
) -> float:
    """Estimate USD cost for a completion request.

    - Tries exact model-name match first, then partial (for versioned names).
    - Cache-read tokens are discounted by ``DEFAULT_CACHE_DISCOUNT`` against
      input pricing. Matches TS ``estimateCost`` and Go ``EstimateCost``
      byte-for-byte.
    """
    pricing = PRICING_DATA.get(model)
    if pricing is None:
        lower = str(model).lower()
        for key, entry in PRICING_DATA.items():
            if key in lower or lower.startswith(key):
                pricing = entry
                break
    if pricing is None:
        return 0.0

    input_cost = (input_tokens * pricing["input"]) / 1_000_000
    output_cost = (output_tokens * pricing["output"]) / 1_000_000
    cache_discount = (
        (cache_tokens * pricing["input"] * DEFAULT_CACHE_DISCOUNT) / 1_000_000
        if cache_tokens > 0
        else 0.0
    )
    return round(input_cost + output_cost - cache_discount, 6)


def pricing_table() -> Mapping[str, PricingEntry]:
    """Read-only view of the full pricing table."""
    return dict(PRICING_DATA)
