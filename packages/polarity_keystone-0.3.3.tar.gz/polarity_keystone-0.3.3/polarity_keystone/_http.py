"""Internal HTTP helper for the Keystone SDK.

Uses only ``urllib.request`` -- zero external dependencies.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Dict, Optional, Union

from .types import KeystoneError


class HTTPClient:
    """Low-level HTTP transport for Keystone API calls."""

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str],
        timeout: int,
        workspace: Optional[str] = None,
    ) -> None:
        # Strip trailing slash so callers can use "/v1/..." paths directly.
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        # `workspace` is the raw selector the caller supplied (id like
        # `ws_<hex>` or name like `search-assistant`). Sent on every
        # request as X-Polarity-Workspace; the server resolves name → id
        # lazily.
        self.workspace = workspace

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def get(self, path: str) -> Any:
        """Perform a GET request and return decoded JSON (or None for 204)."""
        return self._request("GET", path)

    def get_bytes(self, path: str) -> bytes:
        """Perform a GET request and return the raw response body."""
        return self._request_bytes("GET", path)

    def post(self, path: str, body: Any = None) -> Any:
        """Perform a POST request with a JSON body."""
        return self._request("POST", path, body=body)

    def post_raw(self, path: str, data: bytes, content_type: str = "application/x-yaml") -> Any:
        """Perform a POST request with a raw body (e.g. YAML)."""
        return self._request("POST", path, raw_data=data, content_type=content_type)

    def post_multipart(
        self,
        path: str,
        fields: "Dict[str, str] | None" = None,
        files: "Dict[str, tuple] | None" = None,
    ) -> Any:
        """Perform a POST with multipart/form-data encoding.

        Args:
            fields: String key-value pairs.
            files: File fields as ``{name: (filename, data_bytes, content_type)}``.
        """
        import uuid
        boundary = uuid.uuid4().hex
        body = b""

        for name, value in (fields or {}).items():
            body += f"--{boundary}\r\n".encode()
            body += f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
            body += value.encode("utf-8") + b"\r\n"

        for name, (filename, data, ct) in (files or {}).items():
            body += f"--{boundary}\r\n".encode()
            body += f'Content-Disposition: form-data; name="{name}"; filename="{filename}"\r\n'.encode()
            body += f"Content-Type: {ct}\r\n\r\n".encode()
            if isinstance(data, str):
                data = data.encode("utf-8")
            body += data + b"\r\n"

        body += f"--{boundary}--\r\n".encode()

        return self._request(
            "POST", path, raw_data=body,
            content_type=f"multipart/form-data; boundary={boundary}",
        )

    def delete(self, path: str) -> None:
        """Perform a DELETE request. Returns None."""
        self._request("DELETE", path)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _build_request(
        self,
        method: str,
        path: str,
        data: Optional[bytes] = None,
        content_type: str = "application/json",
    ) -> urllib.request.Request:
        url = self.base_url + urllib.request.quote(path, safe="/:@!$&'()*+,;=-._~?#[]")
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Accept", "application/json")
        # Override urllib's default User-Agent — Cloudflare bot protection
        # (error 1010) blocks `Python-urllib/3.x` by default on prod edges.
        # Use a stable, identifiable agent so ops can see the SDK version
        # in logs and whitelist it distinctly from generic bot traffic.
        req.add_header("User-Agent", "polarity-python/0.3.0")
        if data is not None:
            req.add_header("Content-Type", content_type)
        if self.api_key:
            req.add_header("Authorization", f"Bearer {self.api_key}")
        if self.workspace:
            req.add_header("X-Polarity-Workspace", self.workspace)
        return req

    def _request(
        self,
        method: str,
        path: str,
        body: Any = None,
        raw_data: Optional[bytes] = None,
        content_type: str = "application/json",
    ) -> Any:
        data: Optional[bytes] = None
        ct = content_type

        if raw_data is not None:
            data = raw_data
            ct = content_type
        elif body is not None:
            data = json.dumps(body).encode("utf-8")
            ct = "application/json"

        req = self._build_request(method, path, data=data, content_type=ct)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                status = resp.status
                if status == 204:
                    return None
                resp_body = resp.read()
                if not resp_body:
                    return None
                return json.loads(resp_body)
        except urllib.error.HTTPError as exc:
            error_body = exc.read().decode("utf-8", errors="replace")
            message = error_body
            try:
                parsed = json.loads(error_body)
                if isinstance(parsed, dict) and "error" in parsed:
                    message = parsed["error"]
            except (json.JSONDecodeError, ValueError):
                pass
            raise KeystoneError(exc.code, message) from exc
        except urllib.error.URLError as exc:
            raise KeystoneError(0, f"Connection error: {exc.reason}") from exc

    def _request_bytes(self, method: str, path: str) -> bytes:
        req = self._build_request(method, path)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as exc:
            error_body = exc.read().decode("utf-8", errors="replace")
            message = error_body
            try:
                parsed = json.loads(error_body)
                if isinstance(parsed, dict) and "error" in parsed:
                    message = parsed["error"]
            except (json.JSONDecodeError, ValueError):
                pass
            raise KeystoneError(exc.code, message) from exc
        except urllib.error.URLError as exc:
            raise KeystoneError(0, f"Connection error: {exc.reason}") from exc
