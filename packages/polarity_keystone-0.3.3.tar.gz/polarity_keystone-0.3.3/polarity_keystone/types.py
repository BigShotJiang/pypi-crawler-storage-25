"""Type definitions for the Keystone SDK."""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


class KeystoneError(Exception):
    """Raised when the Polarity API returns a non-2xx response.

    Kept as a backwards-compatible name; new code should use
    :class:`PolarityError` (a subclass — ``isinstance`` works both ways).
    """

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"Polarity API error ({status_code}): {message}")


class PolarityError(KeystoneError):
    """Raised when the Polarity API returns a non-2xx response.

    Inherits from :class:`KeystoneError` so existing
    ``except KeystoneError`` blocks keep catching these.
    """
    pass


# ---------------------------------------------------------------------------
# Sandbox types
# ---------------------------------------------------------------------------


@dataclass
class ServiceInfo:
    """Connection details for a running backing service."""

    host: str = ""
    port: int = 0
    ready: bool = False

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ServiceInfo":
        if data is None:
            return cls()
        return cls(
            host=data.get("host", ""),
            port=data.get("port", 0),
            ready=data.get("ready", False),
        )


@dataclass
class ConfigFile:
    """A template-rendered file written into the sandbox."""

    path: str = ""
    template: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConfigFile":
        if data is None:
            return cls()
        return cls(path=data.get("path", ""), template=data.get("template", ""))


@dataclass
class AgentAuth:
    """Declares what credentials an agent snapshot needs."""

    required_env: List[str] = field(default_factory=list)
    config_files: List[ConfigFile] = field(default_factory=list)
    egress: Dict[str, List[str]] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentAuth":
        if data is None:
            return cls()
        config_files = [
            ConfigFile.from_dict(cf) for cf in (data.get("config_files") or [])
        ]
        return cls(
            required_env=data.get("required_env") or [],
            config_files=config_files,
            egress=data.get("egress") or {},
        )


@dataclass
class AgentSnapshot:
    """A versioned, content-addressed agent bundle.

    Resolve once via ``AgentService.get()``, then pass the object around.
    The ``id`` field is immutable — use it in specs and API calls.
    """

    id: str = ""
    name: str = ""
    version: int = 0
    tag: str = ""
    digest: str = ""
    size_bytes: int = 0
    storage_path: str = ""
    runtime: str = ""
    entrypoint: List[str] = field(default_factory=list)
    auth: Optional[AgentAuth] = None
    created_at: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentSnapshot":
        if data is None:
            return cls()
        auth = None
        if data.get("auth"):
            auth = AgentAuth.from_dict(data["auth"])
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            version=data.get("version", 0),
            tag=data.get("tag", ""),
            digest=data.get("digest", ""),
            size_bytes=data.get("size_bytes", 0),
            storage_path=data.get("storage_path", ""),
            runtime=data.get("runtime", ""),
            entrypoint=data.get("entrypoint") or [],
            auth=auth,
            created_at=data.get("created_at", ""),
        )


@dataclass
class Sandbox:
    """Represents an isolated workspace managed by Keystone."""

    id: str = ""
    spec_id: str = ""
    state: str = ""
    path: str = ""
    url: str = ""
    created_at: str = ""
    metadata: Dict[str, str] = field(default_factory=dict)
    services: Dict[str, ServiceInfo] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Sandbox":
        if data is None:
            return cls()
        services = {}
        for name, svc_data in (data.get("services") or {}).items():
            services[name] = ServiceInfo.from_dict(svc_data) if isinstance(svc_data, dict) else svc_data
        return cls(
            id=data.get("id", ""),
            spec_id=data.get("spec_id", ""),
            state=data.get("state", ""),
            path=data.get("path", ""),
            url=data.get("url", ""),
            created_at=data.get("created_at", ""),
            metadata=data.get("metadata") or {},
            services=services,
        )


@dataclass
class CommandResult:
    """Output of a command executed inside a sandbox."""

    command: str = ""
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    duration_ms: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CommandResult":
        if data is None:
            return cls()
        return cls(
            command=data.get("command", ""),
            stdout=data.get("stdout", ""),
            stderr=data.get("stderr", ""),
            exit_code=data.get("exit_code", 0),
            duration_ms=data.get("duration_ms", 0),
        )


@dataclass
class FileState:
    """Metadata and checksum for a single file in a snapshot."""

    size: int = 0
    mode: str = ""
    checksum: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FileState":
        if data is None:
            return cls()
        return cls(
            size=data.get("size", 0),
            mode=data.get("mode", ""),
            checksum=data.get("checksum", ""),
        )


@dataclass
class StateSnapshot:
    """Filesystem state at a point in time."""

    captured_at: str = ""
    files: Dict[str, FileState] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StateSnapshot":
        if data is None:
            return cls()
        files = {}
        for path, fs_data in (data.get("files") or {}).items():
            files[path] = FileState.from_dict(fs_data) if isinstance(fs_data, dict) else fs_data
        return cls(
            captured_at=data.get("captured_at", ""),
            files=files,
        )


@dataclass
class StateDiff:
    """Changes between two snapshots."""

    added: List[str] = field(default_factory=list)
    removed: List[str] = field(default_factory=list)
    modified: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StateDiff":
        if data is None:
            return cls()
        return cls(
            added=data.get("added") or [],
            removed=data.get("removed") or [],
            modified=data.get("modified") or [],
        )


# ---------------------------------------------------------------------------
# Spec types
# ---------------------------------------------------------------------------


@dataclass
class SandboxSpec:
    """A sandbox specification. Specs are complex YAML structures, so this is
    a thin wrapper around the raw dictionary returned by the API."""

    id: str = ""
    version: int = 0
    description: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SandboxSpec":
        if data is None:
            return cls()
        return cls(
            id=data.get("id", ""),
            version=data.get("version", 0),
            description=data.get("description", ""),
            raw=data,
        )


# ---------------------------------------------------------------------------
# Experiment types
# ---------------------------------------------------------------------------


@dataclass
class Experiment:
    """A batch of scenario runs against a spec."""

    id: str = ""
    name: str = ""
    spec_id: str = ""
    status: str = ""
    created_at: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Experiment":
        if data is None:
            return cls()
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            spec_id=data.get("spec_id", ""),
            status=data.get("status", ""),
            created_at=data.get("created_at", ""),
        )


@dataclass
class CostInfo:
    """Token usage and estimated cost for a scenario."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    model: str = ""
    estimated_usd: float = 0.0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CostInfo":
        if data is None:
            return cls()
        return cls(
            input_tokens=data.get("input_tokens", 0),
            output_tokens=data.get("output_tokens", 0),
            cache_read_tokens=data.get("cache_read_tokens", 0),
            model=data.get("model", ""),
            estimated_usd=data.get("estimated_usd", 0.0),
        )


@dataclass
class InvariantResult:
    """Pass/fail outcome of a single invariant check."""

    name: str = ""
    passed: bool = False
    gate: bool = False
    weight: float = 0.0
    score: float = 0.0
    message: str = ""
    reason: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "InvariantResult":
        if data is None:
            return cls()
        return cls(
            name=data.get("name", ""),
            passed=data.get("passed", False),
            gate=data.get("gate", False),
            weight=data.get("weight", 0.0),
            score=data.get("score", 0.0),
            message=data.get("message", ""),
            reason=data.get("reason", ""),
        )


@dataclass
class ForbiddenCheckResult:
    """Reports a trajectory constraint violation."""

    rule: str = ""
    violated: bool = False
    details: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ForbiddenCheckResult":
        if data is None:
            return cls()
        return cls(
            rule=data.get("rule", ""),
            violated=data.get("violated", False),
            details=data.get("details", ""),
        )


@dataclass
class Reproducer:
    """Minimal info needed to reproduce a failure."""

    spec_file: str = ""
    seed: int = 0
    scenario_id: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    command: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Reproducer":
        if data is None:
            return cls()
        return cls(
            spec_file=data.get("spec_file", ""),
            seed=data.get("seed", 0),
            scenario_id=data.get("scenario_id", ""),
            parameters=data.get("parameters") or {},
            command=data.get("command", ""),
        )


@dataclass
class ScenarioResult:
    """Results for a single scenario execution."""

    scenario_id: str = ""
    sandbox_id: str = ""
    status: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    wall_ms: int = 0
    exit_code: int = 0
    tool_calls: int = 0
    composite_score: float = 0.0
    agent_output: str = ""
    agent_stderr: str = ""
    invariants: List[InvariantResult] = field(default_factory=list)
    forbidden_checks: List[ForbiddenCheckResult] = field(default_factory=list)
    trace_file: str = ""
    reproducer: Optional[Reproducer] = None
    error: str = ""
    cost: Optional[CostInfo] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ScenarioResult":
        if data is None:
            return cls()
        invariants = [
            InvariantResult.from_dict(i) for i in (data.get("invariants") or [])
        ]
        forbidden_checks = [
            ForbiddenCheckResult.from_dict(f) for f in (data.get("forbidden_checks") or [])
        ]
        reproducer = None
        if data.get("reproducer"):
            reproducer = Reproducer.from_dict(data["reproducer"])
        cost = None
        if data.get("cost"):
            cost = CostInfo.from_dict(data["cost"])
        return cls(
            scenario_id=data.get("scenario_id", ""),
            sandbox_id=data.get("sandbox_id", ""),
            status=data.get("status", ""),
            parameters=data.get("parameters") or {},
            wall_ms=data.get("wall_ms", 0),
            exit_code=data.get("exit_code", 0),
            tool_calls=data.get("tool_calls", 0),
            composite_score=data.get("composite_score", 0.0),
            agent_output=data.get("agent_output", ""),
            agent_stderr=data.get("agent_stderr", ""),
            invariants=invariants,
            forbidden_checks=forbidden_checks,
            trace_file=data.get("trace_file", ""),
            reproducer=reproducer,
            error=data.get("error", ""),
            cost=cost,
        )


@dataclass
class RunMetrics:
    """Aggregate metrics for a run."""

    pass_rate: float = 0.0
    mean_wall_ms: int = 0
    p95_wall_ms: int = 0
    mean_tool_calls: float = 0.0
    mean_tokens: int = 0
    total_cost_usd: float = 0.0
    mean_cost_per_run_usd: float = 0.0
    tool_success_rate: float = 0.0
    side_effect_violations: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RunMetrics":
        if data is None:
            return cls()
        return cls(
            pass_rate=data.get("pass_rate", 0.0),
            mean_wall_ms=data.get("mean_wall_ms", 0),
            p95_wall_ms=data.get("p95_wall_ms", 0),
            mean_tool_calls=data.get("mean_tool_calls", 0.0),
            mean_tokens=data.get("mean_tokens", 0),
            total_cost_usd=data.get("total_cost_usd", 0.0),
            mean_cost_per_run_usd=data.get("mean_cost_per_run_usd", 0.0),
            tool_success_rate=data.get("tool_success_rate", 0.0),
            side_effect_violations=data.get("side_effect_violations", 0),
        )


@dataclass
class RunResults:
    """Top-level output of a Keystone experiment run."""

    ran_at: str = ""
    spec_id: str = ""
    experiment_id: str = ""
    seed: int = 0
    total_scenarios: int = 0
    passed: int = 0
    failed: int = 0
    flaky: int = 0
    errors: int = 0
    metrics: RunMetrics = field(default_factory=RunMetrics)
    scenarios: List[ScenarioResult] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RunResults":
        if data is None:
            return cls()
        scenarios = [
            ScenarioResult.from_dict(s) for s in (data.get("scenarios") or [])
        ]
        metrics = RunMetrics.from_dict(data.get("metrics") or {})
        return cls(
            ran_at=data.get("ran_at", ""),
            spec_id=data.get("spec_id", ""),
            experiment_id=data.get("experiment_id", ""),
            seed=data.get("seed", 0),
            total_scenarios=data.get("total_scenarios", 0),
            passed=data.get("passed", 0),
            failed=data.get("failed", 0),
            flaky=data.get("flaky", 0),
            errors=data.get("errors", 0),
            metrics=metrics,
            scenarios=scenarios,
        )


# ---------------------------------------------------------------------------
# Comparison types
# ---------------------------------------------------------------------------


@dataclass
class MetricComparison:
    """A single metric compared across baseline and candidate."""

    name: str = ""
    baseline: float = 0.0
    candidate: float = 0.0
    delta: float = 0.0
    direction: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MetricComparison":
        if data is None:
            return cls()
        return cls(
            name=data.get("name", ""),
            baseline=data.get("baseline", 0.0),
            candidate=data.get("candidate", 0.0),
            delta=data.get("delta", 0.0),
            direction=data.get("direction", ""),
        )


@dataclass
class Comparison:
    """Side-by-side comparison of two experiment runs."""

    baseline_id: str = ""
    candidate_id: str = ""
    metrics: List[MetricComparison] = field(default_factory=list)
    regressed: bool = False
    regressions: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Comparison":
        if data is None:
            return cls()
        metrics = [
            MetricComparison.from_dict(m) for m in (data.get("metrics") or [])
        ]
        return cls(
            baseline_id=data.get("baseline_id", ""),
            candidate_id=data.get("candidate_id", ""),
            metrics=metrics,
            regressed=data.get("regressed", False),
            regressions=data.get("regressions") or [],
        )


# ---------------------------------------------------------------------------
# Metrics types
# ---------------------------------------------------------------------------


@dataclass
class ToolMetric:
    """Per-tool aggregated metrics."""

    count: int = 0
    mean_ms: int = 0
    error_rate: float = 0.0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ToolMetric":
        if data is None:
            return cls()
        return cls(
            count=data.get("count", 0),
            mean_ms=data.get("mean_ms", 0),
            error_rate=data.get("error_rate", 0.0),
        )


@dataclass
class MetricsSummary:
    """Top-level aggregate for an experiment's metrics."""

    total_runs: int = 0
    pass_rate: float = 0.0
    total_cost_usd: float = 0.0
    mean_cost_per_run_usd: float = 0.0
    mean_wall_ms: int = 0
    p95_wall_ms: int = 0
    total_tool_calls: int = 0
    tool_success_rate: float = 0.0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MetricsSummary":
        if data is None:
            return cls()
        return cls(
            total_runs=data.get("total_runs", 0),
            pass_rate=data.get("pass_rate", 0.0),
            total_cost_usd=data.get("total_cost_usd", 0.0),
            mean_cost_per_run_usd=data.get("mean_cost_per_run_usd", 0.0),
            mean_wall_ms=data.get("mean_wall_ms", 0),
            p95_wall_ms=data.get("p95_wall_ms", 0),
            total_tool_calls=data.get("total_tool_calls", 0),
            tool_success_rate=data.get("tool_success_rate", 0.0),
        )


@dataclass
class CostDataPoint:
    """One point in the cost trend."""

    run_id: str = ""
    cost_usd: float = 0.0
    ts: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CostDataPoint":
        if data is None:
            return cls()
        return cls(
            run_id=data.get("run_id", ""),
            cost_usd=data.get("cost_usd", 0.0),
            ts=data.get("ts", ""),
        )


@dataclass
class PassRateDataPoint:
    """One point in the pass rate trend."""

    run_id: str = ""
    pass_rate: float = 0.0
    ts: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PassRateDataPoint":
        if data is None:
            return cls()
        return cls(
            run_id=data.get("run_id", ""),
            pass_rate=data.get("pass_rate", 0.0),
            ts=data.get("ts", ""),
        )


@dataclass
class ExperimentMetrics:
    """Full metrics response for an experiment."""

    experiment_id: str = ""
    summary: MetricsSummary = field(default_factory=MetricsSummary)
    tool_breakdown: Dict[str, ToolMetric] = field(default_factory=dict)
    cost_trend: List[CostDataPoint] = field(default_factory=list)
    pass_rate_trend: List[PassRateDataPoint] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExperimentMetrics":
        if data is None:
            return cls()
        summary = MetricsSummary.from_dict(data.get("summary") or {})
        tool_breakdown = {
            name: ToolMetric.from_dict(td) if isinstance(td, dict) else td
            for name, td in (data.get("tool_breakdown") or {}).items()
        }
        cost_trend = [
            CostDataPoint.from_dict(c) for c in (data.get("cost_trend") or [])
        ]
        pass_rate_trend = [
            PassRateDataPoint.from_dict(p) for p in (data.get("pass_rate_trend") or [])
        ]
        return cls(
            experiment_id=data.get("experiment_id", ""),
            summary=summary,
            tool_breakdown=tool_breakdown,
            cost_trend=cost_trend,
            pass_rate_trend=pass_rate_trend,
        )


# ---------------------------------------------------------------------------
# Alert types
# ---------------------------------------------------------------------------


@dataclass
class AlertRule:
    """A condition that triggers a notification."""

    id: str = ""
    name: str = ""
    eval_id: str = ""
    condition: str = ""
    window: str = ""
    notify: str = ""
    webhook_url: str = ""
    slack_channel: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AlertRule":
        if data is None:
            return cls()
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            eval_id=data.get("eval_id", ""),
            condition=data.get("condition", ""),
            window=data.get("window", ""),
            notify=data.get("notify", ""),
            webhook_url=data.get("webhook_url", ""),
            slack_channel=data.get("slack_channel", ""),
        )


@dataclass
class AlertFiring:
    """A triggered alert."""

    rule_id: str = ""
    rule_name: str = ""
    reason: str = ""
    experiment_id: str = ""
    fired_at: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AlertFiring":
        if data is None:
            return cls()
        return cls(
            rule_id=data.get("rule_id", ""),
            rule_name=data.get("rule_name", ""),
            reason=data.get("reason", ""),
            experiment_id=data.get("experiment_id", ""),
            fired_at=data.get("fired_at", ""),
        )


# ---------------------------------------------------------------------------
# Regression types
# ---------------------------------------------------------------------------


@dataclass
class EvalHistoryPoint:
    """A single point in an eval's historical trend."""

    experiment_id: str = ""
    pass_rate: float = 0.0
    mean_wall_ms: int = 0
    total_cost_usd: float = 0.0
    ts: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalHistoryPoint":
        if data is None:
            return cls()
        return cls(
            experiment_id=data.get("experiment_id", ""),
            pass_rate=data.get("pass_rate", 0.0),
            mean_wall_ms=data.get("mean_wall_ms", 0),
            total_cost_usd=data.get("total_cost_usd", 0.0),
            ts=data.get("ts", ""),
        )
