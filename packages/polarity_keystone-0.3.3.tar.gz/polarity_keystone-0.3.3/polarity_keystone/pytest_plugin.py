"""Pytest plugin: turns ``polarity_score(scorer, ...)`` calls into Eval rows.

Usage:

    def test_summary(polarity_score):
        out = summarize("Long text…")
        polarity_score(Factuality(expected="Short"), input="Long text…",
                       output=out, min=0.8)

The plugin:
  * Registers a ``polarity_score`` fixture (and ``keystone_score`` as a
    backwards-compatible alias).
  * Buffers each call into a per-module list.
  * On ``pytest_sessionfinish``, posts one Eval per module to the dashboard
    using the same /v1/traces event shape as ``Eval()``.
  * If a ``min`` is supplied and the scorer returns below it, raises
    AssertionError so pytest reports the test as failed.

Loaded via the ``pytest11`` entry point in pyproject.toml.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List

import pytest

from ._compat import get_env
from .eval import _aggregate, _make_scenario, _score_one
from .scorers.base import BaseScorer


# Module-level buffer keyed by test file path. Each entry is a list of dicts
# with nodeid / scorer / input / output / expected / score.
_buffer: "Dict[str, List[Dict[str, Any]]]" = defaultdict(list)


def pytest_addoption(parser: Any) -> None:
    group = parser.getgroup("polarity")
    group.addoption(
        "--polarity-no-flush",
        action="store_true",
        default=False,
        help="Skip posting buffered scores to the Polarity dashboard at session end.",
    )
    # Legacy flag — keep working for existing users / CI configs.
    group.addoption(
        "--keystone-no-flush",
        action="store_true",
        default=False,
        help="Deprecated alias for --polarity-no-flush.",
    )


def _no_flush(config: Any) -> bool:
    return bool(
        config.getoption("--polarity-no-flush")
        or config.getoption("--keystone-no-flush")
    )


def _record_score(buffer_path: str, request: Any, scorer: BaseScorer, input: Any,
                  output: Any, expected: Any, min: float) -> float:
    scenario = _make_scenario(input, output, expected)
    try:
        value = _score_one(scorer, scenario, expected)
    except Exception as exc:  # noqa: BLE001
        raise AssertionError(
            f"polarity_score: scorer {scorer.name} raised: {exc}"
        ) from exc
    if value is None:
        value = 0.0

    _buffer[buffer_path].append({
        "nodeid": request.node.nodeid,
        "scorer": scorer.name,
        "input": input,
        "output": output,
        "expected": expected,
        "score": value,
    })

    if min is not None and value < float(min):
        raise AssertionError(
            f"polarity_score: {scorer.name} = {value:.3f} < min "
            f"{float(min):.3f} for nodeid {request.node.nodeid}"
        )
    return value


@pytest.fixture
def polarity_score(request: Any):
    """Per-test scoring callable. Records score; raises if min violated."""

    def _score(
        scorer: BaseScorer,
        *,
        input: Any,
        output: Any,
        expected: Any = None,
        min: float = None,
    ) -> float:
        return _record_score(
            str(request.node.fspath), request, scorer, input, output, expected, min,
        )

    return _score


@pytest.fixture
def keystone_score(polarity_score):
    """Backwards-compatible alias for :func:`polarity_score`."""
    return polarity_score


def pytest_sessionfinish(session: Any, exitstatus: int) -> None:
    """Flush buffered scores: one experiment per test module."""
    if _no_flush(session.config):
        _buffer.clear()
        return
    api_key = get_env("POLARITY_API_KEY", "KEYSTONE_API_KEY")
    by_module = dict(_buffer)
    _buffer.clear()
    if not by_module:
        return

    if not api_key:
        for path, rows in by_module.items():
            summary = _summarize_rows(rows)
            print(f"polarity: {path} → {len(rows)} scored rows | summary={summary}")
        return

    for path, rows in by_module.items():
        summary = _summarize_rows(rows)
        try:
            span_id = _post_module_eval(path, rows, summary)
            print(f"polarity: posted eval {path} → span={span_id} rows={len(rows)}")
        except Exception as exc:  # noqa: BLE001
            print(f"polarity: failed to post eval {path}: {exc}")


def _summarize_rows(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
    by_scorer: Dict[str, List[float]] = defaultdict(list)
    for row in rows:
        by_scorer[row["scorer"]].append(float(row["score"]))
    return {name: _aggregate(values) for name, values in by_scorer.items()}


def _post_module_eval(
    name: str,
    rows: List[Dict[str, Any]],
    summary: Dict[str, Any],
) -> str:
    """POST a single eval event for one module's rows."""
    from datetime import datetime, timezone
    import uuid as _uuid

    from .client import Keystone

    ks = Keystone()
    span_id = f"span_eval_{_uuid.uuid4().hex[:12]}"
    event = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "event_type": "eval",
        "tool": f"Eval:pytest::{name}",
        "phase": "complete",
        "span_id": span_id,
        "status": "ok",
        "duration_ms": 0,
        "metadata": {
            "eval.name": f"pytest::{name}",
            "eval.rows": len(rows),
            "eval.summary": summary,
            "eval.source": "pytest",
        },
    }
    ks._http.post("/v1/traces", {"events": [event]})
    return span_id
