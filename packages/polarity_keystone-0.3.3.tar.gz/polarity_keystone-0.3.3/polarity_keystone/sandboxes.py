"""Sandbox operations for the Keystone SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ._http import HTTPClient
from .types import CommandResult, Sandbox, StateDiff, StateSnapshot


class SandboxHandle:
    """Bound handle around a single sandbox.

    Returned by :meth:`SandboxService.create`, :meth:`SandboxService.get`, and
    :meth:`SandboxService.handle`. Mirrors the E2B-style "sandbox is the
    agent's tool" mental model — methods like :meth:`exec` / :meth:`read` /
    :meth:`write` are bound to the sandbox ID so the caller doesn't keep
    typing it.

    Attribute access falls through to the underlying :class:`Sandbox`
    metadata, so existing code that reads ``sb.id`` / ``sb.state`` keeps
    working unchanged.
    """

    __slots__ = ("_info", "_svc")

    def __init__(self, info: Sandbox, svc: "SandboxService") -> None:
        object.__setattr__(self, "_info", info)
        object.__setattr__(self, "_svc", svc)

    # -- attribute passthrough --------------------------------------------------
    def __getattr__(self, name: str) -> Any:
        # Only called when the attribute isn't found on the class — methods
        # defined below take precedence. Fall through to the metadata struct.
        info = object.__getattribute__(self, "_info")
        return getattr(info, name)

    @property
    def info(self) -> Sandbox:
        """Underlying :class:`Sandbox` metadata."""
        return self._info

    def __repr__(self) -> str:
        return f"SandboxHandle(id={self._info.id!r}, state={self._info.state!r})"

    # -- bound methods ----------------------------------------------------------
    def exec(self, command: str, timeout: Optional[str] = None) -> CommandResult:
        """Run a shell command inside the sandbox."""
        return self._svc.run_command(self._info.id, command, timeout)

    def read(self, path: str) -> bytes:
        """Read a file from the workspace."""
        return self._svc.read_file(self._info.id, path)

    def write(self, path: str, content: str) -> None:
        """Write a file to the workspace."""
        self._svc.write_file(self._info.id, path, content)

    def delete(self, path: str) -> None:
        """Delete a file from the workspace."""
        self._svc.delete_file(self._info.id, path)

    def get_state(self) -> StateSnapshot:
        """Capture the current filesystem state."""
        return self._svc.state(self._info.id)

    def diff(self) -> StateDiff:
        """Diff the current state against the baseline snapshot."""
        return self._svc.diff(self._info.id)

    def destroy(self) -> None:
        """Destroy the sandbox and clean up all resources."""
        self._svc.destroy(self._info.id)

    def ingest_trace(self, events: list) -> dict:
        """Post tool-call trace events from the agent."""
        return self._svc.ingest_trace(self._info.id, events)

    def get_trace(self) -> dict:
        """Fetch trace events + computed metrics."""
        return self._svc.get_trace(self._info.id)

    def refresh(self) -> "SandboxHandle":
        """Re-fetch metadata from the server (state may have changed)."""
        fresh = self._svc.get_info(self._info.id)
        object.__setattr__(self, "_info", fresh)
        return self


class SandboxService:
    """CRUD and interaction operations for Keystone sandboxes."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(
        self,
        spec_id: str,
        timeout: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        *,
        secrets: Optional[Dict[str, str]] = None,
        spec_path: Optional[str] = None,
    ) -> SandboxHandle:
        """Create a new sandbox from a spec. Returns a bound handle.

        Args:
            spec_id: ID of the spec to create the sandbox from.
            timeout: Optional duration string (e.g. ``"10m"``).
            metadata: Optional key-value metadata.
            secrets: Optional explicit runtime secrets. Merged with Dashboard
                secrets on the server; these win.
            spec_path: Optional path to a local spec YAML. When set, the SDK
                parses the ``secrets:`` declarations and auto-forwards matching
                ``os.environ`` values. Explicit ``secrets`` take priority.
        """
        body: Dict[str, Any] = {"spec_id": spec_id}
        if timeout is not None:
            body["timeout"] = timeout
        if metadata is not None:
            body["metadata"] = metadata
        merged: Dict[str, str] = {}
        if spec_path:
            from .env_secrets import collect_declared_secrets_from_file
            merged.update(collect_declared_secrets_from_file(spec_path))
        if secrets:
            merged.update(secrets)  # explicit wins
        if merged:
            body["secrets"] = merged
        data = self._http.post("/v1/sandboxes", body)
        return SandboxHandle(Sandbox.from_dict(data), self)

    def get(self, sandbox_id: str) -> SandboxHandle:
        """Get a sandbox by ID. Returns a bound handle."""
        data = self._http.get(f"/v1/sandboxes/{sandbox_id}")
        return SandboxHandle(Sandbox.from_dict(data), self)

    def handle(self, sandbox_id: str) -> SandboxHandle:
        """Build a bound handle from an ID without making a network call."""
        return SandboxHandle(Sandbox(id=sandbox_id), self)

    def get_info(self, sandbox_id: str) -> Sandbox:
        """Get raw :class:`Sandbox` metadata for an ID without wrapping."""
        data = self._http.get(f"/v1/sandboxes/{sandbox_id}")
        return Sandbox.from_dict(data)

    def list(self) -> List[SandboxHandle]:
        """List all active sandboxes. Returns bound handles."""
        data = self._http.get("/v1/sandboxes")
        if data is None:
            return []
        return [SandboxHandle(Sandbox.from_dict(item), self) for item in data]

    def destroy(self, sandbox_id: str) -> None:
        """Destroy a sandbox and clean up all its resources."""
        self._http.delete(f"/v1/sandboxes/{sandbox_id}")

    def run_command(
        self,
        sandbox_id: str,
        command: str,
        timeout: Optional[str] = None,
    ) -> CommandResult:
        """Execute a shell command inside a sandbox.

        Args:
            sandbox_id: Target sandbox.
            command: Shell command to run.
            timeout: Optional duration string (e.g. ``"30s"``).
        """
        body: Dict[str, Any] = {"command": command}
        if timeout is not None:
            body["timeout"] = timeout
        data = self._http.post(f"/v1/sandboxes/{sandbox_id}/commands", body)
        return CommandResult.from_dict(data)

    def read_file(self, sandbox_id: str, path: str) -> bytes:
        """Read a file from the sandbox workspace.

        Returns the raw bytes of the file.
        """
        return self._http.get_bytes(f"/v1/sandboxes/{sandbox_id}/files/{path}")

    def write_file(self, sandbox_id: str, path: str, content: str) -> None:
        """Write a file to the sandbox workspace.

        Args:
            sandbox_id: Target sandbox.
            path: Relative file path inside the sandbox.
            content: File content as a string.
        """
        self._http.post(f"/v1/sandboxes/{sandbox_id}/files", {"path": path, "content": content})

    def delete_file(self, sandbox_id: str, path: str) -> None:
        """Delete a file from the sandbox workspace."""
        self._http.delete(f"/v1/sandboxes/{sandbox_id}/files/{path}")

    def state(self, sandbox_id: str) -> StateSnapshot:
        """Capture the current filesystem state of a sandbox."""
        data = self._http.get(f"/v1/sandboxes/{sandbox_id}/state")
        return StateSnapshot.from_dict(data)

    def diff(self, sandbox_id: str) -> StateDiff:
        """Get the diff between the before-run snapshot and current state."""
        data = self._http.get(f"/v1/sandboxes/{sandbox_id}/diff")
        return StateDiff.from_dict(data)

    def ingest_trace(self, sandbox_id: str, events: list) -> dict:
        """Post tool call trace events to a sandbox.

        Any agent can use this to report what it did. Keystone uses these
        for scoring, metrics, and observability.

        Args:
            sandbox_id: Target sandbox.
            events: List of trace event dicts with keys like:
                ts, event_type, tool, phase, duration_ms, status,
                input_bytes, output_bytes, cost
        """
        return self._http.post(
            f"/v1/sandboxes/{sandbox_id}/trace", {"events": events}
        )

    def get_trace(self, sandbox_id: str) -> dict:
        """Get trace events and computed metrics for a sandbox.

        Returns dict with 'events' (list) and 'metrics' (dict).
        """
        return self._http.get(f"/v1/sandboxes/{sandbox_id}/trace")
