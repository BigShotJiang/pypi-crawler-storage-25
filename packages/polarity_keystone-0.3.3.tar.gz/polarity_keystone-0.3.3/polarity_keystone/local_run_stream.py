"""Local run stream event types + encoder/decoder, mirroring the
@cursor/sdk surface. The Keystone Paragon server emits SSE in this
shape; these helpers let SDK consumers parse those events into typed
values, or wrap their own loop's output the same way.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from typing import Any, AsyncIterator, Dict, Iterator, List, Literal, Optional, Union


# ─── Event shapes ─────────────────────────────────────────────────────

@dataclass
class RunUsage:
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    total_tokens: Optional[int] = None
    cost_usd: Optional[float] = None


@dataclass
class RunResultEvent:
    run_id: str
    exit_reason: Optional[str] = None
    usage: Optional[RunUsage] = None
    final_message: Optional[Dict[str, Any]] = None
    type: Literal["result"] = "result"


@dataclass
class RunDoneEvent:
    run_id: str
    error: Optional[Dict[str, Any]] = None
    type: Literal["done"] = "done"


@dataclass
class RunSdkMessageEvent:
    run_id: str
    message: Dict[str, Any]
    type: Literal["sdk_message"] = "sdk_message"


LocalRunStreamEvent = Union[RunResultEvent, RunDoneEvent, RunSdkMessageEvent]


# ─── Encoding ─────────────────────────────────────────────────────────

def encode_local_run_stream_event(event: LocalRunStreamEvent) -> str:
    """Encode an event to a single SSE frame: `data: <json>\\n\\n`."""
    return f"data: {json.dumps(asdict(event))}\n\n"


def encode_local_run_stream_event_ndjson(event: LocalRunStreamEvent) -> str:
    """Encode an event to one NDJSON line."""
    return json.dumps(asdict(event)) + "\n"


# ─── Decoding ─────────────────────────────────────────────────────────

def decode_local_run_stream_event(line: str) -> LocalRunStreamEvent:
    """Decode a single SSE `data: …` line (without the trailing blank) into
    the right LocalRunStreamEvent variant. Raises ValueError on bad input."""
    json_str = line.strip()
    if json_str.startswith("data:"):
        json_str = json_str[5:].strip()
    parsed = json.loads(json_str)
    if not isinstance(parsed, dict) or parsed.get("type") not in ("result", "done", "sdk_message"):
        raise ValueError(f"not a LocalRunStreamEvent: {json_str[:80]}")
    t = parsed["type"]
    if t == "result":
        usage = parsed.get("usage")
        return RunResultEvent(
            run_id=parsed["run_id"],
            exit_reason=parsed.get("exit_reason"),
            usage=RunUsage(**usage) if usage else None,
            final_message=parsed.get("final_message"),
        )
    if t == "done":
        return RunDoneEvent(run_id=parsed["run_id"], error=parsed.get("error"))
    return RunSdkMessageEvent(run_id=parsed["run_id"], message=parsed.get("message") or {})


def iter_local_run_stream(reader) -> Iterator[LocalRunStreamEvent]:
    """Iterate framed events from a file-like reader yielding bytes/str."""
    buf = ""
    while True:
        chunk = reader.read(4096)
        if not chunk:
            if buf.strip():
                for line in buf.splitlines():
                    if line.strip().startswith("data:"):
                        yield decode_local_run_stream_event(line)
            return
        if isinstance(chunk, bytes):
            chunk = chunk.decode("utf-8", errors="replace")
        buf += chunk
        while "\n\n" in buf:
            frame, _, buf = buf.partition("\n\n")
            for line in frame.splitlines():
                if line.strip().startswith("data:"):
                    yield decode_local_run_stream_event(line)


async def aiter_local_run_stream(stream) -> AsyncIterator[LocalRunStreamEvent]:
    """Async iterate framed events from an httpx-style aiter_bytes stream."""
    buf = ""
    async for chunk in stream:
        if isinstance(chunk, bytes):
            chunk = chunk.decode("utf-8", errors="replace")
        buf += chunk
        while "\n\n" in buf:
            frame, _, buf = buf.partition("\n\n")
            for line in frame.splitlines():
                if line.strip().startswith("data:"):
                    yield decode_local_run_stream_event(line)


__all__ = [
    "RunUsage",
    "RunResultEvent",
    "RunDoneEvent",
    "RunSdkMessageEvent",
    "LocalRunStreamEvent",
    "encode_local_run_stream_event",
    "encode_local_run_stream_event_ndjson",
    "decode_local_run_stream_event",
    "iter_local_run_stream",
    "aiter_local_run_stream",
]
