"""Behaviors — 1:1 wrappers around a Judge.

Mirrors Judgment Labs' ``behaviors create-binary`` / ``create-classifier``
CLI. Use :meth:`BehaviorsService.create_binary` and
:meth:`BehaviorsService.create_classifier` as the idiomatic entry
points; the generic :meth:`create` is available too.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ._http import HTTPClient


class BehaviorsService:
    """CRUD + stats for behaviors."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(
        self,
        judge_id: str,
        flavor: str,
        name: str,
        *,
        description: str = "",
        categories: Optional[List[str]] = None,
        options: Optional[List[Dict[str, Any]]] = None,
        evaluation_mode: str = "continuous",
        sampling_rate: float = 1.0,
        span_triggers: str = "all",
        session_scoring: str = "disabled",
    ) -> Dict[str, Any]:
        """Create a behavior bound to ``judge_id``.

        ``flavor`` must be ``binary`` (for binary judges) or
        ``classifier`` (for classification judges).
        """
        body = {
            "judge_id": judge_id,
            "flavor": flavor,
            "name": name,
            "description": description,
            "categories": categories or [],
            "evaluation_mode": evaluation_mode,
            "sampling_rate": sampling_rate,
            "span_triggers": span_triggers,
            "session_scoring": session_scoring,
        }
        if options is not None:
            body["options"] = options
        return self._http.post("/v1/behaviors", body)

    def create_binary(self, judge_id: str, name: str, **kw: Any) -> Dict[str, Any]:
        """Create a binary behavior. Equivalent to JL's ``behaviors create-binary``."""
        return self.create(judge_id=judge_id, flavor="binary", name=name, **kw)

    def create_classifier(self, judge_id: str, name: str, **kw: Any) -> Dict[str, Any]:
        """Create a classifier behavior. Equivalent to JL's ``behaviors create-classifier``."""
        return self.create(judge_id=judge_id, flavor="classifier", name=name, **kw)

    def list(self) -> List[Dict[str, Any]]:
        """List behaviors for the current owner."""
        return self._http.get("/v1/behaviors") or []

    def get(self, behavior_id: str) -> Dict[str, Any]:
        return self._http.get(f"/v1/behaviors/{behavior_id}")

    def update(self, behavior_id: str, **patch: Any) -> Dict[str, Any]:
        return self._http.request("PUT", f"/v1/behaviors/{behavior_id}", patch)

    def delete(self, behavior_id: str) -> None:
        self._http.delete(f"/v1/behaviors/{behavior_id}")

    def stats(self, behavior_id: str, range: str = "30d") -> Dict[str, Any]:
        """Detection-rate, activity series, per-option stats, sample traces."""
        return self._http.get(f"/v1/behaviors/{behavior_id}/stats?range={range}")
