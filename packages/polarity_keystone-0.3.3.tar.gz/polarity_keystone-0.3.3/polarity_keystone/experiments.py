"""Experiment operations for the Keystone SDK."""

from __future__ import annotations

import time as _time
from typing import Any, Dict, List, Optional, Union

from ._http import HTTPClient
from .types import (
    Comparison,
    Experiment,
    ExperimentMetrics,
    KeystoneError,
    RunResults,
)


class ExperimentHandle:
    """Bound handle around a single experiment.

    Returned by :meth:`ExperimentService.create`, :meth:`list`, and
    :meth:`handle`. Methods delegate to the underlying service so callers
    don't keep typing the experiment ID::

        exp = ks.experiments.create("my-eval", spec_id="s")
        exp.run()
        results = exp.results()
        cmp = exp.compare(other_exp)

    Attribute access falls through to the underlying :class:`Experiment`
    metadata, so ``exp.id`` / ``exp.status`` / ``exp.name`` keep working.
    """

    __slots__ = ("_info", "_svc")

    def __init__(self, info: Experiment, svc: "ExperimentService") -> None:
        object.__setattr__(self, "_info", info)
        object.__setattr__(self, "_svc", svc)

    def __getattr__(self, name: str) -> Any:
        info = object.__getattribute__(self, "_info")
        return getattr(info, name)

    @property
    def info(self) -> Experiment:
        """Underlying :class:`Experiment` metadata."""
        return self._info

    def __repr__(self) -> str:
        return f"ExperimentHandle(id={self._info.id!r}, status={self._info.status!r})"

    # -- bound methods ----------------------------------------------------------
    def run(self) -> None:
        """Trigger a run (async on the server)."""
        self._svc.run(self._info.id)

    def run_and_wait(
        self,
        poll_interval: float = 1.0,
        timeout: float = 600,
        scores: "Optional[list]" = None,
    ) -> RunResults:
        """Run + poll until completion."""
        return self._svc.run_and_wait(
            self._info.id,
            poll_interval=poll_interval,
            timeout=timeout,
            scores=scores,
        )

    def results(self) -> RunResults:
        """Fetch the full :class:`RunResults`."""
        return self._svc.get(self._info.id)

    def metrics(self) -> ExperimentMetrics:
        """Fetch experiment-level metrics breakdown."""
        return self._svc.metrics(self._info.id)

    def compare(self, other: "Union[ExperimentHandle, str]") -> Comparison:
        """Compare against another experiment (handle or raw ID)."""
        candidate_id = other._info.id if isinstance(other, ExperimentHandle) else other
        return self._svc.compare(self._info.id, candidate_id)


class ExperimentService:
    """Operations for Keystone experiments."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(
        self,
        name: str,
        spec_id: str,
        *,
        secrets: Optional[Dict[str, str]] = None,
        spec_path: Optional[str] = None,
    ) -> ExperimentHandle:
        """Create a new experiment. Returns a bound handle.

        Args:
            name: Human-readable experiment name.
            spec_id: ID of the spec this experiment runs against.
            secrets: Optional explicit runtime secrets to forward. Merged
                with Dashboard-stored secrets on the server; these win.
            spec_path: Optional path to a local spec YAML. When provided,
                the SDK reads the spec's ``secrets:`` block and auto-forwards
                matching values from ``os.environ``. Explicit ``secrets``
                take priority (explicit > implicit).
        """
        body: Dict[str, Any] = {"name": name, "spec_id": spec_id}
        merged: Dict[str, str] = {}
        if spec_path:
            from .env_secrets import collect_declared_secrets_from_file
            merged.update(collect_declared_secrets_from_file(spec_path))
        if secrets:
            merged.update(secrets)  # explicit wins over .env
        if merged:
            body["secrets"] = merged
        data = self._http.post("/v1/experiments", body)
        return ExperimentHandle(Experiment.from_dict(data), self)

    def get(self, experiment_id: str) -> RunResults:
        """Get experiment results (including scenario-level detail).

        Returns a ``RunResults`` object.  If the experiment is still
        running, the results will reflect progress so far.
        """
        data = self._http.get(f"/v1/experiments/{experiment_id}")
        return RunResults.from_dict(data)

    def handle(self, experiment_id: str) -> ExperimentHandle:
        """Build a bound handle from an ID without making a network call."""
        return ExperimentHandle(Experiment(id=experiment_id), self)

    def list(self) -> List[ExperimentHandle]:
        """List all experiments. Returns bound handles."""
        data = self._http.get("/v1/experiments")
        if data is None:
            return []
        return [ExperimentHandle(Experiment.from_dict(item), self) for item in data]

    def run(self, experiment_id: str) -> None:
        """Trigger an experiment run.

        This enqueues scenario jobs and returns immediately.  Use
        :meth:`get` or :meth:`run_and_wait` to poll for results.
        """
        self._http.post(f"/v1/experiments/{experiment_id}/run")

    def run_and_wait(
        self,
        experiment_id: str,
        poll_interval: float = 1.0,
        timeout: float = 600,
        scores: "Optional[list]" = None,
    ) -> RunResults:
        """Run an experiment and poll until it completes.

        This is the convenience "fire-and-forget" method: it triggers the
        run, then polls ``GET /v1/experiments/{id}`` until the experiment
        status is ``"completed"`` or the *timeout* is exceeded.

        After completion, any client-side scorer functions in ``scores``
        are executed against each scenario result. Their scores are appended
        to the invariant results.

        Args:
            experiment_id: Experiment to run.
            poll_interval: Seconds between polls (default 1).
            timeout: Maximum seconds to wait (default 600).
            scores: Optional list of scorer objects (built-in or custom).
                Built-in scorers (FileExists, LLMJudge, etc.) are converted
                to spec invariants. Custom scorers (``@Scorer`` decorated
                functions) run client-side after completion.

        Returns:
            Final ``RunResults`` once the experiment completes.

        Raises:
            KeystoneError: If the timeout is exceeded.
        """
        self.run(experiment_id)

        deadline = _time.monotonic() + timeout
        while True:
            results = self.get(experiment_id)

            if results.total_scenarios > 0:
                done = (results.passed + results.failed + results.flaky + results.errors)
                if done >= results.total_scenarios:
                    # Run client-side scorers.
                    if scores:
                        from .scores import run_client_scorers
                        for scenario in results.scenarios:
                            client_scores = run_client_scorers(scores, scenario)
                            for cs in client_scores:
                                from .types import InvariantResult
                                scenario.invariants.append(InvariantResult(
                                    name=cs.name,
                                    passed=cs.passed,
                                    score=cs.score,
                                    message=cs.message,
                                    weight=1.0,
                                ))
                    return results

            if _time.monotonic() >= deadline:
                raise KeystoneError(
                    0,
                    f"Timed out waiting for experiment {experiment_id} "
                    f"after {timeout}s",
                )

            _time.sleep(poll_interval)

    def compare(self, baseline_id: str, candidate_id: str) -> Comparison:
        """Compare two experiment runs.

        Args:
            baseline_id: Experiment ID of the baseline run.
            candidate_id: Experiment ID of the candidate run.
        """
        data = self._http.post(
            "/v1/experiments/compare",
            {"baseline_id": baseline_id, "candidate_id": candidate_id},
        )
        return Comparison.from_dict(data)

    def metrics(self, experiment_id: str) -> ExperimentMetrics:
        """Get detailed metrics for an experiment."""
        data = self._http.get(f"/v1/metrics/experiments/{experiment_id}")
        return ExperimentMetrics.from_dict(data)
