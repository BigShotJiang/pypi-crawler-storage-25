"""Tool-call argument and result dataclasses mirroring @cursor/sdk's full
tool taxonomy (Read / Write / Edit / Delete / Grep / Glob / Ls / Shell /
Task / CreatePlan / UpdateTodos / SemSearch / Mcp / ReadLints).

Pure type/dataclass declarations: the Keystone Paragon agent's built-in
tools are different (`search_traces`, `get_judge`, `get_behavior`). These
exist so Python code that wants to share types with a Cursor SDK
consumer — or adapt one to Keystone — has the same shapes available.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Union


# ─── Shared ──────────────────────────────────────────────────────────

@dataclass
class SimpleError:
    message: str
    code: Optional[str] = None


ToolType = Literal[
    "read",
    "write",
    "edit",
    "delete",
    "grep",
    "glob",
    "ls",
    "shell",
    "task",
    "create_plan",
    "update_todos",
    "sem_search",
    "mcp",
    "read_lints",
]


# ─── Read / Write / Edit / Delete ───────────────────────────────────

@dataclass
class ReadArgs:
    path: str
    start_line: Optional[int] = None
    end_line: Optional[int] = None


@dataclass
class ReadSuccess:
    content: str
    total_lines: Optional[int] = None
    truncated: Optional[bool] = None


ReadResult = Union["ReadSuccess", SimpleError]


@dataclass
class ReadToolCall:
    args: ReadArgs
    result: Optional[ReadResult] = None
    type: Literal["read"] = "read"


@dataclass
class WriteArgs:
    path: str
    content: str


@dataclass
class WriteSuccess:
    bytes_written: int
    created: bool


WriteResult = Union[WriteSuccess, SimpleError]


@dataclass
class WriteToolCall:
    args: WriteArgs
    result: Optional[WriteResult] = None
    type: Literal["write"] = "write"


@dataclass
class EditArgs:
    path: str
    old_string: str
    new_string: str
    replace_all: Optional[bool] = None


@dataclass
class EditSuccess:
    edits: int
    preview: Optional[str] = None


EditResult = Union[EditSuccess, SimpleError]


@dataclass
class EditToolCall:
    args: EditArgs
    result: Optional[EditResult] = None
    type: Literal["edit"] = "edit"


@dataclass
class DeleteArgs:
    path: str
    recursive: Optional[bool] = None


@dataclass
class DeleteSuccess:
    removed: List[str]


DeleteResult = Union[DeleteSuccess, SimpleError]


@dataclass
class DeleteToolCall:
    args: DeleteArgs
    result: Optional[DeleteResult] = None
    type: Literal["delete"] = "delete"


# ─── Glob / Ls ──────────────────────────────────────────────────────

@dataclass
class GlobArgs:
    pattern: str
    cwd: Optional[str] = None
    limit: Optional[int] = None


@dataclass
class GlobSuccess:
    paths: List[str]
    truncated: Optional[bool] = None


GlobResult = Union[GlobSuccess, SimpleError]


@dataclass
class GlobToolCall:
    args: GlobArgs
    result: Optional[GlobResult] = None
    type: Literal["glob"] = "glob"


@dataclass
class LsEntry:
    name: str
    is_dir: bool
    size: Optional[int] = None


@dataclass
class LsArgs:
    path: str
    show_hidden: Optional[bool] = None


@dataclass
class LsSuccess:
    entries: List[LsEntry]


LsResult = Union[LsSuccess, SimpleError]


@dataclass
class LsToolCall:
    args: LsArgs
    result: Optional[LsResult] = None
    type: Literal["ls"] = "ls"


# ─── Grep ───────────────────────────────────────────────────────────

@dataclass
class GrepArgs:
    pattern: str
    path: Optional[str] = None
    glob: Optional[str] = None
    output_mode: Optional[Literal["content", "count", "files"]] = None
    case_insensitive: Optional[bool] = None
    context_before: Optional[int] = None
    context_after: Optional[int] = None
    limit: Optional[int] = None


@dataclass
class GrepContentMatch:
    path: str
    line_number: int
    line: str
    before_context: Optional[List[str]] = None
    after_context: Optional[List[str]] = None


@dataclass
class GrepContentOutput:
    matches: List[GrepContentMatch]
    mode: Literal["content"] = "content"


@dataclass
class GrepCountOutput:
    counts: List[Dict[str, Any]]  # [{path, count}]
    mode: Literal["count"] = "count"


@dataclass
class GrepFilesOutput:
    paths: List[str]
    mode: Literal["files"] = "files"


GrepSuccess = Union[GrepContentOutput, GrepCountOutput, GrepFilesOutput]
GrepResult = Union[GrepSuccess, SimpleError]


@dataclass
class GrepToolCall:
    args: GrepArgs
    result: Optional[GrepResult] = None
    type: Literal["grep"] = "grep"


# ─── Shell ──────────────────────────────────────────────────────────

@dataclass
class ShellArgs:
    command: str
    cwd: Optional[str] = None
    env: Optional[Dict[str, str]] = None
    timeout_ms: Optional[int] = None


@dataclass
class ShellSuccess:
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: Optional[int] = None


ShellResult = Union[ShellSuccess, SimpleError]


@dataclass
class ShellToolCall:
    args: ShellArgs
    result: Optional[ShellResult] = None
    type: Literal["shell"] = "shell"


# ─── Task (subagent spawn) ──────────────────────────────────────────

TaskMode = Literal["foreground", "background"]
TaskSubagentType = Literal["planner", "editor", "researcher", "custom"]
SubagentBackgroundReason = Literal["long_running", "parallel", "user_requested"]


@dataclass
class TaskArgs:
    prompt: str
    subagent: Optional[TaskSubagentType] = None
    mode: Optional[TaskMode] = None
    context: Optional[str] = None


@dataclass
class TaskSuccess:
    task_id: str
    result: str


TaskResult = Union[TaskSuccess, SimpleError]


@dataclass
class TaskToolCall:
    args: TaskArgs
    result: Optional[TaskResult] = None
    type: Literal["task"] = "task"


# ─── CreatePlan / UpdateTodos ───────────────────────────────────────

@dataclass
class PlanStep:
    description: str
    status: Optional[Literal["pending", "in_progress", "completed"]] = None


@dataclass
class CreatePlanArgs:
    steps: List[PlanStep]


@dataclass
class CreatePlanSuccess:
    plan_id: str


CreatePlanResult = Union[CreatePlanSuccess, SimpleError]


@dataclass
class CreatePlanToolCall:
    args: CreatePlanArgs
    result: Optional[CreatePlanResult] = None
    type: Literal["create_plan"] = "create_plan"


TodoStatus = Literal["pending", "in_progress", "completed"]


@dataclass
class TodoItem:
    id: str
    content: str
    status: TodoStatus


@dataclass
class UpdateTodosArgs:
    todos: List[TodoItem]


@dataclass
class UpdateTodosSuccess:
    updated: int


UpdateTodosResult = Union[UpdateTodosSuccess, SimpleError]


@dataclass
class UpdateTodosToolCall:
    args: UpdateTodosArgs
    result: Optional[UpdateTodosResult] = None
    type: Literal["update_todos"] = "update_todos"


# ─── SemSearch / Mcp / ReadLints ────────────────────────────────────

@dataclass
class SemSearchArgs:
    query: str
    paths: Optional[List[str]] = None
    limit: Optional[int] = None


@dataclass
class SemSearchHit:
    path: str
    score: float
    preview: str


@dataclass
class SemSearchSuccess:
    hits: List[SemSearchHit]


SemSearchResult = Union[SemSearchSuccess, SimpleError]


@dataclass
class SemSearchToolCall:
    args: SemSearchArgs
    result: Optional[SemSearchResult] = None
    type: Literal["sem_search"] = "sem_search"


McpProviderId = str
McpToolId = str


@dataclass
class McpArgs:
    provider: McpProviderId
    tool: McpToolId
    arguments: Dict[str, Any] = field(default_factory=dict)


@dataclass
class McpSuccess:
    content: List[Dict[str, Any]]
    structured_content: Optional[Dict[str, Any]] = None
    is_error: Optional[bool] = None


McpResult = Union[McpSuccess, SimpleError]


@dataclass
class McpToolCall:
    args: McpArgs
    result: Optional[McpResult] = None
    type: Literal["mcp"] = "mcp"


@dataclass
class LintIssue:
    path: str
    line: int
    severity: Literal["error", "warning", "info"]
    message: str
    column: Optional[int] = None
    rule: Optional[str] = None


@dataclass
class ReadLintsArgs:
    paths: List[str]


@dataclass
class ReadLintsSuccess:
    issues: List[LintIssue]


ReadLintsResult = Union[ReadLintsSuccess, SimpleError]


@dataclass
class ReadLintsToolCall:
    args: ReadLintsArgs
    result: Optional[ReadLintsResult] = None
    type: Literal["read_lints"] = "read_lints"


# ─── ToolCall union ─────────────────────────────────────────────────

ToolCall = Union[
    ReadToolCall,
    WriteToolCall,
    EditToolCall,
    DeleteToolCall,
    GlobToolCall,
    LsToolCall,
    GrepToolCall,
    ShellToolCall,
    TaskToolCall,
    CreatePlanToolCall,
    UpdateTodosToolCall,
    SemSearchToolCall,
    McpToolCall,
    ReadLintsToolCall,
]


__all__ = [
    "SimpleError",
    "ToolType",
    "ToolCall",
    "ReadArgs", "ReadSuccess", "ReadResult", "ReadToolCall",
    "WriteArgs", "WriteSuccess", "WriteResult", "WriteToolCall",
    "EditArgs", "EditSuccess", "EditResult", "EditToolCall",
    "DeleteArgs", "DeleteSuccess", "DeleteResult", "DeleteToolCall",
    "GlobArgs", "GlobSuccess", "GlobResult", "GlobToolCall",
    "LsArgs", "LsEntry", "LsSuccess", "LsResult", "LsToolCall",
    "GrepArgs", "GrepContentMatch", "GrepContentOutput", "GrepCountOutput",
    "GrepFilesOutput", "GrepSuccess", "GrepResult", "GrepToolCall",
    "ShellArgs", "ShellSuccess", "ShellResult", "ShellToolCall",
    "TaskArgs", "TaskMode", "TaskSubagentType", "SubagentBackgroundReason",
    "TaskSuccess", "TaskResult", "TaskToolCall",
    "PlanStep", "CreatePlanArgs", "CreatePlanSuccess", "CreatePlanResult", "CreatePlanToolCall",
    "TodoItem", "TodoStatus", "UpdateTodosArgs", "UpdateTodosSuccess",
    "UpdateTodosResult", "UpdateTodosToolCall",
    "SemSearchArgs", "SemSearchHit", "SemSearchSuccess", "SemSearchResult", "SemSearchToolCall",
    "McpArgs", "McpProviderId", "McpToolId", "McpSuccess", "McpResult", "McpToolCall",
    "LintIssue", "ReadLintsArgs", "ReadLintsSuccess", "ReadLintsResult", "ReadLintsToolCall",
]
