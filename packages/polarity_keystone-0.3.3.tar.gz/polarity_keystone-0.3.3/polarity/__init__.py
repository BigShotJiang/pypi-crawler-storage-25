"""Polarity Python SDK.

This is the canonical import name. The historical ``polarity_keystone``
package re-exports the same symbols and continues to work indefinitely::

    from polarity import Polarity                  # preferred
    from polarity_keystone import Keystone          # legacy, still works

``Polarity`` is a subclass of ``Keystone`` so existing ``isinstance``
checks against ``Keystone`` keep passing for both old and new code.
"""

from polarity_keystone import *  # noqa: F401, F403
from polarity_keystone import (  # noqa: F401  (explicit re-export)
    Keystone,
    Polarity,
)
from polarity_keystone.types import KeystoneError, PolarityError  # noqa: F401


__all__ = [
    "Polarity",
    "PolarityError",
    # Legacy names — re-exported for symmetry.
    "Keystone",
    "KeystoneError",
]
