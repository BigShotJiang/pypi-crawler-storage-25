"""Tool parser helpers for kamiwaza_mlx."""
