#!/usr/bin/env python3
"""
Launch an upstream mlx_lm.server process across two hosts via mlx.launch.

This keeps the control plane simple for Kamiwaza:
- Kamiwaza manages one local launcher process
- mlx.launch fans out to rank 0 locally and rank 1 remotely over SSH
- termination of the local launcher tears down the distributed job
"""

from __future__ import annotations

import argparse
import json
import os
import shlex
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Iterable, Sequence


def _resolve_sibling_binary(name: str) -> str:
    candidates = [
        Path(sys.executable).with_name(name),
        Path(sys.prefix) / "bin" / name,
        Path(sys.exec_prefix) / "bin" / name,
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    resolved = shutil.which(name)
    if resolved:
        return resolved
    raise SystemExit(f"Required executable not found: {name}")


def _resolve_mlx_launch_command() -> list[str]:
    return [_resolve_sibling_binary("mlx.launch")]


def _env_default(*names: str, default: str = "") -> str:
    for name in names:
        value = os.getenv(name)
        if value:
            return value
    return default


def _bool_env(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _local_venv_path() -> str:
    return str(Path(sys.prefix))


def _server_binary_for_venv(venv_path: str) -> str:
    return str(Path(venv_path) / "bin" / "mlx_lm.server")


def _pick_free_port() -> int:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])
    finally:
        sock.close()


def _build_ssh_shell_command(
    *,
    ssh_key_path: str,
    strict_host_key_checking: bool,
) -> list[str]:
    ssh_target = [
        "ssh",
        "-i",
        ssh_key_path,
        "-o",
        "IdentitiesOnly=yes",
        "-o",
        "BatchMode=yes",
    ]
    if strict_host_key_checking:
        ssh_target.extend(["-o", "StrictHostKeyChecking=yes"])
    else:
        ssh_target.extend(
            [
                "-o",
                "StrictHostKeyChecking=no",
                "-o",
                "UserKnownHostsFile=/dev/null",
            ]
        )
    return ssh_target


def _build_peer_ssh_target(
    *,
    peer_host: str,
    peer_user: str,
    ssh_key_path: str,
    strict_host_key_checking: bool,
) -> str:
    ssh_target = _build_ssh_shell_command(
        ssh_key_path=ssh_key_path,
        strict_host_key_checking=strict_host_key_checking,
    )[1:]
    ssh_target.append(f"{peer_user}@{peer_host}")
    return shlex.join(ssh_target)


def _run_subprocess(command: Sequence[str], *, stdin=None) -> None:
    subprocess.run(list(command), check=True, stdin=stdin)


def _remote_bash_command(
    ssh_command: Sequence[str],
    remote_login: str,
    script: str,
) -> list[str]:
    return [*ssh_command, remote_login, f"bash -lc {shlex.quote(script)}"]


def _remote_model_check_script(remote_model_path: str) -> str:
    quoted_path = shlex.quote(remote_model_path)
    return (
        f"d={quoted_path}\n"
        "shopt -s nullglob\n"
        'files=("$d"/*.safetensors)\n'
        '[[ -d "$d" && -f "$d/config.json" && ${#files[@]} -gt 0 ]]'
    )


def _expected_remote_shard_count(local_model_path: str) -> int:
    local_model_dir = Path(local_model_path)
    if not local_model_dir.is_dir():
        raise SystemExit(f"Local model path does not exist or is not a directory: {local_model_path}")
    return len(list(local_model_dir.glob("model*.safetensors")))


def _remote_model_exists(
    *,
    ssh_command: Sequence[str],
    remote_login: str,
    local_model_path: str,
    remote_model_path: str,
) -> bool:
    expected_shards = _expected_remote_shard_count(local_model_path)
    quoted_path = shlex.quote(remote_model_path)
    check_script = (
        f"d={quoted_path}\n"
        "shopt -s nullglob\n"
        'files=("$d"/model*.safetensors)\n'
        f'[[ -d "$d" && -f "$d/config.json" && ${{#files[@]}} -eq {expected_shards} ]]'
    )
    result = subprocess.run(
        _remote_bash_command(
            ssh_command,
            remote_login,
            check_script,
        ),
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return result.returncode == 0


def _sync_remote_model_from_local(
    *,
    ssh_command: Sequence[str],
    remote_login: str,
    local_model_path: str,
    remote_model_path: str,
) -> None:
    local_model_dir = Path(local_model_path)
    if not local_model_dir.is_dir():
        raise SystemExit(f"Local model path does not exist or is not a directory: {local_model_path}")
    print(
        f"[kamiwaza-mlx] syncing model to paired host: {local_model_path} -> {remote_login}:{remote_model_path}",
        file=sys.stderr,
        flush=True,
    )
    mkdir_script = f"mkdir -p {shlex.quote(str(Path(remote_model_path).parent))}"
    _run_subprocess(_remote_bash_command(ssh_command, remote_login, mkdir_script))

    tar_send = subprocess.Popen(
        ["tar", "-C", str(local_model_dir.parent), "-cf", "-", local_model_dir.name],
        stdout=subprocess.PIPE,
    )
    try:
        remote_parent = Path(remote_model_path).parent
        remote_name = Path(remote_model_path).name
        local_name = local_model_dir.name
        rename_tail = ""
        if remote_name != local_name:
            rename_tail = (
                f"\nrm -rf {shlex.quote(str(Path(remote_model_path)))}"
                f"\nmv {shlex.quote(str(remote_parent / local_name))} {shlex.quote(str(Path(remote_model_path)))}"
            )
        extract_script = (
            f"mkdir -p {shlex.quote(str(remote_parent))}\n"
            f"tar -C {shlex.quote(str(remote_parent))} -xf -"
            f"{rename_tail}"
        )
        _run_subprocess(
            _remote_bash_command(ssh_command, remote_login, extract_script),
            stdin=tar_send.stdout,
        )
    finally:
        if tar_send.stdout is not None:
            tar_send.stdout.close()
        return_code = tar_send.wait()
        if return_code != 0:
            raise SystemExit(f"Local model archive process failed with exit code {return_code}")


def _ensure_remote_model_available(
    *,
    sync_mode: str,
    ssh_command: Sequence[str],
    remote_login: str,
    local_model_path: str,
    remote_model_path: str,
) -> None:
    if sync_mode == "never":
        return
    if sync_mode == "if-missing" and _remote_model_exists(
        ssh_command=ssh_command,
        remote_login=remote_login,
        local_model_path=local_model_path,
        remote_model_path=remote_model_path,
    ):
        return
    _sync_remote_model_from_local(
        ssh_command=ssh_command,
        remote_login=remote_login,
        local_model_path=local_model_path,
        remote_model_path=remote_model_path,
    )


def _derive_model_aliases(model_path: str) -> list[str]:
    path = Path(model_path)
    aliases: list[str] = []
    seen: set[str] = set()

    def add(value: str | None) -> None:
        if not value:
            return
        cleaned = str(value).strip()
        if not cleaned or cleaned in seen:
            return
        seen.add(cleaned)
        aliases.append(cleaned)

    add(model_path)
    add(str(path))
    add(path.name)
    add("local")

    env_roots = [
        os.getenv("KAMIWAZA_HOST_MODELS_PATH"),
        os.getenv("KAMIWAZA_MODELS_ROOT"),
    ]
    for root in env_roots:
        if not root:
            continue
        try:
            rel = path.resolve().relative_to(Path(root).resolve())
        except Exception:
            continue
        add(rel.as_posix())

    parts = list(path.parts)
    if "models" in parts:
        idx = parts.index("models")
        rel_parts = parts[idx + 1 :]
        if rel_parts:
            add(Path(*rel_parts).as_posix())

    return aliases


def _build_hostfile_payload(
    *,
    backend: str,
    local_ip: str,
    peer_ip: str,
    local_rdma: str | None,
    peer_rdma: str | None,
    peer_ssh_target: str,
    extra_env: Iterable[str],
) -> dict:
    if backend in {"jaccl", "jaccl-ring"}:
        if not local_rdma or not peer_rdma:
            raise SystemExit(
                f"{backend} requires both local and peer RDMA device names"
            )
        hosts = [
            {"ssh": "127.0.0.1", "ips": [local_ip], "rdma": [None, local_rdma]},
            {"ssh": peer_ssh_target, "ips": [peer_ip], "rdma": [peer_rdma, None]},
        ]
    else:
        hosts = [
            {"ssh": "127.0.0.1", "ips": [local_ip], "rdma": []},
            {"ssh": peer_ssh_target, "ips": [peer_ip], "rdma": []},
        ]

    return {
        "backend": backend,
        "envs": list(extra_env),
        "hosts": hosts,
    }


def _write_hostfile(payload: dict) -> str:
    fd, hostfile_path = tempfile.mkstemp(prefix="kamiwaza-mlx-hostfile-", suffix=".json")
    os.close(fd)
    path = Path(hostfile_path)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return str(path)


def _extend_server_command(
    base_command: list[str],
    unknown_args: Sequence[str],
) -> list[str]:
    command = list(base_command)
    if unknown_args:
        command.extend(unknown_args)
    return command


def _build_rank_switch_command(
    *,
    local_server: str,
    remote_server: str,
    local_python: str,
    local_model_path: str,
    remote_model_path: str,
    host: str,
    port: int,
    local_proxy_upstream_port: int,
    model_aliases: Sequence[str],
    trust_remote_code: bool,
    unknown_args: Sequence[str],
) -> str:
    local_upstream_command = _extend_server_command(
        [
            local_server,
            "--model",
            local_model_path,
            "--host",
            "127.0.0.1",
            "--port",
            str(local_proxy_upstream_port),
        ]
        + (["--trust-remote-code"] if trust_remote_code else []),
        unknown_args,
    )
    local_proxy_command = [
        local_python,
        "-m",
        "kamiwaza_mlx.distributed_proxy",
        "--loaded-model-path",
        local_model_path,
        "--host",
        host,
        "--port",
        str(port),
        "--upstream-port",
        str(local_proxy_upstream_port),
    ]
    for alias in model_aliases:
        local_proxy_command.extend(["--model-alias", alias])
    local_proxy_command.extend(["--", *local_upstream_command])

    local_command = _extend_server_command(
        local_proxy_command,
        [],
    )
    remote_command = _extend_server_command(
        [
            remote_server,
            "--model",
            remote_model_path,
            "--host",
            host,
            "--port",
            str(port),
        ]
        + (["--trust-remote-code"] if trust_remote_code else []),
        unknown_args,
    )
    return (
        'if [[ "${MLX_RANK:-0}" == "0" ]]; then '
        f"exec {shlex.join(local_command)}; "
        "else "
        f"exec {shlex.join(remote_command)}; "
        "fi"
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Launch distributed MLX-LM serving across a paired macOS host"
    )
    parser.add_argument("--model", required=True)
    parser.add_argument(
        "--remote-venv-path",
        default=_env_default("KAMIWAZA_MLX_REMOTE_VENV_PATH", default=""),
        help="Remote venv root; defaults to the local venv path",
    )
    parser.add_argument(
        "--remote-model-path",
        default=_env_default("KAMIWAZA_MLX_REMOTE_MODEL_PATH", default=""),
        help="Remote model directory; defaults to --model",
    )
    parser.add_argument(
        "--remote-model-sync",
        choices=("never", "if-missing", "always"),
        default=_env_default("KAMIWAZA_MLX_REMOTE_MODEL_SYNC", default="if-missing"),
        help="Copy the local model directory to the paired host when the remote copy is missing or always",
    )
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument(
        "--backend",
        default=_env_default("KAMIWAZA_MLX_BACKEND", "BACKEND", default="jaccl"),
        help="mlx.launch backend (jaccl, jaccl-ring, ring, mpi, nccl)",
    )
    parser.add_argument(
        "--peer-host",
        default=_env_default("KAMIWAZA_PAIRED_NODE"),
        help="Remote paired host reachable over SSH",
    )
    parser.add_argument(
        "--peer-ssh-host",
        default=_env_default("KAMIWAZA_PAIRED_SSH_HOST", "KAMIWAZA_MLX_PEER_SSH_HOST", default=""),
        help="Override SSH/sync host for the paired node; defaults to --peer-ip when set, else --peer-host",
    )
    parser.add_argument(
        "--peer-user",
        default=_env_default("KAMIWAZA_PAIRED_USER", default=os.getenv("USER", "")),
        help="SSH username for the paired host",
    )
    parser.add_argument(
        "--ssh-key-path",
        default=_env_default("KAMIWAZA_PAIRED_KEY", default=""),
        help="SSH private key used by mlx.launch for the paired host",
    )
    parser.add_argument(
        "--peer-alias",
        default="kw-mlx-peer",
        help="Temporary SSH config alias used inside the generated hostfile",
    )
    parser.add_argument(
        "--local-ip",
        default=_env_default("KAMIWAZA_MLX_LOCAL_IP", default=""),
        help="Coordinator-reachable IP for the local host",
    )
    parser.add_argument(
        "--peer-ip",
        default=_env_default("KAMIWAZA_MLX_REMOTE_IP", default=""),
        help="Coordinator-reachable IP for the paired host",
    )
    parser.add_argument(
        "--local-rdma",
        default=_env_default("KAMIWAZA_MLX_LOCAL_RDMA", "KAMIWAZA_MLX_RDMA_DEVICE", default=""),
        help="Local RDMA device name for JACCL, e.g. rdma_en5",
    )
    parser.add_argument(
        "--peer-rdma",
        default=_env_default("KAMIWAZA_MLX_REMOTE_RDMA", "KAMIWAZA_MLX_RDMA_DEVICE", default=""),
        help="Remote RDMA device name for JACCL, e.g. rdma_en5",
    )
    parser.add_argument(
        "--trust-remote-code",
        action=argparse.BooleanOptionalAction,
        default=_bool_env("KAMIWAZA_MLX_TRUST_REMOTE_CODE", default=True),
    )
    parser.add_argument(
        "--fast-synch",
        default=_env_default("KAMIWAZA_MLX_FAST_SYNCH", "FAST_SYNCH", default="1"),
        help="MLX_METAL_FAST_SYNCH value for launched ranks",
    )
    parser.add_argument(
        "--strict-host-key-checking",
        action=argparse.BooleanOptionalAction,
        default=_bool_env("KAMIWAZA_PAIRED_STRICT_KNOWN_HOSTS", default=False),
    )
    parser.add_argument(
        "--env",
        action="append",
        default=[],
        help="Additional env assignment forwarded to mlx.launch ranks",
    )
    args, unknown_args = parser.parse_known_args()

    if not args.peer_host:
        raise SystemExit("--peer-host or KAMIWAZA_PAIRED_NODE is required")
    if not args.peer_user:
        raise SystemExit("--peer-user or KAMIWAZA_PAIRED_USER is required")
    if not args.ssh_key_path:
        raise SystemExit("--ssh-key-path or KAMIWAZA_PAIRED_KEY is required")
    if not args.local_ip:
        raise SystemExit("--local-ip or KAMIWAZA_MLX_LOCAL_IP is required")
    if not args.peer_ip:
        raise SystemExit("--peer-ip or KAMIWAZA_MLX_REMOTE_IP is required")

    mlx_launch_command = _resolve_mlx_launch_command()
    local_venv_path = _local_venv_path()
    local_server = _resolve_sibling_binary("mlx_lm.server")
    remote_venv_path = args.remote_venv_path or local_venv_path
    remote_server = _server_binary_for_venv(remote_venv_path)
    remote_model_path = args.remote_model_path or args.model
    remote_python = sys.executable
    local_proxy_upstream_port = _pick_free_port()
    model_aliases = _derive_model_aliases(args.model)

    peer_ssh_host = args.peer_ssh_host or args.peer_ip or args.peer_host
    peer_ssh_target = _build_peer_ssh_target(
        peer_host=peer_ssh_host,
        peer_user=args.peer_user,
        ssh_key_path=args.ssh_key_path,
        strict_host_key_checking=bool(args.strict_host_key_checking),
    )
    remote_login = f"{args.peer_user}@{peer_ssh_host}"
    ssh_shell_command = _build_ssh_shell_command(
        ssh_key_path=args.ssh_key_path,
        strict_host_key_checking=bool(args.strict_host_key_checking),
    )

    _ensure_remote_model_available(
        sync_mode=args.remote_model_sync,
        ssh_command=ssh_shell_command,
        remote_login=remote_login,
        local_model_path=args.model,
        remote_model_path=remote_model_path,
    )

    extra_env = list(args.env)
    if args.fast_synch:
        extra_env.append(f"MLX_METAL_FAST_SYNCH={args.fast_synch}")
    hostfile = _write_hostfile(
        _build_hostfile_payload(
            backend=args.backend,
            local_ip=args.local_ip,
            peer_ip=args.peer_ip,
            local_rdma=args.local_rdma or None,
            peer_rdma=args.peer_rdma or None,
            peer_ssh_target=peer_ssh_target,
            extra_env=extra_env,
        )
    )

    server_command = _build_rank_switch_command(
        local_server=local_server,
        remote_server=remote_server,
        local_python=sys.executable,
        local_model_path=args.model,
        remote_model_path=remote_model_path,
        host=args.host,
        port=args.port,
        local_proxy_upstream_port=local_proxy_upstream_port,
        model_aliases=model_aliases,
        trust_remote_code=bool(args.trust_remote_code),
        unknown_args=unknown_args,
    )

    launch_command = [
        *mlx_launch_command,
        "--hostfile",
        hostfile,
        "--backend",
        args.backend,
        "--no-verify-script",
        "--python",
        remote_python,
    ]
    for env_assignment in extra_env:
        launch_command.extend(["--env", env_assignment])
    launch_command.extend(["--", "bash", "-lc", server_command])

    os.execvpe(launch_command[0], launch_command, os.environ.copy())


if __name__ == "__main__":
    main()
