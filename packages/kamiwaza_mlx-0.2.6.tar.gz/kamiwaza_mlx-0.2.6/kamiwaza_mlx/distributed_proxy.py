#!/usr/bin/env python3
"""Thin rank-0 proxy that locks requests to the launched local model."""

from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator, Optional

import requests
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse


def _dedupe(values: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        cleaned = str(value).strip()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        out.append(cleaned)
    return out


def _derive_display_model_id(loaded_model_path: str, aliases: Iterable[str]) -> str:
    alias_list = _dedupe(aliases)
    path = Path(loaded_model_path)
    preferred = [alias for alias in alias_list if alias not in {loaded_model_path, str(path), "local"}]
    if preferred:
        return preferred[0]
    if path.name:
        return path.name
    return loaded_model_path


@dataclass
class ProxyState:
    loaded_model_path: str
    accepted_models: set[str]
    display_model_id: str
    upstream_host: str
    upstream_port: int
    upstream_command: list[str]
    timeout: float

    child: Optional[subprocess.Popen] = None
    _stopping: bool = False

    @property
    def upstream_base(self) -> str:
        return f"http://{self.upstream_host}:{self.upstream_port}"

    def start(self) -> None:
        if self.child is not None:
            return
        self.child = subprocess.Popen(self.upstream_command)
        watcher = threading.Thread(target=self._watch_child, daemon=True)
        watcher.start()

    def stop(self) -> None:
        self._stopping = True
        child = self.child
        if child is None or child.poll() is not None:
            return
        child.terminate()
        try:
            child.wait(timeout=10)
            return
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=5)

    def _watch_child(self) -> None:
        child = self.child
        if child is None:
            return
        rc = child.wait()
        if self._stopping:
            return
        print(
            f"[kamiwaza-mlx] {_describe_child_returncode(rc)}; terminating rank-0 proxy.",
            file=sys.stderr,
            flush=True,
        )
        os._exit(_proxy_exit_code(rc))

    def is_ready(self) -> bool:
        if self.child is None or self.child.poll() is not None:
            return False
        try:
            resp = requests.get(
                f"{self.upstream_base}/v1/models",
                timeout=min(self.timeout, 2.0),
            )
            return resp.status_code == 200
        except Exception:
            return False

    def normalize_model(self, raw_model: object) -> str:
        if raw_model is None:
            return self.loaded_model_path
        model = str(raw_model).strip()
        if not model:
            return self.loaded_model_path
        if model in self.accepted_models:
            return self.loaded_model_path
        raise ValueError(
            f"Unsupported model '{model}'. This server only exposes {sorted(self.accepted_models)!r}."
        )


def _filter_forward_headers(headers: Request) -> dict[str, str]:
    allowed = {
        "x-conversation-id",
        "x-request-id",
        "user-agent",
        "x-forwarded-for",
        "accept",
        "content-type",
    }
    out: dict[str, str] = {}
    for key, value in headers.headers.items():
        if key.lower() in allowed:
            out[key] = value
    return out


def _signal_name(signum: int) -> str:
    try:
        return signal.Signals(signum).name
    except ValueError:
        return f"SIG{signum}"


def _describe_child_returncode(returncode: int) -> str:
    if returncode < 0:
        signum = abs(returncode)
        return f"upstream MLX server exited from signal {signum} ({_signal_name(signum)})"
    return f"upstream MLX server exited with code {returncode}"


def _proxy_exit_code(returncode: int) -> int:
    if returncode < 0:
        return 128 + abs(returncode)
    return returncode if returncode else 1


STREAM_READ_CHUNK_SIZE = 64


def _iter_stream(resp: requests.Response, chunk_size: int = STREAM_READ_CHUNK_SIZE) -> Iterator[bytes]:
    with resp:
        # mlx_lm.server flushes SSE events but does not mark the response as
        # chunked. With chunk_size=None, requests can wait for EOF and collapse
        # the whole stream into one late delivery.
        for chunk in resp.iter_content(chunk_size=chunk_size):
            if chunk:
                yield chunk


def create_app(state: ProxyState) -> FastAPI:
    app = FastAPI()

    @app.get("/v1/models")
    async def list_models() -> Response:
        if not state.is_ready():
            return JSONResponse(
                status_code=503,
                content={"error": {"message": "Upstream MLX server is still starting."}},
            )
        return JSONResponse(
            content={
                "object": "list",
                "data": [
                    {
                        "id": state.display_model_id,
                        "object": "model",
                        "owned_by": "kamiwaza",
                    }
                ],
            }
        )

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request) -> Response:
        if not state.is_ready():
            return JSONResponse(
                status_code=503,
                content={"error": {"message": "Upstream MLX server is still starting."}},
            )
        try:
            payload = await request.json()
        except Exception:
            return JSONResponse(
                status_code=400,
                content={"error": {"message": "Request body must be valid JSON."}},
            )
        try:
            payload["model"] = state.normalize_model(payload.get("model"))
        except ValueError as exc:
            return JSONResponse(
                status_code=400,
                content={
                    "error": {
                        "message": str(exc),
                        "type": "invalid_request_error",
                    }
                },
            )
        headers = _filter_forward_headers(request)
        stream = bool(payload.get("stream"))
        upstream = requests.post(
            f"{state.upstream_base}/v1/chat/completions",
            json=payload,
            headers=headers,
            stream=stream,
            timeout=state.timeout,
        )
        media_type = upstream.headers.get("content-type", "application/json")
        if not stream:
            return Response(
                content=upstream.content,
                status_code=upstream.status_code,
                media_type=media_type,
            )
        if upstream.status_code >= 400:
            return Response(
                content=upstream.content,
                status_code=upstream.status_code,
                media_type=media_type,
            )
        return StreamingResponse(
            _iter_stream(upstream),
            status_code=upstream.status_code,
            headers={
                "Cache-Control": "no-cache, no-transform",
                "X-Accel-Buffering": "no",
            },
            media_type=media_type,
        )

    @app.get("/v1/allocator/stats")
    async def allocator_stats() -> Response:
        upstream = requests.get(
            f"{state.upstream_base}/v1/allocator/stats",
            timeout=state.timeout,
        )
        return Response(
            content=upstream.content,
            status_code=upstream.status_code,
            media_type=upstream.headers.get("content-type", "application/json"),
        )

    @app.get("/v1/kv_cache/stats")
    async def kv_cache_stats(request: Request) -> Response:
        upstream = requests.get(
            f"{state.upstream_base}/v1/kv_cache/stats",
            params=dict(request.query_params),
            timeout=state.timeout,
        )
        return Response(
            content=upstream.content,
            status_code=upstream.status_code,
            media_type=upstream.headers.get("content-type", "application/json"),
        )

    return app


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rank-0 proxy that locks an upstream mlx_lm.server to a single launched model."
    )
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--upstream-host", default="127.0.0.1")
    parser.add_argument("--upstream-port", type=int, required=True)
    parser.add_argument("--loaded-model-path", required=True)
    parser.add_argument("--model-alias", action="append", default=[])
    parser.add_argument("--timeout", type=float, default=900.0)
    parser.add_argument("upstream", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.upstream and args.upstream[0] == "--":
        args.upstream = args.upstream[1:]
    if not args.upstream:
        raise SystemExit("An upstream command is required after '--'.")
    return args


def main() -> None:
    args = _parse_args()
    aliases = _dedupe([args.loaded_model_path, Path(args.loaded_model_path).name, "local", *args.model_alias])
    state = ProxyState(
        loaded_model_path=args.loaded_model_path,
        accepted_models=set(aliases),
        display_model_id=_derive_display_model_id(args.loaded_model_path, aliases),
        upstream_host=args.upstream_host,
        upstream_port=args.upstream_port,
        upstream_command=list(args.upstream),
        timeout=float(args.timeout),
    )
    state.start()

    def _handle_signal(signum, _frame) -> None:
        state.stop()
        raise SystemExit(128 + int(signum))

    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    try:
        uvicorn.run(create_app(state), host=args.host, port=args.port)
    finally:
        state.stop()


if __name__ == "__main__":
    main()
