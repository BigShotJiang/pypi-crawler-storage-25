import signal
import unittest

from kamiwaza_mlx.distributed_proxy import (
    STREAM_READ_CHUNK_SIZE,
    _describe_child_returncode,
    _iter_stream,
    _proxy_exit_code,
)


class FakeStreamingResponse:
    def __init__(self, chunks):
        self.chunks = chunks
        self.chunk_size = None
        self.closed = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.closed = True

    def iter_content(self, chunk_size=None):
        self.chunk_size = chunk_size
        yield from self.chunks


class DistributedProxyStreamTests(unittest.TestCase):
    def test_iter_stream_uses_bounded_reads(self):
        response = FakeStreamingResponse([b"data: one\n\n", b"data: two\n\n"])

        self.assertEqual(list(_iter_stream(response)), [b"data: one\n\n", b"data: two\n\n"])
        self.assertEqual(response.chunk_size, STREAM_READ_CHUNK_SIZE)
        self.assertIsNotNone(response.chunk_size)
        self.assertTrue(response.closed)


class DistributedProxyExitCodeTests(unittest.TestCase):
    def test_proxy_exit_code_maps_signal_returncodes_to_shell_style_status(self):
        self.assertEqual(_proxy_exit_code(-signal.SIGKILL), 137)
        self.assertEqual(_proxy_exit_code(-signal.SIGTERM), 143)

    def test_proxy_exit_code_preserves_nonzero_exit_status(self):
        self.assertEqual(_proxy_exit_code(2), 2)

    def test_proxy_exit_code_uses_failure_for_clean_unexpected_child_exit(self):
        self.assertEqual(_proxy_exit_code(0), 1)

    def test_describe_child_returncode_includes_signal_name(self):
        self.assertIn("SIGKILL", _describe_child_returncode(-signal.SIGKILL))


if __name__ == "__main__":
    unittest.main()
