![barkd](https://gitlab.com/ark-bitcoin/barkd-clients/-/raw/master/assets/barkd-header-white.jpg)

# barkd-client

Auto-generated Python client for the **barkd REST API**, built from its OpenAPI specification.

## Installation

```bash
pip install barkd-client
```

## Usage

```python
import barkd_client
from barkd_client.rest import ApiException

config = barkd_client.Configuration(
    host="http://localhost:3535",
)

with barkd_client.ApiClient(config) as api_client:
    wallet = barkd_client.WalletApi(api_client)
    balance = wallet.balance()
```

## API Endpoints

All URIs are relative to *http://localhost*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*BitcoinApi* | **tip** | **GET** /api/v1/bitcoin/tip | Get bitcoin tip height
*BoardsApi* | **board_all** | **POST** /api/v1/boards/board-all | Board all on-chain bitcoin
*BoardsApi* | **board_amount** | **POST** /api/v1/boards/board-amount | Board a specific amount
*BoardsApi* | **get_pending_boards** | **GET** /api/v1/boards/pending | List pending boards
*DefaultApi* | **ping** | **GET** /ping | Ping
*ExitsApi* | **exit_claim_all** | **POST** /api/v1/exits/claim/all | Claim all exited VTXOs
*ExitsApi* | **exit_claim_vtxos** | **POST** /api/v1/exits/claim/vtxos | Claim specific exited VTXOs
*ExitsApi* | **exit_progress** | **POST** /api/v1/exits/progress | Progress exits
*ExitsApi* | **exit_start_all** | **POST** /api/v1/exits/start/all | Start exit for all VTXOs
*ExitsApi* | **exit_start_vtxos** | **POST** /api/v1/exits/start/vtxos | Start exit for specific VTXOs
*ExitsApi* | **get_all_exit_status** | **GET** /api/v1/exits/status | List all exit statuses
*ExitsApi* | **get_exit_status_by_vtxo_id** | **GET** /api/v1/exits/status/{vtxo_id} | Get exit status
*FeesApi* | **board_fee** | **GET** /api/v1/fees/board | Estimate board fee
*FeesApi* | **lightning_receive_fee** | **GET** /api/v1/fees/lightning/receive | Estimate Lightning receive fee
*FeesApi* | **lightning_send_fee** | **GET** /api/v1/fees/lightning/pay | Estimate Lightning send fee
*FeesApi* | **offboard_all_fee** | **GET** /api/v1/fees/offboard-all | Estimate offboard-all fee
*FeesApi* | **onchain_fee_rates** | **GET** /api/v1/fees/onchain | Get on-chain fee rates
*FeesApi* | **send_onchain_fee** | **GET** /api/v1/fees/send-onchain | Estimate send-onchain fee
*LightningApi* | **cancel_receive** | **DELETE** /api/v1/lightning/receives/{identifier} | Cancel a pending receive
*LightningApi* | **generate_invoice** | **POST** /api/v1/lightning/receives/invoice | Create a BOLT11 invoice
*LightningApi* | **get_receive_status** | **GET** /api/v1/lightning/receives/{identifier} | Get receive status
*LightningApi* | **list_receive_statuses** | **GET** /api/v1/lightning/receives | List all pending receive statuses
*LightningApi* | **pay** | **POST** /api/v1/lightning/pay | Send a Lightning payment
*NotificationsApi* | **websocket_ticket** | **GET** /api/v1/notifications/ws/ticket | Create a websocket ticket
*OnchainApi* | **onchain_address** | **POST** /api/v1/onchain/addresses/next | Generate on-chain address
*OnchainApi* | **onchain_balance** | **GET** /api/v1/onchain/balance | Get on-chain balance
*OnchainApi* | **onchain_drain** | **POST** /api/v1/onchain/drain | Drain on-chain wallet
*OnchainApi* | **onchain_send** | **POST** /api/v1/onchain/send | Send on-chain payment
*OnchainApi* | **onchain_send_many** | **POST** /api/v1/onchain/send-many | Send to multiple addresses
*OnchainApi* | **onchain_sync** | **POST** /api/v1/onchain/sync | Sync on-chain wallet
*OnchainApi* | **onchain_transactions** | **GET** /api/v1/onchain/transactions | List on-chain transactions
*OnchainApi* | **onchain_utxos** | **GET** /api/v1/onchain/utxos | List on-chain UTXOs
*WalletApi* | **address** | **POST** /api/v1/wallet/addresses/next | Generate Ark address
*WalletApi* | **ark_info** | **GET** /api/v1/wallet/ark-info | Get Ark server info
*WalletApi* | **balance** | **GET** /api/v1/wallet/balance | Get wallet balance
*WalletApi* | **connected** | **GET** /api/v1/wallet/connected | Check server connection
*WalletApi* | **create_wallet** | **POST** /api/v1/wallet/create | Create a wallet
*WalletApi* | **get_vtxo** | **GET** /api/v1/wallet/vtxos/{id} | Get VTXO detail
*WalletApi* | **get_vtxo_encoded** | **GET** /api/v1/wallet/vtxos/{id}/encoded | Get encoded VTXO
*WalletApi* | **history** | **GET** /api/v1/wallet/history | Get wallet history
*WalletApi* | **import_vtxo** | **POST** /api/v1/wallet/import-vtxo | Import a VTXO
*WalletApi* | **movements** | **GET** /api/v1/wallet/movements | List movements (deprecated)
*WalletApi* | **next_round** | **GET** /api/v1/wallet/next-round | Get next round time
*WalletApi* | **offboard_all** | **POST** /api/v1/wallet/offboard/all | Offboard all VTXOs
*WalletApi* | **offboard_vtxos** | **POST** /api/v1/wallet/offboard/vtxos | Offboard specific VTXOs
*WalletApi* | **peek_address** | **GET** /api/v1/wallet/addresses/index/{index} | Get Ark address by index
*WalletApi* | **pending_rounds** | **GET** /api/v1/wallet/rounds | List round participations
*WalletApi* | **refresh_all** | **POST** /api/v1/wallet/refresh/all | Refresh all VTXOs
*WalletApi* | **refresh_counterparty** | **POST** /api/v1/wallet/refresh/counterparty | Refresh received VTXOs
*WalletApi* | **refresh_vtxos** | **POST** /api/v1/wallet/refresh/vtxos | Refresh specific VTXOs
*WalletApi* | **send** | **POST** /api/v1/wallet/send | Send a payment
*WalletApi* | **send_onchain** | **POST** /api/v1/wallet/send-onchain | Send on-chain from Ark balance
*WalletApi* | **sync** | **POST** /api/v1/wallet/sync | Sync wallet
*WalletApi* | **sync_mailbox** | **POST** /api/v1/wallet/sync/mailbox | Sync mailbox only
*WalletApi* | **vtxos** | **GET** /api/v1/wallet/vtxos | List VTXOs
*WalletApi* | **wallet_delete** | **DELETE** /api/v1/wallet | 
*WalletApi* | **wallet_exists** | **GET** /api/v1/wallet | 


## License

Released under the **MIT** license.
