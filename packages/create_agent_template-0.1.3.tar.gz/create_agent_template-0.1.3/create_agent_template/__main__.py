from create_agent_template.cli import main
import sys

if __name__ == "__main__":
    sys.exit(main())
