"""TDD — openai-agents-maxia-oracle tools."""
import json
import pytest
import respx
import httpx
from agents.tool_context import ToolContext
from openai_agents_maxia_oracle import get_price, get_price_context, get_batch_prices
from openai_agents_maxia_oracle._client import ORACLE_BASE

FAKE_KEY = "mxo_test1234567890"


def make_ctx(tool_name: str, args: dict) -> ToolContext:
    raw = json.dumps(args)
    return ToolContext(
        context=None, usage=None, turn_input=None,
        tool_input=raw, tool_name=tool_name, tool_call_id="test",
        tool_arguments=raw, tool_call=None, tool_namespace=None,
        agent=None, run_config=None,
    )


@pytest.fixture(autouse=True)
def set_env(monkeypatch):
    monkeypatch.setenv("MAXIA_API_KEY", FAKE_KEY)


# ── tool metadata ──────────────────────────────────────────────────────────────

def test_tools_are_function_tools():
    from agents import FunctionTool
    assert isinstance(get_price, FunctionTool)
    assert isinstance(get_price_context, FunctionTool)
    assert isinstance(get_batch_prices, FunctionTool)


def test_tool_names():
    assert get_price.name == "get_price"
    assert get_price_context.name == "get_price_context"
    assert get_batch_prices.name == "get_batch_prices"


def test_tools_have_descriptions():
    for tool in (get_price, get_price_context, get_batch_prices):
        assert tool.description and len(tool.description) > 20


# ── get_price ──────────────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_get_price_calls_correct_endpoint():
    route = respx.get(f"{ORACLE_BASE}/api/price/BTC").mock(
        return_value=httpx.Response(200, json={"data": {"symbol": "BTC", "price": 60000}})
    )
    ctx = make_ctx("get_price", {"symbol": "BTC"})
    result = await get_price.on_invoke_tool(ctx, json.dumps({"symbol": "BTC"}))
    assert route.called
    parsed = json.loads(result)
    assert parsed["data"]["price"] == 60000


@respx.mock
@pytest.mark.asyncio
async def test_get_price_sends_api_key():
    respx.get(f"{ORACLE_BASE}/api/price/ETH").mock(
        return_value=httpx.Response(200, json={"data": {"symbol": "ETH", "price": 3000}})
    )
    ctx = make_ctx("get_price", {"symbol": "ETH"})
    await get_price.on_invoke_tool(ctx, json.dumps({"symbol": "ETH"}))
    request = respx.calls.last.request
    assert request.headers.get("x-api-key") == FAKE_KEY


@respx.mock
@pytest.mark.asyncio
async def test_get_price_upcases_symbol():
    route = respx.get(f"{ORACLE_BASE}/api/price/SOL").mock(
        return_value=httpx.Response(200, json={"data": {"symbol": "SOL", "price": 150}})
    )
    ctx = make_ctx("get_price", {"symbol": "sol"})
    await get_price.on_invoke_tool(ctx, json.dumps({"symbol": "sol"}))
    assert route.called


@respx.mock
@pytest.mark.asyncio
async def test_get_price_returns_error_on_429():
    respx.get(f"{ORACLE_BASE}/api/price/BTC").mock(
        return_value=httpx.Response(429, json={"error": "rate limit exceeded", "upgrade_url": "https://oracle.maxiaworld.app/#pricing"})
    )
    ctx = make_ctx("get_price", {"symbol": "BTC"})
    result = await get_price.on_invoke_tool(ctx, json.dumps({"symbol": "BTC"}))
    parsed = json.loads(result)
    assert "error" in parsed
    assert "429" in parsed["error"]


# ── get_price_context ──────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_get_price_context_calls_context_endpoint():
    route = respx.get(f"{ORACLE_BASE}/api/price/ETH/context").mock(
        return_value=httpx.Response(200, json={"data": {"symbol": "ETH", "confidence": 0.97, "anomaly": False}})
    )
    ctx = make_ctx("get_price_context", {"symbol": "ETH"})
    result = await get_price_context.on_invoke_tool(ctx, json.dumps({"symbol": "ETH"}))
    assert route.called
    parsed = json.loads(result)
    assert parsed["data"]["confidence"] == 0.97


# ── get_batch_prices ───────────────────────────────────────────────────────────

@respx.mock
@pytest.mark.asyncio
async def test_get_batch_prices_posts_symbols():
    route = respx.post(f"{ORACLE_BASE}/api/prices/batch").mock(
        return_value=httpx.Response(200, json={"data": {"prices": {"BTC": 60000, "ETH": 3000}}})
    )
    ctx = make_ctx("get_batch_prices", {"symbols": ["BTC", "ETH"]})
    result = await get_batch_prices.on_invoke_tool(ctx, json.dumps({"symbols": ["BTC", "ETH"]}))
    assert route.called
    body = json.loads(route.calls.last.request.content)
    assert body["symbols"] == ["BTC", "ETH"]
    parsed = json.loads(result)
    assert parsed["data"]["prices"]["BTC"] == 60000


@pytest.mark.asyncio
async def test_get_batch_prices_rejects_over_50():
    symbols = [f"SYM{i}" for i in range(51)]
    ctx = make_ctx("get_batch_prices", {"symbols": symbols})
    result = await get_batch_prices.on_invoke_tool(ctx, json.dumps({"symbols": symbols}))
    parsed = json.loads(result)
    assert "error" in parsed
    assert "50" in parsed["error"]
