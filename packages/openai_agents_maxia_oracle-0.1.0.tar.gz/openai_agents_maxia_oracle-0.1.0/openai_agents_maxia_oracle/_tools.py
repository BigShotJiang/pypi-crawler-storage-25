from __future__ import annotations
import json
from agents import function_tool
from ._client import get, post


@function_tool
async def get_price(symbol: str) -> str:
    """Fetch the latest aggregated crypto price from MAXIA Oracle (8 independent sources:
    Pyth, Chainlink, RedStone, Binance, Kraken, CoinGecko, Uniswap v3 TWAP, Pyth Solana).
    Returns a cross-validated median price. Use before any trade decision.

    Args:
        symbol: Crypto ticker, e.g. BTC, ETH, SOL, KAS.
    """
    data = await get(f"/api/price/{symbol.upper()}")
    return json.dumps(data)


@function_tool
async def get_price_context(symbol: str) -> str:
    """Fetch price + confidence score + anomaly flag for a crypto symbol.
    Confidence is 0-1 (higher = more source agreement). Anomaly is true when sources
    diverge beyond threshold. Skip the trade if confidence < 0.9 or anomaly is true.

    Args:
        symbol: Crypto ticker, e.g. BTC, ETH, SOL.
    """
    data = await get(f"/api/price/{symbol.upper()}/context")
    return json.dumps(data)


@function_tool
async def get_batch_prices(symbols: list[str]) -> str:
    """Fetch prices for up to 50 crypto symbols in a single request.
    Use when the agent needs prices for a portfolio or multiple assets at once.

    Args:
        symbols: List of crypto tickers, e.g. ['BTC', 'ETH', 'SOL']. Max 50.
    """
    if len(symbols) > 50:
        return json.dumps({"error": "Too many symbols: max 50 per request."})
    data = await post("/api/prices/batch", {"symbols": [s.upper() for s in symbols]})
    return json.dumps(data)
