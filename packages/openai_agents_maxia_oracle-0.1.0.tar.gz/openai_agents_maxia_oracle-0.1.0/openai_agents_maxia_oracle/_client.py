from __future__ import annotations
import os
import httpx

ORACLE_BASE = "https://oracle.maxiaworld.app"


def _api_key() -> str:
    return os.environ.get("MAXIA_API_KEY", "")


def _headers() -> dict[str, str]:
    return {"X-API-Key": _api_key()}


async def get(path: str) -> dict:
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{ORACLE_BASE}{path}", headers=_headers())
        return _wrap(r)


async def post(path: str, body: dict) -> dict:
    async with httpx.AsyncClient() as client:
        r = await client.post(f"{ORACLE_BASE}{path}", json=body, headers=_headers())
        return _wrap(r)


def _wrap(r: httpx.Response) -> dict:
    data = r.json()
    if not r.is_success:
        return {"error": f"HTTP {r.status_code}", "detail": data}
    return data
