# openai-agents-maxia-oracle

OpenAI Agents SDK tools for [MAXIA Oracle](https://oracle.maxiaworld.app) — multi-source crypto price feeds for AI agents.

## Install

```bash
pip install openai-agents-maxia-oracle
```

## Usage

```python
import os
from agents import Agent, Runner
from openai_agents_maxia_oracle import get_price, get_price_context, get_batch_prices

os.environ["MAXIA_API_KEY"] = "mxo_..."  # or set in env

agent = Agent(
    name="crypto-assistant",
    instructions="Use MAXIA Oracle to answer price questions accurately.",
    tools=[get_price, get_price_context, get_batch_prices],
)

result = Runner.run_sync(agent, "What is ETH trading at right now?")
print(result.final_output)
```

Get a free API key (100 req/day, no email): [oracle.maxiaworld.app](https://oracle.maxiaworld.app)

## Tools

| Tool | Description |
|---|---|
| `get_price` | Multi-source median price (8 sources: Pyth, Chainlink, RedStone, Binance, Kraken…) |
| `get_price_context` | Price + confidence score + anomaly flag |
| `get_batch_prices` | Prices for up to 50 symbols in one request |

## License

Apache-2.0
