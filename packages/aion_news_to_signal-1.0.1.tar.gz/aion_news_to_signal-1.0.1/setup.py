from setuptools import setup


setup(
    name="aion-news-to-signal",
    version="1.0.1",
    description="Offline/self-hosted AION News-to-Signal package for Indian financial news analysis.",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=["aion", "aion_news_to_signal"],
    include_package_data=True,
    package_data={
        "aion": [
            "taxonomy/*.yaml",
            "data/*.csv",
            "models/*",
        ],
    },
    install_requires=[
        "torch==2.10.0",
        "transformers==5.3.0",
        "sentencepiece",
        "pandas",
        "numpy",
        "pyyaml",
        "huggingface_hub==1.7.1",
        "safetensors",
        "mcp>=1.27",
    ],
    entry_points={
        "console_scripts": [
            "aion-news-to-signal-mcp=aion_news_to_signal.mcp_server:main",
        ]
    },
    python_requires=">=3.10",
)
