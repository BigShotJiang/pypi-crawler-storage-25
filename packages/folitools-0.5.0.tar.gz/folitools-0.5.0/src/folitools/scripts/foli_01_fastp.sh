#!/usr/bin/env bash

set -euo pipefail

script_dir=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
source "$script_dir/utils.sh"

# Help function
show_help() {
    echo "Usage: foli_01_fastp.sh <input_files> [output_dir] [threads] [skip] [delete]"
    echo "  input_files : Space-separated list of R1 FASTQ file paths (.fq/.fastq/.fq.gz/.fastq.gz)"
    echo "  output_dir  : Output directory for trimmed files (default: ./fastp)"
    echo "  threads     : Number of threads to use (default: 16)"
    echo "  skip        : Skip certain steps (default: 0)"
    echo "  delete      : Delete intermediate files (default: false)"
    echo "  -h, --help  : Show this help message"
    exit 0
}

# Check for help option
if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
    show_help
fi

INPUT_FILES="${1}"  # Space-separated list of actual file paths
OUTPUT_DIR="${2:-./fastp}"  # Output directory for trimmed files
THREADS="${3:-16}"
SKIP="${4:-0}"
DELETE="${5:-false}"

FASTP_DIR="$OUTPUT_DIR"
FASTP_FASTQC_DIR="${OUTPUT_DIR}_fastqc"

mkdir -p "$FASTP_DIR" "$FASTP_FASTQC_DIR"

# Create a temporary directory for input FastQC (only if files are found)
FASTQ_FASTQC_DIR="./fastq_fastqc"
mkdir -p "$FASTQ_FASTQC_DIR"

# Convert space-separated string back to array
read -ra fqr1s <<< "$INPUT_FILES"

# Validate that all files are FASTQ format
validate_file_formats "$INPUT_FILES" "fastq"

############################################
# Main loop over paired-end FASTQs
############################################
i=0
for fqR1 in "${fqr1s[@]}"; do
    ((++i))
    if [[ $i -le $SKIP ]]; then
        echo "Skipping sample $i: $fqR1"
        continue
    fi
    
    # Derive the matching R2 using utility function
    fqR2="$(derive_r2_from_r1 "$fqR1")"
    sample_name="$(extract_sample_name "$fqR1")"
    trimmed_R1="$FASTP_DIR/${sample_name}_1.fq.gz"
    trimmed_R2="$FASTP_DIR/${sample_name}_2.fq.gz"

    # skip if "$FASTP_DIR/${sample_name}_1.fq.gz" already exists
    # if [[ -f "$trimmed_R1" && -f "$trimmed_R2" ]]; then
    #     echo "Skipping already processed sample: $sample_name"
    #     continue
    # fi

    # Skip if no matching R2
    if [[ ! -f "$fqR2" ]]; then
        echo "WARNING: Could not find R2 for: $fqR1"
        continue
    fi
    echo "Processing sample: $sample_name"

    # run_fastqc "$fqR1" "$fqR2" "$FASTP_FASTQC_DIR" "$THREADS"

    # Run fastqc "$fqR1" "$fqR2" "$FASTQ_FASTQC_DIR" "$THREADS"
    # NOTE:
    # We saw in our NovaSeq X Plus sequencing data that read-through do not necessarily 
    # end with poly-G tails, but rather a mixture of poly-G and poly-X and some other jibberish.
    # In these case fastp cannot properly do poly-G trimming and overlap analysis will 
    # also fail. That's why here we must use this extra step to remove TruSeq adapters 
    # with cutadapt (since fastp adapter removal is not as flexible).
    fastp \
        --in1 "$fqR1" \
        --in2 "$fqR2" \
        --stdout \
        --thread "$THREADS" \
        --cut_tail \
        --correction \
        --html "$FASTP_DIR/${sample_name}.fastp.html" \
        --json "$FASTP_DIR/${sample_name}.fastp.json" \
        2> /dev/null | cutadapt \
            -e 0.1 \
            -a "AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC;min_overlap=5" \
            -A "AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT;min_overlap=5" \
            -j "$THREADS" \
            --interleaved \
            -o "$trimmed_R1" \
            -p "$trimmed_R2" \
            - &> /dev/null
        # --trim_poly_g \
        # --trim_poly_x \
        # --adapter_sequence AGATCGGAAGAGCACACGTC \
        # --adapter_sequence_r2 AGATCGGAAGAGCGTCGTGT \
        # Adapter sequences are the first 20bp of Illumina TruSeq adapters:
        # i7 adapter: AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC
        # i5 adapter: AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT

    # fastp \
    #     --in1 "$fqR1" \
    #     --in2 "$fqR2" \
    #     --out1 "$trimmed_R1" \
    #     --out2 "$trimmed_R2" \
    #     --thread "$THREADS" \
    #     --cut_tail \
    #     --correction \
    #     --html "$FASTP_DIR/${sample_name}.fastp.html" \
    #     --json "$FASTP_DIR/${sample_name}.fastp.json" \
    #     2> /dev/null

    run_fastqc "$trimmed_R1" "$trimmed_R2" "$FASTP_FASTQC_DIR" "$THREADS"

    # Remove input FASTQs to save space
    if [[ "$DELETE" == "True" ]]; then
        rm "$fqR1" "$fqR2"
    fi
done | tqdm --total ${#fqr1s[@]} > /dev/null

run_seqkit_stats "$FASTP_DIR"

echo "Preprocessing pipeline completed successfully!"
