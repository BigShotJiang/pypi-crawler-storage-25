"""System integration document generator for multi-ECU systems.

Produces a Markdown / LaTeX / HTML document that describes the system as a
whole — the per-ECU details remain in each ECU's individual document
(generated via the existing single-ECU `TexGenerator`). The system document
covers:

  - System name, ECU roster (name, role, description)
  - Topology table and topology diagram (SVG inline for HTML, TikZ figure for LaTeX)
  - Routing matrix (each rule's match criteria, inferred flag)
  - Per-rule sequence diagram (LaTeX only)
  - Cross-ECU coverage tables: SID, DID, RID per ECU
  - Cross-ECU NRC table
  - Validation findings (calls validate_system)

Public API:
    generate_system_markdown(system, *, validate=True) -> str
    generate_system_latex(system, *, validate=True)    -> str
    generate_system_html(system, *, validate=True)     -> str
"""

from __future__ import annotations

from typing import Any, Iterable

from udsxml2tex.multi_ecu.models import EcuSystem, RoutingRule
from udsxml2tex.multi_ecu.validator import validate_system


# ----------------------------------------------------------------------------
# Shared helpers
# ----------------------------------------------------------------------------

def _all_sids(system: EcuSystem) -> list[int]:
    return sorted({s.service_id for ecu in system.ecus.values()
                   if ecu.spec for s in (ecu.spec.services or [])})


def _all_dids(system: EcuSystem) -> list[int]:
    return sorted({d.did_id for ecu in system.ecus.values()
                   if ecu.spec for d in (ecu.spec.dids or [])})


def _all_rids(system: EcuSystem) -> list[int]:
    return sorted({r.routine_id for ecu in system.ecus.values()
                   if ecu.spec for r in (ecu.spec.routines or [])})


def _all_nrcs(system: EcuSystem) -> dict[int, str]:
    out: dict[int, str] = {}
    for ecu in system.ecus.values():
        if not ecu.spec:
            continue
        for svc in (ecu.spec.services or []):
            for nrc in (svc.nrc_list or []):
                out.setdefault(nrc.nrc_code, nrc.nrc_name)
    return dict(sorted(out.items()))


def _has_sid(spec: Any, sid: int) -> bool:
    return any(s.service_id == sid for s in (spec.services or []))


def _has_did(spec: Any, did: int) -> bool:
    return any(d.did_id == did for d in (spec.dids or []))


def _has_rid(spec: Any, rid: int) -> bool:
    return any(r.routine_id == rid for r in (spec.routines or []))


def _has_nrc(spec: Any, nrc_code: int) -> bool:
    for svc in (spec.services or []):
        if any(n.nrc_code == nrc_code for n in (svc.nrc_list or [])):
            return True
    return False


# ----------------------------------------------------------------------------
# Markdown
# ----------------------------------------------------------------------------

def generate_system_markdown(system: EcuSystem, *, validate: bool = True) -> str:
    lines: list[str] = []
    lines.append(f"# System Integration Document: {system.name}")
    if system.description:
        lines.append("")
        lines.append(system.description)
    lines.append("")

    # ECU roster
    lines.append("## ECU Roster")
    lines.append("")
    lines.append("| Name | Role | ARXML | DEM | Description |")
    lines.append("|---|---|---|---|---|")
    for ecu in system.ecus.values():
        arxml = ", ".join(p.name for p in ecu.arxml_files) or "—"
        dem = ecu.dem_arxml.name if ecu.dem_arxml else "—"
        desc = ecu.description or ""
        lines.append(
            f"| **{ecu.name}** | `{ecu.role.value}` | {arxml} | {dem} | {desc} |"
        )
    lines.append("")

    # Topology
    if system.topology.connections:
        lines.append("## Physical Topology")
        lines.append("")
        lines.append("| From | To | Medium | Description |")
        lines.append("|---|---|---|---|")
        for c in system.topology.connections:
            lines.append(
                f"| {c.from_ecu} | {c.to_ecu} | {c.medium} | {c.description or ''} |"
            )
        lines.append("")

    # Routing matrix
    if system.routing_rules:
        lines.append("## Routing Matrix")
        lines.append("")
        lines.append(
            "Diagnostic requests received by the source ECU that match the "
            "criteria below are forwarded to the target ECU. Rules tagged "
            "*inferred* were derived heuristically from ARXML coverage gaps; "
            "review and convert them into explicit rules in the system "
            "config when verified."
        )
        lines.append("")
        lines.append("| # | From | To | Match | Via | Source | Description |")
        lines.append("|---|---|---|---|---|---|---|")
        for i, r in enumerate(system.routing_rules, start=1):
            origin = "inferred" if r.inferred else "explicit"
            via = r.via or "—"
            lines.append(
                f"| {i} | {r.from_ecu} | {r.to_ecu} | "
                f"{r.match.description()} | {via} | {origin} | "
                f"{r.description or ''} |"
            )
        lines.append("")

    # Cross-ECU coverage matrices
    ecu_names = list(system.ecus.keys())

    sids = _all_sids(system)
    if sids:
        lines.append("## SID × ECU Coverage")
        lines.append("")
        header = "| SID |" + "".join(f" {n} |" for n in ecu_names)
        sep = "|---|" + "|".join("---" for _ in ecu_names) + "|"
        lines.append(header)
        lines.append(sep)
        for sid in sids:
            row = f"| `0x{sid:02X}` |"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += " ✓ |" if spec and _has_sid(spec, sid) else " — |"
            lines.append(row)
        lines.append("")

    dids = _all_dids(system)
    if dids:
        lines.append("## DID × ECU Coverage")
        lines.append("")
        header = "| DID |" + "".join(f" {n} |" for n in ecu_names)
        sep = "|---|" + "|".join("---" for _ in ecu_names) + "|"
        lines.append(header)
        lines.append(sep)
        for did in dids:
            row = f"| `0x{did:04X}` |"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += " ✓ |" if spec and _has_did(spec, did) else " — |"
            lines.append(row)
        lines.append("")

    rids = _all_rids(system)
    if rids:
        lines.append("## RID × ECU Coverage")
        lines.append("")
        header = "| RID |" + "".join(f" {n} |" for n in ecu_names)
        sep = "|---|" + "|".join("---" for _ in ecu_names) + "|"
        lines.append(header)
        lines.append(sep)
        for rid in rids:
            row = f"| `0x{rid:04X}` |"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += " ✓ |" if spec and _has_rid(spec, rid) else " — |"
            lines.append(row)
        lines.append("")

    nrcs = _all_nrcs(system)
    if nrcs:
        lines.append("## NRC × ECU Coverage")
        lines.append("")
        header = "| NRC | Description |" + "".join(f" {n} |" for n in ecu_names)
        sep = "|---|---|" + "|".join("---" for _ in ecu_names) + "|"
        lines.append(header)
        lines.append(sep)
        for code, name in nrcs.items():
            row = f"| `0x{code:02X}` | {name} |"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += " ✓ |" if spec and _has_nrc(spec, code) else " — |"
            lines.append(row)
        lines.append("")

    # Validation
    if validate:
        result = validate_system(system)
        lines.append("## Cross-ECU Validation")
        lines.append("")
        lines.append(f"**Result:** {result.summary()}")
        lines.append("")
        if result.issues:
            lines.append("| Severity | Category | Item | Message |")
            lines.append("|---|---|---|---|")
            for issue in result.issues:
                lines.append(
                    f"| {issue.severity} | {issue.category} | "
                    f"{issue.item_id or '—'} | {issue.message} |"
                )
        else:
            lines.append("✓ No cross-ECU consistency issues detected.")
        lines.append("")

    return "\n".join(lines)


# ----------------------------------------------------------------------------
# LaTeX
# ----------------------------------------------------------------------------

def _tex_escape(s: str) -> str:
    return (
        s.replace("\\", r"\textbackslash{}")
         .replace("&", r"\&")
         .replace("%", r"\%")
         .replace("#", r"\#")
         .replace("_", r"\_")
         .replace("$", r"\$")
         .replace("{", r"\{")
         .replace("}", r"\}")
         .replace("^", r"\^{}")
         .replace("~", r"\~{}")
    )


def generate_system_latex(system: EcuSystem, *, validate: bool = True) -> str:
    """Standalone LaTeX article for the system integration document.

    Compiles independently with `pdflatex` / `xelatex`. Includes the topology
    figure inline (as a tikzpicture) — no external image dependency.
    """
    from udsxml2tex.multi_ecu.visualizations import generate_topology_tikz

    lines: list[str] = []
    lines.append(r"\documentclass[11pt,a4paper]{article}")
    lines.append(r"\usepackage[margin=2.5cm]{geometry}")
    lines.append(r"\usepackage{tikz}")
    lines.append(r"\usepackage{xcolor}")
    lines.append(r"\usepackage{longtable}")
    lines.append(r"\usepackage{booktabs}")
    lines.append(r"\usepackage{array}")
    lines.append(r"\usepackage{hyperref}")
    lines.append(r"\usetikzlibrary{positioning, arrows.meta, shapes.geometric, calc}")
    lines.append(r"\definecolor{ecugw}{HTML}{334466}")
    lines.append(r"\definecolor{ecuep}{HTML}{2A6E2A}")
    lines.append(r"\definecolor{ecupeer}{HTML}{996600}")
    lines.append(r"\title{System Integration Document\\\large " + _tex_escape(system.name) + "}")
    lines.append(r"\author{Generated by udsxml2tex}")
    lines.append(r"\date{\today}")
    lines.append(r"\begin{document}")
    lines.append(r"\maketitle")
    if system.description:
        lines.append(r"\begin{abstract}")
        lines.append(_tex_escape(system.description))
        lines.append(r"\end{abstract}")

    # ECU roster
    lines.append(r"\section{ECU Roster}")
    lines.append(r"\begin{longtable}{lll p{6cm}}")
    lines.append(r"\toprule")
    lines.append(r"\textbf{Name} & \textbf{Role} & \textbf{ARXML} & \textbf{Description} \\")
    lines.append(r"\midrule")
    for ecu in system.ecus.values():
        arxml = _tex_escape(", ".join(p.name for p in ecu.arxml_files) or "—")
        desc = _tex_escape(ecu.description or "")
        lines.append(
            f"\\textbf{{{_tex_escape(ecu.name)}}} & "
            f"\\texttt{{{ecu.role.value}}} & {arxml} & {desc} \\\\"
        )
    lines.append(r"\bottomrule")
    lines.append(r"\end{longtable}")

    # Topology figure (extract tikzpicture from standalone wrapper)
    lines.append(r"\section{System Topology}")
    topo_full = generate_topology_tikz(system)
    # Pull out just the tikzpicture environment
    start = topo_full.find(r"\begin{tikzpicture}")
    end = topo_full.find(r"\end{tikzpicture}") + len(r"\end{tikzpicture}")
    if start >= 0 and end > start:
        lines.append(r"\begin{figure}[h!]")
        lines.append(r"\centering")
        lines.append(topo_full[start:end])
        lines.append(r"\caption{System topology: ECUs and routing flows.}")
        lines.append(r"\end{figure}")

    if system.topology.connections:
        lines.append(r"\subsection{Physical Connections}")
        lines.append(r"\begin{longtable}{lllp{5cm}}")
        lines.append(r"\toprule")
        lines.append(r"\textbf{From} & \textbf{To} & \textbf{Medium} & \textbf{Description} \\")
        lines.append(r"\midrule")
        for c in system.topology.connections:
            lines.append(
                f"{_tex_escape(c.from_ecu)} & {_tex_escape(c.to_ecu)} & "
                f"{_tex_escape(c.medium)} & {_tex_escape(c.description or '')} \\\\"
            )
        lines.append(r"\bottomrule")
        lines.append(r"\end{longtable}")

    # Routing matrix
    if system.routing_rules:
        lines.append(r"\section{Routing Matrix}")
        lines.append(
            r"Diagnostic requests received by the source ECU that match the "
            r"criteria below are forwarded to the target ECU. Rules tagged "
            r"\emph{inferred} were derived heuristically from ARXML coverage "
            r"gaps; verify and convert them into explicit rules when confirmed."
        )
        lines.append(r"\begin{longtable}{lllp{4.5cm}lp{3cm}}")
        lines.append(r"\toprule")
        lines.append(r"\textbf{\#} & \textbf{From} & \textbf{To} & "
                     r"\textbf{Match} & \textbf{Origin} & \textbf{Description} \\")
        lines.append(r"\midrule")
        for i, r in enumerate(system.routing_rules, start=1):
            origin = "inferred" if r.inferred else "explicit"
            lines.append(
                f"{i} & {_tex_escape(r.from_ecu)} & {_tex_escape(r.to_ecu)} & "
                f"{_tex_escape(r.match.description())} & "
                f"\\texttt{{{origin}}} & {_tex_escape(r.description or '')} \\\\"
            )
        lines.append(r"\bottomrule")
        lines.append(r"\end{longtable}")

    # Cross-ECU coverage tables
    ecu_names = list(system.ecus.keys())
    n = len(ecu_names)
    cols = "l" + "c" * n

    def _coverage_section(title: str, ids: Iterable[int], fmt: str,
                           predicate, extra_col: bool = False,
                           extra_label: str = "") -> None:
        lst = list(ids)
        if not lst:
            return
        lines.append(r"\subsection{" + title + "}")
        ec = "l" if extra_col else ""
        lines.append(r"\begin{longtable}{l" + ec + "c" * n + "}")
        lines.append(r"\toprule")
        head = r"\textbf{ID}"
        if extra_col:
            head += " & \\textbf{" + extra_label + "}"
        for nm in ecu_names:
            head += " & \\textbf{" + _tex_escape(nm) + "}"
        head += r" \\"
        lines.append(head)
        lines.append(r"\midrule")
        for x in lst:
            row = f"\\texttt{{{fmt.format(x)}}}"
            if extra_col:
                # Caller provides extra_label_value via predicate signature is awkward —
                # callers below build their own rows when extra_col is needed.
                continue
            for nm in ecu_names:
                spec = system.ecus[nm].spec
                row += " & " + ("$\\bullet$" if spec and predicate(spec, x) else "---")
            row += r" \\"
            lines.append(row)
        lines.append(r"\bottomrule")
        lines.append(r"\end{longtable}")

    lines.append(r"\section{Cross-ECU Coverage}")
    _coverage_section("SID Coverage", _all_sids(system), "0x{:02X}", _has_sid)
    _coverage_section("DID Coverage", _all_dids(system), "0x{:04X}", _has_did)
    _coverage_section("RID Coverage", _all_rids(system), "0x{:04X}", _has_rid)

    # NRC table needs description column → render manually
    nrcs = _all_nrcs(system)
    if nrcs:
        lines.append(r"\subsection{NRC Coverage}")
        lines.append(r"\begin{longtable}{lp{6cm}" + "c" * n + "}")
        lines.append(r"\toprule")
        head = r"\textbf{NRC} & \textbf{Description}"
        for nm in ecu_names:
            head += " & \\textbf{" + _tex_escape(nm) + "}"
        head += r" \\"
        lines.append(head)
        lines.append(r"\midrule")
        for code, name in nrcs.items():
            row = f"\\texttt{{0x{code:02X}}} & {_tex_escape(name)}"
            for nm in ecu_names:
                spec = system.ecus[nm].spec
                row += " & " + ("$\\bullet$" if spec and _has_nrc(spec, code) else "---")
            row += r" \\"
            lines.append(row)
        lines.append(r"\bottomrule")
        lines.append(r"\end{longtable}")

    # Validation
    if validate:
        result = validate_system(system)
        lines.append(r"\section{Cross-ECU Validation}")
        lines.append(r"\textbf{Result:} " + _tex_escape(result.summary()) + r"\\")
        if result.issues:
            lines.append(r"\begin{longtable}{llp{3cm}p{6cm}}")
            lines.append(r"\toprule")
            lines.append(r"\textbf{Severity} & \textbf{Category} & "
                         r"\textbf{Item} & \textbf{Message} \\")
            lines.append(r"\midrule")
            for issue in result.issues:
                lines.append(
                    f"\\texttt{{{issue.severity}}} & {_tex_escape(issue.category)} & "
                    f"{_tex_escape(issue.item_id or '—')} & "
                    f"{_tex_escape(issue.message)} \\\\"
                )
            lines.append(r"\bottomrule")
            lines.append(r"\end{longtable}")
        else:
            lines.append(r"No cross-ECU consistency issues detected.")

    lines.append(r"\end{document}")
    return "\n".join(lines)


# ----------------------------------------------------------------------------
# HTML
# ----------------------------------------------------------------------------

def _html_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
         .replace('"', "&quot;").replace("'", "&#39;")
    )


_HTML_CSS = """
* { box-sizing: border-box; }
body { font-family: Georgia, "Times New Roman", serif; font-size: 14px;
       line-height: 1.6; color: #111; max-width: 1100px;
       margin: 0 auto; padding: 2.5em 3em; background: #fff; }
h1 { font-size: 1.9em; border-bottom: 2px solid #111; padding-bottom: 0.25em; }
h2 { font-size: 1.3em; border-bottom: 1px solid #999; padding-bottom: 0.15em;
     margin-top: 2em; }
h3 { font-size: 1.05em; margin-top: 1.4em; }
table { border-collapse: collapse; margin: 0.8em 0 1.4em; font-size: 0.9em;
        font-family: Arial, Helvetica, sans-serif; }
th { background: #ebebea; color: #111; padding: 6px 10px;
     border: 1px solid #999; text-align: left; }
td { padding: 5px 10px; border: 1px solid #bbb; vertical-align: top; }
tr:nth-child(even) td { background: #f7f7f7; }
code { font-family: "Courier New", Courier, monospace; }
.role-gateway { color: #334466; font-weight: bold; }
.role-endpoint { color: #2A6E2A; font-weight: bold; }
.role-peer { color: #996600; font-weight: bold; }
.tick { color: #2A6E2A; font-weight: bold; }
.miss { color: #aaa; }
.severity-error { color: #aa2222; font-weight: bold; }
.severity-warning { color: #996600; font-weight: bold; }
.severity-info { color: #334466; }
.inferred { font-style: italic; color: #888; }
"""


def generate_system_html(system: EcuSystem, *, validate: bool = True) -> str:
    """Standalone HTML page for the system integration document."""
    from udsxml2tex.multi_ecu.visualizations import generate_topology_html

    parts: list[str] = []
    parts.append("<!DOCTYPE html><html lang='en'><head>")
    parts.append("<meta charset='UTF-8'>")
    parts.append(f"<title>System Integration: {_html_escape(system.name)}</title>")
    parts.append(f"<style>{_HTML_CSS}</style>")
    parts.append("</head><body>")
    parts.append(f"<h1>System Integration Document &mdash; {_html_escape(system.name)}</h1>")
    if system.description:
        parts.append(f"<p>{_html_escape(system.description)}</p>")

    parts.append("<h2>ECU Roster</h2>")
    parts.append("<table><thead><tr><th>Name</th><th>Role</th><th>ARXML</th>"
                 "<th>DEM</th><th>Description</th></tr></thead><tbody>")
    for ecu in system.ecus.values():
        arxml = ", ".join(p.name for p in ecu.arxml_files) or "—"
        dem = ecu.dem_arxml.name if ecu.dem_arxml else "—"
        parts.append(
            f"<tr><td><strong>{_html_escape(ecu.name)}</strong></td>"
            f"<td><span class='role-{ecu.role.value}'>{ecu.role.value}</span></td>"
            f"<td>{_html_escape(arxml)}</td>"
            f"<td>{_html_escape(dem)}</td>"
            f"<td>{_html_escape(ecu.description or '')}</td></tr>"
        )
    parts.append("</tbody></table>")

    parts.append("<h2>System Topology</h2>")
    parts.append(generate_topology_html(system))

    if system.topology.connections:
        parts.append("<h3>Physical Connections</h3>")
        parts.append("<table><thead><tr><th>From</th><th>To</th><th>Medium</th>"
                     "<th>Description</th></tr></thead><tbody>")
        for c in system.topology.connections:
            parts.append(
                f"<tr><td>{_html_escape(c.from_ecu)}</td>"
                f"<td>{_html_escape(c.to_ecu)}</td>"
                f"<td>{_html_escape(c.medium)}</td>"
                f"<td>{_html_escape(c.description or '')}</td></tr>"
            )
        parts.append("</tbody></table>")

    if system.routing_rules:
        parts.append("<h2>Routing Matrix</h2>")
        parts.append("<p>Diagnostic requests received by the source ECU that match "
                     "the criteria below are forwarded to the target. Rules in "
                     "italic are inferred from ARXML coverage gaps and should be "
                     "reviewed.</p>")
        parts.append("<table><thead><tr><th>#</th><th>From</th><th>To</th>"
                     "<th>Match</th><th>Via</th><th>Origin</th>"
                     "<th>Description</th></tr></thead><tbody>")
        for i, r in enumerate(system.routing_rules, start=1):
            origin = "inferred" if r.inferred else "explicit"
            klass = ' class="inferred"' if r.inferred else ""
            parts.append(
                f"<tr{klass}><td>{i}</td>"
                f"<td>{_html_escape(r.from_ecu)}</td>"
                f"<td>{_html_escape(r.to_ecu)}</td>"
                f"<td>{_html_escape(r.match.description())}</td>"
                f"<td>{_html_escape(r.via or '—')}</td>"
                f"<td><code>{origin}</code></td>"
                f"<td>{_html_escape(r.description or '')}</td></tr>"
            )
        parts.append("</tbody></table>")

    # Coverage tables
    ecu_names = list(system.ecus.keys())

    def _coverage_table(title: str, ids: Iterable[int], fmt: str, pred) -> None:
        lst = list(ids)
        if not lst:
            return
        parts.append(f"<h3>{title}</h3>")
        parts.append("<table><thead><tr><th>ID</th>" +
                     "".join(f"<th>{_html_escape(n)}</th>" for n in ecu_names) +
                     "</tr></thead><tbody>")
        for x in lst:
            row = f"<tr><td><code>{fmt.format(x)}</code></td>"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += ("<td class='tick'>&#x2713;</td>"
                        if spec and pred(spec, x)
                        else "<td class='miss'>&mdash;</td>")
            row += "</tr>"
            parts.append(row)
        parts.append("</tbody></table>")

    parts.append("<h2>Cross-ECU Coverage</h2>")
    _coverage_table("SID Coverage", _all_sids(system), "0x{:02X}", _has_sid)
    _coverage_table("DID Coverage", _all_dids(system), "0x{:04X}", _has_did)
    _coverage_table("RID Coverage", _all_rids(system), "0x{:04X}", _has_rid)

    nrcs = _all_nrcs(system)
    if nrcs:
        parts.append("<h3>NRC Coverage</h3>")
        parts.append("<table><thead><tr><th>NRC</th><th>Description</th>" +
                     "".join(f"<th>{_html_escape(n)}</th>" for n in ecu_names) +
                     "</tr></thead><tbody>")
        for code, name in nrcs.items():
            row = (f"<tr><td><code>0x{code:02X}</code></td>"
                   f"<td>{_html_escape(name)}</td>")
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += ("<td class='tick'>&#x2713;</td>"
                        if spec and _has_nrc(spec, code)
                        else "<td class='miss'>&mdash;</td>")
            row += "</tr>"
            parts.append(row)
        parts.append("</tbody></table>")

    if validate:
        result = validate_system(system)
        parts.append("<h2>Cross-ECU Validation</h2>")
        parts.append(f"<p><strong>Result:</strong> {_html_escape(result.summary())}</p>")
        if result.issues:
            parts.append("<table><thead><tr><th>Severity</th><th>Category</th>"
                         "<th>Item</th><th>Message</th></tr></thead><tbody>")
            for issue in result.issues:
                parts.append(
                    f"<tr><td class='severity-{issue.severity}'>{issue.severity}</td>"
                    f"<td>{_html_escape(issue.category)}</td>"
                    f"<td>{_html_escape(issue.item_id or '—')}</td>"
                    f"<td>{_html_escape(issue.message)}</td></tr>"
                )
            parts.append("</tbody></table>")
        else:
            parts.append("<p>&#x2713; No cross-ECU consistency issues detected.</p>")

    parts.append("</body></html>")
    return "\n".join(parts)
