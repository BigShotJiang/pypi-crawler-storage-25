"""Command-line interface for udsxml2tex."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Optional

from udsxml2tex import __version__
from udsxml2tex.generator import TexGenerator
from udsxml2tex.parser import ArxmlParser


_EPILOG = """\
Usage modes:
  1) CLI mode (default):
       udsxml2tex input.arxml -o output.tex
     Directly specify ARXML files for batch conversion.

  2) Interactive mode:
       udsxml2tex -I
     Step-by-step guided generation where you select ARXML type,
     file paths, items to include, and more.

  3) Config file mode:
       udsxml2tex --config udsxml2tex_config.json
     Load a previously saved configuration file to generate the spec.
     Config files can be saved from interactive mode.

  4) Python library usage:
       from udsxml2tex import ArxmlParser, TexGenerator
       spec = ArxmlParser().parse("input.arxml")
       TexGenerator().generate(spec, "output.tex")
     Import and use directly from Python code.
"""


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="udsxml2tex",
        description="Convert AUTOSAR DCM/CanTp arxml to LaTeX UDS specification documents.",
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "input",
        nargs="*",
        help="Input ARXML file(s). Multiple files will be merged. "
             "Not required when using -I or --config.",
    )
    parser.add_argument(
        "-I",
        "--interactive",
        action="store_true",
        help="Launch interactive mode — step-by-step guided generation.",
    )
    parser.add_argument(
        "--config",
        default=None,
        metavar="FILE",
        help="Path to a JSON config file (saved from interactive mode).",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output .tex file path. Default: <input_stem>_uds_spec.tex",
    )
    parser.add_argument(
        "--ecu-name",
        default=None,
        help="Override ECU name in the generated document.",
    )
    parser.add_argument(
        "--template-dir",
        default=None,
        help="Directory containing custom Jinja2 LaTeX templates.",
    )
    parser.add_argument(
        "--template",
        default="uds_spec.tex.j2",
        help="Template file name (default: uds_spec.tex.j2).",
    )
    parser.add_argument(
        "--pdf",
        action="store_true",
        help="Compile the generated .tex to PDF (requires latexmk or pdflatex).",
    )
    parser.add_argument(
        "--html",
        action="store_true",
        help="Generate an HTML document in addition to (or instead of) LaTeX.",
    )
    parser.add_argument(
        "--dem",
        default=None,
        metavar="FILE",
        help="Path to a separate DEM ARXML file to merge DEM data from.",
    )
    parser.add_argument(
        "--c-source",
        action="append",
        metavar="PATH",
        default=[],
        help=(
            "C source file or directory to scan for DID global variables. "
            "Can be specified multiple times. "
            "When provided, DID data-element tables in the output will include "
            "the global variable names referenced by each DID read/write function."
        ),
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Parse ARXML and print a summary without generating any output files.",
    )
    parser.add_argument(
        "--format",
        default="tex",
        choices=["tex", "pdf", "html", "md", "rst", "csv", "yaml", "json", "docx"],
        metavar="FORMAT",
        help="Output format: tex (default), pdf, html, md, rst, csv, yaml, json, docx. "
             "`pdf` is currently honoured by --system mode (per-ECU spec.tex + "
             "system.tex are compiled to .pdf via latexmk/pdflatex). For "
             "single-ECU mode, use --pdf alongside --format tex/html.",
    )
    parser.add_argument(
        "--extra-vars",
        action="append",
        metavar="KEY=VALUE",
        default=[],
        help=(
            "Extra Jinja2 template variable (KEY=VALUE). "
            "Can be specified multiple times. Only applies to tex/html output."
        ),
    )
    parser.add_argument(
        "--lang",
        default="en",
        choices=["en", "ja"],
        help="Language for generated document labels (default: en).",
    )
    parser.add_argument(
        "--filter-dids",
        default=None,
        metavar="IDS",
        help="Comma-separated hex DID IDs to include (e.g. 0x1234,0x1235). "
             "Other DIDs are excluded from the output.",
    )
    parser.add_argument(
        "--filter-services",
        default=None,
        metavar="IDS",
        help="Comma-separated hex service IDs to include (e.g. 0x10,0x22).",
    )
    parser.add_argument(
        "--filter-dtcs",
        default=None,
        metavar="IDS",
        help="Comma-separated hex DTC IDs to include.",
    )
    parser.add_argument(
        "--diff",
        default=None,
        metavar="FILE",
        help="Compare parsed ARXML against FILE (ARXML or JSON) and print a diff report.",
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Run ISO 14229-1 consistency validation and print issues. "
             "Exits non-zero if errors are found.",
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Watch input files for changes and re-generate automatically. "
             "Requires the watchdog package (pip install udsxml2tex[watch]).",
    )
    parser.add_argument(
        "--serve",
        action="store_true",
        help="Start the local web server (browser mode). "
             "Requires pip install udsxml2tex[web].",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Port for --serve mode (default: 8765).",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host for --serve mode (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--generate-completion",
        choices=["bash", "zsh", "fish"],
        metavar="SHELL",
        help="Print a shell completion script and exit (bash, zsh, or fish).",
    )
    parser.add_argument(
        "--bootstrap-ollama",
        action="store_true",
        help="One-shot setup for the Chat tab's local LLM backend: download "
             "Ollama into ~/.local if missing, start `ollama serve`, pull a "
             "model, and print a ready-to-use llm.json snippet. Linux/macOS "
             "only. Customize with --bootstrap-model / --bootstrap-ctx / "
             "--bootstrap-ollama-port.",
    )
    parser.add_argument(
        "--bootstrap-model",
        metavar="MODEL",
        default=None,
        help="Model tag to pull during --bootstrap-ollama (default: qwen2.5:7b).",
    )
    parser.add_argument(
        "--bootstrap-ctx",
        type=int,
        metavar="N",
        default=None,
        help="num_ctx for the bootstrapped Ollama serve (default: 24576). "
             "Increase only if your spec JSON exceeds 24K tokens; decrease "
             "to fit on a smaller GPU.",
    )
    parser.add_argument(
        "--bootstrap-ollama-port",
        type=int,
        metavar="PORT",
        default=None,
        help="Port for the bootstrapped `ollama serve` (default: 11434).",
    )
    parser.add_argument(
        "--c-scan-depth",
        type=int,
        default=0,
        metavar="N",
        help="Transitive C-scan depth: follow function calls up to N levels deep "
             "(0 = direct body only, max 3).",
    )
    parser.add_argument(
        "--doip",
        default=None,
        metavar="FILE",
        help="Path to a DoIP ARXML file to extract ISO 13400 configuration from.",
    )
    parser.add_argument(
        "--comm",
        default=None,
        metavar="FILE",
        help="Path to a Communication ARXML file (I-SIGNAL, FRAME, PDU-TO-FRAME-MAPPING).",
    )
    parser.add_argument(
        "--validate-xsd",
        default=None,
        metavar="XSD",
        help="Validate input ARXML against XSD schema file before parsing.",
    )
    parser.add_argument(
        "--parallel",
        action="store_true",
        help="Parse multiple ARXML input files in parallel (ProcessPoolExecutor).",
    )
    parser.add_argument(
        "--progress",
        action="store_true",
        help="Display a tqdm progress bar during parse_multi() / parse_streaming() (requires `pip install udsxml2tex[progress]`).",
    )
    parser.add_argument(
        "--cache-dir",
        default=None,
        metavar="DIR",
        help="Directory to cache parsed specs by file hash for incremental parsing.",
    )
    parser.add_argument(
        "--json-schema",
        action="store_true",
        help="Print the JSON Schema for UdsSpecification to stdout and exit.",
    )
    parser.add_argument(
        "--byte-diagrams",
        default=None,
        metavar="DIR",
        help="Generate bytefield DID byte-layout .tex files into DIR.",
    )
    parser.add_argument(
        "--sequence-diagrams",
        default=None,
        metavar="DIR",
        help="Generate TikZ UML sequence diagram .tex files into DIR.",
    )
    parser.add_argument(
        "--visualizations",
        default=None,
        metavar="DIR",
        help=(
            "Generate heatmaps (session×service, security×DID) and timing "
            "diagrams into DIR. Outputs both standalone TikZ .tex and PNG "
            "(when matplotlib is installed; install via "
            "`pip install udsxml2tex[viz]`)."
        ),
    )
    parser.add_argument(
        "--viz-format",
        default="both",
        choices=["tikz", "png", "both"],
        help="Output format for --visualizations (default: both).",
    )
    parser.add_argument(
        "--llm-summarize",
        default=None,
        nargs="?",
        const="1page",
        choices=["short", "1page", "2page", "long"],
        help=(
            "Generate an LLM-authored Markdown executive summary of the spec "
            "and write it to --llm-output (default: spec_summary.md). "
            "Requires `pip install udsxml2tex[llm]` and ANTHROPIC_API_KEY."
        ),
    )
    parser.add_argument(
        "--llm-query",
        default=None,
        metavar="QUESTION",
        help=(
            "Ask the LLM a natural-language question about the spec "
            "(e.g. 'Which DIDs require security level 2?')."
        ),
    )
    parser.add_argument(
        "--llm-translate",
        default=None,
        metavar="LANG",
        choices=["en", "ja", "de"],
        help=(
            "Translate the LLM summary or query result into LANG "
            "(en|ja|de) before writing/printing."
        ),
    )
    parser.add_argument(
        "--llm-nrc-descriptions",
        action="store_true",
        help=(
            "Generate ECU-specific NRC descriptions via the LLM and print "
            "them as JSON to stdout (or --llm-output)."
        ),
    )
    parser.add_argument(
        "--llm-model",
        default=None,
        help=(
            "Model identifier for LLM features. For Anthropic: sonnet|opus|"
            "haiku alias or full model ID. For OpenAI-compatible: pass the "
            "server's model name (e.g. 'llama3.1:8b' for Ollama). "
            "Defaults to 'sonnet' for Anthropic."
        ),
    )
    parser.add_argument(
        "--llm-provider",
        default=None,
        choices=["anthropic", "openai"],
        help=(
            "LLM backend. 'anthropic' = Claude API (cloud, requires "
            "ANTHROPIC_API_KEY). 'openai' = OpenAI-compatible HTTP API "
            "(works with Ollama, llama.cpp, vLLM, LM Studio, OpenRouter, "
            "Azure OpenAI, real OpenAI). Default: from "
            "$UDSXML2TEX_LLM_PROVIDER, ~/.udsxml2tex/llm.json, or 'anthropic'."
        ),
    )
    parser.add_argument(
        "--llm-base-url",
        default=None,
        metavar="URL",
        help=(
            "Endpoint URL for --llm-provider=openai. Aliases: 'ollama' "
            "(http://localhost:11434/v1), 'llamacpp' (8080), 'lmstudio' "
            "(1234), 'vllm' (8000), 'openrouter', 'openai'. Defaults to "
            "Ollama on localhost."
        ),
    )
    parser.add_argument(
        "--llm-api-key",
        default=None,
        metavar="KEY",
        help=(
            "Override the API key. For Anthropic, beats ANTHROPIC_API_KEY. "
            "For OpenAI-compatible, beats OPENAI_API_KEY. Local servers "
            "(Ollama etc.) usually need any non-empty placeholder."
        ),
    )
    parser.add_argument(
        "--llm-config",
        default=None,
        metavar="FILE",
        help=(
            "Load LLM provider config from a JSON or TOML file. Schema: "
            "{provider, model, base_url, api_key, structured_mode, "
            "timeout}. Per-flag overrides above take precedence. "
            "Without this flag, ~/.udsxml2tex/llm.json (or .toml) is "
            "consulted automatically."
        ),
    )
    parser.add_argument(
        "--llm-structured-mode",
        default=None,
        choices=["auto", "json_schema", "json_object", "prompt"],
        help=(
            "Structured-output strategy for --llm-nrc-descriptions. 'auto' "
            "picks per-provider sensible default (json_schema for "
            "Anthropic, json_object for OpenAI-compatible)."
        ),
    )
    parser.add_argument(
        "--llm-output",
        default=None,
        metavar="FILE",
        help="Output file for --llm-summarize / --llm-query / --llm-nrc-descriptions.",
    )
    parser.add_argument(
        "--iso-version",
        default=None,
        choices=["2006", "2013", "2020"],
        help=(
            "Filter the parsed spec by ISO 14229-1 version. Drops services, "
            "NRCs, and ReadDTCInformation sub-functions that are not defined "
            "in the chosen revision."
        ),
    )
    parser.add_argument(
        "--iso-version-mode",
        default="warn",
        choices=["warn", "strict"],
        help=(
            "How to handle items not in the chosen ISO version: 'warn' (log "
            "only) or 'strict' (drop from spec). Default: warn."
        ),
    )
    parser.add_argument(
        "--autosar-compat-report",
        default=None,
        nargs="?",
        const="-",
        metavar="FILE",
        help=(
            "Generate an AUTOSAR version compatibility report (Markdown). "
            "Pass a path to write to file, or omit the path to print to stdout."
        ),
    )
    parser.add_argument(
        "--system",
        default=None,
        metavar="CONFIG",
        help=(
            "Path to a multi-ECU system config (.yaml/.yml/.json). When set, "
            "each ECU declared in the config is parsed independently and a "
            "system integration document is generated alongside per-ECU "
            "specs. Mutually exclusive with positional ARXML inputs."
        ),
    )
    parser.add_argument(
        "--no-routing-inference",
        action="store_true",
        help=(
            "Disable ARXML-based routing inference for --system mode. "
            "Only explicit routing rules from the config are used."
        ),
    )
    parser.add_argument(
        "--system-output-dir",
        default=None,
        metavar="DIR",
        help=(
            "Output directory for --system mode. The system integration "
            "document is written to <DIR>/system.<ext>; per-ECU outputs to "
            "<DIR>/<ecu_name>/spec.<ext>. Defaults to './uds-spec/'."
        ),
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging output.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the CLI.

    Args:
        argv: Command-line arguments. Defaults to sys.argv[1:].

    Returns:
        Exit code (0 for success).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
    )

    # --- JSON Schema output ---------------------------------------------
    if getattr(args, "json_schema", False):
        from udsxml2tex.schema import generate_json_schema
        import json as _json
        print(_json.dumps(generate_json_schema(), indent=2))
        return 0

    # --- Shell completion -----------------------------------------------
    if args.generate_completion:
        from udsxml2tex.completion import print_completion
        print_completion(args.generate_completion)
        return 0

    # --- Ollama bootstrap (Chat tab one-shot setup) ---------------------
    if getattr(args, "bootstrap_ollama", False):
        from udsxml2tex.ollama_setup import run_from_cli
        return run_from_cli(
            model=args.bootstrap_model,
            ctx=args.bootstrap_ctx,
            host="127.0.0.1",
            port=args.bootstrap_ollama_port,
        )

    # --- Web server (browser mode) --------------------------------------
    if args.serve:
        try:
            from udsxml2tex.webserver import start_server
        except ImportError:
            logging.error(
                "Web server dependencies not installed. "
                "Run: pip install udsxml2tex[web]"
            )
            return 1
        start_server(host=args.host, port=args.port, open_browser=True)
        return 0

    # --- Interactive mode -----------------------------------------------
    if args.interactive:
        from udsxml2tex.interactive import InteractiveSession

        return InteractiveSession().run()

    # --- Config-file mode -----------------------------------------------
    if args.config:
        from udsxml2tex.config import GenerationConfig
        from udsxml2tex.interactive import generate_from_config

        try:
            config = GenerationConfig.load(args.config)
        except Exception as e:
            logging.error("Failed to load config: %s", e)
            return 1
        # Allow CLI overrides on top of config
        if args.output:
            config.output_path = args.output
        if args.ecu_name:
            config.ecu_name = args.ecu_name
        if args.template_dir:
            config.template_dir = args.template_dir
        if args.template != "uds_spec.tex.j2":
            config.template = args.template
        return generate_from_config(config)

    # --- Multi-ECU system mode (mutually exclusive with positional inputs)
    if getattr(args, "system", None):
        if args.input:
            logging.error(
                "--system is mutually exclusive with positional ARXML inputs."
            )
            return 1
        return _run_multi_ecu_system(args)

    # --- Direct CLI mode ------------------------------------------------
    if not args.input:
        parser.print_help()
        return 1

    # Validate input files
    input_paths = [Path(p) for p in args.input]
    for p in input_paths:
        if not p.exists():
            logging.error("Input file not found: %s", p)
            return 1
        if not p.suffix.lower() == ".arxml":
            logging.warning(
                "File does not have .arxml extension: %s", p
            )

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        stem = input_paths[0].stem
        suffix = ".html" if args.html and not args.pdf else ".tex"
        output_path = input_paths[0].parent / f"{stem}_uds_spec{suffix}"

    # XSD validation (before parsing)
    if getattr(args, "validate_xsd", None):
        xsd_path = Path(args.validate_xsd)
        if not xsd_path.exists():
            logging.error("XSD file not found: %s", xsd_path)
            return 1
        errs = ArxmlParser().validate_against_xsd(input_paths[0], xsd_path)
        if errs:
            for e in errs:
                logging.error("XSD: %s", e)
            return 1
        logging.info("XSD validation passed.")

    # Parse ARXML
    arxml_parser = ArxmlParser()
    _parallel = getattr(args, "parallel", False)
    _cache_dir = getattr(args, "cache_dir", None)
    _progress = getattr(args, "progress", False)
    try:
        if len(input_paths) == 1:
            spec = arxml_parser.parse(input_paths[0], cache_dir=_cache_dir)
        else:
            spec = arxml_parser.parse_multi(
                input_paths, parallel=_parallel, show_progress=_progress
            )
    except Exception as e:
        logging.error("Failed to parse ARXML: %s", e)
        return 1

    # Report validation warnings
    if arxml_parser.warnings:
        for w in arxml_parser.warnings:
            logging.warning("[%s] %s", w.section, w.message)

    # Merge separate DEM arxml if provided
    if args.dem:
        from udsxml2tex.dem_parser import DemParser

        dem_path = Path(args.dem)
        if not dem_path.exists():
            logging.error("DEM ARXML file not found: %s", dem_path)
            return 1
        try:
            DemParser().parse(dem_path, spec)
        except Exception as e:
            logging.error("Failed to parse DEM ARXML: %s", e)
            return 1

    # Override ECU name if specified
    if args.ecu_name:
        spec.ecu_name = args.ecu_name

    # Parse DoIP ARXML if provided
    if getattr(args, "doip", None):
        from udsxml2tex.doip_parser import DoIpParser
        from lxml import etree as _etree
        doip_path = Path(args.doip)
        if not doip_path.exists():
            logging.error("DoIP ARXML file not found: %s", doip_path)
            return 1
        try:
            _doip_root = _etree.parse(str(doip_path)).getroot()
            spec.doip_config = DoIpParser().parse(_doip_root)
        except Exception as e:
            logging.warning("DoIP ARXML parsing failed: %s", e)

    # Parse Communication ARXML if provided
    if getattr(args, "comm", None):
        from udsxml2tex.comm_arxml_parser import CommArxmlParser
        from lxml import etree as _etree
        comm_path = Path(args.comm)
        if not comm_path.exists():
            logging.error("Comm ARXML file not found: %s", comm_path)
            return 1
        try:
            _comm_root = _etree.parse(str(comm_path)).getroot()
            spec.comm_config = CommArxmlParser().parse(_comm_root)
        except Exception as e:
            logging.warning("Communication ARXML parsing failed: %s", e)

    # Scan C source files for DID global variables
    if args.c_source:
        from udsxml2tex.c_scanner import scan_did_variables

        c_paths = [Path(p) for p in args.c_source]
        try:
            scan_did_variables(
                c_paths,
                spec.dids,
                transitive_depth=getattr(args, "c_scan_depth", 0),
            )
        except Exception as e:
            logging.warning("C source scanning failed: %s", e)

    # --- Apply filters --------------------------------------------------
    _apply_filters(spec, args)

    # --- ISO 14229-1 version filtering ----------------------------------
    if getattr(args, "iso_version", None):
        from udsxml2tex.iso_versions import filter_spec_by_iso_version
        notes = filter_spec_by_iso_version(
            spec, args.iso_version,
            mode=getattr(args, "iso_version_mode", "warn"),
        )
        for note in notes:
            logging.warning("[ISO 14229-1:%s] %s", args.iso_version, note)

    # --- AUTOSAR compatibility report -----------------------------------
    if getattr(args, "autosar_compat_report", None) is not None:
        from udsxml2tex.autosar_compat import autosar_compat_report
        report = autosar_compat_report(spec, parser=arxml_parser)
        target = args.autosar_compat_report
        if target == "-":
            print(report.to_markdown())
        else:
            Path(target).write_text(report.to_markdown(), encoding="utf-8")
            logging.info("AUTOSAR compatibility report written to: %s", target)

    # --- Validation mode ------------------------------------------------
    if args.validate:
        return _run_validate(spec)

    # --- Diff mode ------------------------------------------------------
    if args.diff:
        return _run_diff(spec, args.diff)

    # --- Dry-run mode: print summary and exit ---------------------------
    if args.dry_run:
        return _print_dry_run_summary(spec, arxml_parser)

    # --- LLM features (summarize / query / NRC descriptions) ------------
    if (args.llm_summarize is not None
            or args.llm_query is not None
            or args.llm_nrc_descriptions):
        return _run_llm(spec, args)

    # --- Parse extra_vars -----------------------------------------------
    extra_vars: dict = {}
    for kv in getattr(args, "extra_vars", []):
        if "=" in kv:
            k, _, v = kv.partition("=")
            extra_vars[k.strip()] = v.strip()
        else:
            logging.warning("Ignoring malformed --extra-vars entry: %r", kv)

    # Add i18n translator to extra_vars when lang is specified
    if getattr(args, "lang", "en") != "en" or extra_vars:
        from udsxml2tex.i18n import Translator
        extra_vars.setdefault("_t", Translator(getattr(args, "lang", "en")).t)

    # --- Generate output ------------------------------------------------
    fmt = getattr(args, "format", "tex")
    # Legacy --html flag maps to html format
    if getattr(args, "html", False) and fmt == "tex" and not getattr(args, "pdf", False):
        fmt = "html"

    try:
        tex_gen = TexGenerator(template_dir=args.template_dir)

        if fmt == "tex":
            tex_output = output_path.with_suffix(".tex")
            result = tex_gen.generate(spec, tex_output, template_name=args.template,
                                      extra_vars=extra_vars or None)
            logging.info("LaTeX output written to: %s", result)
            if getattr(args, "pdf", False):
                pdf_path = tex_gen.compile_pdf(result)
                logging.info("PDF output written to: %s", pdf_path)

        elif fmt == "html":
            html_output = output_path.with_suffix(".html")
            tex_gen.generate_html(spec, html_output)
            logging.info("HTML output written to: %s", html_output)

        elif fmt == "md":
            out = output_path.with_suffix(".md")
            tex_gen.generate_markdown(spec, out)
            logging.info("Markdown output written to: %s", out)

        elif fmt == "rst":
            out = output_path.with_suffix(".rst")
            tex_gen.generate_rst(spec, out)
            logging.info("RST output written to: %s", out)

        elif fmt == "csv":
            csv_dir = output_path.parent / (output_path.stem + "_csv")
            files = tex_gen.generate_csv(spec, csv_dir)
            logging.info("CSV output written to: %s (%d file(s))", csv_dir, len(files))

        elif fmt == "yaml":
            out = output_path.with_suffix(".yaml")
            tex_gen.generate_yaml(spec, out)
            logging.info("YAML output written to: %s", out)

        elif fmt == "json":
            out = output_path.with_suffix(".json")
            tex_gen.generate_json(spec, out)
            logging.info("JSON output written to: %s", out)

        elif fmt == "docx":
            out = output_path.with_suffix(".docx")
            tex_gen.generate_docx(spec, out)
            logging.info("DOCX output written to: %s", out)

        # Byte-level DID diagrams
        if getattr(args, "byte_diagrams", None):
            bd_dir = Path(args.byte_diagrams)
            bd_dir.mkdir(parents=True, exist_ok=True)
            bd_path = tex_gen.generate_byte_diagrams(spec, bd_dir)
            logging.info("Byte diagrams written to: %s", bd_path)

        # UML sequence diagrams
        if getattr(args, "sequence_diagrams", None):
            sd_dir = Path(args.sequence_diagrams)
            sd_dir.mkdir(parents=True, exist_ok=True)
            sd_paths = tex_gen.generate_sequence_diagrams(spec, sd_dir)
            logging.info("Sequence diagrams written to: %s (%d file(s))", sd_dir, len(sd_paths))

        # Heatmaps + timing diagrams
        if getattr(args, "visualizations", None):
            from udsxml2tex.visualizations import generate_all_visualizations
            viz_dir = Path(args.visualizations)
            viz_dir.mkdir(parents=True, exist_ok=True)
            viz_fmt = getattr(args, "viz_format", "both") or "both"
            viz_paths = generate_all_visualizations(spec, viz_dir, format=viz_fmt)
            logging.info("Visualizations written to: %s (%d file(s))",
                         viz_dir, len(viz_paths))

        # Also generate HTML when --html is set alongside --pdf
        if getattr(args, "html", False) and getattr(args, "pdf", False):
            html_output = output_path.with_suffix(".html")
            tex_gen.generate_html(spec, html_output)
            logging.info("HTML output written to: %s", html_output)

    except FileNotFoundError as e:
        logging.error("%s", e)
        return 1
    except Exception as e:
        logging.error("Failed to generate output: %s", e)
        return 1

    # --- Watch mode (must be last) --------------------------------------
    if getattr(args, "watch", False):
        return _run_watch(args, argv)

    return 0


def _print_dry_run_summary(spec, arxml_parser) -> int:
    """Print a summary of the parsed ARXML data (rich-formatted when available)."""
    from udsxml2tex._rich_output import print_dry_run, use_rich

    if use_rich():
        print_dry_run(spec, arxml_parser.warnings)
        return 0

    from udsxml2tex.models import UDS_SERVICE_NAMES

    print(f"\n{'=' * 60}")
    print(f"  udsxml2tex -- Dry Run Summary")
    print(f"{'=' * 60}")
    print(f"  ECU Name:          {spec.ecu_name}")
    print(f"  Protocol:          {spec.protocol_name}")
    if spec.protocol_type:
        print(f"  Protocol Type:     {spec.protocol_type}")
    print(f"  S3 Server Timeout: {spec.s3_server} s")
    print()

    print(f"  Sessions:          {len(spec.sessions)}")
    for s in sorted(spec.sessions, key=lambda x: x.session_id):
        print(f"    0x{s.session_id:02X} - {s.short_name} "
              f"(P2={s.p2_server_max}s, P2*={s.p2_star_server_max}s)")

    print(f"  Security Levels:   {len(spec.security_levels)}")
    for s in sorted(spec.security_levels, key=lambda x: x.security_level):
        print(f"    Level {s.security_level} - {s.short_name} "
              f"(seed={s.seed_size}B, key={s.key_size}B)")

    print(f"  Services:          {len(spec.services)}")
    for s in sorted(spec.services, key=lambda x: x.service_id):
        name = UDS_SERVICE_NAMES.get(s.service_id, s.short_name)
        sf_count = len(s.sub_functions)
        nrc_count = len(s.nrc_list)
        print(f"    0x{s.service_id:02X} - {name} "
              f"({sf_count} sub-functions, {nrc_count} NRCs)")

    print(f"  DIDs:              {len(spec.dids)}")
    print(f"  Routines:          {len(spec.routines)}")
    print(f"  DTCs:              {len(spec.dtcs)}")
    print(f"  Memory Ranges:     {len(spec.memory_ranges)}")
    print(f"  IO Control DIDs:   {len(spec.io_control_dids)}")
    print(f"  Periodic DIDs:     {len(spec.periodic_dids)}")
    print(f"  DID Ranges:        {len(spec.did_ranges)}")
    print(f"  Dynamic DIDs:      {len(spec.dynamic_dids)}")

    if spec.transport_config:
        print(f"  CanTp Channels:    {len(spec.transport_config.channels)}")
        print(f"  CAN-FD:            {'Yes' if spec.transport_config.can_fd_enabled else 'No'}")

    if arxml_parser.warnings:
        print(f"\n  Warnings:          {len(arxml_parser.warnings)}")
        for w in arxml_parser.warnings:
            print(f"    [{w.section}] {w.message}")

    print(f"\n{'=' * 60}")
    return 0


def _apply_filters(spec, args) -> None:
    """Apply --filter-dids / --filter-services / --filter-dtcs to spec in-place."""
    def _parse_ids(s: Optional[str]) -> Optional[set[int]]:
        if not s:
            return None
        ids: set[int] = set()
        for tok in s.split(","):
            tok = tok.strip()
            if tok:
                try:
                    ids.add(int(tok, 0))
                except ValueError:
                    logging.warning("Ignoring invalid ID in filter: %r", tok)
        return ids if ids else None

    did_ids = _parse_ids(getattr(args, "filter_dids", None))
    svc_ids = _parse_ids(getattr(args, "filter_services", None))
    dtc_ids = _parse_ids(getattr(args, "filter_dtcs", None))

    if did_ids is not None:
        spec.dids = [d for d in spec.dids if d.did_id in did_ids]
    if svc_ids is not None:
        spec.services = [s for s in spec.services if s.service_id in svc_ids]
    if dtc_ids is not None:
        spec.dtcs = [d for d in spec.dtcs if d.dtc_id in dtc_ids]


def _run_multi_ecu_system(args) -> int:
    """Handle --system mode: parse a system YAML/JSON, generate per-ECU specs +
    a system integration document.

    Output layout under --system-output-dir (default ./uds-spec/):
        <DIR>/<ecu_name>/spec.<ext>          # one per ECU
        <DIR>/system.<ext>                   # integration document
        <DIR>/system_topology.tex            # standalone TikZ topology figure

    The output format is taken from --format (default tex). LaTeX, HTML, and
    Markdown are fully supported; other formats fall back to per-ECU output
    only and a Markdown system document.
    """
    try:
        from udsxml2tex.multi_ecu import (
            generate_system_html,
            generate_system_latex,
            generate_system_markdown,
            generate_topology_tikz,
            load_system_config,
        )
    except ImportError as e:
        logging.error("multi_ecu module not available: %s", e)
        return 1

    cfg_path = Path(args.system)
    out_dir = Path(args.system_output_dir or "uds-spec")
    out_dir.mkdir(parents=True, exist_ok=True)
    fmt = (args.format or "tex").lower()

    # Load + parse + infer
    try:
        system = load_system_config(
            cfg_path,
            parse_arxml=True,
            infer_routing=not args.no_routing_inference,
        )
    except Exception as e:  # noqa: BLE001
        logging.error("Failed to load system config %s: %s", cfg_path, e)
        return 1

    logging.info(
        "Loaded system %r with %d ECU(s); %d routing rule(s) "
        "(%d explicit, %d inferred)",
        system.name, len(system.ecus), len(system.routing_rules),
        sum(1 for r in system.routing_rules if not r.inferred),
        sum(1 for r in system.routing_rules if r.inferred),
    )

    # Per-ECU outputs via the existing TexGenerator
    tex_gen = TexGenerator()
    per_ecu_ext = {
        "tex": ".tex", "pdf": ".tex", "html": ".zip", "md": ".md",
        "rst": ".rst", "yaml": ".yaml", "json": ".json", "docx": ".docx",
    }.get(fmt, ".tex")

    for name, ecu in system.ecus.items():
        if not ecu.spec:
            continue
        ecu_dir = out_dir / name
        ecu_dir.mkdir(parents=True, exist_ok=True)
        spec_out = ecu_dir / f"spec{per_ecu_ext}"
        try:
            if fmt in ("tex", "pdf"):
                # `pdf` writes spec.tex first, then compiles below.
                tex_gen.generate(ecu.spec, spec_out)
            elif fmt == "html":
                tex_gen.generate_html_zip(ecu.spec, spec_out)
            elif fmt == "md":
                tex_gen.generate_markdown(ecu.spec, spec_out)
            elif fmt == "rst":
                tex_gen.generate_rst(ecu.spec, spec_out)
            elif fmt == "yaml":
                tex_gen.generate_yaml(ecu.spec, spec_out)
            elif fmt == "json":
                tex_gen.generate_json(ecu.spec, spec_out)
            elif fmt == "docx":
                tex_gen.generate_docx(ecu.spec, spec_out)
            elif fmt == "csv":
                csv_dir = ecu_dir / "spec_csv"
                tex_gen.generate_csv(ecu.spec, csv_dir)
            else:
                logging.warning("Unsupported per-ECU format %r; skipping %s",
                                fmt, name)
                continue
            logging.info("ECU %r: wrote %s", name, spec_out)
            if fmt == "pdf":
                pdf_path = tex_gen.compile_pdf(spec_out)
                logging.info("ECU %r: PDF written to: %s", name, pdf_path)
        except Exception as e:  # noqa: BLE001
            logging.error("ECU %r generation failed: %s", name, e)
            return 1

    # System integration document
    try:
        if fmt in ("tex", "pdf"):
            sys_text = generate_system_latex(system)
            sys_path = out_dir / "system.tex"
        elif fmt == "html":
            sys_text = generate_system_html(system)
            sys_path = out_dir / "system.html"
        else:
            sys_text = generate_system_markdown(system)
            sys_path = out_dir / "system.md"
        sys_path.write_text(sys_text, encoding="utf-8")
        logging.info("System integration document written to: %s", sys_path)

        # Always emit the standalone topology figure
        topo_tikz = generate_topology_tikz(system)
        topo_path = out_dir / "system_topology.tex"
        topo_path.write_text(topo_tikz, encoding="utf-8")
        logging.info("System topology figure written to: %s", topo_path)

        if fmt == "pdf":
            # The integration LaTeX needs udsspec.cls / tikz-uml.sty next to it.
            for asset in ("udsspec.cls", "tikz-uml.sty"):
                src = Path(__file__).parent / "templates" / asset
                if src.exists():
                    (out_dir / asset).write_bytes(src.read_bytes())
            sys_pdf = tex_gen.compile_pdf(sys_path)
            logging.info("System integration PDF: %s", sys_pdf)
    except Exception as e:  # noqa: BLE001
        logging.error("System integration document generation failed: %s", e)
        return 1

    return 0


def _build_llm_config_from_args(args):  # type: ignore[no-untyped-def]
    """Layer CLI flags on top of $UDSXML2TEX_LLM_* / config file / defaults."""
    from udsxml2tex.llm_integration import LLMConfig

    # Start from --llm-config when given, otherwise auto-resolve.
    if getattr(args, "llm_config", None):
        cfg = LLMConfig.from_file(args.llm_config)
    else:
        cfg = LLMConfig.auto()

    # Per-flag overrides — only when explicitly set.
    if getattr(args, "llm_provider", None):
        cfg.provider = args.llm_provider
    if getattr(args, "llm_model", None):
        cfg.model = args.llm_model
    if getattr(args, "llm_base_url", None):
        cfg.base_url = args.llm_base_url
    if getattr(args, "llm_api_key", None):
        cfg.api_key = args.llm_api_key
    if getattr(args, "llm_structured_mode", None):
        cfg.structured_mode = args.llm_structured_mode
    return cfg


def _run_llm(spec, args) -> int:
    """Dispatch --llm-summarize / --llm-query / --llm-nrc-descriptions."""
    try:
        from udsxml2tex import llm_integration as llm
    except ImportError as e:
        logging.error("%s", e)
        return 1

    target_lang = getattr(args, "llm_translate", None)
    out_path = getattr(args, "llm_output", None)
    cfg = _build_llm_config_from_args(args)
    logging.info(
        "LLM provider: %s, model: %s%s",
        cfg.provider, cfg.resolved_model() or cfg.model,
        f", base_url: {cfg.resolved_base_url()}" if cfg.provider == "openai" else "",
    )

    try:
        if args.llm_nrc_descriptions:
            descriptions = llm.complete_nrc_descriptions(spec, config=cfg)
            text = json.dumps(
                {f"0x{k:02X}": v for k, v in sorted(descriptions.items())},
                indent=2, ensure_ascii=False,
            )
        elif args.llm_query is not None:
            text = llm.query_spec(spec, args.llm_query, config=cfg)
            if target_lang:
                text = llm.translate_text(text, target_lang, config=cfg)
        else:
            length = args.llm_summarize or "1page"
            text = llm.summarize_spec(spec, length=length, config=cfg)
            if target_lang:
                text = llm.translate_text(text, target_lang, config=cfg)
    except Exception as e:  # noqa: BLE001
        logging.error("LLM call failed: %s", e)
        return 1

    if out_path:
        Path(out_path).write_text(text, encoding="utf-8")
        logging.info("LLM output written to: %s", out_path)
    else:
        print(text)
    return 0


def _run_validate(spec) -> int:
    """Run ISO 14229-1 validation and print results. Returns 1 if errors found."""
    try:
        from udsxml2tex.validator import UdsValidator
    except ImportError:
        logging.error("validator module not available.")
        return 1

    result = UdsValidator().validate(spec)
    from udsxml2tex._rich_output import print_validation
    print_validation(result)
    return 1 if result.has_errors() else 0


def _run_diff(spec_a, diff_target: str) -> int:
    """Compare spec_a against diff_target (ARXML or JSON) and print diff."""
    try:
        from udsxml2tex.diff import SpecDiffer
    except ImportError:
        logging.error("diff module not available.")
        return 1

    target_path = Path(diff_target)
    if not target_path.exists():
        logging.error("Diff target not found: %s", target_path)
        return 1

    try:
        if target_path.suffix.lower() == ".json":
            from udsxml2tex.models import UdsSpecification
            spec_b = UdsSpecification.load_json(target_path)
        else:
            spec_b = ArxmlParser().parse(target_path)
    except Exception as e:
        logging.error("Failed to load diff target: %s", e)
        return 1

    diff = SpecDiffer().diff(spec_a, spec_b)
    from udsxml2tex._rich_output import print_diff_markdown
    print_diff_markdown(diff.to_markdown())
    return 0


def _run_watch(args, argv: Optional[list[str]]) -> int:
    """Watch input files and re-run generation on changes."""
    try:
        from watchdog.observers import Observer  # type: ignore[import]
        from watchdog.events import FileSystemEventHandler  # type: ignore[import]
    except ImportError:
        logging.error(
            "watchdog is required for --watch mode. "
            "Install it with: pip install udsxml2tex[watch]"
        )
        return 1

    import time

    watch_paths = list(args.input)
    if getattr(args, "dem", None):
        watch_paths.append(args.dem)

    logging.info("Watching %d file(s) for changes. Press Ctrl+C to stop.", len(watch_paths))

    class _Handler(FileSystemEventHandler):
        def on_modified(self, event):  # type: ignore[override]
            if event.src_path in watch_paths:
                logging.info("Change detected: %s — regenerating…", event.src_path)
                # Re-run without --watch to avoid recursion
                filtered = [a for a in (argv or sys.argv[1:]) if a != "--watch"]
                main(filtered)

    observer = Observer()
    watched_dirs: set[str] = set()
    for p in watch_paths:
        d = str(Path(p).parent.resolve())
        if d not in watched_dirs:
            observer.schedule(_Handler(), d, recursive=False)
            watched_dirs.add(d)

    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
    return 0


if __name__ == "__main__":
    sys.exit(main())
