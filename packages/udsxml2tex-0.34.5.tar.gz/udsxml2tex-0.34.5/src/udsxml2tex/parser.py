"""ARXML parser for AUTOSAR DCM/CanTp module configuration."""

from __future__ import annotations

import hashlib
import json
import logging
import os
import pickle
import re
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from itertools import islice
from pathlib import Path
from typing import Optional

from lxml import etree

from udsxml2tex.models import (
    STANDARD_NRCS,
    UDS_SERVICE_NAMES,
    AccessTimingRow,
    AuthenticationConfig,
    ClearDtcNotification,
    ComControlConfig,
    ComControlSubNode,
    DataElement,
    DemDebounceConfig,
    DemEnableCondition,
    DemEventMemoryConfig,
    DemEventParameter,
    DemGeneralConfig,
    DemIndicatorConfig,
    DemOperationCycle,
    DemStorageCondition,
    DiagSession,
    Did,
    DidRange,
    DslConnection,
    DtcDefinition,
    DtcExtendedDataRecord,
    DtcGroup,
    DtcSnapshotRecord,
    DynamicDidDefinition,
    IoControlDid,
    LinkControlBaudrateEntry,
    MemoryRange,
    NrcEntry,
    PeriodicDid,
    ProtocolRow,
    RequestFileTransferConfig,
    ResponseOnEventConfig,
    Routine,
    RoutineParameter,
    STANDARD_ADDRESSING_MODES,
    STANDARD_SUB_FUNCTIONS,
    SecurityLevel,
    SubFunction,
    UdsService,
    UdsSpecification,
)

logger = logging.getLogger(__name__)


class _NullProgress:
    """No-op progress bar used when tqdm is unavailable or disabled."""

    def update(self, n: int = 1) -> None:  # noqa: D401
        return None

    def close(self) -> None:
        return None

    def __iter__(self):
        return iter(())


def _make_progress(iterable, desc: str, enabled: bool):
    """Return a tqdm progress bar when enabled and tqdm is installed.

    Falls back to a silent no-op bar otherwise so callers can use
    `progress.update(1)` / `progress.close()` unconditionally.
    """
    if not enabled:
        return _NullProgress()
    try:
        from tqdm import tqdm  # type: ignore[import-not-found]
    except ImportError:
        return _NullProgress()
    try:
        total = len(iterable)  # type: ignore[arg-type]
    except TypeError:
        total = None
    return tqdm(total=total, desc=desc, unit="file", leave=False)


# Common AUTOSAR namespaces
AR_NAMESPACES = {
    "ar": "http://autosar.org/schema/r4.0",
    "ar3": "http://autosar.org/3.0.2",
    "xsi": "http://www.w3.org/2001/XMLSchema-instance",
}

# AUTOSAR namespace map covering R3.x and R4.x releases
AUTOSAR_NAMESPACES: dict[str, str] = {
    # R4.x
    "http://autosar.org/schema/r4.0":   "R4.0",
    "http://autosar.org/schema/r4.0.1": "R4.0",
    "http://autosar.org/schema/r4.0.2": "R4.0",
    "http://autosar.org/schema/r4.0.3": "R4.0",
    "http://autosar.org/schema/r4.1":   "R4.1",
    "http://autosar.org/schema/r4.2":   "R4.2",
    "http://autosar.org/schema/r4.2.1": "R4.2",
    "http://autosar.org/schema/r4.2.2": "R4.2",
    "http://autosar.org/schema/r4.3":   "R4.3",
    # R3.x
    "http://autosar.org/schema/r3.0":  "R3.0",
    "http://autosar.org/schema/r3.1":  "R3.1",
    "http://autosar.org/schema/r3.2":  "R3.2",
}


class ArxmlValidationError(Exception):
    """Raised when ARXML validation fails and cannot be recovered."""


class ArxmlValidationWarning:
    """Container for a recoverable ARXML validation issue."""

    def __init__(self, section: str, message: str) -> None:
        self.section = section
        self.message = message

    def __repr__(self) -> str:
        return f"ArxmlValidationWarning({self.section!r}, {self.message!r})"


def _detect_namespace(root: etree._Element) -> dict[str, str]:
    """Detect the AUTOSAR namespace from the root element."""
    ns = root.nsmap
    # Try to find the AUTOSAR namespace
    for prefix, uri in ns.items():
        if "autosar.org" in uri:
            return {"ar": uri}
    # Check if there's a default namespace
    if None in ns and "autosar.org" in ns[None]:
        return {"ar": ns[None]}
    # Fallback: try without namespace
    return {}


def _detect_arxml_version(root: etree._Element) -> str:
    """Detect AUTOSAR schema version from root element namespace."""
    # Try nsmap first (lxml feature)
    if hasattr(root, 'nsmap'):
        for uri in root.nsmap.values():
            if uri in AUTOSAR_NAMESPACES:
                return AUTOSAR_NAMESPACES[uri]
    # Fallback: extract from tag
    if root.tag and root.tag.startswith("{"):
        uri = root.tag[1:root.tag.index("}")]
        return AUTOSAR_NAMESPACES.get(uri, "unknown")
    return "no-namespace"


def _xpath(element: etree._Element, path: str, ns: dict[str, str]) -> list:
    """Execute XPath query with namespace handling."""
    if ns:
        return element.xpath(path, namespaces=ns)
    # Fallback: try without namespace prefix
    clean_path = re.sub(r"ar:", "", path)
    return element.xpath(clean_path)


def _xpath_text(
    element: etree._Element, path: str, ns: dict[str, str], default: str = ""
) -> str:
    """Get text content from XPath query."""
    results = _xpath(element, path, ns)
    if results:
        if isinstance(results[0], etree._Element):
            return results[0].text or default
        return str(results[0]) or default
    return default


def _xpath_int(
    element: etree._Element, path: str, ns: dict[str, str], default: int = 0
) -> int:
    """Get integer value from XPath query."""
    text = _xpath_text(element, path, ns)
    if not text:
        return default
    try:
        if text.startswith("0x") or text.startswith("0X"):
            return int(text, 16)
        return int(text)
    except ValueError:
        return default


def _xpath_float(
    element: etree._Element, path: str, ns: dict[str, str], default: float = 0.0
) -> float:
    """Get float value from XPath query."""
    text = _xpath_text(element, path, ns)
    if not text:
        return default
    try:
        return float(text)
    except ValueError:
        return default


def _parse_single_file(path: str) -> "UdsSpecification":
    """Top-level function for subprocess-safe parallel parsing."""
    return ArxmlParser().parse(path)


class ArxmlParser:
    """Parser for AUTOSAR DCM/CanTp ARXML files."""

    def __init__(self) -> None:
        self.ns: dict[str, str] = {}
        self.tree: Optional[etree._ElementTree] = None
        self.root: Optional[etree._Element] = None
        self.warnings: list[ArxmlValidationWarning] = []
        self.arxml_version: str = "unknown"
        self._path_index: dict[str, object] = {}

    def validate(self, arxml_path: str | Path) -> list[ArxmlValidationWarning]:
        """Validate an ARXML file structure and return warnings.

        Raises ArxmlValidationError for unrecoverable problems.
        Returns a list of ArxmlValidationWarning for recoverable issues.
        """
        arxml_path = Path(arxml_path)
        warnings: list[ArxmlValidationWarning] = []

        if not arxml_path.exists():
            raise ArxmlValidationError(f"ARXML file not found: {arxml_path}")

        if not arxml_path.suffix.lower() == ".arxml":
            warnings.append(ArxmlValidationWarning(
                "file", f"File extension is not .arxml: {arxml_path.suffix}"))

        # Try to parse as XML
        try:
            parser = etree.XMLParser(remove_blank_text=True, remove_comments=True)
            tree = etree.parse(str(arxml_path), parser)
        except etree.XMLSyntaxError as e:
            raise ArxmlValidationError(f"XML syntax error in {arxml_path}: {e}") from e

        root = tree.getroot()
        tag = etree.QName(root.tag).localname if root.tag else ""

        # Check for AUTOSAR root element
        if tag != "AUTOSAR":
            raise ArxmlValidationError(
                f"Root element is <{tag}>, expected <AUTOSAR>. "
                f"File may not be a valid AUTOSAR ARXML.")

        ns = _detect_namespace(root)
        if not ns:
            warnings.append(ArxmlValidationWarning(
                "namespace", "No AUTOSAR namespace detected; parsing may be unreliable"))

        # Check for DCM or CanTp module configuration
        has_dcm = bool(_xpath(root,
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES[contains(ar:SHORT-NAME/text(), 'Dcm')]", ns)
        ) if ns else bool(root.xpath(".//*[contains(local-name(), 'Dcm')]"))
        has_cantp = bool(_xpath(root,
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES[contains(ar:SHORT-NAME/text(), 'CanTp')]", ns)
        ) if ns else bool(root.xpath(".//*[contains(local-name(), 'CanTp')]"))

        if not has_dcm and not has_cantp:
            warnings.append(ArxmlValidationWarning(
                "content", "No DCM or CanTp module configuration found in ARXML"))

        return warnings

    def parse(
        self,
        arxml_path: "str | Path",
        cache_dir: "Optional[str | Path]" = None,
    ) -> UdsSpecification:
        """Parse an ARXML file and return a UDS specification.

        Args:
            arxml_path: Path to the ARXML file.
            cache_dir: Optional directory for caching parsed results.
                       When provided, a previously cached result is returned
                       if the file content has not changed.

        Returns:
            UdsSpecification with all parsed data.
        """
        arxml_path = Path(arxml_path)
        if not arxml_path.exists():
            raise FileNotFoundError(f"ARXML file not found: {arxml_path}")

        # Check cache before parsing
        cache_key: Optional[str] = None
        if cache_dir is not None:
            cache_key = self._get_cache_key(arxml_path)
            cached = self._load_from_cache(cache_key, cache_dir)
            if cached is not None:
                logger.debug("Cache hit for %s (key=%s)", arxml_path.name, cache_key)
                return cached

        logger.info("Parsing ARXML file: %s", arxml_path)

        # Validate first
        self.warnings = self.validate(arxml_path)
        for w in self.warnings:
            logger.warning("Validation [%s]: %s", w.section, w.message)

        parser = etree.XMLParser(remove_blank_text=True, remove_comments=True)
        self.tree = etree.parse(str(arxml_path), parser)
        self.root = self.tree.getroot()
        self.ns = _detect_namespace(self.root)

        # Detect AUTOSAR schema version
        self.arxml_version = _detect_arxml_version(self.root)
        if self.arxml_version.startswith("R3."):
            logger.debug(
                "Detected AUTOSAR %s — R3.x support is best-effort",
                self.arxml_version,
            )

        spec = UdsSpecification()

        # Build path index for faster DEFINITION-REF / BASE-REF lookups
        try:
            self._build_path_index(self.root)
        except Exception as e:
            logger.debug("Path index build failed (non-fatal): %s", e)

        # Parse each section with error recovery; skip broken sections
        parse_steps: list[tuple[str, ...]] = [
            ("ECU info",           "_parse_ecu_info"),
            ("DSL",                "_parse_dsl"),
            ("S3 server",         "_parse_s3_server"),
            ("Sessions",          "_parse_sessions"),
            ("Security",          "_parse_security"),
            ("DIDs",              "_parse_dids"),
            ("Routines",          "_parse_routines"),
            ("DTCs",              "_parse_dtcs"),
            ("Memory ranges",     "_parse_memory_ranges"),
            ("IO control DIDs",   "_parse_io_control_dids"),
            ("Periodic DIDs",     "_parse_periodic_dids"),
            ("DID ranges",        "_parse_did_ranges"),
            ("ComControl",        "_parse_com_control"),
            ("ResponseOnEvent",   "_parse_response_on_event"),
            ("DTC status mask",   "_parse_dtc_status_availability_mask"),
            ("MaxNumRespPend",    "_parse_max_num_resp_pend"),
            ("MaxResponseLength", "_parse_max_response_length"),
            ("FileTransfer",      "_parse_request_file_transfer"),
            ("ClearDTC notif",    "_parse_clear_dtc_notifications"),
            ("Dynamic DIDs",      "_parse_dynamic_dids"),
            ("General config",    "_parse_general_config"),
            ("CDTC/ClearDTC",     "_parse_cdtc_and_clear_dtc_group"),
            ("DTC groups",        "_parse_dtc_groups"),
            ("LinkControl BRs",   "_parse_link_control_baudrates"),
            ("MaxBlockLength",    "_parse_max_block_length"),
            ("Memory config",     "_parse_memory_config"),
            ("Multi-Client",      "_parse_multi_client"),
            ("Authentication",    "_parse_authentication"),
            ("Access Timing",     "_parse_access_timing"),
            ("DEM General",       "_parse_dem_general"),
            ("DEM OpCycles",      "_parse_dem_operation_cycles"),
            ("DEM Events",        "_parse_dem_event_parameters"),
            ("DEM Indicators",    "_parse_dem_indicators"),
            ("DEM EnableCond",    "_parse_dem_enable_conditions"),
            ("DEM StorageCond",   "_parse_dem_storage_conditions"),
            ("DEM EventMemory",   "_parse_dem_event_memories"),
            ("Services",          "_parse_services"),
        ]

        for section_name, method_name in parse_steps:
            try:
                getattr(self, method_name)(spec)
            except Exception as e:
                self.warnings.append(ArxmlValidationWarning(
                    section_name, f"Failed to parse: {e}"))
                logger.warning("Skipping '%s' section due to error: %s",
                               section_name, e)

        # Try to parse CanTp configuration from the same file
        try:
            self._parse_cantp(spec, arxml_path)
        except Exception as e:
            self.warnings.append(ArxmlValidationWarning(
                "CanTp", f"Failed to parse CanTp: {e}"))
            logger.warning("Skipping CanTp parsing: %s", e)

        logger.info(
            "Parsed: %d sessions, %d security levels, %d services, %d DIDs, %d routines",
            len(spec.sessions),
            len(spec.security_levels),
            len(spec.services),
            len(spec.dids),
            len(spec.routines),
        )

        # Save to cache if requested
        if cache_dir is not None and cache_key is not None:
            self._save_to_cache(spec, cache_key, cache_dir)

        return spec

    def parse_multi(
        self,
        arxml_paths: "list[str | Path]",
        parallel: bool = False,
        max_workers: Optional[int] = None,
        show_progress: bool = False,
    ) -> UdsSpecification:
        """Parse multiple ARXML files and merge results.

        Args:
            arxml_paths: List of paths to ARXML files.
            parallel: When True, parse files concurrently using
                      ProcessPoolExecutor.
            max_workers: Maximum number of worker processes when
                         parallel=True.  Defaults to os.cpu_count().
            show_progress: When True and tqdm is installed, display a
                           progress bar. Falls back to silent iteration
                           when tqdm is unavailable.

        Returns:
            Merged UdsSpecification.
        """
        progress = _make_progress(arxml_paths, "Parsing ARXML", enabled=show_progress)
        if parallel:
            specs: list[UdsSpecification] = []
            path_list = [str(p) for p in arxml_paths]
            with ProcessPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(_parse_single_file, p): p for p in path_list
                }
                for future in as_completed(futures):
                    try:
                        specs.append(future.result())
                    except Exception as e:
                        logger.warning(
                            "Failed to parse %s: %s", futures[future], e
                        )
                    finally:
                        progress.update(1)
            progress.close()
        else:
            specs = []
            for p in arxml_paths:
                specs.append(self.parse(p))
                progress.update(1)
            progress.close()

        if not specs:
            return UdsSpecification()

        merged = specs[0]
        for s in specs[1:]:
            merged.sessions.extend(s.sessions)
            merged.security_levels.extend(s.security_levels)
            merged.services.extend(s.services)
            merged.dids.extend(s.dids)
            merged.routines.extend(s.routines)
            merged.dtcs.extend(s.dtcs)
            merged.memory_ranges.extend(s.memory_ranges)
            merged.io_control_dids.extend(s.io_control_dids)
            merged.periodic_dids.extend(s.periodic_dids)
            merged.did_ranges.extend(s.did_ranges)
            merged.response_on_event.extend(s.response_on_event)
            merged.request_file_transfer.extend(s.request_file_transfer)
            merged.clear_dtc_notifications.extend(s.clear_dtc_notifications)
            merged.protocol_rows.extend(s.protocol_rows)
            merged.access_timing_rows.extend(s.access_timing_rows)
            if s.authentication_config is not None and merged.authentication_config is None:
                merged.authentication_config = s.authentication_config
            if s.com_control is not None:
                if merged.com_control is None:
                    merged.com_control = s.com_control
                else:
                    merged.com_control.sub_nodes.extend(s.com_control.sub_nodes)
            if s.dtc_status_availability_mask != 0xFF:
                merged.dtc_status_availability_mask = s.dtc_status_availability_mask
            if s.max_num_resp_pend > 0:
                merged.max_num_resp_pend = s.max_num_resp_pend
            if s.max_response_length > 0:
                merged.max_response_length = s.max_response_length
            # Merge transport config
            if s.transport_config is not None:
                if merged.transport_config is None:
                    merged.transport_config = s.transport_config
                else:
                    merged.transport_config.channels.extend(
                        s.transport_config.channels
                    )
            # Merge DEM fields
            merged.dem_operation_cycles.extend(s.dem_operation_cycles)
            merged.dem_event_parameters.extend(s.dem_event_parameters)
            merged.dem_indicators.extend(s.dem_indicators)
            merged.dem_enable_conditions.extend(s.dem_enable_conditions)
            merged.dem_storage_conditions.extend(s.dem_storage_conditions)
            merged.dem_event_memories.extend(s.dem_event_memories)
            merged.dem_dtcs.extend(s.dem_dtcs)
            merged.dem_freeze_frame_classes.extend(s.dem_freeze_frame_classes)
            merged.dem_extended_data_classes.extend(s.dem_extended_data_classes)
            merged.dem_combined_dtcs.extend(s.dem_combined_dtcs)
            merged.dtc_groups.extend(s.dtc_groups)
            merged.link_control_baudrates.extend(s.link_control_baudrates)
            if s.dem_general is not None and merged.dem_general is None:
                merged.dem_general = s.dem_general
            if s.max_block_length > 0 and merged.max_block_length == 0:
                merged.max_block_length = s.max_block_length

        return merged

    def _parse_ecu_info(self, spec: UdsSpecification) -> None:
        """Extract ECU name from module configuration."""
        assert self.root is not None

        # Try to find ECU-INSTANCE or MODULE-CONFIGURATION short name
        for path in [
            ".//ar:ECU-INSTANCE/ar:SHORT-NAME",
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES/ar:SHORT-NAME",
            ".//ar:ECUC-VALUE-COLLECTION/ar:SHORT-NAME",
            ".//ar:MODULE-CONFIGURATION/ar:SHORT-NAME",
        ]:
            name = _xpath_text(self.root, path, self.ns)
            if name:
                # Clean up "Dcm" prefix if present
                spec.ecu_name = name.replace("Dcm", "").strip("_") or name
                return

        # Try from SHORT-NAME of top-level AR-PACKAGE
        name = _xpath_text(self.root, ".//ar:AR-PACKAGE/ar:SHORT-NAME", self.ns)
        if name:
            spec.ecu_name = name

    def _parse_cantp(self, spec: UdsSpecification, arxml_path: Path) -> None:
        """Try to parse CanTp configuration from the ARXML file."""
        assert self.root is not None

        # Check if this file contains CanTp module configuration
        cantp_indicators = [
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES[ar:SHORT-NAME='CanTp']",
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES[contains(ar:SHORT-NAME/text(), 'CanTp')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'CanTpChannel')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'CanTpRxNSdu')]",
        ]
        has_cantp = False
        for path in cantp_indicators:
            if _xpath(self.root, path, self.ns):
                has_cantp = True
                break

        if has_cantp:
            try:
                from udsxml2tex.cantp_parser import CanTpParser

                cantp_parser = CanTpParser()
                config = cantp_parser.parse(arxml_path)
                if config.channels:
                    spec.transport_config = config
                    logger.info(
                        "CanTp: %d transport channels parsed",
                        len(config.channels),
                    )
            except Exception as e:
                logger.warning("Failed to parse CanTp config: %s", e)

    def _parse_dsl(self, spec: UdsSpecification) -> None:
        """Parse Diagnostic Session Layer configuration."""
        assert self.root is not None

        # Search for DcmDsl protocol configuration
        protocols = []
        for proto_path in [
            ".//ar:ECUC-CONTAINER-VALUE[starts-with(ar:SHORT-NAME,'DcmDslProtocolRow')]",
            ".//ar:CONTAINER[starts-with(ar:SHORT-NAME,'DcmDslProtocolRow')]",
            ".//ar:SUB-CONTAINER[starts-with(ar:SHORT-NAME,'DcmDslProtocolRow')]",
        ]:
            protocols = _xpath(self.root, proto_path, self.ns)
            if protocols:
                break

        # Extract protocol type from DcmDslProtocolRow
        for proto in protocols:
            ptype = self._get_param_value_text(proto, "DcmDslProtocolType")
            if ptype:
                spec.protocol_type = ptype
                logger.debug("  Protocol type: %s", ptype)
            # Protocol priority
            priority = self._get_param_value_int(proto, "DcmDslProtocolPriority")
            if priority > 0:
                spec.protocol_priority = priority
            # Protocol trans type
            trans_type = self._get_param_value_text(proto, "DcmDslProtocolTransType")
            if trans_type:
                spec.protocol_trans_type = trans_type
            # Protocol preempt timeout
            preempt = self._get_param_value_float(proto, "DcmDslProtocolPreemptTimeout")
            if preempt > 0.0:
                spec.protocol_preempt_timeout = preempt
            if ptype:
                break

        # Parse DSL buffer sizes from DcmDsl container
        dsl_containers = self._find_containers("DcmDsl")
        for dsl in dsl_containers:
            rx_buf = self._get_param_value_int(dsl, "DcmDslRxBufferSize")
            tx_buf = self._get_param_value_int(dsl, "DcmDslTxBufferSize")
            if rx_buf > 0:
                spec.dsl_rx_buffer_size = rx_buf
            if tx_buf > 0:
                spec.dsl_tx_buffer_size = tx_buf

        # Parse periodic transmission rates from DcmDsl
        for dsl in dsl_containers:
            slow = self._get_param_value_float(dsl, "DcmDslPeriodicTransmissionSlowRate")
            if slow > 0.0:
                spec.periodic_slow_rate = slow
            medium = self._get_param_value_float(dsl, "DcmDslPeriodicTransmissionMediumRate")
            if medium > 0.0:
                spec.periodic_medium_rate = medium
            fast = self._get_param_value_float(dsl, "DcmDslPeriodicTransmissionFastRate")
            if fast > 0.0:
                spec.periodic_fast_rate = fast

        # Try to find CAN IDs and connection mode from DcmDslConnection
        for conn_path in [
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DcmDslConnection')]",
            ".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), 'DcmDslConnection')]",
        ]:
            connections = _xpath(self.root, conn_path, self.ns)
            if connections:
                for conn in connections:
                    # Parse connection mode
                    conn_mode = self._get_param_value_text(
                        conn, "DcmDslConnectionMode"
                    )
                    if conn_mode and not spec.connection_mode:
                        spec.connection_mode = conn_mode
                    # Parse end-of-connection type
                    end_type = self._get_param_value_text(
                        conn, "DcmDslConnectionDcmEndOfConnectionType"
                    )
                    if end_type and not spec.connection_end_of_type:
                        spec.connection_end_of_type = end_type

                    for param_path in [
                        ".//ar:ECUC-NUMERICAL-PARAM-VALUE",
                        ".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE",
                    ]:
                        params = _xpath(conn, param_path, self.ns)
                        for param in params:
                            def_ref = _xpath_text(
                                param, "ar:DEFINITION-REF", self.ns
                            ) or _xpath_text(param, "ar:DEFINITION-REF/@DEST", self.ns)
                            value = _xpath_text(param, "ar:VALUE", self.ns)
                            if "RxPduId" in def_ref or "RxAddr" in def_ref:
                                spec.can_rx_id = value
                            elif "TxPduId" in def_ref or "TxAddr" in def_ref:
                                spec.can_tx_id = value
                break

    def _parse_s3_server(self, spec: UdsSpecification) -> None:
        """Parse the S3Server timeout from DcmDsp configuration."""
        assert self.root is not None

        # S3Server is a global parameter under DcmDsp
        dsp_containers = self._find_containers("DcmDsp")
        for container in dsp_containers:
            s3 = self._get_param_value_float(
                container, "DcmDspSessionS3Server", 0.0
            )
            if s3 > 0:
                spec.s3_server = s3
                logger.debug("  S3Server timeout: %.2f s", s3)
                return

    def _parse_sessions(self, spec: UdsSpecification) -> None:
        """Parse diagnostic session definitions."""
        assert self.root is not None

        # Search for DcmDspSession containers
        session_containers = self._find_containers("DcmDspSession")

        for container in session_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspSession":
                # This might be the parent container; look for sub-containers
                sub_containers = _xpath(
                    container,
                    ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                ) or _xpath(
                    container,
                    ".//ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_session(sub, spec)
                continue

            self._parse_single_session(container, spec)

    def _parse_single_session(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single session container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspSession",):
            return

        session_id = self._get_param_value_int(container, "DcmDspSessionLevel")
        if session_id == 0:
            session_id = self._get_param_value_int(container, "DcmDspSessionForBoot")

        p2 = self._get_param_value_float(container, "DcmDspSessionP2ServerMax", 0.05)
        p2_star = self._get_param_value_float(
            container, "DcmDspSessionP2StarServerMax", 5.0
        )

        session = DiagSession(
            short_name=short_name,
            session_id=session_id,
            p2_server_max=p2,
            p2_star_server_max=p2_star,
            comm_ctrl_option_mask=self._get_param_value_int(
                container, "DcmDspSessionCommCtrlOptionMask"
            ),
        )
        spec.sessions.append(session)
        logger.debug("  Session: %s (0x%02X)", short_name, session_id)

    def _parse_security(self, spec: UdsSpecification) -> None:
        """Parse security access level definitions."""
        assert self.root is not None

        sec_containers = self._find_containers("DcmDspSecurityRow")
        if not sec_containers:
            sec_containers = self._find_containers("DcmDspSecurity")

        for container in sec_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspSecurity":
                sub_containers = _xpath(
                    container,
                    ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_security(sub, spec)
                continue
            self._parse_single_security(container, spec)

    def _parse_single_security(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single security level container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspSecurity", "DcmDspSecurityRow"):
            # Check sub-containers
            subs = _xpath(
                container, ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
            )
            for sub in subs:
                self._parse_single_security(sub, spec)
            return

        level = self._get_param_value_int(container, "DcmDspSecurityLevel")
        max_attempts = self._get_param_value_int(
            container, "DcmDspSecurityNumAttDelay", 3
        )
        attempt_delay = self._get_param_value_float(
            container, "DcmDspSecurityDelayTime", 0.0
        )
        key_size = self._get_param_value_int(
            container, "DcmDspSecurityKeySize", 0
        )
        seed_size = self._get_param_value_int(
            container, "DcmDspSecuritySeedSize", 0
        )
        adr_size = self._get_param_value_int(
            container, "DcmDspSecurityADRSize", 0
        )
        num_provided_seed_attempts = self._get_param_value_int(
            container, "DcmDspSecurityNumProvidedSeedAttempts", 0
        )
        algorithm_ref = self._get_param_value_text(
            container, "DcmDspSecurityAlgorithmRef"
        ) or (self._get_ref_list(container, "DcmDspSecurityAlgorithmRef") or [""])[0]
        seed_key_increment_mode = self._get_param_value_text(
            container, "DcmDspSecuritySeedAndKeyTypeIncrementMode"
        )

        sec = SecurityLevel(
            short_name=short_name,
            security_level=level,
            num_max_attempts=max_attempts,
            attempt_delay=attempt_delay,
            key_size=key_size,
            seed_size=seed_size,
            adr_size=adr_size,
            num_provided_seed_attempts=num_provided_seed_attempts,
            algorithm_ref=algorithm_ref,
            seed_key_increment_mode=seed_key_increment_mode,
            delay_time_on_boot=self._get_param_value_float(
                container, "DcmDspSecurityDelayTimeOnBoot", 0.0
            ),
            attempt_counter_enabled=self._get_param_value_bool(
                container, "DcmDspSecurityAttemptCounterEnabled", True
            ),
        )
        spec.security_levels.append(sec)
        logger.debug("  Security: %s (level=%d)", short_name, level)

    def _build_data_function_map(self) -> dict[str, tuple[str, str]]:
        """Build a map of DcmDspData short-name -> (read_fnc, write_fnc)."""
        assert self.root is not None
        result: dict[str, tuple[str, str]] = {}
        for pattern in [
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DcmDspData')]",
            ".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), 'DcmDspData')]",
        ]:
            containers = _xpath(self.root, pattern, self.ns)
            if containers:
                for c in containers:
                    sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
                    if not sn:
                        continue
                    read_fnc = self._get_param_value_text(c, "DcmDspDataReadFnc")
                    write_fnc = self._get_param_value_text(c, "DcmDspDataWriteFnc")
                    if read_fnc or write_fnc:
                        result[sn] = (read_fnc, write_fnc)
                break
        return result

    def _parse_dids(self, spec: UdsSpecification) -> None:
        """Parse Data Identifier definitions."""
        assert self.root is not None

        data_fnc_map = self._build_data_function_map()
        did_containers = self._find_containers("DcmDspDid")

        for container in did_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspDid":
                sub_containers = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_did(sub, spec, data_fnc_map)
                continue
            self._parse_single_did(container, spec, data_fnc_map)

    def _parse_single_did(
        self,
        container: etree._Element,
        spec: UdsSpecification,
        data_fnc_map: dict[str, tuple[str, str]] | None = None,
    ) -> None:
        """Parse a single DID container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspDid",):
            return
        # Skip signal/data sub-containers that are not actual DIDs
        if "Signal" in short_name and "DID" not in short_name.upper().replace("SIGNAL", ""):
            return

        did_id = self._get_param_value_int(container, "DcmDspDidIdentifier")
        if did_id == 0:
            # Try to extract from the short name like "DID_F190"
            match = re.search(r"(?:DID[_]?)([0-9A-Fa-f]{4})", short_name)
            if match:
                did_id = int(match.group(1), 16)

        # Extract description
        description = self._get_description(container)

        # Check read/write access
        read_access = True
        write_access = False
        read_ref = self._get_param_ref(container, "DcmDspDidRead")
        write_ref = self._get_param_ref(container, "DcmDspDidWrite")
        if read_ref is not None:
            read_access = True
        if write_ref is not None:
            write_access = True

        # Parse session and security references
        sessions = self._get_ref_list(container, "DcmDspDidReadSessionRef")
        sessions.extend(self._get_ref_list(container, "DcmDspDidWriteSessionRef"))
        security = self._get_ref_list(container, "DcmDspDidReadSecurityLevelRef")
        security.extend(
            self._get_ref_list(container, "DcmDspDidWriteSecurityLevelRef")
        )

        # Check for snapshot/freeze-frame reference
        snapshot_ref = self._get_param_ref(container, "DcmDspDidFreezeFrameRef")
        snapshot_record = snapshot_ref is not None
        if not snapshot_record:
            # Also check for DcmDspSnapshotRecord sub-container
            snapshot_containers = _xpath(
                container,
                ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'SnapshotRecord')]",
                self.ns,
            ) or _xpath(
                container,
                ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'FreezeFrame')]",
                self.ns,
            )
            snapshot_record = len(snapshot_containers) > 0

        # Parse data elements (DcmDspDidSignal)
        data_elements: list[DataElement] = []
        signal_containers = _xpath(
            container,
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'Signal')]",
            self.ns,
        ) or _xpath(
            container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sig in signal_containers:
            sig_name = _xpath_text(sig, "ar:SHORT-NAME", self.ns)
            if sig_name and "Signal" in sig_name:
                byte_pos = self._get_param_value_int(
                    sig, "DcmDspDidBytePosition"
                ) or self._get_param_value_int(sig, "DcmDspDidDataByteOffset")
                bit_size = self._get_param_value_int(
                    sig, "DcmDspDidBitSize"
                ) or self._get_param_value_int(sig, "DcmDspDidDataSize", 8)
                data_type = self._get_param_value_text(
                    sig, "DcmDspDidDataType"
                ) or self._get_param_value_text(sig, "DcmDspDataType", "uint8")
                unit = self._get_param_value_text(sig, "DcmDspDidDataUnit")
                min_val_text = self._get_param_value_text(sig, "DcmDspDidDataMinValue")
                max_val_text = self._get_param_value_text(sig, "DcmDspDidDataMaxValue")
                coding = self._get_param_value_text(sig, "DcmDspDidDataCoding")
                endianness = self._get_param_value_text(
                    sig, "DcmDspDidDataEndianness"
                ) or self._get_param_value_text(sig, "DcmDspDataEndianness")
                fixed_len_text = self._get_param_value_text(
                    sig, "DcmDspDidDataFixedLength"
                ) or self._get_param_value_text(sig, "DcmDspDidFixedLength")
                fixed_length = fixed_len_text.lower() != "false" if fixed_len_text else True

                # Resolve DcmDspDataReadFnc / WriteFnc via DcmDspDidDataRef
                read_fnc = ""
                write_fnc = ""
                if data_fnc_map:
                    data_ref = self._get_param_ref(sig, "DcmDspDidDataRef")
                    if data_ref:
                        ref_key = data_ref.rsplit("/", 1)[-1]
                        read_fnc, write_fnc = data_fnc_map.get(ref_key, ("", ""))

                de = DataElement(
                    short_name=sig_name,
                    byte_position=byte_pos,
                    bit_size=bit_size,
                    data_type=data_type,
                    unit=unit,
                    coding=coding,
                    endianness=endianness,
                    fixed_length=fixed_length,
                    min_value=float(min_val_text) if min_val_text else None,
                    max_value=float(max_val_text) if max_val_text else None,
                    read_function=read_fnc,
                    write_function=write_fnc,
                )
                data_elements.append(de)

        # Calculate total byte length
        total_bytes = self._get_param_value_int(container, "DcmDspDidDataSize")
        if total_bytes == 0 and data_elements:
            max_end = max(
                de.byte_position + (de.bit_size + 7) // 8 for de in data_elements
            )
            total_bytes = max_end

        did = Did(
            short_name=short_name,
            did_id=did_id,
            description=description,
            data_elements=data_elements,
            read_access=read_access,
            write_access=write_access,
            snapshot_record=snapshot_record,
            supported_sessions=list(set(sessions)),
            required_security_levels=list(set(security)),
            total_byte_length=total_bytes,
        )
        spec.dids.append(did)
        logger.debug("  DID: %s (0x%04X)", short_name, did_id)

    def _parse_routines(self, spec: UdsSpecification) -> None:
        """Parse Routine Control definitions."""
        assert self.root is not None

        routine_containers = self._find_containers("DcmDspRoutine")

        for container in routine_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspRoutine":
                sub_containers = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_routine(sub, spec)
                continue
            self._parse_single_routine(container, spec)

    def _parse_single_routine(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single routine container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspRoutine",):
            return

        routine_id = self._get_param_value_int(
            container, "DcmDspRoutineIdentifier"
        ) or self._get_param_value_int(container, "DcmDspRoutineId")

        if routine_id == 0:
            match = re.search(r"(?:Routine[_]?)([0-9A-Fa-f]{4})", short_name)
            if match:
                routine_id = int(match.group(1), 16)

        # Check start/stop/result support
        start_ref = self._get_param_ref(container, "DcmDspStartRoutine")
        stop_ref = self._get_param_ref(container, "DcmDspStopRoutine")
        result_ref = self._get_param_ref(container, "DcmDspRequestRoutineResults")

        sessions = self._get_ref_list(container, "DcmDspRoutineSessionRef")
        security = self._get_ref_list(container, "DcmDspRoutineSecurityLevelRef")

        max_num_options = self._get_param_value_int(
            container, "DcmDspRoutineMaxNumberOfOptions"
        )
        access_type_required = self._get_param_value_bool(
            container, "DcmDspRoutineAccessTypeRequired"
        )

        routine = Routine(
            short_name=short_name,
            routine_id=routine_id,
            description=self._get_description(container),
            start_supported=start_ref is not None or True,
            stop_supported=stop_ref is not None,
            result_supported=result_ref is not None,
            in_parameters=self._parse_routine_params(container, "in"),
            out_parameters=self._parse_routine_params(container, "out"),
            supported_sessions=sessions,
            required_security_levels=security,
            max_number_of_options=max_num_options,
            access_type_required=access_type_required,
        )
        spec.routines.append(routine)
        logger.debug("  Routine: %s (0x%04X)", short_name, routine_id)

    def _parse_routine_params(
        self, container: etree._Element, direction: str
    ) -> list[RoutineParameter]:
        """Parse routine in/out signal parameters."""
        params: list[RoutineParameter] = []
        # DcmDspRoutineInSignal / DcmDspRoutineOutSignal sub-containers
        tag = "InSignal" if direction == "in" else "OutSignal"
        sig_containers = _xpath(
            container,
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{tag}')]",
            self.ns,
        )
        for sig in sig_containers:
            sig_name = _xpath_text(sig, "ar:SHORT-NAME", self.ns)
            if not sig_name:
                continue
            byte_pos = self._get_param_value_int(sig, "DcmDspRoutineSignalPos")
            bit_size = self._get_param_value_int(sig, "DcmDspRoutineSignalLength", 8)
            data_type = self._get_param_value_text(
                sig, "DcmDspRoutineSignalType", "uint8"
            )
            params.append(
                RoutineParameter(
                    short_name=sig_name,
                    direction=direction,
                    byte_position=byte_pos,
                    bit_size=bit_size,
                    data_type=data_type,
                )
            )
        return sorted(params, key=lambda p: p.byte_position)

    def _parse_dtcs(self, spec: UdsSpecification) -> None:
        """Parse DTC (Diagnostic Trouble Code) definitions."""
        assert self.root is not None

        dtc_containers = self._find_containers("DcmDspDtc")
        for container in dtc_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspDtc":
                subs = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in subs:
                    self._parse_single_dtc(sub, spec)
                continue
            self._parse_single_dtc(container, spec)

    def _parse_single_dtc(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DTC container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspDtc",):
            return

        dtc_id = self._get_param_value_int(container, "DcmDspDtcId")
        if dtc_id == 0:
            dtc_id = self._get_param_value_int(container, "DcmDspDtcValue")
        func_unit = self._get_param_value_text(container, "DcmDspDtcFunctionalUnit")
        severity = self._get_param_value_text(container, "DcmDspDtcSeverity")
        description = self._get_description(container)
        manufacturer_severity = self._get_param_value_text(
            container, "DcmDspDtcManufacturerSeverity"
        )

        dtc = DtcDefinition(
            short_name=short_name,
            dtc_id=dtc_id,
            functional_unit=func_unit,
            severity=severity,
            description=description,
            extended_data_records=self._parse_dtc_extended_data(container),
            snapshot_records=self._parse_dtc_snapshots(container),
            manufacturer_severity=manufacturer_severity,
            aging_cycle_counter_threshold=self._get_param_value_int(
                container, "DcmDspDtcAgingCycleCounterThreshold"
            ),
            aging_allowed=self._get_param_value_bool(
                container, "DcmDspDtcAgingAllowed", True
            ),
            priority=self._get_param_value_int(
                container, "DcmDspDtcPriority"
            ),
            dtc_kind=self._get_param_value_text(
                container, "DcmDspDtcKind"
            ),
            immediate_nv_storage=self._get_param_value_bool(
                container, "DcmDspDtcImmediateNvStorage"
            ),
            occurrence_counter_processing=self._get_param_value_text(
                container, "DcmDspDtcOccurrenceCounterProcessing"
            ),
        )
        spec.dtcs.append(dtc)
        logger.debug("  DTC: %s (0x%06X)", short_name, dtc_id)

    def _parse_dtc_extended_data(
        self, container: etree._Element
    ) -> list[DtcExtendedDataRecord]:
        """Parse DcmDspDtcExtendedDataRecord sub-containers within a DTC."""
        records: list[DtcExtendedDataRecord] = []
        subs = _xpath(
            container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sub in subs:
            sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
            if not sn or "ExtendedData" not in sn:
                # Also check DEFINITION-REF
                def_ref = _xpath_text(
                    sub,
                    ".//ar:DEFINITION-REF",
                    self.ns,
                )
                if not def_ref or "ExtendedDataRecord" not in def_ref:
                    continue
            rec_num = self._get_param_value_int(
                sub, "DcmDspExtendedDataRecordNumber"
            ) or self._get_param_value_int(sub, "DcmDspDtcExtDataRecordNumber")
            data_size = self._get_param_value_int(
                sub, "DcmDspExtendedDataRecordSize"
            ) or self._get_param_value_int(sub, "DcmDspDtcExtDataRecordSize")
            records.append(
                DtcExtendedDataRecord(
                    record_number=rec_num,
                    short_name=sn or "",
                    data_size=data_size,
                )
            )
        return sorted(records, key=lambda r: r.record_number)

    def _parse_dtc_snapshots(
        self, container: etree._Element
    ) -> list[DtcSnapshotRecord]:
        """Parse DcmDspDtcSnapshotRecord sub-containers within a DTC."""
        records: list[DtcSnapshotRecord] = []
        subs = _xpath(
            container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sub in subs:
            sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
            if not sn or "Snapshot" not in sn:
                def_ref = _xpath_text(
                    sub,
                    ".//ar:DEFINITION-REF",
                    self.ns,
                )
                if not def_ref or "SnapshotRecord" not in def_ref:
                    continue
            rec_num = self._get_param_value_int(
                sub, "DcmDspDtcSnapshotRecordNumber"
            ) or self._get_param_value_int(sub, "DcmDspSnapshotRecordNumber")
            # Parse referenced DIDs
            did_refs = self._get_ref_list(sub, "DcmDspDtcSnapshotRecordDidRef")
            did_ids: list[int] = []
            for ref in did_refs:
                # extract DID ID from reference name like "DID_F190_VIN"
                match = re.search(r"(?:DID[_]?)([0-9A-Fa-f]{4})", ref)
                if match:
                    did_ids.append(int(match.group(1), 16))
            records.append(
                DtcSnapshotRecord(
                    record_number=rec_num,
                    short_name=sn or "",
                    dids=did_ids,
                )
            )
        return sorted(records, key=lambda r: r.record_number)

    def _parse_memory_ranges(self, spec: UdsSpecification) -> None:
        """Parse memory access range definitions."""
        assert self.root is not None

        for tag in ("DcmDspReadMemoryRangeInfo", "DcmDspWriteMemoryRangeInfo",
                     "DcmDspMemoryRangeInfo"):
            containers = self._find_containers(tag)
            for container in containers:
                sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
                if not sn or sn == tag:
                    subs = _xpath(
                        container,
                        "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                        self.ns,
                    )
                    for sub in subs:
                        self._parse_single_memory_range(sub, spec, tag)
                    continue
                self._parse_single_memory_range(container, spec, tag)

    def _parse_single_memory_range(
        self, container: etree._Element, spec: UdsSpecification, tag: str
    ) -> None:
        """Parse a single memory range container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name:
            return

        start_addr = self._get_param_value_int(
            container, "DcmDspMemoryRangeStartAddress"
        ) or self._get_param_value_int(container, "DcmDspReadMemoryRangeLow")
        end_addr = self._get_param_value_int(
            container, "DcmDspMemoryRangeEndAddress"
        ) or self._get_param_value_int(container, "DcmDspReadMemoryRangeHigh")

        read_access = "Read" in tag or "MemoryRange" in tag
        write_access = "Write" in tag

        sessions = self._get_ref_list(container, "DcmDspMemoryRangeSessionRef")
        security = self._get_ref_list(container, "DcmDspMemoryRangeSecurityLevelRef")

        addressing_mode = self._get_param_value_text(
            container, "DcmDspMemoryRangeAddressingMode"
        )
        mem_range_length = self._get_param_value_int(
            container, "DcmDspMemoryRangeLength"
        )

        mr = MemoryRange(
            short_name=short_name,
            start_address=start_addr,
            end_address=end_addr,
            read_access=read_access,
            write_access=write_access,
            supported_sessions=sessions,
            required_security_levels=security,
            addressing_mode=addressing_mode,
            memory_range_length=mem_range_length,
            memory_id_value=self._get_param_value_int(
                container, "DcmDspMemoryIdValue"
            ),
        )
        spec.memory_ranges.append(mr)
        logger.debug("  MemoryRange: %s (0x%08X–0x%08X)", short_name, start_addr, end_addr)

    def _parse_io_control_dids(self, spec: UdsSpecification) -> None:
        """Parse IO Control DID definitions."""
        assert self.root is not None

        # IO control info is stored as DcmDspDidControl inside DcmDspDid containers
        did_containers = self._find_containers("DcmDspDid")
        for container in did_containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DcmDspDid":
                subs = _xpath(
                    container, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    self._try_parse_io_control_did(sub, spec)
                continue
            self._try_parse_io_control_did(container, spec)

    def _try_parse_io_control_did(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Try to parse a DID container as IO-control-capable."""
        # Check for DcmDspDidControl sub-container
        ctrl_containers = _xpath(
            container,
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DcmDspDidControl')]",
            self.ns,
        )
        if not ctrl_containers:
            return

        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name:
            return

        did_id = self._get_param_value_int(container, "DcmDspDidIdentifier")
        ctrl = ctrl_containers[0]
        mask_size = self._get_param_value_int(ctrl, "DcmDspDidControlMaskSize")
        freeze = self._get_param_value_bool(ctrl, "DcmDspDidFreezeCurrentState")
        reset = self._get_param_value_bool(ctrl, "DcmDspDidResetToDefault")
        short_term = self._get_param_value_bool(ctrl, "DcmDspDidShortTermAdjustment")
        return_ctrl = self._get_param_value_bool(ctrl, "DcmDspDidReturnControlToEcu")
        ctrl_opt_rec_size = self._get_param_value_int(
            ctrl, "DcmDspDidControlOptionRecordSize"
        )
        support_phys = self._get_param_value_bool(
            ctrl, "DcmDspDidControlSupportOnPhysicalRequest", True
        )
        support_func = self._get_param_value_bool(
            ctrl, "DcmDspDidControlSupportOnFunctionalRequest", False
        )

        sessions = self._get_ref_list(container, "DcmDspDidControlSessionRef")
        if not sessions:
            sessions = self._get_ref_list(container, "DcmDspDidReadSessionRef")
        security = self._get_ref_list(container, "DcmDspDidControlSecurityLevelRef")
        if not security:
            security = self._get_ref_list(container, "DcmDspDidReadSecurityLevelRef")

        io_did = IoControlDid(
            short_name=short_name,
            did_id=did_id,
            control_mask_size=mask_size,
            freeze_current_state=freeze,
            reset_to_default=reset,
            short_term_adjustment=short_term,
            return_control_to_ecu=return_ctrl,
            supported_sessions=sessions,
            required_security_levels=security,
            control_option_record_size=ctrl_opt_rec_size,
            support_on_physical=support_phys,
            support_on_functional=support_func,
        )
        spec.io_control_dids.append(io_did)
        logger.debug("  IOControlDID: %s (0x%04X)", short_name, did_id)

    def _parse_periodic_dids(self, spec: UdsSpecification) -> None:
        """Parse periodic / ReadDataByPeriodicIdentifier DID definitions."""
        assert self.root is not None

        periodic_containers = self._find_containers("DcmDspPeriodicDid")
        for container in periodic_containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DcmDspPeriodicDid":
                subs = _xpath(
                    container, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    self._parse_single_periodic_did(sub, spec)
                continue
            self._parse_single_periodic_did(container, spec)

    def _parse_single_periodic_did(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single periodic DID container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspPeriodicDid",):
            return

        did_id = self._get_param_value_int(container, "DcmDspPeriodicDidIdentifier")
        mode = self._get_param_value_text(container, "DcmDspPeriodicTransmissionMode")
        sessions = self._get_ref_list(container, "DcmDspPeriodicDidSessionRef")
        update_period = self._get_param_value_float(
            container, "DcmDspPeriodicDidUpdatePeriod"
        )
        security = self._get_ref_list(container, "DcmDspPeriodicDidSecurityLevelRef")

        pdid = PeriodicDid(
            short_name=short_name,
            did_id=did_id,
            transmission_mode=mode,
            supported_sessions=sessions,
            update_period=update_period,
            required_security_levels=security,
        )
        spec.periodic_dids.append(pdid)
        logger.debug("  PeriodicDID: %s (0x%04X)", short_name, did_id)

    def _parse_did_ranges(self, spec: UdsSpecification) -> None:
        """Parse DcmDspDidRange definitions."""
        assert self.root is not None

        containers = self._find_containers("DcmDspDidRange")
        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DcmDspDidRange":
                subs = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in subs:
                    self._parse_single_did_range(sub, spec)
                continue
            self._parse_single_did_range(container, spec)

    def _parse_single_did_range(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DID range container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspDidRange",):
            return

        lower = self._get_param_value_int(
            container, "DcmDspDidRangeIdentifierLowerLimit"
        ) or self._get_param_value_int(container, "DcmDspDidRangeLowerLimit")
        upper = self._get_param_value_int(
            container, "DcmDspDidRangeIdentifierUpperLimit"
        ) or self._get_param_value_int(container, "DcmDspDidRangeUpperLimit")

        has_read = self._get_param_value_bool(container, "DcmDspDidRangeHasGaps") is not None
        # Check read/write access via references or flags
        read_access = True  # default for DID ranges
        write_access = False
        read_ref = self._get_param_ref(container, "DcmDspDidRangeRead")
        write_ref = self._get_param_ref(container, "DcmDspDidRangeWrite")
        if read_ref:
            read_access = True
        if write_ref:
            write_access = True

        sessions = self._get_ref_list(container, "DcmDspDidRangeSessionRef")
        security = self._get_ref_list(container, "DcmDspDidRangeSecurityLevelRef")

        has_gaps = self._get_param_value_bool(container, "DcmDspDidRangeHasGaps", True)
        data_length = self._get_param_value_int(container, "DcmDspDidRangeDataLength")

        dr = DidRange(
            short_name=short_name,
            lower_did=lower,
            upper_did=upper,
            read_access=read_access,
            write_access=write_access,
            supported_sessions=sessions,
            required_security_levels=security,
            has_gaps=has_gaps,
            data_length=data_length,
        )
        spec.did_ranges.append(dr)
        logger.debug(
            "  DIDRange: %s (0x%04X–0x%04X)", short_name, lower, upper
        )

    def _parse_services(self, spec: UdsSpecification) -> None:
        """Parse Diagnostic Service Dispatcher (DSD) service table."""
        assert self.root is not None

        service_containers = self._find_containers("DcmDsdService")

        for container in service_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name in ("DcmDsdService", "DcmDsdServiceTable"):
                sub_containers = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_service(sub, spec)
                continue
            self._parse_single_service(container, spec)

    def _parse_single_service(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single service container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in (
            "DcmDsdService",
            "DcmDsdServiceTable",
        ):
            return

        service_id = self._get_param_value_int(container, "DcmDsdSidTabServiceId")
        if service_id == 0:
            service_id = self._get_param_value_int(container, "DcmDsdServiceId")

        # Check if subfunctions supported
        has_subfunc = self._get_param_value_bool(
            container, "DcmDsdSidTabSubfuncAvail"
        )

        # Check suppressPosRspMsgIndicationBit
        suppress_pos_rsp = self._get_param_value_bool(
            container, "DcmDsdSidTabSuppressPosRsp"
        )

        # Get session and security info
        sessions = self._get_ref_list(container, "DcmDsdSidTabSessionLevelRef")
        security = self._get_ref_list(container, "DcmDsdSidTabSecurityLevelRef")

        # Get addressing mode
        addressing = []
        addr_val = self._get_param_value_text(container, "DcmDsdSidTabAddressingMode")
        if addr_val:
            # Normalize AUTOSAR enum values
            val = addr_val.upper()
            if "FUNC" in val and "PHYS" in val:
                addressing = ["physical", "functional"]
            elif "FUNC" in val:
                addressing = ["functional"]
            elif "PHYS" in val:
                addressing = ["physical"]
            else:
                addressing = [addr_val]
        else:
            # Fall back to ISO 14229-1 standard addressing modes
            addressing = STANDARD_ADDRESSING_MODES.get(service_id, ["physical"])

        # Use standard service name if available
        name = UDS_SERVICE_NAMES.get(service_id, short_name)

        # Parse sub-functions from ARXML (DcmDsdSubService containers)
        sub_functions = self._parse_sub_services(container)
        if not sub_functions and has_subfunc:
            # Fall back to ISO 14229-1 standard sub-functions
            std_sfs = STANDARD_SUB_FUNCTIONS.get(service_id, [])
            sub_functions = [
                SubFunction(short_name=sf_name, sub_function_id=sf_id)
                for sf_id, sf_name in std_sfs
            ]

        # Build NRC list: prefer ARXML definitions, fall back to defaults
        nrc_list = self._parse_service_nrcs(container)
        if not nrc_list:
            nrc_list = self._build_default_nrcs(service_id, has_subfunc)

        service = UdsService(
            short_name=name,
            service_id=service_id,
            supported_sessions=sessions,
            required_security_levels=security,
            sub_functions=sub_functions,
            nrc_list=nrc_list,
            addressing_modes=addressing,
            suppress_pos_rsp=suppress_pos_rsp,
            request_min_length=self._get_param_value_int(
                container, "DcmDsdServiceRequestMinLength"
            ),
            request_max_length=self._get_param_value_int(
                container, "DcmDsdServiceRequestMaxLength"
            ),
            response_min_length=self._get_param_value_int(
                container, "DcmDsdServiceResponseMinLength"
            ),
            response_max_length=self._get_param_value_int(
                container, "DcmDsdServiceResponseMaxLength"
            ),
        )
        spec.services.append(service)
        logger.debug("  Service: %s (0x%02X), %d sub-functions",
                     name, service_id, len(sub_functions))

    def _parse_sub_services(
        self, service_container: etree._Element
    ) -> list[SubFunction]:
        """Parse DcmDsdSubService sub-containers within a service."""
        sub_functions: list[SubFunction] = []
        # Look for DcmDsdSubService containers
        sub_svc_containers = _xpath(
            service_container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sub_c in sub_svc_containers:
            sn = _xpath_text(sub_c, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue
            sf_id_text = self._get_param_value_text(sub_c, "DcmDsdSubServiceId")
            if not sf_id_text and not sn.lower().startswith("subservice"):
                # No sub-service ID found and name doesn't indicate a sub-service
                continue
            sf_id = self._get_param_value_int(sub_c, "DcmDsdSubServiceId")
            sf_sessions = self._get_ref_list(
                sub_c, "DcmDsdSubServiceSessionLevelRef"
            )
            sf_security = self._get_ref_list(
                sub_c, "DcmDsdSubServiceSecurityLevelRef"
            )
            sf_suppress = self._get_param_value_bool(
                sub_c, "DcmDsdSubServiceSuppressPosRsp"
            )
            sf_data_block = self._get_param_value_int(
                sub_c, "DcmDsdSubServiceDataBlockSize"
            )
            sub_functions.append(
                SubFunction(
                    short_name=sn,
                    sub_function_id=sf_id,
                    supported_sessions=sf_sessions,
                    required_security_levels=sf_security,
                    suppress_pos_rsp=sf_suppress,
                    data_block_size=sf_data_block,
                )
            )
        return sorted(sub_functions, key=lambda s: s.sub_function_id)

    def _parse_service_nrcs(
        self, service_container: etree._Element
    ) -> list[NrcEntry]:
        """Parse NRC definitions from DcmDsdNegativeResponseCode sub-containers."""
        nrcs: list[NrcEntry] = []
        # Look for NRC containers within service
        nrc_containers = _xpath(
            service_container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for nc in nrc_containers:
            sn = _xpath_text(nc, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue
            # Check if this is a NRC container via DEFINITION-REF or name
            def_ref = _xpath_text(nc, ".//ar:DEFINITION-REF", self.ns) or ""
            if "NegativeResponseCode" not in def_ref and "Nrc" not in sn and "NRC" not in sn:
                continue
            nrc_code = self._get_param_value_int(nc, "DcmDsdNegativeResponseCodeValue")
            if nrc_code == 0:
                nrc_code = self._get_param_value_int(nc, "DcmDsdNrcValue")
            if nrc_code == 0:
                # Try to extract from name like NRC_0x31 or NRC_31
                match = re.search(r"(?:0x)?([0-9A-Fa-f]{2})", sn)
                if match:
                    nrc_code = int(match.group(1), 16)
            if nrc_code == 0:
                continue
            nrc_name = STANDARD_NRCS.get(nrc_code, sn)
            # For NRC 0x22 with empty standard name, try to pull DESC from ARXML
            nrc_description = ""
            if nrc_code == 0x22 and not nrc_name:
                nrc_description = self._extract_nrc_description_from_arxml(nc)
            nrcs.append(
                NrcEntry(nrc_code=nrc_code, nrc_name=nrc_name or nrc_description)
            )
        return sorted(nrcs, key=lambda n: n.nrc_code)

    def _build_default_nrcs(
        self, service_id: int, has_subfunc: bool
    ) -> list[NrcEntry]:
        """Build default NRC list for a service."""
        nrcs = []
        # Common NRCs for all services
        common_nrc_codes = [0x10, 0x11, 0x13, 0x22, 0x7F]
        if has_subfunc:
            common_nrc_codes.append(0x12)
            common_nrc_codes.append(0x7E)

        # Service-specific NRCs
        if service_id == 0x11:  # ECUReset
            common_nrc_codes.extend([0x33])
        elif service_id == 0x14:  # ClearDiagnosticInformation
            common_nrc_codes.extend([0x31])
        elif service_id == 0x19:  # ReadDTCInformation
            common_nrc_codes.extend([0x31])
        elif service_id == 0x27:  # SecurityAccess
            common_nrc_codes.extend([0x24, 0x31, 0x33, 0x35, 0x36, 0x37])
        elif service_id == 0x29:  # Authentication
            common_nrc_codes.extend([0x24, 0x31, 0x33, 0x70])
        elif service_id == 0x28:  # CommunicationControl
            common_nrc_codes.extend([0x31])
        elif service_id in (0x22, 0x2E):  # Read/Write DID
            common_nrc_codes.extend([0x31, 0x33])
        elif service_id == 0x31:  # RoutineControl
            common_nrc_codes.extend([0x24, 0x31, 0x33])
        elif service_id == 0x34:  # RequestDownload
            common_nrc_codes.extend([0x31, 0x33, 0x70])
        elif service_id == 0x36:  # TransferData
            common_nrc_codes.extend([0x24, 0x31, 0x71, 0x72, 0x73])
        elif service_id == 0x37:  # RequestTransferExit
            common_nrc_codes.extend([0x24, 0x31, 0x72])
        elif service_id == 0x85:  # ControlDTCSetting
            common_nrc_codes.extend([0x31])

        for code in sorted(set(common_nrc_codes)):
            name = STANDARD_NRCS.get(code, f"NRC_{code:02X}")
            nrcs.append(NrcEntry(nrc_code=code, nrc_name=name))

        return nrcs

    def _parse_com_control(self, spec: UdsSpecification) -> None:
        """Parse DcmDspComControl configuration."""
        assert self.root is not None

        containers = self._find_containers("DcmDspComControl")
        if not containers:
            return

        sub_nodes: list[ComControlSubNode] = []
        sessions: list[str] = []
        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if sn == "DcmDspComControl":
                sessions = self._get_ref_list(container, "DcmDspComControlSessionRef")
            # Look for sub-node containers
            subs = _xpath(
                container,
                ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                self.ns,
            ) or [container]
            for sub in subs:
                sub_sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
                if not sub_sn or sub_sn == "DcmDspComControl":
                    continue
                comm_type = self._get_param_value_int(
                    sub, "DcmDspComControlCommunicationType"
                )
                subnet = self._get_param_value_int(
                    sub, "DcmDspComControlSubNodeId"
                ) or self._get_param_value_int(sub, "DcmDspComControlSubnetNumber")
                sub_nodes.append(
                    ComControlSubNode(
                        short_name=sub_sn,
                        communication_type=comm_type,
                        subnet_number=subnet,
                    )
                )
        if sub_nodes:
            suppressor_mask = False
            for container in containers:
                suppressor_mask = self._get_param_value_bool(
                    container, "DcmDspComControlSuppressorRxUsingMask"
                )
                if suppressor_mask:
                    break
            spec.com_control = ComControlConfig(
                sub_nodes=sub_nodes,
                supported_sessions=sessions,
                suppressor_rx_using_mask=suppressor_mask,
            )
            logger.debug("  ComControl: %d sub-nodes", len(sub_nodes))

    def _parse_response_on_event(self, spec: UdsSpecification) -> None:
        """Parse DcmDspResponseOnEvent / DcmDspRoe configuration."""
        assert self.root is not None

        for tag in ("DcmDspResponseOnEvent", "DcmDspRoe"):
            containers = self._find_containers(tag)
            for container in containers:
                sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
                if not sn or sn in (tag,):
                    subs = _xpath(
                        container,
                        "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                        self.ns,
                    )
                    for sub in subs:
                        self._parse_single_roe(sub, spec)
                    continue
                self._parse_single_roe(container, spec)

    def _parse_single_roe(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single ResponseOnEvent entry."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return

        ewt = self._get_param_value_int(container, "DcmDspRoeEventWindowTime")
        if ewt == 0:
            ewt = self._get_param_value_int(container, "DcmDspResponseOnEventWindowTime")
        store = self._get_param_value_bool(container, "DcmDspRoeStoreEvent")
        svc_to_resp = self._get_param_value_int(
            container, "DcmDspRoeServiceToRespondTo"
        )
        event_type = self._get_param_value_text(container, "DcmDspRoeEventType")
        sessions = self._get_ref_list(container, "DcmDspRoeSessionRef")

        roe = ResponseOnEventConfig(
            short_name=sn,
            event_window_time=ewt,
            store_event=store,
            service_to_respond_to=svc_to_resp,
            event_type=event_type,
            supported_sessions=sessions,
            max_event_map_range_identifier=self._get_param_value_int(
                container, "DcmDspRoeMaxEventMapRangeIdentifier"
            ),
            transmission_mode=self._get_param_value_text(
                container, "DcmDspRoeTransmissionMode"
            ),
        )
        spec.response_on_event.append(roe)
        logger.debug("  ROE: %s (eventType=%s)", sn, event_type)

    def _parse_dtc_status_availability_mask(self, spec: UdsSpecification) -> None:
        """Parse DcmDspDtcStatusAvailabilityMask from DcmDsp container."""
        assert self.root is not None

        dsp_containers = self._find_containers("DcmDsp")
        for container in dsp_containers:
            mask = self._get_param_value_int(
                container, "DcmDspDtcStatusAvailabilityMask", 0
            )
            if mask > 0:
                spec.dtc_status_availability_mask = mask
                logger.debug("  DTC StatusAvailabilityMask: 0x%02X", mask)
                return

    def _parse_max_num_resp_pend(self, spec: UdsSpecification) -> None:
        """Parse DcmDslDiagRespMaxNumRespPend from DcmDsl."""
        assert self.root is not None

        dsl_containers = self._find_containers("DcmDsl")
        for container in dsl_containers:
            val = self._get_param_value_int(
                container, "DcmDslDiagRespMaxNumRespPend", 0
            )
            if val > 0:
                spec.max_num_resp_pend = val
                logger.debug("  MaxNumRespPend: %d", val)
                return
        # Also try in DcmDslProtocolRow
        proto_containers = self._find_containers("DcmDslProtocolRow")
        for container in proto_containers:
            val = self._get_param_value_int(
                container, "DcmDslDiagRespMaxNumRespPend", 0
            )
            if val > 0:
                spec.max_num_resp_pend = val
                return

    def _parse_max_response_length(self, spec: UdsSpecification) -> None:
        """Parse DcmDslProtocolMaximumResponseLength."""
        assert self.root is not None

        for tag in ("DcmDslProtocolRow", "DcmDsl"):
            containers = self._find_containers(tag)
            for container in containers:
                val = self._get_param_value_int(
                    container, "DcmDslProtocolMaximumResponseLength", 0
                )
                if val > 0:
                    spec.max_response_length = val
                    logger.debug("  MaxResponseLength: %d", val)
                    return

    def _parse_request_file_transfer(self, spec: UdsSpecification) -> None:
        """Parse DcmDspRequestFileTransfer configuration."""
        assert self.root is not None

        containers = self._find_containers("DcmDspRequestFileTransfer")
        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DcmDspRequestFileTransfer":
                subs = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in subs:
                    self._parse_single_file_transfer(sub, spec)
                continue
            self._parse_single_file_transfer(container, spec)

    def _parse_single_file_transfer(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single file transfer config."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return

        max_path = self._get_param_value_int(
            container, "DcmDspRequestFileTransferMaxFilePathLength"
        )
        max_size = self._get_param_value_int(
            container, "DcmDspRequestFileTransferMaxFileSize"
        )
        sessions = self._get_ref_list(
            container, "DcmDspRequestFileTransferSessionRef"
        )
        security = self._get_ref_list(
            container, "DcmDspRequestFileTransferSecurityLevelRef"
        )

        rft = RequestFileTransferConfig(
            short_name=sn,
            max_file_path_length=max_path,
            max_file_size=max_size,
            supported_sessions=sessions,
            required_security_levels=security,
            format_identifier=self._get_param_value_int(
                container, "DcmDspRequestFileTransferFormatIdentifier"
            ),
            data_block_size=self._get_param_value_int(
                container, "DcmDspRequestFileTransferDataBlockSize"
            ),
            address_length=self._get_param_value_int(
                container, "DcmDspRequestFileTransferAddressLength"
            ),
            length_length=self._get_param_value_int(
                container, "DcmDspRequestFileTransferLengthLength"
            ),
        )
        spec.request_file_transfer.append(rft)
        logger.debug("  FileTransfer: %s", sn)

    def _parse_clear_dtc_notifications(self, spec: UdsSpecification) -> None:
        """Parse DcmDspClearDtcNotification configuration."""
        assert self.root is not None

        containers = self._find_containers("DcmDspClearDTCNotification")
        if not containers:
            containers = self._find_containers("DcmDspClearDtcNotification")
        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue
            notif_class = self._get_param_value_text(
                container, "DcmDspClearDTCNotificationClass"
            ) or self._get_param_value_text(
                container, "DcmDspClearDtcNotificationType"
            )
            spec.clear_dtc_notifications.append(
                ClearDtcNotification(short_name=sn, notification_class=notif_class)
            )
            logger.debug("  ClearDTC notify: %s (%s)", sn, notif_class)

    def _parse_dynamic_dids(self, spec: UdsSpecification) -> None:
        """Parse DcmDspDynamicDid definitions (service 0x2C)."""
        assert self.root is not None

        for tag in ("DcmDspDynamicDid", "DcmDspDDDID"):
            containers = self._find_containers(tag)
            for container in containers:
                sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
                if not sn or sn == tag:
                    # Top-level wrapper — iterate sub-containers
                    subs = _xpath(
                        container,
                        "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                        self.ns,
                    )
                    for sub in subs:
                        self._parse_single_dynamic_did(sub, spec)
                    continue
                self._parse_single_dynamic_did(container, spec)

    def _parse_single_dynamic_did(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DynamicDid entry."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return

        did_id = self._get_param_value_int(container, "DcmDspDDDIDIdentifier")
        if did_id == 0:
            did_id = self._get_param_value_int(container, "DcmDspDynamicDidIdentifier")
        max_src = self._get_param_value_int(
            container, "DcmDspDDDIDMaxNumberOfSourceElements"
        )
        if max_src == 0:
            max_src = self._get_param_value_int(
                container, "DcmDspDynamicDidMaxNumberOfSourceElements"
            )
        sessions = self._get_ref_list(container, "DcmDspDDDIDSessionRef")
        if not sessions:
            sessions = self._get_ref_list(container, "DcmDspDynamicDidSessionRef")
        security = self._get_ref_list(container, "DcmDspDDDIDSecurityLevelRef")
        if not security:
            security = self._get_ref_list(container, "DcmDspDynamicDidSecurityLevelRef")

        dyn_did = DynamicDidDefinition(
            short_name=sn,
            did_id=did_id,
            max_number_of_source_elements=max_src,
            supported_sessions=sessions,
            required_security_levels=security,
        )
        spec.dynamic_dids.append(dyn_did)
        logger.debug(
            "  DynamicDID: %s (0x%04X), max_src=%d",
            sn,
            did_id,
            max_src,
        )

    def _parse_general_config(self, spec: UdsSpecification) -> None:
        """Parse DcmGeneral configuration parameters."""
        assert self.root is not None

        for tag in ("DcmGeneral", "DcmConfigSet"):
            containers = self._find_containers(tag)
            for container in containers:
                period = self._get_param_value_float(
                    container, "DcmModuleMainFunctionPeriod"
                )
                if period > 0.0:
                    spec.module_main_function_period = period
                fim = self._get_param_value_bool(
                    container, "DcmEnableFimTrigger"
                )
                if fim:
                    spec.enable_fim_trigger = fim
                det = self._get_param_value_bool(
                    container, "DcmDevErrorDetect"
                )
                if det:
                    spec.dev_error_detect = det
                ver = self._get_param_value_bool(
                    container, "DcmVersionInfoApi"
                )
                if ver:
                    spec.version_info_api = ver
                task = self._get_param_value_float(
                    container, "DcmTaskTime"
                )
                if task > 0.0:
                    spec.task_time = task
                rall = self._get_param_value_text(
                    container, "DcmRespondAllRequest"
                )
                if rall.lower() in ("false", "0", "off"):
                    spec.respond_all_request = False

    def _parse_cdtc_and_clear_dtc_group(self, spec: UdsSpecification) -> None:
        """Parse CDTC status mask and ClearDTC group from DcmDsp."""
        assert self.root is not None

        for tag in ("DcmDspCDTC", "DcmDspControlDtcStatusMask"):
            containers = self._find_containers(tag)
            for container in containers:
                mask = self._get_param_value_int(
                    container, "DcmDspCDTCStatusMask"
                )
                if mask == 0:
                    mask = self._get_param_value_int(
                        container, "DcmDspControlDtcStatusMask"
                    )
                if mask > 0:
                    spec.cdtc_status_mask = mask

        for tag in ("DcmDspClearDTC", "DcmDspClearDTCGroup"):
            containers = self._find_containers(tag)
            for container in containers:
                grp = self._get_param_value_int(
                    container, "DcmDspClearDTCGroup"
                )
                if grp > 0:
                    spec.clear_dtc_group = grp

    def _parse_memory_config(self, spec: UdsSpecification) -> None:
        """Parse DcmDspMemory global config (compression, encrypting)."""
        assert self.root is not None

        for tag in ("DcmDspMemory", "DcmDsp"):
            containers = self._find_containers(tag)
            for container in containers:
                comp = self._get_param_value_text(
                    container, "DcmDspMemoryCompressionMethod"
                )
                if comp:
                    spec.memory_compression_method = comp
                enc = self._get_param_value_text(
                    container, "DcmDspMemoryEncryptingMethod"
                )
                if enc:
                    spec.memory_encrypting_method = enc

    def _parse_max_block_length(self, spec: UdsSpecification) -> None:
        """Parse DcmDspMaxBlockLength — max block size for Upload/Download (ISO 14229-1 §13)."""
        assert self.root is not None

        for tag in ("DcmDspMemory", "DcmDsp"):
            containers = self._find_containers(tag)
            for container in containers:
                val = self._get_param_value_int(container, "DcmDspMaxBlockLength")
                if val > 0:
                    spec.max_block_length = val
                    logger.debug("  MaxBlockLength: %d bytes", val)
                    return

    def _parse_link_control_baudrates(self, spec: UdsSpecification) -> None:
        """Parse LinkControl (0x87) supported baud rates — ISO 14229-1 §9.10."""
        assert self.root is not None

        seen: set[str] = set()
        for baudrate_type, param_name in [
            ("FIXED",    "DcmDspLinkControlFixedBaudRateRecord"),
            ("SPECIFIC", "DcmDspLinkControlSpecBaudrateRecord"),
        ]:
            for tag in (
                "DcmDspLinkControlFixedBaudRate",
                "DcmDspLinkControlSpecificBaudRate",
                "DcmDspLinkControl",
            ):
                containers = self._find_containers(tag)
                for container in containers:
                    sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
                    if sn == tag:
                        subs = _xpath(
                            container,
                            "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                            self.ns,
                        )
                        for sub in subs:
                            sub_sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
                            if sub_sn and sub_sn not in seen:
                                val = self._get_param_value_int(sub, param_name)
                                if val > 0:
                                    seen.add(sub_sn)
                                    spec.link_control_baudrates.append(
                                        LinkControlBaudrateEntry(
                                            short_name=sub_sn,
                                            baudrate_type=baudrate_type,
                                            baudrate_value=val,
                                        )
                                    )
                    else:
                        if sn and sn not in seen:
                            val = self._get_param_value_int(container, param_name)
                            if val > 0:
                                seen.add(sn)
                                spec.link_control_baudrates.append(
                                    LinkControlBaudrateEntry(
                                        short_name=sn,
                                        baudrate_type=baudrate_type,
                                        baudrate_value=val,
                                    )
                                )

        if spec.link_control_baudrates:
            logger.debug("  LinkControl baud rates: %d entries", len(spec.link_control_baudrates))

    def _parse_dtc_groups(self, spec: UdsSpecification) -> None:
        """Parse DcmDspGroupOfDTC containers — named DTC groups (ISO 14229-1 §11)."""
        assert self.root is not None

        seen: set[str] = set()
        for tag in ("DcmDspGroupOfDTC",):
            containers = self._find_containers(tag)
            for container in containers:
                sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
                if not sn or sn == tag:
                    subs = _xpath(
                        container,
                        "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                        self.ns,
                    )
                    for sub in subs:
                        self._parse_single_dtc_group(sub, spec, seen)
                    continue
                self._parse_single_dtc_group(container, spec, seen)

    def _parse_single_dtc_group(
        self, container: etree._Element, spec: UdsSpecification, seen: set[str]
    ) -> None:
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn in seen:
            return
        seen.add(sn)
        group_val = self._get_param_value_int(container, "DcmDspGroupOfDTCIdentifier")
        if group_val == 0:
            group_val = self._get_param_value_int(container, "DcmDspGroupOfDTCValue")
        spec.dtc_groups.append(DtcGroup(short_name=sn, group_value=group_val))
        logger.debug("  DTC Group: %s = 0x%06X", sn, group_val)

    def _parse_multi_client(self, spec: UdsSpecification) -> None:
        """Parse multi-client / multi-protocol configuration (ISO 14229-1 Annex D).

        Extracts multiple DcmDslProtocolRow entries and their DcmDslConnection
        sub-containers to represent per-client protocol configurations.
        """
        assert self.root is not None

        proto_containers: list = []
        for path in [
            ".//ar:ECUC-CONTAINER-VALUE[starts-with(ar:SHORT-NAME,'DcmDslProtocolRow')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DcmDslProtocolRow')]",
        ]:
            proto_containers = _xpath(self.root, path, self.ns)
            if proto_containers:
                break

        for proto in proto_containers:
            sn = _xpath_text(proto, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue

            # If this is the wrapper container, look inside for individual rows
            if sn == "DcmDslProtocolRow":
                subs = _xpath(
                    proto, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    self._parse_single_protocol_row(sub, spec)
                continue

            self._parse_single_protocol_row(proto, spec)

        if len(spec.protocol_rows) > 0:
            logger.debug("  Multi-Client: %d protocol rows", len(spec.protocol_rows))

    def _parse_single_protocol_row(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DcmDslProtocolRow container."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn == "DcmDslProtocolRow":
            return

        ptype = self._get_param_value_text(container, "DcmDslProtocolType")
        priority = self._get_param_value_int(container, "DcmDslProtocolPriority")
        preempt = self._get_param_value_float(container, "DcmDslProtocolPreemptTimeout")
        trans_type = self._get_param_value_text(container, "DcmDslProtocolTransType")
        max_resp = self._get_param_value_int(
            container, "DcmDslProtocolMaximumResponseLength"
        )

        # Parse connections within this protocol row
        connections: list[DslConnection] = []
        for conn_path in [
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DcmDslConnection')]",
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'Connection')]",
        ]:
            conn_containers = _xpath(container, conn_path, self.ns)
            for conn in conn_containers:
                conn_sn = _xpath_text(conn, "ar:SHORT-NAME", self.ns)
                if not conn_sn:
                    continue

                rx_addr = ""
                tx_addr = ""
                # Extract CAN IDs from numerical params
                for param_path in [
                    ".//ar:ECUC-NUMERICAL-PARAM-VALUE",
                    ".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE",
                ]:
                    params = _xpath(conn, param_path, self.ns)
                    for param in params:
                        def_ref = _xpath_text(
                            param, "ar:DEFINITION-REF", self.ns
                        )
                        value = _xpath_text(param, "ar:VALUE", self.ns)
                        if not def_ref or not value:
                            continue
                        if "RxPduId" in def_ref or "RxAddr" in def_ref:
                            rx_addr = value
                        elif "TxPduId" in def_ref or "TxAddr" in def_ref:
                            tx_addr = value

                conn_mode = self._get_param_value_text(
                    conn, "DcmDslConnectionMode"
                )
                end_type = self._get_param_value_text(
                    conn, "DcmDslConnectionDcmEndOfConnectionType"
                )

                connections.append(DslConnection(
                    short_name=conn_sn,
                    rx_addr=rx_addr,
                    tx_addr=tx_addr,
                    connection_mode=conn_mode,
                    end_of_connection_type=end_type,
                ))

        row = ProtocolRow(
            short_name=sn,
            protocol_type=ptype,
            priority=priority,
            preempt_timeout=preempt,
            trans_type=trans_type,
            max_response_length=max_resp,
            connections=connections,
        )
        spec.protocol_rows.append(row)
        logger.debug(
            "  ProtocolRow: %s (type=%s, prio=%d, %d conns)",
            sn, ptype, priority, len(connections),
        )

    def _parse_authentication(self, spec: UdsSpecification) -> None:
        """Parse Authentication service (0x29) configuration — ISO 14229-1:2020 §9.6."""
        assert self.root is not None

        containers = self._find_containers("DcmDspAuthentication")
        if not containers:
            return

        for container in containers:
            sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue

            role = self._get_param_value_text(container, "DcmDspAuthenticationRole")
            cert_id = self._get_param_value_text(container, "DcmDspAuthenticationCertificateId")
            psk = self._get_param_value_text(container, "DcmDspAuthenticationPSKIdentity")
            max_att = self._get_param_value_int(
                container, "DcmDspAuthenticationNumMaxAuthAttempts"
            )
            delay = self._get_param_value_float(
                container, "DcmDspAuthenticationDelayTime"
            )
            sessions = self._get_ref_list(container, "DcmDspAuthenticationSessionRef")
            security = self._get_ref_list(container, "DcmDspAuthenticationSecurityLevelRef")

            # Parse white-list of services allowed after authentication
            white_list: list[str] = []
            wl_refs = self._get_ref_list(container, "DcmDspAuthenticationWhiteListServiceRef")
            if wl_refs:
                white_list = wl_refs
            else:
                # Try sub-containers for white-list entries
                wl_containers = _xpath(
                    container,
                    ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'WhiteList')]",
                    self.ns,
                )
                for wl in wl_containers:
                    wl_sn = _xpath_text(wl, "ar:SHORT-NAME", self.ns)
                    if wl_sn:
                        white_list.append(wl_sn)

            spec.authentication_config = AuthenticationConfig(
                short_name=sn,
                role=role,
                white_list=white_list,
                certificate_id=cert_id,
                psk_identity=psk,
                num_max_attempts=max_att,
                delay_time=delay,
                supported_sessions=sessions,
                required_security_levels=security,
            )
            logger.debug(
                "  Authentication: %s (role=%s, max_attempts=%d)",
                sn, role, max_att,
            )
            break  # only one authentication config

    def _parse_access_timing(self, spec: UdsSpecification) -> None:
        """Parse access timing parameter rows — ISO 14229-2 / DcmDspTimingRow."""
        assert self.root is not None

        for tag in ("DcmDspTimingRow", "DcmDspTiming"):
            containers = self._find_containers(tag)
            for container in containers:
                sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
                if not sn or sn in (tag,):
                    subs = _xpath(
                        container,
                        "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                        self.ns,
                    )
                    for sub in subs:
                        self._parse_single_timing_row(sub, spec)
                    continue
                self._parse_single_timing_row(container, spec)

    def _parse_single_timing_row(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single access timing row."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return

        p2 = self._get_param_value_float(container, "DcmDspTimingP2ServerMax", 0.0)
        if p2 == 0.0:
            p2 = self._get_param_value_float(container, "DcmTimingP2ServerMax", 0.05)
        p2_star = self._get_param_value_float(
            container, "DcmDspTimingP2StarServerMax", 0.0
        )
        if p2_star == 0.0:
            p2_star = self._get_param_value_float(
                container, "DcmTimingP2StarServerMax", 5.0
            )
        s3 = self._get_param_value_float(container, "DcmDspTimingS3Server", 0.0)
        if s3 == 0.0:
            s3 = self._get_param_value_float(container, "DcmTimingS3Server", 5.0)
        timing_type = self._get_param_value_text(
            container, "DcmDspTimingType"
        ) or self._get_param_value_text(container, "DcmTimingType")

        row = AccessTimingRow(
            short_name=sn,
            p2_server_max=p2,
            p2_star_server_max=p2_star,
            s3_server=s3,
            timing_type=timing_type,
        )
        spec.access_timing_rows.append(row)
        logger.debug(
            "  TimingRow: %s (P2=%.3fs, P2*=%.3fs, S3=%.3fs)",
            sn, p2, p2_star, s3,
        )

    # ---- DEM (Diagnostic Event Manager) parsing ----

    def _parse_dem_general(self, spec: UdsSpecification) -> None:
        """Parse DemGeneral container."""
        assert self.root is not None
        containers = self._find_containers("DemGeneral")
        if not containers:
            return
        c = containers[0]
        spec.dem_general = DemGeneralConfig(
            status_bit_storage_test_failed=self._get_param_value_bool(
                c, "DemStatusBitStorageTestFailed", True
            ),
            status_bit_handling_tfslc=self._get_param_value_text(
                c, "DemStatusBitHandlingTestFailedSinceLastClear"
            ),
            reset_confirmed_bit_on_overflow=self._get_param_value_bool(
                c, "DemResetConfirmedBitOnOverflow", True
            ),
            operation_cycle_status_storage=self._get_param_value_bool(
                c, "DemOperationCycleStatusStorage"
            ),
            suppression_support=self._get_param_value_bool(
                c, "DemSuppressionSupport"
            ),
            availability_support=self._get_param_value_bool(
                c, "DemAvailabilitySupport"
            ),
            trigger_fim_reports=self._get_param_value_bool(
                c, "DemTriggerFiMReports"
            ),
            type_of_dtc_supported=self._get_param_value_text(
                c, "DemTypeOfDTCSupported"
            ),
            clear_dtc_limitation=self._get_param_value_text(
                c, "DemClearDTCLimitation"
            ),
        )

        # ---- DTC status availability mask (ISO 14229-1 §11.3.5.2.2) ----
        # Vendor parameter (when present) takes precedence over derivation.
        mask = self._get_param_value_int(c, "DemDtcStatusAvailabilityMask", 0)
        if mask == 0:
            mask = self._get_param_value_int(c, "DemStatusAvailabilityMask", 0)
        if mask == 0:
            from udsxml2tex.dem_parser import derive_dtc_status_availability_mask
            mask = derive_dtc_status_availability_mask(
                op_cycle_status_storage=self._get_param_value_bool(
                    c, "DemOperationCycleStatusStorage", False
                ),
                tfslc_handling=self._get_param_value_text(
                    c, "DemStatusBitHandlingTestFailedSinceLastClear"
                ),
                has_indicators=bool(
                    spec.dem_indicators or self._find_containers("DemIndicator")
                ),
            )
        spec.dem_general.dtc_status_availability_mask = mask
        if mask and spec.dtc_status_availability_mask == 0xFF:
            spec.dtc_status_availability_mask = mask

        # ---- DTC severity availability mask (ISO 14229-1 §C.3.1) ----
        sev_mask = self._get_param_value_int(c, "DemDTCSeverityAvailabilityMask", 0)
        spec.dem_general.dtc_severity_availability_mask = sev_mask

        # ---- DTC format identifier (ISO 14229-1 §11.3.6) ----
        from udsxml2tex.dem_parser import DemParser as _DP
        spec.dem_general.dtc_format_identifier = _DP._dtc_format_id(
            spec.dem_general.type_of_dtc_supported
        )

        logger.debug("DEM General: status_bit_storage_tf=%s, mask=0x%02X",
                      spec.dem_general.status_bit_storage_test_failed, mask)

    def _parse_dem_operation_cycles(self, spec: UdsSpecification) -> None:
        """Parse DemOperationCycle containers."""
        assert self.root is not None
        containers = self._find_containers("DemOperationCycle")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DemOperationCycle":
                # Wrapper container; parse sub-containers
                subs = _xpath(
                    c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    self._parse_single_dem_operation_cycle(sub, spec)
                continue
            self._parse_single_dem_operation_cycle(c, spec)

    def _parse_single_dem_operation_cycle(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DemOperationCycle."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return
        cycle = DemOperationCycle(
            short_name=sn,
            cycle_id=self._get_param_value_int(container, "DemOperationCycleId"),
            cycle_type=self._get_param_value_text(container, "DemOperationCycleType"),
            autostart=self._get_param_value_bool(container, "DemOperationCycleAutostart"),
        )
        spec.dem_operation_cycles.append(cycle)
        logger.debug("  DEM OpCycle: %s (id=%d, type=%s)",
                      sn, cycle.cycle_id, cycle.cycle_type)

    def _parse_dem_event_parameters(self, spec: UdsSpecification) -> None:
        """Parse DemEventParameter containers."""
        assert self.root is not None
        containers = self._find_containers("DemEventParameter")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DemEventParameter":
                subs = _xpath(
                    c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    self._parse_single_dem_event_param(sub, spec)
                continue
            self._parse_single_dem_event_param(c, spec)

    def _parse_single_dem_event_param(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DemEventParameter."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn in ("DemEventParameter",):
            return

        # Parse debounce algorithm sub-container
        debounce = self._parse_dem_debounce(container)

        # Parse operation cycle reference (extract short name from ref path)
        op_cycle_ref = self._get_param_ref(container, "DemOperationCycleRef")
        op_cycle_name = op_cycle_ref.rsplit("/", 1)[-1] if op_cycle_ref else ""

        # Parse DTC reference
        dtc_ref = self._get_param_ref(container, "DemDTCRef")
        dtc_name = dtc_ref.rsplit("/", 1)[-1] if dtc_ref else ""

        # Parse indicator references
        indicator_refs = self._get_ref_list(container, "DemIndicatorRef")

        # Parse enable/storage condition group refs
        ec_ref = self._get_param_ref(container, "DemEnableConditionGroupRef")
        ec_name = ec_ref.rsplit("/", 1)[-1] if ec_ref else ""
        sc_ref = self._get_param_ref(container, "DemStorageConditionGroupRef")
        sc_name = sc_ref.rsplit("/", 1)[-1] if sc_ref else ""

        evt = DemEventParameter(
            short_name=sn,
            event_id=self._get_param_value_int(container, "DemEventId"),
            event_kind=self._get_param_value_text(container, "DemEventKind"),
            confirmation_threshold=self._get_param_value_int(
                container, "DemEventConfirmationThreshold", 1
            ),
            operation_cycle_ref=op_cycle_name,
            enable_condition_group_ref=ec_name,
            storage_condition_group_ref=sc_name,
            dtc_ref=dtc_name,
            debounce=debounce,
            indicator_refs=indicator_refs,
            recoverable_in_same_cycle=self._get_param_value_bool(
                container, "DemEventRecoverableInSameOperationCycle", True
            ),
            report_behavior=self._get_param_value_text(
                container, "DemReportBehavior"
            ),
            ff_prestorage_supported=self._get_param_value_bool(
                container, "DemFFPrestorageSupported"
            ),
        )
        spec.dem_event_parameters.append(evt)
        logger.debug("  DEM Event: %s (id=%d, dtc=%s)", sn, evt.event_id, dtc_name)

    def _parse_dem_debounce(
        self, container: etree._Element
    ) -> Optional[DemDebounceConfig]:
        """Parse DemDebounceAlgorithmClass sub-container."""
        # Find the debounce choice container
        debounce_containers = _xpath(
            container,
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DemDebounce')]",
            self.ns,
        )
        if not debounce_containers:
            return None

        dc = debounce_containers[0]
        sn = _xpath_text(dc, "ar:SHORT-NAME", self.ns) or ""

        if "CounterBased" in sn:
            algo = "COUNTER_BASED"
        elif "TimeBase" in sn:
            algo = "TIME_BASED"
        elif "MonitorInternal" in sn:
            algo = "MONITOR_INTERNAL"
        else:
            algo = sn

        return DemDebounceConfig(
            algorithm=algo,
            counter_failed_threshold=self._get_param_value_int(
                dc, "DemDebounceCounterFailedThreshold", 127
            ),
            counter_passed_threshold=self._get_param_value_int(
                dc, "DemDebounceCounterPassedThreshold", -128
            ),
            counter_increment_step=self._get_param_value_int(
                dc, "DemDebounceCounterIncrementStepSize", 1
            ),
            counter_decrement_step=self._get_param_value_int(
                dc, "DemDebounceCounterDecrementStepSize", 1
            ),
            counter_jump_up=self._get_param_value_bool(
                dc, "DemDebounceCounterJumpUp"
            ),
            counter_jump_down=self._get_param_value_bool(
                dc, "DemDebounceCounterJumpDown"
            ),
            counter_storage=self._get_param_value_bool(
                dc, "DemDebounceCounterStorage"
            ),
            time_failed_threshold=self._get_param_value_float(
                dc, "DemDebounceTimeFailedThreshold", 0.0
            ),
            time_passed_threshold=self._get_param_value_float(
                dc, "DemDebounceTimePassedThreshold", 0.0
            ),
        )

    def _parse_dem_indicators(self, spec: UdsSpecification) -> None:
        """Parse DemIndicator containers."""
        assert self.root is not None
        containers = self._find_containers("DemIndicator")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn == "DemIndicator":
                subs = _xpath(
                    c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    self._parse_single_dem_indicator(sub, spec)
                continue
            self._parse_single_dem_indicator(c, spec)

    def _parse_single_dem_indicator(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DemIndicator."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn or sn in ("DemIndicator",):
            return

        ind = DemIndicatorConfig(
            short_name=sn,
            indicator_id=self._get_param_value_int(container, "DemIndicatorId"),
            behaviour=self._get_param_value_text(container, "DemIndicatorBehaviour"),
            failure_cycle_counter_threshold=self._get_param_value_int(
                container, "DemIndicatorFailureCycleCounterThreshold"
            ),
            healing_cycle_counter_threshold=self._get_param_value_int(
                container, "DemIndicatorHealingCycleCounterThreshold"
            ),
        )
        spec.dem_indicators.append(ind)
        logger.debug("  DEM Indicator: %s (id=%d)", sn, ind.indicator_id)

    def _parse_dem_enable_conditions(self, spec: UdsSpecification) -> None:
        """Parse DemEnableCondition containers."""
        assert self.root is not None
        containers = self._find_containers("DemEnableCondition")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn in ("DemEnableCondition", "DemEnableConditionGroup"):
                subs = _xpath(
                    c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    sub_sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
                    if sub_sn and "Group" not in sub_sn:
                        self._parse_single_dem_enable_condition(sub, spec)
                continue
            if "Group" in sn:
                continue
            self._parse_single_dem_enable_condition(c, spec)

    def _parse_single_dem_enable_condition(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DemEnableCondition."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return
        ec = DemEnableCondition(
            short_name=sn,
            condition_id=self._get_param_value_int(container, "DemEnableConditionId"),
            initial_status=self._get_param_value_bool(
                container, "DemEnableConditionStatus", True
            ),
        )
        spec.dem_enable_conditions.append(ec)
        logger.debug("  DEM EnableCond: %s (id=%d)", sn, ec.condition_id)

    def _parse_dem_storage_conditions(self, spec: UdsSpecification) -> None:
        """Parse DemStorageCondition containers."""
        assert self.root is not None
        containers = self._find_containers("DemStorageCondition")
        for c in containers:
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns)
            if not sn or sn in ("DemStorageCondition", "DemStorageConditionGroup"):
                subs = _xpath(
                    c, "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
                )
                for sub in subs:
                    sub_sn = _xpath_text(sub, "ar:SHORT-NAME", self.ns)
                    if sub_sn and "Group" not in sub_sn:
                        self._parse_single_dem_storage_condition(sub, spec)
                continue
            if "Group" in sn:
                continue
            self._parse_single_dem_storage_condition(c, spec)

    def _parse_single_dem_storage_condition(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DemStorageCondition."""
        sn = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not sn:
            return
        ref = self._get_param_ref(container, "DemStorageConditionReplacementEventRef")
        sc = DemStorageCondition(
            short_name=sn,
            condition_id=self._get_param_value_int(
                container, "DemStorageConditionId"
            ),
            initial_status=self._get_param_value_bool(
                container, "DemStorageConditionStatus", True
            ),
            replacement_event_ref=ref.rsplit("/", 1)[-1] if ref else "",
        )
        spec.dem_storage_conditions.append(sc)
        logger.debug("  DEM StorageCond: %s (id=%d)", sn, sc.condition_id)

    def _parse_dem_event_memories(self, spec: UdsSpecification) -> None:
        """Parse DemEventMemorySet / DemPrimaryMemory / DemUserDefinedMemory."""
        assert self.root is not None

        # Parse DemPrimaryMemory
        for c in self._find_containers("DemPrimaryMemory"):
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns) or "PrimaryMemory"
            mem = DemEventMemoryConfig(
                short_name=sn,
                memory_type="PRIMARY",
                max_number_event_entries=self._get_param_value_int(
                    c, "DemMaxNumberEventEntryPrimary"
                ),
                displacement_strategy=self._get_param_value_text(
                    c, "DemEventDisplacementStrategy"
                ),
                occurrence_counter_processing=self._get_param_value_text(
                    c, "DemOccurrenceCounterProcessing"
                ),
                event_memory_entry_storage_trigger=self._get_param_value_text(
                    c, "DemEventMemoryEntryStorageTrigger"
                ),
                freeze_frame_record_trigger=self._get_param_value_text(
                    c, "DemFreezeFrameRecordTrigger"
                ),
                extended_data_record_trigger=self._get_param_value_text(
                    c, "DemExtendedDataRecordTrigger"
                ),
                type_of_freeze_frame_record_numeration=self._get_param_value_text(
                    c, "DemTypeOfFreezeFrameRecordNumeration"
                ),
                max_number_freeze_frame_records=self._get_param_value_int(
                    c, "DemMaxNumberFreezeFrameRecords"
                ),
            )
            spec.dem_event_memories.append(mem)
            logger.debug("  DEM Memory: %s (max=%d)", sn,
                          mem.max_number_event_entries)

        # Parse DemUserDefinedMemory
        for c in self._find_containers("DemUserDefinedMemory"):
            sn = _xpath_text(c, "ar:SHORT-NAME", self.ns) or "UserDefinedMemory"
            mem = DemEventMemoryConfig(
                short_name=sn,
                memory_type="USER_DEFINED",
                max_number_event_entries=self._get_param_value_int(
                    c, "DemMaxNumberEventEntryUserDefined"
                ),
                displacement_strategy=self._get_param_value_text(
                    c, "DemEventDisplacementStrategy"
                ),
                occurrence_counter_processing=self._get_param_value_text(
                    c, "DemOccurrenceCounterProcessing"
                ),
                event_memory_entry_storage_trigger=self._get_param_value_text(
                    c, "DemEventMemoryEntryStorageTrigger"
                ),
                freeze_frame_record_trigger=self._get_param_value_text(
                    c, "DemFreezeFrameRecordTrigger"
                ),
                extended_data_record_trigger=self._get_param_value_text(
                    c, "DemExtendedDataRecordTrigger"
                ),
                type_of_freeze_frame_record_numeration=self._get_param_value_text(
                    c, "DemTypeOfFreezeFrameRecordNumeration"
                ),
                max_number_freeze_frame_records=self._get_param_value_int(
                    c, "DemMaxNumberFreezeFrameRecords"
                ),
            )
            spec.dem_event_memories.append(mem)
            logger.debug("  DEM Memory: %s (type=USER_DEFINED)", sn)

    # ---- New methods: version detection, NRC, XSD validation, path resolution, cache ----

    def _detect_arxml_version(self, root: etree._Element) -> str:
        """Detect AUTOSAR schema version from root element namespace."""
        return _detect_arxml_version(root)

    def _extract_nrc_description_from_arxml(self, nrc_el: etree._Element) -> str:
        """Extract NRC description from DESC/L-2 elements in an ARXML NRC container."""
        desc = (
            _xpath_text(nrc_el, "ar:DESC/ar:L-2", self.ns)
            or _xpath_text(nrc_el, "ar:LONG-NAME/ar:L-4X", self.ns)
            or _xpath_text(nrc_el, "ar:LONG-NAME", self.ns)
        )
        return desc

    def validate_against_xsd(
        self,
        xml_path: "str | Path",
        xsd_path: "Optional[str | Path]" = None,
    ) -> list[str]:
        """Validate an ARXML file against its XSD schema.

        If xsd_path is None, attempts to find the schema URL from the XML
        noNamespaceSchemaLocation or schemaLocation attribute.

        Returns a list of error strings (empty = valid).
        """
        from pathlib import Path as _Path

        xml_path = _Path(xml_path)
        errors: list[str] = []

        try:
            xml_doc = etree.parse(str(xml_path))
        except etree.XMLSyntaxError as e:
            return [f"XML syntax error: {e}"]

        if xsd_path is None:
            # Try to extract schema location from XML
            root = xml_doc.getroot()
            schema_loc = root.get(
                "{http://www.w3.org/2001/XMLSchema-instance}schemaLocation", ""
            ) or root.get(
                "{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation",
                "",
            )
            if schema_loc:
                # schemaLocation format: "namespace url namespace url ..."
                parts = schema_loc.split()
                for part in parts:
                    if part.endswith(".xsd") or ".xsd" in part:
                        xsd_path = part
                        break
            if xsd_path is None:
                return [
                    "No XSD schema location found in document; "
                    "provide xsd_path explicitly"
                ]

        try:
            xsd_doc = etree.parse(str(xsd_path))
            schema = etree.XMLSchema(xsd_doc)
            schema.validate(xml_doc)
            for error in schema.error_log:
                errors.append(f"Line {error.line}: {error.message}")
        except (etree.XMLSchemaParseError, OSError) as e:
            errors.append(f"Schema error: {e}")

        return errors

    def _resolve_autosar_path(
        self, root: etree._Element, path: str
    ) -> Optional[etree._Element]:
        """Resolve a full AUTOSAR path like /Package/SubPackage/Element.

        Returns the lxml element if found, None otherwise.
        """
        if not path.startswith("/"):
            return None
        parts = [p for p in path.split("/") if p]
        current: etree._Element = root
        for part in parts:
            found = None
            for el in current:
                sn = (
                    el.find(f"{{{self.ns.get('ar', '')}}}SHORT-NAME")
                    if self.ns
                    else el.find("SHORT-NAME")
                )
                if sn is not None and sn.text == part:
                    found = el
                    break
            if found is None:
                return None
            current = found
        return current

    def _build_path_index(self, root: etree._Element) -> dict[str, object]:
        """Scan the entire ARXML tree once and build a dict of AUTOSAR path -> element.

        The result is stored as ``self._path_index`` for fast DEFINITION-REF /
        BASE-REF lookups.
        """
        index: dict[str, object] = {}
        ns_uri = self.ns.get("ar", "")
        sn_tag = f"{{{ns_uri}}}SHORT-NAME" if ns_uri else "SHORT-NAME"

        def _walk(el: etree._Element, prefix: str) -> None:
            sn_el = el.find(sn_tag)
            if sn_el is None or not sn_el.text:
                return
            current_path = prefix + "/" + sn_el.text
            index[current_path] = el
            for child in el:
                _walk(child, current_path)

        for child in root:
            _walk(child, "")

        self._path_index = index
        return index

    def _get_cache_key(self, path: "str | Path") -> str:
        """Return cache key: first 16 hex chars of sha256 of file content."""
        from pathlib import Path as _Path

        content = _Path(path).read_bytes()
        return hashlib.sha256(content).hexdigest()[:16]

    def _load_from_cache(
        self,
        cache_key: str,
        cache_dir: "str | Path",
    ) -> Optional[UdsSpecification]:
        """Load a UdsSpecification from the pickle cache, or return None."""
        from pathlib import Path as _Path

        cache_file = _Path(cache_dir) / f"{cache_key}.pkl"
        if cache_file.exists():
            try:
                with open(cache_file, "rb") as f:
                    return pickle.load(f)
            except Exception:
                return None
        return None

    def _save_to_cache(
        self,
        spec: UdsSpecification,
        cache_key: str,
        cache_dir: "str | Path",
    ) -> None:
        """Persist a UdsSpecification to the pickle cache."""
        from pathlib import Path as _Path

        cache_dir_p = _Path(cache_dir)
        cache_dir_p.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir_p / f"{cache_key}.pkl"
        try:
            with open(cache_file, "wb") as f:
                pickle.dump(spec, f, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception as e:
            logger.debug("Failed to write cache: %s", e)

    def parse_streaming(
        self, xml_path: "str | Path", show_progress: bool = False
    ) -> UdsSpecification:
        """Parse ARXML using lxml iterparse for large files (lower memory usage).

        Note: Extracts only DID and DTC information in streaming mode.
        For full extraction including sessions, security, etc., use parse() instead.

        Args:
            xml_path: Path to the ARXML file.
            show_progress: When True and tqdm is installed, display a byte-based
                           progress bar; falls back to silent iteration otherwise.
        """
        from pathlib import Path as _Path

        spec = UdsSpecification()
        path_p = _Path(xml_path)
        progress: "object" = _NullProgress()
        if show_progress:
            try:
                from tqdm import tqdm  # type: ignore[import-not-found]
                total_bytes = path_p.stat().st_size
                progress = tqdm(
                    total=total_bytes, desc=f"Streaming {path_p.name}",
                    unit="B", unit_scale=True, leave=False,
                )
            except ImportError:
                progress = _NullProgress()

        # Streaming parse — collect elements as they come
        context = etree.iterparse(
            str(path_p),
            events=("end",),
            recover=True,
        )

        last_pos = 0
        for event, elem in context:
            # Update progress on element close — approximate
            try:
                cur_pos = context.position if hasattr(context, "position") else 0  # type: ignore[attr-defined]
                if cur_pos and cur_pos > last_pos:
                    progress.update(cur_pos - last_pos)  # type: ignore[attr-defined]
                    last_pos = cur_pos
            except Exception:  # noqa: BLE001
                pass
            local = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
            if local == "DcmDspDid":
                sn_el = elem.find("SHORT-NAME")
                if sn_el is None:
                    # Try with namespace
                    for child in elem:
                        cloc = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                        if cloc == "SHORT-NAME":
                            sn_el = child
                            break
                if sn_el is not None and sn_el.text:
                    did_id_el = None
                    for child in elem:
                        cloc = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                        if cloc == "DcmDspDidIdentifier":
                            did_id_el = child
                            break
                    did_id = (
                        int(did_id_el.text, 0)
                        if did_id_el is not None and did_id_el.text
                        else 0
                    )
                    spec.dids.append(Did(short_name=sn_el.text, did_id=did_id))
            elif local == "DcmDspDtc":
                sn_el = None
                dtc_id_el = None
                for child in elem:
                    cloc = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                    if cloc == "SHORT-NAME":
                        sn_el = child
                    elif cloc == "DcmDspDtcValue":
                        dtc_id_el = child
                if sn_el is not None and sn_el.text:
                    dtc_id = (
                        int(dtc_id_el.text, 0)
                        if dtc_id_el is not None and dtc_id_el.text
                        else 0
                    )
                    spec.dtcs.append(
                        DtcDefinition(short_name=sn_el.text, dtc_id=dtc_id)
                    )
            # Clear element to free memory
            elem.clear()
            while elem.getprevious() is not None:
                del elem.getparent()[0]

        progress.close()  # type: ignore[attr-defined]
        return spec

    # ---- Helper methods ----

    def _find_containers(self, name: str) -> list:
        """Find ECUC container values by SHORT-NAME pattern."""
        assert self.root is not None
        results = []

        # Try multiple XPath patterns for different ARXML structures
        patterns = [
            f".//ar:ECUC-CONTAINER-VALUE[ar:SHORT-NAME='{name}']",
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
            f".//ar:CONTAINER[ar:SHORT-NAME='{name}']",
            f".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), '{name}')]",
        ]

        for pattern in patterns:
            found = _xpath(self.root, pattern, self.ns)
            if found:
                results.extend(found)
                break

        return results

    def _get_param_value_int(
        self, container: etree._Element, param_name: str, default: int = 0
    ) -> int:
        """Get integer parameter value from container."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    if text.startswith("0x") or text.startswith("0X"):
                        return int(text, 16)
                    return int(float(text))
                except ValueError:
                    pass
        return default

    def _get_param_value_float(
        self, container: etree._Element, param_name: str, default: float = 0.0
    ) -> float:
        """Get float parameter value from container."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    return float(text)
                except ValueError:
                    pass
        return default

    def _get_param_value_text(
        self, container: etree._Element, param_name: str, default: str = ""
    ) -> str:
        """Get text parameter value from container."""
        for path in [
            f".//ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                return text
        return default

    def _get_param_value_bool(
        self, container: etree._Element, param_name: str, default: bool = False
    ) -> bool:
        """Get boolean parameter value from container."""
        text = self._get_param_value_text(container, param_name)
        if text.lower() in ("true", "1"):
            return True
        if text.lower() in ("false", "0"):
            return False
        return default

    def _get_param_ref(
        self, container: etree._Element, param_name: str
    ) -> Optional[str]:
        """Get a reference parameter value."""
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            if results:
                elem = results[0]
                return elem.text if isinstance(elem, etree._Element) else str(elem)
        return None

    def _get_ref_list(
        self, container: etree._Element, param_name: str
    ) -> list[str]:
        """Get a list of reference names for a parameter."""
        refs: list[str] = []
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            for r in results:
                text = r.text if isinstance(r, etree._Element) else str(r)
                if text:
                    # Extract the last part of the reference path
                    ref_name = text.rsplit("/", 1)[-1]
                    refs.append(ref_name)
        # Remove duplicates caused by overlapping XPath patterns, preserving order
        return list(dict.fromkeys(refs))

    def _get_description(self, container: etree._Element) -> str:
        """Extract a description from standard AUTOSAR elements."""
        # Try DESC/L-2 (AUTOSAR R4)
        for path in [
            "ar:DESC/ar:L-2",
            "ar:ADMIN-DATA/ar:DOC-REVISIONS/ar:DOC-REVISION/ar:DESC/ar:L-2",
            "ar:LONG-NAME/ar:L-4",
            "ar:LABEL/ar:L-4",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text and text.strip():
                return text.strip()
        # Try DcmDspDidDescription textual param
        desc = self._get_param_value_text(container, "Description")
        if desc:
            return desc
        return ""
