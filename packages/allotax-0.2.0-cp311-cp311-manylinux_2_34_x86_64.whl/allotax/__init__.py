from .allotax import *

__doc__ = allotax.__doc__
if hasattr(allotax, "__all__"):
    __all__ = allotax.__all__