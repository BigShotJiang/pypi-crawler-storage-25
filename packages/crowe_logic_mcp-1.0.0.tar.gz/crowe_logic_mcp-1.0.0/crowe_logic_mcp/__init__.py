"""Crowe Logic MCP Server — mycology expertise, photo analysis, grow logs, and SOP generation."""

from crowe_logic_mcp.server import main, mcp

__all__ = ["main", "mcp"]
