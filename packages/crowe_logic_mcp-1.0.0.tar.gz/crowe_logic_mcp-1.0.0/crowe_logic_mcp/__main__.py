"""Allow running as: python -m crowe_logic_mcp"""
from crowe_logic_mcp.server import main

main()
