# crowe-logic-mcp

MCP server for the [Crowe Logic](https://ai.southwestmushrooms.com) platform -- mycology expertise, photo analysis, grow logs, and SOP generation.

## Install

```bash
uvx crowe-logic-mcp
```

## Tools

| Tool | Description |
|------|-------------|
| `crowe_chat` | Chat with CroweLM for mycology and cultivation expertise |
| `crowe_vision` | Analyze cultivation photos (contamination, health, species ID) |
| `crowe_grow_log` | Create, read, update, and list cultivation grow logs |
| `crowe_sop` | Generate Standard Operating Procedures for cultivation tasks |

## Configuration

### Claude Code

```json
{
  "mcpServers": {
    "crowe-logic": {
      "command": "uvx",
      "args": ["crowe-logic-mcp"],
      "env": {
        "CROWE_LOGIC_URL": "https://ai.southwestmushrooms.com",
        "CROWE_LOGIC_KEY": "your-key"
      }
    }
  }
}
```

### Cursor / Windsurf / Gemini CLI

Same pattern -- add `crowe-logic` to your MCP server config with `uvx crowe-logic-mcp`.

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `CROWE_LOGIC_URL` | `https://ai.southwestmushrooms.com` | Platform URL |
| `CROWE_LOGIC_KEY` | (empty) | API key for authenticated access |

## License

MIT
