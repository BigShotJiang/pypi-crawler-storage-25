"""Output guard — filters LLM responses for policy violations and context drift."""

from __future__ import annotations

import logging
import re
import time
from typing import List, Optional, Set

from rag_guard.config import GuardConfig
from rag_guard.detector.prompt_injection import PromptInjectionDetector
from rag_guard.sanitizer.pipeline import SanitizationPipeline
from rag_guard.types import DetectionResult, GuardResult, ThreatType

logger = logging.getLogger("rag_guard.guards.output")

# Patterns indicating the LLM may have been hijacked
HIJACK_INDICATORS = [
    re.compile(r"(?:I|i)\s+(?:have been|was)\s+(?:hacked|compromised|hijacked)", re.IGNORECASE),
    re.compile(r"(?:my|the)\s+(?:previous|original)\s+instructions?\s+(?:were|are|said)", re.IGNORECASE),
    re.compile(r"(?:system|original)\s+prompt\s*(?:is|was|:)", re.IGNORECASE),
    re.compile(r"(?:here|these)\s+(?:are|is)\s+(?:my|the)\s+(?:system|original)\s+(?:instructions?|prompt)", re.IGNORECASE),
]

# Common refusal phrases indicating model detected something wrong
REFUSAL_PATTERNS = [
    re.compile(r"I\s+(?:cannot|can'?t|won'?t|should\s+not)\s+(?:help|assist|do\s+that)", re.IGNORECASE),
    re.compile(r"(?:sorry|apologies),?\s+(?:but\s+)?I\s+(?:cannot|can'?t)", re.IGNORECASE),
]


class OutputGuard:
    """Filters LLM outputs before returning to the user or executing actions.

    Checks:
    - Output doesn't leak system prompt
    - Output isn't hijacked (attacker-chosen content)
    - Output doesn't contain embedded injection for downstream processing
    - Policy compliance (blocklist words, content categories)
    """

    def __init__(
        self,
        config: GuardConfig | None = None,
        blocked_phrases: Optional[Set[str]] = None,
    ) -> None:
        self.config = config or GuardConfig()
        self.sanitizer = SanitizationPipeline(self.config.sanitizer)
        self.injection_detector = PromptInjectionDetector(self.config.detector)
        self.blocked_phrases = blocked_phrases or set()

    def check(
        self,
        output: str,
        user_query: Optional[str] = None,
    ) -> GuardResult:
        """Check LLM output for safety before returning to user.

        Args:
            output: The LLM-generated response text
            user_query: Original user query (for relevance checking)

        Returns:
            GuardResult with allowed=True if safe
        """
        start = time.perf_counter()
        detections: List[DetectionResult] = []

        # Check 1: Hijack indicators
        for pattern in HIJACK_INDICATORS:
            if pattern.search(output):
                detections.append(DetectionResult(
                    flagged=True,
                    score=0.90,
                    threat_type=ThreatType.CONTEXT_DRIFT,
                    reason="hijack_indicator",
                    detector_name="output_guard",
                ))
                break

        # Check 2: Embedded injection in output (for downstream consumption)
        injection_result = self.injection_detector.scan(output)
        if injection_result.flagged:
            detections.append(injection_result)

        # Check 3: Blocked phrases
        output_lower = output.lower()
        for phrase in self.blocked_phrases:
            if phrase.lower() in output_lower:
                detections.append(DetectionResult(
                    flagged=True,
                    score=0.85,
                    threat_type=ThreatType.POLICY_VIOLATION,
                    reason=f"blocked_phrase: {phrase}",
                    detector_name="output_guard",
                ))
                break

        has_threats = any(d.flagged for d in detections)
        elapsed_ms = (time.perf_counter() - start) * 1000

        if has_threats:
            worst = max(detections, key=lambda d: d.score)
            logger.warning("Output flagged: %s", worst.reason)
            return GuardResult(
                allowed=False,
                reason=worst.reason,
                confidence=worst.score,
                suggested_action="block",
                detections=detections,
            )

        return GuardResult(
            allowed=True,
            reason="output_safe",
            confidence=1.0,
            suggested_action="proceed",
            detections=detections,
        )
