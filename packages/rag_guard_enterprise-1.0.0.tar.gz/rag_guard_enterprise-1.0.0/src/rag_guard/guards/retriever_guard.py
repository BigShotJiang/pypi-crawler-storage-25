"""Retriever guard — wraps any retriever to sanitize queries and filter poisoned docs."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol

from rag_guard.config import GuardConfig
from rag_guard.detector.pipeline import DetectionPipeline
from rag_guard.sanitizer.pipeline import SanitizationPipeline
from rag_guard.types import DetectionResult, GuardResult

logger = logging.getLogger("rag_guard.guards.retriever")


@dataclass
class Document:
    """Minimal document representation for framework-agnostic usage."""
    id: str = ""
    text: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    score: float = 0.0
    embedding: Optional[Any] = None


class RetrieverInterface(Protocol):
    """Protocol for any retriever backend (FAISS, Pinecone, Chroma, etc.)."""
    def retrieve(self, query: str, top_k: int = 5) -> List[Document]: ...


class RetrieverGuard:
    """Wraps any retriever to add security checks at retrieval time.

    Pipeline:
    1. Sanitize the query
    2. Detect injection in the query
    3. Forward to underlying retriever
    4. Sanitize each retrieved document
    5. Detect injection in each retrieved document
    6. Filter out flagged documents
    7. Return clean documents + guard result
    """

    def __init__(
        self,
        retriever: Any = None,
        config: GuardConfig | None = None,
    ) -> None:
        self.retriever = retriever
        self.config = config or GuardConfig()
        self.sanitizer = SanitizationPipeline(self.config.sanitizer)
        self.detector = DetectionPipeline(self.config.detector)

    def retrieve(
        self,
        query: str,
        top_k: int = 5,
        retriever: Any = None,
        retrieve_fn: Optional[Callable] = None,
    ) -> GuardResult:
        """Sanitize query → retrieve → sanitize+check docs → return clean.

        Args:
            query: User query string
            top_k: Number of documents to retrieve
            retriever: Override retriever for this call
            retrieve_fn: Callable(query, top_k) -> List[Document] alternative

        Returns:
            GuardResult with allowed docs in details["documents"]
        """
        start = time.perf_counter()
        detections: List[DetectionResult] = []

        # Step 1: Sanitize query
        clean_query = self.sanitizer.sanitize_text(query)

        # Step 2: Detect injection in query
        query_result = self.detector.scan_text(clean_query)
        detections.append(query_result)

        if query_result.flagged:
            logger.warning("Query flagged: %s", query_result.reason)
            if self.config.fail_policy == "closed":
                return GuardResult(
                    allowed=False,
                    reason=f"query_injection: {query_result.reason}",
                    confidence=query_result.score,
                    suggested_action="block",
                    detections=detections,
                )

        # Step 3: Retrieve documents
        active_retriever = retriever or self.retriever
        docs: List[Document] = []

        if retrieve_fn:
            docs = retrieve_fn(clean_query, top_k)
        elif active_retriever is not None:
            if hasattr(active_retriever, "retrieve"):
                docs = active_retriever.retrieve(clean_query, top_k)
            elif callable(active_retriever):
                docs = active_retriever(clean_query, top_k)

        # Steps 4-6: Sanitize and check each document
        clean_docs: List[Document] = []
        quarantined: List[Document] = []

        for doc in docs:
            # Sanitize doc text
            doc.text = self.sanitizer.sanitize_text(doc.text)

            # Detect injection in doc
            doc_result = self.detector.scan_text(doc.text)
            detections.append(doc_result)

            if doc_result.flagged:
                logger.warning(
                    "Document %s flagged: %s", doc.id, doc_result.reason
                )
                quarantined.append(doc)
            else:
                clean_docs.append(doc)

        elapsed_ms = (time.perf_counter() - start) * 1000
        has_threats = any(d.flagged for d in detections)

        return GuardResult(
            allowed=True,
            reason=f"retrieved {len(clean_docs)} clean, quarantined {len(quarantined)}",
            confidence=1.0 - (len(quarantined) / max(len(docs), 1)),
            suggested_action="proceed" if not has_threats else "confirm",
            detections=detections,
        )
