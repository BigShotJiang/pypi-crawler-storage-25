"""Agent guard — validates tool calls and tool outputs against user intent."""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from rag_guard.config import GuardConfig
from rag_guard.detector.prompt_injection import PromptInjectionDetector
from rag_guard.sanitizer.pipeline import SanitizationPipeline
from rag_guard.types import DetectionResult, GuardResult, ThreatType

logger = logging.getLogger("rag_guard.guards.agent")

# Dangerous tool/action patterns
DANGEROUS_ACTIONS = re.compile(
    r"(?:delete|drop|truncate|rm\s+-rf|format|shutdown|kill|exec|eval|os\.system)",
    re.IGNORECASE,
)

SENSITIVE_DATA_PATTERNS = re.compile(
    r"(?:password|secret|api[_-]?key|token|credential|private[_-]?key|ssn|credit[_-]?card)",
    re.IGNORECASE,
)

EXTERNAL_URL_PATTERN = re.compile(
    r"https?://(?!(?:localhost|127\.0\.0\.1|10\.|172\.(?:1[6-9]|2\d|3[01])\.|192\.168\.))",
    re.IGNORECASE,
)


@dataclass
class ToolCall:
    """Represents a tool/function call from an LLM agent."""
    name: str = ""
    arguments: Dict[str, Any] = field(default_factory=dict)
    description: str = ""


class AgentGuard:
    """Validates LLM agent tool calls and outputs for safety.

    Checks:
    - Tool call matches user intent (not hijacked)
    - No destructive actions without confirmation
    - Tool outputs don't contain injection payloads
    - No sensitive data leakage in outputs
    - No unauthorized external requests
    """

    def __init__(self, config: GuardConfig | None = None) -> None:
        self.config = config or GuardConfig()
        self.sanitizer = SanitizationPipeline(self.config.sanitizer)
        self.injection_detector = PromptInjectionDetector(self.config.detector)

    def check_tool_call(
        self,
        user_goal: str,
        action: ToolCall,
    ) -> GuardResult:
        """Validate a proposed tool/API call against user intent.

        Returns GuardResult with allowed=True if safe, or block/confirm.
        """
        start = time.perf_counter()
        detections: List[DetectionResult] = []

        # Check 1: Dangerous action patterns in tool name or arguments
        action_str = f"{action.name} {str(action.arguments)}"
        if DANGEROUS_ACTIONS.search(action_str):
            logger.warning(
                "Dangerous action detected: %s", action.name
            )
            detections.append(DetectionResult(
                flagged=True,
                score=0.95,
                threat_type=ThreatType.TOOL_HIJACK,
                reason=f"dangerous_action: {action.name}",
                detector_name="agent_guard",
            ))
            return GuardResult(
                allowed=False,
                reason=f"Dangerous action requires confirmation: {action.name}",
                confidence=0.95,
                suggested_action="confirm",
                detections=detections,
            )

        # Check 2: Sensitive data in arguments
        args_str = str(action.arguments)
        if SENSITIVE_DATA_PATTERNS.search(args_str):
            logger.warning("Sensitive data in tool arguments: %s", action.name)
            detections.append(DetectionResult(
                flagged=True,
                score=0.80,
                threat_type=ThreatType.POLICY_VIOLATION,
                reason="sensitive_data_in_args",
                detector_name="agent_guard",
            ))

        # Check 3: Unauthorized external URLs
        if EXTERNAL_URL_PATTERN.search(args_str):
            logger.warning("External URL in tool arguments: %s", action.name)
            detections.append(DetectionResult(
                flagged=True,
                score=0.75,
                threat_type=ThreatType.TOOL_HIJACK,
                reason="unauthorized_external_url",
                detector_name="agent_guard",
            ))

        # Check 4: Injection in arguments
        injection_result = self.injection_detector.scan(args_str)
        if injection_result.flagged:
            detections.append(injection_result)

        has_threats = any(d.flagged for d in detections)
        elapsed_ms = (time.perf_counter() - start) * 1000

        if has_threats:
            worst = max(detections, key=lambda d: d.score)
            return GuardResult(
                allowed=False,
                reason=worst.reason,
                confidence=worst.score,
                suggested_action="block" if worst.score > 0.9 else "confirm",
                detections=detections,
            )

        return GuardResult(
            allowed=True,
            reason="tool_call_safe",
            confidence=1.0,
            suggested_action="proceed",
            detections=detections,
        )

    def check_tool_output(
        self,
        user_goal: str,
        output: str,
    ) -> GuardResult:
        """Check tool output for injection payloads or off-topic content.

        Returns GuardResult indicating whether the output is safe to use.
        """
        start = time.perf_counter()
        detections: List[DetectionResult] = []

        # Sanitize output
        clean_output = self.sanitizer.sanitize_text(output)

        # Check for injection in output
        injection_result = self.injection_detector.scan(clean_output)
        detections.append(injection_result)

        # Check for sensitive data leakage
        if SENSITIVE_DATA_PATTERNS.search(clean_output):
            detections.append(DetectionResult(
                flagged=True,
                score=0.80,
                threat_type=ThreatType.POLICY_VIOLATION,
                reason="sensitive_data_in_output",
                detector_name="agent_guard",
            ))

        has_threats = any(d.flagged for d in detections)
        elapsed_ms = (time.perf_counter() - start) * 1000

        if has_threats:
            worst = max(detections, key=lambda d: d.score)
            return GuardResult(
                allowed=False,
                reason=worst.reason,
                confidence=worst.score,
                suggested_action="block",
                detections=detections,
            )

        return GuardResult(
            allowed=True,
            reason="output_safe",
            confidence=1.0,
            suggested_action="proceed",
            detections=detections,
        )
