"""Prompt injection detector — pattern-based + heuristic detection.

Detects direct and indirect prompt injection attempts using:
- Known injection pattern matching
- Instruction-override heuristics
- Structural analysis of text
"""

from __future__ import annotations

import logging
import re
import time
from typing import List, Pattern, Tuple

from rag_guard.config import DetectorConfig
from rag_guard.types import DetectionResult, ThreatType

logger = logging.getLogger("rag_guard.detector.prompt_injection")

# Known prompt injection patterns — compiled at module level
INJECTION_PATTERNS: List[Tuple[Pattern[str], str, float]] = [
    # (pattern, description, severity_score)
    (
        re.compile(r"ignore\s+(all\s+)?previous\s+instructions", re.IGNORECASE),
        "instruction_override",
        0.95,
    ),
    (
        re.compile(r"ignore\s+(all\s+)?above\s+instructions?", re.IGNORECASE),
        "instruction_override",
        0.95,
    ),
    (
        re.compile(r"disregard\s+(all\s+)?previous", re.IGNORECASE),
        "instruction_override",
        0.90,
    ),
    (
        re.compile(r"forget\s+(all\s+)?(?:previous|prior|above)", re.IGNORECASE),
        "instruction_override",
        0.90,
    ),
    (
        re.compile(r"you\s+are\s+now\s+(?:a|an|the)", re.IGNORECASE),
        "role_hijack",
        0.85,
    ),
    (
        re.compile(r"new\s+instructions?\s*:", re.IGNORECASE),
        "instruction_injection",
        0.88,
    ),
    (
        re.compile(r"system\s*(?:prompt|message)\s*:", re.IGNORECASE),
        "system_prompt_leak",
        0.90,
    ),
    (
        re.compile(r"<\s*(?:SUDO|ADMIN|SYSTEM)\s*>", re.IGNORECASE),
        "privilege_escalation",
        0.95,
    ),
    (
        re.compile(r"(?:when|if)\s+asked\s+about\s+.+,?\s*(?:always\s+)?(?:say|answer|respond|reply)", re.IGNORECASE),
        "indirect_injection",
        0.92,
    ),
    (
        re.compile(r"(?:always|must)\s+(?:say|answer|respond|output)\s+", re.IGNORECASE),
        "forced_output",
        0.80,
    ),
    (
        re.compile(r"(?:do\s+not|don'?t)\s+(?:mention|reveal|disclose|tell)", re.IGNORECASE),
        "information_suppression",
        0.75,
    ),
    (
        re.compile(r"repeat\s+(?:after\s+me|the\s+following|this)", re.IGNORECASE),
        "forced_repetition",
        0.70,
    ),
    (
        re.compile(r"(?:execute|run|eval)\s*\(", re.IGNORECASE),
        "code_execution",
        0.95,
    ),
    (
        re.compile(r"(?:fetch|request|curl|wget)\s+https?://", re.IGNORECASE),
        "external_request",
        0.85,
    ),
    (
        re.compile(r"base64\s*[\.\(]?\s*(?:decode|encode)", re.IGNORECASE),
        "encoding_manipulation",
        0.80,
    ),
]

# Structural indicators of injection
DELIMITER_PATTERNS = [
    re.compile(r"-{5,}"),  # Long dashes
    re.compile(r"={5,}"),  # Long equals
    re.compile(r"\*{5,}"),  # Long asterisks
    re.compile(r"#{3,}\s*(?:system|instruction|override)", re.IGNORECASE),
]


class PromptInjectionDetector:
    """Detects prompt injection attempts using pattern matching and heuristics.

    This detector runs in <5ms and catches the majority of known injection
    patterns. For semantic attacks, use the LLM guard or classifier as
    additional layers.
    """

    def __init__(self, config: DetectorConfig | None = None) -> None:
        self.config = config or DetectorConfig()
        self.threshold = self.config.classifier_threshold

    def scan(self, text: str) -> DetectionResult:
        """Scan text for prompt injection patterns.

        Returns DetectionResult with the highest-scoring match.
        """
        start = time.perf_counter()

        max_score = 0.0
        max_reason = ""
        all_matches = []

        # Check against known injection patterns
        for pattern, description, severity_score in INJECTION_PATTERNS:
            match = pattern.search(text)
            if match:
                all_matches.append({
                    "pattern": description,
                    "score": severity_score,
                    "match": match.group()[:100],  # truncate for logging
                })
                if severity_score > max_score:
                    max_score = severity_score
                    max_reason = description

        # Check structural indicators
        delimiter_count = sum(
            1 for p in DELIMITER_PATTERNS if p.search(text)
        )
        if delimiter_count >= 2:
            structural_score = 0.6
            all_matches.append({
                "pattern": "structural_delimiter",
                "score": structural_score,
                "match": f"{delimiter_count} delimiter patterns",
            })
            if structural_score > max_score:
                max_score = structural_score
                max_reason = "structural_delimiter"

        # Heuristic: very long text with instruction-like language
        instruction_density = self._instruction_density(text)
        if instruction_density > 0.3:
            density_score = min(0.75, instruction_density)
            all_matches.append({
                "pattern": "high_instruction_density",
                "score": density_score,
                "match": f"density={instruction_density:.2f}",
            })
            if density_score > max_score:
                max_score = density_score
                max_reason = "high_instruction_density"

        flagged = max_score >= self.threshold
        elapsed_ms = (time.perf_counter() - start) * 1000

        if flagged:
            logger.warning(
                "Prompt injection detected: %s (score=%.2f)",
                max_reason,
                max_score,
            )

        return DetectionResult(
            flagged=flagged,
            score=max_score,
            threat_type=ThreatType.PROMPT_INJECTION if flagged else None,
            reason=max_reason if flagged else "clean",
            details={"matches": all_matches} if all_matches else None,
            detector_name="prompt_injection",
            latency_ms=elapsed_ms,
        )

    def _instruction_density(self, text: str) -> float:
        """Estimate the ratio of instruction-like sentences in text."""
        if not text:
            return 0.0
        instruction_words = {
            "ignore", "forget", "override", "execute", "run", "system",
            "instruction", "command", "always", "never", "must", "shall",
            "respond", "answer", "output", "return", "print", "say",
        }
        words = text.lower().split()
        if not words:
            return 0.0
        count = sum(1 for w in words if w in instruction_words)
        return count / len(words)
