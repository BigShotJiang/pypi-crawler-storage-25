"""Embedding-based anomaly detection for data poisoning defense.

The single highest-ROI defense for enterprise RAG systems.
Detects:
- Near-duplicate documents (overriding attacks)
- Cluster-dense neighborhoods (coordinated poisoning)
- Corpus outliers (topic drift / unrelated injection)
"""

from __future__ import annotations

import logging
import time
from typing import Callable, List, Optional, Tuple

import numpy as np

from rag_guard.config import DetectorConfig
from rag_guard.types import DetectionResult, ThreatType

logger = logging.getLogger("rag_guard.detector.embedding_anomaly")


class EmbeddingAnomalyDetector:
    """Detects poisoned documents via embedding similarity analysis.

    Before adding documents to the knowledge base, compute their vector
    embeddings and compare against existing corpus. Flags:
    1. Near-duplicates (max cosine sim > 0.97)
    2. Cluster-dense neighborhoods (too many docs above similarity threshold)
    3. Outliers far from corpus centroid

    Research shows this reduces PoisonedRAG attack success from 95% → 20%.
    """

    def __init__(
        self,
        config: DetectorConfig | None = None,
        embedding_fn: Optional[Callable] = None,
    ) -> None:
        self.config = config or DetectorConfig()
        self.similarity_threshold = self.config.similarity_threshold
        self.near_duplicate_threshold = self.config.near_duplicate_threshold
        self.cluster_density_max = self.config.cluster_density_max
        self.outlier_z_score = self.config.outlier_z_score
        self.embedding_fn = embedding_fn

    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))

    def _cosine_batch(
        self, doc_embedding: np.ndarray, corpus_embeddings: np.ndarray
    ) -> np.ndarray:
        """Compute cosine similarity between a document and all corpus docs."""
        if corpus_embeddings.size == 0:
            return np.array([])
        # Normalize
        doc_norm = doc_embedding / (np.linalg.norm(doc_embedding) + 1e-10)
        corpus_norms = corpus_embeddings / (
            np.linalg.norm(corpus_embeddings, axis=1, keepdims=True) + 1e-10
        )
        return corpus_norms @ doc_norm

    def check_document(
        self,
        doc_embedding: np.ndarray,
        corpus_embeddings: np.ndarray,
    ) -> DetectionResult:
        """Check if a document embedding is anomalous relative to the corpus.

        Returns DetectionResult with:
        - flagged: True if suspicious
        - score: max cosine similarity to any existing doc
        - threat_type: NEAR_DUPLICATE, CLUSTER_ANOMALY, or CORPUS_OUTLIER
        """
        start = time.perf_counter()

        if corpus_embeddings.size == 0:
            elapsed_ms = (time.perf_counter() - start) * 1000
            return DetectionResult(
                flagged=False,
                score=0.0,
                reason="empty_corpus",
                detector_name="embedding_anomaly",
                latency_ms=elapsed_ms,
            )

        similarities = self._cosine_batch(doc_embedding, corpus_embeddings)
        max_sim = float(np.max(similarities))
        top_k = int(np.sum(similarities > self.similarity_threshold))

        # Flag 1: Near-duplicate of existing content
        if max_sim > self.near_duplicate_threshold:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.warning(
                "Near-duplicate detected: max_sim=%.4f", max_sim
            )
            return DetectionResult(
                flagged=True,
                score=max_sim,
                threat_type=ThreatType.NEAR_DUPLICATE,
                reason=f"near_duplicate (sim={max_sim:.4f})",
                details={"max_similarity": max_sim, "top_k_similar": top_k},
                detector_name="embedding_anomaly",
                latency_ms=elapsed_ms,
            )

        # Flag 2: Cluster-dense — multiple docs too similar
        if top_k >= self.cluster_density_max:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.warning(
                "Cluster density anomaly: %d docs above threshold", top_k
            )
            return DetectionResult(
                flagged=True,
                score=max_sim,
                threat_type=ThreatType.CLUSTER_ANOMALY,
                reason=f"cluster_dense ({top_k} docs above {self.similarity_threshold})",
                details={"max_similarity": max_sim, "top_k_similar": top_k},
                detector_name="embedding_anomaly",
                latency_ms=elapsed_ms,
            )

        # Flag 3: Outlier — too far from corpus centroid
        centroid = np.mean(corpus_embeddings, axis=0)
        centroid_sim = self._cosine_similarity(doc_embedding, centroid)
        # Low similarity to centroid means the doc is an outlier
        mean_sim = float(np.mean(similarities))
        std_sim = float(np.std(similarities))
        if std_sim > 0:
            z_score = (mean_sim - centroid_sim) / std_sim
            if z_score > self.outlier_z_score:
                elapsed_ms = (time.perf_counter() - start) * 1000
                logger.warning(
                    "Corpus outlier: centroid_sim=%.4f, z=%.2f",
                    centroid_sim,
                    z_score,
                )
                return DetectionResult(
                    flagged=True,
                    score=max_sim,
                    threat_type=ThreatType.CORPUS_OUTLIER,
                    reason=f"corpus_outlier (centroid_sim={centroid_sim:.4f})",
                    details={
                        "max_similarity": max_sim,
                        "centroid_similarity": centroid_sim,
                        "z_score": z_score,
                    },
                    detector_name="embedding_anomaly",
                    latency_ms=(time.perf_counter() - start) * 1000,
                )

        elapsed_ms = (time.perf_counter() - start) * 1000
        return DetectionResult(
            flagged=False,
            score=max_sim,
            reason="clean",
            details={"max_similarity": max_sim, "centroid_similarity": centroid_sim},
            detector_name="embedding_anomaly",
            latency_ms=elapsed_ms,
        )

    def check_batch(
        self,
        doc_embeddings: np.ndarray,
        corpus_embeddings: np.ndarray,
    ) -> List[DetectionResult]:
        """Check a batch of documents against the corpus."""
        results = []
        for emb in doc_embeddings:
            results.append(self.check_document(emb, corpus_embeddings))
        return results
