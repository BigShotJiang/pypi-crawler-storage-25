"""Token-level anomaly detection — O(n) single-pass character scanner."""

from __future__ import annotations

import logging
import time
from typing import Set

from rag_guard.config import DetectorConfig
from rag_guard.types import DetectionResult, ThreatType

logger = logging.getLogger("rag_guard.detector.token_anomaly")

# Character sets for fast lookup
ZERO_WIDTH_CODEPOINTS: Set[int] = {
    0x200B,  # ZERO WIDTH SPACE
    0x200C,  # ZERO WIDTH NON-JOINER
    0x200D,  # ZERO WIDTH JOINER
    0x2060,  # WORD JOINER
    0xFEFF,  # ZERO WIDTH NO-BREAK SPACE / BOM
    0x00AD,  # SOFT HYPHEN
    0x034F,  # COMBINING GRAPHEME JOINER
    0x180E,  # MONGOLIAN VOWEL SEPARATOR
}

BIDI_CODEPOINTS: Set[int] = {
    0x202A,  # LEFT-TO-RIGHT EMBEDDING
    0x202B,  # RIGHT-TO-LEFT EMBEDDING
    0x202C,  # POP DIRECTIONAL FORMATTING
    0x202D,  # LEFT-TO-RIGHT OVERRIDE
    0x202E,  # RIGHT-TO-LEFT OVERRIDE
    0x2066,  # LEFT-TO-RIGHT ISOLATE
    0x2067,  # RIGHT-TO-LEFT ISOLATE
    0x2068,  # FIRST STRONG ISOLATE
    0x2069,  # POP DIRECTIONAL ISOLATE
}


class TokenAnomalyDetector:
    """O(n) single-pass character scanner for invisible/suspicious characters.

    Checks for:
    - Zero-width character density (ratio)
    - Private Use Area characters (count)
    - Bidirectional control characters (count)
    - Tag characters (U+E0000–U+E007F)

    This is the fastest detection layer — sub-1ms latency.
    """

    def __init__(self, config: DetectorConfig | None = None) -> None:
        self.config = config or DetectorConfig()
        self.zw_threshold = self.config.zw_ratio_threshold
        self.pua_threshold = self.config.pua_count_threshold
        self.bidi_threshold = self.config.bidi_count_threshold

    def scan(self, text: str) -> DetectionResult:
        """Single-pass O(n) character scan.

        Returns a DetectionResult with detailed character anomaly stats.
        """
        start = time.perf_counter()

        zw = 0
        pua = 0
        bidi = 0
        tag_chars = 0
        text_len = len(text)

        for ch in text:
            cp = ord(ch)
            if cp in ZERO_WIDTH_CODEPOINTS:
                zw += 1
            elif 0xE000 <= cp <= 0xF8FF:
                pua += 1
            elif cp in BIDI_CODEPOINTS:
                bidi += 1
            elif 0xE0000 <= cp <= 0xE007F:
                tag_chars += 1

        ratio = zw / max(text_len, 1)

        # Determine threat type and reason
        reasons = []
        threat_type = None

        if ratio > self.zw_threshold:
            reasons.append(f"zero_width_ratio={ratio:.4f}>{self.zw_threshold}")
            threat_type = ThreatType.ZERO_WIDTH

        if pua > self.pua_threshold:
            reasons.append(f"pua_count={pua}>{self.pua_threshold}")
            threat_type = threat_type or ThreatType.PUA

        if bidi > self.bidi_threshold:
            reasons.append(f"bidi_count={bidi}>{self.bidi_threshold}")
            threat_type = threat_type or ThreatType.BIDI

        if tag_chars > 0:
            reasons.append(f"tag_chars={tag_chars}")
            threat_type = threat_type or ThreatType.PUA

        flagged = len(reasons) > 0
        score = min(1.0, (ratio * 100) + (pua / 10) + (bidi / 10) + (tag_chars / 5))

        elapsed_ms = (time.perf_counter() - start) * 1000

        if flagged:
            logger.warning(
                "Token anomaly detected: %s",
                "; ".join(reasons),
            )

        return DetectionResult(
            flagged=flagged,
            score=score,
            threat_type=threat_type,
            reason="; ".join(reasons) if reasons else "clean",
            details={
                "zw_count": zw,
                "zw_ratio": ratio,
                "pua_count": pua,
                "bidi_count": bidi,
                "tag_chars": tag_chars,
                "text_length": text_len,
            },
            detector_name="token_anomaly",
            latency_ms=elapsed_ms,
        )
