"""Detection pipeline — chains all detectors with tiered execution and short-circuit."""

from __future__ import annotations

import logging
import time
from typing import List, Optional

import numpy as np

from rag_guard.config import DetectorConfig
from rag_guard.detector.token_anomaly import TokenAnomalyDetector
from rag_guard.detector.embedding_anomaly import EmbeddingAnomalyDetector
from rag_guard.detector.prompt_injection import PromptInjectionDetector
from rag_guard.types import DetectionResult, ThreatType

logger = logging.getLogger("rag_guard.detector.pipeline")


class DetectionPipeline:
    """Chains all detectors in tiered execution order.

    Tier 1: Token anomaly scan (~0.1ms) — regex/char scan
    Tier 2: Prompt injection patterns (~2ms) — pattern matching
    Tier 3: Embedding anomaly (~10ms) — cosine similarity analysis

    Short-circuits on first flag if configured. Each tier's result is
    collected and the worst finding is returned as the primary result.
    """

    def __init__(self, config: DetectorConfig | None = None) -> None:
        self.config = config or DetectorConfig()
        self.token_detector = TokenAnomalyDetector(self.config)
        self.embedding_detector = EmbeddingAnomalyDetector(self.config)
        self.injection_detector = PromptInjectionDetector(self.config)

    def scan_text(self, text: str) -> DetectionResult:
        """Run all text-based detectors on input text.

        This does NOT include embedding anomaly (requires vector data).
        """
        start = time.perf_counter()
        all_results: List[DetectionResult] = []

        # Tier 1: Token anomaly scan
        if self.config.enable_token_scan:
            token_result = self.token_detector.scan(text)
            all_results.append(token_result)
            if token_result.flagged and self.config.short_circuit:
                token_result.latency_ms = (time.perf_counter() - start) * 1000
                return token_result

        # Tier 2: Prompt injection patterns
        injection_result = self.injection_detector.scan(text)
        all_results.append(injection_result)
        if injection_result.flagged and self.config.short_circuit:
            injection_result.latency_ms = (time.perf_counter() - start) * 1000
            return injection_result

        # Return worst result
        elapsed_ms = (time.perf_counter() - start) * 1000
        flagged_results = [r for r in all_results if r.flagged]

        if flagged_results:
            worst = max(flagged_results, key=lambda r: r.score)
            worst.latency_ms = elapsed_ms
            return worst

        return DetectionResult(
            flagged=False,
            score=0.0,
            reason="clean",
            detector_name="pipeline",
            latency_ms=elapsed_ms,
        )

    def scan_document(
        self,
        text: str,
        doc_embedding: Optional[np.ndarray] = None,
        corpus_embeddings: Optional[np.ndarray] = None,
    ) -> DetectionResult:
        """Full document scan: text checks + embedding anomaly.

        Use this when ingesting documents into the knowledge base.
        """
        start = time.perf_counter()
        all_results: List[DetectionResult] = []

        # Text-based scans
        text_result = self.scan_text(text)
        all_results.append(text_result)
        if text_result.flagged and self.config.short_circuit:
            text_result.latency_ms = (time.perf_counter() - start) * 1000
            return text_result

        # Tier 3: Embedding anomaly
        if (
            self.config.enable_embedding_scan
            and doc_embedding is not None
            and corpus_embeddings is not None
        ):
            emb_result = self.embedding_detector.check_document(
                doc_embedding, corpus_embeddings
            )
            all_results.append(emb_result)
            if emb_result.flagged and self.config.short_circuit:
                emb_result.latency_ms = (time.perf_counter() - start) * 1000
                return emb_result

        # Return worst result
        elapsed_ms = (time.perf_counter() - start) * 1000
        flagged_results = [r for r in all_results if r.flagged]

        if flagged_results:
            worst = max(flagged_results, key=lambda r: r.score)
            worst.latency_ms = elapsed_ms
            return worst

        return DetectionResult(
            flagged=False,
            score=0.0,
            reason="clean",
            detector_name="pipeline",
            latency_ms=elapsed_ms,
        )
