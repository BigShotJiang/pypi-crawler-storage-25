"""RAGGuard — top-level orchestrator for the entire defense pipeline.

This is the primary entry point for the library. It wires together
sanitizers, detectors, guards, alerting, and telemetry into a single
easy-to-use API.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable, Dict, List, Optional

import numpy as np

from rag_guard.alerting import AlertManager
from rag_guard.config import GuardConfig
from rag_guard.detector.pipeline import DetectionPipeline
from rag_guard.guards.agent_guard import AgentGuard, ToolCall
from rag_guard.guards.output_guard import OutputGuard
from rag_guard.guards.prompt_builder import PromptBuilder
from rag_guard.guards.retriever_guard import RetrieverGuard
from rag_guard.sanitizer.pipeline import SanitizationPipeline
from rag_guard.telemetry.logger import StructuredLogger
from rag_guard.telemetry.metrics import MetricsCollector
from rag_guard.types import (
    AlertEvent,
    DetectionResult,
    GuardResult,
    SanitizationResult,
    ThreatType,
)

logger = logging.getLogger("rag_guard.core")


class RAGGuard:
    """Enterprise RAG security orchestrator.

    Provides a unified API for:
    - Text scanning (user inputs, documents)
    - Document ingestion security (embedding anomaly detection)
    - Retrieval guarding
    - Agent/tool call validation
    - Output filtering
    - Prompt construction with spotlighting
    - Alerting on detected threats

    Usage:
        guard = RAGGuard(GuardConfig(alert_webhook="https://hooks.slack.com/..."))

        # Scan user input
        result = guard.scan_text("user query here")
        if result.flagged:
            print(f"Blocked: {result.reason}")

        # Scan document before ingestion
        result = guard.scan_document(doc_text, doc_embedding, corpus_embeddings)
        if result.flagged:
            print(f"Quarantined: {result.reason}")
    """

    def __init__(self, config: GuardConfig | None = None) -> None:
        self.config = config or GuardConfig()

        # Core modules
        self.sanitizer = SanitizationPipeline(self.config.sanitizer)
        self.detector = DetectionPipeline(self.config.detector)
        self.retriever_guard = RetrieverGuard(config=self.config)
        self.agent_guard = AgentGuard(config=self.config)
        self.output_guard = OutputGuard(config=self.config)
        self.prompt_builder = PromptBuilder()

        # Telemetry
        self._structured_logger = StructuredLogger(self.config.telemetry)
        self._metrics = MetricsCollector(self.config.telemetry)

        # Alerting
        self.alert_manager = AlertManager(
            config=self.config.alert,
            structured_logger=self._structured_logger,
            metrics=self._metrics,
        )

    # ── Scanning ──────────────────────────────────────────────────

    def scan_text(self, text: str, source: str = "user_input") -> DetectionResult:
        """Scan text for all threat types. Sanitizes first, then detects.

        This is the primary method for checking user inputs and queries.
        Alerts are automatically dispatched if threats are found.
        """
        start = time.perf_counter()

        # Step 1: Sanitize
        san_result = self.sanitizer.sanitize(text)
        clean_text = san_result.sanitized_text

        if san_result.was_modified:
            self._metrics.record_sanitization(san_result.chars_removed)

        # Step 2: Detect
        detection = self.detector.scan_text(clean_text)
        detection.latency_ms = (time.perf_counter() - start) * 1000

        # Step 3: Record metrics
        self._metrics.record_detection(
            flagged=detection.flagged,
            threat_type=detection.threat_type.value if detection.threat_type else None,
            detector=detection.detector_name,
            latency_ms=detection.latency_ms,
        )

        # Step 4: Alert if flagged
        if detection.flagged:
            self.alert_manager.alert_from_detection(detection, source=source)

        return detection

    def scan_document(
        self,
        text: str,
        doc_embedding: Optional[np.ndarray] = None,
        corpus_embeddings: Optional[np.ndarray] = None,
        source: str = "document_ingestion",
    ) -> DetectionResult:
        """Full document scan for ingestion security.

        Includes text checks + embedding anomaly detection.
        Use this before adding documents to your knowledge base.
        """
        start = time.perf_counter()

        # Sanitize
        san_result = self.sanitizer.sanitize(text)
        clean_text = san_result.sanitized_text

        if san_result.was_modified:
            self._metrics.record_sanitization(san_result.chars_removed)

        # Full detection pipeline
        detection = self.detector.scan_document(
            clean_text, doc_embedding, corpus_embeddings
        )
        detection.latency_ms = (time.perf_counter() - start) * 1000

        # Metrics + alerting
        self._metrics.record_detection(
            flagged=detection.flagged,
            threat_type=detection.threat_type.value if detection.threat_type else None,
            detector=detection.detector_name,
            latency_ms=detection.latency_ms,
        )

        if detection.flagged:
            self.alert_manager.alert_from_detection(detection, source=source)

        return detection

    # ── Sanitization ──────────────────────────────────────────────

    def sanitize(self, text: str) -> SanitizationResult:
        """Sanitize text through the full pipeline."""
        result = self.sanitizer.sanitize(text)
        if result.was_modified:
            self._metrics.record_sanitization(result.chars_removed)
        return result

    def sanitize_text(self, text: str) -> str:
        """Convenience: returns only the cleaned string."""
        return self.sanitize(text).sanitized_text

    # ── Guards ────────────────────────────────────────────────────

    def guard_retrieval(
        self,
        query: str,
        retrieve_fn: Optional[Callable] = None,
        retriever: Any = None,
        top_k: int = 5,
    ) -> GuardResult:
        """Guard a retrieval operation. Sanitizes query, checks docs."""
        result = self.retriever_guard.retrieve(
            query, top_k=top_k, retriever=retriever, retrieve_fn=retrieve_fn
        )
        for det in result.detections:
            if det.flagged:
                self.alert_manager.alert_from_detection(det, source="retrieval")
        return result

    def guard_tool_call(
        self,
        user_goal: str,
        tool_name: str,
        tool_args: Optional[Dict[str, Any]] = None,
    ) -> GuardResult:
        """Guard an agent tool call."""
        action = ToolCall(name=tool_name, arguments=tool_args or {})
        result = self.agent_guard.check_tool_call(user_goal, action)
        for det in result.detections:
            if det.flagged:
                self.alert_manager.alert_from_detection(det, source="agent_tool")
        return result

    def guard_tool_output(self, user_goal: str, output: str) -> GuardResult:
        """Guard the output from a tool execution."""
        result = self.agent_guard.check_tool_output(user_goal, output)
        for det in result.detections:
            if det.flagged:
                self.alert_manager.alert_from_detection(det, source="tool_output")
        return result

    def guard_output(
        self, output: str, user_query: Optional[str] = None
    ) -> GuardResult:
        """Guard LLM output before returning to user."""
        result = self.output_guard.check(output, user_query)
        for det in result.detections:
            if det.flagged:
                self.alert_manager.alert_from_detection(det, source="llm_output")
        return result

    # ── Prompt Building ───────────────────────────────────────────

    def build_prompt(
        self,
        query: str,
        documents: List[str],
        system_prompt: Optional[str] = None,
    ) -> str:
        """Build a spotlighting-enabled prompt with delimiter isolation."""
        return self.prompt_builder.build(query, documents, system_prompt)

    def build_chat_messages(
        self,
        query: str,
        documents: List[str],
        system_prompt: Optional[str] = None,
    ) -> List[dict]:
        """Build chat-style messages for OpenAI/Anthropic APIs."""
        return self.prompt_builder.build_chat_messages(
            query, documents, system_prompt
        )

    # ── Telemetry ─────────────────────────────────────────────────

    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics snapshot."""
        return self._metrics.get_stats()

    def get_alert_history(self, limit: int = 100) -> List[AlertEvent]:
        """Get recent alert history."""
        return self.alert_manager.get_history(limit=limit)

    @property
    def alert_count(self) -> int:
        """Total alerts triggered."""
        return self.alert_manager.alert_count
