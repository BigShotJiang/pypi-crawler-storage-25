"""Core data types for RAG Guard detection and alerting."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class ThreatType(Enum):
    """Classification of detected threat vectors."""
    ZERO_WIDTH = "zero_width"
    PUA = "private_use_area"
    BIDI = "bidi_control"
    HOMOGLYPH = "homoglyph"
    HTML_INJECTION = "html_injection"
    PROMPT_INJECTION = "prompt_injection"
    DATA_POISONING = "data_poisoning"
    NEAR_DUPLICATE = "near_duplicate"
    CLUSTER_ANOMALY = "cluster_anomaly"
    CORPUS_OUTLIER = "corpus_outlier"
    TOOL_HIJACK = "tool_hijack"
    CONTEXT_DRIFT = "context_drift"
    POLICY_VIOLATION = "policy_violation"
    UNKNOWN = "unknown"


class Severity(Enum):
    """Severity levels for alerts and detections."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


THREAT_SEVERITY_MAP: Dict[ThreatType, Severity] = {
    ThreatType.ZERO_WIDTH: Severity.CRITICAL,
    ThreatType.PUA: Severity.CRITICAL,
    ThreatType.BIDI: Severity.HIGH,
    ThreatType.HOMOGLYPH: Severity.HIGH,
    ThreatType.HTML_INJECTION: Severity.HIGH,
    ThreatType.PROMPT_INJECTION: Severity.CRITICAL,
    ThreatType.DATA_POISONING: Severity.CRITICAL,
    ThreatType.NEAR_DUPLICATE: Severity.HIGH,
    ThreatType.CLUSTER_ANOMALY: Severity.CRITICAL,
    ThreatType.CORPUS_OUTLIER: Severity.MEDIUM,
    ThreatType.TOOL_HIJACK: Severity.CRITICAL,
    ThreatType.CONTEXT_DRIFT: Severity.HIGH,
    ThreatType.POLICY_VIOLATION: Severity.HIGH,
    ThreatType.UNKNOWN: Severity.MEDIUM,
}


@dataclass
class DetectionResult:
    """Result from any detection/scanning operation."""
    flagged: bool
    score: float = 0.0
    threat_type: Optional[ThreatType] = None
    reason: str = ""
    details: Optional[Dict[str, Any]] = None
    detector_name: str = ""
    latency_ms: float = 0.0

    @property
    def severity(self) -> Severity:
        if self.threat_type is None:
            return Severity.INFO
        return THREAT_SEVERITY_MAP.get(self.threat_type, Severity.MEDIUM)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "flagged": self.flagged,
            "score": self.score,
            "threat_type": self.threat_type.value if self.threat_type else None,
            "severity": self.severity.value,
            "reason": self.reason,
            "details": self.details,
            "detector_name": self.detector_name,
            "latency_ms": self.latency_ms,
        }


@dataclass
class SanitizationResult:
    """Result from text sanitization."""
    original_length: int
    sanitized_length: int
    chars_removed: int
    categories_removed: Dict[str, int] = field(default_factory=dict)
    sanitized_text: str = ""

    @property
    def was_modified(self) -> bool:
        return self.chars_removed > 0


@dataclass
class GuardResult:
    """Result from guard checks (retriever, agent, output)."""
    allowed: bool
    reason: str = ""
    confidence: float = 1.0
    suggested_action: str = "proceed"  # proceed | block | confirm | quarantine
    detections: List[DetectionResult] = field(default_factory=list)

    @property
    def has_threats(self) -> bool:
        return any(d.flagged for d in self.detections)


@dataclass
class AlertEvent:
    """Structured alert event for the alerting system."""
    alert_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: float = field(default_factory=time.time)
    threat_type: Optional[ThreatType] = None
    severity: Severity = Severity.MEDIUM
    source: str = ""
    message: str = ""
    details: Optional[Dict[str, Any]] = None
    detection_result: Optional[DetectionResult] = None
    acknowledged: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "alert_id": self.alert_id,
            "timestamp": self.timestamp,
            "threat_type": self.threat_type.value if self.threat_type else None,
            "severity": self.severity.value,
            "source": self.source,
            "message": self.message,
            "details": self.details,
            "detection": self.detection_result.to_dict() if self.detection_result else None,
            "acknowledged": self.acknowledged,
        }
