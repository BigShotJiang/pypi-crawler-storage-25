"""Enterprise alerting system for data poisoning detection.

Supports multiple alert channels:
- Webhook (Slack, PagerDuty, Teams, custom)
- Email (SMTP)
- Callback functions
- Structured logging (always-on)

Includes rate limiting, deduplication, and severity filtering.
"""

from __future__ import annotations

import json
import logging
import smtplib
import threading
import time
from collections import deque
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any, Callable, Deque, Dict, List, Optional
from urllib.request import Request, urlopen
from urllib.error import URLError

from rag_guard.config import AlertConfig, GuardConfig
from rag_guard.telemetry.logger import StructuredLogger
from rag_guard.telemetry.metrics import MetricsCollector
from rag_guard.types import AlertEvent, DetectionResult, Severity, ThreatType

logger = logging.getLogger("rag_guard.alerting")

SEVERITY_ORDER = {
    Severity.INFO: 0,
    Severity.LOW: 1,
    Severity.MEDIUM: 2,
    Severity.HIGH: 3,
    Severity.CRITICAL: 4,
}

SEVERITY_FROM_STR = {s.value: s for s in Severity}


class AlertManager:
    """Central alert manager for RAG Guard.

    Receives detection results, creates alert events, and dispatches
    them to configured channels. Features:

    - **Severity filtering**: Only alerts above configured threshold
    - **Rate limiting**: Max N alerts per minute to prevent storms
    - **Deduplication**: Same threat_type from same source within window
    - **Multi-channel**: Webhook, email, callback, log
    - **Thread-safe**: Safe for concurrent use
    - **Alert history**: Queryable in-memory ring buffer
    """

    def __init__(
        self,
        config: AlertConfig | GuardConfig | None = None,
        structured_logger: StructuredLogger | None = None,
        metrics: MetricsCollector | None = None,
    ) -> None:
        if isinstance(config, GuardConfig):
            self._config = config.alert
        elif isinstance(config, AlertConfig):
            self._config = config
        else:
            self._config = AlertConfig()

        self._logger = structured_logger or StructuredLogger()
        self._metrics = metrics or MetricsCollector()
        self._lock = threading.Lock()

        # Rate limiting state
        self._alert_timestamps: Deque[float] = deque()
        self._dedup_cache: Dict[str, float] = {}
        self._dedup_window = 60.0  # seconds

        # Alert history (ring buffer)
        self._history: Deque[AlertEvent] = deque(maxlen=10000)

        # Custom callbacks
        self._callbacks: List[Callable[[AlertEvent], None]] = []
        if self._config.callback and callable(self._config.callback):
            self._callbacks.append(self._config.callback)

    @property
    def min_severity(self) -> Severity:
        return SEVERITY_FROM_STR.get(
            self._config.alert_on_severity, Severity.MEDIUM
        )

    def register_callback(self, callback: Callable[[AlertEvent], None]) -> None:
        """Register a custom callback for alert events."""
        self._callbacks.append(callback)

    def alert_from_detection(
        self,
        detection: DetectionResult,
        source: str = "",
    ) -> Optional[AlertEvent]:
        """Create and dispatch an alert from a detection result.

        Returns the AlertEvent if dispatched, None if filtered/rate-limited.
        """
        if not detection.flagged:
            return None

        severity = detection.severity
        if SEVERITY_ORDER.get(severity, 0) < SEVERITY_ORDER.get(self.min_severity, 0):
            return None

        event = AlertEvent(
            threat_type=detection.threat_type,
            severity=severity,
            source=source,
            message=(
                f"Data poisoning alert: {detection.threat_type.value if detection.threat_type else 'unknown'} "
                f"detected by {detection.detector_name} "
                f"(score={detection.score:.3f})"
            ),
            details=detection.details,
            detection_result=detection,
        )

        return self.dispatch(event)

    def dispatch(self, event: AlertEvent) -> Optional[AlertEvent]:
        """Dispatch an alert event through all configured channels.

        Applies rate limiting and deduplication before dispatch.
        Returns the event if dispatched, None if filtered.
        """
        if not self._config.enabled:
            return None

        with self._lock:
            # Rate limiting
            now = time.time()
            self._alert_timestamps = deque(
                t for t in self._alert_timestamps if now - t < 60
            )
            if len(self._alert_timestamps) >= self._config.max_alerts_per_minute:
                logger.debug("Alert rate limit exceeded, dropping alert")
                return None
            self._alert_timestamps.append(now)

            # Deduplication
            dedup_key = f"{event.threat_type}:{event.source}"
            last_seen = self._dedup_cache.get(dedup_key, 0)
            if now - last_seen < self._dedup_window:
                logger.debug("Duplicate alert suppressed: %s", dedup_key)
                return None
            self._dedup_cache[dedup_key] = now

            # Store in history
            self._history.append(event)

        # Dispatch to channels (outside lock to avoid blocking)
        self._dispatch_log(event)
        self._dispatch_webhook(event)
        self._dispatch_email(event)
        self._dispatch_callbacks(event)

        # Record metrics
        self._metrics.record_alert(event.severity.value)

        return event

    def _dispatch_log(self, event: AlertEvent) -> None:
        """Always log alerts via structured logger."""
        if self._config.log_alerts:
            self._logger.log_alert(
                alert_id=event.alert_id,
                severity=event.severity.value,
                message=event.message,
                details=event.details,
            )

    def _dispatch_webhook(self, event: AlertEvent) -> None:
        """Send alert to webhook (Slack, PagerDuty, Teams, custom)."""
        url = self._config.webhook_url
        if not url:
            return

        payload = json.dumps(event.to_dict()).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        headers.update(self._config.webhook_headers)

        try:
            req = Request(url, data=payload, headers=headers, method="POST")
            with urlopen(req, timeout=5) as resp:
                if resp.status >= 400:
                    logger.error("Webhook failed: HTTP %d", resp.status)
        except (URLError, OSError) as exc:
            logger.error("Webhook dispatch failed: %s", exc)

    def _dispatch_email(self, event: AlertEvent) -> None:
        """Send alert via email (SMTP)."""
        if not self._config.email_recipients or not self._config.smtp_host:
            return

        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = (
                f"[RAG Guard {event.severity.value.upper()}] "
                f"{event.threat_type.value if event.threat_type else 'Alert'}"
            )
            msg["From"] = self._config.smtp_user or "rag-guard@system"
            msg["To"] = ", ".join(self._config.email_recipients)

            body = (
                f"Alert ID: {event.alert_id}\n"
                f"Severity: {event.severity.value}\n"
                f"Threat: {event.threat_type.value if event.threat_type else 'N/A'}\n"
                f"Source: {event.source}\n"
                f"Message: {event.message}\n"
                f"Timestamp: {event.timestamp}\n"
                f"\nDetails:\n{json.dumps(event.details, indent=2, default=str)}"
            )
            msg.attach(MIMEText(body, "plain"))

            with smtplib.SMTP(self._config.smtp_host, self._config.smtp_port) as server:
                server.ehlo()
                if self._config.smtp_port == 587:
                    server.starttls()
                if self._config.smtp_user and self._config.smtp_password:
                    server.login(self._config.smtp_user, self._config.smtp_password)
                server.sendmail(
                    msg["From"],
                    self._config.email_recipients,
                    msg.as_string(),
                )
        except Exception as exc:
            logger.error("Email dispatch failed: %s", exc)

    def _dispatch_callbacks(self, event: AlertEvent) -> None:
        """Call registered callback functions."""
        for cb in self._callbacks:
            try:
                cb(event)
            except Exception as exc:
                logger.error("Callback failed: %s", exc)

    def get_history(
        self,
        limit: int = 100,
        severity: Optional[str] = None,
        threat_type: Optional[str] = None,
    ) -> List[AlertEvent]:
        """Query alert history with optional filters."""
        with self._lock:
            alerts = list(self._history)

        if severity:
            sev = SEVERITY_FROM_STR.get(severity)
            if sev:
                alerts = [a for a in alerts if a.severity == sev]

        if threat_type:
            tt = None
            for t in ThreatType:
                if t.value == threat_type:
                    tt = t
                    break
            if tt:
                alerts = [a for a in alerts if a.threat_type == tt]

        return alerts[-limit:]

    @property
    def alert_count(self) -> int:
        """Total number of alerts in history."""
        return len(self._history)

    def clear_history(self) -> None:
        """Clear alert history."""
        with self._lock:
            self._history.clear()
            self._dedup_cache.clear()
