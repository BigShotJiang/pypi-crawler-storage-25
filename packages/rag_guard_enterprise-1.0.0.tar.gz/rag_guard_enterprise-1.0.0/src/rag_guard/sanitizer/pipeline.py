"""Sanitization pipeline — chains all sanitizers in sequence."""

from __future__ import annotations

import logging
import time
from typing import Optional

from rag_guard.config import SanitizerConfig
from rag_guard.sanitizer.unicode import UnicodeSanitizer
from rag_guard.sanitizer.html import HTMLSanitizer
from rag_guard.sanitizer.homoglyph import HomoglyphCanonicalizer
from rag_guard.types import SanitizationResult

logger = logging.getLogger("rag_guard.sanitizer.pipeline")


class SanitizationPipeline:
    """Chains UnicodeSanitizer → HTMLSanitizer → HomoglyphCanonicalizer.

    Runs all sanitizers in sequence. Each step's output feeds the next.
    Designed for <0.5ms total latency on typical inputs.
    """

    def __init__(self, config: SanitizerConfig | None = None) -> None:
        self.config = config or SanitizerConfig()
        self.unicode_sanitizer = UnicodeSanitizer(self.config)
        self.html_sanitizer = HTMLSanitizer(self.config)
        self.homoglyph_canonicalizer = HomoglyphCanonicalizer(self.config)

    def sanitize(self, text: str) -> SanitizationResult:
        """Run the full sanitization pipeline."""
        start = time.perf_counter()
        original_len = len(text)

        # Step 1: Unicode sanitization (zero-width, PUA, bidi, etc.)
        unicode_result = self.unicode_sanitizer.sanitize(text)
        text = unicode_result.sanitized_text

        # Step 2: HTML sanitization (scripts, comments, hidden CSS)
        text = self.html_sanitizer.sanitize(text)

        # Step 3: Homoglyph canonicalization
        if self.config.mode == "strict":
            text = self.homoglyph_canonicalizer.canonicalize(text)

        elapsed_ms = (time.perf_counter() - start) * 1000
        total_removed = original_len - len(text)

        if total_removed > 0:
            logger.info(
                "Pipeline sanitized %d chars in %.2fms",
                total_removed,
                elapsed_ms,
            )

        return SanitizationResult(
            original_length=original_len,
            sanitized_length=len(text),
            chars_removed=total_removed,
            categories_removed=unicode_result.categories_removed,
            sanitized_text=text,
        )

    def sanitize_text(self, text: str) -> str:
        """Convenience: returns only the cleaned string."""
        return self.sanitize(text).sanitized_text
