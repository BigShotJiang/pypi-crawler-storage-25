"""Unicode sanitizer — removes invisible characters, PUA, bidi controls, tag chars."""

from __future__ import annotations

import logging
import re
import unicodedata
from typing import Dict

from rag_guard.config import SanitizerConfig
from rag_guard.types import SanitizationResult

logger = logging.getLogger("rag_guard.sanitizer.unicode")

# Compiled once at module level — zero per-call regex cost
INVISIBLE_RE = re.compile(
    "["
    "\u200b-\u200f"           # Zero-width & directional marks
    "\u2028-\u202f"           # Line/paragraph seps, bidi controls
    "\u2060-\u2064"           # Word joiners, invisible operators
    "\u2066-\u206f"           # Bidi isolates & overrides
    "\ufeff"                  # BOM / ZWNBSP
    "\U000e0000-\U000e007f"   # Tag characters
    "\U000f0000-\U000fffff"   # Supplementary PUA-A
    "\U00100000-\U0010ffff"   # Supplementary PUA-B
    "]"
)

ZERO_WIDTH_RE = re.compile(
    "[\u200b\u200c\u200d\u2060\ufeff]"
)

PUA_BASIC_RE = re.compile("[\ue000-\uf8ff]")

BIDI_RE = re.compile(
    "[\u202a-\u202e\u2066-\u2069]"
)

TAG_CHARS_RE = re.compile("[\U000e0000-\U000e007f]")

WHITESPACE_COLLAPSE_RE = re.compile(r"\s+")


class UnicodeSanitizer:
    """Strips or normalizes dangerous Unicode characters from text.

    This is the first line of defense — runs before any other processing.
    Designed for <0.5ms latency on typical inputs.
    """

    def __init__(self, config: SanitizerConfig | None = None) -> None:
        self.config = config or SanitizerConfig()

    def sanitize(self, text: str) -> SanitizationResult:
        """Remove invisible chars, normalize Unicode, collapse whitespace.

        Returns a SanitizationResult with the cleaned text and removal stats.
        """
        original = text
        original_len = len(text)
        categories: Dict[str, int] = {}

        # 1. NFC normalize — collapse decomposed forms
        if self.config.normalize_unicode:
            text = unicodedata.normalize("NFC", text)

        # 2. Strip zero-width characters
        if self.config.strip_zero_width:
            before = len(text)
            text = ZERO_WIDTH_RE.sub("", text)
            removed = before - len(text)
            if removed:
                categories["zero_width"] = removed

        # 3. Strip PUA characters
        if self.config.strip_pua:
            before = len(text)
            text = PUA_BASIC_RE.sub("", text)
            removed = before - len(text)
            if removed:
                categories["pua"] = removed

        # 4. Strip bidi controls
        if self.config.strip_bidi:
            before = len(text)
            text = BIDI_RE.sub("", text)
            removed = before - len(text)
            if removed:
                categories["bidi"] = removed

        # 5. Strip tag characters
        if self.config.strip_tag_chars:
            before = len(text)
            text = TAG_CHARS_RE.sub("", text)
            removed = before - len(text)
            if removed:
                categories["tag_chars"] = removed

        # 6. Full invisible sweep (catch anything missed above)
        before = len(text)
        text = INVISIBLE_RE.sub("", text)
        removed = before - len(text)
        if removed:
            categories["other_invisible"] = removed

        # 7. Collapse whitespace runs
        if self.config.collapse_whitespace:
            text = WHITESPACE_COLLAPSE_RE.sub(" ", text).strip()

        total_removed = original_len - len(text)
        if total_removed > 0:
            logger.warning(
                "Sanitized: removed %d chars (%s)",
                total_removed,
                ", ".join(f"{k}={v}" for k, v in categories.items()),
            )

        return SanitizationResult(
            original_length=original_len,
            sanitized_length=len(text),
            chars_removed=total_removed,
            categories_removed=categories,
            sanitized_text=text,
        )

    def sanitize_text(self, text: str) -> str:
        """Convenience: returns only the cleaned string."""
        return self.sanitize(text).sanitized_text

    def has_invisible_chars(self, text: str) -> bool:
        """Quick check: does the text contain any invisible characters?"""
        return bool(INVISIBLE_RE.search(text)) or bool(PUA_BASIC_RE.search(text))
