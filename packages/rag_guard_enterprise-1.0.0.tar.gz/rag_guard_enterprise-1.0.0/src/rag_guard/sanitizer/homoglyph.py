"""Homoglyph canonicalizer — normalizes visually similar cross-script characters."""

from __future__ import annotations

import logging
from typing import Dict, Optional

from rag_guard.config import SanitizerConfig

logger = logging.getLogger("rag_guard.sanitizer.homoglyph")

# Common homoglyph mappings: confusable char → ASCII equivalent
# Covers Cyrillic, Greek, and other scripts that have Latin lookalikes
HOMOGLYPH_MAP: Dict[str, str] = {
    # Cyrillic → Latin
    "\u0410": "A",  # А
    "\u0412": "B",  # В
    "\u0421": "C",  # С
    "\u0415": "E",  # Е
    "\u041d": "H",  # Н
    "\u041a": "K",  # К
    "\u041c": "M",  # М
    "\u041e": "O",  # О
    "\u0420": "P",  # Р
    "\u0422": "T",  # Т
    "\u0425": "X",  # Х
    "\u0430": "a",  # а
    "\u0435": "e",  # е
    "\u043e": "o",  # о
    "\u0440": "p",  # р
    "\u0441": "c",  # с
    "\u0443": "y",  # у
    "\u0445": "x",  # х
    "\u0455": "s",  # ѕ
    "\u0456": "i",  # і
    "\u0458": "j",  # ј
    # Greek → Latin
    "\u0391": "A",  # Α
    "\u0392": "B",  # Β
    "\u0395": "E",  # Ε
    "\u0396": "Z",  # Ζ
    "\u0397": "H",  # Η
    "\u0399": "I",  # Ι
    "\u039a": "K",  # Κ
    "\u039c": "M",  # Μ
    "\u039d": "N",  # Ν
    "\u039f": "O",  # Ο
    "\u03a1": "P",  # Ρ
    "\u03a4": "T",  # Τ
    "\u03a5": "Y",  # Υ
    "\u03a7": "X",  # Χ
    "\u03bf": "o",  # ο
    "\u03b1": "a",  # α (loosely)
    # Fullwidth → ASCII
    "\uff21": "A",
    "\uff22": "B",
    "\uff23": "C",
    "\uff24": "D",
    "\uff25": "E",
    "\uff26": "F",
    "\uff27": "G",
    "\uff28": "H",
    "\uff29": "I",
    "\uff2a": "J",
    "\uff2b": "K",
    "\uff2c": "L",
    "\uff2d": "M",
    "\uff2e": "N",
    "\uff2f": "O",
    "\uff30": "P",
    "\uff31": "Q",
    "\uff32": "R",
    "\uff33": "S",
    "\uff34": "T",
    "\uff35": "U",
    "\uff36": "V",
    "\uff37": "W",
    "\uff38": "X",
    "\uff39": "Y",
    "\uff3a": "Z",
    "\uff41": "a",
    "\uff42": "b",
    "\uff43": "c",
    "\uff44": "d",
    "\uff45": "e",
    "\uff46": "f",
    "\uff47": "g",
    "\uff48": "h",
    "\uff49": "i",
    "\uff4a": "j",
    "\uff4b": "k",
    "\uff4c": "l",
    "\uff4d": "m",
    "\uff4e": "n",
    "\uff4f": "o",
    "\uff50": "p",
    "\uff51": "q",
    "\uff52": "r",
    "\uff53": "s",
    "\uff54": "t",
    "\uff55": "u",
    "\uff56": "v",
    "\uff57": "w",
    "\uff58": "x",
    "\uff59": "y",
    "\uff5a": "z",
}

# Build a translation table for fast substitution
_TRANS_TABLE = str.maketrans(HOMOGLYPH_MAP)


class HomoglyphCanonicalizer:
    """Normalizes homoglyphs to their ASCII equivalents.

    Detects and replaces visually identical characters from Cyrillic,
    Greek, and fullwidth Unicode ranges that attackers use to bypass
    text filters while appearing identical to humans.
    """

    def __init__(
        self,
        config: SanitizerConfig | None = None,
        extra_mappings: Dict[str, str] | None = None,
    ) -> None:
        self.config = config or SanitizerConfig()
        self._trans_table = _TRANS_TABLE
        if extra_mappings:
            extended = dict(HOMOGLYPH_MAP)
            extended.update(extra_mappings)
            self._trans_table = str.maketrans(extended)

    def canonicalize(self, text: str) -> str:
        """Replace all known homoglyphs with ASCII equivalents."""
        if not self.config.canonicalize_homoglyphs:
            return text
        result = text.translate(self._trans_table)
        if result != text:
            count = sum(1 for a, b in zip(text, result) if a != b)
            logger.warning("Homoglyph: canonicalized %d characters", count)
        return result

    def detect_homoglyphs(self, text: str) -> Dict[str, int]:
        """Detect homoglyphs without modifying text. Returns {char: count}."""
        found: Dict[str, int] = {}
        for ch in text:
            if ch in HOMOGLYPH_MAP:
                found[ch] = found.get(ch, 0) + 1
        return found

    def has_homoglyphs(self, text: str) -> bool:
        """Quick check: does text contain any known homoglyphs?"""
        return any(ch in HOMOGLYPH_MAP for ch in text)

    @property
    def known_homoglyphs(self) -> int:
        """Number of homoglyph mappings registered."""
        return len(HOMOGLYPH_MAP)
