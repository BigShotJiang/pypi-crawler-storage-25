"""HTML sanitizer — strips scripts, CSS, hidden elements, and comments."""

from __future__ import annotations

import logging
import re
from typing import Optional

from rag_guard.config import SanitizerConfig

logger = logging.getLogger("rag_guard.sanitizer.html")

SCRIPT_RE = re.compile(r"<script[\s\S]*?</script>", re.IGNORECASE)
STYLE_RE = re.compile(r"<style[\s\S]*?</style>", re.IGNORECASE)
COMMENT_RE = re.compile(r"<!--[\s\S]*?-->")
HIDDEN_CSS_RE = re.compile(
    r'(?:display\s*:\s*none|visibility\s*:\s*hidden|opacity\s*:\s*0'
    r'|font-size\s*:\s*0|color\s*:\s*(?:transparent|rgba\s*\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*0\s*\)))',
    re.IGNORECASE,
)
HIDDEN_ELEMENT_RE = re.compile(
    r'<[^>]+(?:style\s*=\s*["\'][^"\']*(?:display\s*:\s*none|visibility\s*:\s*hidden|opacity\s*:\s*0|font-size\s*:\s*0)[^"\']*["\'])[^>]*>[\s\S]*?</[^>]+>',
    re.IGNORECASE,
)
TAG_RE = re.compile(r"<[^>]+>")
ON_EVENT_RE = re.compile(r'\s+on\w+\s*=\s*["\'][^"\']*["\']', re.IGNORECASE)
IFRAME_RE = re.compile(r"<iframe[\s\S]*?(?:</iframe>|/>)", re.IGNORECASE)
OBJECT_RE = re.compile(r"<object[\s\S]*?(?:</object>|/>)", re.IGNORECASE)
EMBED_RE = re.compile(r"<embed[\s\S]*?(?:</embed>|/>)", re.IGNORECASE)


class HTMLSanitizer:
    """Strips dangerous HTML constructs that can hide prompt injections.

    Targets: script tags, style tags, HTML comments, hidden CSS elements,
    iframe/object/embed, and inline event handlers.
    """

    def __init__(self, config: SanitizerConfig | None = None) -> None:
        self.config = config or SanitizerConfig()

    def sanitize(self, html: str) -> str:
        """Strip dangerous HTML while preserving visible text content."""
        original_len = len(html)

        # Remove script tags
        if self.config.strip_html_scripts:
            html = SCRIPT_RE.sub("", html)

        # Remove style tags
        html = STYLE_RE.sub("", html)

        # Remove HTML comments (common injection vector)
        if self.config.strip_html_comments:
            html = COMMENT_RE.sub("", html)

        # Remove hidden CSS elements
        if self.config.strip_hidden_css:
            html = HIDDEN_ELEMENT_RE.sub("", html)

        # Remove iframe, object, embed tags
        html = IFRAME_RE.sub("", html)
        html = OBJECT_RE.sub("", html)
        html = EMBED_RE.sub("", html)

        # Remove inline event handlers (onclick, onload, etc.)
        html = ON_EVENT_RE.sub("", html)

        removed = original_len - len(html)
        if removed > 0:
            logger.warning("HTML sanitized: removed %d chars", removed)

        return html

    def strip_all_tags(self, html: str) -> str:
        """Remove ALL HTML tags, returning plain text only."""
        html = self.sanitize(html)
        return TAG_RE.sub("", html).strip()

    def detect_hidden_content(self, html: str) -> bool:
        """Check if HTML contains hidden content patterns (without modifying)."""
        if COMMENT_RE.search(html):
            return True
        if HIDDEN_CSS_RE.search(html):
            return True
        if SCRIPT_RE.search(html):
            return True
        if IFRAME_RE.search(html):
            return True
        return False
