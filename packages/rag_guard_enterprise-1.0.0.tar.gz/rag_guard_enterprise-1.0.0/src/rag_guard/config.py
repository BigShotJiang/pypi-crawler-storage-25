"""Configuration for RAG Guard — thresholds, policies, and integration settings."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class SanitizerConfig:
    """Sanitizer module configuration."""
    mode: str = "strict"  # strict | permissive
    strip_zero_width: bool = True
    strip_pua: bool = True
    strip_bidi: bool = True
    strip_tag_chars: bool = True
    canonicalize_homoglyphs: bool = True
    normalize_unicode: bool = True  # NFC normalization
    collapse_whitespace: bool = True
    strip_html_scripts: bool = True
    strip_html_comments: bool = True
    strip_hidden_css: bool = True


@dataclass
class DetectorConfig:
    """Detector module configuration."""
    # Token anomaly thresholds
    zw_ratio_threshold: float = 0.01
    pua_count_threshold: int = 3
    bidi_count_threshold: int = 5

    # Embedding anomaly thresholds
    similarity_threshold: float = 0.92
    near_duplicate_threshold: float = 0.97
    cluster_density_max: int = 5
    outlier_z_score: float = 3.0

    # Prompt injection classifier
    classifier_threshold: float = 0.6
    classifier_model_path: Optional[str] = None

    # Tiered execution
    enable_token_scan: bool = True
    enable_embedding_scan: bool = True
    enable_classifier: bool = True
    enable_llm_guard: bool = False  # expensive — opt-in

    # Short-circuit: stop on first flag
    short_circuit: bool = True


@dataclass
class AlertConfig:
    """Alerting system configuration."""
    enabled: bool = True
    alert_on_severity: str = "medium"  # minimum severity to trigger alert
    webhook_url: Optional[str] = None
    webhook_headers: Dict[str, str] = field(default_factory=dict)
    email_recipients: List[str] = field(default_factory=list)
    smtp_host: Optional[str] = None
    smtp_port: int = 587
    smtp_user: Optional[str] = None
    smtp_password: Optional[str] = None
    log_alerts: bool = True
    max_alerts_per_minute: int = 100  # rate limiting
    callback: Any = None  # callable(AlertEvent) for custom handlers


@dataclass
class TelemetryConfig:
    """Telemetry/monitoring configuration."""
    enabled: bool = True
    log_format: str = "json"  # json | text
    log_level: str = "WARNING"
    metrics_enabled: bool = False
    metrics_port: int = 9090
    siem_enabled: bool = False
    siem_endpoint: Optional[str] = None


@dataclass
class GuardConfig:
    """Top-level RAG Guard configuration."""
    # Sub-configs
    sanitizer: SanitizerConfig = field(default_factory=SanitizerConfig)
    detector: DetectorConfig = field(default_factory=DetectorConfig)
    alert: AlertConfig = field(default_factory=AlertConfig)
    telemetry: TelemetryConfig = field(default_factory=TelemetryConfig)

    # Global policies
    fail_policy: str = "closed"  # closed (block on error) | open (allow on error)
    quarantine_enabled: bool = True

    # Convenience shortcuts
    alert_webhook: Optional[str] = None  # shortcut for alert.webhook_url

    def __post_init__(self) -> None:
        if self.alert_webhook and not self.alert.webhook_url:
            self.alert.webhook_url = self.alert_webhook

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GuardConfig":
        """Create config from a dictionary (e.g. Django settings, YAML)."""
        sanitizer = SanitizerConfig(**data.get("sanitizer", {}))
        detector = DetectorConfig(**data.get("detector", {}))
        alert = AlertConfig(**data.get("alert", {}))
        telemetry = TelemetryConfig(**data.get("telemetry", {}))
        return cls(
            sanitizer=sanitizer,
            detector=detector,
            alert=alert,
            telemetry=telemetry,
            fail_policy=data.get("fail_policy", "closed"),
            quarantine_enabled=data.get("quarantine_enabled", True),
            alert_webhook=data.get("alert_webhook"),
        )
