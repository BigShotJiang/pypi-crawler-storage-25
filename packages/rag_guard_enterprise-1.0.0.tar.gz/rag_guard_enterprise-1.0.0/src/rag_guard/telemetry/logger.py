"""Structured JSON logger for RAG Guard events."""

from __future__ import annotations

import json
import logging
import sys
import time
from typing import Any, Dict, Optional

from rag_guard.config import TelemetryConfig


class JSONFormatter(logging.Formatter):
    """Formats log records as JSON lines for SIEM ingestion."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if hasattr(record, "extra_data"):
            log_entry["data"] = record.extra_data
        if record.exc_info and record.exc_info[1]:
            log_entry["exception"] = str(record.exc_info[1])
        return json.dumps(log_entry, default=str)


class StructuredLogger:
    """Provides structured logging with JSON output for RAG Guard.

    All security events are logged with structured fields for easy
    parsing by SIEM systems (Elastic, Splunk, Datadog).
    """

    def __init__(self, config: TelemetryConfig | None = None) -> None:
        self.config = config or TelemetryConfig()
        self._logger = logging.getLogger("rag_guard")

        if not self._logger.handlers:
            handler = logging.StreamHandler(sys.stderr)
            if self.config.log_format == "json":
                handler.setFormatter(JSONFormatter())
            else:
                handler.setFormatter(
                    logging.Formatter(
                        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
                    )
                )
            self._logger.addHandler(handler)

        self._logger.setLevel(getattr(logging, self.config.log_level.upper(), logging.WARNING))

    def log_detection(
        self,
        detector_name: str,
        flagged: bool,
        score: float,
        threat_type: Optional[str] = None,
        reason: str = "",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Log a detection event."""
        data = {
            "event_type": "detection",
            "detector": detector_name,
            "flagged": flagged,
            "score": score,
            "threat_type": threat_type,
            "reason": reason,
        }
        if details:
            data["details"] = details

        record = self._logger.makeRecord(
            self._logger.name,
            logging.WARNING if flagged else logging.INFO,
            "", 0, f"Detection: {detector_name} flagged={flagged}", (), None,
        )
        record.extra_data = data  # type: ignore[attr-defined]
        self._logger.handle(record)

    def log_alert(
        self,
        alert_id: str,
        severity: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Log an alert event."""
        data = {
            "event_type": "alert",
            "alert_id": alert_id,
            "severity": severity,
            "message": message,
        }
        if details:
            data["details"] = details

        level = logging.CRITICAL if severity in ("critical", "high") else logging.WARNING
        record = self._logger.makeRecord(
            self._logger.name, level,
            "", 0, f"ALERT [{severity.upper()}]: {message}", (), None,
        )
        record.extra_data = data  # type: ignore[attr-defined]
        self._logger.handle(record)

    def log_sanitization(
        self,
        chars_removed: int,
        categories: Dict[str, int],
    ) -> None:
        """Log a sanitization event."""
        data = {
            "event_type": "sanitization",
            "chars_removed": chars_removed,
            "categories": categories,
        }
        record = self._logger.makeRecord(
            self._logger.name, logging.INFO,
            "", 0, f"Sanitized: removed {chars_removed} chars", (), None,
        )
        record.extra_data = data  # type: ignore[attr-defined]
        self._logger.handle(record)
