"""Metrics collector for monitoring detection rates, latency, and false positives."""

from __future__ import annotations

import threading
import time
from collections import defaultdict
from typing import Any, Dict, Optional

from rag_guard.config import TelemetryConfig


class MetricsCollector:
    """Thread-safe metrics collector for RAG Guard.

    Tracks:
    - Detection counts by threat type
    - Alert counts by severity
    - Latency histograms per detector
    - False positive tracking
    - Sanitization stats

    Can optionally export to Prometheus via prometheus_client.
    """

    def __init__(self, config: TelemetryConfig | None = None) -> None:
        self.config = config or TelemetryConfig()
        self._lock = threading.Lock()
        self._counters: Dict[str, int] = defaultdict(int)
        self._latencies: Dict[str, list] = defaultdict(list)
        self._start_time = time.time()

    def inc(self, metric: str, value: int = 1) -> None:
        """Increment a counter metric."""
        with self._lock:
            self._counters[metric] += value

    def record_latency(self, detector: str, latency_ms: float) -> None:
        """Record a latency measurement for a detector."""
        with self._lock:
            bucket = self._latencies[detector]
            bucket.append(latency_ms)
            # Keep last 10000 measurements
            if len(bucket) > 10000:
                self._latencies[detector] = bucket[-5000:]

    def record_detection(
        self,
        flagged: bool,
        threat_type: Optional[str] = None,
        detector: str = "",
        latency_ms: float = 0.0,
    ) -> None:
        """Record a detection event."""
        self.inc("detections_total")
        if flagged:
            self.inc("detections_flagged")
            if threat_type:
                self.inc(f"detections_by_type.{threat_type}")
        else:
            self.inc("detections_clean")
        if detector and latency_ms > 0:
            self.record_latency(detector, latency_ms)

    def record_alert(self, severity: str) -> None:
        """Record an alert event."""
        self.inc("alerts_total")
        self.inc(f"alerts_by_severity.{severity}")

    def record_sanitization(self, chars_removed: int) -> None:
        """Record a sanitization event."""
        self.inc("sanitizations_total")
        self.inc("chars_removed_total", chars_removed)

    def get_stats(self) -> Dict[str, Any]:
        """Get current metrics snapshot."""
        with self._lock:
            stats: Dict[str, Any] = {
                "uptime_seconds": time.time() - self._start_time,
                "counters": dict(self._counters),
            }
            # Compute latency percentiles
            latency_stats = {}
            for detector, values in self._latencies.items():
                if values:
                    sorted_v = sorted(values)
                    n = len(sorted_v)
                    latency_stats[detector] = {
                        "count": n,
                        "mean_ms": sum(sorted_v) / n,
                        "p50_ms": sorted_v[n // 2],
                        "p95_ms": sorted_v[int(n * 0.95)],
                        "p99_ms": sorted_v[int(n * 0.99)],
                        "max_ms": sorted_v[-1],
                    }
            stats["latency"] = latency_stats
            return stats

    def reset(self) -> None:
        """Reset all metrics."""
        with self._lock:
            self._counters.clear()
            self._latencies.clear()
            self._start_time = time.time()
