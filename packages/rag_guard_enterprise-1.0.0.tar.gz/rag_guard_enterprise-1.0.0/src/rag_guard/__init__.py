"""
RAG Guard — Enterprise Data Poisoning Detection & Alerting Library

Protects RAG (Retrieval-Augmented Generation) systems against:
- Invisible Unicode injection (zero-width, PUA, bidi controls)
- Homoglyph obfuscation attacks
- HTML/CSS hidden text injection
- Prompt injection (direct & indirect)
- Data poisoning & backdoor attacks
- Agent tool hijacking

Usage:
    from rag_guard import RAGGuard, GuardConfig

    guard = RAGGuard(GuardConfig(alert_webhook="https://..."))
    result = guard.scan_text("user input here")
    if result.flagged:
        print(f"ALERT: {result.threat_type} — {result.reason}")
"""

__version__ = "1.0.0"
__all__ = [
    "RAGGuard",
    "GuardConfig",
    "DetectionResult",
    "GuardResult",
    "ThreatType",
    "Severity",
    "AlertEvent",
    "AlertManager",
]

from rag_guard.types import (
    DetectionResult,
    GuardResult,
    ThreatType,
    Severity,
    AlertEvent,
)
from rag_guard.config import GuardConfig
from rag_guard.alerting import AlertManager
from rag_guard.core import RAGGuard
