"""Tests for the alerting system — dispatch, rate limiting, dedup, history."""

import time

import pytest

from rag_guard.alerting import AlertManager
from rag_guard.config import AlertConfig, GuardConfig
from rag_guard.types import (
    AlertEvent,
    DetectionResult,
    Severity,
    ThreatType,
)


class TestAlertManager:
    def setup_method(self):
        self.config = AlertConfig(
            enabled=True,
            alert_on_severity="medium",
            log_alerts=False,  # suppress log noise in tests
            max_alerts_per_minute=10,
        )
        self.manager = AlertManager(config=self.config)

    def _make_detection(
        self,
        flagged=True,
        score=0.9,
        threat_type=ThreatType.DATA_POISONING,
    ):
        return DetectionResult(
            flagged=flagged,
            score=score,
            threat_type=threat_type,
            reason="test_detection",
            detector_name="test",
        )

    def test_alert_from_detection_dispatched(self):
        detection = self._make_detection()
        event = self.manager.alert_from_detection(detection, source="test")
        assert event is not None
        assert event.severity == Severity.CRITICAL
        assert event.threat_type == ThreatType.DATA_POISONING
        assert "data_poisoning" in event.message

    def test_clean_detection_no_alert(self):
        detection = self._make_detection(flagged=False)
        event = self.manager.alert_from_detection(detection)
        assert event is None

    def test_below_severity_threshold_no_alert(self):
        config = AlertConfig(enabled=True, alert_on_severity="critical")
        manager = AlertManager(config=config)
        # MEDIUM severity should not trigger
        detection = DetectionResult(
            flagged=True,
            score=0.5,
            threat_type=ThreatType.CORPUS_OUTLIER,  # MEDIUM severity
            reason="test",
            detector_name="test",
        )
        event = manager.alert_from_detection(detection)
        assert event is None

    def test_alert_disabled(self):
        config = AlertConfig(enabled=False)
        manager = AlertManager(config=config)
        detection = self._make_detection()
        event = manager.alert_from_detection(detection)
        assert event is None

    def test_alert_history(self):
        for i in range(5):
            detection = DetectionResult(
                flagged=True,
                score=0.8,
                threat_type=ThreatType.ZERO_WIDTH,
                reason=f"test_{i}",
                detector_name="test",
            )
            # Clear dedup cache so each alert goes through
            self.manager._dedup_cache.clear()
            self.manager.alert_from_detection(detection, source=f"src_{i}")

        history = self.manager.get_history()
        assert len(history) == 5
        assert self.manager.alert_count == 5

    def test_rate_limiting(self):
        config = AlertConfig(
            enabled=True,
            log_alerts=False,
            max_alerts_per_minute=3,
        )
        manager = AlertManager(config=config)

        dispatched = 0
        for i in range(10):
            event = AlertEvent(
                threat_type=ThreatType.PROMPT_INJECTION,
                severity=Severity.CRITICAL,
                source=f"unique_source_{i}",
                message=f"test_{i}",
            )
            result = manager.dispatch(event)
            if result:
                dispatched += 1

        assert dispatched == 3  # rate limited after 3

    def test_deduplication(self):
        detection = self._make_detection()
        # Same source + threat_type should be deduplicated
        event1 = self.manager.alert_from_detection(detection, source="same_src")
        event2 = self.manager.alert_from_detection(detection, source="same_src")
        assert event1 is not None
        assert event2 is None  # deduplicated

    def test_different_sources_not_deduped(self):
        detection = self._make_detection()
        event1 = self.manager.alert_from_detection(detection, source="src_a")
        event2 = self.manager.alert_from_detection(detection, source="src_b")
        assert event1 is not None
        assert event2 is not None

    def test_custom_callback(self):
        received = []

        def my_callback(event: AlertEvent):
            received.append(event)

        self.manager.register_callback(my_callback)
        detection = self._make_detection()
        self.manager.alert_from_detection(detection, source="callback_test")
        assert len(received) == 1
        assert received[0].threat_type == ThreatType.DATA_POISONING

    def test_callback_via_config(self):
        received = []
        config = AlertConfig(
            enabled=True,
            log_alerts=False,
            callback=lambda e: received.append(e),
        )
        manager = AlertManager(config=config)
        detection = self._make_detection()
        manager.alert_from_detection(detection, source="cfg_callback")
        assert len(received) == 1

    def test_history_filter_by_severity(self):
        self.manager._dedup_cache.clear()
        # Add CRITICAL alert
        d1 = self._make_detection(threat_type=ThreatType.DATA_POISONING)
        self.manager.alert_from_detection(d1, source="s1")
        # Add HIGH alert
        d2 = DetectionResult(
            flagged=True, score=0.7,
            threat_type=ThreatType.BIDI,
            reason="test", detector_name="test",
        )
        self.manager.alert_from_detection(d2, source="s2")

        critical_only = self.manager.get_history(severity="critical")
        assert all(a.severity == Severity.CRITICAL for a in critical_only)

    def test_clear_history(self):
        detection = self._make_detection()
        self.manager.alert_from_detection(detection, source="clear_test")
        assert self.manager.alert_count > 0
        self.manager.clear_history()
        assert self.manager.alert_count == 0

    def test_alert_event_to_dict(self):
        detection = self._make_detection()
        event = self.manager.alert_from_detection(detection, source="dict_test")
        d = event.to_dict()
        assert "alert_id" in d
        assert d["severity"] == "critical"
        assert d["threat_type"] == "data_poisoning"

    def test_guard_config_shortcut(self):
        config = GuardConfig(alert_webhook="https://example.com/hook")
        manager = AlertManager(config=config)
        assert manager._config.webhook_url == "https://example.com/hook"
