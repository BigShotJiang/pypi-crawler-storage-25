"""Upload Python scripts and wheels to Databricks."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import DatabricksError, ResourceAlreadyExists
from databricks.sdk.service.workspace import ImportFormat

from databricks_job_runner.errors import RunnerError


def _ensure_volumes_prefix(path: str) -> str:
    """Prepend ``/Volumes`` if the path doesn't already start with it."""
    return path if path.startswith("/Volumes") else f"/Volumes{path}"


def upload_file(ws: WorkspaceClient, local_path: Path, remote_path: str) -> None:
    """Upload a single file to the Databricks workspace.

    Handles FILE-vs-NOTEBOOK type mismatches by deleting the existing
    object and re-uploading, since the workspace API cannot overwrite
    across object types.
    """
    print(f"Uploading: {local_path.name} -> {remote_path}")
    content = local_path.read_bytes()
    try:
        ws.workspace.upload(
            path=remote_path,
            content=content,
            format=ImportFormat.AUTO,
            overwrite=True,
        )
    except DatabricksError as exc:
        if "type mismatch" in str(exc).lower():
            ws.workspace.delete(path=remote_path)
            ws.workspace.upload(
                path=remote_path,
                content=content,
                format=ImportFormat.AUTO,
                overwrite=True,
            )
        else:
            raise
    print("  Done.")


def ensure_remote_dirs(
    ws: WorkspaceClient, workspace_dir: str, scripts_dir: str = "agent_modules"
) -> None:
    """Create the workspace and scripts directories if needed."""
    ws.workspace.mkdirs(workspace_dir)
    ws.workspace.mkdirs(f"{workspace_dir}/{scripts_dir}")


def upload_agent_modules(
    ws: WorkspaceClient,
    agent_modules_dir: Path,
    workspace_dir: str,
    scripts_dir: str = "agent_modules",
    extra_files: list[tuple[Path, str]] | None = None,
) -> None:
    """Upload all .py files from the scripts directory, plus any extra files.

    *extra_files* is a list of ``(local_path, remote_filename)`` pairs. Each
    file is uploaded into the same remote scripts directory alongside the
    Python scripts.  Use this to co-locate non-Python assets (e.g. ``.sql``
    schema files) that job scripts read via ``Path(__file__).parent``.
    """
    ensure_remote_dirs(ws, workspace_dir, scripts_dir)
    remote_dir = f"{workspace_dir}/{scripts_dir}"
    for f in sorted(agent_modules_dir.glob("*.py")):
        upload_file(ws, f, f"{remote_dir}/{f.name}")
    for local_path, remote_name in (extra_files or []):
        upload_file(ws, local_path, f"{remote_dir}/{remote_name}")


def find_latest_wheel(dist_dir: Path, wheel_package: str) -> Path | None:
    """Return the most recently built wheel for *wheel_package* in *dist_dir*.

    Uses PEP 625 name normalisation (hyphens become underscores) and sorts
    by mtime descending so the newest build wins.
    """
    glob_name = wheel_package.replace("-", "_")
    wheels = sorted(
        dist_dir.glob(f"{glob_name}-*.whl"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return wheels[0] if wheels else None


def _bump_patch_version(project_dir: Path) -> str:
    """Increment the patch version in pyproject.toml and return the new version."""
    pyproject = project_dir / "pyproject.toml"
    content = pyproject.read_text()
    match = re.search(r'^(version = ")(\d+)\.(\d+)\.(\d+)(")', content, re.MULTILINE)
    if not match:
        raise RunnerError("Could not find version = \"x.y.z\" in pyproject.toml")
    prefix, major, minor, patch, suffix = match.groups()
    new_version = f"{major}.{minor}.{int(patch) + 1}"
    pyproject.write_text(content[: match.start()] + f'{prefix}{new_version}{suffix}' + content[match.end() :])
    return new_version


def build_and_upload_wheel(
    ws: WorkspaceClient,
    project_dir: Path,
    wheel_volume_dir: str,
    wheel_package: str,
) -> None:
    """Build a Python wheel with ``uv build`` and upload it to a UC Volume."""
    if not wheel_volume_dir:
        raise RunnerError(
            "volume path not set in .env — cannot determine wheel upload path."
        )

    dist_dir = project_dir / "dist"

    new_version = _bump_patch_version(project_dir)
    print(f"Building {wheel_package} wheel (v{new_version})...")
    # ``--out-dir dist`` forces output into project_dir/dist even when the
    # project is a uv workspace member (where the default is the workspace
    # root's dist/).  Matches what find_latest_wheel() looks for below.
    subprocess.run(
        ["uv", "build", "--wheel", "--quiet", "--out-dir", "dist"],
        cwd=project_dir,
        check=True,
    )

    whl = find_latest_wheel(dist_dir, wheel_package)
    if whl is None:
        glob_name = wheel_package.replace("-", "_")
        raise RunnerError(f"wheel build failed — no {glob_name}-*.whl found in dist/")

    # Ensure the path starts with /Volumes for the Files API
    volume_path = _ensure_volumes_prefix(wheel_volume_dir)
    dest = f"{volume_path}/{whl.name}"

    print(f"Uploading: {whl.name} -> {dest}")
    try:
        ws.files.create_directory(volume_path)
    except ResourceAlreadyExists:
        pass

    with whl.open("rb") as fh:
        ws.files.upload(file_path=dest, contents=fh, overwrite=True)
    print("  Done.")


_DEFAULT_EXCLUDE_DIRS = frozenset({
    ".venv", "venv", "__pycache__", ".git", ".tox", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", "node_modules", ".eggs",
})

_DEFAULT_EXCLUDE_FILES = frozenset({
    ".env", ".env.local", ".env.production", ".env.development",
    ".gitignore", ".gitattributes", ".DS_Store",
    "credentials.json", "secrets.json", "token.json",
})

_DEFAULT_EXCLUDE_PREFIXES = (".env.",)


def _is_excluded_file(name: str) -> bool:
    """Return True if *name* matches a sensitive-file pattern."""
    if name in _DEFAULT_EXCLUDE_FILES:
        return True
    return name.startswith(_DEFAULT_EXCLUDE_PREFIXES)


def upload_data_to_volume(
    ws: WorkspaceClient,
    local_dir: Path,
    volume_path: str,
    *,
    exclude_dirs: set[str] | None = None,
) -> None:
    """Upload a local directory tree to a UC Volume, preserving structure.

    Walks *local_dir* recursively and uploads every file to
    ``{volume_path}/{relative_path}``.  Creates subdirectories as needed
    via the Files API.

    Directories whose names appear in *exclude_dirs* (or the built-in
    default set) are silently skipped.  Sensitive files (``.env``,
    ``credentials.json``, etc.) are also skipped regardless of location.
    """
    volume_path = _ensure_volumes_prefix(volume_path)
    excluded = exclude_dirs if exclude_dirs is not None else _DEFAULT_EXCLUDE_DIRS

    # Collect all files and the set of directories to create
    dirs_created: set[str] = set()

    for local_file in sorted(local_dir.rglob("*")):
        if not local_file.is_file():
            continue

        rel = local_file.relative_to(local_dir)

        # Skip files inside excluded directories
        if excluded & set(rel.parts[:-1]):
            continue

        # Skip sensitive files
        if _is_excluded_file(local_file.name):
            print(f"  [skipped] {rel}")
            continue

        rel = local_file.relative_to(local_dir)
        remote_file = f"{volume_path}/{rel}"

        # Ensure parent directory exists
        remote_parent = (
            f"{volume_path}/{rel.parent}" if str(rel.parent) != "." else volume_path
        )
        if remote_parent not in dirs_created:
            try:
                ws.files.create_directory(remote_parent)
            except ResourceAlreadyExists:
                pass
            dirs_created.add(remote_parent)

        print(f"  {rel} -> {remote_file}")
        with local_file.open("rb") as fh:
            ws.files.upload(file_path=remote_file, contents=fh, overwrite=True)
