"""List workspace contents and verify uploaded files."""

from __future__ import annotations

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound

from databricks_job_runner.errors import RunnerError


def list_workspace(
    ws: WorkspaceClient, workspace_dir: str, scripts_dir: str = "agent_modules"
) -> None:
    """List the remote workspace directory and its scripts subdir.

    Raises :class:`RunnerError` if *workspace_dir* does not exist.
    """
    print(f"Listing workspace: {workspace_dir}")
    print("---")
    try:
        entries = list(ws.workspace.list(workspace_dir))
    except NotFound as exc:
        raise RunnerError(
            f"Remote directory {workspace_dir} does not exist.\n"
            "Run `python -m cli upload --all` first to create it."
        ) from exc
    for entry in entries:
        print(f"  {entry.path}")

    print()
    print(f"Listing: {workspace_dir}/{scripts_dir}")
    print("---")
    try:
        for entry in ws.workspace.list(f"{workspace_dir}/{scripts_dir}"):
            print(f"  {entry.path}")
    except NotFound:
        print("  (empty or not created yet)")


def check_file_exists(
    ws: WorkspaceClient, workspace_dir: str, filename: str, scripts_dir: str = "agent_modules"
) -> None:
    """Verify a specific file exists under ``{workspace_dir}/{scripts_dir}/``.

    Raises :class:`RunnerError` if the file is not found.
    """
    path = f"{workspace_dir}/{scripts_dir}/{filename}"
    print()
    print(f"Checking: {path}")
    try:
        ws.workspace.get_status(path)
    except NotFound as exc:
        raise RunnerError(f"{path} not found.") from exc
    print("  Found.")
