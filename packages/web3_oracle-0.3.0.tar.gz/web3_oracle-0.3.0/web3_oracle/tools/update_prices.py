#!/usr/bin/env python3
"""
Price Data Updater

Updates ETH/BTC historical daily prices via Binance API,
and refreshes altcoin reference prices via CoinGecko API.

Usage:
    python -m web3_oracle.tools.update_prices [--skip-eth-btc] [--skip-altcoins]
"""

import argparse
import csv
import os
import sys
import time
import logging
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import requests

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

DATA_DIR = Path(os.path.dirname(os.path.abspath(__file__))).parent / 'data'

BINANCE_KLINES_URL = "https://api.binance.com/api/v3/klines"
DEFILLAMA_PRICES_URL = "https://coins.llama.fi/prices/current"

# Batch size for DeFiLlama token price queries (generous free tier)
DEFILLAMA_BATCH_SIZE = 100
# Delay between DeFiLlama batches (conservative, API is free and generous)
DEFILLAMA_BATCH_DELAY = 0.5  # seconds


def fetch_binance_daily(symbol: str, start_ts: int, end_ts: int) -> list[tuple[int, float, float]]:
    """
    Fetch daily OHLCV from Binance between start_ts and end_ts (unix seconds).
    Returns list of (timestamp_seconds, close_price, volume).
    """
    results = []
    start_ms = start_ts * 1000
    end_ms = end_ts * 1000

    while start_ms < end_ms:
        params = {
            "symbol": symbol,
            "interval": "1d",
            "startTime": start_ms,
            "endTime": end_ms,
            "limit": 1000,
        }
        resp = requests.get(BINANCE_KLINES_URL, params=params, timeout=30)
        resp.raise_for_status()
        candles = resp.json()

        if not candles:
            break

        for c in candles:
            open_time_ms = int(c[0])
            close_price = float(c[4])
            volume = float(c[5])
            results.append((open_time_ms // 1000, close_price, volume))

        last_open_ms = int(candles[-1][0])
        if last_open_ms <= start_ms:
            break
        start_ms = last_open_ms + 86400 * 1000  # move past the last candle

    return results


def update_eth_btc_prices():
    """Append missing ETH and BTC daily prices using Binance API."""
    pairs = [
        ("ETHUSDT", DATA_DIR / "ethereum_prices.csv"),
        ("BTCUSDT", DATA_DIR / "bitcoin_prices.csv"),
    ]

    for symbol, csv_path in pairs:
        logger.info(f"Updating {csv_path.name} ...")

        df = pd.read_csv(csv_path)
        df = df.sort_values("timestamp")
        latest_ts = int(df["timestamp"].max())
        logger.info(f"  Current latest: {datetime.fromtimestamp(latest_ts, tz=timezone.utc).date()}")

        # Start from the day after the latest record
        start_ts = latest_ts + 86400
        end_ts = int(datetime.now(tz=timezone.utc).timestamp())

        if start_ts >= end_ts:
            logger.info(f"  Already up to date, skipping.")
            continue

        logger.info(f"  Fetching {symbol} from {datetime.fromtimestamp(start_ts, tz=timezone.utc).date()} ...")
        new_rows = fetch_binance_daily(symbol, start_ts, end_ts)

        if not new_rows:
            logger.info(f"  No new data returned.")
            continue

        # Filter out any timestamps already in the file
        existing_ts = set(df["timestamp"].astype(int).tolist())
        new_rows = [(ts, price, vol) for ts, price, vol in new_rows if ts not in existing_ts]

        if not new_rows:
            logger.info(f"  All fetched rows already present.")
            continue

        new_df = pd.DataFrame(new_rows, columns=["timestamp", "price", "volume"])
        combined = pd.concat([df, new_df], ignore_index=True)
        combined = combined.sort_values("timestamp", ascending=False)
        combined.to_csv(csv_path, index=False)
        logger.info(f"  Added {len(new_rows)} new rows. Latest: {datetime.fromtimestamp(new_rows[-1][0], tz=timezone.utc).date()}")


def fetch_defillama_batch(addresses: list[str]) -> dict[str, float]:
    """
    Query DeFiLlama for current USD prices of a batch of ERC20 contract addresses.
    Returns {address_lower: price} for successfully found tokens.
    """
    coins = ",".join(f"ethereum:{addr}" for addr in addresses)
    url = f"{DEFILLAMA_PRICES_URL}/{coins}"
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    data = resp.json().get("coins", {})

    result = {}
    for key, info in data.items():
        # key format: "ethereum:0xaddr"
        addr = key.split(":")[-1].lower()
        if "price" in info and info["price"] is not None:
            result[addr] = float(info["price"])
    return result


def update_altcoin_prices():
    """Refresh reference prices for all tokens in altcoins_prices.csv via DeFiLlama."""
    csv_path = DATA_DIR / "altcoins_prices.csv"
    logger.info(f"Updating {csv_path.name} ...")

    df = pd.read_csv(csv_path)
    addresses = df["address"].str.lower().tolist()
    total = len(addresses)
    total_batches = (total + DEFILLAMA_BATCH_SIZE - 1) // DEFILLAMA_BATCH_SIZE
    logger.info(f"  {total} tokens to update, {total_batches} batches")

    updated_prices: dict[str, float] = {}
    failed_batches = 0

    for i in range(0, total, DEFILLAMA_BATCH_SIZE):
        batch = addresses[i:i + DEFILLAMA_BATCH_SIZE]
        batch_num = i // DEFILLAMA_BATCH_SIZE + 1

        try:
            prices = fetch_defillama_batch(batch)
            updated_prices.update(prices)
            logger.info(f"  Batch {batch_num}/{total_batches}: {len(prices)}/{len(batch)} prices fetched")
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 429:
                logger.warning(f"  Batch {batch_num}: rate limited, waiting 30s ...")
                time.sleep(30)
                try:
                    prices = fetch_defillama_batch(batch)
                    updated_prices.update(prices)
                    logger.info(f"  Batch {batch_num} retry: {len(prices)}/{len(batch)} prices fetched")
                except Exception as retry_err:
                    logger.error(f"  Batch {batch_num} retry failed: {retry_err}")
                    failed_batches += 1
            else:
                logger.error(f"  Batch {batch_num} HTTP error: {e}")
                failed_batches += 1
        except Exception as e:
            logger.error(f"  Batch {batch_num} error: {e}")
            failed_batches += 1

        if i + DEFILLAMA_BATCH_SIZE < total:
            time.sleep(DEFILLAMA_BATCH_DELAY)

    now_iso = datetime.now(tz=timezone.utc).isoformat()
    update_count = 0
    for idx, row in df.iterrows():
        addr = row["address"].lower()
        if addr in updated_prices:
            df.at[idx, "price"] = updated_prices[addr]
            df.at[idx, "timestamp"] = now_iso
            update_count += 1

    df.to_csv(csv_path, index=False)
    logger.info(f"  Updated {update_count}/{total} token prices. Failed batches: {failed_batches}")


def main():
    parser = argparse.ArgumentParser(description="Update web3_oracle price data")
    parser.add_argument("--skip-eth-btc", action="store_true", help="Skip ETH/BTC daily price update")
    parser.add_argument("--skip-altcoins", action="store_true", help="Skip altcoin reference price update")
    args = parser.parse_args()

    if not args.skip_eth_btc:
        update_eth_btc_prices()

    if not args.skip_altcoins:
        update_altcoin_prices()

    logger.info("Done.")


if __name__ == "__main__":
    main()
