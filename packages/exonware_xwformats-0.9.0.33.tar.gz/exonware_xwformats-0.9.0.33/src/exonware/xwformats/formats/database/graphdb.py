"""
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.33
Generation Date: November 2, 2025

GraphDB serialization - Graph database serialization.

Following I→A→XW pattern:
- I: ISerialization (interface)
- A: ASerialization (abstract base)
- XW: XWGraphDbSerializer (concrete implementation)
"""

from typing import Any

from exonware.xwsystem.io.serialization.base import ASerialization
from exonware.xwsystem.io.contracts import EncodeOptions, DecodeOptions
from exonware.xwsystem.io.defs import CodecCapability


class XWGraphDbSerializer(ASerialization):
    """GraphDB serializer - follows I→A→XW pattern."""
    
    @property
    def codec_id(self) -> str:
        return "graphdb"
    
    @property
    def media_types(self) -> list[str]:
        return ["application/x-graph"]
    
    @property
    def file_extensions(self) -> list[str]:
        return [".graph", ".graphdb"]
    
    @property
    def format_name(self) -> str:
        return "GraphDB"
    
    @property
    def mime_type(self) -> str:
        return "application/x-graph"
    
    @property
    def is_binary_format(self) -> bool:
        return True
    
    @property
    def supports_streaming(self) -> bool:
        return False
    
    @property
    def capabilities(self) -> CodecCapability:
        return CodecCapability.BIDIRECTIONAL
    
    @property
    def aliases(self) -> list[str]:
        return ["graphdb", "graph"]
    
    def encode(self, value: Any, *, options: EncodeOptions | None = None) -> bytes | str:
        """GraphDB encode requires database connection - use save_file() instead."""
        raise NotImplementedError("GraphDB requires database operations - use save_file()")
    
    def decode(self, repr: bytes | str, *, options: DecodeOptions | None = None) -> Any:
        """GraphDB decode requires database connection - use load_file() instead."""
        raise NotImplementedError("GraphDB requires database operations - use load_file()")


GraphDbSerializer = XWGraphDbSerializer

