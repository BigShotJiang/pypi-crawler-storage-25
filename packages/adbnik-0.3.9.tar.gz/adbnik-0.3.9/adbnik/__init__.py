__version__ = "0.3.9"
APP_TITLE = "Adbnik"
