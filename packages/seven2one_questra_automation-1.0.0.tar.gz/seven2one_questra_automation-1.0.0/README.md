# seven2one-questra-automation

Typsicherer Python Client für die Questra Automation GraphQL API.

## Features

- **Type-safe**: Vollständig typisierte GraphQL API
- **Authentication**: Integration mit questra-authentication
- **Umfassend**: Workspaces, Repositories, Schedules, Executions
- **Modern Python**: 3.10+ mit native Type Hints

## Installation

```bash
pip install seven2one-questra-automation
```

## Requirements

- Python >= 3.10
- seven2one-questra-authentication >= 0.2.1
- gql[all] >= 3.5.0

## Schnellstart

```python
from seven2one.questra.authentication import QuestraAuthentication
from seven2one.questra.automation import QuestraAutomation

auth = QuestraAuthentication(
    url="https://auth.example.com",
    username="ServiceUser",
    password="secret"
)

client = QuestraAutomation(
    graphql_url="https://example.com/automation/graphql",
    auth_client=auth
)

# Verfügbare API-Gruppen:
# client.queries - GraphQL Queries
# client.mutations - GraphQL Mutations
# client.execute_raw(query) - Custom GraphQL
```

## Weitere Informationen

- **Vollständige Dokumentation:** <https://pydocs.[questra-host.domain]>
- **Support:** <support@seven2one.de>

## License

Proprietary - Seven2one Informationssysteme GmbH
