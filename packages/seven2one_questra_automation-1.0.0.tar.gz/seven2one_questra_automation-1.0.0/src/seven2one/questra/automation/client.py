"""Main client class for Questra Automation."""

from __future__ import annotations

import logging
from collections.abc import Iterator
from datetime import datetime
from typing import Any

from seven2one.questra.authentication import QuestraAuthentication

from .generated.models import (
    AutomationExecutionView,
    AutomationView,
    ErrorCodeView,
    RepositoryView,
    ScheduledExecutionView,
    ScheduleView,
    WorkspaceView,
)
from .operations import MutationOperations, QueryOperations
from .transport import GraphQLTransport

logger = logging.getLogger(__name__)


class QuestraAutomation:
    """
    Client for Questra Automation GraphQL API.

    Uses to existing QuestraAuthentication for authentication
    and provides a type-safe interface to the Automation GraphQL API.

    Example:
        ```python
        from seven2one.questra.authentication import QuestraAuthentication
        from seven2one.questra.automation import QuestraAutomation, ExecutionInitiator

        # Create QuestraAuthentication
        auth_client = QuestraAuthentication(
            url="https://authentik.dev.example.com",
            username="ServiceUser",
            password="secret_password",
            oidc_discovery_paths=["/application/o/automation"],
        )

        # Initialize QuestraAutomation with QuestraAuthentication
        automation = QuestraAutomation(
            graphql_url="https://automation.dev.example.com/graphql",
            auth_client=auth_client,
        )

        # Use iterator methods for automatic pagination
        for workspace in automation.list_workspaces():
            print(f"Workspace: {workspace.name}")

        # Query with filter
        for execution in automation.list_executions(where={"status": {"eq": "FAILED"}}):
            print(f"Failed execution: {execution.id}")

        # Traditional query approach (single page)
        workspaces = automation.queries.get_workspaces(first=10)
        for workspace in workspaces.edges:
            print(f"Workspace: {workspace.node.name}")

        # Execute to automation
        result = automation.mutations.execute_automation(
            workspace_name="my-workspace",
            automation_path="scripts/my_automation.py",
            initiator_type=ExecutionInitiator.MANUAL,
            arguments=[{"name": "param1", "value": "value1"}],
        )
        print(f"Execution ID: {result.id}")
        ```
    """

    def __init__(
        self,
        graphql_url: str,
        auth_client: QuestraAuthentication,
    ):
        """
        Initialize the QuestraAutomation client.

        Args:
            graphql_url: URL of the GraphQL endpoint
            auth_client: Configured and authenticated QuestraAuthentication

        Raises:
            ValueError: If auth_client is not authenticated
        """
        logger.info("Initializing QuestraAutomation for URL: %s", graphql_url)

        self._graphql_url = graphql_url
        self._auth_client = auth_client

        if not self._auth_client.is_authenticated():
            logger.error("QuestraAuthentication is not authenticated")
            raise ValueError(
                "QuestraAuthentication is not authenticated. "
                "Please authenticate the client before passing it."
            )

        logger.debug("QuestraAuthentication authentication verified")

        self._transport = GraphQLTransport(
            url=graphql_url,
            get_access_token_func=self._auth_client.get_access_token,
        )

        self._queries = QueryOperations(execute_func=self._transport.execute)
        self._mutations = MutationOperations(execute_func=self._transport.execute)

        logger.info("QuestraAutomation initialized successfully")

    @property
    def queries(self) -> QueryOperations:
        """
        Access to query operations.

        Returns:
            QueryOperations instance for queries

        Example:
            ```python
            # Get all workspaces
            workspaces = client.queries.get_workspaces(first=10)

            # Get executions with filter
            executions = client.queries.get_executions(
                first=10,
                where={"status": {"eq": "SUCCEEDED"}},
            )

            # Get service info
            info = client.queries.get_service_info()
            print(f"Service: {info.name} v{info.version}")
            ```
        """
        return self._queries

    @property
    def mutations(self) -> MutationOperations:
        """
        Access to mutation operations.

        Returns:
            MutationOperations instance for mutations

        Example:
            ```python
            # Execute to automation
            result = client.mutations.execute_automation(
                workspace_name="my-workspace",
                automation_path="scripts/my_automation.py",
                initiator_type=ExecutionInitiator.MANUAL,
                arguments=[{"name": "param1", "value": "value1"}],
            )

            # Create a workspace
            workspace = client.mutations.create_workspace(
                repository_name="my-repo",
                name="my-workspace",
                branch_name="main",
                commit="abc123",
            )

            # Create a schedule
            schedule = client.mutations.create_schedule(
                workspace_name="my-workspace",
                automation_path="scripts/my_automation.py",
                name="daily-run",
                description="Run daily at midnight",
                cron="0 0 * * *",
                timezone="Europe/Berlin",
                active=True,
            )
            ```
        """
        return self._mutations

    def execute_raw(
        self, query: str, variables: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Execute a raw GraphQL query or mutation.

        Useful for custom operations that are not covered by the standard operations.

        Args:
            query: GraphQL query or mutation string
            variables: Optional variables

        Returns:
            dict: Raw result of the GraphQL operation

        Example:
            ```python
            result = client.execute_raw('''
                query {
                    automationServiceInfo {
                        name
                        version
                    }
                }
            ''')
            ```
        """
        logger.debug("Executing raw GraphQL operation via QuestraAutomation")
        return self._transport.execute(query, variables)

    def is_authenticated(self) -> bool:
        """
        Check if the client is authenticated.

        Returns:
            bool: True if authenticated, False otherwise
        """
        return self._auth_client.is_authenticated()

    def reauthenticate(self) -> None:
        """
        Force reauthentication.

        Useful for authentication problems or when credentials have changed.
        """
        logger.info("Forcing reauthentication")
        self._auth_client.reauthenticate()
        logger.info("Reauthentication completed")

    @property
    def graphql_url(self) -> str:
        """
        GraphQL endpoint URL.

        Returns:
            str: URL of the GraphQL endpoint
        """
        return self._graphql_url

    def list_automations(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 100,
    ) -> Iterator[AutomationView]:
        """
        Iterate over all automations with automatic pagination.

        Args:
            where: GraphQL filter conditions (AutomationViewFilterInput).
                Available fields:
                - `workspaceName`, `path`, `description`, `environment` (StringOperationFilterInput):
                  `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`, `startsWith`, `nstartsWith`,
                  `endsWith`, `nendsWith`, `and`, `or`
                - `allowParallelExecution` (BooleanOperationFilterInput): `eq`, `neq`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            AutomationView instances

        Example:
            ```python
            # Iterate over all automations
            for automation in client.list_automations():
                print(f"Automation: {automation.workspace_name}/{automation.path}")

            # Filter by workspace name (exact match)
            for automation in client.list_automations(
                where={"workspaceName": {"eq": "my-workspace"}}
            ):
                print(f"Path: {automation.path}")

            # Filter by path pattern
            for automation in client.list_automations(
                where={"path": {"startsWith": "/scripts/"}}
            ):
                print(f"Script: {automation.path}")

            # Filter by parallel execution capability
            for automation in client.list_automations(
                where={"allowParallelExecution": {"eq": True}}
            ):
                print(f"Parallel: {automation.path}")

            # Complex filter with AND
            for automation in client.list_automations(
                where={
                    "and": [
                        {"workspaceName": {"eq": "production"}},
                        {"path": {"contains": "daily"}},
                    ]
                }
            ):
                print(f"Daily automation: {automation.path}")
            ```
        """
        after = None
        while True:
            connection = self._queries.get_automations(
                first=page_size, after=after, where=where, order=order
            )
            if not connection.edges:
                break
            for edge in connection.edges:
                if edge.node is not None:
                    yield edge.node
            if connection.page_info is None or not connection.page_info.has_next_page:
                break
            after = connection.page_info.end_cursor

    def list_executions(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 100,
    ) -> Iterator[AutomationExecutionView]:
        """
        Iterate over all automation executions with automatic pagination.

        Args:
            where: GraphQL filter conditions (AutomationExecutionViewFilterInput).
                Available fields:
                - String fields (`branch`, `commit`, `workspaceName`, `repositoryName`,
                  `repositoryUrl`, `automationPath`, `environment`, `initiatorReference`,
                  `output`, `domainStatusMessage`): `eq`, `neq`, `in`, `nin`, `contains`,
                  `ncontains`, `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - `id` (UUID): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`, `ngte`,
                  `lt`, `nlt`, `lte`, `nlte`
                - DateTime fields (`createdAt`, `startedAt`, `finishedAt`): `eq`, `neq`,
                  `in`, `nin`, `gt`, `ngt`, `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - `duration` (TimeSpan): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            AutomationExecutionView instances

        Example:
            ```python
            # Iterate over all executions
            for execution in client.list_executions():
                print(f"Execution {execution.id}: {execution.status}")

            # Filter for failed executions
            for execution in client.list_executions(where={"status": {"eq": "FAILED"}}):
                print(f"Failed: {execution.automation_path}")

            # Filter by automation path pattern
            for execution in client.list_executions(
                where={"automationPath": {"startsWith": "/prod/"}}
            ):
                print(f"Production execution: {execution.id}")

            # Filter by date range
            from datetime import datetime, timedelta

            since = datetime.now() - timedelta(days=7)
            for execution in client.list_executions(
                where={"createdAt": {"gte": since.isoformat()}}
            ):
                print(f"Recent: {execution.id}")

            # Complex filter with AND
            for execution in client.list_executions(
                where={
                    "and": [
                        {"workspaceName": {"eq": "production"}},
                        {"status": {"eq": "SUCCESS"}},
                    ]
                }
            ):
                print(f"Successful production run: {execution.id}")
            ```
        """
        after = None
        while True:
            connection = self._queries.get_executions(
                first=page_size, after=after, where=where, order=order
            )
            if not connection.edges:
                break
            for edge in connection.edges:
                if edge.node is not None:
                    yield edge.node
            if connection.page_info is None or not connection.page_info.has_next_page:
                break
            after = connection.page_info.end_cursor

    def list_error_codes(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 100,
    ) -> Iterator[ErrorCodeView]:
        """
        Iterate over all error codes with automatic pagination.

        Args:
            where: GraphQL filter conditions (ErrorCodeViewFilterInput).
                Available fields:
                - `code` (StringOperationFilterInput): `eq`, `neq`, `in`, `nin`,
                  `contains`, `ncontains`, `startsWith`, `nstartsWith`, `endsWith`,
                  `nendsWith`, `and`, `or`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            ErrorCodeView instances

        Example:
            ```python
            # Iterate over all error codes
            for error_code in client.list_error_codes():
                print(f"Error {error_code.code}: {error_code.message_template}")

            # Filter by code pattern
            for error_code in client.list_error_codes(
                where={"code": {"startsWith": "SCHEDULE_"}}
            ):
                print(f"Error code: {error_code.code}")

            # Filter by exact codes
            for error_code in client.list_error_codes(
                where={
                    "code": {
                        "in": [
                            "AUTOMATION_ARGUMENT_DUPLICATE",
                            "AUTOMATION_ARGUMENT_INVALID",
                        ]
                    }
                }
            ):
                print(f"Specific error: {error_code.code}")

            # Exclude specific error codes
            for error_code in client.list_error_codes(
                where={"code": {"nin": ["SCHEDULE_CRON_INVALID"]}}
            ):
                print(f"Active error: {error_code.code}")
            ```
        """
        after = None
        while True:
            connection = self._queries.get_error_codes(
                first=page_size, after=after, where=where, order=order
            )
            if not connection.edges:
                break
            for edge in connection.edges:
                if edge.node is not None:
                    yield edge.node
            if connection.page_info is None or not connection.page_info.has_next_page:
                break
            after = connection.page_info.end_cursor

    def list_repositories(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 100,
    ) -> Iterator[RepositoryView]:
        """
        Iterate over all repositories with automatic pagination.

        Args:
            where: GraphQL filter conditions (RepositoryViewFilterInput).
                Available fields:
                - String fields (`name`, `url`, `username`, `sshPublicKey`):
                  `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`, `startsWith`,
                  `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - DateTime fields (`createdAt`, `changedAt`): `eq`, `neq`, `in`, `nin`,
                  `gt`, `ngt`, `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            RepositoryView instances

        Example:
            ```python
            # Iterate over all repositories
            for repository in client.list_repositories():
                print(f"Repository: {repository.name}")

            # Filter by authentication method
            for repository in client.list_repositories(
                where={"authenticationMethod": {"eq": "SSH_KEY"}}
            ):
                print(f"SSH Repo: {repository.name}")

            # Filter by name pattern
            for repository in client.list_repositories(
                where={"name": {"contains": "production"}}
            ):
                print(f"Production repo: {repository.name}")

            # Filter by URL pattern
            for repository in client.list_repositories(
                where={"url": {"startsWith": "https://github.com/"}}
            ):
                print(f"GitHub repo: {repository.name}")

            # Filter by creation date
            from datetime import datetime, timedelta

            since = datetime.now() - timedelta(days=30)
            for repository in client.list_repositories(
                where={"createdAt": {"gte": since.isoformat()}}
            ):
                print(f"Recent repo: {repository.name}")
            ```
        """
        after = None
        while True:
            connection = self._queries.get_repositories(
                first=page_size, after=after, where=where, order=order
            )
            if not connection.edges:
                break
            for edge in connection.edges:
                if edge.node is not None:
                    yield edge.node
            if connection.page_info is None or not connection.page_info.has_next_page:
                break
            after = connection.page_info.end_cursor

    def list_schedules(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 100,
    ) -> Iterator[ScheduleView]:
        """
        Iterate over all schedules with automatic pagination.

        Args:
            where: GraphQL filter conditions (ScheduleViewFilterInput).
                Available fields:
                - String fields (`automationPath`, `name`, `description`, `cron`, `timezone`):
                  `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`, `startsWith`,
                  `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - `active` (Boolean): `eq`, `neq`
                - `version` (Long): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            ScheduleView instances

        Example:
            ```python
            # Iterate over all schedules
            for schedule in client.list_schedules():
                print(f"Schedule: {schedule.name}")

            # Filter by name pattern
            for schedule in client.list_schedules(
                where={"name": {"contains": "daily"}}
            ):
                print(f"Daily schedule: {schedule.name}")

            # Filter active schedules
            for schedule in client.list_schedules(where={"active": {"eq": True}}):
                print(f"Active: {schedule.name}")

            # Filter by automation path
            for schedule in client.list_schedules(
                where={"automationPath": {"startsWith": "/production/"}}
            ):
                print(f"Production schedule: {schedule.name}")

            # Filter by timezone
            for schedule in client.list_schedules(
                where={"timezone": {"eq": "Europe/Berlin"}}
            ):
                print(f"Berlin time: {schedule.name}")

            # Iterate over active schedules
            for schedule in client.list_schedules(where={"active": {"eq": True}}):
                print(f"Active: {schedule.name} - {schedule.cron}")
            ```
        """
        after = None
        while True:
            connection = self._queries.get_schedules(
                first=page_size, after=after, where=where, order=order
            )
            if not connection.edges:
                break
            for edge in connection.edges:
                if edge.node is not None:
                    yield edge.node
            if connection.page_info is None or not connection.page_info.has_next_page:
                break
            after = connection.page_info.end_cursor

    def list_scheduled_executions(
        self,
        from_time: datetime | None = None,
        to_time: datetime | None = None,
        page_size: int = 100,
    ) -> Iterator[ScheduledExecutionView]:
        """
        Iterate over scheduled executions with automatic pagination.

        Args:
            from_time: Start time for scheduled executions
            to_time: End time for scheduled executions
            page_size: Number of items per page

        Yields:
            ScheduledExecutionView instances

        Example:
            ```python
            from datetime import datetime, timedelta

            # Iterate over next 7 days of scheduled executions
            start = datetime.now()
            end = start + timedelta(days=7)
            for scheduled in client.list_scheduled_executions(
                from_time=start, to_time=end
            ):
                print(f"Schedule: {scheduled.name} at {scheduled.fire_time}")
            ```
        """
        after = None
        while True:
            connection = self._queries.get_scheduled_executions(
                from_time=from_time, to_time=to_time, first=page_size, after=after
            )
            if not connection.edges:
                break
            for edge in connection.edges:
                if edge.node is not None:
                    yield edge.node
            if connection.page_info is None or not connection.page_info.has_next_page:
                break
            after = connection.page_info.end_cursor

    def list_workspaces(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 100,
    ) -> Iterator[WorkspaceView]:
        """
        Iterate over all workspaces with automatic pagination.

        Args:
            where: GraphQL filter conditions (WorkspaceViewFilterInput).
                Available fields:
                - String fields (`name`, `repositoryName`, `buildBranch`, `buildCommit`,
                  `activeBranch`, `activeCommit`): `eq`, `neq`, `in`, `nin`, `contains`,
                  `ncontains`, `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - UUID fields (`buildId`, `activeBuildId`): `eq`, `neq`, `in`, `nin`,
                  `gt`, `ngt`, `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - DateTime fields (`buildStartedAt`, `buildFinishedAt`, `createdAt`, `changedAt`):
                  `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - `buildDuration` (TimeSpan): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            WorkspaceView instances

        Example:
            ```python
            # Iterate over all workspaces
            for workspace in client.list_workspaces():
                print(f"Workspace: {workspace.name}")

            # Filter by build status
            for workspace in client.list_workspaces(
                where={"buildStatus": {"eq": "SUCCEEDED"}}
            ):
                print(f"Success: {workspace.name}")

            # Filter by name pattern
            for workspace in client.list_workspaces(
                where={"name": {"startsWith": "prod-"}}
            ):
                print(f"Production workspace: {workspace.name}")

            # Filter by build duration (fast builds only)
            for workspace in client.list_workspaces(
                where={"buildDuration": {"lt": "00:05:00"}}
            ):
                print(f"Fast build: {workspace.name}")

            # Filter by recent builds
            from datetime import datetime, timedelta

            since = datetime.now() - timedelta(hours=1)
            for workspace in client.list_workspaces(
                where={"buildFinishedAt": {"gte": since.isoformat()}}
            ):
                print(f"Recently built: {workspace.name}")
            ```
        """
        after = None
        while True:
            connection = self._queries.get_workspaces(
                first=page_size, after=after, where=where, order=order
            )
            if not connection.edges:
                break
            for edge in connection.edges:
                if edge.node is not None:
                    yield edge.node
            if connection.page_info is None or not connection.page_info.has_next_page:
                break
            after = connection.page_info.end_cursor

    def __repr__(self) -> str:
        """String representation of the client."""
        auth_status = (
            "authenticated" if self.is_authenticated() else "not authenticated"
        )
        return (
            f"QuestraAutomation(graphql_url='{self._graphql_url}', "
            f"status='{auth_status}')"
        )
