"""
alphainfo — Structure-aware analysis for any time series

Detect structural changes, measure similarity, and diagnose what type of
change occurred — across any domain. See /v1/guide for encoding patterns.

Quick start:
    >>> from alphainfo import AlphaInfo
    >>> client = AlphaInfo(api_key="ai_your_key")
    >>> result = client.analyze(signal=[...], sampling_rate=250.0)
    >>> print(result.confidence_band)  # 'stable', 'transition', or 'unstable'

Async:
    >>> from alphainfo import AsyncAlphaInfo
    >>> async with AsyncAlphaInfo(api_key="ai_your_key") as client:
    ...     result = await client.analyze(signal=[...], sampling_rate=250.0)
"""

from .client import AlphaInfo, AsyncAlphaInfo
from .exceptions import (
    AlphaInfoError,
    APIError,
    AuthError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)
from .models import (
    AnalysisResult,
    AuditReplay,
    AuditSummary,
    BatchItemResult,
    BatchResult,
    ChannelResult,
    FingerprintResult,
    HealthStatus,
    MatrixResult,
    PlanInfo,
    RateLimitInfo,
    SemanticResult,
    VectorResult,
)

__version__ = "1.5.3"
__all__ = [
    # Clients
    "AlphaInfo",
    "AsyncAlphaInfo",
    # Result models
    "AnalysisResult",
    "SemanticResult",
    "BatchResult",
    "BatchItemResult",
    "VectorResult",
    "ChannelResult",
    "MatrixResult",
    "FingerprintResult",
    # Audit
    "AuditReplay",
    "AuditSummary",
    # Infrastructure
    "HealthStatus",
    "PlanInfo",
    "RateLimitInfo",
    # Exceptions
    "AlphaInfoError",
    "APIError",
    "AuthError",
    "NetworkError",
    "NotFoundError",
    "RateLimitError",
    "TimeoutError",
    "ValidationError",
]
