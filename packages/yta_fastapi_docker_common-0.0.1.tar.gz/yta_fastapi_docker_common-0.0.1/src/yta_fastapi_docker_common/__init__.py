"""
The FastAPI and Docker module to share code that
will be used for the different modules.
"""
from pathlib import Path
from typing import Iterator


def stream_response_to_file(
    response: 'Response',
    output_filename: str,
    chunk_size: int = 8192
):
    """
    Method to export to a file a response that is
    returning a file content through a generator.
    """
    with Path(output_filename).open('wb') as f:
        for chunk in response.iter_bytes(chunk_size = chunk_size):
            if not isinstance(chunk, (bytes, bytearray)):
                raise TypeError(f'Invalid chunk type: {type(chunk)}')
            f.write(chunk)

def stream_to_file(
    stream: Iterator[bytes],
    path: Path
):
    """
    Method to export to a file a bytes stream.
    """
    with path.open('wb') as f:
        for chunk in stream:
            if not isinstance(chunk, (bytes, bytearray)):
                raise TypeError(f'Invalid chunk type: {type(chunk)}')
            f.write(chunk)