# Youtube Autonomous FastAPI Docker Common Module

The module that is to include code that different projects based on `FastAPI` and `Docker` will use, to avoid duplicities.

This project will not include any docker file because it's meant to be used as a simple dependency, but could include some FastAPI dependencies to be able to handle the code we need.