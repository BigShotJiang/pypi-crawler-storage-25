from django.contrib import admin

# Register your models here.
from .models import AuthToggle

@admin.register(AuthToggle)
class AuthToggleAdmin(admin.ModelAdmin):
    list_display = ("id", "site",)
    search_fields = ("site__domain", "email")
