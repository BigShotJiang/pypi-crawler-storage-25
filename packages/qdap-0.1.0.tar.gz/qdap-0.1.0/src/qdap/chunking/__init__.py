"""QDAP Adaptive Chunking Module."""
