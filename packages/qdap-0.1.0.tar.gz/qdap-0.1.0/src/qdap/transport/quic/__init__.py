"""QUIC transport adapter package."""
