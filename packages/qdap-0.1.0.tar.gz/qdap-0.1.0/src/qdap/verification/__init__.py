"""QDAP Verification Package."""
