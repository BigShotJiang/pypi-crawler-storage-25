"""Ghost session verification subpackage."""
