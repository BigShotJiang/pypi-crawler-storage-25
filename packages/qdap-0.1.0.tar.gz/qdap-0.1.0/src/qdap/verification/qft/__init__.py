"""QFT verification subpackage."""
