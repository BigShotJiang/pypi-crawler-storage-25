"""Video streaming demo package."""
