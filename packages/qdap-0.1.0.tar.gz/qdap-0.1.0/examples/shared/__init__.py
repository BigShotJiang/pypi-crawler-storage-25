"""Shared demo utilities."""
