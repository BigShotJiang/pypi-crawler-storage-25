"""Examples package."""
