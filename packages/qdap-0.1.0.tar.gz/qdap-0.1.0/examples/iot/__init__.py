"""IoT demo package."""
