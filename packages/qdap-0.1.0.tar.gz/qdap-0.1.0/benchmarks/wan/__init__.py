"""WAN simulation benchmark package."""
