"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - NEAR update key
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class UpdateKeyInput(BaseModel):
    account_id: str
    public_key: str
    new_allowance: Optional[str] = None
    receiver_id: Optional[str] = None
    method_names: Optional[List[str]] = None
    network: str = "mainnet"

class NEARUpdateKeyTool(BaseTool):
    name: str = "near_update_key"
    description: str = (
        "Update a NEAR access key's permissions or allowance. "
        "Provide account_id, public_key, and optionally new_allowance (in yoctoNEAR), "
        "receiver_id, and method_names for function call keys. "
        "Returns current key info and guidance on constructing the update transaction."
    )
    args_schema: Type[BaseModel] = UpdateKeyInput

    def _run(
        self,
        account_id: str,
        public_key: str,
        new_allowance: Optional[str] = None,
        receiver_id: Optional[str] = None,
        method_names: Optional[List[str]] = None,
        network: str = "mainnet",
    ) -> str:
        try:
            result = _near_rpc(
                "query",
                {
                    "request_type": "view_access_key",
                    "finality": "final",
                    "account_id": account_id,
                    "public_key": public_key,
                },
                network=network,
            )
            if "error" in result:
                return f"Error fetching key: {result['error']}"

            key_info = result.get("result", result)
            permission = key_info.get("permission", {})

            update_payload: Dict[str, Any] = {
                "account_id": account_id,
                "public_key": public_key,
                "current_permission": permission,
            }

            if isinstance(permission, dict) and "FunctionCall" in permission:
                fc = permission["FunctionCall"]
                update_payload["action"] = "DeleteKey + AddKey (AddKey with updated FunctionCall)"
                update_payload["proposed_new_permission"] = {
                    "FunctionCall": {
                        "allowance": new_allowance if new_allowance is not None else fc.get("allowance"),
                        "receiver_id": receiver_id if receiver_id is not None else fc.get("receiver_id"),
                        "method_names": method_names if method_names is not None else fc.get("method_names", []),
                    }
                }
            elif permission == "FullAccess":
                update_payload["action"] = "FullAccess keys cannot have allowance/receiver restrictions"
                update_payload["note"] = "To downgrade, DeleteKey then AddKey with FunctionCall permission"
            else:
                update_payload["action"] = "DeleteKey + AddKey with desired permission"

            update_payload["instructions"] = (
                "Use NEAR CLI: `near delete-key <account_id> <public_key>` then "
                "`near add-key <account_id> <public_key> --contract-id <receiver_id> "
                "--allowance <allowance>` or use near-api-js with DeleteKey + AddKey actions."
            )
            return str(update_payload)
        except Exception as e:
            return f"Exception during key update lookup: {e}"

    async def _arun(
        self,
        account_id: str,
        public_key: str,
        new_allowance: Optional[str] = None,
        receiver_id: Optional[str] = None,
        method_names: Optional[List[str]] = None,
        network: str = "mainnet",
    ) -> str:
        return self._run(account_id, public_key, new_allowance, receiver_id, method_names, network)


class ListAccessKeysInput(BaseModel):
    account_id: str
    network: str = "mainnet"

class NEARListAccessKeysTool(BaseTool):
    name: str = "near_list_access_keys"
    description: str = (
        "List all access keys for a NEAR account, showing each key's public key, "
        "permission type (FullAccess or FunctionCall), allowance, receiver_id, and nonce. "
        "Useful before updating a key to identify which key to modify."
    )
    args_schema: Type[BaseModel] = ListAccessKeysInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        try:
            result = _near_rpc(
                "query",
                {
                    "request_type": "view_access_key_list",
                    "finality": "final",
                    "account_id": account_id,
                },
                network=network,
            )
            if "error" in result:
                return f"Error fetching keys: {result['error']}"
            keys = result.get("result", {}).get("keys", result.get("keys", []))
            if not keys:
                return f"No access keys found for {account_id}"
            output = [f"Access keys for {account_id} on {network}:"]
            for k in keys:
                perm = k.get("access_key", {}).get("permission", "unknown")
                nonce = k.get("access_key", {}).get("nonce", "?")
                pub = k.get("public_key", "unknown")
                if isinstance(perm, dict) and "FunctionCall" in perm:
                    fc = perm["FunctionCall"]
                    output.append(
                        f"  {pub} | FunctionCall | receiver={fc.get('receiver_id')} "
                        f"| allowance={fc.get('allowance')} | methods={fc.get('method_names')} | nonce={nonce}"
                    )
                else:
                    output.append(f"  {pub} | {perm} | nonce={nonce}")
            return "\n".join(output)
        except Exception as e:
            return f"Exception listing keys: {e}"

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)