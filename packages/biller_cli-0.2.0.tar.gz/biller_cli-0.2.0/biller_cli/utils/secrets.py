from pathlib import Path
from rich.console import Console

console = Console()

def write_env_file(project_dir: Path, secrets: dict):
    """Write sensitive values to .env.biller. Never call yaml.dump on these."""
    env_file = project_dir / ".env.biller"
    lines = ["# Biller secrets — DO NOT COMMIT\n"]
    for key, value in secrets.items():
        lines.append(f"{key.upper()}={value}\n")
    env_file.write_text("".join(lines))
    _ensure_gitignore(project_dir)
    console.print(f"[dim]Secrets → {env_file} (git-ignored)[/dim]")

def read_env_file(project_dir: Path) -> dict:
    """Reads secrets back for native mode injection."""
    env_file = project_dir / ".env.biller"
    if not env_file.exists():
        return {}
    result = {}
    for line in env_file.read_text().splitlines():
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            result[k.lower()] = v
    return result

def _ensure_gitignore(project_dir: Path):
    """Guarantees .env.biller is ignored in the user's generated repo."""
    gitignore = project_dir / ".gitignore"
    entry = ".env.biller"
    if gitignore.exists():
        if entry not in gitignore.read_text():
            with gitignore.open("a") as f:
                f.write(f"\n# Biller secrets — auto-added by biller-cli\n{entry}\n")
    else:
        gitignore.write_text(f"# Biller secrets\n{entry}\n")