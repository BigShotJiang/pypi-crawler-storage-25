import shutil, subprocess, sys
from rich.console import Console
from enum import Enum

console = Console()

class RuntimeMode(Enum):
    DOCKER = "docker"
    NATIVE = "native"
    NONE   = "none"

# ── Individual check functions ────────────────────────────────────────────────

def _check_python() -> bool:
    return sys.version_info >= (3, 10)

def _check_git() -> bool:
    return shutil.which("git") is not None

def _check_java() -> bool:
    if not shutil.which("java"):
        return False
    result = subprocess.run(["java", "-version"], capture_output=True, text=True)
    output = result.stderr + result.stdout
    for line in output.splitlines():
        if "version" in line:
            try:
                version_str = line.split('"')[1]
                major = int(version_str.split(".")[0])
                if major == 1:           # legacy 1.8.x format
                    major = int(version_str.split(".")[1])
                return major >= 17
            except (IndexError, ValueError):
                return False
    return False

def _check_maven() -> bool:
    return shutil.which("mvn") is not None

def _check_docker_installed() -> bool:
    return shutil.which("docker") is not None

def _check_docker_daemon() -> bool:
    if not _check_docker_installed():
        return False
    result = subprocess.run(["docker", "info"], capture_output=True)
    return result.returncode == 0

# ── Runtime detection ─────────────────────────────────────────────────────────

def detect_runtime() -> RuntimeMode:
    """
    Returns the best available runtime:
      docker  — Docker installed AND daemon running
      native  — No Docker (or daemon down), but Java 17+ and Maven present
      none    — Neither viable
    """
    if _check_docker_daemon():
        return RuntimeMode.DOCKER
    if _check_java() and _check_maven():
        return RuntimeMode.NATIVE
    return RuntimeMode.NONE

# ── Pre-flight gate ───────────────────────────────────────────────────────────

UNIVERSAL_CHECKS = [
    {
        "name": "Python >= 3.10",
        "check": _check_python,
        "fix": "Upgrade Python: https://python.org",
    },
    {
        "name": "Git",
        "check": _check_git,
        "fix": "Install Git:  sudo apt-get install git",
    },
]

NATIVE_CHECKS = [
    {
        "name": "Java 17+",
        "check": _check_java,
        "fix": "Install Java: sudo apt-get install openjdk-17-jdk\n"
               "              Or: https://adoptium.net",
    },
    {
        "name": "Maven",
        "check": _check_maven,
        "fix": "Install Maven: sudo apt-get install maven\n"
               "               Or: https://maven.apache.org/install.html",
    },
]

def run_preflight(require_runtime: bool = True) -> RuntimeMode:
    """
    Run all pre-flight checks. Returns the detected RuntimeMode.
    Exits with a clear message if any universal check fails,
    or if require_runtime=True and no runtime is viable.
    """
    # Universal checks — must always pass
    failed = []
    for item in UNIVERSAL_CHECKS:
        try:
            passed = item["check"]()
        except Exception:
            passed = False
        if not passed:
            failed.append(item)

    if failed:
        console.print("\n[red]Pre-flight failed:[/red]\n")
        for item in failed:
            console.print(f"  [red]✗[/red]  {item['name']}")
            console.print(f"       → {item['fix']}\n")
        raise SystemExit(1)

    # Runtime detection
    runtime = detect_runtime()

    if runtime == RuntimeMode.DOCKER:
        console.print("[dim]Runtime: Docker ✓[/dim]")

    elif runtime == RuntimeMode.NATIVE:
        console.print("[yellow]Docker not available — using native Maven mode.[/yellow]")
        failed_native = []
        for item in NATIVE_CHECKS:
            try:
                passed = item["check"]()
            except Exception:
                passed = False
            if not passed:
                failed_native.append(item)
        if failed_native:
            console.print("\n[red]Native mode also unavailable:[/red]\n")
            for item in failed_native:
                console.print(f"  [red]✗[/red]  {item['name']}")
                console.print(f"       → {item['fix']}\n")
            raise SystemExit(1)

    elif runtime == RuntimeMode.NONE and require_runtime:
        console.print("\n[red]No viable runtime found.[/red]")
        console.print("biller-cli needs either:\n")
        console.print("  [bold]Docker (recommended)[/bold]")
        console.print("    sudo apt-get install docker.io")
        console.print("    sudo systemctl start docker")
        console.print("    sudo usermod -aG docker $USER  # then log out and back in\n")
        console.print("  [bold]OR: Java 17+ and Maven[/bold]")
        console.print("    sudo apt-get install openjdk-17-jdk maven\n")
        raise SystemExit(1)

    return runtime