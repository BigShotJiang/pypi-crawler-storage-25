"""
Shared utility for reading and writing the biller-core version pin.

Used by both `biller-cli upgrade` and `biller-cli downgrade`.
Updates two files atomically:
  - biller.yaml  → core.version
  - pom.xml      → properties/biller.core.version

Uses an XML parser (not regex) so POM reformatting by IDEs or Maven
does not silently break the update.
"""

import xml.etree.ElementTree as ET
from pathlib import Path
import yaml


MAVEN_NS = "http://maven.apache.org/POM/4.0.0"


def get_version_pin(project_dir: Path) -> str:
    """Return the currently pinned biller-core version from biller.yaml."""
    bp = project_dir / "biller.yaml"
    if not bp.exists():
        raise FileNotFoundError(f"biller.yaml not found in {project_dir}")
    cfg = yaml.safe_load(bp.read_text())
    version = cfg.get("core", {}).get("version")
    if not version:
        raise KeyError("core.version not found in biller.yaml")
    return version


def set_version_pin(project_dir: Path, version: str) -> None:
    """
    Write version to both biller.yaml and pom.xml.

    Raises RuntimeError if biller.core.version property is missing from pom.xml —
    this means the pom.xml was not scaffolded correctly and should not be silently fixed.
    """
    # 1. biller.yaml
    bp = project_dir / "biller.yaml"
    cfg = yaml.safe_load(bp.read_text())
    if "core" not in cfg:
        cfg["core"] = {}
    cfg["core"]["version"] = version
    bp.write_text(yaml.dump(cfg, default_flow_style=False, sort_keys=False))

    # 2. pom.xml — use XML parser, never regex
    pom_path = project_dir / "pom.xml"
    if not pom_path.exists():
        raise FileNotFoundError(f"pom.xml not found in {project_dir}")

    ET.register_namespace("", MAVEN_NS)
    tree = ET.parse(pom_path)
    root = tree.getroot()
    ns = {"m": MAVEN_NS}

    prop = root.find(".//m:properties/m:biller.core.version", ns)
    if prop is None:
        raise RuntimeError(
            "biller.core.version not found in pom.xml <properties>. "
            "The pom.xml may not have been scaffolded by biller-cli init. "
            "Add: <biller.core.version>VERSION</biller.core.version> under <properties>."
        )

    prop.text = version
    tree.write(str(pom_path), xml_declaration=True, encoding="unicode")