"""
biller-cli downgrade

Rolls back the biller-core version pin in biller.yaml and pom.xml.

DATABASE WARNING:
  Downgrade does NOT touch the database. If the upgrade applied schema
  migrations, a downgrade will leave the DB in a state incompatible
  with the older code. You must roll back the database manually.
  This warning is printed before the confirmation prompt — always.
"""

import subprocess
import sys
import typer
import yaml
from pathlib import Path
from rich.console import Console
from packaging.version import Version

from biller_cli.utils.version_pin import get_version_pin, set_version_pin

app = typer.Typer(help="Downgrade biller-core to an older version.")
console = Console()

REGISTRY_URL_DEFAULT = "https://biller-registry-production.up.railway.app"


def _get_registry_url(project_dir: Path) -> str:
    """Read BILLER_REGISTRY_URL from environment, then .env.biller, fallback to default."""
    # Environment variable takes highest priority
    import os
    env_var = os.environ.get("BILLER_REGISTRY_URL")
    if env_var:
        return env_var
    # Then .env.biller file
    env_file = project_dir / ".env.biller"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if line.startswith("BILLER_REGISTRY_URL="):
                return line.split("=", 1)[1].strip()
    return REGISTRY_URL_DEFAULT


def _version_exists_in_registry(registry_url: str, version: str) -> bool:
    """Return True if the version exists in the registry manifest."""
    import requests
    try:
        resp = requests.get(f"{registry_url}/api/v1/manifest", timeout=10)
        if resp.status_code != 200:
            return True  # Fail open — don't block downgrade on registry unavailability
        manifest = resp.json()
        return version in manifest.get("versions", {})
    except Exception:
        return True  # Fail open


def _restart_stack(project_dir: Path) -> None:
    """
    Restart the stack using the biller-cli executable found via sys.executable.
    Avoids PATH lookup failures when installed in a venv (e.g. via pipx).
    """
    biller_cli_exe = Path(sys.executable).parent / "biller-cli"
    if not biller_cli_exe.exists():
        console.print("[red]Cannot find biller-cli executable for auto-restart.[/red]")
        console.print("Run manually: [bold]biller-cli down && biller-cli up[/bold]")
        return

    dir_str = str(project_dir)

    result_down = subprocess.run([str(biller_cli_exe), "down", "--dir", dir_str])
    if result_down.returncode != 0:
        console.print("[yellow]⚠ biller-cli down exited with an error. Proceeding to up anyway.[/yellow]")

    result_up = subprocess.run([str(biller_cli_exe), "up", "--dir", dir_str])
    if result_up.returncode != 0:
        console.print("[red]biller-cli up failed after downgrade.[/red]")
        console.print("Check logs and run [bold]biller-cli up[/bold] manually.")


@app.callback(invoke_without_command=True)
def downgrade(
    project_dir: Path = typer.Option(Path("."), "--dir", "-d", help="Project directory"),
    to: str = typer.Option(..., "--to", help="Target version to downgrade to"),
    restart: bool = typer.Option(False, "--restart", help="Restart the stack after downgrade"),
):
    """Downgrade biller-core to an older version."""
    # Resolve current version
    try:
        current_version = get_version_pin(project_dir)
    except (FileNotFoundError, KeyError) as e:
        console.print(f"[red]{e}[/red]")
        console.print("Run [bold]biller-cli init[/bold] first.")
        raise typer.Exit(1)

    # Guard: same version
    if Version(to) == Version(current_version):
        console.print(f"Already on [bold]{current_version}[/bold]. Nothing to do.")
        raise typer.Exit(0)

    # Guard: target is newer
    if Version(to) > Version(current_version):
        console.print(f"[red]{to} is newer than {current_version}.[/red]")
        console.print("Use [bold]biller-cli upgrade[/bold] to upgrade.")
        raise typer.Exit(1)

    # Validate target version exists in registry
    registry_url = _get_registry_url(project_dir)
    if not _version_exists_in_registry(registry_url, to):
        console.print(f"[red]Version {to} is not in the registry manifest.[/red]")
        console.print(f"Check available versions: {registry_url}/api/v1/manifest")
        raise typer.Exit(1)

    # DB warning — always shown before confirmation
    console.print("\n[yellow bold]⚠ DATABASE WARNING[/yellow bold]")
    console.print(
        "Downgrade does [bold]NOT[/bold] roll back database schema changes.\n"
        "If the upgrade applied migrations, the older code may fail to boot\n"
        "or behave incorrectly against the current schema.\n"
        "Roll back your database manually before proceeding."
    )

    console.print(
        f"\nDowngrading biller-core: [bold]{current_version}[/bold] → [bold]{to}[/bold]"
    )
    typer.confirm("Continue with downgrade?", abort=True)

    # Update version pin
    try:
        set_version_pin(project_dir, to)
    except (FileNotFoundError, RuntimeError) as e:
        console.print(f"[red]Failed to update version pin: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"\n[green bold]✓ Downgrade complete.[/green bold]")
    console.print(f"biller-core pinned to [bold]{to}[/bold] in biller.yaml and pom.xml.")

    if restart:
        console.print("\nRestarting stack...")
        _restart_stack(project_dir)
    else:
        console.print("\nRun [bold]biller-cli down && biller-cli up[/bold] to apply the downgrade.")