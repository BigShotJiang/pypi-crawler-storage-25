"""
biller_cli/commands/ingest.py

CLI entry point for `biller-cli ingest`.

Usage:
  biller-cli ingest --source path/to/file1.md --source path/to/file2.md

Multiple --source flags are supported. All files are ingested into a single
ChromaDB collection in one pass.
"""

from pathlib import Path
from typing import List

import typer

app = typer.Typer(help="Ingest source documents into the ChromaDB knowledge base.")


@app.callback(invoke_without_command=True)
def ingest(
    sources: List[Path] = typer.Option(
        ...,
        "--source",
        "-s",
        help="Path to a source .md file to ingest. Repeat for multiple files.",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
    ),
) -> None:
    """
    Chunk and embed source documents into ChromaDB.

    Supports codebase dumps (## src/ headers) and spec documents
    (## N. numbered headings). Pass --source multiple times to ingest
    all files into a single collection in one run.

    Example:
      biller-cli ingest \\
        --source ~/Desktop/repoSpec/bbps_biller_integrator_codebase.md \\
        --source ~/Desktop/repoSpec/bbps_bou_integration.md \\
        --source ~/Desktop/repoSpec/bbps_schema_specification.md \\
        --source ~/Desktop/repoSpec/upms.md
    """
    from biller_cli.ai.ingest import run_ingest

    run_ingest([p.resolve() for p in sources])