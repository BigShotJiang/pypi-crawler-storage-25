"""
biller-cli upgrade

Fetches migration rules from the registry, applies automatable ones,
runs a sandbox compile-check, then updates the version pin in
biller.yaml and pom.xml.

SCOPE OF SANDBOX:
  Runs `mvn clean package -pl biller-user-layer --also-make`.
  This is a COMPILE-ONLY gate. It does NOT prove the app boots,
  that the DB schema is compatible, or that the cert path resolves.
  A green sandbox means the code compiles against the new biller-core.
  Boot correctness must be verified by running biller-cli up after upgrade.
"""

import subprocess
import sys
import shutil
import typer
import requests
import yaml
from pathlib import Path
from rich.console import Console
from packaging.version import Version

from biller_cli.utils.version_pin import get_version_pin, set_version_pin

app = typer.Typer(help="Upgrade biller-core to a newer version.")
console = Console()

REGISTRY_URL_DEFAULT = "https://biller-registry-production.up.railway.app"


def _get_registry_url(project_dir: Path) -> str:
    """Read BILLER_REGISTRY_URL from environment, then .env.biller, fallback to default."""
    # Environment variable takes highest priority
    import os
    env_var = os.environ.get("BILLER_REGISTRY_URL")
    if env_var:
        return env_var
    # Then .env.biller file
    env_file = project_dir / ".env.biller"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if line.startswith("BILLER_REGISTRY_URL="):
                return line.split("=", 1)[1].strip()
    return REGISTRY_URL_DEFAULT


def _fetch_migration_path(registry_url: str, from_version: str, to_version: str) -> dict:
    """Fetch ordered migration rules from the registry."""
    url = f"{registry_url}/api/v1/manifest/migration-path"
    try:
        resp = requests.get(url, params={"from_version": from_version, "to_version": to_version}, timeout=10)
    except requests.ConnectionError:
        console.print(f"[red]Cannot reach registry at {registry_url}.[/red]")
        console.print("Check your network or set BILLER_REGISTRY_URL in .env.biller.")
        raise typer.Exit(1)

    if resp.status_code == 400:
        console.print(f"[red]{resp.json().get('detail', 'Bad request')}[/red]")
        raise typer.Exit(1)
    if resp.status_code == 404:
        console.print(f"[red]Version not found in registry: {resp.json().get('detail')}[/red]")
        raise typer.Exit(1)
    if resp.status_code != 200:
        console.print(f"[red]Registry error {resp.status_code}: {resp.text}[/red]")
        raise typer.Exit(1)

    return resp.json()


def _fetch_latest_version(registry_url: str) -> str:
    """Fetch the latest published biller-core version from the registry."""
    try:
        resp = requests.get(f"{registry_url}/api/v1/manifest/latest", timeout=10)
        resp.raise_for_status()
        return resp.json()["version"]
    except Exception as e:
        console.print(f"[red]Failed to fetch latest version from registry: {e}[/red]")
        raise typer.Exit(1)


def _apply_config_rename_rule(project_dir: Path, rule: dict) -> None:
    """Apply a config_rename migration rule to biller.yaml."""
    old_key = rule.get("old_key")
    new_key = rule.get("new_key")
    if not old_key or not new_key:
        return

    bp = project_dir / "biller.yaml"
    cfg = yaml.safe_load(bp.read_text())

    # Support dot-notation keys like "core.timeout"
    def get_nested(d, keys):
        for k in keys:
            if not isinstance(d, dict) or k not in d:
                return None, False
            d = d[k]
        return d, True

    def set_nested(d, keys, value):
        for k in keys[:-1]:
            d = d.setdefault(k, {})
        d[keys[-1]] = value

    def del_nested(d, keys):
        for k in keys[:-1]:
            if k not in d:
                return
            d = d[k]
        d.pop(keys[-1], None)

    old_parts = old_key.split(".")
    new_parts = new_key.split(".")

    value, found = get_nested(cfg, old_parts)
    if found:
        set_nested(cfg, new_parts, value)
        del_nested(cfg, old_parts)
        bp.write_text(yaml.dump(cfg, default_flow_style=False, sort_keys=False))
        console.print(f"  [green]✓[/green] Renamed config key [bold]{old_key}[/bold] → [bold]{new_key}[/bold]")
    else:
        console.print(f"  [yellow]⚠[/yellow] Config key [bold]{old_key}[/bold] not found — skipping rename")


def _run_sandbox_build(project_dir: Path, target_version: str) -> bool:
    """
    Create a Git worktree sandbox, pin the new version, and attempt compilation.
    Returns True if build passes, False if it fails.
    Always cleans up the worktree regardless of outcome.

    COMPILE-ONLY: Does not test boot, DB connectivity, or cert resolution.
    """
    worktree_path = project_dir / ".biller" / f"sandbox-{target_version}"

    # Require a git repo for worktree support
    git_dir = project_dir / ".git"
    if not git_dir.exists():
        console.print("[yellow]⚠ Not a git repository — skipping sandbox build.[/yellow]")
        console.print("[dim]Sandbox compile-check requires git. Proceeding without it.[/dim]")
        return True

    # Check Maven is available
    if not shutil.which("mvn"):
        console.print("[yellow]⚠ Maven (mvn) not found on PATH — skipping sandbox build.[/yellow]")
        return True

    try:
        console.print(f"[dim]Creating sandbox worktree at {worktree_path}...[/dim]")
        result = subprocess.run(
            ["git", "worktree", "add", str(worktree_path), "HEAD"],
            cwd=str(project_dir),
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            console.print(f"[yellow]⚠ Could not create sandbox worktree: {result.stderr.strip()}[/yellow]")
            console.print("[dim]Proceeding without sandbox.[/dim]")
            return True

        # Pin the target version in the sandbox copy (not in the live project)
        set_version_pin(worktree_path, target_version)

        console.print("[dim]Running sandbox compile check (mvn clean package)...[/dim]")
        console.print("[dim]Sandbox scope: compile-only. Boot correctness verified after upgrade.[/dim]")

        build_result = subprocess.run(
            ["mvn", "clean", "package", "-pl", "biller-user-layer", "--also-make", "-q"],
            cwd=str(worktree_path),
        )

        if build_result.returncode != 0:
            console.print("[red]✗ Sandbox build FAILED. Version pin NOT updated.[/red]")
            console.print("Fix the compilation errors before upgrading.")
            return False

        console.print("[green]✓ Sandbox compile check passed.[/green]")
        return True

    finally:
        # Always clean up worktree — success or failure
        subprocess.run(
            ["git", "worktree", "remove", "--force", str(worktree_path)],
            cwd=str(project_dir),
            capture_output=True,
        )


@app.callback(invoke_without_command=True)
def upgrade(
    project_dir: Path = typer.Option(Path("."), "--dir", "-d", help="Project directory"),
    to: str = typer.Option(None, "--to", help="Target version (default: latest from registry)"),
    skip_sandbox: bool = typer.Option(False, "--skip-sandbox", help="Skip the sandbox compile check"),
):
    """Upgrade biller-core to a newer version."""
    registry_url = _get_registry_url(project_dir)

    # Resolve current version
    try:
        current_version = get_version_pin(project_dir)
    except (FileNotFoundError, KeyError) as e:
        console.print(f"[red]{e}[/red]")
        console.print("Run [bold]biller-cli init[/bold] first.")
        raise typer.Exit(1)

    # Resolve target version
    target_version = to or _fetch_latest_version(registry_url)

    # Guard: already on target
    if Version(target_version) <= Version(current_version):
        console.print(f"Already on [bold]{current_version}[/bold]. Nothing to upgrade.")
        if Version(target_version) < Version(current_version):
            console.print("To downgrade, use [bold]biller-cli downgrade[/bold].")
        raise typer.Exit(0)

    console.print(f"\nUpgrading biller-core: [bold]{current_version}[/bold] → [bold]{target_version}[/bold]")
    console.print(f"Registry: {registry_url}\n")

    # Fetch migration path
    migration = _fetch_migration_path(registry_url, current_version, target_version)
    rules = migration.get("rules", [])
    path = migration.get("path", [])

    if path:
        console.print(f"Migration path: {' → '.join([current_version] + path)}")
    else:
        console.print("No intermediate versions — direct upgrade.")

    if migration.get("has_breaking_changes"):
        console.print("\n[red bold]⚠ Breaking changes detected in this upgrade path.[/red bold]")
        typer.confirm("Continue?", abort=True)

    # Apply automatable rules
    auto_rules = [r for r in rules if r.get("type") == "config_rename"]
    manual_rules = [r for r in rules if r.get("type") == "manual"]

    if auto_rules:
        console.print(f"\nApplying {len(auto_rules)} automated migration rule(s):")
        for rule in auto_rules:
            _apply_config_rename_rule(project_dir, rule)

    if manual_rules:
        console.print(f"\n[yellow bold]⚠ {len(manual_rules)} manual step(s) required:[/yellow bold]")
        for rule in manual_rules:
            console.print(f"  → {rule.get('description', 'See docs')}")
            if rule.get("docs_url"):
                console.print(f"    Docs: {rule['docs_url']}")
        console.print("[yellow]These must be completed manually before running biller-cli up.[/yellow]")

    # Sandbox compile check
    if not skip_sandbox:
        passed = _run_sandbox_build(project_dir, target_version)
        if not passed:
            raise typer.Exit(1)
    else:
        console.print("[yellow]⚠ Sandbox skipped.[/yellow]")

    # All gates passed — update the live version pin
    try:
        set_version_pin(project_dir, target_version)
    except (FileNotFoundError, RuntimeError) as e:
        console.print(f"[red]Failed to update version pin: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"\n[green bold]✓ Upgrade complete.[/green bold]")
    console.print(f"biller-core pinned to [bold]{target_version}[/bold] in biller.yaml and pom.xml.")
    console.print("\nNext: run [bold]biller-cli down && biller-cli up[/bold] to apply.")

    if manual_rules:
        console.print("[yellow]Reminder: complete the manual steps above before starting the stack.[/yellow]")