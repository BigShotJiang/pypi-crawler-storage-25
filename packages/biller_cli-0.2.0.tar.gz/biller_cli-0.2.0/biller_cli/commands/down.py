import os
import signal
import time
import yaml
import psutil
import typer
import subprocess
from pathlib import Path
from rich.console import Console

app = typer.Typer(help="Stop the Biller middleware stack.")
console = Console()

PID_FILE_NAME = ".biller/biller.pid"

def _down_docker(project_dir: Path):
    compose_file = project_dir / "docker-compose.yml"
    if not compose_file.exists():
        console.print("[yellow]docker-compose.yml not found. Nothing to stop.[/yellow]")
        return
        
    console.print("[blue]Stopping Docker stack...[/blue]")
    result = subprocess.run(["docker", "compose", "-f", str(compose_file), "down"])
    if result.returncode == 0:
        console.print("[green]✓ Stack stopped successfully.[/green]")
    else:
        console.print("[red]Failed to stop Docker compose stack.[/red]")
        raise typer.Exit(result.returncode)

def _down_native(project_dir: Path):
    pid_file = project_dir / PID_FILE_NAME

    if not pid_file.exists():
        console.print("[yellow]No running native stack found (no PID file).[/yellow]")
        return

    try:
        pid = int(pid_file.read_text().strip())
    except ValueError:
        console.print("[yellow]Corrupted PID file. Removing it.[/yellow]")
        pid_file.unlink()
        return

    if not psutil.pid_exists(pid):
        console.print("[yellow]Process is already dead. Cleaning up stale PID file.[/yellow]")
        pid_file.unlink()
        return

    try:
        console.print(f"[blue]Sending SIGTERM to PID {pid}...[/blue]")
        os.kill(pid, signal.SIGTERM)

        # Wait gracefully for up to 10 seconds
        deadline = time.time() + 10
        while time.time() < deadline:
            if not psutil.pid_exists(pid):
                break
            time.sleep(0.5)

        # Escalate to SIGKILL if it refuses to die
        if psutil.pid_exists(pid):
            console.print("[yellow]Process did not terminate cleanly. Force killing (SIGKILL)...[/yellow]")
            os.kill(pid, signal.SIGKILL)

        pid_file.unlink()
        console.print("[green]✓ Native stack stopped successfully.[/green]")

    except ProcessLookupError:
        pid_file.unlink()
        console.print("[green]✓ Already stopped.[/green]")
    except PermissionError:
        console.print(f"[red]Permission denied. Try running: kill -9 {pid}[/red]")

@app.callback(invoke_without_command=True)
def down(
    project_dir: Path = typer.Option(Path("."), "--dir", "-d", help="Project directory"),
):
    """Stop the Biller middleware stack."""
    biller_yaml_path = project_dir / "biller.yaml"
    if not biller_yaml_path.exists():
        console.print("[red]No biller.yaml found. Are you in the project directory?[/red]")
        raise typer.Exit(1)

    try:
        config = yaml.safe_load(biller_yaml_path.read_text())
    except Exception:
        config = {}

    runtime = config.get("runtime", "docker")

    if runtime == "docker":
        _down_docker(project_dir)
    elif runtime == "native":
        _down_native(project_dir)
    else:
        console.print(f"[red]Unknown runtime '{runtime}'.[/red]")
