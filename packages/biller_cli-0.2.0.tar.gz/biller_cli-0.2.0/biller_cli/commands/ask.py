"""
biller_cli/commands/ask.py

`biller-cli ask` — query the BBPS Biller Integrator knowledge base.

Usage:
  biller-cli ask "How does BOU signature verification work?"
  biller-cli ask --top-k 6 "What does BillingProvider interface expect?"

Flow:
  1. Pre-flight: verify Ollama running, models available
  2. Embed question via qwen3-embedding:0.6b
  3. Retrieve top-k deduplicated chunks from ChromaDB
  4. Build prompt from system template + chunks + question
  5. Stream response via qwen3:8b → Rich Live display
"""

from __future__ import annotations

import sys

import typer
from rich.console import Console

app = typer.Typer(help="Ask a question about the BBPS Biller Integrator codebase.")
console = Console()

# ---------------------------------------------------------------------------
# Prompt template (from Phase 3 plan)
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are an expert on the BBPS Biller Integrator codebase.
Answer questions using only the code context provided.
If the answer is not in the context, say so explicitly — do not guess.
Be specific: name the class, method, or file when relevant.\
"""

USER_PROMPT_TEMPLATE = """\
CODEBASE CONTEXT:
{chunks}

QUESTION:
{question}\
"""


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


@app.callback(invoke_without_command=True)
def ask(
    question: str = typer.Argument(..., help="The question to ask about the codebase."),
    top_k: int = typer.Option(4, "--top-k", "-k", help="Number of context chunks to retrieve."),
) -> None:
    """
    Ask a question about the BBPS Biller Integrator codebase.

    Examples:
      biller-cli ask "How does BOU signature verification work?"
      biller-cli ask "What does BillingProvider interface expect me to implement?"
      biller-cli ask --top-k 6 "How is the database connection configured?"
    """
    from biller_cli.ai.ollama_client import check_ollama_ready, stream_response
    from biller_cli.ai.retriever import retrieve, format_chunks_for_prompt

    # --- Pre-flight ---
    try:
        check_ollama_ready()
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    # --- Retrieve ---
    console.print(f"\n[dim]Searching knowledge base (top-{top_k})...[/dim]")
    try:
        chunks = retrieve(question, top_k=top_k)
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if not chunks:
        console.print("[yellow]No relevant context found in the knowledge base.[/yellow]")
        console.print("Try re-running: biller-cli ingest --source <path>")
        raise typer.Exit(1)

    # Show sources being used
    console.print("[dim]Sources:[/dim]")
    for chunk in chunks:
        tag = "[blue]spec[/blue]" if chunk["doc_type"] == "spec" else "[green]source[/green]"
        console.print(f"  {tag} {chunk['section_id']}")
    console.print()

    # --- Build prompt ---
    chunk_text = format_chunks_for_prompt(chunks)
    user_prompt = USER_PROMPT_TEMPLATE.format(
        chunks=chunk_text,
        question=question,
    )

    # --- Stream response ---
    console.rule("[bold]Answer[/bold]")
    console.print()

    full_response = ""
    try:
        for token in stream_response(user_prompt, SYSTEM_PROMPT):
            full_response += token
            sys.stdout.write(token)
            sys.stdout.flush()
    except RuntimeError as e:
        console.print(f"\n[red]{e}[/red]")
        raise typer.Exit(1)

    console.print("\n")
    console.rule()