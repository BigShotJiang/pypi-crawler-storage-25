"""
biller_cli/commands/setup.py

`biller-cli setup` — first-run setup wizard.

Flow:
  1. Check Ollama is installed and running
  2. List available local models, user picks LLM
  3. Set MCP server URL automatically
  4. Verify MCP server is reachable
  5. Save config and print confirmation

Run this once after installing biller-cli:
  pipx install biller-cli
  biller-cli setup
  biller-cli ask "How does BillFetchService work?"
"""

from __future__ import annotations

import subprocess
import sys

import typer
from rich.console import Console
from rich.panel import Panel

app = typer.Typer(help="First-run setup wizard for biller-cli.")

console = Console()

MCP_SERVER_URL = "https://biller-mcp-production.up.railway.app"

OLLAMA_INSTALL_INSTRUCTIONS = """
Ollama is required to run the local LLM for biller-cli ask and debug.

Install Ollama:
  Linux/Mac : curl -fsSL https://ollama.com/install.sh | sh
  Windows   : https://ollama.com/download

After installing, start Ollama:
  ollama serve

Then pull a model (recommended):
  ollama pull qwen3:8b

Then re-run:
  biller-cli setup
"""

EMBEDDING_MODEL_PATTERNS = [
    "embed",
    "minilm",
    "bge-m3",
    "arctic-embed",
]


def _check_ollama() -> bool:
    """Check if Ollama is installed and running. Returns True if ready."""
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False
    except subprocess.TimeoutExpired:
        return False


def _get_ollama_models() -> list[str]:
    """Return available non-embedding Ollama models."""
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        lines = result.stdout.strip().splitlines()
        models = []
        for line in lines[1:]:
            parts = line.split()
            if not parts:
                continue
            model_name = parts[0]
            if any(p in model_name.lower() for p in EMBEDDING_MODEL_PATTERNS):
                continue
            models.append(model_name)
        return models
    except Exception:
        return []


def _verify_mcp(url: str) -> bool:
    """Verify MCP server is reachable."""
    try:
        import httpx
        # HEAD request to base URL — just check the server responds
        response = httpx.get(url.rstrip("/"), timeout=10)
        return response.status_code in (200, 404, 405, 421, 422)
    except Exception:
        return False


@app.callback(invoke_without_command=True)
def setup() -> None:
    """
    First-run setup wizard for biller-cli.

    Sets up your local LLM model and connects to the BBPS knowledge base.
    Run this once after installing biller-cli.
    """
    from biller_cli.ai.config_manager import set_value, get_llm_model

    console.print()
    console.print(Panel(
        "[bold]biller-cli setup[/bold]\n"
        "This wizard will configure your local LLM and connect you to\n"
        "the BBPS Biller Integrator knowledge base.",
        expand=False,
    ))
    console.print()

    # --- Step 1: Check Ollama ---
    console.print("[bold]Step 1 of 3[/bold] — Checking Ollama...")

    if not _check_ollama():
        console.print()
        console.print("[red]✗ Ollama is not installed or not running.[/red]")
        console.print(OLLAMA_INSTALL_INSTRUCTIONS)
        raise typer.Exit(1)

    console.print("[green]✓[/green] Ollama is running.\n")

    # --- Step 2: Model picker ---
    console.print("[bold]Step 2 of 3[/bold] — Select your LLM model.")
    console.print("[dim]This model will be used for biller-cli ask and debug.[/dim]\n")

    models = _get_ollama_models()

    if not models:
        console.print("[red]✗ No LLM models found in Ollama.[/red]")
        console.print(
            "\nPull a model first:\n"
            "  ollama pull qwen3:8b    [recommended — fast, good instruction following]\n"
            "  ollama pull phi3:latest [smaller — if you have limited RAM]\n"
        )
        console.print("Then re-run: biller-cli setup")
        raise typer.Exit(1)

    current = get_llm_model()

    console.print("Available models:")
    for i, model in enumerate(models, 1):
        marker = " [green]← current[/green]" if model == current else ""
        console.print(f"  [bold]{i}[/bold]. {model}{marker}")

    console.print()

    if len(models) == 1:
        selected = models[0]
        console.print(f"[dim]Only one model available — using {selected}[/dim]")
    else:
        choice_str = typer.prompt(
            f"Select model [1-{len(models)}]",
            default="1",
        )
        try:
            choice = int(choice_str)
            if not 1 <= choice <= len(models):
                raise ValueError
        except ValueError:
            console.print(f"[red]Invalid selection.[/red]")
            raise typer.Exit(1)

        selected = models[choice - 1]

    set_value("llm_model", selected)
    console.print(f"\n[green]✓[/green] LLM model set to: [bold]{selected}[/bold]\n")

    # --- Step 3: MCP server ---
    console.print("[bold]Step 3 of 3[/bold] — Connecting to BBPS knowledge base...")
    console.print(f"[dim]Verifying: {MCP_SERVER_URL}[/dim]")

    if _verify_mcp(MCP_SERVER_URL):
        set_value("mcp_server_url", MCP_SERVER_URL)
        console.print(f"[green]✓[/green] Connected to BBPS knowledge base.\n")
    else:
        console.print(
            f"[yellow]⚠[/yellow] Could not reach the BBPS knowledge base at:\n"
            f"  {MCP_SERVER_URL}\n\n"
            "This may be a temporary issue. The URL has been saved — "
            "biller-cli will retry when you run ask or debug.\n"
        )
        set_value("mcp_server_url", MCP_SERVER_URL)

    # --- Done ---
    console.print(Panel(
        f"[bold green]Setup complete![/bold green]\n\n"
        f"  LLM model : [bold]{selected}[/bold]\n"
        f"  Knowledge : BBPS Biller Integrator (hosted)\n\n"
        f"You can now use:\n"
        f"  [bold]biller-cli ask[/bold] \"How does BillFetchService work?\"\n"
        f"  [bold]biller-cli debug[/bold] \"NoSuchBeanDefinitionException for BillingProvider\"\n"
        f"  [bold]biller-cli config set-model[/bold]  — change LLM model anytime",
        expand=False,
    ))
    console.print()