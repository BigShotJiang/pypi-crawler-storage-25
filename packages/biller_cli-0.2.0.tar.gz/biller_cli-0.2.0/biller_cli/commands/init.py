import os
import shutil
import typer
import yaml
import requests
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm

# Import our custom utilities
from biller_cli.utils.preflight import run_preflight, RuntimeMode
from biller_cli.utils.secrets import write_env_file

app = typer.Typer(help="Scaffold a new project.")
console = Console()

# Fallback registry URL (we will build the real FastAPI registry in Phase 2)
REGISTRY_URL = os.getenv("BILLER_REGISTRY_URL", "https://biller-registry-production.up.railway.app")

def _fetch_bous() -> list[dict]:
    """Fetch available BOUs from the central registry."""
    try:
        resp = requests.get(f"{REGISTRY_URL}/api/v1/bous", timeout=5)
        resp.raise_for_status()
        return resp.json().get("bous", [])
    except requests.RequestException:
        console.print(f"[yellow]⚠ Cannot reach registry at {REGISTRY_URL}[/yellow]")
        console.print("[dim]Using fallback local BOU list for offline development.[/dim]")
        return [
            {
                "id": "nsdl",
                "name": "NSDL Payments Bank",
                "auth_header": "X-NSDL-Auth",
                "environment": {
                    "dev": "https://uat-bou.nsdlbank.com/bbps/callback",
                    "prod": "https://bou.nsdlbank.com/bbps/callback"
                }
            },
            {
                "id": "fino",
                "name": "Fino Payments Bank",
                "auth_header": "X-Fino-Auth",
                "environment": {
                    "dev": "https://uat-bou.finopayments.com/bbps/callback",
                    "prod": "https://bou.finopayments.com/bbps/callback"
                }
            }
        ]

def _select_bou(bous: list[dict], environment: str) -> dict:
    """Show a numbered list of BOUs and let the developer pick one."""
    console.print("\n[bold]Select your target BOU:[/bold]")
    for i, bou in enumerate(bous, 1):
        console.print(f"  {i}. {bou['name']}")

    while True:
        raw = Prompt.ask(">", default="1")
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(bous):
                selected = bous[idx]
                callback_url = selected["environment"].get(
                    environment,
                    selected["environment"].get("dev", "URL_NOT_FOUND")
                )
                console.print(
                    f"\n[green]✓[/green] {selected['name']} selected\n"
                    f"  Callback URL ({environment}): [dim]{callback_url}[/dim]\n"
                )
                return {**selected, "resolved_callback_url": callback_url}
        except (ValueError, IndexError):
            pass
        console.print("[red]Invalid selection. Enter a valid number from the list.[/red]")

@app.callback(invoke_without_command=True)
def init_project(
    output_dir: Path = typer.Option(Path("."), "--output", "-o", help="Directory to create the project in."),
):
    """Scaffold a new Biller Integrator project interactively."""
    runtime = run_preflight()

    console.rule("[bold blue]Biller Integrator Setup Wizard[/bold blue]")

    if runtime == RuntimeMode.NATIVE:
        console.print("[yellow]Notice: Docker not found. Project will be configured for native Maven mode.[/yellow]\n")

    # 1. Base Prompts
    biller_name = Prompt.ask("Biller Name (e.g., electricity-board)")
    environment = Prompt.ask("Environment", choices=["dev", "staging", "prod"], default="dev")

    # 1b. Runtime Selection
    runtime_choice = Prompt.ask("Runtime mode", choices=["docker", "native"], default="native")

    # 2. BOU Selection
    console.print("\n[dim]Fetching available BOUs from registry...[/dim]")
    bous = _fetch_bous()
    if not bous:
        console.print("[red]Error: No BOUs available. Cannot proceed.[/red]")
        raise typer.Exit(1)
    
    selected_bou = _select_bou(bous, environment)

    # 3. BBPS Specifics & Optional Secrets
    biller_id = Prompt.ask(
        "Biller ID [dim](Press Enter to set later — assigned by BBPS after registration)[/dim]",
        default="PENDING",
    )

    console.print("\n[dim]Sensitive credentials (can be left blank for Day 0 setup):[/dim]")
    bou_auth_token = Prompt.ask("BOU Auth Token [dim](Press Enter to skip)[/dim]", password=True, default="")
    bbps_api_key = Prompt.ask("BBPS API Key [dim](Press Enter to skip)[/dim]", password=True, default="")

    secrets = {
        "bou_auth_token": bou_auth_token if bou_auth_token else "PENDING",
        "bbps_api_key": bbps_api_key if bbps_api_key else "PENDING",
        "bbps_cert_path": "CERT_PATH_PLACEHOLDER"  # Replaced after target_path is resolved
    }

    # 4. Overwrite Protection
    target_path = output_dir / biller_name
    if target_path.exists():
        if not Confirm.ask(f"[yellow]Directory '{target_path}' already exists. Overwrite contents?[/yellow]", default=False):
            console.print("Aborting.")
            raise typer.Exit(0)
    else:
        target_path.mkdir(parents=True)
    secrets["bbps_cert_path"] = str(target_path.absolute() / "certs" / "ousigner.p12")

    # 5. Scaffolding Java Template
    template_dir = Path(__file__).parent.parent / "templates"
    if not template_dir.exists():
         console.print(f"[red]Fatal: Template directory not found at {template_dir}[/red]")
         raise typer.Exit(1)

    console.print(f"\n[dim]Copying template to {target_path}...[/dim]")
    shutil.copytree(template_dir, target_path, dirs_exist_ok=True)

    # 6. Scaffold Certs Directory & Gitignore
    certs_dir = target_path / "certs"
    certs_dir.mkdir(exist_ok=True)
    (certs_dir / ".gitignore").write_text("# Never commit certificates\n*.p12\n*.pfx\n")
    console.print(f"[dim]Created isolated certs/ directory.[/dim]")

    # 7. Generate docker-compose.yml dynamically
    compose_content = f"""services:
  biller-middleware:
    build: .
    env_file:
      - .env.biller
    environment:
      - BILLER_NAME={biller_name}
      - BILLER_ID={biller_id}
      - BILLER_ENV={environment}
      - BBPS_CERT_PATH=/app/certs/ousigner.p12
    ports:
      - "8080:8080"
    volumes:
      - ./certs:/app/certs:ro
"""
    (target_path / "docker-compose.yml").write_text(compose_content)

    # 8. Generate basic Dockerfile for the User Layer
    dockerfile_content = """FROM eclipse-temurin:17-jdk-alpine
VOLUME /tmp
COPY biller-user-layer/target/biller-user-layer-*.jar app.jar
ENTRYPOINT ["java","-jar","/app.jar"]
"""
    (target_path / "Dockerfile").write_text(dockerfile_content)

    # 9. Write biller.yaml config
    biller_yaml_data = {
        "version": "1",
        "biller": {
            "name": biller_name,
            "id": biller_id,
            "environment": environment,
        },
        "bou": {
            "id": selected_bou["id"],
            "name": selected_bou["name"],
            "callback_url": selected_bou["resolved_callback_url"],
            "auth_header": selected_bou["auth_header"],
        },
        "core": {"version": "1.0.1"},
        "runtime": runtime_choice,
    }
    
    yaml_path = target_path / "biller.yaml"
    yaml_path.write_text(yaml.dump(biller_yaml_data, default_flow_style=False, sort_keys=False))

    # 10. Manage Secrets
    write_env_file(target_path, secrets)

    # 11. Interpolate POM Pin
    pom_path = target_path / "biller-user-layer" / "pom.xml"
    if pom_path.exists():
        pom_content = pom_path.read_text().replace("{{BILLER_CORE_VERSION}}", "1.0.1")
        pom_path.write_text(pom_content)

    # Wrap up UX
    console.print(f"\n[bold green]✓ Project '{biller_name}' successfully scaffolded![/bold green]")
    
    if biller_id == "PENDING" or not bou_auth_token:
        console.print("\n[yellow]Day 0 Notice:[/yellow] Your Biller ID and/or secrets are PENDING.")
        console.print(f"When ready, drop your certificate into [bold]./{target_path}/certs/ousigner.p12[/bold]")
        console.print("Then update your credentials via:")
        console.print(f"  [bold]cd {target_path} && biller-cli config set biller.id YOUR_ID[/bold]\n")
        
    console.print(f"Detected Runtime: [bold]{runtime.value}[/bold]")
    console.print(f"Next step: [bold]cd {target_path} && biller-cli up[/bold]")