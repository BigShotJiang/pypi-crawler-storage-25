"""
biller_cli/commands/debug.py

`biller-cli debug` — diagnose errors in a running biller integration.

Usage:
  biller-cli debug "NoSuchBeanDefinitionException for BillingProvider"
  biller-cli debug --logs "Application fails to start"
  biller-cli debug --stack "Payment callback not reaching BOU"

Flow:
  1. Pre-flight: verify Ollama running, models available
  2. Collect runtime context:
       - .biller/biller.log last 100 lines (if --logs or --stack)
       - biller.yaml contents (if present in cwd)
       - health endpoint status (http://localhost:8111/health)
  3. Embed error + question
  4. Retrieve top-k deduplicated chunks from ChromaDB
  5. Build prompt: runtime context + stack trace + chunks + question
  6. Stream response via qwen3:8b → Rich Live display
"""

from __future__ import annotations

import sys
from pathlib import Path

import typer
from rich.console import Console

app = typer.Typer(help="Diagnose errors in a running biller integration.")
console = Console()

# ---------------------------------------------------------------------------
# Prompt template (from Phase 3 plan)
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are debugging a BBPS Biller Integrator application.
Use the runtime context and codebase excerpts to diagnose the problem.
Be specific about which file and method is the likely root cause.
If you cannot determine the cause from the context, say so explicitly — do not guess.\
"""

USER_PROMPT_TEMPLATE = """\
RUNTIME CONTEXT:
- biller.yaml: {biller_yaml}
- Health endpoint: {health_status}
- Recent log (last 100 lines):
{log_tail}

RELEVANT CODEBASE:
{chunks}

ERROR / QUESTION:
{question}\
"""

# ---------------------------------------------------------------------------
# Runtime context collectors
# ---------------------------------------------------------------------------

LOG_PATH_CANDIDATES = [
    Path(".biller") / "biller.log",
    Path("biller.log"),
]

HEALTH_URL = "http://localhost:8111/health"
BILLER_YAML_CANDIDATES = [
    Path("biller.yaml"),
    Path(".biller") / "biller.yaml",
]


def _read_log_tail(lines: int = 100) -> str:
    for candidate in LOG_PATH_CANDIDATES:
        if candidate.exists():
            text = candidate.read_text(encoding="utf-8", errors="replace")
            tail = text.splitlines()[-lines:]
            return "\n".join(tail)
    return "(biller.log not found — run from your biller project directory)"


def _read_biller_yaml() -> str:
    for candidate in BILLER_YAML_CANDIDATES:
        if candidate.exists():
            return candidate.read_text(encoding="utf-8", errors="replace")
    return "(biller.yaml not found in current directory)"


def _check_health() -> str:
    try:
        import urllib.request
        with urllib.request.urlopen(HEALTH_URL, timeout=3) as resp:
            return f"HTTP {resp.status} — {resp.read(200).decode('utf-8', errors='replace')}"
    except Exception as e:
        return f"unreachable ({e})"


def _extract_stack_trace(log_text: str) -> str:
    """
    Extract the last stack trace from a log tail.
    Looks for lines starting with 'Exception', 'Error', or '\tat '.
    Returns the stack trace block or empty string if none found.
    """
    lines = log_text.splitlines()
    stack_lines: list[str] = []
    in_stack = False

    for line in lines:
        stripped = line.strip()
        if any(
            stripped.startswith(prefix)
            for prefix in ("Exception", "Error", "Caused by:", "java.")
        ) or stripped.startswith("at "):
            in_stack = True
            stack_lines.append(line)
        elif in_stack and stripped == "":
            # Blank line may end the stack trace
            stack_lines.append(line)
        elif in_stack and not stripped.startswith("at ") and not stripped.startswith("..."):
            in_stack = False

    return "\n".join(stack_lines[-50:]) if stack_lines else ""


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


@app.callback(invoke_without_command=True)
def debug(
    question: str = typer.Argument(..., help="The error or question to diagnose."),
    top_k: int = typer.Option(4, "--top-k", "-k", help="Number of context chunks to retrieve."),
    logs: bool = typer.Option(False, "--logs", help="Read .biller/biller.log automatically."),
    stack: bool = typer.Option(False, "--stack", help="Extract last stack trace from log."),
) -> None:
    """
    Diagnose errors in a running BBPS Biller Integrator application.

    Examples:
      biller-cli debug "Application fails to start with NoSuchBeanDefinitionException"
      biller-cli debug --logs "Payment callback not reaching BOU"
      biller-cli debug --stack "BillingProvider bean missing"
    """
    from biller_cli.ai.ollama_client import check_ollama_ready, stream_response
    from biller_cli.ai.retriever import retrieve, format_chunks_for_prompt

    # --- Pre-flight ---
    try:
        check_ollama_ready()
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    # --- Collect runtime context ---
    console.print("\n[dim]Collecting runtime context...[/dim]")

    biller_yaml = _read_biller_yaml()
    health_status = _check_health()

    log_tail = "(log not requested)"
    if logs or stack:
        raw_log = _read_log_tail(100)
        if stack:
            extracted = _extract_stack_trace(raw_log)
            log_tail = extracted if extracted else raw_log
        else:
            log_tail = raw_log

    console.print(f"  Health: {health_status}")
    if logs or stack:
        log_lines = log_tail.count("\n") + 1
        console.print(f"  Log: {log_lines} lines read")
    console.print()

    # --- Build retrieval query ---
    # Combine question with any extracted stack trace for better retrieval
    retrieval_query = question
    if stack and log_tail != "(log not requested)":
        # Prepend first line of stack trace to improve retrieval signal
        first_error_line = next(
            (l for l in log_tail.splitlines() if l.strip().startswith(("Exception", "Error", "Caused by"))),
            "",
        )
        if first_error_line:
            retrieval_query = f"{first_error_line}\n{question}"

    # --- Retrieve ---
    console.print(f"[dim]Searching knowledge base (top-{top_k})...[/dim]")
    try:
        chunks = retrieve(retrieval_query, top_k=top_k)
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if not chunks:
        console.print("[yellow]No relevant context found in the knowledge base.[/yellow]")
        console.print("Try re-running: biller-cli ingest --source <path>")
        raise typer.Exit(1)

    console.print("[dim]Sources:[/dim]")
    for chunk in chunks:
        tag = "[blue]spec[/blue]" if chunk["doc_type"] == "spec" else "[green]source[/green]"
        console.print(f"  {tag} {chunk['section_id']}")
    console.print()

    # --- Build prompt ---
    chunk_text = format_chunks_for_prompt(chunks)
    user_prompt = USER_PROMPT_TEMPLATE.format(
        biller_yaml=biller_yaml[:500] + "..." if len(biller_yaml) > 500 else biller_yaml,
        health_status=health_status,
        log_tail=log_tail,
        chunks=chunk_text,
        question=question,
    )

    # --- Stream response ---
    console.rule("[bold]Diagnosis[/bold]")
    console.print()

    full_response = ""
    try:
        for token in stream_response(user_prompt, SYSTEM_PROMPT):
            full_response += token
            sys.stdout.write(token)
            sys.stdout.flush()
    except RuntimeError as e:
        console.print(f"\n[red]{e}[/red]")
        raise typer.Exit(1)

    console.print("\n")
    console.rule()