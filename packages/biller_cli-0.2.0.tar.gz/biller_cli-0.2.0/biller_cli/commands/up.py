import os
import time
import subprocess
import yaml
import psutil
import typer
import requests
from pathlib import Path
from rich.console import Console

from biller_cli.utils.preflight import run_preflight, RuntimeMode

app = typer.Typer(help="Start the Biller middleware stack.")
console = Console()

PID_FILE_NAME = ".biller/biller.pid"
LOG_FILE_NAME = ".biller/biller.log"

def _wait_for_health(timeout: int = 90):
    """Polls the Spring Boot actuator endpoint to ensure the service is up."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = requests.get("http://localhost:8111/health", timeout=2)
            if r.status_code == 200:
                console.print("[green]✓ Biller stack is running and healthy.[/green]")
                console.print("Health check: [bold]curl http://localhost:8111/health[/bold]")
                return
        except requests.RequestException:
            pass
        time.sleep(2)
    
    console.print("[yellow]⚠ Stack may still be starting, or health check timed out.[/yellow]")
    console.print("Check manually: [bold]curl http://localhost:8111/health[/bold]")

def _up_docker(project_dir: Path, detach: bool):
    """Orchestrates the Docker Compose stack."""
    compose_file = project_dir / "docker-compose.yml"
    if not compose_file.exists():
        console.print("[red]Fatal: docker-compose.yml not found.[/red]")
        raise typer.Exit(1)

    cmd = ["docker", "compose", "-f", str(compose_file), "up", "--build"]
    if detach:
        cmd.append("-d")

    console.print("[blue]🚀 Starting Biller stack (Docker Mode)...[/blue]")
    result = subprocess.run(cmd)

    if result.returncode != 0:
        console.print("[red]Docker Compose failed to start.[/red]")
        console.print("Run without detach mode for full logs: [bold]biller-cli up --no-detach[/bold]")
        raise typer.Exit(result.returncode)

    if detach:
        _wait_for_health(timeout=30)

def _up_native(project_dir: Path, detach: bool):
    """Starts the application natively via Maven with PID management."""
    biller_dir = project_dir / ".biller"
    biller_dir.mkdir(exist_ok=True)
    
    pid_file = project_dir / PID_FILE_NAME
    log_file = project_dir / LOG_FILE_NAME

    # Guard against duplicate starts
    if pid_file.exists():
        try:
            existing_pid = int(pid_file.read_text().strip())
            if psutil.pid_exists(existing_pid):
                console.print(f"[yellow]Stack is already running (PID {existing_pid}).[/yellow]")
                console.print("Run [bold]biller-cli down[/bold] first to restart.")
                raise typer.Exit(0)
            else:
                pid_file.unlink() # Stale PID, clean it up
        except ValueError:
            pid_file.unlink()

    # Load secrets into process environment
    env = os.environ.copy()
    env_file = project_dir / ".env.biller"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()

    cmd = ["mvn", "spring-boot:run"]
    console.print("[blue]🚀 Starting Biller stack (Native Maven Mode)...[/blue]")
    console.print("[dim]Note: First run compiles the project and takes ~30 seconds.[/dim]")

    if detach:
        with open(log_file, "w") as lf:
            process = subprocess.Popen(
                cmd,
                cwd=str(project_dir / "biller-user-layer"),
                env=env,
                stdout=lf,
                stderr=lf,
            )
        pid_file.write_text(str(process.pid))
        console.print(f"[dim]Process running in background (PID {process.pid}). Logs stored in {log_file}[/dim]")
        _wait_for_health(timeout=90)
    else:
        try:
            subprocess.run(cmd, cwd=str(project_dir / "biller-user-layer"), env=env)
        except KeyboardInterrupt:
            console.print("\n[yellow]Shutting down native process...[/yellow]")

@app.callback(invoke_without_command=True)
def up(
    project_dir: Path = typer.Option(Path("."), "--dir", "-d", help="Project directory"),
    detach: bool = typer.Option(True, "--detach/--no-detach", help="Run in background"),
    runtime_override: str = typer.Option(None, "--runtime", help="Force 'docker' or 'native'"),
):
    """Start the Biller middleware stack (Auto-detects Docker vs Native)."""
    run_preflight(require_runtime=True)

    biller_yaml_path = project_dir / "biller.yaml"
    if not biller_yaml_path.exists():
        console.print(f"[red]No biller.yaml found in {project_dir}. Run 'biller-cli init' first.[/red]")
        raise typer.Exit(1)

    try:
        config = yaml.safe_load(biller_yaml_path.read_text())
    except Exception as e:
        console.print(f"[red]Failed to parse biller.yaml: {e}[/red]")
        raise typer.Exit(1)

    effective_runtime = runtime_override or config.get("runtime", "docker")

    if effective_runtime == "docker":
        _up_docker(project_dir, detach)
    elif effective_runtime == "native":
        _up_native(project_dir, detach)
    else:
        console.print(f"[red]Unknown runtime '{effective_runtime}' in biller.yaml. Use 'docker' or 'native'.[/red]")
        raise typer.Exit(1)
