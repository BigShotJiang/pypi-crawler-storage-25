"""
biller_cli/commands/config.py

`biller-cli config` — view and set biller-cli configuration.

Subcommands:
  biller-cli config show               — print current config
  biller-cli config set-model          — interactive Ollama model picker
  biller-cli config set-mcp <url>      — set hosted MCP server URL

Model picker flow:
  1. Run `ollama list` to get available models
  2. Filter out embedding models (not useful as LLM)
  3. Present numbered list with arrow-key selection via questionary
  4. Save choice to ~/.biller-cli/config.yaml
  5. Confirm with current model shown
"""

from __future__ import annotations

import subprocess
import sys

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(help="View and set biller-cli configuration.")
console = Console()

# Models that are embedding-only — exclude from LLM picker
EMBEDDING_MODEL_PATTERNS = [
    "embed",
    "minilm",
    "bge-m3",
    "arctic-embed",
]


def _get_ollama_models() -> list[str]:
    """
    Run `ollama list` and return model names as a list.
    Filters out embedding-only models.
    Exits with actionable error if Ollama is not running.
    """
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except FileNotFoundError:
        console.print("[red]Ollama is not installed or not on PATH.[/red]")
        console.print("Install from: https://ollama.com")
        raise typer.Exit(1)
    except subprocess.TimeoutExpired:
        console.print("[red]Ollama did not respond within 10 seconds.[/red]")
        console.print("Start it with: ollama serve")
        raise typer.Exit(1)

    lines = result.stdout.strip().splitlines()
    models: list[str] = []

    for line in lines[1:]:  # skip header row
        parts = line.split()
        if not parts:
            continue
        model_name = parts[0]

        # Skip embedding models — they're not useful as LLMs
        if any(pattern in model_name.lower() for pattern in EMBEDDING_MODEL_PATTERNS):
            continue

        models.append(model_name)

    return models


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


@app.command("show")
def show() -> None:
    """Print the current biller-cli configuration."""
    from biller_cli.ai.config_manager import get_all, CONFIG_PATH

    config = get_all()

    table = Table(title="biller-cli configuration", show_header=True)
    table.add_column("Key", style="bold")
    table.add_column("Value")
    table.add_column("Source")

    from biller_cli.ai.config_manager import _load_raw, DEFAULTS
    file_data = _load_raw()

    for key, value in config.items():
        if key == "projects":
            display_value = f"{len(value)} project(s) indexed"
        elif key == "embed_model":
            display_value = str(value)
        else:
            display_value = str(value) if value else "[dim](not set)[/dim]"

        source = "file" if key in file_data else "default"
        table.add_row(key, display_value, f"[dim]{source}[/dim]")

    console.print()
    console.print(table)
    console.print(f"\n[dim]Config file: {CONFIG_PATH}[/dim]")
    console.print()


@app.command("set-model")
def set_model() -> None:
    """
    Interactively select the LLM model from your local Ollama instance.

    Lists all available non-embedding models and lets you pick one.
    The selection is saved to ~/.biller-cli/config.yaml.
    """
    from biller_cli.ai.config_manager import set_value, get_llm_model

    current = get_llm_model()
    console.print(f"\nCurrent LLM model: [bold]{current}[/bold]")
    console.print("[dim]Fetching available models from Ollama...[/dim]\n")

    models = _get_ollama_models()

    if not models:
        console.print("[red]No LLM models found in Ollama.[/red]")
        console.print("Pull a model first, e.g.:")
        console.print("  ollama pull qwen3:8b")
        raise typer.Exit(1)

    # Display numbered list
    console.print("Available models:")
    for i, model in enumerate(models, 1):
        marker = " [green]← current[/green]" if model == current else ""
        console.print(f"  [bold]{i}[/bold]. {model}{marker}")

    console.print()

    # Get selection
    choice_str = typer.prompt(
        f"Select model [1-{len(models)}]",
        default="1",
    )

    try:
        choice = int(choice_str)
        if not 1 <= choice <= len(models):
            raise ValueError
    except ValueError:
        console.print(f"[red]Invalid selection. Enter a number between 1 and {len(models)}.[/red]")
        raise typer.Exit(1)

    selected = models[choice - 1]

    if selected == current:
        console.print(f"\n[dim]Model unchanged: {selected}[/dim]")
        raise typer.Exit(0)

    set_value("llm_model", selected)
    console.print(f"\n[green]✓[/green] LLM model set to: [bold]{selected}[/bold]")
    console.print(f"[dim]Saved to ~/.biller-cli/config.yaml[/dim]\n")


@app.command("set-mcp")
def set_mcp(
    url: str = typer.Argument(..., help="URL of your hosted MCP server."),
) -> None:
    """
    Set the hosted MCP server URL.

    Example:
      biller-cli config set-mcp http://your-server:7337/mcp
    """
    from biller_cli.ai.config_manager import set_value

    if not url.startswith("http"):
        console.print("[red]URL must start with http:// or https://[/red]")
        raise typer.Exit(1)

    set_value("mcp_server_url", url)
    console.print(f"\n[green]✓[/green] MCP server URL set to: [bold]{url}[/bold]")
    console.print("[dim]Saved to ~/.biller-cli/config.yaml[/dim]\n")