import typer
from rich.console import Console

from biller_cli.commands import init, up, down, upgrade, downgrade
from biller_cli.commands import ask, debug, config, setup
from biller_cli.commands import ingest  # imported but not registered in help

app = typer.Typer(
    name="biller-cli",
    help="Manage your Biller Integrator lifecycle: from scaffold to production.",
    add_completion=False,
)

console = Console()

# --- Core lifecycle commands ---
app.add_typer(init.app, name="init")
app.add_typer(up.app, name="up")
app.add_typer(down.app, name="down")
app.add_typer(upgrade.app, name="upgrade")
app.add_typer(downgrade.app, name="downgrade")

# --- AI commands ---
app.add_typer(setup.app, name="setup")
app.add_typer(ask.app, name="ask")
app.add_typer(debug.app, name="debug")
app.add_typer(config.app, name="config")

# --- Internal commands (hidden from end users) ---
# ingest is for maintainer use only — not registered in the public CLI
# Run directly: python -m biller_cli.commands.ingest
_ingest_app = typer.Typer(hidden=True)
app.add_typer(ingest.app, name="ingest", hidden=True)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        None, "--version", "-v",
        is_eager=True,
        help="Print version and exit.",
    ),
):
    if version:
        console.print("biller-cli v0.2.0")
        raise typer.Exit()

    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())


if __name__ == "__main__":
    app()