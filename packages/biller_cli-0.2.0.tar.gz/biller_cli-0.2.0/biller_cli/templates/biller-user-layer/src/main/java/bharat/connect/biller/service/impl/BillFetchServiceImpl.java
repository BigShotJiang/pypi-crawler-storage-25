package bharat.connect.biller.service.impl;

import bharat.connect.biller.common.CommonUtils;
import bharat.connect.biller.model.BillDetails;
import bharat.connect.biller.provider.BillingProvider;
import bharat.connect.biller.provider.CustomerParamCriteriaMapper;
import bharat.connect.biller.rest.OuRestTemplate;
import bharat.connect.biller.service.BillFetchService;
import org.bbps.schema.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import java.io.StringWriter;

@Service
public class BillFetchServiceImpl implements BillFetchService {

    @Autowired
    private BillingProvider billingProvider;

    @Value("${ou.id}")
    private String ouId;

    @Value("${bbps.ip:${bou.domain:${bou.domain}}}")
    private String bbpsIp;

    @Value("${bbps.billfetchresponse.url:${bou.billfetchresponse.url:${bou.billfetchresponse.url}}}")
    private String billFetchResponseUrl;

    @Autowired
    private final OuRestTemplate ouRestTemplate;

    private static final JAXBContext jaxbContext;

    static {
        JAXBContext jaxbContext2 = null;
        try {
            jaxbContext2 = JAXBContext.newInstance(Ack.class, BillFetchResponse.class);
        } catch (JAXBException e) {
            e.printStackTrace();
            jaxbContext2 = null;
        }
        jaxbContext = jaxbContext2;
    }

    public BillFetchServiceImpl(OuRestTemplate ouRestTemplate) {
        this.ouRestTemplate = ouRestTemplate;
    }

    @Async
    @Override
    public void processBillFetchAsync(BillFetchRequest fetchRequest, String referenceId) {
        System.out.println("Processing Bill Fetch");
        if (fetchRequest == null || fetchRequest.getBillDetails() == null || fetchRequest.getBillDetails().getCustomerParams() == null) return;
        BillDetails bd = billingProvider.findLatestUnpaidBill(
                CustomerParamCriteriaMapper.from(fetchRequest.getBillDetails().getCustomerParams())
        );
        if (bd == null) {
            System.out.println("No Bills found");
            return;
        }

        try {
            BillFetchResponse fetchResponse = new BillFetchResponse();
            fetchResponse.setHead(fetchRequest.getHead());
            fetchResponse.setTxn(fetchRequest.getTxn());
            String ts = CommonUtils.getFormattedCurrentTimestamp();
            fetchResponse.getHead().setRefId(fetchRequest.getHead().getRefId());
            fetchResponse.getHead().setTs(ts);
            fetchResponse.getHead().setOrigInst(ouId);
            fetchResponse.getTxn().setTs(fetchRequest.getTxn().getTs());
            fetchResponse.getTxn().setMsgId(fetchRequest.getTxn().getMsgId());
            fetchResponse.getTxn().setTxnReferenceId(fetchRequest.getTxn().getTxnReferenceId());
            BillerResponseType billerResponseType = new BillerResponseType();

            billerResponseType.setAmount(String.valueOf(bd.getBillAmount()));
            billerResponseType.setBillDate(String.valueOf(bd.getBillDate()));
            billerResponseType.setDueDate(String.valueOf(bd.getDueDate()));
//            fetchResponse.getBillerResponses().set(0, billerResponseType);
            fetchResponse.getBillerResponses().add(billerResponseType);
            fetchResponse.setBillDetails(fetchRequest.getBillDetails());
            ReasonType responseReason = new ReasonType();
            responseReason.setResponseCode("000");
            responseReason.setApprovalRefNum("AB123456");
            responseReason.setResponseReason("Successful");
            fetchResponse.setReason(responseReason);
            fetchResponse.getTxn().setRiskScores(null);

            Marshaller marshaller = jaxbContext.createMarshaller();
            StringWriter sw = new StringWriter();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.marshal(fetchResponse, sw);
            System.out.println("========================= BillFetchResponse SENT ================================");
            System.out.println(sw.toString());

            String bbpsBillFetchResponseUrl = bbpsIp + billFetchResponseUrl + fetchResponse.getHead().getRefId();
            ResponseEntity<Ack> ackResponse = ouRestTemplate.postForEntity(
                    bbpsBillFetchResponseUrl,
                    fetchResponse,
                    Ack.class,
                    MediaType.APPLICATION_XML,
                    MediaType.APPLICATION_XML
            );

            System.out.println("==================== Received Ack against Bill Fetch Response ===============");
            System.out.println(ackResponse.getStatusCode());
            if (ackResponse.getBody() != null) {
                JAXBContext ackContext = JAXBContext.newInstance(Ack.class);
                Marshaller ackMarshaller = ackContext.createMarshaller();
                ackMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
                StringWriter ackSw = new StringWriter();
                ackMarshaller.marshal(ackResponse.getBody(), ackSw);
                System.out.println(ackSw);
            } else {
                System.out.println("Ack body is null");
            }
        } catch (JAXBException e1) {
            e1.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
