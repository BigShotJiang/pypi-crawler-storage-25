"""
biller_cli/ai/ingest.py

Chunks source documents and writes embeddings to ChromaDB.

Supported document types:
  - Codebase dump  (contains ## src/ headers) → file-boundary chunking
  - Spec documents (contains ## N. headers)   → heading-boundary chunking

Split strategy:
  Pass 1 — detect doc type, split on appropriate boundary markers
  Pass 2 — split oversized chunks at method/blank/sentence boundaries
            with OVERLAP_TOKENS overlap
  Table guard — table blocks (contiguous | lines) are never split mid-row;
                header row is re-attached if a table must be sub-chunked

Exclusions — dead scaffolding deleted in Phase 0:
  BillerController, UserService, UserServiceImpl,
  UserDao, UserDaoImpl, User.java

Embedding model: qwen3-embedding:0.6b (4096-dim, code + prose aware)
  Previous model (nomic-embed-text, 768-dim) failed on Java identifier
  retrieval. Any existing 768-dim collection must be deleted before re-ingest.

Run:
  biller-cli ingest \
    --source ~/Desktop/repoSpec/bbps_biller_integrator_codebase.md \
    --source ~/Desktop/repoSpec/bbps_bou_integration.md \
    --source ~/Desktop/repoSpec/bbps_schema_specification.md \
    --source ~/Desktop/repoSpec/upms.md
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path
from typing import Generator

import chromadb
import tiktoken

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CHROMA_DIR = Path.home() / ".biller-cli" / "chroma"
COLLECTION_NAME = "biller_codebase"
EMBED_MODEL = "qwen3-embedding:0.6b"
MAX_TOKENS = 256
OVERLAP_TOKENS = 32

# Matches file-level headers in codebase dump only.
# ## src/main/java/... or ## src/main/resources/...
FILE_HEADER_RE = re.compile(r"^## (src/\S+)", re.MULTILINE)

# Matches heading boundaries in spec documents.
# ## 1. Title or ### 1.1 Title — numbered headings only.
SPEC_HEADER_RE = re.compile(r"^#{1,3} \d+[\d.]*[. ]", re.MULTILINE)

# Dead scaffolding — explicitly deleted in Phase 0.
EXCLUDE_PATHS: frozenset[str] = frozenset(
    {
        "src/main/java/bharat/connect/biller/controller/BillerController.java",
        "src/main/java/bharat/connect/biller/service/UserService.java",
        "src/main/java/bharat/connect/biller/service/impl/UserServiceImpl.java",
        "src/main/java/bharat/connect/biller/dao/UserDao.java",
        "src/main/java/bharat/connect/biller/dao/impl/UserDaoImpl.java",
        "src/main/java/bharat/connect/biller/model/User.java",
    }
)

_ENC = tiktoken.get_encoding("cl100k_base")


# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------


def _check_ollama_model(model: str) -> None:
    """Exit with an actionable error if the required Ollama model is not pulled."""
    try:
        result = subprocess.run(
            ["ollama", "list"], capture_output=True, text=True, timeout=10
        )
        if model not in result.stdout:
            print(
                f"\nError: Ollama model '{model}' is not available.\n"
                f"Pull it with:  ollama pull {model}\n"
            )
            sys.exit(1)
    except FileNotFoundError:
        print(
            "\nError: Ollama is not installed or not on PATH.\n"
            "Install from: https://ollama.com\n"
            f"Then run:     ollama pull {model}\n"
        )
        sys.exit(1)
    except subprocess.TimeoutExpired:
        print(
            "\nError: Ollama did not respond within 10 seconds.\n"
            "Start it with: ollama serve\n"
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# Document type detection
# ---------------------------------------------------------------------------


def _is_codebase_dump(text: str) -> bool:
    """Return True if the document contains ## src/ file headers."""
    return bool(FILE_HEADER_RE.search(text))


# ---------------------------------------------------------------------------
# Table-aware block splitter
# ---------------------------------------------------------------------------


def _split_into_blocks(text: str) -> list[dict]:
    """
    Split text into typed blocks: 'table', 'code', or 'prose'.

    Table blocks: contiguous lines starting with |
    Code blocks:  content between ``` fences
    Prose blocks: everything else

    Blocks are never merged here — that happens in the chunking pass.
    Each block is a dict: {"type": str, "text": str}
    """
    blocks: list[dict] = []
    lines = text.splitlines(keepends=True)
    i = 0
    in_code = False
    code_buf: list[str] = []
    table_buf: list[str] = []
    prose_buf: list[str] = []

    def flush_prose():
        if prose_buf:
            blocks.append({"type": "prose", "text": "".join(prose_buf).strip()})
            prose_buf.clear()

    def flush_table():
        if table_buf:
            blocks.append({"type": "table", "text": "".join(table_buf).strip()})
            table_buf.clear()

    def flush_code():
        if code_buf:
            blocks.append({"type": "code", "text": "".join(code_buf).strip()})
            code_buf.clear()

    while i < len(lines):
        line = lines[i]

        # Code fence toggle
        if line.strip().startswith("```"):
            if not in_code:
                flush_prose()
                flush_table()
                in_code = True
                code_buf.append(line)
            else:
                code_buf.append(line)
                in_code = False
                flush_code()
            i += 1
            continue

        if in_code:
            code_buf.append(line)
            i += 1
            continue

        # Table line
        if line.startswith("|"):
            flush_prose()
            table_buf.append(line)
            i += 1
            continue

        # Non-table line after table block — flush table
        if table_buf:
            flush_table()

        prose_buf.append(line)
        i += 1

    # Flush whatever remains
    if in_code:
        flush_code()
    flush_table()
    flush_prose()

    return [b for b in blocks if b["text"]]


def _attach_table_header(table_text: str, sub_rows: str) -> str:
    """
    Given a full table block and a subset of its rows, prepend the
    header row and separator so the sub-chunk is self-contained.
    """
    lines = table_text.splitlines()
    header_lines = []
    for line in lines:
        header_lines.append(line)
        # The separator row (|---|---|) marks end of header
        if re.match(r"^\|[-:| ]+\|", line):
            break
    return "\n".join(header_lines) + "\n" + sub_rows


# ---------------------------------------------------------------------------
# Parsing — Pass 1 (codebase dump)
# ---------------------------------------------------------------------------


def _doc_type_for_path(file_path: str) -> str:
    return "source" if file_path.endswith(".java") else "resource"


def _parse_codebase_sections(
    text: str,
) -> Generator[tuple[str, str, str], None, None]:
    """
    Yield (file_path, content, doc_type) for every ## src/ section.
    Skips EXCLUDE_PATHS.
    """
    matches = list(FILE_HEADER_RE.finditer(text))
    for i, match in enumerate(matches):
        file_path = match.group(1)
        if file_path in EXCLUDE_PATHS:
            continue
        content_start = match.end()
        content_end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        content = text[content_start:content_end].strip()
        if content:
            yield file_path, content, _doc_type_for_path(file_path)


def _parse_spec_sections(
    text: str, source_name: str
) -> Generator[tuple[str, str, str], None, None]:
    """
    Yield (section_id, content, 'spec') for every numbered heading section.

    section_id format: "<source_name>::<heading_text>"
    Falls back to yielding the full document as one section if no
    numbered headings are found.
    """
    matches = list(SPEC_HEADER_RE.finditer(text))

    if not matches:
        # No numbered headings — treat entire file as one section.
        yield f"{source_name}::full", text.strip(), "spec"
        return

    for i, match in enumerate(matches):
        heading_line_end = text.index("\n", match.start())
        heading_text = text[match.start():heading_line_end].strip()
        # Strip markdown # characters for the section_id
        heading_clean = re.sub(r"^#+\s*", "", heading_text)

        content_start = heading_line_end + 1
        content_end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        content = text[content_start:content_end].strip()

        if content:
            section_id = f"{source_name}::{heading_clean}"
            yield section_id, content, "spec"


# ---------------------------------------------------------------------------
# Chunking — Pass 2 (shared)
# ---------------------------------------------------------------------------


def _token_count(text: str) -> int:
    return len(_ENC.encode(text))


def _hard_split(content: str) -> list[str]:
    """Token-boundary split for content with no natural delimiters."""
    tokens = _ENC.encode(content)
    chunks: list[str] = []
    step = MAX_TOKENS - OVERLAP_TOKENS
    for start in range(0, len(tokens), step):
        chunk_tokens = tokens[start: start + MAX_TOKENS]
        chunks.append(_ENC.decode(chunk_tokens))
    return chunks


def _merge_parts(parts: list[str]) -> list[str]:
    """
    Greedily merge parts into chunks under MAX_TOKENS with overlap seeding.
    """
    chunks: list[str] = []
    current = ""

    for part in parts:
        candidate = (current + "\n\n" + part).strip() if current else part.strip()
        if _token_count(candidate) <= MAX_TOKENS:
            current = candidate
        else:
            if current:
                chunks.append(current)
                tail_tokens = _ENC.encode(current)[-OVERLAP_TOKENS:]
                overlap_text = _ENC.decode(tail_tokens)
                current = (overlap_text + "\n\n" + part.strip()).strip()
            else:
                chunks.append(part.strip())
                current = ""

    if current:
        chunks.append(current)

    return [c for c in chunks if c]


def _chunk_blocks(blocks: list[dict]) -> list[str]:
    """
    Convert a list of typed blocks into token-bounded chunks.

    Rules:
    - Table blocks are kept intact if under MAX_TOKENS.
      If over MAX_TOKENS, rows are split but the header is re-attached
      to every sub-chunk.
    - Code blocks are kept intact if under MAX_TOKENS.
      If over, hard-split (no semantic split available).
    - Prose blocks are split at paragraph boundaries then merged greedily.
    """
    result_chunks: list[str] = []

    # Accumulate a prose/code/table working buffer.
    # We flush it when we hit a table that would overflow, or at the end.
    prose_parts: list[str] = []

    def flush_prose_parts():
        if prose_parts:
            merged = _merge_parts(prose_parts)
            result_chunks.extend(merged)
            prose_parts.clear()

    for block in blocks:
        btype = block["type"]
        btext = block["text"]
        btokens = _token_count(btext)

        if btype == "table":
            # Tables cannot be mixed into prose parts — flush first.
            flush_prose_parts()

            if btokens <= MAX_TOKENS:
                result_chunks.append(btext)
            else:
                # Split table by rows, re-attach header to each sub-chunk.
                lines = btext.splitlines()
                # Identify header boundary (header + separator)
                header_end_idx = 0
                for idx, line in enumerate(lines):
                    if re.match(r"^\|[-:| ]+\|", line):
                        header_end_idx = idx
                        break
                header = "\n".join(lines[: header_end_idx + 1])
                data_rows = lines[header_end_idx + 1:]

                row_buf: list[str] = []
                for row in data_rows:
                    candidate = header + "\n" + "\n".join(row_buf + [row])
                    if _token_count(candidate) <= MAX_TOKENS:
                        row_buf.append(row)
                    else:
                        if row_buf:
                            result_chunks.append(
                                header + "\n" + "\n".join(row_buf)
                            )
                        row_buf = [row]
                if row_buf:
                    result_chunks.append(header + "\n" + "\n".join(row_buf))

        elif btype == "code":
            flush_prose_parts()
            if btokens <= MAX_TOKENS:
                result_chunks.append(btext)
            else:
                result_chunks.extend(_hard_split(btext))

        else:  # prose
            # Split on paragraph boundaries, add to prose accumulator.
            paragraphs = re.split(r"\n\n+", btext)
            prose_parts.extend(p.strip() for p in paragraphs if p.strip())

    flush_prose_parts()

    # Safety pass — any chunk still over MAX_TOKENS gets hard-split.
    final: list[str] = []
    for chunk in result_chunks:
        if _token_count(chunk) > MAX_TOKENS:
            final.extend(_hard_split(chunk))
        else:
            final.append(chunk)

    return [c for c in final if c.strip()]


def _chunk_section(section_id: str, content: str, doc_type: str) -> list[dict]:
    """
    Return chunk dicts for a single section (file or spec heading).
    """
    blocks = _split_into_blocks(content)
    sub_chunks = _chunk_blocks(blocks)

    # Determine language tag
    if doc_type in ("source", "resource"):
        if section_id.endswith(".java"):
            language = "java"
        elif section_id.endswith(".xsd"):
            language = "xml"
        elif section_id.endswith(".sql"):
            language = "sql"
        else:
            language = "properties"
    else:
        language = "markdown"

    result = []
    for idx, chunk_text in enumerate(sub_chunks):
        result.append(
            {
                "text": chunk_text,
                "section_id": section_id,
                "chunk_index": idx,
                "language": language,
                "token_count": _token_count(chunk_text),
                "doc_type": doc_type,
            }
        )
    return result


# ---------------------------------------------------------------------------
# Embedding — via Ollama
# ---------------------------------------------------------------------------


def _embed_batch(texts: list[str]) -> list[list[float]]:
    import ollama

    embeddings = []
    for text in texts:
        response = ollama.embeddings(model=EMBED_MODEL, prompt=text)
        embeddings.append(response["embedding"])
    return embeddings


# ---------------------------------------------------------------------------
# ChromaDB write
# ---------------------------------------------------------------------------


def _get_collection(client: chromadb.PersistentClient) -> chromadb.Collection:
    """Delete and recreate collection on every full ingest run."""
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass
    return client.create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )


BATCH_SIZE = 50


def _write_to_chroma(
    collection: chromadb.Collection, chunks: list[dict]
) -> None:
    total = len(chunks)
    for batch_start in range(0, total, BATCH_SIZE):
        batch = chunks[batch_start: batch_start + BATCH_SIZE]
        # Prepend section_id for retrieval context
        texts = [f"{c['section_id']}\n\n{c['text']}" for c in batch]
        embeddings = _embed_batch(texts)
        ids = [
            f"{c['section_id']}::chunk_{c['chunk_index']}" for c in batch
        ]
        metadatas = [
            {
                "section_id": c["section_id"],
                "chunk_index": c["chunk_index"],
                "language": c["language"],
                "token_count": c["token_count"],
                "doc_type": c["doc_type"],
            }
            for c in batch
        ]
        collection.add(
            ids=ids,
            embeddings=embeddings,
            documents=texts,
            metadatas=metadatas,
        )
        done = min(batch_start + BATCH_SIZE, total)
        print(f"  Embedded and stored {done}/{total} chunks...", end="\r")

    print()


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_ingest(source_paths: list[Path]) -> None:
    """
    Full ingest pipeline. Called by `biller-cli ingest --source <path> ...`.

    Accepts multiple source paths. All documents are ingested into a single
    ChromaDB collection in one pass. The collection is deleted and recreated
    on every run — no partial updates.

    Steps:
      1. Pre-flight: verify Ollama + embedding model available
      2. Read and classify each source file
      3. Parse sections (Pass 1) — codebase or spec strategy per file
      4. Chunk sections (Pass 2) — table-aware, overlap-seeded
      5. Write to ChromaDB (delete + recreate collection)
    """
    # --- 1. Pre-flight ---
    print("Checking Ollama availability...")
    _check_ollama_model(EMBED_MODEL)
    print(f"  OK: '{EMBED_MODEL}' is available.\n")

    # --- 2 & 3. Read + parse all sources ---
    all_chunks: list[dict] = []
    total_excluded = 0

    for source_path in source_paths:
        if not source_path.exists():
            print(f"Error: Source file not found: {source_path}")
            sys.exit(1)

        print(f"Reading: {source_path.name}")
        text = source_path.read_text(encoding="utf-8")
        print(f"  {len(text):,} characters loaded.")

        source_name = source_path.stem  # filename without extension

        if _is_codebase_dump(text):
            print(f"  Detected: codebase dump — using file-boundary chunking.")
            section_count = 0
            excluded_count = 0

            for section_id, content, doc_type in _parse_codebase_sections(text):
                section_count += 1
                all_chunks.extend(_chunk_section(section_id, content, doc_type))

            for match in FILE_HEADER_RE.finditer(text):
                if match.group(1) in EXCLUDE_PATHS:
                    excluded_count += 1

            total_excluded += excluded_count
            print(
                f"  {section_count} sections parsed, "
                f"{excluded_count} excluded (dead scaffolding)."
            )
        else:
            print(f"  Detected: spec document — using heading-boundary chunking.")
            section_count = 0

            for section_id, content, doc_type in _parse_spec_sections(text, source_name):
                section_count += 1
                all_chunks.extend(_chunk_section(section_id, content, doc_type))

            print(f"  {section_count} sections parsed.")

        print()

    print(f"Total chunks across all sources: {len(all_chunks)}")
    if total_excluded:
        print(f"Total excluded (dead scaffolding): {total_excluded}")
    print()

    if not all_chunks:
        print("Error: No chunks produced. Verify source file formats.")
        sys.exit(1)

    # --- 4. Embed + write ---
    print(f"Initialising ChromaDB at: {CHROMA_DIR}")
    CHROMA_DIR.mkdir(parents=True, exist_ok=True)
    client = chromadb.PersistentClient(path=str(CHROMA_DIR))
    collection = _get_collection(client)
    print(f"  Collection '{COLLECTION_NAME}' ready (previous data cleared).\n")

    print(f"Embedding and storing {len(all_chunks)} chunks...")
    print(f"  Model: {EMBED_MODEL} (4096-dim, code + prose aware)")
    print("  This will take 45-90 minutes on CPU for a full ingest.\n")
    _write_to_chroma(collection, all_chunks)

    # --- Summary ---
    final_count = collection.count()
    print(f"\nIngest complete.")
    print(f"  Collection : {COLLECTION_NAME}")
    print(f"  Location   : {CHROMA_DIR}")
    print(f"  Chunks     : {final_count}")
    if total_excluded:
        print(f"  Excluded   : {total_excluded} dead scaffolding files")
    print()
    print("Smoke test:")
    print("  python -c \"")
    print("  import chromadb, ollama")
    print(f"  c = chromadb.PersistentClient(path='{CHROMA_DIR}')")
    print(f"  col = c.get_collection('{COLLECTION_NAME}')")
    print(f"  emb = ollama.embeddings(model='{EMBED_MODEL}', prompt='BillFetchService implementation')['embedding']")
    print("  r = col.query(query_embeddings=[emb], n_results=3)")
    print("  [print(m['section_id']) for m in r['metadatas'][0]]")
    print("  \"")
    print()
    print("Pass condition: BillFetchServiceImpl.java appears in top 3 results.")