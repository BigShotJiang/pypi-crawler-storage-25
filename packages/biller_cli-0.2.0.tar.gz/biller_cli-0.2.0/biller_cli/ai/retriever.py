"""
biller_cli/ai/retriever.py

ChromaDB query interface used by `biller-cli ask` and `biller-cli debug`.

Two modes:
  Local  — ChromaDB exists at ~/.biller-cli/chroma/ → query directly
  Remote — ChromaDB missing + mcp_server_url configured → call Railway MCP server

This allows `biller-cli ask` to work on any machine:
  - Your dev machine: uses local ChromaDB (fast, no network)
  - Any other machine: falls back to Railway MCP server (requires internet)

Set the remote URL:
  biller-cli config set-mcp https://biller-mcp-production.up.railway.app
"""

from __future__ import annotations

from pathlib import Path
import re

CHROMA_DIR = Path.home() / ".biller-cli" / "chroma"
COLLECTION_NAME = "biller_codebase"
EMBED_MODEL = "qwen3-embedding:0.6b"
DEDUP_MULTIPLIER = 3

MCP_TOOL_URL_TEMPLATE = "{base_url}/mcp"


# ---------------------------------------------------------------------------
# Mode detection
# ---------------------------------------------------------------------------


def _has_local_chroma() -> bool:
    return CHROMA_DIR.exists()


def _get_mcp_url() -> str:
    """Return configured MCP server URL or empty string."""
    try:
        from biller_cli.ai.config_manager import get_mcp_server_url
        return get_mcp_server_url().strip()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Local retrieval
# ---------------------------------------------------------------------------


def _get_collection():
    import chromadb

    if not CHROMA_DIR.exists():
        raise RuntimeError(
            f"ChromaDB collection not found at {CHROMA_DIR}.\n"
            "Options:\n"
            "  1. Run ingest:  biller-cli ingest --source <path>\n"
            "  2. Set remote:  biller-cli config set-mcp https://biller-mcp-production.up.railway.app"
        )

    try:
        client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        return client.get_collection(COLLECTION_NAME)
    except Exception:
        raise RuntimeError(
            f"ChromaDB collection '{COLLECTION_NAME}' not found.\n"
            "Run: biller-cli ingest --source <path>"
        )


def _embed_query(query: str) -> list[float]:
    import ollama
    response = ollama.embeddings(model=EMBED_MODEL, prompt=query)
    return response["embedding"]


def _retrieve_local(query: str, top_k: int = 4) -> list[dict]:
    """Query local ChromaDB directly."""
    collection = _get_collection()
    fetch_k = top_k * DEDUP_MULTIPLIER
    embedding = _embed_query(query)

    results = collection.query(
        query_embeddings=[embedding],
        n_results=min(fetch_k, collection.count()),
        include=["documents", "metadatas", "distances"],
    )

    documents = results["documents"][0]
    metadatas = results["metadatas"][0]
    distances = results["distances"][0]

    seen: set[str] = set()
    chunks: list[dict] = []

    for doc, meta, dist in zip(documents, metadatas, distances):
        section_id = meta["section_id"]
        if section_id in seen:
            continue
        seen.add(section_id)
        chunks.append({
            "text": doc,
            "section_id": section_id,
            "doc_type": meta["doc_type"],
            "language": meta["language"],
            "distance": dist,
        })
        if len(chunks) >= top_k:
            break

    return chunks


# ---------------------------------------------------------------------------
# Remote retrieval via MCP server
# ---------------------------------------------------------------------------


def _retrieve_remote(query: str, top_k: int, mcp_url: str) -> list[dict]:
    """
    Call the Railway MCP server using the official MCP SSE client.
    """
    import asyncio
    import json
    import re
    from mcp.client.sse import sse_client
    from mcp import ClientSession

    async def _call():
        url = mcp_url.rstrip("/") + "/sse"
        async with sse_client(url) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(
                    "ask_codebase",
                    {"question": query, "top_k": top_k},
                )
                for item in result.content:
                    if hasattr(item, "text"):
                        return item.text
        return ""

    try:
        result_text = asyncio.run(_call())
    except Exception as e:
        raise RuntimeError(f"MCP server error: {e}")

    if not result_text:
        return []

    # Parse chunks from formatted response
    chunks = []
    parts = re.split(r"--- Source \d+: ", result_text)
    for part in parts[1:]:
        lines = part.strip().splitlines()
        if not lines:
            continue
        header = lines[0]
        header_match = re.match(r"(.+?)\s+\[(\w+)\]\s+\(distance: ([\d.]+)\)\s+---", header)
        if header_match:
            chunks.append({
                "text": "\n".join(lines[1:]).strip(),
                "section_id": header_match.group(1),
                "doc_type": header_match.group(2),
                "language": "unknown",
                "distance": float(header_match.group(3)),
            })
    return chunks


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------


def retrieve(query: str, top_k: int = 4) -> list[dict]:
    """
    Retrieve top-k deduplicated chunks relevant to the query.

    Automatically selects local or remote mode:
    - Local ChromaDB present → query directly (fast)
    - No local ChromaDB + mcp_server_url set → query Railway MCP server
    - Neither → raise RuntimeError with actionable message

    Returns list of dicts with: text, section_id, doc_type, language, distance
    """
    if _has_local_chroma():
        return _retrieve_local(query, top_k)

    mcp_url = _get_mcp_url()
    if mcp_url:
        return _retrieve_remote(query, top_k, mcp_url)

    raise RuntimeError(
        "No knowledge base available.\n\n"
        "Option 1 — Use remote knowledge base (recommended for most machines):\n"
        "  biller-cli config set-mcp https://biller-mcp-production.up.railway.app\n\n"
        "Option 2 — Ingest locally (requires source files and Ollama):\n"
        "  biller-cli ingest --source ~/Desktop/repoSpec/bbps_biller_integrator_codebase.md \\\n"
        "    --source ~/Desktop/repoSpec/bbps_bou_integration.md \\\n"
        "    --source ~/Desktop/repoSpec/bbps_schema_specification.md \\\n"
        "    --source ~/Desktop/repoSpec/upms.md"
    )


def format_chunks_for_prompt(chunks: list[dict]) -> str:
    """Format retrieved chunks into a single string for prompt injection."""
    parts = []
    for i, chunk in enumerate(chunks, 1):
        parts.append(
            f"--- Source {i}: {chunk['section_id']} ---\n{chunk['text']}"
        )
    return "\n\n".join(parts)