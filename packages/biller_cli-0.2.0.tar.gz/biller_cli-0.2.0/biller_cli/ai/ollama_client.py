"""
biller_cli/ai/ollama_client.py

Thin wrapper around the ollama Python library.

Responsibilities:
  - Read LLM model from ~/.biller-cli/config.yaml via config_manager
  - Pre-flight check: verify Ollama is running and required models are available
  - Provide a streaming chat interface for ask and debug commands
  - Return clean actionable errors — never raw connection exceptions

Models:
  LLM        : read from config (default: qwen3:8b)
  Embeddings : read from config (default: qwen3-embedding:0.6b)
              handled by retriever.py directly
"""

from __future__ import annotations

from typing import Generator


def _get_llm_model() -> str:
    from biller_cli.ai.config_manager import get_llm_model
    return get_llm_model()


def _get_embed_model() -> str:
    from biller_cli.ai.config_manager import get_embed_model
    return get_embed_model()


def _not_running_message() -> str:
    llm = _get_llm_model()
    embed = _get_embed_model()
    return (
        "\nOllama is not running. Start it with:\n"
        "  ollama serve\n\n"
        f"Required models: {llm}, {embed}\n"
        "Pull with:\n"
        f"  ollama pull {llm}\n"
        f"  ollama pull {embed}\n"
    )


def check_ollama_ready() -> None:
    """
    Verify Ollama is running and both required models are available.
    Raises RuntimeError with actionable message on any failure.
    Does NOT exit — callers decide how to handle.
    """
    import subprocess

    llm_model = _get_llm_model()
    embed_model = _get_embed_model()

    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "\nOllama is not installed or not on PATH.\n"
            "Install from: https://ollama.com\n"
            + _not_running_message()
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError(
            "\nOllama did not respond within 10 seconds.\n"
            + _not_running_message()
        )

    available = result.stdout

    for model in (llm_model, embed_model):
        if model not in available:
            raise RuntimeError(
                f"\nOllama model '{model}' is not available.\n"
                f"Pull it with:\n"
                f"  ollama pull {model}\n"
            )


def stream_response(prompt: str, system: str) -> Generator[str, None, None]:
    """
    Stream a response from the LLM token by token.

    Reads the LLM model from config on every call — picks up model
    changes made via `biller-cli config set-model` without restart.

    Handles qwen3 thinking mode: <think>...</think> blocks are stripped
    from the stream. Empty tokens are skipped. Only answer tokens are yielded.

    Yields string tokens as they arrive from Ollama.
    Raises RuntimeError if Ollama is not reachable.
    """
    import ollama

    llm_model = _get_llm_model()

    try:
        stream = ollama.chat(
            model=llm_model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            stream=True,
        )

        # Buffer to detect and strip <think>...</think> blocks.
        # qwen3:8b emits these before the actual answer.
        in_think = False
        buf = ""

        for chunk in stream:
            token = chunk["message"]["content"]
            if not token:
                continue

            buf += token

            # Process buffer character by character to handle
            # think tags that arrive split across multiple tokens.
            while buf:
                if in_think:
                    end = buf.find("</think>")
                    if end == -1:
                        # Still inside think block — discard entire buffer
                        buf = ""
                        break
                    else:
                        # Found end of think block — discard up to and including </think>
                        buf = buf[end + len("</think>"):]
                        in_think = False
                else:
                    start = buf.find("<think>")
                    if start == -1:
                        # No think block — yield everything
                        yield buf
                        buf = ""
                        break
                    elif start > 0:
                        # Yield content before the think block
                        yield buf[:start]
                        buf = buf[start:]
                    else:
                        # buf starts with <think>
                        in_think = True
                        buf = buf[len("<think>"):]

        # Yield any remaining buffer content after stream ends
        if buf and not in_think:
            yield buf

    except Exception as e:
        error_str = str(e).lower()
        if "connection" in error_str or "refused" in error_str:
            raise RuntimeError(_not_running_message())
        raise RuntimeError(f"Ollama error: {e}")