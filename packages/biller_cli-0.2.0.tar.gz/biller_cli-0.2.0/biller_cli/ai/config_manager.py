"""
biller_cli/ai/config_manager.py

Read and write ~/.biller-cli/config.yaml.

This is the single source of truth for all user-configurable settings.
All other modules read from here — nothing hardcodes model names directly.

Schema (v1):
  llm_model:      str   — Ollama model used for ask/debug LLM calls
  embed_model:    str   — Ollama model used for embeddings (locked, not user-configurable)
  mcp_server_url: str   — Hosted MCP server URL (empty until Step 3.6)
  projects:       dict  — Per-project sync metadata (populated by biller-cli sync)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

CONFIG_DIR = Path.home() / ".biller-cli"
CONFIG_PATH = CONFIG_DIR / "config.yaml"

# Defaults — used when config file does not exist or key is missing
DEFAULTS: dict[str, Any] = {
    "llm_model": "qwen3:8b",
    "embed_model": "qwen3-embedding:0.6b",
    "mcp_server_url": "",
    "projects": {},
}


def _load_raw() -> dict[str, Any]:
    """Load raw config dict from disk. Returns empty dict if file missing."""
    if not CONFIG_PATH.exists():
        return {}
    try:
        with CONFIG_PATH.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_raw(data: dict[str, Any]) -> None:
    """Write config dict to disk, creating directory if needed."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with CONFIG_PATH.open("w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=False, allow_unicode=True)


def get(key: str) -> Any:
    """
    Get a config value by key.
    Falls back to DEFAULTS if key is not set in the config file.
    """
    data = _load_raw()
    return data.get(key, DEFAULTS.get(key))


def set_value(key: str, value: Any) -> None:
    """
    Set a config value and persist to disk.
    Only allows setting keys that exist in DEFAULTS — rejects unknown keys.
    """
    if key not in DEFAULTS:
        raise ValueError(f"Unknown config key: '{key}'. Valid keys: {list(DEFAULTS.keys())}")
    data = _load_raw()
    data[key] = value
    _save_raw(data)


def get_all() -> dict[str, Any]:
    """
    Return the full resolved config — file values merged over defaults.
    What you see is what every module will use.
    """
    data = _load_raw()
    resolved = {**DEFAULTS, **data}
    return resolved


def get_llm_model() -> str:
    return str(get("llm_model"))


def get_embed_model() -> str:
    return str(get("embed_model"))


def get_mcp_server_url() -> str:
    return str(get("mcp_server_url"))