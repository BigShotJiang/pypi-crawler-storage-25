"""
tests/unit/test_preflight.py

Unit tests for biller_cli/utils/preflight.py
"""

import subprocess
import sys
from unittest.mock import MagicMock, patch

import pytest

from biller_cli.utils.preflight import (
    RuntimeMode,
    _check_docker_daemon,
    _check_docker_installed,
    _check_git,
    _check_java,
    _check_maven,
    _check_python,
    detect_runtime,
    run_preflight,
)


# ---------------------------------------------------------------------------
# Individual check functions
# ---------------------------------------------------------------------------


class TestCheckPython:
    def test_passes_on_current_interpreter(self):
        # The test is running on Python 3.10+ (enforced by pyproject.toml)
        assert _check_python() is True

    def test_fails_on_old_version(self):
        with patch.object(sys, "version_info", (3, 9, 0)):
            assert _check_python() is False


class TestCheckGit:
    def test_passes_when_git_on_path(self):
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/git"):
            assert _check_git() is True

    def test_fails_when_git_not_on_path(self):
        with patch("biller_cli.utils.preflight.shutil.which", return_value=None):
            assert _check_git() is False


class TestCheckJava:
    def test_passes_for_java_17(self):
        mock_result = MagicMock()
        mock_result.stderr = 'openjdk version "17.0.1" 2021-10-19\n'
        mock_result.stdout = ""
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/java"), \
             patch("biller_cli.utils.preflight.subprocess.run", return_value=mock_result):
            assert _check_java() is True

    def test_passes_for_java_21(self):
        mock_result = MagicMock()
        mock_result.stderr = 'openjdk version "21.0.1" 2023-10-17\n'
        mock_result.stdout = ""
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/java"), \
             patch("biller_cli.utils.preflight.subprocess.run", return_value=mock_result):
            assert _check_java() is True

    def test_fails_for_java_11(self):
        mock_result = MagicMock()
        mock_result.stderr = 'openjdk version "11.0.1" 2018-10-16\n'
        mock_result.stdout = ""
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/java"), \
             patch("biller_cli.utils.preflight.subprocess.run", return_value=mock_result):
            assert _check_java() is False

    def test_fails_for_legacy_java_8(self):
        mock_result = MagicMock()
        mock_result.stderr = 'java version "1.8.0_292"\n'
        mock_result.stdout = ""
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/java"), \
             patch("biller_cli.utils.preflight.subprocess.run", return_value=mock_result):
            assert _check_java() is False

    def test_fails_when_java_not_on_path(self):
        with patch("biller_cli.utils.preflight.shutil.which", return_value=None):
            assert _check_java() is False


class TestCheckMaven:
    def test_passes_when_mvn_on_path(self):
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/mvn"):
            assert _check_maven() is True

    def test_fails_when_mvn_not_on_path(self):
        with patch("biller_cli.utils.preflight.shutil.which", return_value=None):
            assert _check_maven() is False


class TestCheckDocker:
    def test_installed_passes_when_docker_on_path(self):
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/docker"):
            assert _check_docker_installed() is True

    def test_installed_fails_when_docker_not_on_path(self):
        with patch("biller_cli.utils.preflight.shutil.which", return_value=None):
            assert _check_docker_installed() is False

    def test_daemon_passes_when_docker_info_succeeds(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/docker"), \
             patch("biller_cli.utils.preflight.subprocess.run", return_value=mock_result):
            assert _check_docker_daemon() is True

    def test_daemon_fails_when_docker_info_fails(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        with patch("biller_cli.utils.preflight.shutil.which", return_value="/usr/bin/docker"), \
             patch("biller_cli.utils.preflight.subprocess.run", return_value=mock_result):
            assert _check_docker_daemon() is False

    def test_daemon_fails_when_docker_not_installed(self):
        with patch("biller_cli.utils.preflight.shutil.which", return_value=None):
            assert _check_docker_daemon() is False


# ---------------------------------------------------------------------------
# detect_runtime
# ---------------------------------------------------------------------------


class TestDetectRuntime:
    def test_returns_docker_when_daemon_running(self):
        with patch("biller_cli.utils.preflight._check_docker_daemon", return_value=True):
            assert detect_runtime() == RuntimeMode.DOCKER

    def test_returns_native_when_no_docker_but_java_and_maven(self):
        with patch("biller_cli.utils.preflight._check_docker_daemon", return_value=False), \
             patch("biller_cli.utils.preflight._check_java", return_value=True), \
             patch("biller_cli.utils.preflight._check_maven", return_value=True):
            assert detect_runtime() == RuntimeMode.NATIVE

    def test_returns_none_when_nothing_available(self):
        with patch("biller_cli.utils.preflight._check_docker_daemon", return_value=False), \
             patch("biller_cli.utils.preflight._check_java", return_value=False), \
             patch("biller_cli.utils.preflight._check_maven", return_value=False):
            assert detect_runtime() == RuntimeMode.NONE

    def test_docker_takes_priority_over_native(self):
        with patch("biller_cli.utils.preflight._check_docker_daemon", return_value=True), \
             patch("biller_cli.utils.preflight._check_java", return_value=True), \
             patch("biller_cli.utils.preflight._check_maven", return_value=True):
            assert detect_runtime() == RuntimeMode.DOCKER


# ---------------------------------------------------------------------------
# run_preflight
# ---------------------------------------------------------------------------


class TestRunPreflight:
    def test_exits_1_when_git_missing(self):
        failing_checks = [{"name": "Git", "check": lambda: False, "fix": "install git"}]
        with patch("biller_cli.utils.preflight.UNIVERSAL_CHECKS", failing_checks):
            with pytest.raises(SystemExit) as exc:
                run_preflight()
            assert exc.value.code == 1

    def test_exits_1_when_no_runtime_and_require_runtime_true(self):
        with patch("biller_cli.utils.preflight._check_python", return_value=True), \
             patch("biller_cli.utils.preflight._check_git", return_value=True), \
             patch("biller_cli.utils.preflight.detect_runtime", return_value=RuntimeMode.NONE):
            with pytest.raises(SystemExit) as exc:
                run_preflight(require_runtime=True)
            assert exc.value.code == 1

    def test_does_not_exit_when_no_runtime_and_require_runtime_false(self):
        with patch("biller_cli.utils.preflight._check_python", return_value=True), \
             patch("biller_cli.utils.preflight._check_git", return_value=True), \
             patch("biller_cli.utils.preflight.detect_runtime", return_value=RuntimeMode.NONE):
            # Should not raise
            result = run_preflight(require_runtime=False)
            assert result == RuntimeMode.NONE

    def test_returns_docker_mode_on_success(self):
        with patch("biller_cli.utils.preflight._check_python", return_value=True), \
             patch("biller_cli.utils.preflight._check_git", return_value=True), \
             patch("biller_cli.utils.preflight.detect_runtime", return_value=RuntimeMode.DOCKER):
            result = run_preflight()
            assert result == RuntimeMode.DOCKER