"""
tests/unit/test_main.py

Tests for biller_cli/main.py (CLI entry point) and additional coverage
for uncovered paths in upgrade.py and downgrade.py.
"""

import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
from typer.testing import CliRunner

from biller_cli.main import app
from biller_cli.commands.upgrade import _run_sandbox_build, _fetch_latest_version
from biller_cli.commands.downgrade import _get_registry_url, _version_exists_in_registry

runner = CliRunner()


# ---------------------------------------------------------------------------
# main.py — CLI entry point
# ---------------------------------------------------------------------------


class TestMainVersion:
    def test_version_flag_prints_version(self):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_short_version_flag(self):
        result = runner.invoke(app, ["-v"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_no_subcommand_prints_help(self):
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        # Help output must mention the available subcommands
        assert "init" in result.output
        assert "upgrade" in result.output
        assert "downgrade" in result.output

    def test_help_flag(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "biller-cli" in result.output.lower() or "Manage" in result.output


# ---------------------------------------------------------------------------
# upgrade.py — _run_sandbox_build uncovered paths
# ---------------------------------------------------------------------------


class TestRunSandboxBuild:
    def test_returns_true_when_no_git_repo(self, tmp_path):
        """No .git directory — sandbox skipped, returns True (non-blocking)."""
        result = _run_sandbox_build(tmp_path, "1.1.0")
        assert result is True

    def test_returns_true_when_maven_not_on_path(self, tmp_path):
        """Maven not installed — sandbox skipped, returns True."""
        (tmp_path / ".git").mkdir()
        with patch("biller_cli.commands.upgrade.shutil.which", return_value=None):
            result = _run_sandbox_build(tmp_path, "1.1.0")
        assert result is True

    def test_returns_true_when_worktree_creation_fails(self, tmp_path):
        """git worktree add fails — sandbox skipped, returns True (non-blocking)."""
        import textwrap
        (tmp_path / ".git").mkdir()
        (tmp_path / "biller.yaml").write_text(
            "core:\n  version: 1.0.0\nbou:\n  id: test\n"
        )
        (tmp_path / "pom.xml").write_text(textwrap.dedent("""\
            <?xml version="1.0" encoding="UTF-8"?>
            <project xmlns="http://maven.apache.org/POM/4.0.0"
                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                     http://maven.apache.org/xsd/maven-4.0.0.xsd">
                <modelVersion>4.0.0</modelVersion>
                <groupId>com.bharatconnect.biller</groupId>
                <artifactId>biller-user-layer</artifactId>
                <version>1.0.0</version>
                <properties>
                    <biller.core.version>1.0.0</biller.core.version>
                </properties>
            </project>
        """))
        failed_result = MagicMock()
        failed_result.returncode = 1
        failed_result.stderr = "fatal: not a git repository"
        with patch("biller_cli.commands.upgrade.shutil.which", return_value="/usr/bin/mvn"), \
             patch("biller_cli.commands.upgrade.subprocess.run", return_value=failed_result):
            result = _run_sandbox_build(tmp_path, "1.1.0")
        assert result is True

    def test_returns_false_when_maven_build_fails(self, tmp_path):
        """Worktree created, mvn build fails — returns False, version pin not updated."""
        import textwrap
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        worktree = tmp_path / ".biller" / "sandbox-1.1.0"
        worktree.mkdir(parents=True)
        # Scaffold files in worktree so set_version_pin works
        (worktree / "biller.yaml").write_text("core:\n  version: 1.0.0\nbou:\n  id: test\n")
        (worktree / "pom.xml").write_text(textwrap.dedent("""\
            <?xml version="1.0" encoding="UTF-8"?>
            <project xmlns="http://maven.apache.org/POM/4.0.0"
                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                     http://maven.apache.org/xsd/maven-4.0.0.xsd">
                <modelVersion>4.0.0</modelVersion>
                <groupId>com.bharatconnect.biller</groupId>
                <artifactId>biller-user-layer</artifactId>
                <version>1.0.0</version>
                <properties>
                    <biller.core.version>1.0.0</biller.core.version>
                </properties>
            </project>
        """))

        worktree_ok = MagicMock()
        worktree_ok.returncode = 0

        build_failed = MagicMock()
        build_failed.returncode = 1

        cleanup_ok = MagicMock()
        cleanup_ok.returncode = 0

        with patch("biller_cli.commands.upgrade.shutil.which", return_value="/usr/bin/mvn"), \
             patch("biller_cli.commands.upgrade.subprocess.run",
                   side_effect=[worktree_ok, build_failed, cleanup_ok]):
            result = _run_sandbox_build(tmp_path, "1.1.0")
        assert result is False

    def test_returns_true_when_maven_build_passes(self, tmp_path):
        """Worktree created, mvn build passes — returns True."""
        import textwrap
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        worktree = tmp_path / ".biller" / "sandbox-1.1.0"
        worktree.mkdir(parents=True)
        (worktree / "biller.yaml").write_text("core:\n  version: 1.0.0\nbou:\n  id: test\n")
        (worktree / "pom.xml").write_text(textwrap.dedent("""\
            <?xml version="1.0" encoding="UTF-8"?>
            <project xmlns="http://maven.apache.org/POM/4.0.0"
                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                     http://maven.apache.org/xsd/maven-4.0.0.xsd">
                <modelVersion>4.0.0</modelVersion>
                <groupId>com.bharatconnect.biller</groupId>
                <artifactId>biller-user-layer</artifactId>
                <version>1.0.0</version>
                <properties>
                    <biller.core.version>1.0.0</biller.core.version>
                </properties>
            </project>
        """))

        ok = MagicMock()
        ok.returncode = 0

        with patch("biller_cli.commands.upgrade.shutil.which", return_value="/usr/bin/mvn"), \
             patch("biller_cli.commands.upgrade.subprocess.run",
                   side_effect=[ok, ok, ok]):
            result = _run_sandbox_build(tmp_path, "1.1.0")
        assert result is True


# ---------------------------------------------------------------------------
# upgrade.py — _fetch_latest_version error path
# ---------------------------------------------------------------------------


class TestFetchLatestVersion:
    def test_exits_1_on_network_error(self):
        import requests as req
        import typer
        with patch("biller_cli.commands.upgrade.requests.get",
                   side_effect=req.ConnectionError("down")):
            with pytest.raises(typer.Exit) as exc:
                _fetch_latest_version("https://registry.example.com")
            assert exc.value.exit_code == 1


# ---------------------------------------------------------------------------
# downgrade.py — _get_registry_url and _version_exists_in_registry
# ---------------------------------------------------------------------------


class TestDowngradeRegistryUrl:
    def test_returns_default_when_no_env_file(self, tmp_path):
        url = _get_registry_url(tmp_path)
        assert url == "https://biller-registry-production.up.railway.app"

    def test_reads_from_env_biller(self, tmp_path):
        (tmp_path / ".env.biller").write_text(
            "BILLER_REGISTRY_URL=https://custom.registry.com\n"
        )
        assert _get_registry_url(tmp_path) == "https://custom.registry.com"


class TestVersionExistsInRegistry:
    def test_returns_true_when_version_present(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"versions": {"1.0.0": {}, "1.1.0": {}}}
        with patch("requests.get", return_value=mock_resp):
            assert _version_exists_in_registry("https://registry.example.com", "1.0.0") is True

    def test_returns_false_when_version_absent(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"versions": {"1.0.0": {}}}
        with patch("requests.get", return_value=mock_resp):
            assert _version_exists_in_registry("https://registry.example.com", "0.9.0") is False

    def test_returns_true_when_registry_returns_non_200(self):
        """Fail open — non-200 must not block downgrade."""
        mock_resp = MagicMock()
        mock_resp.status_code = 503
        with patch("requests.get", return_value=mock_resp):
            assert _version_exists_in_registry("https://registry.example.com", "1.0.0") is True

    def test_returns_true_on_connection_error(self):
        """Fail open — network error must not block downgrade."""
        import requests as req
        with patch("requests.get", side_effect=req.ConnectionError("down")):
            assert _version_exists_in_registry("https://registry.example.com", "1.0.0") is True