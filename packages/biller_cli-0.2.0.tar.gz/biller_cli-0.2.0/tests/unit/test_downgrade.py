"""
tests/unit/test_downgrade.py

Unit tests for biller_cli/commands/downgrade.py
"""

import textwrap
import yaml
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
from typer.testing import CliRunner

from biller_cli.commands.downgrade import app, _get_registry_url
from biller_cli.utils.version_pin import get_version_pin

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _scaffold(tmp_path: Path, version: str = "1.1.0") -> Path:
    bp = tmp_path / "biller.yaml"
    bp.write_text(yaml.dump(
        {"core": {"version": version}, "bou": {"id": "test-bou"}},
        default_flow_style=False,
        sort_keys=False,
    ))
    pom = tmp_path / "pom.xml"
    pom.write_text(textwrap.dedent(f"""\
        <?xml version="1.0" encoding="UTF-8"?>
        <project xmlns="http://maven.apache.org/POM/4.0.0"
                 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                 xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                 http://maven.apache.org/xsd/maven-4.0.0.xsd">
            <modelVersion>4.0.0</modelVersion>
            <groupId>com.bharatconnect.biller</groupId>
            <artifactId>biller-user-layer</artifactId>
            <version>1.0.0</version>
            <properties>
                <biller.core.version>{version}</biller.core.version>
            </properties>
        </project>
    """))
    return tmp_path


def _mock_registry_has_version(version: str) -> MagicMock:
    m = MagicMock()
    m.status_code = 200
    m.json.return_value = {"versions": {version: {}}}
    return m


def _mock_registry_missing_version() -> MagicMock:
    m = MagicMock()
    m.status_code = 200
    m.json.return_value = {"versions": {"1.1.0": {}}}
    return m


# ---------------------------------------------------------------------------
# Guard conditions
# ---------------------------------------------------------------------------


class TestDowngradeGuards:
    def test_target_same_as_current_exits_0(self, tmp_path):
        _scaffold(tmp_path, "1.1.0")
        with patch("requests.get",
                   return_value=_mock_registry_has_version("1.1.0")):
            result = runner.invoke(app, ["--dir", str(tmp_path), "--to", "1.1.0"])
        assert result.exit_code == 0
        assert "Nothing to do" in result.output

    def test_target_newer_than_current_exits_1(self, tmp_path):
        _scaffold(tmp_path, "1.0.0")
        with patch("requests.get",
                   return_value=_mock_registry_has_version("1.1.0")):
            result = runner.invoke(app, ["--dir", str(tmp_path), "--to", "1.1.0"])
        assert result.exit_code == 1
        assert "upgrade" in result.output.lower()

    def test_version_not_in_registry_exits_1(self, tmp_path):
        _scaffold(tmp_path, "1.1.0")
        with patch("requests.get",
                   return_value=_mock_registry_missing_version()):
            result = runner.invoke(app, ["--dir", str(tmp_path), "--to", "0.9.0"])
        assert result.exit_code == 1
        assert "not in the registry" in result.output

    def test_registry_unreachable_proceeds_fails_open(self, tmp_path):
        """
        If the registry is unreachable, downgrade must NOT block.
        _version_exists_in_registry returns True on exception — fail open.
        """
        _scaffold(tmp_path, "1.1.0")
        import requests as req
        with patch("requests.get",
                   side_effect=req.ConnectionError("unreachable")):
            # Confirm the prompt with "y"
            result = runner.invoke(
                app, ["--dir", str(tmp_path), "--to", "1.0.0"], input="y\n"
            )
        # Should NOT exit 1 due to registry unreachability
        assert result.exit_code == 0
        assert get_version_pin(tmp_path) == "1.0.0"


# ---------------------------------------------------------------------------
# DB warning
# ---------------------------------------------------------------------------


class TestDbWarning:
    def test_db_warning_printed_before_confirmation(self, tmp_path):
        """
        The DATABASE WARNING must appear in the output before the confirmation
        prompt. This is a hard architectural rule — the developer must see it
        before being asked to proceed.
        """
        _scaffold(tmp_path, "1.1.0")
        with patch("requests.get",
                   return_value=_mock_registry_has_version("1.0.0")):
            result = runner.invoke(
                app, ["--dir", str(tmp_path), "--to", "1.0.0"], input="y\n"
            )
        output = result.output
        warning_pos = output.find("DATABASE WARNING")
        confirm_pos = output.find("Continue with downgrade?")
        assert warning_pos != -1, "DATABASE WARNING not found in output"
        assert confirm_pos != -1, "Confirmation prompt not found in output"
        assert warning_pos < confirm_pos, (
            "DATABASE WARNING must appear BEFORE the confirmation prompt. "
            f"warning at {warning_pos}, confirm at {confirm_pos}"
        )

    def test_db_warning_always_shown_no_exceptions(self, tmp_path):
        """DB warning is unconditional — no code path may skip it."""
        _scaffold(tmp_path, "1.1.0")
        with patch("requests.get",
                   return_value=_mock_registry_has_version("1.0.0")):
            # Abort at confirmation — warning must still have been printed
            result = runner.invoke(
                app, ["--dir", str(tmp_path), "--to", "1.0.0"], input="n\n"
            )
        assert "DATABASE WARNING" in result.output


# ---------------------------------------------------------------------------
# Version pin correctness
# ---------------------------------------------------------------------------


class TestDowngradeVersionPin:
    def test_version_pin_updated_after_confirmation(self, tmp_path):
        _scaffold(tmp_path, "1.1.0")
        with patch("requests.get",
                   return_value=_mock_registry_has_version("1.0.0")):
            result = runner.invoke(
                app, ["--dir", str(tmp_path), "--to", "1.0.0"], input="y\n"
            )
        assert result.exit_code == 0
        assert get_version_pin(tmp_path) == "1.0.0"

    def test_version_pin_unchanged_if_user_aborts(self, tmp_path):
        _scaffold(tmp_path, "1.1.0")
        with patch("requests.get",
                   return_value=_mock_registry_has_version("1.0.0")):
            result = runner.invoke(
                app, ["--dir", str(tmp_path), "--to", "1.0.0"], input="n\n"
            )
        # User said no — pin must be unchanged
        assert get_version_pin(tmp_path) == "1.1.0"

    def test_both_yaml_and_pom_updated(self, tmp_path):
        _scaffold(tmp_path, "1.1.0")
        with patch("requests.get",
                   return_value=_mock_registry_has_version("1.0.0")):
            runner.invoke(
                app, ["--dir", str(tmp_path), "--to", "1.0.0"], input="y\n"
            )
        # biller.yaml
        assert get_version_pin(tmp_path) == "1.0.0"
        # pom.xml
        pom_text = (tmp_path / "pom.xml").read_text()
        assert "<biller.core.version>1.0.0</biller.core.version>" in pom_text

class TestDowngradeRegistryUrl:
    def test_returns_default_when_no_env_file(self, tmp_path):
        from biller_cli.commands.downgrade import _get_registry_url
        url = _get_registry_url(tmp_path)
        assert url == "https://biller-registry-production.up.railway.app"

    def test_env_var_takes_priority_over_env_file(self, tmp_path):
        import os
        from biller_cli.commands.downgrade import _get_registry_url
        env = tmp_path / ".env.biller"
        env.write_text("BILLER_REGISTRY_URL=https://file.registry.com\n")
        with patch.dict(os.environ, {"BILLER_REGISTRY_URL": "https://env.registry.com"}):
            assert _get_registry_url(tmp_path) == "https://env.registry.com"
