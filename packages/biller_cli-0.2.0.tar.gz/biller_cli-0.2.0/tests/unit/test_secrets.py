"""
tests/unit/test_secrets.py

Unit tests for biller_cli/utils/secrets.py
"""

from pathlib import Path
import pytest

from biller_cli.utils.secrets import write_env_file, read_env_file, _ensure_gitignore


class TestWriteEnvFile:
    def test_writes_key_value_pairs(self, tmp_path):
        write_env_file(tmp_path, {"db_password": "secret", "ou_id": "BBCU001"})
        content = (tmp_path / ".env.biller").read_text()
        assert "DB_PASSWORD=secret" in content
        assert "OU_ID=BBCU001" in content

    def test_keys_uppercased(self, tmp_path):
        write_env_file(tmp_path, {"lowercase_key": "value"})
        content = (tmp_path / ".env.biller").read_text()
        assert "LOWERCASE_KEY=value" in content
        assert "lowercase_key" not in content

    def test_do_not_commit_header_present(self, tmp_path):
        write_env_file(tmp_path, {"key": "val"})
        content = (tmp_path / ".env.biller").read_text()
        assert "DO NOT COMMIT" in content

    def test_creates_gitignore_if_missing(self, tmp_path):
        write_env_file(tmp_path, {"key": "val"})
        assert (tmp_path / ".gitignore").exists()
        assert ".env.biller" in (tmp_path / ".gitignore").read_text()

    def test_appends_to_existing_gitignore(self, tmp_path):
        gi = tmp_path / ".gitignore"
        gi.write_text("*.pyc\n__pycache__/\n")
        write_env_file(tmp_path, {"key": "val"})
        content = gi.read_text()
        assert "*.pyc" in content
        assert ".env.biller" in content

    def test_does_not_duplicate_gitignore_entry(self, tmp_path):
        gi = tmp_path / ".gitignore"
        gi.write_text(".env.biller\n")
        write_env_file(tmp_path, {"key": "val"})
        assert gi.read_text().count(".env.biller") == 1


class TestReadEnvFile:
    def test_reads_written_values(self, tmp_path):
        write_env_file(tmp_path, {"db_password": "secret", "ou_id": "BBCU001"})
        result = read_env_file(tmp_path)
        assert result["db_password"] == "secret"
        assert result["ou_id"] == "BBCU001"

    def test_keys_lowercased_on_read(self, tmp_path):
        (tmp_path / ".env.biller").write_text("DB_PASSWORD=secret\n")
        result = read_env_file(tmp_path)
        assert "db_password" in result
        assert result["db_password"] == "secret"

    def test_returns_empty_dict_if_no_env_file(self, tmp_path):
        assert read_env_file(tmp_path) == {}

    def test_ignores_comment_lines(self, tmp_path):
        (tmp_path / ".env.biller").write_text("# comment\nDB_PASSWORD=secret\n")
        result = read_env_file(tmp_path)
        assert len(result) == 1
        assert result["db_password"] == "secret"

    def test_handles_value_with_equals_sign(self, tmp_path):
        (tmp_path / ".env.biller").write_text("JDBC_URL=jdbc:postgresql://host/db?ssl=true\n")
        result = read_env_file(tmp_path)
        assert result["jdbc_url"] == "jdbc:postgresql://host/db?ssl=true"


class TestEnsureGitignore:
    def test_creates_gitignore_with_entry(self, tmp_path):
        _ensure_gitignore(tmp_path)
        assert (tmp_path / ".gitignore").exists()
        assert ".env.biller" in (tmp_path / ".gitignore").read_text()

    def test_does_not_add_duplicate_entry(self, tmp_path):
        gi = tmp_path / ".gitignore"
        gi.write_text(".env.biller\n")
        _ensure_gitignore(tmp_path)
        assert gi.read_text().count(".env.biller") == 1

    def test_preserves_existing_entries(self, tmp_path):
        gi = tmp_path / ".gitignore"
        gi.write_text("node_modules/\n*.log\n")
        _ensure_gitignore(tmp_path)
        content = gi.read_text()
        assert "node_modules/" in content
        assert "*.log" in content
        assert ".env.biller" in content