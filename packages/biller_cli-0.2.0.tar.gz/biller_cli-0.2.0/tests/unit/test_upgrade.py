"""
tests/unit/test_upgrade.py

Unit tests for biller_cli/commands/upgrade.py

Mocking strategy:
  - Registry HTTP calls: mock requests.get via pytest-mock
  - Sandbox: mock _run_sandbox_build directly — subprocess/git not under test here
  - version_pin: uses real implementation against tmp_path fixtures
  - typer CLI invocation: via typer.testing.CliRunner
"""

import yaml
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
from typer.testing import CliRunner

from biller_cli.commands.upgrade import app, _get_registry_url, _apply_config_rename_rule
from biller_cli.utils.version_pin import get_version_pin

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _scaffold(tmp_path: Path, version: str = "1.0.0") -> Path:
    """Scaffold a minimal biller project in tmp_path."""
    import textwrap
    bp = tmp_path / "biller.yaml"
    bp.write_text(yaml.dump(
        {"core": {"version": version}, "bou": {"id": "test-bou"}},
        default_flow_style=False,
        sort_keys=False,
    ))
    pom = tmp_path / "pom.xml"
    pom.write_text(textwrap.dedent(f"""\
        <?xml version="1.0" encoding="UTF-8"?>
        <project xmlns="http://maven.apache.org/POM/4.0.0"
                 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                 xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                 http://maven.apache.org/xsd/maven-4.0.0.xsd">
            <modelVersion>4.0.0</modelVersion>
            <groupId>com.bharatconnect.biller</groupId>
            <artifactId>biller-user-layer</artifactId>
            <version>1.0.0</version>
            <properties>
                <biller.core.version>{version}</biller.core.version>
            </properties>
        </project>
    """))
    return tmp_path


def _mock_latest(version: str) -> MagicMock:
    m = MagicMock()
    m.status_code = 200
    m.json.return_value = {"version": version}
    m.raise_for_status = MagicMock()
    return m


def _mock_migration(rules=None, has_breaking=False, path=None) -> MagicMock:
    m = MagicMock()
    m.status_code = 200
    m.json.return_value = {
        "rules": rules or [],
        "has_breaking_changes": has_breaking,
        "path": path or [],
    }
    return m


# ---------------------------------------------------------------------------
# _get_registry_url
# ---------------------------------------------------------------------------


class TestGetRegistryUrl:
    def test_returns_default_when_no_env_file(self, tmp_path):
        url = _get_registry_url(tmp_path)
        assert url == "https://biller-registry-production.up.railway.app"

    def test_reads_from_env_biller(self, tmp_path):
        env = tmp_path / ".env.biller"
        env.write_text("BILLER_REGISTRY_URL=https://my-registry.example.com\n")
        assert _get_registry_url(tmp_path) == "https://my-registry.example.com"

    def test_falls_back_if_key_not_in_env_file(self, tmp_path):
        env = tmp_path / ".env.biller"
        env.write_text("SOME_OTHER_KEY=value\n")
        url = _get_registry_url(tmp_path)
        assert url == "https://biller-registry-production.up.railway.app"


# ---------------------------------------------------------------------------
# _apply_config_rename_rule
# ---------------------------------------------------------------------------


class TestApplyConfigRenameRule:
    def test_renames_top_level_key(self, tmp_path):
        bp = tmp_path / "biller.yaml"
        bp.write_text(yaml.dump({"old_key": "value", "other": "x"}))
        _apply_config_rename_rule(tmp_path, {"old_key": "old_key", "new_key": "new_key"})
        cfg = yaml.safe_load(bp.read_text())
        assert "new_key" in cfg
        assert "old_key" not in cfg
        assert cfg["new_key"] == "value"

    def test_renames_dot_notation_key(self, tmp_path):
        bp = tmp_path / "biller.yaml"
        bp.write_text(yaml.dump({"core": {"timeout": 30}, "bou": {"id": "x"}}))
        _apply_config_rename_rule(tmp_path, {"old_key": "core.timeout", "new_key": "core.connect_timeout"})
        cfg = yaml.safe_load(bp.read_text())
        assert cfg["core"]["connect_timeout"] == 30
        assert "timeout" not in cfg["core"]

    def test_skips_gracefully_if_old_key_not_present(self, tmp_path):
        bp = tmp_path / "biller.yaml"
        bp.write_text(yaml.dump({"core": {"version": "1.0.0"}}))
        original = bp.read_text()
        # Should not raise
        _apply_config_rename_rule(tmp_path, {"old_key": "nonexistent.key", "new_key": "new.key"})
        # File must be unchanged
        assert bp.read_text() == original

    def test_preserves_other_keys(self, tmp_path):
        bp = tmp_path / "biller.yaml"
        bp.write_text(yaml.dump({"old_key": "v", "keep_this": "intact"}))
        _apply_config_rename_rule(tmp_path, {"old_key": "old_key", "new_key": "new_key"})
        cfg = yaml.safe_load(bp.read_text())
        assert cfg["keep_this"] == "intact"


# ---------------------------------------------------------------------------
# upgrade command — CLI invocation via CliRunner
# ---------------------------------------------------------------------------


class TestUpgradeCommand:
    def test_nothing_to_upgrade_when_already_on_target(self, tmp_path):
        _scaffold(tmp_path, "1.0.0")
        with patch("biller_cli.commands.upgrade.requests.get") as mock_get:
            mock_get.return_value = _mock_latest("1.0.0")
            result = runner.invoke(app, ["--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "Nothing to upgrade" in result.output

    def test_suggests_downgrade_if_target_older(self, tmp_path):
        _scaffold(tmp_path, "1.1.0")
        with patch("biller_cli.commands.upgrade.requests.get") as mock_get:
            mock_get.return_value = _mock_latest("1.0.0")
            result = runner.invoke(app, ["--dir", str(tmp_path), "--to", "1.0.0"])
        assert result.exit_code == 0
        assert "downgrade" in result.output.lower()

    def test_version_pin_updated_after_successful_upgrade(self, tmp_path):
        _scaffold(tmp_path, "1.0.0")
        with patch("biller_cli.commands.upgrade.requests.get") as mock_get, \
             patch("biller_cli.commands.upgrade._run_sandbox_build", return_value=True):
            mock_get.side_effect = [
                _mock_latest("1.1.0"),
                _mock_migration(),
            ]
            result = runner.invoke(app, ["--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert get_version_pin(tmp_path) == "1.1.0"

    def test_version_pin_not_updated_when_sandbox_fails(self, tmp_path):
        _scaffold(tmp_path, "1.0.0")
        with patch("biller_cli.commands.upgrade.requests.get") as mock_get, \
             patch("biller_cli.commands.upgrade._run_sandbox_build", return_value=False):
            mock_get.side_effect = [
                _mock_latest("1.1.0"),
                _mock_migration(),
            ]
            result = runner.invoke(app, ["--dir", str(tmp_path)])
        assert result.exit_code == 1
        # Version pin must remain unchanged
        assert get_version_pin(tmp_path) == "1.0.0"

    def test_network_failure_exits_1_and_leaves_pin_unchanged(self, tmp_path):
        _scaffold(tmp_path, "1.0.0")
        import requests as req
        with patch("biller_cli.commands.upgrade.requests.get",
                   side_effect=req.ConnectionError("network down")):
            result = runner.invoke(app, ["--dir", str(tmp_path)])
        assert result.exit_code == 1
        assert get_version_pin(tmp_path) == "1.0.0"

    def test_breaking_changes_shows_confirmation_prompt(self, tmp_path):
        _scaffold(tmp_path, "1.0.0")
        with patch("biller_cli.commands.upgrade.requests.get") as mock_get, \
             patch("biller_cli.commands.upgrade._run_sandbox_build", return_value=True):
            mock_get.side_effect = [
                _mock_latest("1.1.0"),
                _mock_migration(has_breaking=True),
            ]
            # Simulate user typing "y" at the confirmation prompt
            result = runner.invoke(app, ["--dir", str(tmp_path)], input="y\n")
        assert "Breaking changes" in result.output or "breaking" in result.output.lower()

    def test_config_rename_rule_applied_during_upgrade(self, tmp_path):
        _scaffold(tmp_path, "1.0.0")
        # Add the old key to biller.yaml
        bp = tmp_path / "biller.yaml"
        cfg = yaml.safe_load(bp.read_text())
        cfg["old_timeout"] = 30
        bp.write_text(yaml.dump(cfg))

        rule = {"type": "config_rename", "old_key": "old_timeout", "new_key": "core.timeout"}
        with patch("biller_cli.commands.upgrade.requests.get") as mock_get, \
             patch("biller_cli.commands.upgrade._run_sandbox_build", return_value=True):
            mock_get.side_effect = [
                _mock_latest("1.1.0"),
                _mock_migration(rules=[rule]),
            ]
            runner.invoke(app, ["--dir", str(tmp_path)])

        final_cfg = yaml.safe_load(bp.read_text())
        assert "old_timeout" not in final_cfg
        assert final_cfg.get("core", {}).get("timeout") == 30

    def test_skip_sandbox_flag_bypasses_sandbox(self, tmp_path):
        _scaffold(tmp_path, "1.0.0")
        with patch("biller_cli.commands.upgrade.requests.get") as mock_get, \
             patch("biller_cli.commands.upgrade._run_sandbox_build") as mock_sandbox:
            mock_get.side_effect = [
                _mock_latest("1.1.0"),
                _mock_migration(),
            ]
            result = runner.invoke(app, ["--dir", str(tmp_path), "--skip-sandbox"])
        mock_sandbox.assert_not_called()
        assert result.exit_code == 0
    def test_env_var_takes_priority_over_env_file(self, tmp_path):
        import os
        env = tmp_path / ".env.biller"
        env.write_text("BILLER_REGISTRY_URL=https://file.registry.com\n")
        with patch.dict(os.environ, {"BILLER_REGISTRY_URL": "https://env.registry.com"}):
            assert _get_registry_url(tmp_path) == "https://env.registry.com"
