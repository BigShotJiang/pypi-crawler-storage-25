"""
tests/unit/test_version_pin.py

Unit tests for biller_cli/utils/version_pin.py

Run first — version_pin is a load-bearing assumption of the entire
upgrade/downgrade flow. All cases must pass before any other test is written.

Run:
    pytest tests/unit/test_version_pin.py -v
"""

import textwrap
from pathlib import Path

import pytest
import yaml

from biller_cli.utils.version_pin import get_version_pin, set_version_pin


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_biller_yaml(tmp_path: Path, version: str) -> Path:
    """Write a minimal biller.yaml with the given core.version."""
    bp = tmp_path / "biller.yaml"
    bp.write_text(
        yaml.dump(
            {"core": {"version": version}, "bou": {"id": "test-bou"}},
            default_flow_style=False,
            sort_keys=False,
        )
    )
    return bp


def _make_pom_xml(tmp_path: Path, version: str) -> Path:
    """Write a minimal pom.xml with biller.core.version property."""
    pom = tmp_path / "pom.xml"
    pom.write_text(
        textwrap.dedent(f"""\
            <?xml version="1.0" encoding="UTF-8"?>
            <project xmlns="http://maven.apache.org/POM/4.0.0"
                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                     http://maven.apache.org/xsd/maven-4.0.0.xsd">
                <modelVersion>4.0.0</modelVersion>
                <groupId>com.bharatconnect.biller</groupId>
                <artifactId>biller-user-layer</artifactId>
                <version>1.0.0</version>
                <properties>
                    <java.version>17</java.version>
                    <biller.core.version>{version}</biller.core.version>
                </properties>
            </project>
        """)
    )
    return pom


def _make_pom_xml_multiline(tmp_path: Path, version: str) -> Path:
    """
    Write a pom.xml where biller.core.version is split across multiple lines —
    simulating what an IDE or Maven reformatter produces.
    The XML parser must handle this correctly. A regex would silently fail.
    """
    pom = tmp_path / "pom.xml"
    pom.write_text(
        textwrap.dedent(f"""\
            <?xml version="1.0" encoding="UTF-8"?>
            <project xmlns="http://maven.apache.org/POM/4.0.0"
                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                     http://maven.apache.org/xsd/maven-4.0.0.xsd">
                <modelVersion>4.0.0</modelVersion>
                <groupId>com.bharatconnect.biller</groupId>
                <artifactId>biller-user-layer</artifactId>
                <version>1.0.0</version>
                <properties>
                    <java.version>17</java.version>
                    <biller.core.version>
                        {version}
                    </biller.core.version>
                </properties>
            </project>
        """)
    )
    return pom


def _make_pom_xml_missing_property(tmp_path: Path) -> Path:
    """Write a pom.xml with no biller.core.version property at all."""
    pom = tmp_path / "pom.xml"
    pom.write_text(
        textwrap.dedent("""\
            <?xml version="1.0" encoding="UTF-8"?>
            <project xmlns="http://maven.apache.org/POM/4.0.0"
                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                     http://maven.apache.org/xsd/maven-4.0.0.xsd">
                <modelVersion>4.0.0</modelVersion>
                <groupId>com.bharatconnect.biller</groupId>
                <artifactId>biller-user-layer</artifactId>
                <version>1.0.0</version>
                <properties>
                    <java.version>17</java.version>
                </properties>
            </project>
        """)
    )
    return pom


# ---------------------------------------------------------------------------
# get_version_pin
# ---------------------------------------------------------------------------


class TestGetVersionPin:
    def test_returns_version_from_biller_yaml(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        assert get_version_pin(tmp_path) == "1.0.0"

    def test_raises_if_biller_yaml_missing(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="biller.yaml"):
            get_version_pin(tmp_path)

    def test_raises_if_core_version_key_missing(self, tmp_path):
        bp = tmp_path / "biller.yaml"
        bp.write_text(yaml.dump({"bou": {"id": "test-bou"}}))
        with pytest.raises(KeyError, match="core.version"):
            get_version_pin(tmp_path)

    def test_raises_if_core_section_missing(self, tmp_path):
        bp = tmp_path / "biller.yaml"
        bp.write_text(yaml.dump({"bou": {"id": "test-bou"}}))
        with pytest.raises(KeyError, match="core.version"):
            get_version_pin(tmp_path)


# ---------------------------------------------------------------------------
# set_version_pin — biller.yaml
# ---------------------------------------------------------------------------


class TestSetVersionPinBillerYaml:
    def test_updates_version_in_biller_yaml(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        _make_pom_xml(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.1.0")
        assert get_version_pin(tmp_path) == "1.1.0"

    def test_preserves_other_keys_in_biller_yaml(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        _make_pom_xml(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.1.0")
        cfg = yaml.safe_load((tmp_path / "biller.yaml").read_text())
        assert cfg["bou"]["id"] == "test-bou"

    def test_idempotent_biller_yaml(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        _make_pom_xml(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.0.0")
        assert get_version_pin(tmp_path) == "1.0.0"

    def test_raises_if_biller_yaml_missing(self, tmp_path):
        _make_pom_xml(tmp_path, "1.0.0")
        with pytest.raises(FileNotFoundError):
            set_version_pin(tmp_path, "1.1.0")


# ---------------------------------------------------------------------------
# set_version_pin — pom.xml
# ---------------------------------------------------------------------------


class TestSetVersionPinPomXml:
    def test_updates_biller_core_version_in_pom(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        _make_pom_xml(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.1.0")
        pom_text = (tmp_path / "pom.xml").read_text()
        assert "<biller.core.version>1.1.0</biller.core.version>" in pom_text

    def test_does_not_write_old_version_to_pom(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        _make_pom_xml(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.1.0")
        pom_text = (tmp_path / "pom.xml").read_text()
        assert "<biller.core.version>1.0.0</biller.core.version>" not in pom_text

    def test_raises_if_biller_core_version_property_missing(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        _make_pom_xml_missing_property(tmp_path)
        with pytest.raises(RuntimeError, match="biller.core.version not found"):
            set_version_pin(tmp_path, "1.1.0")

    def test_raises_if_pom_missing(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        with pytest.raises(FileNotFoundError, match="pom.xml"):
            set_version_pin(tmp_path, "1.1.0")

    def test_multiline_pom_updated_correctly(self, tmp_path):
        """
        Regression test: IDE/Maven reformatting splits the property tag across
        lines. A regex-based updater would silently do nothing. The XML parser
        must handle this and write the version correctly.
        """
        _make_biller_yaml(tmp_path, "1.0.0")
        _make_pom_xml_multiline(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.1.0")
        pom_text = (tmp_path / "pom.xml").read_text()
        assert "1.1.0" in pom_text
        assert "1.0.0" not in pom_text.split("<biller.core.version>")[1].split(
            "</biller.core.version>"
        )[0]

    def test_idempotent_pom(self, tmp_path):
        _make_biller_yaml(tmp_path, "1.0.0")
        _make_pom_xml(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.0.0")
        set_version_pin(tmp_path, "1.0.0")
        pom_text = (tmp_path / "pom.xml").read_text()
        assert pom_text.count("<biller.core.version>1.0.0</biller.core.version>") == 1
