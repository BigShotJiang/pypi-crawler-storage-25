"""
tests/integration/test_native_lifecycle.py

Integration Flow 2: Native init → up → health check → down
Integration Flow 3: init → upgrade (1.0.0 → 1.1.0) → up
Integration Flow 4: init → upgrade → downgrade → up

These tests require:
  - PostgreSQL running on localhost:5432 with billerdb database
  - biller-core:1.0.0 and 1.1.0 on GitHub Packages
  - Maven on PATH
  - Docker daemon NOT required for Flow 2 (native mode)

Run with: pytest tests/integration/test_native_lifecycle.py -v --timeout=600
"""

import subprocess
import shutil
import time
import yaml
import pytest
import requests

from tests.integration.conftest import biller_cli, wait_for_health, NATIVE_PROJECT


def _stop_native(project_dir):
    """Stop native stack if running."""
    subprocess.run(
        ["biller-cli", "down", "--dir", str(project_dir)],
        capture_output=True,
    )
    # Give process time to terminate
    time.sleep(2)


def _health_ok(timeout: int = 180) -> bool:
    return wait_for_health("http://localhost:8111/health", timeout=timeout)


# ---------------------------------------------------------------------------
# Flow 2: Native lifecycle
# ---------------------------------------------------------------------------

@pytest.mark.timeout(600)
class TestNativeLifecycle:
    def test_flow2_native_up_health_down(self, native_project):
        """
        Flow 2: Native init → up → health check → down
        Pass condition: health endpoint returns 200, stack stops cleanly.
        Note: First run compiles the project — allow up to 10 minutes.
        """
        _stop_native(native_project)

        result = subprocess.run(
            ["biller-cli", "up", "--dir", str(native_project), "--detach"],
            capture_output=True,
            text=True,
            timeout=600,
        )

        assert result.returncode == 0, (
            f"biller-cli up (native) failed.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )

        healthy = _health_ok(timeout=300)
        assert healthy, (
            "Health endpoint did not return 200 within 300 seconds (native mode).\n"
            f"Check logs: cat {native_project}/.biller/biller.log"
        )

        r = requests.get("http://localhost:8111/health", timeout=5)
        assert r.status_code == 200

        result = biller_cli("down", "--dir", str(native_project))
        assert result.returncode == 0, (
            f"biller-cli down (native) failed.\nstdout: {result.stdout}"
        )

        # Verify PID file is cleaned up
        pid_file = native_project / ".biller" / "biller.pid"
        assert not pid_file.exists(), "PID file still exists after biller-cli down"

        # Verify process is not responding
        time.sleep(3)
        try:
            requests.get("http://localhost:8111/health", timeout=2)
            pytest.fail("Native stack still responding after biller-cli down")
        except requests.RequestException:
            pass


# ---------------------------------------------------------------------------
# Flow 3: Upgrade flow
# ---------------------------------------------------------------------------

@pytest.mark.timeout(600)
class TestUpgradeFlow:
    def test_flow3_upgrade_1_0_0_to_1_1_0(self, tmp_path):
        """
        Flow 3: init → upgrade (1.0.0 → 1.1.0) → up
        Pass condition: version pin updated to 1.1.0, stack starts healthy.

        Uses a copy of native_project to avoid mutating the shared fixture.
        """
        test_dir = tmp_path / "upgrade_test"
        shutil.copytree(str(NATIVE_PROJECT), str(test_dir))

        # Verify starting version
        version_before = yaml.safe_load(
            (test_dir / "biller.yaml").read_text()
        )["core"]["version"]
        assert version_before == "1.0.1", f"Expected 1.0.1, got {version_before}"

        # Run upgrade with sandbox skipped for speed
        # (sandbox compile is tested in unit tests and Flow 7)
        result = subprocess.run(
            ["biller-cli", "upgrade", "--dir", str(test_dir),
             "--to", "1.1.1", "--skip-sandbox"],
            capture_output=True,
            text=True,
        )

        assert result.returncode == 0, (
            f"biller-cli upgrade failed.\nstdout: {result.stdout}\nstderr: {result.stderr}"
        )

        # Version pin must be updated
        version_after = yaml.safe_load(
            (test_dir / "biller.yaml").read_text()
        )["core"]["version"]
        assert version_after == "1.1.1", (
            f"Version pin not updated. Expected 1.1.0, got {version_after}"
        )

        # POM must also be updated
        pom_text = (test_dir / "pom.xml").read_text()
        assert "<biller.core.version>1.1.1</biller.core.version>" in pom_text, (
            "pom.xml not updated to 1.1.0"
        )

        # Stack must start successfully on 1.1.0
        _stop_native(test_dir)
        result = subprocess.run(
            ["biller-cli", "up", "--dir", str(test_dir), "--detach"],
            capture_output=True,
            text=True,
            timeout=600,
        )
        assert result.returncode == 0

        healthy = _health_ok(timeout=300)
        assert healthy, "Stack not healthy after upgrade to 1.1.1"

        _stop_native(test_dir)


# ---------------------------------------------------------------------------
# Flow 4: Upgrade → downgrade roundtrip
# ---------------------------------------------------------------------------

@pytest.mark.timeout(600)
class TestDowngradeRoundtrip:
    def test_flow4_upgrade_then_downgrade_then_up(self, tmp_path):
        """
        Flow 4: init → upgrade → downgrade → up
        Pass condition: stack healthy after full round trip.
        """
        test_dir = tmp_path / "roundtrip_test"
        shutil.copytree(str(NATIVE_PROJECT), str(test_dir))

        # Step 1: Upgrade to 1.1.1
        result = subprocess.run(
            ["biller-cli", "upgrade", "--dir", str(test_dir),
             "--to", "1.1.1", "--skip-sandbox"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, f"Upgrade failed: {result.stdout}"

        version = yaml.safe_load(
            (test_dir / "biller.yaml").read_text()
        )["core"]["version"]
        assert version == "1.1.1"

        # Step 2: Downgrade to 1.0.0 (confirm prompt with "y")
        result = subprocess.run(
            ["biller-cli", "downgrade", "--dir", str(test_dir), "--to", "1.0.1"],
            input="y\n",
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, (
            f"Downgrade failed.\nstdout: {result.stdout}\nstderr: {result.stderr}"
        )

        version = yaml.safe_load(
            (test_dir / "biller.yaml").read_text()
        )["core"]["version"]
        assert version == "1.0.1", f"Downgrade did not roll back. Got: {version}"

        # DB warning must have appeared before confirmation
        assert "DATABASE WARNING" in result.stdout, (
            "DB warning not shown during downgrade"
        )

        # Step 3: Stack must start on 1.0.0
        _stop_native(test_dir)
        result = subprocess.run(
            ["biller-cli", "up", "--dir", str(test_dir), "--detach"],
            capture_output=True,
            text=True,
            timeout=600,
        )
        assert result.returncode == 0

        healthy = _health_ok(timeout=300)
        assert healthy, "Stack not healthy after downgrade roundtrip to 1.0.1"

        _stop_native(test_dir)