"""
tests/integration/conftest.py

Shared fixtures for integration tests.

These tests require:
  - Docker running (docker info succeeds)
  - PostgreSQL running on localhost:5432 with billerdb database
  - biller-core:1.0.0 and 1.1.0 on GitHub Packages (~/.m2/settings.xml configured)
  - biller-cli installed (pipx or venv)

Run:
    pytest tests/integration/ -v --timeout=120

Do NOT run with unit tests — these tests start real processes and take minutes.
"""

import subprocess
import shutil
import time
from pathlib import Path

import pytest
import requests

# ---------------------------------------------------------------------------
# Project directories
# ---------------------------------------------------------------------------

REPO_ROOT = Path(__file__).parent.parent.parent.parent  # ~/Desktop/biller-cli
DOCKER_PROJECT = REPO_ROOT / "test_bill"      # runtime: docker
NATIVE_PROJECT = REPO_ROOT / "test_biller"   # runtime: native


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def biller_cli(*args, timeout=600) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["biller-cli"] + list(args),
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def wait_for_health(url: str = "http://localhost:8111/health", timeout: int = 120) -> bool:
    """Poll health endpoint until 200 or timeout. Returns True if healthy."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = requests.get(url, timeout=3)
            if r.status_code == 200:
                return True
        except requests.RequestException:
            pass
        time.sleep(3)
    return False


def docker_running() -> bool:
    result = subprocess.run(["docker", "info"], capture_output=True)
    return result.returncode == 0


def postgres_running() -> bool:
    result = subprocess.run(
        ["pg_isready", "-h", "localhost", "-p", "5432"],
        capture_output=True,
    )
    return result.returncode == 0


# ---------------------------------------------------------------------------
# Session-scoped fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def verify_prerequisites():
    """
    Gate: fail fast if infrastructure is not available.
    All integration tests are skipped rather than failing with cryptic errors.
    """
    if not docker_running():
        pytest.skip("Docker daemon not running — skipping all integration tests")
    if not postgres_running():
        pytest.skip("PostgreSQL not running on localhost:5432 — skipping all integration tests")
    if not shutil.which("biller-cli"):
        pytest.skip("biller-cli not on PATH — install with: pipx install -e cli/")
    if not shutil.which("mvn"):
        pytest.skip("Maven not on PATH — required for native mode and sandbox tests")


@pytest.fixture(scope="session")
def docker_project() -> Path:
    """Return path to the Docker-mode test project."""
    assert DOCKER_PROJECT.exists(), f"Docker test project not found: {DOCKER_PROJECT}"
    assert (DOCKER_PROJECT / "biller.yaml").exists()
    return DOCKER_PROJECT


@pytest.fixture(scope="session")
def native_project() -> Path:
    """Return path to the native-mode test project."""
    assert NATIVE_PROJECT.exists(), f"Native test project not found: {NATIVE_PROJECT}"
    assert (NATIVE_PROJECT / "biller.yaml").exists()
    return NATIVE_PROJECT


@pytest.fixture(scope="session")
def built_jar(docker_project) -> Path:
    """
    Build the JAR for the Docker project.
    The Dockerfile expects target/biller-user-layer-*.jar to exist.
    Session-scoped — built once per test run.
    """
    result = subprocess.run(
        ["mvn", "clean", "package", "-pl", "biller-user-layer",
         "--also-make", "-q", "-DskipTests"],
        cwd=str(docker_project),
        capture_output=True,
        text=True,
        timeout=300,
    )
    if result.returncode != 0:
        pytest.fail(
            f"JAR build failed before Docker tests.\n"
            f"stdout: {result.stdout[-500:]}\n"
            f"stderr: {result.stderr[-500:]}"
        )
    jars = list((docker_project / "biller-user-layer" / "target").glob("*.jar"))
    assert jars, "No JAR produced by mvn package"
    return jars[0]


@pytest.fixture
def ensure_stack_down(docker_project):
    """
    Teardown fixture — ensure Docker stack is stopped after a test.
    Used by Docker lifecycle tests to prevent port conflicts between runs.
    """
    yield
    subprocess.run(
        ["docker", "compose", "-f", str(docker_project / "docker-compose.yml"), "down"],
        capture_output=True,
    )