"""BrowserSessionManager: one CDP connection, one BrowserContext per effective_key."""

from __future__ import annotations

import asyncio
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Awaitable, Callable

from loguru import logger

from pythinker.agent.browser.state import (
    BrowserContextState,
    _ssrf_route_handler,
    storage_path_for_key,
)
from pythinker.agent.browser.transport import cdp_healthcheck

if TYPE_CHECKING:
    from playwright.async_api import Playwright

    from pythinker.config.schema import BrowserConfig


_USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)


async def _default_pw_factory() -> "Playwright":
    """Default Playwright entry point. Imported lazily so the [browser] extra is optional."""
    from playwright.async_api import async_playwright

    return await async_playwright().start()


class BrowserSessionManager:
    """One CDP connection. N BrowserContextState entries keyed by effective_key.

    The ``_pw_factory`` parameter exists so tests can inject a fake. Production
    callers should leave it at the default.
    """

    def __init__(
        self,
        config: "BrowserConfig",
        storage_dir: Path,
        *,
        _pw_factory: Callable[[], Awaitable["Playwright"]] = _default_pw_factory,
    ) -> None:
        self._config = config
        self._storage_dir = storage_dir
        self._pw_factory = _pw_factory
        self._pw: Any = None  # Playwright | None
        self._browser: Any = None  # Browser | None
        self._states: dict[str, BrowserContextState] = {}
        self._connect_lock = asyncio.Lock()

    async def _ensure_browser(self) -> Any:
        async with self._connect_lock:
            if self._browser is not None and self._browser.is_connected():
                return self._browser
            ok, err = await cdp_healthcheck(self._config.cdp_url)
            if not ok:
                raise RuntimeError(
                    f"browser service unreachable at {self._config.cdp_url}: {err}"
                )
            self._pw = await self._pw_factory()
            self._browser = await self._pw.chromium.connect_over_cdp(self._config.cdp_url)
            self._browser.on("disconnected", self._on_disconnected)
            logger.info("browser: connected via CDP at {}", self._config.cdp_url)
            return self._browser

    def _on_disconnected(self, _browser: Any = None) -> None:
        logger.warning("browser: CDP disconnected; states will be recreated on next acquire")
        for state in self._states.values():
            # Mark dead so acquire() does NOT return a stale BrowserContext/Page.
            state.dead = True
            state.notify_restart_prefix = (
                f"[browser session was restarted; previous url was {state.last_url}]"
            )
        self._browser = None

    async def acquire(self, effective_key: str) -> BrowserContextState:
        """Get the state for ``effective_key``, creating it lazily."""
        existing = self._states.get(effective_key)
        if (
            existing is not None
            and not existing.dead
            and not existing.closed
            and existing.context is not None
        ):
            existing.last_used_at = time.monotonic()
            return existing

        # Carry the post-disconnect notification onto the freshly-created state.
        carried_prefix = existing.notify_restart_prefix if existing is not None else None
        if existing is not None:
            self._states.pop(effective_key, None)

        browser = await self._ensure_browser()
        storage_path = storage_path_for_key(self._storage_dir, effective_key)
        storage_path.parent.mkdir(parents=True, exist_ok=True)
        kwargs: dict[str, Any] = {
            "user_agent": _USER_AGENT,
            "locale": "en-US",
            "viewport": {"width": 1280, "height": 800},
        }
        if storage_path.exists():
            kwargs["storage_state"] = str(storage_path)
        context = await browser.new_context(**kwargs)
        context.set_default_timeout(self._config.default_timeout_ms)
        page = await context.new_page()
        state = BrowserContextState(
            effective_key=effective_key,
            context=context,
            page=page,
            storage_path=storage_path,
            lock=asyncio.Lock(),
            last_used_at=time.monotonic(),
            notify_restart_prefix=carried_prefix,
        )
        # Bind the SSRF route handler at context-creation time, before the first
        # navigation. Without this, sub-request SSRF protection is silently dead.
        await context.route("**/*", _ssrf_route_handler(state))
        self._states[effective_key] = state
        logger.info("browser: opened context for {}", effective_key)
        return state

    async def close_session(self, effective_key: str) -> None:
        """Save + close one chat's context. Idempotent."""
        state = self._states.pop(effective_key, None)
        if state is None:
            return
        await state.close()

    async def shutdown(self, force: bool = False) -> None:
        """Save + close everything; disconnect CDP; stop Playwright."""
        keys = list(self._states.keys())
        await asyncio.gather(
            *(self.close_session(k) for k in keys), return_exceptions=True
        )
        if self._browser is not None:
            try:
                await self._browser.close()
            except Exception as e:
                logger.debug("browser: close error during shutdown ({})", e)
            self._browser = None
        if self._pw is not None:
            try:
                await self._pw.stop()
            except Exception as e:
                logger.debug("browser: pw.stop error during shutdown ({})", e)
            self._pw = None
