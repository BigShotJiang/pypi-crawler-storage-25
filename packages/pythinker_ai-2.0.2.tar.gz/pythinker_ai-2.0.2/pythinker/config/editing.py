"""Safe config read/edit helpers shared by CLI and admin surfaces."""

from __future__ import annotations

import json
import re
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ValidationError
from pydantic.alias_generators import to_camel

from pythinker.config.loader import save_config
from pythinker.config.schema import Config

SECRET_PLACEHOLDER = "********"

_SECRET_NAME_RE = re.compile(r"(api[_-]?key|token|secret|password|credential|oauth)", re.I)


class ConfigEditError(ValueError):
    """Raised when a config path cannot be safely read or edited."""


@dataclass(frozen=True)
class ConfigEditResult:
    path: str
    value: Any
    restart_required: bool = True


def _camel_to_snake(value: str) -> str:
    value = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", value)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", value).replace("-", "_").lower()


def _field_lookup(cursor: BaseModel, candidates: tuple[str, ...]) -> str | None:
    fields = type(cursor).model_fields
    aliases = {info.alias: name for name, info in fields.items() if info.alias}
    for cand in candidates:
        if cand in fields:
            return cand
        if cand in aliases:
            return aliases[cand]
    return None


def _resolve_segment(cursor: Any, raw: str, *, dotted: str, depth: int) -> Any:
    snake, camel = raw, to_camel(raw)
    if isinstance(cursor, BaseModel):
        attr = _field_lookup(cursor, (snake, camel))
        if attr is not None:
            return getattr(cursor, attr)
    if isinstance(cursor, dict):
        for cand in (raw, snake, camel):
            if cand in cursor:
                return cursor[cand]
    raise ConfigEditError(
        f"unknown config segment {raw!r} at position {depth} of {dotted!r}"
    )


def _walk_config_path(root: Config, dotted: str) -> tuple[Any, str]:
    parts = [p for p in dotted.split(".") if p]
    if not parts:
        raise ConfigEditError("config path must not be empty")
    cursor: Any = root
    for i, raw in enumerate(parts[:-1]):
        cursor = _resolve_segment(cursor, raw, dotted=dotted, depth=i)
    return cursor, parts[-1]


def _read_leaf(cursor: Any, leaf: str) -> Any:
    snake, camel = leaf, to_camel(leaf)
    if isinstance(cursor, BaseModel):
        attr = _field_lookup(cursor, (snake, camel))
        if attr is not None:
            return getattr(cursor, attr)
    if isinstance(cursor, dict):
        for cand in (leaf, snake, camel):
            if cand in cursor:
                return cursor[cand]
    raise ConfigEditError(f"unknown leaf field {leaf!r}")


def read_config_value(config: Config, dotted: str) -> Any:
    parent, leaf = _walk_config_path(config, dotted)
    return _read_leaf(parent, leaf)


def coerce_config_value(raw: Any) -> Any:
    """Best-effort JSON string coercion, matching the CLI config command."""

    if not isinstance(raw, str) or raw == "":
        return raw
    try:
        return json.loads(raw)
    except (TypeError, ValueError):
        return raw


def _validate_config(config: Config) -> None:
    try:
        type(config).model_validate(config.model_dump(mode="json", by_alias=True))
    except ValidationError as exc:
        first = exc.errors()[0]
        raise ConfigEditError(str(first.get("msg", "invalid config"))) from exc


def set_config_value(config: Config, dotted: str, value: Any) -> ConfigEditResult:
    parent, leaf = _walk_config_path(config, dotted)
    coerced = coerce_config_value(value)
    if isinstance(parent, BaseModel):
        target = _field_lookup(parent, (leaf, to_camel(leaf)))
        if target is None:
            raise ConfigEditError(f"unknown field {leaf!r}")
        old_value = getattr(parent, target)
        try:
            setattr(parent, target, coerced)
            _validate_config(config)
        except Exception:
            setattr(parent, target, old_value)
            raise
    elif isinstance(parent, dict):
        old_missing = object()
        old_value = parent.get(leaf, old_missing)
        try:
            parent[leaf] = coerced
            _validate_config(config)
        except Exception:
            if old_value is old_missing:
                parent.pop(leaf, None)
            else:
                parent[leaf] = old_value
            raise
    else:
        raise ConfigEditError(f"cannot set on {type(parent).__name__}")
    return ConfigEditResult(path=dotted, value=coerced)


def _field_default(parent: BaseModel, attr: str) -> Any:
    info = type(parent).model_fields[attr]
    if info.default_factory is not None:
        return info.default_factory()
    return info.default


def unset_config_value(config: Config, dotted: str) -> ConfigEditResult:
    parent, leaf = _walk_config_path(config, dotted)
    if isinstance(parent, BaseModel):
        target = _field_lookup(parent, (leaf, to_camel(leaf)))
        if target is None:
            raise ConfigEditError(f"unknown field {leaf!r}")
        old_value = getattr(parent, target)
        try:
            value = _field_default(parent, target)
            setattr(parent, target, value)
            _validate_config(config)
        except Exception:
            setattr(parent, target, old_value)
            raise
    elif isinstance(parent, dict):
        for cand in (leaf, to_camel(leaf)):
            parent.pop(cand, None)
        value = None
        _validate_config(config)
    else:
        raise ConfigEditError(f"cannot unset on {type(parent).__name__}")
    return ConfigEditResult(path=dotted, value=value)


def _is_secret_path(path: str, value: Any) -> bool:
    parts = path.split(".")
    last = parts[-1] if parts else ""
    if last in {"extra_headers", "headers"} and value:
        return True
    return any(_SECRET_NAME_RE.search(part) for part in parts)


def redacted_config(config: Config) -> dict[str, Any]:
    data = config.model_dump(mode="json", by_alias=True)
    secret_paths: list[str] = []

    def visit(value: Any, path: list[str]) -> Any:
        canonical = ".".join(_camel_to_snake(part) for part in path)
        if path and _is_secret_path(canonical, value):
            if value in (None, "", {}, []):
                return value
            secret_paths.append(canonical)
            return SECRET_PLACEHOLDER
        if isinstance(value, dict):
            return {key: visit(child, [*path, key]) for key, child in value.items()}
        if isinstance(value, list):
            return [visit(child, [*path, str(i)]) for i, child in enumerate(value)]
        return value

    return {"config": visit(data, []), "secret_paths": sorted(set(secret_paths))}


def save_config_with_backup(config: Config, config_path: Path) -> Path | None:
    backup: Path | None = None
    if config_path.exists():
        stamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
        backup = config_path.with_name(f"{config_path.name}.bak.{stamp}")
        shutil.copy2(config_path, backup)
    save_config(config, config_path)
    return backup
