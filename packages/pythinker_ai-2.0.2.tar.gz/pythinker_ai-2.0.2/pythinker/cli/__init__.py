"""CLI module for pythinker."""
