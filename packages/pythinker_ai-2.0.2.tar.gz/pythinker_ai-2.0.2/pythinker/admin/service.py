"""Read and mutate local-admin dashboard state."""

from __future__ import annotations

import json
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from pythinker import __version__
from pythinker.agent.usage import estimate_session_usage
from pythinker.config.editing import (
    ConfigEditError,
    read_config_value,
    redacted_config,
    save_config_with_backup,
    set_config_value,
    unset_config_value,
)
from pythinker.config.loader import load_config
from pythinker.config.schema import Config


class AdminService:
    """Small domain layer behind the embedded WebUI admin dashboard."""

    def __init__(
        self,
        *,
        config: Config,
        config_path: Path,
        session_manager: Any | None = None,
        agent_loop: Any | None = None,
        channel_manager: Any | None = None,
    ) -> None:
        self.config = config
        self.config_path = config_path
        self.session_manager = session_manager
        self.agent_loop = agent_loop
        self.channel_manager = channel_manager

    def overview(self) -> dict[str, Any]:
        start_time = float(getattr(self.agent_loop, "_start_time", time.time()))
        channels = self.channel_manager.channels if self.channel_manager is not None else {}
        return {
            "version": __version__,
            "uptime_s": max(0, int(time.time() - start_time)),
            "workspace": str(self.config.workspace_path),
            "config_path": str(self.config_path),
            "gateway": {
                "host": self.config.gateway.host,
                "port": self.config.gateway.port,
            },
            "api": {
                "host": self.config.api.host,
                "port": self.config.api.port,
            },
            "websocket": self._websocket_config(),
            "agent": {
                "provider": self.config.get_provider_name(),
                "model": getattr(self.agent_loop, "model", self.config.agents.defaults.model),
                "configured_model": self.config.agents.defaults.model,
            },
            "channels": [
                {"name": name, "enabled": True}
                for name in sorted(channels)
            ],
            "local_admin": True,
        }

    def _websocket_config(self) -> dict[str, Any]:
        section = getattr(self.config.channels, "websocket", None)
        if section is None:
            section = (getattr(self.config.channels, "__pydantic_extra__", {}) or {}).get(
                "websocket", {}
            )
        if isinstance(section, dict):
            return {
                "host": section.get("host", "127.0.0.1"),
                "port": section.get("port", 8765),
                "path": section.get("path", "/ws"),
            }
        return {
            "host": getattr(section, "host", "127.0.0.1"),
            "port": getattr(section, "port", 8765),
            "path": getattr(section, "path", "/ws"),
        }

    def sessions(self) -> dict[str, Any]:
        if self.session_manager is None:
            return {"sessions": []}
        rows = []
        for item in self.session_manager.list_sessions():
            key = item.get("key", "")
            channel, _, chat_id = key.partition(":")
            cleaned = {k: v for k, v in item.items() if k != "path"}
            cleaned["channel"] = channel
            cleaned["chat_id"] = chat_id
            cleaned["usage"] = self._session_usage(key)
            rows.append(cleaned)
        return {"sessions": rows}

    def _session_usage(self, key: str) -> dict[str, int]:
        if self.session_manager is None:
            return {"used": 0, "limit": self.config.agents.defaults.context_window_tokens}
        data = self.session_manager.read_session_file(key)
        if not isinstance(data, dict):
            return {"used": 0, "limit": self.config.agents.defaults.context_window_tokens}

        class _SessionView:
            messages = data.get("messages", [])

        return estimate_session_usage(_SessionView(), self.config.agents.defaults)  # type: ignore[arg-type]

    def models(self) -> dict[str, Any]:
        provider = self.config.get_provider_name()
        default = self.config.agents.defaults.model
        rows: list[dict[str, Any]] = [{"name": default, "source": "configured", "active": True}]
        seen = {default}
        for model in self.config.agents.defaults.alternate_models:
            if model and model not in seen:
                rows.append({"name": model, "source": "alternate", "active": False})
                seen.add(model)
        try:
            from pythinker.cli.models import RECOMMENDED_BY_PROVIDER

            for model in RECOMMENDED_BY_PROVIDER.get(provider, ()):
                if model not in seen:
                    rows.append({"name": model, "source": "recommended", "active": False})
                    seen.add(model)
        except Exception:
            pass
        return {
            "provider": provider,
            "active_model": getattr(self.agent_loop, "model", default),
            "models": rows,
        }

    def usage(self) -> dict[str, Any]:
        from pythinker.agent.usage_ledger import load_usage_summary

        last_usage = getattr(self.agent_loop, "_last_usage", {}) or {}
        ledger = load_usage_summary(self.config.workspace_path)
        return {
            "last_turn": dict(last_usage),
            "sessions": self.sessions()["sessions"],
            "consumption": {
                "total_tokens": int(ledger.get("total_tokens", 0)),
                "cost": None,
                "currency": None,
            },
            "ledger": ledger,
        }

    def surfaces(self) -> dict[str, Any]:
        return {
            "overview": self.overview(),
            "channels": self.channels(),
            "sessions": self.sessions(),
            "usage": self.usage(),
            "models": self.models(),
            "agents": self.agents(),
            "skills": self.skills(),
            "cron": self.cron(),
            "dreams": self.dreams(),
            "config": self.config_payload(),
            "appearance": self.appearance(),
            "infrastructure": self.infrastructure(),
            "debug": self.debug(),
            "logs": self.logs(),
        }

    def channels(self) -> dict[str, Any]:
        status = {}
        if self.channel_manager is not None and hasattr(self.channel_manager, "get_status"):
            try:
                status = self.channel_manager.get_status()
            except Exception:
                status = {}
        configured = getattr(self.config.channels, "__pydantic_extra__", {}) or {}
        rows = []
        names = sorted(set(configured) | set(status))
        for name in names:
            section = configured.get(name, {})
            enabled = bool(section.get("enabled", False)) if isinstance(section, dict) else False
            runtime = status.get(name, {})
            rows.append({
                "name": name,
                "enabled": enabled or bool(runtime.get("enabled")),
                "running": bool(runtime.get("running")),
                "streaming": bool(section.get("streaming", False)) if isinstance(section, dict) else False,
            })
        return {
            "total": len(rows),
            "running": sum(1 for row in rows if row["running"]),
            "rows": rows,
        }

    def agents(self) -> dict[str, Any]:
        registry = getattr(self.agent_loop, "agent_registry", None)
        manifests = []
        if registry is not None:
            for agent_id in registry.ids():
                manifest = registry.get(agent_id)
                if manifest is None:
                    continue
                manifests.append(manifest.model_dump(mode="json", by_alias=True))
        return {
            "default_agent_id": self.config.runtime.default_agent_id,
            "policy_enabled": self.config.runtime.policy_enabled,
            "manifests_dir": self.config.runtime.manifests_dir,
            "total": len(manifests),
            "agents": manifests,
        }

    def skills(self) -> dict[str, Any]:
        from pythinker.agent.skills import SkillsLoader

        loader = SkillsLoader(
            self.config.workspace_path,
            disabled_skills=set(self.config.agents.defaults.disabled_skills),
        )
        rows = []
        for entry in loader.list_skills(filter_unavailable=False):
            meta = loader.get_skill_metadata(entry["name"]) or {}
            rows.append({
                "name": entry["name"],
                "source": entry["source"],
                "description": meta.get("description") or entry["name"],
                "always": bool(meta.get("always")),
                "disabled": entry["name"] in self.config.agents.defaults.disabled_skills,
            })
        return {
            "total": len(rows),
            "disabled": len(self.config.agents.defaults.disabled_skills),
            "rows": rows,
        }

    def cron(self) -> dict[str, Any]:
        service = getattr(self.agent_loop, "cron_service", None)
        if service is None:
            return {"status": {"enabled": False, "jobs": 0}, "jobs": []}
        try:
            status = service.status()
            jobs = [self._cron_job_payload(job) for job in service.list_jobs(include_disabled=True)]
        except Exception as exc:
            return {"status": {"enabled": False, "jobs": 0, "error": str(exc)}, "jobs": []}
        return {"status": status, "jobs": jobs}

    def _cron_job_payload(self, job: Any) -> dict[str, Any]:
        if is_dataclass(job):
            payload = asdict(job)
        elif hasattr(job, "model_dump"):
            payload = job.model_dump(mode="json", by_alias=True)
        else:
            payload = dict(job)
        # Keep the schedule/routing visible, but avoid dumping long task bodies into overview cards.
        message = payload.get("payload", {}).get("message")
        if isinstance(message, str) and len(message) > 160:
            payload["payload"]["message"] = f"{message[:160]}..."
        return payload

    def dreams(self) -> dict[str, Any]:
        dream = self.config.agents.defaults.dream
        return {
            "schedule": dream.describe_schedule(),
            "model_override": dream.model_override,
            "max_batch_size": dream.max_batch_size,
            "max_iterations": dream.max_iterations,
            "annotate_line_ages": dream.annotate_line_ages,
        }

    def appearance(self) -> dict[str, Any]:
        return {
            "theme": "system",
            "mode": "light/dark",
            "radius": "control",
            "notes": "Appearance is currently browser-local via the WebUI theme toggle.",
        }

    def infrastructure(self) -> dict[str, Any]:
        return {
            "workspace": str(self.config.workspace_path),
            "config_path": str(self.config_path),
            "gateway": self.overview()["gateway"],
            "api": self.overview()["api"],
            "websocket": self._websocket_config(),
            "telemetry": {
                "sink": self.config.runtime.telemetry_sink,
                "jsonl_path": self.config.runtime.telemetry_jsonl_path,
            },
            "mcp_servers": len(self.config.tools.mcp_servers),
            "ssrf_whitelist": list(self.config.tools.ssrf_whitelist),
        }

    def debug(self) -> dict[str, Any]:
        bus = getattr(self.agent_loop, "bus", None)
        subagents = getattr(self.agent_loop, "subagents", None)
        return {
            "policy_enabled": self.config.runtime.policy_enabled,
            "blocked_senders": len(self.config.runtime.blocked_senders),
            "queue_depth": {
                "inbound": self._call_int(bus, "inbound_size"),
                "outbound": self._call_int(bus, "outbound_size"),
            },
            "subagents_running": self._call_int(subagents, "get_running_count"),
            "session_cache_max": self.config.runtime.session_cache_max,
        }

    def logs(self, *, limit: int = 80) -> dict[str, Any]:
        paths: list[Path] = []
        if self.config.runtime.telemetry_jsonl_path:
            paths.append(Path(self.config.runtime.telemetry_jsonl_path).expanduser())
        paths.extend(sorted((self.config_path.parent / "logs").glob("*.log"))[-3:])
        entries: list[dict[str, Any]] = []
        for path in paths:
            if not path.exists() or not path.is_file():
                continue
            try:
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for line in lines[-limit:]:
                entries.append(self._log_entry(path, line))
        return {
            "entries": entries[-limit:],
            "sources": [str(path) for path in paths],
            "truncated": len(entries) > limit,
        }

    def _log_entry(self, path: Path, line: str) -> dict[str, Any]:
        try:
            payload = json.loads(line)
            if isinstance(payload, dict):
                return {
                    "source": str(path),
                    "level": payload.get("level") or payload.get("event") or "info",
                    "message": payload.get("message") or payload.get("event") or line,
                    "raw": payload,
                }
        except json.JSONDecodeError:
            pass
        return {"source": str(path), "level": "log", "message": line, "raw": line}

    @staticmethod
    def _call_int(obj: Any, method: str) -> int:
        if obj is None:
            return 0
        fn = getattr(obj, method, None)
        if not callable(fn):
            return 0
        try:
            return int(fn())
        except Exception:
            return 0

    def config_payload(self) -> dict[str, Any]:
        payload = redacted_config(self._disk_config())
        payload["restart_required_paths"] = ["*"]
        return payload

    def config_schema(self) -> dict[str, Any]:
        schema = Config.model_json_schema(by_alias=True)
        return {
            "schema": schema,
            "secret_paths": self.config_payload()["secret_paths"],
            "restart_required_paths": ["*"],
        }

    def read_config(self, path: str) -> Any:
        return read_config_value(self._disk_config(), path)

    def set_config(self, path: str, value: Any) -> None:
        config = self._disk_config()
        set_config_value(config, path, value)
        save_config_with_backup(config, self.config_path)
        self._mirror_runtime_edit(path, value)

    def unset_config(self, path: str) -> None:
        config = self._disk_config()
        unset_config_value(config, path)
        save_config_with_backup(config, self.config_path)
        self._mirror_runtime_unset(path)

    def replace_secret(self, path: str, value: Any) -> None:
        if not isinstance(value, str) or not value:
            raise ConfigEditError("secret replacement value must be a non-empty string")
        self.set_config(path, value)

    def _disk_config(self) -> Config:
        return load_config(self.config_path)

    def _mirror_runtime_edit(self, path: str, value: Any) -> None:
        try:
            set_config_value(self.config, path, value)
        except Exception:
            pass

    def _mirror_runtime_unset(self, path: str) -> None:
        try:
            unset_config_value(self.config, path)
        except Exception:
            pass
