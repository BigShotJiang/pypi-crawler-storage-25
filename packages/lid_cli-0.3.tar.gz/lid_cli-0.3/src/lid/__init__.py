# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""lid-cli."""

from __future__ import annotations

import importlib
import importlib.metadata

TYPE_CHECKING = False
if TYPE_CHECKING:
    from types import ModuleType

    from lid import gio, io, subprocess, types
else:

    def __getattr__(key: str, /) -> ModuleType:
        if key in __all__:
            return importlib.import_module(f"{__package__}.{key}", package=__package__)
        raise AttributeError(f"module `{__name__}` has not attribute `{key}`")


__version__ = importlib.metadata.version("lid-cli")
__all__ = ["__version__", "gio", "io", "subprocess", "types"]
