# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""CLI."""

from __future__ import annotations

import itertools as it
import logging
import pathlib as pl
from typing import Annotated

import rich.console
import rich.theme
import typer

import lid

log = logging.getLogger(__name__)

env: lid.types.Environment
console: rich.console.Console

_HELP = """
Resource activation and communication helper.
"""

app = typer.Typer(help=_HELP, no_args_is_help=True, rich_markup_mode="markdown")


@app.callback()
def _setup_io() -> None:
    global env, console  # noqa: PLW0603

    import logging

    theme = rich.theme.Theme(
        {
            "info": "italic yellow",
            "warning": "italic red",
            "error": "bold bright_red",
        }
    )
    console = rich.console.Console(
        theme=theme,
        # STDOUT is used for piping; formatted output should go to stderr.
        stderr=True,
    )
    try:
        env = lid.io.capture_environment()
    except lid.types.EnvCaptureError as err:
        console.print("Failed to capture environment.", style="error")
        raise typer.Exit(2) from err

    if env.log_level is None:
        logging.basicConfig(level=logging.CRITICAL)
    else:
        from pathlib import Path

        import msgspec

        logging.basicConfig(
            filename=Path.cwd() / ".lid.jsonl",
            encoding="utf-8",
            level=env.log_level,
            force=True,
        )

        _encode_json = msgspec.json.Encoder().encode

        class JsonLineFormatter(logging.Formatter):
            def format(self, record: logging.LogRecord) -> str:
                return _encode_json(
                    {
                        "time": self.formatTime(record),
                        "level": record.levelname,
                        "logger": record.name,
                        "message": record.getMessage(),
                    }
                ).decode("utf-8")

        root_logger = logging.getLogger()
        for handler in root_logger.handlers:
            handler.setFormatter(JsonLineFormatter())


# Use `list` as return value since type must be available at runtime for typer to work.
# Argument is passed as kwarg by typer.
def _complete_mount_kw(incomplete: str) -> list[str]:
    import asyncio

    env = lid.io.capture_environment()
    return asyncio.run(
        lid.gio.find_device_names(
            incomplete, mounted_only=False, env=env, runner=lid.subprocess.run
        )
    )


def _require_nonempty(param: typer.CallbackParam, v: str | None) -> str | None:
    if v is None or v:
        return v
    raise typer.BadParameter(f"parameter `{param.name}` must not be an empty string")


@app.command()
def mount(
    kw: Annotated[
        str,
        typer.Argument(
            help="Device keyword.",
            autocompletion=_complete_mount_kw,
            callback=_require_nonempty,
        ),
    ],
) -> int:
    import asyncio
    import uuid

    import msgspec

    with asyncio.Runner() as runner:
        try:
            mt = runner.run(lid.gio.mount(kw, env=env, runner=lid.subprocess.run))
        except lid.types.GioNotFoundError as err:
            log.exception("Failed to mount for keyword `%s`.", kw)
            raise typer.BadParameter(f"Device not determined: {err}.") from None
        except lid.types.GioMountError as err:
            log.exception("Failed to mount for keyword `%s`.", kw)
            console.print(f"Mount failure: {err}.", style="error")
            raise typer.Exit(2) from None

        console.print(f"Mounted `{mt.name}`.", style="info")
        if mt.triggered:
            mt_info = msgspec.json.encode(mt)
            try:
                env.runtime_dir.mkdir(parents=True, exist_ok=True)
                env.runtime_dir.joinpath(str(uuid.uuid4())).write_bytes(mt_info)
            except OSError, PermissionError:
                log.exception("Failed to create mount marker file.")
                try:
                    runner.run(
                        lid.gio.umount(mount=mt, env=env, runner=lid.subprocess.run)
                    )
                except lid.types.GioMountError as err:
                    console.print(
                        f"Failed to create marker file, then failed to umount: {err}.",
                        style="error",
                    )
                    raise typer.Exit(2) from None

    # Needs to be unformatted to not confuse receiver (listening on STDOUT).
    print(mt.mountpoint)
    return 0


def _complete_umount_kw(incomplete: str) -> list[str]:
    import asyncio

    env = lid.io.capture_environment()
    return asyncio.run(
        lid.gio.find_device_names(
            incomplete, mounted_only=True, env=env, runner=lid.subprocess.run
        )
    )


async def _umount(kw: str, /, env: lid.types.Environment) -> int:
    import asyncio

    names, markers = await asyncio.gather(
        lid.gio.find_device_names(
            kw, mounted_only=True, env=env, runner=lid.subprocess.run
        ),
        asyncio.to_thread(lid.io.read_mount_markers, env),
    )
    match [(p, m) for n, (p, m) in it.product(names, markers) if n == m.name]:
        case []:
            log.info("Found no matching marker file. Exiting.")
            return 0
        case [[pl.Path() as f, lid.types.Mount() as mt]]:
            try:
                await lid.gio.umount(mount=mt, env=env, runner=lid.subprocess.run)
            except lid.types.GioNotFoundError as err:
                log.exception("Failed to mount for keyword `%s` (match: `%s`.", kw, mt)
                raise typer.BadParameter(f"Device not determined: {err}.") from None
            except lid.types.GioMountError as err:
                log.exception(
                    "Failed to unmount for keyword `%s` (match: `%s`).", kw, mt
                )
                console.print(f"Unmount failure: {err}.", style="error")
                raise typer.Exit(2) from None

            console.print(f"Unmounted `{mt.name}`.", style="info")

            try:
                f.unlink()
            except OSError, PermissionError:
                console.print(
                    f"Failed to remove marker file `{f.as_posix()}`.", style="error"
                )
                raise typer.Exit(2) from None
            return 0
        case [[pl.Path() as f, fmt], [pl.Path() as s, smt], *m]:
            raise typer.BadParameter(
                f"Keyword `{kw}` matches `{fmt.name}` (file:`{f.name}`), "
                f"`{smt.name}` (file: `{s.name}`), and {len(m)} more."
            )

    console.print(
        "Discovered unsupported case. No action will be taken.", style="error"
    )
    return 2


@app.command()
def umount(
    kw: Annotated[
        str,
        typer.Argument(
            help="Device keyword.",
            autocompletion=_complete_umount_kw,
            callback=_require_nonempty,
        ),
    ],
) -> int:
    import asyncio

    env = lid.io.capture_environment()
    return asyncio.run(_umount(kw, env=env))
