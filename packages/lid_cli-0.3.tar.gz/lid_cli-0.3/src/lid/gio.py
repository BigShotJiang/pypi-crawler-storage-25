# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""Parse mount-style indentation based files."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass

from lid import types

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Sequence
    from typing import Any, Protocol, cast, overload

    class AsyncRunner(Protocol):
        async def __call__(
            self, bin_: str, /, *args: str, env_mods: dict[str, str] | None = None
        ) -> str: ...

    @overload
    async def umount(
        kw: str,
        /,
        *,
        env: types.Environment,
        runner: AsyncRunner,
    ) -> None: ...
    @overload
    async def umount(
        *,
        mount: types.Mount,
        env: types.Environment,
        runner: AsyncRunner,
    ) -> None: ...


__all__ = ["find_device_names", "mount", "umount"]

log = logging.getLogger(__name__)


# Return type dictated by use a completion suggester.
async def find_device_names(
    kw: str, /, mounted_only: bool, env: types.Environment, runner: AsyncRunner
) -> list[str]:
    device_info = await _query_matching_device_info(
        kw, include_details=False, env=env, runner=runner
    )
    if not mounted_only:
        return [d["__name__"] for d in device_info]
    return [d["__name__"] for d in device_info if any(k.startswith("Mount") for k in d)]


async def mount(kw: str, /, env: types.Environment, runner: AsyncRunner) -> types.Mount:
    """Mount device.

    Parameters
    ----------
    kw
        (Partial) name of device as given in the top line of the gio output section.
    """
    device_info = await _query_matching_device_info(
        kw, include_details=True, env=env, runner=runner
    )
    device = _extract_device(kw, device_info=device_info)

    name, mount_id, is_mounted = device.name, device.id_, device.is_mounted
    if is_mounted:
        log.info("Device `%s` already mounted.", name)
    else:
        log.info("Mounting device `%s`.", name)
        try:
            await runner(env.gio_bin, "mount", "--device", mount_id)
        except types.SubprocessError as err:
            log.exception("Failed to mount device ID `%s`.", mount_id)
            raise types.GioMountError(
                f"failed to mount device with ID`{mount_id}`"
            ) from err

    try:
        mp = await _find_mountpoint(mount_id, env=env, runner=runner)
    except types.GioMountError as err:
        log.exception("Found no mount point for `%s`.", name)
        raise types.GioMountError(f"found no mount point for `{name}`") from err

    return types.Mount(name=name, mountpoint=mp, triggered=mount_id is not None)


async def umount(
    kw: str | None = None,
    /,
    *,
    mount: types.Mount | None = None,
    env: types.Environment,
    runner: AsyncRunner,
) -> None:
    """Unmount device."""
    if kw is not None:
        device_info = await _query_matching_device_info(
            kw, include_details=True, env=env, runner=runner
        )
        device = _extract_device(kw, device_info=device_info)

        if not device.is_mounted:
            log.info("Device `%s` not mounted.")
            return
        name, mount_id = device.name, device.id_

        try:
            mountpoint = await _find_mountpoint(mount_id, env=env, runner=runner)
        except types.GioMountError as err:
            log.exception("Found no mount point for `%s`.", name)
            raise types.GioMountError(f"found no mount point for `{name}`") from err
    else:
        if TYPE_CHECKING:
            mount = cast("types.Mount", mount)
        mountpoint = mount.mountpoint

    try:
        await runner(env.gio_bin, "mount", "--unmount", mountpoint)
    except types.SubprocessError as err:
        raise types.GioMountError(f"failed to unmount `{mountpoint}`") from err


@dataclass(slots=True, kw_only=True)
class _Device:
    name: str
    id_: str
    is_mounted: bool
    data: dict[str, Any]


async def _query_matching_device_info(
    kw: str, /, include_details: bool, env: types.Environment, runner: AsyncRunner
) -> Sequence[dict[str, Any]]:
    if not kw:
        raise ValueError("empty keyword cannot be used for device identification")

    if include_details:
        gio_args = ("mount", "--list", "--detail")
    else:
        gio_args = ("mount", "--list")
    try:
        gio_out = await runner(env.gio_bin, *gio_args)
    except types.SubprocessError as err:
        raise types.GioMountError(
            "failed to collect gio output for device discovery"
        ) from err
    try:
        info = _parse_output(gio_out)
    except types.GioParseError as err:
        raise types.GioMountError(
            "failed to parse gio output for device discovery"
        ) from err

    pattern = re.compile(kw, re.IGNORECASE)
    return [
        v
        for k, v in info.items()
        if k.startswith(("Volume", "Drive"))
        and isinstance(v, dict)
        and pattern.search(v.get("__name__", "")) is not None
    ]


def _extract_device(kw: str, /, device_info: Sequence[dict[str, Any]]) -> _Device:
    match device_info:
        case []:
            raise types.GioNotFoundError(f"found no device matching for `{kw}`")
        case [{"__name__": name} as v]:
            log.debug("Matched `%s` to full name `%s`.", kw, name)

            is_mounted = any(k_.startswith("Mount") for k_ in v)
            match v:
                case {"ids": {"unix-device": str() as mount_id}}:
                    log.info("Found unix-device `%s`.")
                case {"ids": {"uuid": str() as mount_id}}:
                    log.info("Found UUID `%s`.")
                case _:
                    log.error("Failed to find mount ID in `%s`.", v)
                    raise types.GioNotFoundError(f"failed to find ID for `{name}`")
            return _Device(name=name, id_=mount_id, is_mounted=is_mounted, data=v)
        case [f, s, *ms]:
            fn, sn, lms = f["__name__"], s["__name__"], len(ms)
            raise types.GioNotFoundError(
                f"found multiple matches for `{kw}`: `{fn}`, `{sn}`, and {lms} more."
            )
        case _:
            raise types.GioNotFoundError("unsupported gio output structure")


async def _find_mountpoint(
    id_: str, /, env: types.Environment, runner: AsyncRunner
) -> str:
    try:
        # Requires device to be mounted.
        # Need to the US locale as the output key are adapted to that setting.
        gio_out = await runner(
            env.gio_bin, "info", "-a", "local", id_, env_mods={"LANG": "en_US-UTF-8"}
        )
    except types.SubprocessError as err:
        raise types.GioMountError(
            "failed to collect gio output for mountpoint discovery"
        ) from err
    try:
        gio_out = _parse_output(gio_out)
    except types.GioParseError as err:
        raise types.GioMountError(
            "failed to parse gio output for path discovery"
        ) from err

    return gio_out["local path"]


def _parse_output(text: str, /, header_name: str = "__name__") -> dict[str, Any]:
    content, stack = {}, []
    for line in text.splitlines():
        if (line := _parse_line(line)) is None:
            continue

        if not stack:
            log.debug("Entering toplevel (indent %s).", line.indent)
            content[line.key] = line.value
            stack.append(_SubConfig(indent=line.indent, content=content))
            continue

        while len(stack) > 1 and line.indent < (prev_indent := stack[-1].indent):
            log.debug("Leaving level (indent %s).", prev_indent)
            stack.pop()
        current = stack[-1]
        if line.indent < current.indent:
            raise types.GioParseError(
                f"indent {line.indent} does not match any previous level"
            )

        if line.indent > current.indent:
            log.debug("Entering level (indent %s).", line.indent)
            # `current.content` is only empty in empty in the first round, wherein
            # this case cannot occur.
            prev_k, prev_v = next(reversed(current.content.items()))
            if prev_v is None:
                log.debug("Adding %s=%s.", line.key, line.value)
                current.content[prev_k] = {line.key: line.value}
            else:
                log.debug("Adding existing value as header name.")
                log.debug("Adding %s=%s.", line.key, line.value)
                current.content[prev_k] = {header_name: prev_v, line.key: line.value}
            stack.append(
                _SubConfig(indent=line.indent, content=current.content[prev_k])
            )
        else:
            log.debug("Adding %s=%s.", line.key, line.value)
            current.content[line.key] = line.value

    return content


@dataclass(slots=True, kw_only=True)
class _SubConfig:
    indent: int
    content: dict[str, Any]


@dataclass(slots=True, kw_only=True)
class _Line:
    indent: int
    key: str
    value: str | None


_LEADING_WHITESP = re.compile(r"\s*(?=\S)")
_POS_QUOTED = re.compile(r"'?(?P<cnt>.?)'?")
_SPEC = re.compile(r"(?P<key>[A-Za-z][\w() -]*?)\s*[:=]\s*(?P<val>.*?)\s*")


def _parse_line(
    line: str,
    /,
) -> _Line | None:
    log.debug("Parsing `%s`.", line)
    if (lwsp_match := _LEADING_WHITESP.match(line)) is None:
        # Empty line or line containing only whitespace.
        log.debug("Skipping empty line.")
        return None

    lwsp = lwsp_match.group()
    indent = len(lwsp)
    content = _POS_QUOTED.sub(r"\g<cnt>", line[lwsp_match.end() :])
    log.debug("Extracted content: `%s` (indent: %s).", content, indent)

    if (spec_match := _SPEC.fullmatch(content)) is None:
        raise types.GioParseError("line not matching expected pattern: `%s`", content)

    key, value = spec_match.group("key"), spec_match.group("val") or None
    log.debug("Found key/value: `%s`=`%s`.", key, value)
    return _Line(indent=indent, key=key, value=value)
