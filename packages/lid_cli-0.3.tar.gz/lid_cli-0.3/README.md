# lid-cli

To find device, run `gio mount --list --detail` and select ID in the first line.
