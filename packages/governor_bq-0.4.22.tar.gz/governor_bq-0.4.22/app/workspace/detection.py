"""Local workspace detection — dbt project, Git repo, and branch discovery.

Scans a directory for dbt project indicators and Git configuration.
Used by the CLI during `governor init` and by the UI for branch display.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("app.workspace.detection")


@dataclass
class WorkspaceInfo:
    """Result of scanning a local directory for dbt + Git context."""

    project_path: str | None = None
    dbt_project_name: str | None = None
    has_manifest: bool = False
    has_run_results: bool = False
    git_repo: str | None = None  # owner/repo format
    git_branch: str | None = None
    git_is_repo: bool = False
    errors: list[str] = field(default_factory=list)


def detect_workspace(path: str | Path) -> WorkspaceInfo:
    """Scan a directory for dbt project and Git information.

    Args:
        path: Directory to scan (typically the developer's CWD or a provided path).

    Returns:
        WorkspaceInfo with all discovered information.
    """
    info = WorkspaceInfo()
    project_dir = Path(path).expanduser().resolve()

    if not project_dir.is_dir():
        info.errors.append(f"Not a directory: {project_dir}")
        return info

    # Detect dbt project
    dbt_project_yml = project_dir / "dbt_project.yml"
    if dbt_project_yml.exists():
        info.project_path = str(project_dir)
        info.dbt_project_name = _parse_dbt_project_name(dbt_project_yml)
        logger.info("Found dbt project: %s at %s", info.dbt_project_name, project_dir)
    else:
        # Check if we're inside a subdirectory of a dbt project
        for parent in project_dir.parents:
            if (parent / "dbt_project.yml").exists():
                info.project_path = str(parent)
                info.dbt_project_name = _parse_dbt_project_name(
                    parent / "dbt_project.yml"
                )
                logger.info(
                    "Found dbt project in parent: %s at %s",
                    info.dbt_project_name,
                    parent,
                )
                break

    if not info.project_path:
        info.errors.append(f"No dbt_project.yml found in {project_dir} or parents")
        return info

    project_root = Path(info.project_path)

    # Check for manifest and run_results
    manifest_path = project_root / "target" / "manifest.json"
    info.has_manifest = manifest_path.exists()
    if not info.has_manifest:
        info.errors.append(
            f"No target/manifest.json found. Run 'dbt compile' or 'dbt build' first."
        )

    run_results_path = project_root / "target" / "run_results.json"
    info.has_run_results = run_results_path.exists()

    # Detect Git information
    git_info = detect_git_info(info.project_path)
    info.git_is_repo = git_info["is_repo"]
    info.git_repo = git_info["repo"]
    info.git_branch = git_info["branch"]

    return info


def detect_git_info(project_path: str) -> dict:
    """Detect Git repository URL and current branch.

    Args:
        project_path: Path to the project directory.

    Returns:
        Dict with keys: is_repo, repo (owner/repo or None), branch (or None).
    """
    result = {"is_repo": False, "repo": None, "branch": None}

    try:
        # Check if it's a git repo
        cp = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=project_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if cp.returncode != 0:
            return result
        result["is_repo"] = True

        # Get current branch
        cp = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=project_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if cp.returncode == 0 and cp.stdout.strip():
            result["branch"] = cp.stdout.strip()

        # Get remote URL
        cp = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=project_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if cp.returncode == 0 and cp.stdout.strip():
            result["repo"] = _parse_github_remote(cp.stdout.strip())

    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        logger.debug("Git detection failed: %s", exc)

    return result


def read_local_manifest(project_path: str) -> bytes | None:
    """Read target/manifest.json from a local dbt project.

    Returns manifest bytes or None if file doesn't exist.
    """
    manifest = Path(project_path) / "target" / "manifest.json"
    if manifest.exists():
        return manifest.read_bytes()
    return None


def read_local_run_results(project_path: str) -> dict | None:
    """Read and parse target/run_results.json from a local dbt project.

    Returns parsed JSON dict or None if file doesn't exist.
    """
    run_results = Path(project_path) / "target" / "run_results.json"
    if not run_results.exists():
        return None
    try:
        return json.loads(run_results.read_bytes())
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Failed to parse run_results.json: %s", exc)
        return None


def read_local_file(project_path: str, relative_path: str) -> str | None:
    """Read a source file from the local dbt project working tree.

    Args:
        project_path: Absolute path to the dbt project root.
        relative_path: Relative path within the project (e.g., 'models/staging/stg_orders.sql').

    Returns:
        File contents as string, or None if file doesn't exist.

    Raises:
        ValueError: If the resolved path escapes the project directory (path traversal).
    """
    project_root = Path(project_path).resolve()
    target = (project_root / relative_path).resolve()

    # Path traversal protection
    if not str(target).startswith(str(project_root)):
        raise ValueError(
            f"Path traversal detected: {relative_path} resolves outside project root"
        )

    if not target.exists() or not target.is_file():
        return None

    return target.read_text(encoding="utf-8")


def write_local_file(project_path: str, relative_path: str, content: str) -> str:
    """Write content to a file in the local dbt project working tree.

    Args:
        project_path: Absolute path to the dbt project root.
        relative_path: Relative path within the project.
        content: File content to write.

    Returns:
        Absolute path of the written file.

    Raises:
        ValueError: If the resolved path escapes the project directory.
    """
    project_root = Path(project_path).resolve()
    target = (project_root / relative_path).resolve()

    # Path traversal protection
    if not str(target).startswith(str(project_root)):
        raise ValueError(
            f"Path traversal detected: {relative_path} resolves outside project root"
        )

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    logger.info("Wrote solution to %s", target)
    return str(target)


def _parse_dbt_project_name(yml_path: Path) -> str | None:
    """Extract the project name from dbt_project.yml."""
    try:
        text = yml_path.read_text(encoding="utf-8")
        for line in text.splitlines():
            if line.strip().startswith("name:"):
                return line.split(":", 1)[1].strip().strip("'\"")
    except OSError:
        pass
    return None


def _parse_github_remote(url: str) -> str | None:
    """Parse a Git remote URL into owner/repo format.

    Handles:
    - https://github.com/owner/repo.git
    - git@github.com:owner/repo.git
    - https://github.com/owner/repo
    """
    # HTTPS format
    match = re.match(r"https?://github\.com/([^/]+)/([^/.]+?)(?:\.git)?$", url)
    if match:
        return f"{match.group(1)}/{match.group(2)}"

    # SSH format
    match = re.match(r"git@github\.com:([^/]+)/([^/.]+?)(?:\.git)?$", url)
    if match:
        return f"{match.group(1)}/{match.group(2)}"

    return None
