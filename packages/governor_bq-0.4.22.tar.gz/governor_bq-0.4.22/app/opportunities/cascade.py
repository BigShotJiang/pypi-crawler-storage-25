"""Cascade solution consolidation — lineage-aware opportunity grouping.

When the same performance issue appears across multiple models in a lineage
chain, the CascadeAnalyzer groups them and elects a single root-cause model
where one fix has maximum cascading impact.
"""

from __future__ import annotations

import logging
import uuid
from collections import defaultdict
from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.opportunities.models import Opportunity

logger = logging.getLogger("app.opportunities.cascade")

COMPATIBLE_TYPES: frozenset[str] = frozenset(
    {
        "shuffle_spill",
        "slot_contention",
        "join_explosion",
        "partition_pruning",
    }
)

MAX_GROUP_SIZE = 20


@dataclass
class CascadeResult:
    """Statistics from cascade analysis."""

    groups_created: int = 0
    opportunities_grouped: int = 0
    root_causes_elected: int = 0
    skipped_too_large: int = 0


@dataclass
class RootCandidate:
    """Validated upstream root candidate for a delegated opportunity."""

    root_id: str
    lineage_path: list[str]
    propagation_reason: str
    upstream_depth: int
    config_gap: int
    severity: int
    dominates_all_other_candidates: bool = False


class CascadeAnalyzer:
    """Analyzes lineage chains to group and consolidate related opportunities.

    The analyzer runs after detection completes, before solution queuing.
    It groups opportunities that share the same lineage chain and elects
    a single root-cause model for each group.
    """

    def analyze(
        self,
        config_id: str,
        manifest_content: dict,
        db: Session,
    ) -> CascadeResult:
        """Run cascade analysis for all active opportunities in a config.

        1. Load active opportunities with compatible types
        2. Clear stale cascade fields
        3. Build lineage graph from manifest
        4. Find connected components
        5. For each group (≥2 opps): elect root, mark others as delegated
        """
        import time

        t0 = time.monotonic()
        result = CascadeResult()

        if not manifest_content or not manifest_content.get("nodes"):
            logger.debug("No manifest content, skipping cascade analysis")
            return result

        opportunities = (
            db.query(Opportunity)
            .filter(
                Opportunity.config_id == config_id,
                Opportunity.status == "active",
                Opportunity.opportunity_type.in_(COMPATIBLE_TYPES),
            )
            .all()
        )

        # Filter out opportunities with no dbt_model_name (can't do lineage)
        skipped = [o for o in opportunities if not o.dbt_model_name]
        opportunities = [o for o in opportunities if o.dbt_model_name]
        for opp in skipped:
            opp.cascade_group_id = None
            opp.cascade_root_id = None
            opp.cascade_status = None
            self._clear_cascade_evidence(opp)

        if len(opportunities) < 2:
            # Clear any stale cascade fields from prior runs
            for opp in opportunities:
                opp.cascade_group_id = None
                opp.cascade_root_id = None
                opp.cascade_status = None
                self._clear_cascade_evidence(opp)
            db.flush()
            return result

        # Clear existing cascade fields before fresh analysis
        for opp in opportunities:
            opp.cascade_group_id = None
            opp.cascade_root_id = None
            opp.cascade_status = None
            self._clear_cascade_evidence(opp)

        opps_by_id = {opp.id: opp for opp in opportunities}
        model_nodes, deps = self._build_manifest_maps(manifest_content)
        assignments = self._build_root_assignments(
            opportunities, opps_by_id, model_nodes, deps
        )

        groups_by_root: dict[str, set[str]] = defaultdict(set)
        relationship_payloads: dict[str, dict] = {}
        for delegated_id, candidate in assignments.items():
            groups_by_root[candidate.root_id].add(candidate.root_id)
            groups_by_root[candidate.root_id].add(delegated_id)
            relationship_payloads[delegated_id] = {
                "root_model": opps_by_id[candidate.root_id].dbt_model_name,
                "delegated_model": opps_by_id[delegated_id].dbt_model_name,
                "lineage_path": candidate.lineage_path,
                "propagation_reason": candidate.propagation_reason,
                "validation_status": "valid",
            }

        for root_id, component in groups_by_root.items():
            if len(component) < 2:
                continue

            if len(component) > MAX_GROUP_SIZE:
                result.skipped_too_large += 1
                logger.info(
                    "Skipping cascade group with %d opportunities (exceeds max %d)",
                    len(component),
                    MAX_GROUP_SIZE,
                )
                continue

            group_id = str(uuid.uuid4())

            for opp_id in component:
                opp = opps_by_id[opp_id]
                opp.cascade_group_id = group_id
                if opp_id == root_id:
                    opp.cascade_status = "root"
                    opp.cascade_root_id = None
                    self._set_cascade_relationship(opp, None)
                else:
                    opp.cascade_status = "delegated"
                    opp.cascade_root_id = root_id
                    self._set_cascade_relationship(
                        opp, relationship_payloads.get(opp_id)
                    )

            # Aggregate severity: root gets max severity across the group
            root_opp = opps_by_id[root_id]
            max_severity = max(
                opps_by_id[oid].severity_score for oid in component
            )
            if root_opp.severity_score < max_severity:
                root_opp.severity_score = max_severity

            result.groups_created += 1
            result.opportunities_grouped += len(component)
            result.root_causes_elected += 1

        db.flush()

        elapsed_ms = (time.monotonic() - t0) * 1000
        logger.info(
            "Cascade analysis completed in %.0fms: %d groups, %d grouped, "
            "%d roots, %d skipped (too large)",
            elapsed_ms,
            result.groups_created,
            result.opportunities_grouped,
            result.root_causes_elected,
            result.skipped_too_large,
        )
        return result

    def _build_manifest_maps(
        self, manifest_content: dict
    ) -> tuple[dict[str, dict], dict[str, set[str]]]:
        """Build model-node and upstream dependency maps from manifest."""
        nodes = manifest_content.get("nodes", {})
        model_nodes: dict[str, dict] = {}
        deps: dict[str, set[str]] = {}
        uid_to_name: dict[str, str] = {}

        for uid, node in nodes.items():
            if node.get("resource_type") != "model":
                continue
            model_name = node.get("name", "")
            model_nodes[model_name] = node
            uid_to_name[uid] = model_name

        for model_name, node in model_nodes.items():
            upstream_uids = node.get("depends_on", {}).get("nodes", [])
            deps[model_name] = {
                uid_to_name[u_uid]
                for u_uid in upstream_uids
                if u_uid in uid_to_name
            }

        return model_nodes, deps

    def _build_root_assignments(
        self,
        opportunities: list[Opportunity],
        opps_by_id: dict[str, Opportunity],
        model_nodes: dict[str, dict],
        deps: dict[str, set[str]],
    ) -> dict[str, RootCandidate]:
        """Assign each opportunity to a validated upstream root candidate, if any."""
        assignments: dict[str, RootCandidate] = {}
        opps_by_model: dict[str, list[Opportunity]] = defaultdict(list)
        for opp in opportunities:
            if opp.dbt_model_name:
                opps_by_model[opp.dbt_model_name].append(opp)

        for opp in opportunities:
            target_model = opp.dbt_model_name
            if not target_model or target_model not in model_nodes:
                continue

            candidates: list[RootCandidate] = []
            for root_opp in opportunities:
                if root_opp.id == opp.id:
                    continue
                root_model = root_opp.dbt_model_name
                if not root_model or root_model == target_model:
                    continue

                lineage_path = self._find_upstream_path(
                    root_model,
                    target_model,
                    deps,
                )
                if not lineage_path:
                    continue

                root_node = model_nodes.get(root_model, {})
                if not self._is_materializable(root_node):
                    continue
                if not self._is_fix_family_compatible(root_opp, opp):
                    continue

                candidate = RootCandidate(
                    root_id=root_opp.id,
                    lineage_path=lineage_path,
                    propagation_reason=self._build_propagation_reason(
                        root_opp=root_opp,
                        delegated_opp=opp,
                    ),
                    upstream_depth=self._compute_downstream_count(root_model, deps),
                    config_gap=self._config_gap(root_node),
                    severity=root_opp.severity_score or 0,
                )
                candidates.append(candidate)

            if not candidates:
                continue

            for candidate in candidates:
                candidate.dominates_all_other_candidates = all(
                    other.root_id == candidate.root_id
                    or self._find_upstream_path(
                        opps_by_id[candidate.root_id].dbt_model_name or "",
                        opps_by_id[other.root_id].dbt_model_name or "",
                        deps,
                    )
                    is not None
                    for other in candidates
                )

            dominant_candidates = [c for c in candidates if c.dominates_all_other_candidates]
            if len(dominant_candidates) != 1:
                self._set_cascade_rejection(
                    opp,
                    reason="invalid_ambiguous",
                    candidate_root_model=None,
                )
                continue

            dominant_candidates.sort(
                key=lambda c: (c.upstream_depth, c.config_gap, c.severity),
                reverse=True,
            )
            assignments[opp.id] = dominant_candidates[0]

        # A root cannot itself be delegated. If assignments create a cycle or a
        # delegated-root chain, prefer no delegation over speculative grouping.
        while True:
            delegated_ids = set(assignments.keys())
            invalid_targets = [
                delegated_id
                for delegated_id, candidate in assignments.items()
                if candidate.root_id in delegated_ids
            ]
            if not invalid_targets:
                break
            for delegated_id in invalid_targets:
                assignments.pop(delegated_id, None)

        return assignments

    def _is_materializable(self, node: dict) -> bool:
        materialized = (node.get("config") or {}).get("materialized", "view")
        return materialized in ("table", "incremental")

    def _is_fix_family_compatible(
        self,
        root_opp: Opportunity,
        delegated_opp: Opportunity,
    ) -> bool:
        """Return True when the upstream fix can plausibly propagate downstream."""
        return (
            root_opp.opportunity_type in COMPATIBLE_TYPES
            and delegated_opp.opportunity_type in COMPATIBLE_TYPES
        )

    def _build_propagation_reason(
        self,
        *,
        root_opp: Opportunity,
        delegated_opp: Opportunity,
    ) -> str:
        return (
            f"Upstream {root_opp.opportunity_type.replace('_', ' ')} fix on "
            f"{root_opp.dbt_model_name} can propagate through dbt ref() lineage "
            f"to {delegated_opp.dbt_model_name}."
        )

    def _find_upstream_path(
        self,
        root_model: str,
        target_model: str,
        deps: dict[str, set[str]],
    ) -> list[str] | None:
        """Return directed upstream path root -> ... -> target if one exists."""
        if not root_model or not target_model or root_model == target_model:
            return None

        queue: list[tuple[str, list[str]]] = [(target_model, [target_model])]
        visited: set[str] = set()
        while queue:
            current, path = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            for upstream in deps.get(current, set()):
                next_path = [upstream, *path]
                if upstream == root_model:
                    return next_path
                queue.append((upstream, next_path))
        return None

    def _compute_downstream_count(
        self,
        model_name: str,
        deps: dict[str, set[str]],
    ) -> int:
        """Count how many models transitively depend on this model."""
        reverse_deps: dict[str, set[str]] = defaultdict(set)
        for child, parents in deps.items():
            for parent in parents:
                reverse_deps[parent].add(child)

        visited: set[str] = set()
        queue = list(reverse_deps.get(model_name, set()))
        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            queue.extend(reverse_deps.get(current, []))

        return len(visited)

    def _config_gap(self, node: dict) -> int:
        config = node.get("config", {})
        has_partition = 1 if config.get("partition_by") else 0
        has_cluster = 1 if config.get("cluster_by") else 0
        return 2 - has_partition - has_cluster

    def _set_cascade_relationship(
        self,
        opp: Opportunity,
        payload: dict | None,
    ) -> None:
        snapshot = dict(opp.evidence_snapshot or {})
        if payload is None:
            snapshot.pop("cascade_relationship", None)
        else:
            snapshot["cascade_relationship"] = payload
        opp.evidence_snapshot = snapshot

    def _set_cascade_rejection(
        self,
        opp: Opportunity,
        *,
        reason: str,
        candidate_root_model: str | None,
    ) -> None:
        snapshot = dict(opp.evidence_snapshot or {})
        snapshot["cascade_rejection"] = {
            "candidate_root_model": candidate_root_model,
            "delegated_model": opp.dbt_model_name,
            "reason": reason,
        }
        snapshot.pop("cascade_relationship", None)
        opp.evidence_snapshot = snapshot

    def _clear_cascade_evidence(self, opp: Opportunity) -> None:
        snapshot = dict(opp.evidence_snapshot or {})
        snapshot.pop("cascade_relationship", None)
        snapshot.pop("cascade_rejection", None)
        opp.evidence_snapshot = snapshot
