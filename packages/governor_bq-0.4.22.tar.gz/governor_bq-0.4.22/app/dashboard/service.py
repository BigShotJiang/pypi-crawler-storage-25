"""
Dashboard service for cost analytics aggregation.

Provides aggregated views of BigQuery costs, trends, and optimization opportunities.
All queries are read-only against existing tables from specs 003, 004, and 005.
"""

from __future__ import annotations

import re
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation

from sqlalchemy import and_, case, false, func, literal, select
from sqlalchemy.orm import Session

from app.core.config import is_local_mode
from app.dashboard.schemas import (
    CostDriver,
    DailyProjectStats,
    DailySpend,
    DashboardSummary,
    DatasetStorageSummary,
    EnrichedCostDriver,
    EnvironmentBreakdown,
    LocalModelDriver,
    LocalModelRunPoint,
    ManifestHealthScore,
    OpportunitySummary,
    ProjectBreakdown,
    ProjectDriver,
    ProjectHealthScore,
    StorageSummary,
)
from app.configurations.models import ManifestConfiguration
from app.opportunities.historical_savings import (
    calculate_historical_possible_savings,
)
from app.opportunities.models import Opportunity
from app.opportunities.presentation import _POSSIBLE_SAVINGS_RULE_TYPES
from app.opportunities.presentation import (
    get_active_solution_job_statuses,
    get_latest_solution_snapshots,
)
from app.solutions.models import SolutionJob
from app.sync.models import (
    BigQueryJob,
    ManifestVersion,
    SyncOperation,
    TableStorageMetric,
)
from app.sync.service import (
    WORKLOAD_KIND_BUILD,
    WORKLOAD_KIND_CONSUMPTION,
)
from app.utils.pagination import PaginationContext

VALID_COST_LENSES = frozenset({"all", "build", "consumption", "storage"})
_RUN_RESULTS_JOB_ID_PATTERN = re.compile(r"Job ID:\s*([A-Za-z0-9_-]+)")


def _coerce_decimal(value) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    if isinstance(value, bool):
        return Decimal(int(value))
    if isinstance(value, (int, float, str)):
        try:
            return Decimal(str(value))
        except ValueError, TypeError, InvalidOperation:
            return None
    return None


def _coerce_occurrence_count(value) -> int:
    if isinstance(value, bool):
        return 1
    if isinstance(value, int):
        return max(value, 1)
    if value in (None, ""):
        return 1
    try:
        return max(int(value), 1)
    except ValueError, TypeError:
        return 1


def _extract_opportunity_ids(rows: list) -> list[str]:
    ids: list[str] = []
    for row in rows:
        opportunity_id = getattr(row, "id", None)
        if isinstance(opportunity_id, str) and opportunity_id:
            ids.append(opportunity_id)
    return ids


def _normalize_cost_lens(lens: str | None) -> str:
    if lens in VALID_COST_LENSES:
        return lens
    return "all"


def _workload_kind_for_lens(lens: str | None) -> str | None:
    normalized_lens = _normalize_cost_lens(lens)
    if normalized_lens == WORKLOAD_KIND_BUILD:
        return WORKLOAD_KIND_BUILD
    if normalized_lens == WORKLOAD_KIND_CONSUMPTION:
        return WORKLOAD_KIND_CONSUMPTION
    return None


class DashboardService:
    """Service for aggregating dashboard metrics from synced data."""

    def __init__(self, db: Session) -> None:
        self._db = db
        self._local_sync_scope_cache: dict[str | None, list[str] | None] = {}

    @staticmethod
    def _verified_savings_expr():
        gross = case(
            (
                and_(
                    Opportunity.latest_solution_dry_run_original_cost.isnot(None),
                    Opportunity.latest_solution_dry_run_modified_cost.isnot(None),
                    Opportunity.latest_solution_dry_run_original_cost
                    > Opportunity.latest_solution_dry_run_modified_cost,
                ),
                Opportunity.latest_solution_dry_run_original_cost
                - Opportunity.latest_solution_dry_run_modified_cost,
            ),
            else_=literal(Decimal("0")),
        )
        process_cost = func.coalesce(Opportunity.process_cost_usd, Decimal("0"))
        net = gross - process_cost
        # Clamp to zero: CASE WHEN net > 0 THEN net ELSE 0 END
        return case(
            (net > literal(Decimal("0")), net),
            else_=literal(Decimal("0")),
        )

    def _latest_local_sync_ids(self, config_id: str | None = None) -> list[str] | None:
        """Return sync IDs for the latest local execution scope.

        Local mode should reflect the most recent completed local execution, not an
        aggregate of historical runs across configs.
        """
        if not is_local_mode():
            return None

        if config_id in self._local_sync_scope_cache:
            return self._local_sync_scope_cache[config_id]

        query = (
            select(
                SyncOperation.id,
                SyncOperation.config_id,
                SyncOperation.completed_at,
                SyncOperation.created_at,
                SyncOperation.run_results_json,
            )
            .join(
                ManifestConfiguration,
                SyncOperation.config_id == ManifestConfiguration.id,
            )
            .where(
                SyncOperation.status == "completed",
                ManifestConfiguration.local_project_path.isnot(None),
            )
            .order_by(
                SyncOperation.config_id.asc(),
                SyncOperation.completed_at.desc(),
                SyncOperation.created_at.desc(),
            )
        )
        if config_id is not None:
            query = query.where(SyncOperation.config_id == config_id)

        rows = self._db.execute(query).all()
        rows_with_run_results = [row for row in rows if row.run_results_json is not None]
        candidate_rows = rows_with_run_results or rows

        if config_id is not None:
            scoped_ids = [candidate_rows[0].id] if candidate_rows else []
        else:
            latest_row = max(
                candidate_rows,
                key=lambda row: (
                    row.completed_at or row.created_at,
                    row.created_at,
                    row.id,
                ),
                default=None,
            )
            scoped_ids = [latest_row.id] if latest_row else []
        self._local_sync_scope_cache[config_id] = scoped_ids
        return scoped_ids

    def _local_sync_filter(self, config_id: str | None = None) -> list:
        local_sync_ids = self._latest_local_sync_ids(config_id)
        if local_sync_ids is None:
            return []
        if not local_sync_ids:
            return [false()]
        return [BigQueryJob.sync_id.in_(local_sync_ids)]

    @staticmethod
    def _extract_run_result_job_id(result: dict) -> str | None:
        adapter_response = result.get("adapter_response")
        if isinstance(adapter_response, dict):
            raw_job_id = adapter_response.get("job_id")
            if isinstance(raw_job_id, str) and raw_job_id.strip():
                return raw_job_id.strip()

        message_candidates = [result.get("message")]
        if isinstance(adapter_response, dict):
            message_candidates.append(adapter_response.get("_message"))

        for candidate in message_candidates:
            if not isinstance(candidate, str):
                continue
            match = _RUN_RESULTS_JOB_ID_PATTERN.search(candidate)
            if match:
                return match.group(1).strip()
        return None

    @staticmethod
    def _model_name_from_unique_id(
        unique_id: str | None, relation_name: str | None
    ) -> str:
        if isinstance(unique_id, str) and unique_id.strip():
            return unique_id.strip().split(".")[-1]
        if isinstance(relation_name, str) and relation_name.strip():
            return relation_name.strip().split(".")[-1]
        return "unknown_model"

    @staticmethod
    def _local_model_score(
        issue_count: int,
        severities: list[int],
        job_state: str,
    ) -> int:
        penalty = 0
        for severity in severities:
            if severity >= 70:
                penalty += 25
            elif severity >= 40:
                penalty += 15
            else:
                penalty += 8

        if job_state and job_state.upper() != "DONE":
            penalty += 30

        return max(0, min(100, 100 - penalty))

    def _latest_local_sync_operations(
        self,
    ) -> list[tuple[SyncOperation, ManifestConfiguration]]:
        sync_ids = self._latest_local_sync_ids()
        if not sync_ids:
            return []

        rows = (
            self._db.query(SyncOperation, ManifestConfiguration)
            .join(
                ManifestConfiguration,
                SyncOperation.config_id == ManifestConfiguration.id,
            )
            .filter(SyncOperation.id.in_(sync_ids))
            .all()
        )
        return list(rows)

    @staticmethod
    def _normalize_relation_name(relation_name: str | None) -> str | None:
        if not isinstance(relation_name, str):
            return None
        normalized = relation_name.replace("`", "").strip()
        return normalized or None

    @staticmethod
    def _manifest_materialization(manifest_content: dict | None, unique_id: str | None) -> str | None:
        if not isinstance(manifest_content, dict) or not isinstance(unique_id, str):
            return None
        nodes = manifest_content.get("nodes")
        if not isinstance(nodes, dict):
            return None
        node = nodes.get(unique_id)
        if not isinstance(node, dict):
            return None
        config = node.get("config")
        if not isinstance(config, dict):
            return None
        materialized = config.get("materialized")
        if isinstance(materialized, str) and materialized.strip():
            return materialized.strip()
        return None

    def _build_local_model_records(self) -> list[dict]:
        if not is_local_mode():
            return []

        sync_rows = self._latest_local_sync_operations()
        if not sync_rows:
            return []

        sync_by_id = {sync.id: (sync, config) for sync, config in sync_rows}
        config_ids = [config.id for _, config in sync_rows]
        manifest_versions_by_id: dict[str, ManifestVersion] = {}
        used_manifest_ids = [
            sync.used_manifest_version_id
            for sync, _ in sync_rows
            if sync.used_manifest_version_id
        ]
        if used_manifest_ids:
            manifest_rows = (
                self._db.query(ManifestVersion)
                .filter(ManifestVersion.id.in_(used_manifest_ids))
                .all()
            )
            manifest_versions_by_id = {manifest.id: manifest for manifest in manifest_rows}

        run_result_job_ids: list[str] = []
        for sync, _ in sync_rows:
            run_results = sync.run_results_json or {}
            results = run_results.get("results") or []
            for result in results:
                if not isinstance(result, dict):
                    continue
                job_id = self._extract_run_result_job_id(result)
                if job_id:
                    run_result_job_ids.append(job_id)
        run_result_job_ids = list(dict.fromkeys(run_result_job_ids))

        jobs_by_id: dict[str, BigQueryJob] = {}
        if run_result_job_ids:
            job_rows = (
                self._db.query(BigQueryJob)
                .filter(BigQueryJob.job_id.in_(run_result_job_ids))
                .all()
            )
            jobs_by_id = {job.job_id: job for job in job_rows}

        opportunities = []
        if config_ids:
            opportunities = (
                self._db.query(Opportunity)
                .filter(
                    Opportunity.status == "active",
                    Opportunity.config_id.in_(config_ids),
                )
                .all()
            )

        opps_by_config: dict[str, list[Opportunity]] = {}
        for opp in opportunities:
            opps_by_config.setdefault(opp.config_id, []).append(opp)

        records: list[dict] = []
        for sync_id, (sync, config) in sync_by_id.items():
            run_results = sync.run_results_json or {}
            results = run_results.get("results") or []
            manifest_version = manifest_versions_by_id.get(sync.used_manifest_version_id)
            manifest_content = manifest_version.content if manifest_version else None
            for result in results:
                if not isinstance(result, dict):
                    continue
                unique_id = result.get("unique_id")
                relation_name = result.get("relation_name")
                normalized_relation_name = self._normalize_relation_name(relation_name)
                model_name = self._model_name_from_unique_id(unique_id, relation_name)
                materialization = self._manifest_materialization(manifest_content, unique_id)
                job_id = self._extract_run_result_job_id(result)
                job = jobs_by_id.get(job_id) if job_id else None
                adapter_response = result.get("adapter_response")
                if not isinstance(adapter_response, dict):
                    adapter_response = {}

                related_opportunities: list[Opportunity] = []
                for opp in opps_by_config.get(config.id, []):
                    related_job_ids = opp.related_job_ids or []
                    if job_id and job_id in related_job_ids:
                        related_opportunities.append(opp)
                        continue
                    normalized_affected_table = self._normalize_relation_name(
                        getattr(opp, "affected_table", None)
                    )
                    if (
                        normalized_relation_name
                        and normalized_affected_table == normalized_relation_name
                    ):
                        related_opportunities.append(opp)

                issue_opps = [
                    opp
                    for opp in related_opportunities
                    if opp.opportunity_type not in _POSSIBLE_SAVINGS_RULE_TYPES
                ]
                enhancement_opps = [
                    opp
                    for opp in related_opportunities
                    if opp.opportunity_type in _POSSIBLE_SAVINGS_RULE_TYPES
                ]

                sorted_opps = sorted(
                    related_opportunities,
                    key=lambda opp: (
                        -int(getattr(opp, "severity_score", 0) or 0),
                        str(getattr(opp, "id", "")),
                    ),
                )
                opportunity_url = None
                if sorted_opps:
                    opportunity_url = (
                        f"/projects/{config.id}/opportunities/{sorted_opps[0].id}"
                    )

                execution_time_s = result.get("execution_time")
                if execution_time_s is not None:
                    try:
                        execution_time_s = float(execution_time_s)
                    except TypeError, ValueError:
                        execution_time_s = None

                total_bytes_billed = (
                    getattr(job, "total_bytes_billed", None)
                    or adapter_response.get("bytes_billed")
                    or 0
                )
                duration_ms = getattr(job, "duration_ms", None)
                if duration_ms is None and execution_time_s is not None:
                    duration_ms = int(execution_time_s * 1000)

                job_state = (
                    getattr(job, "job_state", None)
                    or str(result.get("status") or "UNKNOWN").upper()
                )
                if job_state == "SUCCESS":
                    job_state = "DONE"

                records.append(
                    {
                        "config_id": config.id,
                        "config_name": config.name or "Unknown",
                        "sync_id": sync_id,
                        "model_name": model_name,
                        "unique_id": unique_id,
                        "materialization": materialization,
                        "relation_name": relation_name,
                        "job_id": job_id,
                        "job_state": job_state,
                        "total_cost": getattr(job, "total_cost", None) or Decimal("0"),
                        "total_bytes_billed": int(total_bytes_billed or 0),
                        "duration_ms": int(duration_ms or 0),
                        "execution_time_s": execution_time_s,
                        "issue_count": len(issue_opps),
                        "enhancement_count": len(enhancement_opps),
                        "opportunity_count": len(related_opportunities),
                        "opportunity_url": opportunity_url,
                        "score": self._local_model_score(
                            len(issue_opps),
                            [
                                int(getattr(opp, "severity_score", 0) or 0)
                                for opp in issue_opps
                            ],
                            job_state,
                        ),
                    }
                )

        return records

    def _build_query_filters(
        self,
        start_date: datetime,
        end_date: datetime,
        config_id: str | None = None,
        lens: str = "all",
    ) -> list:
        filters = [
            BigQueryJob.creation_time >= start_date,
            BigQueryJob.creation_time <= end_date,
            BigQueryJob.total_cost.isnot(None),
            *self._local_sync_filter(config_id),
        ]
        if config_id is not None:
            filters.append(BigQueryJob.config_id == config_id)

        workload_kind = _workload_kind_for_lens(lens)
        if workload_kind is not None:
            filters.append(BigQueryJob.workload_kind == workload_kind)

        return filters

    def _build_summary(
        self,
        start_date: datetime,
        end_date: datetime,
        config_id: str | None = None,
    ) -> DashboardSummary:
        result = self._db.execute(
            select(
                func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                    "total_spend"
                ),
                func.coalesce(
                    func.sum(
                        case(
                            (
                                BigQueryJob.workload_kind == WORKLOAD_KIND_BUILD,
                                BigQueryJob.total_cost,
                            ),
                            else_=Decimal("0"),
                        )
                    ),
                    Decimal("0"),
                ).label("build_spend"),
                func.coalesce(
                    func.sum(
                        case(
                            (
                                BigQueryJob.workload_kind == WORKLOAD_KIND_CONSUMPTION,
                                BigQueryJob.total_cost,
                            ),
                            else_=Decimal("0"),
                        )
                    ),
                    Decimal("0"),
                ).label("consumption_spend"),
                func.count(BigQueryJob.id).label("job_count"),
                func.min(BigQueryJob.creation_time).label("data_start"),
                func.max(BigQueryJob.creation_time).label("data_end"),
            ).where(*self._build_query_filters(start_date, end_date, config_id))
        ).one()

        total_spend = result.total_spend or Decimal("0")
        job_count = result.job_count or 0
        avg_cost = total_spend / job_count if job_count > 0 else Decimal("0")

        days_with_data = 0
        if result.data_start and result.data_end:
            days_with_data = (
                self._db.execute(
                    select(
                        func.count(func.distinct(func.date(BigQueryJob.creation_time)))
                    ).where(*self._build_query_filters(start_date, end_date, config_id))
                ).scalar_one()
                or 0
            )

        storage_summary = self.get_storage_cost_summary(config_id)

        return DashboardSummary(
            total_spend=total_spend,
            build_spend=result.build_spend or Decimal("0"),
            consumption_spend=result.consumption_spend or Decimal("0"),
            job_count=job_count,
            avg_cost_per_job=avg_cost,
            date_range_start=result.data_start,
            date_range_end=result.data_end,
            data_coverage_days=days_with_data,
            storage_monthly_cost=(
                storage_summary.total_monthly_cost if storage_summary else None
            ),
            storage_potential_savings=(
                storage_summary.total_potential_savings if storage_summary else None
            ),
            storage_latest_synced_at=(
                storage_summary.latest_synced_at if storage_summary else None
            ),
        )

    def get_summary(self, start_date: datetime, end_date: datetime) -> DashboardSummary:
        """
        Get aggregated cost summary for the date range.

        Args:
            start_date: Start of date range (inclusive)
            end_date: End of date range (inclusive)

        Returns:
            DashboardSummary with total spend, job count, and data coverage
        """
        return self._build_summary(start_date, end_date)

    def get_daily_trend(
        self, start_date: datetime, end_date: datetime, lens: str = "all"
    ) -> list[DailySpend]:
        """
        Get daily spend trend with zero-fill for missing days.

        Per FR-022: Days with no spend show zero values rather than being omitted.

        Args:
            start_date: Start of date range (inclusive)
            end_date: End of date range (inclusive)

        Returns:
            List of DailySpend objects, one per day in range
        """
        if _normalize_cost_lens(lens) == "storage":
            return []

        # Query actual daily aggregates
        result = self._db.execute(
            select(
                func.date(BigQueryJob.creation_time).label("date"),
                func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                    "total_cost"
                ),
                func.coalesce(
                    func.sum(
                        case(
                            (
                                BigQueryJob.workload_kind == WORKLOAD_KIND_BUILD,
                                BigQueryJob.total_cost,
                            ),
                            else_=Decimal("0"),
                        )
                    ),
                    Decimal("0"),
                ).label("build_cost"),
                func.coalesce(
                    func.sum(
                        case(
                            (
                                BigQueryJob.workload_kind == WORKLOAD_KIND_CONSUMPTION,
                                BigQueryJob.total_cost,
                            ),
                            else_=Decimal("0"),
                        )
                    ),
                    Decimal("0"),
                ).label("consumption_cost"),
                func.count(BigQueryJob.id).label("job_count"),
            )
            .where(*self._build_query_filters(start_date, end_date, lens=lens))
            .group_by(func.date(BigQueryJob.creation_time))
            .order_by(func.date(BigQueryJob.creation_time))
        ).all()

        # Build lookup of actual data
        data_by_date: dict[date, DailySpend] = {}
        for row in result:
            data_by_date[row.date] = DailySpend(
                date=row.date,
                total_cost=row.total_cost or Decimal("0"),
                build_cost=row.build_cost or Decimal("0"),
                consumption_cost=row.consumption_cost or Decimal("0"),
                job_count=row.job_count or 0,
            )

        # Generate complete date range with zero-fill
        trend: list[DailySpend] = []
        current = start_date.date()
        end = end_date.date()

        while current <= end:
            if current in data_by_date:
                trend.append(data_by_date[current])
            else:
                trend.append(
                    DailySpend(
                        date=current,
                        total_cost=Decimal("0"),
                        build_cost=Decimal("0"),
                        consumption_cost=Decimal("0"),
                        job_count=0,
                    )
                )
            current += timedelta(days=1)

        return trend

    def get_local_model_run_points(self) -> list[LocalModelRunPoint]:
        """Return latest local run models ordered by execution time descending."""
        records = self._build_local_model_records()
        records.sort(
            key=lambda row: (
                -(row.get("execution_time_s") or 0),
                -float(row.get("total_cost") or 0),
                row.get("model_name") or "",
            )
        )
        return [
            LocalModelRunPoint(
                model_name=row["model_name"],
                unique_id=row.get("unique_id"),
                materialization=row.get("materialization"),
                total_cost=row.get("total_cost") or Decimal("0"),
                total_bytes_billed=row.get("total_bytes_billed") or 0,
                duration_ms=row.get("duration_ms") or 0,
                execution_time_s=row.get("execution_time_s"),
                job_state=row.get("job_state") or "UNKNOWN",
            )
            for row in records
        ]

    def get_local_model_drivers(
        self,
        search_query: str = "",
        page: int = 1,
        page_size: int = 10,
        sort_by: str = "execution",
        sort_direction: str = "desc",
    ) -> tuple[list[LocalModelDriver], PaginationContext]:
        """Return local latest-run model driver rows with pagination."""
        rows = self._build_local_model_records()

        if search_query.strip():
            needle = search_query.strip().lower()
            rows = [
                row
                for row in rows
                if needle in (row.get("model_name") or "").lower()
                or needle in (row.get("config_name") or "").lower()
            ]

        sort_map = {
            "model": lambda row: (row.get("model_name") or "").lower(),
            "cost": lambda row: row.get("total_cost") or Decimal("0"),
            "bytes": lambda row: row.get("total_bytes_billed") or 0,
            "issues": lambda row: row.get("issue_count") or 0,
            "enhancements": lambda row: row.get("enhancement_count") or 0,
            "score": lambda row: row.get("score") or 0,
            "opportunity": lambda row: row.get("opportunity_count") or 0,
            "execution": lambda row: row.get("execution_time_s") or 0,
        }
        sort_key = sort_map.get(sort_by, sort_map["cost"])
        rows = sorted(rows, key=sort_key, reverse=sort_direction != "asc")

        total_items = len(rows)
        pagination = PaginationContext(
            page=page,
            page_size=page_size,
            total_items=total_items,
        )
        if total_items == 0:
            return [], pagination

        offset = (pagination.page - 1) * pagination.page_size
        page_rows = rows[offset : offset + pagination.page_size]

        return (
            [
                LocalModelDriver(
                    model_name=row["model_name"],
                    unique_id=row.get("unique_id"),
                    materialization=row.get("materialization"),
                    total_cost=row.get("total_cost") or Decimal("0"),
                    total_bytes_billed=row.get("total_bytes_billed") or 0,
                    duration_ms=row.get("duration_ms") or 0,
                    execution_time_s=row.get("execution_time_s"),
                    issue_count=row.get("issue_count") or 0,
                    enhancement_count=row.get("enhancement_count") or 0,
                    score=row.get("score") or 100,
                    opportunity_count=row.get("opportunity_count") or 0,
                    opportunity_url=row.get("opportunity_url"),
                    job_state=row.get("job_state") or "UNKNOWN",
                )
                for row in page_rows
            ],
            pagination,
        )

    def get_top_cost_drivers(
        self,
        start_date: datetime,
        end_date: datetime,
        limit: int = 5,
        lens: str = "all",
    ) -> list[CostDriver]:
        """
        Get top cost drivers ranked by actual spend.

        Per FR-030/FR-031: Aggregates at dbt model level when available,
        falls back to destination_table.

        Args:
            start_date: Start of date range (inclusive)
            end_date: End of date range (inclusive)
            limit: Maximum number of drivers to return

        Returns:
            List of CostDriver objects ranked by spend
        """
        if _normalize_cost_lens(lens) == "storage":
            return []

        # Get total spend for percentage calculation
        total_result = self._db.execute(
            select(
                func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                    "total"
                )
            ).where(*self._build_query_filters(start_date, end_date, lens=lens))
        ).scalar_one()
        total_spend = total_result or Decimal("0")

        # Query by destination_table (dbt model mapping would be an enhancement)
        result = self._db.execute(
            select(
                BigQueryJob.destination_table.label("identifier"),
                func.sum(BigQueryJob.total_cost).label("total_spend"),
                func.count(BigQueryJob.id).label("job_count"),
            )
            .where(
                *self._build_query_filters(start_date, end_date, lens=lens),
                BigQueryJob.destination_table.isnot(None),
            )
            .group_by(BigQueryJob.destination_table)
            .order_by(func.sum(BigQueryJob.total_cost).desc())
            .limit(limit)
        ).all()

        drivers: list[CostDriver] = []
        for rank, row in enumerate(result, start=1):
            spend = row.total_spend or Decimal("0")
            pct = float(spend / total_spend * 100) if total_spend > 0 else 0.0

            # Extract model name from destination_table (project.dataset.table)
            identifier = row.identifier or "Unknown"
            parts = identifier.split(".")
            display_name = parts[-1] if parts else identifier

            drivers.append(
                CostDriver(
                    rank=rank,
                    identifier=display_name,
                    identifier_type="table",
                    total_spend=spend,
                    percentage_of_total=round(pct, 1),
                    job_count=row.job_count or 0,
                    detail_url="#",  # Placeholder for future drill-down
                )
            )

        return drivers

    def get_enriched_cost_drivers(
        self,
        start_date: datetime,
        end_date: datetime,
        limit: int = 10,
        days: int | None = None,
    ) -> list[EnrichedCostDriver]:
        """Get top cost drivers enriched with project context and opportunity data.

        Groups by (config_id, destination_table) with JOIN to ManifestConfiguration
        for project names and batch query to Opportunity for counts/severity.
        """
        from sqlalchemy import tuple_

        # Step 1: Global total spend for percentage calculation
        total_result = self._db.execute(
            select(
                func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                    "total"
                )
            ).where(
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
                BigQueryJob.total_cost.isnot(None),
                *self._local_sync_filter(),
            )
        ).scalar_one()
        total_spend = total_result or Decimal("0")

        # Step 2: Cost drivers grouped by (config_id, destination_table)
        result = self._db.execute(
            select(
                BigQueryJob.config_id,
                ManifestConfiguration.name.label("config_name"),
                BigQueryJob.destination_table,
                func.sum(BigQueryJob.total_cost).label("total_spend"),
                func.count(BigQueryJob.id).label("job_count"),
            )
            .join(
                ManifestConfiguration,
                BigQueryJob.config_id == ManifestConfiguration.id,
            )
            .where(
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
                BigQueryJob.total_cost.isnot(None),
                BigQueryJob.destination_table.isnot(None),
                *self._local_sync_filter(),
            )
            .group_by(
                BigQueryJob.config_id,
                ManifestConfiguration.name,
                BigQueryJob.destination_table,
            )
            .order_by(func.sum(BigQueryJob.total_cost).desc())
            .limit(limit)
        ).all()

        if not result:
            return []

        # Step 3: Batch query for opportunity counts
        driver_pairs = [(row.config_id, row.destination_table) for row in result]

        opp_data: dict[tuple[str, str], tuple[int, int | None]] = {}
        if driver_pairs:
            opp_result = self._db.execute(
                select(
                    Opportunity.config_id,
                    Opportunity.affected_table,
                    func.count(Opportunity.id).label("opp_count"),
                    func.max(Opportunity.severity_score).label("max_severity"),
                )
                .where(
                    Opportunity.status == "active",
                    tuple_(Opportunity.config_id, Opportunity.affected_table).in_(
                        driver_pairs
                    ),
                )
                .group_by(Opportunity.config_id, Opportunity.affected_table)
            ).all()

            for opp_row in opp_result:
                opp_data[(opp_row.config_id, opp_row.affected_table)] = (
                    opp_row.opp_count,
                    opp_row.max_severity,
                )

        # Assemble EnrichedCostDriver objects
        drivers: list[EnrichedCostDriver] = []
        for rank, row in enumerate(result, start=1):
            spend = row.total_spend or Decimal("0")
            pct = float(spend / total_spend * 100) if total_spend > 0 else 0.0

            # Extract display name (last segment of qualified table name)
            table_name = row.destination_table or "Unknown"
            parts = table_name.split(".")
            display_name = parts[-1] if parts else table_name

            opp_count, max_sev = opp_data.get(
                (row.config_id, row.destination_table), (0, None)
            )

            project_url = f"/projects/{row.config_id}"
            opportunities_url = None
            if opp_count > 0:
                opportunities_url = f"/projects/{row.config_id}?opp_status=active"
                if days is not None:
                    opportunities_url += f"&days={days}"

            if days is not None:
                project_url += f"?days={days}"

            drivers.append(
                EnrichedCostDriver(
                    rank=rank,
                    config_id=row.config_id,
                    config_name=row.config_name or "Unknown",
                    table_name=table_name,
                    display_name=display_name,
                    total_spend=spend,
                    percentage_of_total=round(pct, 1),
                    job_count=row.job_count or 0,
                    opportunity_count=opp_count,
                    max_severity=max_sev,
                    project_url=project_url,
                    opportunities_url=opportunities_url,
                )
            )

        return drivers

    def get_project_breakdown(
        self, start_date: datetime, end_date: datetime
    ) -> list[ProjectBreakdown]:
        """
        Get spend breakdown by GCP project.

        Args:
            start_date: Start of date range (inclusive)
            end_date: End of date range (inclusive)

        Returns:
            List of ProjectBreakdown objects sorted by spend (highest first)
        """
        # Get total spend for percentage calculation
        total_result = self._db.execute(
            select(
                func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                    "total"
                )
            ).where(
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
                BigQueryJob.total_cost.isnot(None),
                *self._local_sync_filter(),
            )
        ).scalar_one()
        total_spend = total_result or Decimal("0")

        # Join with configurations to get project info
        result = self._db.execute(
            select(
                ManifestConfiguration.id.label("config_id"),
                ManifestConfiguration.gcp_project_id.label("project_id"),
                ManifestConfiguration.name.label("project_name"),
                func.sum(BigQueryJob.total_cost).label("total_spend"),
                func.count(BigQueryJob.id).label("job_count"),
            )
            .join(
                ManifestConfiguration,
                BigQueryJob.config_id == ManifestConfiguration.id,
            )
            .where(
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
                BigQueryJob.total_cost.isnot(None),
                *self._local_sync_filter(),
            )
            .group_by(
                ManifestConfiguration.id,
                ManifestConfiguration.gcp_project_id,
                ManifestConfiguration.name,
            )
            .order_by(func.sum(BigQueryJob.total_cost).desc())
        ).all()

        breakdown: list[ProjectBreakdown] = []
        for row in result:
            spend = row.total_spend or Decimal("0")
            pct = float(spend / total_spend * 100) if total_spend > 0 else 0.0

            breakdown.append(
                ProjectBreakdown(
                    config_id=row.config_id,
                    project_id=row.project_id or "Unknown",
                    project_name=row.project_name or row.project_id or "Unknown",
                    total_spend=spend,
                    percentage_of_total=round(pct, 1),
                    job_count=row.job_count or 0,
                    detail_url=f"/projects/{row.config_id}",
                )
            )

        return breakdown

    def get_environment_breakdown(
        self, start_date: datetime, end_date: datetime
    ) -> list[EnvironmentBreakdown]:
        """
        Get spend breakdown by environment (dev/staging/prod).

        Per FR-061/FR-063: Derived from dbt manifest target, with Unknown category
        for jobs not linked to an environment.

        Args:
            start_date: Start of date range (inclusive)
            end_date: End of date range (inclusive)

        Returns:
            List of EnvironmentBreakdown objects sorted by spend (highest first)
        """
        # Get total spend for percentage calculation
        total_result = self._db.execute(
            select(
                func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                    "total"
                )
            ).where(
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
                BigQueryJob.total_cost.isnot(None),
                *self._local_sync_filter(),
            )
        ).scalar_one()
        total_spend = total_result or Decimal("0")

        # For now, all jobs go to "Unknown" until manifest environment mapping is implemented
        job_result = self._db.execute(
            select(
                func.sum(BigQueryJob.total_cost).label("total_spend"),
                func.count(BigQueryJob.id).label("job_count"),
            ).where(
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
                BigQueryJob.total_cost.isnot(None),
                *self._local_sync_filter(),
            )
        ).one()

        breakdown: list[EnvironmentBreakdown] = []
        if job_result.job_count and job_result.job_count > 0:
            spend = job_result.total_spend or Decimal("0")
            pct = float(spend / total_spend * 100) if total_spend > 0 else 0.0

            breakdown.append(
                EnvironmentBreakdown(
                    environment="Unknown",
                    total_spend=spend,
                    percentage_of_total=round(pct, 1),
                    job_count=job_result.job_count or 0,
                )
            )

        return breakdown

    def get_opportunities_summary(
        self, start_date: datetime, end_date: datetime
    ) -> OpportunitySummary:
        """
        Get aggregated opportunity metrics with cost-at-risk.

        Per FR-074/FR-075: Cost-at-risk is actual job costs, no double-counting
        when a job is associated with multiple opportunity types.

        Args:
            start_date: Start of date range (inclusive)
            end_date: End of date range (inclusive)

        Returns:
            OpportunitySummary with cost-at-risk, issue density, and counts by type
        """
        # Get total spend for issue density calculation
        total_result = self._db.execute(
            select(
                func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                    "total"
                )
            ).where(
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
                BigQueryJob.total_cost.isnot(None),
                *self._local_sync_filter(),
            )
        ).scalar_one()
        total_spend = total_result or Decimal("0")

        # Get active opportunities and their types
        opportunities = self._db.execute(
            select(
                Opportunity.id,
                Opportunity.opportunity_type,
                Opportunity.related_job_ids,
                Opportunity.severity_score,
                Opportunity.latest_solution_dry_run_original_cost,
                Opportunity.latest_solution_dry_run_modified_cost,
                Opportunity.current_cost_estimate,
                Opportunity.expected_savings,
                Opportunity.occurrence_count,
            ).where(Opportunity.status == "active")
        ).all()

        if not opportunities:
            return OpportunitySummary(
                cost_at_risk=Decimal("0"),
                potential_savings=Decimal("0"),
                issue_density=0.0,
                total_opportunities=0,
                critical_count=0,
                by_type={},
                detail_url="/opportunities",
            )

        active_solution_job_status_map = get_active_solution_job_statuses(
            self._db,
            _extract_opportunity_ids(opportunities),
        )

        # Collect unique job IDs (no double-counting)
        affected_job_ids: set[str] = set()
        by_type: dict[str, int] = {}
        by_type_detail: dict[str, dict] = {}
        critical_count = 0
        potential_savings = Decimal("0")

        for opp in opportunities:
            opp_type = opp.opportunity_type
            by_type[opp_type] = by_type.get(opp_type, 0) + 1

            # Aggregate per-type detail
            if opp_type not in by_type_detail:
                by_type_detail[opp_type] = {
                    "count": 0,
                    "total_cost": Decimal("0"),
                    "estimated_savings": Decimal("0"),
                }
            by_type_detail[opp_type]["count"] += 1
            occ = _coerce_occurrence_count(getattr(opp, "occurrence_count", None))
            current_cost_estimate = _coerce_decimal(
                getattr(opp, "current_cost_estimate", None)
            )
            if current_cost_estimate is not None:
                by_type_detail[opp_type]["total_cost"] += current_cost_estimate / occ
            expected_savings = _coerce_decimal(getattr(opp, "expected_savings", None))
            if expected_savings is not None and active_solution_job_status_map.get(
                getattr(opp, "id", None)
            ) not in ("queued", "in_progress"):
                by_type_detail[opp_type]["estimated_savings"] += expected_savings / occ

            if opp.severity_score is not None and opp.severity_score >= 70:
                critical_count += 1

            if (
                opp.latest_solution_dry_run_original_cost is not None
                and opp.latest_solution_dry_run_modified_cost is not None
                and opp.latest_solution_dry_run_original_cost
                > opp.latest_solution_dry_run_modified_cost
            ):
                potential_savings += (
                    opp.latest_solution_dry_run_original_cost
                    - opp.latest_solution_dry_run_modified_cost
                )

            # related_job_ids is a JSONB array of job_id strings
            if opp.related_job_ids:
                for job_id in opp.related_job_ids:
                    affected_job_ids.add(job_id)

        # Calculate cost-at-risk from affected jobs
        cost_at_risk = Decimal("0")
        if affected_job_ids:
            cost_result = self._db.execute(
                select(
                    func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                        "cost"
                    )
                ).where(
                    BigQueryJob.job_id.in_(affected_job_ids),
                    BigQueryJob.creation_time >= start_date,
                    BigQueryJob.creation_time <= end_date,
                    BigQueryJob.total_cost.isnot(None),
                    *self._local_sync_filter(),
                )
            ).scalar_one()
            cost_at_risk = cost_result or Decimal("0")

        # Calculate issue density
        issue_density = 0.0
        if total_spend > 0:
            issue_density = float(cost_at_risk / total_spend * 100)

        return OpportunitySummary(
            cost_at_risk=cost_at_risk,
            potential_savings=potential_savings,
            issue_density=round(issue_density, 1),
            total_opportunities=len(opportunities),
            critical_count=critical_count,
            by_type=by_type,
            by_type_detail=by_type_detail,
            detail_url="/opportunities",
        )

    def get_active_config_count(self) -> int:
        """Count manifest configurations with status 'active'."""
        result = self._db.execute(
            select(func.count(ManifestConfiguration.id)).where(
                ManifestConfiguration.status == "active"
            )
        ).scalar_one()
        return result or 0

    def get_total_process_costs(self) -> Decimal:
        """Sum LLM process costs recorded across all opportunities."""
        result = self._db.execute(
            select(
                func.coalesce(func.sum(Opportunity.process_cost_usd), Decimal("0"))
            ).where(Opportunity.process_cost_usd.isnot(None))
        ).scalar_one()
        return result or Decimal("0")

    def get_clearing_savings(self) -> Decimal:
        """Sum expected_savings for opportunities currently in clearing state."""
        result = self._db.execute(
            select(
                func.coalesce(func.sum(Opportunity.expected_savings), Decimal("0"))
            ).where(Opportunity.status == "clearing")
        ).scalar_one()
        return result or Decimal("0")

    def get_total_verified_savings(self) -> Decimal:
        """Sum verified dry-run savings from all active opportunities."""
        result = self._db.execute(
            select(
                func.coalesce(func.sum(self._verified_savings_expr()), Decimal("0"))
            ).where(Opportunity.status == "active")
        ).scalar_one()
        return result or Decimal("0")

    def get_total_possible_savings(self) -> Decimal:
        """Sum heuristic possible savings for active eligible opportunities."""
        opportunities = self._db.execute(
            select(
                Opportunity.expected_savings,
                Opportunity.occurrence_count,
            )
            .select_from(Opportunity)
            .outerjoin(
                SolutionJob,
                and_(
                    SolutionJob.opportunity_id == Opportunity.id,
                    SolutionJob.status.in_(("queued", "in_progress")),
                ),
            )
            .where(
                Opportunity.status == "active",
                Opportunity.opportunity_type.in_(_POSSIBLE_SAVINGS_RULE_TYPES),
                Opportunity.expected_savings.isnot(None),
                Opportunity.expected_savings > 0,
                Opportunity.latest_solution_dry_run_modified_cost.is_(None),
                SolutionJob.id.is_(None),
            )
        ).all()
        if not opportunities:
            return Decimal("0")

        total = Decimal("0")
        for expected_savings, occurrence_count in opportunities:
            occ = _coerce_occurrence_count(occurrence_count)
            total += (expected_savings or Decimal("0")) / Decimal(str(occ))
        return total

    def get_total_estimated_savings(self) -> Decimal:
        """Backward-compatible alias for verified savings."""
        return self.get_total_verified_savings()

    def get_savings_for_date_range(
        self, start_date: datetime, end_date: datetime
    ) -> tuple[Decimal, Decimal]:
        """Compute period savings for active opportunities in the selected range."""
        opps = (
            self._db.execute(select(Opportunity).where(Opportunity.status == "active"))
            .scalars()
            .all()
        )

        if not opps:
            return Decimal("0"), Decimal("0")

        opportunity_ids = _extract_opportunity_ids(opps)
        latest_solution_map = get_latest_solution_snapshots(self._db, opportunity_ids)
        active_solution_job_status_map = get_active_solution_job_statuses(
            self._db, opportunity_ids
        )
        historical = calculate_historical_possible_savings(
            self._db,
            opps,
            start_date=start_date,
            end_date=end_date,
        )

        # Collect all related job IDs across opportunities
        all_job_ids: list[str] = []
        opp_job_map: dict[str, list[str]] = {}
        for opp in opps:
            job_ids = opp.related_job_ids or []
            if job_ids:
                opp_job_map[opp.id] = job_ids
                all_job_ids.extend(job_ids)

        # Count jobs per ID that ran in date range
        job_in_range: set[str] = set()
        if all_job_ids:
            rows = self._db.execute(
                select(BigQueryJob.job_id).where(
                    BigQueryJob.job_id.in_(all_job_ids),
                    BigQueryJob.creation_time >= start_date,
                    BigQueryJob.creation_time <= end_date,
                    *self._local_sync_filter(),
                )
            ).all()
            job_in_range = {r.job_id for r in rows}

        estimated_total = Decimal("0")
        verified_total = Decimal("0")
        # Deduplicate by table: keep highest estimated savings per table
        best_estimated_per_table: dict[str, Decimal] = {}

        for opp in opps:
            latest_solution = latest_solution_map.get(opp.id, {})
            if active_solution_job_status_map.get(opp.id) in ("queued", "in_progress"):
                continue
            prefers_possible_savings_display = latest_solution.get(
                "prefers_possible_savings_display",
                False,
            )
            dry_run_original_cost = latest_solution.get("dry_run_original_cost")
            dry_run_modified_cost = latest_solution.get("dry_run_modified_cost")

            opp_estimated = Decimal("0")
            if historical.has_history(opp.id):
                if opp.opportunity_type in _POSSIBLE_SAVINGS_RULE_TYPES and (
                    prefers_possible_savings_display or dry_run_modified_cost is None
                ):
                    opp_estimated = historical.savings_for(opp.id)
            else:
                # Fallback for legacy rows that lack reconstructable history.
                opp_jobs = opp_job_map.get(opp.id, [])
                runs_in_range = sum(1 for jid in opp_jobs if jid in job_in_range)
                if runs_in_range > 0 and (
                    opp.expected_savings
                    and opp.expected_savings > 0
                    and opp.opportunity_type in _POSSIBLE_SAVINGS_RULE_TYPES
                    and (
                        prefers_possible_savings_display
                        or dry_run_modified_cost is None
                    )
                ):
                    occ = max(opp.occurrence_count or 1, 1)
                    per_run = opp.expected_savings / Decimal(str(occ))
                    opp_estimated = per_run * runs_in_range

            # Deduplicate: keep highest estimated savings per table
            table_key = opp.affected_table
            current_best = best_estimated_per_table.get(table_key, Decimal("0"))
            if opp_estimated > current_best:
                best_estimated_per_table[table_key] = opp_estimated

            # Count how many of this opportunity's related jobs ran in range
            opp_jobs = opp_job_map.get(opp.id, [])
            runs_in_range = sum(1 for jid in opp_jobs if jid in job_in_range)
            if runs_in_range == 0:
                continue

            # Verified savings (dry-run, already per run), net of process cost
            if (
                not prefers_possible_savings_display
                and dry_run_original_cost is not None
                and dry_run_modified_cost is not None
                and dry_run_original_cost > dry_run_modified_cost
            ):
                per_run = dry_run_original_cost - dry_run_modified_cost
                gross = per_run * runs_in_range
                process_cost = opp.process_cost_usd or Decimal("0")
                verified_total += max(Decimal("0"), gross - process_cost)

        estimated_total = sum(best_estimated_per_table.values(), Decimal("0"))
        return estimated_total, verified_total

    def get_opportunity_type_summary(
        self, start_date: datetime, end_date: datetime
    ) -> list[dict]:
        """Per-type opportunity summary with period-based cost and savings.

        Returns a list of dicts sorted by total_cost descending, each containing:
        type_key, label, count, total_cost, estimated_savings, verified_savings.
        """
        opps = (
            self._db.execute(select(Opportunity).where(Opportunity.status == "active"))
            .scalars()
            .all()
        )

        if not opps:
            return []

        opportunity_ids = _extract_opportunity_ids(opps)
        latest_solution_map = get_latest_solution_snapshots(self._db, opportunity_ids)
        active_solution_job_status_map = get_active_solution_job_statuses(
            self._db, opportunity_ids
        )
        historical = calculate_historical_possible_savings(
            self._db,
            opps,
            start_date=start_date,
            end_date=end_date,
        )

        # Collect all job IDs
        all_job_ids: list[str] = []
        opp_job_map: dict[str, list[str]] = {}
        for opp in opps:
            job_ids = opp.related_job_ids or []
            if job_ids:
                opp_job_map[opp.id] = job_ids
                all_job_ids.extend(job_ids)

        # Get job costs in date range
        job_costs: dict[str, Decimal] = {}
        if all_job_ids:
            rows = self._db.execute(
                select(BigQueryJob.job_id, BigQueryJob.total_cost).where(
                    BigQueryJob.job_id.in_(all_job_ids),
                    BigQueryJob.creation_time >= start_date,
                    BigQueryJob.creation_time <= end_date,
                    BigQueryJob.total_cost.isnot(None),
                    *self._local_sync_filter(),
                )
            ).all()
            for r in rows:
                job_costs[r.job_id] = r.total_cost or Decimal("0")

        # Aggregate per type
        type_data: dict[str, dict] = {}
        for opp in opps:
            t = opp.opportunity_type
            if t not in type_data:
                type_data[t] = {
                    "type_key": t,
                    "label": t.replace("_", " "),
                    "count": 0,
                    "total_cost": Decimal("0"),
                    "estimated_savings": Decimal("0"),
                    "verified_savings": Decimal("0"),
                }
            type_data[t]["count"] += 1

            latest_solution = latest_solution_map.get(opp.id, {})
            if active_solution_job_status_map.get(opp.id) in ("queued", "in_progress"):
                continue
            prefers_possible_savings_display = latest_solution.get(
                "prefers_possible_savings_display",
                False,
            )
            dry_run_original_cost = latest_solution.get("dry_run_original_cost")
            dry_run_modified_cost = latest_solution.get("dry_run_modified_cost")

            if historical.has_history(opp.id):
                type_data[t]["total_cost"] += historical.cost_for(opp.id)
                if opp.opportunity_type in _POSSIBLE_SAVINGS_RULE_TYPES and (
                    prefers_possible_savings_display or dry_run_modified_cost is None
                ):
                    type_data[t]["estimated_savings"] += historical.savings_for(opp.id)
            else:
                opp_jobs = opp_job_map.get(opp.id, [])
                for jid in opp_jobs:
                    if jid in job_costs:
                        type_data[t]["total_cost"] += job_costs[jid]

                runs_in_range = sum(1 for jid in opp_jobs if jid in job_costs)
                if runs_in_range > 0 and (
                    opp.expected_savings
                    and opp.expected_savings > 0
                    and opp.opportunity_type in _POSSIBLE_SAVINGS_RULE_TYPES
                    and (
                        prefers_possible_savings_display
                        or dry_run_modified_cost is None
                    )
                ):
                    occ = max(opp.occurrence_count or 1, 1)
                    per_run = opp.expected_savings / Decimal(str(occ))
                    type_data[t]["estimated_savings"] += per_run * runs_in_range

            opp_jobs = opp_job_map.get(opp.id, [])
            runs_in_range = sum(1 for jid in opp_jobs if jid in job_costs)
            if runs_in_range == 0:
                continue

            if (
                not prefers_possible_savings_display
                and dry_run_original_cost is not None
                and dry_run_modified_cost is not None
                and dry_run_original_cost > dry_run_modified_cost
            ):
                gross = (dry_run_original_cost - dry_run_modified_cost) * runs_in_range
                process_cost = opp.process_cost_usd or Decimal("0")
                type_data[t]["verified_savings"] += max(
                    Decimal("0"), gross - process_cost
                )

        result = sorted(
            type_data.values(),
            key=lambda d: (-float(d["total_cost"]), -d["count"]),
        )
        # Convert Decimals to float for template
        for d in result:
            d["total_cost"] = float(d["total_cost"])
            d["estimated_savings"] = float(d["estimated_savings"])
            d["verified_savings"] = float(d["verified_savings"])
        return result

    def _get_storage_project_drivers(
        self,
        search_query: str = "",
        page: int = 1,
        page_size: int = 20,
        sort_by: str = "spend",
        sort_direction: str = "desc",
    ) -> tuple[list[ProjectDriver], PaginationContext]:
        search_filters = []
        if search_query.strip():
            escaped = (
                search_query.replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_")
            )
            search_filters.append(ManifestConfiguration.name.ilike(f"%{escaped}%"))

        config_rows = self._db.execute(
            select(
                ManifestConfiguration.id,
                ManifestConfiguration.name,
            )
            .join(
                TableStorageMetric,
                TableStorageMetric.config_id == ManifestConfiguration.id,
            )
            .where(*search_filters)
            .group_by(ManifestConfiguration.id, ManifestConfiguration.name)
        ).all()

        storage_opp_counts = {
            row.config_id: row.opp_count
            for row in self._db.execute(
                select(
                    Opportunity.config_id,
                    func.count(Opportunity.id).label("opp_count"),
                )
                .where(
                    Opportunity.status == "active",
                    Opportunity.opportunity_type == "storage_billing_optimization",
                )
                .group_by(Opportunity.config_id)
            ).all()
        }

        drivers: list[ProjectDriver] = []
        for row in config_rows:
            storage_summary = self.get_storage_cost_summary(row.id)
            if not storage_summary:
                continue

            drivers.append(
                ProjectDriver(
                    config_id=row.id,
                    config_name=row.name or "Unknown",
                    total_spend=storage_summary.total_monthly_cost,
                    unique_job_count=storage_summary.dataset_count,
                    opportunity_count=storage_opp_counts.get(row.id, 0),
                    potential_savings=storage_summary.total_potential_savings,
                    project_url=f"/projects/{row.id}?lens=storage",
                    storage_latest_synced_at=storage_summary.latest_synced_at,
                    storage_dataset_count=storage_summary.dataset_count,
                    storage_logical_bytes=storage_summary.total_logical_bytes,
                    storage_physical_bytes=storage_summary.total_physical_bytes,
                )
            )

        total_items = len(drivers)
        pagination = PaginationContext(
            page=page, page_size=page_size, total_items=total_items
        )
        if total_items == 0:
            return [], pagination

        total_spend = sum((driver.total_spend for driver in drivers), Decimal("0"))
        for driver in drivers:
            if total_spend > 0:
                driver.percentage_of_total = round(
                    float(driver.total_spend / total_spend * 100), 1
                )

        sort_map = {
            "project": lambda d: d.config_name.lower(),
            "spend": lambda d: d.total_spend,
            "jobs": lambda d: d.storage_dataset_count,
            "slots": lambda d: d.storage_physical_bytes,
            "data": lambda d: d.storage_logical_bytes,
            "duration": lambda d: (
                d.storage_latest_synced_at.timestamp()
                if d.storage_latest_synced_at
                else 0
            ),
            "opportunities": lambda d: d.opportunity_count,
            "savings": lambda d: d.potential_savings,
        }
        sort_key = sort_map.get(sort_by, sort_map["spend"])
        drivers = sorted(
            drivers,
            key=sort_key,
            reverse=sort_direction != "asc",
        )

        offset = (pagination.page - 1) * pagination.page_size
        return drivers[offset : offset + pagination.page_size], pagination

    def get_project_drivers(
        self,
        start_date: datetime,
        end_date: datetime,
        search_query: str = "",
        page: int = 1,
        page_size: int = 20,
        sort_by: str = "spend",
        sort_direction: str = "desc",
        lens: str = "all",
    ) -> tuple[list[ProjectDriver], PaginationContext]:
        """Get project-level cost drivers with pagination.

        Groups BigQueryJob data by config_id (ManifestConfiguration) and
        enriches with opportunity counts and potential savings.
        """
        if _normalize_cost_lens(lens) == "storage":
            return self._get_storage_project_drivers(
                search_query=search_query,
                page=page,
                page_size=page_size,
                sort_by=sort_by,
                sort_direction=sort_direction,
            )

        # Base filters
        base_filters = self._build_query_filters(start_date, end_date, lens=lens)

        # Search filter on config name
        search_filters = []
        if search_query.strip():
            escaped = (
                search_query.replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_")
            )
            search_filters.append(ManifestConfiguration.name.ilike(f"%{escaped}%"))

        # Count query: distinct config_ids matching filters
        count_query = (
            select(func.count(func.distinct(BigQueryJob.config_id)))
            .join(
                ManifestConfiguration,
                BigQueryJob.config_id == ManifestConfiguration.id,
            )
            .where(*base_filters, *search_filters)
        )
        total_items = self._db.execute(count_query).scalar_one() or 0

        pagination = PaginationContext(
            page=page, page_size=page_size, total_items=total_items
        )

        if total_items == 0:
            return [], pagination

        # Validate sort params
        if sort_by not in (
            "project",
            "spend",
            "jobs",
            "slots",
            "data",
            "duration",
            "opportunities",
            "savings",
        ):
            sort_by = "spend"
        if sort_direction not in ("asc", "desc"):
            sort_direction = "desc"

        # Opportunity subquery for sorting by opportunities/savings
        opp_subquery = (
            select(
                Opportunity.config_id.label("opp_config_id"),
                func.count(Opportunity.id).label("opp_count"),
                func.coalesce(
                    func.sum(self._verified_savings_expr()), Decimal("0")
                ).label("opp_savings"),
            )
            .where(Opportunity.status == "active")
            .group_by(Opportunity.config_id)
            .subquery()
        )

        # Data query: grouped aggregation with opportunity LEFT JOIN
        offset = (page - 1) * page_size
        data_query = (
            select(
                BigQueryJob.config_id,
                ManifestConfiguration.name.label("config_name"),
                func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                    "total_spend"
                ),
                func.count(func.distinct(BigQueryJob.job_id)).label("unique_job_count"),
                func.coalesce(func.sum(BigQueryJob.total_slot_ms), 0).label(
                    "total_slot_ms"
                ),
                func.coalesce(func.sum(BigQueryJob.total_bytes_billed), 0).label(
                    "total_bytes_billed"
                ),
                func.coalesce(func.sum(BigQueryJob.duration_ms), 0).label(
                    "total_duration_ms"
                ),
                func.coalesce(opp_subquery.c.opp_count, literal(0)).label(
                    "opp_count_col"
                ),
                func.coalesce(opp_subquery.c.opp_savings, literal(Decimal("0"))).label(
                    "opp_savings_col"
                ),
            )
            .join(
                ManifestConfiguration,
                BigQueryJob.config_id == ManifestConfiguration.id,
            )
            .outerjoin(
                opp_subquery,
                BigQueryJob.config_id == opp_subquery.c.opp_config_id,
            )
            .where(*base_filters, *search_filters)
            .group_by(
                BigQueryJob.config_id,
                ManifestConfiguration.name,
                opp_subquery.c.opp_count,
                opp_subquery.c.opp_savings,
            )
        )

        # Map sort keys to expressions
        sort_map = {
            "project": ManifestConfiguration.name,
            "spend": func.sum(BigQueryJob.total_cost),
            "jobs": func.count(func.distinct(BigQueryJob.job_id)),
            "slots": func.sum(BigQueryJob.total_slot_ms),
            "data": func.sum(BigQueryJob.total_bytes_billed),
            "duration": func.sum(BigQueryJob.duration_ms),
            "opportunities": func.coalesce(opp_subquery.c.opp_count, literal(0)),
            "savings": func.coalesce(opp_subquery.c.opp_savings, literal(Decimal("0"))),
        }
        sort_expr = sort_map.get(sort_by, func.sum(BigQueryJob.total_cost))
        if sort_direction == "asc":
            data_query = data_query.order_by(sort_expr.asc())
        else:
            data_query = data_query.order_by(sort_expr.desc())

        data_query = data_query.limit(page_size).offset(offset)
        rows = self._db.execute(data_query).all()

        if not rows:
            return [], pagination

        # Global total spend for percentage calculation
        total_spend_result = self._db.execute(
            select(func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0"))).where(
                *base_filters
            )
        ).scalar_one()
        total_spend = total_spend_result or Decimal("0")

        # Build ProjectDriver objects — opportunity data comes from the JOIN
        drivers: list[ProjectDriver] = []
        for row in rows:
            spend = row.total_spend or Decimal("0")
            pct = float(spend / total_spend * 100) if total_spend > 0 else 0.0
            opp_count = row.opp_count_col or 0
            savings = row.opp_savings_col or Decimal("0")

            drivers.append(
                ProjectDriver(
                    config_id=row.config_id,
                    config_name=row.config_name or "Unknown",
                    total_spend=spend,
                    percentage_of_total=round(pct, 1),
                    unique_job_count=row.unique_job_count or 0,
                    total_slot_ms=row.total_slot_ms or 0,
                    total_bytes_billed=row.total_bytes_billed or 0,
                    total_duration_ms=row.total_duration_ms or 0,
                    opportunity_count=opp_count,
                    potential_savings=savings,
                    project_url=f"/projects/{row.config_id}",
                )
            )

        return drivers, pagination

    # ------------------------------------------------------------------
    # Config-scoped methods for project detail views (spec 008)
    # ------------------------------------------------------------------

    def get_project_summary(
        self, config_id: str, start_date: datetime, end_date: datetime
    ) -> DashboardSummary:
        """Get cost summary scoped to a single configuration."""
        return self._build_summary(start_date, end_date, config_id=config_id)

    def get_project_daily_stats(
        self,
        config_id: str | None,
        start_date: datetime,
        end_date: datetime,
        lens: str = "all",
    ) -> list[DailyProjectStats]:
        """Get daily stats (cost, jobs, bytes, slots).

        When *config_id* is provided the results are scoped to that single
        configuration.  When ``None``, all configurations are aggregated.
        """
        if _normalize_cost_lens(lens) == "storage":
            return []

        query = select(
            func.date(BigQueryJob.creation_time).label("date"),
            func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0")).label(
                "total_cost"
            ),
            func.coalesce(
                func.sum(
                    case(
                        (
                            BigQueryJob.workload_kind == WORKLOAD_KIND_BUILD,
                            BigQueryJob.total_cost,
                        ),
                        else_=Decimal("0"),
                    )
                ),
                Decimal("0"),
            ).label("build_cost"),
            func.coalesce(
                func.sum(
                    case(
                        (
                            BigQueryJob.workload_kind == WORKLOAD_KIND_CONSUMPTION,
                            BigQueryJob.total_cost,
                        ),
                        else_=Decimal("0"),
                    )
                ),
                Decimal("0"),
            ).label("consumption_cost"),
            func.count(BigQueryJob.id).label("job_count"),
            func.coalesce(func.sum(BigQueryJob.total_bytes_billed), 0).label(
                "total_bytes_billed"
            ),
            func.coalesce(func.sum(BigQueryJob.total_slot_ms), 0).label(
                "total_slot_ms"
            ),
        ).where(*self._build_query_filters(start_date, end_date, config_id, lens))
        query = query.group_by(func.date(BigQueryJob.creation_time)).order_by(
            func.date(BigQueryJob.creation_time)
        )

        result = self._db.execute(query).all()

        data_by_date: dict[date, DailyProjectStats] = {}
        for row in result:
            data_by_date[row.date] = DailyProjectStats(
                date=row.date,
                total_cost=row.total_cost or Decimal("0"),
                build_cost=row.build_cost or Decimal("0"),
                consumption_cost=row.consumption_cost or Decimal("0"),
                job_count=row.job_count or 0,
                total_bytes_billed=row.total_bytes_billed or 0,
                total_slot_ms=row.total_slot_ms or 0,
            )

        stats: list[DailyProjectStats] = []
        current = start_date.date()
        end = end_date.date()
        while current <= end:
            if current in data_by_date:
                stats.append(data_by_date[current])
            else:
                stats.append(
                    DailyProjectStats(
                        date=current,
                        total_cost=Decimal("0"),
                        build_cost=Decimal("0"),
                        consumption_cost=Decimal("0"),
                        job_count=0,
                        total_bytes_billed=0,
                        total_slot_ms=0,
                    )
                )
            current += timedelta(days=1)

        return stats

    def get_project_health(
        self, config_id: str, start_date: datetime, end_date: datetime
    ) -> ProjectHealthScore:
        """Calculate health score for a project based on active opportunities."""
        from app.dashboard.health import calculate_health_score, get_status

        # Get active opportunities for this config
        opp_rows = self._db.execute(
            select(
                Opportunity.id,
                Opportunity.severity_score,
                Opportunity.current_cost_estimate,
                Opportunity.manifest_version_id,
            ).where(
                Opportunity.config_id == config_id,
                Opportunity.status == "active",
            )
        ).all()

        # Get total spend for cost-at-risk ratio
        total_spend_result = self._db.execute(
            select(func.coalesce(func.sum(BigQueryJob.total_cost), Decimal("0"))).where(
                BigQueryJob.config_id == config_id,
                BigQueryJob.creation_time >= start_date,
                BigQueryJob.creation_time <= end_date,
                BigQueryJob.total_cost.isnot(None),
                *self._local_sync_filter(config_id),
            )
        ).scalar_one()
        total_spend = total_spend_result or Decimal("0")

        if not opp_rows:
            return ProjectHealthScore(
                config_id=config_id,
                overall_score=100,
                overall_status="good",
                manifest_scores=[],
                total_opportunities=0,
                cost_at_risk=Decimal("0"),
                total_spend=total_spend,
            )

        # Build opportunity dicts and aggregate cost-at-risk
        opp_dicts = [{"severity_score": r.severity_score} for r in opp_rows]
        cost_at_risk = sum((r.current_cost_estimate or Decimal("0")) for r in opp_rows)

        # Overall score
        overall_score = calculate_health_score(opp_dicts, cost_at_risk, total_spend)
        overall_status = get_status(overall_score)

        # Per-manifest breakdown
        by_manifest: dict[str | None, list] = {}
        for r in opp_rows:
            by_manifest.setdefault(r.manifest_version_id, []).append(r)

        manifest_scores: list[ManifestHealthScore] = []
        for mv_id, opps in by_manifest.items():
            m_opp_dicts = [{"severity_score": o.severity_score} for o in opps]
            m_cost = sum((o.current_cost_estimate or Decimal("0")) for o in opps)
            m_score = calculate_health_score(m_opp_dicts, m_cost, total_spend)
            critical_count = sum(1 for o in opps if o.severity_score >= 70)
            avg_sev = sum(o.severity_score for o in opps) / len(opps)

            # Get manifest hash
            m_hash = "unknown"
            if mv_id:
                mv_row = self._db.execute(
                    select(ManifestVersion.content_hash).where(
                        ManifestVersion.id == mv_id
                    )
                ).scalar_one_or_none()
                if mv_row:
                    m_hash = mv_row[:12]

            manifest_scores.append(
                ManifestHealthScore(
                    manifest_version_id=mv_id or "unlinked",
                    manifest_hash=m_hash,
                    score=m_score,
                    status=get_status(m_score),
                    opportunity_count=len(opps),
                    critical_count=critical_count,
                    avg_severity=round(avg_sev, 1),
                )
            )

        return ProjectHealthScore(
            config_id=config_id,
            overall_score=overall_score,
            overall_status=overall_status,
            manifest_scores=manifest_scores,
            total_opportunities=len(opp_rows),
            cost_at_risk=cost_at_risk,
            total_spend=total_spend,
        )

    def _get_manifest_table_set(self, config_id: str) -> set[tuple[str, str]] | None:
        """Build a set of (dataset_name, table_name) tuples from the latest manifest.

        Returns None if no manifest is available (meaning no filtering should apply).
        """
        latest_mv = (
            self._db.query(ManifestVersion)
            .filter(ManifestVersion.config_id == config_id)
            .order_by(ManifestVersion.retrieved_at.desc())
            .first()
        )
        if not latest_mv or not latest_mv.content:
            return None

        manifest_tables: set[tuple[str, str]] = set()
        nodes = latest_mv.content.get("nodes", {})
        for node_id, node in nodes.items():
            if not node_id.startswith("model."):
                continue
            schema = node.get("schema", "")
            identifier = node.get("identifier") or node.get("name", "")
            if schema and identifier:
                manifest_tables.add((schema.lower(), identifier.lower()))
        return manifest_tables if manifest_tables else None

    def get_storage_cost_summary(
        self, config_id: str | None = None
    ) -> StorageSummary | None:
        """Get storage cost breakdown for a project, aggregated by dataset.

        Queries TableStorageMetric records, filters to manifest tables,
        groups by dataset, and returns a StorageSummary or None if no
        matching metrics exist.
        """
        from collections import defaultdict

        from app.opportunities.rules.storage_pricing import (
            BYTES_PER_GB,
            LOGICAL_ACTIVE_PRICE_PER_GB,
            LOGICAL_LONG_TERM_PRICE_PER_GB,
            PHYSICAL_ACTIVE_PRICE_PER_GB,
            PHYSICAL_FAIL_SAFE_PRICE_PER_GB,
            PHYSICAL_LONG_TERM_PRICE_PER_GB,
            PHYSICAL_TIME_TRAVEL_PRICE_PER_GB,
        )

        metrics_query = self._db.query(TableStorageMetric)
        if config_id is not None:
            metrics_query = metrics_query.filter(
                TableStorageMetric.config_id == config_id
            )
        metrics = metrics_query.all()

        if not metrics:
            return None

        filtered_metrics: list[TableStorageMetric] = []
        metrics_by_config: dict[str, list[TableStorageMetric]] = {}
        for metric in metrics:
            metrics_by_config.setdefault(metric.config_id, []).append(metric)

        for metric_config_id, config_metrics in metrics_by_config.items():
            manifest_tables = self._get_manifest_table_set(metric_config_id)
            if manifest_tables is None:
                filtered_metrics.extend(config_metrics)
                continue

            filtered_metrics.extend(
                [
                    metric
                    for metric in config_metrics
                    if (metric.dataset_name.lower(), metric.table_name.lower())
                    in manifest_tables
                ]
            )

        if not filtered_metrics:
            return None

        # Group by dataset
        dataset_groups: dict[str, list] = defaultdict(list)
        latest_synced_at = None
        for metric in filtered_metrics:
            dataset_key = metric.dataset_name
            if config_id is None:
                dataset_key = f"{metric.project_id}.{metric.dataset_name}"
            dataset_groups[dataset_key].append(metric)
            if latest_synced_at is None or (
                metric.synced_at and metric.synced_at > latest_synced_at
            ):
                latest_synced_at = metric.synced_at

        datasets: list[DatasetStorageSummary] = []
        total_monthly_cost = Decimal("0")
        total_potential_savings = Decimal("0")
        total_logical = 0
        total_physical = 0

        for dataset_name in sorted(dataset_groups.keys()):
            ds_metrics = dataset_groups[dataset_name]
            # All tables in a dataset share the same billing model
            billing_model = ds_metrics[0].billing_model or "LOGICAL"

            # Aggregate byte totals across all tables in dataset
            ds_logical = sum(m.total_logical_bytes or 0 for m in ds_metrics)
            ds_physical = sum(m.total_physical_bytes or 0 for m in ds_metrics)
            active_logical = sum(m.active_logical_bytes or 0 for m in ds_metrics)
            lt_logical = sum(m.long_term_logical_bytes or 0 for m in ds_metrics)
            active_physical = sum(m.active_physical_bytes or 0 for m in ds_metrics)
            lt_physical = sum(m.long_term_physical_bytes or 0 for m in ds_metrics)
            tt_physical = sum(m.time_travel_physical_bytes or 0 for m in ds_metrics)
            fs_physical = sum(m.fail_safe_physical_bytes or 0 for m in ds_metrics)

            compression = round(ds_logical / ds_physical, 2) if ds_physical > 0 else 0.0

            # Calculate current monthly cost
            if billing_model == "PHYSICAL":
                monthly_cost = (
                    Decimal(str(active_physical))
                    / BYTES_PER_GB
                    * PHYSICAL_ACTIVE_PRICE_PER_GB
                    + Decimal(str(lt_physical))
                    / BYTES_PER_GB
                    * PHYSICAL_LONG_TERM_PRICE_PER_GB
                    + Decimal(str(tt_physical))
                    / BYTES_PER_GB
                    * PHYSICAL_TIME_TRAVEL_PRICE_PER_GB
                    + Decimal(str(fs_physical))
                    / BYTES_PER_GB
                    * PHYSICAL_FAIL_SAFE_PRICE_PER_GB
                )
            else:
                monthly_cost = (
                    Decimal(str(active_logical))
                    / BYTES_PER_GB
                    * LOGICAL_ACTIVE_PRICE_PER_GB
                    + Decimal(str(lt_logical))
                    / BYTES_PER_GB
                    * LOGICAL_LONG_TERM_PRICE_PER_GB
                )

            # Calculate potential savings
            logical_cost = (
                Decimal(str(active_logical))
                / BYTES_PER_GB
                * LOGICAL_ACTIVE_PRICE_PER_GB
                + Decimal(str(lt_logical))
                / BYTES_PER_GB
                * LOGICAL_LONG_TERM_PRICE_PER_GB
            )
            physical_cost = (
                Decimal(str(active_physical))
                / BYTES_PER_GB
                * PHYSICAL_ACTIVE_PRICE_PER_GB
                + Decimal(str(lt_physical))
                / BYTES_PER_GB
                * PHYSICAL_LONG_TERM_PRICE_PER_GB
                + Decimal(str(tt_physical))
                / BYTES_PER_GB
                * PHYSICAL_TIME_TRAVEL_PRICE_PER_GB
                + Decimal(str(fs_physical))
                / BYTES_PER_GB
                * PHYSICAL_FAIL_SAFE_PRICE_PER_GB
            )
            savings = (
                max(logical_cost - physical_cost, Decimal("0"))
                if billing_model == "LOGICAL"
                else Decimal("0")
            )

            monthly_cost = round(monthly_cost, 2)
            savings = round(savings, 2)

            datasets.append(
                DatasetStorageSummary(
                    dataset_name=dataset_name,
                    billing_model=billing_model,
                    table_count=len(ds_metrics),
                    total_logical_bytes=ds_logical,
                    total_physical_bytes=ds_physical,
                    compression_ratio=compression,
                    monthly_cost=monthly_cost,
                    potential_savings=savings,
                )
            )

            total_monthly_cost += monthly_cost
            total_potential_savings += savings
            total_logical += ds_logical
            total_physical += ds_physical

        return StorageSummary(
            total_monthly_cost=total_monthly_cost,
            total_potential_savings=total_potential_savings,
            dataset_count=len(datasets),
            total_logical_bytes=total_logical,
            total_physical_bytes=total_physical,
            latest_synced_at=latest_synced_at,
            datasets=datasets,
        )
