import json
from pathlib import Path

from searchbox import BM25Retriever, SqliteDocumentRepository, docsearch


def _write_simple_pdf(path: Path, text: str) -> None:
    stream = f"BT /F1 18 Tf 72 720 Td ({text}) Tj ET"
    objects = [
        "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n",
        "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n",
        (
            "3 0 obj\n"
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
            "/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\n"
            "endobj\n"
        ),
        "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n",
        (
            f"5 0 obj\n<< /Length {len(stream)} >>\nstream\n{stream}\nendstream\nendobj\n"
        ),
    ]

    parts = ["%PDF-1.4\n"]
    offsets = [0]
    for obj in objects:
        offsets.append(sum(len(part.encode("latin-1")) for part in parts))
        parts.append(obj)

    xref_offset = sum(len(part.encode("latin-1")) for part in parts)
    parts.append(f"xref\n0 {len(objects) + 1}\n")
    parts.append("0000000000 65535 f \n")
    for offset in offsets[1:]:
        parts.append(f"{offset:010d} 00000 n \n")
    parts.append(
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n"
    )
    path.write_bytes("".join(parts).encode("latin-1"))


def test_docsearch_indexes_single_text_file(tmp_path):
    engine = docsearch(db_path=str(tmp_path / "searchbox.db"))
    doc_path = tmp_path / "guide.txt"
    doc_path.write_text("searchbox stores local documents in sqlite", encoding="utf-8")

    engine.add_path(str(doc_path))
    result = engine.search("sqlite documents", top_k=1)

    assert result[0]["id"] == str(doc_path)
    assert result[0]["metadata"]["source_name"] == "guide.txt"


def test_docsearch_indexes_supported_files_and_returns_document_hits(tmp_path):
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "guide.md").write_text(
        "# Guide\nDocument ingestion stores files in sqlite for retrieval.\n",
        encoding="utf-8",
    )
    (docs_dir / "faq.json").write_text(
        json.dumps({"topic": "retrieval", "answer": "search returns the best document"}),
        encoding="utf-8",
    )

    engine = docsearch(db_path=str(tmp_path / "docs.db"), chunk_size=8, chunk_overlap=2)
    indexed_ids = engine.add_path(str(docs_dir))

    assert len(indexed_ids) >= 2

    result = engine.search("document ingestion retrieval", top_k=2)

    assert result[0]["id"] == "guide.md"
    assert result[0]["metadata"]["matched_chunks"] == [0, 1]
    assert result[0]["metadata"]["best_chunk_index"] in {0, 1}


def test_docsearch_reads_pdf_and_surfaces_it_in_search_results(tmp_path):
    pdf_path = tmp_path / "manual.pdf"
    _write_simple_pdf(pdf_path, "PDF retrieval stores the document in sqlite")

    engine = docsearch(db_path=str(tmp_path / "docs.db"))
    indexed_ids = engine.add_path(str(pdf_path))

    assert len(indexed_ids) == 1

    result = engine.search("sqlite pdf retrieval", top_k=1)

    assert result[0]["id"] == str(pdf_path)
    assert result[0]["metadata"]["source_name"] == "manual.pdf"


def test_docsearch_skips_unsupported_files(tmp_path):
    docs_dir = tmp_path / "docs"
    docs_dir.mkdir()
    (docs_dir / "notes.txt").write_text("plain text retrieval notes", encoding="utf-8")
    (docs_dir / "image.png").write_bytes(b"not really an image")

    engine = docsearch(db_path=str(tmp_path / "docs.db"))
    indexed_ids = engine.add_path(str(docs_dir))

    assert len(indexed_ids) == 1
    assert engine.count() == 1


def test_docsearch_search_pretty_returns_readable_fields(tmp_path):
    doc_path = tmp_path / "guide.txt"
    doc_path.write_text(
        "vllm improves serving throughput for large language models in production systems",
        encoding="utf-8",
    )

    engine = docsearch(db_path=str(tmp_path / "docs.db"), chunk_size=6, chunk_overlap=1)
    engine.add_path(str(doc_path))

    result = engine.search_pretty("vllm throughput", top_k=1, snippet_length=40)

    assert result[0]["path"] == str(doc_path)
    assert result[0]["file_name"] == "guide.txt"
    assert result[0]["matched_chunk_count"] >= 1
    assert "vllm" in result[0]["snippet"].lower()


def test_docsearch_replaces_old_chunks_for_the_same_source(tmp_path):
    doc_path = tmp_path / "guide.txt"
    doc_path.write_text("alpha beta gamma delta", encoding="utf-8")

    engine = docsearch(db_path=str(tmp_path / "docs.db"), chunk_size=2, chunk_overlap=0)
    engine.add_path(str(doc_path))
    first_count = engine.count()

    doc_path.write_text("alpha beta", encoding="utf-8")
    engine.add_path(str(doc_path))

    assert first_count == 2
    assert engine.count() == 1


def test_docsearch_accepts_modular_repository_and_retriever(tmp_path):
    repository = SqliteDocumentRepository(db_path=str(tmp_path / "custom.db"))
    retriever = BM25Retriever(k1=1.2, b=0.7)
    engine = docsearch(repository=repository, retriever=retriever)

    doc_path = tmp_path / "guide.txt"
    doc_path.write_text("bm25 ranking prefers repeated retrieval terms", encoding="utf-8")

    engine.add_path(str(doc_path))
    result = engine.search("retrieval retrieval", top_k=1)

    assert result[0]["id"] == str(doc_path)
