from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class ChunkRecord:
    id: str
    title: str
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ChunkHit:
    chunk: ChunkRecord
    score: float
    tokens: List[str] = field(default_factory=list)
