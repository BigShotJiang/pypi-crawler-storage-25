from __future__ import annotations

import json
import sqlite3
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Iterable, List, Sequence

from .models import ChunkRecord


class DocumentRepository(ABC):
    @abstractmethod
    def upsert_chunks(self, chunks: Sequence[ChunkRecord]) -> List[str]:
        raise NotImplementedError

    @abstractmethod
    def fetch_chunks(self) -> List[ChunkRecord]:
        raise NotImplementedError

    @abstractmethod
    def delete_by_source_paths(self, source_paths: Sequence[str]) -> None:
        raise NotImplementedError

    @abstractmethod
    def count(self) -> int:
        raise NotImplementedError

    @abstractmethod
    def clear(self) -> None:
        raise NotImplementedError


class SqliteDocumentRepository(DocumentRepository):
    def __init__(self, db_path: str = "searchbox.db") -> None:
        self.db_path = Path(db_path)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS documents (
                    doc_id TEXT PRIMARY KEY,
                    title TEXT,
                    content TEXT NOT NULL,
                    metadata TEXT
                )
                """
            )
            conn.commit()

    def upsert_chunks(self, chunks: Sequence[ChunkRecord]) -> List[str]:
        if not chunks:
            return []

        rows = [
            (
                chunk.id,
                chunk.title,
                chunk.content,
                json.dumps(chunk.metadata, ensure_ascii=False),
            )
            for chunk in chunks
        ]
        with self._connect() as conn:
            conn.executemany(
                """
                INSERT INTO documents (doc_id, title, content, metadata)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(doc_id) DO UPDATE SET
                    title = excluded.title,
                    content = excluded.content,
                    metadata = excluded.metadata
                """,
                rows,
            )
            conn.commit()
        return [chunk.id for chunk in chunks]

    def fetch_chunks(self) -> List[ChunkRecord]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT doc_id, title, content, metadata FROM documents"
            ).fetchall()
        return [
            ChunkRecord(
                id=row[0],
                title=row[1] or "",
                content=row[2],
                metadata=json.loads(row[3]) if row[3] else {},
            )
            for row in rows
        ]

    def delete_by_source_paths(self, source_paths: Sequence[str]) -> None:
        if not source_paths:
            return

        with self._connect() as conn:
            conn.executemany(
                """
                DELETE FROM documents
                WHERE json_extract(metadata, '$.source_path') = ?
                """,
                [(source_path,) for source_path in source_paths],
            )
            conn.commit()

    def count(self) -> int:
        with self._connect() as conn:
            row = conn.execute("SELECT COUNT(*) FROM documents").fetchone()
        return int(row[0])

    def clear(self) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM documents")
            conn.commit()
