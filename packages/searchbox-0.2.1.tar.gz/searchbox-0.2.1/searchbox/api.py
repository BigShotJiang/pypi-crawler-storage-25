from __future__ import annotations

from typing import Any

from .document import DocumentSearch


def docsearch(*args: Any, **kwargs: Any) -> DocumentSearch:
    return DocumentSearch(*args, **kwargs)
