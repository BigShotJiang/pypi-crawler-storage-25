from __future__ import annotations

import math
import re
from abc import ABC, abstractmethod
from collections import Counter
from typing import Dict, List, Sequence

from .models import ChunkHit, ChunkRecord


TOKEN_PATTERN = re.compile(r"\w+", re.UNICODE)


class Retriever(ABC):
    @abstractmethod
    def score(self, query: str, chunks: Sequence[ChunkRecord]) -> List[ChunkHit]:
        raise NotImplementedError


class BM25Retriever(Retriever):
    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b

    def score(self, query: str, chunks: Sequence[ChunkRecord]) -> List[ChunkHit]:
        if not query or not query.strip():
            raise ValueError("`query` must not be empty.")
        if not chunks:
            return []

        query_tokens = self._tokenize(query)
        if not query_tokens:
            return []

        tokenized_chunks = [
            self._tokenize(f"{chunk.title} {chunk.content}") for chunk in chunks
        ]
        avg_doc_len = sum(len(tokens) for tokens in tokenized_chunks) / len(tokenized_chunks)
        if avg_doc_len == 0:
            return []

        doc_freq = Counter()
        for tokens in tokenized_chunks:
            doc_freq.update(set(tokens))

        total_docs = len(tokenized_chunks)
        hits: List[ChunkHit] = []
        for chunk, tokens in zip(chunks, tokenized_chunks):
            token_counts = Counter(tokens)
            doc_len = len(tokens)
            score = 0.0
            for token in query_tokens:
                term_freq = token_counts.get(token, 0)
                if term_freq == 0:
                    continue
                idf = math.log(1 + ((total_docs - doc_freq[token] + 0.5) / (doc_freq[token] + 0.5)))
                numerator = term_freq * (self.k1 + 1)
                denominator = term_freq + self.k1 * (1 - self.b + self.b * (doc_len / avg_doc_len))
                score += idf * (numerator / denominator)
            if score <= 0:
                continue
            hits.append(ChunkHit(chunk=chunk, score=round(score, 6), tokens=tokens))

        hits.sort(key=lambda item: item.score, reverse=True)
        return hits

    def _tokenize(self, text: str) -> List[str]:
        return [token.lower() for token in TOKEN_PATTERN.findall(text)]
