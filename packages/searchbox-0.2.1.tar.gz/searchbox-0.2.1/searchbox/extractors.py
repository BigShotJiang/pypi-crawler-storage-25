from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Any, List


TAG_PATTERN = re.compile(r"<[^>]+>")
WHITESPACE_PATTERN = re.compile(r"\s+")
PDF_TEXT_FALLBACK_PATTERN = re.compile(rb"\(([^()]*)\)")
TEXT_SUFFIXES = {
    ".txt",
    ".md",
    ".rst",
    ".py",
    ".toml",
    ".yaml",
    ".yml",
    ".csv",
    ".tsv",
}
HTML_SUFFIXES = {".html", ".htm"}


class FileTextExtractor:
    def supported_extensions(self) -> List[str]:
        return sorted(TEXT_SUFFIXES | HTML_SUFFIXES | {".json", ".pdf"})

    def read_text(self, path: Path) -> str:
        suffix = path.suffix.lower()
        if suffix in TEXT_SUFFIXES:
            return self._normalize_text(path.read_text(encoding="utf-8", errors="ignore"))
        if suffix in HTML_SUFFIXES:
            html = path.read_text(encoding="utf-8", errors="ignore")
            return self._normalize_text(TAG_PATTERN.sub(" ", html))
        if suffix == ".json":
            return self._normalize_text(self._read_json(path))
        if suffix == ".pdf":
            return self._normalize_text(self._read_pdf(path))
        return ""

    def _read_json(self, path: Path) -> str:
        with path.open("r", encoding="utf-8", errors="ignore") as file:
            return self._json_to_text(json.load(file))

    def _read_pdf(self, path: Path) -> str:
        try:
            completed = subprocess.run(
                ["pdftotext", "-layout", str(path), "-"],
                check=True,
                capture_output=True,
            )
        except (FileNotFoundError, subprocess.CalledProcessError):
            return self._read_pdf_fallback(path)
        return completed.stdout.decode("utf-8", errors="ignore")

    def _read_pdf_fallback(self, path: Path) -> str:
        data = path.read_bytes()
        segments = []
        for match in PDF_TEXT_FALLBACK_PATTERN.findall(data):
            text = match.decode("latin-1", errors="ignore")
            text = text.replace("\\n", " ").replace("\\r", " ").replace("\\t", " ")
            if any(character.isalpha() for character in text):
                segments.append(text)
        return " ".join(segments)

    def _json_to_text(self, payload: Any) -> str:
        if isinstance(payload, dict):
            return " ".join(
                f"{key} {self._json_to_text(value)}"
                for key, value in payload.items()
            )
        if isinstance(payload, list):
            return " ".join(self._json_to_text(item) for item in payload)
        if payload is None:
            return ""
        return str(payload)

    def _normalize_text(self, text: str) -> str:
        return WHITESPACE_PATTERN.sub(" ", text).strip()
