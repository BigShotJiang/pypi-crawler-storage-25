from __future__ import annotations

import io
from pathlib import Path
from typing import TYPE_CHECKING, cast

from .contracts import ExportClient, MarkdownOutput, TextWriter
from .output import open_output_stream
from .replies import build_reply_lookup
from .rendering import write_chat_markdown

if TYPE_CHECKING:
    from telethon import hints


async def export(
    client: ExportClient,
    chat: hints.EntityLike,
    output_path: MarkdownOutput = None,
    *,
    limit: int = 1000,
) -> str | Path | TextWriter:
    """Export recent chat messages into markdown.

    When ``output_path`` is ``None`` or ``bytes``, the markdown is returned in-memory
    as ``str``. Path-like targets are written to disk. Any other object must expose a
    text ``write()`` method and will be written to directly.
    """
    if limit < 0:
        raise ValueError("limit must be >= 0")

    entity = await client.get_entity(chat)
    messages = [message async for message in client.iter_messages(chat, limit=limit)]
    messages.reverse()
    reply_lookup = await build_reply_lookup(client, chat, messages)
    stream, output_target, in_memory = open_output_stream(output_path)
    try:
        write_chat_markdown(stream, entity, messages, reply_lookup)

        flush = getattr(stream, "flush", None)
        if callable(flush):
            flush()

        if in_memory:
            return cast(io.StringIO, stream).getvalue()
        return output_target
    finally:
        if in_memory or isinstance(output_target, Path):
            stream.close()
