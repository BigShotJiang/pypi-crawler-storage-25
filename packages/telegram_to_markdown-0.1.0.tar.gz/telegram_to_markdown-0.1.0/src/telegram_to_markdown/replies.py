from __future__ import annotations

from collections.abc import Iterable, Sequence
from typing import TYPE_CHECKING, Any

from .contracts import ExportClient

if TYPE_CHECKING:
    from telethon import hints


async def build_reply_lookup(
    client: ExportClient, entity: hints.EntityLike, messages: list[Any]
) -> dict[int, Any]:
    reply_lookup = {
        message.id: message
        for message in messages
        if message is not None and getattr(message, "id", None) is not None
    }

    missing_reply_ids = sorted(
        {
            reply_id
            for message in messages
            if message is not None
            for reply_id in [reply_to_message_id(message)]
            if reply_id is not None and reply_id not in reply_lookup
        }
    )
    if not missing_reply_ids:
        return reply_lookup

    resolved_replies = await client.get_messages(entity, ids=missing_reply_ids)
    for reply_message in iter_reply_messages(resolved_replies):
        if reply_message is None:
            continue
        reply_id = getattr(reply_message, "id", None)
        if reply_id is not None:
            reply_lookup[reply_id] = reply_message

    return reply_lookup


def reply_to_message_id(message: Any) -> int | None:
    reply_to = getattr(message, "reply_to", None)
    if reply_to is None:
        return None
    return getattr(reply_to, "reply_to_msg_id", None)


def iter_reply_messages(resolved_replies: object) -> Iterable[Any]:
    if resolved_replies is None:
        return ()
    if isinstance(resolved_replies, Sequence) and not isinstance(
        resolved_replies, (str, bytes)
    ):
        return resolved_replies
    return (resolved_replies,)
