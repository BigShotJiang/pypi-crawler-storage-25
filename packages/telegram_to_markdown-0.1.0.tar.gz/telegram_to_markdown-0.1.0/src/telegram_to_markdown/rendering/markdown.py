from __future__ import annotations

import re

from .names import single_line

_BODY_MARKDOWN_PREFIX = re.compile(r"\s*(?:#{1,6}|>|[*+-]|\d+\.)\s")
_BODY_MARKDOWN_RULE = re.compile(r"\s*(?:-{3,}|\*{3,}|_{3,})\s*$")
_BODY_FENCE_LINE = re.compile(r"^(`{3,})([^\r\n`]*)$")
_INLINE_ESCAPE_TABLE = str.maketrans(
    {
        "\\": r"\\",
        "`": r"\`",
        "*": r"\*",
        "_": r"\_",
        "[": r"\[",
        "]": r"\]",
    }
)


def iter_text_lines(text: str):
    yield from text.split("\n")


def escape_markdown_body_text(text: str) -> str:
    lines = text.split("\n")
    escaped_lines: list[str] = []
    active_fence: str | None = None

    for line in lines:
        if active_fence is not None:
            escaped_lines.append(line)
            if is_closing_fence(line, active_fence):
                active_fence = None
            continue

        fence = opening_fence(line)
        if fence is not None:
            escaped_lines.append(line)
            active_fence = fence
            continue

        escaped_lines.append(escape_markdown_body_structure(line))

    return "\n".join(escaped_lines)


def escape_markdown_body(line: str) -> str:
    escaped = escape_inline_text(line)
    return escape_markdown_body_structure(escaped)


def escape_markdown_body_structure(line: str) -> str:
    stripped = line.lstrip()
    indent = line[: len(line) - len(stripped)]
    if (
        stripped.startswith("|")
        or _BODY_MARKDOWN_PREFIX.match(line)
        or _BODY_MARKDOWN_RULE.match(line)
    ):
        return f"{indent}\\{line[len(indent):]}"
    return line


def escape_inline_text(text: str) -> str:
    return text.translate(_INLINE_ESCAPE_TABLE)


def opening_fence(line: str) -> str | None:
    match = _BODY_FENCE_LINE.match(line)
    if match is None:
        return None
    return match.group(1)


def is_closing_fence(line: str, fence: str) -> bool:
    return bool(re.fullmatch(rf"{re.escape(fence)}\s*", line))


def quoted_text(text: str) -> str:
    escaped = escape_inline_text(single_line(text)).replace('"', r"\"")
    return f'"{escaped}"'


def escape_link_destination(url: str) -> str:
    return url.replace("\\", r"\\").replace(")", r"\)")
