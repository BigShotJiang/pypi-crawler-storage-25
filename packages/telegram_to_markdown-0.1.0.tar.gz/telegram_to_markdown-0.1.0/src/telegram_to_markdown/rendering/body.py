from __future__ import annotations

from typing import Any

from .entities import render_message_entities
from .markdown import escape_markdown_body, escape_markdown_body_text


def plain_message_text(message: Any) -> str:
    text = getattr(message, "raw_text", None)
    if text is None:
        text = getattr(message, "message", None)
    if not text:
        return ""
    return str(text).replace("\r\n", "\n").replace("\r", "\n")


def message_body_text(message: Any) -> str:
    text = plain_message_text(message)
    if not text:
        return ""

    rendered = render_message_entities(message, text)
    if rendered is None:
        return "\n".join(escape_markdown_body(line) for line in text.split("\n"))
    return escape_markdown_body_text(rendered)
