from __future__ import annotations

from typing import Any

from ..contracts import TextWriter

from .body import message_body_text
from .markdown import escape_inline_text, iter_text_lines
from .metadata import metadata_lines
from .names import (
    display_name,
    format_date_heading,
    format_time,
    sender_display_name,
    single_line,
)


def write_chat_markdown(
    stream: TextWriter,
    chat_entity: Any,
    messages: list[Any],
    reply_lookup: dict[int, Any],
) -> None:
    heading = escape_inline_text(single_line(display_name(chat_entity) or "Telegram Chat"))
    stream.write(f"# {heading}\n\n")

    if not messages:
        stream.write("_No messages found._\n")
        return

    current_day = None
    for index, message in enumerate(messages):
        day_heading = format_date_heading(getattr(message, "date", None))
        if day_heading != current_day:
            if index:
                stream.write("\n\n")
            stream.write(f"## {day_heading}\n\n")
            current_day = day_heading
        elif index:
            stream.write("\n\n")

        write_message_block(stream, message, reply_lookup)

    stream.write("\n")


def write_message_block(
    stream: TextWriter, message: Any, reply_lookup: dict[int, Any]
) -> None:
    first_line = True
    for line in iter_message_lines(message, reply_lookup):
        if not first_line:
            stream.write("\n")
        stream.write(line)
        first_line = False


def iter_message_lines(message: Any, reply_lookup: dict[int, Any]):
    yield render_message_heading(message)

    details = metadata_lines(message, reply_lookup)
    if details:
        yield from details

    text = message_body_text(message)
    if text:
        yield ""
        yield from iter_text_lines(text)
        return

    if not details:
        yield ""
        yield "_Empty message_"


def render_message_heading(message: Any) -> str:
    sender = escape_inline_text(sender_display_name(message))
    timestamp = format_time(getattr(message, "date", None))
    return f"### {sender} · {timestamp}"
