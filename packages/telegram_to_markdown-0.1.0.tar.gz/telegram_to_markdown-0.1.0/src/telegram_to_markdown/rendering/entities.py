from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from telethon.helpers import add_surrogate, del_surrogate
from telethon.tl import types as telethon_types

from .markdown import escape_inline_text, escape_link_destination
from .names import single_line

_SUPPORTED_ENTITY_TYPES = (
    telethon_types.MessageEntityBold,
    telethon_types.MessageEntityItalic,
    telethon_types.MessageEntityStrike,
    telethon_types.MessageEntityCode,
    telethon_types.MessageEntityPre,
    telethon_types.MessageEntityTextUrl,
    telethon_types.MessageEntityMentionName,
)


@dataclass(frozen=True)
class RenderedEntity:
    start: int
    end: int
    start_marker: str
    end_marker: str
    is_verbatim: bool = False
    order: int = 0


def render_message_entities(message: Any, text: str) -> str | None:
    entities = getattr(message, "entities", None) or []
    if not entities:
        return None

    surrogate_text = add_surrogate(text)
    rendered_entities = rendered_entities_for_text(surrogate_text, entities)
    if not rendered_entities:
        return None

    starts: dict[int, list[RenderedEntity]] = {}
    ends: dict[int, list[RenderedEntity]] = {}
    for rendered_entity in rendered_entities:
        starts.setdefault(rendered_entity.start, []).append(rendered_entity)
        ends.setdefault(rendered_entity.end, []).append(rendered_entity)

    for offset in starts:
        starts[offset].sort(
            key=lambda item: (-(item.end - item.start), item.end, item.start, item.order)
        )
    for offset in ends:
        ends[offset].sort(
            key=lambda item: ((item.end - item.start), -item.start, -item.end, -item.order)
        )

    parts: list[str] = []
    verbatim_depth = 0
    cursor = 0

    for rendered_entity in starts.get(0, ()):
        parts.append(rendered_entity.start_marker)
        if rendered_entity.is_verbatim:
            verbatim_depth += 1

    event_positions = sorted(
        position
        for position in set(starts) | set(ends) | {len(surrogate_text)}
        if position > 0
    )
    for position in event_positions:
        chunk = del_surrogate(surrogate_text[cursor:position])
        if chunk:
            parts.append(chunk if verbatim_depth else escape_inline_text(chunk))

        for rendered_entity in ends.get(position, ()):
            parts.append(rendered_entity.end_marker)
            if rendered_entity.is_verbatim:
                verbatim_depth -= 1

        for rendered_entity in starts.get(position, ()):
            parts.append(rendered_entity.start_marker)
            if rendered_entity.is_verbatim:
                verbatim_depth += 1

        cursor = position

    return "".join(parts)


def rendered_entities_for_text(
    surrogate_text: str, entities: list[Any]
) -> list[RenderedEntity]:
    rendered_entities: list[RenderedEntity] = []
    for order, entity in enumerate(entities):
        if not isinstance(entity, _SUPPORTED_ENTITY_TYPES):
            continue

        offset = getattr(entity, "offset", None)
        length = getattr(entity, "length", None)
        if not isinstance(offset, int) or not isinstance(length, int) or length <= 0:
            continue

        end = offset + length
        if offset < 0 or end > len(surrogate_text):
            continue

        content = del_surrogate(surrogate_text[offset:end])
        rendered_entity = render_entity(
            entity, content, surrogate_text, offset, end, order
        )
        if rendered_entity is not None:
            rendered_entities.append(rendered_entity)

    return rendered_entities


def render_entity(
    entity: Any, content: str, surrogate_text: str, start: int, end: int, order: int
) -> RenderedEntity | None:
    if isinstance(entity, telethon_types.MessageEntityBold):
        return RenderedEntity(start, end, "**", "**", order=order)

    if isinstance(entity, telethon_types.MessageEntityItalic):
        return RenderedEntity(start, end, "_", "_", order=order)

    if isinstance(entity, telethon_types.MessageEntityStrike):
        return RenderedEntity(start, end, "~~", "~~", order=order)

    if isinstance(entity, telethon_types.MessageEntityTextUrl):
        url = getattr(entity, "url", None)
        if not url:
            return None
        return RenderedEntity(
            start, end, "[", f"]({escape_link_destination(str(url))})", order=order
        )

    if isinstance(entity, telethon_types.MessageEntityMentionName):
        user_id = getattr(entity, "user_id", None)
        if user_id is None:
            return None
        return RenderedEntity(
            start, end, "[", f"](tg://user?id={user_id})", order=order
        )

    if isinstance(entity, telethon_types.MessageEntityCode):
        markers = inline_code_markers(content)
        if markers is None:
            return None
        return RenderedEntity(
            start, end, markers[0], markers[1], is_verbatim=True, order=order
        )

    if isinstance(entity, telethon_types.MessageEntityPre):
        if "\n" in content and can_render_fenced_pre_block(surrogate_text, start, end):
            fence = code_fence_delimiter(content)
            language = single_line(getattr(entity, "language", None))
            opening = f"{fence}{language}\n"
            closing = f"\n{fence}"
            return RenderedEntity(
                start, end, opening, closing, is_verbatim=True, order=order
            )

        markers = inline_code_markers(content)
        if markers is None:
            return None
        return RenderedEntity(
            start, end, markers[0], markers[1], is_verbatim=True, order=order
        )

    return None


def inline_code_markers(content: str) -> tuple[str, str] | None:
    if "\n" in content or "``" in content:
        return None

    delimiter = (
        "``"
        if ("`" in content or content[:1].isspace() or content[-1:].isspace())
        else "`"
    )
    padding = " " if delimiter == "``" else ""
    return f"{delimiter}{padding}", f"{padding}{delimiter}"


def code_fence_delimiter(content: str) -> str:
    longest_run = max((len(match.group(0)) for match in re.finditer(r"`+", content)), default=0)
    return "`" * max(3, longest_run + 1)


def can_render_fenced_pre_block(surrogate_text: str, start: int, end: int) -> bool:
    at_line_start = start == 0 or surrogate_text[start - 1] == "\n"
    at_line_end = end == len(surrogate_text) or surrogate_text[end] == "\n"
    return at_line_start and at_line_end
