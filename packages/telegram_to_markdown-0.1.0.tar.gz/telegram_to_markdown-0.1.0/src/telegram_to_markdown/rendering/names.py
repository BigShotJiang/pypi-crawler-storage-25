from __future__ import annotations

from typing import Any

from telethon import utils as telethon_utils

_REPLY_PREVIEW_LIMIT = 80


def format_date_heading(value: Any) -> str:
    if value is None:
        return "Unknown date"
    return value.strftime("%Y-%m-%d")


def format_time(value: Any) -> str:
    if value is None:
        return "Unknown time"
    return value.strftime("%H:%M")


def sender_display_name(message: Any) -> str:
    for candidate in (
        getattr(message, "post_author", None),
        display_name(getattr(message, "sender", None)),
        peer_label(getattr(message, "sender_id", None)),
        peer_label(getattr(message, "from_id", None)),
    ):
        if candidate:
            return single_line(candidate)
    return "Unknown sender"


def display_name(entity: Any) -> str | None:
    if entity is None:
        return None

    resolved = telethon_utils.get_display_name(entity)
    if resolved:
        return str(resolved)

    title = getattr(entity, "title", None)
    if title:
        return str(title)

    first_name = getattr(entity, "first_name", None)
    last_name = getattr(entity, "last_name", None)
    if first_name or last_name:
        return " ".join(part for part in (first_name, last_name) if part)

    username = getattr(entity, "username", None)
    if username:
        username = str(username)
        return username if username.startswith("@") else f"@{username}"

    for attr in ("from_name", "post_author"):
        value = getattr(entity, attr, None)
        if value:
            return str(value)

    return None


def peer_label(value: Any) -> str | None:
    if value is None:
        return None

    if isinstance(value, int):
        return f"User {value}"

    for attr, prefix in (
        ("user_id", "User"),
        ("chat_id", "Chat"),
        ("channel_id", "Channel"),
        ("id", "ID"),
    ):
        peer_id = getattr(value, attr, None)
        if peer_id is not None:
            return f"{prefix} {peer_id}"

    return display_name(value)


def truncate_preview(text: str, limit: int = _REPLY_PREVIEW_LIMIT) -> str:
    flattened = single_line(text)
    if len(flattened) <= limit:
        return flattened
    return flattened[: limit - 3].rstrip() + "..."


def single_line(value: Any) -> str:
    if value is None:
        return ""
    return " ".join(str(value).split())


def class_name(value: Any) -> str:
    if value is None:
        return ""
    return value.__class__.__name__
