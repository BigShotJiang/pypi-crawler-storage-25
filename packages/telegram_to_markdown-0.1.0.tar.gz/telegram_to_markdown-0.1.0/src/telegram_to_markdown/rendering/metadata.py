from __future__ import annotations

import re
from typing import Any

from .body import plain_message_text
from .markdown import escape_inline_text, quoted_text
from .names import class_name, display_name, peer_label, single_line, truncate_preview


def metadata_lines(message: Any, reply_lookup: dict[int, Any]) -> list[str]:
    lines: list[str] = []

    forwarded = forwarded_from(message)
    if forwarded:
        lines.append(f"- Forwarded from: {escape_inline_text(forwarded)}")

    preview = reply_preview(message, reply_lookup)
    if preview:
        lines.append(f"- Reply to: {preview}")

    service = service_description(message)
    if service:
        lines.append(f"- Service: {escape_inline_text(service)}")

    poll_lines = poll_metadata_lines(message)
    if poll_lines:
        lines.extend(poll_lines)
    else:
        includes = content_summary(message)
        if includes:
            lines.append(render_attached_content(includes))

    reactions = format_reactions(getattr(message, "reactions", None))
    if reactions:
        lines.append(f"- Reactions: {escape_inline_text(reactions)}")

    if getattr(message, "edit_date", None):
        lines.append("- Edited")

    return lines


def reply_preview(message: Any, reply_lookup: dict[int, Any]) -> str | None:
    reply_to = getattr(message, "reply_to", None)
    reply_id = None if reply_to is None else getattr(reply_to, "reply_to_msg_id", None)
    if reply_id is None:
        return None

    reply_message = reply_lookup.get(reply_id)
    if reply_message is None:
        return "Unavailable message"

    reply_text = plain_message_text(reply_message)
    if reply_text:
        preview = truncate_preview(reply_text)
        return quoted_text(preview)

    reply_label = service_description(reply_message) or content_summary(reply_message)
    if reply_label:
        return escape_inline_text(reply_label)

    return "Empty message"


def forwarded_from(message: Any) -> str | None:
    forward = getattr(message, "forward", None)
    if forward is not None:
        sender_name = display_name(getattr(forward, "sender", None))
        if sender_name:
            return single_line(sender_name)

        chat_name = display_name(getattr(forward, "chat", None))
        if chat_name:
            return single_line(chat_name)

    fwd_from = getattr(message, "fwd_from", None)
    if fwd_from is None:
        return None

    for candidate in (
        getattr(fwd_from, "from_name", None),
        getattr(fwd_from, "post_author", None),
        peer_label(getattr(fwd_from, "from_id", None)),
        peer_label(getattr(fwd_from, "saved_from_id", None)),
    ):
        if candidate:
            return single_line(candidate)

    return None


def format_reactions(reactions: Any) -> str | None:
    if reactions is None:
        return None

    parts = []
    for result in getattr(reactions, "results", []) or []:
        reaction = reaction_label(getattr(result, "reaction", None))
        if not reaction:
            continue

        count = getattr(result, "count", None)
        parts.append(f"{reaction} {count}" if count is not None else reaction)

    if not parts:
        return None
    return ", ".join(parts)


def reaction_label(reaction: Any) -> str | None:
    if reaction is None:
        return None

    emoticon = getattr(reaction, "emoticon", None)
    if emoticon:
        return str(emoticon)

    if getattr(reaction, "document_id", None):
        return "Custom emoji"

    return "Reaction"


def service_description(message: Any) -> str | None:
    action = getattr(message, "action", None)
    if action is None:
        return None

    action_name = class_name(action)

    if action_name == "MessageActionPinMessage":
        return "pinned a message"

    if action_name == "MessageActionChatEditTitle":
        title = single_line(getattr(action, "title", None))
        if title:
            return f'changed the chat title to "{title}"'
        return "changed the chat title"

    if action_name == "MessageActionChatEditPhoto":
        return "changed the chat photo"

    if action_name == "MessageActionChatDeletePhoto":
        return "removed the chat photo"

    if action_name == "MessageActionChatAddUser":
        users = format_added_users(getattr(action, "users", None))
        if users:
            return f"added {users}"
        return "added users"

    if action_name == "MessageActionChatDeleteUser":
        user_label = peer_label(getattr(action, "user_id", None)) or "a user"
        return f"removed {user_label}"

    if action_name == "MessageActionChatJoinedByLink":
        return "joined via invite link"

    if action_name == "MessageActionChatJoinedByRequest":
        return "joined by request"

    if action_name == "MessageActionChatCreate":
        title = single_line(getattr(action, "title", None))
        if title:
            return f'created the group "{title}"'
        return "created the group"

    if action_name == "MessageActionChannelCreate":
        title = single_line(getattr(action, "title", None))
        if title:
            return f'created the channel "{title}"'
        return "created the channel"

    if action_name == "MessageActionHistoryClear":
        return "chat history was cleared"

    if action_name == "MessageActionContactSignUp":
        return "joined Telegram"

    if action_name == "MessageActionCustomAction":
        custom = single_line(getattr(action, "message", None))
        if custom:
            return custom

    return humanize_action_name(action_name)


def format_added_users(users: Any) -> str | None:
    if not users:
        return None

    labels = [peer_label(user) for user in users]
    labels = [label for label in labels if label]
    if not labels:
        return None
    if len(labels) <= 3:
        return ", ".join(labels)
    return f"{', '.join(labels[:3])}, and {len(labels) - 3} more"


def humanize_action_name(action_name: str) -> str:
    if action_name.startswith("MessageAction"):
        action_name = action_name[len("MessageAction") :]
    action_name = re.sub(r"(?<!^)([A-Z])", r" \1", action_name).strip()
    return action_name.lower() or "service message"


def render_attached_content(content: str) -> str:
    kind, separator, detail = content.partition(" - ")
    attached_kind = kind.lower()
    if separator:
        return f"- Attached {attached_kind}: {escape_inline_text(detail)}"
    return f"- Attached {attached_kind}"


def poll_metadata_lines(message: Any) -> list[str]:
    poll = poll_data(message)
    if poll is None:
        return []

    question_text = poll_text(getattr(poll, "question", None))
    flag_suffix = poll_flag_suffix(poll)
    if question_text:
        lines = [f"- Attached poll: {escape_inline_text(question_text)}{flag_suffix}"]
    else:
        lines = [f"- Attached poll{flag_suffix}"]

    for answer in getattr(poll, "answers", []) or []:
        answer_text = poll_text(getattr(answer, "text", answer))
        if answer_text:
            lines.append(f"  - {escape_inline_text(answer_text)}")

    return lines


def poll_data(message: Any) -> Any:
    poll = getattr(message, "poll", None)
    if poll is None:
        return None
    return getattr(poll, "poll", poll)


def poll_text(value: Any) -> str:
    return single_line(getattr(value, "text", value))


def poll_flag_suffix(poll: Any) -> str:
    flags: list[str] = []
    if getattr(poll, "quiz", None):
        flags.append("Quiz")
    if getattr(poll, "multiple_choice", None):
        flags.append("Multiple choice")
    if not flags:
        return ""
    return f" ({', '.join(flags)})"


def content_summary(message: Any) -> str | None:
    if getattr(message, "action", None) is not None:
        return None

    file_info = getattr(message, "file", None)

    if getattr(message, "sticker", None):
        emoji = single_line(getattr(file_info, "emoji", None))
        return f"Sticker - {emoji}" if emoji else "Sticker"

    if getattr(message, "photo", None):
        return "Photo"

    if getattr(message, "video", None):
        return "Video"

    if getattr(message, "voice", None):
        return "Voice message"

    if getattr(message, "video_note", None):
        return "Video note"

    if getattr(message, "audio", None):
        performer = single_line(getattr(file_info, "performer", None))
        title = single_line(getattr(file_info, "title", None))
        if performer and title:
            return f"Audio - {performer} - {title}"
        if title:
            return f"Audio - {title}"
        if performer:
            return f"Audio - {performer}"
        return "Audio"

    if getattr(message, "gif", None):
        return "GIF"

    poll = poll_data(message)
    if poll is not None:
        question = getattr(poll, "question", None)
        question_text = single_line(getattr(question, "text", question))
        return f"Poll - {question_text}" if question_text else "Poll"

    contact = getattr(message, "contact", None)
    if contact is not None:
        contact_name = " ".join(
            part
            for part in (
                getattr(contact, "first_name", None),
                getattr(contact, "last_name", None),
            )
            if part
        ).strip()
        phone_number = single_line(getattr(contact, "phone_number", None))
        suffix = " ".join(part for part in (contact_name, phone_number) if part)
        return f"Contact - {suffix}" if suffix else "Contact"

    venue = getattr(message, "venue", None)
    if venue is not None:
        title = single_line(getattr(venue, "title", None))
        return f"Venue - {title}" if title else "Venue"

    media = getattr(message, "media", None)
    if class_name(media) in {"MessageMediaGeo", "MessageMediaGeoLive"}:
        return "Location"

    if getattr(message, "web_preview", None):
        return "Link preview"

    if getattr(message, "document", None) or file_info is not None:
        file_name = single_line(getattr(file_info, "name", None))
        return f"File - {file_name}" if file_name else "File"

    if media is not None:
        return "Media"

    return None
