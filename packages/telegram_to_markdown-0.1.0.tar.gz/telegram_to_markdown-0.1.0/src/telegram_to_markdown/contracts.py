from __future__ import annotations

from collections.abc import AsyncIterator, Iterable
from os import PathLike
from typing import TYPE_CHECKING, Any, Protocol, TypeGuard

if TYPE_CHECKING:
    from telethon import hints


class TextWriter(Protocol):
    def write(self, text: str, /) -> object: ...


type MarkdownPath = str | PathLike[str]
type MarkdownOutput = MarkdownPath | type[bytes] | TextWriter | None


class ExportClient(Protocol):
    async def get_entity(self, chat: "hints.EntityLike") -> Any: ...

    def iter_messages(self, entity: "hints.EntityLike", limit: int) -> AsyncIterator[Any]:
        ...

    async def get_messages(
        self, entity: "hints.EntityLike", ids: Iterable[int]
    ) -> Any: ...


def is_text_writer(value: object) -> TypeGuard[TextWriter]:
    return callable(getattr(value, "write", None))


def is_markdown_path(value: object) -> TypeGuard[MarkdownPath]:
    return isinstance(value, (str, PathLike)) and not is_text_writer(value)
