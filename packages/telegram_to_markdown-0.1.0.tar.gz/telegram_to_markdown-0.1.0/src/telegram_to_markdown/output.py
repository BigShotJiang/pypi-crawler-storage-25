from __future__ import annotations

import io
from pathlib import Path

from .contracts import MarkdownOutput, TextWriter, is_markdown_path, is_text_writer


def open_output_stream(
    output_path: MarkdownOutput,
) -> tuple[io.StringIO | TextWriter, Path | TextWriter, bool]:
    in_memory = output_path is None or output_path is bytes
    if in_memory:
        buffer = io.StringIO()
        return buffer, buffer, True

    if is_markdown_path(output_path):
        path = Path(output_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        return path.open("w", encoding="utf-8"), path, False

    if not is_text_writer(output_path):
        raise TypeError(
            "output_path must be a path, a text stream, None, or the bytes type sentinel"
        )
    return output_path, output_path, False
