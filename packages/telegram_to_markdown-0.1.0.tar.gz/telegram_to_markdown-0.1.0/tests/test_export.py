from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

from telegram_to_markdown import export

from tests.helpers import ExportTestCase
from tests.stubs import RecordingWriter, StubClient, StubMessage, StubSender


class ExportTests(ExportTestCase):
    async def test_text_messages_are_rendered_oldest_first_and_grouped_by_day(self):
        older = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            date=datetime(2026, 4, 17, 23, 58, tzinfo=timezone.utc),
            raw_text="First message",
        )
        newer = StubMessage(
            2,
            sender=StubSender(first_name="Bob"),
            date=datetime(2026, 4, 18, 0, 5, tzinfo=timezone.utc),
            raw_text="Second message",
        )
        client = StubClient(SimpleNamespace(title="Demo chat"), [newer, older])

        result, output_path, content = await self.export_to_path(client, limit=1000)

        self.assertEqual(result, output_path)
        self.assertEqual(
            content,
            "# Demo chat\n\n"
            "## 2026-04-17\n\n"
            "### Alice · 23:58\n\n"
            "First message\n\n"
            "## 2026-04-18\n\n"
            "### Bob · 00:05\n\n"
            "Second message\n",
        )

    async def test_zero_messages_writes_empty_state(self):
        client = StubClient(SimpleNamespace(title="Empty"), [])

        _, _, content = await self.export_to_path(client, filename="empty.md", limit=0)

        self.assertEqual(content, "# Empty\n\n_No messages found._\n")

    async def test_bytes_output_returns_markdown_string(self):
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text="Hello from memory",
        )
        client = StubClient(SimpleNamespace(title="In memory"), [message])

        result = await export(client, "chat", bytes)

        self.assertEqual(
            result,
            "# In memory\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n\n"
            "Hello from memory\n",
        )

    async def test_none_output_returns_markdown_string(self):
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text="Implicit buffer",
        )
        client = StubClient(SimpleNamespace(title="In memory"), [message])

        result = await export(client, "chat")

        self.assertEqual(
            result,
            "# In memory\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n\n"
            "Implicit buffer\n",
        )

    async def test_accepts_open_text_stream_and_writes_incrementally(self):
        older = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            date=datetime(2026, 4, 18, 15, 0, tzinfo=timezone.utc),
            raw_text="First message",
        )
        newer = StubMessage(
            2,
            sender=StubSender(first_name="Bob"),
            date=datetime(2026, 4, 18, 15, 5, tzinfo=timezone.utc),
            raw_text="Second message",
        )
        client = StubClient(SimpleNamespace(title="Stream chat"), [newer, older])
        writer = RecordingWriter()

        result = await export(client, "chat", writer)
        content = writer.getvalue()

        self.assertIs(result, writer)
        self.assertGreater(len(writer.calls), 3)
        self.assertEqual(
            content,
            "# Stream chat\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:00\n\n"
            "First message\n\n"
            "### Bob · 15:05\n\n"
            "Second message\n",
        )
