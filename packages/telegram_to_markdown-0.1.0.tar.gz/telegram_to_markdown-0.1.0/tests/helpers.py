from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from telegram_to_markdown import export


class ExportTestCase(unittest.IsolatedAsyncioTestCase):
    async def export_to_path(self, client, filename="conversation.md", **kwargs):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / filename
            result = await export(client, "chat", output_path, **kwargs)
            content = output_path.read_text(encoding="utf-8")

        return result, output_path, content
