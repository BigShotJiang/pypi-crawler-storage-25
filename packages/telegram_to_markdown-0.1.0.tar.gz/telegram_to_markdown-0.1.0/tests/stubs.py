from __future__ import annotations

import io
from collections.abc import AsyncIterator, Iterable
from datetime import datetime, timezone
from typing import Any


class StubClient:
    def __init__(
        self,
        entity: Any,
        messages: Iterable[Any],
        reply_messages: dict[int, Any | None] | None = None,
    ) -> None:
        self.entity = entity
        self.messages = list(messages)
        self.reply_messages = reply_messages or {}
        self.get_messages_calls: list[list[int]] = []

    async def get_entity(self, chat: object) -> Any:
        return self.entity

    async def iter_messages(self, entity: object, limit: int) -> AsyncIterator[Any]:
        for message in self.messages[:limit]:
            yield message

    async def get_messages(
        self, entity: object, ids: Iterable[int]
    ) -> list[Any | None]:
        requested_ids = list(ids)
        self.get_messages_calls.append(requested_ids)
        return [self.reply_messages.get(message_id) for message_id in requested_ids]


class StubSender:
    def __init__(self, *, first_name=None, last_name=None, title=None, username=None):
        self.first_name = first_name
        self.last_name = last_name
        self.title = title
        self.username = username


class StubMessage:
    def __init__(
        self,
        message_id,
        *,
        sender=None,
        date=None,
        raw_text="",
        sender_id=None,
        reply_to=None,
        file=None,
        action=None,
        fwd_from=None,
        reactions=None,
        media=None,
        edit_date=None,
        post_author=None,
        forward=None,
        entities=None,
        sticker=None,
        photo=None,
        video=None,
        voice=None,
        video_note=None,
        audio=None,
        gif=None,
        poll=None,
        contact=None,
        venue=None,
        web_preview=None,
        document=None,
    ):
        self.id = message_id
        self.sender = sender
        self.date = date or datetime(2026, 4, 18, 15, 30, tzinfo=timezone.utc)
        self.raw_text = raw_text
        self.sender_id = sender_id
        self.reply_to = reply_to
        self.file = file
        self.action = action
        self.fwd_from = fwd_from
        self.reactions = reactions
        self.media = media
        self.edit_date = edit_date
        self.post_author = post_author
        self.forward = forward
        self.entities = entities or []
        self.sticker = sticker
        self.photo = photo
        self.video = video
        self.voice = voice
        self.video_note = video_note
        self.audio = audio
        self.gif = gif
        self.poll = poll
        self.contact = contact
        self.venue = venue
        self.web_preview = web_preview
        self.document = document
        self.message = raw_text


class MessageActionChatEditTitle:
    def __init__(self, title):
        self.title = title


class MessageMediaGeo:
    pass


class RecordingWriter(io.StringIO):
    def __init__(self) -> None:
        super().__init__()
        self.calls: list[str] = []

    def write(self, text: str) -> int:
        self.calls.append(text)
        return super().write(text)
