from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

from telethon.tl import types as telethon_types

from tests.helpers import ExportTestCase
from tests.stubs import (
    MessageActionChatEditTitle,
    MessageMediaGeo,
    StubClient,
    StubMessage,
    StubSender,
)


class MetadataTests(ExportTestCase):
    async def test_reply_preview_uses_resolved_reply_text(self):
        original = StubMessage(
            10,
            sender=StubSender(first_name="Alice"),
            raw_text="Original context",
        )
        reply = StubMessage(
            11,
            sender=StubSender(first_name="Bob"),
            raw_text="Reply message",
            reply_to=SimpleNamespace(reply_to_msg_id=10),
        )
        client = StubClient(
            SimpleNamespace(title="Replies"),
            [reply],
            reply_messages={10: original},
        )

        _, _, content = await self.export_to_path(client, filename="nested/replies.md")

        self.assertEqual(client.get_messages_calls, [[10]])
        self.assertEqual(
            content,
            "# Replies\n\n"
            "## 2026-04-18\n\n"
            "### Bob · 15:30\n"
            '- Reply to: "Original context"\n\n'
            "Reply message\n",
        )

    async def test_reply_preview_escapes_markdown_once(self):
        original = StubMessage(
            10,
            sender=StubSender(first_name="Alice"),
            raw_text="те_ст",
        )
        reply = StubMessage(
            11,
            sender=StubSender(first_name="Bob"),
            raw_text="Reply message",
            reply_to=SimpleNamespace(reply_to_msg_id=10),
        )
        client = StubClient(
            SimpleNamespace(title="Replies"),
            [reply],
            reply_messages={10: original},
        )

        _, _, content = await self.export_to_path(client, filename="reply-escape.md")

        self.assertIn('- Reply to: "те\\_ст"\n', content)
        self.assertNotIn('- Reply to: "те\\\\_ст"\n', content)

    async def test_reply_preview_falls_back_to_content_summary(self):
        photo_message = StubMessage(
            20,
            sender=StubSender(first_name="Alice"),
            raw_text="",
            photo=object(),
            file=SimpleNamespace(name=None),
        )
        reply = StubMessage(
            21,
            sender=StubSender(first_name="Bob"),
            raw_text="Nice one",
            reply_to=SimpleNamespace(reply_to_msg_id=20),
        )
        client = StubClient(
            SimpleNamespace(title="Photos"),
            [reply],
            reply_messages={20: photo_message},
        )

        _, _, content = await self.export_to_path(client, filename="photos.md")

        self.assertEqual(
            content,
            "# Photos\n\n"
            "## 2026-04-18\n\n"
            "### Bob · 15:30\n"
            "- Reply to: Photo\n\n"
            "Nice one\n",
        )

    async def test_reply_preview_uses_plain_text_when_original_message_has_entities(self):
        original = StubMessage(
            10,
            sender=StubSender(first_name="Alice"),
            raw_text="Bold text",
            entities=[telethon_types.MessageEntityBold(offset=0, length=4)],
        )
        reply = StubMessage(
            11,
            sender=StubSender(first_name="Bob"),
            raw_text="Reply message",
            reply_to=SimpleNamespace(reply_to_msg_id=10),
        )
        client = StubClient(
            SimpleNamespace(title="Replies"),
            [reply],
            reply_messages={10: original},
        )

        _, _, content = await self.export_to_path(
            client, filename="reply-plain-preview.md"
        )

        self.assertIn('- Reply to: "Bold text"\n', content)
        self.assertNotIn('- Reply to: "**Bold** text"\n', content)

    async def test_metadata_rows_are_sorted_logically(self):
        sticker = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text="",
            sticker=object(),
            file=SimpleNamespace(emoji="🙂"),
        )
        file_message = StubMessage(
            2,
            sender=StubSender(first_name="Bob"),
            raw_text="See attachment",
            document=object(),
            file=SimpleNamespace(name="report.pdf"),
            fwd_from=SimpleNamespace(from_name="Archive"),
            reactions=SimpleNamespace(
                results=[
                    SimpleNamespace(reaction=SimpleNamespace(emoticon="👍"), count=3),
                    SimpleNamespace(reaction=SimpleNamespace(emoticon="❤️"), count=1),
                ]
            ),
            edit_date=datetime(2026, 4, 18, 16, 0, tzinfo=timezone.utc),
        )
        poll_message = StubMessage(
            3,
            sender=StubSender(first_name="Cara"),
            raw_text="",
            poll=SimpleNamespace(
                poll=SimpleNamespace(
                    question="Weekend plans?",
                    answers=[
                        SimpleNamespace(text="Stay in"),
                        SimpleNamespace(text="Go out"),
                    ],
                )
            ),
        )
        service = StubMessage(
            4,
            sender=StubSender(first_name="Dora"),
            raw_text="",
            action=MessageActionChatEditTitle("Roadmap"),
        )
        location = StubMessage(
            5,
            sender=StubSender(first_name="Evan"),
            raw_text="",
            media=MessageMediaGeo(),
        )
        client = StubClient(
            SimpleNamespace(title="Mixed"),
            [location, service, poll_message, file_message, sticker],
        )

        _, _, content = await self.export_to_path(client, filename="mixed.md")

        self.assertEqual(
            content,
            "# Mixed\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n"
            "- Attached sticker: 🙂\n\n"
            "### Bob · 15:30\n"
            "- Forwarded from: Archive\n"
            "- Attached file: report.pdf\n"
            "- Reactions: 👍 3, ❤️ 1\n"
            "- Edited\n\n"
            "See attachment\n\n"
            "### Cara · 15:30\n"
            "- Attached poll: Weekend plans?\n"
            "  - Stay in\n"
            "  - Go out\n\n"
            "### Dora · 15:30\n"
            '- Service: changed the chat title to "Roadmap"\n\n'
            "### Evan · 15:30\n"
            "- Attached location\n",
        )

    async def test_poll_metadata_includes_selected_flags(self):
        poll_message = StubMessage(
            1,
            sender=StubSender(first_name="Cara"),
            raw_text="",
            poll=SimpleNamespace(
                poll=SimpleNamespace(
                    question="Pick a format",
                    answers=[
                        SimpleNamespace(text="Markdown"),
                        SimpleNamespace(text="HTML"),
                    ],
                    quiz=True,
                    multiple_choice=True,
                )
            ),
        )
        client = StubClient(SimpleNamespace(title="Polls"), [poll_message])

        _, _, content = await self.export_to_path(client, filename="poll-flags.md")

        self.assertEqual(
            content,
            "# Polls\n\n"
            "## 2026-04-18\n\n"
            "### Cara · 15:30\n"
            "- Attached poll: Pick a format (Quiz, Multiple choice)\n"
            "  - Markdown\n"
            "  - HTML\n",
        )

    async def test_poll_metadata_escapes_markdown_once(self):
        poll_message = StubMessage(
            1,
            sender=StubSender(first_name="Cara"),
            raw_text="",
            poll=SimpleNamespace(
                question="Road_map *draft* [v1]",
                answers=[
                    SimpleNamespace(text="Alpha_[1]"),
                    SimpleNamespace(text="`Beta`"),
                ],
            ),
        )
        client = StubClient(SimpleNamespace(title="Poll escape"), [poll_message])

        _, _, content = await self.export_to_path(client, filename="poll-escape.md")

        self.assertIn("- Attached poll: Road\\_map \\*draft\\* \\[v1\\]\n", content)
        self.assertIn("  - Alpha\\_\\[1\\]\n", content)
        self.assertIn("  - \\`Beta\\`\n", content)
        self.assertNotIn("Road\\\\_map", content)
        self.assertNotIn("Alpha\\\\_", content)

    async def test_reply_preview_for_poll_uses_single_line_summary(self):
        original = StubMessage(
            10,
            sender=StubSender(first_name="Alice"),
            raw_text="",
            poll=SimpleNamespace(
                poll=SimpleNamespace(
                    question="Weekend plans?",
                    answers=[
                        SimpleNamespace(text="Stay in"),
                        SimpleNamespace(text="Go out"),
                    ],
                )
            ),
        )
        reply = StubMessage(
            11,
            sender=StubSender(first_name="Bob"),
            raw_text="I vote later",
            reply_to=SimpleNamespace(reply_to_msg_id=10),
        )
        client = StubClient(
            SimpleNamespace(title="Replies"),
            [reply],
            reply_messages={10: original},
        )

        _, _, content = await self.export_to_path(client, filename="reply-poll.md")

        self.assertEqual(
            content,
            "# Replies\n\n"
            "## 2026-04-18\n\n"
            "### Bob · 15:30\n"
            "- Reply to: Poll - Weekend plans?\n\n"
            "I vote later\n",
        )

    async def test_service_titles_escape_markdown_once(self):
        service = StubMessage(
            1,
            sender=StubSender(first_name="Dora"),
            raw_text="",
            action=MessageActionChatEditTitle("Road_map"),
        )
        client = StubClient(SimpleNamespace(title="Mixed"), [service])

        _, _, content = await self.export_to_path(client, filename="service-escape.md")

        self.assertIn('- Service: changed the chat title to "Road\\_map"\n', content)
        self.assertNotIn('- Service: changed the chat title to "Road\\\\_map"\n', content)
