from __future__ import annotations

from types import SimpleNamespace

from telethon.tl import types as telethon_types

from tests.helpers import ExportTestCase
from tests.stubs import StubClient, StubMessage, StubSender


class RenderingTests(ExportTestCase):
    async def test_body_text_escapes_markdown_structure_and_inline_syntax(self):
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice", last_name="[*]"),
            raw_text=(
                "# Heading\n## Still heading\n- bullet\n1. number\n| pipe\n```\n---\n"
                "literal *bold* and [x](https://example.com)\nplain"
            ),
        )
        client = StubClient(SimpleNamespace(title="Escapes [demo]"), [message])

        _, _, content = await self.export_to_path(client, filename="escapes.md")

        self.assertEqual(
            content,
            "# Escapes \\[demo\\]\n\n"
            "## 2026-04-18\n\n"
            "### Alice \\[\\*\\] · 15:30\n\n"
            "\\# Heading\n"
            "\\## Still heading\n"
            "\\- bullet\n"
            "\\1. number\n"
            "\\| pipe\n"
            "\\`\\`\\`\n"
            "\\---\n"
            "literal \\*bold\\* and \\[x\\](https://example.com)\n"
            "plain\n",
        )

    async def test_body_text_preserves_leading_and_trailing_blank_lines(self):
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text="\nleading\ntrailing\n",
        )
        client = StubClient(SimpleNamespace(title="Whitespace"), [message])

        _, _, content = await self.export_to_path(client, filename="whitespace.md")

        self.assertEqual(
            content,
            "# Whitespace\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n\n\n"
            "leading\n"
            "trailing\n\n",
        )

    async def test_body_text_preserves_supported_telegram_formatting(self):
        text = "Bold italic strike code link mention"
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text=text,
            entities=[
                telethon_types.MessageEntityBold(offset=0, length=4),
                telethon_types.MessageEntityItalic(offset=5, length=6),
                telethon_types.MessageEntityStrike(offset=12, length=6),
                telethon_types.MessageEntityCode(offset=19, length=4),
                telethon_types.MessageEntityTextUrl(
                    offset=24,
                    length=4,
                    url="https://example.com/a)b",
                ),
                telethon_types.MessageEntityMentionName(offset=29, length=7, user_id=42),
            ],
        )
        client = StubClient(SimpleNamespace(title="Formatting"), [message])

        _, _, content = await self.export_to_path(client, filename="formatting.md")

        self.assertEqual(
            content,
            "# Formatting\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n\n"
            "**Bold** _italic_ ~~strike~~ `code` [link](https://example.com/a\\)b) "
            "[mention](tg://user?id=42)\n",
        )

    async def test_body_text_closes_same_span_entities_in_reverse_order(self):
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text="тест",
            entities=[
                telethon_types.MessageEntityBold(offset=0, length=4),
                telethon_types.MessageEntityItalic(offset=0, length=4),
            ],
        )
        client = StubClient(SimpleNamespace(title="Nested formatting"), [message])

        _, _, content = await self.export_to_path(client, filename="nested-formatting.md")

        self.assertEqual(
            content,
            "# Nested formatting\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n\n"
            "**_тест_**\n",
        )

    async def test_body_text_preserves_literal_markdown_while_rendering_entities(self):
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text="*literal* and # heading and [plain] plus bold",
            entities=[telethon_types.MessageEntityBold(offset=41, length=4)],
        )
        client = StubClient(SimpleNamespace(title="Mixed formatting"), [message])

        _, _, content = await self.export_to_path(client, filename="mixed-formatting.md")

        self.assertEqual(
            content,
            "# Mixed formatting\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n\n"
            "\\*literal\\* and # heading and \\[plain\\] plus **bold**\n",
        )

    async def test_body_text_preserves_fenced_pre_blocks_for_multiline_pre_entities(self):
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text="before\nline1\nline2\nafter",
            entities=[telethon_types.MessageEntityPre(offset=7, length=11, language="python")],
        )
        client = StubClient(SimpleNamespace(title="Pre"), [message])

        _, _, content = await self.export_to_path(client, filename="pre.md")

        self.assertEqual(
            content,
            "# Pre\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n\n"
            "before\n"
            "```python\n"
            "line1\n"
            "line2\n"
            "```\n"
            "after\n",
        )

    async def test_body_text_leaves_unsupported_entities_as_plain_text(self):
        message = StubMessage(
            1,
            sender=StubSender(first_name="Alice"),
            raw_text="underlined",
            entities=[telethon_types.MessageEntityUnderline(offset=0, length=10)],
        )
        client = StubClient(SimpleNamespace(title="Unsupported"), [message])

        _, _, content = await self.export_to_path(client, filename="unsupported.md")

        self.assertEqual(
            content,
            "# Unsupported\n\n"
            "## 2026-04-18\n\n"
            "### Alice · 15:30\n\n"
            "underlined\n",
        )
