# telegram-to-markdown

Convert Telegram chats into human-readable and LLM-friendly Markdown, keeping it simple and informative.

Example output:

```markdown
# Cat Chat

## 2026-04-18

### Luna · 09:12

mrrp~

### Milo · 09:13

coming meow

### Luna · 09:15
- Reply to: "coming meow"

Please bring the box.

### Coco · 09:18
- Forwarded from: Cat Notes
- Attached file: nap-plan.pdf
- Reactions: 👍 2, 😸 1

I shared the plan. Please check **bedroom naps**, _feeding time_, ~~old toy list~~, and [today's tasks](https://example.com/tasks).

### Nala · 09:21
- Attached photo

will be sleeping here

### Luna · 09:24
- Service: changed the chat title to "Sleepy Cat Chat"
```

## Setup

### As dependency


`telegram-to-markdown` is a Telethon package. Install with pip/uv/etc:

```shell
pip install telegram-to-markdown
```

Compatible with [Folds](https://pcraft.dev/folds) bot framework (pass the bot as the client).

### For one-off use

TGPy recommended for running scripts in Telegram :)

1. [Start TGPy](https://tgpy.dev)
2. Install `telegram-to-markdown` to the TGPy environment
3. <details>
   <summary>Run the snippet</summary>
   
   ```python
   from telegram_to_markdown import export
   
   await export(client, msg.chat, 'export.md', limit=100)
   await msg.respond(file='export.md')
   return 'Chat exported!'
   ```
   </details>

## Usage

```python
from telegram_to_markdown import export

await export(client, chat, output_path, limit=1000)
```

- client: Telethon `TelegramClient`
- chat: username/link of any chat or ID/title of a known chat. "me" for saved messages
- output_path: optional output path or writable text stream
- limit: number of recent messages
