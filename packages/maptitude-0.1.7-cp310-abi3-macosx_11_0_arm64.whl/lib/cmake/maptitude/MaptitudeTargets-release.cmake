#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Maptitude::maptitude" for configuration "Release"
set_property(TARGET Maptitude::maptitude APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Maptitude::maptitude PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmaptitude.a"
  )

list(APPEND _cmake_import_check_targets Maptitude::maptitude )
list(APPEND _cmake_import_check_files_for_Maptitude::maptitude "${_IMPORT_PREFIX}/lib/libmaptitude.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
