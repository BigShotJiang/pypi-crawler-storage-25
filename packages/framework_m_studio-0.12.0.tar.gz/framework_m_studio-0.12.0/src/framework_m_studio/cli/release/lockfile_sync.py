"""Lockfile synchronization utilities for release orchestration."""

import shutil
import sys
from pathlib import Path

from framework_m_studio.core.shell import run_cmd


def sync_lockfiles(root: Path) -> None:
    """Synchronize lockfiles for diverse environments."""
    print("📦 Synchronizing lockfiles...")
    if (root / "pnpm-lock.yaml").exists():
        pnpm_bin = shutil.which("pnpm")
        if pnpm_bin:
            try:
                run_cmd([pnpm_bin, "install", "--no-frozen-lockfile"], check=True)
            except Exception as e:
                print(f"Error: pnpm lockfile sync failed: {e}", file=sys.stderr)
                raise
        else:
            raise RuntimeError(
                "pnpm-lock.yaml exists but 'pnpm' tool was not found. "
                "Please install pnpm or ensure it's in your PATH to synchronize lockfiles."
            )

    if (root / "uv.lock").exists() or (root / "pyproject.toml").exists():
        uv_bin = shutil.which("uv")
        if uv_bin:
            try:
                run_cmd([uv_bin, "lock"], check=True)
            except Exception as e:
                print(f"Error: uv lockfile sync failed: {e}", file=sys.stderr)
                raise
        else:
            # Only fail on uv if we explicitly have a uv.lock or need to generate one
            if (root / "uv.lock").exists():
                raise RuntimeError(
                    "uv.lock exists but 'uv' tool was not found. "
                    "Please install uv or ensure it's in your PATH to synchronize lockfiles."
                )
