"""Dependency Management CLI."""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Annotated

import cyclopts

from framework_m_studio.core.gitops import GitLabProvider
from framework_m_studio.core.shell import run_cmd

deps_app = cyclopts.App(name="deps", help="Manage dependencies and upgrades")


def _check_uv_outdated(root: Path) -> list[dict[str, str]]:
    """Parse uv pip list --outdated output."""
    output = run_cmd("uv pip list --outdated", cwd=root, check=False)
    outdated: list[dict[str, str]] = []
    for line in output.splitlines():
        parts = line.split()
        if (
            len(parts) >= 3
            and not line.startswith("Package")
            and not line.startswith("---")
        ):
            outdated.append({"name": parts[0], "current": parts[1], "latest": parts[2]})
    return outdated


def _check_pnpm_outdated(root: Path) -> list[dict[str, str]]:
    """Parse pnpm outdated -r --format json output."""
    output = run_cmd("pnpm outdated -r --format json", cwd=root, check=False)
    outdated: list[dict[str, str]] = []
    if not output:
        return outdated
    try:
        data = json.loads(output)
        if isinstance(data, dict):
            for pkg_name, details in data.items():
                outdated.append(
                    {
                        "name": pkg_name,
                        "current": details.get("current", ""),
                        "latest": details.get("latest", ""),
                    }
                )
    except json.JSONDecodeError:  # pragma: no cover
        pass  # pragma: no cover
    return outdated


def _get_workspace_projects(
    root: Path,
    manager: str,
    base_dirs: list[str] | None = None,
    updated_packages: list[str] | None = None,
) -> list[str]:
    """Get all workspace projects from the given base directories that depend on updated_packages."""
    projects = []

    # If no specific packages were updated, we can't easily filter
    if not updated_packages:
        return []

    for base_dir in base_dirs or ["apps", "libs"]:
        dir_path = root / base_dir
        if not dir_path.exists():
            continue

        for item in dir_path.iterdir():
            if not item.is_dir() or item.name.startswith("."):
                continue

            if manager == "uv":
                pyproject = item / "pyproject.toml"
                if pyproject.exists():
                    try:
                        content = pyproject.read_text()
                        # Check if this project depends on any of the updated packages
                        # We check for '"pkg-name"' or 'pkg-name>=' to avoid partial matches
                        has_dep = False
                        for pkg in updated_packages:
                            if (
                                f'"{pkg}"' in content
                                or f"'{pkg}'" in content
                                or f"{pkg}>=" in content
                            ):
                                has_dep = True
                                break

                        if has_dep:
                            for line in content.splitlines():
                                if line.startswith("name ="):
                                    proj_name = (
                                        line.split("=", 1)[1]
                                        .strip()
                                        .strip('"')
                                        .strip("'")
                                    )
                                    projects.append(proj_name)
                                    break
                    except Exception:  # pragma: no cover
                        pass  # pragma: no cover
            elif manager == "pnpm":
                pkg_json = item / "package.json"
                if pkg_json.exists():
                    try:
                        data = json.loads(pkg_json.read_text())
                        # Check all dependency types
                        all_deps = {
                            **data.get("dependencies", {}),
                            **data.get("devDependencies", {}),
                            **data.get("peerDependencies", {}),
                        }

                        if (
                            any(pkg in all_deps for pkg in updated_packages)
                            and "name" in data
                        ):
                            projects.append(data["name"])
                    except Exception:  # pragma: no cover
                        pass  # pragma: no cover
    return sorted(set(projects))


def _push_branch(branch: str, token: str) -> None:
    """Push branch to origin."""
    host = os.environ.get("CI_SERVER_HOST", "gitlab.com")
    path = os.environ.get("CI_PROJECT_PATH", "")
    remote = f"https://oauth2:{token}@{host}/{path}.git"
    run_cmd(f"git remote set-url origin {remote}")
    run_cmd(f"git push origin {branch}")


@deps_app.command(name="check")
def deps_check_command(
    manager: Annotated[
        str | None, cyclopts.Parameter(name="--manager", help="uv or pnpm")
    ] = None,
    root: Annotated[
        str | None, cyclopts.Parameter(name="--root", help="Project root directory")
    ] = None,
    json_output: Annotated[
        bool, cyclopts.Parameter(name="--json", help="Output as JSON")
    ] = False,
) -> None:
    """Check for outdated dependencies."""
    root_path = Path(root) if root else Path.cwd()
    outdated: list[dict[str, str]] = []

    if manager in (None, "uv"):
        outdated.extend(_check_uv_outdated(root_path))

    if manager in (None, "pnpm"):
        outdated.extend(_check_pnpm_outdated(root_path))

    if json_output:
        print(json.dumps(outdated, indent=2))
        return

    for pkg in outdated:
        print(f"📦 {pkg['name']}: {pkg['current']} -> {pkg['latest']}")


@deps_app.command(name="upgrade")
async def deps_upgrade_command(
    package: Annotated[
        str | None,
        cyclopts.Parameter(name="package", help="Package to upgrade (omit for all)"),
    ] = None,
    manager: Annotated[
        str, cyclopts.Parameter(name="--manager", help="uv or pnpm")
    ] = "uv",
    provider: Annotated[
        str, cyclopts.Parameter(name="--provider", help="Git provider")
    ] = "gitlab",
    token: Annotated[
        str | None, cyclopts.Parameter(name="--token", help="Provider token")
    ] = None,
    project_id: Annotated[
        str | None, cyclopts.Parameter(name="--project-id", help="Provider project ID")
    ] = None,
    dry_run: Annotated[
        bool, cyclopts.Parameter(name="--dry-run", help="Skip branch creation and MR")
    ] = False,
    root: Annotated[
        str | None, cyclopts.Parameter(name="--root", help="Project root directory")
    ] = None,
    skip_branch: Annotated[
        bool,
        cyclopts.Parameter(
            name="--skip-branch", help="Skip branch creation, keep changes unstaged"
        ),
    ] = False,
    dirs: Annotated[
        list[str] | None,
        cyclopts.Parameter(
            name="--dirs",
            help="Base directories to discover workspace projects [default: apps libs]",
        ),
    ] = None,
) -> None:
    """Upgrade a dependency and create a merge request."""
    root_path = Path(root) if root else Path.cwd()
    final_token = (
        token
        or os.environ.get("CITADEL_CI_TOKEN")
        or os.environ.get("GITLAB_TOKEN")
        or ""
    )
    final_project_id = project_id or os.environ.get("CI_PROJECT_ID") or ""

    # Check for changes in lockfiles and git status
    uv_lock = root_path / "uv.lock"
    pnpm_lock = root_path / "pnpm-lock.yaml"

    uv_mtime = uv_lock.stat().st_mtime if uv_lock.exists() else 0
    pnpm_mtime = pnpm_lock.stat().st_mtime if pnpm_lock.exists() else 0

    outdated: list[dict[str, str]] = []

    if not package:
        print(f"Checking for all outdated packages using {manager}...")
        if manager == "uv":
            outdated = _check_uv_outdated(root_path)
            packages_to_upgrade = [pkg["name"] for pkg in outdated]
            if not packages_to_upgrade:
                print("All uv dependencies are up to date.")
                return

            print(f"Upgrading {len(packages_to_upgrade)} packages...")
            pkg_args = " ".join(
                [f"--upgrade-package {pkg}" for pkg in packages_to_upgrade]
            )
            run_cmd(f"uv lock {pkg_args}", cwd=root_path)
        elif manager == "pnpm":
            outdated = _check_pnpm_outdated(root_path)
            run_cmd("pnpm update -r", cwd=root_path)
            print("Running pnpm audit fix...")
            run_cmd("pnpm audit fix", cwd=root_path, check=False)
        else:  # pragma: no cover
            print(f"Unknown manager: {manager}", file=sys.stderr)  # pragma: no cover
            return  # pragma: no cover
        package = "all"
    else:
        if manager == "uv":
            run_cmd(f"uv lock --upgrade-package {package}", cwd=root_path)
        elif manager == "pnpm":
            run_cmd(f"pnpm update -r {package}", cwd=root_path)
        else:  # pragma: no cover
            print(f"Unknown manager: {manager}", file=sys.stderr)  # pragma: no cover
            return  # pragma: no cover

    # Check if anything actually changed
    new_uv_mtime = uv_lock.stat().st_mtime if uv_lock.exists() else 0
    new_pnpm_mtime = pnpm_lock.stat().st_mtime if pnpm_lock.exists() else 0

    lock_changed = (new_uv_mtime != uv_mtime) or (new_pnpm_mtime != pnpm_mtime)
    git_status = run_cmd("git status --short", cwd=root_path)

    if not (git_status or lock_changed):
        print(f"No changes found after updating {package or 'all'}. Skipping MR.")
        return

    # Generate commit message and discover affected projects
    if package == "all":
        mr_title = f"fix({manager}): update dependencies"
        body = f"Automated upgrade of all {manager} dependencies."
    else:
        mr_title = f"fix({manager}): update {package}"
        body = f"Automated upgrade of {package}."

    # Discovery
    updated_pkgs = [package] if package != "all" else [pkg["name"] for pkg in outdated]
    projects = _get_workspace_projects(root_path, manager, dirs, updated_pkgs)
    if projects:
        releases = ", ".join(projects)
        body += f"\n\nReleases: {releases}"

    if dry_run or skip_branch:
        if dry_run:
            print("\n[DRY RUN] Would create MR:")
            print(f"Title: {mr_title}")
            print(f"Body:\n{body}\n")
        else:
            print("Changes applied to lockfiles. skipping branch/commit as requested.")
        return

    # Create and switch to new branch
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    branch_name = f"deps/{manager}-{package or 'all'}-{timestamp}"

    # Check for existing branch and delete it
    run_cmd(f"git branch -D {branch_name}", cwd=root_path, check=False)
    run_cmd(f"git checkout -b {branch_name}", cwd=root_path)

    # Force add lockfiles if they are ignored
    if manager == "uv":
        run_cmd("git add -f uv.lock", cwd=root_path, check=False)
    elif manager == "pnpm":
        run_cmd("git add -f pnpm-lock.yaml", cwd=root_path, check=False)

    run_cmd("git add .", cwd=root_path)

    run_cmd(["git", "commit", "-m", mr_title, "-m", body], cwd=root_path)

    if final_token:
        _push_branch(branch_name, final_token)

        if provider == "gitlab" and final_project_id:
            client = GitLabProvider(token=final_token, project_id=final_project_id)
            await client.create_mr(
                title=mr_title,
                description=body,
                source_branch=branch_name,
                target_branch="main",
            )
    else:
        print("Skipping push and MR: No token provided.", file=sys.stderr)

    run_cmd("git checkout main", cwd=root_path)


__all__ = ["deps_app", "deps_check_command", "deps_upgrade_command"]
