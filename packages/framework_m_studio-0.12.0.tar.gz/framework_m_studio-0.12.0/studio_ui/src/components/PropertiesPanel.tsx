import React, { useState } from "react";
import { FieldEditor, type FieldData, type FieldTypeInfo } from "./FieldEditor";
import type { DocTypeSchema, SelectedNode, FormSection, FormTab } from "../pages/doctypes/edit";

export interface PropertiesPanelProps {
  doctype: DocTypeSchema;
  setDoctype: React.Dispatch<React.SetStateAction<DocTypeSchema>>;
  selectedNode: SelectedNode | null;
  onSelectNode: (node: SelectedNode | null) => void;
  fieldTypes: FieldTypeInfo[];
  availableDocTypes: string[];
  handleFieldChange: (updatedField: FieldData) => void;
  handleAddField: () => void;
  isDark: boolean;
}

export function PropertiesPanel({
  doctype,
  setDoctype,
  selectedNode,
  onSelectNode,
  fieldTypes,
  availableDocTypes,
  handleFieldChange,
  handleAddField,
  isDark,
}: PropertiesPanelProps) {
  const [isCollapsed, setIsCollapsed] = useState(true);

  const renderEditor = () => {
    if (!selectedNode) {
      return (
        <div className={`text-center py-8 px-4 text-sm ${isDark ? "text-zinc-500" : "text-gray-500"}`}>
          Select a field, section, or tab on the canvas to edit its properties, or add a new field.
        </div>
      );
    }

    if (selectedNode.type === "field") {
      const fieldIndex = selectedNode.index;
      if (fieldIndex !== null && fieldIndex >= 0 && doctype.fields[fieldIndex]) {
        const fieldName = doctype.fields[fieldIndex].name;
        const field = doctype.fields[fieldIndex];
        return (
          <div className="flex flex-col">
            <FieldEditor
              key={`field-${fieldIndex}`}
              field={field}
              fieldTypes={fieldTypes}
              availableDocTypes={availableDocTypes}
              onChange={handleFieldChange}
            />
            <div className={`p-3 border-t space-y-3 ${isDark ? "border-zinc-700" : "border-gray-200"}`}>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white">UI Metadata</h3>
              <div>
                <label htmlFor="ui-widget-select" className="block text-xs font-medium mb-1 text-gray-700 dark:text-zinc-300">UI Widget</label>
                <select
                  id="ui-widget-select"
                  value={field.ui_widget || ""}
                  onChange={(e) => handleFieldChange({ ...field, ui_widget: e.target.value })}
                  className={`w-full px-2 py-1 rounded-md border text-sm ${isDark ? "bg-zinc-800 border-zinc-700 text-white focus:ring-blue-500 focus:border-blue-500 outline-none" : "bg-white border-gray-300 text-gray-900 focus:ring-blue-500 focus:border-blue-500 outline-none"}`}
                >
                  <option value="">Default Widget</option>
                  <option value="RadioGroup">RadioGroup</option>
                  <option value="Select">Select</option>
                  <option value="Combobox">Combobox</option>
                  <option value="Textarea">Textarea</option>
                  <option value="Password">Password</option>
                  <option value="DatePicker">DatePicker</option>
                </select>
              </div>
            </div>
            <FieldLocationEditor doctype={doctype} setDoctype={setDoctype} fieldName={fieldName} isDark={isDark} />
          </div>
        );
      }
    }

    if (selectedNode.type === "section") {
      return <SectionEditor key={`sec-${selectedNode.tabIndex}-${selectedNode.sectionIndex}`} doctype={doctype} setDoctype={setDoctype} selectedNode={selectedNode} onSelectNode={onSelectNode} isDark={isDark} />;
    }

    if (selectedNode.type === "tab") {
      return <TabEditor key={`tab-${selectedNode.tabIndex}`} doctype={doctype} setDoctype={setDoctype} selectedNode={selectedNode} onSelectNode={onSelectNode} isDark={isDark} />;
    }

    return null;
  };

  return (
    <div
      className={`transition-all duration-300 ease-in-out border-l flex flex-col shrink-0 ${
        isCollapsed ? "w-12" : "w-72 lg:w-80"
      } ${
        isDark ? "border-zinc-700 bg-zinc-900/50" : "border-gray-200 bg-white"
      }`}
    >
      <div
        className={`h-12 border-b flex items-center whitespace-nowrap overflow-hidden ${
          isCollapsed ? "justify-center px-2" : "justify-between px-4"
        } ${
          isDark ? "border-zinc-700" : "border-gray-200"
        }`}
      >
        {!isCollapsed && (
          <h2 className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}>
            Properties
          </h2>
        )}
        <div className="flex items-center gap-2">
          {!isCollapsed && (
            <button onClick={handleAddField} className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded-md transition-colors shadow-sm">
              + Add
            </button>
          )}
          <button onClick={() => setIsCollapsed(!isCollapsed)} className={`p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-zinc-800 transition-colors ${isDark ? "text-zinc-400" : "text-gray-500"}`} title={isCollapsed ? "Expand Properties" : "Collapse Properties"}>
            <svg className={`w-5 h-5 transition-transform duration-300 ${isCollapsed ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg>
          </button>
        </div>
      </div>
      <div className={`flex-1 overflow-y-auto p-3 ${isCollapsed ? "hidden" : "block"}`}>
        {renderEditor()}
      </div>
    </div>
  );
}

interface FieldLocationEditorProps {
  doctype: DocTypeSchema;
  setDoctype: React.Dispatch<React.SetStateAction<DocTypeSchema>>;
  fieldName: string;
  isDark: boolean;
}

function FieldLocationEditor({ doctype, setDoctype, fieldName, isDark }: FieldLocationEditorProps) {
  const form = doctype.meta?.ui_meta?.form || { layout: "sections", sections: [] };
  const isTabs = form.layout === "tabs";

  let currentTabIdx = -1;
  let currentSecIdx = -1;

  if (isTabs) {
    (form.tabs || []).forEach((tab: FormTab, tIdx: number) => {
      (tab.sections || []).forEach((sec: FormSection, sIdx: number) => {
        if (sec.fields?.includes(fieldName)) {
          currentTabIdx = tIdx;
          currentSecIdx = sIdx;
        }
      });
    });
  } else {
    (form.sections || []).forEach((sec: FormSection, sIdx: number) => {
      if (sec.fields?.includes(fieldName)) {
        currentSecIdx = sIdx;
      }
    });
  }

  const moveField = (targetTabIdx: number, targetSecIdx: number) => {
    setDoctype((prev: DocTypeSchema) => {
      const newForm = JSON.parse(JSON.stringify(prev.meta?.ui_meta?.form || { layout: "sections", sections: [] }));

      const clearSections = (secs: FormSection[]) => secs.forEach((s: FormSection) => {
        if (s.fields) s.fields = s.fields.filter((name: string) => name !== fieldName);
      });

      if (newForm.layout === "tabs") {
        newForm.tabs?.forEach((t: FormTab) => clearSections(t.sections || []));
        const tabs = newForm.tabs || [];
        if (tabs[targetTabIdx]) {
          tabs[targetTabIdx].sections = tabs[targetTabIdx].sections || [];
          if (!tabs[targetTabIdx].sections[targetSecIdx]) {
            tabs[targetTabIdx].sections[targetSecIdx] = { label: "New Section", fields: [], columns: 1 };
          }
          tabs[targetTabIdx].sections[targetSecIdx].fields = tabs[targetTabIdx].sections[targetSecIdx].fields || [];
          tabs[targetTabIdx].sections[targetSecIdx].fields.push(fieldName);
        }
      } else {
        clearSections(newForm.sections || []);
        const sections = newForm.sections || [];
        if (sections[targetSecIdx]) {
          sections[targetSecIdx].fields = sections[targetSecIdx].fields || [];
          sections[targetSecIdx].fields.push(fieldName);
        } else if (sections.length === 0) {
          sections.push({ label: "New Section", fields: [fieldName], columns: 1 });
        }
      }

      return { ...prev, meta: { ...prev.meta, ui_meta: { ...prev.meta?.ui_meta, form: newForm } } };
    });
  };

  const selectClasses = `w-full px-2 py-1 rounded-md border text-sm ${isDark ? "bg-zinc-800 border-zinc-700 text-white focus:ring-blue-500 focus:border-blue-500 outline-none" : "bg-white border-gray-300 text-gray-900 focus:ring-blue-500 focus:border-blue-500 outline-none"}`;
  const safeTabIdx = Math.max(0, currentTabIdx);
  const safeSecIdx = Math.max(0, currentSecIdx);

  return (
    <div className={`p-3 border-t space-y-3 ${isDark ? "border-zinc-700" : "border-gray-200"}`}>
      <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Layout Position</h3>
      {isTabs && (
        <div>
          <label className="block text-xs font-medium mb-1 text-gray-700 dark:text-zinc-300">Tab</label>
          <select value={safeTabIdx} onChange={(e) => moveField(parseInt(e.target.value), 0)} className={selectClasses}>
            {(form.tabs || []).map((tab: FormTab, idx: number) => (
              <option key={idx} value={idx}>{tab.label || `Tab ${idx + 1}`}</option>
            ))}
          </select>
        </div>
      )}
      <div>
        <label className="block text-xs font-medium mb-1 text-gray-700 dark:text-zinc-300">Section</label>
        <select value={safeSecIdx} onChange={(e) => moveField(safeTabIdx, parseInt(e.target.value))} className={selectClasses}>
          {((isTabs ? form.tabs?.[safeTabIdx]?.sections : form.sections) || []).map((sec: FormSection, idx: number) => (
            <option key={idx} value={idx}>{sec.label || `Section ${idx + 1}`}</option>
          ))}
        </select>
      </div>
    </div>
  );
}

interface SectionEditorProps {
  doctype: DocTypeSchema;
  setDoctype: React.Dispatch<React.SetStateAction<DocTypeSchema>>;
  selectedNode: { type: "section"; tabIndex?: number; sectionIndex: number };
  onSelectNode: (node: SelectedNode | null) => void;
  isDark: boolean;
}

function SectionEditor({ doctype, setDoctype, selectedNode, onSelectNode, isDark }: SectionEditorProps) {
  const form = doctype.meta?.ui_meta?.form || {};
  const isTabs = form.layout === "tabs";
  const section = isTabs
    ? form.tabs?.[selectedNode.tabIndex as number]?.sections?.[selectedNode.sectionIndex]
    : form.sections?.[selectedNode.sectionIndex];

  if (!section) return null;

  const updateSection = (updates: Partial<FormSection>) => {
    setDoctype((prev: DocTypeSchema) => {
      const newForm = JSON.parse(JSON.stringify(prev.meta?.ui_meta?.form || {}));
      const targetSection = newForm.layout === "tabs"
        ? newForm.tabs?.[selectedNode.tabIndex as number]?.sections?.[selectedNode.sectionIndex]
        : newForm.sections?.[selectedNode.sectionIndex];
      if (targetSection) {
        Object.assign(targetSection, updates);
      }
      return { ...prev, meta: { ...prev.meta, ui_meta: { ...prev.meta?.ui_meta, form: newForm } } };
    });
  };

  const validFields = doctype.fields.map((f: FieldData) => f.name);
  const activeFields = (section.fields || []).filter((fName: string) => validFields.includes(fName));
  const isEmpty = activeFields.length === 0;

  const handleDelete = () => {
    setDoctype((prev: DocTypeSchema) => {
      const newForm = JSON.parse(JSON.stringify(prev.meta?.ui_meta?.form || {}));
      if (newForm.layout === "tabs") {
        newForm.tabs?.[selectedNode.tabIndex as number]?.sections?.splice(selectedNode.sectionIndex, 1);
      } else {
        newForm.sections?.splice(selectedNode.sectionIndex, 1);
      }
      return { ...prev, meta: { ...prev.meta, ui_meta: { ...prev.meta?.ui_meta, form: newForm } } };
    });
    onSelectNode(null);
  };

  const inputClass = `w-full px-2 py-1 rounded-md border text-sm ${isDark ? "bg-zinc-800 border-zinc-700 text-white focus:ring-blue-500 focus:border-blue-500 outline-none" : "bg-white border-gray-300 text-gray-900 focus:ring-blue-500 focus:border-blue-500 outline-none"}`;

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Section Properties</h3>
      <div>
        <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-zinc-300">Label</label>
        <input type="text" value={section.label || ""} onChange={e => updateSection({ label: e.target.value })} className={inputClass} placeholder="Section Label" />
      </div>
      <div>
        <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-zinc-300">Columns</label>
        <select value={section.columns || 1} onChange={e => updateSection({ columns: parseInt(e.target.value, 10) as 1 | 2 | 3 })} className={inputClass}>
          <option value={1}>1 Column</option>
          <option value={2}>2 Columns</option>
          <option value={3}>3 Columns</option>
        </select>
      </div>
      <div className="flex items-center gap-2 mt-4">
        <input type="checkbox" id="collapsible" checked={!!section.collapsible} onChange={e => updateSection({ collapsible: e.target.checked })} className="w-4 h-4 text-blue-600 rounded border-gray-300" />
        <label htmlFor="collapsible" className="text-sm font-medium text-gray-700 dark:text-zinc-300">Collapsible</label>
      </div>
      {section.collapsible && (
        <div className="flex items-center gap-2 mt-2 ml-6">
          <input type="checkbox" id="collapsed_by_default" checked={!!section.collapsed_by_default} onChange={e => updateSection({ collapsed_by_default: e.target.checked })} className="w-4 h-4 text-blue-600 rounded border-gray-300" />
          <label htmlFor="collapsed_by_default" className="text-sm text-gray-700 dark:text-zinc-300">Collapsed by Default</label>
        </div>
      )}
      <div className={`pt-4 border-t ${isDark ? "border-zinc-700" : "border-gray-200"}`}>
        <button onClick={handleDelete} disabled={!isEmpty} className={`w-full px-3 py-2 text-sm font-medium rounded-lg transition-colors ${isEmpty ? "text-red-600 bg-red-50 hover:bg-red-100 dark:text-red-400 dark:bg-red-900/20 dark:hover:bg-red-900/40" : "text-gray-400 bg-gray-100 dark:text-zinc-500 dark:bg-zinc-800 cursor-not-allowed"}`}>
          {isEmpty ? "Delete Section" : "Remove all fields to delete section"}
        </button>
      </div>
    </div>
  );
}

interface TabEditorProps {
  doctype: DocTypeSchema;
  setDoctype: React.Dispatch<React.SetStateAction<DocTypeSchema>>;
  selectedNode: { type: "tab"; tabIndex: number };
  onSelectNode: (node: SelectedNode | null) => void;
  isDark: boolean;
}

function TabEditor({ doctype, setDoctype, selectedNode, onSelectNode, isDark }: TabEditorProps) {
  const form = doctype.meta?.ui_meta?.form || {};
  const tab = form.tabs?.[selectedNode.tabIndex];

  if (!tab) return null;

  const updateTab = (updates: Partial<FormTab>) => {
    setDoctype((prev: DocTypeSchema) => {
      const newForm = JSON.parse(JSON.stringify(prev.meta?.ui_meta?.form || {}));
      const targetTab = newForm.tabs?.[selectedNode.tabIndex];
      if (targetTab) {
        Object.assign(targetTab, updates);
      }
      return { ...prev, meta: { ...prev.meta, ui_meta: { ...prev.meta?.ui_meta, form: newForm } } };
    });
  };

  const validFields = doctype.fields.map((f: FieldData) => f.name);
  const isEmpty = !tab.sections || tab.sections.length === 0 || tab.sections.every((s: FormSection) => {
    const activeFields = (s.fields || []).filter((fName: string) => validFields.includes(fName));
    return activeFields.length === 0;
  });

  const handleDelete = () => {
    setDoctype((prev: DocTypeSchema) => {
      const newForm = JSON.parse(JSON.stringify(prev.meta?.ui_meta?.form || {}));
      newForm.tabs?.splice(selectedNode.tabIndex, 1);
      return { ...prev, meta: { ...prev.meta, ui_meta: { ...prev.meta?.ui_meta, form: newForm } } };
    });
    onSelectNode(null);
  };

  const inputClass = `w-full px-2 py-1 rounded-md border text-sm ${isDark ? "bg-zinc-800 border-zinc-700 text-white focus:ring-blue-500 focus:border-blue-500 outline-none" : "bg-white border-gray-300 text-gray-900 focus:ring-blue-500 focus:border-blue-500 outline-none"}`;

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Tab Properties</h3>
      <div>
        <label className="block text-sm font-medium mb-1 text-gray-700 dark:text-zinc-300">Label</label>
        <input type="text" value={tab.label || ""} onChange={e => updateTab({ label: e.target.value })} className={inputClass} placeholder="Tab Label" />
      </div>
      <div className={`pt-4 border-t ${isDark ? "border-zinc-700" : "border-gray-200"}`}>
        <button onClick={handleDelete} disabled={!isEmpty} className={`w-full px-3 py-2 text-sm font-medium rounded-lg transition-colors ${isEmpty ? "text-red-600 bg-red-50 hover:bg-red-100 dark:text-red-400 dark:bg-red-900/20 dark:hover:bg-red-900/40" : "text-gray-400 bg-gray-100 dark:text-zinc-500 dark:bg-zinc-800 cursor-not-allowed"}`}>
          {isEmpty ? "Delete Tab" : "Remove all sections/fields to delete tab"}
        </button>
      </div>
    </div>
  );
}