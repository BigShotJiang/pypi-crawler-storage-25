"""Tests for Quality CLI Commands - Comprehensive Integration Coverage."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestQualityImport:
    """Tests for quality module imports."""

    def test_import_test_command(self) -> None:
        """test_command should be importable."""
        from framework_m_studio.cli.quality import test_command

        assert test_command is not None

    def test_import_lint_command(self) -> None:
        """lint_command should be importable."""
        from framework_m_studio.cli.quality import lint_command

        assert lint_command is not None

    def test_import_format_command(self) -> None:
        """format_command should be importable."""
        from framework_m_studio.cli.quality import format_command

        assert format_command is not None

    def test_import_typecheck_command(self) -> None:
        """typecheck_command should be importable."""
        from framework_m_studio.cli.quality import typecheck_command

        assert typecheck_command is not None

    def test_import_security_command(self) -> None:
        """security_command should be importable."""
        from framework_m_studio.cli.quality import security_command

        assert security_command is not None

    def test_import_verify_doc_numbering(self) -> None:
        """verify_doc_numbering should be importable."""
        from framework_m_studio.cli.quality import verify_doc_numbering

        assert verify_doc_numbering is not None


class TestGetPythonPath:
    """Tests for get_pythonpath function."""

    def test_get_pythonpath_returns_string(self) -> None:
        """get_pythonpath should return a string."""
        from framework_m_studio.cli.quality import get_pythonpath

        result = get_pythonpath()
        assert isinstance(result, str)

    def test_get_pythonpath_includes_cwd(self) -> None:
        """get_pythonpath should include current directory."""
        from framework_m_studio.cli.quality import get_pythonpath

        result = get_pythonpath()
        cwd = str(Path.cwd())
        assert cwd in result

    def test_get_pythonpath_includes_src(self, tmp_path: Path) -> None:
        """get_pythonpath should include src if it exists."""
        from framework_m_studio.cli.quality import get_pythonpath

        src_path = tmp_path / "src"
        src_path.mkdir()

        with patch("framework_m_studio.cli.quality.Path.cwd", return_value=tmp_path):
            result = get_pythonpath()

        assert str(src_path) in result

    def test_get_pythonpath_no_src(self, tmp_path: Path) -> None:
        """get_pythonpath should handle missing src directory."""
        from framework_m_studio.cli.quality import get_pythonpath

        with patch("framework_m_studio.cli.quality.Path.cwd", return_value=tmp_path):
            result = get_pythonpath()

        assert str(tmp_path / "src") not in result


class TestRunCommand:
    """Tests for _run_command internal helper."""

    def test_run_command_no_existing_pythonpath(self, tmp_path: Path) -> None:
        """_run_command should work without existing PYTHONPATH."""
        from framework_m_studio.cli.quality import _run_command

        with (
            patch.dict("os.environ", {}, clear=True),
            patch("framework_m_studio.cli.quality.run_cmd") as mock_run,
            pytest.raises(SystemExit),
        ):
            _run_command(["echo"], cwd=tmp_path)

        assert "PYTHONPATH" in mock_run.call_args.kwargs["env"]

    def test_run_command_called_process_error(self) -> None:
        """_run_command should catch CalledProcessError and exit with its code."""
        from framework_m_studio.cli.quality import _run_command

        with patch(
            "framework_m_studio.cli.quality.run_cmd",
            side_effect=subprocess.CalledProcessError(42, []),
        ):
            with pytest.raises(SystemExit) as exc:
                _run_command(["dummy"])
            assert exc.value.code == 42


class TestTestCommand:
    """Tests for test_command function."""

    def test_test_command_is_callable(self) -> None:
        """test_command should be callable."""
        from framework_m_studio.cli.quality import test_command

        assert callable(test_command)

    def test_test_command_runs_subprocess(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """test_command should run subprocess."""
        from framework_m_studio.cli.quality import test_command

        mock_run = MagicMock()
        mock_run.return_value.returncode = 0

        with patch("subprocess.run", mock_run):
            with pytest.raises(SystemExit) as exc:
                test_command("tests/")
            assert exc.value.code == 0

        mock_run.assert_called_once()

    def test_test_command_handles_keyboard_interrupt(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """test_command should handle KeyboardInterrupt."""
        from framework_m_studio.cli.quality import test_command

        with patch("subprocess.run", side_effect=KeyboardInterrupt()):
            with pytest.raises(SystemExit) as exc:
                test_command()
            assert exc.value.code == 130

        captured = capsys.readouterr()
        assert "interrupted" in captured.out.lower()

    def test_test_command_with_target(self) -> None:
        """test_command with target should not append '.'."""
        from framework_m_studio.cli.quality import test_command

        with patch("framework_m_studio.cli.quality._run_command") as mock_run:
            test_command("tests/")
            args = mock_run.call_args[0][0]
            assert "." not in args


class TestLintCommand:
    """Tests for lint_command function."""

    def test_lint_command_is_callable(self) -> None:
        """lint_command should be callable."""
        from framework_m_studio.cli.quality import lint_command

        assert callable(lint_command)

    def test_lint_command_runs_subprocess(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """lint_command should run subprocess."""
        from framework_m_studio.cli.quality import lint_command

        mock_run = MagicMock()
        mock_run.return_value.returncode = 0

        with patch("subprocess.run", mock_run):
            with pytest.raises(SystemExit) as exc:
                lint_command()
            assert exc.value.code == 0

        mock_run.assert_called_once()

    def test_lint_command_handles_keyboard_interrupt(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """lint_command should handle KeyboardInterrupt."""
        from framework_m_studio.cli.quality import lint_command

        with patch("subprocess.run", side_effect=KeyboardInterrupt()):
            with pytest.raises(SystemExit) as exc:
                lint_command()
            assert exc.value.code == 130

        captured = capsys.readouterr()
        assert "interrupted" in captured.out.lower()

    def test_lint_command_with_target(self) -> None:
        """lint_command with target should not append '.'."""
        from framework_m_studio.cli.quality import lint_command

        with patch("framework_m_studio.cli.quality._run_command") as mock_run:
            lint_command("src/")
            args = mock_run.call_args[0][0]
            assert "." not in args


class TestFormatCommand:
    """Tests for format_command function."""

    def test_format_command_is_callable(self) -> None:
        """format_command should be callable."""
        from framework_m_studio.cli.quality import format_command

        assert callable(format_command)

    def test_format_command_runs_subprocess(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """format_command should run subprocess."""
        from framework_m_studio.cli.quality import format_command

        mock_run = MagicMock()
        mock_run.return_value.returncode = 0

        with patch("subprocess.run", mock_run):
            with pytest.raises(SystemExit) as exc:
                format_command()
            assert exc.value.code == 0

        mock_run.assert_called_once()

    def test_format_command_handles_keyboard_interrupt(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """format_command should handle KeyboardInterrupt."""
        from framework_m_studio.cli.quality import format_command

        with patch("subprocess.run", side_effect=KeyboardInterrupt()):
            with pytest.raises(SystemExit) as exc:
                format_command()
            assert exc.value.code == 130

        captured = capsys.readouterr()
        assert "interrupted" in captured.out.lower()

    def test_format_command_with_target(self) -> None:
        """format_command with target should not append '.'."""
        from framework_m_studio.cli.quality import format_command

        with patch("framework_m_studio.cli.quality._run_command") as mock_run:
            format_command("src/")
            args = mock_run.call_args[0][0]
            assert "." not in args


class TestTypecheckCommand:
    """Tests for typecheck_command function."""

    def test_typecheck_command_is_callable(self) -> None:
        """typecheck_command should be callable."""
        from framework_m_studio.cli.quality import typecheck_command

        assert callable(typecheck_command)

    def test_typecheck_command_runs_subprocess(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """typecheck_command should run subprocess."""
        from framework_m_studio.cli.quality import typecheck_command

        mock_run = MagicMock()
        mock_run.return_value.returncode = 0

        with patch("subprocess.run", mock_run):
            with pytest.raises(SystemExit) as exc:
                typecheck_command()
            assert exc.value.code == 0

        mock_run.assert_called_once()

    def test_typecheck_command_handles_keyboard_interrupt(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """typecheck_command should handle KeyboardInterrupt."""
        from framework_m_studio.cli.quality import typecheck_command

        with patch("subprocess.run", side_effect=KeyboardInterrupt()):
            with pytest.raises(SystemExit) as exc:
                typecheck_command()
            assert exc.value.code == 130

        captured = capsys.readouterr()
        assert "interrupted" in captured.out.lower()

    def test_typecheck_command_with_target(self) -> None:
        """typecheck_command with target should not append 'src'."""
        from framework_m_studio.cli.quality import typecheck_command

        with patch("framework_m_studio.cli.quality._run_command") as mock_run:
            typecheck_command("tests/")
            args = mock_run.call_args[0][0]
            assert "src" not in args


class TestSecurityCommand:
    """Tests for security_command function."""

    def test_security_command_is_callable(self) -> None:
        """security_command should be callable."""
        from framework_m_studio.cli.quality import security_command

        assert callable(security_command)

    def test_security_command_runs_subprocess(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """security_command should run subprocess calling bandit."""
        from framework_m_studio.cli.quality import security_command

        mock_run = MagicMock()
        mock_run.return_value.returncode = 0

        with patch("subprocess.run", mock_run):
            with pytest.raises(SystemExit) as exc:
                security_command()
            assert exc.value.code == 0

        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "bandit" in args

    def test_security_command_handles_keyboard_interrupt(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """security_command should handle KeyboardInterrupt."""
        from framework_m_studio.cli.quality import security_command

        with patch("subprocess.run", side_effect=KeyboardInterrupt()):
            with pytest.raises(SystemExit) as exc:
                security_command()
            assert exc.value.code == 130

        captured = capsys.readouterr()
        assert "interrupted" in captured.out.lower()

    def test_security_command_with_target(self) -> None:
        """security_command with target should not append '.'."""
        from framework_m_studio.cli.quality import security_command

        with patch("framework_m_studio.cli.quality._run_command") as mock_run:
            security_command("src/")
            args = mock_run.call_args[0][0]
            assert "." not in args


class TestVerifyDocNumbering:
    """Tests for verify_doc_numbering function."""

    def test_verify_doc_numbering_success(self, tmp_path: Path) -> None:
        """Should return no errors for sequential files."""
        from framework_m_studio.cli.quality import verify_doc_numbering

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "0001-first.md").touch()
        (docs_dir / "0002-second.md").touch()
        (docs_dir / "0003-third.md").touch()
        (docs_dir / "template.md").touch()  # Should be ignored

        errors = verify_doc_numbering(docs_dir)
        assert not errors

    def test_verify_doc_numbering_duplicates(self, tmp_path: Path) -> None:
        """Should return error for duplicate numbers."""
        from framework_m_studio.cli.quality import verify_doc_numbering

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "0001-first.md").touch()
        (docs_dir / "0001-duplicate.md").touch()

        errors = verify_doc_numbering(docs_dir)
        assert len(errors) == 1
        assert "0001" in errors[0]

    def test_verify_doc_numbering_missing(self, tmp_path: Path) -> None:
        """Should return error for missing numbers in sequence."""
        from framework_m_studio.cli.quality import verify_doc_numbering

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "0001-first.md").touch()
        (docs_dir / "0003-third.md").touch()

        errors = verify_doc_numbering(docs_dir)
        assert len(errors) == 1
        assert "0002" in errors[0]

    def test_verify_doc_numbering_missing_dir(self, tmp_path: Path) -> None:
        """Should return empty list if docs_dir does not exist."""
        from framework_m_studio.cli.quality import verify_doc_numbering

        errors = verify_doc_numbering(tmp_path / "nonexistent")
        assert not errors

    def test_verify_doc_numbering_ignores_index(self, tmp_path: Path) -> None:
        """Should explicitly ignore index.md."""
        from framework_m_studio.cli.quality import verify_doc_numbering

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "index.md").touch()
        errors = verify_doc_numbering(docs_dir)
        assert not errors

    def test_verify_doc_numbering_ignores_zero(self, tmp_path: Path) -> None:
        """Should ignore files starting with 0000."""
        from framework_m_studio.cli.quality import verify_doc_numbering

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "0000-intro.md").touch()
        errors = verify_doc_numbering(docs_dir)
        assert not errors

    def test_verify_doc_numbering_no_numbered_files(self, tmp_path: Path) -> None:
        """Should not report missing numbers if no numbered files exist."""
        from framework_m_studio.cli.quality import verify_doc_numbering

        errors = verify_doc_numbering(tmp_path)
        assert not errors


class TestCommandExecution:
    """Tests for command execution."""

    def test_test_help(self) -> None:
        """test --help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "test", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        # assert "test" in result.stdout.lower() or "pytest" in result.stdout.lower()

    def test_lint_help(self) -> None:
        """lint --help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "lint", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0

    def test_format_help(self) -> None:
        """format --help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "format", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0

    def test_typecheck_help(self) -> None:
        """typecheck --help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "typecheck", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0


class TestQualityExports:
    """Tests for quality module exports."""

    def test_all_exports(self) -> None:
        """quality module should export expected items."""
        from framework_m_studio.cli import quality

        assert "test_command" in quality.__all__
        assert "lint_command" in quality.__all__
        assert "format_command" in quality.__all__
        assert "typecheck_command" in quality.__all__
        assert "security_command" in quality.__all__
        assert "verify_doc_numbering" in quality.__all__
