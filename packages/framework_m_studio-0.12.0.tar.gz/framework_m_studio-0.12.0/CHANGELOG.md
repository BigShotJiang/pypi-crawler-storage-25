## framework-m-studio v0.12.0

### Features

- update plugin scaffolding templates for navigation (83d7e7a)
- refactor aggregate builder into editor tab (2e1315c)
- implement aggregate controller generation (7bb53a1)
- migrate dev configurator and enhance doctype management (d8c2589)
- implement aggregate designer and codegen locking (160ca87)
- refactor API to modular routers and add role discovery (b0a37fa)
- implement code-first MX repositories and AST tools (635da9a)

### Bug Fixes

- delete aggregate page related exports (dbdd28d)
- lint backend and frontend (170d500)
- build error for edit.tsx (36e791b)

## framework-m-studio v0.11.0

### Features

- update scaffolding templates for virtual modules and vite dedupe (6e20d30)

## framework-m-studio v0.10.2

### Bug Fixes

- cli boolean flags (2462916)

## framework-m-studio v0.10.1

### Bug Fixes

- support workspace semi-version pinning in release orchestrator (aa2c08f)

## framework-m-studio v0.10.0

### Features

- synchronize plugin template with high-fidelity form engine (da10acf)
- update plugin templates with theme support and code-splitting (54f62cc)
- refactor documentation paths and improve generator (0c6671d)

### Bug Fixes

- cast ASGI headers to list in auth middleware to resolve CI typecheck error (de38e14)
- ruff reformat (0fb4072)
- typecheck and mypy errors (071c64c)
- quality warnings from static analysis (86c6af7)

## framework-m-studio v0.9.1

### Bug Fixes

- sync platform dependencies in templates (ca2ba65)
- harden release orchestrator and scaffolding templates (991f958)
- implement self-healing tag synchronization (d008f6c)

## framework-m-studio v0.9.0

### Features

- update plugin scaffolding for refined shell architecture (3dbc0f6)
- consolidate frontend scaffolding into unified plugin templates (c12ae9a)
- consolidated and externalized CLI scaffolding (f5633b2)
- update plugin scaffolding for refined shell architecture (96a23b0)
- consolidate frontend scaffolding into unified plugin templates (9f34e3a)
- consolidated and externalized CLI scaffolding (fae62f2)
- implement negative-filter discovery with regression tests (9305ad4)
- improve automated MR formatting (3168236)
- implement brand-aligned shell layout and improved frontend templates (7bf913e)
- automate dependency discovery for release (879bd49)
- add standalone landing page to plugin scaffold (4d9f834)

### Bug Fixes

- robust dependency discovery and orchestrator compatibility (7def0e4)
- improve deps upgrade semantic commits and discovery (49f0f01)

## framework-m-studio v0.8.5

### Bug Fixes

- add node types to tsconfig and sync related apps (da1934f)

## framework-m-studio v0.8.4

### Bug Fixes

- implement bulk dependency upgrades and fix typecheck stubs (bf01d94)
- install pnpm and coreutils in release phase (ed335f8)
- enforce tool availability and install pnpm in CI (b8f9465)
- enforce lockfile sync, stage templates, and fix types (a41aad0)
- enhance local dry-run and silence check-ignore spam (29f9ef6)
- modernize gitops auth and api integration (7f15453)
- secure staging logic and resolve test regressions (e31d701)
- implement pnpm/uv lockfile sync and config cleanup (8302956)
- lint cleanup for cli.py (40b3a78)
- support GITLAB_TOKEN and harden auth check (c08b25c)
- implement atomic direct push for CI/CD stability (2947270)
- harden sync orchestration and align warning filters (714f9ba)
- modularize release package and resolve test regressions (fe8c676)

## framework-m-studio v0.8.3

### Bug Fixes

- install pnpm and coreutils in release phase (ed335f8)
- enforce tool availability and install pnpm in CI (b8f9465)
- enforce lockfile sync, stage templates, and fix types (a41aad0)
- enhance local dry-run and silence check-ignore spam (29f9ef6)
- modernize gitops auth and api integration (7f15453)
- secure staging logic and resolve test regressions (e31d701)
- implement pnpm/uv lockfile sync and config cleanup (8302956)
- lint cleanup for cli.py (40b3a78)
- support GITLAB_TOKEN and harden auth check (c08b25c)
- implement atomic direct push for CI/CD stability (2947270)
- harden sync orchestration and align warning filters (714f9ba)
- modularize release package and resolve test regressions (fe8c676)

# Changelog

## framework-m-studio v0.8.2

### Bug Fixes

- fix uv-build output and sync python packages (d9c994a)


## framework-m-studio v0.8.1

### Bug Fixes

- refine dependency sync to respect explicit targets (187938c)
- support commit body tags for synchronized releases (b83d42a)


## framework-m-studio v0.8.0

### Features

- enhance scaffolding and fix release orchestration (63883a6)

### Bug Fixes

- add license and resolve linter errors (b6857e9)
- align default ports across studio CLI commands (7ea9281)


## framework-m-studio v0.7.0

### Features

- split cli modules and add security command (44214a1)
- refactor documentation generation CLI and add integration tests (81055f2)
- implement screenshot pipeline and automated docs generation (4c7ae26)
- enhance CLI commands and documentation generators (759045b)

### Bug Fixes

- env for deps test (2b99410)
- add ipython as dependency (e81a27c)
- improve default target handling in quality commands (7a921ff)
- studio polish and cli polish (b8f62ec)
- generate explicit heading IDs in feature summary (9115617)
- mock environment for consistent source link tests (2946ab6)
- resolve B310 security vulnerability in OpenAPI export (aaea4a8)


## framework-m-studio v0.6.0

### Features

- add entrypoints discovery command (b24dbf1)
- implement mfe verification cli (bcd87a2)


## framework-m-studio v0.5.2

### Bug Fixes

- clarify development-only status in readme (7d5e066)


## framework-m-studio v0.5.1

### Bug Fixes

- resolve duplicate filenames in wheel (7b752db)


## framework-m-studio v0.5.0

### Features

- implement plugin template in new.py (31abc2b)
- output protocol docs adjacent to doctype docs (57d76ab)
- output protocol docs adjacent to doctype docs (7ac326d)


## framework-m-studio v0.4.7

### Bug Fixes

- server ips to 0.0.0.0 instead of 127.0.0.1 (97e0960)


## framework-m-studio v0.4.6

### Bug Fixes

- implement m dev mode flag (5fd57e0)


## framework-m-studio v0.4.5

### Bug Fixes

- refine readme reading (8c8adb6)


## framework-m-studio v0.4.4

### Bug Fixes

- code preview, rename doctypes and add new docs (c711fdd)


## framework-m-studio v0.4.3

### Bug Fixes

- mock static assets for robust api testing (9332b17)
- build UI in publish job + remove test dependencies (ebe7661)


## framework-m-studio v0.4.2

### Bug Fixes

- preserve static assets in build (b155a0b)


## framework-m-studio v0.4.1

### Bug Fixes

- update studio readme to www.frameworkm.dev (91de2da)


## framework-m-studio v0.4.0

### Features

- implement dynamic versioning and dev groups in app scaffolding (2d66119)

### Bug Fixes

- use last tag version as base for release bump (bfefd3f)
- support version bumping for package.json in release script (2b6a7c3)
- fix build crash and ensure static assets are packaged (bdc18b7)
- force include gitignored static assets in packages (4fd49a5)


## framework-m-studio v0.3.5

### Bug Fixes

- trigger doc builds on studio changes (d1a2a7b)
- synchronize pages rules with build-docs (3b2d9b7)
- aggressive filtering and dependency decoupling (6b8dbf0)
- global dummy assets and artifact integrity (f6d39f2)
- dual-track artifacts and tag optimization (6b9cdfb)
- optimize tag pipeline and kill duplication (d9154ae)
- use hatch artifacts to resolve duplicate filenames (e499457)


## framework-m-studio v0.3.4

### Bug Fixes

- robustly detect existing tags in auto_tag_release (8aeef39)


## framework-m-studio v0.3.3

### Bug Fixes

- bulletproof tagging and gitlab pypi upload idempotency (530466b)
- make auto_tag_release script idempotent (c211ab5)


## framework-m-studio v0.3.2

### Bug Fixes

- remove unsupported --skip-existing from gitlab twine upload (a1b6a96)


## framework-m-studio v0.3.1

### Bug Fixes

- make test-workspace needs optional (96450fc)
- restore gitlint general section header (7131edc)
- adjust gitlint limits and script for long release titles (1a1371e)
- resolve duplicate filenames in wheel and improve CI robustness (e24c0ef)


## framework-m-studio v0.3.0

### Features

- support namespaced app, test directory and dev.py moved to studio (37beae6)


## framework-m-studio v0.2.8

### Bug Fixes

- add ruff code style badge to README (c2482ea)


## framework-m-studio v0.2.7

### Bug Fixes

- add Python version and license badges to README (90d1adf)


## framework-m-studio v0.2.6

### Bug Fixes

- format and lint (090018f)


## framework-m-studio v0.2.3

### Bug Fixes

- ensure static assets are bundled in the wheel (ce0a0e1)


## framework-m-studio v0.2.2

### Bug Fixes

- add badges to readme (012333b)


## framework-m-studio v0.2.1

### Bug Fixes

- modernize aesthetics (300cdda)


## framework-m-studio 0.2.0

### Features

- implement path prefix architecture for UI/API separation (7a8d2d2)
- add cloud workspace & git adapter, controller scaffolding and sandbox (a7a4a3e)
- implement Studio backend and frontend (abf5d03)

### Bug Fixes

- include static files in package for PyPI publishing (565bcb8)

