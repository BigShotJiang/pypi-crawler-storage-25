"""Display - render port info as rich terminal output."""

from __future__ import annotations

import json

from rich.console import Console
from rich.table import Table

from devports.health import HealthStatus
from devports.scanner import PortInfo

console = Console()

STATUS_STYLE = {
    HealthStatus.HEALTHY: ("[green]healthy[/green]", "[green]●[/green]"),
    HealthStatus.UNHEALTHY: ("[red]down[/red]", "[red]●[/red]"),
    HealthStatus.UNKNOWN: ("[yellow]unknown[/yellow]", "[yellow]●[/yellow]"),
}


def render_table(
    ports: list[PortInfo],
    health: dict[int, object] | None = None,
    show_pid: bool = False,
    show_cmd: bool = False,
) -> None:
    """Render port information as a rich table."""
    if not ports:
        console.print("[dim]No listening ports found.[/dim]")
        return

    table = Table(title="Local Services", border_style="dim")
    table.add_column("PORT", style="bold cyan", justify="right")
    table.add_column("SERVICE", style="white")
    table.add_column("STATUS", justify="center")

    if show_pid:
        table.add_column("PID", style="dim", justify="right")
    if show_cmd:
        table.add_column("COMMAND", style="dim", max_width=50)

    table.add_column("ADDRESS", style="dim")

    for p in ports:
        status_text = ""
        if health and p.port in health:
            h = health[p.port]
            label, dot = STATUS_STYLE.get(h.status, ("[dim]?[/dim]", "[dim]?[/dim]"))
            if h.response_ms is not None:
                status_text = f"{dot} {label} [dim]({h.response_ms}ms)[/dim]"
            else:
                status_text = f"{dot} {label}"
        else:
            status_text = "[dim]-[/dim]"

        service = p.service_name or p.process_name or f"port-{p.port}"
        tags = ""
        if p.tags:
            tags = " " + " ".join(f"[dim][{t}][/dim]" for t in p.tags)

        row = [str(p.port), f"{service}{tags}", status_text]

        if show_pid:
            row.append(str(p.pid) if p.pid else "-")
        if show_cmd:
            cmd = p.cmdline[:50] if p.cmdline else "-"
            row.append(cmd)

        row.append(p.address)
        table.add_row(*row)

    console.print(table)
    console.print(f"[dim]{len(ports)} service(s) found[/dim]")


def render_json(ports: list[PortInfo], health: dict[int, object] | None = None) -> str:
    """Render port information as JSON."""
    data = []
    for p in ports:
        entry: dict = {
            "port": p.port,
            "service": p.service_name or p.process_name or f"port-{p.port}",
            "pid": p.pid,
            "process": p.process_name,
            "address": p.address,
            "tags": p.tags,
        }
        if health and p.port in health:
            h = health[p.port]
            entry["health"] = {
                "status": h.status.value,
                "response_ms": h.response_ms,
                "error": h.error,
            }
        data.append(entry)

    return json.dumps(data, indent=2)
