"""Port scanner - discover listening TCP ports and their processes."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field


@dataclass
class PortInfo:
    """Information about a listening port."""

    port: int
    pid: int | None = None
    process_name: str = ""
    cmdline: str = ""
    user: str = ""
    protocol: str = "tcp"
    address: str = "0.0.0.0"
    docker_container: str | None = None
    service_name: str = ""
    tags: list[str] = field(default_factory=list)


def scan_ports() -> list[PortInfo]:
    """Scan all listening TCP ports using ss (Linux)."""
    ports: dict[int, PortInfo] = {}

    try:
        result = subprocess.run(
            ["ss", "-tlnpH"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []

    for line in result.stdout.strip().splitlines():
        info = _parse_ss_line(line)
        if info and info.port not in ports:
            ports[info.port] = info

    return sorted(ports.values(), key=lambda p: p.port)


def _parse_ss_line(line: str) -> PortInfo | None:
    """Parse a single line from `ss -tlnpH`."""
    # Format: State  Recv-Q  Send-Q  Local Address:Port  Peer Address:Port  Process
    parts = line.split()
    if len(parts) < 5:
        return None

    local_addr = parts[3]
    # Extract port from address like 0.0.0.0:3000 or [::]:3000 or *:3000
    if ":" not in local_addr:
        return None

    port_str = local_addr.rsplit(":", 1)[-1]
    try:
        port = int(port_str)
    except ValueError:
        return None

    address = local_addr.rsplit(":", 1)[0].strip("[]")

    pid = None
    process_name = ""
    # Process info is in the last column, format: users:(("name",pid=123,fd=4))
    for part in parts[5:]:
        if "pid=" in part:
            try:
                pid = int(part.split("pid=")[1].split(",")[0].split(")")[0])
            except (ValueError, IndexError):
                pass
        if part.startswith("users:"):
            try:
                process_name = part.split('"')[1]
            except IndexError:
                pass

    info = PortInfo(port=port, pid=pid, process_name=process_name, address=address)

    if pid:
        _enrich_from_proc(info)

    return info


def _enrich_from_proc(info: PortInfo) -> None:
    """Enrich PortInfo with data from /proc filesystem."""
    if not info.pid:
        return

    try:
        cmdline_path = f"/proc/{info.pid}/cmdline"
        with open(cmdline_path) as f:
            info.cmdline = f.read().replace("\x00", " ").strip()
    except (OSError, PermissionError):
        pass

    if not info.process_name:
        try:
            comm_path = f"/proc/{info.pid}/comm"
            with open(comm_path) as f:
                info.process_name = f.read().strip()
        except (OSError, PermissionError):
            pass
