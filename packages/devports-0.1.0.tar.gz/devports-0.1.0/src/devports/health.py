"""Health checking - probe ports to determine if services are responding."""

from __future__ import annotations

import socket
from dataclasses import dataclass
from enum import Enum


class HealthStatus(Enum):
    """Health status of a port."""

    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass
class HealthResult:
    """Result of a health check."""

    port: int
    status: HealthStatus
    response_ms: float | None = None
    error: str | None = None


def check_health(port: int, host: str = "127.0.0.1", timeout: float = 2.0) -> HealthResult:
    """Check if a port is accepting connections."""
    import time

    start = time.monotonic()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            elapsed = (time.monotonic() - start) * 1000
            return HealthResult(
                port=port, status=HealthStatus.HEALTHY, response_ms=round(elapsed, 1)
            )
    except ConnectionRefusedError:
        return HealthResult(port=port, status=HealthStatus.UNHEALTHY, error="connection refused")
    except TimeoutError:
        return HealthResult(port=port, status=HealthStatus.UNHEALTHY, error="timeout")
    except OSError as e:
        return HealthResult(port=port, status=HealthStatus.UNKNOWN, error=str(e))


def check_all_health(
    ports: list[int], host: str = "127.0.0.1", timeout: float = 2.0
) -> dict[int, HealthResult]:
    """Check health of multiple ports."""
    results = {}
    for port in ports:
        results[port] = check_health(port, host, timeout)
    return results
