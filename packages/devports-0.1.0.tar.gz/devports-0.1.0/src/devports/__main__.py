"""Allow running devports as `python -m devports`."""

from devports.cli import cli

cli()
