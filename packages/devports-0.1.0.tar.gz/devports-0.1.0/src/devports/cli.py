"""CLI interface for devports."""

from __future__ import annotations

import subprocess
import sys
import time

import click
from rich.console import Console
from rich.live import Live

from devports.display import render_json, render_table
from devports.health import check_all_health
from devports.identify import identify_docker_containers, identify_service
from devports.scanner import scan_ports

console = Console()


def _scan_and_identify(health_check: bool = True) -> tuple:
    """Scan ports, identify services, and optionally check health."""
    ports = scan_ports()
    identify_docker_containers(ports)

    for p in ports:
        p.service_name = identify_service(p)

    health = {}
    if health_check:
        health = check_all_health([p.port for p in ports])

    return ports, health


@click.group(invoke_without_command=True)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--pid", "show_pid", is_flag=True, help="Show process IDs.")
@click.option("--cmd", "show_cmd", is_flag=True, help="Show full command line.")
@click.option("--no-health", is_flag=True, help="Skip health checks.")
@click.version_option(package_name="devports")
@click.pass_context
def cli(ctx: click.Context, as_json: bool, show_pid: bool, show_cmd: bool, no_health: bool) -> None:
    """devports - See what's running on your local ports."""
    if ctx.invoked_subcommand is not None:
        return

    ports, health = _scan_and_identify(health_check=not no_health)

    if as_json:
        click.echo(render_json(ports, health))
    else:
        render_table(ports, health, show_pid=show_pid, show_cmd=show_cmd)


@cli.command()
@click.option("--interval", "-i", default=2, help="Refresh interval in seconds.")
@click.option("--pid", "show_pid", is_flag=True, help="Show process IDs.")
def watch(interval: int, show_pid: bool) -> None:
    """Live-updating view of local services."""
    try:
        with Live(console=console, refresh_per_second=1) as live:
            while True:
                ports, health = _scan_and_identify()

                table_obj = _build_table(ports, health, show_pid=show_pid)
                live.update(table_obj)
                time.sleep(interval)
    except KeyboardInterrupt:
        console.print("\n[dim]Stopped.[/dim]")


@cli.command()
@click.argument("target")
def open_port(target: str) -> None:
    """Open a service in the browser. TARGET can be a port number or service name."""
    ports, _ = _scan_and_identify(health_check=False)

    match = None
    try:
        port_num = int(target)
        match = next((p for p in ports if p.port == port_num), None)
    except ValueError:
        match = next(
            (p for p in ports if target.lower() in (p.service_name or "").lower()),
            None,
        )

    if not match:
        console.print(f"[red]Not found:[/red] {target}")
        console.print("[dim]Use 'devports' to see available services.[/dim]")
        sys.exit(1)

    url = f"http://127.0.0.1:{match.port}"
    console.print(f"Opening {url} ...")

    try:
        subprocess.run(["xdg-open", url], check=False, capture_output=True)
    except FileNotFoundError:
        try:
            subprocess.run(["wslview", url], check=False, capture_output=True)
        except FileNotFoundError:
            console.print(f"[yellow]Could not open browser. Visit:[/yellow] {url}")


@cli.command()
@click.argument("port", type=int)
def kill(port: int) -> None:
    """Kill the process listening on a port."""
    ports, _ = _scan_and_identify(health_check=False)
    match = next((p for p in ports if p.port == port), None)

    if not match:
        console.print(f"[red]No process found on port {port}[/red]")
        sys.exit(1)

    if not match.pid:
        console.print(f"[red]Cannot determine PID for port {port}[/red]")
        sys.exit(1)

    service = match.service_name or match.process_name
    console.print(f"Killing {service} (PID {match.pid}) on port {port}...")

    try:
        import os
        import signal

        os.kill(match.pid, signal.SIGTERM)
        console.print(f"[green]Sent SIGTERM to PID {match.pid}[/green]")
    except ProcessLookupError:
        console.print(f"[yellow]Process {match.pid} already gone[/yellow]")
    except PermissionError:
        console.print(f"[red]Permission denied. Try: sudo kill {match.pid}[/red]")
        sys.exit(1)


def _build_table(ports: list, health: dict, show_pid: bool = False) -> object:
    """Build a Rich Table for live display."""
    from rich.table import Table

    from devports.display import STATUS_STYLE

    table = Table(title="Local Services", border_style="dim")
    table.add_column("PORT", style="bold cyan", justify="right")
    table.add_column("SERVICE", style="white")
    table.add_column("STATUS", justify="center")
    if show_pid:
        table.add_column("PID", style="dim", justify="right")
    table.add_column("ADDRESS", style="dim")

    for p in ports:
        status_text = "[dim]-[/dim]"
        if p.port in health:
            h = health[p.port]
            label, dot = STATUS_STYLE.get(h.status, ("[dim]?[/dim]", "[dim]?[/dim]"))
            if h.response_ms is not None:
                status_text = f"{dot} {label} [dim]({h.response_ms}ms)[/dim]"
            else:
                status_text = f"{dot} {label}"

        service = p.service_name or p.process_name or f"port-{p.port}"
        tags = ""
        if p.tags:
            tags = " " + " ".join(f"[dim][{t}][/dim]" for t in p.tags)

        row = [str(p.port), f"{service}{tags}", status_text]
        if show_pid:
            row.append(str(p.pid) if p.pid else "-")
        row.append(p.address)
        table.add_row(*row)

    return table
