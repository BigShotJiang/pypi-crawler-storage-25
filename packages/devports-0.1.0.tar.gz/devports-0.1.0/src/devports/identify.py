"""Service identification - map ports and processes to friendly names."""

from __future__ import annotations

import json
import subprocess

from devports.scanner import PortInfo

# Common development ports and their typical services
KNOWN_PORTS: dict[int, str] = {
    80: "http",
    443: "https",
    1080: "socks-proxy",
    2181: "zookeeper",
    3000: "dev-server",
    3001: "dev-server",
    3306: "mysql",
    4200: "angular",
    4321: "astro",
    5000: "flask",
    5173: "vite",
    5432: "postgres",
    5500: "live-server",
    5672: "rabbitmq",
    6379: "redis",
    6380: "redis",
    7474: "neo4j",
    8000: "django",
    8080: "http-alt",
    8081: "http-alt",
    8443: "https-alt",
    8761: "eureka",
    8888: "jupyter",
    9000: "php-fpm",
    9090: "prometheus",
    9092: "kafka",
    9200: "elasticsearch",
    9300: "elasticsearch",
    11211: "memcached",
    15672: "rabbitmq-mgmt",
    27017: "mongodb",
}

# Process name to service mapping
PROCESS_MAP: dict[str, str] = {
    "node": "node",
    "python": "python",
    "python3": "python",
    "java": "java",
    "ruby": "ruby",
    "php": "php",
    "go": "go",
    "nginx": "nginx",
    "apache2": "apache",
    "httpd": "apache",
    "postgres": "postgres",
    "mysqld": "mysql",
    "redis-server": "redis",
    "mongod": "mongodb",
    "docker-proxy": "docker",
    "containerd": "containerd",
    "code-server": "vscode",
    "jupyter": "jupyter",
}


def identify_service(info: PortInfo) -> str:
    """Determine a friendly service name for a port."""
    # 1. Check if it's a Docker container
    if info.docker_container:
        return info.docker_container

    # 2. Check process name against known mappings
    if info.process_name in PROCESS_MAP:
        mapped = PROCESS_MAP[info.process_name]
        # For generic runtimes, try to extract app name from cmdline
        if mapped in ("node", "python", "java", "ruby", "go") and info.cmdline:
            app = _extract_app_name(info.cmdline, mapped)
            if app:
                return app

    # 3. Check known port database
    if info.port in KNOWN_PORTS:
        return KNOWN_PORTS[info.port]

    # 4. Fall back to process name
    if info.process_name:
        return info.process_name

    return f"port-{info.port}"


def _extract_app_name(cmdline: str, runtime: str) -> str:
    """Try to extract a meaningful app name from a command line."""
    parts = cmdline.split()

    if runtime == "node":
        for part in parts:
            if "next" in part.lower():
                return "next-dev"
            if "vite" in part.lower():
                return "vite"
            if "nuxt" in part.lower():
                return "nuxt"
            if "remix" in part.lower():
                return "remix"
            if "express" in part.lower():
                return "express"
            if "nest" in part.lower():
                return "nestjs"
        # Use the script name if it looks like a file
        for part in parts[1:]:
            if part.endswith((".js", ".mjs", ".ts")):
                return part.rsplit("/", 1)[-1].rsplit(".", 1)[0]

    if runtime == "python":
        for part in parts:
            if "django" in part.lower() or "manage.py" in part:
                return "django"
            if "flask" in part.lower():
                return "flask"
            if "fastapi" in part.lower() or "uvicorn" in part.lower():
                return "fastapi"
            if "gunicorn" in part.lower():
                return "gunicorn"
            if "jupyter" in part.lower():
                return "jupyter"

    if runtime == "java":
        for part in parts:
            if "spring" in part.lower():
                return "spring"
            if "tomcat" in part.lower():
                return "tomcat"

    return ""


def identify_docker_containers(ports: list[PortInfo]) -> None:
    """Enrich port info with Docker container names."""
    try:
        result = subprocess.run(
            ["docker", "ps", "--format", "{{json .}}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return

    if result.returncode != 0:
        return

    containers: dict[int, str] = {}
    for line in result.stdout.strip().splitlines():
        try:
            container = json.loads(line)
        except json.JSONDecodeError:
            continue

        name = container.get("Names", "")
        port_bindings = container.get("Ports", "")
        for binding in port_bindings.split(","):
            binding = binding.strip()
            if "->" in binding:
                host_part = binding.split("->")[0]
                port_str = host_part.rsplit(":", 1)[-1]
                try:
                    containers[int(port_str)] = name
                except ValueError:
                    pass

    for info in ports:
        if info.port in containers:
            info.docker_container = containers[info.port]
            info.tags.append("docker")
