"""Tests for devports.scanner module."""

from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, mock_open, patch

from devports.scanner import PortInfo, _enrich_from_proc, _parse_ss_line, scan_ports
from tests.conftest import (
    SS_LINE_FULL,
    SS_LINE_IPV6,
    SS_LINE_NO_PROCESS,
    SS_LINE_STAR,
    SS_OUTPUT_MULTI,
)

# ---------------------------------------------------------------------------
# scan_ports
# ---------------------------------------------------------------------------


class TestScanPorts:
    def test_should_return_sorted_ports_when_ss_succeeds(self):
        mock_result = MagicMock()
        mock_result.stdout = SS_OUTPUT_MULTI

        with patch("devports.scanner.subprocess.run", return_value=mock_result):
            with patch("devports.scanner._enrich_from_proc"):
                ports = scan_ports()

        port_numbers = [p.port for p in ports]
        assert port_numbers == sorted(port_numbers)

    def test_should_return_correct_port_count_when_ss_has_three_lines(self):
        mock_result = MagicMock()
        mock_result.stdout = SS_OUTPUT_MULTI

        with patch("devports.scanner.subprocess.run", return_value=mock_result):
            with patch("devports.scanner._enrich_from_proc"):
                ports = scan_ports()

        assert len(ports) == 3

    def test_should_return_empty_list_when_ss_not_found(self):
        with patch("devports.scanner.subprocess.run", side_effect=FileNotFoundError):
            ports = scan_ports()

        assert ports == []

    def test_should_return_empty_list_when_ss_times_out(self):
        with patch(
            "devports.scanner.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="ss", timeout=5),
        ):
            ports = scan_ports()

        assert ports == []

    def test_should_return_empty_list_when_ss_output_is_empty(self):
        mock_result = MagicMock()
        mock_result.stdout = ""

        with patch("devports.scanner.subprocess.run", return_value=mock_result):
            ports = scan_ports()

        assert ports == []

    def test_should_deduplicate_ports_when_ss_has_duplicate_entries(self):
        duplicate_output = "\n".join([SS_LINE_FULL, SS_LINE_FULL])
        mock_result = MagicMock()
        mock_result.stdout = duplicate_output

        with patch("devports.scanner.subprocess.run", return_value=mock_result):
            with patch("devports.scanner._enrich_from_proc"):
                ports = scan_ports()

        assert len(ports) == 1

    def test_should_call_enrich_from_proc_when_pid_is_present(self):
        mock_result = MagicMock()
        mock_result.stdout = SS_LINE_FULL

        with patch("devports.scanner.subprocess.run", return_value=mock_result):
            with patch("devports.scanner._enrich_from_proc") as mock_enrich:
                scan_ports()

        mock_enrich.assert_called_once()

    def test_should_pass_correct_args_to_ss(self):
        mock_result = MagicMock()
        mock_result.stdout = ""

        with patch("devports.scanner.subprocess.run", return_value=mock_result) as mock_run:
            scan_ports()

        mock_run.assert_called_once_with(
            ["ss", "-tlnpH"],
            capture_output=True,
            text=True,
            timeout=5,
        )


# ---------------------------------------------------------------------------
# _parse_ss_line
# ---------------------------------------------------------------------------


class TestParseSsLine:
    def test_should_parse_port_when_line_has_ipv4_address(self):
        info = _parse_ss_line(SS_LINE_FULL)

        assert info is not None
        assert info.port == 3000

    def test_should_parse_pid_when_line_has_process_info(self):
        with patch("devports.scanner._enrich_from_proc"):
            info = _parse_ss_line(SS_LINE_FULL)

        assert info.pid == 1234

    def test_should_parse_process_name_when_line_has_users_field(self):
        with patch("devports.scanner._enrich_from_proc"):
            info = _parse_ss_line(SS_LINE_FULL)

        assert info.process_name == "node"

    def test_should_parse_address_when_line_has_ipv4(self):
        with patch("devports.scanner._enrich_from_proc"):
            info = _parse_ss_line(SS_LINE_FULL)

        assert info.address == "0.0.0.0"

    def test_should_parse_port_when_line_has_ipv6_address(self):
        with patch("devports.scanner._enrich_from_proc"):
            info = _parse_ss_line(SS_LINE_IPV6)

        assert info is not None
        assert info.port == 8080

    def test_should_strip_brackets_from_ipv6_address(self):
        with patch("devports.scanner._enrich_from_proc"):
            info = _parse_ss_line(SS_LINE_IPV6)

        assert info.address == "::"

    def test_should_parse_port_when_address_uses_star_wildcard(self):
        with patch("devports.scanner._enrich_from_proc"):
            info = _parse_ss_line(SS_LINE_STAR)

        assert info is not None
        assert info.port == 5432

    def test_should_return_none_pid_when_line_has_no_process_info(self):
        info = _parse_ss_line(SS_LINE_NO_PROCESS)

        assert info is not None
        assert info.pid is None

    def test_should_return_empty_process_name_when_no_users_field(self):
        info = _parse_ss_line(SS_LINE_NO_PROCESS)

        assert info.process_name == ""

    def test_should_return_none_when_line_has_fewer_than_5_parts(self):
        info = _parse_ss_line("LISTEN 0 128")

        assert info is None

    def test_should_return_none_when_local_addr_has_no_colon(self):
        line = "LISTEN 0 128 badaddress 0.0.0.0:*"
        info = _parse_ss_line(line)

        assert info is None

    def test_should_return_none_when_port_is_not_numeric(self):
        line = "LISTEN 0 128 0.0.0.0:notaport 0.0.0.0:*"
        info = _parse_ss_line(line)

        assert info is None

    def test_should_handle_malformed_pid_field_gracefully(self):
        line = 'LISTEN 0 128 0.0.0.0:9000 0.0.0.0:* users:(("php",pid=BADPID,fd=5))'
        info = _parse_ss_line(line)

        assert info is not None
        assert info.pid is None

    def test_should_call_enrich_when_pid_is_parsed(self):
        with patch("devports.scanner._enrich_from_proc") as mock_enrich:
            _parse_ss_line(SS_LINE_FULL)

        mock_enrich.assert_called_once()

    def test_should_not_call_enrich_when_no_pid(self):
        with patch("devports.scanner._enrich_from_proc") as mock_enrich:
            _parse_ss_line(SS_LINE_NO_PROCESS)

        mock_enrich.assert_not_called()


# ---------------------------------------------------------------------------
# _enrich_from_proc
# ---------------------------------------------------------------------------


class TestEnrichFromProc:
    def test_should_populate_cmdline_when_proc_file_is_readable(self):
        info = PortInfo(port=3000, pid=1234)
        fake_cmdline = "node\x00/app/server.js\x00"

        with patch("builtins.open", mock_open(read_data=fake_cmdline)):
            _enrich_from_proc(info)

        assert info.cmdline == "node /app/server.js"

    def test_should_replace_null_bytes_with_spaces_in_cmdline(self):
        info = PortInfo(port=3000, pid=1234)
        fake_cmdline = "python\x00manage.py\x00runserver\x00"

        with patch("builtins.open", mock_open(read_data=fake_cmdline)):
            _enrich_from_proc(info)

        assert info.cmdline == "python manage.py runserver"

    def test_should_strip_trailing_whitespace_from_cmdline(self):
        info = PortInfo(port=3000, pid=1234)

        with patch("builtins.open", mock_open(read_data="node server.js   ")):
            _enrich_from_proc(info)

        assert info.cmdline == "node server.js"

    def test_should_not_raise_when_proc_cmdline_raises_oserror(self):
        info = PortInfo(port=3000, pid=1234)

        with patch("builtins.open", side_effect=OSError):
            _enrich_from_proc(info)  # must not raise

        assert info.cmdline == ""

    def test_should_not_raise_when_proc_cmdline_raises_permission_error(self):
        info = PortInfo(port=3000, pid=1234)

        with patch("builtins.open", side_effect=PermissionError):
            _enrich_from_proc(info)

        assert info.cmdline == ""

    def test_should_do_nothing_when_pid_is_none(self):
        info = PortInfo(port=3000, pid=None)

        with patch("builtins.open") as mock_file:
            _enrich_from_proc(info)

        mock_file.assert_not_called()

    def test_should_populate_process_name_from_comm_when_name_is_empty(self):
        info = PortInfo(port=3000, pid=1234, process_name="")

        open_calls = ["node /app/server.js", "node\n"]

        with patch(
            "builtins.open",
            side_effect=[
                mock_open(read_data=open_calls[0])(),
                mock_open(read_data=open_calls[1])(),
            ],
        ):
            _enrich_from_proc(info)

        assert info.process_name == "node"

    def test_should_not_overwrite_process_name_when_already_set(self):
        info = PortInfo(port=3000, pid=1234, process_name="already-set")

        with patch("builtins.open", mock_open(read_data="node server.js")):
            _enrich_from_proc(info)

        assert info.process_name == "already-set"

    def test_should_read_from_correct_proc_path(self):
        info = PortInfo(port=3000, pid=9999)
        opened_paths = []

        def fake_open(path, *args, **kwargs):
            opened_paths.append(path)
            return mock_open(read_data="dummy")()

        with patch("builtins.open", side_effect=fake_open):
            _enrich_from_proc(info)

        assert "/proc/9999/cmdline" in opened_paths
