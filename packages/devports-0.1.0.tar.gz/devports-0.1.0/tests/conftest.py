"""Shared fixtures for devports tests."""

from __future__ import annotations

import pytest

from devports.health import HealthResult, HealthStatus
from devports.scanner import PortInfo


@pytest.fixture
def port_info_node():
    """A PortInfo representing a Node.js dev server."""
    return PortInfo(
        port=3000,
        pid=1234,
        process_name="node",
        cmdline="node /app/node_modules/.bin/next start",
        user="lucas",
        address="0.0.0.0",
    )


@pytest.fixture
def port_info_python():
    """A PortInfo representing a Python/Django server."""
    return PortInfo(
        port=8000,
        pid=5678,
        process_name="python",
        cmdline="python manage.py runserver",
        user="lucas",
        address="127.0.0.1",
    )


@pytest.fixture
def port_info_postgres():
    """A PortInfo representing postgres."""
    return PortInfo(
        port=5432,
        pid=999,
        process_name="postgres",
        cmdline="postgres -D /var/lib/pgsql/data",
        user="postgres",
        address="127.0.0.1",
    )


@pytest.fixture
def port_info_no_pid():
    """A PortInfo with no PID (e.g. docker-proxy where proc is hidden)."""
    return PortInfo(
        port=6379,
        pid=None,
        process_name="",
        cmdline="",
        address="0.0.0.0",
    )


@pytest.fixture
def port_info_docker():
    """A PortInfo tagged as a Docker container."""
    info = PortInfo(
        port=8080,
        pid=None,
        process_name="docker-proxy",
        address="0.0.0.0",
    )
    info.docker_container = "my-app"
    info.tags = ["docker"]
    return info


@pytest.fixture
def sample_ports(port_info_node, port_info_python, port_info_postgres):
    """A list of diverse PortInfo objects."""
    return [port_info_node, port_info_python, port_info_postgres]


# ---------------------------------------------------------------------------
# Raw ss output fixtures
# ---------------------------------------------------------------------------

SS_LINE_FULL = 'LISTEN 0 128 0.0.0.0:3000 0.0.0.0:* users:(("node",pid=1234,fd=22))'

SS_LINE_IPV6 = 'LISTEN 0 128 [::]:8080 [::]:* users:(("python3",pid=5678,fd=10))'

SS_LINE_STAR = 'LISTEN 0 511 *:5432 *:* users:(("postgres",pid=999,fd=5))'

SS_LINE_NO_PROCESS = "LISTEN 0 128 0.0.0.0:6379 0.0.0.0:*"

SS_OUTPUT_MULTI = "\n".join([SS_LINE_FULL, SS_LINE_IPV6, SS_LINE_STAR])


# ---------------------------------------------------------------------------
# Docker ps --format '{{json .}}' fixtures
# ---------------------------------------------------------------------------

DOCKER_PS_LINE_SINGLE = '{"Names":"redis","Ports":"0.0.0.0:6379->6379/tcp"}'

DOCKER_PS_LINE_MULTI_PORT = (
    '{"Names":"my-app","Ports":"0.0.0.0:8080->80/tcp, 0.0.0.0:8443->443/tcp"}'
)

DOCKER_PS_OUTPUT = "\n".join([DOCKER_PS_LINE_SINGLE, DOCKER_PS_LINE_MULTI_PORT])


# ---------------------------------------------------------------------------
# Health result fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def health_healthy():
    return HealthResult(port=3000, status=HealthStatus.HEALTHY, response_ms=5.2)


@pytest.fixture
def health_unhealthy():
    return HealthResult(port=8000, status=HealthStatus.UNHEALTHY, error="connection refused")


@pytest.fixture
def health_unknown():
    return HealthResult(port=5432, status=HealthStatus.UNKNOWN, error="Network unreachable")


@pytest.fixture
def sample_health(health_healthy, health_unhealthy, health_unknown):
    return {
        3000: health_healthy,
        8000: health_unhealthy,
        5432: health_unknown,
    }
