"""Tests for devports.display module."""

from __future__ import annotations

import json
from io import StringIO
from unittest.mock import patch

from rich.console import Console

from devports.display import render_json, render_table
from devports.health import HealthResult, HealthStatus
from devports.scanner import PortInfo


def _capture_render_table(ports, health=None, show_pid=False, show_cmd=False) -> str:
    """Run render_table and capture its console output as a plain string."""
    buf = StringIO()
    test_console = Console(file=buf, highlight=False, markup=False)
    with patch("devports.display.console", test_console):
        render_table(ports, health=health, show_pid=show_pid, show_cmd=show_cmd)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# render_table
# ---------------------------------------------------------------------------


class TestRenderTable:
    def test_should_print_no_ports_message_when_list_is_empty(self):
        output = _capture_render_table([])

        assert "No listening ports found" in output

    def test_should_include_port_number_in_output(self, port_info_node):
        output = _capture_render_table([port_info_node])

        assert "3000" in output

    def test_should_include_service_name_in_output(self, port_info_node):
        port_info_node.service_name = "next-dev"
        output = _capture_render_table([port_info_node])

        assert "next-dev" in output

    def test_should_show_process_name_when_service_name_is_empty(self, port_info_node):
        port_info_node.service_name = ""
        output = _capture_render_table([port_info_node])

        assert "node" in output

    def test_should_show_port_fallback_when_no_service_or_process_name(self):
        info = PortInfo(port=12345)
        output = _capture_render_table([info])

        assert "port-12345" in output

    def test_should_include_address_in_output(self, port_info_node):
        output = _capture_render_table([port_info_node])

        assert "0.0.0.0" in output

    def test_should_include_service_count_in_footer(self, sample_ports):
        output = _capture_render_table(sample_ports)

        assert "3 service(s) found" in output

    def test_should_show_single_service_count(self, port_info_node):
        output = _capture_render_table([port_info_node])

        assert "1 service(s) found" in output

    def test_should_include_pid_column_when_show_pid_is_true(self, port_info_node):
        output = _capture_render_table([port_info_node], show_pid=True)

        assert "1234" in output

    def test_should_show_dash_for_pid_when_pid_is_none(self):
        info = PortInfo(port=6379, pid=None, process_name="redis")
        output = _capture_render_table([info], show_pid=True)

        assert "-" in output

    def test_should_include_cmdline_when_show_cmd_is_true(self, port_info_node):
        output = _capture_render_table([port_info_node], show_cmd=True)

        assert "node" in output

    def test_should_show_dash_for_cmd_when_cmdline_is_empty(self):
        info = PortInfo(port=6379, pid=1, process_name="redis", cmdline="")
        output = _capture_render_table([info], show_cmd=True)

        assert "-" in output

    def test_should_include_all_ports_in_output(self, sample_ports):
        output = _capture_render_table(sample_ports)

        assert "3000" in output
        assert "8000" in output
        assert "5432" in output

    def test_should_show_healthy_status_when_health_result_is_healthy(self, port_info_node):
        health = {3000: HealthResult(port=3000, status=HealthStatus.HEALTHY, response_ms=5.2)}
        port_info_node.service_name = "next-dev"
        output = _capture_render_table([port_info_node], health=health)

        assert "healthy" in output

    def test_should_show_down_status_when_health_result_is_unhealthy(self, port_info_node):
        health = {
            3000: HealthResult(port=3000, status=HealthStatus.UNHEALTHY, error="connection refused")
        }
        output = _capture_render_table([port_info_node], health=health)

        assert "down" in output

    def test_should_show_unknown_status_when_health_result_is_unknown(self, port_info_node):
        health = {3000: HealthResult(port=3000, status=HealthStatus.UNKNOWN, error="no route")}
        output = _capture_render_table([port_info_node], health=health)

        assert "unknown" in output

    def test_should_show_dash_for_status_when_port_not_in_health_dict(self, port_info_node):
        output = _capture_render_table([port_info_node], health={})

        assert "-" in output

    def test_should_include_response_ms_in_output_when_healthy(self, port_info_node):
        health = {3000: HealthResult(port=3000, status=HealthStatus.HEALTHY, response_ms=12.3)}
        output = _capture_render_table([port_info_node], health=health)

        assert "12.3ms" in output

    def test_should_include_docker_tag_in_output(self, port_info_docker):
        port_info_docker.service_name = "my-app"
        output = _capture_render_table([port_info_docker])

        assert "docker" in output

    def test_should_not_include_pid_column_by_default(self, port_info_node):
        output = _capture_render_table([port_info_node])

        # PID column header should not appear
        assert "PID" not in output


# ---------------------------------------------------------------------------
# render_json
# ---------------------------------------------------------------------------


class TestRenderJson:
    def test_should_return_valid_json_string(self, port_info_node):
        result = render_json([port_info_node])

        parsed = json.loads(result)
        assert isinstance(parsed, list)

    def test_should_return_empty_json_array_when_no_ports(self):
        result = render_json([])

        assert json.loads(result) == []

    def test_should_include_port_number_in_json(self, port_info_node):
        result = render_json([port_info_node])

        data = json.loads(result)
        assert data[0]["port"] == 3000

    def test_should_include_pid_in_json(self, port_info_node):
        result = render_json([port_info_node])

        data = json.loads(result)
        assert data[0]["pid"] == 1234

    def test_should_include_process_name_in_json(self, port_info_node):
        result = render_json([port_info_node])

        data = json.loads(result)
        assert data[0]["process"] == "node"

    def test_should_include_address_in_json(self, port_info_node):
        result = render_json([port_info_node])

        data = json.loads(result)
        assert data[0]["address"] == "0.0.0.0"

    def test_should_include_tags_in_json(self, port_info_docker):
        port_info_docker.service_name = "my-app"
        result = render_json([port_info_docker])

        data = json.loads(result)
        assert "docker" in data[0]["tags"]

    def test_should_use_service_name_in_service_field_when_set(self, port_info_node):
        port_info_node.service_name = "next-dev"
        result = render_json([port_info_node])

        data = json.loads(result)
        assert data[0]["service"] == "next-dev"

    def test_should_use_process_name_in_service_field_when_service_name_empty(self, port_info_node):
        port_info_node.service_name = ""
        result = render_json([port_info_node])

        data = json.loads(result)
        assert data[0]["service"] == "node"

    def test_should_use_port_fallback_in_service_field_when_no_names(self):
        info = PortInfo(port=99999)
        result = render_json([info])

        data = json.loads(result)
        assert data[0]["service"] == "port-99999"

    def test_should_include_health_when_health_dict_provided(self, port_info_node):
        health = {3000: HealthResult(port=3000, status=HealthStatus.HEALTHY, response_ms=4.0)}
        result = render_json([port_info_node], health=health)

        data = json.loads(result)
        assert "health" in data[0]
        assert data[0]["health"]["status"] == "healthy"

    def test_should_include_response_ms_in_health(self, port_info_node):
        health = {3000: HealthResult(port=3000, status=HealthStatus.HEALTHY, response_ms=4.0)}
        result = render_json([port_info_node], health=health)

        data = json.loads(result)
        assert data[0]["health"]["response_ms"] == 4.0

    def test_should_include_error_in_health_when_unhealthy(self, port_info_node):
        health = {
            3000: HealthResult(port=3000, status=HealthStatus.UNHEALTHY, error="connection refused")
        }
        result = render_json([port_info_node], health=health)

        data = json.loads(result)
        assert data[0]["health"]["error"] == "connection refused"

    def test_should_not_include_health_field_when_port_not_in_health_dict(self, port_info_node):
        result = render_json([port_info_node], health={9999: MagicMock()})

        data = json.loads(result)
        assert "health" not in data[0]

    def test_should_omit_health_key_entirely_when_health_is_none(self, port_info_node):
        result = render_json([port_info_node], health=None)

        data = json.loads(result)
        assert "health" not in data[0]

    def test_should_include_all_ports_in_json_array(self, sample_ports):
        result = render_json(sample_ports)

        data = json.loads(result)
        assert len(data) == 3

    def test_should_null_pid_when_pid_is_none(self):
        info = PortInfo(port=6379, pid=None)
        result = render_json([info])

        data = json.loads(result)
        assert data[0]["pid"] is None


# avoid import error from test using MagicMock inside class above
from unittest.mock import MagicMock  # noqa: E402
