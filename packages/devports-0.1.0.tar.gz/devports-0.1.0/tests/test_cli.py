"""Tests for devports.cli module."""

from __future__ import annotations

import json
import signal
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from devports.cli import cli
from devports.scanner import PortInfo


def make_port(port: int, service: str = "", process: str = "", pid: int | None = None) -> PortInfo:
    info = PortInfo(port=port, pid=pid, process_name=process)
    info.service_name = service
    return info


# ---------------------------------------------------------------------------
# Helpers / shared mock builder
# ---------------------------------------------------------------------------


def _patch_scan(ports, health=None):
    """Return a context manager that patches _scan_and_identify."""
    if health is None:
        health = {}
    return patch("devports.cli._scan_and_identify", return_value=(ports, health))


# ---------------------------------------------------------------------------
# Default command (no subcommand)
# ---------------------------------------------------------------------------


class TestCliDefault:
    def setup_method(self):
        self.runner = CliRunner()

    def test_should_exit_zero_when_ports_are_found(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports):
            result = self.runner.invoke(cli, [])

        assert result.exit_code == 0

    def test_should_display_port_number_in_table_output(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports):
            result = self.runner.invoke(cli, [])

        assert "3000" in result.output

    def test_should_display_service_name_in_table_output(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports):
            result = self.runner.invoke(cli, [])

        assert "next-dev" in result.output

    def test_should_exit_zero_when_no_ports_are_found(self):
        with _patch_scan([]):
            result = self.runner.invoke(cli, [])

        assert result.exit_code == 0

    def test_should_display_no_ports_message_when_list_is_empty(self):
        with _patch_scan([]):
            result = self.runner.invoke(cli, [])

        assert "No listening ports found" in result.output

    def test_should_output_valid_json_when_json_flag_is_passed(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports):
            result = self.runner.invoke(cli, ["--json"])

        parsed = json.loads(result.output)
        assert isinstance(parsed, list)

    def test_should_include_port_in_json_output(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports):
            result = self.runner.invoke(cli, ["--json"])

        data = json.loads(result.output)
        assert data[0]["port"] == 3000

    def test_should_skip_health_check_when_no_health_flag_is_passed(self):
        with _patch_scan([]) as mock_scan:
            self.runner.invoke(cli, ["--no-health"])

        mock_scan.assert_called_once_with(health_check=False)

    def test_should_run_health_check_by_default(self):
        with _patch_scan([]) as mock_scan:
            self.runner.invoke(cli, [])

        mock_scan.assert_called_once_with(health_check=True)

    def test_should_output_valid_json_when_no_ports_and_json_flag(self):
        with _patch_scan([]):
            result = self.runner.invoke(cli, ["--json"])

        assert json.loads(result.output) == []

    def test_should_include_pid_in_output_when_pid_flag_is_passed(self):
        ports = [make_port(3000, "next-dev", "node", 9999)]

        with _patch_scan(ports):
            result = self.runner.invoke(cli, ["--pid"])

        assert "9999" in result.output

    def test_should_include_cmdline_in_output_when_cmd_flag_is_passed(self):
        port = make_port(3000, "next-dev", "node", 1234)
        port.cmdline = "node server.js"

        with _patch_scan([port]):
            result = self.runner.invoke(cli, ["--cmd"])

        assert "node server.js" in result.output


# ---------------------------------------------------------------------------
# open_port subcommand
# ---------------------------------------------------------------------------


class TestCliOpenPort:
    def setup_method(self):
        self.runner = CliRunner()

    def test_should_exit_zero_when_port_is_found_by_number(self):
        ports = [make_port(3000, "next-dev", "node", 1)]

        with _patch_scan(ports, {}):
            with patch("devports.cli.subprocess.run"):
                result = self.runner.invoke(cli, ["open-port", "3000"])

        assert result.exit_code == 0

    def test_should_display_url_when_port_found_by_number(self):
        ports = [make_port(3000, "next-dev", "node", 1)]

        with _patch_scan(ports, {}):
            with patch("devports.cli.subprocess.run"):
                result = self.runner.invoke(cli, ["open-port", "3000"])

        assert "http://127.0.0.1:3000" in result.output

    def test_should_find_port_by_service_name(self):
        ports = [make_port(3000, "next-dev", "node", 1)]

        with _patch_scan(ports, {}):
            with patch("devports.cli.subprocess.run"):
                result = self.runner.invoke(cli, ["open-port", "next-dev"])

        assert "http://127.0.0.1:3000" in result.output

    def test_should_exit_nonzero_when_port_not_found(self):
        with _patch_scan([], {}):
            result = self.runner.invoke(cli, ["open-port", "9999"])

        assert result.exit_code != 0

    def test_should_print_not_found_message_when_port_missing(self):
        with _patch_scan([], {}):
            result = self.runner.invoke(cli, ["open-port", "9999"])

        assert "Not found" in result.output

    def test_should_try_wslview_when_xdg_open_not_found(self):
        ports = [make_port(3000, "next-dev", "node", 1)]

        def fake_run(cmd, **kwargs):
            if cmd[0] == "xdg-open":
                raise FileNotFoundError
            return MagicMock()

        with _patch_scan(ports, {}):
            with patch("devports.cli.subprocess.run", side_effect=fake_run) as mock_run:
                self.runner.invoke(cli, ["open-port", "3000"])

        called_cmds = [call.args[0][0] for call in mock_run.call_args_list]
        assert "wslview" in called_cmds

    def test_should_print_fallback_url_when_both_open_commands_fail(self):
        ports = [make_port(3000, "next-dev", "node", 1)]

        with _patch_scan(ports, {}):
            with patch("devports.cli.subprocess.run", side_effect=FileNotFoundError):
                result = self.runner.invoke(cli, ["open-port", "3000"])

        assert "http://127.0.0.1:3000" in result.output

    def test_should_match_service_name_case_insensitively(self):
        ports = [make_port(3000, "Next-Dev", "node", 1)]

        with _patch_scan(ports, {}):
            with patch("devports.cli.subprocess.run"):
                result = self.runner.invoke(cli, ["open-port", "next-dev"])

        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# kill subcommand
# ---------------------------------------------------------------------------


class TestCliKill:
    def setup_method(self):
        self.runner = CliRunner()

    def test_should_exit_zero_when_sigterm_sent_successfully(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports, {}):
            with patch("os.kill"):
                result = self.runner.invoke(cli, ["kill", "3000"])

        assert result.exit_code == 0

    def test_should_print_sigterm_sent_message(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports, {}):
            with patch("os.kill"):
                result = self.runner.invoke(cli, ["kill", "3000"])

        assert "1234" in result.output

    def test_should_send_sigterm_to_correct_pid(self):
        ports = [make_port(3000, "next-dev", "node", 5678)]

        with _patch_scan(ports, {}):
            with patch("os.kill") as mock_kill:
                self.runner.invoke(cli, ["kill", "3000"])

        mock_kill.assert_called_once_with(5678, signal.SIGTERM)

    def test_should_exit_nonzero_when_port_not_found(self):
        with _patch_scan([], {}):
            result = self.runner.invoke(cli, ["kill", "9999"])

        assert result.exit_code != 0

    def test_should_print_not_found_message_when_port_missing(self):
        with _patch_scan([], {}):
            result = self.runner.invoke(cli, ["kill", "9999"])

        assert "No process found on port 9999" in result.output

    def test_should_exit_nonzero_when_pid_is_none(self):
        ports = [make_port(3000, "next-dev", "node", pid=None)]

        with _patch_scan(ports, {}):
            result = self.runner.invoke(cli, ["kill", "3000"])

        assert result.exit_code != 0

    def test_should_print_cannot_determine_pid_message_when_pid_is_none(self):
        ports = [make_port(3000, "next-dev", "node", pid=None)]

        with _patch_scan(ports, {}):
            result = self.runner.invoke(cli, ["kill", "3000"])

        assert "Cannot determine PID" in result.output

    def test_should_print_already_gone_when_process_lookup_error(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports, {}):
            with patch("os.kill", side_effect=ProcessLookupError):
                result = self.runner.invoke(cli, ["kill", "3000"])

        assert "already gone" in result.output

    def test_should_exit_nonzero_when_permission_denied(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports, {}):
            with patch("os.kill", side_effect=PermissionError):
                result = self.runner.invoke(cli, ["kill", "3000"])

        assert result.exit_code != 0

    def test_should_print_permission_denied_message_when_permission_error(self):
        ports = [make_port(3000, "next-dev", "node", 1234)]

        with _patch_scan(ports, {}):
            with patch("os.kill", side_effect=PermissionError):
                result = self.runner.invoke(cli, ["kill", "3000"])

        assert "Permission denied" in result.output


# ---------------------------------------------------------------------------
# --version flag
# ---------------------------------------------------------------------------


class TestCliVersion:
    def setup_method(self):
        self.runner = CliRunner()

    def test_should_exit_zero_when_version_flag_is_passed(self):
        result = self.runner.invoke(cli, ["--version"])

        assert result.exit_code == 0

    def test_should_include_version_string_in_output(self):
        result = self.runner.invoke(cli, ["--version"])

        assert "0.1.0" in result.output
