"""Tests for devports.health module."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from devports.health import HealthResult, HealthStatus, check_all_health, check_health

# ---------------------------------------------------------------------------
# check_health
# ---------------------------------------------------------------------------


class TestCheckHealth:
    def test_should_return_healthy_status_when_connection_succeeds(self):
        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        with patch("devports.health.socket.create_connection", return_value=mock_sock):
            result = check_health(3000)

        assert result.status == HealthStatus.HEALTHY

    def test_should_return_response_ms_when_connection_succeeds(self):
        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        with patch("devports.health.socket.create_connection", return_value=mock_sock):
            result = check_health(3000)

        assert result.response_ms is not None
        assert result.response_ms >= 0

    def test_should_return_correct_port_when_connection_succeeds(self):
        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        with patch("devports.health.socket.create_connection", return_value=mock_sock):
            result = check_health(8080)

        assert result.port == 8080

    def test_should_return_unhealthy_status_when_connection_refused(self):
        with patch(
            "devports.health.socket.create_connection",
            side_effect=ConnectionRefusedError,
        ):
            result = check_health(3000)

        assert result.status == HealthStatus.UNHEALTHY

    def test_should_set_connection_refused_error_message(self):
        with patch(
            "devports.health.socket.create_connection",
            side_effect=ConnectionRefusedError,
        ):
            result = check_health(3000)

        assert result.error == "connection refused"

    def test_should_return_unhealthy_status_when_connection_times_out(self):
        with patch(
            "devports.health.socket.create_connection",
            side_effect=TimeoutError,
        ):
            result = check_health(3000)

        assert result.status == HealthStatus.UNHEALTHY

    def test_should_set_timeout_error_message(self):
        with patch(
            "devports.health.socket.create_connection",
            side_effect=TimeoutError,
        ):
            result = check_health(3000)

        assert result.error == "timeout"

    def test_should_return_unknown_status_when_oserror_occurs(self):
        with patch(
            "devports.health.socket.create_connection",
            side_effect=OSError("Network unreachable"),
        ):
            result = check_health(3000)

        assert result.status == HealthStatus.UNKNOWN

    def test_should_include_oserror_message_in_error_field(self):
        with patch(
            "devports.health.socket.create_connection",
            side_effect=OSError("Network unreachable"),
        ):
            result = check_health(3000)

        assert "Network unreachable" in result.error

    def test_should_pass_host_and_timeout_to_create_connection(self):
        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        with patch("devports.health.socket.create_connection", return_value=mock_sock) as mock_conn:
            check_health(3000, host="10.0.0.1", timeout=1.5)

        mock_conn.assert_called_once_with(("10.0.0.1", 3000), timeout=1.5)

    def test_should_use_default_host_127_0_0_1(self):
        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        with patch("devports.health.socket.create_connection", return_value=mock_sock) as mock_conn:
            check_health(3000)

        args = mock_conn.call_args[0]
        assert args[0] == ("127.0.0.1", 3000)

    def test_should_return_none_response_ms_when_unhealthy(self):
        with patch(
            "devports.health.socket.create_connection",
            side_effect=ConnectionRefusedError,
        ):
            result = check_health(3000)

        assert result.response_ms is None


# ---------------------------------------------------------------------------
# check_all_health
# ---------------------------------------------------------------------------


class TestCheckAllHealth:
    def test_should_return_dict_with_result_for_each_port(self):
        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        with patch("devports.health.socket.create_connection", return_value=mock_sock):
            results = check_all_health([3000, 8000, 5432])

        assert set(results.keys()) == {3000, 8000, 5432}

    def test_should_return_empty_dict_when_no_ports_given(self):
        results = check_all_health([])

        assert results == {}

    def test_should_return_healthy_result_for_open_port(self):
        mock_sock = MagicMock()
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)

        with patch("devports.health.socket.create_connection", return_value=mock_sock):
            results = check_all_health([3000])

        assert results[3000].status == HealthStatus.HEALTHY

    def test_should_return_unhealthy_for_refused_port_and_healthy_for_open(self):
        def fake_create_connection(addr, timeout):
            host, port = addr
            if port == 3000:
                mock_sock = MagicMock()
                mock_sock.__enter__ = MagicMock(return_value=mock_sock)
                mock_sock.__exit__ = MagicMock(return_value=False)
                return mock_sock
            raise ConnectionRefusedError

        with patch("devports.health.socket.create_connection", side_effect=fake_create_connection):
            results = check_all_health([3000, 9999])

        assert results[3000].status == HealthStatus.HEALTHY
        assert results[9999].status == HealthStatus.UNHEALTHY

    def test_should_call_check_health_for_each_port(self):
        with patch("devports.health.check_health") as mock_check:
            mock_check.return_value = HealthResult(port=0, status=HealthStatus.HEALTHY)
            check_all_health([1111, 2222, 3333])

        assert mock_check.call_count == 3

    def test_should_pass_host_and_timeout_to_each_check(self):
        with patch("devports.health.check_health") as mock_check:
            mock_check.return_value = HealthResult(port=0, status=HealthStatus.HEALTHY)
            check_all_health([1234], host="192.168.1.1", timeout=0.5)

        mock_check.assert_called_once_with(1234, "192.168.1.1", 0.5)

    def test_should_return_health_result_instances(self):
        with patch("devports.health.socket.create_connection", side_effect=ConnectionRefusedError):
            results = check_all_health([9999])

        assert isinstance(results[9999], HealthResult)
