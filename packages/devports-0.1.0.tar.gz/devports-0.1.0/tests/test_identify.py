"""Tests for devports.identify module."""

from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

from devports.identify import (
    _extract_app_name,
    identify_docker_containers,
    identify_service,
)
from devports.scanner import PortInfo
from tests.conftest import DOCKER_PS_LINE_MULTI_PORT, DOCKER_PS_LINE_SINGLE, DOCKER_PS_OUTPUT

# ---------------------------------------------------------------------------
# identify_service
# ---------------------------------------------------------------------------


class TestIdentifyService:
    def test_should_return_docker_container_name_when_docker_container_is_set(
        self, port_info_docker
    ):
        result = identify_service(port_info_docker)

        assert result == "my-app"

    def test_should_return_mapped_name_when_process_is_known_non_runtime(self):
        # Use a port not in KNOWN_PORTS so process-name mapping wins
        info = PortInfo(port=19999, pid=1, process_name="nginx")
        result = identify_service(info)

        assert result == "nginx"

    def test_should_return_known_port_name_when_port_is_in_database(self):
        info = PortInfo(port=5432, pid=None, process_name="")
        result = identify_service(info)

        assert result == "postgres"

    def test_should_return_process_name_when_port_not_in_database_and_no_runtime(self):
        info = PortInfo(port=12345, pid=1, process_name="my-daemon")
        result = identify_service(info)

        assert result == "my-daemon"

    def test_should_return_port_fallback_when_no_info_available(self):
        info = PortInfo(port=54321)
        result = identify_service(info)

        assert result == "port-54321"

    def test_should_extract_app_name_from_cmdline_when_runtime_is_node(self):
        info = PortInfo(
            port=3000,
            pid=1,
            process_name="node",
            cmdline="node /app/node_modules/.bin/next start",
        )
        result = identify_service(info)

        assert result == "next-dev"

    def test_should_extract_app_name_from_cmdline_when_runtime_is_python_django(self):
        info = PortInfo(
            port=8000,
            pid=1,
            process_name="python",
            cmdline="python manage.py runserver",
        )
        result = identify_service(info)

        assert result == "django"

    def test_should_fall_back_to_known_port_when_runtime_cmdline_yields_nothing(self):
        info = PortInfo(
            port=8000,
            pid=1,
            process_name="python",
            cmdline="python some_unknown_script.py",
        )
        result = identify_service(info)

        # port 8000 is in KNOWN_PORTS as "django"
        assert result == "django"

    def test_should_return_process_name_when_runtime_has_no_cmdline(self):
        info = PortInfo(port=99999, pid=1, process_name="node", cmdline="")
        result = identify_service(info)

        assert result == "node"

    def test_should_prefer_docker_container_over_everything_else(self):
        info = PortInfo(port=5432, pid=1, process_name="postgres")
        info.docker_container = "my-postgres"
        result = identify_service(info)

        assert result == "my-postgres"


# ---------------------------------------------------------------------------
# _extract_app_name - node
# ---------------------------------------------------------------------------


class TestExtractAppNameNode:
    def test_should_return_next_dev_when_cmdline_contains_next(self):
        result = _extract_app_name("node /app/.bin/next start", "node")

        assert result == "next-dev"

    def test_should_return_vite_when_cmdline_contains_vite(self):
        result = _extract_app_name("node /app/.bin/vite --host", "node")

        assert result == "vite"

    def test_should_return_nuxt_when_cmdline_contains_nuxt(self):
        result = _extract_app_name("node /app/.bin/nuxt dev", "node")

        assert result == "nuxt"

    def test_should_return_remix_when_cmdline_contains_remix(self):
        result = _extract_app_name("node /app/.bin/remix dev", "node")

        assert result == "remix"

    def test_should_return_express_when_cmdline_contains_express(self):
        result = _extract_app_name("node express-server.js", "node")

        assert result == "express"

    def test_should_return_nestjs_when_cmdline_contains_nest(self):
        result = _extract_app_name("node /app/.bin/nest start", "node")

        assert result == "nestjs"

    def test_should_return_script_stem_when_cmdline_ends_with_js(self):
        result = _extract_app_name("node server.js", "node")

        assert result == "server"

    def test_should_return_script_stem_when_cmdline_ends_with_mjs(self):
        result = _extract_app_name("node index.mjs", "node")

        assert result == "index"

    def test_should_return_script_stem_when_cmdline_ends_with_ts(self):
        result = _extract_app_name("node app.ts", "node")

        assert result == "app"

    def test_should_strip_directory_prefix_from_script_name(self):
        result = _extract_app_name("node /var/app/src/server.js", "node")

        assert result == "server"

    def test_should_return_empty_string_when_no_recognizable_script(self):
        result = _extract_app_name("node", "node")

        assert result == ""


# ---------------------------------------------------------------------------
# _extract_app_name - python
# ---------------------------------------------------------------------------


class TestExtractAppNamePython:
    def test_should_return_django_when_cmdline_contains_manage_py(self):
        result = _extract_app_name("python manage.py runserver", "python")

        assert result == "django"

    def test_should_return_django_when_cmdline_contains_django(self):
        result = _extract_app_name("python -m django runserver", "python")

        assert result == "django"

    def test_should_return_flask_when_cmdline_contains_flask(self):
        result = _extract_app_name("python -m flask run", "python")

        assert result == "flask"

    def test_should_return_fastapi_when_cmdline_contains_uvicorn(self):
        result = _extract_app_name("python -m uvicorn main:app", "python")

        assert result == "fastapi"

    def test_should_return_fastapi_when_cmdline_contains_fastapi(self):
        result = _extract_app_name("python -m fastapi dev", "python")

        assert result == "fastapi"

    def test_should_return_gunicorn_when_cmdline_contains_gunicorn(self):
        result = _extract_app_name("gunicorn app:create_app()", "python")

        assert result == "gunicorn"

    def test_should_return_jupyter_when_cmdline_contains_jupyter(self):
        result = _extract_app_name("python -m jupyter notebook", "python")

        assert result == "jupyter"

    def test_should_return_empty_string_when_no_python_framework_detected(self):
        result = _extract_app_name("python script.py", "python")

        assert result == ""


# ---------------------------------------------------------------------------
# _extract_app_name - java
# ---------------------------------------------------------------------------


class TestExtractAppNameJava:
    def test_should_return_spring_when_cmdline_contains_spring(self):
        result = _extract_app_name("java -jar spring-boot-app.jar", "java")

        assert result == "spring"

    def test_should_return_tomcat_when_cmdline_contains_tomcat(self):
        result = _extract_app_name("java -cp /opt/tomcat/lib Bootstrap", "java")

        assert result == "tomcat"

    def test_should_return_empty_string_when_no_java_framework_detected(self):
        result = _extract_app_name("java -jar unknown.jar", "java")

        assert result == ""


# ---------------------------------------------------------------------------
# identify_docker_containers
# ---------------------------------------------------------------------------


class TestIdentifyDockerContainers:
    def test_should_set_docker_container_name_when_port_matches(self):
        info = PortInfo(port=6379)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = DOCKER_PS_LINE_SINGLE

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info])

        assert info.docker_container == "redis"

    def test_should_add_docker_tag_when_port_matches_container(self):
        info = PortInfo(port=6379)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = DOCKER_PS_LINE_SINGLE

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info])

        assert "docker" in info.tags

    def test_should_handle_multi_port_container(self):
        info_80 = PortInfo(port=8080)
        info_443 = PortInfo(port=8443)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = DOCKER_PS_LINE_MULTI_PORT

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info_80, info_443])

        assert info_80.docker_container == "my-app"
        assert info_443.docker_container == "my-app"

    def test_should_enrich_multiple_containers_at_once(self):
        info_redis = PortInfo(port=6379)
        info_app = PortInfo(port=8080)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = DOCKER_PS_OUTPUT

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info_redis, info_app])

        assert info_redis.docker_container == "redis"
        assert info_app.docker_container == "my-app"

    def test_should_leave_unmatched_port_unchanged(self):
        info = PortInfo(port=9999)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = DOCKER_PS_LINE_SINGLE

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info])

        assert info.docker_container is None
        assert info.tags == []

    def test_should_do_nothing_when_docker_not_found(self):
        info = PortInfo(port=6379)

        with patch("devports.identify.subprocess.run", side_effect=FileNotFoundError):
            identify_docker_containers([info])

        assert info.docker_container is None

    def test_should_do_nothing_when_docker_times_out(self):
        info = PortInfo(port=6379)

        with patch(
            "devports.identify.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="docker", timeout=5),
        ):
            identify_docker_containers([info])

        assert info.docker_container is None

    def test_should_do_nothing_when_docker_returns_nonzero(self):
        info = PortInfo(port=6379)
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info])

        assert info.docker_container is None

    def test_should_skip_malformed_json_lines(self):
        info = PortInfo(port=6379)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "not-json\n" + DOCKER_PS_LINE_SINGLE

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info])

        assert info.docker_container == "redis"

    def test_should_skip_port_binding_without_arrow(self):
        info = PortInfo(port=6379)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = '{"Names":"redis","Ports":"6379/tcp"}'

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info])

        assert info.docker_container is None

    def test_should_handle_empty_docker_ps_output(self):
        info = PortInfo(port=6379)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""

        with patch("devports.identify.subprocess.run", return_value=mock_result):
            identify_docker_containers([info])

        assert info.docker_container is None

    def test_should_pass_correct_args_to_docker(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""

        with patch("devports.identify.subprocess.run", return_value=mock_result) as mock_run:
            identify_docker_containers([])

        mock_run.assert_called_once_with(
            ["docker", "ps", "--format", "{{json .}}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
