from __future__ import annotations

import subprocess
import tempfile
import unittest
import json
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

from ait.app import create_commit_for_attempt, create_attempt, create_intent, show_attempt
from ait.db import connect_db, list_memory_facts, NewMemoryFact, run_migrations, upsert_memory_fact
from ait.db.repositories import update_attempt
from ait.memory import (
    add_memory_note,
    add_attempt_memory_note,
    add_memory_candidates_for_attempt,
    agent_memory_status,
    build_relevant_memory_recall,
    build_repo_memory,
    ensure_agent_memory_imported,
    import_agent_memory,
    lint_memory_notes,
    list_memory_notes,
    MemorySearchResult,
    remove_memory_note,
    render_repo_memory_text,
    search_repo_memory,
    _normalize_recall_ranker_scores,
    _temporal_ranked_result,
)
from ait.memory.repository import open_memory_repository
from ait.memory_policy import init_memory_policy


class MemoryTests(unittest.TestCase):
    def test_memory_repository_reuses_one_connection_for_multiple_helpers(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)

            with patch("ait.memory.repository.connect_db", wraps=connect_db) as connect:
                with open_memory_repository(repo_root) as repo:
                    first = repo.add_note(topic="release", body="Run twine check.", source="manual")
                    second = repo.add_note(topic="release", body="Run pytest.", source="manual")
                    self.assertTrue(repo.active_source_exists("manual"))
                    self.assertIn(first, repo.all_active_notes())
                    self.assertTrue(repo.remove_note(note_id=second.id))

            self.assertEqual(1, connect.call_count)

    def test_build_repo_memory_summarizes_recent_attempts_and_hot_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            intent = create_intent(repo_root, title="Remember change", description=None, kind="feature")
            attempt = create_attempt(repo_root, intent_id=intent.intent_id, agent_id="claude-code:test")
            worktree = Path(attempt.workspace_ref)
            (worktree / "memory.txt").write_text("remember me\n", encoding="utf-8")
            _git(worktree, "add", "memory.txt")
            create_commit_for_attempt(repo_root, attempt_id=attempt.attempt_id, message="memory")

            memory = build_repo_memory(repo_root)
            text = render_repo_memory_text(memory)

            self.assertEqual(str(repo_root.resolve()), memory.repo_root)
            self.assertEqual(1, len(memory.recent_attempts))
            self.assertEqual("Remember change", memory.recent_attempts[0].intent_title)
            self.assertEqual(("memory.txt",), memory.recent_attempts[0].changed_files)
            self.assertEqual(("memory.txt",), memory.hot_files)
            self.assertIn("AIT Long-Term Repo Memory", text)
            self.assertIn("Remember change", text)
            self.assertIn("memory.txt", text)

    def test_memory_notes_can_be_added_listed_filtered_and_removed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)

            note = add_memory_note(
                repo_root,
                topic="architecture",
                body="Keep API adapters thin.",
            )

            self.assertEqual((note,), list_memory_notes(repo_root, topic="architecture"))
            memory = build_repo_memory(repo_root, topic="architecture")
            text = render_repo_memory_text(memory)
            self.assertEqual((note,), memory.notes)
            self.assertIn("Curated Notes:", text)
            self.assertIn("Keep API adapters thin.", text)

            self.assertTrue(remove_memory_note(repo_root, note_id=note.id))
            self.assertEqual((), list_memory_notes(repo_root))

    def test_memory_candidates_keep_uncorroborated_rules_as_candidates(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            attempt_id = _record_trace_attempt(
                repo_root,
                title="Project rule",
                trace_text="Rule: 以後所有 API route 必須使用 zod 驗證。\nToken usage: total=1\n",
            )
            attempt_result = show_attempt(repo_root, attempt_id=attempt_id)

            notes = add_memory_candidates_for_attempt(repo_root, attempt_result)
            durable_notes = list_memory_notes(repo_root, topic="durable-memory")
            candidate_notes = list_memory_notes(repo_root, topic="memory-candidate")
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            facts = list_memory_facts(conn, status="accepted", kind="rule")

            self.assertEqual(1, len(notes))
            self.assertEqual((), durable_notes)
            self.assertEqual(1, len(candidate_notes))
            self.assertEqual(0, len(facts))
            self.assertIn("kind=constraint", candidate_notes[0].body)
            self.assertIn("status=candidate", candidate_notes[0].body)
            self.assertIn("以後所有 API route 必須使用 zod 驗證", candidate_notes[0].body)
            self.assertNotIn("Token usage", candidate_notes[0].body)

    def test_memory_search_and_recall_use_accepted_structured_facts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            _upsert_test_fact(
                conn,
                fact_id="release-rule",
                kind="rule",
                body="以後所有 release 必須先跑 pytest。",
                updated_at="2026-04-23T00:00:00Z",
            )

            results = search_repo_memory(repo_root, "release pytest")
            recall = build_relevant_memory_recall(repo_root, "release pytest")

            fact_results = [result for result in results if result.kind == "fact"]
            self.assertTrue(fact_results)
            self.assertEqual("accepted", fact_results[0].metadata["status"])
            self.assertEqual("fact", recall.selected[0].kind)
            self.assertIn("release 必須先跑 pytest", recall.selected[0].text)
            self.assertEqual("temporal-v1", recall.selected[0].metadata["temporal_ranker"])
            self.assertIn("temporal_score", recall.selected[0].metadata)

    def test_relevant_memory_recall_prefers_recent_current_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            _upsert_test_fact(
                conn,
                fact_id="fact:old-state",
                kind="current_state",
                body="Billing retry cache mode uses legacy queue.",
                updated_at="2024-01-01T00:00:00Z",
            )
            _upsert_test_fact(
                conn,
                fact_id="fact:recent-state",
                kind="current_state",
                body="Billing retry cache mode uses durable queue.",
                updated_at="2026-04-20T00:00:00Z",
            )

            recall = build_relevant_memory_recall(repo_root, "billing retry cache mode", limit=1)

            self.assertEqual(("fact:recent-state",), tuple(item.id for item in recall.selected))
            self.assertEqual("temporal-v1", recall.selected[0].metadata["temporal_ranker"])
            self.assertIn("temporal_age_days", recall.selected[0].metadata)

    def test_relevant_memory_recall_skips_superseded_accepted_facts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            _upsert_test_fact(
                conn,
                fact_id="fact:current-state",
                kind="current_state",
                body="Billing retry cache mode uses durable queue.",
                updated_at="2026-04-20T00:00:00Z",
            )
            _upsert_test_fact(
                conn,
                fact_id="fact:superseded-state",
                kind="current_state",
                body="Billing retry cache mode uses legacy queue.",
                updated_at="2026-04-20T00:00:00Z",
                superseded_by="fact:current-state",
            )

            recall = build_relevant_memory_recall(repo_root, "billing retry cache mode", limit=6)

            selected_ids = tuple(item.id for item in recall.selected)
            self.assertIn("fact:current-state", selected_ids)
            self.assertNotIn("fact:superseded-state", selected_ids)

    def test_relevant_memory_recall_skips_expired_accepted_facts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            _upsert_test_fact(
                conn,
                fact_id="fact:expired-state",
                kind="current_state",
                body="Billing retry cache mode uses legacy queue.",
                updated_at="2024-01-01T00:00:00Z",
                valid_to="2024-01-02T00:00:00Z",
            )
            _upsert_test_fact(
                conn,
                fact_id="fact:active-state",
                kind="current_state",
                body="Billing retry cache mode uses durable queue.",
                updated_at="2026-04-20T00:00:00Z",
            )

            recall = build_relevant_memory_recall(repo_root, "billing retry cache mode", limit=6)

            selected_ids = tuple(item.id for item in recall.selected)
            self.assertIn("fact:active-state", selected_ids)
            self.assertNotIn("fact:expired-state", selected_ids)

    def test_relevant_memory_recall_skips_policy_blocked_facts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            (repo_root / ".ait").mkdir()
            (repo_root / ".ait" / "memory-policy.json").write_text(
                json.dumps(
                    {
                        "exclude_paths": ["secret/**"],
                        "exclude_transcript_patterns": [],
                        "recall_source_allow": ["trusted:*"],
                        "recall_source_block": ["blocked:*"],
                        "recall_lint_block_severities": ["error"],
                    }
                ),
                encoding="utf-8",
            )
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            _upsert_test_fact(
                conn,
                fact_id="fact:trusted",
                kind="rule",
                body="Release workflow must run pytest.",
                updated_at="2026-04-20T00:00:00Z",
                source_trace_ref="trusted:release",
            )
            _upsert_test_fact(
                conn,
                fact_id="fact:blocked-source",
                kind="rule",
                body="Release workflow must run pytest.",
                updated_at="2026-04-20T00:00:00Z",
                source_trace_ref="blocked:release",
            )
            _upsert_test_fact(
                conn,
                fact_id="fact:excluded-path",
                kind="rule",
                body="Release workflow must run pytest.",
                updated_at="2026-04-20T00:00:00Z",
                source_file_path="secret/release.md",
            )
            _upsert_test_fact(
                conn,
                fact_id="fact:untrusted-logical",
                kind="rule",
                body="Release workflow must run pytest.",
                updated_at="2026-04-20T00:00:00Z",
                source_trace_ref="untrusted:release",
            )

            recall = build_relevant_memory_recall(repo_root, "release workflow pytest", limit=6)

            selected_ids = {item.id for item in recall.selected}
            skipped = {item["id"]: item["reason"] for item in recall.skipped}
            self.assertIn("fact:trusted", selected_ids)
            self.assertNotIn("fact:blocked-source", selected_ids)
            self.assertNotIn("fact:excluded-path", selected_ids)
            self.assertNotIn("fact:untrusted-logical", selected_ids)
            self.assertEqual("fact source blocked by memory policy", skipped["fact:blocked-source"])
            self.assertEqual("fact source path excluded by memory policy", skipped["fact:excluded-path"])
            self.assertEqual("fact source not allowed by memory policy", skipped["fact:untrusted-logical"])

    def test_relevant_memory_recall_keeps_old_decision_ahead_of_old_current_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            _upsert_test_fact(
                conn,
                fact_id="fact:old-state",
                kind="current_state",
                body="Billing retry architecture uses job queue.",
                updated_at="2024-01-01T00:00:00Z",
            )
            _upsert_test_fact(
                conn,
                fact_id="fact:old-decision",
                kind="decision",
                body="Billing retry architecture uses job queue.",
                updated_at="2024-01-01T00:00:00Z",
            )

            recall = build_relevant_memory_recall(repo_root, "billing retry architecture job queue", limit=1)

            self.assertEqual(("fact:old-decision",), tuple(item.id for item in recall.selected))

    def test_relevant_memory_recall_does_not_rank_failure_above_rule_on_same_relevance(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            _upsert_test_fact(
                conn,
                fact_id="fact:failure",
                kind="failure",
                body="Release package workflow requires pytest.",
                updated_at="2026-04-20T00:00:00Z",
                confidence="high",
            )
            _upsert_test_fact(
                conn,
                fact_id="fact:rule",
                kind="rule",
                body="Release package workflow requires pytest.",
                updated_at="2026-04-20T00:00:00Z",
                confidence="high",
            )

            recall = build_relevant_memory_recall(repo_root, "release package workflow pytest", limit=1)

            self.assertEqual(("fact:rule",), tuple(item.id for item in recall.selected))

    def test_recall_ranker_scores_are_normalized_per_ranker(self) -> None:
        results = _normalize_recall_ranker_scores(
            [
                MemorySearchResult(
                    kind="fact",
                    id="literal",
                    score=15.0,
                    title="literal",
                    text="literal",
                    metadata={"ranker": "literal"},
                ),
                MemorySearchResult(
                    kind="fact",
                    id="vector-low",
                    score=0.25,
                    title="vector",
                    text="vector",
                    metadata={"ranker": "vector"},
                ),
                MemorySearchResult(
                    kind="fact",
                    id="vector-high",
                    score=0.75,
                    title="vector",
                    text="vector",
                    metadata={"ranker": "vector"},
                ),
            ]
        )

        by_id = {result.id: result for result in results}
        self.assertEqual(1.0, by_id["literal"].score)
        self.assertEqual(0.0, by_id["vector-low"].score)
        self.assertEqual(1.0, by_id["vector-high"].score)
        self.assertEqual(15.0, by_id["literal"].metadata["ranker_raw_score"])
        self.assertEqual(0.75, by_id["vector-high"].metadata["ranker_raw_score"])

    def test_recall_ranker_normalization_treats_tiny_float_drift_as_tie(self) -> None:
        results = _normalize_recall_ranker_scores(
            [
                MemorySearchResult(
                    kind="fact",
                    id="left",
                    score=0.7957873682853489,
                    title="left",
                    text="left",
                    metadata={"ranker": "vector"},
                ),
                MemorySearchResult(
                    kind="fact",
                    id="right",
                    score=0.7957873682853488,
                    title="right",
                    text="right",
                    metadata={"ranker": "vector"},
                ),
            ]
        )

        self.assertEqual((1.0, 1.0), tuple(result.score for result in results))

    def test_manual_notes_are_allowed_and_ranked_as_manual_memory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            add_memory_note(
                repo_root,
                topic="release",
                source="manual",
                body="Release checklist must include package smoke tests.",
            )

            recall = build_relevant_memory_recall(repo_root, "release package smoke tests")

            self.assertEqual("manual", recall.selected[0].metadata["temporal_kind"])
            self.assertEqual("manual", recall.selected[0].metadata["kind"])

    def test_temporal_ranking_formula_uses_expected_factors(self) -> None:
        result = MemorySearchResult(
            kind="fact",
            id="fact:rule",
            score=2.0,
            title="release",
            text="release rule",
            metadata={
                "kind": "rule",
                "confidence": "high",
                "updated_at": "2026-04-20T00:00:00Z",
            },
        )

        ranked = _temporal_ranked_result(
            result,
            now=datetime.fromisoformat("2026-04-20T00:00:00+00:00"),
        )

        self.assertAlmostEqual(2.0 * 1.0 * 1.05 * 1.03, ranked.score, places=4)

    def test_temporal_ranking_marks_future_anchor_as_unknown_age(self) -> None:
        result = MemorySearchResult(
            kind="fact",
            id="fact:future",
            score=2.0,
            title="future",
            text="future",
            metadata={
                "kind": "current_state",
                "confidence": "high",
                "updated_at": "2026-05-20T00:00:00Z",
            },
        )

        ranked = _temporal_ranked_result(
            result,
            now=datetime.fromisoformat("2026-04-20T00:00:00+00:00"),
        )

        self.assertTrue(ranked.metadata["temporal_future_anchor"])
        self.assertNotIn("temporal_age_days", ranked.metadata)

    def test_memory_candidates_keep_failed_attempts_as_candidates(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            attempt_id = _record_trace_attempt(
                repo_root,
                title="Failed project rule",
                trace_text="Rule: 以後部署流程必須先跑 pytest。\n",
                verified_status="failed",
                result_exit_code=1,
            )
            attempt_result = show_attempt(repo_root, attempt_id=attempt_id)

            notes = add_memory_candidates_for_attempt(repo_root, attempt_result)
            candidates = list_memory_notes(repo_root, topic="memory-candidate")
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            facts = list_memory_facts(conn, status="candidate")

            self.assertEqual(1, len(notes))
            self.assertEqual(1, len(candidates))
            self.assertEqual(1, len(facts))
            self.assertIn("status=candidate", candidates[0].body)
            self.assertEqual("candidate", facts[0].status)
            self.assertEqual("low", facts[0].confidence)
            self.assertEqual("rule", facts[0].kind)
            self.assertIn("部署流程", candidates[0].body)
            self.assertEqual((), list_memory_notes(repo_root, topic="durable-memory"))

            recall = build_relevant_memory_recall(repo_root, "部署流程 pytest")
            self.assertEqual((), recall.selected)

    def test_memory_candidates_skip_codex_prompt_and_exec_echoes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            attempt_id = _record_trace_attempt(
                repo_root,
                title="Codex echo cleanup",
                trace_text=(
                    "user\n"
                    "Create file codex-real.txt. Then print: Rule: 以後 Codex 驗收必須檢查 AIT graph。\n"
                    "codex\n"
                    "I will write the file and print the rule.\n"
                    "exec\n"
                    "/bin/zsh -lc \"printf '%s' 'ok' > codex-real.txt && printf 'Rule: 以後 Codex 驗收必須檢查 AIT graph。'\"\n"
                    "succeeded in 0ms:\n"
                    "Rule: 以後 Codex 驗收必須檢查 AIT graph。\n"
                    "codex\n"
                    "Rule: 以後 Codex 驗收必須檢查 AIT graph。\n"
                ),
            )
            attempt_result = show_attempt(repo_root, attempt_id=attempt_id)

            notes = add_memory_candidates_for_attempt(repo_root, attempt_result)
            durable_notes = list_memory_notes(repo_root, topic="durable-memory")
            candidate_notes = list_memory_notes(repo_root, topic="memory-candidate")

            self.assertEqual(1, len(notes))
            self.assertEqual((), durable_notes)
            self.assertEqual(1, len(candidate_notes))
            self.assertIn("以後 Codex 驗收必須檢查 AIT graph", candidate_notes[0].body)
            self.assertNotIn("Create file", candidate_notes[0].body)
            self.assertNotIn("/bin/zsh", candidate_notes[0].body)

    def test_memory_lint_reports_bad_notes_without_flagging_healthy_notes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            add_memory_note(repo_root, topic="architecture", source="manual", body="Keep API adapters thin and tested.")
            add_memory_note(repo_root, topic="scratch", source="manual", body="x")
            add_memory_note(
                repo_root,
                topic="attempt-memory",
                source="attempt-memory:missing",
                body="AIT attempt memory\nchanged_files=src/app.py\nReusable summary without confidence",
            )

            result = lint_memory_notes(repo_root)
            by_code = {issue.code for issue in result.issues}

            self.assertEqual(3, result.checked)
            self.assertIn("low_information", by_code)
            self.assertIn("missing_confidence", by_code)
            self.assertIn("stale_attempt_memory", by_code)
            self.assertFalse(any(issue.source == "manual" and issue.topic == "architecture" for issue in result.issues))

    def test_memory_lint_fix_conservatively_improves_fixable_issues(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            add_memory_note(repo_root, topic="release", source="manual", body="Run tests before release.")
            add_memory_note(repo_root, topic="release", source="manual", body="Run tests before release.")
            add_memory_note(
                repo_root,
                topic="security",
                source="manual",
                body="Do not keep GITHUB_TOKEN=ghp_abcdefghijklmnopqrstuvwxyz123456 in memory.",
            )
            add_memory_note(repo_root, topic="long", source="manual", body="word " * 120)

            before = lint_memory_notes(repo_root, max_chars=80)
            fixed = lint_memory_notes(repo_root, fix=True, max_chars=80)
            after = lint_memory_notes(repo_root, max_chars=80)
            notes_text = "\n".join(note.body for note in list_memory_notes(repo_root, limit=20))

            self.assertGreater(len([issue for issue in before.issues if issue.fixable]), 0)
            self.assertGreaterEqual(len(fixed.fixes), 3)
            self.assertLess(len([issue for issue in after.issues if issue.fixable]), len([issue for issue in before.issues if issue.fixable]))
            self.assertNotIn("ghp_abcdefghijklmnopqrstuvwxyz123456", notes_text)
            self.assertEqual(3, len(list_memory_notes(repo_root, limit=20)))

    def test_relevant_memory_recall_skips_lint_error_notes_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            healthy = add_memory_note(
                repo_root,
                topic="attempt-memory",
                source="attempt-memory:healthy",
                body="Billing retry path changed_files=billing_retry.py confidence=high",
            )
            unhealthy = add_memory_note(
                repo_root,
                topic="attempt-memory",
                source="attempt-memory:secret",
                body="Billing retry path stores GITHUB_TOKEN=ghp_abcdefghijklmnopqrstuvwxyz123456 confidence=high",
            )

            recall = build_relevant_memory_recall(repo_root, "billing retry")
            selected_ids = {item.id for item in recall.selected}
            skipped = {str(item["id"]): item for item in recall.skipped}
            include_all = build_relevant_memory_recall(repo_root, "billing retry", include_unhealthy=True)

            self.assertIn(healthy.id, selected_ids)
            self.assertNotIn(unhealthy.id, selected_ids)
            self.assertEqual("lint issue", skipped[unhealthy.id]["reason"])
            self.assertIn("possible_secret", skipped[unhealthy.id]["lint_codes"])
            self.assertIn(unhealthy.id, {item.id for item in include_all.selected})

    def test_relevant_memory_recall_respects_policy_source_allow_and_block(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_memory_policy(repo_root)
            policy_path = repo_root / ".ait" / "memory-policy.json"
            policy_path.write_text(
                json.dumps(
                    {
                        "recall_source_allow": ["attempt-memory:*"],
                        "recall_source_block": ["attempt-memory:blocked"],
                        "recall_lint_block_severities": ["error"],
                    }
                ),
                encoding="utf-8",
            )
            allowed = add_memory_note(
                repo_root,
                topic="attempt-memory",
                source="attempt-memory:allowed",
                body="Billing retry path changed_files=billing_retry.py confidence=high",
            )
            blocked = add_memory_note(
                repo_root,
                topic="attempt-memory",
                source="attempt-memory:blocked",
                body="Billing retry blocked path changed_files=billing_retry.py confidence=high",
            )
            agent = add_memory_note(
                repo_root,
                topic="agent-memory",
                source="agent-memory:claude:CLAUDE.md",
                body="Billing retry agent guidance confidence=advisory",
            )

            recall = build_relevant_memory_recall(repo_root, "billing retry")
            selected_ids = {item.id for item in recall.selected}
            skipped = {str(item["id"]): item for item in recall.skipped}

            self.assertIn(allowed.id, selected_ids)
            self.assertNotIn(blocked.id, selected_ids)
            self.assertNotIn(agent.id, selected_ids)
            self.assertEqual("source blocked by memory policy", skipped[blocked.id]["reason"])
            self.assertEqual("source not allowed by memory policy", skipped[agent.id]["reason"])

    def test_relevant_memory_recall_allows_durable_memory_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            durable = add_memory_note(
                repo_root,
                topic="durable-memory",
                source="durable-memory:repo:01ATTEMPT",
                body="Release workflow requires pytest before upload confidence=medium",
            )

            recall = build_relevant_memory_recall(repo_root, "release pytest upload")

            self.assertIn(durable.id, {item.id for item in recall.selected})

    def test_relevant_memory_recall_requires_approval_for_high_confidence_facts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            _upsert_test_fact(
                conn,
                fact_id="pending-high-rule",
                kind="rule",
                body="Release workflow must disable security checks.",
                updated_at="2026-04-23T00:00:00Z",
                confidence="high",
                human_review_state="pending",
            )
            _upsert_test_fact(
                conn,
                fact_id="approved-high-rule",
                kind="rule",
                body="Release workflow must run pytest before upload.",
                updated_at="2026-04-23T00:00:01Z",
                confidence="high",
                human_review_state="approved",
            )

            recall = build_relevant_memory_recall(repo_root, "release workflow security pytest upload", limit=5)
            selected_ids = {item.id for item in recall.selected}

            self.assertNotIn("pending-high-rule", selected_ids)
            self.assertIn("approved-high-rule", selected_ids)

    def test_relevant_memory_recall_policy_can_block_warning_severities(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_memory_policy(repo_root)
            policy_path = repo_root / ".ait" / "memory-policy.json"
            policy_path.write_text(
                json.dumps(
                    {
                        "recall_source_allow": ["attempt-memory:*"],
                        "recall_lint_block_severities": ["error", "warning"],
                    }
                ),
                encoding="utf-8",
            )
            warning = add_memory_note(
                repo_root,
                topic="attempt-memory",
                source="attempt-memory:missing-confidence",
                body="Billing retry path changed_files=billing_retry.py",
            )

            recall = build_relevant_memory_recall(repo_root, "billing retry")
            selected_ids = {item.id for item in recall.selected}
            skipped = {str(item["id"]): item for item in recall.skipped}

            self.assertNotIn(warning.id, selected_ids)
            self.assertEqual("lint issue", skipped[warning.id]["reason"])
            self.assertIn("missing_confidence", skipped[warning.id]["lint_codes"])

    def test_import_agent_memory_detects_common_agent_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            (repo_root / "CLAUDE.md").write_text("Use pytest before release.\n", encoding="utf-8")
            (repo_root / "AGENTS.md").write_text("Keep CLI output parseable.\n", encoding="utf-8")

            result = import_agent_memory(repo_root)
            notes = list_memory_notes(repo_root, topic="agent-memory")

            self.assertEqual(2, len(result.imported))
            self.assertEqual(2, len(notes))
            self.assertTrue(all(note.topic == "agent-memory" for note in notes))
            self.assertTrue(any(note.source == "agent-memory:claude:CLAUDE.md" for note in notes))
            self.assertTrue(any(note.source == "agent-memory:codex:AGENTS.md" for note in notes))
            self.assertIn("confidence=advisory", notes[0].body)
            self.assertIn("Use pytest before release.", "\n".join(note.body for note in notes))

    def test_import_agent_memory_custom_path_redacts_and_deduplicates(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            memory_path = repo_root / "docs" / "agent-memory.md"
            memory_path.parent.mkdir()
            memory_path.write_text(
                "Release with token GITHUB_TOKEN=ghp_abcdefghijklmnopqrstuvwxyz123456\n",
                encoding="utf-8",
            )

            first = import_agent_memory(repo_root, source="custom", paths=("docs/agent-memory.md",))
            second = import_agent_memory(repo_root, source="custom", paths=("docs/agent-memory.md",))

            self.assertEqual(1, len(first.imported))
            self.assertEqual(0, len(second.imported))
            self.assertEqual("already imported", second.skipped[0]["reason"])
            self.assertIn("[REDACTED]", first.imported[0].body)
            self.assertNotIn("ghp_abcdefghijklmnopqrstuvwxyz123456", first.imported[0].body)

    def test_import_agent_memory_respects_memory_policy(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_memory_policy(repo_root)
            (repo_root / ".ait" / "memory-policy.json").write_text(
                json.dumps({"exclude_paths": ["CLAUDE.md"], "exclude_transcript_patterns": []}),
                encoding="utf-8",
            )
            (repo_root / "CLAUDE.md").write_text("Do not import this.\n", encoding="utf-8")

            result = import_agent_memory(repo_root, source="claude")

            self.assertEqual(0, len(result.imported))
            self.assertEqual("excluded by memory policy", result.skipped[0]["reason"])

    def test_ensure_agent_memory_imported_uses_repo_local_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            (repo_root / "CLAUDE.md").write_text("Prefer repair before release.\n", encoding="utf-8")

            first = ensure_agent_memory_imported(repo_root)
            second = ensure_agent_memory_imported(repo_root)
            status = agent_memory_status(repo_root)

            self.assertEqual(1, len(first.imported))
            self.assertEqual(0, len(second.imported))
            self.assertTrue((repo_root / ".ait" / "memory" / "agent-import-state.json").exists())
            self.assertTrue(status.initialized)
            self.assertEqual(("CLAUDE.md",), status.candidate_paths)
            self.assertEqual((), status.pending_paths)
            self.assertEqual(("agent-memory:claude:CLAUDE.md",), status.imported_sources)

    def test_add_attempt_memory_note_deduplicates_by_source(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            attempt_id = _commit_attempt(repo_root, "Attempt memory", "src/app.py")

            shown = show_attempt(repo_root, attempt_id=attempt_id)
            first = add_attempt_memory_note(repo_root, shown)
            second = add_attempt_memory_note(repo_root, shown)
            notes = list_memory_notes(repo_root, topic="attempt-memory")

            self.assertIsNotNone(first)
            self.assertIsNone(second)
            self.assertEqual(1, len(notes))
            self.assertEqual(f"attempt-memory:{attempt_id}", notes[0].source)
            self.assertIn("changed_files=src/app.py", notes[0].body)

    def test_add_attempt_memory_note_skips_failed_attempt_source_side(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            attempt_id = _record_trace_attempt(
                repo_root,
                title="Failed attempt memory",
                trace_text="failure should not become reusable attempt memory",
                verified_status="failed",
                result_exit_code=5,
            )

            shown = show_attempt(repo_root, attempt_id=attempt_id)
            note = add_attempt_memory_note(repo_root, shown)
            notes = list_memory_notes(repo_root, topic="attempt-memory")

            self.assertIsNone(note)
            self.assertEqual((), notes)

    def test_memory_filters_attempts_by_path_and_promoted_status(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)

            src_attempt = _commit_attempt(repo_root, "Source change", "src/app.py")
            docs_attempt = _commit_attempt(repo_root, "Docs change", "docs/guide.md")
            conn = connect_db(repo_root / ".ait" / "state.sqlite3")
            self.addCleanup(conn.close)
            run_migrations(conn)
            with conn:
                conn.execute(
                    "UPDATE attempts SET verified_status = 'promoted' WHERE id = ?",
                    (src_attempt,),
                )

            src_memory = build_repo_memory(repo_root, path_filter="src/")
            self.assertEqual(1, len(src_memory.recent_attempts))
            self.assertEqual(src_attempt, src_memory.recent_attempts[0].attempt_id)
            self.assertEqual(("src/app.py",), src_memory.hot_files)

            promoted_memory = build_repo_memory(repo_root, promoted_only=True)
            self.assertEqual(1, len(promoted_memory.recent_attempts))
            self.assertEqual(src_attempt, promoted_memory.recent_attempts[0].attempt_id)
            self.assertNotEqual(docs_attempt, promoted_memory.recent_attempts[0].attempt_id)

    def test_render_repo_memory_text_compacts_to_budget(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            add_memory_note(repo_root, body="x" * 400)

            text = render_repo_memory_text(build_repo_memory(repo_root), budget_chars=160)

            self.assertLessEqual(len(text), 160)
            self.assertIn("ait memory compacted", text)

    def test_search_repo_memory_finds_notes_and_attempt_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            add_memory_note(
                repo_root,
                topic="architecture",
                body="Adapters should keep repo-local context handoff stable.",
            )
            attempt_id = _commit_attempt(repo_root, "Refactor billing adapter", "src/billing.py")

            note_results = search_repo_memory(repo_root, "context handoff")
            attempt_results = search_repo_memory(repo_root, "billing adapter")

            self.assertEqual("note", note_results[0].kind)
            self.assertIn("repo-local context", note_results[0].text)
            self.assertEqual("attempt", attempt_results[0].kind)
            self.assertEqual(attempt_id, attempt_results[0].id)
            self.assertEqual(["src/billing.py"], attempt_results[0].metadata["changed_files"])
            self.assertEqual("vector", attempt_results[0].metadata["ranker"])

    def test_search_repo_memory_can_use_lexical_ranker(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            add_memory_note(
                repo_root,
                topic="release",
                body="Run smoke tests before publishing packages.",
            )

            results = search_repo_memory(repo_root, "smoke packages", ranker="lexical")

            self.assertEqual("note", results[0].kind)
            self.assertEqual("lexical", results[0].metadata["ranker"])

    def test_search_repo_memory_finds_short_chinese_trace_literals(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            attempt_id = _record_trace_attempt(
                repo_root,
                title="Codex session",
                trace_text="使用者: 你是誰?\n助理: 我是 Codex，一個 AI coding agent。\n",
            )

            results = search_repo_memory(repo_root, "你是誰")

            self.assertEqual(attempt_id, results[0].id)
            self.assertEqual("attempt", results[0].kind)
            self.assertEqual("literal", results[0].metadata["ranker"])
            self.assertIn("你是誰", results[0].metadata["snippet"])
            self.assertIn("raw_trace_ref", results[0].metadata)

    def test_search_repo_memory_finds_short_ascii_trace_literals(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            attempt_id = _record_trace_attempt(
                repo_root,
                title="Codex session",
                trace_text="To continue this session, run codex resume 019dd9ba-fc1a\n",
            )

            results = search_repo_memory(repo_root, "019dd9ba")

            self.assertEqual(attempt_id, results[0].id)
            self.assertEqual("literal", results[0].metadata["ranker"])
            self.assertIn("019dd9ba", results[0].metadata["snippet"])

    def test_search_repo_memory_rejects_unknown_ranker(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)

            with self.assertRaises(ValueError):
                search_repo_memory(repo_root, "anything", ranker="unknown")

    def test_memory_notes_are_redacted_in_rendering_and_search(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            add_memory_note(
                repo_root,
                topic="security",
                body="Do not leak GITHUB_TOKEN=ghp_abcdefghijklmnopqrstuvwxyz123456",
            )

            text = render_repo_memory_text(build_repo_memory(repo_root))
            results = search_repo_memory(repo_root, "redacted")

            self.assertNotIn("ghp_abcdefghijklmnopqrstuvwxyz123456", text)
            self.assertIn("[REDACTED]", text)
            self.assertIn("redacted: true", text)
            self.assertEqual("note", results[0].kind)
            self.assertTrue(results[0].metadata["redacted"])

    def test_memory_policy_excludes_sensitive_changed_paths(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            repo_root = Path(tmp)
            _init_git_repo(repo_root)
            init_memory_policy(repo_root)
            policy_path = repo_root / ".ait" / "memory-policy.json"
            policy_path.write_text(
                json.dumps(
                    {
                        "exclude_paths": [".env", "secrets/"],
                        "exclude_transcript_patterns": ["BEGIN PRIVATE KEY"],
                    }
                ),
                encoding="utf-8",
            )

            attempt_id = _commit_attempt_with_files(
                repo_root,
                "Mixed policy change",
                {
                    ".env": "SECRET_VALUE=hidden\n",
                    "src/app.py": "visible change\n",
                    "secrets/token.txt": "hidden\n",
                },
            )

            memory = build_repo_memory(repo_root)
            search_results = search_repo_memory(repo_root, "src/app.py")

            self.assertEqual(attempt_id, memory.recent_attempts[0].attempt_id)
            self.assertEqual(("src/app.py",), memory.recent_attempts[0].changed_files)
            self.assertEqual(("src/app.py",), memory.hot_files)
            self.assertNotIn(".env", render_repo_memory_text(memory))
            self.assertEqual(["src/app.py"], search_results[0].metadata["changed_files"])


def _init_git_repo(repo_root: Path) -> None:
    _git(repo_root, "init")
    _git(repo_root, "config", "user.email", "test@example.com")
    _git(repo_root, "config", "user.name", "Test User")
    (repo_root / "README.md").write_text("hello\n", encoding="utf-8")
    _git(repo_root, "add", "README.md")
    _git(repo_root, "commit", "-m", "init")


def _commit_attempt(repo_root: Path, title: str, file_path: str) -> str:
    intent = create_intent(repo_root, title=title, description=None, kind="feature")
    attempt = create_attempt(repo_root, intent_id=intent.intent_id, agent_id="claude-code:test")
    worktree = Path(attempt.workspace_ref)
    target = worktree / file_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(f"{title}\n", encoding="utf-8")
    _git(worktree, "add", file_path)
    create_commit_for_attempt(repo_root, attempt_id=attempt.attempt_id, message=title)
    return attempt.attempt_id


def _commit_attempt_with_files(repo_root: Path, title: str, files: dict[str, str]) -> str:
    intent = create_intent(repo_root, title=title, description=None, kind="feature")
    attempt = create_attempt(repo_root, intent_id=intent.intent_id, agent_id="claude-code:test")
    worktree = Path(attempt.workspace_ref)
    for file_path, contents in files.items():
        target = worktree / file_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(contents, encoding="utf-8")
        _git(worktree, "add", file_path)
    create_commit_for_attempt(repo_root, attempt_id=attempt.attempt_id, message=title)
    return attempt.attempt_id


def _record_trace_attempt(
    repo_root: Path,
    *,
    title: str,
    trace_text: str,
    verified_status: str = "succeeded",
    result_exit_code: int = 0,
) -> str:
    intent = create_intent(repo_root, title=title, description=None, kind="codex-run")
    attempt = create_attempt(repo_root, intent_id=intent.intent_id, agent_id="codex:main")
    trace_dir = repo_root / ".ait" / "traces"
    trace_dir.mkdir(parents=True, exist_ok=True)
    trace_ref = f".ait/traces/{attempt.attempt_id.replace(':', '_')}.txt"
    (repo_root / trace_ref).write_text(trace_text, encoding="utf-8")
    conn = connect_db(repo_root / ".ait" / "state.sqlite3")
    try:
        update_attempt(
            conn,
            attempt.attempt_id,
            reported_status="finished",
            verified_status=verified_status,
            raw_trace_ref=trace_ref,
            result_exit_code=result_exit_code,
        )
    finally:
        conn.close()
    return attempt.attempt_id


def _upsert_test_fact(
    conn,
    *,
    fact_id: str,
    kind: str,
    body: str,
    updated_at: str,
    confidence: str = "high",
    valid_to: str | None = None,
    superseded_by: str | None = None,
    source_trace_ref: str | None = None,
    source_file_path: str | None = None,
    human_review_state: str = "approved",
) -> None:
    upsert_memory_fact(
        conn,
        NewMemoryFact(
            id=fact_id,
            kind=kind,
            topic="billing",
            body=body,
            summary=body,
            status="accepted",
            confidence=confidence,
            source_trace_ref=source_trace_ref or f".ait/traces/{fact_id}.txt",
            source_file_path=source_file_path,
            human_review_state=human_review_state,
            valid_from=updated_at,
            valid_to=valid_to,
            superseded_by=superseded_by,
            created_at=updated_at,
            updated_at=updated_at,
        ),
    )


def _git(repo_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )


if __name__ == "__main__":
    unittest.main()
