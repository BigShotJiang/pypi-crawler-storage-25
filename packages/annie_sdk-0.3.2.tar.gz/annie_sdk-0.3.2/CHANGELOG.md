# Changelog

## 0.3.2 (2026-04-22)

### New features

- **SDK: `general_context` and `language` parameters**: `agent.run()` now accepts `general_context` (max 500 chars) and `language` parameters directly. Previously these were only available via direct HTTP API calls.
  ```python
  agent.run(
      "show revenue by region",
      general_context="Use CGM_ANALYSIS and CGM_INSIGHTS markers...",
      language="de",
  )
  ```
- **SDK: `column_display_names` in response**: `AgentResponse` now exposes the `column_display_names` dict returned by the API, mapping raw column names to human-readable labels.

### Bug fixes

- **IN (NULL, ...) invalid SQL**: Fixed `IN` and `NOT IN` clauses containing `NULL` values generating invalid SQL. `col IN (NULL, 'P')` now correctly generates `(col IN ('P') OR col IS NULL)`.
- **Expression parser: IN / NOT IN / IS NULL support**: The expression parser now recognizes `IN`, `NOT IN`, `IS NULL`, and `IS NOT NULL` keywords. Previously, LLM-generated expressions using these keywords caused intermittent `"Invalid character"` parse errors.
- **30 column limit with data_model**: Tables that define a `data_model` with an explicit `select` step are no longer rejected by the 30-column validation limit, since the columns have already been curated.

### Breaking changes

None. All changes are backward-compatible.

## 0.3.1 (2026-03-30)

### Bug fixes

- **Select constraint + summarize**: Fixed select constraints being appended after summarize steps, producing invalid SQL that referenced source columns (e.g. `amount`, `id`) on a subquery that only contained aggregation outputs (e.g. `sum`, `count`). Select constraints are now inserted before the first summarize step.
- **Duplicate filters with JOINs**: Fixed constraint filter enforcement creating duplicate filter steps when the LLM already included the same filter, causing `"Found multiple WHERE clauses"` errors on queries with JOINs.
- **Type-aware filter deduplication**: Fixed constraint value `"42"` (string) not matching LLM value `42` (int) during deduplication, causing redundant filters with mismatched types.

## 0.3.0 (2026-03-30)

### New features

- **General context**: Pass additional instructions to the AI via the `general_context` parameter (max 500 chars). Use it for domain-specific rules, formatting preferences, or any extra context the AI should consider.
- **Language support**: Control the response language via the `language` parameter (e.g. `"it"`, `"es"`, `"fr"`). Titles, labels, and explanations will be generated in the specified language.
- **Column display names**: The query response now includes a `column_display_names` field mapping raw column names to human-readable labels (e.g. `"sum"` -> `"Sum of revenue"`, `"count"` -> `"Count"`).
- **Column pre-filtering**: Schema columns are now automatically filtered to only those relevant to the query before being sent to the AI. This reduces noise for tables with many columns and improves response quality. Disable with `filter_columns=False`.

### Bug fixes

- **Donut chart rendering**: Fixed donut visualizations not rendering correctly due to a `"donut"` vs `"doughnut"` naming mismatch. The SDK's `VisualizationType.DONUT` now correctly maps to Chart.js `"doughnut"` type.
- **Horizontal bar and combo charts**: `horizontal_bar` and `combo` visualization types are now recognized and mapped correctly. Horizontal bar charts set `indexAxis: "y"` for proper Chart.js rendering.
- **PostgreSQL ROUND() transpilation**: Fixed `ROUND(expr, n)` failing on PostgreSQL with `"function round(double precision, integer) does not exist"`. Two-argument ROUND now casts the first argument to NUMERIC.
- **PostgreSQL LOG() transpilation**: Fixed `LOG(a, b)` failing on PostgreSQL with `"function log(integer, double precision) does not exist"`. Both arguments are now cast to NUMERIC.
- **Constraint enforcement**: Constraints defined via `ConnectorTable.data_model` (e.g. `tenant_id` filters, column restrictions) are now correctly applied to generated queries. Previously, constraints were serialized in the schema but never enforced, leading to unfiltered data being returned.

### Breaking changes

None. All new fields are optional and backward-compatible.

## 0.2.1

- Fix LLM prompts
- Fix `over()` expressions

## 0.2.0

- Initial public release
