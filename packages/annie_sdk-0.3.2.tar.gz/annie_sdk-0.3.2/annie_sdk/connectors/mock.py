"""
Mock Connector

A mock connector for testing and demos. Does not connect to any real
database — returns configurable mock results.
"""

from __future__ import annotations

from typing import Any

from .base import BaseConnector, ConnectorRelationship, ConnectorTable, ConnectorTableColumn


class MockConnector(BaseConnector):
    """Mock connector for testing.

    Returns predefined results for any SQL query executed. Useful for
    testing SDK integration without a real database.

    Args:
        dialect_name: SQL dialect to report (default: 'postgres')
        tables: Table configurations
        mock_results: Default results to return for any query
    """

    def __init__(
        self,
        dialect_name: str = "postgres",
        tables: list[ConnectorTable] | None = None,
        relationships: list[ConnectorRelationship] | None = None,
        mock_results: list[dict[str, Any]] | None = None,
    ):
        super().__init__(tables=tables, relationships=relationships)
        self._dialect_name = dialect_name
        self._mock_results = mock_results or []
        self._executed_queries: list[str] = []

    @property
    def dialect(self) -> str:
        return self._dialect_name

    @property
    def executed_queries(self) -> list[str]:
        """Get list of all executed SQL queries (for assertions in tests)."""
        return self._executed_queries

    @property
    def last_query(self) -> str | None:
        """Get the last executed SQL query."""
        return self._executed_queries[-1] if self._executed_queries else None

    def set_results(self, results: list[dict[str, Any]]) -> None:
        """Set the mock results to return for the next query."""
        self._mock_results = results

    def connect(self) -> None:
        """No-op connection."""
        self._connected = True

    def disconnect(self) -> None:
        """No-op disconnection."""
        self._connected = False

    def execute(self, sql: str) -> list[dict[str, Any]]:
        """Record the query and return mock results."""
        self._executed_queries.append(sql)
        return self._mock_results

    def discover_tables(self) -> list[str]:
        """Return configured table names."""
        return [table.name for table in self._tables]

    def discover_columns(self, table_name: str) -> list[ConnectorTableColumn]:
        """Return configured columns for the table."""
        table = self.get_table_config(table_name)
        if table and table.columns:
            return table.columns
        return []
