"""
Annie SDK

A Python SDK for querying databases using natural language.
The SDK connects to your database through connectors, sends your
query and schema context to the Annie API, and executes the
resulting SQL locally against your database.

Your data never leaves your infrastructure — only schema metadata
is sent to the API.

Quick start:
    ```python
    from annie_sdk import Agent, PostgresConnector, ConnectorTable, ConnectorTableColumn

    connector = PostgresConnector(
        connection_string="postgresql://user:pass@localhost:5432/mydb",
        tables=[
            ConnectorTable(
                name="orders",
                description="Customer orders",
                columns=[
                    ConnectorTableColumn(name="id", type="integer"),
                    ConnectorTableColumn(name="amount", type="decimal"),
                    ConnectorTableColumn(name="status", type="string"),
                ],
            ),
        ],
    )

    with Agent(connector=connector, api_key="your-api-key") as agent:
        response = agent.run("Show me top 10 orders by amount")
        print(response.sql)
        print(response.data)
    ```
"""

# Agent
from .agent import Agent

# Connectors
from .connectors.base import (
    BaseConnector,
    ConnectorRelationship,
    ConnectorTable,
    ConnectorTableColumn,
)
from .connectors.mock import MockConnector
from .connectors.mysql import MySQLConnector
from .connectors.postgres import PostgresConnector

# Exceptions
from .exceptions import (
    AnnieError,
    APIError,
    AuthenticationError,
    ConnectionError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)

# Models (DSL)
from .models import (
    AggregationFunction,
    AggregationSpec,
    BySpec,
    DataModel,
    DateBinning,
    DateBinningInterval,
    FilterCondition,
    FilterStep,
    LimitStep,
    NumberBinning,
    NumberBinningStrategy,
    Operator,
    OrderByColumn,
    OrderByStep,
    SelectStep,
    SortDirection,
    SummarizeStep,
    VisualizationType,
)

# Response
from .response import (
    AgentResponse,
    ChartContent,
    ChartFormat,
    DataContent,
    ErrorContent,
    ResponseType,
    TextContent,
)

__all__ = [
    # Agent
    "Agent",
    # Connectors
    "BaseConnector",
    "ConnectorRelationship",
    "ConnectorTable",
    "ConnectorTableColumn",
    "MockConnector",
    "MySQLConnector",
    "PostgresConnector",
    # Exceptions
    "AnnieError",
    "APIError",
    "AuthenticationError",
    "ConnectionError",
    "RateLimitError",
    "TimeoutError",
    "ValidationError",
    # Models
    "AggregationFunction",
    "AggregationSpec",
    "BySpec",
    "DataModel",
    "DateBinning",
    "DateBinningInterval",
    "FilterCondition",
    "FilterStep",
    "LimitStep",
    "NumberBinning",
    "NumberBinningStrategy",
    "Operator",
    "OrderByColumn",
    "OrderByStep",
    "SelectStep",
    "SortDirection",
    "SummarizeStep",
    "VisualizationType",
    # Response
    "AgentResponse",
    "ChartContent",
    "ChartFormat",
    "DataContent",
    "ErrorContent",
    "ResponseType",
    "TextContent",
]
