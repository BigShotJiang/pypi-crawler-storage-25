"""
Annie SDK Exceptions

Exception hierarchy for the Annie SDK, following the same pattern
as the pandas-ai-sdk.
"""

from __future__ import annotations


class AnnieError(Exception):
    """Base exception for all Annie SDK errors."""

    def __init__(self, message: str = "An error occurred"):
        self.message = message
        super().__init__(self.message)


class APIError(AnnieError):
    """Error communicating with the Annie API."""

    def __init__(
        self,
        message: str = "API request failed",
        status_code: int | None = None,
        code: str | None = None,
        response: dict | None = None,
    ):
        self.status_code = status_code
        self.code = code
        self.response = response
        super().__init__(message)


class ValidationError(AnnieError):
    """Invalid input or configuration."""

    def __init__(self, message: str = "Validation error", field: str | None = None):
        self.field = field
        super().__init__(message)


class ConnectionError(AnnieError):
    """Error connecting to a database."""

    def __init__(
        self,
        message: str = "Connection failed",
        original_error: Exception | None = None,
    ):
        self.original_error = original_error
        super().__init__(message)


class AuthenticationError(AnnieError):
    """Invalid or missing API key."""

    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message)


class TimeoutError(AnnieError):
    """Request timed out."""

    def __init__(self, message: str = "Request timed out"):
        super().__init__(message)


class RateLimitError(AnnieError):
    """Rate limit exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: int | None = None,
    ):
        self.retry_after = retry_after
        super().__init__(message)
