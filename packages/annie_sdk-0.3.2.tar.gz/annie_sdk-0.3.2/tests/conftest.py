"""Shared test fixtures for Annie SDK tests."""

from __future__ import annotations

import pytest

from annie_sdk import (
    ConnectorRelationship,
    ConnectorTable,
    ConnectorTableColumn,
    MockConnector,
)


@pytest.fixture
def sample_columns():
    """A set of columns covering common types."""
    return [
        ConnectorTableColumn(name="id", type="integer"),
        ConnectorTableColumn(name="name", type="string"),
        ConnectorTableColumn(name="amount", type="decimal"),
        ConnectorTableColumn(
            name="status", type="string", description="Order status"
        ),
        ConnectorTableColumn(name="created_at", type="timestamp"),
    ]


@pytest.fixture
def orders_table(sample_columns):
    """Orders table with explicit columns."""
    return ConnectorTable(
        name="orders",
        description="Customer orders",
        columns=sample_columns,
    )


@pytest.fixture
def products_table():
    """Products table with explicit columns."""
    return ConnectorTable(
        name="products",
        description="Product catalog",
        columns=[
            ConnectorTableColumn(name="id", type="integer"),
            ConnectorTableColumn(name="name", type="string"),
            ConnectorTableColumn(name="price", type="decimal"),
        ],
    )


@pytest.fixture
def sample_tables(orders_table, products_table):
    """Two tables: orders + products."""
    return [orders_table, products_table]


@pytest.fixture
def sample_relationship():
    """Relationship between orders and products."""
    return ConnectorRelationship(
        primary_table="orders",
        primary_column="product_id",
        foreign_table="products",
        foreign_column="id",
        description="Each order references a product",
    )


@pytest.fixture
def mock_connector(sample_tables, sample_relationship):
    """MockConnector with two tables, a relationship, and sample results."""
    return MockConnector(
        tables=sample_tables,
        relationships=[sample_relationship],
        mock_results=[
            {"name": "Alice", "amount": 100.0},
            {"name": "Bob", "amount": 200.0},
        ],
    )


@pytest.fixture
def single_table_connector(orders_table):
    """MockConnector with a single table and no results."""
    return MockConnector(
        tables=[orders_table],
        mock_results=[],
    )
