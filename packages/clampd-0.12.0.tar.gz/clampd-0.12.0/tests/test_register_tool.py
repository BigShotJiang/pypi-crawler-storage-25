"""Tests for clampd.register_tool — explicit tool classification at import."""

from __future__ import annotations

import logging
from unittest.mock import MagicMock, patch

import pytest

import clampd
from clampd import (
    Category,
    ClampdClassificationError,
    Operation,
    Subcategory,
)
from clampd.taxonomy import TAXONOMY, compute_scope, validate


# ── Taxonomy internal-consistency tests ────────────────────────────────


class TestTaxonomy:
    def test_all_categories_have_at_least_one_subcategory(self):
        for cat, subs in TAXONOMY.items():
            assert subs, f"Category {cat!r} has no subcategories"

    def test_all_subcategories_have_at_least_one_operation(self):
        for cat, subs in TAXONOMY.items():
            for sub, ops in subs.items():
                assert ops, f"Subcategory {cat}.{sub} has no operations"

    def test_every_category_enum_value_in_taxonomy(self):
        for member in Category:
            assert member.value in TAXONOMY, (
                f"Category.{member.name} missing from TAXONOMY"
            )

    def test_compute_scope_string(self):
        scope = compute_scope(Category.DB, Subcategory.QUERY, Operation.READ)
        assert scope == "db:query:read"

    def test_validate_accepts_known_triple(self):
        assert validate(Category.DB, Subcategory.QUERY, Operation.READ) is True

    def test_validate_rejects_bad_operation(self):
        # fs.file does not permit run
        assert validate("fs", "file", "run") is False

    def test_validate_rejects_bad_subcategory_for_category(self):
        # db has no slack subcategory
        assert validate("db", "slack", "read") is False

    def test_validate_rejects_unknown_category(self):
        assert validate("made_up", "query", "read") is False


# ── register_tool tests ────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch):
    """Give every test a known clean env."""
    monkeypatch.setenv("CLAMPD_ORG_ID", "org-test-123")
    monkeypatch.setenv("CLAMPD_DASHBOARD_URL", "http://dashboard-test:3001")
    monkeypatch.setenv("CLAMPD_API_KEY", "clmpd_test_key")
    # Avoid leaking _shared_config across tests
    clampd._reset()
    yield
    clampd._reset()


class TestRegisterToolValid:
    def test_valid_triple_posts_expected_body(self):
        with patch("httpx.post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_post.return_value = mock_resp

            clampd.register_tool(
                "db.run_query",
                category=Category.DB,
                subcategory=Subcategory.QUERY,
                operation=Operation.READ,
                description="Read-only SQL",
            )

        assert mock_post.called
        url = mock_post.call_args[0][0]
        assert url == (
            "http://dashboard-test:3001/v1/orgs/org-test-123/"
            "tool-descriptors/register"
        )

        body = mock_post.call_args[1]["json"]
        assert body == {
            "name": "db.run_query",
            "category": "db",
            "subcategory": "query",
            "operation": "read",
            "description": "Read-only SQL",
            "source": "sdk",
            "scope": "db:query:read",
        }

        headers = mock_post.call_args[1]["headers"]
        assert headers["Content-Type"] == "application/json"
        assert headers["X-AG-Key"] == "clmpd_test_key"

    def test_string_values_coerced_to_enums(self):
        with patch("httpx.post") as mock_post:
            mock_post.return_value = MagicMock(status_code=200)
            # Pass strings; register_tool should accept and coerce.
            clampd.register_tool(
                "slack.post_message",
                category="comms",           # type: ignore[arg-type]
                subcategory="slack",        # type: ignore[arg-type]
                operation="send",           # type: ignore[arg-type]
            )
        assert mock_post.call_args[1]["json"]["scope"] == "comms:slack:send"

    def test_logs_info_on_success(self, caplog):
        with patch("httpx.post") as mock_post:
            mock_post.return_value = MagicMock(status_code=201)
            with caplog.at_level(logging.INFO, logger="clampd"):
                clampd.register_tool(
                    "fs.write_file",
                    category=Category.FS,
                    subcategory=Subcategory.FILE,
                    operation=Operation.WRITE,
                )
        assert any(
            "fs.write_file" in r.getMessage() and "fs:file:write" in r.getMessage()
            for r in caplog.records
        )


class TestRegisterToolInvalid:
    def test_invalid_operation_for_subcategory_raises(self):
        # db.query allows "read" only, not "write"
        with pytest.raises(ClampdClassificationError) as excinfo:
            clampd.register_tool(
                "db.bad",
                category=Category.DB,
                subcategory=Subcategory.QUERY,
                operation=Operation.WRITE,
            )
        msg = str(excinfo.value)
        assert "db:query" in msg
        assert "read" in msg  # valid ops listed

    def test_invalid_subcategory_for_category_raises(self):
        # db has no "slack" subcategory
        with pytest.raises(ClampdClassificationError) as excinfo:
            clampd.register_tool(
                "db.bad",
                category=Category.DB,
                subcategory=Subcategory.SLACK,
                operation=Operation.READ,
            )
        msg = str(excinfo.value)
        assert "slack" in msg
        assert "db" in msg

    def test_unknown_category_string_raises(self):
        with pytest.raises(ClampdClassificationError):
            clampd.register_tool(
                "whatever",
                category="made_up_category",          # type: ignore[arg-type]
                subcategory=Subcategory.QUERY,
                operation=Operation.READ,
            )

    def test_unknown_operation_string_raises(self):
        with pytest.raises(ClampdClassificationError):
            clampd.register_tool(
                "whatever",
                category=Category.DB,
                subcategory=Subcategory.QUERY,
                operation="teleport",                 # type: ignore[arg-type]
            )

    def test_invalid_triple_does_not_hit_network(self):
        with patch("httpx.post") as mock_post:
            with pytest.raises(ClampdClassificationError):
                clampd.register_tool(
                    "db.bad",
                    category=Category.DB,
                    subcategory=Subcategory.QUERY,
                    operation=Operation.DESTRUCTIVE,
                )
        assert not mock_post.called


class TestRegisterToolNetworkTolerance:
    def test_backend_unreachable_logs_warning_does_not_raise(self, caplog):
        with patch("httpx.post", side_effect=OSError("connection refused")):
            with caplog.at_level(logging.WARNING, logger="clampd"):
                # Must not raise
                clampd.register_tool(
                    "db.query_safe",
                    category=Category.DB,
                    subcategory=Subcategory.QUERY,
                    operation=Operation.READ,
                )
        assert any(
            "backend unreachable" in r.getMessage() for r in caplog.records
        )

    def test_backend_returns_500_logs_warning_does_not_raise(self, caplog):
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.json.return_value = {"error": "db down"}
        mock_resp.text = '{"error":"db down"}'

        with patch("httpx.post", return_value=mock_resp):
            with caplog.at_level(logging.WARNING, logger="clampd"):
                clampd.register_tool(
                    "db.query_safe",
                    category=Category.DB,
                    subcategory=Subcategory.QUERY,
                    operation=Operation.READ,
                )
        assert any(
            "returned 500" in r.getMessage() for r in caplog.records
        )

    def test_missing_org_id_skips_post_with_warning(self, monkeypatch, caplog):
        monkeypatch.delenv("CLAMPD_ORG_ID", raising=False)
        with patch("httpx.post") as mock_post:
            with caplog.at_level(logging.WARNING, logger="clampd"):
                clampd.register_tool(
                    "db.no_org",
                    category=Category.DB,
                    subcategory=Subcategory.QUERY,
                    operation=Operation.READ,
                )
        assert not mock_post.called
        assert any(
            "CLAMPD_ORG_ID not set" in r.getMessage()
            for r in caplog.records
        )
