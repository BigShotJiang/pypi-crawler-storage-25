"""FitMyLLM TUI — Textual app."""

from textual.app import App
from textual.binding import Binding

from .styles import CSS
from .screens.menu import MenuScreen


class FitMyLLMApp(App):
    TITLE = "fitmyllm"
    SUB_TITLE = "Find the best local AI model"
    CSS = CSS
    BINDINGS = [Binding("q", "quit", "Quit", show=False)]

    def on_mount(self) -> None:
        self.push_screen(MenuScreen())
