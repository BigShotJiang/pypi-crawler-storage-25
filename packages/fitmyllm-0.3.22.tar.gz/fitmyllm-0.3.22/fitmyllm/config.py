"""Configuration storage — API key, preferences, saved items."""
import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".fitmyllm"
CONFIG_FILE = CONFIG_DIR / "config.json"

def _load() -> dict:
    """Load config from disk."""
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            pass
    return {}

def _save(data: dict) -> None:
    """Save config to disk."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, indent=2) + "\n")

def get_api_key() -> str | None:
    """Get API key from env var or config file."""
    key = os.environ.get("FITMYLLM_API_KEY")
    if key:
        return key
    return _load().get("api_key")

def save_api_key(key: str) -> None:
    """Save API key to config file."""
    data = _load()
    data["api_key"] = key
    _save(data)

def get_api_base() -> str:
    """Get API base URL."""
    return os.environ.get("FITMYLLM_API_URL", "https://www.fitmyllm.com/api/v1")

# ── User Preferences ──────────────────────────────────────────────────────

def get_preferences() -> dict:
    """Get saved user preferences (GPU, use case, filters)."""
    return _load().get("preferences", {})

def save_preferences(prefs: dict) -> None:
    """Save user preferences."""
    data = _load()
    data["preferences"] = prefs
    _save(data)

def get_preferred_gpu() -> str | None:
    """Get saved GPU name."""
    return get_preferences().get("gpu_name")

def save_preferred_gpu(gpu_name: str) -> None:
    """Save preferred GPU name."""
    prefs = get_preferences()
    prefs["gpu_name"] = gpu_name
    save_preferences(prefs)

# ── Backend Preferences ──────���────────────────────────────────────────────

def get_preferred_backend() -> str | None:
    """Get preferred inference backend name (e.g. 'ollama', 'llama-server')."""
    return get_preferences().get("backend")

def save_preferred_backend(name: str) -> None:
    """Save preferred inference backend."""
    prefs = get_preferences()
    prefs["backend"] = name
    save_preferences(prefs)

def get_models_dir() -> Path:
    """Get GGUF model storage directory."""
    custom = get_preferences().get("models_dir")
    if custom:
        return Path(custom)
    return CONFIG_DIR / "models"

# ── Saved Models ─────────────────────────────────────────��────────────────

def get_saved_models() -> list[str]:
    """Get list of saved model IDs."""
    return _load().get("saved_models", [])

def toggle_saved_model(model_id: str) -> bool:
    """Toggle a model in saved list. Returns True if added, False if removed."""
    data = _load()
    saved = data.get("saved_models", [])
    if model_id in saved:
        saved.remove(model_id)
        data["saved_models"] = saved
        _save(data)
        return False
    else:
        saved.append(model_id)
        data["saved_models"] = saved
        _save(data)
        return True
