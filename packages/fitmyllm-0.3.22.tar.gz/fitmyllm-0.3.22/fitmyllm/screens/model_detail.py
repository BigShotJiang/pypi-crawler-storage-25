"""Model detail screen — full model info, benchmarks, run commands."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, LoadingIndicator
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

from .. import api
from ..widgets import get_key, bar, vbar, FIT_COLORS


class ModelDetailScreen(Screen):
    DEFAULT_CSS = "ModelDetailScreen { layout: vertical; }"

    BINDINGS = [
        Binding("i", "install", "Install", show=True),
        Binding("c", "chat", "Chat", show=True),
        Binding("t", "tune", "Tune", show=True),
        Binding("s", "save_model", "Save", show=True),
        Binding("r", "show_readme", "README", show=True),
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self, model_id: str, rec: dict | None = None):
        super().__init__()
        self.model_id = model_id
        self.rec = rec
        self.full_model: dict | None = None
        self._readme_loaded = False

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield LoadingIndicator()
        yield VerticalScroll(Static("", id="model-detail-content"))
        yield Footer()

    def on_mount(self) -> None:
        self._load()

    @work(thread=True)
    def _load(self) -> None:
        key = get_key()
        if not key:
            return
        try:
            data = api.get_model(key, self.model_id)
            self.app.call_from_thread(self._show, data)
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _show(self, data: dict) -> None:
        self.full_model = data
        try:
            self.query_one(LoadingIndicator).remove()
        except NoMatches:
            pass

        r = self.rec
        name = data.get("name", "")
        provider = data.get("provider", "")
        params = data.get("params_b", 0)
        active = data.get("active_params_b")
        arch = data.get("architecture", "")
        ctx = data.get("context_length", 0)
        caps = ", ".join(data.get("capabilities", []))
        desc = data.get("description", "")
        hf = data.get("hf_id", "")
        release = data.get("release_date", "")
        ollama_base = data.get("ollama_base", "")

        # Header
        lines = f"  [bold]{name}[/]  [dim]by {provider}[/]\n"
        if desc:
            lines += f"  [dim]{desc}[/]\n"
        lines += "\n"

        # Model Info
        lines += "  ─── [bold cyan]Model Info[/] ───\n"
        params_str = f"{params}B"
        if active:
            params_str += f" ({active}B active)"
        lines += f"  [dim]Parameters[/]     {params_str} {arch}\n"
        lines += f"  [dim]Context[/]        {ctx // 1024}K tokens\n"
        lines += f"  [dim]Capabilities[/]   {caps}\n"
        lines += f"  [dim]Released[/]       {release}\n"
        if hf:
            lines += f"  [dim]HuggingFace[/]   {hf}\n"
        lines += "\n"

        # Performance (from recommendation if available)
        if r:
            score = r.get("score", 0)
            speed = r.get("speed_toks")
            vram_pct = r.get("vram_percent", 0)
            fit = r.get("fit", "")
            ql = r.get("quant", {}).get("level", "")
            vram_gb = r.get("quant", {}).get("vram_mb", 0) / 1024
            fs = FIT_COLORS.get(fit, "")

            mode_labels = {
                "gpu_full": "[green]Full GPU[/]",
                "gpu_offload": "[yellow]GPU+RAM Offload[/]",
                "cpu_only": "[red]CPU Only[/]",
            }
            mode = mode_labels.get(r.get("inference_mode", ""), r.get("inference_mode", ""))

            lines += "  ─── [bold cyan]Performance[/] ───\n"
            lines += f"  [dim]Selected Quant[/] {ql} ({int(r.get('quant', {}).get('quality', 0) * 100)}% quality)\n"
            lines += f"  [dim]Inference Mode[/] {mode}\n"
            lines += f"  [dim]Score[/]          {bar(score, 20)} [bold]{score}[/]/100\n"
            if speed:
                lines += f"  [dim]Decode Speed[/]   {bar(min(100, speed * 1.2), 20)} [bold]~{speed} tok/s[/]\n"
            prefill = r.get("prefill_tps")
            if prefill:
                lines += f"  [dim]Prefill Speed[/]  [bold]~{prefill} tok/s[/]\n"
            ttft = r.get("ttft_ms")
            if ttft:
                ttft_color = "green" if ttft < 200 else "yellow" if ttft < 500 else "red"
                lines += f"  [dim]TTFT[/]           [{ttft_color}][bold]{ttft}ms[/][/]\n"
            load_time = r.get("load_time_s")
            if load_time:
                lines += f"  [dim]Load Time[/]      ~{load_time}s\n"

            # Memory breakdown
            model_vram = r.get("model_vram_gb")
            kv_cache = r.get("kv_cache_gb")
            total_vram = r.get("vram_gb")
            ram_offload = r.get("ram_offload_gb")
            gpu_layers = r.get("gpu_layers")

            lines += f"  [dim]VRAM[/]           {vbar(vram_pct, 20)} [bold]{vram_pct}%[/] [{fs}]● {fit}[/]\n"
            if model_vram is not None and kv_cache is not None:
                lines += f"  [dim]  Model weights[/] {model_vram:.1f}GB\n"
                lines += f"  [dim]  KV cache[/]      {kv_cache:.1f}GB\n"
                if total_vram is not None:
                    lines += f"  [dim]  Total VRAM[/]    {total_vram:.1f}GB\n"
            if ram_offload:
                lines += f"  [dim]  RAM offload[/]   {ram_offload:.1f}GB\n"
            if gpu_layers and gpu_layers != "all":
                lines += f"  [dim]  GPU layers[/]    {gpu_layers}\n"

            # Fine-tuning estimates (computed client-side)
            lines += "\n  ─── [bold cyan]Fine-tuning Estimates[/] ───\n"
            fp16_vram = params * 2  # FP16 in GB
            qlora_vram = params * 0.5 * 1.1 + 2  # Q4 model + adapters + optimizer
            lora_vram = fp16_vram * 1.2 + 2  # FP16 + LoRA adapters + optimizer
            full_vram = fp16_vram * 4  # model + gradients + optimizer states
            lines += f"  [dim]QLoRA[/]    ~{qlora_vram:.0f}GB VRAM  [green]{'feasible' if qlora_vram < 24 else 'needs multi-GPU'}[/]\n"
            lines += f"  [dim]LoRA[/]     ~{lora_vram:.0f}GB VRAM  [{'green' if lora_vram < 48 else 'yellow'}]{'feasible' if lora_vram < 80 else 'needs multi-GPU'}[/]\n"
            lines += f"  [dim]Full FT[/]  ~{full_vram:.0f}GB VRAM  [{'green' if full_vram < 48 else 'yellow' if full_vram < 160 else 'red'}]{'feasible' if full_vram < 80 else 'needs cluster'}[/]\n"

            # Warnings
            warnings = r.get("warnings", [])
            if warnings:
                lines += "\n"
                for w in warnings:
                    lines += f"  [yellow]⚠ {w}[/]\n"
            lines += "\n"

        # Benchmarks
        benchmarks = data.get("benchmarks", {})
        if benchmarks:
            lines += "  ─── [bold cyan]Benchmarks[/] ───\n"
            for bkey, bval in sorted(benchmarks.items()):
                if bval is not None:
                    is_elo = bkey == "arena_elo"
                    bar_val = min(100, (bval - 800) / 6) if is_elo else bval
                    lines += f"  [dim]{bkey:20s}[/] {bar(bar_val, 15)} [bold]{bval}[/]\n"
            lines += "\n"

        # All Quantizations
        quants = data.get("quantizations", [])
        if quants:
            lines += "  ─── [bold cyan]Quantizations[/] ───\n"
            lines += f"  [dim]{'Level':10s} {'BPW':>5s} {'Size':>8s} {'VRAM':>8s} {'Quality':>8s}  Ollama tag[/]\n"
            for q in quants:
                file_gb = params * q["bpw"] / 8
                vram_gb = q["vram_mb"] / 1024
                qual = int(q["quality"] * 100)
                tag = q.get("ollama_tag", "—")
                lines += f"  {q['level']:10s} {q['bpw']:5.1f} {file_gb:7.1f}GB {vram_gb:7.1f}GB {qual:7d}%  [cyan]{tag}[/]\n"
            lines += "\n"

        # Run Commands (7 engines)
        lines += "  ─── [bold cyan]Run Commands[/] ───\n"
        if ollama_base:
            lines += f"  [dim]Ollama[/]         [cyan]ollama run {ollama_base}[/]\n"
        if hf:
            lines += f"  [dim]vLLM[/]           [cyan]vllm serve {hf}[/]\n"
            lines += f"  [dim]LM Studio[/]      [cyan]lms load {hf}[/]\n"
            lines += f"  [dim]Jan[/]            [cyan]jan run {hf}[/]\n"
        gguf = data.get("gguf_sources", [])
        if gguf:
            repo = gguf[0]['repo']
            lines += f"  [dim]llama.cpp[/]      [cyan]llama-cli -m <gguf> -ngl 99 -c 4096 -cnv[/]\n"
            lines += f"  [dim]KoboldCpp[/]      [cyan]koboldcpp <gguf> --gpulayers 99[/]\n"
        if ollama_base:
            lines += f"  [dim]Docker[/]         [cyan]docker model run {ollama_base}[/]\n"
        lines += "\n"

        # GGUF Sources
        if gguf:
            lines += "  ─── [bold cyan]GGUF Downloads[/] ───\n"
            for g in gguf:
                lines += f"  [dim]{g.get('provider', ''):12s}[/] [cyan]huggingface.co/{g['repo']}[/]\n"
            lines += "\n"

        lines += "  [dim]Press [bold]i[/bold] install · [bold]c[/bold] chat · [bold]t[/bold] tune · [bold]s[/bold] save · [bold]r[/bold] readme[/]"

        self.query_one("#model-detail-content", Static).update(lines)

    def action_install(self) -> None:
        if not self.full_model:
            return
        from .install import InstallScreen
        self.app.push_screen(InstallScreen(self.full_model, self.rec))

    def action_chat(self) -> None:
        """Open chat — auto-detects backend (Ollama, llama-server, etc.)."""
        if not self.full_model:
            return

        # Try to find a model tag
        tag = self.full_model.get("ollama_base", "")
        if self.rec:
            tag = self.rec.get("quant", {}).get("ollama_tag", "") or tag

        # Check if any backend has this model
        from ..backends import detect_backends, get_backend

        for backend in detect_backends():
            models = backend.list_models()
            for m in models:
                if tag and tag.lower() in m.get("name", "").lower():
                    from .chat import ChatScreen
                    self.app.push_screen(ChatScreen(m["name"], backend=backend))
                    return

        # Check local GGUF inventory
        from ..models.store import get_inventory, get_model_path
        from ..backends import get_managed_port
        model_name = self.full_model.get("name", "").lower()
        for entry in get_inventory():
            if model_name in entry.get("name", "").lower():
                port = get_managed_port()
                if port:
                    from ..backends.openai_compat import OpenAICompatBackend
                    from .chat import ChatScreen
                    backend = OpenAICompatBackend(base_url=f"http://localhost:{port}", name="llama-server")
                    self.app.push_screen(ChatScreen(entry["filename"].replace(".gguf", ""), backend=backend))
                    return

        # Fallback: try with tag on auto-detected backend
        if tag:
            from .chat import ChatScreen
            self.app.push_screen(ChatScreen(tag))
        else:
            self.notify("No model tag available — install first with 'i'", severity="warning")

    def action_tune(self) -> None:
        """Open command simulator for parameter tuning."""
        if not self.full_model:
            return
        from .command_sim import CommandSimScreen
        self.app.push_screen(CommandSimScreen(self.full_model, self.rec))

    def action_save_model(self) -> None:
        """Toggle model in saved list."""
        from ..config import toggle_saved_model
        added = toggle_saved_model(self.model_id)
        if added:
            self.notify(f"Saved {self.model_id}", timeout=3)
        else:
            self.notify(f"Removed {self.model_id}", timeout=3)

    def action_show_readme(self) -> None:
        """Load and display HuggingFace README."""
        if self._readme_loaded:
            return
        if not self.full_model or not self.full_model.get("hf_id"):
            self.notify("No HuggingFace ID for this model", severity="warning")
            return
        self._readme_loaded = True
        self.notify("Loading README...", timeout=2)
        self._fetch_readme()

    @work(thread=True)
    def _fetch_readme(self) -> None:
        key = get_key()
        if not key or not self.full_model:
            return
        hf_id = self.full_model.get("hf_id", "")
        if not hf_id:
            return
        try:
            readme = api.fetch_hf_readme(key, hf_id)
            if readme:
                self.app.call_from_thread(self._append_readme, readme)
            else:
                self.app.call_from_thread(self.notify, "README not available", severity="warning")
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _append_readme(self, readme: str) -> None:
        """Append README content to the detail view."""
        content = self.query_one("#model-detail-content", Static)
        # Clean up markdown for terminal: strip images, limit length
        lines = []
        for line in readme.split("\n"):
            # Skip image lines
            if line.strip().startswith("![") or line.strip().startswith("<img"):
                continue
            # Convert headers to Rich markup
            if line.startswith("### "):
                lines.append(f"  [bold]{line[4:]}[/]")
            elif line.startswith("## "):
                lines.append(f"\n  [bold cyan]{line[3:]}[/]")
            elif line.startswith("# "):
                lines.append(f"\n  [bold cyan]{line[2:]}[/]")
            else:
                lines.append(f"  {line}")
        readme_text = "\n".join(lines[:100])  # limit to 100 lines
        current = content.renderable
        content.update(
            f"{current}\n\n"
            f"  ─── [bold cyan]HuggingFace README[/] ───\n"
            f"{readme_text}\n"
        )
