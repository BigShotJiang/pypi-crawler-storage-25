"""Run Benchmark — comprehensive speed test with upload to FitMyLLM."""

from __future__ import annotations

import time

from rich.markup import escape

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable, Input
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

import httpx

from ..backends import get_backend, detect_backends
from ..detect import detect_gpu
from ..widgets import get_key
from .. import config

PROMPTS = {
    "decode": (
        "Write a Python function to sort a list using quicksort. "
        "Include docstring, type hints, and example usage."
    ),
    "prefill": (
        "Below is a long passage about the history of computing. Read it carefully and then "
        "answer the question at the end.\n\n"
        "The history of computing is longer than the history of computing hardware and modern "
        "computing technology and includes the history of methods intended for pen and paper or "
        "for chalk and slate, with or without the aid of tables. Computing is intimately tied to "
        "the representation of numbers. But long before abstractions like the number arose, there "
        "were mathematical concepts to serve the purposes of civilization. These concepts are "
        "implicit in concrete practices such as counting, measuring, and trading. The earliest "
        "known tool for use in computation was the abacus, developed in the period between 2700 "
        "and 2300 BCE in Sumer. The Sumerians' abacus consisted of a table of successive columns "
        "which delimited the successive orders of magnitude of their sexagesimal number system. "
        "Its original style of usage was by lines drawn in sand with pebbles. More recently, a "
        "Hindu-Arabic numeral system spread from the Indian subcontinent to the Middle East, "
        "Europe, and eventually the world. The Hindu-Arabic numeral system reached Europe through "
        "the works of Middle Eastern mathematicians, especially al-Khwarizmi and al-Kindi, by the "
        "12th century. The system was adopted in the West by the end of the 16th century. "
        "Blaise Pascal designed the first mechanical calculator in 1642. Charles Babbage designed "
        "the Analytical Engine in 1837, which is considered the first general-purpose computer. "
        "Ada Lovelace wrote the first algorithm intended for a machine, making her the first "
        "computer programmer. Alan Turing formalized the concept of computation with the Turing "
        "machine in 1936. The ENIAC, built in 1945, was the first general-purpose electronic "
        "computer. The invention of the transistor in 1947 led to smaller and faster computers. "
        "The integrated circuit, invented in 1958, further miniaturized computing. The "
        "microprocessor, developed in 1971, put an entire CPU on a single chip. Personal "
        "computers became widespread in the 1980s. The World Wide Web was invented in 1989. "
        "Modern computing includes cloud computing, artificial intelligence, and quantum "
        "computing.\n\n"
        "Question: Who designed the Analytical Engine and in what year?"
    ),
}


class BenchSubmitScreen(Screen):
    """Comprehensive benchmark: decode speed, prefill, TTFT, with upload."""

    DEFAULT_CSS = "BenchSubmitScreen { layout: vertical; }"

    BINDINGS = [
        Binding("m", "manual_input", "Manual", show=True),
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._models: list[dict] = []
        self._loaded = False

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(
            "\n  [bold]Run Benchmark[/]  [dim]Loading models...[/]\n",
            id="bench-header",
        )
        yield DataTable(id="bench-table", cursor_type="row")
        yield Input(
            placeholder="Or type a model tag manually and press Enter...",
            id="bench-manual",
        )
        yield VerticalScroll(Static("", id="bench-results"))
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#bench-table", DataTable)
        table.add_columns("", "Model", "Source")
        self.query_one("#bench-manual", Input).display = False
        self._load_models()

    def action_manual_input(self) -> None:
        inp = self.query_one("#bench-manual", Input)
        inp.display = not inp.display
        if inp.display:
            inp.focus()

    @work(thread=True)
    def _load_models(self) -> None:
        models: list[dict] = []
        seen: set[str] = set()

        # 1. Models from running backends
        backends = detect_backends()
        for backend in backends:
            try:
                for m in backend.list_models():
                    name = m.get("name", "")
                    if name and name not in seen:
                        seen.add(name)
                        models.append({
                            "name": name,
                            "source": f"installed ({backend.name})",
                            "backend_name": backend.name,
                            "tag": name,
                            "status": "[green]\u2713 ready[/]",
                        })
            except Exception:
                pass

        # 2. Local GGUF models (can be started with llama-server)
        from ..models.store import get_inventory, get_model_path
        for entry in get_inventory():
            filename = entry.get("filename", "")
            name = entry.get("name", filename)
            quant = entry.get("quant_level", "")
            display = f"{name} ({quant})" if quant else name
            if display not in seen:
                path = get_model_path(filename)
                if path:
                    seen.add(display)
                    models.append({
                        "name": display,
                        "source": "local GGUF",
                        "backend_name": None,  # needs llama-server
                        "tag": filename.replace(".gguf", ""),
                        "gguf_path": str(path),
                        "status": "[cyan]\u25cf local[/]",
                        "quant_level": quant,
                        "model_id": entry.get("id", ""),
                    })

        self._models = models
        self._loaded = True
        self.app.call_from_thread(self._populate_table)

    def _populate_table(self) -> None:
        header = self.query_one("#bench-header", Static)
        table = self.query_one("#bench-table", DataTable)
        table.clear()

        if not self._models:
            header.update(
                "\n  [bold]Run Benchmark[/]  "
                "[yellow]No models found — start an inference backend, "
                "or press [bold]m[/bold] for manual input[/]\n"
            )
            return

        header.update(
            f"\n  [bold]Run Benchmark[/]  "
            f"[dim]{len(self._models)} models · Select and press Enter · "
            f"[bold]m[/bold] for manual input[/]\n"
        )

        for m in self._models:
            table.add_row(m["status"], m["name"], f"[dim]{m['source']}[/]")
        table.focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if not self._models or event.cursor_row >= len(self._models):
            return
        model = self._models[event.cursor_row]
        self._run_full_benchmark(model)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "bench-manual" and event.value.strip():
            tag = event.value.strip()
            self._run_full_benchmark({
                "tag": tag, "name": tag, "backend_name": None,
                "model_id": "", "quant_level": "", "predicted_speed": None,
            })

    @work(thread=True)
    def _run_full_benchmark(self, model: dict) -> None:
        """Run comprehensive benchmark: decode, prefill, TTFT."""
        results_widget = self.query_one("#bench-results", Static)
        tag = model["tag"]
        display = model["name"]

        def update(text: str) -> None:
            self.app.call_from_thread(results_widget.update, text)

        # Get or start backend
        backend_name = model.get("backend_name")
        gguf_path = model.get("gguf_path")

        if gguf_path and not backend_name:
            # Local GGUF — need to start llama-server
            from ..backends import start_server, calculate_params, get_managed_port
            from ..backends.openai_compat import OpenAICompatBackend

            port = get_managed_port()
            if port:
                backend = OpenAICompatBackend(base_url=f"http://localhost:{port}", name="llama-server")
            else:
                update("  [cyan]Starting llama-server for benchmark...[/]\n")
                gpu_info = detect_gpu()
                vram = gpu_info.get("vram_mb") if gpu_info else None
                from pathlib import Path
                size_gb = Path(gguf_path).stat().st_size / (1024**3)
                params = calculate_params(vram_mb=vram, model_size_gb=size_gb)
                try:
                    port = start_server(gguf_path, params)
                    backend = OpenAICompatBackend(base_url=f"http://localhost:{port}", name="llama-server")
                except Exception as e:
                    update(f"  [red]Failed to start llama-server: {escape(str(e))}[/]")
                    return
        else:
            backend = get_backend(backend_name)

        if not backend:
            update("  [red]No inference backend available. Install a model or start a server.[/]")
            return

        # Detect GPU
        gpu = detect_gpu()
        gpu_name = gpu["name"] if gpu else "Unknown"
        vram_mb = gpu.get("vram_mb") if gpu else None

        update(
            f"\n  ─── [bold cyan]Benchmarking {escape(display)}[/] ───\n"
            f"  [dim]Backend: {backend.name} · GPU: {gpu_name}[/]\n\n"
            f"  [dim]Running 3 tests...[/]\n"
        )

        results: dict = {
            "model_tag": tag,
            "model_id": model.get("model_id", ""),
            "quant_level": model.get("quant_level", ""),
            "gpu_name": gpu_name,
            "gpu_vram_mb": vram_mb,
            "backend": backend.name,
        }

        # ─── Test 1: Decode Speed (short prompt → long output) ───
        update(
            f"\n  ─── [bold cyan]Benchmarking {escape(display)}[/] ───\n"
            f"  [dim]Backend: {backend.name} · GPU: {gpu_name}[/]\n\n"
            f"  [cyan]1/3[/] Decode speed (generating ~200 tokens)...\n"
        )

        decode_tps, decode_tokens, decode_time, ttft_ms = self._run_single_test(
            backend, tag, PROMPTS["decode"]
        )

        if decode_tokens == 0:
            update(
                f"\n  [red]Model did not respond.[/]\n"
                f"  [dim]The model '{escape(tag)}' may not be loaded in {backend.name}.[/]\n"
                f"  [dim]Make sure the model is running before benchmarking.[/]"
            )
            return

        results["decode_tps"] = decode_tps
        results["decode_tokens"] = decode_tokens
        results["decode_time"] = decode_time
        results["ttft_ms"] = ttft_ms

        # ─── Test 2: Prefill Speed (long prompt → short output) ───
        update(
            f"\n  ─── [bold cyan]Benchmarking {escape(display)}[/] ───\n"
            f"  [dim]Backend: {backend.name} · GPU: {gpu_name}[/]\n\n"
            f"  [green]\u2713[/] Decode: [bold]{decode_tps:.1f} tok/s[/] ({decode_tokens} tokens in {decode_time:.1f}s)\n"
            f"  [green]\u2713[/] TTFT: [bold]{ttft_ms:.0f}ms[/]\n\n"
            f"  [cyan]2/3[/] Prefill speed (processing ~500 token prompt)...\n"
        )

        prefill_tps, prefill_tokens, prefill_time, prefill_ttft = self._run_single_test(
            backend, tag, PROMPTS["prefill"]
        )
        results["prefill_tps"] = prefill_tps
        results["prefill_ttft_ms"] = prefill_ttft

        # ─── Test 3: Consistency (run decode again for variance) ───
        update(
            f"\n  ─── [bold cyan]Benchmarking {escape(display)}[/] ───\n"
            f"  [dim]Backend: {backend.name} · GPU: {gpu_name}[/]\n\n"
            f"  [green]\u2713[/] Decode: [bold]{decode_tps:.1f} tok/s[/]\n"
            f"  [green]\u2713[/] TTFT: [bold]{ttft_ms:.0f}ms[/]\n"
            f"  [green]\u2713[/] Prefill TTFT: [bold]{prefill_ttft:.0f}ms[/] (long prompt)\n\n"
            f"  [cyan]3/3[/] Consistency check (second decode run)...\n"
        )

        decode2_tps, _, _, ttft2_ms = self._run_single_test(
            backend, tag, "Explain the concept of recursion with a simple example in Python."
        )
        results["decode2_tps"] = decode2_tps
        results["ttft2_ms"] = ttft2_ms

        # ─── Calculate final results ───
        avg_decode = (decode_tps + decode2_tps) / 2
        variance = abs(decode_tps - decode2_tps) / avg_decode * 100 if avg_decode > 0 else 0
        avg_ttft = (ttft_ms + ttft2_ms) / 2

        results["avg_decode_tps"] = avg_decode
        results["variance_pct"] = variance
        results["avg_ttft_ms"] = avg_ttft

        # ─── Show results ───
        predicted = model.get("predicted_speed")
        delta_str = ""
        if predicted:
            delta = avg_decode - predicted
            delta_pct = (delta / predicted * 100) if predicted > 0 else 0
            color = "green" if delta >= 0 else "red"
            delta_str = (
                f"  [dim]Predicted[/]       {predicted:.1f} tok/s\n"
                f"  [dim]Delta[/]           [{color}]{delta:+.1f} tok/s ({delta_pct:+.0f}%)[/]\n"
            )

        output = (
            f"\n  ─── [bold cyan]Benchmark Results[/] ───\n\n"
            f"  [dim]Model[/]           [bold]{escape(display)}[/]\n"
            f"  [dim]Backend[/]         {backend.name} ({backend.base_url})\n"
            f"  [dim]GPU[/]             {gpu_name}"
            f"{f' ({vram_mb // 1024}GB)' if vram_mb else ''}\n\n"
            f"  ─── [bold]Speed[/] ───\n"
            f"  [dim]Decode[/]          [bold green]{avg_decode:.1f} tok/s[/]"
            f"  [dim](run 1: {decode_tps:.1f}, run 2: {decode2_tps:.1f}, variance: {variance:.0f}%)[/]\n"
            f"  [dim]Prefill TTFT[/]    [bold]{prefill_ttft:.0f}ms[/]"
            f"  [dim](~500 token prompt)[/]\n"
            f"  [dim]TTFT (avg)[/]      [bold]{avg_ttft:.0f}ms[/]\n"
            f"{delta_str}"
            f"\n  ─── [bold]Details[/] ───\n"
            f"  [dim]Decode tokens[/]   {decode_tokens}\n"
            f"  [dim]Decode time[/]     {decode_time:.1f}s\n"
            f"  [dim]Runtime[/]         {backend.name}\n"
            f"  [dim]Quant[/]           {model.get('quant_level', 'unknown')}\n"
        )

        # ─── Upload to FitMyLLM ───
        upload_status = self._upload_benchmark(results)
        output += f"\n  ─── [bold]Upload[/] ───\n  {upload_status}\n"

        update(output)

    def _run_single_test(
        self, backend: object, tag: str, prompt: str,
    ) -> tuple[float, int, float, float]:
        """Run a single benchmark test. Returns (tok/s, token_count, elapsed, ttft_ms)."""
        messages = [{"role": "user", "content": prompt}]
        token_count = 0
        ttft_ms = 0.0
        start = time.time()
        first_token_time = None

        try:
            for chunk in backend.stream_chat(tag, messages, timeout=120.0):
                if chunk.content:
                    if first_token_time is None:
                        first_token_time = time.time()
                        ttft_ms = (first_token_time - start) * 1000
                    token_count += 1
                if chunk.done:
                    break
        except Exception:
            pass

        elapsed = time.time() - start
        tps = token_count / elapsed if elapsed > 0 else 0
        return tps, token_count, elapsed, ttft_ms

    def _upload_benchmark(self, results: dict) -> str:
        """Upload benchmark results to FitMyLLM API."""
        key = get_key()
        if not key:
            return "[yellow]Not uploaded — no API key (run fitmyllm setup)[/]"

        avg_tps = results.get("avg_decode_tps", 0)
        if avg_tps <= 0:
            return "[yellow]Not uploaded — no valid speed data[/]"

        # Resolve model_id: try stored id, then tag, then extract from filename
        model_id = results.get("model_id", "") or results.get("model_tag", "")
        # Clean up filename-style tags: "Qwen3.5-4B-Q8_0" → "qwen3.5-4b"
        if model_id and not any(c == "/" for c in model_id):
            # Remove quant suffix from filename-based tags
            for suffix in ["-Q8_0", "-Q4_K_M", "-Q5_K_M", "-Q6_K", "-Q3_K_M", "-FP16",
                           "-q8_0", "-q4_k_m", "-q5_k_m", "-q6_k", "-q3_k_m", "-fp16"]:
                if model_id.endswith(suffix):
                    model_id = model_id[:-len(suffix)]
                    break

        gpu_name = results.get("gpu_name", "Unknown")
        quant = results.get("quant_level", "unknown")

        payload = {
            "model_id": model_id,
            "quant_level": quant,
            "gpu_name": gpu_name,
            "gpu_vram_mb": results.get("gpu_vram_mb"),
            "tokens_per_second": round(avg_tps, 2),
            "prefill_tokens_per_second": round(results["prefill_tps"], 2) if results.get("prefill_tps") else None,
            "time_to_first_token_ms": round(results["avg_ttft_ms"]) if results.get("avg_ttft_ms") else None,
            "context_length": 4096,
            "runtime": results.get("backend", "llama.cpp"),
            "notes": f"CLI benchmark | {gpu_name} | variance {results.get('variance_pct', 0):.0f}%",
        }

        try:
            base = config.get_api_base()
            resp = httpx.post(
                f"{base}/benchmarks/submit",
                json=payload,
                headers={
                    "Authorization": f"Bearer {key}",
                    "User-Agent": "fitmyllm-cli/0.3",
                },
                timeout=15.0,
            )
            if resp.status_code == 200:
                data = resp.json()
                bid = data.get("benchmark_id", "")
                return f"[green]\u2713 Uploaded to FitMyLLM[/] [dim](id: {bid[:8]})[/]"
            else:
                try:
                    err = resp.json().get("error", "Unknown error")
                except Exception:
                    err = f"HTTP {resp.status_code}"
                return f"[yellow]Upload failed: {escape(str(err))}[/]"
        except httpx.ConnectError:
            return "[yellow]Upload failed: cannot connect to fitmyllm.com[/]"
        except httpx.TimeoutException:
            return "[yellow]Upload failed: request timed out[/]"
        except Exception as e:
            return f"[yellow]Upload failed: {escape(str(e))}[/]"
