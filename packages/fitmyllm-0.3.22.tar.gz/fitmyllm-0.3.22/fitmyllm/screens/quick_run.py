"""Quick Run screen — detect GPU, show available models, let user choose, run."""

from __future__ import annotations

from rich.markup import escape

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

from .. import api, config
from ..detect import detect_gpu
from ..models.store import get_inventory, get_model_path
from ..models.download import resolve_gguf_url
from ..backends import (
    detect_backends,
    get_backend,
    calculate_params,
    start_server,
    is_llama_server_installed,
    get_managed_port,
)
from ..backends.openai_compat import OpenAICompatBackend
from ..widgets import get_key


class QuickRunScreen(Screen):
    """Detect GPU, discover models from all sources, let user pick, then run."""

    DEFAULT_CSS = "QuickRunScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._gpu: dict | None = None
        self._gpu_name: str | None = None
        self._models: list[dict] = []
        # Each model: {name, display, source, tag, backend, backend_name,
        #              gguf_repo, gguf_level, ollama_tag, speed, action}
        # action: "chat" (ready), "download_gguf", "ollama_pull"

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(
            "\n  [bold]Quick Run[/]  [dim]Detecting hardware...[/]\n",
            id="qr-header",
        )
        yield Static("", id="qr-status")
        yield DataTable(id="qr-table", cursor_type="row")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#qr-table", DataTable)
        table.add_columns("", "Model", "Speed", "Source")
        self._discover()

    @work(thread=True)
    def _discover(self) -> None:
        """Detect GPU and gather all available models."""
        models: list[dict] = []
        seen: set[str] = set()

        # Step 1: Detect GPU
        gpu = detect_gpu()
        if gpu:
            self._gpu = gpu
            self._gpu_name = gpu["name"]
            vram = gpu.get("vram_mb")
            vram_str = f" ({vram // 1024}GB)" if vram else ""
            config.save_preferred_gpu(self._gpu_name)
            gpu_line = f"  [green]✓[/] GPU: [bold]{escape(self._gpu_name)}[/]{vram_str}"
        else:
            gpu_line = "  [yellow]![/] No GPU detected — CPU mode"

        self.app.call_from_thread(
            self.query_one("#qr-status", Static).update, gpu_line
        )

        # Step 2: Installed models from running backends
        backends = detect_backends()
        for backend in backends:
            try:
                for m in backend.list_models():
                    name = m.get("name", "")
                    if name and name not in seen:
                        seen.add(name)
                        models.append({
                            "name": name,
                            "display": name,
                            "source": f"installed ({backend.name})",
                            "tag": name,
                            "backend": backend,
                            "backend_name": backend.name,
                            "speed": "",
                            "status": "[green]✓ ready[/]",
                            "action": "chat",
                        })
            except Exception:
                pass

        # Step 3: Local GGUF files
        for entry in get_inventory():
            filename = entry.get("filename", "")
            name = entry.get("name", filename)
            quant = entry.get("quant_level", "")
            display = f"{name} ({quant})" if quant else name
            if display not in seen:
                seen.add(display)
                path = get_model_path(filename)
                if path:
                    models.append({
                        "name": name,
                        "display": display,
                        "source": "local GGUF",
                        "tag": filename.replace(".gguf", ""),
                        "backend": None,
                        "backend_name": None,
                        "gguf_path": str(path),
                        "speed": "",
                        "status": "[green]✓ ready[/]",
                        "action": "start_and_chat",
                    })

        # Step 4: API recommendations (fast — no per-model API calls)
        inventory = get_inventory()
        key = get_key()
        if key and self._gpu_name:
            try:
                result = api.recommend(key, self._gpu_name)
                recs = result.get("recommendations", [])
                for r in recs[:15]:
                    rm = r.get("model", {})
                    rq = r.get("quant", {})
                    name = rm.get("name", "")
                    model_id = rm.get("id", "")
                    level = rq.get("level", "")
                    display = f"{name} ({level})"
                    speed = r.get("speed_toks", 0)
                    speed_str = f"~{speed} tok/s" if speed else ""

                    if display in seen:
                        continue
                    seen.add(display)

                    gguf_sources = rm.get("gguf_sources", [])
                    ollama_tag = rq.get("ollama_tag", "")

                    # Check if already downloaded as GGUF
                    local_gguf_path = None
                    for entry in inventory:
                        if (level.lower() in entry.get("quant_level", "").lower()
                                and name.lower() in entry.get("name", "").lower()):
                            p = get_model_path(entry["filename"])
                            if p:
                                local_gguf_path = str(p)
                                break

                    if local_gguf_path:
                        action = "start_and_chat"
                        status = "[green]✓ downloaded[/]"
                        source = "local GGUF"
                    else:
                        # Mark as downloadable — GGUF URL resolved lazily on selection
                        action = "download_gguf"
                        status = "[cyan]↓ download[/]"
                        source = "recommended"

                    models.append({
                        "name": name,
                        "display": display,
                        "source": source,
                        "tag": local_gguf_path.split("/")[-1].replace(".gguf", "") if local_gguf_path else ollama_tag,
                        "backend": None,
                        "backend_name": None,
                        "gguf_path": local_gguf_path,
                        "gguf_repo": gguf_sources[0].get("repo", "") if gguf_sources else "",
                        "gguf_level": level,
                        "model_id": model_id,
                        "ollama_tag": ollama_tag,
                        "speed": speed_str,
                        "status": status,
                        "action": action,
                        "rec": r,
                    })
            except Exception:
                pass

        self._models = models
        self.app.call_from_thread(self._populate_table)

    def _populate_table(self) -> None:
        header = self.query_one("#qr-header", Static)
        table = self.query_one("#qr-table", DataTable)
        table.clear()

        if not self._models:
            header.update(
                "\n  [bold]Quick Run[/]  "
                "[yellow]No models found — check your API key or start an inference backend[/]\n"
            )
            return

        n_ready = sum(1 for m in self._models if m["action"] == "chat")
        n_download = sum(1 for m in self._models if m["action"] != "chat")
        header.update(
            f"\n  [bold]Quick Run[/]  "
            f"[dim]{len(self._models)} models"
            f" ({n_ready} ready, {n_download} downloadable)"
            f" · Select and press Enter[/]\n"
        )

        for m in self._models:
            table.add_row(
                m["status"],
                f"[bold]{escape(m['display'])}[/]",
                m.get("speed", ""),
                f"[dim]{m['source']}[/]",
            )

        table.focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if not self._models or event.cursor_row >= len(self._models):
            return
        model = self._models[event.cursor_row]
        action = model["action"]

        if action == "chat":
            self._open_chat(model["tag"], model.get("backend"), model.get("backend_name"))
        elif action == "start_and_chat":
            self._start_and_chat(model)
        elif action == "download_gguf":
            self._download_gguf(model)
        elif action == "ollama_pull":
            self._ollama_pull(model.get("ollama_tag", model["tag"]))

    def _open_chat(
        self,
        tag: str,
        backend: object | None = None,
        backend_name: str | None = None,
    ) -> None:
        from .chat import ChatScreen

        if backend is None and backend_name:
            backend = get_backend(backend_name)

        self.app.push_screen(ChatScreen(tag, backend=backend))

    def _start_and_chat(self, model: dict) -> None:
        """Start llama-server for a local GGUF, then open chat."""
        gguf_path = model.get("gguf_path", "")

        # Check if llama-server already managed
        port = get_managed_port()
        if port:
            backend = OpenAICompatBackend(base_url=f"http://localhost:{port}", name="llama-server")
            self._open_chat(model["tag"], backend=backend)
            return

        vram_mb = self._gpu.get("vram_mb") if self._gpu else None
        from pathlib import Path
        file_size_gb = Path(gguf_path).stat().st_size / (1024**3)

        params = calculate_params(vram_mb=vram_mb, model_size_gb=file_size_gb)
        self.notify(f"Preparing llama-server ({params['mode']})...", timeout=3)

        try:
            # start_server auto-installs llama-server if needed
            port = start_server(gguf_path, params)
            backend = OpenAICompatBackend(base_url=f"http://localhost:{port}", name="llama-server")
            self._open_chat(model["tag"], backend=backend)
        except Exception as e:
            self.notify(f"Failed: {e}", severity="error", timeout=5)

    def _download_gguf(self, model: dict) -> None:
        """Resolve GGUF source (lazily) and download."""
        repo = model.get("gguf_repo", "")
        level = model.get("gguf_level", "Q4_K_M")
        model_id = model.get("model_id", "")

        # Lazy resolve: if no repo from recommendation, fetch full model details now
        if not repo and model_id:
            self.notify("Resolving download source...", timeout=3)
            key = get_key()
            if key:
                try:
                    full = api.get_model(key, model_id)
                    gguf_sources = full.get("gguf_sources", [])
                    if gguf_sources:
                        repo = gguf_sources[0].get("repo", "")
                except Exception:
                    pass

        if not repo:
            # Final fallback: try ollama pull
            ollama_tag = model.get("ollama_tag", "")
            if ollama_tag:
                self._ollama_pull(ollama_tag)
            else:
                self.notify("No download source available for this model", severity="warning")
            return

        try:
            url = resolve_gguf_url(repo, level)
        except RuntimeError as e:
            self.notify(str(e), severity="error", timeout=5)
            return

        if not url:
            self.notify(f"No {level} GGUF found in {repo}", severity="warning")
            return

        from .gguf_install import GGUFInstallScreen
        self.app.push_screen(GGUFInstallScreen(
            url=url,
            model_id=model.get("name", ""),
            model_name=model.get("name", ""),
            quant_level=level,
            repo=repo,
        ))

    def _ollama_pull(self, tag: str) -> None:
        """Fallback: pull via Ollama."""
        from .ollama_install import OllamaInstallScreen
        self.app.push_screen(OllamaInstallScreen(f"ollama pull {tag}"))
