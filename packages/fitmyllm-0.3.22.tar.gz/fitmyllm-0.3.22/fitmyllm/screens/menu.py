"""Main menu screen."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable
from textual.containers import Vertical
from textual.binding import Binding


class MenuScreen(Screen):
    DEFAULT_CSS = "MenuScreen { layout: vertical; }"

    BINDINGS = [Binding("q", "quit", "Quit")]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Vertical(
            Static(""),
            Static("[bold cyan]  ╭─────────────────────────────╮[/]"),
            Static("[bold cyan]  │     f i t m y l l m         │[/]"),
            Static("[bold cyan]  ╰─────────────────────────────╯[/]"),
            Static(""),
            Static("  [dim]Find the best local AI model for your hardware[/]"),
            Static("  [dim]330+ models · 1700+ GPUs · fitmyllm.com[/]"),
            Static(""),
        )
        table = DataTable(id="menu-table", cursor_type="row")
        table.add_columns("", "Mode", "Description")
        table.add_row("[cyan]>[/]", "[bold]Quick Run[/]", "[dim]Detect GPU, pick model, chat — zero config[/]")
        table.add_row(" ", "[bold]Find Models[/]", "[dim]What can I run on my GPU?[/]")
        table.add_row(" ", "[bold]Find GPU[/]", "[dim]What GPU do I need for a model?[/]")
        table.add_row(" ", "[bold]Enterprise[/]", "[dim]Deploy at scale — sizing, cost, latency[/]")
        table.add_row(" ", "[bold]Model Library[/]", "[dim]Manage installed models[/]")
        table.add_row(" ", "[bold]Tier List[/]", "[dim]Models ranked S-F by score[/]")
        table.add_row(" ", "[bold]Benchmarks[/]", "[dim]Model benchmark leaderboard[/]")
        table.add_row(" ", "[bold]GPU Prices[/]", "[dim]Search and compare GPU pricing[/]")
        table.add_row(" ", "[bold]Run Benchmark[/]", "[dim]Speed test a model locally[/]")
        yield table
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#menu-table", DataTable).focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        idx = event.cursor_row
        if idx == 0:
            from .quick_run import QuickRunScreen
            self.app.push_screen(QuickRunScreen())
        elif idx == 1:
            from .find_models import FindModelsScreen
            self.app.push_screen(FindModelsScreen())
        elif idx == 2:
            from .model_search import ModelSearchScreen
            self.app.push_screen(ModelSearchScreen("gpu"))
        elif idx == 3:
            from .model_search import ModelSearchScreen
            self.app.push_screen(ModelSearchScreen("enterprise"))
        elif idx == 4:
            from .model_library import ModelLibraryScreen
            self.app.push_screen(ModelLibraryScreen())
        elif idx == 5:
            from .tier_list import TierListScreen
            self.app.push_screen(TierListScreen())
        elif idx == 6:
            from .benchmarks import BenchmarkScreen
            self.app.push_screen(BenchmarkScreen())
        elif idx == 7:
            from .gpu_prices import GpuPricesScreen
            self.app.push_screen(GpuPricesScreen())
        elif idx == 8:
            from .bench_submit import BenchSubmitScreen
            self.app.push_screen(BenchSubmitScreen())
