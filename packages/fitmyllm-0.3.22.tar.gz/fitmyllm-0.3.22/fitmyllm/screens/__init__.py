"""FitMyLLM TUI screens."""

from .menu import MenuScreen
from .find_models import FindModelsScreen
from .model_search import ModelSearchScreen
from .model_detail import ModelDetailScreen
from .find_gpu import FindGpuScreen
from .enterprise_input import EnterpriseInputScreen
from .enterprise import EnterpriseScreen
from .install import InstallScreen
from .ollama_install import OllamaInstallScreen
from .compare import CompareScreen
from .tier_list import TierListScreen
from .command_sim import CommandSimScreen
from .gpu_compare import GpuCompareScreen
from .charts import ChartsScreen
from .benchmarks import BenchmarkScreen
from .gpu_prices import GpuPricesScreen
from .bench_submit import BenchSubmitScreen
from .chat import ChatScreen
from .gguf_install import GGUFInstallScreen
from .quick_run import QuickRunScreen
from .model_library import ModelLibraryScreen

__all__ = [
    "MenuScreen",
    "FindModelsScreen",
    "ModelSearchScreen",
    "ModelDetailScreen",
    "FindGpuScreen",
    "EnterpriseInputScreen",
    "EnterpriseScreen",
    "InstallScreen",
    "OllamaInstallScreen",
    "GGUFInstallScreen",
    "QuickRunScreen",
    "ModelLibraryScreen",
    "CompareScreen",
    "TierListScreen",
    "CommandSimScreen",
    "GpuCompareScreen",
    "ChartsScreen",
    "BenchmarkScreen",
    "GpuPricesScreen",
    "BenchSubmitScreen",
    "ChatScreen",
]
