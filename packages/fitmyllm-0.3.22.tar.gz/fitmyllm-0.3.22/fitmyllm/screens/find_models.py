"""Find Models screen — What can I run on my GPU?"""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import (
    Header, Footer, Static, DataTable, Input, Label, Select, Switch,
)
from textual.containers import Vertical, Horizontal, VerticalScroll
from textual.binding import Binding
from textual import work

from .. import api
from ..detect import detect_gpu
from ..widgets import get_key, bar, vbar, FIT_COLORS
from ..constants import (
    USE_CASES, CONTEXT_OPTIONS, SORT_OPTIONS, SIZE_OPTIONS,
    ARCH_OPTIONS, SPEED_OPTIONS, KV_QUANT_OPTIONS,
    FAMILY_OPTIONS, QUANT_OPTIONS, QUANT_LEVEL_MAP,
    GPU_COUNT_OPTIONS,
)

# Inference mode display labels
MODE_LABELS = {
    "gpu_full": "[green]GPU[/]",
    "gpu_offload": "[yellow]Offload[/]",
    "cpu_only": "[red]CPU[/]",
    "not_possible": "[dim]N/A[/]",
}


class FindModelsScreen(Screen):
    DEFAULT_CSS = "FindModelsScreen { layout: vertical; }"

    BINDINGS = [
        Binding("f", "toggle_filters", "Filters", show=True),
        Binding("g", "search_gpu", "GPU", show=True),
        Binding("space", "toggle_compare", "Mark", show=True),
        Binding("c", "compare", "Compare", show=True),
        Binding("e", "export", "Export", show=True),
        Binding("v", "charts", "Charts", show=True),
        Binding("ctrl+s", "save_filters", "Save Filters"),
        Binding("enter", "open_detail", "Details", show=True),
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self):
        super().__init__()
        self.gpu_name: str | None = None
        self.recs: list[dict] = []
        self._loading = False
        self._gpu_searching = False
        self._compare_set: set[int] = set()  # indices of marked models

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static("  [dim]Detecting GPU...[/]", id="gpu-bar")
        # GPU search bar (hidden by default)
        yield Input(
            placeholder="Type GPU name and press Enter (e.g. RTX 4060, RX 7900 XTX)...",
            id="gpu-search-input",
        )

        with Horizontal():
            with VerticalScroll(id="filters-panel"):
                yield Label("USE CASE")
                yield Select([(uc.title(), uc) for uc in USE_CASES], value="chat", id="sel-usecase", allow_blank=False)
                yield Label("CONTEXT")
                yield Select(CONTEXT_OPTIONS, value="4096", id="sel-context", allow_blank=False)
                yield Label("SORT BY")
                yield Select(SORT_OPTIONS, value="score", id="sel-sort", allow_blank=False)
                yield Label("MODEL SIZE")
                yield Select(SIZE_OPTIONS, value="all", id="sel-size", allow_blank=False)
                yield Label("ARCHITECTURE")
                yield Select(ARCH_OPTIONS, value="all", id="sel-arch", allow_blank=False)
                yield Label("FAMILY")
                yield Select(FAMILY_OPTIONS, value="all", id="sel-family", allow_blank=False)
                yield Label("QUANTIZATION")
                yield Select(QUANT_OPTIONS, value="all", id="sel-quant", allow_blank=False)
                yield Label("MIN SPEED")
                yield Select(SPEED_OPTIONS, value="0", id="sel-speed", allow_blank=False)
                yield Label("KV CACHE")
                yield Select(KV_QUANT_OPTIONS, value="fp16", id="sel-kv", allow_blank=False)
                yield Label("GPU COUNT")
                yield Select(GPU_COUNT_OPTIONS, value="1", id="sel-gpucount", allow_blank=False)
                yield Horizontal(
                    Switch(value=False, id="sw-nvlink"),
                    Static(" NVLink", classes="switch-label"),
                )
                yield Label("RAM (GB)")
                yield Input(placeholder="optional", id="inp-ram")
                yield Label("CPU")
                yield Input(placeholder="e.g. Ryzen 9 7950X", id="inp-cpu")
                yield Label("")
                yield Horizontal(
                    Switch(value=True, id="sw-offload"),
                    Static(" Show offload", classes="switch-label"),
                )
                yield Horizontal(
                    Switch(value=True, id="sw-cpu"),
                    Static(" Show CPU-only", classes="switch-label"),
                )
                yield Horizontal(
                    Switch(value=False, id="sw-vram-only"),
                    Static(" Only fits VRAM", classes="switch-label"),
                )

            with Vertical():
                yield DataTable(id="models-table", cursor_type="row")

        yield Static("", id="detail-panel")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#models-table", DataTable)
        table.add_columns("#", "Model", "Params", "Quant", "Score", "Speed", "VRAM%", "Mode", "Fit")
        # Hide GPU search bar initially
        self.query_one("#gpu-search-input", Input).display = False
        table.focus()
        self._detect_and_load()

    def action_toggle_filters(self) -> None:
        panel = self.query_one("#filters-panel")
        panel.display = not panel.display

    def action_search_gpu(self) -> None:
        """Toggle GPU search input."""
        inp = self.query_one("#gpu-search-input", Input)
        inp.display = not inp.display
        if inp.display:
            inp.focus()

    def action_toggle_compare(self) -> None:
        """Mark/unmark current model for comparison."""
        if not self.recs:
            return
        table = self.query_one("#models-table", DataTable)
        idx = table.cursor_row
        if idx is None or idx < 0 or idx >= len(self.recs):
            return
        if idx in self._compare_set:
            self._compare_set.discard(idx)
        elif len(self._compare_set) < 4:
            self._compare_set.add(idx)
        else:
            self.notify("Max 4 models for comparison", severity="warning")
            return
        # Re-render the table to show markers
        self._refresh_table()

    def action_compare(self) -> None:
        """Open compare screen with marked models."""
        if len(self._compare_set) < 2:
            self.notify("Mark at least 2 models with Space", severity="warning")
            return
        selected = [self.recs[i] for i in sorted(self._compare_set)]
        from .compare import CompareScreen
        self.app.push_screen(CompareScreen(selected))

    def action_export(self) -> None:
        """Export results as Markdown file."""
        if not self.recs:
            self.notify("No results to export", severity="warning")
            return
        lines = [f"# FitMyLLM Results — {self.gpu_name}\n"]
        lines.append(f"| # | Model | Params | Quant | Score | Speed | VRAM% | Mode | Fit |")
        lines.append(f"|---|-------|--------|-------|-------|-------|-------|------|-----|")
        for i, r in enumerate(self.recs):
            lines.append(
                f"| {i+1} | {r['model']['name']} | {r['model']['params_b']}B | "
                f"{r['quant']['level']} | {r['score']} | "
                f"{'~'+str(r['speed_toks'])+' tok/s' if r['speed_toks'] else '—'} | "
                f"{r['vram_percent']}% | {r.get('inference_mode', '')} | {r.get('fit', '')} |"
            )
        from pathlib import Path
        out = Path("fitmyllm-results.md")
        out.write_text("\n".join(lines) + "\n")
        self.notify(f"Exported to {out.absolute()}", timeout=5)

    def action_save_filters(self) -> None:
        """Save current filter settings as defaults."""
        from ..config import save_preferences
        filters = self._get_filters()
        if self.gpu_name:
            filters["gpu_name"] = self.gpu_name
        save_preferences(filters)
        self.notify("Filters saved as defaults", timeout=3)

    def action_charts(self) -> None:
        """Open ASCII charts visualization."""
        if not self.recs:
            self.notify("No results to chart", severity="warning")
            return
        from .charts import ChartsScreen
        self.app.push_screen(ChartsScreen(self.recs, self.gpu_name or ""))

    def _refresh_table(self) -> None:
        """Refresh the results table with compare markers."""
        table = self.query_one("#models-table", DataTable)
        cursor = table.cursor_row
        table.clear()
        for i, r in enumerate(self.recs):
            fit = r.get("fit", "")
            fs = FIT_COLORS.get(fit, "")
            ss = "green" if r["score"] >= 70 else "yellow" if r["score"] >= 50 else "red"
            mode = MODE_LABELS.get(r.get("inference_mode", ""), "")
            marker = "[bold cyan]★[/]" if i in self._compare_set else " "
            table.add_row(
                f"{marker}{i + 1}",
                r["model"]["name"],
                f'{r["model"]["params_b"]}B',
                r["quant"]["level"],
                f'[{ss}]{r["score"]}[/]',
                f'~{r["speed_toks"]} tok/s' if r["speed_toks"] else "—",
                f'{r["vram_percent"]}%',
                mode,
                f'[{fs}]● {fit}[/]',
            )
        if cursor is not None and cursor < len(self.recs):
            table.move_cursor(row=cursor)

    def action_open_detail(self) -> None:
        if not self.recs:
            return
        table = self.query_one("#models-table", DataTable)
        idx = table.cursor_row
        if idx is None or idx < 0 or idx >= len(self.recs):
            return
        from .model_detail import ModelDetailScreen
        r = self.recs[idx]
        self.app.push_screen(ModelDetailScreen(r["model"]["id"], r))

    def _get_filters(self) -> dict:
        """Collect all current filter values."""
        def val(sel_id: str) -> str:
            try:
                return str(self.query_one(f"#{sel_id}", Select).value)
            except Exception:
                return ""

        size = val("sel-size")
        arch = val("sel-arch")
        speed = val("sel-speed")
        family = val("sel-family")
        quant = val("sel-quant")

        filters: dict = {
            "use_case": val("sel-usecase") or "chat",
            "context_length": int(val("sel-context") or "4096"),
            "sort_by": val("sel-sort") or "score",
            "kv_cache_quant": val("sel-kv") or "fp16",
        }

        if size and size != "all":
            filters["size_ranges"] = [size]
        if arch and arch != "all":
            filters["architectures"] = [arch]
        if speed and int(speed) > 0:
            filters["min_speed"] = int(speed)
        if family and family != "all":
            filters["families"] = [family]
        if quant and quant != "all":
            levels = QUANT_LEVEL_MAP.get(quant, [])
            if levels:
                filters["quant_levels"] = levels

        # Multi-GPU
        gpu_count = val("sel-gpucount")
        if gpu_count and int(gpu_count) > 1:
            filters["gpu_count"] = int(gpu_count)
            try:
                filters["nvlink"] = self.query_one("#sw-nvlink", Switch).value
            except Exception:
                pass

        # Show/hide toggles
        try:
            filters["show_offload"] = self.query_one("#sw-offload", Switch).value
            filters["show_cpu_only"] = self.query_one("#sw-cpu", Switch).value
            filters["only_fits_vram"] = self.query_one("#sw-vram-only", Switch).value
        except Exception:
            pass

        try:
            ram_val = self.query_one("#inp-ram", Input).value
            if ram_val:
                filters["ram_gb"] = int(ram_val)
        except Exception:
            pass

        return filters

    def on_select_changed(self, event: Select.Changed) -> None:
        if not self._loading and self.gpu_name:
            self._fetch()

    def on_switch_changed(self, event: Switch.Changed) -> None:
        if not self._loading and self.gpu_name:
            self._fetch()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "inp-ram" and self.gpu_name:
            self._fetch()
        elif event.input.id == "gpu-search-input" and event.value.strip():
            self._search_gpu(event.value.strip())

    @work(thread=True)
    def _detect_and_load(self) -> None:
        gpu = detect_gpu()
        if gpu:
            self.gpu_name = gpu["name"]
            self.app.call_from_thread(self._update_gpu_bar, gpu["name"], gpu.get("vram_mb"))
            self._do_fetch()
        else:
            self.app.call_from_thread(self._show_gpu_search)

    def _show_gpu_search(self) -> None:
        """Show GPU search when auto-detect fails."""
        self.query_one("#gpu-bar", Static).update(
            "  [yellow]GPU not detected[/]  [dim]Press [bold]g[/bold] to search manually[/]"
        )
        inp = self.query_one("#gpu-search-input", Input)
        inp.display = True
        inp.focus()

    def _update_gpu_bar(self, name: str, vram_mb: int | None = None) -> None:
        vram = f"  {vram_mb // 1024}GB" if vram_mb else ""
        self.query_one("#gpu-bar", Static).update(
            f"  [bold]{name}[/]{vram}  [dim](press [bold]g[/bold] to change)[/]"
        )

    @work(thread=True)
    def _search_gpu(self, query: str) -> None:
        """Search for a GPU by name and use the first result."""
        key = get_key()
        if not key:
            return
        try:
            results = api.search_gpus(key, query)
            if results:
                gpu = results[0]
                self.gpu_name = gpu["name"]
                self.app.call_from_thread(self._on_gpu_selected, gpu)
                self._do_fetch()
            else:
                self.app.call_from_thread(
                    self.notify, f'No GPU found for "{query}"', severity="warning"
                )
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _on_gpu_selected(self, gpu: dict) -> None:
        vram_mb = gpu.get("vram_mb", 0)
        vram = f"  {vram_mb // 1024}GB" if vram_mb else ""
        self.query_one("#gpu-bar", Static).update(
            f"  [bold]{gpu['name']}[/]{vram}  [dim](press [bold]g[/bold] to change)[/]"
        )
        inp = self.query_one("#gpu-search-input", Input)
        inp.display = False
        self.query_one("#models-table", DataTable).focus()

    @work(thread=True)
    def _fetch(self) -> None:
        self._do_fetch()

    def _do_fetch(self) -> None:
        self._loading = True
        key = get_key()
        if not key or not self.gpu_name:
            self._loading = False
            return
        try:
            filters = self.app.call_from_thread(self._get_filters)
            data = api.recommend(key, self.gpu_name, **filters)
            self.app.call_from_thread(self._show_results, data)
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")
        finally:
            self._loading = False

    def _show_results(self, data: dict) -> None:
        self.recs = data.get("recommendations", [])
        gpu = data.get("gpu", {})

        vram = gpu.get("vram_mb", 0) // 1024
        uc = data.get("use_case", "")
        ctx = data.get("context_length", 4096) // 1024
        self.query_one("#gpu-bar", Static).update(
            f"  [bold]{gpu.get('name', '')}[/]  [dim]{vram}GB {gpu.get('memory_type', '')} · {gpu.get('bandwidth_gbps', 0)} GB/s[/]  "
            f"[dim]|[/]  [cyan]{uc}[/]  [cyan]{ctx}K[/]  "
            f"[dim]{len(self.recs)} models[/]  "
            f"[dim](press [bold]g[/bold] to change GPU)[/]"
        )

        table = self.query_one("#models-table", DataTable)
        table.clear()
        for i, r in enumerate(self.recs):
            fit = r.get("fit", "")
            fs = FIT_COLORS.get(fit, "")
            ss = "green" if r["score"] >= 70 else "yellow" if r["score"] >= 50 else "red"
            mode = MODE_LABELS.get(r.get("inference_mode", ""), "")
            table.add_row(
                str(i + 1),
                r["model"]["name"],
                f'{r["model"]["params_b"]}B',
                r["quant"]["level"],
                f'[{ss}]{r["score"]}[/]',
                f'~{r["speed_toks"]} tok/s' if r["speed_toks"] else "—",
                f'{r["vram_percent"]}%',
                mode,
                f'[{fs}]● {fit}[/]',
            )
        if self.recs:
            self._show_detail(0)
            table.focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Enter on a model opens the detail screen."""
        if event.cursor_row is not None and event.cursor_row < len(self.recs):
            from .model_detail import ModelDetailScreen
            r = self.recs[event.cursor_row]
            self.app.push_screen(ModelDetailScreen(r["model"]["id"], r))

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.cursor_row is not None:
            self._show_detail(event.cursor_row)

    def _show_detail(self, idx: int) -> None:
        if idx < 0 or idx >= len(self.recs):
            return
        r = self.recs[idx]
        tag = r["quant"].get("ollama_tag") or r["model"]["id"]
        vg = r["quant"]["vram_mb"] / 1024
        q = int(r["quant"]["quality"] * 100)
        s, sp, vp = r["score"], r["speed_toks"], r["vram_percent"]
        fit = r.get("fit", "")
        fs = FIT_COLORS.get(fit, "")
        sb = bar(s, 15)
        spb = bar(min(100, (sp or 0) * 1.2), 15) if sp else "[dim]" + "░" * 15 + "[/]"
        vb = vbar(vp, 15)

        # Warnings
        warnings = r.get("warnings", [])
        warn_str = ""
        if warnings:
            warn_str = "  [yellow]⚠ " + " · ".join(warnings[:2]) + "[/]"

        mode = MODE_LABELS.get(r.get("inference_mode", ""), "")

        # Show install command — prefer GGUF download, fallback to ollama
        gguf_sources = r["model"].get("gguf_sources", [])
        if gguf_sources:
            install_cmd = f"  [cyan]↓ Download GGUF[/] [dim]from {gguf_sources[0].get('repo', '')}[/]"
        elif tag:
            install_cmd = f"  [dim]$ ollama pull {tag}[/]"
        else:
            install_cmd = ""

        self.query_one("#detail-panel", Static).update(
            f"  [bold]{r['model']['name']}[/] [dim]{r['model']['provider']}[/]  "
            f"[dim]{r['model']['params_b']}B {r['model']['architecture']} · {r['quant']['level']} ({q}%) · {vg:.1f}GB VRAM · {r['model']['params_b'] * r['quant'].get('bpw', 4.5) / 8:.1f}GB download[/]  "
            f"Score {sb} [bold]{s}[/]  "
            f"Speed {spb} [bold]{'~' + str(sp) if sp else '—'}[/]  "
            f"VRAM {vb} [bold]{vp}%[/] [{fs}]{fit}[/]  {mode}"
            f"{warn_str}\n"
            f"{install_cmd}  [dim]Press [bold]i[/bold] to install · [bold]Enter[/bold] for details[/]"
        )
