"""Entry point for fitmyllm CLI."""
import sys

__version__ = "0.3.22"


def _check_update() -> None:
    """Quick check for newer version on PyPI (2s timeout, non-blocking)."""
    try:
        import httpx
        resp = httpx.get("https://pypi.org/pypi/fitmyllm/json", timeout=2.0)
        if resp.is_success:
            latest = resp.json().get("info", {}).get("version", "")
            if latest and latest != __version__:
                print(f"  [update] fitmyllm {latest} available (you have {__version__})")
                print(f"           pip install --upgrade fitmyllm\n")
    except Exception:
        pass


def main():
    # Handle --help before loading Textual
    if "--help" in sys.argv or "-h" in sys.argv:
        print(f"""
  fitmyllm {__version__} — Run the right LLM locally. Automatically.

  Usage:
    fitmyllm              Interactive TUI (recommended)
    fitmyllm setup        Save your API key

  API key:
    Get your free key at https://www.fitmyllm.com/?tab=mcp
    Save it with: fitmyllm setup
    Or: export FITMYLLM_API_KEY=fml_xxxxx

  Main menu (9 modes):
    Quick Run       Detect GPU -> best model -> download -> chat (zero config)
    Find Models     What can I run on my GPU?
    Find GPU        What GPU do I need for a model?
    Enterprise      Deploy at scale — sizing, cost, latency
    Model Library   Manage installed models (Ollama, llama-server, local GGUF)
    Tier List       Models ranked S-F by score
    Benchmarks      Model benchmark leaderboard
    GPU Prices      Search and compare GPU pricing
    Run Benchmark   Speed test with model selection + delta vs predicted

  Keyboard shortcuts (in TUI):
    f          Toggle filter panel
    g          Search/change GPU
    Space      Mark model for comparison
    c          Compare marked / chat from library
    d          Delete model (in Model Library)
    i          Install model
    m          Manual input (in Run Benchmark)
    t          Command simulator / toggle thinking
    s          Save model
    r          Refresh / HuggingFace README
    Enter      Open model detail
    Escape     Go back
    q          Quit

  Backends (auto-detected):
    Ollama          localhost:11434 (ollama pull / run)
    llama-server    localhost:8080 (auto-started or manual)
    OpenAI-compat   Any server speaking /v1/chat/completions

  Data storage:
    ~/.fitmyllm/config.json     Preferences, API key, saved models
    ~/.fitmyllm/cache/          API response cache (24h TTL)
    ~/.fitmyllm/models/         Downloaded GGUF files + inventory

  Environment:
    FITMYLLM_API_KEY      API key
    FITMYLLM_API_URL      API base URL (default: https://www.fitmyllm.com/api/v1)
        """)
        return

    if "--version" in sys.argv or "-V" in sys.argv:
        print(f"fitmyllm {__version__}")
        return

    if "setup" in sys.argv:
        from .config import save_api_key
        key = input("  API key: ").strip()
        if not key.startswith("fml_"):
            print("  Error: API key must start with 'fml_'")
            sys.exit(1)
        save_api_key(key)
        print("  Saved to ~/.fitmyllm/config.json")
        return

    # Auto-update check (quick, non-blocking)
    _check_update()

    from .app import FitMyLLMApp
    app = FitMyLLMApp()
    result = app.run()
    if result:
        print(f"\n  Run: {result}\n")

if __name__ == "__main__":
    main()
