# Dari CLI

`dari` validates, packages, and publishes agent projects to Agent Host.

Full docs: https://docs.dari.dev

## Install

```bash
uv tool install dari-cli
```

Or:

```bash
pipx install dari-cli
```

From GitHub before a PyPI release:

```bash
uv tool install git+https://github.com/mupt-ai/dari-cli.git
```

## Commands

Most commands require `dari auth login` first. The CLI talks to `https://api.dari.dev`.

### auth

```bash
dari auth login      # browser login, caches org key locally
dari auth logout     # clear local login state
dari auth status     # show current login and org
```

### org

```bash
dari org list
dari org create <name>
dari org switch <organization>               # slug or id
dari org members
dari org invite <email> [--role owner|admin|member]
```

### deploy

```bash
dari deploy [repo_root]
```

| Flag | Description |
| --- | --- |
| `--api-key` | Override the cached org key |
| `--agent-id` | Publish to a specific agent |
| `--dry-run` | Validate and package without uploading |

### api-keys

```bash
dari api-keys list
dari api-keys create --name <name>           # plaintext key returned once
dari api-keys revoke <key_id>
```

### credentials

Stored secrets referenced by name from `dari.yml` (e.g. `llm.api_key_secret: OPENROUTER_API_KEY`).

```bash
dari credentials list
dari credentials add <name> [value]          # prompts if value omitted
dari credentials add <name> --value-stdin < secret.txt
dari credentials remove <name>
```

### manifest

```bash
dari manifest validate [repo_root]
dari manifest validate --json                # prints normalized manifest
```

## Bundle shape

The repo root must contain:

- `dari.yml`
- `Dockerfile`
- any prompt files referenced by `instructions`
- custom tools under `tools/<name>/tool.yml`

Supported `harness` values: `pi`, `opencode`, `openai-agents`, `claude-agent-sdk`.

Minimal `dari.yml`:

```yaml
name: support-agent
harness: pi

instructions:
  system: prompts/system.md

runtime:
  dockerfile: Dockerfile

sandbox:
  provider: e2b
  provider_api_key_secret: E2B_API_KEY

tools:
  - name: repo_search
    path: tools/repo_search
    kind: main
  - name: sandbox.exec
    kind: ephemeral
```

Store the referenced E2B key as an org credential before publishing:

```bash
dari credentials add E2B_API_KEY
```

See [examples/](./examples) for per-harness starters. Full schema: https://docs.dari.dev/manifest.

## Local development

```bash
uv sync --group dev
uv run pytest
```

## Release

1. Bump `version` in `pyproject.toml`.
2. Refresh `uv.lock` so the editable entry matches.
3. Commit the bump before tagging.
4. `uv build && uv run pytest`.
5. Push a `v0.1.x` tag matching `pyproject.toml` — the release workflow rejects mismatched tags.

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md).
