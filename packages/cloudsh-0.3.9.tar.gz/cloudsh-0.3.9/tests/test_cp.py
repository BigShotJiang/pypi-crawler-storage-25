import pytest
from argparse import Namespace

from panpath import PanPath
from cloudsh.commands.cp import run


class TestCp:
    """Test cp command functionality"""

    @pytest.fixture
    def source_file(self, workdir):
        """Create a source test file"""
        path = workdir / "source.txt"
        path.write_text("test content")
        return str(path)

    @pytest.fixture
    def source_dir(self, workdir):
        """Create a source test directory with files"""
        path = workdir / "source_dir"
        path.mkdir(exist_ok=True)
        (path / "file1.txt").write_text("content1")
        (path / "file2.txt").write_text("content2")
        (path / "subdir").mkdir(exist_ok=True)
        (path / "subdir/file3.txt").write_text("content3")
        return str(path)

    @pytest.fixture
    def local_source_dir(self, tmp_path):
        """Create a local source directory with files"""
        path = tmp_path / "local_source_dir"
        path.mkdir(exist_ok=True)
        (path / "file1.txt").write_text("local1")
        (path / "file2.txt").write_text("local2")
        (path / "subdir").mkdir()
        (path / "subdir" / "file3.txt").write_text("local3")
        return str(path)

    @pytest.fixture
    def cloud_source_dir(self, workdir):
        """Create a cloud source directory with files"""
        path = workdir / "cloud_source_dir"
        path.mkdir(exist_ok=True)
        (path / "file1.txt").write_text("cloud1")
        (path / "file2.txt").write_text("cloud2")
        (path / "subdir").mkdir()
        (path / "subdir" / "file3.txt").write_text("cloud3")
        return str(path)

    @pytest.fixture(autouse=True)
    def setup_input(self, monkeypatch):
        """Set up input mocking for interactive prompts"""
        self.input_response = "y"

        def mock_input(prompt):
            print(prompt, end="")  # Show prompt in test output
            return self.input_response

        monkeypatch.setattr("builtins.input", mock_input)

    async def test_cp_single_file(self, source_file, workdir, capsys):
        """Test copying a single file"""
        dest = str(workdir / "dest.txt")
        args = Namespace(
            SOURCE=[source_file],
            DEST=dest,
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        dest_path = PanPath(dest)
        assert await dest_path.a_exists()
        assert await dest_path.a_read_text() == "test content"
        assert "-> '" in capsys.readouterr().out

    async def test_cp_to_directory(self, source_file, workdir):
        """Test copying file to directory"""
        dest_dir = workdir / "dest_dir"
        await dest_dir.a_mkdir()
        args = Namespace(
            SOURCE=[source_file],
            DEST=str(dest_dir),
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        copied_file = dest_dir / "source.txt"
        assert await copied_file.a_exists()
        assert await copied_file.a_read_text() == "test content"

    async def test_cp_recursive(self, source_dir, workdir):
        """Test recursive directory copying"""
        dest_dir = workdir / "dest_dir_recursive"
        args = Namespace(
            SOURCE=[source_dir],
            DEST=str(dest_dir),
            recursive=True,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await (dest_dir / "file1.txt").a_exists()
        assert await (dest_dir / "file2.txt").a_exists()
        assert await (dest_dir / "subdir/file3.txt").a_exists()

    async def test_cp_interactive_yes(self, source_file, workdir):
        """Test interactive copying with 'yes' response"""
        dest = workdir / "interactive.txt"
        await dest.a_write_text("original content")
        self.input_response = "y"
        args = Namespace(
            SOURCE=[source_file],
            DEST=str(dest),
            recursive=False,
            interactive=True,
            force=False,
            no_clobber=False,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await dest.a_read_text() == "test content"

    async def test_cp_interactive_no(self, source_file, workdir):
        """Test interactive copying with 'no' response"""
        dest = workdir / "interactive_no.txt"
        await dest.a_write_text("original content")
        self.input_response = "n"
        args = Namespace(
            SOURCE=[source_file],
            DEST=str(dest),
            recursive=False,
            interactive=True,
            force=False,
            no_clobber=False,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await dest.a_read_text() == "original content"

    async def test_cp_no_clobber(self, source_file, workdir):
        """Test no-clobber option"""
        dest = workdir / "noclobber.txt"
        await dest.a_write_text("original content")
        args = Namespace(
            SOURCE=[source_file],
            DEST=str(dest),
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=True,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await dest.a_read_text() == "original content"

    async def test_cp_preserve(self, source_file, workdir):
        """Test preserving file attributes"""
        dest = str(workdir / "preserved.txt")
        args = Namespace(
            SOURCE=[source_file],
            DEST=dest,
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=False,
            preserve=True,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        src_path = PanPath(source_file)
        dst_path = PanPath(dest)
        assert src_path.stat().st_mode == dst_path.stat().st_mode

    async def test_cp_target_directory(self, source_file, workdir):
        """Test using target-directory option"""
        target_dir = str(workdir / "target_dir")
        args = Namespace(
            SOURCE=[source_file],
            DEST="unused",  # Should be ignored
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=target_dir,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        copied_file = PanPath(target_dir) / "source.txt"
        assert await copied_file.a_exists()
        assert await copied_file.a_read_text() == "test content"

    async def test_cp_error_handling(self, source_dir, workdir, capsys):
        """Test error handling for various scenarios"""
        # Test copying to existing directory without -r
        dest_dir = workdir / "existing_file"
        await dest_dir.a_touch()
        args = Namespace(
            SOURCE=[source_dir],
            DEST=str(dest_dir),
            recursive=True,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=True,  # Treat dest as file
            parents=False,
        )
        with pytest.raises(SystemExit):
            await run(args)
        assert "cannot copy" in capsys.readouterr().err

    async def test_cp_multiple_sources(self, source_file, source_dir, workdir, capsys):
        """Test copying multiple sources to directory"""
        dest_dir = workdir / "multi_dest"
        await dest_dir.a_mkdir()
        args = Namespace(
            SOURCE=[source_file, source_dir],
            DEST=str(dest_dir),
            recursive=True,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        dest_path = PanPath(dest_dir)
        assert await (dest_path / "source.txt").a_exists()
        assert await (dest_path / "source_dir").a_is_dir()
        assert await (dest_path / "source_dir/file1.txt").a_exists()

    async def test_cp_local_to_local(self, local_source_dir, tmp_path):
        """Test copying from local to local"""
        dest = PanPath(tmp_path) / "local_dest"
        args = Namespace(
            SOURCE=[local_source_dir],
            DEST=str(dest),
            recursive=True,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await (dest / "file1.txt").a_exists()
        assert await (dest / "file2.txt").a_exists()
        assert await (dest / "subdir" / "file3.txt").a_exists()
        assert await (dest / "file1.txt").a_read_text() == "local1"

    async def test_cp_local_to_cloud(self, local_source_dir, workdir):
        """Test copying from local to cloud"""
        dest = workdir / "cloud_dest_from_local"
        args = Namespace(
            SOURCE=[local_source_dir],
            DEST=str(dest),
            recursive=True,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await (dest / "file1.txt").a_exists()
        assert await (dest / "file2.txt").a_exists()
        assert await (dest / "subdir" / "file3.txt").a_exists()
        assert await (dest / "file1.txt").a_read_text() == "local1"

    async def test_cp_cloud_to_local(self, cloud_source_dir, tmp_path):
        """Test copying from cloud to local"""
        dest = PanPath(tmp_path) / "local_dest_from_cloud"
        args = Namespace(
            SOURCE=[cloud_source_dir],
            DEST=str(dest),
            recursive=True,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await (dest / "file1.txt").a_exists()
        assert await (dest / "file2.txt").a_exists()
        assert await (dest / "subdir" / "file3.txt").a_exists()
        assert await (dest / "file1.txt").a_read_text() == "cloud1"

    async def test_cp_single_file_local_to_cloud(self, tmp_path, workdir):
        """Test copying single file from local to cloud"""
        local_file = PanPath(tmp_path) / "local.txt"
        await local_file.a_write_text("local content")
        cloud_dest = workdir / "cloud_file.txt"

        args = Namespace(
            SOURCE=[str(local_file)],
            DEST=str(cloud_dest),
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await cloud_dest.a_exists()
        assert await cloud_dest.a_read_text() == "local content"

    async def test_cp_single_file_cloud_to_local(self, tmp_path, workdir):
        """Test copying single file from cloud to local"""
        cloud_file = workdir / "cloud_source.txt"
        await cloud_file.a_write_text("cloud content")
        local_dest = PanPath(tmp_path) / "local_dest.txt"

        args = Namespace(
            SOURCE=[str(cloud_file)],
            DEST=str(local_dest),
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await local_dest.a_exists()
        assert await local_dest.a_read_text() == "cloud content"

    async def test_cp_parent_not_exists(self, source_file, workdir, capsys):
        """Test copying to non-existent parent directory"""
        dest = workdir / "nonexistent/dest.txt"
        args = Namespace(
            SOURCE=[source_file],
            DEST=str(dest),
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        with pytest.raises(SystemExit) as exc_info:
            await run(args)
        assert exc_info.value.code == 1
        assert "No such file or directory" in capsys.readouterr().err

    async def test_cp_directory_without_recursive(self, source_dir, workdir, capsys):
        """Test copying directory without -r flag"""
        dest = workdir / "dest"
        args = Namespace(
            SOURCE=[source_dir],
            DEST=str(dest),
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        with pytest.raises(SystemExit) as exc_info:
            await run(args)
        assert exc_info.value.code == 1
        assert "-r not specified" in capsys.readouterr().err

    async def test_cp_multiple_sources_to_non_directory(
        self, source_file, workdir, capsys
    ):
        """Test error when copying multiple sources to non-directory"""
        src1 = workdir / "src1.txt"
        await src1.a_write_text("content1")
        src2 = workdir / "src2.txt"
        await src2.a_write_text("content2")
        dest = workdir / "dest.txt"

        args = Namespace(
            SOURCE=[str(src1), str(src2)],
            DEST=str(dest),
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        with pytest.raises(SystemExit) as exc_info:
            await run(args)
        assert exc_info.value.code == 1
        assert "target must be a directory" in capsys.readouterr().err

    async def test_cp_force_overwrite(self, source_file, workdir):
        """Test force overwriting existing file"""
        dest = workdir / "dest.txt"
        await dest.a_write_text("old content")

        args = Namespace(
            SOURCE=[source_file],
            DEST=str(dest),
            recursive=False,
            interactive=False,
            force=True,
            no_clobber=False,
            verbose=False,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await dest.a_read_text() == "test content"

    async def test_cp_cloud_file_to_cloud_file(self, cloud_workdir):
        """Test copying between two cloud paths"""
        src = cloud_workdir / "cloud_src.txt"
        await src.a_write_text("cloud to cloud content")
        dest = cloud_workdir / "cloud_dest.txt"

        args = Namespace(
            SOURCE=[str(src)],
            DEST=str(dest),
            recursive=False,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await dest.a_exists()
        assert await dest.a_read_text() == "cloud to cloud content"

    async def test_cp_cloud_dir_to_cloud_dir_exists(self, cloud_workdir):
        """Test copying cloud directory to existing cloud directory"""
        src_dir = cloud_workdir / "cloud_src_dir"
        await src_dir.a_mkdir()
        await (src_dir / "file1.txt").a_write_text("cloud1")
        await (src_dir / "file2.txt").a_write_text("cloud2")

        dest_dir = cloud_workdir / "cloud_dest_dir"
        await dest_dir.a_mkdir()

        args = Namespace(
            SOURCE=[str(src_dir)],
            DEST=str(dest_dir),
            recursive=True,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await (dest_dir / "cloud_src_dir/file1.txt").a_exists()
        assert await (dest_dir / "cloud_src_dir/file2.txt").a_exists()

    async def test_cp_cloud_dir_to_cloud_dir_not_exists(self, cloud_workdir):
        """Test copying cloud directory to non-existing cloud directory"""
        src_dir = cloud_workdir / "cloud_src_dir2"
        await src_dir.a_mkdir()
        await (src_dir / "file1.txt").a_write_text("cloudA")
        await (src_dir / "file2.txt").a_write_text("cloudB")

        dest_dir = cloud_workdir / "cloud_dest_dir2"

        args = Namespace(
            SOURCE=[str(src_dir)],
            DEST=str(dest_dir),
            recursive=True,
            interactive=False,
            force=False,
            no_clobber=False,
            verbose=True,
            preserve=False,
            target_directory=None,
            no_target_directory=False,
            parents=False,
        )
        await run(args)
        assert await (dest_dir / "file1.txt").a_exists()
        assert await (dest_dir / "file2.txt").a_exists()
