"""
qrtdb — Official Python client for QRTdb
=========================================
By Quorta Software Foundation · Est. 2026

    from qrtdb import QRT

    # Master key — manage databases
    master = QRT("http://server:8000", api_key="qrt-...")
    scoped_key = master.create_database("myapp")

    # Scoped key — use a specific database
    db = QRT("http://server:8000", api_key=scoped_key)
    db.create_table("users")
    db.insert("users", {"name": "Alex", "age": 17})
    records = db.select("users", where={"name": "Alex"})

Contact: qsdk_app_team.info@yahoo.com
Source:  QBit_Safe (coming soon)
"""

from .client import QRT
from .exceptions import (
    QRTError,
    AuthError,
    RateLimitError,
    QueryError,
    ConnectionError,
    NotFoundError,
)

__version__ = "2.0.0"
__author__  = "Quorta Software Foundation"
__email__   = "qsdk_app_team.info@yahoo.com"

__all__ = [
    "QRT",
    "QRTError",
    "AuthError",
    "RateLimitError",
    "QueryError",
    "ConnectionError",
    "NotFoundError",
]
