"""qrtdb.exceptions — all exceptions raised by the QRTdb client."""

class QRTError(Exception):
    """Base exception."""

class AuthError(QRTError):
    """Invalid, missing, or revoked API key."""

class RateLimitError(QRTError):
    """Server rate limit exceeded."""

class QueryError(QRTError):
    """Query failed — bad syntax, missing table, etc."""

class ConnectionError(QRTError):
    """Server unreachable."""

class NotFoundError(QRTError):
    """Resource not found."""
