"""
qrtdb.client
------------
Official Python client for QRTdb v2.
Matches the sector-based QRTdb server with scoped keys per database.

Usage:
    from qrtdb import QRT

    # Connect with master key
    db = QRT("http://your-server:8000", api_key="qrt-...")

    # Create a database (returns scoped key)
    scoped_key = db.create_database("myapp")

    # Connect with scoped key (no need to pass db= on every query)
    app = QRT("http://your-server:8000", api_key=scoped_key)
    app.create_table("users")
    app.insert("users", {"name": "Alex", "age": 17})
    app.select("users", where={"name": "Alex"})
    app.delete("users", where={"name": "Alex"})
"""

import os
from typing import Any, Dict, List, Optional

try:
    import requests
except ImportError:
    raise ImportError("qrtdb requires 'requests'. Run: pip install requests")

from .exceptions import (
    AuthError, RateLimitError, QueryError,
    ConnectionError, NotFoundError, QRTError,
)

__all__ = ["QRT"]


class QRT:
    """
    QRTdb Python client.

    Parameters
    ----------
    url : str
        Base URL of your QRTdb server.
        e.g. "http://localhost:8000" or "https://your.ngrok.app"
    api_key : str
        Your API key (master or scoped). Can also be set via QRT_API_KEY env var.
    database : str, optional
        Database name. Required only when using a master key (*).
        Scoped keys already know their database.
    timeout : int
        Request timeout in seconds. Default: 10.
    """

    def __init__(
        self,
        url:      str,
        api_key:  Optional[str] = None,
        database: Optional[str] = None,
        timeout:  int           = 10,
    ):
        self.url      = url.rstrip("/")
        self.api_key  = api_key or os.environ.get("QRT_API_KEY", "")
        self.database = database
        self.timeout  = timeout

        if not self.api_key:
            raise AuthError(
                "No API key. Pass api_key= or set QRT_API_KEY environment variable."
            )

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _headers(self) -> Dict[str, str]:
        return {
            "X-API-Key":    self.api_key,
            "Content-Type": "application/json",
        }

    def _post(self, endpoint: str, payload: dict) -> dict:
        try:
            r = requests.post(
                self.url + endpoint,
                json=payload,
                headers=self._headers(),
                timeout=self.timeout,
            )
        except requests.exceptions.ConnectionError:
            raise ConnectionError(f"Cannot reach QRTdb server at {self.url}.")
        except requests.exceptions.Timeout:
            raise ConnectionError(f"Server timed out after {self.timeout}s.")
        return self._handle(r)

    def _get(self, endpoint: str, params: dict = None) -> dict:
        try:
            r = requests.get(
                self.url + endpoint,
                headers=self._headers(),
                params=params,
                timeout=self.timeout,
            )
        except requests.exceptions.ConnectionError:
            raise ConnectionError(f"Cannot reach QRTdb server at {self.url}.")
        return self._handle(r)

    def _handle(self, response) -> dict:
        if response.status_code == 401:
            raise AuthError("Invalid or missing API key.")
        if response.status_code == 403:
            raise AuthError("API key revoked or forbidden.")
        if response.status_code == 429:
            raise RateLimitError("Rate limit exceeded. Slow down!")
        if response.status_code == 404:
            raise NotFoundError("Endpoint not found.")
        try:
            data = response.json()
        except Exception:
            raise QRTError(f"Non-JSON response: {response.text[:200]}")
        if not data.get("ok"):
            raise QueryError(data.get("error", "Unknown server error."))
        return data

    def _query(self, q: str) -> dict:
        payload = {"q": q}
        if self.database:
            payload["db"] = self.database
        return self._post("/query", payload)

    # ── Health ────────────────────────────────────────────────────────────────

    def ping(self) -> bool:
        """
        Check if the server is reachable.
        Returns True if alive, raises ConnectionError if not.
        """
        try:
            r = requests.get(self.url + "/ping", timeout=self.timeout)
            return r.json().get("ok", False)
        except Exception:
            raise ConnectionError(f"Cannot reach QRTdb server at {self.url}.")

    # ── Account / database management ─────────────────────────────────────────

    def create_database(self, name: str) -> str:
        """
        Create a new database and return its scoped API key.
        Use the scoped key to connect directly to that database.

        >>> scoped_key = db.create_database("myapp")
        >>> app = QRT("http://server:8000", api_key=scoped_key)
        """
        data = self._post("/db/create", {"name": name})
        return data["api_key"]

    def list_databases(self) -> List[str]:
        """List all your databases."""
        return self._get("/db/list").get("databases", [])

    def list_keys(self) -> List[dict]:
        """List all your active API keys and which database each covers."""
        return self._get("/keys").get("keys", [])

    def revoke_key(self, api_key: str) -> bool:
        """Revoke an API key permanently."""
        self._post("/revoke", {"api_key": api_key})
        return True

    # ── Table operations ──────────────────────────────────────────────────────

    def create_table(self, table: str) -> bool:
        """
        Create a table in the current database.

        >>> db.create_table("users")
        True
        """
        self._query(f"CREATE TABLE {table}")
        return True

    def drop_table(self, table: str) -> bool:
        """Drop a table and all its records permanently."""
        self._query(f"DROP TABLE {table}")
        return True

    def list_tables(self) -> List[str]:
        """List all tables in the current database."""
        params = {"db": self.database} if self.database else {}
        return self._get("/tables", params=params).get("tables", [])

    def stats(self, table: str) -> dict:
        """
        Get stats for a table: record count, sector count, file sizes.

        >>> db.stats("users")
        {"table": "users", "record_count": 42, "sector_count": 9, ...}
        """
        return self._query(f"STATS {table}")

    # ── Record operations ─────────────────────────────────────────────────────

    def insert(self, table: str, data: Dict[str, Any]) -> dict:
        """
        Insert a record.

        >>> db.insert("users", {"name": "Alex", "age": 17, "city": "Kolkata"})
        {"ok": True, "id": 1, "record": {...}}
        """
        fields = ", ".join(f"{k}={v}" for k, v in data.items())
        return self._query(f"INSERT INTO {table} ({fields})")

    def select(
        self,
        table: str,
        where: Optional[Dict[str, Any]] = None,
    ) -> List[dict]:
        """
        Select records. Uses the field index for WHERE queries (fast).

        >>> db.select("users")
        >>> db.select("users", where={"city": "Kolkata"})
        """
        if where:
            k, v = next(iter(where.items()))
            q = f"SELECT FROM {table} WHERE {k}={v}"
        else:
            q = f"SELECT FROM {table}"
        return self._query(q).get("records", [])

    def delete(
        self,
        table: str,
        where: Dict[str, Any],
    ) -> int:
        """
        Delete records matching where clause. Uses index for fast lookup.
        Returns number of deleted records.

        >>> db.delete("users", where={"name": "Alex"})
        1
        >>> db.delete("users", where={"id": 1})
        1
        """
        k, v = next(iter(where.items()))
        return self._query(f"DELETE FROM {table} WHERE {k}={v}").get("deleted", 0)

    # ── Repr ──────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        db = f", db={self.database!r}" if self.database else ""
        return f"QRT(url={self.url!r}, key={self.api_key[:14]}...{db})"
