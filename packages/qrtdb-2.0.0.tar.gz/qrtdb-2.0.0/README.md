# qrtdb — Python Client v2.0

Official Python client for **QRTdb** by Quorta Software Foundation.

QRTdb is a self-hosted portable database — sector-based storage, field index for fast lookups, HTTP API.

## Install

```bash
pip install qrtdb
```

## Quick Start

```python
from qrtdb import QRT

# Step 1 — Connect with master key
master = QRT("http://your-server:8000", api_key="qrt-...")

# Step 2 — Create a database (returns scoped key)
scoped_key = master.create_database("myapp")

# Step 3 — Connect with scoped key (no db= needed on every query)
db = QRT("http://your-server:8000", api_key=scoped_key)

# Step 4 — Use it
db.create_table("users")
db.insert("users", {"name": "Alex", "age": 17, "city": "Kolkata"})
db.select("users")                          # all records
db.select("users", where={"city": "Kolkata"})  # indexed lookup
db.delete("users", where={"name": "Alex"})
db.stats("users")
db.list_tables()
db.drop_table("users")
```

## Storage Format

QRTdb stores data in `.qrt` sector files — not JSON, not SQL, not SQLite.

```
[SECTOR:0]
{"id":1,"name":"Alex","age":"17","city":"Kolkata"}
{"id":2,"name":"Rahul","age":"16","city":"Delhi"}
[SECTOR:1]
{"id":3,"name":"Sara","age":"15","city":"Mumbai"}
...
```

Field index (`.idx`) enables O(1) WHERE lookups:
```
name=Alex    → 0,0
city=Kolkata → 0,0
id=1         → 0,0
```

## Master Key vs Scoped Key

```python
# Master key — full account access
master = QRT(url, api_key="qrt-master-...")
master.create_database("myapp")   # → returns scoped key
master.list_databases()
master.list_keys()

# Scoped key — one database only, use for apps
db = QRT(url, api_key="qrt-scoped-...")
db.insert("users", {...})   # no db= needed
```

## Error Handling

```python
from qrtdb import QRT, AuthError, QueryError, ConnectionError

try:
    db.select("nonexistent")
except QueryError as e:
    print("Query failed:", e)
except AuthError as e:
    print("Bad API key:", e)
except ConnectionError as e:
    print("Server unreachable:", e)
```

## Other Languages

QRTdb is HTTP — use it from any language:

```javascript
// JavaScript
const res = await fetch("http://server:8000/query", {
  method: "POST",
  headers: { "Content-Type": "application/json", "X-API-Key": "qrt-..." },
  body: JSON.stringify({ q: "SELECT FROM users" })
});
```

```go
// Go
body, _ := json.Marshal(map[string]string{"q": "SELECT FROM users"})
req, _  := http.NewRequest("POST", "http://server:8000/query", bytes.NewBuffer(body))
req.Header.Set("X-API-Key", "qrt-...")
```

```rust
// Rust
client.post("http://server:8000/query")
    .header("X-API-Key", "qrt-...")
    .json(&json!({"q": "SELECT FROM users"}))
    .send().await?;
```

## About QSF

**Quorta Software Foundation** — Non-profit · Est. 2026 · Closed Source · Members & Founders Only

| Product | Status |
|---------|--------|
| QRTdb | ✅ Live |
| QRTOS | ⚡ In Dev |
| QSDK  | ⚡ In Dev |
| QDNS  | ◌ Planned |
| QBit_Safe | ◌ Planned |

📧 qsdk_app_team.info@yahoo.com
