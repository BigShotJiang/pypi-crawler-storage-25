import argparse
import sys
import unittest

from deephaven_enterprise.client.session_manager import SessionManager

parser = argparse.ArgumentParser(
    description="Run GetPQScriptTestCase with required parameters."
)
parser.add_argument(
    "--host",
    required=True,
    help="Server host, eg: --host qa-grizzly-java17-cluster-infra-1.int.illumon.com",
)
parser.add_argument(
    "--port", type=int, required=True, help="Server port, eg: --port 8000"
)
parser.add_argument("--user", required=True, help="Username, eg. --user iris")
parser.add_argument("--passwd", required=True, help="Password, eg. --passwd iris")
parser.add_argument(
    "--git-script-pq",
    required=True,
    help="PQ name with script in git repo, eg. DH-20631-PG-Git",
)

parser.add_argument(
    "--nongit-script-pq",
    required=True,
    help="PQ name with script embedded in config, eg. DH-20631-PG-NoGit",
)
args, remaining_argv = parser.parse_known_args()
sys.argv = [sys.argv[0]] + remaining_argv


class GetPQScriptTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.host = args.host
        cls.port = args.port
        cls.user = args.user
        cls.passwd = args.passwd
        cls.git_script_pq = args.git_script_pq
        cls.nongit_script_pq = args.nongit_script_pq

    def setUp(self):
        self.session_manager = SessionManager(
            f"https://{self.host}:{self.port}/iris/connection.json"
        )
        self.session_manager.password(self.user, self.passwd)
        self.controller_client = self.session_manager.controller_client

    def tearDown(self):
        self.controller_client.close()
        self.session_manager.close()

    def test_non_git(self):
        pq_name = self.nongit_script_pq
        pq_serial = self.controller_client.get_serial_for_name(pq_name)
        self.assertTrue(self.controller_client.fetch_script(pq_name))
        self.assertEqual(
            self.controller_client.fetch_script(pq_name),
            self.controller_client.fetch_script(pq_serial),
        )

    def test_git(self):
        pq_name = self.git_script_pq
        pq_serial = self.controller_client.get_serial_for_name(pq_name)
        self.assertTrue(self.controller_client.fetch_script(pq_name))
        self.assertEqual(
            self.controller_client.fetch_script(pq_name),
            self.controller_client.fetch_script(pq_serial),
        )

    def test_enumerate_pqs(self):
        self.assertGreater(len(self.controller_client.map()), 0)

    def test_fetch_scripts(self):
        scripts = self.controller_client.fetch_scripts()
        self.assertGreater(len(scripts), 0)
        for pq_serial, script in scripts.items():
            self.assertGreater(pq_serial, 0, f"Invalid serial: {pq_serial}")
            self.assertTrue(script)


if __name__ == "__main__":
    unittest.main()
