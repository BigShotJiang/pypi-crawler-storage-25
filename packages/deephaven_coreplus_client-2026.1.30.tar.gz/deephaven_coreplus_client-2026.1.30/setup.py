#
#  Copyright (c) 2016-2025 Deephaven Data Labs and Patent Pending
#
import os

from setuptools import setup


def get_project_info(for_sphinx: bool = False) -> dict[str, str]:
    """Placeholder for get_project_info"""
    return {}


if os.environ.get("DH_FROM_BUILD_DIR", None):
    project_info_module = "../../src/main/py/project_info.py"
else:
    project_info_module = "../project_info.py"
exec(open(project_info_module).read())

project_info = get_project_info()

setup(
    name="deephaven-coreplus-client",
    version=project_info["version"],
    description="The Deephaven Enterprise Core+ Python Client",
    long_description=project_info["readme"],
    long_description_content_type="text/markdown",
    packages=[
        "deephaven_enterprise.client",
        "deephaven_enterprise.proto",
        "deephaven_enterprise.deephaven_internal",
    ],
    package_dir={
        "deephaven_enterprise.client": project_info["client_dir"],
        "deephaven_enterprise.proto": project_info["proto_dir"],
        "deephaven_enterprise.deephaven_internal": project_info["internal_dir"],
    },
    url="https://deephaven.io/",
    license="Deephaven Enterprise License Agreement",
    author="Deephaven Data Labs",
    author_email="python@deephaven.io",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
    ],
    python_requires=">=3.10",
    install_requires=[
        "pydeephaven==" + project_info["dhc_version"],
        "pycryptodomex>=3.19.0",
        "pycryptodome>=3.19.0",
        "grpcio>=1.76.0",
        "urllib3",
        "requests",
    ],
    package_data={
        "deephaven_enterprise.client": ["py.typed"],
        "deephaven_enterprise.deephaven_internal": ["py.typed"],
    },
)
