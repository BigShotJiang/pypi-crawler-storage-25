"""Integration tests for severity filter + export correctness.

Validates that after _apply_filters() shrinks self.V_all, both
_export_detailed_solution() and _export_minimal_solution() still
look up the correct vulnerability by its *original* SARIF index,
not by list position.

Test data (test_data.sarif — 5 vulns, 3 severity levels):
  idx 0  java/XSS           error   → HIGH
  idx 1  java/XSS           error   → HIGH
  idx 2  java/PT            warning → MEDIUM
  idx 3  javascript/DOMXSS  note    → LOW
  idx 4  java/PT            warning → MEDIUM
"""

import json
from pathlib import Path
from unittest.mock import patch, Mock

import pytest

from codeflow_solver.solver.set_cover_solver import SarifSetCoverSolver
from codeflow_solver.utils.data_structures import FixLocation
from codeflow_solver.utils.severity_mapper import IssueSeverity


SARIF_PATH = str(Path(__file__).parent.parent / "data" / "test_data.sarif")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _build_solver(severity_filter=None, export_detailed=True, minimal_export=False):
    """Create a solver, run steps 1-2, and return it."""
    solver = SarifSetCoverSolver(
        SARIF_PATH,
        severity_filter=severity_filter or [],
        export_detailed=export_detailed,
        minimal_export=minimal_export,
        quiet=True,
    )
    solver.step1_construct_mathematical_sets()
    solver.step2_partition_sets_by_vulnerability_type()
    return solver


def _export_detailed(solver, tmp_path):
    """Run _export_detailed_solution() and return the parsed JSON."""
    solver.sarif_file_path = str(tmp_path / "test.sarif")
    solver._export_detailed_solution()
    with open(tmp_path / "test_optimal_fix_path.json") as f:
        return json.load(f)


def _export_minimal(solver, tmp_path):
    """Run _export_minimal_solution() and return the parsed JSON."""
    solver.sarif_file_path = str(tmp_path / "test.json")
    solver._export_minimal_solution()
    with open(tmp_path / "test_minimal_fix_path.json") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# tests
# ---------------------------------------------------------------------------

class TestSeverityFilterExport:
    """Regression tests for the severity-filter index-mismatch bug."""

    # -- basic filter behaviour -----------------------------------------

    def test_filter_reduces_vulnerability_list(self):
        """Only matching-severity vulns survive filtering."""
        solver_high = _build_solver(severity_filter=["high"])
        solver_medium = _build_solver(severity_filter=["medium"])
        solver_all = _build_solver()

        assert len(solver_all.V_all) == 5
        assert len(solver_high.V_all) == 2  # vulns 0, 1
        assert len(solver_medium.V_all) == 2  # vulns 2, 4

    def test_filtered_vulnerabilities_keep_original_indices(self):
        """After filtering, vuln.index still holds the original SARIF index."""
        solver = _build_solver(severity_filter=["medium"])
        indices = {v.index for v in solver.V_all}
        # medium vulns are at original SARIF indices 2 and 4
        assert indices == {2, 4}

    # -- _export_detailed_solution() ------------------------------------

    def test_detailed_export_contains_vulnerability_details(self, tmp_path):
        """Fix locations that cover filtered vulns should have non-empty details.

        Before the fix, vuln_by_index lookup missed filtered vulns and
        produced empty vulnerability_details lists.
        """
        solver = _build_solver(severity_filter=["high"])

        # Mock optimisation results: one fix covering vuln 0
        solver.x_optimal_by_type = {
            "java/XSS": [
                FixLocation("Controller.java", 30, 25, {0, 1}),
            ],
        }

        result = _export_detailed(solver, tmp_path)
        fix_type = result["fixes_by_vulnerability_type"][0]
        details = fix_type["fix_locations"][0]["vulnerability_details"]
        assert len(details) > 0, "vulnerability_details must not be empty after filter"

    def test_detailed_export_rule_ids_match_type(self, tmp_path):
        """Every exported vulnerability detail must have a rule_id matching
        the surrounding vulnerability type section.

        Before the fix, original index 2 (java/PT) could be looked up via
        list position 2 in the filtered list, landing on a different vuln.
        """
        solver = _build_solver(severity_filter=["medium"])

        # vulns 2 and 4 are java/PT
        solver.x_optimal_by_type = {
            "java/PT": [
                FixLocation("FileHandler.java", 12, 25, {2, 4}),
            ],
        }

        result = _export_detailed(solver, tmp_path)
        for fix_type in result["fixes_by_vulnerability_type"]:
            expected_rule = fix_type["vulnerability_type"]
            for loc in fix_type["fix_locations"]:
                for detail in loc["vulnerability_details"]:
                    assert detail["rule_id"] == expected_rule, (
                        f"Expected rule_id '{expected_rule}', "
                        f"got '{detail['rule_id']}'"
                    )

    def test_detailed_export_severity_matches_filter(self, tmp_path):
        """All exported vulnerability details must have a severity that
        matches the active filter."""
        solver = _build_solver(severity_filter=["high"])

        solver.x_optimal_by_type = {
            "java/XSS": [
                FixLocation("Controller.java", 30, 25, {0, 1}),
            ],
        }

        result = _export_detailed(solver, tmp_path)
        for fix_type in result["fixes_by_vulnerability_type"]:
            for loc in fix_type["fix_locations"]:
                for detail in loc["vulnerability_details"]:
                    assert detail["severity"] == "high"

    # -- _export_minimal_solution() -------------------------------------

    def test_minimal_export_coverage_counts_nonzero(self, tmp_path):
        """Minimal export must report >0 coverage for locations that cover
        filtered vulns.

        Before the fix, V_t was built with enumerate positions, so the
        intersection with covered_vulnerabilities (which uses original
        indices) was empty → coverage = 0.
        """
        solver = _build_solver(severity_filter=["medium"], minimal_export=True)

        solver.x_optimal_by_type = {
            "java/PT": [
                FixLocation("FileHandler.java", 12, 25, {2, 4}),
            ],
        }

        result = _export_minimal(solver, tmp_path)
        pt_type = next(
            t for t in result["optimal_fixes_by_type"]
            if t["vulnerability_type"] == "java/PT"
        )
        top_fix = pt_type["top_fixes"][0]
        assert top_fix["vulnerabilities_covered"] == 2

    def test_minimal_export_partial_coverage(self, tmp_path):
        """A fix that covers only 1 of 2 vulns of a type should report 1."""
        solver = _build_solver(severity_filter=["medium"], minimal_export=True)

        solver.x_optimal_by_type = {
            "java/PT": [
                FixLocation("FileHandler.java", 12, 25, {2}),  # only vuln 2
            ],
        }

        result = _export_minimal(solver, tmp_path)
        pt_type = next(
            t for t in result["optimal_fixes_by_type"]
            if t["vulnerability_type"] == "java/PT"
        )
        top_fix = pt_type["top_fixes"][0]
        assert top_fix["vulnerabilities_covered"] == 1

    # -- regression guard -----------------------------------------------

    def test_unfiltered_export_still_works(self, tmp_path):
        """Without any filter the export path must remain correct."""
        solver = _build_solver()

        solver.x_optimal_by_type = {
            "java/XSS": [FixLocation("Controller.java", 30, 25, {0, 1})],
            "java/PT": [FixLocation("FileHandler.java", 12, 25, {2, 4})],
            "javascript/DOMXSS": [FixLocation("app.js", 25, 5, {3})],
        }

        result = _export_detailed(solver, tmp_path)

        # Every section should have the right rule_ids
        for fix_type in result["fixes_by_vulnerability_type"]:
            expected_rule = fix_type["vulnerability_type"]
            for loc in fix_type["fix_locations"]:
                for detail in loc["vulnerability_details"]:
                    assert detail["rule_id"] == expected_rule
