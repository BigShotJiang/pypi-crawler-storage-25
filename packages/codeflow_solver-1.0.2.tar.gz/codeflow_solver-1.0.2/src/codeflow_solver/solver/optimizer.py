"""
OR-Tools optimizer for set cover problems.
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, List, Set

from ..utils.data_structures import FixLocation

# OR-Tools imports for mathematical optimization
try:
    from ortools.linear_solver import pywraplp
    from ortools.sat.python import cp_model

    HAS_ORTOOLS = True
except ImportError:
    HAS_ORTOOLS = False


class SolverType(Enum):
    """Enumeration of available solver types."""
    SCIP = "scip"
    CP_SAT = "cp-sat"


class BaseSolver(ABC):
    """Base class for set cover solvers."""
    
    @abstractmethod
    def solve_single_set_cover_problem(
        self, vuln_type: str, V_t: Set[int], Sv_t: Dict[int, Set[int]], N_all: List[FixLocation]
    ) -> List[FixLocation]:
        """Solve set cover problem for a single vulnerability type."""
        pass


class SCIPSolver(BaseSolver):
    """SCIP-based solver for set cover problems using linear programming."""
    
    def solve_single_set_cover_problem(
        self, vuln_type: str, V_t: Set[int], Sv_t: Dict[int, Set[int]], N_all: List[FixLocation]
    ) -> List[FixLocation]:
        """Solve using SCIP linear programming solver."""
        if not V_t or not Sv_t:
            print(f"  No data for {vuln_type}")
            return []

        print(f"  |V_t| = {len(V_t)} vulnerabilities, |N_t| = {len(Sv_t)} fix locations")

        # Create OR-Tools SCIP solver for integer linear programming
        solver = pywraplp.Solver.CreateSolver("SCIP")
        if not solver:
            print(f"  ERROR: SCIP solver unavailable for {vuln_type}")
            return []

        # Decision variables: xᵢ ∈ {0,1} for each fix location nᵢ ∈ N_t
        x = {}  # x[i] represents xᵢ in mathematical notation
        for location_index in Sv_t.keys():
            x[location_index] = solver.IntVar(0, 1, f"x_{location_index}")

        # Coverage constraints: ∀vⱼ ∈ V_t, Σ(xᵢ: vⱼ ∈ Sᵥ_t(nᵢ)) ≥ 1
        print(f"  Creating coverage constraints for {len(V_t)} vulnerabilities...")
        for vuln_j in V_t:
            # Find all fix locations nᵢ that can cover vulnerability vⱼ
            covering_locations = []
            for location_i, Sv_t_ni in Sv_t.items():
                if vuln_j in Sv_t_ni:  # if vⱼ ∈ Sᵥ_t(nᵢ)
                    covering_locations.append(location_i)

            # Create constraint: Σ(xᵢ: vⱼ ∈ Sᵥ_t(nᵢ)) ≥ 1
            if covering_locations:
                constraint = solver.Constraint(1, solver.infinity())
                for location_i in covering_locations:
                    constraint.SetCoefficient(x[location_i], 1)

        # Objective function: Minimize Σxᵢ (minimize number of selected fix locations)
        objective = solver.Objective()
        for location_index in Sv_t.keys():
            objective.SetCoefficient(x[location_index], 1)
        objective.SetMinimization()

        # Solve the optimization problem
        print("  Solving integer linear program...")
        status = solver.Solve()

        # Extract optimal solution
        if status == pywraplp.Solver.OPTIMAL:
            optimal_locations = []
            for location_i, xi_var in x.items():
                if xi_var.solution_value() > 0.5:  # xᵢ = 1 (location selected)
                    optimal_locations.append(N_all[location_i])

            print(f"  ✓ OPTIMAL: {len(optimal_locations)} fix locations needed")
            return optimal_locations
        else:
            print(f"  ✗ No optimal solution found for {vuln_type}")
            return []


class CPSATSolver(BaseSolver):
    """CP-SAT-based solver for set cover problems using constraint programming."""
    
    def solve_single_set_cover_problem(
        self, vuln_type: str, V_t: Set[int], Sv_t: Dict[int, Set[int]], N_all: List[FixLocation]
    ) -> List[FixLocation]:
        """Solve using CP-SAT constraint programming solver."""
        if not V_t or not Sv_t:
            print(f"  No data for {vuln_type}")
            return []

        print(f"  |V_t| = {len(V_t)} vulnerabilities, |N_t| = {len(Sv_t)} fix locations")

        # Create CP-SAT model
        model = cp_model.CpModel()
        
        # Decision variables: xᵢ ∈ {0,1} for each fix location nᵢ ∈ N_t
        x = {}
        for location_index in Sv_t.keys():
            x[location_index] = model.NewBoolVar(f"x_{location_index}")

        # Coverage constraints: ∀vⱼ ∈ V_t, Σ(xᵢ: vⱼ ∈ Sᵥ_t(nᵢ)) ≥ 1
        print(f"  Creating coverage constraints for {len(V_t)} vulnerabilities...")
        for vuln_j in V_t:
            # Find all fix locations nᵢ that can cover vulnerability vⱼ
            covering_vars = []
            for location_i, Sv_t_ni in Sv_t.items():
                if vuln_j in Sv_t_ni:  # if vⱼ ∈ Sᵥ_t(nᵢ)
                    covering_vars.append(x[location_i])

            # Create constraint: Σ(xᵢ: vⱼ ∈ Sᵥ_t(nᵢ)) ≥ 1
            if covering_vars:
                model.Add(sum(covering_vars) >= 1)

        # Objective function: Minimize Σxᵢ (minimize number of selected fix locations)
        model.Minimize(sum(x[location_index] for location_index in Sv_t.keys()))

        # Create solver and solve
        solver = cp_model.CpSolver()
        print("  Solving constraint programming problem...")
        status = solver.Solve(model)

        # Extract optimal solution
        if status == cp_model.OPTIMAL:
            optimal_locations = []
            for location_i, xi_var in x.items():
                if solver.Value(xi_var):  # xᵢ = 1 (location selected)
                    optimal_locations.append(N_all[location_i])

            print(f"  ✓ OPTIMAL: {len(optimal_locations)} fix locations needed")
            return optimal_locations
        else:
            print(f"  ✗ No optimal solution found for {vuln_type}")
            return []


class SetCoverOptimizer:
    """
    Modular optimizer for set cover problems supporting multiple solvers.

    Solves the mathematical formulation:
    Variables: xᵢ ∈ {0,1} for each nᵢ ∈ N_t
    Objective: Minimize Σxᵢ
    Constraints: For each vⱼ ∈ V_t, Σ(xᵢ: vⱼ ∈ Sᵥ_t(nᵢ)) ≥ 1
    """

    def __init__(self, solver_type: SolverType = SolverType.SCIP):
        """Initialize the optimizer with the specified solver type.
        
        Args:
            solver_type: Type of solver to use (SCIP or CP_SAT)
        """
        if not HAS_ORTOOLS:
            raise ImportError("OR-Tools not available. Install with: pip install ortools")
            
        self.solver_type = solver_type
        self._create_solver()
    
    def _create_solver(self) -> None:
        """Create the appropriate solver instance based on solver type."""
        if self.solver_type == SolverType.SCIP:
            self.solver = SCIPSolver()
        elif self.solver_type == SolverType.CP_SAT:
            self.solver = CPSATSolver()
        else:
            raise ValueError(f"Unsupported solver type: {self.solver_type}")

    def solve_single_set_cover_problem(
        self, vuln_type: str, V_t: Set[int], Sv_t: Dict[int, Set[int]], N_all: List[FixLocation]
    ) -> List[FixLocation]:
        """Delegate to the underlying solver implementation."""
        return self.solver.solve_single_set_cover_problem(vuln_type, V_t, Sv_t, N_all)

    def solve_all_set_cover_problems(
        self, V_by_type: Dict[str, Set[int]], Sv_by_type: Dict[str, Dict[int, Set[int]]], N_all: List[FixLocation]
    ) -> Dict[str, List[FixLocation]]:
        """
        Solve set cover problems for all vulnerability types.

        Args:
            V_by_type: Vulnerability sets by type
            Sv_by_type: Coverage mappings by type
            N_all: Complete list of fix locations

        Returns:
            Dictionary mapping vulnerability type to optimal fix locations
        """
        print(f"\nSolving set cover optimization problems using {self.solver_type.value.upper()}...")

        x_optimal_by_type = {}

        for vuln_type in V_by_type:
            print(f"\nSolving set cover problem for vulnerability type: {vuln_type}")
            V_t, Sv_t = V_by_type[vuln_type], Sv_by_type[vuln_type]
            optimal_solution = self.solve_single_set_cover_problem(vuln_type, V_t, Sv_t, N_all)
            x_optimal_by_type[vuln_type] = optimal_solution

        return x_optimal_by_type
