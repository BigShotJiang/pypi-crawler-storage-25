import json
import time
import re
import os
import subprocess
import hashlib
from pathlib import Path
from typing import List, Dict, Any

from .git import get_git_diff

def fetch_proposed_commits(config: dict, requested_count: int | str, context: str = None, persona_override: str = None, model_override: str = None, optimize: bool = True, paths: List[str] = None) -> List[Dict[str, Any]]:
    """
    Sends git diff to configured AI provider and asks for `requested_count` logical commits.
    Checks local cache first to avoid redundant API calls.
    """
    provider = config.get("provider", "gemini").lower()
    api_key = os.environ.get("COMMITER_API_KEY") or config.get("api_key")
    persona_key = persona_override or config.get("persona", "senior dev").lower()
    
    # 1. Prepare Diff
    diff = get_git_diff(optimize=optimize, paths=paths)
    if not diff.strip():
        raise ValueError("No git diff output to analyze.")

    # 2. Check Cache
    cache_key = _get_cache_hash(diff, requested_count, persona_key, model_override or config.get("ollama_model", ""))
    cached_data = _load_from_cache(cache_key)
    if cached_data:
        # Check if we are in a TUI or CLI to maybe log this
        # For now, just return
        return cached_data

    # 3. Resolve Persona
    # Check for custom personas in config
    custom_personas = config.get("personas", {})
    if persona_key in custom_personas:
        persona_desc = f"{persona_key} format: {custom_personas[persona_key]}"
    elif "senior" in persona_key:
        persona_desc = "senior dev format: highly properly formatted, professional, correct, and strictly conventional."
    elif "junior" in persona_key:
        persona_desc = "junior dev format: less structured but highly, thoroughly detailed."
    else:
        persona_desc = "newbie format: concise, on-point, simple explanation without jargon, but strictly formatted as a real, short git commit message (not conversational)."
    
    if not api_key or api_key == "YOUR_API_KEY_HERE":
        raise ValueError(f"Please set your {provider.capitalize()} API key in ~/.commiter/config.toml")
        
    diff = get_git_diff(optimize=optimize, paths=paths)
    if not diff.strip():
        raise ValueError("No git diff output to analyze.")

    # Context window protection
    max_diff_chars = 1000000 if provider == "gemini" else 100000
    if len(diff) > max_diff_chars:
        diff = diff[:max_diff_chars] + "\n\n... [Git diff truncated: Change list is too large for AI context] ..."

    if str(requested_count).lower() == "auto":
        count_instruction = "group the changes into logical distinct commits. Determine the best, most appropriate number of commits to effectively and atomically represent the changes organically."
    else:
        count_instruction = f"group the changes into exactly {requested_count} logical commits. If ({requested_count}) is too small or too large, try to best group them logically without omitting any changed files."
        
    custom_prompt_file = Path.home() / ".commiter" / "custom_prompt.txt"
    custom_prompt_text = ""
    if custom_prompt_file.exists():
        try:
            with open(custom_prompt_file, "r", encoding="utf-8") as f:
                custom_prompt_text = f"\n\nCUSTOM USER PROMPT:\n{f.read().strip()}\n"
        except Exception:
            pass

    # Load project context from .git/.commiter_context if available
    project_context_text = ""
    try:
        import subprocess as _sp
        git_root = _sp.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5
        ).stdout.strip()
        if git_root:
            ctx_file = Path(git_root) / ".git" / ".commiter_context"
            if ctx_file.exists():
                project_context_text = f"\n\nPROJECT CONTEXT:\n{ctx_file.read_text(encoding='utf-8').strip()}\n"
    except Exception:
        pass

    context_str = f"\n\nADDITIONAL USER CONTEXT:\n{context}\n" if context else ""
        
    prompt = f"""You are an expert developer. Analyze the following git diff and {count_instruction}
    {context_str}
    {project_context_text}
    {custom_prompt_text}
    CRITICAL: You must use the {persona_desc}
    
Return a JSON array of objects, where each object has:
- `message`: A commit message summarizing the changes, crafted exactly as the {persona_key} persona would write it.
- `files`: A list of strings, containing the file paths involved in this commit.

Diff:
```
{diff}
```

Return ONLY valid JSON and nothing else. Do not use markdown blocks for the JSON.
"""

    max_retries = 3
    for attempt in range(max_retries):
        try:
            if provider == "gemini":
                result = _call_gemini(api_key, prompt, model_override)
            elif provider == "openai":
                result = _call_openai(api_key, prompt, model_override)
            elif provider == "anthropic":
                result = _call_anthropic(api_key, prompt, model_override)
            elif provider == "ollama":
                if not is_ollama_running():
                    raise ValueError("Ollama service is not running at http://localhost:11434. Please start it with 'ollama serve'.")
                result = _call_ollama(prompt, model_override or config.get("ollama_model"))
            else:
                raise ValueError(f"Unknown AI provider: {provider}")
            break # Success
        except Exception as e:
            error_str = str(e).lower()
            if attempt < max_retries - 1 and any(k in error_str for k in ["429", "quota", "limit", "too many requests"]):
                time.sleep(2 ** attempt)
                continue
            raise e

    # 4. Save to Cache
    if result:
        _save_to_cache(cache_key, result)
    return result



def condense_project_context(config: dict, raw_text: str) -> str:
    """
    Use the AI to summarize a long project description into 5-6 concise lines.
    Falls back to the raw text if AI call fails.
    """
    provider = config.get("provider", "gemini").lower()
    api_key = os.environ.get("COMMITER_API_KEY") or config.get("api_key")

    if not api_key or api_key == "YOUR_API_KEY_HERE":
        return raw_text  # No API key, store raw

    prompt = f"""Summarize the following project description into exactly 5-6 concise lines.
Focus on: what the project does, its main technology, and its primary purpose.
Write in clear, factual language suitable as context for an AI commit message generator.
Do NOT use bullet points. Just plain paragraphs.

Project Description:
{raw_text}

Return ONLY the summary, nothing else.
"""
    try:
        if provider == "gemini":
            result = _call_gemini(api_key, prompt, None)
            # _call_gemini returns parsed JSON which won't work for plain text.
            # Call the raw api directly for plain text.
            raise ValueError("Use raw call")
    except Exception:
        pass

    # Simple raw call for summarization
    try:
        if provider == "gemini":
            from google import genai
            client = genai.Client(api_key=api_key, http_options={'api_version': 'v1'})
            for model in ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash']:
                try:
                    resp = client.models.generate_content(model=model, contents=prompt)
                    return resp.text.strip()
                except Exception:
                    continue
        elif provider == "openai":
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            resp = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}]
            )
            return resp.choices[0].message.content.strip()
        elif provider == "anthropic":
            from anthropic import Anthropic
            client = Anthropic(api_key=api_key)
            resp = client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=500,
                messages=[{"role": "user", "content": prompt}]
            )
            return resp.content[0].text.strip()
        elif provider == "ollama":
            import ollama
            resp = ollama.generate(model=config.get("ollama_model", "llama3"), prompt=prompt, stream=False)
            return resp.get("response", raw_text).strip()
    except Exception:
        pass

    return raw_text  # Fallback: store raw text


def _parse_ai_response(text: str) -> List[Dict[str, Any]]:

    # strip markdown wrapping if present
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
        
    if text.endswith("```"):
        text = text[:-3]
        
    try:
        return json.loads(text.strip())
    except json.JSONDecodeError:
        # Fallback: extract JSON array using regex if AI added conversational text
        match = re.search(r"(\[[\s\S]*\])", text)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError as e:
                raise ValueError(f"Failed to parse extracted JSON array: {e}\nExtracted: {match.group(1)}")
        raise ValueError(f"Failed to parse AI response as JSON and no JSON array found. Response: {text}")

def _is_auth_error(e: Exception) -> bool:
    error_str = str(e).lower()
    return any(keyword in error_str for keyword in ["401", "403", "unauthorized", "invalid api key", "authentication", "permission denied"])

def _check_quota_error(e: Exception) -> None:
    error_str = str(e).lower()
    if any(keyword in error_str for keyword in ["429", "quota", "limit", "exhausted", "too many requests", "insufficient_quota"]):
        raise ValueError(f"API Usage Limit Reached: The AI provider returned a rate limit or quota error. (Details: {e})")
    if any(keyword in error_str for keyword in ["503", "high demand", "unavailable", "overloaded", "capacity", "service unavailable"]):
        raise ValueError(f"API Overloaded: The AI provider ({e}) is currently experiencing high demand. Exhausted all fallback models. Please try again later.")

def _call_gemini(api_key: str, prompt: str, model_override: str = None) -> List[Dict[str, Any]]:
    try:
        from google import genai
        # Force v1 API version which is generally more stable than v1beta
        client = genai.Client(api_key=api_key, http_options={'api_version': 'v1'})
    except ImportError:
        raise ValueError("Please install google-genai to use Gemini provider")
        
    # Known stable and available preview models
    models = [
        'gemini-2.5-flash',
        'gemini-2.5-pro',
        'gemini-2.5-flash-lite',
        'gemini-3-flash',
        'gemini-3.1-flash-lite',
        'gemini-3.1-pro',
        'gemini-2-flash',
        'gemini-2-flash-lite',
        'gemini-2.0-flash', 
        'gemini-1.5-flash', 
        'gemini-1.5-pro',
        'gemma-3-27b',
        'gemma-3-12b',
        'gemma-3-4b',
        'gemma-3-2b',
        'gemma-3-1b',
        'gemma-4-31b',
        'gemma-4-26b',
        'gemini-pro' # Legacy fallback
    ]
    if model_override:
        models = [model_override] + models
        
    last_error = None

    # Step 1: Try hardcoded reputable models in v1
    for model in models:
        try:
            response = client.models.generate_content(model=model, contents=prompt)
            return _parse_ai_response(response.text)
        except Exception as e:
            last_error = e
            if _is_auth_error(e):
                raise ValueError(f"Gemini API Auth Error: {e}")
            continue

    # Step 2: If all fail, try v1beta explicitly if we haven't already
    try:
        beta_client = genai.Client(api_key=api_key, http_options={'api_version': 'v1beta'})
        for model in models:
            try:
                response = beta_client.models.generate_content(model=model, contents=prompt)
                return _parse_ai_response(response.text)
            except Exception as e:
                last_error = e
                continue
    except Exception:
        pass

    # Step 3: Dynamic discovery (last resort)
    try:
        click_echo = __import__("click").echo
        click_echo("⚠️  Initial model attempts failed. Attempting dynamic model discovery...")
        
        # Try listing with both clients
        for test_client in [client, beta_client]:
            try:
                available_models = list(test_client.models.list())
                compatible = [
                    m.name for m in available_models 
                    if 'generateContent' in m.supported_methods and 'vision' not in m.name.lower()
                ]
                
                if compatible:
                    compatible.sort(key=lambda x: 0 if "flash" in x.lower() else 1)
                    for model_name in compatible:
                        clean_name = model_name.replace("models/", "")
                        try:
                            response = test_client.models.generate_content(model=clean_name, contents=prompt)
                            return _parse_ai_response(response.text)
                        except Exception as e:
                            last_error = e
                            continue
            except Exception:
                continue
    except Exception:
        pass

    _check_quota_error(last_error)
    raise last_error

def _call_openai(api_key: str, prompt: str, model_override: str = None) -> List[Dict[str, Any]]:
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
    except ImportError:
        raise ValueError("Please install openai to use OpenAI provider")
        
    models = ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo']
    if model_override:
        models = [model_override] + models
    last_error = None
    
    for model in models:
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}]
            )
            return _parse_ai_response(response.choices[0].message.content)
        except Exception as e:
            last_error = e
            if _is_auth_error(e):
                raise ValueError(f"OpenAI API Auth Error: {e}")
            continue
            
    _check_quota_error(last_error)
    raise last_error
        
def _call_anthropic(api_key: str, prompt: str, model_override: str = None) -> List[Dict[str, Any]]:
    try:
        from anthropic import Anthropic
        client = Anthropic(api_key=api_key)
    except ImportError:
         raise ValueError("Please install anthropic to use Anthropic provider")
         
    models = ['claude-3-7-sonnet-20250219', 'claude-3-5-haiku-20241022', 'claude-3-haiku-20240307']
    if model_override:
        models = [model_override] + models
    last_error = None
    
    for model in models:
        try:
            response = client.messages.create(
                model=model,
                max_tokens=4000,
                messages=[{"role": "user", "content": prompt}]
            )
            return _parse_ai_response(response.content[0].text)
        except Exception as e:
            last_error = e
            if _is_auth_error(e):
                raise ValueError(f"Anthropic API Auth Error: {e}")
            continue
            
    _check_quota_error(last_error)
    raise last_error

def is_ollama_running() -> bool:
    """Check if local Ollama server is responsive."""
    import http.client
    try:
        # Use a simple connection check to the default port
        conn = http.client.HTTPConnection("localhost", 11434, timeout=2)
        conn.request("GET", "/api/version")
        resp = conn.getresponse()
        return resp.status == 200
    except Exception:
        return False

def ensure_ollama_running() -> bool:
    """Ensure Ollama is running, starting it in background if necessary."""
    if is_ollama_running():
        return True
        
    try:
        # Launch ollama serve in background
        # On Windows, we need specific flags to detach from the parent console
        kwargs = {}
        if os.name == 'nt':
            # CREATE_NEW_PROCESS_GROUP = 0x00000200
            # DETACHED_PROCESS = 0x00000008
            kwargs['creationflags'] = 0x00000008 | 0x00000200
            
        subprocess.Popen(
            ["ollama", "serve"], 
            stdout=subprocess.DEVNULL, 
            stderr=subprocess.DEVNULL,
            **kwargs
        )
        return True
    except Exception:
        return False

def get_ollama_models() -> List[str]:
    """Fetch list of locally available Ollama models."""
    try:
        import ollama
        resp = ollama.list()
        
        # Handle different SDK return formats:
        # 1. New SDK: Object with .models attribute
        if hasattr(resp, 'models'):
             models_data = resp.models
        # 2. Dict-like: get('models')
        elif hasattr(resp, 'get'):
             models_data = resp.get('models', [])
        # 3. Direct list
        elif isinstance(resp, list):
             models_data = resp
        else:
             models_data = []
             
        names = []
        for m in models_data:
            # Handle object-like model item
            if hasattr(m, 'model'):
                names.append(m.model)
            elif hasattr(m, 'name'):
                names.append(m.name)
            # Handle dict-like model item
            elif hasattr(m, 'get'):
                names.append(m.get('model', m.get('name', '')))
            # Handle string
            elif isinstance(m, str):
                names.append(m)
        return [n for n in names if n]
    except Exception:
        return []

def post_process_commits(proposed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Apply 'One file, one commit' rule.
    Ensures each file appears in only the first commit that claims it.
    Removes empty commits.
    """
    seen_files = set()
    deduplicated = []
    
    for commit in proposed:
        msg = commit.get("message", "")
        files = commit.get("files", [])
        
        # Only keep files we haven't seen yet
        unique_files = [f for f in files if f not in seen_files]
        
        if unique_files:
            deduplicated.append({
                "message": msg,
                "files": unique_files
            })
            seen_files.update(unique_files)
            
    return deduplicated

def _call_ollama(prompt: str, model: str = None) -> List[Dict[str, Any]]:
    """Call local Ollama instance."""
    try:
        import ollama
    except ImportError:
        raise ValueError("Please install 'ollama' python package to use Ollama provider")
        
    target_model = model or "llama3:latest"
    try:
        response = ollama.generate(model=target_model, prompt=prompt, stream=False)
        return _parse_ai_response(response.get('response', ''))
    except Exception as e:
        raise RuntimeError(f"Ollama generation failed: {e}")

def validate_api_key(provider: str, api_key: str) -> bool:
    """Proactively validate API key by making a lightweight request."""
    if not api_key or api_key == "YOUR_API_KEY_HERE":
        return False
        
    try:
        if provider == "gemini":
            from google import genai
            client = genai.Client(api_key=api_key)
            # List models as a health check
            list(client.models.list())
            return True
        elif provider == "openai":
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            client.models.list()
            return True
        elif provider == "anthropic":
            from anthropic import Anthropic
            client = Anthropic(api_key=api_key)
            client.models.list()
            return True
        elif provider == "ollama":
            return is_ollama_running()
    except Exception:
        return False
    return False

# --- Caching Infrastructure ---

CACHE_DIR = Path.home() / ".commiter" / "cache"

def _get_cache_hash(diff: str, count: str|int, persona: str, model: str) -> str:
    combined = f"{diff}|{count}|{persona}|{model}"
    return hashlib.sha256(combined.encode('utf-8')).hexdigest()

def _load_from_cache(key: str) -> List[Dict[str, Any]] | None:
    cache_path = CACHE_DIR / f"{key}.json"
    if cache_path.exists():
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, Exception):
            cache_path.unlink(missing_ok=True)
            return None
    return None

def _save_to_cache(key: str, data: List[Dict[str, Any]]) -> None:
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cache_path = CACHE_DIR / f"{key}.json"
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(data, f)
        _prune_cache()
    except Exception:
        pass

def _prune_cache(max_files: int = 50) -> None:
    """Keep only the most recent N cache files."""
    try:
        files = list(CACHE_DIR.glob("*.json"))
        if len(files) > max_files:
            # Sort by modification time (oldest first)
            files.sort(key=lambda x: x.stat().st_mtime)
            for f in files[:len(files) - max_files]:
                f.unlink()
    except Exception:
        pass
