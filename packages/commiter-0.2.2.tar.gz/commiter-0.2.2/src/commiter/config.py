import sys
from pathlib import Path

try:
    import tomli
except ImportError:
    pass

import tomli_w

CONFIG_DIR = Path.home() / ".commiter"
CONFIG_FILE = CONFIG_DIR / "config.toml"

DEFAULT_CONFIG = {
    "provider": "gemini",
    "api_key": "YOUR_API_KEY_HERE",
    "persona": "senior dev",
    "personas": {}
}

def load_or_create_config(config_path: str = None) -> dict:
    """Load config file, or create with default values if it doesn't exist."""
    path = Path(config_path) if config_path else CONFIG_FILE
    if not path.exists():
        save_config(DEFAULT_CONFIG, config_path=config_path)
        return DEFAULT_CONFIG
    
    with open(path, "rb") as f:
        if sys.version_info >= (3, 11):
            import tomllib
            return tomllib.load(f)
        else:
            return tomli.load(f)

def save_config(config: dict, config_path: str = None) -> None:
    """Save the given config dictionary to the TOML config file with restricted permissions."""
    import os
    path = Path(config_path) if config_path else CONFIG_FILE
    parent_dir = path.parent
    parent_dir.mkdir(parents=True, exist_ok=True)
    
    # Restrict directory permissions on Unix
    if os.name != 'nt':
        try:
            os.chmod(parent_dir, 0o700)
        except OSError:
            pass
            
    with open(path, "wb") as f:
        tomli_w.dump(config, f)
        
    # Restrict file permissions on Unix
    if os.name != 'nt':
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
