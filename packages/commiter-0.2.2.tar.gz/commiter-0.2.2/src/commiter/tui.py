import asyncio
from typing import List, Dict, Any, Callable, Optional

from textual import on, work, events
from textual.binding import Binding
from textual.command import Provider, Hit, Hits
from textual.app import App, ComposeResult
from textual.screen import Screen, ModalScreen
from textual.widgets import (
    Header,
    Footer,
    DataTable,
    Input,
    Button,
    Static,
    LoadingIndicator,
    ListView,
    ListItem,
    Label,
    RichLog,
    ProgressBar,
    SelectionList,
)
from textual.containers import Vertical, Horizontal, Center, Container

from .git import get_changed_files, execute_commit, execute_push, has_unmerged_paths
from .ai import fetch_proposed_commits, post_process_commits


class DigitOnlyInput(Input):
    """Input that lets non-digit printable keys bubble up to Screen bindings.

    Textual's Input calls event.stop() for ALL printable keys (even rejected
    ones), so Screen-level bindings like A/R/F/I never fire while Input has
    focus. We override _on_key: if the character is a non-digit letter/symbol
    (which this input rejects anyway), we return WITHOUT calling super() or
    event.stop(), so the event continues to bubble up to the Screen.
    """

    async def _on_key(self, event: events.Key) -> None:
        # event.character is non-None only for printable characters.
        # For digits and 'a': let Input handle normally.
        # For all other characters (letters, symbols): bubble to Screen.
        if event.character is not None:
            char = event.character.lower()
            if not (char.isdigit() or char == "a"):
                return  # no event.stop() → event bubbles up
        await super()._on_key(event)


def format_status(status: str) -> str:
    status = status.strip()
    if status == "M":
        return "[bold blue]M[/bold blue]"
    elif status == "A":
        return "[bold green]A[/bold green]"
    elif status == "D":
        return "[bold red]D[/bold red]"
    elif status == "??":
        return "[bold yellow]?[/bold yellow]"
    return f"[{status}]"


class MainScreen(Screen):
    """The main screen showing diffs and asking for commit count."""

    BINDINGS = [
        Binding("q", "app.exit", "Quit"),
        Binding("escape", "app.exit", "Quit"),
        Binding("ctrl+c", "app.exit", "Quit"),
        Binding("r", "refresh", "Refresh", priority=True),
        Binding("a", "auto_group", "Auto Group", priority=True),
        Binding("tab", "focus_next", "Next Field", show=False),
        Binding("shift+tab", "focus_previous", "Prev Field", show=False),
        Binding("f", "focus_files", "Focus Files", priority=True),
        Binding("i", "focus_input", "Focus Input", priority=True),
    ]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Container(id="main-content"):
            yield Static(
                "[bold cyan]/// COMMITER AI ///[/bold cyan]  [dim]SYSTEM.AUTO_GROUP[/dim]",
                classes="title-banner",
            )

            table = DataTable(id="files-table", cursor_type="row")
            table.add_columns("Status", "File Path")
            yield table
            yield Static(
                "[dim]  F focus files  •  R refresh[/dim]",
                id="files-hint",
                classes="field-hint",
            )

            with Center():
                yield Static(
                    "[bold cyan]INPUT COMMIT COUNT[/bold cyan] [dim]OR PRESS[/dim] [bold yellow]A[/bold yellow] [dim]FOR AUTO[/dim]",
                    id="input-hint-text"
                )
                yield DigitOnlyInput(
                    placeholder="E.g., 3 or A...",
                    id="commit-count-input",
                    restrict=r"^([aA]|[1-9][0-9]*)?$",
                )
            yield Static(
                "[dim]  I focus input  •  A auto-group  •  Enter submit[/dim]",
                id="input-keys-hint",
                classes="field-hint",
            )
            yield Static("", id="main-error-label", classes="error-text")
        yield Footer()

    def on_mount(self) -> None:
        self.action_refresh()
        self.query_one("#commit-count-input", Input).focus()

    def on_key(self, event) -> None:
        """Explicit key handler — fires after DigitOnlyInput lets a letter bubble.

        Belt-and-suspenders alongside priority BINDINGS: even if the bindings
        system doesn't re-check during the bubble phase, this handler will
        catch letters that DigitOnlyInput passed through.
        """
        if event.key == "a":
            event.stop()
            self.action_auto_group()
        elif event.key == "r":
            event.stop()
            self.action_refresh()
        elif event.key == "f":
            event.stop()
            self.action_focus_files()
        elif event.key == "i":
            event.stop()
            self.action_focus_input()

    def action_refresh(self) -> None:
        """Refresh the git changed files table."""
        table = self.query_one("#files-table", DataTable)
        table.clear()
        files = get_changed_files()
        for f in files:
            table.add_row(format_status(f.status), f.path)

        inp = self.query_one("#commit-count-input", Input)
        hint = self.query_one("#input-hint-text", Static)
        error = self.query_one("#main-error-label", Static)

        if not files:
            inp.disabled = True
            hint.update("[dim]Waiting for changes... (Press 'r' to re-scan)[/dim]")
            error.update("[yellow]No changed files detected. Modify or stage files to continue.[/yellow]")
        else:
            inp.disabled = False
            hint.update("[bold cyan]INPUT COMMIT COUNT[/bold cyan] [dim]OR PRESS[/dim] [bold yellow]A[/bold yellow] [dim]FOR AUTO[/dim]")
            error.update("")

    def action_focus_files(self) -> None:
        """Move focus to the files table (F key)."""
        self.query_one("#files-table", DataTable).focus()

    def action_focus_input(self) -> None:
        """Move focus to the commit count input (I key)."""
        inp = self.query_one("#commit-count-input", Input)
        if not inp.disabled:
            inp.focus()

    def action_auto_group(self) -> None:
        """Trigger AI commit grouping automatically."""
        # Check for conflicts first
        from .git import has_unmerged_paths
        if has_unmerged_paths():
            self.app.notify("Git conflicts detected! Resolve them before grouping.", severity="error")
            return
            
        if get_changed_files():
            self.query_one("#main-error-label", Static).update("")
            # Lock input
            self.query_one("#commit-count-input", Input).disabled = True
            self.app.push_screen(LoadingScreen("auto"))
        else:
            self.app.notify("No changes to group!", severity="error")

    @on(Input.Submitted, "#commit-count-input")
    def on_submit(self, event: Input.Submitted) -> None:
        # Check for conflicts first
        from .git import has_unmerged_paths
        if has_unmerged_paths():
            self.app.notify("Git conflicts detected! Resolve them before grouping.", severity="error")
            return

        val = event.value.strip().lower()
        if val == "a":
            self.query_one("#main-error-label", Static).update("")
            event.input.disabled = True
            self.app.push_screen(LoadingScreen("auto"))
            return

        if val.isdigit():
            self.query_one("#main-error-label", Static).update("")
            # Lock input
            event.input.disabled = True
            self.app.push_screen(LoadingScreen(int(val)))


class CyberLoader(Static):
    """A futuristic scanning loader with animated robot mascot."""

    def on_mount(self) -> None:
        self.frame_idx = 0
        self.width_cells = 64
        self.set_interval(0.04, self.animate_loader)

    def animate_loader(self) -> None:
        self.frame_idx += 1
        pos = self.frame_idx % (self.width_cells * 2)
        if pos >= self.width_cells:
            pos = (self.width_cells * 2) - pos - 1

        bar = [" "] * self.width_cells
        for i in range(self.width_cells):
            dist = abs(i - pos)
            if dist == 0:
                bar[i] = "[bold cyan]█[/bold cyan]"
            elif dist == 1:
                bar[i] = "[cyan]▓[/cyan]"
            elif dist == 2:
                bar[i] = "[cyan]▒[/cyan]"
            else:
                bar[i] = "[dim]·[/dim]"

        bot_cycle = (self.frame_idx // 8) % 4
        if bot_cycle == 0:
            eyes = "o_o"
        elif bot_cycle == 1:
            eyes = "-_-"
        elif bot_cycle == 2:
            eyes = ">_<"
        else:
            eyes = "O_O"
            
        ant_cycle = (self.frame_idx // 2) % 4
        antenna = ["|", "/", "-", "\\"][ant_cycle]
        
        mascot = f"""[bold yellow]   {antenna}   [/bold yellow]
[bold cyan] ╭━━━╮ [/bold cyan]
[bold cyan] ┃[/bold cyan][bold white]{eyes}[/bold white][bold cyan]┃ [/bold cyan]
[bold cyan] ╰━━━╯ [/bold cyan]"""

        bar_str = f"[bold blue]▐[/bold blue]{''.join(bar)}[bold blue]▌[/bold blue]"
        
        self.update(f"{mascot}\n{bar_str}")



class LoadingScreen(Screen):
    """Screen displayed while AI is thinking. Shows streaming tokens below the loader."""

    TIPS = [
        "Use 'commiter -c 3' for quick atomic commits.",
        "Ctrl+K in TUI opens the professional Command Palette.",
        "Atomic commits keep your git history clean and readable.",
        "--push flag automatically pushes after successful commits.",
        "Include only specific files with '--include *.py'.",
        "Truncate huge diffs automatically to save AI context window.",
        "Define custom personas in config.toml for tailored messages.",
        "Run 'commiter --config' to update your AI preferences.",
        "Atomic commits make code reviews faster and easier.",
        "The 'One file, one commit' rule ensures extreme commit integrity."
    ]

    BINDINGS = [
        Binding("escape", "cancel_generation", "Cancel"),
        Binding("c", "cancel_generation", "Cancel"),
    ]

    def __init__(self, commit_count: int | str, **kwargs):
        super().__init__(**kwargs)
        self.commit_count = commit_count
        self.tip_index = 0
        self._cancelled = False

    def action_cancel_generation(self) -> None:
        self._cancelled = True
        self.app.pop_screen()
        main = self.app.screen
        if isinstance(main, MainScreen):
            try:
                main.query_one("#commit-count-input", Input).disabled = False
                main.query_one("#commit-count-input", Input).focus()
            except Exception:
                pass

    def compose(self) -> ComposeResult:
        with Center(id="loading-center"):
            yield Static("[bold cyan]>>> AI NEURAL LINK ESTABLISHED[/bold cyan]", classes="loading-title")
            yield CyberLoader(id="cyber-loader")
            yield Static("STATUS: [blink bold green]PROCESSING REPOSITORY DATA...[/blink bold green]", id="loading-state")
            yield Static(self.TIPS[0], id="tip-label")

    def on_mount(self) -> None:
        self.fetch_ai(self.commit_count)
        self.set_interval(3.0, self.update_tip)

    def update_tip(self) -> None:
        self.tip_index = (self.tip_index + 1) % len(self.TIPS)
        self.query_one("#tip-label", Static).update(self.TIPS[self.tip_index])

    @work(thread=True)
    def fetch_ai(self, count: int | str) -> None:
        try:
            from .ai import fetch_proposed_commits
            commits = fetch_proposed_commits(self.app.config, count)
            if self._cancelled:
                return
            commits = post_process_commits(commits)
            if self._cancelled:
                return
            self.app.call_from_thread(self.show_review, commits)
        except Exception as e:
            if not self._cancelled:
                self.app.call_from_thread(self.show_error, str(e))

    def show_review(self, commits: List[Dict[str, Any]]) -> None:
        self.app.pop_screen()
        self.app.push_screen(ReviewScreen(commits))

    def show_error(self, message: str) -> None:
        self.app.pop_screen()
        main = self.app.screen
        if isinstance(main, MainScreen):
            main.query_one("#main-error-label", Static).update(f"Error: {message}")
            # Unlock input
            try:
                main.query_one("#commit-count-input", Input).disabled = False
                main.query_one("#commit-count-input", Input).focus()
            except Exception:
                pass


class EditCommitModal(ModalScreen):
    """Modal screen for editing a commit message inline."""

    BINDINGS = [
        Binding("escape", "dismiss_modal", "Cancel"),
    ]

    def __init__(self, original_message: str, **kwargs):
        super().__init__(**kwargs)
        self.original_message = original_message

    def compose(self) -> ComposeResult:
        with Container(id="edit-modal-container"):
            yield Static("[bold cyan]/// EDIT COMMIT MESSAGE //[/bold cyan]", classes="title-banner")
            yield Static(
                "[dim]Edit the commit message below. Press [bold]Enter[/bold] to save or [bold]Esc[/bold] to cancel.[/dim]",
                classes="subtitle",
            )
            yield Input(value=self.original_message, id="edit-commit-input")
            yield Static("", id="edit-error-label", classes="error-text")
            with Horizontal(id="edit-modal-buttons"):
                yield Button("Cancel [dim](Esc)[/dim]", id="edit-cancel-btn", variant="error")
                yield Button("Reset to AI suggestion", id="edit-reset-btn", variant="default")
                yield Button("Save [dim](Enter)[/dim]", id="edit-save-btn", variant="success")

    def on_mount(self) -> None:
        self.query_one("#edit-commit-input", Input).focus()

    def action_dismiss_modal(self) -> None:
        self.dismiss(None)

    @on(Input.Submitted, "#edit-commit-input")
    def on_submit(self, event: Input.Submitted) -> None:
        self._do_save()

    @on(Button.Pressed, "#edit-save-btn")
    def on_save(self) -> None:
        self._do_save()

    @on(Button.Pressed, "#edit-cancel-btn")
    def on_cancel(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#edit-reset-btn")
    def on_reset(self) -> None:
        self.query_one("#edit-commit-input", Input).value = self.original_message
        self.query_one("#edit-error-label", Static).update("")

    def _do_save(self) -> None:
        val = self.query_one("#edit-commit-input", Input).value.strip()
        if not val:
            self.query_one("#edit-error-label", Static).update("[red]Commit message cannot be empty.[/red]")
            return
        self.dismiss(val)


class ReviewScreen(Screen):
    """Screen for reviewing and selecting the proposed commits.

    Click / arrow  → highlights item & shows its files + diff in the panel.
    Space          → toggles the checkmark (include / exclude from execution).
    M              → opens edit modal to modify the commit message.
    D              → toggles the diff panel visibility.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Back"),
        Binding("ctrl+c", "app.exit", "Quit"),
        Binding("enter", "execute_selected", "Execute", priority=True),
        Binding("e", "execute_selected", "Execute", priority=True, show=False),
        Binding("c", "cancel", "Cancel", priority=True),
        Binding("space", "toggle_current", "Toggle", priority=True),
        Binding("m", "edit_commit", "Edit Msg", priority=True),
        Binding("d", "toggle_diff", "Diff View", priority=True),
    ]

    def __init__(self, commits: List[Dict[str, Any]], **kwargs):
        super().__init__(**kwargs)
        self.commits = commits
        # all commits are checked by default
        self._checked: set[int] = set(range(len(commits)))
        self.commit_files: Dict[int, List[str]] = {}
        self.commit_selected_files: Dict[int, set[str]] = {}
        self._diff_cache: Dict[int, str] = {}
        self._diff_visible: bool = True
        for i, c in enumerate(commits):
            self.commit_files[i] = c.get("files", [])
            self.commit_selected_files[i] = set(self.commit_files[i])
        self._current_details_idx: int = -1
        self._current_file: str | None = None

    # ------------------------------------------------------------------ compose
    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="review-content"):
            yield Static("[bold cyan]/// REVIEW PROPOSED COMMITS ///[/bold cyan]", classes="title-banner")
            yield Static(
                "[dim]↑↓ navigate  •  [bold]Space[/bold] toggle  •  [bold]M[/bold] edit  •  [bold]D[/bold] diff  •  [bold]Enter[/bold] execute  •  [bold]C[/bold]/[bold]Esc[/bold] back[/dim]",
                classes="subtitle",
            )

            with Horizontal(id="review-main"):
                with Vertical(id="left-panel"):
                    yield ListView(id="commits-list")
                    with Vertical(id="files-panel"):
                        yield Static("[dim]FILES IN COMMIT:[/dim]", id="files-panel-title")
                        yield SelectionList[str](id="file-details-list")
                with Vertical(id="diff-panel"):
                    yield Static("[bold cyan]DIFF PREVIEW[/bold cyan] [dim](D to toggle)[/dim]", id="diff-panel-title")
                    yield RichLog(id="diff-log", highlight=True, markup=True, wrap=False)

            with Horizontal(id="review-buttons"):
                yield Button("Cancel [dim](c)[/dim]", id="cancel-btn", variant="error")
                yield Button("Execute Commits [dim](enter)[/dim]", id="execute-btn", variant="success")

        yield Footer()

    # ------------------------------------------------------------------ mount
    def on_mount(self) -> None:
        lv = self.query_one("#commits-list", ListView)
        for idx, c in enumerate(self.commits):
            self._append_item(lv, idx)
        if self.commits:
            self.call_after_refresh(self._update_details, 0)
        
        # Initial display state
        main = self.query_one("#review-main")
        panel = self.query_one("#diff-panel")
        if self._diff_visible:
            main.add_class("diff-active")
            panel.display = True
        else:
            main.remove_class("diff-active")
            panel.display = False

    # ------------------------------------------------------------------ helpers
    def _item_label(self, idx: int) -> str:
        c = self.commits[idx]
        msg = c.get("message", "No message")
        file_count = len(self.commit_selected_files.get(idx, set()))
        tick = "[bold cyan][*][/bold cyan]" if idx in self._checked else "[dim][ ][/dim]"
        return f"{tick}  [b]{msg}[/b] [dim]({file_count} file{'s' if file_count != 1 else ''})[/dim]"

    def _append_item(self, lv: ListView, idx: int) -> None:
        item = ListItem(Label(self._item_label(idx)), id=f"commit-item-{idx}")
        lv.append(item)

    def _refresh_item(self, idx: int) -> None:
        try:
            item = self.query_one(f"#commit-item-{idx}", ListItem)
            item.query_one(Label).update(self._item_label(idx))
        except Exception:
            pass

    def _update_details(self, idx: int) -> None:
        self._current_details_idx = idx
        sel_list = self.query_one("#file-details-list", SelectionList)
        sel_list.clear_options()
        all_files = self.commit_files.get(idx, [])
        selected_set = self.commit_selected_files.get(idx, set())
        for f in all_files:
            sel_list.add_option((f, f, f in selected_set))
        
        # Default to first file if nothing selected
        if all_files:
            self._current_file = all_files[0]
            self._load_diff(idx, self._current_file)
        else:
            self._current_file = None
            diff_log = self.query_one("#diff-log", RichLog)
            diff_log.clear()
            diff_log.write("[dim]No files in this commit.[/dim]")

    def _load_diff(self, idx: int, file: str | None = None) -> None:
        """Load and display the diff for the given commit index or specific file."""
        diff_log = self.query_one("#diff-log", RichLog)
        diff_log.clear()
        
        files = [file] if file else self.commit_files.get(idx, [])
        
        # Check cache (simple key commit_idx:file)
        cache_key = f"{idx}:{file or 'all'}"
        if cache_key in self._diff_cache:
            self._render_diff(self._diff_cache[cache_key])
            return
        
        if not files:
            diff_log.write("[dim]No files to display.[/dim]")
            return
        
        diff_log.write(f"[dim]Loading diff for {file or 'all files'}...[/dim]")
        self._fetch_diff_async(idx, files, cache_key)

    @work(thread=True)
    def _fetch_diff_async(self, idx: int, files: List[str], cache_key: str) -> None:
        """Fetch the git diff for the given files in a background thread."""
        import subprocess
        try:
            result = subprocess.run(
                ["git", "diff", "HEAD", "--"] + files,
                capture_output=True, text=True, timeout=10,
                env={**__import__("os").environ, "GIT_TERMINAL_PROMPT": "0"}
            )
            diff_text = result.stdout.strip()
            # Also check staged diff
            if not diff_text:
                result2 = subprocess.run(
                    ["git", "diff", "--cached", "--"] + files,
                    capture_output=True, text=True, timeout=10,
                    env={**__import__("os").environ, "GIT_TERMINAL_PROMPT": "0"}
                )
                diff_text = result2.stdout.strip()
            
            # Truncate very large diffs to keep TUI responsive
            max_chars = 8000
            truncated = False
            if len(diff_text) > max_chars:
                diff_text = diff_text[:max_chars]
                truncated = True

            # Cache result
            self._diff_cache[cache_key] = diff_text
            if truncated:
                diff_text += "\n\n... [diff truncated] ..."
            self.app.call_from_thread(self._render_diff, diff_text)
        except Exception as e:
            self.app.call_from_thread(self._render_diff_error, str(e))

    def _render_diff(self, diff_text: str) -> None:
        """Render the diff text into the diff log widget."""
        diff_log = self.query_one("#diff-log", RichLog)
        diff_log.clear()
        if not diff_text:
            diff_log.write("[dim]No changes to display for these files.[/dim]")
            return
        for line in diff_text.splitlines():
            if line.startswith("+") and not line.startswith("+++"):
                diff_log.write(f"[green]{line}[/green]")
            elif line.startswith("-") and not line.startswith("---"):
                diff_log.write(f"[red]{line}[/red]")
            elif line.startswith("@@"):
                diff_log.write(f"[cyan]{line}[/cyan]")
            elif line.startswith("diff ") or line.startswith("index "):
                diff_log.write(f"[dim]{line}[/dim]")
            else:
                diff_log.write(line)

    def _render_diff_error(self, error: str) -> None:
        diff_log = self.query_one("#diff-log", RichLog)
        diff_log.clear()
        diff_log.write(f"[red]Failed to load diff: {error}[/red]")

    # ------------------------------------------------------------------ events
    def _idx_from_item(self, item) -> int | None:
        """Extract the commit index from a ListItem's id."""
        try:
            return int(item.id.split("-")[-1])  # type: ignore
        except (AttributeError, ValueError, IndexError, TypeError):
            return None

    @on(ListView.Highlighted)
    def on_highlighted(self, event: ListView.Highlighted) -> None:
        """Update the details panel when a commit is highlighted (arrows / initial)."""
        if event.item is not None:
            idx = self._idx_from_item(event.item)
            if idx is not None:
                self._update_details(idx)

    @on(ListView.Selected)
    def on_selected(self, event: ListView.Selected) -> None:
        """Update the details panel when a commit is clicked / Enter-pressed."""
        if event.item is not None:
            idx = self._idx_from_item(event.item)
            if idx is not None:
                self._update_details(idx)

    @on(SelectionList.OptionHighlighted, "#file-details-list")
    def on_file_highlighted(self, event: SelectionList.OptionHighlighted) -> None:
        """Update diff view when user highlights a different file."""
        file = event.option.value
        self._current_file = file
        if self._current_details_idx != -1:
            self._load_diff(self._current_details_idx, file)

    @on(SelectionList.SelectedChanged, "#file-details-list")
    def on_file_selection_changed(self, event: SelectionList.SelectedChanged) -> None:
        if self._current_details_idx >= 0:
            idx = self._current_details_idx
            self.commit_selected_files[idx] = set(event.selection_list.selected)
            self._refresh_item(idx)

    def action_toggle_current(self) -> None:
        """Toggle the checked state of the currently highlighted commit (Space key)."""
        lv = self.query_one("#commits-list", ListView)
        if lv.highlighted_child is None:
            return
        try:
            idx = int(lv.highlighted_child.id.split("-")[-1])  # type: ignore
        except (AttributeError, ValueError, IndexError):
            return
        if idx in self._checked:
            self._checked.discard(idx)
        else:
            self._checked.add(idx)
        self._refresh_item(idx)

    def action_toggle_diff(self) -> None:
        """Toggle the diff panel on/off."""
        self._diff_visible = not self._diff_visible
        main = self.query_one("#review-main")
        panel = self.query_one("#diff-panel")
        
        if self._diff_visible:
            main.add_class("diff-active")
            panel.display = True
            if self._current_details_idx >= 0:
                self._load_diff(self._current_details_idx, self._current_file)
        else:
            main.remove_class("diff-active")
            panel.display = False

    def action_edit_commit(self) -> None:
        """Open the edit modal for the highlighted commit."""
        lv = self.query_one("#commits-list", ListView)
        if lv.highlighted_child is None:
            self.app.notify("No commit selected to edit.", severity="warning")
            return
        try:
            idx = int(lv.highlighted_child.id.split("-")[-1])
        except (AttributeError, ValueError, IndexError):
            return
        original_msg = self.commits[idx].get("message", "")
        
        def on_modal_dismiss(result: str | None) -> None:
            if result is not None:
                # Update both the commits dict and UI
                self.commits[idx]["message"] = result
                self._refresh_item(idx)
                self.app.notify(f"Commit message updated.", severity="information")
        
        self.app.push_screen(EditCommitModal(original_msg), on_modal_dismiss)

    def action_cancel(self) -> None:
        self.app.pop_screen()

    @on(Button.Pressed, "#cancel-btn")
    def on_cancel(self) -> None:
        self.app.pop_screen()

    @on(Button.Pressed, "#execute-btn")
    def action_execute_selected(self) -> None:
        if not self._checked:
            self.app.notify("No commits selected!", severity="warning")
            return
        selected_commits = []
        for i in sorted(self._checked):
            c = dict(self.commits[i])
            c["files"] = list(self.commit_selected_files.get(i, set()))
            if c["files"]:
                selected_commits.append(c)
                
        if not selected_commits:
            self.app.notify("No files selected in checked commits!", severity="warning")
            return
            
        self.app.pop_screen()
        self.app.push_screen(ExecutionScreen(selected_commits))


class ExecutionScreen(Screen):
    """Screen that executes and streams logs."""

    BINDINGS = [
        Binding("q", "app.exit", "Quit"),
        Binding("escape", "app.exit", "Quit"),
        Binding("ctrl+c", "app.exit", "Quit"),
        Binding("enter", "try_exit", "Exit", priority=True),
    ]

    def __init__(self, commits: List[Dict[str, Any]], **kwargs):
        super().__init__(**kwargs)
        self.commits = commits

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="execution-content"):
            yield Static("[bold cyan]/// EXECUTING COMMITS ///[/bold cyan]", classes="title-banner")
            yield RichLog(id="execution-log", highlight=True, markup=True)

            with Center():
                yield Button("Exit", id="exit-btn", variant="primary", disabled=True)
        yield Footer()

    def on_mount(self) -> None:
        self.run_execution()

    @work(thread=True)
    def run_execution(self) -> None:
        log = self.query_one("#execution-log", RichLog)
        total = len(self.commits)
        for i, commit in enumerate(self.commits, 1):
            msg = commit.get("message", "No message")
            files = commit.get("files", [])
            file_lines = "\n".join([f"  [dim]• {f}[/dim]" for f in files])
            self.app.call_from_thread(
                log.write, f"[cyan]({i}/{total}) Committing: {msg}[/cyan]\n{file_lines}"
            )

            try:
                result = execute_commit(files, msg)
                if result == "SKIPPED_NO_CHANGES":
                    self.app.call_from_thread(log.write, "  [yellow]SKIPPED (No changes remaining)[/yellow]")
                else:
                    self.app.call_from_thread(log.write, f"  [green][OK] {result}[/green]")
            except Exception as e:
                self.app.call_from_thread(log.write, f"  [red][ERROR] Failed! {e}[/red]")
                self.app.call_from_thread(log.write, "[bold red]Halting further commits.[/bold red]")
                break

        self.app.call_from_thread(self.finish_execution)

    def append_log(self, message: str) -> None:
        log_view = self.query_one("#execution-log", RichLog)
        log_view.write(message)

    def finish_execution(self) -> None:
        log_view = self.query_one("#execution-log", RichLog)
        log_view.write(
            "\n[bold green]All requested operations completed. Press Enter, Escape or Quit to exit.[/bold green]"
        )

        exit_btn = self.query_one("#exit-btn", Button)
        exit_btn.disabled = False
        exit_btn.focus()

    def action_try_exit(self) -> None:
        """Only allow Enter-to-exit once execution is finished."""
        btn = self.query_one("#exit-btn", Button)
        if not btn.disabled:
            self.app.exit(self.commits)

    @on(Button.Pressed, "#exit-btn")
    def on_exit(self) -> None:
        self.app.exit(self.commits)


class CommiterProvider(Provider):
    """A command provider to search for commiter commands."""
    
    async def search(self, query: str) -> Hits:
        """Search for Commiter commands."""
        matcher = self.matcher(query)
        
        commands = [
            ("Refresh Diffs", "screen.refresh", "Rescan current git changes"),
            ("Auto-Group Commits", "screen.auto_group", "Let AI decide commit groups"),
            ("Quit App", "app.exit", "Exit Commiter immediately"),
        ]
        
        for name, action, help_text in commands:
            score = matcher.match(name)
            if score > 0:
                yield Hit(
                    score,
                    matcher.highlight(name),
                    self.callback(action),
                    help=help_text,
                )

    def callback(self, action: str):
        """Returns a callback for the given action."""
        if action == "app.exit":
            return self.app.action_exit
        elif action == "screen.refresh":
            return lambda: getattr(self.app.screen, "action_refresh", lambda: None)()
        elif action == "screen.auto_group":
            return lambda: getattr(self.app.screen, "action_auto_group", lambda: None)()
        return lambda: None


class CommiterApp(App):
    """A Textual app to manage git commits cleanly."""

    COMMAND_EXTENSIONS = {CommiterProvider}
    
    BINDINGS = [
        Binding("ctrl+k", "command_palette", "Command Palette"),
    ]

    def action_exit(self) -> None:
        """Exit the application. Referenced by all ctrl+c / escape / q bindings."""
        self.exit()

    async def _on_key(self, event) -> None:
        """Capture phase — fires before ANY focused widget (including Input) sees the key."""
        if event.key == "ctrl+c":
            event.stop()
            self.exit()
            return
        # On MainScreen, intercept 'a' and 'r' regardless of which widget is focused
        if isinstance(self.screen, MainScreen):
            if event.key == "a":
                event.prevent_default()
                event.stop()
                self.screen.action_auto_group()
                return
            elif event.key == "r":
                event.prevent_default()
                event.stop()
                self.screen.action_refresh()
                return
        await super()._on_key(event)

    def on_key(self, event) -> None:
        """Bubble phase catch-all (backup for ctrl+c)."""
        if event.key == "ctrl+c":
            event.stop()
            self.exit()

    CSS = """
    Screen {
        background: $surface;
    }
    
    .title-banner {
        text-align: center;
        background: $panel;
        color: $text;
        padding: 0;
        margin-bottom: 0;
        border-bottom: heavy $secondary;
    }
    
    .subtitle {
        text-align: center;
        margin-bottom: 0;
    }
    
    #main-content, #review-content, #execution-content {
        margin: 0;
        height: 1fr;
    }
    
    #files-table {
        height: 1fr;
        border: solid $accent;
        margin-bottom: 0;
    }
    
    #commit-count-input {
        width: 40;
        margin-top: 0;
        margin-bottom: 0;
    }
    
    .input-hint {
        text-align: center;
    }
    
    .error-text {
        color: $error;
        text-align: center;
        margin-top: 0;
    }

    .field-hint {
        color: $text-muted;
        margin-bottom: 0;
        height: 1;
    }
    
    #loading-center {
        align: center middle;
        width: 100%;
        height: 100%;
    }
    
    .loading-title {
        margin-bottom: 0;
        width: 100%;
        text-align: center;
        color: cyan;
    }

    #tip-label {
        margin-top: 1;
        width: 100%;
        text-align: center;
        color: $text-muted;
        height: 1;
    }

    #cyber-loader {
        width: 100%;
        margin: 0;
        text-align: center;
    }



    #loading-state {
        text-align: center;
        margin-top: 0;
        margin-bottom: 0;
    }
    
    #review-main {
        height: 1fr;
        margin-bottom: 0;
    }

    #left-panel {
        width: 100%;
        height: 1fr;
    }
    
    #review-main.diff-active #left-panel {
        width: 45%;
    }
    
    #commits-list {
        height: 60%;
        border: solid $accent;
    }

    #commits-list > ListItem {
        padding: 0;
    }

    #commits-list > ListItem.--highlight {
        background: $primary 30%;
    }

    #files-panel {
        height: 40%;
        border: solid $primary;
        padding: 0;
        margin-top: 0;
    }

    #files-panel-title {
        height: 1;
        margin-bottom: 0;
    }

    #diff-panel {
        width: 55%;
        height: 1fr;
        border: solid $secondary;
        padding: 0;
        margin-left: 0;
        background: $panel;
        display: none;
    }
    
    #review-main.diff-active #diff-panel {
        display: block;
    }

    #diff-panel-title {
        height: 1;
        margin-bottom: 0;
    }

    #diff-log {
        height: 1fr;
    }
    
    #details-panel {
        width: 40%;
        height: 1fr;
        border: solid $primary;
        padding: 0;
        margin-left: 0;
        background: $panel;
    }
    
    #file-details {
        height: 1fr;
        overflow-y: auto;
    }

    #review-buttons {
        height: auto;
        align-horizontal: center;
        margin-top: 0;
        margin-bottom: 0;
    }
    
    #review-buttons Button {
        margin: 0 1;
    }
    
    #execution-log {
        height: 1fr;
        border: solid $accent;
        background: $panel;
        padding: 0;
        margin-bottom: 0;
    }
    
    Button {
        margin-top: 0;
    }

    /* Edit Commit Modal */
    EditCommitModal {
        align: center middle;
    }

    #edit-modal-container {
        width: 75%;
        height: auto;
        background: $surface;
        border: solid $accent;
        padding: 1 2;
    }

    #edit-modal-buttons {
        height: auto;
        align-horizontal: center;
        margin-top: 1;
    }

    #edit-modal-buttons Button {
        margin: 0 1;
    }

    #edit-commit-input {
        margin-top: 1;
        margin-bottom: 0;
    }
    """

    def __init__(self, config: dict):
        super().__init__()
        self.config = config

    def _on_key(self, event) -> None:
        """Capture-phase key handler — fires BEFORE the focused widget sees the key.

        In Textual, `_on_key` (underscore prefix) is called top-down during the
        capture phase, before `Input._on_key` has a chance to call event.stop().
        This makes it the only reliable way to intercept global shortcuts while
        an Input widget is focused.
        """
        key = event.key
        
        # Global quit bindings
        if key in ("q", "escape", "ctrl+c"):
            event.stop()
            event.prevent_default()
            self.exit()
            return

        # MainScreen specific bindings
        if hasattr(self.screen, "action_auto_group"):
            focused = getattr(self.screen, "focused", None)
            is_input_focused = focused and focused.id == "commit-count-input"

            if key == "a":
                if not is_input_focused:
                    event.stop()
                    event.prevent_default()
                    self.screen.action_auto_group()
            elif key == "r":
                event.stop()
                event.prevent_default()
                self.screen.action_refresh()
            elif key == "f":
                event.stop()
                event.prevent_default()
                self.screen.action_focus_files()
            elif key == "i":
                event.stop()
                event.prevent_default()
                self.screen.action_focus_input()

    def on_mount(self) -> None:
        self.push_screen(MainScreen())


def run_tui(config: dict):
    app = CommiterApp(config)
    selected_commits = app.run()
    return selected_commits
