"""
Setup configuration for paper-search-lib
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='paper-search-lib',
    version='1.0.0',
    author='Your Name',
    author_email='your.email@example.com',
    description='Unified paper search across 20+ academic sources',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/paper-search-lib',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    python_requires='>=3.9',
    install_requires=[
        'requests>=2.28.0',
        'feedparser>=6.0.0',
        'httpx>=0.24.0',
        'beautifulsoup4>=4.12.0',
        'lxml>=4.9.0',
    ],
    extras_require={
        'pdf': [
            'PyPDF2>=3.0.0',
            'pdf2image>=1.16.0',
            'pdfminer>=20221105',
        ],
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=4.0.0',
            'black>=23.0.0',
            'flake8>=6.0.0',
        ],
    },
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Scientific/Engineering',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
    ],
    keywords='paper search academic arxiv pubmed semantic scholar google scholar research',
    project_urls={
        'Documentation': 'https://github.com/yourusername/paper-search-lib/wiki',
        'Source': 'https://github.com/yourusername/paper-search-lib',
        'Tracker': 'https://github.com/yourusername/paper-search-lib/issues',
    },
)
