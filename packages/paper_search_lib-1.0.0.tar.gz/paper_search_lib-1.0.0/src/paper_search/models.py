# paper_search/models.py
"""
Data models for academic papers and search results
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Optional


@dataclass
class Paper:
    """Standardized paper format with core fields for academic sources"""
    # Required fields (but allow None values)
    paper_id: str              # Unique identifier (e.g., arXiv ID, PMID, DOI)
    title: str                 # Paper title
    authors: List[str]         # List of author names
    abstract: str              # Abstract text
    doi: str                   # Digital Object Identifier
    published_date: Optional[datetime]   # Publication date
    pdf_url: str               # Direct PDF link
    url: str                   # URL to paper page
    source: str                # Source platform (e.g., 'arxiv', 'pubmed')

    # Optional fields
    updated_date: Optional[datetime] = None        # Last updated date
    categories: Optional[List[str]] = field(default_factory=list)
    keywords: Optional[List[str]] = field(default_factory=list)
    citations: int = 0                             # Citation count
    references: Optional[List[str]] = field(default_factory=list)
    extra: Dict = field(default_factory=dict)      # Source-specific metadata

    def to_dict(self) -> Dict:
        """Convert paper to dictionary format for serialization"""
        return {
            'paper_id': self.paper_id,
            'title': self.title,
            'authors': '; '.join(self.authors) if self.authors else '',
            'abstract': self.abstract,
            'doi': self.doi,
            'published_date': self.published_date.isoformat() if self.published_date else '',
            'pdf_url': self.pdf_url,
            'url': self.url,
            'source': self.source,
            'updated_date': self.updated_date.isoformat() if self.updated_date else '',
            'categories': '; '.join(self.categories) if self.categories else '',
            'keywords': '; '.join(self.keywords) if self.keywords else '',
            'citations': self.citations,
            'references': '; '.join(self.references) if self.references else '',
            'extra': str(self.extra) if self.extra else ''
        }


@dataclass
class SearchResult:
    """Container for search results from multiple sources"""
    query: str
    papers: List[Paper]
    total_found: int
    sources_queried: List[str]
    successful_sources: List[str]
    failed_sources: List[str]
    query_time_seconds: float

    def to_dict(self) -> Dict:
        """Convert search result to dictionary"""
        return {
            'query': self.query,
            'total_found': self.total_found,
            'papers': [p.to_dict() for p in self.papers],
            'sources_queried': self.sources_queried,
            'successful_sources': self.successful_sources,
            'failed_sources': self.failed_sources,
            'query_time_seconds': self.query_time_seconds
        }
