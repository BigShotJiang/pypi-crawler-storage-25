# paper_search/base.py
"""
Abstract base class for academic paper source connectors
"""
from abc import ABC, abstractmethod
from typing import List, Optional
from .models import Paper


class PaperConnector(ABC):
    """Abstract base class for academic paper sources"""

    @abstractmethod
    def search(self, query: str, max_results: int = 10, **kwargs) -> List[Paper]:
        """Search papers matching the query

        Args:
            query: Search query string
            max_results: Maximum number of results to return
            **kwargs: Source-specific parameters (e.g., filters, year ranges)

        Returns:
            List of Paper objects
        """
        pass

    def download_pdf(self, paper: Paper, save_path: str) -> Optional[str]:
        """Download the PDF for a given paper

        Args:
            paper: Paper object
            save_path: Directory to save the downloaded PDF

        Returns:
            Path to the saved PDF file, or None if download failed

        Raises:
            NotImplementedError: If the source does not support PDF downloads
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support PDF downloads"
        )

    def get_source_name(self) -> str:
        """Get the human-readable name of this source"""
        return self.__class__.__name__.replace('Connector', '').lower()
