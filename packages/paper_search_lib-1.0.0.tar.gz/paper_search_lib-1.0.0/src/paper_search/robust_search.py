# paper_search/robust_search.py
"""
Robust search with automatic retries, proper delays, and error handling
Built from production experience with ArXiv and other academic APIs
"""
import time
from typing import List, Optional, Dict
from .models import Paper, SearchResult
from .base import PaperConnector


class RobustSearch:
    """
    Robust paper search with:
    - Proper delays between requests (rate limit safe)
    - Retry logic with exponential backoff
    - Timeout handling
    - Fallback to alternative sources
    """

    def __init__(
        self,
        connectors: List[PaperConnector],
        min_delay: float = 10.0,
        max_retries: int = 3,
        timeout: float = 90.0,
        use_fallback: bool = True
    ):
        """
        Initialize robust search

        Args:
            connectors: List of PaperConnector instances to use
            min_delay: Minimum seconds between requests (default 10s)
            max_retries: Maximum retry attempts (default 3)
            timeout: Request timeout in seconds (default 90s)
            use_fallback: Try alternative sources if primary fails
        """
        self.connectors = connectors
        self.min_delay = min_delay
        self.max_retries = max_retries
        self.timeout = timeout
        self.use_fallback = use_fallback
        self.last_request_time = 0

    def _wait_before_request(self):
        """Implement proper delay between requests"""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.min_delay:
            wait_time = self.min_delay - elapsed
            time.sleep(wait_time)
        self.last_request_time = time.time()

    def search(
        self,
        query: str,
        max_results: int = 10,
        sources: Optional[List[str]] = None
    ) -> SearchResult:
        """
        Search across multiple sources with proper error handling

        Args:
            query: Search query
            max_results: Maximum results per source
            sources: Specific sources to search (uses all if None)

        Returns:
            SearchResult with papers from successful sources
        """
        import time as time_module
        start_time = time_module.time()

        papers = []
        successful_sources = []
        failed_sources = []
        sources_queried = []

        # Filter connectors by requested sources
        active_connectors = self.connectors
        if sources:
            active_connectors = [
                c for c in self.connectors
                if c.get_source_name() in sources
            ]

        for connector in active_connectors:
            source_name = connector.get_source_name()
            sources_queried.append(source_name)

            try:
                self._wait_before_request()

                # Search with retry logic
                results = None
                for attempt in range(self.max_retries):
                    try:
                        results = connector.search(
                            query,
                            max_results=max_results
                        )
                        break
                    except TimeoutError:
                        if attempt < self.max_retries - 1:
                            time.sleep(5)  # Brief wait before retry
                            continue
                        raise
                    except Exception as e:
                        if attempt < self.max_retries - 1:
                            time.sleep(10)
                            continue
                        raise

                if results:
                    papers.extend(results)
                    successful_sources.append(source_name)

            except Exception as e:
                failed_sources.append(source_name)
                if not self.use_fallback:
                    raise

        query_time = time_module.time() - start_time

        return SearchResult(
            query=query,
            papers=papers,
            total_found=len(papers),
            sources_queried=sources_queried,
            successful_sources=successful_sources,
            failed_sources=failed_sources,
            query_time_seconds=query_time
        )

    def search_multiple(
        self,
        queries: List[str],
        max_results: int = 10
    ) -> Dict[str, SearchResult]:
        """
        Search multiple queries sequentially with proper delays

        Args:
            queries: List of search queries
            max_results: Maximum results per query

        Returns:
            Dictionary mapping query -> SearchResult
        """
        results = {}
        for i, query in enumerate(queries):
            result = self.search(query, max_results)
            results[query] = result

            # Wait before next query
            if i < len(queries) - 1:
                time.sleep(self.min_delay)

        return results
