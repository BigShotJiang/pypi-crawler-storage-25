# paper_search/connectors/google_scholar.py
"""
Google Scholar paper connector
Handles searching papers from Google Scholar via HTML scraping
Note: Google Scholar has strict rate limits and may return CAPTCHAs.
      Use a proxy (proxy_url) or reduce request frequency to avoid blocks.
"""
from typing import List, Optional
from datetime import datetime
import requests
from bs4 import BeautifulSoup
import time
import random
from ..models import Paper
from ..base import PaperConnector


class GoogleScholarConnector(PaperConnector):
    """Search papers from Google Scholar (HTML scraping)"""

    SCHOLAR_URL = "https://scholar.google.com/scholar"

    BROWSERS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
    ]

    def __init__(self, proxy_url: Optional[str] = None, max_retries: int = 3, retry_delay: float = 2.0):
        self.proxy_url = proxy_url
        self.max_retries = max(1, max_retries)
        self.retry_delay = max(0.5, retry_delay)
        self.session = requests.Session()
        self._rotate_user_agent()
        if proxy_url:
            self.session.proxies.update({'http': proxy_url, 'https': proxy_url})

    def _rotate_user_agent(self):
        self.session.headers.update({
            'User-Agent': random.choice(self.BROWSERS),
            'Accept': 'text/html,application/xhtml+xml',
            'Accept-Language': 'en-US,en;q=0.9',
        })

    @staticmethod
    def _is_captcha(soup: BeautifulSoup) -> bool:
        return bool(
            soup.find('form', {'id': 'gs_captcha_f'})
            or soup.find('input', {'name': 'captcha'})
            or "please show you're not a robot" in soup.get_text(' ', strip=True).lower()
        )

    def _extract_year(self, text: str) -> Optional[int]:
        for word in text.split():
            if word.isdigit() and 1900 <= int(word) <= datetime.now().year:
                return int(word)
        return None

    def _parse_paper(self, item) -> Optional[Paper]:
        try:
            title_elem = item.find('h3', class_='gs_rt')
            info_elem = item.find('div', class_='gs_a')
            abstract_elem = item.find('div', class_='gs_rs')

            if not title_elem or not info_elem:
                return None

            title = title_elem.get_text(strip=True).replace('[PDF]', '').replace('[HTML]', '').strip()
            link = title_elem.find('a', href=True)
            url = link['href'] if link else ''

            info_text = info_elem.get_text()
            authors = [a.strip() for a in info_text.split('-')[0].split(',')]
            year = self._extract_year(info_text)
            abstract = abstract_elem.get_text() if abstract_elem else ''

            return Paper(
                paper_id=f"gs_{abs(hash(url))}",
                title=title,
                authors=authors,
                abstract=abstract,
                url=url,
                pdf_url='',
                published_date=datetime(year, 1, 1) if year else None,
                updated_date=None,
                source='google_scholar',
                categories=[],
                keywords=[],
                doi='',
                citations=0
            )
        except Exception:
            return None

    def search(self, query: str, max_results: int = 10, **kwargs) -> List[Paper]:
        """
        Search Google Scholar for papers

        Args:
            query: Search query
            max_results: Maximum papers to return
            **kwargs: Ignored

        Returns:
            List of Paper objects (may be empty if CAPTCHA is triggered)
        """
        papers = []
        start = 0

        while len(papers) < max_results:
            params = {
                'q': query,
                'start': start,
                'hl': 'en',
                'as_sdt': '0,5'
            }

            response = None
            for attempt in range(self.max_retries):
                self._rotate_user_agent()
                time.sleep(random.uniform(1.0, 2.5))

                try:
                    response = self.session.get(self.SCHOLAR_URL, params=params, timeout=30)
                except Exception:
                    break

                if response.status_code == 200:
                    break

                if response.status_code in (403, 429, 503):
                    wait_time = self.retry_delay * (2 ** attempt) + random.uniform(0, 0.5)
                    time.sleep(wait_time)
                    continue

                break

            if response is None or response.status_code != 200:
                break

            soup = BeautifulSoup(response.text, 'html.parser')

            if self._is_captcha(soup):
                break

            results = soup.find_all('div', class_='gs_ri')
            if not results:
                break

            for item in results:
                if len(papers) >= max_results:
                    break
                paper = self._parse_paper(item)
                if paper:
                    papers.append(paper)

            start += 10

        return papers[:max_results]

    def get_source_name(self) -> str:
        return 'google_scholar'
