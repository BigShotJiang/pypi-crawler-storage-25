# paper_search/connectors/semantic_scholar.py
"""
Semantic Scholar paper connector
Handles searching papers via the Semantic Scholar Graph API
"""
from typing import List, Optional
from datetime import datetime
import requests
import time
import random
from ..models import Paper
from ..base import PaperConnector


class SemanticScholarConnector(PaperConnector):
    """Search papers from Semantic Scholar Graph API"""

    SEARCH_URL = "https://api.semanticscholar.org/graph/v1/paper/search"
    BASE_URL = "https://api.semanticscholar.org/graph/v1"

    BROWSERS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
    ]

    FIELDS = [
        "title", "abstract", "year", "citationCount",
        "authors", "url", "publicationDate",
        "externalIds", "fieldsOfStudy", "openAccessPdf",
    ]

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': random.choice(self.BROWSERS),
            'Accept': 'application/json',
        })

    def _parse_date(self, date_str: Optional[str]) -> Optional[datetime]:
        if not date_str:
            return None
        try:
            return datetime.strptime(date_str.strip(), "%Y-%m-%d")
        except Exception:
            return None

    def _parse_paper(self, item: dict) -> Optional[Paper]:
        try:
            authors = [a['name'] for a in item.get('authors', [])]
            published_date = self._parse_date(item.get('publicationDate'))

            pdf_url = ''
            open_pdf = item.get('openAccessPdf')
            if open_pdf and open_pdf.get('url'):
                pdf_url = open_pdf['url']

            doi = ''
            ext_ids = item.get('externalIds') or {}
            if ext_ids.get('DOI'):
                doi = ext_ids['DOI']

            categories = item.get('fieldsOfStudy') or []

            return Paper(
                paper_id=item['paperId'],
                title=item.get('title', ''),
                authors=authors,
                abstract=item.get('abstract', ''),
                url=item.get('url', ''),
                pdf_url=pdf_url,
                published_date=published_date,
                updated_date=None,
                source='semantic_scholar',
                categories=categories,
                keywords=[],
                doi=doi,
                citations=item.get('citationCount', 0)
            )
        except Exception:
            return None

    def search(self, query: str, max_results: int = 10, **kwargs) -> List[Paper]:
        """
        Search Semantic Scholar for papers

        Args:
            query: Search query
            max_results: Maximum papers to return
            **kwargs: Optional 'year' filter (e.g., '2020', '2018-2022')

        Returns:
            List of Paper objects
        """
        params = {
            'query': query,
            'limit': min(max_results, 100),
            'fields': ','.join(self.FIELDS),
        }
        year = kwargs.get('year')
        if year:
            params['year'] = year

        headers = {}
        if self.api_key:
            headers['x-api-key'] = self.api_key

        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = self.session.get(
                    f"{self.BASE_URL}/paper/search",
                    params=params,
                    headers=headers,
                    timeout=30
                )

                if response.status_code == 429:
                    retry_after = int(response.headers.get('Retry-After', 5 * (2 ** attempt)))
                    time.sleep(retry_after)
                    continue

                if response.status_code != 200:
                    return []

                data = response.json()
                results = data.get('data', [])

                papers = []
                for item in results:
                    if len(papers) >= max_results:
                        break
                    paper = self._parse_paper(item)
                    if paper:
                        papers.append(paper)

                return papers

            except Exception:
                if attempt < max_retries - 1:
                    time.sleep(3)
                    continue
                return []

        return []

    def get_source_name(self) -> str:
        return 'semantic_scholar'
