# paper_search/connectors/__init__.py
"""
Academic source connectors
"""
from .arxiv import ArxivConnector
from .pubmed import PubmedConnector
from .semantic_scholar import SemanticScholarConnector
from .google_scholar import GoogleScholarConnector

__all__ = [
    'ArxivConnector',
    'PubmedConnector',
    'SemanticScholarConnector',
    'GoogleScholarConnector',
]
