# paper_search/connectors/arxiv.py
"""
ArXiv paper connector
Handles searching and downloading papers from arXiv
"""
from typing import List, Optional
from datetime import datetime
import requests
import feedparser
import time
import os
from ..models import Paper
from ..base import PaperConnector


class ArxivConnector(PaperConnector):
    """Search and download papers from arXiv"""

    BASE_URL = "http://export.arxiv.org/api/query"
    MIN_DELAY_SECONDS = 10  # ArXiv requires ~1 request per 3 seconds, we use 10s to be safe

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'paper-search-lib/1.0 (mailto:contact@example.com)',
            'Accept': 'application/atom+xml, application/xml;q=0.9, */*;q=0.8',
        })
        self.last_request_time = 0

    def _enforce_rate_limit(self):
        """Enforce ArXiv rate limiting (min 10 seconds between requests)"""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.MIN_DELAY_SECONDS:
            wait_time = self.MIN_DELAY_SECONDS - elapsed
            time.sleep(wait_time)
        self.last_request_time = time.time()

    def search(self, query: str, max_results: int = 10, **kwargs) -> List[Paper]:
        """
        Search arXiv for papers

        Args:
            query: Search query
            max_results: Maximum papers to return
            **kwargs: Additional parameters (ignored for ArXiv)

        Returns:
            List of Paper objects
        """
        # Simplify query - remove exact phrases that cause parsing issues
        simplified_query = query.replace('"', '')

        params = {
            'search_query': f'all:{simplified_query}',
            'max_results': max_results,
            'sortBy': 'submittedDate',
            'sortOrder': 'descending'
        }

        response = None
        max_retries = 3

        for attempt in range(max_retries):
            try:
                self._enforce_rate_limit()

                response = self.session.get(
                    self.BASE_URL,
                    params=params,
                    timeout=90  # 90 seconds (not 30!)
                )

                # Handle rate limiting
                if response.status_code == 429:
                    time.sleep(30)  # Wait longer for rate limit
                    continue

                # Handle server errors - skip this source
                if response.status_code == 503:
                    return []

                response.raise_for_status()
                break

            except requests.exceptions.Timeout:
                if attempt < max_retries - 1:
                    time.sleep(5)
                    continue
                return []
            except Exception:
                if attempt < max_retries - 1:
                    time.sleep(10)
                    continue
                return []

        if response is None or response.status_code != 200:
            return []

        # Parse results
        try:
            feed = feedparser.parse(response.content)
            papers = []

            for entry in feed.entries:
                try:
                    authors = [author.name for author in entry.get('authors', [])]
                    published = self._parse_date(entry.get('published'))
                    updated = self._parse_date(entry.get('updated'))

                    pdf_url = ''
                    for link in entry.get('links', []):
                        if link.get('type') == 'application/pdf':
                            pdf_url = link.get('href', '')
                            break

                    paper = Paper(
                        paper_id=entry.id.split('/abs/')[-1],
                        title=entry.get('title', '').replace('\n', ' ').strip(),
                        authors=authors,
                        abstract=entry.get('summary', '').replace('\n', ' ').strip(),
                        url=entry.id,
                        pdf_url=pdf_url,
                        published_date=published,
                        updated_date=updated,
                        source='arxiv',
                        categories=[tag.term for tag in entry.get('tags', [])],
                        keywords=[],
                        doi=''
                    )
                    papers.append(paper)

                except Exception:
                    # Skip entries that fail to parse
                    continue

            return papers

        except Exception:
            return []

    @staticmethod
    def _parse_date(date_string: Optional[str]) -> Optional[datetime]:
        """Parse ISO 8601 date string"""
        if not date_string:
            return None
        try:
            return datetime.strptime(date_string, '%Y-%m-%dT%H:%M:%SZ')
        except Exception:
            return None

    def download_pdf(self, paper: Paper, save_path: str) -> Optional[str]:
        """
        Download PDF for a paper

        Args:
            paper: Paper object
            save_path: Directory to save PDF

        Returns:
            Path to saved PDF, or None if failed
        """
        if not paper.pdf_url:
            return None

        try:
            os.makedirs(save_path, exist_ok=True)
            response = requests.get(paper.pdf_url, timeout=30)
            response.raise_for_status()

            output_file = os.path.join(save_path, f"{paper.paper_id}.pdf")
            with open(output_file, 'wb') as f:
                f.write(response.content)

            return output_file

        except Exception:
            return None

    def get_source_name(self) -> str:
        """Get source name"""
        return 'arxiv'
