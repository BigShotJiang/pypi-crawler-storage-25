# paper_search/connectors/pubmed.py
"""
PubMed paper connector
Handles searching papers from PubMed via NCBI E-utilities API
"""
from typing import List, Optional
from datetime import datetime
import requests
from xml.etree import ElementTree as ET
from ..models import Paper
from ..base import PaperConnector


class PubmedConnector(PaperConnector):
    """Search papers from PubMed via NCBI E-utilities"""

    SEARCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    FETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'paper-search-lib/1.0 (mailto:contact@example.com)',
        })

    def search(self, query: str, max_results: int = 10, **kwargs) -> List[Paper]:
        """
        Search PubMed for papers

        Args:
            query: Search query
            max_results: Maximum papers to return
            **kwargs: Additional parameters (ignored)

        Returns:
            List of Paper objects
        """
        try:
            search_params = {
                'db': 'pubmed',
                'term': query,
                'retmax': max_results,
                'retmode': 'xml'
            }
            search_response = self.session.get(self.SEARCH_URL, params=search_params, timeout=30)
            search_response.raise_for_status()
            search_root = ET.fromstring(search_response.content)
            ids = [id_elem.text for id_elem in search_root.findall('.//Id') if id_elem.text]

            if not ids:
                return []

            fetch_params = {
                'db': 'pubmed',
                'id': ','.join(ids),
                'retmode': 'xml'
            }
            fetch_response = self.session.get(self.FETCH_URL, params=fetch_params, timeout=30)
            fetch_response.raise_for_status()
            fetch_root = ET.fromstring(fetch_response.content)

            papers = []
            for article in fetch_root.findall('.//PubmedArticle'):
                try:
                    pmid_elem = article.find('.//PMID')
                    pmid = pmid_elem.text.strip() if pmid_elem is not None and pmid_elem.text else ''
                    if not pmid:
                        continue

                    title_elem = article.find('.//ArticleTitle')
                    title = ''.join(title_elem.itertext()).strip() if title_elem is not None else ''
                    if not title:
                        continue

                    authors = []
                    for author in article.findall('.//Author'):
                        last_name = author.find('LastName')
                        initials = author.find('Initials')
                        if last_name is not None and last_name.text:
                            name = last_name.text.strip()
                            if initials is not None and initials.text:
                                name = f"{name} {initials.text.strip()}"
                            authors.append(name)

                    abstract_parts = []
                    for abstract_elem in article.findall('.//AbstractText'):
                        text = ''.join(abstract_elem.itertext()).strip()
                        if text:
                            abstract_parts.append(text)
                    abstract = ' '.join(abstract_parts)

                    year_elem = article.find('.//PubDate/Year')
                    pub_date = year_elem.text if year_elem is not None else None
                    published = datetime.strptime(pub_date, '%Y') if pub_date else None

                    doi_elem = article.find('.//ELocationID[@EIdType="doi"]')
                    doi = doi_elem.text if doi_elem is not None else ''

                    papers.append(Paper(
                        paper_id=pmid,
                        title=title,
                        authors=authors,
                        abstract=abstract,
                        url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
                        pdf_url='',
                        published_date=published,
                        updated_date=published,
                        source='pubmed',
                        categories=[],
                        keywords=[],
                        doi=doi
                    ))
                except Exception:
                    continue

            return papers

        except Exception:
            return []

    def get_source_name(self) -> str:
        return 'pubmed'
