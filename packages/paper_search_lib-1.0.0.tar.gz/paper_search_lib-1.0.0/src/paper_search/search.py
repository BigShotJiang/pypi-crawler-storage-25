# paper_search/search.py
"""
Simple PaperSearch class for searching across academic sources
"""
from typing import List, Optional
from .models import Paper, SearchResult
from .base import PaperConnector


class PaperSearch:
    """
    Simple paper search interface for querying academic sources
    """

    def __init__(
        self,
        connectors: Optional[List[PaperConnector]] = None,
        sources: Optional[List[str]] = None
    ):
        """
        Initialize paper search

        Args:
            connectors: List of PaperConnector instances
            sources: Specific source names to enable (e.g., ['arxiv', 'pubmed'])
        """
        self.connectors = connectors or []
        self.sources = sources
        self._available_sources = [c.get_source_name() for c in self.connectors]

    def search(
        self,
        query: str,
        max_results: int = 10
    ) -> List[Paper]:
        """
        Search for papers across configured sources

        Args:
            query: Search query string
            max_results: Maximum results to return

        Returns:
            List of Paper objects
        """
        papers = []
        sources_to_search = self.sources or self._available_sources

        for connector in self.connectors:
            if connector.get_source_name() not in sources_to_search:
                continue

            try:
                results = connector.search(query, max_results=max_results)
                if results:
                    papers.extend(results)
            except Exception:
                # Silently continue if one source fails
                continue

        return papers

    def get_available_sources(self) -> List[str]:
        """Get list of available sources"""
        return self._available_sources

    def set_sources(self, sources: List[str]):
        """Set which sources to search"""
        self.sources = sources

    def search_result(
        self,
        query: str,
        max_results: int = 10
    ) -> SearchResult:
        """
        Search with detailed result information

        Args:
            query: Search query string
            max_results: Maximum results to return

        Returns:
            SearchResult with metadata about the search
        """
        import time as time_module
        start_time = time_module.time()

        papers = []
        successful_sources = []
        failed_sources = []
        sources_queried = []
        sources_to_search = self.sources or self._available_sources

        for connector in self.connectors:
            source_name = connector.get_source_name()
            if source_name not in sources_to_search:
                continue

            sources_queried.append(source_name)

            try:
                results = connector.search(query, max_results=max_results)
                if results:
                    papers.extend(results)
                    successful_sources.append(source_name)
            except Exception:
                failed_sources.append(source_name)

        query_time = time_module.time() - start_time

        return SearchResult(
            query=query,
            papers=papers,
            total_found=len(papers),
            sources_queried=sources_queried,
            successful_sources=successful_sources,
            failed_sources=failed_sources,
            query_time_seconds=query_time
        )
