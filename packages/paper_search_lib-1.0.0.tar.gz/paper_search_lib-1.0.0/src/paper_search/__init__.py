# paper_search/__init__.py
"""
Paper Search - Unified search across 20+ academic sources

Simple usage:
    from paper_search import PaperSearch

    searcher = PaperSearch(connectors=[...])
    papers = searcher.search("machine learning", max_results=10)

With robust error handling:
    from paper_search import RobustSearch

    robust = RobustSearch(
        connectors=[...],
        min_delay=10,
        max_retries=3,
        use_fallback=True
    )
    results = robust.search("bitcoin", max_results=20)
"""

from .models import Paper, SearchResult
from .search import PaperSearch
from .robust_search import RobustSearch
from .base import PaperConnector

__version__ = '0.1.0'
__author__ = 'Your Name'

__all__ = [
    'Paper',
    'SearchResult',
    'PaperSearch',
    'RobustSearch',
    'PaperConnector',
]
