# tests/test_semantic_scholar.py
"""Tests for Semantic Scholar connector"""
import pytest
from paper_search.connectors import SemanticScholarConnector
from paper_search.models import Paper


class TestSemanticScholarConnector:
    def setup_method(self):
        self.connector = SemanticScholarConnector()

    def test_search_returns_papers(self):
        papers = self.connector.search("machine learning", max_results=3)
        assert isinstance(papers, list)
        assert len(papers) > 0
        assert all(isinstance(p, Paper) for p in papers)

    def test_paper_fields(self):
        papers = self.connector.search("deep learning", max_results=1)
        assert len(papers) > 0
        paper = papers[0]
        assert paper.paper_id
        assert paper.title
        assert isinstance(paper.authors, list)
        assert paper.source == 'semantic_scholar'

    def test_respects_max_results(self):
        papers = self.connector.search("neural networks", max_results=5)
        assert isinstance(papers, list)
        assert len(papers) <= 5

    def test_empty_results(self):
        papers = self.connector.search("xyzabc123nonexistentquerystring99999", max_results=1)
        assert isinstance(papers, list)

    def test_source_name(self):
        assert self.connector.get_source_name() == 'semantic_scholar'
