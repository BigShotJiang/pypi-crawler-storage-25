# tests/test_integration.py
"""Integration tests for multi-source search"""
import pytest
from paper_search import PaperSearch
from paper_search.connectors import ArxivConnector, PubmedConnector, SemanticScholarConnector


class TestMultiSourceSearch:
    def test_multi_source_search(self):
        searcher = PaperSearch(connectors=[
            ArxivConnector(),
            SemanticScholarConnector(),
        ])
        papers = searcher.search("machine learning", max_results=6)
        assert isinstance(papers, list)
        assert len(papers) > 0

    def test_sources_are_labelled(self):
        searcher = PaperSearch(connectors=[
            ArxivConnector(),
            SemanticScholarConnector(),
        ])
        papers = searcher.search("deep learning", max_results=4)
        sources = {p.source for p in papers}
        # At least one source should be present
        assert len(sources) >= 1

    def test_get_available_sources(self):
        searcher = PaperSearch(connectors=[
            ArxivConnector(),
            PubmedConnector(),
            SemanticScholarConnector(),
        ])
        sources = searcher.get_available_sources()
        assert 'arxiv' in sources
        assert 'pubmed' in sources
        assert 'semantic_scholar' in sources
