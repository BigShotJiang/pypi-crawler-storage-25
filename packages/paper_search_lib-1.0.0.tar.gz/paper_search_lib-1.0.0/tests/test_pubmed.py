# tests/test_pubmed.py
"""Tests for PubMed connector"""
import pytest
from paper_search.connectors import PubmedConnector
from paper_search.models import Paper


class TestPubmedConnector:
    def setup_method(self):
        self.connector = PubmedConnector()

    def test_search_returns_papers(self):
        papers = self.connector.search("cancer", max_results=3)
        assert isinstance(papers, list)
        assert len(papers) > 0
        assert all(isinstance(p, Paper) for p in papers)

    def test_paper_fields(self):
        papers = self.connector.search("disease", max_results=1)
        assert len(papers) > 0
        paper = papers[0]
        assert paper.paper_id
        assert paper.title
        assert isinstance(paper.authors, list)
        assert paper.url.startswith('https://pubmed.ncbi.nlm.nih.gov/')
        assert paper.source == 'pubmed'

    def test_empty_results(self):
        papers = self.connector.search("xyzabc123nonexistentquerystring99999", max_results=1)
        assert isinstance(papers, list)

    def test_source_name(self):
        assert self.connector.get_source_name() == 'pubmed'
