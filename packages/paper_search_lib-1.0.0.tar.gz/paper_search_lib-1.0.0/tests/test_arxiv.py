# tests/test_arxiv.py
"""Tests for ArXiv connector"""
import pytest
from paper_search.connectors import ArxivConnector
from paper_search.models import Paper


class TestArxivConnector:
    """Test ArXiv connector functionality"""

    def setup_method(self):
        """Setup for each test"""
        self.connector = ArxivConnector()

    def test_search_returns_papers(self):
        """Test that search returns paper objects"""
        papers = self.connector.search("changepoint detection", max_results=3)

        assert isinstance(papers, list)
        assert len(papers) > 0
        assert all(isinstance(p, Paper) for p in papers)

    def test_paper_fields(self):
        """Test that papers have required fields"""
        papers = self.connector.search("machine learning", max_results=1)

        assert len(papers) > 0
        paper = papers[0]

        assert paper.paper_id
        assert paper.title
        assert isinstance(paper.authors, list)
        assert paper.url
        assert paper.source == 'arxiv'

    def test_rate_limiting(self):
        """Test that rate limiting is enforced"""
        import time

        start = time.time()
        self.connector.search("test1", max_results=1)
        self.connector.search("test2", max_results=1)
        elapsed = time.time() - start

        # Should take at least 10 seconds due to rate limiting
        assert elapsed >= 10

    def test_search_simplifies_query(self):
        """Test that exact phrases are removed from query"""
        # This query has quotes that would normally fail
        papers = self.connector.search('"exact phrase" query', max_results=1)

        # Should still get results (query simplified internally)
        assert isinstance(papers, list)

    def test_empty_results(self):
        """Test handling of empty results"""
        papers = self.connector.search("xyzabc123nonexistentquerystring", max_results=1)

        assert isinstance(papers, list)
        assert len(papers) == 0


class TestArxivConnectorIntegration:
    """Integration tests for ArXiv connector"""

    def test_realistic_search(self):
        """Test with realistic research queries"""
        connector = ArxivConnector()

        queries = [
            "Bayesian changepoint detection",
            "regime switching models",
            "statistical arbitrage"
        ]

        for query in queries:
            papers = connector.search(query, max_results=5)
            assert isinstance(papers, list)
            # Each query should find at least one paper
            assert len(papers) >= 0  # May be zero in some cases
