from __future__ import annotations

import importlib.util
import os
import time
from dataclasses import asdict, dataclass, field
from io import BytesIO, StringIO
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple


def _setup_windows_dll_paths() -> None:
    try:
        spec = importlib.util.find_spec("tsfile")
        if spec and spec.origin:
            package_dir = os.path.dirname(spec.origin)
            if hasattr(os, "add_dll_directory"):
                os.add_dll_directory(package_dir)
            os.environ["PATH"] = package_dir + os.pathsep + os.environ.get("PATH", "")

        git_mingw_path = r"C:\Program Files\Git\mingw64\bin"
        if os.path.exists(git_mingw_path):
            if hasattr(os, "add_dll_directory"):
                os.add_dll_directory(git_mingw_path)
            os.environ["PATH"] = git_mingw_path + os.pathsep + os.environ.get("PATH", "")
    except Exception:
        # Import should still fail naturally with the original tsfile error if paths are insufficient.
        pass


_setup_windows_dll_paths()

from tsfile import ColumnCategory, ColumnSchema, TSDataType, TableSchema, Tablet, TsFileTableWriter


STEP_NAMES = [
    "decode_source",
    "analyze_dataframe",
    "convert_time_column",
    "build_tablet",
    "write_tsfile",
]

TSFILE_TYPES = {
    "DOUBLE": TSDataType.DOUBLE,
    "FLOAT": TSDataType.FLOAT,
    "INT64": TSDataType.INT64,
    "INT32": TSDataType.INT32,
    "BOOLEAN": TSDataType.BOOLEAN,
    "STRING": TSDataType.STRING,
}


class ConversionError(ValueError):
    """Raised when input data cannot be converted to TsFile."""


@dataclass(frozen=True)
class ConversionOptions:
    table_name: str = "converted_data"
    time_column: str = "time"
    timestamp_unit: str = "auto"
    tablet_rows: int = 262_144
    overwrite: bool = False
    schema: Optional[Mapping[str, str]] = None


@dataclass(frozen=True)
class ConversionResult:
    output_path: str
    input_format: str
    rows: int
    columns: List[str]
    output_bytes: int
    profiling: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def convert_csv_to_tsfile(
    source: Any,
    output_path: Any,
    *,
    options: Optional[ConversionOptions] = None,
    read_csv_kwargs: Optional[Mapping[str, Any]] = None,
) -> ConversionResult:
    """Convert CSV content/path/file-like object to a TsFile."""
    import pandas as pd

    profiling = _new_profiling("csv")
    started = time.perf_counter()
    kwargs = dict(read_csv_kwargs or {})
    df = pd.read_csv(_normalize_csv_source(source), **kwargs)
    _record_step(profiling, "decode_source", started, rows=len(df.index), columns=len(df.columns))
    return convert_dataframe_to_tsfile(df, output_path, input_format="csv", options=options, profiling=profiling)


def convert_parquet_to_tsfile(
    source: Any,
    output_path: Any,
    *,
    options: Optional[ConversionOptions] = None,
    read_parquet_kwargs: Optional[Mapping[str, Any]] = None,
) -> ConversionResult:
    """Convert a Parquet path/file-like object to a TsFile."""
    import pandas as pd

    profiling = _new_profiling("parquet")
    started = time.perf_counter()
    df = pd.read_parquet(source, **dict(read_parquet_kwargs or {}))
    _record_step(profiling, "decode_source", started, rows=len(df.index), columns=len(df.columns))
    return convert_dataframe_to_tsfile(df, output_path, input_format="parquet", options=options, profiling=profiling)


def convert_arrow_to_tsfile(
    source: Any,
    output_path: Any,
    *,
    options: Optional[ConversionOptions] = None,
) -> ConversionResult:
    """Convert Arrow IPC/stream/Feather data to a TsFile."""
    import pyarrow as pa
    import pyarrow.feather as pa_feather
    import pyarrow.ipc as pa_ipc

    profiling = _new_profiling("arrow")
    decode_started = time.perf_counter()
    source_name = _source_name(source)

    if source_name.lower().endswith(".feather"):
        table = pa_feather.read_table(source)
    else:
        payload = _read_arrow_payload(source)
        reader = pa.BufferReader(payload) if isinstance(payload, (bytes, bytearray, memoryview)) else payload
        try:
            table = pa_ipc.open_file(reader).read_all()
        except Exception:
            reader = pa.BufferReader(payload) if isinstance(payload, (bytes, bytearray, memoryview)) else _read_arrow_payload(source)
            table = pa_ipc.open_stream(reader).read_all()

    if table is None or table.num_rows == 0:
        raise ConversionError("Arrow input has no rows")

    df = table.to_pandas()
    _record_step(profiling, "decode_source", decode_started, rows=len(df.index), columns=len(df.columns))
    return convert_dataframe_to_tsfile(df, output_path, input_format="arrow", options=options, profiling=profiling)


def convert_dataframe_to_tsfile(
    df: Any,
    output_path: Any,
    *,
    input_format: str = "dataframe",
    options: Optional[ConversionOptions] = None,
    profiling: Optional[MutableMapping[str, Any]] = None,
) -> ConversionResult:
    """Convert a pandas DataFrame containing one time column and one or more field columns."""
    import pandas as pd

    opts = options or ConversionOptions()
    profiling = profiling or _new_profiling(input_format)
    output = Path(output_path)
    if opts.tablet_rows <= 0:
        raise ConversionError("tablet_rows must be greater than 0")

    if output.exists() and not opts.overwrite:
        raise ConversionError(f"Output already exists: {output}")
    if df is None or df.empty:
        raise ConversionError("Input has no rows")

    analyze_started = time.perf_counter()
    time_col = _locate_time_column(df.columns, opts.time_column)
    field_columns = [col for col in df.columns if col != time_col]
    if not field_columns:
        raise ConversionError("Input needs at least one field column besides the time column")

    field_metas = _build_field_metas(df, field_columns, opts.schema, pd)
    column_names = [meta[1] for meta in field_metas]
    column_types = [meta[2] for meta in field_metas]
    table_schema = TableSchema(
        opts.table_name,
        columns=[ColumnSchema(name, dtype, ColumnCategory.FIELD) for name, dtype in zip(column_names, column_types)],
    )
    _record_step(
        profiling,
        "analyze_dataframe",
        analyze_started,
        time_column=str(time_col),
        field_count=len(field_metas),
    )

    convert_started = time.perf_counter()
    time_ms_series, valid_mask = _convert_time_series_to_millis(df[time_col], pd, opts.timestamp_unit)
    valid_indices = _valid_indices(valid_mask)
    if not valid_indices:
        raise ConversionError("Input has no valid timestamps")
    _record_step(profiling, "convert_time_column", convert_started, valid_rows=len(valid_indices))

    build_ms = 0.0
    tablet_count = 0
    write_started = time.perf_counter()
    write_table_ms = 0.0
    output.parent.mkdir(parents=True, exist_ok=True)
    with TsFileTableWriter(str(output), table_schema) as writer:
        for chunk_indices in _iter_chunks(valid_indices, opts.tablet_rows):
            build_started = time.perf_counter()
            tablet = Tablet(column_names, column_types, len(chunk_indices))
            _fill_tablet_from_dataframe(tablet, df, chunk_indices, time_ms_series, field_metas, pd)
            build_ms += (time.perf_counter() - build_started) * 1000
            tablet_count += 1

            write_table_started = time.perf_counter()
            writer.write_table(tablet)
            write_table_ms += (time.perf_counter() - write_table_started) * 1000

    _set_step(
        profiling,
        "build_tablet",
        round(build_ms, 3),
        rows=len(valid_indices),
        columns=len(column_names),
        tablet_count=tablet_count,
        tablet_rows=opts.tablet_rows,
    )
    _record_step(
        profiling,
        "write_tsfile",
        write_started,
        output_bytes=output.stat().st_size,
        write_table_ms=round(write_table_ms, 3),
    )
    _finalize_profiling(profiling)

    return ConversionResult(
        output_path=str(output),
        input_format=input_format,
        rows=len(valid_indices),
        columns=column_names,
        output_bytes=output.stat().st_size,
        profiling=dict(profiling),
    )


def _new_profiling(input_format: str) -> Dict[str, Any]:
    return {
        "input_format": input_format,
        "steps": [{"name": name, "ms": 0.0} for name in STEP_NAMES],
        "_started_at": time.perf_counter(),
    }


def _record_step(profiling: MutableMapping[str, Any], step_name: str, started_at: float, **extra: Any) -> None:
    _set_step(profiling, step_name, round((time.perf_counter() - started_at) * 1000, 3), **extra)


def _set_step(profiling: MutableMapping[str, Any], step_name: str, ms: float, **extra: Any) -> None:
    for step in profiling.get("steps", []):
        if step.get("name") == step_name:
            step["ms"] = ms
            for key, value in extra.items():
                if value is not None:
                    step[key] = value
            return


def _finalize_profiling(profiling: MutableMapping[str, Any]) -> None:
    started_at = profiling.pop("_started_at", None)
    if started_at is not None:
        profiling["total_ms"] = round((time.perf_counter() - started_at) * 1000, 3)


def _normalize_csv_source(source: Any) -> Any:
    if isinstance(source, bytes):
        return BytesIO(source)
    if isinstance(source, str):
        if "\n" in source or "\r" in source:
            return StringIO(source)
        return source
    return source


def _source_name(source: Any) -> str:
    name = getattr(source, "name", "")
    if name:
        return str(name)
    if isinstance(source, (str, os.PathLike)):
        return str(source)
    return ""


def _read_arrow_payload(source: Any) -> Any:
    if isinstance(source, (bytes, bytearray, memoryview)):
        return bytes(source)
    if isinstance(source, (str, os.PathLike)):
        return Path(source).read_bytes()
    if hasattr(source, "seek"):
        source.seek(0)
    return source.read()


def _locate_time_column(columns: Iterable[Any], expected_name: str) -> Any:
    normalized_expected = expected_name.strip().lower()
    for col in columns:
        if str(col).strip().lower() == normalized_expected:
            return col
    raise ConversionError(f"Missing time column: {expected_name}")


def _build_field_metas(
    df: Any,
    field_columns: Sequence[Any],
    schema: Optional[Mapping[str, str]],
    pd: Any,
) -> List[Tuple[Any, str, Any]]:
    field_metas = []
    seen_names = set()
    for col in field_columns:
        schema_name = str(col)
        if schema_name in seen_names:
            raise ConversionError(f"Duplicate output column name: {schema_name}")
        seen_names.add(schema_name)

        dtype = _schema_dtype(schema, schema_name) if schema else _infer_series_type(df[col], pd)
        field_metas.append((col, schema_name, dtype))
    return field_metas


def _schema_dtype(schema: Optional[Mapping[str, str]], column_name: str) -> Any:
    raw = (schema or {}).get(column_name)
    if raw is None:
        raise ConversionError(f"Schema is missing type for column: {column_name}")
    dtype = TSFILE_TYPES.get(str(raw).strip().upper())
    if dtype is None:
        raise ConversionError(f"Unsupported TsFile type for {column_name}: {raw}")
    return dtype


def _infer_series_type(series: Any, pd: Any) -> Any:
    if pd.api.types.is_bool_dtype(series):
        return TSDataType.BOOLEAN
    if pd.api.types.is_integer_dtype(series):
        return TSDataType.INT64
    if pd.api.types.is_float_dtype(series):
        return TSDataType.DOUBLE
    return TSDataType.STRING


def _convert_time_series_to_millis(series: Any, pd: Any, timestamp_unit: str = "auto") -> Tuple[Any, Any]:
    unit = timestamp_unit.strip().lower()
    if unit not in {"auto", "s", "ms", "us", "ns"}:
        raise ConversionError(f"Unsupported timestamp unit: {timestamp_unit}")

    if pd.api.types.is_datetime64_any_dtype(series):
        time_dt = series
        if hasattr(time_dt.dt, "tz") and time_dt.dt.tz is not None:
            time_dt = time_dt.dt.tz_convert(None)
        valid_mask = ~time_dt.isna()
        return time_dt.astype("int64") // 1_000_000, valid_mask

    if pd.api.types.is_integer_dtype(series) or pd.api.types.is_float_dtype(series) or unit != "auto":
        numeric = pd.to_numeric(series, errors="coerce")
        valid_mask = ~numeric.isna()
        if unit == "auto":
            max_abs_val = numeric[valid_mask].abs().max() if valid_mask.any() else 0
            if max_abs_val >= 1e17:
                divisor = 1_000_000
            elif max_abs_val >= 1e14:
                divisor = 1_000
            elif max_abs_val >= 1e11:
                divisor = 1
            else:
                divisor = 0.001
        else:
            divisor = {"s": 0.001, "ms": 1, "us": 1_000, "ns": 1_000_000}[unit]
        time_ms = (numeric / divisor).where(valid_mask, 0).astype("int64")
        return time_ms, valid_mask

    time_dt = pd.to_datetime(series, errors="coerce")
    valid_mask = ~time_dt.isna()
    return time_dt.astype("int64") // 1_000_000, valid_mask


def _valid_indices(valid_mask: Any) -> List[int]:
    return [idx for idx, is_valid in enumerate(valid_mask.tolist()) if is_valid]


def _iter_chunks(values: Sequence[int], chunk_size: int) -> Iterable[Sequence[int]]:
    for start in range(0, len(values), chunk_size):
        yield values[start : start + chunk_size]


def _fill_tablet_from_dataframe(
    tablet: Any,
    df: Any,
    valid_indices: Sequence[int],
    time_ms_series: Any,
    field_metas: Sequence[Tuple[Any, str, Any]],
    pd: Any,
) -> None:
    tablet.set_timestamp_list([int(value) for value in time_ms_series.iloc[list(valid_indices)].tolist()])
    selected_df = df.iloc[list(valid_indices)] if len(valid_indices) != len(df.index) else df
    value_lists = tablet.get_value_list()
    for col_idx, (col, _schema_name, dtype) in enumerate(field_metas):
        value_lists[col_idx][:] = _coerce_series_to_tablet_values(selected_df[col], dtype, pd)


def _coerce_series_to_tablet_values(series: Any, dtype: Any, pd: Any) -> List[Any]:
    if dtype in (TSDataType.DOUBLE, TSDataType.FLOAT):
        numeric = pd.to_numeric(series, errors="coerce").fillna(0.0)
        values = numeric.astype("float64", copy=False).tolist()
        return values if dtype == TSDataType.DOUBLE else [float(value) for value in values]

    if dtype in (TSDataType.INT64, TSDataType.INT32):
        numeric = pd.to_numeric(series, errors="coerce").fillna(0).astype("int64", copy=False)
        return numeric.tolist()

    if dtype == TSDataType.BOOLEAN:
        return [_coerce_bool(value, pd) for value in series.tolist()]

    raw_values = series.tolist()
    return ["" if pd.isna(value) else str(value) for value in raw_values]


def _coerce_bool(value: Any, pd: Any) -> bool:
    if pd.isna(value):
        return False
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "1", "yes", "y", "t"}:
            return True
        if lowered in {"false", "0", "no", "n", "f", ""}:
            return False
    return bool(value)
