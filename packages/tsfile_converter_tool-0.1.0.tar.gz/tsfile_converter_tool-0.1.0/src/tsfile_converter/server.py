from __future__ import annotations

from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Union

from .converter import (
    ConversionError,
    ConversionOptions,
    convert_arrow_to_tsfile,
    convert_csv_to_tsfile,
    convert_parquet_to_tsfile,
)


def create_app(output_dir: Union[str, Path] = "converted_tsfiles"):
    from flask import Flask, jsonify, request

    app = Flask(__name__)
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)

    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.post("/convert")
    def convert():
        try:
            fmt = (request.form.get("format") or "").strip().lower()
            upload = request.files.get("file")
            csv_content = request.form.get("csv_content")
            if not upload and not csv_content:
                return jsonify({"error": "Provide multipart file or csv_content"}), 400

            if not fmt:
                fmt = _infer_format(upload.filename if upload else "source.csv")
            if fmt not in {"csv", "parquet", "arrow"}:
                return jsonify({"error": "format must be csv, parquet, or arrow"}), 400

            output_name = (request.form.get("output_filename") or "").strip()
            if not output_name:
                output_name = f"{fmt}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.tsfile"
            if not output_name.endswith(".tsfile"):
                output_name += ".tsfile"

            output_path = output_root / Path(output_name).name
            options = ConversionOptions(
                table_name=request.form.get("table_name") or "converted_data",
                time_column=request.form.get("time_column") or "time",
                timestamp_unit=request.form.get("timestamp_unit") or "auto",
                overwrite=(request.form.get("overwrite") or "").lower() in {"1", "true", "yes"},
            )

            with TemporaryDirectory() as temp_dir:
                source = csv_content
                if upload:
                    temp_path = Path(temp_dir) / Path(upload.filename or f"input.{fmt}").name
                    upload.save(temp_path)
                    source = temp_path

                if fmt == "csv":
                    result = convert_csv_to_tsfile(source, output_path, options=options)
                elif fmt == "parquet":
                    result = convert_parquet_to_tsfile(source, output_path, options=options)
                else:
                    result = convert_arrow_to_tsfile(source, output_path, options=options)

            return jsonify(result.to_dict())
        except ConversionError as exc:
            return jsonify({"error": str(exc)}), 400
        except Exception as exc:
            return jsonify({"error": str(exc)}), 500

    return app


def _infer_format(filename: str) -> str:
    suffix = Path(filename or "").suffix.lower()
    if suffix == ".csv":
        return "csv"
    if suffix == ".parquet":
        return "parquet"
    if suffix in {".arrow", ".ipc", ".feather"}:
        return "arrow"
    return ""
