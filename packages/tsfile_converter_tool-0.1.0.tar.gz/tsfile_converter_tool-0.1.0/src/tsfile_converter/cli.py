from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .converter import (
    ConversionError,
    ConversionOptions,
    convert_arrow_to_tsfile,
    convert_csv_to_tsfile,
    convert_parquet_to_tsfile,
)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="tsfile-convert", description="Convert CSV/Parquet/Arrow data to TsFile.")
    parser.add_argument("source", help="Input CSV, Parquet, Arrow IPC, or Feather file.")
    parser.add_argument("output", help="Output .tsfile path.")
    parser.add_argument(
        "--format",
        choices=["auto", "csv", "parquet", "arrow"],
        default="auto",
        help="Input format. Defaults to inferring from the source suffix.",
    )
    parser.add_argument("--time-column", default="time", help="Name of the source time column.")
    parser.add_argument("--table-name", default="converted_data", help="TsFile table name.")
    parser.add_argument(
        "--timestamp-unit",
        choices=["auto", "s", "ms", "us", "ns"],
        default="auto",
        help="Numeric timestamp unit. Defaults to magnitude-based inference.",
    )
    parser.add_argument("--overwrite", action="store_true", help="Overwrite the output file if it exists.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable conversion result JSON.")
    args = parser.parse_args(argv)

    source = Path(args.source)
    fmt = args.format if args.format != "auto" else _infer_format(source)
    options = ConversionOptions(
        table_name=args.table_name,
        time_column=args.time_column,
        timestamp_unit=args.timestamp_unit,
        overwrite=args.overwrite,
    )

    try:
        if fmt == "csv":
            result = convert_csv_to_tsfile(source, args.output, options=options)
        elif fmt == "parquet":
            result = convert_parquet_to_tsfile(source, args.output, options=options)
        else:
            result = convert_arrow_to_tsfile(source, args.output, options=options)
    except ConversionError as exc:
        print(f"tsfile-convert: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"tsfile-convert: unexpected error: {exc}", file=sys.stderr)
        return 1

    payload = result.to_dict()
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(
            f"Converted {payload['rows']} rows and {len(payload['columns'])} columns "
            f"to {payload['output_path']} ({payload['output_bytes']} bytes)."
        )
    return 0


def _infer_format(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return "csv"
    if suffix == ".parquet":
        return "parquet"
    if suffix in {".arrow", ".ipc", ".feather"}:
        return "arrow"
    raise ConversionError(f"Cannot infer input format from suffix: {suffix or '<none>'}")


if __name__ == "__main__":
    raise SystemExit(main())
