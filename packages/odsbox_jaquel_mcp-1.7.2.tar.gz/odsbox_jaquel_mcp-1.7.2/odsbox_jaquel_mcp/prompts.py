"""Starting prompts for the ASAM ODS Jaquel MCP Server.

This module provides helpful starting prompts to guide users on how to use
the server's tools for Jaquel query creation, validation, and ODS data access.
"""

from __future__ import annotations


class PromptLibrary:
    """Collection of starting prompts for the MCP server."""

    @staticmethod
    def get_prompt_content(prompt_name: str, arguments: dict | None = None) -> str:
        """Generate content for a specific prompt.

        Args:
            prompt_name: Name of the prompt
            arguments: Optional arguments for customizing the prompt content

        Returns:
            Prompt content as a formatted string
        """
        arguments = arguments or {}

        if prompt_name == "connect_ods_server":
            server_details = arguments.get("server_details", "")
            content = (
                "# Setting Up ODS Server Connection\n\n"
                "Connect to your ASAM ODS server to enable live data model inspection and query data execution.\n\n"
                "## Connection Steps:\n"
                "1. Use `ods_connect` with your server URL, username, and password\n"
                "2. Verify connection with `ods_get_connection_info`\n"
                "3. Use `schema_test_to_measurement_hierarchy` to explore hierarchy entity relations\n"
                "4. List entities with `schema_list_entities` to explore the entity relationship model\n"
                "5. Generate query templates with `query_generate_skeleton` for specific entity\n"
                "6. Execute queries directly with `query_execute`\n\n"
                "## Available ODS Connection Tools:\n"
                "- `ods_connect` - Establish connection\n"
                "- `ods_disconnect` - Close connection\n"
                "- `ods_get_connection_info` - Check current connection status\n"
                "- `schema_test_to_measurement_hierarchy` - Explore test-measurement relationships\n"
                "- `schema_list_entities` - List available entities in the data model\n"
                "- `query_generate_skeleton` - Create query templates for entity\n"
                "- `query_execute` - Run queries on live server\n\n"
            )
            if server_details:
                content += f"**Your server details:** {server_details}\n"
            return content

        elif prompt_name == "query_validate":
            query_example = arguments.get("query_example", "")
            content = (
                "# Validating Jaquel Queries\n\n"
                "Use the `query_validate` tool to check your Jaquel queries for:\n"
                "- Syntax errors and structural issues\n"
                "- Missing required fields\n"
                "- Invalid operators or comparisons\n"
                "- Best practice violations\n\n"
                "## How to use:\n"
                "1. Call `query_validate` with your query object\n"
                "2. Review the validation report\n"
                "3. Use suggestions to fix any issues\n\n"
            )
            if query_example:
                content += f"**Your query:**\n```json\n{query_example}\n```\n"
            return content

        elif prompt_name == "explore_patterns":
            pattern_type = arguments.get("pattern_type", "")
            content = (
                "# Jaquel Query Patterns\n\n"
                "The MCP server provides templates for common query patterns:\n\n"
                "**Available patterns:**\n"
                "- `get_all_instances` - Retrieve all instances of an entity\n"
                "- `get_by_id` - Get a specific instance by ID\n"
                "- `get_by_name` - Filter by name field\n"
                "- `case_insensitive_search` - Pattern matching without case sensitivity\n"
                "- `time_range` - Filter by date/time ranges\n"
                "- `inner_join` - Join related entities\n"
                "- `outer_join` - Outer join for optional relationships\n"
                "- `aggregates` - Aggregate functions like count, sum, avg\n\n"
                "## How to use:\n"
                "1. Call `query_list_patterns` to see all available patterns\n"
                "2. Use `query_get_pattern` with a specific pattern name\n"
                "3. Adapt the template to your entity and requirements\n"
                "4. Use `query_generate_skeleton` for entity-specific starting points\n\n"
            )
            if pattern_type:
                content += f"**Pattern of interest:** {pattern_type}\n"
            return content

        elif prompt_name == "timeseries_access":
            use_case = arguments.get("use_case", "")
            content = (
                "# Bulk API & Submatrix Data Access\n\n"
                "Efficiently access large timeseries datasets from ODS using the 3-step Bulk API workflow.\n\n"
                "## The 3-Step Workflow:\n"
                "1. **Locate** - Find the submatrix ID you need\n"
                "2. **Access** - Use Bulk API to read the data efficiently\n"
                "3. **Process** - Transform and analyze the data\n\n"
                "## Key Tools:\n"
                "- `data_read_submatrix` - Read data with pattern matching\n"
                "- `data_get_quantities` - List available quantities\n"
                "- `data_generate_fetcher_script` - Generate reusable scripts\n"
                "- `help_bulk_api` - Get detailed guidance\n\n"
                "## Script Generation Types:\n"
                "- `basic` - Simple data fetching\n"
                "- `advanced` - With analysis and visualization\n"
                "- `batch` - For processing multiple submatrices\n"
                "- `analysis` - Statistical analysis included\n\n"
                "## Quick Start:\n"
                "1. Get measurement quantities: `data_get_quantities`\n"
                "2. Read data: `data_read_submatrix` with patterns\n"
                "3. Generate script for reuse: `data_generate_fetcher_script`\n\n"
            )
            if use_case:
                content += f"**Your use case:** {use_case}\n"
            return content

        else:
            return f"Prompt '{prompt_name}' not found."
