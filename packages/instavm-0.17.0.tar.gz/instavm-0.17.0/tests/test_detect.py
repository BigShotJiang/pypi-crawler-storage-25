"""Unit tests for ``instavm._detect`` — zero-config project detection."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from instavm._detect import (
    DeployPlan,
    _collect_secrets,
    _detect_health_path,
    _detect_node,
    _detect_node_pm,
    _detect_port_from_source,
    _detect_python,
    _detect_python_pm,
    _find_deno_main,
    _find_django_wsgi,
    _find_python_app_module,
    _find_static_root,
    _has_static_signals,
    _is_yarn_berry,
    _parse_pipfile_deps,
    _read_node_deps,
    _read_python_deps,
    _scan_env_vars,
    _slugify,
    detect_project,
    plan_to_manifest,
)
from instavm._cookbook import CookbookManifest, SecretSpec

FIXTURES = Path(__file__).parent / "fixtures" / "deploy"


# ── Helpers ──────────────────────────────────────────────────────────────────


def _fixture(name: str) -> Path:
    return FIXTURES / name


def _load_pkg(name: str) -> dict:
    return json.loads((_fixture(name) / "package.json").read_text())


# ── Slugify ──────────────────────────────────────────────────────────────────


class TestSlugify:
    def test_simple_name(self):
        assert _slugify("my-app") == "my-app"

    def test_spaces_and_uppercase(self):
        assert _slugify("My Cool App") == "my-cool-app"

    def test_scoped_npm_package(self):
        assert _slugify("@openai/agents") == "openai-agents"

    def test_empty_falls_back(self):
        assert _slugify("") == "app"
        assert _slugify("---") == "app"


# ── Package Manager Detection ────────────────────────────────────────────────


class TestNodePM:
    def test_npm_default(self):
        assert _detect_node_pm(_fixture("11-node-npm-basic"), _load_pkg("11-node-npm-basic")) == "npm"

    def test_yarn(self):
        assert _detect_node_pm(_fixture("13-node-yarn"), _load_pkg("13-node-yarn")) == "yarn"

    def test_pnpm(self):
        assert _detect_node_pm(_fixture("14-node-pnpm"), _load_pkg("14-node-pnpm")) == "pnpm"

    def test_bun(self):
        assert _detect_node_pm(_fixture("15-node-bun"), _load_pkg("15-node-bun")) == "bun"

    def test_packagemanager_field_pnpm(self):
        assert _detect_node_pm(_fixture("32-node-packagemanager"), _load_pkg("32-node-packagemanager")) == "pnpm"

    def test_packagemanager_field_yarn(self):
        assert _detect_node_pm(_fixture("35-node-yarn-berry"), _load_pkg("35-node-yarn-berry")) == "yarn"

    def test_packagemanager_overrides_lockfile(self):
        """packageManager field should take priority over lockfiles."""
        # 32 has packageManager=pnpm but no lockfile
        plan = detect_project(_fixture("32-node-packagemanager"))
        assert plan.package_manager == "pnpm"


class TestYarnBerry:
    def test_is_berry_from_version(self):
        pkg = {"packageManager": "yarn@4.0.0"}
        assert _is_yarn_berry(Path("/nonexistent"), pkg) is True

    def test_is_not_berry_from_version(self):
        pkg = {"packageManager": "yarn@1.22.0"}
        assert _is_yarn_berry(Path("/nonexistent"), pkg) is False

    def test_is_berry_from_yarnrc(self):
        assert _is_yarn_berry(_fixture("35-node-yarn-berry"), {}) is True

    def test_35_yarn_berry_install_command(self):
        plan = detect_project(_fixture("35-node-yarn-berry"))
        assert plan.package_manager == "yarn"
        assert plan.install_command == "corepack enable >/dev/null 2>&1 && yarn install --check-cache"
        assert plan.start_command == "corepack enable >/dev/null 2>&1 && yarn start"

    def test_13_yarn_classic_install_command(self):
        plan = detect_project(_fixture("13-node-yarn"))
        assert plan.install_command == "corepack enable >/dev/null 2>&1 && yarn install --frozen-lockfile"


class TestPythonPM:
    def test_pip_default(self):
        assert _detect_python_pm(_fixture("01-python-fastapi")) == "pip"

    def test_poetry(self):
        assert _detect_python_pm(_fixture("05-python-poetry")) == "poetry"

    def test_uv(self):
        assert _detect_python_pm(_fixture("06-python-uv")) == "uv"

    def test_pipenv(self):
        assert _detect_python_pm(_fixture("31-python-pipenv")) == "pipenv"

    def test_pdm(self):
        assert _detect_python_pm(_fixture("33-python-pdm")) == "pdm"


# ── Dependency Reading ───────────────────────────────────────────────────────


class TestReadDeps:
    def test_python_requirements(self):
        deps = _read_python_deps(_fixture("01-python-fastapi"))
        assert "fastapi==0.128.8" in deps
        assert "uvicorn[standard]==0.39.0" in deps

    def test_python_empty_dir(self):
        deps = _read_python_deps(_fixture("19-negative-empty"))
        assert deps == []

    def test_node_deps(self):
        pkg = json.loads((_fixture("16-node-openai-agents") / "package.json").read_text())
        deps = _read_node_deps(pkg)
        assert "@openai/agents" in deps
        assert "next" in deps

    def test_pipfile_deps(self):
        deps = _parse_pipfile_deps(_fixture("31-python-pipenv") / "Pipfile")
        assert "fastapi" in deps
        assert "uvicorn" in deps
        # dev-packages should NOT be included
        assert "pytest" not in deps

    def test_pipenv_deps_via_read_python_deps(self):
        deps = _read_python_deps(_fixture("31-python-pipenv"))
        assert "fastapi" in deps
        assert "uvicorn" in deps

    def test_pdm_deps_via_pyproject(self):
        deps = _read_python_deps(_fixture("33-python-pdm"))
        assert any("fastapi" in d for d in deps)
        assert any("uvicorn" in d for d in deps)


# ── App Module Detection ─────────────────────────────────────────────────────


class TestFindPythonAppModule:
    def test_finds_app_py(self):
        assert _find_python_app_module(_fixture("01-python-fastapi")) == "app"

    def test_defaults_to_app(self):
        assert _find_python_app_module(_fixture("19-negative-empty")) == "app"

    def test_finds_main_py(self):
        assert _find_python_app_module(_fixture("34-python-fasthtml")) == "main"


# ── Port Detection ───────────────────────────────────────────────────────────


class TestPortDetection:
    def test_port_from_source_node(self):
        port = _detect_port_from_source(
            _fixture("11-node-npm-basic"),
            ["server.js"],
        )
        assert port == 3000

    def test_port_from_source_yarn(self):
        port = _detect_port_from_source(
            _fixture("13-node-yarn"),
            ["index.js"],
        )
        assert port == 4000

    def test_port_from_source_main_field(self):
        port = _detect_port_from_source(
            _fixture("22-node-main-field"),
            ["server.js"],
        )
        assert port == 5000

    def test_no_port_file(self):
        port = _detect_port_from_source(
            _fixture("19-negative-empty"),
            ["server.js"],
        )
        assert port is None


# ── Health Path Detection ────────────────────────────────────────────────────


class TestHealthPath:
    def test_detects_health_route_python(self):
        path = _detect_health_path(_fixture("01-python-fastapi"))
        assert path == "/health"

    def test_detects_api_health_route(self):
        path = _detect_health_path(_fixture("06-python-uv"))
        assert path == "/api/health"

    def test_defaults_to_health(self):
        path = _detect_health_path(_fixture("19-negative-empty"))
        assert path == "/health"


# ── Env Var Scanning ─────────────────────────────────────────────────────────


class TestScanEnvVars:
    def test_python_env_vars(self):
        found = _scan_env_vars(_fixture("08-python-google-adk"), "python")
        assert "GOOGLE_API_KEY" in found
        assert "GEMINI_API_KEY" in found

    def test_python_env_vars_recursive(self, tmp_path):
        nested = tmp_path / "src" / "utils"
        nested.mkdir(parents=True)
        (nested / "config.py").write_text(
            'import os\nAPI_KEY = os.getenv("DEEP_SECRET_KEY")\n',
            encoding="utf-8",
        )
        found = _scan_env_vars(tmp_path, "python")
        assert "DEEP_SECRET_KEY" in found

    def test_python_dspy_env_vars(self):
        found = _scan_env_vars(_fixture("10-python-dspy"), "python")
        assert "OPENROUTER_API_KEY" in found

    def test_node_env_vars(self):
        found = _scan_env_vars(_fixture("17-node-ai-sdk-anthropic"), "node")
        assert "ANTHROPIC_API_KEY" in found

    def test_empty_dir(self):
        found = _scan_env_vars(_fixture("19-negative-empty"), "python")
        assert found == set()

    def test_go_env_vars(self):
        found = _scan_env_vars(_fixture("27-go-basic"), "go")
        assert "API_KEY" in found

    def test_deno_env_vars(self):
        """Deno.env.get not used in 29, so should be empty."""
        found = _scan_env_vars(_fixture("29-deno-basic"), "deno")
        # our basic fixture has no Deno.env.get calls
        assert "PORT" not in found


# ── Secret Collection ────────────────────────────────────────────────────────


class TestCollectSecrets:
    def test_python_openai_agents(self):
        secrets = _collect_secrets(
            _fixture("07-python-openai-agents"),
            ["openai-agents", "fastapi", "uvicorn"],
            "python",
        )
        env_names = [s.env_name for s in secrets]
        assert "OPENAI_API_KEY" in env_names

    def test_python_google_adk(self):
        secrets = _collect_secrets(
            _fixture("08-python-google-adk"),
            ["google-adk", "fastapi", "uvicorn"],
            "python",
        )
        env_names = [s.env_name for s in secrets]
        assert "GOOGLE_API_KEY" in env_names
        # GEMINI_API_KEY found via env scan
        assert "GEMINI_API_KEY" in env_names

    def test_node_anthropic_sdk(self):
        secrets = _collect_secrets(
            _fixture("17-node-ai-sdk-anthropic"),
            ["@ai-sdk/anthropic", "ai", "express"],
            "node",
        )
        env_names = [s.env_name for s in secrets]
        assert "ANTHROPIC_API_KEY" in env_names

    def test_no_secrets_basic(self):
        secrets = _collect_secrets(
            _fixture("01-python-fastapi"),
            ["fastapi", "uvicorn"],
            "python",
        )
        # No SDK deps, no env vars in source → no secrets (or just PORT-type excluded)
        env_names = [s.env_name for s in secrets]
        assert "OPENAI_API_KEY" not in env_names
        assert "ANTHROPIC_API_KEY" not in env_names


# ── Full Detection: Python ───────────────────────────────────────────────────


class TestDetectPython:
    def test_01_fastapi(self):
        plan = detect_project(_fixture("01-python-fastapi"))
        assert plan.runtime == "python"
        assert plan.package_manager == "pip"
        assert plan.install_command == "pip install -r requirements.txt"
        assert plan.build_command is None
        assert "uvicorn" in plan.start_command
        assert "app:app" in plan.start_command
        assert "--host 0.0.0.0" in plan.start_command
        assert plan.port == 8000
        assert plan.health_path == "/health"

    def test_02_flask(self):
        plan = detect_project(_fixture("02-python-flask"))
        assert plan.runtime == "python"
        assert "flask" in plan.start_command.lower()
        assert plan.port == 8000

    def test_03_gunicorn(self):
        plan = detect_project(_fixture("03-python-gunicorn"))
        assert plan.runtime == "python"
        assert "gunicorn" in plan.start_command
        assert "app:app" in plan.start_command

    def test_04_streamlit(self):
        plan = detect_project(_fixture("04-python-streamlit"))
        assert plan.runtime == "python"
        assert "streamlit" in plan.start_command
        assert "app.py" in plan.start_command

    def test_05_poetry(self):
        plan = detect_project(_fixture("05-python-poetry"))
        assert plan.runtime == "python"
        assert plan.package_manager == "poetry"
        assert plan.install_command == "poetry install"

    def test_06_uv(self):
        plan = detect_project(_fixture("06-python-uv"))
        assert plan.runtime == "python"
        assert plan.package_manager == "uv"
        assert plan.install_command == "uv sync"
        assert plan.health_path == "/api/health"

    def test_07_openai_agents(self):
        plan = detect_project(_fixture("07-python-openai-agents"))
        assert plan.runtime == "python"
        env_names = [s.env_name for s in plan.secrets]
        assert "OPENAI_API_KEY" in env_names

    def test_08_google_adk(self):
        plan = detect_project(_fixture("08-python-google-adk"))
        env_names = [s.env_name for s in plan.secrets]
        assert "GOOGLE_API_KEY" in env_names

    def test_09_anthropic(self):
        plan = detect_project(_fixture("09-python-anthropic"))
        env_names = [s.env_name for s in plan.secrets]
        assert "ANTHROPIC_API_KEY" in env_names

    def test_10_dspy(self):
        plan = detect_project(_fixture("10-python-dspy"))
        env_names = [s.env_name for s in plan.secrets]
        assert "OPENROUTER_API_KEY" in env_names


# ── Full Detection: Node ─────────────────────────────────────────────────────


class TestDetectNode:
    def test_11_npm_basic(self):
        plan = detect_project(_fixture("11-node-npm-basic"))
        assert plan.runtime == "node"
        assert plan.package_manager == "npm"
        assert plan.install_command == "npm install"
        assert plan.start_command == "npm start"
        assert plan.port == 3000
        assert plan.health_path == "/health"

    def test_12_npm_build(self):
        plan = detect_project(_fixture("12-node-npm-build"))
        assert plan.runtime == "node"
        assert plan.package_manager == "npm"
        assert plan.install_command == "npm ci"  # has package-lock.json
        assert plan.build_command == "npm run build"
        assert plan.start_command == "npm start"

    def test_13_yarn(self):
        plan = detect_project(_fixture("13-node-yarn"))
        assert plan.package_manager == "yarn"
        assert plan.install_command == "yarn install --frozen-lockfile"
        assert plan.start_command == "yarn start"
        assert plan.port == 4000  # from index.js source scan

    def test_14_pnpm(self):
        plan = detect_project(_fixture("14-node-pnpm"))
        assert plan.package_manager == "pnpm"
        assert plan.install_command == "pnpm install"
        assert plan.start_command == "pnpm start"

    def test_15_bun(self):
        plan = detect_project(_fixture("15-node-bun"))
        assert plan.package_manager == "bun"
        assert plan.install_command == "bun install"
        assert plan.start_command == "bun start"

    def test_16_openai_agents_js(self):
        plan = detect_project(_fixture("16-node-openai-agents"))
        assert plan.runtime == "node"
        env_names = [s.env_name for s in plan.secrets]
        assert "OPENAI_API_KEY" in env_names
        assert plan.build_command == "npm run build"

    def test_17_ai_sdk_anthropic(self):
        plan = detect_project(_fixture("17-node-ai-sdk-anthropic"))
        env_names = [s.env_name for s in plan.secrets]
        assert "ANTHROPIC_API_KEY" in env_names

    def test_18_ai_sdk_google(self):
        plan = detect_project(_fixture("18-node-ai-sdk-google"))
        env_names = [s.env_name for s in plan.secrets]
        assert "GOOGLE_API_KEY" in env_names

    def test_22_main_field_fallback(self):
        plan = detect_project(_fixture("22-node-main-field"))
        assert plan.start_command == "node server.js"
        assert plan.port == 5000


# ── Full Detection: Static ───────────────────────────────────────────────────


class TestDetectStatic:
    def test_23_static_index_root(self):
        plan = detect_project(_fixture("23-static-index-root"))
        assert plan.runtime == "static"
        assert plan.package_manager == "none"
        assert "--directory ." in plan.start_command
        assert plan.port == 3000
        assert plan.health_path == "/"

    def test_24_static_public(self):
        plan = detect_project(_fixture("24-static-public"))
        assert plan.runtime == "static"
        assert "--directory public" in plan.start_command

    def test_25_static_dist(self):
        plan = detect_project(_fixture("25-static-dist"))
        assert plan.runtime == "static"
        assert "--directory dist" in plan.start_command

    def test_26_static_build(self):
        plan = detect_project(_fixture("26-static-build"))
        assert plan.runtime == "static"
        assert "--directory build" in plan.start_command

    def test_public_preferred_over_root(self, tmp_path):
        """public/ should be preferred over root index.html."""
        (tmp_path / "index.html").write_text("<html></html>")
        (tmp_path / "public").mkdir()
        (tmp_path / "public" / "index.html").write_text("<html></html>")
        plan = detect_project(tmp_path)
        assert "--directory public" in plan.start_command

    def test_node_with_index_not_static(self, tmp_path):
        """Node project with index.html should be detected as node, not static."""
        (tmp_path / "index.html").write_text("<html></html>")
        (tmp_path / "package.json").write_text(json.dumps({
            "name": "test",
            "scripts": {"start": "node server.js"},
            "dependencies": {"express": "^5.0.0"},
        }))
        (tmp_path / "server.js").write_text(
            "const e = require('express'); e().listen(3000);"
        )
        plan = detect_project(tmp_path)
        assert plan.runtime == "node"

    def test_has_static_signals(self):
        assert _has_static_signals(_fixture("23-static-index-root"))
        assert _has_static_signals(_fixture("24-static-public"))
        assert not _has_static_signals(_fixture("19-negative-empty"))

    def test_find_static_root_public(self):
        assert _find_static_root(_fixture("24-static-public")) == "public"

    def test_find_static_root_dot(self):
        assert _find_static_root(_fixture("23-static-index-root")) == "."


# ── Full Detection: Go ───────────────────────────────────────────────────────


class TestDetectGo:
    def test_27_go_basic(self):
        plan = detect_project(_fixture("27-go-basic"))
        assert plan.runtime == "go"
        assert plan.package_manager == "go"
        assert "go build" in plan.build_command
        assert plan.start_command == "./app"
        assert plan.port == 8080
        assert plan.health_path == "/health"

    def test_28_go_cmd(self):
        plan = detect_project(_fixture("28-go-cmd"))
        assert plan.runtime == "go"
        assert "./cmd/server" in plan.build_command
        assert plan.port == 9090
        assert plan.health_path == "/health"

    def test_go_env_scan(self):
        found = _scan_env_vars(_fixture("27-go-basic"), "go")
        assert "API_KEY" in found

    def test_go_manifest(self):
        plan = detect_project(_fixture("27-go-basic"))
        manifest = plan_to_manifest(plan, _fixture("27-go-basic"))
        assert "dl.google.com/go/go" in manifest.source.setup_command
        assert "go build" in manifest.source.setup_command
        assert manifest.run.start_command == "./app"
        assert manifest.app.port == 8080

    def test_go_scanned_env_vars_are_optional(self):
        plan = detect_project(_fixture("27-go-basic"))
        api_key = next(secret for secret in plan.secrets if secret.env_name == "API_KEY")
        assert api_key.required is False


# ── Full Detection: Deno ─────────────────────────────────────────────────────


class TestDetectDeno:
    def test_29_deno_basic(self):
        plan = detect_project(_fixture("29-deno-basic"))
        assert plan.runtime == "deno"
        assert plan.package_manager == "deno"
        assert "deno run --allow-all main.ts" in plan.start_command
        assert plan.port == 8000
        assert plan.health_path == "/"

    def test_deno_server_ts_fallback(self, tmp_path):
        """If no main.ts, should find server.ts."""
        (tmp_path / "deno.json").write_text("{}")
        (tmp_path / "server.ts").write_text("Deno.serve({ port: 9000 }, () => new Response('ok'));")
        plan = detect_project(tmp_path)
        assert plan.runtime == "deno"
        assert "server.ts" in plan.start_command
        assert plan.port == 9000

    def test_deno_no_main_file(self, tmp_path):
        """Should error if deno.json exists but no main file found."""
        (tmp_path / "deno.json").write_text("{}")
        with pytest.raises(ValueError, match="Could not detect start command"):
            detect_project(tmp_path)

    def test_deno_manifest(self):
        plan = detect_project(_fixture("29-deno-basic"))
        manifest = plan_to_manifest(plan, _fixture("29-deno-basic"))
        assert "curl" in manifest.source.setup_command
        assert "deno" in manifest.run.start_command
        assert manifest.app.port == 8000

    def test_find_deno_main(self):
        assert _find_deno_main(_fixture("29-deno-basic")) == "main.ts"
        assert _find_deno_main(_fixture("19-negative-empty")) is None


# ── Full Detection: Django ───────────────────────────────────────────────────


class TestDetectDjango:
    def test_30_django_gunicorn(self):
        plan = detect_project(_fixture("30-python-django"))
        assert plan.runtime == "python"
        assert "manage.py migrate" in plan.start_command
        assert "gunicorn" in plan.start_command
        assert "mysite.wsgi:application" in plan.start_command

    def test_django_without_gunicorn(self, tmp_path):
        """Django without gunicorn should use runserver."""
        (tmp_path / "requirements.txt").write_text("django==5.1\n")
        (tmp_path / "manage.py").write_text("# manage.py")
        (tmp_path / "myapp").mkdir()
        (tmp_path / "myapp" / "settings.py").write_text(
            "WSGI_APPLICATION = 'myapp.wsgi.application'"
        )
        plan = detect_project(tmp_path)
        assert "runserver" in plan.start_command
        assert "gunicorn" not in plan.start_command

    def test_django_wsgi_extraction(self):
        wsgi = _find_django_wsgi(_fixture("30-python-django"))
        assert wsgi == "mysite.wsgi"

    def test_django_not_detected_without_manage_py(self, tmp_path):
        """django in deps but no manage.py → should NOT use Django start command."""
        (tmp_path / "requirements.txt").write_text("django==5.1\nuvicorn==0.39.0\n")
        (tmp_path / "app.py").write_text("from fastapi import FastAPI\napp = FastAPI()")
        plan = detect_project(tmp_path)
        assert "manage.py" not in plan.start_command
        assert "uvicorn" in plan.start_command


# ── Full Detection: Pipenv ───────────────────────────────────────────────────


class TestDetectPipenv:
    def test_31_pipenv_with_lock(self):
        plan = detect_project(_fixture("31-python-pipenv"))
        assert plan.runtime == "python"
        assert plan.package_manager == "pipenv"
        assert plan.install_command == "pipenv install --deploy"
        assert "uvicorn" in plan.start_command

    def test_pipenv_without_lock(self, tmp_path):
        """Pipfile without lockfile should use plain pipenv install."""
        (tmp_path / "Pipfile").write_text("[packages]\nfastapi = \"*\"\nuvicorn = \"*\"\n")
        (tmp_path / "app.py").write_text("from fastapi import FastAPI\napp = FastAPI()")
        plan = detect_project(tmp_path)
        assert plan.package_manager == "pipenv"
        assert plan.install_command == "pipenv install"


# ── Full Detection: PDM ──────────────────────────────────────────────────────


class TestDetectPDM:
    def test_33_pdm_basic(self):
        plan = detect_project(_fixture("33-python-pdm"))
        assert plan.runtime == "python"
        assert plan.package_manager == "pdm"
        assert plan.install_command == "pdm install"
        assert "uvicorn" in plan.start_command

    def test_pdm_reads_pyproject_deps(self):
        deps = _read_python_deps(_fixture("33-python-pdm"))
        assert any("fastapi" in d for d in deps)


# ── Full Detection: FastHTML ─────────────────────────────────────────────────


class TestDetectFastHTML:
    def test_34_fasthtml_with_uvicorn(self):
        plan = detect_project(_fixture("34-python-fasthtml"))
        assert plan.runtime == "python"
        assert "uvicorn" in plan.start_command
        assert "main:app" in plan.start_command

    def test_fasthtml_without_uvicorn(self, tmp_path):
        """FastHTML without explicit uvicorn dep should still use uvicorn (bundled)."""
        (tmp_path / "requirements.txt").write_text("python-fasthtml==0.12.0\n")
        (tmp_path / "main.py").write_text("from fasthtml.common import fast_app\napp, rt = fast_app()")
        plan = detect_project(tmp_path)
        assert "uvicorn" in plan.start_command


# ── Full Detection: packageManager field ─────────────────────────────────────


class TestNodePackageManagerField:
    def test_32_packagemanager_pnpm(self):
        plan = detect_project(_fixture("32-node-packagemanager"))
        assert plan.package_manager == "pnpm"
        assert plan.install_command == "corepack enable >/dev/null 2>&1 && pnpm install"
        assert plan.start_command == "corepack enable >/dev/null 2>&1 && pnpm start"

    def test_35_yarn_berry(self):
        plan = detect_project(_fixture("35-node-yarn-berry"))
        assert plan.package_manager == "yarn"
        assert plan.install_command == "corepack enable >/dev/null 2>&1 && yarn install --check-cache"


# ── Negative Cases ───────────────────────────────────────────────────────────


class TestNegativeCases:
    def test_19_empty_dir(self):
        with pytest.raises(ValueError, match="Could not detect project type"):
            detect_project(_fixture("19-negative-empty"))

    def test_20_no_framework(self):
        with pytest.raises(ValueError, match="Could not detect start command"):
            detect_project(_fixture("20-negative-no-framework"))

    def test_21_no_start_script(self):
        with pytest.raises(ValueError, match="Could not detect start command"):
            detect_project(_fixture("21-node-no-start"))

    def test_nonexistent_dir(self):
        with pytest.raises(ValueError, match="Not a directory"):
            detect_project(Path("/nonexistent/dir"))


# ── plan_to_manifest ─────────────────────────────────────────────────────────


class TestPlanToManifest:
    def test_basic_conversion(self):
        plan = detect_project(_fixture("01-python-fastapi"))
        manifest = plan_to_manifest(plan, _fixture("01-python-fastapi"))
        assert isinstance(manifest, CookbookManifest)
        assert manifest.deploy.kind == "upload_and_run"
        assert manifest.app.port == 8000
        assert manifest.app.healthcheck_path == "/health"
        assert manifest.vm.memory_mb == 2048
        assert manifest.vm.vcpu_count == 2
        assert manifest.run.start_command == plan.start_command
        assert "pip install" in manifest.source.setup_command

    def test_build_command_in_setup(self):
        plan = detect_project(_fixture("12-node-npm-build"))
        manifest = plan_to_manifest(plan, _fixture("12-node-npm-build"))
        assert "npm ci" in manifest.source.setup_command
        assert "npm run build" in manifest.source.setup_command

    def test_no_build_command(self):
        plan = detect_project(_fixture("11-node-npm-basic"))
        manifest = plan_to_manifest(plan, _fixture("11-node-npm-basic"))
        assert "npm run build" not in manifest.source.setup_command

    def test_static_manifest_no_dist_exclude(self):
        plan = detect_project(_fixture("25-static-dist"))
        manifest = plan_to_manifest(plan, _fixture("25-static-dist"))
        # static sites should NOT exclude dist/build from source
        assert "dist" not in manifest.source.exclude
        assert "dist/*" not in manifest.source.exclude
        assert manifest.app.port == 3000
        assert manifest.app.healthcheck_path == "/"

    def test_node_manifest_has_dist_exclude(self):
        plan = detect_project(_fixture("11-node-npm-basic"))
        manifest = plan_to_manifest(plan, _fixture("11-node-npm-basic"))
        assert "dist" in manifest.source.exclude

    def test_go_manifest_setup(self):
        plan = detect_project(_fixture("27-go-basic"))
        manifest = plan_to_manifest(plan, _fixture("27-go-basic"))
        # Go setup should contain install + build
        assert "dl.google.com/go/go" in manifest.source.setup_command
        assert "go build" in manifest.source.setup_command
        # Start is just ./app, no NVM prefix
        assert "nvm" not in manifest.run.start_command

    def test_deno_manifest_setup(self):
        plan = detect_project(_fixture("29-deno-basic"))
        manifest = plan_to_manifest(plan, _fixture("29-deno-basic"))
        assert "curl" in manifest.source.setup_command
        assert "nvm" not in manifest.run.start_command


# ── Real Cookbook Detection ───────────────────────────────────────────────────


COOKBOOKS_DIR = Path.home() / "Documents" / "projects" / "cookbooks"


@pytest.mark.skipif(
    not COOKBOOKS_DIR.exists(),
    reason="Cookbooks directory not found",
)
class TestRealCookbooks:
    """Smoke tests against the actual cookbook apps on this machine."""

    def test_hello_fastapi(self):
        plan = detect_project(COOKBOOKS_DIR / "hello-fastapi")
        assert plan.runtime == "python"
        assert plan.package_manager == "pip"
        assert plan.port == 8000
        assert "uvicorn" in plan.start_command
        assert plan.health_path == "/health"

    def test_openai_agents_python(self):
        plan = detect_project(COOKBOOKS_DIR / "openai-agents-python-research")
        assert plan.runtime == "python"
        env_names = [s.env_name for s in plan.secrets]
        assert "OPENAI_API_KEY" in env_names

    def test_google_adk(self):
        plan = detect_project(COOKBOOKS_DIR / "google-adk-web-chat")
        assert plan.runtime == "python"
        env_names = [s.env_name for s in plan.secrets]
        assert "GOOGLE_API_KEY" in env_names

    def test_dspy(self):
        plan = detect_project(COOKBOOKS_DIR / "dspy-hosted-chat")
        assert plan.runtime == "python"
        env_names = [s.env_name for s in plan.secrets]
        assert "OPENROUTER_API_KEY" in env_names

    def test_claude_chatapp(self):
        plan = detect_project(COOKBOOKS_DIR / "claude-simple-chatapp")
        assert plan.runtime == "node"
        assert plan.package_manager == "npm"
        assert plan.build_command == "npm run build"
        env_names = [s.env_name for s in plan.secrets]
        assert "ANTHROPIC_API_KEY" in env_names

    def test_openai_agents_js(self):
        plan = detect_project(COOKBOOKS_DIR / "openai-agents-js-chat")
        assert plan.runtime == "node"
        assert plan.build_command == "npm run build"
        env_names = [s.env_name for s in plan.secrets]
        assert "OPENAI_API_KEY" in env_names

    def test_neon_city_webgl(self):
        plan = detect_project(COOKBOOKS_DIR / "neon-city-webgl")
        assert plan.runtime == "node"
        assert plan.build_command == "npm run build"
        # neon-city has serve script, no start → should use serve
        assert "serve" in plan.start_command or "node" in plan.start_command
