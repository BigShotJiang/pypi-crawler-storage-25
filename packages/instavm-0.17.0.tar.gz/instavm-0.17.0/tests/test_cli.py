import base64
import json
import os
import stat
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import pytest

import instavm.cli as cli
from instavm import _detect
from instavm import _cookbook
from instavm import _cli_config as cli_config
from instavm.exceptions import InstaVMError


def _set_home(monkeypatch, tmp_path):
    monkeypatch.setattr(cli_config, "get_home_dir", lambda: tmp_path)


def test_update_profile_settings_writes_secure_config(tmp_path, monkeypatch):
    _set_home(monkeypatch, tmp_path)

    config_path = cli_config.update_profile_settings(
        api_key="instavm_sk_test_1234567890",
        base_url="https://api.instavm.io",
    )

    assert config_path == tmp_path / ".instavm" / "config.json"
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    assert payload["schema_version"] == 1
    assert payload["profiles"]["default"]["auth"]["api_key"] == "instavm_sk_test_1234567890"
    assert payload["profiles"]["default"]["base_url"] == "https://api.instavm.io"

    if os.name != "nt":
        assert stat.S_IMODE(config_path.parent.stat().st_mode) == 0o700
        assert stat.S_IMODE(config_path.stat().st_mode) == 0o600


def test_resolve_runtime_config_prefers_flags_then_env_then_config(tmp_path, monkeypatch):
    _set_home(monkeypatch, tmp_path)
    cli_config.update_profile_settings(api_key="stored_key")

    monkeypatch.setenv("INSTAVM_API_KEY", "env_key")
    monkeypatch.setenv("INSTAVM_BASE_URL", "https://staging.api.instavm.io")

    resolved = cli_config.resolve_runtime_config(api_key="flag_key")
    assert resolved.api_key == "flag_key"
    assert resolved.api_key_source == "flag"
    assert resolved.base_url == "https://staging.api.instavm.io"
    assert resolved.base_url_source == "env"
    assert resolved.ssh_host == "staging.instavm.dev"
    assert resolved.ssh_host_source == "derived"

    fallback = cli_config.resolve_runtime_config()
    assert fallback.api_key == "env_key"
    assert fallback.api_key_source == "env"


def test_redact_secret_and_ssh_host_derivation():
    assert cli_config.redact_secret("instavm_sk_1234567890") == "instavm_...7890"
    assert cli_config.derive_ssh_host("https://api.instavm.io") == "instavm.dev"
    assert cli_config.derive_ssh_host("https://staging.api.instavm.io") == "staging.instavm.dev"


def test_auth_set_key_and_status_json(tmp_path, monkeypatch, capsys):
    _set_home(monkeypatch, tmp_path)
    monkeypatch.setattr(cli.sys.stdin, "isatty", lambda: True)
    monkeypatch.setattr(cli.getpass, "getpass", lambda prompt: "instavm_sk_test_1234567890")

    assert cli.main(["auth", "set-key", "--json"]) == 0
    set_key_payload = json.loads(capsys.readouterr().out)
    assert set_key_payload["status"] == "stored"

    assert cli.main(["auth", "status", "--json"]) == 0
    status_payload = json.loads(capsys.readouterr().out)
    assert status_payload["api_key"]["source"] == "config"
    assert status_payload["api_key"]["configured"] is True
    assert status_payload["api_key"]["redacted"] == "instavm_...7890"


def test_auth_set_key_reads_stdin_when_not_tty(tmp_path, monkeypatch, capsys):
    _set_home(monkeypatch, tmp_path)
    monkeypatch.setattr(cli.sys.stdin, "isatty", lambda: False)
    monkeypatch.setattr(cli.sys.stdin, "read", lambda: "instavm_sk_pipe_1234567890\n")

    assert cli.main(["auth", "set-key", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["status"] == "stored"
    assert payload["api_key"] == "instavm_...7890"


def test_whoami_json_output(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def get_current_user(self):
            return {"id": 7, "email": "cli@example.com", "name": "CLI", "is_verified": True}

        def list_ssh_keys(self):
            return [{"id": 11, "fingerprint": "SHA256:abc", "comment": "laptop"}]

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["whoami", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["email"] == "cli@example.com"
    assert payload["ssh_keys"][0]["fingerprint"] == "SHA256:abc"


def test_whoami_text_output_is_grouped(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def get_current_user(self):
            return {"id": 7, "email": "cli@example.com", "name": "CLI", "is_verified": True}

        def list_ssh_keys(self):
            return [{"id": 11, "fingerprint": "SHA256:abc", "comment": "laptop"}]

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["whoami", "--api-key", "instavm_sk_test"]) == 0
    output = capsys.readouterr().out
    assert "Account" in output
    assert "SSH Keys (1)" in output
    assert "Fingerprint" in output
    assert "laptop" in output


def test_ls_filters_to_active_vms_by_default_and_supports_all_alias(monkeypatch, capsys):
    class FakeVMs:
        def list(self):
            return [
                {"vm_id": "vm_dead", "status": "killed"},
                {"vm_id": "vm_live", "status": "active"},
            ]

        def list_all_records(self):
            return [
                {"vm_id": "vm_dead", "status": "killed"},
                {"vm_id": "vm_live", "status": "active"},
            ]

    class FakeClient:
        def __init__(self, **kwargs):
            self.vms = FakeVMs()

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["ls", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert [vm["vm_id"] for vm in payload["vms"]] == ["vm_live"]

    assert cli.main(["ls", "-all", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert [vm["vm_id"] for vm in payload["vms"]] == ["vm_dead", "vm_live"]


def test_ls_text_output_has_headings(monkeypatch, capsys):
    class FakeVMs:
        def list(self):
            return [{"vm_id": "vm_live", "status": "active", "created_at": "2026-03-28T00:00:00Z", "ssh_host": "vm_live@instavm.dev"}]

    class FakeClient:
        def __init__(self, **kwargs):
            self.vms = FakeVMs()

    monkeypatch.setattr(cli, "InstaVM", FakeClient)
    monkeypatch.setattr(cli, "_supports_ansi", lambda stream: True)

    assert cli.main(["ls", "--api-key", "instavm_sk_test"]) == 0
    output = capsys.readouterr().out
    assert "Active VMs (1)" in output
    assert "Use `instavm ls --all` to include terminated VMs." in output
    assert "Created" in output
    assert "\x1b[32m●\x1b[0m active" in output
    assert "vm_live@instavm.dev" in output


def test_share_create_json_output(monkeypatch, capsys):
    class FakeShares:
        def create(self, **kwargs):
            return {
                "share_id": "share_123",
                "url": "https://share_123.instavm.site/",
                "port": kwargs["port"],
                "is_public": kwargs["is_public"],
            }

    class FakeClient:
        def __init__(self, **kwargs):
            self.shares = FakeShares()

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["share", "create", "vm_123", "3000", "--public", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["share_id"] == "share_123"
    assert payload["is_public"] is True


def test_volume_ls_json_output(monkeypatch, capsys):
    class FakeVolumes:
        def list(self, refresh_usage=False):
            assert refresh_usage is True
            return [
                {
                    "id": "vol_123",
                    "name": "workspace",
                    "quota_bytes": 5 * 1024**3,
                    "used_bytes": 1024,
                    "status": "available",
                }
            ]

    class FakeClient:
        def __init__(self, **kwargs):
            self.volumes = FakeVolumes()

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["volume", "ls", "--refresh", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["volumes"][0]["id"] == "vol_123"


def test_snapshot_ls_text_output_is_table(monkeypatch, capsys):
    class FakeSnapshots:
        def list(self, snapshot_type=None):
            assert snapshot_type is None
            return [{"id": "snap_123", "name": "workspace", "status": "ready", "type": "user"}]

    class FakeClient:
        def __init__(self, **kwargs):
            self.snapshots = FakeSnapshots()

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["snapshot", "ls", "--api-key", "instavm_sk_test"]) == 0
    output = capsys.readouterr().out
    assert "Snapshots (1)" in output
    assert "workspace" in output
    assert "Type" in output


def test_volume_related_text_output_uses_tables(monkeypatch, capsys):
    class FakeVolumes:
        def list(self, refresh_usage=False):
            return [{"id": "vol_123", "name": "workspace", "quota_bytes": 5 * 1024**3, "used_bytes": 1024, "status": "available"}]

        def list_checkpoints(self, volume_id):
            assert volume_id == "vol_123"
            return [{"id": "chk_123", "name": "morning", "status": "ready"}]

        def list_files(self, volume_id, prefix="", recursive=True, limit=1000):
            assert volume_id == "vol_123"
            return [{"path": "notes/today.md", "size": 2048}]

    class FakeClient:
        def __init__(self, **kwargs):
            self.volumes = FakeVolumes()

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["volume", "ls", "--api-key", "instavm_sk_test"]) == 0
    volume_output = capsys.readouterr().out
    assert "Volumes (1)" in volume_output
    assert "Usage" in volume_output
    assert "1.0KB / 5.0GB" in volume_output

    assert cli.main(["volume", "checkpoint", "ls", "vol_123", "--api-key", "instavm_sk_test"]) == 0
    checkpoint_output = capsys.readouterr().out
    assert "Checkpoints (1)" in checkpoint_output
    assert "morning" in checkpoint_output

    assert cli.main(["volume", "files", "ls", "vol_123", "--api-key", "instavm_sk_test"]) == 0
    files_output = capsys.readouterr().out
    assert "Files (1)" in files_output
    assert "notes/today.md" in files_output
    assert "2.0KB" in files_output


def test_ssh_key_list_json_output(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def list_ssh_keys(self):
            return [{"id": 3, "fingerprint": "SHA256:def", "comment": "desktop"}]

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["ssh-key", "list", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["keys"][0]["fingerprint"] == "SHA256:def"


def test_ssh_key_list_text_output_is_table(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def list_ssh_keys(self):
            return [{"id": 3, "fingerprint": "SHA256:def", "comment": "desktop"}]

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["ssh-key", "list", "--api-key", "instavm_sk_test"]) == 0
    output = capsys.readouterr().out
    assert "SSH Keys (1)" in output
    assert "desktop" in output
    assert "Fingerprint" in output


def test_desktop_status_json_output(monkeypatch, capsys):
    session_id = str(uuid4())

    class FakeComputerUse:
        def viewer_url(self, target_session_id):
            assert target_session_id == session_id
            return {"viewer_url": "https://viewer.example.com", "websocket_url": "wss://viewer.example.com/ws"}

    class FakeClient:
        def __init__(self, **kwargs):
            self.computer_use = FakeComputerUse()

        def get_session_status(self, target_session_id):
            assert target_session_id == session_id
            return {"session_id": target_session_id, "vm_id": "vm_desktop_123", "vm_status": "active", "vm_alive": True}

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["desktop", "status", session_id, "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["viewer_url"] == "https://viewer.example.com"
    assert payload["vm_id"] == "vm_desktop_123"


def test_connect_uses_derived_ssh_host(monkeypatch):
    commands = []

    monkeypatch.setattr(cli.shutil, "which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr(
        cli.subprocess,
        "run",
        lambda command, check=False: commands.append(command) or SimpleNamespace(returncode=0),
    )

    assert cli.main([
        "connect",
        "--base-url",
        "https://staging.api.instavm.io",
        "vm_123",
        "--",
        "-L",
        "9000:localhost:80",
    ]) == 0
    assert commands == [["/usr/bin/ssh.exe", "vm_123@staging.instavm.dev", "-L", "9000:localhost:80"]]


def test_egress_get_session_json_output(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def get_session_egress(self, session_id):
            assert session_id == "sess_123"
            return {
                "allow_public_repos": False,
                "allow_http": False,
                "allow_https": True,
                "allowed_domains": ["pypi.org"],
                "allowed_cidrs": ["10.0.0.0/24"],
            }

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["egress", "get", "--session", "sess_123", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["target_type"] == "session"
    assert payload["target_id"] == "sess_123"
    assert payload["allow_package_managers"] is False
    assert payload["allowed_domains"] == ["pypi.org"]


def test_egress_set_vm_text_output(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def set_vm_egress(self, vm_id, **kwargs):
            assert vm_id == "vm_123"
            assert kwargs == {
                "allow_package_managers": False,
                "allow_http": False,
                "allow_https": True,
                "allowed_domains": ["example.com"],
                "allowed_cidrs": ["10.1.0.0/16"],
            }
            return {"status": "updated", "allow_public_repos": kwargs["allow_package_managers"], **kwargs}

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main([
        "egress",
        "set",
        "--vm",
        "vm_123",
        "--no-allow-package-managers",
        "--deny-http",
        "--allow-https",
        "--domain",
        "example.com",
        "--cidr",
        "10.1.0.0/16",
        "--api-key",
        "instavm_sk_test",
    ]) == 0
    output = capsys.readouterr().out
    assert "Target: vm vm_123" in output
    assert "Status: updated" in output
    assert "Package managers: blocked" in output
    assert "Domains: example.com" in output


def test_exec_inline_command_json_output(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, **kwargs):
            self.session_id = None

        def start_session(self):
            self.session_id = "sess_auto_123"
            return self.session_id

        def execute(self, command, language=None, timeout=None):
            assert command == "print('hello')"
            assert language == "python"
            assert timeout == 30
            return {"stdout": "hello\n", "stderr": ""}

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main([
        "exec",
        "--cmd",
        "print('hello')",
        "--language",
        "python",
        "--timeout",
        "30",
        "--api-key",
        "instavm_sk_test",
        "--json",
    ]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["session_id"] == "sess_auto_123"
    assert payload["language"] == "python"
    assert payload["stdout"] == "hello\n"


def test_exec_file_reads_local_source_and_infers_language(tmp_path, monkeypatch, capsys):
    script_path = tmp_path / "script.py"
    script_path.write_text("print('file run')\n", encoding="utf-8")

    class FakeClient:
        def __init__(self, **kwargs):
            self.session_id = None

        def start_session(self):
            self.session_id = "sess_file_123"
            return self.session_id

        def execute(self, command, language=None, timeout=None):
            assert command == "print('file run')\n"
            assert language == "python"
            return {"stdout": "file run\n", "stderr": ""}

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["exec", str(script_path), "--api-key", "instavm_sk_test"]) == 0
    output = capsys.readouterr().out
    assert "Session: sess_file_123" in output
    assert "Language: python" in output
    assert "file run" in output


def test_exec_result_json_output(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def get_task_result(self, task_id, poll_interval=1, timeout=60):
            assert task_id == "task_123"
            assert poll_interval == 2
            assert timeout == 45
            return {"stdout": "done\n", "stderr": "", "execution_time": 5}

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main([
        "exec",
        "result",
        "task_123",
        "--poll-interval",
        "2",
        "--timeout",
        "45",
        "--api-key",
        "instavm_sk_test",
        "--json",
    ]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["task_id"] == "task_123"
    assert payload["stdout"] == "done\n"


def test_browser_read_json_output_uses_temporary_session(monkeypatch, capsys):
    closed_sessions = []

    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def create_browser_session(self):
            return "browser_123"

        def browser_navigate(self, url, session_id):
            assert url == "https://example.com"
            assert session_id == "browser_123"
            return {"url": url, "title": "Example"}

        def browser_extract_content(self, session_id=None, include_interactive=True, include_anchors=True, max_anchors=50):
            assert session_id == "browser_123"
            assert include_interactive is True
            assert include_anchors is True
            assert max_anchors == 50
            return {
                "readable_content": {"title": "Example", "content": "Readable page text"},
                "interactive_elements": [{"selector": "a"}],
                "content_anchors": [{"text": "Read more", "selector": "a.more"}],
            }

        def close_browser_session(self, session_id):
            closed_sessions.append(session_id)
            return True

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main(["browser", "read", "https://example.com", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["session_id"] == "browser_123"
    assert payload["readable_content"]["title"] == "Example"
    assert closed_sessions == ["browser_123"]


def test_browser_screenshot_writes_file(tmp_path, monkeypatch, capsys):
    output_path = tmp_path / "page.png"
    image_bytes = b"fake-image-bytes"

    class FakeClient:
        def __init__(self, **kwargs):
            pass

        def create_browser_session(self):
            return "browser_456"

        def browser_navigate(self, url, session_id):
            assert url == "https://example.com"
            assert session_id == "browser_456"
            return {"url": url}

        def browser_screenshot(self, session_id, full_page=True, format="png", quality=None):
            assert session_id == "browser_456"
            assert full_page is True
            assert format == "png"
            assert quality is None
            return base64.b64encode(image_bytes).decode("ascii")

        def close_browser_session(self, session_id):
            assert session_id == "browser_456"
            return True

    monkeypatch.setattr(cli, "InstaVM", FakeClient)

    assert cli.main([
        "browser",
        "screenshot",
        "https://example.com",
        "--out",
        str(output_path),
        "--api-key",
        "instavm_sk_test",
        "--json",
    ]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["local_path"] == str(output_path)
    assert output_path.read_bytes() == image_bytes


def _write_cookbook_manifest(root, slug="hello-fastapi"):
    cookbook_dir = root / slug
    cookbook_dir.mkdir(parents=True, exist_ok=True)
    (cookbook_dir / "app.py").write_text("print('hello')\n", encoding="utf-8")
    (cookbook_dir / "requirements.txt").write_text("fastapi\n", encoding="utf-8")
    (cookbook_dir / "Dockerfile").write_text("FROM python:3.12-slim\n", encoding="utf-8")
    (cookbook_dir / "instavm.yaml").write_text(
        f"""
schema_version: 1
slug: {slug}
title: Hello FastAPI
version: "0.1.0"
summary: Minimal example
category: web
runtime: python-fastapi
deploy:
  kind: upload_and_run
vm:
  memory_mb: 1024
  vcpu_count: 1
  timeout_seconds: 3600
app:
  port: 8000
  healthcheck_path: /health
  share_public_default: true
  readiness_timeout_seconds: 30
run:
  workdir: .
  start_command: python -m uvicorn app:app --host 0.0.0.0 --port 8000
secrets: []
post_deploy_notes:
  - open the share URL
build:
  context: .
  dockerfile: Dockerfile
artifact:
  oci_image: docker.io/instavm/cookbooks-{slug}:0.1.0
  snapshot_name: cookbook/{slug}:0.1.0
  snapshot_visibility: public_system
source:
  include:
    - app.py
    - requirements.txt
    - Dockerfile
    - instavm.yaml
  exclude: []
  setup_command: python -m pip install -r requirements.txt
""".strip()
        + "\n",
        encoding="utf-8",
    )
    return cookbook_dir


def _write_neon_city_manifest(root):
    cookbook_dir = root / "neon-city-webgl"
    cookbook_dir.mkdir(parents=True, exist_ok=True)
    (cookbook_dir / "index.html").write_text("<!doctype html><div id='root'></div>\n", encoding="utf-8")
    (cookbook_dir / "server.mjs").write_text("console.log('serve neon city')\n", encoding="utf-8")
    (cookbook_dir / "package.json").write_text('{"name":"neon-city-webgl"}\n', encoding="utf-8")
    (cookbook_dir / "Dockerfile").write_text("FROM node:20-bookworm-slim\n", encoding="utf-8")
    (cookbook_dir / "instavm.yaml").write_text(
        """
schema_version: 1
slug: neon-city-webgl
title: Neon City WebGL
version: "0.1.0"
summary: Fullscreen WebGL city
category: graphics
runtime: node-vite-r3f
deploy:
  kind: upload_and_run
vm:
  memory_mb: 2048
  vcpu_count: 2
  timeout_seconds: 7200
app:
  port: 3000
  healthcheck_path: /health
  share_public_default: true
  readiness_timeout_seconds: 180
run:
  workdir: .
  start_command: node server.mjs
secrets: []
post_deploy_notes:
  - open the share URL
build:
  context: .
  dockerfile: Dockerfile
artifact:
  oci_image: docker.io/instavm/cookbooks-neon-city-webgl:0.1.0
  snapshot_name: cookbook/neon-city-webgl:0.1.0
  snapshot_visibility: public_system
source:
  include:
    - index.html
    - server.mjs
    - package.json
    - Dockerfile
    - instavm.yaml
  exclude: []
  setup_command: npm install && npm run build
""".strip()
        + "\n",
        encoding="utf-8",
    )
    return cookbook_dir


def test_cookbook_list_and_info_json(tmp_path, monkeypatch, capsys):
    cookbook_root = tmp_path / "cookbooks"
    _write_cookbook_manifest(cookbook_root)
    monkeypatch.setenv("INSTAVM_COOKBOOKS_DIR", str(cookbook_root))

    assert cli.main(["cookbook", "list", "--json"]) == 0
    listed = json.loads(capsys.readouterr().out)
    assert listed["cookbooks"][0]["slug"] == "hello-fastapi"

    assert cli.main(["cookbook", "info", "hello-fastapi", "--json"]) == 0
    info = json.loads(capsys.readouterr().out)
    assert info["slug"] == "hello-fastapi"
    assert info["app"]["port"] == 8000


def test_cookbook_list_text_groups_entries_for_humans(tmp_path, monkeypatch, capsys):
    cookbook_root = tmp_path / "cookbooks"
    _write_cookbook_manifest(cookbook_root)
    _write_neon_city_manifest(cookbook_root)
    monkeypatch.setenv("INSTAVM_COOKBOOKS_DIR", str(cookbook_root))

    assert cli.main(["cookbook", "list"]) == 0
    output = capsys.readouterr().out
    assert "Cookbooks (2)" in output
    assert "Try first" in output
    assert "Neon City WebGL" in output
    assert "Hello FastAPI" in output
    assert ":3000  no key" in output
    assert ":8000  no key" in output
    assert "Use `instavm cookbook info <slug>` for details." in output
    assert "Minimal example" not in output


def test_cookbook_list_and_info_support_neon_city_manifest(tmp_path, monkeypatch, capsys):
    cookbook_root = tmp_path / "cookbooks"
    _write_neon_city_manifest(cookbook_root)
    monkeypatch.setenv("INSTAVM_COOKBOOKS_DIR", str(cookbook_root))

    assert cli.main(["cookbook", "list", "--json"]) == 0
    listed = json.loads(capsys.readouterr().out)
    assert listed["cookbooks"][0]["slug"] == "neon-city-webgl"
    assert listed["cookbooks"][0]["runtime"] == "node-vite-r3f"

    assert cli.main(["cookbook", "info", "neon-city-webgl", "--json"]) == 0
    info = json.loads(capsys.readouterr().out)
    assert info["slug"] == "neon-city-webgl"
    assert info["app"]["port"] == 3000
    assert info["secrets"] == []


def test_ensure_account_ssh_key_uses_matching_local_identity(tmp_path):
    ssh_dir = tmp_path / ".ssh"
    ssh_dir.mkdir()
    public_key_path = ssh_dir / "id_ed25519.pub"
    public_key_path.write_text(
        "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGi+1NnURQRiFNg+4fEvfh0Yp5pjYEZ+TEhFswJ+OeB7 codex cookbook smoke\n",
        encoding="utf-8",
    )

    class FakeClient:
        def list_ssh_keys(self):
            return [{"id": 64, "fingerprint": "SHA256:IX9w2/yFYxTMymF+18p5io3bSKNM6UZ3r4KSgBh5m0Q"}]

    result = _cookbook.ensure_account_ssh_key(FakeClient(), home=tmp_path)
    assert result["configured"] is True
    assert result["auto_added"] is False
    assert Path(result["selected_path"]).as_posix() == public_key_path.as_posix()


def test_cookbook_deploy_auto_adds_ssh_key_and_emits_payload(tmp_path, monkeypatch, capsys):
    cookbook_root = tmp_path / "cookbooks"
    _write_cookbook_manifest(cookbook_root)
    monkeypatch.setenv("INSTAVM_COOKBOOKS_DIR", str(cookbook_root))

    ssh_dir = tmp_path / ".ssh"
    ssh_dir.mkdir()
    (ssh_dir / "id_ed25519.pub").write_text("ssh-ed25519 AAAAFAILKEY user@example.com\n", encoding="utf-8")
    public_key_path = ssh_dir / "id_rsa.pub"
    public_key_path.write_text("ssh-rsa AAAATESTKEY user@example.com\n", encoding="utf-8")
    monkeypatch.setattr(_cookbook.Path, "home", staticmethod(lambda: tmp_path))

    class FakeVMs:
        def create(self, wait=True, **payload):
            assert payload["memory_mb"] == 1024
            return {"vm_id": "vm_cookbook_123", "session_id": "sess_123", "status": "active"}

    class FakeShares:
        def create(self, **payload):
            assert payload["vm_id"] == "vm_cookbook_123"
            return {"share_id": "share_123", "url": "https://share_123.instavm.site/", "is_public": True}

    class FakeClient:
        def __init__(self, **kwargs):
            self.vms = FakeVMs()
            self.shares = FakeShares()
            self.added_keys = []

        def list_ssh_keys(self):
            return []

        def add_ssh_key(self, public_key):
            self.added_keys.append(public_key)
            if public_key.startswith("ssh-ed25519 "):
                raise InstaVMError("Key already registered to another user")
            return {"id": 1, "fingerprint": "SHA256:test"}

    fake_client = FakeClient()
    monkeypatch.setattr(cli, "InstaVM", lambda **kwargs: fake_client)
    monkeypatch.setattr(_cookbook, "preflight_tools", lambda: {"git": "/usr/bin/git", "ssh": "/usr/bin/ssh", "scp": "/usr/bin/scp", "tar": "/usr/bin/tar"})
    monkeypatch.setattr(_cookbook, "start_remote_service", lambda **kwargs: ("instavm-cookbook-hello-fastapi", "nohup"))
    monkeypatch.setattr(_cookbook, "wait_for_internal_health", lambda **kwargs: None)
    monkeypatch.setattr(_cookbook, "verify_public_share", lambda *args, **kwargs: None)
    monkeypatch.setattr(_cookbook, "_run_command", lambda *args, **kwargs: SimpleNamespace(stdout="", stderr=""))
    monkeypatch.setattr(_cookbook, "run_ssh", lambda *args, **kwargs: SimpleNamespace(stdout="nohup\n", stderr=""))

    assert cli.main(["cookbook", "deploy", "hello-fastapi", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["vm_id"] == "vm_cookbook_123"
    assert payload["share_url"] == "https://share_123.instavm.site/"
    assert fake_client.added_keys == [
        "ssh-ed25519 AAAAFAILKEY user@example.com",
        "ssh-rsa AAAATESTKEY user@example.com",
    ]


def test_cookbook_deploy_text_output_is_curated(tmp_path, monkeypatch, capsys):
    cookbook_root = tmp_path / "cookbooks"
    _write_cookbook_manifest(cookbook_root)
    monkeypatch.setenv("INSTAVM_COOKBOOKS_DIR", str(cookbook_root))

    ssh_dir = tmp_path / ".ssh"
    ssh_dir.mkdir()
    (ssh_dir / "id_ed25519.pub").write_text("ssh-ed25519 AAAATESTKEY user@example.com\n", encoding="utf-8")
    monkeypatch.setattr(_cookbook.Path, "home", staticmethod(lambda: tmp_path))

    class FakeVMs:
        def create(self, wait=True, **payload):
            return {"vm_id": "vm_cookbook_123", "session_id": "sess_123", "status": "active"}

    class FakeShares:
        def create(self, **payload):
            return {"share_id": "share_123", "url": "https://share_123.instavm.site/", "is_public": True}

    class FakeClient:
        def __init__(self, **kwargs):
            self.vms = FakeVMs()
            self.shares = FakeShares()

        def list_ssh_keys(self):
            return [{"id": 1}]

    monkeypatch.setattr(cli, "InstaVM", lambda **kwargs: FakeClient())
    monkeypatch.setattr(_cookbook, "preflight_tools", lambda: {"git": "/usr/bin/git", "ssh": "/usr/bin/ssh", "scp": "/usr/bin/scp", "tar": "/usr/bin/tar"})
    monkeypatch.setattr(_cookbook, "start_remote_service", lambda **kwargs: ("instavm-cookbook-hello-fastapi", "nohup"))
    monkeypatch.setattr(_cookbook, "wait_for_internal_health", lambda **kwargs: None)
    monkeypatch.setattr(_cookbook, "verify_public_share", lambda *args, **kwargs: None)
    monkeypatch.setattr(_cookbook, "_run_command", lambda *args, **kwargs: SimpleNamespace(stdout="", stderr=""))
    monkeypatch.setattr(_cookbook, "run_ssh", lambda *args, **kwargs: SimpleNamespace(stdout="nohup\n", stderr=""))

    assert cli.main(["cookbook", "deploy", "hello-fastapi", "--api-key", "instavm_sk_test"]) == 0
    output = capsys.readouterr().out
    assert "Cookbook ready" in output
    assert "URL       https://share_123.instavm.site" in output
    assert "Connect   instavm connect vm_cookbook_123" in output
    assert "~/.instavm-cookbooks/logs/hello-fastapi.log" in output
    assert "Destroy   instavm rm vm_cookbook_123" in output
    assert "id_ed25519" not in output


def test_cookbook_deploy_retries_vm_create_without_sizing_on_free_tier(tmp_path, monkeypatch, capsys):
    cookbook_root = tmp_path / "cookbooks"
    _write_cookbook_manifest(cookbook_root)
    monkeypatch.setenv("INSTAVM_COOKBOOKS_DIR", str(cookbook_root))

    ssh_dir = tmp_path / ".ssh"
    ssh_dir.mkdir()
    (ssh_dir / "id_ed25519.pub").write_text("ssh-ed25519 AAAATESTKEY user@example.com\n", encoding="utf-8")
    monkeypatch.setattr(_cookbook.Path, "home", staticmethod(lambda: tmp_path))

    class FakeVMs:
        def __init__(self):
            self.calls = []

        def create(self, wait=True, **payload):
            self.calls.append(payload)
            if len(self.calls) == 1:
                raise InstaVMError("Free tier is limited to 2 CPU cores. Upgrade to Pro for configurable CPU.")
            assert "memory_mb" not in payload
            assert "vcpu_count" not in payload
            return {"vm_id": "vm_retry_123", "session_id": "sess_retry_123", "status": "active"}

    class FakeShares:
        def create(self, **payload):
            return {"share_id": "share_retry_123", "url": "https://share_retry_123.instavm.site/", "is_public": True}

    class FakeClient:
        def __init__(self):
            self.vms = FakeVMs()
            self.shares = FakeShares()

        def list_ssh_keys(self):
            return [{"id": 1}]

    fake_client = FakeClient()
    monkeypatch.setattr(cli, "InstaVM", lambda **kwargs: fake_client)
    monkeypatch.setattr(_cookbook, "preflight_tools", lambda: {"git": "/usr/bin/git", "ssh": "/usr/bin/ssh", "scp": "/usr/bin/scp", "tar": "/usr/bin/tar"})
    monkeypatch.setattr(_cookbook, "start_remote_service", lambda **kwargs: ("instavm-cookbook-hello-fastapi", "nohup"))
    monkeypatch.setattr(_cookbook, "wait_for_internal_health", lambda **kwargs: None)
    monkeypatch.setattr(_cookbook, "verify_public_share", lambda *args, **kwargs: None)
    monkeypatch.setattr(_cookbook, "_run_command", lambda *args, **kwargs: SimpleNamespace(stdout="", stderr=""))
    monkeypatch.setattr(_cookbook, "run_ssh", lambda *args, **kwargs: SimpleNamespace(stdout="nohup\n", stderr=""))

    assert cli.main(["cookbook", "deploy", "hello-fastapi", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["vm_id"] == "vm_retry_123"
    assert len(fake_client.vms.calls) == 2


def test_cookbook_deploy_retries_vm_create_with_plan_lifetime_limit(tmp_path, monkeypatch, capsys):
    cookbook_root = tmp_path / "cookbooks"
    _write_cookbook_manifest(cookbook_root, slug="claude-simple-chatapp")
    manifest_path = cookbook_root / "claude-simple-chatapp" / "instavm.yaml"
    manifest_text = manifest_path.read_text(encoding="utf-8").replace("timeout_seconds: 3600", "timeout_seconds: 7200", 1)
    manifest_text = manifest_text.replace("secrets: []", "secrets:\n  - name: anthropic_api_key\n    required: true\n    prompt: Anthropic API key\n    env_name: ANTHROPIC_API_KEY", 1)
    manifest_path.write_text(manifest_text, encoding="utf-8")
    monkeypatch.setenv("INSTAVM_COOKBOOKS_DIR", str(cookbook_root))
    monkeypatch.setenv("ANTHROPIC_API_KEY", "dummy")

    ssh_dir = tmp_path / ".ssh"
    ssh_dir.mkdir()
    (ssh_dir / "id_ed25519.pub").write_text("ssh-ed25519 AAAATESTKEY user@example.com\n", encoding="utf-8")
    monkeypatch.setattr(_cookbook.Path, "home", staticmethod(lambda: tmp_path))

    class FakeVMs:
        def __init__(self):
            self.calls = []

        def create(self, wait=True, **payload):
            self.calls.append(payload)
            if len(self.calls) == 1:
                raise InstaVMError("VM lifetime cannot exceed 3600s on your plan. Upgrade to Pro for longer VM sessions.")
            assert payload["vm_lifetime_seconds"] == 3600
            return {"vm_id": "vm_lifetime_123", "session_id": "sess_lifetime_123", "status": "active"}

    class FakeShares:
        def create(self, **payload):
            return {"share_id": "share_lifetime_123", "url": "https://share_lifetime_123.instavm.site/", "is_public": True}

    class FakeClient:
        def __init__(self):
            self.vms = FakeVMs()
            self.shares = FakeShares()

        def list_ssh_keys(self):
            return [{"id": 1}]

    fake_client = FakeClient()
    monkeypatch.setattr(cli, "InstaVM", lambda **kwargs: fake_client)
    monkeypatch.setattr(_cookbook, "preflight_tools", lambda: {"git": "/usr/bin/git", "ssh": "/usr/bin/ssh", "scp": "/usr/bin/scp", "tar": "/usr/bin/tar"})
    monkeypatch.setattr(_cookbook, "start_remote_service", lambda **kwargs: ("instavm-cookbook-claude-simple-chatapp", "nohup"))
    monkeypatch.setattr(_cookbook, "wait_for_internal_health", lambda **kwargs: None)
    monkeypatch.setattr(_cookbook, "verify_public_share", lambda *args, **kwargs: None)
    monkeypatch.setattr(_cookbook, "_run_command", lambda *args, **kwargs: SimpleNamespace(stdout="", stderr=""))
    monkeypatch.setattr(_cookbook, "run_ssh", lambda *args, **kwargs: SimpleNamespace(stdout="nohup\n", stderr=""))

    assert cli.main(["cookbook", "deploy", "claude-simple-chatapp", "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["vm_id"] == "vm_lifetime_123"
    assert len(fake_client.vms.calls) == 2


def test_cookbook_deploy_reports_retry_step_for_plan_lifetime_limit(tmp_path, monkeypatch, capsys):
    cookbook_root = tmp_path / "cookbooks"
    _write_cookbook_manifest(cookbook_root, slug="claude-simple-chatapp")
    manifest_path = cookbook_root / "claude-simple-chatapp" / "instavm.yaml"
    manifest_text = manifest_path.read_text(encoding="utf-8").replace("timeout_seconds: 3600", "timeout_seconds: 7200", 1)
    manifest_text = manifest_text.replace("secrets: []", "secrets:\n  - name: anthropic_api_key\n    required: true\n    prompt: Anthropic API key\n    env_name: ANTHROPIC_API_KEY", 1)
    manifest_path.write_text(manifest_text, encoding="utf-8")
    monkeypatch.setenv("INSTAVM_COOKBOOKS_DIR", str(cookbook_root))
    monkeypatch.setenv("ANTHROPIC_API_KEY", "dummy")

    ssh_dir = tmp_path / ".ssh"
    ssh_dir.mkdir()
    (ssh_dir / "id_ed25519.pub").write_text("ssh-ed25519 AAAATESTKEY user@example.com\n", encoding="utf-8")
    monkeypatch.setattr(_cookbook.Path, "home", staticmethod(lambda: tmp_path))

    class FakeVMs:
        def __init__(self):
            self.calls = 0

        def create(self, wait=True, **payload):
            self.calls += 1
            if self.calls == 1:
                raise InstaVMError("VM lifetime cannot exceed 3600s on your plan. Upgrade to Pro for longer VM sessions.")
            return {"vm_id": "vm_lifetime_123", "session_id": "sess_lifetime_123", "status": "active"}

    class FakeShares:
        def create(self, **payload):
            return {"share_id": "share_lifetime_123", "url": "https://share_lifetime_123.instavm.site/", "is_public": True}

    class FakeClient:
        def __init__(self):
            self.vms = FakeVMs()
            self.shares = FakeShares()

        def list_ssh_keys(self):
            return [{"id": 1}]

    monkeypatch.setattr(cli, "InstaVM", lambda **kwargs: FakeClient())
    monkeypatch.setattr(_cookbook, "preflight_tools", lambda: {"git": "/usr/bin/git", "ssh": "/usr/bin/ssh", "scp": "/usr/bin/scp", "tar": "/usr/bin/tar"})
    monkeypatch.setattr(_cookbook, "start_remote_service", lambda **kwargs: ("instavm-cookbook-claude-simple-chatapp", "nohup"))
    monkeypatch.setattr(_cookbook, "wait_for_internal_health", lambda **kwargs: None)
    monkeypatch.setattr(_cookbook, "verify_public_share", lambda *args, **kwargs: None)
    monkeypatch.setattr(_cookbook, "_run_command", lambda *args, **kwargs: SimpleNamespace(stdout="", stderr=""))
    monkeypatch.setattr(_cookbook, "run_ssh", lambda *args, **kwargs: SimpleNamespace(stdout="nohup\n", stderr=""))

    assert cli.main(["cookbook", "deploy", "claude-simple-chatapp", "--api-key", "instavm_sk_test"]) == 0
    stderr = capsys.readouterr().err
    assert "Requested VM lifetime exceeds the current account tier." in stderr
    assert "Retrying VM creation with a 3600s lifetime..." in stderr


def test_wait_for_ssh_ready_surfaces_last_error(monkeypatch):
    def fake_run_ssh(*args, **kwargs):
        raise _cookbook.CookbookError("ssh gateway denied access")

    timestamps = iter([0.0, 0.5, 1.5])
    monkeypatch.setattr(_cookbook, "run_ssh", fake_run_ssh)
    monkeypatch.setattr(_cookbook.time, "sleep", lambda _: None)
    monkeypatch.setattr(_cookbook.time, "time", lambda: next(timestamps))

    with pytest.raises(_cookbook.CookbookError, match="Last SSH error: ssh gateway denied access"):
        _cookbook.wait_for_ssh_ready("vmid-test@instavm.dev", timeout_seconds=1)


def test_deploy_save_snapshot_creates_snapshot_record(tmp_path, monkeypatch, capsys):
    _set_home(monkeypatch, tmp_path)
    project_dir = tmp_path / "app"
    project_dir.mkdir()
    (project_dir / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")

    plan = _detect.DeployPlan(
        slug="app",
        runtime="static",
        package_manager="none",
        install_command="echo 'No dependencies'",
        build_command=None,
        start_command="python3 -m http.server 3000 --directory . --bind 0.0.0.0",
        port=3000,
        health_path="/",
        secrets=[],
    )

    class FakeVMs:
        def __init__(self):
            self.snapshot_calls = []

        def snapshot(self, vm_id, wait=True, name=None):
            self.snapshot_calls.append((vm_id, wait, name))
            return {"snapshot_id": "snap_saved_123", "status": "ready"}

    fake_client = SimpleNamespace(
        vms=FakeVMs(),
        snapshots=SimpleNamespace(get=lambda snapshot_id: {"id": snapshot_id, "status": "ready"}),
    )

    monkeypatch.setattr(_detect, "detect_project", lambda path: plan)
    monkeypatch.setattr(cli, "_require_api_key", lambda args: (fake_client, SimpleNamespace(ssh_host="instavm.dev")))
    monkeypatch.setattr(
        cli,
        "_run_deploy",
        lambda manifest, **kwargs: {
            "slug": "app",
            "vm_id": "vm_saved_123",
            "share_url": "https://saved.example/",
            "destroy_command": "instavm rm vm_saved_123",
        },
    )

    assert cli.main(["deploy", str(project_dir), "--api-key", "instavm_sk_test", "--save-snapshot", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["saved_snapshot_id"] == "snap_saved_123"
    assert fake_client.vms.snapshot_calls == [("vm_saved_123", True, "deploy/app")]

    cache_payload = json.loads(next((tmp_path / ".instavm" / "deploys").glob("*.json")).read_text(encoding="utf-8"))
    assert cache_payload["snapshot_id"] == "snap_saved_123"
    assert cache_payload["project_path"] == str(project_dir.resolve())


def test_deploy_reuses_saved_snapshot_when_fingerprint_matches(tmp_path, monkeypatch, capsys):
    _set_home(monkeypatch, tmp_path)
    project_dir = tmp_path / "app"
    project_dir.mkdir()
    (project_dir / "index.html").write_text("<h1>hi</h1>", encoding="utf-8")

    plan = _detect.DeployPlan(
        slug="app",
        runtime="static",
        package_manager="none",
        install_command="echo 'No dependencies'",
        build_command=None,
        start_command="python3 -m http.server 3000 --directory . --bind 0.0.0.0",
        port=3000,
        health_path="/",
        secrets=[],
    )

    cache_path = cli._deploy_cache_path(project_dir)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(json.dumps({
        "slug": "app",
        "project_path": str(project_dir.resolve()),
        "snapshot_id": "snap_cached_123",
        "fingerprint": cli._deploy_fingerprint(plan),
    }), encoding="utf-8")

    fake_client = SimpleNamespace(
        vms=SimpleNamespace(snapshot=lambda *args, **kwargs: {"snapshot_id": "snap_new"}),
        snapshots=SimpleNamespace(get=lambda snapshot_id: {"id": snapshot_id, "status": "ready"}),
    )
    captured = {}

    monkeypatch.setattr(_detect, "detect_project", lambda path: plan)
    monkeypatch.setattr(cli, "_require_api_key", lambda args: (fake_client, SimpleNamespace(ssh_host="instavm.dev")))

    def fake_run_deploy(manifest, **kwargs):
        captured["snapshot_id_override"] = kwargs.get("snapshot_id_override")
        return {
            "slug": "app",
            "vm_id": "vm_reuse_123",
            "share_url": "https://reuse.example/",
            "destroy_command": "instavm rm vm_reuse_123",
        }

    monkeypatch.setattr(cli, "_run_deploy", fake_run_deploy)

    assert cli.main(["deploy", str(project_dir), "--api-key", "instavm_sk_test", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert captured["snapshot_id_override"] == "snap_cached_123"
    assert payload["reused_snapshot_id"] == "snap_cached_123"
