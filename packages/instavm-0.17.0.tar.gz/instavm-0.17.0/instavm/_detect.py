"""Zero-config project detection for ``instavm deploy``.

Inspects a local project directory and infers runtime, package manager,
install/build/start commands, port, health-check path, and required secrets
so the deploy pipeline can run without an ``instavm.yaml``.

Detection heuristics inspired by Railpack (MIT License):
https://github.com/railwayapp/railpack
"""

from __future__ import annotations

import json
import os
import re
import shlex
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ._cookbook import (
    AppConfig,
    CookbookManifest,
    DeploySpec,
    RunConfig,
    SecretSpec,
    SourceConfig,
    VMConfig,
)

# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

@dataclass
class DeployPlan:
    slug: str
    runtime: str  # "node", "python", "static", "go", or "deno"
    package_manager: str  # npm, yarn, pnpm, bun, pip, poetry, uv, pipenv, pdm, go, deno, none
    install_command: str
    build_command: Optional[str]
    start_command: str
    port: int
    health_path: str
    secrets: list[SecretSpec] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_NON_SECRET_VARS = frozenset({
    "PORT", "HOST", "NODE_ENV", "DEBUG", "PYTHONPATH", "PATH", "HOME",
    "HOSTNAME", "LANG", "TZ", "TERM", "CI", "VIRTUAL_ENV", "PWD", "SHELL",
    "USER", "LOGNAME", "TMPDIR", "PYTHONDONTWRITEBYTECODE", "PYTHONUNBUFFERED",
    "NPM_CONFIG_LOGLEVEL", "NEXT_TELEMETRY_DISABLED",
    # Model/config env vars that typically have defaults in source
    "OPENAI_MODEL", "GOOGLE_MODEL", "ANTHROPIC_MODEL",
    "OPENAI_COMPAT_API_BASE", "OPENAI_COMPAT_MODEL",
})

_DEP_SECRET_HINTS: dict[str, tuple[str, str]] = {
    # Python packages
    "anthropic": ("ANTHROPIC_API_KEY", "Anthropic API key"),
    "openai-agents": ("OPENAI_API_KEY", "OpenAI API key"),
    "openai": ("OPENAI_API_KEY", "OpenAI API key"),
    "google-adk": ("GOOGLE_API_KEY", "Google API key"),
    "google-generativeai": ("GOOGLE_API_KEY", "Google API key"),
    "replicate": ("REPLICATE_API_TOKEN", "Replicate API token"),
    # Node packages
    "@anthropic-ai/claude-agent-sdk": ("ANTHROPIC_API_KEY", "Anthropic API key"),
    "@anthropic-ai/sdk": ("ANTHROPIC_API_KEY", "Anthropic API key"),
    "@openai/agents": ("OPENAI_API_KEY", "OpenAI API key"),
    "@ai-sdk/anthropic": ("ANTHROPIC_API_KEY", "Anthropic API key"),
    "@ai-sdk/openai": ("OPENAI_API_KEY", "OpenAI API key"),
    "@ai-sdk/google": ("GOOGLE_API_KEY", "Google API key"),
}

_PYTHON_APP_CANDIDATES = ("app.py", "main.py", "server.py", "bot.py", "start.py", "src/app.py", "src/main.py")

_NODE_SOURCE_CANDIDATES = (
    "server.mjs", "server.js", "server.ts", "index.js", "index.ts",
    "src/index.ts", "src/index.js", "src/server.ts", "src/server.js",
    "server/server.ts", "server/server.js",
)

_GO_SOURCE_CANDIDATES = ("main.go", "server.go", "app.go", "cmd/server/main.go", "cmd/main.go")

_DENO_MAIN_CANDIDATES = ("main.ts", "main.js", "main.mjs", "main.mts", "server.ts", "server.js", "app.ts", "app.js")

_STATIC_ROOT_CANDIDATES = ("public", "dist", "build")

_NVM_SETUP_PREFIX = (
    'export NVM_DIR="$HOME/.nvm" && '
    'if [ ! -s "$NVM_DIR/nvm.sh" ]; then '
    "curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash; "
    "fi && "
    '. "$NVM_DIR/nvm.sh" && '
    "nvm install {node_version} && "
    "nvm use {node_version} && "
)

_NVM_RUN_PREFIX = (
    'export NVM_DIR="$HOME/.nvm" && '
    '. "$NVM_DIR/nvm.sh" && '
    "nvm use {node_version} >/dev/null && "
)

_COREPACK_ENABLE_PREFIX = "corepack enable >/dev/null 2>&1 && "

_HEALTH_ROUTE_RE = re.compile(
    r"""(?:@app\.(?:get|route)|app\.get|router\.get)\s*\(\s*['"](/(?:health|healthz|api/health))['"]\s*""",
)

_GO_HEALTH_RE = re.compile(
    r"""(?:HandleFunc|Handle)\s*\(\s*['"](/(?:health|healthz|api/health))['"]""",
)

_GO_PORT_RE = re.compile(r'''ListenAndServe\s*\(\s*["']:(\d{2,5})["']''')

_PORT_PATTERN_RE = re.compile(r"PORT\s*(?:\|\||===?\s*undefined\s*\?\s*|\?\?)\s*['\"]?(\d{2,5})['\"]?")

_PYTHON_ENV_RE = re.compile(
    r"""os\.(?:environ\s*(?:\.get\s*\(|(?:\[)))\s*['"]([\w]+)['"]"""
    r"""|os\.getenv\s*\(\s*['"]([\w]+)['"]""",
)

_NODE_ENV_RE = re.compile(r"process\.env\.([\w]+)")

_GO_ENV_RE = re.compile(r'''os\.(?:Getenv|LookupEnv)\s*\(\s*["'](\w+)["']\)''')

_DENO_ENV_RE = re.compile(r'''Deno\.env\.get\s*\(\s*["'](\w+)["']\)''')

_DJANGO_WSGI_RE = re.compile(r'''WSGI_APPLICATION\s*=\s*["']([A-Za-z_][\w.]*)\.application["']''')


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_project(path: Path) -> DeployPlan:
    """Detect runtime, commands, port, and secrets from project files.

    Raises ``ValueError`` if the project type cannot be determined.
    """
    path = path.resolve()
    if not path.is_dir():
        raise ValueError(f"Not a directory: {path}")

    # 1. Node.js
    if (path / "package.json").exists():
        return _detect_node(path)

    # 2. Python
    if (
        (path / "requirements.txt").exists()
        or (path / "pyproject.toml").exists()
        or (path / "Pipfile").exists()
    ):
        return _detect_python(path)

    # 3. Go
    if (path / "go.mod").exists() or (path / "main.go").exists():
        return _detect_go(path)

    # 4. Deno
    if (path / "deno.json").exists() or (path / "deno.jsonc").exists():
        return _detect_deno(path)

    # 5. Static site (fallback)
    if _has_static_signals(path):
        return _detect_static(path)

    raise ValueError(
        "Could not detect project type. "
        "Expected package.json, requirements.txt, pyproject.toml, Pipfile, "
        "go.mod, deno.json, or index.html."
    )


def _detect_node_version(path: Path) -> str:
    """Read Node version from package.json engines field, default to 22."""
    pkg_path = path / "package.json"
    if pkg_path.exists():
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            engines = pkg.get("engines", {})
            node_constraint = engines.get("node", "")
            m = re.search(r"(\d+)", node_constraint)
            if m:
                return m.group(1)
        except (OSError, json.JSONDecodeError):
            pass
    return "22"


def plan_to_manifest(plan: DeployPlan, path: Path) -> CookbookManifest:
    """Convert a *DeployPlan* into a *CookbookManifest* for the deploy pipeline."""
    setup_command = plan.install_command
    if plan.build_command:
        setup_command += f" && {plan.build_command}"

    start_command = plan.start_command

    # For Node.js, prepend NVM installation to setup and NVM sourcing to start
    if plan.runtime == "node":
        node_version = _detect_node_version(path)
        setup_command = _NVM_SETUP_PREFIX.format(node_version=node_version) + setup_command
        start_command = _NVM_RUN_PREFIX.format(node_version=node_version) + start_command

    return CookbookManifest(
        path=path.resolve(),
        schema_version=1,
        slug=plan.slug,
        title=plan.slug,
        version="0.0.0",
        summary="",
        category="deploy",
        runtime=plan.runtime,
        deploy=DeploySpec(kind="upload_and_run"),
        vm=VMConfig(memory_mb=2048, vcpu_count=2, timeout_seconds=3600, image_variant=None),
        app=AppConfig(
            port=plan.port,
            healthcheck_path=plan.health_path,
            share_public_default=True,
            readiness_timeout_seconds=120,
        ),
        run=RunConfig(workdir=".", start_command=start_command, logs_hint=None),
        secrets=tuple(plan.secrets),
        post_deploy_notes=(),
        artifact=None,
        build=None,
        source=SourceConfig(
            include=("*",),
            exclude=() if plan.runtime == "static" else ("dist", "dist/*", "build", "build/*"),
            setup_command=setup_command,
        ),
    )


# ---------------------------------------------------------------------------
# Node.js detection
# ---------------------------------------------------------------------------

def _detect_node(path: Path) -> DeployPlan:
    pkg_path = path / "package.json"
    try:
        pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Cannot read package.json: {exc}") from exc

    pm = _detect_node_pm(path, pkg)
    scripts = pkg.get("scripts") or {}
    deps = _read_node_deps(pkg)

    # Install command — varies by package manager
    if pm == "npm" and (path / "package-lock.json").exists():
        install_cmd = "npm ci"
    elif pm == "yarn":
        if _is_yarn_berry(path, pkg):
            install_cmd = _wrap_node_pm_command(pm, "yarn install --check-cache")
        else:
            install_cmd = _wrap_node_pm_command(pm, "yarn install --frozen-lockfile")
    elif pm == "pnpm":
        install_cmd = _wrap_node_pm_command(pm, "pnpm install")
    else:
        install_cmd = f"{pm} install"

    # Build command
    build_cmd: Optional[str] = None
    if "build" in scripts:
        build_cmd = _wrap_node_pm_command(pm, f"{pm} run build")

    # Start command
    start_cmd: Optional[str] = None
    if "start" in scripts:
        start_cmd = _wrap_node_pm_command(pm, f"{pm} start")
    elif "serve" in scripts:
        start_cmd = _wrap_node_pm_command(pm, f"{pm} run serve")
    elif pkg.get("main"):
        start_cmd = f"node {shlex.quote(str(pkg['main']))}"

    if not start_cmd:
        raise ValueError(
            "Could not detect start command. "
            "Add a 'start' script to package.json or use --start-command."
        )

    # Port
    port = _detect_port_from_start_script(scripts.get("start", ""))
    if port is None:
        port = _detect_port_from_source(path, list(_NODE_SOURCE_CANDIDATES))
    if port is None:
        port = 3000

    # Health path
    health = _detect_health_path(path)

    # Secrets
    secrets = _collect_secrets(path, deps, "node")

    return DeployPlan(
        slug=_slugify(pkg.get("name") or path.name),
        runtime="node",
        package_manager=pm,
        install_command=install_cmd,
        build_command=build_cmd,
        start_command=start_cmd,
        port=port,
        health_path=health,
        secrets=secrets,
    )


def _detect_node_pm(path: Path, pkg: dict) -> str:
    """Detect Node.js package manager.

    Priority: packageManager field > lockfiles > default npm.
    """
    # Priority 1: packageManager field in package.json
    pm_field = str(pkg.get("packageManager") or "").strip()
    if pm_field:
        pm_name = pm_field.split("@")[0].strip().lower()
        if pm_name in ("pnpm", "yarn", "bun", "npm"):
            return pm_name

    # Priority 2: Lockfiles
    if (path / "pnpm-lock.yaml").exists():
        return "pnpm"
    if (path / "yarn.lock").exists():
        return "yarn"
    if (path / "bun.lockb").exists() or (path / "bun.lock").exists():
        return "bun"
    return "npm"


def _is_yarn_berry(path: Path, pkg: dict) -> bool:
    """Check if yarn version is Berry (2+) rather than Classic (1)."""
    pm_field = str(pkg.get("packageManager") or "").strip()
    if pm_field.lower().startswith("yarn@"):
        version_part = pm_field.split("@")[1].split("+")[0]  # strip SHA
        major = version_part.split(".")[0]
        if major.isdigit() and int(major) >= 2:
            return True
    if (path / ".yarnrc.yml").exists() or (path / ".yarnrc.yaml").exists():
        return True
    return False


def _wrap_node_pm_command(pm: str, command: str) -> str:
    if pm in {"yarn", "pnpm"}:
        return f"{_COREPACK_ENABLE_PREFIX}{command}"
    return command


def _read_node_deps(pkg: dict) -> list[str]:
    deps: list[str] = []
    for section in ("dependencies", "devDependencies", "peerDependencies"):
        deps.extend((pkg.get(section) or {}).keys())
    return deps


# ---------------------------------------------------------------------------
# Python detection
# ---------------------------------------------------------------------------

def _detect_python(path: Path) -> DeployPlan:
    deps = _read_python_deps(path)
    pm = _detect_python_pm(path)

    # Install command
    if pm == "poetry":
        install_cmd = "poetry install"
    elif pm == "uv":
        install_cmd = "uv sync"
    elif pm == "pdm":
        install_cmd = "pdm install"
    elif pm == "pipenv":
        if (path / "Pipfile.lock").exists():
            install_cmd = "pipenv install --deploy"
        else:
            install_cmd = "pipenv install"
    elif (path / "requirements.txt").exists():
        install_cmd = "pip install -r requirements.txt"
    else:
        install_cmd = "pip install ."

    # Detect app module and start command
    app_module = _find_python_app_module(path)
    start_cmd: Optional[str] = None
    port = 8000

    dep_names_lower = {d.lower().split("==")[0].split(">=")[0].split("[")[0].strip() for d in deps}

    # Django detection: manage.py + django in deps
    if "django" in dep_names_lower and (path / "manage.py").exists():
        wsgi_module = _find_django_wsgi(path)
        if "gunicorn" in dep_names_lower:
            start_cmd = f"python manage.py migrate && gunicorn {wsgi_module}:application -b 0.0.0.0:{port}"
        else:
            start_cmd = f"python manage.py migrate && python manage.py runserver 0.0.0.0:{port}"
    elif "uvicorn" in dep_names_lower or "python-fasthtml" in dep_names_lower or "fasthtml" in dep_names_lower:
        start_cmd = f"python -m uvicorn {app_module}:app --host 0.0.0.0 --port {port}"
    elif "gunicorn" in dep_names_lower:
        start_cmd = f"gunicorn {app_module}:app -b 0.0.0.0:{port}"
    elif "flask" in dep_names_lower:
        start_cmd = f"python -m flask run --host 0.0.0.0 --port {port}"
    elif "streamlit" in dep_names_lower:
        entry = _find_streamlit_entry(path)
        start_cmd = f"python -m streamlit run {entry} --server.port {port} --server.address 0.0.0.0"

    if not start_cmd:
        raise ValueError(
            "Could not detect start command. "
            "No django, uvicorn, gunicorn, flask, fasthtml, or streamlit found in dependencies. "
            "Use --start-command to specify how to start the app."
        )

    # Health path
    health = _detect_health_path(path)

    # Secrets
    secrets = _collect_secrets(path, list(dep_names_lower), "python")

    return DeployPlan(
        slug=_slugify(path.name),
        runtime="python",
        package_manager=pm,
        install_command=install_cmd,
        build_command=None,
        start_command=start_cmd,
        port=port,
        health_path=health,
        secrets=secrets,
    )


def _detect_python_pm(path: Path) -> str:
    if (path / "uv.lock").exists():
        return "uv"
    if (path / "pdm.lock").exists():
        return "pdm"
    pyproject = path / "pyproject.toml"
    if pyproject.exists():
        try:
            text = pyproject.read_text(encoding="utf-8")
        except OSError:
            text = ""
        if "[tool.uv]" in text:
            return "uv"
        if "[tool.poetry]" in text:
            return "poetry"
    if (path / "Pipfile").exists() or (path / "Pipfile.lock").exists():
        return "pipenv"
    return "pip"


def _read_python_deps(path: Path) -> list[str]:
    # Try requirements.txt first
    req = path / "requirements.txt"
    if req.exists():
        try:
            lines = req.read_text(encoding="utf-8").splitlines()
            deps = [
                line.strip()
                for line in lines
                if line.strip() and not line.strip().startswith("#")
            ]
            if deps:
                return deps
        except OSError:
            pass

    # Fall back to pyproject.toml dependency lists
    pyproject = path / "pyproject.toml"
    if pyproject.exists():
        try:
            text = pyproject.read_text(encoding="utf-8")
            return _parse_pyproject_deps(text)
        except OSError:
            pass

    # Fall back to Pipfile
    pipfile = path / "Pipfile"
    if pipfile.exists():
        return _parse_pipfile_deps(pipfile)

    return []


def _parse_pyproject_deps(text: str) -> list[str]:
    """Extract dependency names from pyproject.toml (simple line-by-line parser).

    Handles both PEP 621 (``[project] dependencies = [...]``) and
    Poetry (``[tool.poetry.dependencies]``) formats.
    """
    deps: list[str] = []

    # PEP 621: dependencies = ["fastapi>=0.128", "uvicorn>=0.39"]
    # Use word boundary to avoid matching dev-dependencies
    inline_match = re.search(r'(?<![a-z-])dependencies\s*=\s*\[([^\]]*)\]', text)
    if inline_match:
        for item in inline_match.group(1).split(","):
            cleaned = item.strip().strip('"').strip("'").strip()
            if cleaned:
                deps.append(cleaned)

    # Poetry: [tool.poetry.dependencies] section with key = "version" lines
    in_poetry_deps = False
    for line in text.splitlines():
        stripped = line.strip()
        if stripped == "[tool.poetry.dependencies]":
            in_poetry_deps = True
            continue
        if in_poetry_deps:
            if stripped.startswith("["):
                break
            if "=" in stripped and not stripped.startswith("#"):
                key = stripped.split("=")[0].strip()
                if key and key != "python":
                    deps.append(key)

    return deps


def _parse_pipfile_deps(pipfile: Path) -> list[str]:
    """Extract package names from [packages] section of Pipfile."""
    deps: list[str] = []
    in_packages = False
    try:
        text = pipfile.read_text(encoding="utf-8")
    except OSError:
        return []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped == "[packages]":
            in_packages = True
            continue
        if in_packages:
            if stripped.startswith("["):
                break
            if "=" in stripped and not stripped.startswith("#"):
                key = stripped.split("=")[0].strip()
                if key:
                    deps.append(key)
    return deps


def _find_python_app_module(path: Path) -> str:
    for candidate in _PYTHON_APP_CANDIDATES:
        full = path / candidate
        if full.exists():
            module = candidate.replace("/", ".").removesuffix(".py")
            return module
    return "app"


def _find_streamlit_entry(path: Path) -> str:
    for name in ("app.py", "main.py", "streamlit_app.py"):
        if (path / name).exists():
            return name
    return "app.py"


def _find_django_wsgi(path: Path) -> str:
    """Find Django WSGI application module from settings files."""
    for settings_file in _iter_project_files(path, filenames={"settings.py"}):
        try:
            text = settings_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        m = _DJANGO_WSGI_RE.search(text)
        if m:
            return m.group(1)
    # Fallback: use project directory name
    return f"{path.name}.wsgi"


# ---------------------------------------------------------------------------
# Go detection
# ---------------------------------------------------------------------------

def _detect_go(path: Path) -> DeployPlan:
    # Determine build target
    build_target = "."
    if list(path.glob("*.go")):
        build_target = "."
    elif (path / "cmd").is_dir():
        subdirs = sorted([d.name for d in (path / "cmd").iterdir() if d.is_dir()])
        if subdirs:
            build_target = f"./cmd/{subdirs[0]}"
    elif (path / "main.go").exists():
        build_target = "."

    go_version = _detect_go_version(path)
    build_cmd = (
        'export GOROOT="$HOME/.local/go" && export PATH="$GOROOT/bin:$PATH" && '
        f"CGO_ENABLED=0 go build -ldflags='-w -s' -o app {build_target}"
    )
    install_cmd = (
        f'GO_VERSION="{go_version}" && '
        'case "$GO_VERSION" in *.*.*) ;; *) GO_VERSION="$GO_VERSION.0" ;; esac && '
        'export GOROOT="$HOME/.local/go" && export PATH="$GOROOT/bin:$PATH" && '
        'if [ ! -x "$GOROOT/bin/go" ] || ! "$GOROOT/bin/go" version | grep -q "go$GO_VERSION"; then '
        'rm -rf "$GOROOT" && mkdir -p "$HOME/.local" && '
        'curl -fsSL "https://dl.google.com/go/go$GO_VERSION.linux-amd64.tar.gz" -o /tmp/instavm-go.tgz && '
        'tar -C "$HOME/.local" -xzf /tmp/instavm-go.tgz; '
        'fi && go mod download'
    )

    # Port detection
    port = _detect_go_port(path)

    # Health path
    health = _detect_go_health_path(path)

    # Secrets
    secrets = _collect_secrets(path, [], "go")

    return DeployPlan(
        slug=_slugify(path.name),
        runtime="go",
        package_manager="go",
        install_command=install_cmd,
        build_command=build_cmd,
        start_command="./app",
        port=port,
        health_path=health,
        secrets=secrets,
    )


def _detect_go_port(path: Path) -> int:
    for candidate in _GO_SOURCE_CANDIDATES:
        full = path / candidate
        if full.exists():
            try:
                text = full.read_text(encoding="utf-8")
            except OSError:
                continue
            m = _GO_PORT_RE.search(text)
            if m:
                return int(m.group(1))
            m = _PORT_PATTERN_RE.search(text)
            if m:
                return int(m.group(1))
    # Also check all .go files in root
    for go_file in path.glob("*.go"):
        try:
            text = go_file.read_text(encoding="utf-8")
        except OSError:
            continue
        m = _GO_PORT_RE.search(text)
        if m:
            return int(m.group(1))
    return 8080


def _detect_go_version(path: Path) -> str:
    go_mod = path / "go.mod"
    if not go_mod.exists():
        return "1.23.0"
    try:
        text = go_mod.read_text(encoding="utf-8")
    except OSError:
        return "1.23.0"
    match = re.search(r"^go\s+([0-9]+(?:\.[0-9]+){1,2})\s*$", text, re.MULTILINE)
    if not match:
        return "1.23.0"
    return match.group(1)


def _detect_go_health_path(path: Path) -> str:
    for candidate in _GO_SOURCE_CANDIDATES:
        full = path / candidate
        if full.exists():
            try:
                text = full.read_text(encoding="utf-8")
            except OSError:
                continue
            m = _GO_HEALTH_RE.search(text)
            if m:
                return m.group(1)
    for go_file in path.glob("*.go"):
        try:
            text = go_file.read_text(encoding="utf-8")
        except OSError:
            continue
        m = _GO_HEALTH_RE.search(text)
        if m:
            return m.group(1)
    return "/"


# ---------------------------------------------------------------------------
# Deno detection
# ---------------------------------------------------------------------------

def _detect_deno(path: Path) -> DeployPlan:
    main_file = _find_deno_main(path)
    if not main_file:
        raise ValueError(
            "Could not detect start command. "
            "No main.ts, main.js, server.ts, server.js, app.ts, or app.js found. "
            "Use --start-command to specify how to start the app."
        )

    # Port detection from main file
    port = 8000
    full = path / main_file
    if full.exists():
        try:
            text = full.read_text(encoding="utf-8")
            m = re.search(r"port:\s*(\d{2,5})", text)
            if m:
                port = int(m.group(1))
            else:
                m = _PORT_PATTERN_RE.search(text)
                if m:
                    port = int(m.group(1))
        except OSError:
            pass

    secrets = _collect_secrets(path, [], "deno")

    return DeployPlan(
        slug=_slugify(path.name),
        runtime="deno",
        package_manager="deno",
        install_command="curl -fsSL https://deno.land/install.sh | sh",
        build_command=None,
        start_command=f"$HOME/.deno/bin/deno run --allow-all {main_file}",
        port=port,
        health_path="/",
        secrets=secrets,
    )


def _find_deno_main(path: Path) -> Optional[str]:
    for candidate in _DENO_MAIN_CANDIDATES:
        if (path / candidate).exists():
            return candidate
    return None


# ---------------------------------------------------------------------------
# Static site detection
# ---------------------------------------------------------------------------

def _has_static_signals(path: Path) -> bool:
    if (path / "index.html").exists():
        return True
    return any((path / d / "index.html").exists() for d in _STATIC_ROOT_CANDIDATES)


def _find_static_root(path: Path) -> str:
    for candidate in _STATIC_ROOT_CANDIDATES:
        if (path / candidate / "index.html").exists():
            return candidate
    if (path / "index.html").exists():
        return "."
    raise ValueError(
        "Could not detect project type. "
        "Expected package.json, requirements.txt, pyproject.toml, Pipfile, "
        "go.mod, deno.json, or index.html."
    )


def _detect_static(path: Path) -> DeployPlan:
    root_dir = _find_static_root(path)
    port = 3000
    return DeployPlan(
        slug=_slugify(path.name),
        runtime="static",
        package_manager="none",
        install_command="echo 'No dependencies'",
        build_command=None,
        start_command=f"python3 -m http.server {port} --directory {root_dir} --bind 0.0.0.0",
        port=port,
        health_path="/",
        secrets=[],
    )


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _detect_port_from_start_script(script: str) -> Optional[int]:
    m = re.search(r"--port\s+(\d+)", script)
    if m:
        return int(m.group(1))
    m = re.search(r"-p\s+(\d+)", script)
    if m:
        return int(m.group(1))
    return None


def _detect_port_from_source(path: Path, candidates: list[str]) -> Optional[int]:
    for candidate in candidates:
        full = path / candidate
        if full.exists():
            try:
                text = full.read_text(encoding="utf-8")
            except OSError:
                continue
            m = _PORT_PATTERN_RE.search(text)
            if m:
                return int(m.group(1))
    return None


def _detect_health_path(path: Path) -> str:
    """Detect health path from route definitions in source files."""
    all_candidates = list(_PYTHON_APP_CANDIDATES) + list(_NODE_SOURCE_CANDIDATES)
    for candidate in all_candidates:
        full = path / candidate
        if full.exists():
            try:
                text = full.read_text(encoding="utf-8")
            except OSError:
                continue
            m = _HEALTH_ROUTE_RE.search(text)
            if m:
                return m.group(1)
    return "/health"


def _collect_secrets(path: Path, deps: list[str], runtime: str) -> list[SecretSpec]:
    seen: set[str] = set()
    secrets: list[SecretSpec] = []

    # Hints from known dependency → env var mapping
    for dep in deps:
        dep_key = dep.lower().split("==")[0].split(">=")[0].split("[")[0].strip()
        if dep_key in _DEP_SECRET_HINTS:
            env_name, prompt = _DEP_SECRET_HINTS[dep_key]
            if env_name not in seen:
                seen.add(env_name)
                secrets.append(SecretSpec(name=env_name, prompt=prompt, env_name=env_name, required=True))

    # Scan source files for env var references
    scanned = _scan_env_vars(path, runtime)
    for var in sorted(scanned):
        if var not in seen and var not in _NON_SECRET_VARS:
            seen.add(var)
            secrets.append(SecretSpec(name=var, prompt=f"{var}", env_name=var, required=False))

    return secrets


def _scan_env_vars(path: Path, runtime: str) -> set[str]:
    """Scan source files for environment variable references."""
    found: set[str] = set()
    if runtime == "python":
        extensions = ("*.py",)
        pattern = _PYTHON_ENV_RE
    elif runtime == "go":
        extensions = ("*.go",)
        pattern = _GO_ENV_RE
    elif runtime == "deno":
        extensions = ("*.ts", "*.js", "*.mjs", "*.mts")
        pattern = _DENO_ENV_RE
    else:
        extensions = ("*.js", "*.ts", "*.mjs", "*.tsx", "*.jsx")
        pattern = _NODE_ENV_RE

    for ext in extensions:
        for source_file in _iter_project_files(path, extensions={ext.lstrip("*")}):
            try:
                text = source_file.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for m in pattern.finditer(text):
                var = m.group(1) or (m.group(2) if m.lastindex and m.lastindex >= 2 else None)
                if var:
                    found.add(var)

    return found


def _iter_project_files(
    project_root: Path,
    *,
    extensions: Optional[set[str]] = None,
    filenames: Optional[set[str]] = None,
) -> list[Path]:
    skip_dirs = {"node_modules", ".venv", "venv", "__pycache__", ".git", "dist", "build", ".next"}
    matches: list[Path] = []

    for dirpath, dirnames, file_names in os.walk(project_root, topdown=True, followlinks=False):
        dirnames[:] = [name for name in dirnames if name not in skip_dirs]
        base = Path(dirpath)
        for file_name in file_names:
            file_path = base / file_name
            if filenames is not None and file_name not in filenames:
                continue
            if extensions is not None and file_path.suffix not in extensions:
                continue
            matches.append(file_path)
    return matches


def _should_skip_file(source_file: Path, project_root: Path) -> bool:
    rel = source_file.relative_to(project_root)
    parts = rel.parts
    skip_dirs = {"node_modules", ".venv", "venv", "__pycache__", ".git", "dist", "build", ".next"}
    return bool(skip_dirs & set(parts))


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower().strip())
    return slug.strip("-") or "app"
