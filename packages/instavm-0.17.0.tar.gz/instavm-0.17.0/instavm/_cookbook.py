from __future__ import annotations

import fnmatch
import hashlib
import getpass
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from base64 import b64decode, b64encode
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Optional, Sequence
from urllib import error as urllib_error
from urllib import parse as urllib_parse
from urllib import request as urllib_request

import yaml

from ._cli_config import get_config_dir
from .exceptions import InstaVMError

DEFAULT_COOKBOOK_REPO_URL = "https://github.com/instavm/cookbooks.git"
DEFAULT_COOKBOOK_REF = "main"
DEFAULT_REMOTE_ROOT = ".instavm-cookbooks"
DEFAULT_SOURCE_EXCLUDES = (
    ".git",
    ".git/*",
    "__pycache__",
    "__pycache__/*",
    ".pytest_cache",
    ".pytest_cache/*",
    ".venv",
    ".venv/*",
    "venv",
    "venv/*",
    "node_modules",
    "node_modules/*",
    ".next",
    ".next/*",
    "dist",
    "dist/*",
    "build",
    "build/*",
    "*.pyc",
    ".DS_Store",
)


class CookbookError(RuntimeError):
    """Raised when cookbook commands cannot complete safely."""


class CookbookDeployError(CookbookError):
    """Raised when deploy fails after creating resources."""

    def __init__(self, message: str, payload: Mapping[str, Any]):
        super().__init__(message)
        self.payload = dict(payload)


@dataclass(frozen=True)
class SecretSpec:
    name: str
    prompt: str
    env_name: str
    required: bool = True


@dataclass(frozen=True)
class DeploySpec:
    kind: str


@dataclass(frozen=True)
class VMConfig:
    memory_mb: int
    vcpu_count: int
    timeout_seconds: Optional[int]
    image_variant: Optional[str]


@dataclass(frozen=True)
class AppConfig:
    port: int
    healthcheck_path: str
    share_public_default: bool
    readiness_timeout_seconds: int


@dataclass(frozen=True)
class RunConfig:
    workdir: str
    start_command: str
    logs_hint: Optional[str]


@dataclass(frozen=True)
class ArtifactConfig:
    oci_image: str
    snapshot_name: str
    snapshot_visibility: str


@dataclass(frozen=True)
class BuildConfig:
    context: str
    dockerfile: str
    target: Optional[str]


@dataclass(frozen=True)
class SourceConfig:
    include: tuple[str, ...]
    exclude: tuple[str, ...]
    setup_command: str


@dataclass(frozen=True)
class CookbookManifest:
    path: Path
    schema_version: int
    slug: str
    title: str
    version: str
    summary: str
    category: str
    runtime: str
    deploy: DeploySpec
    vm: VMConfig
    app: AppConfig
    run: RunConfig
    secrets: tuple[SecretSpec, ...]
    post_deploy_notes: tuple[str, ...]
    artifact: Optional[ArtifactConfig]
    build: Optional[BuildConfig]
    source: Optional[SourceConfig]


def _require_mapping(value: Any, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise CookbookError(f"Manifest field `{field_name}` must be an object.")
    return value


def _require_string(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise CookbookError(f"Manifest field `{field_name}` must be a non-empty string.")
    return value.strip()


def _require_int(value: Any, field_name: str) -> int:
    if not isinstance(value, int):
        raise CookbookError(f"Manifest field `{field_name}` must be an integer.")
    return value


def _optional_int(value: Any, field_name: str) -> Optional[int]:
    if value is None:
        return None
    return _require_int(value, field_name)


def _optional_string(value: Any) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        raise CookbookError("Expected an optional string value.")
    cleaned = value.strip()
    return cleaned or None


def get_cookbook_cache_dir(home: Optional[Path] = None) -> Path:
    return get_config_dir(home) / "cookbooks"


def get_cookbook_repo_dir(home: Optional[Path] = None) -> Path:
    return get_cookbook_cache_dir(home) / "repo"


def resolve_cookbook_root(home: Optional[Path] = None, progress: Optional[Callable[[str], None]] = None) -> Path:
    override_dir = os.environ.get("INSTAVM_COOKBOOKS_DIR")
    if override_dir:
        root = Path(override_dir).expanduser().resolve()
        if not root.exists():
            raise CookbookError(f"Cookbook directory override does not exist: {root}")
        return root
    return sync_cookbook_repo(home=home, progress=progress)


def sync_cookbook_repo(home: Optional[Path] = None, progress: Optional[Callable[[str], None]] = None) -> Path:
    repo_url = os.environ.get("INSTAVM_COOKBOOKS_REPO", DEFAULT_COOKBOOK_REPO_URL)
    repo_ref = os.environ.get("INSTAVM_COOKBOOKS_REF", DEFAULT_COOKBOOK_REF)
    repo_dir = get_cookbook_repo_dir(home)
    repo_dir.parent.mkdir(parents=True, exist_ok=True)

    if progress:
        progress(f"Syncing cookbook catalog from {repo_url}")

    if not (repo_dir / ".git").exists():
        _run_command(
            ["git", "clone", "--depth", "1", "--branch", repo_ref, repo_url, str(repo_dir)],
            error_message="Failed to clone the cookbook catalog.",
        )
        return repo_dir

    _run_command(
        ["git", "-C", str(repo_dir), "fetch", "--depth", "1", "origin", repo_ref],
        error_message="Failed to update the cookbook catalog.",
    )
    _run_command(
        ["git", "-C", str(repo_dir), "checkout", repo_ref],
        error_message="Failed to check out the cookbook catalog branch.",
    )
    _run_command(
        ["git", "-C", str(repo_dir), "reset", "--hard", "FETCH_HEAD"],
        error_message="Failed to reset the cookbook catalog to the latest remote state.",
    )
    return repo_dir


def discover_cookbooks(root: Path) -> list[CookbookManifest]:
    manifests: list[CookbookManifest] = []
    if not root.exists():
        return manifests
    for entry in sorted(root.iterdir(), key=lambda path: path.name):
        manifest_path = entry / "instavm.yaml"
        if entry.is_dir() and manifest_path.exists():
            manifests.append(load_manifest(manifest_path))
    return manifests


def load_manifest(manifest_path: Path | str) -> CookbookManifest:
    path = Path(manifest_path)
    try:
        raw_data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise CookbookError(f"Unable to read manifest: {path}") from exc
    except yaml.YAMLError as exc:
        raise CookbookError(f"Invalid YAML in manifest: {path}") from exc

    data = _require_mapping(raw_data, "root")
    required_fields = {
        "schema_version",
        "slug",
        "title",
        "version",
        "summary",
        "category",
        "runtime",
        "deploy",
        "vm",
        "app",
        "run",
        "secrets",
        "post_deploy_notes",
    }
    missing = sorted(required_fields - set(data))
    if missing:
        raise CookbookError(f"Manifest is missing required fields: {', '.join(missing)}")
    deploy = _require_mapping(data.get("deploy"), "deploy")
    vm = _require_mapping(data.get("vm"), "vm")
    app = _require_mapping(data.get("app"), "app")
    run = _require_mapping(data.get("run"), "run")

    secret_specs: list[SecretSpec] = []
    raw_secrets = data.get("secrets") or []
    if not isinstance(raw_secrets, Sequence) or isinstance(raw_secrets, (str, bytes)):
        raise CookbookError("Manifest field `secrets` must be an array.")
    for index, raw_secret in enumerate(raw_secrets):
        secret = _require_mapping(raw_secret, f"secrets[{index}]")
        secret_specs.append(
            SecretSpec(
                name=_require_string(secret.get("name"), f"secrets[{index}].name"),
                prompt=_require_string(secret.get("prompt"), f"secrets[{index}].prompt"),
                env_name=_require_string(secret.get("env_name"), f"secrets[{index}].env_name"),
                required=bool(secret.get("required", True)),
            )
        )

    artifact = None
    build = None
    source = None

    deploy_kind = _require_string(deploy.get("kind"), "deploy.kind")
    if deploy_kind == "published_snapshot":
        artifact_data = _require_mapping(data.get("artifact"), "artifact")
        build_data = _require_mapping(data.get("build"), "build")
        artifact = ArtifactConfig(
            oci_image=_require_string(artifact_data.get("oci_image"), "artifact.oci_image"),
            snapshot_name=_require_string(artifact_data.get("snapshot_name"), "artifact.snapshot_name"),
            snapshot_visibility=_require_string(
                artifact_data.get("snapshot_visibility"), "artifact.snapshot_visibility"
            ),
        )
        build = BuildConfig(
            context=_require_string(build_data.get("context"), "build.context"),
            dockerfile=_require_string(build_data.get("dockerfile"), "build.dockerfile"),
            target=_optional_string(build_data.get("target")),
        )
        if artifact.snapshot_visibility != "public_system":
            raise CookbookError("Manifest field `artifact.snapshot_visibility` must be `public_system`.")
        if not (path.parent / build.context).exists():
            raise CookbookError(f"Build context does not exist: {path.parent / build.context}")
        if not (path.parent / build.dockerfile).exists():
            raise CookbookError(f"Dockerfile does not exist: {path.parent / build.dockerfile}")
    elif deploy_kind == "upload_and_run":
        source_data = _require_mapping(data.get("source"), "source")
        include = source_data.get("include") or []
        exclude = source_data.get("exclude") or []
        if not isinstance(include, Sequence) or isinstance(include, (str, bytes)):
            raise CookbookError("Manifest field `source.include` must be an array.")
        if not isinstance(exclude, Sequence) or isinstance(exclude, (str, bytes)):
            raise CookbookError("Manifest field `source.exclude` must be an array.")
        source = SourceConfig(
            include=tuple(_require_string(item, "source.include[]") for item in include),
            exclude=tuple(_require_string(item, "source.exclude[]") for item in exclude),
            setup_command=_require_string(source_data.get("setup_command"), "source.setup_command"),
        )
        if not source.include:
            raise CookbookError("Manifest field `source.include` must contain at least one path or glob.")
    else:
        raise CookbookError("Manifest field `deploy.kind` must be `published_snapshot` or `upload_and_run`.")

    notes = data.get("post_deploy_notes") or []
    if isinstance(notes, str):
        post_deploy_notes = (notes.strip(),) if notes.strip() else ()
    elif isinstance(notes, Sequence):
        post_deploy_notes = tuple(_require_string(note, "post_deploy_notes[]") for note in notes)
    else:
        raise CookbookError("Manifest field `post_deploy_notes` must be a string or array of strings.")

    manifest = CookbookManifest(
        path=path.parent,
        schema_version=_require_int(data.get("schema_version"), "schema_version"),
        slug=_require_string(data.get("slug"), "slug"),
        title=_require_string(data.get("title"), "title"),
        version=_require_string(data.get("version"), "version"),
        summary=_require_string(data.get("summary"), "summary"),
        category=_require_string(data.get("category"), "category"),
        runtime=_require_string(data.get("runtime"), "runtime"),
        deploy=DeploySpec(kind=deploy_kind),
        vm=VMConfig(
            memory_mb=_require_int(vm.get("memory_mb"), "vm.memory_mb"),
            vcpu_count=_require_int(vm.get("vcpu_count"), "vm.vcpu_count"),
            timeout_seconds=_optional_int(vm.get("timeout_seconds"), "vm.timeout_seconds"),
            image_variant=_optional_string(vm.get("image_variant")),
        ),
        app=AppConfig(
            port=_require_int(app.get("port"), "app.port"),
            healthcheck_path=_require_string(app.get("healthcheck_path"), "app.healthcheck_path"),
            share_public_default=bool(app.get("share_public_default", True)),
            readiness_timeout_seconds=_require_int(
                app.get("readiness_timeout_seconds"), "app.readiness_timeout_seconds"
            ),
        ),
        run=RunConfig(
            workdir=_require_string(run.get("workdir"), "run.workdir"),
            start_command=_require_string(run.get("start_command"), "run.start_command"),
            logs_hint=_optional_string(run.get("logs_hint")),
        ),
        secrets=tuple(secret_specs),
        post_deploy_notes=post_deploy_notes,
        artifact=artifact,
        build=build,
        source=source,
    )
    if not manifest.app.healthcheck_path.startswith("/"):
        raise CookbookError("Manifest field `app.healthcheck_path` must start with `/`.")
    if manifest.schema_version != 1:
        raise CookbookError("Unsupported cookbook schema version. Expected `schema_version: 1`.")
    return manifest


def manifest_display_record(manifest: CookbookManifest) -> dict[str, Any]:
    return {
        "slug": manifest.slug,
        "title": manifest.title,
        "summary": manifest.summary,
        "runtime": manifest.runtime,
        "category": manifest.category,
        "deploy_kind": manifest.deploy.kind,
        "port": manifest.app.port,
        "requires_secrets": bool(manifest.secrets),
        "version": manifest.version,
    }


def preflight_tools() -> dict[str, str]:
    binaries = ("git", "ssh", "scp", "tar")
    found: dict[str, str] = {}
    missing: list[str] = []
    for binary in binaries:
        resolved = shutil.which(binary) or shutil.which(f"{binary}.exe")
        if resolved:
            found[binary] = resolved
        else:
            missing.append(binary)
    if missing:
        raise CookbookError(f"Missing required local tools: {', '.join(missing)}")
    return found


def scan_public_keys(home: Optional[Path] = None) -> list[Path]:
    ssh_dir = (home or Path.home()) / ".ssh"
    if not ssh_dir.exists():
        return []
    return sorted(path for path in ssh_dir.glob("*.pub") if path.is_file())


def _public_key_fingerprint(path: Path) -> Optional[str]:
    try:
        parts = path.read_text(encoding="utf-8").strip().split()
    except OSError:
        return None
    if len(parts) < 2:
        return None
    try:
        key_blob = b64decode(parts[1].encode("ascii"))
    except Exception:
        return None
    fingerprint = b64encode(hashlib.sha256(key_blob).digest()).decode("ascii").rstrip("=")
    return f"SHA256:{fingerprint}"


def _matching_local_public_key(account_keys: Sequence[Mapping[str, Any]], candidates: Sequence[Path]) -> Optional[Path]:
    known_fingerprints = {
        str(key.get("fingerprint") or "").strip()
        for key in account_keys
        if str(key.get("fingerprint") or "").strip()
    }
    if not known_fingerprints:
        return None
    for candidate in candidates:
        fingerprint = _public_key_fingerprint(candidate)
        if fingerprint and fingerprint in known_fingerprints:
            return candidate
    return None


def ensure_account_ssh_key(
    client: Any,
    *,
    home: Optional[Path] = None,
    progress: Optional[Callable[[str], None]] = None,
) -> dict[str, Any]:
    keys = client.list_ssh_keys()
    candidates = scan_public_keys(home)
    if keys:
        selected = _matching_local_public_key(keys, candidates)
        if progress and selected:
            progress(f"Using local SSH identity from {selected}")
        return {"configured": True, "auto_added": False, "keys": keys, "selected_path": str(selected) if selected else None}

    if not candidates:
        raise CookbookError(
            "No SSH key is registered on your account, and no local public key was found in ~/.ssh. "
            "Generate one with `ssh-keygen -t ed25519` and rerun the command."
        )

    if progress:
        progress("No account SSH key found. Selecting a local public key to register.")

    selected = candidates[0]
    if len(candidates) > 1 and sys.stdin.isatty():
        sys.stdout.write("Select a public key to add:\n")
        for index, candidate in enumerate(candidates, start=1):
            sys.stdout.write(f"  {index}. {candidate}\n")
        choice = input("Choose a key [1]: ").strip()
        if choice:
            try:
                selected = candidates[max(int(choice) - 1, 0)]
            except (ValueError, IndexError):
                raise CookbookError("Invalid SSH key selection.")

    ordered_candidates = [selected, *[candidate for candidate in candidates if candidate != selected]]
    failures: list[str] = []
    for candidate in ordered_candidates:
        public_key = candidate.read_text(encoding="utf-8").strip()
        if not public_key:
            failures.append(f"{candidate}: empty file")
            continue
        try:
            result = client.add_ssh_key(public_key)
        except InstaVMError as exc:
            failures.append(f"{candidate}: {exc}")
            continue
        if progress:
            progress(f"Registered SSH key from {candidate}")
        return {"configured": True, "auto_added": True, "selected_path": str(candidate), "result": result}

    raise CookbookError(
        "Unable to register any local public SSH key. "
        f"Tried: {'; '.join(failures)}"
    )


def resolve_secret_values(
    manifest: CookbookManifest,
    *,
    env: Optional[Mapping[str, str]] = None,
) -> tuple[dict[str, str], list[str]]:
    env_map = env or os.environ
    values: dict[str, str] = {}
    configured_names: list[str] = []
    for secret in manifest.secrets:
        value = (env_map.get(secret.env_name) or "").strip()
        if not value and secret.required:
            if not sys.stdin.isatty():
                raise CookbookError(
                    f"Secret `{secret.env_name}` is required for `{manifest.slug}`. "
                    f"Set it in the environment or rerun interactively."
                )
            value = getpass.getpass(f"{secret.prompt}: ").strip()
        if value:
            values[secret.env_name] = value
            configured_names.append(secret.env_name)
        elif secret.required:
            raise CookbookError(f"Secret `{secret.env_name}` is required for `{manifest.slug}`.")
    return values, configured_names


def resolve_snapshot_id(client: Any, manifest: CookbookManifest) -> str:
    if not manifest.artifact:
        raise CookbookError("Published snapshot deploys require `artifact` config.")
    snapshots = client.snapshots.list(snapshot_type="system")
    for snapshot in snapshots:
        if (
            snapshot.get("name") == manifest.artifact.snapshot_name
            and snapshot.get("status") == "ready"
            and snapshot.get("is_public")
        ):
            return str(snapshot.get("id"))
    raise CookbookError(
        f"Public system snapshot `{manifest.artifact.snapshot_name}` was not found or is not ready."
    )


def build_vm_payload(manifest: CookbookManifest, snapshot_id: Optional[str] = None) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "memory_mb": manifest.vm.memory_mb,
        "vcpu_count": manifest.vm.vcpu_count,
        "vm_lifetime_seconds": manifest.vm.timeout_seconds,
    }
    if manifest.vm.image_variant:
        payload["image_variant"] = manifest.vm.image_variant
    if snapshot_id:
        payload["snapshot_id"] = snapshot_id
    return {key: value for key, value in payload.items() if value is not None}


def _is_resource_tier_error(exc: InstaVMError) -> bool:
    # The current public API does not expose a stable structured error code for
    # free-tier sizing limits, so we must fall back to message inspection here.
    message = str(exc).lower()
    return "free tier" in message and ("configurable cpu" in message or "configurable memory" in message)


def _plan_lifetime_limit_seconds(exc: InstaVMError) -> Optional[int]:
    match = re.search(r"vm lifetime cannot exceed\s+(\d+)s", str(exc), re.IGNORECASE)
    if not match:
        return None
    return int(match.group(1))


def create_vm(
    client: Any,
    manifest: CookbookManifest,
    *,
    snapshot_id: Optional[str] = None,
    progress: Optional[Callable[[str], None]] = None,
) -> dict[str, Any]:
    payload = build_vm_payload(manifest, snapshot_id=snapshot_id)
    adjusted_for_tier = False
    adjusted_for_lifetime = False
    while True:
        try:
            return client.vms.create(wait=True, **payload)
        except InstaVMError as exc:
            next_payload = dict(payload)

            if _is_resource_tier_error(exc) and any(key in next_payload for key in {"memory_mb", "vcpu_count"}):
                next_payload = {
                    key: value for key, value in next_payload.items() if key not in {"memory_mb", "vcpu_count"}
                }
                if progress and not adjusted_for_tier:
                    progress("Requested CPU or memory exceeds the current account tier.")
                    progress("Retrying VM creation with platform defaults")
                adjusted_for_tier = True

            lifetime_limit = _plan_lifetime_limit_seconds(exc)
            current_lifetime = next_payload.get("vm_lifetime_seconds")
            if lifetime_limit is not None and current_lifetime and current_lifetime > lifetime_limit:
                next_payload["vm_lifetime_seconds"] = lifetime_limit
                if progress and not adjusted_for_lifetime:
                    progress("Requested VM lifetime exceeds the current account tier.")
                    progress(f"Retrying VM creation with a {lifetime_limit}s lifetime")
                adjusted_for_lifetime = True

            if next_payload == payload:
                raise
            payload = next_payload


def package_source(manifest: CookbookManifest) -> Path:
    if manifest.source is None:
        raise CookbookError("Upload-and-run cookbooks require `source` config.")
    temp_file = tempfile.NamedTemporaryFile(prefix=f"{manifest.slug}-", suffix=".tar.gz", delete=False)
    temp_path = Path(temp_file.name)
    temp_file.close()

    excludes = tuple(set(DEFAULT_SOURCE_EXCLUDES + manifest.source.exclude))

    with tarfile.open(temp_path, "w:gz") as archive:
        for item in manifest.path.rglob("*"):
            if item == temp_path:
                continue
            if item.is_dir():
                continue
            relative = item.relative_to(manifest.path).as_posix()
            if not _should_include(relative, manifest.source.include, excludes):
                continue
            archive.add(item, arcname=relative)
    return temp_path


def _should_include(relative_path: str, include: Sequence[str], exclude: Sequence[str]) -> bool:
    if any(fnmatch.fnmatch(relative_path, pattern) for pattern in exclude):
        return False
    if not include:
        return True
    return any(
        fnmatch.fnmatch(relative_path, pattern)
        or relative_path == pattern
        or relative_path.startswith(f"{pattern.rstrip('/')}/")
        for pattern in include
    )


def _run_deploy(
    manifest: CookbookManifest,
    *,
    client: Any,
    ssh_host: str,
    progress: Optional[Callable[[str], None]] = None,
    snapshot_id_override: Optional[str] = None,
) -> dict[str, Any]:
    """Core deploy pipeline shared by ``deploy_cookbook`` and ``instavm deploy``."""
    preflight_tools()
    ssh_key_info = ensure_account_ssh_key(client, progress=progress)
    secret_values, configured_secret_names = resolve_secret_values(manifest)

    snapshot_id = snapshot_id_override
    if snapshot_id is None and manifest.deploy.kind == "published_snapshot":
        if progress:
            progress(f"Resolving public snapshot {manifest.artifact.snapshot_name}")
        snapshot_id = resolve_snapshot_id(client, manifest)

    if progress:
        progress("Creating VM")
    vm = create_vm(client, manifest, snapshot_id=snapshot_id, progress=progress)
    vm_id = str(vm.get("vm_id") or "")
    session_id = str(vm.get("session_id") or "")
    if not vm_id:
        raise CookbookError("VM creation did not return a VM ID.")

    ssh_target = f"{vm_id}@{ssh_host}"
    identity_file = _resolve_identity_file(ssh_key_info.get("selected_path"))
    remote_base = f"/home/appuser/{DEFAULT_REMOTE_ROOT}"
    remote_root = f"{remote_base}/{manifest.slug}"
    workdir = _remote_workdir(manifest, remote_root)
    connect_command = _connect_command(vm_id, ssh_host, identity_file)

    service_name = f"instavm-cookbook-{manifest.slug}"
    service_mode = "unknown"

    try:
        if progress:
            progress("Waiting for SSH access")
        wait_for_ssh_ready(ssh_target, identity_file=identity_file)
        remote_base = _resolve_remote_base(ssh_target=ssh_target, identity_file=identity_file)
        remote_root = f"{remote_base}/{manifest.slug}"
        workdir = _remote_workdir(manifest, remote_root)

        if manifest.deploy.kind == "upload_and_run":
            upload_path = package_source(manifest)
            try:
                remote_tarball = f"/tmp/{manifest.slug}-{int(time.time())}.tar.gz"
                if progress:
                    progress("Uploading cookbook source")
                run_scp(
                    upload_path.as_posix(),
                    f"{ssh_target}:{remote_tarball}",
                    "Failed to upload the cookbook bundle to the VM.",
                    identity_file=identity_file,
                )
                extract_command = (
                    f"mkdir -p {sh_quote(remote_root)} && "
                    f"tar -xzf {sh_quote(remote_tarball)} -C {sh_quote(remote_root)} && "
                    f"rm -f {sh_quote(remote_tarball)}"
                )
                run_ssh(ssh_target, extract_command, "Failed to extract the cookbook bundle.", identity_file=identity_file)
                if progress:
                    progress("Running cookbook setup")
                run_ssh(
                    ssh_target,
                    f"cd {sh_quote(workdir)} && {manifest.source.setup_command}",
                    "Cookbook setup command failed.",
                    identity_file=identity_file,
                )
            finally:
                upload_path.unlink(missing_ok=True)

        if progress:
            progress("Starting application service")
        service_name, service_mode = start_remote_service(
            ssh_target=ssh_target,
            manifest=manifest,
            remote_root=remote_root,
            workdir=workdir,
            secret_values=secret_values,
            identity_file=identity_file,
            progress=None,
        )

        if progress:
            progress("Waiting for application healthcheck")
        wait_for_internal_health(
            ssh_target=ssh_target,
            port=manifest.app.port,
            health_path=manifest.app.healthcheck_path,
            timeout_seconds=manifest.app.readiness_timeout_seconds,
            identity_file=identity_file,
        )

        if progress:
            progress("Creating public share")
        share = client.shares.create(
            port=manifest.app.port,
            vm_id=vm_id,
            is_public=manifest.app.share_public_default,
        )
        share_url = str(share.get("url") or "")
        if not share_url:
            raise CookbookError("Share creation did not return a URL.")

        if progress:
            progress("Verifying public share URL")
        healthcheck_url = urllib_parse.urljoin(
            share_url if share_url.endswith("/") else f"{share_url}/",
            manifest.app.healthcheck_path.lstrip("/"),
        )
        verify_public_share(healthcheck_url, timeout_seconds=manifest.app.readiness_timeout_seconds)
    except CookbookError as exc:
        partial_payload = {
            "slug": manifest.slug,
            "version": manifest.version,
            "deploy_kind": manifest.deploy.kind,
            "vm_id": vm_id,
            "session_id": session_id,
            "service_name": service_name,
            "service_mode": service_mode,
            "port": manifest.app.port,
            "connect_command": connect_command,
            "logs_command": _logs_command(
                vm_id,
                ssh_host,
                manifest.slug,
                service_name,
                service_mode,
                remote_base,
                manifest.run.logs_hint,
                identity_file,
            ),
            "destroy_command": f"instavm rm {vm_id}",
            "configured_secrets": configured_secret_names,
        }
        raise CookbookDeployError(str(exc), partial_payload) from exc

    logs_command = _logs_command(
        vm_id,
        ssh_host,
        manifest.slug,
        service_name,
        service_mode,
        remote_base,
        manifest.run.logs_hint,
        identity_file,
    )
    payload = {
        "slug": manifest.slug,
        "version": manifest.version,
        "deploy_kind": manifest.deploy.kind,
        "vm_id": vm_id,
        "session_id": session_id,
        "service_name": service_name,
        "service_mode": service_mode,
        "port": manifest.app.port,
        "share_url": share_url,
        "healthcheck_url": healthcheck_url,
        "connect_command": connect_command,
        "logs_command": logs_command,
        "destroy_command": f"instavm rm {vm_id}",
        "configured_secrets": configured_secret_names,
        "notes": list(manifest.post_deploy_notes),
    }
    return payload


def deploy_cookbook(
    manifest: CookbookManifest,
    *,
    client: Any,
    ssh_host: str,
    progress: Optional[Callable[[str], None]] = None,
) -> dict[str, Any]:
    """Deploy a catalog cookbook application."""
    return _run_deploy(manifest, client=client, ssh_host=ssh_host, progress=progress)


def start_remote_service(
    *,
    ssh_target: str,
    manifest: CookbookManifest,
    remote_root: str,
    workdir: str,
    secret_values: Mapping[str, str],
    identity_file: Optional[str] = None,
    progress: Optional[Callable[[str], None]] = None,
) -> tuple[str, str]:
    unit_name = f"instavm-cookbook-{manifest.slug}"
    remote_base = remote_root.rsplit("/", 1)[0]
    log_file = f"{remote_base}/logs/{manifest.slug}.log"
    environment_exports = " ".join(
        f"{key}={sh_quote(value)}" for key, value in sorted(secret_values.items())
    )
    launch_body = f"cd {sh_quote(workdir)} && {environment_exports} {manifest.run.start_command}".strip()
    remote_script = f"""
set -e
mkdir -p {sh_quote(f"{remote_base}/logs")}
mkdir -p {sh_quote(remote_root)}
if command -v systemd-run >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
  if systemd-run --unit {sh_quote(unit_name)} --collect --quiet --property=WorkingDirectory={sh_quote(workdir)} /bin/bash -lc {sh_quote(launch_body)} >/dev/null 2>&1; then
    printf '%s' 'systemd'
    exit 0
  fi
fi
nohup /bin/bash -lc {sh_quote(launch_body)} > {sh_quote(log_file)} 2>&1 < /dev/null &
echo $! > {sh_quote(f"{remote_base}/logs/{manifest.slug}.pid")}
printf '%s' 'nohup'
"""
    if progress:
        progress("Launching remote service")
    completed = run_ssh(
        ssh_target,
        remote_script,
        "Failed to start the cookbook service.",
        capture_output=True,
        identity_file=identity_file,
    )
    return unit_name, (completed.stdout.strip() or "nohup")


def wait_for_internal_health(
    *,
    ssh_target: str,
    port: int,
    health_path: str,
    timeout_seconds: int,
    identity_file: Optional[str] = None,
) -> None:
    url = f"http://127.0.0.1:{port}{health_path}"
    attempts = max(timeout_seconds // 2, 1)
    remote_script = f"""
set -e
URL={sh_quote(url)}
for _ in $(seq 1 {attempts}); do
  if command -v curl >/dev/null 2>&1; then
    curl -fsS "$URL" >/dev/null && exit 0
  elif command -v wget >/dev/null 2>&1; then
    wget -q -O /dev/null "$URL" && exit 0
  elif command -v python3 >/dev/null 2>&1; then
    python3 - <<'PY' && exit 0
import sys
from urllib.request import urlopen

with urlopen({url!r}, timeout=3) as response:
    if response.status >= 400:
        raise SystemExit(1)
PY
  fi
  sleep 2
done
exit 1
"""
    try:
        run_ssh(
            ssh_target,
            remote_script,
            "Timed out waiting for the app healthcheck.",
            identity_file=identity_file,
        )
    except CookbookError as exc:
        raise CookbookError(
            f"{exc} Use `instavm connect {ssh_target.split('@', 1)[0]}` to inspect the VM."
        ) from exc


def verify_public_share(url: str, *, timeout_seconds: int) -> None:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            request = urllib_request.Request(url, method="GET")
            with urllib_request.urlopen(request, timeout=5) as response:
                if 200 <= response.status < 400:
                    return
        except (urllib_error.URLError, urllib_error.HTTPError):
            time.sleep(2)
    raise CookbookError(f"Timed out verifying the public share URL: {url}")


def run_ssh(
    ssh_target: str,
    remote_command: str,
    error_message: str,
    *,
    capture_output: bool = False,
    identity_file: Optional[str] = None,
) -> subprocess.CompletedProcess[str]:
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "StrictHostKeyChecking=accept-new",
    ]
    if identity_file:
        command.extend(["-o", "IdentitiesOnly=yes", "-i", identity_file])
    command.extend([ssh_target, remote_command])
    return _run_command(
        command,
        error_message=error_message,
        capture_output=capture_output,
    )


def run_scp(local_path: str, remote_path: str, error_message: str, *, identity_file: Optional[str] = None) -> None:
    # Force legacy SCP mode because the gateway path does not behave correctly
    # with OpenSSH's default SFTP-based SCP transport.
    command = ["scp", "-O", "-q"]
    if identity_file:
        command.extend(["-o", "IdentitiesOnly=yes", "-i", identity_file])
    command.extend([local_path, remote_path])
    _run_command(command, error_message=error_message)


def wait_for_ssh_ready(
    ssh_target: str,
    *,
    timeout_seconds: int = 90,
    identity_file: Optional[str] = None,
) -> None:
    deadline = time.time() + timeout_seconds
    last_error: Optional[str] = None
    while time.time() < deadline:
        try:
            run_ssh(
                ssh_target,
                "true",
                "Timed out waiting for SSH access to the VM.",
                capture_output=True,
                identity_file=identity_file,
            )
            return
        except CookbookError as exc:
            last_error = str(exc)
            time.sleep(2)
    if last_error:
        raise CookbookError(f"Timed out waiting for SSH access to the VM: {ssh_target}. Last SSH error: {last_error}")
    raise CookbookError(f"Timed out waiting for SSH access to the VM: {ssh_target}")


def _logs_command(
    vm_id: str,
    ssh_host: str,
    slug: str,
    service_name: str,
    service_mode: str,
    remote_base: str,
    logs_hint: Optional[str],
    identity_file: Optional[str] = None,
) -> str:
    if logs_hint:
        return logs_hint
    ssh_prefix = _ssh_prefix(vm_id, ssh_host, identity_file)
    if service_mode == "systemd":
        return f"{ssh_prefix} journalctl --no-pager -u {service_name} -n 200"
    return f"{ssh_prefix} tail -n 200 {sh_quote(f'{remote_base}/logs/{slug}.log')}"


def _remote_workdir(manifest: CookbookManifest, remote_root: str) -> str:
    if manifest.run.workdir.startswith("/"):
        return manifest.run.workdir
    if manifest.run.workdir in {".", "./"}:
        return remote_root
    return f"{remote_root}/{manifest.run.workdir.strip('./')}"


def _resolve_remote_base(*, ssh_target: str, identity_file: Optional[str]) -> str:
    completed = run_ssh(
        ssh_target,
        'printf %s "$HOME"',
        "Failed to determine the remote home directory.",
        capture_output=True,
        identity_file=identity_file,
    )
    remote_home = completed.stdout.strip() or "/tmp"
    return f"{remote_home}/{DEFAULT_REMOTE_ROOT}"


def _resolve_identity_file(selected_path: Optional[str]) -> Optional[str]:
    if not selected_path:
        return None
    candidate = Path(selected_path)
    if candidate.suffix == ".pub":
        candidate = candidate.with_suffix("")
    return candidate.as_posix() if candidate.exists() else None


def _ssh_prefix(vm_id: str, ssh_host: str, identity_file: Optional[str]) -> str:
    if identity_file:
        return f"ssh -o IdentitiesOnly=yes -i {sh_quote(identity_file)} {vm_id}@{ssh_host}"
    return f"ssh {vm_id}@{ssh_host}"


def _connect_command(vm_id: str, ssh_host: str, identity_file: Optional[str]) -> str:
    if identity_file:
        return f"{_ssh_prefix(vm_id, ssh_host, identity_file)}"
    return f"instavm connect {vm_id}"


def _run_command(
    command: Sequence[str],
    *,
    error_message: str,
    capture_output: bool = False,
) -> subprocess.CompletedProcess[str]:
    kwargs: dict[str, Any] = {"text": True}
    if capture_output:
        kwargs["capture_output"] = True
    try:
        return subprocess.run(command, check=True, **kwargs)
    except subprocess.CalledProcessError as exc:
        detail = exc.stderr.strip() if isinstance(exc.stderr, str) and exc.stderr.strip() else ""
        suffix = f" {detail}" if detail else ""
        raise CookbookError(f"{error_message}{suffix}") from exc
    except OSError as exc:
        raise CookbookError(error_message) from exc


def sh_quote(value: str) -> str:
    return shlex.quote(value)
