from __future__ import annotations

import argparse
import base64
import binascii
import getpass
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

from ._cli_config import (
    DEFAULT_BILLING_URL,
    DEFAULT_DOCS_URL,
    ConfigError,
    get_config_dir,
    get_active_profile,
    redact_secret,
    resolve_runtime_config,
    update_profile_settings,
)
from ._cookbook import (
    CookbookDeployError,
    CookbookError,
    _run_deploy,
    deploy_cookbook,
    discover_cookbooks,
    load_manifest,
    manifest_display_record,
    resolve_cookbook_root,
)
from .exceptions import AuthenticationError, InstaVMError
from .sandbox_client import InstaVM

ACTIVE_VM_STATUSES = frozenset({"active", "running", "creating"})
INTERACTIVE_PROGRESS_PREFIXES = (
    "Resolving public snapshot ",
    "Reusing saved snapshot ",
    "Retrying VM creation ",
)
INTERACTIVE_PROGRESS_STEPS = frozenset({
    "Creating VM",
    "Waiting for SSH access",
    "Uploading cookbook source",
    "Uploading source",
    "Running cookbook setup",
    "Running setup",
    "Starting application service",
    "Starting service",
    "Waiting for application healthcheck",
    "Waiting for healthcheck",
    "Creating public share",
    "Verifying public share URL",
    "Detecting project",
    "Creating snapshot",
})


def _print_json(payload: Any) -> None:
    sys.stdout.write(json.dumps(payload) + "\n")


def _print_lines(*lines: str) -> None:
    for line in lines:
        sys.stdout.write(line + "\n")


def _print_error_lines(*lines: str) -> None:
    for line in lines:
        sys.stderr.write(line + "\n")


def _supports_ansi(stream: Any) -> bool:
    is_tty = getattr(stream, "isatty", lambda: False)
    return bool(is_tty()) and not os.environ.get("NO_COLOR") and os.environ.get("TERM") != "dumb"


def _style_text(text: str, *codes: str, enabled: bool) -> str:
    if not enabled or not codes:
        return text
    return f"\033[{';'.join(codes)}m{text}\033[0m"


def _status_badge(status: Any, *, enabled: bool) -> str:
    label = _display_value(status)
    normalized = label.lower()
    codes = ("31",)
    if normalized in ACTIVE_VM_STATUSES or normalized == "ready":
        codes = ("32",)
    elif normalized in {"building", "creating", "pending"}:
        codes = ("33",)
    return f"{_style_text('●', *codes, enabled=enabled)} {label}"


def _parse_watch_seconds(value: Optional[int]) -> Optional[int]:
    if value is None:
        return None
    if value <= 0:
        raise ValueError("--watch must be a positive integer")
    return value


def _emit_watch_payload(
    args: argparse.Namespace,
    payload_factory: Callable[[], tuple[Any, Sequence[str]]],
) -> int:
    watch_seconds = _parse_watch_seconds(getattr(args, "watch", None))
    clear_between_frames = not getattr(args, "json_output", False) and _supports_ansi(sys.stdout)
    first = True
    while True:
        payload, text_lines = payload_factory()
        if not first and clear_between_frames:
            sys.stdout.write("\033c")
            sys.stdout.flush()
        _emit_payload(args, payload, text_lines)
        if watch_seconds is None:
            return 0
        first = False
        time.sleep(watch_seconds)


def _run_with_spinner(
    args: argparse.Namespace,
    message: str,
    callback: Callable[[], Any],
) -> Any:
    display = _ProgressDisplay(args)
    try:
        display.step(message)
        return callback()
    finally:
        display.stop()


def _filter_active_vms(vms: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        vm for vm in vms
        if str(vm.get("status") or "").lower() in ACTIVE_VM_STATUSES
    ]


def _normalize_argv(argv: Optional[Sequence[str]]) -> Optional[list[str]]:
    if argv is None:
        return None
    return ["--all" if token == "-all" else token for token in argv]


def _deploy_cache_dir() -> Path:
    cache_dir = get_config_dir() / "deploys"
    cache_dir.mkdir(parents=True, exist_ok=True)
    try:
        cache_dir.chmod(0o700)
    except OSError:
        pass
    return cache_dir


def _deploy_cache_path(project_path: Path) -> Path:
    digest = hashlib.sha256(str(project_path.resolve()).encode("utf-8")).hexdigest()
    return _deploy_cache_dir() / f"{digest}.json"


def _deploy_fingerprint(plan: Any) -> str:
    payload = {
        "slug": plan.slug,
        "runtime": plan.runtime,
        "package_manager": plan.package_manager,
        "install_command": plan.install_command,
        "build_command": plan.build_command,
        "start_command": plan.start_command,
        "port": plan.port,
        "health_path": plan.health_path,
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()


def _load_deploy_record(project_path: Path) -> Optional[dict[str, Any]]:
    cache_path = _deploy_cache_path(project_path)
    if not cache_path.exists():
        return None
    try:
        return json.loads(cache_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _save_deploy_record(project_path: Path, record: dict[str, Any]) -> None:
    cache_path = _deploy_cache_path(project_path)
    fd = os.open(str(cache_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
    try:
        cache_path.chmod(0o600)
    except OSError:
        pass


def _resolve_saved_snapshot(
    client: InstaVM,
    project_path: Path,
    plan: Any,
    *,
    progress: Optional[Callable[[str], None]] = None,
) -> Optional[str]:
    record = _load_deploy_record(project_path)
    if not record:
        return None
    snapshot_id = str(record.get("snapshot_id") or "").strip()
    if not snapshot_id or record.get("fingerprint") != _deploy_fingerprint(plan):
        return None
    try:
        snapshot = client.snapshots.get(snapshot_id)
    except Exception:
        return None
    status = str(snapshot.get("status") or "").lower()
    if status and status != "ready":
        return None
    if progress:
        progress(f"Reusing saved snapshot {snapshot_id}")
    return snapshot_id


def _create_deploy_snapshot(
    client: InstaVM,
    project_path: Path,
    plan: Any,
    payload: dict[str, Any],
    *,
    progress: Optional[Callable[[str], None]] = None,
) -> Optional[str]:
    vm_id = str(payload.get("vm_id") or "").strip()
    if not vm_id:
        return None
    if progress:
        progress("Creating snapshot")
    try:
        result = client.vms.snapshot(vm_id, wait=True, name=f"deploy/{plan.slug}")
    except Exception as exc:
        raise CookbookError(f"Failed to create deploy snapshot: {exc}") from exc
    snapshot_id = str(result.get("snapshot_id") or result.get("id") or "").strip()
    if not snapshot_id:
        return None
    record = {
        "slug": plan.slug,
        "project_path": str(project_path.resolve()),
        "snapshot_id": snapshot_id,
        "vm_id": vm_id,
        "share_url": payload.get("share_url"),
        "last_deployed": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "fingerprint": _deploy_fingerprint(plan),
        "plan": {
            "runtime": plan.runtime,
            "package_manager": plan.package_manager,
            "install_command": plan.install_command,
            "build_command": plan.build_command,
            "start_command": plan.start_command,
            "port": plan.port,
            "health_path": plan.health_path,
        },
    }
    _save_deploy_record(project_path, record)
    return snapshot_id


def _require_api_key(args: argparse.Namespace) -> tuple[InstaVM, Any]:
    settings = resolve_runtime_config(
        api_key=getattr(args, "api_key", None),
        base_url=getattr(args, "base_url", None),
        ssh_host=getattr(args, "ssh_host", None),
    )
    if not settings.api_key:
        raise AuthenticationError(
            "No InstaVM API key configured. Run `instavm auth set-key` or export INSTAVM_API_KEY."
        )
    return InstaVM(
        api_key=settings.api_key,
        base_url=settings.base_url,
        auto_start_session=False,
    ), settings


def _client_from_settings(args: argparse.Namespace, *, auto_start_session: bool = False) -> tuple[InstaVM, Any]:
    settings = _resolve_settings(args)
    if not settings.api_key:
        raise AuthenticationError(
            "No InstaVM API key configured. Run `instavm auth set-key` or export INSTAVM_API_KEY."
        )
    return InstaVM(
        api_key=settings.api_key,
        base_url=settings.base_url,
        auto_start_session=auto_start_session,
    ), settings


def _resolve_settings(args: argparse.Namespace):
    return resolve_runtime_config(
        api_key=getattr(args, "api_key", None),
        base_url=getattr(args, "base_url", None),
        ssh_host=getattr(args, "ssh_host", None),
    )


def _redacted_status_payload(args: argparse.Namespace) -> dict[str, Any]:
    settings = _resolve_settings(args)
    active_profile = get_active_profile(settings.config)
    auth = active_profile.get("auth") if isinstance(active_profile, dict) else {}
    stored_key = auth.get("api_key") if isinstance(auth, dict) else None
    return {
        "config_path": str(settings.config_path),
        "active_profile": settings.config.get("active_profile", "default"),
        "api_key": {
            "configured": bool(settings.api_key),
            "redacted": redact_secret(settings.api_key),
            "source": settings.api_key_source,
            "stored": bool(stored_key),
        },
        "base_url": {
            "value": settings.base_url,
            "source": settings.base_url_source,
        },
        "ssh_host": {
            "value": settings.ssh_host,
            "source": settings.ssh_host_source,
        },
    }


def _emit_payload(args: argparse.Namespace, payload: Any, text_lines: Sequence[str]) -> int:
    if getattr(args, "json_output", False):
        _print_json(payload)
    else:
        _print_lines(*text_lines)
    return 0


def _title_case_label(value: str) -> str:
    parts = [part for part in re.split(r"[-_\s]+", value) if part]
    return " ".join(part[:1].upper() + part[1:] for part in parts)


def _display_value(value: Any, default: str = "-") -> str:
    if value is None:
        return default
    text = str(value).strip()
    return text or default


def _format_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> list[str]:
    widths = [len(header) for header in headers]
    normalized_rows: list[list[str]] = []
    for row in rows:
        normalized = [_display_value(cell) for cell in row]
        normalized_rows.append(normalized)
        for index, cell in enumerate(normalized):
            widths[index] = max(widths[index], len(cell))

    header_line = "  " + "  ".join(header.ljust(widths[index]) for index, header in enumerate(headers))
    separator_line = "  " + "  ".join("-" * widths[index] for index in range(len(headers)))
    body_lines = [
        "  " + "  ".join(cell.ljust(widths[index]) for index, cell in enumerate(row))
        for row in normalized_rows
    ]
    return [header_line, separator_line, *body_lines]


def _format_cookbook_list(cookbooks: Sequence[dict[str, Any]]) -> list[str]:
    if not cookbooks:
        return ["No cookbooks found."]

    category_order = {"web": 0, "graphics": 1, "agents": 2}

    sorted_entries = sorted(
        cookbooks,
        key=lambda entry: (
            category_order.get(str(entry.get("category") or "other"), 99),
            str(entry.get("category") or "other"),
            0 if not entry.get("requires_secrets") else 1,
            str(entry.get("title") or entry.get("slug") or ""),
        ),
    )
    featured = [entry for entry in sorted_entries if not entry.get("requires_secrets")]
    title_width = min(20, max(len(str(entry.get("title", ""))) for entry in sorted_entries))
    slug_width = max(len(str(entry.get("slug", ""))) for entry in sorted_entries)

    def _catalog_line(entry: dict[str, Any]) -> str:
        title = str(entry.get("title", "")).ljust(title_width)
        slug = str(entry.get("slug", "")).ljust(slug_width)
        secret_state = "key" if entry.get("requires_secrets") else "no key"
        return f"  {title}  {slug}  :{entry.get('port')}  {secret_state}"

    lines = [f"Cookbooks ({len(sorted_entries)})"]

    if featured:
        lines.extend(["", "Try first"])
        lines.extend(_catalog_line(entry) for entry in featured)

    current_category: Optional[str] = None
    for entry in sorted_entries:
        if entry in featured:
            continue
        category = str(entry.get("category") or "other")
        if category != current_category:
            lines.extend(["", _title_case_label(category)])
            current_category = category
        lines.append(_catalog_line(entry))

    lines.extend([
        "",
        "Use `instavm cookbook info <slug>` for details.",
        "Use `instavm cookbook deploy <slug>` to launch one.",
    ])
    return lines


def _format_whoami_text(payload: dict[str, Any]) -> list[str]:
    ssh_keys = payload.get("ssh_keys") or []
    lines = [
        "Account",
        f"  Email: {_display_value(payload.get('email'))}",
        f"  User ID: {_display_value(payload.get('id'))}",
        f"  Name: {_display_value(payload.get('name'))}",
        f"  Verified: {'yes' if payload.get('is_verified') else 'no'}",
        "",
        f"SSH Keys ({len(ssh_keys)})",
    ]
    if ssh_keys:
        rows = [
            [
                _display_value(key.get("id")),
                _display_value(key.get("fingerprint")),
                _display_value(key.get("comment")),
            ]
            for key in ssh_keys
        ]
        lines.extend(_format_table(["ID", "Fingerprint", "Comment"], rows))
    else:
        lines.append("  none")
    return lines


def _format_vm_list(vms: Sequence[dict[str, Any]], *, include_all: bool) -> list[str]:
    heading = f"VMs ({len(vms)})" if include_all else f"Active VMs ({len(vms)})"
    lines = [heading]
    if not include_all:
        lines.append("Use `instavm ls --all` to include terminated VMs.")
    lines.append("")
    color_enabled = _supports_ansi(sys.stdout)
    rows = [
        [
            _display_value(vm.get("vm_id")),
            _status_badge(vm.get("status"), enabled=color_enabled),
            _display_value(vm.get("created_at")),
            _display_value(vm.get("ssh_host")),
        ]
        for vm in vms
    ]
    lines.extend(_format_table(["ID", "Status", "Created", "SSH"], rows))
    return lines


def _format_snapshot_list(snapshots: Sequence[dict[str, Any]]) -> list[str]:
    rows = [
        [
            _display_value(snap.get("id")),
            _display_value(snap.get("name")),
            _display_value(snap.get("status")),
            _display_value(snap.get("type")),
        ]
        for snap in snapshots
    ]
    return [f"Snapshots ({len(snapshots)})", "", *_format_table(["ID", "Name", "Status", "Type"], rows)]


def _format_ssh_key_list(keys: Sequence[dict[str, Any]]) -> list[str]:
    rows = [
        [
            _display_value(key.get("id")),
            _display_value(key.get("fingerprint")),
            _display_value(key.get("comment")),
        ]
        for key in keys
    ]
    return [f"SSH Keys ({len(keys)})", "", *_format_table(["ID", "Fingerprint", "Comment"], rows)]


def _format_volume_list(volumes: Sequence[dict[str, Any]]) -> list[str]:
    rows = [
        [
            _display_value(volume.get("id")),
            _display_value(volume.get("name")),
            f"{_human_bytes(volume.get('used_bytes'))} / {_human_bytes(volume.get('quota_bytes'))}",
            _display_value(volume.get("status")),
        ]
        for volume in volumes
    ]
    return [f"Volumes ({len(volumes)})", "", *_format_table(["ID", "Name", "Usage", "Status"], rows)]


def _format_checkpoint_list(checkpoints: Sequence[dict[str, Any]]) -> list[str]:
    rows = [
        [
            _display_value(checkpoint.get("id")),
            _display_value(checkpoint.get("name")),
            _display_value(checkpoint.get("status")),
        ]
        for checkpoint in checkpoints
    ]
    return [f"Checkpoints ({len(checkpoints)})", "", *_format_table(["ID", "Name", "Status"], rows)]


def _format_file_list(files: Sequence[dict[str, Any]]) -> list[str]:
    rows = [
        [
            _display_value(entry.get("path")),
            _human_bytes(entry.get("size")),
        ]
        for entry in files
    ]
    return [f"Files ({len(files)})", "", *_format_table(["Path", "Size"], rows)]


def _normalize_egress_payload(payload: dict[str, Any], *, target_type: str, target_id: str) -> dict[str, Any]:
    normalized = {
        "target_type": target_type,
        "target_id": target_id,
        "allow_package_managers": payload.get("allow_package_managers", payload.get("allow_public_repos", True)),
        "allow_http": payload.get("allow_http", True),
        "allow_https": payload.get("allow_https", True),
        "allowed_domains": list(payload.get("allowed_domains") or []),
        "allowed_cidrs": list(payload.get("allowed_cidrs") or []),
    }
    if payload.get("status") is not None:
        normalized["status"] = payload.get("status")
    return normalized


def _format_egress_text(payload: dict[str, Any]) -> list[str]:
    lines = [f"Target: {payload['target_type']} {payload['target_id']}"]
    if payload.get("status"):
        lines.append(f"Status: {payload['status']}")
    lines.extend([
        f"Package managers: {'allowed' if payload.get('allow_package_managers') else 'blocked'}",
        f"HTTP: {'allowed' if payload.get('allow_http') else 'blocked'}",
        f"HTTPS: {'allowed' if payload.get('allow_https') else 'blocked'}",
        f"Domains: {', '.join(payload.get('allowed_domains') or []) or 'none'}",
        f"CIDRs: {', '.join(payload.get('allowed_cidrs') or []) or 'none'}",
    ])
    return lines


def _append_output_block(lines: list[str], label: str, value: Any) -> bool:
    if value is None:
        return False
    text = str(value)
    if not text:
        return False
    lines.extend(["", label, *text.rstrip("\n").splitlines()])
    return True


def _format_exec_text(payload: dict[str, Any]) -> list[str]:
    lines: list[str] = []
    if payload.get("task_id"):
        lines.append(f"Task: {payload['task_id']}")
    if payload.get("session_id"):
        lines.append(f"Session: {payload['session_id']}")
    if payload.get("language"):
        lines.append(f"Language: {payload['language']}")
    if payload.get("created_at"):
        lines.append(f"Created: {payload['created_at']}")
    if payload.get("execution_time") is not None:
        lines.append(f"Execution time: {payload['execution_time']}")
    if payload.get("cpu_time") is not None:
        lines.append(f"CPU time: {payload['cpu_time']}")

    has_output = False
    has_output = _append_output_block(lines, "Stdout", payload.get("stdout") or payload.get("output")) or has_output
    has_output = _append_output_block(lines, "Stderr", payload.get("stderr")) or has_output
    if not has_output:
        lines.append("No output.")
    return lines


def _format_browser_read_text(payload: dict[str, Any]) -> list[str]:
    readable = payload.get("readable_content") or {}
    navigation = payload.get("navigation") or {}
    title = readable.get("title") or navigation.get("title") or "-"
    url = readable.get("url") or navigation.get("url") or payload.get("url") or "-"
    content = str(readable.get("content") or "").strip()
    lines = [
        f"Session: {payload.get('session_id') or '-'}",
        f"URL: {url}",
        f"Title: {title}",
        f"Interactive elements: {len(payload.get('interactive_elements') or [])}",
        f"Anchors: {len(payload.get('content_anchors') or [])}",
        "",
    ]
    if content:
        lines.extend(content.splitlines())
    else:
        lines.append("No readable content.")
    return lines


class _ProgressDisplay:
    def __init__(self, args: argparse.Namespace):
        self._json_output = getattr(args, "json_output", False)
        self._enabled = not self._json_output and _supports_ansi(sys.stderr)
        self._message: Optional[str] = None
        self._started_at: Optional[float] = None
        self._frame = 0
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        if self._enabled:
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

    def step(self, message: str) -> None:
        if self._json_output:
            return
        if not self._enabled:
            _print_error_lines(f"{message}...")
            return
        with self._lock:
            if message != self._message:
                self._started_at = time.monotonic()
                self._frame = 0
            self._message = message

    def note(self, message: str) -> None:
        if self._json_output:
            return
        if not self._enabled:
            _print_error_lines(message)
            return
        with self._lock:
            self._message = None
            self._started_at = None
        sys.stderr.write("\r\033[2K")
        sys.stderr.write(message + "\n")
        sys.stderr.flush()

    def stop(self) -> None:
        if not self._enabled:
            return
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=0.5)
        sys.stderr.write("\r\033[2K")
        sys.stderr.flush()

    def _run(self) -> None:
        suffixes = ("", ".", "..", "...")
        while not self._stop_event.is_set():
            with self._lock:
                message = self._message
                started_at = self._started_at
                frame = self._frame
            if message:
                elapsed = int(time.monotonic() - started_at) if started_at is not None else 0
                sys.stderr.write(
                    f"\r\033[2K{message}{suffixes[frame % len(suffixes)]} {elapsed}s"
                )
                sys.stderr.flush()
                with self._lock:
                    self._frame += 1
                time.sleep(0.2)
            else:
                time.sleep(0.05)


def _should_spin(message: str) -> bool:
    return message in INTERACTIVE_PROGRESS_STEPS or any(
        message.startswith(prefix) for prefix in INTERACTIVE_PROGRESS_PREFIXES
    )


def _progress(display: _ProgressDisplay, message: str) -> None:
    if _should_spin(message):
        display.step(message)
    else:
        display.note(message)


def _format_cookbook_deploy_success(args: argparse.Namespace, payload: dict[str, Any]) -> list[str]:
    color_enabled = _supports_ansi(sys.stdout) and not getattr(args, "json_output", False)
    vm_id = str(payload.get("vm_id") or "")
    slug = str(payload.get("slug") or "")
    display_url = str(payload.get("share_url") or "").rstrip("/")
    connect_hint = f"instavm connect {vm_id}" if vm_id else "-"
    logs_hint = f"After connecting: tail -n 200 ~/.instavm-cookbooks/logs/{slug}.log" if slug else "-"
    lines = [
        _style_text("Cookbook ready", "1", "32", enabled=color_enabled),
        "",
        f"  Cookbook  {slug}",
        f"  VM        {vm_id}",
        f"  URL       {_style_text(display_url, '32', '4', enabled=color_enabled)}",
        f"  Connect   {connect_hint}",
        f"  Logs      {logs_hint}",
        f"  Destroy   {payload['destroy_command']}",
    ]
    if payload.get("notes"):
        lines.append("")
        lines.append("  Notes")
        lines.extend(f"    - {note}" for note in payload["notes"])
    return lines


def _format_cookbook_deploy_failure(args: argparse.Namespace, message: str, payload: dict[str, Any]) -> list[str]:
    color_enabled = _supports_ansi(sys.stderr) and not getattr(args, "json_output", False)
    vm_id = str(payload.get("vm_id") or "")
    slug = str(payload.get("slug") or "")
    connect_hint = f"instavm connect {vm_id}" if vm_id else "-"
    logs_hint = f"After connecting: tail -n 200 ~/.instavm-cookbooks/logs/{slug}.log" if vm_id and slug else "-"
    return [
        _style_text("Deploy failed", "1", "31", enabled=color_enabled),
        f"  Error     {message}",
        f"  VM        {vm_id or '-'}",
        f"  Connect   {connect_hint}",
        f"  Logs      {logs_hint}",
        f"  Destroy   {payload.get('destroy_command') or '-'}",
    ]


def _parse_size(value: str) -> int:
    raw = (value or "").strip().lower()
    if not raw:
        raise ValueError("size is required")
    units = (
        ("tb", 1024**4),
        ("gb", 1024**3),
        ("mb", 1024**2),
        ("kb", 1024),
        ("b", 1),
    )
    for suffix, multiplier in units:
        if raw.endswith(suffix) and raw != suffix:
            number = raw[: -len(suffix)].strip()
            return int(float(number) * multiplier)
    return int(raw)


def _human_bytes(value: Optional[int]) -> str:
    amount = float(value or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if amount < 1024 or unit == "TB":
            if unit == "B":
                return f"{int(amount)}{unit}"
            return f"{amount:.1f}{unit}"
        amount /= 1024
    return f"{int(value or 0)}B"


def _looks_like_uuid(value: str) -> bool:
    try:
        uuid.UUID(str(value))
        return True
    except (TypeError, ValueError, AttributeError):
        return False


def _parse_env_pairs(values: Optional[list[str]]) -> dict[str, str]:
    result: dict[str, str] = {}
    for entry in values or []:
        if "=" not in entry:
            raise ValueError(f"Expected KEY=VALUE, got: {entry}")
        key, value = entry.split("=", 1)
        key = key.strip()
        if not key:
            raise ValueError(f"Invalid env key: {entry}")
        result[key] = value
    return result


def _parse_volume_spec(spec: str) -> dict[str, Any]:
    parts = spec.split(":")
    if len(parts) < 2:
        raise ValueError("volume mounts must use <volume_id>:<mount_path>[:rw|ro[:checkpoint_id]]")
    volume_id = parts[0].strip()
    mount_path = parts[1].strip()
    mode = "rw"
    checkpoint_id = None
    if len(parts) >= 3 and parts[2].strip():
        mode = parts[2].strip().lower()
    if len(parts) >= 4 and parts[3].strip():
        checkpoint_id = parts[3].strip()
    if len(parts) > 4:
        raise ValueError("volume mounts must use <volume_id>:<mount_path>[:rw|ro[:checkpoint_id]]")
    if mode not in {"rw", "ro"}:
        raise ValueError("volume mount mode must be rw or ro")
    if mode == "rw" and checkpoint_id is not None:
        raise ValueError("checkpoint_id is only allowed for ro mounts")
    if mode == "ro" and checkpoint_id is None:
        checkpoint_id = "latest"
    return {
        "volume_id": volume_id,
        "mount_path": mount_path,
        "mode": mode,
        "checkpoint_id": checkpoint_id,
    }


def _require_target(args: argparse.Namespace) -> tuple[str, str]:
    if bool(getattr(args, "session_id", None)) == bool(getattr(args, "vm_id", None)):
        raise ValueError("Provide exactly one of --session or --vm.")
    if getattr(args, "session_id", None):
        return "session", str(args.session_id)
    return "vm", str(args.vm_id)


def _infer_exec_language(path: Path) -> Optional[str]:
    return {
        ".py": "python",
        ".sh": "bash",
        ".bash": "bash",
    }.get(path.suffix.lower())


def _resolve_exec_source(args: argparse.Namespace) -> tuple[str, Optional[str]]:
    if args.target == "result":
        raise ValueError("Use `instavm exec result <task_id>` without --cmd or a file path.")
    if args.cmd and args.target:
        raise ValueError("Provide either a local file path or --cmd, not both.")
    if args.cmd:
        return args.cmd, args.language
    if not args.target:
        raise ValueError("Provide a local file path or --cmd.")
    source_path = Path(args.target)
    if not source_path.is_file():
        raise FileNotFoundError(f"Local file not found: {source_path}")
    return source_path.read_text(encoding="utf-8"), (args.language or _infer_exec_language(source_path))


def _prepare_browser_session(
    client: InstaVM,
    *,
    session_id: Optional[str],
    url: Optional[str],
) -> tuple[str, bool, Optional[dict[str, Any]]]:
    target_session_id = session_id
    created_temp_session = False
    navigation: Optional[dict[str, Any]] = None

    if not target_session_id:
        if not url:
            raise ValueError("Provide a URL or --session.")
        target_session_id = client.create_browser_session()
        created_temp_session = True

    if url:
        navigation = client.browser_navigate(url, target_session_id)

    return target_session_id, created_temp_session, navigation


def _write_screenshot(path_value: str, screenshot_b64: str) -> int:
    try:
        image_bytes = base64.b64decode(screenshot_b64)
    except (ValueError, binascii.Error) as exc:
        raise ValueError("Browser screenshot was not valid base64 data.") from exc
    output_path = Path(path_value)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(image_bytes)
    return len(image_bytes)


def _find_subparser(parser: argparse.ArgumentParser, path: Sequence[str]) -> Optional[argparse.ArgumentParser]:
    current = parser
    for token in path:
        subparsers_action = next(
            (action for action in current._actions if isinstance(action, argparse._SubParsersAction)),
            None,
        )
        if subparsers_action is None:
            return None
        current = subparsers_action.choices.get(token)
        if current is None:
            return None
    return current


def _add_runtime_options(parser: argparse.ArgumentParser, *, include_json: bool = True, include_ssh_host: bool = False) -> None:
    parser.add_argument("--api-key", help="Override the InstaVM API key for this command")
    parser.add_argument("--base-url", help="Override the InstaVM API base URL for this command")
    if include_ssh_host:
        parser.add_argument("--ssh-host", help="Override the SSH gateway host for this command")
    if include_json:
        parser.add_argument("-j", "--json", dest="json_output", action="store_true", help="Emit JSON output")


def _status_text(payload: dict[str, Any]) -> list[str]:
    lines = [
        f"Config path: {payload['config_path']}",
        f"Active profile: {payload['active_profile']}",
        f"API key: {payload['api_key']['redacted'] or 'not configured'} ({payload['api_key']['source']})",
        f"Base URL: {payload['base_url']['value']} ({payload['base_url']['source']})",
        f"SSH host: {payload['ssh_host']['value']} ({payload['ssh_host']['source']})",
    ]
    if payload["api_key"]["stored"]:
        lines.append("Stored key: present")
    return lines


def handle_help(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    if not args.command_path:
        parser.print_help()
        return 0
    target_parser = _find_subparser(parser, args.command_path)
    if target_parser is None:
        raise ValueError(f"Unknown help topic: {' '.join(args.command_path)}")
    target_parser.print_help()
    return 0


def handle_auth_set_key(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    if sys.stdin.isatty():
        api_key = getpass.getpass("InstaVM API key: ").strip()
    else:
        api_key = sys.stdin.read().strip()
    if not api_key:
        raise ValueError("API key is required. Enter it at the prompt or pipe it over stdin.")

    config_path = update_profile_settings(
        api_key=api_key,
        base_url=args.base_url,
        ssh_host=args.ssh_host,
    )
    payload = {
        "status": "stored",
        "config_path": str(config_path),
        "api_key": redact_secret(api_key),
        "base_url": args.base_url,
        "ssh_host": args.ssh_host,
    }
    text_lines = [
        f"Stored API key in {config_path}",
        f"API key: {payload['api_key']}",
    ]
    if args.base_url:
        text_lines.append(f"Default base URL: {args.base_url}")
    if args.ssh_host:
        text_lines.append(f"Default SSH host: {args.ssh_host}")
    return _emit_payload(args, payload, text_lines)


def handle_auth_status(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    payload = _redacted_status_payload(args)
    return _emit_payload(args, payload, _status_text(payload))


def handle_auth_logout(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    settings = _resolve_settings(args)
    config_path = update_profile_settings(clear_api_key=True)
    payload = {
        "status": "logged_out",
        "config_path": str(config_path),
        "env_key_active": settings.api_key_source == "env",
    }
    text_lines = [f"Removed the stored API key from {config_path}"]
    if payload["env_key_active"]:
        text_lines.append("INSTAVM_API_KEY is still set in the environment and will remain active.")
    return _emit_payload(args, payload, text_lines)


def handle_whoami(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    user = client.get_current_user()
    ssh_keys = client.list_ssh_keys()
    payload = {
        "id": user.get("id"),
        "email": user.get("email"),
        "name": user.get("name"),
        "is_verified": user.get("is_verified"),
        "ssh_keys": ssh_keys,
    }
    return _emit_payload(args, payload, _format_whoami_text(payload))


def handle_create(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, settings = _require_api_key(args)
    payload: dict[str, Any] = {}
    if args.vm_type == "computer-use":
        payload["image_variant"] = "computer-use"
    if args.timeout is not None:
        payload["vm_lifetime_seconds"] = args.timeout
    if args.memory is not None:
        payload["memory_mb"] = args.memory
    if args.vcpu is not None:
        payload["vcpu_count"] = args.vcpu
    if args.snapshot:
        payload["snapshot_id"] = args.snapshot
    if args.session:
        payload["session_id"] = args.session
    if args.volume:
        payload["volumes"] = [_parse_volume_spec(spec) for spec in args.volume]
    result = client.vms.create(wait=True, **payload)
    text_lines = [
        f"VM: {result.get('vm_id') or '-'}",
        f"Session: {result.get('session_id') or '-'}",
        f"Status: {result.get('status') or '-'}",
    ]
    if result.get("vm_id"):
        text_lines.append(f"SSH: ssh {result['vm_id']}@{settings.ssh_host}")
    return _emit_payload(args, result, text_lines)


def handle_ls(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    def payload_factory() -> tuple[Any, Sequence[str]]:
        listed_vms = client.vms.list_all_records() if args.all else client.vms.list()
        vms = listed_vms if args.all else _filter_active_vms(listed_vms)
        payload = {"vms": vms}
        if not vms:
            message = "No VMs." if args.all else "No active VMs. Use `instavm ls -a` or `instavm ls --all` to include terminated VMs."
            return payload, [message]
        return payload, _format_vm_list(vms, include_all=args.all)

    return _emit_watch_payload(args, payload_factory)


def handle_rm(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    results = []
    for vm_id in args.vm_ids:
        response = client.vms.delete(vm_id)
        results.append({"vm_id": vm_id, **response})
    payload = {"results": results}
    text_lines = [f"{item['vm_id']}: {item.get('status', 'ok')}" for item in results]
    return _emit_payload(args, payload, text_lines)


def handle_clone(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, settings = _require_api_key(args)
    result = client.vms.clone(args.vm_id, wait=True, snapshot_name=args.name)
    text_lines = [
        f"VM: {result.get('vm_id') or '-'}",
        f"Session: {result.get('session_id') or '-'}",
        f"Status: {result.get('status') or '-'}",
    ]
    if result.get("vm_id"):
        text_lines.append(f"SSH: ssh {result['vm_id']}@{settings.ssh_host}")
    return _emit_payload(args, result, text_lines)


def handle_connect(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    settings = _resolve_settings(args)
    ssh_binary = shutil.which("ssh.exe") or shutil.which("ssh")
    if not ssh_binary:
        raise FileNotFoundError("ssh client not found on PATH")
    ssh_args = list(args.ssh_args)
    if ssh_args and ssh_args[0] == "--":
        ssh_args = ssh_args[1:]
    command = [ssh_binary, f"{args.vm_id}@{settings.ssh_host}", *ssh_args]
    if args.json_output:
        _print_json({"command": command})
        return 0
    return subprocess.run(command, check=False).returncode


def handle_snapshot_ls(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    snapshots = client.snapshots.list(snapshot_type=args.snapshot_type)
    payload = {"snapshots": snapshots}
    if not snapshots:
        return _emit_payload(args, payload, ["No snapshots."])
    return _emit_payload(args, payload, _format_snapshot_list(snapshots))


def handle_snapshot_create(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.vms.snapshot(args.vm_id, wait=True, name=args.name)
    text_lines = [
        f"Snapshot: {result.get('snapshot_id') or result.get('id') or '-'}",
        f"Status: {result.get('status') or '-'}",
    ]
    return _emit_payload(args, result, text_lines)


def handle_snapshot_build(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    build_args: dict[str, Any] = {}
    if args.apt:
        build_args["extra_apt_packages"] = args.apt
    if args.pip:
        build_args["extra_pip_packages"] = args.pip
    if args.npm:
        build_args["extra_npm_packages"] = args.npm
    if args.git_clone:
        build_args["git_clone_url"] = args.git_clone
    if args.git_branch:
        build_args["git_clone_branch"] = args.git_branch
    if args.disk_size:
        build_args["disk_size_gb"] = args.disk_size
    if args.run:
        build_args["post_build_cmd"] = args.run
    if args.env:
        build_args["envs"] = _parse_env_pairs(args.env)
    result = _run_with_spinner(
        args,
        "Building snapshot",
        lambda: client.snapshots.create(
            oci_image=args.oci_image,
            name=args.name,
            vcpu_count=args.vcpu,
            memory_mb=args.memory,
            build_args=build_args or None,
            snapshot_type=args.snapshot_type,
        ),
    )
    text_lines = [
        f"Snapshot: {result.get('id') or '-'}",
        f"Name: {result.get('name') or '-'}",
        f"Status: {result.get('status') or '-'}",
    ]
    return _emit_payload(args, result, text_lines)


def handle_snapshot_get(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    def payload_factory() -> tuple[Any, Sequence[str]]:
        result = client.snapshots.get(args.snapshot_id)
        text_lines = [
            f"Snapshot: {result.get('id') or '-'}",
            f"Name: {result.get('name') or '-'}",
            f"Status: {result.get('status') or '-'}",
            f"Type: {result.get('type') or '-'}",
        ]
        return result, text_lines

    return _emit_watch_payload(args, payload_factory)


def handle_snapshot_rm(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.snapshots.delete(args.snapshot_id)
    payload = {"snapshot_id": args.snapshot_id, **result}
    text_lines = [f"Deleted snapshot {args.snapshot_id}"]
    return _emit_payload(args, payload, text_lines)


def handle_share_create(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.shares.create(port=args.port, vm_id=args.vm_id, is_public=args.public)
    text_lines = [
        f"Share: {result.get('share_id')}",
        f"URL: {result.get('url')}",
        f"Port: {result.get('port')}",
        f"Visibility: {'public' if result.get('is_public') else 'private'}",
    ]
    return _emit_payload(args, result, text_lines)


def handle_share_update(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    is_public = args.visibility == "public"
    revoke = args.visibility == "revoke"
    result = client.shares.update(args.share_id, is_public=None if revoke else is_public, revoke=revoke or None)
    payload = {"share_id": args.share_id, **result}
    if revoke:
        text_lines = [f"Revoked share {args.share_id}"]
    else:
        text_lines = [f"Updated share {args.share_id} to {'public' if is_public else 'private'}"]
    return _emit_payload(args, payload, text_lines)


def handle_egress_get(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    target_type, target_id = _require_target(args)
    if target_type == "session":
        result = client.get_session_egress(target_id)
    else:
        result = client.get_vm_egress(target_id)
    payload = _normalize_egress_payload(result, target_type=target_type, target_id=target_id)
    return _emit_payload(args, payload, _format_egress_text(payload))


def handle_egress_set(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    target_type, target_id = _require_target(args)
    kwargs = {
        "allow_package_managers": args.allow_package_managers,
        "allow_http": args.allow_http,
        "allow_https": args.allow_https,
        "allowed_domains": args.allowed_domains,
        "allowed_cidrs": args.allowed_cidrs,
    }
    if target_type == "session":
        result = client.set_session_egress(target_id, **kwargs)
    else:
        result = client.set_vm_egress(target_id, **kwargs)
    payload = _normalize_egress_payload(result, target_type=target_type, target_id=target_id)
    return _emit_payload(args, payload, _format_egress_text(payload))


def handle_ssh_key_list(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    keys = client.list_ssh_keys()
    payload = {"keys": keys}
    if not keys:
        return _emit_payload(args, payload, ["No SSH keys."])
    return _emit_payload(args, payload, _format_ssh_key_list(keys))


def handle_ssh_key_add(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    public_key = args.public_key
    if public_key is None:
        public_key = sys.stdin.read().strip()
    if not public_key:
        raise ValueError("Public key is required")
    result = client.add_ssh_key(public_key)
    text_lines = [f"Added {result.get('fingerprint') or result.get('id')}"]
    return _emit_payload(args, result, text_lines)


def handle_ssh_key_remove(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.delete_ssh_key(int(args.key_id))
    payload = {"key_id": int(args.key_id), **result}
    text_lines = [f"Removed {args.key_id}"]
    return _emit_payload(args, payload, text_lines)


def handle_exec(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    if args.target == "result":
        if args.cmd:
            raise ValueError("Use `instavm exec result <task_id>` without --cmd.")
        if not args.task_id:
            raise ValueError("Task ID is required: `instavm exec result <task_id>`.")
        client, _settings = _client_from_settings(args)
        result = client.get_task_result(
            args.task_id,
            poll_interval=args.poll_interval,
            timeout=args.timeout if args.timeout is not None else 60,
        )
        payload = {"task_id": args.task_id, **result}
        return _emit_payload(args, payload, _format_exec_text(payload))

    command, language = _resolve_exec_source(args)
    client, _settings = _client_from_settings(args)
    if args.session:
        client.session_id = args.session
    else:
        client.start_session()

    if args.async_exec:
        result = client.execute_async(command, language=language, timeout=args.timeout)
        payload = {
            "task_id": result.get("task_id"),
            "session_id": client.session_id,
            "language": language,
            **result,
        }
        text_lines = _format_exec_text(payload)
        text_lines.extend(["", "Use `instavm exec result <task_id>` to wait for completion."])
        return _emit_payload(args, payload, text_lines)

    result = client.execute(command, language=language, timeout=args.timeout)
    payload = {
        "session_id": client.session_id,
        "language": language,
        **result,
    }
    return _emit_payload(args, payload, _format_exec_text(payload))


def handle_browser_read(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    session_id, created_temp_session, navigation = _prepare_browser_session(
        client,
        session_id=args.session,
        url=args.url,
    )
    try:
        content = client.browser_extract_content(
            session_id=session_id,
            include_interactive=not args.no_interactive,
            include_anchors=not args.no_anchors,
            max_anchors=args.max_anchors,
        )
    finally:
        if created_temp_session:
            client.close_browser_session(session_id)

    payload = {
        "session_id": session_id,
        "url": args.url,
        "navigation": navigation,
        "readable_content": content.get("readable_content") or {},
        "interactive_elements": content.get("interactive_elements") or [],
        "content_anchors": content.get("content_anchors") or [],
    }
    return _emit_payload(args, payload, _format_browser_read_text(payload))


def handle_browser_screenshot(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    session_id, created_temp_session, _navigation = _prepare_browser_session(
        client,
        session_id=args.session,
        url=args.url,
    )
    try:
        screenshot_b64 = client.browser_screenshot(
            session_id,
            full_page=not args.no_full_page,
            format=args.image_format,
            quality=args.quality,
        )
    finally:
        if created_temp_session:
            client.close_browser_session(session_id)

    saved_bytes = _write_screenshot(args.out, screenshot_b64)
    payload = {
        "session_id": session_id,
        "url": args.url,
        "format": args.image_format,
        "local_path": args.out,
        "size": saved_bytes,
    }
    text_lines = [
        f"Saved screenshot: {args.out}",
        f"Session: {session_id}",
        f"Format: {args.image_format}",
        f"Size: {_human_bytes(saved_bytes)}",
    ]
    return _emit_payload(args, payload, text_lines)


def _resolve_desktop_target(client: InstaVM, target: str) -> dict[str, Any]:
    if _looks_like_uuid(target):
        status = client.get_session_status(target)
        status["session_id"] = target
        return status
    vm = client.vms.get(target)
    session_id = vm.get("session_id")
    if session_id:
        status = client.get_session_status(session_id)
        status["session_id"] = session_id
        status.setdefault("vm_id", vm.get("vm_id"))
        return status
    return {
        "session_id": None,
        "vm_id": vm.get("vm_id"),
        "vm_status": vm.get("status"),
        "vm_alive": vm.get("status") == "active",
    }


def _desktop_payload(client: InstaVM, target: str) -> dict[str, Any]:
    payload = _resolve_desktop_target(client, target)
    session_id = payload.get("session_id")
    if payload.get("vm_alive") and session_id:
        try:
            payload.update(client.computer_use.viewer_url(session_id))
        except InstaVMError:
            pass
    return payload


def handle_desktop_status(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    payload = _desktop_payload(client, args.target)
    text_lines = [
        f"Session: {payload.get('session_id') or '-'}",
        f"VM: {payload.get('vm_id') or '-'}",
        f"Status: {payload.get('vm_status') or ('active' if payload.get('vm_alive') else 'stopped')}",
    ]
    if payload.get("viewer_url"):
        text_lines.append(f"Viewer: {payload['viewer_url']}")
    return _emit_payload(args, payload, text_lines)


def handle_desktop_viewer(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    payload = _desktop_payload(client, args.target)
    if not payload.get("session_id") or not payload.get("vm_alive"):
        raise ValueError("Desktop is not running.")
    if "viewer_url" not in payload:
        payload.update(client.computer_use.viewer_url(payload["session_id"]))
    text_lines = [
        f"Session: {payload.get('session_id')}",
        f"VM: {payload.get('vm_id') or '-'}",
        f"Viewer URL: {payload.get('viewer_url')}",
    ]
    if payload.get("websocket_url"):
        text_lines.append(f"WebSocket: {payload['websocket_url']}")
    return _emit_payload(args, payload, text_lines)


def handle_desktop_start(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    payload = _desktop_payload(client, args.target)
    if payload.get("vm_alive"):
        return _emit_payload(
            args,
            payload,
            [
                f"Desktop already running: {payload.get('vm_id') or '-'}",
                f"Session: {payload.get('session_id') or '-'}",
            ],
        )
    session_id = payload.get("session_id")
    if not session_id:
        raise ValueError("Desktop start requires a session-backed VM or session ID.")
    result = client.vms.create(wait=True, session_id=session_id, image_variant="computer-use")
    merged = _desktop_payload(client, result.get("session_id") or session_id)
    merged.update(result)
    text_lines = [
        f"Desktop started: {merged.get('vm_id') or result.get('vm_id') or '-'}",
        f"Session: {merged.get('session_id') or result.get('session_id') or '-'}",
    ]
    if merged.get("viewer_url"):
        text_lines.append(f"Viewer: {merged['viewer_url']}")
    return _emit_payload(args, merged, text_lines)


def handle_desktop_stop(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    payload = _desktop_payload(client, args.target)
    if not payload.get("vm_alive"):
        return _emit_payload(args, payload, ["Desktop is already stopped."])
    if payload.get("session_id"):
        result = client.kill(payload["session_id"])
    elif payload.get("vm_id"):
        result = client.vms.delete(payload["vm_id"])
    else:
        raise ValueError("No active desktop VM found.")
    merged = {"session_id": payload.get("session_id"), "vm_id": payload.get("vm_id"), **result}
    text_lines = [f"Stopping {payload.get('vm_id') or payload.get('session_id')}..."]
    return _emit_payload(args, merged, text_lines)


def handle_volume_ls(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    volumes = client.volumes.list(refresh_usage=args.refresh)
    payload = {"volumes": volumes}
    if not volumes:
        return _emit_payload(args, payload, ["No volumes."])
    return _emit_payload(args, payload, _format_volume_list(volumes))


def handle_volume_get(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    volume = client.volumes.get(args.volume_id, refresh_usage=args.refresh)
    text_lines = [
        f"ID: {volume.get('id')}",
        f"Name: {volume.get('name')}",
        f"Status: {volume.get('status')}",
        f"Quota: {_human_bytes(volume.get('quota_bytes'))}",
        f"Used: {_human_bytes(volume.get('used_bytes'))}",
    ]
    return _emit_payload(args, volume, text_lines)


def handle_volume_create(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.volumes.create(name=args.name, quota_bytes=_parse_size(args.quota))
    text_lines = [
        f"Volume: {result.get('id')}",
        f"Name: {result.get('name')}",
        f"Quota: {_human_bytes(result.get('quota_bytes'))}",
    ]
    return _emit_payload(args, result, text_lines)


def handle_volume_update(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    kwargs: dict[str, Any] = {}
    if args.name:
        kwargs["name"] = args.name
    if args.quota:
        kwargs["quota_bytes"] = _parse_size(args.quota)
    if not kwargs:
        raise ValueError("Provide --name and/or --quota")
    result = client.volumes.update(args.volume_id, **kwargs)
    text_lines = [f"Updated volume {result.get('id') or args.volume_id}"]
    return _emit_payload(args, result, text_lines)


def handle_volume_rm(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.volumes.delete(args.volume_id)
    payload = {"volume_id": args.volume_id, **result}
    return _emit_payload(args, payload, [f"Deleted {args.volume_id}"])


def handle_volume_checkpoint_ls(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    checkpoints = client.volumes.list_checkpoints(args.volume_id)
    payload = {"checkpoints": checkpoints}
    if not checkpoints:
        return _emit_payload(args, payload, ["No checkpoints."])
    return _emit_payload(args, payload, _format_checkpoint_list(checkpoints))


def handle_volume_checkpoint_create(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.volumes.create_checkpoint(args.volume_id, name=args.name)
    return _emit_payload(args, result, [f"Created checkpoint {result.get('id') or '-'}"])


def handle_volume_checkpoint_rm(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.volumes.delete_checkpoint(args.volume_id, args.checkpoint_id)
    payload = {"checkpoint_id": args.checkpoint_id, **result}
    return _emit_payload(args, payload, [f"Deleted checkpoint {args.checkpoint_id}"])


def handle_volume_files_ls(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    files = client.volumes.list_files(
        args.volume_id,
        prefix=args.prefix or "",
        recursive=not args.no_recursive,
        limit=args.limit,
    )
    payload = {"files": files}
    if not files:
        return _emit_payload(args, payload, ["No files."])
    return _emit_payload(args, payload, _format_file_list(files))


def handle_volume_files_upload(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    remote_path = args.path or Path(args.local_path).name
    result = client.volumes.upload_file(
        args.volume_id,
        file_path=args.local_path,
        path=remote_path,
        overwrite=args.overwrite,
    )
    return _emit_payload(args, result, [f"Uploaded {args.local_path} -> {remote_path}"])


def handle_volume_files_download(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    output_path = args.out or Path(args.remote_path).name
    result = client.volumes.download_file(args.volume_id, path=args.remote_path, local_path=output_path)
    payload = {
        "path": result.get("path"),
        "filename": result.get("filename"),
        "size": result.get("size") or result.get("saved_bytes"),
        "local_path": result.get("local_path") or output_path,
    }
    return _emit_payload(args, payload, [f"Downloaded {args.remote_path} -> {payload['local_path']}"])


def handle_volume_files_rm(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    client, _settings = _require_api_key(args)
    result = client.volumes.delete_file(args.volume_id, path=args.remote_path)
    payload = {"path": args.remote_path, **result}
    return _emit_payload(args, payload, [f"Deleted {args.remote_path}"])


def handle_doc(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    payload = {"url": DEFAULT_DOCS_URL}
    return _emit_payload(args, payload, [DEFAULT_DOCS_URL])


def handle_billing(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    payload = {"url": DEFAULT_BILLING_URL}
    return _emit_payload(args, payload, [DEFAULT_BILLING_URL])


def handle_cookbook_list(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    root = resolve_cookbook_root()
    cookbooks = [manifest_display_record(manifest) for manifest in discover_cookbooks(root)]
    payload = {"cookbooks": cookbooks}
    return _emit_payload(args, payload, _format_cookbook_list(cookbooks))


def handle_cookbook_info(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    root = resolve_cookbook_root()
    manifest = load_manifest(root / args.slug / "instavm.yaml")
    payload = {
        **manifest_display_record(manifest),
        "vm": {
            "memory_mb": manifest.vm.memory_mb,
            "vcpu_count": manifest.vm.vcpu_count,
            "timeout_seconds": manifest.vm.timeout_seconds,
            "image_variant": manifest.vm.image_variant,
        },
        "app": {
            "port": manifest.app.port,
            "healthcheck_path": manifest.app.healthcheck_path,
            "share_public_default": manifest.app.share_public_default,
            "readiness_timeout_seconds": manifest.app.readiness_timeout_seconds,
        },
        "run": {
            "workdir": manifest.run.workdir,
            "start_command": manifest.run.start_command,
            "logs_hint": manifest.run.logs_hint,
        },
        "secrets": [
            {
                "name": secret.name,
                "env_name": secret.env_name,
                "required": secret.required,
                "prompt": secret.prompt,
            }
            for secret in manifest.secrets
        ],
        "notes": list(manifest.post_deploy_notes),
    }
    text_lines = [
        f"Slug: {manifest.slug}",
        f"Title: {manifest.title}",
        f"Summary: {manifest.summary}",
        f"Runtime: {manifest.runtime}",
        f"Deploy: {manifest.deploy.kind}",
        f"VM: {manifest.vm.vcpu_count} vCPU, {manifest.vm.memory_mb}MB",
        f"Port: {manifest.app.port}",
        f"Healthcheck: {manifest.app.healthcheck_path}",
        f"Secrets: {', '.join(secret.env_name for secret in manifest.secrets) or 'none'}",
    ]
    if manifest.post_deploy_notes:
        text_lines.append("Notes:")
        text_lines.extend(f"  - {note}" for note in manifest.post_deploy_notes)
    return _emit_payload(args, payload, text_lines)


def _print_deploy_plan(plan: Any) -> None:
    """Pretty-print the detected deploy plan."""
    runtime_label = {"node": "Node.js", "python": "Python", "static": "Static Site", "go": "Go", "deno": "Deno"}.get(plan.runtime, plan.runtime)
    lines = [
        "",
        f"  Detected: {runtime_label} ({plan.package_manager})",
        "",
        f"  Install:  {plan.install_command}",
    ]
    if plan.build_command:
        lines.append(f"  Build:    {plan.build_command}")
    lines.extend([
        f"  Start:    {plan.start_command}",
        f"  Port:     {plan.port}",
        f"  Health:   {plan.health_path}",
    ])
    if plan.secrets:
        lines.append("")
        lines.append("  Secrets:")
        for s in plan.secrets:
            env_val = os.environ.get(s.env_name, "")
            if env_val:
                lines.append(f"    {s.env_name}: set  (from environment)")
            else:
                lines.append(f"    {s.env_name}: (not set — will prompt)")
    lines.append("")
    _print_lines(*lines)


def _format_deploy_success(args: argparse.Namespace, payload: dict[str, Any]) -> list[str]:
    color_enabled = _supports_ansi(sys.stdout) and not getattr(args, "json_output", False)
    vm_id = str(payload.get("vm_id") or "")
    slug = str(payload.get("slug") or "")
    display_url = str(payload.get("share_url") or "").rstrip("/")
    connect_hint = f"instavm connect {vm_id}" if vm_id else "-"
    lines = [
        _style_text("Deployed", "1", "32", enabled=color_enabled),
        "",
        f"  App       {slug}",
        f"  VM        {vm_id}",
        f"  URL       {_style_text(display_url, '32', '4', enabled=color_enabled)}",
        f"  Connect   {connect_hint}",
        f"  Destroy   {payload.get('destroy_command', '')}",
    ]
    if payload.get("reused_snapshot_id"):
        lines.append(f"  Snapshot  reused {payload['reused_snapshot_id']}")
    if payload.get("saved_snapshot_id"):
        lines.append(f"  Snapshot  saved {payload['saved_snapshot_id']}")
    return lines


def handle_deploy(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    import dataclasses

    from ._detect import detect_project, plan_to_manifest

    path = Path(getattr(args, "path", ".")).resolve()
    if not path.is_dir():
        sys.stderr.write(f"Error: {path} is not a directory.\n")
        return 1

    try:
        plan = detect_project(path)
    except ValueError as exc:
        sys.stderr.write(f"Error: {exc}\n")
        return 1

    # Apply overrides from flags
    if getattr(args, "port", None):
        plan.port = args.port
    if getattr(args, "health_path", None):
        plan.health_path = args.health_path
    if getattr(args, "start_command", None):
        plan.start_command = args.start_command
    if getattr(args, "install_command", None):
        plan.install_command = args.install_command
    if getattr(args, "build_command", None) is not None:
        plan.build_command = args.build_command

    # Inject --env values into the environment so resolve_secret_values finds them
    for kv in (getattr(args, "env", None) or []):
        key, _, value = kv.partition("=")
        if key and value:
            os.environ[key] = value

    if getattr(args, "plan", False):
        if getattr(args, "json_output", False):
            _print_json({
                "slug": plan.slug,
                "runtime": plan.runtime,
                "package_manager": plan.package_manager,
                "install_command": plan.install_command,
                "build_command": plan.build_command,
                "start_command": plan.start_command,
                "port": plan.port,
                "health_path": plan.health_path,
                "secrets": [s.env_name for s in plan.secrets],
            })
        else:
            _print_deploy_plan(plan)
        return 0

    if not getattr(args, "yes", False) and sys.stdin.isatty():
        _print_deploy_plan(plan)
        confirm = input("  Deploy? [Y/n] ").strip().lower()
        if confirm == "n":
            return 0

    manifest = plan_to_manifest(plan, path)
    if getattr(args, "private", False):
        manifest = dataclasses.replace(
            manifest,
            app=dataclasses.replace(manifest.app, share_public_default=False),
        )

    client, settings = _require_api_key(args)
    progress_display = _ProgressDisplay(args)
    reused_snapshot_id = _resolve_saved_snapshot(
        client,
        path,
        plan,
        progress=lambda message: _progress(progress_display, message),
    )

    try:
        payload = _run_deploy(
            manifest,
            client=client,
            ssh_host=settings.ssh_host,
            progress=lambda message: _progress(progress_display, message),
            snapshot_id_override=reused_snapshot_id,
        )
        if reused_snapshot_id:
            payload["reused_snapshot_id"] = reused_snapshot_id
        if getattr(args, "save_snapshot", False):
            saved_snapshot_id = _create_deploy_snapshot(
                client,
                path,
                plan,
                payload,
                progress=lambda message: _progress(progress_display, message),
            )
            if saved_snapshot_id:
                payload["saved_snapshot_id"] = saved_snapshot_id
    except CookbookDeployError as exc:
        progress_display.stop()
        fail_payload = {"status": "failed", "error": str(exc), **exc.payload}
        lines = _format_cookbook_deploy_failure(args, str(exc), exc.payload)
        if getattr(args, "json_output", False):
            _print_json(fail_payload)
        else:
            _print_error_lines(*lines)
        return 1
    except (CookbookError, ValueError) as exc:
        progress_display.stop()
        if getattr(args, "json_output", False):
            _print_json({"status": "failed", "error": str(exc)})
        else:
            _print_error_lines(f"Error: {exc}")
        return 1
    finally:
        progress_display.stop()

    return _emit_payload(args, payload, _format_deploy_success(args, payload))


def handle_cookbook_deploy(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    progress_display = _ProgressDisplay(args)
    root = resolve_cookbook_root(progress=lambda message: _progress(progress_display, message))
    manifest = load_manifest(root / args.slug / "instavm.yaml")
    client, settings = _require_api_key(args)
    try:
        payload = deploy_cookbook(
            manifest,
            client=client,
            ssh_host=settings.ssh_host,
            progress=lambda message: _progress(progress_display, message),
        )
    except CookbookDeployError as exc:
        progress_display.stop()
        payload = {"status": "failed", "error": str(exc), **exc.payload}
        lines = _format_cookbook_deploy_failure(args, str(exc), exc.payload)
        if args.json_output:
            _print_json(payload)
        else:
            _print_error_lines(*lines)
        return 1
    except CookbookError as exc:
        progress_display.stop()
        if args.json_output:
            _print_json({"status": "failed", "error": str(exc), "slug": args.slug})
        else:
            _print_error_lines(*_format_cookbook_deploy_failure(args, str(exc), {}))
        return 1
    finally:
        progress_display.stop()

    return _emit_payload(args, payload, _format_cookbook_deploy_success(args, payload))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="instavm",
        description="InstaVM CLI for VM, snapshot, volume, desktop, identity, and sharing workflows.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    help_parser = subparsers.add_parser("help", help="Show help for the CLI or a subcommand")
    help_parser.add_argument("command_path", nargs="*", help="Command path, for example: volume files")
    help_parser.set_defaults(handler=handle_help)

    auth_parser = subparsers.add_parser("auth", help="Manage stored auth for the installed CLI")
    auth_subparsers = auth_parser.add_subparsers(dest="auth_command", required=True)

    auth_set_key = auth_subparsers.add_parser(
        "set-key",
        help="Store an InstaVM API key in ~/.instavm/config.json",
        description="Store an InstaVM API key from a hidden prompt or piped stdin.",
    )
    auth_set_key.add_argument("--base-url", help="Persist a default API base URL")
    auth_set_key.add_argument("--ssh-host", help="Persist a default SSH host")
    auth_set_key.add_argument("-j", "--json", dest="json_output", action="store_true", help="Emit JSON output")
    auth_set_key.set_defaults(handler=handle_auth_set_key)

    auth_status = auth_subparsers.add_parser("status", help="Show the effective CLI auth and endpoint settings")
    _add_runtime_options(auth_status, include_json=True, include_ssh_host=True)
    auth_status.set_defaults(handler=handle_auth_status)

    auth_logout = auth_subparsers.add_parser("logout", help="Remove the stored API key from the local CLI config")
    _add_runtime_options(auth_logout, include_json=True, include_ssh_host=True)
    auth_logout.set_defaults(handler=handle_auth_logout)

    whoami = subparsers.add_parser("whoami", help="Show the current account and SSH key registrations")
    _add_runtime_options(whoami)
    whoami.set_defaults(handler=handle_whoami)

    create = subparsers.add_parser("create", aliases=["new"], help="Create a new VM or desktop")
    _add_runtime_options(create)
    create.add_argument("--type", dest="vm_type", choices=["standard", "computer-use"], default="standard")
    create.add_argument("--timeout", type=int, help="VM lifetime in seconds")
    create.add_argument("--memory", type=int, help="Memory in MB")
    create.add_argument("--vcpu", type=int, help="vCPU count")
    create.add_argument("--snapshot", help="Snapshot ID to boot from")
    create.add_argument("--session", help="Session ID to attach or respawn")
    create.add_argument("--volume", action="append", help="Volume spec: <volume_id>:<mount_path>[:rw|ro[:checkpoint_id]]")
    create.set_defaults(handler=handle_create)

    ls_parser = subparsers.add_parser(
        "ls",
        aliases=["list"],
        help="List active VMs by default",
        description="List active VMs by default. Use -a or --all to include terminated VM records.",
    )
    _add_runtime_options(ls_parser)
    ls_parser.add_argument("-a", "--all", action="store_true", help="Include all VM records, including terminated VMs")
    ls_parser.add_argument("--watch", nargs="?", const=5, type=int, help="Refresh every N seconds (default: 5)")
    ls_parser.set_defaults(handler=handle_ls)

    rm_parser = subparsers.add_parser("rm", aliases=["delete"], help="Delete one or more VMs")
    _add_runtime_options(rm_parser)
    rm_parser.add_argument("vm_ids", nargs="+", help="VM IDs to terminate")
    rm_parser.set_defaults(handler=handle_rm)

    clone_parser = subparsers.add_parser("clone", help="Clone a VM via snapshot")
    _add_runtime_options(clone_parser)
    clone_parser.add_argument("vm_id", help="Source VM ID")
    clone_parser.add_argument("--name", help="Snapshot name used during clone")
    clone_parser.set_defaults(handler=handle_clone)

    connect_parser = subparsers.add_parser("connect", help="SSH into a VM with the local ssh client")
    _add_runtime_options(connect_parser, include_json=True, include_ssh_host=True)
    connect_parser.add_argument("vm_id", help="VM ID to connect to")
    connect_parser.add_argument("ssh_args", nargs=argparse.REMAINDER, help="Additional ssh arguments after --")
    connect_parser.set_defaults(handler=handle_connect)

    snapshot_parser = subparsers.add_parser("snapshot", help="List, inspect, build, create, and delete snapshots")
    snapshot_subparsers = snapshot_parser.add_subparsers(dest="snapshot_command", required=True)

    snapshot_ls = snapshot_subparsers.add_parser("ls", aliases=["list"], help="List snapshots")
    _add_runtime_options(snapshot_ls)
    snapshot_ls.add_argument("--type", dest="snapshot_type", choices=["user", "system"], help="Snapshot type filter")
    snapshot_ls.set_defaults(handler=handle_snapshot_ls)

    snapshot_create = snapshot_subparsers.add_parser("create", help="Create a snapshot from a running VM")
    _add_runtime_options(snapshot_create)
    snapshot_create.add_argument("vm_id", help="VM ID to snapshot")
    snapshot_create.add_argument("--name", help="Snapshot name")
    snapshot_create.set_defaults(handler=handle_snapshot_create)

    snapshot_build = snapshot_subparsers.add_parser("build", help="Build a snapshot from an OCI image")
    _add_runtime_options(snapshot_build)
    snapshot_build.add_argument("oci_image", help="OCI image reference")
    snapshot_build.add_argument("--name", help="Snapshot name")
    snapshot_build.add_argument("--vcpu", type=int, help="vCPU count")
    snapshot_build.add_argument("--memory", type=int, help="Memory in MB")
    snapshot_build.add_argument("--disk-size", type=int, help="Snapshot disk size in GB")
    snapshot_build.add_argument("--env", action="append", help="Build environment variable in KEY=VALUE form")
    snapshot_build.add_argument("--git-clone", help="Git repository to clone during build")
    snapshot_build.add_argument("--git-branch", help="Git branch to checkout")
    snapshot_build.add_argument("--run", help="Command to run after the image is prepared")
    snapshot_build.add_argument("--apt", help="Extra apt packages")
    snapshot_build.add_argument("--pip", help="Extra pip packages")
    snapshot_build.add_argument("--npm", help="Extra npm packages")
    snapshot_build.add_argument("--type", dest="snapshot_type", choices=["user", "system"], default="user")
    snapshot_build.set_defaults(handler=handle_snapshot_build)

    snapshot_get = snapshot_subparsers.add_parser("get", help="Get a snapshot by ID")
    _add_runtime_options(snapshot_get)
    snapshot_get.add_argument("snapshot_id", help="Snapshot ID")
    snapshot_get.add_argument("--watch", nargs="?", const=5, type=int, help="Refresh every N seconds (default: 5)")
    snapshot_get.set_defaults(handler=handle_snapshot_get)

    snapshot_rm = snapshot_subparsers.add_parser("rm", aliases=["delete"], help="Delete a snapshot")
    _add_runtime_options(snapshot_rm)
    snapshot_rm.add_argument("snapshot_id", help="Snapshot ID")
    snapshot_rm.set_defaults(handler=handle_snapshot_rm)

    share_parser = subparsers.add_parser("share", help="Create and manage VM shares")
    share_subparsers = share_parser.add_subparsers(dest="share_command", required=True)

    share_create = share_subparsers.add_parser("create", help="Create a share for a VM and port")
    _add_runtime_options(share_create)
    share_create.add_argument("vm_id", help="VM ID")
    share_create.add_argument("port", type=int, help="Port to expose")
    share_create.add_argument("--public", action="store_true", help="Create the share as public")
    share_create.set_defaults(handler=handle_share_create)

    share_set_public = share_subparsers.add_parser("set-public", help="Set a share to public visibility")
    _add_runtime_options(share_set_public)
    share_set_public.add_argument("share_id", help="Share ID")
    share_set_public.set_defaults(handler=handle_share_update, visibility="public")

    share_set_private = share_subparsers.add_parser("set-private", help="Set a share to private visibility")
    _add_runtime_options(share_set_private)
    share_set_private.add_argument("share_id", help="Share ID")
    share_set_private.set_defaults(handler=handle_share_update, visibility="private")

    share_revoke = share_subparsers.add_parser("revoke", help="Revoke a share by share ID")
    _add_runtime_options(share_revoke)
    share_revoke.add_argument("share_id", help="Share ID")
    share_revoke.set_defaults(handler=handle_share_update, visibility="revoke")

    egress_parser = subparsers.add_parser("egress", help="Get or set VM and session egress policy")
    egress_subparsers = egress_parser.add_subparsers(dest="egress_command", required=True)

    egress_get = egress_subparsers.add_parser("get", help="Get the egress policy for a session or VM")
    _add_runtime_options(egress_get)
    egress_get.add_argument("--session", dest="session_id", help="Session ID")
    egress_get.add_argument("--vm", dest="vm_id", help="VM ID")
    egress_get.set_defaults(handler=handle_egress_get)

    egress_set = egress_subparsers.add_parser("set", help="Set the egress policy for a session or VM")
    _add_runtime_options(egress_set)
    egress_set.add_argument("--session", dest="session_id", help="Session ID")
    egress_set.add_argument("--vm", dest="vm_id", help="VM ID")
    egress_set.add_argument(
        "--allow-package-managers",
        dest="allow_package_managers",
        action="store_true",
        help="Allow package-manager traffic to public repos",
    )
    egress_set.add_argument(
        "--no-allow-package-managers",
        dest="allow_package_managers",
        action="store_false",
        help="Block package-manager traffic to public repos",
    )
    egress_set.add_argument("--allow-http", dest="allow_http", action="store_true", help="Allow HTTP traffic")
    egress_set.add_argument("--deny-http", dest="allow_http", action="store_false", help="Block HTTP traffic")
    egress_set.add_argument("--allow-https", dest="allow_https", action="store_true", help="Allow HTTPS traffic")
    egress_set.add_argument("--deny-https", dest="allow_https", action="store_false", help="Block HTTPS traffic")
    egress_set.add_argument("--domain", dest="allowed_domains", action="append", default=[], help="Allowed domain (repeatable)")
    egress_set.add_argument("--cidr", dest="allowed_cidrs", action="append", default=[], help="Allowed CIDR (repeatable)")
    egress_set.set_defaults(
        handler=handle_egress_set,
        allow_package_managers=True,
        allow_http=True,
        allow_https=True,
    )

    ssh_key_parser = subparsers.add_parser("ssh-key", aliases=["sshkey"], help="Manage SSH keys on your account")
    ssh_key_subparsers = ssh_key_parser.add_subparsers(dest="ssh_key_command", required=True)

    ssh_key_list = ssh_key_subparsers.add_parser("list", help="List active SSH keys")
    _add_runtime_options(ssh_key_list)
    ssh_key_list.set_defaults(handler=handle_ssh_key_list)

    ssh_key_add = ssh_key_subparsers.add_parser("add", help="Add an SSH public key")
    _add_runtime_options(ssh_key_add)
    ssh_key_add.add_argument("public_key", nargs="?", help="Public key string. If omitted, reads from stdin.")
    ssh_key_add.set_defaults(handler=handle_ssh_key_add)

    ssh_key_remove = ssh_key_subparsers.add_parser("remove", help="Remove an SSH key by key ID")
    _add_runtime_options(ssh_key_remove)
    ssh_key_remove.add_argument("key_id", help="SSH key ID")
    ssh_key_remove.set_defaults(handler=handle_ssh_key_remove)

    exec_parser = subparsers.add_parser("exec", help="Execute inline code or a local file in a session-backed VM")
    _add_runtime_options(exec_parser)
    exec_parser.add_argument("target", nargs="?", help="Local file path or the keyword `result`")
    exec_parser.add_argument("task_id", nargs="?", help="Task ID when using `instavm exec result <task_id>`")
    exec_parser.add_argument("--cmd", help="Inline command or source code to execute")
    exec_parser.add_argument("--language", choices=["python", "bash"], help="Execution language override")
    exec_parser.add_argument("--session", help="Reuse an existing session ID")
    exec_parser.add_argument("--timeout", type=int, help="Execution timeout in seconds")
    exec_parser.add_argument("--async", dest="async_exec", action="store_true", help="Run asynchronously")
    exec_parser.add_argument("--poll-interval", type=int, default=1, help="Polling interval in seconds for result lookup")
    exec_parser.set_defaults(handler=handle_exec)

    browser_parser = subparsers.add_parser("browser", help="Read pages and save browser screenshots")
    browser_subparsers = browser_parser.add_subparsers(dest="browser_command", required=True)

    browser_read = browser_subparsers.add_parser("read", help="Extract readable page content in the terminal")
    _add_runtime_options(browser_read)
    browser_read.add_argument("url", nargs="?", help="URL to open in a temporary browser session")
    browser_read.add_argument("--session", help="Reuse an existing browser session ID")
    browser_read.add_argument("--no-interactive", action="store_true", help="Omit interactive elements from the response")
    browser_read.add_argument("--no-anchors", action="store_true", help="Omit content anchors from the response")
    browser_read.add_argument("--max-anchors", type=int, default=50, help="Maximum number of anchors to extract")
    browser_read.set_defaults(handler=handle_browser_read)

    browser_screenshot = browser_subparsers.add_parser("screenshot", help="Save a browser screenshot to a local file")
    _add_runtime_options(browser_screenshot)
    browser_screenshot.add_argument("url", nargs="?", help="URL to open in a temporary browser session")
    browser_screenshot.add_argument("--session", help="Reuse an existing browser session ID")
    browser_screenshot.add_argument("--out", required=True, help="Local output path")
    browser_screenshot.add_argument("--format", dest="image_format", choices=["png", "jpeg", "webp"], default="png", help="Image format")
    browser_screenshot.add_argument("--quality", type=int, help="Image quality for jpeg/webp")
    browser_screenshot.add_argument("--no-full-page", action="store_true", help="Capture only the current viewport")
    browser_screenshot.set_defaults(handler=handle_browser_screenshot)

    desktop_parser = subparsers.add_parser("desktop", help="Manage computer-use desktops and viewer handoff")
    desktop_subparsers = desktop_parser.add_subparsers(dest="desktop_command", required=True)
    for name, help_text, handler in (
        ("status", "Show desktop status for a VM or session", handle_desktop_status),
        ("start", "Start a computer-use desktop for a session", handle_desktop_start),
        ("stop", "Stop a running desktop VM", handle_desktop_stop),
        ("viewer", "Get the noVNC viewer URL for a running desktop", handle_desktop_viewer),
    ):
        desktop_command = desktop_subparsers.add_parser(name, help=help_text)
        _add_runtime_options(desktop_command)
        desktop_command.add_argument("target", help="VM ID or session ID")
        desktop_command.set_defaults(handler=handler)

    volume_parser = subparsers.add_parser("volume", aliases=["volumes"], help="Manage persistent volumes")
    volume_subparsers = volume_parser.add_subparsers(dest="volume_command", required=True)

    volume_ls = volume_subparsers.add_parser("ls", aliases=["list"], help="List volumes")
    _add_runtime_options(volume_ls)
    volume_ls.add_argument("--refresh", action="store_true", help="Refresh usage before listing")
    volume_ls.set_defaults(handler=handle_volume_ls)

    volume_get = volume_subparsers.add_parser("get", help="Get a volume")
    _add_runtime_options(volume_get)
    volume_get.add_argument("volume_id", help="Volume ID")
    volume_get.add_argument("--refresh", action="store_true", help="Refresh usage before reading")
    volume_get.set_defaults(handler=handle_volume_get)

    volume_create = volume_subparsers.add_parser("create", help="Create a volume")
    _add_runtime_options(volume_create)
    volume_create.add_argument("name", help="Volume name")
    volume_create.add_argument("--quota", required=True, help="Quota in bytes or units like 5gb")
    volume_create.set_defaults(handler=handle_volume_create)

    volume_update = volume_subparsers.add_parser("update", help="Update a volume")
    _add_runtime_options(volume_update)
    volume_update.add_argument("volume_id", help="Volume ID")
    volume_update.add_argument("--name", help="Updated volume name")
    volume_update.add_argument("--quota", help="Updated quota in bytes or units like 5gb")
    volume_update.set_defaults(handler=handle_volume_update)

    volume_rm = volume_subparsers.add_parser("rm", aliases=["delete"], help="Delete a volume")
    _add_runtime_options(volume_rm)
    volume_rm.add_argument("volume_id", help="Volume ID")
    volume_rm.set_defaults(handler=handle_volume_rm)

    checkpoint_parser = volume_subparsers.add_parser("checkpoint", help="Manage checkpoints for a volume")
    checkpoint_subparsers = checkpoint_parser.add_subparsers(dest="volume_checkpoint_command", required=True)

    checkpoint_ls = checkpoint_subparsers.add_parser("ls", aliases=["list"], help="List checkpoints for a volume")
    _add_runtime_options(checkpoint_ls)
    checkpoint_ls.add_argument("volume_id", help="Volume ID")
    checkpoint_ls.set_defaults(handler=handle_volume_checkpoint_ls)

    checkpoint_create = checkpoint_subparsers.add_parser("create", help="Create a checkpoint for a volume")
    _add_runtime_options(checkpoint_create)
    checkpoint_create.add_argument("volume_id", help="Volume ID")
    checkpoint_create.add_argument("--name", help="Checkpoint name")
    checkpoint_create.set_defaults(handler=handle_volume_checkpoint_create)

    checkpoint_rm = checkpoint_subparsers.add_parser("rm", aliases=["delete"], help="Delete a checkpoint")
    _add_runtime_options(checkpoint_rm)
    checkpoint_rm.add_argument("volume_id", help="Volume ID")
    checkpoint_rm.add_argument("checkpoint_id", help="Checkpoint ID")
    checkpoint_rm.set_defaults(handler=handle_volume_checkpoint_rm)

    files_parser = volume_subparsers.add_parser("files", help="Manage files stored inside a volume")
    files_subparsers = files_parser.add_subparsers(dest="volume_files_command", required=True)

    files_ls = files_subparsers.add_parser("ls", aliases=["list"], help="List files inside a volume")
    _add_runtime_options(files_ls)
    files_ls.add_argument("volume_id", help="Volume ID")
    files_ls.add_argument("--prefix", help="Path prefix filter")
    files_ls.add_argument("--limit", type=int, default=1000, help="Maximum number of entries")
    files_ls.add_argument("--no-recursive", action="store_true", help="Do not recurse into subdirectories")
    files_ls.set_defaults(handler=handle_volume_files_ls)

    files_upload = files_subparsers.add_parser("upload", help="Upload a file into a volume")
    _add_runtime_options(files_upload)
    files_upload.add_argument("volume_id", help="Volume ID")
    files_upload.add_argument("local_path", help="Local file path")
    files_upload.add_argument("--path", help="Remote path inside the volume")
    files_upload.add_argument("--overwrite", action="store_true", help="Overwrite if the path already exists")
    files_upload.set_defaults(handler=handle_volume_files_upload)

    files_download = files_subparsers.add_parser("download", help="Download a file from a volume")
    _add_runtime_options(files_download)
    files_download.add_argument("volume_id", help="Volume ID")
    files_download.add_argument("remote_path", help="Remote path inside the volume")
    files_download.add_argument("--out", help="Local output path")
    files_download.set_defaults(handler=handle_volume_files_download)

    files_rm = files_subparsers.add_parser("rm", aliases=["delete"], help="Delete a file from a volume")
    _add_runtime_options(files_rm)
    files_rm.add_argument("volume_id", help="Volume ID")
    files_rm.add_argument("remote_path", help="Remote path inside the volume")
    files_rm.set_defaults(handler=handle_volume_files_rm)

    doc_parser = subparsers.add_parser("doc", aliases=["docs"], help="Show InstaVM documentation links")
    doc_parser.add_argument("-j", "--json", dest="json_output", action="store_true", help="Emit JSON output")
    doc_parser.set_defaults(handler=handle_doc)

    billing_parser = subparsers.add_parser("billing", help="Show the billing portal URL")
    billing_parser.add_argument("-j", "--json", dest="json_output", action="store_true", help="Emit JSON output")
    billing_parser.set_defaults(handler=handle_billing)

    deploy_parser = subparsers.add_parser("deploy", help="Detect and deploy an app from a local directory")
    _add_runtime_options(deploy_parser, include_json=True, include_ssh_host=True)
    deploy_parser.add_argument("path", nargs="?", default=".", help="Project directory (default: .)")
    deploy_parser.add_argument("-y", "--yes", action="store_true", help="Skip confirmation prompt")
    deploy_parser.add_argument("--env", action="append", metavar="KEY=VALUE", help="Set environment variable (repeatable)")
    deploy_parser.add_argument("--port", type=int, help="Override detected port")
    deploy_parser.add_argument("--health-path", dest="health_path", help="Override detected health check path")
    deploy_parser.add_argument("--start-command", dest="start_command", help="Override detected start command")
    deploy_parser.add_argument("--install-command", dest="install_command", help="Override detected install command")
    deploy_parser.add_argument("--build-command", dest="build_command", help="Override detected build command")
    deploy_parser.add_argument("--plan", action="store_true", help="Show detected plan and exit (dry-run)")
    deploy_parser.add_argument("--private", action="store_true", help="Don't create public share")
    deploy_parser.add_argument("--save-snapshot", action="store_true", help="Create VM snapshot after successful deploy")
    deploy_parser.set_defaults(handler=handle_deploy)

    cookbook_parser = subparsers.add_parser("cookbook", help="Discover and deploy curated cookbook applications")
    cookbook_subparsers = cookbook_parser.add_subparsers(dest="cookbook_command", required=True)

    cookbook_list = cookbook_subparsers.add_parser("list", help="List available cookbooks")
    cookbook_list.add_argument("-j", "--json", dest="json_output", action="store_true", help="Emit JSON output")
    cookbook_list.set_defaults(handler=handle_cookbook_list)

    cookbook_info = cookbook_subparsers.add_parser("info", help="Show cookbook details and required secrets")
    cookbook_info.add_argument("slug", help="Cookbook slug")
    cookbook_info.add_argument("-j", "--json", dest="json_output", action="store_true", help="Emit JSON output")
    cookbook_info.set_defaults(handler=handle_cookbook_info)

    cookbook_deploy = cookbook_subparsers.add_parser(
        "deploy",
        help="Create a VM, start the cookbook app, and return the public share URL",
    )
    _add_runtime_options(cookbook_deploy, include_json=True, include_ssh_host=True)
    cookbook_deploy.add_argument("slug", help="Cookbook slug")
    cookbook_deploy.set_defaults(handler=handle_cookbook_deploy)

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(_normalize_argv(argv))
        return args.handler(args, parser)
    except (AuthenticationError, ConfigError, FileNotFoundError, InstaVMError, ValueError) as exc:
        sys.stderr.write(f"Error: {exc}\n")
        return 1
    except KeyboardInterrupt:
        sys.stderr.write("Interrupted.\n")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
