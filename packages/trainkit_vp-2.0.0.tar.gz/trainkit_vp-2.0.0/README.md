# trainkit-vp

`trainkit-vp` packages reusable training infrastructure for PyTorch projects.

It includes:

- checkpoint save/load helpers
- staged freezing utilities
- memory estimation and training plan helpers
- cosine scheduling and structured loss helpers

Install:

```bash
pip install trainkit-vp
```
