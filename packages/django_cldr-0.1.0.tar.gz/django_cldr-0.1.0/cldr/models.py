from django.db import models


# =============================================================================
# Core supplemental data (from cldr-core)
# =============================================================================


class Territory(models.Model):
    """ISO 3166-1 countries and UN M.49 regions/groupings."""

    class TerritoryType(models.TextChoices):
        WORLD = "world", "World"
        CONTINENT = "continent", "Continent"
        SUBCONTINENT = "subcontinent", "Sub-continent"
        COUNTRY = "country", "Country"
        GROUPING = "grouping", "Grouping"

    code = models.CharField(max_length=10, unique=True, db_index=True)
    alpha3 = models.CharField(max_length=3, blank=True, default="")
    numeric_code = models.CharField(max_length=3, blank=True, default="")
    fips = models.CharField(max_length=10, blank=True, default="")
    territory_type = models.CharField(
        max_length=20,
        choices=TerritoryType,
        default=TerritoryType.COUNTRY,
    )
    gdp = models.BigIntegerField(null=True, blank=True)
    literacy_percent = models.FloatField(null=True, blank=True)
    population = models.BigIntegerField(null=True, blank=True)

    class Meta:
        verbose_name_plural = "territories"
        ordering = ["code"]

    def __str__(self):
        return self.code


class TerritoryContainment(models.Model):
    """Parent-child relationships between territories (DAG, not tree).

    A territory can appear in both geographic and non-geographic groupings.
    E.g., France is in Europe (geographic) and EU/Eurozone (groupings).
    """

    class GroupType(models.TextChoices):
        GEOGRAPHIC = "geographic", "Geographic"
        NON_GEOGRAPHIC = "non_geographic", "Non-geographic"
        DEPRECATED = "deprecated", "Deprecated"

    parent = models.ForeignKey(
        Territory,
        on_delete=models.CASCADE,
        related_name="children",
    )
    child = models.ForeignKey(
        Territory,
        on_delete=models.CASCADE,
        related_name="parents",
    )
    group_type = models.CharField(
        max_length=20,
        choices=GroupType,
        default=GroupType.GEOGRAPHIC,
    )

    class Meta:
        unique_together = [("parent", "child", "group_type")]

    def __str__(self):
        return f"{self.parent.code} > {self.child.code}"


class Language(models.Model):
    """BCP47 language codes."""

    code = models.CharField(max_length=20, unique=True, db_index=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return self.code


class Script(models.Model):
    """ISO 15924 writing system codes."""

    code = models.CharField(max_length=4, unique=True, db_index=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return self.code


class Currency(models.Model):
    """ISO 4217 currency codes with formatting rules."""

    code = models.CharField(max_length=3, unique=True, db_index=True)
    numeric_code = models.IntegerField(null=True, blank=True)
    digits = models.IntegerField(default=2)
    rounding = models.IntegerField(default=0)
    cash_digits = models.IntegerField(null=True, blank=True)
    cash_rounding = models.IntegerField(null=True, blank=True)
    is_tender = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = "currencies"
        ordering = ["code"]

    def __str__(self):
        return self.code


class LanguageTerritory(models.Model):
    """Languages spoken in a territory with population and status data."""

    class OfficialStatus(models.TextChoices):
        OFFICIAL = "official", "Official"
        OFFICIAL_REGIONAL = "official_regional", "Official (regional)"
        DE_FACTO_OFFICIAL = "de_facto_official", "De facto official"
        UNKNOWN = "", "Unknown"

    language = models.ForeignKey(
        Language,
        on_delete=models.CASCADE,
        related_name="territories",
    )
    territory = models.ForeignKey(
        Territory,
        on_delete=models.CASCADE,
        related_name="languages",
    )
    population_percent = models.FloatField(null=True, blank=True)
    official_status = models.CharField(
        max_length=30,
        choices=OfficialStatus,
        blank=True,
        default="",
    )
    literacy_percent = models.FloatField(null=True, blank=True)

    class Meta:
        unique_together = [("language", "territory")]

    def __str__(self):
        return f"{self.language.code} in {self.territory.code}"


class LanguageScript(models.Model):
    """Scripts used by a language (primary vs secondary)."""

    language = models.ForeignKey(
        Language,
        on_delete=models.CASCADE,
        related_name="scripts",
    )
    script = models.ForeignKey(
        Script,
        on_delete=models.CASCADE,
        related_name="languages",
    )
    is_primary = models.BooleanField(default=True)

    class Meta:
        unique_together = [("language", "script")]

    def __str__(self):
        return f"{self.language.code}-{self.script.code}"


class TerritoryCurrency(models.Model):
    """Historical currency usage per territory with date ranges."""

    territory = models.ForeignKey(
        Territory,
        on_delete=models.CASCADE,
        related_name="currencies",
    )
    currency = models.ForeignKey(
        Currency,
        on_delete=models.CASCADE,
        related_name="territories",
    )
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    is_tender = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = "territory currencies"
        ordering = ["territory", "-from_date"]

    def __str__(self):
        return f"{self.territory.code}: {self.currency.code}"


class LikelySubtag(models.Model):
    """Locale inference rules (e.g., 'ar' -> 'ar-Arab-EG')."""

    from_tag = models.CharField(max_length=50, unique=True)
    to_tag = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.from_tag} -> {self.to_tag}"


class CodeMapping(models.Model):
    """Maps between alpha-2, alpha-3, numeric (M.49), and FIPS codes.

    Stored on Territory directly, but this model captures the full
    CLDR codeMappings including historical/deprecated codes.
    """

    alpha2 = models.CharField(max_length=2, db_index=True)
    alpha3 = models.CharField(max_length=3, blank=True, default="")
    numeric = models.CharField(max_length=3, blank=True, default="")
    fips = models.CharField(max_length=10, blank=True, default="")

    class Meta:
        ordering = ["alpha2"]

    def __str__(self):
        return self.alpha2


class WeekData(models.Model):
    """Week preferences per territory."""

    territory = models.OneToOneField(
        Territory,
        on_delete=models.CASCADE,
        related_name="week_data",
    )
    first_day = models.CharField(max_length=3)  # mon, tue, etc.
    min_days = models.IntegerField(default=1)
    weekend_start = models.CharField(max_length=3, blank=True, default="sat")
    weekend_end = models.CharField(max_length=3, blank=True, default="sun")

    class Meta:
        verbose_name_plural = "week data"

    def __str__(self):
        return f"{self.territory.code}: first={self.first_day}"


class MeasurementSystem(models.Model):
    """Measurement and paper size preferences per territory."""

    class System(models.TextChoices):
        METRIC = "metric", "Metric"
        US = "US", "US"
        UK = "UK", "UK"

    class PaperSize(models.TextChoices):
        A4 = "A4", "A4"
        US_LETTER = "US-Letter", "US Letter"

    territory = models.OneToOneField(
        Territory,
        on_delete=models.CASCADE,
        related_name="measurement",
    )
    system = models.CharField(
        max_length=10,
        choices=System,
        default=System.METRIC,
    )
    paper_size = models.CharField(
        max_length=10,
        choices=PaperSize,
        default=PaperSize.A4,
    )

    def __str__(self):
        return f"{self.territory.code}: {self.system}"


class NumberingSystem(models.Model):
    """Numbering systems (Latin, Arabic-Indic, Devanagari, etc.)."""

    class SystemType(models.TextChoices):
        NUMERIC = "numeric", "Numeric"
        ALGORITHMIC = "algorithmic", "Algorithmic"

    system_id = models.CharField(max_length=20, unique=True)
    system_type = models.CharField(
        max_length=20,
        choices=SystemType,
        default=SystemType.NUMERIC,
    )
    digits = models.CharField(max_length=40, blank=True, default="")
    rules = models.TextField(blank=True, default="")

    def __str__(self):
        return self.system_id


class CalendarPreference(models.Model):
    """Preferred calendar types per territory, ordered."""

    territory = models.ForeignKey(
        Territory,
        on_delete=models.CASCADE,
        related_name="calendar_preferences",
    )
    calendar_type = models.CharField(max_length=30)
    ordering = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["territory", "ordering"]
        unique_together = [("territory", "calendar_type")]

    def __str__(self):
        return f"{self.territory.code}: {self.calendar_type}"


class PluralRule(models.Model):
    """Cardinal and ordinal plural rules per locale.

    Rules are stored as CLDR algorithmic text (e.g., 'i = 1 and v = 0').
    Use a library like Babel for runtime evaluation.
    """

    class RuleType(models.TextChoices):
        CARDINAL = "cardinal", "Cardinal"
        ORDINAL = "ordinal", "Ordinal"

    class PluralCategory(models.TextChoices):
        ZERO = "zero", "Zero"
        ONE = "one", "One"
        TWO = "two", "Two"
        FEW = "few", "Few"
        MANY = "many", "Many"
        OTHER = "other", "Other"

    locale = models.CharField(max_length=20, db_index=True)
    rule_type = models.CharField(max_length=10, choices=RuleType)
    category = models.CharField(max_length=10, choices=PluralCategory)
    rule = models.TextField(blank=True, default="")
    examples = models.TextField(blank=True, default="")

    class Meta:
        unique_together = [("locale", "rule_type", "category")]
        ordering = ["locale", "rule_type"]

    def __str__(self):
        return f"{self.locale} {self.rule_type}: {self.category}"


class ParentLocale(models.Model):
    """Non-obvious locale inheritance overrides."""

    locale = models.CharField(max_length=20, unique=True)
    parent = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.locale} -> {self.parent}"


# =============================================================================
# Subdivisions (from cldr-subdivisions)
# =============================================================================


class Subdivision(models.Model):
    """Administrative subdivisions (states, provinces, etc.)."""

    code = models.CharField(max_length=20, unique=True, db_index=True)
    territory = models.ForeignKey(
        Territory,
        on_delete=models.CASCADE,
        related_name="subdivisions",
    )

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return self.code


# =============================================================================
# Localized display names (from cldr-localenames-full)
# =============================================================================


class LocalizedName(models.Model):
    """Translated display names for territories, languages, scripts, currencies.

    With 700 locales and ~1000+ entities, this table can be very large.
    Configure CLDR_LOCALES to limit which locales are imported.
    """

    class EntityType(models.TextChoices):
        TERRITORY = "territory", "Territory"
        LANGUAGE = "language", "Language"
        SCRIPT = "script", "Script"
        CURRENCY = "currency", "Currency"
        SUBDIVISION = "subdivision", "Subdivision"
        VARIANT = "variant", "Variant"

    entity_type = models.CharField(max_length=20, choices=EntityType, db_index=True)
    entity_code = models.CharField(max_length=20, db_index=True)
    locale = models.CharField(max_length=20, db_index=True)
    name = models.CharField(max_length=255)
    alt_type = models.CharField(max_length=30, blank=True, default="")

    class Meta:
        unique_together = [("entity_type", "entity_code", "locale", "alt_type")]
        indexes = [
            models.Index(
                fields=["entity_type", "entity_code", "locale"],
                name="cldr_locname_lookup",
            ),
        ]

    def __str__(self):
        return f"{self.entity_type}:{self.entity_code} [{self.locale}] = {self.name}"


# =============================================================================
# Number formatting (from cldr-numbers-full)
# =============================================================================


class NumberSymbols(models.Model):
    """Number formatting symbols per locale and numbering system."""

    locale = models.CharField(max_length=20, db_index=True)
    numbering_system = models.CharField(max_length=20, default="latn")
    decimal = models.CharField(max_length=5, default=".")
    group = models.CharField(max_length=5, default=",")
    percent_sign = models.CharField(max_length=5, default="%")
    minus_sign = models.CharField(max_length=5, default="-")
    plus_sign = models.CharField(max_length=5, default="+")
    exponential = models.CharField(max_length=5, default="E")
    superscripting_exponent = models.CharField(max_length=10, default="x")
    infinity = models.CharField(max_length=5, default="\u221e")
    nan = models.CharField(max_length=10, default="NaN")
    time_separator = models.CharField(max_length=5, default=":")

    class Meta:
        verbose_name_plural = "number symbols"
        unique_together = [("locale", "numbering_system")]

    def __str__(self):
        return f"{self.locale} ({self.numbering_system})"


class NumberPattern(models.Model):
    """Number formatting patterns (ICU syntax) per locale."""

    class PatternType(models.TextChoices):
        DECIMAL = "decimal", "Decimal"
        PERCENT = "percent", "Percent"
        SCIENTIFIC = "scientific", "Scientific"
        CURRENCY = "currency", "Currency"
        CURRENCY_ACCOUNTING = "currency_accounting", "Currency (Accounting)"

    locale = models.CharField(max_length=20, db_index=True)
    numbering_system = models.CharField(max_length=20, default="latn")
    pattern_type = models.CharField(max_length=25, choices=PatternType)
    pattern = models.CharField(max_length=100)

    class Meta:
        unique_together = [("locale", "numbering_system", "pattern_type")]

    def __str__(self):
        return f"{self.locale} {self.pattern_type}: {self.pattern}"


class CurrencyDisplayName(models.Model):
    """Localized currency names with plural forms.

    E.g., 'one' -> 'US dollar', 'other' -> 'US dollars'.
    """

    currency = models.ForeignKey(
        Currency,
        on_delete=models.CASCADE,
        related_name="display_names",
    )
    locale = models.CharField(max_length=20, db_index=True)
    count = models.CharField(max_length=10, blank=True, default="")
    name = models.CharField(max_length=100)
    symbol = models.CharField(max_length=20, blank=True, default="")
    narrow_symbol = models.CharField(max_length=10, blank=True, default="")

    class Meta:
        unique_together = [("currency", "locale", "count")]

    def __str__(self):
        return f"{self.currency.code} [{self.locale}] {self.count}: {self.name}"


# =============================================================================
# Date/time formatting (from cldr-dates-full)
# =============================================================================


class DateTimePattern(models.Model):
    """Date, time, and combined datetime formatting patterns per locale."""

    class PatternLength(models.TextChoices):
        FULL = "full", "Full"
        LONG = "long", "Long"
        MEDIUM = "medium", "Medium"
        SHORT = "short", "Short"

    locale = models.CharField(max_length=20, db_index=True)
    calendar = models.CharField(max_length=30, default="gregorian")
    length = models.CharField(max_length=10, choices=PatternLength)
    date_pattern = models.CharField(max_length=100, blank=True, default="")
    time_pattern = models.CharField(max_length=100, blank=True, default="")
    datetime_pattern = models.CharField(max_length=200, blank=True, default="")

    class Meta:
        unique_together = [("locale", "calendar", "length")]

    def __str__(self):
        return f"{self.locale} {self.calendar} {self.length}"


class MonthName(models.Model):
    """Localized month names in various widths and contexts."""

    class Context(models.TextChoices):
        FORMAT = "format", "Format"
        STANDALONE = "stand-alone", "Stand-alone"

    class Width(models.TextChoices):
        WIDE = "wide", "Wide"
        ABBREVIATED = "abbreviated", "Abbreviated"
        NARROW = "narrow", "Narrow"

    locale = models.CharField(max_length=20, db_index=True)
    calendar = models.CharField(max_length=30, default="gregorian")
    context = models.CharField(max_length=15, choices=Context)
    width = models.CharField(max_length=15, choices=Width)
    month = models.PositiveIntegerField()  # 1-13 (13 for lunisolar)
    name = models.CharField(max_length=50)

    class Meta:
        unique_together = [("locale", "calendar", "context", "width", "month")]

    def __str__(self):
        return f"{self.locale} month {self.month} ({self.width}): {self.name}"


class DayName(models.Model):
    """Localized day-of-week names in various widths and contexts."""

    class DayOfWeek(models.TextChoices):
        SUN = "sun", "Sunday"
        MON = "mon", "Monday"
        TUE = "tue", "Tuesday"
        WED = "wed", "Wednesday"
        THU = "thu", "Thursday"
        FRI = "fri", "Friday"
        SAT = "sat", "Saturday"

    locale = models.CharField(max_length=20, db_index=True)
    calendar = models.CharField(max_length=30, default="gregorian")
    context = models.CharField(max_length=15, choices=MonthName.Context)
    width = models.CharField(max_length=15, choices=MonthName.Width)
    day = models.CharField(max_length=3, choices=DayOfWeek)
    name = models.CharField(max_length=50)

    class Meta:
        unique_together = [("locale", "calendar", "context", "width", "day")]

    def __str__(self):
        return f"{self.locale} {self.day} ({self.width}): {self.name}"


class TimezoneName(models.Model):
    """Localized timezone display names."""

    class NameType(models.TextChoices):
        GENERIC_LONG = "generic_long", "Generic (long)"
        GENERIC_SHORT = "generic_short", "Generic (short)"
        STANDARD_LONG = "standard_long", "Standard (long)"
        STANDARD_SHORT = "standard_short", "Standard (short)"
        DAYLIGHT_LONG = "daylight_long", "Daylight (long)"
        DAYLIGHT_SHORT = "daylight_short", "Daylight (short)"
        CITY = "city", "Exemplar city"

    locale = models.CharField(max_length=20, db_index=True)
    zone_id = models.CharField(max_length=50, db_index=True)
    name_type = models.CharField(max_length=20, choices=NameType)
    name = models.CharField(max_length=100)

    class Meta:
        unique_together = [("locale", "zone_id", "name_type")]

    def __str__(self):
        return f"{self.locale} {self.zone_id} ({self.name_type}): {self.name}"
