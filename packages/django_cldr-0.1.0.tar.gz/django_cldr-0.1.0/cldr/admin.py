from django.contrib import admin

from . import models


@admin.register(models.Territory)
class TerritoryAdmin(admin.ModelAdmin):
    list_display = ["code", "territory_type", "alpha3", "numeric_code", "population"]
    list_filter = ["territory_type"]
    search_fields = ["code", "alpha3", "numeric_code"]


@admin.register(models.TerritoryContainment)
class TerritoryContainmentAdmin(admin.ModelAdmin):
    list_display = ["parent", "child", "group_type"]
    list_filter = ["group_type"]
    raw_id_fields = ["parent", "child"]


@admin.register(models.Language)
class LanguageAdmin(admin.ModelAdmin):
    list_display = ["code"]
    search_fields = ["code"]


@admin.register(models.Script)
class ScriptAdmin(admin.ModelAdmin):
    list_display = ["code"]
    search_fields = ["code"]


@admin.register(models.Currency)
class CurrencyAdmin(admin.ModelAdmin):
    list_display = ["code", "digits", "rounding", "is_tender"]
    list_filter = ["is_tender"]
    search_fields = ["code"]


@admin.register(models.LanguageTerritory)
class LanguageTerritoryAdmin(admin.ModelAdmin):
    list_display = ["language", "territory", "population_percent", "official_status"]
    list_filter = ["official_status"]
    raw_id_fields = ["language", "territory"]


@admin.register(models.LanguageScript)
class LanguageScriptAdmin(admin.ModelAdmin):
    list_display = ["language", "script", "is_primary"]
    list_filter = ["is_primary"]


@admin.register(models.TerritoryCurrency)
class TerritoryCurrencyAdmin(admin.ModelAdmin):
    list_display = ["territory", "currency", "from_date", "to_date", "is_tender"]
    raw_id_fields = ["territory", "currency"]


@admin.register(models.LikelySubtag)
class LikelySubtagAdmin(admin.ModelAdmin):
    list_display = ["from_tag", "to_tag"]
    search_fields = ["from_tag", "to_tag"]


@admin.register(models.WeekData)
class WeekDataAdmin(admin.ModelAdmin):
    list_display = ["territory", "first_day", "min_days", "weekend_start", "weekend_end"]


@admin.register(models.MeasurementSystem)
class MeasurementSystemAdmin(admin.ModelAdmin):
    list_display = ["territory", "system", "paper_size"]
    list_filter = ["system", "paper_size"]


@admin.register(models.NumberingSystem)
class NumberingSystemAdmin(admin.ModelAdmin):
    list_display = ["system_id", "system_type", "digits"]
    list_filter = ["system_type"]


@admin.register(models.CalendarPreference)
class CalendarPreferenceAdmin(admin.ModelAdmin):
    list_display = ["territory", "calendar_type", "ordering"]
    raw_id_fields = ["territory"]


@admin.register(models.PluralRule)
class PluralRuleAdmin(admin.ModelAdmin):
    list_display = ["locale", "rule_type", "category", "rule"]
    list_filter = ["rule_type", "category"]
    search_fields = ["locale"]


@admin.register(models.ParentLocale)
class ParentLocaleAdmin(admin.ModelAdmin):
    list_display = ["locale", "parent"]


@admin.register(models.Subdivision)
class SubdivisionAdmin(admin.ModelAdmin):
    list_display = ["code", "territory"]
    search_fields = ["code"]
    raw_id_fields = ["territory"]


@admin.register(models.LocalizedName)
class LocalizedNameAdmin(admin.ModelAdmin):
    list_display = ["entity_type", "entity_code", "locale", "name", "alt_type"]
    list_filter = ["entity_type", "locale"]
    search_fields = ["entity_code", "name"]


@admin.register(models.NumberSymbols)
class NumberSymbolsAdmin(admin.ModelAdmin):
    list_display = ["locale", "numbering_system", "decimal", "group"]
    search_fields = ["locale"]


@admin.register(models.NumberPattern)
class NumberPatternAdmin(admin.ModelAdmin):
    list_display = ["locale", "numbering_system", "pattern_type", "pattern"]
    list_filter = ["pattern_type"]
    search_fields = ["locale"]


@admin.register(models.CurrencyDisplayName)
class CurrencyDisplayNameAdmin(admin.ModelAdmin):
    list_display = ["currency", "locale", "count", "name", "symbol"]
    search_fields = ["currency__code", "name"]
    raw_id_fields = ["currency"]


@admin.register(models.DateTimePattern)
class DateTimePatternAdmin(admin.ModelAdmin):
    list_display = ["locale", "calendar", "length"]
    list_filter = ["calendar", "length"]
    search_fields = ["locale"]


@admin.register(models.MonthName)
class MonthNameAdmin(admin.ModelAdmin):
    list_display = ["locale", "calendar", "context", "width", "month", "name"]
    list_filter = ["calendar", "context", "width"]
    search_fields = ["locale"]


@admin.register(models.DayName)
class DayNameAdmin(admin.ModelAdmin):
    list_display = ["locale", "calendar", "context", "width", "day", "name"]
    list_filter = ["calendar", "context", "width"]
    search_fields = ["locale"]


@admin.register(models.TimezoneName)
class TimezoneNameAdmin(admin.ModelAdmin):
    list_display = ["locale", "zone_id", "name_type", "name"]
    list_filter = ["name_type"]
    search_fields = ["locale", "zone_id"]


@admin.register(models.CodeMapping)
class CodeMappingAdmin(admin.ModelAdmin):
    list_display = ["alpha2", "alpha3", "numeric", "fips"]
    search_fields = ["alpha2", "alpha3"]
