"""Import Unicode CLDR data from JSON packages.

Downloads JSON packages from the npm registry and imports data into
Django models. Follows the import pattern of django-cities.

Usage:
    python manage.py cldr_import                    # import all
    python manage.py cldr_import --import=core      # supplemental data only
    python manage.py cldr_import --import=names     # localized display names
    python manage.py cldr_import --import=numbers   # number formatting
    python manage.py cldr_import --import=dates     # date/time formatting
    python manage.py cldr_import --force            # re-download packages
"""

import io
import json
import os
import tarfile
from datetime import date

import requests
from django.core.management.base import BaseCommand
from django.db import transaction
from tqdm import tqdm

from cldr import conf
from cldr.models import (
    CalendarPreference,
    CodeMapping,
    Currency,
    CurrencyDisplayName,
    DateTimePattern,
    DayName,
    Language,
    LanguageScript,
    LanguageTerritory,
    LikelySubtag,
    LocalizedName,
    MeasurementSystem,
    MonthName,
    NumberingSystem,
    NumberPattern,
    NumberSymbols,
    ParentLocale,
    PluralRule,
    Script,
    Subdivision,
    Territory,
    TerritoryContainment,
    TerritoryCurrency,
    TimezoneName,
    WeekData,
)

USER_AGENT = "django-cldr/0.1.0"


class Command(BaseCommand):
    help = "Import Unicode CLDR data from JSON packages"

    def add_arguments(self, parser):
        parser.add_argument(
            "--import",
            dest="import_group",
            type=str,
            default="all",
            choices=conf.IMPORT_GROUPS.keys(),
            help="Data group to import (default: all)",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Re-download packages even if cached",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress progress output",
        )

    def handle(self, *args, **options):
        self.quiet = options["quiet"]
        self.force = options["force"]
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT})

        group = options["import_group"]
        packages = conf.IMPORT_GROUPS[group]

        for pkg_key in packages:
            self._ensure_package(pkg_key)

        if "core" in packages:
            self._import_core()
        if "localenames" in packages:
            self._import_localenames()
        if "numbers" in packages:
            self._import_numbers()
        if "dates" in packages:
            self._import_dates()
        if "subdivisions" in packages:
            self._import_subdivisions()

        self.stdout.write(self.style.SUCCESS("CLDR import complete."))

    # =========================================================================
    # Package download & extraction
    # =========================================================================

    def _ensure_package(self, pkg_key):
        """Download and extract an npm package if not already cached."""
        pkg_name = conf.PACKAGES[pkg_key]
        pkg_dir = os.path.join(conf.DATA_DIR, pkg_name)

        if os.path.isdir(pkg_dir) and not self.force:
            return

        url = f"{conf.NPM_REGISTRY}/{pkg_name}/-/{pkg_name}-{conf.VERSION}.tgz"
        self.stdout.write(f"Downloading {pkg_name} v{conf.VERSION}...")

        resp = self.session.get(url, stream=True, timeout=120)
        resp.raise_for_status()

        os.makedirs(conf.DATA_DIR, exist_ok=True)

        with tarfile.open(fileobj=io.BytesIO(resp.content), mode="r:gz") as tar:
            # npm tarballs have a "package/" prefix
            for member in tar.getmembers():
                if member.isfile():
                    # Strip "package/" prefix -> pkg_name/rest
                    rel = member.name.split("/", 1)[-1]
                    dest = os.path.join(pkg_dir, rel)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with tar.extractfile(member) as src:
                        with open(dest, "wb") as dst:
                            dst.write(src.read())

        self.stdout.write(f"  Extracted to {pkg_dir}")

    def _load_json(self, pkg_key, *path_parts):
        """Load a JSON file from an extracted package."""
        pkg_name = conf.PACKAGES[pkg_key]
        filepath = os.path.join(conf.DATA_DIR, pkg_name, *path_parts)
        with open(filepath, encoding="utf-8") as f:
            return json.load(f)

    def _get_locales(self, pkg_key):
        """List available locale directories in a package's main/ folder."""
        pkg_name = conf.PACKAGES[pkg_key]
        main_dir = os.path.join(conf.DATA_DIR, pkg_name, "main")
        if not os.path.isdir(main_dir):
            return []

        configured = conf.LOCALES
        available = sorted(os.listdir(main_dir))

        if configured == ["modern"] or configured == ["full"]:
            return available

        return [loc for loc in available if loc in configured]

    # =========================================================================
    # Core supplemental data
    # =========================================================================

    def _import_core(self):
        self.stdout.write(self.style.MIGRATE_HEADING("Importing core supplemental data"))

        with transaction.atomic():
            self._import_territories()
            self._import_territory_containment()
            self._import_code_mappings()
            self._import_currencies()
            self._import_territory_currencies()
            self._import_languages_and_scripts()
            self._import_language_territories()
            self._import_likely_subtags()
            self._import_week_data()
            self._import_measurement_data()
            self._import_numbering_systems()
            self._import_calendar_preferences()
            self._import_plural_rules()
            self._import_parent_locales()

    def _import_territories(self):
        data = self._load_json("core", "supplemental", "territoryInfo.json")
        info = data["supplemental"]["territoryInfo"]

        # Determine territory types from containment data
        containment_data = self._load_json(
            "core", "supplemental", "territoryContainment.json"
        )
        containment = containment_data["supplemental"]["territoryContainment"]

        # Build type map
        type_map = {}
        type_map["001"] = Territory.TerritoryType.WORLD

        continents = set()
        for parent_code, children_data in containment.items():
            if parent_code.startswith("_"):
                continue
            children = [
                c for c in children_data.get("_contains", [])
            ]
            if parent_code == "001":
                continents.update(children)

        subcontinents = set()
        for code in continents:
            type_map[code] = Territory.TerritoryType.CONTINENT
            if code in containment:
                children = containment[code].get("_contains", [])
                for child in children:
                    # If child itself contains more territories, it's a subcontinent
                    if child in containment and "_contains" in containment[child]:
                        subcontinents.add(child)

        for code in subcontinents:
            type_map[code] = Territory.TerritoryType.SUBCONTINENT

        # Non-geographic groupings
        group_data = containment.get("_grouping", {})
        if isinstance(group_data, dict):
            for code in group_data.get("_contains", []):
                if code not in type_map:
                    type_map[code] = Territory.TerritoryType.GROUPING

        count = 0
        for code, territory_data in tqdm(
            info.items(),
            disable=self.quiet,
            desc="Territories",
        ):
            if code.startswith("_"):
                continue

            territory_type = type_map.get(code, Territory.TerritoryType.COUNTRY)

            gdp = None
            literacy = None
            population = None
            if isinstance(territory_data, dict):
                gdp_str = territory_data.get("_gdp")
                if gdp_str:
                    gdp = int(float(gdp_str))
                lit_str = territory_data.get("_literacyPercent")
                if lit_str:
                    literacy = float(lit_str)
                pop_str = territory_data.get("_population")
                if pop_str:
                    population = int(float(pop_str))

            Territory.objects.update_or_create(
                code=code,
                defaults={
                    "territory_type": territory_type,
                    "gdp": gdp,
                    "literacy_percent": literacy,
                    "population": population,
                },
            )
            count += 1

        # Ensure parent territories from containment exist too
        all_codes = set()
        for parent_code, children_data in containment.items():
            if parent_code.startswith("_"):
                continue
            all_codes.add(parent_code)
            all_codes.update(children_data.get("_contains", []))

        for code in all_codes:
            if not Territory.objects.filter(code=code).exists():
                territory_type = type_map.get(code, Territory.TerritoryType.GROUPING)
                Territory.objects.create(code=code, territory_type=territory_type)
                count += 1

        self.stdout.write(f"  Territories: {count}")

    def _import_territory_containment(self):
        data = self._load_json(
            "core", "supplemental", "territoryContainment.json"
        )
        containment = data["supplemental"]["territoryContainment"]

        territory_cache = {t.code: t for t in Territory.objects.all()}

        TerritoryContainment.objects.all().delete()
        records = []

        for parent_code, children_data in containment.items():
            if parent_code.startswith("_"):
                # Handle top-level _grouping
                if parent_code == "_grouping":
                    continue
                continue

            parent = territory_cache.get(parent_code)
            if not parent:
                continue

            group_type = TerritoryContainment.GroupType.GEOGRAPHIC
            if "_grouping" in children_data:
                group_type = TerritoryContainment.GroupType.NON_GEOGRAPHIC
            if "_deprecated" in children_data:
                group_type = TerritoryContainment.GroupType.DEPRECATED

            for child_code in children_data.get("_contains", []):
                child = territory_cache.get(child_code)
                if child:
                    records.append(
                        TerritoryContainment(
                            parent=parent,
                            child=child,
                            group_type=group_type,
                        )
                    )

        TerritoryContainment.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Territory containment: {len(records)}")

    def _import_code_mappings(self):
        data = self._load_json("core", "supplemental", "codeMappings.json")
        mappings = data["supplemental"]["codeMappings"]

        CodeMapping.objects.all().delete()
        records = []

        territory_cache = {t.code: t for t in Territory.objects.all()}

        for code, mapping in tqdm(
            mappings.items(),
            disable=self.quiet,
            desc="Code mappings",
        ):
            if code.startswith("_"):
                continue

            alpha3 = mapping.get("_alpha3", "")
            numeric = mapping.get("_numeric", "")
            fips = mapping.get("_fips10", "")

            records.append(
                CodeMapping(
                    alpha2=code,
                    alpha3=alpha3,
                    numeric=numeric,
                    fips=fips,
                )
            )

            # Also update the Territory record
            territory = territory_cache.get(code)
            if territory:
                Territory.objects.filter(pk=territory.pk).update(
                    alpha3=alpha3,
                    numeric_code=numeric,
                    fips=fips,
                )

        CodeMapping.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Code mappings: {len(records)}")

    def _import_currencies(self):
        data = self._load_json("core", "supplemental", "currencyData.json")
        fractions = data["supplemental"]["currencyData"]["fractions"]

        # Default fractions
        default = fractions.get("DEFAULT", {})
        default_digits = int(default.get("_digits", 2))
        default_rounding = int(default.get("_rounding", 0))

        # Collect all currency codes from fractions + territory data
        currency_codes = set(fractions.keys()) - {"DEFAULT"}

        # Also collect from territory currency data
        region_data = data["supplemental"]["currencyData"].get("region", {})
        for _territory_code, currency_list in region_data.items():
            if not isinstance(currency_list, list):
                continue
            for entry in currency_list:
                for cur_code in entry:
                    if not cur_code.startswith("_"):
                        currency_codes.add(cur_code)

        count = 0
        for code in tqdm(
            sorted(currency_codes),
            disable=self.quiet,
            desc="Currencies",
        ):
            frac = fractions.get(code, {})
            digits = int(frac.get("_digits", default_digits))
            rounding = int(frac.get("_rounding", default_rounding))
            cash_digits = frac.get("_cashDigits")
            cash_rounding = frac.get("_cashRounding")
            is_tender = frac.get("_isTender", "true") != "false"

            Currency.objects.update_or_create(
                code=code,
                defaults={
                    "digits": digits,
                    "rounding": rounding,
                    "cash_digits": int(cash_digits) if cash_digits else None,
                    "cash_rounding": int(cash_rounding) if cash_rounding else None,
                    "is_tender": is_tender,
                },
            )
            count += 1

        self.stdout.write(f"  Currencies: {count}")

    def _import_territory_currencies(self):
        data = self._load_json("core", "supplemental", "currencyData.json")
        region_data = data["supplemental"]["currencyData"].get("region", {})

        territory_cache = {t.code: t for t in Territory.objects.all()}
        currency_cache = {c.code: c for c in Currency.objects.all()}

        TerritoryCurrency.objects.all().delete()
        records = []

        for territory_code, currency_list in tqdm(
            region_data.items(),
            disable=self.quiet,
            desc="Territory currencies",
        ):
            territory = territory_cache.get(territory_code)
            if not territory or not isinstance(currency_list, list):
                continue

            for entry in currency_list:
                for cur_code, cur_info in entry.items():
                    if cur_code.startswith("_"):
                        continue
                    currency = currency_cache.get(cur_code)
                    if not currency:
                        continue

                    from_date = None
                    to_date = None
                    if isinstance(cur_info, dict):
                        from_str = cur_info.get("_from")
                        to_str = cur_info.get("_to")
                        if from_str:
                            from_date = self._parse_date(from_str)
                        if to_str:
                            to_date = self._parse_date(to_str)
                        is_tender = cur_info.get("_tender", "true") != "false"
                    else:
                        is_tender = True

                    records.append(
                        TerritoryCurrency(
                            territory=territory,
                            currency=currency,
                            from_date=from_date,
                            to_date=to_date,
                            is_tender=is_tender,
                        )
                    )

        TerritoryCurrency.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Territory currencies: {len(records)}")

    def _import_languages_and_scripts(self):
        data = self._load_json("core", "supplemental", "languageData.json")
        lang_data = data["supplemental"]["languageData"]

        lang_count = 0
        script_count = 0
        ls_records = []

        script_cache = {}
        lang_cache = {}

        for lang_code, info in tqdm(
            lang_data.items(),
            disable=self.quiet,
            desc="Languages & scripts",
        ):
            if lang_code.startswith("_"):
                continue

            lang, _created = Language.objects.get_or_create(code=lang_code)
            lang_cache[lang_code] = lang
            if _created:
                lang_count += 1

            # Primary scripts
            for script_code in info.get("_scripts", []):
                if script_code not in script_cache:
                    script, created = Script.objects.get_or_create(code=script_code)
                    script_cache[script_code] = script
                    if created:
                        script_count += 1

                ls_records.append(
                    LanguageScript(
                        language=lang,
                        script=script_cache[script_code],
                        is_primary=True,
                    )
                )

            # Secondary scripts
            for script_code in info.get("_secondary", []):
                if script_code not in script_cache:
                    script, created = Script.objects.get_or_create(code=script_code)
                    script_cache[script_code] = script
                    if created:
                        script_count += 1

                ls_records.append(
                    LanguageScript(
                        language=lang,
                        script=script_cache[script_code],
                        is_primary=False,
                    )
                )

        LanguageScript.objects.all().delete()
        LanguageScript.objects.bulk_create(ls_records, batch_size=500)
        self.stdout.write(
            f"  Languages: {lang_count}, Scripts: {script_count}, "
            f"Associations: {len(ls_records)}"
        )

    def _import_language_territories(self):
        data = self._load_json("core", "supplemental", "territoryInfo.json")
        info = data["supplemental"]["territoryInfo"]

        territory_cache = {t.code: t for t in Territory.objects.all()}
        lang_cache = {lg.code: lg for lg in Language.objects.all()}

        LanguageTerritory.objects.all().delete()
        records = []

        for territory_code, territory_data in info.items():
            if territory_code.startswith("_") or not isinstance(territory_data, dict):
                continue

            territory = territory_cache.get(territory_code)
            if not territory:
                continue

            lang_pop = territory_data.get("_languagePopulation", {})
            if not isinstance(lang_pop, dict):
                continue

            for lang_code, lang_info in lang_pop.items():
                if lang_code.startswith("_"):
                    continue

                if lang_code not in lang_cache:
                    lang, _ = Language.objects.get_or_create(code=lang_code)
                    lang_cache[lang_code] = lang

                pop_pct = None
                literacy = None
                official = ""

                if isinstance(lang_info, dict):
                    pop_str = lang_info.get("_populationPercent")
                    if pop_str:
                        pop_pct = float(pop_str)
                    lit_str = lang_info.get("_literacyPercent")
                    if lit_str:
                        literacy = float(lit_str)
                    official = lang_info.get("_officialStatus", "")

                records.append(
                    LanguageTerritory(
                        language=lang_cache[lang_code],
                        territory=territory,
                        population_percent=pop_pct,
                        official_status=official,
                        literacy_percent=literacy,
                    )
                )

        LanguageTerritory.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Language-territory associations: {len(records)}")

    def _import_likely_subtags(self):
        data = self._load_json("core", "supplemental", "likelySubtags.json")
        subtags = data["supplemental"]["likelySubtags"]

        LikelySubtag.objects.all().delete()
        records = [
            LikelySubtag(from_tag=k, to_tag=v)
            for k, v in subtags.items()
            if not k.startswith("_")
        ]
        LikelySubtag.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Likely subtags: {len(records)}")

    def _import_week_data(self):
        data = self._load_json("core", "supplemental", "weekData.json")
        week = data["supplemental"]["weekData"]

        territory_cache = {t.code: t for t in Territory.objects.all()}

        first_day_map = week.get("firstDay", {})
        min_days_map = week.get("minDays", {})
        weekend_start_map = week.get("weekendStart", {})
        weekend_end_map = week.get("weekendEnd", {})

        # Collect all territory codes mentioned
        all_codes = set()
        for mapping in [first_day_map, min_days_map, weekend_start_map, weekend_end_map]:
            all_codes.update(mapping.keys())

        WeekData.objects.all().delete()
        records = []

        for code in all_codes:
            if code.startswith("_"):
                continue
            territory = territory_cache.get(code)
            if not territory:
                continue

            # Use territory-specific value or fall back to "001" (world default)
            first_day = first_day_map.get(code, first_day_map.get("001", "mon"))
            min_days = int(min_days_map.get(code, min_days_map.get("001", "1")))
            weekend_start = weekend_start_map.get(
                code, weekend_start_map.get("001", "sat")
            )
            weekend_end = weekend_end_map.get(
                code, weekend_end_map.get("001", "sun")
            )

            records.append(
                WeekData(
                    territory=territory,
                    first_day=first_day,
                    min_days=min_days,
                    weekend_start=weekend_start,
                    weekend_end=weekend_end,
                )
            )

        WeekData.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Week data: {len(records)}")

    def _import_measurement_data(self):
        data = self._load_json("core", "supplemental", "measurementData.json")
        mdata = data["supplemental"]["measurementData"]

        territory_cache = {t.code: t for t in Territory.objects.all()}

        system_map = mdata.get("measurementSystem", {})
        paper_map = mdata.get("paperSize", {})

        all_codes = set(system_map.keys()) | set(paper_map.keys())

        MeasurementSystem.objects.all().delete()
        records = []

        for code in all_codes:
            if code.startswith("_"):
                continue
            territory = territory_cache.get(code)
            if not territory:
                continue

            system = system_map.get(code, system_map.get("001", "metric"))
            paper = paper_map.get(code, paper_map.get("001", "A4"))

            records.append(
                MeasurementSystem(
                    territory=territory,
                    system=system,
                    paper_size=paper,
                )
            )

        MeasurementSystem.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Measurement systems: {len(records)}")

    def _import_numbering_systems(self):
        data = self._load_json("core", "supplemental", "numberingSystems.json")
        systems = data["supplemental"]["numberingSystems"]

        NumberingSystem.objects.all().delete()
        records = []

        for sys_id, info in systems.items():
            if sys_id.startswith("_"):
                continue

            sys_type = info.get("_type", "numeric")
            digits = info.get("_digits", "")
            rules = info.get("_rules", "")

            records.append(
                NumberingSystem(
                    system_id=sys_id,
                    system_type=sys_type,
                    digits=digits,
                    rules=rules,
                )
            )

        NumberingSystem.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Numbering systems: {len(records)}")

    def _import_calendar_preferences(self):
        data = self._load_json(
            "core", "supplemental", "calendarPreferenceData.json"
        )
        prefs = data["supplemental"]["calendarPreferenceData"]

        territory_cache = {t.code: t for t in Territory.objects.all()}

        CalendarPreference.objects.all().delete()
        records = []

        for code, cal_str in prefs.items():
            if code.startswith("_"):
                continue
            territory = territory_cache.get(code)
            if not territory:
                continue

            calendars = cal_str.split(" ") if isinstance(cal_str, str) else [cal_str]
            for idx, cal_type in enumerate(calendars):
                records.append(
                    CalendarPreference(
                        territory=territory,
                        calendar_type=cal_type,
                        ordering=idx,
                    )
                )

        CalendarPreference.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Calendar preferences: {len(records)}")

    def _import_plural_rules(self):
        PluralRule.objects.all().delete()
        records = []

        for rule_type, filename in [
            ("cardinal", "plurals.json"),
            ("ordinal", "ordinals.json"),
        ]:
            data = self._load_json("core", "supplemental", filename)
            key = "plurals-type-cardinal" if rule_type == "cardinal" else "plurals-type-ordinal"
            rules = data["supplemental"][key]

            for locale, categories in rules.items():
                if locale.startswith("_"):
                    continue

                for cat_key, rule_data in categories.items():
                    # cat_key is like "pluralRule-count-one"
                    category = cat_key.rsplit("-", 1)[-1]

                    if isinstance(rule_data, dict):
                        rule_text = rule_data.get("_value", "")
                        examples = rule_data.get("_examples", "")
                    else:
                        rule_text = str(rule_data)
                        examples = ""

                    records.append(
                        PluralRule(
                            locale=locale,
                            rule_type=rule_type,
                            category=category,
                            rule=rule_text,
                            examples=examples,
                        )
                    )

        PluralRule.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Plural rules: {len(records)}")

    def _import_parent_locales(self):
        data = self._load_json("core", "supplemental", "parentLocales.json")
        parents = data["supplemental"]["parentLocales"]["parentLocale"]

        ParentLocale.objects.all().delete()
        records = [
            ParentLocale(locale=k, parent=v)
            for k, v in parents.items()
            if not k.startswith("_")
        ]
        ParentLocale.objects.bulk_create(records, batch_size=500)
        self.stdout.write(f"  Parent locales: {len(records)}")

    # =========================================================================
    # Localized display names
    # =========================================================================

    def _import_localenames(self):
        self.stdout.write(self.style.MIGRATE_HEADING("Importing localized names"))
        locales = self._get_locales("localenames")

        if not locales:
            self.stdout.write("  No locales configured. Set CLDR_LOCALES.")
            return

        LocalizedName.objects.all().delete()

        for locale in tqdm(locales, disable=self.quiet, desc="Locale names"):
            self._import_locale_names(locale)

        total = LocalizedName.objects.count()
        self.stdout.write(f"  Localized names: {total:,} ({len(locales)} locales)")

    def _import_locale_names(self, locale):
        records = []

        # Territory names
        try:
            data = self._load_json(
                "localenames", "main", locale, "territories.json"
            )
            territories = data["main"][locale]["localeDisplayNames"]["territories"]
            for code, name in territories.items():
                alt_type = ""
                if "-alt-" in code:
                    code, alt_type = code.split("-alt-", 1)
                records.append(
                    LocalizedName(
                        entity_type=LocalizedName.EntityType.TERRITORY,
                        entity_code=code,
                        locale=locale,
                        name=name,
                        alt_type=alt_type,
                    )
                )
        except (FileNotFoundError, KeyError):
            pass

        # Language names
        try:
            data = self._load_json(
                "localenames", "main", locale, "languages.json"
            )
            languages = data["main"][locale]["localeDisplayNames"]["languages"]
            for code, name in languages.items():
                alt_type = ""
                if "-alt-" in code:
                    code, alt_type = code.split("-alt-", 1)
                records.append(
                    LocalizedName(
                        entity_type=LocalizedName.EntityType.LANGUAGE,
                        entity_code=code,
                        locale=locale,
                        name=name,
                        alt_type=alt_type,
                    )
                )
        except (FileNotFoundError, KeyError):
            pass

        # Script names
        try:
            data = self._load_json(
                "localenames", "main", locale, "scripts.json"
            )
            scripts = data["main"][locale]["localeDisplayNames"]["scripts"]
            for code, name in scripts.items():
                alt_type = ""
                if "-alt-" in code:
                    code, alt_type = code.split("-alt-", 1)
                records.append(
                    LocalizedName(
                        entity_type=LocalizedName.EntityType.SCRIPT,
                        entity_code=code,
                        locale=locale,
                        name=name,
                        alt_type=alt_type,
                    )
                )
        except (FileNotFoundError, KeyError):
            pass

        if records:
            LocalizedName.objects.bulk_create(records, batch_size=1000)

    # =========================================================================
    # Number formatting
    # =========================================================================

    def _import_numbers(self):
        self.stdout.write(self.style.MIGRATE_HEADING("Importing number formatting"))
        locales = self._get_locales("numbers")

        if not locales:
            self.stdout.write("  No locales configured. Set CLDR_LOCALES.")
            return

        NumberSymbols.objects.all().delete()
        NumberPattern.objects.all().delete()
        CurrencyDisplayName.objects.all().delete()

        currency_cache = {c.code: c for c in Currency.objects.all()}

        for locale in tqdm(locales, disable=self.quiet, desc="Number data"):
            self._import_locale_numbers(locale, currency_cache)

        self.stdout.write(
            f"  Number symbols: {NumberSymbols.objects.count()}, "
            f"Patterns: {NumberPattern.objects.count()}, "
            f"Currency names: {CurrencyDisplayName.objects.count():,}"
        )

    def _import_locale_numbers(self, locale, currency_cache):
        try:
            data = self._load_json("numbers", "main", locale, "numbers.json")
        except FileNotFoundError:
            return

        numbers = data["main"][locale]["numbers"]

        # Find the default numbering system
        default_ns = numbers.get("defaultNumberingSystem", "latn")

        # Number symbols
        symbols_key = f"symbols-numberSystem-{default_ns}"
        if symbols_key in numbers:
            sym = numbers[symbols_key]
            NumberSymbols.objects.create(
                locale=locale,
                numbering_system=default_ns,
                decimal=sym.get("decimal", "."),
                group=sym.get("group", ","),
                percent_sign=sym.get("percentSign", "%"),
                minus_sign=sym.get("minusSign", "-"),
                plus_sign=sym.get("plusSign", "+"),
                exponential=sym.get("exponential", "E"),
                superscripting_exponent=sym.get("superscriptingExponent", "x"),
                infinity=sym.get("infinity", "\u221e"),
                nan=sym.get("nan", "NaN"),
                time_separator=sym.get("timeSeparator", ":"),
            )

        # Number patterns
        pattern_records = []
        pattern_map = {
            f"decimalFormats-numberSystem-{default_ns}": "decimal",
            f"percentFormats-numberSystem-{default_ns}": "percent",
            f"scientificFormats-numberSystem-{default_ns}": "scientific",
            f"currencyFormats-numberSystem-{default_ns}": "currency",
        }

        for json_key, pattern_type in pattern_map.items():
            formats = numbers.get(json_key, {})
            if isinstance(formats, dict):
                pattern = formats.get("standard", "")
                if isinstance(pattern, str) and pattern:
                    pattern_records.append(
                        NumberPattern(
                            locale=locale,
                            numbering_system=default_ns,
                            pattern_type=pattern_type,
                            pattern=pattern,
                        )
                    )
                # Accounting pattern for currency
                if pattern_type == "currency":
                    acct = formats.get("accounting", "")
                    if isinstance(acct, str) and acct:
                        pattern_records.append(
                            NumberPattern(
                                locale=locale,
                                numbering_system=default_ns,
                                pattern_type="currency_accounting",
                                pattern=acct,
                            )
                        )

        if pattern_records:
            NumberPattern.objects.bulk_create(pattern_records, batch_size=500)

        # Currency display names
        try:
            cur_data = self._load_json("numbers", "main", locale, "currencies.json")
            currencies = cur_data["main"][locale]["numbers"]["currencies"]

            cur_records = []
            for cur_code, cur_info in currencies.items():
                currency = currency_cache.get(cur_code)
                if not currency or not isinstance(cur_info, dict):
                    continue

                symbol = cur_info.get("symbol", "")
                narrow = cur_info.get("symbol-alt-narrow", "")
                display_name = cur_info.get("displayName", "")

                if display_name:
                    cur_records.append(
                        CurrencyDisplayName(
                            currency=currency,
                            locale=locale,
                            count="",
                            name=display_name,
                            symbol=symbol,
                            narrow_symbol=narrow,
                        )
                    )

                # Plural forms
                for count in ["zero", "one", "two", "few", "many", "other"]:
                    plural_key = f"displayName-count-{count}"
                    if plural_key in cur_info:
                        cur_records.append(
                            CurrencyDisplayName(
                                currency=currency,
                                locale=locale,
                                count=count,
                                name=cur_info[plural_key],
                                symbol=symbol,
                                narrow_symbol=narrow,
                            )
                        )

            if cur_records:
                CurrencyDisplayName.objects.bulk_create(
                    cur_records, batch_size=1000
                )
        except (FileNotFoundError, KeyError):
            pass

    # =========================================================================
    # Date/time formatting
    # =========================================================================

    def _import_dates(self):
        self.stdout.write(self.style.MIGRATE_HEADING("Importing date/time formatting"))
        locales = self._get_locales("dates")

        if not locales:
            self.stdout.write("  No locales configured. Set CLDR_LOCALES.")
            return

        DateTimePattern.objects.all().delete()
        MonthName.objects.all().delete()
        DayName.objects.all().delete()
        TimezoneName.objects.all().delete()

        for locale in tqdm(locales, disable=self.quiet, desc="Date data"):
            self._import_locale_dates(locale)

        self.stdout.write(
            f"  Date patterns: {DateTimePattern.objects.count()}, "
            f"Month names: {MonthName.objects.count():,}, "
            f"Day names: {DayName.objects.count():,}, "
            f"Timezone names: {TimezoneName.objects.count():,}"
        )

    def _import_locale_dates(self, locale):
        # Gregorian calendar data
        try:
            data = self._load_json("dates", "main", locale, "ca-gregorian.json")
        except FileNotFoundError:
            return

        cal = data["main"][locale]["dates"]["calendars"]["gregorian"]
        calendar = "gregorian"

        # Date/time patterns
        dt_records = []
        for length in ["full", "long", "medium", "short"]:
            date_pat = cal.get("dateFormats", {}).get(length, "")
            time_pat = cal.get("timeFormats", {}).get(length, "")
            datetime_pat = cal.get("dateTimeFormats", {}).get(length, "")

            if isinstance(date_pat, dict):
                date_pat = date_pat.get("_value", "")
            if isinstance(time_pat, dict):
                time_pat = time_pat.get("_value", "")
            if isinstance(datetime_pat, dict):
                datetime_pat = datetime_pat.get("_value", "")

            dt_records.append(
                DateTimePattern(
                    locale=locale,
                    calendar=calendar,
                    length=length,
                    date_pattern=date_pat or "",
                    time_pattern=time_pat or "",
                    datetime_pattern=datetime_pat or "",
                )
            )

        if dt_records:
            DateTimePattern.objects.bulk_create(dt_records, batch_size=500)

        # Month names
        month_records = []
        for context in ["format", "stand-alone"]:
            months_data = cal.get("months", {}).get(context, {})
            for width in ["wide", "abbreviated", "narrow"]:
                width_data = months_data.get(width, {})
                for month_num, name in width_data.items():
                    try:
                        month_int = int(month_num)
                    except ValueError:
                        continue
                    month_records.append(
                        MonthName(
                            locale=locale,
                            calendar=calendar,
                            context=context,
                            width=width,
                            month=month_int,
                            name=name,
                        )
                    )

        if month_records:
            MonthName.objects.bulk_create(month_records, batch_size=500)

        # Day names
        day_records = []
        for context in ["format", "stand-alone"]:
            days_data = cal.get("days", {}).get(context, {})
            for width in ["wide", "abbreviated", "narrow"]:
                width_data = days_data.get(width, {})
                for day_key, name in width_data.items():
                    day_records.append(
                        DayName(
                            locale=locale,
                            calendar=calendar,
                            context=context,
                            width=width,
                            day=day_key[:3],
                            name=name,
                        )
                    )

        if day_records:
            DayName.objects.bulk_create(day_records, batch_size=500)

        # Timezone names
        try:
            tz_data = self._load_json("dates", "main", locale, "timeZoneNames.json")
            tz_names = tz_data["main"][locale]["dates"]["timeZoneNames"]

            tz_records = []
            zone_data = tz_names.get("zone", {})
            for region, zones in zone_data.items():
                self._extract_tz_names(locale, region, zones, tz_records)

            if tz_records:
                TimezoneName.objects.bulk_create(tz_records, batch_size=1000)
        except (FileNotFoundError, KeyError):
            pass

    def _extract_tz_names(self, locale, prefix, data, records):
        """Recursively extract timezone names from nested zone data."""
        if not isinstance(data, dict):
            return

        for key, value in data.items():
            zone_id = f"{prefix}/{key}"

            if isinstance(value, dict):
                # Check if this has timezone name fields
                if "exemplarCity" in value:
                    records.append(
                        TimezoneName(
                            locale=locale,
                            zone_id=zone_id,
                            name_type=TimezoneName.NameType.CITY,
                            name=value["exemplarCity"],
                        )
                    )

                for tz_type, name_type in [
                    ("generic", TimezoneName.NameType.GENERIC_LONG),
                    ("standard", TimezoneName.NameType.STANDARD_LONG),
                    ("daylight", TimezoneName.NameType.DAYLIGHT_LONG),
                ]:
                    if tz_type in value:
                        records.append(
                            TimezoneName(
                                locale=locale,
                                zone_id=zone_id,
                                name_type=name_type,
                                name=value[tz_type],
                            )
                        )

                # Check for short forms
                short = value.get("short", {})
                for tz_type, name_type in [
                    ("generic", TimezoneName.NameType.GENERIC_SHORT),
                    ("standard", TimezoneName.NameType.STANDARD_SHORT),
                    ("daylight", TimezoneName.NameType.DAYLIGHT_SHORT),
                ]:
                    if tz_type in short:
                        records.append(
                            TimezoneName(
                                locale=locale,
                                zone_id=zone_id,
                                name_type=name_type,
                                name=short[tz_type],
                            )
                        )

                # Recurse for nested zones
                if "exemplarCity" not in value and not any(
                    k in value
                    for k in ["generic", "standard", "daylight", "short"]
                ):
                    self._extract_tz_names(locale, zone_id, value, records)

    # =========================================================================
    # Subdivisions
    # =========================================================================

    def _import_subdivisions(self):
        self.stdout.write(self.style.MIGRATE_HEADING("Importing subdivisions"))
        locales = self._get_locales("subdivisions")

        if not locales:
            self.stdout.write("  No locales configured. Set CLDR_LOCALES.")
            return

        territory_cache = {t.code: t for t in Territory.objects.all()}

        # Create Subdivision records from the first locale's data
        first_locale = locales[0]
        try:
            data = self._load_json(
                "subdivisions", "main", first_locale, "subdivisions.json"
            )
            subdivisions = data["main"][first_locale]["localeDisplayNames"]["subdivisions"]

            Subdivision.objects.all().delete()
            records = []
            for code, _name in subdivisions.items():
                if code.startswith("_") or "-alt-" in code:
                    continue
                # Territory code is the first 2 chars
                territory_code = code[:2].upper()
                territory = territory_cache.get(territory_code)
                if territory:
                    records.append(
                        Subdivision(code=code, territory=territory)
                    )

            Subdivision.objects.bulk_create(records, batch_size=500)
            self.stdout.write(f"  Subdivisions: {len(records)}")
        except (FileNotFoundError, KeyError):
            self.stdout.write("  No subdivision data found")
            return

        # Import localized subdivision names
        for locale in tqdm(locales, disable=self.quiet, desc="Subdivision names"):
            try:
                data = self._load_json(
                    "subdivisions", "main", locale, "subdivisions.json"
                )
                subdivisions = data["main"][locale]["localeDisplayNames"]["subdivisions"]

                records = []
                for code, name in subdivisions.items():
                    alt_type = ""
                    if "-alt-" in code:
                        code, alt_type = code.split("-alt-", 1)
                    records.append(
                        LocalizedName(
                            entity_type=LocalizedName.EntityType.SUBDIVISION,
                            entity_code=code,
                            locale=locale,
                            name=name,
                            alt_type=alt_type,
                        )
                    )

                if records:
                    LocalizedName.objects.bulk_create(records, batch_size=1000)
            except (FileNotFoundError, KeyError):
                pass

        sub_names = LocalizedName.objects.filter(
            entity_type=LocalizedName.EntityType.SUBDIVISION
        ).count()
        self.stdout.write(f"  Subdivision names: {sub_names:,}")

    # =========================================================================
    # Utilities
    # =========================================================================

    @staticmethod
    def _parse_date(date_str):
        """Parse a CLDR date string like '1999-01-01' or '1999'."""
        parts = date_str.split("-")
        try:
            year = int(parts[0])
            month = int(parts[1]) if len(parts) > 1 else 1
            day = int(parts[2]) if len(parts) > 2 else 1  # noqa: PLR2004
            return date(year, month, day)
        except (ValueError, IndexError):
            return None
