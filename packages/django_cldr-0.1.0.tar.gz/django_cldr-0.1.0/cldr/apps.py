from django.apps import AppConfig


class CldrConfig(AppConfig):
    name = "cldr"
    default_auto_field = "django.db.models.BigAutoField"
    verbose_name = "Unicode CLDR"
