"""CLDR package configuration and settings."""

import os

from django.conf import settings

# CLDR version to download
VERSION = getattr(settings, "CLDR_VERSION", "46.0.0")

# Locales to import for localized name/formatting data.
# Use ["modern"] for ~80 most-used locales, or list specific codes.
LOCALES = getattr(settings, "CLDR_LOCALES", ["en"])

# Directory to cache downloaded CLDR JSON files
DATA_DIR = getattr(
    settings,
    "CLDR_DATA_DIR",
    os.path.join(settings.BASE_DIR, "data", "cldr"),
)

# npm registry base for downloading package tarballs
NPM_REGISTRY = "https://registry.npmjs.org"

# Packages and their npm names
PACKAGES = {
    "core": "cldr-core",
    "localenames": "cldr-localenames-full",
    "numbers": "cldr-numbers-full",
    "dates": "cldr-dates-full",
    "subdivisions": "cldr-subdivisions-full",
    "units": "cldr-units-full",
}

# Which import groups map to which packages
IMPORT_GROUPS = {
    "core": ["core"],
    "names": ["localenames"],
    "numbers": ["numbers"],
    "dates": ["dates"],
    "subdivisions": ["subdivisions"],
    "units": ["units"],
    "all": list(PACKAGES.keys()),
}
