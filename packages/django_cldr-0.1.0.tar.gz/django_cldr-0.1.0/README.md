# django-cldr

A Django application for importing and managing [Unicode CLDR](https://cldr.unicode.org/) (Common Locale Data Repository) data.

Provides models for territories, languages, scripts, currencies, subdivisions, and their localized names, plus number and date/time formatting patterns across hundreds of locales.

## Features

- **Territories**: ISO 3166-1 countries and UN M.49 regions with GDP, literacy, and population data
- **Languages & Scripts**: BCP47 language codes and ISO 15924 script codes with usage data
- **Currencies**: ISO 4217 currency codes with formatting rules and historical territory usage
- **Subdivisions**: Administrative subdivisions (states, provinces, etc.)
- **Localized Names**: Translated names for territories, languages, scripts, currencies, and subdivisions across 700+ locales
- **Number Formatting**: Locale-specific number symbols and patterns (decimal, percent, currency, scientific)
- **Date/Time Formatting**: Locale-specific date, time, and datetime patterns with localized month, day, and timezone names
- **Supplemental Data**: Week preferences, measurement systems, numbering systems, calendar preferences, plural rules, and more

## Requirements

- Python 3.10+
- Django 4.2+
- PostgreSQL (recommended)

## Installation

```bash
pip install django-cldr
```

Add to your `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    'cldr',
]
```

Run migrations:

```bash
python manage.py migrate cldr
```

## Quick Start

Import CLDR data:

```bash
# Import core data (territories, languages, currencies, etc.)
python manage.py cldr_import --import=core

# Import localized names
python manage.py cldr_import --import=names

# Import number formatting data
python manage.py cldr_import --import=numbers

# Import date/time formatting data
python manage.py cldr_import --import=dates

# Import subdivisions
python manage.py cldr_import --import=subdivisions

# Import everything
python manage.py cldr_import --import=all
```

## Configuration

Optional settings in `settings.py`:

```python
# CLDR version to download (default: 46.0.0)
CLDR_VERSION = '46.0.0'

# Locales to import for localized data
# Use a list of locale codes, or "modern" for ~80 most-used locales
CLDR_LOCALES = ['en']  # default

# Cache directory for downloaded CLDR JSON files
CLDR_DATA_DIR = '/path/to/cldr/data'
```

## Usage Examples

```python
from cldr.models import Territory, Language, Currency, LocalizedName

# Get a territory
usa = Territory.objects.get(code='US')

# Get languages spoken in a territory
from cldr.models import LanguageTerritory
languages = LanguageTerritory.objects.filter(territory=usa)

# Get localized territory name
localized = LocalizedName.objects.get(
    territory__code='JP',
    locale='fr',
)
print(localized.name)  # "Japon"

# Get number formatting symbols for a locale
from cldr.models import NumberSymbols
symbols = NumberSymbols.objects.get(locale='de')
print(symbols.decimal)  # ","
print(symbols.group)    # "."

# Get currency display names
from cldr.models import CurrencyDisplayName
names = CurrencyDisplayName.objects.filter(
    currency__code='EUR',
    locale='en',
)
```

## Models

### Core Supplemental Data
- **Territory** - Countries and regions with metadata
- **Language** - BCP47 language codes
- **Script** - ISO 15924 writing system codes
- **Currency** - ISO 4217 currency codes
- **LanguageTerritory** - Languages spoken per territory
- **TerritoryCurrency** - Historical currency usage per territory
- **TerritoryContainment** - Parent-child territory relationships
- **CodeMapping** - Maps between alpha-2, alpha-3, numeric, and FIPS codes
- **WeekData** - Week preferences per territory
- **MeasurementSystem** - Measurement and paper size preferences
- **NumberingSystem** - Numbering systems (Latin, Arabic-Indic, etc.)
- **LikelySubtag** - Locale inference rules
- **PluralRule** - Cardinal and ordinal plural rules
- **CalendarPreference** - Preferred calendar types

### Subdivisions
- **Subdivision** - Administrative subdivisions

### Localized Data
- **LocalizedName** - Translated names across locales
- **NumberSymbols** - Number formatting symbols per locale
- **NumberPattern** - Number formatting patterns (ICU syntax)
- **CurrencyDisplayName** - Localized currency names with plural forms
- **DateTimePattern** - Date/time formatting patterns per locale
- **MonthName** - Localized month names
- **DayName** - Localized day-of-week names
- **TimezoneName** - Localized timezone display names

## Data Source

Data is sourced from the [Unicode CLDR](https://cldr.unicode.org/) project via npm packages published by the Unicode Consortium. The CLDR data is licensed under the [Unicode License](https://www.unicode.org/license.txt).

## Disclaimer

This project is not affiliated with, endorsed by, or associated with the [Unicode Consortium](https://unicode.org/) or the [CLDR](https://cldr.unicode.org/) project. It is an independent, third-party Django integration that consumes publicly available CLDR data.

## License

MIT License - see [LICENSE](LICENSE) for details.
