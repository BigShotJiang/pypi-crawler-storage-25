"""Anthropic provider adapter package."""
