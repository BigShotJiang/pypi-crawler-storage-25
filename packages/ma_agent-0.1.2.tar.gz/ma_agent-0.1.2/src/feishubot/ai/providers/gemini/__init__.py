"""Gemini provider adapter package."""
