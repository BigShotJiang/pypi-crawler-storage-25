from __future__ import annotations

import argparse
import asyncio
import importlib.resources
import json
import tomllib
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from feishubot.ai.memory import SessionManager
from feishubot.ai.orchestrator.agent_loop import AgentLoop
from feishubot.ai.prompts import build_system_prompt
from feishubot.ai.providers import create_active_provider
from feishubot.ai.tools import ToolRuntime
from feishubot.config import settings

LLM_PRESETS: dict[str, dict[str, str]] = {
    "qwen": {
        "label": "Qwen (DashScope)",
        "base_url": "https://dashscope.aliyuncs.com",
        "model": "qwen-plus",
        "chat_path": "/compatible-mode/v1/chat/completions",
    },
    "kimi": {
        "label": "Kimi (Moonshot)",
        "base_url": "https://api.moonshot.cn",
        "model": "moonshot-v1-8k",
        "chat_path": "/v1/chat/completions",
    },
    "deepseek": {
        "label": "DeepSeek",
        "base_url": "https://api.deepseek.com",
        "model": "deepseek-chat",
        "chat_path": "/v1/chat/completions",
    },
    "glm": {
        "label": "GLM-4",
        "base_url": "https://open.bigmodel.cn/api/paas/v4/",
        "model": "glm-4",
        "chat_path": "/chat/completions",
    },
}


_DEFAULT_ENV_FILE = "~/.feishubot/.env"
_DEFAULT_TOOLS_CONFIG = "tools.toml"
_FALLBACK_TOOLS_TOML = """# `soul_memory` is enabled by default to persist stable user profile facts
# (name, habits, hobbies, preferences) into SOUL.md for better continuity.
enabled_tools = [\"web_search\", \"calculator\", \"terminal\", \"soul_memory\"]

[routing.web_search]
timeout_seconds = 20

[routing.calculator]
timeout_seconds = 5

[routing.terminal]
timeout_seconds = 30

[routing.soul_memory]
timeout_seconds = 5

[terminal]
blocked_commands = [
    \"rm -rf /\",
    \"shutdown\",
    \"reboot\"
]
"""


def _add_chat_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--user-id", default="terminal-user", help="User ID passed to the LLM backend"
    )
    parser.add_argument(
        "--system-prompt",
        default=None,
        help="Optional system prompt (only works with openai_compatible provider)",
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="FeishuBot command line")
    subparsers = parser.add_subparsers(dest="command")

    chat_parser = subparsers.add_parser("chat", help="Start terminal chat loop")
    _add_chat_arguments(chat_parser)

    gateway_parser = subparsers.add_parser("gateway", help="Start HTTP gateway service")
    gateway_parser.add_argument(
        "--host",
        default="0.0.0.0",  # noqa: S104 - intentional default for dev/container access
        help="Gateway bind host",
    )
    gateway_parser.add_argument("--port", type=int, default=8000, help="Gateway bind port")
    gateway_parser.add_argument(
        "--reload", action="store_true", help="Enable auto-reload for development"
    )

    events_parser = subparsers.add_parser(
        "events", help="Start Feishu long-connection event receiver"
    )
    events_parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],
        help="Log level for lark-oapi websocket client",
    )
    events_parser.add_argument(
        "--no-fallback-webhook",
        action="store_true",
        help="Disable fallback to webhook gateway when long connection is unavailable",
    )
    events_parser.add_argument(
        "--fallback-host",
        default="0.0.0.0",  # noqa: S104 - intentional default for dev/container access
        help="Fallback webhook gateway bind host",
    )
    events_parser.add_argument(
        "--fallback-port", type=int, default=8000, help="Fallback webhook gateway bind port"
    )
    events_parser.add_argument(
        "--fallback-reload",
        action="store_true",
        help="Enable auto-reload when fallback webhook gateway starts",
    )

    setup_parser = subparsers.add_parser("setup", help="Interactive quick setup for .env")
    setup_parser.add_argument(
        "--env-file",
        default=_DEFAULT_ENV_FILE,
        help="Path to the environment file to create/update",
    )
    setup_parser.add_argument(
        "--yes", action="store_true", help="Skip overwrite confirmation if env file exists"
    )

    model_parser = subparsers.add_parser(
        "model", help="List configured models and switch active model"
    )
    model_parser.add_argument(
        "--env-file",
        default=_DEFAULT_ENV_FILE,
        help="Path to the environment file to update",
    )
    model_parser.add_argument(
        "--use",
        default=None,
        help="Switch directly to a model name without interactive prompt",
    )

    session_parser = subparsers.add_parser("session", help="Manage sessions")
    session_subparsers = session_parser.add_subparsers(dest="session_command")

    # List sessions
    session_subparsers.add_parser("list", help="List all sessions")

    # Cleanup expired sessions
    cleanup_parser = session_subparsers.add_parser("cleanup", help="Clean up expired sessions")
    cleanup_parser.add_argument(
        "--days", type=int, default=30, help="Days after which a session is considered expired"
    )

    # Cleanup all sessions
    session_subparsers.add_parser("cleanup-all", help="Clean up all sessions")

    return parser


def _prompt_text(label: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    if value:
        return value
    return default


def _prompt_secret(label: str, default: str = "") -> str:
    masked = "***" if default else ""
    suffix = f" [{masked}]" if masked else ""
    value = input(f"{label}{suffix}: ").strip()
    if value:
        return value
    return default


def _prompt_choice(label: str, options: list[tuple[str, str]], default_key: str) -> str:
    print(label)
    for key, desc in options:
        marker = " (default)" if key == default_key else ""
        print(f"  {key}) {desc}{marker}")

    valid_keys = {key for key, _ in options}
    while True:
        value = input("Choose: ").strip() or default_key
        if value in valid_keys:
            return value
        print(f"Invalid choice: {value}")


def _prompt_yes_no(label: str, default: bool = True) -> bool:
    default_text = "Y/n" if default else "y/N"
    while True:
        value = input(f"{label} [{default_text}]: ").strip().lower()
        if not value:
            return default
        if value in {"y", "yes"}:
            return True
        if value in {"n", "no"}:
            return False
        print(f"Invalid choice: {value}")


def _load_env_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}

    values: dict[str, str] = {}
    lines = path.read_text(encoding="utf-8").splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            i += 1
            continue

        key, value = stripped.split("=", 1)
        key = key.strip()
        value = value.strip()

        if value.startswith(('"', "'")):
            quote = value[0]
            if not (len(value) >= 2 and value.endswith(quote)):
                collected = [value]
                j = i + 1
                while j < len(lines):
                    collected.append(lines[j])
                    if lines[j].rstrip().endswith(quote):
                        break
                    j += 1
                value = "\n".join(collected)
                i = j

        if value.startswith('"') and value.endswith('"') and len(value) >= 2:
            value = value[1:-1].replace('\\"', '"').replace("\\\\", "\\")
        elif value.startswith("'") and value.endswith("'") and len(value) >= 2:
            value = value[1:-1]

        values[key] = value
        i += 1

    return values


def _format_env_value(value: str) -> str:
    needs_quote = any(ch.isspace() for ch in value) or any(ch in value for ch in ["#", '"', "'"])
    if not needs_quote:
        return value
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _format_env_assignment(key: str, value: str) -> str:
    return f"{key}={_format_env_value(value)}"


def _write_env_file(path: Path, values: dict[str, str]) -> None:
    keys_in_order = [
        "APP_ENV",
        "LOG_LEVEL",
        "DEFAULT_CHANNEL",
        "FEISHU_APP_ID",
        "FEISHU_APP_SECRET",
        "FEISHU_VERIFICATION_TOKEN",
        "FEISHU_ENCRYPT_KEY",
        "GATEWAY_INTERNAL_API_KEY",
        "LLM_PROVIDER",
        "LLM_ACTIVE_MODEL",
        "LLM_BASE_URL",
        "LLM_API_KEY",
        "LLM_MODEL",
        "LLM_CHAT_PATH",
        "LLM_TIMEOUT_SECONDS",
        "LLM_SYSTEM_PROMPT",
        "LLM_MODELS_CONFIG_PATH",
        "AI_TOOLS_CONFIG_PATH",
    ]

    lines = [_format_env_assignment(key, values.get(key, "")) for key in keys_in_order]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _resolve_models_config_path(config_value: str, env_path: Path) -> Path:
    raw = config_value.strip() or "models.toml"
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = (env_path.parent / path).resolve()
    else:
        path = path.resolve()
    return path


def _resolve_config_path(config_value: str, env_path: Path, default_name: str) -> Path:
    raw = config_value.strip() or default_name
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = (env_path.parent / path).resolve()
    else:
        path = path.resolve()
    return path


def _load_packaged_tools_template() -> str:
    try:
        template_path = importlib.resources.files("feishubot.ai.configs").joinpath(
            "tools.example.toml"
        )
        return template_path.read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError):
        return _FALLBACK_TOOLS_TOML


def _ensure_tools_config(path: Path) -> None:
    if path.exists():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_load_packaged_tools_template(), encoding="utf-8")


def _load_models_config(path: Path) -> tuple[str, dict[str, dict[str, str]]]:
    if not path.exists():
        return "", {}

    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except (tomllib.TOMLDecodeError, OSError):
        return "", {}

    if not isinstance(raw, dict):
        return "", {}

    default_model = str(raw.get("default_model", "")).strip()
    models_raw = raw.get("models")
    if not isinstance(models_raw, dict):
        return default_model, {}

    models: dict[str, dict[str, str]] = {}
    for name, config in models_raw.items():
        if not isinstance(name, str) or not isinstance(config, dict):
            continue
        model_name = name.strip()
        if not model_name:
            continue
        models[model_name] = {k: str(v) for k, v in config.items()}

    return default_model, models


def _escape_toml_string(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _dump_models_config(default_model: str, models: dict[str, dict[str, str]]) -> str:
    lines: list[str] = []
    if default_model.strip():
        lines.append(f"default_model = {_escape_toml_string(default_model.strip())}")
        lines.append("")

    for model_name, config in models.items():
        lines.append(f"[models.{_escape_toml_string(model_name)}]")
        ordered_fields = [
            "provider",
            "base_url",
            "api_key",
            "model",
            "chat_path",
            "timeout_seconds",
            "system_prompt",
        ]
        for field_name in ordered_fields:
            if field_name in config:
                lines.append(f"{field_name} = {_escape_toml_string(str(config[field_name]))}")

        for field_name, field_value in config.items():
            if field_name not in ordered_fields:
                lines.append(f"{field_name} = {_escape_toml_string(str(field_value))}")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _write_models_config(path: Path, default_model: str, models: dict[str, dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_dump_models_config(default_model, models), encoding="utf-8")


def _run_setup(args: argparse.Namespace) -> None:
    env_path = Path(args.env_file).expanduser().resolve()
    current = _load_env_file(env_path)

    print("FeishuBot quick setup")
    print(f"Target env file: {env_path}")

    if env_path.exists() and not args.yes:
        should_overwrite = _prompt_yes_no("Env file exists, update it", default=True)
        if not should_overwrite:
            print("Setup cancelled.")
            return

    model_choice = _prompt_choice(
        "Choose model provider",
        options=[
            ("1", f"qwen - {LLM_PRESETS['qwen']['label']}"),
            ("2", f"kimi - {LLM_PRESETS['kimi']['label']}"),
            ("3", f"deepseek - {LLM_PRESETS['deepseek']['label']}"),
            ("4", f"glm - {LLM_PRESETS['glm']['label']}"),
            ("5", "echo (for local smoke testing)"),
        ],
        default_key="5" if current.get("LLM_PROVIDER") == "echo" else "1",
    )

    selected_preset_key = ""
    if model_choice == "1":
        selected_preset_key = "qwen"
    elif model_choice == "2":
        selected_preset_key = "kimi"
    elif model_choice == "3":
        selected_preset_key = "deepseek"
    elif model_choice == "4":
        selected_preset_key = "glm"

    provider_value = "echo" if model_choice == "5" else "openai_compatible"

    feishu_verification_token = current.get("FEISHU_VERIFICATION_TOKEN", "")
    feishu_encrypt_key = current.get("FEISHU_ENCRYPT_KEY", "")
    configure_feishu_security = _prompt_yes_no(
        "Configure optional FEISHU_VERIFICATION_TOKEN / FEISHU_ENCRYPT_KEY",
        default=bool(feishu_verification_token or feishu_encrypt_key),
    )
    if configure_feishu_security:
        feishu_verification_token = _prompt_text(
            "FEISHU_VERIFICATION_TOKEN (optional)",
            feishu_verification_token,
        )
        feishu_encrypt_key = _prompt_text(
            "FEISHU_ENCRYPT_KEY (optional)",
            feishu_encrypt_key,
        )

    values: dict[str, str] = {
        "APP_ENV": _prompt_text("APP_ENV", current.get("APP_ENV", "dev")),
        "LOG_LEVEL": _prompt_text("LOG_LEVEL", current.get("LOG_LEVEL", "INFO")),
        "DEFAULT_CHANNEL": current.get("DEFAULT_CHANNEL", "feishu"),
        "FEISHU_APP_ID": _prompt_text("FEISHU_APP_ID", current.get("FEISHU_APP_ID", "")),
        "FEISHU_APP_SECRET": _prompt_secret(
            "FEISHU_APP_SECRET", current.get("FEISHU_APP_SECRET", "")
        ),
        "FEISHU_VERIFICATION_TOKEN": feishu_verification_token,
        "FEISHU_ENCRYPT_KEY": feishu_encrypt_key,
        "GATEWAY_INTERNAL_API_KEY": current.get("GATEWAY_INTERNAL_API_KEY", ""),
        "LLM_PROVIDER": provider_value,
        "LLM_ACTIVE_MODEL": current.get("LLM_ACTIVE_MODEL", ""),
        "LLM_BASE_URL": current.get("LLM_BASE_URL", ""),
        "LLM_API_KEY": "",
        "LLM_MODEL": current.get("LLM_MODEL", ""),
        "LLM_CHAT_PATH": current.get("LLM_CHAT_PATH", "/v1/chat/completions"),
        "LLM_TIMEOUT_SECONDS": current.get("LLM_TIMEOUT_SECONDS", "60"),
        "LLM_SYSTEM_PROMPT": current.get("LLM_SYSTEM_PROMPT", "You are a helpful assistant."),
        "LLM_MODELS_CONFIG_PATH": current.get("LLM_MODELS_CONFIG_PATH", "models.toml"),
        "AI_TOOLS_CONFIG_PATH": current.get("AI_TOOLS_CONFIG_PATH", _DEFAULT_TOOLS_CONFIG),
    }

    if provider_value == "openai_compatible":
        preset = LLM_PRESETS[selected_preset_key]
        values["LLM_BASE_URL"] = preset["base_url"]
        values["LLM_MODEL"] = preset["model"]
        values["LLM_CHAT_PATH"] = preset["chat_path"]
        values["LLM_API_KEY"] = _prompt_secret("LLM_API_KEY", current.get("LLM_API_KEY", ""))
        values["LLM_TIMEOUT_SECONDS"] = _prompt_text(
            "LLM_TIMEOUT_SECONDS", current.get("LLM_TIMEOUT_SECONDS", "60")
        )
        values["LLM_SYSTEM_PROMPT"] = _prompt_text(
            "LLM_SYSTEM_PROMPT",
            current.get("LLM_SYSTEM_PROMPT", "You are a helpful assistant."),
        )

        models_config_path = _resolve_models_config_path(values["LLM_MODELS_CONFIG_PATH"], env_path)
        _, models = _load_models_config(models_config_path)
        models[selected_preset_key] = {
            "provider": "openai_compatible",
            "base_url": values["LLM_BASE_URL"],
            "api_key": values["LLM_API_KEY"],
            "model": values["LLM_MODEL"],
            "chat_path": values["LLM_CHAT_PATH"],
            "timeout_seconds": values["LLM_TIMEOUT_SECONDS"],
            "system_prompt": values["LLM_SYSTEM_PROMPT"],
        }
        values["LLM_ACTIVE_MODEL"] = selected_preset_key
        _write_models_config(models_config_path, selected_preset_key, models)

        print("Applied model preset:")
        print(f"  provider: {selected_preset_key}")
        print(f"  base_url: {values['LLM_BASE_URL']}")
        print(f"  model: {values['LLM_MODEL']}")
        print(f"  chat_path: {values['LLM_CHAT_PATH']}")
        print(f"  active_model: {values['LLM_ACTIVE_MODEL']}")

    if provider_value == "echo":
        values["LLM_ACTIVE_MODEL"] = ""
        values["LLM_MODELS_CONFIG_PATH"] = ""

    tools_config_path = _resolve_config_path(
        values["AI_TOOLS_CONFIG_PATH"], env_path, _DEFAULT_TOOLS_CONFIG
    )
    _ensure_tools_config(tools_config_path)

    env_path.parent.mkdir(parents=True, exist_ok=True)
    _write_env_file(env_path, values)

    print("\nSetup complete.")
    if not values["FEISHU_APP_ID"] or not values["FEISHU_APP_SECRET"]:
        print("Warning: FEISHU_APP_ID / FEISHU_APP_SECRET are empty.")
        print("Long connection mode (feishubot events) requires both values.")
    print("Next steps:")
    print("  1) Start chat: feishubot chat")
    print("  2) Start gateway: feishubot gateway --reload")
    print(f"  3) Env file path: {env_path}")
    print(f"  4) Tools config path: {tools_config_path}")


def _run_model_switch(args: argparse.Namespace) -> None:
    env_path = Path(args.env_file).expanduser().resolve()
    current = _load_env_file(env_path)
    models_config_value = current.get("LLM_MODELS_CONFIG_PATH", "models.toml")
    models_config_path = _resolve_models_config_path(models_config_value, env_path)
    default_model, models = _load_models_config(models_config_path)

    if not models:
        print(f"No models found in: {models_config_path}")
        print("Run 'feishubot setup' first.")
        return

    model_names = list(models.keys())
    active = current.get("LLM_ACTIVE_MODEL", "") or default_model
    if active not in models:
        active = model_names[0]

    print(f"Target env file: {env_path}")
    print("Available models:")
    for idx, name in enumerate(model_names, start=1):
        config = models[name]
        model_id = config.get("model", "")
        marker = " (active)" if name == active else ""
        print(f"  {idx}) {name} -> {model_id}{marker}")

    selected_name = args.use
    if selected_name is None:
        default_index = model_names.index(active) + 1
        selected_index = _prompt_choice(
            "Choose active model",
            options=[(str(i), n) for i, n in enumerate(model_names, start=1)],
            default_key=str(default_index),
        )
        selected_name = model_names[int(selected_index) - 1]

    if selected_name not in models:
        print(f"Model not found: {selected_name}")
        print("Use one of:", ", ".join(model_names))
        return

    selected_config = models[selected_name]
    current["LLM_ACTIVE_MODEL"] = selected_name
    current["LLM_PROVIDER"] = selected_config.get("provider", "openai_compatible")
    current["LLM_BASE_URL"] = selected_config.get("base_url", "")
    current["LLM_API_KEY"] = selected_config.get("api_key", "")
    current["LLM_MODEL"] = selected_config.get("model", "")
    current["LLM_CHAT_PATH"] = selected_config.get("chat_path", "/v1/chat/completions")
    current["LLM_TIMEOUT_SECONDS"] = selected_config.get("timeout_seconds", "60")
    current["LLM_SYSTEM_PROMPT"] = selected_config.get(
        "system_prompt", "You are a helpful assistant."
    )
    current["LLM_MODELS_CONFIG_PATH"] = models_config_value
    _write_models_config(models_config_path, selected_name, models)

    _write_env_file(env_path, current)

    print(f"Active model switched to: {selected_name}")
    print("Restart 'feishubot chat' or gateway to apply the new model.")


def _parse_direct_tool_command(user_input: str) -> tuple[str, dict[str, Any]] | None:
    stripped = user_input.strip()
    if stripped.startswith("/terminal ") or stripped.startswith("/shell "):
        command = stripped.split(" ", 1)[1].strip()
        return "terminal", {"command": command}

    if not stripped.startswith("/tool "):
        return None

    remainder = stripped.split(" ", 1)[1].strip()
    if not remainder:
        return None
    if " " not in remainder:
        return remainder, {}

    tool_name, payload_text = remainder.split(" ", 1)
    payload_text = payload_text.strip()
    if payload_text.startswith("{"):
        try:
            payload = json.loads(payload_text)
        except json.JSONDecodeError:
            payload = {"command": payload_text}
        if isinstance(payload, dict):
            return tool_name, payload

    if tool_name == "calculator":
        return tool_name, {"expression": payload_text}
    return tool_name, {"command": payload_text}


async def _chat_loop(user_id: str, system_prompt: str | None) -> None:
    active = settings.active_llm_config()
    model_provider = create_active_provider()
    tool_runtime = ToolRuntime()
    agent_loop = AgentLoop(
        model_provider=model_provider,
        tool_runtime=tool_runtime,
        system_prompt=build_system_prompt(active.system_prompt, system_prompt, include_core=False),
    )

    print("FeishuBot terminal chat is ready.")
    if active.provider == "echo":
        print("Using model: echo")
    else:
        print(f"Using model: {active.model}")
    print("Tool shortcuts: /terminal <command>, /tool <name> <payload>")
    print("Type your message and press Enter. Use /exit to quit.")

    while True:
        try:
            user_input = input("you> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nbye")
            break

        if not user_input:
            continue

        if user_input.lower() in {"/exit", "exit", "quit"}:
            print("bye")
            break

        try:
            direct_tool_call = _parse_direct_tool_command(user_input)
            if direct_tool_call is not None:
                tool_name, arguments = direct_tool_call
                tool_result = await tool_runtime.execute(tool_name, arguments)
                print(f"bot> {tool_runtime.format_result(tool_name, tool_result)}")
                continue

            final_reply = await agent_loop.run(user_input=user_input, user_id=user_id)
            print(f"bot> {final_reply}")
        except Exception as exc:  # noqa: BLE001
            print(f"bot(error)> {exc}")
            continue


def _run_chat(args: argparse.Namespace) -> None:
    asyncio.run(_chat_loop(user_id=args.user_id, system_prompt=args.system_prompt))


def _run_gateway(args: argparse.Namespace) -> None:
    _run_webhook_gateway(args.host, args.port, args.reload)


def _run_webhook_gateway(host: str, port: int, reload: bool) -> None:
    import uvicorn

    if reload:
        print("Starting FeishuBot gateway in reload mode.")
    else:
        print("Starting FeishuBot gateway.")
    print(f"URL: http://{host}:{port}")
    uvicorn.run(
        "feishubot.main:app",
        host=host,
        port=port,
        reload=reload,
        log_level=settings.log_level.lower(),
    )


def _run_events(args: argparse.Namespace) -> None:
    import lark_oapi as lark

    from feishubot.ai.orchestrator.feishu_events import (
        build_event_dispatcher,
        start_event_worker_loop,
    )

    if not settings.feishu_app_id or not settings.feishu_app_secret:
        print("FEISHU_APP_ID and FEISHU_APP_SECRET are required for long connection mode.")
        return

    log_level_map = {
        "CRITICAL": lark.LogLevel.CRITICAL,
        "ERROR": lark.LogLevel.ERROR,
        "WARNING": lark.LogLevel.WARNING,
        "INFO": lark.LogLevel.INFO,
        "DEBUG": lark.LogLevel.DEBUG,
    }
    log_level = log_level_map[args.log_level]

    print("Starting Feishu long-connection event receiver.")
    print("Fallback policy: webhook gateway will start if long connection is unavailable.")
    print("Press Ctrl+C to stop.")

    start_event_worker_loop()
    client = lark.ws.Client(
        settings.feishu_app_id,
        settings.feishu_app_secret,
        log_level=log_level,
        event_handler=build_event_dispatcher(log_level),
        auto_reconnect=False,
    )
    try:
        client.start()
    except Exception as exc:  # noqa: BLE001
        fallback_enabled = not args.no_fallback_webhook
        if not fallback_enabled:
            raise

        print(f"Long connection unavailable: {exc}")
        print("Falling back to webhook gateway mode.")
        _run_webhook_gateway(args.fallback_host, args.fallback_port, args.fallback_reload)


def main(argv: Sequence[str] | None = None) -> None:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "chat":
        _run_chat(args)
        return

    if args.command == "gateway":
        _run_gateway(args)
        return

    if args.command == "events":
        _run_events(args)
        return

    if args.command == "setup":
        _run_setup(args)
        return

    if args.command == "model":
        _run_model_switch(args)
        return

    if args.command == "session":
        session_manager = SessionManager()
        if args.session_command == "list":
            sessions = session_manager.list_sessions()
            if not sessions:
                print("No sessions found.")
            else:
                print("Sessions:")
                for session in sessions:
                    print(f"  User ID: {session['key']}")
                    print(f"  Created: {session['created_at']}")
                    print(f"  Updated: {session['updated_at']}")
                    print(f"  Messages: {session['message_count']}")
                    print()
        elif args.session_command == "cleanup":
            count = session_manager.cleanup_expired_sessions(days=args.days)
            print(f"Cleaned up {count} expired sessions.")
        elif args.session_command == "cleanup-all":
            count = session_manager.cleanup_all_sessions()
            print(f"Cleaned up {count} sessions.")
        else:
            parser.print_help()
        return

    parser.print_help()


def chat_main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Run FeishuBot chat in terminal")
    _add_chat_arguments(parser)
    args = parser.parse_args(argv)
    _run_chat(args)


if __name__ == "__main__":
    main()
