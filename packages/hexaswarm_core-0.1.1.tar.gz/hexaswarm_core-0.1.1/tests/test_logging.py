from __future__ import annotations

from hexa_swarm_core.logging import bind_request, get_logger, setup_logging


def test_setup_logging_idempotent() -> None:
    setup_logging(level="INFO", json_output=True)
    setup_logging(level="DEBUG", json_output=False)


def test_get_logger_returns_usable_logger() -> None:
    setup_logging(level="INFO", json_output=True)
    log = get_logger("test")
    # Should not raise
    log.info("hello", extra_field=1)


def test_bind_request_returns_id() -> None:
    rid = bind_request()
    assert rid
    assert len(rid) >= 8


def test_bind_request_explicit_id() -> None:
    rid = bind_request(request_id="abc123", session_id="sess", agent="Beta")
    assert rid == "abc123"
