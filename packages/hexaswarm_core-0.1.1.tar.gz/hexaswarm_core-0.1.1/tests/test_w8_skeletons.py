"""W8 coverage - Go / Rust / Kotlin / Swift skeleton adapters.

These are "skeleton" in that they dispatch to native toolchains and don't
ship deep invariants yet. Tests verify detection + the shape of returned
CommandSpecs so regressions in the polymorphic dispatch surface fail fast.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from hexa_swarm_core.adapters import detect_adapters, get_adapter


# ---------- go-chi -------------------------------------------------
def test_go_chi_detects_from_go_mod(tmp_path: Path) -> None:
    (tmp_path / "go.mod").write_text(
        "module demo\n\nrequire github.com/go-chi/chi/v5 v5.1.0\n",
        encoding="utf-8",
    )
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "go-chi" in names


def test_go_chi_not_detected_without_chi(tmp_path: Path) -> None:
    (tmp_path / "go.mod").write_text("module demo\n", encoding="utf-8")
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "go-chi" not in names


def test_go_chi_commands_shape(tmp_path: Path) -> None:
    a = get_adapter("go-chi")
    assert a.lint_cmd(tmp_path)[0].cmd[0] == "golangci-lint"
    assert a.test_cmd(tmp_path)[0].cmd[:2] == ["go", "test"]
    assert a.typecheck_cmd(tmp_path)[0].cmd[:2] == ["go", "build"]


def test_go_chi_s5_enforcer_present() -> None:
    enforcers = get_adapter("go-chi").invariant_enforcers(Path("."))
    assert [e.invariant for e in enforcers] == ["S5"]


# ---------- rust-axum ----------------------------------------------
def test_rust_axum_detects_via_cargo(tmp_path: Path) -> None:
    (tmp_path / "Cargo.toml").write_text(
        "[package]\nname='x'\n\n[dependencies]\naxum = '0.7'\n",
        encoding="utf-8",
    )
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "rust-axum" in names


def test_rust_axum_not_detected_without_axum(tmp_path: Path) -> None:
    (tmp_path / "Cargo.toml").write_text("[package]\nname='x'\n", encoding="utf-8")
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "rust-axum" not in names


def test_rust_axum_commands(tmp_path: Path) -> None:
    a = get_adapter("rust-axum")
    assert a.lint_cmd(tmp_path)[0].cmd[:2] == ["cargo", "clippy"]
    assert a.test_cmd(tmp_path)[0].cmd[:2] == ["cargo", "test"]
    assert a.format_check_cmd(tmp_path)[0].cmd == ["cargo", "fmt", "--all", "--check"]


# ---------- kotlin-ktor --------------------------------------------
def test_kotlin_ktor_detects_from_build_gradle(tmp_path: Path) -> None:
    (tmp_path / "build.gradle.kts").write_text(
        'dependencies { implementation("io.ktor:ktor-server-core:2.3.0") }',
        encoding="utf-8",
    )
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "kotlin-ktor" in names


def test_kotlin_ktor_uses_gradlew_when_present(tmp_path: Path) -> None:
    (tmp_path / "build.gradle.kts").write_text('implementation("io.ktor:ktor")', encoding="utf-8")
    (tmp_path / "gradlew").write_text("#!/bin/sh", encoding="utf-8")
    a = get_adapter("kotlin-ktor")
    assert a.test_cmd(tmp_path)[0].cmd[0] == "./gradlew"


def test_kotlin_ktor_falls_back_to_gradle(tmp_path: Path) -> None:
    (tmp_path / "build.gradle.kts").write_text('implementation("io.ktor:ktor")', encoding="utf-8")
    a = get_adapter("kotlin-ktor")
    assert a.test_cmd(tmp_path)[0].cmd[0] == "gradle"


# ---------- swift-vapor --------------------------------------------
def test_swift_vapor_detects_from_package_swift(tmp_path: Path) -> None:
    (tmp_path / "Package.swift").write_text(
        '// swift-tools-version:5.9\nimport PackageDescription\n'
        '// .package(url: "https://github.com/vapor/vapor.git", from: "4.0.0")\n',
        encoding="utf-8",
    )
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "swift-vapor" in names


def test_swift_vapor_commands(tmp_path: Path) -> None:
    a = get_adapter("swift-vapor")
    assert a.test_cmd(tmp_path)[0].cmd[:2] == ["swift", "test"]
    assert a.build_cmd(tmp_path)[0].cmd[:4] == ["swift", "build", "-c", "release"]


# ---------- aggregate ----------------------------------------------
@pytest.mark.parametrize("name", ["go-chi", "rust-axum", "kotlin-ktor", "swift-vapor"])
def test_w8_adapter_registered(name: str) -> None:
    # get_adapter raises if the name is unknown - catching regressions where
    # a skeleton gets dropped from the registry by accident.
    a = get_adapter(name)
    assert a.name == name
    assert a.priority == 65


@pytest.mark.parametrize("name", ["go-chi", "rust-axum", "kotlin-ktor", "swift-vapor"])
def test_w8_adapter_exposes_all_stages(name: str, tmp_path: Path) -> None:
    a = get_adapter(name)
    for stage in (a.lint_cmd, a.format_check_cmd, a.typecheck_cmd, a.test_cmd, a.build_cmd, a.dep_audit_cmd):
        specs = stage(tmp_path)
        assert specs, f"{name}:{stage.__name__} should produce at least one CommandSpec"
