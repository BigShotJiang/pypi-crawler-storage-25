from __future__ import annotations

import json
from pathlib import Path

from hexa_swarm_core.mcp.openapi_server import (
    find_operation,
    info,
    list_operations,
    load_spec,
    main,
)

SAMPLE_SPEC = {
    "openapi": "3.1.0",
    "info": {"title": "Sample API", "version": "1.2.3"},
    "servers": [{"url": "https://api.example.com"}],
    "paths": {
        "/users": {
            "get": {"operationId": "listUsers", "summary": "List users"},
            "post": {"operationId": "createUser", "summary": "Create user"},
        },
        "/users/{id}": {
            "get": {"operationId": "getUser", "summary": "Get one user"},
            "delete": {"operationId": "deleteUser", "summary": "Delete user"},
        },
    },
}


def _write_spec(path: Path) -> None:
    import yaml

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(SAMPLE_SPEC), encoding="utf-8")


def test_load_spec_missing_file(project: Path) -> None:
    assert load_spec(project / "nope.yaml") == {}


def test_load_spec_malformed(project: Path) -> None:
    path = project / "bad.yaml"
    path.write_text("not: [valid: yaml", encoding="utf-8")
    assert load_spec(path) == {}


def test_info_happy_path(project: Path) -> None:
    spec_path = project / "openapi.yaml"
    _write_spec(spec_path)
    spec = load_spec(spec_path)
    meta = info(spec)
    assert meta["title"] == "Sample API"
    assert meta["version"] == "1.2.3"
    assert meta["spec_file_present"] is True


def test_info_when_missing_spec(project: Path) -> None:
    meta = info({})
    assert meta["spec_file_present"] is False


def test_list_operations(project: Path) -> None:
    spec_path = project / "openapi.yaml"
    _write_spec(spec_path)
    ops = list_operations(load_spec(spec_path))
    names = {op["operationId"] for op in ops}
    assert names == {"listUsers", "createUser", "getUser", "deleteUser"}
    methods = {op["method"] for op in ops}
    assert methods == {"GET", "POST", "DELETE"}


def test_find_operation(project: Path) -> None:
    spec_path = project / "openapi.yaml"
    _write_spec(spec_path)
    spec = load_spec(spec_path)
    op = find_operation(spec, "createUser")
    assert op is not None
    assert op["method"] == "POST"
    assert op["path"] == "/users"


def test_find_operation_unknown(project: Path) -> None:
    spec_path = project / "openapi.yaml"
    _write_spec(spec_path)
    assert find_operation(load_spec(spec_path), "nope") is None


def test_main_dry_run(capsys, project: Path) -> None:
    spec_path = project / "openapi.yaml"
    _write_spec(spec_path)
    rc = main([str(spec_path), "--dry-run"])
    assert rc == 0
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert payload["info"]["title"] == "Sample API"
    assert len(payload["operations"]) == 4
