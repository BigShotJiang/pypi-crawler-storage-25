from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from hexa_swarm_core.assets import tier_a_root
from hexa_swarm_core.cli.app import app
from hexa_swarm_core.install import install, plan
from hexa_swarm_core.profile import load_profile

runner = CliRunner()


def test_tier_a_root_exists() -> None:
    root = tier_a_root()
    assert root.exists()
    assert (root / ".claude" / "settings.json").exists()
    assert (root / ".ai-sync" / "RULES.md").exists()


def test_plan_empty_target_all_creates(project: Path) -> None:
    p = plan(project, force=False)
    assert p.will_create, "new files should be created"
    assert not p.will_overwrite
    # .gitkeep entries may be "skip" because the directory already exists


def test_install_creates_files(project: Path) -> None:
    r = install(project, force=False, dry_run=False)
    assert (project / ".claude" / "settings.json").exists()
    assert (project / ".claude" / "hooks" / "pre_tool_use_guard.py").exists()
    assert (project / ".claude" / "skills" / "quality-gate" / "SKILL.md").exists()
    assert (project / ".claude" / "agents" / "explorer.md").exists()
    assert (project / ".ai-sync" / "RULES.md").exists()
    assert (project / ".ai-sync" / "CODEOWNERS.md").exists()
    assert r.installed_assets


def test_install_idempotent_without_force(project: Path) -> None:
    install(project, force=False)
    second = install(project, force=False)
    # Everything existing → skipped
    assert second.created == []
    assert second.overwritten == []
    assert second.skipped


def test_install_force_overwrites(project: Path) -> None:
    install(project, force=False)
    # Corrupt a file and ensure --force repairs it
    target = project / ".ai-sync" / "RULES.md"
    target.write_text("CORRUPT", encoding="utf-8")
    r = install(project, force=True)
    assert any("RULES.md" in str(p) for p in r.overwritten)
    assert "CORRUPT" not in target.read_text(encoding="utf-8")


def test_install_dry_run_writes_nothing(project: Path) -> None:
    r = install(project, force=False, dry_run=True)
    assert r.created  # reported but not persisted
    assert not (project / ".claude" / "settings.json").exists()


def test_adopt_cli_installs_tier_a(fastapi_project: Path) -> None:
    r = runner.invoke(app, ["adopt", str(fastapi_project)])
    assert r.exit_code == 0, r.stdout + (r.stderr or "")
    assert (fastapi_project / ".claude" / "settings.json").exists()
    assert (fastapi_project / ".claude" / "hooks" / "pre_tool_use_guard.py").exists()
    prof = load_profile(fastapi_project)
    assert prof.archetype == "backend-api"
    assert "py-fastapi" in prof.stacks
    assert prof.feature_flags.get("has_tier_a") is True
    # installed_assets stored via pydantic extra
    extra = prof.model_dump()
    assert extra.get("installed_assets")


def test_adopt_cli_skip_install(fastapi_project: Path) -> None:
    r = runner.invoke(app, ["adopt", str(fastapi_project), "--skip-install"])
    assert r.exit_code == 0
    assert not (fastapi_project / ".claude" / "settings.json").exists()
    assert (fastapi_project / ".hexa" / "profile.yaml").exists()


def test_adopt_cli_dry_run_no_files(fastapi_project: Path) -> None:
    r = runner.invoke(app, ["adopt", str(fastapi_project), "--dry-run"])
    assert r.exit_code == 0
    assert not (fastapi_project / ".claude" / "settings.json").exists()
    assert not (fastapi_project / ".hexa" / "profile.yaml").exists()
