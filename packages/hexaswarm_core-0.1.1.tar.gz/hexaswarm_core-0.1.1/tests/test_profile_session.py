from __future__ import annotations

from pathlib import Path

import pytest

from hexa_swarm_core.exceptions import ProfileError
from hexa_swarm_core.profile import (
    DEFAULT_UNIVERSAL_INVARIANTS,
    init_profile,
    load_profile,
    profile_path,
    save_profile,
)
from hexa_swarm_core.session import current_session, end_session, init_session, session_path


def test_profile_save_load_roundtrip(project: Path) -> None:
    p = init_profile(project, archetype="backend-api", stacks=["py-fastapi"])
    save_profile(project, p)
    assert profile_path(project).exists()
    loaded = load_profile(project)
    assert loaded.archetype == "backend-api"
    assert loaded.stacks == ["py-fastapi"]
    assert set(loaded.invariants) == set(DEFAULT_UNIVERSAL_INVARIANTS)


def test_load_profile_missing_raises(project: Path) -> None:
    with pytest.raises(ProfileError):
        load_profile(project)


def test_session_init_and_current(project: Path) -> None:
    uid = init_session(project)
    assert len(uid) == 12
    assert session_path(project).exists()
    assert current_session(project) == uid


def test_session_end(project: Path) -> None:
    init_session(project)
    end_session(project)
    assert not session_path(project).exists()


def test_session_idempotent(project: Path) -> None:
    a = init_session(project)
    b = init_session(project)
    assert a == b
