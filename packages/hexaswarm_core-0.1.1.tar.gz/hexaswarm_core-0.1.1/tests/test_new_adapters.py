from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters import detect_adapters, get_adapter
from hexa_swarm_core.adapters.node_next import NodeNextAdapter
from tests.conftest import write_pkg_json as _write_pkg


# ---------- py-click ------------------------------------------------
def test_py_click_detects_typer(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='x'\ndependencies=['typer']\n",
        encoding="utf-8",
    )
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "py-click" in names


def test_py_click_detects_click_in_requirements(tmp_path: Path) -> None:
    (tmp_path / "requirements.txt").write_text("click>=8\n", encoding="utf-8")
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "py-click" in names


def test_py_click_priority_below_fastapi(tmp_path: Path) -> None:
    # Mixed project: declares both click and fastapi — fastapi must win
    (tmp_path / "src" / "backend").mkdir(parents=True)
    (tmp_path / "src" / "backend" / "pyproject.toml").write_text(
        "[project]\nname='x'\ndependencies=['fastapi','click']\n",
        encoding="utf-8",
    )
    adapters = detect_adapters(tmp_path)
    assert adapters[0].name == "py-fastapi"
    assert "py-click" in [a.name for a in adapters]


def test_py_click_commands(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='x'\ndependencies=['click']\n",
        encoding="utf-8",
    )
    a = get_adapter("py-click")
    assert a.lint_cmd(tmp_path)[0].cmd[:2] == ["ruff", "check"]
    assert a.test_cmd(tmp_path)[0].cmd[0] == "pytest"
    assert a.typecheck_cmd(tmp_path)[0].cmd[0] == "mypy"


def test_py_click_invariant_enforcers_includes_s2(tmp_path: Path) -> None:
    enforcers = get_adapter("py-click").invariant_enforcers(tmp_path)
    invariants = [e.invariant for e in enforcers]
    assert "S2" in invariants


# ---------- node-next ------------------------------------------------
def test_node_next_detects_via_package_json(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"next": "^15.0.0", "react": "^18"})
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-next" in names


def test_node_next_detects_via_next_config(tmp_path: Path) -> None:
    (tmp_path / "next.config.ts").write_text("export default {};", encoding="utf-8")
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-next" in names


def test_node_next_not_detected_without_next(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"express": "^5.0.0"})
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-next" not in names


def test_node_next_picks_pnpm_when_lockfile_present(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"next": "^15.0.0"})
    (tmp_path / "pnpm-lock.yaml").write_text("", encoding="utf-8")
    cmds = NodeNextAdapter().lint_cmd(tmp_path)
    assert cmds[0].cmd[0] == "pnpm"


def test_node_next_picks_yarn_when_lockfile_present(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"next": "^15.0.0"})
    (tmp_path / "yarn.lock").write_text("", encoding="utf-8")
    cmds = NodeNextAdapter().lint_cmd(tmp_path)
    assert cmds[0].cmd[0] == "yarn"


def test_node_next_defaults_to_npm(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"next": "^15.0.0"})
    cmds = NodeNextAdapter().lint_cmd(tmp_path)
    assert cmds[0].cmd[0] == "npm"


def test_node_next_typecheck_uses_tsc(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"next": "^15.0.0"})
    cmds = NodeNextAdapter().typecheck_cmd(tmp_path)
    assert any("tsc" in " ".join(spec.cmd) for spec in cmds)


def test_node_next_dep_audit(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"next": "^15.0.0"})
    cmds = NodeNextAdapter().dep_audit_cmd(tmp_path)
    joined = " ".join(cmds[0].cmd)
    assert "audit" in joined


# ---------- adopt with archetype ------------------------------------
def test_adopt_seeds_feature_flags_from_archetype(tmp_path: Path) -> None:
    """`hexa adopt` inherits the archetype's default_feature_flags into the profile."""
    from typer.testing import CliRunner

    from hexa_swarm_core.archetypes import get_archetype
    from hexa_swarm_core.cli.app import app
    from hexa_swarm_core.profile import load_profile

    runner = CliRunner()

    # Minimal cli-tool project: just a pyproject with click
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='x'\ndependencies=['click']\n",
        encoding="utf-8",
    )

    r = runner.invoke(app, ["adopt", str(tmp_path)])
    assert r.exit_code == 0, r.stdout + (r.stderr or "")

    profile = load_profile(tmp_path)
    arch = get_archetype(profile.archetype)
    for flag, expected in arch.default_feature_flags.items():
        assert profile.feature_flags.get(flag) == expected, (flag, expected)
