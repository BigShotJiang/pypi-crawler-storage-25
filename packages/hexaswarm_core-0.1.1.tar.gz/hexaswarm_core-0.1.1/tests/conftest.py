from __future__ import annotations

import json
from pathlib import Path

import pytest


def write_pkg_json(root: Path, deps: dict[str, str]) -> None:
    """Write a minimal package.json with the given deps under `root`."""
    root.mkdir(parents=True, exist_ok=True)
    (root / "package.json").write_text(
        json.dumps({"name": "x", "dependencies": deps, "scripts": {"lint": "echo", "test": "echo"}}),
        encoding="utf-8",
    )


@pytest.fixture
def project(tmp_path: Path) -> Path:
    """Empty project root."""
    return tmp_path


@pytest.fixture
def fastapi_project(tmp_path: Path) -> Path:
    """A minimal py-fastapi-looking project (pyproject.toml with 'fastapi' import)."""
    (tmp_path / "src" / "backend").mkdir(parents=True)
    (tmp_path / "src" / "backend" / "pyproject.toml").write_text(
        '[project]\nname = "x"\ndependencies = ["fastapi"]\n',
        encoding="utf-8",
    )
    return tmp_path


@pytest.fixture(autouse=True)
def _clean_hexa_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in ("HEXA_SESSION_UUID",):
        monkeypatch.delenv(var, raising=False)
