from __future__ import annotations

from pathlib import Path

import pytest

from hexa_swarm_core.adapters import detect_adapters, get_adapter
from hexa_swarm_core.adapters.protocol import StackAdapter
from hexa_swarm_core.exceptions import AdapterError


def test_get_adapter_known() -> None:
    a = get_adapter("py-fastapi")
    assert isinstance(a, StackAdapter)
    assert a.name == "py-fastapi"


def test_get_adapter_unknown_raises() -> None:
    with pytest.raises(AdapterError):
        get_adapter("nope")


def test_detect_empty_project_no_match(project: Path) -> None:
    assert detect_adapters(project) == []


def test_detect_fastapi_matches(fastapi_project: Path) -> None:
    adapters = detect_adapters(fastapi_project)
    assert [a.name for a in adapters][0] == "py-fastapi"


def test_detect_fastapi_not_matched_without_import(project: Path) -> None:
    (project / "src" / "backend").mkdir(parents=True)
    (project / "src" / "backend" / "pyproject.toml").write_text(
        "[project]\nname='x'\n",
        encoding="utf-8",
    )
    names = [a.name for a in detect_adapters(project)]
    assert "py-fastapi" not in names


def test_py_fastapi_commands(fastapi_project: Path) -> None:
    a = get_adapter("py-fastapi")
    assert a.lint_cmd(fastapi_project)[0].cmd[:2] == ["ruff", "check"]
    assert a.format_check_cmd(fastapi_project)[0].cmd[:2] == ["ruff", "format"]
    assert a.typecheck_cmd(fastapi_project)[0].cmd[0] == "mypy"
    assert a.test_cmd(fastapi_project)[0].cmd[0] == "pytest"


def test_generic_shell_matches_makefile(project: Path) -> None:
    (project / "Makefile").write_text("test:\n\techo ok\n", encoding="utf-8")
    names = [a.name for a in detect_adapters(project)]
    assert "generic-shell" in names


def test_detect_priority_sort(fastapi_project: Path) -> None:
    (fastapi_project / "Makefile").write_text("test:\n\techo ok\n", encoding="utf-8")
    adapters = detect_adapters(fastapi_project)
    # fastapi priority 70 > generic-shell 5
    assert adapters[0].name == "py-fastapi"
    assert adapters[-1].name == "generic-shell"
