"""W7 coverage - 4 new archetypes + 4 new adapters + detection heuristics."""

from __future__ import annotations

from pathlib import Path

import pytest

from hexa_swarm_core.adapters import detect_adapters, get_adapter
from hexa_swarm_core.adapters.node_express import NodeExpressAdapter
from hexa_swarm_core.adapters.node_nest import NodeNestAdapter
from hexa_swarm_core.adapters.py_celery import PyCeleryAdapter
from hexa_swarm_core.adapters.py_django import PyDjangoAdapter
from hexa_swarm_core.archetypes import ARCHETYPE_IDS, detect_archetype, get_archetype
from tests.conftest import write_pkg_json as _write_pkg


# ---------- archetypes ---------------------------------------------
def test_w7_archetypes_registered() -> None:
    assert {"data-pipeline", "rpa-bot", "ml-training", "library"}.issubset(ARCHETYPE_IDS)


def test_data_pipeline_defaults_deterministic_on() -> None:
    a = get_archetype("data-pipeline")
    assert a.default_feature_flags["has_deterministic_contracts"] is True
    assert a.default_feature_flags["has_external_integrations"] is True


def test_rpa_bot_defaults_advisory_on() -> None:
    a = get_archetype("rpa-bot")
    assert a.default_feature_flags["has_advisory_output"] is True


def test_ml_training_advisory_nondeterministic() -> None:
    a = get_archetype("ml-training")
    assert a.default_feature_flags["has_advisory_output"] is True
    assert a.default_feature_flags["has_deterministic_contracts"] is False


def test_library_deterministic_no_external() -> None:
    a = get_archetype("library")
    assert a.default_feature_flags["has_deterministic_contracts"] is True
    assert a.default_feature_flags["has_external_integrations"] is False


# ---------- detection heuristics -----------------------------------
def test_detect_archetype_ml_training_from_notebook(tmp_path: Path) -> None:
    (tmp_path / "notebooks").mkdir()
    (tmp_path / "notebooks" / "train.ipynb").write_text("{}", encoding="utf-8")
    assert detect_archetype(tmp_path, []) == "ml-training"


def test_detect_archetype_data_pipeline_from_pipelines_dir(tmp_path: Path) -> None:
    (tmp_path / "pipelines").mkdir()
    assert detect_archetype(tmp_path, []) == "data-pipeline"


def test_detect_archetype_data_pipeline_from_celery_stack(tmp_path: Path) -> None:
    assert detect_archetype(tmp_path, ["py-celery"]) == "data-pipeline"


def test_detect_archetype_rpa_bot_from_bot_dir(tmp_path: Path) -> None:
    (tmp_path / "src" / "bot").mkdir(parents=True)
    assert detect_archetype(tmp_path, ["py-click"]) == "rpa-bot"


def test_detect_archetype_library_from_src_tests_layout(tmp_path: Path) -> None:
    (tmp_path / "src" / "mypkg").mkdir(parents=True)
    (tmp_path / "tests").mkdir()
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='mypkg'\n",
        encoding="utf-8",
    )
    assert detect_archetype(tmp_path, []) == "library"


# ---------- py-celery ----------------------------------------------
def test_py_celery_detects_celery(tmp_path: Path) -> None:
    (tmp_path / "requirements.txt").write_text("celery>=5\n", encoding="utf-8")
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "py-celery" in names


def test_py_celery_detects_airflow(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='x'\ndependencies=['apache-airflow']\n",
        encoding="utf-8",
    )
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "py-celery" in names


def test_py_celery_commands(tmp_path: Path) -> None:
    a = PyCeleryAdapter()
    assert a.lint_cmd(tmp_path)[0].cmd[:2] == ["ruff", "check"]
    assert a.test_cmd(tmp_path)[0].cmd[0] == "pytest"


def test_py_celery_invariant_s3_idempotent() -> None:
    invariants = [e.invariant for e in PyCeleryAdapter().invariant_enforcers(Path("."))]
    assert "S3" in invariants


# ---------- py-django ----------------------------------------------
def test_py_django_detects_django(tmp_path: Path) -> None:
    (tmp_path / "manage.py").write_text("# django\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='x'\ndependencies=['django>=5']\n",
        encoding="utf-8",
    )
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "py-django" in names


def test_py_django_test_cmd_uses_manage_py(tmp_path: Path) -> None:
    (tmp_path / "manage.py").write_text("# django\n", encoding="utf-8")
    cmd = PyDjangoAdapter().test_cmd(tmp_path)[0].cmd
    assert cmd[:3] == ["python", "manage.py", "test"]


def test_py_django_invariant_is_s5() -> None:
    invariants = [e.invariant for e in PyDjangoAdapter().invariant_enforcers(Path("."))]
    assert invariants == ["S5", "S5"]


def test_py_django_priority_below_fastapi(tmp_path: Path) -> None:
    (tmp_path / "manage.py").write_text("", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='x'\ndependencies=['django','fastapi']\n",
        encoding="utf-8",
    )
    adapters = detect_adapters(tmp_path)
    names = [a.name for a in adapters]
    assert names[0] == "py-fastapi"
    assert "py-django" in names


# ---------- node-nest ----------------------------------------------
def test_node_nest_detects_via_nestjs_dep(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"@nestjs/core": "^10", "@nestjs/common": "^10"})
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-nest" in names


def test_node_nest_detects_via_nest_cli(tmp_path: Path) -> None:
    (tmp_path / "nest-cli.json").write_text("{}", encoding="utf-8")
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-nest" in names


def test_node_nest_default_npm(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"@nestjs/core": "^10"})
    cmds = NodeNestAdapter().lint_cmd(tmp_path)
    assert cmds[0].cmd[0] == "npm"


# ---------- node-express -------------------------------------------
def test_node_express_detects_express(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"express": "^5"})
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-express" in names


def test_node_express_detects_fastify(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"fastify": "^4"})
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-express" in names


def test_node_express_yields_to_next(tmp_path: Path) -> None:
    # A repo using Next.js with express middleware should still be handled
    # by node-next - node-express must opt out.
    _write_pkg(tmp_path, {"next": "^15", "express": "^5"})
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-next" in names
    assert "node-express" not in names


def test_node_express_yields_to_nest(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"@nestjs/core": "^10", "express": "^5"})
    names = [a.name for a in detect_adapters(tmp_path)]
    assert "node-nest" in names
    assert "node-express" not in names


def test_node_express_defaults_to_pnpm_when_lockfile(tmp_path: Path) -> None:
    _write_pkg(tmp_path, {"express": "^5"})
    (tmp_path / "pnpm-lock.yaml").write_text("", encoding="utf-8")
    cmds = NodeExpressAdapter().build_cmd(tmp_path)
    assert cmds[0].cmd[0] == "pnpm"


# ---------- smoke: every W7 adapter exposes build_cmd ---------------
@pytest.mark.parametrize("name", ["py-django", "node-nest", "node-express"])
def test_w7_adapter_build_cmd_not_empty(name: str, tmp_path: Path) -> None:
    # Set up a minimal file so the adapter object can be constructed cleanly.
    if name.startswith("py-"):
        (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
        if name == "py-django":
            (tmp_path / "manage.py").write_text("", encoding="utf-8")
    else:
        _write_pkg(tmp_path, {"express": "^5"} if name == "node-express" else {"@nestjs/core": "^10"})
    adapter = get_adapter(name)
    # build_cmd is allowed to be empty for adapters that have no build step,
    # but these four all have one - assert that.
    assert adapter.build_cmd(tmp_path), f"{name} should expose a build command"
