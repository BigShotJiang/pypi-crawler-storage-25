from __future__ import annotations

from pathlib import Path

import pytest

from hexa_swarm_core.exceptions import SafetyViolationError
from hexa_swarm_core.invariants import (
    CostCeilingEnforcer,
    KillSwitchEnforcer,
    PromptSafetyEnforcer,
    assert_all,
    universal_enforcers,
)
from hexa_swarm_core.safety import KillSwitch
from hexa_swarm_core.telemetry.cost import CostTracker


def test_cost_ceiling_enforcer_pass(project: Path) -> None:
    ledger = project / "cost.jsonl"
    e = CostCeilingEnforcer(max_usd=1.0, project_id="p", ledger=ledger)
    r = e.run(project)
    assert r.ok
    assert r.invariant == "S4"


def test_cost_ceiling_enforcer_fail(project: Path) -> None:
    ledger = project / "cost.jsonl"
    CostTracker(ledger_path=ledger).record(
        project_id="p", stage="s", service="x", operation="o", cost_usd=1.5
    )
    e = CostCeilingEnforcer(max_usd=1.0, project_id="p", ledger=ledger)
    r = e.run(project)
    assert not r.ok
    assert "$1.5000" in r.detail


def test_killswitch_enforcer_pass(project: Path) -> None:
    assert KillSwitchEnforcer().run(project).ok


def test_killswitch_enforcer_fail(project: Path) -> None:
    KillSwitch(project).activate("test")
    r = KillSwitchEnforcer().run(project)
    assert not r.ok
    assert "engaged" in r.detail


def test_prompt_safety_enforcer(project: Path) -> None:
    r = PromptSafetyEnforcer().run(project)
    assert r.ok
    assert r.invariant == "S6"


def test_universal_enforcers_pass(project: Path) -> None:
    ledger = project / "cost.jsonl"
    enforcers = [
        CostCeilingEnforcer(max_usd=5.0, project_id="p", ledger=ledger),
        KillSwitchEnforcer(),
        PromptSafetyEnforcer(),
    ]
    results = assert_all(enforcers, project)
    assert [r.invariant for r in results] == ["S4", "S5", "S6"]
    assert all(r.ok for r in results)


def test_assert_all_raises_with_invariant_id(project: Path) -> None:
    KillSwitch(project).activate("test")
    with pytest.raises(SafetyViolationError) as ei:
        assert_all([KillSwitchEnforcer()], project)
    assert ei.value.invariant == "S5"
    assert ei.value.code == "SAFETY_S5"


def test_universal_enforcers_factory(project: Path) -> None:
    enforcers = universal_enforcers(project_id="p", max_usd_per_session=5.0)
    assert [e.invariant for e in enforcers] == ["S4", "S5", "S6"]
