from __future__ import annotations

import os
from pathlib import Path

import pytest

from hexa_swarm_core.exceptions import LockBusyError
from hexa_swarm_core.locks import acquire_lock, cleanup_stale, heartbeat, is_stale, release_lock


def test_acquire_and_release(project: Path) -> None:
    lp = acquire_lock(project, "SYSTEM_STATE.md", agent="Beta", reason="test")
    assert lp.exists()
    payload = lp.read_text(encoding="utf-8")
    assert "SYSTEM_STATE.md" in payload
    assert release_lock(lp) is True
    assert not lp.exists()


def test_double_acquire_is_busy(project: Path) -> None:
    acquire_lock(project, "F", agent="A", session_uuid="fixedsess")
    with pytest.raises(LockBusyError):
        acquire_lock(project, "F", agent="A", session_uuid="fixedsess")


def test_different_sessions_do_not_collide(project: Path) -> None:
    a = acquire_lock(project, "F", agent="A", session_uuid="s1")
    b = acquire_lock(project, "F", agent="A", session_uuid="s2")
    assert a != b
    assert a.exists()
    assert b.exists()


def test_heartbeat_creates_side_file(project: Path) -> None:
    lp = acquire_lock(project, "F", agent="A", session_uuid="s")
    heartbeat(lp)
    hb = lp.with_suffix(lp.suffix + ".hb")
    assert hb.exists()


def test_cleanup_removes_stale(project: Path) -> None:
    lp = acquire_lock(project, "F", agent="A", session_uuid="s")
    old = lp.stat().st_mtime - 10_000  # 2.7h ago
    os.utime(lp, (old, old))
    removed = cleanup_stale(project)
    assert lp in removed
    assert not lp.exists()


def test_cleanup_keeps_fresh(project: Path) -> None:
    lp = acquire_lock(project, "F", agent="A", session_uuid="s")
    removed = cleanup_stale(project)
    assert removed == []
    assert lp.exists()


def test_is_stale_with_dead_heartbeat(project: Path) -> None:
    lp = acquire_lock(project, "F", agent="A", session_uuid="s")
    heartbeat(lp)
    hb = lp.with_suffix(lp.suffix + ".hb")
    old = hb.stat().st_mtime - 10_000
    os.utime(hb, (old, old))
    assert is_stale(lp) is True


def test_cleanup_dry_run_does_not_delete(project: Path) -> None:
    lp = acquire_lock(project, "F", agent="A", session_uuid="s")
    old = lp.stat().st_mtime - 10_000
    os.utime(lp, (old, old))
    removed = cleanup_stale(project, dry_run=True)
    assert lp in removed
    assert lp.exists()  # dry run does not delete
