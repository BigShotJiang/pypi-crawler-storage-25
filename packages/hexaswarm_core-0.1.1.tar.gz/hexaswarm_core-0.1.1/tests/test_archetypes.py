from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from hexa_swarm_core.archetypes import (
    ARCHETYPE_IDS,
    ARCHETYPES,
    detect_archetype,
    get_archetype,
)
from hexa_swarm_core.cli.app import app
from hexa_swarm_core.exceptions import HexaError

runner = CliRunner()


def test_registry_contains_w6_archetypes() -> None:
    assert set(ARCHETYPE_IDS) >= {"fullstack-web", "backend-api", "frontend-app", "cli-tool"}
    assert all(a.description for a in ARCHETYPES)


def test_get_archetype_unknown_raises() -> None:
    with pytest.raises(HexaError):
        get_archetype("not-a-real-archetype")


def test_archetype_summary_shape() -> None:
    a = get_archetype("fullstack-web")
    summary = a.summary()
    for key in (
        "id",
        "description",
        "default_stacks",
        "default_feature_flags",
        "required_skills",
        "optional_skills",
        "ci_workflows",
        "dir_expectations",
    ):
        assert key in summary


def test_fullstack_web_declares_both_stacks() -> None:
    a = get_archetype("fullstack-web")
    assert "py-fastapi" in a.default_stacks
    assert "node-next" in a.default_stacks


def test_cli_tool_enables_deterministic_contracts() -> None:
    a = get_archetype("cli-tool")
    assert a.default_feature_flags.get("has_deterministic_contracts") is True


def test_detect_archetype_backend_only(tmp_path: Path) -> None:
    (tmp_path / "src" / "backend").mkdir(parents=True)
    assert detect_archetype(tmp_path, ["py-fastapi"]) == "backend-api"


def test_detect_archetype_frontend_only(tmp_path: Path) -> None:
    (tmp_path / "app").mkdir()
    (tmp_path / "next.config.ts").write_text("export default {};", encoding="utf-8")
    assert detect_archetype(tmp_path, ["node-next"]) == "frontend-app"


def test_detect_archetype_fullstack(tmp_path: Path) -> None:
    (tmp_path / "src" / "backend").mkdir(parents=True)
    (tmp_path / "app").mkdir()
    assert detect_archetype(tmp_path, ["py-fastapi", "node-next"]) == "fullstack-web"


def test_detect_archetype_cli_fallback(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='x'\ndependencies=['click']\n",
        encoding="utf-8",
    )
    assert detect_archetype(tmp_path, ["py-click"]) == "cli-tool"


def test_cli_archetype_list() -> None:
    r = runner.invoke(app, ["archetype", "list"])
    assert r.exit_code == 0
    assert "fullstack-web" in r.stdout
    assert "backend-api" in r.stdout


def test_cli_archetype_list_json() -> None:
    r = runner.invoke(app, ["archetype", "list", "--json"])
    assert r.exit_code == 0
    data = json.loads(r.stdout)
    ids = [a["id"] for a in data]
    assert "fullstack-web" in ids


def test_cli_archetype_show() -> None:
    r = runner.invoke(app, ["archetype", "show", "fullstack-web"])
    assert r.exit_code == 0
    data = json.loads(r.stdout)
    assert data["id"] == "fullstack-web"
    assert "py-fastapi" in data["default_stacks"]


def test_cli_archetype_show_unknown() -> None:
    r = runner.invoke(app, ["archetype", "show", "nope"])
    assert r.exit_code != 0
