from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest
from typer.testing import CliRunner

from hexa_swarm_core.cli.app import app
from hexa_swarm_core.locks import acquire_lock
from hexa_swarm_core.safety.killswitch import KillSwitch
from hexa_swarm_core.session import init_session
from hexa_swarm_core.swarm import (
    heartbeat_loop,
    heartbeat_once,
    list_proposals,
    mark_applied,
    propose_contract_change,
)

runner = CliRunner()


def _git_available() -> bool:
    return shutil.which("git") is not None


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    if not _git_available():
        pytest.skip("git not installed")
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init", "--initial-branch=main"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "t@t.t"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "T"], cwd=repo, check=True, capture_output=True)
    (repo / "README.md").write_text("hi\n", encoding="utf-8")
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=repo, check=True, capture_output=True)
    return repo


# ----- worktree -----
def test_worktree_boot_and_teardown(git_repo: Path) -> None:
    from hexa_swarm_core.swarm.worktree import (
        boot_worktree,
        list_worktrees,
        teardown_worktree,
    )

    h = boot_worktree(git_repo, agent="writer-be", session="sess1")
    assert h.path.exists()
    assert h.branch == "sess/sess1/writer-be"
    handles = list_worktrees(git_repo)
    assert any(x.agent == "writer-be" for x in handles)
    teardown_worktree(h)
    assert not h.path.exists()


def test_worktree_boot_errors_on_non_repo(tmp_path: Path) -> None:
    from hexa_swarm_core.swarm.worktree import boot_worktree

    with pytest.raises(RuntimeError, match="not a git repo"):
        boot_worktree(tmp_path, agent="a", session="s")


# ----- heartbeat -----
def test_heartbeat_once_touches_own_locks(project: Path) -> None:
    sid = init_session(project)
    lp = acquire_lock(project, "SYSTEM_STATE.md", agent="Beta", session_uuid=sid)
    touched = heartbeat_once(project)
    assert any(p.name == lp.name + ".hb" for p in touched)


def test_heartbeat_loop_stops_on_killswitch(project: Path) -> None:
    init_session(project)
    KillSwitch(project).activate("stop")
    n = heartbeat_loop(project, interval_s=0.01, max_iterations=5)
    # Loop exits before doing full iterations (killswitch check at top).
    assert 0 <= n <= 5


def test_heartbeat_loop_bounded(project: Path) -> None:
    init_session(project)
    n = heartbeat_loop(project, interval_s=0.001, max_iterations=3)
    assert n == 3


# ----- contract writer -----
def test_propose_list_apply(project: Path) -> None:
    p1 = propose_contract_change(
        project,
        target_file=".ai-sync/contracts/openapi.yaml",
        proposer="beta",
        summary="add /users/search",
        diff="--- a/...\n+++ b/...\n",
    )
    assert p1.exists()
    ps = list_proposals(project)
    assert len(ps) == 1
    assert ps[0].target_file.endswith("openapi.yaml")
    assert ps[0].diff

    archived = mark_applied(p1)
    assert archived.exists()
    assert not p1.exists()
    assert len(list_proposals(project)) == 0
    assert len(list_proposals(project, include_applied=True)) == 1


# ----- CLI wiring -----
def test_cli_contract_propose_list_apply(project: Path) -> None:
    r = runner.invoke(
        app,
        [
            "contract", "propose",
            "--target", ".ai-sync/contracts/openapi.yaml",
            "--summary", "add users endpoint",
            "--proposer", "beta",
            "--path", str(project),
        ],
    )
    assert r.exit_code == 0, r.stdout + (r.stderr or "")
    prop_path = Path(r.stdout.strip().splitlines()[-1])
    assert prop_path.exists()

    r2 = runner.invoke(app, ["contract", "list", "--path", str(project)])
    assert r2.exit_code == 0
    assert "add users endpoint" in r2.stdout

    r3 = runner.invoke(app, ["contract", "apply", str(prop_path)])
    assert r3.exit_code == 0


def test_cli_heartbeat_once(project: Path) -> None:
    init_session(project)
    r = runner.invoke(app, ["heartbeat", "once", "--path", str(project)])
    assert r.exit_code == 0
    assert "touched=" in r.stdout


def test_cli_worktree_boot_and_teardown(git_repo: Path) -> None:
    # Use hexa session/init + hexa worktree boot
    r0 = runner.invoke(app, ["session", "init", str(git_repo)])
    assert r0.exit_code == 0

    r1 = runner.invoke(
        app,
        [
            "worktree", "boot",
            "--agent", "writer-fe",
            "--path", str(git_repo),
        ],
    )
    assert r1.exit_code == 0, r1.stdout + (r1.stderr or "")
    wt_path = Path(r1.stdout.strip().splitlines()[0])
    assert wt_path.exists()

    r2 = runner.invoke(app, ["worktree", "list", "--path", str(git_repo)])
    assert r2.exit_code == 0

    r3 = runner.invoke(app, ["worktree", "teardown", str(wt_path), "--repo", str(git_repo)])
    assert r3.exit_code == 0


# keep strict file count for coverage calc
_ = os  # noqa: F401
