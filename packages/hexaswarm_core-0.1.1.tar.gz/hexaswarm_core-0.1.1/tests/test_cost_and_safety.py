from __future__ import annotations

from pathlib import Path

import pytest

from hexa_swarm_core.exceptions import SafetyViolationError
from hexa_swarm_core.safety import CostCeiling, KillSwitch
from hexa_swarm_core.telemetry import CostTracker


def test_cost_tracker_record_and_total(project: Path) -> None:
    t = CostTracker(ledger_path=project / "costs.jsonl")
    t.record(project_id="p", stage="s", service="claude", operation="generate", cost_usd=0.01)
    t.record(project_id="p", stage="s", service="claude", operation="generate", cost_usd=0.02)
    t.record(project_id="q", stage="s", service="claude", operation="generate", cost_usd=0.10)
    assert t.total(project_id="p") == pytest.approx(0.03)
    assert t.total(project_id="q") == pytest.approx(0.10)


def test_cost_tracker_total_empty(project: Path) -> None:
    t = CostTracker(ledger_path=project / "costs.jsonl")
    assert t.total(project_id="p") == 0.0


def test_cost_ceiling_allows(project: Path) -> None:
    t = CostTracker(ledger_path=project / "c.jsonl")
    c = CostCeiling(max_usd=1.0, tracker=t)
    c.check_can_spend("p", estimated_usd=0.5)  # no raise
    t.record(project_id="p", stage="s", service="x", operation="o", cost_usd=0.5)
    c.check_can_spend("p", estimated_usd=0.3)  # still under


def test_cost_ceiling_blocks(project: Path) -> None:
    t = CostTracker(ledger_path=project / "c.jsonl")
    t.record(project_id="p", stage="s", service="x", operation="o", cost_usd=0.9)
    c = CostCeiling(max_usd=1.0, tracker=t)
    with pytest.raises(SafetyViolationError) as ei:
        c.check_can_spend("p", estimated_usd=0.2)
    assert ei.value.invariant == "S4"
    assert ei.value.code == "SAFETY_S4"


def test_killswitch_activate_deactivate(project: Path) -> None:
    ks = KillSwitch(project)
    assert not ks.is_active()
    ks.activate(reason="manual test")
    assert ks.is_active()
    with pytest.raises(SafetyViolationError) as ei:
        ks.assert_live()
    assert ei.value.invariant == "S5"
    ks.deactivate()
    assert not ks.is_active()
    ks.assert_live()  # no raise
