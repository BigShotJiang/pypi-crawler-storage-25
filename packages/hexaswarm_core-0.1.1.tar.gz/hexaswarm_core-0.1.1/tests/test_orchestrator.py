from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from hexa_swarm_core.exceptions import SafetyViolationError
from hexa_swarm_core.orchestrator import PipelineOrchestrator, StageResult
from hexa_swarm_core.safety import CostCeiling, KillSwitch
from hexa_swarm_core.telemetry.cost import CostTracker


class _Echo:
    """Minimal Stage that records its name into the project dict."""

    def __init__(self, name: str, cost: float = 0.0, fail: bool = False, skip: bool = False) -> None:
        self.name = name
        self.cost = cost
        self.fail = fail
        self.skip = skip

    def run(self, project: dict[str, Any]) -> StageResult:
        if self.fail:
            raise RuntimeError("boom")
        project.setdefault("ran", []).append(self.name)
        return StageResult(
            stage=self.name,
            status="ok",
            cost_usd=self.cost,
            artifacts={"service": "test"},
        )

    def should_skip(self, project: dict[str, Any]) -> bool:  # noqa: ARG002
        return self.skip


def test_runs_all_stages_in_order(project: Path) -> None:
    orch = PipelineOrchestrator(
        [_Echo("a"), _Echo("b"), _Echo("c")],
        project_root=project,
    )
    state: dict[str, Any] = {"project_id": "p"}
    results = orch.run(state)
    assert [r.stage for r in results] == ["a", "b", "c"]
    assert state["ran"] == ["a", "b", "c"]


def test_resume_from_middle(project: Path) -> None:
    orch = PipelineOrchestrator([_Echo("a"), _Echo("b"), _Echo("c")], project_root=project)
    state: dict[str, Any] = {"project_id": "p"}
    results = orch.run(state, resume_from="b")
    assert [r.stage for r in results] == ["b", "c"]
    assert state["ran"] == ["b", "c"]


def test_unknown_resume_raises(project: Path) -> None:
    orch = PipelineOrchestrator([_Echo("a")], project_root=project)
    with pytest.raises(ValueError, match="unknown resume_from"):
        orch.run({"project_id": "p"}, resume_from="nope")


def test_should_skip_respected(project: Path) -> None:
    orch = PipelineOrchestrator([_Echo("a"), _Echo("b", skip=True), _Echo("c")], project_root=project)
    state: dict[str, Any] = {"project_id": "p"}
    results = orch.run(state)
    assert [r.status for r in results] == ["ok", "skipped", "ok"]
    assert state["ran"] == ["a", "c"]


def test_stops_on_failure_and_records(project: Path) -> None:
    orch = PipelineOrchestrator([_Echo("a"), _Echo("b", fail=True), _Echo("c")], project_root=project)
    state: dict[str, Any] = {"project_id": "p"}
    results = orch.run(state)
    assert [r.stage for r in results] == ["a", "b"]
    assert results[-1].status == "failed"
    assert "boom" in (results[-1].error or "")


def test_cost_ledger_receives_entries(project: Path) -> None:
    ledger = project / "cost.jsonl"
    tracker = CostTracker(ledger_path=ledger)
    orch = PipelineOrchestrator(
        [_Echo("a", cost=0.01), _Echo("b", cost=0.03)],
        project_root=project,
        cost_tracker=tracker,
    )
    orch.run({"project_id": "p"})
    assert tracker.total(project_id="p") == pytest.approx(0.04)


def test_killswitch_aborts_before_stage(project: Path) -> None:
    KillSwitch(project).activate("abort")
    orch = PipelineOrchestrator([_Echo("a")], project_root=project)
    with pytest.raises(SafetyViolationError) as ei:
        orch.run({"project_id": "p"})
    assert ei.value.invariant == "S5"


def test_cost_ceiling_blocks_before_stage(project: Path) -> None:
    tracker = CostTracker(ledger_path=project / "c.jsonl")
    tracker.record(project_id="p", stage="pre", service="x", operation="o", cost_usd=0.99)
    ceiling = CostCeiling(max_usd=1.0, tracker=tracker)
    orch = PipelineOrchestrator(
        [_Echo("a", cost=0.5)],
        project_root=project,
        cost_tracker=tracker,
        cost_ceiling=ceiling,
    )
    # 0.99 spent + 0.0 estimated = <= 1.0 so first gate passes,
    # but seeding > 1.0 + explicit estimate triggers.
    tracker.record(project_id="p", stage="pre2", service="x", operation="o", cost_usd=0.1)
    with pytest.raises(SafetyViolationError) as ei:
        orch.run({"project_id": "p"})
    assert ei.value.invariant == "S4"


def test_rejects_duplicate_stage_names(project: Path) -> None:
    with pytest.raises(ValueError, match="unique"):
        PipelineOrchestrator([_Echo("a"), _Echo("a")], project_root=project)


def test_rejects_empty_stage_list(project: Path) -> None:
    with pytest.raises(ValueError, match="non-empty"):
        PipelineOrchestrator([], project_root=project)


def test_duration_populated(project: Path) -> None:
    results = PipelineOrchestrator([_Echo("a")], project_root=project).run({"project_id": "p"})
    assert results[0].duration_seconds >= 0
