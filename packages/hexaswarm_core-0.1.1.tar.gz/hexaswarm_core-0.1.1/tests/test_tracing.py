from __future__ import annotations

import asyncio
from typing import Any

import pytest

from hexa_swarm_core.logging.tracing import (
    X_REQUEST_ID_HEADER,
    RequestIdMiddleware,
    new_trace_id,
    parse_traceparent,
    trace_scope,
)


def test_new_trace_id_length_and_uniqueness() -> None:
    a = new_trace_id()
    b = new_trace_id()
    assert len(a) == 16
    assert a != b
    assert all(c in "0123456789abcdef" for c in a)


@pytest.mark.parametrize(
    ("header", "expected"),
    [
        ("00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01", "0af7651916cd43dd"),
        ("invalid", None),
        ("", None),
        (None, None),
    ],
)
def test_parse_traceparent(header: str | None, expected: str | None) -> None:
    assert parse_traceparent(header) == expected


def test_trace_scope_binds_request_id() -> None:
    with trace_scope(request_id="fixed-id") as rid:
        from hexa_swarm_core.logging.config import _request_id_var
        assert _request_id_var.get() == "fixed-id"
        assert rid == "fixed-id"


def test_trace_scope_auto_generates_id() -> None:
    with trace_scope() as rid:
        assert rid
        assert len(rid) == 16


def _run_middleware(inbound_headers: list[tuple[bytes, bytes]]) -> dict[str, Any]:
    """Drive RequestIdMiddleware through a single fake HTTP request."""
    sent: list[dict[str, Any]] = []

    async def downstream(scope, receive, send):  # noqa: ANN001
        # Emit a minimal response.start
        await send({"type": "http.response.start", "status": 200, "headers": []})

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(message):
        sent.append(message)

    mw = RequestIdMiddleware(downstream)
    scope = {"type": "http", "headers": inbound_headers}
    asyncio.run(mw(scope, receive, send))

    # The start message should have an X-Request-Id header now.
    start = [m for m in sent if m["type"] == "http.response.start"][0]
    hdrs = dict(start["headers"])
    return {"headers": hdrs, "sent": sent}


def test_middleware_echoes_inbound_request_id() -> None:
    out = _run_middleware([(X_REQUEST_ID_HEADER.encode("latin-1"), b"abc-123")])
    assert out["headers"][X_REQUEST_ID_HEADER.encode("latin-1")] == b"abc-123"


def test_middleware_generates_when_missing() -> None:
    out = _run_middleware([])
    got = out["headers"][X_REQUEST_ID_HEADER.encode("latin-1")]
    assert got
    assert len(got) >= 12


def test_middleware_accepts_traceparent() -> None:
    out = _run_middleware(
        [(b"traceparent", b"00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01")]
    )
    got = out["headers"][X_REQUEST_ID_HEADER.encode("latin-1")].decode("latin-1")
    assert got == "0af7651916cd43dd"


def test_middleware_passes_through_non_http() -> None:
    """Lifespan/websocket paths must not be intercepted."""
    async def downstream(scope, receive, send):  # noqa: ANN001
        await send({"type": "lifespan.startup.complete"})

    sent: list[dict[str, Any]] = []
    async def receive():
        return {"type": "lifespan.startup"}
    async def send(message):
        sent.append(message)

    mw = RequestIdMiddleware(downstream)
    asyncio.run(mw({"type": "lifespan"}, receive, send))
    assert sent == [{"type": "lifespan.startup.complete"}]
