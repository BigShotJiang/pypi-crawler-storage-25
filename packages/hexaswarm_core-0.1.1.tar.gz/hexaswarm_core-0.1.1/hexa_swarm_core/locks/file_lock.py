"""
Atomic file-based locks for shared files (SYSTEM_STATE.md, contracts/*).

Uses `os.open(O_CREAT|O_EXCL)` — the only portable primitive that guarantees
race-free creation. Heartbeat support via a `.hb` side-file touched on a timer.
"""

from __future__ import annotations

import contextlib
import errno
import json
import logging
import os
import time
import uuid
from pathlib import Path

from hexa_swarm_core.exceptions import LockBusyError

logger = logging.getLogger("hexa.locks")

LOCK_DIR_REL = ".ai-sync/locks"

# Default staleness windows. Overridable via env for ops tuning.
DEFAULT_STALE_SECONDS = int(os.getenv("HEXA_LOCK_STALE_SECONDS", "3600"))
DEFAULT_HEARTBEAT_STALE = int(os.getenv("HEXA_LOCK_HEARTBEAT_STALE", "180"))


def _safe_target(target_file: str) -> str:
    return target_file.replace("/", "__").replace("\\", "__").strip(".")


def _lock_dir(project_root: Path) -> Path:
    d = project_root.resolve() / LOCK_DIR_REL
    d.mkdir(parents=True, exist_ok=True)
    return d


def acquire_lock(
    project_root: Path,
    target_file: str,
    *,
    agent: str,
    session_uuid: str | None = None,
    reason: str = "",
) -> Path:
    """Acquire an atomic lock. Raises LockBusyError if already held."""
    sid = session_uuid or os.getenv("HEXA_SESSION_UUID") or uuid.uuid4().hex[:12]
    path = _lock_dir(project_root) / f"{_safe_target(target_file)}_{agent}_{sid}.lock"
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except OSError as exc:
        if exc.errno == errno.EEXIST:
            raise LockBusyError(f"Lock already held: {path.name}") from exc
        raise
    try:
        payload = {
            "file": target_file,
            "agent": agent,
            "session": sid,
            "acquired_ts": time.time(),
            "reason": reason,
        }
        os.write(fd, json.dumps(payload, ensure_ascii=False).encode("utf-8"))
    finally:
        os.close(fd)
    return path


def release_lock(lock_path: Path) -> bool:
    hb = lock_path.with_suffix(lock_path.suffix + ".hb")
    released = False
    try:
        lock_path.unlink()
        released = True
    except FileNotFoundError:
        pass
    if hb.exists():
        with contextlib.suppress(FileNotFoundError):
            hb.unlink()
    return released


def heartbeat(lock_path: Path) -> None:
    """Touch the heartbeat side-file so stale-cleanup treats the holder as alive."""
    hb = lock_path.with_suffix(lock_path.suffix + ".hb")
    hb.touch(exist_ok=True)
    os.utime(hb, None)


def is_stale(
    lock_path: Path,
    *,
    stale_seconds: int = DEFAULT_STALE_SECONDS,
    heartbeat_stale: int = DEFAULT_HEARTBEAT_STALE,
    now: float | None = None,
) -> bool:
    """Staleness = mtime > stale_seconds, OR heartbeat file older than heartbeat_stale."""
    now = now or time.time()
    try:
        stat = lock_path.stat()
    except OSError:
        return False
    if now - stat.st_mtime > stale_seconds:
        return True
    hb = lock_path.with_suffix(lock_path.suffix + ".hb")
    if hb.exists():
        try:
            if now - hb.stat().st_mtime > heartbeat_stale:
                return True
        except OSError:
            return True
    return False


def cleanup_stale(
    project_root: Path,
    *,
    dry_run: bool = False,
    stale_seconds: int = DEFAULT_STALE_SECONDS,
    heartbeat_stale: int = DEFAULT_HEARTBEAT_STALE,
) -> list[Path]:
    """Remove stale locks. Returns list of removed paths."""
    d = project_root.resolve() / LOCK_DIR_REL
    if not d.exists():
        return []
    removed: list[Path] = []
    now = time.time()
    for lock in d.glob("*.lock"):
        if is_stale(lock, stale_seconds=stale_seconds, heartbeat_stale=heartbeat_stale, now=now):
            logger.warning("stale lock: %s (dry_run=%s)", lock, dry_run)
            if not dry_run:
                try:
                    lock.unlink()
                    hb = lock.with_suffix(lock.suffix + ".hb")
                    if hb.exists():
                        hb.unlink()
                    removed.append(lock)
                except OSError as exc:
                    logger.error("release fail %s: %s", lock, exc)
            else:
                removed.append(lock)
    return removed


__all__ = [
    "DEFAULT_HEARTBEAT_STALE",
    "DEFAULT_STALE_SECONDS",
    "LOCK_DIR_REL",
    "acquire_lock",
    "cleanup_stale",
    "heartbeat",
    "is_stale",
    "release_lock",
]
