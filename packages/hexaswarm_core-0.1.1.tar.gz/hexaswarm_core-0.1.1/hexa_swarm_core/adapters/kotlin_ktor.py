"""kotlin-ktor StackAdapter - Kotlin services using Ktor."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class KotlinKtorAdapter(BaseAdapter):
    name = "kotlin-ktor"
    language = "kotlin"
    detect_files = [
        "build.gradle.kts",
        "build.gradle",
        "settings.gradle.kts",
    ]
    detect_imports = ["io.ktor"]
    priority = 65

    @staticmethod
    def _gradle(project_root: Path) -> str:
        return "./gradlew" if (project_root / "gradlew").exists() else "gradle"

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:
        g = self._gradle(project_root)
        return [CommandSpec([g, "ktlintCheck"], description="ktlint")]

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:
        g = self._gradle(project_root)
        return [CommandSpec([g, "detekt"], description="detekt")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:
        g = self._gradle(project_root)
        return [CommandSpec([g, "compileKotlin", "--no-daemon"], description="kotlin compile")]

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:
        g = self._gradle(project_root)
        return [CommandSpec([g, "test", "--no-daemon"], description="gradle test")]

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:
        g = self._gradle(project_root)
        return [CommandSpec([g, "build", "-x", "test", "--no-daemon"], description="gradle build")]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:
        g = self._gradle(project_root)
        # Requires the OWASP dependency-check plugin; a no-op when absent.
        return [CommandSpec([g, "dependencyCheckAnalyze", "--no-daemon"], description="owasp dep-check")]

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return []


__all__ = ["KotlinKtorAdapter"]
