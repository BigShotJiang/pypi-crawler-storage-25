"""node-next StackAdapter - Next.js App Router projects."""

from __future__ import annotations

import json
from pathlib import Path

from hexa_swarm_core.adapters._node_base import NodeAdapterBase
from hexa_swarm_core.adapters.protocol import InvariantEnforcer


class NodeNextAdapter(NodeAdapterBase):
    name = "node-next"
    detect_files = [
        "package.json",
        "next.config.ts",
        "next.config.js",
        "next.config.mjs",
    ]
    detect_imports = ["next"]
    priority = 70

    def detect(self, project_root: Path) -> bool:
        if any((project_root / p).exists() for p in ("next.config.ts", "next.config.js", "next.config.mjs")):
            return True
        pkg = project_root / "package.json"
        if not pkg.exists():
            return False
        try:
            data = json.loads(pkg.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        deps = dict(data.get("dependencies") or {})
        deps.update(data.get("devDependencies") or {})
        return "next" in deps

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return []


__all__ = ["NodeNextAdapter"]
