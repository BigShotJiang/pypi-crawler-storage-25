"""go-chi StackAdapter - Go services using the chi router."""

from __future__ import annotations

import os
from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class GoChiAdapter(BaseAdapter):
    name = "go-chi"
    language = "go"
    detect_files = ["go.mod"]
    detect_imports = ["github.com/go-chi/chi"]
    priority = 65

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["golangci-lint", "run", "./..."], description="golangci-lint")]

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["gofmt", "-l", "."], description="gofmt -l (nonempty = drift)")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["go", "build", "-o", os.devnull, "./..."], description="go build (typecheck)")]

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["go", "test", "-race", "-count=1", "./..."], description="go test -race")]

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["go", "build", "./..."], description="go build")]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["govulncheck", "./..."], description="govulncheck")]

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return [
            InvariantEnforcer(
                invariant="S5",
                description="go vet must pass before merge",
                cmd=["go", "vet", "./..."],
            ),
        ]


__all__ = ["GoChiAdapter"]
