"""swift-vapor StackAdapter - Swift services using Vapor."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class SwiftVaporAdapter(BaseAdapter):
    name = "swift-vapor"
    language = "swift"
    detect_files = ["Package.swift"]
    detect_imports = ["vapor"]
    priority = 65

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["swiftlint", "--strict"], description="swiftlint --strict")]

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["swift-format", "lint", "--recursive", "Sources"], description="swift-format lint")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["swift", "build"], description="swift build (typecheck)")]

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["swift", "test", "--parallel"], description="swift test")]

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["swift", "build", "-c", "release"], description="swift build release")]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        # SwiftPM has no first-party vuln scanner - dumping the graph is the
        # closest reviewable approximation.
        return [CommandSpec(["swift", "package", "show-dependencies"], description="swift package show-dependencies")]

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return []


__all__ = ["SwiftVaporAdapter"]
