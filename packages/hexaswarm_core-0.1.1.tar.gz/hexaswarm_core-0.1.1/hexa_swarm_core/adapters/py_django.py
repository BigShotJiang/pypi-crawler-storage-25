"""py-django StackAdapter - Django web projects (views, ORM, manage.py)."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class PyDjangoAdapter(BaseAdapter):
    name = "py-django"
    language = "python"
    detect_files = [
        "manage.py",
        "pyproject.toml",
        "requirements.txt",
        "src/backend/manage.py",
        "src/backend/pyproject.toml",
        "backend/manage.py",
        "backend/pyproject.toml",
    ]
    detect_imports = ["django", "Django"]
    priority = 68  # just below py-fastapi so a polyglot repo prefers fastapi

    @staticmethod
    def _manage_root(project_root: Path) -> Path:
        for cand in (
            project_root / "src" / "backend",
            project_root / "backend",
            project_root,
        ):
            if (cand / "manage.py").exists():
                return cand
        return project_root

    def _cwd(self, project_root: Path) -> str | None:
        rel = self._manage_root(project_root).relative_to(project_root)
        s = str(rel)
        return s if s and s != "." else None

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:
        return [CommandSpec(["ruff", "check", "."], cwd=self._cwd(project_root), description="ruff check")]

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:
        return [CommandSpec(["ruff", "format", "--check", "."], cwd=self._cwd(project_root), description="ruff format")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:
        return [CommandSpec(["mypy", "."], cwd=self._cwd(project_root), description="mypy")]

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:
        return [
            CommandSpec(
                ["python", "manage.py", "test", "--noinput", "--parallel"],
                cwd=self._cwd(project_root),
                description="django test",
            )
        ]

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:
        # collectstatic is the closest thing Django has to a "build" step -
        # verifying it succeeds catches missing static files before deploy.
        return [
            CommandSpec(
                ["python", "manage.py", "collectstatic", "--noinput", "--dry-run"],
                cwd=self._cwd(project_root),
                description="django collectstatic --dry-run",
            )
        ]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:
        cwd = self._cwd(project_root)
        if (self._manage_root(project_root) / "requirements.txt").exists():
            return [
                CommandSpec(["python", "-m", "pip", "install", "--quiet", "pip-audit"], cwd=cwd, description="ensure pip-audit"),
                CommandSpec(["pip-audit", "-r", "requirements.txt"], cwd=cwd, description="pip-audit"),
            ]
        return [
            CommandSpec(["python", "-m", "pip", "install", "--quiet", "pip-audit"], cwd=cwd, description="ensure pip-audit"),
            CommandSpec(["pip-audit"], cwd=cwd, description="pip-audit (env)"),
        ]

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        # Django ships system checks that cover config drift, missing migrations,
        # permission misconfig, etc. Running them as an S5 guardrail keeps a
        # broken migration from landing on main.
        return [
            InvariantEnforcer(
                invariant="S5",
                description="Django system checks (deploy) + missing migrations",
                cmd=["python", "manage.py", "check", "--deploy"],
            ),
            InvariantEnforcer(
                invariant="S5",
                description="Makemigrations dry-run must report no pending changes",
                cmd=["python", "manage.py", "makemigrations", "--check", "--dry-run"],
            ),
        ]


__all__ = ["PyDjangoAdapter"]
