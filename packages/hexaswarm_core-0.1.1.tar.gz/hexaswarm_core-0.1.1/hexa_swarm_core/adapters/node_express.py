"""node-express StackAdapter - Express / Fastify / Koa style Node services."""

from __future__ import annotations

import json
from pathlib import Path

from hexa_swarm_core.adapters._node_base import NodeAdapterBase
from hexa_swarm_core.adapters.protocol import InvariantEnforcer


class NodeExpressAdapter(NodeAdapterBase):
    name = "node-express"
    detect_files = ["package.json"]
    detect_imports = ["express", "fastify", "koa"]
    priority = 58

    def detect(self, project_root: Path) -> bool:
        pkg = project_root / "package.json"
        if not pkg.exists():
            return False
        try:
            data = json.loads(pkg.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        deps = dict(data.get("dependencies") or {})
        deps.update(data.get("devDependencies") or {})
        # `next` and `@nestjs/*` are owned by dedicated adapters - opt out
        # so polyglot repos don't get this adapter attached twice.
        if "next" in deps or any(d.startswith("@nestjs/") for d in deps):
            return False
        return any(imp in deps for imp in self.detect_imports)

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return []


__all__ = ["NodeExpressAdapter"]
