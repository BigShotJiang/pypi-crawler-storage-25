"""generic-shell adapter — fallback for `hexa adopt` on unknown stacks.

Does not presume any linter/test runner. Reads `.hexa/profile.yaml` or a
`Makefile` for user-provided commands. Safe to use anywhere — just a thin
command registry that keeps the CLI interface uniform across stacks.
"""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec


class GenericShellAdapter(BaseAdapter):
    name = "generic-shell"
    language = "shell"
    detect_files = ["Makefile", "justfile", "Taskfile.yml"]
    priority = 5  # very low — only matches when nothing else does

    def detect(self, project_root: Path) -> bool:
        # Always available as an explicit fallback, but `detect()` only returns
        # True when a Make-like runner exists. Registry still allows forcing
        # this adapter via `--stack generic-shell`.
        return any((project_root / f).exists() for f in self.detect_files)

    def _make_cmd(self, target: str, description: str) -> list[CommandSpec]:
        return [CommandSpec(["make", target], description=description)]

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:
        return self._make_cmd("lint", "make lint") if (project_root / "Makefile").exists() else []

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:
        return self._make_cmd("fmt", "make fmt") if (project_root / "Makefile").exists() else []

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:
        return self._make_cmd("typecheck", "make typecheck") if (project_root / "Makefile").exists() else []

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:
        return self._make_cmd("test", "make test") if (project_root / "Makefile").exists() else []

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:
        return self._make_cmd("build", "make build") if (project_root / "Makefile").exists() else []


__all__ = ["GenericShellAdapter"]
