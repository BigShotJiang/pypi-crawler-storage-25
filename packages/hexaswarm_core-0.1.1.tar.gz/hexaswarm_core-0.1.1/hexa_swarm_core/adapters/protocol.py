"""
StackAdapter Protocol — the contract every language/framework adapter fulfils.

A polymorphic `quality-gate` / `contract-sync` / `invariants-check` command works
identically across Python, Node, Go, Rust, etc. — because it dispatches to the
adapter that matches the current project.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable


@dataclass(frozen=True)
class CommandSpec:
    """One shell invocation the adapter wants to run."""

    cmd: list[str]
    cwd: str | None = None  # relative to project root; None = project root
    env: dict[str, str] | None = None
    description: str = ""


@dataclass(frozen=True)
class InvariantEnforcer:
    """A check tied to a safety invariant (S1..S6) that an adapter wants to
    enforce on this stack. Runs within the quality-gate or a dedicated
    `invariants` job; failure is merge-blocking.
    """

    invariant: str  # e.g. "S1", "S3"
    description: str
    cmd: list[str]  # shell command; nonzero exit = violation


@runtime_checkable
class StackAdapter(Protocol):
    """Every adapter implements this. See `BaseAdapter` for a default skeleton."""

    name: str  # e.g. "py-fastapi", "node-next"
    language: str  # "python", "typescript", "go", ...
    detect_files: list[str]  # file globs whose presence indicates this stack
    detect_imports: list[str]  # optional: substrings that must appear in a detect_file
    priority: int  # higher wins when multiple adapters match

    def detect(self, project_root: Path) -> bool:
        """Return True if this adapter applies to the given project root."""
        ...

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]: ...
    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]: ...
    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]: ...
    def test_cmd(self, project_root: Path) -> list[CommandSpec]: ...
    def build_cmd(self, project_root: Path) -> list[CommandSpec]: ...
    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]: ...

    def contract_generator(self, project_root: Path) -> CommandSpec | None:
        """Command that regenerates `.ai-sync/contracts/openapi.yaml` (or None)."""
        ...

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]: ...


__all__ = ["CommandSpec", "InvariantEnforcer", "StackAdapter"]
