"""rust-axum StackAdapter - Rust services using axum."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class RustAxumAdapter(BaseAdapter):
    name = "rust-axum"
    language = "rust"
    detect_files = ["Cargo.toml"]
    detect_imports = ["axum"]
    priority = 65

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        # -D warnings promotes warnings to errors; allowlists go in clippy.toml.
        return [
            CommandSpec(
                ["cargo", "clippy", "--all-targets", "--all-features", "--", "-D", "warnings"],
                description="cargo clippy -D warnings",
            )
        ]

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["cargo", "fmt", "--all", "--check"], description="cargo fmt --check")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["cargo", "check", "--all-targets"], description="cargo check")]

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["cargo", "test", "--all-features"], description="cargo test")]

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["cargo", "build", "--release"], description="cargo build --release")]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["cargo", "audit"], description="cargo audit")]

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return []


__all__ = ["RustAxumAdapter"]
