"""Shared plumbing for Node-family adapters (next, nest, express)."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec


class NodeAdapterBase(BaseAdapter):
    """Base for Node/TS adapters - handles pnpm/yarn/npm dispatch uniformly."""

    language = "typescript"

    @staticmethod
    def _pm(project_root: Path) -> str:
        if (project_root / "pnpm-lock.yaml").exists():
            return "pnpm"
        if (project_root / "yarn.lock").exists():
            return "yarn"
        return "npm"

    def _run(self, project_root: Path, script: str) -> list[CommandSpec]:
        pm = self._pm(project_root)
        if pm == "pnpm":
            return [CommandSpec(["pnpm", "run", script], description=f"pnpm run {script}")]
        if pm == "yarn":
            return [CommandSpec(["yarn", script], description=f"yarn {script}")]
        return [CommandSpec(["npm", "run", script, "--if-present"], description=f"npm run {script}")]

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:
        return self._run(project_root, "lint")

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:
        return self._run(project_root, "test")

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:
        return self._run(project_root, "build")

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:
        pm = self._pm(project_root)
        if pm == "pnpm":
            return [CommandSpec(["pnpm", "exec", "prettier", "--check", "."], description="prettier --check")]
        if pm == "yarn":
            return [CommandSpec(["yarn", "prettier", "--check", "."], description="yarn prettier --check")]
        return [CommandSpec(["npx", "--yes", "prettier", "--check", "."], description="npx prettier --check")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:
        pm = self._pm(project_root)
        if pm == "pnpm":
            return [CommandSpec(["pnpm", "exec", "tsc", "--noEmit"], description="tsc --noEmit")]
        if pm == "yarn":
            return [CommandSpec(["yarn", "tsc", "--noEmit"], description="yarn tsc --noEmit")]
        return [CommandSpec(["npx", "--yes", "tsc", "--noEmit"], description="npx tsc --noEmit")]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:
        pm = self._pm(project_root)
        if pm == "pnpm":
            return [CommandSpec(["pnpm", "audit", "--audit-level=high"], description="pnpm audit")]
        if pm == "yarn":
            return [CommandSpec(["yarn", "npm", "audit", "--severity", "high"], description="yarn npm audit")]
        return [CommandSpec(["npm", "audit", "--audit-level=high"], description="npm audit")]


__all__ = ["NodeAdapterBase"]
