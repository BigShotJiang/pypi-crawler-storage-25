"""py-click StackAdapter — Python CLI tools built with Click or Typer."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class PyClickAdapter(BaseAdapter):
    name = "py-click"
    language = "python"
    # CLI-only projects live at the repo root; monorepos may nest backends.
    # Accept both layouts so a fullstack repo with click under src/backend
    # still surfaces the adapter (below fastapi's priority, so it only fires
    # as a fallback or for repos with no fastapi dep).
    detect_files = [
        "pyproject.toml",
        "requirements.txt",
        "setup.py",
        "setup.cfg",
        "src/backend/pyproject.toml",
        "src/backend/requirements.txt",
        "backend/pyproject.toml",
        "backend/requirements.txt",
    ]
    detect_imports = ["click", "typer"]  # typer is a click superset
    # Lower than py-fastapi so fullstack projects that also import click
    # (e.g. for a `manage.py`) don't steal the adapter slot.
    priority = 55

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["ruff", "check", "."], description="ruff check")]

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["ruff", "format", "--check", "."], description="ruff format")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["mypy", "."], description="mypy")]

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [
            CommandSpec(
                ["pytest", "-m", "not slow and not e2e", "-q", "--timeout=30"],
                description="pytest",
            )
        ]

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        # Optional: produce a wheel so distribution smoke is part of the gate.
        return [CommandSpec(["python", "-m", "pip", "wheel", "--no-deps", "."], description="pip wheel")]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:
        if (project_root / "requirements.txt").exists():
            return [
                CommandSpec(["python", "-m", "pip", "install", "--quiet", "pip-audit"], description="ensure pip-audit"),
                CommandSpec(["pip-audit", "-r", "requirements.txt"], description="pip-audit"),
            ]
        return [
            CommandSpec(["python", "-m", "pip", "install", "--quiet", "pip-audit"], description="ensure pip-audit"),
            CommandSpec(["pip-audit"], description="pip-audit (env)"),
        ]

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return [
            InvariantEnforcer(
                invariant="S2",
                description="CLI functions marked @deterministic must remain deterministic",
                cmd=["pytest", "-m", "invariants and deterministic", "-q"],
            )
        ]


__all__ = ["PyClickAdapter"]
