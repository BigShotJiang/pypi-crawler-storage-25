"""py-celery StackAdapter - Celery workers / Airflow / staged Python pipelines."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class PyCeleryAdapter(BaseAdapter):
    name = "py-celery"
    language = "python"
    detect_files = [
        "pyproject.toml",
        "requirements.txt",
        "src/backend/pyproject.toml",
        "src/backend/requirements.txt",
        "backend/pyproject.toml",
        "backend/requirements.txt",
    ]
    # airflow shares the "staged pipeline" archetype shape; also route to this.
    detect_imports = ["celery", "apache-airflow", "prefect"]
    # Below fastapi (70): a FastAPI app with celery workers should still be
    # identified as py-fastapi primarily, with py-celery as an add-on.
    priority = 60

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["ruff", "check", "."], description="ruff check")]

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["ruff", "format", "--check", "."], description="ruff format")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [CommandSpec(["mypy", "."], description="mypy")]

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return [
            CommandSpec(
                ["pytest", "-m", "not slow and not e2e", "-q", "--timeout=60"],
                description="pytest (pipeline tests)",
            )
        ]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:
        if (project_root / "requirements.txt").exists():
            return [
                CommandSpec(["python", "-m", "pip", "install", "--quiet", "pip-audit"], description="ensure pip-audit"),
                CommandSpec(["pip-audit", "-r", "requirements.txt"], description="pip-audit"),
            ]
        return [
            CommandSpec(["python", "-m", "pip", "install", "--quiet", "pip-audit"], description="ensure pip-audit"),
            CommandSpec(["pip-audit"], description="pip-audit (env)"),
        ]

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        # S3 (idempotency) is critical for pipeline stages - if a stage retries
        # after a killswitch, it must not double-charge / double-write.
        return [
            InvariantEnforcer(
                invariant="S3",
                description="Pipeline stages marked @idempotent must pass resume-safety checks",
                cmd=["pytest", "-m", "invariants and idempotent", "-q"],
            ),
        ]


__all__ = ["PyCeleryAdapter"]
