"""py-fastapi StackAdapter — FastAPI + pyproject.toml + ruff + mypy + pytest."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.base import BaseAdapter
from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class PyFastAPIAdapter(BaseAdapter):
    name = "py-fastapi"
    language = "python"
    detect_files = [
        "src/backend/pyproject.toml",
        "src/backend/requirements.txt",
        "backend/pyproject.toml",
        "backend/requirements.txt",
        "pyproject.toml",
        "requirements.txt",
    ]
    detect_imports = ["fastapi"]
    priority = 70

    # Most hexa-swarm projects keep the backend under `src/backend/`.
    # Fall back to the project root if that directory doesn't exist.
    def _backend_root(self, project_root: Path) -> Path:
        candidates = [
            project_root / "src" / "backend",
            project_root / "backend",
            project_root,
        ]
        for c in candidates:
            if (c / "pyproject.toml").exists():
                return c
        return project_root

    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:
        cwd = str(self._backend_root(project_root).relative_to(project_root)) or None
        return [CommandSpec(["ruff", "check", "."], cwd=cwd, description="ruff check")]

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:
        cwd = str(self._backend_root(project_root).relative_to(project_root)) or None
        return [CommandSpec(["ruff", "format", "--check", "."], cwd=cwd, description="ruff format")]

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:
        cwd = str(self._backend_root(project_root).relative_to(project_root)) or None
        return [CommandSpec(["mypy", ".", "--config-file", "pyproject.toml"], cwd=cwd, description="mypy --strict")]

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:
        cwd = str(self._backend_root(project_root).relative_to(project_root)) or None
        return [
            CommandSpec(
                ["pytest", "-m", "not slow and not e2e", "-q", "--timeout=30"],
                cwd=cwd,
                description="pytest (unit+security)",
            )
        ]

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:
        cwd = str(self._backend_root(project_root).relative_to(project_root)) or None
        return [
            CommandSpec(
                ["python", "-m", "pip", "install", "--quiet", "pip-audit"],
                cwd=cwd,
                description="ensure pip-audit",
            ),
            CommandSpec(["pip-audit", "-r", "requirements.txt"], cwd=cwd, description="pip-audit"),
        ]

    def contract_generator(self, project_root: Path) -> CommandSpec | None:
        backend = self._backend_root(project_root)
        gen = project_root / "scripts" / "gen_openapi.py"
        if not gen.exists():
            return None
        cwd = str(backend.relative_to(project_root)) or None
        return CommandSpec(
            ["python", str(gen.resolve())],
            cwd=cwd,
            description="regenerate .ai-sync/contracts/openapi.yaml",
        )

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        # W3에서 AST 기반 검증 추가 예정. W1은 pytest invariants 마커에 위임.
        return [
            InvariantEnforcer(
                invariant="S6",
                description="Prompt-injection sanitize_for_prompt coverage (pytest -m invariants)",
                cmd=["pytest", "-m", "invariants", "-q"],
            ),
        ]


__all__ = ["PyFastAPIAdapter"]
