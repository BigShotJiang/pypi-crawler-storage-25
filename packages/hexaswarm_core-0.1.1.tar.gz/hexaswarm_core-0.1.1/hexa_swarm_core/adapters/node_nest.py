"""node-nest StackAdapter - NestJS backend services."""

from __future__ import annotations

import json
from pathlib import Path

from hexa_swarm_core.adapters._node_base import NodeAdapterBase
from hexa_swarm_core.adapters.protocol import InvariantEnforcer


class NodeNestAdapter(NodeAdapterBase):
    name = "node-nest"
    detect_files = ["package.json", "nest-cli.json"]
    detect_imports = ["@nestjs/core", "@nestjs/common"]
    priority = 68

    def detect(self, project_root: Path) -> bool:
        if (project_root / "nest-cli.json").exists():
            return True
        pkg = project_root / "package.json"
        if not pkg.exists():
            return False
        try:
            data = json.loads(pkg.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        deps = dict(data.get("dependencies") or {})
        deps.update(data.get("devDependencies") or {})
        return any(d.startswith("@nestjs/") for d in deps)

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return []


__all__ = ["NodeNestAdapter"]
