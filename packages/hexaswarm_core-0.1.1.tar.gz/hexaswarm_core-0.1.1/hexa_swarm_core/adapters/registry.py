"""Adapter registry + autodetect."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.generic_shell import GenericShellAdapter
from hexa_swarm_core.adapters.go_chi import GoChiAdapter
from hexa_swarm_core.adapters.kotlin_ktor import KotlinKtorAdapter
from hexa_swarm_core.adapters.node_express import NodeExpressAdapter
from hexa_swarm_core.adapters.node_nest import NodeNestAdapter
from hexa_swarm_core.adapters.node_next import NodeNextAdapter
from hexa_swarm_core.adapters.protocol import StackAdapter
from hexa_swarm_core.adapters.py_celery import PyCeleryAdapter
from hexa_swarm_core.adapters.py_click import PyClickAdapter
from hexa_swarm_core.adapters.py_django import PyDjangoAdapter
from hexa_swarm_core.adapters.py_fastapi import PyFastAPIAdapter
from hexa_swarm_core.adapters.rust_axum import RustAxumAdapter
from hexa_swarm_core.adapters.swift_vapor import SwiftVaporAdapter
from hexa_swarm_core.exceptions import AdapterError

# Registry - priority ordering tiebreaks `detect_adapters`.
ADAPTERS: tuple[StackAdapter, ...] = (
    PyFastAPIAdapter(),
    NodeNextAdapter(),
    PyDjangoAdapter(),
    NodeNestAdapter(),
    GoChiAdapter(),
    RustAxumAdapter(),
    KotlinKtorAdapter(),
    SwiftVaporAdapter(),
    PyCeleryAdapter(),
    NodeExpressAdapter(),
    PyClickAdapter(),
    GenericShellAdapter(),
)


def get_adapter(name: str) -> StackAdapter:
    for a in ADAPTERS:
        if a.name == name:
            return a
    raise AdapterError(f"Unknown adapter: {name!r}. Known: {[a.name for a in ADAPTERS]}")


def detect_adapters(project_root: Path) -> list[StackAdapter]:
    """Return matching adapters sorted by descending priority (first match first).

    Callers typically pick the head of this list, but for polyglot repos
    (FastAPI backend + Next frontend) they may want to run multiple.
    """
    project_root = project_root.resolve()
    matches = [a for a in ADAPTERS if a.detect(project_root)]
    matches.sort(key=lambda a: a.priority, reverse=True)
    return matches


__all__ = ["ADAPTERS", "detect_adapters", "get_adapter"]
