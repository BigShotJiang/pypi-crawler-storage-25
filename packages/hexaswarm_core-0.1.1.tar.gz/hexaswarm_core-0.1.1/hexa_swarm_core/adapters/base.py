"""BaseAdapter — a default skeleton most adapters can subclass."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.adapters.protocol import CommandSpec, InvariantEnforcer


class BaseAdapter:
    """Common adapter plumbing.

    Subclasses override attributes (name, language, detect_files, detect_imports,
    priority) and `_*_cmd()` methods as needed. Default implementations return
    empty lists — "no-op" is a valid adapter stance for a stage it doesn't own.
    """

    name: str = "base"
    language: str = "unknown"
    detect_files: list[str] = []
    detect_imports: list[str] = []
    priority: int = 0

    # -- detection --------------------------------------------------------
    def detect(self, project_root: Path) -> bool:
        if not self.detect_files:
            return False
        matched: list[Path] = []
        for glob in self.detect_files:
            matched.extend(project_root.glob(glob))
        if not matched:
            return False
        if not self.detect_imports:
            return True
        for path in matched:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if any(imp in text for imp in self.detect_imports):
                return True
        return False

    # -- commands (override in subclasses) --------------------------------
    def lint_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return []

    def format_check_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return []

    def typecheck_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return []

    def test_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return []

    def build_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return []

    def dep_audit_cmd(self, project_root: Path) -> list[CommandSpec]:  # noqa: ARG002
        return []

    def contract_generator(self, project_root: Path) -> CommandSpec | None:  # noqa: ARG002
        return None

    def invariant_enforcers(self, project_root: Path) -> list[InvariantEnforcer]:  # noqa: ARG002
        return []


__all__ = ["BaseAdapter"]
