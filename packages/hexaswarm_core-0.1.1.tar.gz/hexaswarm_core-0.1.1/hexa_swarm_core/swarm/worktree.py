"""
Worktree orchestration — physical isolation for parallel agents.

Uses git worktrees in a SIBLING directory (`../<slug>-wt/<agent>-<session>/`)
rather than a nested `.worktrees/` folder so Windows symlink handling stays
predictable.

Every worktree gets its own session-scoped branch
(`sess/<session_uuid>-<agent>`) so parallel writers can never commit to the
same branch by accident.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path

logger = logging.getLogger("hexa.swarm.worktree")


@dataclass
class WorktreeHandle:
    repo: Path          # main repo path
    path: Path          # worktree path (sibling dir)
    branch: str
    agent: str
    session: str

    def to_dict(self) -> dict[str, str]:
        d = asdict(self)
        for k, v in d.items():
            if isinstance(v, Path):
                d[k] = str(v)
        return d


def _run_git(args: list[str], cwd: Path) -> tuple[int, str, str]:
    try:
        proc = subprocess.run(  # noqa: S603
            ["git", *args],
            cwd=str(cwd),
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("git is not installed or not on PATH") from exc
    return proc.returncode, proc.stdout, proc.stderr


def _wt_parent(repo: Path) -> Path:
    return repo.parent / f"{repo.name}-wt"


def boot_worktree(
    repo: Path | str,
    *,
    agent: str,
    session: str,
    base: str = "HEAD",
) -> WorktreeHandle:
    """Create a sibling-dir worktree for one agent + one session."""
    repo_path = Path(repo).resolve()
    if not (repo_path / ".git").exists():
        raise RuntimeError(f"{repo_path} is not a git repo")

    wt_parent = _wt_parent(repo_path)
    wt_parent.mkdir(parents=True, exist_ok=True)
    wt_path = wt_parent / f"{agent}-{session}"
    # Slash between session and agent so agents with hyphens round-trip cleanly.
    branch = f"sess/{session}/{agent}"

    if wt_path.exists():
        raise RuntimeError(f"worktree path already exists: {wt_path}")

    rc, out, err = _run_git(
        ["worktree", "add", "-b", branch, str(wt_path), base],
        cwd=repo_path,
    )
    if rc != 0:
        raise RuntimeError(f"git worktree add failed: {err.strip() or out.strip()}")

    logger.info("worktree booted: %s @ %s (branch=%s)", agent, wt_path, branch)
    return WorktreeHandle(
        repo=repo_path,
        path=wt_path,
        branch=branch,
        agent=agent,
        session=session,
    )


def teardown_worktree(handle: WorktreeHandle, *, delete_branch: bool = True) -> None:
    """Remove the worktree and (optionally) the session branch."""
    rc, _, err = _run_git(
        ["worktree", "remove", "--force", str(handle.path)],
        cwd=handle.repo,
    )
    if rc != 0 and handle.path.exists():
        # Fallback: force-remove directory
        shutil.rmtree(handle.path, ignore_errors=True)
        logger.warning("worktree remove fallback via shutil: %s", err.strip())

    if delete_branch:
        _run_git(["branch", "-D", handle.branch], cwd=handle.repo)


def list_worktrees(repo: Path | str) -> list[WorktreeHandle]:
    """Parse `git worktree list --porcelain` into handles for hexa-managed worktrees."""
    repo_path = Path(repo).resolve()
    rc, out, _ = _run_git(["worktree", "list", "--porcelain"], cwd=repo_path)
    if rc != 0:
        return []
    handles: list[WorktreeHandle] = []
    current: dict[str, str] = {}
    for line in out.splitlines() + [""]:
        if not line:
            if current and "worktree" in current:
                wt_path = Path(current["worktree"]).resolve()
                branch = current.get("branch", "").removeprefix("refs/heads/")
                # Format: sess/<session>/<agent>
                if branch.startswith("sess/") and branch.count("/") >= 2:
                    _, session, agent = branch.split("/", 2)
                    handles.append(
                        WorktreeHandle(
                            repo=repo_path,
                            path=wt_path,
                            branch=branch,
                            agent=agent,
                            session=session,
                        )
                    )
            current = {}
        else:
            key, _, val = line.partition(" ")
            current[key] = val
    return handles


__all__ = ["WorktreeHandle", "boot_worktree", "list_worktrees", "teardown_worktree"]
