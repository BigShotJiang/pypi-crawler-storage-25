"""
Heartbeat loop for active locks — keeps `{lock}.hb` files fresh so the
cleanup logic doesn't mark long-running sessions as stale.

Design:
- `heartbeat_once()` touches every `.lock` in `.ai-sync/locks/` that matches
  the current session's UUID (only our own session's locks).
- `heartbeat_loop()` is the long-running daemon; exits cleanly on
  SIGINT/SIGTERM or when the kill switch engages.
"""

from __future__ import annotations

import contextlib
import logging
import signal
import time
from pathlib import Path

from hexa_swarm_core.locks.file_lock import LOCK_DIR_REL
from hexa_swarm_core.safety.killswitch import KillSwitch
from hexa_swarm_core.session import current_session

logger = logging.getLogger("hexa.swarm.heartbeat")


def heartbeat_once(project_root: Path | str) -> list[Path]:
    """Touch `.hb` files for every lock owned by the current session. Returns the list touched."""
    root = Path(project_root).resolve()
    session = current_session(root)
    lock_dir = root / LOCK_DIR_REL
    if not lock_dir.exists():
        return []
    touched: list[Path] = []
    for lock in lock_dir.glob(f"*_{session}.lock"):
        hb = lock.with_suffix(lock.suffix + ".hb")
        hb.touch(exist_ok=True)
        touched.append(hb)
    return touched


def heartbeat_loop(
    project_root: Path | str,
    *,
    interval_s: float = 60.0,
    max_iterations: int | None = None,
) -> int:
    """Run until interrupted or killswitch engaged. Returns iteration count."""
    root = Path(project_root).resolve()
    ks = KillSwitch(root)
    stop = {"flag": False}

    def _handler(signum, _frame):  # noqa: ANN001
        logger.info("heartbeat loop signal %s received, exiting", signum)
        stop["flag"] = True

    for sig in (signal.SIGINT, signal.SIGTERM):
        # Not main thread on Windows, etc. — fine, we can still loop.
        with contextlib.suppress(ValueError, OSError):
            signal.signal(sig, _handler)

    count = 0
    while not stop["flag"]:
        if ks.is_active():
            logger.warning("heartbeat loop stopping — kill switch engaged")
            break
        touched = heartbeat_once(root)
        if touched:
            logger.debug("heartbeat touched %d lock(s)", len(touched))
        count += 1
        if max_iterations is not None and count >= max_iterations:
            break
        time.sleep(interval_s)
    return count


__all__ = ["heartbeat_loop", "heartbeat_once"]
