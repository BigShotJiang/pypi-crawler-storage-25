"""
Contract-writer queue — proposals for `.ai-sync/contracts/*` changes.

Rule: only the Orchestrator (human or CI) commits contract changes. Other
agents append a proposal to `.ai-sync/events/CONTRACT_PROPOSAL_*.md` and
notify the Orchestrator. This module is the queue primitive — propose,
list, mark-applied. Actual patch application is deferred to the
Orchestrator's `/contract-sync` skill.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

EVENTS_DIR_REL = ".ai-sync/events"
ARCHIVE_SUBDIR = "archive"


@dataclass
class ContractProposal:
    path: Path
    target_file: str
    proposer: str
    summary: str
    created_ts: str
    diff: str = ""

    @classmethod
    def parse(cls, path: Path) -> ContractProposal:
        text = path.read_text(encoding="utf-8", errors="ignore")
        meta = {"target_file": "", "proposer": "", "summary": "", "created_ts": ""}
        diff_lines: list[str] = []
        in_diff = False
        for line in text.splitlines():
            if in_diff:
                diff_lines.append(line)
                continue
            if line.startswith("```diff"):
                in_diff = True
                continue
            for key in meta:
                prefix = f"- {key}: "
                if line.startswith(prefix):
                    meta[key] = line[len(prefix):].strip()
        return cls(
            path=path,
            target_file=meta["target_file"],
            proposer=meta["proposer"],
            summary=meta["summary"],
            created_ts=meta["created_ts"],
            diff="\n".join(diff_lines).rstrip("`\n "),
        )


def _slug(text: str, max_len: int = 40) -> str:
    s = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in text.lower())
    s = "-".join(filter(None, s.split("-")))
    return s[:max_len] or "proposal"


def propose_contract_change(
    project_root: Path | str,
    *,
    target_file: str,
    proposer: str,
    summary: str,
    diff: str = "",
) -> Path:
    """Write a proposal markdown into `.ai-sync/events/`. Returns the new path."""
    root = Path(project_root).resolve()
    events = root / EVENTS_DIR_REL
    events.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(UTC).strftime("%Y-%m-%dT%H-%M-%SZ")
    name = f"CONTRACT_PROPOSAL_{ts}_{_slug(summary or target_file)}.md"
    path = events / name

    body = [
        f"# Contract proposal — {target_file}",
        "",
        f"- target_file: {target_file}",
        f"- proposer: {proposer}",
        f"- summary: {summary}",
        f"- created_ts: {datetime.now(UTC).isoformat()}",
        "",
    ]
    if diff:
        body += ["```diff", diff.rstrip(), "```", ""]
    path.write_text("\n".join(body), encoding="utf-8")
    return path


def list_proposals(project_root: Path | str, *, include_applied: bool = False) -> list[ContractProposal]:
    root = Path(project_root).resolve()
    events = root / EVENTS_DIR_REL
    if not events.exists():
        return []
    out: list[ContractProposal] = []
    for p in sorted(events.glob("CONTRACT_PROPOSAL_*.md")):
        out.append(ContractProposal.parse(p))
    if include_applied:
        archive = events / ARCHIVE_SUBDIR
        if archive.exists():
            for p in sorted(archive.glob("CONTRACT_PROPOSAL_*.md")):
                out.append(ContractProposal.parse(p))
    return out


def mark_applied(proposal_path: Path) -> Path:
    """Move a proposal into events/archive/ to signal it was applied."""
    archive = proposal_path.parent / ARCHIVE_SUBDIR
    archive.mkdir(parents=True, exist_ok=True)
    dest = archive / proposal_path.name
    proposal_path.rename(dest)
    return dest


__all__ = [
    "ARCHIVE_SUBDIR",
    "ContractProposal",
    "EVENTS_DIR_REL",
    "list_proposals",
    "mark_applied",
    "propose_contract_change",
]
