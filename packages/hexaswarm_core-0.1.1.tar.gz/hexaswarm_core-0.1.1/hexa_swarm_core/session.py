"""Session UUID — written once per interactive session, read by hooks/locks."""

from __future__ import annotations

import os
import uuid
from pathlib import Path

SESSION_FILE_REL = ".ai-sync/session.uuid"
SESSION_ENV = "HEXA_SESSION_UUID"


def session_path(project_root: Path) -> Path:
    return project_root.resolve() / SESSION_FILE_REL


def init_session(project_root: Path, *, force: bool = False) -> str:
    """Create `.ai-sync/session.uuid` if missing. Returns the UUID."""
    path = session_path(project_root)
    if path.exists() and not force:
        uid = path.read_text(encoding="utf-8").strip()
        if uid:
            os.environ.setdefault(SESSION_ENV, uid)
            return uid
    path.parent.mkdir(parents=True, exist_ok=True)
    uid = uuid.uuid4().hex[:12]
    path.write_text(uid, encoding="utf-8")
    os.environ[SESSION_ENV] = uid
    return uid


def current_session(project_root: Path | None = None) -> str:
    """Return the session UUID. Priority: env > file > generate (non-persistent)."""
    env = os.getenv(SESSION_ENV)
    if env:
        return env
    if project_root is not None:
        path = session_path(project_root)
        if path.exists():
            uid = path.read_text(encoding="utf-8").strip()
            if uid:
                os.environ[SESSION_ENV] = uid
                return uid
    return uuid.uuid4().hex[:12]


def end_session(project_root: Path) -> None:
    """Clear the session file. Hook-safe (idempotent)."""
    path = session_path(project_root)
    if path.exists():
        path.unlink()
    os.environ.pop(SESSION_ENV, None)


__all__ = ["SESSION_ENV", "SESSION_FILE_REL", "current_session", "end_session", "init_session", "session_path"]
