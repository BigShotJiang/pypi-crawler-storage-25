"""
CostTracker — append-only JSONL ledger for LLM / service costs.

Originally pulled from ai-video's `src/utils/cost_tracker.py` and generalised.
Every adapter/provider response should carry `cost_usd`; the tracker is the
single place they funnel into for per-project, per-stage rollups.
"""

from __future__ import annotations

import json
import threading
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

DEFAULT_LEDGER_REL = ".ai-sync/logs/cost.jsonl"


@dataclass
class CostEntry:
    timestamp: str
    project_id: str
    stage: str
    service: str
    operation: str
    cost_usd: float
    details: dict[str, Any] = field(default_factory=dict)


class CostTracker:
    """Thread-safe append-only JSONL writer."""

    def __init__(self, ledger_path: Path | str = DEFAULT_LEDGER_REL) -> None:
        self._ledger = Path(ledger_path)
        self._lock = threading.Lock()

    @property
    def ledger(self) -> Path:
        return self._ledger

    def record(
        self,
        *,
        project_id: str,
        stage: str,
        service: str,
        operation: str,
        cost_usd: float,
        **details: Any,
    ) -> CostEntry:
        entry = CostEntry(
            timestamp=datetime.now(UTC).isoformat(),
            project_id=project_id,
            stage=stage,
            service=service,
            operation=operation,
            cost_usd=float(cost_usd),
            details=dict(details),
        )
        with self._lock:
            self._ledger.parent.mkdir(parents=True, exist_ok=True)
            with self._ledger.open("a", encoding="utf-8") as f:
                f.write(json.dumps(asdict(entry), ensure_ascii=False) + "\n")
        return entry

    def total(
        self,
        *,
        project_id: str | None = None,
        stage: str | None = None,
    ) -> float:
        if not self._ledger.exists():
            return 0.0
        total = 0.0
        with self._ledger.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if project_id is not None and e.get("project_id") != project_id:
                    continue
                if stage is not None and e.get("stage") != stage:
                    continue
                total += float(e.get("cost_usd", 0.0))
        return total


_default_tracker: CostTracker | None = None


def default_tracker(ledger_path: Path | str = DEFAULT_LEDGER_REL) -> CostTracker:
    global _default_tracker
    if _default_tracker is None or Path(_default_tracker.ledger) != Path(ledger_path):
        _default_tracker = CostTracker(ledger_path)
    return _default_tracker


__all__ = ["CostEntry", "CostTracker", "DEFAULT_LEDGER_REL", "default_tracker"]
