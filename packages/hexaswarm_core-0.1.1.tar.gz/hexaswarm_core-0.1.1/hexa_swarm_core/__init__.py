"""hexa_swarm_core — Universal primitives for Claude-native multi-agent delivery."""

from __future__ import annotations

from hexa_swarm_core._version import __version__

__all__ = ["__version__"]
