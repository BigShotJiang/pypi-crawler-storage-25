"""`hexa adopt` — non-destructive retrofit for an existing repo (full install).

Archetype-aware as of W6: when an archetype is selected (explicit or
auto-inferred), its `default_feature_flags` seed `profile.feature_flags`
and its id is written into `profile.archetype`. The CI workflow list is
stored in `profile.ci_workflows` so later tooling knows which .yml to keep.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer

from hexa_swarm_core.adapters import detect_adapters, get_adapter
from hexa_swarm_core.archetypes import ARCHETYPE_IDS, detect_archetype, get_archetype
from hexa_swarm_core.exceptions import HexaError
from hexa_swarm_core.install import install as tier_a_install
from hexa_swarm_core.install import plan as tier_a_plan
from hexa_swarm_core.profile import (
    init_profile,
    profile_path,
    save_profile,
)
from hexa_swarm_core.session import init_session


def adopt_cmd(
    path: Path = typer.Argument(Path("."), help="Project root to adopt."),
    archetype: str | None = typer.Option(None, help=f"One of: {', '.join(ARCHETYPE_IDS)}"),
    stack: list[str] = typer.Option([], "--stack", help="Force adapter(s). Repeatable."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Print what would change without writing."),
    force: bool = typer.Option(False, "--force", help="Overwrite existing files + profile."),
    skip_install: bool = typer.Option(
        False,
        "--skip-install",
        help="Do not copy Tier A assets. Only write .hexa/profile.yaml + session.",
    ),
) -> None:
    """Adopt the repo at PATH. Writes `.hexa/profile.yaml`, `.ai-sync/session.uuid`,
    and copies Tier A assets (`.claude/`, `.ai-sync/` skeleton) unless `--skip-install`.
    Existing code is never modified.
    """
    root = path.resolve()
    if not root.exists():
        typer.echo(f"error: {root} does not exist", err=True)
        raise typer.Exit(code=2)

    # --- Stack adapters ------------------------------------------------
    if stack:
        adapters = [get_adapter(name) for name in stack]
    else:
        adapters = detect_adapters(root)
    adapter_names = [a.name for a in adapters]

    # --- Archetype (explicit or auto-inferred) -------------------------
    try:
        arch_id = archetype or detect_archetype(root, adapter_names)
        arch = get_archetype(arch_id)
    except HexaError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(code=2) from exc

    # If no stacks were forced / detected, fall back to archetype defaults.
    if not adapter_names and arch.default_stacks:
        adapter_names = list(arch.default_stacks)

    typer.echo(f"project_root:  {root}")
    typer.echo(f"archetype:     {arch.id}")
    typer.echo(f"detected:      {adapter_names or ['(none - use --stack to force)']}")

    # --- Tier A install plan/apply -------------------------------------
    install_result: Any | None = None
    if not skip_install:
        tier_plan = tier_a_plan(root, force=force)
        typer.echo(
            f"tier A:        create={len(tier_plan.will_create)} "
            f"overwrite={len(tier_plan.will_overwrite)} skip={len(tier_plan.will_skip)}",
        )
        if dry_run and tier_plan.files_touched:
            for rel in list(tier_plan.files_touched)[:10]:
                typer.echo(f"  + {rel}")
            if len(tier_plan.files_touched) > 10:
                typer.echo(f"  ... ({len(tier_plan.files_touched) - 10} more)")

    # --- Profile (seed feature flags from archetype) -------------------
    profile = init_profile(
        project_root=root,
        archetype=arch.id,
        stacks=adapter_names,
        adapters_enabled=adapter_names,
        feature_flags=dict(arch.default_feature_flags),
    )
    typer.echo(f"invariants:    {profile.invariants}")
    typer.echo(f"feature_flags: {profile.feature_flags}")
    typer.echo(f"profile path:  {profile_path(root)}")

    if dry_run:
        typer.echo("dry-run: no files written.")
        raise typer.Exit(code=0)

    pp = profile_path(root)
    if pp.exists() and not force:
        typer.echo(f"error: {pp} already exists. Use --force to overwrite.", err=True)
        raise typer.Exit(code=1)

    # --- Install -------------------------------------------------------
    if not skip_install:
        install_result = tier_a_install(root, force=force, dry_run=False)
        profile.feature_flags.setdefault("has_tier_a", True)
        profile.__pydantic_extra__["installed_assets"] = install_result.installed_assets  # type: ignore[index]
        profile.__pydantic_extra__["ci_workflows"] = list(arch.ci_workflows)  # type: ignore[index]

    save_profile(root, profile)
    sid = init_session(root)
    typer.echo(f"wrote:         {pp}")
    typer.echo(f"session uuid:  {sid}")
    if install_result is not None:
        typer.echo(
            f"installed:     created={len(install_result.created)} "
            f"overwritten={len(install_result.overwritten)} "
            f"skipped={len(install_result.skipped)}",
        )
    typer.echo("done. next: `hexa quality-gate run`")
