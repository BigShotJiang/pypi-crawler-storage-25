"""`hexa cost` — record / summarise LLM + service costs."""

from __future__ import annotations

from pathlib import Path

import typer

from hexa_swarm_core.telemetry.cost import DEFAULT_LEDGER_REL, CostTracker

app = typer.Typer(help="LLM / service cost tracker (JSONL append-only ledger).")


def _tracker(path: Path) -> CostTracker:
    return CostTracker(ledger_path=path)


@app.command("track")
def track_cmd(
    project_id: str = typer.Option(..., "--project-id"),
    stage: str = typer.Option(..., "--stage"),
    service: str = typer.Option(..., "--service"),
    operation: str = typer.Option("generate", "--operation"),
    cost_usd: float = typer.Option(..., "--cost"),
    model: str = typer.Option("", "--model"),
    tokens_in: int = typer.Option(0, "--tokens-in"),
    tokens_out: int = typer.Option(0, "--tokens-out"),
    ledger: Path = typer.Option(Path(DEFAULT_LEDGER_REL), "--ledger"),
) -> None:
    """Append one cost entry to the JSONL ledger."""
    t = _tracker(ledger)
    entry = t.record(
        project_id=project_id,
        stage=stage,
        service=service,
        operation=operation,
        cost_usd=cost_usd,
        model=model,
        tokens_in=tokens_in,
        tokens_out=tokens_out,
    )
    typer.echo(f"recorded: ${entry.cost_usd:.6f} ({entry.service}/{entry.stage})")


@app.command("summary")
def summary_cmd(
    project_id: str = typer.Option(None, "--project-id"),
    stage: str = typer.Option(None, "--stage"),
    ledger: Path = typer.Option(Path(DEFAULT_LEDGER_REL), "--ledger"),
) -> None:
    t = _tracker(ledger)
    total = t.total(project_id=project_id, stage=stage)
    typer.echo(f"total_usd: {total:.6f}")
