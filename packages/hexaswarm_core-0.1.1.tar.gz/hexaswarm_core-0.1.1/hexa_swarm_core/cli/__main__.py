"""Allow `python -m hexa_swarm_core.cli`."""

from hexa_swarm_core.cli.app import main

if __name__ == "__main__":
    main()
