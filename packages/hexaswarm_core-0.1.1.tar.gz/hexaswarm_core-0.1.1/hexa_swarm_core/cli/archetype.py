"""`hexa archetype` — list and inspect archetype definitions."""

from __future__ import annotations

import json

import typer

from hexa_swarm_core.archetypes import ARCHETYPES, get_archetype
from hexa_swarm_core.exceptions import HexaError

app = typer.Typer(help="List / inspect project archetypes.")


@app.command("list")
def list_cmd(as_json: bool = typer.Option(False, "--json", help="Emit JSON instead of a table.")) -> None:
    if as_json:
        typer.echo(json.dumps([a.summary() for a in ARCHETYPES], ensure_ascii=False, indent=2))
        return
    for a in ARCHETYPES:
        typer.echo(f"{a.id:15}  {a.description}")


@app.command("show")
def show_cmd(archetype_id: str = typer.Argument(..., help="Archetype id (see `hexa archetype list`).")) -> None:
    try:
        a = get_archetype(archetype_id)
    except HexaError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(code=2) from exc
    typer.echo(json.dumps(a.summary(), ensure_ascii=False, indent=2))
