"""
`hexa` CLI entry point — Typer app.

Wiring only. Individual command bodies live in sibling modules so each is
independently testable via typer.testing.CliRunner.
"""

from __future__ import annotations

import typer

from hexa_swarm_core import __version__
from hexa_swarm_core.cli import archetype as archetype_mod
from hexa_swarm_core.cli import contract as contract_mod
from hexa_swarm_core.cli import cost as cost_mod
from hexa_swarm_core.cli import heartbeat as heartbeat_mod
from hexa_swarm_core.cli import killswitch as killswitch_mod
from hexa_swarm_core.cli import lock as lock_mod
from hexa_swarm_core.cli import quality_gate as qg_mod
from hexa_swarm_core.cli import session as session_mod
from hexa_swarm_core.cli import worktree as worktree_mod
from hexa_swarm_core.cli.adopt import adopt_cmd

app = typer.Typer(
    name="hexa",
    help="Universal primitives for Claude-native multi-agent delivery.",
    no_args_is_help=True,
    add_completion=False,
)

# Single-verb command (direct):
app.command(name="adopt", help="Adopt an existing repo (Tier A only).")(adopt_cmd)

# Multi-verb command groups:
app.add_typer(session_mod.app, name="session")
app.add_typer(lock_mod.app, name="lock")
app.add_typer(qg_mod.app, name="quality-gate")
app.add_typer(cost_mod.app, name="cost")
app.add_typer(killswitch_mod.app, name="killswitch")
app.add_typer(worktree_mod.app, name="worktree")
app.add_typer(heartbeat_mod.app, name="heartbeat")
app.add_typer(contract_mod.app, name="contract")
app.add_typer(archetype_mod.app, name="archetype")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"hexa-swarm-core {__version__}")
        raise typer.Exit(code=0)


@app.callback()
def _root(
    version: bool = typer.Option(  # noqa: ARG001
        False,
        "--version",
        help="Print hexa-swarm-core version and exit.",
        is_eager=True,
        callback=_version_callback,
    ),
) -> None:
    """No-op root callback. Sub-commands carry the logic."""


def main() -> None:
    """`hexa` entry point (registered in pyproject [project.scripts])."""
    app()


if __name__ == "__main__":
    main()
