"""`hexa heartbeat` — keep active locks fresh."""

from __future__ import annotations

from pathlib import Path

import typer

from hexa_swarm_core.swarm.heartbeat import heartbeat_loop, heartbeat_once

app = typer.Typer(help="Keep active locks fresh so stale-cleanup does not kill a live session.")


@app.command("once")
def once_cmd(path: Path = typer.Option(Path("."), "--path")) -> None:
    touched = heartbeat_once(path.resolve())
    typer.echo(f"touched={len(touched)}")


@app.command("start")
def start_cmd(
    path: Path = typer.Option(Path("."), "--path"),
    interval: float = typer.Option(60.0, "--interval", help="Seconds between heartbeats."),
    max_iterations: int = typer.Option(0, "--max-iterations", help="0 = forever."),
) -> None:
    """Run the heartbeat daemon. Ctrl+C stops cleanly; kill switch aborts."""
    max_i = max_iterations if max_iterations > 0 else None
    n = heartbeat_loop(path.resolve(), interval_s=interval, max_iterations=max_i)
    typer.echo(f"iterations={n}")
