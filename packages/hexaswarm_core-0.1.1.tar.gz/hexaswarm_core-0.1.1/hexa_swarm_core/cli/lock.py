"""`hexa lock` — atomic lock operations."""

from __future__ import annotations

from pathlib import Path

import typer

from hexa_swarm_core.exceptions import LockBusyError
from hexa_swarm_core.locks import acquire_lock, cleanup_stale, release_lock

app = typer.Typer(help="Atomic file-based locks for shared resources.")


@app.command("acquire")
def acquire_cmd(
    target: str = typer.Argument(..., help="Logical target file, e.g. SYSTEM_STATE.md"),
    agent: str = typer.Option(..., "--agent", help="Agent name (e.g. Beta, Delta)."),
    reason: str = typer.Option("", "--reason", help="Human-readable reason."),
    path: Path = typer.Option(Path("."), "--path", help="Project root."),
) -> None:
    """Acquire a lock. Prints the lock file path; exits nonzero on LockBusyError."""
    try:
        lp = acquire_lock(path.resolve(), target, agent=agent, reason=reason)
    except LockBusyError as exc:
        typer.echo(f"BUSY: {exc.message}", err=True)
        raise typer.Exit(code=3) from exc
    typer.echo(str(lp))


@app.command("release")
def release_cmd(
    lock_path: Path = typer.Argument(..., help="Exact path to the lock file to release."),
) -> None:
    ok = release_lock(lock_path)
    typer.echo("released" if ok else "not-held")


@app.command("cleanup")
def cleanup_cmd(
    path: Path = typer.Argument(Path("."), help="Project root."),
    dry_run: bool = typer.Option(False, "--dry-run"),
    verbose: bool = typer.Option(False, "-v", "--verbose"),
) -> None:
    removed = cleanup_stale(path.resolve(), dry_run=dry_run)
    if verbose:
        for p in removed:
            typer.echo(str(p))
    typer.echo(f"removed={len(removed)} dry_run={dry_run}")
