"""`hexa session` — manage `.ai-sync/session.uuid`."""

from __future__ import annotations

from pathlib import Path

import typer

from hexa_swarm_core.session import current_session, end_session, init_session, session_path

app = typer.Typer(help="Session UUID management.")


@app.command("init")
def init_cmd(
    path: Path = typer.Argument(Path("."), help="Project root."),
    force: bool = typer.Option(False, "--force", help="Regenerate even if file exists."),
) -> None:
    """Create `.ai-sync/session.uuid` if missing and print it."""
    uid = init_session(path.resolve(), force=force)
    typer.echo(uid)


@app.command("show")
def show_cmd(path: Path = typer.Argument(Path("."))) -> None:
    """Print the current session UUID (from env or file)."""
    typer.echo(current_session(path.resolve()))


@app.command("end")
def end_cmd(path: Path = typer.Argument(Path("."))) -> None:
    """Remove `.ai-sync/session.uuid`. Idempotent."""
    root = path.resolve()
    end_session(root)
    typer.echo(f"ended: {session_path(root)}")
