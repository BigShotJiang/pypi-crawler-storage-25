"""`hexa worktree` — sibling-dir git worktree orchestration."""

from __future__ import annotations

from pathlib import Path

import typer

from hexa_swarm_core.session import current_session
from hexa_swarm_core.swarm.worktree import (
    boot_worktree,
    list_worktrees,
    teardown_worktree,
)

app = typer.Typer(help="Physical isolation for parallel agents via git worktrees.")


@app.command("boot")
def boot_cmd(
    agent: str = typer.Option(..., "--agent", help="Agent name (writer-be, writer-fe, delta, ...)"),
    session: str = typer.Option(
        "",
        "--session",
        help="Session UUID (defaults to current session from .ai-sync/session.uuid)",
    ),
    base: str = typer.Option("HEAD", "--base", help="Base ref/branch/commit to fork from."),
    path: Path = typer.Option(Path("."), "--path", help="Main repo path."),
) -> None:
    root = path.resolve()
    sid = session or current_session(root)
    try:
        h = boot_worktree(root, agent=agent, session=sid, base=base)
    except RuntimeError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(code=2) from exc
    typer.echo(str(h.path))
    typer.echo(f"branch:  {h.branch}")
    typer.echo(f"session: {sid}")


@app.command("list")
def list_cmd(path: Path = typer.Option(Path("."), "--path")) -> None:
    for h in list_worktrees(path.resolve()):
        typer.echo(f"{h.agent}\t{h.session}\t{h.branch}\t{h.path}")


@app.command("teardown")
def teardown_cmd(
    worktree_path: Path = typer.Argument(..., help="Absolute path of the worktree to remove."),
    keep_branch: bool = typer.Option(False, "--keep-branch", help="Do not delete the session branch."),
    repo: Path = typer.Option(Path("."), "--repo", help="Main repo path."),
) -> None:
    from hexa_swarm_core.swarm.worktree import WorktreeHandle

    # Reconstruct a minimal handle
    handle = WorktreeHandle(
        repo=repo.resolve(),
        path=worktree_path.resolve(),
        branch="",
        agent="",
        session="",
    )
    # Try to resolve branch from the live list so we can delete it cleanly
    for h in list_worktrees(repo.resolve()):
        if h.path == handle.path:
            handle = h
            break
    teardown_worktree(handle, delete_branch=not keep_branch)
    typer.echo(f"removed {worktree_path}")
