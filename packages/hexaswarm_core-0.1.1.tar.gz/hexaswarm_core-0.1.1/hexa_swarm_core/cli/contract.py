"""`hexa contract` — contract-proposal queue."""

from __future__ import annotations

from pathlib import Path

import typer

from hexa_swarm_core.swarm.contract_writer import (
    list_proposals,
    mark_applied,
    propose_contract_change,
)

app = typer.Typer(help="Contract proposal queue (Orchestrator-only applies; agents queue).")


@app.command("propose")
def propose_cmd(
    target_file: str = typer.Option(..., "--target", help="Contract file being proposed for change."),
    summary: str = typer.Option(..., "--summary"),
    proposer: str = typer.Option("unknown", "--proposer"),
    diff: str = typer.Option("", "--diff", help="Unified diff (optional)."),
    diff_file: Path = typer.Option(None, "--diff-file"),
    path: Path = typer.Option(Path("."), "--path"),
) -> None:
    patch = diff
    if diff_file is not None:
        patch = diff_file.read_text(encoding="utf-8")
    proposal_path = propose_contract_change(
        path.resolve(),
        target_file=target_file,
        proposer=proposer,
        summary=summary,
        diff=patch,
    )
    typer.echo(str(proposal_path))


@app.command("list")
def list_cmd(
    path: Path = typer.Option(Path("."), "--path"),
    include_applied: bool = typer.Option(False, "--include-applied"),
) -> None:
    ps = list_proposals(path.resolve(), include_applied=include_applied)
    for p in ps:
        typer.echo(
            f"{p.created_ts or '?'}\t{p.proposer}\t{p.target_file}\t{p.summary}\t{p.path.name}",
        )
    typer.echo(f"# total={len(ps)}")


@app.command("apply")
def apply_cmd(proposal_path: Path = typer.Argument(...)) -> None:
    """Mark a proposal as applied (moves the file to events/archive/). Does NOT patch anything."""
    dest = mark_applied(proposal_path.resolve())
    typer.echo(str(dest))
