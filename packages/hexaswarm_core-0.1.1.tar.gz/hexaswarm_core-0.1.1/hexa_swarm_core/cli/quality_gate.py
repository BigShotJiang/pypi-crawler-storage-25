"""`hexa quality-gate` — polymorphic lint+format+type+test dispatch via StackAdapter."""

from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path

import typer

from hexa_swarm_core.adapters import detect_adapters, get_adapter
from hexa_swarm_core.adapters.protocol import CommandSpec, StackAdapter
from hexa_swarm_core.profile import load_profile

app = typer.Typer(help="Polymorphic quality gate dispatched via StackAdapter.")


STAGES = ("lint", "format", "typecheck", "test", "build", "dep_audit")


def _collect_commands(adapter: StackAdapter, project_root: Path, stage: str) -> list[CommandSpec]:
    method = {
        "lint": adapter.lint_cmd,
        "format": adapter.format_check_cmd,
        "typecheck": adapter.typecheck_cmd,
        "test": adapter.test_cmd,
        "build": adapter.build_cmd,
        "dep_audit": adapter.dep_audit_cmd,
    }[stage]
    return method(project_root)


def _run(spec: CommandSpec, project_root: Path) -> int:
    cwd = project_root / spec.cwd if spec.cwd else project_root
    env = os.environ.copy()
    if spec.env:
        env.update(spec.env)
    typer.echo(f"$ (cd {cwd}) {' '.join(shlex.quote(x) for x in spec.cmd)}")
    try:
        result = subprocess.run(spec.cmd, cwd=str(cwd), env=env, check=False)  # noqa: S603
    except FileNotFoundError as exc:
        typer.echo(f"  ✗ not-found: {exc}", err=True)
        return 127
    return result.returncode


def _load_adapters(project_root: Path) -> list[StackAdapter]:
    """Prefer profile; fall back to detection."""
    from hexa_swarm_core.exceptions import HexaError, ProfileError

    try:
        prof = load_profile(project_root)
    except (ProfileError, HexaError):
        return detect_adapters(project_root)
    if prof.adapters_enabled:
        return [get_adapter(n) for n in prof.adapters_enabled]
    return detect_adapters(project_root)


@app.command("run")
def run_cmd(
    path: Path = typer.Argument(Path("."), help="Project root."),
    stages: list[str] = typer.Option(
        [],
        "--stage",
        help=f"Stages to run (default: lint,format,typecheck,test). Choices: {', '.join(STAGES)}",
    ),
    fail_fast: bool = typer.Option(True, help="Stop on first failing stage."),
) -> None:
    """Run quality gate. Exits nonzero if any stage fails."""
    project_root = path.resolve()
    adapters = _load_adapters(project_root)
    if not adapters:
        typer.echo(
            "No stack adapter matched. Run `hexa adopt .` or pass `--stack <name>` to the parent command.",
            err=True,
        )
        raise typer.Exit(code=2)

    selected = list(stages) if stages else ["lint", "format", "typecheck", "test"]
    unknown = [s for s in selected if s not in STAGES]
    if unknown:
        typer.echo(f"unknown stages: {unknown}. choices: {list(STAGES)}", err=True)
        raise typer.Exit(code=2)

    overall_rc = 0
    for adapter in adapters:
        typer.echo(f"\n== {adapter.name} ({adapter.language}) ==")
        for stage in selected:
            cmds = _collect_commands(adapter, project_root, stage)
            if not cmds:
                typer.echo(f"  · {stage}: no commands (skipped)")
                continue
            for spec in cmds:
                rc = _run(spec, project_root)
                if rc != 0:
                    typer.echo(f"  ✗ {stage} FAILED ({spec.description or ' '.join(spec.cmd)})", err=True)
                    overall_rc = rc if overall_rc == 0 else overall_rc
                    if fail_fast:
                        raise typer.Exit(code=overall_rc)
                else:
                    typer.echo(f"  ✓ {stage} ok")

    if overall_rc:
        raise typer.Exit(code=overall_rc)
    typer.echo("\nquality-gate: PASS")


@app.command("list")
def list_cmd(
    path: Path = typer.Argument(Path("."), help="Project root."),
) -> None:
    """List matched adapters + resolved commands per stage."""
    project_root = path.resolve()
    adapters = _load_adapters(project_root)
    if not adapters:
        typer.echo("no adapters matched")
        raise typer.Exit(code=1)
    for adapter in adapters:
        typer.echo(f"{adapter.name} ({adapter.language}) priority={adapter.priority}")
        for stage in STAGES:
            cmds = _collect_commands(adapter, project_root, stage)
            if not cmds:
                continue
            for spec in cmds:
                prefix = f"cd {spec.cwd} && " if spec.cwd else ""
                typer.echo(f"  {stage:10} {prefix}{' '.join(spec.cmd)}")
