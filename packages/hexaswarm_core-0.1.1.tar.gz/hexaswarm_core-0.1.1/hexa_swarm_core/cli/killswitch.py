"""`hexa killswitch` — activate / deactivate / status."""

from __future__ import annotations

from pathlib import Path

import typer

from hexa_swarm_core.safety.killswitch import KillSwitch

app = typer.Typer(help="Emergency stop for autonomous agents.")


@app.command("activate")
def activate_cmd(
    reason: str = typer.Option("", "--reason"),
    path: Path = typer.Option(Path("."), "--path"),
) -> None:
    p = KillSwitch(path).activate(reason=reason)
    typer.echo(f"activated: {p}")


@app.command("deactivate")
def deactivate_cmd(path: Path = typer.Option(Path("."), "--path")) -> None:
    ok = KillSwitch(path).deactivate()
    typer.echo("deactivated" if ok else "not-active")


@app.command("status")
def status_cmd(path: Path = typer.Option(Path("."), "--path")) -> None:
    active = KillSwitch(path).is_active()
    typer.echo("ACTIVE" if active else "inactive")
    raise typer.Exit(code=1 if active else 0)
