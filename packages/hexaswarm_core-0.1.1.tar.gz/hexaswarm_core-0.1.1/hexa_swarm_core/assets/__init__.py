"""Tier A asset package. Installed by `hexa adopt` into target repos."""

from __future__ import annotations

from importlib import resources
from pathlib import Path


def tier_a_root() -> Path:
    """Filesystem path to the bundled Tier A assets.

    Works both when installed from a wheel (importlib.resources) and when
    running from a source checkout (fallback to __file__-relative path).
    """
    try:
        files = resources.files(__package__)
        candidate = files / "tier_a"
        # Some loaders return a MultiplexedPath; convert to a real path.
        return Path(str(candidate))
    except Exception:  # noqa: BLE001
        return Path(__file__).parent / "tier_a"
