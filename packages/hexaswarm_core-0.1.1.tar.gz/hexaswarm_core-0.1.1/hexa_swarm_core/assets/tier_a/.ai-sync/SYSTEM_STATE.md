# SYSTEM_STATE

Canonical snapshot of the project's moving parts. Only the Orchestrator
writes to this file — other agents propose updates via
`.ai-sync/events/*.md` tickets.

## API
- Base URL: (fill in)
- Contract: `.ai-sync/contracts/openapi.yaml`

## Database
- Engine:
- Migrations: `alembic/versions/`

## External services
- LLM provider:
- Payment provider:
- Observability:

## Environment conventions
- `IS_PRODUCTION=false` in development
- Secrets in `.env` (never committed)
