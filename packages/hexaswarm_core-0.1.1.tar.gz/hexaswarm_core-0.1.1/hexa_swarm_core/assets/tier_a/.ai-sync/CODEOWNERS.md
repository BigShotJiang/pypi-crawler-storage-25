# CODEOWNERS

Longest literal prefix wins. Ties are DENIED by the
`post_edit_ownership.py` hook — add a more specific rule to resolve.

| glob | agent |
|------|-------|
| `.ai-sync/**` | Orchestrator |
| `.claude/**` | Orchestrator |
| `src/backend/db/**` | Alpha |
| `src/backend/etl/**` | Alpha |
| `src/backend/**/schemas*.py` | Alpha |
| `alembic/**` | Alpha |
| `src/backend/services/commerce/**` | Gamma |
| `src/backend/services/payments/**` | Gamma |
| `src/backend/integrations/**` | Gamma |
| `src/backend/utils/rpa_*.py` | Epsilon |
| `src/backend/edge/**` | Epsilon |
| `src/backend/streams/**` | Epsilon |
| `src/backend/routers/**` | Beta |
| `src/backend/services/**` | Beta |
| `src/backend/auth*.py` | Beta |
| `src/backend/utils/**` | Beta |
| `src/backend/**` | Beta |
| `app/**` | Cursor |
| `src/frontend/**` | Cursor |
| `e2e/**` | Cursor |
| `next.config.*` | Cursor |
| `public/**` | Cursor |
