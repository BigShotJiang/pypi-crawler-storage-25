# ADR 0001 — Adopted hexa-swarm-core

**Date**: (filled in at adopt time)
**Status**: Accepted

## Context
This project adopted `hexa-swarm-core` via `hexa adopt .` to standardise
Claude-native multi-agent delivery.

## Decision
- Installed Tier A assets: `.claude/{settings,mcp}.json`, hooks, skills,
  agents; `.ai-sync/` skeleton.
- Archetype and stack recorded in `.hexa/profile.yaml`.
- Universal invariants S4/S5/S6 apply unconditionally; S1/S2/S3 gated by
  feature flags.

## Consequences
- `hexa quality-gate run` is now the single entry point for CI-like
  checks across all stacks.
- Every agent session auto-runs the hook stack at start/end.
- Upgrades: `hexa adopt . --force` to refresh Tier A when a new
  `hexa-swarm-core` version ships.
