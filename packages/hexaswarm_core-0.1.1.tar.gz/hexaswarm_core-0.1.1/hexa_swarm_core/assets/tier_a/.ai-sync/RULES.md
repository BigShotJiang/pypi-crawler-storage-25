# Multi-agent coordination rules

Installed by `hexa adopt`. Not a copier-generated file — this is the
universal baseline; projects extend it rather than replace.

## Core principle
One file, one owner at a time. Use atomic file locks in
`.ai-sync/locks/` (created via `hexa lock acquire …` — see
`.ai-sync/locks/` for the protocol).

## Read before starting a session
1. `SYSTEM_STATE.md`
2. `.ai-sync/CODEOWNERS.md`
3. `.ai-sync/changelog/{other_side}_CURRENT.md`
4. The latest `.ai-sync/plans/*.md` matching your task

## Write when finishing a session
1. `.ai-sync/changelog/{your_side}_CURRENT.md` (append, not overwrite)
2. A new `.ai-sync/events/*.md` ticket if you changed anything the
   other agents need to react to.

## Lock protocol
```bash
hexa lock acquire SYSTEM_STATE.md --agent <you> --reason "…"
# edit…
hexa lock release <path-printed-above>
```

Stale locks (>1h mtime, or heartbeat >3min old) are cleared on next
`SessionStart` by the `session_start_lock_cleanup.py` hook.
