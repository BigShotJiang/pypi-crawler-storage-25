---
name: ship
description: Writer → Reviewer → PR pipeline. Hands the current branch to a fresh-context Reviewer subagent; if zero critical findings, opens a PR. Auto-invoke when the user says "ship it", "open PR", "ready to merge".
allowed-tools: Bash(hexa *), Bash(gh *), Bash(git *), Task
---

# ship

The end-of-loop skill. Encapsulates Karpathy's Writer/Reviewer-as-separate-
contexts pattern and Anthropic's "fresh-context review is less biased."

## Sequence

1. `hexa quality-gate run` — must pass end-to-end first.
2. Invoke the `reviewer` subagent (see `.claude/agents/reviewer.md` once W3
   lands) with:
   - `git diff origin/main...HEAD` as input,
   - `.ai-sync/plans/<latest>.md` as the spec,
   - severity rubric: CRITICAL / HIGH / MEDIUM / LOW.
3. If the Reviewer emits **zero CRITICAL** findings:
   ```bash
   git push -u origin "$(git symbolic-ref --short HEAD)"
   gh pr create \
     --title  "<type>: <summary>" \
     --body-file .ai-sync/plans/<latest>.md
   ```
4. If CRITICAL findings exist, stop and print them. Do not push.

## Why it matters

"Ship" is the only place where the same agent both wrote AND signs off on
code. Forcing a fork-context review here is the cheapest bias reduction
available and turns every PR description into an executable spec.
