---
name: cross-sync-alert
description: Detect when an edit to backend routers / schemas implies a breaking change the frontend must react to, and emit a REQ_FE ticket. Auto-invoke after any Edit/Write under `src/backend/routers/` or `src/backend/**/schemas.py`.
allowed-tools: Bash(hexa *), Bash(git diff *), Write
---

# cross-sync-alert

Prevents silent FE/BE contract drift. When a backend route/schema changes:

1. Extract the affected endpoints (URL + method + body/response shape).
2. Append a ticket to `.ai-sync/events/REQ_FE_{ISO}_{slug}.md` describing
   - the change,
   - impacted screens/components (best-effort grep over `app/`),
   - the new OpenAPI contract path.
3. Append a changelog line to `.ai-sync/changelog/BE_CURRENT.md` under
   "## API 변경 (⚠️ 프론트 영향)".
4. Remind the user to regenerate types:
   ```bash
   hexa quality-gate run --stage test  # re-verify BE
   # W4 will ship: hexa contract regenerate
   ```

## Safety

- Never writes to frontend source files directly — only to `.ai-sync/events/`.
- If both sides are owned by the same agent, still write the ticket (audit trail).

## Future (W4)

Replaced by an event-driven contract writer process. This skill remains the
human-readable entry point.
