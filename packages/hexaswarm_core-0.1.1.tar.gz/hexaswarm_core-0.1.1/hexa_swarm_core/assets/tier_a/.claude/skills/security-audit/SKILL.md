---
name: security-audit
description: Delegate a read-only security audit (Red Team posture) against the current branch. Auto-invoke when the user asks for "security review", "audit", "red team check", or before a production release.
allowed-tools: Bash(hexa *), Bash(gh *), Bash(npm audit *), Bash(pip-audit *), Bash(git log *), Bash(git diff *)
---

# security-audit

A read-only, refuses-to-write audit driven by the **Delta (Red Team)** persona.
Output is appended to `.ai-sync/audit/AUDIT_YYYY-MM-DD.md`. Critical findings
are merge-blockers.

## Scope

1. Auth / JWT / RLS paths — confirm `get_tenant_session`-equivalent is used
   across all data-access call sites for this stack (S1 conditional invariant).
2. Secret handling — grep for leaked tokens, plaintext encryption inputs,
   missing `.env` entries in `.gitignore` (S3).
3. Prompt injection paths — every LLM call must route untrusted text through
   `sanitize_for_prompt()` or the stack-equivalent sanitiser (S6 universal).
4. Idempotency on external side-effects — POSTs with retries must carry
   `X-Idempotency-Key`.
5. Dependency audit: `pip-audit`, `npm audit`, `osv-scanner` (whichever applies).
6. CORS, CSRF, rate-limit regressions.

## Execution

```bash
# 1. Produce a dated audit skeleton
hexa session init .
mkdir -p .ai-sync/audit

# 2. Run the adapter dep-audit stage (pip-audit / npm audit etc.)
hexa quality-gate run --stage dep_audit

# 3. Invoke this skill in Claude Code — findings appended to audit file
```

## Severity

- **CRITICAL** — merge-block. Auth bypass, secret leak, RLS hole, RCE.
- **HIGH** — open a P1 ticket, ship within 24h.
- **MEDIUM / LOW** — backlog.

## Refusal posture (S1 reminder)

This skill will NOT edit code. It only emits findings. Fix-ups go to a
separate agent so the audit remains independent.
