---
name: worktree-boot
description: Boot an isolated git worktree for a named agent (writer-be, writer-fe, delta, etc.) so parallel agents never touch each other's files. Auto-invoke on "spin up a worktree", "parallel agent", "isolated branch".
allowed-tools: Bash(git worktree *), Bash(hexa *), Bash(mkdir *)
---

# worktree-boot

Physical isolation for parallel agents — the Rev3 plan's principal
conflict-avoidance mechanism.

## Convention

```
<repo>/../<slug>-wt/<agent>-<session>/   (sibling dir, Windows-safe)
branch: sess/<session_uuid>-<agent>
```

Sibling rather than nested dir avoids Windows symlink limitations.

## Commands

```bash
SESSION="$(hexa session show .)"
AGENT="writer-be"
WT="../$(basename "$(pwd)")-wt/${AGENT}-${SESSION}"
BR="sess/${SESSION}-${AGENT}"

git worktree add -b "$BR" "$WT" HEAD
```

The worktree directory inherits `.claude/` and `.ai-sync/` via git, so hooks
and skills continue to work identically inside the isolated copy.

## Teardown

```bash
git worktree remove "../$(basename "$(pwd)")-wt/${AGENT}-${SESSION}"
git branch -D "sess/${SESSION}-${AGENT}" 2>/dev/null || true
```

Full orchestration (BE + FE + Delta in parallel, heartbeat, contract writer
queue) arrives in W4 as `scripts/swarm/boot.py` + `run_parallel.py`. This
skill is the manual entry point for now.
