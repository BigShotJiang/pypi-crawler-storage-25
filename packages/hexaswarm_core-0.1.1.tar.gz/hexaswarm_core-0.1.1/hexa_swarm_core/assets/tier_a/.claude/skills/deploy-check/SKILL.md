---
name: deploy-check
description: Pre-deployment checklist — confirms quality gate, invariants, contracts, and release metadata are green. Auto-invoke on "ready to deploy", "release check", "pre-prod audit".
allowed-tools: Bash(hexa *), Bash(git *), Bash(gh *), Bash(pytest *), Bash(ruff *), Bash(mypy *)
---

# deploy-check

Run before every production deploy.

## Checklist

1. `hexa quality-gate run` — all stages green.
2. `pytest -m invariants` — S1-S6 enforcement tests pass.
3. `.ai-sync/contracts/openapi.yaml` drift-free against backend OpenAPI dump.
4. No unreleased changelog entries in `.ai-sync/changelog/BE_CURRENT.md` /
   `FE_CURRENT.md` (archive first, then deploy).
5. No active locks in `.ai-sync/locks/` (someone mid-edit on shared state).
6. `.ai-sync/audit/` latest report has zero CRITICAL findings.
7. `.ai-sync/KILL` does not exist.
8. `git status` clean; current branch tracks `origin`.

## Execution

```bash
hexa quality-gate run
hexa lock cleanup --dry-run
ls .ai-sync/audit/ 2>/dev/null | tail -1
test ! -e .ai-sync/KILL
git status --porcelain | wc -l      # must be 0
```

Report PASS / FAIL per item. Stop on first FAIL.
