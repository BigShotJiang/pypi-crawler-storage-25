---
name: auto-test
description: After Edit/Write on a source file, run the minimal pytest / test command that covers that path. Auto-invoke on Edit or Write of non-test source files.
allowed-tools: Bash(hexa *), Bash(pytest *), Bash(npm test *), Bash(pnpm test *)
---

# auto-test

Keep the write-edit-test loop tight (Anthropic + Karpathy principle).

## Strategy

1. For the edited file, try to locate a sibling test:
   - `src/backend/auth.py` → `tests/test_auth.py`
   - `app/lib/foo.ts` → `app/lib/foo.test.ts`
2. If a sibling test exists, run **only** that test (fast feedback).
3. If not, run the adapter's default test command from `hexa quality-gate`.
4. Do not run the full suite — that is what CI and the explicit `quality-gate`
   skill are for.

## Commands

```bash
# Python sibling:
pytest tests/test_<module>.py -q --timeout=30

# Node/TS sibling:
npm test -- --run <file>.test.ts

# Fallback:
hexa quality-gate run --stage test
```

## Rationale

Full-suite auto-test on every edit is a **performance regression** on large
repos (the ai-solar-app audit flagged this). Smart routing + explicit
`quality-gate` for full runs keeps the loop fast and honest.
