---
name: quality-gate
description: Run the polymorphic quality gate — lint + format + typecheck + test — for whichever stacks the project uses. Auto-invoke when the user says "verify", "check", "quality gate", "ship", or "ready to commit".
allowed-tools: Bash(hexa *), Bash(ruff *), Bash(mypy *), Bash(pytest *), Bash(npm *), Bash(pnpm *)
---

# quality-gate

The quality gate runs a stack-agnostic sequence:

1. Resolve `StackAdapter`s from `.hexa/profile.yaml` (or auto-detect if absent).
2. For each adapter, run `lint → format-check → typecheck → test` using the adapter's native commands (ruff/mypy/pytest for Python, eslint/tsc/vitest for Node, etc.).
3. Exit nonzero on the first failing stage. Summarise only failing items.

## Primary command

```bash
hexa quality-gate run
```

To scope stages:

```bash
hexa quality-gate run --stage lint --stage test
```

To see what would run without executing:

```bash
hexa quality-gate list
```

## When this skill auto-invokes

- User asks to "verify", "check if ready", "run quality checks", "ship it".
- User edits a critical file and says "does this pass?".
- After fixing a test failure, to confirm.

## Failure handling

- Print only the failing file:line and test/error name.
- Do not attempt to auto-fix unless explicitly asked.
- Re-run after every fix — do not batch.

## Rationale

This skill is the single entry point enforcing Karpathy's "verification loop is
the highest-leverage productivity lever". Polymorphism lets the same prompt work
in a py-fastapi repo, a node-next repo, or a multi-stack repo.
