---
name: fix-issue
description: Pull a GitHub issue, plan a fix, implement it in a checkpoint-friendly sequence, and open a PR. Auto-invoke when the user says "fix issue #N", "take this ticket", or pastes a GitHub issue URL.
disable-model-invocation: false
allowed-tools: Bash(gh *), Bash(hexa *), Bash(git *), Read, Edit, Write, Grep, Glob
---

# fix-issue

Implements an end-to-end "issue → PR" pipeline using the Anthropic-recommended
explore → plan → implement → commit loop.

## Arguments

`$ARGUMENTS` = issue number (e.g. `123`) or full GitHub URL.

## Pipeline

1. **Explore** (subagent, fork context):
   ```bash
   gh issue view "$ISSUE" --json title,body,labels,comments
   ```
   Use Grep/Glob/Read to locate affected files. Do NOT edit yet.

2. **Plan** (plan mode):
   Write `.ai-sync/plans/$(date +%Y-%m-%d)_${issue-slug}.md` with:
   - Root cause (for bugs) or required change (for features)
   - Files to touch (list)
   - Tests to add / modify (tests-as-spec, Karpathy)
   - Risk / rollback plan (S5 checkpoint discipline)

3. **Implement** (normal mode):
   - Create failing tests first.
   - Commit after each green stage (`feat:`, `test:`, `fix:` prefixes).
   - Run `hexa quality-gate run` before final commit.

4. **Commit & PR**:
   ```bash
   git push -u origin "fix/${issue-slug}"
   gh pr create --title "fix: <summary>" --body-file .ai-sync/plans/<plan>.md
   ```

## Safety

- Respects the S4 cost ceiling — the fix is aborted if spend would breach it.
- Honours S5 — no `--force` pushes; checkpoints every functional step.
- The `/ship` skill is the preferred wrapper that also invokes the Reviewer
  subagent before opening the PR.
