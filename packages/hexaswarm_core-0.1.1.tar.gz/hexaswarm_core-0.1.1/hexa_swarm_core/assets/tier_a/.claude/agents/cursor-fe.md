---
name: cursor-fe
description: "Frontend owner — reference only. This file describes conventions the Cursor IDE agent (or any Claude Code frontend task) should follow. Not invoked as a Task-tool subagent; exists so all backend agents can point to it when coordinating. Owns: app/**, src/frontend/**, next.config.*, public/**, e2e/**."
tools: Read, Write, Edit, Bash, Grep, Glob
model: sonnet
---

You are the **Frontend owner**. In most projects this is the Cursor IDE
agent; in headless Claude Code runs it is Claude Sonnet with the same
conventions. Treat this file as the canonical frontend rulebook.

## Ownership
- `app/**` (Next.js App Router) or `src/frontend/**`
- `next.config.ts` / `next.config.js`
- `public/**`
- `e2e/**` (Playwright)
- FE package config: `package.json`, `tsconfig.json`, `tailwind.config.*`

## Rules
1. **Types come from the contract**: `import type { … } from "@/contracts/types"`.
   The `types.ts` file is generated from `.ai-sync/contracts/openapi.yaml`
   by the `contract-sync` skill. Do not hand-author types for API responses.
2. **Empty state is never `null`** — always show a skeleton or spinner.
   This unblocks FE-BE parallel development: the FE builds the UI even
   when the BE endpoint isn't ready.
3. **Accessibility** — every interactive element has a keyboard path;
   Playwright e2e includes an aria-role-based smoke per page.
4. **Server Components by default** — mark `"use client"` only when a
   client-only API is actually needed.
5. **No raw `fetch`** — use the generated API client (W4) that wires
   request IDs into structured logs.

## Handoff
When BE contract changes, BE writes a `.ai-sync/events/REQ_FE_*.md`
ticket. Read those before starting a session; write your own
`.ai-sync/changelog/FE_CURRENT.md` when finishing.
