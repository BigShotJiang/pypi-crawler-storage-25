#!/usr/bin/env python3
"""
PostToolUse(Edit|Write) ownership check — CODEOWNERS enforcement.

Reads `.ai-sync/CODEOWNERS.md` (markdown table: `| glob | agent |`) and
blocks edits to files owned by a different agent than `$CURRENT_AGENT`.

Tie-break rule: **longest glob wins.** When two rules match, the one with
the longest literal path prefix (segments without wildcards) takes
precedence. If there is still a tie, the edit is DENIED — explicit wins.

Fail-open when:
  - CODEOWNERS.md is missing (not adopted yet)
  - CURRENT_AGENT is unset (interactive / non-multi-agent run)
"""
from __future__ import annotations

import fnmatch
import json
import os
import re
import sys
from pathlib import Path

CODEOWNERS = Path(".ai-sync/CODEOWNERS.md")


def _read_hook_input() -> dict:
    try:
        return json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}


def _block(reason: str) -> None:
    print(f"[hexa ownership] BLOCK: {reason}", file=sys.stderr)
    sys.exit(2)


def _parse_codeowners(text: str) -> list[tuple[str, str]]:
    """Parse a simple markdown table: | glob | agent | ..."""
    rules: list[tuple[str, str]] = []
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("|") or line.startswith("|-") or "---" in line:
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 2:
            continue
        glob, agent = cells[0], cells[1]
        if not glob or not agent or glob.lower() in {"path", "glob"}:
            continue
        rules.append((glob, agent))
    return rules


def _specificity(glob: str) -> int:
    """Score by longest literal prefix. Segments without wildcards win."""
    parts = re.split(r"[\\/]", glob)
    literal = sum(len(p) for p in parts if "*" not in p and "?" not in p)
    return literal


def _match(file_path: str, rules: list[tuple[str, str]]) -> tuple[str, str] | None:
    norm = file_path.replace("\\", "/")
    candidates: list[tuple[int, str, str]] = []
    for glob, agent in rules:
        g = glob.replace("\\", "/")
        if fnmatch.fnmatch(norm, g) or fnmatch.fnmatch(norm, g.rstrip("/") + "/**"):
            candidates.append((_specificity(g), g, agent))
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0], reverse=True)
    top = candidates[0]
    ties = [c for c in candidates if c[0] == top[0]]
    if len(ties) > 1:
        # Tie → deny (require explicit resolution).
        return ("__tie__", " / ".join(t[1] for t in ties))
    return (top[1], top[2])


def main() -> int:
    payload = _read_hook_input()
    tool_input = payload.get("tool_input") or {}
    file_path = tool_input.get("file_path")
    if not file_path:
        return 0
    current_agent = (os.getenv("CURRENT_AGENT") or "").strip()
    if not current_agent:
        return 0
    if not CODEOWNERS.exists():
        return 0

    rules = _parse_codeowners(CODEOWNERS.read_text(encoding="utf-8", errors="ignore"))
    match = _match(file_path, rules)
    if match is None:
        return 0
    matched_glob, owner = match
    if matched_glob == "__tie__":
        _block(f"ownership tie for {file_path}: {owner}. Add a more specific rule.")
    if owner.lower() != current_agent.lower():
        _block(f"{file_path} owned by {owner}, but CURRENT_AGENT={current_agent}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001
        print(f"[hexa ownership] hook error (fail-open): {exc}", file=sys.stderr)
        sys.exit(0)
