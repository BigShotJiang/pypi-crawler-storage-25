#!/usr/bin/env python3
"""
PreToolUse guard — blocks dangerous Bash invocations and honours the kill switch.

Hook contract (Claude Code):
  - stdin  : JSON { "tool_name": "Bash", "tool_input": { "command": "..." }, ... }
  - stdout : informational text
  - stderr : block reason (only when blocking)
  - exit 0 : allow; exit 2 : block

Layered checks:
  1. KillSwitch file `.ai-sync/KILL` → block everything until cleared.
  2. Regex blocklist for obviously-destructive Bash (rm -rf /, force push, DROP, etc.).
  3. `curl | sh` / `curl | bash` pipe → block.

This hook is intentionally cautious: false-negatives are worse than false-positives.
Legitimate work can be unblocked with clearer wording.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

KILL_FILE = Path(os.getenv("HEXA_KILL_FILE", ".ai-sync/KILL"))

_DESTRUCTIVE_PATTERNS = [
    r"\brm\s+-rf?\b.*/\s*$",
    r"\brm\s+-rf?\s+/\b",
    r"\brm\s+-rf?\s+\*",
    r"\brm\s+-rf?\s+~",
    r"\bgit\s+push\b.*--force\b",
    r"\bgit\s+push\b.*\s-f\b",
    r"\bgit\s+reset\s+--hard\b",
    r"\bgit\s+clean\s+-fd\b",
    r"\bgit\s+checkout\s+--\s+\.",
    r"\bDROP\s+(TABLE|DATABASE|SCHEMA)\b",
    r"\bTRUNCATE\s+TABLE\b",
    r"\bDELETE\s+FROM\s+\w+\s*;",  # DELETE without WHERE
    r"\bsudo\b",
    r"\bchmod\s+-R\s+777\b",
    r"\bmkfs\b",
    r"\b:\(\)\s*\{\s*:\|:&\s*\};:",  # fork bomb
    r"\bcurl\s+[^|]*\|\s*(?:sh|bash|zsh)\b",
    r"\bwget\s+[^|]*\|\s*(?:sh|bash|zsh)\b",
]
_DESTRUCTIVE_RE = re.compile("|".join(f"(?:{p})" for p in _DESTRUCTIVE_PATTERNS), re.IGNORECASE)


def _read_hook_input() -> dict:
    try:
        raw = sys.stdin.read()
    except Exception:  # noqa: BLE001
        return {}
    if not raw.strip():
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def _block(reason: str) -> None:
    print(f"[hexa pre-tool-use] BLOCK: {reason}", file=sys.stderr)
    sys.exit(2)


def main() -> int:
    # 1. KillSwitch
    if KILL_FILE.exists():
        _block(f"kill switch engaged ({KILL_FILE}). Clear it with `hexa killswitch deactivate`.")

    payload = _read_hook_input()
    tool = payload.get("tool_name", "")
    tool_input = payload.get("tool_input") or {}

    # 2. Bash inspection
    if tool == "Bash":
        command = (tool_input.get("command") or "").strip()
        if not command:
            return 0
        if _DESTRUCTIVE_RE.search(command):
            _block(f"destructive command rejected: {command[:120]}")

    # 3. Write/Edit guard: refuse if path escapes project root
    if tool in ("Write", "Edit"):
        file_path = tool_input.get("file_path") or ""
        if file_path and (".." in Path(file_path).parts or file_path.startswith(("/etc", "/usr", "/bin"))):
            _block(f"path outside project root: {file_path}")

    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001
        # Fail open on unexpected hook errors — never block real work on our bug.
        print(f"[hexa pre-tool-use] hook error (fail-open): {exc}", file=sys.stderr)
        sys.exit(0)
