#!/usr/bin/env python3
"""
PostToolUse(Edit|Write) validator — syntax check + secret / hardcoded-constant scan.

  - Python files        : ast.parse (syntax error → block).
  - TypeScript/JS files : skipped here (tsc runs in quality-gate).
  - Any file            : grep for secret patterns (sk-, ghp_, AKIA…, etc.).
  - Python files        : warn on likely-hardcoded magic constants.

Hook contract: stdin JSON, exit 0 = pass, exit 2 = block.
We block only on syntax errors and explicit secret leaks. Magic-constant hits
are warnings printed to stderr but allowed through.
"""
from __future__ import annotations

import ast
import json
import re
import sys
from pathlib import Path

_SECRET_PATTERNS = [
    (r"sk-[A-Za-z0-9]{20,}", "OpenAI / Anthropic-style API key"),
    (r"ghp_[A-Za-z0-9]{20,}", "GitHub personal access token"),
    (r"github_pat_[A-Za-z0-9_]{40,}", "GitHub fine-grained PAT"),
    (r"AKIA[0-9A-Z]{16}", "AWS access key id"),
    (r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", "Private key block"),
    (r"xox[baprs]-[A-Za-z0-9-]{10,}", "Slack token"),
]
_SECRET_RES = [(re.compile(p), name) for p, name in _SECRET_PATTERNS]

# Heuristic: decimal literals looking like physics constants or thresholds.
_MAGIC_FLOAT_RE = re.compile(r"=\s*-?\d+\.\d+e-?\d+\b")


def _read_hook_input() -> dict:
    try:
        return json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}


def _block(reason: str) -> None:
    print(f"[hexa post-write] BLOCK: {reason}", file=sys.stderr)
    sys.exit(2)


def _warn(msg: str) -> None:
    print(f"[hexa post-write] warn: {msg}", file=sys.stderr)


def _check_python_syntax(path: Path, text: str) -> None:
    try:
        ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        _block(f"Python syntax error in {path}:{exc.lineno}: {exc.msg}")


def _check_secrets(path: Path, text: str) -> None:
    for rx, label in _SECRET_RES:
        m = rx.search(text)
        if m:
            _block(f"possible {label} committed in {path}: {m.group(0)[:12]}…")


def _check_magic_floats(path: Path, text: str) -> None:
    for i, line in enumerate(text.splitlines(), start=1):
        if _MAGIC_FLOAT_RE.search(line):
            _warn(f"possible hardcoded physical constant at {path}:{i} — consider moving to constants module")


def main() -> int:
    payload = _read_hook_input()
    tool_input = payload.get("tool_input") or {}
    file_path = tool_input.get("file_path")
    if not file_path:
        return 0
    p = Path(file_path)
    if not p.exists():
        return 0
    try:
        text = p.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return 0

    _check_secrets(p, text)
    if p.suffix == ".py":
        _check_python_syntax(p, text)
        _check_magic_floats(p, text)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001
        print(f"[hexa post-write] hook error (fail-open): {exc}", file=sys.stderr)
        sys.exit(0)
