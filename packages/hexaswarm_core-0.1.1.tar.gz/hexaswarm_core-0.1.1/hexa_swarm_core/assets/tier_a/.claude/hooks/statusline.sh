#!/usr/bin/env bash
# statusline — shows session UUID, current agent, active locks, total LLM cost.
# Keep under 80 chars so the bottom line in the Claude Code TUI stays readable.
set -euo pipefail

SESSION_FILE=".ai-sync/session.uuid"
LOCKS_DIR=".ai-sync/locks"
COST_FILE=".ai-sync/logs/cost.jsonl"

SESSION="-"
if [ -r "$SESSION_FILE" ]; then
  SESSION="$(tr -d '[:space:]' < "$SESSION_FILE" | head -c 8)"
fi

AGENT="${CURRENT_AGENT:-?}"

LOCKS=0
if [ -d "$LOCKS_DIR" ]; then
  LOCKS="$(find "$LOCKS_DIR" -maxdepth 1 -name '*.lock' 2>/dev/null | wc -l | tr -d '[:space:]')"
fi

COST="0.00"
if [ -r "$COST_FILE" ] && command -v awk >/dev/null 2>&1; then
  COST="$(awk -F'"cost_usd":' 'NF>1 { split($2,a,","); s+=a[1]+0 } END { printf "%.2f", s+0 }' "$COST_FILE" 2>/dev/null || echo "0.00")"
fi

BRANCH="-"
if command -v git >/dev/null 2>&1; then
  BRANCH="$(git symbolic-ref --short HEAD 2>/dev/null || echo '-')"
fi

printf "hexa %s · %s · agent=%s · locks=%s · \$%s" "$SESSION" "$BRANCH" "$AGENT" "$LOCKS" "$COST"
