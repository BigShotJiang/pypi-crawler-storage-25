#!/usr/bin/env python3
"""
SessionEnd hook — archive BE/FE CURRENT changelogs into `.ai-sync/changelog/archive/`.

Names the archive `YYYY-MM-DDTHH-MM-SSZ_{be,fe}.md` so multiple sessions per day
never collide (B14). Current files are truncated back to a minimal template.
"""
from __future__ import annotations

import shutil
import sys
from datetime import UTC, datetime
from pathlib import Path

CHANGELOG_DIR = Path(".ai-sync/changelog")
ARCHIVE_DIR = CHANGELOG_DIR / "archive"

_TEMPLATE = """# {title}

## 작업 요약
(세션 시작 — 여기에 변경사항을 append)

## 수정 파일
- 없음

## API 변경
- 없음
"""


def _archive_one(current: Path, side: str, stamp: str) -> None:
    if not current.exists():
        return
    try:
        text = current.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return
    if "(세션 시작 — 여기에 변경사항을 append)" in text and len(text) < 400:
        # nothing meaningful to archive
        return
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    dst = ARCHIVE_DIR / f"{stamp}_{side}.md"
    shutil.copy2(current, dst)
    # Reset CURRENT to template
    title = "BE Changelog — CURRENT" if side == "be" else "FE Changelog — CURRENT"
    current.write_text(_TEMPLATE.format(title=title), encoding="utf-8")
    print(f"[hexa session-end] archived {current} -> {dst}")


def main() -> int:
    stamp = datetime.now(UTC).strftime("%Y-%m-%dT%H-%M-%SZ")
    _archive_one(CHANGELOG_DIR / "BE_CURRENT.md", "be", stamp)
    _archive_one(CHANGELOG_DIR / "FE_CURRENT.md", "fe", stamp)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:  # noqa: BLE001
        print(f"[hexa session-end] hook error (fail-open): {exc}", file=sys.stderr)
        sys.exit(0)
