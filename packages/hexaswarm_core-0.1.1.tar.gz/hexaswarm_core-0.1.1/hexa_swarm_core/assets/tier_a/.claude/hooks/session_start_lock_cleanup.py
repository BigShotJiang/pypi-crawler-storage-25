#!/usr/bin/env python3
"""
SessionStart hook — ensure session.uuid exists + clean up stale locks.

Uses the `hexa` CLI if available (pipx-installed hexa-swarm-core); otherwise
falls back to the in-template `scripts/lock_cleanup.py`.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str]) -> int:
    try:
        r = subprocess.run(cmd, check=False)  # noqa: S603
    except FileNotFoundError:
        return 127
    return r.returncode


def main() -> int:
    # Prefer `hexa` CLI
    if shutil.which("hexa"):
        _run(["hexa", "session", "init", "."])
        _run(["hexa", "lock", "cleanup", "."])
        return 0

    # Fallback to template-shipped script
    fallback = Path("scripts/lock_cleanup.py")
    if fallback.exists():
        _run([sys.executable, str(fallback)])
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:  # noqa: BLE001
        print(f"[hexa session-start] hook error (fail-open): {exc}", file=sys.stderr)
        sys.exit(0)
