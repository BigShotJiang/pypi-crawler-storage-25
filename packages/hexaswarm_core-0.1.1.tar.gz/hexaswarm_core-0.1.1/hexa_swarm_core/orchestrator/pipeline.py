"""
PipelineOrchestrator — sequential stage runner with resume_from, kill-switch,
and CostCeiling integration.

Design notes:
- Sequential by default. Parallelism is a stage-internal concern — running
  stages concurrently hides budget breaches and complicates resume.
- Every stage's result is appended to `project["_stage_results"]` so a later
  stage can cheaply read "did the prior stage succeed?" without revisiting
  the orchestrator state.
- `resume_from="stage-name"` skips every stage before the matching name.
  Combined with `Stage.should_skip`, this supports idempotent re-runs even
  inside the resume window.
- `KillSwitch` + `CostCeiling` are consulted **before** each stage runs.
  Both raise `SafetyViolationError` with the invariant ID, and the
  orchestrator reports the failing stage name in the exception message.
"""

from __future__ import annotations

import logging
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

from hexa_swarm_core.exceptions import SafetyViolationError
from hexa_swarm_core.orchestrator.stage import Stage, StageResult
from hexa_swarm_core.safety.ceiling import CostCeiling
from hexa_swarm_core.safety.killswitch import KillSwitch
from hexa_swarm_core.telemetry.cost import CostTracker

logger = logging.getLogger("hexa.orchestrator")


class PipelineOrchestrator:
    def __init__(
        self,
        stages: list[Stage],
        *,
        project_root: Path | str = ".",
        kill_switch: KillSwitch | None = None,
        cost_tracker: CostTracker | None = None,
        cost_ceiling: CostCeiling | None = None,
    ) -> None:
        if not stages:
            raise ValueError("stages must be non-empty")
        names = [s.name for s in stages]
        if len(set(names)) != len(names):
            raise ValueError(f"stage names must be unique, got {names}")
        self.stages: list[Stage] = list(stages)
        self.project_root = Path(project_root).resolve()
        self.kill_switch = kill_switch or KillSwitch(self.project_root)
        self.cost_tracker = cost_tracker or CostTracker()
        self.cost_ceiling = cost_ceiling

    def _resume_index(self, resume_from: str | None) -> int:
        if resume_from is None:
            return 0
        for i, s in enumerate(self.stages):
            if s.name == resume_from:
                return i
        raise ValueError(f"unknown resume_from stage: {resume_from!r}. Known: {[s.name for s in self.stages]}")

    def run(
        self,
        project: dict[str, Any],
        *,
        resume_from: str | None = None,
    ) -> list[StageResult]:
        """Run every stage from `resume_from` (or the beginning). Records costs."""
        project.setdefault("_stage_results", [])
        results: list[StageResult] = []
        start_idx = self._resume_index(resume_from)
        project_id = str(project.get("project_id", "unknown"))

        for stage in self.stages[start_idx:]:
            # S5 — honour the kill switch before every stage
            self.kill_switch.assert_live()

            # Respect stage-level resume via should_skip
            if stage.should_skip(project):
                r = StageResult(stage=stage.name, status="skipped")
                results.append(r)
                project["_stage_results"].append(asdict(r))
                logger.info("stage skipped: %s", stage.name)
                continue

            # S4 — check ceiling *before* the stage spends anything (project-wide).
            if self.cost_ceiling is not None:
                self.cost_ceiling.check_can_spend(project_id, estimated_usd=0.0)

            started = time.monotonic()
            try:
                r = stage.run(project)
            except SafetyViolationError:
                raise
            except Exception as exc:  # noqa: BLE001
                duration = time.monotonic() - started
                r = StageResult(
                    stage=stage.name,
                    status="failed",
                    duration_seconds=duration,
                    error=f"{type(exc).__name__}: {exc}",
                )
                results.append(r)
                project["_stage_results"].append(asdict(r))
                logger.error("stage failed: %s -- %s", stage.name, exc)
                return results  # stop on first failure

            # If the stage didn't fill in duration, compute it.
            if r.duration_seconds == 0.0:
                r.duration_seconds = time.monotonic() - started

            # Record cost in the ledger (idempotent even if already recorded by stage).
            if r.cost_usd > 0:
                self.cost_tracker.record(
                    project_id=project_id,
                    stage=stage.name,
                    service=str(r.artifacts.get("service", "stage")),
                    operation=str(r.artifacts.get("operation", "run")),
                    cost_usd=r.cost_usd,
                )

            results.append(r)
            project["_stage_results"].append(asdict(r))
            logger.info(
                "stage done: %s status=%s cost=%.4f duration=%.2fs",
                stage.name,
                r.status,
                r.cost_usd,
                r.duration_seconds,
            )

        return results


__all__ = ["PipelineOrchestrator"]
