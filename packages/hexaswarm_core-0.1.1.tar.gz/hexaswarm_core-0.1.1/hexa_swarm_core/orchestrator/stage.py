"""
Stage Protocol + StageResult — pipeline building block.

Pattern extracted from ai-video/src/pipeline. Generalised so it works for
content-automation pipelines, ETL stages, predictive-ops streaming steps,
and any long sequence of costed operations.

A `Stage` implementation only needs:
  - a stable `name` (used for resume-from matching and cost attribution),
  - a sync `run(project)` that returns a StageResult,
  - an optional `should_skip(project)` that returns True when the stage's
    output is already present on disk (enables `resume_from=<name>` to
    also skip earlier stages whose artefacts still exist).

Why sync? Keeps the Protocol tiny and testable. Stages that need I/O
concurrency can call `asyncio.run` internally — the orchestrator remains
a sequential driver.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, runtime_checkable

StageStatus = Literal["ok", "skipped", "failed"]


@dataclass
class StageResult:
    """One stage's outcome. Every orchestrator run emits a list of these."""

    stage: str
    status: StageStatus
    cost_usd: float = 0.0
    duration_seconds: float = 0.0
    artifacts: dict[str, Any] = field(default_factory=dict)
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "ok"


@runtime_checkable
class Stage(Protocol):
    """Every pipeline step implements this. Subclass `hexa_swarm_core...` or roll your own."""

    name: str

    def run(self, project: dict[str, Any]) -> StageResult: ...

    def should_skip(self, project: dict[str, Any]) -> bool:  # noqa: ARG002
        """Default: never skip. Override to enable idempotent re-runs."""
        return False


__all__ = ["Stage", "StageResult", "StageStatus"]
