"""
Tier A installer — copies `hexa_swarm_core.assets.tier_a` into a target repo.

Non-destructive by default: existing files are left alone and reported as
"skipped" unless `--force` is passed. Every installed file is recorded in
`.hexa/profile.yaml -> installed_assets` for later audit and for
`hexa adopt --force` (surgical re-install).
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from pathlib import Path

from hexa_swarm_core.assets import tier_a_root


@dataclass
class InstallPlan:
    will_create: list[Path] = field(default_factory=list)
    will_overwrite: list[Path] = field(default_factory=list)
    will_skip: list[Path] = field(default_factory=list)

    @property
    def files_touched(self) -> list[Path]:
        return self.will_create + self.will_overwrite


@dataclass
class InstallResult:
    created: list[Path] = field(default_factory=list)
    overwritten: list[Path] = field(default_factory=list)
    skipped: list[Path] = field(default_factory=list)

    @property
    def installed_assets(self) -> list[str]:
        """Relative paths for the profile.installed_assets field."""
        return sorted({str(p).replace("\\", "/") for p in self.created + self.overwritten})


def _iter_assets(src_root: Path) -> list[Path]:
    """Walk the Tier A assets, return file paths relative to the asset root."""
    paths: list[Path] = []
    for p in sorted(src_root.rglob("*")):
        if p.is_file():
            rel = p.relative_to(src_root)
            # Skip bundle-internal `.gitkeep` — we don't want to copy those
            # verbatim, we want to *create* the directory and leave it empty.
            if rel.name == ".gitkeep":
                paths.append(rel)
                continue
            paths.append(rel)
    return paths


def plan(target_root: Path, *, force: bool) -> InstallPlan:
    src_root = tier_a_root()
    if not src_root.exists():
        raise FileNotFoundError(f"Tier A asset bundle not found at {src_root}")
    p = InstallPlan()
    for rel in _iter_assets(src_root):
        dst = target_root / rel
        if dst.exists():
            if rel.name == ".gitkeep":
                # Directory already present — treat as a skip so we don't
                # spam the user with gitkeep noise.
                p.will_skip.append(rel)
            elif force:
                p.will_overwrite.append(rel)
            else:
                p.will_skip.append(rel)
        else:
            p.will_create.append(rel)
    return p


def install(
    target_root: Path,
    *,
    force: bool = False,
    dry_run: bool = False,
) -> InstallResult:
    src_root = tier_a_root()
    if not src_root.exists():
        raise FileNotFoundError(f"Tier A asset bundle not found at {src_root}")

    result = InstallResult()
    for rel in _iter_assets(src_root):
        src = src_root / rel
        dst = target_root / rel

        if dst.exists() and not force and rel.name != ".gitkeep":
            result.skipped.append(rel)
            continue

        if dry_run:
            if dst.exists() and force:
                result.overwritten.append(rel)
            elif not dst.exists():
                result.created.append(rel)
            continue

        dst.parent.mkdir(parents=True, exist_ok=True)
        if rel.name == ".gitkeep":
            # Ensure the directory exists but do not overwrite existing files.
            if not dst.exists():
                dst.write_text("", encoding="utf-8")
                result.created.append(rel)
            else:
                result.skipped.append(rel)
            continue

        existed = dst.exists()
        shutil.copy2(src, dst)
        if existed:
            result.overwritten.append(rel)
        else:
            result.created.append(rel)

    return result


__all__ = ["InstallPlan", "InstallResult", "install", "plan"]
