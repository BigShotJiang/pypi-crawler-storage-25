"""
KillSwitch — file-flag-based hard stop for autonomous agents.

Cheap and race-free: the presence of `.ai-sync/KILL` means "abort the next
tool call". Used by PreToolUse hooks and long-running RPA/data-pipeline loops.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from hexa_swarm_core.exceptions import SafetyViolationError

KILL_FILE_REL = ".ai-sync/KILL"


class KillSwitch:
    def __init__(self, project_root: Path | str = ".") -> None:
        self.project_root = Path(project_root).resolve()

    @property
    def path(self) -> Path:
        return self.project_root / KILL_FILE_REL

    def is_active(self) -> bool:
        return self.path.exists()

    def activate(self, reason: str = "") -> Path:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(UTC).isoformat()
        self.path.write_text(f"{stamp} :: {reason}\n", encoding="utf-8")
        return self.path

    def deactivate(self) -> bool:
        if self.path.exists():
            self.path.unlink()
            return True
        return False

    def assert_live(self) -> None:
        """Raise SafetyViolationError if the kill switch is engaged."""
        if self.is_active():
            raise SafetyViolationError("Kill switch is active — aborting.", invariant="S5")


__all__ = ["KILL_FILE_REL", "KillSwitch"]
