"""
CostCeiling — enforces S4 universal invariant (LLM spend cap per session).

Usage:
    ceiling = CostCeiling(max_usd=5.0, tracker=default_tracker())
    ceiling.check_can_spend(project_id, estimated_usd=0.02)
    # ... make LLM call, then record via CostTracker
"""

from __future__ import annotations

from hexa_swarm_core.exceptions import SafetyViolationError
from hexa_swarm_core.telemetry.cost import CostTracker


class CostCeiling:
    def __init__(self, *, max_usd: float, tracker: CostTracker) -> None:
        if max_usd <= 0:
            raise ValueError("max_usd must be positive")
        self.max_usd = float(max_usd)
        self.tracker = tracker

    def remaining(self, *, project_id: str, stage: str | None = None) -> float:
        spent = self.tracker.total(project_id=project_id, stage=stage)
        return max(0.0, self.max_usd - spent)

    def check_can_spend(
        self,
        project_id: str,
        *,
        estimated_usd: float,
        stage: str | None = None,
    ) -> None:
        if estimated_usd < 0:
            raise ValueError("estimated_usd must be non-negative")
        spent = self.tracker.total(project_id=project_id, stage=stage)
        if spent + estimated_usd > self.max_usd:
            raise SafetyViolationError(
                f"Cost ceiling would be exceeded: spent={spent:.4f} + est={estimated_usd:.4f} "
                f"> max={self.max_usd:.4f}",
                invariant="S4",
            )


__all__ = ["CostCeiling"]
