"""
Prompt-injection defense (S6 universal invariant).

Extracted from the template's `shared/helpers.py` so every project — regardless
of stack — gets the same sanitation via `hexa_swarm_core`. Adapters can point
their invariant enforcers at this module so "did you route user text through
sanitize_for_prompt?" is a static check.

The chain (two passes):
  1. Primary
     a. NFKC normalise (fullwidth / compatibility → canonical form, preserves
        Korean and CJK readability).
     b. Strip `Cf` (format) unicode category — closes ZWSP and bidi-override bypasses.
     c. Remove C0/C1 control chars (tab and newline preserved).
     d. XML-escape `<` `>` `&`.
     e. Inject zero-width space into detected injection triggers so the model
        cannot treat them as instructions.
  2. Probe (detection only)
     a. NFKD normalise (decomposes Ó → O + combining acute).
     b. Strip `Cf` + `Mn`.
     c. If the regex matches here but not in the primary pass, prepend a ZWSP
        marker so the downstream marker-check still trips.

Why two passes?  NFKC preserves Korean syllables, which we need for the Korean
injection patterns.  NFKD catches combining-mark homographs.  Running both
gives correctness on both axes without destroying readability.
"""

from __future__ import annotations

import re
import unicodedata

_INJECTION_PATTERNS: list[str] = [
    r"IGNORE\s+(ALL\s+)?(PREVIOUS\s+)?INSTRUCTIONS?",
    r"SYSTEM\s*:",
    r"ASSISTANT\s*:",
    r"USER\s*:",
    r"<\s*/?\s*(?:system|instruction|prompt|role)\s*>?",
    r"YOU\s+ARE\s+NOW",
    r"FORGET\s+(EVERYTHING|ALL)",
    r"DO\s+NOT\s+FOLLOW",
    r"OVERRIDE\s+(?:ALL|PREVIOUS|SYSTEM)",
    r"NEW\s+INSTRUCTIONS?",
    r"DISREGARD\s+(?:ALL|PREVIOUS|ABOVE)",
    # Korean — medical / finance domains in Korean enterprises
    r"이전\s*지시\s*(사항)?\s*(을|를)?\s*(무시|잊어|버려)",
    r"역할\s*(을|를)?\s*변경",
    r"지시\s*(사항)?\s*(을|를)?\s*(무시|변경|취소)",
    r"새로운\s*지시",
    r"모든\s*규칙\s*(을|를)?\s*(무시|잊어)",
]
_INJECTION_RE = re.compile("|".join(f"(?:{p})" for p in _INJECTION_PATTERNS), re.IGNORECASE)
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_XML_MAP = str.maketrans({"<": "&lt;", ">": "&gt;", "&": "&amp;"})

DEFAULT_MAX_LENGTH = 5000


def _strip_cf(text: str) -> str:
    return "".join(ch for ch in text if unicodedata.category(ch) != "Cf")


def _strip_cf_mn(text: str) -> str:
    return "".join(ch for ch in text if unicodedata.category(ch) not in {"Cf", "Mn"})


def sanitize_for_prompt(text: str, max_length: int = DEFAULT_MAX_LENGTH) -> str:
    """Return a defanged version of `text` safe to interpolate into an LLM prompt."""
    if not text:
        return ""

    # Primary pass — keep Korean and CJK readable.
    primary = unicodedata.normalize("NFKC", text)
    primary = _strip_cf(primary)
    primary = _CONTROL_RE.sub("", primary)
    primary = primary.translate(_XML_MAP)

    def _defang(m: re.Match[str]) -> str:
        word = m.group(0)
        if len(word) <= 2:
            return word
        return word[0] + "\u200b" + word[1:]

    primary_defanged = _INJECTION_RE.sub(_defang, primary)

    # Probe pass — catch combining-mark homographs the primary pass misses.
    probe = unicodedata.normalize("NFKD", text)
    probe = _strip_cf_mn(probe)
    missed_by_primary = (
        _INJECTION_RE.search(probe) is not None and "\u200b" not in primary_defanged
    )
    if missed_by_primary and primary_defanged:
        primary_defanged = primary_defanged[0] + "\u200b" + primary_defanged[1:]

    result = re.sub(r"\n{3,}", "\n\n", primary_defanged)
    if len(result) > max_length:
        result = result[:max_length] + "...[truncated]"
    return result


def contains_injection_marker(text: str) -> bool:
    """Fast check used by audit tools — does `text` contain a sanitized marker?"""
    return "\u200b" in text or "...[truncated]" in text


__all__ = ["DEFAULT_MAX_LENGTH", "contains_injection_marker", "sanitize_for_prompt"]
