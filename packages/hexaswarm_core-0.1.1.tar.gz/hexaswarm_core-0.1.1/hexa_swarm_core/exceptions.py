"""
Exception hierarchy for hexa_swarm_core.

Inspired by ai-coin's `SafetyViolationError(invariant="S1")` pattern.
All custom errors carry a stable `code` so they can be mapped to HTTP status,
CI error codes, or log fields without string parsing.
"""

from __future__ import annotations


class HexaError(Exception):
    """Base class. All library-raised errors inherit this."""

    code: str = "HEXA_UNKNOWN"

    def __init__(self, message: str = "", *, code: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        if code:
            self.code = code


# --- Domain errors ---------------------------------------------------------
class DomainError(HexaError):
    code = "DOMAIN_ERROR"


class ValidationError(DomainError):
    code = "VALIDATION"


# --- External / network ----------------------------------------------------
class ExternalError(HexaError):
    code = "EXTERNAL"


class LLMError(ExternalError):
    code = "LLM_PROVIDER"


class DBError(ExternalError):
    code = "DB"


# --- Safety (invariant violations) -----------------------------------------
class SafetyViolationError(HexaError):
    """Raised when a request violates one of the Safety Invariants.

    Usage:
        raise SafetyViolationError(
            "Cost ceiling exceeded: 5.12 > 5.00",
            invariant="S4",
        )
    """

    code = "SAFETY_VIOLATION"

    def __init__(self, message: str = "", *, invariant: str) -> None:
        self.invariant = invariant
        super().__init__(message, code=f"SAFETY_{invariant}")


# --- Adapter / profile -----------------------------------------------------
class AdapterError(HexaError):
    code = "ADAPTER"


class ProfileError(HexaError):
    code = "PROFILE"


# --- Concurrency -----------------------------------------------------------
class LockError(HexaError):
    code = "LOCK"


class LockBusyError(LockError):
    code = "LOCK_BUSY"


__all__ = [
    "AdapterError",
    "DBError",
    "DomainError",
    "ExternalError",
    "HexaError",
    "LLMError",
    "LockBusyError",
    "LockError",
    "ProfileError",
    "SafetyViolationError",
    "ValidationError",
]
