"""
Archetype — the "shape" a project takes independent of its stack.

Every repo adopted into the hexa framework picks one of eight archetypes
(fullstack-web, backend-api, frontend-app, cli-tool, data-pipeline,
rpa-bot, ml-training, library). The archetype controls:

  - Which default stacks the auto-detect prefers (e.g. fullstack-web
    wants py-fastapi + node-next first).
  - Which feature flags get seeded in `.hexa/profile.yaml` so the
    conditional invariants (S1/S2/S3) switch on appropriately.
  - Which skills MUST ship (subset of the 10 universal skills) and
    which are optional.
  - Which CI workflows get activated by default.
  - Directory patterns we expect present so confidence is high during
    `hexa adopt`'s archetype auto-inference.

Archetypes are plain data classes, not plugins. Users add a new one by
dropping a definition in `definitions.py` and registering it.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Archetype:
    id: str
    description: str
    default_stacks: tuple[str, ...] = ()
    default_feature_flags: dict[str, bool] = field(default_factory=dict)
    required_skills: tuple[str, ...] = ()
    optional_skills: tuple[str, ...] = ()
    ci_workflows: tuple[str, ...] = ()
    dir_expectations: tuple[str, ...] = ()
    notes: str = ""

    def summary(self) -> dict[str, object]:
        """Plain-dict representation for the CLI + CI."""
        return {
            "id": self.id,
            "description": self.description,
            "default_stacks": list(self.default_stacks),
            "default_feature_flags": dict(self.default_feature_flags),
            "required_skills": list(self.required_skills),
            "optional_skills": list(self.optional_skills),
            "ci_workflows": list(self.ci_workflows),
            "dir_expectations": list(self.dir_expectations),
            "notes": self.notes,
        }


__all__ = ["Archetype"]
