"""Archetype registry + heuristic auto-detection."""

from __future__ import annotations

from pathlib import Path

from hexa_swarm_core.archetypes.definitions import ALL_DEFAULT
from hexa_swarm_core.archetypes.protocol import Archetype
from hexa_swarm_core.exceptions import HexaError

ARCHETYPES: tuple[Archetype, ...] = ALL_DEFAULT
ARCHETYPE_IDS: tuple[str, ...] = tuple(a.id for a in ARCHETYPES)


def get_archetype(archetype_id: str) -> Archetype:
    for a in ARCHETYPES:
        if a.id == archetype_id:
            return a
    raise HexaError(
        f"Unknown archetype: {archetype_id!r}. Known: {list(ARCHETYPE_IDS)}",
        code="ARCHETYPE_UNKNOWN",
    )


def detect_archetype(project_root: Path, adapter_names: list[str]) -> str:
    """Heuristic: directory layout + detected adapters → archetype id.

    The rules mirror (and will eventually replace) the older
    `_infer_archetype` in `cli/adopt.py`. They are documented in
    docs/archetype-guide.md.
    """
    root = project_root.resolve()
    has_backend = (root / "src" / "backend").exists() or (root / "backend").exists()
    has_frontend = (
        (root / "app").exists()
        or (root / "src" / "frontend").exists()
        or (root / "next.config.ts").exists()
        or (root / "next.config.js").exists()
    )
    has_notebooks = _has_any_notebook(root)
    has_pipelines = (
        (root / "src" / "pipeline").exists()
        or (root / "pipelines").exists()
        or (root / "dags").exists()
    )
    has_bot = (root / "src" / "bot").exists() or (root / "bot").exists() or (root / "src" / "automation").exists()
    has_celery_stack = "py-celery" in adapter_names
    has_django_stack = "py-django" in adapter_names
    has_click_stack = "py-click" in adapter_names
    has_fastapi_stack = "py-fastapi" in adapter_names
    has_node_stack = "node-next" in adapter_names or "node-nest" in adapter_names or "node-express" in adapter_names
    is_py_package = (root / "pyproject.toml").exists() and not has_backend
    # Library heuristic: a src/ layout + tests/ + no app code is the common PyPI shape.
    looks_like_library = (
        (root / "src").exists()
        and (root / "tests").exists()
        and not has_backend
        and not has_frontend
        and not has_bot
        and not has_pipelines
        and not has_notebooks
    )

    if has_notebooks:
        return "ml-training"
    if has_pipelines or has_celery_stack:
        return "data-pipeline"
    if has_bot:
        return "rpa-bot"

    if has_backend and (has_frontend or has_node_stack):
        return "fullstack-web"
    if has_frontend and not has_backend:
        return "frontend-app"
    if has_backend and not has_frontend:
        return "backend-api"
    if has_django_stack:
        return "backend-api"
    if has_click_stack:
        return "cli-tool"
    if has_fastapi_stack:
        return "backend-api"
    if looks_like_library:
        return "library"
    if is_py_package:
        return "cli-tool"
    return "cli-tool"


_NOTEBOOK_SKIP_DIRS = frozenset(
    {".git", ".venv", "venv", "node_modules", ".tox", "dist", "build", "__pycache__", ".next", "target"}
)


def _has_any_notebook(root: Path) -> bool:
    """True if any `.ipynb` exists outside common tool/vendor dirs.

    `rglob` would descend into `.venv/.../jupyter/tests/...` and mislabel
    any Python repo with jupyter installed as `ml-training`. This walk
    prunes the usual suspects and short-circuits on first match.
    """
    stack: list[Path] = [root]
    while stack:
        d = stack.pop()
        try:
            for entry in d.iterdir():
                if entry.is_dir():
                    if entry.name not in _NOTEBOOK_SKIP_DIRS and not entry.name.startswith("."):
                        stack.append(entry)
                elif entry.suffix == ".ipynb":
                    return True
        except OSError:
            continue
    return False


__all__ = [
    "ARCHETYPES",
    "ARCHETYPE_IDS",
    "detect_archetype",
    "get_archetype",
]
