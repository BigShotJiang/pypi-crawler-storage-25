"""Archetype definitions.

Edit / add rules:
  - Keep `required_skills` minimal; universally useful ones live in the Tier A
    asset bundle, not in a per-archetype requirement list.
  - Feature flags drive conditional invariants (S1/S2/S3). Defaults should be
    the common-case answer for the archetype; operators override per-project
    in `.hexa/profile.yaml` post-adopt.
  - `ci_workflows` list filenames relative to `{{project_slug}}/.github/workflows/`.
    Names must exist in the template output for activation to stick.
"""

from __future__ import annotations

from hexa_swarm_core.archetypes.protocol import Archetype

FULLSTACK_WEB = Archetype(
    id="fullstack-web",
    description="Backend + Frontend + DB in one repo (FastAPI + Next.js is the canonical combo).",
    default_stacks=("py-fastapi", "node-next"),
    default_feature_flags={
        "has_advisory_output": False,
        "has_deterministic_contracts": False,
        "has_external_integrations": True,
    },
    required_skills=(
        "quality-gate",
        "security-audit",
        "deploy-check",
        "cross-sync-alert",
        "contract-sync",
        "ship",
    ),
    optional_skills=("auto-test", "cost-tracker", "worktree-boot", "fix-issue"),
    ci_workflows=(
        "backend-ci.yml",
        "frontend-ci.yml",
        "invariants.yml",
        "security-audit.yml",
        "contracts-drift.yml",
        "ownership.yml",
        "parallel-lane.yml",
        "cost-cap.yml",
    ),
    dir_expectations=("src/backend", "app", "src/frontend", "next.config.ts", "next.config.js"),
    notes="Use when BE and FE live side-by-side and share one release train.",
)

BACKEND_API = Archetype(
    id="backend-api",
    description="Headless API service. No frontend. Optionally a DB + workers.",
    default_stacks=("py-fastapi",),
    default_feature_flags={
        "has_advisory_output": False,
        "has_deterministic_contracts": False,
        "has_external_integrations": True,
    },
    required_skills=(
        "quality-gate",
        "security-audit",
        "deploy-check",
        "contract-sync",
        "ship",
    ),
    optional_skills=("auto-test", "cost-tracker", "worktree-boot", "fix-issue"),
    ci_workflows=(
        "backend-ci.yml",
        "invariants.yml",
        "security-audit.yml",
        "contracts-drift.yml",
        "ownership.yml",
        "cost-cap.yml",
    ),
    dir_expectations=("src/backend", "backend", "pyproject.toml"),
    notes="Pair with archetype `frontend-app` in a sibling repo for split FE/BE.",
)

FRONTEND_APP = Archetype(
    id="frontend-app",
    description="Frontend-only app (Next.js / Vite / etc.) consuming an external API.",
    default_stacks=("node-next",),
    default_feature_flags={
        "has_advisory_output": False,
        "has_deterministic_contracts": False,
        "has_external_integrations": True,
    },
    required_skills=(
        "quality-gate",
        "deploy-check",
        "cross-sync-alert",
        "ship",
    ),
    optional_skills=("auto-test", "contract-sync", "worktree-boot", "fix-issue"),
    ci_workflows=(
        "frontend-ci.yml",
        "invariants.yml",
        "security-audit.yml",
        "ownership.yml",
    ),
    dir_expectations=("app", "src/frontend", "next.config.ts", "next.config.js", "package.json"),
    notes="Contracts stay read-only - generated types come from the BE repo via `contract-sync`.",
)

CLI_TOOL = Archetype(
    id="cli-tool",
    description="Command-line tool (Typer/Click/argparse). No long-running process, no FE.",
    default_stacks=("py-click",),
    default_feature_flags={
        "has_advisory_output": False,
        "has_deterministic_contracts": True,
        "has_external_integrations": False,
    },
    required_skills=(
        "quality-gate",
        "security-audit",
        "ship",
    ),
    optional_skills=("auto-test", "cost-tracker", "fix-issue"),
    ci_workflows=(
        "backend-ci.yml",
        "invariants.yml",
        "security-audit.yml",
    ),
    dir_expectations=("pyproject.toml", "setup.py", "requirements.txt"),
    notes="Deterministic by default - S2 is enforced unless the tool explicitly opts out.",
)

DATA_PIPELINE = Archetype(
    id="data-pipeline",
    description="Staged batch/stream processing (Celery/Airflow/custom) with resume + cost tracking.",
    default_stacks=("py-celery",),
    default_feature_flags={
        # Stage outputs typically need to be reproducible for debugging,
        # so deterministic contracts default on. Cost tracking matters most
        # here because LLM-in-the-loop pipelines dominate spend.
        "has_advisory_output": False,
        "has_deterministic_contracts": True,
        "has_external_integrations": True,
    },
    required_skills=(
        "quality-gate",
        "security-audit",
        "cost-tracker",
        "ship",
    ),
    optional_skills=("auto-test", "worktree-boot", "fix-issue"),
    ci_workflows=(
        "backend-ci.yml",
        "invariants.yml",
        "security-audit.yml",
        "cost-cap.yml",
    ),
    dir_expectations=("src/pipeline", "pipelines", "dags", "workflows"),
    notes="Pair with PipelineOrchestrator (resume_from) and CostTracker JSONL ledger.",
)

RPA_BOT = Archetype(
    id="rpa-bot",
    description="Long-running automation/RPA agent with killswitch + stochastic delays + circuit breaker.",
    default_stacks=("py-click",),
    default_feature_flags={
        # RPA bots touch external systems constantly; idempotency matters.
        # Advisory output is almost always on (the bot logs what it *would*
        # have done before --execute).
        "has_advisory_output": True,
        "has_deterministic_contracts": False,
        "has_external_integrations": True,
    },
    required_skills=(
        "quality-gate",
        "security-audit",
        "cost-tracker",
        "ship",
    ),
    optional_skills=("auto-test", "fix-issue"),
    ci_workflows=(
        "backend-ci.yml",
        "invariants.yml",
        "security-audit.yml",
        "cost-cap.yml",
    ),
    dir_expectations=("src/bot", "bot", "src/automation"),
    notes="Relies on hexa_swarm_core.safety KillSwitch/CircuitBreaker/stochastic_delay.",
)

ML_TRAINING = Archetype(
    id="ml-training",
    description="Notebooks + experiments + model registry. Training loops, not inference serving.",
    default_stacks=("py-click",),
    default_feature_flags={
        # ML work produces advisory output by nature - predictions require
        # human review before acting. Determinism is usually NOT possible
        # (stochastic training) so S2 stays off.
        "has_advisory_output": True,
        "has_deterministic_contracts": False,
        "has_external_integrations": False,
    },
    required_skills=(
        "quality-gate",
        "cost-tracker",
        "ship",
    ),
    optional_skills=("auto-test", "security-audit", "fix-issue"),
    ci_workflows=(
        "backend-ci.yml",
        "invariants.yml",
        "cost-cap.yml",
    ),
    dir_expectations=("notebooks", "experiments", "models", "data"),
    notes="Inference-serving repos should use `backend-api`; this archetype is for training runs.",
)

LIBRARY = Archetype(
    id="library",
    description="Published package (PyPI/npm) imported by other code. No app, no long-running process.",
    default_stacks=("py-click",),
    default_feature_flags={
        # Libraries should behave identically across calls -> determinism on.
        # They don't call external services themselves (consumers do).
        "has_advisory_output": False,
        "has_deterministic_contracts": True,
        "has_external_integrations": False,
    },
    required_skills=(
        "quality-gate",
        "security-audit",
        "ship",
    ),
    optional_skills=("auto-test", "fix-issue"),
    ci_workflows=(
        "backend-ci.yml",
        "invariants.yml",
        "security-audit.yml",
    ),
    dir_expectations=("pyproject.toml", "src", "tests"),
    notes="Release via `hexa ship` -> builds wheel/sdist and tags. No deploy-check (no deployment).",
)


ALL_DEFAULT: tuple[Archetype, ...] = (
    FULLSTACK_WEB,
    BACKEND_API,
    FRONTEND_APP,
    CLI_TOOL,
    DATA_PIPELINE,
    RPA_BOT,
    ML_TRAINING,
    LIBRARY,
)

__all__ = [
    "ALL_DEFAULT",
    "BACKEND_API",
    "CLI_TOOL",
    "DATA_PIPELINE",
    "FRONTEND_APP",
    "FULLSTACK_WEB",
    "LIBRARY",
    "ML_TRAINING",
    "RPA_BOT",
]
