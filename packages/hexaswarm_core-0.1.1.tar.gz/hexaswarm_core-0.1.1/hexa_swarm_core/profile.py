"""
Profile — `.hexa/profile.yaml` load / save / create.

Created by `hexa adopt` and read by every CLI command. Single source of truth
for "which archetype + which stack adapters apply to this repo".
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field

from hexa_swarm_core.exceptions import ProfileError

PROFILE_DIR = ".hexa"
PROFILE_FILE = "profile.yaml"

DEFAULT_UNIVERSAL_INVARIANTS: tuple[str, ...] = ("S4", "S5", "S6")


class Profile(BaseModel):
    """Schema for `.hexa/profile.yaml`."""

    archetype: str = "backend-api"
    stacks: list[str] = Field(default_factory=list)
    adapters_enabled: list[str] = Field(default_factory=list)
    invariants: list[str] = Field(default_factory=lambda: list(DEFAULT_UNIVERSAL_INVARIANTS))
    feature_flags: dict[str, bool] = Field(default_factory=dict)
    adopted_at: str = ""
    notes: str = ""

    model_config = {"extra": "allow"}  # forward-compat: unknown keys preserved


def profile_path(project_root: Path) -> Path:
    return project_root.resolve() / PROFILE_DIR / PROFILE_FILE


def load_profile(project_root: Path) -> Profile:
    path = profile_path(project_root)
    if not path.exists():
        raise ProfileError(
            f"No .hexa/profile.yaml at {path}. Run `hexa adopt .` first.",
        )
    try:
        data: Any = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise ProfileError(f"Malformed profile: {exc}") from exc
    return Profile.model_validate(data)


def save_profile(project_root: Path, profile: Profile) -> Path:
    path = profile_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    dumped = yaml.safe_dump(profile.model_dump(mode="json"), sort_keys=False, allow_unicode=True)
    path.write_text(dumped, encoding="utf-8")
    return path


def init_profile(
    project_root: Path,
    *,
    archetype: str,
    stacks: list[str],
    adapters_enabled: list[str] | None = None,
    feature_flags: dict[str, bool] | None = None,
    invariants: list[str] | None = None,
    notes: str = "",
) -> Profile:
    return Profile(
        archetype=archetype,
        stacks=stacks,
        adapters_enabled=adapters_enabled if adapters_enabled is not None else list(stacks),
        invariants=invariants if invariants is not None else list(DEFAULT_UNIVERSAL_INVARIANTS),
        feature_flags=feature_flags or {},
        adopted_at=datetime.now(UTC).isoformat(),
        notes=notes,
    )


__all__ = [
    "DEFAULT_UNIVERSAL_INVARIANTS",
    "PROFILE_DIR",
    "PROFILE_FILE",
    "Profile",
    "init_profile",
    "load_profile",
    "profile_path",
    "save_profile",
]
