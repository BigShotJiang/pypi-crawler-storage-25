"""
Provider response dataclasses.

Pattern extracted from ai-video/src/services/base.py. Every paid external
service (LLM / TTS / image / search / translation) returns one of these,
carrying `cost_usd` so the CostTracker and CostCeiling have a uniform hook.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class LLMResponse:
    text: str
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    model: str = ""
    provider: str = ""
    latency_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TTSResponse:
    audio_bytes: bytes
    duration_seconds: float = 0.0
    cost_usd: float = 0.0
    voice: str = ""
    provider: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ImageResponse:
    image_bytes: bytes
    width: int = 0
    height: int = 0
    cost_usd: float = 0.0
    provider: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


__all__ = ["ImageResponse", "LLMResponse", "TTSResponse"]
