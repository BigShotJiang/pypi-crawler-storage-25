"""
BaseLLMClient + safe_generate — the universal wrapper for any LLM provider.

Pattern extracted from ai-coin/src/backend/clients/llm/base.py.

Every concrete provider (Anthropic, OpenAI, Gemini, local) subclasses
`BaseLLMClient` and implements `_generate`. Users call `safe_generate`,
which:

  1. Sanitises the user text through `sanitize_for_prompt` (S6 enforced).
  2. Checks the CostCeiling (if configured) — raises S4 violation *before* the call.
  3. Retries on transient errors with exponential backoff.
  4. Records cost to the CostTracker (if configured).

Retryable errors: timeouts, HTTP 429, HTTP 5xx, connection resets.
Non-retryable: auth errors, 4xx (except 429), malformed prompts.
"""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from typing import Any

from hexa_swarm_core.exceptions import LLMError
from hexa_swarm_core.providers.base import LLMResponse
from hexa_swarm_core.safety.ceiling import CostCeiling
from hexa_swarm_core.safety.prompt import sanitize_for_prompt
from hexa_swarm_core.telemetry.cost import CostTracker

logger = logging.getLogger("hexa.llm")


class LLMProviderError(LLMError):
    """Raised by provider implementations; retryability inferred via the message."""

    code = "LLM_PROVIDER"


_RETRYABLE_TOKENS = (
    "timeout",
    "timed out",
    "rate limit",
    "rate_limit",
    "429",
    " 500",
    " 502",
    " 503",
    " 504",
    "connection reset",
    "connection aborted",
    "server disconnected",
)


def is_retryable_error(exc: BaseException) -> bool:
    """Heuristic: is this exception worth retrying with backoff?"""
    msg = str(exc).lower()
    return any(tok in msg for tok in _RETRYABLE_TOKENS)


class BaseLLMClient(ABC):
    """Subclass per provider. Override `_generate`.

    Concrete subclasses should set `provider` (e.g. "anthropic") + `model`.
    """

    provider: str = "base"
    model: str = ""

    _MAX_RETRIES: int = 3
    _BACKOFF_BASE: float = 2.0  # seconds
    _BACKOFF_CAP: float = 30.0

    def __init__(
        self,
        *,
        cost_tracker: CostTracker | None = None,
        cost_ceiling: CostCeiling | None = None,
        project_id: str = "default",
        sanitize: bool = True,
    ) -> None:
        self.cost_tracker = cost_tracker
        self.cost_ceiling = cost_ceiling
        self.project_id = project_id
        self.sanitize = sanitize

    # ------------------------------------------------------------------
    # Subclass surface
    # ------------------------------------------------------------------
    @abstractmethod
    def _generate(
        self,
        *,
        user_prompt: str,
        system_prompt: str = "",
        max_tokens: int = 4096,
        temperature: float = 0.7,
        **kwargs: Any,
    ) -> LLMResponse: ...

    # ------------------------------------------------------------------
    # Public surface
    # ------------------------------------------------------------------
    def safe_generate(
        self,
        user_prompt: str,
        *,
        system_prompt: str = "",
        max_tokens: int = 4096,
        temperature: float = 0.7,
        stage: str = "generate",
        estimated_usd: float = 0.0,
        **kwargs: Any,
    ) -> LLMResponse:
        """Sanitise + ceiling-check + retry + cost-record."""
        prompt = sanitize_for_prompt(user_prompt) if self.sanitize else user_prompt

        if self.cost_ceiling is not None:
            # Ceiling is project-wide (S4 is a session/monthly budget, not per-stage).
            # The stage label still flows into the cost_tracker.record() below.
            self.cost_ceiling.check_can_spend(
                project_id=self.project_id,
                estimated_usd=estimated_usd,
            )

        last_exc: BaseException | None = None
        for attempt in range(1 + self._MAX_RETRIES):
            try:
                started = time.monotonic()
                resp = self._generate(
                    user_prompt=prompt,
                    system_prompt=system_prompt,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    **kwargs,
                )
                resp.latency_ms = (time.monotonic() - started) * 1000
                if not resp.provider:
                    resp.provider = self.provider
                if not resp.model:
                    resp.model = self.model

                if self.cost_tracker is not None and resp.cost_usd:
                    self.cost_tracker.record(
                        project_id=self.project_id,
                        stage=stage,
                        service=resp.provider or self.provider,
                        operation="generate",
                        cost_usd=resp.cost_usd,
                        model=resp.model or self.model,
                        tokens_in=resp.input_tokens,
                        tokens_out=resp.output_tokens,
                    )
                return resp

            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                if attempt >= self._MAX_RETRIES or not is_retryable_error(exc):
                    break
                delay = min(self._BACKOFF_BASE ** (attempt + 1), self._BACKOFF_CAP)
                logger.warning(
                    "llm retry %s/%s after %.1fs: %s",
                    attempt + 1,
                    self._MAX_RETRIES,
                    delay,
                    exc,
                )
                time.sleep(delay)

        assert last_exc is not None
        raise LLMProviderError(str(last_exc)) from last_exc


__all__ = ["BaseLLMClient", "LLMProviderError", "is_retryable_error"]
