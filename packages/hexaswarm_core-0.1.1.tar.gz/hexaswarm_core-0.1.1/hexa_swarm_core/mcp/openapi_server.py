"""
Minimal MCP server that exposes `.ai-sync/contracts/openapi.yaml` as
structured resources the agent can query by endpoint instead of grepping
the raw YAML into its context window.

Transport: stdio (matches the `.claude/mcp.json` entry).
Dependency: `mcp` Python package — installable via the `mcp` extra:
    pip install 'hexa-swarm-core[mcp]'

Exposed capabilities:
  - resource://openapi/info                 → spec title, version, server list
  - resource://openapi/operations            → list of (method, path, operationId, summary)
  - resource://openapi/operation/<opId>      → full operation object for one endpoint

If the spec file does not exist, every resource returns an empty placeholder
so the server still starts cleanly (useful for scaffolded projects).
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError as exc:  # pragma: no cover
    print("PyYAML is required: pip install pyyaml", file=sys.stderr)
    raise SystemExit(2) from exc


def load_spec(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        print(f"openapi_server: malformed YAML at {path}: {exc}", file=sys.stderr)
        return {}
    return data if isinstance(data, dict) else {}


def list_operations(spec: dict[str, Any]) -> list[dict[str, str]]:
    ops: list[dict[str, str]] = []
    paths = spec.get("paths") or {}
    for path, methods in paths.items():
        if not isinstance(methods, dict):
            continue
        for method, op in methods.items():
            if method.lower() not in {"get", "post", "put", "patch", "delete", "options", "head"}:
                continue
            if not isinstance(op, dict):
                continue
            ops.append(
                {
                    "method": method.upper(),
                    "path": path,
                    "operationId": str(op.get("operationId") or ""),
                    "summary": str(op.get("summary") or ""),
                }
            )
    return ops


def find_operation(spec: dict[str, Any], operation_id: str) -> dict[str, Any] | None:
    for path, methods in (spec.get("paths") or {}).items():
        if not isinstance(methods, dict):
            continue
        for method, op in methods.items():
            if not isinstance(op, dict):
                continue
            if op.get("operationId") == operation_id:
                return {"method": method.upper(), "path": path, **op}
    return None


def info(spec: dict[str, Any]) -> dict[str, Any]:
    meta = spec.get("info") or {}
    return {
        "title": meta.get("title", ""),
        "version": meta.get("version", ""),
        "description": meta.get("description", ""),
        "servers": spec.get("servers", []),
        "spec_file_present": bool(spec),
    }


async def _run_stdio(spec_path: Path) -> int:  # pragma: no cover - needs mcp extra
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
    except ImportError:
        print(
            "openapi_server: the `mcp` package is required. "
            "Install with `pip install 'hexa-swarm-core[mcp]'`.",
            file=sys.stderr,
        )
        return 2

    srv = Server("openapi")

    @srv.list_resources()
    async def _resources() -> list[dict[str, str]]:
        spec = load_spec(spec_path)
        out = [
            {"uri": "openapi://info", "name": "info", "description": "Spec metadata"},
            {"uri": "openapi://operations", "name": "operations", "description": "All operations"},
        ]
        for op in list_operations(spec):
            if op["operationId"]:
                out.append(
                    {
                        "uri": f"openapi://operation/{op['operationId']}",
                        "name": op["operationId"],
                        "description": f"{op['method']} {op['path']} — {op['summary']}",
                    }
                )
        return out

    @srv.read_resource()
    async def _read(uri: str) -> str:
        spec = load_spec(spec_path)
        if uri == "openapi://info":
            return json.dumps(info(spec), ensure_ascii=False, indent=2)
        if uri == "openapi://operations":
            return json.dumps(list_operations(spec), ensure_ascii=False, indent=2)
        prefix = "openapi://operation/"
        if uri.startswith(prefix):
            op = find_operation(spec, uri[len(prefix):])
            return json.dumps(op or {}, ensure_ascii=False, indent=2)
        return json.dumps({"error": f"unknown uri: {uri}"})

    async with stdio_server() as (read, write):
        await srv.run(read, write, srv.create_initialization_options())
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "spec",
        nargs="?",
        default=".ai-sync/contracts/openapi.yaml",
        help="Path to the OpenAPI YAML file to expose.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print what the server would expose and exit (useful in CI).",
    )
    args = parser.parse_args(argv)
    spec_path = Path(args.spec)

    if args.dry_run:
        spec = load_spec(spec_path)
        payload = {
            "info": info(spec),
            "operations": list_operations(spec),
            "spec_file": str(spec_path),
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    return asyncio.run(_run_stdio(spec_path))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
