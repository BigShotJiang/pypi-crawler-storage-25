"""MCP servers shipped by hexa_swarm_core.

Each server module is directly executable as `python -m hexa_swarm_core.mcp.<name>`
and wire-compatible with the Claude Code `.claude/mcp.json` stdio transport.
The `mcp` package is an optional extra — `pip install 'hexa-swarm-core[mcp]'`.
"""
