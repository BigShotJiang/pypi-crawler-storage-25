"""
Trace / request ID helpers.

Keeps three ids in ContextVars so structured log entries — wherever they are
emitted — carry the same correlation. This is cheap and reliable for
single-process workers; for distributed tracing, the `trace_id` is designed
to accept an inbound W3C Trace-Context header or OpenTelemetry span id.

Usage:
    from hexa_swarm_core.logging import bind_request, setup_logging, get_logger

    setup_logging()
    bind_request(request_id="req-42", session_id="abc", agent="Beta")
    get_logger().info("starting work")    # carries request_id/session_id/agent

In a FastAPI app, mount the middleware below — it extracts/generates an id
for every request.
"""

from __future__ import annotations

import contextlib
import uuid
from collections.abc import Iterator
from contextlib import contextmanager

from hexa_swarm_core.logging.config import (
    _agent_var,
    _request_id_var,
    _session_id_var,
    bind_request,
)

W3C_TRACEPARENT_HEADER = "traceparent"
X_REQUEST_ID_HEADER = "x-request-id"
X_SESSION_ID_HEADER = "x-session-id"


def new_trace_id() -> str:
    """Fresh 16-hex-char trace id (same shape as W3C trace parent)."""
    return uuid.uuid4().hex[:16]


def parse_traceparent(value: str | None) -> str | None:
    """Extract the 16-hex trace_id from a W3C traceparent header."""
    if not value:
        return None
    parts = value.split("-")
    # 00-<trace_id 32hex>-<span_id 16hex>-<flags 2hex>
    if len(parts) < 2 or len(parts[1]) < 16:
        return None
    return parts[1][:16]


@contextmanager
def trace_scope(
    *,
    request_id: str | None = None,
    session_id: str | None = None,
    agent: str | None = None,
) -> Iterator[str]:
    """Bind IDs for the lifetime of a context manager. Restores previous on exit."""
    tokens = [
        _request_id_var.set(request_id or new_trace_id()),
    ]
    if session_id is not None:
        tokens.append(_session_id_var.set(session_id))
    if agent is not None:
        tokens.append(_agent_var.set(agent))
    try:
        yield _request_id_var.get()
    finally:
        for t in reversed(tokens):
            with contextlib.suppress(LookupError, ValueError):
                t.var.reset(t)


class RequestIdMiddleware:
    """Tiny ASGI middleware — usable on any FastAPI/Starlette app.

        from fastapi import FastAPI
        from hexa_swarm_core.logging.tracing import RequestIdMiddleware

        app = FastAPI()
        app.add_middleware(RequestIdMiddleware)

    For each HTTP request it:
      - extracts X-Request-Id or W3C traceparent (whichever is present) or
        generates a new trace id,
      - binds it into the logging context for the duration of the request,
      - echoes `X-Request-Id` on the outbound response.

    The lifespan/websocket paths are passed through unchanged (binding a
    request id per ASGI message would be noise).
    """

    def __init__(self, app, header_name: str = X_REQUEST_ID_HEADER) -> None:  # noqa: ANN001
        self.app = app
        self.header_name = header_name.lower().encode("latin-1")

    async def __call__(self, scope, receive, send):  # noqa: ANN001
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        headers = dict(scope.get("headers") or [])
        inbound = headers.get(self.header_name, b"").decode("latin-1").strip()
        if not inbound:
            inbound = (
                parse_traceparent(
                    headers.get(W3C_TRACEPARENT_HEADER.encode("latin-1"), b"").decode("latin-1"),
                )
                or new_trace_id()
            )
        bind_request(request_id=inbound)

        header_bytes = self.header_name  # already bytes
        value_bytes = inbound.encode("latin-1")

        async def _send_with_header(message):  # noqa: ANN001
            if message["type"] == "http.response.start":
                raw_headers = list(message.get("headers") or [])
                if not any(h[0] == header_bytes for h in raw_headers):
                    raw_headers.append((header_bytes, value_bytes))
                message["headers"] = raw_headers
            await send(message)

        await self.app(scope, receive, _send_with_header)


__all__ = [
    "RequestIdMiddleware",
    "W3C_TRACEPARENT_HEADER",
    "X_REQUEST_ID_HEADER",
    "X_SESSION_ID_HEADER",
    "new_trace_id",
    "parse_traceparent",
    "trace_scope",
]
