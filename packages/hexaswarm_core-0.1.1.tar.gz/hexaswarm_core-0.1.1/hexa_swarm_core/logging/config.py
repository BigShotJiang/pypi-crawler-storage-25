"""Structured logging with request_id contextvar (structlog)."""

from __future__ import annotations

import logging
import os
import sys
import uuid
from contextvars import ContextVar
from typing import Any

import structlog

_request_id_var: ContextVar[str] = ContextVar("request_id", default="")
_session_id_var: ContextVar[str] = ContextVar("session_id", default="")
_agent_var: ContextVar[str] = ContextVar("agent", default="")


def _add_contextvars(
    _logger: Any,
    _method_name: str,
    event_dict: dict[str, Any],
) -> dict[str, Any]:
    rid = _request_id_var.get()
    sid = _session_id_var.get()
    agent = _agent_var.get()
    if rid:
        event_dict.setdefault("request_id", rid)
    if sid:
        event_dict.setdefault("session_id", sid)
    if agent:
        event_dict.setdefault("agent", agent)
    return event_dict


def setup_logging(
    level: str | None = None,
    *,
    json_output: bool | None = None,
) -> None:
    """Configure structlog + stdlib logging.

    Args:
        level: defaults to env `LOG_LEVEL` or `INFO`.
        json_output: defaults to env `LOG_JSON` or auto (JSON on non-TTY).
    """
    raw_level: str = level or os.getenv("LOG_LEVEL") or "INFO"
    lvl: str = raw_level.upper()
    use_json = (
        json_output
        if json_output is not None
        else (os.getenv("LOG_JSON", "").lower() in {"1", "true", "yes"} or not sys.stderr.isatty())
    )

    logging.basicConfig(
        level=lvl,
        format="%(message)s",
        stream=sys.stderr,
    )

    renderer: Any = (
        structlog.processors.JSONRenderer()
        if use_json
        else structlog.dev.ConsoleRenderer(colors=sys.stderr.isatty())
    )

    processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        _add_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        renderer,
    ]
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(getattr(logging, lvl, logging.INFO)),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str | None = None) -> Any:
    return structlog.get_logger(name)


def bind_request(
    request_id: str | None = None,
    *,
    session_id: str | None = None,
    agent: str | None = None,
) -> str:
    """Bind request/session/agent IDs for the current context. Returns request_id."""
    rid = request_id or uuid.uuid4().hex[:12]
    _request_id_var.set(rid)
    if session_id is not None:
        _session_id_var.set(session_id)
    if agent is not None:
        _agent_var.set(agent)
    return rid


__all__ = ["bind_request", "get_logger", "setup_logging"]
