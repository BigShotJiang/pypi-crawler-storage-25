# hexa-swarm-core

Universal primitives for Claude-native multi-agent software delivery.
Provides the `hexa` CLI plus a Python library used by `hexa-swarm-template` and any project adopted via `hexa adopt .`.

## What lives here

- **`hexa` CLI** — `hexa adopt`, `hexa quality-gate`, `hexa lock`, `hexa session`, `hexa cost-track`
- **StackAdapter protocol** — pluggable language/framework support (py-fastapi, node-next, go-chi, …)
- **Orchestrator primitives** — atomic file locks, session UUID, heartbeat, contract writer queue
- **Telemetry** — JSONL cost tracker, structured logging, trace IDs
- **Safety** — KillSwitch, CostCeiling, CircuitBreaker, stochastic delay
- **Exceptions** — `SafetyViolationError(invariant=...)` hierarchy
- **Config** — Pydantic nested settings

## Install

```bash
pipx install hexa-swarm-core
hexa --help
```

## Adopt an existing repo (non-destructive)

```bash
cd my-existing-project
hexa adopt . --dry-run   # show what would change
hexa adopt .             # install Tier A only
```

See the parent repo's [README](../README.md) and [ARCHITECTURE.md](../ARCHITECTURE.md) for the full picture.
