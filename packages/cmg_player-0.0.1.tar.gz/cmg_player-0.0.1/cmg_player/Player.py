"""
Esta es la docuemtacion de PLAYER
"""


class Player:
    """
    Crea un reproductor de musica
    """

    def play(self, song):
        """
        Reproduce la cancion que recibio en los paramentros

        Parametes:
        song (str): este es un string con elpath de la cancion.

        Returns:
        int: devuelve 1 si es correcto, 2 si falla
        """
        print("Reproduciondo la la cacion dada")

    def stop(self):
        """ detiene la reproduccion en curso"""
