# Changelog

All notable changes to this project will be documented in this file.

## [1.4.4] - 2026-04-02

### Added
- Organisation: `employee-update` Command hinzugefügt (`--first-name`, `--last-name`, `--email`, `--phone`, `--mobile`, `--user`, `--funktion`, `--eintrittsdatum`, `--austrittsdatum`) (bb)
- Organisation: `--user` Option zu `employee-create` hinzugefügt (verknüpft Mitarbeitenden mit User-Account) (bb)

## [1.4.3] - 2026-04-01

### Added
- Standards: Chapter-CRUD-Commands hinzugefügt (`chapter-get`, `chapter-create`, `chapter-update`, `chapter-delete`) (bb)

## [1.4.2] - 2026-04-01

### Added
- Users: `--username` Option zu `users update` hinzugefügt (bb)

## [1.4.1] - 2026-03-30

### Documentation
- Issues: Farb-Konvention für Kategorien dokumentiert (Materialize CSS Klassennamen) (bb)

## [1.4.0] - 2026-03-30

### Added
- Issues: Kategorie-CRUD — `categories`, `category-get`, `category-create`, `category-update`, `category-delete` (bb)

## [1.3.0] - 2026-03-30

### Added
- Issues: Vollständiges Tracker-CRUD — `tracker-create`, `tracker-get`, `tracker-update`, `tracker-delete` (bb)

## [1.2.0] - 2026-03-30

### Added
- Issues: `followup-add` unterstützt jetzt `--file/-f` zum Anhängen von Dateien (bb)

## [1.1.0] - 2026-03-30

### Added
- Issues: Knowledge Base CRUD — `kb-list`, `kb-get`, `kb-create`, `kb-update`, `kb-delete`, `kb-link` (bb)

## [1.0.0] - 2026-03-27

### Added
- **24 CLI-Module:** issues, dms, forms, kpi, processes, spaces, standards, streams, time, users, contenttypes, glossar, organisation, contracts, projects, tutorials, okr, swot, dsg, bot, measuring, resources, businesscontext, ims
- **MCP-Server** mit ~70 Tools für AI-Agent-Integration (Claude Cowork, Claude Code, Cursor)
- **Spaces-Erweiterungen:** card-get, card-comments, card-comment-add mit Multipart-Upload
- **Issues:** Serial Number Lookup (`--serial` Flag)
- **Multi-Instanz-Support:** Konfiguration in `~/.myeliza/config.yaml`
- **Output-Formate:** Rich Table (default), JSON, CSV
- Organisation: Skill-Assignment Commands — skills, skill-categories, skill-entries, skill-entry-add, skill-entry-remove, qualifikationen, qualifikation-add
- Users: User-Management Commands — create, update, deactivate, activate, set-password, invite
- Users: groups --search Filter für Gruppensuche nach Name
- Users: user_type Option bei create und update (--user-type consultant)
- Time: Public Holiday Commands — holidays, holiday-create, holiday-delete
- DMS: `dms export` Command — Markdown-Beschreibungen als professionelle PDF oder DOCX exportieren mit Logo, Cover-Seite und Branding
- Spaces: card-set-parent und card-clear-parent Commands zum Verknüpfen von Cards mit Objekten

### Changed
- Package umbenannt von `eliza-cli` zu `myeliza-cli`
- Command umbenannt von `eliza` zu `myeliza`
- Config-Pfad: `~/.myeliza/` mit Fallback auf `~/.eliza/`
- PyPI-ready: Classifiers, URLs, Keywords, LICENSE
