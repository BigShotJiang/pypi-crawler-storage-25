"""Organisation commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Organisation (Mitarbeitende, Orgeinheiten, Funktionen, Skills)")
console = Console()

EMPLOYEE_COLUMNS = ["id", "vorname", "nachname", "email_business", "funktion"]
EMPLOYEE_DETAIL = ["id", "vorname", "nachname", "email_business", "funktion", "phone_business", "phone_mobile", "eintrittsdatum"]
ORGUNIT_COLUMNS = ["id", "titel", "description_clean", "parent_name"]
FUNCTION_COLUMNS = ["id", "titel", "description_clean"]
MEMBERSHIP_COLUMNS = ["id", "employee_name", "orgunit_name", "function_name"]
SKILL_ENTRY_COLUMNS = ["id", "mitarbeiter_name", "skill_titel", "qualifikation_titel", "datum", "expiration_date", "is_expired"]
QUALIFIKATION_COLUMNS = ["id", "titel", "code"]
SKILL_COLUMNS = ["id", "titel"]
SKILL_CATEGORY_COLUMNS = ["id", "titel"]


import re

def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _enrich_employee(emp: dict) -> dict:
    orgunit = emp.get("orgunit") or {}
    emp["orgunit_name"] = orgunit.get("title", "") if isinstance(orgunit, dict) else str(orgunit)
    func = emp.get("function") or {}
    emp["function_name"] = func.get("title", "") if isinstance(func, dict) else str(func)
    return emp


def _enrich_orgunit(ou: dict) -> dict:
    ou["description_clean"] = _clean_html(ou.get("description", ""))
    parent = ou.get("parent") or {}
    ou["parent_name"] = parent.get("title", "") if isinstance(parent, dict) else str(parent or "")
    return ou


def _enrich_membership(m: dict) -> dict:
    emp = m.get("employee") or {}
    if isinstance(emp, dict):
        m["employee_name"] = f"{emp.get('first_name', '')} {emp.get('last_name', '')}".strip()
    else:
        m["employee_name"] = str(emp)
    orgunit = m.get("orgunit") or {}
    m["orgunit_name"] = orgunit.get("title", "") if isinstance(orgunit, dict) else str(orgunit)
    func = m.get("function") or {}
    m["function_name"] = func.get("title", "") if isinstance(func, dict) else str(func)
    return m


# ── Employees ─────────────────────────────────────────────

@app.command("employees")
def list_employees(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List employees."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    employees = client.get_paginated("organisation/mitarbeitende", params=params, limit=limit)
    employees = [_enrich_employee(e) for e in employees]
    format_output(employees, fmt=fmt, columns=EMPLOYEE_COLUMNS, title=f"Employees ({len(employees)})")


@app.command("employee-get")
def get_employee(
    employee_id: int = typer.Argument(help="Employee ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get employee details."""
    client = ElizaClient(instance=instance)
    emp = client.get(f"organisation/mitarbeitende/{employee_id}")
    emp = _enrich_employee(emp)
    format_output(emp, fmt=fmt, columns=EMPLOYEE_DETAIL)


@app.command("employee-create")
def create_employee(
    first_name: str = typer.Option(..., "--first-name"),
    last_name: str = typer.Option(..., "--last-name"),
    email: Optional[str] = typer.Option(None, "--email"),
    phone: Optional[str] = typer.Option(None, "--phone"),
    mobile: Optional[str] = typer.Option(None, "--mobile"),
    user: Optional[int] = typer.Option(None, "--user", help="Link to user account (user ID)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create an employee."""
    client = ElizaClient(instance=instance)
    data = {"vorname": first_name, "nachname": last_name}
    if email:
        data["email_business"] = email
    if phone:
        data["phone_business"] = phone
    if mobile:
        data["phone_mobile"] = mobile
    if user is not None:
        data["user"] = user
    result = client.post("organisation/mitarbeitende", data=data)
    console.print(f"[green]✓[/green] Employee created: ID={result.get('id')} — {first_name} {last_name}")


@app.command("employee-update")
def update_employee(
    employee_id: int = typer.Argument(help="Employee ID"),
    first_name: Optional[str] = typer.Option(None, "--first-name"),
    last_name: Optional[str] = typer.Option(None, "--last-name"),
    email: Optional[str] = typer.Option(None, "--email"),
    phone: Optional[str] = typer.Option(None, "--phone"),
    mobile: Optional[str] = typer.Option(None, "--mobile"),
    user: Optional[int] = typer.Option(None, "--user", help="Link to user account (user ID)"),
    funktion: Optional[str] = typer.Option(None, "--funktion", help="Job function/title"),
    eintrittsdatum: Optional[str] = typer.Option(None, "--eintrittsdatum", help="Entry date (YYYY-MM-DD)"),
    austrittsdatum: Optional[str] = typer.Option(None, "--austrittsdatum", help="Exit date (YYYY-MM-DD)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update an employee."""
    client = ElizaClient(instance=instance)
    data: dict = {}
    if first_name is not None:
        data["vorname"] = first_name
    if last_name is not None:
        data["nachname"] = last_name
    if email is not None:
        data["email_business"] = email
    if phone is not None:
        data["phone_business"] = phone
    if mobile is not None:
        data["phone_mobile"] = mobile
    if user is not None:
        data["user"] = user
    if funktion is not None:
        data["funktion"] = funktion
    if eintrittsdatum is not None:
        data["eintrittsdatum"] = eintrittsdatum
    if austrittsdatum is not None:
        data["austrittsdatum"] = austrittsdatum
    if not data:
        console.print("[yellow]No fields to update. Use --help to see available options.[/yellow]")
        raise typer.Exit(1)
    result = client.patch(f"organisation/mitarbeitende/{employee_id}", data=data)
    name = f"{result.get('vorname', '')} {result.get('nachname', '')}".strip()
    console.print(f"[green]✓[/green] Employee {employee_id} updated — {name}")


# ── Org Units ─────────────────────────────────────────────

@app.command("orgunits")
def list_orgunits(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List organisational units."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    units = client.get_paginated("organisation/orgunit", params=params, limit=limit)
    units = [_enrich_orgunit(u) for u in units]
    format_output(units, fmt=fmt, columns=ORGUNIT_COLUMNS, title=f"Org Units ({len(units)})")


@app.command("orgunit-get")
def get_orgunit(
    orgunit_id: int = typer.Argument(help="Org unit ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get org unit details."""
    client = ElizaClient(instance=instance)
    unit = client.get(f"organisation/orgunit/{orgunit_id}")
    unit = _enrich_orgunit(unit)
    format_output(unit, fmt=fmt, columns=["id", "title", "description_clean", "parent_name"])


@app.command("orgunit-create")
def create_orgunit(
    title: str = typer.Option(..., "--title"),
    description: str = typer.Option("", "--description", "-d"),
    parent: Optional[int] = typer.Option(None, "--parent", help="Parent org unit ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create an org unit."""
    client = ElizaClient(instance=instance)
    data = {"titel": title}
    if description:
        data["description"] = description
    if parent:
        data["parent"] = parent
    result = client.post("organisation/orgunit", data=data)
    console.print(f"[green]✓[/green] Org unit created: ID={result.get('id')} — {title}")


# ── Functions ─────────────────────────────────────────────

@app.command("functions")
def list_functions(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List functions."""
    client = ElizaClient(instance=instance)
    funcs = client.get_paginated("organisation/funktionen", limit=limit)
    for f in funcs:
        f["description_clean"] = _clean_html(f.get("description", ""))
    format_output(funcs, fmt=fmt, columns=FUNCTION_COLUMNS, title=f"Functions ({len(funcs)})")


@app.command("function-get")
def get_function(
    function_id: int = typer.Argument(help="Function ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get function details."""
    client = ElizaClient(instance=instance)
    func = client.get(f"organisation/funktionen/{function_id}")
    func["description_clean"] = _clean_html(func.get("description", ""))
    format_output(func, fmt=fmt, columns=FUNCTION_COLUMNS)


# ── Memberships ───────────────────────────────────────────

@app.command("memberships")
def list_memberships(
    employee: Optional[int] = typer.Option(None, "--employee", help="Employee ID"),
    orgunit: Optional[int] = typer.Option(None, "--orgunit", help="Org unit ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List memberships."""
    client = ElizaClient(instance=instance)
    params = {}
    if employee:
        params["employee"] = employee
    if orgunit:
        params["orgunit"] = orgunit
    memberships = client.get_paginated("organisation/membership", params=params, limit=limit)
    memberships = [_enrich_membership(m) for m in memberships]
    format_output(memberships, fmt=fmt, columns=MEMBERSHIP_COLUMNS, title=f"Memberships ({len(memberships)})")


# ── Skills ────────────────────────────────────────────────

@app.command("skills")
def list_skills(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List skills."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    skills = client.get_paginated("organisation/skill", params=params, limit=limit)
    format_output(skills, fmt=fmt, columns=SKILL_COLUMNS, title=f"Skills ({len(skills)})")


@app.command("skill-categories")
def list_skill_categories(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List skill categories."""
    client = ElizaClient(instance=instance)
    categories = client.get_paginated("organisation/skill-kategorie", limit=limit)
    format_output(categories, fmt=fmt, columns=SKILL_CATEGORY_COLUMNS, title=f"Skill Categories ({len(categories)})")


# ── Skill Entries (Assignments) ──────────────────────────

@app.command("skill-entries")
def list_skill_entries(
    employee: Optional[int] = typer.Option(None, "--employee", help="Employee ID"),
    skill: Optional[int] = typer.Option(None, "--skill", help="Skill ID"),
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List skill assignments."""
    client = ElizaClient(instance=instance)
    params = {}
    if employee:
        params["mitarbeiter"] = employee
    if skill:
        params["skill"] = skill
    if search:
        params["search"] = search
    entries = client.get_paginated("organisation/skill-entry", params=params, limit=limit)
    format_output(entries, fmt=fmt, columns=SKILL_ENTRY_COLUMNS, title=f"Skill Entries ({len(entries)})")


@app.command("skill-entry-add")
def add_skill_entry(
    employee: int = typer.Option(..., "--employee", help="Employee ID"),
    skill: int = typer.Option(..., "--skill", help="Skill ID"),
    qualifikation: Optional[int] = typer.Option(None, "--qualifikation", help="Qualification level ID"),
    datum: Optional[str] = typer.Option(None, "--datum", help="Date (YYYY-MM-DD)"),
    expiration: Optional[str] = typer.Option(None, "--expiration", help="Expiration date (YYYY-MM-DD)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Assign a skill to an employee."""
    client = ElizaClient(instance=instance)
    data = {"mitarbeiter": employee, "skill": skill}
    if qualifikation:
        data["qualifikation"] = qualifikation
    if datum:
        data["datum"] = datum
    if expiration:
        data["expiration_date"] = expiration
    result = client.post("organisation/skill-entry", data=data)
    console.print(f"[green]✓[/green] Skill entry created: ID={result.get('id')}")


@app.command("skill-entry-remove")
def remove_skill_entry(
    entry_id: int = typer.Argument(help="Skill entry ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Remove a skill assignment."""
    client = ElizaClient(instance=instance)
    client.delete(f"organisation/skill-entry/{entry_id}")
    console.print(f"[green]✓[/green] Skill entry {entry_id} removed.")


# ── Qualifikationen ──────────────────────────────────────

@app.command("qualifikationen")
def list_qualifikationen(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List qualification levels."""
    client = ElizaClient(instance=instance)
    quals = client.get_paginated("organisation/qualifikation", limit=limit)
    format_output(quals, fmt=fmt, columns=QUALIFIKATION_COLUMNS, title=f"Qualifikationen ({len(quals)})")


@app.command("qualifikation-add")
def add_qualifikation(
    title: str = typer.Option(..., "--title", help="Qualification title"),
    code: str = typer.Option("", "--code", help="Short code"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Add a qualification level."""
    client = ElizaClient(instance=instance)
    data = {"titel": title}
    if code:
        data["code"] = code
    result = client.post("organisation/qualifikation", data=data)
    console.print(f"[green]✓[/green] Qualifikation created: ID={result.get('id')} — {title}")
