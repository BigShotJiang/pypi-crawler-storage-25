"""Business Context commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Geschäftskontext / Business Context")
console = Console()

PARTY_COLUMNS = ["id", "title", "interest", "influence"]
PARTY_DETAIL = ["id", "title", "interest", "influence"]
ISSUETYPE_COLUMNS = ["id", "title", "description_clean"]
ISSUE_COLUMNS = ["id", "title", "type_name", "description_clean"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


# ── Interested Parties ────────────────────────────────────

@app.command("parties")
def list_parties(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List interested parties."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    parties = client.get_paginated("businesscontext/interestedparty", params=params, limit=limit)
    format_output(parties, fmt=fmt, columns=PARTY_COLUMNS, title=f"Interested Parties ({len(parties)})")


@app.command("party-get")
def get_party(
    party_id: int = typer.Argument(help="Party ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get interested party details."""
    client = ElizaClient(instance=instance)
    party = client.get(f"businesscontext/interestedparty/{party_id}")
    format_output(party, fmt=fmt, columns=PARTY_DETAIL)


@app.command("party-create")
def create_party(
    title: str = typer.Option(..., "--title"),
    interest: int = typer.Option(0, "--interest", help="Interest level (0-3)"),
    influence: int = typer.Option(0, "--influence", help="Influence level (0-3)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create an interested party."""
    client = ElizaClient(instance=instance)
    data = {"title": title, "interest": interest, "influence": influence}
    result = client.post("businesscontext/interestedparty", data=data)
    console.print(f"[green]✓[/green] Party created: ID={result.get('id')} — {title}")


# ── Issue Types ───────────────────────────────────────────

@app.command("issuetypes")
def list_issuetypes(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List issue types."""
    client = ElizaClient(instance=instance)
    types = client.get_paginated("businesscontext/issuetype", limit=limit)
    for t in types:
        t["description_clean"] = _clean_html(t.get("description", ""))
    format_output(types, fmt=fmt, columns=ISSUETYPE_COLUMNS, title=f"Issue Types ({len(types)})")


# ── Issues ────────────────────────────────────────────────

@app.command("issues")
def list_issues(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List business context issues."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    issues = client.get_paginated("businesscontext/issue", params=params, limit=limit)
    for iss in issues:
        iss["description_clean"] = _clean_html(iss.get("description", ""))
        t = iss.get("type") or {}
        iss["type_name"] = t.get("title", "") if isinstance(t, dict) else str(t or "")
    format_output(issues, fmt=fmt, columns=ISSUE_COLUMNS, title=f"Issues ({len(issues)})")


@app.command("issue-get")
def get_issue(
    issue_id: int = typer.Argument(help="Issue ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get issue details."""
    client = ElizaClient(instance=instance)
    issue = client.get(f"businesscontext/issue/{issue_id}")
    issue["description_clean"] = _clean_html(issue.get("description", ""))
    t = issue.get("type") or {}
    issue["type_name"] = t.get("title", "") if isinstance(t, dict) else str(t or "")
    format_output(issue, fmt=fmt, columns=ISSUE_COLUMNS)
