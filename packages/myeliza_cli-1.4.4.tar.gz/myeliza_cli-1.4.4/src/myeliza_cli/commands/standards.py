"""Standards / Normen commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Standards / Normen")
console = Console()

STANDARD_COLUMNS = ["id", "title", "short_title", "category_name"]
STANDARD_DETAIL = ["id", "title", "short_title", "description", "category_name"]
CATEGORY_COLUMNS = ["id", "title", "description"]
CHAPTER_COLUMNS = ["id", "title", "standard"]


def _enrich_standard(std: dict) -> dict:
    cat = std.get("category", {}) or {}
    if isinstance(cat, dict):
        std["category_name"] = cat.get("title", str(cat.get("id", "")))
    else:
        std["category_name"] = str(cat)
    return std


@app.command("list")
def list_standards(
    category: Optional[int] = typer.Option(None, "--category", "-c", help="Category ID"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List standards."""
    client = ElizaClient(instance=instance)
    params = {}
    if category:
        params["category"] = category
    standards = client.get_paginated("standards/standard", params=params, limit=limit)
    standards = [_enrich_standard(s) for s in standards]
    format_output(standards, fmt=fmt, columns=STANDARD_COLUMNS, title=f"Standards ({len(standards)})")


@app.command("get")
def get_standard(
    standard_id: int = typer.Argument(help="Standard ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get standard details."""
    client = ElizaClient(instance=instance)
    standard = client.get(f"standards/standard/{standard_id}")
    standard = _enrich_standard(standard)
    format_output(standard, fmt=fmt, columns=STANDARD_DETAIL)


@app.command("create")
def create_standard(
    title: str = typer.Option(..., "--title", "-t", help="Standard title"),
    short_title: Optional[str] = typer.Option(None, "--short-title", help="Short title"),
    category: Optional[int] = typer.Option(None, "--category", "-c", help="Category ID"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a new standard."""
    client = ElizaClient(instance=instance)
    data: dict = {"title": title}
    if short_title is not None:
        data["short_title"] = short_title
    if category is not None:
        data["category"] = category
    if description is not None:
        data["description"] = description
    result = client.post("standards/standard", data=data)
    console.print(f"[green]✓[/green] Standard created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("delete")
def delete_standard(
    standard_id: int = typer.Argument(help="Standard ID"),
    force: bool = typer.Option(False, "--force", help="Skip confirmation"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a standard."""
    if not force:
        confirm = typer.confirm(f"Delete standard {standard_id}?")
        if not confirm:
            raise typer.Abort()
    client = ElizaClient(instance=instance)
    client.delete(f"standards/standard/{standard_id}")
    console.print(f"[green]✓[/green] Standard {standard_id} deleted")


@app.command("categories")
def list_categories(
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List standard categories."""
    client = ElizaClient(instance=instance)
    categories = client.get_paginated("standards/category")
    format_output(categories, fmt=fmt, columns=CATEGORY_COLUMNS, title="Categories")


@app.command("chapters")
def list_chapters(
    standard_id: int = typer.Argument(help="Standard ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List chapters for a standard."""
    client = ElizaClient(instance=instance)
    chapters = client.get_paginated("standards/chapter", params={"standard": standard_id})
    format_output(chapters, fmt=fmt, columns=CHAPTER_COLUMNS, title="Chapters")


@app.command("chapter-get")
def get_chapter(
    chapter_id: int = typer.Argument(help="Chapter ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get chapter details."""
    client = ElizaClient(instance=instance)
    chapter = client.get(f"standards/chapter/{chapter_id}")
    format_output(chapter, fmt=fmt)


@app.command("chapter-create")
def create_chapter(
    standard_id: int = typer.Option(..., "--standard", "-s", help="Standard ID"),
    title: str = typer.Option(..., "--title", "-t", help="Chapter title"),
    number: Optional[str] = typer.Option(None, "--number", "-n", help="Chapter number (e.g. N1, 1.1)"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    parent: Optional[int] = typer.Option(None, "--parent", "-p", help="Parent chapter ID"),
    required: bool = typer.Option(False, "--required", help="Mark as required (Basisindikator)"),
    order: Optional[int] = typer.Option(None, "--order", help="Sort order"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a chapter (or sub-chapter) for a standard."""
    client = ElizaClient(instance=instance)
    data: dict = {"standard": standard_id, "title": title, "required": required}
    if number is not None:
        data["number"] = number
    if description is not None:
        data["description"] = description
    if parent is not None:
        data["parent_chapter"] = parent
    if order is not None:
        data["order"] = order
    result = client.post("standards/chapter", data=data)
    console.print(f"[green]✓[/green] Chapter created: ID={result.get('id', '')} — {title}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("chapter-update")
def update_chapter(
    chapter_id: int = typer.Argument(help="Chapter ID"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Chapter title"),
    number: Optional[str] = typer.Option(None, "--number", "-n", help="Chapter number"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    parent: Optional[int] = typer.Option(None, "--parent", "-p", help="Parent chapter ID"),
    required: Optional[bool] = typer.Option(None, "--required/--not-required", help="Required flag"),
    order: Optional[int] = typer.Option(None, "--order", help="Sort order"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Update a chapter."""
    client = ElizaClient(instance=instance)
    data: dict = {}
    if title is not None:
        data["title"] = title
    if number is not None:
        data["number"] = number
    if description is not None:
        data["description"] = description
    if parent is not None:
        data["parent_chapter"] = parent
    if required is not None:
        data["required"] = required
    if order is not None:
        data["order"] = order
    if not data:
        console.print("[yellow]No fields to update.[/yellow]")
        raise typer.Exit(1)
    result = client.patch(f"standards/chapter/{chapter_id}", data=data)
    console.print(f"[green]✓[/green] Chapter {chapter_id} updated.")
    format_output(result, fmt=fmt, columns=CHAPTER_COLUMNS)


@app.command("chapter-delete")
def delete_chapter(
    chapter_id: int = typer.Argument(help="Chapter ID"),
    force: bool = typer.Option(False, "--force", help="Skip confirmation"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a chapter."""
    if not force:
        confirm = typer.confirm(f"Delete chapter {chapter_id}?")
        if not confirm:
            raise typer.Abort()
    client = ElizaClient(instance=instance)
    client.delete(f"standards/chapter/{chapter_id}")
    console.print(f"[green]✓[/green] Chapter {chapter_id} deleted.")
