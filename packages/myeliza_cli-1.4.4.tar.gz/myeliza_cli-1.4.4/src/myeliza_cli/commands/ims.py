"""IMS (Integriertes Management System) commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Integriertes Management System (IMS)")
console = Console()

SYSTEM_COLUMNS = ["id", "title", "description_clean"]
CATEGORY_COLUMNS = ["id", "title", "description_clean"]
ASSET_COLUMNS = ["id", "title", "category_name", "description_clean"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


# ── Systems ───────────────────────────────────────────────

@app.command("systems")
def list_systems(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List IMS systems."""
    client = ElizaClient(instance=instance)
    systems = client.get_paginated("ims/system", limit=limit)
    for s in systems:
        s["description_clean"] = _clean_html(s.get("description", ""))
    format_output(systems, fmt=fmt, columns=SYSTEM_COLUMNS, title=f"IMS Systems ({len(systems)})")


@app.command("system-get")
def get_system(
    system_id: int = typer.Argument(help="System ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get IMS system details."""
    client = ElizaClient(instance=instance)
    system = client.get(f"ims/system/{system_id}")
    system["description_clean"] = _clean_html(system.get("description", ""))
    format_output(system, fmt=fmt, columns=SYSTEM_COLUMNS)


@app.command("system-create")
def create_system(
    title: str = typer.Option(..., "--title"),
    description: str = typer.Option("", "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create an IMS system."""
    client = ElizaClient(instance=instance)
    data = {"title": title}
    if description:
        data["description"] = description
    result = client.post("ims/system", data=data)
    console.print(f"[green]✓[/green] IMS system created: ID={result.get('id')} — {title}")


# ── Asset Categories ──────────────────────────────────────

@app.command("categories")
def list_categories(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List asset categories."""
    client = ElizaClient(instance=instance)
    cats = client.get_paginated("ims/assetcategory", limit=limit)
    for c in cats:
        c["description_clean"] = _clean_html(c.get("description", ""))
    format_output(cats, fmt=fmt, columns=CATEGORY_COLUMNS, title=f"Asset Categories ({len(cats)})")


# ── Assets ────────────────────────────────────────────────

@app.command("assets")
def list_assets(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    category: Optional[int] = typer.Option(None, "--category", help="Category ID"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List assets."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    if category:
        params["category"] = category
    assets = client.get_paginated("ims/asset", params=params, limit=limit)
    for a in assets:
        a["description_clean"] = _clean_html(a.get("description", ""))
        cat = a.get("category") or {}
        a["category_name"] = cat.get("title", "") if isinstance(cat, dict) else str(cat or "")
    format_output(assets, fmt=fmt, columns=ASSET_COLUMNS, title=f"Assets ({len(assets)})")


@app.command("asset-get")
def get_asset(
    asset_id: int = typer.Argument(help="Asset ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get asset details."""
    client = ElizaClient(instance=instance)
    asset = client.get(f"ims/asset/{asset_id}")
    asset["description_clean"] = _clean_html(asset.get("description", ""))
    cat = asset.get("category") or {}
    asset["category_name"] = cat.get("title", "") if isinstance(cat, dict) else str(cat or "")
    format_output(asset, fmt=fmt, columns=ASSET_COLUMNS)
