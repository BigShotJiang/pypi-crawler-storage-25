"""Contracts commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Vertragsverwaltung")
console = Console()

COLUMNS = ["id", "title", "partner_name", "type_name", "status", "start_date", "end_date"]
DETAIL_COLUMNS = ["id", "title", "partner_name", "type_name", "status", "start_date", "end_date", "value", "description_clean"]
PARTNER_COLUMNS = ["id", "title", "description_clean"]
FOLDER_COLUMNS = ["id", "title"]
TYPE_COLUMNS = ["id", "title"]
CASHFLOW_COLUMNS = ["id", "title", "amount", "date", "contract_name"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _enrich(contract: dict) -> dict:
    contract["description_clean"] = _clean_html(contract.get("description", ""))
    partner = contract.get("partner") or {}
    contract["partner_name"] = partner.get("title", "") if isinstance(partner, dict) else str(partner or "")
    ctype = contract.get("type") or {}
    contract["type_name"] = ctype.get("title", "") if isinstance(ctype, dict) else str(ctype or "")
    contract["start_date"] = (contract.get("start_date") or "")[:10]
    contract["end_date"] = (contract.get("end_date") or "")[:10]
    return contract


# ── Contracts ─────────────────────────────────────────────

@app.command("list")
def list_contracts(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    status: Optional[str] = typer.Option(None, "--status", "-s"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List contracts."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    if status:
        params["status"] = status
    contracts = client.get_paginated("contracts/contract", params=params, limit=limit)
    contracts = [_enrich(c) for c in contracts]
    format_output(contracts, fmt=fmt, columns=COLUMNS, title=f"Contracts ({len(contracts)})")


@app.command("get")
def get_contract(
    contract_id: int = typer.Argument(help="Contract ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get contract details."""
    client = ElizaClient(instance=instance)
    contract = client.get(f"contracts/contract/{contract_id}")
    contract = _enrich(contract)
    format_output(contract, fmt=fmt, columns=DETAIL_COLUMNS)


@app.command("create")
def create_contract(
    title: str = typer.Option(..., "--title"),
    partner: Optional[int] = typer.Option(None, "--partner", help="Partner ID"),
    type_id: Optional[int] = typer.Option(None, "--type", "-t", help="Contract type ID"),
    status: Optional[str] = typer.Option(None, "--status", "-s"),
    start_date: Optional[str] = typer.Option(None, "--start-date"),
    end_date: Optional[str] = typer.Option(None, "--end-date"),
    value: Optional[float] = typer.Option(None, "--value"),
    description: str = typer.Option("", "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a contract."""
    client = ElizaClient(instance=instance)
    data = {"title": title}
    if partner:
        data["partner"] = partner
    if type_id:
        data["type"] = type_id
    if status:
        data["status"] = status
    if start_date:
        data["start_date"] = start_date
    if end_date:
        data["end_date"] = end_date
    if value is not None:
        data["value"] = value
    if description:
        data["description"] = description
    result = client.post("contracts/contract", data=data)
    console.print(f"[green]✓[/green] Contract created: ID={result.get('id')} — {title}")


@app.command("update")
def update_contract(
    contract_id: int = typer.Argument(help="Contract ID"),
    title: Optional[str] = typer.Option(None, "--title"),
    status: Optional[str] = typer.Option(None, "--status", "-s"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a contract."""
    client = ElizaClient(instance=instance)
    data = {}
    if title:
        data["title"] = title
    if status:
        data["status"] = status
    if description is not None:
        data["description"] = description
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"contracts/contract/{contract_id}", data=data)
    console.print(f"[green]✓[/green] Contract {contract_id} updated")


@app.command("delete")
def delete_contract(
    contract_id: int = typer.Argument(help="Contract ID"),
    confirm: bool = typer.Option(False, "--yes", "-y"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a contract."""
    if not confirm:
        typer.confirm(f"Delete contract {contract_id}?", abort=True)
    client = ElizaClient(instance=instance)
    client.delete(f"contracts/contract/{contract_id}")
    console.print(f"[green]✓[/green] Contract {contract_id} deleted")


# ── Partners ──────────────────────────────────────────────

@app.command("partners")
def list_partners(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List contract partners."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    partners = client.get_paginated("contracts/partner", params=params, limit=limit)
    for p in partners:
        p["description_clean"] = _clean_html(p.get("description", ""))
    format_output(partners, fmt=fmt, columns=PARTNER_COLUMNS, title=f"Partners ({len(partners)})")


@app.command("partner-get")
def get_partner(
    partner_id: int = typer.Argument(help="Partner ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get partner details."""
    client = ElizaClient(instance=instance)
    partner = client.get(f"contracts/partner/{partner_id}")
    partner["description_clean"] = _clean_html(partner.get("description", ""))
    format_output(partner, fmt=fmt, columns=PARTNER_COLUMNS)


# ── Folders ───────────────────────────────────────────────

@app.command("folders")
def list_folders(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List contract folders."""
    client = ElizaClient(instance=instance)
    folders = client.get_paginated("contracts/folder", limit=limit)
    format_output(folders, fmt=fmt, columns=FOLDER_COLUMNS, title=f"Folders ({len(folders)})")


# ── Types ─────────────────────────────────────────────────

@app.command("types")
def list_types(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List contract types."""
    client = ElizaClient(instance=instance)
    types = client.get_paginated("contracts/type", limit=limit)
    format_output(types, fmt=fmt, columns=TYPE_COLUMNS, title=f"Types ({len(types)})")


# ── Cashflows ─────────────────────────────────────────────

@app.command("cashflows")
def list_cashflows(
    contract: Optional[int] = typer.Option(None, "--contract", help="Contract ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List cashflows."""
    client = ElizaClient(instance=instance)
    params = {}
    if contract:
        params["contract"] = contract
    cashflows = client.get_paginated("contracts/cashflow", params=params, limit=limit)
    for cf in cashflows:
        c = cf.get("contract") or {}
        cf["contract_name"] = c.get("title", "") if isinstance(c, dict) else str(c or "")
    format_output(cashflows, fmt=fmt, columns=CASHFLOW_COLUMNS, title=f"Cashflows ({len(cashflows)})")
