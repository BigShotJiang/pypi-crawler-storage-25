"""Projects commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Projektverwaltung")
console = Console()

COLUMNS = ["id", "title", "state", "manager_name", "description_clean"]
DETAIL_COLUMNS = ["id", "title", "description_clean", "state", "manager_name", "created_date"]
TASK_COLUMNS = ["id", "title", "status", "project_name", "assignee_name"]
MILESTONE_COLUMNS = ["id", "title", "date", "project_name"]
PHASE_COLUMNS = ["id", "title", "start_date", "end_date", "project_name"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _enrich(project: dict) -> dict:
    project["description_clean"] = _clean_html(project.get("description", ""))
    manager = project.get("manager") or {}
    if isinstance(manager, dict):
        project["manager_name"] = f"{manager.get('first_name', '')} {manager.get('last_name', '')}".strip()
    else:
        project["manager_name"] = str(manager or "")
    project["created_date"] = (project.get("created_date") or "")[:10]
    return project


def _enrich_task(task: dict) -> dict:
    proj = task.get("project") or {}
    task["project_name"] = proj.get("title", "") if isinstance(proj, dict) else str(proj or "")
    assignee = task.get("assignee") or {}
    if isinstance(assignee, dict):
        task["assignee_name"] = f"{assignee.get('first_name', '')} {assignee.get('last_name', '')}".strip()
    else:
        task["assignee_name"] = str(assignee or "")
    return task


# ── Projects ──────────────────────────────────────────────

@app.command("list")
def list_projects(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    state: Optional[str] = typer.Option(None, "--state", "-s", help="planned/active/finished"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List projects."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    if state:
        params["state"] = state
    projects = client.get_paginated("projects/project", params=params, limit=limit)
    projects = [_enrich(p) for p in projects]
    format_output(projects, fmt=fmt, columns=COLUMNS, title=f"Projects ({len(projects)})")


@app.command("get")
def get_project(
    project_id: int = typer.Argument(help="Project ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get project details."""
    client = ElizaClient(instance=instance)
    project = client.get(f"projects/project/{project_id}")
    project = _enrich(project)
    format_output(project, fmt=fmt, columns=DETAIL_COLUMNS)


@app.command("create")
def create_project(
    title: str = typer.Option(..., "--title"),
    description: str = typer.Option("", "--description", "-d"),
    state: str = typer.Option("planned", "--state", "-s", help="planned/active/finished"),
    manager: Optional[int] = typer.Option(None, "--manager", help="Manager ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a project."""
    client = ElizaClient(instance=instance)
    data = {"title": title, "state": state}
    if description:
        data["description"] = description
    if manager:
        data["manager"] = manager
    result = client.post("projects/project", data=data)
    console.print(f"[green]✓[/green] Project created: ID={result.get('id')} — {title}")


@app.command("update")
def update_project(
    project_id: int = typer.Argument(help="Project ID"),
    title: Optional[str] = typer.Option(None, "--title"),
    state: Optional[str] = typer.Option(None, "--state", "-s"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a project."""
    client = ElizaClient(instance=instance)
    data = {}
    if title:
        data["title"] = title
    if state:
        data["state"] = state
    if description is not None:
        data["description"] = description
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"projects/project/{project_id}", data=data)
    console.print(f"[green]✓[/green] Project {project_id} updated")


@app.command("delete")
def delete_project(
    project_id: int = typer.Argument(help="Project ID"),
    confirm: bool = typer.Option(False, "--yes", "-y"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a project."""
    if not confirm:
        typer.confirm(f"Delete project {project_id}?", abort=True)
    client = ElizaClient(instance=instance)
    client.delete(f"projects/project/{project_id}")
    console.print(f"[green]✓[/green] Project {project_id} deleted")


# ── Tasks ─────────────────────────────────────────────────

@app.command("tasks")
def list_tasks(
    project: Optional[int] = typer.Option(None, "--project", help="Project ID"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List project tasks."""
    client = ElizaClient(instance=instance)
    params = {}
    if project:
        params["project"] = project
    tasks = client.get_paginated("projects/task", params=params, limit=limit)
    tasks = [_enrich_task(t) for t in tasks]
    format_output(tasks, fmt=fmt, columns=TASK_COLUMNS, title=f"Tasks ({len(tasks)})")


@app.command("task-get")
def get_task(
    task_id: int = typer.Argument(help="Task ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get task details."""
    client = ElizaClient(instance=instance)
    task = client.get(f"projects/task/{task_id}")
    task = _enrich_task(task)
    format_output(task, fmt=fmt, columns=TASK_COLUMNS)


# ── Milestones ────────────────────────────────────────────

@app.command("milestones")
def list_milestones(
    project: Optional[int] = typer.Option(None, "--project", help="Project ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List milestones."""
    client = ElizaClient(instance=instance)
    params = {}
    if project:
        params["project"] = project
    milestones = client.get_paginated("projects/milestone", params=params, limit=limit)
    for m in milestones:
        p = m.get("project") or {}
        m["project_name"] = p.get("title", "") if isinstance(p, dict) else str(p or "")
        m["date"] = (m.get("date") or "")[:10]
    format_output(milestones, fmt=fmt, columns=MILESTONE_COLUMNS, title=f"Milestones ({len(milestones)})")


# ── Phases ────────────────────────────────────────────────

@app.command("phases")
def list_phases(
    project: Optional[int] = typer.Option(None, "--project", help="Project ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List phases."""
    client = ElizaClient(instance=instance)
    params = {}
    if project:
        params["project"] = project
    phases = client.get_paginated("projects/phase", params=params, limit=limit)
    for ph in phases:
        p = ph.get("project") or {}
        ph["project_name"] = p.get("title", "") if isinstance(p, dict) else str(p or "")
        ph["start_date"] = (ph.get("start_date") or "")[:10]
        ph["end_date"] = (ph.get("end_date") or "")[:10]
    format_output(phases, fmt=fmt, columns=PHASE_COLUMNS, title=f"Phases ({len(phases)})")
