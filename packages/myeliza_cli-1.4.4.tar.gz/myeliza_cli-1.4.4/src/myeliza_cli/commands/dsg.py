"""DSG (Datenschutz) commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Datenschutz (DSG)")
console = Console()

ACTIVITY_COLUMNS = ["id", "title", "purpose_clean", "legal_basis"]
ACTIVITY_DETAIL = ["id", "title", "description_clean", "purpose_clean", "legal_basis"]
DATACATEGORY_COLUMNS = ["id", "title", "description_clean"]
TOM_COLUMNS = ["id", "title", "description_clean"]
SUBCONTRACTOR_COLUMNS = ["id", "title", "description_clean"]
APPLICATION_COLUMNS = ["id", "title", "description_clean"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _enrich_activity(a: dict) -> dict:
    a["description_clean"] = _clean_html(a.get("description", ""))
    a["purpose_clean"] = _clean_html(a.get("purpose", ""))
    return a


# ── Activities ────────────────────────────────────────────

@app.command("activities")
def list_activities(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List data processing activities."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    activities = client.get_paginated("dsg/activity", params=params, limit=limit)
    activities = [_enrich_activity(a) for a in activities]
    format_output(activities, fmt=fmt, columns=ACTIVITY_COLUMNS, title=f"Activities ({len(activities)})")


@app.command("activity-get")
def get_activity(
    activity_id: int = typer.Argument(help="Activity ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get activity details."""
    client = ElizaClient(instance=instance)
    activity = client.get(f"dsg/activity/{activity_id}")
    activity = _enrich_activity(activity)
    format_output(activity, fmt=fmt, columns=ACTIVITY_DETAIL)


@app.command("activity-create")
def create_activity(
    title: str = typer.Option(..., "--title"),
    description: str = typer.Option("", "--description", "-d"),
    purpose: str = typer.Option("", "--purpose"),
    legal_basis: Optional[str] = typer.Option(None, "--legal-basis"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a data processing activity."""
    client = ElizaClient(instance=instance)
    data = {"title": title}
    if description:
        data["description"] = description
    if purpose:
        data["purpose"] = purpose
    if legal_basis:
        data["legal_basis"] = legal_basis
    result = client.post("dsg/activity", data=data)
    console.print(f"[green]✓[/green] Activity created: ID={result.get('id')} — {title}")


# ── Data Categories ───────────────────────────────────────

@app.command("datacategories")
def list_datacategories(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List data categories."""
    client = ElizaClient(instance=instance)
    cats = client.get_paginated("dsg/datacategory", limit=limit)
    for c in cats:
        c["description_clean"] = _clean_html(c.get("description", ""))
    format_output(cats, fmt=fmt, columns=DATACATEGORY_COLUMNS, title=f"Data Categories ({len(cats)})")


# ── TOMs ──────────────────────────────────────────────────

@app.command("toms")
def list_toms(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List technical/organisational measures (TOMs)."""
    client = ElizaClient(instance=instance)
    toms = client.get_paginated("dsg/tom", limit=limit)
    for t in toms:
        t["description_clean"] = _clean_html(t.get("description", ""))
    format_output(toms, fmt=fmt, columns=TOM_COLUMNS, title=f"TOMs ({len(toms)})")


# ── Subcontractors ────────────────────────────────────────

@app.command("subcontractors")
def list_subcontractors(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List subcontractors."""
    client = ElizaClient(instance=instance)
    subs = client.get_paginated("dsg/subcontractor", limit=limit)
    for s in subs:
        s["description_clean"] = _clean_html(s.get("description", ""))
    format_output(subs, fmt=fmt, columns=SUBCONTRACTOR_COLUMNS, title=f"Subcontractors ({len(subs)})")


# ── Applications ──────────────────────────────────────────

@app.command("applications")
def list_applications(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List applications."""
    client = ElizaClient(instance=instance)
    apps = client.get_paginated("dsg/application", limit=limit)
    for a in apps:
        a["description_clean"] = _clean_html(a.get("description", ""))
    format_output(apps, fmt=fmt, columns=APPLICATION_COLUMNS, title=f"Applications ({len(apps)})")
