"""OKR (Objectives & Key Results) commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="OKR — Objectives & Key Results")
console = Console()

SYSTEM_COLUMNS = ["id", "title", "vision_clean", "mission_clean"]
PERIOD_COLUMNS = ["id", "title", "start_date", "end_date"]
OBJECTIVE_COLUMNS = ["id", "title", "period_name", "description_clean"]
RESULT_COLUMNS = ["id", "title", "objective_name", "target_value", "current_value"]
UPDATE_COLUMNS = ["id", "date", "value", "result_name"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


# ── Systems ───────────────────────────────────────────────

@app.command("systems")
def list_systems(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List OKR systems."""
    client = ElizaClient(instance=instance)
    systems = client.get_paginated("okr/system", limit=limit)
    for s in systems:
        s["vision_clean"] = _clean_html(s.get("vision", ""))
        s["mission_clean"] = _clean_html(s.get("mission", ""))
    format_output(systems, fmt=fmt, columns=SYSTEM_COLUMNS, title=f"OKR Systems ({len(systems)})")


@app.command("system-get")
def get_system(
    system_id: int = typer.Argument(help="System ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get OKR system details."""
    client = ElizaClient(instance=instance)
    system = client.get(f"okr/system/{system_id}")
    system["vision_clean"] = _clean_html(system.get("vision", ""))
    system["mission_clean"] = _clean_html(system.get("mission", ""))
    format_output(system, fmt=fmt, columns=SYSTEM_COLUMNS)


# ── Periods ───────────────────────────────────────────────

@app.command("periods")
def list_periods(
    system: Optional[int] = typer.Option(None, "--system", help="System ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List OKR periods."""
    client = ElizaClient(instance=instance)
    params = {}
    if system:
        params["system"] = system
    periods = client.get_paginated("okr/period", params=params, limit=limit)
    for p in periods:
        p["start_date"] = (p.get("start_date") or "")[:10]
        p["end_date"] = (p.get("end_date") or "")[:10]
    format_output(periods, fmt=fmt, columns=PERIOD_COLUMNS, title=f"Periods ({len(periods)})")


# ── Objectives ────────────────────────────────────────────

@app.command("objectives")
def list_objectives(
    period: Optional[int] = typer.Option(None, "--period", help="Period ID"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List objectives."""
    client = ElizaClient(instance=instance)
    params = {}
    if period:
        params["period"] = period
    objectives = client.get_paginated("okr/objective", params=params, limit=limit)
    for o in objectives:
        o["description_clean"] = _clean_html(o.get("description", ""))
        p = o.get("period") or {}
        o["period_name"] = p.get("title", "") if isinstance(p, dict) else str(p or "")
    format_output(objectives, fmt=fmt, columns=OBJECTIVE_COLUMNS, title=f"Objectives ({len(objectives)})")


@app.command("objective-get")
def get_objective(
    objective_id: int = typer.Argument(help="Objective ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get objective details."""
    client = ElizaClient(instance=instance)
    obj = client.get(f"okr/objective/{objective_id}")
    obj["description_clean"] = _clean_html(obj.get("description", ""))
    p = obj.get("period") or {}
    obj["period_name"] = p.get("title", "") if isinstance(p, dict) else str(p or "")
    format_output(obj, fmt=fmt, columns=OBJECTIVE_COLUMNS)


# ── Results ───────────────────────────────────────────────

@app.command("results")
def list_results(
    objective: Optional[int] = typer.Option(None, "--objective", help="Objective ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List key results."""
    client = ElizaClient(instance=instance)
    params = {}
    if objective:
        params["objective"] = objective
    results = client.get_paginated("okr/result", params=params, limit=limit)
    for r in results:
        o = r.get("objective") or {}
        r["objective_name"] = o.get("title", "") if isinstance(o, dict) else str(o or "")
    format_output(results, fmt=fmt, columns=RESULT_COLUMNS, title=f"Key Results ({len(results)})")


# ── Updates ───────────────────────────────────────────────

@app.command("updates")
def list_updates(
    result: Optional[int] = typer.Option(None, "--result", help="Result ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List result updates."""
    client = ElizaClient(instance=instance)
    params = {}
    if result:
        params["result"] = result
    updates = client.get_paginated("okr/update", params=params, limit=limit)
    for u in updates:
        u["date"] = (u.get("date") or "")[:10]
        r = u.get("result") or {}
        u["result_name"] = r.get("title", "") if isinstance(r, dict) else str(r or "")
    format_output(updates, fmt=fmt, columns=UPDATE_COLUMNS, title=f"Updates ({len(updates)})")
