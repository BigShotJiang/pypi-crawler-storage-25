"""KPI / Kennzahlen commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="KPIs / Kennzahlen")
console = Console()

KPI_COLUMNS = ["uuid", "title", "unit", "target_value", "folder_name"]
KPI_DETAIL = ["uuid", "title", "description", "unit", "target_value", "folder_name", "created_date"]
FOLDER_COLUMNS = ["uuid", "title", "description"]
MEASUREMENT_COLUMNS = ["id", "date", "value", "description", "created_date"]


def _enrich_kpi(kpi: dict) -> dict:
    folder = kpi.get("folder", {}) or {}
    if isinstance(folder, dict):
        kpi["folder_name"] = folder.get("title", str(folder.get("uuid", "")))
    else:
        kpi["folder_name"] = str(folder)
    return kpi


@app.command("list")
def list_kpis(
    folder: Optional[str] = typer.Option(None, "--folder", help="Folder UUID"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List KPIs."""
    client = ElizaClient(instance=instance)
    params = {}
    if folder:
        params["folder"] = folder
    kpis = client.get_paginated("kpi/kpi", params=params, limit=limit)
    kpis = [_enrich_kpi(k) for k in kpis]
    format_output(kpis, fmt=fmt, columns=KPI_COLUMNS, title="KPIs")


@app.command("get")
def get_kpi(
    kpi_uuid: str = typer.Argument(help="KPI UUID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get KPI details."""
    client = ElizaClient(instance=instance)
    kpi = client.get(f"kpi/kpi/{kpi_uuid}")
    kpi = _enrich_kpi(kpi)
    format_output(kpi, fmt=fmt, columns=KPI_DETAIL, title="KPI")


@app.command("folders")
def list_folders(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List KPI folders."""
    client = ElizaClient(instance=instance)
    folders = client.get_paginated("kpi/folder", limit=limit)
    format_output(folders, fmt=fmt, columns=FOLDER_COLUMNS, title="KPI Folders")


@app.command("record")
def record_measurement(
    kpi_uuid: str = typer.Argument(help="KPI UUID"),
    date: str = typer.Option(..., "--date", "-d", help="Date (YYYY-MM-DD)"),
    value: float = typer.Option(..., "--value", "-v", help="Measurement value"),
    description: Optional[str] = typer.Option(None, "--description", help="Description"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Record a KPI measurement."""
    client = ElizaClient(instance=instance)
    data = {"kpi": kpi_uuid, "date": date, "value": value}
    if description:
        data["description"] = description
    result = client.post("kpi/measurement", data=data)
    console.print(f"[green]✓[/green] Measurement recorded: {value} on {date}")


@app.command("measurements")
def list_measurements(
    kpi_uuid: str = typer.Argument(help="KPI UUID"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List measurements for a KPI."""
    client = ElizaClient(instance=instance)
    params = {"kpi": kpi_uuid}
    measurements = client.get_paginated("kpi/measurement", params=params, limit=limit)
    format_output(measurements, fmt=fmt, columns=MEASUREMENT_COLUMNS, title="Measurements")
