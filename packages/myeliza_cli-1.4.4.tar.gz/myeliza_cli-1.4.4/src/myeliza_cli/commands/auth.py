"""Auth commands: login, status, instances."""

from typing import Optional

import typer
from rich.console import Console

from ..config import add_instance, get_instance, list_instances, remove_instance
from ..output import format_output

app = typer.Typer(help="Authentication and instance management")
console = Console()


@app.command()
def login(
    instance: str = typer.Option(..., "--instance", "-i", help="Instance name (e.g. elizaag)"),
    url: str = typer.Option(..., "--url", help="API base URL"),
    token: str = typer.Option(..., "--token", help="API token"),
    default: bool = typer.Option(False, "--default", help="Set as default instance"),
):
    """Configure an ELIZA instance."""
    add_instance(instance, url, token, set_default=default)
    console.print(f"[green]✓[/green] Instance '{instance}' configured ({url})")
    if default:
        console.print(f"[green]✓[/green] Set as default instance")


@app.command()
def status(
    instance: Optional[str] = typer.Option(None, "--instance", "-i", help="Instance to check"),
):
    """Show current authentication status."""
    try:
        from ..client import ElizaClient
        client = ElizaClient(instance=instance)
        # Quick health check — try listing users with limit 1
        data = client.get("user", params={"limit": 1})
        count = data.get("count", "?") if isinstance(data, dict) else len(data)
        console.print(f"[green]✓[/green] Connected to [bold]{client.instance_name}[/bold] ({client.base_url})")
        console.print(f"  Users: {count}")
    except Exception as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(1)


@app.command()
def instances(
    fmt: str = typer.Option("table", "--format", "-f", help="Output format"),
):
    """List all configured instances."""
    insts = list_instances()
    if not insts:
        console.print("[yellow]No instances configured.[/yellow] Run 'myeliza auth login' to add one.")
        raise typer.Exit(0)
    for inst in insts:
        inst["default"] = "✓" if inst["default"] else ""
    format_output(insts, fmt=fmt, columns=["name", "url", "default"], title="Instances")


@app.command()
def logout(
    instance: str = typer.Option(..., "--instance", "-i", help="Instance to remove"),
):
    """Remove an instance from config."""
    remove_instance(instance)
    console.print(f"[green]✓[/green] Instance '{instance}' removed")
