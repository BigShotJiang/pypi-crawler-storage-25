"""Timetracker commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Time tracking")
console = Console()

WORKTIME_COLUMNS = ["id", "user_name", "date", "start_time", "end_time", "type_name", "description"]


def _enrich_worktime(entry: dict) -> dict:
    """Add computed fields."""
    user = entry.get("user", {}) or {}
    if isinstance(user, dict):
        entry["user_name"] = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip()
    else:
        entry["user_name"] = str(user)
    wtype = entry.get("type", {}) or {}
    if isinstance(wtype, dict):
        entry["type_name"] = wtype.get("title", str(wtype.get("id", "")))
    else:
        entry["type_name"] = str(wtype)
    return entry


@app.command("list")
def list_worktimes(
    user: Optional[int] = typer.Option(None, "--user", "-u", help="User ID"),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Date (YYYY-MM-DD)"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List work time entries."""
    client = ElizaClient(instance=instance)
    params = {}
    if user:
        params["user"] = user
    if date:
        params["date"] = date
    entries = client.get_paginated("timetracker/worktime", params=params, limit=limit)
    entries = [_enrich_worktime(e) for e in entries]
    format_output(entries, fmt=fmt, columns=WORKTIME_COLUMNS, title="Work Times")


@app.command("add")
def add_worktime(
    user: int = typer.Option(..., "--user", "-u", help="User ID"),
    date: str = typer.Option(..., "--date", "-d", help="Date (YYYY-MM-DD)"),
    start: str = typer.Option(..., "--start", help="Start time (HH:MM)"),
    end: str = typer.Option(..., "--end", help="End time (HH:MM)"),
    type_id: int = typer.Option(1, "--type", "-t", help="Time type ID (1=work, 5=travel)"),
    description: str = typer.Option("", "--description", help="Description"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Add a work time entry."""
    client = ElizaClient(instance=instance)
    data = {
        "user": user,
        "date": date,
        "start_time": start,
        "end_time": end,
        "type": type_id,
        "description": description,
    }
    result = client.post("timetracker/worktime", data=data)
    console.print(f"[green]✓[/green] Work time added: {date} {start}–{end}")


@app.command("absences")
def list_absences(
    user: Optional[int] = typer.Option(None, "--user", "-u"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List absences."""
    client = ElizaClient(instance=instance)
    params = {}
    if user:
        params["user"] = user
    absences = client.get_paginated("timetracker/absence", params=params, limit=limit)
    format_output(
        absences, fmt=fmt,
        columns=["id", "user", "start_date", "end_date", "type", "state"],
        title="Absences",
    )


# =============================================================================
# Public Holidays (Feiertage)
# =============================================================================

HOLIDAY_COLUMNS = ["id", "date", "title", "factor", "description"]


@app.command("holidays")
def list_holidays(
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List public holidays (Feiertage)."""
    client = ElizaClient(instance=instance)
    data = client.get_paginated("timetracker/publicholiday")
    format_output(data, fmt=fmt, columns=HOLIDAY_COLUMNS, title="Public Holidays")


@app.command("holiday-create")
def create_holiday(
    date: str = typer.Option(..., "--date", "-d", help="Datum (YYYY-MM-DD)"),
    title: str = typer.Option(..., "--title", "-t", help="Titel des Feiertags"),
    factor: float = typer.Option(0.0, "--factor", "-f", help="Faktor (0.0=ganzer Tag frei, 0.5=halber Tag frei, 1.0=kein freier Tag)"),
    description: str = typer.Option("", "--description", help="Beschreibung"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a public holiday (Feiertag)."""
    client = ElizaClient(instance=instance)
    data = {"date": date, "title": title, "factor": factor, "description": description}
    result = client.post("timetracker/publicholiday", json=data)
    console.print(f"✓ Holiday created: {result.get('id')} — {result.get('title')} ({result.get('date')}, factor={result.get('factor')})")


@app.command("holiday-delete")
def delete_holiday(
    holiday_id: int = typer.Argument(..., help="Holiday ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a public holiday (Feiertag)."""
    client = ElizaClient(instance=instance)
    client.delete(f"timetracker/publicholiday/{holiday_id}")
    console.print(f"✓ Holiday {holiday_id} deleted")
