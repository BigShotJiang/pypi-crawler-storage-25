"""Spaces commands."""

import re
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Spaces")
console = Console()

SPACE_COLUMNS = ["id", "title", "state", "description"]
SPACE_DETAIL = ["id", "title", "state", "description", "created_date", "modified_date"]
BOARD_COLUMNS = ["id", "title", "space"]
CARD_COLUMNS = ["id", "title", "description", "list"]
MEETING_COLUMNS = ["id", "title", "start_date", "end_date"]
MEETING_DETAIL = ["id", "title", "description", "start_date", "end_date", "location"]
MEETINGITEM_COLUMNS = ["id", "number", "title", "text"]


@app.command("list")
def list_spaces(
    state: Optional[str] = typer.Option(None, "--state", "-s", help="Filter by state"),
    search: Optional[str] = typer.Option(None, "--search", "-q", help="Search text"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List spaces."""
    client = ElizaClient(instance=instance)
    params = {}
    if state:
        params["state"] = state
    if search:
        params["search"] = search
    spaces = client.get_paginated("teams/space", params=params, limit=limit)
    format_output(spaces, fmt=fmt, columns=SPACE_COLUMNS, title=f"Spaces ({len(spaces)})")


@app.command("get")
def get_space(
    space_id: int = typer.Argument(help="Space ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get space details."""
    client = ElizaClient(instance=instance)
    space = client.get(f"teams/space/{space_id}")
    format_output(space, fmt=fmt, columns=SPACE_DETAIL)


@app.command("create")
def create_space(
    title: str = typer.Option(..., "--title", "-t", help="Space title"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    state: Optional[str] = typer.Option(None, "--state", "-s", help="public or private"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a new space."""
    client = ElizaClient(instance=instance)
    data: dict = {"title": title}
    if description is not None:
        data["description"] = description
    if state is not None:
        data["state"] = state
    result = client.post("teams/space", data=data)
    console.print(f"[green]✓[/green] Space created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("delete")
def delete_space(
    space_id: int = typer.Argument(help="Space ID"),
    force: bool = typer.Option(False, "--force", help="Skip confirmation"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a space."""
    if not force:
        confirm = typer.confirm(f"Delete space {space_id}?")
        if not confirm:
            raise typer.Abort()
    client = ElizaClient(instance=instance)
    client.delete(f"teams/space/{space_id}")
    console.print(f"[green]✓[/green] Space {space_id} deleted")


@app.command("boards")
def list_boards(
    space_id: int = typer.Argument(help="Space ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List boards for a space."""
    client = ElizaClient(instance=instance)
    boards = client.get_paginated("teams/board", params={"space": space_id})
    format_output(boards, fmt=fmt, columns=BOARD_COLUMNS, title="Boards")


@app.command("cards")
def list_cards(
    board: int = typer.Option(..., "--board", "-b", help="Board ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List cards in a board (via card lists)."""
    client = ElizaClient(instance=instance)
    cardlists = client.get_paginated("teams/list", params={"board": board})
    all_cards = []
    for cl in cardlists:
        cl_id = cl.get("id")
        if cl_id:
            cards = client.get_paginated("teams/card", params={"list": cl_id})
            all_cards.extend(cards)
    format_output(all_cards, fmt=fmt, columns=CARD_COLUMNS, title="Cards")


CARD_DETAIL = ["id", "title", "description", "list", "assigned_user", "due_date", "content_type", "object_id", "created_date", "modified_date"]


@app.command("card-get")
def get_card(
    card_id: int = typer.Argument(help="Card ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get card details."""
    client = ElizaClient(instance=instance)
    card = client.get(f"teams/card/{card_id}")
    format_output(card, fmt=fmt, columns=CARD_DETAIL)


@app.command("card-create")
def create_card(
    cardlist: int = typer.Option(..., "--cardlist", help="Card list ID"),
    title: str = typer.Option(..., "--title", "-t", help="Card title"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a card in a card list."""
    client = ElizaClient(instance=instance)
    data: dict = {"list": cardlist, "title": title}
    if description is not None:
        data["description"] = description
    result = client.post("teams/card", data=data)
    console.print(f"[green]✓[/green] Card created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("card-set-parent")
def card_set_parent(
    card_id: int = typer.Argument(help="Card ID"),
    content_type: int = typer.Option(..., "--content-type", "-ct", help="Content Type ID"),
    object_id: int = typer.Option(..., "--object-id", "-oid", help="Object ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Set the parent object (gehört zu) for a card."""
    client = ElizaClient(instance=instance)
    data = {"content_type": content_type, "object_id": object_id}
    client.post(f"teams/card/{card_id}/set_parent", data=data)
    console.print(f"[green]✓ Parent set for card {card_id}[/green]")


@app.command("card-clear-parent")
def card_clear_parent(
    card_id: int = typer.Argument(help="Card ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Clear the parent object (gehört zu) for a card."""
    client = ElizaClient(instance=instance)
    client.post(f"teams/card/{card_id}/set_parent", data={})
    console.print(f"[green]✓ Parent cleared for card {card_id}[/green]")


COMMENT_COLUMNS = ["id", "user_name", "created_date", "comment_clean"]


def _clean_html(text: str) -> str:
    """Strip HTML tags and collapse whitespace."""
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:500]


@app.command("card-comments")
def list_card_comments(
    card_id: int = typer.Argument(help="Card ID"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List comments (followups) for a card."""
    client = ElizaClient(instance=instance)
    comments = client.get(f"teams/card/{card_id}/comments")
    if isinstance(comments, dict):
        comments = comments.get("results", [])
    comments = comments[:limit]

    for c in comments:
        user = c.get("user") or {}
        c["user_name"] = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip()
        c["comment_clean"] = _clean_html(c.get("comment", ""))
        c["created_date"] = (c.get("created_date") or "")[:16]
        files = c.get("files", [])
        if files:
            c["comment_clean"] += f" [📎 {len(files)} Datei(en)]"

    format_output(comments, fmt=fmt, columns=COMMENT_COLUMNS, title="Comments")


@app.command("card-comment-add")
def add_card_comment(
    card_id: int = typer.Argument(help="Card ID"),
    comment: str = typer.Option("", "--comment", "-c", help="Comment text"),
    file: Optional[list[str]] = typer.Option(None, "--file", "-f", help="File(s) to attach"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Add a comment (followup) to a card, optionally with file attachments."""
    if not comment and not file:
        console.print("[red]Fehler:[/red] --comment oder --file erforderlich.")
        raise typer.Exit(1)

    client = ElizaClient(instance=instance)

    if file:
        # Multipart upload with files
        data = {"comment": comment} if comment else {}
        files_list = []
        for f in file:
            p = Path(f)
            if not p.exists():
                console.print(f"[red]Fehler:[/red] Datei nicht gefunden: {f}")
                raise typer.Exit(1)
            files_list.append(("file", (p.name, open(p, "rb"))))
        result = client.post_multipart(f"teams/card/{card_id}/add-comment", data=data, files=files_list)
    else:
        result = client.post(f"teams/card/{card_id}/add-comment", data={"comment": comment})

    console.print(f"[green]✓[/green] Comment added to card {card_id}")
    file_count = len(result.get("files", []))
    if file_count:
        console.print(f"  📎 {file_count} Datei(en) angehängt")


@app.command("meetings")
def list_meetings(
    space_id: int = typer.Argument(help="Space ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List meetings for a space."""
    client = ElizaClient(instance=instance)
    meetings = client.get_paginated("teams/meeting", params={"space": space_id})
    format_output(meetings, fmt=fmt, columns=MEETING_COLUMNS, title="Meetings")


@app.command("meeting-create")
def create_meeting(
    space: int = typer.Option(..., "--space", help="Space ID"),
    title: str = typer.Option(..., "--title", "-t", help="Meeting title"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    start: Optional[str] = typer.Option(None, "--start", help="Start datetime"),
    end: Optional[str] = typer.Option(None, "--end", help="End datetime"),
    location: Optional[str] = typer.Option(None, "--location", help="Location"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a meeting in a space."""
    client = ElizaClient(instance=instance)
    data: dict = {"space": space, "title": title}
    if description is not None:
        data["description"] = description
    if start is not None:
        data["start"] = start
    if end is not None:
        data["end"] = end
    if location is not None:
        data["location"] = location
    result = client.post("teams/meeting", data=data)
    console.print(f"[green]✓[/green] Meeting created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("meeting-get")
def get_meeting(
    meeting_id: int = typer.Argument(help="Meeting ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get meeting details."""
    client = ElizaClient(instance=instance)
    meeting = client.get(f"teams/meeting/{meeting_id}")
    format_output(meeting, fmt=fmt, columns=MEETING_DETAIL)


@app.command("items")
def list_meetingitems(
    meeting_id: int = typer.Argument(help="Meeting ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List meeting items (Traktanden) for a meeting."""
    client = ElizaClient(instance=instance)
    items = client.get_paginated("teams/meetingitem", params={"meeting": meeting_id})
    format_output(items, fmt=fmt, columns=MEETINGITEM_COLUMNS, title="Meeting Items")


@app.command("item-create")
def create_meetingitem(
    meeting: int = typer.Option(..., "--meeting", help="Meeting ID"),
    title: str = typer.Option(..., "--title", "-t", help="Item title"),
    number: Optional[int] = typer.Option(None, "--number", "-n", help="Item number"),
    text: Optional[str] = typer.Option(None, "--text", help="Item text"),
    parent: Optional[int] = typer.Option(None, "--parent", help="Parent item ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a meeting item (Traktandum)."""
    client = ElizaClient(instance=instance)
    data: dict = {"meeting": meeting, "title": title}
    if number is not None:
        data["number"] = number
    if text is not None:
        data["text"] = text
    if parent is not None:
        data["parent"] = parent
    result = client.post("teams/meetingitem", data=data)
    console.print(f"[green]✓[/green] Meeting item created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")
