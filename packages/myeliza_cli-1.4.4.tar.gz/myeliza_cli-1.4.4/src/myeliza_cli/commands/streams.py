"""Streams / News commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Streams / News")
console = Console()

STREAM_COLUMNS = ["id", "title", "description", "created_date"]
MESSAGE_COLUMNS = ["id", "stream_name", "title", "text_preview", "created_date"]
EVENT_COLUMNS = ["id", "title", "stream_name", "start_date", "end_date", "location"]


def _enrich_message(msg: dict) -> dict:
    stream = msg.get("stream", {}) or {}
    if isinstance(stream, dict):
        msg["stream_name"] = stream.get("title", str(stream.get("id", "")))
    else:
        msg["stream_name"] = str(stream)
    text = msg.get("text", "") or ""
    msg["text_preview"] = text[:100].replace("\n", " ")
    return msg


def _enrich_event(event: dict) -> dict:
    stream = event.get("stream", {}) or {}
    if isinstance(stream, dict):
        event["stream_name"] = stream.get("title", str(stream.get("id", "")))
    else:
        event["stream_name"] = str(stream)
    return event


@app.command("list")
def list_streams(
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List streams (Newskanäle)."""
    client = ElizaClient(instance=instance)
    streams = client.get_paginated("stream/stream", limit=limit)
    format_output(streams, fmt=fmt, columns=STREAM_COLUMNS, title="Streams")


@app.command("get")
def get_stream(
    stream_id: int = typer.Argument(help="Stream ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get stream details."""
    client = ElizaClient(instance=instance)
    stream = client.get(f"stream/stream/{stream_id}")
    format_output(stream, fmt=fmt, columns=STREAM_COLUMNS)


@app.command("create")
def create_stream(
    title: str = typer.Option(..., "--title", "-t", help="Stream title"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Stream description"),
    visibility: Optional[str] = typer.Option(None, "--visibility", help="normal or protected"),
    allow_comments: Optional[bool] = typer.Option(None, "--allow-comments"),
    allow_likes: Optional[bool] = typer.Option(None, "--allow-likes"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a new stream."""
    client = ElizaClient(instance=instance)
    data: dict = {"title": title}
    if description is not None:
        data["description"] = description
    if visibility is not None:
        data["visibility"] = visibility
    if allow_comments is not None:
        data["allow_comments"] = allow_comments
    if allow_likes is not None:
        data["allow_likes"] = allow_likes
    result = client.post("stream/stream", data=data)
    console.print(f"[green]✓[/green] Stream created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("update")
def update_stream(
    stream_id: int = typer.Argument(help="Stream ID"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Stream title"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Stream description"),
    visibility: Optional[str] = typer.Option(None, "--visibility", help="normal or protected"),
    archived: Optional[bool] = typer.Option(None, "--archived"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Update a stream."""
    client = ElizaClient(instance=instance)
    data: dict = {}
    if title is not None:
        data["title"] = title
    if description is not None:
        data["description"] = description
    if visibility is not None:
        data["visibility"] = visibility
    if archived is not None:
        data["archived"] = archived
    if not data:
        console.print("[yellow]No fields to update.[/yellow]")
        raise typer.Exit(1)
    result = client.patch(f"stream/stream/{stream_id}", data=data)
    console.print(f"[green]✓[/green] Stream {stream_id} updated")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("delete")
def delete_stream(
    stream_id: int = typer.Argument(help="Stream ID"),
    force: bool = typer.Option(False, "--force", help="Skip confirmation"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a stream."""
    if not force:
        confirm = typer.confirm(f"Delete stream {stream_id}?")
        if not confirm:
            raise typer.Abort()
    client = ElizaClient(instance=instance)
    client.delete(f"stream/stream/{stream_id}")
    console.print(f"[green]✓[/green] Stream {stream_id} deleted")


@app.command("messages")
def list_messages(
    stream: Optional[int] = typer.Option(None, "--stream", "-s", help="Stream ID"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List stream messages."""
    client = ElizaClient(instance=instance)
    params = {}
    if stream:
        params["stream"] = stream
    messages = client.get_paginated("stream/messages", params=params, limit=limit)
    messages = [_enrich_message(m) for m in messages]
    format_output(messages, fmt=fmt, columns=MESSAGE_COLUMNS, title="Messages")


@app.command("post")
def post_message(
    stream: int = typer.Option(..., "--stream", "-s", help="Stream ID"),
    title: str = typer.Option(..., "--title", "-t", help="Message title"),
    text: str = typer.Option(..., "--text", help="Message text"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a message in a stream."""
    client = ElizaClient(instance=instance)
    data = {"stream": stream, "title": title, "text": text}
    result = client.post("stream/messages", data=data)
    console.print(f"[green]✓[/green] Message created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("events")
def list_events(
    stream: Optional[int] = typer.Option(None, "--stream", "-s", help="Filter by stream ID"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List events."""
    client = ElizaClient(instance=instance)
    params = {}
    if stream:
        params["stream"] = stream
    events = client.get_paginated("stream/event", params=params, limit=limit)
    events = [_enrich_event(e) for e in events]
    format_output(events, fmt=fmt, columns=EVENT_COLUMNS, title="Events")


@app.command("event-get")
def get_event(
    event_id: int = typer.Argument(help="Event ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get event details."""
    client = ElizaClient(instance=instance)
    event = client.get(f"stream/event/{event_id}")
    event = _enrich_event(event)
    format_output(event, fmt=fmt, columns=EVENT_COLUMNS)


@app.command("event-create")
def create_event(
    stream: int = typer.Option(..., "--stream", "-s", help="Stream ID"),
    title: str = typer.Option(..., "--title", "-t", help="Event title"),
    start_date: str = typer.Option(..., "--start-date", help="Start date (ISO format)"),
    end_date: Optional[str] = typer.Option(None, "--end-date", help="End date (ISO format)"),
    text: Optional[str] = typer.Option(None, "--text", help="Event description"),
    location: Optional[str] = typer.Option(None, "--location", help="Event location"),
    whole_day: Optional[bool] = typer.Option(None, "--whole-day"),
    max_participants: Optional[int] = typer.Option(None, "--max-participants"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create an event."""
    client = ElizaClient(instance=instance)
    data: dict = {"stream": stream, "title": title, "start_date": start_date}
    if end_date is not None:
        data["end_date"] = end_date
    if text is not None:
        data["text"] = text
    if location is not None:
        data["location"] = location
    if whole_day is not None:
        data["whole_day"] = whole_day
    if max_participants is not None:
        data["max_participants"] = max_participants
    result = client.post("stream/event", data=data)
    console.print(f"[green]✓[/green] Event created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")
