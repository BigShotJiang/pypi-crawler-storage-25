"""Bot / AI Chat commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Bot / AI Chat")
console = Console()

CHAT_COLUMNS = ["uuid_short", "title", "ai_model_id", "created"]
CHAT_DETAIL = ["uuid", "title", "system_role", "ai_model_id", "created"]
ENTRY_COLUMNS = ["id", "role", "content_short", "created"]


def _enrich_chat(chat: dict) -> dict:
    chat["uuid_short"] = (chat.get("uuid") or "")[:8]
    chat["created"] = (chat.get("created_date") or chat.get("created") or "")[:10]
    return chat


def _enrich_entry(entry: dict) -> dict:
    content = entry.get("content") or ""
    entry["content_short"] = content[:100] + ("..." if len(content) > 100 else "")
    entry["created"] = (entry.get("created_date") or entry.get("created") or "")[:10]
    return entry


# ── Chats ─────────────────────────────────────────────────

@app.command("chats")
def list_chats(
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List chats."""
    client = ElizaClient(instance=instance)
    chats = client.get_paginated("bot/chat", limit=limit)
    chats = [_enrich_chat(c) for c in chats]
    format_output(chats, fmt=fmt, columns=CHAT_COLUMNS, title=f"Chats ({len(chats)})")


@app.command("chat-get")
def get_chat(
    uuid: str = typer.Argument(help="Chat UUID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get chat details."""
    client = ElizaClient(instance=instance)
    chat = client.get(f"bot/chat/{uuid}")
    chat = _enrich_chat(chat)
    format_output(chat, fmt=fmt, columns=CHAT_DETAIL)


@app.command("chat-create")
def create_chat(
    title: str = typer.Option(..., "--title"),
    system_role: Optional[str] = typer.Option(None, "--system-role"),
    ai_model_id: Optional[int] = typer.Option(None, "--model-id", help="AI model ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a chat."""
    client = ElizaClient(instance=instance)
    data = {"title": title}
    if system_role:
        data["system_role"] = system_role
    if ai_model_id:
        data["ai_model_id"] = ai_model_id
    result = client.post("bot/chat", data=data)
    console.print(f"[green]✓[/green] Chat created: {result.get('uuid', '?')} — {title}")


@app.command("chat-update")
def update_chat(
    uuid: str = typer.Argument(help="Chat UUID"),
    title: Optional[str] = typer.Option(None, "--title"),
    system_role: Optional[str] = typer.Option(None, "--system-role"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a chat."""
    client = ElizaClient(instance=instance)
    data = {}
    if title:
        data["title"] = title
    if system_role:
        data["system_role"] = system_role
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"bot/chat/{uuid}", data=data)
    console.print(f"[green]✓[/green] Chat {uuid[:8]}… updated")


# ── Entries ───────────────────────────────────────────────

@app.command("entries")
def list_entries(
    uuid: str = typer.Argument(help="Chat UUID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List chat entries."""
    client = ElizaClient(instance=instance)
    entries = client.get_paginated(f"bot/chat/{uuid}/entry", limit=limit)
    entries = [_enrich_entry(e) for e in entries]
    format_output(entries, fmt=fmt, columns=ENTRY_COLUMNS, title=f"Entries ({len(entries)})")
