"""Processes (Prozesse) commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Processes / Prozesse")
console = Console()

PROCESS_COLUMNS = ["id", "nummer", "titel", "state", "color"]
PROCESS_DETAIL = [
    "id", "nummer", "titel", "state", "beschreibung",
    "color", "text_color", "uebergeordneter_prozess",
]
STEP_COLUMNS = ["id", "nummer", "titel", "text", "ergebnis"]
LABEL_COLUMNS = ["id", "title"]
TRANSITION_COLUMNS = ["name", "label"]


@app.command("list")
def list_processes(
    state: Optional[str] = typer.Option(None, "--state", "-s", help="Filter by state"),
    search: Optional[str] = typer.Option(None, "--search", "-q", help="Search text"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List processes."""
    client = ElizaClient(instance=instance)
    params = {}
    if state:
        params["state"] = state
    if search:
        params["search"] = search
    processes = client.get_paginated("process/process", params=params, limit=limit)
    format_output(processes, fmt=fmt, columns=PROCESS_COLUMNS, title=f"Processes ({len(processes)})")


@app.command("get")
def get_process(
    process_id: int = typer.Argument(help="Process ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get process details."""
    client = ElizaClient(instance=instance)
    process = client.get(f"process/process/{process_id}")
    format_output(process, fmt=fmt, columns=PROCESS_DETAIL)


@app.command("create")
def create_process(
    nummer: str = typer.Option(..., "--nummer", "-n", help="Process number"),
    title: str = typer.Option(..., "--title", "-t", help="Process title"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    color: Optional[str] = typer.Option(None, "--color", help="Color (hex)"),
    text_color: Optional[str] = typer.Option(None, "--text-color", help="Text color (hex)"),
    parent: Optional[int] = typer.Option(None, "--parent", help="Parent process ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a new process."""
    client = ElizaClient(instance=instance)
    data: dict = {"nummer": nummer, "titel": title, "state": "draft"}
    if description is not None:
        data["beschreibung"] = description
    if color is not None:
        data["color"] = color
    if text_color is not None:
        data["text_color"] = text_color
    if parent is not None:
        data["uebergeordneter_prozess"] = parent
    result = client.post("process/process", data=data)
    console.print(f"[green]✓[/green] Process created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("update")
def update_process(
    process_id: int = typer.Argument(help="Process ID"),
    title: Optional[str] = typer.Option(None, "--title", "-t"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    color: Optional[str] = typer.Option(None, "--color"),
    text_color: Optional[str] = typer.Option(None, "--text-color"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a process."""
    client = ElizaClient(instance=instance)
    data: dict = {}
    if title is not None:
        data["titel"] = title
    if description is not None:
        data["beschreibung"] = description
    if color is not None:
        data["color"] = color
    if text_color is not None:
        data["text_color"] = text_color
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"process/process/{process_id}", data=data)
    console.print(f"[green]✓[/green] Process {process_id} updated")


@app.command("delete")
def delete_process(
    process_id: int = typer.Argument(help="Process ID"),
    force: bool = typer.Option(False, "--force", help="Skip confirmation"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a process."""
    if not force:
        confirm = typer.confirm(f"Delete process {process_id}?")
        if not confirm:
            raise typer.Abort()
    client = ElizaClient(instance=instance)
    client.delete(f"process/process/{process_id}")
    console.print(f"[green]✓[/green] Process {process_id} deleted")


@app.command("steps")
def list_steps(
    process_id: int = typer.Argument(help="Process ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List steps for a process."""
    client = ElizaClient(instance=instance)
    steps = client.get_paginated("process/processsteps", params={"prozess": process_id}, limit=limit)
    format_output(steps, fmt=fmt, columns=STEP_COLUMNS, title="Process Steps")


@app.command("step-create")
def create_step(
    process: int = typer.Option(..., "--process", "-p", help="Process ID"),
    nummer: str = typer.Option(..., "--nummer", "-n", help="Step number"),
    title: str = typer.Option(..., "--title", "-t", help="Step title"),
    text: Optional[str] = typer.Option(None, "--text", help="Step text"),
    result: Optional[str] = typer.Option(None, "--result", help="Expected result"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a process step."""
    client = ElizaClient(instance=instance)
    data: dict = {"prozess": process, "nummer": nummer, "titel": title}
    if text is not None:
        data["text"] = text
    if result is not None:
        data["ergebnis"] = result
    res = client.post("process/processsteps", data=data)
    console.print(f"[green]✓[/green] Step created: ID={res.get('id', '')}")
    if fmt == "json":
        format_output(res, fmt="json")


@app.command("labels")
def list_labels(
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List process labels."""
    client = ElizaClient(instance=instance)
    labels = client.get_paginated("process/label")
    format_output(labels, fmt=fmt, columns=LABEL_COLUMNS, title="Labels")


@app.command("transitions")
def list_transitions(
    process_id: int = typer.Argument(help="Process ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Show available transitions for a process."""
    client = ElizaClient(instance=instance)
    transitions = client.get(f"process/process/{process_id}/available_transitions")
    if isinstance(transitions, dict):
        transitions = transitions.get("results", [])
    format_output(transitions, fmt=fmt, columns=TRANSITION_COLUMNS, title="Available Transitions")


@app.command("transition")
def execute_transition(
    process_id: int = typer.Argument(help="Process ID"),
    action: str = typer.Option(..., "--action", "-a", help="Transition name"),
    comment: Optional[str] = typer.Option(None, "--comment", "-c", help="Comment"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Execute a state transition on a process."""
    client = ElizaClient(instance=instance)
    data: dict = {"transition": action}
    if comment:
        data["comment"] = comment
    client.post(f"process/process/{process_id}/transition", data=data)
    console.print(f"[green]✓[/green] Transition '{action}' executed on process {process_id}")
