"""SWOT / Risikomanagement commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="SWOT / Risikomanagement")
console = Console()

MEASURE_COLUMNS = ["id", "titel", "status", "verantwortung_name", "beschreibung_clean"]
MEASURE_DETAIL = ["id", "titel", "beschreibung_clean", "status", "verantwortung_name"]
ESTIMATE_COLUMNS = ["id", "titel", "art"]
CONTROL_COLUMNS = ["id", "titel", "measure_name"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _enrich_measure(m: dict) -> dict:
    m["beschreibung_clean"] = _clean_html(m.get("beschreibung", ""))
    v = m.get("verantwortung") or {}
    if isinstance(v, dict):
        m["verantwortung_name"] = f"{v.get('first_name', '')} {v.get('last_name', '')}".strip() or v.get("title", "")
    else:
        m["verantwortung_name"] = str(v or "")
    return m


# ── Measures ──────────────────────────────────────────────

@app.command("measures")
def list_measures(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    status: Optional[str] = typer.Option(None, "--status", "-s"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List measures."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    if status:
        params["status"] = status
    measures = client.get_paginated("swot/measure", params=params, limit=limit)
    measures = [_enrich_measure(m) for m in measures]
    format_output(measures, fmt=fmt, columns=MEASURE_COLUMNS, title=f"Measures ({len(measures)})")


@app.command("measure-get")
def get_measure(
    measure_id: int = typer.Argument(help="Measure ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get measure details."""
    client = ElizaClient(instance=instance)
    measure = client.get(f"swot/measure/{measure_id}")
    measure = _enrich_measure(measure)
    format_output(measure, fmt=fmt, columns=MEASURE_DETAIL)


@app.command("measure-create")
def create_measure(
    title: str = typer.Option(..., "--title"),
    description: str = typer.Option("", "--description", "-d"),
    status: Optional[str] = typer.Option(None, "--status", "-s"),
    verantwortung: Optional[int] = typer.Option(None, "--verantwortung", help="Responsible person ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a measure."""
    client = ElizaClient(instance=instance)
    data = {"titel": title}
    if description:
        data["beschreibung"] = description
    if status:
        data["status"] = status
    if verantwortung:
        data["verantwortung"] = verantwortung
    result = client.post("swot/measure", data=data)
    console.print(f"[green]✓[/green] Measure created: ID={result.get('id')} — {title}")


# ── Estimates ─────────────────────────────────────────────

@app.command("estimates")
def list_estimates(
    art: Optional[str] = typer.Option(None, "--art", help="S/W/O/T"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List estimates."""
    client = ElizaClient(instance=instance)
    params = {}
    if art:
        params["art"] = art
    estimates = client.get_paginated("swot/estimate", params=params, limit=limit)
    format_output(estimates, fmt=fmt, columns=ESTIMATE_COLUMNS, title=f"Estimates ({len(estimates)})")


@app.command("estimate-get")
def get_estimate(
    estimate_id: int = typer.Argument(help="Estimate ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get estimate details."""
    client = ElizaClient(instance=instance)
    estimate = client.get(f"swot/estimate/{estimate_id}")
    format_output(estimate, fmt=fmt, columns=ESTIMATE_COLUMNS)


# ── Controls ──────────────────────────────────────────────

@app.command("controls")
def list_controls(
    measure: Optional[int] = typer.Option(None, "--measure", help="Measure ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List controls."""
    client = ElizaClient(instance=instance)
    params = {}
    if measure:
        params["measure"] = measure
    controls = client.get_paginated("swot/control", params=params, limit=limit)
    for c in controls:
        m = c.get("measure") or {}
        c["measure_name"] = m.get("title", "") if isinstance(m, dict) else str(m or "")
    format_output(controls, fmt=fmt, columns=CONTROL_COLUMNS, title=f"Controls ({len(controls)})")
