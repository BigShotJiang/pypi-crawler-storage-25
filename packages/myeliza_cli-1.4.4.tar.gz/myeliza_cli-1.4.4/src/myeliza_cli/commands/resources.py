"""Resources / Inventar commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Inventar / Resources")
console = Console()

COLUMNS = ["id", "title", "type_name", "serial_number", "location_name"]
DETAIL_COLUMNS = ["id", "title", "type_name", "serial_number", "location_name"]
ALLOCATION_COLUMNS = ["id", "resource_name", "start_date", "end_date"]


def _enrich(resource: dict) -> dict:
    t = resource.get("type") or {}
    resource["type_name"] = t.get("title", "") if isinstance(t, dict) else str(t or "")
    loc = resource.get("location") or {}
    resource["location_name"] = loc.get("title", "") if isinstance(loc, dict) else str(loc or "")
    return resource


def _enrich_allocation(alloc: dict) -> dict:
    r = alloc.get("resource") or {}
    alloc["resource_name"] = r.get("title", "") if isinstance(r, dict) else str(r or "")
    alloc["start_date"] = (alloc.get("start_date") or "")[:10]
    alloc["end_date"] = (alloc.get("end_date") or "")[:10]
    return alloc


# ── Resources ─────────────────────────────────────────────

@app.command("list")
def list_resources(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List resources."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    resources = client.get_paginated("resources/resources", params=params, limit=limit)
    resources = [_enrich(r) for r in resources]
    format_output(resources, fmt=fmt, columns=COLUMNS, title=f"Resources ({len(resources)})")


@app.command("get")
def get_resource(
    resource_id: int = typer.Argument(help="Resource ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get resource details."""
    client = ElizaClient(instance=instance)
    resource = client.get(f"resources/resources/{resource_id}")
    resource = _enrich(resource)
    format_output(resource, fmt=fmt, columns=DETAIL_COLUMNS)


@app.command("create")
def create_resource(
    title: str = typer.Option(..., "--title"),
    type_id: Optional[int] = typer.Option(None, "--type", "-t", help="Type ID"),
    serial_number: Optional[str] = typer.Option(None, "--serial-number"),
    location_id: Optional[int] = typer.Option(None, "--location", help="Location ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a resource."""
    client = ElizaClient(instance=instance)
    data = {"title": title}
    if type_id:
        data["type"] = type_id
    if serial_number:
        data["serial_number"] = serial_number
    if location_id:
        data["location"] = location_id
    result = client.post("resources/resources", data=data)
    console.print(f"[green]✓[/green] Resource created: ID={result.get('id')} — {title}")


@app.command("update")
def update_resource(
    resource_id: int = typer.Argument(help="Resource ID"),
    title: Optional[str] = typer.Option(None, "--title"),
    serial_number: Optional[str] = typer.Option(None, "--serial-number"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a resource."""
    client = ElizaClient(instance=instance)
    data = {}
    if title:
        data["title"] = title
    if serial_number:
        data["serial_number"] = serial_number
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"resources/resources/{resource_id}", data=data)
    console.print(f"[green]✓[/green] Resource {resource_id} updated")


@app.command("delete")
def delete_resource(
    resource_id: int = typer.Argument(help="Resource ID"),
    confirm: bool = typer.Option(False, "--yes", "-y"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a resource."""
    if not confirm:
        typer.confirm(f"Delete resource {resource_id}?", abort=True)
    client = ElizaClient(instance=instance)
    client.delete(f"resources/resources/{resource_id}")
    console.print(f"[green]✓[/green] Resource {resource_id} deleted")


# ── Allocations ───────────────────────────────────────────

@app.command("allocations")
def list_allocations(
    resource: Optional[int] = typer.Option(None, "--resource", help="Resource ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List allocations."""
    client = ElizaClient(instance=instance)
    params = {}
    if resource:
        params["resource"] = resource
    allocs = client.get_paginated("resources/allocations", params=params, limit=limit)
    allocs = [_enrich_allocation(a) for a in allocs]
    format_output(allocs, fmt=fmt, columns=ALLOCATION_COLUMNS, title=f"Allocations ({len(allocs)})")


@app.command("allocation-get")
def get_allocation(
    allocation_id: int = typer.Argument(help="Allocation ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get allocation details."""
    client = ElizaClient(instance=instance)
    alloc = client.get(f"resources/allocations/{allocation_id}")
    alloc = _enrich_allocation(alloc)
    format_output(alloc, fmt=fmt, columns=ALLOCATION_COLUMNS)
