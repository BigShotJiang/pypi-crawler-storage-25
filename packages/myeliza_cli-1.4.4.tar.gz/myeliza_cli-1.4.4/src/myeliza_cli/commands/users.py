"""Users & Groups commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Users and groups")
console = Console()

USER_COLUMNS = ["id", "username", "first_name", "last_name", "email", "is_active"]
GROUP_COLUMNS = ["id", "name"]


@app.command("list")
def list_users(
    limit: int = typer.Option(50, "--limit", "-l"),
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List users."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    users = client.get_paginated("user", params=params, limit=limit)
    format_output(users, fmt=fmt, columns=USER_COLUMNS, title=f"Users ({len(users)})")


@app.command("get")
def get_user(
    user_id: int = typer.Argument(help="User ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get user details."""
    client = ElizaClient(instance=instance)
    user = client.get(f"user/{user_id}")
    format_output(user, fmt=fmt, columns=USER_COLUMNS)


@app.command("create")
def create_user(
    username: str = typer.Option(..., "--username", "-u", help="Username (typically email)"),
    first_name: str = typer.Option(..., "--first-name", help="First name"),
    last_name: str = typer.Option(..., "--last-name", help="Last name"),
    email: Optional[str] = typer.Option(None, "--email", "-e", help="Email (defaults to username)"),
    groups: Optional[str] = typer.Option(None, "--groups", "-g", help="Comma-separated group IDs"),
    user_type: Optional[str] = typer.Option(None, "--user-type", "-t", help="User type (only 'consultant' can be set manually)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a new user (without password)."""
    client = ElizaClient(instance=instance)
    data = {
        "username": username,
        "first_name": first_name,
        "last_name": last_name,
        "email": email or username,
    }
    if groups:
        data["groups"] = [int(g.strip()) for g in groups.split(",")]
    if user_type:
        data["user_type"] = user_type
    user = client.post("user", data=data)
    console.print(f"[green]User created (ID: {user['id']})[/green]")
    format_output(user, fmt=fmt, columns=USER_COLUMNS)


@app.command("update")
def update_user(
    user_id: int = typer.Argument(help="User ID"),
    username: Optional[str] = typer.Option(None, "--username", "-u", help="Username (typically email)"),
    first_name: Optional[str] = typer.Option(None, "--first-name", help="First name"),
    last_name: Optional[str] = typer.Option(None, "--last-name", help="Last name"),
    email: Optional[str] = typer.Option(None, "--email", "-e", help="Email"),
    is_active: Optional[bool] = typer.Option(None, "--is-active", help="Active status"),
    user_type: Optional[str] = typer.Option(None, "--user-type", "-t", help="User type (only 'consultant' or null)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Update user fields."""
    client = ElizaClient(instance=instance)
    data = {}
    if username is not None:
        data["username"] = username
    if user_type is not None:
        data["user_type"] = user_type if user_type != "null" else None
    if first_name is not None:
        data["first_name"] = first_name
    if last_name is not None:
        data["last_name"] = last_name
    if email is not None:
        data["email"] = email
    if is_active is not None:
        data["is_active"] = is_active
    if not data:
        console.print("[yellow]No fields to update.[/yellow]")
        raise typer.Exit(1)
    user = client.patch(f"user/{user_id}", data=data)
    console.print(f"[green]User {user_id} updated.[/green]")
    format_output(user, fmt=fmt, columns=USER_COLUMNS)


@app.command("deactivate")
def deactivate_user(
    user_id: int = typer.Argument(help="User ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Deactivate a user."""
    client = ElizaClient(instance=instance)
    result = client.post(f"user/{user_id}/deactivate")
    console.print(f"[green]{result.get('detail', 'User deactivated.')}[/green]")


@app.command("activate")
def activate_user(
    user_id: int = typer.Argument(help="User ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Activate a user."""
    client = ElizaClient(instance=instance)
    result = client.post(f"user/{user_id}/activate")
    console.print(f"[green]{result.get('detail', 'User activated.')}[/green]")


@app.command("set-password")
def set_password(
    user_id: int = typer.Argument(help="User ID"),
    password: str = typer.Option(..., "--password", "-p", help="New password"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Set password for a user (admin only)."""
    client = ElizaClient(instance=instance)
    result = client.post(f"user/{user_id}/set_password", data={"password": password})
    console.print(f"[green]{result.get('detail', 'Password set.')}[/green]")


@app.command("invite")
def invite_user(
    user_id: int = typer.Argument(help="User ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Send invite email with password reset link."""
    client = ElizaClient(instance=instance)
    result = client.post(f"user/{user_id}/send_invite")
    console.print(f"[green]{result.get('detail', 'Invite sent.')}[/green]")


@app.command("groups")
def list_groups(
    search: Optional[str] = typer.Option(None, "--search", "-q", help="Filter by group name"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List groups (auth.Group)."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["name__icontains"] = search
    groups = client.get_paginated("group", params=params, limit=limit)
    format_output(groups, fmt=fmt, columns=GROUP_COLUMNS, title=f"Groups ({len(groups)})")
