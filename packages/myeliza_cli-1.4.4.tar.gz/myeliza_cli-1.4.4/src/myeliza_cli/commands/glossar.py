"""Glossar commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Glossar")
console = Console()

COLUMNS = ["id", "title", "description_clean"]
DETAIL_COLUMNS = ["id", "title", "description_clean"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _enrich(entry: dict) -> dict:
    entry["description_clean"] = _clean_html(entry.get("description", ""))
    return entry


@app.command("list")
def list_entries(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List glossary entries."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    entries = client.get_paginated("glossar/entry", params=params, limit=limit)
    entries = [_enrich(e) for e in entries]
    format_output(entries, fmt=fmt, columns=COLUMNS, title=f"Glossar ({len(entries)})")


@app.command("get")
def get_entry(
    entry_id: int = typer.Argument(help="Entry ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get glossary entry details."""
    client = ElizaClient(instance=instance)
    entry = client.get(f"glossar/entry/{entry_id}")
    entry = _enrich(entry)
    format_output(entry, fmt=fmt, columns=DETAIL_COLUMNS)


@app.command("create")
def create_entry(
    title: str = typer.Option(..., "--title"),
    description: str = typer.Option("", "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a glossary entry."""
    client = ElizaClient(instance=instance)
    result = client.post("glossar/entry", data={"title": title, "description": description})
    console.print(f"[green]✓[/green] Entry created: ID={result.get('id')} — {title}")


@app.command("update")
def update_entry(
    entry_id: int = typer.Argument(help="Entry ID"),
    title: Optional[str] = typer.Option(None, "--title"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a glossary entry."""
    client = ElizaClient(instance=instance)
    data = {}
    if title:
        data["title"] = title
    if description is not None:
        data["description"] = description
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"glossar/entry/{entry_id}", data=data)
    console.print(f"[green]✓[/green] Entry {entry_id} updated")


@app.command("delete")
def delete_entry(
    entry_id: int = typer.Argument(help="Entry ID"),
    confirm: bool = typer.Option(False, "--yes", "-y"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a glossary entry."""
    if not confirm:
        typer.confirm(f"Delete entry {entry_id}?", abort=True)
    client = ElizaClient(instance=instance)
    client.delete(f"glossar/entry/{entry_id}")
    console.print(f"[green]✓[/green] Entry {entry_id} deleted")
