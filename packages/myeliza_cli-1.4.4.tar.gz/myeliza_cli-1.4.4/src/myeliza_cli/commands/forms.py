"""Forms (Formulare) commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Forms / Formulare")
console = Console()

TEMPLATE_COLUMNS = ["id", "title", "description", "created_date"]
TEMPLATE_DETAIL = ["id", "title", "description", "created_date", "modified_date"]
FOLDER_COLUMNS = ["id", "title"]
SECTION_COLUMNS = ["id", "title", "position"]
QUESTION_COLUMNS = ["id", "text", "answer_type", "position", "section"]


@app.command("list")
def list_templates(
    folder: Optional[int] = typer.Option(None, "--folder", help="Folder ID"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List form templates."""
    client = ElizaClient(instance=instance)
    params = {}
    if folder:
        params["folder"] = folder
    templates = client.get_paginated("forms/template", params=params, limit=limit)
    format_output(templates, fmt=fmt, columns=TEMPLATE_COLUMNS, title=f"Templates ({len(templates)})")


@app.command("get")
def get_template(
    template_id: int = typer.Argument(help="Template ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get template details."""
    client = ElizaClient(instance=instance)
    template = client.get(f"forms/template/{template_id}")
    format_output(template, fmt=fmt, columns=TEMPLATE_DETAIL)


@app.command("full")
def get_template_full(
    template_id: int = typer.Argument(help="Template ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get full template with sections and questions."""
    client = ElizaClient(instance=instance)
    template = client.get(f"forms/template/{template_id}/full")
    format_output(template, fmt="json" if fmt == "json" else "json")


@app.command("create")
def create_template(
    title: str = typer.Option(..., "--title", "-t", help="Template title"),
    folder: Optional[int] = typer.Option(None, "--folder", help="Folder ID"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a form template."""
    client = ElizaClient(instance=instance)
    data: dict = {"title": title}
    if folder is not None:
        data["folder"] = folder
    if description is not None:
        data["description"] = description
    result = client.post("forms/template", data=data)
    console.print(f"[green]✓[/green] Template created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("delete")
def delete_template(
    template_id: int = typer.Argument(help="Template ID"),
    force: bool = typer.Option(False, "--force", help="Skip confirmation"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a form template."""
    if not force:
        confirm = typer.confirm(f"Delete template {template_id}?")
        if not confirm:
            raise typer.Abort()
    client = ElizaClient(instance=instance)
    client.delete(f"forms/template/{template_id}")
    console.print(f"[green]✓[/green] Template {template_id} deleted")


@app.command("folders")
def list_folders(
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List form folders."""
    client = ElizaClient(instance=instance)
    folders = client.get_paginated("forms/folder")
    format_output(folders, fmt=fmt, columns=FOLDER_COLUMNS, title="Folders")


@app.command("folder-create")
def create_folder(
    title: str = typer.Option(..., "--title", "-t", help="Folder title"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a form folder."""
    client = ElizaClient(instance=instance)
    result = client.post("forms/folder", data={"title": title})
    console.print(f"[green]✓[/green] Folder created: ID={result.get('id', '')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("sections")
def list_sections(
    template_id: int = typer.Argument(help="Template ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List sections for a template."""
    client = ElizaClient(instance=instance)
    sections = client.get_paginated("forms/section", params={"template": template_id})
    format_output(sections, fmt=fmt, columns=SECTION_COLUMNS, title="Sections")


@app.command("questions")
def list_questions(
    template_id: int = typer.Argument(help="Template ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List questions for a template."""
    client = ElizaClient(instance=instance)
    questions = client.get_paginated("forms/question", params={"template": template_id})
    format_output(questions, fmt=fmt, columns=QUESTION_COLUMNS, title="Questions")
