"""ContentType commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="ContentTypes (Django content type lookup)")
console = Console()

COLUMNS = ["id", "app_label", "model"]


@app.command("list")
def list_contenttypes(
    app_label: Optional[str] = typer.Option(None, "--app", "-a", help="Filter by app_label"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Filter by model name"),
    search: Optional[str] = typer.Option(None, "--search", "-q", help="Search app_label and model"),
    limit: int = typer.Option(200, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List content types. Useful for finding content_type IDs for GenericForeignKey relations."""
    client = ElizaClient(instance=instance)
    params = {}
    if app_label:
        params["app_label"] = app_label
    if model:
        params["model"] = model
    if search:
        params["search"] = search
    types = client.get_paginated("contenttype", params=params, limit=limit)
    format_output(types, fmt=fmt, columns=COLUMNS, title=f"Content Types ({len(types)})")


@app.command("get")
def get_contenttype(
    ct_id: int = typer.Argument(help="ContentType ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get a single content type by ID."""
    client = ElizaClient(instance=instance)
    ct = client.get(f"contenttype/{ct_id}")
    format_output(ct, fmt=fmt, columns=COLUMNS)


@app.command("lookup")
def lookup_contenttype(
    model_name: str = typer.Argument(help="Model name to look up (e.g. 'measure', 'issue', 'process')"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Look up content type ID by model name."""
    client = ElizaClient(instance=instance)
    types = client.get_paginated("contenttype", params={"model": model_name.lower()})
    if not types:
        console.print(f"[red]No content type found for model '{model_name}'[/red]")
        raise typer.Exit(1)
    format_output(types, fmt=fmt, columns=COLUMNS, title=f"Content Type for '{model_name}'")
