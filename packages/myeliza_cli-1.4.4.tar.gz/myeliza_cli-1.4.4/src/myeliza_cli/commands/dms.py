"""DMS (Document Management System) commands."""

import base64
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Document Management System")
console = Console()

DOC_COLUMNS = ["uuid_short", "doc_id", "title", "state_label", "type_name", "folder_name", "modified"]
DOC_DETAIL = [
    "uuid", "doc_id", "title", "description_clean", "state_label", "type_name",
    "folder_name", "author", "version", "file_url",
    "created", "modified", "approval_date", "valid_from", "valid_to", "next_review",
]
FOLDER_COLUMNS = ["uuid_short", "title", "parent_name", "doc_count"]
DOCTYPE_COLUMNS = ["id", "title", "description_clean"]

STATE_LABELS = {
    "1": "Entwurf", "2": "In Prüfung", "3": "Geprüft",
    "4": "Freigegeben", "5": "Veraltet", "6": "Archiviert",
}


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _enrich_doc(doc: dict) -> dict:
    doc["uuid_short"] = (doc.get("uuid") or "")[:8]
    doc["doc_id"] = doc.get("document_id") or doc.get("identifier") or ""
    doc["state_label"] = STATE_LABELS.get(str(doc.get("state", "")), str(doc.get("state", "")))
    doc["description_clean"] = _clean_html(doc.get("description", ""))

    dtype = doc.get("type") or {}
    doc["type_name"] = dtype.get("title", "") if isinstance(dtype, dict) else str(dtype)

    folder = doc.get("folder") or {}
    doc["folder_name"] = folder.get("title", "") if isinstance(folder, dict) else str(folder)

    author = doc.get("author") or {}
    if isinstance(author, dict):
        doc["author"] = f"{author.get('first_name', '')} {author.get('last_name', '')}".strip()

    doc["version"] = doc.get("revision_number", doc.get("version", ""))
    doc["file_url"] = doc.get("file", "") or ""
    doc["created"] = (doc.get("created_date") or doc.get("creation_date") or "")[:10]
    doc["modified"] = (doc.get("modified_date") or doc.get("modification_date") or "")[:10]
    doc["approval_date"] = (doc.get("approval_date") or "")[:10]
    doc["valid_from"] = (doc.get("valid_from") or "")[:10]
    doc["valid_to"] = (doc.get("valid_to") or "")[:10]
    doc["next_review"] = (doc.get("next_review") or "")[:10]
    return doc


def _enrich_folder(folder: dict) -> dict:
    folder["uuid_short"] = (folder.get("uuid") or "")[:8]
    parent = folder.get("parent") or {}
    folder["parent_name"] = parent.get("title", "") if isinstance(parent, dict) else str(parent or "")
    folder["doc_count"] = folder.get("document_count", "")
    return folder


# ── Documents ──────────────────────────────────────────────

@app.command("list")
def list_documents(
    folder_uuid: Optional[str] = typer.Option(None, "--folder", help="Folder UUID"),
    state: Optional[str] = typer.Option(None, "--state", "-s", help="State (1=Draft..6=Archived)"),
    type_id: Optional[int] = typer.Option(None, "--type", "-t", help="Document type ID"),
    search: Optional[str] = typer.Option(None, "--search", "-q", help="Search in title"),
    template: Optional[bool] = typer.Option(None, "--template", help="Filter templates"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List documents."""
    client = ElizaClient(instance=instance)
    params = {}
    if folder_uuid:
        params["folder_uuid"] = folder_uuid
    if state:
        params["state"] = state
    if type_id:
        params["type"] = type_id
    if search:
        params["search"] = search
    if template is not None:
        params["is_template"] = str(template).lower()

    docs = client.get_paginated("dms/document", params=params, limit=limit)
    docs = [_enrich_doc(d) for d in docs]
    format_output(docs, fmt=fmt, columns=DOC_COLUMNS, title=f"Documents ({len(docs)})")


@app.command("get")
def get_document(
    uuid: str = typer.Argument(help="Document UUID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get document details."""
    client = ElizaClient(instance=instance)
    doc = client.get(f"dms/document/{uuid}")
    doc = _enrich_doc(doc)
    format_output(doc, fmt=fmt, columns=DOC_DETAIL)


@app.command("create")
def create_document(
    title: str = typer.Option(..., "--title", help="Document title"),
    folder_uuid: Optional[str] = typer.Option(None, "--folder", help="Folder UUID"),
    type_id: Optional[int] = typer.Option(None, "--type", "-t", help="Document type ID"),
    description: str = typer.Option("", "--description", "-d"),
    doc_id: Optional[str] = typer.Option(None, "--doc-id", help="Document ID/number"),
    file: Optional[Path] = typer.Option(None, "--file", help="File to upload"),
    is_template: bool = typer.Option(False, "--template", help="Create as template"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a new document."""
    client = ElizaClient(instance=instance)

    if file and file.exists():
        # Multipart upload
        import mimetypes as mt
        mime = mt.guess_type(str(file))[0] or "application/octet-stream"
        data = {"title": title}
        if folder_uuid:
            data["folder"] = folder_uuid
        if type_id:
            data["type"] = str(type_id)
        if description:
            data["description"] = description
        if doc_id:
            data["document_id"] = doc_id
        if is_template:
            data["is_template"] = "true"

        files = {"file": (file.name, open(file, "rb"), mime)}
        r = client.session.post(client._url("dms/document"), data=data, files=files)
        r.raise_for_status()
        result = r.json()
    else:
        data = {"title": title}
        if folder_uuid:
            data["folder"] = folder_uuid
        if type_id:
            data["type"] = type_id
        if description:
            data["description"] = description
        if doc_id:
            data["document_id"] = doc_id
        if is_template:
            data["is_template"] = True
        result = client.post("dms/document", data=data)

    console.print(f"[green]✓[/green] Document created: {result.get('uuid', '?')} — {result.get('title', title)}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("update")
def update_document(
    uuid: str = typer.Argument(help="Document UUID"),
    title: Optional[str] = typer.Option(None, "--title"),
    state: Optional[str] = typer.Option(None, "--state", "-s"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    folder_uuid: Optional[str] = typer.Option(None, "--folder"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a document."""
    client = ElizaClient(instance=instance)
    data = {}
    if title:
        data["title"] = title
    if state:
        data["state"] = state
    if description is not None:
        data["description"] = description
    if folder_uuid:
        data["folder"] = folder_uuid
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"dms/document/{uuid}", data=data)
    console.print(f"[green]✓[/green] Document {uuid[:8]}… updated")


@app.command("delete")
def delete_document(
    uuid: str = typer.Argument(help="Document UUID"),
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a document."""
    if not confirm:
        typer.confirm(f"Delete document {uuid}?", abort=True)
    client = ElizaClient(instance=instance)
    client.delete(f"dms/document/{uuid}")
    console.print(f"[green]✓[/green] Document {uuid[:8]}… deleted")


# ── Folders ────────────────────────────────────────────────

@app.command("folders")
def list_folders(
    root: bool = typer.Option(False, "--root", help="Only root folders"),
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List folders."""
    client = ElizaClient(instance=instance)
    params = {}
    if root:
        params["parent__isnull"] = "true"
    if search:
        params["search"] = search
    folders = client.get_paginated("dms/folder", params=params, limit=limit)
    folders = [_enrich_folder(f) for f in folders]
    format_output(folders, fmt=fmt, columns=FOLDER_COLUMNS, title=f"Folders ({len(folders)})")


@app.command("folder-get")
def get_folder(
    uuid: str = typer.Argument(help="Folder UUID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get folder details."""
    client = ElizaClient(instance=instance)
    folder = client.get(f"dms/folder/{uuid}")
    folder = _enrich_folder(folder)
    format_output(folder, fmt=fmt, columns=["uuid", "title", "description", "parent_name"])


@app.command("folder-create")
def create_folder(
    title: str = typer.Option(..., "--title", help="Folder name"),
    parent_uuid: Optional[str] = typer.Option(None, "--parent", help="Parent folder UUID"),
    description: str = typer.Option("", "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a folder."""
    client = ElizaClient(instance=instance)
    data = {"title": title}
    if parent_uuid:
        data["parent"] = parent_uuid
    if description:
        data["description"] = description
    result = client.post("dms/folder", data=data)
    console.print(f"[green]✓[/green] Folder created: {result.get('uuid', '?')} — {title}")


@app.command("folder-delete")
def delete_folder(
    uuid: str = typer.Argument(help="Folder UUID"),
    confirm: bool = typer.Option(False, "--yes", "-y"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a folder."""
    if not confirm:
        typer.confirm(f"Delete folder {uuid}?", abort=True)
    client = ElizaClient(instance=instance)
    client.delete(f"dms/folder/{uuid}")
    console.print(f"[green]✓[/green] Folder {uuid[:8]}… deleted")


# ── Document Types ─────────────────────────────────────────

@app.command("types")
def list_doctypes(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List document types."""
    client = ElizaClient(instance=instance)
    types = client.get_paginated("dms/documenttype", limit=limit)
    for t in types:
        t["description_clean"] = _clean_html(t.get("description", ""))
    format_output(types, fmt=fmt, columns=DOCTYPE_COLUMNS, title=f"Document Types ({len(types)})")


@app.command("type-create")
def create_doctype(
    title: str = typer.Option(..., "--title"),
    description: str = typer.Option("", "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a document type."""
    client = ElizaClient(instance=instance)
    result = client.post("dms/documenttype", data={"title": title, "description": description})
    console.print(f"[green]✓[/green] Document type created: ID={result.get('id')} — {title}")


@app.command("type-delete")
def delete_doctype(
    type_id: int = typer.Argument(help="Document type ID"),
    confirm: bool = typer.Option(False, "--yes", "-y"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a document type."""
    if not confirm:
        typer.confirm(f"Delete document type {type_id}?", abort=True)
    client = ElizaClient(instance=instance)
    client.delete(f"dms/documenttype/{type_id}")
    console.print(f"[green]✓[/green] Document type {type_id} deleted")


# ── Export ─────────────────────────────────────────────────

_CSS_TEMPLATE = """
@page {{
    size: A4;
    margin: 2.5cm 2.5cm 2cm 2.5cm;
    @top-left {{ content: element(header); }}
    @bottom-center {{
        content: "{footer_text}";
        font-size: 8pt; color: #999;
        font-family: 'Helvetica Neue', Arial, sans-serif;
    }}
    @bottom-right {{
        content: "Seite " counter(page) " von " counter(pages);
        font-size: 8pt; color: #999;
        font-family: 'Helvetica Neue', Arial, sans-serif;
    }}
}}
@page :first {{ margin-top: 1.5cm; }}
body {{
    font-family: 'Helvetica Neue', Arial, sans-serif;
    font-size: 10.5pt; color: #333; line-height: 1.5;
}}
.header-logo {{
    position: running(header);
    padding-bottom: 8px;
    border-bottom: 2px solid {accent};
    margin-bottom: 12px;
}}
.header-logo img {{ height: 30px; }}
.cover {{
    text-align: center; padding-top: 4cm;
    page-break-after: always;
}}
.cover img {{ width: 8cm; margin-bottom: 2cm; }}
.cover h1 {{
    font-size: 28pt; color: {accent};
    margin-bottom: 0.5cm; font-weight: 700;
}}
.cover .subtitle {{ font-size: 14pt; color: #666; margin-bottom: 2cm; }}
.cover .meta {{ font-size: 11pt; color: #888; margin-top: 3cm; }}
h1 {{
    font-size: 18pt; color: {accent}; margin-top: 24pt; margin-bottom: 8pt;
    border-bottom: 1px solid #ddd; padding-bottom: 4pt;
}}
h2 {{ font-size: 14pt; color: {accent}; margin-top: 18pt; margin-bottom: 6pt; }}
h3 {{ font-size: 12pt; color: {accent_light}; margin-top: 14pt; margin-bottom: 4pt; }}
table {{ border-collapse: collapse; width: 100%; margin: 12pt 0; font-size: 9.5pt; }}
th {{
    background-color: {accent}; color: white;
    padding: 8pt 10pt; text-align: left; font-weight: 600;
}}
td {{ padding: 6pt 10pt; border-bottom: 1px solid #e0e0e0; }}
tr:nth-child(even) {{ background-color: #f8f9fa; }}
code {{ background: #f4f4f4; padding: 2pt 4pt; border-radius: 3pt; font-size: 9pt; }}
pre {{ background: #f4f4f4; padding: 12pt; border-radius: 4pt; font-size: 9pt; }}
ul, ol {{ margin: 6pt 0; padding-left: 20pt; }}
li {{ margin-bottom: 3pt; }}
hr {{ border: none; border-top: 1px solid #ddd; margin: 18pt 0; }}
strong {{ color: {accent}; }}
"""


def _find_tool(name: str) -> Optional[str]:
    """Find an external tool on PATH."""
    return shutil.which(name)


def _fetch_branding(client: ElizaClient) -> Optional[dict]:
    """Fetch branding info from the /api/branding/ endpoint (if available)."""
    try:
        return client.get("branding")
    except Exception:
        return None


def _fetch_instance_logo(client: ElizaClient) -> tuple[Optional[bytes], Optional[dict]]:
    """Auto-detect and download the instance logo.

    Tries in order:
    1. /api/branding/ endpoint (returns logo URL from Constance whitelabel config)
    2. /static/img/eliza-logo.png (fallback)
    3. /static/img/eliza-logo.svg (fallback)

    Returns (logo_bytes, branding_info).
    """
    base = client.base_url.rsplit("/api", 1)[0]  # e.g. https://eliza.myeliza.ch

    # Try branding API first
    branding = _fetch_branding(client)
    if branding:
        logo_url = branding.get("logo_docx_url") or branding.get("logo_url")
        if logo_url:
            try:
                r = client.session.get(logo_url)
                if r.status_code == 200 and len(r.content) > 100:
                    return r.content, branding
            except Exception:
                pass

    # Fallback: static paths
    for path in ["/static/img/eliza-logo.png", "/static/img/eliza-logo.svg"]:
        try:
            r = client.session.get(f"{base}{path}")
            if r.status_code == 200 and len(r.content) > 100:
                return r.content, branding
        except Exception:
            continue
    return None, branding


def _download_logo(client: ElizaClient, logo_arg: Optional[str]) -> tuple[Optional[bytes], Optional[dict]]:
    """Download logo from DMS UUID, URL, local file path, or auto-detect from instance.

    If logo_arg is None, tries to auto-detect the instance logo via /api/branding/.
    Returns (logo_bytes, branding_info).
    """
    if logo_arg is None:
        return _fetch_instance_logo(client)

    if logo_arg == "none":
        return None, _fetch_branding(client)

    branding = _fetch_branding(client)

    # Local file
    path = Path(logo_arg)
    if path.exists():
        return path.read_bytes(), branding

    # UUID (short or full) — fetch from DMS
    if re.match(r"^[0-9a-f-]{8,36}$", logo_arg):
        try:
            doc = client.get(f"dms/document/{logo_arg}")
            file_url = doc.get("file") or ""
            if file_url:
                r = client.session.get(file_url)
                r.raise_for_status()
                return r.content, branding
        except Exception:
            pass

    # URL
    if logo_arg.startswith("http"):
        try:
            r = client.session.get(logo_arg)
            r.raise_for_status()
            return r.content, branding
        except Exception:
            pass

    return None, branding


def _build_html(
    body_html: str,
    title: str,
    subtitle: str,
    logo_b64: Optional[str],
    footer_text: str,
    accent: str,
    accent_light: str,
    version: str,
    date: str,
    org_name: str,
    org_address: str,
) -> str:
    """Build a complete HTML document with cover page and branding."""
    css = _CSS_TEMPLATE.format(
        footer_text=footer_text,
        accent=accent,
        accent_light=accent_light,
    )

    logo_tag = ""
    cover_logo = ""
    if logo_b64:
        logo_tag = f'<img src="data:image/png;base64,{logo_b64}" alt="{org_name}">'
        cover_logo = f'<img src="data:image/png;base64,{logo_b64}" alt="{org_name}">'

    return f"""<!DOCTYPE html>
<html lang="de">
<head><meta charset="utf-8"><style>{css}</style></head>
<body>
<div class="header-logo">{logo_tag}</div>
<div class="cover">
    {cover_logo}
    <h1>{title}</h1>
    <div class="subtitle">{subtitle}</div>
    <div class="meta">
        <p><strong>{org_name}</strong></p>
        <p>{version} | {date}</p>
        <p>{org_address}</p>
    </div>
</div>
{body_html}
</body>
</html>"""


@app.command("export")
def export_document(
    uuid: str = typer.Argument(help="Document UUID (short or full)"),
    fmt: str = typer.Option("pdf", "--format", "-f", help="Output format: pdf or docx"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    logo: Optional[str] = typer.Option(None, "--logo", help="Logo: DMS UUID, URL, local file, or 'none'. Auto-detects instance logo if omitted."),
    title: Optional[str] = typer.Option(None, "--title", help="Override document title"),
    subtitle: Optional[str] = typer.Option(None, "--subtitle", help="Subtitle on cover page"),
    accent: str = typer.Option("#1a568e", "--accent", help="Accent color (hex)"),
    org_name: str = typer.Option("ELIZA AG", "--org", help="Organization name"),
    org_address: str = typer.Option("Dammweg 9, 3013 Bern", "--address", help="Organization address"),
    footer: Optional[str] = typer.Option(None, "--footer", help="Footer text"),
    upload: bool = typer.Option(False, "--upload", help="Upload generated file back to the DMS document"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Export a DMS document (Markdown description) as PDF or DOCX.

    Fetches the document description from ELIZA, renders it with professional
    branding (logo, cover page, styled tables), and saves as PDF or DOCX.

    Requires pandoc (for DOCX) or weasyprint (for PDF) to be installed.

    Examples:

        myeliza dms export b9b3feb8 -i elizaag

        myeliza dms export b9b3feb8 -i elizaag --logo f42a91d3 -f pdf -o sla.pdf

        myeliza dms export b9b3feb8 -i elizaag --upload
    """
    fmt = fmt.lower()
    if fmt not in ("pdf", "docx"):
        console.print("[red]Format must be 'pdf' or 'docx'[/red]")
        raise typer.Exit(1)

    # Check dependencies
    if fmt == "pdf" and not _find_tool("weasyprint"):
        pandoc = _find_tool("pandoc")
        if not pandoc:
            console.print("[red]PDF export requires weasyprint or pandoc. Install with: brew install weasyprint[/red]")
            raise typer.Exit(1)
    if fmt == "docx" and not _find_tool("pandoc"):
        console.print("[red]DOCX export requires pandoc. Install with: brew install pandoc[/red]")
        raise typer.Exit(1)

    client = ElizaClient(instance=instance)

    # Fetch document
    console.print(f"[dim]Fetching document {uuid[:8]}…[/dim]")
    doc = client.get(f"dms/document/{uuid}")
    description = doc.get("description", "")
    if not description:
        console.print("[red]Document has no description/content to export.[/red]")
        raise typer.Exit(1)

    doc_title = title or doc.get("title", "Dokument")
    doc_date = (doc.get("modification_date") or doc.get("creation_date") or "")[:10]
    doc_version = f"Version {doc.get('revision_number', '1.0')}" if doc.get("revision_number") else ""
    default_subtitle = f"{doc_title}" if not subtitle else subtitle
    footer_text = footer or f"{org_name} | {org_address}"

    # Determine output path
    safe_title = re.sub(r"[^\w\s-]", "", doc_title).strip().replace(" ", "_")
    if not output:
        output = Path(f"{safe_title}.{fmt}")

    # Download logo and branding info
    logo_bytes, branding = _download_logo(client, logo)
    logo_b64 = base64.b64encode(logo_bytes).decode() if logo_bytes else None

    if logo and logo != "none" and not logo_bytes:
        console.print(f"[yellow]⚠ Could not load logo from '{logo}', continuing without logo.[/yellow]")

    # Apply branding from instance if available (CLI flags take precedence)
    if branding:
        if accent == "#1a568e" and branding.get("heading_color"):
            accent = branding["heading_color"]
            console.print(f"[dim]Using instance accent color: {accent}[/dim]")

    accent_light = accent.replace("#1a", "#2c").replace("56", "7b").replace("8e", "b6") if accent == "#1a568e" else accent

    with tempfile.TemporaryDirectory() as tmpdir:
        md_path = Path(tmpdir) / "content.md"
        md_path.write_text(description, encoding="utf-8")

        if fmt == "pdf":
            # Markdown → HTML via pandoc, then styled HTML → PDF via weasyprint
            html_path = Path(tmpdir) / "document.html"

            # Convert markdown to HTML body
            pandoc = _find_tool("pandoc")
            if pandoc:
                result = subprocess.run(
                    [pandoc, str(md_path), "--from=markdown", "--to=html5"],
                    capture_output=True, text=True,
                )
                body_html = result.stdout
            else:
                # Fallback: use weasyprint with basic markdown (limited)
                body_html = f"<pre>{description}</pre>"

            full_html = _build_html(
                body_html=body_html,
                title=doc_title,
                subtitle=default_subtitle,
                logo_b64=logo_b64,
                footer_text=footer_text,
                accent=accent,
                accent_light=accent_light,
                version=doc_version,
                date=doc_date,
                org_name=org_name,
                org_address=org_address,
            )
            html_path.write_text(full_html, encoding="utf-8")

            # weasyprint HTML → PDF
            weasyprint = _find_tool("weasyprint")
            if weasyprint:
                result = subprocess.run(
                    [weasyprint, str(html_path), str(output)],
                    capture_output=True, text=True,
                )
                if result.returncode != 0:
                    console.print(f"[red]weasyprint error: {result.stderr}[/red]")
                    raise typer.Exit(1)
            else:
                # Fallback: pandoc → PDF
                result = subprocess.run(
                    [pandoc, str(md_path), "-o", str(output), "--pdf-engine=weasyprint"],
                    capture_output=True, text=True,
                )
                if result.returncode != 0:
                    console.print(f"[red]pandoc error: {result.stderr}[/red]")
                    raise typer.Exit(1)

        elif fmt == "docx":
            pandoc = _find_tool("pandoc")
            args = [pandoc, str(md_path), "--from=markdown", "--to=docx", "-o", str(output)]

            # If we have a logo, build a reference docx with branding
            if logo_bytes:
                ref_path = _build_reference_docx(tmpdir, logo_bytes, accent, org_name, footer_text)
                if ref_path:
                    args.extend(["--reference-doc", str(ref_path)])

            result = subprocess.run(args, capture_output=True, text=True)
            if result.returncode != 0:
                console.print(f"[red]pandoc error: {result.stderr}[/red]")
                raise typer.Exit(1)

    if not output.exists():
        console.print("[red]Export failed — output file not created.[/red]")
        raise typer.Exit(1)

    size_kb = output.stat().st_size / 1024
    console.print(f"[green]✓[/green] Exported: [bold]{output}[/bold] ({size_kb:.0f} KB)")

    # Upload back to DMS
    if upload:
        console.print(f"[dim]Uploading to DMS document {uuid[:8]}…[/dim]")
        import mimetypes as mt
        mime = mt.guess_type(str(output))[0] or "application/octet-stream"
        files = {"file": (output.name, open(output, "rb"), mime)}
        r = client.session.patch(client._url(f"dms/document/{uuid}"), files=files)
        r.raise_for_status()
        console.print(f"[green]✓[/green] Uploaded to DMS document {uuid[:8]}")


def _build_reference_docx(
    tmpdir: str, logo_bytes: bytes, accent: str, org_name: str, footer_text: str
) -> Optional[Path]:
    """Build a pandoc reference DOCX with logo header and branding."""
    try:
        from docx import Document
        from docx.shared import Pt, Cm, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from io import BytesIO
    except ImportError:
        console.print("[yellow]⚠ python-docx not installed, DOCX will have no branding.[/yellow]")
        return None

    doc = Document()

    # Page margins
    for section in doc.sections:
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)

    # Styles
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10.5)
    try:
        r, g, b = int(accent[1:3], 16), int(accent[3:5], 16), int(accent[5:7], 16)
    except (ValueError, IndexError):
        r, g, b = 0x1a, 0x56, 0x8e

    for level in range(1, 4):
        h = doc.styles[f"Heading {level}"]
        h.font.name = "Calibri"
        h.font.color.rgb = RGBColor(r, g, b)
        h.font.bold = True
        h.font.size = Pt([24, 16, 13][level - 1])

    # Header with logo
    header = doc.sections[0].header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = hp.add_run()
    run.add_picture(BytesIO(logo_bytes), width=Cm(4))

    # Footer
    ft = doc.sections[0].footer
    fp = ft.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run(footer_text)
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(0x99, 0x99, 0x99)

    doc.add_paragraph("")

    ref_path = Path(tmpdir) / "reference.docx"
    doc.save(str(ref_path))
    return ref_path
