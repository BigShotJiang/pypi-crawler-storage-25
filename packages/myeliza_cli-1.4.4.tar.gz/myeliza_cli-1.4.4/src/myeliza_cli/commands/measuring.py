"""Measuring tools (Prüfmittel) commands."""

from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Prüfmittel / Measuring Tools")
console = Console()

COLUMNS = ["id", "title", "serial_number", "type_name", "location", "last_inspection"]
DETAIL_COLUMNS = ["id", "title", "serial_number", "type_name", "inspection_interval", "last_inspection", "location"]


def _enrich(tool: dict) -> dict:
    t = tool.get("type") or {}
    tool["type_name"] = t.get("title", "") if isinstance(t, dict) else str(t or "")
    tool["last_inspection"] = (tool.get("last_inspection") or "")[:10]
    return tool


@app.command("list")
def list_tools(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List measuring tools."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    tools = client.get_paginated("measuringtool/measuringtool", params=params, limit=limit)
    tools = [_enrich(t) for t in tools]
    format_output(tools, fmt=fmt, columns=COLUMNS, title=f"Measuring Tools ({len(tools)})")


@app.command("get")
def get_tool(
    tool_id: int = typer.Argument(help="Tool ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get measuring tool details."""
    client = ElizaClient(instance=instance)
    tool = client.get(f"measuringtool/measuringtool/{tool_id}")
    tool = _enrich(tool)
    format_output(tool, fmt=fmt, columns=DETAIL_COLUMNS)


@app.command("create")
def create_tool(
    title: str = typer.Option(..., "--title"),
    serial_number: Optional[str] = typer.Option(None, "--serial-number"),
    type_id: Optional[int] = typer.Option(None, "--type", "-t", help="Type ID"),
    inspection_interval: Optional[int] = typer.Option(None, "--interval", help="Inspection interval (days)"),
    last_inspection: Optional[str] = typer.Option(None, "--last-inspection", help="YYYY-MM-DD"),
    location: Optional[str] = typer.Option(None, "--location"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a measuring tool."""
    client = ElizaClient(instance=instance)
    data = {"title": title}
    if serial_number:
        data["serial_number"] = serial_number
    if type_id:
        data["type"] = type_id
    if inspection_interval:
        data["inspection_interval"] = inspection_interval
    if last_inspection:
        data["last_inspection"] = last_inspection
    if location:
        data["location"] = location
    result = client.post("measuringtool/measuringtool", data=data)
    console.print(f"[green]✓[/green] Measuring tool created: ID={result.get('id')} — {title}")


@app.command("update")
def update_tool(
    tool_id: int = typer.Argument(help="Tool ID"),
    title: Optional[str] = typer.Option(None, "--title"),
    serial_number: Optional[str] = typer.Option(None, "--serial-number"),
    location: Optional[str] = typer.Option(None, "--location"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a measuring tool."""
    client = ElizaClient(instance=instance)
    data = {}
    if title:
        data["title"] = title
    if serial_number:
        data["serial_number"] = serial_number
    if location:
        data["location"] = location
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"measuringtool/measuringtool/{tool_id}", data=data)
    console.print(f"[green]✓[/green] Measuring tool {tool_id} updated")


@app.command("delete")
def delete_tool(
    tool_id: int = typer.Argument(help="Tool ID"),
    confirm: bool = typer.Option(False, "--yes", "-y"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a measuring tool."""
    if not confirm:
        typer.confirm(f"Delete measuring tool {tool_id}?", abort=True)
    client = ElizaClient(instance=instance)
    client.delete(f"measuringtool/measuringtool/{tool_id}")
    console.print(f"[green]✓[/green] Measuring tool {tool_id} deleted")
