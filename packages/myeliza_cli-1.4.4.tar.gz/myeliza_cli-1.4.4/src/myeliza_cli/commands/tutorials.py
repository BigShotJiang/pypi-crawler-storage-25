"""Tutorials / E-Learning commands."""

import re
from typing import Optional

import typer
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Tutorials / E-Learning")
console = Console()

FOLDER_COLUMNS = ["id", "title"]
COURSE_COLUMNS = ["id", "title", "folder_name", "description_clean"]
COURSE_DETAIL = ["id", "title", "description_clean", "folder_name"]
LESSON_COLUMNS = ["id", "title", "course_name"]
SECTION_COLUMNS = ["id", "title", "lesson_name"]


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _enrich_course(course: dict) -> dict:
    course["description_clean"] = _clean_html(course.get("description", ""))
    folder = course.get("folder") or {}
    course["folder_name"] = folder.get("title", "") if isinstance(folder, dict) else str(folder or "")
    return course


# ── Folders ───────────────────────────────────────────────

@app.command("folders")
def list_folders(
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List tutorial folders."""
    client = ElizaClient(instance=instance)
    folders = client.get_paginated("tutorial/folder", limit=limit)
    format_output(folders, fmt=fmt, columns=FOLDER_COLUMNS, title=f"Folders ({len(folders)})")


# ── Courses ───────────────────────────────────────────────

@app.command("courses")
def list_courses(
    search: Optional[str] = typer.Option(None, "--search", "-q"),
    folder: Optional[int] = typer.Option(None, "--folder"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List courses."""
    client = ElizaClient(instance=instance)
    params = {}
    if search:
        params["search"] = search
    if folder:
        params["folder"] = folder
    courses = client.get_paginated("tutorial/course", params=params, limit=limit)
    courses = [_enrich_course(c) for c in courses]
    format_output(courses, fmt=fmt, columns=COURSE_COLUMNS, title=f"Courses ({len(courses)})")


@app.command("course-get")
def get_course(
    course_id: int = typer.Argument(help="Course ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get course details."""
    client = ElizaClient(instance=instance)
    course = client.get(f"tutorial/course/{course_id}")
    course = _enrich_course(course)
    format_output(course, fmt=fmt, columns=COURSE_DETAIL)


@app.command("course-create")
def create_course(
    title: str = typer.Option(..., "--title"),
    description: str = typer.Option("", "--description", "-d"),
    folder: Optional[int] = typer.Option(None, "--folder", help="Folder ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a course."""
    client = ElizaClient(instance=instance)
    data = {"title": title}
    if description:
        data["description"] = description
    if folder:
        data["folder"] = folder
    result = client.post("tutorial/course", data=data)
    console.print(f"[green]✓[/green] Course created: ID={result.get('id')} — {title}")


# ── Lessons ───────────────────────────────────────────────

@app.command("lessons")
def list_lessons(
    course: Optional[int] = typer.Option(None, "--course", help="Course ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List lessons."""
    client = ElizaClient(instance=instance)
    params = {}
    if course:
        params["course"] = course
    lessons = client.get_paginated("tutorial/lesson", params=params, limit=limit)
    for les in lessons:
        c = les.get("course") or {}
        les["course_name"] = c.get("title", "") if isinstance(c, dict) else str(c or "")
    format_output(lessons, fmt=fmt, columns=LESSON_COLUMNS, title=f"Lessons ({len(lessons)})")


@app.command("lesson-get")
def get_lesson(
    lesson_id: int = typer.Argument(help="Lesson ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get lesson details."""
    client = ElizaClient(instance=instance)
    lesson = client.get(f"tutorial/lesson/{lesson_id}")
    c = lesson.get("course") or {}
    lesson["course_name"] = c.get("title", "") if isinstance(c, dict) else str(c or "")
    format_output(lesson, fmt=fmt, columns=LESSON_COLUMNS)


# ── Sections ──────────────────────────────────────────────

@app.command("sections")
def list_sections(
    lesson: Optional[int] = typer.Option(None, "--lesson", help="Lesson ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List sections."""
    client = ElizaClient(instance=instance)
    params = {}
    if lesson:
        params["lesson"] = lesson
    sections = client.get_paginated("tutorial/section", params=params, limit=limit)
    for s in sections:
        les = s.get("lesson") or {}
        s["lesson_name"] = les.get("title", "") if isinstance(les, dict) else str(les or "")
    format_output(sections, fmt=fmt, columns=SECTION_COLUMNS, title=f"Sections ({len(sections)})")
