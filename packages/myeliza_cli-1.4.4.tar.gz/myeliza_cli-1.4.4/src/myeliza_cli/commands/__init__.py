# ELIZA CLI commands
