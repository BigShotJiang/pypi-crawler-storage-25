"""Issues (Meldungen) commands."""

import re
from typing import Optional

import typer
from requests.exceptions import HTTPError
from rich.console import Console

from ..client import ElizaClient
from ..output import format_output

app = typer.Typer(help="Issues / Meldungen")
console = Console()

ISSUE_COLUMNS = ["serial_number", "state", "title", "contact_name", "created_date"]
ISSUE_DETAIL = [
    "id", "serial_number", "title", "state", "description_clean",
    "contact_firstname", "contact_lastname", "contact_email",
    "reference_number", "proposed_solution", "assigned_user",
    "created_date", "modified_date", "closed_date",
]
FOLLOWUP_COLUMNS = ["id", "user_name", "created_date", "comment_clean"]


def _clean_html(text: str) -> str:
    """Strip HTML tags and collapse whitespace."""
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:500]


def _resolve_issue_id(client: ElizaClient, issue_id: int, serial: bool, tracker: Optional[int] = None) -> int:
    """Resolve an issue identifier to an internal ID.

    If serial is True, looks up by serial_number directly.
    Otherwise tries the ID first, falls back to serial_number on 404.
    When tracker is given, filters serial_number lookup by tracker.
    """
    def _find_by_serial(sn: int, trk: Optional[int] = None) -> Optional[int]:
        """Search for issue by serial_number (client-side filter, API doesn't support it)."""
        params: dict = {}
        if trk:
            params["tracker"] = trk
        # Fetch enough issues to find the serial number
        results = client.get_paginated("issue/issue", params=params, limit=500)
        for r in results:
            if str(r.get("serial_number")) == str(sn):
                return r["id"]
        return None

    if serial:
        resolved = _find_by_serial(issue_id, tracker)
        if resolved is None:
            console.print(f"[red]Issue not found (serial_number={issue_id})[/red]")
            raise typer.Exit(1)
        return resolved

    # Try as internal ID first
    try:
        client.get(f"issue/issue/{issue_id}")
        return issue_id
    except HTTPError as e:
        if e.response is not None and e.response.status_code == 404:
            # Fallback: try as serial_number
            resolved = _find_by_serial(issue_id, tracker)
            if resolved is not None:
                return resolved
            console.print(f"[red]Issue not found (id={issue_id})[/red]")
            raise typer.Exit(1)
        raise


def _enrich_issue(issue: dict) -> dict:
    """Add computed fields for display."""
    issue["contact_name"] = (
        f"{issue.get('contact_firstname', '') or ''} {issue.get('contact_lastname', '') or ''}".strip()
    )
    issue["description_clean"] = _clean_html(issue.get("description", ""))
    issue["created_date"] = (issue.get("created_date") or "")[:10]
    issue["modified_date"] = (issue.get("modified_date") or "")[:10]
    issue["closed_date"] = (issue.get("closed_date") or "")[:10]
    return issue


@app.command("list")
def list_issues(
    tracker: Optional[int] = typer.Option(None, "--tracker", "-t", help="Tracker ID"),
    state: Optional[str] = typer.Option(None, "--state", "-s", help="Filter by state"),
    search: Optional[str] = typer.Option(None, "--search", "-q", help="Full-text search"),
    assigned: Optional[int] = typer.Option(None, "--assigned", help="Assigned user ID"),
    since: Optional[str] = typer.Option(None, "--since", help="Only issues modified since date (YYYY-MM-DD)"),
    created_since: Optional[str] = typer.Option(None, "--created-since", help="Only issues created since date (YYYY-MM-DD)"),
    ordering: Optional[str] = typer.Option(None, "--ordering", "-o", help="Sort order (e.g. -modified_date, serial_number)"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List issues."""
    client = ElizaClient(instance=instance)
    params = {}
    if tracker:
        params["tracker"] = tracker
    if state:
        params["state"] = state
    if assigned:
        params["assigned_user"] = assigned
    if since:
        params["modified_date__gte"] = since
    if created_since:
        params["created_date__gte"] = created_since
    if ordering:
        params["ordering"] = ordering
    # Note: search param doesn't work well in ELIZA API, but we pass it anyway
    if search:
        params["search"] = search

    issues = client.get_paginated("issue/issue", params=params, limit=limit)
    issues = [_enrich_issue(i) for i in issues]
    format_output(issues, fmt=fmt, columns=ISSUE_COLUMNS, title=f"Issues ({len(issues)})")


@app.command("get")
def get_issue(
    issue_id: int = typer.Argument(help="Issue ID or serial number"),
    serial: bool = typer.Option(False, "--serial", "-s", help="Lookup by serial number"),
    tracker: Optional[int] = typer.Option(None, "--tracker", "-t", help="Tracker ID (useful with --serial to disambiguate)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get issue details."""
    client = ElizaClient(instance=instance)
    resolved_id = _resolve_issue_id(client, issue_id, serial, tracker)
    issue = client.get(f"issue/issue/{resolved_id}")
    issue = _enrich_issue(issue)
    format_output(issue, fmt=fmt, columns=ISSUE_DETAIL)


@app.command("create")
def create_issue(
    tracker: int = typer.Option(..., "--tracker", "-t", help="Tracker ID"),
    title: str = typer.Option(..., "--title", help="Issue title"),
    description: str = typer.Option("", "--description", "-d", help="Description (HTML)"),
    contact_firstname: Optional[str] = typer.Option(None, "--contact-firstname"),
    contact_lastname: Optional[str] = typer.Option(None, "--contact-lastname"),
    contact_email: Optional[str] = typer.Option(None, "--contact-email"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Create a new issue."""
    client = ElizaClient(instance=instance)
    data = {
        "tracker_id": tracker,
        "title": title,
        "description": description,
    }
    if contact_firstname:
        data["contact_firstname"] = contact_firstname
    if contact_lastname:
        data["contact_lastname"] = contact_lastname
    if contact_email:
        data["contact_email"] = contact_email

    result = client.post("issue/issue", data=data)
    console.print(f"[green]✓[/green] Issue created: ID={result['id']}, SN={result.get('serial_number', '?')}")
    if fmt == "json":
        format_output(result, fmt="json")


@app.command("update")
def update_issue(
    issue_id: int = typer.Argument(help="Issue ID"),
    state: Optional[str] = typer.Option(None, "--state", "-s"),
    title: Optional[str] = typer.Option(None, "--title"),
    assigned_user: Optional[int] = typer.Option(None, "--assign", help="Assign to user ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update an issue."""
    client = ElizaClient(instance=instance)
    data = {}
    if state:
        data["state"] = state
    if title:
        data["title"] = title
    if assigned_user:
        data["assigned_user"] = assigned_user
    if not data:
        console.print("[yellow]Nothing to update.[/yellow]")
        raise typer.Exit(0)

    result = client.patch(f"issue/issue/{issue_id}", data=data)
    console.print(f"[green]✓[/green] Issue {issue_id} updated")


@app.command("followups")
def list_followups(
    issue_id: int = typer.Argument(help="Issue ID or serial number"),
    serial: bool = typer.Option(False, "--serial", "-s", help="Lookup by serial number"),
    tracker: Optional[int] = typer.Option(None, "--tracker", "-t", help="Tracker ID (useful with --serial to disambiguate)"),
    since: Optional[str] = typer.Option(None, "--since", help="Only followups created since date (YYYY-MM-DD)"),
    ordering: Optional[str] = typer.Option(None, "--ordering", "-o", help="Sort order (e.g. -created_date)"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List followups for an issue."""
    client = ElizaClient(instance=instance)
    resolved_id = _resolve_issue_id(client, issue_id, serial, tracker)
    followups = client.get(f"issue/issue/{resolved_id}/followup")
    if isinstance(followups, dict):
        followups = followups.get("results", [])
    # Client-side filtering (followup action doesn't support query params)
    if since:
        followups = [f for f in followups if (f.get("created_date") or "") >= since]
    if ordering:
        reverse = ordering.startswith("-")
        field = ordering.lstrip("-")
        followups = sorted(followups, key=lambda f: f.get(field) or "", reverse=reverse)
    followups = followups[:limit]

    for f in followups:
        user = f.get("user", {}) or {}
        f["user_name"] = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip()
        f["comment_clean"] = _clean_html(f.get("comment", ""))
        f["created_date"] = (f.get("created_date") or "")[:16]

    format_output(followups, fmt=fmt, columns=FOLLOWUP_COLUMNS, title="Followups")


@app.command("followup-add")
def add_followup(
    issue_id: int = typer.Argument(help="Issue ID"),
    comment: str = typer.Option(..., "--comment", "-c", help="Followup comment"),
    files: Optional[list[str]] = typer.Option(None, "--file", "-f", help="Datei(en) anhängen (Pfad, mehrfach verwendbar)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Add a followup to an issue. Optionally attach files with --file."""
    import requests as _requests
    client = ElizaClient(instance=instance)
    result = client.post(f"issue/issue/{issue_id}/followup", data={"comment": comment})
    comment_id = result.get("id")
    console.print(f"[green]✓[/green] Followup added to issue {issue_id}")

    if files and comment_id:
        for file_path in files:
            import os
            if not os.path.exists(file_path):
                console.print(f"[yellow]⚠[/yellow] Datei nicht gefunden: {file_path}")
                continue
            url = client._url(f"issue/followup/{comment_id}/upload")
            with open(file_path, "rb") as fp:
                r = _requests.post(
                    url,
                    headers={"Authorization": f"Token {client.session.headers['Authorization'].split(' ')[1]}"},
                    files={"file": (os.path.basename(file_path), fp)},
                )
            if r.status_code in (200, 201):
                console.print(f"[green]✓[/green] Datei angehängt: {os.path.basename(file_path)}")
            else:
                console.print(f"[red]✗[/red] Upload fehlgeschlagen: {r.status_code} {r.text[:100]}")


@app.command("trackers")
def list_trackers(
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List all trackers (Meldekreise)."""
    client = ElizaClient(instance=instance)
    trackers = client.get_paginated("issue/tracker")
    format_output(
        trackers, fmt=fmt,
        columns=["id", "title", "state"],
        title="Trackers",
    )


# ---------------------------------------------------------------------------
# Knowledge Base (Wissensartikel)
# ---------------------------------------------------------------------------

KB_COLUMNS = ["uuid", "question_short", "status", "tracker_title", "issues_count"]
KB_DETAIL = ["uuid", "tracker_title", "question", "answer", "status", "related_issues"]


def _clean_text(text: str, max_len: int = 60) -> str:
    """Strip HTML and truncate."""
    import re
    text = re.sub(r"<[^>]+>", "", text or "")
    return text[:max_len] + "…" if len(text) > max_len else text


@app.command("kb-list")
def kb_list(
    tracker: Optional[int] = typer.Option(None, "--tracker", "-t", help="Tracker ID"),
    search: Optional[str] = typer.Option(None, "--search", "-q", help="Volltext-Suche (Frage + Antwort)"),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Status: draft|verification|reviewed|approved"),
    limit: int = typer.Option(20, "--limit", "-l"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List knowledge base articles."""
    client = ElizaClient(instance=instance)
    params = {}
    if tracker:
        params["tracker"] = tracker
    if search:
        params["search"] = search
    if status:
        params["status"] = status
    articles = client.get_paginated("issue/kbarticle", params=params)[:limit]
    for a in articles:
        a["question_short"] = _clean_text(a.get("question", ""), 60)
        a["tracker_title"] = (a.get("tracker") or {}).get("title", "—")
        a["issues_count"] = len(a.get("related_issues") or [])
    format_output(articles, fmt=fmt, columns=KB_COLUMNS, title=f"Knowledge Base ({len(articles)})")


@app.command("kb-get")
def kb_get(
    uuid: str = typer.Argument(help="UUID des Wissensartikels"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get a knowledge base article."""
    client = ElizaClient(instance=instance)
    a = client.get(f"issue/kbarticle/{uuid}")
    a["question_short"] = _clean_text(a.get("question", ""), 80)
    a["tracker_title"] = (a.get("tracker") or {}).get("title", "—")
    a["issues_count"] = len(a.get("related_issues") or [])
    format_output([a], fmt=fmt, columns=KB_DETAIL, title="Knowledge Base Article")


@app.command("kb-create")
def kb_create(
    tracker_id: int = typer.Option(..., "--tracker", "-t", help="Tracker ID"),
    question: str = typer.Option(..., "--question", "-q", help="Frage"),
    answer: str = typer.Option(..., "--answer", "-a", help="Antwort (Markdown)"),
    issue_ids: Optional[str] = typer.Option(None, "--issues", help="Kommagetrennte Issue-IDs zuordnen (z.B. 123,456)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a knowledge base article."""
    client = ElizaClient(instance=instance)
    data: dict = {
        "tracker_id": tracker_id,
        "question": question,
        "answer": answer,
    }
    if issue_ids:
        data["related_issues"] = [int(x.strip()) for x in issue_ids.split(",") if x.strip()]
    result = client.post("issue/kbarticle", data=data)
    console.print(f"[green]✓[/green] Wissensartikel erstellt: {result.get('uuid')}")
    if fmt := "table":
        result["question_short"] = _clean_text(result.get("question", ""), 60)
        result["tracker_title"] = (result.get("tracker") or {}).get("title", "—")
        result["issues_count"] = len(result.get("related_issues") or [])
        format_output([result], fmt="table", columns=KB_COLUMNS, title="Erstellt")


@app.command("kb-update")
def kb_update(
    uuid: str = typer.Argument(help="UUID des Wissensartikels"),
    question: Optional[str] = typer.Option(None, "--question", "-q"),
    answer: Optional[str] = typer.Option(None, "--answer", "-a"),
    issue_ids: Optional[str] = typer.Option(None, "--issues", help="Kommagetrennte Issue-IDs (überschreibt bestehende)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a knowledge base article."""
    client = ElizaClient(instance=instance)
    data: dict = {}
    if question:
        data["question"] = question
    if answer:
        data["answer"] = answer
    if issue_ids is not None:
        data["related_issues"] = [int(x.strip()) for x in issue_ids.split(",") if x.strip()]
    if not data:
        console.print("[yellow]Nichts zu aktualisieren.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"issue/kbarticle/{uuid}", data=data)
    console.print(f"[green]✓[/green] Wissensartikel {uuid[:8]}… aktualisiert")


@app.command("kb-delete")
def kb_delete(
    uuid: str = typer.Argument(help="UUID des Wissensartikels"),
    confirm: bool = typer.Option(False, "--yes", "-y", help="Ohne Bestätigung löschen"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a knowledge base article."""
    client = ElizaClient(instance=instance)
    if not confirm:
        typer.confirm(f"Wissensartikel {uuid[:8]}… wirklich löschen?", abort=True)
    client.delete(f"issue/kbarticle/{uuid}")
    console.print(f"[green]✓[/green] Wissensartikel {uuid[:8]}… gelöscht")


@app.command("kb-link")
def kb_link(
    uuid: str = typer.Argument(help="UUID des Wissensartikels"),
    issue_id: int = typer.Argument(help="Issue ID zuordnen"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Link an issue to a knowledge base article."""
    client = ElizaClient(instance=instance)
    # Bestehende Issues holen, neue hinzufügen
    article = client.get(f"issue/kbarticle/{uuid}")
    existing = list(article.get("related_issues") or [])
    if issue_id in existing:
        console.print(f"[yellow]Issue {issue_id} ist bereits verknüpft.[/yellow]")
        raise typer.Exit(0)
    existing.append(issue_id)
    client.patch(f"issue/kbarticle/{uuid}", data={"related_issues": existing})
    console.print(f"[green]✓[/green] Issue {issue_id} mit Wissensartikel verknüpft")


@app.command("tracker-create")
def create_tracker(
    title: str = typer.Option(..., "--title", "-t", help="Tracker-Titel"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a new tracker (Meldekreis)."""
    client = ElizaClient(instance=instance)
    data: dict = {"title": title, "state": "approved"}
    if description:
        data["description"] = description
    result = client.post("issue/tracker", data=data)
    console.print(f"[green]✓[/green] Tracker created: ID={result.get('id')} — {result.get('title')}")


@app.command("tracker-get")
def get_tracker(
    tracker_id: int = typer.Argument(help="Tracker ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get tracker details."""
    client = ElizaClient(instance=instance)
    result = client.get(f"issue/tracker/{tracker_id}")
    format_output([result], fmt=fmt, columns=["id", "title", "description", "state"], title="Tracker")


@app.command("tracker-update")
def update_tracker(
    tracker_id: int = typer.Argument(help="Tracker ID"),
    title: Optional[str] = typer.Option(None, "--title", "-t"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    state: Optional[str] = typer.Option(None, "--state", "-s", help="approved|draft|archived"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a tracker."""
    client = ElizaClient(instance=instance)
    data: dict = {}
    if title:
        data["title"] = title
    if description:
        data["description"] = description
    if state:
        data["state"] = state
    if not data:
        console.print("[yellow]Nichts zu aktualisieren.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"issue/tracker/{tracker_id}", data=data)
    console.print(f"[green]✓[/green] Tracker {tracker_id} aktualisiert")


@app.command("tracker-delete")
def delete_tracker(
    tracker_id: int = typer.Argument(help="Tracker ID"),
    confirm: bool = typer.Option(False, "--yes", "-y", help="Ohne Bestätigung löschen"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a tracker."""
    client = ElizaClient(instance=instance)
    if not confirm:
        typer.confirm(f"Tracker {tracker_id} wirklich löschen?", abort=True)
    client.delete(f"issue/tracker/{tracker_id}")
    console.print(f"[green]✓[/green] Tracker {tracker_id} gelöscht")


# ---------------------------------------------------------------------------
# Tracker-Kategorien (Labels)
# ---------------------------------------------------------------------------

@app.command("categories")
def list_categories(
    tracker: Optional[int] = typer.Option(None, "--tracker", "-t", help="Tracker ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """List issue categories (labels) for a tracker."""
    client = ElizaClient(instance=instance)
    params = {}
    if tracker:
        params["tracker"] = tracker
    cats = client.get_paginated("issue/category", params=params)
    format_output(cats, fmt=fmt, columns=["id", "title", "color", "tracker"], title=f"Categories ({len(cats)})")


@app.command("category-get")
def get_category(
    category_id: int = typer.Argument(help="Category ID"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
    fmt: str = typer.Option("table", "--format", "-f"),
):
    """Get category details."""
    client = ElizaClient(instance=instance)
    result = client.get(f"issue/category/{category_id}")
    format_output([result], fmt=fmt, columns=["id", "title", "color", "tracker"], title="Category")


@app.command("category-create")
def create_category(
    tracker_id: int = typer.Option(..., "--tracker", "-t", help="Tracker ID"),
    title: str = typer.Option(..., "--title", help="Kategorie-Titel"),
    color: Optional[str] = typer.Option(None, "--color", help="Farbe (z.B. #ff0000 oder red)"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Create a category (label) for a tracker."""
    client = ElizaClient(instance=instance)
    data: dict = {"tracker_id": tracker_id, "title": title}
    if color:
        data["color"] = color
    result = client.post("issue/category", data=data)
    console.print(f"[green]✓[/green] Category created: ID={result.get('id')} — {result.get('title')}")


@app.command("category-update")
def update_category(
    category_id: int = typer.Argument(help="Category ID"),
    title: Optional[str] = typer.Option(None, "--title"),
    color: Optional[str] = typer.Option(None, "--color"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Update a category."""
    client = ElizaClient(instance=instance)
    data: dict = {}
    if title:
        data["title"] = title
    if color:
        data["color"] = color
    if not data:
        console.print("[yellow]Nichts zu aktualisieren.[/yellow]")
        raise typer.Exit(0)
    client.patch(f"issue/category/{category_id}", data=data)
    console.print(f"[green]✓[/green] Category {category_id} aktualisiert")


@app.command("category-delete")
def delete_category(
    category_id: int = typer.Argument(help="Category ID"),
    confirm: bool = typer.Option(False, "--yes", "-y"),
    instance: Optional[str] = typer.Option(None, "--instance", "-i"),
):
    """Delete a category."""
    client = ElizaClient(instance=instance)
    if not confirm:
        typer.confirm(f"Kategorie {category_id} wirklich löschen?", abort=True)
    client.delete(f"issue/category/{category_id}")
    console.print(f"[green]✓[/green] Kategorie {category_id} gelöscht")
