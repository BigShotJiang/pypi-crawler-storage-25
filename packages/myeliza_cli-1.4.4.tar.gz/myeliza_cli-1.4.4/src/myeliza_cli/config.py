"""Configuration management for ELIZA CLI.

Supports:
- Config file: ~/.myeliza/config.yaml (fallback: ~/.eliza/config.yaml)
- Environment variables: ELIZA_{NAME}_URL + ELIZA_{NAME}_TOKEN (backward compat)
"""

import os
from pathlib import Path
from typing import Optional

import yaml

def _resolve_config_dir() -> Path:
    """Resolve config directory.

    Resolution order:
    1. ELIZA_CONFIG_DIR environment variable
    2. .myeliza/ in current working directory (if exists)
    3. .eliza/ in current working directory (if exists, backward compat)
    4. ~/.myeliza/ (if exists or ~/.eliza/ does not exist)
    5. ~/.eliza/ (backward compat fallback)
    """
    env_dir = os.environ.get("ELIZA_CONFIG_DIR")
    if env_dir:
        return Path(env_dir)
    local_dir = Path.cwd() / ".myeliza"
    if local_dir.exists():
        return local_dir
    local_dir_legacy = Path.cwd() / ".eliza"
    if local_dir_legacy.exists():
        return local_dir_legacy
    new_home = Path.home() / ".myeliza"
    legacy_home = Path.home() / ".eliza"
    if new_home.exists():
        return new_home
    if legacy_home.exists():
        return legacy_home
    return new_home


CONFIG_DIR = _resolve_config_dir()
CONFIG_FILE = CONFIG_DIR / "config.yaml"


def _load_config() -> dict:
    """Load config from config.yaml."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return yaml.safe_load(f) or {}
    return {}


def _save_config(config: dict) -> None:
    """Save config to config.yaml."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)


def get_instance(name: Optional[str] = None) -> dict:
    """Get instance config (url + token) by name.

    Resolution order:
    1. Explicit name parameter
    2. ELIZA_DEFAULT env var
    3. 'default' key in config.yaml
    4. First instance in config

    Returns dict with 'url' and 'token' keys.
    """
    config = _load_config()
    instances = config.get("instances", {})

    # Resolve instance name
    if not name:
        name = os.environ.get("ELIZA_DEFAULT") or config.get("default")

    if not name and instances:
        name = next(iter(instances))

    if not name:
        # Try legacy env vars
        url = os.environ.get("ELIZA_API_URL")
        token = os.environ.get("ELIZA_API_TOKEN")
        if url and token:
            return {"url": _ensure_api_url(url), "token": token, "name": "default"}
        raise ValueError(
            "No ELIZA instance configured. Run 'myeliza auth login' or set environment variables."
        )

    # Try config file first
    if name in instances:
        inst = instances[name]
        return {
            "url": _ensure_api_url(inst["url"]),
            "token": inst["token"],
            "name": name,
        }

    # Try env vars: ELIZA_{NAME}_URL + ELIZA_{NAME}_TOKEN
    env_name = name.upper()
    url = os.environ.get(f"ELIZA_{env_name}_URL")
    token = os.environ.get(f"ELIZA_{env_name}_TOKEN")
    if url and token:
        return {"url": _ensure_api_url(url), "token": token, "name": name}

    raise ValueError(
        f"Instance '{name}' not found. Run 'myeliza auth login --instance {name}' to configure."
    )


def list_instances() -> list[dict]:
    """List all configured instances."""
    config = _load_config()
    instances = config.get("instances", {})
    default = config.get("default", "")
    result = []
    for name, inst in instances.items():
        result.append({
            "name": name,
            "url": inst["url"],
            "default": name == default,
        })
    return result


def _ensure_api_url(url: str) -> str:
    """Ensure URL ends with /api for API requests."""
    url = url.rstrip("/")
    if not url.endswith("/api"):
        url = url + "/api"
    return url


def _strip_api_suffix(url: str) -> str:
    """Strip /api suffix from URL for clean storage.

    Stores only the base URL in config; /api is appended at request time.

    Accepts:
      https://kunde.myeliza.ch/api/   → https://kunde.myeliza.ch
      https://kunde.myeliza.ch/api    → https://kunde.myeliza.ch
      https://kunde.myeliza.ch/       → https://kunde.myeliza.ch
      https://kunde.myeliza.ch        → https://kunde.myeliza.ch
    """
    url = url.rstrip("/")
    if url.endswith("/api"):
        url = url[:-4]
    return url


def add_instance(name: str, url: str, token: str, set_default: bool = False) -> None:
    """Add or update an instance in config."""
    config = _load_config()
    if "instances" not in config:
        config["instances"] = {}
    config["instances"][name] = {"url": _strip_api_suffix(url), "token": token}
    if set_default or not config.get("default"):
        config["default"] = name
    _save_config(config)


def remove_instance(name: str) -> None:
    """Remove an instance from config."""
    config = _load_config()
    instances = config.get("instances", {})
    if name in instances:
        del instances[name]
        if config.get("default") == name:
            config["default"] = next(iter(instances), "")
        _save_config(config)
