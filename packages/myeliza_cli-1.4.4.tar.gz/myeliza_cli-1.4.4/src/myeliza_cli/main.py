"""ELIZA CLI — Command-line interface for the ELIZA platform."""

import asyncio
from typing import Optional

import typer

from . import __version__, client
from .commands import (
    auth, bot, businesscontext, contenttypes, contracts, dms, dsg, forms,
    glossar, ims, issues, kpi, measuring, okr, organisation, processes,
    projects, resources, spaces, standards, streams, swot, time, tutorials, users,
)


def _main_callback(
    dry_run: bool = typer.Option(False, "--dry-run", help="Show HTTP request without executing it"),
):
    if dry_run:
        client._dry_run = True


app = typer.Typer(
    name="myeliza",
    help="ELIZA CLI — Command-line interface for the ELIZA platform.\n\nAI agents: Run 'myeliza skills-path' to find bundled skill documentation with API details, examples and scripts.",
    no_args_is_help=True,
    callback=_main_callback,
)

mcp_app = typer.Typer(help="MCP (Model Context Protocol) server for AI agents")

# Core commands
app.add_typer(auth.app, name="auth")
app.add_typer(issues.app, name="issues")
app.add_typer(users.app, name="users")
app.add_typer(contenttypes.app, name="contenttypes")
app.add_typer(time.app, name="time")
app.add_typer(mcp_app, name="mcp")
app.add_typer(dms.app, name="dms")
app.add_typer(streams.app, name="streams")
app.add_typer(kpi.app, name="kpi")

# Module commands
app.add_typer(processes.app, name="processes")
app.add_typer(spaces.app, name="spaces")
app.add_typer(forms.app, name="forms")
app.add_typer(standards.app, name="standards")
app.add_typer(glossar.app, name="glossar")
app.add_typer(organisation.app, name="organisation")
app.add_typer(contracts.app, name="contracts")
app.add_typer(projects.app, name="projects")
app.add_typer(tutorials.app, name="tutorials")
app.add_typer(okr.app, name="okr")
app.add_typer(swot.app, name="swot")
app.add_typer(dsg.app, name="dsg")
app.add_typer(bot.app, name="bot")
app.add_typer(measuring.app, name="measuring")
app.add_typer(resources.app, name="resources")
app.add_typer(businesscontext.app, name="businesscontext")
app.add_typer(ims.app, name="ims")


@app.command()
def version():
    """Show CLI version."""
    typer.echo(f"myeliza-cli {__version__}")


@app.command()
def skills_path():
    """Show path to bundled skills directory (for AI agents)."""
    from pathlib import Path
    skills_dir = Path(__file__).parent / "skills"
    if skills_dir.exists():
        typer.echo(str(skills_dir))
    else:
        typer.echo("Skills not found. Reinstall with: pip install myeliza-cli", err=True)
        raise typer.Exit(1)


@mcp_app.command("serve")
def mcp_serve():
    """Start MCP server over stdio (for Claude Code, OpenClaw, etc.)."""
    from .mcp_server import run_stdio
    asyncio.run(run_stdio())


if __name__ == "__main__":
    app()
