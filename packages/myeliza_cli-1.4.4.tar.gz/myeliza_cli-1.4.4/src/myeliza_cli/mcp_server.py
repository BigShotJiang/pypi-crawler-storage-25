"""ELIZA MCP Server — Model Context Protocol server for AI agent integration.

Usage:
    myeliza mcp serve              # stdio transport (for Claude Code, OpenClaw)
    myeliza mcp serve --http 8080  # HTTP transport (for remote agents)
"""

import json
import re
from typing import Any, Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .client import ElizaClient

server = Server("eliza")


def _clean_html(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"data:image/[^\"')]+", "[BASE64_IMG]", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _compact_issue(issue: dict) -> dict:
    """Flatten issue for LLM consumption."""
    assigned = issue.get("assigned_user") or {}
    return {
        "id": issue.get("id"),
        "serial_number": issue.get("serial_number"),
        "title": issue.get("title", ""),
        "state": issue.get("state", ""),
        "contact": f"{issue.get('contact_firstname', '') or ''} {issue.get('contact_lastname', '') or ''}".strip(),
        "contact_email": issue.get("contact_email", ""),
        "description": _clean_html(issue.get("description", ""))[:1000],
        "proposed_solution": _clean_html(issue.get("proposed_solution", ""))[:500],
        "assigned_to": f"{assigned.get('first_name', '')} {assigned.get('last_name', '')}".strip() if assigned else "",
        "reference": issue.get("reference_number", ""),
        "created": (issue.get("created_date") or "")[:10],
        "modified": (issue.get("modified_date") or "")[:10],
    }


def _compact_followup(f: dict) -> dict:
    user = f.get("user", {}) or {}
    return {
        "id": f.get("id"),
        "user": f"{user.get('first_name', '')} {user.get('last_name', '')}".strip(),
        "date": (f.get("created_date") or "")[:16],
        "comment": _clean_html(f.get("comment", ""))[:1000],
    }


def _compact_document(doc: dict) -> dict:
    """Flatten document for LLM consumption."""
    dtype = doc.get("type") or {}
    folder = doc.get("folder") or {}
    author = doc.get("author") or {}
    state_labels = {"1": "Entwurf", "2": "In Prüfung", "3": "Geprüft", "4": "Freigegeben", "5": "Veraltet", "6": "Archiviert"}
    return {
        "uuid": doc.get("uuid", ""),
        "document_id": doc.get("document_id", ""),
        "title": doc.get("title", ""),
        "state": state_labels.get(str(doc.get("state", "")), str(doc.get("state", ""))),
        "type": dtype.get("title", "") if isinstance(dtype, dict) else str(dtype),
        "folder": folder.get("title", "") if isinstance(folder, dict) else str(folder),
        "author": f"{author.get('first_name', '')} {author.get('last_name', '')}".strip() if isinstance(author, dict) else str(author),
        "version": doc.get("revision_number", ""),
        "description": _clean_html(doc.get("description", ""))[:500],
        "created": (doc.get("created_date") or doc.get("creation_date") or "")[:10],
        "modified": (doc.get("modified_date") or doc.get("modification_date") or "")[:10],
        "approval_date": (doc.get("approval_date") or "")[:10],
    }


def _compact_folder(f: dict) -> dict:
    parent = f.get("parent") or {}
    return {
        "uuid": f.get("uuid", ""),
        "title": f.get("title", ""),
        "parent": parent.get("title", "") if isinstance(parent, dict) else str(parent or ""),
        "document_count": f.get("document_count", ""),
    }


def _compact_user(u: dict) -> dict:
    return {
        "id": u.get("id"),
        "username": u.get("username", ""),
        "first_name": u.get("first_name", ""),
        "last_name": u.get("last_name", ""),
        "email": u.get("email", ""),
        "is_active": u.get("is_active", True),
    }


def _compact_stream_message(msg: dict) -> dict:
    stream = msg.get("stream", {}) or {}
    return {
        "id": msg.get("id"),
        "stream": stream.get("title", str(stream.get("id", ""))) if isinstance(stream, dict) else str(stream),
        "title": msg.get("title", ""),
        "text": _clean_html(msg.get("text", ""))[:1000],
        "created": (msg.get("created_date") or "")[:10],
    }


def _compact_kpi(kpi: dict) -> dict:
    folder = kpi.get("folder", {}) or {}
    return {
        "uuid": kpi.get("uuid", ""),
        "title": kpi.get("title", ""),
        "unit": kpi.get("unit", ""),
        "target_value": kpi.get("target_value", ""),
        "folder": folder.get("title", "") if isinstance(folder, dict) else str(folder),
    }


def _compact_glossar(entry: dict) -> dict:
    return {
        "id": entry.get("id"),
        "title": entry.get("title", ""),
        "description": _clean_html(entry.get("description", ""))[:500],
    }


def _compact_employee(emp: dict) -> dict:
    return {
        "id": emp.get("id"),
        "vorname": emp.get("vorname", ""),
        "nachname": emp.get("nachname", ""),
        "email_business": emp.get("email_business", ""),
        "phone_business": emp.get("phone_business", ""),
        "phone_mobile": emp.get("phone_mobile", ""),
        "funktion": emp.get("funktion", ""),
        "eintrittsdatum": emp.get("eintrittsdatum", ""),
    }


def _compact_contract(c: dict) -> dict:
    partner = c.get("partner") or {}
    ctype = c.get("type") or {}
    return {
        "id": c.get("id"),
        "title": c.get("title", ""),
        "partner": partner.get("title", "") if isinstance(partner, dict) else str(partner or ""),
        "type": ctype.get("title", "") if isinstance(ctype, dict) else str(ctype or ""),
        "status": c.get("status", ""),
        "start_date": (c.get("start_date") or "")[:10],
        "end_date": (c.get("end_date") or "")[:10],
        "value": c.get("value", ""),
        "description": _clean_html(c.get("description", ""))[:500],
    }


def _compact_project(p: dict) -> dict:
    manager = p.get("manager") or {}
    return {
        "id": p.get("id"),
        "title": p.get("title", ""),
        "state": p.get("state", ""),
        "manager": f"{manager.get('first_name', '')} {manager.get('last_name', '')}".strip() if isinstance(manager, dict) else str(manager or ""),
        "description": _clean_html(p.get("description", ""))[:500],
        "created": (p.get("created_date") or "")[:10],
    }


def _compact_task(t: dict) -> dict:
    proj = t.get("project") or {}
    assignee = t.get("assignee") or {}
    return {
        "id": t.get("id"),
        "title": t.get("title", ""),
        "status": t.get("status", ""),
        "project": proj.get("title", "") if isinstance(proj, dict) else str(proj or ""),
        "assignee": f"{assignee.get('first_name', '')} {assignee.get('last_name', '')}".strip() if isinstance(assignee, dict) else str(assignee or ""),
    }


def _compact_course(c: dict) -> dict:
    folder = c.get("folder") or {}
    return {
        "id": c.get("id"),
        "title": c.get("title", ""),
        "folder": folder.get("title", "") if isinstance(folder, dict) else str(folder or ""),
        "description": _clean_html(c.get("description", ""))[:500],
    }


def _compact_measure(m: dict) -> dict:
    v = m.get("verantwortung") or {}
    return {
        "id": m.get("id"),
        "titel": m.get("titel", ""),
        "status": m.get("status", ""),
        "verantwortung": f"{v.get('first_name', '')} {v.get('last_name', '')}".strip() if isinstance(v, dict) else str(v or ""),
        "beschreibung": _clean_html(m.get("beschreibung", ""))[:500],
    }


def _compact_dsg_activity(a: dict) -> dict:
    return {
        "id": a.get("id"),
        "title": a.get("title", ""),
        "purpose": _clean_html(a.get("purpose", ""))[:300],
        "legal_basis": a.get("legal_basis", ""),
        "description": _clean_html(a.get("description", ""))[:500],
    }


def _compact_chat(chat: dict) -> dict:
    return {
        "uuid": chat.get("uuid", ""),
        "title": chat.get("title", ""),
        "system_role": chat.get("system_role", ""),
        "ai_model_id": chat.get("ai_model_id", ""),
        "created": (chat.get("created_date") or chat.get("created") or "")[:10],
    }


def _compact_chat_entry(e: dict) -> dict:
    return {
        "id": e.get("id"),
        "role": e.get("role", ""),
        "content": (e.get("content") or "")[:500],
        "created": (e.get("created_date") or e.get("created") or "")[:10],
    }


def _compact_measuring_tool(t: dict) -> dict:
    mtype = t.get("type") or {}
    return {
        "id": t.get("id"),
        "title": t.get("title", ""),
        "serial_number": t.get("serial_number", ""),
        "type": mtype.get("title", "") if isinstance(mtype, dict) else str(mtype or ""),
        "location": t.get("location", ""),
        "inspection_interval": t.get("inspection_interval", ""),
        "last_inspection": (t.get("last_inspection") or "")[:10],
    }


def _compact_resource(r: dict) -> dict:
    rtype = r.get("type") or {}
    loc = r.get("location") or {}
    return {
        "id": r.get("id"),
        "title": r.get("title", ""),
        "type": rtype.get("title", "") if isinstance(rtype, dict) else str(rtype or ""),
        "serial_number": r.get("serial_number", ""),
        "location": loc.get("title", "") if isinstance(loc, dict) else str(loc or ""),
    }


def _compact_allocation(a: dict) -> dict:
    res = a.get("resource") or {}
    return {
        "id": a.get("id"),
        "resource": res.get("title", "") if isinstance(res, dict) else str(res or ""),
        "start_date": (a.get("start_date") or "")[:10],
        "end_date": (a.get("end_date") or "")[:10],
    }


def _compact_party(p: dict) -> dict:
    return {
        "id": p.get("id"),
        "title": p.get("title", ""),
        "interest": p.get("interest", ""),
        "influence": p.get("influence", ""),
    }


def _compact_ims_asset(a: dict) -> dict:
    cat = a.get("category") or {}
    return {
        "id": a.get("id"),
        "title": a.get("title", ""),
        "category": cat.get("title", "") if isinstance(cat, dict) else str(cat or ""),
        "description": _clean_html(a.get("description", ""))[:500],
    }


def _get_client(args: dict) -> ElizaClient:
    return ElizaClient(instance=args.get("instance"))


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="eliza_issues_list",
            description="List issues/tickets from an ELIZA tracker. Returns compact issue summaries.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string", "description": "ELIZA instance name (optional, uses default)"},
                    "tracker": {"type": "integer", "description": "Tracker ID to filter by"},
                    "state": {"type": "string", "enum": ["new", "pending", "accepted", "active", "effectiveness_check", "resolved", "rejected"]},
                    "limit": {"type": "integer", "description": "Max results (default 20)", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_issues_get",
            description="Get details of a specific issue by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "issue_id": {"type": "integer", "description": "Issue ID"},
                },
                "required": ["issue_id"],
            },
        ),
        Tool(
            name="eliza_issues_create",
            description="Create a new issue in a tracker.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "tracker": {"type": "integer", "description": "Tracker ID"},
                    "title": {"type": "string"},
                    "description": {"type": "string", "description": "HTML description"},
                    "contact_firstname": {"type": "string"},
                    "contact_lastname": {"type": "string"},
                    "contact_email": {"type": "string"},
                },
                "required": ["tracker", "title"],
            },
        ),
        Tool(
            name="eliza_issues_update",
            description="Update an issue (state, title, assignment).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "issue_id": {"type": "integer"},
                    "state": {"type": "string"},
                    "title": {"type": "string"},
                    "assigned_user": {"type": "integer"},
                },
                "required": ["issue_id"],
            },
        ),
        Tool(
            name="eliza_issues_followups",
            description="List followups/comments for an issue.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "issue_id": {"type": "integer"},
                    "limit": {"type": "integer", "default": 20},
                },
                "required": ["issue_id"],
            },
        ),
        Tool(
            name="eliza_issues_followup_add",
            description="Add a followup comment to an issue.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "issue_id": {"type": "integer"},
                    "comment": {"type": "string"},
                },
                "required": ["issue_id", "comment"],
            },
        ),
        Tool(
            name="eliza_trackers_list",
            description="List all trackers (Meldekreise) on the instance.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                },
            },
        ),
        Tool(
            name="eliza_dms_documents",
            description="List documents from the DMS. Filter by folder, state, type, or search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "folder_uuid": {"type": "string", "description": "Folder UUID to filter"},
                    "state": {"type": "string", "description": "1=Draft, 2=Review, 3=Reviewed, 4=Approved, 5=Outdated, 6=Archived"},
                    "type_id": {"type": "integer", "description": "Document type ID"},
                    "search": {"type": "string", "description": "Search in title"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_dms_document_get",
            description="Get document details by UUID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "uuid": {"type": "string", "description": "Document UUID"},
                },
                "required": ["uuid"],
            },
        ),
        Tool(
            name="eliza_dms_folders",
            description="List DMS folders.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "root_only": {"type": "boolean", "description": "Only root folders", "default": False},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        Tool(
            name="eliza_dms_doctypes",
            description="List document types.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                },
            },
        ),
        Tool(
            name="eliza_users_list",
            description="List users on the ELIZA instance.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        Tool(
            name="eliza_users_get",
            description="Get user details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "user_id": {"type": "integer"},
                },
                "required": ["user_id"],
            },
        ),
        Tool(
            name="eliza_time_list",
            description="List work time entries.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "user": {"type": "integer", "description": "User ID"},
                    "date": {"type": "string", "description": "Date YYYY-MM-DD"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_time_add",
            description="Add a work time entry.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "user": {"type": "integer"},
                    "date": {"type": "string", "description": "YYYY-MM-DD"},
                    "start_time": {"type": "string", "description": "HH:MM"},
                    "end_time": {"type": "string", "description": "HH:MM"},
                    "type": {"type": "integer", "description": "1=work, 5=travel", "default": 1},
                    "description": {"type": "string", "default": ""},
                },
                "required": ["user", "date", "start_time", "end_time"],
            },
        ),
        # --- Streams tools ---
        Tool(
            name="eliza_streams_list",
            description="List streams (Newskanäle) on the ELIZA instance.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_streams_messages_list",
            description="List messages from streams. Optionally filter by stream ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "stream": {"type": "integer", "description": "Stream ID to filter by"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_streams_messages_create",
            description="Create a new message in a stream.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "stream": {"type": "integer", "description": "Stream ID"},
                    "title": {"type": "string"},
                    "text": {"type": "string"},
                },
                "required": ["stream", "title", "text"],
            },
        ),
        # --- KPI tools ---
        Tool(
            name="eliza_kpi_list",
            description="List KPIs (Kennzahlen). Optionally filter by folder UUID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "folder": {"type": "string", "description": "Folder UUID to filter by"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_kpi_record",
            description="Record a KPI measurement value.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "kpi": {"type": "string", "description": "KPI UUID"},
                    "date": {"type": "string", "description": "Date YYYY-MM-DD"},
                    "value": {"type": "number", "description": "Measurement value"},
                    "description": {"type": "string"},
                },
                "required": ["kpi", "date", "value"],
            },
        ),
        # --- Processes tools ---
        Tool(
            name="eliza_processes_list",
            description="List processes (Prozesse). Filter by state or search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "state": {"type": "string", "description": "Filter by state (e.g. draft)"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_processes_get",
            description="Get process details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "process_id": {"type": "integer", "description": "Process ID"},
                },
                "required": ["process_id"],
            },
        ),
        Tool(
            name="eliza_processes_create",
            description="Create a new process.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "nummer": {"type": "string", "description": "Process number"},
                    "titel": {"type": "string", "description": "Process title"},
                    "beschreibung": {"type": "string", "description": "Description"},
                    "color": {"type": "string", "description": "Color hex"},
                    "parent": {"type": "integer", "description": "Parent process ID"},
                },
                "required": ["nummer", "titel"],
            },
        ),
        # --- Forms tools ---
        Tool(
            name="eliza_forms_list",
            description="List form templates. Optionally filter by folder.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "folder": {"type": "integer", "description": "Folder ID to filter by"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_forms_get",
            description="Get form template details by ID (full with sections and questions).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "template_id": {"type": "integer", "description": "Template ID"},
                },
                "required": ["template_id"],
            },
        ),
        # --- Spaces tools ---
        Tool(
            name="eliza_spaces_list",
            description="List spaces. Filter by state or search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "state": {"type": "string", "description": "Filter by state"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_spaces_get",
            description="Get space details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "space_id": {"type": "integer", "description": "Space ID"},
                },
                "required": ["space_id"],
            },
        ),
        Tool(
            name="eliza_spaces_card_create",
            description="Create a card in a space board card list.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "cardlist": {"type": "integer", "description": "Card list ID"},
                    "title": {"type": "string"},
                    "description": {"type": "string"},
                },
                "required": ["cardlist", "title"],
            },
        ),
        Tool(
            name="eliza_spaces_meeting_create",
            description="Create a meeting in a space.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "space": {"type": "integer", "description": "Space ID"},
                    "title": {"type": "string"},
                    "description": {"type": "string"},
                    "start": {"type": "string", "description": "Start datetime"},
                    "end": {"type": "string", "description": "End datetime"},
                    "location": {"type": "string"},
                },
                "required": ["space", "title"],
            },
        ),
        Tool(
            name="eliza_spaces_meetingitems",
            description="List meeting items (Traktanden) for a meeting.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "meeting_id": {"type": "integer", "description": "Meeting ID"},
                },
                "required": ["meeting_id"],
            },
        ),
        Tool(
            name="eliza_spaces_meetingitem_create",
            description="Create a meeting item (Traktandum).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "meeting": {"type": "integer", "description": "Meeting ID"},
                    "title": {"type": "string"},
                    "number": {"type": "integer", "description": "Item number"},
                    "text": {"type": "string", "description": "Item text"},
                },
                "required": ["meeting", "title"],
            },
        ),
        # --- Standards tools ---
        Tool(
            name="eliza_standards_list",
            description="List standards (Normen). Optionally filter by category.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "category": {"type": "integer", "description": "Category ID to filter by"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_standards_get",
            description="Get standard details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "standard_id": {"type": "integer", "description": "Standard ID"},
                },
                "required": ["standard_id"],
            },
        ),
        # --- Glossar tools ---
        Tool(
            name="eliza_glossar_list",
            description="List glossary entries. Search by keyword.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_glossar_get",
            description="Get glossary entry details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "entry_id": {"type": "integer", "description": "Glossary entry ID"},
                },
                "required": ["entry_id"],
            },
        ),
        Tool(
            name="eliza_glossar_create",
            description="Create a glossary entry.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "title": {"type": "string"},
                    "description": {"type": "string"},
                },
                "required": ["title"],
            },
        ),
        # --- Organisation tools ---
        Tool(
            name="eliza_organisation_employees",
            description="List employees (Mitarbeitende). Search by name.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_organisation_employee_get",
            description="Get employee details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "employee_id": {"type": "integer", "description": "Employee ID"},
                },
                "required": ["employee_id"],
            },
        ),
        Tool(
            name="eliza_organisation_orgunits",
            description="List organisational units (Orgeinheiten).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        Tool(
            name="eliza_organisation_functions",
            description="List organisational functions (Funktionen).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        # --- Contracts tools ---
        Tool(
            name="eliza_contracts_list",
            description="List contracts. Filter by status or search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "status": {"type": "string", "description": "Filter by status"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_contracts_get",
            description="Get contract details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "contract_id": {"type": "integer", "description": "Contract ID"},
                },
                "required": ["contract_id"],
            },
        ),
        Tool(
            name="eliza_contracts_create",
            description="Create a contract.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "title": {"type": "string"},
                    "partner": {"type": "integer", "description": "Partner ID"},
                    "type": {"type": "integer", "description": "Contract type ID"},
                    "status": {"type": "string"},
                    "start_date": {"type": "string", "description": "YYYY-MM-DD"},
                    "end_date": {"type": "string", "description": "YYYY-MM-DD"},
                    "value": {"type": "number"},
                    "description": {"type": "string"},
                },
                "required": ["title"],
            },
        ),
        Tool(
            name="eliza_contracts_partners",
            description="List contract partners.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        # --- Projects tools ---
        Tool(
            name="eliza_projects_list",
            description="List projects. Filter by state (planned/active/finished) or search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "state": {"type": "string", "description": "planned/active/finished"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_projects_get",
            description="Get project details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "project_id": {"type": "integer", "description": "Project ID"},
                },
                "required": ["project_id"],
            },
        ),
        Tool(
            name="eliza_projects_create",
            description="Create a project.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "title": {"type": "string"},
                    "description": {"type": "string"},
                    "state": {"type": "string", "description": "planned/active/finished", "default": "planned"},
                    "manager": {"type": "integer", "description": "Manager user ID"},
                },
                "required": ["title"],
            },
        ),
        Tool(
            name="eliza_projects_tasks",
            description="List project tasks. Optionally filter by project ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "project": {"type": "integer", "description": "Project ID"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        # --- Tutorials tools ---
        Tool(
            name="eliza_tutorials_courses",
            description="List e-learning courses. Filter by folder or search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "folder": {"type": "integer", "description": "Folder ID"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_tutorials_course_get",
            description="Get course details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "course_id": {"type": "integer", "description": "Course ID"},
                },
                "required": ["course_id"],
            },
        ),
        Tool(
            name="eliza_tutorials_lessons",
            description="List lessons. Optionally filter by course ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "course": {"type": "integer", "description": "Course ID"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        # --- OKR tools ---
        Tool(
            name="eliza_okr_systems",
            description="List OKR systems (with vision and mission).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        Tool(
            name="eliza_okr_objectives",
            description="List OKR objectives. Optionally filter by period ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "period": {"type": "integer", "description": "Period ID"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_okr_results",
            description="List OKR key results. Optionally filter by objective ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "objective": {"type": "integer", "description": "Objective ID"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        # --- SWOT tools ---
        Tool(
            name="eliza_swot_measures",
            description="List SWOT/risk measures. Filter by status or search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "status": {"type": "string", "description": "Filter by status"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_swot_measure_get",
            description="Get SWOT measure details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "measure_id": {"type": "integer", "description": "Measure ID"},
                },
                "required": ["measure_id"],
            },
        ),
        Tool(
            name="eliza_swot_measure_create",
            description="Create a SWOT/risk measure.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "titel": {"type": "string", "description": "Measure title"},
                    "beschreibung": {"type": "string", "description": "Description"},
                    "status": {"type": "string"},
                    "verantwortung": {"type": "integer", "description": "Responsible person ID"},
                },
                "required": ["titel"],
            },
        ),
        # --- DSG tools ---
        Tool(
            name="eliza_dsg_activities",
            description="List data processing activities (Datenschutz/GDPR).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_dsg_activity_get",
            description="Get data processing activity details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "activity_id": {"type": "integer", "description": "Activity ID"},
                },
                "required": ["activity_id"],
            },
        ),
        Tool(
            name="eliza_dsg_activity_create",
            description="Create a data processing activity (GDPR).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "title": {"type": "string"},
                    "description": {"type": "string"},
                    "purpose": {"type": "string"},
                    "legal_basis": {"type": "string"},
                },
                "required": ["title"],
            },
        ),
        # --- Bot tools ---
        Tool(
            name="eliza_bot_chats",
            description="List AI bot chats.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_bot_chat_get",
            description="Get bot chat details by UUID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "uuid": {"type": "string", "description": "Chat UUID"},
                },
                "required": ["uuid"],
            },
        ),
        Tool(
            name="eliza_bot_chat_create",
            description="Create a new AI bot chat.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "title": {"type": "string"},
                    "system_role": {"type": "string", "description": "System role prompt"},
                    "ai_model_id": {"type": "integer", "description": "AI model ID"},
                },
                "required": ["title"],
            },
        ),
        Tool(
            name="eliza_bot_entries",
            description="List chat entries/messages for a bot chat.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "uuid": {"type": "string", "description": "Chat UUID"},
                    "limit": {"type": "integer", "default": 50},
                },
                "required": ["uuid"],
            },
        ),
        # --- Measuring tools ---
        Tool(
            name="eliza_measuring_list",
            description="List measuring tools (Prüfmittel). Search by keyword.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_measuring_get",
            description="Get measuring tool details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "tool_id": {"type": "integer", "description": "Measuring tool ID"},
                },
                "required": ["tool_id"],
            },
        ),
        Tool(
            name="eliza_measuring_create",
            description="Create a measuring tool (Prüfmittel).",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "title": {"type": "string"},
                    "serial_number": {"type": "string"},
                    "type": {"type": "integer", "description": "Type ID"},
                    "inspection_interval": {"type": "integer", "description": "Inspection interval in days"},
                    "last_inspection": {"type": "string", "description": "YYYY-MM-DD"},
                    "location": {"type": "string"},
                },
                "required": ["title"],
            },
        ),
        # --- Resources tools ---
        Tool(
            name="eliza_resources_list",
            description="List resources/inventory items. Search by keyword.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="eliza_resources_get",
            description="Get resource details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "resource_id": {"type": "integer", "description": "Resource ID"},
                },
                "required": ["resource_id"],
            },
        ),
        Tool(
            name="eliza_resources_create",
            description="Create a resource/inventory item.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "title": {"type": "string"},
                    "type": {"type": "integer", "description": "Type ID"},
                    "serial_number": {"type": "string"},
                    "location": {"type": "integer", "description": "Location ID"},
                },
                "required": ["title"],
            },
        ),
        Tool(
            name="eliza_resources_allocations",
            description="List resource allocations. Optionally filter by resource ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "resource": {"type": "integer", "description": "Resource ID"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        # --- Business Context tools ---
        Tool(
            name="eliza_businesscontext_parties",
            description="List interested parties (Stakeholder). Search by keyword.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        Tool(
            name="eliza_businesscontext_party_get",
            description="Get interested party details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "party_id": {"type": "integer", "description": "Party ID"},
                },
                "required": ["party_id"],
            },
        ),
        Tool(
            name="eliza_businesscontext_issues",
            description="List business context issues. Search by keyword.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
        # --- IMS tools ---
        Tool(
            name="eliza_ims_systems",
            description="List IMS (Integriertes Management System) systems.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "limit": {"type": "integer", "default": 50},
                },
            },
        ),
        Tool(
            name="eliza_ims_system_get",
            description="Get IMS system details by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "system_id": {"type": "integer", "description": "IMS system ID"},
                },
                "required": ["system_id"],
            },
        ),
        Tool(
            name="eliza_ims_assets",
            description="List IMS assets. Filter by category or search.",
            inputSchema={
                "type": "object",
                "properties": {
                    "instance": {"type": "string"},
                    "search": {"type": "string", "description": "Search text"},
                    "category": {"type": "integer", "description": "Category ID"},
                    "limit": {"type": "integer", "default": 20},
                },
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        client = _get_client(arguments)
        result = _dispatch(name, client, arguments)
        return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False, default=str))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


def _dispatch(name: str, client: ElizaClient, args: dict) -> Any:
    if name == "eliza_issues_list":
        params = {}
        if args.get("tracker"):
            params["tracker"] = args["tracker"]
        if args.get("state"):
            params["state"] = args["state"]
        issues = client.get_paginated("issue/issue", params=params, limit=args.get("limit", 20))
        return [_compact_issue(i) for i in issues]

    elif name == "eliza_issues_get":
        issue = client.get(f"issue/issue/{args['issue_id']}")
        return _compact_issue(issue)

    elif name == "eliza_issues_create":
        data = {"tracker": args["tracker"], "title": args["title"]}
        for field in ["description", "contact_firstname", "contact_lastname", "contact_email"]:
            if args.get(field):
                data[field] = args[field]
        result = client.post("issue/issue", data=data)
        return {"id": result["id"], "serial_number": result.get("serial_number"), "status": "created"}

    elif name == "eliza_issues_update":
        data = {}
        for field in ["state", "title", "assigned_user"]:
            if args.get(field):
                data[field] = args[field]
        client.patch(f"issue/issue/{args['issue_id']}", data=data)
        return {"id": args["issue_id"], "status": "updated"}

    elif name == "eliza_issues_followups":
        fups = client.get(f"issue/issue/{args['issue_id']}/followup")
        if isinstance(fups, dict):
            fups = fups.get("results", [])
        return [_compact_followup(f) for f in fups[:args.get("limit", 20)]]

    elif name == "eliza_issues_followup_add":
        client.post(f"issue/issue/{args['issue_id']}/followup", data={"comment": args["comment"]})
        return {"issue_id": args["issue_id"], "status": "followup_added"}

    elif name == "eliza_trackers_list":
        trackers = client.get_paginated("issue/tracker")
        return [{"id": t["id"], "title": t["title"], "state": t["state"]} for t in trackers]

    elif name == "eliza_dms_documents":
        params = {}
        if args.get("folder_uuid"):
            params["folder_uuid"] = args["folder_uuid"]
        if args.get("state"):
            params["state"] = args["state"]
        if args.get("type_id"):
            params["type"] = args["type_id"]
        if args.get("search"):
            params["search"] = args["search"]
        docs = client.get_paginated("dms/document", params=params, limit=args.get("limit", 20))
        return [_compact_document(d) for d in docs]

    elif name == "eliza_dms_document_get":
        doc = client.get(f"dms/document/{args['uuid']}")
        return _compact_document(doc)

    elif name == "eliza_dms_folders":
        params = {}
        if args.get("root_only"):
            params["parent__isnull"] = "true"
        folders = client.get_paginated("dms/folder", params=params, limit=args.get("limit", 50))
        return [_compact_folder(f) for f in folders]

    elif name == "eliza_dms_doctypes":
        types = client.get_paginated("dms/documenttype")
        return [{"id": t["id"], "title": t["title"]} for t in types]

    elif name == "eliza_users_list":
        users = client.get_paginated("user", limit=args.get("limit", 50))
        return [_compact_user(u) for u in users]

    elif name == "eliza_users_get":
        user = client.get(f"user/{args['user_id']}")
        return _compact_user(user)

    elif name == "eliza_time_list":
        params = {}
        if args.get("user"):
            params["user"] = args["user"]
        if args.get("date"):
            params["date"] = args["date"]
        entries = client.get_paginated("timetracker/worktime", params=params, limit=args.get("limit", 20))
        return entries

    elif name == "eliza_time_add":
        data = {
            "user": args["user"],
            "date": args["date"],
            "start_time": args["start_time"],
            "end_time": args["end_time"],
            "type": args.get("type", 1),
            "description": args.get("description", ""),
        }
        result = client.post("timetracker/worktime", data=data)
        return {"id": result.get("id"), "status": "created"}

    # --- Streams ---
    elif name == "eliza_streams_list":
        streams = client.get_paginated("stream/stream", limit=args.get("limit", 20))
        return [{"id": s.get("id"), "title": s.get("title", ""), "description": s.get("description", "")} for s in streams]

    elif name == "eliza_streams_messages_list":
        params = {}
        if args.get("stream"):
            params["stream"] = args["stream"]
        messages = client.get_paginated("stream/messages", params=params, limit=args.get("limit", 20))
        return [_compact_stream_message(m) for m in messages]

    elif name == "eliza_streams_messages_create":
        data = {"stream": args["stream"], "title": args["title"], "text": args["text"]}
        result = client.post("stream/messages", data=data)
        return {"id": result.get("id"), "status": "created"}

    # --- KPI ---
    elif name == "eliza_kpi_list":
        params = {}
        if args.get("folder"):
            params["folder"] = args["folder"]
        kpis = client.get_paginated("kpi/kpi", params=params, limit=args.get("limit", 20))
        return [_compact_kpi(k) for k in kpis]

    elif name == "eliza_kpi_record":
        data = {"kpi": args["kpi"], "date": args["date"], "value": args["value"]}
        if args.get("description"):
            data["description"] = args["description"]
        result = client.post("kpi/measurement", data=data)
        return {"id": result.get("id"), "status": "created"}


    # --- Processes ---
    elif name == "eliza_processes_list":
        params = {}
        if args.get("state"):
            params["state"] = args["state"]
        if args.get("search"):
            params["search"] = args["search"]
        processes = client.get_paginated("process/process", params=params, limit=args.get("limit", 20))
        return [{"id": p.get("id"), "nummer": p.get("nummer", ""), "titel": p.get("titel", ""), "state": p.get("state", "")} for p in processes]

    elif name == "eliza_processes_get":
        process = client.get(f"process/process/{args['process_id']}")
        return {"id": process.get("id"), "nummer": process.get("nummer", ""), "titel": process.get("titel", ""), "state": process.get("state", ""), "beschreibung": _clean_html(process.get("beschreibung", ""))[:500]}

    elif name == "eliza_processes_create":
        data = {"nummer": args["nummer"], "titel": args["titel"], "state": "draft"}
        for field in ["beschreibung", "color"]:
            if args.get(field):
                data[field] = args[field]
        if args.get("parent"):
            data["uebergeordneter_prozess"] = args["parent"]
        result = client.post("process/process", data=data)
        return {"id": result.get("id"), "status": "created"}

    # --- Forms ---
    elif name == "eliza_forms_list":
        params = {}
        if args.get("folder"):
            params["folder"] = args["folder"]
        templates = client.get_paginated("forms/template", params=params, limit=args.get("limit", 20))
        return [{"id": t.get("id"), "title": t.get("title", ""), "description": t.get("description", "")} for t in templates]

    elif name == "eliza_forms_get":
        template = client.get(f"forms/template/{args['template_id']}/full")
        return template

    # --- Spaces ---
    elif name == "eliza_spaces_list":
        params = {}
        if args.get("state"):
            params["state"] = args["state"]
        if args.get("search"):
            params["search"] = args["search"]
        spaces = client.get_paginated("teams/space", params=params, limit=args.get("limit", 20))
        return [{"id": s.get("id"), "title": s.get("title", ""), "state": s.get("state", ""), "description": s.get("description", "")} for s in spaces]

    elif name == "eliza_spaces_get":
        space = client.get(f"teams/space/{args['space_id']}")
        return {"id": space.get("id"), "title": space.get("title", ""), "state": space.get("state", ""), "description": space.get("description", "")}

    elif name == "eliza_spaces_card_create":
        data = {"list": args["cardlist"], "title": args["title"]}
        if args.get("description"):
            data["description"] = args["description"]
        result = client.post("teams/card", data=data)
        return {"id": result.get("id"), "status": "created"}


    elif name == "eliza_spaces_meeting_create":
        data = {"space": args["space"], "title": args["title"]}
        for key in ("description", "start", "end", "location"):
            if args.get(key):
                data[key] = args[key]
        result = client.post("teams/meeting", data=data)
        return {"id": result.get("id"), "status": "created"}

    elif name == "eliza_spaces_meetingitems":
        items = client.get_paginated("teams/meetingitem", params={"meeting": args["meeting_id"]})
        return [{"id": it.get("id"), "number": it.get("number"), "title": it.get("title", ""), "text": it.get("text", "")} for it in items]

    elif name == "eliza_spaces_meetingitem_create":
        data = {"meeting": args["meeting"], "title": args["title"]}
        if args.get("number"):
            data["number"] = args["number"]
        if args.get("text"):
            data["text"] = args["text"]
        result = client.post("teams/meetingitem", data=data)
        return {"id": result.get("id"), "status": "created"}

    # --- Standards ---
    elif name == "eliza_standards_list":
        params = {}
        if args.get("category"):
            params["category"] = args["category"]
        standards = client.get_paginated("standards/standard", params=params, limit=args.get("limit", 20))
        return [{"id": s.get("id"), "title": s.get("title", ""), "short_title": s.get("short_title", "")} for s in standards]

    elif name == "eliza_standards_get":
        standard = client.get(f"standards/standard/{args['standard_id']}")
        return {"id": standard.get("id"), "title": standard.get("title", ""), "short_title": standard.get("short_title", ""), "description": _clean_html(standard.get("description", ""))[:500]}

    # --- Glossar ---
    elif name == "eliza_glossar_list":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        entries = client.get_paginated("glossar/entry", params=params, limit=args.get("limit", 20))
        return [_compact_glossar(e) for e in entries]

    elif name == "eliza_glossar_get":
        entry = client.get(f"glossar/entry/{args['entry_id']}")
        return _compact_glossar(entry)

    elif name == "eliza_glossar_create":
        data = {"title": args["title"]}
        if args.get("description"):
            data["description"] = args["description"]
        result = client.post("glossar/entry", data=data)
        return {"id": result.get("id"), "status": "created"}

    # --- Organisation ---
    elif name == "eliza_organisation_employees":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        employees = client.get_paginated("organisation/mitarbeitende", params=params, limit=args.get("limit", 20))
        return [_compact_employee(e) for e in employees]

    elif name == "eliza_organisation_employee_get":
        emp = client.get(f"organisation/mitarbeitende/{args['employee_id']}")
        return _compact_employee(emp)

    elif name == "eliza_organisation_orgunits":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        units = client.get_paginated("organisation/orgunit", params=params, limit=args.get("limit", 50))
        return [{"id": u.get("id"), "titel": u.get("titel", ""), "description": _clean_html(u.get("description", ""))[:300]} for u in units]

    elif name == "eliza_organisation_functions":
        funcs = client.get_paginated("organisation/funktionen", limit=args.get("limit", 50))
        return [{"id": f.get("id"), "titel": f.get("titel", ""), "description": _clean_html(f.get("description", ""))[:300]} for f in funcs]

    # --- Contracts ---
    elif name == "eliza_contracts_list":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        if args.get("status"):
            params["status"] = args["status"]
        contracts = client.get_paginated("contracts/contract", params=params, limit=args.get("limit", 20))
        return [_compact_contract(c) for c in contracts]

    elif name == "eliza_contracts_get":
        contract = client.get(f"contracts/contract/{args['contract_id']}")
        return _compact_contract(contract)

    elif name == "eliza_contracts_create":
        data = {"title": args["title"]}
        for field in ["description", "status", "start_date", "end_date"]:
            if args.get(field):
                data[field] = args[field]
        if args.get("partner"):
            data["partner"] = args["partner"]
        if args.get("type"):
            data["type"] = args["type"]
        if args.get("value") is not None:
            data["value"] = args["value"]
        result = client.post("contracts/contract", data=data)
        return {"id": result.get("id"), "status": "created"}

    elif name == "eliza_contracts_partners":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        partners = client.get_paginated("contracts/partner", params=params, limit=args.get("limit", 50))
        return [{"id": p.get("id"), "title": p.get("title", ""), "description": _clean_html(p.get("description", ""))[:300]} for p in partners]

    # --- Projects ---
    elif name == "eliza_projects_list":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        if args.get("state"):
            params["state"] = args["state"]
        projects = client.get_paginated("projects/project", params=params, limit=args.get("limit", 20))
        return [_compact_project(p) for p in projects]

    elif name == "eliza_projects_get":
        project = client.get(f"projects/project/{args['project_id']}")
        return _compact_project(project)

    elif name == "eliza_projects_create":
        data = {"title": args["title"], "state": args.get("state", "planned")}
        if args.get("description"):
            data["description"] = args["description"]
        if args.get("manager"):
            data["manager"] = args["manager"]
        result = client.post("projects/project", data=data)
        return {"id": result.get("id"), "status": "created"}

    elif name == "eliza_projects_tasks":
        params = {}
        if args.get("project"):
            params["project"] = args["project"]
        tasks = client.get_paginated("projects/task", params=params, limit=args.get("limit", 20))
        return [_compact_task(t) for t in tasks]

    # --- Tutorials ---
    elif name == "eliza_tutorials_courses":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        if args.get("folder"):
            params["folder"] = args["folder"]
        courses = client.get_paginated("tutorial/course", params=params, limit=args.get("limit", 20))
        return [_compact_course(c) for c in courses]

    elif name == "eliza_tutorials_course_get":
        course = client.get(f"tutorial/course/{args['course_id']}")
        return _compact_course(course)

    elif name == "eliza_tutorials_lessons":
        params = {}
        if args.get("course"):
            params["course"] = args["course"]
        lessons = client.get_paginated("tutorial/lesson", params=params, limit=args.get("limit", 50))
        return [{"id": l.get("id"), "title": l.get("title", "")} for l in lessons]

    # --- OKR ---
    elif name == "eliza_okr_systems":
        systems = client.get_paginated("okr/system", limit=args.get("limit", 50))
        return [{"id": s.get("id"), "title": s.get("title", ""), "vision": _clean_html(s.get("vision", ""))[:300], "mission": _clean_html(s.get("mission", ""))[:300]} for s in systems]

    elif name == "eliza_okr_objectives":
        params = {}
        if args.get("period"):
            params["period"] = args["period"]
        objectives = client.get_paginated("okr/objective", params=params, limit=args.get("limit", 20))
        return [{"id": o.get("id"), "title": o.get("title", ""), "description": _clean_html(o.get("description", ""))[:300]} for o in objectives]

    elif name == "eliza_okr_results":
        params = {}
        if args.get("objective"):
            params["objective"] = args["objective"]
        results = client.get_paginated("okr/result", params=params, limit=args.get("limit", 50))
        return [{"id": r.get("id"), "title": r.get("title", ""), "target_value": r.get("target_value", ""), "current_value": r.get("current_value", "")} for r in results]

    # --- SWOT ---
    elif name == "eliza_swot_measures":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        if args.get("status"):
            params["status"] = args["status"]
        measures = client.get_paginated("swot/measure", params=params, limit=args.get("limit", 20))
        return [_compact_measure(m) for m in measures]

    elif name == "eliza_swot_measure_get":
        measure = client.get(f"swot/measure/{args['measure_id']}")
        return _compact_measure(measure)

    elif name == "eliza_swot_measure_create":
        data = {"titel": args["titel"]}
        if args.get("beschreibung"):
            data["beschreibung"] = args["beschreibung"]
        if args.get("status"):
            data["status"] = args["status"]
        if args.get("verantwortung"):
            data["verantwortung"] = args["verantwortung"]
        result = client.post("swot/measure", data=data)
        return {"id": result.get("id"), "status": "created"}

    # --- DSG ---
    elif name == "eliza_dsg_activities":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        activities = client.get_paginated("dsg/activity", params=params, limit=args.get("limit", 20))
        return [_compact_dsg_activity(a) for a in activities]

    elif name == "eliza_dsg_activity_get":
        activity = client.get(f"dsg/activity/{args['activity_id']}")
        return _compact_dsg_activity(activity)

    elif name == "eliza_dsg_activity_create":
        data = {"title": args["title"]}
        for field in ["description", "purpose", "legal_basis"]:
            if args.get(field):
                data[field] = args[field]
        result = client.post("dsg/activity", data=data)
        return {"id": result.get("id"), "status": "created"}

    # --- Bot ---
    elif name == "eliza_bot_chats":
        chats = client.get_paginated("bot/chat", limit=args.get("limit", 20))
        return [_compact_chat(c) for c in chats]

    elif name == "eliza_bot_chat_get":
        chat = client.get(f"bot/chat/{args['uuid']}")
        return _compact_chat(chat)

    elif name == "eliza_bot_chat_create":
        data = {"title": args["title"]}
        if args.get("system_role"):
            data["system_role"] = args["system_role"]
        if args.get("ai_model_id"):
            data["ai_model_id"] = args["ai_model_id"]
        result = client.post("bot/chat", data=data)
        return {"uuid": result.get("uuid"), "status": "created"}

    elif name == "eliza_bot_entries":
        entries = client.get_paginated(f"bot/chat/{args['uuid']}/entry", limit=args.get("limit", 50))
        return [_compact_chat_entry(e) for e in entries]

    # --- Measuring ---
    elif name == "eliza_measuring_list":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        tools = client.get_paginated("measuringtool/measuringtool", params=params, limit=args.get("limit", 20))
        return [_compact_measuring_tool(t) for t in tools]

    elif name == "eliza_measuring_get":
        tool = client.get(f"measuringtool/measuringtool/{args['tool_id']}")
        return _compact_measuring_tool(tool)

    elif name == "eliza_measuring_create":
        data = {"title": args["title"]}
        for field in ["serial_number", "location", "last_inspection"]:
            if args.get(field):
                data[field] = args[field]
        if args.get("type"):
            data["type"] = args["type"]
        if args.get("inspection_interval"):
            data["inspection_interval"] = args["inspection_interval"]
        result = client.post("measuringtool/measuringtool", data=data)
        return {"id": result.get("id"), "status": "created"}

    # --- Resources ---
    elif name == "eliza_resources_list":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        resources = client.get_paginated("resources/resources", params=params, limit=args.get("limit", 20))
        return [_compact_resource(r) for r in resources]

    elif name == "eliza_resources_get":
        resource = client.get(f"resources/resources/{args['resource_id']}")
        return _compact_resource(resource)

    elif name == "eliza_resources_create":
        data = {"title": args["title"]}
        if args.get("type"):
            data["type"] = args["type"]
        if args.get("serial_number"):
            data["serial_number"] = args["serial_number"]
        if args.get("location"):
            data["location"] = args["location"]
        result = client.post("resources/resources", data=data)
        return {"id": result.get("id"), "status": "created"}

    elif name == "eliza_resources_allocations":
        params = {}
        if args.get("resource"):
            params["resource"] = args["resource"]
        allocs = client.get_paginated("resources/allocations", params=params, limit=args.get("limit", 50))
        return [_compact_allocation(a) for a in allocs]

    # --- Business Context ---
    elif name == "eliza_businesscontext_parties":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        parties = client.get_paginated("businesscontext/interestedparty", params=params, limit=args.get("limit", 50))
        return [_compact_party(p) for p in parties]

    elif name == "eliza_businesscontext_party_get":
        party = client.get(f"businesscontext/interestedparty/{args['party_id']}")
        return _compact_party(party)

    elif name == "eliza_businesscontext_issues":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        issues = client.get_paginated("businesscontext/issue", params=params, limit=args.get("limit", 20))
        return [{"id": i.get("id"), "title": i.get("title", ""), "description": _clean_html(i.get("description", ""))[:300]} for i in issues]

    # --- IMS ---
    elif name == "eliza_ims_systems":
        systems = client.get_paginated("ims/system", limit=args.get("limit", 50))
        return [{"id": s.get("id"), "title": s.get("title", ""), "description": _clean_html(s.get("description", ""))[:300]} for s in systems]

    elif name == "eliza_ims_system_get":
        system = client.get(f"ims/system/{args['system_id']}")
        return {"id": system.get("id"), "title": system.get("title", ""), "description": _clean_html(system.get("description", ""))[:500]}

    elif name == "eliza_ims_assets":
        params = {}
        if args.get("search"):
            params["search"] = args["search"]
        if args.get("category"):
            params["category"] = args["category"]
        assets = client.get_paginated("ims/asset", params=params, limit=args.get("limit", 20))
        return [_compact_ims_asset(a) for a in assets]

    else:
        return {"error": f"Unknown tool: {name}"}


async def run_stdio():
    """Run MCP server over stdio."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())
