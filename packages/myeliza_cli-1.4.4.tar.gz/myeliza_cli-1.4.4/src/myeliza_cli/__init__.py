"""ELIZA CLI — Command-line interface for the ELIZA platform."""

__version__ = "0.1.0"
