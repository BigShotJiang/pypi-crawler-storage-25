"""Output formatters for ELIZA CLI."""

import csv
import io
import json
from typing import Any

from rich.console import Console
from rich.table import Table

console = Console()


def print_table(data: list[dict], columns: list[str], title: str = "") -> None:
    """Print data as a Rich table."""
    table = Table(title=title, show_lines=False)
    for col in columns:
        table.add_column(col.replace("_", " ").title(), no_wrap=col in ("id", "serial_number"))
    for row in data:
        table.add_row(*[str(row.get(col, "")) for col in columns])
    console.print(table)


def print_json(data: Any) -> None:
    """Print data as formatted JSON."""
    console.print_json(json.dumps(data, ensure_ascii=False, default=str))


def print_csv(data: list[dict], columns: list[str]) -> None:
    """Print data as CSV."""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(data)
    print(output.getvalue(), end="")


def print_detail(data: dict, fields: list[str]) -> None:
    """Print a single record as key-value pairs."""
    for field in fields:
        value = data.get(field, "")
        if isinstance(value, dict):
            # User objects etc.
            value = value.get("first_name", "") + " " + value.get("last_name", "")
            value = value.strip() or str(data.get(field, ""))
        label = field.replace("_", " ").title()
        console.print(f"[bold]{label}:[/bold] {value}")


def format_output(
    data: Any,
    fmt: str = "table",
    columns: list[str] | None = None,
    title: str = "",
) -> None:
    """Route output to the correct formatter."""
    if fmt == "json":
        print_json(data)
    elif fmt == "csv":
        if isinstance(data, list) and columns:
            print_csv(data, columns)
        else:
            print_json(data)  # Fallback
    elif fmt == "table":
        if isinstance(data, list) and columns:
            print_table(data, columns, title=title)
        elif isinstance(data, dict) and columns:
            print_detail(data, columns)
        else:
            print_json(data)
