"""ELIZA REST API Client."""

import json
from typing import Any, Optional
from urllib.parse import urljoin

import requests
from rich.console import Console

from .config import get_instance

# Global dry-run flag, set by main.py callback
_dry_run: bool = False


class ElizaClient:
    """Client for the ELIZA REST API."""

    def __init__(self, instance: Optional[str] = None):
        inst = get_instance(instance)
        self.base_url = inst["url"]
        self.instance_name = inst["name"]
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Token {inst['token']}",
            "Accept": "application/json",
        })

    def _url(self, endpoint: str) -> str:
        """Build full URL. No trailing slash (important for POST)."""
        return f"{self.base_url}/{endpoint.strip('/')}"

    def _print_dry_run(self, method: str, url: str, params: Optional[dict] = None, data: Optional[dict] = None) -> None:
        console = Console(stderr=True)
        console.print(f"[bold cyan]DRY RUN[/bold cyan]")
        console.print(f"[bold]Method:[/bold]  {method}")
        console.print(f"[bold]URL:[/bold]     {url}")
        headers = dict(self.session.headers)
        headers["Authorization"] = headers["Authorization"][:12] + "..."
        console.print(f"[bold]Headers:[/bold] {json.dumps(headers, indent=2)}")
        if params:
            console.print(f"[bold]Params:[/bold]  {json.dumps(params, indent=2)}")
        if data:
            console.print(f"[bold]Body:[/bold]    {json.dumps(data, indent=2, default=str)}")

    def get(self, endpoint: str, params: Optional[dict] = None) -> Any:
        """GET request, returns parsed JSON."""
        if _dry_run:
            self._print_dry_run("GET", self._url(endpoint), params=params)
            raise SystemExit(0)
        r = self.session.get(self._url(endpoint), params=params)
        r.raise_for_status()
        return r.json()

    def get_paginated(
        self, endpoint: str, params: Optional[dict] = None, limit: Optional[int] = None
    ) -> list:
        """GET with auto-pagination. Returns all results up to limit."""
        params = dict(params or {})
        page_size = min(limit or 100, 100)
        params["limit"] = page_size
        results = []
        offset = 0

        while True:
            params["offset"] = offset
            data = self.get(endpoint, params=params)

            if isinstance(data, list):
                results.extend(data)
                break

            page_results = data.get("results", [])
            results.extend(page_results)

            if limit and len(results) >= limit:
                results = results[:limit]
                break

            total = data.get("count", 0)
            offset += page_size
            if offset >= total or not page_results:
                break

        return results

    def post(self, endpoint: str, data: Optional[dict] = None) -> Any:
        """POST request (no trailing slash!)."""
        if _dry_run:
            self._print_dry_run("POST", self._url(endpoint), data=data)
            raise SystemExit(0)
        r = self.session.post(self._url(endpoint), json=data)
        r.raise_for_status()
        return r.json()

    def post_multipart(self, endpoint: str, data: Optional[dict] = None, files: Optional[list] = None) -> Any:
        """POST request with multipart/form-data (for file uploads)."""
        if _dry_run:
            self._print_dry_run("POST (multipart)", self._url(endpoint), data=data)
            raise SystemExit(0)
        r = self.session.post(self._url(endpoint), data=data, files=files)
        r.raise_for_status()
        return r.json()

    def patch(self, endpoint: str, data: Optional[dict] = None) -> Any:
        """PATCH request."""
        if _dry_run:
            self._print_dry_run("PATCH", self._url(endpoint), data=data)
            raise SystemExit(0)
        r = self.session.patch(self._url(endpoint), json=data)
        r.raise_for_status()
        return r.json()

    def delete(self, endpoint: str) -> bool:
        """DELETE request."""
        if _dry_run:
            self._print_dry_run("DELETE", self._url(endpoint))
            raise SystemExit(0)
        r = self.session.delete(self._url(endpoint))
        r.raise_for_status()
        return True
