---
name: eliza-organisation
description: Manage employees, org units, functions, memberships, skills, and skill assignments in ELIZA
---

# ELIZA Organisation

Manage the organisational structure: employees (Mitarbeitende), org units (Orgeinheiten), functions (Funktionen), memberships, skills, and skill assignments (Skill-Entries).

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List employees

```bash
myeliza organisation employees
myeliza organisation employees --search "müller" --limit 10
myeliza organisation employees -f json
```

Filters: `--search/-q` (full-text), `--limit/-l` (default 20)

Output columns: `id`, `vorname`, `nachname`, `email_business`, `funktion`

### Get employee details

```bash
myeliza organisation employee-get 3
myeliza organisation employee-get 3 -f json
```

Returns: `id`, `vorname`, `nachname`, `email_business`, `funktion`, `phone_business`, `phone_mobile`, `eintrittsdatum`

### Create employee

```bash
myeliza organisation employee-create --first-name "Max" --last-name "Muster"
myeliza organisation employee-create --first-name "Anna" --last-name "Schmidt" --email "anna@example.com" --phone "+41 44 123 45 67"
myeliza organisation employee-create --first-name "Thomas" --last-name "Leppert" --email "t.leppert@example.com" --user 7
```

Required: `--first-name`, `--last-name`
Optional: `--email`, `--phone`, `--mobile`, `--user` (user account ID to link)

### Update employee

```bash
myeliza organisation employee-update 3 --email "neue@email.com"
myeliza organisation employee-update 3 --user 5
myeliza organisation employee-update 3 --funktion "Teamleitung" --eintrittsdatum 2023-01-01
```

Required: `EMPLOYEE_ID` (positional argument)
Optional: `--first-name`, `--last-name`, `--email`, `--phone`, `--mobile`, `--user` (user account ID), `--funktion`, `--eintrittsdatum` (YYYY-MM-DD), `--austrittsdatum` (YYYY-MM-DD)

### List org units

```bash
myeliza organisation orgunits
myeliza organisation orgunits --search "IT" -f json
```

Filters: `--search/-q`, `--limit/-l` (default 50)

Output columns: `id`, `titel`, `description_clean`, `parent_name`

### Get org unit details

```bash
myeliza organisation orgunit-get 2
```

Returns: `id`, `title`, `description_clean`, `parent_name`

### Create org unit

```bash
myeliza organisation orgunit-create --title "IT-Abteilung"
myeliza organisation orgunit-create --title "Entwicklung" --parent 2 --description "Software-Entwicklung"
```

Required: `--title`
Optional: `--description/-d`, `--parent` (parent org unit ID)

### List functions

```bash
myeliza organisation functions
myeliza organisation functions -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `titel`, `description_clean`

### Get function details

```bash
myeliza organisation function-get 1
```

Returns: `id`, `titel`, `description_clean`

### List memberships

```bash
myeliza organisation memberships
myeliza organisation memberships --employee 3
myeliza organisation memberships --orgunit 2
```

Filters: `--employee` (employee ID), `--orgunit` (org unit ID), `--limit/-l` (default 50)

Output columns: `id`, `employee_name`, `orgunit_name`, `function_name`

### List skills

```bash
myeliza organisation skills
myeliza organisation skills --search "Logopädie"
myeliza organisation skills -f json
```

Filters: `--search/-q`, `--limit/-l` (default 50)

Output columns: `id`, `titel`

### List skill categories

```bash
myeliza organisation skill-categories
myeliza organisation skill-categories -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `titel`

### List skill assignments

```bash
myeliza organisation skill-entries
myeliza organisation skill-entries --employee 3
myeliza organisation skill-entries --skill 5
myeliza organisation skill-entries --search "Logopädie"
```

Filters: `--employee` (employee ID), `--skill` (skill ID), `--search/-q`, `--limit/-l` (default 20)

Output columns: `id`, `mitarbeiter_name`, `skill_titel`, `qualifikation_titel`, `datum`, `expiration_date`, `is_expired`

### Assign skill to employee

```bash
myeliza organisation skill-entry-add --employee 3 --skill 5
myeliza organisation skill-entry-add --employee 3 --skill 5 --qualifikation 2 --datum 2024-01-15 --expiration 2026-12-31
```

Required: `--employee`, `--skill`
Optional: `--qualifikation`, `--datum` (YYYY-MM-DD), `--expiration` (YYYY-MM-DD)

### Remove skill assignment

```bash
myeliza organisation skill-entry-remove 42
```

### List qualification levels

```bash
myeliza organisation qualifikationen
myeliza organisation qualifikationen -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `titel`, `code`

### Add qualification level

```bash
myeliza organisation qualifikation-add --title "Experte" --code "EXP"
```

Required: `--title`
Optional: `--code`

## Common Workflows

### Explore org structure

```bash
# List all org units
myeliza organisation orgunits -f json

# List employees in an org unit
myeliza organisation memberships --orgunit 2 -f json

# Get employee details
myeliza organisation employee-get 3 -f json
```

### Manage skill assignments

```bash
# List available skills and qualification levels
myeliza organisation skills -f json
myeliza organisation qualifikationen -f json

# Assign a skill to an employee
myeliza organisation skill-entry-add --employee 3 --skill 5 --qualifikation 2

# View all skill assignments for an employee
myeliza organisation skill-entries --employee 3 -f json

# Remove a skill assignment
myeliza organisation skill-entry-remove 42
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- API fields use German names: `vorname`, `nachname`, `titel`
