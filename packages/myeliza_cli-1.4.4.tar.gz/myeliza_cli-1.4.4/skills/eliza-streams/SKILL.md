---
name: eliza-streams
description: Manage news streams, messages, events, and journal entries in ELIZA (Newskanäle)
---

# ELIZA Streams

Manage news streams (Newskanäle), their messages, and events. Use for company announcements, project journals, team updates, and event logs.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List streams

```bash
myeliza streams list
myeliza streams list --limit 50 -f json
```

Output columns: `id`, `title`, `description`, `created_date`

### Get stream details

```bash
myeliza streams get 1
myeliza streams get 1 -f json
```

### Create a stream

```bash
myeliza streams create --title "Engineering Updates"
myeliza streams create --title "Team Blog" --description "Weekly updates" --visibility protected
myeliza streams create --title "Open Forum" --allow-comments --allow-likes
```

Required: `--title/-t`
Optional: `--description/-d`, `--visibility` (normal/protected), `--allow-comments`, `--allow-likes`

### Update a stream

```bash
myeliza streams update 1 --title "New Title"
myeliza streams update 1 --description "Updated description" --archived
```

Required: `stream_id` (positional)
Optional: `--title/-t`, `--description/-d`, `--visibility`, `--archived`

### Delete a stream

```bash
myeliza streams delete 1
myeliza streams delete 1 --force
```

Required: `stream_id` (positional)
Optional: `--force` (skip confirmation prompt)

### List messages

```bash
# All messages across streams
myeliza streams messages --limit 20 -f json

# Messages from a specific stream
myeliza streams messages --stream 1 --limit 10
```

Filters: `--stream/-s` (stream ID), `--limit/-l` (default 20)

Output columns: `id`, `stream_name`, `title`, `text_preview`, `created_date`

### Post a message

```bash
myeliza streams post --stream 1 --title "Deployment Update" --text "v2.0 deployed successfully"
```

Required: `--stream/-s`, `--title/-t`, `--text`

### List events

```bash
myeliza streams events
myeliza streams events --stream 1 --limit 10 -f json
```

Filters: `--stream/-s` (stream ID), `--limit/-l` (default 20)

Output columns: `id`, `title`, `stream_name`, `start_date`, `end_date`, `location`

### Get event details

```bash
myeliza streams event-get 42
myeliza streams event-get 42 -f json
```

### Create an event

```bash
myeliza streams event-create --stream 1 --title "Sprint Review" --start-date "2026-03-15T14:00:00"
myeliza streams event-create --stream 1 --title "All Hands" \
  --start-date "2026-03-20" --end-date "2026-03-20" \
  --text "Quarterly review" --location "Room A1" --whole-day --max-participants 50
```

Required: `--stream/-s`, `--title/-t`, `--start-date` (ISO format)
Optional: `--end-date`, `--text`, `--location`, `--whole-day`, `--max-participants`

## Common Workflows

### Post a project update

```bash
# Find the right stream
myeliza streams list -f json

# Post update
myeliza streams post --stream 3 --title "Sprint 12 Complete" \
  --text "All user stories delivered. Key changes: new auth flow, dashboard redesign."
```

### Create and manage a stream

```bash
# Create a new stream
myeliza streams create --title "Project Alpha" --description "Updates for Project Alpha"

# Update it later
myeliza streams update 10 --description "All updates for Project Alpha (archived)" --archived

# Delete when no longer needed
myeliza streams delete 10 --force
```

### Schedule an event

```bash
# Create an event in a stream
myeliza streams event-create --stream 1 --title "Team Standup" \
  --start-date "2026-03-12T09:00:00" --location "Teams Call"

# List upcoming events
myeliza streams events --stream 1 -f json
```

### Monitor stream activity

```bash
# Latest messages across all streams
myeliza streams messages --limit 20 -f json

# Latest from a specific stream
myeliza streams messages --stream 1 --limit 5 -f json
```

### Journal entry workflow

```bash
# Use a dedicated stream as a work journal
myeliza streams post --stream 5 --title "2026-03-10 Standup" \
  --text "Completed: API migration. Blocked: waiting for QA sign-off."
```

## Tips

- Use `--format json` (`-f json`) for structured output
- Use `--dry-run` to preview: `myeliza --dry-run streams post --stream 1 --title "Test" --text "Test"`
- Use `--instance` to target a specific instance
- Message text is plain text (not HTML)
- Streams are read-write — any authenticated user can post
- Use `--force` on delete to skip interactive confirmation

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_streams_list` | `limit?`, `instance?` | List all streams |
| `eliza_streams_messages_list` | `stream?`, `limit?`, `instance?` | List messages (optional stream filter) |
| `eliza_streams_messages_create` | `stream`, `title`, `text` | Post a message to a stream |
