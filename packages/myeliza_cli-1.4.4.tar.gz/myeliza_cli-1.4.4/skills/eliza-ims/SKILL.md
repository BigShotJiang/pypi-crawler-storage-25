---
name: eliza-ims
description: Manage integrated management system (IMS) systems, asset categories, and assets in ELIZA
---

# ELIZA IMS

Manage the Integrated Management System: systems, asset categories, and assets.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List IMS systems

```bash
myeliza ims systems
myeliza ims systems -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`, `description_clean`

### Get IMS system details

```bash
myeliza ims system-get 1
```

Returns: `id`, `title`, `description_clean`

### Create IMS system

```bash
myeliza ims system-create --title "ISO 9001 QMS"
myeliza ims system-create --title "ISO 14001 UMS" --description "Umweltmanagementsystem"
```

Required: `--title`
Optional: `--description/-d`

### List asset categories

```bash
myeliza ims categories
myeliza ims categories -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`, `description_clean`

### List assets

```bash
myeliza ims assets
myeliza ims assets --search "dokument" --category 1 --limit 10
myeliza ims assets -f json
```

Filters: `--search/-q` (full-text), `--category` (category ID), `--limit/-l` (default 20)

Output columns: `id`, `title`, `category_name`, `description_clean`

### Get asset details

```bash
myeliza ims asset-get 5
```

Returns: `id`, `title`, `category_name`, `description_clean`

## Common Workflows

### IMS overview

```bash
# List management systems
myeliza ims systems -f json

# List asset categories
myeliza ims categories -f json

# List assets in a category
myeliza ims assets --category 1 -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- IMS = Integriertes Managementsystem
