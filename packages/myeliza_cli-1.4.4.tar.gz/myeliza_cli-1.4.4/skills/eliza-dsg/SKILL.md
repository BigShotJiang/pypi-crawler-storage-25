---
name: eliza-dsg
description: Manage data protection (DSG/GDPR) activities, data categories, TOMs, subcontractors, and applications in ELIZA
---

# ELIZA DSG (Datenschutz)

Manage data protection compliance: processing activities, data categories, technical/organisational measures (TOMs), subcontractors, and applications.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List processing activities

```bash
myeliza dsg activities
myeliza dsg activities --search "personal" --limit 10
myeliza dsg activities -f json
```

Filters: `--search/-q` (full-text), `--limit/-l` (default 20)

Output columns: `id`, `title`, `purpose_clean`, `legal_basis`

### Get activity details

```bash
myeliza dsg activity-get 1
myeliza dsg activity-get 1 -f json
```

Returns: `id`, `title`, `description_clean`, `purpose_clean`, `legal_basis`

### Create processing activity

```bash
myeliza dsg activity-create --title "Bewerbermanagement"
myeliza dsg activity-create --title "Newsletter-Versand" --purpose "Marketing" --legal-basis "Einwilligung"
```

Required: `--title`
Optional: `--description/-d`, `--purpose`, `--legal-basis`

### List data categories

```bash
myeliza dsg datacategories
myeliza dsg datacategories -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`, `description_clean`

### List TOMs (Technical/Organisational Measures)

```bash
myeliza dsg toms
myeliza dsg toms -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`, `description_clean`

### List subcontractors

```bash
myeliza dsg subcontractors
myeliza dsg subcontractors -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`, `description_clean`

### List applications

```bash
myeliza dsg applications
myeliza dsg applications -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`, `description_clean`

## Common Workflows

### Data protection audit

```bash
# List all processing activities
myeliza dsg activities -f json

# Review activity details
myeliza dsg activity-get 1 -f json

# Check TOMs
myeliza dsg toms -f json

# Review subcontractors
myeliza dsg subcontractors -f json

# List data categories
myeliza dsg datacategories -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- DSG = Datenschutzgesetz (Swiss data protection law, similar to GDPR)
