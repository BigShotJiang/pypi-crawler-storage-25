---
name: eliza-businesscontext
description: Manage stakeholders (interested parties), issue types, and business context issues in ELIZA
---

# ELIZA Business Context

Manage business context analysis: interested parties (stakeholders), issue types, and context issues.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List interested parties

```bash
myeliza businesscontext parties
myeliza businesscontext parties --search "kunde" --limit 10
myeliza businesscontext parties -f json
```

Filters: `--search/-q` (full-text), `--limit/-l` (default 50)

Output columns: `id`, `title`, `interest`, `influence`

### Get interested party details

```bash
myeliza businesscontext party-get 2
```

Returns: `id`, `title`, `interest`, `influence`

### Create interested party

```bash
myeliza businesscontext party-create --title "Kunden"
myeliza businesscontext party-create --title "Lieferanten" --interest 2 --influence 1
```

Required: `--title`
Optional: `--interest` (level 0-3, default 0), `--influence` (level 0-3, default 0)

### List issue types

```bash
myeliza businesscontext issuetypes
myeliza businesscontext issuetypes -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`, `description_clean`

### List business context issues

```bash
myeliza businesscontext issues
myeliza businesscontext issues --search "markt" -f json
```

Filters: `--search/-q` (full-text), `--limit/-l` (default 20)

Output columns: `id`, `title`, `type_name`, `description_clean`

### Get issue details

```bash
myeliza businesscontext issue-get 1
```

Returns: `id`, `title`, `type_name`, `description_clean`

## Common Workflows

### Stakeholder analysis

```bash
# List all interested parties
myeliza businesscontext parties -f json

# Review context issues
myeliza businesscontext issues -f json

# Check issue types
myeliza businesscontext issuetypes -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- Interest and influence levels: 0 (none) to 3 (high)
