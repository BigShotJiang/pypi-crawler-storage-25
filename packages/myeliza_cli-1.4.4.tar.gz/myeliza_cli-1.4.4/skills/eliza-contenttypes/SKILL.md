---
name: eliza-contenttypes
description: ContentType-Lookup über die ELIZA REST API. Ermöglicht das Nachschlagen von content_type IDs für GenericForeignKey-Verknüpfungen (z.B. Massnahmen mit Objekten verknüpfen).
---

# eliza-contenttypes

ContentType-Lookup über die ELIZA REST API.

## Anwendungsfall

Wenn du ein Objekt nachträglich mit einer Massnahme (oder einem anderen Model mit GenericForeignKey) verknüpfen willst, brauchst du:
- `content_type` — die ID des Django ContentType für das Ziel-Model
- `object_id` — die ID des konkreten Objekts

Dieser Endpoint liefert die `content_type` ID.

## API Endpunkte

| Methode | Endpunkt | Beschreibung |
|---------|----------|--------------|
| GET | `/api/contenttype` | Liste aller ContentTypes |
| GET | `/api/contenttype/{id}` | ContentType-Details |

**Nur lesend (read-only).** Keine POST/PATCH/DELETE.

## Datenmodell

| Feld | Typ | Beschreibung |
|------|-----|--------------|
| `id` | int | ContentType-ID (für `content_type`-Felder) |
| `app_label` | string | Django App (z.B. `swot`, `issues`, `prozesse`) |
| `model` | string | Model-Name (z.B. `measure`, `issue`, `process`) |

## CLI-Befehle

```bash
# Alle ContentTypes auflisten
myeliza contenttypes list -i elizaag

# Nach Model-Name filtern
myeliza contenttypes list -i elizaag --model measure

# Nach App filtern
myeliza contenttypes list -i elizaag --app swot

# Suche
myeliza contenttypes list -i elizaag --search prozess

# Direkter Lookup eines Models
myeliza contenttypes lookup measure -i elizaag

# Details eines ContentType
myeliza contenttypes get 42 -i elizaag
```

## Beispiel: Massnahme mit Risiko verknüpfen

```bash
# 1. ContentType-ID für das Ziel-Model finden
myeliza contenttypes lookup estimate -i elizaag
# → id: 87, app_label: swot, model: estimate

# 2. Massnahme mit dem Objekt verknüpfen (PATCH)
# content_type: 87, object_id: <ID des Risikos>
```

## Filter-Optionen

- `app_label` — Exakter Match auf App-Name
- `model` — Exakter Match auf Model-Name
- `search` — Suche über app_label und model (enthält)
