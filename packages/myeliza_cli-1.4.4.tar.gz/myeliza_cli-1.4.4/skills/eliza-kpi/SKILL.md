---
name: eliza-kpi
description: Track KPIs (Kennzahlen), record measurements, and browse KPI folders
---

# ELIZA KPI

Track Key Performance Indicators (Kennzahlen) — list KPIs, browse folders, record measurements, and view measurement history. Use for metrics tracking, reporting, and automated data collection.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List KPIs

```bash
myeliza kpi list
myeliza kpi list --folder 550e8400-e29b-41d4-a716-446655440000 -f json
myeliza kpi list --limit 50
```

Filters: `--folder` (folder UUID), `--limit/-l` (default 20)

Output columns: `uuid`, `title`, `unit`, `target_value`, `folder_name`

### Get KPI details

```bash
myeliza kpi get 550e8400-e29b-41d4-a716-446655440000
myeliza kpi get 550e8400-e29b-41d4-a716-446655440000 -f json
```

Returns: `uuid`, `title`, `description`, `unit`, `target_value`, `folder_name`, `created_date`

### List KPI folders

```bash
myeliza kpi folders
myeliza kpi folders -f json --limit 100
```

Output columns: `uuid`, `title`, `description`

### Record a measurement

```bash
myeliza kpi record 550e8400-e29b-41d4-a716-446655440000 \
  --date 2026-03-10 --value 42.5
myeliza kpi record 550e8400-e29b-41d4-a716-446655440000 \
  --date 2026-03-10 --value 42.5 --description "Monthly customer satisfaction score"
```

Required: KPI UUID (positional), `--date/-d` (YYYY-MM-DD), `--value/-v` (numeric)

### List measurements

```bash
myeliza kpi measurements 550e8400-e29b-41d4-a716-446655440000
myeliza kpi measurements 550e8400-e29b-41d4-a716-446655440000 -f json --limit 50
```

Output columns: `id`, `date`, `value`, `description`, `created_date`

## Common Workflows

### Browse and record

```bash
# Find KPI folders
myeliza kpi folders -f json

# List KPIs in a folder
myeliza kpi list --folder <folder-uuid> -f json

# Record today's value
myeliza kpi record <kpi-uuid> --date 2026-03-10 --value 95.2
```

### Automated daily metric collection

```bash
# List all KPIs to find the right UUID
myeliza kpi list -f json

# Record multiple measurements
myeliza kpi record <kpi-uuid-1> --date 2026-03-10 --value 150 --description "Daily active users"
myeliza kpi record <kpi-uuid-2> --date 2026-03-10 --value 99.8 --description "Uptime percentage"
```

### Review measurement history

```bash
# Get KPI details including target
myeliza kpi get <kpi-uuid> -f json

# Get recent measurements
myeliza kpi measurements <kpi-uuid> -f json --limit 30
```

## Tips

- Use `--format json` (`-f json`) for structured output
- KPIs are identified by UUID, not integer ID
- Use `--dry-run` to preview: `myeliza --dry-run kpi record <uuid> --date 2026-03-10 --value 42`
- Use `--instance` to target a specific instance
- Values are numeric (float) — units are defined on the KPI itself

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_kpi_list` | `folder?`, `limit?`, `instance?` | List KPIs (optional folder filter) |
| `eliza_kpi_record` | `kpi`, `date`, `value`, `description?` | Record a measurement |
