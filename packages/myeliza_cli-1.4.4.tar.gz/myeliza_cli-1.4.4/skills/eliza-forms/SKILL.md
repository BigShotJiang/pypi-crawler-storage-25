---
name: eliza-forms
description: Manage form templates, folders, sections, and questions in ELIZA (Formulare)
---

# ELIZA Forms

Manage form templates (Formulare), their folders, sections, and questions. Use for surveys, checklists, audits, and structured data collection.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List templates

```bash
myeliza forms list
myeliza forms list --folder 1 --limit 10 -f json
```

Output columns: `id`, `title`, `description`, `created_date`

### Get template details

```bash
myeliza forms get 1
myeliza forms get 1 -f json
```

### Get full template (with sections and questions)

```bash
myeliza forms full 1
myeliza forms full 1 -f json
```

### Create a template

```bash
myeliza forms create --title "Safety Checklist"
myeliza forms create --title "Audit Form" --folder 1 --description "Annual audit template"
```

Required: `--title/-t`
Optional: `--folder`, `--description/-d`

### Delete a template

```bash
myeliza forms delete 1
myeliza forms delete 1 --force
```

### List folders

```bash
myeliza forms folders
```

### Create a folder

```bash
myeliza forms folder-create --title "Audits"
```

### List sections for a template

```bash
myeliza forms sections 1
myeliza forms sections 1 -f json
```

### List questions for a template

```bash
myeliza forms questions 1
myeliza forms questions 1 -f json
```

## Common Workflows

### Browse form structure

```bash
# List all templates
myeliza forms list -f json

# Get full template with sections and questions
myeliza forms full 1 -f json
```

### Organize templates

```bash
# Create a folder
myeliza forms folder-create --title "HR Forms"

# Create a template in that folder
myeliza forms create --title "Exit Interview" --folder 5 --description "Employee exit survey"
```

## Tips

- Use `--format json` (`-f json`) for structured output
- Use `myeliza forms full ID` to see the complete form structure
- Use `--instance` to target a specific instance
- Use `--force` on delete to skip interactive confirmation

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_forms_list` | `folder?`, `limit?`, `instance?` | List form templates |
| `eliza_forms_get` | `template_id`, `instance?` | Get full template with sections and questions |
