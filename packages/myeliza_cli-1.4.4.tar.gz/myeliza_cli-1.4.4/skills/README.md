# ELIZA CLI — Agent Skills

OpenClaw agent skills for the [ELIZA CLI](../README.md). Each skill provides structured reference documentation for AI agents interacting with ELIZA modules.

## Skills Index

| Skill | Directory | Description |
|-------|-----------|-------------|
| `eliza-issues` | [eliza-issues/](eliza-issues/SKILL.md) | Issue/ticket management — CRUD, followups, trackers (Meldekreise) |
| `eliza-streams` | [eliza-streams/](eliza-streams/SKILL.md) | News streams (Newskanäle), messages, journal entries |
| `eliza-kpi` | [eliza-kpi/](eliza-kpi/SKILL.md) | KPI tracking (Kennzahlen), measurements, folders |
| `eliza-time` | [eliza-time/](eliza-time/SKILL.md) | Time tracking (Zeiterfassung), work hours, absences |
| `eliza-dms` | [eliza-dms/](eliza-dms/SKILL.md) | Document management (Dokumentenmanagement), folders, types |
| `eliza-users` | [eliza-users/](eliza-users/SKILL.md) | User and group management (Benutzerverwaltung) |

## Usage

These skills are loaded automatically by OpenClaw agents when relevant ELIZA tasks are detected. Each skill documents:

- All CLI commands with examples and flags
- Common multi-step workflows
- MCP tool names and parameters for programmatic access
- Output format options (`--format json` for structured data)

## Global Flags

All commands support:

| Flag | Description |
|------|-------------|
| `--format json` / `-f json` | JSON output (preferred for agents) |
| `--format csv` / `-f csv` | CSV output |
| `--instance` / `-i` | Target a specific ELIZA instance |
| `--dry-run` | Preview HTTP request without executing (global: `eliza --dry-run ...`) |
