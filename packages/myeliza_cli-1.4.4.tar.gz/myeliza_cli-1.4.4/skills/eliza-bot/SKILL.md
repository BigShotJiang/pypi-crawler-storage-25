---
name: eliza-bot
description: Manage AI chat conversations and entries in ELIZA
---

# ELIZA Bot

Manage AI chat conversations: list, create, update chats, and view chat entries.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List chats

```bash
myeliza bot chats
myeliza bot chats --limit 10
myeliza bot chats -f json
```

Filters: `--limit/-l` (default 20)

Output columns: `uuid_short`, `title`, `ai_model_id`, `created`

### Get chat details

```bash
myeliza bot chat-get a1b2c3d4-e5f6-7890-abcd-ef1234567890
myeliza bot chat-get a1b2c3d4-e5f6-7890-abcd-ef1234567890 -f json
```

Returns: `uuid`, `title`, `system_role`, `ai_model_id`, `created`

### Create chat

```bash
myeliza bot chat-create --title "Support Assistant"
myeliza bot chat-create --title "Code Review Bot" --system-role "You are a code reviewer" --model-id 2
```

Required: `--title`
Optional: `--system-role`, `--model-id` (AI model ID)

### Update chat

```bash
myeliza bot chat-update a1b2c3d4-e5f6-7890-abcd-ef1234567890 --title "New Title"
myeliza bot chat-update a1b2c3d4-e5f6-7890-abcd-ef1234567890 --system-role "Updated system prompt"
```

Fields: `--title`, `--system-role`

### List chat entries

```bash
myeliza bot entries a1b2c3d4-e5f6-7890-abcd-ef1234567890
myeliza bot entries a1b2c3d4-e5f6-7890-abcd-ef1234567890 --limit 50 -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `role`, `content_short`, `created`

## Common Workflows

### Review chat history

```bash
# List all chats
myeliza bot chats -f json

# Get chat details
myeliza bot chat-get <uuid> -f json

# View conversation entries
myeliza bot entries <uuid> -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- Chat IDs are UUIDs (not integer IDs)
- `content_short` is truncated to 100 characters in table output
