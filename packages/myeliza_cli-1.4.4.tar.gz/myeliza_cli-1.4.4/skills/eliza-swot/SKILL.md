---
name: eliza-swot
description: Manage SWOT analysis, measures, estimates, and controls in ELIZA
---

# ELIZA SWOT

Manage SWOT analysis and risk management: measures (Massnahmen), estimates (Einschätzungen), and controls.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List measures

```bash
myeliza swot measures
myeliza swot measures --search "sicherheit" --status active --limit 10
myeliza swot measures -f json
```

Filters: `--search/-q` (full-text), `--status/-s`, `--limit/-l` (default 20)

Output columns: `id`, `titel`, `status`, `verantwortung_name`, `beschreibung_clean`

### Get measure details

```bash
myeliza swot measure-get 3
myeliza swot measure-get 3 -f json
```

Returns: `id`, `titel`, `beschreibung_clean`, `status`, `verantwortung_name`

### Create measure

```bash
myeliza swot measure-create --title "Backup-Strategie verbessern"
myeliza swot measure-create --title "Firewall Update" --status active --verantwortung 5 \
  --description "Firewall-Regeln aktualisieren"
```

Required: `--title`
Optional: `--description/-d`, `--status/-s`, `--verantwortung` (responsible person ID)

### List estimates

```bash
myeliza swot estimates
myeliza swot estimates --art S -f json
```

Filters: `--art` (S/W/O/T), `--limit/-l` (default 50)

Output columns: `id`, `titel`, `art`

### Get estimate details

```bash
myeliza swot estimate-get 2
```

Returns: `id`, `titel`, `art`

### List controls

```bash
myeliza swot controls
myeliza swot controls --measure 3 -f json
```

Filters: `--measure` (measure ID), `--limit/-l` (default 50)

Output columns: `id`, `titel`, `measure_name`

## Common Workflows

### SWOT analysis overview

```bash
# List all estimates by type
myeliza swot estimates --art S -f json  # Strengths
myeliza swot estimates --art W -f json  # Weaknesses
myeliza swot estimates --art O -f json  # Opportunities
myeliza swot estimates --art T -f json  # Threats

# Review measures and controls
myeliza swot measures -f json
myeliza swot controls --measure 3 -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- Estimate types: S (Strength), W (Weakness), O (Opportunity), T (Threat)
- API fields use German names: `titel`, `beschreibung`, `verantwortung`
