---
name: eliza-issues
description: Manage issues, tickets, and followups in ELIZA trackers (Meldekreise)
---

# ELIZA Issues

Manage issues (Meldungen) across trackers (Meldekreise). Supports full CRUD, followups/comments, and tracker listing. Use this for support tickets, incident reports, and task tracking.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List trackers (Meldekreise)

```bash
myeliza issues trackers
myeliza issues trackers -f json
```

Output columns: `id`, `title`, `state`

### List issues

```bash
myeliza issues list --tracker 2 --limit 10
myeliza issues list --tracker 2 --state new -f json
myeliza issues list --assigned 5 --limit 50
myeliza issues list --search "login error" --tracker 2
```

Filters: `--tracker/-t` (tracker ID), `--state/-s` (new|pending|accepted|active|effectiveness_check|resolved|rejected), `--assigned` (user ID), `--search/-q` (full-text), `--limit/-l` (default 20)

JSON output fields: `serial_number`, `state`, `title`, `contact_name`, `created_date`

### Get issue details

```bash
myeliza issues get 2530
myeliza issues get 2530 -f json
```

Returns: `id`, `serial_number`, `title`, `state`, `description_clean`, `contact_firstname`, `contact_lastname`, `contact_email`, `reference_number`, `proposed_solution`, `assigned_user`, `created_date`, `modified_date`, `closed_date`

### Create issue

```bash
myeliza issues create --tracker 2 --title "Server timeout on login" \
  --description "<p>Users report 504 errors</p>" \
  --contact-firstname "Max" --contact-lastname "Muster" \
  --contact-email "max@example.com"
```

Required: `--tracker/-t`, `--title`

### Update issue

```bash
myeliza issues update 2530 --state resolved
myeliza issues update 2530 --assign 5 --title "Updated title"
```

Fields: `--state/-s`, `--title`, `--assign` (user ID)

### List followups

```bash
myeliza issues followups 2530
myeliza issues followups 2530 -f json --limit 50
```

Output: `id`, `user_name`, `created_date`, `comment_clean`

### Add followup

```bash
myeliza issues followup-add 2530 --comment "Fix deployed to production"
```

## Common Workflows

### Triage new tickets

```bash
# List new issues in tracker 2
myeliza issues list -t 2 -s new -f json

# Review details
myeliza issues get 2530 -f json

# Assign and move to active
myeliza issues update 2530 --assign 5 --state active
myeliza issues followup-add 2530 --comment "Assigned to team lead for investigation"
```

### Resolve and document

```bash
# Add resolution comment
myeliza issues followup-add 2530 --comment "Root cause: memory leak in auth service. Deployed hotfix v2.1.3"

# Close the issue
myeliza issues update 2530 --state resolved
```

### Audit tracker activity

```bash
# Get all issues as JSON for analysis
myeliza issues list -t 2 -l 100 -f json

# Check followup trail
myeliza issues followups 2530 -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--dry-run` (global flag) to preview HTTP requests: `myeliza --dry-run issues list -t 2`
- Use `--instance` to target a specific ELIZA instance: `myeliza issues list -t 2 --instance iks2`
- Issue states: new -> pending -> accepted -> active -> effectiveness_check -> resolved (or rejected)
- Description field accepts HTML

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_trackers_list` | `instance?` | List all trackers |
| `eliza_issues_list` | `tracker?`, `state?`, `limit?`, `instance?` | List issues with filters |
| `eliza_issues_get` | `issue_id` | Get issue details |
| `eliza_issues_create` | `tracker`, `title`, `description?`, `contact_*?` | Create issue |
| `eliza_issues_update` | `issue_id`, `state?`, `title?`, `assigned_user?` | Update issue |
| `eliza_issues_followups` | `issue_id`, `limit?` | List followups |
| `eliza_issues_followup_add` | `issue_id`, `comment` | Add followup |

### Knowledge Base (Wissensartikel)

```bash
# Artikel auflisten (pro Tracker)
myeliza issues kb-list --tracker 2
myeliza issues kb-list --tracker 2 --search "passwort"
myeliza issues kb-list --status approved

# Artikel details
myeliza issues kb-get <uuid>

# Artikel erstellen
myeliza issues kb-create --tracker 2 --question "Wie..." --answer "Du kannst..."

# Artikel bearbeiten
myeliza issues kb-update <uuid> --answer "Neue Antwort"

# Issue zuordnen
myeliza issues kb-link <uuid> 2654

# Issue-IDs beim Erstellen/Aktualisieren setzen
myeliza issues kb-create --tracker 2 --question "..." --answer "..." --issues 2654,2655
myeliza issues kb-update <uuid> --issues 100,200,300

# Artikel löschen
myeliza issues kb-delete <uuid>
myeliza issues kb-delete <uuid> --yes  # ohne Bestätigung
```

Felder: `uuid`, `tracker_id`, `question`, `answer`, `status` (draft|verification|reviewed|approved), `related_issues`

### Tracker (Meldekreise) erstellen

```bash
# Auflisten
myeliza issues trackers
myeliza issues trackers -i elizaag

# Details
myeliza issues tracker-get 1

# Erstellen
myeliza issues tracker-create --title "Besondere Vorkommnisse" --description "Kritische Ereignisse"
myeliza issues tracker-create -t "Verbesserungsvorschläge" -i elizaag

# Aktualisieren
myeliza issues tracker-update 1 --title "Neuer Titel"
myeliza issues tracker-update 1 --state archived

# Löschen
myeliza issues tracker-delete 1
myeliza issues tracker-delete 1 --yes  # ohne Bestätigung
```


### Kategorien (Labels) pro Tracker

```bash
# Auflisten (pro Tracker)
myeliza issues categories --tracker 1
myeliza issues categories -t 1 -i elizaag

# Details
myeliza issues category-get 5

# Erstellen
myeliza issues category-create --tracker 1 --title "Pflege" --color "#4caf50"
myeliza issues category-create -t 2 --title "Dringend" --color "#f44336"

# Aktualisieren
myeliza issues category-update 5 --title "Neuer Titel" --color "#2196f3"

# Löschen
myeliza issues category-delete 5
myeliza issues category-delete 5 --yes
```

Felder: `id`, `tracker_id`, `title`, `color` (Hex oder CSS-Farbe)

### Farben für Kategorien (Materialize CSS)

Das `--color` Feld akzeptiert **Materialize CSS Klassennamen** (nicht Hex-Farben).
Die Farbe wird direkt als CSS-Klasse auf den Label-Button angewendet — weisser Text ist automatisch lesbar.

**Empfohlene Farben:**

| Farbe | Klasse | Verwendung |
|-------|--------|-----------|
| Rot | `red darken-3` | Kritisch, Abgelehnt |
| Orange | `orange darken-3` | Erheblich, In Prüfung |
| Grün | `green darken-2` | Leicht, Umgesetzt |
| Blau | `blue darken-3` | Bereiche, allgemein |
| Lila | `deep-purple darken-3` | Typen, Kategorien |
| Grau | `grey darken-2` | Neutral, Sonstiges |
| Teal | `teal darken-2` | Prozesse, Abläufe |
| Pink | `pink darken-3` | Spezial |

**Beispiele:**
```bash
myeliza issues category-create -t 1 --title "Schwere:Kritisch" --color "red darken-3"
myeliza issues category-create -t 1 --title "Schwere:Leicht" --color "green darken-2"
myeliza issues category-create -t 1 --title "Bereich:Pflege" --color "blue darken-3"
```

**Achtung:** Hex-Farben (`#ff0000`) funktionieren nicht — nur Materialize-Klassennamen verwenden.
