---
name: eliza-contracts
description: Manage contracts, partners, folders, types, and cashflows in ELIZA
---

# ELIZA Contracts

Manage contracts, partners, folders, contract types, and cashflows. Supports full contract lifecycle management.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List contracts

```bash
myeliza contracts list
myeliza contracts list --search "wartung" --status active --limit 10
myeliza contracts list -f json
```

Filters: `--search/-q` (full-text), `--status/-s`, `--limit/-l` (default 20)

Output columns: `id`, `title`, `partner_name`, `type_name`, `status`, `start_date`, `end_date`

### Get contract details

```bash
myeliza contracts get 5
myeliza contracts get 5 -f json
```

Returns: `id`, `title`, `partner_name`, `type_name`, `status`, `start_date`, `end_date`, `value`, `description_clean`

### Create contract

```bash
myeliza contracts create --title "Wartungsvertrag Server"
myeliza contracts create --title "SLA Partner X" --partner 3 --type 1 --status active \
  --start-date 2026-01-01 --end-date 2026-12-31 --value 50000
```

Required: `--title`
Optional: `--partner` (partner ID), `--type/-t` (type ID), `--status/-s`, `--start-date`, `--end-date`, `--value`, `--description/-d`

### Update contract

```bash
myeliza contracts update 5 --status expired
myeliza contracts update 5 --title "Updated title"
```

Fields: `--title`, `--status/-s`, `--description/-d`

### Delete contract

```bash
myeliza contracts delete 5
myeliza contracts delete 5 --yes
```

### List partners

```bash
myeliza contracts partners
myeliza contracts partners --search "AG" -f json
```

Filters: `--search/-q`, `--limit/-l` (default 50)

Output columns: `id`, `title`, `description_clean`

### Get partner details

```bash
myeliza contracts partner-get 3
```

Returns: `id`, `title`, `description_clean`

### List folders

```bash
myeliza contracts folders
```

Output columns: `id`, `title`

### List contract types

```bash
myeliza contracts types
```

Output columns: `id`, `title`

### List cashflows

```bash
myeliza contracts cashflows
myeliza contracts cashflows --contract 5 -f json
```

Filters: `--contract` (contract ID), `--limit/-l` (default 50)

Output columns: `id`, `title`, `amount`, `date`, `contract_name`

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- Use `--yes/-y` on delete to skip confirmation
