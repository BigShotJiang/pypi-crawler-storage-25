---
name: eliza-projects
description: Manage projects, tasks, milestones, and phases in ELIZA
---

# ELIZA Projects

Manage projects with tasks, milestones, and phases. Supports full project lifecycle management.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List projects

```bash
myeliza projects list
myeliza projects list --search "migration" --state active --limit 10
myeliza projects list -f json
```

Filters: `--search/-q` (full-text), `--state/-s` (planned|active|finished), `--limit/-l` (default 20)

Output columns: `id`, `title`, `state`, `manager_name`, `description_clean`

### Get project details

```bash
myeliza projects get 1
myeliza projects get 1 -f json
```

Returns: `id`, `title`, `description_clean`, `state`, `manager_name`, `created_date`

### Create project

```bash
myeliza projects create --title "Migration Phase 2"
myeliza projects create --title "Website Relaunch" --state active --manager 5 --description "Complete relaunch"
```

Required: `--title`
Optional: `--state/-s` (default: planned), `--manager` (manager ID), `--description/-d`

### Update project

```bash
myeliza projects update 1 --state active
myeliza projects update 1 --title "New title" --description "Updated"
```

Fields: `--title`, `--state/-s`, `--description/-d`

### Delete project

```bash
myeliza projects delete 1
myeliza projects delete 1 --yes
```

### List tasks

```bash
myeliza projects tasks
myeliza projects tasks --project 1 -f json
```

Filters: `--project` (project ID), `--limit/-l` (default 20)

Output columns: `id`, `title`, `status`, `project_name`, `assignee_name`

### Get task details

```bash
myeliza projects task-get 10
```

Returns: `id`, `title`, `status`, `project_name`, `assignee_name`

### List milestones

```bash
myeliza projects milestones
myeliza projects milestones --project 1 -f json
```

Filters: `--project` (project ID), `--limit/-l` (default 50)

Output columns: `id`, `title`, `date`, `project_name`

### List phases

```bash
myeliza projects phases
myeliza projects phases --project 1 -f json
```

Filters: `--project` (project ID), `--limit/-l` (default 50)

Output columns: `id`, `title`, `start_date`, `end_date`, `project_name`

## Common Workflows

### Project overview

```bash
# List active projects
myeliza projects list --state active -f json

# Get project tasks
myeliza projects tasks --project 1 -f json

# Check milestones
myeliza projects milestones --project 1 -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- Project states: planned -> active -> finished
