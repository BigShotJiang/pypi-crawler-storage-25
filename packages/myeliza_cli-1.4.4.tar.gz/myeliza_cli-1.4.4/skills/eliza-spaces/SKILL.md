---
name: eliza-spaces
description: Manage spaces, boards, cards, meetings, and meeting items in ELIZA
---

# ELIZA Spaces

Manage spaces, their boards, card lists, cards, meetings, and meeting items (Traktanden). Use for project management, team collaboration, and task tracking.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List spaces

```bash
myeliza spaces list
myeliza spaces list --state public --limit 10 -f json
myeliza spaces list --search "project"
```

Output columns: `id`, `title`, `state`, `description`

### Get space details

```bash
myeliza spaces get 1
myeliza spaces get 1 -f json
```

### Create a space

```bash
myeliza spaces create --title "Project Alpha"
myeliza spaces create --title "Team Board" --description "Team collaboration space" --state public
```

Required: `--title/-t`
Optional: `--description/-d`, `--state/-s` (public/private)

### Delete a space

```bash
myeliza spaces delete 1
myeliza spaces delete 1 --force
```

### List boards for a space

```bash
myeliza spaces boards 1
myeliza spaces boards 1 -f json
```

### List cards in a board

```bash
myeliza spaces cards --board 1
myeliza spaces cards --board 1 -f json
```

### Get card details

```bash
myeliza spaces card-get 42
myeliza spaces card-get 42 -f json
```

Returns: `id`, `title`, `description`, `cardlist`, `assigned_user`, `due_date`, `content_type`, `object_id`, `created_date`, `modified_date`

### Set card parent (gehört zu)

```bash
myeliza spaces card-set-parent 42 --content-type 15 --object-id 123
myeliza spaces card-set-parent 42 -ct 15 -oid 123 --instance iks2
```

Required: `--content-type/-ct` (Content Type ID), `--object-id/-oid` (Object ID)

### Clear card parent

```bash
myeliza spaces card-clear-parent 42
myeliza spaces card-clear-parent 42 --instance iks2
```

Removes the parent object association from a card.

### Create a card

```bash
myeliza spaces card-create --cardlist 1 --title "New Task"
myeliza spaces card-create --cardlist 1 --title "Bug Fix" --description "Fix login issue"
```

Required: `--cardlist`, `--title/-t`
Optional: `--description/-d`

### List card comments

```bash
myeliza spaces card-comments 42
myeliza spaces card-comments 42 --limit 50 -f json
```

Output columns: `id`, `user_name`, `created_date`, `comment_clean`

### Add card comment

```bash
myeliza spaces card-comment-add 42 --comment "Task completed"
myeliza spaces card-comment-add 42 --comment "See attachment" --file report.pdf
myeliza spaces card-comment-add 42 --file screenshot.png --file log.txt
```

Options: `--comment/-c` (text), `--file/-f` (file attachment, repeatable)
At least one of `--comment` or `--file` is required. Supports multipart file upload.

### List meetings for a space

```bash
myeliza spaces meetings 1
myeliza spaces meetings 1 -f json
```

### Create a meeting

```bash
myeliza spaces meeting-create --space 1 --title "Sprint Review"
myeliza spaces meeting-create --space 1 --title "Standup" --start "2026-03-12T09:00" --end "2026-03-12T09:30" --location "Room A"
```

Required: `--space`, `--title/-t`
Optional: `--description/-d`, `--start`, `--end`, `--location`

### Get meeting details

```bash
myeliza spaces meeting-get 1
myeliza spaces meeting-get 1 -f json
```

### List meeting items (Traktanden)

```bash
myeliza spaces items 1
myeliza spaces items 1 -f json
```

### Create a meeting item

```bash
myeliza spaces item-create --meeting 1 --title "Welcome"
myeliza spaces item-create --meeting 1 --title "Budget Review" --number 3 --text "Discuss Q2 budget"
```

Required: `--meeting`, `--title/-t`
Optional: `--number/-n`, `--text`, `--parent`

## Common Workflows

### Browse space structure

```bash
# List spaces
myeliza spaces list -f json

# Get boards for a space
myeliza spaces boards 1 -f json

# Get cards in a board
myeliza spaces cards --board 1 -f json
```

### Create tasks in a board

```bash
# Find the right board and card list
myeliza spaces boards 1 -f json
myeliza spaces cards --board 1 -f json

# Create a card
myeliza spaces card-create --cardlist 3 --title "Implement feature X" --description "Detailed description here"
```

### Browse meetings and agenda

```bash
# List meetings for a space
myeliza spaces meetings 1 -f json

# Get meeting items (Traktanden)
myeliza spaces items 1 -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output
- Use `--instance` to target a specific instance
- Use `--force` on delete to skip interactive confirmation
- Cards belong to card lists, which belong to boards, which belong to spaces
- Meeting items (Traktanden) belong to meetings, which belong to spaces

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_spaces_list` | `state?`, `search?`, `limit?`, `instance?` | List spaces |
| `eliza_spaces_get` | `space_id`, `instance?` | Get space details |
| `eliza_spaces_card_create` | `cardlist`, `title`, `description?` | Create a card |
| `eliza_spaces_meeting_create` | `space`, `title`, `description?`, `start?`, `end?`, `location?` | Create a meeting |
| `eliza_spaces_meetingitems` | `meeting_id` | List meeting items |
| `eliza_spaces_meetingitem_create` | `meeting`, `title`, `number?`, `text?` | Create a meeting item |
