---
name: eliza-glossar
description: Manage glossary entries in ELIZA (create, read, update, delete)
---

# ELIZA Glossar

Manage glossary entries. Supports full CRUD for terminology definitions.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List glossary entries

```bash
myeliza glossar list
myeliza glossar list --search "qualität" --limit 10
myeliza glossar list -f json
```

Filters: `--search/-q` (full-text), `--limit/-l` (default 20)

Output columns: `id`, `title`, `description_clean`

### Get glossary entry details

```bash
myeliza glossar get 5
myeliza glossar get 5 -f json
```

Returns: `id`, `title`, `description_clean`

### Create glossary entry

```bash
myeliza glossar create --title "SLA" --description "<p>Service Level Agreement</p>"
```

Required: `--title`
Optional: `--description/-d`

### Update glossary entry

```bash
myeliza glossar update 5 --title "SLA (updated)"
myeliza glossar update 5 --description "<p>New definition</p>"
```

Fields: `--title`, `--description/-d`

### Delete glossary entry

```bash
myeliza glossar delete 5
myeliza glossar delete 5 --yes
```

Use `--yes/-y` to skip confirmation prompt.

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- Description field accepts HTML
