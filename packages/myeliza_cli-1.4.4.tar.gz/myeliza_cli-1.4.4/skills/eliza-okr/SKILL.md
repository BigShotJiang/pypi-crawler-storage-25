---
name: eliza-okr
description: Manage OKR systems, periods, objectives, key results, and updates in ELIZA
---

# ELIZA OKR

Manage Objectives & Key Results: systems, periods, objectives, key results, and progress updates.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List OKR systems

```bash
myeliza okr systems
myeliza okr systems -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`, `vision_clean`, `mission_clean`

### Get OKR system details

```bash
myeliza okr system-get 1
```

Returns: `id`, `title`, `vision_clean`, `mission_clean`

### List periods

```bash
myeliza okr periods
myeliza okr periods --system 1 -f json
```

Filters: `--system` (system ID), `--limit/-l` (default 50)

Output columns: `id`, `title`, `start_date`, `end_date`

### List objectives

```bash
myeliza okr objectives
myeliza okr objectives --period 1 -f json
```

Filters: `--period` (period ID), `--limit/-l` (default 20)

Output columns: `id`, `title`, `period_name`, `description_clean`

### Get objective details

```bash
myeliza okr objective-get 5
```

Returns: `id`, `title`, `period_name`, `description_clean`

### List key results

```bash
myeliza okr results
myeliza okr results --objective 5 -f json
```

Filters: `--objective` (objective ID), `--limit/-l` (default 50)

Output columns: `id`, `title`, `objective_name`, `target_value`, `current_value`

### List updates

```bash
myeliza okr updates
myeliza okr updates --result 3 -f json
```

Filters: `--result` (result ID), `--limit/-l` (default 50)

Output columns: `id`, `date`, `value`, `result_name`

## Common Workflows

### Review OKR progress

```bash
# Get OKR system overview
myeliza okr systems -f json

# List current period objectives
myeliza okr objectives --period 1 -f json

# Check key results for an objective
myeliza okr results --objective 5 -f json

# View progress updates
myeliza okr updates --result 3 -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- Hierarchy: Systems > Periods > Objectives > Key Results > Updates
