---
name: eliza-users
description: Manage users and groups on an ELIZA instance — list, create, update, activate/deactivate, set password, send invite
---

# ELIZA Users

Manage users (Benutzer) and groups on an ELIZA instance. Use for user lookups, creating accounts, managing access, and resolving user IDs for other modules.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`
- Admin permissions (core.change_user, core.add_user) for management actions

## Commands

### List users

```bash
myeliza users list
myeliza users list --search "Muster" -f json
myeliza users list --limit 100
```

Filters: `--search/-q` (search by name), `--limit/-l` (default 50)

Output columns: `id`, `username`, `first_name`, `last_name`, `email`, `is_active`

### Get user details

```bash
myeliza users get 2
myeliza users get 2 -f json
```

Returns: `id`, `username`, `first_name`, `last_name`, `email`, `is_active`

### Create user

```bash
myeliza users create --username max@example.com --first-name Max --last-name Muster
myeliza users create --username max@example.com --first-name Max --last-name Muster --email max@example.com --groups 1,3
```

Creates a user **without password** (unusable password). Use `invite` or `set-password` to enable login.

Options: `--username/-u` (required), `--first-name` (required), `--last-name` (required), `--email/-e` (defaults to username), `--groups/-g` (comma-separated group IDs)

### Update user

```bash
myeliza users update 42 --first-name Maximilian
myeliza users update 42 --email new@example.com --is-active false
```

Options: `--first-name`, `--last-name`, `--email/-e`, `--is-active` (true/false)

### Deactivate user

```bash
myeliza users deactivate 42
```

Sets `is_active=False`. User cannot log in.

### Activate user

```bash
myeliza users activate 42
```

Sets `is_active=True`. Re-enables login.

### Set password

```bash
myeliza users set-password 42 --password "SecurePass123"
```

Admin-only. Sets the password for a user directly.

### Send invite

```bash
myeliza users invite 42
```

Sends an invitation email with a password reset link. User must have an email address.

### List groups

```bash
myeliza users groups
myeliza users groups --search "dms"    # Filter by name
myeliza users groups -f json --limit 100
```

Filters: `--search/-q` (search by group name, case-insensitive)

Output columns: `id`, `name`

Common group names: `dms_users` (DMS Lesen), `dms_admin` (DMS Admin), `dms_reviewers` (DMS Prüfen), `dms_approvers` (DMS Freigeben), `issues_users`, `issues_admin`, `streams_users`, `streams_admin`, `forms_users`, `forms_admin`

## Common Workflows

### Onboarding: Create and invite a user

```bash
# 1. Create user
myeliza users create -i elizaag --username max.muster@example.com --first-name Max --last-name Muster

# 2. Send invite email
myeliza users invite -i elizaag 42
```

### Find a user ID

```bash
# Search by name
myeliza users list --search "Max" -f json

# Use the ID in other commands
myeliza time add --user 2 --date 2026-03-10 --start 08:00 --end 12:00
myeliza issues update 2530 --assign 2
```

### Deactivate a departing employee

```bash
myeliza users deactivate -i elizaag 42
```

### Audit active users

```bash
# Get all users as JSON
myeliza users list --limit 200 -f json

# List all groups
myeliza users groups -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output
- User IDs are integers — used across modules (time, issues)
- Use `--instance` to target a specific instance
- The `is_active` field indicates whether the account is enabled
- New users have no password — use `invite` to send a setup email
- Superusers cannot be managed via the API

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_users_list` | `limit?`, `instance?` | List users |
| `eliza_users_get` | `user_id` | Get user details |
| `eliza_users_create` | `username`, `first_name`, `last_name`, `email?`, `groups?` | Create user |
| `eliza_users_update` | `user_id`, `first_name?`, `last_name?`, `email?`, `is_active?` | Update user |
| `eliza_users_deactivate` | `user_id` | Deactivate user |
| `eliza_users_activate` | `user_id` | Activate user |
| `eliza_users_set_password` | `user_id`, `password` | Set password |
| `eliza_users_invite` | `user_id` | Send invite email |
