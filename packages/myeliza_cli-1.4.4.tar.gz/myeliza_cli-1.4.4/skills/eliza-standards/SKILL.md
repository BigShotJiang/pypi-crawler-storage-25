---
name: eliza-standards
description: Manage standards (Normen), categories, and chapters in ELIZA
---

# ELIZA Standards

Manage standards (Normen), their categories, and chapters. Use for compliance tracking, regulatory standards, and normative references.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List standards

```bash
myeliza standards list
myeliza standards list --category 1 --limit 10 -f json
```

Output columns: `id`, `title`, `short_title`, `category_name`

### Get standard details

```bash
myeliza standards get 1
myeliza standards get 1 -f json
```

### Create a standard

```bash
myeliza standards create --title "ISO 9001:2015"
myeliza standards create --title "ISO 27001" --short-title "27001" --category 1 --description "Information security management"
```

Required: `--title/-t`
Optional: `--short-title`, `--category/-c`, `--description/-d`

### Delete a standard

```bash
myeliza standards delete 1
myeliza standards delete 1 --force
```

### List categories

```bash
myeliza standards categories
myeliza standards categories -f json
```

### List chapters for a standard

```bash
myeliza standards chapters 1
myeliza standards chapters 1 -f json
```

## Common Workflows

### Browse standards

```bash
# List categories
myeliza standards categories -f json

# List standards in a category
myeliza standards list --category 1 -f json

# Get standard details with chapters
myeliza standards get 1 -f json
myeliza standards chapters 1 -f json
```

### Create a standard

```bash
# Create in a category
myeliza standards create --title "DIN EN ISO 14001:2015" --short-title "14001" --category 2 --description "Environmental management systems"
```

## Tips

- Use `--format json` (`-f json`) for structured output
- Use `--instance` to target a specific instance
- Use `--force` on delete to skip interactive confirmation

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_standards_list` | `category?`, `limit?`, `instance?` | List standards |
| `eliza_standards_get` | `standard_id`, `instance?` | Get standard details |
