---
name: eliza-measuring
description: Manage measuring tools (Prüfmittel) with calibration tracking in ELIZA
---

# ELIZA Measuring

Manage measuring tools (Prüfmittel) inventory with calibration/inspection tracking.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List measuring tools

```bash
myeliza measuring list
myeliza measuring list --search "messchieber" --limit 10
myeliza measuring list -f json
```

Filters: `--search/-q` (full-text), `--limit/-l` (default 20)

Output columns: `id`, `title`, `serial_number`, `type_name`, `location`, `last_inspection`

### Get measuring tool details

```bash
myeliza measuring get 5
myeliza measuring get 5 -f json
```

Returns: `id`, `title`, `serial_number`, `type_name`, `inspection_interval`, `last_inspection`, `location`

### Create measuring tool

```bash
myeliza measuring create --title "Messschieber Digital"
myeliza measuring create --title "Drehmomentschlüssel" --serial-number "SN-12345" \
  --type 1 --interval 365 --last-inspection 2026-01-15 --location "Werkstatt A"
```

Required: `--title`
Optional: `--serial-number`, `--type/-t` (type ID), `--interval` (inspection interval in days), `--last-inspection` (YYYY-MM-DD), `--location`

### Update measuring tool

```bash
myeliza measuring update 5 --title "Updated name"
myeliza measuring update 5 --serial-number "SN-99999" --location "Lager B"
```

Fields: `--title`, `--serial-number`, `--location`

### Delete measuring tool

```bash
myeliza measuring delete 5
myeliza measuring delete 5 --yes
```

## Common Workflows

### Calibration audit

```bash
# List all measuring tools
myeliza measuring list -l 100 -f json

# Check specific tool's inspection date
myeliza measuring get 5 -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- `inspection_interval` is in days
- `last_inspection` date format: YYYY-MM-DD
