---
name: eliza-dms
description: Manage documents, folders, and document types in the ELIZA DMS (Dokumentenmanagement)
---

# ELIZA DMS

Manage documents (Dokumente), folders, and document types in the Document Management System. Use for document search, metadata management, folder organization, and document lifecycle tracking.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List documents

```bash
myeliza dms list
myeliza dms list --folder <folder-uuid> --state 4 -f json
myeliza dms list --type 3 --search "Handbuch" --limit 50
myeliza dms list --template
```

Filters: `--folder` (folder UUID), `--state/-s` (1-6), `--type/-t` (document type ID), `--search/-q` (title search), `--template` (filter templates), `--limit/-l` (default 20)

Document states: 1=Entwurf (Draft), 2=In Prüfung (Review), 3=Geprüft (Reviewed), 4=Freigegeben (Approved), 5=Veraltet (Outdated), 6=Archiviert (Archived)

Output columns: `uuid_short`, `doc_id`, `title`, `state_label`, `type_name`, `folder_name`, `modified`

### Get document details

```bash
myeliza dms get 550e8400-e29b-41d4-a716-446655440000
myeliza dms get 550e8400-e29b-41d4-a716-446655440000 -f json
```

Returns: `uuid`, `doc_id`, `title`, `description_clean`, `state_label`, `type_name`, `folder_name`, `author`, `version`, `file_url`, `created`, `modified`, `approval_date`, `valid_from`, `valid_to`, `next_review`

### Create document

```bash
myeliza dms create --title "Safety Manual v3" --folder <folder-uuid> --type 2
myeliza dms create --title "Report Q1" --description "Quarterly report" \
  --doc-id "DOC-2026-001" --file ./report.pdf
myeliza dms create --title "Template: Audit" --template
```

Required: `--title`. Optional: `--folder`, `--type/-t`, `--description/-d`, `--doc-id`, `--file` (upload), `--template`

### Update document

```bash
myeliza dms update 550e8400-e29b-41d4-a716-446655440000 --state 4
myeliza dms update 550e8400-e29b-41d4-a716-446655440000 --title "Updated Title" \
  --folder <new-folder-uuid>
```

Fields: `--title`, `--state/-s` (1-6), `--description/-d`, `--folder`

### Delete document

```bash
myeliza dms delete 550e8400-e29b-41d4-a716-446655440000 --yes
```

### List folders

```bash
myeliza dms folders
myeliza dms folders --root -f json
myeliza dms folders --search "Quality" --limit 100
```

Filters: `--root` (root folders only), `--search/-q`, `--limit/-l` (default 50)

Output columns: `uuid_short`, `title`, `parent_name`, `doc_count`

### Get folder details

```bash
myeliza dms folder-get <folder-uuid>
```

### Create folder

```bash
myeliza dms folder-create --title "Q1 Reports" --parent <parent-uuid>
myeliza dms folder-create --title "Root Folder" --description "Top-level folder"
```

### Delete folder

```bash
myeliza dms folder-delete <folder-uuid> --yes
```

### List document types

```bash
myeliza dms types -f json
```

Output columns: `id`, `title`, `description_clean`

### Create document type

```bash
myeliza dms type-create --title "Audit Report" --description "Internal audit documents"
```

### Delete document type

```bash
myeliza dms type-delete 5 --yes
```

### Export document as PDF or DOCX

```bash
# PDF with auto-detected instance logo and branding
myeliza dms export <doc-uuid> -i elizaag

# PDF with specific logo from DMS
myeliza dms export <doc-uuid> -i elizaag --logo <logo-dms-uuid>

# DOCX format
myeliza dms export <doc-uuid> -i elizaag -f docx

# Custom output path
myeliza dms export <doc-uuid> -i elizaag -o /path/to/output.pdf

# Export and upload back to DMS document
myeliza dms export <doc-uuid> -i elizaag --upload

# Custom branding (override auto-detect)
myeliza dms export <doc-uuid> -i elizaag --accent '#2e7d32' --org 'Firma AG' \
  --address 'Zürich' --subtitle 'Internes Dokument'

# No logo
myeliza dms export <doc-uuid> -i elizaag --logo none
```

Options: `--format/-f` (pdf|docx, default: pdf), `--output/-o`, `--logo` (DMS UUID, URL, file path, or 'none'), `--title`, `--subtitle`, `--accent` (hex color), `--org`, `--address`, `--footer`, `--upload`, `--instance/-i`

**Auto-detect:** Without `--logo`, the command fetches the instance logo via `/api/branding/` (Constance whitelabel config). Falls back to the default ELIZA logo if the endpoint is unavailable.

**Requirements:** `pandoc` and `weasyprint` for PDF, `pandoc` for DOCX. Optional: `python-docx` for DOCX branding (logo in header/footer).

## Common Workflows

### Find and review documents

```bash
# Browse folder structure
myeliza dms folders --root -f json

# List documents in a folder
myeliza dms list --folder <folder-uuid> -f json

# Get document details
myeliza dms get <doc-uuid> -f json
```

### Export document for sharing

```bash
# Generate branded PDF from markdown description
myeliza dms export <doc-uuid> -i elizaag --upload

# Generate for customer instance (auto-detects their whitelabel logo)
myeliza dms export <doc-uuid> -i ruetimattli --upload
```

### Document approval workflow

```bash
# Find documents in review
myeliza dms list --state 2 -f json

# Approve a document
myeliza dms update <doc-uuid> --state 4

# Archive outdated version
myeliza dms update <old-doc-uuid> --state 6
```

### Organize documents

```bash
# Create folder structure
myeliza dms folder-create --title "2026" --description "Documents for 2026"
myeliza dms folder-create --title "Q1" --parent <2026-folder-uuid>

# Move document to new folder
myeliza dms update <doc-uuid> --folder <q1-folder-uuid>
```

## Tips

- Use `--format json` (`-f json`) for structured output
- Documents and folders use UUIDs, document types use integer IDs
- Use `--dry-run` to preview: `myeliza --dry-run dms create --title "Test"`
- Use `--instance` to target a specific instance
- File upload supports any file type via `--file`
- Delete operations require `--yes` or interactive confirmation

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_dms_documents` | `folder_uuid?`, `state?`, `type_id?`, `search?`, `limit?` | List documents |
| `eliza_dms_document_get` | `uuid` | Get document details |
| `eliza_dms_folders` | `root_only?`, `limit?`, `instance?` | List folders |
| `eliza_dms_doctypes` | `instance?` | List document types |
| `eliza_dms_export` | `uuid`, `format?`, `logo?`, `upload?`, `instance?` | Export document as PDF/DOCX |
