---
name: eliza-tutorials
description: Manage e-learning courses, lessons, sections, and folders in ELIZA
---

# ELIZA Tutorials

Manage e-learning content: folders, courses, lessons, and sections.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List folders

```bash
myeliza tutorials folders
myeliza tutorials folders -f json
```

Filters: `--limit/-l` (default 50)

Output columns: `id`, `title`

### List courses

```bash
myeliza tutorials courses
myeliza tutorials courses --search "onboarding" --folder 1 --limit 10
myeliza tutorials courses -f json
```

Filters: `--search/-q` (full-text), `--folder` (folder ID), `--limit/-l` (default 20)

Output columns: `id`, `title`, `folder_name`, `description_clean`

### Get course details

```bash
myeliza tutorials course-get 1
myeliza tutorials course-get 1 -f json
```

Returns: `id`, `title`, `description_clean`, `folder_name`

### Create course

```bash
myeliza tutorials course-create --title "Onboarding"
myeliza tutorials course-create --title "Safety Training" --folder 1 --description "Annual safety course"
```

Required: `--title`
Optional: `--folder` (folder ID), `--description/-d`

### List lessons

```bash
myeliza tutorials lessons
myeliza tutorials lessons --course 1 -f json
```

Filters: `--course` (course ID), `--limit/-l` (default 50)

Output columns: `id`, `title`, `course_name`

### Get lesson details

```bash
myeliza tutorials lesson-get 3
```

Returns: `id`, `title`, `course_name`

### List sections

```bash
myeliza tutorials sections
myeliza tutorials sections --lesson 3 -f json
```

Filters: `--lesson` (lesson ID), `--limit/-l` (default 50)

Output columns: `id`, `title`, `lesson_name`

## Common Workflows

### Browse course structure

```bash
# List folders
myeliza tutorials folders -f json

# List courses in a folder
myeliza tutorials courses --folder 1 -f json

# Get lessons for a course
myeliza tutorials lessons --course 1 -f json

# Get sections for a lesson
myeliza tutorials sections --lesson 3 -f json
```

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
- Hierarchy: Folders > Courses > Lessons > Sections
