---
name: eliza-processes
description: Manage processes (Prozesse), process steps, labels, and state transitions in ELIZA
---

# ELIZA Processes

Manage processes (Prozesse), their steps, labels, and state transitions. Use for process management, workflow definitions, and quality management.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List processes

```bash
myeliza processes list
myeliza processes list --state draft --limit 10 -f json
myeliza processes list --search "quality"
```

Output columns: `id`, `nummer`, `titel`, `state`, `color`

### Get process details

```bash
myeliza processes get 1
myeliza processes get 1 -f json
```

### Create a process

```bash
myeliza processes create --nummer "P-001" --title "Quality Review"
myeliza processes create --nummer "P-002" --title "Onboarding" --description "New employee onboarding" --color "#FF5733" --parent 1
```

Required: `--nummer/-n`, `--title/-t`
Optional: `--description/-d`, `--color`, `--text-color`, `--parent`

### Update a process

```bash
myeliza processes update 1 --title "Updated Title"
myeliza processes update 1 --description "New description" --color "#00FF00"
```

### Delete a process

```bash
myeliza processes delete 1
myeliza processes delete 1 --force
```

### List process steps

```bash
myeliza processes steps 1
myeliza processes steps 1 -f json
```

### Create a process step

```bash
myeliza processes step-create --process 1 --nummer "1.1" --title "Initial Review" --text "Review documents" --result "Approved/Rejected"
```

Required: `--process/-p`, `--nummer/-n`, `--title/-t`
Optional: `--text`, `--result`

### List labels

```bash
myeliza processes labels
```

### Show available transitions

```bash
myeliza processes transitions 1
```

### Execute a transition

```bash
myeliza processes transition 1 --action approve --comment "Looks good"
```

Required: `process_id` (positional), `--action/-a`
Optional: `--comment/-c`

## Common Workflows

### Create a process with steps

```bash
# Create process
myeliza processes create --nummer "P-010" --title "Document Review Process"

# Add steps
myeliza processes step-create --process 10 --nummer "1" --title "Submit" --text "Author submits document"
myeliza processes step-create --process 10 --nummer "2" --title "Review" --text "Reviewer checks content"
myeliza processes step-create --process 10 --nummer "3" --title "Approve" --text "Manager approves"
```

### Transition a process

```bash
# Check available transitions
myeliza processes transitions 1

# Execute transition
myeliza processes transition 1 --action approve --comment "All checks passed"
```

## Tips

- Use `--format json` (`-f json`) for structured output
- Use `--dry-run` to preview: `myeliza --dry-run processes create --nummer "P-001" --title "Test"`
- Use `--instance` to target a specific instance
- Use `--force` on delete to skip interactive confirmation

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_processes_list` | `state?`, `search?`, `limit?`, `instance?` | List processes |
| `eliza_processes_get` | `process_id`, `instance?` | Get process details |
| `eliza_processes_create` | `nummer`, `titel`, `beschreibung?`, `color?`, `parent?` | Create a process |
