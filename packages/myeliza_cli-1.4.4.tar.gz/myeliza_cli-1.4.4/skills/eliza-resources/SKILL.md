---
name: eliza-resources
description: Manage resource inventory and allocations in ELIZA
---

# ELIZA Resources

Manage resource inventory (Inventar) and allocations.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List resources

```bash
myeliza resources list
myeliza resources list --search "laptop" --limit 10
myeliza resources list -f json
```

Filters: `--search/-q` (full-text), `--limit/-l` (default 20)

Output columns: `id`, `title`, `type_name`, `serial_number`, `location_name`

### Get resource details

```bash
myeliza resources get 3
myeliza resources get 3 -f json
```

Returns: `id`, `title`, `type_name`, `serial_number`, `location_name`

### Create resource

```bash
myeliza resources create --title "Laptop Dell XPS 15"
myeliza resources create --title "Beamer Epson" --type 2 --serial-number "EP-001" --location 1
```

Required: `--title`
Optional: `--type/-t` (type ID), `--serial-number`, `--location` (location ID)

### Update resource

```bash
myeliza resources update 3 --title "Updated name"
myeliza resources update 3 --serial-number "NEW-SN"
```

Fields: `--title`, `--serial-number`

### Delete resource

```bash
myeliza resources delete 3
myeliza resources delete 3 --yes
```

### List allocations

```bash
myeliza resources allocations
myeliza resources allocations --resource 3 -f json
```

Filters: `--resource` (resource ID), `--limit/-l` (default 50)

Output columns: `id`, `resource_name`, `start_date`, `end_date`

### Get allocation details

```bash
myeliza resources allocation-get 1
```

Returns: `id`, `resource_name`, `start_date`, `end_date`

## Tips

- Use `--format json` (`-f json`) for structured output — agents should prefer this
- Use `--instance` to target a specific ELIZA instance
