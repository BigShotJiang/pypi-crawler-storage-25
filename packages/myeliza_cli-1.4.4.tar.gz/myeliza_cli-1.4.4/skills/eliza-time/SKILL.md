---
name: eliza-time
description: Track work hours, time entries, and absences in ELIZA (Zeiterfassung)
---

# ELIZA Time

Manage time tracking (Zeiterfassung) — log work hours, list time entries, and view absences. Use for timesheet management, work hour reporting, and absence tracking.

## Prerequisites

- ELIZA CLI installed and configured (`myeliza auth status` to verify)
- Instance configured via `myeliza auth login`

## Commands

### List work time entries

```bash
myeliza time list
myeliza time list --user 2 --date 2026-03-10 -f json
myeliza time list --user 2 --limit 50
```

Filters: `--user/-u` (user ID), `--date/-d` (YYYY-MM-DD), `--limit/-l` (default 20)

Output columns: `id`, `user_name`, `date`, `start_time`, `end_time`, `type_name`, `description`

### Add work time

```bash
myeliza time add --user 2 --date 2026-03-10 --start 08:00 --end 12:00
myeliza time add --user 2 --date 2026-03-10 --start 13:00 --end 17:30 \
  --type 1 --description "Feature development"
myeliza time add --user 2 --date 2026-03-10 --start 08:00 --end 10:00 \
  --type 5 --description "Client visit travel"
```

Required: `--user/-u`, `--date/-d` (YYYY-MM-DD), `--start` (HH:MM), `--end` (HH:MM)

Optional: `--type/-t` (1=work, 5=travel; default 1), `--description`

### List absences

```bash
myeliza time absences
myeliza time absences --user 2 -f json
myeliza time absences --limit 50
```

Filters: `--user/-u` (user ID), `--limit/-l` (default 20)

Output columns: `id`, `user`, `start_date`, `end_date`, `type`, `state`

## Common Workflows

### Log a full work day

```bash
# Morning block
myeliza time add --user 2 --date 2026-03-10 --start 08:00 --end 12:00 \
  --description "Sprint planning + development"

# Afternoon block
myeliza time add --user 2 --date 2026-03-10 --start 13:00 --end 17:00 \
  --description "Code review + deployment"
```

### Review a user's timesheet

```bash
# List entries for a specific date
myeliza time list --user 2 --date 2026-03-10 -f json

# List recent entries
myeliza time list --user 2 --limit 30 -f json

# Check absences
myeliza time absences --user 2 -f json
```

### Bulk time entry

```bash
# Log time for multiple days
for d in 2026-03-{10..14}; do
  eliza time add --user 2 --date $d --start 08:00 --end 12:00
  eliza time add --user 2 --date $d --start 13:00 --end 17:00
done
```

## Tips

- Use `--format json` (`-f json`) for structured output
- Use `--dry-run` to preview: `myeliza --dry-run time add --user 2 --date 2026-03-10 --start 08:00 --end 12:00`
- Time format is HH:MM (24-hour)
- Type IDs: 1 = work (Arbeit), 5 = travel (Reise)
- Use `--instance` to target a specific instance
- You need the user ID — use `myeliza users list` to find it

## MCP Tools

| Tool | Parameters | Description |
|------|-----------|-------------|
| `eliza_time_list` | `user?`, `date?`, `limit?`, `instance?` | List work time entries |
| `eliza_time_add` | `user`, `date`, `start_time`, `end_time`, `type?`, `description?` | Add a work time entry |

### Public Holidays (Feiertage)

```bash
# List all public holidays
myeliza time holidays --instance elizaag

# Create a public holiday (full day off)
myeliza time holiday-create --instance elizaag --date 2026-04-03 --title "Karfreitag" --factor 0.0

# Create a half-day holiday
myeliza time holiday-create --instance elizaag --date 2026-04-02 --title "Gründonnerstag" --factor 0.5 --description "Nachmittag frei"

# Delete a public holiday
myeliza time holiday-delete 42 --instance elizaag
```

Factor values:
- `0.0` = ganzer Tag frei (Karfreitag, Weihnachten etc.)
- `0.5` = halber Tag frei (Gründonnerstag, Heiligabend etc.)
- `1.0` = kein freier Tag (normaler Arbeitstag, nur zur Markierung)
