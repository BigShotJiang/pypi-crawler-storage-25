# ELIZA CLI

Command-line interface for the [ELIZA](https://eliza.swiss) platform — for humans and AI agents.

> **New here?** Check out the [Quick Start Guide](QUICKSTART.md).

## Installation

```bash
# From PyPI
pip install myeliza-cli

# Or with uv
uv tool install myeliza-cli

# Or from source
git clone https://gitlab.com/eliza.swiss/myeliza-cli.git
cd myeliza-cli && uv sync
```

## Quick Start

```bash
# Configure an instance
myeliza auth login --instance elizaag --url https://eliza.myeliza.ch/api --token YOUR_TOKEN --default

# Check connection
myeliza auth status

# List support tickets
myeliza issues list --tracker 2 --limit 10

# Get issue details
myeliza issues get 2530

# Add a followup
myeliza issues followup-add 2530 --comment "Fix deployed"

# List users
myeliza users list

# Add work time
myeliza time add --user 2 --date 2026-03-10 --start 08:00 --end 12:00

# List news streams
myeliza streams list

# Post a message to a stream
myeliza streams messages create --stream 1 --title "Update" --text "Deployed v2.0"

# List KPIs
myeliza kpi list

# Record a KPI measurement
myeliza kpi record 550e8400-e29b-41d4-a716-446655440000 --date 2026-03-10 --value 42
```

## Output Formats

```bash
myeliza issues list -t 2 -l 5              # Rich table (default)
myeliza issues list -t 2 -l 5 -f json      # JSON (for scripting/agents)
myeliza issues list -t 2 -l 5 -f csv       # CSV
```

## Dry Run

```bash
# Show the HTTP request without executing it
myeliza --dry-run issues list --tracker 2
```

## Configuration

Config is stored in `~/.myeliza/config.yaml`:

```yaml
default: elizaag
instances:
  elizaag:
    url: https://eliza.myeliza.ch/api
    token: your-token-here
  iks2:
    url: https://iks2.myeliza.ch/api
    token: your-token-here
```

### Environment Variables (backward compatible)

```bash
export ELIZA_ELIZAAG_URL=https://eliza.myeliza.ch/api
export ELIZA_ELIZAAG_TOKEN=your-token
export ELIZA_DEFAULT=elizaag
```

## AI Agent Integration

### Bundled Skills (API Documentation)

The package includes 24 skill modules with detailed API documentation, examples and scripts. AI agents can discover them automatically:

```bash
# Find the skills directory
myeliza skills-path
# → /home/user/.local/lib/python3.12/site-packages/myeliza_cli/skills/

# Each skill contains a SKILL.md with:
# - API endpoints and fields
# - CLI examples
# - Python scripts for common tasks
```

**Agent workflow:**
1. `pip install myeliza-cli` — install the package
2. `myeliza auth login ...` — configure an ELIZA instance
3. `myeliza skills-path` — find the skill documentation
4. Read the relevant `SKILL.md` files — understand the API
5. Use `myeliza` commands or MCP tools — interact with ELIZA

### MCP Server (Model Context Protocol)

The CLI includes a built-in [Model Context Protocol](https://modelcontextprotocol.io) server, allowing AI agents to interact with ELIZA directly.

### With Claude Code

```bash
# Register ELIZA as MCP tool provider
claude mcp add myeliza -- myeliza mcp serve

# Now Claude Code can use ELIZA tools natively:
# "List the latest support tickets" → calls eliza_issues_list
# "Create an issue in tracker 2" → calls eliza_issues_create
```

### With OpenClaw

Add to your OpenClaw config (`openclaw.json`):

```json
{
  "mcp": {
    "servers": {
      "myeliza": {
        "command": "myeliza",
        "args": ["mcp", "serve"]
      }
    }
  }
}
```

### Available MCP Tools (33)

| Tool | Description |
|------|-------------|
| `eliza_trackers_list` | List all trackers (Meldekreise) |
| `eliza_issues_list` | List issues with optional filters (tracker, state, limit) |
| `eliza_issues_get` | Get issue details by ID |
| `eliza_issues_create` | Create a new issue |
| `eliza_issues_update` | Update issue (state, title, assignment) |
| `eliza_issues_followups` | List followups for an issue |
| `eliza_issues_followup_add` | Add a followup comment |
| `eliza_dms_documents` | List documents (optional folder, type filter) |
| `eliza_dms_document_get` | Get document details by ID |
| `eliza_dms_folders` | List DMS folders |
| `eliza_dms_doctypes` | List document types |
| `eliza_users_list` | List users |
| `eliza_users_get` | Get user details |
| `eliza_time_list` | List work time entries |
| `eliza_time_add` | Add a work time entry |
| `eliza_streams_list` | List streams (Newskanäle) |
| `eliza_streams_messages_list` | List stream messages (optional stream filter) |
| `eliza_streams_messages_create` | Create a message in a stream |
| `eliza_kpi_list` | List KPIs (optional folder filter) |
| `eliza_kpi_record` | Record a KPI measurement |
| `eliza_processes_list` | List processes (filter by state, search) |
| `eliza_processes_get` | Get process details by ID |
| `eliza_processes_create` | Create a new process |
| `eliza_forms_list` | List form templates (optional folder filter) |
| `eliza_forms_get` | Get full template with sections and questions |
| `eliza_spaces_list` | List spaces (filter by state, search) |
| `eliza_spaces_get` | Get space details by ID |
| `eliza_spaces_card_create` | Create a card in a board card list |
| `eliza_spaces_meeting_create` | Create a meeting in a space |
| `eliza_spaces_meetingitems` | List meeting items (Traktanden) |
| `eliza_spaces_meetingitem_create` | Create a meeting item |
| `eliza_standards_list` | List standards (optional category filter) |
| `eliza_standards_get` | Get standard details by ID |

All MCP responses are **compact JSON** optimized for LLM consumption — HTML stripped, base64 images removed, nested objects flattened.

### Testing the MCP Server

```bash
# Start server manually (stdio)
myeliza mcp serve

# Test tools programmatically
python3 -c "
import asyncio
from myeliza_cli.mcp_server import call_tool
result = asyncio.run(call_tool('eliza_trackers_list', {}))
print(result[0].text)
"
```

## Commands

| Command | Status | Description |
|---------|--------|-------------|
| `myeliza auth` | ✅ | Authentication & instance management |
| `myeliza issues` | ✅ | Issues / Meldungen (CRUD + followups + trackers) |
| `myeliza users` | ✅ | Users & groups |
| `myeliza time` | ✅ | Time tracking & absences |
| `myeliza mcp` | ✅ | MCP server for AI agents |
| `myeliza dms` | ✅ | Document management |
| `myeliza streams` | ✅ | News streams & events |
| `myeliza kpi` | ✅ | KPIs / Kennzahlen |
| `myeliza processes` | ✅ | Process management (CRUD + steps + transitions) |
| `myeliza spaces` | ✅ | Spaces (boards, cards, comments, meetings) |
| `myeliza forms` | ✅ | Forms (templates, sections, questions) |
| `myeliza standards` | ✅ | Standards / Normen (categories, chapters) |
| `myeliza glossar` | ✅ | Glossary (CRUD) |
| `myeliza organisation` | ✅ | Employees, org units, functions, memberships |
| `myeliza contracts` | ✅ | Contracts, partners, cashflows |
| `myeliza projects` | ✅ | Projects, tasks, milestones, phases |
| `myeliza tutorials` | ✅ | E-learning courses, lessons, sections |
| `myeliza okr` | ✅ | OKR (objectives, key results, updates) |
| `myeliza swot` | ✅ | SWOT / risk management (measures, controls) |
| `myeliza dsg` | ✅ | Data protection (activities, TOMs, categories) |
| `myeliza bot` | ✅ | AI chat conversations |
| `myeliza measuring` | ✅ | Measuring tools / calibration tracking |
| `myeliza resources` | ✅ | Resource inventory & allocations |
| `myeliza businesscontext` | ✅ | Stakeholders & business context |
| `myeliza ims` | ✅ | Integrated management system (assets) |

## Architecture

```
src/myeliza_cli/
├── main.py          # Typer app with subcommand groups + --dry-run
├── client.py        # REST API client (auto-pagination, multi-instance, dry-run)
├── config.py        # Config management (~/.myeliza/config.yaml + env vars)
├── output.py        # Formatters (Rich table, JSON, CSV)
├── mcp_server.py           # MCP server (stdio transport, 33 tools)
└── commands/
    ├── auth.py              # login, logout, status, instances
    ├── issues.py            # list, get, create, update, followups, trackers
    ├── users.py             # list, get, groups
    ├── time.py              # list, add, absences
    ├── dms.py               # documents, folders, document types
    ├── streams.py           # streams, messages, events
    ├── kpi.py               # KPIs, folders, measurements
    ├── processes.py         # processes, steps, labels, transitions
    ├── forms.py             # templates, folders, sections, questions
    ├── spaces.py            # spaces, boards, cards, comments, meetings
    ├── standards.py         # standards, categories, chapters
    ├── glossar.py           # glossary entries
    ├── organisation.py      # employees, org units, functions
    ├── contracts.py         # contracts, partners, cashflows
    ├── projects.py          # projects, tasks, milestones, phases
    ├── tutorials.py         # e-learning courses, lessons
    ├── okr.py               # objectives & key results
    ├── swot.py              # SWOT measures, estimates, controls
    ├── dsg.py               # data protection (DSG/GDPR)
    ├── bot.py               # AI chat conversations
    ├── measuring.py         # measuring tools, calibration
    ├── resources.py         # resource inventory, allocations
    ├── businesscontext.py   # stakeholders, context issues
    └── ims.py               # integrated management system
```

## License

MIT — [ELIZA AG](https://eliza.swiss)
