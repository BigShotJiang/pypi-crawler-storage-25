# ELIZA CLI in n8n Workflows

Die ELIZA CLI lässt sich in [n8n](https://n8n.io) Workflows über den **Execute Command**-Node einbinden. Damit können ELIZA-Daten (Issues, Verträge, Zeiterfassung etc.) in Automatisierungen verwendet werden.

## Voraussetzungen

- `uv` installiert auf dem n8n-Server
- `eliza-cli` Repo geklont
- `.eliza/config.yaml` konfiguriert (oder Umgebungsvariablen)

### Installation auf dem n8n-Server

```bash
# Repo klonen
git clone https://gitlab.com/eliza.swiss/eliza-cli.git /opt/eliza-cli

# Config erstellen
mkdir -p /opt/eliza-cli/.eliza
cat > /opt/eliza-cli/.eliza/config.yaml << EOF
default: prod
instances:
  prod:
    url: https://meine-instanz.myeliza.ch/api
    token: <API-TOKEN>
EOF
```

### Alternative: Umgebungsvariablen

Statt einer config.yaml können Instanzen auch über Umgebungsvariablen konfiguriert werden:

```
ELIZA_PROD_URL=https://meine-instanz.myeliza.ch/api
ELIZA_PROD_TOKEN=<API-TOKEN>
```

## Grundprinzip

Alle CLI-Befehle mit `--format json` liefern JSON-Output, der in n8n direkt weiterverarbeitet werden kann:

```bash
cd /opt/eliza-cli && uv run eliza issues list -i prod --tracker 2 --format json
```

## Beispiel-Workflows

- [Support-Tickets überwachen & Teams benachrichtigen](support-tickets-teams.md)

## Tipps

- **Immer `--format json`** verwenden für maschinenlesbaren Output
- **`--limit`** setzen um die Datenmenge zu begrenzen
- **Arbeitsverzeichnis** im Execute Command Node auf das eliza-cli Repo setzen
- **Fehlerbehandlung:** Der Exit-Code ist `0` bei Erfolg, `1` bei Fehler
