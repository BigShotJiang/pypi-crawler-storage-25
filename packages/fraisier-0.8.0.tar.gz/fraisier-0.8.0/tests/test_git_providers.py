"""Tests for git provider implementations."""

import hashlib
import hmac

from fraisier.git.bitbucket import Bitbucket
from fraisier.git.gitea import Gitea
from fraisier.git.github import GitHub
from fraisier.git.gitlab import GitLab


class TestGitHubProvider:
    """Tests for GitHub provider."""

    def test_init(self):
        """Test GitHub provider initialization."""
        config = {"webhook_secret": "test-secret"}
        provider = GitHub(config)

        assert provider.name == "github"
        assert provider.webhook_secret == "test-secret"

    def test_verify_webhook_signature_valid(self):
        """Test webhook signature verification with valid signature."""
        secret = b"test-secret"
        payload = b'{"test": "data"}'

        # Create correct signature
        signature = "sha256=" + hmac.new(secret, payload, hashlib.sha256).hexdigest()

        provider = GitHub({"webhook_secret": secret.decode()})

        # Verify signature
        result = provider.verify_webhook_signature(
            payload, {"x-hub-signature-256": signature}
        )

        assert result is True

    def test_verify_webhook_signature_invalid(self):
        """Test webhook signature verification with invalid signature."""
        provider = GitHub({"webhook_secret": "correct-secret"})

        result = provider.verify_webhook_signature(
            b'{"test": "data"}', {"x-hub-signature-256": "sha256=invalidsignature"}
        )

        assert result is False

    def test_verify_webhook_signature_missing_header(self):
        """Test webhook signature verification with missing signature header."""
        provider = GitHub({"webhook_secret": "secret"})

        result = provider.verify_webhook_signature(b'{"test": "data"}', {})

        assert result is False

    def test_parse_webhook_push_event(self):
        """Test parsing GitHub push event."""
        provider = GitHub({"webhook_secret": "secret"})

        payload = {
            "ref": "refs/heads/main",
            "repository": {"full_name": "user/repo"},
            "pusher": {"name": "user"},
            "head_commit": {"id": "abc123def456"},
        }
        headers = {"x-github-event": "push"}

        event = provider.parse_webhook_event(headers, payload)

        assert event.branch == "main"
        assert event.commit_sha == "abc123def456"
        assert event.sender == "user"
        assert event.is_push is True

    def test_parse_webhook_ping_event(self):
        """Test parsing GitHub ping event."""
        provider = GitHub({"webhook_secret": "secret"})

        payload = {"zen": "Design for failure"}
        headers = {"x-github-event": "ping"}

        event = provider.parse_webhook_event(headers, payload)

        assert event.event_type == "ping"

    def test_parse_webhook_pull_request_event(self):
        """Test parsing GitHub pull request event."""
        provider = GitHub({"webhook_secret": "secret"})

        payload = {
            "action": "opened",
            "pull_request": {
                "head": {
                    "ref": "feature-branch",
                    "sha": "xyz789",
                },
                "user": {"login": "developer"},
            },
        }
        headers = {"x-github-event": "pull_request"}

        event = provider.parse_webhook_event(headers, payload)

        assert event.branch == "feature-branch"
        assert event.event_type == "pull_request"


class TestGitLabProvider:
    """Tests for GitLab provider."""

    def test_init(self):
        """Test GitLab provider initialization."""
        config = {"webhook_secret": "test-secret"}
        provider = GitLab(config)

        assert provider.name == "gitlab"

    def test_verify_webhook_signature_valid(self):
        """Test GitLab webhook signature verification."""
        secret = "test-secret"
        payload = b'{"test": "data"}'

        # GitLab uses X-Gitlab-Token header
        provider = GitLab({"webhook_secret": secret})

        result = provider.verify_webhook_signature(payload, {"x-gitlab-token": secret})

        assert result is True

    def test_verify_webhook_signature_invalid(self):
        """Test GitLab webhook verification with invalid token."""
        provider = GitLab({"webhook_secret": "correct-secret"})

        result = provider.verify_webhook_signature(
            b'{"test": "data"}', {"x-gitlab-token": "wrong-token"}
        )

        assert result is False

    def test_parse_webhook_push_event(self):
        """Test parsing GitLab push event."""
        provider = GitLab({"webhook_secret": "secret"})

        payload = {
            "ref": "refs/heads/main",
            "user_username": "developer",
            "checkout_sha": "abc123",
            "project": {"name": "my-project"},
        }
        headers = {"x-gitlab-event": "Push Hook"}

        event = provider.parse_webhook_event(headers, payload)

        assert event.branch == "main"
        assert event.commit_sha == "abc123"
        assert event.sender == "developer"

    def test_get_default_base_url(self):
        provider = GitLab({"webhook_secret": "secret"})
        assert provider.get_default_base_url() == "https://gitlab.com"

    def test_verify_signature_missing_token(self):
        provider = GitLab({"webhook_secret": "secret"})
        result = provider.verify_webhook_signature(b"payload", {})
        assert result is False

    def test_parse_webhook_push_tag_event(self):
        """Test parsing GitLab push event for a tag ref."""
        provider = GitLab({"webhook_secret": "secret"})
        payload = {
            "ref": "refs/tags/v1.0.0",
            "checkout_sha": "def456",
            "project": {},
        }
        headers = {"x-gitlab-event": "Push Hook"}
        event = provider.parse_webhook_event(headers, payload)
        assert event.is_tag is True
        assert event.branch == "v1.0.0"

    def test_parse_webhook_tag_push_hook(self):
        """Test parsing GitLab Tag Push Hook event."""
        provider = GitLab({"webhook_secret": "secret"})
        payload = {
            "object_kind": "tag_push",
            "ref": "refs/tags/v2.0.0",
            "checkout_sha": "ghi789",
            "project": {},
        }
        headers = {"x-gitlab-event": "Tag Push Hook"}
        event = provider.parse_webhook_event(headers, payload)
        assert event.is_tag is True
        assert event.is_push is True
        assert event.branch == "v2.0.0"

    def test_parse_webhook_merge_request_event(self):
        """Test parsing GitLab Merge Request Hook event."""
        provider = GitLab({"webhook_secret": "secret"})
        payload = {
            "object_kind": "merge_request",
            "object_attributes": {
                "source_branch": "feature-x",
                "last_commit": {"id": "abc111"},
            },
            "project": {},
        }
        headers = {"x-gitlab-event": "Merge Request Hook"}
        event = provider.parse_webhook_event(headers, payload)
        assert event.is_merge_request is True
        assert event.branch == "feature-x"
        assert event.commit_sha == "abc111"


class TestGiteaProvider:
    """Tests for Gitea provider."""

    def test_init(self):
        """Test Gitea provider initialization."""
        config = {"webhook_secret": "test-secret"}
        provider = Gitea(config)

        assert provider.name == "gitea"

    def test_verify_webhook_signature_valid(self):
        """Test Gitea webhook signature verification."""
        secret = b"test-secret"
        payload = b'{"test": "data"}'

        # Gitea uses sha256 HMAC like GitHub
        signature = "sha256=" + hmac.new(secret, payload, hashlib.sha256).hexdigest()

        provider = Gitea({"webhook_secret": secret.decode()})

        result = provider.verify_webhook_signature(
            payload, {"x-gitea-signature": signature}
        )

        assert result is True

    def test_parse_webhook_push_event(self):
        """Test parsing Gitea push event."""
        provider = Gitea({"webhook_secret": "secret"})

        payload = {
            "ref": "refs/heads/main",
            "pusher": {"username": "developer"},
            "after": "abc123def456",
        }
        headers = {"x-gitea-event": "push"}

        event = provider.parse_webhook_event(headers, payload)

        assert event.branch == "main"
        assert event.commit_sha == "abc123def456"
        assert event.sender == "developer"

    def test_get_default_base_url(self):
        provider = Gitea({"webhook_secret": "secret"})
        assert "gitea" in provider.get_default_base_url()

    def test_verify_signature_missing_header(self):
        provider = Gitea({"webhook_secret": "secret"})
        result = provider.verify_webhook_signature(b"payload", {})
        assert result is False

    def test_parse_webhook_push_tag_ref(self):
        """Test parsing Gitea push event for a tag ref."""
        provider = Gitea({"webhook_secret": "secret"})
        payload = {
            "ref": "refs/tags/v1.0.0",
            "after": "def456",
        }
        headers = {"x-gitea-event": "push"}
        event = provider.parse_webhook_event(headers, payload)
        assert event.is_tag is True
        assert event.branch == "v1.0.0"

    def test_parse_webhook_create_tag_event(self):
        """Test parsing Gitea create tag event."""
        provider = Gitea({"webhook_secret": "secret"})
        payload = {
            "ref_type": "tag",
            "ref": "v1.2.3",
        }
        headers = {"x-gitea-event": "create"}
        event = provider.parse_webhook_event(headers, payload)
        assert event.is_tag is True
        assert event.is_push is True
        assert event.branch == "v1.2.3"

    def test_parse_webhook_pull_request_event(self):
        """Test parsing Gitea pull_request event."""
        provider = Gitea({"webhook_secret": "secret"})
        payload = {
            "pull_request": {
                "head": {"ref": "feature-y", "sha": "xyz999"},
            },
        }
        headers = {"x-gitea-event": "pull_request"}
        event = provider.parse_webhook_event(headers, payload)
        assert event.is_merge_request is True
        assert event.branch == "feature-y"
        assert event.commit_sha == "xyz999"


class TestBitbucketProvider:
    """Tests for Bitbucket provider."""

    def test_init(self):
        """Test Bitbucket provider initialization."""
        config = {"webhook_secret": "test-secret"}
        provider = Bitbucket(config)

        assert provider.name == "bitbucket"

    def test_verify_webhook_signature_valid(self):
        """Test Bitbucket webhook signature verification."""
        secret = b"test-secret"
        payload = b'{"test": "data"}'

        # Bitbucket uses sha256 HMAC
        signature = "sha256=" + hmac.new(secret, payload, hashlib.sha256).hexdigest()

        provider = Bitbucket({"webhook_secret": secret.decode()})

        result = provider.verify_webhook_signature(
            payload, {"x-hub-signature": signature}
        )

        assert result is True

    def test_parse_webhook_push_event(self):
        """Test parsing Bitbucket push event."""
        provider = Bitbucket({"webhook_secret": "secret"})

        payload = {
            "push": {
                "changes": [
                    {
                        "new": {
                            "name": "main",
                            "target": {"hash": "abc123def456"},
                        },
                    }
                ]
            },
            "actor": {"username": "developer"},
        }
        headers = {}

        event = provider.parse_webhook_event(headers, payload)

        assert event.branch == "main"
        assert event.commit_sha == "abc123def456"
        assert event.sender == "developer"


FULL_SHA = "abc123def456789012345678901234567890abcd"


class TestCommitShaNormalization:
    """All providers must return full-length commit SHA (not truncated)."""

    def test_github_returns_full_sha(self):
        provider = GitHub({"webhook_secret": "s"})
        event = provider.parse_webhook_event(
            {"x-github-event": "push"},
            {"ref": "refs/heads/main", "head_commit": {"id": FULL_SHA}},
        )
        assert event.commit_sha == FULL_SHA

    def test_gitlab_returns_full_sha(self):
        provider = GitLab({"webhook_secret": "s"})
        event = provider.parse_webhook_event(
            {"x-gitlab-event": "Push Hook"},
            {"ref": "refs/heads/main", "checkout_sha": FULL_SHA},
        )
        assert event.commit_sha == FULL_SHA

    def test_gitea_returns_full_sha(self):
        provider = Gitea({"webhook_secret": "s"})
        event = provider.parse_webhook_event(
            {"x-gitea-event": "push"},
            {"ref": "refs/heads/main", "after": FULL_SHA},
        )
        assert event.commit_sha == FULL_SHA

    def test_bitbucket_returns_full_sha(self):
        provider = Bitbucket({"webhook_secret": "s"})
        event = provider.parse_webhook_event(
            {},
            {
                "push": {
                    "changes": [{"new": {"name": "main", "target": {"hash": FULL_SHA}}}]
                },
            },
        )
        assert event.commit_sha == FULL_SHA


class TestWebhookEventParsing:
    """Tests for webhook event object."""

    def test_webhook_event_push_attributes(self):
        """Test WebhookEvent has push attributes."""
        from fraisier.git.base import WebhookEvent

        event = WebhookEvent(
            event_type="push",
            branch="main",
            commit_sha="abc123",
            sender="user",
        )

        assert event.event_type == "push"
        assert event.branch == "main"
        assert event.commit_sha == "abc123"
        assert event.sender == "user"
        assert event.is_push is True
        assert event.is_ping is False

    def test_webhook_event_ping_attributes(self):
        """Test WebhookEvent ping detection."""
        from fraisier.git.base import WebhookEvent

        event = WebhookEvent(event_type="ping")

        assert event.is_ping is True
        assert event.is_push is False

    def test_webhook_event_pull_request_attributes(self):
        """Test WebhookEvent pull_request detection."""
        from fraisier.git.base import WebhookEvent

        event = WebhookEvent(event_type="pull_request")

        assert event.is_pull_request is True
        assert event.is_push is False
