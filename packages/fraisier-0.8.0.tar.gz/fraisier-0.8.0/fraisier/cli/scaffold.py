"""Scaffold command for generating infrastructure files."""

from __future__ import annotations

import subprocess
from pathlib import Path

import click

from ._helpers import console, require_config
from .main import main


@main.command(name="scaffold-diff")
@click.argument("fraise", required=False)
@click.argument("environment", required=False)
@click.option("--apply", is_flag=True, help="Apply diffs (re-install changed files)")
@click.option("--server", "-s", default=None, help="Only include paths for this server")
@click.pass_context
def scaffold_diff(
    ctx: click.Context,
    fraise: str | None,
    environment: str | None,
    apply: bool,
    server: str | None,
) -> None:
    """Compare scaffold files against installed system files.

    Shows unified diffs for files that differ between the generated scaffold
    and what's currently installed on the system. Use --apply to automatically
    re-install changed files.

    \b
    Exit codes:
        0 - No differences found
        1 - Differences found

    \b
    Examples:
        fraisier scaffold-diff                    # all fraises/environments
        fraisier scaffold-diff api production    # specific fraise/env
        fraisier scaffold-diff --apply           # apply all differences
    """
    from fraisier.scaffold.diff import compute_scaffold_diff

    config = require_config(ctx)

    # Compute differences
    diffs = compute_scaffold_diff(
        config=config,
        server=server,
        fraise_filter=fraise,
        env_filter=environment,
    )

    if not diffs:
        console.print("[green]✓[/green] No scaffold differences found")
        raise SystemExit(0)

    # Display results
    changed_count = 0
    for diff in diffs:
        if diff.status == "match":
            console.print(f"[green]✓[/green] {diff.generated_path}")
        elif diff.status == "missing_installed":
            console.print(f"[red]✗[/red] {diff.generated_path} - missing from system")
            changed_count += 1
        elif diff.status == "missing_generated":
            console.print(f"[yellow]?[/yellow] {diff.generated_path} - not in scaffold")
        elif diff.status == "permission_denied":
            console.print(
                f"[yellow]![/yellow] {diff.generated_path}"
                " - permission denied (cannot compare)"
            )
        elif diff.status == "differs":
            console.print(f"[red]✗[/red] {diff.generated_path}")
            if diff.diff_lines:
                # Show first few lines of diff
                for line in diff.diff_lines[:10]:  # Limit output
                    console.print(f"  {line.rstrip()}")
                if len(diff.diff_lines) > 10:
                    console.print(f"  ... ({len(diff.diff_lines) - 10} more lines)")
            changed_count += 1

    # Summary
    total_files = len(diffs)
    console.print(f"\nSummary: {changed_count}/{total_files} files differ")

    if apply and changed_count > 0:
        from fraisier.scaffold.diff import apply_scaffold_diffs

        console.print("\n[cyan]Applying changes...[/cyan]")
        applied, failures = apply_scaffold_diffs(config, diffs, server=server)

        for path in applied:
            console.print(f"[green]✓[/green] Updated {path}")
        for path, error in failures:
            console.print(f"[red]✗[/red] Failed {path}: {error}")

        if failures:
            console.print(f"\n[red]{len(failures)} file(s) failed to apply.[/red]")
            raise SystemExit(1)

        console.print(f"\n[green]Applied {len(applied)} change(s).[/green]")
        raise SystemExit(0)

    # Exit with appropriate code
    raise SystemExit(1 if changed_count > 0 else 0)


@main.command(name="scaffold")
@click.option("--dry-run", is_flag=True, help="Show what would be generated")
@click.option(
    "--server",
    "-s",
    default=None,
    help="Only include paths for this server",
)
@click.pass_context
def scaffold(ctx: click.Context, dry_run: bool, server: str | None) -> None:
    """Generate infrastructure files from fraises.yaml.

    Renders systemd units, nginx configs, GitHub Actions workflows,
    sudoers, install scripts, confiture configs, and shell scripts.

    \b
    Examples:
        fraisier scaffold
        fraisier scaffold --dry-run
        fraisier scaffold --server server-1
    """
    from fraisier.scaffold.renderer import ScaffoldRenderer

    config = ctx.obj["config"]
    renderer = ScaffoldRenderer(config, server=server)
    files = renderer.render(dry_run=dry_run)

    if dry_run:
        console.print("[cyan]Would generate the following files:[/cyan]")
        for f in files:
            console.print(f"  {config.scaffold.output_dir}/{f}")
    else:
        console.print(
            f"[green]Generated {len(files)} files "
            f"in {config.scaffold.output_dir}[/green]"
        )
        for f in files:
            console.print(f"  {f}")

        # Provide helpful next steps
        console.print("\n[cyan]Next steps:[/cyan]")
        console.print("  1. Review generated files:")
        console.print(f"     git diff {config.scaffold.output_dir}/")
        console.print("\n  2. Install to system:")
        console.print("     fraisier scaffold-install --dry-run    # Preview")
        console.print("     fraisier scaffold-install --yes        # Install")


def _run_script(cmd: list[str]) -> int:
    """Run a script and return the exit code."""
    try:
        result = subprocess.run(cmd, check=False)
        return result.returncode
    except FileNotFoundError as e:
        console.print(
            "[red]Error:[/red] Could not run script. Please ensure sudo is available.",
            style="bold",
        )
        raise SystemExit(1) from e


def _build_preview_cmd(cmd: list[str]) -> list[str]:
    """Build a preview command by adding --dry-run flag."""
    if "--dry-run" in cmd:
        return cmd
    preview = list(cmd)
    # Insert before other flags
    flag_count = sum(1 for c in preview if c.startswith("--"))
    insert_pos = len(preview) - flag_count
    preview.insert(insert_pos, "--dry-run")
    return preview


@main.command(name="scaffold-install")
@click.option("--dry-run", is_flag=True, help="Preview what would be installed")
@click.option(
    "--validate-only", is_flag=True, help="Check prerequisites only (no install)"
)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.pass_context
def scaffold_install(
    ctx: click.Context,
    dry_run: bool,
    validate_only: bool,
    yes: bool,
    verbose: bool,
) -> None:
    """Install generated scaffold files to system locations.

    Runs the generated install.sh script with sudo to install systemd units,
    nginx configs, sudoers rules, wrapper scripts, and system dependencies.

    Must run 'fraisier scaffold' first to generate the files.

    Prerequisites:
    - Must run 'fraisier scaffold' first
    - Must have sudo access (or be running as root)
    - Generated files must be in PROJECT_DIR (usually /opt/<project_name>)

    \b
    Examples:
        fraisier scaffold-install --dry-run     # Preview changes
        fraisier scaffold-install --validate-only # Check prerequisites
        fraisier scaffold-install --yes          # Install without prompt
    """
    config = require_config(ctx)

    # Locate the install.sh script
    output_dir = Path(config.scaffold.output_dir)
    install_script = output_dir / "install.sh"

    if not install_script.exists():
        console.print(
            f"[red]Error:[/red] {install_script} not found.\n"
            "Run 'fraisier scaffold' first to generate it.",
            style="bold",
        )
        raise SystemExit(1)

    if not install_script.is_file():
        console.print(
            f"[red]Error:[/red] {install_script} is not a regular file.",
            style="bold",
        )
        raise SystemExit(1)

    # Make sure install.sh is executable
    install_script.chmod(0o755)

    # Build the command
    cmd: list[str] = ["sudo", str(install_script)]
    if dry_run:
        cmd.append("--dry-run")
    if validate_only:
        cmd.append("--validate-only")
    if verbose:
        cmd.append("--verbose")

    # Show what will happen
    if validate_only:
        console.print("[cyan]Checking prerequisites...[/cyan]\n")
    elif dry_run:
        console.print("[cyan]Preview of what would be installed:[/cyan]\n")
    else:
        console.print("[cyan]Installation plan:[/cyan]\n")

    # If not --yes and not validating/dry-running, show preview first
    if not yes and not validate_only and not dry_run:
        preview_cmd = _build_preview_cmd(cmd)
        _run_script(preview_cmd)
        console.print()
        if not click.confirm("Proceed with installation?"):
            console.print("[yellow]Aborted.[/yellow]")
            return

    # Run the actual command
    returncode = _run_script(cmd)

    if returncode == 0:
        if validate_only:
            console.print("\n[green]✓ All prerequisites met![/green]")
        elif dry_run:
            console.print("\n[green]✓ Preview complete[/green]")
        else:
            console.print(
                "\n[green]✓ Installation complete![/green]\n"
                "[cyan]Next steps:[/cyan]\n"
                "  1. Enable and start socket units:\n"
                "     sudo systemctl enable fraisier-{project}-*-deploy.socket\n"
                "     sudo systemctl start fraisier-{project}-*-deploy.socket\n"
                "  2. Verify socket units are listening:\n"
                "     systemctl status fraisier-{project}-*-deploy.socket\n"
                "  3. Test deployment:\n"
                "     fraisier trigger-deploy <fraise> <environment>"
            )
    else:
        if validate_only or dry_run:
            console.print(
                "\n[yellow]⚠ Preview/validation encountered issues.[/yellow]\n"
                "Review the output above for details."
            )
        else:
            console.print(
                "\n[red]✗ Installation failed[/red]\n"
                "Review the output above for details."
            )
        raise SystemExit(returncode)
