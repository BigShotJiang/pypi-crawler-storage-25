import unittest
from pathlib import Path
from tempfile import TemporaryDirectory


class TestWritefitsRoundtrip(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            from jinwu.core import readfits as _readfits, writefits as _writefits
        except Exception as e:
            raise unittest.SkipTest(f"jinwu.core import failed in current env: {e}")

        cls.ep_dir = Path("/home/xinxiang/research/EP250111a/ep")
        if not cls.ep_dir.exists():
            raise unittest.SkipTest(f"EP test data folder not found: {cls.ep_dir}")

        cls.files = {
            "pha": cls.ep_dir / "ep11916646654wxt12s1.pha",
            "lc": cls.ep_dir / "ep11916646654wxt12s1.lc",
            "evt": cls.ep_dir / "ep11916646654wxt12po_cl.evt",
            "arf": cls.ep_dir / "ep11916646654wxt12s1.arf",
            "rmf": cls.ep_dir / "ep11916646654wxt12.rmf",
        }
        missing = [str(p) for p in cls.files.values() if not p.exists()]
        if missing:
            raise unittest.SkipTest(f"Missing EP input files: {missing}")

    def test_pha_roundtrip(self):
        from jinwu.core import readfits, writefits

        src = self.files["pha"]
        d1 = readfits(src, kind="pha")
        with TemporaryDirectory() as td:
            out = Path(td) / "roundtrip_pha.fits"
            writefits(d1, out, kind="pha", overwrite=True)
            d2 = readfits(out, kind="pha")
        self.assertEqual(d1.channels.shape, d2.channels.shape)
        self.assertEqual(d1.counts.shape, d2.counts.shape)
        self.assertAlmostEqual(float(d1.exposure), float(d2.exposure), places=6)

    def test_lc_roundtrip(self):
        from jinwu.core import readfits, writefits

        src = self.files["lc"]
        d1 = readfits(src, kind="lc")
        with TemporaryDirectory() as td:
            out = Path(td) / "roundtrip_lc.fits"
            writefits(d1, out, kind="lc", overwrite=True)
            d2 = readfits(out, kind="lc")
        t1 = d1.time
        t2 = d2.time
        if t1 is None or t2 is None:
            self.fail("lightcurve time is None after roundtrip")
        self.assertEqual(t1.shape, t2.shape)
        self.assertEqual(d2.kind, "lc")
        self.assertTrue(d2.time is not None)

    def test_evt_roundtrip(self):
        from jinwu.core import readfits, writefits

        src = self.files["evt"]
        d1 = readfits(src, kind="evt")
        with TemporaryDirectory() as td:
            out = Path(td) / "roundtrip_evt.fits"
            writefits(d1, out, kind="evt", overwrite=True)
            d2 = readfits(out, kind="evt")
        self.assertEqual(d1.time.shape, d2.time.shape)
        self.assertEqual(d2.kind, "evt")

    def test_arf_roundtrip(self):
        from jinwu.core import readfits, writefits

        src = self.files["arf"]
        d1 = readfits(src, kind="arf")
        with TemporaryDirectory() as td:
            out = Path(td) / "roundtrip_arf.fits"
            writefits(d1, out, kind="arf", overwrite=True)
            d2 = readfits(out, kind="arf")
        self.assertEqual(d1.energ_lo.shape, d2.energ_lo.shape)
        self.assertEqual(d1.specresp.shape, d2.specresp.shape)

    def test_rmf_roundtrip(self):
        from jinwu.core import readfits, writefits

        src = self.files["rmf"]
        d1 = readfits(src, kind="rmf")
        with TemporaryDirectory() as td:
            out = Path(td) / "roundtrip_rmf.fits"
            writefits(d1, out, kind="rmf", overwrite=True)
            d2 = readfits(out, kind="rmf")
        self.assertEqual(d1.energ_lo.shape, d2.energ_lo.shape)
        self.assertEqual(d2.kind, "rmf")


if __name__ == "__main__":
    unittest.main()
