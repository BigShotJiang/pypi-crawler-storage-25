import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, cast

import numpy as np


class TestIoDataWithEpFiles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            from jinwu.core import readfits
        except Exception as e:
            raise unittest.SkipTest(f"jinwu.core import failed in current env: {e}")

        cls.ep_dir = Path("/home/xinxiang/research/EP250111a/ep")
        if not cls.ep_dir.exists():
            raise unittest.SkipTest(f"EP test data folder not found: {cls.ep_dir}")

        cls.paths = {
            "pha": cls.ep_dir / "ep11916646654wxt12s1.pha",
            "lc": cls.ep_dir / "ep11916646654wxt12s1.lc",
            "evt": cls.ep_dir / "ep11916646654wxt12po_cl.evt",
            "arf": cls.ep_dir / "ep11916646654wxt12s1.arf",
            "rmf": cls.ep_dir / "ep11916646654wxt12.rmf",
        }
        missing = [str(p) for p in cls.paths.values() if not p.exists()]
        if missing:
            raise unittest.SkipTest(f"Missing EP input files: {missing}")

        cls.data = {k: readfits(p, kind=cast(Any, k)) for k, p in cls.paths.items()}

    def test_readfits_explicit_and_auto_kind(self):
        from jinwu.core import readfits

        for kind, path in self.paths.items():
            with self.subTest(kind=kind):
                d1 = readfits(path, kind=cast(Any, kind))
                d2 = readfits(path)
                self.assertEqual(getattr(d1, "kind", None), kind)
                self.assertEqual(getattr(d2, "kind", None), kind)

    def test_validate_reports_for_all_kinds(self):
        for kind, d in self.data.items():
            with self.subTest(kind=kind):
                rpt = d.validate()
                self.assertIsNotNone(rpt)
                self.assertTrue(hasattr(rpt, "messages"))
                self.assertTrue(hasattr(rpt, "errors"))
                self.assertTrue(hasattr(rpt, "warnings"))
                self.assertEqual(len(rpt.errors()), 0, f"{kind} has validation errors: {[m.message for m in rpt.errors()]}")

    def test_writefits_roundtrip_all_kinds(self):
        from jinwu.core import readfits, writefits

        for kind, d in self.data.items():
            with self.subTest(kind=kind):
                with TemporaryDirectory() as td:
                    out = Path(td) / f"roundtrip_{kind}.fits"
                    writefits(d, out, kind=cast(Any, kind), overwrite=True)
                    d2 = readfits(out, kind=cast(Any, kind))

                    self.assertEqual(getattr(d2, "kind", None), kind)

                    if kind == "pha":
                        self.assertEqual(d.channels.shape, d2.channels.shape)
                        self.assertEqual(d.counts.shape, d2.counts.shape)
                    elif kind == "lc":
                        self.assertIsNotNone(d2.time)
                        self.assertEqual(len(d.time), len(d2.time))
                    elif kind == "evt":
                        self.assertEqual(len(d.time), len(d2.time))
                    elif kind == "arf":
                        self.assertEqual(d.energ_lo.shape, d2.energ_lo.shape)
                        self.assertEqual(d.specresp.shape, d2.specresp.shape)
                    elif kind == "rmf":
                        self.assertEqual(d.energ_lo.shape, d2.energ_lo.shape)

    def test_io_utility_functions(self):
        from jinwu.core import band_from_arf_bins, channel_mask_from_ebounds

        arf = self.data["arf"]
        pha = self.data["pha"]
        band = band_from_arf_bins(self.paths["arf"], 10, 100)
        self.assertGreater(float(band.emax), float(band.emin))

        if pha.ebounds is not None:
            mask = channel_mask_from_ebounds(pha.ebounds, band)
            self.assertEqual(mask.dtype, np.bool_)
            self.assertEqual(mask.shape[0], pha.ebounds[0].shape[0])
        else:
            self.skipTest("PHA EBOUNDS not available in test file")

        self.assertGreater(len(arf.energ_lo), 0)

    def test_pha_data_features(self):
        pha = self.data["pha"]
        self.assertGreater(pha.channels.size, 0)
        self.assertEqual(pha.channels.shape, pha.counts.shape)

        cr = pha.count_rate
        self.assertIsNotNone(cr)
        self.assertEqual(np.asarray(cr).shape, pha.counts.shape)

        grouping = pha.group_by_min_counts(30)
        self.assertEqual(grouping.shape[0], pha.counts.shape[0])

        pha_rebin = pha.rebin(factor=4)
        self.assertLessEqual(pha_rebin.channels.size, pha.channels.size)
        self.assertEqual(pha_rebin.channels.shape, pha_rebin.counts.shape)

    def test_arf_data_features(self):
        arf = self.data["arf"]
        self.assertEqual(arf.energ_lo.shape, arf.energ_hi.shape)
        self.assertEqual(arf.energ_lo.shape, arf.specresp.shape)

        arf_rebin = arf.rebin(3)
        self.assertLessEqual(arf_rebin.energ_lo.size, arf.energ_lo.size)
        self.assertEqual(arf_rebin.energ_lo.shape, arf_rebin.specresp.shape)

    def test_rmf_data_features(self):
        rmf = self.data["rmf"]
        dense = rmf.rebuild_dense()
        self.assertEqual(dense.ndim, 2)
        self.assertEqual(dense.shape[0], rmf.energ_lo.size)
        self.assertTrue(np.all(np.isfinite(dense)))

        dense2 = rmf.dense_matrix
        self.assertEqual(dense2.shape, dense.shape)

        rmf_rebin = rmf.rebin(2)
        dense_rebin = rmf_rebin.rebuild_dense()
        self.assertLessEqual(dense_rebin.shape[0], dense.shape[0])

    def test_lightcurve_data_features(self):
        lc = self.data["lc"]
        self.assertIsNotNone(lc.time)
        self.assertGreater(lc.n, 0)
        self.assertEqual(lc.n, len(lc.time))
        self.assertEqual(lc.absolute_time.shape[0], lc.n)

        self.assertIsNotNone(lc.bin_centers)
        self.assertIsNotNone(lc.mean_rate if lc.rate is not None else lc.mean_counts)

        mask = np.zeros(lc.n, dtype=bool)
        mask[: max(1, lc.n // 3)] = True
        lc_masked = lc.apply_mask(mask, inplace=False)
        self.assertEqual(lc_masked.n, int(mask.sum()))

        t0 = float(lc.time[0])
        t1 = float(lc.time[min(lc.n - 1, max(1, lc.n // 2))])
        lc_trunc = lc.truncate(tmin=t0, tmax=t1)
        self.assertLessEqual(lc_trunc.n, lc.n)

        lc_rebin = lc.rebin(binsize=max(1.0, float(np.median(np.diff(lc.time))) * 2.0))
        self.assertGreater(lc_rebin.n, 0)

    def test_event_data_features(self):
        evt = self.data["evt"]
        rmf = self.data["rmf"]

        self.assertGreater(evt.n, 0)
        self.assertIsNotNone(evt.duration)
        self.assertEqual(evt.absolute_time.shape[0], evt.n)

        energy = evt.get_energy(rmf=rmf)
        if energy is not None:
            self.assertEqual(len(energy), evt.n)

        ev_lc = evt.rebin(binsize=2.0)
        self.assertEqual(getattr(ev_lc, "kind", None), "lc")
        self.assertGreater(ev_lc.n, 0)


if __name__ == "__main__":
    unittest.main()
