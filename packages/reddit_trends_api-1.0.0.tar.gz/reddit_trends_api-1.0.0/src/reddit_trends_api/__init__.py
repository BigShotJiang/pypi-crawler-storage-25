"""
reddit-trends-api -- Reddit mention volume over time via a Python client. Weekly or daily series, period-over-period growth, and live Reddit trending posts. No scraping, no OAuth.

Get your free API key at https://trendsmcp.ai
Full docs at https://trendsmcp.ai/docs
"""

from trendsmcp import TrendsMcpClient, AsyncTrendsMcpClient, TrendsMcpError
from trendsmcp.types import (
    TrendsSource,
    TrendsDataPoint,
    GetTrendsParams,
    GetTrendsResponse,
    GrowthPreset,
    CustomGrowthPeriod,
    GetGrowthParams,
    GrowthResult,
    GrowthMetadata,
    GetGrowthResponse,
    TopTrendsFeed,
    GetTopTrendsParams,
    GetTopTrendsResponse,
)

# Default source for this package. Pass to 'source' in any request.
SOURCE: TrendsSource = "reddit"

__version__ = "1.0.0"
__all__ = [
    "TrendsMcpClient",
    "AsyncTrendsMcpClient",
    "TrendsMcpError",
    "SOURCE",
    "TrendsSource",
    "TrendsDataPoint",
    "GetTrendsParams",
    "GetTrendsResponse",
    "GrowthPreset",
    "CustomGrowthPeriod",
    "GetGrowthParams",
    "GrowthResult",
    "GrowthMetadata",
    "GetGrowthResponse",
    "TopTrendsFeed",
    "GetTopTrendsParams",
    "GetTopTrendsResponse",
]
