# k8s-debug-tool

CLI helper for DevOps: list pods in a Kubernetes namespace and highlight common problem states (failed phase, CrashLoopBackOff, terminated with messages).

Requires a valid kubeconfig (or in-cluster credentials when run inside a pod).

## Install

```bash
pip install k8s-debug-tool
```

## Usage

```bash
k8s-debug --namespace default
k8s-debug -n kube-system
```

## Build and publish (maintainers)

From this directory (`k8s-debug-tool/`):

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine upload dist/*
```

Use an [API token](https://pypi.org/help/#apitoken) as the password when `twine` prompts you.

Before the first upload, create the project on [PyPI](https://pypi.org/) (or use `twine` with a token that has upload scope). If the name `k8s-debug-tool` is taken, change `name` in `pyproject.toml` and pick a unique name on PyPI.

## License

MIT — see `LICENSE`.
