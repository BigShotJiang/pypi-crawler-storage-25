#!/usr/bin/env python3
import argparse

from kubernetes import client, config


def load_kubeconfig():
    try:
        config.load_incluster_config()  # when running inside a pod
    except config.ConfigException:
        config.load_kube_config()  # when running from node / laptop


def list_pods_with_issues(namespace="default"):
    v1 = client.CoreV1Api()
    pods = v1.list_namespaced_pod(namespace=namespace)

    print(f"=== Pods in namespace: {namespace} ===")
    for pod in pods.items:
        print(f"{pod.metadata.name}  {pod.status.phase}")

    print(f"\n=== Pods with issues in {namespace} ===")
    for pod in pods.items:
        status = pod.status
        if status.phase in ("Failed", "Unknown"):
            print(f"[FAILURE] {pod.metadata.name}")
        if status.container_statuses:
            for cs in status.container_statuses:
                if cs.state.waiting and "CrashLoopBackOff" in str(cs.state.waiting):
                    print(f"[CRASHLOOP] {pod.metadata.name} - {cs.name}")
                if cs.state.terminated and cs.state.terminated.message:
                    print(
                        f"[TERMINATED] {pod.metadata.name} - {cs.name}: "
                        f"{cs.state.terminated.message}"
                    )


def main():
    parser = argparse.ArgumentParser(
        description="K8s debug tool — list pods and common failure states in a namespace"
    )
    parser.add_argument(
        "--namespace", "-n", default="default", help="Namespace to scan"
    )
    parser.add_argument(
        "--only-failing",
        action="store_true",
        help="Reserved for future use: only show failing pods",
    )

    args = parser.parse_args()
    _ = args.only_failing  # not yet implemented

    load_kubeconfig()
    list_pods_with_issues(args.namespace)


if __name__ == "__main__":
    main()
