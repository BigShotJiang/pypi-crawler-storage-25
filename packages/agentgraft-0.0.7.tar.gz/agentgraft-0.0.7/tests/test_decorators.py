"""Unit tests for ``@ag.tool``, ``@ag.agent``, ``@ag.user_loader``, ``ag.graft``."""

from typing import Annotated

import agentgraft as ag
import pytest
from agentgraft import get_registry

# ---------------------------------------------------------------------------
# @ag.tool
# ---------------------------------------------------------------------------


class TestToolDecorator:
    def test_bare_decorator_registers(self):
        @ag.tool
        def list_things(user) -> list[dict]:
            """List things."""
            return []

        reg = get_registry()
        assert "list_things" in reg.tools
        assert reg.tools["list_things"].description == "List things."

    def test_with_explicit_description(self):
        @ag.tool(description="Custom desc.")
        def t(user) -> str:
            return ""

        assert get_registry().tools["t"].description == "Custom desc."

    def test_function_name_becomes_tool_name(self):
        @ag.tool
        def my_tool_name(user) -> int:
            """X."""
            return 0

        assert "my_tool_name" in get_registry().tools

    def test_first_param_is_skipped_in_schema(self):
        @ag.tool
        def with_args(user, query: str, limit: int = 5) -> list:
            """Search."""
            return []

        schema = get_registry().tools["with_args"].parameters_schema
        # 'user' must NOT appear in the schema
        assert "user" not in schema["properties"]
        assert set(schema["properties"].keys()) == {"query", "limit"}
        assert "query" in schema["required"]
        assert "limit" not in schema["required"]  # has default

    def test_no_params_raises(self):
        with pytest.raises(ValueError, match="at least one parameter"):

            @ag.tool
            def bad():
                """Bad."""

    def test_missing_docstring_raises(self):
        with pytest.raises(ValueError, match="missing description"):

            @ag.tool
            def bad(user):
                pass

    def test_missing_type_hint_raises(self):
        with pytest.raises(ValueError, match="missing a type hint"):

            @ag.tool
            def bad(user, untyped):
                """Bad."""

    def test_returns_original_function(self):
        @ag.tool
        def round_trip(user) -> int:
            """X."""
            return 42

        # The decorator must return the function so the developer can still
        # call it directly (in tests, in unit tests of the host app).
        assert round_trip.__name__ == "round_trip"

    def test_duplicate_name_raises(self):
        @ag.tool
        def same(user) -> int:
            """X."""
            return 1

        with pytest.raises(ValueError, match="already registered"):

            @ag.tool
            def same(user) -> int:  # noqa: F811
                """Y."""
                return 2


# ---------------------------------------------------------------------------
# @ag.agent
# ---------------------------------------------------------------------------


class TestAgentDecorator:
    def test_basic_registration(self):
        @ag.agent
        def helper():
            """You are the helper agent."""

        reg = get_registry().agents["helper"]
        assert reg.instructions == "You are the helper agent."
        assert reg.is_entry_point is False
        assert reg.model_tier == "auto"

    def test_entry_point_flag(self):
        @ag.agent(entry=True)
        def main():
            """Entry point."""

        assert get_registry().agents["main"].is_entry_point is True

    def test_model_tier(self):
        @ag.agent(model="pro")
        def smart():
            """Smart agent."""

        assert get_registry().agents["smart"].model_tier == "pro"

    def test_tool_refs_resolved_to_names(self):
        @ag.tool
        def tool_a(user) -> int:
            """A."""
            return 1

        @ag.tool
        def tool_b(user) -> int:
            """B."""
            return 2

        @ag.agent(tools=[tool_a, tool_b])
        def consumer():
            """Uses tools."""

        agent_reg = get_registry().agents["consumer"]
        assert agent_reg.tool_names == ["tool_a", "tool_b"]

    def test_handoff_refs_can_be_strings(self):
        @ag.agent(handoffs=["other_agent"])
        def first():
            """X."""

        assert get_registry().agents["first"].handoff_names == ["other_agent"]

    def test_handoff_refs_can_be_callables(self):
        @ag.agent
        def target():
            """T."""

        @ag.agent(handoffs=[target])
        def source():
            """S."""

        assert get_registry().agents["source"].handoff_names == ["target"]

    def test_missing_docstring_raises(self):
        with pytest.raises(ValueError, match="missing docstring"):

            @ag.agent
            def bad():
                pass

    def test_invalid_tool_ref_raises(self):
        with pytest.raises(ValueError, match="reference must be"):

            @ag.agent(tools=[42])
            def bad():
                """X."""

    def test_duplicate_agent_raises(self):
        @ag.agent
        def same():
            """X."""

        with pytest.raises(ValueError, match="already registered"):

            @ag.agent
            def same():  # noqa: F811
                """Y."""

    def test_sub_agent_callable_refs_resolved(self):
        @ag.agent
        def worker():
            """Worker agent."""

        @ag.agent(sub_agents=[worker])
        def orchestrator():
            """Orchestrator agent."""

        assert get_registry().agents["orchestrator"].sub_agent_names == ["worker"]

    def test_sub_agent_string_refs_work(self):
        @ag.agent(sub_agents=["some_specialist"])
        def delegator():
            """Delegator agent."""

        assert get_registry().agents["delegator"].sub_agent_names == ["some_specialist"]

    def test_sub_agent_names_defaults_to_empty_list(self):
        @ag.agent
        def plain():
            """Plain agent."""

        assert get_registry().agents["plain"].sub_agent_names == []

    def test_invalid_sub_agent_ref_raises(self):
        with pytest.raises(ValueError, match="reference must be"):

            @ag.agent(sub_agents=[99])
            def bad():
                """X."""


# ---------------------------------------------------------------------------
# @ag.user_loader
# ---------------------------------------------------------------------------


class TestUserLoaderDecorator:
    def test_registers_callback(self):
        @ag.user_loader
        def load(external_id: str):
            return {"id": external_id}

        loader = get_registry().user_loader
        assert loader is not None
        assert loader("42") == {"id": "42"}

    def test_double_registration_raises(self):
        @ag.user_loader
        def load(x: str):
            return x

        with pytest.raises(ValueError, match="already registered"):

            @ag.user_loader
            def load2(x: str):  # noqa: F811
                return x


# ---------------------------------------------------------------------------
# ag.graft(...)
# ---------------------------------------------------------------------------


class TestGraftConfig:
    def test_sets_all_fields(self):
        ag.graft(
            name="MyApp",
            identity="I am here.",
            product_context="We do things.",
            voice="Be concise.",
            scope="Investing only.",
            policies="No advice.",
            webhook_url="https://example.com/wh",
        )
        cfg = get_registry().graft_config
        assert cfg.name == "MyApp"
        assert cfg.identity == "I am here."
        assert cfg.product_context == "We do things."
        assert cfg.voice == "Be concise."
        assert cfg.scope == "Investing only."
        assert cfg.policies == ["No advice."]
        assert cfg.webhook_url == "https://example.com/wh"

    def test_partial_config(self):
        ag.graft(identity="I.", voice="V.")
        cfg = get_registry().graft_config
        assert cfg.identity == "I."
        assert cfg.voice == "V."
        assert cfg.product_context == ""
        assert cfg.scope == ""

    def test_strips_whitespace_from_text_fields(self):
        ag.graft(identity="  \n  Hello.  \n  ")
        assert get_registry().graft_config.identity == "Hello."

    def test_can_be_called_multiple_times(self):
        ag.graft(identity="first")
        ag.graft(identity="second")
        assert get_registry().graft_config.identity == "second"


# ---------------------------------------------------------------------------
# @ag.tool — docstring Args: integration
# ---------------------------------------------------------------------------


class TestToolDecoratorDocstringDescriptions:
    """End-to-end tests for the full description priority chain:
    ag.Param > docstring Args: > no description.
    """

    # ── Docstring Args: as primary source ────────────────────────────────

    def test_args_section_populates_param_descriptions(self):
        @ag.tool
        def search(user, query: str, limit: int = 10) -> list:
            """Search for items.

            Args:
                query: The search query to run.
                limit: Max results to return.
            """
            return []

        props = get_registry().tools["search"].parameters_schema["properties"]
        assert props["query"]["description"] == "The search query to run."
        assert props["limit"]["description"] == "Max results to return."

    def test_args_section_stripped_from_tool_description(self):
        @ag.tool
        def fetch(user, item_id: int) -> dict:
            """Fetch one item by ID.

            Returns the full item payload.

            Args:
                item_id: Numeric ID of the item.
            """
            return {}

        desc = get_registry().tools["fetch"].description
        assert "Fetch one item by ID." in desc
        assert "Returns the full item payload." in desc
        assert "Args:" not in desc
        assert "item_id" not in desc

    def test_multiline_param_description_joined(self):
        @ag.tool
        def process(user, text: str) -> str:
            """Process text.

            Args:
                text: A long description that wraps
                    onto a second line for readability.
            """
            return text

        desc = (
            get_registry().tools["process"].parameters_schema["properties"]["text"]["description"]
        )
        assert desc == "A long description that wraps onto a second line for readability."

    def test_param_with_no_docstring_entry_has_no_description(self):
        @ag.tool
        def compute(user, value: float, units: str) -> float:
            """Compute a result.

            Args:
                value: The numeric input.
            """
            return value

        props = get_registry().tools["compute"].parameters_schema["properties"]
        assert props["value"]["description"] == "The numeric input."
        # units has no entry in the Args: block — no description key at all
        assert "description" not in props["units"]

    def test_tool_with_no_args_section_has_no_param_descriptions(self):
        @ag.tool
        def ping(user, target: str) -> bool:
            """Ping a target."""
            return True

        props = get_registry().tools["ping"].parameters_schema["properties"]
        assert "description" not in props["target"]

    # ── ag.Param wins over docstring ─────────────────────────────────────

    def test_ag_param_overrides_docstring_description(self):
        @ag.tool
        def get_dataset(
            user,
            dataset_id: Annotated[int, ag.Param("From ag.Param — very explicit.")],
        ) -> dict:
            """Get a dataset.

            Args:
                dataset_id: Generic ID from the docstring.
            """
            return {}

        desc = (
            get_registry()
            .tools["get_dataset"]
            .parameters_schema["properties"]["dataset_id"]["description"]
        )
        assert desc == "From ag.Param — very explicit."
        assert "Generic" not in desc

    def test_ag_param_wins_only_for_annotated_params_others_use_docstring(self):
        @ag.tool
        def mixed(
            user,
            explicit: Annotated[str, ag.Param("Explicit ag.Param desc.")],
            fallback: str,
        ) -> None:
            """Mixed description sources.

            Args:
                explicit: This will be overridden by ag.Param.
                fallback: This comes from the docstring.
            """

        props = get_registry().tools["mixed"].parameters_schema["properties"]
        assert props["explicit"]["description"] == "Explicit ag.Param desc."
        assert props["fallback"]["description"] == "This comes from the docstring."

    def test_ag_param_with_examples_preserved(self):
        @ag.tool
        def query_items(
            user,
            item_id: Annotated[int, ag.Param("The item ID.", examples=[42, 137])],
        ) -> dict:
            """Query items.

            Args:
                item_id: Plain docstring description.
            """
            return {}

        prop = get_registry().tools["query_items"].parameters_schema["properties"]["item_id"]
        assert prop["description"] == "The item ID."
        assert prop["examples"] == [42, 137]

    # ── explicit description= kwarg ──────────────────────────────────────

    def test_explicit_description_kwarg_is_used_as_tool_description(self):
        @ag.tool(description="Hard-coded description, ignores docstring.")
        def explicit_desc(user, x: int) -> int:
            """This docstring is ignored.

            Args:
                x: Some param.
            """
            return x

        assert (
            get_registry().tools["explicit_desc"].description
            == "Hard-coded description, ignores docstring."
        )

    def test_explicit_description_kwarg_does_not_affect_param_descriptions(self):
        # description= only overrides the tool-level description, NOT param extraction.
        @ag.tool(description="Tool description.")
        def kwarg_tool(user, value: str) -> str:
            """Docstring.

            Args:
                value: Param description from docstring.
            """
            return value

        reg = get_registry().tools["kwarg_tool"]
        assert reg.description == "Tool description."
        assert (
            reg.parameters_schema["properties"]["value"]["description"]
            == "Param description from docstring."
        )

    # ── Optional / defaulted params still get descriptions ───────────────

    def test_optional_param_receives_docstring_description(self):
        @ag.tool
        def with_optional(user, query: str, limit: int | None = None) -> list:
            """Search.

            Args:
                query: The search string.
                limit: Cap the result count; None means unlimited.
            """
            return []

        props = get_registry().tools["with_optional"].parameters_schema["properties"]
        assert props["limit"]["description"] == "Cap the result count; None means unlimited."
        # Optional → still not required
        assert "limit" not in get_registry().tools["with_optional"].parameters_schema["required"]

    def test_defaulted_param_receives_docstring_description(self):
        @ag.tool
        def with_default(user, mode: str = "fast") -> str:
            """Run in a mode.

            Args:
                mode: Execution mode; one of 'fast' or 'thorough'.
            """
            return mode

        props = get_registry().tools["with_default"].parameters_schema["properties"]
        assert props["mode"]["description"] == "Execution mode; one of 'fast' or 'thorough'."
