"""``manage.py agentgraft_sync`` — push the local registry to the hosted graft.

The host app's config module is the source of truth. This command
serializes the in-memory registry for the named profile into the sync
payload shape and POSTs it to ``/api/v1/admin/grafts/{id}/sync/``.

Auto-discovery happens at app-startup time inside
``apps.AgentGraftConfig.ready``; by the time this command runs, every
profile's registry is already populated.

Examples::

    manage.py agentgraft_sync                    # sync every declared profile (default)
    manage.py agentgraft_sync --profile public   # sync only the public profile
    manage.py agentgraft_sync --dry-run          # print the payload, don't POST
"""

import json

from django.core.management.base import BaseCommand, CommandError

from ....client import APIError, Client
from ....registry import PolicyRef, get_registry
from ...settings_helpers import (
    get_profile_config,
    list_profile_names,
    require,
)


class Command(BaseCommand):
    help = "Push tools, agents, and graft config to AgentGraft."

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--profile",
            default=None,
            help=(
                "Which profile to sync. Omit to sync every declared profile "
                "(same as --all). Pass a name (e.g. --profile default) to "
                "restrict the sync to one profile."
            ),
        )

        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Print the payload but don't send it.",
        )
        parser.add_argument(
            "--retries",
            type=int,
            default=3,
            metavar="N",
            help=(
                "Number of times to retry transient network errors or 5xx "
                "responses before giving up. Set to 0 to disable retries. "
                "Uses exponential back-off with jitter between attempts. "
                "Default: 3."
            ),
        )
        parser.add_argument(
            "--skip-if-unconfigured",
            action="store_true",
            help=(
                "Exit 0 with a warning instead of failing when a profile's "
                "credentials (api_key / graft_id) aren't set OR the registry "
                "is empty. Designed for CI/preDeploy hooks where the first "
                "deploy ships without credentials and you don't want sync "
                "to block the build. Subsequent deploys (with credentials "
                "set) push as normal."
            ),
        )

    def handle(self, *args, profile: str | None, dry_run: bool = False, **options) -> None:
        skip_if_unconfigured = options.get("skip_if_unconfigured", False)
        max_retries = options["retries"]

        if profile is None:
            profiles_to_sync = list_profile_names()
            if not profiles_to_sync:
                if skip_if_unconfigured:
                    self.stdout.write(
                        self.style.WARNING(
                            "AGENTGRAFT['profiles'] is empty — nothing to sync. "
                            "Skipping (--skip-if-unconfigured)."
                        )
                    )
                    return
                raise CommandError("AGENTGRAFT['profiles'] is empty — nothing to sync.")
        else:
            profiles_to_sync = [profile]

        for name in profiles_to_sync:
            self._sync_one(
                name,
                dry_run=dry_run,
                skip_if_unconfigured=skip_if_unconfigured,
                max_retries=max_retries,
            )

    def _sync_one(
        self,
        profile: str,
        *,
        dry_run: bool,
        skip_if_unconfigured: bool = False,
        max_retries: int = 3,
    ) -> None:
        profile_config = get_profile_config(profile)
        try:
            require(profile_config, "api_base", "api_key", "graft_id")
        except ValueError as exc:
            if skip_if_unconfigured:
                # Designed for CI/preDeploy: missing credentials means
                # this profile isn't ready to sync yet. Warn loudly so
                # the deploy log makes the "no sync happened" obvious,
                # but don't block the build. Subsequent deploys (after
                # the operator pastes credentials into env vars) will
                # push normally.
                self.stdout.write(
                    self.style.WARNING(
                        f"Profile {profile!r}: skipping sync — {exc}. (--skip-if-unconfigured)"
                    )
                )
                return
            raise CommandError(f"Profile {profile!r}: {exc}") from exc

        registry = get_registry(profile)
        if not registry.tools and not registry.agents:
            if skip_if_unconfigured:
                self.stdout.write(
                    self.style.WARNING(
                        f"Profile {profile!r}: registry is empty — skipping sync. "
                        f"(--skip-if-unconfigured)"
                    )
                )
                return
            raise CommandError(
                f"Profile {profile!r}: registry is empty. Make sure your "
                f"AGENTGRAFT['config_module'] imports cleanly and uses the "
                f"@ag.tool / @ag.agent decorators with profile={profile!r}."
            )

        # Resolve any ``ag.policy(...)`` references against the public
        # Policy Shop API BEFORE serializing the payload. This way the
        # composed text is in the payload by the time we POST to the
        # admin API; the runtime never has to know about codenames.
        client = Client(
            api_base=profile_config["api_base"],
            api_key=profile_config["api_key"],
            max_retries=max_retries,
        )
        try:
            resolved_policies = _resolve_policies(
                registry.graft_config.policies, client, profile=profile
            )
        except APIError as exc:
            raise CommandError(
                f"Profile {profile!r}: policy resolution failed ({exc.status_code}): {exc.body}"
            ) from exc

        payload = _build_payload(registry, profile_config, resolved_policies)

        self.stdout.write(self.style.MIGRATE_HEADING(f"\n— Profile {profile!r} —"))

        if dry_run:
            self.stdout.write(json.dumps(payload, indent=2))
            return

        try:
            summary = client.sync_graft(
                graft_id=profile_config["graft_id"],
                payload=payload,
            )
        except APIError as exc:
            raise CommandError(
                f"Profile {profile!r}: sync failed ({exc.status_code}): {exc.body}"
            ) from exc

        _print_summary(self.stdout, self.style, summary)


def _resolve_policies(items, client, *, profile: str) -> str:
    """Resolve a normalized policy list into a single composed string.

    Walks the registry's ``graft_config.policies`` list (which is
    always a list after :func:`decorators._normalise_policies` runs).
    Each item is either a free-form string or a :class:`PolicyRef`.
    PolicyRefs get fetched via the public Policy Shop endpoint; the
    fetched body is substituted in place. Strings pass through
    unchanged. Non-empty results are joined by a blank line so the
    composed text reads as discrete sections in the system prompt.

    A :class:`PolicyRef` whose codename doesn't exist in the
    catalogue surfaces as a :class:`CommandError` with the typo
    spelled out — sync refuses to push partial state.
    """
    parts: list[str] = []
    for item in items or []:
        if isinstance(item, PolicyRef):
            try:
                policy_data = client.fetch_policy(item.codename)
            except APIError as exc:
                if exc.status_code == 404:
                    raise CommandError(
                        f"Profile {profile!r}: policy "
                        f"{item.codename!r} not found in the AgentGraft "
                        f"Policy Shop. Browse the catalogue at "
                        f"{client.api_base}/api/v1/policies/ for the "
                        f"list of valid codenames."
                    ) from exc
                raise
            body = (policy_data.get("body") or "").strip()
            if body:
                parts.append(body)
        elif isinstance(item, str):
            stripped = item.strip()
            if stripped:
                parts.append(stripped)
        # Anything else was already rejected by _normalise_policies.
    return "\n\n".join(parts)


def _build_payload(registry, profile_config: dict, resolved_policies: str) -> dict:
    """Serialize the in-memory registry into the sync request body.

    ``resolved_policies`` is the composed policy text from
    :func:`_resolve_policies` — a single string ready to land in the
    Graft model's ``policies`` TextField.
    """
    tools = [
        {
            "name": tool.name,
            "description": tool.description,
            "parameters_schema": tool.parameters_schema,
        }
        for tool in registry.tools.values()
    ]
    agents = [
        {
            "name": agent.name,
            "instructions": agent.instructions,
            "tool_names": agent.tool_names,
            "handoff_names": agent.handoff_names,
            "sub_agent_names": agent.sub_agent_names,
            "model_tier": agent.model_tier,
            "is_entry_point": agent.is_entry_point,
        }
        for agent in registry.agents.values()
    ]

    graft_meta = {
        # Display name — overwrites whatever the graft was minted with
        # at signup ("First's Default Graft") so the dashboard label
        # matches the host app's ``ag.graft(name="...")`` declaration.
        # Skipped server-side if absent or empty.
        "name": registry.graft_config.name or "",
        "identity": registry.graft_config.identity,
        "product_context": registry.graft_config.product_context,
        "voice": registry.graft_config.voice,
        "scope": registry.graft_config.scope,
        "policies": resolved_policies,
        "greeting": registry.graft_config.greeting,
        "example_prompts": list(registry.graft_config.example_prompts or []),
    }

    body: dict = {"tools": tools, "agents": agents, "graft": graft_meta}

    # webhook_url comes from either the profile config OR the graft block
    # (profile config wins, since it's the operational source of truth).
    webhook_url = profile_config.get("webhook_url") or registry.graft_config.webhook_url
    if webhook_url:
        body["webhook_url"] = webhook_url

    return body


def _print_summary(stdout, style, summary: dict) -> None:
    def _line(prefix: str, items: list[str]) -> None:
        if items:
            stdout.write(f"  {prefix}: {', '.join(items)}")

    stdout.write(style.SUCCESS("Sync complete."))
    tools = summary.get("tools", {})
    agents = summary.get("agents", {})
    stdout.write("Tools:")
    _line("added", tools.get("added", []))
    _line("updated", tools.get("updated", []))
    _line("removed", tools.get("removed", []))
    stdout.write("Agents:")
    _line("added", agents.get("added", []))
    _line("updated", agents.get("updated", []))
    _line("removed", agents.get("removed", []))
    if summary.get("webhook_url_changed"):
        stdout.write("  webhook_url updated")
    changed_fields = summary.get("graft_fields_changed") or []
    if changed_fields:
        stdout.write(f"  graft fields updated: {', '.join(changed_fields)}")
