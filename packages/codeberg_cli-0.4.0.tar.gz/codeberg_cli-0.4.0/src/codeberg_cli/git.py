import subprocess
from pathlib import Path
from urllib.parse import urlparse


def parse_repo_from_remote(remote_url: str) -> str:
    """Extract owner/repo from a git remote URL."""
    # HTTPS: https://hostname/owner/repo.git
    parsed = urlparse(remote_url)
    if parsed.scheme in ("http", "https"):
        path = parsed.path
    elif "@" in remote_url:
        # SSH: git@hostname:owner/repo.git
        path = remote_url.split(":", 1)[1]
    else:
        raise ValueError(f"Could not parse repo from remote: {remote_url}")

    path = path.rstrip("/")
    if path.endswith(".git"):
        path = path[:-4]
    owner_repo = path.removeprefix("/")
    if "/" not in owner_repo:
        raise ValueError(f"Could not parse repo from remote: {remote_url}")
    return owner_repo


def get_default_branch(cwd: Path) -> str:
    """Get the default branch name for a repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, check=True, cwd=cwd,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "main"


def get_repo_remote(cwd: Path | None = None) -> str | None:
    """Get the 'origin' remote URL from a git repo, or None."""
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True, text=True, check=True,
            cwd=cwd or Path.cwd(),
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def infer_repo(cwd: Path | None = None) -> str | None:
    """Infer owner/repo from git remote origin."""
    remote = get_repo_remote(cwd)
    if remote is None:
        return None
    try:
        return parse_repo_from_remote(remote)
    except ValueError:
        return None
