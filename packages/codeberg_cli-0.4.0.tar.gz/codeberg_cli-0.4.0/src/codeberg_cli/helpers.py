from __future__ import annotations

import json as _json
import sys
from collections.abc import Iterable, Mapping
from typing import Any

import rich

from codeberg_cli.client import Client, ClientError, DEFAULT_BASE_URL
from codeberg_cli.config import load_config


def is_json_mode() -> bool:
    """Check whether ``--json`` was passed on the CLI."""
    return "--json" in sys.argv[1:]


def output(
    data: Any,
    *,
    json: bool | None = None,
    default: str | None = None,
) -> None:
    """Print *data* as JSON or fall back to *default* text.

    When ``json=True`` (or global ``--json`` was passed), data is printed as
    prettified JSON.  When ``json=False`` the *default* string (if given) is
    printed.  When *default* is ``None`` and JSON mode is off, this is a no-op
    — the caller is expected to handle rich printing themselves.
    """
    if json is None:
        json = is_json_mode()
    if json:
        _json.dump(
            data,
            sys.stdout,
            indent=2,
            default=str,
        )
        sys.stdout.write("\n")
    elif default is not None:
        rich.print(default)


def print_table(
    columns: list[str],
    rows: Iterable[Iterable[str]],
    *,
    json: bool | None = None,
    json_data: Any = None,
    title: str | None = None,
) -> None:
    """Print a table, or JSON when ``--json`` is active.

    When JSON mode is on, *json_data* is printed as JSON (or *rows* converted
    to a list if no explicit json_data is given).  When not in JSON mode, a
    rich ``Table`` is printed.
    """
    if json is None:
        json = is_json_mode()
    if json:
        _json.dump(
            json_data if json_data is not None else list(rows),
            sys.stdout,
            indent=2,
            default=str,
        )
        sys.stdout.write("\n")
        return

    from rich.table import Table

    table = Table(*columns, title=title)
    for row in rows:
        table.add_row(*row)
    rich.print(table)


def get_base_url() -> str:
    """Get the web base URL from cascading CLI context or default."""
    from xclif.context import get_context

    try:
        ctx = get_context()
        raw = ctx.get("base_url", DEFAULT_BASE_URL)
    except RuntimeError:
        raw = DEFAULT_BASE_URL

    # Normalize: ensure scheme, strip API path suffix for backward compat
    if "://" not in raw:
        raw = "https://" + raw
    raw = raw.rstrip("/")
    if raw.endswith("/api/v1"):
        raw = raw[:-7]
    return raw


def get_web_base_url() -> str:
    """Derive the web UI base URL from the API base URL."""
    return get_base_url()


def get_authenticated_client(base_url: str | None = None) -> Client | None:
    """Return a Client if token is stored, else None."""
    config = load_config()
    token = config.get("token")
    if not token:
        return None
    return Client(token=token, base_url=base_url or get_base_url())


def require_client(base_url: str | None = None) -> Client:
    """Return an authenticated Client or print error and exit."""
    client = get_authenticated_client(base_url=base_url)
    if client is None:
        from xclif.errors import UsageError

        raise UsageError("Not logged in. Run 'cb auth login' first.")
    return client
