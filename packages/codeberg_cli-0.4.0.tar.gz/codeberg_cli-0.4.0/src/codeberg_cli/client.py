import httpx
from rich.status import Status
from xclif.context import get_context

DEFAULT_BASE_URL = "https://codeberg.org"

_VERBS = {
    "GET": "Fetching",
    "POST": "Creating",
    "PUT": "Updating",
    "PATCH": "Updating",
    "DELETE": "Deleting",
}


class ClientError(RuntimeError):
    """Raised when the API returns a non-2xx status."""


class Client:
    """HTTP client for the Codeberg API."""

    def __init__(self, token: str | None = None, base_url: str | None = None) -> None:
        headers = {
            "Accept": "application/json",
            "User-Agent": "codeberg-cli/0.1.0",
            "Content-Type": "application/json",
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"
        raw = base_url or DEFAULT_BASE_URL
        if "://" not in raw:
            raw = "https://" + raw
        raw = raw.rstrip("/")
        if not raw.endswith("/api/v1"):
            raw += "/api/v1"
        self._client = httpx.Client(base_url=raw, headers=headers, timeout=30.0)

    @property
    def base_url(self) -> str:
        """The API base URL used by this client."""
        return str(self._client.base_url)

    def get(
        self, path: str, params: dict | None = None, action: str | None = None
    ) -> dict | list:
        return self._request("GET", path, params=params, action=action)

    def post(
        self, path: str, data: dict | None = None, action: str | None = None
    ) -> dict | list:
        return self._request("POST", path, json=data, action=action)

    def patch(
        self, path: str, data: dict | None = None, action: str | None = None
    ) -> dict | list:
        return self._request("PATCH", path, json=data, action=action)

    def put(
        self, path: str, data: dict | None = None, action: str | None = None
    ) -> dict | list:
        return self._request("PUT", path, json=data, action=action)

    def delete(self, path: str, action: str | None = None) -> None:
        self._request("DELETE", path, action=action)

    def _request(
        self, method: str, path: str, action: str | None = None, **kwargs
    ) -> dict | list | None:
        try:
            ctx = get_context()
            verbosity = ctx.verbosity
        except RuntimeError:
            verbosity = 0
        label = action or (
            f"{method} {path}"
            if verbosity >= 2
            else f"{_VERBS.get(method, method)} {path.split('/')[-1]}"
        )
        with Status(f"{label}..."):
            response = self._client.request(method, path, **kwargs)
        if not response.is_success:
            msg = (
                response.json().get("message", "unknown error")
                if response.text
                else "unknown error"
            )
            raise ClientError(f"{response.status_code} {msg}")
        if response.status_code == 204:
            return None
        return response.json()
