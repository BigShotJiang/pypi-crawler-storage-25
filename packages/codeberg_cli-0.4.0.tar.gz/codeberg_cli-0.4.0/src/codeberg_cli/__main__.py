from xclif import Cli

from . import routes

cli = Cli.from_routes(routes, config_name="codeberg-cli")

if __name__ == "__main__":
    cli()
