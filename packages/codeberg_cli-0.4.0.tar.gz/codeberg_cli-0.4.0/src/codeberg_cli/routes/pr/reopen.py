from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("reopen")
def _(
    id: Annotated[int, Arg(description="PR number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Reopen a closed pull request."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.patch(f"/repos/{repo}/pulls/{id}", data={"state": "open"})
    rich.print(f"[bold green]Reopened[/bold green] PR #{id} in {repo}")
