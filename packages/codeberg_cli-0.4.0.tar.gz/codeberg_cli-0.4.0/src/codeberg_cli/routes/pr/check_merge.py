from typing import Annotated

import rich

from codeberg_cli.client import ClientError
from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("check-merge")
def _(
    id: Annotated[int, Arg(description="PR number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Check if a pull request has been merged."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    try:
        client.get(f"/repos/{repo}/pulls/{id}/merge")
        rich.print("[bold green]Merged[/bold green]")
    except ClientError as e:
        if "404" in str(e):
            rich.print("[bold yellow]Not merged[/bold yellow]")
        else:
            raise
