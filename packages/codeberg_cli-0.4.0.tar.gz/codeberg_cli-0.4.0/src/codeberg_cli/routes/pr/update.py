from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("update")
def _(
    id: Annotated[int, Arg(description="PR number")],
    style: Annotated[str, Option(description="Merge style: merge, rebase", name="style")] = "merge",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Update a pull request from base branch."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.post(f"/repos/{repo}/pulls/{id}/update", data={"style": style})
    rich.print(f"[bold green]Updated[/bold green] PR #{id} from base branch ({style})")
