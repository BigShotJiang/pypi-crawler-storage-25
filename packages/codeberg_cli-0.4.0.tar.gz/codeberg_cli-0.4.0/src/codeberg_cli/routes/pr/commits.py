from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Arg, Option, command


@command("commits")
def _(
    id: Annotated[int, Arg(description="PR number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List commits in a pull request."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    commits = client.get(f"/repos/{repo}/pulls/{id}/commits")

    if not commits:
        rich.print(f"[dim]No commits in PR #{id}.[/dim]")
        return

    rows = []
    json_rows = []
    for c in commits:
        sha = c["sha"][:8]
        author = c["commit"]["author"].get("name", "")
        message = c["commit"]["message"].split("\n")[0]
        rows.append((sha, author, message))
        json_rows.append({
            "sha": c["sha"],
            "author": author,
            "message": message,
        })

    print_table(["SHA", "Author", "Message"], rows, json_data=json_rows)
