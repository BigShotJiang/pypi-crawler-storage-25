from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("list", "ls")
def _(
    state: Annotated[str, Option(description="Filter by state: open, closed", name="state")] = "open",
    limit: Annotated[int, Option(description="Maximum PRs to show", name="limit")] = 30,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List pull requests."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    pulls = client.get(f"/repos/{repo}/pulls", params={"state": state, "limit": limit, "page": 1})

    if not pulls:
        rich.print(f"[dim]No {state} PRs in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for pr in pulls:
        rows.append((str(pr["number"]), pr["title"], pr["user"]["login"], f"{pr['base']['ref']} \u2192 {pr['head']['ref']}"))
        json_rows.append({
            "number": pr["number"],
            "title": pr["title"],
            "author": pr["user"]["login"],
            "state": pr.get("state"),
            "base": pr["base"]["ref"],
            "head": pr["head"]["ref"],
            "created_at": pr.get("created_at"),
            "draft": pr.get("draft", False),
        })

    print_table(["#", "Title", "Author", "Base → Head"], rows, json_data=json_rows)


