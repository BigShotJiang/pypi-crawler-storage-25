import subprocess
from pathlib import Path
from typing import Annotated

import rich

from codeberg_cli.git import get_default_branch, infer_repo
from codeberg_cli.helpers import get_web_base_url, require_client
from xclif import Option, command


@command("create")
def _(
    title: Annotated[str, Option(description="PR title", name="title")] = "",
    body: Annotated[str, Option(description="PR body", name="body")] = "",
    base: Annotated[str, Option(description="Base branch", name="base")] = "",
    head: Annotated[str, Option(description="Head branch (default: current branch)", name="head")] = "",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Create a pull request."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if not base:
        base = get_default_branch(Path.cwd())

    if not head:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True,
        )
        head = result.stdout.strip()

    if not title:
        title = input("Title: ").strip()
        if not title:
            rich.print("[bold red]Error:[/bold red] Title is required")
            return 1

    if not body:
        rich.print("[dim]Enter body (Ctrl+D to finish, or leave empty):[/dim]")
        try:
            lines = []
            while True:
                line = input()
                lines.append(line)
        except (EOFError, KeyboardInterrupt):
            pass
        body = "\n".join(lines).strip()

    data = {
        "title": title,
        "body": body,
        "base": base,
        "head": head,
    }

    result = client.post(f"/repos/{repo}/pulls", data=data)
    rich.print(f"[bold green]Created PR[/bold green] #{result['number']}: {result['title']}")
    rich.print(f"[dim]{get_web_base_url()}/{repo}/pulls/{result['number']}[/dim]")


