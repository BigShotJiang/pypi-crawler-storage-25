import webbrowser
from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import get_web_base_url, is_json_mode, output, require_client
from xclif import Arg, Option, command


@command("view")
def _(
    id: Annotated[int, Arg(description="PR number")],
    web: Annotated[bool, Option(description="Open in browser", name="web")] = False,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """View a pull request."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if web:
        webbrowser.open(f"{get_web_base_url()}/{repo}/pulls/{id}")
        return

    pr = client.get(f"/repos/{repo}/pulls/{id}")

    if is_json_mode():
        output(pr)
        return

    state_color = "green" if pr["state"] == "open" else "red"
    merged = "[bold magenta]MERGED[/bold magenta] " if pr.get("merged") else ""
    rich.print(f"[bold]#{pr['number']}[/bold] [bold]{pr['title']}[/bold]")
    rich.print(f"{merged}[{state_color}]{pr['state']}[/{state_color}] [dim]by {pr['user']['login']}[/dim]")
    rich.print(f"  [dim]{pr['base']['ref']}[/dim] \u2190 [dim]{pr['head']['ref']}[/dim]")
    if pr.get("body"):
        rich.print()
        rich.print(pr["body"])


