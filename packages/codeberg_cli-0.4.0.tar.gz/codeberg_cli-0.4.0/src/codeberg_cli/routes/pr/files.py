from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Arg, Option, command


@command("files")
def _(
    id: Annotated[int, Arg(description="PR number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List changed files in a pull request."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    files = client.get(f"/repos/{repo}/pulls/{id}/files")

    if not files:
        rich.print(f"[dim]No changed files in PR #{id}.[/dim]")
        return

    rows = []
    json_rows = []
    for f in files:
        rows.append((f["filename"], f.get("status", ""), str(f.get("additions", 0)), str(f.get("deletions", 0))))
        json_rows.append({
            "filename": f["filename"],
            "status": f.get("status", ""),
            "additions": f.get("additions", 0),
            "deletions": f.get("deletions", 0),
        })

    print_table(["Filename", "Status", "Additions", "Deletions"], rows, json_data=json_rows)
