from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("edit")
def _(
    id: Annotated[int, Arg(description="PR number")],
    title: Annotated[str, Option(description="New title", name="title")] = "",
    body: Annotated[str, Option(description="New body", name="body")] = "",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Edit a pull request's title or body."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data: dict = {}
    if title:
        data["title"] = title
    if body:
        data["body"] = body

    if not data:
        rich.print("[bold yellow]Nothing to update.[/bold yellow] Pass --title and/or --body.")
        return 1

    client.patch(f"/repos/{repo}/pulls/{id}", data=data)
    rich.print(f"[bold green]Updated[/bold green] PR #{id} in {repo}")
