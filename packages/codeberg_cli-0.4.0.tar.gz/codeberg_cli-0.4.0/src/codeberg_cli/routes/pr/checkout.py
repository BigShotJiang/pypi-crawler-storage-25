import subprocess
from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("checkout", "co")
def _(
    id: Annotated[int, Arg(description="PR number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Checkout a pull request locally."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    pr = client.get(f"/repos/{repo}/pulls/{id}")
    branch = pr["head"]["ref"]
    repo_url = pr["head"]["repo"]["clone_url"]

    rich.print(f"Fetching PR #{id} ({branch})...")
    subprocess.run(
        ["git", "fetch", repo_url, branch],
        check=True,
    )
    result = subprocess.run(
        ["git", "checkout", branch],
    )
    if result.returncode != 0:
        subprocess.run(["git", "checkout", "-b", branch, "FETCH_HEAD"], check=True)
    rich.print(f"[bold green]Checked out[/bold green] PR #{id} as [bold]{branch}[/bold]")


