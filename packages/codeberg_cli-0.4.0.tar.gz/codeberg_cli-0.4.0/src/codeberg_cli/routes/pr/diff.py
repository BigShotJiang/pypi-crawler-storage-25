from typing import Annotated

import httpx
import rich

from codeberg_cli.client import ClientError
from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("diff")
def _(
    id: Annotated[int, Arg(description="PR number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Get the diff of a pull request."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    response = client._client.get(f"/repos/{repo}/pulls/{id}.diff")
    if not response.is_success:
        msg = response.json().get("message", "unknown error") if response.text else "unknown error"
        raise ClientError(f"{response.status_code} {msg}")
    rich.print(response.text)
