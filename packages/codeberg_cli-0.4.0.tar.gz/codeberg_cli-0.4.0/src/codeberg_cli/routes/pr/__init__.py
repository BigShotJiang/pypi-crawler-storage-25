from xclif import command


@command("pr")
def _() -> None:
    """Manage pull requests — create, list, comment, and more."""
