from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("merge")
def _(
    id: Annotated[int, Arg(description="PR number")],
    style: Annotated[str, Option(description="Merge style: merge, rebase, squash", name="style")] = "merge",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Merge a pull request."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data = {
        "Do": style,
    }
    client.post(f"/repos/{repo}/pulls/{id}/merge", data=data)
    rich.print(f"[bold green]Merged[/bold green] #{id} in {repo}")


