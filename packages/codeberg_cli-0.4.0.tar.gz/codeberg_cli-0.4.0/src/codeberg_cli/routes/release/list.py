from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("list", "ls")
def _(
    limit: Annotated[int, Option(description="Maximum releases to show", name="limit")] = 30,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List releases."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    releases = client.get(f"/repos/{repo}/releases", params={"limit": limit, "page": 1})

    if not releases:
        rich.print(f"[dim]No releases in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for r in releases:
        release_type = "draft" if r.get("draft") else "prerelease" if r.get("prerelease") else "release"
        rows.append((r["tag_name"], r.get("name", ""), release_type, str(len(r.get("assets", [])))))
        json_rows.append({
            "tag_name": r["tag_name"],
            "name": r.get("name", ""),
            "type": release_type,
            "assets": len(r.get("assets", [])),
            "created_at": r.get("created_at", ""),
        })

    print_table(["Tag", "Title", "Type", "Assets"], rows, json_data=json_rows)

