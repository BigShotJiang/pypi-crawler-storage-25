import webbrowser
from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import get_web_base_url, is_json_mode, output, require_client
from xclif import Arg, Option, command


@command("view")
def _(
    id: Annotated[str, Arg(description="Release ID or tag name")],
    web: Annotated[bool, Option(description="Open in browser", name="web")] = False,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """View a release."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if id == "latest":
        release = client.get(f"/repos/{repo}/releases/latest")
    elif id.isdigit():
        release = client.get(f"/repos/{repo}/releases/{id}")
    else:
        release = client.get(f"/repos/{repo}/releases/tags/{id}")

    if web:
        webbrowser.open(release.get("html_url", f"{get_web_base_url()}/{repo}/releases/tag/{release['tag_name']}"))
        return

    if is_json_mode():
        output(release)
        return

    rich.print(f"[bold]{release.get('name', release['tag_name'])}[/bold]")
    rich.print(f"  [dim]Tag:[/dim] {release['tag_name']}")
    rich.print(f"  [dim]Draft:[/dim] {release.get('draft', False)}")
    rich.print(f"  [dim]Prerelease:[/dim] {release.get('prerelease', False)}")

    if release.get("body"):
        rich.print()
        rich.print(release["body"])

    assets = release.get("assets", [])
    if assets:
        rich.print()
        rich.print(f"[bold]{len(assets)} asset(s)[/bold]")
        for asset in assets:
            size = asset.get("size", 0)
            size_str = f"{size / 1024:.1f} KB" if size < 1024 * 1024 else f"{size / 1024 / 1024:.1f} MB"
            rich.print(f"  [dim]-[/dim] {asset['name']} ({size_str})")

