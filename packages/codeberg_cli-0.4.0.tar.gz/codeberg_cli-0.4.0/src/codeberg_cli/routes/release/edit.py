from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("edit")
def _(
    id: Annotated[int, Arg(description="Release ID")],
    name: Annotated[str, Option(description="Release title", name="name")] = "",
    body: Annotated[str, Option(description="Release body text", name="body")] = "",
    tag_name: Annotated[str, Option(description="Tag name", name="tag-name")] = "",
    target_commitish: Annotated[str, Option(description="Target commit SHA or branch", name="target-commitish")] = "",
    draft: Annotated[bool, Option(description="Mark as draft", name="draft")] = False,
    no_draft: Annotated[bool, Option(description="Remove draft status", name="no-draft")] = False,
    prerelease: Annotated[bool, Option(description="Mark as prerelease", name="prerelease")] = False,
    no_prerelease: Annotated[bool, Option(description="Remove prerelease status", name="no-prerelease")] = False,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Edit a release."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    body_data: dict = {}
    if name:
        body_data["name"] = name
    if body:
        body_data["body"] = body
    if tag_name:
        body_data["tag_name"] = tag_name
    if target_commitish:
        body_data["target_commitish"] = target_commitish
    if draft:
        body_data["draft"] = True
    if no_draft:
        body_data["draft"] = False
    if prerelease:
        body_data["prerelease"] = True
    if no_prerelease:
        body_data["prerelease"] = False

    if not body_data:
        rich.print("[bold yellow]Nothing to update.[/bold yellow] Pass at least one option to change.")
        return 1

    client.patch(f"/repos/{repo}/releases/{id}", data=body_data)
    rich.print(f"[bold green]Updated release[/bold green] #{id} in {repo}")
