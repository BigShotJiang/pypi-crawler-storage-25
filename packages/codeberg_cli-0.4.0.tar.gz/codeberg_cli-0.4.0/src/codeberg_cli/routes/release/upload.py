from pathlib import Path
from typing import Annotated

import httpx
import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("upload")
def _(
    id: Annotated[int, Arg(description="Release ID")],
    file: Annotated[str, Arg(description="File to upload")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Upload a release asset."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    file_path = Path(file)
    if not file_path.exists():
        rich.print(f"[bold red]Error:[/bold red] File not found: {file}")
        return 1

    with open(file_path, "rb") as f:
        content = f.read()

    # Direct multipart upload (bypasses Client for multipart support)
    token = client._client.headers.get("Authorization", "").replace("Bearer ", "")
    headers = {"Authorization": f"Bearer {token}"}

    response = httpx.post(
        f"{client.base_url}/repos/{repo}/releases/{id}/assets",
        headers=headers,
        files={"attachment": (file_path.name, content)},
    )
    if response.is_success:
        rich.print(f"[bold green]Uploaded[/bold green] {file_path.name} to release #{id}")
    else:
        msg = response.json().get("message", "unknown error") if response.text else "unknown error"
        rich.print(f"[bold red]Error:[/bold red] {response.status_code} {msg}")
        return 1

