from xclif import command


@command("release")
def _() -> None:
    """Manage releases — create, list, view, and upload assets."""
