from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import get_web_base_url, require_client
from xclif import Arg, Option, command


@command("create")
def _(
    tag: Annotated[str, Arg(description="Git tag for the release")],
    title: Annotated[str, Option(description="Release title", name="title")] = "",
    notes: Annotated[str, Option(description="Release notes", name="notes")] = "",
    prerelease: Annotated[bool, Option(description="Mark as prerelease", name="prerelease")] = False,
    draft: Annotated[bool, Option(description="Create as draft", name="draft")] = False,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Create a release."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data = {
        "tag_name": tag,
        "name": title or tag,
        "body": notes,
        "prerelease": prerelease,
        "draft": draft,
    }

    result = client.post(f"/repos/{repo}/releases", data=data)
    rich.print(f"[bold green]Created release[/bold green] {result.get('name', tag)}")
    rich.print(f"[dim]{get_web_base_url()}/{repo}/releases/tag/{tag}[/dim]")

