import json
from typing import Annotated

import rich

from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("api")
def _(
    method: Annotated[str, Arg(description="HTTP method (GET, POST, PATCH, DELETE)")],
    path: Annotated[str, Arg(description="API path (e.g. /repos/owner/repo)")],
    data: Annotated[str, Option(description="JSON body for POST/PATCH", name="data")] = "",
) -> None:
    """Make an authenticated API request to Codeberg."""
    client = require_client()
    kwargs = {}
    if data:
        kwargs["json"] = json.loads(data)
    result = client._request(method.upper(), path, **kwargs)
    if result is not None:
        rich.print_json(data=result)
