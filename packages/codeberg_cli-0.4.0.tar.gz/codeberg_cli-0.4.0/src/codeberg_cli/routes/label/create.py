from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("create")
def _(
    name: Annotated[str, Arg(description="Label name")],
    color: Annotated[str, Option(description="Label color (hex, e.g. ff0000)")] = "",
    description: Annotated[str, Option(description="Label description", name="description")] = "",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Create a label."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data: dict = {"name": name}
    if color:
        data["color"] = color.lstrip("#")
    if description:
        data["description"] = description

    label = client.post(f"/repos/{repo}/labels", data=data)

    rich.print(f"[bold green]Created label[/bold green] {label['name']} (#{label['color']})")
