from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("edit")
def _(
    label_id: Annotated[int, Arg(description="Label ID")],
    name: Annotated[str, Option(description="New label name", name="name")] = "",
    color: Annotated[str, Option(description="New label color (hex, e.g. ff0000)", name="color")] = "",
    description: Annotated[str, Option(description="New label description", name="description")] = "",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Edit a label."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    body: dict = {}
    if name:
        body["name"] = name
    if color:
        body["color"] = color.lstrip("#")
    if description:
        body["description"] = description

    if not body:
        rich.print("[bold yellow]Nothing to update.[/bold yellow] Pass --name, --color, and/or --description.")
        return 1

    client.patch(f"/repos/{repo}/labels/{label_id}", data=body)
    rich.print(f"[bold green]Updated label[/bold green] #{label_id} in {repo}")
