from xclif import command


@command("label")
def _() -> None:
    """Manage repository labels — create, list, and delete."""
