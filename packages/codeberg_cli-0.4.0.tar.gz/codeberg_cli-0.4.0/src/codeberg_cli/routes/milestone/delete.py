from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("delete", "rm")
def _(
    id: Annotated[int, Arg(description="Milestone ID")],
    yes: Annotated[bool, Option(description="Skip confirmation", name="yes")] = False,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Delete a milestone."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if not yes:
        rich.print(f"[bold yellow]Are you sure you want to delete milestone #{id} from {repo}?[/bold yellow]")
        try:
            response = input("Type 'yes' to confirm: ")
        except (EOFError, KeyboardInterrupt):
            rich.print()
            return 1
        if response.strip().lower() != "yes":
            rich.print("[dim]Cancelled.[/dim]")
            return

    client.delete(f"/repos/{repo}/milestones/{id}")
    rich.print(f"[bold green]Deleted milestone[/bold green] #{id}")
