from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import is_json_mode, output, require_client
from xclif import Arg, Option, command


@command("view")
def _(
    id: Annotated[int, Arg(description="Milestone ID")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """View a milestone."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    ms = client.get(f"/repos/{repo}/milestones/{id}")

    if is_json_mode():
        output(ms)
        return

    state_color = "green" if ms.get("state") == "open" else "red"
    rich.print(f"[bold]#{ms['id']}[/bold] [bold]{ms['title']}[/bold]")
    rich.print(f"  [dim]State:[/dim] [{state_color}]{ms.get('state', '')}[/{state_color}]")
    rich.print(f"  [dim]Open issues:[/dim] {ms.get('open_issues', 0)}")
    rich.print(f"  [dim]Closed issues:[/dim] {ms.get('closed_issues', 0)}")
    due_on = ms.get("due_on", "")
    if due_on:
        rich.print(f"  [dim]Due date:[/dim] {due_on[:10]}")

    if ms.get("description"):
        rich.print()
        rich.print(ms["description"])
