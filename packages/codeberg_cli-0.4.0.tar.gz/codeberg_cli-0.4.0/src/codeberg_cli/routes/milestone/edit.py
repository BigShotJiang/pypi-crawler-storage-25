from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("edit")
def _(
    id: Annotated[int, Arg(description="Milestone ID")],
    title: Annotated[str, Option(description="New title", name="title")] = "",
    description: Annotated[str, Option(description="New description", name="description")] = "",
    due_on: Annotated[str, Option(description="Due date (YYYY-MM-DD)", name="due-on")] = "",
    state: Annotated[str, Option(description="New state: open, closed", name="state")] = "",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Edit a milestone."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    body: dict = {}
    if title:
        body["title"] = title
    if description:
        body["description"] = description
    if due_on:
        body["due_on"] = due_on
    if state:
        body["state"] = state

    if not body:
        rich.print("[bold yellow]Nothing to update.[/bold yellow] Pass at least one option to change.")
        return 1

    client.patch(f"/repos/{repo}/milestones/{id}", data=body)
    rich.print(f"[bold green]Updated milestone[/bold green] #{id} in {repo}")
