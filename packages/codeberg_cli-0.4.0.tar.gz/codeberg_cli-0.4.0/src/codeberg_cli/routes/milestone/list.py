from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("list", "ls")
def _(
    state: Annotated[str, Option(description="Filter by state: open, closed", name="state")] = "open",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
    limit: Annotated[int, Option(description="Maximum milestones to show", name="limit")] = 30,
) -> None:
    """List milestones."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    milestones = client.get(f"/repos/{repo}/milestones", params={"state": state, "limit": limit})

    if not milestones:
        rich.print(f"[dim]No {state} milestones in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for ms in milestones:
        due = (ms.get("due_on") or "")[:10]
        rows.append((str(ms["id"]), ms["title"], ms["state"], f"{ms.get('open_issues', 0)} / {ms.get('closed_issues', 0)}", due))
        json_rows.append({
            "id": ms["id"],
            "title": ms["title"],
            "state": ms["state"],
            "open_issues": ms.get("open_issues", 0),
            "closed_issues": ms.get("closed_issues", 0),
            "due_on": due,
        })

    print_table(["#", "Title", "State", "Open / Closed", "Due Date"], rows, json_data=json_rows)
