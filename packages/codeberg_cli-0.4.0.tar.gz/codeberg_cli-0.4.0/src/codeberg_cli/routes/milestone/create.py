from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("create")
def _(
    title: Annotated[str, Arg(description="Milestone title")],
    description: Annotated[str, Option(description="Milestone description")] = "",
    due_on: Annotated[str, Option(description="Due date (YYYY-MM-DD)")] = "",
    repo: Annotated[str, Option(description="Repository (owner/repo)")] = "",
) -> None:
    """Create a milestone."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data: dict = {"title": title}
    if description:
        data["description"] = description
    if due_on:
        data["due_on"] = due_on

    ms = client.post(f"/repos/{repo}/milestones", data=data)

    rich.print(f"[bold green]Created milestone[/bold green] #{ms['id']}: {ms['title']}")
