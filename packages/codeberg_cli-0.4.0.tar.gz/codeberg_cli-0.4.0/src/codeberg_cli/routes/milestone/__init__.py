from xclif import command


@command("milestone")
def _() -> None:
    """Manage milestones — create and list."""
