from codeberg_cli.client import DEFAULT_BASE_URL
from xclif import Cascade, WithConfig, command


@command("cb")
def _(
    base_url: Cascade[WithConfig[str]] = DEFAULT_BASE_URL,
    json: bool = False,
) -> None:
    """Interact with Codeberg or any Forgejo instance — manage repos, issues, PRs, releases, actions, and more.

    Use --json on any command for machine-readable output.
    """
