from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("unpin")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Unpin an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.delete(f"/repos/{repo}/issues/{id}/pin")
    rich.print(f"[bold green]Unpinned[/bold green] issue #{id} in {repo}")
