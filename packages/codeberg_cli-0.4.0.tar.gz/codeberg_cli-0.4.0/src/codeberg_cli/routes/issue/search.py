from typing import Annotated

import rich

from codeberg_cli.helpers import print_table, require_client
from xclif import Arg, Option, command


@command("search")
def _(
    query: Annotated[str, Arg(description="Search query")],
    state: Annotated[str, Option(description="Filter by state: open, closed", name="state")] = "open",
    limit: Annotated[int, Option(description="Maximum results to show", name="limit")] = 30,
    repo: Annotated[str, Option(description="Repository (owner/repo) to scope search", name="repo")] = "",
) -> None:
    """Search issues across repositories."""
    client = require_client()

    params = {"q": query, "state": state, "limit": limit, "page": 1}

    if repo:
        # Scope search to a specific repository
        if "/" in repo:
            owner, name = repo.split("/", 1)
            params["owner"] = owner
            params["repo"] = name
        else:
            params["repo"] = repo

    results = client.get("/repos/issues/search", params=params)

    if not results:
        rich.print(f"[dim]No issues found matching \"{query}\".[/dim]")
        return

    rows = []
    json_rows = []
    for issue in results:
        labels_str = ", ".join(l["name"] for l in (issue.get("labels") or []))
        rows.append((
            str(issue["number"]),
            issue["title"],
            issue["user"]["login"],
            issue.get("repository", {}).get("full_name", ""),
            issue["state"],
            labels_str,
        ))
        json_rows.append({
            "number": issue["number"],
            "title": issue["title"],
            "author": issue["user"]["login"],
            "repo": issue.get("repository", {}).get("full_name", ""),
            "state": issue["state"],
            "labels": [l["name"] for l in (issue.get("labels") or [])],
            "created_at": issue.get("created_at"),
            "updated_at": issue.get("updated_at"),
        })

    print_table(["#", "Title", "Author", "Repo", "State", "Labels"], rows, json_data=json_rows)
