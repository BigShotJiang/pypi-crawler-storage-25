from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("delete")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Delete an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    confirm = input(f"Are you sure you want to delete issue #{id} in {repo}? [y/N] ").strip().lower()
    if confirm != "y":
        rich.print("[dim]Cancelled.[/dim]")
        return

    client.delete(f"/repos/{repo}/issues/{id}")
    rich.print(f"[bold green]Deleted[/bold green] issue #{id} in {repo}")
