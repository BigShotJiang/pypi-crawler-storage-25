from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("subscribe")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Subscribe to an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    user = client.get("/user")["login"]
    client.put(f"/repos/{repo}/issues/{id}/subscriptions/{user}")
    rich.print(f"[bold green]Subscribed[/bold green] to issue #{id} in {repo}")
