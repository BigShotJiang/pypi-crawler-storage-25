from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import get_web_base_url, require_client
from xclif import Option, command


@command("create")
def _(
    title: Annotated[str, Option(description="Issue title", name="title")] = "",
    body: Annotated[str, Option(description="Issue body", name="body")] = "",
    labels: Annotated[str, Option(description="Comma-separated label names", name="labels")] = "",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Create an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if not title:
        title = input("Title: ").strip()
        if not title:
            rich.print("[bold red]Error:[/bold red] Title is required")
            return 1

    if not body:
        rich.print("[dim]Enter body (Ctrl+D to finish, or leave empty):[/dim]")
        try:
            lines = []
            while True:
                line = input()
                lines.append(line)
        except (EOFError, KeyboardInterrupt):
            pass
        body = "\n".join(lines).strip()

    data = {"title": title}
    if body:
        data["body"] = body
    if labels:
        data["labels"] = [l.strip() for l in labels.split(",")]

    result = client.post(f"/repos/{repo}/issues", data=data)

    rich.print(f"[bold green]Created issue[/bold green] #{result['number']}: {result['title']}")
    rich.print(f"[dim]{get_web_base_url()}/{repo}/issues/{result['number']}[/dim]")


