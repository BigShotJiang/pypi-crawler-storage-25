import webbrowser
from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import get_web_base_url, is_json_mode, output, require_client
from xclif import Arg, Option, command


@command("view")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    web: Annotated[bool, Option(description="Open in browser", name="web")] = False,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """View an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if web:
        webbrowser.open(f"{get_web_base_url()}/{repo}/issues/{id}")
        return

    issue = client.get(f"/repos/{repo}/issues/{id}")
    comments = client.get(f"/repos/{repo}/issues/{id}/comments")

    if is_json_mode():
        output({"issue": issue, "comments": comments})
        return

    state_color = "green" if issue["state"] == "open" else "red"
    rich.print(f"[bold]#{issue['number']}[/bold] [bold]{issue['title']}[/bold]")
    rich.print(f"[{state_color}]{issue['state']}[/{state_color}] [dim]by {issue['user']['login']}[/dim]")
    if issue.get("body"):
        rich.print()
        rich.print(issue["body"])
    if comments:
        rich.print()
        rich.print(f"[bold]{len(comments)} comments[/bold]")
        for comment in comments:
            rich.print(f"  [dim]{comment['user']['login']}:[/dim] {comment.get('body', '')[:100]}")


