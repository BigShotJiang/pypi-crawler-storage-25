from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("list", "ls")
def _(
    state: Annotated[str, Option(description="Filter by state: open, closed", name="state")] = "open",
    label: Annotated[str, Option(description="Filter by label", name="label")] = "",
    limit: Annotated[int, Option(description="Maximum issues to show", name="limit")] = 30,
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List issues."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    params = {"state": state, "limit": limit, "page": 1, "type": "issues"}
    if label:
        params["labels"] = label

    issues = client.get(f"/repos/{repo}/issues", params=params)

    if not issues:
        rich.print(f"[dim]No {state} issues in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for issue in issues:
        labels_str = ", ".join(l["name"] for l in (issue.get("labels") or []))
        rows.append((str(issue["number"]), issue["title"], issue["user"]["login"], labels_str))
        json_rows.append({
            "number": issue["number"],
            "title": issue["title"],
            "author": issue["user"]["login"],
            "state": issue.get("state"),
            "labels": [l["name"] for l in (issue.get("labels") or [])],
            "created_at": issue.get("created_at"),
            "updated_at": issue.get("updated_at"),
        })

    print_table(["#", "Title", "Author", "Labels"], rows, json_data=json_rows)


