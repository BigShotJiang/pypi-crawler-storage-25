from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("add")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    label: Annotated[str, Arg(description="Label name")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Add a label to an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.post(f"/repos/{repo}/issues/{id}/labels", data={"labels": [label]})
    rich.print(f"[bold green]Added label[/bold green] \"{label}\" to issue #{id} in {repo}")
