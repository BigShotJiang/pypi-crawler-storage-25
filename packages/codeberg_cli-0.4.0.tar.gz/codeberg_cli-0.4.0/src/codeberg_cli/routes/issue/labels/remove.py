from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("remove")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    label: Annotated[str, Arg(description="Label identifier")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Remove a label from an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.delete(f"/repos/{repo}/issues/{id}/labels/{label}")
    rich.print(f"[bold green]Removed label[/bold green] \"{label}\" from issue #{id} in {repo}")
