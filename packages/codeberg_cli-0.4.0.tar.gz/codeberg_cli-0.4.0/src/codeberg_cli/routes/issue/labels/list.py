from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Arg, Option, command


@command("list")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List labels on an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    labels = client.get(f"/repos/{repo}/issues/{id}/labels")

    if not labels:
        rich.print(f"[dim]No labels on issue #{id} in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for label in labels:
        color = label.get("color", "ffffff")
        rows.append((str(label["id"]), f"#{color} {label['name']}", f"#{color}", label.get("description", "") or ""))
        json_rows.append({
            "id": label["id"],
            "name": label["name"],
            "color": f"#{color}",
            "description": label.get("description", ""),
        })

    print_table(["#", "Name", "Color", "Description"], rows, json_data=json_rows)
