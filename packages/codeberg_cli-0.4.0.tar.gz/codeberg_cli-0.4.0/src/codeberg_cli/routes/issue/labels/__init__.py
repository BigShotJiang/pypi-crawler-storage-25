from xclif import command


@command("labels")
def _() -> None:
    """Manage issue labels — list, add, and remove."""
