from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("comment")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    message: Annotated[str, Option(description="Comment text", name="message")] = "",
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Comment on an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if not message:
        rich.print("[dim]Enter comment (Ctrl+D to finish):[/dim]")
        try:
            lines = []
            while True:
                line = input()
                lines.append(line)
        except (EOFError, KeyboardInterrupt):
            pass
        message = "\n".join(lines).strip()
        if not message:
            rich.print("[bold red]Error:[/bold red] Comment cannot be empty")
            return 1

    client.post(f"/repos/{repo}/issues/{id}/comments", data={"body": message})
    rich.print(f"[bold green]Commented[/bold green] on issue #{id} in {repo}")
