from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Arg, Option, command


@command("list")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List tracked time on an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    times = client.get(f"/repos/{repo}/issues/{id}/times")

    if not times:
        rich.print(f"[dim]No tracked time on issue #{id} in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for t in times:
        rows.append((str(t["id"]), t["user"]["login"], str(t.get("time", "")), t.get("created", "")[:10]))
        json_rows.append({
            "id": t["id"],
            "user": t["user"]["login"],
            "time": t.get("time"),
            "created": t.get("created"),
        })

    print_table(["#", "User", "Time (s)", "Date"], rows, json_data=json_rows)
