from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("add")
def _(
    id: Annotated[int, Arg(description="Issue number")],
    time: Annotated[str, Arg(description="Time to add (e.g. 1h30m)")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
    user: Annotated[str, Option(description="User to add time for", name="user")] = "",
) -> None:
    """Add tracked time to an issue."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if not user:
        user = client.get("/user")["login"]

    client.post(f"/repos/{repo}/issues/{id}/times", data={"time": time, "user": user})
    rich.print(f"[bold green]Added[/bold green] {time} to issue #{id} in {repo}")
