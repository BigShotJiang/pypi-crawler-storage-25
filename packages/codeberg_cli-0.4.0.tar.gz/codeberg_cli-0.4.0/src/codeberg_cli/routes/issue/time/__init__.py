from xclif import command


@command("time")
def _() -> None:
    """Manage tracked time on issues — list and add."""
