from xclif import command


@command("issue")
def _() -> None:
    """Manage issues — create, view, close, and more."""
