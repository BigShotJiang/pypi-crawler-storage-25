from typing import Annotated

import rich

from codeberg_cli.client import Client
from codeberg_cli.config import save_config
from xclif import Option, command


@command("login")
def _(
    token: Annotated[str, Option(description="Codeberg access token", name="token")] = "",
) -> None:
    """Authenticate with Codeberg using a personal access token."""
    if not token:
        token = input("Enter your Codeberg access token: ").strip()

    client = Client(token=token)
    user = client.get("/user", action="Verifying token")
    save_config({"token": token})
    rich.print(f"[bold green]Logged in as[/bold green] [bold]{user['login']}[/bold]")
