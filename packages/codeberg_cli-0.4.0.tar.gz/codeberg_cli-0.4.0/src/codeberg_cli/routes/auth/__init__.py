from xclif import command


@command("auth")
def _() -> None:
    """Manage authentication — login, logout, check status, and whoami."""
