import rich

from codeberg_cli.config import config_file_path
from xclif import command


@command("logout")
def _() -> None:
    """Remove stored Codeberg credentials."""
    path = config_file_path()
    if path.exists():
        path.unlink()
        rich.print("[dim]Logged out.[/dim]")
    else:
        rich.print("[dim]Not logged in.[/dim]")


