import rich

from codeberg_cli.helpers import get_authenticated_client
from xclif import command


@command("status")
def _() -> None:
    """Show authentication status."""
    client = get_authenticated_client()
    if client is None:
        rich.print("[yellow]Not logged in[/yellow]")
        rich.print("Run [bold]cb auth login[/bold] to authenticate.")
        return

    user = client.get("/user", action="Checking authentication")
    rich.print(f"Logged in to [cyan]Codeberg[/cyan] as [bold]{user['login']}[/bold]")
    rich.print(f"  User ID: {user['id']}")
    rich.print(f"  Full Name: {user.get('full_name', '(not set)')}")
