import rich

from codeberg_cli.helpers import require_client
from xclif import command


@command("whoami")
def _() -> None:
    """Print the current authenticated user's username."""
    client = require_client()
    user = client.get("/user")
    print(user["login"])
