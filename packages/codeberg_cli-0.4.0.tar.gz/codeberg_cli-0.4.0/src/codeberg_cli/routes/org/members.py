from typing import Annotated

import rich

from codeberg_cli.helpers import print_table, require_client
from xclif import Arg, command


@command("members")
def _(
    org: Annotated[str, Arg(description="Organization name")],
) -> None:
    """List members of an organization."""
    client = require_client()

    members = client.get(f"/orgs/{org}/members")

    if not members:
        rich.print(f"[dim]No members found in {org}.[/dim]")
        return

    rows = []
    json_rows = []
    for member in members:
        rows.append((member["login"], member.get("full_name", "")))
        json_rows.append({
            "login": member["login"],
            "full_name": member.get("full_name", ""),
        })

    print_table(["User", "Name"], rows, json_data=json_rows)
