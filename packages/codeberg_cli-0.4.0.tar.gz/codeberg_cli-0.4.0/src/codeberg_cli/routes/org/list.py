import rich

from codeberg_cli.helpers import print_table, require_client
from xclif import command


@command("list", "ls")
def _() -> None:
    """List organizations for the authenticated user."""
    client = require_client()

    orgs = client.get("/user/orgs")

    if not orgs:
        rich.print("[dim]You are not a member of any organizations.[/dim]")
        return

    rows = []
    json_rows = []
    for org in orgs:
        rows.append((org["username"], org.get("full_name", ""), str(org.get("repo_count", "?"))))
        json_rows.append({
            "username": org["username"],
            "full_name": org.get("full_name", ""),
            "repo_count": org.get("repo_count", 0),
        })

    print_table(["Org", "Full Name", "Repos"], rows, json_data=json_rows)
