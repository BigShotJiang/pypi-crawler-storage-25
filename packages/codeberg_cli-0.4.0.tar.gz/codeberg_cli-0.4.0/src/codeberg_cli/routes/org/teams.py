from typing import Annotated

import rich

from codeberg_cli.helpers import print_table, require_client
from xclif import Arg, command


@command("teams")
def _(
    org: Annotated[str, Arg(description="Organization name")],
) -> None:
    """List teams in an organization."""
    client = require_client()

    teams = client.get(f"/orgs/{org}/teams")

    if not teams:
        rich.print(f"[dim]No teams found in {org}.[/dim]")
        return

    rows = []
    json_rows = []
    for team in teams:
        rows.append((
            str(team["id"]),
            team["name"],
            team.get("permission", "?"),
            str(team.get("member_count", 0)),
        ))
        json_rows.append({
            "id": team["id"],
            "name": team["name"],
            "permission": team.get("permission", ""),
            "member_count": team.get("member_count", 0),
        })

    print_table(["ID", "Name", "Permission", "Members"], rows, json_data=json_rows)
