from xclif import command


@command("org")
def _() -> None:
    """Manage organizations — view orgs, list members and teams."""
