from typing import Annotated

import rich

from codeberg_cli.helpers import is_json_mode, output, require_client
from xclif import Arg, command


@command("view")
def _(
    org: Annotated[str, Arg(description="Organization name")],
) -> None:
    """View an organization's profile."""
    client = require_client()

    data = client.get(f"/orgs/{org}")

    if is_json_mode():
        output(data)
        return

    rich.print(f"[bold]{data['username']}[/bold]")
    if data.get("full_name"):
        rich.print(f"  Name:        {data['full_name']}")
    if data.get("description"):
        rich.print(f"  Description: {data['description']}")
    if data.get("website"):
        rich.print(f"  Website:     {data['website']}")
    if data.get("location"):
        rich.print(f"  Location:    {data['location']}")
    rich.print(f"  Repos:       {data.get('repo_count', '?')}")
    rich.print(f"  Members:     {data.get('member_count', '?')}")
    rich.print(f"  Visibility:  {data.get('visibility', '?')}")
