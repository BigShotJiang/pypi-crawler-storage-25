from xclif import command


@command("tag")
def _() -> None:
    """Manage repository tags — create, list, and delete."""
