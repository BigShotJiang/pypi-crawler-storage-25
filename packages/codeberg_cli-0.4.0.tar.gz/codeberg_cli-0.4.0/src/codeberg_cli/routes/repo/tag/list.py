from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("list")
def _(
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List repository tags."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    tags = client.get(f"/repos/{repo}/tags")

    if not tags:
        rich.print(f"[dim]No tags in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for tag in tags:
        commit_sha = (tag.get("commit") or {}).get("sha", "")[:8] if tag.get("commit") else ""
        rows.append((tag["name"], commit_sha))
        json_rows.append({"name": tag["name"], "commit_sha": commit_sha})
    print_table(["Tag", "Commit"], rows, json_data=json_rows)
