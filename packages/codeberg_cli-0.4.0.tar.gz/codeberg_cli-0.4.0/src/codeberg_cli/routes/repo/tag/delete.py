from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("delete")
def _(
    tag: Annotated[str, Arg(description="Tag name")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Delete a tag."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.delete(f"/repos/{repo}/tags/{tag}")
    rich.print(f"[bold green]Deleted[/bold green] tag {tag} from {repo}.")
