from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("create")
def _(
    tag_name: Annotated[str, Arg(description="Tag name")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
    message: Annotated[str, Option(description="Tag message")] = "",
    target: Annotated[str, Option(description="Target commit SHA or branch")] = "",
) -> None:
    """Create a tag (annotated or lightweight)."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    body = {"tag_name": tag_name}
    if message:
        body["message"] = message
    if target:
        body["target"] = target

    client.post(f"/repos/{repo}/tags", data=body, action=f"Creating tag {tag_name}")
    rich.print(f"[bold green]Created[/bold green] tag {tag_name} in {repo}.")
