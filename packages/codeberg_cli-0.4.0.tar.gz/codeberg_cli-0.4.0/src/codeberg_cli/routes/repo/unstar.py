from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Option, command


@command("unstar")
def _(
    repo: Annotated[str, Option(description="Repository to unstar")] = "",
) -> None:
    """Unstar a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.delete(f"/user/starred/{repo}", action=f"Unstarring {repo}")
    rich.print(f"[bold green]Unstarred[/bold green] {repo}")
