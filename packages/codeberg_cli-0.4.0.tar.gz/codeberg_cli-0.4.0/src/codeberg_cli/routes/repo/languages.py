from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("languages")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
) -> None:
    """List repository languages and byte counts."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data = client.get(f"/repos/{repo}/languages")

    if not data:
        rich.print("[dim]No language data found.[/dim]")
        return

    total = sum(data.values()) if isinstance(data, dict) else 0

    json_rows = []
    for lang, bytes_count in data.items():
        json_rows.append({
            "language": lang,
            "bytes": bytes_count,
            "percentage": round(bytes_count / total * 100, 1) if total else 0,
        })

    rows = []
    for lang, bytes_count in data.items():
        pct = f"{bytes_count / total * 100:.1f}%" if total else "N/A"
        rows.append((lang, f"{bytes_count:,}", pct))

    print_table(["Language", "Bytes", "Percentage"], rows, json_data=json_rows)
