from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("commits")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    limit: Annotated[int, Option(description="Maximum number of commits")] = 30,
    sha: Annotated[str, Option(description="Branch or commit SHA to start from")] = "",
) -> None:
    """List commits in a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    params = {"limit": limit, "page": 1}
    if sha:
        params["sha"] = sha

    commits = client.get(f"/repos/{repo}/commits", params=params, action=f"Fetching commits for {repo}")

    if not commits:
        rich.print("[dim]No commits found.[/dim]")
        return

    rows = []
    json_rows = []
    for c in commits:
        sha_short = c["sha"][:7]
        author = c["commit"]["author"].get("name", "Unknown")
        message = c["commit"]["message"].split("\n")[0]
        date = c["commit"]["author"].get("date", "")
        rows.append((sha_short, author, message, date))
        json_rows.append({
            "sha": c["sha"],
            "author": author,
            "message": message,
            "date": date,
        })

    print_table(["SHA", "Author", "Message", "Date"], rows, json_data=json_rows)
