from pathlib import Path
from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Option, command


@command("archive")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    ref: Annotated[str, Option(description="Branch or tag to archive")] = "main",
    format: Annotated[str, Option(description="Archive format")] = "tar.gz",
) -> None:
    """Download a repository archive."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    owner, name = repo.split("/", 1)
    ext = format
    filename = f"{owner}-{name}-{ref}.{ext}"

    rich.print(f"[dim]Downloading archive...[/dim]")

    raw = client._client.get(f"/repos/{repo}/archive/{format}", params={"ref": ref})

    Path(filename).write_bytes(raw.content)
    rich.print(f"[bold green]Saved[/bold green] {filename}")
