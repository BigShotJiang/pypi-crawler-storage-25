from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("forks")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    limit: Annotated[int, Option(description="Maximum number of forks")] = 30,
) -> None:
    """List forks of a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    forks = client.get(f"/repos/{repo}/forks", params={"limit": limit, "page": 1}, action=f"Fetching forks for {repo}")

    if not forks:
        rich.print("[dim]No forks found.[/dim]")
        return

    rows = []
    json_rows = []
    for f in forks:
        rows.append((f["full_name"], f["owner"]["login"], f.get("description") or ""))
        json_rows.append({
            "full_name": f["full_name"],
            "owner": f["owner"]["login"],
            "description": f.get("description"),
            "stars": f.get("stars_count", 0),
        })

    print_table(["Name", "Owner", "Description"], rows, json_data=json_rows)
