from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Option, command


@command("watch")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
) -> None:
    """Watch (subscribe to) a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.put(f"/repos/{repo}/subscription", action=f"Watching {repo}")
    rich.print(f"[bold green]Now watching[/bold green] {repo}")
