from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("watchers")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    limit: Annotated[int, Option(description="Maximum number of watchers")] = 30,
) -> None:
    """List watchers (subscribers) of a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    watchers = client.get(f"/repos/{repo}/subscribers", params={"limit": limit, "page": 1}, action=f"Fetching watchers for {repo}")

    if not watchers:
        rich.print("[dim]No watchers found.[/dim]")
        return

    rows = []
    json_rows = []
    for w in watchers:
        rows.append((w["login"],))
        json_rows.append({
            "login": w["login"],
            "id": w["id"],
        })

    print_table(["User"], rows, json_data=json_rows)
