from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("stargazers")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    limit: Annotated[int, Option(description="Maximum number of stargazers")] = 30,
) -> None:
    """List stargazers of a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    stargazers = client.get(f"/repos/{repo}/stargazers", params={"limit": limit, "page": 1}, action=f"Fetching stargazers for {repo}")

    if not stargazers:
        rich.print("[dim]No stargazers found.[/dim]")
        return

    rows = []
    json_rows = []
    for s in stargazers:
        rows.append((s["login"],))
        json_rows.append({
            "login": s["login"],
            "id": s["id"],
        })

    print_table(["User"], rows, json_data=json_rows)
