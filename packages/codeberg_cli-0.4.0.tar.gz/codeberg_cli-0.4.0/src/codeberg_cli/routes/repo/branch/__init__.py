from xclif import command


@command("branch")
def _() -> None:
    """Manage branches — list, create, view, and delete."""
