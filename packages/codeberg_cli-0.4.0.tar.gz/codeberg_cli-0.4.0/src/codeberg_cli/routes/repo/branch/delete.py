from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("delete")
def _(
    branch: Annotated[str, Arg(description="Branch name")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Delete a branch."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.delete(f"/repos/{repo}/branches/{branch}")
    rich.print(f"[bold green]Deleted[/bold green] branch {branch} from {repo}.")
