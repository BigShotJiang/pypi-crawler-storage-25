from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("list")
def _(
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List branches."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    branches = client.get(f"/repos/{repo}/branches")

    if not branches:
        rich.print(f"[dim]No branches in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for b in branches:
        commit_sha = (b.get("commit") or {}).get("id", "")[:8]
        rows.append((b["name"], commit_sha))
        json_rows.append({"name": b["name"], "commit_sha": commit_sha})
    print_table(["Branch", "Commit"], rows, json_data=json_rows)
