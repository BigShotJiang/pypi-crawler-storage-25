from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("create")
def _(
    name: Annotated[str, Arg(description="Name of the branch to create")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
    ref: Annotated[str, Option(description="Source branch/tag/commit")] = "",
) -> None:
    """Create a branch."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    body = {"new_branch_name": name}
    if ref:
        body["old_ref_name"] = ref

    client.post(f"/repos/{repo}/branches", data=body, action=f"Creating branch {name}")
    rich.print(f"[bold green]Created[/bold green] branch {name} in {repo}.")
