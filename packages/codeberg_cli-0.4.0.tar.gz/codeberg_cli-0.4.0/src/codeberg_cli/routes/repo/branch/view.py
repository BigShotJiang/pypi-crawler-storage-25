from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import is_json_mode, output, require_client
from xclif import Arg, Option, command


@command("view")
def _(
    branch: Annotated[str, Arg(description="Branch name")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """View a branch."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data = client.get(f"/repos/{repo}/branches/{branch}")

    if is_json_mode():
        output(data)
        return

    rich.print(f"[bold]{data['name']}[/bold]")
    commit = data.get("commit", {})
    rich.print(f"  Commit:  {commit.get('id', '?')}")
    rich.print(f"  Message: {(commit.get('commit', {})).get('message', '')[:80]}")
    author = (commit.get("commit", {})).get("author", {})
    rich.print(f"  Author:  {author.get('name', '?')} <{author.get('email', '')}>")
