from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("fork")
def _(
    repo: Annotated[str, Option(description="Repository to fork")] = "",
) -> None:
    """Fork a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    result = client.post(f"/repos/{repo}/forks", action=f"Forking {repo}")
    fork_name = result.get("full_name", f"{result['owner']['login']}/{result['name']}")
    rich.print(f"[bold green]Forked[/bold green] {repo} -> [bold]{fork_name}[/bold]")


