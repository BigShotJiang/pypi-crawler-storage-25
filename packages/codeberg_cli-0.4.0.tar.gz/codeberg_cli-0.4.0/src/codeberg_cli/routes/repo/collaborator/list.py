from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("list")
def _(
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List collaborators of a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    collaborators = client.get(f"/repos/{repo}/collaborators")

    if not collaborators:
        rich.print(f"[dim]No collaborators in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for c in collaborators:
        perms = c.get("permissions", {})
        perm = "admin" if perms.get("admin") else "write" if perms.get("push") else "read"
        rows.append((c["login"], perm))
        json_rows.append({"login": c["login"], "permission": perm})
    print_table(["User", "Permission"], rows, json_data=json_rows)
