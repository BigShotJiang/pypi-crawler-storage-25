from xclif import command


@command("collaborator")
def _() -> None:
    """Manage collaborators — list, add, and remove."""
