from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("rm", "delete")
def _(
    username: Annotated[str, Arg(description="Username to remove")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Remove a collaborator from a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.delete(f"/repos/{repo}/collaborators/{username}")
    rich.print(f"[bold green]Removed[/bold green] {username} from {repo}.")
