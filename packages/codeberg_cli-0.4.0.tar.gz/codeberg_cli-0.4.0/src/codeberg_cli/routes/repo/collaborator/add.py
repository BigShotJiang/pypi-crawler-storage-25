from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("add")
def _(
    username: Annotated[str, Arg(description="Username to add")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
    permission: Annotated[str, Option(description="Permission (read/write/admin)")] = "",
) -> None:
    """Add a collaborator to a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    body = {}
    if permission:
        body["permission"] = permission

    client.put(f"/repos/{repo}/collaborators/{username}", data=body)
    rich.print(f"[bold green]Added[/bold green] {username} as a collaborator to {repo}.")
