from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Option, command


@command("sync")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    branch: Annotated[str, Option(description="Branch to sync")] = "",
) -> None:
    """Sync a fork with its upstream repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data = {}
    if branch:
        data["branch"] = branch

    result = client.post(f"/repos/{repo}/sync_fork", data=data, action=f"Syncing fork {repo}")
    rich.print(f"[bold green]Synced[/bold green] {repo}")
    if result:
        rich.print(f"  [dim]Status:[/dim] {result}")
