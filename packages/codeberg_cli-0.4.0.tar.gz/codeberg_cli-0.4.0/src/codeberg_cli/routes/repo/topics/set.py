from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("set")
def _(
    topics: Annotated[str, Arg(description="Comma-separated topics")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """Set repository topics (replaces all existing topics)."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    topic_list = [t.strip() for t in topics.split(",") if t.strip()]
    client.put(f"/repos/{repo}/topics", data={"topics": topic_list})
    rich.print(f"[bold green]Set[/bold green] topics for {repo}: {', '.join(topic_list)}")
