from xclif import command


@command("topics")
def _() -> None:
    """Manage repository topics — list and set."""
