from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import is_json_mode, output, require_client
from xclif import Option, command


@command("list")
def _(
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List repository topics."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data = client.get(f"/repos/{repo}/topics")
    topics = data.get("topics", []) if isinstance(data, dict) else data

    if is_json_mode():
        output(topics)
        return

    if not topics:
        rich.print(f"[dim]No topics in {repo}.[/dim]")
        return

    for topic in topics:
        rich.print(f"  - {topic}")
