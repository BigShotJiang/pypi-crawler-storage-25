from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("transfer")
def _(
    new_owner: Annotated[str, Arg(description="New owner (user or org)")],
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    team_ids: Annotated[str, Option(description="Comma-separated team IDs to transfer to")] = "",
) -> None:
    """Transfer repository ownership to another user or organization."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data = {"new_owner": new_owner}
    if team_ids:
        data["team_ids"] = [int(t.strip()) for t in team_ids.split(",") if t.strip()]

    client.post(
        f"/repos/{repo}/transfer",
        data=data,
        action=f"Transferring {repo} to {new_owner}",
    )
    rich.print(f"[bold green]Transferred[/bold green] {repo} to {new_owner}")
