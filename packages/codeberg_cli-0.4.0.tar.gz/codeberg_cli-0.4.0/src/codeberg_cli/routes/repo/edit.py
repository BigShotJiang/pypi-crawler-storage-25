from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Option, command


@command("edit")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    name: Annotated[str, Option(description="New repository name")] = "",
    description: Annotated[str, Option(description="New description")] = "",
    private: Annotated[bool, Option(description="Make repository private")] = False,
    public: Annotated[bool, Option(description="Make repository public")] = False,
    default_branch: Annotated[str, Option(description="Default branch name")] = "",
    website: Annotated[str, Option(description="Repository website")] = "",
    archived: Annotated[bool, Option(description="Archive repository")] = False,
    unarchived: Annotated[bool, Option(description="Unarchive repository")] = False,
    has_issues: Annotated[bool, Option(description="Enable issues")] = False,
    has_pull_requests: Annotated[bool, Option(description="Enable pull requests")] = False,
    template: Annotated[bool, Option(description="Make repository a template")] = False,
) -> None:
    """Edit repository properties."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    data: dict = {}
    if name:
        data["name"] = name
    if description:
        data["description"] = description
    if private:
        data["private"] = True
    if public:
        data["private"] = False
    if default_branch:
        data["default_branch"] = default_branch
    if website:
        data["website"] = website
    if archived:
        data["archived"] = True
    if unarchived:
        data["archived"] = False
    if has_issues:
        data["has_issues"] = True
    if has_pull_requests:
        data["has_pull_requests"] = True
    if template:
        data["template"] = True

    if not data:
        rich.print("[yellow]No changes specified.[/yellow]")
        return

    client.patch(f"/repos/{repo}", data=data, action=f"Editing {repo}")
    rich.print(f"[bold green]Updated[/bold green] {repo}")
