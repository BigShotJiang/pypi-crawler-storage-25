from typing import Annotated

import rich

from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("delete", "rm")
def _(
    repo: Annotated[str, Arg(description="Repository to delete")],
    yes: Annotated[bool, Option(description="Skip confirmation")] = False,
) -> None:
    """Delete a repository."""
    client = require_client()

    if not yes:
        rich.print(f"[bold red]Warning:[/bold red] This will permanently delete [bold]{repo}[/bold]")
        confirm = input("Type the repo name to confirm: ").strip()
        if confirm != repo:
            rich.print("[dim]Aborted.[/dim]")
            return

    client.delete(f"/repos/{repo}")
    rich.print(f"[bold green]Deleted[/bold green] {repo}")


