import subprocess
from typing import Annotated

import rich

from codeberg_cli.helpers import get_web_base_url
from xclif import Arg, command


@command("clone")
def _(
    repo: Annotated[str, Arg(description="Repository in owner/repo format")],
) -> None:
    """Clone a repository."""
    url = f"{get_web_base_url()}/{repo}.git"
    rich.print(f"Cloning [cyan]{repo}[/cyan]...")
    result = subprocess.run(["git", "clone", url])
    if result.returncode != 0:
        rich.print(f"[bold red]Error:[/bold red] git clone failed")
        return 1


