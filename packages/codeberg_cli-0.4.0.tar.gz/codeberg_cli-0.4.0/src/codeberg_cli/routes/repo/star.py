from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Option, command


@command("star")
def _(
    repo: Annotated[str, Option(description="Repository to star")] = "",
) -> None:
    """Star a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.put(f"/user/starred/{repo}", action=f"Starring {repo}")
    rich.print(f"[bold green]Starred[/bold green] {repo}")
