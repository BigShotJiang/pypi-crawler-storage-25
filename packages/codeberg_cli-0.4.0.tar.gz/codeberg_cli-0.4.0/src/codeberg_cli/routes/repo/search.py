from typing import Annotated

import rich

from codeberg_cli.helpers import print_table, require_client
from xclif import Arg, Option, command


@command("search")
def _(
    query: Annotated[str, Arg(description="Search keyword")],
    topic: Annotated[bool, Option(description="Limit to repos with keyword as topic")] = False,
    include_desc: Annotated[bool, Option(description="Include search in description")] = False,
    private: Annotated[bool, Option(description="Include private repos")] = False,
    archived: Annotated[bool, Option(description="Show archived repos only")] = False,
    mode: Annotated[str, Option(description="Type: fork, source, mirror")] = "",
    sort: Annotated[str, Option(description="Sort by: alpha, created, updated, stars, forks")] = "alpha",
    order: Annotated[str, Option(description="Order: asc or desc")] = "asc",
    limit: Annotated[int, Option(description="Max results")] = 30,
) -> None:
    """Search for repositories."""
    client = require_client()

    params: dict = {"q": query, "limit": limit, "page": 1, "sort": sort, "order": order}
    if topic:
        params["topic"] = True
    if include_desc:
        params["includeDesc"] = True
    if private:
        params["private"] = True
    if archived:
        params["archived"] = True
    if mode:
        params["mode"] = mode

    data = client.get("/repos/search", params=params)
    repos = data.get("data", []) if isinstance(data, dict) else data

    if not repos:
        rich.print(f"[dim]No repositories found matching '{query}'.[/dim]")
        return

    rows = []
    json_rows = []
    for r in repos:
        visibility = "public" if not r.get("private") else "private"
        rows.append((r["full_name"], r.get("language") or "", str(r.get("stars_count", 0)), visibility))
        json_rows.append({
            "full_name": r["full_name"],
            "language": r.get("language"),
            "stars": r.get("stars_count", 0),
            "description": r.get("description"),
            "private": r.get("private", False),
            "archived": r.get("archived", False),
            "fork": r.get("fork", False),
        })

    print_table(["Name", "Language", "Stars", "Visibility"], rows, json_data=json_rows)
