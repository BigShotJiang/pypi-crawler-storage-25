from xclif import command


@command("repo")
def _() -> None:
    """Manage repositories — create, list, star, and more."""
