from pathlib import Path
from typing import Annotated

import rich
from rich.prompt import Confirm, Prompt

from codeberg_cli.git import get_repo_remote
from codeberg_cli.helpers import get_web_base_url, require_client
from xclif import Option, command


@command("create")
def _(
    name: Annotated[str, Option(description="Repository name")] = "",
    org: Annotated[str, Option(description="Organization to create repo under")] = "",
    description: Annotated[str, Option(description="Repository description")] = "",
    private: Annotated[bool, Option(description="Make repository private")] = False,
    remote: Annotated[bool, Option(description="Add git remote and push")] = False,
) -> None:
    """Create a repository."""
    client = require_client()

    if not name:
        name = Prompt.ask("Repository name", default=Path.cwd().name)
        if not description:
            description = Prompt.ask("Description", default="")
        private = not Confirm.ask("Public repository?", default=True)
        is_git = Path.cwd().joinpath(".git").exists()
        if is_git and not get_repo_remote(Path.cwd()):
            remote = Confirm.ask("Add remote and push to Codeberg?", default=True)

    data = {
        "name": name,
        "description": description,
        "private": private,
        "auto_init": True,
    }

    web = get_web_base_url()
    if org:
        result = client.post(f"/orgs/{org}/repos", data=data, action=f"Creating repository in {org}")
        owner = org
        repo_url = f"{web}/{org}/{name}"
    else:
        result = client.post("/user/repos", data=data, action="Creating repository")
        owner = result["owner"]["login"]
        repo_url = f"{web}/{owner}/{name}"

    rich.print(f"[bold green]Created repository[/bold green] {repo_url}")

    if remote:
        import subprocess

        cwd = Path.cwd()
        if not (cwd / ".git").exists():
            rich.print("[yellow]Not a git repository, skipping remote setup[/yellow]")
            return

        existing = get_repo_remote(cwd)
        if existing:
            rich.print(f"[yellow]Remote 'origin' already exists ({existing}), skipping[/yellow]")
            return

        try:
            subprocess.run(
                ["git", "remote", "add", "origin", f"{web}/{owner}/{name}.git"],
                capture_output=True, text=True, check=True, cwd=cwd,
            )
            rich.print("[dim]Added remote 'origin'[/dim]")
            subprocess.run(
                ["git", "push", "-u", "origin", "HEAD"],
                capture_output=True, text=True, cwd=cwd,
            )
            rich.print("[dim]Pushed current branch[/dim]")
        except subprocess.CalledProcessError as e:
            rich.print(f"[red]Failed to set up remote: {e.stderr.strip()}[/red]")


