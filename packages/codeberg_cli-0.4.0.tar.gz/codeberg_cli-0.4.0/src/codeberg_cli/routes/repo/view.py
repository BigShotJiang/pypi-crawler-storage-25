import webbrowser
from typing import Annotated

import rich
from rich.markup import escape

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import get_web_base_url, is_json_mode, output, require_client
from xclif import Option, command


@command("view")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    web: Annotated[bool, Option(description="Open in browser", name="web")] = False,
) -> None:
    """View a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    if web:
        webbrowser.open(f"{get_web_base_url()}/{repo}")
        return

    data = client.get(f"/repos/{repo}")

    if is_json_mode():
        output(data)
        return

    rich.print(f"[bold]{data['full_name']}[/bold]")
    if data.get("description"):
        rich.print(escape(data["description"]))
    rich.print(f"  [dim]Stars:[/dim] {data.get('stars_count', 0)}  [dim]Forks:[/dim] {data.get('forks_count', 0)}")
    rich.print(f"  [dim]Language:[/dim] {data.get('language', 'N/A')}")
    rich.print(f"  [dim]Visibility:[/dim] {'Private' if data.get('private') else 'Public'}")
    web_url = f"{get_web_base_url()}/{repo}"
    rich.print(f"  [dim]URL:[/dim] {web_url}")


