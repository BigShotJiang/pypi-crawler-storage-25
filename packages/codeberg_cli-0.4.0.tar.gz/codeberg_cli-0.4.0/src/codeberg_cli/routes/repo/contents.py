from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import is_json_mode, output, print_table, require_client
from xclif import Arg, Option, command


@command("contents")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
    ref: Annotated[str, Option(description="Branch or ref")] = "",
    filepath: Annotated[str, Option(description="Path to file or directory")] = "",
) -> None:
    """Get file contents or directory listing."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    params = {}
    if ref:
        params["ref"] = ref

    data = client.get(f"/repos/{repo}/contents/{filepath}", params=params, action=f"Fetching contents of {filepath}")

    if is_json_mode():
        output(data)
        return

    if isinstance(data, list):
        # Directory listing
        if not data:
            rich.print("[dim]Empty directory.[/dim]")
            return
        rows = []
        json_rows = []
        for entry in data:
            rows.append((entry["type"], entry["name"], entry.get("size", "")))
            json_rows.append({
                "type": entry["type"],
                "name": entry["name"],
                "size": entry.get("size"),
            })
        print_table(["Type", "Name", "Size"], rows, json_data=json_rows)
    else:
        # File content
        import base64
        content = base64.b64decode(data.get("content", "")).decode("utf-8", errors="replace")
        rich.print(content, end="")
