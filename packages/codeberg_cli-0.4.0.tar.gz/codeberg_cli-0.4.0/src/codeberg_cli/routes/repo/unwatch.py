from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Option, command


@command("unwatch")
def _(
    repo: Annotated[str, Option(description="Repository in owner/repo format")] = "",
) -> None:
    """Unwatch (unsubscribe from) a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.delete(f"/repos/{repo}/subscription", action=f"Unwatching {repo}")
    rich.print(f"[bold green]No longer watching[/bold green] {repo}")
