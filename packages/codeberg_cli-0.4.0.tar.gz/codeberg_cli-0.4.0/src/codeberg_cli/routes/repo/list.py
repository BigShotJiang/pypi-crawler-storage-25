from typing import Annotated

import rich

from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("list", "ls")
def _(
    owner: Annotated[str, Option(description="Owner (user or org)")] = "",
    limit: Annotated[int, Option(description="Maximum number of repos")] = 30,
) -> None:
    """List repositories for a user or organization."""
    client = require_client()

    if owner:
        repos = client.get(f"/users/{owner}/repos", params={"limit": limit, "page": 1}, action=f"Fetching {owner}'s repositories")
    else:
        repos = client.get("/user/repos", params={"limit": limit, "page": 1}, action="Fetching your repositories")

    if not repos:
        rich.print("[dim]No repositories found.[/dim]")
        return

    rows = []
    json_rows = []
    for r in repos:
        visibility = "public" if not r.get("private") else "private"
        rows.append((r["full_name"], visibility, r.get("description") or ""))
        json_rows.append({
            "full_name": r["full_name"],
            "visibility": visibility,
            "description": r.get("description"),
            "stars": r.get("stars_count", 0),
            "forks": r.get("forks_count", 0),
            "language": r.get("language"),
        })

    print_table(["Name", "Visibility", "Description"], rows, json_data=json_rows)


