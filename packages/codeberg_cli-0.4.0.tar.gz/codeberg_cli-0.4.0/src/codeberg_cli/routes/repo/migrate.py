from typing import Annotated

import rich

from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("migrate")
def _(
    clone_addr: Annotated[str, Arg(description="URL to clone from")],
    repo_name: Annotated[str, Arg(description="Repository name")],
    owner: Annotated[str, Arg(description="Owner (user or org)")],
    description: Annotated[str, Option(description="Repository description")] = "",
    private: Annotated[bool, Option(description="Make repository private")] = False,
    mirror: Annotated[bool, Option(description="Migrate as a mirror")] = False,
    service: Annotated[str, Option(description="Git service type")] = "git",
) -> None:
    """Migrate a repository from another source."""
    client = require_client()

    body = {
        "clone_addr": clone_addr,
        "repo_name": repo_name,
        "repo_owner": owner,
        "description": description,
        "private": private,
        "mirror": mirror,
        "service": service,
    }

    result = client.post("/repos/migrate", data=body, action=f"Migrating {clone_addr}")
    rich.print(f"[bold green]Migrated[/bold green] {clone_addr} -> {result.get('full_name', repo_name)}")
