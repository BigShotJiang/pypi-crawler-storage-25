from typing import Annotated

import rich
from rich.markup import escape

from codeberg_cli.helpers import is_json_mode, output, require_client
from xclif import Option, command


@command("user")
def _(
    username: Annotated[str, Option(description="Username (defaults to authenticated user)", name="username")] = "",
) -> None:
    """View a user's profile (defaults to the authenticated user)."""
    client = require_client()

    user = client.get(f"/users/{username}" if username else "/user")

    if is_json_mode():
        output(user)
        return

    rich.print(f"[bold]{user['login']}[/bold]")
    if user.get("full_name"):
        rich.print(escape(user["full_name"]))
    if user.get("email"):
        rich.print(f"  [dim]Email:[/dim] {user['email']}")
    rich.print(f"  [dim]Repos:[/dim] {user.get('num_repos', 0)}  [dim]Stars:[/dim] {user.get('num_stars', 0)}  [dim]Followers:[/dim] {user.get('followers_count', 0)}  [dim]Following:[/dim] {user.get('following_count', 0)}")
    if user.get("description"):
        rich.print(f"  [dim]Bio:[/dim] {escape(user['description'])}")
