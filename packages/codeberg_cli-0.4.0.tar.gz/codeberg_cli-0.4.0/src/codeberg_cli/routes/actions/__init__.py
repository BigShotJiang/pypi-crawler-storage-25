from xclif import command


@command("actions")
def _() -> None:
    """Manage Forgejo Actions — view runs, list workflows, and dispatch workflows."""
