from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("workflows")
def _(
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """List workflows for a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    workflows = client.get(f"/repos/{repo}/actions/workflows")

    if not workflows:
        rich.print(f"[dim]No workflows in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for wf in workflows:
        state = wf.get("state", "?")
        rows.append((str(wf["id"]), wf["name"], wf.get("filename", ""), state))
        json_rows.append({
            "id": wf["id"],
            "name": wf["name"],
            "filename": wf.get("filename", ""),
            "state": state,
        })

    print_table(
        ["ID", "Name", "Filename", "State"],
        rows,
        json_data=json_rows,
    )
