from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import require_client
from xclif import Arg, Option, command


@command("dispatch")
def _(
    workflow: Annotated[str, Arg(description="Workflow filename (e.g. ci.yml)")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
    ref: Annotated[str, Option(description="Branch or tag to dispatch on", name="ref")] = "main",
) -> None:
    """Dispatch a workflow (trigger a workflow_dispatch event)."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    client.post(
        f"/repos/{repo}/actions/workflows/{workflow}/dispatches",
        data={"ref": ref},
        action="Dispatching workflow",
    )
    rich.print(f"[green]Dispatched {workflow} on {ref} in {repo}.[/green]")
