from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import is_json_mode, output, require_client
from xclif import Arg, Option, command


@command("run")
def _(
    run_id: Annotated[int, Arg(description="Run ID")],
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
) -> None:
    """View details of a specific action run."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    run = client.get(f"/repos/{repo}/actions/runs/{run_id}")

    if is_json_mode():
        output(run)
        return

    rich.print(f"[bold]Run #{run['id']}:[/bold] {run['display_title']}")
    rich.print(f"  Status:      {run.get('status', '?')}")
    rich.print(f"  Conclusion:  {run.get('conclusion', 'N/A')}")
    rich.print(f"  Event:       {run.get('event', '?')}")
    rich.print(f"  Branch:      {run.get('head_branch', '?')}")
    rich.print(f"  Commit:      {run.get('head_sha', '?')[:12]}")
    rich.print(f"  Created:     {run.get('created_at', '?')}")
    rich.print(f"  Updated:     {run.get('updated_at', '?')}")
    if run.get("url"):
        rich.print(f"  URL:         {run['url']}")
