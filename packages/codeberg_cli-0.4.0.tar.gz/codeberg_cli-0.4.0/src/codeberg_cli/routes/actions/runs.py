from typing import Annotated

import rich

from codeberg_cli.git import infer_repo
from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("runs")
def _(
    repo: Annotated[str, Option(description="Repository (owner/repo)", name="repo")] = "",
    limit: Annotated[int, Option(description="Maximum runs to show", name="limit")] = 20,
) -> None:
    """List action runs for a repository."""
    client = require_client()

    if not repo:
        inferred = infer_repo()
        if not inferred:
            rich.print("[bold red]Error:[/bold red] No repo specified and not in a git directory")
            return 1
        repo = inferred

    runs = client.get(f"/repos/{repo}/actions/runs", params={"limit": limit, "page": 1})

    if not runs:
        rich.print(f"[dim]No action runs in {repo}.[/dim]")
        return

    rows = []
    json_rows = []
    for run in runs:
        status = run.get("status", "?")
        conclusion = run.get("conclusion", "")
        label = f"{status}" if not conclusion else f"{conclusion}"
        rows.append((str(run["id"]), run["display_title"][:72], label, run["event"]))
        json_rows.append({
            "id": run["id"],
            "title": run["display_title"],
            "status": status,
            "conclusion": conclusion,
            "event": run["event"],
            "created_at": run.get("created_at", ""),
            "head_branch": run.get("head_branch", ""),
        })

    print_table(
        ["ID", "Title", "Status", "Event"],
        rows,
        json_data=json_rows,
    )
