from typing import Annotated

import rich

from codeberg_cli.helpers import print_table, require_client
from xclif import Option, command


@command("notifications")
def _(
    limit: Annotated[int, Option(description="Maximum notifications to show", name="limit")] = 30,
    all: Annotated[bool, Option(description="Show all notifications, not just unread", name="all")] = False,
) -> None:
    """List notifications."""
    client = require_client()

    params: dict = {"limit": limit, "page": 1}
    if not all:
        params["status-types"] = "unread"

    notifications = client.get("/notifications", params=params)

    if not notifications:
        rich.print("[dim]No notifications.[/dim]")
        return

    rows = []
    json_rows = []
    for n in notifications:
        subject = n.get("subject", {})
        repo = n.get("repository", {})
        rows.append((str(n["id"]), subject.get("type", ""), subject.get("title", ""), repo.get("full_name", "")))
        json_rows.append({
            "id": n["id"],
            "type": subject.get("type", ""),
            "title": subject.get("title", ""),
            "repo": repo.get("full_name", ""),
            "unread": n.get("unread", False),
            "updated_at": n.get("updated_at", ""),
        })

    print_table(["ID", "Type", "Subject", "Repo"], rows, json_data=json_rows)
