from pathlib import Path

import tomlkit
from platformdirs import user_config_path


def get_config_path() -> Path:
    """Return the config directory for codeberg-cli."""
    return user_config_path("codeberg-cli", ensure_exists=False)


def config_file_path() -> Path:
    """Return the path to the config file."""
    return get_config_path() / "config.toml"


def load_config() -> dict:
    """Load config from ~/.config/codeberg-cli/config.toml. Returns {} if missing."""
    path = config_file_path()
    if not path.exists():
        return {}
    return dict(tomlkit.parse(path.read_text()))


def save_config(data: dict) -> None:
    """Save config to ~/.config/codeberg-cli/config.toml."""
    path = config_file_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(tomlkit.dumps(data))
