from xclif import Command


def test_release_commands_are_commands():
    from codeberg_cli.routes.release.create import _ as cmd
    from codeberg_cli.routes.release.list import _ as list_cmd
    from codeberg_cli.routes.release.view import _ as view_cmd
    from codeberg_cli.routes.release.upload import _ as upload_cmd

    for cmd in [cmd, list_cmd, view_cmd, upload_cmd]:
        assert isinstance(cmd, Command)


def test_release_create_command_name():
    from codeberg_cli.routes.release.create import _ as cmd
    assert cmd.name == "create"


def test_release_list_has_alias():
    from codeberg_cli.routes.release.list import _ as cmd
    assert "ls" in cmd.aliases
