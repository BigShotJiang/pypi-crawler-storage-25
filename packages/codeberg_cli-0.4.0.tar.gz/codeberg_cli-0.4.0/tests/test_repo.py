from xclif import Command


def test_repo_commands_are_commands():
    from codeberg_cli.routes.repo.create import _ as create_cmd
    from codeberg_cli.routes.repo.clone import _ as clone_cmd
    from codeberg_cli.routes.repo.list import _ as list_cmd
    from codeberg_cli.routes.repo.view import _ as view_cmd
    from codeberg_cli.routes.repo.fork import _ as fork_cmd
    from codeberg_cli.routes.repo.delete import _ as delete_cmd
    from codeberg_cli.routes.repo.star import _ as star_cmd
    from codeberg_cli.routes.repo.unstar import _ as unstar_cmd

    for cmd in [create_cmd, clone_cmd, list_cmd, view_cmd, fork_cmd, delete_cmd, star_cmd, unstar_cmd]:
        assert isinstance(cmd, Command)


def test_repo_create_command_name():
    from codeberg_cli.routes.repo.create import _ as cmd
    assert cmd.name == "create"


def test_repo_clone_command_name():
    from codeberg_cli.routes.repo.clone import _ as cmd
    assert cmd.name == "clone"


def test_repo_list_has_alias():
    from codeberg_cli.routes.repo.list import _ as cmd
    assert "ls" in cmd.aliases
