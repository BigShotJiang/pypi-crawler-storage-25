from pathlib import Path

import pytest

from codeberg_cli.git import parse_repo_from_remote, get_default_branch


def test_parse_https_remote():
    url = "https://codeberg.org/ThatXliner/codeberg-cli.git"
    assert parse_repo_from_remote(url) == "ThatXliner/codeberg-cli"


def test_parse_ssh_remote():
    url = "git@codeberg.org:ThatXliner/codeberg-cli.git"
    assert parse_repo_from_remote(url) == "ThatXliner/codeberg-cli"


def test_parse_no_suffix():
    url = "https://codeberg.org/user/repo"
    assert parse_repo_from_remote(url) == "user/repo"


def test_parse_trailing_slash():
    url = "https://codeberg.org/user/repo/"
    assert parse_repo_from_remote(url) == "user/repo"


def test_get_default_branch(tmp_path):
    """get_default_branch returns 'main' by default."""
    repo = tmp_path / "myrepo"
    repo.mkdir()
    (repo / ".git").mkdir()
    result = get_default_branch(repo)
    assert result == "main"
