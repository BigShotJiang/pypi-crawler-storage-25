import os
import tempfile
from pathlib import Path

import pytest
import tomlkit

from codeberg_cli.config import load_config, save_config, get_config_path


def test_load_config_not_found(monkeypatch, tmp_path):
    """Loading config from non-existent dir returns default."""
    monkeypatch.setattr("codeberg_cli.config.get_config_path", lambda: tmp_path / "codeberg-cli")
    config = load_config()
    assert config == {}


def test_save_and_load_config(monkeypatch, tmp_path):
    monkeypatch.setattr("codeberg_cli.config.get_config_path", lambda: tmp_path / "codeberg-cli")
    save_config({"token": "cb_test_token"})
    loaded = load_config()
    assert loaded == {"token": "cb_test_token"}


def test_get_config_path():
    """get_config_path returns the config directory path without side effects."""
    path = get_config_path()
    assert str(path).endswith("/codeberg-cli")
