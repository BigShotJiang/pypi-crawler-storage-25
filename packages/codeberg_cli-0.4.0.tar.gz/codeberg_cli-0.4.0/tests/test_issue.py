from xclif import Command


def test_issue_commands_are_commands():
    from codeberg_cli.routes.issue.create import _ as cmd
    from codeberg_cli.routes.issue.list import _ as list_cmd
    from codeberg_cli.routes.issue.view import _ as view_cmd
    from codeberg_cli.routes.issue.close import _ as close_cmd
    from codeberg_cli.routes.issue.reopen import _ as reopen_cmd
    from codeberg_cli.routes.issue.comment import _ as comment_cmd
    from codeberg_cli.routes.issue.edit import _ as edit_cmd

    for cmd in [cmd, list_cmd, view_cmd, close_cmd, reopen_cmd, comment_cmd, edit_cmd]:
        assert isinstance(cmd, Command)


def test_issue_create_command_name():
    from codeberg_cli.routes.issue.create import _ as cmd
    assert cmd.name == "create"


def test_issue_list_has_alias():
    from codeberg_cli.routes.issue.list import _ as cmd
    assert "ls" in cmd.aliases
