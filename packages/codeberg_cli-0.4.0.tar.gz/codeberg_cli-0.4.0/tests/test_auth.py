import pytest
from xclif import Command


def test_auth_commands_are_commands():
    from codeberg_cli.routes.auth.login import _ as login_cmd
    from codeberg_cli.routes.auth.logout import _ as logout_cmd
    from codeberg_cli.routes.auth.status import _ as status_cmd
    from codeberg_cli.routes.auth.whoami import _ as whoami_cmd

    for cmd in [login_cmd, logout_cmd, status_cmd, whoami_cmd]:
        assert isinstance(cmd, Command)


def test_login_saves_token(tmp_path, monkeypatch, capsys, httpx_mock):
    httpx_mock.add_response(url="https://codeberg.org/api/v1/user", json={"login": "testuser"})
    monkeypatch.setattr("codeberg_cli.config.get_config_path", lambda: tmp_path / "codeberg-cli")

    from codeberg_cli.routes.auth.login import _ as cmd
    cmd.execute(["login", "--token", "cb_test_token_123"])

    from codeberg_cli.config import load_config
    assert load_config() == {"token": "cb_test_token_123"}
    captured = capsys.readouterr()
    assert "Logged in as" in captured.out
