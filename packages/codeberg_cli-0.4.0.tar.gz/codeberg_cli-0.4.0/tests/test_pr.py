from xclif import Command


def test_pr_commands_are_commands():
    from codeberg_cli.routes.pr.create import _ as cmd
    from codeberg_cli.routes.pr.list import _ as list_cmd
    from codeberg_cli.routes.pr.view import _ as view_cmd
    from codeberg_cli.routes.pr.merge import _ as merge_cmd
    from codeberg_cli.routes.pr.checkout import _ as checkout_cmd
    from codeberg_cli.routes.pr.close import _ as close_cmd
    from codeberg_cli.routes.pr.comment import _ as comment_cmd
    from codeberg_cli.routes.pr.edit import _ as edit_cmd

    for cmd in [cmd, list_cmd, view_cmd, merge_cmd, checkout_cmd, close_cmd, comment_cmd, edit_cmd]:
        assert isinstance(cmd, Command)


def test_pr_checkout_has_alias():
    from codeberg_cli.routes.pr.checkout import _ as cmd
    assert "co" in cmd.aliases


def test_pr_list_has_alias():
    from codeberg_cli.routes.pr.list import _ as cmd
    assert "ls" in cmd.aliases
