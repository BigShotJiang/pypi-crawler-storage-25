import pytest
from unittest.mock import patch
from xclif import Command


def test_api_command_exists():
    from codeberg_cli.routes.api import _ as cmd
    assert isinstance(cmd, Command)
    assert cmd.name == "api"


def test_api_execute_get(httpx_mock, capsys, tmp_path, monkeypatch):
    monkeypatch.setattr("codeberg_cli.config.get_config_path", lambda: tmp_path / "codeberg-cli")
    from codeberg_cli.config import save_config
    save_config({"token": "test_token"})

    httpx_mock.add_response(
        url="https://codeberg.org/api/v1/version",
        json={"version": "1.22.0"},
    )

    from codeberg_cli.routes.api import _ as cmd
    cmd.execute(["GET", "/version"])
    captured = capsys.readouterr()
    assert "1.22.0" in captured.out
