import pytest
from httpx import Request, Response

from codeberg_cli.client import Client, ClientError


def test_client_get(httpx_mock):
    httpx_mock.add_response(url="https://codeberg.org/api/v1/user", json={"login": "testuser"})
    client = Client(token="cb_test")
    result = client.get("/user")
    assert result == {"login": "testuser"}


def test_client_post(httpx_mock):
    httpx_mock.add_response(url="https://codeberg.org/api/v1/repos", json={"id": 1}, method="POST")
    client = Client(token="cb_test")
    result = client.post("/repos", data={"name": "my-repo"})
    assert result == {"id": 1}


def test_client_auth_header(httpx_mock):
    """Client sends Authorization header with token."""
    def check_request(request: Request):
        assert request.headers["Authorization"] == "Bearer cb_test_token"
        return Response(200, json={"login": "u"})

    httpx_mock.add_callback(check_request, url="https://codeberg.org/api/v1/user")
    client = Client(token="cb_test_token")
    client.get("/user")


def test_client_error(httpx_mock):
    httpx_mock.add_response(url="https://codeberg.org/api/v1/user", status_code=401, json={"message": "bad token"})
    client = Client(token="bad")
    with pytest.raises(ClientError) as exc:
        client.get("/user")
    assert "401" in str(exc.value)


def test_client_no_auth(httpx_mock):
    """Client without token can still be created."""
    httpx_mock.add_response(url="https://codeberg.org/api/v1/version", json={"version": "1.22"})
    client = Client()
    result = client.get("/version")
    assert result == {"version": "1.22"}


def test_client_headers(httpx_mock):
    """Client sends Accept and User-Agent headers."""
    def check_request(request: Request):
        assert request.headers["Accept"] == "application/json"
        assert request.headers["User-Agent"] == "codeberg-cli/0.1.0"
        return Response(200, json={})

    httpx_mock.add_callback(check_request, url="https://codeberg.org/api/v1/user")
    client = Client(token="t")
    client.get("/user")
