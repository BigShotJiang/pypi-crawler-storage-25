# cb — A Codeberg CLI

[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/codeberg-cli)](https://pypi.org/project/codeberg-cli)
[![PyPI](https://img.shields.io/pypi/v/codeberg-cli)](https://pypi.org/project/codeberg-cli)
[![PyPI - License](https://img.shields.io/pypi/l/codeberg-cli)](#license)

`cb` is a CLI for [Codeberg](https://codeberg.org) (a [Forgejo](https://forgejo.org) instance) — think `gh` for Codeberg. It also works with any Forgejo instance. Built with [Xclif](https://xclif.readthedocs.io).

```text
# One-time setup
cb auth login

# Work with repos, issues, PRs, releases
cb repo list
cb issue create --title "Fix the thing"
cb pr create --base main --head fix
cb release create v0.2.0
```

## Install

```bash
pip install codeberg-cli  # or: uv tool install codeberg-cli
```

Or from source:

```bash
git clone https://codeberg.org/ThatXliner/codeberg-cli.git
cd cb
uv tool install .
```

## Quickstart

```bash
# Authenticate (tokens at https://codeberg.org/user/settings/applications)
cb auth login

# Who am I?
cb auth whoami

# List your repos
cb repo list

# Clone one
cb repo clone ThatXliner/cb

# Open an issue
cb issue create --title "suggestion" --body "what about..."

# See everything you can do
cb --help
```

## Config

Token stored in `$XDG_CONFIG_HOME/codeberg-cli/config.toml` (managed by `cb auth login` / `cb auth logout`).

View or change config:

```bash
cb config path  # Show config file location
cb config get   # Print all config values
cb config set base_url "https://codeberg.org/api/v1"     # Codeberg (default)
cb config set base_url "https://git.example.com/api/v1"  # Self-hosted Forgejo
```

## Comparison

Here's how `cb` stacks up against other Forgejo CLI tools. *Last updated: May 2026.*

| | **cb** (this) | **fj** (forgejo-cli) | **berg** (codeberg-cli) | **tea** (gitea/tea) | **gcli** |
|---|---|---|---|---|---|
| Language | Python | Rust | Rust | Go | C |
| Version | v0.2.0 | v0.5.0 | v0.5.1 | v0.13.0 | v2.11.0 |
| Install | `pip install codeberg-cli` | prebuilt binaries/Cargo | `cargo install codeberg-cli` | `brew install tea` | `brew install gcli` |
| Multi-instance | `cb config set base_url` | `-H <instance>` | `BERG_BASE_URL` | `tea login add` | `-t forgejo` |

### Issues
| | **cb** | **fj** | **berg** | **tea** | **gcli** |
|---|---|---|---|---|---|
| Create | ✅ | ✅ | ✅ | ✅ | ✅ |
| List | ✅ | ✅ | ✅ | ✅ | ✅ |
| View | ✅ | ✅ | ✅ | ✅ | ✅ |
| Close | ✅ | ✅ | ✅ | ✅ | — |
| Reopen | ✅ | — | ✅ | ✅ | — |
| Comment | ✅ | ✅ | ✅ | ✅ | ✅ |
| Edit | ✅ | — | ✅ | ✅ | — |
| Delete | ✅ | — | — | — | — |
| Pin/Unpin | ✅ | — | — | ✅ | — |
| Search | ✅ | ✅ | — | ✅ | — |
| Attachments | — | — | — | ✅ | — |
| Labels (manage on issue) | ✅ | — | — | ✅ | — |
| Reactions | — | — | — | — | — |
| Subscriptions | ✅ | — | — | ✅ | — |
| Tracked times | ✅ | — | — | — | ✅ |
| Dependencies | — | — | — | — | — |
| Deadline | — | — | — | ✅ | — |
| Templates | — | ✅ | — | — | — |

### Pull Requests
| | **cb** | **fj** | **berg** | **tea** | **gcli** |
|---|---|---|---|---|---|
| Create | ✅ | ✅ | ✅ | ✅ | ✅ |
| List | ✅ | ✅ | ✅ | ✅ | ✅ |
| View | ✅ | ✅ | ✅ | ✅ | ✅ |
| Merge | ✅ | ✅ | ✅ | ✅ | ✅ |
| Close | ✅ | — | ✅ | ✅ | — |
| Reopen | ✅ | — | ✅ | ✅ | — |
| Comment | ✅ | ✅ | ✅ | ✅ | ✅ |
| Edit | ✅ | — | ✅ | ✅ | — |
| Checkout | ✅ | — | ✅ | ✅ | ✅ |
| Commits | ✅ | — | — | ✅ | — |
| Files/changed | ✅ | — | — | ✅ | — |
| Reviews | — | ✅ | — | ✅ | ✅ |
| Diff/Patch | ✅ | — | — | ✅ | — |
| Update branch | ✅ | — | — | ✅ | — |
| AGit (no-fork) | — | ✅ | — | — | — |
| CI status | — | ✅ | — | — | — |
| Templates | — | ✅ | — | — | — |
| Auto-merge | — | — | — | ✅ | — |

### Releases
| | **cb** | **fj** | **berg** | **tea** | **gcli** |
|---|---|---|---|---|---|
| Create | ✅ | ✅ | ✅ | ✅ | ✅ |
| List | ✅ | ✅ | ✅ | ✅ | ✅ |
| View | ✅ | ✅ | ✅ | ✅ | ✅ |
| Upload assets | ✅ | — | ✅ | — | ✅ |
| Delete | ✅ | — | — | ✅ | ✅ |
| Edit | ✅ | — | — | ✅ | — |
| Latest | ✅ | — | — | ✅ | — |
| By tag | ✅ | — | — | ✅ | — |

### Repositories
| | **cb** | **fj** | **berg** | **tea** | **gcli** |
|---|---|---|---|---|---|
| Create | ✅ | ✅ | ✅ | ✅ | ✅ |
| List | ✅ | ✅ | ✅ | ✅ | ✅ |
| View | ✅ | ✅ | ✅ | ✅ | ✅ |
| Clone | ✅ | — | ✅ | ✅ | — |
| Fork | ✅ | ✅ | ✅ | ✅ | ✅ |
| Delete | ✅ | — | ✅ | ✅ | — |
| Star | ✅ | ✅ | ✅ | ✅ | — |
| Unstar | ✅ | — | ✅ | ✅ | — |
| Watch/Unwatch | ✅ | ✅ | — | ✅ | — |
| Edit | ✅ | ✅ | — | ✅ | — |
| Migrate/Mirror | ✅ | ✅ | — | ✅ | — |
| Branches | ✅ | — | — | ✅ | — |
| Topics | ✅ | — | — | ✅ | — |
| Languages | ✅ | — | — | — | — |
| Hooks | — | — | — | ✅ | — |
| Archive | ✅ | — | — | ✅ | — |
| Commits | ✅ | — | — | — | — |
| Contents | ✅ | — | — | ✅ | — |
| Collaborators | ✅ | — | — | ✅ | — |
| Transfer | ✅ | — | — | ✅ | — |
| Wikis | — | — | — | ✅ | — |
| Push mirrors | — | — | — | ✅ | — |
| Search | ✅ | — | — | ✅ | — |

### Labels
| | **cb** | **fj** | **berg** | **tea** | **gcli** |
|---|---|---|---|---|---|
| Create | ✅ | — | ✅ | ✅ | ✅ |
| List | ✅ | — | ✅ | ✅ | ✅ |
| Delete | ✅ | — | ✅ | ✅ | — |
| Edit | ✅ | — | — | ✅ | — |

### Milestones
| | **cb** | **fj** | **berg** | **tea** | **gcli** |
|---|---|---|---|---|---|
| Create | ✅ | — | ✅ | ✅ | — |
| List | ✅ | — | ✅ | ✅ | ✅ |
| View | ✅ | — | — | ✅ | — |
| Delete | ✅ | — | — | ✅ | — |
| Edit | ✅ | — | — | ✅ | — |

### Notifications
| | **cb** | **fj** | **berg** | **tea** | **gcli** |
|---|---|---|---|---|---|
| List | ✅ | — | ✅ | ✅ | ✅ |
| Mark read | — | — | — | ✅ | — |
| Thread details | — | — | — | ✅ | — |
| Per-repo | — | — | — | ✅ | — |

### Extra
| | **cb** | **fj** | **berg** | **tea** | **gcli** |
|---|---|---|---|---|---|
| Raw API | ✅ | — | ✅ | — | ✅ |
| User profiles | ✅ | ✅ | — | — | — |
| SSH keys | — | ✅ | — | ✅ | ✅ |
| GPG keys | — | ✅ | — | — | — |
| Org/team mgmt | ✅ | ✅ | — | ✅ | — |
| Forgejo Actions | ✅ | ✅ | — | — | — |
| Shell completions | ✅ (auto via xclif) | ✅ | ✅ | ✅ | — |
| JSON output | ✅ (via `--json`) | — | ✅ | ✅ | — |
| Non-interactive | auto (no prompts) | — | ✅ | ✅ | — |
| Config management | ✅ | — | ✅ | — | — |
| Web browser flag | on view commands | — | — | ✅ | — |

**`cb` is the most feature-complete Forgejo CLI** — by a wide margin. It dominates on repo management (branches, topics, languages, tags, commits, contents, collaborators, search, archive, transfer, watch/unwatch, sync-fork, migrate), issues (delete, pin, labels, search, subscribe, tracked times), PRs (diff, commits, files, reopen, update), releases (delete, edit, latest, by-tag), and extras (Actions, org/team management, `--json` on every command, raw API, release uploads). Built in Python with [Xclif](https://xclif.readthedocs.io) for a clean, hackable codebase. If something's missing, open an issue!

## License

MIT
