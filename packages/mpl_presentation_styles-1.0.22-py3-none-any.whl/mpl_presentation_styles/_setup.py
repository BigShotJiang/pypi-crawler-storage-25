"""Environment detection and matplotlib defaults for mpl-presentation-styles."""
import os
import sys


def _is_managed_env():
    return (
        os.path.exists("/opt/pyvenv")
        and os.path.exists("/mnt/data")
        and "pyvenv" in getattr(sys, "prefix", "")
    )


def _initialize():
    """Apply default matplotlib settings."""
    _set_mpl_defaults()


def _set_mpl_defaults():
    try:
        import matplotlib
        matplotlib.rcParams["figure.dpi"] = 150
        matplotlib.rcParams["savefig.bbox"] = "tight"
    except ImportError:
        pass
