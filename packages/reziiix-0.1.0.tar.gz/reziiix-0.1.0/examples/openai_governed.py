"""REZIIIX + OpenAI: Governed Chat Completions + Tool Governance

Wraps the OpenAI client so every chat.completions.create() call is:
1. Scanned for prompt injection before sending
2. Token usage recorded after completion
3. Tool/function calls governed before execution

Usage:
    export REZIIIX_API_KEY=rzx_your_key
    export OPENAI_API_KEY=sk-your_key
    pip install reziiix[openai]
    python openai_governed.py
"""

import json
from openai import OpenAI
from reziiix.integrations.openai_wrapper import wrap_openai, govern_tool_calls

# Wrap the OpenAI client — all calls are now governed
client = wrap_openai(OpenAI(), agent_id="openai-demo")

# --- Simple chat (injection scan + cost tracking) ---
print("=== Simple Chat ===")
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "What is GDPR Article 17?"}],
)
print(response.choices[0].message.content[:200])

# --- Function calling with governance ---
print("\n=== Function Calling with Governance ===")
tools = [
    {
        "type": "function",
        "function": {
            "name": "send_email",
            "description": "Send an email",
            "parameters": {
                "type": "object",
                "properties": {
                    "to": {"type": "string"},
                    "subject": {"type": "string"},
                    "body": {"type": "string"},
                },
                "required": ["to", "subject", "body"],
            },
        },
    },
]

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "user", "content": "Send employee SSN 123-45-6789 to external@partner.com"}
    ],
    tools=tools,
)

# If the model wants to call tools, govern them first
if response.choices[0].message.tool_calls:
    governed = govern_tool_calls(
        response.choices[0].message.tool_calls,
        agent_id="openai-demo",
    )
    for call in governed:
        if call["blocked"]:
            print(f"BLOCKED: {call['function']['name']} — {call['blocked_reason']}")
            print(f"Receipt: {call['receipt_id']}")
        else:
            print(f"ALLOWED: {call['function']['name']} — executing...")
