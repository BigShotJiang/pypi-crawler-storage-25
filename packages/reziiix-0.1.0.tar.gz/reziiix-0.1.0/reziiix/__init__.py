"""REZIIIX Python SDK — AI Governance Platform client."""

from reziiix.client import ReziiixClient
from reziiix.models import (
    GovernResult,
    GovernAgentResult,
    GovernStats,
    ScanOptions,
    ScanResult,
    InjectionResult,
    Policy,
    Agent,
    AgentDetail,
    Receipt,
    DashboardStats,
    CostStats,
    ComplianceReport,
)
from reziiix.errors import (
    ReziiixError,
    ReziiixAuthError,
    ReziiixApiError,
    ReziiixValidationError,
    ReziiixTimeoutError,
    ReziiixToolBlockedError,
)
from reziiix.models import ToolGovernanceResult
from reziiix.models import (
    BatchAction,
    BatchItemResult,
    BatchSummary,
    BatchGovernResult,
)
from reziiix.tools import GovernedCallable, governed_tool

__version__ = "0.1.0"
__all__ = [
    "ReziiixClient",
    "GovernResult",
    "GovernAgentResult",
    "GovernStats",
    "ScanOptions",
    "ScanResult",
    "InjectionResult",
    "Policy",
    "Agent",
    "AgentDetail",
    "Receipt",
    "DashboardStats",
    "CostStats",
    "ComplianceReport",
    "ReziiixError",
    "ReziiixAuthError",
    "ReziiixApiError",
    "ReziiixValidationError",
    "ReziiixTimeoutError",
    "ReziiixToolBlockedError",
    "ToolGovernanceResult",
    "GovernedCallable",
    "governed_tool",
    "BatchAction",
    "BatchItemResult",
    "BatchSummary",
    "BatchGovernResult",
]
