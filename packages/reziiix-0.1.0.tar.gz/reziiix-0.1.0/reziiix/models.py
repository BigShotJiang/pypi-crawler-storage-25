"""REZIIIX SDK — Pydantic models matching the REST API response shapes."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


# ═══════════════════════════════════════════════
# Govern (Orchestration Pipeline)
# ═══════════════════════════════════════════════


class GovernAgentResult(BaseModel):
    agent_id: str = Field(alias="agentId")
    agent_name: str = Field(alias="agentName")
    agent_key: str = Field("", alias="agentKey")
    status: str
    decision: str
    detail: str = ""
    duration_ms: int = 0
    data: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class GovernStats(BaseModel):
    passed: int = 0
    failed: int = 0
    warned: int = 0
    total: int = 0
    duration_ms: int = 0


class AnonymizationResult(BaseModel):
    applied: bool = False
    sanitized_text: str | None = Field(None, alias="sanitizedText")
    entities_found: int = Field(0, alias="entitiesFound")
    entity_types: dict[str, int] = Field(default_factory=dict, alias="entityTypes")
    reversal_map_hash: str | None = Field(None, alias="reversalMapHash")
    receipt_id: str | None = Field(None, alias="receiptId")
    session_id: str | None = Field(None, alias="sessionId")

    model_config = {"populate_by_name": True}


class GovernResultData(BaseModel):
    orchestration_id: str = Field("", alias="orchestrationId")
    outcome: str = ""
    classification: str = ""
    agents: list[GovernAgentResult] = Field(default_factory=list)
    policy: dict[str, Any] = Field(default_factory=dict)
    crypto: dict[str, Any] = Field(default_factory=dict)
    anonymization: AnonymizationResult | None = None
    stats: GovernStats = Field(default_factory=GovernStats)

    model_config = {"populate_by_name": True}


class GovernResult(BaseModel):
    ok: bool
    data: GovernResultData


# ═══════════════════════════════════════════════
# Scan
# ═══════════════════════════════════════════════


class ScanOptions(BaseModel):
    agent_id: str = Field(..., alias="agentId")
    action: str
    context: dict[str, Any] = Field(default_factory=dict)
    mode: str = "sample"
    data: str | None = None

    model_config = {"populate_by_name": True}


class SampleViolation(BaseModel):
    row: int
    type: str
    severity: str
    count: int


class ScanResultData(BaseModel):
    total_records: int = Field(alias="totalRecords")
    pii_found: int = Field(alias="piiFound")
    rows_with_pii: int = Field(alias="rowsWithPii")
    detection_rate: str = Field(alias="detectionRate")
    violations_by_type: dict[str, int] = Field(alias="violationsByType")
    classification_distribution: dict[str, int] = Field(alias="classificationDistribution")
    sample_violations: list[SampleViolation] = Field(alias="sampleViolations")
    duration_ms: int = Field(alias="durationMs")
    engines: list[str]

    model_config = {"populate_by_name": True}


class ScanResult(BaseModel):
    ok: bool
    results: ScanResultData


# ═══════════════════════════════════════════════
# Injection Detection
# ═══════════════════════════════════════════════


class InjectionFinding(BaseModel):
    layer: str
    category: str
    severity: str
    weight: float
    matched: str | None = None
    signals: list[dict[str, Any]] | None = None


class InjectionResult(BaseModel):
    ok: bool
    safe: bool
    score: float
    verdict: str
    categories: list[str]
    findings: list[InjectionFinding] = Field(default_factory=list)
    duration_ms: int = Field(0, alias="durationMs")

    model_config = {"populate_by_name": True}


# ═══════════════════════════════════════════════
# Policies
# ═══════════════════════════════════════════════


class PolicyPrincipal(BaseModel):
    roles: list[str]
    departments: list[str] | None = None


class PolicyAction(BaseModel):
    types: list[str]
    platforms: list[str]


class PolicyResource(BaseModel):
    classifications: list[str]
    types: list[str] | None = None


class PolicyCondition(BaseModel):
    field: str
    operator: str
    value: Any


class Policy(BaseModel):
    id: str
    version: str = "1.0.0"
    effect: str
    priority: int = 50
    description: str
    principal: PolicyPrincipal | None = None
    action: PolicyAction | None = None
    resource: PolicyResource | None = None
    conditions: list[PolicyCondition] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    active: bool = True
    source: str = "custom"
    tenant_id: str | None = Field(None, alias="tenantId")
    created_at: str | None = Field(None, alias="createdAt")
    updated_at: str | None = Field(None, alias="updatedAt")

    model_config = {"populate_by_name": True}


# ═══════════════════════════════════════════════
# Agents
# ═══════════════════════════════════════════════


class Agent(BaseModel):
    agent_id: str = Field(alias="agentId")
    agent_name: str = Field(alias="agentName")
    framework: str = ""
    total_actions: int = Field(0, alias="totalActions")
    blocked: int = 0
    warned: int = 0
    allowed: int = 0
    block_rate: float = Field(0, alias="blockRate")
    last_active: str = Field("", alias="lastActive")
    status: str = "active"

    model_config = {"populate_by_name": True}


class AgentAction(BaseModel):
    id: str
    action: str
    outcome: str
    classification: str = ""
    intent: str = ""
    tool: str = ""
    receipt_id: str = Field("", alias="receiptId")
    created_at: str = Field("", alias="createdAt")

    model_config = {"populate_by_name": True}


class AgentDetail(Agent):
    recent_actions: list[AgentAction] = Field(default_factory=list, alias="recentActions")

    model_config = {"populate_by_name": True}


# ═══════════════════════════════════════════════
# Receipts
# ═══════════════════════════════════════════════


class ReceiptDecision(BaseModel):
    decision: str
    reason: str = ""


class ReceiptProof(BaseModel):
    hmac: str = ""
    chain_hash: str | None = Field(None, alias="chain_hash")


class Receipt(BaseModel):
    receipt_id: str = Field(alias="receiptId")
    decision: ReceiptDecision | None = None
    proof: ReceiptProof | None = None
    action: str = ""
    outcome: str = ""
    classification: str = ""
    intent: str = ""
    agent_name: str = Field("", alias="agentName")
    created_at: str = Field("", alias="createdAt")

    model_config = {"populate_by_name": True}


class VerifyResult(BaseModel):
    receipt_id: str = Field(alias="receiptId")
    verified: bool
    has_proof: bool = Field(alias="hasProof")
    has_signature: bool = Field(alias="hasSignature")
    chain_valid: bool | None = Field(None, alias="chainValid")

    model_config = {"populate_by_name": True}


# ═══════════════════════════════════════════════
# Dashboard Stats
# ═══════════════════════════════════════════════


class DecisionsBreakdown(BaseModel):
    allowed: int = 0
    blocked: int = 0
    warned: int = 0


class TimelineEntry(BaseModel):
    hour: str
    outcome: str
    count: int


class DashboardStatsData(BaseModel):
    governance_score: int = Field(alias="governanceScore")
    active_agents: int = Field(alias="activeAgents")
    decisions_today: int = Field(alias="decisionsToday")
    decisions_breakdown: DecisionsBreakdown = Field(alias="decisionsBreakdown")
    open_anomalies: int = Field(alias="openAnomalies")
    compliance_posture: int = Field(alias="compliancePosture")
    total_decisions: int = Field(alias="totalDecisions")
    dlp_violations: int = Field(alias="dlpViolations")
    active_policies: int = Field(alias="activePolicies")
    timeline: list[TimelineEntry] = Field(default_factory=list)
    updated_at: str = Field("", alias="updatedAt")

    model_config = {"populate_by_name": True}


class DashboardStats(BaseModel):
    ok: bool
    data: DashboardStatsData


# ═══════════════════════════════════════════════
# Cost Stats
# ═══════════════════════════════════════════════


class CostSummary(BaseModel):
    total_prompt_tokens: int = Field(0, alias="totalPromptTokens")
    total_completion_tokens: int = Field(0, alias="totalCompletionTokens")
    total_tokens: int = Field(0, alias="totalTokens")
    total_cost_usd: float = Field(0, alias="totalCostUsd")
    total_calls: int = Field(0, alias="totalCalls")
    avg_latency_ms: int = Field(0, alias="avgLatencyMs")

    model_config = {"populate_by_name": True}


class CostByModel(BaseModel):
    model: str
    provider: str
    tokens: int = 0
    cost_usd: float = Field(0, alias="costUsd")
    calls: int = 0

    model_config = {"populate_by_name": True}


class CostStats(BaseModel):
    ok: bool
    period: str = "30d"
    summary: CostSummary
    by_model: list[CostByModel] = Field(default_factory=list, alias="byModel")
    by_agent: list[dict[str, Any]] = Field(default_factory=list, alias="byAgent")
    timeline: list[dict[str, Any]] = Field(default_factory=list)

    model_config = {"populate_by_name": True}


# ═══════════════════════════════════════════════
# Compliance Report
# ═══════════════════════════════════════════════


class ComplianceCategory(BaseModel):
    article: str
    name: str
    status: str
    score: int
    recommendations: list[str] = Field(default_factory=list)


class ComplianceReport(BaseModel):
    ok: bool
    overall: int = 0
    framework: str = "EU AI Act"
    categories: list[ComplianceCategory] = Field(default_factory=list)
    generated_at: str = Field("", alias="generatedAt")

    model_config = {"populate_by_name": True}


# ═══════════════════════════════════════════════
# Tool Governance (Week 12)
# ═══════════════════════════════════════════════


class ToolGovernanceResult(BaseModel):
    """Result of a tool governance check."""

    outcome: str = "ALLOWED"
    receipt_id: str | None = None
    orchestration_id: str | None = None
    classification: str = ""
    violations: list[dict[str, Any]] = Field(default_factory=list)
    policy: dict[str, Any] = Field(default_factory=dict)
    govern_result: GovernResult | None = None


# ═══════════════════════════════════════════════
# Batch Operations
# ═══════════════════════════════════════════════


class BatchAction(BaseModel):
    """Single action within a batch governance request."""

    agent_id: str = Field(alias="agentId", default="batch")
    action: str
    action_type: str | None = Field(alias="actionType", default=None)
    platform: str = "M365"
    user_role: str = Field(alias="userRole", default="Authenticated")
    recipients: list[str] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(populate_by_name=True)


class BatchItemResult(BaseModel):
    """Result of a single action within a batch."""

    index: int
    outcome: str = "ALLOWED"
    receipt_id: str | None = Field(alias="receiptId", default=None)
    classification: str | None = None
    agents: list[dict[str, str]] | None = None
    policy_hits: list[dict[str, str]] | None = Field(alias="policyHits", default=None)
    duration_ms: int = Field(alias="durationMs", default=0)
    error: str | None = None

    model_config = ConfigDict(populate_by_name=True)


class BatchSummary(BaseModel):
    """Summary statistics for a batch governance request."""

    total: int = 0
    allowed: int = 0
    blocked: int = 0
    warned: int = 0
    errors: int = 0
    duration_ms: int = Field(alias="durationMs", default=0)

    model_config = ConfigDict(populate_by_name=True)


class BatchGovernResult(BaseModel):
    """Response from the batch governance API."""

    ok: bool = True
    results: list[BatchItemResult] = Field(default_factory=list)
    summary: BatchSummary = Field(default_factory=BatchSummary)
