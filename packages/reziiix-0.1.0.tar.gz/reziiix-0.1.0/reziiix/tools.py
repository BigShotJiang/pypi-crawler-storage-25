"""REZIIIX SDK — Tool governance wrappers.

Wraps any callable, LangChain tool, CrewAI tool, or OpenAI function definition
with REZIIIX governance checks. Every tool call runs through the 10-agent pipeline
before execution and produces a cryptographic receipt.

Usage:
    from reziiix import ReziiixClient, governed_tool

    client = ReziiixClient(api_key="rzx_...")

    # Wrap a list of callables
    governed = client.wrap_tools([send_email, query_db], agent_id="my-agent")

    # Decorator
    @governed_tool(client=client, agent_id="my-agent")
    def send_email(to: str, body: str) -> str:
        ...
"""

from __future__ import annotations

import json
import logging
import os
from functools import wraps
from typing import Any, Callable, Sequence

from reziiix.errors import (
    ReziiixApiError,
    ReziiixError,
    ReziiixTimeoutError,
    ReziiixToolBlockedError,
    ReziiixValidationError,
)
from reziiix.models import ToolGovernanceResult

logger = logging.getLogger("reziiix")


# ═══════════════════════════════════════════════
# Core governance check
# ═══════════════════════════════════════════════


def check_tool_governance(
    client: Any,
    tool_name: str,
    tool_args: dict[str, Any],
    agent_id: str,
    scope: str = "tool_execution",
    platform: str = "M365",
    user_role: str = "Authenticated",
    fail_open: bool = True,
) -> ToolGovernanceResult:
    """Run a tool call through the governance pipeline.

    Calls client.govern() internally, maps the result to ToolGovernanceResult.
    On timeout/network error with fail_open=True, returns ALLOWED with a warning.
    """
    action_desc = f"Execute tool '{tool_name}'"
    args_preview = json.dumps(tool_args, default=str)[:500] if tool_args else "{}"
    action_text = f"{action_desc} with args: {args_preview}"

    try:
        result = client.govern(
            agent_id=agent_id,
            action=action_text,
            action_type=scope,
            platform=platform,
            user_role=user_role,
            context={"tool_name": tool_name, "tool_args": tool_args},
        )

        data = result.data if result and hasattr(result, "data") else None
        if not data:
            return ToolGovernanceResult(outcome="ALLOWED", govern_result=result)

        # Extract violations from DLP agent
        violations = []
        if hasattr(data, "agents"):
            for agent in data.agents:
                if agent.status == "FAIL" and agent.data:
                    for v in agent.data.get("violations", []):
                        violations.append(v)

        # Extract receipt ID
        receipt_id = None
        if hasattr(data, "crypto") and data.crypto:
            receipt_id = data.crypto.get("receiptId")

        return ToolGovernanceResult(
            outcome=data.outcome if hasattr(data, "outcome") else "ALLOWED",
            receipt_id=receipt_id,
            orchestration_id=data.orchestration_id if hasattr(data, "orchestration_id") else None,
            classification=data.classification if hasattr(data, "classification") else "",
            violations=violations,
            policy=data.policy if hasattr(data, "policy") and isinstance(data.policy, dict) else {},
            govern_result=result,
        )

    except (ReziiixTimeoutError, ReziiixApiError) as exc:
        if fail_open:
            logger.warning(
                "[REZIIIX] Governance check failed for tool '%s' — failing open: %s",
                tool_name,
                exc,
            )
            return ToolGovernanceResult(outcome="ALLOWED")
        raise


async def async_check_tool_governance(
    client: Any,
    tool_name: str,
    tool_args: dict[str, Any],
    agent_id: str,
    scope: str = "tool_execution",
    platform: str = "M365",
    user_role: str = "Authenticated",
    fail_open: bool = True,
) -> ToolGovernanceResult:
    """Async variant of check_tool_governance."""
    action_desc = f"Execute tool '{tool_name}'"
    args_preview = json.dumps(tool_args, default=str)[:500] if tool_args else "{}"
    action_text = f"{action_desc} with args: {args_preview}"

    try:
        result = await client.async_govern(
            agent_id=agent_id,
            action=action_text,
            action_type=scope,
            platform=platform,
            user_role=user_role,
            context={"tool_name": tool_name, "tool_args": tool_args},
        )

        data = result.data if result and hasattr(result, "data") else None
        if not data:
            return ToolGovernanceResult(outcome="ALLOWED", govern_result=result)

        violations = []
        if hasattr(data, "agents"):
            for agent in data.agents:
                if agent.status == "FAIL" and agent.data:
                    for v in agent.data.get("violations", []):
                        violations.append(v)

        receipt_id = None
        if hasattr(data, "crypto") and data.crypto:
            receipt_id = data.crypto.get("receiptId")

        return ToolGovernanceResult(
            outcome=data.outcome if hasattr(data, "outcome") else "ALLOWED",
            receipt_id=receipt_id,
            orchestration_id=data.orchestration_id if hasattr(data, "orchestration_id") else None,
            classification=data.classification if hasattr(data, "classification") else "",
            violations=violations,
            policy=data.policy if hasattr(data, "policy") and isinstance(data.policy, dict) else {},
            govern_result=result,
        )

    except (ReziiixTimeoutError, ReziiixApiError) as exc:
        if fail_open:
            logger.warning(
                "[REZIIIX] Governance check failed for tool '%s' — failing open: %s",
                tool_name,
                exc,
            )
            return ToolGovernanceResult(outcome="ALLOWED")
        raise


# ═══════════════════════════════════════════════
# GovernedCallable — wraps any plain callable
# ═══════════════════════════════════════════════


class GovernedCallable:
    """Wraps a callable function with REZIIIX governance.

    Before each invocation, runs the tool call through the 10-agent governance
    pipeline. If BLOCKED, raises ReziiixToolBlockedError with a clear message.
    If governance is unreachable and fail_open=True, the tool executes anyway.
    """

    def __init__(
        self,
        fn: Callable,
        client: Any,
        agent_id: str,
        tool_name: str | None = None,
        scope: str = "tool_execution",
        platform: str = "M365",
        user_role: str = "Authenticated",
        on_blocked: Callable[[ReziiixToolBlockedError], Any] | None = None,
        on_warned: Callable[[ToolGovernanceResult], Any] | None = None,
        raise_on_warn: bool = False,
        fail_open: bool = True,
    ):
        self._fn = fn
        self._client = client
        self._agent_id = agent_id
        self._tool_name = tool_name or getattr(fn, "__name__", "unknown_tool")
        self._scope = scope
        self._platform = platform
        self._user_role = user_role
        self._on_blocked = on_blocked
        self._on_warned = on_warned
        self._raise_on_warn = raise_on_warn
        self._fail_open = fail_open
        self._last_gov = None
        # Preserve function metadata (but NOT __wrapped__ — prevents governance bypass)
        self.__name__ = self._tool_name
        self.__doc__ = getattr(fn, "__doc__", None)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        tool_args = {**kwargs}
        if args:
            tool_args["_positional"] = [repr(a)[:200] for a in args]

        gov = check_tool_governance(
            client=self._client,
            tool_name=self._tool_name,
            tool_args=tool_args,
            agent_id=self._agent_id,
            scope=self._scope,
            platform=self._platform,
            user_role=self._user_role,
            fail_open=self._fail_open,
        )
        self._last_gov = gov

        if gov.outcome == "BLOCKED":
            err = ReziiixToolBlockedError(
                tool_name=self._tool_name,
                outcome=gov.outcome,
                classification=gov.classification,
                violations=gov.violations,
                receipt_id=gov.receipt_id,
            )
            if self._on_blocked:
                self._on_blocked(err)
            logger.warning(
                "[REZIIIX] BLOCKED tool '%s' | class=%s | receipt=%s",
                self._tool_name,
                gov.classification,
                gov.receipt_id,
            )
            raise err

        if gov.outcome == "WARNED":
            logger.warning(
                "[REZIIIX] WARNED tool '%s' | class=%s | receipt=%s",
                self._tool_name,
                gov.classification,
                gov.receipt_id,
            )
            if self._on_warned:
                self._on_warned(gov)
            if self._raise_on_warn:
                raise ReziiixToolBlockedError(
                    tool_name=self._tool_name,
                    outcome="WARNED",
                    classification=gov.classification,
                    violations=gov.violations,
                    receipt_id=gov.receipt_id,
                )

        logger.debug(
            "[REZIIIX] %s tool '%s' | receipt=%s",
            gov.outcome,
            self._tool_name,
            gov.receipt_id,
        )

        return self._fn(*args, **kwargs)

    @property
    def last_governance_result(self) -> ToolGovernanceResult | None:
        """Access the last governance result (for testing/debugging)."""
        return getattr(self, "_last_gov", None)


# ═══════════════════════════════════════════════
# @governed_tool decorator
# ═══════════════════════════════════════════════


def governed_tool(
    client: Any = None,
    agent_id: str = "default-agent",
    scope: str = "tool_execution",
    *,
    platform: str = "M365",
    user_role: str = "Authenticated",
    fail_open: bool = True,
    raise_on_warn: bool = False,
) -> Callable:
    """Decorator that wraps a function with REZIIIX governance.

    Usage with explicit client:
        @governed_tool(client=rzx, agent_id="my-agent")
        def send_email(to: str, body: str) -> str: ...

    Usage with env vars (REZIIIX_API_KEY, REZIIIX_ENDPOINT):
        @governed_tool(agent_id="my-agent")
        def send_email(to: str, body: str) -> str: ...
    """

    def decorator(fn: Callable) -> GovernedCallable:
        actual_client = client or _get_default_client()
        return GovernedCallable(
            fn=fn,
            client=actual_client,
            agent_id=agent_id,
            tool_name=fn.__name__,
            scope=scope,
            platform=platform,
            user_role=user_role,
            fail_open=fail_open,
            raise_on_warn=raise_on_warn,
        )

    return decorator


def _get_default_client() -> Any:
    """Construct a ReziiixClient from environment variables."""
    from reziiix.client import ReziiixClient

    api_key = os.environ.get("REZIIIX_API_KEY", "")
    endpoint = os.environ.get("REZIIIX_ENDPOINT", "https://reziiix.com")
    governance_endpoint = os.environ.get("REZIIIX_GOVERNANCE_ENDPOINT")
    if not api_key:
        raise ReziiixValidationError(
            "No client provided and REZIIIX_API_KEY env var not set. "
            "Either pass client= to @governed_tool or set REZIIIX_API_KEY."
        )
    return ReziiixClient(
        api_key=api_key,
        endpoint=endpoint,
        governance_endpoint=governance_endpoint,
    )


# ═══════════════════════════════════════════════
# Framework adapters
# ═══════════════════════════════════════════════


def wrap_langchain_tool(
    tool: Any,
    client: Any,
    agent_id: str,
    scope: str = "tool_execution",
    platform: str = "M365",
    user_role: str = "Authenticated",
    fail_open: bool = True,
    on_blocked: Callable | None = None,
    on_warned: Callable | None = None,
    raise_on_warn: bool = False,
) -> Any:
    """Wrap a LangChain BaseTool with REZIIIX governance.

    Returns a BaseTool subclass that runs governance before execution.
    On BLOCKED, returns an error string (not an exception) so the LLM agent
    can understand and retry — LangChain handles tool error strings gracefully.
    """
    try:
        from langchain_core.tools import BaseTool
    except ImportError:
        raise ImportError(
            "langchain-core is required for LangChain tool wrapping. "
            "Install with: pip install reziiix[langchain]"
        )

    original_name = tool.name
    original_description = tool.description
    original_args_schema = getattr(tool, "args_schema", None)

    class GovernedLangChainTool(BaseTool):
        name: str = original_name
        description: str = original_description

        def _run(self, *args: Any, **kwargs: Any) -> Any:
            tool_args = {**kwargs}
            if args:
                tool_args["_input"] = str(args[0])[:500] if args else ""

            gov = check_tool_governance(
                client=client,
                tool_name=original_name,
                tool_args=tool_args,
                agent_id=agent_id,
                scope=scope,
                platform=platform,
                user_role=user_role,
                fail_open=fail_open,
            )

            if gov.outcome == "BLOCKED":
                err = ReziiixToolBlockedError(
                    tool_name=original_name,
                    outcome=gov.outcome,
                    classification=gov.classification,
                    violations=gov.violations,
                    receipt_id=gov.receipt_id,
                )
                if on_blocked:
                    on_blocked(err)
                return f"[GOVERNANCE BLOCKED] Tool '{original_name}' was blocked: {gov.classification}. Receipt: {gov.receipt_id}"

            if gov.outcome == "WARNED":
                if on_warned:
                    on_warned(gov)
                if raise_on_warn:
                    return f"[GOVERNANCE WARNED] Tool '{original_name}' raised a warning: {gov.classification}. Receipt: {gov.receipt_id}"

            return tool._run(*args, **kwargs)

        async def _arun(self, *args: Any, **kwargs: Any) -> Any:
            return self._run(*args, **kwargs)

    governed = GovernedLangChainTool()
    if original_args_schema:
        governed.args_schema = original_args_schema
    return governed


def wrap_crewai_tool(
    tool: Any,
    client: Any,
    agent_id: str,
    scope: str = "tool_execution",
    platform: str = "M365",
    user_role: str = "Authenticated",
    fail_open: bool = True,
    on_blocked: Callable | None = None,
) -> Any:
    """Wrap a CrewAI BaseTool with REZIIIX governance.

    Returns a CrewAI BaseTool subclass that runs governance before execution.
    On BLOCKED, returns an error string so the CrewAI agent can handle it.
    """
    try:
        from crewai.tools import BaseTool as CrewAIBaseTool
    except ImportError:
        raise ImportError(
            "crewai is required for CrewAI tool wrapping. "
            "Install with: pip install reziiix[crewai]"
        )

    original_name = tool.name
    original_description = tool.description

    class GovernedCrewAITool(CrewAIBaseTool):
        name: str = original_name
        description: str = original_description

        def _run(self, *args: Any, **kwargs: Any) -> Any:
            tool_args = {**kwargs}
            if args:
                tool_args["_input"] = str(args[0])[:500]

            gov = check_tool_governance(
                client=client,
                tool_name=original_name,
                tool_args=tool_args,
                agent_id=agent_id,
                scope=scope,
                platform=platform,
                user_role=user_role,
                fail_open=fail_open,
            )

            if gov.outcome == "BLOCKED":
                err = ReziiixToolBlockedError(
                    tool_name=original_name,
                    outcome=gov.outcome,
                    classification=gov.classification,
                    violations=gov.violations,
                    receipt_id=gov.receipt_id,
                )
                if on_blocked:
                    on_blocked(err)
                return f"[GOVERNANCE BLOCKED] Tool '{original_name}' was blocked: {gov.classification}. Receipt: {gov.receipt_id}"

            return tool._run(*args, **kwargs)

    return GovernedCrewAITool()


def wrap_openai_function(
    func_def: dict[str, Any],
    client: Any,
    agent_id: str,
    scope: str = "tool_execution",
    platform: str = "M365",
    user_role: str = "Authenticated",
    fail_open: bool = True,
) -> dict[str, Any]:
    """Wrap an OpenAI function definition with REZIIIX governance.

    Expects a dict with:
        - name: str
        - handler: Callable (the actual function to execute)
        - parameters: dict (OpenAI function schema, optional)
        - description: str (optional)

    Returns the same dict with the handler wrapped in governance checks.
    The function schema is preserved for OpenAI API consumption.
    """
    handler = func_def.get("handler")
    if not handler or not callable(handler):
        raise ReziiixValidationError(
            f"OpenAI function definition must have a callable 'handler' field. Got: {type(handler)}"
        )

    func_name = func_def.get("name", handler.__name__)

    governed_handler = GovernedCallable(
        fn=handler,
        client=client,
        agent_id=agent_id,
        tool_name=func_name,
        scope=scope,
        platform=platform,
        user_role=user_role,
        fail_open=fail_open,
    )

    return {
        **func_def,
        "handler": governed_handler,
    }


# ═══════════════════════════════════════════════
# Tool type detection
# ═══════════════════════════════════════════════


def detect_tool_type(tool: Any) -> str:
    """Detect the framework type of a tool via duck typing + optional imports."""
    # LangChain
    try:
        from langchain_core.tools import BaseTool as LCBaseTool

        if isinstance(tool, LCBaseTool):
            return "langchain"
    except ImportError:
        pass

    # CrewAI
    try:
        from crewai.tools import BaseTool as CrewAIBaseTool

        if isinstance(tool, CrewAIBaseTool):
            return "crewai"
    except ImportError:
        pass

    # OpenAI function dict shape
    if isinstance(tool, dict) and "name" in tool and ("handler" in tool or "function" in tool):
        return "openai"

    # Plain callable
    if callable(tool):
        return "callable"

    raise ReziiixValidationError(
        f"Cannot wrap tool of type {type(tool).__name__}. "
        "Expected: callable, LangChain BaseTool, CrewAI BaseTool, or OpenAI function dict."
    )
