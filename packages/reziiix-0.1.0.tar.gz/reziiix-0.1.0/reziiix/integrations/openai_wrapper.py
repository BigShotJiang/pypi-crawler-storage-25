"""REZIIIX OpenAI integration — governance wrapper for OpenAI client.

Intercepts `chat.completions.create()` to:
1. Scan user messages for prompt injection before sending
2. Govern tool/function calls before execution (when tools are provided)
3. Record token usage and costs after completion

Usage:
    ```python
    from openai import OpenAI
    from reziiix.integrations.openai_wrapper import wrap_openai

    client = wrap_openai(OpenAI())
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}],
    )
    ```

For function calling governance:
    ```python
    # After getting tool_calls from the model, govern each before execution:
    from reziiix.integrations.openai_wrapper import govern_tool_calls

    governed = govern_tool_calls(
        response.choices[0].message.tool_calls,
        agent_id="my-agent",
    )
    for call in governed:
        if call["blocked"]:
            # Feed blocked result back to the model
            messages.append({"role": "tool", "tool_call_id": call["id"],
                           "content": call["blocked_reason"]})
        else:
            result = execute_tool(call["function"])
            messages.append({"role": "tool", "tool_call_id": call["id"],
                           "content": result})
    ```
"""

from __future__ import annotations

import json
import os
import time
from typing import Any

from reziiix.client import ReziiixClient


def wrap_openai(
    openai_client: Any,
    api_key: str | None = None,
    endpoint: str | None = None,
    agent_id: str = "openai-agent",
    block_on_injection: bool = True,
    track_costs: bool = True,
    fail_open: bool = True,
) -> Any:
    """Wrap an OpenAI client with REZIIIX governance.

    Intercepts `chat.completions.create()` to:
    1. Scan user messages for prompt injection before sending
    2. Record token usage and costs after completion

    For tool/function call governance, use govern_tool_calls() separately
    between receiving tool_calls and executing them.
    """
    rzx_key = api_key or os.environ.get("REZIIIX_API_KEY", "")
    rzx_endpoint = endpoint or os.environ.get("REZIIIX_ENDPOINT", "https://reziiix.com")

    rzx = ReziiixClient(api_key=rzx_key, endpoint=rzx_endpoint)

    original_create = openai_client.chat.completions.create

    def governed_create(*args: Any, **kwargs: Any) -> Any:
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")

        # Pre-call: scan for injection
        if block_on_injection:
            for msg in messages:
                if msg.get("role") == "user":
                    content = msg.get("content", "")
                    if isinstance(content, str) and content:
                        try:
                            result = rzx.detect_injection(content)
                            if not result.safe:
                                raise RuntimeError(
                                    f"REZIIIX: Prompt injection detected in user message "
                                    f"(score={result.score}, verdict={result.verdict})"
                                )
                        except RuntimeError:
                            raise
                        except Exception:
                            if not fail_open:
                                raise

        # Execute original call
        start = time.monotonic()
        response = original_create(*args, **kwargs)
        latency_ms = int((time.monotonic() - start) * 1000)

        # Post-call: record usage
        if track_costs and hasattr(response, "usage") and response.usage:
            try:
                rzx.record_usage(
                    agent_id=agent_id,
                    model=model,
                    prompt_tokens=response.usage.prompt_tokens or 0,
                    completion_tokens=response.usage.completion_tokens or 0,
                    provider="openai",
                    latency_ms=latency_ms,
                )
            except Exception:
                pass  # Non-critical

        return response

    openai_client.chat.completions.create = governed_create
    return openai_client


def govern_tool_calls(
    tool_calls: Any,
    agent_id: str = "openai-agent",
    api_key: str | None = None,
    endpoint: str | None = None,
    fail_open: bool = True,
) -> list[dict[str, Any]]:
    """Govern OpenAI tool/function calls before execution.

    Takes the tool_calls from a chat completion response and runs each
    through the REZIIIX governance pipeline. Returns a list of dicts
    with the original call data plus governance results.

    Args:
        tool_calls: response.choices[0].message.tool_calls from OpenAI
        agent_id: Agent identifier for governance context
        api_key: REZIIIX API key (or set REZIIIX_API_KEY env var)
        endpoint: REZIIIX endpoint URL
        fail_open: Allow execution if governance is unreachable

    Returns:
        List of dicts with keys:
        - id: tool call ID
        - function: {name, arguments} from the original call
        - blocked: True if governance blocked this call
        - blocked_reason: Human-readable reason (for feeding back to model)
        - receipt_id: Governance receipt ID
        - outcome: ALLOWED/BLOCKED/WARN
    """
    rzx_key = api_key or os.environ.get("REZIIIX_API_KEY", "")
    rzx_endpoint = endpoint or os.environ.get("REZIIIX_ENDPOINT", "https://reziiix.com")
    rzx = ReziiixClient(api_key=rzx_key, endpoint=rzx_endpoint)

    results = []
    for call in tool_calls or []:
        func_name = call.function.name
        func_args = call.function.arguments

        entry: dict[str, Any] = {
            "id": call.id,
            "function": {"name": func_name, "arguments": func_args},
            "blocked": False,
            "blocked_reason": None,
            "receipt_id": None,
            "outcome": "ALLOWED",
        }

        try:
            args_preview = func_args[:500] if isinstance(func_args, str) else json.dumps(func_args)[:500]
            result = rzx.govern(
                agent_id=agent_id,
                action=f"Execute function '{func_name}' with args: {args_preview}",
                action_type="tool_execution",
            )
            data = result.data if hasattr(result, "data") else result
            outcome = data.get("outcome", "ALLOWED") if isinstance(data, dict) else getattr(data, "outcome", "ALLOWED")
            crypto = data.get("crypto", {}) if isinstance(data, dict) else getattr(data, "crypto", None)
            receipt_id = None
            if crypto:
                receipt_id = crypto.get("receiptId") if isinstance(crypto, dict) else getattr(crypto, "receiptId", None)
            policy = data.get("policy", {}) if isinstance(data, dict) else getattr(data, "policy", None)
            reason = None
            if policy:
                reason = policy.get("reason") if isinstance(policy, dict) else getattr(policy, "reason", None)

            entry["outcome"] = outcome
            entry["receipt_id"] = receipt_id
            if outcome == "BLOCKED":
                entry["blocked"] = True
                entry["blocked_reason"] = (
                    f"This action was blocked by governance policy. "
                    f"{reason or 'Policy violation detected.'} "
                    f"Receipt: {receipt_id}"
                )
        except Exception:
            if not fail_open:
                entry["blocked"] = True
                entry["blocked_reason"] = "Governance check failed — tool execution denied."

        results.append(entry)

    return results
