"""REZIIIX CrewAI integration — governance tool wrapper for CrewAI agents.

Two integration patterns:

1. **Governance tool** — Add as an explicit tool that agents can call to check policies:
   ```python
   from reziiix.integrations.crewai import get_reziiix_tool
   governance_tool = get_reziiix_tool(agent_id="crew-agent")
   agent = Agent(tools=[governance_tool, ...])
   ```

2. **Governed tool wrapper** — Wrap existing tools to auto-enforce governance:
   ```python
   from reziiix.integrations.crewai import govern_tools
   governed = govern_tools([search_tool, email_tool], agent_id="crew-agent")
   agent = Agent(tools=governed)
   ```
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from reziiix.client import ReziiixClient


@dataclass
class GovernanceDecision:
    """Structured governance decision returned by the governance tool."""

    outcome: str  # ALLOWED, BLOCKED, WARN
    classification: str
    receipt_id: str | None
    policy_id: str | None
    reason: str | None
    agent_verdicts: list[dict[str, Any]]

    def __str__(self) -> str:
        status = "ALLOWED" if self.outcome == "ALLOWED" else self.outcome
        parts = [f"Governance Decision: {status}"]
        if self.classification:
            parts.append(f"Classification: {self.classification}")
        if self.policy_id:
            parts.append(f"Policy: {self.policy_id}")
        if self.reason:
            parts.append(f"Reason: {self.reason}")
        if self.receipt_id:
            parts.append(f"Receipt: {self.receipt_id}")
        return " | ".join(parts)


def _extract_decision(result: Any) -> GovernanceDecision:
    """Extract a structured decision from a govern() result."""
    data = result.data if hasattr(result, "data") else result
    if isinstance(data, dict):
        outcome = data.get("outcome", "ALLOWED")
        classification = data.get("classification", "")
        crypto = data.get("crypto", {}) or {}
        receipt_id = crypto.get("receiptId")
        policy = data.get("policy", {}) or {}
        policy_id = policy.get("policyId")
        reason = policy.get("reason")
        agents = data.get("agents", []) or []
        verdicts = [
            {"name": a.get("name", a.get("key", "")), "status": a.get("status", "")}
            for a in agents
        ]
    else:
        outcome = getattr(data, "outcome", "ALLOWED")
        classification = getattr(data, "classification", "")
        crypto = getattr(data, "crypto", None)
        receipt_id = getattr(crypto, "receiptId", None) if crypto else None
        policy = getattr(data, "policy", None)
        policy_id = getattr(policy, "policyId", None) if policy else None
        reason = getattr(policy, "reason", None) if policy else None
        verdicts = []
    return GovernanceDecision(
        outcome=outcome,
        classification=classification,
        receipt_id=receipt_id,
        policy_id=policy_id,
        reason=reason,
        agent_verdicts=verdicts,
    )


def get_reziiix_tool(**kwargs: Any) -> Any:
    """Create a CrewAI-compatible tool for governance scanning.

    Returns a BaseTool that agents can call to check whether an action
    is allowed by governance policies before executing it.
    """
    try:
        from crewai.tools import BaseTool
    except ImportError:
        raise ImportError(
            "crewai is required for CrewAI integration. "
            "Install it with: pip install reziiix[crewai]"
        )

    api_key = kwargs.pop("api_key", None) or os.environ.get("REZIIIX_API_KEY", "")
    endpoint = kwargs.pop("endpoint", None) or os.environ.get("REZIIIX_ENDPOINT", "https://reziiix.com")
    agent_id = kwargs.pop("agent_id", "crewai-agent")

    client = ReziiixClient(api_key=api_key, endpoint=endpoint)

    class ReziiixGovernanceTool(BaseTool):
        name: str = "reziiix_governance_check"
        description: str = (
            "Check if an AI agent action is allowed by governance policies. "
            "Input: description of the action the agent wants to take. "
            "Output: structured governance decision (ALLOWED/BLOCKED/WARN) with "
            "classification, policy triggers, and receipt ID."
        )

        def _run(self, action: str) -> str:
            try:
                result = client.govern(agent_id=agent_id, action=action)
                decision = _extract_decision(result)
                return str(decision)
            except Exception as e:
                return f"Governance check failed (fail-open): {e}"

    return ReziiixGovernanceTool()


def govern_tools(
    tools: list[Any],
    agent_id: str = "crewai-agent",
    api_key: str | None = None,
    endpoint: str | None = None,
    fail_open: bool = True,
) -> list[Any]:
    """Wrap a list of CrewAI tools with governance enforcement.

    Each wrapped tool runs the full 10-agent governance pipeline before
    executing. If BLOCKED, returns a governance error message instead of
    executing the tool. If fail_open=True and governance is unreachable,
    the tool executes normally.

    Args:
        tools: List of CrewAI BaseTool instances
        agent_id: Agent identifier for governance context
        api_key: REZIIIX API key (or set REZIIIX_API_KEY env var)
        endpoint: REZIIIX endpoint URL
        fail_open: Allow execution if governance is unreachable (default: True)

    Returns:
        List of governed tools in the same order.
    """
    try:
        from crewai.tools import BaseTool
    except ImportError:
        raise ImportError(
            "crewai is required for CrewAI integration. "
            "Install it with: pip install reziiix[crewai]"
        )

    resolved_key = api_key or os.environ.get("REZIIIX_API_KEY", "")
    resolved_endpoint = endpoint or os.environ.get("REZIIIX_ENDPOINT", "https://reziiix.com")
    client = ReziiixClient(api_key=resolved_key, endpoint=resolved_endpoint)

    governed = []
    for tool in tools:
        original_run = tool._run

        def make_governed_run(orig_run: Any, tool_name: str) -> Any:
            def governed_run(action: str) -> str:
                try:
                    result = client.govern(
                        agent_id=agent_id,
                        action=f"Execute tool '{tool_name}' with input: {action[:500]}",
                        action_type="tool_execution",
                    )
                    decision = _extract_decision(result)
                    if decision.outcome == "BLOCKED":
                        return (
                            f"BLOCKED by governance policy. {decision.reason or ''} "
                            f"Receipt: {decision.receipt_id}"
                        )
                except Exception:
                    if not fail_open:
                        return "Governance check failed — tool execution denied."
                return orig_run(action)

            return governed_run

        tool._run = make_governed_run(original_run, tool.name)
        governed.append(tool)

    return governed
