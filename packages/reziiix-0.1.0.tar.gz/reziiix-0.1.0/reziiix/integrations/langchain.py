"""REZIIIX LangChain integration — governance callback handler.

Hooks into three LangChain lifecycle events:
1. on_llm_start: Scans prompts for injection attacks
2. on_tool_start: Runs full 10-agent governance pipeline before tool execution
3. on_llm_end: Records token usage for cost tracking

Usage:
    ```python
    from reziiix.integrations.langchain import get_reziiix_callback

    callback = get_reziiix_callback(agent_id="my-agent")
    chain.invoke({"input": "..."}, config={"callbacks": [callback]})
    ```
"""

from __future__ import annotations

import os
from typing import Any

from reziiix.client import ReziiixClient


class GovernanceBlockedError(RuntimeError):
    """Raised when a tool call is blocked by REZIIIX governance."""

    def __init__(self, tool_name: str, outcome: str, receipt_id: str | None = None):
        self.tool_name = tool_name
        self.outcome = outcome
        self.receipt_id = receipt_id
        super().__init__(
            f"REZIIIX: Tool '{tool_name}' blocked by governance policy "
            f"(outcome={outcome}, receipt={receipt_id})"
        )


def get_reziiix_callback(**kwargs: Any) -> Any:
    """Create a LangChain callback handler that enforces REZIIIX governance.

    Args:
        api_key: REZIIIX API key (or set REZIIIX_API_KEY env var)
        endpoint: REZIIIX endpoint URL (or set REZIIIX_ENDPOINT env var)
        agent_id: Agent identifier for governance context (default: "langchain-agent")
        block_on_injection: Scan prompts for injection attacks (default: True)
        govern_tools: Run full governance pipeline on tool calls (default: True)
        track_costs: Record token usage after LLM calls (default: True)
        fail_open: Allow execution if governance service is unreachable (default: True)
        on_blocked: Callback when a tool is blocked (receives tool_name, outcome, receipt_id)
    """
    try:
        from langchain_core.callbacks import BaseCallbackHandler
    except ImportError:
        raise ImportError(
            "langchain-core is required for LangChain integration. "
            "Install it with: pip install reziiix[langchain]"
        )

    api_key = kwargs.pop("api_key", None) or os.environ.get("REZIIIX_API_KEY", "")
    endpoint = kwargs.pop("endpoint", None) or os.environ.get("REZIIIX_ENDPOINT", "https://reziiix.com")
    agent_id = kwargs.pop("agent_id", "langchain-agent")
    block_on_injection = kwargs.pop("block_on_injection", True)
    govern_tools = kwargs.pop("govern_tools", True)
    track_costs = kwargs.pop("track_costs", True)
    fail_open = kwargs.pop("fail_open", True)
    on_blocked = kwargs.pop("on_blocked", None)

    client = ReziiixClient(api_key=api_key, endpoint=endpoint)

    class ReziiixCallbackHandler(BaseCallbackHandler):
        """LangChain callback: injection scan, tool governance, cost tracking."""

        def on_llm_start(
            self,
            serialized: dict[str, Any],
            prompts: list[str],
            **kw: Any,
        ) -> None:
            """Scan prompts for injection attacks before sending to LLM."""
            if not block_on_injection:
                return
            for prompt in prompts:
                try:
                    result = client.detect_injection(prompt)
                    if not result.safe:
                        raise RuntimeError(
                            f"REZIIIX: Prompt injection detected (score={result.score}, "
                            f"verdict={result.verdict})"
                        )
                except RuntimeError:
                    raise
                except Exception:
                    if not fail_open:
                        raise

        def on_tool_start(
            self,
            serialized: dict[str, Any],
            input_str: str,
            **kw: Any,
        ) -> None:
            """Run full 10-agent governance pipeline before tool execution."""
            if not govern_tools:
                return

            tool_name = serialized.get("name", "unknown_tool")
            action_text = f"Execute tool '{tool_name}' with input: {input_str[:500]}"

            try:
                result = client.govern(
                    agent_id=agent_id,
                    action=action_text,
                    action_type="tool_execution",
                )
                data = result.data if hasattr(result, "data") else result
                outcome = getattr(data, "outcome", None) or (
                    data.get("outcome") if isinstance(data, dict) else "ALLOWED"
                )
                receipt_id = None
                crypto = getattr(data, "crypto", None) or (
                    data.get("crypto") if isinstance(data, dict) else None
                )
                if crypto:
                    receipt_id = (
                        getattr(crypto, "receiptId", None)
                        or (crypto.get("receiptId") if isinstance(crypto, dict) else None)
                    )

                if outcome == "BLOCKED":
                    if on_blocked:
                        on_blocked(tool_name, outcome, receipt_id)
                    raise GovernanceBlockedError(tool_name, outcome, receipt_id)
            except GovernanceBlockedError:
                raise
            except Exception:
                if not fail_open:
                    raise
                # Fail open — allow tool execution

        def on_llm_end(self, response: Any, **kw: Any) -> None:
            """Record token usage for cost tracking."""
            if not track_costs:
                return
            try:
                usage = getattr(response, "llm_output", {}) or {}
                token_usage = usage.get("token_usage", {})
                if token_usage:
                    model = usage.get("model_name", "unknown")
                    client.record_usage(
                        agent_id=agent_id,
                        model=model,
                        prompt_tokens=token_usage.get("prompt_tokens", 0),
                        completion_tokens=token_usage.get("completion_tokens", 0),
                        provider="openai",
                    )
            except Exception:
                pass  # Non-critical

    return ReziiixCallbackHandler()
