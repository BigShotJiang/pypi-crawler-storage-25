"""REZIIIX Python SDK — Async/sync client for the AI Governance Platform API."""

from __future__ import annotations

from typing import Any, Callable, Sequence
from urllib.parse import quote

import httpx

from reziiix.errors import (
    ReziiixApiError,
    ReziiixAuthError,
    ReziiixError,
    ReziiixTimeoutError,
    ReziiixValidationError,
)
from reziiix.models import (
    Agent,
    AgentDetail,
    ComplianceReport,
    CostStats,
    DashboardStats,
    GovernResult,
    InjectionResult,
    Policy,
    Receipt,
    ScanResult,
    VerifyResult,
)

DEFAULT_ENDPOINT = "https://reziiix.com"
DEFAULT_TIMEOUT = 10.0


class ReziiixClient:
    """REZIIIX AI Governance SDK client.

    Supports both sync and async usage. For async, use the `async_*` methods
    or the `async with` context manager.

    Example:
        ```python
        from reziiix import ReziiixClient

        client = ReziiixClient(api_key="rzx_...")

        # Sync
        result = client.scan(agent_id="my-agent", action="Send email")

        # Async
        result = await client.async_scan(agent_id="my-agent", action="Send email")
        ```
    """

    def __init__(
        self,
        api_key: str,
        endpoint: str = DEFAULT_ENDPOINT,
        governance_endpoint: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        if not api_key:
            raise ReziiixValidationError(
                "api_key is required — create one at Developer Hub → API Keys"
            )

        self._api_key = api_key
        self._endpoint = endpoint.rstrip("/")
        self._governance_endpoint = (governance_endpoint or endpoint).rstrip("/")
        self._timeout = timeout
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None
        self._governance_sync_client: httpx.Client | None = None
        self._governance_async_client: httpx.AsyncClient | None = None

    def __repr__(self) -> str:
        masked = self._api_key[:8] + "..." if len(self._api_key) > 8 else "***"
        return f"ReziiixClient(api_key='{masked}', endpoint='{self._endpoint}')"

    def __str__(self) -> str:
        return self.__repr__()

    def _get_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "reziiix-python/0.1.0",
        }

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        if response.status_code in (401, 403):
            try:
                data = response.json()
                msg = data.get("error", "Authentication failed")
            except Exception:
                msg = "Authentication failed"
            raise ReziiixAuthError(msg)

        if not response.is_success:
            try:
                data = response.json()
                msg = data.get("error", f"API error: {response.status_code}")
            except Exception:
                msg = f"API error: {response.status_code} — {response.text[:200]}"
            raise ReziiixApiError(msg, status=response.status_code)

        return response.json()

    # ── Sync HTTP ──

    @property
    def _sync(self) -> httpx.Client:
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                base_url=self._endpoint,
                headers=self._get_headers(),
                timeout=self._timeout,
            )
        return self._sync_client

    @property
    def _governance_sync(self) -> httpx.Client:
        """Sync client pointed at the governance service (Railway)."""
        if self._governance_sync_client is None:
            self._governance_sync_client = httpx.Client(
                base_url=self._governance_endpoint,
                headers=self._get_headers(),
                timeout=self._timeout,
            )
        return self._governance_sync_client

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        try:
            response = self._sync.request(method, path, **kwargs)
            return self._handle_response(response)
        except httpx.TimeoutException:
            raise ReziiixTimeoutError(self._timeout)
        except ReziiixError:
            raise
        except Exception as e:
            raise ReziiixApiError(str(e))

    def _governance_request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send request to governance service endpoint."""
        try:
            response = self._governance_sync.request(method, path, **kwargs)
            return self._handle_response(response)
        except httpx.TimeoutException:
            raise ReziiixTimeoutError(self._timeout)
        except ReziiixError:
            raise
        except Exception as e:
            raise ReziiixApiError(str(e))

    # ── Async HTTP ──

    @property
    def _async(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                base_url=self._endpoint,
                headers=self._get_headers(),
                timeout=self._timeout,
            )
        return self._async_client

    @property
    def _governance_async(self) -> httpx.AsyncClient:
        """Async client pointed at the governance service (Railway)."""
        if self._governance_async_client is None:
            self._governance_async_client = httpx.AsyncClient(
                base_url=self._governance_endpoint,
                headers=self._get_headers(),
                timeout=self._timeout,
            )
        return self._governance_async_client

    async def _arequest(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        try:
            response = await self._async.request(method, path, **kwargs)
            return self._handle_response(response)
        except httpx.TimeoutException:
            raise ReziiixTimeoutError(self._timeout)
        except ReziiixError:
            raise
        except Exception as e:
            raise ReziiixApiError(str(e))

    async def _governance_arequest(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        """Send async request to governance service endpoint."""
        try:
            response = await self._governance_async.request(method, path, **kwargs)
            return self._handle_response(response)
        except httpx.TimeoutException:
            raise ReziiixTimeoutError(self._timeout)
        except ReziiixError:
            raise
        except Exception as e:
            raise ReziiixApiError(str(e))

    # ── Context managers ──

    def __enter__(self) -> ReziiixClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    async def __aenter__(self) -> ReziiixClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    def close(self) -> None:
        if self._sync_client:
            self._sync_client.close()
            self._sync_client = None
        if self._governance_sync_client:
            self._governance_sync_client.close()
            self._governance_sync_client = None

    async def aclose(self) -> None:
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None
        if self._governance_async_client:
            await self._governance_async_client.aclose()
            self._governance_async_client = None

    # ═══════════════════════════════════════════════
    # Scan
    # ═══════════════════════════════════════════════

    def scan(
        self,
        agent_id: str,
        action: str,
        context: dict[str, Any] | None = None,
        mode: str = "sample",
        data: str | None = None,
    ) -> ScanResult:
        """Scan an AI agent action against governance policies."""
        if not agent_id:
            raise ReziiixValidationError("agent_id is required")
        if not action:
            raise ReziiixValidationError("action is required")

        body: dict[str, Any] = {
            "agentId": agent_id,
            "action": action,
            "context": context or {},
            "mode": mode,
        }
        if data:
            body["data"] = data

        raw = self._request("POST", "/api/scan", json=body)
        return ScanResult.model_validate(raw)

    async def async_scan(
        self,
        agent_id: str,
        action: str,
        context: dict[str, Any] | None = None,
        mode: str = "sample",
        data: str | None = None,
    ) -> ScanResult:
        """Async: Scan an AI agent action against governance policies."""
        if not agent_id:
            raise ReziiixValidationError("agent_id is required")
        if not action:
            raise ReziiixValidationError("action is required")

        body: dict[str, Any] = {
            "agentId": agent_id,
            "action": action,
            "context": context or {},
            "mode": mode,
        }
        if data:
            body["data"] = data

        raw = await self._arequest("POST", "/api/scan", json=body)
        return ScanResult.model_validate(raw)

    # ═══════════════════════════════════════════════
    # Govern (Orchestration Pipeline)
    # ═══════════════════════════════════════════════

    def govern(
        self,
        agent_id: str,
        action: str,
        action_type: str | None = None,
        platform: str = "M365",
        user_role: str = "Authenticated",
        recipients: list[str] | None = None,
        context: dict[str, Any] | None = None,
    ) -> GovernResult:
        """Run an AI agent action through the full 10-agent governance pipeline."""
        if not agent_id:
            raise ReziiixValidationError("agent_id is required")
        if not action:
            raise ReziiixValidationError("action is required")

        body: dict[str, Any] = {
            "text": action,
            "action": action_type or "unknown",
            "actionType": action_type,
            "platform": platform,
            "userRole": user_role,
            "recipients": recipients or [],
            "agentId": agent_id,
            **(context or {}),
        }

        raw = self._governance_request("POST", "/api/orchestrate", json=body)
        return GovernResult.model_validate(raw)

    async def async_govern(
        self,
        agent_id: str,
        action: str,
        action_type: str | None = None,
        platform: str = "M365",
        user_role: str = "Authenticated",
        recipients: list[str] | None = None,
        context: dict[str, Any] | None = None,
    ) -> GovernResult:
        """Async: Run an AI agent action through the full 10-agent governance pipeline."""
        if not agent_id:
            raise ReziiixValidationError("agent_id is required")
        if not action:
            raise ReziiixValidationError("action is required")

        body: dict[str, Any] = {
            "text": action,
            "action": action_type or "unknown",
            "actionType": action_type,
            "platform": platform,
            "userRole": user_role,
            "recipients": recipients or [],
            "agentId": agent_id,
            **(context or {}),
        }

        raw = await self._governance_arequest("POST", "/api/orchestrate", json=body)
        return GovernResult.model_validate(raw)

    # ═══════════════════════════════════════════════
    # Batch Operations
    # ═══════════════════════════════════════════════

    def batch_govern(
        self,
        actions: list[dict[str, Any]],
        parallel_limit: int = 5,
        stop_on_blocked: bool = False,
    ) -> "BatchGovernResult":
        """Run multiple governance checks in a single request.

        Solves the N+1 problem: instead of calling govern() in a loop,
        send one batch and get all results with a summary.

        Args:
            actions: List of action dicts, each with at least 'action' key.
                     Optional keys: agentId, actionType, platform, userRole, recipients, context.
            parallel_limit: Max concurrent pipeline executions (1-10, default 5).
            stop_on_blocked: Stop processing on first BLOCKED result (default False).

        Returns:
            BatchGovernResult with results list and summary stats.

        Example::

            batch = client.batch_govern([
                {"agentId": "agent-1", "action": "Send employee PII to partner"},
                {"agentId": "agent-1", "action": "Read public training docs"},
                {"agentId": "agent-2", "action": "Export all customer records"},
            ])
            print(batch.summary)
            # BatchSummary(total=3, allowed=1, blocked=2, warned=0, errors=0, ...)
        """
        from .models import BatchGovernResult

        if not actions:
            raise ReziiixValidationError("actions list is required and must not be empty")
        if len(actions) > 50:
            raise ReziiixValidationError("Maximum 50 actions per batch")

        body = {
            "actions": actions,
            "parallelLimit": parallel_limit,
            "stopOnBlocked": stop_on_blocked,
        }
        raw = self._request("POST", "/api/batch", json=body)
        return BatchGovernResult.model_validate(raw)

    async def async_batch_govern(
        self,
        actions: list[dict[str, Any]],
        parallel_limit: int = 5,
        stop_on_blocked: bool = False,
    ) -> "BatchGovernResult":
        """Async: Run multiple governance checks in a single request."""
        from .models import BatchGovernResult

        if not actions:
            raise ReziiixValidationError("actions list is required and must not be empty")
        if len(actions) > 50:
            raise ReziiixValidationError("Maximum 50 actions per batch")

        body = {
            "actions": actions,
            "parallelLimit": parallel_limit,
            "stopOnBlocked": stop_on_blocked,
        }
        raw = await self._arequest("POST", "/api/batch", json=body)
        return BatchGovernResult.model_validate(raw)

    # ═══════════════════════════════════════════════
    # Injection Detection
    # ═══════════════════════════════════════════════

    def detect_injection(
        self,
        text: str,
        threshold: float = 0.5,
        detailed: bool = True,
    ) -> InjectionResult:
        """Scan text for prompt injection attempts."""
        raw = self._request("POST", "/api/scan/injection", json={
            "text": text,
            "threshold": threshold,
            "detailed": detailed,
        })
        return InjectionResult.model_validate(raw)

    async def async_detect_injection(
        self,
        text: str,
        threshold: float = 0.5,
        detailed: bool = True,
    ) -> InjectionResult:
        """Async: Scan text for prompt injection attempts."""
        raw = await self._arequest("POST", "/api/scan/injection", json={
            "text": text,
            "threshold": threshold,
            "detailed": detailed,
        })
        return InjectionResult.model_validate(raw)

    # ═══════════════════════════════════════════════
    # Dashboard Stats
    # ═══════════════════════════════════════════════

    def stats(self) -> DashboardStats:
        """Get aggregated dashboard metrics."""
        raw = self._request("GET", "/api/dashboard-stats")
        return DashboardStats.model_validate(raw)

    async def async_stats(self) -> DashboardStats:
        raw = await self._arequest("GET", "/api/dashboard-stats")
        return DashboardStats.model_validate(raw)

    # ═══════════════════════════════════════════════
    # Policies
    # ═══════════════════════════════════════════════

    def list_policies(self) -> list[Policy]:
        """List all active policies."""
        raw = self._request("GET", "/api/policies")
        return [Policy.model_validate(p) for p in raw.get("data", [])]

    async def async_list_policies(self) -> list[Policy]:
        raw = await self._arequest("GET", "/api/policies")
        return [Policy.model_validate(p) for p in raw.get("data", [])]

    # ═══════════════════════════════════════════════
    # Agents
    # ═══════════════════════════════════════════════

    def list_agents(self) -> list[Agent]:
        """List all registered agents."""
        raw = self._request("GET", "/api/agents")
        return [Agent.model_validate(a) for a in raw.get("data", [])]

    async def async_list_agents(self) -> list[Agent]:
        raw = await self._arequest("GET", "/api/agents")
        return [Agent.model_validate(a) for a in raw.get("data", [])]

    def get_agent(self, agent_id: str) -> AgentDetail:
        """Get detailed info for a specific agent."""
        if not agent_id:
            raise ReziiixValidationError("agent_id is required")
        raw = self._request("GET", f"/api/agents?id={quote(agent_id, safe='')}")
        return AgentDetail.model_validate(raw.get("data", {}))

    async def async_get_agent(self, agent_id: str) -> AgentDetail:
        if not agent_id:
            raise ReziiixValidationError("agent_id is required")
        raw = await self._arequest("GET", f"/api/agents?id={quote(agent_id, safe='')}")
        return AgentDetail.model_validate(raw.get("data", {}))

    # ═══════════════════════════════════════════════
    # Receipts
    # ═══════════════════════════════════════════════

    def list_receipts(
        self,
        agent: str | None = None,
        decision: str | None = None,
        limit: int = 50,
    ) -> list[Receipt]:
        """List receipts with optional filters."""
        params: dict[str, Any] = {"limit": limit}
        if agent:
            params["agent"] = agent
        if decision:
            params["decision"] = decision
        raw = self._request("GET", "/api/receipts", params=params)
        return [Receipt.model_validate(r) for r in raw.get("data", [])]

    async def async_list_receipts(
        self,
        agent: str | None = None,
        decision: str | None = None,
        limit: int = 50,
    ) -> list[Receipt]:
        params: dict[str, Any] = {"limit": limit}
        if agent:
            params["agent"] = agent
        if decision:
            params["decision"] = decision
        raw = await self._arequest("GET", "/api/receipts", params=params)
        return [Receipt.model_validate(r) for r in raw.get("data", [])]

    def verify_receipts(self, receipt_ids: list[str]) -> list[VerifyResult]:
        """Batch verify receipt integrity."""
        if not receipt_ids:
            raise ReziiixValidationError("receipt_ids is required")
        raw = self._request("POST", "/api/receipts?verify=1", json={"receiptIds": receipt_ids})
        return [VerifyResult.model_validate(r) for r in raw.get("results", [])]

    async def async_verify_receipts(self, receipt_ids: list[str]) -> list[VerifyResult]:
        if not receipt_ids:
            raise ReziiixValidationError("receipt_ids is required")
        raw = await self._arequest(
            "POST", "/api/receipts?verify=1", json={"receiptIds": receipt_ids}
        )
        return [VerifyResult.model_validate(r) for r in raw.get("results", [])]

    # ═══════════════════════════════════════════════
    # Cost Tracking
    # ═══════════════════════════════════════════════

    def get_costs(self, period: str = "30d") -> CostStats:
        """Get cost and token usage stats."""
        raw = self._request("GET", "/api/costs", params={"period": period})
        return CostStats.model_validate(raw)

    async def async_get_costs(self, period: str = "30d") -> CostStats:
        raw = await self._arequest("GET", "/api/costs", params={"period": period})
        return CostStats.model_validate(raw)

    def record_usage(
        self,
        agent_id: str,
        model: str,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        provider: str = "openai",
        latency_ms: int | None = None,
        action: str | None = None,
    ) -> dict[str, Any]:
        """Record token usage for an LLM call."""
        body: dict[str, Any] = {
            "agentId": agent_id,
            "model": model,
            "promptTokens": prompt_tokens,
            "completionTokens": completion_tokens,
            "provider": provider,
        }
        if latency_ms is not None:
            body["latencyMs"] = latency_ms
        if action:
            body["action"] = action
        return self._request("POST", "/api/costs", json=body)

    async def async_record_usage(
        self,
        agent_id: str,
        model: str,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        provider: str = "openai",
        latency_ms: int | None = None,
        action: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "agentId": agent_id,
            "model": model,
            "promptTokens": prompt_tokens,
            "completionTokens": completion_tokens,
            "provider": provider,
        }
        if latency_ms is not None:
            body["latencyMs"] = latency_ms
        if action:
            body["action"] = action
        return await self._arequest("POST", "/api/costs", json=body)

    # ═══════════════════════════════════════════════
    # Compliance
    # ═══════════════════════════════════════════════

    def compliance_report(self) -> ComplianceReport:
        """Generate an EU AI Act compliance report."""
        raw = self._request("GET", "/api/reports/compliance")
        return ComplianceReport.model_validate(raw)

    async def async_compliance_report(self) -> ComplianceReport:
        raw = await self._arequest("GET", "/api/reports/compliance")
        return ComplianceReport.model_validate(raw)

    # ═══════════════════════════════════════════════
    # Tool Governance (Week 12)
    # ═══════════════════════════════════════════════

    def wrap_tools(
        self,
        tools: Sequence[Any],
        agent_id: str,
        scope: str = "tool_execution",
        *,
        platform: str = "M365",
        user_role: str = "Authenticated",
        on_blocked: Callable | None = None,
        on_warned: Callable | None = None,
        raise_on_warn: bool = False,
        fail_open: bool = True,
    ) -> list[Any]:
        """Wrap a list of tools with REZIIIX governance.

        Auto-detects the tool type (LangChain, CrewAI, OpenAI function, or
        plain callable) and returns governed versions that run the full
        10-agent pipeline before each execution.

        Args:
            tools: List of callables, LangChain tools, CrewAI tools, or
                   OpenAI function dicts with a 'handler' field.
            agent_id: Agent identifier for governance context.
            scope: Action type for policy evaluation (default: "tool_execution").
            platform: Platform context (default: "M365").
            user_role: User role for RBAC evaluation.
            on_blocked: Callback when a tool call is BLOCKED.
            on_warned: Callback when a tool call gets a WARN.
            raise_on_warn: Raise on WARN instead of just logging.
            fail_open: Allow tool execution if governance is unreachable.

        Returns:
            List of governed tools in the same order. Each is a drop-in
            replacement for the original.
        """
        from reziiix.tools import detect_tool_type, GovernedCallable, wrap_langchain_tool, wrap_crewai_tool, wrap_openai_function

        result = []
        for tool in tools:
            result.append(
                self.wrap_tool(
                    tool,
                    agent_id=agent_id,
                    scope=scope,
                    platform=platform,
                    user_role=user_role,
                    on_blocked=on_blocked,
                    on_warned=on_warned,
                    raise_on_warn=raise_on_warn,
                    fail_open=fail_open,
                )
            )
        return result

    def wrap_tool(
        self,
        tool: Any,
        agent_id: str,
        scope: str = "tool_execution",
        *,
        platform: str = "M365",
        user_role: str = "Authenticated",
        on_blocked: Callable | None = None,
        on_warned: Callable | None = None,
        raise_on_warn: bool = False,
        fail_open: bool = True,
    ) -> Any:
        """Wrap a single tool with REZIIIX governance.

        See wrap_tools() for parameter documentation.
        """
        from reziiix.tools import detect_tool_type, GovernedCallable, wrap_langchain_tool, wrap_crewai_tool, wrap_openai_function

        tool_type = detect_tool_type(tool)
        kwargs = dict(
            client=self,
            agent_id=agent_id,
            scope=scope,
            platform=platform,
            user_role=user_role,
            fail_open=fail_open,
        )

        if tool_type == "langchain":
            return wrap_langchain_tool(
                tool, on_blocked=on_blocked, on_warned=on_warned,
                raise_on_warn=raise_on_warn, **kwargs,
            )
        elif tool_type == "crewai":
            return wrap_crewai_tool(tool, on_blocked=on_blocked, **kwargs)
        elif tool_type == "openai":
            return wrap_openai_function(tool, **kwargs)
        else:
            return GovernedCallable(
                fn=tool,
                on_blocked=on_blocked,
                on_warned=on_warned,
                raise_on_warn=raise_on_warn,
                **kwargs,
            )
