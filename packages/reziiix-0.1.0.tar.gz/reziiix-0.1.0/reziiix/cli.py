"""REZIIIX CLI — Command-line interface for the AI Governance Platform."""

from __future__ import annotations

import json
import os
import sys


def _get_client():
    """Lazy import to avoid requiring typer/rich for SDK-only usage."""
    from reziiix.client import ReziiixClient

    api_key = os.environ.get("REZIIIX_API_KEY", "")
    endpoint = os.environ.get("REZIIIX_ENDPOINT", "https://reziiix.com")

    if not api_key:
        print("Error: REZIIIX_API_KEY environment variable is required", file=sys.stderr)
        sys.exit(1)

    return ReziiixClient(api_key=api_key, endpoint=endpoint)


def _create_app():
    try:
        import typer
        from rich.console import Console
        from rich.table import Table
    except ImportError:
        print("CLI requires typer and rich. Install with: pip install reziiix[cli]", file=sys.stderr)
        sys.exit(1)

    app = typer.Typer(name="reziiix", help="REZIIIX AI Governance Platform CLI")
    console = Console()

    @app.command()
    def scan(
        text: str = typer.Argument(..., help="Text to scan for prompt injection"),
        threshold: float = typer.Option(0.5, help="Detection threshold (0-1)"),
    ):
        """Scan text for prompt injection attempts."""
        client = _get_client()
        result = client.detect_injection(text, threshold=threshold)

        if result.safe:
            console.print(f"[green]✓ CLEAN[/green] (score: {result.score})")
        else:
            console.print(f"[red]✗ {result.verdict}[/red] (score: {result.score})")
            for finding in result.findings:
                console.print(f"  → {finding.category}: {finding.severity} ({finding.weight})")

    @app.command()
    def stats():
        """Show dashboard statistics."""
        client = _get_client()
        result = client.stats()
        data = result.data

        table = Table(title="REZIIIX Governance Dashboard")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Governance Score", f"{data.governance_score}%")
        table.add_row("Active Agents", str(data.active_agents))
        table.add_row("Decisions Today", str(data.decisions_today))
        table.add_row("Allowed", str(data.decisions_breakdown.allowed))
        table.add_row("Blocked", str(data.decisions_breakdown.blocked))
        table.add_row("Warned", str(data.decisions_breakdown.warned))
        table.add_row("DLP Violations", str(data.dlp_violations))
        table.add_row("Active Policies", str(data.active_policies))

        console.print(table)

    @app.command()
    def policies():
        """List all governance policies."""
        client = _get_client()
        result = client.list_policies()

        table = Table(title="Governance Policies")
        table.add_column("ID", style="cyan")
        table.add_column("Effect", style="bold")
        table.add_column("Priority")
        table.add_column("Description")
        table.add_column("Source")

        for p in result:
            effect_style = {"FORBID": "red", "PERMIT": "green", "WARN": "yellow"}.get(p.effect, "")
            table.add_row(
                p.id,
                f"[{effect_style}]{p.effect}[/{effect_style}]" if effect_style else p.effect,
                str(p.priority),
                p.description[:60],
                p.source,
            )

        console.print(table)

    @app.command()
    def agents():
        """List all registered agents."""
        client = _get_client()
        result = client.list_agents()

        table = Table(title="Registered Agents")
        table.add_column("ID", style="cyan")
        table.add_column("Name")
        table.add_column("Actions")
        table.add_column("Blocked", style="red")
        table.add_column("Status")

        for a in result:
            table.add_row(
                a.agent_id,
                a.agent_name,
                str(a.total_actions),
                str(a.blocked),
                a.status,
            )

        console.print(table)

    @app.command()
    def costs(period: str = typer.Option("30d", help="Time period: 24h, 7d, 30d, 90d")):
        """Show token usage and cost statistics."""
        client = _get_client()
        result = client.get_costs(period=period)
        s = result.summary

        table = Table(title=f"Cost Report ({period})")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Total Tokens", f"{s.total_tokens:,}")
        table.add_row("Prompt Tokens", f"{s.total_prompt_tokens:,}")
        table.add_row("Completion Tokens", f"{s.total_completion_tokens:,}")
        table.add_row("Total Cost", f"${s.total_cost_usd:.4f}")
        table.add_row("Total Calls", f"{s.total_calls:,}")
        table.add_row("Avg Latency", f"{s.avg_latency_ms}ms")

        console.print(table)

        if result.by_model:
            model_table = Table(title="By Model")
            model_table.add_column("Model")
            model_table.add_column("Tokens")
            model_table.add_column("Cost")
            model_table.add_column("Calls")

            for m in result.by_model:
                model_table.add_row(
                    m.model,
                    f"{m.tokens:,}",
                    f"${m.cost_usd:.4f}",
                    str(m.calls),
                )

            console.print(model_table)

    @app.command()
    def compliance():
        """Generate EU AI Act compliance report."""
        client = _get_client()
        result = client.compliance_report()

        console.print(f"\n[bold]EU AI Act Compliance Report[/bold]")
        console.print(f"Overall Score: [{'green' if result.overall >= 80 else 'yellow' if result.overall >= 50 else 'red'}]{result.overall}%[/]")
        console.print()

        for cat in result.categories:
            status_color = {"compliant": "green", "partial": "yellow", "non_compliant": "red"}.get(cat.status, "white")
            console.print(f"  [{status_color}]{'●' if cat.status == 'compliant' else '◐' if cat.status == 'partial' else '○'}[/{status_color}] {cat.article}: {cat.name} — {cat.score}%")
            for rec in cat.recommendations[:2]:
                console.print(f"    → {rec}")

    @app.command()
    def simulate(
        fixtures: str = typer.Argument(..., help="Path to fixture file (JSON array or newline-separated actions)"),
        fail_on: str = typer.Option("BLOCKED", help="Exit 1 if any result matches this outcome"),
        output: str = typer.Option("table", help="Output format: table, json"),
        agent_id: str = typer.Option("ci-simulate", help="Agent ID for governance context"),
    ):
        """Simulate governance decisions for CI/CD policy-as-code.

        Run a set of test actions through the governance pipeline and check outcomes.
        Use in CI/CD to catch policy regressions before deploy.

        Examples:
            reziiix simulate tests/governance-fixtures.json
            reziiix simulate tests/fixtures.json --fail-on=BLOCKED --output=json
        """
        import pathlib

        fixture_path = pathlib.Path(fixtures)
        if not fixture_path.exists():
            console.print(f"[red]Error: {fixtures} not found[/red]")
            raise typer.Exit(1)

        raw = fixture_path.read_text()

        # Parse fixtures: JSON array or newline-separated strings
        try:
            actions = json.loads(raw)
            if isinstance(actions, dict) and "fixtures" in actions:
                actions = actions["fixtures"]
            if not isinstance(actions, list):
                actions = [actions]
        except json.JSONDecodeError:
            # Treat as newline-separated plain text actions
            actions = [line.strip() for line in raw.splitlines() if line.strip()]

        if not actions:
            console.print("[yellow]No fixtures found in file[/yellow]")
            raise typer.Exit(1)

        client = _get_client()
        results = []
        blocked_count = 0
        warned_count = 0
        allowed_count = 0
        errors = []

        for i, action_item in enumerate(actions):
            # Each item can be a string or a dict with action + expected_outcome
            if isinstance(action_item, str):
                action_text = action_item
                expected = None
            elif isinstance(action_item, dict):
                action_text = action_item.get("action", action_item.get("text", ""))
                expected = action_item.get("expected_outcome", action_item.get("expected"))
            else:
                continue

            if not action_text:
                continue

            try:
                result = client.govern(agent_id=agent_id, action=action_text)
                data = result.data if hasattr(result, "data") else result
                outcome = getattr(data, "outcome", None) or (
                    data.get("outcome") if isinstance(data, dict) else "UNKNOWN"
                )
                classification = getattr(data, "classification", None) or (
                    data.get("classification", "") if isinstance(data, dict) else ""
                )
                crypto = getattr(data, "crypto", None) or (
                    data.get("crypto") if isinstance(data, dict) else None
                )
                receipt_id = None
                if crypto:
                    receipt_id = (
                        getattr(crypto, "receiptId", None)
                        or (crypto.get("receiptId") if isinstance(crypto, dict) else None)
                    )

                entry = {
                    "index": i + 1,
                    "action": action_text[:80],
                    "outcome": outcome,
                    "classification": classification,
                    "receipt_id": receipt_id,
                    "expected": expected,
                    "match": expected is None or expected.upper() == outcome.upper() if expected else True,
                }
                results.append(entry)

                if outcome == "BLOCKED":
                    blocked_count += 1
                elif outcome == "WARNED":
                    warned_count += 1
                else:
                    allowed_count += 1

                if expected and expected.upper() != outcome.upper():
                    errors.append(f"#{i+1}: expected {expected}, got {outcome} — {action_text[:60]}")

            except Exception as e:
                results.append({
                    "index": i + 1,
                    "action": action_text[:80],
                    "outcome": "ERROR",
                    "classification": "",
                    "receipt_id": None,
                    "expected": expected,
                    "match": False,
                    "error": str(e),
                })
                errors.append(f"#{i+1}: ERROR — {e}")

        # Output results
        if output == "json":
            report = {
                "total": len(results),
                "allowed": allowed_count,
                "blocked": blocked_count,
                "warned": warned_count,
                "errors": len(errors),
                "fixtures": results,
                "pass": len(errors) == 0 and not any(
                    r["outcome"] == fail_on for r in results
                ),
            }
            console.print_json(json.dumps(report, default=str))
        else:
            table = Table(title=f"Governance Simulation ({len(results)} fixtures)")
            table.add_column("#", style="dim", width=4)
            table.add_column("Action", max_width=50)
            table.add_column("Outcome")
            table.add_column("Classification")
            table.add_column("Receipt")
            if any(r.get("expected") for r in results):
                table.add_column("Expected")
                table.add_column("Match")

            for r in results:
                outcome_style = {
                    "ALLOWED": "green", "BLOCKED": "red", "WARNED": "yellow", "ERROR": "red bold"
                }.get(r["outcome"], "")
                row = [
                    str(r["index"]),
                    r["action"],
                    f"[{outcome_style}]{r['outcome']}[/{outcome_style}]" if outcome_style else r["outcome"],
                    r["classification"],
                    (r["receipt_id"] or "—")[:12],
                ]
                if any(res.get("expected") for res in results):
                    row.append(r.get("expected") or "—")
                    match_str = "[green]✓[/green]" if r.get("match") else "[red]✗[/red]"
                    row.append(match_str)
                table.add_row(*row)

            console.print(table)
            console.print(f"\n  [green]{allowed_count} allowed[/green]  [red]{blocked_count} blocked[/red]  [yellow]{warned_count} warned[/yellow]")

        # Exit code
        has_fail_outcome = any(r["outcome"] == fail_on for r in results)
        has_mismatches = len(errors) > 0

        if has_mismatches:
            console.print(f"\n[red]✗ {len(errors)} expectation mismatches:[/red]")
            for e in errors:
                console.print(f"  {e}")
            raise typer.Exit(1)

        if has_fail_outcome:
            console.print(f"\n[red]✗ FAIL: {sum(1 for r in results if r['outcome'] == fail_on)} fixtures returned {fail_on}[/red]")
            raise typer.Exit(1)

        console.print(f"\n[green]✓ PASS: All {len(results)} fixtures passed[/green]")

    @app.command()
    def validate(
        config: str = typer.Argument("reziiix.yaml", help="Path to policy YAML config"),
    ):
        """Validate policy YAML without connecting to API."""
        import yaml as _yaml

        try:
            with open(config) as f:
                data = _yaml.safe_load(f)
        except FileNotFoundError:
            console.print(f"[red]Error: {config} not found[/red]")
            raise typer.Exit(1)
        except Exception as e:
            console.print(f"[red]Error parsing YAML: {e}[/red]")
            raise typer.Exit(1)

        if not isinstance(data, dict) or "policies" not in data:
            console.print("[red]Error: YAML must contain a 'policies' key[/red]")
            raise typer.Exit(1)

        errors = []
        for i, p in enumerate(data["policies"]):
            if not p.get("name"):
                errors.append(f"Policy #{i+1}: missing 'name'")
            if p.get("effect") not in ("FORBID", "PERMIT", "WARN"):
                errors.append(f"Policy '{p.get('name', f'#{i+1}')}': effect must be FORBID, PERMIT, or WARN")
            if "priority" in p and not isinstance(p["priority"], int):
                errors.append(f"Policy '{p.get('name', f'#{i+1}')}': priority must be integer")

        if errors:
            console.print(f"[red]Validation failed ({len(errors)} errors):[/red]")
            for e in errors:
                console.print(f"  [red]✗[/red] {e}")
            raise typer.Exit(1)

        console.print(f"[green]✓ Valid[/green] — {len(data['policies'])} policies in {config}")

    @app.command()
    def plan(
        config: str = typer.Argument("reziiix.yaml", help="Path to policy YAML config"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Show plan without connecting to API"),
    ):
        """Show what policy changes would be made (Terraform-style plan)."""
        import yaml as _yaml

        try:
            with open(config) as f:
                data = _yaml.safe_load(f)
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)

        local_policies = {p["name"]: p for p in data.get("policies", [])}

        console.print("\n[bold]REZIIIX Governance Plan[/bold]")
        console.print("───────────────────────")

        if dry_run:
            for name, p in local_policies.items():
                console.print(f"  [green]+[/green] CREATE  {name:<30} ({p['effect']}, priority {p.get('priority', 50)})")
            console.print(f"\n  Plan: {len(local_policies)} to create (dry-run, no API connection)")
            return

        client = _get_client()
        remote = {p.id: p for p in client.list_policies()}

        creates, updates, deletes = [], [], []
        for name, p in local_policies.items():
            pid = p.get("id", name)
            if pid in remote:
                updates.append((pid, p, remote[pid]))
            else:
                creates.append((pid, p))

        for pid, rp in remote.items():
            if rp.source == "builtin":
                continue
            if pid not in local_policies and pid not in {p.get("id", n) for n, p in local_policies.items()}:
                deletes.append((pid, rp))

        for pid, p in creates:
            console.print(f"  [green]+[/green] CREATE  {pid:<30} ({p['effect']}, priority {p.get('priority', 50)})")
        for pid, local, remote_p in updates:
            changes = []
            if local.get("effect") != remote_p.effect:
                changes.append(f"effect: {remote_p.effect} → {local['effect']}")
            if local.get("priority", 50) != remote_p.priority:
                changes.append(f"priority: {remote_p.priority} → {local.get('priority', 50)}")
            if changes:
                console.print(f"  [yellow]~[/yellow] UPDATE  {pid:<30} ({', '.join(changes)})")
        for pid, rp in deletes:
            console.print(f"  [red]-[/red] DELETE  {pid:<30} (was {rp.effect})")

        total = len(creates) + len([u for u in updates if u]) + len(deletes)
        console.print(f"\n  Plan: {len(creates)} to create, {len(updates)} to update, {len(deletes)} to delete")
        if total == 0:
            console.print("  [green]Infrastructure is up to date.[/green]")

    @app.command()
    def apply(
        config: str = typer.Argument("reziiix.yaml", help="Path to policy YAML config"),
        auto_approve: bool = typer.Option(False, "--auto-approve", help="Skip confirmation"),
    ):
        """Apply policy changes from YAML config (Terraform-style apply)."""
        import yaml as _yaml

        try:
            with open(config) as f:
                data = _yaml.safe_load(f)
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)

        local_policies = data.get("policies", [])
        client = _get_client()
        remote = {p.id: p for p in client.list_policies()}

        creates, updates = [], []
        for p in local_policies:
            pid = p.get("id", p["name"])
            if pid in remote:
                updates.append((pid, p))
            else:
                creates.append((pid, p))

        if not creates and not updates:
            console.print("[green]Nothing to apply — policies are up to date.[/green]")
            return

        console.print(f"\n[bold]Apply: {len(creates)} create, {len(updates)} update[/bold]")

        if not auto_approve:
            confirm = typer.confirm("Do you want to apply these changes?")
            if not confirm:
                console.print("[yellow]Cancelled.[/yellow]")
                raise typer.Exit(0)

        for pid, p in creates:
            try:
                client._request("POST", "/api/policies", json={
                    "id": pid, "effect": p["effect"], "priority": p.get("priority", 50),
                    "description": p.get("description", ""), "active": p.get("active", True),
                    "conditions": p.get("conditions", []),
                })
                console.print(f"  [green]✓[/green] Created {pid}")
            except Exception as e:
                console.print(f"  [red]✗[/red] Failed to create {pid}: {e}")

        for pid, p in updates:
            try:
                client._request("PUT", f"/api/policies/{pid}", json={
                    "effect": p["effect"], "priority": p.get("priority", 50),
                    "description": p.get("description", ""), "active": p.get("active", True),
                    "conditions": p.get("conditions", []),
                })
                console.print(f"  [green]✓[/green] Updated {pid}")
            except Exception as e:
                console.print(f"  [red]✗[/red] Failed to update {pid}: {e}")

        console.print("\n[green]Apply complete.[/green]")

    return app


# Lazy app creation
app = _create_app() if "typer" in sys.modules or "--help" in sys.argv or len(sys.argv) > 1 else None

if app is None:
    # Fallback for when typer is not installed
    def app():
        print("CLI requires typer and rich. Install with: pip install reziiix[cli]", file=sys.stderr)
        sys.exit(1)
