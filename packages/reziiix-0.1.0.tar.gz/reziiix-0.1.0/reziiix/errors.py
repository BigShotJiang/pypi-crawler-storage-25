"""REZIIIX SDK error classes."""


class ReziiixError(Exception):
    """Base error for all REZIIIX SDK errors."""

    def __init__(self, message: str, code: str = "UNKNOWN", status: int | None = None):
        super().__init__(message)
        self.code = code
        self.status = status


class ReziiixAuthError(ReziiixError):
    """Raised when the API key is invalid, expired, or revoked."""

    def __init__(self, message: str = "Authentication failed — check your API key"):
        super().__init__(message, code="AUTH_ERROR", status=401)


class ReziiixApiError(ReziiixError):
    """Raised when the API returns a non-OK response."""

    def __init__(self, message: str, status: int = 500):
        super().__init__(message, code="API_ERROR", status=status)


class ReziiixValidationError(ReziiixError):
    """Raised when request parameters fail client-side validation."""

    def __init__(self, message: str):
        super().__init__(message, code="VALIDATION_ERROR", status=400)


class ReziiixTimeoutError(ReziiixError):
    """Raised when a request exceeds the configured timeout."""

    def __init__(self, timeout_seconds: float):
        super().__init__(
            f"Request timed out after {timeout_seconds}s",
            code="TIMEOUT_ERROR",
            status=408,
        )
        self.timeout_seconds = timeout_seconds


class ReziiixToolBlockedError(ReziiixError):
    """Raised when a tool call is blocked by governance policy.

    Returns a clear, structured message so AI agents understand why a tool
    was blocked — not a generic crash.
    """

    def __init__(
        self,
        tool_name: str,
        outcome: str = "BLOCKED",
        classification: str = "",
        violations: list[dict] | None = None,
        receipt_id: str | None = None,
    ):
        self.tool_name = tool_name
        self.outcome = outcome
        self.classification = classification
        self.violations = violations or []
        self.receipt_id = receipt_id
        reasons = (
            "; ".join(
                v.get("type", v.get("reason", "policy violation"))
                for v in self.violations
            )
            if self.violations
            else "policy violation"
        )
        message = (
            f"Tool '{tool_name}' blocked by REZIIIX governance. "
            f"Classification: {classification}. Reason: {reasons}. "
            f"Receipt: {receipt_id}"
        )
        super().__init__(message, code="TOOL_BLOCKED", status=403)
