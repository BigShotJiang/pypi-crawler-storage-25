"""FastMCP 2.0 resource implementations.

This module provides Docker resources using FastMCP's @mcp.resource() decorator:
- container://logs/{container_id} - Container logs
- container://stats/{container_id} - Container resource statistics
"""

import asyncio
from typing import Any

from docker.errors import APIError, NotFound

from mcp_docker.docker.client import DockerClientWrapper
from mcp_docker.utils.errors import ContainerNotFound, MCPDockerError
from mcp_docker.utils.logger import get_logger
from mcp_docker.utils.messages import ERROR_CONTAINER_NOT_FOUND
from mcp_docker.utils.stats_formatter import (
    calculate_cpu_usage,
    calculate_memory_usage,
    format_network_stats,
)

logger = get_logger(__name__)


def _decode_docker_logs(logs: bytes | Any) -> str:
    """Decode Docker logs to string.

    Args:
        logs: Docker logs (bytes or generator)

    Returns:
        Decoded log text
    """
    if isinstance(logs, bytes):
        return logs.decode("utf-8", errors="replace")

    # Handle generator case
    log_text = ""
    for line in logs:
        if isinstance(line, bytes):
            log_text += line.decode("utf-8", errors="replace")
        else:
            log_text += str(line)
    return log_text


def create_container_logs_resource(
    docker_client: DockerClientWrapper,
) -> tuple[str, Any]:
    """Create the container logs FastMCP resource.

    Args:
        docker_client: Docker client wrapper

    Returns:
        Tuple of (uri_template, async_function)
    """
    # Hardcoded tail limit prevents Docker from streaming unlimited logs into memory.
    # This is a pre-fetch safety limit, not output truncation — the ResponseLimitingMiddleware
    # handles response size enforcement globally.
    resource_log_tail: int = 1000

    async def get_container_logs(container_id: str) -> str:
        """Get logs from a Docker container.

        Args:
            container_id: Container ID or name

        Returns:
            Container logs as text

        Raises:
            ContainerNotFound: If container doesn't exist
            MCPDockerError: If logs cannot be retrieved
        """
        try:

            def _fetch_logs() -> str:
                container = docker_client.client.containers.get(container_id)
                logs = container.logs(tail=resource_log_tail, follow=False)
                return _decode_docker_logs(logs)

            log_text = await asyncio.to_thread(_fetch_logs)

            logger.debug(f"Retrieved logs for container {container_id} (tail={resource_log_tail})")
            return log_text

        except NotFound as e:
            # SECURITY: Use proper Docker SDK exception instead of string matching
            error_msg = ERROR_CONTAINER_NOT_FOUND.format(container_id)
            raise ContainerNotFound(error_msg) from e
        except APIError as e:
            logger.error(f"Docker API error getting logs for container {container_id}: {e}")
            raise MCPDockerError(f"Failed to get container logs: {e}") from e
        except Exception as e:
            logger.error(f"Unexpected error getting logs for container {container_id}: {e}")
            raise MCPDockerError(f"Failed to get container logs: {e}") from e

    return ("container://logs/{container_id}", get_container_logs)


def create_container_stats_resource(
    docker_client: DockerClientWrapper,
) -> tuple[str, Any]:
    """Create the container stats FastMCP resource.

    Args:
        docker_client: Docker client wrapper

    Returns:
        Tuple of (uri_template, async_function)
    """

    async def get_container_stats(container_id: str) -> str:
        """Get resource usage statistics for a Docker container.

        Args:
            container_id: Container ID or name

        Returns:
            Container statistics as formatted text

        Raises:
            ContainerNotFound: If container doesn't exist
            MCPDockerError: If stats cannot be retrieved
        """
        try:
            # Offload blocking Docker I/O to thread pool
            def _fetch_stats() -> dict[str, Any]:
                container = docker_client.client.containers.get(container_id)
                # Get stats (stream=False for single snapshot)
                stats_data = container.stats(stream=False)
                # Handle union type - stream=False returns dict directly
                if isinstance(stats_data, dict):
                    return stats_data
                return next(iter(stats_data))

            stats = await asyncio.to_thread(_fetch_stats)

            # Format stats as readable text using stats formatter utilities
            cpu_info = calculate_cpu_usage(stats)
            memory_info = calculate_memory_usage(stats)
            network_text = format_network_stats(stats)

            stats_text = f"""Container Statistics for {container_id}
==========================================

CPU:
  Online CPUs: {cpu_info["online_cpus"]}
  Total Usage: {cpu_info["total_usage"]}
  System Usage: {cpu_info["system_usage"]}

Memory:
  Usage: {memory_info["usage_mb"]:.2f} MB
  Limit: {memory_info["limit_mb"]:.2f} MB
  Percentage: {memory_info["percent"]:.2f}%

Network:{network_text}

Block I/O:
  {stats.get("blkio_stats", "No block I/O stats available")}
"""

            logger.debug(f"Retrieved stats for container {container_id}")
            return stats_text

        except NotFound as e:
            # SECURITY: Use proper Docker SDK exception instead of string matching
            error_msg = ERROR_CONTAINER_NOT_FOUND.format(container_id)
            raise ContainerNotFound(error_msg) from e
        except APIError as e:
            logger.error(f"Docker API error getting stats for container {container_id}: {e}")
            raise MCPDockerError(f"Failed to get container stats: {e}") from e
        except Exception as e:
            logger.error(f"Unexpected error getting stats for container {container_id}: {e}")
            raise MCPDockerError(f"Failed to get container stats: {e}") from e

    return ("container://stats/{container_id}", get_container_stats)


def register_all_resources(
    app: Any,
    docker_client: DockerClientWrapper,
    allowed_resources: list[str] | None = None,
) -> dict[str, list[str]]:
    """Register all Docker resources with FastMCP.

    Args:
        app: FastMCP application instance
        docker_client: Docker client wrapper
        allowed_resources: Optional list of allowed resource names (None = allow all)

    Returns:
        Dictionary mapping category names to lists of registered resource URIs
    """
    logger.info("Registering FastMCP resources...")

    registered: dict[str, list[str]] = {"container": []}

    # Define all available resources with their names
    all_resources = [
        ("container_logs", create_container_logs_resource(docker_client)),
        ("container_stats", create_container_stats_resource(docker_client)),
    ]

    for resource_name, (uri, func) in all_resources:
        # Filter based on allowed_resources if specified
        # None (not set) = allow all, [] (empty string) = block all, ['foo'] = allow only foo
        if allowed_resources is not None and resource_name not in allowed_resources:
            logger.debug(f"Skipping resource (not in allowed list): {resource_name}")
            continue

        app.resource(uri)(func)
        registered["container"].append(uri)
        logger.debug(f"Registered resource: {uri}")

    total_resources = sum(len(resources) for resources in registered.values())
    logger.info(f"Successfully registered {total_resources} FastMCP resources")

    return registered
