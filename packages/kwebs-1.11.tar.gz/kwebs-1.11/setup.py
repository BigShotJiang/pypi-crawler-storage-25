
# 打包上传 python setup.py sdist upload
# 安装 python setup.py install
import os,sys
from setuptools import setup
from kwebs import kwebsinfo
confkcws={}
confkcws['name']=kwebsinfo['name']                             #项目的名称 
confkcws['version']=kwebsinfo['version']							#项目版本
confkcws['description']=kwebsinfo['description']       #项目的简单描述
confkcws['long_description']=kwebsinfo['long_description']     #项目详细描述
confkcws['license']=kwebsinfo['license']                    #开源协议   mit开源
confkcws['url']=kwebsinfo['url']
confkcws['author']=kwebsinfo['author']  					 #名字
confkcws['author_email']=kwebsinfo['author_email'] 	     #邮件地址
confkcws['maintainer']=kwebsinfo['maintainer'] 						 #维护人员的名字
confkcws['maintainer_email']=kwebsinfo['maintainer_email']    #维护人员的邮件地址
def get_file(folder='./',lists=[]):
    lis=os.listdir(folder)
    for files in lis:
        if not os.path.isfile(folder+"/"+files):
            if files=='__pycache__' or files=='.git':
                pass
            else:
                lists.append(folder+"/"+files)
                get_file(folder+"/"+files,lists)
        else:
            pass
    return lists
def start():
    b=get_file("kwebs",['kwebs'])
    setup(
        name = confkcws["name"],
        version = confkcws["version"],
        keywords = "kwebs"+confkcws['version'],
        description = confkcws["description"],
        long_description = confkcws["long_description"],
        license = confkcws["license"],
        author = confkcws["author"],
        author_email = confkcws["author_email"],
        maintainer = confkcws["maintainer"],
        maintainer_email = confkcws["maintainer_email"],
        url=confkcws['url'],
        packages =  b,
        
        install_requires = ['kunapi>=1.7','kmysql>=1.4','ksqlite>=1.1','khttp>=1.2','python-dateutil==2.9.0',
                            'pymongo==3.10.0','Mako==1.3.6','six>=1.12.0',
                            # 'websockets==10.4',
                            'curl_cffi==0.9.0',
                            'websockets>=8.1,<=13.1',
                            # 'websockets==8.1',
                            ], #第三方包
        package_data = {
            '': ['*.html', '*.js','*.css','*.jpg','*.png','*.gif'],
        },
        entry_points = {
            'console_scripts':[
                'kwebs = kwebs.kwebs:cill_start'
            ]
        }
    )
start()