"""LLM plugin that provides PostgreSQL pgvector storage for embeddings."""

import click
import json
import llm
import sqlite_utils
import sys
import time


@llm.hookimpl
def register_commands(cli):
    @cli.group()
    def pgvector():
        "Store and search embeddings using PostgreSQL pgvector"
        pass

    @pgvector.command()
    @click.option(
        "--db",
        envvar="LLM_PGVECTOR_URL",
        required=True,
        help="PostgreSQL connection URL",
    )
    def setup(db):
        "Initialize pgvector extension and tables"
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(db) as store:
            store.setup()
            click.echo("pgvector schema initialized successfully.")

    @pgvector.command()
    @click.argument("collection")
    @click.option("--db", envvar="LLM_PGVECTOR_URL", required=True)
    @click.option(
        "-d",
        "--database",
        "sqlite_db",
        type=click.Path(exists=True),
        help="Path to LLM embeddings SQLite database (default: llm's default)",
    )
    def sync(collection, db, sqlite_db):
        "Sync a collection from LLM's SQLite to pgvector"
        from llm_pgvector.store import PgVectorStore, decode_llm_embedding

        # Get SQLite database path
        if sqlite_db is None:
            sqlite_db = str(llm.user_dir() / "embeddings.db")

        sqlite_db_obj = sqlite_utils.Database(sqlite_db)

        # Find collection in SQLite
        try:
            coll_row = list(
                sqlite_db_obj["collections"].rows_where("name = ?", [collection])
            )[0]
        except (IndexError, sqlite_utils.db.sqlite3.OperationalError):
            click.echo(
                f"Error: Collection '{collection}' not found in SQLite database.",
                err=True,
            )
            sys.exit(1)

        model_id = coll_row["model"]
        coll_id_sqlite = coll_row["id"]

        # Count embeddings
        total = sqlite_db_obj.execute(
            "SELECT COUNT(*) FROM embeddings WHERE collection_id = ?",
            [coll_id_sqlite],
        ).fetchone()[0]

        if total == 0:
            click.echo(f"Collection '{collection}' is empty.")
            return

        click.echo(
            f"Syncing collection '{collection}' ({total} embeddings, model: {model_id})"
        )

        with PgVectorStore(db) as store:
            store.setup()

            # Get first embedding to determine dimension
            first_row = sqlite_db_obj.execute(
                "SELECT embedding FROM embeddings WHERE collection_id = ? LIMIT 1",
                [coll_id_sqlite],
            ).fetchone()
            dimension = len(decode_llm_embedding(first_row[0]))

            pg_coll_id = store.get_or_create_collection(
                collection, model_id, dimension
            )

            # Incremental sync: get existing hashes from pgvector
            existing_hashes = store.get_existing_hashes(pg_coll_id)

            # Read and sync in batches, skipping unchanged embeddings
            batch = []
            synced = 0
            new_count = 0
            updated_count = 0
            unchanged_count = 0
            start_time = time.time()

            for row in sqlite_db_obj.execute(
                "SELECT id, embedding, content, content_hash, metadata "
                "FROM embeddings WHERE collection_id = ?",
                [coll_id_sqlite],
            ).fetchall():
                entry_id, emb_binary, content, content_hash, metadata = row

                # Check if embedding already exists with same hash
                pg_hash = existing_hashes.get(entry_id)
                if pg_hash is not None and pg_hash == content_hash:
                    unchanged_count += 1
                    continue

                if pg_hash is None:
                    new_count += 1
                else:
                    updated_count += 1

                embedding = decode_llm_embedding(emb_binary)
                meta = json.loads(metadata) if metadata else None

                batch.append(
                    {
                        "id": entry_id,
                        "embedding": embedding,
                        "content": content,
                        "metadata": meta,
                        "content_hash": content_hash,
                    }
                )

                if len(batch) >= 500:
                    store.bulk_upsert(pg_coll_id, batch)
                    synced += len(batch)
                    click.echo(f"  Synced {synced}/{new_count + updated_count} embeddings...")
                    batch = []

            if batch:
                store.bulk_upsert(pg_coll_id, batch)
                synced += len(batch)

            elapsed = time.time() - start_time
            click.echo(
                f"  {new_count} new, {updated_count} updated, "
                f"{unchanged_count} unchanged, total {total}"
            )
            click.echo(f"  Synced {synced} embeddings in {elapsed:.1f}s")

            # Create index if we synced anything
            if synced > 0:
                click.echo("  Creating HNSW index...")
                store.create_index(pg_coll_id)
            click.echo(f"Done. Collection '{collection}' is ready for search.")

    @pgvector.command()
    @click.argument("collection")
    @click.argument("query")
    @click.option("--db", envvar="LLM_PGVECTOR_URL", required=True)
    @click.option("-n", "--number", default=10, help="Number of results")
    @click.option(
        "-m",
        "--metric",
        default="cosine",
        type=click.Choice(["cosine", "l2", "ip"]),
    )
    @click.option("--ef-search", type=int, help="HNSW ef_search parameter")
    @click.option("--metadata", "metadata_filter", help="JSON metadata filter")
    def similar(collection, query, db, number, metric, ef_search, metadata_filter):
        "Search for similar items in a pgvector collection"
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(db) as store:
            # Look up collection to get model
            row = store.conn.execute(
                "SELECT id, model FROM llm_collections WHERE name = %s",
                (collection,),
            ).fetchone()
            if not row:
                click.echo(
                    f"Error: Collection '{collection}' not found.", err=True
                )
                sys.exit(1)

            pg_coll_id, model_id = row

            # Get embedding model and embed the query
            model = llm.get_embedding_model(model_id)
            query_vector = list(model.embed(query))

            # Parse metadata filter
            meta = json.loads(metadata_filter) if metadata_filter else None

            # Search
            results = store.search(
                pg_coll_id,
                query_vector,
                n=number,
                metric=metric,
                ef_search=ef_search,
                metadata_filter=meta,
            )

            # Output results as JSON
            click.echo(json.dumps(results, indent=2, ensure_ascii=False))

    @pgvector.command(name="list")
    @click.option("--db", envvar="LLM_PGVECTOR_URL", required=True)
    def list_collections(db):
        "List all collections in pgvector"
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(db) as store:
            collections = store.list_collections()
            if not collections:
                click.echo("No collections found.")
                return
            # Print as table
            click.echo(
                f"{'Name':<30} {'Model':<30} {'Count':>8} {'Dimension':>10}"
            )
            click.echo("-" * 82)
            for c in collections:
                click.echo(
                    f"{c['name']:<30} {c['model']:<30} "
                    f"{c['count']:>8} {str(c['dimension'] or '?'):>10}"
                )

    @pgvector.command()
    @click.argument("collection")
    @click.option("--db", envvar="LLM_PGVECTOR_URL", required=True)
    @click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
    def delete(collection, db, yes):
        "Delete a collection from pgvector"
        if not yes:
            click.confirm(
                f"Delete collection '{collection}' and all its embeddings?",
                abort=True,
            )

        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(db) as store:
            store.delete_collection(collection)
            click.echo(f"Collection '{collection}' deleted.")

    @pgvector.command(name="create-index")
    @click.argument("collection")
    @click.option("--db", envvar="LLM_PGVECTOR_URL", required=True)
    @click.option(
        "--type",
        "index_type",
        default="hnsw",
        type=click.Choice(["hnsw", "ivfflat"]),
    )
    @click.option(
        "--metric",
        default="cosine",
        type=click.Choice(["cosine", "l2", "ip"]),
    )
    @click.option("--m", "m_param", default=16, type=int, help="HNSW m parameter")
    @click.option("--ef-construction", default=64, type=int)
    @click.option("--lists", type=int, help="IVFFlat lists parameter")
    def create_index(collection, db, index_type, metric, m_param, ef_construction, lists):
        "Create or rebuild a vector index"
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(db) as store:
            row = store.conn.execute(
                "SELECT id FROM llm_collections WHERE name = %s",
                (collection,),
            ).fetchone()
            if not row:
                click.echo(
                    f"Error: Collection '{collection}' not found.", err=True
                )
                sys.exit(1)

            click.echo(
                f"Creating {index_type} index ({metric}) for '{collection}'..."
            )
            store.create_index(
                row[0],
                index_type=index_type,
                metric=metric,
                m=m_param,
                ef_construction=ef_construction,
                lists=lists,
            )
            click.echo("Index created successfully.")

    @pgvector.command()
    @click.argument("collection")
    @click.option("--db", envvar="LLM_PGVECTOR_URL", required=True)
    def status(collection, db):
        "Show detailed status of a pgvector collection"
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(db) as store:
            info = store.collection_status(collection)
            if not info:
                click.echo(f"Error: Collection '{collection}' not found.", err=True)
                sys.exit(1)

            click.echo(f"Collection: {info['name']}")
            click.echo(f"Model:      {info['model']}")
            click.echo(f"Dimension:  {info['dimension'] or 'variable'}")
            click.echo(f"Embeddings: {info['count']}")
            click.echo(f"Size:       {info['embedding_size']}")
            click.echo(f"Created:    {info['created_at']}")
            if info['indexes']:
                click.echo(f"\nIndexes ({len(info['indexes'])}):")
                for idx in info['indexes']:
                    click.echo(f"  - {idx['name']}")
            else:
                click.echo("\nNo indexes (run 'llm pgvector create-index' to create one)")
