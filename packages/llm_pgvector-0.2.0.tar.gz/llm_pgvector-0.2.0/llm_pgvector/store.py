"""PostgreSQL pgvector storage backend for LLM embeddings."""

import json
import struct
from typing import Optional

import numpy as np
import psycopg
from pgvector.psycopg import register_vector


def decode_llm_embedding(binary: bytes) -> list[float]:
    """Decode LLM's little-endian float32 binary format to list of floats."""
    return list(struct.unpack("<" + "f" * (len(binary) // 4), binary))


def encode_llm_embedding(values: list[float]) -> bytes:
    """Encode list of floats to LLM's little-endian float32 binary format."""
    return struct.pack("<" + "f" * len(values), *values)


class PgVectorStore:
    """Manages embedding storage and similarity search in PostgreSQL with pgvector."""

    def __init__(self, db_url: str):
        self.db_url = db_url
        self._conn = None
        self._vector_registered = False

    @property
    def conn(self):
        """Lazy connection with pgvector type registration."""
        if self._conn is None or self._conn.closed:
            self._conn = psycopg.connect(self.db_url, autocommit=True)
            try:
                register_vector(self._conn)
                self._vector_registered = True
            except psycopg.ProgrammingError:
                # Extension not yet installed; setup() will register after CREATE EXTENSION
                pass
        return self._conn

    def close(self):
        """Close the database connection."""
        if self._conn and not self._conn.closed:
            self._conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def setup(self):
        """Initialize pgvector extension and create tables."""
        self.conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
        # Now that the extension exists, register vector types
        if not self._vector_registered:
            register_vector(self.conn)
            self._vector_registered = True
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS llm_collections (
                id SERIAL PRIMARY KEY,
                name TEXT UNIQUE NOT NULL,
                model TEXT NOT NULL,
                dimension INTEGER,
                created_at TIMESTAMPTZ DEFAULT NOW()
            )
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS llm_embeddings (
                collection_id INTEGER REFERENCES llm_collections(id) ON DELETE CASCADE,
                id TEXT NOT NULL,
                embedding vector,
                content TEXT,
                content_hash BYTEA,
                metadata JSONB,
                updated TIMESTAMPTZ DEFAULT NOW(),
                PRIMARY KEY (collection_id, id)
            )
        """)

    def get_or_create_collection(
        self, name: str, model: str, dimension: Optional[int] = None
    ) -> int:
        """Get existing collection ID or create new one. Returns collection_id."""
        row = self.conn.execute(
            "SELECT id FROM llm_collections WHERE name = %s", (name,)
        ).fetchone()
        if row:
            return row[0]
        row = self.conn.execute(
            "INSERT INTO llm_collections (name, model, dimension) "
            "VALUES (%s, %s, %s) RETURNING id",
            (name, model, dimension),
        ).fetchone()
        return row[0]

    def upsert_embedding(
        self,
        collection_id: int,
        entry_id: str,
        embedding: list[float],
        content: Optional[str] = None,
        metadata: Optional[dict] = None,
        content_hash: Optional[bytes] = None,
    ):
        """Insert or update a single embedding."""
        vec = np.array(embedding, dtype=np.float32)
        meta_json = json.dumps(metadata) if metadata else None
        self.conn.execute(
            """
            INSERT INTO llm_embeddings
                (collection_id, id, embedding, content, content_hash, metadata, updated)
            VALUES (%s, %s, %s, %s, %s, %s::jsonb, NOW())
            ON CONFLICT (collection_id, id) DO UPDATE SET
                embedding = EXCLUDED.embedding,
                content = EXCLUDED.content,
                content_hash = EXCLUDED.content_hash,
                metadata = EXCLUDED.metadata,
                updated = NOW()
            """,
            (collection_id, entry_id, vec, content, content_hash, meta_json),
        )

    def bulk_upsert(
        self, collection_id: int, embeddings: list[dict], batch_size: int = 500
    ):
        """Bulk upsert embeddings using batched INSERT ... ON CONFLICT.

        Each dict must have 'id' and 'embedding' keys, and may include
        'content', 'metadata', and 'content_hash'.
        """
        for i in range(0, len(embeddings), batch_size):
            batch = embeddings[i : i + batch_size]
            with self.conn.transaction():
                for item in batch:
                    self.upsert_embedding(
                        collection_id=collection_id,
                        entry_id=item["id"],
                        embedding=item["embedding"],
                        content=item.get("content"),
                        metadata=item.get("metadata"),
                        content_hash=item.get("content_hash"),
                    )

    def create_index(
        self,
        collection_id: int,
        index_type: str = "hnsw",
        metric: str = "cosine",
        m: int = 16,
        ef_construction: int = 64,
        lists: Optional[int] = None,
    ):
        """Create a vector index on embeddings for a specific collection.

        Args:
            collection_id: Target collection.
            index_type: 'hnsw' or 'ivfflat'.
            metric: 'cosine', 'l2', or 'ip'.
            m: HNSW max connections per node.
            ef_construction: HNSW build-time search breadth.
            lists: IVFFlat number of clusters (auto-calculated if None).
        """
        opclass = {
            "cosine": "vector_cosine_ops",
            "l2": "vector_l2_ops",
            "ip": "vector_ip_ops",
        }[metric]

        # Verify embeddings exist and get dimension
        row = self.conn.execute(
            "SELECT vector_dims(embedding) FROM llm_embeddings "
            "WHERE collection_id = %s LIMIT 1",
            (collection_id,),
        ).fetchone()
        if not row:
            raise ValueError(
                "No embeddings found in collection -- cannot create index"
            )
        dimension = row[0]

        # pgvector requires fixed dimensions on the column to build an index.
        # Cast the column to vector(N) if it doesn't already have dimensions.
        try:
            self.conn.execute(
                f"ALTER TABLE llm_embeddings "
                f"ALTER COLUMN embedding SET DATA TYPE vector({dimension})"
            )
        except psycopg.errors.UndefinedObject:
            pass  # column already has the correct type

        index_name = f"idx_llm_emb_{collection_id}_{index_type}_{metric}"

        if index_type == "hnsw":
            self.conn.execute(
                f"CREATE INDEX IF NOT EXISTS {index_name} "
                f"ON llm_embeddings USING hnsw (embedding {opclass}) "
                f"WITH (m = {m}, ef_construction = {ef_construction}) "
                f"WHERE collection_id = {collection_id}"
            )
        elif index_type == "ivfflat":
            if lists is None:
                count = self.conn.execute(
                    "SELECT COUNT(*) FROM llm_embeddings WHERE collection_id = %s",
                    (collection_id,),
                ).fetchone()[0]
                lists = max(1, int(count**0.5))
            self.conn.execute(
                f"CREATE INDEX IF NOT EXISTS {index_name} "
                f"ON llm_embeddings USING ivfflat (embedding {opclass}) "
                f"WITH (lists = {lists}) "
                f"WHERE collection_id = {collection_id}"
            )
        else:
            raise ValueError(f"Unknown index_type: {index_type!r}")

    def search(
        self,
        collection_id: int,
        query_vector: list[float],
        n: int = 10,
        metric: str = "cosine",
        metadata_filter: Optional[dict] = None,
        ef_search: Optional[int] = None,
    ) -> list[dict]:
        """Search for similar embeddings using pgvector ANN.

        Args:
            collection_id: Collection to search in.
            query_vector: The query embedding.
            n: Number of results to return.
            metric: Distance metric ('cosine', 'l2', or 'ip').
            metadata_filter: Optional JSONB containment filter.
            ef_search: Optional HNSW ef_search parameter override.

        Returns:
            List of dicts with 'id', 'content', 'metadata', and 'score'
            (similarity -- higher is better).
        """
        vec = np.array(query_vector, dtype=np.float32)
        operator = {"cosine": "<=>", "l2": "<->", "ip": "<#>"}[metric]

        if ef_search:
            self.conn.execute(f"SET hnsw.ef_search = {ef_search}")

        conditions = ["collection_id = %(cid)s"]
        params: dict = {"cid": collection_id, "vec": vec, "n": n}

        if metadata_filter:
            conditions.append("metadata @> %(meta)s::jsonb")
            params["meta"] = json.dumps(metadata_filter)

        where = " AND ".join(conditions)

        rows = self.conn.execute(
            f"SELECT id, content, metadata, "
            f"       1 - (embedding {operator} %(vec)s) AS score "
            f"FROM llm_embeddings "
            f"WHERE {where} "
            f"ORDER BY embedding {operator} %(vec)s "
            f"LIMIT %(n)s",
            params,
        ).fetchall()

        return [
            {
                "id": row[0],
                "content": row[1],
                "metadata": row[2],
                "score": float(row[3]),
            }
            for row in rows
        ]

    def list_collections(self) -> list[dict]:
        """List all collections with their embedding counts."""
        rows = self.conn.execute("""
            SELECT c.name, c.model, c.dimension, c.created_at,
                   COUNT(e.id) AS count
            FROM llm_collections c
            LEFT JOIN llm_embeddings e ON c.id = e.collection_id
            GROUP BY c.id
            ORDER BY c.name
        """).fetchall()
        return [
            {
                "name": r[0],
                "model": r[1],
                "dimension": r[2],
                "created_at": str(r[3]),
                "count": r[4],
            }
            for r in rows
        ]

    def delete_collection(self, name: str):
        """Delete a collection and all its embeddings (via CASCADE)."""
        self.conn.execute(
            "DELETE FROM llm_collections WHERE name = %s", (name,)
        )

    def count(self, collection_id: int) -> int:
        """Count embeddings in a collection."""
        row = self.conn.execute(
            "SELECT COUNT(*) FROM llm_embeddings WHERE collection_id = %s",
            (collection_id,),
        ).fetchone()
        return row[0]

    def get_existing_hashes(self, collection_id: int) -> dict[str, bytes]:
        """Return {entry_id: content_hash} for all embeddings in collection."""
        rows = self.conn.execute(
            "SELECT id, content_hash FROM llm_embeddings WHERE collection_id = %s",
            (collection_id,),
        ).fetchall()
        return {r[0]: r[1] for r in rows}

    def collection_status(self, name: str) -> dict:
        """Get detailed status of a collection including index info."""
        row = self.conn.execute(
            "SELECT id, name, model, dimension, created_at FROM llm_collections WHERE name = %s",
            (name,),
        ).fetchone()
        if not row:
            return None

        cid = row[0]
        count = self.count(cid)

        # Check indexes
        indexes = self.conn.execute(
            "SELECT indexname, indexdef FROM pg_indexes "
            "WHERE tablename = 'llm_embeddings' AND indexdef LIKE %s",
            (f"%collection_id = {cid}%",),
        ).fetchall()

        # Storage size
        size_row = self.conn.execute(
            "SELECT pg_size_pretty(sum(pg_column_size(embedding))) FROM llm_embeddings WHERE collection_id = %s",
            (cid,),
        ).fetchone()

        return {
            "name": row[1],
            "model": row[2],
            "dimension": row[3],
            "created_at": str(row[4]),
            "count": count,
            "indexes": [{"name": idx[0], "definition": idx[1]} for idx in indexes],
            "embedding_size": size_row[0] if size_row and size_row[0] else "0 bytes",
        }
