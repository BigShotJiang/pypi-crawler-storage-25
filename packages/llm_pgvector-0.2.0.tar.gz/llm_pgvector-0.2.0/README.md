# llm-pgvector

[![PyPI](https://img.shields.io/pypi/v/llm-pgvector.svg)](https://pypi.org/project/llm-pgvector/)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](https://github.com/xr843/llm-pgvector/blob/main/LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/xr843/llm-pgvector)](https://github.com/xr843/llm-pgvector)

PostgreSQL pgvector storage backend for [LLM](https://llm.datasette.io/).

## Why

LLM's default SQLite storage computes cosine similarity with brute-force O(n) scans. This works for small collections but becomes a bottleneck as your embedding count grows.

llm-pgvector replaces that with pgvector's HNSW and IVFFlat approximate nearest neighbor indexes, delivering sub-millisecond search at scale.

## Installation

```bash
llm install llm-pgvector
```

### Prerequisites

PostgreSQL with the [pgvector](https://github.com/pgvector/pgvector) extension installed.

Quick Docker setup:

```bash
docker run -d --name pgvector -e POSTGRES_PASSWORD=postgres -p 5432:5432 pgvector/pgvector:pg16
```

## Configuration

Set the `LLM_PGVECTOR_URL` environment variable:

```bash
export LLM_PGVECTOR_URL="postgresql://postgres:postgres@localhost:5432/postgres"
```

## Usage

### Initialize schema

```bash
llm pgvector setup
```

### Sync embeddings from SQLite to pgvector

```bash
llm pgvector sync <collection>
```

Use `-d` to specify a custom SQLite database path:

```bash
llm pgvector sync <collection> -d /path/to/embeddings.db
```

### Search similar items

```bash
llm pgvector similar <collection> "query text"
```

Options:

- `-n` -- Number of results (default: 10)
- `-m` -- Distance metric: `cosine`, `l2`, or `ip`
- `--ef-search` -- HNSW ef_search parameter for recall/speed tradeoff
- `--metadata` -- JSON metadata filter (e.g. `'{"category":"science"}'`)

### List collections

```bash
llm pgvector list
```

### Create or rebuild an index

```bash
llm pgvector create-index <collection>
```

Options:

- `--type` -- Index type: `hnsw` (default) or `ivfflat`
- `--metric` -- Distance metric: `cosine`, `l2`, or `ip`
- `--m` -- HNSW max connections per node (default: 16)
- `--ef-construction` -- HNSW build-time search depth (default: 64)

### Delete a collection

```bash
llm pgvector delete <collection>
```

## Complete workflow

```bash
# Embed some content using llm
llm embed-multi articles --files ./docs '*.md' -m 3-small --store

# Sync to pgvector
llm pgvector setup
llm pgvector sync articles

# Create an HNSW index for fast search
llm pgvector create-index articles --type hnsw

# Search with sub-millisecond latency
llm pgvector similar articles "machine learning fundamentals" -n 5
```

## Performance

HNSW indexes provide approximately 99% recall at 100x+ speed improvement over brute-force search. Key tunable parameters:

- **m** -- Higher values improve recall at the cost of memory and build time (default: 16)
- **ef_construction** -- Higher values improve index quality at the cost of build time (default: 64)
- **ef_search** -- Higher values improve query recall at the cost of latency (default: 40)

## Background

Built from production experience powering [FoJin](https://github.com/xr843/fojin), a Buddhist digital text platform serving 678,000+ embedding vectors across 30 languages with sub-50ms semantic search latency.

## Development

Clone the repository and install in development mode:

```bash
git clone https://github.com/xr843/llm-pgvector.git
cd llm-pgvector
pip install -e '.[test]'
```

Run tests:

```bash
pytest
```

## License

Apache-2.0
