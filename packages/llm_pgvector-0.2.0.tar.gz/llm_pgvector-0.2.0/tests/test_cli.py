"""Tests for llm-pgvector CLI commands."""

from unittest.mock import MagicMock, patch
from click.testing import CliRunner
from llm.cli import cli
import json


class TestCLISetup:
    """Test the 'llm pgvector setup' command."""

    @patch("llm_pgvector.store.PgVectorStore")
    def test_setup_success(self, MockStore):
        mock_store = MagicMock()
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["pgvector", "setup", "--db", "postgresql://test"])

        assert result.exit_code == 0
        assert "initialized" in result.output.lower()
        mock_store.setup.assert_called_once()


class TestCLIList:
    """Test the 'llm pgvector list' command."""

    @patch("llm_pgvector.store.PgVectorStore")
    def test_list_empty(self, MockStore):
        mock_store = MagicMock()
        mock_store.list_collections.return_value = []
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["pgvector", "list", "--db", "postgresql://test"])

        assert result.exit_code == 0
        assert "No collections found" in result.output

    @patch("llm_pgvector.store.PgVectorStore")
    def test_list_with_collections(self, MockStore):
        mock_store = MagicMock()
        mock_store.list_collections.return_value = [
            {"name": "articles", "model": "3-small", "dimension": 1536, "created_at": "2026-01-01", "count": 100},
            {"name": "docs", "model": "bge-m3", "dimension": 1024, "created_at": "2026-01-02", "count": 50},
        ]
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["pgvector", "list", "--db", "postgresql://test"])

        assert result.exit_code == 0
        assert "articles" in result.output
        assert "docs" in result.output
        assert "100" in result.output


class TestCLIDelete:
    """Test the 'llm pgvector delete' command."""

    @patch("llm_pgvector.store.PgVectorStore")
    def test_delete_with_yes(self, MockStore):
        mock_store = MagicMock()
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["pgvector", "delete", "mytest", "--db", "postgresql://test", "-y"])

        assert result.exit_code == 0
        assert "deleted" in result.output.lower()
        mock_store.delete_collection.assert_called_once_with("mytest")

    @patch("llm_pgvector.store.PgVectorStore")
    def test_delete_abort(self, MockStore):
        mock_store = MagicMock()
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["pgvector", "delete", "mytest", "--db", "postgresql://test"], input="n\n")

        # Should abort without deleting
        mock_store.delete_collection.assert_not_called()


class TestCLICreateIndex:
    """Test the 'llm pgvector create-index' command."""

    @patch("llm_pgvector.store.PgVectorStore")
    def test_create_index_hnsw(self, MockStore):
        mock_store = MagicMock()
        mock_store.conn.execute.return_value.fetchone.return_value = (1,)
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, [
            "pgvector", "create-index", "articles",
            "--db", "postgresql://test",
            "--type", "hnsw", "--metric", "cosine"
        ])

        assert result.exit_code == 0
        assert "created" in result.output.lower()
        mock_store.create_index.assert_called_once()

    @patch("llm_pgvector.store.PgVectorStore")
    def test_create_index_collection_not_found(self, MockStore):
        mock_store = MagicMock()
        mock_store.conn.execute.return_value.fetchone.return_value = None
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, [
            "pgvector", "create-index", "nonexistent",
            "--db", "postgresql://test"
        ])

        assert result.exit_code != 0


class TestCLIStatus:
    """Test the 'llm pgvector status' command."""

    @patch("llm_pgvector.store.PgVectorStore")
    def test_status_found(self, MockStore):
        mock_store = MagicMock()
        mock_store.collection_status.return_value = {
            "name": "articles", "model": "3-small", "dimension": 1536,
            "created_at": "2026-01-01", "count": 500,
            "indexes": [{"name": "idx_hnsw", "definition": "CREATE INDEX..."}],
            "embedding_size": "12 MB",
        }
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["pgvector", "status", "articles", "--db", "postgresql://test"])

        assert result.exit_code == 0
        assert "articles" in result.output
        assert "500" in result.output
        assert "12 MB" in result.output

    @patch("llm_pgvector.store.PgVectorStore")
    def test_status_not_found(self, MockStore):
        mock_store = MagicMock()
        mock_store.collection_status.return_value = None
        MockStore.return_value.__enter__ = MagicMock(return_value=mock_store)
        MockStore.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(cli, ["pgvector", "status", "nonexistent", "--db", "postgresql://test"])

        assert result.exit_code != 0
