"""Tests for llm_pgvector.store module."""

import os
import random
import struct

import pytest

from llm_pgvector.store import decode_llm_embedding, encode_llm_embedding

# ---------------------------------------------------------------------------
# Integration test helpers
# ---------------------------------------------------------------------------

PG_URL = os.environ.get("LLM_PGVECTOR_TEST_URL")
requires_pg = pytest.mark.skipif(not PG_URL, reason="LLM_PGVECTOR_TEST_URL not set")

# Simple 3-D test vectors
VEC_A = [1.0, 0.0, 0.0]
VEC_B = [0.9, 0.1, 0.0]  # similar to A
VEC_C = [0.0, 0.0, 1.0]  # dissimilar to A


# ===========================================================================
# Unit tests — no database required
# ===========================================================================


class TestDecodeEncodeHelpers:
    """Unit tests for binary embedding encode/decode helpers."""

    def test_decode_llm_embedding(self):
        """Encode known floats to little-endian bytes, decode back, verify round-trip."""
        original = [1.0, -2.5, 3.75]
        raw = struct.pack("<fff", *original)
        decoded = decode_llm_embedding(raw)
        assert decoded == pytest.approx(original)

    def test_encode_llm_embedding(self):
        """Encode [1.0, 2.0, 3.0] and verify byte length equals 12 (3 * 4 bytes)."""
        encoded = encode_llm_embedding([1.0, 2.0, 3.0])
        assert isinstance(encoded, bytes)
        assert len(encoded) == 12

    def test_decode_encode_roundtrip(self):
        """Random floats survive an encode-then-decode round-trip."""
        random.seed(42)
        original = [random.uniform(-100, 100) for _ in range(128)]
        encoded = encode_llm_embedding(original)
        decoded = decode_llm_embedding(encoded)
        assert decoded == pytest.approx(original, rel=1e-6)

    def test_decode_empty(self):
        """Empty bytes decodes to an empty list."""
        assert decode_llm_embedding(b"") == []


# ===========================================================================
# Integration tests — require a running PostgreSQL with pgvector
# ===========================================================================


@requires_pg
class TestSetup:
    """Verify that the store can initialize its schema."""

    def test_setup(self):
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(PG_URL) as store:
            store.setup()


@requires_pg
class TestCollectionLifecycle:
    """Create, list, and delete a collection."""

    def test_collection_lifecycle(self):
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(PG_URL) as store:
            store.setup()
            coll_name = "_test_lifecycle"

            # Create
            cid = store.get_or_create_collection(coll_name, "test-model", dimension=3)
            assert isinstance(cid, int)

            # List — should appear
            names = [c["name"] for c in store.list_collections()]
            assert coll_name in names

            # Delete
            store.delete_collection(coll_name)
            names = [c["name"] for c in store.list_collections()]
            assert coll_name not in names


@requires_pg
class TestUpsertAndSearch:
    """Insert embeddings, search, and verify result ordering."""

    def test_upsert_and_search(self):
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(PG_URL) as store:
            store.setup()
            coll_name = "_test_search"
            cid = store.get_or_create_collection(coll_name, "test-model", dimension=3)

            try:
                store.upsert_embedding(cid, "a", VEC_A, content="vec a")
                store.upsert_embedding(cid, "b", VEC_B, content="vec b")
                store.upsert_embedding(cid, "c", VEC_C, content="vec c")

                # Search for vectors similar to A
                results = store.search(cid, VEC_A, n=3, metric="cosine")
                assert len(results) == 3

                ids = [r["id"] for r in results]
                # A should be first (exact match), B second (similar), C last
                assert ids[0] == "a"
                assert ids[1] == "b"
                assert ids[2] == "c"

                # Scores should be descending (higher = more similar)
                assert results[0]["score"] >= results[1]["score"]
                assert results[1]["score"] >= results[2]["score"]
            finally:
                store.delete_collection(coll_name)


@requires_pg
class TestBulkUpsert:
    """Insert a batch of embeddings and verify the count."""

    def test_bulk_upsert(self):
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(PG_URL) as store:
            store.setup()
            coll_name = "_test_bulk"
            cid = store.get_or_create_collection(coll_name, "test-model", dimension=3)

            try:
                items = [
                    {"id": f"item_{i}", "embedding": [float(i), 0.0, 0.0]}
                    for i in range(20)
                ]
                store.bulk_upsert(cid, items)
                assert store.count(cid) == 20
            finally:
                store.delete_collection(coll_name)


@requires_pg
class TestMetadataFilter:
    """Insert embeddings with metadata and search with a filter."""

    def test_metadata_filter(self):
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(PG_URL) as store:
            store.setup()
            coll_name = "_test_metadata"
            cid = store.get_or_create_collection(coll_name, "test-model", dimension=3)

            try:
                store.upsert_embedding(
                    cid, "a", VEC_A, content="vec a", metadata={"color": "red"}
                )
                store.upsert_embedding(
                    cid, "b", VEC_B, content="vec b", metadata={"color": "blue"}
                )
                store.upsert_embedding(
                    cid, "c", VEC_C, content="vec c", metadata={"color": "red"}
                )

                # Filter for red only — should return a and c
                results = store.search(
                    cid, VEC_A, n=10, metric="cosine", metadata_filter={"color": "red"}
                )
                result_ids = {r["id"] for r in results}
                assert result_ids == {"a", "c"}
            finally:
                store.delete_collection(coll_name)


@requires_pg
class TestCreateIndex:
    """Create an HNSW index without error."""

    def test_create_index(self):
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(PG_URL) as store:
            store.setup()
            coll_name = "_test_index"
            cid = store.get_or_create_collection(coll_name, "test-model", dimension=3)

            try:
                store.upsert_embedding(cid, "a", VEC_A)
                store.create_index(cid, index_type="hnsw", metric="cosine")
            finally:
                store.delete_collection(coll_name)


@requires_pg
class TestCollectionStatus:
    """Test collection_status method."""

    def test_collection_status(self):
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(PG_URL) as store:
            store.setup()
            coll_name = "_test_status"
            cid = store.get_or_create_collection(coll_name, "test-model", dimension=3)
            try:
                store.upsert_embedding(cid, "a", [1.0, 0.0, 0.0])
                status = store.collection_status(coll_name)
                assert status is not None
                assert status["name"] == coll_name
                assert status["count"] == 1
                assert status["model"] == "test-model"
            finally:
                store.delete_collection(coll_name)


@requires_pg
class TestGetExistingHashes:
    """Test get_existing_hashes method."""

    def test_get_existing_hashes(self):
        from llm_pgvector.store import PgVectorStore

        with PgVectorStore(PG_URL) as store:
            store.setup()
            coll_name = "_test_hashes"
            cid = store.get_or_create_collection(coll_name, "test-model", dimension=3)
            try:
                store.upsert_embedding(cid, "a", [1.0, 0.0, 0.0], content_hash=b"\x01\x02")
                store.upsert_embedding(cid, "b", [0.0, 1.0, 0.0], content_hash=b"\x03\x04")
                hashes = store.get_existing_hashes(cid)
                assert len(hashes) == 2
                assert hashes["a"] == b"\x01\x02"
                assert hashes["b"] == b"\x03\x04"
            finally:
                store.delete_collection(coll_name)
