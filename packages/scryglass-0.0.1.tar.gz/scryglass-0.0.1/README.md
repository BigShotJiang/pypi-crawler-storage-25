# scryglass

Semantic query layer for structured data pipelines.

Coming soon.
