import os
import sys
import subprocess
from pathlib import Path

# -------------------------
# Colors
# -------------------------

class C:
    PURPLE = "\033[95m"
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    RESET = "\033[0m"


# -------------------------
# Branding
# -------------------------

BANNER = f"""{C.PURPLE}
██╗  ██╗ █████╗ ███████╗███████╗██╗     
██║  ██║██╔══██╗╚══███╔╝██╔════╝██║     
███████║███████║  ███╔╝ █████╗  ██║     
██╔══██║██╔══██║ ███╔╝  ██╔══╝  ██║     
██║  ██║██║  ██║███████╗███████╗███████╗
╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝
{C.RESET}"""

WELCOME = f"""{C.CYAN}
Welcome 👋
This framework was built using HazelTech — clean, scalable, and made for powerful Discord experiences.

Get started by exploring the available commands and features.
Need help? Use the help command anytime.

— HazelTech
{C.RESET}
"""

# -------------------------
# File Templates
# -------------------------

MAIN_PY = """import discord
from discord.ext import commands
import os

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print("\\n✨ HazelAura Bot Online — Powered by HazelTech")
    print(f"Logged in as {bot.user}")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\n")


async def load_cogs():
    for folder in os.listdir("./cogs"):
        path = f"./cogs/{folder}"
        if os.path.isdir(path):
            for file in os.listdir(path):
                if file.endswith(".py") and file != "__init__.py":
                    await bot.load_extension(f"cogs.{folder}.{file[:-3]}")


async def main():
    async with bot:
        await load_cogs()
        await bot.start("YOUR_TOKEN_HERE")


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
"""

CONFIG_PY = """import os

TOKEN = os.getenv("DISCORD_TOKEN", "YOUR_TOKEN_HERE")
"""

DATABASE_PY = """def connect():
    print("Database connected (placeholder)")
"""

HELPERS_PY = """def ping():
    return "pong"
"""

REQUIREMENTS = """discord.py
python-dotenv
"""

COG_TEMPLATE = """from discord.ext import commands

class {class_name}(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # your content here


async def setup(bot):
    await bot.add_cog({class_name}(bot))
"""


# -------------------------
# Core Functions
# -------------------------

def create_project(name):
    base = Path(name)

    folders = [
        base,
        base / "cogs",
        base / "data",
        base / "core",
        base / "utils",
        base / "components",
    ]

    for folder in folders:
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "__init__.py").touch()

    (base / "main.py").write_text(MAIN_PY)
    (base / "requirements.txt").write_text(REQUIREMENTS)

    (base / "core" / "config.py").write_text(CONFIG_PY)
    (base / "core" / "database.py").write_text(DATABASE_PY)

    (base / "utils" / "helpers.py").write_text(HELPERS_PY)

    print(f"{C.GREEN}✅ Project '{name}' created successfully!{C.RESET}")


def create_cog(name):
    cwd = Path.cwd()

    if cwd.name != "cogs":
        print(f"{C.RED}❌ Run this inside the 'cogs/' folder{C.RESET}")
        return

    folder = cwd / name
    folder.mkdir(exist_ok=True)

    (folder / "__init__.py").touch()

    class_name = name.capitalize()
    cog_file = folder / f"{name}.py"
    cog_file.write_text(COG_TEMPLATE.format(class_name=class_name))

    print(f"{C.GREEN}✅ Cog '{name}' created!{C.RESET}")


def run_dev():
    if not Path("main.py").exists():
        print(f"{C.RED}❌ Run this inside your project root{C.RESET}")
        return

    print(BANNER)
    print(f"{C.CYAN}🚀 Starting HazelAura Dev Mode...{C.RESET}\n")

    subprocess.run([sys.executable, "main.py"])


def show_help():
    print(BANNER)
    print(WELCOME)

    print(f"""{C.YELLOW}Commands:{C.RESET}

  aura create --project <name>   Create new bot project
  aura create --cog <name>       Create cog (inside /cogs)
  aura run dev                   Run the bot
  aura help                      Show this menu
""")


# -------------------------
# CLI Handler
# -------------------------

def main():
    args = sys.argv

    if len(args) < 2:
        show_help()
        return

    cmd = args[1]

    if cmd == "create":
        if "--project" in args:
            idx = args.index("--project")
            try:
                name = args[idx + 1]
                create_project(name)
            except IndexError:
                print(f"{C.RED}❌ Missing project name{C.RESET}")

        elif "--cog" in args:
            idx = args.index("--cog")
            try:
                name = args[idx + 1]
                create_cog(name)
            except IndexError:
                print(f"{C.RED}❌ Missing cog name{C.RESET}")

    elif cmd == "run" and len(args) > 2 and args[2] == "dev":
        run_dev()

    elif cmd == "help":
        show_help()

    else:
        print(f"{C.RED}Unknown command{C.RESET}")
        show_help()


def run():
    main()