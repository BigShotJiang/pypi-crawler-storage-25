import numpy as np
from scipy import fft
from . import constants as c
from .range_equation import snr_range_eqn, snr_range_eqn_cp
from .pulse_doppler_radar import Radar
from .waveform import WaveformSample
from .returns import Target


def noise_checks(signal_dc: np.ndarray, noise_dc: np.ndarray, total_dc: np.ndarray) -> None:
    """Prints various noise and signal-to-noise ratio (SNR) checks.

    Args:
        signal_dc (np.ndarray): The down-converted signal data.
        noise_dc (np.ndarray): The down-converted noise data.
        total_dc (np.ndarray): The down-converted total signal (signal + noise).
    """
    print(f"\n5.3.2 noise check: {np.var(fft.fft(noise_dc, axis=1))=: .4f}")
    print("\nnoise check:")
    noise_var = np.var(total_dc, 1)
    print(f"\t{np.mean(noise_var)=: .4f}")
    print(f"\t{np.var(noise_var)=: .4f}")
    print(f"\t{np.mean(20*np.log10(noise_var))=: .4f}")
    print(f"\t{np.var(20*np.log10(noise_var))=: .4f}")
    print("\nSNR test:")
    print(f"\t{20*np.log10(np.max(abs(signal_dc)))=:.2f}")
    print(f"\t{20*np.log10(np.max(abs(noise_dc)))=:.2f}")
    print(f"\t{20*np.log10(np.max(abs(total_dc)))=:.2f}")


def check_expected_snr(radar: Radar, target: Target, waveform: WaveformSample) -> None:
    """Calculates and prints expected SNR based on the radar equation.

    Args:
        radar: Radar system parameters.
        target: Target kinematics and scattering parameters.
        waveform: WaveformSample containing pulse data and parameters.
    """
    ## expected
    SNR_expected = snr_range_eqn_cp(
        radar.tx_power,
        radar.tx_gain,
        radar.rx_gain,
        target.rcs,
        c.C / radar.fcar,
        target.range,
        waveform.bw,
        radar.noise_factor,
        radar.total_losses,
        radar.op_temp,
        radar.n_pulses,
        waveform.time_bw_product,
    )
    ## volatge used in return (recalculated)
    SNR_onepulse = snr_range_eqn(
        radar.tx_power,
        radar.tx_gain,
        radar.rx_gain,
        target.rcs,
        c.C / radar.fcar,
        target.range,
        waveform.bw,
        radar.noise_factor,
        radar.total_losses,
        radar.op_temp,
        waveform.time_bw_product,
    )
    SNR_volt = np.sqrt(SNR_onepulse / radar.n_pulses)

    print("SNR Check:")
    print(f"\t{10*np.log10(SNR_onepulse)=:.2f}")
    print(f"\t{SNR_volt=:.1e}")
    print(f"\t{SNR_expected=:.1e}")
    print(f"\t{10*np.log10(SNR_expected)=:.2f}")
