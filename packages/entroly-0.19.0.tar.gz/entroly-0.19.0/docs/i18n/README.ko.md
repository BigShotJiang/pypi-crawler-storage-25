<p align="center">
  <a href="../../README.md">🇬🇧 English</a> •
  <a href="README.zh-CN.md">🇨🇳 中文</a> •
  <a href="README.ja.md">🇯🇵 日本語</a> •
  <a href="README.pt-BR.md">🇧🇷 Português</a> •
  <a href="README.es.md">🇪🇸 Español</a> •
  <a href="README.de.md">🇩🇪 Deutsch</a> •
  <a href="README.fr.md">🇫🇷 Français</a> •
  <a href="README.ru.md">🇷🇺 Русский</a> •
  <a href="README.hi.md">🇮🇳 हिन्दी</a> •
  <a href="README.tr.md">🇹🇷 Türkçe</a>
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/juyterman1000/entroly/main/docs/assets/logo.png" width="180" alt="Entroly">
</p>

<h1 align="center">Entroly — AI 토큰 비용을 70–95% 절감</h1>

<h3 align="center">당신의 AI 코딩 도구는 코드베이스의 5%만 봅니다.<br/>Entroly는 전체 그림을 보여줍니다 — 극히 적은 비용으로.</h3>

<p align="center">
  <a href="../../README.md#install"><b>설치</b></a> ·
  <a href="../../cookbook/README.md"><b>Cookbook</b></a> ·
  <a href="../../README.md#benchmarks"><b>벤치마크</b></a> ·
  <a href="../../README.md#works-with-your-stack"><b>65+ 지원 에이전트</b></a> ·
  <a href="https://juyterman1000.github.io/entroly/docs/dashboard.html"><b>대시보드</b></a>
</p>

<p align="center">
  <code>npm install entroly-wasm && npx entroly-wasm</code>&nbsp;&nbsp;|&nbsp;&nbsp;<code>pip install entroly && entroly go</code>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="https://juyterman1000.github.io/entroly/"><b>라이브 데모 →</b></a>
</p>

---

### 자가 개선 — 컨텍스트 엔진이 코드베이스를 학습하는 것을 관찰하세요

<p align="center">
  <img src="https://raw.githubusercontent.com/juyterman1000/entroly/main/docs/assets/self_improvement.svg" alt="Entroly 자가 개선" width="800">
</p>

### 수익 — 실시간 토큰 절약과 비용 절감

<p align="center">
  <img src="https://raw.githubusercontent.com/juyterman1000/entroly/main/docs/assets/token_savings.svg" alt="Entroly 수익" width="800">
</p>

### 컨텍스트 품질 — 전후 비교

<p align="center">
  <img src="https://raw.githubusercontent.com/juyterman1000/entroly/main/docs/assets/context_quality.svg" alt="Entroly 컨텍스트 품질" width="800">
</p>

---

## 문제 — 그리고 수익에 미치는 영향

모든 AI 코딩 도구 — Claude, Cursor, Copilot, Codex — 는 같은 맹점이 있습니다: **한 번에 5~10개 파일만 봅니다.** 나머지 95%의 코드베이스는 보이지 않습니다.

모델은 계속 커지고 있습니다 — 더 강력한 기능과 더 높은 토큰당 비용을 가진 **Claude Opus 4.7**이 막 출시되었습니다. 컨텍스트 창이 커진다고 문제가 해결되지는 않습니다. 오히려 더 악화됩니다. 당신은 요청당 186,000 토큰의 비용을 지불하고 있습니다 — 그리고 그 중 대부분은 중복된 보일러플레이트입니다.

> **Entroly는 30초 안에 두 문제를 모두 해결합니다.**

---

## 첫날부터 달라지는 것

| 지표 | Entroly 이전 | **Entroly 이후** |
|---|---|---|
| AI가 보는 파일 | 5–10 | **전체 저장소** |
| 요청당 토큰 | ~186,000 | **9,300 – 55,000** |
| 월 AI 지출 (일 1K 요청) | ~$16,800 | **$840 – $5,040** |
| AI 답변 정확도 | 불완전, 종종 환각 | **의존성 인식, 정확** |
| AI 실수 수정에 드는 개발자 시간 | 주당 수 시간 | **거의 제로** |
| 설정 | 수일간의 프롬프트 엔지니어링 | **30초** |

> **ROI 예시:** AI API에 월 $15K 지출하는 10인 팀은 첫날에 **월 $10K–$14K를 절약**합니다.

---

## 경쟁사가 이미 알고 있는 것

오늘 Entroly를 도입하는 팀은 단순히 돈을 절약하는 게 아닙니다 — 당신의 팀이 **따라잡을 수 없는 우위를 복리로 쌓고** 있습니다.

- **1주차:** 그들의 AI는 코드베이스 100%를 봅니다. 당신의 것은 5%. 그들이 더 빨리 배포합니다.
- **1개월째:** 그들의 런타임은 코드베이스 패턴을 학습했습니다. 당신의 것은 아직 import에서 환각합니다.
- **3개월째:** 그들의 설치는 연합에 연결되어 — 전 세계 수천 팀의 최적화 전략을 흡수합니다. 당신은 이것이 존재하는지도 모릅니다.
- **6개월째:** 그들은 API 비용 $80K+ 절약. 그 예산은 채용에 투입. 당신은 아직 재무팀에 AI 청구서가 왜 계속 늘어나는지 설명하고 있습니다.

매일 기다릴수록 격차는 벌어집니다. 연합 효과는 **얼리 어답터를 더 빠르게 강하게** 만들고 — 그 우위는 복리로 커집니다.

---

## 작동 방식 (30초)

```bash
npm install entroly-wasm && npx entroly-wasm
# 또는
pip install entroly && entroly go
```

끝. Entroly가 IDE를 자동 감지하고 Claude/Cursor/Copilot/Codex/MiniMax에 연결하여 최적화를 시작합니다.

---

## 경쟁 우위 — Entroly만의 차이점

### 🧠 추가 비용 없이 더 똑똑해짐

```
학습 예산 ≤ 5% × 평생 절약액
```

1일차: 70% 토큰 절약. 30일차: 85%+. 90일차: 90%+. **개선 비용 $0.**

### 🌐 연합 군집 학습 — SF처럼 들리는 부분

드리밍 루프를 **지구상의 모든 Entroly 개발자로 곱하세요.**

당신이 잠든 사이 당신의 데몬이 꿈을 꿉니다 — 그리고 10,000개의 다른 데몬도 마찬가지입니다. 각각이 약간 다른 코드 압축 요령을 발견합니다. 각각이 배운 것을 익명으로 공유합니다. 각각이 다른 데몬의 발견을 흡수합니다.

**아침에 일어나면 AI가 어젯밤보다 똑똑해져 있습니다. 당신이 한 게 아닙니다 — 군집이 꿈에서 찾은 것 때문에.**

```
당신의 데몬이 꿈을 꿈 → 더 나은 전략 발견 → 익명으로 공유
     ↓
10,000개의 다른 데몬이 어젯밤 같은 일을 함
     ↓
노트북을 열음 → AI가 이미 전부 흡수함
```


**네트워크 효과:**
- 새 사용자마다 모든 사람의 AI가 좋아집니다 — 그 설치 기반은 fork할 수 없습니다
- 코드는 절대 이동하지 않습니다. 최적화 가중치만 — 노이즈 보호 & 익명
- 인프라 비용: **$0**. GitHub에서 동작. 서버 없음. GPU 없음. 클라우드 없음

```bash
# 옵트인 — 언제나 당신의 선택
export ENTROLY_FEDERATION=1
```

### ✂️ 응답 증류 — 출력 토큰도 절약

LLM 응답에는 ~40% 필러가 있습니다. Entroly가 제거합니다. 코드 블록은 절대 건드리지 않습니다.

```
전: "물론이죠! 기꺼이 도와드리겠습니다. 코드를 살펴볼게요.
     문제는 auth 모듈에 있습니다. 도움이 되셨으면!"

후: "문제는 auth 모듈에 있습니다."
     → 출력 토큰 70% 절약
```

### 🔒 로컬 실행. 코드는 절대 머신 밖으로 나가지 않습니다.

에어갭 및 규제 환경에서 작동합니다 — 외부로 데이터를 전송하지 않습니다.

---

## 벤치마크

### 정확도 유지

압축은 정확도에 영향을 미치지 않습니다 — 라이브 API로 검증 (gpt-4o-mini, Wilson 95% CI):

| 벤치마크 | n | 예산 | 베이스라인 (95% CI) | Entroly 사용 (95% CI) | 유지율 | 토큰 절약 |
|---|---|---|---|---|---|---|
| NeedleInAHaystack | 20 | 2K | 100% [83.9–100%] | 100% [83.9–100%] | **100.0%** | **99.5%** |
| LongBench (HotpotQA) | 50 | 2K | 64.0% [50.1–75.9%] | 68.0% [54.2–79.2%] | **106.2%** | **85.3%** |
| Berkeley Function Calling | 50 | 500 | 100% [92.9–100%] | 100% [92.9–100%] | **100.0%** | **79.3%** |
| SQuAD 2.0 | 50 | 100 | 78.0% [64.8–87.2%] | 76.0% [62.6–85.7%] | **97.4%** | **39.3%** |
| GSM8K | 100 | 50K | 85.0% [76.7–90.7%] | 86.0% [77.9–91.5%] | **101.2%** | pass-through¹ |
| MMLU | 100 | 50K | 82.0% [73.3–88.3%] | 85.9% [77.8–91.4%] | **104.7%** | pass-through¹ |
| TruthfulQA (MC1) | 100 | 50K | 72.0% [62.5–79.9%] | 73.7% [64.3–81.4%] | **102.4%** | pass-through¹ |

> ¹ **pass-through**: 컨텍스트가 이미 예산 내 — Entroly는 올바르게 아무것도 하지 않습니다. 모든 벤치마크에서 신뢰 구간이 겹칩니다.

### Entroly 비교 (롱 컨텍스트)

| 방법 | 유지율 | 토큰 감소 | 아키텍처 / 트레이드오프 |
|---|---|---|---|
| **Entroly** | **100–106%** | **85–99%** | **빠름 (~80ms).** 프래그먼트 수준 배낭 알고리즘. 완벽한 구조적 충실도 유지. |
| 토큰 수준 신경 가지치기 | ~98–99% | 80–95% | **높은 오버헤드.** 로컬 트랜스포머 필요. 코드 구문 손상. |
| 규칙 기반 축어 압축 | ~100% | 50–70% | **높은 충실도.** 낮은 토큰 감소. |
| 어텐션 기반 압축 | 95%+ | 26–54% | **견고한 정확도.** 낮은 토큰 감소. |

---

## 완전 동등: Python & Node.js

| 능력 | Python | Node.js (WASM) |
|---|---|---|
| 컨텍스트 압축 | ✅ | ✅ |
| 자기 진화 | ✅ | ✅ |
| 드리밍 루프 | ✅ | ✅ |
| 연합 | ✅ | ✅ |
| 응답 증류 | ✅ | ✅ |
| 채팅 게이트웨이 | ✅ | ✅ |
| agentskills.io 내보내기 | ✅ | ✅ |

---

<p align="center">
  <b>AI가 낭비하는 토큰에 돈을 지불하는 것을 멈추세요. 스스로 배우는 AI를 시작하세요.</b><br/>
  <code>npm install entroly-wasm && npx entroly-wasm</code>&nbsp;&nbsp;|&nbsp;&nbsp;<code>pip install entroly && entroly go</code>
</p>
