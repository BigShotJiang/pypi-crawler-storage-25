"""
Console entrypoint for the `puvinoise` command (shipped with puvinoise-sdk).

Currently implements: `puvinoise run ...` — see puvinoise.puvinoise_run.
"""

from __future__ import annotations

import argparse
import sys


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="puvinoise",
        description="PUVINoise SDK — run agents with CLI-injected telemetry (puvinoise run).",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    from puvinoise.puvinoise_run import (
        register_subparser as _register_run,
        register_upgrade_subparser as _register_upgrade,
    )

    _register_run(sub)
    _register_upgrade(sub)
    return parser


def main() -> int:
    parser = build_parser()
    args, unknown = parser.parse_known_args()
    args._unknown_args = unknown  # noqa: SLF001 — merged in cmd_run for passthrough flags
    if not hasattr(args, "func"):
        parser.print_help()
        return 1
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
