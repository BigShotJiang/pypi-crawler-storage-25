"""Tests for transformers __init__ module."""

import pytest
from gnps.transformers import BaseTransformer, PythonTransformer, VerilogTransformer
from gnps.transformers.base_transformer import BaseTransformer as BaseTransformerClass
from gnps.transformers.python_transformer import PythonTransformer as PythonTransformerClass
from gnps.transformers.verilog_transformer import VerilogTransformer as VerilogTransformerClass


class TestTransformersInit:
    """Test the transformers __init__ module imports."""

    def test_base_transformer_import(self):
        """Test that BaseTransformer is imported correctly."""
        assert BaseTransformer is BaseTransformerClass

    def test_python_transformer_import(self):
        """Test that PythonTransformer is imported correctly."""
        assert PythonTransformer is PythonTransformerClass

    def test_verilog_transformer_import(self):
        """Test that VerilogTransformer is imported correctly."""
        assert VerilogTransformer is VerilogTransformerClass

    def test_all_exports(self):
        """Test that __all__ exports are correct."""
        from gnps.transformers import __all__
        assert "BaseTransformer" in __all__
        assert "PythonTransformer" in __all__
        assert "VerilogTransformer" in __all__
        assert len(__all__) == 3
