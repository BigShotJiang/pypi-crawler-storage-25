"""Tests for VerilogTransformer and Verilog CLI integration."""

from pathlib import Path
from io import StringIO
from unittest.mock import patch
import shutil
import textwrap
import uuid

import pytest

from gnps.cli_transform import get_transformer, main
from gnps.system import GnpsSystem
from gnps.transformers import VerilogTransformer


def write_text(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(textwrap.dedent(content).strip() + "\n", encoding="utf-8")


class TempDirContext:
    def __init__(self):
        self.path = Path(r"C:\Users\ver\.codex\memories\nump_test_tmp") / f"tmp_{uuid.uuid4().hex}"

    def __enter__(self):
        self.path.mkdir(parents=True, exist_ok=False)
        return str(self.path)

    def __exit__(self, exc_type, exc, tb):
        shutil.rmtree(self.path, ignore_errors=True)


class TestVerilogTransformer:
    def test_get_transformer_verilog(self):
        transformer = get_transformer("verilog")
        assert isinstance(transformer, VerilogTransformer)

    def test_transform_wraps_module_with_default_nettype_guards(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "simple.yaml"
            write_text(
                system_file,
                """
                cells:
                  - id: 1
                    contents:
                      - x = 0
                rules: []
                """,
            )

            system = GnpsSystem.from_yaml(str(system_file))
            result = VerilogTransformer().transform(system)

            assert result.startswith("`default_nettype none\n\nmodule ")
            assert result.rstrip().endswith("`default_nettype wire")

    def test_transform_emits_imports_externals_and_conversions(self):
        with TempDirContext() as tmp_dir:
            tmp_path = Path(tmp_dir)
            lib_dir = tmp_path / "lib"
            write_text(
                lib_dir / "sensor.yaml",
                """
                module:
                  name: sensor
                  real_encoding:
                    kind: fixed_point
                    signed: true
                    width: 24
                    frac_bits: 8
                cells:
                  - id: 1
                    contents:
                      - level = 3
                    output: [level]
                rules: []
                """,
            )
            write_text(
                lib_dir / "uart.header.yaml",
                """
                external_module:
                  name: uart
                  ports:
                    - name: clk
                      dir: input
                      kind: logic
                      width: 1
                      signed: false
                    - name: rst
                      dir: input
                      kind: logic
                      width: 1
                      signed: false
                    - name: rx
                      dir: input
                      kind: logic
                      width: 1
                      signed: false
                    - name: rx_data
                      dir: output
                      kind: int
                      width: 8
                      signed: false
                    - name: rx_valid
                      dir: output
                      kind: logic
                      width: 1
                      signed: false
                """,
            )
            root_file = tmp_path / "controller.yaml"
            write_text(
                root_file,
                """
                module:
                  name: controller_top
                  real_encoding:
                    kind: fixed_point
                    signed: true
                    width: 32
                    frac_bits: 16
                  top_ports:
                    - name: uart_rx
                      dir: input
                      kind: logic
                      width: 1
                      signed: false
                imports:
                  - module: sensor.yaml
                    as: sensor0
                externals:
                  - header: uart.header.yaml
                    as: uart0
                    connections:
                      clk: top.clk
                      rst: top.rst
                      rx: top.uart_rx
                aliases:
                  sensed: sensor0.level
                  rx_byte: uart0.rx_data
                cells:
                  - id: 1
                    contents:
                      - alarm = 0
                    output: [alarm]
                rules:
                  - sensed > 1 && uart0.rx_valid == 1 | rx_byte + 1 -> alarm
                """,
            )

            system = GnpsSystem.from_yaml(str(root_file), import_paths=[str(lib_dir)])
            result = VerilogTransformer().transform(system)

            assert "module controller_top #(" in result
            assert "parameter int DATA_WIDTH = 32" in result
            assert "sensor sensor0 (" in result
            assert "uart uart0 (" in result
            assert "logic signed [23:0] sensor0__level;" in result
            assert "function automatic logic signed [31:0] conv_sfixed_24_8_to_sfixed_32_16(" in result
            assert "function automatic logic signed [31:0] conv_uint_8_to_sfixed_32_16(" in result
            assert "localparam logic signed [31:0] _VAL_1_0 = 32'sd65536;" in result
            assert ".clk(clk)" in result
            assert ".rst(rst)" in result
            assert "conv_sfixed_24_8_to_sfixed_32_16(sensor0__level)" in result
            assert "conv_uint_8_to_sfixed_32_16(uart0__rx_data)" in result
            assert "_VAL_1_0" in result
            assert "always_comb begin" in result
            assert "always_ff @(posedge clk or posedge rst) begin" in result
            assert "assign alarm = state_alarm;" in result

    def test_transform_rejects_unsupported_function_calls(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "bad.yaml"
            write_text(
                system_file,
                """
                cells:
                  - id: 1
                    contents:
                      - x = 0
                      - y = 0
                rules:
                  - sin(x) -> y
                """,
            )
            system = GnpsSystem.from_yaml(str(system_file))

            with pytest.raises(ValueError, match="function calls"):
                VerilogTransformer().transform(system)

    def test_cli_import_paths_emit_full_closure(self):
        with TempDirContext() as tmp_dir:
            tmp_path = Path(tmp_dir)
            lib_dir = tmp_path / "lib"
            out_dir = tmp_path / "out"
            write_text(
                lib_dir / "sensor.yaml",
                """
                module:
                  name: sensor
                cells:
                  - id: 1
                    contents:
                      - level = 0
                    output: [level]
                rules: []
                """,
            )
            root_file = tmp_path / "controller.yaml"
            write_text(
                root_file,
                """
                module:
                  name: controller_top
                imports:
                  - module: sensor.yaml
                    as: sensor0
                cells:
                  - id: 1
                    contents:
                      - alarm = 0
                    output: [alarm]
                rules:
                  - sensor0.level + 1 -> alarm
                """,
            )

            with patch(
                "sys.argv",
                [
                    "gnps-transformer",
                    str(root_file),
                    "-t",
                    "verilog",
                    "-o",
                    str(out_dir),
                    "--import-path",
                    str(lib_dir),
                ],
            ):
                with patch("sys.stdout", new_callable=StringIO):
                    main()

            assert (out_dir / "controller.sv").exists()
            assert (out_dir / "sensor.sv").exists()

    def test_zero_reset_mode_omits_used_signals(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "zero_reset.yaml"
            write_text(
                system_file,
                """
                module:
                  name: zero_reset_demo
                  zero_reset_mode: true
                cells:
                  - id: 1
                    contents:
                      - x = 5
                      - y = 0
                    output: [y]
                rules:
                  - x + 1 -> y
                """,
            )

            system = GnpsSystem.from_yaml(str(system_file))
            result = VerilogTransformer().transform(system)

            assert "_used" not in result
            assert "state_x_next = '0;" in result
            assert "state_y_next = '0;" in result
            assert "state_y_prod = state_y_prod + (state_x + _VAL_1_0);" in result

    def test_top_ports_apply_boundary_conversions_for_same_named_io(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "top_io.yaml"
            write_text(
                system_file,
                """
                module:
                  name: top_io_demo
                  top_ports:
                    - name: sample
                      dir: input
                      kind: int
                      width: 8
                      signed: false
                    - name: alarm
                      dir: output
                      kind: int
                      width: 8
                      signed: false
                cells:
                  - id: 1
                    contents:
                      - sample = 0
                      - alarm = 0
                    input: [sample]
                    output: [alarm]
                rules:
                  - sample + 1.5 -> alarm
                """,
            )

            system = GnpsSystem.from_yaml(str(system_file))
            result = VerilogTransformer().transform(system)

            assert "function automatic logic signed [31:0] conv_uint_8_to_sfixed_32_16(" in result
            assert "function automatic logic [7:0] conv_sfixed_32_16_to_uint_8(" in result
            assert "state_sample_next = conv_uint_8_to_sfixed_32_16(sample);" in result
            assert "assign alarm = conv_sfixed_32_16_to_uint_8(state_alarm);" in result
            assert "((value >= '0) ? (value >>> 16) : -((-value) >>> 16))" in result

    def test_import_connection_uses_local_state_for_unqualified_variable(self):
        with TempDirContext() as tmp_dir:
            tmp_path = Path(tmp_dir)
            lib_dir = tmp_path / "lib"
            write_text(
                lib_dir / "child.yaml",
                """
                module:
                  name: child
                cells:
                  - id: 1
                    contents:
                      - trigger = 0
                    input: [trigger]
                rules: []
                """,
            )
            root_file = tmp_path / "root.yaml"
            write_text(
                root_file,
                """
                module:
                  name: root
                imports:
                  - module: child.yaml
                    as: child0
                    connections:
                      trigger: toggle_pulse
                cells:
                  - id: 1
                    contents:
                      - toggle_pulse = 0
                rules: []
                """,
            )

            system = GnpsSystem.from_yaml(str(root_file), import_paths=[str(lib_dir)])
            result = VerilogTransformer().transform(system)

            assert ".trigger(state_toggle_pulse)" in result
            assert ".trigger(toggle_pulse)" not in result

    def test_unsigned_real_encoding_emits_unsigned_fixed_storage_and_literals(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "unsigned_fixed.yaml"
            write_text(
                system_file,
                """
                module:
                  name: unsigned_fixed_demo
                  real_encoding:
                    kind: fixed_point
                    signed: false
                    width: 16
                    frac_bits: 8
                constants:
                  SCALE: 1
                cells:
                  - id: 1
                    contents:
                      - x = 0
                      - y = 0
                    output: [y]
                rules:
                  - x + SCALE + 1.5 -> y
                """,
            )

            system = GnpsSystem.from_yaml(str(system_file))
            result = VerilogTransformer().transform(system)

            assert "logic [15:0] state_x;" in result
            assert "logic [15:0] state_y;" in result
            assert "localparam logic [15:0] SCALE = 16'd256;" in result
            assert "localparam logic [15:0] _VAL_1_5 = 16'd384;" in result
            assert "16'sd" not in result

    def test_zero_reset_mode_preserves_input_ports_in_next_state(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "zero_reset_input.yaml"
            write_text(
                system_file,
                """
                module:
                  name: zero_reset_input_demo
                  zero_reset_mode: true
                cells:
                  - id: 1
                    contents:
                      - trigger = 0
                      - out = 0
                    input: [trigger]
                    output: [out]
                rules:
                  - 1 -> out
                """,
            )

            system = GnpsSystem.from_yaml(str(system_file))
            result = VerilogTransformer().transform(system)

            assert "state_trigger_next = trigger;" in result
            assert "state_out_next = '0;" in result

    def test_helper_generated_literals_are_emitted(self):
        with TempDirContext() as tmp_dir:
            tmp_path = Path(tmp_dir)
            lib_dir = tmp_path / "lib"
            write_text(
                lib_dir / "child.yaml",
                """
                module:
                  name: child
                cells:
                  - id: 1
                    contents:
                      - sig = 0
                    input: [sig]
                rules: []
                """,
            )
            root_file = tmp_path / "root.yaml"
            write_text(
                root_file,
                """
                module:
                  name: root
                  real_encoding:
                    kind: fixed_point
                    signed: false
                    width: 40
                    frac_bits: 10
                  top_ports:
                    - name: led
                      dir: input
                      kind: logic
                      width: 1
                      signed: false
                imports:
                  - module: child.yaml
                    as: child0
                    connections:
                      sig: top.led
                cells:
                  - id: 1
                    contents:
                      - x = 0
                rules: []
                """,
            )

            system = GnpsSystem.from_yaml(str(root_file), import_paths=[str(lib_dir)])
            result = VerilogTransformer().transform(system)

            assert "localparam logic signed [31:0] _VAL_1_0 = 32'sd65536;" in result
            assert "conv_logic_to_sfixed_32_16 = (value ? _VAL_1_0 : '0);" in result

    def test_external_output_connection_to_top_port_is_emitted(self):
        with TempDirContext() as tmp_dir:
            tmp_path = Path(tmp_dir)
            lib_dir = tmp_path / "lib"
            write_text(
                lib_dir / "uart_tx.header.yaml",
                """
                external_module:
                  name: uart_tx
                  ports:
                    - name: clk
                      dir: input
                      kind: logic
                      width: 1
                      signed: false
                    - name: tx
                      dir: output
                      kind: logic
                      width: 1
                      signed: false
                """,
            )
            root_file = tmp_path / "root.yaml"
            write_text(
                root_file,
                """
                module:
                  name: root
                  top_ports:
                    - name: uart_tx
                      dir: output
                      kind: logic
                      width: 1
                      signed: false
                externals:
                  - header: uart_tx.header.yaml
                    as: uart0
                    connections:
                      clk: top.clk
                      tx: top.uart_tx
                cells:
                  - id: 1
                    contents:
                      - x = 0
                rules: []
                """,
            )

            system = GnpsSystem.from_yaml(str(root_file), import_paths=[str(lib_dir)])
            result = VerilogTransformer().transform(system)

            assert ".tx(uart0__tx)" in result
            assert "assign uart_tx = uart0__tx;" in result

    def test_logic_vector_top_output_uses_shifted_fixed_bits(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "logic_vector.yaml"
            write_text(
                system_file,
                """
                module:
                  name: logic_vector_demo
                  real_encoding:
                    kind: fixed_point
                    signed: false
                    width: 40
                    frac_bits: 10
                  top_ports:
                    - name: leds
                      dir: output
                      kind: logic
                      width: 6
                      signed: false
                cells:
                  - id: 1
                    contents:
                      - leds = 62
                    output: [leds]
                rules: []
                """,
            )

            system = GnpsSystem.from_yaml(str(system_file))
            result = VerilogTransformer().transform(system)

            assert "function automatic logic [5:0] conv_ufixed_40_10_to_logic_6(" in result
            assert "conv_ufixed_40_10_to_logic_6 = (value >>> 10);" in result
            assert "assign leds = conv_ufixed_40_10_to_logic_6(state_leds);" in result

    def test_multiple_logic_vector_output_widths_use_distinct_helpers(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "logic_vectors.yaml"
            write_text(
                system_file,
                """
                module:
                  name: logic_vectors_demo
                  real_encoding:
                    kind: fixed_point
                    signed: false
                    width: 40
                    frac_bits: 10
                  top_ports:
                    - name: leds4
                      dir: output
                      kind: logic
                      width: 4
                      signed: false
                    - name: leds6
                      dir: output
                      kind: logic
                      width: 6
                      signed: false
                cells:
                  - id: 1
                    contents:
                      - leds4 = 14
                      - leds6 = 62
                    output: [leds4, leds6]
                rules: []
                """,
            )

            system = GnpsSystem.from_yaml(str(system_file))
            result = VerilogTransformer().transform(system)

            assert "function automatic logic [3:0] conv_ufixed_40_10_to_logic_4(" in result
            assert "function automatic logic [5:0] conv_ufixed_40_10_to_logic_6(" in result
            assert "assign leds4 = conv_ufixed_40_10_to_logic_4(state_leds4);" in result
            assert "assign leds6 = conv_ufixed_40_10_to_logic_6(state_leds6);" in result

    def test_recursive_if_and_fsm_yaml_export_to_verilog(self):
        with TempDirContext() as tmp_dir:
            system_file = Path(tmp_dir) / "fsm_if.yaml"
            write_text(
                system_file,
                """
                module:
                  name: fsm_if_demo
                cells:
                  - id: 1
                    contents:
                      - ctrl_state = 0
                      - x = 0
                      - y = 0
                    input: [x]
                    output: [y]
                fsm:
                  - name: ctrl
                    variable: ctrl_state
                    initial: IDLE
                    states:
                      - IDLE:
                          rules:
                            - if: x > 2
                              then:
                                - RUN -> ctrl_state
                                - 1 -> y
                              else:
                                - 0 -> y
                      - RUN:
                          rules:
                            - if: x > 10
                              then: 2 -> y
                              else: 1 -> y
                """,
            )

            system = GnpsSystem.from_yaml(str(system_file))
            result = VerilogTransformer().transform(system)

            assert "ctrl__IDLE" in system.constants
            assert "ctrl__RUN" in system.constants
            assert "localparam logic signed [31:0] ctrl__IDLE = 32'sd0;" in result
            assert "localparam logic signed [31:0] ctrl__RUN = 32'sd65536;" in result
            assert "state_ctrl_state" in result
            assert "assign y = state_y;" in result
