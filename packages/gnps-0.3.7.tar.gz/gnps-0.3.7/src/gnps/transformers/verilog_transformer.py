"""Verilog transformer for converting GNPS AST to a synthesizable subset."""

from __future__ import annotations

from .base_transformer import BaseTransformer
from ..hardware import PortConfig
from ..parser.ast import *
from ..parser.ast.expression import FunctionCallExpression
from ..system import GnpsSystem


class VerilogTransformer(BaseTransformer):
    """Transform GNPS systems into parameterized Verilog modules."""

    def __init__(self):
        super().__init__()
        self.system: GnpsSystem | None = None
        self.local_variables: list[str] = []
        self.reference_inputs: dict[str, str] = {}
        self.conversion_helpers: dict[tuple[str, int, bool, int, str, int, bool, int], str] = {}
        self.literal_params: dict[tuple[float, int, int, bool], str] = {}

    def get_file_extension(self) -> str:
        return ".sv"

    def transform(self, system: GnpsSystem) -> str:
        self.reset()
        self.system = system
        self.local_variables = sorted(system.variables.keys())
        self.reference_inputs = self._collect_reference_inputs(system)
        self.conversion_helpers = {}
        self.literal_params = {}

        self._validate_supported_system(system)

        module_name = system.module_config.name
        enc = system.module_config.real_encoding
        ports = self._collect_ports(system)
        port_lines = [self._port_decl(port) for port in ports]

        self.add_line("`default_nettype none")
        self.add_line()
        self.add_line(f"module {module_name} #(")
        self.add_line(f"parameter int DATA_WIDTH = {enc.width},", 1)
        self.add_line(f"parameter int FRAC_BITS = {enc.frac_bits}", 1)
        self.add_line(") (")
        for index, line in enumerate(port_lines):
            suffix = "," if index < len(port_lines) - 1 else ""
            self.add_line(f"{line}{suffix}", 1)
        self.add_line(");")
        self.add_line()

        for const_name, value in system.constants.items():
            self.add_line(f"// {const_name} = {value.value} in fixed-point Q{enc.width - enc.frac_bits}.{enc.frac_bits}")
            self.add_line(
                f"localparam {self._fixed_storage_decl(enc.width, enc.signed)} {const_name} = {self._encode_float(value.value, enc.width, enc.frac_bits, enc.signed)};"
            )
        if system.constants:
            self.add_line()
        self.add_line("// __LITERAL_PARAMS__")
        self.add_line()
        self.add_line("// __CONVERSION_HELPERS__")
        self.add_line()

        self._emit_import_wires()
        self._emit_external_wires()
        self._emit_state()
        self._emit_submodules()
        self._emit_external_output_bindings()
        self._emit_next_state_logic()
        self._emit_outputs()

        self.add_line("endmodule")
        self.add_line()
        self.add_line("`default_nettype wire")
        helper_text = self._emit_conversion_helpers()
        literal_text = self._emit_literal_params()
        return self.get_output().replace("// __LITERAL_PARAMS__\n\n", literal_text).replace("// __CONVERSION_HELPERS__\n\n", helper_text)

    def _validate_supported_system(self, system: GnpsSystem):
        for rule in system.rules:
            self._validate_expression(rule.producer)
            self._validate_expression(rule.guard)

    def _validate_expression(self, node):
        supported = (
            ConstantExpression,
            VariableExpression,
            ReferenceExpression,
            SumExpression,
            DifferenceExpression,
            MultiplicationExpression,
            DivisionExpression,
            UnaryMinusExpression,
            IntMultiplicationExpression,
            IntDivisionExpression,
            BooleanConstantExpression,
            BooleanAndExpression,
            BooleanOrExpression,
            BooleanNotExpression,
            BooleanLessTestExpression,
            BooleanLessEqualTestExpression,
            BooleanGreaterTestExpression,
            BooleanGreaterEqualTestExpression,
            BooleanEqualTestExpression,
            BooleanNotEqualTestExpression,
        )
        if isinstance(node, supported):
            for attr in ("left", "right", "expression"):
                child = getattr(node, attr, None)
                if child is not None:
                    self._validate_expression(child)
            for arg in getattr(node, "arguments", []):
                self._validate_expression(arg)
            return
        if isinstance(node, MultiplicationExpression):
            if isinstance(node.left, ConstantExpression) or isinstance(node.right, ConstantExpression):
                self._validate_expression(node.left)
                self._validate_expression(node.right)
                return
            raise ValueError("Verilog export does not support variable-by-variable multiplication")
        if isinstance(node, DivisionExpression):
            if isinstance(node.right, ConstantExpression):
                self._validate_expression(node.left)
                self._validate_expression(node.right)
                return
            raise ValueError("Verilog export does not support general division")
        if isinstance(node, FunctionCallExpression):
            raise ValueError("Verilog export does not support function calls")
        raise ValueError(f"Unsupported expression type for Verilog export: {type(node).__name__}")

    def _collect_reference_inputs(self, system: GnpsSystem) -> dict[str, str]:
        refs: dict[str, str] = {}
        for rule in system.rules:
            for reference in system._iter_references(rule.guard):
                refs[reference] = self._reference_signal_name(reference)
            for reference in system._iter_references(rule.producer):
                refs[reference] = self._reference_signal_name(reference)
        for alias_expr in system.aliases.values():
            for reference in system._iter_references(alias_expr):
                refs[reference] = self._reference_signal_name(reference)
        return refs

    def _reference_signal_name(self, reference: str) -> str:
        return reference.replace(".", "__")

    def _collect_ports(self, system: GnpsSystem) -> list[PortConfig]:
        ports = [
            PortConfig(system.module_config.clock.name, "input", "logic", 1, False),
            PortConfig(system.module_config.reset.name, "input", "logic", 1, False),
        ]
        existing = {ports[0].name, ports[1].name}

        for port in system.module_config.top_ports:
            if port.name not in existing:
                ports.append(port)
                existing.add(port.name)

        fixed_kind = "fixed"
        fixed_signed = system.module_config.real_encoding.signed
        fixed_width = system.module_config.real_encoding.width

        for variable_name in system.input_variables.keys():
            if variable_name not in existing:
                ports.append(PortConfig(variable_name, "input", fixed_kind, fixed_width, fixed_signed))
                existing.add(variable_name)

        for variable_name in system.output_variables.keys():
            if variable_name not in existing:
                ports.append(PortConfig(variable_name, "output", fixed_kind, fixed_width, fixed_signed))
                existing.add(variable_name)

        return ports

    def _port_decl(self, port: PortConfig) -> str:
        signed = " signed" if port.signed and port.width > 1 else ""
        width = "" if port.width == 1 else f" [{port.width - 1}:0]"
        return f"{port.dir} logic{signed}{width} {port.name}"

    def _emit_import_wires(self):
        assert self.system is not None
        for item in self.system.imports:
            imported = item.system
            for output_name in imported.output_variables.keys():
                wire_name = f"{item.alias}__{output_name}"
                width = imported.module_config.real_encoding.width
                signed = " signed" if imported.module_config.real_encoding.signed else ""
                self.add_line(f"logic{signed} [{width - 1}:0] {wire_name};")
        if self.system.imports:
            self.add_line()

    def _emit_external_wires(self):
        assert self.system is not None
        for item in self.system.externals:
            for port in item.definition.ports:
                if port.dir == "output":
                    signed = " signed" if port.signed and port.width > 1 else ""
                    width = "" if port.width == 1 else f" [{port.width - 1}:0]"
                    self.add_line(f"logic{signed}{width} {item.alias}__{port.name};")
        if self.system.externals:
            self.add_line()

    def _emit_external_output_bindings(self):
        assert self.system is not None
        emitted = False
        for item in self.system.externals:
            for port in item.definition.ports:
                if port.dir != "output":
                    continue
                target_ref = item.connections.get(port.name)
                if not target_ref:
                    continue
                if "." not in target_ref:
                    continue
                target_signal = self._reference_signal(target_ref)
                source_signal = f"{item.alias}__{port.name}"
                source_frac_bits = self.system.module_config.real_encoding.frac_bits if port.kind == "fixed" else 0
                target_kind, target_width, target_signed, target_frac_bits = self._reference_encoding(target_ref)
                converted = self._external_output_to_target(
                    source_signal,
                    port.kind,
                    port.width,
                    port.signed,
                    source_frac_bits,
                    target_kind,
                    target_width,
                    target_signed,
                    target_frac_bits,
                )
                self.add_line(f"assign {target_signal} = {converted};")
                emitted = True
        if emitted:
            self.add_line()

    def _emit_state(self):
        assert self.system is not None
        width = self.system.module_config.real_encoding.width
        signed = self.system.module_config.real_encoding.signed
        for variable_name in self.local_variables:
            state_name = self._state_name(variable_name)
            self.add_line(f"{self._fixed_storage_decl(width, signed)} {state_name};")
            self.add_line(f"{self._fixed_storage_decl(width, signed)} {state_name}_next;")
            self.add_line(f"{self._fixed_storage_decl(width, signed)} {state_name}_prod;")
            if not self.system.module_config.zero_reset_mode:
                self.add_line(f"logic {state_name}_used;")
        self.add_line()

    def _emit_submodules(self):
        assert self.system is not None
        for item in self.system.imports:
            imported = item.system
            self.add_line(f"{imported.module_config.name} {item.alias} (")
            connections = []
            connections.append(f".{imported.module_config.clock.name}({self.system.module_config.clock.name})")
            connections.append(f".{imported.module_config.reset.name}({self.system.module_config.reset.name})")
            for input_name in imported.input_variables.keys():
                ref = item.connections.get(input_name, "0")
                connections.append(
                    f".{input_name}({self._resolve_connection(ref, 'fixed', imported.module_config.real_encoding.width, imported.module_config.real_encoding.signed, imported.module_config.real_encoding.frac_bits)})"
                )
            for output_name in imported.output_variables.keys():
                connections.append(f".{output_name}({item.alias}__{output_name})")
            for index, conn in enumerate(connections):
                suffix = "," if index < len(connections) - 1 else ""
                self.add_line(f"{conn}{suffix}", 1)
            self.add_line(");")
            self.add_line()

        for item in self.system.externals:
            header = item.definition
            param_lines = []
            merged_params = dict(header.parameters)
            merged_params.update(item.parameters)
            if merged_params:
                params = ", ".join(f".{key}({value})" for key, value in merged_params.items())
                param_lines.append(f"#({params})")
            prefix = f"{header.name} {param_lines[0]} {item.alias}" if param_lines else f"{header.name} {item.alias}"
            self.add_line(f"{prefix} (")
            connections = []
            for port in header.ports:
                if port.dir == "output":
                    target = f"{item.alias}__{port.name}"
                else:
                    target = self._resolve_connection(
                        item.connections.get(port.name, "0"),
                        port.kind,
                        port.width,
                        port.signed,
                        0 if port.kind != "fixed" else self.system.module_config.real_encoding.frac_bits,
                    )
                connections.append(f".{port.name}({target})")
            for index, conn in enumerate(connections):
                suffix = "," if index < len(connections) - 1 else ""
                self.add_line(f"{conn}{suffix}", 1)
            self.add_line(");")
            self.add_line()

    def _emit_next_state_logic(self):
        assert self.system is not None
        self.add_line("always_comb begin")
        for variable_name in self.local_variables:
            state_name = self._state_name(variable_name)
            self.add_line(f"{state_name}_prod = '0;", 1)
            if not self.system.module_config.zero_reset_mode:
                self.add_line(f"{state_name}_used = 1'b0;", 1)
        self.add_line()
        for rule in self.system.rules:
            guard = self.visit(rule.guard)
            producer = self.visit(rule.producer)
            self.add_line(f"// {rule}", 1)
            self.add_line(f"if ({guard}) begin", 1)
            consumer_state = self._state_name(rule.consumer.name)
            self.add_line(f"{consumer_state}_prod = {consumer_state}_prod + {producer};", 2)
            if not self.system.module_config.zero_reset_mode:
                for used_name in sorted(rule.vars.keys()):
                    used_state = self._state_name(used_name)
                    self.add_line(f"{used_state}_used = 1'b1;", 2)
            self.add_line("end", 1)
        self.add_line()
        for variable_name in self.local_variables:
            state_name = self._state_name(variable_name)
            if self.system.module_config.zero_reset_mode:
                if variable_name in self.system.input_variables:
                    top_port = self._top_port_config(variable_name)
                    if top_port is None:
                        self.add_line(f"{state_name}_next = {variable_name};", 1)
                    else:
                        self.add_line(
                            f"{state_name}_next = {self._resolve_connection(variable_name, 'fixed', self.system.module_config.real_encoding.width, self.system.module_config.real_encoding.signed, self.system.module_config.real_encoding.frac_bits)};",
                            1,
                        )
                else:
                    self.add_line(f"{state_name}_next = '0;", 1)
            else:
                if variable_name in self.system.input_variables:
                    top_port = self._top_port_config(variable_name)
                    if top_port is None:
                        self.add_line(f"{state_name}_next = {variable_name};", 1)
                    else:
                        self.add_line(
                            f"{state_name}_next = {self._resolve_connection(variable_name, 'fixed', self.system.module_config.real_encoding.width, self.system.module_config.real_encoding.signed, self.system.module_config.real_encoding.frac_bits)};",
                            1,
                        )
                else:
                    self.add_line(f"{state_name}_next = {state_name};", 1)
                self.add_line(f"if ({state_name}_used) begin", 1)
                self.add_line(f"{state_name}_next = '0;", 2)
                self.add_line("end", 1)
            self.add_line(f"{state_name}_next = {state_name}_next + {state_name}_prod;", 1)
        self.add_line("end")
        self.add_line()

        reset_edge = "posedge" if self.system.module_config.reset.active_high else "negedge"
        self.add_line(f"always_ff @(posedge {self.system.module_config.clock.name} or {reset_edge} {self.system.module_config.reset.name}) begin")
        reset_condition = self.system.module_config.reset.name if self.system.module_config.reset.active_high else f"!{self.system.module_config.reset.name}"
        self.add_line(f"if ({reset_condition}) begin", 1)
        for variable_name in self.local_variables:
            initial_value = self._encode_float(
                self.system.variables[variable_name].value.value,
                self.system.module_config.real_encoding.width,
                self.system.module_config.real_encoding.frac_bits,
                self.system.module_config.real_encoding.signed,
            )
            self.add_line(f"// reset {variable_name} = {self.system.variables[variable_name].value.value}", 2)
            self.add_line(f"{self._state_name(variable_name)} <= {initial_value};", 2)
        self.add_line("end else begin", 1)
        for variable_name in self.local_variables:
            self.add_line(f"{self._state_name(variable_name)} <= {self._state_name(variable_name)}_next;", 2)
        self.add_line("end", 1)
        self.add_line("end")
        self.add_line()

    def _emit_outputs(self):
        assert self.system is not None
        for output_name in self.system.output_variables.keys():
            top_port = self._top_port_config(output_name)
            if top_port is None:
                self.add_line(f"assign {output_name} = {self._state_name(output_name)};")
            else:
                self.add_line(
                    f"assign {output_name} = {self._convert_local_fixed_to_target(output_name, top_port.kind, top_port.width, top_port.signed)};"
                )
        if self.system.output_variables:
            self.add_line()

    def _resolve_connection(self, reference: str, target_kind: str, target_width: int, target_signed: bool, target_frac_bits: int) -> str:
        if reference == "0":
            return "0"
        if "." in reference:
            signal = self._reference_signal(reference)
            return self._maybe_convert_signal(reference, signal, target_kind, target_width, target_signed, target_frac_bits)
        top_port = self._top_port_config(reference)
        if top_port is not None:
            reference_name = f"top.{reference}"
            return self._maybe_convert_signal(reference_name, reference, target_kind, target_width, target_signed, target_frac_bits)
        if reference in self.local_variables:
            assert self.system is not None
            signal = self._state_name(reference)
            enc = self.system.module_config.real_encoding
            if (
                target_kind == "fixed"
                and target_width == enc.width
                and target_signed == enc.signed
                and target_frac_bits == enc.frac_bits
            ):
                return signal
            helper_name = self._conversion_helper_name(
                "fixed",
                enc.width,
                enc.signed,
                enc.frac_bits,
                target_kind,
                target_width,
                target_signed,
                target_frac_bits,
            )
            return f"{helper_name}({signal})"
        return reference

    def _reference_signal(self, reference: str) -> str:
        head, _, tail = reference.partition(".")
        if head == "top":
            return tail
        return self._reference_signal_name(reference)

    def _top_port_config(self, port_name: str) -> PortConfig | None:
        assert self.system is not None
        return next((port for port in self.system.module_config.top_ports if port.name == port_name), None)

    def _convert_local_fixed_to_target(self, signal_name: str, target_kind: str, target_width: int, target_signed: bool) -> str:
        assert self.system is not None
        signal = self._state_name(signal_name)
        enc = self.system.module_config.real_encoding
        if target_kind == "fixed" and target_width == enc.width and target_signed == enc.signed:
            return signal
        helper_name = self._conversion_helper_name(
            "fixed",
            enc.width,
            enc.signed,
            enc.frac_bits,
            target_kind,
            target_width,
            target_signed,
            0,
        )
        return f"{helper_name}({signal})"

    def _external_output_to_target(
        self,
        signal: str,
        source_kind: str,
        source_width: int,
        source_signed: bool,
        source_frac_bits: int,
        target_kind: str,
        target_width: int,
        target_signed: bool,
        target_frac_bits: int,
    ) -> str:
        if (
            source_kind == target_kind
            and source_width == target_width
            and source_signed == target_signed
            and source_frac_bits == target_frac_bits
        ):
            return signal
        helper_name = self._conversion_helper_name(
            source_kind,
            source_width,
            source_signed,
            source_frac_bits,
            target_kind,
            target_width,
            target_signed,
            target_frac_bits,
        )
        return f"{helper_name}({signal})"

    def _reference_encoding(self, reference: str) -> tuple[str, int, bool, int]:
        assert self.system is not None
        head, _, tail = reference.partition(".")
        if head == "top":
            port = next((port for port in self.system.module_config.top_ports if port.name == tail), None)
            if tail == self.system.module_config.clock.name or tail == self.system.module_config.reset.name:
                return ("logic", 1, False, 0)
            if port is None:
                raise ValueError(f"Unknown top-level signal '{reference}'")
            return (port.kind, port.width, port.signed, 0 if port.kind != "fixed" else self.system.module_config.real_encoding.frac_bits)

        for item in self.system.imports:
            if item.alias == head:
                imported = item.system
                if tail in imported.output_variables:
                    enc = imported.module_config.real_encoding
                    return ("fixed", enc.width, enc.signed, enc.frac_bits)
                if tail in imported.input_variables:
                    enc = imported.module_config.real_encoding
                    return ("fixed", enc.width, enc.signed, enc.frac_bits)

        for item in self.system.externals:
            if item.alias == head:
                port = next(port for port in item.definition.ports if port.name == tail)
                frac_bits = self.system.module_config.real_encoding.frac_bits if port.kind == "fixed" else 0
                return (port.kind, port.width, port.signed, frac_bits)

        raise ValueError(f"Unknown connection reference '{reference}'")

    def _maybe_convert_signal(
        self,
        reference: str,
        signal: str,
        target_kind: str,
        target_width: int,
        target_signed: bool,
        target_frac_bits: int,
    ) -> str:
        source_kind, source_width, source_signed, source_frac_bits = self._reference_encoding(reference)
        if (
            source_kind == target_kind
            and source_width == target_width
            and source_signed == target_signed
            and source_frac_bits == target_frac_bits
        ):
            return signal
        if source_signed != target_signed and source_kind == "fixed":
            raise ValueError(f"Signedness mismatch for reference '{reference}'")
        helper_name = self._conversion_helper_name(
            source_kind,
            source_width,
            source_signed,
            source_frac_bits,
            target_kind,
            target_width,
            target_signed,
            target_frac_bits,
        )
        return f"{helper_name}({signal})"

    def _fixed_storage_decl(self, width: int, signed: bool) -> str:
        sign = " signed" if signed else ""
        return f"logic{sign} [{width - 1}:0]"

    def _encode_float(self, value: float, width: int, frac_bits: int, signed: bool) -> str:
        scaled = int(round(value * (2 ** frac_bits)))
        if signed:
            return f"{width}'sd{scaled}"
        masked = scaled % (1 << width)
        return f"{width}'d{masked}"

    def _literal_param_name(self, value: float, width: int, frac_bits: int, signed: bool) -> str:
        key = (value, width, frac_bits, signed)
        if key in self.literal_params:
            return self.literal_params[key]

        base = f"_VAL_{self._sanitize_literal_value(value)}"
        name = base
        suffix = 2
        while name in self.literal_params.values():
            name = f"{base}_{suffix}"
            suffix += 1
        self.literal_params[key] = name
        return name

    def _sanitize_literal_value(self, value: float) -> str:
        text = str(value)
        text = text.replace("-", "NEG_")
        text = text.replace(".", "_")
        return text

    def _fixed_literal_ref(self, value: float, width: int, frac_bits: int, signed: bool) -> str:
        return self._literal_param_name(value, width, frac_bits, signed)

    def _emit_literal_params(self) -> str:
        if not self.literal_params:
            return ""

        lines: list[str] = []
        for (value, width, frac_bits, signed), name in sorted(self.literal_params.items(), key=lambda item: item[1]):
            lines.append(f"// {name} = {value} in fixed-point Q{width - frac_bits}.{frac_bits}")
            lines.append(
                f"localparam {self._fixed_storage_decl(width, signed)} {name} = {self._encode_float(value, width, frac_bits, signed)};"
            )
        lines.append("")
        return "\n".join(lines)

    def visit(self, node) -> str:
        method_name = f"visit_{type(node).__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node) -> str:
        raise ValueError(f"Unsupported Verilog node type: {type(node).__name__}")

    def visit_ConstantExpression(self, node: ConstantExpression) -> str:
        return self._fixed_literal_ref(
            node.value.value,
            self.system.module_config.real_encoding.width,
            self.system.module_config.real_encoding.frac_bits,
            self.system.module_config.real_encoding.signed,
        )

    def visit_VariableExpression(self, node: VariableExpression) -> str:
        return self._state_name(node.variable.name)

    def visit_ReferenceExpression(self, node: ReferenceExpression) -> str:
        name = ".".join(node.parts)
        signal = self._reference_signal(name)
        return self._maybe_convert_signal(
            name,
            signal,
            "fixed",
            self.system.module_config.real_encoding.width,
            self.system.module_config.real_encoding.signed,
            self.system.module_config.real_encoding.frac_bits,
        )

    def _conversion_helper_name(
        self,
        source_kind: str,
        source_width: int,
        source_signed: bool,
        source_frac_bits: int,
        target_kind: str,
        target_width: int,
        target_signed: bool,
        target_frac_bits: int,
    ) -> str:
        key = (
            source_kind,
            source_width,
            source_signed,
            source_frac_bits,
            target_kind,
            target_width,
            target_signed,
            target_frac_bits,
        )
        if key not in self.conversion_helpers:
            self.conversion_helpers[key] = (
                f"conv_{self._conversion_descriptor(source_kind, source_width, source_signed, source_frac_bits)}"
                f"_to_{self._conversion_descriptor(target_kind, target_width, target_signed, target_frac_bits)}"
            )
        return self.conversion_helpers[key]

    def _conversion_descriptor(self, kind: str, width: int, signed: bool, frac_bits: int) -> str:
        sign = "s" if signed else "u"
        if kind == "fixed":
            return f"{sign}fixed_{width}_{frac_bits}"
        if kind == "int":
            return f"{sign}int_{width}"
        if width == 1:
            return "logic"
        return f"logic_{width}"

    def _type_decl(self, kind: str, width: int, signed: bool) -> str:
        if kind == "logic":
            if width == 1:
                return "logic"
            return f"logic [{width - 1}:0]"
        sign = " signed" if signed else ""
        if width == 1:
            return f"logic{sign}"
        return f"logic{sign} [{width - 1}:0]"

    def _emit_conversion_helpers(self) -> str:
        if not self.conversion_helpers:
            return ""

        helper_lines: list[str] = []
        for key, name in sorted(self.conversion_helpers.items(), key=lambda item: item[1]):
            (
                source_kind,
                source_width,
                source_signed,
                source_frac_bits,
                target_kind,
                target_width,
                target_signed,
                target_frac_bits,
            ) = key
            helper_lines.extend(
                self._build_conversion_helper(
                    name,
                    source_kind,
                    source_width,
                    source_signed,
                    source_frac_bits,
                    target_kind,
                    target_width,
                    target_signed,
                    target_frac_bits,
                )
            )
            helper_lines.append("")

        return "\n".join(helper_lines)

    def _build_conversion_helper(
        self,
        name: str,
        source_kind: str,
        source_width: int,
        source_signed: bool,
        source_frac_bits: int,
        target_kind: str,
        target_width: int,
        target_signed: bool,
        target_frac_bits: int,
    ) -> list[str]:
        input_decl = self._type_decl(source_kind, source_width, source_signed)
        output_decl = self._type_decl(target_kind, target_width, target_signed)
        expr = self._conversion_expression(
            source_kind,
            source_width,
            source_signed,
            source_frac_bits,
            target_kind,
            target_width,
            target_signed,
            target_frac_bits,
        )
        return [
            f"function automatic {output_decl} {name}(",
            f"    input {input_decl} value",
            ");",
            f"    {name} = {expr};",
            "endfunction",
        ]

    def _conversion_expression(
        self,
        source_kind: str,
        source_width: int,
        source_signed: bool,
        source_frac_bits: int,
        target_kind: str,
        target_width: int,
        target_signed: bool,
        target_frac_bits: int,
    ) -> str:
        if target_kind == "fixed":
            if source_kind == "fixed":
                delta = target_frac_bits - source_frac_bits
                if delta > 0:
                    return f"(value <<< {delta})"
                if delta < 0:
                    return f"(value >>> {-delta})"
                return "value"
            if source_kind == "int":
                if target_frac_bits > 0:
                    return f"(value <<< {target_frac_bits})"
                return "value"
            if source_kind == "logic":
                return f"(value ? {self._fixed_literal_ref(1.0, target_width, target_frac_bits, target_signed)} : '0)"

        if target_kind == "int":
            if source_kind == "fixed":
                if source_frac_bits > 0:
                    return f"((value >= '0) ? (value >>> {source_frac_bits}) : -((-value) >>> {source_frac_bits}))"
                return "value"
            if source_kind == "int":
                return "value"
            if source_kind == "logic":
                return f"(value ? {target_width}'d1 : '0)"

        if target_kind == "logic":
            if source_kind == "logic":
                return "value"
            if source_kind == "int":
                if target_width == 1:
                    return "(value != '0)"
                return "value"
            if source_kind == "fixed":
                if target_width == 1:
                    return "(value != '0)"
                if source_frac_bits > 0:
                    return f"(value >>> {source_frac_bits})"
                return "value"

        raise ValueError(
            f"Unsupported conversion from {source_kind}({source_width},{source_signed},{source_frac_bits}) "
            f"to {target_kind}({target_width},{target_signed},{target_frac_bits})"
        )

    def _state_name(self, variable_name: str) -> str:
        return f"state_{variable_name}"

    def visit_SumExpression(self, node: SumExpression) -> str:
        return f"({self.visit(node.left)} + {self.visit(node.right)})"

    def visit_DifferenceExpression(self, node: DifferenceExpression) -> str:
        return f"({self.visit(node.left)} - {self.visit(node.right)})"

    def visit_MultiplicationExpression(self, node: MultiplicationExpression) -> str:
        if not isinstance(node.left, ConstantExpression) and not isinstance(node.right, ConstantExpression):
            raise ValueError("Verilog export does not support variable-by-variable multiplication")
        return f"(({self.visit(node.left)} * {self.visit(node.right)}) >>> FRAC_BITS)"

    def visit_DivisionExpression(self, node: DivisionExpression) -> str:
        if not isinstance(node.right, ConstantExpression):
            raise ValueError("Verilog export does not support general division")
        return f"(({self.visit(node.left)} <<< FRAC_BITS) / {self.visit(node.right)})"

    def visit_UnaryMinusExpression(self, node: UnaryMinusExpression) -> str:
        return f"(-{self.visit(node.expression)})"

    def visit_IntMultiplicationExpression(self, node: IntMultiplicationExpression) -> str:
        return f"({node.constant} * {self.visit(node.expression)})"

    def visit_IntDivisionExpression(self, node: IntDivisionExpression) -> str:
        return f"({self.visit(node.expression)} / {node.constant})"

    def visit_BooleanConstantExpression(self, node: BooleanConstantExpression) -> str:
        return "1'b1" if node.value else "1'b0"

    def visit_BooleanAndExpression(self, node: BooleanAndExpression) -> str:
        return f"({self.visit(node.left)} && {self.visit(node.right)})"

    def visit_BooleanOrExpression(self, node: BooleanOrExpression) -> str:
        return f"({self.visit(node.left)} || {self.visit(node.right)})"

    def visit_BooleanNotExpression(self, node: BooleanNotExpression) -> str:
        return f"(!{self.visit(node.expression)})"

    def visit_BooleanLessTestExpression(self, node: BooleanLessTestExpression) -> str:
        return f"({self.visit(node.left)} < {self.visit(node.right)})"

    def visit_BooleanLessEqualTestExpression(self, node: BooleanLessEqualTestExpression) -> str:
        return f"({self.visit(node.left)} <= {self.visit(node.right)})"

    def visit_BooleanGreaterTestExpression(self, node: BooleanGreaterTestExpression) -> str:
        return f"({self.visit(node.left)} > {self.visit(node.right)})"

    def visit_BooleanGreaterEqualTestExpression(self, node: BooleanGreaterEqualTestExpression) -> str:
        return f"({self.visit(node.left)} >= {self.visit(node.right)})"

    def visit_BooleanEqualTestExpression(self, node: BooleanEqualTestExpression) -> str:
        return f"({self.visit(node.left)} == {self.visit(node.right)})"

    def visit_BooleanNotEqualTestExpression(self, node: BooleanNotEqualTestExpression) -> str:
        return f"({self.visit(node.left)} != {self.visit(node.right)})"
