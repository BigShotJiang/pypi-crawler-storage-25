"""Python transformer for converting GNPS AST to Python code using visitor pattern."""

from pathlib import Path
from typing import Any
from .base_transformer import BaseTransformer
from ..system import GnpsSystem
from ..parser.ast import *
from ..parser.ast.value import *


class PythonTransformer(BaseTransformer):
    """Transformer that converts GNPS systems to Python code using proper visitor pattern."""

    def __init__(self):
        super().__init__()
        self.variable_declarations = set()
        self.composed_mode = False
        self.class_names: dict[Path, str] = {}

    def _zero_reset_mode(self, system: GnpsSystem) -> bool:
        module_config = getattr(system, "module_config", None)
        return bool(getattr(module_config, "zero_reset_mode", False))

    def get_file_extension(self) -> str:
        """Get the file extension for Python files."""
        return ".py"

    def transform(self, system: GnpsSystem) -> str:
        """Transform a GNPS system to Python code.

        Args:
            system: The GNPS system to transform

        Returns:
            Python code as a string
        """
        self.reset()
        self.variable_declarations = set()
        self.composed_mode = bool(getattr(system, "imports", []))
        self.class_names = {}

        system_dict = getattr(system, "__dict__", {})
        if system_dict.get("externals"):
            raise ValueError("Python transformation does not support external modules yet")
        if system_dict.get("imports"):
            return self._transform_composed(system)

        # Add imports and header
        self.add_line("# Generated Python code from GNPS system")
        self.add_line("import math")
        self.add_line()

        # Add class definition
        self.add_line("class GnpsSystem:")
        self.add_line("def __init__(self):", 1)

        # Initialize variables from all cells
        for cell in system.cells:
            for var_name, variable in cell.contents.items():
                if var_name not in self.variable_declarations:
                    initial_value = self.visit_value(variable.value)
                    self.add_line(f"self.{var_name} = {initial_value}", 2)
                    self.variable_declarations.add(var_name)
                else: # pragma: no cover
                    pass

        # Store input and output variable names
        input_vars = list(system.input_variables.keys()) if system.input_variables else []
        output_vars = list(system.output_variables.keys()) if system.output_variables else []

        self.add_line()

        # Add step method with input/output handling
        if input_vars:
            # When input variables exist, inputs parameter is required
            self.add_line("def step(self, inputs):", 1)
            self.add_line('"""Execute one step of the GNPS system.', 2)
            self.add_line("", 2)
            self.add_line("Args:", 2)
            self.add_line("inputs: Dictionary with input variable values (required)", 3)
            self.add_line("", 2)
            self.add_line("Returns:", 2)
            self.add_line("Dictionary with output variable values", 3)
            self.add_line('"""', 2)

            # Validate that all input variables are provided
            self.add_line("# Validate that all input variables are provided", 2)
            self.add_line(f"required_inputs = {input_vars}", 2)
            self.add_line("for var_name in required_inputs:", 2)
            self.add_line("if var_name not in inputs:", 3)
            self.add_line(f"raise ValueError(f'Input variable {{var_name}} is required but not provided')", 4)
            self.add_line()

            # Update input variables
            self.add_line("# Update input variables", 2)
            for var_name in input_vars:
                self.add_line(f"self.{var_name} = inputs['{var_name}']", 2)
            self.add_line()
        else:
            # When no input variables, inputs parameter is optional (absent)
            self.add_line("def step(self):", 1)
            self.add_line('"""Execute one step of the GNPS system.', 2)
            self.add_line("", 2)
            self.add_line("Returns:", 2)
            if output_vars:
                self.add_line("Dictionary with output variable values", 3)
            else:
                self.add_line("Dictionary with all variable values", 3)
            self.add_line('"""', 2)

        # GNPS algorithm implementation
        self.add_line("# GNPS step using _new variables approach", 2)
        self.add_line()

        # Step 1: Initialize _new versions of all variables
        zero_reset_mode = self._zero_reset_mode(system)
        step_mode_label = "zero" if zero_reset_mode else "current"
        self.add_line(f"# Step 1: Initialize _new versions of all variables from {step_mode_label} state", 2)
        var_names = sorted(self.variable_declarations)
        for var_name in var_names:
            if zero_reset_mode and var_name not in input_vars:
                self.add_line(f"{var_name}_new = 0.0", 2)
            else:
                self.add_line(f"{var_name}_new = self.{var_name}", 2)
        self.add_line()

        if not zero_reset_mode:
            # Step 2: Track used variables for rules whose guards hold
            self.add_line("# Step 2: Track variables consumed by active rules", 2)
            self.add_line("used_vars = set()", 2)
            self.add_line()

        # Step 3: Evaluate rules, apply productions, and mark consumed vars
        if zero_reset_mode:
            self.add_line("# Step 2: Evaluate active rules and accumulate productions", 2)
        else:
            self.add_line("# Step 3: Evaluate active rules and collect consumed variables", 2)
        for i, rule in enumerate(system.rules):
            self.add_line(f"# Rule {i + 1}", 2)
            guard_code = self.visit(rule.guard)
            producer_code = self.visit(rule.producer)
            consumer_name = rule.consumer.name if hasattr(rule.consumer, 'name') else str(rule.consumer)
            producer_vars = sorted(self._get_producer_variables(rule.producer))

            self.add_line(f"if {guard_code}:", 2)
            self.add_line(f"{consumer_name}_new += {producer_code}", 3)
            if not zero_reset_mode:
                for var_name in producer_vars:
                    self.add_line(f"used_vars.add('{var_name}')", 3)
            self.add_line()

        if not zero_reset_mode:
            # Step 4: Remove consumed old values from variables used by active rules
            self.add_line("# Step 4: Remove old values from dynamically used variables", 2)
            for var_name in var_names:
                self.add_line(f"if '{var_name}' in used_vars:", 2)
                self.add_line(f"{var_name}_new -= self.{var_name}", 3)
            self.add_line()

        # Step 5: Update all variables to their _new values
        final_step = 3 if zero_reset_mode else 5
        self.add_line(f"# Step {final_step}: Update all variables to their final values", 2)
        for var_name in var_names:
            self.add_line(f"self.{var_name} = {var_name}_new", 2)

        # Return output variables
        self.add_line()
        if output_vars:
            self.add_line("# Return output variables", 2)
            self.add_line("return {", 2)
            for var_name in output_vars:
                self.add_line(f"'{var_name}': self.{var_name},", 3)
            self.add_line("}", 2)
        else:
            self.add_line("# No output variables defined, return all variables", 2)
            self.add_line("return self.get_variables()", 2)

        # Add method to get all variables
        self.add_line()
        self.add_line("def get_variables(self):", 1)
        self.add_line("return {", 2)
        for var_name in self.variable_declarations:
            self.add_line(f"'{var_name}': self.{var_name},", 3)
        self.add_line("}", 2)

        # Add main function for CSV processing
        self.add_line()
        self.add_line()
        self.add_line("def format_float(value):", 0)
        self.add_line('"""Format float values with proper precision."""', 1)
        self.add_line("if isinstance(value, (int, float)):", 1)
        self.add_line('return f"{value:.6f}".rstrip("0").rstrip(".")', 2)
        self.add_line("return str(value)", 1)
        self.add_line()
        self.add_line()
        self.add_line("def main():", 0)
        self.add_line('"""Main function for CSV processing."""', 1)
        self.add_line("import sys", 1)
        self.add_line("import csv", 1)
        self.add_line("import argparse", 1)
        self.add_line()

        # Parse command line arguments
        self.add_line("parser = argparse.ArgumentParser(description='GNPS System Simulator')", 1)
        if input_vars:
            # For systems with input variables, no steps parameter (run until input is exhausted)
            self.add_line("args = parser.parse_args()", 1)
        else:
            # For systems without input, steps is required
            self.add_line("parser.add_argument('steps', type=int, help='Number of steps to execute')", 1)
            self.add_line("args = parser.parse_args()", 1)
        self.add_line()

        # Initialize system
        self.add_line("system = GnpsSystem()", 1)
        self.add_line()

        if input_vars:
            # CSV processing for systems with input variables
            self.add_line("# Read CSV from stdin", 1)
            self.add_line("reader = csv.DictReader(sys.stdin)", 1)
            self.add_line("writer = None", 1)
            self.add_line()

            # Changed to continuous processing (no steps parameter)
            self.add_line("step_num = 0", 1)
            self.add_line("# Process all input rows until exhausted", 1)
            self.add_line("while True:", 1)
            self.add_line("try:", 2)
            self.add_line("# Read next input row", 3)
            self.add_line("input_row = next(reader)", 3)

            # Convert input values to appropriate types
            self.add_line("# Convert input values to float", 3)
            self.add_line("inputs = {}", 3)
            for var_name in input_vars:
                self.add_line(f"if '{var_name}' in input_row:", 3)
                self.add_line(f"inputs['{var_name}'] = float(input_row['{var_name}'])", 4)
                self.add_line(f"else:", 3)
                self.add_line(f"print(f'Error: Input variable {var_name} not found in CSV row {{step_num + 1}}', file=sys.stderr)", 4)
                self.add_line("sys.exit(1)", 4)
            self.add_line()

            # Execute step and get output
            self.add_line("# Execute step", 3)
            self.add_line("output = system.step(inputs)", 3)
            self.add_line()

            # Write output to CSV
            if output_vars:
                self.add_line("# Initialize CSV writer on first row", 3)
                self.add_line("if writer is None:", 3)
                self.add_line(f"fieldnames = ['step'] + {output_vars}", 4)
                self.add_line("writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames)", 4)
                self.add_line("writer.writeheader()", 4)
                self.add_line()

                self.add_line("# Write output row with step number and formatted values", 3)
                self.add_line("output_row = {'step': step_num + 1}", 3)
                self.add_line("formatted_output = {k: format_float(v) for k, v in output.items()}", 3)
                self.add_line("output_row.update(formatted_output)", 3)
                self.add_line("writer.writerow(output_row)", 3)

            self.add_line("step_num += 1", 3)

            self.add_line("except StopIteration:", 2)
            self.add_line("# No more input rows, processing complete", 3)
            self.add_line("if step_num == 0:", 3)
            self.add_line("print('Warning: No input data found.', file=sys.stderr)", 4)
            self.add_line("else:", 3)
            self.add_line("print(f'Processed {step_num} input rows successfully.', file=sys.stderr)", 4)
            self.add_line("break", 3)
            self.add_line()
        else:
            # No input variables - run steps and output CSV for each step
            self.add_line("# No input variables - run steps and output CSV for each step", 1)
            self.add_line("writer = None", 1)
            self.add_line()

            # Add step 0 output (initial state)
            if output_vars:
                self.add_line("# Initialize CSV writer", 1)
                self.add_line(f"fieldnames = ['step'] + {output_vars}", 1)
                self.add_line("writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames)", 1)
                self.add_line("writer.writeheader()", 1)
                self.add_line()
                self.add_line("# Write initial state (step 0) with formatted values", 1)
                self.add_line("initial_output = {", 1)
                for var_name in output_vars:
                    self.add_line(f"'{var_name}': format_float(system.{var_name}),", 2)
                self.add_line("}", 1)
                self.add_line("step0_row = {'step': 0}", 1)
                self.add_line("step0_row.update(initial_output)", 1)
                self.add_line("writer.writerow(step0_row)", 1)
                self.add_line()
            else:
                self.add_line("# Initialize CSV writer with all variables", 1)
                self.add_line("all_vars = system.get_variables()", 1)
                self.add_line("fieldnames = ['step'] + list(all_vars.keys())", 1)
                self.add_line("writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames)", 1)
                self.add_line("writer.writeheader()", 1)
                self.add_line()
                self.add_line("# Write initial state (step 0) with formatted values", 1)
                self.add_line("step0_row = {'step': 0}", 1)
                self.add_line("formatted_all_vars = {k: format_float(v) for k, v in all_vars.items()}", 1)
                self.add_line("step0_row.update(formatted_all_vars)", 1)
                self.add_line("writer.writerow(step0_row)", 1)
                self.add_line()

            self.add_line("for step_num in range(args.steps):", 1)
            if output_vars:
                self.add_line("output = system.step()", 2)
                self.add_line("# Write output row with step number and formatted values", 2)
                self.add_line("output_row = {'step': step_num + 1}", 2)
                self.add_line("formatted_output = {k: format_float(v) for k, v in output.items()}", 2)
                self.add_line("output_row.update(formatted_output)", 2)
                self.add_line("writer.writerow(output_row)", 2)
            else:
                self.add_line("system.step()", 2)
                self.add_line("all_vars = system.get_variables()", 2)
                self.add_line("# Write row with step number and formatted values", 2)
                self.add_line("all_vars_row = {'step': step_num + 1}", 2)
                self.add_line("formatted_all_vars = {k: format_float(v) for k, v in all_vars.items()}", 2)
                self.add_line("all_vars_row.update(formatted_all_vars)", 2)
                self.add_line("writer.writerow(all_vars_row)", 2)

        self.add_line()
        self.add_line()
        self.add_line("if __name__ == '__main__':", 0)
        self.add_line("main()", 1)

        return self.get_output()

    def _transform_composed(self, system: GnpsSystem) -> str:
        self.add_line("# Generated Python code from composed GNPS system")
        self.add_line("import math")
        self.add_line()

        self._collect_class_names(system)
        self._emit_base_class()

        emitted: set[Path] = set()
        self._emit_module_class(system, emitted)
        root_base = self._class_name(system)
        self.add_line(f"class GnpsSystem({root_base}):")
        self.add_line("pass", 1)
        self.add_line()

        self._emit_main_function(system)
        return self.get_output()

    def _collect_class_names(self, system: GnpsSystem):
        ordered = self._module_closure(system)
        used: dict[str, int] = {}
        for module in ordered:
            assert module.source_path is not None
            base = self._sanitize_class_name(module.module_config.name)
            count = used.get(base, 0) + 1
            used[base] = count
            suffix = "" if count == 1 else f"_{count}"
            self.class_names[module.source_path] = f"_Module_{base}{suffix}"

    def _module_closure(self, system: GnpsSystem) -> list[GnpsSystem]:
        ordered: list[GnpsSystem] = []
        seen: set[Path] = set()

        def visit(module: GnpsSystem):
            assert module.source_path is not None
            if module.source_path in seen:
                return
            seen.add(module.source_path)
            for item in module.imports:
                assert item.system is not None
                visit(item.system)
            ordered.append(module)

        visit(system)
        return ordered

    def _sanitize_class_name(self, name: str) -> str:
        pieces = []
        for char in name:
            pieces.append(char if char.isalnum() else "_")
        sanitized = "".join(pieces).strip("_") or "Gnps"
        if sanitized[0].isdigit():
            sanitized = f"_{sanitized}"
        return sanitized

    def _class_name(self, system: GnpsSystem) -> str:
        assert system.source_path is not None
        return self.class_names[system.source_path]

    def _emit_base_class(self):
        self.add_line("class _GnpsModuleBase:")
        self.add_line("def _ref(self, reference):", 1)
        self.add_line("head, _, tail = reference.partition('.')", 2)
        self.add_line("if head == 'top':", 2)
        self.add_line("raise ValueError('Generated Python does not support top.* references')", 3)
        self.add_line("module = getattr(self, f'_import_{head}', None)", 2)
        self.add_line("if module is None:", 2)
        self.add_line("raise ValueError(f'Unknown import reference {reference}')", 3)
        self.add_line("return getattr(module, tail)", 2)
        self.add_line()
        self.add_line("def _coerce_inputs(self, inputs, required_inputs):", 1)
        self.add_line("inputs = inputs or {}", 2)
        self.add_line("for var_name in required_inputs:", 2)
        self.add_line("if var_name not in inputs:", 3)
        self.add_line("raise ValueError(f'Input variable {var_name} is required but not provided')", 4)
        self.add_line("return inputs", 2)
        self.add_line()

    def _emit_module_class(self, system: GnpsSystem, emitted: set[Path]):
        assert system.source_path is not None
        if system.source_path in emitted:
            return
        for item in system.imports:
            assert item.system is not None
            self._emit_module_class(item.system, emitted)

        class_name = self._class_name(system)
        self.add_line(f"class {class_name}(_GnpsModuleBase):")
        self.add_line("def __init__(self):", 1)
        for cell in system.cells:
            for var_name, variable in cell.contents.items():
                self.add_line(f"self.{var_name} = {self.visit_value(variable.value)}", 2)
        for item in system.imports:
            assert item.system is not None
            self.add_line(f"self._import_{item.alias} = {self._class_name(item.system)}()", 2)
        if not system.cells and not system.imports:
            self.add_line("pass", 2)
        self.add_line()

        input_vars = list(system.input_variables.keys())
        output_vars = list(system.output_variables.keys())
        signature = "inputs=None"
        self.add_line(f"def step(self, {signature}):", 1)
        self.add_line(f"required_inputs = {input_vars}", 2)
        self.add_line("inputs = self._coerce_inputs(inputs, required_inputs)", 2)
        if input_vars:
            self.add_line("# Update input variables", 2)
            for var_name in input_vars:
                self.add_line(f"self.{var_name} = float(inputs['{var_name}'])", 2)
            self.add_line()

        for item in system._direct_import_step_order():
            assert item.system is not None
            child_inputs = []
            for input_name in item.system.input_variables.keys():
                ref = item.connections.get(input_name)
                if ref is None:
                    child_inputs.append(f"'{input_name}': 0.0")
                elif "." in ref:
                    child_inputs.append(f"'{input_name}': float({self._reference_code(ref)})")
                elif ref in system.constants:
                    child_inputs.append(f"'{input_name}': {system.constants[ref].value}")
                elif ref.replace('.', '', 1).lstrip('-').isdigit():
                    child_inputs.append(f"'{input_name}': {float(ref)}")
                else:
                    child_inputs.append(f"'{input_name}': float(self.{ref})")
            self.add_line(f"self._import_{item.alias}.step({{{', '.join(child_inputs)}}})", 2)
        if system.imports:
            self.add_line()

        var_names = sorted(system.variables.keys())
        zero_reset_mode = self._zero_reset_mode(system)
        step_mode_label = "zero" if zero_reset_mode else "current"
        self.add_line(f"# Step 1: Initialize _new versions of all variables from {step_mode_label} state", 2)
        for var_name in var_names:
            if zero_reset_mode and var_name not in input_vars:
                self.add_line(f"{var_name}_new = 0.0", 2)
            else:
                self.add_line(f"{var_name}_new = self.{var_name}", 2)
        self.add_line()
        if not zero_reset_mode:
            self.add_line("# Step 2: Track variables consumed by active rules", 2)
            self.add_line("used_vars = set()", 2)
            self.add_line()
        if zero_reset_mode:
            self.add_line("# Step 2: Evaluate active rules and accumulate productions", 2)
        else:
            self.add_line("# Step 3: Evaluate active rules and collect consumed variables", 2)
        for i, rule in enumerate(system.rules):
            self.add_line(f"# Rule {i + 1}", 2)
            guard_code = self.visit(rule.guard)
            producer_code = self.visit(rule.producer)
            consumer_name = rule.consumer.name
            producer_vars = sorted(self._get_producer_variables(rule.producer))
            self.add_line(f"if {guard_code}:", 2)
            self.add_line(f"{consumer_name}_new += {producer_code}", 3)
            if not zero_reset_mode:
                for var_name in producer_vars:
                    self.add_line(f"used_vars.add('{var_name}')", 3)
            self.add_line()
        if not zero_reset_mode:
            self.add_line("# Step 4: Remove old values from dynamically used variables", 2)
            for var_name in var_names:
                self.add_line(f"if '{var_name}' in used_vars:", 2)
                self.add_line(f"{var_name}_new -= self.{var_name}", 3)
            self.add_line()
        final_step = 3 if zero_reset_mode else 5
        self.add_line(f"# Step {final_step}: Update all variables to their final values", 2)
        for var_name in var_names:
            self.add_line(f"self.{var_name} = {var_name}_new", 2)
        self.add_line()
        if output_vars:
            self.add_line("return {", 2)
            for var_name in output_vars:
                self.add_line(f"'{var_name}': self.{var_name},", 3)
            self.add_line("}", 2)
        else:
            self.add_line("return self.get_variables()", 2)
        self.add_line()
        self.add_line("def get_variables(self):", 1)
        self.add_line("return {", 2)
        for var_name in var_names:
            self.add_line(f"'{var_name}': self.{var_name},", 3)
        self.add_line("}", 2)
        self.add_line()
        emitted.add(system.source_path)

    def _emit_main_function(self, system: GnpsSystem):
        input_vars = list(system.input_variables.keys())
        output_vars = list(system.output_variables.keys())
        self.add_line("def format_float(value):")
        self.add_line("if isinstance(value, (int, float)):", 1)
        self.add_line('return f"{value:.6f}".rstrip("0").rstrip(".")', 2)
        self.add_line("return str(value)", 1)
        self.add_line()
        self.add_line("def main():")
        self.add_line("import sys", 1)
        self.add_line("import csv", 1)
        self.add_line("import argparse", 1)
        self.add_line("parser = argparse.ArgumentParser(description='GNPS System Simulator')", 1)
        if not input_vars:
            self.add_line("parser.add_argument('steps', type=int, help='Number of steps to execute')", 1)
        self.add_line("args = parser.parse_args()", 1)
        self.add_line("system = GnpsSystem()", 1)
        self.add_line()
        if input_vars:
            self.add_line("reader = csv.DictReader(sys.stdin)", 1)
            self.add_line("writer = None", 1)
            self.add_line("step_num = 0", 1)
            self.add_line("while True:", 1)
            self.add_line("try:", 2)
            self.add_line("input_row = next(reader)", 3)
            self.add_line("inputs = {}", 3)
            for var_name in input_vars:
                self.add_line(f"if '{var_name}' in input_row:", 3)
                self.add_line(f"inputs['{var_name}'] = float(input_row['{var_name}'])", 4)
                self.add_line("else:", 3)
                self.add_line(f"raise ValueError('Input variable {var_name} not found in CSV row')", 4)
            self.add_line("output = system.step(inputs)", 3)
            self.add_line("if writer is None:", 3)
            self.add_line(f"fieldnames = ['step'] + {output_vars}", 4)
            self.add_line("writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames)", 4)
            self.add_line("writer.writeheader()", 4)
            self.add_line("row = {'step': step_num + 1}", 3)
            self.add_line("row.update({k: format_float(v) for k, v in output.items()})", 3)
            self.add_line("writer.writerow(row)", 3)
            self.add_line("step_num += 1", 3)
            self.add_line("except StopIteration:", 2)
            self.add_line("break", 3)
        else:
            if output_vars:
                self.add_line(f"fieldnames = ['step'] + {output_vars}", 1)
            else:
                self.add_line("fieldnames = ['step'] + list(system.get_variables().keys())", 1)
            self.add_line("writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames)", 1)
            self.add_line("writer.writeheader()", 1)
            if output_vars:
                self.add_line("row0 = {'step': 0}", 1)
                self.add_line("row0.update({", 1)
                for var_name in output_vars:
                    self.add_line(f"'{var_name}': format_float(system.{var_name}),", 2)
                self.add_line("})", 1)
                self.add_line("writer.writerow(row0)", 1)
                self.add_line("for step_num in range(args.steps):", 1)
                self.add_line("output = system.step()", 2)
                self.add_line("row = {'step': step_num + 1}", 2)
                self.add_line("row.update({k: format_float(v) for k, v in output.items()})", 2)
                self.add_line("writer.writerow(row)", 2)
            else:
                self.add_line("row0 = {'step': 0}", 1)
                self.add_line("row0.update({k: format_float(v) for k, v in system.get_variables().items()})", 1)
                self.add_line("writer.writerow(row0)", 1)
                self.add_line("for step_num in range(args.steps):", 1)
                self.add_line("system.step()", 2)
                self.add_line("row = {'step': step_num + 1}", 2)
                self.add_line("row.update({k: format_float(v) for k, v in system.get_variables().items()})", 2)
                self.add_line("writer.writerow(row)", 2)
        self.add_line()
        self.add_line("if __name__ == '__main__':")
        self.add_line("main()", 1)

    def _reference_code(self, reference: str) -> str:
        if "." in reference:
            return f"self._ref('{reference}')"
        return f"self.{reference}"

    def _get_producer_variables(self, producer_expr) -> set:
        """Extract variable names used in a producer expression."""
        variables = set()

        # Get all variables from the expression
        if hasattr(producer_expr, 'get_variables'):
            expr_vars = producer_expr.get_variables()
            variables.update(expr_vars.keys())

        return variables

    def visit(self, node) -> str:
        """Generic visit method that dispatches to specific visitor methods."""
        method_name = f'visit_{type(node).__name__}'
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node) -> str:
        """Default visitor for unknown node types."""
        return f"# Unknown node type: {type(node).__name__}"

    # Expression visitors
    def visit_ConstantExpression(self, node: ConstantExpression) -> str:
        """Visit a constant expression."""
        return self.visit_value(node.value)

    def visit_VariableExpression(self, node: VariableExpression) -> str:
        """Visit a variable expression."""
        return f"self.{node.variable.name}"

    def visit_ReferenceExpression(self, node: ReferenceExpression) -> str:
        """Visit a qualified reference expression."""
        reference = ".".join(node.parts)
        if self.composed_mode:
            return self._reference_code(reference)
        return reference

    def visit_SumExpression(self, node: SumExpression) -> str:
        """Visit a sum expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} + {right})"

    def visit_DifferenceExpression(self, node: DifferenceExpression) -> str:
        """Visit a difference expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} - {right})"

    def visit_MultiplicationExpression(self, node: MultiplicationExpression) -> str:
        """Visit a multiplication expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} * {right})"

    def visit_DivisionExpression(self, node: DivisionExpression) -> str:
        """Visit a division expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} / {right})"

    def visit_UnaryMinusExpression(self, node: UnaryMinusExpression) -> str:
        """Visit a unary minus expression."""
        operand = self.visit(node.expression)
        return f"(-{operand})"

    def visit_IntMultiplicationExpression(self, node: IntMultiplicationExpression) -> str:
        """Visit an integer multiplication expression."""
        operand = self.visit(node.expression)
        return f"({node.constant} * {operand})"

    def visit_IntDivisionExpression(self, node: IntDivisionExpression) -> str:
        """Visit an integer division expression."""
        operand = self.visit(node.expression)
        return f"({operand} / {node.constant})"

    def visit_FunctionCallExpression(self, node) -> str:
        """Visit a function call expression."""
        args = [self.visit(arg) for arg in node.arguments]
        args_str = ", ".join(args)

        # Map common mathematical functions to Python's math module
        function_mappings = {
            'sin': 'math.sin',
            'cos': 'math.cos',
            'tan': 'math.tan',
            'exp': 'math.exp',
            'log': 'math.log',
            'sqrt': 'math.sqrt',
            'pow': 'math.pow',
            'abs': 'abs',
            'floor': 'math.floor',
            'ceil': 'math.ceil',
            'pi': 'math.pi',
            'e': 'math.e'
        }

        python_function = function_mappings.get(node.function_name, node.function_name)

        # Handle constants (0-ary functions) differently
        if len(node.arguments) == 0:
            return python_function
        else:
            return f"{python_function}({args_str})"

    # Boolean expression visitors
    def visit_BooleanConstantExpression(self, node: BooleanConstantExpression) -> str:
        """Visit a boolean constant expression."""
        return "True" if node.value else "False"

    def visit_BooleanAndExpression(self, node: BooleanAndExpression) -> str:
        """Visit a boolean AND expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} and {right})"

    def visit_BooleanOrExpression(self, node: BooleanOrExpression) -> str:
        """Visit a boolean OR expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} or {right})"

    def visit_BooleanNotExpression(self, node: BooleanNotExpression) -> str:
        """Visit a boolean NOT expression."""
        operand = self.visit(node.expression)
        return f"(not {operand})"

    def visit_BooleanLessTestExpression(self, node: BooleanLessTestExpression) -> str:
        """Visit a boolean less than expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} < {right})"

    def visit_BooleanLessEqualTestExpression(self, node: BooleanLessEqualTestExpression) -> str:
        """Visit a boolean less than or equal expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} <= {right})"

    def visit_BooleanGreaterTestExpression(self, node: BooleanGreaterTestExpression) -> str:
        """Visit a boolean greater than expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} > {right})"

    def visit_BooleanGreaterEqualTestExpression(self, node: BooleanGreaterEqualTestExpression) -> str:
        """Visit a boolean greater than or equal expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} >= {right})"

    def visit_BooleanEqualTestExpression(self, node: BooleanEqualTestExpression) -> str:
        """Visit a boolean equality expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} == {right})"

    def visit_BooleanNotEqualTestExpression(self, node: BooleanNotEqualTestExpression) -> str:
        """Visit a boolean not equal expression."""
        left = self.visit(node.left)
        right = self.visit(node.right)
        return f"({left} != {right})"

    def visit_value(self, value: Any) -> str:
        """Visit a value node and return Python representation."""
        if hasattr(value, 'value'):
            if isinstance(value.value, (int, float)):
                return str(value.value)
            elif isinstance(value.value, list): # pragma: no cover
                # Handle array values
                return f"[{', '.join(str(v) for v in value.value)}]"
        return str(value)
