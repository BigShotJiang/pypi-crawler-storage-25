"""CLI tool for transforming GNPS systems to various output formats."""

import argparse
import os
import sys
from pathlib import Path
from typing import Dict, Type

from gnps.system import GnpsSystem
from gnps.transformers import BaseTransformer, PythonTransformer, VerilogTransformer
from gnps._version import __version__


# Registry of available transformers
TRANSFORMERS: Dict[str, Type[BaseTransformer]] = {
    'python': PythonTransformer,
    'verilog': VerilogTransformer,
}


def get_transformer(transform_type: str) -> BaseTransformer:
    """Get a transformer instance by type name.

    Args:
        transform_type: The type of transformer to create

    Returns:
        Transformer instance

    Raises:
        ValueError: If transform_type is not supported
    """
    if transform_type not in TRANSFORMERS:
        available = ', '.join(TRANSFORMERS.keys())
        raise ValueError(f"Unsupported transformation type '{transform_type}'. Available types: {available}")

    return TRANSFORMERS[transform_type]()


def main():
    """Main entry point for the gnps-transformer CLI."""
    parser = argparse.ArgumentParser(
        description=f"GNPS Transformer v{__version__} - Convert GNPS systems to various output formats",
        prog='gnps-transformer'
    )

    parser.add_argument(
        'gnps_files',
        nargs='+',
        help='GNPS system files (.yaml) to transform'
    )

    parser.add_argument(
        '-t', '--type',
        dest='transform_type',
        required=True,
        choices=list(TRANSFORMERS.keys()),
        help='Transformation type'
    )

    parser.add_argument(
        '-o', '--output-dir',
        type=Path,
        default=Path('.'),
        help='Output directory for transformed files (default: current directory)'
    )

    parser.add_argument(
        '--output-suffix',
        default='',
        help='Suffix to add to output filenames (before extension)'
    )

    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose output'
    )
    parser.add_argument(
        '--import-path',
        action='append',
        default=[],
        help='Additional directory to search for imported GNPS files and external headers'
    )
    parser.add_argument(
        '--import-paths',
        default='',
        help='Path-separated list of additional import directories'
    )

    args = parser.parse_args()

    # Ensure output directory exists
    args.output_dir.mkdir(parents=True, exist_ok=True)

    # Get transformer
    try:
        transformer = get_transformer(args.transform_type)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    extra_import_paths = list(args.import_path)
    if args.import_paths:
        extra_import_paths.extend([path for path in args.import_paths.split(os.pathsep) if path])

    # Process each file
    for gnps_file_path in args.gnps_files:
        gnps_file = Path(gnps_file_path)

        if not gnps_file.exists():
            print(f"Error: File '{gnps_file}' not found", file=sys.stderr)
            continue

        if args.verbose:
            print(f"Processing: {gnps_file}")

        try:
            # Load GNPS system
            gnps_system = GnpsSystem.from_yaml(str(gnps_file), import_paths=extra_import_paths)

            # Verilog emits one file per module in the import closure.
            # Python emits one composed file for the root system only.
            if args.transform_type == "verilog":
                systems_to_emit = _collect_import_closure(gnps_system)
            else:
                systems_to_emit = [gnps_system]
            for system in systems_to_emit:
                transformed_code = transformer.transform(system)
                source_path = getattr(system, "__dict__", {}).get("source_path") or gnps_file
                base_name = source_path.stem
                if args.output_suffix:
                    base_name += args.output_suffix

                output_file = args.output_dir / (base_name + transformer.get_file_extension())

                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(transformed_code)

                if args.verbose:
                    print(f"  -> {output_file}")

        except Exception as e:
            print(f"Error processing '{gnps_file}': {e}", file=sys.stderr)
            if args.verbose:   # pragma: no cover
                import traceback
                traceback.print_exc()
            continue

    if args.verbose:
        print("Transformation complete.")

def _collect_import_closure(root: GnpsSystem) -> list[GnpsSystem]:
    seen: set[str] = set()
    ordered: list[GnpsSystem] = []

    def visit(system: GnpsSystem):
        source_key = str(getattr(system, "source_path", None) or id(system))
        if source_key in seen:
            return
        seen.add(source_key)
        imports = getattr(system, "__dict__", {}).get("imports", [])
        for item in imports or []:
            if getattr(item, "system", None) is not None:
                visit(item.system)
        ordered.append(system)

    visit(root)
    return ordered


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f"Error: {e}")
