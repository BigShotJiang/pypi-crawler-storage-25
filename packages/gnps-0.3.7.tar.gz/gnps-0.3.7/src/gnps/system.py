from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

from .cell import Cell
from .hardware import (
    ClockConfig,
    ExternalInstance,
    ExternalModuleHeader,
    ImportConfig,
    ModuleConfig,
    PortConfig,
    RealEncoding,
    ResetConfig,
)
from .parser import parse_condition, parse_expression, parse_rule, parse_variable_assignment
from .parser.ast import (
    BooleanAndExpression,
    BooleanConstantExpression,
    BooleanEqualTestExpression,
    BooleanExpression,
    BooleanGreaterEqualTestExpression,
    BooleanGreaterTestExpression,
    BooleanLessEqualTestExpression,
    BooleanLessTestExpression,
    BooleanNotEqualTestExpression,
    BooleanNotExpression,
    BooleanOrExpression,
    ConstantExpression,
    DifferenceExpression,
    DivisionExpression,
    Expression,
    IntDivisionExpression,
    IntMultiplicationExpression,
    MultiplicationExpression,
    ReferenceExpression,
    SumExpression,
    UnaryMinusExpression,
    VariableExpression,
)
from .parser.ast.expression import FunctionCallExpression
from .parser.ast.variable import Variable
from .parser.ast.value import FloatValue
from .parser.ast.value.math_functions import MathFunctions
from .rule import Rule


@dataclass(slots=True)
class ResolvedReference:
    kind: str
    path: str


class GnpsSystem:
    """A GNPS system is a collection of cells, rules, and optional HW metadata."""

    cells: list[Cell]
    rules: list[Rule]
    variables: dict[str, Variable]
    input_variables: dict[str, Variable]
    output_variables: dict[str, Variable]

    def __init__(self):
        self.cells = []
        self.rules = []
        self.variables = {}
        self.input_variables = {}
        self.output_variables = {}
        self.module_config = ModuleConfig(name="gnps")
        self.constants: dict[str, FloatValue] = {}
        self.aliases: dict[str, Expression] = {}
        self.imports: list[ImportConfig] = []
        self.externals: list[ExternalInstance] = []
        self.source_path: Path | None = None
        self.metadata: dict[str, str] = {}

    def add_cell(self, cell: Cell):
        self.cells.append(cell)
        self.variables.update(cell.contents)

    def add_rule(self, rule: Rule):
        self.rules.append(rule)

    def get_variable(self, variable_name):
        return self.variables.get(variable_name, None)

    def _resolve_runtime_reference(self, reference: str) -> FloatValue:
        head, _, tail = reference.partition(".")
        if head == "top":
            raise ValueError("The Python simulator does not support top.* references")

        for item in self.imports:
            if item.alias == head:
                if item.system is None:
                    raise ValueError(f"Import '{head}' is not resolved")
                variable = item.system.variables.get(tail)
                if variable is None:
                    raise ValueError(f"Unknown imported reference '{reference}'")
                return variable.value

        raise ValueError(f"Unknown runtime reference '{reference}'")

    def _evaluate_expression(self, node: Expression) -> FloatValue:
        if isinstance(node, ConstantExpression):
            return node.value
        if isinstance(node, VariableExpression):
            return node.variable.value
        if isinstance(node, ReferenceExpression):
            return self._resolve_runtime_reference(".".join(node.parts))
        if isinstance(node, SumExpression):
            return self._evaluate_expression(node.left) + self._evaluate_expression(node.right)
        if isinstance(node, DifferenceExpression):
            return self._evaluate_expression(node.left) - self._evaluate_expression(node.right)
        if isinstance(node, MultiplicationExpression):
            return self._evaluate_expression(node.left) * self._evaluate_expression(node.right)
        if isinstance(node, DivisionExpression):
            return self._evaluate_expression(node.left) / self._evaluate_expression(node.right)
        if isinstance(node, UnaryMinusExpression):
            return -self._evaluate_expression(node.expression)
        if isinstance(node, IntMultiplicationExpression):
            value = self._evaluate_expression(node.expression)
            return value * type(value)(node.constant)
        if isinstance(node, IntDivisionExpression):
            value = self._evaluate_expression(node.expression)
            return value / type(value)(node.constant)
        if isinstance(node, FunctionCallExpression):
            args = [self._evaluate_expression(argument).value for argument in node.arguments]
            return FloatValue(MathFunctions.evaluate(node.function_name, args))
        raise ValueError(f"Unsupported expression node at runtime: {type(node).__name__}")

    def _evaluate_boolean(self, node: BooleanExpression) -> bool:
        if isinstance(node, BooleanConstantExpression):
            return node.value
        if isinstance(node, BooleanAndExpression):
            return self._evaluate_boolean(node.left) and self._evaluate_boolean(node.right)
        if isinstance(node, BooleanOrExpression):
            return self._evaluate_boolean(node.left) or self._evaluate_boolean(node.right)
        if isinstance(node, BooleanNotExpression):
            return not self._evaluate_boolean(node.expression)
        if isinstance(node, BooleanLessTestExpression):
            return self._evaluate_expression(node.left) < self._evaluate_expression(node.right)
        if isinstance(node, BooleanLessEqualTestExpression):
            return self._evaluate_expression(node.left) <= self._evaluate_expression(node.right)
        if isinstance(node, BooleanGreaterTestExpression):
            return self._evaluate_expression(node.left) > self._evaluate_expression(node.right)
        if isinstance(node, BooleanGreaterEqualTestExpression):
            return self._evaluate_expression(node.left) >= self._evaluate_expression(node.right)
        if isinstance(node, BooleanEqualTestExpression):
            return self._evaluate_expression(node.left) == self._evaluate_expression(node.right)
        if isinstance(node, BooleanNotEqualTestExpression):
            return self._evaluate_expression(node.left) != self._evaluate_expression(node.right)
        raise ValueError(f"Unsupported boolean node at runtime: {type(node).__name__}")

    def _direct_import_step_order(self) -> list[ImportConfig]:
        alias_map = {item.alias: item for item in self.imports}
        dependency_map: dict[str, set[str]] = {alias: set() for alias in alias_map}
        for item in self.imports:
            for connection_ref in item.connections.values():
                if "." not in connection_ref:
                    continue
                head, _, _ = connection_ref.partition(".")
                if head in alias_map:
                    dependency_map[item.alias].add(head)

        ordered: list[ImportConfig] = []
        temp_mark: set[str] = set()
        perm_mark: set[str] = set()

        def visit(alias: str):
            if alias in perm_mark:
                return
            if alias in temp_mark:
                raise ValueError(f"Import connection cycle detected in module '{self.module_config.name}'")
            temp_mark.add(alias)
            for dep in sorted(dependency_map[alias]):
                visit(dep)
            temp_mark.remove(alias)
            perm_mark.add(alias)
            ordered.append(alias_map[alias])

        for alias in sorted(alias_map):
            visit(alias)
        return ordered

    def _build_import_inputs(self, item: ImportConfig) -> dict[str, float]:
        assert item.system is not None
        inputs: dict[str, float] = {}
        for input_name in item.system.input_variables.keys():
            reference = item.connections.get(input_name)
            if reference is None:
                inputs[input_name] = 0.0
                continue
            if "." in reference:
                inputs[input_name] = self._resolve_runtime_reference(reference).value
            elif reference in self.variables:
                inputs[input_name] = self.variables[reference].value.value
            elif reference in self.constants:
                inputs[input_name] = self.constants[reference].value
            else:
                inputs[input_name] = float(reference)
        return inputs

    def get_variables(self) -> dict[str, FloatValue]:
        return {name: variable.value for name, variable in self.variables.items()}

    def step(self, inputs: dict[str, float] | None = None):
        if self.externals:
            raise ValueError("The Python simulator does not support external modules yet")

        if inputs is not None:
            for input_name in self.input_variables.keys():
                if input_name not in inputs:
                    raise ValueError(f"Input variable {input_name} is required but not provided")
                self.input_variables[input_name].value = FloatValue(inputs[input_name])

        for item in self._direct_import_step_order():
            assert item.system is not None
            item.system.step(self._build_import_inputs(item))

        production_values = {}
        used_vars = []
        for rule in self.rules:
            if self._evaluate_boolean(rule.guard):
                production_values[rule] = self._evaluate_expression(rule.producer)
                if not self.module_config.zero_reset_mode:
                    used_vars.extend(rule.vars.values())

        if self.module_config.zero_reset_mode:
            input_names = set(self.input_variables.keys())
            for name, variable in self.variables.items():
                if name not in input_names:
                    variable.value = FloatValue(0.0)
        else:
            used_vars = set(used_vars)
            for variable in used_vars:
                variable.value = FloatValue(0.0)

        for rule in production_values:
            rule.consumer.value += production_values[rule]

        return {name: variable.value.value for name, variable in self.output_variables.items()}

    @staticmethod
    def _parse_real_encoding(raw: dict | None) -> RealEncoding:
        raw = raw or {}
        return RealEncoding(
            kind=raw.get("kind", "fixed_point"),
            signed=raw.get("signed", True),
            width=raw.get("width", 32),
            frac_bits=raw.get("frac_bits", 16),
        )

    @staticmethod
    def _parse_ports(raw_ports: list[dict] | None) -> list[PortConfig]:
        ports = []
        for item in raw_ports or []:
            ports.append(
                PortConfig(
                    name=item["name"],
                    dir=item["dir"],
                    kind=item["kind"],
                    width=item["width"],
                    signed=item.get("signed", False),
                )
            )
        return ports

    @staticmethod
    def _parse_module_config(module_data: dict | None, source_path: Path) -> ModuleConfig:
        module_data = module_data or {}
        # Explicit defaults are documented in rules.md and README:
        # module name -> source filename stem, fixed-point signed Q16.16 on 32 bits,
        # clock -> clk, reset -> rst active-high, and no extra top-level ports.
        return ModuleConfig(
            name=module_data.get("name", source_path.stem),
            real_encoding=GnpsSystem._parse_real_encoding(module_data.get("real_encoding")),
            clock=ClockConfig(name=module_data.get("clock", {}).get("name", "clk")),
            reset=ResetConfig(
                name=module_data.get("reset", {}).get("name", "rst"),
                active_high=module_data.get("reset", {}).get("active_high", True),
            ),
            top_ports=GnpsSystem._parse_ports(module_data.get("top_ports")),
            zero_reset_mode=module_data.get("zero_reset_mode", False),
        )

    @staticmethod
    def _parse_constants(constants_data: dict | None) -> dict[str, FloatValue]:
        constants: dict[str, FloatValue] = {}
        for key, value in (constants_data or {}).items():
            if isinstance(value, str):
                try:
                    constants[key] = parse_expression(value, {}, constants, {}).evaluate()
                except Exception as e:
                    raise ValueError(f"Error evaluating constant '{key}':\n{e}") from None
            else:
                constants[key] = FloatValue(value)
        return constants

    @staticmethod
    def _normalize_rule_items(raw_items) -> list:
        if raw_items is None:
            return []
        if isinstance(raw_items, list):
            return raw_items
        return [raw_items]

    @staticmethod
    def _combine_guards(left: BooleanExpression, right: BooleanExpression) -> BooleanExpression:
        if isinstance(left, BooleanConstantExpression) and left.value is True:
            return right
        if isinstance(right, BooleanConstantExpression) and right.value is True:
            return left
        return BooleanAndExpression(left, right)

    @staticmethod
    def _guard_negation(guard: BooleanExpression) -> BooleanExpression:
        if isinstance(guard, BooleanConstantExpression):
            return BooleanConstantExpression(not guard.value)
        return BooleanNotExpression(guard)

    @staticmethod
    def _parse_structured_rule(
        rule_data: dict,
        variables: dict[str, Variable],
        constants: dict[str, FloatValue],
        aliases: dict[str, Expression],
    ) -> Rule:
        guard_data = rule_data.get("guard", True)
        if isinstance(guard_data, bool):
            guard = BooleanConstantExpression(guard_data)
        else:
            guard = parse_condition(guard_data, variables, constants, aliases)

        producer_data = rule_data.get("producer")
        producer = parse_expression(producer_data, variables, constants, aliases)

        consumer_variable_name = rule_data.get("consumer")
        consumer = variables.get(consumer_variable_name)
        if consumer is None:
            raise ValueError(f"Variable {consumer_variable_name} not defined in the context")
        return Rule(consumer, producer, guard)

    @staticmethod
    def _with_guard(rule: Rule, extra_guard: BooleanExpression) -> Rule:
        return Rule(rule.consumer, rule.producer, GnpsSystem._combine_guards(extra_guard, rule.guard))

    @staticmethod
    def _make_transition_rule(
        consumer: Variable,
        target_constant_name: str,
        guard: BooleanExpression,
        variables: dict[str, Variable],
        constants: dict[str, FloatValue],
        aliases: dict[str, Expression],
    ) -> Rule:
        producer = parse_expression(f"({consumer.name} * 0) + {target_constant_name}", variables, constants, aliases)
        return Rule(consumer, producer, guard)

    @staticmethod
    def _build_state_constants(
        fsm_data: list[dict] | None,
        variables: dict[str, Variable],
        constants: dict[str, FloatValue],
    ) -> tuple[dict[str, dict[str, str]], list[tuple[str, str]]]:
        fsm_constants: dict[str, dict[str, str]] = {}
        fsm_initializers: list[tuple[str, str]] = []
        seen_fsm_names: set[str] = set()
        seen_fsm_variables: set[str] = set()

        for fsm_entry in fsm_data or []:
            fsm_name = fsm_entry["name"]
            fsm_variable = fsm_entry["variable"]
            if fsm_name in seen_fsm_names:
                raise ValueError(f"Duplicate FSM name '{fsm_name}'")
            if fsm_variable in seen_fsm_variables:
                raise ValueError(f"Duplicate FSM variable '{fsm_variable}'")
            if fsm_variable not in variables:
                raise ValueError(f"FSM variable '{fsm_variable}' must be a local variable")
            seen_fsm_names.add(fsm_name)
            seen_fsm_variables.add(fsm_variable)

            states = fsm_entry.get("states", [])
            state_map: dict[str, str] = {}
            seen_state_names: set[str] = set()
            for index, state_entry in enumerate(states):
                if not isinstance(state_entry, dict) or len(state_entry) != 1:
                    raise ValueError(f"FSM '{fsm_name}' states must be single-key mappings")
                state_name = next(iter(state_entry))
                if state_name in seen_state_names:
                    raise ValueError(f"Duplicate state '{state_name}' in FSM '{fsm_name}'")
                seen_state_names.add(state_name)
                constant_name = f"{fsm_name}__{state_name}"
                if constant_name in constants:
                    raise ValueError(f"Generated FSM constant '{constant_name}' collides with an existing constant")
                constants[constant_name] = FloatValue(index)
                state_map[state_name] = constant_name

            initial_state = fsm_entry["initial"]
            if initial_state not in state_map:
                raise ValueError(f"FSM '{fsm_name}' initial state '{initial_state}' is not declared")
            fsm_constants[fsm_name] = state_map
            fsm_initializers.append((fsm_variable, state_map[initial_state]))

        return fsm_constants, fsm_initializers

    @staticmethod
    def _lower_rule_items(
        raw_items,
        variables: dict[str, Variable],
        constants: dict[str, FloatValue],
        aliases: dict[str, Expression],
        accumulated_guard: BooleanExpression | None = None,
    ) -> list[Rule]:
        lowered: list[Rule] = []
        current_guard = accumulated_guard or BooleanConstantExpression(True)

        for item in GnpsSystem._normalize_rule_items(raw_items):
            if isinstance(item, str):
                rule = parse_rule(item, variables, constants, aliases)
                lowered.append(GnpsSystem._with_guard(rule, current_guard))
                continue

            if not isinstance(item, dict):
                raise ValueError(f"Unsupported rule item type: {type(item).__name__}")

            if "if" in item:
                condition = parse_condition(item["if"], variables, constants, aliases)
                then_guard = GnpsSystem._combine_guards(current_guard, condition)
                lowered.extend(GnpsSystem._lower_rule_items(item.get("then"), variables, constants, aliases, then_guard))
                if "else" in item:
                    else_guard = GnpsSystem._combine_guards(current_guard, GnpsSystem._guard_negation(condition))
                    lowered.extend(GnpsSystem._lower_rule_items(item.get("else"), variables, constants, aliases, else_guard))
                continue

            rule = GnpsSystem._parse_structured_rule(item, variables, constants, aliases)
            lowered.append(GnpsSystem._with_guard(rule, current_guard))

        return lowered

    @staticmethod
    def _lower_fsm_rules(
        fsm_data: list[dict] | None,
        variables: dict[str, Variable],
        constants: dict[str, FloatValue],
        aliases: dict[str, Expression],
        fsm_constants: dict[str, dict[str, str]],
    ) -> list[Rule]:
        lowered: list[Rule] = []

        for fsm_entry in fsm_data or []:
            fsm_name = fsm_entry["name"]
            fsm_variable_name = fsm_entry["variable"]
            fsm_variable = variables[fsm_variable_name]
            state_constant_map = fsm_constants[fsm_name]
            local_state_constants = {state_name: constants[constant_name] for state_name, constant_name in state_constant_map.items()}
            fsm_parse_constants = dict(constants)
            fsm_parse_constants.update(local_state_constants)

            def lower_state_items(raw_items, accumulated_guard: BooleanExpression) -> list[Rule]:
                state_rules: list[Rule] = []
                for item in GnpsSystem._normalize_rule_items(raw_items):
                    if isinstance(item, str):
                        rule = parse_rule(item, variables, fsm_parse_constants, aliases)
                        producer_text = item.rsplit("->", 1)[0]
                        if "|" in producer_text:
                            producer_text = producer_text.rsplit("|", 1)[1]
                        elif ":" in producer_text:
                            producer_text = producer_text.rsplit(":", 1)[1]
                        producer_text = producer_text.strip()
                        effective_guard = GnpsSystem._combine_guards(accumulated_guard, rule.guard)
                        if rule.consumer.name == fsm_variable_name and producer_text in state_constant_map:
                            state_rules.append(
                                GnpsSystem._make_transition_rule(
                                    fsm_variable,
                                    state_constant_map[producer_text],
                                    effective_guard,
                                    variables,
                                    constants,
                                    aliases,
                                )
                            )
                        else:
                            state_rules.append(GnpsSystem._with_guard(rule, accumulated_guard))
                        continue

                    if not isinstance(item, dict):
                        raise ValueError(f"Unsupported FSM rule item type: {type(item).__name__}")

                    if "if" in item:
                        condition = parse_condition(item["if"], variables, fsm_parse_constants, aliases)
                        then_guard = GnpsSystem._combine_guards(accumulated_guard, condition)
                        state_rules.extend(lower_state_items(item.get("then"), then_guard))
                        if "else" in item:
                            else_guard = GnpsSystem._combine_guards(accumulated_guard, GnpsSystem._guard_negation(condition))
                            state_rules.extend(lower_state_items(item.get("else"), else_guard))
                        continue

                    consumer_name = item.get("consumer")
                    producer_data = item.get("producer")
                    if (
                        consumer_name == fsm_variable_name
                        and isinstance(producer_data, str)
                        and producer_data in state_constant_map
                    ):
                        guard_data = item.get("guard", True)
                        if isinstance(guard_data, bool):
                            rule_guard = BooleanConstantExpression(guard_data)
                        else:
                            rule_guard = parse_condition(guard_data, variables, fsm_parse_constants, aliases)
                        state_rules.append(
                            GnpsSystem._make_transition_rule(
                                fsm_variable,
                                state_constant_map[producer_data],
                                GnpsSystem._combine_guards(accumulated_guard, rule_guard),
                                variables,
                                constants,
                                aliases,
                            )
                        )
                    else:
                        rule = GnpsSystem._parse_structured_rule(item, variables, fsm_parse_constants, aliases)
                        state_rules.append(GnpsSystem._with_guard(rule, accumulated_guard))

                return state_rules

            for state_entry in fsm_entry.get("states", []):
                state_name = next(iter(state_entry))
                state_body = state_entry[state_name] or {}
                state_guard = parse_condition(
                    f"{fsm_variable_name} == {state_constant_map[state_name]}",
                    variables,
                    fsm_parse_constants,
                    aliases,
                )
                state_rules = lower_state_items(state_body.get("rules"), state_guard)

                transition_indexes = [index for index, rule in enumerate(state_rules) if rule.consumer.name == fsm_variable_name]
                for pos, rule_index in enumerate(transition_indexes):
                    rule = state_rules[rule_index]
                    effective_guard = rule.guard
                    for later_index in transition_indexes[pos + 1:]:
                        effective_guard = GnpsSystem._combine_guards(effective_guard, GnpsSystem._guard_negation(state_rules[later_index].guard))
                    rule.guard = effective_guard

                lowered.extend(state_rules)

        return lowered

    @staticmethod
    def _resolve_path(path_value: str, source_path: Path, import_paths: list[Path]) -> Path:
        candidate = (source_path.parent / path_value).resolve()
        if candidate.exists():
            return candidate
        for import_path in import_paths:
            candidate = (import_path / path_value).resolve()
            if candidate.exists():
                return candidate
        searched = [str(source_path.parent / path_value)] + [str(import_path / path_value) for import_path in import_paths]
        raise ValueError(f"Could not resolve import '{path_value}'. Tried: {', '.join(searched)}")

    @staticmethod
    def _parse_external_header(file_path: Path) -> ExternalModuleHeader:
        with file_path.open("r", encoding="utf-8") as file:
            data = yaml.safe_load(file) or {}
        header_data = data.get("external_module")
        if not header_data:
            raise ValueError(f"External header '{file_path}' must contain an 'external_module' section")
        return ExternalModuleHeader(
            name=header_data["name"],
            parameters=header_data.get("parameters", {}),
            ports=GnpsSystem._parse_ports(header_data.get("ports")),
            source_path=str(file_path),
        )

    @staticmethod
    def _parse_reference_expr(
        reference_value: str,
        variables: dict[str, Variable],
        constants: dict[str, FloatValue],
        aliases: dict[str, Expression],
    ) -> Expression:
        if "." in reference_value:
            return ReferenceExpression(reference_value.split("."))
        if reference_value in aliases:
            return aliases[reference_value]
        if reference_value in constants:
            from .parser.ast import ConstantExpression

            return ConstantExpression(constants[reference_value])
        if reference_value in variables:
            return VariableExpression(variables[reference_value])
        raise ValueError(f"Unknown reference '{reference_value}'")

    @staticmethod
    def _iter_references(node):
        if isinstance(node, ReferenceExpression):
            yield ".".join(node.parts)
            return
        for attr in ("left", "right", "expression"):
            child = getattr(node, attr, None)
            if child is not None:
                yield from GnpsSystem._iter_references(child)
        for arg in getattr(node, "arguments", []):
            yield from GnpsSystem._iter_references(arg)

    def _validate_reference(self, reference: str):
        head, _, tail = reference.partition(".")
        if not tail:
            return
        if head == "top":
            port_names = {port.name for port in self.module_config.top_ports}
            port_names.add(self.module_config.clock.name)
            port_names.add(self.module_config.reset.name)
            if tail not in port_names:
                raise ValueError(f"Unknown top-level signal '{reference}'")
            return

        import_map = {item.alias: item for item in self.imports}
        if head in import_map:
            imported = import_map[head].system
            if imported is None:
                raise ValueError(f"Import '{head}' is not resolved")
            allowed = set(imported.input_variables.keys()) | set(imported.output_variables.keys())
            if tail not in allowed:
                raise ValueError(f"Reference '{reference}' must target an imported module input or output")
            return

        external_map = {item.alias: item for item in self.externals}
        if head in external_map:
            ports = {port.name for port in external_map[head].definition.ports}
            if tail not in ports:
                raise ValueError(f"Reference '{reference}' targets an unknown external port")
            return

        raise ValueError(f"Unknown qualified reference '{reference}'")

    def validate_references(self):
        for alias_expr in self.aliases.values():
            for reference in self._iter_references(alias_expr):
                self._validate_reference(reference)
        for rule in self.rules:
            for reference in self._iter_references(rule.guard):
                self._validate_reference(reference)
            for reference in self._iter_references(rule.producer):
                self._validate_reference(reference)
        for item in self.imports:
            imported = item.system
            if imported is None:
                continue
            imported_inputs = set(imported.input_variables.keys())
            for port_name, ref in item.connections.items():
                if port_name not in imported_inputs and port_name not in {imported.module_config.clock.name, imported.module_config.reset.name}:
                    raise ValueError(f"Import connection '{port_name}' is not an input on '{item.alias}'")
                self._validate_reference(ref)
        for item in self.externals:
            port_map = {port.name: port for port in item.definition.ports}
            for port_name, ref in item.connections.items():
                if port_name not in port_map:
                    raise ValueError(f"External connection '{port_name}' is not a port on '{item.alias}'")
                self._validate_reference(ref)

    @staticmethod
    def from_yaml(
        file_path: str,
        import_paths: list[str] | None = None,
        _loading_stack: list[Path] | None = None,
        _system_cache: dict[Path, "GnpsSystem"] | None = None,
        _header_cache: dict[Path, ExternalModuleHeader] | None = None,
    ):
        source_path = Path(file_path).resolve()
        import_paths_resolved = [Path(path).resolve() for path in (import_paths or [])]
        loading_stack = list(_loading_stack or [])
        system_cache = _system_cache if _system_cache is not None else {}
        header_cache = _header_cache if _header_cache is not None else {}

        if source_path in loading_stack:
            cycle = " -> ".join(str(item) for item in [*loading_stack, source_path])
            raise ValueError(f"Import cycle detected: {cycle}")
        if source_path in system_cache:
            return system_cache[source_path]

        gnps = GnpsSystem()
        gnps.source_path = source_path
        loading_stack.append(source_path)
        system_cache[source_path] = gnps

        with source_path.open("r", encoding="utf-8") as file:
            data = yaml.safe_load(file) or {}

        gnps.metadata = {key: value for key, value in data.items() if key in {"name", "description"}}
        gnps.module_config = GnpsSystem._parse_module_config(data.get("module"), source_path)
        gnps.constants = GnpsSystem._parse_constants(data.get("constants"))

        variables: dict[str, Variable] = {}

        cells_data = data.get("cells", [])
        for cell_data in cells_data:
            cell_id = cell_data.get("id")
            if not isinstance(cell_id, int):
                raise ValueError("Cell id must be an integer")
            contents_data = cell_data.get("contents", [])
            contents = {}
            for variable_data in contents_data:
                if isinstance(variable_data, dict) and "name" in variable_data:
                    variable_name = variable_data.get("name")
                    variable_value = variable_data.get("value")
                    variable = variables.get(variable_name, Variable(variable_name, FloatValue(variable_value)))
                    variables[variable_name] = variable
                    contents[variable_name] = variable
                else:
                    try:
                        parsed_variables = parse_variable_assignment(variable_data, variables, gnps.constants, gnps.aliases)
                        contents.update(parsed_variables)
                        variables.update(parsed_variables)
                    except Exception as e:  # pragma: no cover
                        raise ValueError(f"Error parsing variable assignment '{variable_data}':\n{e}") from None
            cell = Cell(cell_id, contents)
            gnps.add_cell(cell)

            for variable_name in cell_data.get("input", []):
                gnps.input_variables[variable_name] = variables[variable_name]

            for variable_name in cell_data.get("output", []):
                gnps.output_variables[variable_name] = variables[variable_name]

        gnps.variables = variables

        fsm_constants, fsm_initializers = GnpsSystem._build_state_constants(data.get("fsm"), variables, gnps.constants)
        for variable_name, constant_name in fsm_initializers:
            variables[variable_name].value = gnps.constants[constant_name]

        for import_data in data.get("imports", []):
            alias = import_data["as"]
            import_path = GnpsSystem._resolve_path(import_data["module"], source_path, import_paths_resolved)
            imported_system = GnpsSystem.from_yaml(
                str(import_path),
                import_paths=[str(path) for path in import_paths_resolved],
                _loading_stack=loading_stack,
                _system_cache=system_cache,
                _header_cache=header_cache,
            )
            gnps.imports.append(
                ImportConfig(
                    module=str(import_path),
                    alias=alias,
                    connections=import_data.get("connections", {}),
                    system=imported_system,
                )
            )

        for external_data in data.get("externals", []):
            header_path = GnpsSystem._resolve_path(external_data["header"], source_path, import_paths_resolved)
            if header_path not in header_cache:
                header_cache[header_path] = GnpsSystem._parse_external_header(header_path)
            gnps.externals.append(
                ExternalInstance(
                    header=str(header_path),
                    alias=external_data["as"],
                    parameters=external_data.get("parameters", {}),
                    connections=external_data.get("connections", {}),
                    definition=header_cache[header_path],
                )
            )

        for alias_name, target in (data.get("aliases") or {}).items():
            gnps.aliases[alias_name] = GnpsSystem._parse_reference_expr(target, variables, gnps.constants, gnps.aliases)

        try:
            for rule in GnpsSystem._lower_rule_items(data.get("rules", []), variables, gnps.constants, gnps.aliases):
                gnps.add_rule(rule)
            for rule in GnpsSystem._lower_fsm_rules(data.get("fsm"), variables, gnps.constants, gnps.aliases, fsm_constants):
                gnps.add_rule(rule)
        except Exception as e:  # pragma: no cover
            raise ValueError(f"Error lowering YAML rules:\n{e}") from None

        gnps.validate_references()
        loading_stack.pop()
        return gnps
