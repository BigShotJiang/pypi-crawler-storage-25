"""Configuration helpers for module composition and Verilog export."""

from dataclasses import dataclass, field


@dataclass(slots=True)
class RealEncoding:
    """Numeric encoding used for GNPS real values inside one module."""

    kind: str = "fixed_point"
    signed: bool = True
    width: int = 32
    frac_bits: int = 16


@dataclass(slots=True)
class ClockConfig:
    """Clock configuration for generated hardware modules."""

    name: str = "clk"


@dataclass(slots=True)
class ResetConfig:
    """Reset configuration for generated hardware modules."""

    name: str = "rst"
    active_high: bool = True


@dataclass(slots=True)
class PortConfig:
    """Top-level or external module port description."""

    name: str
    dir: str
    kind: str
    width: int
    signed: bool = False


@dataclass(slots=True)
class ModuleConfig:
    """Per-module configuration for code generation."""

    name: str
    real_encoding: RealEncoding = field(default_factory=RealEncoding)
    clock: ClockConfig = field(default_factory=ClockConfig)
    reset: ResetConfig = field(default_factory=ResetConfig)
    top_ports: list[PortConfig] = field(default_factory=list)
    zero_reset_mode: bool = False


@dataclass(slots=True)
class ImportConfig:
    """Imported GNPS module."""

    module: str
    alias: str
    connections: dict[str, str] = field(default_factory=dict)
    system: object | None = None


@dataclass(slots=True)
class ExternalModuleHeader:
    """Interface-only declaration for an external RTL module."""

    name: str
    parameters: dict[str, int | float | str] = field(default_factory=dict)
    ports: list[PortConfig] = field(default_factory=list)
    source_path: str | None = None


@dataclass(slots=True)
class ExternalInstance:
    """Concrete instance of an external RTL module."""

    header: str
    alias: str
    parameters: dict[str, int | float | str] = field(default_factory=dict)
    connections: dict[str, str] = field(default_factory=dict)
    definition: ExternalModuleHeader | None = None

