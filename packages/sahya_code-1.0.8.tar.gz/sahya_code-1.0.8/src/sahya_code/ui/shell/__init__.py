from __future__ import annotations

import asyncio
import contextlib
import shlex
import time
from collections import deque
from collections.abc import Awaitable, Callable, Coroutine
from dataclasses import dataclass
from enum import Enum
from typing import Any

from kosong.chat_provider import APIStatusError, ChatProviderError
from rich.console import Group, RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from sahya_code import logger
from sahya_code.background import list_task_views
from sahya_code.notifications import NotificationManager, NotificationWatcher
from sahya_code.soul import LLMNotSet, LLMNotSupported, MaxStepsReached, RunCancelled, Soul, run_soul
from sahya_code.soul.sahyasoul import SahyaSoul
from sahya_code.ui.shell import update as _update_mod
from sahya_code.ui.shell.console import console
from sahya_code.ui.shell.echo import render_user_echo_text
from sahya_code.ui.shell.mcp_status import render_mcp_prompt
from sahya_code.ui.shell.prompt import (
    CustomPromptSession,
    PromptMode,
    UserInput,
    toast,
)
from sahya_code.ui.shell.replay import replay_recent_history
from sahya_code.ui.shell.slash import registry as shell_slash_registry
from sahya_code.ui.shell.slash import shell_mode_registry
from sahya_code.ui.shell.update import LATEST_VERSION_FILE, UpdateResult, do_update, semver_tuple
from sahya_code.ui.shell.visualize import (
    ApprovalPromptDelegate,
    visualize,
)
from sahya_code.utils.aioqueue import QueueShutDown
from sahya_code.utils.envvar import get_env_bool
from sahya_code.utils.logging import open_original_stderr
from sahya_code.utils.signals import install_sigint_handler
from sahya_code.utils.slashcmd import SlashCommand, SlashCommandCall, parse_slash_command_call
from sahya_code.utils.subprocess_env import get_clean_env
from sahya_code.utils.term import ensure_new_line, ensure_tty_sane
from sahya_code.wire.types import (
    ApprovalRequest,
    ApprovalResponse,
    ContentPart,
    StatusUpdate,
    WireMessage,
)


@dataclass(slots=True)
class _PromptEvent:
    kind: str
    user_input: UserInput | None = None


_MAX_BG_AUTO_TRIGGER_FAILURES = 3
"""Stop auto-triggering after this many consecutive failures."""


class _BackgroundCompletionWatcher:
    """Watches for background task completions and auto-triggers the agent.

    Sits between the idle event loop and the soul: when a background task
    finishes while the agent is idle *and* the LLM hasn't consumed the
    notification yet, it triggers a soul run.
    """

    def __init__(self, soul: Soul) -> None:
        self._event: asyncio.Event | None = None
        self._notifications: NotificationManager | None = None
        if isinstance(soul, SahyaSoul):
            self._event = soul.runtime.background_tasks.completion_event
            self._notifications = soul.runtime.notifications

    @property
    def enabled(self) -> bool:
        return self._event is not None

    def clear(self) -> None:
        """Clear stale signals from the previous soul run."""
        if self._event is not None:
            self._event.clear()

    async def wait_for_next(self, idle_events: asyncio.Queue[_PromptEvent]) -> _PromptEvent | None:
        """Wait for either a user prompt event or a background completion.

        Returns the prompt event if user input arrived first, or ``None``
        if a background task completed with unclaimed LLM notifications.
        User input always takes priority over background completions.
        """
        if self.enabled and self._has_pending_llm_notifications():
            # Pending notifications exist, but user input still wins.
            try:
                return idle_events.get_nowait()
            except asyncio.QueueEmpty:
                return None

        idle_task = asyncio.create_task(idle_events.get())
        if not self.enabled:
            return await idle_task

        assert self._event is not None
        bg_wait_task = asyncio.create_task(self._event.wait())

        done, _ = await asyncio.wait(
            [idle_task, bg_wait_task],
            return_when=asyncio.FIRST_COMPLETED,
        )
        for t in (idle_task, bg_wait_task):
            if t not in done:
                t.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await t

        if idle_task in done:
            if bg_wait_task in done:
                self._event.clear()
            return idle_task.result()

        # Only bg fired
        self._event.clear()
        if self._has_pending_llm_notifications():
            return None
        return _PromptEvent(kind="bg_noop")

    def _has_pending_llm_notifications(self) -> bool:
        if self._notifications is None:
            return False
        return self._notifications.has_pending_for_sink("llm")


class Shell:
    def __init__(self, soul: Soul, welcome_info: list[WelcomeInfoItem] | None = None):
        self.soul = soul
        self._welcome_info = list(welcome_info or [])
        self._background_tasks: set[asyncio.Task[Any]] = set()
        self._prompt_session: CustomPromptSession | None = None
        self._running_input_handler: Callable[[UserInput], None] | None = None
        self._running_interrupt_handler: Callable[[], None] | None = None
        self._active_approval_sink: Any | None = None
        self._pending_approval_requests = deque[ApprovalRequest]()
        self._current_prompt_approval_request: ApprovalRequest | None = None
        self._approval_modal: ApprovalPromptDelegate | None = None
        self._exit_after_run = False
        self._available_slash_commands: dict[str, SlashCommand[Any]] = {
            **{cmd.name: cmd for cmd in soul.available_slash_commands},
            **{cmd.name: cmd for cmd in shell_slash_registry.list_commands()},
        }
        """Shell-level slash commands + soul-level slash commands. Name to command mapping."""

    @property
    def available_slash_commands(self) -> dict[str, SlashCommand[Any]]:
        """Get all available slash commands, including shell-level and soul-level commands."""
        return self._available_slash_commands

    @staticmethod
    def _should_exit_input(user_input: UserInput) -> bool:
        return user_input.command.strip() in {"exit", "quit", "/exit", "/quit"}

    @staticmethod
    def _agent_slash_command_call(user_input: UserInput) -> SlashCommandCall | None:
        if user_input.mode != PromptMode.AGENT:
            return None
        display_call = parse_slash_command_call(user_input.command)
        if display_call is None:
            return None
        resolved_call = parse_slash_command_call(user_input.resolved_command)
        if resolved_call is None or resolved_call.name != display_call.name:
            return display_call
        return resolved_call

    @staticmethod
    def _should_echo_agent_input(user_input: UserInput) -> bool:
        if user_input.mode != PromptMode.AGENT:
            return False
        if Shell._should_exit_input(user_input):
            return False
        return Shell._agent_slash_command_call(user_input) is None

    @staticmethod
    def _echo_agent_input(user_input: UserInput) -> None:
        console.print(render_user_echo_text(user_input.command))

    def _bind_running_input(
        self,
        on_input: Callable[[UserInput], None],
        on_interrupt: Callable[[], None],
    ) -> None:
        self._running_input_handler = on_input
        self._running_interrupt_handler = on_interrupt

    def _unbind_running_input(self) -> None:
        self._running_input_handler = None
        self._running_interrupt_handler = None

    async def _route_prompt_events(
        self,
        prompt_session: CustomPromptSession,
        idle_events: asyncio.Queue[_PromptEvent],
        resume_prompt: asyncio.Event,
    ) -> None:
        while True:
            # Keep exactly one active prompt read. Idle submissions pause the
            # router until the shell decides whether the next prompt should
            # wait for a blocking action or stay live during an agent run.
            await resume_prompt.wait()
            ensure_tty_sane()
            try:
                ensure_new_line()
                user_input = await prompt_session.prompt_next()
            except KeyboardInterrupt:
                logger.debug("Prompt router got KeyboardInterrupt")
                if (
                    self._running_input_handler is not None
                    and prompt_session.running_prompt_accepts_submission()
                ):
                    if self._running_interrupt_handler is not None:
                        self._running_interrupt_handler()
                    continue
                resume_prompt.clear()
                await idle_events.put(_PromptEvent(kind="interrupt"))
                continue
            except EOFError:
                logger.debug("Prompt router got EOF")
                if (
                    self._running_input_handler is not None
                    and prompt_session.running_prompt_accepts_submission()
                ):
                    self._exit_after_run = True
                    if self._running_interrupt_handler is not None:
                        self._running_interrupt_handler()
                    return
                resume_prompt.clear()
                await idle_events.put(_PromptEvent(kind="eof"))
                return
            except Exception:
                logger.exception("Prompt router crashed")
                resume_prompt.clear()
                await idle_events.put(_PromptEvent(kind="error"))
                return

            if prompt_session.last_submission_was_running:  # noqa: SIM102
                if self._running_input_handler is not None:
                    if user_input:
                        self._running_input_handler(user_input)
                    continue
                # Handler already unbound — fall through to idle path.

            resume_prompt.clear()
            await idle_events.put(_PromptEvent(kind="input", user_input=user_input))

    async def run(self, command: str | None = None) -> bool:
        # Initialize theme from config
        if isinstance(self.soul, SahyaSoul):
            from sahya_code.ui.theme import set_active_theme

            set_active_theme(self.soul.runtime.config.theme)
            
            # Fetch available models from openai_legacy providers (LiteLLM, etc.)
            from sahya_code.auth.platforms import refresh_openai_legacy_models
            try:
                await refresh_openai_legacy_models(self.soul.runtime.config)
            except Exception as exc:
                logger.debug("Failed to refresh openai_legacy models on startup: {exc}", exc=exc)

        if command is not None:
            # run single command and exit
            logger.info("Running agent with command: {command}", command=command)
            if isinstance(self.soul, SahyaSoul):
                self._start_background_task(self._watch_root_wire_hub())
            try:
                return await self.run_soul_command(command)
            finally:
                self._cancel_background_tasks()

        # Start auto-update background task if not disabled
        if get_env_bool("KIMI_CLI_NO_AUTO_UPDATE"):
            logger.info("Auto-update disabled by KIMI_CLI_NO_AUTO_UPDATE environment variable")
        else:
            self._start_background_task(self._auto_update())

        _print_welcome_info(self.soul.name or "Kimi Code CLI", self._welcome_info)

        if isinstance(self.soul, SahyaSoul):
            watcher = NotificationWatcher(
                self.soul.runtime.notifications,
                sink="shell",
                before_poll=self.soul.runtime.background_tasks.reconcile,
                on_notification=lambda notification: toast(
                    f"[{notification.event.type}] {notification.event.title}",
                    topic="notification",
                    duration=10.0,
                ),
            )
            self._start_background_task(watcher.run_forever())
            self._start_background_task(self._watch_root_wire_hub())
            await replay_recent_history(
                self.soul.context.history,
                wire_file=self.soul.wire_file,
            )
            await self.soul.start_background_mcp_loading()

        async def _plan_mode_toggle() -> bool:
            if isinstance(self.soul, SahyaSoul):
                return await self.soul.toggle_plan_mode_from_manual()
            return False

        def _mcp_status_block(columns: int):
            if not isinstance(self.soul, SahyaSoul):
                return None
            snapshot = self.soul.status.mcp_status
            if snapshot is None:
                return None
            return render_mcp_prompt(snapshot)

        def _mcp_status_loading() -> bool:
            if not isinstance(self.soul, SahyaSoul):
                return False
            snapshot = self.soul.status.mcp_status
            return bool(snapshot and snapshot.loading)

        @dataclass
        class _BgCountCache:
            time: float = 0.0
            count: int = 0

        _bg_cache = _BgCountCache()

        def _bg_task_count() -> int:
            if not isinstance(self.soul, SahyaSoul):
                return 0
            now = time.monotonic()
            if now - _bg_cache.time < 1.0:
                return _bg_cache.count
            views = list_task_views(self.soul.runtime.background_tasks, active_only=True)
            _bg_cache.count = sum(1 for v in views if v.spec.kind == "bash")
            _bg_cache.time = now
            return _bg_cache.count

        with CustomPromptSession(
            status_provider=lambda: self.soul.status,
            status_block_provider=_mcp_status_block,
            fast_refresh_provider=_mcp_status_loading,
            background_task_count_provider=_bg_task_count,
            model_capabilities=self.soul.model_capabilities or set(),
            model_name=self.soul.model_name,
            thinking=self.soul.thinking or False,
            agent_mode_slash_commands=list(self._available_slash_commands.values()),
            shell_mode_slash_commands=shell_mode_registry.list_commands(),
            editor_command_provider=lambda: (
                self.soul.runtime.config.default_editor if isinstance(self.soul, SahyaSoul) else ""
            ),
            plan_mode_toggle_callback=_plan_mode_toggle,
        ) as prompt_session:
            self._prompt_session = prompt_session
            if isinstance(self.soul, SahyaSoul):
                kimi_soul = self.soul
                snapshot = kimi_soul.status.mcp_status
                if snapshot and snapshot.loading:

                    async def _invalidate_after_mcp_loading() -> None:
                        try:
                            await kimi_soul.wait_for_background_mcp_loading()
                        except Exception:
                            logger.debug("MCP loading finished with error while refreshing prompt")
                        if self._prompt_session is prompt_session:
                            prompt_session.invalidate()

                    self._start_background_task(_invalidate_after_mcp_loading())
            self._exit_after_run = False
            idle_events: asyncio.Queue[_PromptEvent] = asyncio.Queue()
            # resume_prompt controls whether the prompt router reads input.
            # Set BEFORE an await = prompt stays live during the operation
            # (agent runs that accept steer input); set AFTER = prompt is
            # paused until the operation finishes.
            resume_prompt = asyncio.Event()
            resume_prompt.set()
            prompt_task = asyncio.create_task(
                self._route_prompt_events(prompt_session, idle_events, resume_prompt)
            )
            bg_watcher = _BackgroundCompletionWatcher(self.soul)

            shell_ok = True
            bg_auto_failures = 0
            try:
                while True:
                    bg_watcher.clear()
                    if bg_auto_failures >= _MAX_BG_AUTO_TRIGGER_FAILURES:
                        result = await idle_events.get()
                    else:
                        result = await bg_watcher.wait_for_next(idle_events)

                    if result is None:
                        logger.info("Background task completed while idle, triggering agent")
                        resume_prompt.set()
                        ok = await self.run_soul_command(
                            "<system-reminder>"
                            "Background tasks completed while you"
                            " were idle."
                            "</system-reminder>"
                        )
                        console.print()
                        if not ok:
                            bg_auto_failures += 1
                            logger.warning(
                                "Background auto-trigger failed ({n}/{max})",
                                n=bg_auto_failures,
                                max=_MAX_BG_AUTO_TRIGGER_FAILURES,
                            )
                        else:
                            bg_auto_failures = 0
                        if self._exit_after_run:
                            console.print("Bye!")
                            break
                        continue

                    event = result

                    if event.kind == "bg_noop":
                        continue

                    if event.kind == "interrupt":
                        console.print("[grey50]Tip: press Ctrl-D or send 'exit' to quit[/grey50]")
                        resume_prompt.set()
                        continue

                    if event.kind == "eof":
                        console.print("Bye!")
                        break

                    if event.kind == "error":
                        shell_ok = False
                        break

                    user_input = event.user_input
                    assert user_input is not None
                    bg_auto_failures = 0
                    if not user_input:
                        logger.debug("Got empty input, skipping")
                        resume_prompt.set()
                        continue
                    logger.debug("Got user input: {user_input}", user_input=user_input)

                    if self._should_echo_agent_input(user_input):
                        self._echo_agent_input(user_input)

                    if self._should_exit_input(user_input):
                        logger.debug("Exiting by slash command")
                        console.print("Bye!")
                        break

                    if user_input.mode == PromptMode.SHELL:
                        await self._run_shell_command(user_input.command)
                        resume_prompt.set()
                        continue

                    if slash_cmd_call := self._agent_slash_command_call(user_input):
                        is_soul_slash = (
                            slash_cmd_call.name in self._available_slash_commands
                            and shell_slash_registry.find_command(slash_cmd_call.name) is None
                        )
                        if is_soul_slash:
                            resume_prompt.set()
                            await self.run_soul_command(slash_cmd_call.raw_input)
                            console.print()
                            if self._exit_after_run:
                                console.print("Bye!")
                                break
                        else:
                            await self._run_slash_command(slash_cmd_call)
                            resume_prompt.set()
                        continue

                    resume_prompt.set()
                    await self.run_soul_command(user_input.content)
                    console.print()
                    if self._exit_after_run:
                        console.print("Bye!")
                        break
            finally:
                prompt_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await prompt_task
                self._running_input_handler = None
                self._running_interrupt_handler = None
                if self._prompt_session is prompt_session and self._approval_modal is not None:
                    prompt_session.detach_modal(self._approval_modal)
                    self._approval_modal = None
                self._prompt_session = None
                self._cancel_background_tasks()
                ensure_tty_sane()

        return shell_ok

    async def _run_shell_command(self, command: str) -> None:
        """Run a shell command in foreground."""
        if not command.strip():
            return

        # Check if it's an allowed slash command in shell mode
        if slash_cmd_call := parse_slash_command_call(command):
            if shell_mode_registry.find_command(slash_cmd_call.name):
                await self._run_slash_command(slash_cmd_call)
                return
            else:
                console.print(
                    f'[yellow]"/{slash_cmd_call.name}" is not available in shell mode. '
                    "Press Ctrl-X to switch to agent mode.[/yellow]"
                )
                return

        # Check if user is trying to use 'cd' command
        stripped_cmd = command.strip()
        split_cmd: list[str] | None = None
        try:
            split_cmd = shlex.split(stripped_cmd)
        except ValueError as exc:
            logger.debug("Failed to parse shell command for cd check: {error}", error=exc)
        if split_cmd and len(split_cmd) == 2 and split_cmd[0] == "cd":
            console.print(
                "[yellow]Warning: Directory changes are not preserved across command executions."
                "[/yellow]"
            )
            return

        logger.info("Running shell command: {cmd}", cmd=command)

        proc: asyncio.subprocess.Process | None = None

        def _handler():
            logger.debug("SIGINT received.")
            if proc:
                proc.terminate()

        loop = asyncio.get_running_loop()
        remove_sigint = install_sigint_handler(loop, _handler)
        try:
            # TODO: For the sake of simplicity, we now use `create_subprocess_shell`.
            # Later we should consider making this behave like a real shell.
            with open_original_stderr() as stderr:
                kwargs: dict[str, Any] = {}
                if stderr is not None:
                    kwargs["stderr"] = stderr
                proc = await asyncio.create_subprocess_shell(command, env=get_clean_env(), **kwargs)
                await proc.wait()
        except Exception as e:
            logger.exception("Failed to run shell command:")
            console.print(f"[red]Failed to run shell command: {e}[/red]")
        finally:
            remove_sigint()

    async def _run_slash_command(self, command_call: SlashCommandCall) -> None:
        from sahya_code.cli import Reload, SwitchToVis, SwitchToWeb

        if command_call.name not in self._available_slash_commands:
            logger.info("Unknown slash command /{command}", command=command_call.name)
            console.print(
                f'[red]Unknown slash command "/{command_call.name}", '
                'type "/" for all available commands[/red]'
            )
            return

        command = shell_slash_registry.find_command(command_call.name)
        if command is None:
            # the input is a soul-level slash command call
            await self.run_soul_command(command_call.raw_input)
            return

        logger.debug(
            "Running shell-level slash command: /{command} with args: {args}",
            command=command_call.name,
            args=command_call.args,
        )

        try:
            ret = command.func(self, command_call.args)
            if isinstance(ret, Awaitable):
                await ret
        except (Reload, SwitchToWeb, SwitchToVis):
            # just propagate
            raise
        except (asyncio.CancelledError, KeyboardInterrupt):
            # Handle Ctrl-C during slash command execution, return to shell prompt
            logger.debug("Slash command interrupted by KeyboardInterrupt")
            console.print("[red]Interrupted by user[/red]")
        except Exception as e:
            logger.exception("Unknown error:")
            console.print(f"[red]Unknown error: {e}[/red]")
            raise  # re-raise unknown error

    async def run_soul_command(self, user_input: str | list[ContentPart]) -> bool:
        """
        Run the soul and handle any known exceptions.

        Returns:
            bool: Whether the run is successful.
        """
        logger.info("Running soul with user input: {user_input}", user_input=user_input)

        cancel_event = asyncio.Event()

        def _handler():
            logger.debug("SIGINT received.")
            cancel_event.set()

        loop = asyncio.get_running_loop()
        remove_sigint = install_sigint_handler(loop, _handler)

        try:
            snap = self.soul.status
            runtime = self.soul.runtime if isinstance(self.soul, SahyaSoul) else None
            await run_soul(
                self.soul,
                user_input,
                lambda wire: visualize(
                    wire.ui_side(merge=False),  # shell UI maintain its own merge buffer
                    initial_status=StatusUpdate(
                        context_usage=snap.context_usage,
                        context_tokens=snap.context_tokens,
                        max_context_tokens=snap.max_context_tokens,
                        mcp_status=snap.mcp_status,
                    ),
                    cancel_event=cancel_event,
                    prompt_session=self._prompt_session,
                    steer=self.soul.steer if isinstance(self.soul, SahyaSoul) else None,
                    bind_running_input=self._bind_running_input,
                    unbind_running_input=self._unbind_running_input,
                    on_view_ready=self._set_active_approval_sink,
                    on_view_closed=self._clear_active_approval_sink,
                ),
                cancel_event,
                runtime.session.wire_file if runtime else None,
                runtime,
            )
            return True
        except LLMNotSet:
            logger.exception("LLM not set:")
            console.print('[red]LLM not set, send "/login" to login[/red]')
        except LLMNotSupported as e:
            # actually unsupported input/mode should already be blocked by prompt session
            logger.exception("LLM not supported:")
            console.print(f"[red]{e}[/red]")
        except ChatProviderError as e:
            logger.exception("LLM provider error:")
            if isinstance(e, APIStatusError) and e.status_code == 401:
                console.print("[red]Authorization failed, please check your login status[/red]")
            elif isinstance(e, APIStatusError) and e.status_code == 402:
                console.print("[red]Membership expired, please renew your plan[/red]")
            elif isinstance(e, APIStatusError) and e.status_code == 403:
                console.print("[red]Quota exceeded, please upgrade your plan or retry later[/red]")
            else:
                console.print(f"[red]LLM provider error: {e}[/red]")
        except MaxStepsReached as e:
            logger.warning("Max steps reached: {n_steps}", n_steps=e.n_steps)
            console.print(f"[yellow]{e}[/yellow]")
        except RunCancelled:
            logger.info("Cancelled by user")
            console.print("[red]Interrupted by user[/red]")
        except Exception as e:
            logger.exception("Unexpected error:")
            console.print(f"[red]Unexpected error: {e}[/red]")
            raise  # re-raise unknown error
        finally:
            self._maybe_present_pending_approvals()
            remove_sigint()
        return False

    async def _watch_root_wire_hub(self) -> None:
        if not isinstance(self.soul, SahyaSoul):
            return
        if self.soul.runtime.root_wire_hub is None:
            return
        queue = self.soul.runtime.root_wire_hub.subscribe()
        try:
            while True:
                try:
                    msg = await queue.get()
                except QueueShutDown:
                    return
                try:
                    await self._handle_root_hub_message(msg)
                except Exception:
                    logger.exception("Failed to handle root hub message:")
        finally:
            self.soul.runtime.root_wire_hub.unsubscribe(queue)

    async def _handle_root_hub_message(self, msg: WireMessage) -> None:
        if not isinstance(self.soul, SahyaSoul):
            return
        match msg:
            case ApprovalRequest() as request:
                request = self._enrich_approval_request_for_ui(request)
                if self.soul.runtime.approval_runtime is None:
                    return
                record = self.soul.runtime.approval_runtime.get_request(request.id)
                if record is None or record.status != "pending":
                    return
                if self._prompt_session is not None:
                    # Interactive mode: queue and present via modal
                    self._queue_approval_request(request)
                    self._maybe_present_pending_approvals()
                    self._prompt_session.invalidate()
                elif self._active_approval_sink is not None:
                    # Non-interactive with live view: forward to sink
                    self._forward_approval_to_sink(request)
                else:
                    # Queue for later
                    self._queue_approval_request(request)
            case ApprovalResponse() as response:
                # External resolution (e.g. from web UI)
                if (
                    self._approval_modal is not None
                    and self._approval_modal.request.id == response.request_id
                ):
                    if not self._approval_modal.request.resolved:
                        self._approval_modal.request.resolve(response.response)
                    self._clear_current_prompt_approval_request(response.request_id)
                    self._activate_prompt_approval_modal()
                self._remove_pending_approval_request(response.request_id)
                self._maybe_present_pending_approvals()
                if self._prompt_session is not None:
                    self._prompt_session.invalidate()
            case _:
                return

    def _enrich_approval_request_for_ui(self, request: ApprovalRequest) -> ApprovalRequest:
        if not isinstance(self.soul, SahyaSoul):
            return request
        if request.agent_id is None:
            return request
        if self.soul.runtime.subagent_store is None:
            return request
        record = self.soul.runtime.subagent_store.get_instance(request.agent_id)
        if record is None:
            return request
        return request.model_copy(update={"source_description": record.description})

    def _set_active_approval_sink(self, sink: Any) -> None:
        self._active_approval_sink = sink
        # Flush pending approvals to the newly active sink
        while self._pending_approval_requests:
            request = self._pending_approval_requests.popleft()

            if not isinstance(self.soul, SahyaSoul) or self.soul.runtime.approval_runtime is None:
                break
            record = self.soul.runtime.approval_runtime.get_request(request.id)
            if record is None or record.status != "pending":
                continue
            self._forward_approval_to_sink(request)

    def _clear_active_approval_sink(self) -> None:
        self._active_approval_sink = None
        # Re-queue any approval requests that were forwarded to the sink
        # but not yet resolved.  Without this, those requests would be
        # silently lost when the live view closes between turns.
        if not isinstance(self.soul, SahyaSoul) or self.soul.runtime.approval_runtime is None:
            return
        for record in self.soul.runtime.approval_runtime.list_pending():
            self._queue_approval_request(
                self._enrich_approval_request_for_ui(
                    ApprovalRequest(
                        id=record.id,
                        tool_call_id=record.tool_call_id,
                        sender=record.sender,
                        action=record.action,
                        description=record.description,
                        display=record.display,
                        source_kind=record.source.kind,
                        source_id=record.source.id,
                        agent_id=record.source.agent_id,
                        subagent_type=record.source.subagent_type,
                    )
                )
            )

    def _forward_approval_to_sink(self, request: ApprovalRequest) -> None:
        """Forward an approval request to the active live view sink and bridge the response."""
        if self._active_approval_sink is None:
            self._queue_approval_request(request)
            return
        self._active_approval_sink.enqueue_external_message(request)

        async def _bridge() -> None:
            try:
                response = await request.wait()
                if (
                    isinstance(self.soul, SahyaSoul)
                    and self.soul.runtime.approval_runtime is not None
                ):
                    self.soul.runtime.approval_runtime.resolve(
                        request.id, response, feedback=request.feedback
                    )
            finally:
                if self._prompt_session is not None:
                    self._prompt_session.invalidate()

        self._start_background_task(_bridge())

    def _queue_approval_request(self, request: ApprovalRequest) -> None:
        if self._approval_modal is not None and self._approval_modal.request.id == request.id:
            return
        if (
            self._current_prompt_approval_request is not None
            and self._current_prompt_approval_request.id == request.id
        ):
            return
        if any(r.id == request.id for r in self._pending_approval_requests):
            return
        self._pending_approval_requests.append(request)

    def _remove_pending_approval_request(self, request_id: str) -> None:
        self._clear_current_prompt_approval_request(request_id)
        self._pending_approval_requests = deque(
            r for r in self._pending_approval_requests if r.id != request_id
        )

    def _clear_current_prompt_approval_request(self, request_id: str) -> None:
        if (
            self._current_prompt_approval_request is not None
            and self._current_prompt_approval_request.id == request_id
        ):
            self._current_prompt_approval_request = None

    def _maybe_present_pending_approvals(self) -> None:
        if self._prompt_session is not None:
            self._activate_prompt_approval_modal()
            return
        if self._active_approval_sink is not None:
            while self._pending_approval_requests:
                request = self._pending_approval_requests.popleft()

                if not isinstance(self.soul, SahyaSoul):
                    break
                if self.soul.runtime.approval_runtime is None:
                    break
                record = self.soul.runtime.approval_runtime.get_request(request.id)
                if record is None or record.status != "pending":
                    continue
                self._forward_approval_to_sink(request)

    def _activate_prompt_approval_modal(self) -> None:
        if self._prompt_session is None:
            return
        current_request = self._current_prompt_approval_request
        if current_request is None:
            current_request = self._pop_next_pending_approval_request()
            self._current_prompt_approval_request = current_request
        if current_request is None:
            if self._approval_modal is not None:
                self._prompt_session.detach_modal(self._approval_modal)
                self._approval_modal = None
            return
        if self._approval_modal is None:
            self._approval_modal = ApprovalPromptDelegate(
                current_request,
                on_response=self._handle_prompt_approval_response,
                buffer_text_provider=(
                    lambda: self._prompt_session._session.default_buffer.text  # pyright: ignore[reportPrivateUsage]
                    if self._prompt_session is not None
                    else ""
                ),
                text_expander=self._prompt_session._get_placeholder_manager().serialize_for_history,  # pyright: ignore[reportPrivateUsage]
            )
            self._prompt_session.attach_modal(self._approval_modal)
        else:
            if self._approval_modal.request.id != current_request.id:
                self._approval_modal.set_request(current_request)
        self._prompt_session.invalidate()

    def _handle_prompt_approval_response(
        self,
        request: ApprovalRequest,
        response: ApprovalResponse.Kind,
        feedback: str = "",
    ) -> None:
        if not isinstance(self.soul, SahyaSoul):
            return
        if self.soul.runtime.approval_runtime is None:
            return
        self.soul.runtime.approval_runtime.resolve(request.id, response, feedback=feedback)
        self._clear_current_prompt_approval_request(request.id)
        self._activate_prompt_approval_modal()

    def _pop_next_pending_approval_request(self) -> ApprovalRequest | None:
        if not isinstance(self.soul, SahyaSoul) or self.soul.runtime.approval_runtime is None:
            return None
        while self._pending_approval_requests:
            request = self._pending_approval_requests.popleft()

            record = self.soul.runtime.approval_runtime.get_request(request.id)
            if record is None or record.status != "pending":
                continue
            return request
        return None

    async def _auto_update(self) -> None:
        result = await do_update(print=False, check_only=True)
        if result == UpdateResult.UPDATE_AVAILABLE:
            while True:
                toast(
                    f"new version found, run `{_update_mod.UPGRADE_COMMAND}` to upgrade",
                    topic="update",
                    duration=30.0,
                )
                await asyncio.sleep(60.0)
        elif result == UpdateResult.UPDATED:
            toast("auto updated, restart to use the new version", topic="update", duration=5.0)

    def _start_background_task(self, coro: Coroutine[Any, Any, Any]) -> asyncio.Task[Any]:
        task = asyncio.create_task(coro)
        self._background_tasks.add(task)

        def _cleanup(t: asyncio.Task[Any]) -> None:
            self._background_tasks.discard(t)
            try:
                t.result()
            except asyncio.CancelledError:
                pass
            except Exception:
                logger.exception("Background task failed:")

        task.add_done_callback(_cleanup)
        return task

    def _cancel_background_tasks(self) -> None:
        """Cancel all background tasks (notification watcher, auto-update, etc.)."""
        for task in self._background_tasks:
            task.cancel()
        self._background_tasks.clear()


_SAHYA_ORANGE = "#ff4f00"
# Full logo for wide terminals (fits in 80 columns)
_LOGO_FULL = Text.assemble(
    (r"███████╗ █████╗ ██╗  ██╗██╗   ██╗ █████╗     ██████╗ ██████╗ ██████╗ ███████╗" + "\n", _SAHYA_ORANGE),
    (r"██╔════╝██╔══██╗██║  ██║╚██╗ ██╔╝██╔══██╗   ██╔════╝██╔═══██╗██╔══██╗██╔════╝" + "\n", _SAHYA_ORANGE),
    (r"███████╗███████║███████║ ╚████╔╝ ███████║   ██║     ██║   ██║██║  ██║█████╗  " + "\n", _SAHYA_ORANGE),
    (r"╚════██║██╔══██║██╔══██║  ╚██╔╝  ██╔══██║   ██║     ██║   ██║██║  ██║██╔══╝  " + "\n", _SAHYA_ORANGE),
    (r"███████║██║  ██║██║  ██║   ██║   ██║  ██║   ╚██████╗╚██████╔╝██████╔╝███████╗" + "\n", _SAHYA_ORANGE),
    (r"╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝    ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝" + "\n", _SAHYA_ORANGE),
)
# Medium logo for medium terminals (fits in 60 columns)
_LOGO_MEDIUM = Text.assemble(
    (r"┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓" + "\n", _SAHYA_ORANGE),
    (r"┃  ███████╗ █████╗ ██╗  ██╗██╗   ██╗ █████╗               ┃" + "\n", _SAHYA_ORANGE),
    (r"┃  ██╔════╝██╔══██╗██║  ██║╚██╗ ██╔╝██╔══██╗              ┃" + "\n", _SAHYA_ORANGE),
    (r"┃  ███████╗███████║███████║ ╚████╔╝ ███████║              ┃" + "\n", _SAHYA_ORANGE),
    (r"┃  ╚════██║██╔══██║██╔══██║  ╚██╔╝  ██╔══██║              ┃" + "\n", _SAHYA_ORANGE),
    (r"┃  ███████║██║  ██║██║  ██║   ██║   ██║  ██║              ┃" + "\n", _SAHYA_ORANGE),
    (r"┃  ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝              ┃" + "\n", _SAHYA_ORANGE),
    (r"┃           ██████╗ ██████╗ ██████╗ ███████╗              ┃" + "\n", _SAHYA_ORANGE),
    (r"┃          ██╔════╝██╔═══██╗██╔══██╗██╔════╝              ┃" + "\n", _SAHYA_ORANGE),
    (r"┃          ██║     ██║   ██║██║  ██║█████╗                ┃" + "\n", _SAHYA_ORANGE),
    (r"┃          ██║     ██║   ██║██║  ██║██╔══╝                ┃" + "\n", _SAHYA_ORANGE),
    (r"┃          ╚██████╗╚██████╔╝██████╔╝███████╗              ┃" + "\n", _SAHYA_ORANGE),
    (r"┃           ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝              ┃" + "\n", _SAHYA_ORANGE),
    (r"┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛" + "\n", _SAHYA_ORANGE),
)
# Compact logo for narrow terminals - just the letter S
_LOGO_COMPACT = Text.assemble(
    (r"███████╗" + "\n", _SAHYA_ORANGE),
    (r"██╔════╝" + "\n", _SAHYA_ORANGE),
    (r"███████╗" + "\n", _SAHYA_ORANGE),
    (r"╚════██║" + "\n", _SAHYA_ORANGE),
    (r"███████║" + "\n", _SAHYA_ORANGE),
    (r"╚══════╝" + "\n", _SAHYA_ORANGE),
)
# Minimal logo for very narrow terminals
_LOGO_MINIMAL = Text.assemble(
    (r"┏━━━━━━━━━━━┓" + "\n", _SAHYA_ORANGE),
    (r"┃   Sahya   ┃" + "\n", _SAHYA_ORANGE),
    (r"┃    Code   ┃" + "\n", _SAHYA_ORANGE),
    (r"┗━━━━━━━━━━━┛" + "\n", _SAHYA_ORANGE),
)


@dataclass(slots=True)
class WelcomeInfoItem:
    class Level(Enum):
        INFO = "grey50"
        WARN = "yellow"
        ERROR = "red"

    name: str
    value: str
    level: Level = Level.INFO


def _print_welcome_info(name: str, info_items: list[WelcomeInfoItem]) -> None:
    from sahya_code.ui.theme import get_active_theme

    theme = get_active_theme()
    text_color = "#ffffff" if theme == "dark" else "#000000"
    head = Text.from_markup(f"[bold {text_color}]Welcome to Sahya Code CLI[/]")
    help_text = Text.from_markup("[grey50]Send /help for help information.[/grey50]")

    # Choose logo based on terminal width
    import shutil
    term_width = shutil.get_terminal_size().columns
    if term_width >= 80:
        logo = _LOGO_FULL
    elif term_width >= 60:
        logo = _LOGO_MEDIUM
    elif term_width >= 30:
        logo = _LOGO_COMPACT
    else:
        logo = _LOGO_MINIMAL

    # Stack logo and welcome text vertically
    rows: list[RenderableType] = [logo, Text("")]
    rows.append(Group(head, help_text))

    if info_items:
        rows.append(Text(""))  # empty line
    for item in info_items:
        rows.append(Text(f"{item.name}: {item.value}", style=item.level.value))

    if LATEST_VERSION_FILE.exists():
        from sahya_code.constant import VERSION as current_version

        latest_version = LATEST_VERSION_FILE.read_text(encoding="utf-8").strip()
        if semver_tuple(latest_version) > semver_tuple(current_version):
            rows.append(
                Text.from_markup(
                    f"\n[yellow]New version available: {latest_version}. "
                    f"Please run `{_update_mod.UPGRADE_COMMAND}` to upgrade.[/yellow]"
                )
            )

    # Set panel background based on theme
    panel_bg = "on #0d0d0d" if theme == "dark" else "on #fbfbfb"

    console.print(
        Panel(
            Group(*rows),
            border_style=_SAHYA_ORANGE,
            expand=True,
            padding=(1, 2),
            style=panel_bg,
        )
    )
