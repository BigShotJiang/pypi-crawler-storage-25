"""CHESS frame selection toolkit.

A Python package for selecting representative frames from molecular dynamics
trajectories using CHESS Fisher-Rao sampling on cached atomic embeddings.

Main modules:
- featurizers: Pluggable feature extractors (SevenNet, wACSF)
- transforms: Feature transformations (PCA)
- metrics: Fisher-Rao metric helpers
- selection: k-center selection on CHESS histograms
- analysis: Post-selection analysis
- plotting: Visualization functions
- pipelines: High-level workflows (build, sample)

Examples:
    >>> from chess.featurizers import FeaturizerRegistry
    >>> featurizer = FeaturizerRegistry.create("sevennet", model="7net-0")
    >>> from chess.config import load_config
    >>> cfg = load_config("config.yaml")
"""

__version__ = "0.1.0"
__author__ = "Eui-Cheol Shin"
__license__ = "MIT"

from .core import info, ensure_dir, abs_path
from .chess_utils import fit_boe_codebook, build_frame_boe_hist

__all__ = [
    "info",
    "ensure_dir",
    "abs_path",
    "fit_boe_codebook",
    "build_frame_boe_hist",
    "__version__",
]
