"""
Command-line interface for CHESS selection toolkit (chesskit).

Supported usage:
    python -m chesskit --config config.yaml
    python -m chesskit --config config.yaml --mode sample
    python -m chesskit --preset wacsf-build > config_build_wacsf.yaml
    python -m chesskit --preset chess-sample > config_sample.yaml
    python -m chesskit --quickcheck cpu
    python -m chesskit --quickcheck both
    chesskit --config config.yaml  (after pip install)
    chesskit --version
"""

import argparse
import sys
from typing import Optional

from . import __version__
from .config import load_config, write_preset, _get_system_summary, _write_header_files
from .core import info, print_chess_banner


def main() -> int:
    """
    Main CLI entry point.
    
    Returns:
        Exit code (0 for success, 1 for error)
    """
    parser = argparse.ArgumentParser(
        prog="chesskit",
        description="CHESS Frame Selection Toolkit",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Generate templates
    python -m chesskit --preset wacsf-build > config_build_wacsf.yaml
    python -m chesskit --preset sevennet-build > config_build_sevennet.yaml
    python -m chesskit --preset chess-sample > config_sample.yaml

    # Run build stage (creates paths.cache)
    python -m chesskit --config config_build_wacsf.yaml --mode build

    # Run sample stage (reads paths.cache)
    python -m chesskit --config config_sample.yaml --mode sample

    # Let config decide mode
    python -m chesskit --config config.yaml
        """,
    )
    
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to YAML configuration file",
    )
    parser.add_argument(
        "--mode",
        type=str,
        choices=["build", "sample"],
        default=None,
        help="Override mode from config (build=create embeddings cache, sample=select frames from cache)",
    )
    parser.add_argument(
        "--preset",
        type=str,
        choices=["sevennet-build", "wacsf-build", "chess-sample"],
        default=None,
        help="Write preset YAML to stdout and exit.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--quickcheck",
        type=str,
        choices=["cpu", "gpu", "both"],
        default=None,
        help=(
            "Run an internal pytest-based smoke test on a tiny dataset to verify "
            "build+sample end-to-end execution (cpu/gpu/both)."
        ),
    )
    parser.add_argument(
        "--quickcheck-verbose",
        action="store_true",
        help="Verbose output for --quickcheck.",
    )
    
    args = parser.parse_args()
    
    # Handle preset generation
    if args.preset:
        try:
            write_preset(args.preset)
            return 0
        except Exception as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return 1

    # Run packaged pytest-based smoke checks.
    if args.quickcheck is not None:
        try:
            from .selfcheck import run_quickcheck
            return run_quickcheck(args.quickcheck, verbose=bool(args.quickcheck_verbose))
        except Exception as e:
            print(f"ERROR: quickcheck failed to run: {e}", file=sys.stderr)
            return 1
    
    # Require config for normal operation
    if args.config is None:
        parser.print_help(sys.stderr)
        print(f"\nERROR: --config is required", file=sys.stderr)
        print(f"       (or use --preset to generate a template)", file=sys.stderr)
        return 1
    
    try:
        # Load and validate config
        cfg = load_config(args.config)
        
        # Determine mode
        mode = args.mode if args.mode else cfg.get("mode", "build")
        if mode not in ("build", "sample"):
            raise ValueError(f"Invalid mode: {mode}")

        print_chess_banner()
        info(f"CHESS run started | mode={mode} | config={args.config}")
        
        # Dispatch to pipelines.build or pipelines.sample
        from .pipelines import build as run_build, sample as run_sample

        if mode == "build":
            info("Running build pipeline")
            run_build(cfg)
        else:
            info("Running sample pipeline")
            run_sample(cfg)

        return 0
        
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        import traceback
        if "--debug" in sys.argv:
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
