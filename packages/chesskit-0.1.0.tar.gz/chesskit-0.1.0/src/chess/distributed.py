"""
Multi-GPU utilities for distributed computing.

This module provides utilities for parallel execution across multiple GPUs:
- DataParallelWrapper: PyTorch DataParallel model wrapper
- split_data_across_gpus: Data partitioning for parallel processing
- parallel_map_gpus: Map function across GPUs
"""

from typing import List, Optional, Callable, Any, Tuple
import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.multiprocessing as mp
    _HAS_TORCH = True
except ImportError:
    _HAS_TORCH = False


class DataParallelWrapper:
    """
    Wrapper for PyTorch DataParallel model execution.
    
    Simplifies multi-GPU model deployment by handling device placement
    and DataParallel initialization.
    
    Args:
        model: PyTorch model to parallelize
        device_ids: List of GPU indices to use (e.g., [0, 1, 2])
        
    Attributes:
        model: DataParallel-wrapped model
        device_ids: GPU indices in use
        primary_device: Primary device string (e.g., "cuda:0")
        
    Example:
        >>> model = load_my_model()
        >>> wrapper = DataParallelWrapper(model, device_ids=[0, 1])
        >>> output = wrapper.forward(input_tensor)
    """
    
    def __init__(self, model: "nn.Module", device_ids: List[int]):
        if not _HAS_TORCH:
            raise ImportError("torch required for DataParallelWrapper")
        
        self.device_ids = device_ids
        self.primary_device = f"cuda:{device_ids[0]}"
        
        # Move model to primary GPU first
        model = model.to(self.primary_device)
        
        # Wrap with DataParallel
        self.model = nn.DataParallel(model, device_ids=device_ids)
    
    def forward(self, *args, **kwargs):
        """
        Forward pass through DataParallel model.
        
        Args:
            *args: Positional arguments to model
            **kwargs: Keyword arguments to model
            
        Returns:
            Model output (gathered from all GPUs to primary device)
        """
        return self.model(*args, **kwargs)
    
    def __call__(self, *args, **kwargs):
        """Allow wrapper to be called like a model."""
        return self.forward(*args, **kwargs)


def split_data_across_gpus(
    data: np.ndarray,
    n_gpus: int
) -> List[np.ndarray]:
    """
    Split data into chunks for parallel GPU processing.
    
    Divides data along first axis into roughly equal chunks.
    Last chunk may be slightly larger to include remainder.
    
    Args:
        data: NumPy array to split (N, ...)
        n_gpus: Number of GPUs (chunks)
        
    Returns:
        List of n_gpus data chunks
        
    Example:
        >>> data = np.random.rand(1000, 64)
        >>> chunks = split_data_across_gpus(data, n_gpus=4)
        >>> len(chunks)
        4
        >>> chunks[0].shape[0]
        250
    """
    if n_gpus <= 0:
        raise ValueError(f"n_gpus must be positive, got {n_gpus}")
    
    if n_gpus == 1:
        return [data]
    
    n_samples = len(data)
    chunk_size = n_samples // n_gpus
    
    chunks = []
    for i in range(n_gpus):
        start = i * chunk_size
        # Last chunk includes remainder
        end = start + chunk_size if i < n_gpus - 1 else n_samples
        chunks.append(data[start:end])
    
    return chunks


def parallel_map_gpus(
    func: Callable[[Any, str], Any],
    data_chunks: List[Any],
    device_ids: List[int]
) -> List[Any]:
    """
    Map function across data chunks on multiple GPUs in parallel.
    
    Uses torch.multiprocessing to spawn processes for each GPU.
    Each process receives one data chunk and a CUDA device string.
    
    Args:
        func: Function with signature func(data_chunk, device) -> result
        data_chunks: List of data chunks (one per GPU)
        device_ids: GPU indices to use
        
    Returns:
        List of results (one per chunk, in same order)
        
    Note:
        - Function must be picklable (no lambdas or closures)
        - Uses 'spawn' context (creates fresh process)
        - Each process has independent GPU memory
        
    Example:
        >>> def process_on_gpu(chunk, device):
        ...     tensor = torch.from_numpy(chunk).to(device)
        ...     return tensor.sum().cpu().numpy()
        >>> 
        >>> chunks = split_data_across_gpus(data, n_gpus=2)
        >>> results = parallel_map_gpus(process_on_gpu, chunks, [0, 1])
    """
    if not _HAS_TORCH:
        raise ImportError("torch required for parallel_map_gpus")
    
    if len(data_chunks) != len(device_ids):
        raise ValueError(
            f"Number of data chunks ({len(data_chunks)}) must match "
            f"number of device IDs ({len(device_ids)})"
        )
    
    # Set spawn context for CUDA compatibility
    try:
        mp.set_start_method('spawn', force=True)
    except RuntimeError:
        # Already set, ignore
        pass
    
    # Create process pool
    with mp.Pool(processes=len(device_ids)) as pool:
        # Map function to (chunk, device) pairs
        results = pool.starmap(
            func,
            [(chunk, f"cuda:{device_id}") 
             for chunk, device_id in zip(data_chunks, device_ids)]
        )
    
    return results


def merge_results(results: List[np.ndarray]) -> np.ndarray:
    """
    Merge results from multiple GPUs along first axis.
    
    Args:
        results: List of NumPy arrays with matching shapes except axis 0
        
    Returns:
        Concatenated array along axis 0
        
    Example:
        >>> results = [np.array([[1, 2]]), np.array([[3, 4]])]
        >>> merged = merge_results(results)
        >>> merged
        array([[1, 2],
               [3, 4]])
    """
    if not results:
        raise ValueError("Cannot merge empty results list")
    
    return np.concatenate(results, axis=0)


__all__ = [
    "DataParallelWrapper",
    "split_data_across_gpus",
    "parallel_map_gpus",
    "merge_results",
]
