"""CHESS frame selection algorithms using Fisher–Rao distance."""

from typing import List

import numpy as np

from ..core import info, _pct_bin, fmt_count, fmt_float, fmt_progress
from ..metrics import (
    prepare_fisherrao_phi_np,
    prepare_fisherrao_phi_torch,
)

from ..core import _HAS_TORCH, _pick_device

__all__ = [
    "chess_kcenter_fisherrao",
]


def chess_kcenter_fisherrao(
    H_boe_all: np.ndarray,
    K_select: int,
    block_size: int = 200_000,
    fr_eps: float = 1e-12,
    seed: int = 0,
    radius_stop: float = 0.0,
    log_step_pct: int = 10,
    multi_gpu: bool = False,
    gpu_ids=None,
):
    """k-center selection on BoE histograms with Fisher–Rao distance."""
    n_frames, K = H_boe_all.shape
    if n_frames == 0 or K_select <= 0:
        return [], []

    row_sums = H_boe_all.sum(axis=1)
    zero_rows = np.flatnonzero(row_sums <= 0.0)
    if zero_rows.size == n_frames:
        info("Error: all frame histograms are zero. Fisher-Rao distances cannot be computed.")
        return [], []
    elif zero_rows.size > 0:
        info(f"Warning: {zero_rows.size:,} of {n_frames:,} frame histogram(s) are zero.")
    valid_frames = np.flatnonzero(row_sums > 0.0)
    if K_select > valid_frames.size:
        info(
            f"Requested K={K_select:,} exceeds the number of nonzero histograms. "
            f"Clamping to {valid_frames.size:,}."
        )
        K_select = max(1, valid_frames.size)

    rng = np.random.RandomState(int(seed))
    seed_idx = int(valid_frames[rng.randint(0, valid_frames.size)])
    idx_width = len(f"{max(0, n_frames - 1):,}")

    use_torch = _HAS_TORCH
    radius_hist: List[float] = []

    if use_torch:
        import torch
        from ..core import _pick_devices

        # Decide whether to use multi-GPU sharding
        _use_multi = False
        _device_ids: List[int] = []
        if multi_gpu:
            _, _device_ids = _pick_devices(multi_gpu=True, gpu_ids=gpu_ids)
            _use_multi = len(_device_ids) > 1

        if _use_multi:
            # ── Multi-GPU sharded k-center ──────────────────────────────────
            # Strategy: distribute rows of Phi evenly across GPUs.
            # Each GPU owns a contiguous shard and maintains its own min_dist.
            # Per iteration:
            #   1. Gather per-shard (max_val, local_idx) to CPU
            #   2. Global argmax → (best_shard, local_idx, global_idx)
            #   3. Pull centroid vector from that shard's GPU to CPU
            #   4. Broadcast centroid to all shards for distance update
            n_gpus = len(_device_ids)
            shard_size = (n_frames + n_gpus - 1) // n_gpus
            shard_lo = [i * shard_size for i in range(n_gpus)]
            shard_hi = [min((i + 1) * shard_size, n_frames) for i in range(n_gpus)]

            # Build Phi on CPU once, then distribute shards
            Phi_cpu = torch.from_numpy(
                prepare_fisherrao_phi_np(H_boe_all, fr_eps).astype(np.float32)
            )  # (N, K) float32, CPU

            devs = [f"cuda:{d}" for d in _device_ids]
            Phi_shards = [
                Phi_cpu[lo:hi].to(devs[i])
                for i, (lo, hi) in enumerate(zip(shard_lo, shard_hi))
            ]
            min_dist_shards = [
                torch.full((hi - lo,), float("inf"), device=devs[i], dtype=torch.float32)
                for i, (lo, hi) in enumerate(zip(shard_lo, shard_hi))
            ]

            # Seed: compute initial distances on all shards
            seed_shard = next(
                si for si, (lo, hi) in enumerate(zip(shard_lo, shard_hi))
                if lo <= seed_idx < hi
            )
            seed_local = seed_idx - shard_lo[seed_shard]
            cvec_cpu = Phi_shards[seed_shard][seed_local].cpu()
            for si, (dev, lo, hi) in enumerate(zip(devs, shard_lo, shard_hi)):
                cvec = cvec_cpu.to(dev)
                cos = Phi_shards[si] @ cvec
                cos = torch.clamp(cos, 0.0, 1.0)
                min_dist_shards[si] = torch.minimum(min_dist_shards[si], torch.acos(cos))
            min_dist_shards[seed_shard][seed_local] = -float("inf")

            selected = [seed_idx]
            # Compute initial radius: gather max from each shard
            shard_maxvals = [
                float(torch.max(mds[torch.isfinite(mds)]).item())
                if torch.isfinite(mds).any() else -float("inf")
                for mds in min_dist_shards
            ]
            last_radius = max(shard_maxvals)
            radius_hist.append(last_radius)
            info("")
            info("Fisher-Rao k-center selection:")
            info(f"  - N frames: {n_frames:,}")
            info(f"  - Target K: {K_select:,}")
            info(f"  - Seed index: {seed_idx:,}")
            info(f"  - Radius stop: {fmt_float(radius_stop)}")
            info(f"  - Device: {n_gpus} GPU(s)")

            TOL = 1e-15
            last_bin_print = -1
            while len(selected) < K_select:
                # Find global argmax
                shard_maxv = []
                shard_maxi = []
                for si, mds in enumerate(min_dist_shards):
                    mxi = int(torch.argmax(mds).item())
                    mxv = float(mds[mxi].item())
                    shard_maxv.append(mxv)
                    shard_maxi.append(mxi)

                best_si = int(np.argmax(shard_maxv))
                radius = shard_maxv[best_si]
                if not np.isfinite(radius):
                    info(
                        f"  - Early stop: radius <= {fmt_float(TOL)} "
                        f"(radius={fmt_float(radius)})"
                    )
                    break

                local_idx = shard_maxi[best_si]
                global_idx = shard_lo[best_si] + local_idx
                selected.append(global_idx)
                min_dist_shards[best_si][local_idx] = -float("inf")

                # Extract centroid and broadcast to all shards
                cvec_cpu = Phi_shards[best_si][local_idx].cpu()
                for si, (dev, lo, hi) in enumerate(zip(devs, shard_lo, shard_hi)):
                    cvec = cvec_cpu.to(dev)
                    cos = Phi_shards[si] @ cvec
                    cos = torch.clamp(cos, 0.0, 1.0)
                    d = torch.acos(cos)
                    min_dist_shards[si] = torch.minimum(min_dist_shards[si], d)

                # Gather stats for logging
                all_finite = [
                    mds[torch.isfinite(mds)].cpu() for mds in min_dist_shards
                ]
                all_finite_cat = torch.cat(all_finite) if any(t.numel() > 0 for t in all_finite) else None
                if all_finite_cat is not None and all_finite_cat.numel() > 0:
                    cur_min = float(torch.min(all_finite_cat).item())
                    cur_med = float(torch.median(all_finite_cat).item())
                    cur_max = float(torch.max(all_finite_cat).item())
                else:
                    cur_min = cur_med = cur_max = -float("inf")

                radius_hist.append(radius)
                last_radius = radius

                if radius_stop > 0.0 and radius <= radius_stop:
                    info(f"  - radius_stop reached at step {len(selected):,} (radius={fmt_float(radius)})")
                    break

                pct = 100.0 * len(selected) / K_select
                bin_idx = _pct_bin(pct, log_step_pct)
                if bin_idx > last_bin_print or len(selected) == K_select:
                    info(
                        f"  - Progress: {fmt_progress(len(selected), K_select, pct)} | "
                        f"picked={global_idx:>{idx_width},d} | radius={fmt_float(radius, width=8)} | "
                        f"min/med/max m(i)={fmt_float(cur_min, width=8)}/{fmt_float(cur_med, width=8)}/{fmt_float(cur_max, width=8)}"
                    )
                    last_bin_print = bin_idx

            return selected, radius_hist
        else:
            # ── Single-GPU k-center ─────────────────────────────────────────
            if _device_ids:
                device = f"cuda:{_device_ids[0]}"
            else:
                device = _pick_device()
            Phi = prepare_fisherrao_phi_torch(H_boe_all, fr_eps, device)
            min_dist = torch.full((n_frames,), float("inf"), device=device, dtype=torch.float32)

            seed_vec = Phi[seed_idx]
            for lo in range(0, n_frames, block_size):
                hi = min(lo + block_size, n_frames)
                cos = Phi[lo:hi] @ seed_vec
                cos = torch.clamp(cos, 0.0, 1.0)
                d = torch.acos(cos)
                min_dist[lo:hi] = torch.minimum(min_dist[lo:hi], d)
            min_dist[seed_idx] = -float("inf")

            selected = [seed_idx]
            last_radius = float(torch.max(min_dist[torch.isfinite(min_dist)]).item()) if torch.isfinite(min_dist).any() else 0.0
            radius_hist.append(last_radius)
            info("")
            info("Fisher-Rao k-center selection:")
            info(f"  - N frames: {n_frames:,}")
            info(f"  - Target K: {K_select:,}")
            info(f"  - Seed index: {seed_idx:,}")
            info(f"  - Block size: {block_size:,}")
            info(f"  - Radius stop: {fmt_float(radius_stop)}")
            info(f"  - Device: {device}")

            TOL = 1e-15
            last_bin_print = -1
            while len(selected) < K_select:
                next_idx = int(torch.argmax(min_dist).item())
                radius = float(min_dist[next_idx].item())
                if not np.isfinite(radius):
                    info(
                        f"  - Early stop: radius <= {fmt_float(TOL)} "
                        f"(radius={fmt_float(radius)})"
                    )
                    break

                selected.append(next_idx)
                min_dist[next_idx] = -float("inf")

                cvec = Phi[next_idx]
                for lo in range(0, n_frames, block_size):
                    hi = min(lo + block_size, n_frames)
                    cos = Phi[lo:hi] @ cvec
                    cos = torch.clamp(cos, 0.0, 1.0)
                    d = torch.acos(cos)
                    min_dist[lo:hi] = torch.minimum(min_dist[lo:hi], d)

                finite_mask = torch.isfinite(min_dist)
                if torch.any(finite_mask):
                    md = min_dist[finite_mask]
                    cur_min = float(torch.min(md).item())
                    cur_med = float(torch.median(md).item())
                    cur_max = float(torch.max(md).item())
                else:
                    cur_min = cur_med = cur_max = -float("inf")

                radius_hist.append(radius)
                last_radius = radius

                if radius_stop > 0.0 and radius <= radius_stop:
                    info(f"  - radius_stop reached at step {len(selected):,} (radius={fmt_float(radius)})")
                    break

                pct = 100.0 * len(selected) / K_select
                bin_idx = _pct_bin(pct, log_step_pct)
                if bin_idx > last_bin_print or len(selected) == K_select:
                    info(
                        f"  - Progress: {fmt_progress(len(selected), K_select, pct)} | "
                        f"picked={next_idx:>{idx_width},d} | radius={fmt_float(radius, width=8)} | "
                        f"min/med/max m(i)={fmt_float(cur_min, width=8)}/{fmt_float(cur_med, width=8)}/{fmt_float(cur_max, width=8)}"
                    )
                    last_bin_print = bin_idx

            return selected, radius_hist

    else:
        Phi = prepare_fisherrao_phi_np(H_boe_all, fr_eps)
        min_dist = np.full((n_frames,), np.inf, dtype=np.float64)

        seed_vec = Phi[seed_idx]
        for lo in range(0, n_frames, block_size):
            hi = min(lo + block_size, n_frames)
            cos = Phi[lo:hi] @ seed_vec
            np.clip(cos, 0.0, 1.0, out=cos)
            d = np.arccos(cos)
            min_dist[lo:hi] = np.minimum(min_dist[lo:hi], d)
        min_dist[seed_idx] = -np.inf

        selected = [seed_idx]
        last_radius = float(np.max(min_dist[np.isfinite(min_dist)])) if np.isfinite(min_dist).any() else 0.0
        radius_hist.append(last_radius)
        info("")
        info("Fisher-Rao k-center selection:")
        info(f"  - N frames: {n_frames:,}")
        info(f"  - Target K: {K_select:,}")
        info(f"  - Seed index: {seed_idx:,}")
        info(f"  - Block size: {block_size:,}")
        info(f"  - Radius stop: {fmt_float(radius_stop)}")
        info("  - Device: NumPy")

        TOL = 1e-15
        last_bin_print = -1
        while len(selected) < K_select:
            next_idx = int(np.argmax(min_dist))
            radius = float(min_dist[next_idx])
            if not np.isfinite(radius):
                info(
                    f"  - Early stop: radius <= {fmt_float(TOL)} "
                    f"(radius={fmt_float(radius)})"
                )
                break

            selected.append(next_idx)
            min_dist[next_idx] = -np.inf

            cvec = Phi[next_idx]
            for lo in range(0, n_frames, block_size):
                hi = min(lo + block_size, n_frames)
                cos = Phi[lo:hi] @ cvec
                np.clip(cos, 0.0, 1.0, out=cos)
                d = np.arccos(cos)
                min_dist[lo:hi] = np.minimum(min_dist[lo:hi], d)

            finite_md = min_dist[np.isfinite(min_dist)]
            cur_min = float(np.min(finite_md)) if finite_md.size else -np.inf
            cur_med = float(np.median(finite_md)) if finite_md.size else -np.inf
            cur_max = float(np.max(finite_md)) if finite_md.size else -np.inf

            radius_hist.append(radius)
            last_radius = radius

            if radius_stop > 0.0 and radius <= radius_stop:
                info(f"  - radius_stop reached at step {len(selected):,} (radius={fmt_float(radius)})")
                break

            pct = 100.0 * len(selected) / K_select
            bin_idx = _pct_bin(pct, log_step_pct)
            if bin_idx > last_bin_print or len(selected) == K_select:
                info(
                    f"  - Progress: {fmt_progress(len(selected), K_select, pct)} | "
                    f"picked={next_idx:>{idx_width},d} | radius={fmt_float(radius, width=8)} | "
                    f"min/med/max m(i)={fmt_float(cur_min, width=8)}/{fmt_float(cur_med, width=8)}/{fmt_float(cur_max, width=8)}"
                )
                last_bin_print = bin_idx

        return selected, radius_hist
