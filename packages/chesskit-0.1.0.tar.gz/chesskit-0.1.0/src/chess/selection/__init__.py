"""Selection layer: frame selection algorithms."""

from .chess_selection import chess_kcenter_fisherrao

__all__ = [
    "chess_kcenter_fisherrao",
]
