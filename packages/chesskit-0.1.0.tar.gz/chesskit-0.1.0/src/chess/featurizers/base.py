"""
Abstract base class and registry for featurizers.

This module provides the plugin system for atomic feature extractors.
"""

from abc import ABC, abstractmethod
from typing import Optional, List, Tuple, Dict, Any
import numpy as np


class Featurizer(ABC):
    """
    Abstract base class for all atomic feature extractors.
    
    A Featurizer converts atomic structures (frames) into numerical embeddings
    suitable for downstream selection algorithms.
    
    Subclasses must implement:
    - name: Unique identifier (e.g., "sevennet", "orca")
    - embedding_dim: Output feature vector dimension
    - featurize(): Convert frames → embeddings + forces + metadata
    - supports_batch(): Whether batch processing is supported
    - supports_forces(): Whether forces are computed
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """
        Featurizer name/identifier.
        
        Returns:
            Unique name (used in config, registry keys)
            
        Example:
            return "sevennet"
        """
        pass
    
    @property
    @abstractmethod
    def embedding_dim(self) -> int:
        """
        Dimension of output per-atom embeddings.
        
        Returns:
            Integer dimension (e.g., 64 for SevenNet)
        """
        pass
    
    @abstractmethod
    def featurize(
        self,
        frames: Any,
        h5_path: str,
    ) -> Tuple[List[int], Optional[Dict[str, Any]]]:
        """
        Stream atomic features from structures directly to an HDF5 file.

        Args:
            frames: Input frames (ASE Atoms list, file path, or custom format)
            h5_path: Destination HDF5 file path. The implementation must write:
                - "E": float32 (N_atoms, embedding_dim) — per-atom embeddings
                - "F": float32 (N_atoms, 3) — per-atom forces
                - "frame_counts": int64 (N_frames,) — atoms per frame

        Returns:
            Tuple of:
            - frame_counts (List[int]): Atom counts for each frame
            - metadata (Dict): Source, device, cutoff, modality, etc.

        Raises:
            RuntimeError: If featurization fails
        """
        pass
    
    @abstractmethod
    def supports_batch(self) -> bool:
        """
        Check if batch processing is supported.
        
        Returns:
            True if multiple frames can be processed at once
        """
        pass
    
    @abstractmethod
    def supports_forces(self) -> bool:
        """
        Check if force computation is supported.
        
        Returns:
            True if per-atom forces are computed
        """
        pass
    
    def get_config_dict(self) -> Dict[str, Any]:
        """
        Get configuration as dictionary for serialization.
        
        Returns:
            Dictionary with name, embedding_dim, and other metadata
        """
        return {
            "name": self.name,
            "embedding_dim": self.embedding_dim,
        }


__all__ = ["Featurizer"]
