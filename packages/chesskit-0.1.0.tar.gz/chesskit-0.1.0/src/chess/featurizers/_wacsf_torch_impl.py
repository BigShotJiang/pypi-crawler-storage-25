"""
Pure-PyTorch wACSF (Weighted Atom-Centered Symmetry Functions) implementation.

Reference:
    Gastegger, M., Schwiedrzik, L., Baumgartner, M., Hofstätter, F., & Marquetand, P.
    (2018). wACSF — Weighted atom-centered symmetry functions as descriptors in machine
    learning potentials. J. Chem. Phys., 148(24), 241709.
    https://doi.org/10.1063/1.5019667

    Original Behler ACSF:
    Behler, J. (2011). Atom-centered symmetry functions for constructing high-dimensional
    neural network potentials. J. Chem. Phys., 134(7), 074106.
    https://doi.org/10.1063/1.3553717

GPU acceleration:
    All tensor operations run on the specified device (cpu / cuda / mps).
    Neighbor lists are built on CPU via ASE's neighbor_list, then transferred
    per frame to the target device.

Descriptor layout per atom i  (fixed size, element-agnostic):
    [ G2_0, G2_1, ..., G2_{n2-1},  G4_0, G4_1, ..., G4_{n4-1} ]
    dim = len(g2_params) + len(g4_params)

G2 — radial, element-weighted:
    G2_μ(i) = Σ_j  Z_j · exp(-η_μ (r_ij - Rs_μ)²) · fc(r_ij)

G4 — angular, element-weighted (j < k unique pairs):
    G4_ν(i) = 2^{1-ζ_ν} Σ_{j<k}  Z_j Z_k
              · (1 + λ_ν cos θ_{ijk})^{ζ_ν}
              · exp(-η_ν (r_ij² + r_ik² + r_jk²))
              · fc(r_ij) fc(r_ik) fc(r_jk)

Cosine cutoff:
    fc(r) = 0.5 · (cos(π r / r_cut) + 1)   for r < r_cut
    fc(r) = 0                               otherwise
"""

import math
import os
from concurrent.futures import ThreadPoolExecutor
from typing import List, Tuple, Optional

import numpy as np

from ..core import info, _pick_device, _pick_devices


def _resolve_nl_workers(n_frames: int) -> int:
    """Resolve number of CPU threads for parallel ASE neighbor-list builds.

    ASE's neighbor_list is a C routine that releases the GIL, so a thread
    pool can scale across CPU cores. The worker count is capped by frame
    count and CPU availability, and can be overridden via the
    ``CHESS_WACSF_NL_WORKERS`` environment variable.
    """
    if n_frames <= 1:
        return 1
    env = os.environ.get("CHESS_WACSF_NL_WORKERS", "").strip()
    if env:
        try:
            n = int(env)
            if n > 0:
                return min(n, n_frames)
        except ValueError:
            pass
    cpu = os.cpu_count() or 1
    return max(1, min(cpu, n_frames))

# ---------------------------------------------------------------------------
# Default parameter sets
# ---------------------------------------------------------------------------

#: Default G2 radial parameters: [[η, Rs], ...]
#: Covers a range of radial distances (Rs=0 with varying Gaussian widths).
DEFAULT_G2_PARAMS: List[List[float]] = [
    [0.01, 0.0],
    [0.10, 0.0],
    [0.50, 0.0],
    [1.00, 0.0],
    [2.50, 0.0],
    [5.00, 0.0],
]

#: Default G4 angular parameters: [[η, ζ, λ], ...]
#: λ ∈ {+1, -1} distinguishes "cosine-positive" vs "cosine-negative" environments.
DEFAULT_G4_PARAMS: List[List[float]] = [
    [0.001, 1.0,  1.0],
    [0.001, 1.0, -1.0],
    [0.001, 2.0,  1.0],
    [0.001, 2.0, -1.0],
    [0.010, 1.0,  1.0],
    [0.010, 1.0, -1.0],
]


# ---------------------------------------------------------------------------
# Low-level helper
# ---------------------------------------------------------------------------

def _cosine_cutoff(r: "torch.Tensor", rcut: float) -> "torch.Tensor":
    """Smooth cosine cutoff function.

    Returns 0.5*(cos(π·r/r_cut)+1) for r < r_cut, and 0 otherwise.
    Gradient is continuous at the cutoff boundary.
    """
    import torch
    fc = 0.5 * (torch.cos(math.pi * r / rcut) + 1.0)
    return fc * (r < rcut).to(fc.dtype)


# ---------------------------------------------------------------------------
# Frame I/O helpers
# ---------------------------------------------------------------------------

def _read_frame_forces(atoms) -> np.ndarray:
    """Read per-atom forces or return zeros when unavailable."""
    n_at = len(atoms)
    try:
        F_raw = atoms.get_forces(apply_constraint=False)
        if F_raw is not None and np.asarray(F_raw).size > 0:
            return np.asarray(F_raw, dtype=np.float32)
    except Exception:
        pass

    for fkey in ("forces", "force", "Forces", "Force"):
        if fkey in getattr(atoms, "arrays", {}):
            return atoms.arrays[fkey].astype(np.float32)

    return np.zeros((n_at, 3), dtype=np.float32)


def _build_frame_batch_inputs(frames, rcut: float):
    """Collect a batch of frames into one disconnected super-graph payload."""
    from ase.neighborlist import neighbor_list as ase_nl

    frame_counts: List[int] = [len(at) for at in frames]
    force_chunks: List[np.ndarray] = [_read_frame_forces(at) for at in frames]
    z_parts: List[np.ndarray] = [at.numbers.astype(np.float32) for at in frames]

    # Frame-local atom offsets (cumulative atom count before each frame).
    atom_offsets = np.zeros(len(frames) + 1, dtype=np.int64)
    atom_offsets[1:] = np.cumsum(np.asarray(frame_counts, dtype=np.int64))
    total_atoms = int(atom_offsets[-1])

    # Build neighbor lists in parallel using a thread pool.  ASE's
    # neighbor_list is implemented in C and releases the GIL, so threads
    # scale reasonably across cores without inter-process pickling overhead.
    def _nl_for(idx: int):
        return ase_nl("ijdD", frames[idx], rcut, self_interaction=False)

    n_workers = _resolve_nl_workers(len(frames))
    if n_workers > 1 and len(frames) > 1:
        with ThreadPoolExecutor(max_workers=n_workers) as pool:
            nl_results = list(pool.map(_nl_for, range(len(frames))))
    else:
        nl_results = [_nl_for(i) for i in range(len(frames))]

    idx_i_parts: List[np.ndarray] = []
    idx_j_parts: List[np.ndarray] = []
    d_parts: List[np.ndarray] = []
    D_parts: List[np.ndarray] = []

    for fi, (idx_i, idx_j, d_ij, D_ij) in enumerate(nl_results):
        if len(idx_i) > 0:
            offset = int(atom_offsets[fi])
            idx_i_parts.append(idx_i.astype(np.int64, copy=False) + offset)
            idx_j_parts.append(idx_j.astype(np.int64, copy=False) + offset)
            d_parts.append(d_ij.astype(np.float32, copy=False))
            D_parts.append(D_ij.astype(np.float32, copy=False))

    F_all = np.concatenate(force_chunks, axis=0).astype(np.float32) if force_chunks else np.zeros((0, 3), dtype=np.float32)
    Z_all = np.concatenate(z_parts, axis=0).astype(np.float32) if z_parts else np.zeros((0,), dtype=np.float32)

    if idx_i_parts:
        idx_i_all = np.concatenate(idx_i_parts, axis=0)
        idx_j_all = np.concatenate(idx_j_parts, axis=0)
        d_all = np.concatenate(d_parts, axis=0).astype(np.float32)
        D_all = np.concatenate(D_parts, axis=0).astype(np.float32)

        order = np.argsort(idx_i_all, kind="stable")
        idx_i_all = idx_i_all[order]
        idx_j_all = idx_j_all[order]
        d_all = d_all[order]
        D_all = D_all[order]

        counts = np.bincount(idx_i_all, minlength=total_atoms)
        offsets = np.zeros(total_atoms + 1, dtype=np.int64)
        offsets[1:] = np.cumsum(counts, dtype=np.int64)
    else:
        idx_i_all = np.zeros((0,), dtype=np.int64)
        idx_j_all = np.zeros((0,), dtype=np.int64)
        d_all = np.zeros((0,), dtype=np.float32)
        D_all = np.zeros((0, 3), dtype=np.float32)
        offsets = np.zeros(total_atoms + 1, dtype=np.int64)

    return frame_counts, F_all, Z_all, idx_i_all, idx_j_all, d_all, D_all, offsets, total_atoms


def _wacsf_frame_batch(
    frames,
    g2_params_t: "torch.Tensor",
    g4_params_t: "torch.Tensor",
    rcut: float,
    device: "torch.device",
):
    """Compute wACSF descriptors for a batch of disconnected frames."""
    import torch

    n_g2 = g2_params_t.shape[0]
    n_g4 = g4_params_t.shape[0]
    dim = n_g2 + n_g4

    (
        frame_counts,
        F_all,
        Z_all,
        idx_i_all,
        idx_j_all,
        d_all,
        D_all,
        offsets,
        total_atoms,
    ) = _build_frame_batch_inputs(frames, rcut)

    E = torch.zeros(total_atoms, dim, device=device, dtype=torch.float32)
    if total_atoms == 0 or dim == 0 or idx_i_all.size == 0:
        return E.cpu().numpy(), frame_counts, F_all

    with torch.no_grad():
        # Use from_numpy() for zero-copy host→tensor conversion before
        # device transfer (avoids the redundant Python-list copy that
        # torch.tensor() incurs for NumPy inputs).
        idx_i_t = torch.from_numpy(np.ascontiguousarray(idx_i_all)).to(device=device, dtype=torch.long, non_blocking=True)
        idx_j_t = torch.from_numpy(np.ascontiguousarray(idx_j_all)).to(device=device, dtype=torch.long, non_blocking=True)
        r_all_t = torch.from_numpy(np.ascontiguousarray(d_all)).to(device=device, dtype=torch.float32, non_blocking=True)
        D_all_t = torch.from_numpy(np.ascontiguousarray(D_all)).to(device=device, dtype=torch.float32, non_blocking=True)
        Z_all_t = torch.from_numpy(np.ascontiguousarray(Z_all)).to(device=device, dtype=torch.float32, non_blocking=True)

        if n_g2 > 0:
            eta = g2_params_t[:, 0]
            Rs = g2_params_t[:, 1]
            fc = _cosine_cutoff(r_all_t, rcut)
            diff = r_all_t.unsqueeze(1) - Rs.unsqueeze(0)
            g2_e = torch.exp(-eta.unsqueeze(0) * diff ** 2)
            w_g2 = (Z_all_t.index_select(0, idx_j_t) * fc).unsqueeze(1) * g2_e
            E[:, :n_g2].scatter_add_(
                0, idx_i_t.unsqueeze(1).expand(-1, n_g2), w_g2
            )

        if n_g4 > 0:
            counts_np = offsets[1:] - offsets[:-1]
            max_neigh = int(counts_np.max()) if counts_np.size else 0
            if max_neigh >= 2:
                counts_t = torch.from_numpy(np.ascontiguousarray(counts_np)).to(
                    device=device, dtype=torch.long, non_blocking=True
                )
                atom_ids = torch.repeat_interleave(
                    torch.arange(total_atoms, device=device, dtype=torch.long),
                    counts_t,
                )
                start_offsets_t = torch.from_numpy(np.ascontiguousarray(offsets[:-1])).to(
                    device=device, dtype=torch.long, non_blocking=True
                )
                local_pos = torch.arange(idx_i_t.numel(), device=device, dtype=torch.long)
                local_pos = local_pos - torch.repeat_interleave(start_offsets_t, counts_t)

                r_pad = torch.zeros((total_atoms, max_neigh), dtype=torch.float32, device=device)
                D_pad = torch.zeros((total_atoms, max_neigh, 3), dtype=torch.float32, device=device)
                Z_pad = torch.zeros((total_atoms, max_neigh), dtype=torch.float32, device=device)
                valid_pad = torch.zeros((total_atoms, max_neigh), dtype=torch.bool, device=device)

                r_pad[atom_ids, local_pos] = r_all_t
                D_pad[atom_ids, local_pos] = D_all_t
                Z_pad[atom_ids, local_pos] = Z_all_t.index_select(0, idx_j_t)
                valid_pad[atom_ids, local_pos] = True

                eta4 = g4_params_t[:, 0].view(1, 1, -1)
                zeta = g4_params_t[:, 1].view(1, 1, -1)
                lam = g4_params_t[:, 2].view(1, 1, -1)
                prefactor = (2.0 ** (1.0 - g4_params_t[:, 1])).view(1, 1, -1)

                pair_a, pair_b = torch.triu_indices(max_neigh, max_neigh, offset=1, device=device)
                g4_out = torch.zeros((total_atoms, n_g4), dtype=torch.float32, device=device)
                pair_chunk = 512

                for pair_start in range(0, pair_a.numel(), pair_chunk):
                    pair_end = min(pair_start + pair_chunk, pair_a.numel())
                    a_idx = pair_a[pair_start:pair_end]
                    b_idx = pair_b[pair_start:pair_end]

                    valid_pairs = valid_pad[:, a_idx] & valid_pad[:, b_idx]
                    if not bool(valid_pairs.any()):
                        continue

                    r_ij = r_pad[:, a_idx]
                    r_ik = r_pad[:, b_idx]
                    D_j = D_pad[:, a_idx, :]
                    D_k = D_pad[:, b_idx, :]
                    Z_j = Z_pad[:, a_idx]
                    Z_k = Z_pad[:, b_idx]

                    r_jk = torch.norm(D_j - D_k, dim=2)
                    valid_pairs = valid_pairs & (r_jk < rcut)
                    if not bool(valid_pairs.any()):
                        continue

                    denom = (r_ij * r_ik).clamp(min=1e-8)
                    cos_theta = ((D_j * D_k).sum(dim=2) / denom).clamp(-1.0, 1.0)

                    fc_ij = _cosine_cutoff(r_ij, rcut)
                    fc_ik = _cosine_cutoff(r_ik, rcut)
                    fc_jk = _cosine_cutoff(r_jk, rcut)

                    r2_sum = r_ij ** 2 + r_ik ** 2 + r_jk ** 2
                    pair_weight = (
                        Z_j * Z_k * fc_ij * fc_ik * fc_jk * valid_pairs.to(torch.float32)
                    ).unsqueeze(-1)

                    ang = (1.0 + lam * cos_theta.unsqueeze(-1)) ** zeta
                    rad = torch.exp(-eta4 * r2_sum.unsqueeze(-1))
                    contrib = (prefactor * ang * rad * pair_weight).sum(dim=1)
                    g4_out = g4_out + contrib

                E[:, n_g2:] = g4_out

    return E.cpu().numpy(), frame_counts, F_all


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def wacsf_embeddings_impl(
    frames,
    g2_params: List[List[float]],
    g4_params: List[List[float]],
    rcut: float,
    device_pref: str,
    h5_path: str,
    batch_size: int = 64,
    multi_gpu: bool = False,
    gpu_ids: Optional[List[int]] = None,
) -> Tuple[List[int], str]:
    """Compute wACSF descriptors for a list of ASE Atoms and write to HDF5.

    Processes frames in mini-batches on a disconnected super-graph. GPU parallelism
    is exploited across edges/triplets from multiple frames at once. All embeddings
    are collected in memory, globally z-score normalised, then written to a single
    HDF5 file with lzf compression.

    Args:
        frames:      List of ASE Atoms objects.
        g2_params:   G2 radial parameters  [[η, Rs], ...].
        g4_params:   G4 angular parameters [[η, ζ, λ], ...].
        rcut:        Neighbor cutoff radius in Angstroms.
        device_pref: Device string (``"auto"`` | ``"cuda"`` | ``"cuda:0"``
                     | ``"mps"`` | ``"cpu"``).
        h5_path:     Output HDF5 file path (created or overwritten).
        batch_size:  Frames per GPU batch.

    Returns:
        ``(frame_counts, dev_str)``
        - *frame_counts*: list of per-frame atom counts.
        - *dev_str*: device string actually used.

    Writes ``h5_path`` containing:
        - ``"E"``            float32 (N_atoms, dim)  — z-score normalised embeddings.
        - ``"F"``            float32 (N_atoms, 3)    — per-atom forces (zeros if absent).
        - ``"frame_counts"`` int64   (N_frames,)     — atoms per frame.
    """
    try:
        import torch
        import h5py
    except ImportError as exc:
        raise ImportError(
            "wACSF requires torch, ase, and h5py. "
            "Install with: pip install torch ase h5py"
        ) from exc

    # ── Device selection ────────────────────────────────────────────────────
    if multi_gpu:
        dev_str, device_ids = _pick_devices(multi_gpu=True, gpu_ids=gpu_ids)
    else:
        dev_str = _pick_device() if device_pref == "auto" else device_pref
        device_ids = None

    device  = torch.device(dev_str)
    info(f"wACSF inference device: {device}.")

    n_g2 = len(g2_params)
    n_g4 = len(g4_params)
    dim  = n_g2 + n_g4

    n_frames = len(frames)
    out_dir  = os.path.dirname(os.path.abspath(h5_path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    if multi_gpu and dev_str == "cuda" and device_ids and len(device_ids) > 1:
        import torch.multiprocessing as mp
        import h5py
        from ase.io import read as _ase_read, write as _ase_write

        tmp_xyz = os.path.join(out_dir, "_wacsf_tmp_frames.extxyz")
        _ase_write(tmp_xyz, list(frames), format="extxyz")

        n_gpus = len(device_ids)
        shard_size = (n_frames + n_gpus - 1) // n_gpus
        frame_splits = [
            (i * shard_size, min((i + 1) * shard_size, n_frames))
            for i in range(n_gpus)
        ]
        frame_splits = [(lo, hi) for lo, hi in frame_splits if lo < hi]
        actual_n = len(frame_splits)
        used_gpu_ids = device_ids[:actual_n]
        shard_paths = [
            os.path.join(out_dir, f"_wacsf_shard_{i}.h5") for i in range(actual_n)
        ]

        info(
            f"Launching {actual_n} wACSF worker process(es) across GPUs {used_gpu_ids}."
        )
        mp.spawn(
            _wacsf_inference_worker,
            args=(
                used_gpu_ids,
                frame_splits,
                tmp_xyz,
                shard_paths,
                g2_params,
                g4_params,
                rcut,
                batch_size,
            ),
            nprocs=actual_n,
            join=True,
        )

        E_parts: List[np.ndarray] = []
        F_parts: List[np.ndarray] = []
        frame_counts: List[int] = []
        for sp in shard_paths:
            with h5py.File(sp, "r") as h5:
                E_parts.append(h5["E"][:])
                F_parts.append(h5["F"][:])
                frame_counts.extend(h5["frame_counts"][:].tolist())
            try:
                os.remove(sp)
            except OSError:
                pass

        try:
            os.remove(tmp_xyz)
        except OSError:
            pass

        E_all = np.concatenate(E_parts, axis=0).astype(np.float32)
        F_all = np.concatenate(F_parts, axis=0).astype(np.float32)

        mu = E_all.mean(axis=0, keepdims=True)
        sd = E_all.std(axis=0, keepdims=True) + 1e-12
        E_norm = ((E_all - mu) / sd).astype(np.float32)

        chunk_rows = min(1024, max(1, E_norm.shape[0]))
        with h5py.File(h5_path, "w") as h5:
            h5.create_dataset(
                "E", data=E_norm, dtype="float32",
                chunks=(chunk_rows, dim), compression="lzf",
            )
            h5.create_dataset(
                "F", data=F_all, dtype="float32",
                chunks=(chunk_rows, 3), compression="lzf",
            )
            h5.create_dataset(
                "frame_counts",
                data=np.array(frame_counts, dtype=np.int64),
            )

        info(
            f"wACSF embeddings written: {E_norm.shape[0]} atom(s) across {n_frames} frame(s) to {h5_path}"
        )
        return frame_counts, f"cuda:{used_gpu_ids[0]}"

    # Pre-build parameter tensors on device (reused across frames)
    g2_t = (
        torch.tensor(g2_params, dtype=torch.float32, device=device)
        if n_g2 > 0
        else torch.zeros(0, 2, dtype=torch.float32, device=device)
    )
    g4_t = (
        torch.tensor(g4_params, dtype=torch.float32, device=device)
        if n_g4 > 0
        else torch.zeros(0, 3, dtype=torch.float32, device=device)
    )

    frame_counts: List[int] = []
    E_chunks: List[np.ndarray] = []
    F_chunks: List[np.ndarray] = []
    frame_batch_size = max(int(batch_size), 1)
    progress_every = max(int(batch_size) * 50, 5000)

    info(f"Preparing wACSF descriptors for {n_frames} frame(s) with dim={dim} and rcut={rcut} A.")

    batch_idx = 0
    for batch_start in range(0, n_frames, frame_batch_size):
        batch_end = min(batch_start + frame_batch_size, n_frames)
        batch_frames = frames[batch_start:batch_end]
        E_batch, frame_counts_batch, F_batch = _wacsf_frame_batch(
            batch_frames, g2_t, g4_t, rcut, device
        )
        frame_counts.extend(frame_counts_batch)
        E_chunks.append(E_batch)
        F_chunks.append(F_batch)
        
        batch_idx += 1
        if batch_idx % max(1, progress_every // frame_batch_size) == 0 or batch_end == n_frames:
            info(f"wACSF progress: {batch_end}/{n_frames} frame(s) processed.")

    # ── Concatenate ─────────────────────────────────────────────────────────
    E_all = np.concatenate(E_chunks, axis=0).astype(np.float32)
    F_all = np.concatenate(F_chunks, axis=0).astype(np.float32)

    # ── Global z-score normalisation ────────────────────────────────────────
    mu    = E_all.mean(axis=0, keepdims=True)
    sd    = E_all.std(axis=0,  keepdims=True) + 1e-12
    E_norm = ((E_all - mu) / sd).astype(np.float32)

    # ── Write HDF5 ───────────────────────────────────────────────────────────
    chunk_rows = min(1024, max(1, E_norm.shape[0]))
    with h5py.File(h5_path, "w") as h5:
        h5.create_dataset(
            "E", data=E_norm, dtype="float32",
            chunks=(chunk_rows, dim), compression="lzf",
        )
        h5.create_dataset(
            "F", data=F_all, dtype="float32",
            chunks=(chunk_rows, 3), compression="lzf",
        )
        h5.create_dataset(
            "frame_counts",
            data=np.array(frame_counts, dtype=np.int64),
        )

    info(
        f"wACSF embeddings written: {E_norm.shape[0]} atom(s) across {n_frames} frame(s) to {h5_path}"
    )
    return frame_counts, dev_str


def _wacsf_inference_worker(
    rank: int,
    device_ids: List[int],
    frame_splits: List[Tuple[int, int]],
    tmp_xyz_path: str,
    shard_paths: List[str],
    g2_params: List[List[float]],
    g4_params: List[List[float]],
    rcut: float,
    batch_size: int,
) -> None:
    """Worker for multi-GPU wACSF inference (one process per GPU)."""
    import torch
    import h5py
    from ase.io import read as _ase_read

    frame_lo, frame_hi = frame_splits[rank]
    shard_path = shard_paths[rank]
    device_id = device_ids[rank]
    dev = torch.device(f"cuda:{device_id}")

    frames = list(_ase_read(tmp_xyz_path, index=f"{frame_lo}:{frame_hi}"))
    n_local = len(frames)

    n_g2 = len(g2_params)
    n_g4 = len(g4_params)
    g2_t = (
        torch.tensor(g2_params, dtype=torch.float32, device=dev)
        if n_g2 > 0
        else torch.zeros(0, 2, dtype=torch.float32, device=dev)
    )
    g4_t = (
        torch.tensor(g4_params, dtype=torch.float32, device=dev)
        if n_g4 > 0
        else torch.zeros(0, 3, dtype=torch.float32, device=dev)
    )

    frame_counts: List[int] = []
    E_chunks: List[np.ndarray] = []
    F_chunks: List[np.ndarray] = []

    frame_batch_size = max(int(batch_size), 1)

    for batch_start in range(0, n_local, frame_batch_size):
        batch_end = min(batch_start + frame_batch_size, n_local)
        batch_frames = frames[batch_start:batch_end]
        E_batch, frame_counts_batch, F_batch = _wacsf_frame_batch(
            batch_frames, g2_t, g4_t, rcut, dev
        )
        frame_counts.extend(frame_counts_batch)
        E_chunks.append(E_batch)
        F_chunks.append(F_batch)
        print(f"[wACSF worker {rank}] {batch_end}/{n_local} frames processed")

    E_shard = np.concatenate(E_chunks, axis=0).astype(np.float32)
    F_shard = np.concatenate(F_chunks, axis=0).astype(np.float32)

    with h5py.File(shard_path, "w") as h5:
        h5.create_dataset("E", data=E_shard)
        h5.create_dataset("F", data=F_shard)
        h5.create_dataset("frame_counts", data=np.array(frame_counts, dtype=np.int64))


__all__ = [
    "DEFAULT_G2_PARAMS",
    "DEFAULT_G4_PARAMS",
    "wacsf_embeddings_impl",
]
