"""
Featurizer package: pluggable atomic feature extractors.

Provides abstract base class, registry, and concrete implementations.

Available featurizers (registered automatically at import time):
    - ``"sevennet"`` — SevenNet GNN embeddings (requires sevenn, torch_geometric)
    - ``"wacsf"``    — Weighted ACSF descriptors (requires torch, ase, h5py)

Example:
    >>> from chess.featurizers import FeaturizerRegistry
    >>> featurizer = FeaturizerRegistry.create("wacsf", rcut=6.0)
    >>> frame_counts, metadata = featurizer.featurize(frames, "embeddings.h5")
"""

from .base import Featurizer
from .registry import FeaturizerRegistry

# ---------------------------------------------------------------------------
# Eager registration — import each featurizer module so that the
# @FeaturizerRegistry.register(...) decorator runs at package import time.
# ImportError / RuntimeError from missing optional deps are suppressed here;
# they will surface with a clear message when the featurizer is instantiated.
# ---------------------------------------------------------------------------

def _register_all() -> None:
    try:
        from . import sevennet as _sn  # noqa: F401  triggers @register("sevennet")
    except Exception:
        pass
    try:
        from . import wacsf as _wa    # noqa: F401  triggers @register("wacsf")
    except Exception:
        pass


_register_all()


# ---------------------------------------------------------------------------
# Lazy attribute access for class imports
# ---------------------------------------------------------------------------

def __getattr__(name: str):
    if name == "SevenNetFeaturizer":
        from .sevennet import SevenNetFeaturizer
        return SevenNetFeaturizer
    if name == "WaCSFFeaturizer":
        from .wacsf import WaCSFFeaturizer
        return WaCSFFeaturizer
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "Featurizer",
    "FeaturizerRegistry",
    "SevenNetFeaturizer",
    "WaCSFFeaturizer",
]
