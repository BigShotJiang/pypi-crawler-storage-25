"""
Weighted ACSF (wACSF) featurizer — model-agnostic, pure-PyTorch.

Produces fixed-size per-atom embeddings that are independent of the set of
chemical species in the dataset (model-agnostic property), achieved by
weighting symmetry-function contributions with neighbor atomic numbers Z_j
(G2) and Z_j·Z_k (G4) instead of using element-specific basis functions.
"""

from typing import Any, Dict, List, Optional, Tuple

from .base import Featurizer
from .registry import FeaturizerRegistry
from ._wacsf_torch_impl import DEFAULT_G2_PARAMS, DEFAULT_G4_PARAMS


@FeaturizerRegistry.register("wacsf")
class WaCSFFeaturizer(Featurizer):
    """Weighted Atom-Centered Symmetry Functions (wACSF) descriptor.

    Produces fixed-size, **element-agnostic** per-atom embeddings.  The
    descriptor size is determined solely by the number of G2 and G4 parameter
    sets and does **not** grow with the number of chemical species — satisfying
    the model-agnostic requirement for the CHESS pipeline.

    Descriptor layout (per atom i):
        ``[G2_0, …, G2_{n2-1},  G4_0, …, G4_{n4-1}]``

    Reference:
        Gastegger et al., J. Chem. Phys. **148**, 241709 (2018).
        https://doi.org/10.1063/1.5019667

    GPU acceleration is available via the ``device`` parameter.  All tensor
    operations run on the selected device; neighbor lists are built on CPU
    via ASE and transferred per frame.

    Args:
        rcut:       Neighbor cutoff radius in Angstroms (default: 6.0).
        g2_params:  List of ``[η, Rs]`` pairs for G2 radial functions.
                    Defaults to 6 standard parameters covering 0–6 Å.
        g4_params:  List of ``[η, ζ, λ]`` triples for G4 angular functions.
                    Defaults to 6 standard parameters (λ ∈ {+1, −1}).
        device:     Compute device — ``"auto"`` (default), ``"cuda"``,
                    ``"cuda:0"``, ``"mps"``, or ``"cpu"``.
        multi_gpu:  Enable multi-GPU frame sharding when CUDA is available.
        gpu_ids:    Specific GPU indices to use in multi-GPU mode.
        batch_size: Number of frames per GPU batch.

    Example:
        >>> feat = WaCSFFeaturizer(rcut=5.0, device="cuda")
        >>> frame_counts, meta = feat.featurize(frames, "embeddings.h5")
    """

    def __init__(
        self,
        rcut: float = 6.0,
        g2_params: Optional[List[List[float]]] = None,
        g4_params: Optional[List[List[float]]] = None,
        device: str = "auto",
        multi_gpu: bool = False,
        gpu_ids: Optional[List[int]] = None,
        batch_size: int = 64,
    ) -> None:
        self.rcut        = float(rcut)
        self.g2_params   = g2_params if g2_params is not None else DEFAULT_G2_PARAMS
        self.g4_params   = g4_params if g4_params is not None else DEFAULT_G4_PARAMS
        self.device_pref = str(device)
        self.multi_gpu   = bool(multi_gpu)
        self.gpu_ids     = gpu_ids if gpu_ids is None else list(gpu_ids)
        self.batch_size  = int(batch_size)

        self._embedding_dim = len(self.g2_params) + len(self.g4_params)
        if self._embedding_dim == 0:
            raise ValueError(
                "WaCSFFeaturizer requires at least one G2 or G4 parameter set."
            )

        self._validate_dependencies()

    # ── Dependency check ─────────────────────────────────────────────────────

    def _validate_dependencies(self) -> None:
        """Verify required packages are importable."""
        missing = []
        for pkg in ("torch", "h5py"):
            try:
                __import__(pkg)
            except ImportError:
                missing.append(pkg)
        try:
            from ase.neighborlist import neighbor_list  # noqa: F401
        except ImportError:
            missing.append("ase")
        if missing:
            raise RuntimeError(
                f"wACSF requires: {', '.join(missing)}. "
                "Install with: pip install torch ase h5py"
            )

    @staticmethod
    def _is_oom_error(exc: Exception) -> bool:
        msg = str(exc).lower()
        return (
            "out of memory" in msg
            or "cuda oom" in msg
            or "cudnn_status_alloc_failed" in msg
            or "mps backend out of memory" in msg
        )

    # ── Abstract property implementations ────────────────────────────────────

    @property
    def name(self) -> str:
        return "wacsf"

    @property
    def embedding_dim(self) -> int:
        return self._embedding_dim

    def supports_batch(self) -> bool:
        """wACSF processes frames sequentially (GPU parallelism within each frame)."""
        return True

    def supports_forces(self) -> bool:
        """wACSF is a descriptor; forces are read from frames if present."""
        return False

    # ── Core featurize ────────────────────────────────────────────────────────

    def featurize(
        self,
        frames: Any,
        h5_path: str,
    ) -> Tuple[List[int], Optional[Dict[str, Any]]]:
        """Compute wACSF descriptors and write to HDF5.

        Args:
            frames:   List of ASE Atoms objects, or path to an extxyz file.
            h5_path:  Destination HDF5 file path.  Written datasets:
                      - ``"E"``            float32 (N_atoms, dim)  normalised embeddings.
                      - ``"F"``            float32 (N_atoms, 3)    per-atom forces or zeros.
                      - ``"frame_counts"`` int64   (N_frames,)     atoms per frame.

        Returns:
            ``(frame_counts, metadata)``
        """
        from ._wacsf_torch_impl import wacsf_embeddings_impl

        if isinstance(frames, str):
            try:
                from ase.io import read
                frames = list(read(frames, index=":"))
            except ImportError:
                raise ImportError("ASE is required to load structures from a file.")

        if not isinstance(frames, list):
            frames = list(frames)

        trial_bs = max(int(self.batch_size), 1)
        while True:
            try:
                frame_counts, dev_str = wacsf_embeddings_impl(
                    frames      = frames,
                    g2_params   = self.g2_params,
                    g4_params   = self.g4_params,
                    rcut        = self.rcut,
                    device_pref = self.device_pref,
                    h5_path     = h5_path,
                    batch_size  = trial_bs,
                    multi_gpu   = self.multi_gpu,
                    gpu_ids     = self.gpu_ids,
                )
                break
            except Exception as exc:
                if (not self._is_oom_error(exc)) or trial_bs <= 1:
                    raise
                next_bs = max(1, trial_bs // 2)
                from ..core import info
                info(
                    f"Memory limit reached at batch size {trial_bs}. Retrying with {next_bs}."
                )
                trial_bs = next_bs

        metadata: Dict[str, Any] = {
            "source"        : "wacsf",
            "device"        : dev_str,
            "rcut"          : self.rcut,
            "n_g2"          : len(self.g2_params),
            "n_g4"          : len(self.g4_params),
            "embedding_dim" : self.embedding_dim,
            "multi_gpu"     : self.multi_gpu,
            "gpu_ids"       : self.gpu_ids,
            "batch_size"    : trial_bs,
            "g2_params"     : self.g2_params,
            "g4_params"     : self.g4_params,
        }
        return frame_counts, metadata

    # ── Serialization ─────────────────────────────────────────────────────────

    def get_config_dict(self) -> Dict[str, Any]:
        return {
            **super().get_config_dict(),
            "rcut"       : self.rcut,
            "g2_params"  : self.g2_params,
            "g4_params"  : self.g4_params,
            "device"     : self.device_pref,
            "multi_gpu"  : self.multi_gpu,
            "gpu_ids"    : self.gpu_ids,
            "batch_size" : self.batch_size,
        }


__all__ = ["WaCSFFeaturizer"]
