"""
Featurizer registry system for dynamic plugin loading.
"""

from typing import Dict, Type, Optional
from .base import Featurizer
from ..core import info


class FeaturizerRegistry:
    """
    Central registry for featurizer implementations.
    
    Enables registration and creation of featurizers using a plugin pattern.
    Featurizers are registered via decorator or explicit registration.
    
    Example:
        >>> @FeaturizerRegistry.register("myfeaturizer")
        ... class MyFeaturizer(Featurizer):
        ...     pass
        
        >>> feat = FeaturizerRegistry.create("myfeaturizer", param=value)
    """
    
    _registry: Dict[str, Type[Featurizer]] = {}
    
    @classmethod
    def register(cls, name: str):
        """
        Decorator to register a Featurizer class.
        
        Args:
            name: Unique identifier for this featurizer
            
        Returns:
            Decorator function
            
        Usage:
            @FeaturizerRegistry.register("sevennet")
            class SevenNetFeaturizer(Featurizer):
                ...
        """
        def wrapper(featurizer_cls: Type[Featurizer]) -> Type[Featurizer]:
            if name in cls._registry:
                info(f"Warning: overriding featurizer '{name}'")
            cls._registry[name] = featurizer_cls
            return featurizer_cls
        return wrapper
    
    @classmethod
    def get(cls, name: str) -> Type[Featurizer]:
        """
        Get registered featurizer class by name.
        
        Args:
            name: Featurizer identifier
            
        Returns:
            Featurizer class
            
        Raises:
            SystemExit: If featurizer not found
        """
        if name not in cls._registry:
            avail = ', '.join(sorted(cls._registry.keys()))
            raise SystemExit(
                f"Unknown featurizer: '{name}'. Available: {avail}"
            )
        return cls._registry[name]
    
    @classmethod
    def create(cls, name: str, **kwargs) -> Featurizer:
        """
        Create and return a featurizer instance.
        
        Args:
            name: Featurizer identifier
            **kwargs: Arguments passed to featurizer __init__
            
        Returns:
            Featurizer instance
            
        Raises:
            SystemExit: If featurizer not found or instantiation fails
        """
        try:
            featurizer_cls = cls.get(name)
            instance = featurizer_cls(**kwargs)
            dim = int(instance.embedding_dim)
            if dim > 0:
                info(f"Featurizer initialized: {name} (embedding dim: {dim})")
            else:
                info(
                    f"Featurizer initialized: {name} "
                    "(embedding dim: pending auto-detect)"
                )
            return instance
        except Exception as e:
            raise SystemExit(f"Failed to create featurizer '{name}': {e}")
    
    @classmethod
    def list_available(cls) -> Dict[str, Type[Featurizer]]:
        """
        List all registered featurizers.
        
        Returns:
            Dictionary {name: featurizer_class}
        """
        return cls._registry.copy()
    
    @classmethod
    def summary(cls) -> str:
        """
        Get human-readable summary of registered featurizers.
        
        Returns:
            Formatted string with featurizer info
        """
        if not cls._registry:
            return "No featurizers registered"
        
        lines = ["Registered Featurizers:"]
        for name in sorted(cls._registry.keys()):
            try:
                # Try to instantiate with minimal args to get embedding_dim
                lines.append(f"  - {name}")
            except Exception:
                lines.append(f"  - {name} (failed to load)")
        return "\n".join(lines)


__all__ = ["FeaturizerRegistry"]
