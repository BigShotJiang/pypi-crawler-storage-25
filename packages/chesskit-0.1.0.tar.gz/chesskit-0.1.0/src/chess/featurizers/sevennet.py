"""
SevenNet featurizer implementation.

Provides atomic embeddings via the SevenNet neural network potential.
Requires: torch, sevenn package
"""

import os
import numpy as np
from typing import List, Tuple, Optional, Dict, Any, Union

from .base import Featurizer
from .registry import FeaturizerRegistry
from ..core import info, _pick_device


@FeaturizerRegistry.register("sevennet")
class SevenNetFeaturizer(Featurizer):
    """
    Atomic embeddings from SevenNet model.
    
    SevenNet is a graph neural network potential that produces
    per-atom embeddings suitable for geometric diversity.
    The embedding dimension is auto-detected from model output.
    
    Requirements:
        - torch (>=1.13.0)
        - torch_geometric (>=2.2.0)
        - sevenn (>=0.1.0)
        - ase (>=3.22.0)
    
    Args:
        model: SevenNet model identifier (default: "7net-0")
        device: Compute device ("auto", "cuda", "mps", "cpu")
        cutoff: Graph cutoff radius in Angstroms (default: 6.0)
        embedding_dir: Directory to cache embeddings (default: "./embedding_files")
        chunk_save_interval: Save checkpoint every N batches (default: 100)
        chunk_size: Atoms per chunk file (default: 1000)
        modality: SevenNet modality parameter (default: None)
        enable_cueq: Enable cuEquivariance inference backend when supported
        enable_flash: Enable flashTP inference backend when supported
        enable_oeq: Enable OpenEquivariance inference backend when supported
        multi_gpu: Enable multi-GPU DataParallel mode (default: False)
        gpu_ids: Specific GPU indices to use (e.g., [0, 1, 2]) or None for all
        batch_size: DataLoader batch size (int) or "auto" for heuristic tuning
    """
    
    def __init__(
        self,
        model: str = "7net-0",
        device: str = "auto",
        cutoff: float = 6.0,
        modality: Optional[str] = None,
        enable_cueq: bool = False,
        enable_flash: bool = False,
        enable_oeq: bool = False,
        multi_gpu: bool = False,
        gpu_ids: Optional[List[int]] = None,
        batch_size: Union[int, str] = 32,
    ):
        self.model_name = str(model)
        self.device_pref = str(device)
        self.cutoff = float(cutoff)
        self.modality = modality
        self.enable_cueq = bool(enable_cueq)
        self.enable_flash = bool(enable_flash)
        self.enable_oeq = bool(enable_oeq)
        self.multi_gpu = bool(multi_gpu)
        self.gpu_ids = gpu_ids if gpu_ids is None else list(gpu_ids)
        self.batch_size = batch_size

        # Auto-detected after first successful featurize() run from HDF5 E.shape[1].
        self._embedding_dim: Optional[int] = None

        self._validate_dependencies()

    def _resolve_batch_size(self, frames: List[Any]) -> int:
        """Resolve batch size from config, supporting 'auto'."""
        if isinstance(self.batch_size, str):
            token = self.batch_size.strip().lower()
            if token != "auto":
                raise ValueError(
                    f"Invalid batch_size={self.batch_size!r}. "
                    "Use a positive integer or 'auto'."
                )
            return self._estimate_auto_batch_size(frames)

        bs = int(self.batch_size)
        if bs <= 0:
            raise ValueError(f"batch_size must be positive, got {self.batch_size!r}")
        return bs

    def _estimate_auto_batch_size(self, frames: List[Any]) -> int:
        """Conservative heuristic for SevenNet DataLoader batch size.

        The estimate is intentionally conservative to reduce OOM risk and is
        scaled by frame size (atoms per frame) and available VRAM tier.
        """
        n = len(frames)
        if n == 0:
            return 1

        sample_n = min(32, n)
        atoms = [int(len(frames[i])) for i in range(sample_n)]
        p90_atoms = int(np.percentile(np.asarray(atoms, dtype=np.float64), 90.0))
        p90_atoms = max(p90_atoms, 1)

        try:
            import torch
        except Exception:
            # CPU-only fallback; keep modest to avoid host RAM pressure.
            return max(1, min(16, int(120 / p90_atoms * 32)))

        if self.multi_gpu and torch.cuda.is_available():
            ids = self.gpu_ids if self.gpu_ids else list(range(torch.cuda.device_count()))
            ids = [int(i) for i in ids] if ids else [0]
            total_mem = min(
                torch.cuda.get_device_properties(i).total_memory for i in ids
            )
            mem_gb = float(total_mem) / float(1024 ** 3)
        elif (self.device_pref == "auto" and torch.cuda.is_available()) or self.device_pref.startswith("cuda"):
            dev_idx = 0
            if self.device_pref.startswith("cuda:"):
                try:
                    dev_idx = int(self.device_pref.split(":", 1)[1])
                except Exception:
                    dev_idx = 0
            total_mem = torch.cuda.get_device_properties(dev_idx).total_memory
            mem_gb = float(total_mem) / float(1024 ** 3)
        else:
            # MPS/CPU: keep small and stable.
            return max(2, min(16, int(120 / p90_atoms * 32)))

        # VRAM-tier base (per GPU) then down-scale for larger frames.
        if mem_gb <= 8:
            base = 8
        elif mem_gb <= 12:
            base = 12
        elif mem_gb <= 16:
            base = 16
        elif mem_gb <= 24:
            base = 24
        else:
            base = 32

        scale = 150.0 / float(p90_atoms)
        estimate = int(round(base * scale))
        estimate = max(1, min(128, estimate))
        return estimate

    @staticmethod
    def _is_oom_error(exc: Exception) -> bool:
        msg = str(exc).lower()
        return (
            "out of memory" in msg
            or "cuda oom" in msg
            or "cudnn_status_alloc_failed" in msg
            or "mps backend out of memory" in msg
        )
    
    def _validate_dependencies(self) -> None:
        """Check required packages are available."""
        try:
            import torch  # noqa: F401
            import sevenn  # noqa: F401
            import h5py  # noqa: F401
        except ImportError as e:
            raise RuntimeError(
                f"SevenNet requires torch, sevenn, and h5py. Install with: "
                f"pip install torch torch_geometric sevenn h5py"
            ) from e
    
    @property
    def name(self) -> str:
        """Featurizer identifier."""
        return "sevennet"
    
    @property
    def embedding_dim(self) -> int:
        """Output embedding dimension.

        Returns:
            Detected embedding dimension after featurize(); 0 if unknown yet.
        """
        return int(self._embedding_dim) if self._embedding_dim is not None else 0

    def _detect_embedding_dim_from_h5(self, h5_path: str) -> int:
        """Read embedding dimension from HDF5 dataset E.

        Args:
            h5_path: HDF5 path written by sevennet_node_embeddings_impl.

        Returns:
            Embedding dimension inferred from E.shape[1].
        """
        import h5py

        with h5py.File(h5_path, "r") as h5:
            if "E" not in h5:
                raise RuntimeError(f"Missing dataset 'E' in {h5_path}")
            shape = h5["E"].shape
            if len(shape) != 2 or int(shape[1]) <= 0:
                raise RuntimeError(f"Invalid embedding shape for 'E': {shape}")
            return int(shape[1])
    
    def supports_batch(self) -> bool:
        """SevenNet supports batch processing via DataLoader."""
        return True
    
    def supports_forces(self) -> bool:
        """SevenNet can compute atomic forces."""
        return True
    
    def featurize(
        self,
        frames: Any,
        h5_path: str,
    ) -> Tuple[List[int], Optional[Dict[str, Any]]]:
        """
        Stream embeddings to HDF5 and return frame metadata.

        Args:
            frames: List of ASE Atoms objects, or path to extxyz file
            h5_path: Destination HDF5 file path

        Returns:
            (frame_counts, metadata)
        """
        from ._sevennet_impl import sevennet_node_embeddings_impl
        
        # Convert frames if needed
        if isinstance(frames, str):
            # Load from file
            try:
                from ase.io import read
                frames = read(frames, index=":")
            except ImportError:
                raise ImportError("ASE required to load structures")
        
        if not isinstance(frames, list):
            frames = [frames]
        
        resolved_batch_size = self._resolve_batch_size(frames)
        info(f"Batch size resolved: {resolved_batch_size}")

        # Retry with smaller batches on OOM to improve robustness across GPUs.
        trial_bs = resolved_batch_size
        while True:
            try:
                frame_counts, dev_str = sevennet_node_embeddings_impl(
                    frames,
                    model_name=self.model_name,
                    device_pref=self.device_pref,
                    h5_path=h5_path,
                    cutoff=self.cutoff,
                    modality=self.modality,
                    enable_cueq=self.enable_cueq,
                    enable_flash=self.enable_flash,
                    enable_oeq=self.enable_oeq,
                    multi_gpu=self.multi_gpu,
                    gpu_ids=self.gpu_ids,
                    batch_size=trial_bs,
                )
                resolved_batch_size = trial_bs
                break
            except Exception as exc:
                if (not self._is_oom_error(exc)) or trial_bs <= 1:
                    raise
                next_bs = max(1, trial_bs // 2)
                info(
                    f"Memory limit reached at batch size {trial_bs}. Retrying with {next_bs}."
                )
                trial_bs = next_bs

        metadata = {
            "source": "sevennet",
            "model": self.model_name,
            "device": dev_str,
            "cutoff": float(self.cutoff),
            "modality": self.modality,
            "enable_cueq": self.enable_cueq,
            "enable_flash": self.enable_flash,
            "enable_oeq": self.enable_oeq,
            "multi_gpu": self.multi_gpu,
            "gpu_ids": self.gpu_ids,
            "batch_size": resolved_batch_size,
        }

        detected_dim = self._detect_embedding_dim_from_h5(h5_path)
        self._embedding_dim = detected_dim
        metadata["embedding_dim"] = detected_dim

        return frame_counts, metadata
    
    def get_config_dict(self) -> Dict[str, Any]:
        """Get configuration for serialization."""
        return {
            **super().get_config_dict(),
            "model": self.model_name,
            "device": self.device_pref,
            "cutoff": float(self.cutoff),
            "modality": self.modality,
            "enable_cueq": self.enable_cueq,
            "enable_flash": self.enable_flash,
            "enable_oeq": self.enable_oeq,
            "multi_gpu": self.multi_gpu,
            "gpu_ids": self.gpu_ids,
            "batch_size": self.batch_size,
        }


__all__ = ["SevenNetFeaturizer"]
