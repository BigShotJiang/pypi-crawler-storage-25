"""
SevenNet implementation with HDF5 streaming support — compatible with sevenn>=0.12.0.

Embeddings are computed frame-by-frame via SevenNet's graph neural network
and streamed directly to a single HDF5 cache file, keeping peak memory
usage O(batch_size) regardless of dataset size.

SevenNet 0.12.x API changes versus 0.11.x:
  - SevenNetGraphDataset._save_meta() now runs Ridge regression on energy labels,
    which fails for unlabeled inference data even with allow_unlabeled=True.
    Solution: bypass SevenNetGraphDataset entirely and call atoms_to_graph directly.
  - AtomGraphSequential has eval_type_map=True by default, so the model handles
    atomic_numbers → one-hot species index mapping internally.
    Solution: remove manual type_map application; just pass batch to model.
  - atoms_to_graph requires atoms.info['y_energy'] / atoms.arrays['y_force'] keys
    (KeyError if absent). allow_unlabeled=True only suppresses the NaN check, not
    the key-existence check.
    Solution: temporarily attach NaN labels before calling atoms_to_graph.
"""

import contextlib
import inspect
import os
import types
import numpy as np
from typing import List, Optional, Tuple

from ..core import info, _pick_device, _pick_devices


@contextlib.contextmanager
def _disable_sevenn_force_outputs(model):
    """Temporarily disable ForceOutput / ForceStressOutput modules.

    Patching out force layers prevents RuntimeError during embedding-only
    inference ('element 0 of tensors does not require grad') because force
    computation uses torch.autograd.grad on pos.
    """
    target_class_names = {
        "ForceOutput",
        "ForceStressOutput",
        "ForceStressOutputFromEdge",
        "ForceStressOutputFromEdgeParallel",
    }
    patched = []
    for m in model.modules():
        if m.__class__.__name__ in target_class_names and hasattr(m, "forward"):
            orig_forward = m.forward

            def _noop_forward(self, data):  # noqa: E306
                return data

            m.forward = types.MethodType(_noop_forward, m)
            patched.append((m, orig_forward))
    try:
        yield
    finally:
        for m, orig_forward in patched:
            m.forward = orig_forward


def _build_calculator_kwargs(
    calculator_cls,
    model_name: str,
    device: str,
    modality: Optional[str],
    enable_cueq: bool,
    enable_flash: bool,
    enable_oeq: bool,
) -> dict:
    """Build SevenNetCalculator kwargs with version-safe argument filtering."""
    kwargs = {"model": model_name, "device": device}
    if modality is not None:
        kwargs["modal"] = modality

    optional_flags = {
        "enable_cueq": bool(enable_cueq),
        "enable_flash": bool(enable_flash),
        "enable_oeq": bool(enable_oeq),
    }

    try:
        params = inspect.signature(calculator_cls.__init__).parameters
    except (TypeError, ValueError):
        params = {}

    for name, value in optional_flags.items():
        if name in params:
            kwargs[name] = value
        elif value:
            info(
                f"Requested accelerator option '{name}' is not supported by the installed sevenn version. Ignoring it."
            )

    return kwargs


def _sanitize_worker_backend_flags(
    enable_cueq: bool,
    enable_flash: bool,
    enable_oeq: bool,
    *,
    multi_gpu: bool,
    n_gpu_workers: int,
) -> Tuple[bool, bool, bool]:
    """Normalize accelerator flags for spawned worker execution.

    Keep the user-requested backend intact — including flashTP in multi-GPU
    mode — while enforcing SevenNet's "one accelerator at a time" contract.
    Each worker then initializes its own pinned CUDA context before model
    construction.
    """
    cueq = bool(enable_cueq)
    flash = bool(enable_flash)
    oeq = bool(enable_oeq)

    if sum((cueq, flash, oeq)) > 1:
        raise ValueError(
            "SevenNet supports at most one accelerator backend at a time. "
            f"Received enable_cueq={cueq}, enable_flash={flash}, enable_oeq={oeq}."
        )

    if multi_gpu and int(n_gpu_workers) > 1:
        info(
            "SevenNet multi-GPU mode detected: preserving the requested backend "
            f"flags across {int(n_gpu_workers)} spawned worker(s)."
        )

    return cueq, flash, oeq


def _attach_batch_modality(batch, modality: Optional[str]) -> None:
    """Attach SevenNet modality to a batched graph before direct model calls."""
    if modality is None:
        return

    try:
        import sevenn._keys as KEY
    except ImportError:
        return

    batch[KEY.DATA_MODALITY] = modality


def _normalize_cuda_device(device_like):
    """Return a CUDA device with an explicit index, defaulting to device 0."""
    import torch

    dev = device_like if isinstance(device_like, torch.device) else torch.device(device_like)
    if dev.type != "cuda":
        return dev

    idx = dev.index
    if idx is None:
        try:
            idx = int(torch.cuda.current_device())
        except Exception:
            idx = 0
    return torch.device(f"cuda:{int(idx)}")


def _pin_cuda_worker_device(device_id: int):
    """Pin a spawned worker to its CUDA device before backend/model init."""
    import torch

    dev = _normalize_cuda_device(f"cuda:{int(device_id)}")
    if torch.cuda.is_available():
        torch.cuda.set_device(dev)
        # Eagerly initialize the device-local CUDA context before SevenNet /
        # flashTP converts backend kernels inside the spawned worker.
        torch.empty(1, device=dev)
        torch.cuda.synchronize(dev)
    return dev


def _warmup_sevennet_model(model, loader, device, modality: Optional[str]) -> None:
    """Run a small warm-up forward pass after backend conversion."""
    import torch

    try:
        first_batch = next(iter(loader))
    except StopIteration:
        return

    with _disable_sevenn_force_outputs(model):
        with torch.no_grad():
            first_batch = first_batch.to(device)
            _attach_batch_modality(first_batch, modality)
            _ = model(first_batch)
            if getattr(device, "type", None) == "cuda" and torch.cuda.is_available():
                torch.cuda.synchronize(device)

    del first_batch
    if getattr(device, "type", None) == "cuda" and torch.cuda.is_available():
        torch.cuda.empty_cache()


def _parse_mp_inference_worker_args(*worker_args):
    """Normalize ``mp.spawn`` argument layout.

    Expects exactly 11 positional arguments after ``rank``.
    """
    n_args = len(worker_args)

    if n_args == 11:
        (
            device_ids,
            frame_splits,
            tmp_xyz_path,
            shard_paths,
            model_name,
            cutoff,
            modality,
            enable_cueq,
            enable_flash,
            enable_oeq,
            batch_size,
        ) = worker_args
    else:
        raise TypeError(
            "_mp_inference_worker received an unsupported argument layout: "
            f"{n_args} positional argument(s) after rank (expected 11)."
        )

    return (
        device_ids,
        frame_splits,
        tmp_xyz_path,
        shard_paths,
        model_name,
        float(cutoff),
        modality,
        bool(enable_cueq),
        bool(enable_flash),
        bool(enable_oeq),
        int(batch_size),
    )


def _build_graph_list(
    frames: List,
    cutoff: float,
) -> List:
    """Build a list of AtomGraphData from ASE Atoms without energy/force labels.

    SevenNet 0.12.x requires y_energy / y_force keys on atoms objects even when
    allow_unlabeled=True.  We attach NaN dummy labels, build the graph (which
    stores pre-computed edge vectors), and clean up the atoms afterwards.

    Args:
        frames: List of ASE Atoms objects.
        cutoff: Neighbor cutoff in Angstroms.

    Returns:
        List of AtomGraphData (CPU tensors), ready for DataLoader.
    """
    from sevenn.train.dataload import atoms_to_graph
    from sevenn.atom_graph_data import AtomGraphData

    graph_list = []
    for atoms in frames:
        atoms.info["y_energy"] = np.nan
        atoms.arrays["y_force"] = np.full((len(atoms), 3), np.nan, dtype=np.float32)
        try:
            g = atoms_to_graph(
                atoms,
                cutoff,
                transfer_info=False,
                allow_unlabeled=True,
                with_shift=False,
            )
            graph_list.append(AtomGraphData.from_numpy_dict(g))
        finally:
            atoms.info.pop("y_energy", None)
            atoms.arrays.pop("y_force", None)

    return graph_list


def _mp_inference_worker(rank: int, *worker_args) -> None:
    """Worker function for multi-GPU SevenNet inference (sevenn>=0.12.0).
    """
    import os as _os
    import types as _types
    import contextlib as _contextlib
    import numpy as _np
    import torch
    import h5py
    import sevenn._keys as KEY
    from sevenn.calculator import SevenNetCalculator
    from sevenn.atom_graph_data import AtomGraphData
    from sevenn.train.dataload import atoms_to_graph as _atoms_to_graph
    from torch_geometric.loader import DataLoader
    from ase.io import read as _ase_read

    (
        device_ids,
        frame_splits,
        tmp_xyz_path,
        shard_paths,
        model_name,
        cutoff,
        modality,
        enable_cueq,
        enable_flash,
        enable_oeq,
        batch_size,
    ) = _parse_mp_inference_worker_args(*worker_args)

    frame_lo, frame_hi = frame_splits[rank]
    shard_path = shard_paths[rank]
    device_id = device_ids[rank]
    dev = _pin_cuda_worker_device(device_id)

    # Read only this worker's frame slice from the shared extxyz.
    frames = list(_ase_read(tmp_xyz_path, index=f"{frame_lo}:{frame_hi}"))
    n_local = len(frames)

    # Build graph list directly — avoids SevenNetGraphDataset._save_meta failure.
    graph_list = []
    for atoms in frames:
        atoms.info["y_energy"] = _np.nan
        atoms.arrays["y_force"] = _np.full((len(atoms), 3), _np.nan, dtype=_np.float32)
        try:
            g = _atoms_to_graph(
                atoms, cutoff, transfer_info=False, allow_unlabeled=True, with_shift=False
            )
            graph_list.append(AtomGraphData.from_numpy_dict(g))
        finally:
            atoms.info.pop("y_energy", None)
            atoms.arrays.pop("y_force", None)

    loader = DataLoader(graph_list, batch_size=int(batch_size), shuffle=False, num_workers=0)

    calc_kwargs = _build_calculator_kwargs(
        SevenNetCalculator,
        model_name=model_name,
        device=str(dev),
        modality=modality,
        enable_cueq=enable_cueq,
        enable_flash=enable_flash,
        enable_oeq=enable_oeq,
    )
    calc = SevenNetCalculator(**calc_kwargs)
    calc.model.eval()
    _warmup_sevennet_model(calc.model, loader, dev, modality)

    print(
        f"[SevenNet worker {rank}] pinned to cuda:{device_id} | "
        f"cueq={bool(enable_cueq)} flash={bool(enable_flash)} oeq={bool(enable_oeq)}",
        flush=True,
    )

    # Inline force-output patcher (avoids cross-module import in subprocess).
    @_contextlib.contextmanager
    def _disable_force(model):
        _target = {
            "ForceOutput", "ForceStressOutput",
            "ForceStressOutputFromEdge", "ForceStressOutputFromEdgeParallel",
        }
        _patched = []
        for m in model.modules():
            if m.__class__.__name__ in _target and hasattr(m, "forward"):
                _orig = m.forward

                def _noop(self, data):
                    return data

                m.forward = _types.MethodType(_noop, m)
                _patched.append((m, _orig))
        try:
            yield
        finally:
            for m, _orig in _patched:
                m.forward = _orig

    frame_counts: List[int] = []
    E_chunks: List[_np.ndarray] = []
    F_chunks: List[_np.ndarray] = []
    frame_offset = 0
    progress_every = max(int(batch_size) * 50, 5000)

    with _disable_force(calc.model):
        with torch.no_grad():
            for batch in loader:
                # In sevenn>=0.12.0, eval_type_map=True handles type mapping.
                batch = batch.to(dev)
                _attach_batch_modality(batch, modality)
                out = calc.model(batch)
                H = out[KEY.NODE_FEATURE].detach().cpu().float().numpy()
                counts = torch.bincount(batch.batch).tolist()

                for fi, n_atoms in enumerate(counts):
                    frame_counts.append(n_atoms)
                    at = frames[frame_offset + fi]
                    F_frame = None
                    try:
                        F_raw = at.get_forces(apply_constraint=False)
                        if F_raw is not None and F_raw.size > 0:
                            F_frame = F_raw.astype(_np.float32)
                    except Exception:
                        pass
                    if F_frame is None:
                        for fkey in ("forces", "force", "Forces", "Force"):
                            if fkey in getattr(at, "arrays", {}):
                                F_frame = at.arrays[fkey].astype(_np.float32)
                                break
                    if F_frame is None:
                        raise RuntimeError(
                            f"[SevenNet worker {rank}] No forces in frame "
                            f"{frame_lo + frame_offset + fi}."
                        )
                    F_chunks.append(F_frame)

                E_chunks.append(H)
                frame_offset += len(counts)

                if (
                    frame_offset % progress_every < len(counts)
                    or frame_offset == n_local
                ):
                    pct = 100.0 * float(frame_offset) / float(max(n_local, 1))
                    print(
                        f"[SevenNet worker {rank}] progress: {frame_offset}/{n_local} "
                        f"frame(s) processed ({pct:5.1f}%)",
                        flush=True,
                    )

                del out, H, batch
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

    E_shard = _np.concatenate(E_chunks, axis=0).astype(_np.float32)
    F_shard = _np.concatenate(F_chunks, axis=0).astype(_np.float32)

    with h5py.File(shard_path, "w") as h5:
        h5.create_dataset("E", data=E_shard)
        h5.create_dataset("F", data=F_shard)
        h5.create_dataset("frame_counts", data=_np.array(frame_counts, dtype=_np.int64))

    print(
        f"[SevenNet worker {rank}] cuda:{device_id} | "
        f"frames {frame_lo}–{frame_hi-1} ({n_local} frames) → {shard_path}",
        flush=True,
    )


def sevennet_node_embeddings_impl(
    ext_frames,
    model_name: str = "7net-0",
    device_pref: str = "auto",
    h5_path: str = "./embeddings.h5",
    cutoff: float = 6.0,
    modality: Optional[str] = None,
    enable_cueq: bool = False,
    enable_flash: bool = False,
    enable_oeq: bool = False,
    multi_gpu: bool = False,
    gpu_ids: Optional[List[int]] = None,
    batch_size: int = 32,
) -> Tuple[List[int], str]:
    """
    Compute SevenNet node embeddings and write to an HDF5 file.

    Single-GPU: streams batches O(batch_size) peak VRAM, no intermediate files.
    Multi-GPU:  spawns one worker per GPU (torch.multiprocessing.spawn).
                Each worker loads an independent model copy (~model_size VRAM per GPU)
                and processes N/N_gpu frames. Workers write temp HDF5 shards;
                main process merges and applies global z-score normalisation.

    Args:
        ext_frames:   List of ASE Atoms objects.
        model_name:   SevenNet model identifier (e.g. "7net-0").
        device_pref:  Device preference ("auto", "cuda", "cpu", "mps"). Single-GPU only.
        h5_path:      Output HDF5 file path (created or overwritten).
        cutoff:       Neighbor cutoff radius in Angstroms.
        modality:     SevenNet modality parameter (None = default).
        enable_cueq:  Use cuEquivariance backend when supported by sevenn.
        enable_flash: Use flashTP backend when supported by sevenn.
        enable_oeq:   Use OpenEquivariance backend when supported by sevenn.
        multi_gpu:    Spawn one worker process per GPU.
        gpu_ids:      Specific GPU indices (None = all available).
        batch_size:   Number of frames per DataLoader batch (per worker in multi-GPU mode).

    Returns:
        (frame_counts, dev_str):
            - frame_counts: atom counts per frame.
            - dev_str:      device string used (primary GPU in multi-GPU mode).

    Writes h5_path with:
        - "E": float32 (N_atoms, 64) — z-score normalised per-atom embeddings.
        - "F": float32 (N_atoms, 3)  — per-atom forces (from input ASE frames).
        - "frame_counts": int64 (N_frames,) — atoms per frame.

    Embedding details:
        out[KEY.NODE_FEATURE] is the 64-dimensional latent from SevenNet's last
        interaction layer (after all E(3)-equivariant convolutions, before the
        scalar energy readout).  Force layers are patched out to avoid
        requires_grad errors during no_grad inference.
        Per-dimension z-score normalisation is applied across all atoms so that
        each of the 64 channels has zero mean and unit variance.
    """
    try:
        import torch
        import torch.multiprocessing as mp
        import h5py
        import sevenn._keys as KEY
        from sevenn.calculator import SevenNetCalculator as _SevenNetCalculator
        from torch_geometric.loader import DataLoader as _TGDataLoader
        from ase.io import write as _ase_write
    except ImportError as e:
        raise ImportError(
            "SevenNet requires torch, sevenn>=0.12.0, torch_geometric, ase, and h5py. "
            "Install with: pip install torch torch_geometric 'sevenn>=0.12.0' ase h5py"
        ) from e

    # ── Device selection ────────────────────────────────────────────────────
    if multi_gpu:
        device_str, device_ids = _pick_devices(multi_gpu=True, gpu_ids=gpu_ids)
        info(f"SevenNet inference will use {len(device_ids)} GPU device(s): {device_ids}.")
        primary_dev = torch.device(f"cuda:{device_ids[0]}" if device_ids else "cuda")
    else:
        device_str = _pick_device() if device_pref == "auto" else device_pref
        device_ids = None
        primary_dev = torch.device(device_str)
        if primary_dev.type == "cuda":
            primary_dev = _normalize_cuda_device(primary_dev)
            device_str = str(primary_dev)
        info(f"SevenNet inference device: {device_str}.")

    n_frames = len(ext_frames)
    work_dir = os.path.dirname(os.path.abspath(h5_path))
    os.makedirs(work_dir, exist_ok=True)

    # ── Multi-GPU path (spawn) ───────────────────────────────────────────────
    if multi_gpu and device_ids and len(device_ids) > 1:
        # Workers communicate via a shared extxyz file (spawn cannot pickle
        # large lists of ASE Atoms directly).
        tmp_xyz = os.path.join(work_dir, "_sevnn_tmp_frames.extxyz")
        _ase_write(tmp_xyz, list(ext_frames), format="extxyz")

        n_gpus = len(device_ids)
        shard_size = (n_frames + n_gpus - 1) // n_gpus
        frame_splits = [
            (i * shard_size, min((i + 1) * shard_size, n_frames))
            for i in range(n_gpus)
        ]
        frame_splits = [(lo, hi) for lo, hi in frame_splits if lo < hi]
        actual_n = len(frame_splits)
        used_gpu_ids = device_ids[:actual_n]
        shard_paths = [
            os.path.join(work_dir, f"_sevnn_shard_{i}.h5") for i in range(actual_n)
        ]

        worker_enable_cueq, worker_enable_flash, worker_enable_oeq = _sanitize_worker_backend_flags(
            enable_cueq,
            enable_flash,
            enable_oeq,
            multi_gpu=True,
            n_gpu_workers=actual_n,
        )

        info(
            f"Launching {actual_n} SevenNet worker process(es) across GPUs {used_gpu_ids}. "
            f"Approximate shard size: {shard_size} frame(s) per worker."
        )
        mp.spawn(
            _mp_inference_worker,
            args=(
                used_gpu_ids,
                frame_splits,
                tmp_xyz,
                shard_paths,
                model_name,
                cutoff,
                modality,
                worker_enable_cueq,
                worker_enable_flash,
                worker_enable_oeq,
                batch_size,
            ),
            nprocs=actual_n,
            join=True,
        )

        # Merge shards in frame order.
        info("Merging distributed SevenNet output shards.")
        E_parts: List[np.ndarray] = []
        F_parts: List[np.ndarray] = []
        frame_counts: List[int] = []
        for sp in shard_paths:
            with h5py.File(sp, "r") as h5:
                E_parts.append(h5["E"][:])
                F_parts.append(h5["F"][:])
                frame_counts.extend(h5["frame_counts"][:].tolist())
            try:
                os.remove(sp)
            except OSError:
                pass

        try:
            os.remove(tmp_xyz)
        except OSError:
            pass

        E_all = np.concatenate(E_parts, axis=0).astype(np.float32)
        F_all = np.concatenate(F_parts, axis=0).astype(np.float32)
        dev_str = f"cuda:{device_ids[0]}"

    # ── Single-GPU / CPU path ─────────────────────────────────────────────────
    else:
        # Build AtomGraphData list directly, bypassing SevenNetGraphDataset.
        # In sevenn>=0.12.0, SevenNetGraphDataset._save_meta() fails for unlabeled
        # data because it runs Ridge regression on NaN energy labels.
        info(f"Preparing SevenNet graphs for {n_frames} frame(s).")
        graph_list = _build_graph_list(list(ext_frames), cutoff)
        loader = _TGDataLoader(
            graph_list, batch_size=int(batch_size), shuffle=False, num_workers=0
        )

        if getattr(primary_dev, "type", None) == "cuda" and torch.cuda.is_available():
            torch.cuda.set_device(primary_dev)
            torch.empty(1, device=primary_dev)
            torch.cuda.synchronize(primary_dev)

        calc_kwargs = _build_calculator_kwargs(
            _SevenNetCalculator,
            model_name=model_name,
            device=str(primary_dev),
            modality=modality,
            enable_cueq=enable_cueq,
            enable_flash=enable_flash,
            enable_oeq=enable_oeq,
        )
        calc = _SevenNetCalculator(**calc_kwargs)
        calc.model.eval()
        _warmup_sevennet_model(calc.model, loader, primary_dev, modality)
        info(f"Running SevenNet inference on {primary_dev}.")

        frame_counts: List[int] = []
        E_chunks: List[np.ndarray] = []
        F_chunks: List[np.ndarray] = []
        frame_offset = 0

        with _disable_sevenn_force_outputs(calc.model):
            with torch.no_grad():
                for batch in loader:
                    # In sevenn>=0.12.0, AtomGraphSequential.eval_type_map=True
                    # handles atomic_numbers → species index mapping internally.
                    # Simply move the batch to device and call model directly.
                    batch = batch.to(primary_dev)
                    _attach_batch_modality(batch, modality)
                    out = calc.model(batch)
                    H = out[KEY.NODE_FEATURE].detach().cpu().float().numpy()
                    counts = torch.bincount(batch.batch).tolist()

                    for fi, n_atoms in enumerate(counts):
                        frame_counts.append(n_atoms)
                        at = ext_frames[frame_offset + fi]
                        F_frame = None
                        try:
                            F_raw = at.get_forces(apply_constraint=False)
                            if F_raw is not None and F_raw.size > 0:
                                F_frame = F_raw.astype(np.float32)
                        except Exception:
                            pass
                        if F_frame is None:
                            for fkey in ("forces", "force", "Forces", "Force"):
                                if fkey in getattr(at, "arrays", {}):
                                    F_frame = at.arrays[fkey].astype(np.float32)
                                    break
                        if F_frame is None:
                            raise RuntimeError(
                                f"No per-atom forces found in frame {frame_offset + fi}. "
                                "Expected 'forces' / 'force' in atoms.arrays or via get_forces()."
                            )
                        F_chunks.append(F_frame)

                    E_chunks.append(H)
                    frame_offset += len(counts)

                    if (
                        frame_offset % max(batch_size * 10, 100) < batch_size
                        or frame_offset == n_frames
                    ):
                        info(f"SevenNet progress: {frame_offset}/{n_frames} frame(s) processed.")

                    del out, H, batch
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()

        E_all = np.concatenate(E_chunks, axis=0).astype(np.float32)
        F_all = np.concatenate(F_chunks, axis=0).astype(np.float32)
        dev_str = device_str

    # ── Global z-score normalisation (over all atoms) ────────────────────────
    mu = E_all.mean(axis=0, keepdims=True)
    sd = E_all.std(axis=0, keepdims=True) + 1e-12
    E_norm = ((E_all - mu) / sd).astype(np.float32)

    # ── Write final HDF5 ─────────────────────────────────────────────────────
    chunk_rows = min(1024, max(1, E_norm.shape[0]))
    with h5py.File(h5_path, "w") as h5:
        h5.create_dataset(
            "E", data=E_norm, dtype="float32",
            chunks=(chunk_rows, E_norm.shape[1]), compression="lzf",
        )
        h5.create_dataset(
            "F", data=F_all, dtype="float32",
            chunks=(chunk_rows, 3), compression="lzf",
        )
        h5.create_dataset("frame_counts", data=np.array(frame_counts, dtype=np.int64))

    info(
        f"SevenNet embeddings written: {E_norm.shape[0]} atom(s) across {n_frames} frame(s) to {h5_path}"
    )
    return frame_counts, dev_str


__all__ = ["sevennet_node_embeddings_impl"]
