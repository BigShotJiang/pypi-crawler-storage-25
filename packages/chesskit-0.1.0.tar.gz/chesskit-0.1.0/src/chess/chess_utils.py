"""Helper routines specific to CHESS selection.

This module exposes codebook fitting and bag-of-embeddings histogram
construction originally defined in the monolithic script.
"""
from typing import List

import numpy as np

from .core import info, _pct_bin, fmt_count, fmt_progress

try:
    from sklearn.cluster import MiniBatchKMeans
    _HAS_SK = True
except ImportError:  # pragma: no cover
    MiniBatchKMeans = None
    _HAS_SK = False


def fit_boe_codebook(Z_atoms: np.ndarray, k: int, batch_size: int = 50000, random_state: int = 0, log_step_pct: int = 10):
    """Fit a MiniBatchKMeans codebook on atomic PCA features.

    Returns the trained MiniBatchKMeans object.
    """
    if not _HAS_SK:
        raise RuntimeError("scikit-learn required for BoE codebook")
    N = Z_atoms.shape[0]
    mb = MiniBatchKMeans(
        n_clusters=int(k),
        random_state=int(random_state),
        batch_size=int(min(batch_size, max(1024, N))),
        n_init="auto",
    )
    info("")
    info("BoE codebook fitting:")
    info(f"  - Clusters (k): {k:,}")
    info(f"  - N atoms: {N:,}")
    info(f"  - Batch size: {batch_size:,}")
    info("  - Method: MiniBatchKMeans partial_fit")
    last_bin = -1
    for i in range(0, N, batch_size):
        j = min(i + batch_size, N)
        mb.partial_fit(Z_atoms[i:j])
        pct = 100.0 * j / N
        bin_idx = _pct_bin(pct, log_step_pct)
        if bin_idx > last_bin or j == N:
            info(f"  - partial_fit progress: {fmt_progress(j, N, pct)}")
            last_bin = bin_idx
    return mb


def build_frame_boe_hist(
    Z_atoms: np.ndarray,
    frame_counts: List[int],
    kmeans,
    assign_batch: int = 200000,
    log_step_pct: int = 10,
    return_labels: bool = False,
):
    """Construct frame-level BoE histograms from atom embeddings and codebook.

    ``kmeans`` must be a fitted MiniBatchKMeans.
    ``frame_counts`` contains number of atoms per frame in the same order as
    rows of ``Z_atoms``. When ``return_labels=True``, the per-atom codeword
    labels are returned alongside the frame histogram matrix.
    """
    n_frames = len(frame_counts)
    N = Z_atoms.shape[0]
    K = int(kmeans.n_clusters)
    H = np.zeros((n_frames, K), dtype=np.float64)
    labels_all = np.empty((N,), dtype=np.int32) if return_labels else None

    info("")
    info("BoE atom assignment:")
    info(f"  - N atoms: {N:,}")
    info(f"  - Batch size: {assign_batch:,}")
    frames_idx = np.repeat(np.arange(n_frames, dtype=np.int64), frame_counts)

    last_bin = -1
    for i in range(0, N, assign_batch):
        j = min(i + assign_batch, N)
        labels = kmeans.predict(Z_atoms[i:j])
        if labels_all is not None:
            labels_all[i:j] = labels.astype(np.int32, copy=False)
        np.add.at(H, (frames_idx[i:j], labels), 1)
        pct = 100.0 * j / N
        bin_idx = _pct_bin(pct, log_step_pct)
        if bin_idx > last_bin or j == N:
            filled = int(np.count_nonzero(H.sum(axis=1)))
            info(
                f"  - assignment progress: {fmt_progress(j, N, pct)} | "
                f"frames_nonzero={fmt_count(filled, n_frames)}"
            )
            last_bin = bin_idx

    H_out = H.astype(np.float32, copy=False)
    if labels_all is not None:
        return H_out, labels_all
    return H_out
