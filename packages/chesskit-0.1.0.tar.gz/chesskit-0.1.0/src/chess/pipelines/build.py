"""Build pipeline: compute and cache embeddings from input trajectory."""

from typing import Optional, List
import os
import json
import time

import numpy as np
import h5py

from ..config import load_config, validate_gpu_config
from ..core import info, ensure_dir, print_runtime_resources, format_elapsed_time
from ..featurizers import FeaturizerRegistry

# We don't attempt to import ASE here; build pipeline will raise if needed.


def _json_dict_to_atoms(d: dict):
    """Convert a plain dict (from JSON/JSONL) to an ASE Atoms object."""
    from ase import Atoms

    # Determine chemical species
    if "numbers" in d:
        species = {"numbers": d["numbers"]}
    elif "atomic_numbers" in d:
        species = {"numbers": d["atomic_numbers"]}
    elif "symbols" in d:
        species = {"symbols": d["symbols"]}
    else:
        raise ValueError(
            "JSON structure entry must contain 'numbers', 'atomic_numbers', or 'symbols'"
        )

    positions = d.get("positions") or d.get("pos")
    if positions is None:
        raise ValueError("JSON structure entry must contain 'positions'")

    cell = d.get("cell", None)
    pbc = d.get("pbc", False)

    atoms = Atoms(
        **species,
        positions=positions,
        cell=cell if cell is not None else [[0, 0, 0]] * 3,
        pbc=pbc,
    )

    # Attach energy / free_energy to atoms.info
    for key in ("energy", "free_energy"):
        if key in d:
            atoms.info[key] = float(d[key])

    # Attach forces to atoms.arrays
    if "forces" in d:
        atoms.arrays["forces"] = np.array(d["forces"], dtype=np.float32)

    # Attach stress to atoms.info
    if "stress" in d:
        atoms.info["stress"] = np.array(d["stress"], dtype=np.float64)

    return atoms


def _read_frames(input_path: str, ase_read) -> List:
    """Read structure frames from extxyz, json, or jsonl files."""
    ext = os.path.splitext(input_path)[1].lower()

    if ext == ".jsonl":
        frames: List = []
        with open(input_path, "r", encoding="utf-8") as fh:
            for lineno, line in enumerate(fh, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"Invalid JSON on line {lineno} of {input_path}: {exc}"
                    ) from exc
                frames.append(_json_dict_to_atoms(d))
        return frames

    if ext == ".json":
        # First try ASE's own JSON format, then fall back to a list-of-dicts
        try:
            return list(ase_read(input_path, index=":"))
        except Exception:
            with open(input_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                data = [data]
            return [_json_dict_to_atoms(d) for d in data]

    # Default: delegate to ASE (handles extxyz, xyz, cif, vasp, etc.)
    return list(ase_read(input_path, index=":"))


def _extract_energy_per_atom(frames: List) -> np.ndarray:
    """Extract total energy per atom for each frame when available.

    Missing energies are stored as ``nan`` so older or partially labelled
    datasets can still be processed without failing the build.
    """
    out = np.full((len(frames),), np.nan, dtype=np.float64)
    for i, atoms in enumerate(frames):
        n_atoms = max(1, len(atoms))
        energy = None
        for key in ("energy", "free_energy"):
            if key in getattr(atoms, "info", {}):
                try:
                    energy = float(atoms.info[key])
                    break
                except Exception:
                    energy = None
        if energy is None:
            try:
                energy = float(atoms.get_potential_energy())
            except Exception:
                energy = None
        if energy is not None and np.isfinite(energy):
            out[i] = energy / float(n_atoms)
    return out


def _to_json_compatible(value):
    """Convert NumPy-heavy objects into JSON-serializable Python objects."""
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _to_json_compatible(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_json_compatible(v) for v in value]
    return value


def build(cfg: dict) -> dict:
    """Run the build stage based on configuration dictionary.

    Returns a dictionary containing keys such as 'cache_path' and 'meta'.
    """
    t0 = time.perf_counter()

    # Validate GPU configuration
    validate_gpu_config(cfg)
    
    # minimal validation
    paths = cfg.get("paths", {})
    input_path = paths.get("input")
    if input_path is None:
        raise ValueError("paths.input is required for build stage")

    # Instantiate featurizer from canonical featurizer section.
    feat_cfg = cfg.get("featurizer", {})
    feat_name = feat_cfg.get("name", "sevennet")
    feat_init = feat_cfg.get("config", {})

    featurizer = FeaturizerRegistry.create(feat_name, **feat_init)

    info("Build stage started")
    info(f"Input file: {input_path}")
    info(f"Featurizer: {featurizer.name}")
    print_runtime_resources("build")

    # read frames from ASE if available
    try:
        from ase.io import read as ase_read
    except ImportError as exc:
        raise RuntimeError("ASE is required for build pipeline") from exc

    frames = _read_frames(input_path, ase_read)

    cache_path = paths.get("cache")
    if cache_path is None:
        cache_path = os.path.abspath("embeddings.h5")
    # Normalise to .h5 extension
    if not cache_path.endswith(".h5"):
        cache_path = os.path.splitext(cache_path)[0] + ".h5"
    ensure_dir(os.path.dirname(os.path.abspath(cache_path)))

    frame_counts, metadata = featurizer.featurize(frames, h5_path=cache_path)
    energy_per_atom = _extract_energy_per_atom(frames)

    embedding_dim = metadata.get("embedding_dim") if isinstance(metadata, dict) else None
    if isinstance(embedding_dim, int) and embedding_dim > 0:
        info(f"Embedding dimension resolved: {embedding_dim}")
    elif hasattr(featurizer, "embedding_dim") and int(featurizer.embedding_dim) > 0:
        info(f"Embedding dimension resolved: {int(featurizer.embedding_dim)}")

    # Append metadata and per-frame total energy per atom to the HDF5 file.
    with h5py.File(cache_path, "a") as h5:
        if "energy_per_atom" in h5:
            del h5["energy_per_atom"]
        h5.create_dataset("energy_per_atom", data=energy_per_atom)
        if isinstance(metadata, dict):
            metadata = dict(metadata)
            metadata["energy_per_atom_valid"] = int(np.isfinite(energy_per_atom).sum())
        h5.attrs["meta"] = json.dumps(metadata)

    n_energy_valid = int(np.isfinite(energy_per_atom).sum())
    info(
        f"Energy per atom cached for {int(np.isfinite(energy_per_atom).sum())}/"
        f"{len(energy_per_atom)} frame(s)."
    )
    info(f"Cache written: {cache_path}")
    info("Next step: run sample mode with this cache")
    elapsed_seconds = float(time.perf_counter() - t0)

    result = {
        "stage": "build",
        "cache_path": cache_path,
        "meta": metadata,
        "input_path": input_path,
        "n_frames": len(frames),
        "n_energy_per_atom_valid": n_energy_valid,
        "elapsed_seconds": elapsed_seconds,
    }

    misc_cfg = cfg.get("misc", {})
    result_json_name = misc_cfg.get("result_json", "result.json")
    if result_json_name is not None:
        result_json_name = str(result_json_name).strip()
        if result_json_name:
            report_dir = os.path.abspath(paths.get("report_dir", "./report"))
            ensure_dir(report_dir)
            result_json_path = os.path.join(report_dir, result_json_name)
            with open(result_json_path, "w", encoding="utf-8") as f:
                json.dump(_to_json_compatible(result), f, indent=2, ensure_ascii=False)
            info(f"Build result JSON saved: {result_json_path}")
            result["result_json_path"] = result_json_path

    info(f"Total elapsed time (build): {format_elapsed_time(elapsed_seconds)}")
    return result
