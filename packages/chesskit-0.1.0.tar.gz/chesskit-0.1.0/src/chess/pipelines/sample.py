"""Sample pipeline: load cache and run CHESS selection & reporting."""

from typing import List
import os
import json
import time

# Reuse the multi-format reader from the build pipeline.
from .build import _read_frames

import numpy as np
import h5py

from ..config import load_config, validate_gpu_config
from ..core import (
    info,
    ensure_dir,
    abs_path,
    base_fig,
    _auto_linthresh,
    fmt_float,
    print_runtime_resources,
    format_elapsed_time,
)
from ..transforms import kaiser_pca
from ..metrics import (
    isotropy_metrics_chess,
    isotropy_metrics_random_kfold,
)
from ..selection import (
    chess_kcenter_fisherrao,
)
from ..plotting import (
    plot_radius_history,
    base_plot_scatter,
)
from ..chess_utils import fit_boe_codebook, build_frame_boe_hist

# this function implements much of the "sample" logic from earlier script,
# but it's kept concise for clarity and reuse in CLI/tests.

_FR_EPS = 1e-12


def _to_json_compatible(value):
    """Convert NumPy-heavy objects into JSON-serializable Python objects."""
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _to_json_compatible(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_json_compatible(v) for v in value]
    return value


def sample(cfg: dict) -> dict:
    """Run CHESS sampling based on configuration dictionary.

    Returns information about selected frames and coverage.
    """
    t0 = time.perf_counter()

    # Validate GPU configuration
    validate_gpu_config(cfg)

    # Extract multi-GPU settings from canonical featurizer.config path.
    _feat_cfg = cfg.get("featurizer", {}).get("config", {})
    gpu_cfg = _feat_cfg
    multi_gpu = bool(gpu_cfg.get("multi_gpu", False))
    gpu_ids = gpu_cfg.get("gpu_ids", None)

    paths = cfg.get("paths", {})
    cache_path = paths.get("cache")
    if cache_path is None:
        raise ValueError("paths.cache is required for sample stage")
    cache_path = abs_path(cache_path)
    if not os.path.exists(cache_path):
        raise FileNotFoundError(cache_path)

    info("Sample stage started")
    info(f"Loading cache: {cache_path}")
    info("Sample mode uses the existing cache and does not run a featurizer.")
    print_runtime_resources("sample")

    chess_cfg = cfg.get("chess")
    if chess_cfg is None:
        raise ValueError(
            "'chess' section is required in config for sample stage. "
            "Generate a template with: python -m chesskit --preset chess-sample > config.yaml"
        )

    misc_cfg = cfg.get("misc", {})
    iso_cfg = misc_cfg.get("isotropy", {})
    iso_enabled = bool(iso_cfg.get("enabled", False))
    seed = int(chess_cfg.get("seed", misc_cfg.get("seed", 0)))

    metric = str(chess_cfg.get("metric", "fisherrao")).strip().lower()
    if metric in {"fr", "fisherrao", "fisher-rao"}:
        metric = "fisherrao"
    else:
        raise ValueError(
            f"Unknown chess.metric={metric!r}. Supported currently: 'fisherrao'."
        )

    k_boe = chess_cfg.get("k_boe", 32)
    radius_stop_cfg = float(chess_cfg.get("radius_stop", 0.0))
    with h5py.File(cache_path, "r") as h5:
        E = h5["E"][:]
        F = h5["F"][:]
        frame_counts = h5["frame_counts"][:].tolist()
        energy_per_atom = h5["energy_per_atom"][:] if "energy_per_atom" in h5 else None
        try:
            cache_meta = json.loads(h5.attrs.get("meta", "{}"))
        except Exception:
            cache_meta = {}

    if cache_meta.get("source"):
        info(f"Cache source: {cache_meta.get('source')}")

    report_dir = abs_path(paths.get("report_dir", "./report"))
    ensure_dir(report_dir)

    k_select_raw = chess_cfg.get("k_select", "all")

    # Perform PCA on embeddings
    Z_atoms, pca_scaler, pca_obj, _ = kaiser_pca(E)
    del E  # free raw embedding memory

    # Fit BoE codebook
    k_boe = int(k_boe)
    kmeans = fit_boe_codebook(
        Z_atoms,
        k_boe,
        batch_size=int(chess_cfg.get("boe_batch_size", 50000)),
        random_state=seed,
    )

    # Build frame-level BoE histograms
    H_boe = build_frame_boe_hist(
        Z_atoms,
        frame_counts,
        kmeans,
        assign_batch=int(chess_cfg.get("assign_batch", 200000)),
        return_labels=False,
    )

    n_frames = H_boe.shape[0]
    k_select_is_all = isinstance(k_select_raw, str) and k_select_raw.strip().lower() == "all"
    if k_select_is_all:
        K_select = n_frames
    else:
        K_select = int(k_select_raw)

    if K_select <= 0:
        raise ValueError(f"chess.k_select must be positive, got {k_select_raw!r}")

    # Run Fisher-Rao selection
    fr_eps = _FR_EPS
    if k_select_is_all:
        radius_stop = radius_stop_cfg
    else:
        # Numeric k_select takes priority by design.
        radius_stop = 0.0

    selected, radius_hist = chess_kcenter_fisherrao(
        H_boe,
        K_select,
        block_size=int(chess_cfg.get("block_size", 200000)),
        fr_eps=fr_eps,
        seed=seed,
        radius_stop=radius_stop,
        multi_gpu=multi_gpu,
        gpu_ids=gpu_ids,
    )

    # --- Isotropy defect analysis (CHESS vs random) ---
    if iso_enabled and len(selected) >= 3:
        iso_n_neighbors = int(iso_cfg.get("n_neighbors", 16))
        iso_n_folds = int(iso_cfg.get("n_folds", 5))
        iso_chunk_size = int(iso_cfg.get("chunk_size", 4096))
        iso_compile_torch = bool(iso_cfg.get("compile_torch", True))
        iso_seed = int(iso_cfg.get("seed", seed))
        iso_max_samples_raw = iso_cfg.get("max_samples", 2000)
        if isinstance(iso_max_samples_raw, str) and iso_max_samples_raw.strip().lower() in {"full", "all"}:
            iso_max_samples = iso_max_samples_raw.strip().lower()
            iso_max_samples_label = "full"
        else:
            iso_max_samples = int(iso_max_samples_raw)
            iso_max_samples_label = f"{iso_max_samples:,}"

        info("")
        info("Isotropy analysis:")
        info(f"  - Reference neighbor count: {iso_n_neighbors}")
        info(f"  - Torch compile: {iso_compile_torch}")
        info(f"  - Random baseline folds: {iso_n_folds}")
        info(f"  - Torch chunk size: {iso_chunk_size}")
        info(f"  - Max isotropy samples: {iso_max_samples_label}")

        iso_chess = isotropy_metrics_chess(
            F,
            frame_counts,
            H_boe,
            selected,
            fr_eps=fr_eps,
            n_neighbors=iso_n_neighbors,
            max_samples=iso_max_samples,
            multi_gpu=multi_gpu,
            gpu_ids=gpu_ids,
            knn_mode="approx",
            chunk_size=iso_chunk_size,
            compile_torch=iso_compile_torch,
        )

        iso_random = isotropy_metrics_random_kfold(
            F,
            frame_counts,
            H_boe,
            k_select=len(selected),
            n_folds=iso_n_folds,
            fr_eps=fr_eps,
            seed=iso_seed,
            n_neighbors=iso_n_neighbors,
            max_samples=iso_max_samples,
            multi_gpu=multi_gpu,
            gpu_ids=gpu_ids,
            knn_mode="approx",
            chunk_size=iso_chunk_size,
            compile_torch=iso_compile_torch,
        )

        geom_chess_erank = iso_chess["geometry_erank_mean"]
        geom_rand_erank_mean = iso_random["geometry_erank_mean"]
        geom_rand_erank_std = iso_random["geometry_erank_std"]
        geom_rand_erank_folds = iso_random["geometry_erank_folds"]

        def _fmt_iso_scalar(v) -> str:
            return fmt_float(v, decimals=3, width=10)

        def _fmt_iso_mean_std(mean_v, std_v) -> str:
            return f"{_fmt_iso_scalar(mean_v)} ± {_fmt_iso_scalar(std_v)}"

        def _fmt_iso_folds(values) -> str:
            arr = np.asarray(values, dtype=np.float64).reshape(-1)
            return "[" + ", ".join(fmt_float(float(v), decimals=3, width=8) for v in arr) + "]"

        label_w = 30

        info(f"  - {'CHESS effective rank':<{label_w}} : {_fmt_iso_scalar(geom_chess_erank)}")
        info(f"  - {'Random effective rank':<{label_w}} : {_fmt_iso_mean_std(geom_rand_erank_mean, geom_rand_erank_std)}")
        info("")

    # Selected frame indices are included in result.json (no separate file needed)

    # --- Optionally write selected + remaining structures as extxyz ---
    input_path = paths.get("input")
    output_path = paths.get("output")
    if input_path:
        input_path = abs_path(input_path)

        # Derive output paths
        if output_path:
            output_path = abs_path(output_path)
            base, ext = os.path.splitext(output_path)
            if not ext:
                ext = ".extxyz"
            sel_out = base + ext
            rem_out = base + "_remaining" + ext
        else:
            sel_out = os.path.join(report_dir, "selected.extxyz")
            rem_out = os.path.join(report_dir, "remaining.extxyz")

        ensure_dir(os.path.dirname(sel_out))
        ensure_dir(os.path.dirname(rem_out))

        try:
            from ase.io import read as ase_read, iread as ase_iread, write as ase_write
        except ImportError as exc:
            raise RuntimeError("ASE is required to write selected structures") from exc

        io_chunk_size = int(misc_cfg.get("io_chunk_size", 4096))
        if io_chunk_size <= 0:
            io_chunk_size = 4096

        info("")
        info("Structure export:")
        info(f"  - Input: {input_path}")
        info(f"  - Selected output: {sel_out}")
        info(f"  - Remaining output: {rem_out}")
        info(f"  - I/O chunk size: {io_chunk_size}")

        def _flush_chunk(file_obj, chunk: List) -> int:
            if not chunk:
                return 0
            n_chunk = len(chunk)
            # Remove "forces" from atoms.arrays when a calculator also stores forces,
            # to suppress ASE's write_xyz() overwrite warning. The calculator result
            # takes precedence and the data is identical.
            for atoms in chunk:
                if atoms.calc is not None and "forces" in atoms.arrays:
                    del atoms.arrays["forces"]
            ase_write(file_obj, chunk, format="extxyz")
            chunk.clear()
            return n_chunk

        sel_set = set(int(i) for i in selected)
        sel_count = 0
        rem_count = 0

        use_streaming = os.path.splitext(input_path)[1].lower() not in {".json", ".jsonl"}

        if use_streaming:
            sel_chunk: List = []
            rem_chunk: List = []
            # Keep file handles open and stream-write chunks.
            # This is more robust than repeated filename append calls on some network/FUSE mounts.
            with open(sel_out, "w", encoding="utf-8") as sel_fh, open(
                rem_out, "w", encoding="utf-8"
            ) as rem_fh:
                for i, atoms in enumerate(ase_iread(input_path, index=":")):
                    if i in sel_set:
                        sel_chunk.append(atoms)
                        sel_count += 1
                    else:
                        rem_chunk.append(atoms)
                        rem_count += 1

                    if len(sel_chunk) >= io_chunk_size:
                        _flush_chunk(sel_fh, sel_chunk)
                    if len(rem_chunk) >= io_chunk_size:
                        _flush_chunk(rem_fh, rem_chunk)

                _flush_chunk(sel_fh, sel_chunk)
                _flush_chunk(rem_fh, rem_chunk)
                sel_fh.flush()
                rem_fh.flush()

            # Defensive validation so logs cannot claim export success while files are missing.
            if sel_count > 0 and (not os.path.exists(sel_out) or os.path.getsize(sel_out) == 0):
                raise RuntimeError(
                    f"Selected export appears empty or missing despite {sel_count} selected frame(s): {sel_out}"
                )
            if rem_count > 0 and (not os.path.exists(rem_out) or os.path.getsize(rem_out) == 0):
                raise RuntimeError(
                    f"Remaining export appears empty or missing despite {rem_count} remaining frame(s): {rem_out}"
                )
        else:
            info("Input format requires fallback in-memory export path (.json/.jsonl).")
            all_frames = _read_frames(input_path, ase_read)
            sel_frames = [all_frames[i] for i in range(len(all_frames)) if i in sel_set]
            rem_frames = [all_frames[i] for i in range(len(all_frames)) if i not in sel_set]
            sel_count = len(sel_frames)
            rem_count = len(rem_frames)
            ase_write(sel_out, sel_frames, format="extxyz")
            ase_write(rem_out, rem_frames, format="extxyz")

        info(f"  - Selected : {sel_count:,} frame(s) -> {sel_out}")
        info(f"  - Remaining: {rem_count:,} frame(s) -> {rem_out}")
        info("")
    elif output_path:
        info(
            "Warning: paths.output is set, but paths.input is missing. "
            "cannot write selected structures without the original file."
        )
    else:
        info(
            "paths.input is not set. Only selected_indices.txt will be written. "
            "Set paths.input to also save selected.extxyz and remaining.extxyz."
        )

    plot_graphs = bool(misc_cfg.get("plot_graphs", True))
    if plot_graphs:
        plot_dpi = int(misc_cfg.get("plot_dpi", 300))

        # 1) Radius trajectory (k-center)
        if len(radius_hist) > 0:
            plot_radius_history(radius_hist, report_dir)

        # 2) Atomic-environment PCA scatter with selected/remaining overlays.
        try:
            if Z_atoms.shape[1] >= 2:
                Z_plot = Z_atoms[:, :2]
            elif Z_atoms.shape[1] == 1:
                Z_plot = np.column_stack(
                    [Z_atoms[:, 0], np.zeros((Z_atoms.shape[0],), dtype=Z_atoms.dtype)]
                )
            else:
                Z_plot = None

            if Z_plot is not None:
                frame_id_per_atom = np.repeat(
                    np.arange(len(frame_counts), dtype=np.int64),
                    np.asarray(frame_counts, dtype=np.int64),
                )
                selected_frame_set = set(
                    int(i) for i in selected if 0 <= int(i) < len(frame_counts)
                )
                selected_atom_mask = np.fromiter(
                    (frame_id in selected_frame_set for frame_id in frame_id_per_atom),
                    dtype=bool,
                    count=frame_id_per_atom.shape[0],
                )
                remaining_atom_mask = ~selected_atom_mask

                sel_markers = Z_plot[selected_atom_mask]
                rem_markers = Z_plot[remaining_atom_mask]

                base_plot_scatter(
                    Z_plot,
                    markers_xy=sel_markers,
                    outfile=os.path.join(report_dir, "pca_selected_atoms.png"),
                    dpi=plot_dpi,
                )

                base_plot_scatter(
                    Z_plot,
                    markers_xy=rem_markers,
                    outfile=os.path.join(report_dir, "pca_remaining_atoms.png"),
                    dpi=plot_dpi,
                )
        except Exception as exc:
            info(f"Warning: PCA scatter plot generation failed: {exc}")



    del Z_atoms  # free PCA embeddings after optional plotting

    result = {
        "selected_frames": selected,
        "radius_history": radius_hist,
        "report_dir": report_dir,
    }
    if iso_enabled and len(selected) >= 3:
        result["isotropy"] = {
            "geometry": {
                "chess_effective_rank": geom_chess_erank,
                "random_effective_rank_mean": geom_rand_erank_mean,
                "random_effective_rank_std": geom_rand_erank_std,
                "random_effective_rank_folds": geom_rand_erank_folds,
            },
            "n_used": iso_chess["n_used"],
        }
    if input_path:
        result["selected_path"] = sel_out
        result["remaining_path"] = rem_out

    result["stage"] = "sample"
    result["cache_path"] = cache_path
    result["n_selected"] = len(selected)
    result["elapsed_seconds"] = float(time.perf_counter() - t0)

    result_json_name = misc_cfg.get("result_json", "result.json")
    if result_json_name is not None:
        result_json_name = str(result_json_name).strip()
        if result_json_name:
            result_json_path = os.path.join(report_dir, result_json_name)
            with open(result_json_path, "w", encoding="utf-8") as f:
                json.dump(_to_json_compatible(result), f, indent=2, ensure_ascii=False)
            result["result_json_path"] = result_json_path

    info("")
    info("Output files:")
    if result_json_name and str(result_json_name).strip():
        info(f"  - result JSON     -> {os.path.join(report_dir, result_json_name)}")
    info(f"  - elapsed time     : {format_elapsed_time(result['elapsed_seconds'])}")
    return result
