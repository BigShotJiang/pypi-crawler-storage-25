"""
Configuration management: YAML loading, presets, system info.
"""

import json
import os
import platform
from datetime import datetime
from typing import Dict, Any, Optional

from . import __version__
from .core import info, abs_path, ensure_dir


def _get_system_summary(featurizer_name: str, input_path: Optional[str], cfg: Dict[str, Any], report_dir: str) -> Dict[str, Any]:
    """
    Collect system information for run header.
    
    Returns:
        Dictionary with system, torch, memory, CPU info
    """
    now = datetime.now()
    sysinfo = {}
    
    try:
        sysinfo["datetime"] = now.strftime("%Y-%m-%d %H:%M:%S")
        sysinfo["script_version"] = __version__
        sysinfo["python_version"] = platform.python_version() if platform else "unknown"
        sysinfo["os"] = {
            "system": platform.system() if platform else "unknown",
            "release": platform.release() if platform else "unknown",
            "version": platform.version() if platform else "unknown",
            "machine": platform.machine() if platform else "unknown",
            "processor": platform.processor() if platform else "unknown",
        }
        sysinfo["cpu"] = {
            "count_logical": os.cpu_count(),
        }
        
        try:
            import psutil
            vm = psutil.virtual_memory()
            sysinfo["memory"] = {
                "total_GB": round(vm.total / (1024**3), 2),
                "available_GB": round(vm.available / (1024**3), 2),
            }
        except ImportError:
            sysinfo["memory"] = {"psutil": "not available"}
        
        try:
            import torch
            cuda_ok = torch.cuda.is_available()
            mps_ok = hasattr(torch.backends, "mps") and torch.backends.mps.is_available()
            gpus = []
            if cuda_ok:
                try:
                    for i in range(torch.cuda.device_count()):
                        gpus.append(torch.cuda.get_device_name(i))
                except Exception:
                    gpus.append("CUDA device(s) detected")
            sysinfo["torch"] = {
                "version": torch.__version__,
                "cuda_available": cuda_ok,
                "mps_available": mps_ok,
                "gpus": gpus,
            }
        except ImportError:
            sysinfo["torch"] = {"available": False}
        
        sysinfo["featurizer"] = featurizer_name
        sysinfo["inputs"] = {
            "input_path": input_path,
            "report_dir": report_dir,
        }
        sysinfo["config_keys"] = list(cfg.keys())
    except Exception as e:
        sysinfo["error"] = f"{e}"
    
    return sysinfo


def _write_header_files(summary: Dict[str, Any], report_dir: str) -> None:
    """Write system summary to header.txt and header.json."""
    ensure_dir(report_dir)
    
    # Text format
    lines = []
    lines.append("# Run Header")
    lines.append(f"datetime       : {summary.get('datetime')}")
    lines.append(f"script_version : {summary.get('script_version')}")
    lines.append(f"python_version : {summary.get('python_version')}")
    osinfo = summary.get("os", {})
    lines.append(f"os             : {osinfo.get('system')} {osinfo.get('release')}")
    lines.append(f"machine/cpu    : {osinfo.get('machine')} | {osinfo.get('processor')}")
    cpuinfo = summary.get("cpu", {})
    lines.append(f"cpu_logical    : {cpuinfo.get('count_logical')}")
    mem = summary.get("memory", {})
    if "total_GB" in mem:
        lines.append(f"memory_totalGB : {mem.get('total_GB')} (avail {mem.get('available_GB')})")
    else:
        lines.append("memory         : psutil not available")
    torchinfo = summary.get("torch", {})
    lines.append(f"torch          : v{torchinfo.get('version','n/a')}")
    lines.append(f"featurizer     : {summary.get('featurizer')}")
    
    text_path = os.path.join(report_dir, "header.txt")
    with open(text_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    
    # JSON format
    json_path = os.path.join(report_dir, "header.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    
    info(f"[header] wrote {text_path}")
    info(f"[header] wrote {json_path}")


def _write_preset(kind: str, out_path: str) -> None:
    """
    Write preset YAML configuration.
    
    Args:
        kind: Preset name (sevennet-build, wacsf-build, chess-sample)
        out_path: Output file path
    """
    key = str(kind).strip().lower()
    if key not in {"sevennet-build", "wacsf-build", "chess-sample"}:
        raise ValueError(
            f"Unknown preset kind: {kind!r}. "
            "Valid: 'sevennet-build', 'wacsf-build', 'chess-sample'"
        )

    templates = {
            "sevennet-build": """# CHESS preset: build embeddings with SevenNet
# This file is for stage-1 only (mode=build).
# It reads extxyz and writes HDF5 cache (E/F/frame_counts).

mode: build

paths:
    input: data/train.extxyz       # input trajectory (ASE-readable, extxyz recommended)
    cache: cache/all_embeddings.h5 # output embedding cache consumed by sample mode
    report_dir: report             # optional output directory for logs/plots/json

featurizer:
    name: sevennet                 # sevennet or wacsf
    config:
        model: "7net-0"             # SevenNet model checkpoint name
        device: auto                 # auto | cpu | cuda | cuda:0 | mps
        modality: null               # optional SevenNet modality
        enable_cueq: false           # use cuEquivariance backend when supported
        enable_flash: false          # use flashTP backend when supported
        enable_oeq: false            # use OpenEquivariance backend when supported
        cutoff: 6.0                 # graph cutoff in angstrom
        batch_size: 32               # frames per DataLoader batch (or auto)
        multi_gpu: false             # enable DataParallel for embedding inference
        gpu_ids: auto                # GPU IDs when multi_gpu=true, auto=all

misc:
    seed: 42
    plot_graphs: true
    result_json: result.json       # saved under paths.report_dir; set null to disable
""",
        "wacsf-build": """# CHESS preset: build embeddings with wACSF
# This file is for stage-1 only (mode=build).
# It reads extxyz and writes HDF5 cache (E/F/frame_counts).

mode: build

paths:
    input: data/train.extxyz         # input trajectory (ASE-readable, extxyz recommended)
    cache: cache/wacsf_embeddings.h5 # output embedding cache consumed by sample mode
    report_dir: report               # optional output directory for logs/plots/json

featurizer:
    name: wacsf                      # sevennet or wacsf
    config:
        rcut: 6.0                      # neighbor cutoff in angstrom
        # G2 radial terms [eta, Rs]; more terms -> richer descriptor, larger dim
        g2_params:
            - [0.01, 0.0]
            - [0.10, 0.0]
            - [0.50, 0.0]
            - [1.00, 0.0]
            - [2.50, 0.0]
            - [5.00, 0.0]
        # G4 angular terms [eta, zeta, lambda]
        g4_params:
            - [0.001, 1.0, 1.0]
            - [0.001, 1.0, -1.0]
            - [0.001, 2.0, 1.0]
            - [0.001, 2.0, -1.0]
            - [0.010, 1.0, 1.0]
            - [0.010, 1.0, -1.0]
        device: auto                   # auto | cpu | cuda | cuda:0 | mps
        multi_gpu: false               # enable frame-sharded multi-GPU on CUDA
        gpu_ids: auto                  # GPU IDs when multi_gpu=true, auto=all
        batch_size: 64                 # frames per GPU batch

misc:
    seed: 42
    plot_graphs: true
    result_json: result.json         # saved under paths.report_dir; set null to disable
""",
        "chess-sample": """# CHESS preset: sample frames from existing cache
# This file is for stage-2 only (mode=sample).
# It does NOT run featurizer. It only reads paths.cache.
# IMPORTANT: paths.cache below must match the cache written by your build config.

mode: sample

paths:
    cache: cache/embeddings.h5       # HDF5 cache produced by build mode
    report_dir: report               # output directory for reports/plots/json
    # input: data/train.extxyz       # optional source trajectory to export selected/remaining
    # output: selected.extxyz        # optional base output path for selected structures

chess:
    metric: fisherrao                # current sample mode metric
    k_boe: 64                        # number of BoE codebook centroids
    block_size: 200000               # block size for distance calculations
    radius_stop: 0.05                # finite stop radius; ignored when k_select is a number
    # k_select: all                  # optional; default is "all" when omitted
    boe_batch_size: 50000            # MiniBatchKMeans fit batch
    assign_batch: 200000             # atom assignment batch size
    seed: 42

misc:
    seed: 42
    plot_graphs: true
    result_json: result.json         # saved under paths.report_dir; set null to disable

    isotropy:
        enabled: true                  # enable isotropy defect computation
        n_neighbors: 16                # FR k-NN neighborhood size
        n_folds: 5                     # random baseline folds
        max_samples: 2000              # int or "full"
        seed: 42                       # random baseline seed
""",
    }

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(templates[key].rstrip() + "\n")
    info(f"[preset] wrote {out_path}")


def load_config(config_path: str) -> Dict[str, Any]:
    """
    Load YAML configuration file.
    
    Args:
        config_path: Path to YAML config file
        
    Returns:
        Configuration dictionary
    """
    try:
        import yaml
    except ImportError:
        raise ImportError("PyYAML required: pip install pyyaml")
    
    config_path = abs_path(config_path)
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    
    if cfg is None:
        raise ValueError(f"Empty or invalid YAML: {config_path}")

    validate_mode_config(cfg)

    info(f"Config loaded: {config_path}")
    return cfg


def validate_mode_config(cfg: Dict[str, Any]) -> None:
    """Validate required fields by run mode and provide actionable messages."""
    mode = str(cfg.get("mode", "build")).strip().lower()
    paths = cfg.get("paths", {})

    if not isinstance(paths, dict):
        raise ValueError("'paths' section must be a mapping/dictionary")

    if mode == "build":
        input_path = paths.get("input")
        if not input_path:
            raise ValueError(
                "mode=build requires paths.input (structure file path). "
                "Supported formats: extxyz, json, jsonl, and any ASE-readable format. "
                "Example: paths.input: data/train.extxyz"
            )

        feat_cfg = cfg.get("featurizer", {})
        if not feat_cfg:
            raise ValueError(
                "mode=build requires featurizer section with featurizer.name. "
                "Use one of: sevennet, wacsf"
            )

        feat_name = str(feat_cfg.get("name", "")).strip().lower()
        if not feat_name:
            raise ValueError(
                "mode=build requires featurizer.name. "
                "Use one of: sevennet, wacsf"
            )

    elif mode == "sample":
        cache_path = paths.get("cache")
        if not cache_path:
            raise ValueError(
                "mode=sample requires paths.cache (HDF5 cache from build stage). "
                "Example: paths.cache: cache/all_embeddings.h5"
            )

        if "chess" not in cfg or not isinstance(cfg.get("chess"), dict):
            raise ValueError(
                "mode=sample requires 'chess' section. "
                "Generate a template with: python -m chesskit --preset chess-sample > config_sample.yaml"
            )

        if "featurizer" in cfg:
            info(
                "Note: mode=sample ignores featurizer settings; "
                "sampling uses only paths.cache produced by build stage"
            )
    else:
        raise ValueError(
            f"Invalid mode={mode!r}. Valid modes are 'build' and 'sample'."
        )


def validate_gpu_config(cfg: Dict[str, Any]) -> None:
    """
    Validate GPU-related configuration settings.
    
    Checks multi_gpu and gpu_ids fields for correctness and availability.
    Logs warnings if requested GPUs are not available.
    
    Args:
        cfg: Configuration dictionary (typically from load_config)
        
    Raises:
        ValueError: If gpu_ids contains invalid values
        
    Example:
        >>> cfg = load_config("config.yaml")
        >>> validate_gpu_config(cfg)
    """
    from .core import get_available_gpus
    
    # Canonical GPU config location.
    gpu_cfg = None
    feat_cfg = cfg.get("featurizer", {}).get("config", {})
    if feat_cfg.get("multi_gpu"):
        gpu_cfg = feat_cfg

    if gpu_cfg is None:
        # No GPU config specified, nothing to validate
        return
    
    multi_gpu = gpu_cfg.get("multi_gpu", False)
    gpu_ids = gpu_cfg.get("gpu_ids", None)
    
    if not multi_gpu:
        # Single GPU mode, no validation needed
        return
    
    # Multi-GPU mode requested
    available = get_available_gpus()
    
    if not available:
        info(
            "[config] Warning: multi_gpu=true but no GPUs available. "
            "Will fall back to CPU."
        )
        return
    
    if gpu_ids is None:
        # Will use all available GPUs
        info(f"[config] Multi-GPU mode: will use all {len(available)} GPUs {available}")
        return
    
    # Validate specific gpu_ids
    if not isinstance(gpu_ids, list):
        raise ValueError(
            f"gpu_ids must be a list of integers, got {type(gpu_ids).__name__}"
        )
    
    invalid = [g for g in gpu_ids if g not in available]
    if invalid:
        raise ValueError(
            f"Requested GPU IDs {invalid} not in available GPUs {available}"
        )
    
    info(f"[config] Multi-GPU mode: using {len(gpu_ids)} GPUs {gpu_ids}")


def write_preset(kind: str) -> None:
    """
    Write preset YAML to stdout.
    
    Args:
          kind: "sevennet-build", "wacsf-build", or "chess-sample"
    """
    try:
        import yaml
        import tempfile
        import sys
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            temp_path = f.name
        
        _write_preset(kind, temp_path)
        
        with open(temp_path, 'r') as f:
            sys.stdout.write(f.read())
        
        os.unlink(temp_path)
    except Exception as e:
        raise RuntimeError(f"Failed to write preset: {e}")


__all__ = [
    "load_config",
    "validate_mode_config",
    "validate_gpu_config",
    "write_preset",
    "_get_system_summary",
    "_write_header_files",
]
