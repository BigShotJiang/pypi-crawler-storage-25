"""
Principal component analysis helpers.

Contains Kaiser PCA and incremental PCA routines originally written for the
monolithic etc_mlp_force_cover_v3.py script.
"""

from typing import Tuple, List

import numpy as np

from ..core import info, _pct_bin, fmt_progress


def kaiser_pca(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, object, np.ndarray]:
    """
    Standard PCA followed by Kaiser criterion dimension selection.

    Args:
        X: array shape (N, d)
    Returns:
        Zk: projected data with only "kept" components
        scaler: sklearn StandardScaler used for normalization
        pca: sklearn PCA object fitted on standardized data
        keep: indices of components with variance > 1.0
    """
    try:
        from sklearn.preprocessing import StandardScaler
        from sklearn.decomposition import PCA
    except ImportError as e:
        raise RuntimeError("scikit-learn is required for PCA") from e

    scaler = StandardScaler(with_mean=True, with_std=True)
    Xs = scaler.fit_transform(X.astype(np.float32, copy=False))
    pca = PCA(svd_solver="auto")
    Z = pca.fit_transform(Xs)
    keep = np.where(pca.explained_variance_ > 1.0)[0]
    if keep.size == 0:
        keep = np.array([0], dtype=int)
    Zk = Z[:, keep]
    return Zk, scaler, pca, keep


def incremental_pca_auto(
    X: np.ndarray,
    n_components: int = 0,
    batch_size: int = 20000,
    log_step_pct: int = 10,
    tag: str = "pca",
) -> Tuple[np.ndarray, object, object, np.ndarray]:
    """
    Incremental PCA with streaming mean/std, partial_fit, and transform passes.

    Parameters mirror original script. Kaiser criterion applied to output.
    """
    try:
        from sklearn.decomposition import IncrementalPCA
    except ImportError as e:
        raise RuntimeError("scikit-learn is required for incremental PCA") from e

    X = X.astype(np.float32, copy=False)
    n, d = X.shape

    nc = int(n_components) if n_components and n_components > 0 else min(d, 256)
    ipca = IncrementalPCA(n_components=nc)

    info("")
    info(f"{tag.upper()} incremental PCA:")
    info(f"  - Samples: {n:,}")
    info(f"  - Input dimension: {d:,}")
    info(f"  - Batch size: {batch_size:,}")
    info(f"  - Requested components: {nc:,}")

    # PASS 1: streaming mean/std
    info("  - PASS1: streaming mean/std")
    sum_ = np.zeros(d, dtype=np.float64)
    sumsq_ = np.zeros(d, dtype=np.float64)
    cnt = 0
    last_bin = -1
    for i in range(0, n, batch_size):
        j = min(i + batch_size, n)
        chunk = X[i:j].astype(np.float64, copy=False)
        sum_ += chunk.sum(axis=0, dtype=np.float64)
        sumsq_ += np.square(chunk, dtype=np.float64).sum(axis=0, dtype=np.float64)
        cnt += (j - i)
        pct = 100.0 * j / n
        bin_idx = _pct_bin(pct, log_step_pct)
        if bin_idx > last_bin or j == n:
            info(f"    - stats progress: {fmt_progress(j, n, pct)}")
            last_bin = bin_idx
    mean = sum_ / max(cnt, 1)
    var = np.maximum(sumsq_ / max(cnt, 1) - mean * mean, 1e-12)
    std = np.sqrt(var, dtype=np.float64)

    class _ScalerLike:
        def __init__(self, m, s):
            self.mean_ = m.astype(np.float32, copy=False)
            self.scale_ = s.astype(np.float32, copy=False)
    scaler_like = _ScalerLike(mean, std)

    # PASS 2: partial_fit
    info("  - PASS2: partial_fit")
    inv_std = (1.0 / std).astype(np.float64, copy=False)
    mean64 = mean
    last_bin = -1
    for i in range(0, n, batch_size):
        j = min(i + batch_size, n)
        chunk = X[i:j].astype(np.float64, copy=False)
        Xs = (chunk - mean64) * inv_std
        ipca.partial_fit(Xs.astype(np.float32, copy=False))
        pct = 100.0 * j / n
        bin_idx = _pct_bin(pct, log_step_pct)
        if bin_idx > last_bin or j == n:
            info(f"    - partial_fit progress: {fmt_progress(j, n, pct)}")
            last_bin = bin_idx

    # PASS 3: transform
    info("  - PASS3: transform")
    Z_parts = []
    last_bin = -1
    for i in range(0, n, batch_size):
        j = min(i + batch_size, n)
        chunk = X[i:j].astype(np.float64, copy=False)
        Xs = (chunk - mean64) * inv_std
        Z_parts.append(ipca.transform(Xs.astype(np.float32, copy=False)))
        pct = 100.0 * j / n
        bin_idx = _pct_bin(pct, log_step_pct)
        if bin_idx > last_bin or j == n:
            info(f"    - transform progress: {fmt_progress(j, n, pct)}")
            last_bin = bin_idx
    Z = np.vstack(Z_parts)

    eig_full = Z.var(axis=0, ddof=1)
    keep = np.where(eig_full > 1.0)[0]
    if keep.size == 0:
        keep = np.array([0], dtype=int)

    return Z[:, keep], scaler_like, ipca, keep


__all__ = [
    "kaiser_pca",
    "incremental_pca_auto",
]
