"""Pytest-based quick self-check for installed users.

This module provides a tiny end-to-end smoke test (build + sample) that can be
run from CLI:

    chesskit --quickcheck cpu
    chesskit --quickcheck gpu
    chesskit --quickcheck both

The tests are generated in a temporary file and executed via pytest to keep the
check lightweight and independent from repository test files.
"""

from __future__ import annotations

from pathlib import Path
import tempfile
from typing import Literal


def _build_pytest_module() -> str:
    return r'''
import os
import numpy as np
import pytest


def _make_tiny_extxyz(path: str, n_frames: int = 4) -> None:
    from ase import Atoms
    from ase.io import write

    frames = []
    rng = np.random.default_rng(0)
    for _ in range(n_frames):
        atoms = Atoms(
            numbers=[11, 17, 11, 17],
            positions=[[0, 0, 0], [2.0, 0, 0], [0, 2.0, 0], [0, 0, 2.0]],
            cell=[8.0, 8.0, 8.0],
            pbc=True,
        )
        atoms.arrays["forces"] = rng.normal(0.0, 0.01, size=(len(atoms), 3)).astype(np.float32)
        frames.append(atoms)

    write(path, frames, format="extxyz")


def _run_pipeline_smoke(device: str, tmp_path):
    from chess.pipelines import build as run_build, sample as run_sample

    inp = str(tmp_path / "tiny.extxyz")
    cache = str(tmp_path / "tiny_cache.h5")
    out_dir = str(tmp_path / f"report_{device}")
    _make_tiny_extxyz(inp)

    cfg_build = {
        "mode": "build",
        "paths": {
            "input": inp,
            "cache": cache,
            "report_dir": out_dir,
        },
        "featurizer": {
            "name": "wacsf",
            "config": {
                "rcut": 4.0,
                "g2_params": [[0.5, 0.0]],
                "g4_params": [],
                "device": device,
                "batch_size": 2,
                "multi_gpu": False,
            },
        },
        "misc": {
            "seed": 0,
            "plot_graphs": False,
        },
    }

    cfg_sample = {
        "mode": "sample",
        "paths": {
            "input": inp,
            "cache": cache,
            "report_dir": out_dir,
        },
        "chess": {
            "metric": "fisherrao",
            "k_boe": 4,
            "block_size": 4096,
            "radius_stop": -1.0,
            "k_select": 2,
            "seed": 0,
            "sample_frames": 256,
            "batch_ref": 128,
            "boe_batch_size": 128,
            "assign_batch": 128,
        },
        "featurizer": {
            "name": "wacsf",
            "config": {
                "device": device,
                "multi_gpu": False,
            },
        },
        "misc": {
            "seed": 0,
            "plot_graphs": False,
        },
    }

    build_out = run_build(cfg_build)
    assert os.path.exists(build_out["cache_path"])

    sample_out = run_sample(cfg_sample)
    assert os.path.exists(sample_out["indices_path"])
    assert len(sample_out["selected_frames"]) == 2


@pytest.mark.skipif(
    not all(
        __import__("importlib").util.find_spec(p)
        for p in ("torch", "ase", "h5py")
    ),
    reason="quickcheck(cpu) requires torch, ase, h5py",
)
def test_quickcheck_cpu(tmp_path):
    _run_pipeline_smoke("cpu", tmp_path)


@pytest.mark.skipif(
    not __import__("importlib").util.find_spec("torch")
    or not __import__("torch").cuda.is_available(),
    reason="CUDA not available",
)
def test_quickcheck_gpu(tmp_path):
    _run_pipeline_smoke("cuda", tmp_path)
'''


def run_quickcheck(mode: Literal["cpu", "gpu", "both"], verbose: bool = False) -> int:
    """Execute an internal pytest smoke-check for build+sample pipeline.

    Args:
        mode: cpu | gpu | both
        verbose: If True, use verbose pytest output.

    Returns:
        pytest exit code.
    """
    try:
        import pytest  # noqa: F401
    except ImportError:
        print("ERROR: pytest is required for --quickcheck. Install with: pip install pytest")
        return 1

    with tempfile.TemporaryDirectory(prefix="chess_quickcheck_") as td:
        test_file = Path(td) / "test_quickcheck_runtime.py"
        test_file.write_text(_build_pytest_module(), encoding="utf-8")

        import pytest

        args = [str(test_file), "-q"]
        if verbose:
            args = [str(test_file), "-vv", "-s"]

        if mode == "cpu":
            args.extend(["-k", "quickcheck_cpu"])
        elif mode == "gpu":
            args.extend(["-k", "quickcheck_gpu"])
        else:
            args.extend(["-k", "quickcheck_cpu or quickcheck_gpu"])

        rc = int(pytest.main(args))
        if rc == 0:
            print(f"[quickcheck] PASS ({mode})")
        else:
            print(f"[quickcheck] FAIL ({mode}) | exit_code={rc}")
        return rc


__all__ = ["run_quickcheck"]
