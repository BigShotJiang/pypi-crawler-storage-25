"""
Core utilities: logging, path handling, and basic helpers.

This module provides lowest-level utilities used throughout the chess package.
"""

import math
import os
import sys
import platform
from typing import Optional

# optional dependencies
try:
    import torch  # type: ignore
    _HAS_TORCH = True
except ImportError:
    _HAS_TORCH = False


def info(msg: str) -> None:
    """Print a concise runtime message."""
    if msg is None or msg == "":
        print("")
        return
    print(msg)


def format_elapsed_time(seconds: float) -> str:
    """Format elapsed wall-clock time in a concise human-readable form."""
    total = max(0.0, float(seconds))
    hours, rem = divmod(total, 3600.0)
    minutes, rem = divmod(rem, 60.0)

    if hours >= 1.0:
        return f"{int(hours)}h {int(minutes):02d}m {rem:05.2f}s"
    if minutes >= 1.0:
        return f"{int(minutes)}m {rem:05.2f}s"
    return f"{rem:.2f}s"


_CHESS_ASCII_ART = r"""
    _______ _    _   ________   _______   ________
  /  ____| | |  | | |  ______| /  _____| /  _____/
 /  /      | |__| | | |______  | |______ | |_____
|  |       |  __  | |  ______|  \______ \ \_____  \
|  |_______| |  | | | |______   ______| |  _____| |
 \_______| |_|  |_| |________| |_______/ |_______/
""".strip("\n")


def print_chess_banner() -> None:
    """Print CHESS ASCII art banner and canonical expansion line."""
    from . import __version__

    print(_CHESS_ASCII_ART)
    info("")
    info(f"Version: {__version__}")
    info("")
    info("Covering Histogram-based atomic Environments through Sampling on Statistical manifolds")


def print_runtime_resources(stage: str) -> None:
    """Print concise runtime resource summary for the current machine."""
    label = stage.strip().lower() if stage else "runtime"

    python_ver = platform.python_version()
    os_name = f"{platform.system()} {platform.release()}"
    cpu_count = os.cpu_count()

    mem_line = "n/a"
    try:
        import psutil

        vm = psutil.virtual_memory()
        mem_line = f"{vm.available / (1024 ** 3):.2f} GB available / {vm.total / (1024 ** 3):.2f} GB total"
    except Exception:
        pass

    info("")
    info(f"Runtime resources ({label}):")
    info("  ------------------------------")
    info(f"  - Python: {python_ver}")
    info(f"  - OS: {os_name}")
    info(f"  - CPU cores: {cpu_count}")
    info(f"  - Memory: {mem_line}")

    if _HAS_TORCH:
        try:
            import torch

            info(f"  - PyTorch: {torch.__version__}")
            cuda_ok = torch.cuda.is_available()
            mps_ok = hasattr(torch.backends, "mps") and torch.backends.mps.is_available()
            info(f"  - CUDA available: {cuda_ok}")
            info(f"  - MPS available: {mps_ok}")
            if cuda_ok:
                n_gpu = torch.cuda.device_count()
                info(f"  - GPU count: {n_gpu}")
                for i in range(n_gpu):
                    name = torch.cuda.get_device_name(i)
                    total = torch.cuda.get_device_properties(i).total_memory / (1024 ** 3)
                    info(f"    * GPU {i}: {name} ({total:.1f} GB)")
        except Exception as exc:
            info(f"  - GPU probe failed: {exc}")
    else:
        info("  - PyTorch: not installed")
    info("")


def ensure_dir(d: Optional[str]) -> None:
    """
    Ensure directory exists, creating if necessary.
    
    Args:
        d: Directory path (None is ignored)
    """
    if d is None:
        return
    os.makedirs(d, exist_ok=True)


def abs_path(p: Optional[str]) -> Optional[str]:
    """
    Convert path to absolute, expanding user home.
    
    Args:
        p: Path string or None
        
    Returns:
        Absolute path, or None if input is None
        
    Example:
        >>> abs_path("~/data.txt")
        '/home/user/data.txt'
    """
    if p is None:
        return None
    return os.path.abspath(os.path.expanduser(p))


def base_fig(figsize=(5.0, 4.0), dpi=300):
    """
    Create matplotlib figure with standard settings.
    
    Args:
        figsize: (width, height) in inches
        dpi: dots per inch
        
    Returns:
        (fig, ax): matplotlib Figure and Axes objects
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("matplotlib required for plotting")
    
    fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
    return fig, ax


def _auto_linthresh(xy) -> float:
    """
    Estimate symlog threshold from data.
    
    Used for symlog scale in plots to handle both large and small values.
    """
    import numpy as np
    x = xy.reshape(-1)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    p = np.percentile(np.abs(x), 10.0)
    return max(1e-6, float(p))


def _pct_bin(pct: float, step: int) -> int:
    """
    Map percentage (0-100) to bin index.
    
    Used for progress logging throttling.
    
    Args:
        pct: Percentage 0-100
        step: Bin step (e.g., 10 for 0-10 bins)
        
    Returns:
        Bin index 0..(100//step)
    """
    import numpy as np
    pct = max(0.0, min(100.0, 100.0 if np.isnan(pct) else pct))
    return int(pct // step)


def fmt_progress(cur: int, total: int, pct: Optional[float] = None) -> str:
    """Format an aligned human-readable progress counter."""
    total_i = max(1, int(total))
    cur_i = int(cur)
    width = len(f"{total_i:,d}")
    if pct is None:
        pct = 100.0 * cur_i / total_i
    return f"{cur_i:>{width},d}/{total_i:,d} ({pct:>6.2f}%)"


def fmt_count(cur: int, total: int) -> str:
    """Format an aligned count pair with thousands separators."""
    total_i = max(1, int(total))
    width = len(f"{total_i:,d}")
    return f"{int(cur):>{width},d}/{total_i:,d}"


def fmt_float(value: float, decimals: int = 2, width: Optional[int] = None) -> str:
    """Format a floating-point value compactly for human-readable logs."""
    try:
        x = float(value)
    except (TypeError, ValueError):
        s = "nan"
    else:
        if not math.isfinite(x):
            s = "nan"
        elif x != 0.0 and abs(x) < 10.0 ** (-decimals):
            s = f"{x:.{decimals}e}"
        else:
            s = f"{x:.{decimals}f}"
    return f"{s:>{width}}" if width is not None else s


def _pick_device() -> str:
    """
    Intelligently pick compute device.
    
    Returns:
        "cuda" if CUDA available, "mps" if M1/M2 available, else "cpu"
    """
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda"
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
    except ImportError:
        pass
    return "cpu"


def get_available_gpus():
    """
    Get list of available GPU device indices.
    
    Returns:
        List of GPU indices (e.g., [0, 1, 2]) or empty list if no GPUs.
        
    Example:
        >>> gpus = get_available_gpus()
        >>> if len(gpus) > 1:
        ...     print(f"Multi-GPU mode with {len(gpus)} GPUs")
    """
    if not _HAS_TORCH:
        return []
    
    try:
        import torch
        if torch.cuda.is_available():
            return list(range(torch.cuda.device_count()))
    except Exception:
        pass
    return []


def _pick_devices(multi_gpu: bool = False, gpu_ids=None):
    """
    Select GPU device(s) based on configuration.
    
    Args:
        multi_gpu: Enable multi-GPU mode
        gpu_ids: Specific GPU indices (e.g., [0, 1]) or None for all available
        
    Returns:
        tuple: (device_str, device_ids)
            - device_str: "cuda", "mps", or "cpu"
            - device_ids: list of GPU indices if CUDA multi-GPU, else None
            
    Example:
        >>> device, ids = _pick_devices(multi_gpu=True, gpu_ids=[0, 1])
        >>> print(f"Using device: {device}, GPUs: {ids}")
        Using device: cuda, GPUs: [0, 1]
    """
    if not multi_gpu:
        # Single-device mode
        return _pick_device(), None
    
    # Multi-GPU mode
    avail = get_available_gpus()
    if not avail:
        # No GPUs available, fall back to CPU
        info("Multi-GPU requested, but no compatible GPU was found. Falling back to CPU.")
        return "cpu", None
    
    # Select GPUs
    if gpu_ids is not None:
        # Validate requested GPU IDs
        invalid = [g for g in gpu_ids if g not in avail]
        if invalid:
            raise ValueError(
                f"Requested GPU IDs {invalid} not in available GPUs {avail}"
            )
        selected = list(gpu_ids)
    else:
        # Use all available GPUs
        selected = avail
    
    if len(selected) == 1:
        info(f"Using GPU device cuda:{selected[0]}.")
    else:
        info(f"Using {len(selected)} GPU devices: {selected}.")
    
    return "cuda", selected


__all__ = [
    "info",
    "format_elapsed_time",
    "print_chess_banner",
    "print_runtime_resources",
    "ensure_dir",
    "abs_path",
    "base_fig",
    "_auto_linthresh",
    "_pct_bin",
    "fmt_progress",
    "fmt_count",
    "_pick_device",
    "get_available_gpus",
    "_pick_devices",
    "_HAS_TORCH",
]
