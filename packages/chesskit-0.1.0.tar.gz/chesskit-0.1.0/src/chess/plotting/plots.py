"""Plotting utilities used across the package.

These functions were originally defined in the monolithic script and have
been extracted here for reuse by pipelines and analysis routines.
"""
from typing import List, Optional
import os

import numpy as np

from ..core import info, ensure_dir, _auto_linthresh, base_fig

_HAS_PLT = True
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
except ImportError:  # pragma: no cover
    _HAS_PLT = False


def plot_radius_history(
    radius_hist: List[float],
    report_dir: str,
    outfile: str = "kcenter_radius.png",
    dpi: int = 150,
) -> None:
    """Draw and save the radius-vs-step curve for k-center.

    A companion .dat file is also dumped in the same directory.
    """
    if not _HAS_PLT or not radius_hist:
        return
    ensure_dir(report_dir)
    fig, ax = plt.subplots(figsize=(6.0, 4.0), dpi=dpi)
    xs = np.arange(len(radius_hist), dtype=np.int32)
    ax.plot(xs, np.asarray(radius_hist, dtype=np.float64), linewidth=1.6)
    ax.set_xlabel("step")
    ax.set_ylabel("radius (max min-dist)")
    fig.tight_layout()
    png_path = os.path.join(report_dir, outfile)
    fig.savefig(png_path, dpi=300, transparent=True)
    plt.close(fig)

    base, _ = os.path.splitext(outfile)
    dat_path = os.path.join(report_dir, base + ".dat")
    try:
        with open(dat_path, "w", encoding="utf-8") as f:
            for i, r in enumerate(radius_hist):
                f.write(f"{i}\t{r:.16g}\n")
    except Exception as e:  # pragma: no cover
        info(f"[warn] writing radius DAT failed: {e}")


def base_plot_scatter(
    Z2: np.ndarray,
    markers_xy: Optional[np.ndarray] = None,
    outfile: str = "pca_selected_atoms.png",
    dpi: int = 300,
) -> None:
    """Scatter plot with symlog scaling and optional highlights."""
    if not _HAS_PLT:
        return
    fig, ax = base_fig(dpi=dpi)
    Zp = np.asarray(Z2, dtype=float)
    linth = _auto_linthresh(Zp)
    ax.set_xscale('symlog', linthresh=linth)
    ax.set_yscale('symlog', linthresh=linth)
    ax.scatter(Zp[:, 0], Zp[:, 1], s=2.6, alpha=0.35, rasterized=True, linewidths=0, zorder=0)
    if markers_xy is not None and len(markers_xy) > 0:
        ax.scatter(markers_xy[:, 0], markers_xy[:, 1], s=24, alpha=0.95, edgecolors="none", zorder=5)

    outdir = os.path.dirname(outfile)
    if outdir:
        ensure_dir(outdir)
    fig.tight_layout()
    fig.savefig(outfile, dpi=dpi, transparent=True)
    plt.close(fig)


def plot_isotropy_comparison(
    chess_defect: float,
    random_mean: float,
    random_std: float,
    random_folds: List[float],
    report_dir: str,
    outfile: str = "isotropy_defect.png",
    dpi: int = 300,
    metric_label: str = "δ(F)",
    title: str = "Force-weighted isotropy defect",
    chess_effective_rank: Optional[float] = None,
    random_effective_rank_mean: Optional[float] = None,
    random_effective_rank_std: Optional[float] = None,
    random_effective_rank_folds: Optional[List[float]] = None,
    chess_d90: Optional[float] = None,
    chess_d95: Optional[float] = None,
    random_d90_mean: Optional[float] = None,
    random_d90_std: Optional[float] = None,
    random_d95_mean: Optional[float] = None,
    random_d95_std: Optional[float] = None,
) -> None:
    """Bar chart comparing CHESS vs random-baseline isotropy defect.

    Also writes a companion .dat file with numerical values.
    """
    if not _HAS_PLT:
        return
    ensure_dir(report_dir)

    fig, ax = plt.subplots(figsize=(4.0, 4.0), dpi=dpi)
    labels = ["CHESS", "Random"]
    means = [chess_defect, random_mean]
    errs = [0.0, random_std]
    colours = ["#2a7fff", "#ff6f2a"]
    ax.bar(
        labels,
        means,
        yerr=errs,
        capsize=5,
        color=colours,
        edgecolor="black",
        linewidth=0.6,
        width=0.5,
    )
    ax.set_ylabel(f"Isotropy defect  {metric_label}")
    ax.set_title(title)
    ax.set_ylim(bottom=0.0)
    fig.tight_layout()

    png_path = os.path.join(report_dir, outfile)
    fig.savefig(png_path, dpi=dpi, transparent=True)
    plt.close(fig)
    info(f"Isotropy defect plot saved: {png_path}")

    base, _ = os.path.splitext(outfile)
    dat_path = os.path.join(report_dir, base + ".dat")
    try:
        with open(dat_path, "w", encoding="utf-8") as f:
            f.write(f"# {title}\n")
            f.write(f"metric_label\t{metric_label}\n")
            f.write(f"chess_defect\t{chess_defect:.10g}\n")
            f.write(f"random_mean\t{random_mean:.10g}\n")
            f.write(f"random_std\t{random_std:.10g}\n")
            f.write(f"random_n_folds\t{len(random_folds)}\n")
            if chess_effective_rank is not None:
                f.write(f"chess_effective_rank\t{chess_effective_rank:.10g}\n")
            if random_effective_rank_mean is not None:
                f.write(f"random_effective_rank_mean\t{random_effective_rank_mean:.10g}\n")
            if random_effective_rank_std is not None:
                f.write(f"random_effective_rank_std\t{random_effective_rank_std:.10g}\n")
            if chess_d90 is not None:
                f.write(f"chess_d90\t{chess_d90:.10g}\n")
            if chess_d95 is not None:
                f.write(f"chess_d95\t{chess_d95:.10g}\n")
            if random_d90_mean is not None:
                f.write(f"random_d90_mean\t{random_d90_mean:.10g}\n")
            if random_d90_std is not None:
                f.write(f"random_d90_std\t{random_d90_std:.10g}\n")
            if random_d95_mean is not None:
                f.write(f"random_d95_mean\t{random_d95_mean:.10g}\n")
            if random_d95_std is not None:
                f.write(f"random_d95_std\t{random_d95_std:.10g}\n")
            for idx, v in enumerate(random_folds):
                f.write(f"random_fold_{idx}\t{v:.10g}\n")
            if random_effective_rank_folds is not None:
                for idx, v in enumerate(random_effective_rank_folds):
                    f.write(f"random_effective_rank_fold_{idx}\t{v:.10g}\n")
        info(f"Isotropy defect data saved: {dat_path}")
    except Exception as e:  # pragma: no cover
        info(f"Warning: writing isotropy DAT failed: {e}")


def plot_isotropy_cumulative_variance(
    chess_curve: np.ndarray,
    chess_std_curve: Optional[np.ndarray],
    random_mean_curve: np.ndarray,
    random_std_curve: Optional[np.ndarray],
    report_dir: str,
    outfile: str = "isotropy_cumulative_variance.png",
    dpi: int = 300,
    title: str = "Cumulative explained variance",
    chess_d90: Optional[float] = None,
    chess_d95: Optional[float] = None,
    random_d90_mean: Optional[float] = None,
    random_d95_mean: Optional[float] = None,
    random_label: str = "Random",
) -> None:
    """Plot cumulative explained variance versus eigenvalue number and dump a .dat file."""
    if not _HAS_PLT:
        return
    ensure_dir(report_dir)

    chess_curve = np.asarray(chess_curve, dtype=np.float64).reshape(-1)
    random_mean_curve = np.asarray(random_mean_curve, dtype=np.float64).reshape(-1)
    if chess_std_curve is None:
        chess_std_curve = np.zeros_like(chess_curve)
    else:
        chess_std_curve = np.asarray(chess_std_curve, dtype=np.float64).reshape(-1)
    if random_std_curve is None:
        random_std_curve = np.zeros_like(random_mean_curve)
    else:
        random_std_curve = np.asarray(random_std_curve, dtype=np.float64).reshape(-1)

    n_dim = min(chess_curve.size, chess_std_curve.size, random_mean_curve.size, random_std_curve.size)
    if n_dim == 0:
        return

    ks = np.arange(1, n_dim + 1, dtype=np.int32)
    chess_curve = chess_curve[:n_dim]
    chess_std_curve = chess_std_curve[:n_dim]
    random_mean_curve = random_mean_curve[:n_dim]
    random_std_curve = random_std_curve[:n_dim]

    fig, ax = plt.subplots(figsize=(5.0, 4.0), dpi=dpi)
    ax.plot(ks, chess_curve, color="#2a7fff", linewidth=2.0, label="CHESS mean")
    chess_lo = np.clip(chess_curve - chess_std_curve, 0.0, 1.0)
    chess_hi = np.clip(chess_curve + chess_std_curve, 0.0, 1.0)
    ax.fill_between(ks, chess_lo, chess_hi, color="#2a7fff", alpha=0.14, linewidth=0)
    ax.plot(ks, random_mean_curve, color="#ff6f2a", linewidth=1.8, label=f"{random_label} mean")
    lo = np.clip(random_mean_curve - random_std_curve, 0.0, 1.0)
    hi = np.clip(random_mean_curve + random_std_curve, 0.0, 1.0)
    ax.fill_between(ks, lo, hi, color="#ff6f2a", alpha=0.18, linewidth=0)
    ax.axhline(0.90, color="#666666", linestyle="--", linewidth=0.9, label="90% / 95%")
    ax.axhline(0.95, color="#666666", linestyle=":", linewidth=0.9)
    ax.set_xlabel("Eigenvalue number  k")
    ax.set_ylabel("Cumulative explained variance  S(k)")
    ax.set_title(title)
    ax.set_xlim(1, n_dim)
    ax.set_ylim(0.0, 1.02)
    ax.legend(frameon=False)
    fig.tight_layout()

    png_path = os.path.join(report_dir, outfile)
    fig.savefig(png_path, dpi=dpi, transparent=True)
    plt.close(fig)

    base, _ = os.path.splitext(outfile)
    dat_path = os.path.join(report_dir, base + ".dat")
    try:
        with open(dat_path, "w", encoding="utf-8") as f:
            f.write(f"# {title}\n")
            if chess_d90 is not None:
                f.write(f"chess_d90\t{float(chess_d90):.10g}\n")
            if chess_d95 is not None:
                f.write(f"chess_d95\t{float(chess_d95):.10g}\n")
            if random_d90_mean is not None:
                f.write(f"random_d90_mean\t{float(random_d90_mean):.10g}\n")
            if random_d95_mean is not None:
                f.write(f"random_d95_mean\t{float(random_d95_mean):.10g}\n")
            f.write(f"random_label\t{random_label}\n")
            f.write("k\tchess_cumvar\tchess_std_cumvar\trandom_mean_cumvar\trandom_std_cumvar\n")
            for k, c, cs, r, s in zip(ks, chess_curve, chess_std_curve, random_mean_curve, random_std_curve):
                f.write(f"{int(k)}\t{float(c):.10g}\t{float(cs):.10g}\t{float(r):.10g}\t{float(s):.10g}\n")
    except Exception as e:  # pragma: no cover
        info(f"Warning: writing cumulative variance DAT failed: {e}")


def write_isotropy_cumulative_variance_dat(
    chess_curve: np.ndarray,
    chess_std_curve: Optional[np.ndarray],
    random_curves: List[np.ndarray],
    random_std_curves: Optional[List[np.ndarray]],
    report_dir: str,
    outfile: str = "isotropy_cumulative_variance.dat",
    title: str = "Cumulative explained variance",
    chess_d90: Optional[float] = None,
    chess_d95: Optional[float] = None,
) -> None:
    """Write a multi-random cumulative-variance DAT with separate columns per random baseline."""
    ensure_dir(report_dir)

    chess_curve = np.asarray(chess_curve, dtype=np.float64).reshape(-1)
    if chess_std_curve is None:
        chess_std_curve = np.zeros_like(chess_curve)
    else:
        chess_std_curve = np.asarray(chess_std_curve, dtype=np.float64).reshape(-1)

    rand_curves = [np.asarray(curve, dtype=np.float64).reshape(-1) for curve in random_curves]
    rand_std_curves = []
    if random_std_curves is None:
        rand_std_curves = [np.zeros_like(curve) for curve in rand_curves]
    else:
        for idx, curve in enumerate(rand_curves):
            if idx < len(random_std_curves) and random_std_curves[idx] is not None:
                rand_std_curves.append(np.asarray(random_std_curves[idx], dtype=np.float64).reshape(-1))
            else:
                rand_std_curves.append(np.zeros_like(curve))

    all_sizes = [chess_curve.size, chess_std_curve.size] + [arr.size for arr in rand_curves] + [arr.size for arr in rand_std_curves]
    n_dim = min(all_sizes) if all_sizes else 0
    if n_dim == 0:
        return

    ks = np.arange(1, n_dim + 1, dtype=np.int32)
    dat_path = os.path.join(report_dir, outfile)
    try:
        with open(dat_path, "w", encoding="utf-8") as f:
            f.write(f"# {title}\n")
            if chess_d90 is not None:
                f.write(f"chess_d90\t{float(chess_d90):.10g}\n")
            if chess_d95 is not None:
                f.write(f"chess_d95\t{float(chess_d95):.10g}\n")
            header = ["k", "chess_cumvar", "chess_std_cumvar"]
            for idx in range(len(rand_curves)):
                header.extend([f"random_{idx + 1:02d}_cumvar", f"random_{idx + 1:02d}_std_cumvar"])
            f.write("\t".join(header) + "\n")
            for pos, k in enumerate(ks):
                row = [f"{int(k)}", f"{float(chess_curve[pos]):.10g}", f"{float(chess_std_curve[pos]):.10g}"]
                for curve, std_curve in zip(rand_curves, rand_std_curves):
                    row.extend([f"{float(curve[pos]):.10g}", f"{float(std_curve[pos]):.10g}"])
                f.write("\t".join(row) + "\n")
    except Exception as e:  # pragma: no cover
        info(f"Warning: writing cumulative variance DAT failed: {e}")


