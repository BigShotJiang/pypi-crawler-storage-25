"""
Command-line interface entry point for CHESS selection toolkit (chesskit).

This module enables execution via:
    python -m chesskit --config config.yaml
    python -m chesskit --preset build

When installed as a package, can also be called via:
    chesskit --config config.yaml
"""

import sys
from .cli import main

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(128)  # Conventional exit code for Ctrl+C
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
