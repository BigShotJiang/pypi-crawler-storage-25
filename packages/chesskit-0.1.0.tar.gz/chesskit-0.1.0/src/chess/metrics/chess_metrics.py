"""CHESS-specific distance metrics and helpers."""

from typing import List, Optional, Tuple

import numpy as np

from ..core import info, _HAS_TORCH, _pick_device, fmt_float


__all__ = [
    "fisherrao_distance_block",
    "prepare_fisherrao_phi_np",
    "prepare_fisherrao_phi_torch",
    "fisherrao_knn_from_phi",
    "auto_radius_from_nn_fisherrao",
    "pairwise_angles_degrees_from_phi",
]


def fisherrao_distance_block(A: np.ndarray, b: np.ndarray, fr_eps: float = 1e-12) -> np.ndarray:
    """Compute Fisher–Rao distance between rows of *A* and vector *b*."""
    A_ = A.astype(np.float64, copy=False) + fr_eps
    A_ = A_ / (A_.sum(axis=1, keepdims=True) + 1e-18)
    b_ = b.astype(np.float64, copy=False) + fr_eps
    b_ = b_ / (b_.sum() + 1e-18)
    aff = np.sqrt(A_ * b_.reshape(1, -1)).sum(axis=1, dtype=np.float64)
    aff = np.clip(aff, 0.0, 1.0)
    return np.arccos(aff).astype(np.float64, copy=False)


def prepare_fisherrao_phi_np(H: np.ndarray, fr_eps: float) -> np.ndarray:
    """Prepare sqrt-normalized probabilities for FR computations (NumPy)."""
    P = H.astype(np.float64, copy=False) + fr_eps
    P /= (P.sum(axis=1, keepdims=True) + 1e-18)
    return np.sqrt(P, dtype=np.float64)


def prepare_fisherrao_phi_torch(H: np.ndarray, fr_eps: float, device: str):
    """Torch version of ``prepare_fisherrao_phi_np``."""
    import torch

    T = torch.from_numpy(H).to(device=device, dtype=torch.float32)
    T = T + fr_eps
    T = T / (T.sum(dim=1, keepdim=True) + 1e-18)
    T = torch.sqrt(T)
    return T  # (N,K) float32


def _torch_device_ready(device: str) -> bool:
    """Check whether a requested torch device is actually usable."""
    if not _HAS_TORCH:
        return False
    dev = str(device).lower()
    try:
        import torch

        if dev.startswith("cuda"):
            return torch.cuda.is_available()
        if dev.startswith("mps"):
            return hasattr(torch.backends, "mps") and torch.backends.mps.is_available()
    except Exception:
        return False
    return dev == "cpu"


def fisherrao_knn_from_phi(
    Phi: np.ndarray,
    n_neighbors: int = 16,
    block_size: int = 1024,
    device: str = "cpu",
    multi_gpu: bool = False,
    gpu_ids=None,
    knn_mode: str = "fast",
) -> Tuple[np.ndarray, np.ndarray]:
    """Fisher–Rao k-NN within a set of sqrt-normalized histograms.

    ``knn_mode='fast'`` and ``knn_mode='approx'`` use the torch GPU blockwise
    top-k path when an accelerator is available, while ``knn_mode='exact'``
    uses the NumPy float64 reference implementation. In all cases the
    neighborhood is ranked by the Fisher–Rao metric via monotonic ``acos`` on
    cosine affinity.
    """
    n = int(Phi.shape[0])
    if n <= 1:
        return (
            np.empty((n, 0), dtype=np.int64),
            np.empty((n, 0), dtype=np.float64),
        )

    mode = str(knn_mode).strip().lower()
    allowed_modes = {"fast", "exact", "approx"}
    if mode not in allowed_modes:
        raise ValueError(
            f"knn_mode must be one of {sorted(allowed_modes)}, got {knn_mode!r}"
        )

    # Legacy alias kept for compatibility; both run the same fast heuristic path.
    if mode == "approx":
        mode = "fast"

    k_eff = max(1, min(int(n_neighbors), n - 1))

    device_ids = None
    if multi_gpu and _HAS_TORCH:
        from ..core import _pick_devices

        _, device_ids = _pick_devices(multi_gpu=True, gpu_ids=gpu_ids)

    use_device = device
    if use_device == "cpu":
        if mode == "fast":
            if device_ids:
                use_device = f"cuda:{device_ids[0]}"
            else:
                use_device = _pick_device()
        else:
            use_device = "cpu"

    if mode == "fast" and _HAS_TORCH and (_torch_device_ready(use_device) and (multi_gpu or use_device != "cpu")):
        import torch

        if multi_gpu and device_ids and len(device_ids) > 1:
            phi_cpu = torch.from_numpy(Phi.astype(np.float32, copy=False))
            all_idx = np.arange(n, dtype=np.int64)
            idx_chunks = np.array_split(all_idx, len(device_ids))
            nn_idx = np.empty((n, k_eff), dtype=np.int64)
            nn_dist = np.empty((n, k_eff), dtype=np.float64)

            for chunk, dev_id in zip(idx_chunks, device_ids):
                if len(chunk) == 0:
                    continue
                dev = f"cuda:{dev_id}"
                with torch.inference_mode():
                    A = phi_cpu[chunk].to(dev)
                    R = phi_cpu.to(dev)
                    cos = torch.clamp(A @ R.t(), 0.0, 1.0)
                    row_ids = torch.arange(len(chunk), device=dev)
                    col_ids = torch.as_tensor(chunk, device=dev)
                    cos[row_ids, col_ids] = -1.0
                    cos_top, inds = torch.topk(cos, k=k_eff, dim=1, largest=True, sorted=True)
                    vals = torch.acos(torch.clamp(cos_top, 0.0, 1.0))
                nn_idx[chunk] = inds.cpu().numpy().astype(np.int64)
                nn_dist[chunk] = vals.cpu().numpy().astype(np.float64)
            return nn_idx, nn_dist

        T = torch.from_numpy(Phi.astype(np.float32, copy=False)).to(use_device)
        nn_idx = np.empty((n, k_eff), dtype=np.int64)
        nn_dist = np.empty((n, k_eff), dtype=np.float64)

        for lo in range(0, n, block_size):
            hi = min(lo + int(block_size), n)
            with torch.inference_mode():
                A = T[lo:hi]
                cos = torch.clamp(A @ T.t(), 0.0, 1.0)
                row_ids = torch.arange(hi - lo, device=use_device)
                col_ids = torch.arange(lo, hi, device=use_device)
                cos[row_ids, col_ids] = -1.0
                cos_top, inds = torch.topk(cos, k=k_eff, dim=1, largest=True, sorted=True)
                vals = torch.acos(torch.clamp(cos_top, 0.0, 1.0))
            nn_idx[lo:hi] = inds.cpu().numpy().astype(np.int64)
            nn_dist[lo:hi] = vals.cpu().numpy().astype(np.float64)
        return nn_idx, nn_dist

    nn_idx = np.empty((n, k_eff), dtype=np.int64)
    nn_dist = np.empty((n, k_eff), dtype=np.float64)
    for lo in range(0, n, block_size):
        hi = min(lo + int(block_size), n)
        A = Phi[lo:hi]
        cos = A @ Phi.T
        np.clip(cos, 0.0, 1.0, out=cos)
        cos[np.arange(hi - lo), np.arange(lo, hi)] = -np.inf
        part = np.argpartition(-cos, kth=k_eff - 1, axis=1)[:, :k_eff]
        part_cos = np.take_along_axis(cos, part, axis=1)
        order = np.argsort(-part_cos, axis=1)
        top_idx = np.take_along_axis(part, order, axis=1).astype(np.int64)
        top_cos = np.take_along_axis(part_cos, order, axis=1)
        np.clip(top_cos, 0.0, 1.0, out=top_cos)
        nn_idx[lo:hi] = top_idx
        nn_dist[lo:hi] = np.arccos(top_cos).astype(np.float64)
    return nn_idx, nn_dist



def auto_radius_from_nn_fisherrao(
    H_boe_all: np.ndarray,
    fr_eps: float,
    sample_frames: int = 4096,
    batch_ref: int = 1024,
    seed: int = 0,
    multi_gpu: bool = False,
    gpu_ids = None,
    knn_mode: str = "fast",
) -> float:
    """
    Estimate radius stop via median nearest‑neighbor Fisher–Rao distance.
    
    Args:
        H_boe_all: BoE histograms (N_frames, n_vocab)
        fr_eps: Fisher-Rao epsilon for smoothing
        sample_frames: Number of probe frames to sample
        batch_ref: Number of reference frames
        seed: Random seed
        multi_gpu: Enable multi-GPU acceleration
        gpu_ids: Specific GPU indices (None = all available)
        
    Returns:
        Median nearest-neighbor Fisher-Rao distance
    """
    rng = np.random.RandomState(int(seed))
    n = H_boe_all.shape[0]
    s = min(n, int(sample_frames))
    if s <= 1:
        return 0.0
    probes = rng.choice(n, size=s, replace=False)
    refs = rng.choice(n, size=min(n, int(batch_ref)), replace=False)

    mode = str(knn_mode).strip().lower()
    if mode not in {"fast", "exact", "approx"}:
        raise ValueError(f"knn_mode must be one of ['approx', 'exact', 'fast'], got {knn_mode!r}")
    if mode == "approx":
        mode = "fast"

    use_torch = _HAS_TORCH and mode == "fast"
    if use_torch:
        from ..core import _pick_devices
        import torch
        
        if multi_gpu:
            # Multi-GPU path
            device_str, device_ids = _pick_devices(multi_gpu=True, gpu_ids=gpu_ids)
            
            if device_ids and len(device_ids) > 1:
                # Actually use multiple GPUs
                from ..distributed import split_data_across_gpus

                # Prepare Phi on primary GPU
                primary_device = f"cuda:{device_ids[0]}"
                Phi = prepare_fisherrao_phi_torch(H_boe_all, fr_eps, primary_device)

                # Split probes across GPUs
                probe_chunks = split_data_across_gpus(probes, len(device_ids))

                # Compute distances on each GPU
                nn_list = []
                R = Phi.index_select(0, torch.from_numpy(refs).to(primary_device))

                for probe_chunk, device_id in zip(probe_chunks, device_ids):
                    dev = f"cuda:{device_id}"
                    # Index on primary_device first, then move shard to target GPU
                    A = Phi.index_select(
                        0, torch.from_numpy(probe_chunk).to(primary_device)
                    ).to(dev)
                    R_local = R.to(dev)
                    cos = A @ R_local.t()
                    cos = torch.clamp(cos, 0.0, 1.0)
                    nn_cos = torch.max(cos, dim=1).values
                    nn = torch.acos(nn_cos)
                    nn_list.append(nn.cpu().numpy())

                nn_all = np.concatenate(nn_list)
                med = float(np.median(nn_all))
            else:
                # Fall back to single GPU
                device = f"cuda:{device_ids[0]}" if device_ids else "cuda"
                Phi = prepare_fisherrao_phi_torch(H_boe_all, fr_eps, device)
                A = Phi.index_select(0, torch.from_numpy(probes).to(device))
                R = Phi.index_select(0, torch.from_numpy(refs).to(device))
                cos = A @ R.t()
                cos = torch.clamp(cos, 0.0, 1.0)
                nn_cos = torch.max(cos, dim=1).values
                nn = torch.acos(nn_cos)
                med = float(torch.median(nn).item())
        else:
            # Single device path (original)
            device = _pick_device()
            Phi = prepare_fisherrao_phi_torch(H_boe_all, fr_eps, device)
            A = Phi.index_select(0, torch.from_numpy(probes).to(device))
            R = Phi.index_select(0, torch.from_numpy(refs).to(device))
            cos = A @ R.t()
            cos = torch.clamp(cos, 0.0, 1.0)
            nn_cos = torch.max(cos, dim=1).values
            nn = torch.acos(nn_cos)
            med = float(torch.median(nn).item())
    else:
        Phi = prepare_fisherrao_phi_np(H_boe_all, fr_eps)
        A = Phi[probes]
        R = Phi[refs]
        cos = A @ R.T
        np.clip(cos, 0.0, 1.0, out=cos)
        nn_cos = np.max(cos, axis=1)
        nn = np.arccos(nn_cos)
        med = float(np.median(nn)) if nn.size else 0.0

    info(
        f"Estimated radius_stop from median nearest-neighbor Fisher-Rao distance: {fmt_float(med)} "
        f"using sample={s:,} and refs={len(refs):,}."
    )
    return med


def pairwise_angles_degrees_from_phi(Phi: np.ndarray, max_pairs: int = 2_000_000, seed: int = 0) -> np.ndarray:
    """Compute (sampled) pairwise angles in degrees from embeddings Phi.

    The returned vector contains random pairs if the full set would exceed
    ``max_pairs``.
    """
    N = Phi.shape[0]
    if N <= 1:
        return np.zeros((0,), dtype=np.float64)
    total_pairs = N * (N - 1) // 2
    rng = np.random.RandomState(int(seed))
    if total_pairs <= max_pairs:
        G = Phi @ Phi.T
        np.clip(G, -1.0, 1.0, out=G)
        iu = np.triu_indices(N, k=1)
        cosv = G[iu]
        ang = np.degrees(np.arccos(cosv))
        return ang.astype(np.float64, copy=False)
    m = int(max_pairs)
    i = rng.randint(0, N - 1, size=m)
    j = rng.randint(0, N - 1, size=m)
    swap = j <= i
    j[swap] = (i[swap] + 1 + rng.randint(0, N - i[swap] - 1))
    dot = np.sum(Phi[i] * Phi[j], axis=1, dtype=np.float64)
    np.clip(dot, -1.0, 1.0, out=dot)
    ang = np.degrees(np.arccos(dot))
    return ang.astype(np.float64, copy=False)
