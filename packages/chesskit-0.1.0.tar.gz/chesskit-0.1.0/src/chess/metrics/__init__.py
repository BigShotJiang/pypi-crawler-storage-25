"""Metrics layer: distance metrics for frame selection."""

from .chess_metrics import (
    fisherrao_distance_block,
    prepare_fisherrao_phi_np,
    prepare_fisherrao_phi_torch,
    fisherrao_knn_from_phi,
    auto_radius_from_nn_fisherrao,
    pairwise_angles_degrees_from_phi,
)

from .isotropy import (
    build_force_norm_histograms,
    l2_histogram_distance_matrix,
    fisherrao_logmap_vectors,
    geometry_only_second_moment,
    isotropy_defect,
    effective_rank,
    spectral_coverage_dimension,
    isotropy_metrics_chess,
    isotropy_metrics_random_kfold,
)

__all__ = [
    "fisherrao_distance_block",
    "prepare_fisherrao_phi_np",
    "prepare_fisherrao_phi_torch",
    "fisherrao_knn_from_phi",
    "auto_radius_from_nn_fisherrao",
    "pairwise_angles_degrees_from_phi",
    "build_force_norm_histograms",
    "l2_histogram_distance_matrix",
    "fisherrao_logmap_vectors",
    "geometry_only_second_moment",
    "isotropy_defect",
    "effective_rank",
    "spectral_coverage_dimension",
    "isotropy_metrics_chess",
    "isotropy_metrics_random_kfold",
]
