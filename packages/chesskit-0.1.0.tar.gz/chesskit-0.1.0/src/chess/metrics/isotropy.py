"""Geometry-only local isotropy defect and spectral analysis.

Builds the local second-moment tensor C_i on Fisher–Rao k-nearest-neighbor
neighborhoods and derives isotropy defect, effective rank, D_0.90/D_0.95,
and cumulative explained-variance summaries for CHESS and Random subsets.

When the number of selected frames exceeds ``max_samples``, the analysis is
performed on a uniformly-random subsample to keep runtime tractable. Set
``max_samples='full'`` to disable that subsampling.
"""

from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np

from ..core import info, _HAS_TORCH, _pick_device, _pick_devices

__all__ = [
    "build_force_norm_histograms",
    "l2_histogram_distance_matrix",
    "fisherrao_logmap_vectors",
    "geometry_only_second_moment",
    "isotropy_defect",
    "effective_rank",
    "spectral_coverage_dimension",
    "isotropy_metrics_chess",
    "isotropy_metrics_random_kfold",
]

_DEFAULT_MAX_SAMPLES = 2000
_DEFAULT_N_NEIGHBORS = 16
MaxSamplesArg = Optional[Union[int, str]]
ScaleArg = Optional[Union[float, str]]


# ---------------------------------------------------------------------------
# 1. Force-norm histogram construction
# ---------------------------------------------------------------------------

def build_force_norm_histograms(
    F: np.ndarray,
    frame_counts: List[int],
    n_bins: int = 50,
) -> np.ndarray:
    """Build per-frame normalised histograms of atomic force norms.

    Args:
        F: Atom force array (N_atoms, 3).
        frame_counts: Number of atoms per frame.
        n_bins: Number of histogram bins.

    Returns:
        P_force: (N_frames, n_bins) normalised histograms (rows sum to 1).
    """
    norms = np.linalg.norm(F, axis=1)  # (N_atoms,)
    n_frames = len(frame_counts)

    # Global bin edges so histograms are comparable across frames.
    lo, hi = float(np.min(norms)), float(np.max(norms))
    if hi - lo < 1e-15:
        hi = lo + 1.0
    edges = np.linspace(lo, hi, n_bins + 1)

    P = np.zeros((n_frames, n_bins), dtype=np.float64)
    offset = 0
    for i, cnt in enumerate(frame_counts):
        seg = norms[offset : offset + cnt]
        h, _ = np.histogram(seg, bins=edges)
        s = h.sum()
        if s > 0:
            P[i] = h / s
        offset += cnt
    return P


def _normalize_histogram_rows(H: np.ndarray) -> np.ndarray:
    """Return row-wise L1-normalized histograms."""
    H = np.asarray(H, dtype=np.float64)
    denom = np.sum(H, axis=1, keepdims=True)
    return H / np.where(denom > 1e-30, denom, 1.0)


def _standardize_observable(X: np.ndarray, method: str = "zscore", eps: float = 1e-12) -> np.ndarray:
    """Standardize per-feature observable blocks for stable Euclidean weights."""
    X = np.asarray(X, dtype=np.float64)
    token = str(method or "zscore").strip().lower()
    if token in {"none", "off", "raw"}:
        return X
    if token in {"zscore", "z", "standard"}:
        mu = np.mean(X, axis=0, keepdims=True)
        sigma = np.std(X, axis=0, keepdims=True)
        return (X - mu) / np.where(sigma > eps, sigma, 1.0)
    if token in {"robust", "iqr"}:
        med = np.median(X, axis=0, keepdims=True)
        q1 = np.percentile(X, 25.0, axis=0, keepdims=True)
        q3 = np.percentile(X, 75.0, axis=0, keepdims=True)
        scale = q3 - q1
        return (X - med) / np.where(scale > eps, scale, 1.0)
    raise ValueError(f"Unknown isotropy.observable.standardize={method!r}")


def _auto_scale_block(X: np.ndarray, method: str = "rms", eps: float = 1e-12) -> float:
    """Return an automatic multiplicative scale for one observable block."""
    X = np.asarray(X, dtype=np.float64)
    if X.size == 0:
        return 1.0

    token = str(method or "rms").strip().lower()
    if token in {"none", "off"}:
        return 1.0
    if token in {"rms", "l2"}:
        row_norm_sq = np.sum(X * X, axis=1)
        rms = float(np.sqrt(np.mean(row_norm_sq)))
        return 1.0 / max(rms, eps)
    raise ValueError(f"Unknown isotropy.observable.scaling_method={method!r}")


def _resolve_scale_arg(scale: ScaleArg, X: np.ndarray, scaling_method: str = "rms") -> float:
    """Resolve numeric or automatic observable block scaling."""
    if scale is None:
        return 1.0
    if isinstance(scale, str):
        token = scale.strip().lower()
        if token in {"auto", "rms"}:
            return _auto_scale_block(X, method=scaling_method)
        try:
            return float(token)
        except ValueError as exc:
            raise ValueError(
                f"Observable scale must be a float or 'auto', got {scale!r}."
            ) from exc
    return float(scale)


def build_force_observable(
    H_boe: np.ndarray,
    F: np.ndarray,
    frame_counts: List[int],
    atom_labels: Optional[np.ndarray] = None,
    mean_scale: ScaleArg = "auto",
    var_scale: ScaleArg = "auto",
    include_histogram: bool = True,
    standardize: str = "zscore",
    scaling_method: str = "rms",
    return_metadata: bool = False,
):
    """Build the hierarchical force observable q^(F) = [h, α m~, β v~].

    The preferred path uses per-codeword force mean and variance computed from
    atom-to-codeword assignments. If assignments are unavailable, a weaker
    fallback based on global force-norm histograms is used for compatibility.

    When ``mean_scale`` / ``var_scale`` are set to ``"auto"``, an RMS-based
    block normalization is applied so that each block has unit average row-norm.
    """
    h = _normalize_histogram_rows(H_boe)
    n_frames, n_codewords = h.shape

    if atom_labels is None:
        m = build_force_norm_histograms(F, frame_counts, n_bins=n_codewords)
        v = np.zeros_like(m, dtype=np.float64)
    else:
        labels = np.asarray(atom_labels, dtype=np.int64).reshape(-1)
        if labels.size != int(F.shape[0]):
            raise ValueError(
                f"atom_labels length ({labels.size}) must match number of atoms ({F.shape[0]})."
            )
        if np.any(labels < 0) or np.any(labels >= n_codewords):
            raise ValueError("atom_labels contain values outside the valid codeword range.")

        norms = np.linalg.norm(F, axis=1).astype(np.float64, copy=False)
        frame_ids = np.repeat(np.arange(n_frames, dtype=np.int64), frame_counts)
        flat = frame_ids * n_codewords + labels
        size = n_frames * n_codewords
        counts = np.bincount(flat, minlength=size).reshape(n_frames, n_codewords).astype(np.float64, copy=False)
        sum1 = np.bincount(flat, weights=norms, minlength=size).reshape(n_frames, n_codewords)
        sum2 = np.bincount(flat, weights=norms * norms, minlength=size).reshape(n_frames, n_codewords)
        m = np.divide(sum1, counts, out=np.zeros_like(sum1), where=counts > 0)
        second = np.divide(sum2, counts, out=np.zeros_like(sum2), where=counts > 0)
        v = np.maximum(second - m * m, 0.0)

    m_std = _standardize_observable(m, method=standardize)
    v_std = _standardize_observable(v, method=standardize)
    mean_scale_val = _resolve_scale_arg(mean_scale, m_std, scaling_method=scaling_method)
    var_scale_val = _resolve_scale_arg(var_scale, v_std, scaling_method=scaling_method)

    parts = []
    if include_histogram:
        parts.append(h)
    parts.append(mean_scale_val * m_std)
    parts.append(var_scale_val * v_std)
    out = np.concatenate(parts, axis=1).astype(np.float64, copy=False)
    if return_metadata:
        return out, {
            "mean_scale": float(mean_scale_val),
            "var_scale": float(var_scale_val),
            "scaling_method": str(scaling_method),
        }
    return out


def build_energy_observable(
    H_boe: np.ndarray,
    energy_per_atom: np.ndarray,
    energy_scale: ScaleArg = "auto",
    include_histogram: bool = True,
    standardize: str = "zscore",
    scaling_method: str = "rms",
    return_metadata: bool = False,
):
    """Build the hierarchical energy observable q^(E) = [h, γ E~]."""
    h = _normalize_histogram_rows(H_boe)
    e = np.asarray(energy_per_atom, dtype=np.float64).reshape(-1, 1)
    e_std = _standardize_observable(e, method=standardize)
    energy_scale_val = _resolve_scale_arg(energy_scale, e_std, scaling_method=scaling_method)
    parts = []
    if include_histogram:
        parts.append(h)
    parts.append(energy_scale_val * e_std)
    out = np.concatenate(parts, axis=1).astype(np.float64, copy=False)
    if return_metadata:
        return out, {
            "energy_scale": float(energy_scale_val),
            "scaling_method": str(scaling_method),
        }
    return out


# ---------------------------------------------------------------------------
# 2. L^2 histogram distance matrix
# ---------------------------------------------------------------------------

def l2_histogram_distance_matrix(P: np.ndarray) -> np.ndarray:
    """Pairwise L2 distance between rows of *P*.

    Args:
        P: (M, n_bins) histogram array.

    Returns:
        D: (M, M) symmetric distance matrix.
    """
    # ||p_i - p_j||_2^2 = ||p_i||^2 + ||p_j||^2 - 2 p_i . p_j
    norms_sq = np.sum(P ** 2, axis=1)
    G = P @ P.T
    D_sq = norms_sq[:, None] + norms_sq[None, :] - 2.0 * G
    np.maximum(D_sq, 0.0, out=D_sq)
    return np.sqrt(D_sq)


# ---------------------------------------------------------------------------
# 3. Pairwise force weights  w_ij = W(p_i,p_j) / (d_FR(x_i,x_j) + delta)
# ---------------------------------------------------------------------------

def _fisherrao_distance_matrix_np(Phi: np.ndarray) -> np.ndarray:
    """Full pairwise Fisher-Rao distance matrix (NumPy)."""
    G = Phi @ Phi.T
    np.clip(G, 0.0, 1.0, out=G)
    return np.arccos(G)


def _fisherrao_distance_matrix_torch(Phi: np.ndarray, device: str):
    """Full pairwise Fisher-Rao distance matrix (Torch, single device)."""
    import torch

    T = torch.from_numpy(Phi.astype(np.float32)).to(device)
    G = T @ T.t()
    G = torch.clamp(G, 0.0, 1.0)
    D = torch.acos(G)
    return D.cpu().numpy().astype(np.float64)


def pairwise_force_weights(
    force_observable_sel: np.ndarray,
    Phi_sel: np.ndarray,
    delta: float = 1e-8,
    n_neighbors: int = _DEFAULT_N_NEIGHBORS,
    device: str = "cpu",
    multi_gpu: bool = False,
    gpu_ids=None,
    block_size: int = 1024,
    nn_idx: Optional[np.ndarray] = None,
    nn_dist: Optional[np.ndarray] = None,
    weight_eps: float = 1e-8,
    knn_mode: str = "fast",
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute local force weights on Fisher–Rao k-NN neighborhoods.

    ``force_observable_sel`` is the hierarchical force observable
    q^(F) = [h, α m~, β v~], and the numerator uses the Euclidean distance
    ||q_i^(F) - q_j^(F)||_2 with a small regularization ``weight_eps``.
    """
    from .chess_metrics import fisherrao_knn_from_phi

    if nn_idx is None or nn_dist is None:
        nn_idx, nn_dist = fisherrao_knn_from_phi(
            Phi_sel,
            n_neighbors=n_neighbors,
            block_size=block_size,
            device=device,
            multi_gpu=multi_gpu,
            gpu_ids=gpu_ids,
            knn_mode=knn_mode,
        )
    if nn_idx.shape[1] == 0:
        return np.zeros((Phi_sel.shape[0], 0), dtype=np.float64), nn_idx

    if _HAS_TORCH and str(device) != "cpu":
        try:
            import torch

            with torch.inference_mode():
                q = torch.as_tensor(force_observable_sel, dtype=torch.float32, device=device)
                idx = torch.as_tensor(nn_idx, dtype=torch.long, device=device)
                dist = torch.as_tensor(nn_dist, dtype=torch.float32, device=device)
                diff_force = q[idx] - q[:, None, :]
                delta_f = torch.linalg.norm(diff_force, dim=2)
                W = (delta_f + float(weight_eps)) / (dist + float(delta))
            return W.detach().cpu().numpy().astype(np.float64, copy=False), nn_idx
        except Exception:
            pass

    diff_force = force_observable_sel[nn_idx] - force_observable_sel[:, None, :]
    delta_f = np.linalg.norm(diff_force, axis=2)
    W = (delta_f + float(weight_eps)) / (nn_dist + delta)
    return W.astype(np.float64, copy=False), nn_idx


def pairwise_energy_weights(
    energy_observable_sel: np.ndarray,
    Phi_sel: np.ndarray,
    delta: float = 1e-8,
    n_neighbors: int = _DEFAULT_N_NEIGHBORS,
    device: str = "cpu",
    multi_gpu: bool = False,
    gpu_ids=None,
    block_size: int = 1024,
    nn_idx: Optional[np.ndarray] = None,
    nn_dist: Optional[np.ndarray] = None,
    weight_eps: float = 1e-8,
    knn_mode: str = "fast",
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute local energy weights on FR k-NN neighborhoods.

    ``energy_observable_sel`` is the hierarchical observable
    q^(E) = [h, γ E~], and the numerator uses ||q_i^(E) - q_j^(E)||_2.
    """
    from .chess_metrics import fisherrao_knn_from_phi

    if nn_idx is None or nn_dist is None:
        nn_idx, nn_dist = fisherrao_knn_from_phi(
            Phi_sel,
            n_neighbors=n_neighbors,
            block_size=block_size,
            device=device,
            multi_gpu=multi_gpu,
            gpu_ids=gpu_ids,
            knn_mode=knn_mode,
        )
    if nn_idx.shape[1] == 0:
        return np.zeros((Phi_sel.shape[0], 0), dtype=np.float64), nn_idx

    if _HAS_TORCH and str(device) != "cpu":
        try:
            import torch

            with torch.inference_mode():
                q = torch.as_tensor(energy_observable_sel, dtype=torch.float32, device=device)
                idx = torch.as_tensor(nn_idx, dtype=torch.long, device=device)
                dist = torch.as_tensor(nn_dist, dtype=torch.float32, device=device)
                delta_q = torch.linalg.norm(q[idx] - q[:, None, :], dim=2)
                W = (delta_q + float(weight_eps)) / (dist + float(delta))
            return W.detach().cpu().numpy().astype(np.float64, copy=False), nn_idx
        except Exception:
            pass

    q = np.asarray(energy_observable_sel, dtype=np.float64)
    delta_q = np.linalg.norm(q[nn_idx] - q[:, None, :], axis=2)
    W = (delta_q + float(weight_eps)) / (nn_dist + delta)
    return W.astype(np.float64, copy=False), nn_idx


# ---------------------------------------------------------------------------
# 4. Fisher–Rao RNC coordinates and local second moments
# ---------------------------------------------------------------------------

def fisherrao_logmap_vectors(
    Phi_sel: np.ndarray,
    nn_idx: np.ndarray,
    nn_dist: Optional[np.ndarray] = None,
    neighbor_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Compute RNC/log-map vectors ξ_ij = log_{Φ_i}(Φ_j) on the FR sphere.

    With square-root probability coordinates Φ on the positive unit sphere,
    the Fisher–Rao log map is

        ξ_ij = (θ_ij / sin θ_ij) * (Φ_j - cos(θ_ij) Φ_i),

    where θ_ij = d_FR(i, j). This preserves both angular and radial magnitude,
    so ``ξ_ij ξ_ij^T`` reflects local RNC covariance rather than only angular
    isotropy.

    Args:
        Phi_sel: (K, d) sqrt-normalised BoE vectors.
        nn_idx: (K, k_eff) integer neighbor indices.
        nn_dist: Optional (K, k_eff) FR distances. If omitted, they are
            recomputed from the selected neighbor pairs.
        neighbor_mask: Optional (K, k_eff) boolean validity mask for padded
            fixed-radius neighborhoods.

    Returns:
        Xi: (K, k_eff, d) log-map vectors.
    """
    K, d = Phi_sel.shape
    k_eff = int(nn_idx.shape[1]) if nn_idx.ndim == 2 else 0
    Xi = np.zeros((K, k_eff, d), dtype=np.float64)
    if k_eff == 0:
        return Xi

    base = Phi_sel[:, None, :]
    nbr = Phi_sel[nn_idx]
    cos_theta = np.sum(base * nbr, axis=2)
    np.clip(cos_theta, 0.0, 1.0, out=cos_theta)

    theta = np.arccos(cos_theta) if nn_dist is None else nn_dist.astype(np.float64, copy=False)
    sin_theta = np.sin(theta)
    scale = np.ones_like(theta, dtype=np.float64)
    mask = sin_theta > 1e-12
    scale[mask] = theta[mask] / sin_theta[mask]

    Xi = scale[:, :, None] * (nbr - cos_theta[:, :, None] * base)
    Xi[theta <= 1e-12] = 0.0
    if neighbor_mask is not None:
        mask = np.asarray(neighbor_mask, dtype=bool)
        Xi[~mask] = 0.0
    return Xi


def _local_second_moment_from_xi(
    Xi: np.ndarray,
    weights: Optional[np.ndarray] = None,
    neighbor_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Compute local second moments from RNC vectors ξ_ij.

    If ``weights`` is omitted, a uniform geometry-only average is used.
    Otherwise the weighted RNC covariance is returned.
    """
    K, _, d = Xi.shape
    M = np.zeros((K, d, d), dtype=np.float64)
    if Xi.shape[1] == 0:
        return M

    mask = None if neighbor_mask is None else np.asarray(neighbor_mask, dtype=bool)
    Xi_eff = Xi if mask is None else np.where(mask[:, :, None], Xi, 0.0)

    if weights is None:
        if mask is None:
            return np.einsum("nkd,nke->nde", Xi_eff, Xi_eff, optimize=True) / float(Xi_eff.shape[1])
        counts = np.sum(mask, axis=1).astype(np.float64, copy=False)
        valid = counts > 1e-30
        if np.any(valid):
            M[valid] = np.einsum("nkd,nke->nde", Xi_eff[valid], Xi_eff[valid], optimize=True)
            M[valid] /= counts[valid, None, None]
        return M

    weights = np.asarray(weights, dtype=np.float64)
    if mask is not None:
        weights = np.where(mask, weights, 0.0)
    denom = np.sum(weights, axis=1)
    valid = denom > 1e-30
    if np.any(valid):
        M[valid] = np.einsum(
            "nk,nkd,nke->nde", weights[valid], Xi_eff[valid], Xi_eff[valid], optimize=True
        )
        M[valid] /= denom[valid, None, None]
    return M


def geometry_only_second_moment(
    Phi_sel: np.ndarray,
    nn_idx: np.ndarray,
    nn_dist: Optional[np.ndarray] = None,
    neighbor_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Compute the geometry-only local RNC covariance tensor.

    M_i^(geom) = (1 / |N_k(i)|) * sum_{j in N_k(i)} ξ_ij ξ_ij^T

    This includes the radial magnitude of the FR log map and is therefore more
    rigorous than the previous unit-direction-only angular tensor.
    """
    Xi = fisherrao_logmap_vectors(Phi_sel, nn_idx, nn_dist=nn_dist, neighbor_mask=neighbor_mask)
    return _local_second_moment_from_xi(Xi, weights=None, neighbor_mask=neighbor_mask)


# ---------------------------------------------------------------------------
# 5. Isotropy defect
# ---------------------------------------------------------------------------

def isotropy_defect(C: np.ndarray, coverage: float = 0.90) -> np.ndarray:
    """Per-centre intrinsic isotropy defect.

    Measures isotropy within the spectral support defined by the top-r_i
    eigen-directions that explain ``coverage`` of total variance.  This avoids
    the ambient-dimension bias of the full I_d reference, which causes
    near-unity defects whenever the intrinsic rank is much smaller than d.

        r_i  = D_{coverage}(C_i)       (coverage support dimension)
        alpha_i = (sum_{l=1}^{r_i} lambda_l) / r_i
        delta_i = sqrt(sum_{l=1}^{r_i}(lambda_l - alpha_i)^2)
                  / sqrt(sum_{l=1}^{r_i} lambda_l^2)
                = sqrt(1 - s_top^2 / (r_i * sum_{l=1}^{r_i} lambda_l^2))

    delta_i = 0  iff  all top-r_i eigenvalues are equal (isotropic within support).
    delta_i -> sqrt((r_i-1)/r_i) when one eigenvalue dominates within the support.
    Zero tensors and r_i=1 (first eigenvalue >= coverage fraction) yield delta_i=0.

    Args:
        C:        (K, d, d) symmetric PSD tensors.
        coverage: Fraction of total variance that defines the spectral support
                  (default 0.90, consistent with D_0.90).

    Returns:
        deltas: (K,) intrinsic isotropy defect values in [0, 1).
    """
    evals = _sorted_nonnegative_eigenvalues(C)
    return _spectral_summary_from_eigenvalues(evals, coverage=coverage)["intr_defect"]


def _sorted_nonnegative_eigenvalues(C: np.ndarray) -> np.ndarray:
    """Return descending nonnegative eigenvalues for each local tensor.
    
    Uses rcond to filter out tiny eigenvalues from ill-conditioned matrices,
    improving numerical stability when computing spectral properties.
    """
    try:
        # Use rcond to suppress tiny eigenvalues from ill-conditioned matrices
        evals = np.linalg.eigvalsh(C)
    except np.linalg.LinAlgError:
        # Fallback for completely singular or ill-conditioned cases
        evals = np.zeros((C.shape[0], C.shape[1]), dtype=np.float64)
    evals = np.clip(np.real(evals), 0.0, None)
    return evals[:, ::-1]


def _spectral_summary_from_eigenvalues(evals: np.ndarray, eps: float = 1e-30, coverage: float = 0.90) -> Dict[str, np.ndarray]:
    """Compute reusable spectral summaries from precomputed eigenvalues."""
    lam = np.asarray(evals, dtype=np.float64)
    s = np.sum(lam, axis=1, keepdims=True)
    valid = s > eps
    safe_s = np.where(valid, s, 1.0)

    p = lam / safe_s
    logp = np.zeros_like(p)
    mask = p > 1e-15
    logp[mask] = np.log(p[mask])
    erank = np.exp(-np.sum(p * logp, axis=1))
    erank[~valid.reshape(-1)] = 0.0

    cum = np.cumsum(lam, axis=1) / safe_s
    cum[~valid.reshape(-1)] = np.nan

    # ------------------------------------------------------------------
    # Intrinsic isotropy defect: measured within D_{coverage} support.
    # r_i = first k covering >= coverage fraction of total variance.
    # delta_i = sqrt(1 - s_top^2 / (r_i * sum_lam2_top))
    # = 0 when all top-r_i eigenvalues are equal; 0 trivially for r_i<=1.
    # ------------------------------------------------------------------
    K, d = lam.shape
    cum_abs = np.cumsum(lam, axis=1)                     # (K, d) absolute
    threshold_abs = (coverage * s).reshape(K)            # (K,)
    hits = cum_abs >= threshold_abs[:, None]             # (K, d)
    r_arr = np.argmax(hits, axis=1) + 1                  # (K,) 1-indexed
    r_arr[~np.any(hits, axis=1)] = 0                     # zero for zero-trace
    r_arr = np.clip(r_arr, 0, d).astype(np.int64)

    l_idx = np.arange(d)[None, :]                        # (1, d)
    support_mask = l_idx < r_arr[:, None]                # (K, d)
    lam_top = lam * support_mask
    s_top = lam_top.sum(axis=1)                          # (K,)
    sum_lam2_top = (lam_top ** 2).sum(axis=1)            # (K,)
    r_f = r_arr.astype(np.float64)

    intr_defect = np.zeros(K, dtype=np.float64)
    v = (sum_lam2_top > eps) & (r_f > 1.0)
    term = s_top[v] ** 2 / (r_f[v] * sum_lam2_top[v])
    intr_defect[v] = np.sqrt(np.maximum(1.0 - term, 0.0))

    return {
        "erank": erank.astype(np.float64, copy=False),
        "cumvar": cum.astype(np.float64, copy=False),
        "valid": valid.reshape(-1),
        "intr_defect": intr_defect,
        "support_dim": r_arr,
    }


def _coverage_dimension_from_cumvar(cum: np.ndarray, threshold: float = 0.90) -> np.ndarray:
    """Return D_threshold from cumulative explained-variance curves."""
    thr = float(threshold)
    if not (0.0 < thr <= 1.0):
        raise ValueError(f"threshold must lie in (0, 1], got {threshold!r}")
    arr = np.asarray(cum, dtype=np.float64)
    hits = arr >= thr
    dims = np.argmax(hits, axis=1) + 1
    dims[~np.any(hits, axis=1)] = 0
    return dims.astype(np.int64, copy=False)


def _mean_curve_over_valid(cum: np.ndarray) -> np.ndarray:
    """Average cumulative variance curves over tensors with nonzero total variance."""
    arr = np.asarray(cum, dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] == 0:
        return np.zeros((0,), dtype=np.float64)
    valid_rows = np.any(np.isfinite(arr), axis=1)
    if not np.any(valid_rows):
        return np.zeros((arr.shape[1],), dtype=np.float64)
    mean_curve = np.nanmean(arr[valid_rows], axis=0)
    mean_curve = np.clip(mean_curve, 0.0, 1.0)
    return mean_curve.astype(np.float64, copy=False)


def _std_curve_over_valid(cum: np.ndarray) -> np.ndarray:
    """Center-level standard deviation of cumulative variance curves over valid tensors."""
    arr = np.asarray(cum, dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] == 0:
        return np.zeros((0,), dtype=np.float64)
    valid_rows = np.any(np.isfinite(arr), axis=1)
    if not np.any(valid_rows):
        return np.zeros((arr.shape[1],), dtype=np.float64)
    valid_arr = arr[valid_rows]
    if valid_arr.shape[0] <= 1:
        return np.zeros((arr.shape[1],), dtype=np.float64)
    std_curve = np.nanstd(valid_arr, axis=0)
    std_curve = np.nan_to_num(std_curve, nan=0.0)
    std_curve = np.clip(std_curve, 0.0, 1.0)
    return std_curve.astype(np.float64, copy=False)


def _spectral_metrics_from_tensor(C: np.ndarray) -> Dict[str, np.ndarray]:
    """Compute effective-rank, D90/D95, and cumulative-variance summaries with one eigendecomposition."""
    evals = _sorted_nonnegative_eigenvalues(C)
    summary = _spectral_summary_from_eigenvalues(evals)
    cum = summary["cumvar"]
    return {
        "erank": summary["erank"],
        "intr_defect": summary["intr_defect"],
        "d90": _coverage_dimension_from_cumvar(cum, threshold=0.90),
        "d95": _coverage_dimension_from_cumvar(cum, threshold=0.95),
        "cumvar": np.nan_to_num(cum, nan=0.0),
        "cumvar_mean_curve": _mean_curve_over_valid(cum),
        "cumvar_std_curve": _std_curve_over_valid(cum),
    }


def effective_rank(C: np.ndarray) -> np.ndarray:
    """Entropy-based effective rank for each local tensor."""
    return _spectral_metrics_from_tensor(C)["erank"]


def _cumulative_explained_variance(C: np.ndarray) -> np.ndarray:
    """Return per-tensor normalized cumulative eigenvalue coverage curves."""
    return _spectral_metrics_from_tensor(C)["cumvar"]


def spectral_coverage_dimension(C: np.ndarray, threshold: float = 0.90) -> np.ndarray:
    """Return the minimum number of eigen-directions needed to explain a target variance fraction."""
    cum = _spectral_summary_from_eigenvalues(_sorted_nonnegative_eigenvalues(C))["cumvar"]
    return _coverage_dimension_from_cumvar(cum, threshold=threshold)


def _prepare_isotropy_inputs(
    H_boe: np.ndarray,
    indices: np.ndarray,
    fr_eps: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """Prepare normalized BoE histograms and FR embeddings for selected frames."""
    from .chess_metrics import prepare_fisherrao_phi_np

    H_norm = _normalize_histogram_rows(H_boe)
    Phi_all = prepare_fisherrao_phi_np(H_boe, fr_eps)
    return H_norm[indices], Phi_all[indices]


def _pick_isotropy_device(multi_gpu: bool = False, gpu_ids=None) -> str:
    """Pick compute device for isotropy-related FR k-NN calculations."""
    if _HAS_TORCH:
        if multi_gpu:
            _, dev_ids = _pick_devices(multi_gpu=True, gpu_ids=gpu_ids)
            return f"cuda:{dev_ids[0]}" if dev_ids else _pick_device()
        return _pick_device()
    return "cpu"


def _resolve_max_samples(max_samples: MaxSamplesArg, total_count: int) -> int:
    """Resolve isotropy max-sample setting.

    Accepts a positive integer or the string ``"full"`` (also ``"all"``),
    which disables isotropy subsampling and uses the full available set.
    """
    total_i = max(0, int(total_count))
    if total_i == 0:
        return 0
    if max_samples is None:
        return total_i
    if isinstance(max_samples, str):
        token = max_samples.strip().lower()
        if token in {"full", "all"}:
            return total_i
        try:
            max_samples = int(token)
        except ValueError as exc:
            raise ValueError(
                "misc.isotropy.max_samples must be a positive integer or 'full'."
            ) from exc
    max_i = int(max_samples)
    if max_i <= 0:
        raise ValueError("misc.isotropy.max_samples must be positive or 'full'.")
    return min(max_i, total_i)


def _masked_mean(values: np.ndarray, valid_mask: Optional[np.ndarray] = None) -> float:
    """Return the mean over finite values, optionally restricted by a validity mask."""
    arr = np.asarray(values, dtype=np.float64).reshape(-1)
    if valid_mask is not None:
        mask = np.asarray(valid_mask, dtype=bool).reshape(-1)
        arr = arr[mask]
    arr = arr[np.isfinite(arr)]
    return float(np.mean(arr)) if arr.size else float("nan")


def _masked_std(values: np.ndarray, valid_mask: Optional[np.ndarray] = None) -> float:
    """Return the standard deviation over finite values, optionally masked."""
    arr = np.asarray(values, dtype=np.float64).reshape(-1)
    if valid_mask is not None:
        mask = np.asarray(valid_mask, dtype=bool).reshape(-1)
        arr = arr[mask]
    arr = arr[np.isfinite(arr)]
    return float(np.std(arr)) if arr.size else float("nan")


def _torch_postprocess_available(device: str) -> bool:
    """Return True when isotropy post-processing can run on the requested device."""
    if not _HAS_TORCH:
        return False
    dev = str(device).lower()
    try:
        import torch

        if dev.startswith("cuda"):
            return torch.cuda.is_available()
        if dev.startswith("mps"):
            return hasattr(torch.backends, "mps") and torch.backends.mps.is_available()
    except Exception:
        return False
    return dev != "cpu"


def _fisherrao_logmap_chunk_torch(Phi_all, base_rows, nn_idx_chunk, nn_dist_chunk):
    """Torch version of the FR log-map on a row chunk."""
    import torch

    nbr = Phi_all[nn_idx_chunk]
    base = base_rows[:, None, :]
    cos_theta = torch.sum(base * nbr, dim=2).clamp_(0.0, 1.0)
    theta = nn_dist_chunk
    sin_theta = torch.sin(theta)
    scale = torch.ones_like(theta)
    mask = torch.abs(sin_theta) > 1e-12
    scale = torch.where(mask, theta / sin_theta, scale)
    Xi = scale.unsqueeze(-1) * (nbr - cos_theta.unsqueeze(-1) * base)
    Xi = torch.where((theta <= 1e-12).unsqueeze(-1), torch.zeros_like(Xi), Xi)
    return Xi


def _local_second_moment_from_xi_torch(Xi, weights=None):
    """Vectorized torch local second moment computation."""
    import torch

    if Xi.shape[1] == 0:
        return torch.zeros(
            (Xi.shape[0], Xi.shape[2], Xi.shape[2]), dtype=Xi.dtype, device=Xi.device
        )
    if weights is None:
        return torch.einsum("nkd,nke->nde", Xi, Xi) / float(Xi.shape[1])

    w = weights.to(dtype=Xi.dtype)
    denom = torch.clamp(torch.sum(w, dim=1), min=1e-30)
    M = torch.einsum("nk,nkd,nke->nde", w, Xi, Xi)
    return M / denom[:, None, None]


def _intrinsic_defect_from_evals_torch(evals, s_tot, coverage: float = 0.90, eps: float = 1e-30):
    """Intrinsic defect from sorted descending non-negative eigenvalues (torch).

    Mirrors the NumPy logic in _spectral_summary_from_eigenvalues:
      r_i    = first k where cumsum(lambda) >= coverage * total
      delta  = sqrt(1 - s_top^2 / (r_i * sum_lam2_top))
    """
    import torch

    K, d = evals.shape
    cum_abs = torch.cumsum(evals, dim=1)                          # (K, d)
    threshold = (coverage * s_tot).unsqueeze(1)                   # (K, 1)
    hits = cum_abs >= threshold                                   # (K, d)
    any_hit = torch.any(hits, dim=1)                              # (K,)
    r_arr = torch.argmax(hits.long(), dim=1) + 1                  # (K,) 1-indexed
    r_arr = torch.where(any_hit, r_arr, torch.zeros_like(r_arr))  # 0 for invalid
    r_arr = torch.clamp(r_arr, 0, d)

    l_idx = torch.arange(d, device=evals.device).unsqueeze(0)    # (1, d)
    support_mask = l_idx < r_arr.unsqueeze(1)                     # (K, d)
    lam_top = evals * support_mask.to(dtype=evals.dtype)
    s_top = lam_top.sum(dim=1)                                    # (K,)
    sum_lam2_top = (lam_top ** 2).sum(dim=1)                      # (K,)
    r_f = r_arr.to(dtype=evals.dtype)

    v = (sum_lam2_top > eps) & (r_f > 1.0)
    intr_defect = torch.zeros(K, dtype=evals.dtype, device=evals.device)
    if v.any():
        term = s_top[v] ** 2 / (r_f[v] * sum_lam2_top[v])
        intr_defect[v] = torch.sqrt(torch.clamp(1.0 - term, min=0.0))
    return intr_defect


def _isotropy_defect_torch(C, coverage: float = 0.90):
    """Vectorized torch intrinsic isotropy defect (support-based)."""
    return _spectral_metrics_torch(C, coverage=coverage)["intr_defect"]


def _effective_rank_torch(C):
    """Vectorized torch effective rank."""
    return _spectral_metrics_torch(C)["erank"]


def _cumulative_explained_variance_torch(C):
    """Torch cumulative explained-variance curves from local tensor spectra."""
    return _spectral_metrics_torch(C)["cumvar"]


def _coverage_index_from_cum_torch(cum, threshold: float):
    """Return D_threshold from cumulative explained-variance curves."""
    import torch

    hits = cum >= float(threshold)
    dims = torch.argmax(hits.to(torch.int64), dim=1) + 1
    valid = torch.any(hits, dim=1)
    return torch.where(valid, dims, torch.zeros_like(dims))


def _spectral_metrics_torch(C, eps: float = 1e-30, coverage: float = 0.90):
    """Compute spectral summaries from a single torch eigendecomposition.
    
    Handles ill-conditioned matrices by adding small regularization if needed.
    """
    import torch

    try:
        evals = torch.linalg.eigvalsh(C)
    except RuntimeError as e:
        # Handle ill-conditioned matrices gracefully
        if "linalg.eigh" in str(e) or "failed to converge" in str(e).lower():
            # Add small regularization to diagonal for ill-conditioned cases
            C_reg = C + 1e-8 * torch.eye(C.shape[-1], dtype=C.dtype, device=C.device)
            evals = torch.linalg.eigvalsh(C_reg)
        else:
            raise
    evals = torch.clamp(evals.real, min=0.0)
    evals = torch.flip(evals, dims=[1])
    s = torch.sum(evals, dim=1, keepdim=True)
    safe_s = torch.clamp(s, min=eps)
    p = evals / safe_s
    logp = torch.zeros_like(p)
    mask = p > 1e-15
    logp[mask] = torch.log(p[mask])
    erank = torch.exp(-torch.sum(p * logp, dim=1))
    valid = s.reshape(-1) > eps
    erank = torch.where(valid, erank, torch.zeros_like(erank))

    cum = torch.cumsum(evals, dim=1) / safe_s
    d90 = _coverage_index_from_cum_torch(cum, 0.90)
    d95 = _coverage_index_from_cum_torch(cum, 0.95)
    cum_clean = torch.where(valid.unsqueeze(1), cum, torch.zeros_like(cum))

    intr_defect = _intrinsic_defect_from_evals_torch(evals, s.reshape(-1), coverage=coverage, eps=eps)

    return {
        "erank": erank,
        "d90": d90,
        "d95": d95,
        "cumvar": cum_clean,
        "valid": valid,
        "intr_defect": intr_defect,
    }


def _spectral_metrics_torch_from_xi(Xi, weights=None, out_dim: Optional[int] = None, eps: float = 1e-30, coverage: float = 0.90):
    """Low-rank spectral summaries from Xi via kxk Gram eigenspectrum.

    For local tensors ``C = X^T X`` (possibly weighted/normalized), nonzero
    eigenvalues of ``C`` equal those of ``X X^T``. This reduces eigendecomp
    from ``d x d`` to ``k x k`` where usually ``k << d``.
    """
    import torch

    n, k_eff, d = Xi.shape
    target_dim = int(d if out_dim is None else out_dim)
    if k_eff == 0:
        zf = torch.zeros((n,), dtype=Xi.dtype, device=Xi.device)
        zi = torch.zeros((n,), dtype=torch.int64, device=Xi.device)
        zc = torch.zeros((n, target_dim), dtype=Xi.dtype, device=Xi.device)
        return {"erank": zf, "d90": zi, "d95": zi, "cumvar": zc, "valid": torch.zeros((n,), dtype=torch.bool, device=Xi.device), "intr_defect": zf}

    if weights is None:
        G = torch.einsum("nkd,nld->nkl", Xi, Xi) / float(k_eff)
    else:
        w = torch.clamp(weights.to(dtype=Xi.dtype), min=0.0)
        denom = torch.clamp(torch.sum(w, dim=1, keepdim=True), min=eps)
        Xw = Xi * torch.sqrt(w).unsqueeze(-1)
        G = torch.einsum("nkd,nld->nkl", Xw, Xw) / denom.unsqueeze(-1)

    try:
        evals = torch.linalg.eigvalsh(G)
    except RuntimeError as e:
        # Handle ill-conditioned matrices gracefully
        if "linalg.eigh" in str(e) or "failed to converge" in str(e).lower():
            # Add small regularization to diagonal for ill-conditioned cases
            G_reg = G + 1e-8 * torch.eye(G.shape[-1], dtype=G.dtype, device=G.device)
            evals = torch.linalg.eigvalsh(G_reg)
        else:
            raise
    evals = torch.clamp(evals.real, min=0.0)
    evals = torch.flip(evals, dims=[1])
    s = torch.sum(evals, dim=1, keepdim=True)
    safe_s = torch.clamp(s, min=eps)
    p = evals / safe_s
    logp = torch.zeros_like(p)
    mask = p > 1e-15
    logp[mask] = torch.log(p[mask])
    erank = torch.exp(-torch.sum(p * logp, dim=1))
    valid = s.reshape(-1) > eps
    erank = torch.where(valid, erank, torch.zeros_like(erank))

    cum_small = torch.cumsum(evals, dim=1) / safe_s
    d90 = _coverage_index_from_cum_torch(cum_small, 0.90)
    d95 = _coverage_index_from_cum_torch(cum_small, 0.95)

    if target_dim > k_eff:
        pad = torch.zeros((n, target_dim - k_eff), dtype=cum_small.dtype, device=cum_small.device)
        cum = torch.cat([cum_small, pad], dim=1)
    else:
        cum = cum_small[:, :target_dim]
    cum_clean = torch.where(valid.unsqueeze(1), cum, torch.zeros_like(cum))

    intr_defect = _intrinsic_defect_from_evals_torch(evals, s.reshape(-1), coverage=coverage, eps=eps)

    return {
        "erank": erank,
        "d90": d90,
        "d95": d95,
        "cumvar": cum_clean,
        "valid": valid,
        "intr_defect": intr_defect,
    }


def _evaluate_isotropy_subset_torch(
    force_observable_sel: np.ndarray,
    Phi_sel: np.ndarray,
    nn_idx: np.ndarray,
    nn_dist: np.ndarray,
    delta: float,
    energy_observable_sel: Optional[np.ndarray] = None,
    device: str = "cuda",
    chunk_size: int = 4096,
    weight_eps: float = 1e-8,
    compile_torch: bool = True,
) -> Dict[str, np.ndarray]:
    """Compute isotropy metrics on GPU/MPS while keeping peak memory bounded.

    The heavy log-map and eigenspectrum work stays on the accelerator, but the
    long-lived per-frame outputs are staged back to CPU chunk-by-chunk so we do
    not retain large ``(K, d, d)`` or ``(K, d)`` tensors on device.
    """
    import torch

    chunk_size = max(1, int(chunk_size))
    with torch.inference_mode():
        Phi_t = torch.as_tensor(Phi_sel, dtype=torch.float32, device=device)
        Qf_t = torch.as_tensor(force_observable_sel, dtype=torch.float32, device=device)
        idx_t = torch.as_tensor(nn_idx, dtype=torch.long, device=device)
        dist_t = torch.as_tensor(nn_dist, dtype=torch.float32, device=device)
        Qe_t = (
            torch.as_tensor(energy_observable_sel, dtype=torch.float32, device=device)
            if energy_observable_sel is not None else None
        )

        K = int(Phi_t.shape[0])
        d = int(Phi_t.shape[1])
        geom = np.empty((K,), dtype=np.float32)
        geom_erank = np.empty((K,), dtype=np.float32)
        geom_d90 = np.empty((K,), dtype=np.int64)
        geom_d95 = np.empty((K,), dtype=np.int64)
        geom_cum = np.zeros((K, d), dtype=np.float32)
        geom_valid = np.zeros((K,), dtype=bool)

        force = np.empty((K,), dtype=np.float32)
        force_erank = np.empty((K,), dtype=np.float32)
        force_d90 = np.empty((K,), dtype=np.int64)
        force_d95 = np.empty((K,), dtype=np.int64)
        force_cum = np.zeros((K, d), dtype=np.float32)
        force_valid = np.zeros((K,), dtype=bool)

        energy = np.empty((K,), dtype=np.float32) if Qe_t is not None else None
        energy_erank = np.empty((K,), dtype=np.float32) if Qe_t is not None else None
        energy_d90 = np.empty((K,), dtype=np.int64) if Qe_t is not None else None
        energy_d95 = np.empty((K,), dtype=np.int64) if Qe_t is not None else None
        energy_cum = np.zeros((K, d), dtype=np.float32) if Qe_t is not None else None
        energy_valid = np.zeros((K,), dtype=bool) if Qe_t is not None else None

        logmap_kernel = _fisherrao_logmap_chunk_torch
        if compile_torch and hasattr(torch, "compile"):
            try:
                logmap_kernel = torch.compile(_fisherrao_logmap_chunk_torch, mode="reduce-overhead", fullgraph=False)
            except Exception:
                logmap_kernel = _fisherrao_logmap_chunk_torch

        for lo in range(0, K, chunk_size):
            hi = min(lo + chunk_size, K)
            base_phi = Phi_t[lo:hi]
            idx_chunk = idx_t[lo:hi]
            dist_chunk = dist_t[lo:hi]

            Xi = logmap_kernel(Phi_t, base_phi, idx_chunk, dist_chunk)

            geom_spec = _spectral_metrics_torch_from_xi(Xi, weights=None, out_dim=d)
            geom[lo:hi] = geom_spec["intr_defect"].detach().cpu().numpy().astype(np.float32, copy=False)
            geom_erank[lo:hi] = geom_spec["erank"].detach().cpu().numpy().astype(np.float32, copy=False)
            geom_d90[lo:hi] = geom_spec["d90"].detach().cpu().numpy().astype(np.int64, copy=False)
            geom_d95[lo:hi] = geom_spec["d95"].detach().cpu().numpy().astype(np.int64, copy=False)
            geom_cum[lo:hi] = geom_spec["cumvar"].detach().cpu().numpy().astype(np.float32, copy=False)
            geom_valid[lo:hi] = geom_spec["valid"].detach().cpu().numpy().astype(bool, copy=False)

            base_force = Qf_t[lo:hi]
            W_force = torch.linalg.norm(Qf_t[idx_chunk] - base_force[:, None, :], dim=2)
            W_force = (W_force + float(weight_eps)) / (dist_chunk + float(delta))
            force_spec = _spectral_metrics_torch_from_xi(Xi, weights=W_force, out_dim=d)
            force[lo:hi] = force_spec["intr_defect"].detach().cpu().numpy().astype(np.float32, copy=False)
            force_erank[lo:hi] = force_spec["erank"].detach().cpu().numpy().astype(np.float32, copy=False)
            force_d90[lo:hi] = force_spec["d90"].detach().cpu().numpy().astype(np.int64, copy=False)
            force_d95[lo:hi] = force_spec["d95"].detach().cpu().numpy().astype(np.int64, copy=False)
            force_cum[lo:hi] = force_spec["cumvar"].detach().cpu().numpy().astype(np.float32, copy=False)
            force_valid[lo:hi] = force_spec["valid"].detach().cpu().numpy().astype(bool, copy=False)

            if (
                Qe_t is not None
                and energy is not None
                and energy_erank is not None
                and energy_d90 is not None
                and energy_d95 is not None
                and energy_cum is not None
                and energy_valid is not None
            ):
                base_energy = Qe_t[lo:hi]
                W_energy = torch.linalg.norm(Qe_t[idx_chunk] - base_energy[:, None, :], dim=2)
                W_energy = (W_energy + float(weight_eps)) / (dist_chunk + float(delta))
                energy_spec = _spectral_metrics_torch_from_xi(Xi, weights=W_energy, out_dim=d)
                energy[lo:hi] = energy_spec["intr_defect"].detach().cpu().numpy().astype(np.float32, copy=False)
                energy_erank[lo:hi] = energy_spec["erank"].detach().cpu().numpy().astype(np.float32, copy=False)
                energy_d90[lo:hi] = energy_spec["d90"].detach().cpu().numpy().astype(np.int64, copy=False)
                energy_d95[lo:hi] = energy_spec["d95"].detach().cpu().numpy().astype(np.int64, copy=False)
                energy_cum[lo:hi] = energy_spec["cumvar"].detach().cpu().numpy().astype(np.float32, copy=False)
                energy_valid[lo:hi] = energy_spec["valid"].detach().cpu().numpy().astype(bool, copy=False)

            del Xi, geom_spec, base_force, W_force, force_spec
            if Qe_t is not None:
                del base_energy, W_energy, energy_spec

        geom_cum = geom_cum.astype(np.float64, copy=False)
        geom_cum[~geom_valid] = np.nan
        geom_curve = _mean_curve_over_valid(geom_cum)
        geom_curve_std = _std_curve_over_valid(geom_cum)

        force_cum = force_cum.astype(np.float64, copy=False)
        force_cum[~force_valid] = np.nan
        force_curve = _mean_curve_over_valid(force_cum)
        force_curve_std = _std_curve_over_valid(force_cum)

        out = {
            "geometry_per_frame": geom.astype(np.float64, copy=False),
            "geometry_erank_per_frame": geom_erank.astype(np.float64, copy=False),
            "geometry_d90_per_frame": geom_d90.astype(np.int64, copy=False),
            "geometry_d95_per_frame": geom_d95.astype(np.int64, copy=False),
            "geometry_cumvar_mean_curve": geom_curve,
            "geometry_cumvar_std_curve": geom_curve_std,
            "geometry_cumvar_curves": np.nan_to_num(geom_cum, nan=0.0),
            "force_per_frame": force.astype(np.float64, copy=False),
            "force_erank_per_frame": force_erank.astype(np.float64, copy=False),
            "force_d90_per_frame": force_d90.astype(np.int64, copy=False),
            "force_d95_per_frame": force_d95.astype(np.int64, copy=False),
            "force_cumvar_mean_curve": force_curve,
            "force_cumvar_std_curve": force_curve_std,
            "force_cumvar_curves": np.nan_to_num(force_cum, nan=0.0),
        }
        if (
            energy is not None
            and energy_erank is not None
            and energy_d90 is not None
            and energy_d95 is not None
            and energy_cum is not None
            and energy_valid is not None
        ):
            energy_cum = energy_cum.astype(np.float64, copy=False)
            energy_cum[~energy_valid] = np.nan
            out["energy_per_frame"] = energy.astype(np.float64, copy=False)
            out["energy_erank_per_frame"] = energy_erank.astype(np.float64, copy=False)
            out["energy_d90_per_frame"] = energy_d90.astype(np.int64, copy=False)
            out["energy_d95_per_frame"] = energy_d95.astype(np.int64, copy=False)
            out["energy_cumvar_mean_curve"] = _mean_curve_over_valid(energy_cum)
            out["energy_cumvar_std_curve"] = _std_curve_over_valid(energy_cum)
            out["energy_cumvar_curves"] = np.nan_to_num(energy_cum, nan=0.0)
        return out


def _evaluate_isotropy_subset(
    force_observable_sel: np.ndarray,
    Phi_sel: np.ndarray,
    delta: float,
    n_neighbors: int,
    energy_observable_sel: Optional[np.ndarray] = None,
    device: str = "cpu",
    multi_gpu: bool = False,
    gpu_ids=None,
    weight_eps: float = 1e-8,
    knn_mode: str = "fast",
    chunk_size: int = 4096,
    compile_torch: bool = True,
) -> Dict[str, np.ndarray]:
    """Compute geometry-only isotropy metrics for one selected/random subset."""
    from .chess_metrics import fisherrao_knn_from_phi

    nn_idx, nn_dist = fisherrao_knn_from_phi(
        Phi_sel,
        n_neighbors=n_neighbors,
        device=device,
        multi_gpu=multi_gpu,
        gpu_ids=gpu_ids,
        knn_mode=knn_mode,
    )

    if _torch_postprocess_available(device):
        try:
            return _evaluate_isotropy_subset_torch(
                force_observable_sel,
                Phi_sel,
                nn_idx,
                nn_dist,
                delta=delta,
                energy_observable_sel=energy_observable_sel,
                device=device,
                chunk_size=chunk_size,
                weight_eps=weight_eps,
                compile_torch=compile_torch,
            )
        except Exception as exc:
            info(
                f"Isotropy accelerator post-processing fallback to NumPy on {device}: {exc}"
            )

    M_geom = geometry_only_second_moment(Phi_sel, nn_idx, nn_dist=nn_dist)
    geom_spec = _spectral_metrics_from_tensor(M_geom)
    geom_curves = np.asarray(geom_spec["cumvar"], dtype=np.float64).copy()

    return {
        "geometry_per_frame": np.asarray(geom_spec["intr_defect"], dtype=np.float64),
        "geometry_erank_per_frame": np.asarray(geom_spec["erank"], dtype=np.float64),
        "geometry_d90_per_frame": np.asarray(geom_spec["d90"], dtype=np.int64),
        "geometry_d95_per_frame": np.asarray(geom_spec["d95"], dtype=np.int64),
        "geometry_cumvar_mean_curve": _mean_curve_over_valid(geom_curves),
        "geometry_cumvar_std_curve": _std_curve_over_valid(geom_curves),
        "geometry_cumvar_curves": geom_curves,
    }


def isotropy_metrics_chess(
    F: np.ndarray,
    frame_counts: List[int],
    H_boe: np.ndarray,
    selected: List[int],
    n_bins: int = 50,
    fr_eps: float = 1e-12,
    delta: float = 1e-8,
    n_neighbors: int = _DEFAULT_N_NEIGHBORS,
    max_samples: MaxSamplesArg = _DEFAULT_MAX_SAMPLES,
    energy_per_atom: Optional[np.ndarray] = None,
    force_observable: Optional[np.ndarray] = None,
    energy_observable: Optional[np.ndarray] = None,
    weight_eps: float = 1e-8,
    multi_gpu: bool = False,
    gpu_ids=None,
    knn_mode: str = "fast",
    chunk_size: int = 4096,
    compile_torch: bool = True,
) -> Dict[str, Any]:
    """Compute geometry-only isotropy metrics for CHESS using fixed FR k-NN neighborhoods."""
    sel = np.asarray(selected, dtype=np.int64)
    max_samples_eff = _resolve_max_samples(max_samples, len(sel))
    if len(sel) > max_samples_eff:
        info(
            f"  - Subsampling {max_samples_eff:,} / {len(sel):,} "
            f"selected frames (max_samples={max_samples!r})"
        )
        rng = np.random.RandomState(42)
        sub_idx = rng.choice(len(sel), size=max_samples_eff, replace=False)
        sel = sel[sub_idx]

    _, Phi_sel = _prepare_isotropy_inputs(H_boe, sel, fr_eps)
    device = _pick_isotropy_device(multi_gpu=multi_gpu, gpu_ids=gpu_ids)

    subset = _evaluate_isotropy_subset(
        np.zeros((len(sel), 1), dtype=np.float64),
        Phi_sel,
        delta=delta,
        n_neighbors=n_neighbors,
        energy_observable_sel=None,
        device=device,
        multi_gpu=multi_gpu,
        gpu_ids=gpu_ids,
        weight_eps=weight_eps,
        knn_mode=knn_mode,
        chunk_size=chunk_size,
        compile_torch=compile_torch,
    )

    return {
        "geometry_mean": _masked_mean(subset["geometry_per_frame"]),
        "geometry_per_frame": subset["geometry_per_frame"],
        "geometry_erank_mean": _masked_mean(subset["geometry_erank_per_frame"]),
        "geometry_erank_per_frame": subset["geometry_erank_per_frame"],
        "geometry_d90_mean": _masked_mean(subset["geometry_d90_per_frame"]),
        "geometry_d90_per_frame": subset["geometry_d90_per_frame"],
        "geometry_d95_mean": _masked_mean(subset["geometry_d95_per_frame"]),
        "geometry_d95_per_frame": subset["geometry_d95_per_frame"],
        "geometry_cumvar_mean_curve": subset["geometry_cumvar_mean_curve"],
        "geometry_cumvar_std_curve": subset.get(
            "geometry_cumvar_std_curve",
            np.zeros_like(subset["geometry_cumvar_mean_curve"]),
        ),
        "n_used": int(len(sel)),
    }


def isotropy_metrics_random_kfold(
    F: np.ndarray,
    frame_counts: List[int],
    H_boe: np.ndarray,
    k_select: int,
    n_folds: int = 5,
    n_bins: int = 50,
    fr_eps: float = 1e-12,
    delta: float = 1e-8,
    seed: int = 42,
    n_neighbors: int = _DEFAULT_N_NEIGHBORS,
    max_samples: MaxSamplesArg = _DEFAULT_MAX_SAMPLES,
    energy_per_atom: Optional[np.ndarray] = None,
    force_observable: Optional[np.ndarray] = None,
    energy_observable: Optional[np.ndarray] = None,
    weight_eps: float = 1e-8,
    multi_gpu: bool = False,
    gpu_ids=None,
    knn_mode: str = "fast",
    chunk_size: int = 4096,
    compile_torch: bool = True,
) -> Dict[str, Any]:
    """Compute geometry-only isotropy baselines for Random subsets using fixed FR k-NN neighborhoods."""
    from .chess_metrics import prepare_fisherrao_phi_np

    n_frames = H_boe.shape[0]
    max_samples_eff = _resolve_max_samples(max_samples, n_frames)
    k_eff = min(int(k_select), max_samples_eff)
    rng = np.random.RandomState(int(seed))

    Phi_all = prepare_fisherrao_phi_np(H_boe, fr_eps)
    device = _pick_isotropy_device(multi_gpu=multi_gpu, gpu_ids=gpu_ids)
    # Each fold samples a different random subset using independent draws from RandomState(seed)
    fold_indices = [rng.choice(n_frames, size=k_eff, replace=False) for _ in range(n_folds)]
    fold_results: List[Dict[str, np.ndarray]] = []

    device_ids = None
    if multi_gpu and _HAS_TORCH:
        _, device_ids = _pick_devices(multi_gpu=True, gpu_ids=gpu_ids)

    if device_ids and len(device_ids) > 1 and n_folds > 1:
        def _run_fold(job):
            fold_id, indices = job
            fold_device = f"cuda:{device_ids[fold_id % len(device_ids)]}"
            return _evaluate_isotropy_subset(
                np.zeros((len(indices), 1), dtype=np.float64),
                Phi_all[indices],
                delta=delta,
                n_neighbors=n_neighbors,
                energy_observable_sel=None,
                device=fold_device,
                multi_gpu=False,
                gpu_ids=None,
                weight_eps=weight_eps,
                knn_mode=knn_mode,
                chunk_size=chunk_size,
                compile_torch=compile_torch,
            )

        with ThreadPoolExecutor(max_workers=min(len(device_ids), n_folds)) as pool:
            fold_results = list(pool.map(_run_fold, list(enumerate(fold_indices))))
    else:
        for indices in fold_indices:
            fold_results.append(
                _evaluate_isotropy_subset(
                    np.zeros((len(indices), 1), dtype=np.float64),
                    Phi_all[indices],
                    delta=delta,
                    n_neighbors=n_neighbors,
                    energy_observable_sel=None,
                    device=device,
                    multi_gpu=multi_gpu,
                    gpu_ids=gpu_ids,
                    weight_eps=weight_eps,
                    knn_mode=knn_mode,
                    chunk_size=chunk_size,
                    compile_torch=compile_torch,
                )
            )

    geom_vals = [_masked_mean(res["geometry_per_frame"]) for res in fold_results]
    geom_erank_vals = [_masked_mean(res["geometry_erank_per_frame"]) for res in fold_results]
    geom_d90_vals = [_masked_mean(res["geometry_d90_per_frame"]) for res in fold_results]
    geom_d95_vals = [_masked_mean(res["geometry_d95_per_frame"]) for res in fold_results]

    geom_arr = np.asarray(geom_vals, dtype=np.float64)
    geom_erank_arr = np.asarray(geom_erank_vals, dtype=np.float64)
    geom_d90_arr = np.asarray(geom_d90_vals, dtype=np.float64)
    geom_d95_arr = np.asarray(geom_d95_vals, dtype=np.float64)

    def _pooled_cumvar_curves(results, curves_key: str, mean_key: str) -> np.ndarray:
        pooled = []
        for res in results:
            curves = res.get(curves_key)
            if curves is None:
                curves = np.asarray(res[mean_key], dtype=np.float64).reshape(1, -1)
            else:
                curves = np.asarray(curves, dtype=np.float64)
                if curves.ndim == 1:
                    curves = curves.reshape(1, -1)
            pooled.append(curves)
        if not pooled:
            return np.zeros((0, 0), dtype=np.float64)
        return np.concatenate(pooled, axis=0)

    geom_curve_pool = _pooled_cumvar_curves(
        fold_results,
        "geometry_cumvar_curves",
        "geometry_cumvar_mean_curve",
    )
    geom_curve_folds = [np.asarray(res["geometry_cumvar_mean_curve"], dtype=np.float64) for res in fold_results]
    geom_curve_std_folds = [
        np.asarray(
            res.get("geometry_cumvar_std_curve", np.zeros_like(res["geometry_cumvar_mean_curve"])),
            dtype=np.float64,
        )
        for res in fold_results
    ]
    return {
        "geometry_mean": _masked_mean(geom_arr),
        "geometry_std": _masked_std(geom_arr),
        "geometry_folds": geom_vals,
        "geometry_erank_mean": _masked_mean(geom_erank_arr),
        "geometry_erank_std": _masked_std(geom_erank_arr),
        "geometry_erank_folds": geom_erank_vals,
        "geometry_d90_mean": _masked_mean(geom_d90_arr),
        "geometry_d90_std": _masked_std(geom_d90_arr),
        "geometry_d90_folds": geom_d90_vals,
        "geometry_d95_mean": _masked_mean(geom_d95_arr),
        "geometry_d95_std": _masked_std(geom_d95_arr),
        "geometry_d95_folds": geom_d95_vals,
        "geometry_cumvar_mean_curve": _mean_curve_over_valid(geom_curve_pool),
        "geometry_cumvar_std_curve": _std_curve_over_valid(geom_curve_pool),
        "geometry_cumvar_fold_curves": geom_curve_folds,
        "geometry_cumvar_fold_std_curves": geom_curve_std_folds,
    }

