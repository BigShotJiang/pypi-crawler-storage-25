"""Compatibility shim for running CHESS via the chesskit module name."""

from chess import __version__

__all__ = ["__version__"]
