import json
import os
import numpy as np

def test_build_missing_input():
    from chess.pipelines import build
    cfg = {"paths": {}}
    try:
        build(cfg)
        assert False, "expected ValueError"
    except ValueError:
        pass


def test_build_caches_energy_per_atom(tmp_path, monkeypatch):
    import h5py
    import importlib
    build_mod = importlib.import_module("chess.pipelines.build")
    from chess.pipelines import build

    input_path = tmp_path / "toy.json"
    cache_path = tmp_path / "toy_cache.h5"
    payload = [
        {
            "numbers": [1, 1],
            "positions": [[0, 0, 0], [0, 0, 0.74]],
            "forces": [[0.0, 0.0, 0.1], [0.0, 0.0, -0.1]],
            "energy": -2.0,
        },
        {
            "numbers": [1, 1, 1, 1],
            "positions": [[0, 0, 0], [0, 0, 1], [0, 1, 0], [1, 0, 0]],
            "forces": [[0.1, 0.0, 0.0]] * 4,
            "energy": -6.0,
        },
    ]
    input_path.write_text(json.dumps(payload), encoding="utf-8")

    class DummyFeaturizer:
        name = "dummy"
        embedding_dim = 4

        def featurize(self, frames, h5_path):
            frame_counts = [len(at) for at in frames]
            n_atoms = sum(frame_counts)
            with h5py.File(h5_path, "w") as h5:
                h5.create_dataset("E", data=np.zeros((n_atoms, 4), dtype=np.float32))
                h5.create_dataset("F", data=np.zeros((n_atoms, 3), dtype=np.float32))
                h5.create_dataset("frame_counts", data=np.asarray(frame_counts, dtype=np.int64))
            return frame_counts, {"embedding_dim": 4}

    monkeypatch.setattr(
        build_mod.FeaturizerRegistry,
        "create",
        lambda *args, **kwargs: DummyFeaturizer(),
    )

    res = build({
        "paths": {"input": str(input_path), "cache": str(cache_path)},
        "featurizer": {"name": "dummy", "config": {}},
    })
    assert os.path.exists(res["cache_path"])
    with h5py.File(cache_path, "r") as h5:
        assert "energy_per_atom" in h5
        np.testing.assert_allclose(h5["energy_per_atom"][:], np.array([-1.0, -1.5]))


def test_sample_missing_cache(tmp_path):
    from chess.pipelines import sample
    cfg = {"paths": {}}
    try:
        sample(cfg)
        assert False
    except ValueError:
        pass


def test_sample_chess_h5(tmp_path):
    """sample() reads an HDF5 cache and runs CHESS selection."""
    import h5py
    cache = tmp_path / "cache.h5"
    n_frames = 10
    atoms_per_frame = 5
    n_atoms = n_frames * atoms_per_frame
    E = np.random.randn(n_atoms, 4).astype(np.float32)
    F = np.random.randn(n_atoms, 3).astype(np.float32)
    fc = np.array([atoms_per_frame] * n_frames, dtype=np.int64)
    with h5py.File(cache, "w") as h5:
        h5.create_dataset("E", data=E)
        h5.create_dataset("F", data=F)
        h5.create_dataset("frame_counts", data=fc)
        h5.attrs["meta"] = "{}"
    cfg = {
        "paths": {"cache": str(cache)},
        "chess": {"k_select": 3, "k_boe": 3},
    }
    from chess.pipelines import sample
    res = sample(cfg)
    assert "selected_frames" in res
    assert len(res["selected_frames"]) == 3


def test_sample_missing_chess_config(tmp_path):
    """sample() raises ValueError when 'chess' section is absent."""
    import h5py
    cache = tmp_path / "cache.h5"
    with h5py.File(cache, "w") as h5:
        h5.create_dataset("E", data=np.zeros((5, 4), dtype=np.float32))
        h5.create_dataset("F", data=np.zeros((5, 3), dtype=np.float32))
        h5.create_dataset("frame_counts", data=np.array([5], dtype=np.int64))
        h5.attrs["meta"] = "{}"
    cfg = {"paths": {"cache": str(cache)}}  # no 'chess' key
    from chess.pipelines import sample
    try:
        sample(cfg)
        assert False, "expected ValueError"
    except ValueError:
        pass


def test_sample_k_select_all(tmp_path):
    """sample() should support k_select='all'."""
    import h5py
    cache = tmp_path / "cache_all.h5"
    n_frames = 6
    atoms_per_frame = 3
    n_atoms = n_frames * atoms_per_frame
    E = np.random.randn(n_atoms, 4).astype(np.float32)
    F = np.random.randn(n_atoms, 3).astype(np.float32)
    fc = np.array([atoms_per_frame] * n_frames, dtype=np.int64)
    with h5py.File(cache, "w") as h5:
        h5.create_dataset("E", data=E)
        h5.create_dataset("F", data=F)
        h5.create_dataset("frame_counts", data=fc)
        h5.attrs["meta"] = "{}"
    cfg = {
        "paths": {"cache": str(cache)},
        "chess": {"k_select": "all", "k_boe": 3},
    }
    from chess.pipelines import sample
    res = sample(cfg)
    assert len(res["selected_frames"]) == n_frames


def test_sample_numeric_k_select_overrides_radius_stop(tmp_path):
    """When k_select is numeric, radius_stop should not cause early stop."""
    import h5py
    cache = tmp_path / "cache_k_priority.h5"
    n_frames = 8
    atoms_per_frame = 3
    n_atoms = n_frames * atoms_per_frame
    E = np.random.randn(n_atoms, 4).astype(np.float32)
    F = np.random.randn(n_atoms, 3).astype(np.float32)
    fc = np.array([atoms_per_frame] * n_frames, dtype=np.int64)
    with h5py.File(cache, "w") as h5:
        h5.create_dataset("E", data=E)
        h5.create_dataset("F", data=F)
        h5.create_dataset("frame_counts", data=fc)
        h5.attrs["meta"] = "{}"
    cfg = {
        "paths": {"cache": str(cache)},
        "chess": {
            "k_select": 4,
            "k_boe": 3,
            "radius_stop": 1e9,
        },
    }
    from chess.pipelines import sample
    res = sample(cfg)
    assert len(res["selected_frames"]) == 4


def test_sample_unsupported_metric_raises(tmp_path):
    """sample() should fail clearly for unsupported metric tokens."""
    import h5py
    cache = tmp_path / "cache_metric.h5"
    with h5py.File(cache, "w") as h5:
        h5.create_dataset("E", data=np.random.randn(20, 4).astype(np.float32))
        h5.create_dataset("F", data=np.random.randn(20, 3).astype(np.float32))
        h5.create_dataset("frame_counts", data=np.array([5, 5, 5, 5], dtype=np.int64))
        h5.attrs["meta"] = "{}"
    cfg = {
        "paths": {"cache": str(cache)},
        "chess": {"k_select": 2, "k_boe": 3, "metric": "unknown_metric"},
    }
    from chess.pipelines import sample
    try:
        sample(cfg)
        assert False, "expected ValueError"
    except ValueError:
        pass


def test_sample_writes_selected_and_remaining_extxyz(tmp_path):
    """sample() should write both selected.extxyz and remaining.extxyz when paths.input is set."""
    pytest = __import__("pytest")
    pytest.importorskip("ase")
    import h5py
    from ase import Atoms
    from ase.io import write as ase_write, iread as ase_iread

    input_xyz = tmp_path / "toy.extxyz"
    cache = tmp_path / "cache.h5"
    report_dir = tmp_path / "report"

    frames = [
        Atoms("H2", positions=[[0.0, 0.0, 0.0], [0.0, 0.0, 0.74]]),
        Atoms("H2", positions=[[0.0, 0.0, 0.0], [0.0, 0.0, 0.76]]),
        Atoms("H2", positions=[[0.0, 0.0, 0.0], [0.0, 0.0, 0.78]]),
        Atoms("H2", positions=[[0.0, 0.0, 0.0], [0.0, 0.0, 0.80]]),
    ]
    ase_write(str(input_xyz), frames, format="extxyz")

    n_atoms = len(frames) * 2
    with h5py.File(cache, "w") as h5:
        h5.create_dataset("E", data=np.random.randn(n_atoms, 4).astype(np.float32))
        h5.create_dataset("F", data=np.random.randn(n_atoms, 3).astype(np.float32))
        h5.create_dataset("frame_counts", data=np.array([2, 2, 2, 2], dtype=np.int64))
        h5.attrs["meta"] = "{}"

    cfg = {
        "paths": {
            "cache": str(cache),
            "input": str(input_xyz),
            "report_dir": str(report_dir),
        },
        "chess": {"k_select": 2, "k_boe": 2, "seed": 0},
        "misc": {"plot_graphs": False, "io_chunk_size": 1},
    }

    from chess.pipelines import sample

    res = sample(cfg)
    selected_out = report_dir / "selected.extxyz"
    remaining_out = report_dir / "remaining.extxyz"

    assert selected_out.exists()
    assert remaining_out.exists()

    n_selected_file = sum(1 for _ in ase_iread(str(selected_out), index=":"))
    n_remaining_file = sum(1 for _ in ase_iread(str(remaining_out), index=":"))
    assert n_selected_file == len(res["selected_frames"])
    assert n_remaining_file == len(frames) - len(res["selected_frames"])


