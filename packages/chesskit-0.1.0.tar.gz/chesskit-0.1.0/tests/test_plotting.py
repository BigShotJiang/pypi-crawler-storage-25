import numpy as np

from chess.plotting import (
    plot_radius_history,
    base_plot_scatter,
    plot_isotropy_cumulative_variance,
)


def test_plot_radius_history(tmp_path, capsys):
    hist = [0.1, 0.5, 0.2]
    report = tmp_path / "report"
    plot_radius_history(hist, str(report), outfile="r.png", dpi=10)
    assert (report / "r.png").exists()
    assert (report / "r.dat").exists()


def test_base_plot_scatter(tmp_path):
    Z = np.random.randn(10, 2)
    markers = Z[:3]
    out = tmp_path / "scatter.png"
    base_plot_scatter(Z, markers_xy=markers, outfile=str(out), dpi=10)
    assert out.exists()


def test_plot_isotropy_cumulative_variance(tmp_path):
    report = tmp_path / "report"
    plot_isotropy_cumulative_variance(
        np.array([0.6, 0.9, 1.0]),
        np.array([0.04, 0.02, 0.0]),
        np.array([0.5, 0.85, 1.0]),
        np.array([0.05, 0.03, 0.0]),
        str(report),
        outfile="cumvar.png",
        dpi=10,
        chess_d90=2.0,
        chess_d95=3.0,
        random_d90_mean=2.2,
        random_d95_mean=2.8,
    )
    assert (report / "cumvar.png").exists()
    dat_path = report / "cumvar.dat"
    assert dat_path.exists()
    text = dat_path.read_text(encoding="utf-8")
    assert "chess_std_cumvar" in text


