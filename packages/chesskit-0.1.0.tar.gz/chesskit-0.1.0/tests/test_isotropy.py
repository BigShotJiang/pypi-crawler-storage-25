"""Tests for isotropy defect analysis module."""

import numpy as np
import pytest

from chess.metrics.isotropy import (
    build_force_norm_histograms,
    build_force_observable,
    build_energy_observable,
    l2_histogram_distance_matrix,
    pairwise_force_weights,
    fisherrao_logmap_vectors,
    geometry_only_second_moment,
    isotropy_defect,
    effective_rank,
    spectral_coverage_dimension,
    _mean_curve_over_valid,
    _std_curve_over_valid,
    _spectral_metrics_from_tensor,
    _spectral_metrics_torch_from_xi,
    isotropy_metrics_chess,
    isotropy_metrics_random_kfold,
)


# ---- fixtures ---------------------------------------------------------------

@pytest.fixture
def simple_data():
    """Small synthetic dataset: 5 frames, 3 atoms each."""
    rng = np.random.RandomState(0)
    n_frames = 5
    atoms_per_frame = 3
    n_atoms = n_frames * atoms_per_frame
    F = rng.randn(n_atoms, 3).astype(np.float32)
    frame_counts = [atoms_per_frame] * n_frames
    # BoE histograms (fake, 4 bins)
    H_boe = rng.rand(n_frames, 4).astype(np.float32)
    H_boe /= H_boe.sum(axis=1, keepdims=True)
    return F, frame_counts, H_boe


# ---- build_force_norm_histograms -------------------------------------------

def test_histogram_shape(simple_data):
    F, frame_counts, _ = simple_data
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    assert P.shape == (5, 10)


def test_histogram_normalised(simple_data):
    F, frame_counts, _ = simple_data
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    sums = P.sum(axis=1)
    np.testing.assert_allclose(sums, 1.0, atol=1e-12)


def test_histogram_non_negative(simple_data):
    F, frame_counts, _ = simple_data
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    assert np.all(P >= 0)


def test_force_observable_mean_var_blocks():
    H_boe = np.array([[2.0, 1.0], [1.0, 2.0]], dtype=np.float32)
    F = np.array([
        [3.0, 0.0, 0.0],
        [0.0, 4.0, 0.0],
        [0.0, 0.0, 5.0],
        [12.0, 0.0, 0.0],
    ], dtype=np.float32)
    frame_counts = [2, 2]
    atom_labels = np.array([0, 1, 0, 1], dtype=np.int64)

    q = build_force_observable(
        H_boe,
        F,
        frame_counts,
        atom_labels,
        mean_scale=1.0,
        var_scale=1.0,
        standardize="none",
    )

    np.testing.assert_allclose(q[:, :2], H_boe / H_boe.sum(axis=1, keepdims=True), atol=1e-12)
    np.testing.assert_allclose(q[0, 2:4], [3.0, 4.0], atol=1e-12)
    np.testing.assert_allclose(q[1, 2:4], [5.0, 12.0], atol=1e-12)
    np.testing.assert_allclose(q[:, 4:6], 0.0, atol=1e-12)


def test_energy_observable_hierarchy_shape():
    H_boe = np.array([[2.0, 1.0], [1.0, 2.0]], dtype=np.float32)
    energy = np.array([1.5, 2.5], dtype=np.float64)
    q = build_energy_observable(H_boe, energy, energy_scale=2.0, standardize="none")

    assert q.shape == (2, 3)
    np.testing.assert_allclose(q[:, :2], H_boe / H_boe.sum(axis=1, keepdims=True), atol=1e-12)
    np.testing.assert_allclose(q[:, 2], 2.0 * energy, atol=1e-12)


def test_force_observable_auto_rms_scaling():
    H_boe = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32)
    F = np.array([
        [3.0, 0.0, 0.0],
        [0.0, 4.0, 0.0],
        [0.0, 0.0, 5.0],
        [12.0, 0.0, 0.0],
    ], dtype=np.float32)
    frame_counts = [2, 2]
    atom_labels = np.array([0, 1, 0, 1], dtype=np.int64)

    q = build_force_observable(
        H_boe,
        F,
        frame_counts,
        atom_labels=atom_labels,
        mean_scale="auto",
        var_scale="auto",
        include_histogram=False,
        standardize="none",
        scaling_method="rms",
    )

    mean_block = q[:, :2]
    var_block = q[:, 2:4]
    np.testing.assert_allclose(np.sqrt(np.mean(np.sum(mean_block ** 2, axis=1))), 1.0, atol=1e-12)
    np.testing.assert_allclose(np.sqrt(np.mean(np.sum(var_block ** 2, axis=1))), 0.0, atol=1e-12)


def test_energy_observable_auto_rms_scaling():
    H_boe = np.array([[2.0, 1.0], [1.0, 2.0]], dtype=np.float32)
    energy = np.array([1.5, 2.5], dtype=np.float64)
    q = build_energy_observable(
        H_boe,
        energy,
        energy_scale="auto",
        include_histogram=False,
        standardize="none",
        scaling_method="rms",
    )

    np.testing.assert_allclose(np.sqrt(np.mean(np.sum(q ** 2, axis=1))), 1.0, atol=1e-12)


# ---- l2_histogram_distance_matrix ------------------------------------------

def test_l2_symmetric(simple_data):
    F, frame_counts, _ = simple_data
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    D = l2_histogram_distance_matrix(P)
    np.testing.assert_allclose(D, D.T, atol=1e-14)


def test_l2_zero_diagonal(simple_data):
    F, frame_counts, _ = simple_data
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    D = l2_histogram_distance_matrix(P)
    np.testing.assert_allclose(np.diag(D), 0.0, atol=1e-7)


def test_l2_non_negative(simple_data):
    F, frame_counts, _ = simple_data
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    D = l2_histogram_distance_matrix(P)
    assert np.all(D >= -1e-14)


# ---- pairwise_force_weights -------------------------------------------------

def test_weights_shape(simple_data):
    F, frame_counts, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    W, nn_idx = pairwise_force_weights(P, Phi, delta=1e-8, n_neighbors=2, device="cpu")
    assert W.shape == (5, 2)
    assert nn_idx.shape == (5, 2)


def test_weights_exclude_self(simple_data):
    F, frame_counts, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    W, nn_idx = pairwise_force_weights(P, Phi, delta=1e-8, n_neighbors=2, device="cpu")
    assert np.all(W >= 0.0)
    assert not np.any(nn_idx == np.arange(Phi.shape[0])[:, None])


def test_weights_neighbor_clamp(simple_data):
    F, frame_counts, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np
    P = build_force_norm_histograms(F, frame_counts, n_bins=10)
    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    W, nn_idx = pairwise_force_weights(P, Phi, delta=1e-8, n_neighbors=99, device="cpu")
    assert W.shape == (5, 4)
    assert nn_idx.shape == (5, 4)


def test_fisherrao_knn_matches_bruteforce(simple_data):
    _, _, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np, fisherrao_knn_from_phi

    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    nn_idx, nn_dist = fisherrao_knn_from_phi(Phi, n_neighbors=2, block_size=2, device="cpu")

    G = Phi @ Phi.T
    np.clip(G, 0.0, 1.0, out=G)
    D = np.arccos(G)
    np.fill_diagonal(D, np.inf)
    order = np.argsort(D, axis=1)[:, :2]
    expected = np.take_along_axis(D, order, axis=1)

    np.testing.assert_array_equal(nn_idx, order)
    np.testing.assert_allclose(nn_dist, expected, atol=1e-6)


def test_fisherrao_knn_fast_and_exact_match_on_cpu(simple_data):
    _, _, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np, fisherrao_knn_from_phi

    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    nn_idx_fast, nn_dist_fast = fisherrao_knn_from_phi(Phi, n_neighbors=2, block_size=2, device="cpu", knn_mode="fast")
    nn_idx_exact, nn_dist_exact = fisherrao_knn_from_phi(Phi, n_neighbors=2, block_size=2, device="cpu", knn_mode="exact")

    np.testing.assert_array_equal(nn_idx_fast, nn_idx_exact)
    np.testing.assert_allclose(nn_dist_fast, nn_dist_exact, atol=1e-6)


# ---- geometry_only_second_moment ------------

def test_logmap_vectors_preserve_fr_radius(simple_data):
    _, _, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np, fisherrao_knn_from_phi
    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    nn_idx, nn_dist = fisherrao_knn_from_phi(Phi, n_neighbors=2, device="cpu")
    Xi = fisherrao_logmap_vectors(Phi, nn_idx, nn_dist=nn_dist)
    np.testing.assert_allclose(np.linalg.norm(Xi, axis=2), nn_dist, atol=1e-6)


def test_second_moment_shape(simple_data):
    _, _, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np, fisherrao_knn_from_phi
    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    nn_idx, nn_dist = fisherrao_knn_from_phi(Phi, n_neighbors=2, device="cpu")
    C_geom = geometry_only_second_moment(Phi, nn_idx, nn_dist=nn_dist)
    d = Phi.shape[1]
    assert C_geom.shape == (5, d, d)


def test_second_moment_symmetric(simple_data):
    _, _, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np, fisherrao_knn_from_phi
    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    nn_idx, nn_dist = fisherrao_knn_from_phi(Phi, n_neighbors=2, device="cpu")
    C_geom = geometry_only_second_moment(Phi, nn_idx, nn_dist=nn_dist)
    for i in range(C_geom.shape[0]):
        np.testing.assert_allclose(C_geom[i], C_geom[i].T, atol=1e-12)


# ---- isotropy_defect --------------------------------------------------------

def test_defect_range(simple_data):
    _, _, H_boe = simple_data
    from chess.metrics.chess_metrics import prepare_fisherrao_phi_np, fisherrao_knn_from_phi
    Phi = prepare_fisherrao_phi_np(H_boe, 1e-12)
    nn_idx, nn_dist = fisherrao_knn_from_phi(Phi, n_neighbors=2, device="cpu")
    C = geometry_only_second_moment(Phi, nn_idx, nn_dist=nn_dist)
    deltas = isotropy_defect(C)
    eranks = effective_rank(C)
    assert deltas.shape == (5,)
    assert np.all(deltas >= 0.0)
    assert np.all(deltas <= 1.0 + 1e-10)
    assert np.all(eranks >= 0.0)
    assert np.all(eranks <= Phi.shape[1] + 1e-10)


def test_perfect_isotropy():
    """An identity-proportional tensor should yield defect ~ 0."""
    d = 4
    C = np.zeros((1, d, d), dtype=np.float64)
    C[0] = 3.0 * np.eye(d)
    deltas = isotropy_defect(C)
    np.testing.assert_allclose(deltas[0], 0.0, atol=1e-12)


def test_intrinsic_defect_low_rank_isotropic():
    """Rank-r isotropic low-rank tensor: intrinsic defect should be 0.

    Old ambient definition would give delta = sqrt(1 - r/d) >> 0.
    New intrinsic definition: all r support eigenvalues are equal -> 0.
    """
    d = 16
    r = 4
    C = np.zeros((1, d, d), dtype=np.float64)
    C[0] = np.diag([3.0] * r + [0.0] * (d - r))
    deltas = isotropy_defect(C)
    np.testing.assert_allclose(deltas[0], 0.0, atol=1e-12)


def test_intrinsic_defect_anisotropic_within_support():
    """Unequal eigenvalues within support produce nonzero intrinsic defect.

    C = diag([5, 3, 2, 0, 0, 0]), total variance = 10.
    coverage threshold = 9.0, cumsum = [5, 8, 10, ...] -> r_i = 3.
    delta = sqrt(1 - 100 / (3 * 38)) = sqrt(7/57) ~ 0.35.
    """
    C = np.zeros((1, 6, 6), dtype=np.float64)
    C[0] = np.diag([5.0, 3.0, 2.0, 0.0, 0.0, 0.0])
    deltas = isotropy_defect(C)
    np.testing.assert_allclose(deltas[0], np.sqrt(7.0 / 57.0), atol=1e-10)
    assert 0.0 < deltas[0] < 1.0


def test_spectral_coverage_dimension():
    """D_0.90 and D_0.95 should reflect cumulative eigenvalue coverage."""
    C = np.zeros((3, 4, 4), dtype=np.float64)
    C[0] = np.diag([4.0, 1.0, 0.0, 0.0])
    C[1] = np.diag([1.0, 1.0, 1.0, 1.0])
    C[2] = np.zeros((4, 4), dtype=np.float64)

    d90 = spectral_coverage_dimension(C, threshold=0.90)
    d95 = spectral_coverage_dimension(C, threshold=0.95)

    np.testing.assert_array_equal(d90, [2, 4, 0])
    np.testing.assert_array_equal(d95, [2, 4, 0])


def test_cumulative_variance_mean_ignores_zero_trace_rows():
    """Mean cumulative variance curve should average only valid spectra."""
    C = np.zeros((2, 3, 3), dtype=np.float64)
    C[0] = np.diag([3.0, 1.0, 0.0])
    metrics = _spectral_metrics_from_tensor(C)

    np.testing.assert_allclose(metrics["cumvar_mean_curve"], [0.75, 1.0, 1.0], atol=1e-12)
    np.testing.assert_allclose(metrics["cumvar_std_curve"], [0.0, 0.0, 0.0], atol=1e-12)


def test_cumulative_variance_helpers_do_not_force_terminal_values():
    """Mean/std helpers should preserve natural terminal values rather than overwrite them."""
    cum = np.array([
        [0.40, 0.70, 0.92],
        [0.20, 0.60, 0.88],
    ], dtype=np.float64)

    np.testing.assert_allclose(_mean_curve_over_valid(cum), [0.30, 0.65, 0.90], atol=1e-12)
    np.testing.assert_allclose(_std_curve_over_valid(cum), [0.10, 0.05, 0.02], atol=1e-12)


def test_lowrank_torch_spectrum_matches_tensor_spectrum():
    torch = pytest.importorskip("torch")
    rng = np.random.RandomState(7)
    Xi_np = rng.randn(3, 4, 6).astype(np.float32)
    Xi = torch.from_numpy(Xi_np)

    C = np.einsum("nkd,nke->nde", Xi_np, Xi_np) / Xi_np.shape[1]
    ref = _spectral_metrics_from_tensor(C)
    got = _spectral_metrics_torch_from_xi(Xi, weights=None, out_dim=Xi_np.shape[2])

    np.testing.assert_allclose(got["erank"].cpu().numpy(), ref["erank"], atol=1e-5)
    np.testing.assert_array_equal(got["d90"].cpu().numpy(), ref["d90"])
    np.testing.assert_array_equal(got["d95"].cpu().numpy(), ref["d95"])


def test_evaluate_subset_dispatches_to_chunked_torch(monkeypatch):
    """Accelerator-backed isotropy should route through the chunked torch evaluator."""
    import chess.metrics.isotropy as iso

    sentinel = {
        "geometry_per_frame": np.array([0.123], dtype=np.float64),
        "geometry_erank_per_frame": np.array([1.5], dtype=np.float64),
        "geometry_d90_per_frame": np.array([1], dtype=np.int64),
        "geometry_d95_per_frame": np.array([1], dtype=np.int64),
        "geometry_cumvar_mean_curve": np.array([1.0], dtype=np.float64),
        "geometry_cumvar_std_curve": np.array([0.0], dtype=np.float64),
        "geometry_cumvar_curves": np.array([[1.0]], dtype=np.float64),
    }

    captured = {}

    def fake_eval(
        force_observable_sel,
        Phi_sel,
        nn_idx,
        nn_dist,
        delta,
        energy_observable_sel=None,
        device="cuda",
        chunk_size=4096,
        weight_eps=1e-8,
        compile_torch=True,
    ):
        captured["device"] = device
        captured["chunk_size"] = chunk_size
        captured["delta"] = delta
        captured["compile_torch"] = compile_torch
        return sentinel

    def fake_knn(*args, **kwargs):
        return np.array([[0]], dtype=np.int64), np.array([[0.0]], dtype=np.float64)

    monkeypatch.setattr(iso, "_torch_postprocess_available", lambda device: True)
    monkeypatch.setattr(iso, "_evaluate_isotropy_subset_torch", fake_eval)
    monkeypatch.setattr("chess.metrics.chess_metrics.fisherrao_knn_from_phi", fake_knn)

    out = iso._evaluate_isotropy_subset(
        np.zeros((1, 1), dtype=np.float64),
        np.array([[1.0, 0.0]], dtype=np.float64),
        delta=1e-8,
        n_neighbors=1,
        device="cuda:0",
        chunk_size=128,
    )

    assert out is sentinel
    assert captured["device"] == "cuda:0"
    assert captured["chunk_size"] == 128
    assert captured["delta"] == pytest.approx(1e-8)
    assert captured["compile_torch"] is True


def test_random_kfold_cumvar_std_pools_center_level_curves(monkeypatch):
    """Random cumulative-variance band should pool center-level curves across folds."""
    import chess.metrics.isotropy as iso

    fold_payloads = [
        {
            "geometry_per_frame": np.array([0.1, 0.2], dtype=np.float64),
            "geometry_erank_per_frame": np.array([1.0, 1.0], dtype=np.float64),
            "geometry_d90_per_frame": np.array([1, 1], dtype=np.int64),
            "geometry_d95_per_frame": np.array([2, 2], dtype=np.int64),
            "geometry_cumvar_mean_curve": np.array([0.5, 1.0], dtype=np.float64),
            "geometry_cumvar_curves": np.array([[0.2, 1.0], [0.8, 1.0]], dtype=np.float64),
            "force_per_frame": np.array([0.1, 0.2], dtype=np.float64),
            "force_erank_per_frame": np.array([1.0, 1.0], dtype=np.float64),
            "force_d90_per_frame": np.array([1, 1], dtype=np.int64),
            "force_d95_per_frame": np.array([2, 2], dtype=np.int64),
            "force_cumvar_mean_curve": np.array([0.5, 1.0], dtype=np.float64),
            "force_cumvar_curves": np.array([[0.2, 1.0], [0.8, 1.0]], dtype=np.float64),
        },
        {
            "geometry_per_frame": np.array([0.3, 0.4], dtype=np.float64),
            "geometry_erank_per_frame": np.array([1.0, 1.0], dtype=np.float64),
            "geometry_d90_per_frame": np.array([1, 1], dtype=np.int64),
            "geometry_d95_per_frame": np.array([2, 2], dtype=np.int64),
            "geometry_cumvar_mean_curve": np.array([0.5, 1.0], dtype=np.float64),
            "geometry_cumvar_curves": np.array([[0.1, 1.0], [0.9, 1.0]], dtype=np.float64),
            "force_per_frame": np.array([0.3, 0.4], dtype=np.float64),
            "force_erank_per_frame": np.array([1.0, 1.0], dtype=np.float64),
            "force_d90_per_frame": np.array([1, 1], dtype=np.int64),
            "force_d95_per_frame": np.array([2, 2], dtype=np.int64),
            "force_cumvar_mean_curve": np.array([0.5, 1.0], dtype=np.float64),
            "force_cumvar_curves": np.array([[0.1, 1.0], [0.9, 1.0]], dtype=np.float64),
        },
    ]
    state = {"i": 0}

    def fake_eval(*args, **kwargs):
        payload = fold_payloads[state["i"]]
        state["i"] += 1
        return payload

    monkeypatch.setattr(iso, "_evaluate_isotropy_subset", fake_eval)

    F = np.zeros((8, 3), dtype=np.float32)
    frame_counts = [1] * 8
    H_boe = np.full((8, 2), 0.5, dtype=np.float32)

    out = iso.isotropy_metrics_random_kfold(
        F,
        frame_counts,
        H_boe,
        k_select=4,
        n_folds=2,
        n_neighbors=1,
        seed=0,
    )

    np.testing.assert_allclose(out["geometry_cumvar_mean_curve"], [0.5, 1.0], atol=1e-12)
    np.testing.assert_allclose(out["geometry_cumvar_std_curve"], [np.std([0.2, 0.8, 0.1, 0.9]), 0.0], atol=1e-12)
    assert len(out["geometry_cumvar_fold_curves"]) == 2
    np.testing.assert_allclose(out["geometry_cumvar_fold_curves"][0], [0.5, 1.0], atol=1e-12)


# ---- sample pipeline integration (isotropy enabled) -------------------------

def test_dual_metrics_helpers(simple_data):
    F, frame_counts, H_boe = simple_data
    selected = [0, 1, 2, 3, 4]
    out_chess = isotropy_metrics_chess(F, frame_counts, H_boe, selected, n_bins=10, n_neighbors=2)
    out_rand = isotropy_metrics_random_kfold(F, frame_counts, H_boe, k_select=3, n_folds=3, n_bins=10, n_neighbors=2, seed=42)
    assert "geometry_mean" in out_chess
    assert "geometry_erank_mean" in out_chess
    assert "geometry_d90_mean" in out_chess and "geometry_d95_mean" in out_chess
    assert "geometry_folds" in out_rand
    assert "geometry_erank_folds" in out_rand
    assert "geometry_d90_folds" in out_rand and "geometry_d95_folds" in out_rand
    assert "geometry_cumvar_std_curve" in out_chess
    assert "geometry_cumvar_std_curve" in out_rand
    assert "force_mean" not in out_chess
    assert "energy_mean" not in out_chess
    assert out_chess["geometry_per_frame"].shape == (5,)
    assert len(out_rand["geometry_folds"]) == 3
    assert out_chess["geometry_cumvar_mean_curve"].ndim == 1
    np.testing.assert_allclose(out_chess["geometry_cumvar_mean_curve"][-1], 1.0, atol=1e-12)
    np.testing.assert_allclose(out_rand["geometry_cumvar_mean_curve"][-1], 1.0, atol=1e-12)
    np.testing.assert_allclose(out_chess["geometry_cumvar_std_curve"][-1], 0.0, atol=1e-12)
    np.testing.assert_allclose(out_rand["geometry_cumvar_std_curve"][-1], 0.0, atol=1e-12)


def test_knn_isotropy_metrics_available(simple_data):
    F, frame_counts, H_boe = simple_data
    selected = [0, 1, 2, 3, 4]

    out = isotropy_metrics_chess(
        F,
        frame_counts,
        H_boe,
        selected,
        n_neighbors=2,
    )

    assert out["geometry_mean"] >= 0.0
    assert out["n_used"] == len(selected)


def test_max_samples_full_uses_all_selected(simple_data):
    F, frame_counts, H_boe = simple_data
    selected = [0, 1, 2, 3, 4]

    out_full = isotropy_metrics_chess(
        F, frame_counts, H_boe, selected, n_bins=10, n_neighbors=2, max_samples="full"
    )
    out_limited = isotropy_metrics_chess(
        F, frame_counts, H_boe, selected, n_bins=10, n_neighbors=2, max_samples=3
    )
    out_rand_full = isotropy_metrics_random_kfold(
        F, frame_counts, H_boe, k_select=5, n_folds=2, n_bins=10, n_neighbors=2, seed=42, max_samples="full"
    )

    assert out_full["n_used"] == len(selected)
    assert out_limited["n_used"] == 3
    assert len(out_rand_full["geometry_folds"]) == 2


def test_sample_isotropy_integration(tmp_path):
    """sample() with isotropy enabled returns isotropy results."""
    import h5py

    n_frames = 10
    atoms_per = 5
    n_atoms = n_frames * atoms_per
    rng = np.random.RandomState(42)
    E = rng.randn(n_atoms, 4).astype(np.float32)
    F = rng.randn(n_atoms, 3).astype(np.float32)
    fc = np.array([atoms_per] * n_frames, dtype=np.int64)

    cache = tmp_path / "cache.h5"
    with h5py.File(cache, "w") as h5:
        h5.create_dataset("E", data=E)
        h5.create_dataset("F", data=F)
        h5.create_dataset("frame_counts", data=fc)
        h5.create_dataset("energy_per_atom", data=rng.randn(n_frames).astype(np.float64))
        h5.attrs["meta"] = "{}"

    cfg = {
        "paths": {"cache": str(cache), "report_dir": str(tmp_path / "report")},
        "chess": {
            "k_select": 4,
            "k_boe": 3,
        },
        "misc": {
            "plot_graphs": False,
            "isotropy": {
                "enabled": True,
                "n_bins": 10,
                "delta": 1e-8,
                "n_neighbors": 3,
                "n_folds": 3,
                "max_samples": "full",
                "seed": 42,
            },
        },
    }
    from chess.pipelines import sample

    res = sample(cfg)
    assert "isotropy" in res
    iso = res["isotropy"]
    assert "geometry" in iso
    assert "force_weighted" not in iso
    assert "energy_weighted" not in iso
    assert "chess_effective_rank" in iso["geometry"]
    assert "random_effective_rank_mean" in iso["geometry"]
    assert len(iso["geometry"]["random_effective_rank_folds"]) == 3
    assert iso["n_used"] == 4


def test_sample_isotropy_plot_outputs_split_random_and_skip_barplots(tmp_path):
    """When isotropy plots are enabled, cumulative-variance outputs split by random fold and bar plots are skipped."""
    import h5py
    from chess.pipelines import sample

    n_frames = 8
    atoms_per = 4
    n_atoms = n_frames * atoms_per
    rng = np.random.RandomState(7)
    E = rng.randn(n_atoms, 4).astype(np.float32)
    F = rng.randn(n_atoms, 3).astype(np.float32)
    fc = np.array([atoms_per] * n_frames, dtype=np.int64)

    cache = tmp_path / "cache_plot.h5"
    report = tmp_path / "report"
    with h5py.File(cache, "w") as h5:
        h5.create_dataset("E", data=E)
        h5.create_dataset("F", data=F)
        h5.create_dataset("frame_counts", data=fc)
        h5.create_dataset("energy_per_atom", data=rng.randn(n_frames).astype(np.float64))
        h5.attrs["meta"] = "{}"

    cfg = {
        "paths": {"cache": str(cache), "report_dir": str(report)},
        "chess": {"k_select": 4, "k_boe": 3},
        "misc": {
            "plot_graphs": True,
            "isotropy": {
                "enabled": True,
                "n_neighbors": 3,
                "n_folds": 2,
                "max_samples": "full",
                "seed": 42,
            },
        },
    }

    sample(cfg)

    assert not (report / "isotropy_geometry_only.png").exists()
    assert not (report / "isotropy_force_weighted.png").exists()
    assert not (report / "isotropy_geometry_cumulative_variance_random_01.png").exists()
    assert not (report / "isotropy_geometry_cumulative_variance_random_02.png").exists()
    assert not (report / "isotropy_geometry_cumulative_variance.dat").exists()
