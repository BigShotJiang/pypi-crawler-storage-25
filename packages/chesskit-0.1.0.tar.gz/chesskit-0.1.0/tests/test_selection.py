import numpy as np

from chess.selection import chess_kcenter_fisherrao


def random_histograms(n, k):
    H = np.abs(np.random.randn(n, k))
    # normalize each row to sum=1 to avoid zeros
    H = H / (H.sum(axis=1, keepdims=True) + 1e-12)
    return H


def test_chess_kcenter_fisherrao_small():
    H = random_histograms(15, 3)
    sel, hist = chess_kcenter_fisherrao(H, K_select=3, block_size=10, seed=1)
    assert len(sel) == 3
    assert len(hist) == 1 + 2
    assert len(set(sel)) == 3
