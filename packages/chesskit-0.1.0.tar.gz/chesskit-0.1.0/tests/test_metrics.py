import numpy as np

from chess.metrics import (
    fisherrao_distance_block,
    prepare_fisherrao_phi_np,
    auto_radius_from_nn_fisherrao,
)


def test_fisherrao_distance_block_symmetry():
    x = np.array([[0.2, 0.8], [0.5, 0.5]])
    d1 = fisherrao_distance_block(x, x[0])
    d2 = fisherrao_distance_block(x, x[1])
    assert d1.shape == (2,)
    assert d2.shape == (2,)
    assert np.all(d1 >= 0)
    assert np.all(d2 >= 0)


def test_prepare_fisherrao_phi_np():
    H = np.array([[1.0, 1.0], [3.0, 1.0]])
    phi = prepare_fisherrao_phi_np(H, 1e-6)
    assert phi.shape == H.shape
    assert np.all(phi >= 0)


def test_auto_radius_fisherrao_returns_float():
    H = np.abs(np.random.randn(10, 4))
    r = auto_radius_from_nn_fisherrao(H, fr_eps=1e-6, sample_frames=5, batch_ref=5, seed=1)
    assert isinstance(r, float)


def test_auto_radius_approx_mode_returns_float():
    H = np.abs(np.random.randn(12, 4))
    r = auto_radius_from_nn_fisherrao(
        H,
        fr_eps=1e-6,
        sample_frames=6,
        batch_ref=6,
        seed=2,
        knn_mode="approx",
    )
    assert isinstance(r, float)
