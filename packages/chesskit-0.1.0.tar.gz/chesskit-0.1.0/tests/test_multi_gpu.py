"""
Tests for multi-GPU functionality.

These tests verify that multi-GPU features work correctly when
multiple GPUs are available.
"""

import pytest
import numpy as np

pytest.importorskip("torch")
import torch


# Skip all tests if CUDA not available or less than 2 GPUs
pytestmark = pytest.mark.skipif(
    not torch.cuda.is_available() or torch.cuda.device_count() < 2,
    reason="Requires 2+ CUDA GPUs"
)


def test_get_available_gpus():
    """Test GPU detection."""
    from chess.core import get_available_gpus
    
    gpus = get_available_gpus()
    assert isinstance(gpus, list)
    assert len(gpus) >= 2, "Test requires at least 2 GPUs"
    assert all(isinstance(g, int) for g in gpus)


def test_pick_devices_single():
    """Test single-device selection."""
    from chess.core import _pick_devices
    
    device, ids = _pick_devices(multi_gpu=False)
    assert device in ["cuda", "mps", "cpu"]
    assert ids is None


def test_pick_devices_multi():
    """Test multi-device selection."""
    from chess.core import _pick_devices
    
    device, ids = _pick_devices(multi_gpu=True)
    assert device == "cuda"
    assert isinstance(ids, list)
    assert len(ids) >= 2


def test_pick_devices_specific_gpus():
    """Test specific GPU selection."""
    from chess.core import _pick_devices, get_available_gpus
    
    available = get_available_gpus()
    if len(available) < 2:
        pytest.skip("Need at least 2 GPUs")
    
    # Select first 2 GPUs
    device, ids = _pick_devices(multi_gpu=True, gpu_ids=[0, 1])
    assert device == "cuda"
    assert ids == [0, 1]


def test_pick_devices_invalid_gpu():
    """Test error on invalid GPU ID."""
    from chess.core import _pick_devices, get_available_gpus
    
    available = get_available_gpus()
    invalid_id = max(available) + 10
    
    with pytest.raises(ValueError, match="not in available GPUs"):
        _pick_devices(multi_gpu=True, gpu_ids=[invalid_id])


def test_split_data_across_gpus():
    """Test data splitting for multi-GPU."""
    from chess.distributed import split_data_across_gpus
    
    data = np.arange(1000)
    chunks = split_data_across_gpus(data, n_gpus=4)
    
    assert len(chunks) == 4
    assert all(isinstance(c, np.ndarray) for c in chunks)
    
    # Verify chunks reconstruct original
    reconstructed = np.concatenate(chunks)
    np.testing.assert_array_equal(reconstructed, data)


def test_split_data_single_gpu():
    """Test data splitting with single GPU."""
    from chess.distributed import split_data_across_gpus
    
    data = np.arange(100)
    chunks = split_data_across_gpus(data, n_gpus=1)
    
    assert len(chunks) == 1
    np.testing.assert_array_equal(chunks[0], data)


def test_validate_gpu_config_valid():
    """Test GPU config validation with valid settings."""
    from chess.config import validate_gpu_config
    
    cfg = {
        "sevennet": {
            "multi_gpu": True,
            "gpu_ids": [0, 1]
        }
    }
    
    # Should not raise
    validate_gpu_config(cfg)


def test_validate_gpu_config_invalid_ids():
    """Test GPU config validation with invalid IDs."""
    from chess.config import validate_gpu_config
    from chess.core import get_available_gpus
    
    available = get_available_gpus()
    invalid_id = max(available) + 10
    
    cfg = {
        "sevennet": {
            "multi_gpu": True,
            "gpu_ids": [invalid_id]
        }
    }
    
    with pytest.raises(ValueError, match="not in available GPUs"):
        validate_gpu_config(cfg)


def test_validate_gpu_config_no_gpus_warning(caplog):
    """Test GPU config validation when no GPUs and multi_gpu=true."""
    from chess.config import validate_gpu_config
    
    # This test is tricky because we can't actually remove GPUs
    # Instead, test the single-GPU fallback
    cfg = {
        "sevennet": {
            "multi_gpu": False
        }
    }
    
    # Should not raise
    validate_gpu_config(cfg)


def test_merge_results():
    """Test result merging after multi-GPU processing."""
    from chess.distributed import merge_results
    
    results = [
        np.array([[1, 2], [3, 4]]),
        np.array([[5, 6], [7, 8]]),
        np.array([[9, 10]])
    ]
    
    merged = merge_results(results)
    expected = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10]])
    
    np.testing.assert_array_equal(merged, expected)


@pytest.mark.slow
def test_fisherrao_multi_gpu():
    """Test Fisher-Rao distance with multi-GPU."""
    from chess.metrics.chess_metrics import auto_radius_from_nn_fisherrao
    
    # Create dummy BoE histograms
    n_frames = 1000
    n_vocab = 128
    H_boe = np.random.rand(n_frames, n_vocab).astype(np.float32)
    H_boe /= H_boe.sum(axis=1, keepdims=True)  # Normalize
    
    # Test single-GPU
    radius_single = auto_radius_from_nn_fisherrao(
        H_boe,
        fr_eps=1e-12,
        sample_frames=100,
        batch_ref=50,
        seed=42,
        multi_gpu=False
    )
    
    # Test multi-GPU
    radius_multi = auto_radius_from_nn_fisherrao(
        H_boe,
        fr_eps=1e-12,
        sample_frames=100,
        batch_ref=50,
        seed=42,
        multi_gpu=True,
        gpu_ids=[0, 1]
    )
    
    # Results should be similar (not exact due to floating point)
    assert abs(radius_single - radius_multi) < 0.01 * radius_single


@pytest.mark.slow
def test_dataparallel_wrapper():
    """Test DataParallel wrapper."""
    from chess.distributed import DataParallelWrapper
    import torch.nn as nn
    
    # Simple test model
    model = nn.Linear(10, 5)
    
    # Wrap with DataParallel
    wrapper = DataParallelWrapper(model, device_ids=[0, 1])
    
    assert wrapper.device_ids == [0, 1]
    assert wrapper.primary_device == "cuda:0"
    
    # Test forward pass
    x = torch.randn(4, 10).to("cuda:0")
    out = wrapper(x)
    
    assert out.shape == (4, 5)
    assert out.device.type == "cuda"
