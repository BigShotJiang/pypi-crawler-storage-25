import os
import sys

# Ensure `src/` is importable when running tests from repo root
TEST_DIR = os.path.dirname(__file__)
ROOT = os.path.abspath(os.path.join(TEST_DIR, ".."))
SRC = os.path.join(ROOT, "src")
if SRC not in sys.path:
    sys.path.insert(0, SRC)

from quantum_framework_adapter.runner import LocalShimRunner


def test_local_shim_runner_basic():
    runner = LocalShimRunner(n_arms=2, epsilon=0.1, seed=123)
    stats = runner.run(n_steps=100, seed=123)
    assert stats["n_steps"] == 100
    assert "fairness_gap_success_rate" in stats
    assert isinstance(stats["fairness_gap_success_rate"], float)
