"""GA-Work adapter wrapper for the experiments harness.

This module implements `GAWorkRunner`, an adapter that conforms to the
`QuantumRunner` interface and invokes the GA-Work `QuantumExperimentRunner` if
the GA-Work package (`daqr`) is available in the environment or can be
auto-discovered under the workspace.

The adapter is intentionally defensive: if GA-Work is not present it raises
ImportError with actionable guidance rather than modifying external code.
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from .runner import QuantumRunner


def _discover_and_add_daqr_root() -> Optional[str]:
    """Try to discover a local GA-Work `daqr` package and add its parent to
    `sys.path` so `import daqr` will succeed.

    Heuristics used (in order):
    - `GA_WORK_PATH` env var if set
    - look for an ancestor folder named `DataScience` (workspace root) and
      check `Semester4/GA-Work/quantum_project_hub` under it
    - finally, try a user home fallback under `~/DataScience/Semester4/GA-Work/quantum_project_hub`
    """
    # 1) env var
    env_path = os.environ.get("GA_WORK_PATH")
    if env_path:
        candidate = Path(env_path)
        if candidate.exists():
            sys.path.insert(0, str(candidate))
            return str(candidate)

    # 2) look for DataScience ancestor
    p = Path(__file__).resolve()
    workspace_root = None
    for ancestor in p.parents:
        if "DataScience" in ancestor.parts:
            workspace_root = ancestor
            break

    if workspace_root:
        candidate = workspace_root / "Semester4" / "GA-Work" / "quantum_project_hub"
        if candidate.exists():
            sys.path.insert(0, str(candidate))
            return str(candidate)

    # 3) home fallback
    home_candidate = Path.home() / "DataScience" / "Semester4" / "GA-Work" / "quantum_project_hub"
    if home_candidate.exists():
        sys.path.insert(0, str(home_candidate))
        return str(home_candidate)

    return None


@dataclass
class GAWorkRunner(QuantumRunner):
    """Adapter that runs GA-Work `QuantumExperimentRunner`.

    Parameters
    - `ga_work_path`: optional explicit path to the GA-Work `quantum_project_hub`
      folder (parent of `daqr`). If not provided the adapter will attempt
      auto-discovery via `_discover_and_add_daqr_root()`.
    - `testbed_id`: optional integer to select a small preconfigured testbed
      (e.g., 99 is a tiny testbed in GA-Work). If not provided the adapter
      will use the default in GA-Work `ExperimentConfiguration`.
    """

    ga_work_path: Optional[str] = None
    testbed_id: Optional[int] = 99
    frames_count: Optional[int] = None
    base_seed: int = 12345
    enable_progress: bool = False

    def _ensure_daqr_importable(self):
        try:
            # Try direct import first
            import daqr  # type: ignore
            return True
        except Exception:
            # attempt discovery
            added = _discover_and_add_daqr_root()
            if added:
                try:
                    import daqr  # type: ignore
                    return True
                except Exception:
                    raise ImportError(
                        "Found candidate GA-Work path but `import daqr` still failed. "
                        "Ensure GA-Work dependencies (torch, numpy, etc.) are installed and "
                        "that Python package resolution is correct."
                    )
            raise ImportError(
                "GA-Work (`daqr`) not found. Add it as a git submodule at "
                "`externals/ga-work` or set GA_WORK_PATH to the `quantum_project_hub` path."
            )

    def run(self, n_steps: int = 1000, seed: Optional[int] = None, outdir: Optional[str] = None) -> Dict[str, Any]:
        seed_to_use = seed if seed is not None else self.base_seed

        # make sure GA-Work is importable or raise a helpful error
        self._ensure_daqr_importable()

        # import required GA-Work classes
        from daqr.evaluation.experiment_runner import QuantumExperimentRunner  # type: ignore
        from daqr.config.experiment_config import ExperimentConfiguration  # type: ignore

        # create a configuration (small testbed by default)
        config = ExperimentConfiguration()
        if self.testbed_id is not None:
            config.testbed_id = self.testbed_id
        # override frames_count if caller provided it directly
        frames = int(n_steps) if n_steps is not None else (self.frames_count or getattr(config.get_testbed_config() or {}, 'base_frames', 10))

        # instantiate the experiment runner
        runner = QuantumExperimentRunner(id=0, config=config, frames_count=frames, base_seed=seed_to_use, enable_progress=self.enable_progress)

        # run a compact experiment and collect results
        try:
            res = runner.run_experiment(frames_count=frames)
        except Exception as e:
            # Wrap and re-raise with context
            raise RuntimeError(f"GA-Work runner failed: {e}")

        # assemble a lightweight stats dict similar to LocalShimRunner shape
        stats: Dict[str, Any] = {
            "n_steps": frames,
            "seed": seed_to_use,
            "ga_work_results": runner.results,
        }

        # optional: persist artifacts to outdir if requested
        if outdir:
            outdir = os.fspath(outdir)
            os.makedirs(outdir, exist_ok=True)
            with open(os.path.join(outdir, "ga_work_results.json"), "w") as f:
                json.dump(runner.results, f, indent=2)
            with open(os.path.join(outdir, "ga_work_stats.json"), "w") as f:
                json.dump(stats, f, indent=2)

        return stats


__all__ = ["GAWorkRunner"]
