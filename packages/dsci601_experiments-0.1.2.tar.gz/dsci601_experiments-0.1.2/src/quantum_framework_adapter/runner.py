"""Adapter runner interfaces and a LocalShim implementation for reviewer tests.

The LocalShimRunner is intentionally self-contained and deterministic given a
seed. When `externals/ga-work` is added, implement a GAWorkRunner that wraps
the GA-Work entrypoints and conforms to `QuantumRunner`.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
import json
import os
import random
from typing import Any, Dict, List, Optional


class QuantumRunner(ABC):
    """Abstract runner API used by experiments harnesses."""

    @abstractmethod
    def run(self, n_steps: int = 1000, seed: Optional[int] = None, outdir: Optional[str] = None) -> Dict[str, Any]:
        """Execute an experiment run and return aggregated stats (and write artifacts to `outdir`)."""


@dataclass
class LocalShimRunner(QuantumRunner):
    n_arms: int = 2
    epsilon: float = 0.05
    seed: Optional[int] = None

    def _rng(self) -> random.Random:
        return random.Random(self.seed)

    def run(self, n_steps: int = 2000, seed: Optional[int] = None, outdir: Optional[str] = None) -> Dict[str, Any]:
        # allow overriding seed per-run
        seed_to_use = seed if seed is not None else self.seed
        rng = random.Random(seed_to_use)

        # simple synthetic per-group arm probabilities
        p_group0 = [0.8, 0.2][: self.n_arms]
        p_group1 = [0.2, 0.8][: self.n_arms]

        logs: List[Dict[str, Any]] = []
        counts = {0: 0, 1: 0}
        rewards = {0: 0, 1: 0}
        selects = {0: {i: 0 for i in range(self.n_arms)}, 1: {i: 0 for i in range(self.n_arms)}}

        # simple epsilon-greedy state
        values = [0.0] * self.n_arms
        arm_counts = [0] * self.n_arms

        for t in range(int(n_steps)):
            # sample group (biased toward group 0 for realism)
            group = 0 if rng.random() < 0.7 else 1
            # select arm
            if rng.random() < self.epsilon:
                arm = rng.randrange(self.n_arms)
            else:
                arm = max(range(self.n_arms), key=lambda i: (values[i], -i))

            # reward
            p = p_group0[arm] if group == 0 else p_group1[arm]
            reward = 1 if rng.random() < p else 0

            # update
            arm_counts[arm] += 1
            values[arm] += (reward - values[arm]) / arm_counts[arm]

            counts[group] += 1
            rewards[group] += reward
            selects[group][arm] += 1

            logs.append({"t": t, "group": group, "arm": arm, "reward": reward})

        stats: Dict[str, Any] = {"n_steps": int(n_steps), "seed": seed_to_use, "epsilon": float(self.epsilon)}
        for g in (0, 1):
            stats[f"group_{g}_count"] = counts[g]
            stats[f"group_{g}_success_rate"] = (rewards[g] / counts[g]) if counts[g] > 0 else None
            for a in range(self.n_arms):
                stats[f"group_{g}_select_rate_arm{a}"] = selects[g][a] / counts[g] if counts[g] > 0 else None

        if counts[0] > 0 and counts[1] > 0:
            stats["fairness_gap_success_rate"] = stats["group_0_success_rate"] - stats["group_1_success_rate"]
        else:
            stats["fairness_gap_success_rate"] = None

        # write outputs if requested
        if outdir:
            outdir = os.fspath(outdir)
            os.makedirs(outdir, exist_ok=True)
            with open(os.path.join(outdir, "baseline_logs.json"), "w") as f:
                json.dump(logs, f)
            with open(os.path.join(outdir, "baseline_stats.json"), "w") as f:
                json.dump(stats, f, indent=2)

        return stats


if __name__ == "__main__":
    r = LocalShimRunner()
    s = r.run(n_steps=200)
    print(s)
