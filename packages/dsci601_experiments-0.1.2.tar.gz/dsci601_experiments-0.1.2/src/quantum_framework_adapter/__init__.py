"""Quantum framework adapter API.

This module exposes a minimal, stable API for the experiments harness to call
into a concrete runner implementation (either a GA-Work-backed adapter, or a
local shim used for reviewer-friendly runs).
"""

__version__ = "0.1.2"

from .runner import QuantumRunner, LocalShimRunner
from .ga_work_runner import GAWorkRunner

__all__ = ["QuantumRunner", "LocalShimRunner", "GAWorkRunner"]
