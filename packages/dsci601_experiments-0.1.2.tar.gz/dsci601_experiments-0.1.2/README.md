# DSCI601 Experiments

This repository contains the experiments harness and adapter for integrating the
GA-Work quantum framework into the DSCI601 reproducible experiments pipeline.

Structure
- `src/quantum_framework_adapter/` — thin adapter exposing a small, stable API.
- `configs/` — reviewer-friendly example configs (`fast_review.yaml`).
- `tests/` — class-based unit tests (pytest).
- `.github/workflows/ci.yml` — CI pipeline for tests and linting.
- `externals/` — place for git submodules (GA-Work) — see `externals/README.md`.

Quick start (developer)

```bash
# from workspace root
cd Semester5/DSCI601/implementation/dsci601_experiments
# initialize externals if using submodules
# git submodule add <GA_WORK_REPO_URL> externals/ga-work
# install dev deps (optional)
python3 -m pip install -e .[dev]
pytest -q tests/test_runner.py
```

Notes
- The adapter contains a `LocalShimRunner` implementation for reviewer-friendly
  runs when GA-Work is not available; once `externals/ga-work` is added, the
  adapter can be extended to call into GA-Work APIs without copying code.
