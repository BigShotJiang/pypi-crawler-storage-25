# dlubal.api.geo_zone_tool

Python client for the Dlubal GeoZone GraphQL API.

Python `>=3.11` is required.

## Installation

```bash
pip install dlubal.api.geo_zone_tool
```

## Quick Start

```python
from dlubal.api import geo_zone_tool

token = "<your-token>"
geo_zone = geo_zone_tool.GeoZoneTool(token)

locations = geo_zone.get_geo_locations(
    address="Flugplatzweg 6, 14913, Germany",
    language=geo_zone_tool.Language.EN,
)

print(f"Found {len(locations.locations)} location(s)")
```

## Documentation

- User guide: `docs/USER_GUIDE.md`
- Developer guide: `docs/DEVELOPER_GUIDE.md`

## API Overview

`GeoZoneTool` — token-bound wrapper for all services:

| Method | Description |
|---|---|
| `get_geo_locations` | Geocode an address or coordinates |
| `get_user_data` | Fetch user profile and usage info |
| `get_load_zone_standards` | List available standards for a country |
| `find_loadzones` | Search load zones by country code |
| `get_load_zone_characteristics` | Get load zone values for a location |
| `get_load_zone_screenshot` | Get a map screenshot (Base64) |
| `get_load_zone_pdf` | Stream PDF generation progress |
| `get_load_zone_pdf_result` | Get the final PDF (Base64) |
| `get_asce722` | Get ASCE 7-22 seismic design parameters (USGS) |

Enums: `Language`, `LoadZoneType`, `ScreenshotType`, `RiskCategory`, `SiteClass`

## PyPI Description (Markdown)

PyPI project description is rendered from `README.md` because
`pyproject.toml` contains:

```toml
[project]
readme = "README.md"
```

How to publish Markdown description updates:

1. Update `README.md`.
2. Build artifacts:

```bash
python -m pip install -U build twine
python -m build
python -m twine check dist/*
```

3. Upload:
   - TestPyPI: `python -m twine upload --repository testpypi dist/*`
   - PyPI: `python -m twine upload dist/*`

## Errors

The client can raise:

- `ValueError` for invalid input values.
- `TypeError` for invalid enum parameters.
- `RuntimeError` for GraphQL or WebSocket subscription errors.
- `requests.HTTPError` for HTTP response errors.
