from arosics import COREG_LOCAL, DESHIFTER
import numpy as np
from geoarray import GeoArray
import os
import tempfile
from glob import glob

Temp_dir_path = tempfile.gettempdir()
os.makedirs(Temp_dir_path, exist_ok=True)
FILL_VAL = -9999  # fill value for failed tie-point matches (arosics default)


def _gradient_to_temp(img_path, suffix='_grad'):
    """Compute Sobel gradient magnitude of band 1 and save to a temp GeoTIFF.

    Gradient magnitude is used instead of histogram equalisation because
    cross-correlation on gradient images is invariant to spectral contrast
    reversal between bands (e.g. vegetation in NIR vs VNIR).
    """
    import rasterio
    from scipy.ndimage import sobel

    with rasterio.open(img_path) as src:
        data = src.read(1).astype(np.float64)
        profile = src.profile.copy()
        nodata = src.nodata

    gx = sobel(data, axis=1)
    gy = sobel(data, axis=0)
    grad = np.sqrt(gx ** 2 + gy ** 2)

    g_max = grad.max()
    if g_max > 0:
        grad = (grad / g_max) * 10000.0

    if nodata is not None:
        grad[data == nodata] = 0.0
    grad[data == 0] = 0.0

    profile.update({'dtype': 'float32', 'nodata': 0.0, 'count': 1})
    tmp_path = os.path.join(
        Temp_dir_path,
        os.path.basename(img_path).rsplit('.', 1)[0] + suffix + '.tif',
    )
    with rasterio.open(tmp_path, 'w', **profile) as dst:
        dst.write(grad.astype(np.float32), 1)

    return tmp_path


def _baddata_mask_to_temp(img_path, suffix='_badmask'):
    """Generate a bad-data mask GeoTIFF and save to a temp file.

    Convention (arosics): 1 = bad pixel (excluded), 0 = valid pixel.
    A pixel is considered bad if all bands are zero or equal to nodata.
    """
    import rasterio

    with rasterio.open(img_path) as src:
        data = src.read()
        nodata = src.nodata
        profile = src.profile.copy()

    bad = np.all(data == 0, axis=0)
    if nodata is not None:
        bad |= np.all(data == nodata, axis=0)

    profile.update({'dtype': 'uint8', 'nodata': None, 'count': 1})
    tmp_path = os.path.join(
        Temp_dir_path,
        os.path.basename(img_path).rsplit('.', 1)[0] + suffix + '.tif',
    )
    with rasterio.open(tmp_path, 'w', **profile) as dst:
        dst.write(bad.astype(np.uint8), 1)

    return tmp_path


def _thin_control_points(CRL, shift_threshold_m=28.0, thin_factor=2):
    """Spatially thin tie points in low-shift regions to speed up DESHIFTER.

    Points with ABS_SHIFT < shift_threshold_m are thinned by keeping every
    nth point (n = thin_factor) along both axes. High-shift points are kept
    in full to preserve interpolation accuracy where displacements are large.
    Thinned points are marked as OUTLIER=True so that the cached GCPList is
    rebuilt on the next access to coreg_info.

    Parameters
    ----------
    CRL : COREG_LOCAL
        Instance after calculate_spatial_shifts() has been called.
    shift_threshold_m : float
        Displacement threshold in map units (metres). Points below this value
        are candidates for thinning.
    thin_factor : int
        Thinning step. 2 retains every other point in each axis (1/4 density).

    Returns
    -------
    (n_before, n_after) : tuple of int
    """
    if not hasattr(CRL, 'CoRegPoints_table') or CRL.CoRegPoints_table is None:
        return 0, 0

    table = CRL.CoRegPoints_table
    valid_mask = table['X_SHIFT_M'] != FILL_VAL
    if 'OUTLIER' in table.columns:
        valid_mask = valid_mask & ~table['OUTLIER'].astype(bool)
    valid = table[valid_mask]

    n_before = len(valid)
    if n_before == 0 or 'ABS_SHIFT' not in valid.columns:
        return n_before, n_before

    low_mask = valid['ABS_SHIFT'] < shift_threshold_m
    low_pts = valid[low_mask]

    if len(low_pts) == 0:
        return n_before, n_before

    x_unique = np.sort(np.unique(low_pts['X_MAP'].values))
    y_unique = np.sort(np.unique(low_pts['Y_MAP'].values))
    x_to_col = {float(x): i for i, x in enumerate(x_unique)}
    y_to_row = {float(y): i for i, y in enumerate(y_unique)}

    col_idx = low_pts['X_MAP'].map(x_to_col)
    row_idx = low_pts['Y_MAP'].map(y_to_row)
    keep_low = (col_idx % thin_factor == 0) & (row_idx % thin_factor == 0)

    keep_indices = set(valid[~low_mask].index.tolist())
    keep_indices |= set(low_pts[keep_low].index.tolist())
    n_after = len(keep_indices)
    n_removed = n_before - n_after

    if n_removed == 0:
        return n_before, n_after

    thinned_valid_indices = list(set(valid.index.tolist()) - keep_indices)
    if thinned_valid_indices:
        if 'OUTLIER' not in CRL.CoRegPoints_table.columns:
            CRL.CoRegPoints_table['OUTLIER'] = False
        CRL.CoRegPoints_table.loc[thinned_valid_indices, 'OUTLIER'] = True
        # Reset cached GCPList so coreg_info rebuilds from the updated table.
        CRL.tiepoint_grid._GCPList = None
        CRL._coreg_info = None

    print(f"[thinning] tie points: {n_before} -> {n_after} "
          f"(removed {n_removed} low-shift points)")

    return n_before, n_after


def shift_info_calculate(
    ref_path,
    warp_path,
    out_path,
    grid_res=32,
    window_size=(120, 120),
    max_shift=30,
    min_reliability=60,
    tieP_filter_level=2,
    preprocess_gradient=True,
    thin_low_shift=True,
    thin_shift_threshold_m=28.0,
    thin_factor=2,
):
    """Calculate spatial shifts and apply them to the target image.

    Parameters
    ----------
    ref_path : str
        Path to the reference GeoTIFF.
    warp_path : str
        Path to the target GeoTIFF to be corrected.
    out_path : str
        Output path for the corrected GeoTIFF.
    grid_res : int, optional
        Tie-point grid resolution in pixels (default 32).
    window_size : tuple of int, optional
        NCC matching window size in pixels (default (120, 120)).
    max_shift : int, optional
        Maximum allowed shift in pixels (default 30).
    min_reliability : float, optional
        Minimum NCC reliability threshold 0-100 (default 60).
    tieP_filter_level : int, optional
        Tie-point filter level 0-3 (default 2).
    preprocess_gradient : bool, optional
        Use Sobel gradient magnitude images for shift calculation (default True).
    thin_low_shift : bool, optional
        Thin tie points in low-shift regions to speed up DESHIFTER (default True).
    thin_shift_threshold_m : float, optional
        Displacement threshold in metres below which thinning is applied (default 28.0).
    thin_factor : int, optional
        Thinning step size (default 2).
    """
    _tmp_files = []
    match_ref = ref_path
    match_warp = warp_path

    if preprocess_gradient:
        try:
            match_ref = _gradient_to_temp(ref_path, '_ref_grad')
            match_warp = _gradient_to_temp(warp_path, '_warp_grad')
            _tmp_files = [match_ref, match_warp]
            print("[coregistration] Sobel gradient preprocessing done.")
        except Exception as e:
            print(f"[coregistration] Gradient preprocessing failed, using raw images: {e}")
            match_ref = ref_path
            match_warp = warp_path
            _tmp_files = []

    mask_ref_path = _baddata_mask_to_temp(ref_path, '_ref_badmask')
    mask_warp_path = _baddata_mask_to_temp(warp_path, '_warp_badmask')
    _tmp_files += [mask_ref_path, mask_warp_path]

    kwargs = {
        'grid_res': grid_res,
        'window_size': window_size,
        'q': False,
        'fmt_out': 'GTIFF',
        'max_shift': max_shift,
        'min_reliability': min_reliability,
        'tieP_filter_level': tieP_filter_level,
        'outFillVal': FILL_VAL,
        'calc_corners': False,
        'mask_baddata_ref': mask_ref_path,
        'mask_baddata_tgt': mask_warp_path,
    }

    Geo_ref = GeoArray(match_ref)
    Geo_tar = GeoArray(match_warp)

    # path_out=None: let DESHIFTER write the corrected original image instead.
    CRL = COREG_LOCAL(Geo_ref, Geo_tar, path_out=None, **kwargs)
    CRL.calculate_spatial_shifts()

    if thin_low_shift and len(CRL.tiepoint_grid.GCPList) >= 1000:
        _thin_control_points(CRL,
                             shift_threshold_m=thin_shift_threshold_m,
                             thin_factor=thin_factor)

    shift_data = {}
    if hasattr(CRL, 'CoRegPoints_table') and CRL.CoRegPoints_table is not None:
        coreg_table = CRL.CoRegPoints_table
        real_pts = coreg_table[coreg_table['X_SHIFT_M'] != FILL_VAL].copy()
        if 'OUTLIER' in real_pts.columns:
            valid_table = real_pts[real_pts['OUTLIER'] == False].copy()
        else:
            valid_table = real_pts.copy()

        shift_data['coreg_points_table'] = coreg_table
        shift_data['valid_points_table'] = valid_table

        if 'X_SHIFT_PX' in valid_table.columns:
            shift_data['x_shifts_px'] = valid_table['X_SHIFT_PX'].values
            shift_data['y_shifts_px'] = valid_table['Y_SHIFT_PX'].values
        if 'X_SHIFT_M' in valid_table.columns:
            shift_data['x_shifts_m'] = valid_table['X_SHIFT_M'].values
            shift_data['y_shifts_m'] = valid_table['Y_SHIFT_M'].values
        if 'ABS_SHIFT' in valid_table.columns:
            shift_data['abs_shifts'] = valid_table['ABS_SHIFT'].values

    original_im = GeoArray(warp_path)
    coreg_info = CRL.coreg_info
    if coreg_info.get('GCPList'):
        DS = DESHIFTER(original_im, coreg_info,
                       path_out=out_path,
                       fmt_out='GTIFF',
                       align_grids=CRL.align_grids,
                       match_gsd=CRL.match_gsd,
                       resamp_alg=CRL.rspAlg_DS,
                       progress=True,
                       q=False)
        DS.correct_shifts()
        print(f"[coregistration] Done -> {out_path}")
    else:
        print("[coregistration] WARNING: GCPList is empty, shift correction skipped. "
              "Check image quality or adjust parameters.")

    for f in _tmp_files:
        try:
            if os.path.exists(f):
                os.remove(f)
        except Exception:
            pass


def arosics_registration(
    folder_path,
    ref_band=9,
    grid_res=32,
    window_size=(120, 120),
    max_shift=30,
    min_reliability=60,
    tieP_filter_level=2,
    preprocess_gradient=True,
    thin_low_shift=True,
    thin_shift_threshold_m=28.0,
    thin_factor=2,
):
    """Co-register all bands in a folder against a reference band.

    Results are written to ``folder_path + "_registration"``.

    Parameters
    ----------
    folder_path : str
        Directory containing per-band GeoTIFF files named ``*B<n>.TIF``.
    ref_band : int, optional
        Reference band number 1-16 (default 9).
    grid_res : int, optional
        Tie-point grid resolution in pixels (default 32).
    window_size : tuple of int, optional
        NCC matching window size in pixels (default (120, 120)).
    max_shift : int, optional
        Maximum allowed shift in pixels (default 30).
    min_reliability : float, optional
        Minimum NCC reliability threshold 0-100 (default 60).
    tieP_filter_level : int, optional
        Tie-point filter level 0-3 (default 2).
    preprocess_gradient : bool, optional
        Use Sobel gradient magnitude images for shift calculation (default True).
    thin_low_shift : bool, optional
        Thin tie points in low-shift regions (default True).
    thin_shift_threshold_m : float, optional
        Displacement threshold in metres for thinning (default 28.0).
    thin_factor : int, optional
        Thinning step size (default 2).
    """
    save_path = folder_path + '_registration'
    os.makedirs(save_path, exist_ok=True)
    reference_path = glob(os.path.join(folder_path, f'*B{ref_band}.TIF'))[0]
    handle_idx = list(range(1, 17))
    handle_idx.remove(ref_band)
    for idx in handle_idx:
        print(f"[coregistration] Processing band B{idx} ...")
        target_path = glob(os.path.join(folder_path, f'*B{idx}.TIF'))[0]
        output_path = os.path.join(save_path, os.path.basename(target_path))
        shift_info_calculate(
            reference_path,
            target_path,
            output_path,
            grid_res=grid_res,
            window_size=window_size,
            max_shift=max_shift,
            min_reliability=min_reliability,
            tieP_filter_level=tieP_filter_level,
            preprocess_gradient=preprocess_gradient,
            thin_low_shift=thin_low_shift,
            thin_shift_threshold_m=thin_shift_threshold_m,
            thin_factor=thin_factor,
        )
    print(f"[coregistration] All bands done -> {save_path}")