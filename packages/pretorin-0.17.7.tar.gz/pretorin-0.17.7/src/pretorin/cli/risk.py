"""Risk-management CLI commands for Pretorin."""

from __future__ import annotations

import asyncio

import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from pretorin.cli.output import is_json_mode, print_json
from pretorin.client import PretorianClient

console = Console()

app = typer.Typer(
    name="risk",
    help="System-scoped risk register: list/seed risks, attach artifact links, set mitigation.",
    no_args_is_help=True,
)

link_app = typer.Typer(
    name="link",
    help="Attach or remove artifact links on a risk (controls, evidence, findings, vendors).",
    no_args_is_help=True,
)
app.add_typer(link_app, name="link")

library_app = typer.Typer(
    name="library",
    help="Browse the org-level risk library.",
    no_args_is_help=True,
)
app.add_typer(library_app, name="library")

VALID_TREATMENTS = {"mitigate", "accept", "transfer", "avoid"}
VALID_LINK_TYPES = {"contributes_to_risk", "mitigates_risk", "evidence_of_risk"}


def _get_client() -> PretorianClient:
    return PretorianClient()


@app.command("list")
def risk_list(
    system_id: str = typer.Argument(..., help="System ID or name"),
    category: str = typer.Option(None, "--category", help="Filter by risk category"),
    risk_level: str = typer.Option(None, "--risk-level", help="Filter by risk level"),
    status: str = typer.Option(None, "--status", help="Filter by status"),
) -> None:
    """List risks for a system."""

    async def _run() -> None:
        client = _get_client()
        risks = await client.list_risks(
            system_id,
            category=category,
            risk_level=risk_level,
            status=status,
        )
        if is_json_mode():
            print_json({"risks": risks, "total": len(risks)})
            return
        if not risks:
            rprint("[dim]No risks found.[/dim]")
            return
        table = Table(title=f"Risks for {system_id}")
        table.add_column("ID", style="dim")
        table.add_column("Title", style="bold")
        table.add_column("Category")
        table.add_column("Level")
        table.add_column("Status")
        table.add_column("Treatment")
        for r in risks:
            table.add_row(
                str(r.get("id", "")),
                r.get("title", ""),
                r.get("category", ""),
                r.get("risk_level", ""),
                r.get("status", ""),
                r.get("treatment", ""),
            )
        console.print(table)

    asyncio.run(_run())


@app.command("show")
def risk_show(
    system_id: str = typer.Argument(..., help="System ID or name"),
    risk_id: str = typer.Argument(..., help="Risk ID"),
) -> None:
    """Show a single risk with its artifact links."""

    async def _run() -> None:
        client = _get_client()
        result = await client.get_risk(system_id, risk_id)
        if is_json_mode():
            print_json(result)
            return
        rprint(f"[bold]{result.get('title', '')}[/bold]")
        rprint(f"  ID: {result.get('id', '')}")
        rprint(f"  Category: {result.get('category', '')}")
        rprint(f"  Level: {result.get('risk_level', '')}")
        rprint(f"  Status: {result.get('status', '')}")
        if result.get("treatment"):
            rprint(f"  Treatment: {result['treatment']}")
        if result.get("treatment_plan"):
            rprint(f"  Plan: {result['treatment_plan']}")
        if result.get("treatment_due_date"):
            rprint(f"  Due: {result['treatment_due_date']}")
        links = result.get("artifact_links") or []
        rprint(f"  Links: {len(links)}")
        for link in links:
            target = (
                link.get("control_id")
                or link.get("evidence_id")
                or link.get("finding_id")
                or link.get("vendor_id")
                or link.get("monitoring_event_id")
                or link.get("id", "")
            )
            rprint(f"    - {link.get('link_type', '?')}: {target}")

    asyncio.run(_run())


@app.command("create")
def risk_create(
    system_id: str = typer.Argument(..., help="System ID or name"),
    title: str = typer.Option(..., "--title", help="Risk title"),
    category: str = typer.Option(..., "--category", help="Risk category"),
    description: str = typer.Option(None, "--description", "-d", help="Risk description"),
    cia_category: str = typer.Option(
        None,
        "--cia-category",
        help="CIA category (confidentiality/integrity/availability)",
    ),
    likelihood: str = typer.Option(None, "--likelihood", help="Likelihood rating"),
    impact: str = typer.Option(None, "--impact", help="Impact rating"),
    owner_id: str = typer.Option(None, "--owner-id", help="Owner user ID"),
    treatment: str = typer.Option(None, "--treatment", help="mitigate | accept | transfer | avoid"),
    treatment_plan: str = typer.Option(None, "--treatment-plan", help="Mitigation plan text"),
    treatment_due_date: str = typer.Option(None, "--treatment-due-date", help="Due date (ISO format)"),
    review_frequency_days: int = typer.Option(None, "--review-frequency-days", help="Review cadence in days"),
    suggested_control_families: list[str] = typer.Option(
        None,
        "--suggested-control-family",
        help="Repeat per family ID. Used for auto-linking when --framework is supplied.",
    ),
    framework_id: str = typer.Option(
        None,
        "--framework",
        help="Framework ID — required for control auto-linking.",
    ),
) -> None:
    """Create a custom risk. Auto-links controls if --framework + --suggested-control-family given."""
    if treatment is not None and treatment not in VALID_TREATMENTS:
        rprint(f"[red]Invalid treatment: {treatment}. Must be one of: {', '.join(sorted(VALID_TREATMENTS))}[/red]")
        raise typer.Exit(1)

    async def _run() -> None:
        client = _get_client()
        result = await client.create_risk(
            system_id,
            title=title,
            category=category,
            description=description,
            cia_category=cia_category,
            likelihood=likelihood,
            impact=impact,
            owner_id=owner_id,
            treatment=treatment,
            treatment_plan=treatment_plan,
            treatment_due_date=treatment_due_date,
            review_frequency_days=review_frequency_days,
            suggested_control_families=list(suggested_control_families) if suggested_control_families else None,
            framework_id=framework_id,
        )
        if is_json_mode():
            print_json(result)
            return
        rprint(f"[green]Risk created:[/green] {result.get('id', '')} - {result.get('title', '')}")
        links = result.get("artifact_links") or []
        if links:
            rprint(f"  Auto-linked {len(links)} artifact(s).")

    asyncio.run(_run())


@app.command("seed")
def risk_seed(
    system_id: str = typer.Argument(..., help="System ID or name"),
    framework_id: str = typer.Option(..., "--framework", help="Framework ID to score and auto-link against"),
    template_ids: list[str] = typer.Option(
        ...,
        "--template-id",
        help="Library template ID. Repeat for multiple.",
    ),
) -> None:
    """Bulk-seed risks from library templates."""

    async def _run() -> None:
        client = _get_client()
        seeded = await client.seed_risks(system_id, list(template_ids), framework_id)
        if is_json_mode():
            print_json({"risks": seeded, "total": len(seeded)})
            return
        rprint(f"[green]Seeded {len(seeded)} risk(s) from library.[/green]")
        for r in seeded:
            rprint(f"  - {r.get('id', '')}: {r.get('title', '')}")

    asyncio.run(_run())


@app.command("update")
def risk_update(
    system_id: str = typer.Argument(..., help="System ID or name"),
    risk_id: str = typer.Argument(..., help="Risk ID"),
    title: str = typer.Option(None, "--title", help="New title"),
    description: str = typer.Option(None, "--description", "-d", help="New description"),
    category: str = typer.Option(None, "--category", help="New category"),
    cia_category: str = typer.Option(None, "--cia-category", help="New CIA category"),
    likelihood: str = typer.Option(None, "--likelihood", help="New likelihood"),
    impact: str = typer.Option(None, "--impact", help="New impact"),
    owner_id: str = typer.Option(None, "--owner-id", help="New owner user ID"),
    status: str = typer.Option(None, "--status", help="New status"),
    treatment: str = typer.Option(None, "--treatment", help="mitigate | accept | transfer | avoid"),
    treatment_plan: str = typer.Option(None, "--treatment-plan", help="New mitigation plan"),
    treatment_due_date: str = typer.Option(None, "--treatment-due-date", help="New due date (ISO)"),
    review_frequency_days: int = typer.Option(None, "--review-frequency-days", help="New review cadence"),
) -> None:
    """Update a risk. This is the mitigation surface — set treatment + plan + due date here."""
    if treatment is not None and treatment not in VALID_TREATMENTS:
        rprint(f"[red]Invalid treatment: {treatment}. Must be one of: {', '.join(sorted(VALID_TREATMENTS))}[/red]")
        raise typer.Exit(1)

    fields: dict[str, object] = {}
    for key, value in (
        ("title", title),
        ("description", description),
        ("category", category),
        ("cia_category", cia_category),
        ("likelihood", likelihood),
        ("impact", impact),
        ("owner_id", owner_id),
        ("status", status),
        ("treatment", treatment),
        ("treatment_plan", treatment_plan),
        ("treatment_due_date", treatment_due_date),
        ("review_frequency_days", review_frequency_days),
    ):
        if value is not None:
            fields[key] = value

    if not fields:
        rprint("[yellow]No fields to update. Pass at least one option.[/yellow]")
        raise typer.Exit(1)

    async def _run() -> None:
        client = _get_client()
        result = await client.update_risk(system_id, risk_id, **fields)
        if is_json_mode():
            print_json(result)
            return
        rprint(f"[green]Risk updated:[/green] {result.get('id', '')} - {result.get('title', '')}")

    asyncio.run(_run())


@app.command("refresh-summary")
def risk_refresh_summary(
    system_id: str = typer.Argument(..., help="System ID or name"),
    risk_id: str = typer.Argument(..., help="Risk ID"),
) -> None:
    """Re-score the risk and trigger a best-effort AI summary refresh."""

    async def _run() -> None:
        client = _get_client()
        result = await client.refresh_risk_summary(system_id, risk_id)
        if is_json_mode():
            print_json(result)
            return
        rprint(f"[green]Risk re-scored:[/green] {result.get('id', '')}")
        ai_at = result.get("ai_summary_generated_at")
        if ai_at:
            rprint(f"  AI summary updated at: {ai_at}")
        else:
            rprint("  [dim]AI summary not updated (best-effort; check ai_summary_generated_at).[/dim]")

    asyncio.run(_run())


@link_app.command("add")
def risk_link_add(
    system_id: str = typer.Argument(..., help="System ID or name"),
    risk_id: str = typer.Argument(..., help="Risk ID"),
    link_type: str = typer.Option(
        ...,
        "--link-type",
        help="contributes_to_risk | mitigates_risk | evidence_of_risk",
    ),
    control_id: str = typer.Option(None, "--control", help="Control ID"),
    evidence_id: str = typer.Option(None, "--evidence", help="Evidence ID"),
    finding_id: str = typer.Option(None, "--finding", help="Finding ID"),
    vendor_id: str = typer.Option(None, "--vendor", help="Vendor ID"),
    monitoring_event_id: str = typer.Option(None, "--monitoring-event", help="Monitoring event ID"),
    framework_id: str = typer.Option(None, "--framework", help="Framework ID (required for control links)"),
) -> None:
    """Attach an artifact link to a risk.

    Pass exactly one of --control / --evidence / --finding / --vendor / --monitoring-event.
    """
    if link_type not in VALID_LINK_TYPES:
        rprint(f"[red]Invalid --link-type: {link_type}. Must be one of: {', '.join(sorted(VALID_LINK_TYPES))}[/red]")
        raise typer.Exit(1)

    selected = [
        name
        for name, val in (
            ("control", control_id),
            ("evidence", evidence_id),
            ("finding", finding_id),
            ("vendor", vendor_id),
            ("monitoring_event", monitoring_event_id),
        )
        if val is not None
    ]
    if len(selected) != 1:
        rprint("[red]Pass exactly one of --control / --evidence / --finding / --vendor / --monitoring-event.[/red]")
        raise typer.Exit(1)

    if control_id is not None and not framework_id:
        rprint("[red]--framework is required when linking a control.[/red]")
        raise typer.Exit(1)

    if control_id is not None:
        from pretorin.utils import normalize_control_id

        control_id = normalize_control_id(control_id)

    async def _run() -> None:
        client = _get_client()
        result = await client.add_risk_link(
            system_id,
            risk_id,
            link_type=link_type,
            control_id=control_id,
            evidence_id=evidence_id,
            finding_id=finding_id,
            vendor_id=vendor_id,
            monitoring_event_id=monitoring_event_id,
            framework_id=framework_id,
        )
        if is_json_mode():
            print_json(result)
            return
        rprint(f"[green]Link created:[/green] {result.get('id', '')} ({link_type})")

    asyncio.run(_run())


@link_app.command("rm")
def risk_link_rm(
    system_id: str = typer.Argument(..., help="System ID or name"),
    risk_id: str = typer.Argument(..., help="Risk ID"),
    link_id: str = typer.Argument(..., help="Link ID"),
) -> None:
    """Remove an artifact link from a risk."""

    async def _run() -> None:
        client = _get_client()
        await client.remove_risk_link(system_id, risk_id, link_id)
        rprint(f"[green]Link {link_id} removed.[/green]")

    asyncio.run(_run())


@library_app.command("list")
def risk_library_list(
    category: str = typer.Option(None, "--category", help="Filter by category"),
) -> None:
    """List risk-library templates available to the org."""

    async def _run() -> None:
        client = _get_client()
        templates = await client.list_risk_library(category=category)
        if is_json_mode():
            print_json({"templates": templates, "total": len(templates)})
            return
        if not templates:
            rprint("[dim]No risk-library templates found.[/dim]")
            return
        table = Table(title="Risk Library")
        table.add_column("ID", style="dim")
        table.add_column("Scenario", style="bold")
        table.add_column("Category")
        table.add_column("CIA")
        for t in templates:
            table.add_row(
                str(t.get("id", "")),
                t.get("scenario", "") or t.get("title", ""),
                t.get("category", ""),
                t.get("cia_category", ""),
            )
        console.print(table)

    asyncio.run(_run())
