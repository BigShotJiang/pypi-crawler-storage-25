"""Coverage tests for src/pretorin/cli/risk.py.

Targets all risk commands: list, show, create, seed, update, refresh-summary,
link add, link rm, library list — in normal and JSON modes plus validation paths.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest
from typer.testing import CliRunner

from pretorin.cli.main import app
from pretorin.cli.output import set_json_mode

runner = CliRunner()


@pytest.fixture(autouse=True)
def _reset_json_mode():
    set_json_mode(False)
    yield
    set_json_mode(False)


def _run_with_mock_client(args: list[str], client: AsyncMock) -> object:
    with patch("pretorin.cli.risk._get_client", return_value=client):
        return runner.invoke(app, args)


def _base_client() -> AsyncMock:
    client = AsyncMock()
    client.is_configured = True
    return client


# =============================================================================
# risk list
# =============================================================================


def test_risk_list_normal_with_items() -> None:
    client = _base_client()
    client.list_risks = AsyncMock(
        return_value=[
            {
                "id": "r-1",
                "title": "Data exfiltration",
                "category": "confidentiality",
                "risk_level": "high",
                "status": "open",
                "treatment": "mitigate",
            },
        ]
    )
    result = _run_with_mock_client(["risk", "list", "sys-1"], client)
    assert result.exit_code == 0, result.output
    assert "Data exfiltration" in result.output
    client.list_risks.assert_awaited_once_with("sys-1", category=None, risk_level=None, status=None)


def test_risk_list_empty() -> None:
    client = _base_client()
    client.list_risks = AsyncMock(return_value=[])
    result = _run_with_mock_client(["risk", "list", "sys-1"], client)
    assert result.exit_code == 0
    assert "No risks found" in result.output


def test_risk_list_json_mode_with_filters() -> None:
    client = _base_client()
    client.list_risks = AsyncMock(return_value=[{"id": "r-1", "title": "X"}])
    result = _run_with_mock_client(
        [
            "--json",
            "risk",
            "list",
            "sys-1",
            "--category",
            "availability",
            "--risk-level",
            "high",
            "--status",
            "open",
        ],
        client,
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["total"] == 1
    client.list_risks.assert_awaited_once_with("sys-1", category="availability", risk_level="high", status="open")


# =============================================================================
# risk show
# =============================================================================


def test_risk_show_normal_mode() -> None:
    client = _base_client()
    client.get_risk = AsyncMock(
        return_value={
            "id": "r-1",
            "title": "Test risk",
            "category": "integrity",
            "risk_level": "medium",
            "status": "open",
            "treatment": "mitigate",
            "treatment_plan": "Roll out 2FA",
            "treatment_due_date": "2026-06-01",
            "artifact_links": [
                {"id": "l-1", "link_type": "mitigates_risk", "control_id": "AC-2"},
            ],
        }
    )
    result = _run_with_mock_client(["risk", "show", "sys-1", "r-1"], client)
    assert result.exit_code == 0, result.output
    assert "Test risk" in result.output
    assert "Roll out 2FA" in result.output
    assert "AC-2" in result.output


def test_risk_show_json_mode() -> None:
    client = _base_client()
    data = {"id": "r-1", "title": "Test", "artifact_links": []}
    client.get_risk = AsyncMock(return_value=data)
    result = _run_with_mock_client(["--json", "risk", "show", "sys-1", "r-1"], client)
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["id"] == "r-1"


# =============================================================================
# risk create
# =============================================================================


def test_risk_create_normal_mode() -> None:
    client = _base_client()
    client.create_risk = AsyncMock(return_value={"id": "r-1", "title": "X", "artifact_links": []})
    result = _run_with_mock_client(
        [
            "risk",
            "create",
            "sys-1",
            "--title",
            "X",
            "--category",
            "availability",
        ],
        client,
    )
    assert result.exit_code == 0, result.output
    assert "Risk created" in result.output


def test_risk_create_with_mitigation_and_autolink() -> None:
    client = _base_client()
    client.create_risk = AsyncMock(return_value={"id": "r-1", "title": "X", "artifact_links": [{"id": "l-1"}]})
    result = _run_with_mock_client(
        [
            "--json",
            "risk",
            "create",
            "sys-1",
            "--title",
            "X",
            "--category",
            "availability",
            "--treatment",
            "mitigate",
            "--treatment-plan",
            "Plan text",
            "--treatment-due-date",
            "2026-06-01",
            "--framework",
            "nist-800-53-r5",
            "--suggested-control-family",
            "AC",
            "--suggested-control-family",
            "AU",
        ],
        client,
    )
    assert result.exit_code == 0, result.output
    client.create_risk.assert_awaited_once()
    kwargs = client.create_risk.await_args.kwargs
    assert kwargs["treatment"] == "mitigate"
    assert kwargs["treatment_plan"] == "Plan text"
    assert kwargs["framework_id"] == "nist-800-53-r5"
    assert kwargs["suggested_control_families"] == ["AC", "AU"]


def test_risk_create_invalid_treatment() -> None:
    client = _base_client()
    result = _run_with_mock_client(
        [
            "risk",
            "create",
            "sys-1",
            "--title",
            "X",
            "--category",
            "availability",
            "--treatment",
            "bogus",
        ],
        client,
    )
    assert result.exit_code == 1
    assert "Invalid treatment" in result.output


# =============================================================================
# risk seed
# =============================================================================


def test_risk_seed_normal_mode() -> None:
    client = _base_client()
    client.seed_risks = AsyncMock(
        return_value=[
            {"id": "r-1", "title": "Phishing"},
            {"id": "r-2", "title": "Insider"},
        ]
    )
    result = _run_with_mock_client(
        [
            "risk",
            "seed",
            "sys-1",
            "--framework",
            "nist-800-53-r5",
            "--template-id",
            "tpl-1",
            "--template-id",
            "tpl-2",
        ],
        client,
    )
    assert result.exit_code == 0, result.output
    assert "Seeded 2 risk" in result.output
    client.seed_risks.assert_awaited_once_with("sys-1", ["tpl-1", "tpl-2"], "nist-800-53-r5")


# =============================================================================
# risk update
# =============================================================================


def test_risk_update_treatment_path() -> None:
    client = _base_client()
    client.update_risk = AsyncMock(return_value={"id": "r-1", "title": "X"})
    result = _run_with_mock_client(
        [
            "risk",
            "update",
            "sys-1",
            "r-1",
            "--treatment",
            "accept",
            "--treatment-plan",
            "Accepted by CISO",
        ],
        client,
    )
    assert result.exit_code == 0, result.output
    client.update_risk.assert_awaited_once_with("sys-1", "r-1", treatment="accept", treatment_plan="Accepted by CISO")


def test_risk_update_no_fields() -> None:
    client = _base_client()
    result = _run_with_mock_client(["risk", "update", "sys-1", "r-1"], client)
    assert result.exit_code == 1
    assert "No fields to update" in result.output


def test_risk_update_invalid_treatment() -> None:
    client = _base_client()
    result = _run_with_mock_client(["risk", "update", "sys-1", "r-1", "--treatment", "bogus"], client)
    assert result.exit_code == 1
    assert "Invalid treatment" in result.output


# =============================================================================
# risk refresh-summary
# =============================================================================


def test_risk_refresh_summary_with_ai() -> None:
    client = _base_client()
    client.refresh_risk_summary = AsyncMock(
        return_value={"id": "r-1", "ai_summary_generated_at": "2026-05-06T12:00:00Z"}
    )
    result = _run_with_mock_client(["risk", "refresh-summary", "sys-1", "r-1"], client)
    assert result.exit_code == 0, result.output
    assert "AI summary updated" in result.output


def test_risk_refresh_summary_ai_skipped() -> None:
    client = _base_client()
    client.refresh_risk_summary = AsyncMock(return_value={"id": "r-1"})
    result = _run_with_mock_client(["risk", "refresh-summary", "sys-1", "r-1"], client)
    assert result.exit_code == 0, result.output
    assert "AI summary not updated" in result.output


# =============================================================================
# risk link add / rm
# =============================================================================


def test_risk_link_add_control() -> None:
    client = _base_client()
    client.add_risk_link = AsyncMock(return_value={"id": "l-1"})
    result = _run_with_mock_client(
        [
            "risk",
            "link",
            "add",
            "sys-1",
            "r-1",
            "--link-type",
            "mitigates_risk",
            "--control",
            "AC-2",
            "--framework",
            "nist-800-53-r5",
        ],
        client,
    )
    assert result.exit_code == 0, result.output
    client.add_risk_link.assert_awaited_once_with(
        "sys-1",
        "r-1",
        link_type="mitigates_risk",
        control_id="ac-02",
        evidence_id=None,
        finding_id=None,
        vendor_id=None,
        monitoring_event_id=None,
        framework_id="nist-800-53-r5",
    )


def test_risk_link_add_control_without_framework_fails() -> None:
    client = _base_client()
    result = _run_with_mock_client(
        [
            "risk",
            "link",
            "add",
            "sys-1",
            "r-1",
            "--link-type",
            "mitigates_risk",
            "--control",
            "AC-2",
        ],
        client,
    )
    assert result.exit_code == 1
    assert "framework is required" in result.output.lower()


def test_risk_link_add_invalid_link_type() -> None:
    client = _base_client()
    result = _run_with_mock_client(
        [
            "risk",
            "link",
            "add",
            "sys-1",
            "r-1",
            "--link-type",
            "bogus",
            "--control",
            "AC-2",
        ],
        client,
    )
    assert result.exit_code == 1
    assert "Invalid --link-type" in result.output


def test_risk_link_add_no_artifact() -> None:
    client = _base_client()
    result = _run_with_mock_client(
        [
            "risk",
            "link",
            "add",
            "sys-1",
            "r-1",
            "--link-type",
            "mitigates_risk",
        ],
        client,
    )
    assert result.exit_code == 1
    assert "exactly one" in result.output


def test_risk_link_add_too_many_artifacts() -> None:
    client = _base_client()
    result = _run_with_mock_client(
        [
            "risk",
            "link",
            "add",
            "sys-1",
            "r-1",
            "--link-type",
            "mitigates_risk",
            "--control",
            "AC-2",
            "--evidence",
            "e-1",
        ],
        client,
    )
    assert result.exit_code == 1
    assert "exactly one" in result.output


def test_risk_link_rm() -> None:
    client = _base_client()
    client.remove_risk_link = AsyncMock(return_value=None)
    result = _run_with_mock_client(["risk", "link", "rm", "sys-1", "r-1", "l-1"], client)
    assert result.exit_code == 0, result.output
    assert "removed" in result.output
    client.remove_risk_link.assert_awaited_once_with("sys-1", "r-1", "l-1")


# =============================================================================
# risk library list
# =============================================================================


def test_risk_library_list_with_items() -> None:
    client = _base_client()
    client.list_risk_library = AsyncMock(
        return_value=[
            {
                "id": "tpl-1",
                "scenario": "Phishing campaign against ops team",
                "category": "Access control",
                "cia_category": "Confidentiality",
            }
        ]
    )
    result = _run_with_mock_client(["risk", "library", "list"], client)
    assert result.exit_code == 0, result.output
    assert "Phishing" in result.output


def test_risk_library_list_empty() -> None:
    client = _base_client()
    client.list_risk_library = AsyncMock(return_value=[])
    result = _run_with_mock_client(["risk", "library", "list"], client)
    assert result.exit_code == 0
    assert "No risk-library templates found" in result.output


def test_risk_library_list_json_with_filter() -> None:
    client = _base_client()
    client.list_risk_library = AsyncMock(return_value=[{"id": "tpl-1"}])
    result = _run_with_mock_client(["--json", "risk", "library", "list", "--category", "availability"], client)
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["total"] == 1
    client.list_risk_library.assert_awaited_once_with(category="availability")
