"""Regression tests for the scope-q-answer and policy-q-answer recipes.

Both recipes shipped with a broken import (``redact_secrets`` instead of
``redact``) that meant every call failed at script-import time, so the
mandatory secret-redaction step in the ``scope-question`` and
``policy-question`` workflows silently never ran. See issue #103.

These tests exercise each recipe through the real loader + registry +
script runner — the same path an external agent hits over MCP — so any
regression in the import shape, the tuple unpack, or the output keys
shows up here.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from pretorin.mcp.handlers.recipe import (
    handle_end_recipe,
    handle_run_recipe_script,
    handle_start_recipe,
)
from pretorin.recipes import loader as loader_module
from pretorin.recipes.context import reset_default_store
from pretorin.recipes.loader import clear_cache
from pretorin.recipes.registry import script_tool_name

# Synthetic AWS access key id assembled at runtime so the file source
# itself doesn't trip GitHub's push-protection scanner. Same trick as
# tests/recipes/test_code_evidence_capture.py.
_SYNTHETIC_AWS_AKID = "AKIA" + "ABCDE0123456789Z"


@pytest.fixture(autouse=True)
def _isolate_state() -> None:
    clear_cache()
    reset_default_store()
    yield
    clear_cache()
    reset_default_store()


@pytest.fixture
def real_builtin_recipes(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Use the real built-in recipes shipped under src/pretorin/recipes/_recipes/.

    Override only the user folder so a contributor's local recipes don't
    pollute the test.
    """
    monkeypatch.setattr(loader_module, "_user_recipes_root", lambda: tmp_path / "no-user-dir")


def _extract(response: Any) -> dict[str, Any]:
    if isinstance(response, list):
        text = response[0].text
    else:
        text = response.content[0].text
    if not text.strip().startswith("{") and not text.strip().startswith("["):
        return {"error": text}
    return json.loads(text)


@pytest.mark.parametrize(
    ("recipe_id", "version"),
    [
        ("scope-q-answer", "0.1.0"),
        ("policy-q-answer", "0.1.0"),
    ],
)
@pytest.mark.asyncio
async def test_redact_answer_script_runs(real_builtin_recipes: None, recipe_id: str, version: str) -> None:
    """Calling the redact_answer tool returns the documented shape.

    Before the fix this raised ``cannot import name 'redact_secrets' from
    'pretorin.evidence.redact'`` at script-import time.
    """
    start = await handle_start_recipe(
        client=MagicMock(),
        arguments={"recipe_id": recipe_id, "recipe_version": version},
    )
    context_id = _extract(start)["context_id"]

    answer_with_secret = f"Our deploy script sets AWS_KEY = '{_SYNTHETIC_AWS_AKID}'."

    response = await handle_run_recipe_script(
        client=MagicMock(),
        arguments={"answer_text": answer_with_secret},
        tool_name=script_tool_name(recipe_id, "redact_answer"),
    )
    payload = _extract(response)

    assert "error" not in payload, payload
    assert set(payload.keys()) == {"redacted", "redaction_summary"}

    # The synthetic key must not survive the redactor.
    assert _SYNTHETIC_AWS_AKID not in payload["redacted"]
    assert "[REDACTED:aws_access_key]" in payload["redacted"]

    summary = payload["redaction_summary"]
    assert summary["secrets"] >= 1
    assert summary["pii"] == 0
    assert summary["custom"] == 0
    assert summary["details"] == {"aws_access_key": 1}

    # Cleanup recipe context.
    await handle_end_recipe(client=MagicMock(), arguments={"context_id": context_id})


@pytest.mark.parametrize(
    "recipe_id",
    ["scope-q-answer", "policy-q-answer"],
)
def test_redact_answer_script_imports(recipe_id: str) -> None:
    """The script module imports cleanly — the precise failure mode of #103.

    This is the loudest, lowest-mock regression: it directly exercises
    the import statement that was broken, without any MCP plumbing.
    Fails on master before the fix with ``ImportError: cannot import
    name 'redact_secrets' from 'pretorin.evidence.redact'``.
    """
    import importlib.util

    script_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "pretorin"
        / "recipes"
        / "_recipes"
        / recipe_id
        / "scripts"
        / "redact_answer.py"
    )
    assert script_path.is_file(), f"recipe script missing at {script_path}"

    spec = importlib.util.spec_from_file_location(f"_test_{recipe_id.replace('-', '_')}_redact_answer", script_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    assert hasattr(module, "run"), "redact_answer.py must export an async run()"
