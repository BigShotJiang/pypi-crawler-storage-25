"""Coverage tests for src/pretorin/mcp/handlers/risks.py."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from mcp.types import CallToolResult

from pretorin.mcp.handlers.risks import (
    handle_create_risk,
    handle_get_risk,
    handle_link_risk_artifact,
    handle_list_risk_library,
    handle_list_risks,
    handle_refresh_risk_summary,
    handle_seed_risks,
    handle_unlink_risk_artifact,
    handle_update_risk,
)


def _make_client(**overrides) -> AsyncMock:
    client = AsyncMock()
    client.is_configured = True
    # Default list_systems for resolve_system_id name/ID lookup
    client.list_systems = AsyncMock(return_value=[{"id": "sys-1", "name": "Test System"}])
    for attr, val in overrides.items():
        setattr(client, attr, AsyncMock(return_value=val))
    return client


def _is_error(result) -> bool:
    return isinstance(result, CallToolResult) and result.isError is True


# ---------------------------------------------------------------------------
# list / get
# ---------------------------------------------------------------------------


class TestHandleListRisks:
    @pytest.mark.anyio
    async def test_success(self):
        client = _make_client(list_risks=[{"id": "r1"}])
        result = await handle_list_risks(client, {"system_id": "sys-1"})
        client.list_risks.assert_awaited_once_with("sys-1", category=None, risk_level=None, status=None)
        assert not _is_error(result)
        assert '"total": 1' in result[0].text

    @pytest.mark.anyio
    async def test_with_filters(self):
        client = _make_client(list_risks=[])
        await handle_list_risks(
            client,
            {
                "system_id": "sys-1",
                "category": "availability",
                "risk_level": "high",
                "status": "open",
            },
        )
        client.list_risks.assert_awaited_once_with("sys-1", category="availability", risk_level="high", status="open")

    @pytest.mark.anyio
    async def test_missing_system_id(self):
        client = _make_client()
        result = await handle_list_risks(client, {})
        assert _is_error(result)


class TestHandleGetRisk:
    @pytest.mark.anyio
    async def test_success(self):
        client = _make_client(get_risk={"id": "r1"})
        result = await handle_get_risk(client, {"system_id": "sys-1", "risk_id": "r1"})
        client.get_risk.assert_awaited_once_with("sys-1", "r1")
        assert not _is_error(result)

    @pytest.mark.anyio
    async def test_missing_params(self):
        client = _make_client()
        result = await handle_get_risk(client, {"system_id": "sys-1"})
        assert _is_error(result)


# ---------------------------------------------------------------------------
# create / seed / update
# ---------------------------------------------------------------------------


class TestHandleCreateRisk:
    @pytest.mark.anyio
    async def test_success_minimal(self):
        client = _make_client(create_risk={"id": "r1"})
        result = await handle_create_risk(
            client,
            {"system_id": "sys-1", "title": "Phishing", "category": "confidentiality"},
        )
        client.create_risk.assert_awaited_once()
        kwargs = client.create_risk.await_args.kwargs
        assert kwargs["title"] == "Phishing"
        assert kwargs["category"] == "confidentiality"
        assert kwargs["treatment"] is None
        assert not _is_error(result)

    @pytest.mark.anyio
    async def test_success_with_mitigation(self):
        client = _make_client(create_risk={"id": "r1"})
        await handle_create_risk(
            client,
            {
                "system_id": "sys-1",
                "title": "Phishing",
                "category": "confidentiality",
                "treatment": "mitigate",
                "treatment_plan": "Roll out 2FA",
                "treatment_due_date": "2026-06-01",
                "framework_id": "nist-800-53-r5",
                "suggested_control_families": ["AC", "AU"],
            },
        )
        kwargs = client.create_risk.await_args.kwargs
        assert kwargs["treatment"] == "mitigate"
        assert kwargs["framework_id"] == "nist-800-53-r5"
        assert kwargs["suggested_control_families"] == ["AC", "AU"]

    @pytest.mark.anyio
    async def test_missing_required(self):
        client = _make_client()
        result = await handle_create_risk(client, {"system_id": "sys-1"})
        assert _is_error(result)

    @pytest.mark.anyio
    async def test_invalid_treatment_rejected(self):
        client = _make_client()
        result = await handle_create_risk(
            client,
            {
                "system_id": "sys-1",
                "title": "X",
                "category": "y",
                "treatment": "bogus",
            },
        )
        assert _is_error(result)
        client.create_risk.assert_not_awaited()


class TestHandleSeedRisks:
    @pytest.mark.anyio
    async def test_success(self):
        client = _make_client(seed_risks=[{"id": "r1"}, {"id": "r2"}])
        result = await handle_seed_risks(
            client,
            {
                "system_id": "sys-1",
                "template_ids": ["t1", "t2"],
                "framework_id": "fw-1",
            },
        )
        client.seed_risks.assert_awaited_once_with("sys-1", ["t1", "t2"], "fw-1")
        assert not _is_error(result)
        assert '"total": 2' in result[0].text

    @pytest.mark.anyio
    async def test_empty_template_ids(self):
        client = _make_client()
        result = await handle_seed_risks(
            client,
            {"system_id": "sys-1", "template_ids": [], "framework_id": "fw-1"},
        )
        assert _is_error(result)

    @pytest.mark.anyio
    async def test_missing_framework(self):
        client = _make_client()
        result = await handle_seed_risks(
            client,
            {"system_id": "sys-1", "template_ids": ["t1"]},
        )
        assert _is_error(result)


class TestHandleUpdateRisk:
    @pytest.mark.anyio
    async def test_treatment_update(self):
        client = _make_client(update_risk={"id": "r1"})
        result = await handle_update_risk(
            client,
            {
                "system_id": "sys-1",
                "risk_id": "r1",
                "treatment": "accept",
                "treatment_plan": "Accepted by CISO",
            },
        )
        client.update_risk.assert_awaited_once_with(
            "sys-1",
            "r1",
            treatment="accept",
            treatment_plan="Accepted by CISO",
        )
        assert not _is_error(result)

    @pytest.mark.anyio
    async def test_no_fields_errors(self):
        client = _make_client(update_risk={"id": "r1"})
        result = await handle_update_risk(client, {"system_id": "sys-1", "risk_id": "r1"})
        client.update_risk.assert_not_awaited()
        assert _is_error(result)

    @pytest.mark.anyio
    async def test_missing_required(self):
        client = _make_client()
        result = await handle_update_risk(client, {"system_id": "sys-1"})
        assert _is_error(result)


# ---------------------------------------------------------------------------
# links
# ---------------------------------------------------------------------------


class TestHandleLinkRiskArtifact:
    @pytest.mark.anyio
    async def test_success_control(self):
        client = _make_client(add_risk_link={"id": "l1"})
        result = await handle_link_risk_artifact(
            client,
            {
                "system_id": "sys-1",
                "risk_id": "r1",
                "link_type": "mitigates_risk",
                "control_id": "AC-2",
                "framework_id": "fw-1",
            },
        )
        client.add_risk_link.assert_awaited_once()
        kwargs = client.add_risk_link.await_args.kwargs
        assert kwargs["link_type"] == "mitigates_risk"
        # Control id should be normalized
        assert kwargs["control_id"] == "ac-02"
        assert not _is_error(result)

    @pytest.mark.anyio
    async def test_invalid_link_type(self):
        client = _make_client()
        result = await handle_link_risk_artifact(
            client,
            {
                "system_id": "sys-1",
                "risk_id": "r1",
                "link_type": "bogus",
                "control_id": "AC-2",
                "framework_id": "fw-1",
            },
        )
        assert _is_error(result)

    @pytest.mark.anyio
    async def test_control_link_without_framework_errors(self):
        client = _make_client()
        result = await handle_link_risk_artifact(
            client,
            {
                "system_id": "sys-1",
                "risk_id": "r1",
                "link_type": "mitigates_risk",
                "control_id": "AC-2",
            },
        )
        assert _is_error(result)
        client.add_risk_link.assert_not_awaited()

    @pytest.mark.anyio
    async def test_empty_string_artifact_rejected(self):
        client = _make_client()
        result = await handle_link_risk_artifact(
            client,
            {
                "system_id": "sys-1",
                "risk_id": "r1",
                "link_type": "mitigates_risk",
                "evidence_id": "",
            },
        )
        assert _is_error(result)
        client.add_risk_link.assert_not_awaited()

    @pytest.mark.anyio
    async def test_no_artifact_id(self):
        client = _make_client()
        result = await handle_link_risk_artifact(
            client,
            {
                "system_id": "sys-1",
                "risk_id": "r1",
                "link_type": "mitigates_risk",
            },
        )
        assert _is_error(result)

    @pytest.mark.anyio
    async def test_too_many_artifact_ids(self):
        client = _make_client()
        result = await handle_link_risk_artifact(
            client,
            {
                "system_id": "sys-1",
                "risk_id": "r1",
                "link_type": "mitigates_risk",
                "control_id": "AC-2",
                "evidence_id": "e-1",
            },
        )
        assert _is_error(result)

    @pytest.mark.anyio
    async def test_missing_link_type(self):
        client = _make_client()
        result = await handle_link_risk_artifact(
            client,
            {"system_id": "sys-1", "risk_id": "r1", "control_id": "AC-2"},
        )
        assert _is_error(result)


class TestHandleUnlinkRiskArtifact:
    @pytest.mark.anyio
    async def test_success(self):
        client = _make_client()
        result = await handle_unlink_risk_artifact(
            client,
            {"system_id": "sys-1", "risk_id": "r1", "link_id": "l-1"},
        )
        client.remove_risk_link.assert_awaited_once_with("sys-1", "r1", "l-1")
        assert not _is_error(result)
        assert '"removed"' in result[0].text

    @pytest.mark.anyio
    async def test_missing_link_id(self):
        client = _make_client()
        result = await handle_unlink_risk_artifact(client, {"system_id": "sys-1", "risk_id": "r1"})
        assert _is_error(result)


# ---------------------------------------------------------------------------
# refresh-summary / library
# ---------------------------------------------------------------------------


class TestHandleRefreshRiskSummary:
    @pytest.mark.anyio
    async def test_success(self):
        client = _make_client(refresh_risk_summary={"id": "r1", "ai_summary_generated_at": "2026-05-06T12:00Z"})
        result = await handle_refresh_risk_summary(client, {"system_id": "sys-1", "risk_id": "r1"})
        client.refresh_risk_summary.assert_awaited_once_with("sys-1", "r1")
        assert not _is_error(result)

    @pytest.mark.anyio
    async def test_missing_params(self):
        client = _make_client()
        result = await handle_refresh_risk_summary(client, {"system_id": "sys-1"})
        assert _is_error(result)


class TestHandleListRiskLibrary:
    @pytest.mark.anyio
    async def test_success(self):
        client = _make_client(list_risk_library=[{"id": "tpl-1"}])
        result = await handle_list_risk_library(client, {})
        client.list_risk_library.assert_awaited_once_with(category=None)
        assert not _is_error(result)
        assert '"total": 1' in result[0].text

    @pytest.mark.anyio
    async def test_with_category(self):
        client = _make_client(list_risk_library=[])
        await handle_list_risk_library(client, {"category": "availability"})
        client.list_risk_library.assert_awaited_once_with(category="availability")
