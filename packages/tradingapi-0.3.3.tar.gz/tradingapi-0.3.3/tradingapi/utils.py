import datetime as dt
import fcntl
import glob
import json
import math
import os
import re
import secrets
import sys
import threading
import time
import traceback
import uuid
from collections import OrderedDict
from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple, Union, cast, Sequence

import numpy as np
import pandas as pd
import redis
from chameli.dateutils import calc_fractional_business_days, parse_datetime, safe_datetime_compare
from chameli.europeanoptions import BlackScholesDelta, BlackScholesIV
from requests import Session
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from .broker_base import BrokerBase, HistoricalData, Order, OrderInfo, OrderStatus, Position, Price
from .config import get_config, get_fno_freeze_limit
from .exceptions import (
    SymbolError,
    TradingAPIError,
    ValidationError,
    DataError,
    RedisError,
    MarketDataError,
    OrderError,
    PnLError,
    CommissionError,
    create_error_context,
)
from .error_handling import retry_on_error, safe_execute, log_execution_time, handle_broker_errors, validate_inputs
from . import trading_logger
from .globals import get_tradingapi_now
from .market_data_exchanges import broker_supports_market_data_exchange

r = redis.Redis(db=1, encoding="utf-8", decode_responses=True)


def json_serializer_default(obj):
    """Convert numpy/pandas types to native Python for JSON serialization.
    Use as default= in json.dumps when logging Order or other objects that may contain numpy types.
    """
    if hasattr(obj, "item"):  # numpy scalar (int64, float64, etc.)
        return obj.item()
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if type(obj).__name__ == "bool_" and type(obj).__module__.startswith("numpy"):
        return bool(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if pd.isna(obj):
        return None
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


# Enhanced exception handler with structured logging
def my_handler(typ, value, trace):
    context = create_error_context(
        exception_type=typ.__name__, exception_value=str(value), traceback="".join(traceback.format_tb(trace))
    )
    trading_logger.log_error(f"Uncaught exception: {typ.__name__}", value, context)


sys.excepthook = my_handler
config = get_config()
mds_history = redis.Redis(db=1, encoding="utf-8", decode_responses=True)
pubsub = mds_history.pubsub()
hds_redis = redis.Redis(db=3, encoding="utf-8", decode_responses=True)
_hds_rr_state = [0]  # round-robin counter for broker selection in get_historical_data

empty_trades = pd.DataFrame(
    {
        "symbol": pd.Series(dtype="object"),
        "side": pd.Series(dtype="object"),
        "entry_time": pd.Series(dtype="string"),
        "entry_quantity": pd.Series(dtype="float64"),
        "entry_price": pd.Series(dtype="float64"),
        "exit_time": pd.Series(dtype="string"),
        "exit_quantity": pd.Series(dtype="float64"),
        "exit_price": pd.Series(dtype="float64"),
        "commission": pd.Series(dtype="int64"),
        "int_order_id": pd.Series(dtype="object"),
        "entry_keys": pd.Series(dtype="object"),
        "exit_keys": pd.Series(dtype="object"),
        "additional_info": pd.Series(dtype="object"),
        "realized_pnl": pd.Series(dtype="float64"),
        "gross_pnl": pd.Series(dtype="float64"),
        "mtm": pd.Series(dtype="float64"),
        "pnl": pd.Series(dtype="float64"),
    }
)

empty_md = {
    "date": pd.Series(dtype="datetime64[ns]"),
    "open": pd.Series(dtype="float64"),
    "high": pd.Series(dtype="float64"),
    "low": pd.Series(dtype="float64"),
    "close": pd.Series(dtype="float64"),
    "volume": pd.Series(dtype="int64"),
}
empty_md = pd.DataFrame(empty_md)


def hget_with_default(brok: BrokerBase, hash_name: str, key: str, default_value):
    value = brok.redis_o.hget(hash_name, key)
    if value is None:
        return default_value
    else:
        return value


def get_all_strategy_names(redis_db) -> set[str]:
    """
    Returns a set of strategies used within the database of the trading system.
    :return:
    """
    out = set()
    if redis_db is not None:
        # Use scan() with cursor 0 instead of scan_iter() to avoid cursor state issues
        cursor = 0
        while True:
            cursor, keys = redis_db.scan(cursor, match="[A-Z]*_[0-9]*", count=1000)
            for key in keys:
                out.add(key.split("_")[0])
            if cursor == 0:
                break
    return out


def set_starting_internal_ids_int(redis_db) -> dict[str, int]:
    """Sets the internal_ids for each strategy. New orders start from the values defined by this function"""
    out: dict[str, int] = {}
    strategies = get_all_strategy_names(redis_db)
    for s in strategies:
        # Use scan() with cursor 0 instead of scan_iter() to avoid cursor state issues
        pattern = s + "_" + "*"
        cursor = 0
        while True:
            cursor, keys = redis_db.scan(cursor, match=pattern, count=1000)
            for key in keys:
                # Expected order key format is <STRATEGY>_<INT>_*; ignore any
                # non-conforming keys (e.g. symbol strings containing "_OPT_").
                parts = key.split("_")
                if len(parts) < 2 or not parts[1].isdigit():
                    trading_logger.log_debug(f"Skipping non-internal-id key while scanning strategy {s}: {key}")
                    continue

                key_id = int(parts[1])
                if out.get(s, 1) <= key_id:
                    out[s] = key_id + 1
            if cursor == 0:
                break
    trading_logger.log_debug(f"Starting internal ids : {out} ")
    return out


def publish_trades_to_redis(
    broker: BrokerBase,
    strategy_name: str,
    publish: bool = True,
    channel: Optional[str] = None,
    trades_out: Optional[list[Any]] = None,
) -> int:
    """
    Publish relevant trades for a strategy to Redis so downstream consumers
    (e.g. order_manager, dashboards) can consume a consistent trade feed.

    This helper centralizes the \"PnL \u2192 Redis\" publishing logic so all strategies
    can use the same mechanism instead of reimplementing it.

    Args:
        broker: Broker instance (e.g. FivePaisa, Shoonya). Must expose ``redis_o`` for publishing.
        strategy_name: Strategy name as used in internal order IDs (e.g. \"TCS01\", \"SCALPING01\").
        publish: If True, publish to Redis; if False, skip publishing (e.g. paper mode or testing).
        channel: Optional Redis channel name. Defaults to ``strategy_name`` when not provided.
        trades_out: Optional list to populate with filtered trades DataFrame when publish=False.

    Returns:
        int: Number of trade rows published, or 0 if nothing was published.
    """
    try:
        today = dt.date.today().strftime("%Y-%m-%d")
        trades = get_pnl_table(broker, strategy_name, refresh_status=True)

        if trades is None or trades.empty:
            trading_logger.log_info(
                f"No trades found for {strategy_name} to publish",
                {"strategy_name": strategy_name},
            )
            return 0

        # Filter to relevant trades: today's trades + open positions from earlier days
        # This matches the logic used by pnl_publisher._initial_load
        relevant_trades = trades
        try:
            if "entry_time" in trades.columns and "exit_time" in trades.columns:
                # Today's trades (entered or exited today)
                # Use date boundaries for comparison (start of today to end of today)
                today_start = dt.datetime.combine(dt.date.today(), dt.time.min)
                today_end = dt.datetime.combine(dt.date.today(), dt.time.max)
                entry_today = safe_datetime_compare(trades.entry_time, today_start, ">=") & safe_datetime_compare(
                    trades.entry_time, today_end, "<="
                )
                exit_today = safe_datetime_compare(trades.exit_time, today_start, ">=") & safe_datetime_compare(
                    trades.exit_time, today_end, "<="
                )
                today_trades = entry_today | exit_today

                # Open trades from earlier days (entered before today, still have open position)
                entry_before_today = safe_datetime_compare(trades.entry_time, today_start, "<")

                # Check if position is still open
                if "entry_quantity" in trades.columns and "exit_quantity" in trades.columns:
                    # Primary check: actual open position quantity
                    has_open_position = trades["entry_quantity"] + trades["exit_quantity"] != 0
                    # Fallback check: exit_time status (empty string '', None, 0, or >= today)
                    exit_time_normalized = trades.exit_time.fillna("").astype(str).replace("NaT", "").replace("nan", "")
                    exit_time_empty = (
                        (exit_time_normalized == "") | (exit_time_normalized == "0") | (trades.exit_time == 0)
                    )
                    # A trade is still open if it has no exit recorded OR has open quantity
                    # (don't consider trades with exit times as "still open", even if exit was today)
                    exit_time_still_open = exit_time_empty
                    still_open = has_open_position | exit_time_still_open
                else:
                    # Fallback if quantity columns missing
                    exit_time_normalized = trades.exit_time.fillna("").astype(str).replace("NaT", "").replace("nan", "")
                    exit_time_empty = (
                        (exit_time_normalized == "") | (exit_time_normalized == "0") | (trades.exit_time == 0)
                    )
                    # A trade is still open if it has no exit recorded
                    # (don't consider trades with exit times as "still open", even if exit was today)
                    still_open = exit_time_empty

                open_from_earlier = entry_before_today & still_open

                # Combine: today's trades OR open trades from earlier days
                relevant_mask = today_trades | open_from_earlier
                relevant_trades = trades[relevant_mask]
        except Exception as e:
            trading_logger.log_warning(
                f"Error filtering trades for {strategy_name}: {e}",
                {"strategy_name": strategy_name, "error": str(e)},
            )
            relevant_trades = trades

        if not publish or relevant_trades.empty:
            if not publish:
                trading_logger.log_debug(
                    f"Skipping publish for {strategy_name} (publish=False)",
                    {"strategy_name": strategy_name},
                )
                # Populate trades_out if provided
                if trades_out is not None:
                    trades_out.append(relevant_trades)
            else:
                trading_logger.log_info(
                    f"No relevant trades to publish for {strategy_name} (relevant_trades is empty)",
                    {"strategy_name": strategy_name, "today": today},
                )
            return 0

        publish_channel = channel or strategy_name

        try:
            pnl_json = relevant_trades.to_json(orient="split")
            broker.redis_o.publish(publish_channel, pnl_json)
            trading_logger.log_info(
                f"Published {len(relevant_trades)} relevant trades for {strategy_name} to Redis",
                {
                    "strategy_name": strategy_name,
                    "channel": publish_channel,
                    "trades_count": len(relevant_trades),
                    "publish": publish,
                },
            )
            return len(relevant_trades)
        except Exception as e:
            trading_logger.log_warning(
                f"Failed to publish trades to Redis for {strategy_name}: {e}",
                {
                    "strategy_name": strategy_name,
                    "channel": publish_channel,
                    "error": str(e),
                },
            )
            return 0

    except Exception as e:
        trading_logger.log_error(
            f"Error publishing trades to Redis for {strategy_name}: {e}",
            e,
            {"strategy_name": strategy_name, "error": str(e)},
            exc_info=True,
        )
        return 0


def _safe_parse_json_or_dict(json_str):
    """
    Safely parse a string that could be either JSON or Python dict string.

    Args:
        json_str (str): String that could be JSON or Python dict

    Returns:
        dict: Parsed dictionary

    Raises:
        DataError: If the string cannot be parsed as either JSON or dict
    """
    if not json_str or not json_str.strip():
        return {}

    try:
        # First try to parse as JSON
        return json.loads(json_str)
    except json.JSONDecodeError:
        try:
            # If JSON fails, try to parse as Python dict string
            import ast

            # Handle common problematic values before parsing
            # Replace bare 'nan' with 'float("nan")' for ast.literal_eval
            processed_str = json_str.replace("'nan'", "float('nan')")
            processed_str = processed_str.replace("nan", "float('nan')")

            # Also handle other common problematic values
            processed_str = processed_str.replace("'inf'", "float('inf')")
            processed_str = processed_str.replace("'-inf'", "float('-inf')")
            processed_str = processed_str.replace("inf", "float('inf')")
            processed_str = processed_str.replace("-inf", "float('-inf')")

            # Handle bare identifiers that should be floats
            import re

            processed_str = re.sub(r"\bnan\b", "float('nan')", processed_str)
            processed_str = re.sub(r"\binf\b", "float('inf')", processed_str)
            processed_str = re.sub(r"\b-inf\b", "float('-inf')", processed_str)

            return ast.literal_eval(processed_str)
        except (ValueError, SyntaxError) as e:
            # If ast.literal_eval still fails, try a more robust approach
            try:
                # Use eval with restricted globals for safety
                safe_globals = {
                    "True": True,
                    "False": False,
                    "None": None,
                    "float": float,
                    "int": int,
                    "str": str,
                    "nan": float("nan"),
                    "inf": float("inf"),
                }
                return eval(json_str, safe_globals, {})
            except Exception as eval_error:
                parsed_loose_info = _parse_loose_additional_info(json_str)
                if parsed_loose_info is not None:
                    return parsed_loose_info
                raise DataError(
                    f"Cannot parse as JSON or Python dict: {str(e)}",
                    {
                        "input_preview": str(json_str)[:200],
                        "input_length": len(str(json_str)),
                        "ast_error": str(e),
                        "eval_error": str(eval_error),
                    },
                )


def _parse_loose_additional_info(info_str):
    info_str = str(info_str).strip()
    if not info_str:
        return {}

    import shlex

    def _coerce_value(value):
        lower_value = value.lower()
        if lower_value == "true":
            return True
        if lower_value == "false":
            return False
        if lower_value == "none":
            return None
        try:
            if any(ch in value for ch in [".", "e", "E"]):
                return float(value)
            return int(value)
        except ValueError:
            return value

    try:
        tokens = shlex.split(info_str)
    except ValueError:
        tokens = info_str.split()

    parsed = {}
    message_tokens = []
    for token in tokens:
        token_parts = [part for part in token.split(",") if part]
        consumed_key_value = False
        for part in token_parts:
            if "=" not in part:
                if not consumed_key_value:
                    message_tokens.append(part)
                continue
            key, value = part.split("=", 1)
            if not key:
                continue
            parsed[key] = _coerce_value(value)
            consumed_key_value = True
        if "=" not in token and not token_parts:
            message_tokens.append(token)

    if message_tokens:
        parsed["message"] = " ".join(message_tokens)

    return parsed or {"message": info_str}


@log_execution_time
def _merge_additional_info(old_info, new_info):
    """
    Merge two JSON strings. Duplicate keys in new_info will be renamed
    with a suffix '_1', '_2', etc., to avoid conflicts.

    Args:
        old_info (str): JSON string representing the original information.
        new_info (str): JSON string representing the new information.

    Returns:
        str: Merged JSON string.

    Raises:
        DataError: If either input is not a valid JSON string.
    """
    try:
        # Parse the JSON strings into dictionaries using the safe parser
        old_dict = _safe_parse_json_or_dict(old_info)
        new_dict = _safe_parse_json_or_dict(new_info)

        if not isinstance(old_dict, dict) or not isinstance(new_dict, dict):
            raise DataError(
                "Both inputs must be JSON objects (dictionaries).",
                {
                    "old_info_type": type(old_info).__name__,
                    "new_info_type": type(new_info).__name__,
                    "old_info": str(old_info)[:100],
                    "new_info": str(new_info)[:100],
                },
            )

        # Create a merged dictionary
        merged_dict = old_dict.copy()

        for key, value in new_dict.items():
            if key not in merged_dict:
                # If the key is unique, add it
                merged_dict[key] = value
            else:
                # If key exists, generate a new key with a numeric suffix
                suffix = 1
                new_key = f"{key}_{suffix}"
                while new_key in merged_dict:
                    suffix += 1
                    new_key = f"{key}_{suffix}"
                merged_dict[new_key] = value

        # Convert the merged dictionary back to JSON string
        return json.dumps(merged_dict)

    except DataError as e:
        # Re-raise DataError from the helper function with additional context
        context = create_error_context(
            old_info_preview=str(old_info)[:200] if old_info else None,
            new_info_preview=str(new_info)[:200] if new_info else None,
            old_info_length=len(str(old_info)) if old_info else 0,
            new_info_length=len(str(new_info)) if new_info else 0,
            original_error=str(e),
        )
        raise DataError(f"Error parsing additional info: {str(e)}", context)
    except Exception as e:
        context = create_error_context(
            old_info_type=type(old_info).__name__, new_info_type=type(new_info).__name__, error_type=type(e).__name__
        )
        raise DataError(f"Error merging additional info: {str(e)}", context)


def is_not_int_order_id(s):
    return not bool(re.match(r"^.*_\d+$", s))


def needs_refresh_status_from_redis(broker: BrokerBase, pnl_df: pd.DataFrame) -> bool:
    """
    Returns True if any trade's entry/exit order price in Redis is 0.
    """
    for _, row in pnl_df.iterrows():
        for order_id_col in ["entry_internal_orderid", "exit_internal_orderid"]:
            order_id = row.get(order_id_col)
            if order_id:
                redis_key = f"order:{order_id}"
                price = cast(str, broker.redis_o.hget(redis_key, "price"))
                if price is not None and float(price) == 0.0:
                    return True
    return False


@log_execution_time
@validate_inputs(
    strategy=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    start_time=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    end_time=lambda x: x is None or (isinstance(x, str) and len(x.strip()) > 0),
    market_close_time=lambda x: isinstance(x, str) and len(x.strip()) > 0,
)
def get_pnl_table(
    broker: BrokerBase,
    strategy: str,
    start_time: str = "1970-01-01 00:00:00",
    end_time: Optional[str] = None,
    refresh_status=False,
    market_close_time="15:30:00",
    eod=False,
) -> pd.DataFrame:
    """Get P&L table for a specified strategy with enhanced error handling.

    Args:
        broker (BrokerBase): broker instance
        strategy (str): strategy name
        start_time (str, optional): Start Date for strategy pnl. Defaults to "1970-01-01 00:00:00".
        end_time (str, optional): End Date for strategy pnl. Defaults to current time when function is called.
        refresh_status (bool, optional): Whether to refresh order status. Defaults to False.
        market_close_time (str, optional): closing time for option expiry, defaults to "15:30:00"
        eod (bool, optional): Whether this is end-of-day processing. Defaults to False.

    Returns:
        pd.DataFrame: strategy pnl

    Raises:
        ValidationError: If input parameters are invalid
        RedisError: If there are issues with Redis operations
        PnLError: If there are issues with P&L calculations
    """
    # Set default end_time inside the function body (evaluated at call time, not import time)
    if end_time is None:
        current_time = get_tradingapi_now()
        # For EOD processing, add a small buffer to account for processing time
        if eod:
            current_time = current_time + dt.timedelta(minutes=2)
        end_time = current_time.strftime("%Y-%m-%d %H:%M:%S")

    try:
        int_order_ids = []
        trades = []

        # Get all internal order IDs for the strategy
        # Use scan_iter with match pattern to find all order IDs
        pattern = strategy + "_" + "*"
        cursor = 0
        scan_count = 0
        while True:
            cursor, keys = cast(tuple[Any, Any], broker.redis_o.scan(cursor, match=pattern, count=1000))
            int_order_ids.extend(keys)
            scan_count += len(keys)
            if cursor == 0:
                break

        if not int_order_ids:
            trading_logger.log_info(
                f"No internal order IDs found for strategy: {strategy}",
                {"strategy": strategy, "start_time": start_time, "end_time": end_time},
            )
            return empty_trades

        # Sort numerically by extracting the number after the underscore
        def extract_order_number(order_id):
            try:
                # Extract number after last underscore (e.g., "SCALPING01_1949" -> 1949)
                parts = order_id.rsplit("_", 1)
                if len(parts) == 2:
                    return int(parts[1])
                return 0
            except (ValueError, IndexError):
                return 0

        int_order_ids.sort(key=extract_order_number)

        for int_order_id in int_order_ids:
            try:
                if is_not_int_order_id(int_order_id):
                    continue

                symbol = cast(str, broker.redis_o.hget(int_order_id, "long_symbol"))
                if not symbol:
                    trading_logger.log_warning(
                        f"No symbol found for internal order ID: {int_order_id}",
                        {"int_order_id": int_order_id, "strategy": strategy},
                    )
                    continue

                entry_keys = hget_with_default(broker, int_order_id, "entry_keys", "").split()  # type: ignore  # type: ignore
                exit_keys = hget_with_default(broker, int_order_id, "exit_keys", "").split()  # type: ignore
                additional_info_entry = ""
                additional_info_exit = ""
                entry_order_type = ""

                if len(entry_keys) == 0:
                    trading_logger.log_error(
                        f"No entry key found for int_order_id: {int_order_id}",
                        None,
                        {"int_order_id": int_order_id, "strategy": strategy, "symbol": symbol},
                    )
                    continue

                # Process entry keys
                entry_time: Union[dt.datetime, str, None] = None
                side: str = ""
                if len(entry_keys) > 0:
                    try:
                        order_1 = Order(**cast(dict[str, Any], broker.redis_o.hgetall(entry_keys[0])))
                        entry_order_type = order_1.order_type
                        side = order_1.order_type if "?" not in symbol else "BUY"
                        try:
                            entry_time = parse_datetime(order_1.remote_order_id[:-2])
                        except (ValueError, TypeError):
                            entry_time = None
                        # Handle case where parsing failed
                        if entry_time is None:
                            entry_time = ""
                        for ek in entry_keys:
                            additional_info_entry = _merge_additional_info(
                                additional_info_entry, hget_with_default(broker, ek, "additional_info", "")
                            )
                    except Exception as e:
                        trading_logger.log_error(
                            f"Error processing entry keys for {int_order_id}",
                            e,
                            {"int_order_id": int_order_id, "symbol": symbol, "entry_keys": entry_keys},
                        )
                        continue

                # Process exit keys
                if len(exit_keys) > 0:
                    try:
                        order_1 = Order(**cast(dict[str, Any], broker.redis_o.hgetall(exit_keys[-1])))
                        try:
                            exit_time = parse_datetime(order_1.remote_order_id[:-2])
                        except (ValueError, TypeError):
                            exit_time = None
                        # Handle case where parsing failed
                        # This can happen when exit order status is UNDEFINED and remote_order_id is malformed
                        if exit_time is None:
                            exit_time = ""
                        for ek in exit_keys:
                            additional_info_exit = _merge_additional_info(
                                additional_info_exit, hget_with_default(broker, ek, "additional_info", "")
                            )
                    except Exception as e:
                        trading_logger.log_error(
                            f"Error processing exit keys for {int_order_id}",
                            e,
                            {"int_order_id": int_order_id, "symbol": symbol, "exit_keys": exit_keys},
                        )
                        exit_time = ""
                else:
                    exit_time = ""

                additional_info = _merge_additional_info(additional_info_entry, additional_info_exit)
                entry_quantity = 0
                entry_price: float = 0.0
                exit_quantity = 0
                exit_price: float = 0.0
                commission = 0
                effective_symbol = symbol

                # Refresh status if requested
                if refresh_status:
                    try:
                        for entry_key in entry_keys:
                            order = Order(**cast(dict[str, Any], broker.redis_o.hgetall(entry_key)))
                            broker_order_id = order.broker_order_id
                            update_order_status(broker, int_order_id, broker_order_id, eod=eod)
                    except Exception as e:
                        trading_logger.log_error(
                            f"Error refreshing entry status for {int_order_id}",
                            e,
                            {"int_order_id": int_order_id, "entry_keys": entry_keys, "exit_keys": exit_keys},
                        )

                # Calculate entry position
                try:
                    entry_position = get_open_position_by_order(broker, int_order_id, exclude_zero=True, side=["entry"])
                    if "?" in symbol and entry_position:
                        try:
                            expected_legs = parse_combo_symbol(symbol)
                        except Exception:
                            expected_legs = {}
                        fully_filled = bool(expected_legs) and all(
                            (entry_position.get(leg_symbol) is not None)
                            and (entry_position[leg_symbol].size != 0)
                            and (
                                math.copysign(1, entry_position[leg_symbol].size)
                                == math.copysign(1, expected_qty)
                            )
                            for leg_symbol, expected_qty in expected_legs.items()
                        )
                        if not fully_filled:
                            derived_symbol = _build_effective_symbol_from_positions(entry_position)
                            if derived_symbol:
                                effective_symbol = derived_symbol
                    if "?" not in effective_symbol and entry_order_type:
                        side = entry_order_type
                    base_position = parse_combo_symbol(effective_symbol)
                    position_combo_info = calculate_extra_combo_positions(entry_position, base_position)
                    entry_quantity = position_combo_info.get("total_in_progress", 0)
                    entry_price = (
                        sum(position.value for position in entry_position.values()) / entry_quantity
                        if entry_quantity != 0
                        else 0.0
                    )
                except Exception as e:
                    trading_logger.log_error(
                        f"Error calculating entry position for {int_order_id}",
                        e,
                        {"int_order_id": int_order_id, "symbol": symbol},
                    )
                    continue

                # Refresh exit status if requested
                if refresh_status:
                    try:
                        for exit_key in exit_keys:
                            order = Order(**cast(dict[str, Any], broker.redis_o.hgetall(exit_key)))
                            broker_order_id = order.broker_order_id
                            update_order_status(broker, int_order_id, broker_order_id, eod=eod)
                    except Exception as e:
                        trading_logger.log_error(
                            f"Error refreshing exit status for {int_order_id}",
                            e,
                            {"int_order_id": int_order_id, "exit_keys": exit_keys},
                        )

                # Calculate exit position
                # Only calculate if exit_keys exist - if empty, set defaults and continue (don't skip trade)
                if len(exit_keys) > 0:
                    try:
                        exit_position = get_open_position_by_order(
                            broker, int_order_id, exclude_zero=True, side=["exit"]
                        )
                        base_position = parse_combo_symbol(effective_symbol)
                        position_combo_info = calculate_extra_combo_positions(exit_position, base_position)
                        exit_quantity = position_combo_info.get("total_in_progress", 0)
                        exit_price = (
                            sum(position.value for position in exit_position.values()) / exit_quantity
                            if exit_quantity != 0
                            else 0
                        )
                    except Exception as e:
                        trading_logger.log_error(
                            f"Error calculating exit position for {int_order_id}",
                            e,
                            {"int_order_id": int_order_id, "symbol": symbol, "exit_keys": exit_keys},
                        )
                        # Don't skip trade - set defaults instead so trade is still included in results
                        # This is important when exit_keys are being written but order data isn't ready yet
                        exit_quantity = 0
                        exit_price = 0.0
                else:
                    # exit_keys empty - set defaults, don't skip trade
                    exit_quantity = 0
                    exit_price = 0.0

                # Validate quantity consistency
                if abs(exit_quantity) > abs(entry_quantity):
                    trading_logger.log_error(
                        f"Exit Quantity > Entry Quantity!! for internal order id: {int_order_id}",
                        None,
                        {
                            "int_order_id": int_order_id,
                            "entry_quantity": entry_quantity,
                            "exit_quantity": exit_quantity,
                            "symbol": effective_symbol,
                        },
                    )
                    # raise ValueError("exit quantity greater than entry quantity")

                if eod:
                    # Handle option expiration
                    if exit_quantity + entry_quantity != 0 and contains_earlier_date(effective_symbol, market_close_time):
                        try:
                            # are options expiration needed?
                            get_open_position_by_order(
                                broker=broker, int_order_id=int_order_id, market_close_time=market_close_time
                            )
                            exit_keys = hget_with_default(broker, int_order_id, "exit_keys", "").split()  # type: ignore
                            exit_position = get_open_position_by_order(
                                broker, int_order_id, exclude_zero=True, side=["exit"]
                            )
                            base_position = parse_combo_symbol(effective_symbol)
                            position_combo_info = calculate_extra_combo_positions(exit_position, base_position)
                            exit_quantity = position_combo_info.get("total_in_progress", 0)
                            exit_price = (
                                sum(position.value for position in exit_position.values()) / exit_quantity
                                if exit_quantity != 0
                                else 0
                            )
                            exit_time = get_tradingapi_now().strftime("%Y-%m-%d %H:%M:%S")
                        except Exception as e:
                            trading_logger.log_error(
                                f"Error handling option expiration for {int_order_id}",
                                e,
                                {
                                    "int_order_id": int_order_id,
                                    "symbol": symbol,
                                    "market_close_time": market_close_time,
                                },
                            )

                # create trade row for internal order id (entry_time/exit_time as string for consistent dtype)
                _entry_time_str = (
                    entry_time.strftime("%Y-%m-%d %H:%M:%S")
                    if isinstance(entry_time, dt.datetime)
                    else str(entry_time or "")
                )
                _exit_time_str = (
                    exit_time.strftime("%Y-%m-%d %H:%M:%S")
                    if isinstance(exit_time, dt.datetime)
                    else str(exit_time or "")
                )
                row = {
                    "symbol": effective_symbol,
                    "side": side,
                    "entry_time": _entry_time_str,
                    "entry_quantity": entry_quantity,
                    "entry_price": float(entry_price),
                    "exit_time": _exit_time_str,
                    "exit_quantity": exit_quantity,
                    "exit_price": float(exit_price),
                    "commission": commission,
                    "int_order_id": int_order_id,
                    "entry_keys": " ".join(entry_keys),
                    "exit_keys": " ".join(exit_keys),
                    "additional_info": additional_info,
                }
                trades.append(row)

                # Debug: Log when trades with exit_keys are added to trades list
                if len(exit_keys) > 0:
                    trading_logger.log_debug(
                        "Trade with exit_keys added to trades list",
                        {
                            "int_order_id": int_order_id,
                            "symbol": effective_symbol,
                            "entry_time": str(entry_time),
                            "exit_time": str(exit_time),
                            "entry_time_type": type(entry_time).__name__,
                            "exit_time_type": type(exit_time).__name__,
                            "entry_quantity": entry_quantity,
                            "exit_quantity": exit_quantity,
                        },
                    )

            except Exception as e:
                trading_logger.log_error(
                    f"Error processing internal order ID: {int_order_id}",
                    e,
                    {"int_order_id": int_order_id, "strategy": strategy},
                )
                continue

        # Process results
        try:
            out = pd.DataFrame(trades)
            if len(out) > 0:
                # Ensure entry_time/exit_time are string-like (historical contract for downstream .str accessor)
                out["entry_time"] = out["entry_time"].astype(str)
                out["exit_time"] = out["exit_time"].astype(str)

                mask = (
                    (safe_datetime_compare(out.entry_time, start_time, ">=")) | (out.entry_time.astype(str) == "")
                ) & (
                    (safe_datetime_compare(out.exit_time, end_time, "<="))
                    | (out.exit_time.astype(str) == "")
                    | (out.entry_time.astype(str) == "")
                )
                out = out[mask]
                out["mtm"] = np.where(out["exit_quantity"] != 0, out["exit_price"], out["entry_price"])
                out["gross_pnl"] = -1 * (
                    out["exit_price"] * out["exit_quantity"]
                    + out["mtm"] * -1 * (out["entry_quantity"] + out["exit_quantity"])
                    + out["entry_quantity"] * out["entry_price"]
                )
                out["pnl"] = out["gross_pnl"]
                out.sort_values(["entry_time", "symbol"], ascending=[True, True], inplace=True)
                out.reset_index(drop=True, inplace=True)
            else:
                out = empty_trades
        except Exception as e:
            trading_logger.log_error(
                "Error processing P&L table results",
                e,
                {"strategy": strategy, "trades_count": len(trades), "start_time": start_time, "end_time": end_time},
            )
            out = empty_trades

        return out
    except Exception as e:
        trading_logger.log_error(
            "Error in get_pnl_table",
            e,
            {
                "strategy": strategy,
                "start_time": start_time,
                "end_time": end_time,
                "refresh_status": refresh_status,
                "market_close_time": market_close_time,
                "eod": eod,
            },
        )
        raise PnLError(
            f"Failed to get P&L table for strategy {strategy}: {str(e)}", {"strategy": strategy, "error": str(e)}
        )


@log_execution_time
@validate_inputs(
    input_string=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    market_close_time=lambda x: isinstance(x, str) and len(x.strip()) > 0,
)
def contains_earlier_date(input_string: str, market_close_time: str) -> bool:
    """True if current time is after (expiry date from input_string + market_close_time)."""
    if ":" in input_string:
        segment = input_string.split(":", 1)[0].split("?", 1)[0].strip()
    else:
        segment = input_string.split("?", 1)[0].strip() if "?" in input_string else input_string
    match = re.search(r"\d{8}", segment)
    if not match:
        return False
    expiry_date = match.group(0)
    close_t = dt.datetime.strptime(market_close_time, "%H:%M:%S").time()
    expiry_dt = dt.datetime.strptime(expiry_date, "%Y%m%d").replace(
        hour=close_t.hour, minute=close_t.minute, second=close_t.second, microsecond=0
    )
    now = dt.datetime.now()
    if now.tzinfo is not None:
        expiry_dt = expiry_dt.replace(tzinfo=now.tzinfo)
    return now > expiry_dt


@log_execution_time
@validate_inputs(
    strategy=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    long_symbol=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    broker_entry_side=lambda x: x is None or (isinstance(x, str) and x in ["BUY", "SHORT"]),
)
def get_orders_by_symbol(broker, strategy: str, long_symbol: str, broker_entry_side: str) -> list[str]:
    """Get a list of internal order IDs for a specified symbol, strategy and entry side combination.

    Args:
        broker: Broker instance
        strategy (str): strategy name
        long_symbol (str): long symbol name
        broker_entry_side (str): side of the entry trade. 'B' or 'S'.
                                So if entry was "SHORT", broker_entry_side will be 'S'

    Returns:
        list[str]: list of internal order ids that meet entry combination

    Raises:
        ValidationError: If input parameters are invalid
        RedisError: If Redis operations fail
    """
    try:
        int_order_ids = []

        def _normalize_leg_symbol(symbol_value: str) -> str:
            value = str(symbol_value or "").strip()
            if not value:
                return ""
            if ":" in value:
                value = value.split(":", 1)[0]
            if "?" in value:
                value = value.split("?", 1)[0]
            return value.strip()

        def _symbol_matches(requested_symbol: str, stored_symbol: str) -> bool:
            """Match exact symbols and allow single-leg lookup within combo parents."""
            if requested_symbol == stored_symbol:
                return True
            requested_leg = _normalize_leg_symbol(requested_symbol)
            stored_leg = _normalize_leg_symbol(stored_symbol)
            if requested_leg and requested_leg == stored_leg:
                return True
            if "?" in stored_symbol:
                try:
                    combo_legs = parse_combo_symbol(stored_symbol)
                    return requested_leg in combo_legs
                except Exception:
                    return False
            return False

        # Scan for internal order IDs
        try:
            # Use scan() with cursor 0 instead of scan_iter() to avoid cursor state issues
            pattern = strategy + "_" + "*"
            cursor = 0
            while True:
                cursor, keys = cast(tuple[Any, Any], broker.redis_o.scan(cursor, match=pattern, count=1000))
                int_order_ids.extend(keys)
                if cursor == 0:
                    break
        except Exception as e:
            context = create_error_context(strategy=strategy, scan_pattern=f"{strategy}_*", error=str(e))
            raise RedisError(f"Failed to scan Redis for strategy {strategy}: {str(e)}", context)

        if not int_order_ids:
            trading_logger.log_info(
                "No internal order IDs found for strategy", {"strategy": strategy, "long_symbol": long_symbol}
            )
            return []

        # Filter by long_symbol
        try:
            int_order_ids = [
                int_order_id
                for int_order_id in int_order_ids
                if cast(str, broker.redis_o.type(int_order_id)) == "hash"
                and cast(bool, broker.redis_o.hexists(int_order_id, "long_symbol"))
                and _symbol_matches(long_symbol, cast(str, broker.redis_o.hget(int_order_id, "long_symbol")))
            ]
        except Exception as e:
            context = create_error_context(
                strategy=strategy, long_symbol=long_symbol, int_order_ids_count=len(int_order_ids), error=str(e)
            )
            raise RedisError(f"Failed to filter orders by symbol {long_symbol}: {str(e)}", context)

        # Filter by broker entry side if specified
        combo = False
        if broker_entry_side is not None:
            try:
                entry_keys = []
                for int_order_id in int_order_ids:
                    symbol = cast(str, broker.redis_o.hget(int_order_id, "long_symbol"))
                    combo = True if ":" in symbol or "?" in symbol else False
                    entry_keys_str = cast(str, broker.redis_o.hget(int_order_id, "entry_keys"))
                    if entry_keys_str:
                        entry_keys.append(entry_keys_str.split()[0])
                    else:
                        trading_logger.log_warning(
                            "No entry keys found for internal order ID",
                            {"int_order_id": int_order_id, "strategy": strategy},
                        )

                jsons = []
                for entry_key in entry_keys:
                    if entry_key:
                        jsons.append(cast(dict[str, Any], broker.redis_o.hgetall(entry_key)))
                    else:
                        jsons.append({})
                if combo:
                    indices = [i for i in range(len(jsons)) if "BUY" == broker_entry_side]
                else:
                    indices = [i for i in range(len(jsons)) if jsons[i].get("order_type") == broker_entry_side]
                int_order_ids = [int_order_ids[index] for index in indices]

            except Exception as e:
                context = create_error_context(
                    strategy=strategy,
                    long_symbol=long_symbol,
                    broker_entry_side=broker_entry_side,
                    int_order_ids_count=len(int_order_ids),
                    error=str(e),
                )
                raise RedisError(f"Failed to filter orders by entry side {broker_entry_side}: {str(e)}", context)

        trading_logger.log_debug(
            "Orders by symbol retrieved",
            {
                "strategy": strategy,
                "long_symbol": long_symbol,
                "broker_entry_side": broker_entry_side,
                "order_count": len(int_order_ids),
            },
        )

        return int_order_ids

    except (ValidationError, RedisError):
        raise
    except Exception as e:
        context = create_error_context(
            strategy=strategy, long_symbol=long_symbol, broker_entry_side=broker_entry_side, error_type=type(e).__name__
        )
        raise RedisError(f"Unexpected error in get_orders_by_symbol: {str(e)}", context)


@log_execution_time
@validate_inputs(
    int_order_id=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    market_close_time=lambda x: isinstance(x, str) and len(x.strip()) > 0,
)
def get_open_position_by_order(
    broker: BrokerBase,
    int_order_id: str,
    exclude_zero: bool = True,
    side: List[str] = ["entry", "exit"],
    market_close_time: str = "15:30:00",
) -> Dict[str, Position]:
    """Get open positions for a specific internal order ID.

    Args:
        broker: Broker instance
        int_order_id: Internal order ID
        exclude_zero: Whether to exclude zero positions
        side: List of sides to include ("entry", "exit")
        market_close_time: Market close time for expiry calculations

    Returns:
        Dict[str, Position]: Dictionary of symbol to position mapping

    Raises:
        ValidationError: If input parameters are invalid
        RedisError: If Redis operations fail
        OrderError: If order processing fails
    """
    trading_logger.log_debug(
        f"Getting open position for {int_order_id}",
        {
            "int_order_id": int_order_id,
            "exclude_zero": exclude_zero,
            "side": side,
            "market_close_time": market_close_time,
        },
    )

    def _get_position_by_broker_order_ids(keys, positions: Dict[str, Position]) -> Dict[str, Position]:
        """Helper function to get positions from broker order IDs."""
        try:
            for key in keys:
                if not key:
                    trading_logger.log_warning(
                        "Empty key found in broker order IDs", {"int_order_id": int_order_id, "keys": keys}
                    )
                    continue

                try:
                    order_data = cast(dict[str, Any], broker.redis_o.hgetall(key))
                    if not order_data:
                        trading_logger.log_warning(
                            "No order data found for key", {"key": key, "int_order_id": int_order_id}
                        )
                        continue

                    order = Order(**order_data)
                    symbol = order.long_symbol
                    position = positions.get(symbol, Position())
                    position.symbol = symbol
                    quantity = order.quantity if order.order_type in ["BUY", "COVER"] else -1 * order.quantity
                    position.value = order.price * quantity + position.price * position.size
                    position.size = position.size + quantity
                    if position.size != 0:
                        position.price = position.value / position.size
                    else:
                        position.price = 0
                    positions[symbol] = position

                except Exception as e:
                    trading_logger.log_error(
                        f"Error processing order key {key}",
                        e,
                        {"key": key, "int_order_id": int_order_id, "error": str(e)},
                    )
                    continue

            return positions

        except Exception as e:
            context = create_error_context(int_order_id=int_order_id, keys_count=len(keys), error=str(e))
            raise OrderError(f"Failed to get positions from broker order IDs: {str(e)}", context)

    def _expire_derivative(
        broker: BrokerBase, internal_order_id: str, symbol: str, size: int, market_close_time: str
    ) -> bool:
        expire = False
        expiry = symbol.split("_")[2]
        if (
            expiry is not None
            and len(expiry) > 0
            and (
                expiry < dt.datetime.now().strftime("%Y%m%d")
                or (
                    expiry == dt.datetime.now().strftime("%Y%m%d")
                    and dt.datetime.now().strftime("%H:%M:%S") > market_close_time
                )
            )
        ):
            expire = True
            entry_keys = hget_with_default(broker, int_order_id, "entry_keys", "").split()  # type: ignore  # type: ignore
            entry_key = entry_keys[0]
            exchange = hget_with_default(broker, entry_key, "exchange", "NSE")  # type: ignore
            quote = broker.get_quote(symbol, exchange)  # type: ignore
            exit_price = quote.last if quote is not None else 0.0
            # Guard against non-finite quote values when creating synthetic
            # expiry squareoff orders; Redis should not store "nan"/"inf" prices.
            try:
                exit_price = float(exit_price)
            except (TypeError, ValueError):
                exit_price = 0.0
            if not math.isfinite(exit_price):
                exit_price = 0.0
            # Some brokers publish 0.05 as the terminal OTM expiry tick.
            # Normalize this artifact to 0.0 for expiry paper exits.
            if isinstance(exit_price, (int, float)) and math.isclose(float(exit_price), 0.05, rel_tol=0.0, abs_tol=1e-9):
                exit_price = 0.0
            exit_quantity = abs(size)
            sq_off_order = Order(
                order_type="SELL" if size > 0 else "COVER",
                quantity=exit_quantity,
                exchange="SQUAREOFF",
                exchange_segment="D",
                is_intraday=False,
                price=exit_price,
                ahplaced="N",
            )
            sq_off_order.exch_order_id = (
                str(secrets.randbelow(9000000000000000 - 1000000000000000) + 1000000000000000) + "P"
            )
            sq_off_order.remote_order_id = get_tradingapi_now().strftime("%Y%m%d%H%M%S%f")[:-4]
            sq_off_order.broker_order_id = str(secrets.randbelow(90000000) + 10000000) + "P"
            sq_off_order.orderRef = internal_order_id
            sq_off_order.internal_order_id = internal_order_id
            sq_off_order.message = "Expiration Paper Order"
            sq_off_order.status = OrderStatus.FILLED
            sq_off_order.long_symbol = symbol
            sq_off_order.scrip_code = int(hget_with_default(broker, entry_key, "scrip_code", "0"))  # type: ignore
            sq_off_order.price_type = 0.0  # LMT order type
            long_symbol_for_update = cast(
                str, broker.redis_o.hget(internal_order_id, "long_symbol") or symbol
            )
            _process_broker_order_update(broker, sq_off_order, long_symbol_for_update)
        return expire

    positions: Dict[str, Position] = {}
    entry = True if "entry" in side else False
    exit = True if "exit" in side else False
    if entry:
        entry_keys = hget_with_default(broker, int_order_id, "entry_keys", "").split()  # type: ignore
        positions = _get_position_by_broker_order_ids(entry_keys, positions)
    if exit:
        exit_keys = hget_with_default(broker, int_order_id, "exit_keys", "").split()  # type: ignore
        positions = _get_position_by_broker_order_ids(exit_keys, positions)
    for position in positions.values():
        position.price = position.value / position.size if position.size != 0 else 0
    if exclude_zero:
        positions = {key: value for key, value in positions.items() if value.size != 0}
    if entry and exit:
        expired_contracts = []
        # check for expired contracts
        for symbol, position in positions.items():
            if position.size != 0:
                expired = _expire_derivative(broker, int_order_id, symbol, position.size, market_close_time)
                if expired:
                    expired_contracts.append(symbol)
        positions = {key: value for key, value in positions.items() if value.symbol not in expired_contracts}
    return positions


def _build_effective_symbol_from_positions(positions: Dict[str, Position]) -> str:
    """Build a symbol/combo string from actual non-zero filled positions."""
    non_zero = [(sym, pos.size) for sym, pos in positions.items() if pos.size != 0]
    if not non_zero:
        return ""
    if len(non_zero) == 1:
        return non_zero[0][0]
    non_zero = sorted(non_zero, key=lambda x: x[0])
    abs_sizes = [abs(size) for _, size in non_zero if size != 0]
    if not abs_sizes:
        return ""
    norm = abs_sizes[0]
    for value in abs_sizes[1:]:
        norm = math.gcd(norm, value)
    if norm == 0:
        norm = 1
    return ":".join(f"{sym}?{int(size / norm)}" for sym, size in non_zero)


@log_execution_time
@validate_inputs(combo_symbol=lambda x: isinstance(x, str) and len(x.strip()) > 0)
def parse_combo_symbol(combo_symbol):
    """Parse a combo symbol string into individual symbols and quantities.

    Args:
        combo_symbol: Symbol string that may contain combo notation

    Returns:
        OrderedDict: Dictionary mapping symbol names to quantities

    Raises:
        ValidationError: If input parameter is invalid
        SymbolError: If combo symbol parsing fails
    """
    try:
        result = OrderedDict()

        if "?" not in combo_symbol:
            result[combo_symbol] = 1
            trading_logger.log_debug("Parsed simple symbol", {"combo_symbol": combo_symbol, "result": dict(result)})
            return result

        symbols = combo_symbol.split(":")

        if len(symbols) == 0:
            context = create_error_context(combo_symbol=combo_symbol, split_result=symbols)
            raise SymbolError("Empty combo symbol after splitting", context)

        for i, symbol in enumerate(symbols):
            try:
                if "?" not in symbol:
                    context = create_error_context(combo_symbol=combo_symbol, symbol=symbol, index=i)
                    raise SymbolError(f"Symbol {symbol} does not contain quantity separator '?'", context)

                name, quantity_str = symbol.split("?", 1)

                if not name.strip():
                    context = create_error_context(combo_symbol=combo_symbol, symbol=symbol, index=i)
                    raise SymbolError(f"Empty symbol name in combo {combo_symbol}", context)

                try:
                    quantity = int(quantity_str)
                except ValueError as e:
                    context = create_error_context(
                        combo_symbol=combo_symbol, symbol=symbol, quantity_str=quantity_str, index=i
                    )
                    raise SymbolError(f"Invalid quantity '{quantity_str}' in combo symbol", context)

                result[name.strip()] = quantity

            except SymbolError:
                raise
            except Exception as e:
                context = create_error_context(combo_symbol=combo_symbol, symbol=symbol, index=i, error=str(e))
                raise SymbolError(f"Error parsing symbol '{symbol}' in combo: {str(e)}", context)

        trading_logger.log_debug(
            "Parsed combo symbol", {"combo_symbol": combo_symbol, "symbols_count": len(result), "result": dict(result)}
        )

        return result

    except (ValidationError, SymbolError):
        raise
    except Exception as e:
        context = create_error_context(combo_symbol=combo_symbol, error_type=type(e).__name__)
        raise SymbolError(f"Unexpected error parsing combo symbol: {str(e)}", context)


def get_exit_candidates(broker: BrokerBase, strategy: str, long_symbol: str, side: str) -> list[str]:
    """Retreive exit candidates for a specified strategy, side and entry order type

    Args:
        strategy (str): strategy name
        long_symbol (str): long symbol
        side (str): 'SELL' if original position is long. 'COVER' if original position is short. side should be the order type that will result in position closure.

    Returns:
        list: list of internal order ids that have matching positions for exit
    """
    if side == "SELL":
        broker_entry_side = "BUY"
    elif side == "COVER":
        broker_entry_side = "SHORT"
    else:
        broker_entry_side = "UNDEFINED"
    int_order_ids = get_orders_by_symbol(broker, strategy, long_symbol, broker_entry_side)
    # get keys that have an open position. This is equal to keys that have an exit order that have a status of
    # filled
    if int_order_ids:
        int_order_ids = [
            int_order_id for int_order_id in int_order_ids if len(get_open_position_by_order(broker, int_order_id)) != 0
        ]
    else:
        # Handle the case where int_order_ids is empty, if needed
        pass
    # order keys to support fifo, key with lower integer component should be first
    int_order_ids.sort(key=lambda pair: pair.split("_")[1])
    trading_logger.log_info("Exit Candidates -->" + ",".join(int_order_ids))
    return int_order_ids


@log_execution_time
@validate_inputs(
    symbol=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    exchange=lambda x: isinstance(x, str) and len(x.strip()) > 0,
)
def get_limit_price(
    broker: BrokerBase,
    price_type=None,
    order_type=None,
    symbol=None,
    price_broker: Optional[List[BrokerBase]] = None,
    exchange="NSE",
    mds: Optional[str] = None,
):
    """Get limit price based on price type and market data.

    Args:
        broker: Broker instance
        price_type: Type of price calculation (LMT, BID, ASK, MKT, etc.)
        order_type: Type of order (BUY, SELL, SHORT, COVER)
        symbol: Trading symbol
        price_broker: Optional list of brokers for price data
        exchange: Exchange name
        mds: Market data service channel name (str). If None or empty, uses broker quotes.
             If provided (e.g., "mds"), uses market data service with that channel.

    Returns:
        float: Calculated limit price

    Raises:
        ValidationError: If input parameters are invalid
        MarketDataError: If price calculation fails
    """
    exchange = broker.map_exchange_for_api(symbol, exchange)
    if price_broker is None:
        price_broker = [broker]
    # quantity = order.quantity if order.order_type=='BUY' or order.order_type=='COVER' else order.quantity*-1
    ref_price = float("nan")
    pattern_plus = r"(LMT|BID|ASK)\s*\+\s*([+-]?\d+(\.\d+)?)"
    pattern_minus = r"(LMT|BID|ASK)\s*\-\s*([+-]?\d+(\.\d+)?)"
    pattern_mult = r"(LMT|BID|ASK)\s*\*\s*([+-]?\d+(\.\d+)?)"
    match_plus = re.match(pattern_plus, str(price_type))
    match_minus = re.match(pattern_minus, str(price_type))
    match_mult = re.match(pattern_mult, str(price_type))
    if price_type in ["LMT", "BID", "ASK"] or match_plus or match_minus or match_mult:
        ticker = get_price(price_broker, symbol, checks=["bid", "ask"], exchange=exchange, mds=mds)
        if "BID" in str(price_type):
            ref_price = ticker.bid
        elif "ASK" in str(price_type):
            ref_price = ticker.ask
        else:
            ref_price = (ticker.bid + ticker.ask) / 2
        if match_plus:
            ref_price = ref_price + float(match_plus.group(2))
        elif match_minus:
            ref_price = ref_price - float(match_minus.group(2))
        elif match_mult:
            ref_price = ref_price * float(match_mult.group(2))
        else:
            pass
        if not math.isnan(ref_price):
            ref_price = int(
                ref_price / broker.exchange_mappings[exchange]["contracttick_map"].get(symbol, 0.05)
            ) * broker.exchange_mappings[exchange]["contracttick_map"].get(symbol, 0.05)
            if ref_price <= 0:
                ref_price = (
                    max(
                        broker.exchange_mappings[exchange]["contracttick_map"].get(symbol, 0.05),
                        ticker.bid + broker.exchange_mappings[exchange]["contracttick_map"].get(symbol, 0.05),
                    )
                    if order_type in ["BUY", "COVER"]
                    else ticker.ask - broker.exchange_mappings[exchange]["contracttick_map"].get(symbol, 0.05)
                )
    elif price_type == "MKT":
        ticker = get_price(price_broker, symbol, checks=["bid", "ask"], exchange=exchange, mds=mds)
        if order_type in ["BUY", "COVER"]:
            ref_price = ticker.ask
            # lmt_price = int(ticker.ask / 2) - 1
        else:
            ref_price = ticker.bid
            # lmt_price = int(ticker.bid * 2) + 1
        if ref_price <= 0:
            ref_price = (
                max(
                    broker.exchange_mappings[exchange]["contracttick_map"].get(symbol, 0.05),
                    ticker.bid + broker.exchange_mappings[exchange]["contracttick_map"].get(symbol, 0.05),
                )
                if order_type in ["BUY", "COVER"]
                else ticker.ask - broker.exchange_mappings[exchange]["contracttick_map"].get(symbol, 0.05)
            )
    elif isinstance(price_type, float) or isinstance(price_type, int):
        ref_price = price_type
    elif isinstance(price_type, list):
        # Handle list inputs (e.g., from scalping.py which returns [mid_price])
        # Extract first element if it's a single-element list, or first element of first sublist
        if price_type and isinstance(price_type[0], list):
            # Nested list: [[price1], [price2]] -> extract first price from first sublist
            ref_price = price_type[0][0] if price_type[0] else 0
        elif price_type:
            # Simple list: [price] -> extract first price
            ref_price = price_type[0]
        else:
            ref_price = 0
    else:
        ref_price = 0
    return ref_price


def get_combo_sub_order_type(order: Order, sub_order_qty: int) -> str:
    """Get the order type  for combo suborder

    Args:
        order (Order): combo order
        sub_order_qty (int): suborder quantity as per combo definition when buying 1 unit of combo

    Returns:
        str: order type of ['BUY','SELL','SHORT','COVER']
    """
    if "?" not in order.long_symbol:
        return order.order_type

    if order.order_type in ["BUY", "SHORT"]:
        if sub_order_qty > 0:
            return "BUY"
        else:
            return "SHORT"

    if order.order_type in ["SELL", "COVER"]:
        if sub_order_qty > 0:
            return "COVER"
        else:
            return "SELL"
    return "UNDEFINED"


@log_execution_time
@validate_inputs(strategy=lambda x: isinstance(x, str) and len(x.strip()) > 0, paper=lambda x: isinstance(x, bool))
def transmit_entry_order(
    broker: BrokerBase,
    strategy: str,
    order: Order,
    paper: bool = True,
    price_broker: Optional[List[BrokerBase]] = None,
    mds: Optional[str] = None,
) -> str:
    """Transmit entry order to broker with enhanced error handling.

    Args:
        broker: Broker instance
        strategy: Strategy name
        order: Order object to transmit
        paper: Whether this is a paper trade
        price_broker: Optional list of brokers for price data

    Returns:
        str: Internal order ID

    Raises:
        ValidationError: If input parameters are invalid
        OrderError: If order transmission fails
    """
    """Entry order sent to broker

    Args:
        strategy (str): strategy
        long_symbol (str): long symbol
        order (Order): order object
        paper (bool): If true (default), places simulated order

    Returns:
        str: internal order id
    """
    # Enforce: combo orders (with ":") must have order_type "BUY"
    if ":" in order.long_symbol and order.order_type != "BUY":
        error_msg = f"Combo order {order.long_symbol} must have order_type 'BUY'. Got '{order.order_type}' instead."
        trading_logger.log_error(error_msg)
        raise OrderError(error_msg, {"symbol": order.long_symbol, "order_type": order.order_type})

    if order.price is None:
        error_msg = f"Order not placed. Price was set as None for symbol: {order.long_symbol}"
        trading_logger.log_error(error_msg)
        raise OrderError(error_msg, {"symbol": order.long_symbol})
    if price_broker is None:
        price_broker = [broker]
    if not order.internal_order_id:
        next_order_id = broker.starting_order_ids_int.get(strategy, 1)
        broker.starting_order_ids_int[strategy] = next_order_id + 1
        internal_order_id = strategy + "_" + str(next_order_id)
        order.internal_order_id = internal_order_id
        order.paper = paper
    order.paper = paper

    if "?" in order.long_symbol:
        combo_symbols = parse_combo_symbol(order.long_symbol)
        symbols = list(combo_symbols.keys())
        quantities = [
            x * order.quantity if order.order_type == "BUY" else -x * order.quantity for x in combo_symbols.values()
        ]
        if isinstance(order.price_type, list):
            price_types = order.price_type
        else:
            price_types = [order.price_type] * len(symbols)
        # price_types = [0] * len(symbols) if paper is False else ["MKT"] * len(symbols)
        additional_infos = [""] * len(combo_symbols)
        trigger_prices = [order.trigger_price] * len(symbols)
    else:
        symbols = [order.long_symbol]
        quantities = [order.quantity if order.order_type == "BUY" else -1 * order.quantity]
        price_types = [order.price_type]
        additional_infos = [order.additional_info]
        trigger_prices = [order.trigger_price]
    symbols, quantities, price_types, additional_infos, trigger_prices = _sort_list(
        symbols, quantities, price_types, additional_infos, trigger_prices=trigger_prices
    )
    int_order_id = ""
    for symbol, quantity, price_type, additional_info, trigger_price in zip(
        symbols, quantities, price_types, additional_infos, trigger_prices
    ):
        temp_order = deepcopy(order)
        temp_order.order_type = get_combo_sub_order_type(order, quantity)
        temp_order.quantity = abs(quantity)
        temp_order.long_symbol = symbol
        temp_order.trigger_price = temp_order._convert_to_float(trigger_price, "trigger_price")
        temp_order.is_stoploss_order = temp_order.is_stoploss_order or not math.isnan(temp_order.trigger_price)
        lmt_price = get_limit_price(
            broker,
            price_type=price_type,
            order_type=temp_order.order_type,
            symbol=symbol,
            price_broker=price_broker,
            exchange=temp_order.exchange,
            mds=mds,
        )
        temp_order.price = lmt_price
        out = broker.place_order(temp_order)
        int_order_id = _process_broker_order_update(broker, out, order.long_symbol)
    return int_order_id


def transmit_exit_order(
    broker: BrokerBase,
    strategy: str,
    order: Order,
    validate_db_position=True,
    paper=True,
    price_broker: Optional[List[BrokerBase]] = None,
    mds: Optional[str] = None,
    int_order_id: str = "",
) -> None:
    """Exit order sent to broker

    Args:
        strategy (str): name of strategy
        long_symbol (str): symbol to exit
        order (Order): order object
        paper (bool): If true (default), places simulated order
        int_order_id (str) : if specified, exits are effected from the specified order id
    """

    def cancel_internal_order_id(
        broker: BrokerBase,
        internal_order_id: str,
    ):
        order_mapping = cast(dict[str, Any], broker.redis_o.hgetall(internal_order_id))
        entry_keys = order_mapping.get("entry_keys")
        if entry_keys is not None:
            entry_keys_list = entry_keys.split(" ")
            for ek in entry_keys_list:
                broker.cancel_order(broker_order_id=ek)
        exit_keys = order_mapping.get("exit_keys")
        if exit_keys is not None:
            exit_keys_list = exit_keys.split(" ")
            for ek in exit_keys_list:
                broker.cancel_order(broker_order_id=ek)

    trading_logger.log_info(
        f"Exit order. Symbol: {order.long_symbol}{chr(10)} Side: {order.order_type}. Quantity: {order.quantity}"
    )
    exit_candidates = (
        [int_order_id] if int_order_id else get_exit_candidates(broker, strategy, order.long_symbol, order.order_type)
    )
    order.paper = paper
    if price_broker is None:
        price_broker = [broker]

    if "?" in order.long_symbol:
        combo_symbols = parse_combo_symbol(order.long_symbol)
        exit_symbols = list(combo_symbols.keys())
        exit_quantities_required = [
            x * order.quantity if order.order_type == "COVER" else -x * order.quantity for x in combo_symbols.values()
        ]

        if isinstance(order.price_type, list):
            price_types = order.price_type
        else:
            price_types = [order.price_type] * len(exit_symbols)
        trigger_prices = [order.trigger_price] * len(exit_symbols)
        # price_types = [0] * len(exit_symbols) if paper is False else ["MKT"] * len(exit_symbols)

    else:
        exit_symbols = [order.long_symbol]
        exit_quantities_required = [order.quantity if order.order_type == "COVER" else -1 * order.quantity]
        price_types = order.price_type if isinstance(order.price_type, list) else [order.price_type]
        trigger_prices = [order.trigger_price] if not isinstance(order.trigger_price, list) else order.trigger_price
    quantities_remaining = exit_quantities_required
    additional_infos = order.additional_info if isinstance(order.additional_info, list) else [order.additional_info]

    (
        exit_symbols,
        quantities_remaining,
        price_types,
        additional_infos,
        trigger_prices,
    ) = _sort_list(exit_symbols, quantities_remaining, price_types, additional_infos, trigger_prices=trigger_prices)

    if len(exit_candidates) > 0 and validate_db_position:
        for internal_order_id in exit_candidates:
            if any(quantities_remaining):
                cancel_internal_order_id(broker, internal_order_id)
                actual_positions = get_open_position_by_order(broker, internal_order_id)
                loop_quantities_remaining = deepcopy(quantities_remaining)
                for exit_symbol, quantity, price_type, additional_info, trigger_price in zip(
                    exit_symbols, loop_quantities_remaining, price_types, additional_infos, trigger_prices
                ):
                    actual_position = actual_positions.get(exit_symbol, Position())
                    if quantity != 0 and quantity * actual_position.size < 0:
                        order_new = deepcopy(order)
                        order_new.additional_info = _merge_additional_info(order_new.additional_info, additional_info)
                        order_new.long_symbol = exit_symbol
                        order_new.quantity = min(abs(quantity), abs(actual_position.size))
                        order_new.order_type = get_combo_sub_order_type(order, quantity)
                        order_new.internal_order_id = internal_order_id
                        order_new.orderRef = internal_order_id
                        order_new.trigger_price = order_new._convert_to_float(trigger_price, "trigger_price")
                        if not math.isnan(order_new.trigger_price):
                            order_new.is_stoploss_order = True
                        lmt_price = get_limit_price(
                            broker,
                            price_type=price_type,
                            order_type=order_new.order_type,
                            symbol=exit_symbol,
                            price_broker=price_broker,
                            exchange=order_new.exchange,
                            mds=mds,
                        )
                        order_new.price = lmt_price
                        out = broker.place_order(order=order_new)
                        _process_broker_order_update(broker, out, order.long_symbol)
                        calc_index = exit_symbols.index(exit_symbol)
                        if order_new.order_type in ["COVER"]:
                            quantities_remaining[calc_index] -= order_new.quantity
                        else:
                            quantities_remaining[calc_index] += order_new.quantity
    else:
        trading_logger.log_info(
            f"No exit candidates found for symbol: {order.long_symbol} and order: {order.order_type} and strategy: "
            f"{strategy}"
        )


def calculate_extra_combo_positions(order_position: Dict[str, Position], base_position: Dict[str, int]) -> dict[str, Any]:
    """Calculates extra positions outside completed combos.

    Args:
        order_position (dict): Positions of symbols within a combo.
        base_position (dict): Baseline combo position making 1 combo unit.

    Returns:
        dict: Dictionary with incomplete details, total in-progress combos, and completed combos.
    """
    # Calculate complete multiples and determine first sign
    complete_multiples = []
    for symbol, base_pos in base_position.items():
        actual_position = order_position.get(symbol, Position())
        complete_multiples.append(actual_position.size / base_pos)

    # Determine the sign of the first non-zero multiple
    first_sign = 1  # Default to positive if all are zeros
    for x in complete_multiples:
        if x != 0:
            first_sign = int(math.copysign(1, x))
            break

    # Check if all multiples are on the same side (considering 0 as positive or negative)
    all_same_side = all(int(math.copysign(1, x)) == first_sign or x == 0 for x in complete_multiples)

    if not all_same_side:
        raise ValueError("Combo Order does not have consistent fill sides")

    # Calculate completed and in-progress combos
    abs_multiples = [abs(m) for m in complete_multiples]
    completed = math.floor(min(abs_multiples))
    in_progress = math.ceil(max(abs_multiples))

    # Adjust completed and in-progress based on sign of first non-zero multiple
    completed *= first_sign
    in_progress *= first_sign

    # Calculate extra positions
    out = {}
    for symbol, base_pos in base_position.items():
        actual_position = order_position.get(symbol, Position())
        extra_position = actual_position.size - base_pos * completed
        if extra_position != 0:
            out[symbol] = extra_position

    return {"incomplete_details": out, "total_in_progress": in_progress, "total_completed": completed}


def _process_broker_order_update(broker: BrokerBase, order: Order, long_symbol: str) -> str:
    """Processes broker  response to a fresh order (entry/exit)

    Args:
        broker (BrokerBase): broker instance
        order (Order): Order
        long_symbol (str): combo symbol if combo order, else actual symbol

    Returns:
        str: internal order id
    """
    if order is None:
        trading_logger.log_error(f"Order Not placed as None was received. Mother symbol: {long_symbol}. Are you logged in??")
        return ""
    if order.status in [OrderStatus.REJECTED, OrderStatus.UNDEFINED]:
        trading_logger.log_error(
            f"Order not placed for {order.long_symbol}. Status was {order.status}. Message was {order.message}. Mother symbol was: {long_symbol}"
        )
        return ""

    if order.order_type in ["BUY", "SHORT"]:
        current_orders = cast(str, broker.redis_o.hget(order.internal_order_id, "entry_keys"))
        entry_keys = [k for k in str(current_orders or "").split() if k]
        broker_key = str(order.broker_order_id)
        if broker_key not in entry_keys:
            entry_keys.append(broker_key)
        new_orders = " ".join(entry_keys)
        cast(bool, broker.redis_o.hset(order.orderRef, "entry_keys", new_orders))
        cast(bool, broker.redis_o.hset(order.internal_order_id, "long_symbol", long_symbol))

    if order.order_type in ["SELL", "COVER"]:
        current_orders = cast(str, broker.redis_o.hget(order.internal_order_id, "exit_keys"))
        exit_keys = [k for k in str(current_orders or "").split() if k]
        broker_key = str(order.broker_order_id)
        if broker_key not in exit_keys:
            exit_keys.append(broker_key)
        new_orders = " ".join(exit_keys)
        cast(bool, broker.redis_o.hset(order.orderRef, "exit_keys", new_orders))
        cast(bool, broker.redis_o.hset(order.internal_order_id, "long_symbol", long_symbol))

    broker.redis_o.hmset(str(order.broker_order_id), {key: str(val) for key, val in order.to_dict().items()})
    update_order_status(broker, order.internal_order_id, str(order.broker_order_id), eod=False)
    return order.internal_order_id


def exit_is_expiration(broker: BrokerBase, internal_order_id: str) -> bool:
    """Are exit key(s) all expired

    Args:
        broker (BrokerBase): broker
        internal_order_id (str): internal order id

    Returns:
        bool: True if exit key(s) exits and are expiration(s). Else False
    """
    exit_keys = hget_with_default(broker, internal_order_id, "exit_keys", "").split()  # type: ignore
    if len(exit_keys) == 0:
        return False
    out = True
    for ek in exit_keys:
        message = cast(str, broker.redis_o.hget(ek, "message"))
        if message and "expir" not in message.lower():
            out = out and False
    return out


def delete_broker_order_id(
    broker,
    internal_order_id: str,
    broker_order_id: str = "0",
):
    """Safely removes broker_order_id from redis and updates internal_order_id with keys

    Args:
        internal_order_id (str): internal  order id
        broker_order_id (str): broker order id
    """
    if broker_order_id == "0":
        trading_logger.log_info(f"Deleting internal order id: {internal_order_id} and linked broker order ids")
        order_mapping = cast(dict[str, Any], broker.redis_o.hgetall(internal_order_id))
        entry_keys = order_mapping.get("entry_keys")
        if entry_keys is not None:
            entry_keys_list = entry_keys.split(" ")
            for ek in entry_keys_list:
                trading_logger.log_info(f"Deleting order. Order {ek}")
                broker.redis_o.delete(ek)
        exit_keys = order_mapping.get("exit_keys")
        if exit_keys is not None:
            exit_keys_list = exit_keys.split(" ")
            for ek in exit_keys_list:
                trading_logger.log_info(f"Deleting order. Order {ek}")
                broker.redis_o.delete(ek)
        trading_logger.log_info(f"Deleting order. Order {internal_order_id}")
        broker.redis_o.delete(internal_order_id)
    else:
        order_mapping = cast(dict[str, Any], broker.redis_o.hgetall(internal_order_id))
        if len(order_mapping) == 0:
            trading_logger.log_info(f"Internal Order ID: {internal_order_id} not found")
            return
        # check if removal is from entry
        entry_keys = order_mapping.get("entry_keys")
        if entry_keys is not None and str(broker_order_id) in entry_keys:
            entry_keys = entry_keys.split()
            entry_keys.remove(str(broker_order_id))
            trading_logger.log_info(f"Deleting broker order id: {broker_order_id}")
            exit_keys = hget_with_default(broker, internal_order_id, "exit_keys", "").split()
            if len(entry_keys) == 0 and len(exit_keys) > 0:
                if exit_is_expiration(broker, internal_order_id):
                    pipe = broker.redis_o.pipeline()
                    pipe.delete(internal_order_id)
                    pipe.delete(broker_order_id)
                    for ek in exit_keys:
                        pipe.delete(ek)
                    pipe.execute()
                    pipe.reset()
                    trading_logger.log_info(
                        f"Deleting order and internal_order_id. Order {broker_order_id}. Internal Order ID: {internal_order_id}"
                    )
                else:
                    trading_logger.log_error(f"Unexpected exit key found for order id {internal_order_id}")
            else:
                order_mapping["entry_keys"] = " ".join(entry_keys)
                pipe = broker.redis_o.pipeline()
                pipe.delete(internal_order_id)
                if not order_mapping["entry_keys"].strip() == "":
                    pipe.hmset(internal_order_id, order_mapping)
                pipe.delete(broker_order_id)
                pipe.execute()
                pipe.reset()
                trading_logger.log_info(
                    f"Deleting unfilled order and updating internal_order_id. Order {broker_order_id}. Internal Order ID: {internal_order_id}"
                )
        else:
            exit_keys = order_mapping.get("exit_keys")
            exit_keys_list: list[str] = []
            if exit_keys is not None and str(broker_order_id) in exit_keys:
                # check if removal is from exit
                exit_keys_list = exit_keys.split()
            exit_keys_list.remove(str(broker_order_id))
            if len(exit_keys_list) == 0:
                order_mapping.pop("exit_keys")
            else:
                order_mapping["exit_keys"] = " ".join(exit_keys_list)
            pipe = broker.redis_o.pipeline()
            pipe.delete(internal_order_id)
            pipe.hmset(internal_order_id, order_mapping)
            pipe.delete(broker_order_id)
            pipe.execute()
            pipe.reset()
            trading_logger.log_info(
                f"Deleting  order and updating internal_order_id. Order {broker_order_id}. Internal Order ID: {internal_order_id}"
            )


def update_order_status(
    broker: BrokerBase, internal_order_id: str, broker_order_id: str, eod: bool = False
) -> Optional[OrderInfo]:
    """
    if eod is false, [price,quantity,status] is updated to [fill_price/order_price,order_size,orderstatus]
    if eod is true, [price,quantity,status] is updated to [fill_price,fill_size,orderstatus]. in addition to eod functionality, order is deleted if fill_size is zero
    """
    # Skip refresh if broker_order_id is invalid (e.g., "0"/paper IDs/missing IDs)
    broker_order_id_str = str(broker_order_id or "").strip()
    if not broker_order_id_str or broker_order_id_str == "0" or broker_order_id_str.upper().endswith("P"):
        return None

    try:
        fills = broker.get_order_info(broker_order_id=broker_order_id_str)
    except Exception as e:
        trading_logger.log_error(
            "Error calling get_order_info in update_order_status",
            e,
            {"internal_order_id": internal_order_id, "broker_order_id": broker_order_id},
        )
        return None

    required_attributes = [
        "broker",
        "status",
        "fill_size",
        "fill_price",
        "order_price",
        "order_size",
        "exchange_order_id",
    ]
    for attr in required_attributes:
        if not hasattr(fills, attr) or getattr(fills, attr) in [None, "0"]:
            attr_value = getattr(fills, attr, "<missing>")
            trading_logger.log_error(
                f"Missing or invalid attribute {attr} in order information for broker_order_id: {broker_order_id}. "
                f"value={attr_value!r}, value_type={type(attr_value).__name__}"
            )
            return fills

    if broker.broker != fills.broker:
        return fills

    if fills.status == OrderStatus.CANCELLED and fills.fill_size > 0:
        broker.redis_o.hset(broker_order_id, "price", str(fills.fill_price))
        broker.redis_o.hset(broker_order_id, "quantity", str(fills.fill_size))
        broker.redis_o.hset(broker_order_id, "status", fills.status.name)
        broker.redis_o.hset(broker_order_id, "exch_order_id", fills.exchange_order_id)
    elif (fills.status == OrderStatus.CANCELLED and fills.fill_size == 0) or (fills.status == OrderStatus.REJECTED):
        delete_broker_order_id(broker, internal_order_id, broker_order_id)
    elif eod:
        if fills.fill_size > 0:
            broker.redis_o.hset(broker_order_id, "price", str(fills.fill_price))
            broker.redis_o.hset(broker_order_id, "quantity", str(fills.fill_size))
            broker.redis_o.hset(broker_order_id, "status", fills.status.name)
            broker.redis_o.hset(broker_order_id, "exch_order_id", fills.exchange_order_id)
        else:
            delete_broker_order_id(broker, internal_order_id, broker_order_id)
    else:
        if fills.status == OrderStatus.HISTORICAL:
            return fills
        # Check if fill_price is 0 or non-numeric
        try:
            fill_price_numeric = float(fills.fill_price)
            is_invalid_price = fill_price_numeric == 0
        except (ValueError, TypeError):
            is_invalid_price = True
        if is_invalid_price:
            broker.redis_o.hset(broker_order_id, "price", str(fills.order_price))
            broker.redis_o.hset(broker_order_id, "exch_order_id", fills.exchange_order_id)
        else:
            broker.redis_o.hset(broker_order_id, "price", str(fills.fill_price))
            broker.redis_o.hset(broker_order_id, "exch_order_id", fills.exchange_order_id)
        broker.redis_o.hset(broker_order_id, "quantity", str(fills.order_size))
        broker.redis_o.hset(broker_order_id, "status", fills.status.name)
    return fills


@log_execution_time
@validate_inputs(
    symbol_name=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    exchange=lambda x: isinstance(x, str) and len(x.strip()) > 0,
)
def get_linked_options(
    broker: BrokerBase, symbol_name: str, expiry: Optional[str] = None, exchange: str = "NSE"
) -> list[str]:
    """Get option chain with enhanced error handling.

    Args:
        broker: Broker instance
        symbol_name: Symbol name either long_name or short_name
        expiry: Optional expiry formatted as yyyymmdd
        exchange: Exchange name

    Returns:
        list[str]: List containing longnames of available option symbols

    Raises:
        ValidationError: If input parameters are invalid
        SymbolError: If symbol mapping fails
    """
    symbol_name_opt = symbol_name.replace("_STK_", "_OPT_").replace("_IND_", "_OPT_")
    exchange = broker.map_exchange_for_api(symbol_name_opt, exchange)
    symbols = list(broker.exchange_mappings[exchange]["symbol_map"].keys())
    short_symbol = symbol_name.split("_")[0]
    linked_options = []
    if expiry:
        try:
            parsed_expiry = parse_datetime(expiry)
            expiry_parsed = True
        except (ValueError, TypeError):
            parsed_expiry = None
            expiry_parsed = False
        if expiry_parsed and parsed_expiry is not None:
            expiry_str = parsed_expiry.strftime("%Y%m%d")
            symbols = [s for s in symbols if s.startswith(f"{short_symbol}_OPT_{expiry_str}")]
        else:
            symbols = []
    else:
        symbols = [s for s in symbols if s.startswith(f"{short_symbol}_OPT_")]
    linked_options = list(symbols)
    return linked_options


def get_linked_futures(symbol_name: str, expiry: str = "", file_path: str = "") -> list[str]:
    """Get futures chain

    Args:
        symbol_name (str): symbol name either long_name or short_name
        expiry (str, optional): Expiry formatted as yyyymmdd. Defaults to None.
        file_path (str, optional): Full path to symbols file. Defaults to None.

    Returns:
        list[str]: List containing longnames of available option symbols
    """
    if file_path:
        symbols = pd.read_csv(file_path)
    else:
        return []
    short_symbol = symbol_name.split("_")[0]
    linked_futures = []
    if expiry:
        symbols = symbols.loc[symbols["long_symbol"].str.contains(f"\\b{short_symbol}_FUT_{expiry}"), "long_symbol"]
    else:
        symbols = symbols.loc[symbols["long_symbol"].str.contains(f"\\b{short_symbol}_FUT_"), "long_symbol"]
    linked_futures = list(symbols)
    return linked_futures


def get_latest_symbol_file(directory_path="/home/psharma/onedrive/data/static/symbols"):
    pattern = "*_symbols.csv"
    files = glob.glob(os.path.join(directory_path, pattern))
    dates = [int(os.path.basename(file).split("_")[0]) for file in files]
    latest_index = dates.index(max(dates))
    latest_file = files[latest_index] if files else None
    return latest_file


def get_universe(
    file_path: Optional[str] = "", product_types=["OPT", "FUT"], exchanges=["N", "B"], expiry: Optional[str] = None
) -> List[str]:
    """Get list of all symbols for a given product type and exchange

    Args:
        file_path (str, optional): _description_. Defaults to empty string.
        product_types (list, optional): _description_. Defaults to ["OPT", "FUT"].
        exchanges (list, optional): _description_. Defaults to ["N", "B"].
        expiry (str, optional): expiry formatted as yyyymmdd

    Returns:
        list: list of long names
    """
    if not file_path:
        file_path = get_latest_symbol_file()
    if file_path is None:
        raise FileNotFoundError("No symbol files found")
    symbols = pd.read_csv(file_path)
    out: List[str] = []

    for exchange in exchanges:
        exchange = exchange[0]
        for prod_type in product_types:
            # Filter condition for prod_type and exchange
            condition = (symbols["long_symbol"].str.contains(f"_{prod_type}_")) & (symbols["Exch"] == exchange)

            # Add condition for expiry if it's not None
            if expiry is not None:
                condition &= symbols["long_symbol"].str.contains(expiry)

            # Always get a Series by using proper pandas indexing, then convert to list
            matching_rows = symbols.loc[condition]
            if not matching_rows.empty:
                temp = matching_rows["long_symbol"].tolist()
            else:
                temp = []
            out = out + temp
    return out


def get_unique_short_symbol_names(exchange: str, sec_type: str, file_path: str = "") -> list[str]:
    """Get a list of all short symbol names for a specified exchange and security type.

    Args:
        exchange (str): Exchange name. Either 'N' for NSE or 'M' for MCX.
        sec_type (str): Security type like 'IND', 'STK', 'FUT', 'OPT'.
        file_path (str, optional): Path to symbols file. Defaults to an empty string.

    Returns:
        list[str]: List of short symbol names.
    """
    if not file_path:
        trading_logger.log_error("File path is empty. Please provide a valid file path.")
        return []

    if os.path.isdir(file_path):
        # Get list of files in directory sorted by modification time in descending order
        files = sorted(os.listdir(file_path), reverse=True)
        if files:
            # Read CSV from the first file in the sorted list
            first_file = files[0]
            symbols = pd.read_csv(os.path.join(file_path, first_file))
        else:
            trading_logger.log_error("No files found in the specified directory.")
            return []
    elif os.path.isfile(file_path):
        # Read CSV from the given file
        symbols = pd.read_csv(file_path)
    else:
        trading_logger.log_error("Invalid file path provided.")
        return []

    # Ensure required columns exist
    if "Exch" not in symbols.columns or "long_symbol" not in symbols.columns:
        trading_logger.log_error("Missing required columns 'Exch' or 'long_symbol' in the symbols file.")
        return []

    # Filter and extract unique short names
    # Ensure long_symbol column is treated as strings
    symbols["long_symbol"] = symbols["long_symbol"].astype(str)
    filtered_symbols = symbols[(symbols.Exch == exchange) & (symbols.long_symbol.str.contains(f"_{sec_type}"))]

    # Extract and process the long_symbol column as pandas Series
    long_symbol_series = pd.Series(filtered_symbols["long_symbol"], dtype=str)
    short_names = long_symbol_series.str.split("_").str[0].unique()
    # Ensure short_names is always iterable before converting to list
    if isinstance(short_names, (list, tuple, np.ndarray)):
        return list(short_names)
    else:
        # Handle scalar case
        return [short_names] if short_names is not None else []


@log_execution_time
@retry_on_error(max_retries=2, delay=1.0, backoff_factor=2.0)
@validate_inputs(
    long_symbol=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    exchange=lambda x: isinstance(x, str) and len(x.strip()) > 0,
)
def get_margin_zerodha(broker: BrokerBase, long_symbol: str, proxy: str = "", exchange="NSE") -> int:
    """Get margin from Zerodha for option contracts with enhanced error handling.

    Args:
        broker: Broker instance
        long_symbol: Long symbol name
        proxy: Optional proxy specified as ipaddress:port
        exchange: Exchange name

    Returns:
        int: Margin for contract

    Raises:
        ValidationError: If input parameters are invalid
        MarginError: If margin calculation fails
        NetworkError: If network request fails
    """
    # https://stackoverflow.com/questions/56591881/web-scrape-with-multiple-inputs-and-collect-total-margin-required
    symbol = long_symbol.split("_")[0]
    strike_price = float(long_symbol.split("_")[4])
    option_type = long_symbol.split("_")[3]
    expiry = long_symbol.split("_")[2]

    BASE_URL = "https://zerodha.com/margin-calculator/SPAN"
    scrip = symbol + dt.datetime.strptime(expiry, "%Y%m%d").strftime("%y%b").upper()
    z_option_type = "CE" if option_type == "CALL" else "PE"
    strike_price_str = ("%f" % strike_price).rstrip("0").rstrip(".")
    #     long_symbol = f'{symbol}_OPT_{expiry}_{option_type}_{strike_price}'
    quantity = broker.get_min_lot_size(long_symbol, exchange)
    payload = {
        "action": "calculate",
        "exchange[]": "NFO",
        "product[]": "OPT",
        "scrip[]": scrip,
        "option_type[]": z_option_type,
        "strike_price[]": strike_price_str,
        "qty[]": quantity,
        "trade[]": "sell",
    }
    try:
        session = Session()
        if proxy:
            proxies = {"http": "https://" + proxy}
            res = session.post(BASE_URL, data=payload, proxies=proxies)
        else:
            res = session.post(BASE_URL, data=payload)
        data = res.json()
        try:
            output = data["total"]["total"]
            output = int(output)
        except Exception:
            output = 1000000
        trading_logger.log_info(f"margin for {long_symbol}:{output}")
        session.close()
        return output
    except Exception:
        trading_logger.log_error("Error")
        return 1000000


def get_margin_samco(long_symbol: str, driver_path: str = "", proxy: Optional[str] = "") -> int:
    """Get margin from SAMCO for option contracts

    Args:
        long_symbol (str): long symbol
        driver_path (str, optional): path to firefox driver. Defaults to None.
        proxy (str, optional): proxy address, specified as ipaddress:port . Defaults to None.

    Returns:
        int: margin
    """
    output = 1000000
    strike = long_symbol.split("_")[4]
    type = long_symbol.split("_")[3].lower()
    expiry = long_symbol.split("_")[2]
    symbol = long_symbol.split("_")[0]

    driver = None
    try:
        margin_url = "https://www.samco.in/span"
        op = webdriver.FirefoxOptions()
        if not driver_path:
            driver_path = "/home/psharma/Downloads/geckodriver"
        if proxy:
            op.add_argument("--proxy-server=%s" % proxy)
        op.add_argument("--headless")
        driver = webdriver.Firefox(executable_path=driver_path, options=op)
        driver.get(margin_url)
        driver.implicitly_wait(10)
        reset = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//a[@class='close-icon sprite-icon'])[1]"))
        )
        driver.execute_script("arguments[0].click();", reset)
        # reset.click()
        exchange = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//select[@id='exchange'])[1]"))
        )
        exchange.send_keys("NFO")
        product = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//select[@id='product'])[1]"))
        )
        product.send_keys("Options")
        underlying = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//select[@id='underlying'])[1]"))
        )
        underlying.send_keys(symbol)
        expiry_element = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//select[@id='expiry'])[1]"))
        )
        expiry_formatted = dt.datetime.strptime(expiry, "%Y%m%d").strftime("%d%b%y").upper()
        expiry_element.send_keys(expiry_formatted)

        strike_1 = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//select[@id='strike_price'])[1]"))
        )
        time.sleep(2)
        strike_1.send_keys(strike)

        sell = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//label[normalize-space()='Sell'])[1]"))
        )
        driver.execute_script("arguments[0].click();", sell)
        # sell.click()

        if type == "put":
            opt_type = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "(//select[@name='option'])[1]"))
            )
            opt_type.send_keys("PUTS")
        add = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//button[normalize-space()='Add'])[1]"))
        )
        driver.execute_script("arguments[0].click();", add)
        wait = 0
        while (
            int(
                "".join(
                    list(filter(str.isdigit, (driver.find_element("xpath", "(//span[@id='total_margin'])[1]").text)))
                )
            )
            == 0
            and wait < 20
        ):
            wait = wait + 1
            time.sleep(1)
        try:
            output = int(
                "".join(
                    list(filter(str.isdigit, (driver.find_element("xpath", "(//span[@id='total_margin'])[1]").text)))
                )
            )
        except Exception:
            output = 100000000
        trading_logger.log_info(f"margin for {long_symbol}:{output}")
        if driver:
            driver.close()
    except Exception:
        trading_logger.log_error("Error")
        if driver:
            driver.close()
        if proxy is not None:
            proxy = get_free_proxy(driver_path)
    return output


def get_margin_5p(long_symbol, strike_price, type, expiry, driver_path: str = "", proxy: Optional[str] = "") -> int:
    output = 1000000
    strike = long_symbol.split("_")[4]
    type = long_symbol.split("_")[3].lower()
    expiry = long_symbol.split("_")[2]
    symbol = long_symbol.split("_")[0]

    driver = None
    try:
        margin_url = "https://zerodha.com/margin-calculator/SPAN"
        op = webdriver.FirefoxOptions()
        if not driver_path:
            driver_path = "/home/psharma/Downloads/geckodriver"
        if proxy:
            op.add_argument("--proxy-server=%s" % proxy)
        op.add_argument("--headless")
        driver = webdriver.Firefox(executable_path=driver_path, options=op)
        driver.get(margin_url)
        driver.implicitly_wait(10)
        # driver.find_element_by_xpath("(//a[@id='btnReset'])[1]").click()
        reset = WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, "(//input[@id='reset'])[1]")))
        reset.click()
        segment = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//select[@id='exchange'])[1]"))
        )
        segment.send_keys("NFO")
        product = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//select[@id='product'])[1]"))
        )
        product.send_keys("Options")
        symbol_box = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//span[@id='select2-scrip-container'])[1]"))
        )
        expiry_formatted = dt.datetime.strptime(expiry, "%Y%m%d").strftime("%d-%b-%y").upper()
        symbol_formatted = f"{symbol} {expiry_formatted}"
        symbol_box.click()
        symbol_txtbox = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//input[@role='textbox'])[1]"))
        )
        symbol_txtbox.send_keys(symbol_formatted)
        symbol_txtbox.send_keys(Keys.DOWN)
        symbol_txtbox.send_keys(Keys.ENTER)
        if type == "put":
            opt_type = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "(//select[@id='option_type'])[1]"))
            )
            opt_type.send_keys("Puts")
            # opt_type.send_keys(Keys.ENTER)
        else:
            pass
        strike = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "(//input[@id='strike_price'])[1]"))
        )
        strike_price = ("%f" % strike_price).rstrip("0").rstrip(".")
        strike.send_keys(strike_price)
        side = WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, "(//input[@value='sell'])[1]")))
        side.click()
        add = WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, "(//input[@value='Add'])[1]")))
        add.click()
        wait = 0
        while (
            int(
                "".join(
                    list(filter(str.isdigit, (driver.find_element("xpath", "(//span[@class='val total'])[1]").text)))
                )
            )
            == 0
            and wait < 20
        ):
            wait = wait + 1
            time.sleep(1)
        try:
            output = int(
                "".join(
                    list(filter(str.isdigit, (driver.find_element("xpath", "(//span[@class='val total'])[1]").text)))
                )
            )
        except Exception:
            output = 100000000
        trading_logger.log_info(f"margin for {long_symbol}:{output}")
        if driver:
            driver.close()
    except Exception:
        if driver:
            driver.close()
        if proxy is not None:
            proxy = get_free_proxy(driver_path)
    return output


def get_free_proxy(driver_path: str = "") -> Optional[str]:
    """Get working proxy. This requires firefox driver (geckodriver) to be available in specified driver path

    Args:
        driver_path (str, optional): _description_. Defaults to None.

    Returns:
        str: proxy as ipaddress:port
    """
    op = webdriver.FirefoxOptions()
    op.add_argument("--headless")
    if not driver_path:
        driver_path = "/home/psharma/Downloads/geckodriver"
    driver = webdriver.Firefox(executable_path=driver_path, options=op)
    driver.get("https://sslproxies.org")
    table = driver.find_element(By.TAG_NAME, "table")
    thead = table.find_element(By.TAG_NAME, "thead").find_elements(By.TAG_NAME, "th")
    tbody = table.find_element(By.TAG_NAME, "tbody").find_elements(By.TAG_NAME, "tr")

    headers = []
    for th in thead:
        headers.append(th.text.strip())

    proxies = []
    for tr in tbody:
        proxy_data = {}
        tds = tr.find_elements(By.TAG_NAME, "td")
        for i in range(len(headers)):
            proxy_data[headers[i]] = tds[i].text.strip()
        proxies.append(proxy_data)
    driver.close()

    selected_proxy_index = None
    for i in range(0, len(proxies)):
        try:
            if proxies[i]["Country"] in ["India", "Singapore"]:
                login_url = "https://login.5paisa.com/lwp"
                op = webdriver.FirefoxOptions()
                PROXY = proxies[i]["IP Address"] + ":" + proxies[i]["Port"]
                op.add_argument("--proxy-server=%s" % PROXY)
                op.add_argument("--headless")
                dr = webdriver.Firefox(executable_path=driver_path, options=op)
                dr.get(login_url)
                if WebDriverWait(dr, 5).until(EC.visibility_of_element_located((By.ID, "loginUser"))):
                    dr.close()
                    selected_proxy_index = i
                    break
        except Exception:
            trading_logger.log_error("Error")
            continue

    if selected_proxy_index is None:
        trading_logger.log_warning("No working proxy found, returning default")
        return None

    trading_logger.log_info(f"Proxy selected: {proxies[selected_proxy_index]}")
    return (
        proxies[selected_proxy_index].get("IP Address", "127.0.0.1")
        + ":"
        + proxies[selected_proxy_index].get("Port", "0")
    )


@log_execution_time
@validate_inputs(
    long_symbol=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    exchange=lambda x: isinstance(x, str) and len(x.strip()) > 0,
)
def get_yield(broker: BrokerBase, long_symbol: str, proxy=None, exchange="NSE") -> list[float]:
    """Get yield to expiry of an option contract with enhanced error handling.

    Args:
        broker: Broker instance
        long_symbol: Long symbol name
        proxy: Optional proxy of form ipaddress:port
        exchange: Exchange name

    Returns:
        list[float]: [midprice, bid, ask, yield, margin]

    Raises:
        ValidationError: If input parameters are invalid
        MarketDataError: If price retrieval fails
        MarginError: If margin calculation fails
    """
    mid = 0.0
    margin = get_margin_zerodha(broker, long_symbol, proxy)
    size = broker.get_min_lot_size(long_symbol, exchange)
    quote = broker.get_quote(long_symbol, exchange)
    if quote.bid > 0 and quote.ask > 0:
        mid = (quote.bid + quote.ask) / 2
    mid = mid if mid > 0 else -1
    if size is not None and quote.bid > 0 and quote.ask > 0:
        max_return = (mid * size) / margin
        return [mid, quote.bid, quote.ask, max_return, margin]
    else:
        return [mid, quote.bid, quote.ask, 100, margin]


def review_price_history(symbol: str, exchange: str = "NSE", count: int = 1):
    """Retrieve the last `count` prices for a symbol from Redis."""
    global mds_history
    price_history_key = f"price_history:{symbol}~{exchange}"
    price_history = cast(list[str], mds_history.zrevrange(price_history_key, 0, 0))
    return [json.loads(price) for price in price_history]


def listen_with_timeout(pubsub, symbol, timeout=60):
    start_time = time.time()
    while time.time() - start_time <= timeout:
        message = pubsub.get_message()  # Non-blocking
        if message:
            if message["type"] == "message" and json.loads(message["data"])["symbol"] == symbol:
                return message
        time.sleep(0.1)  # Prevent busy-waiting
    return None  # Return None if no valid message is received


def is_within_60_seconds(json_price):
    # Parse the timestamp string into a datetime object
    price = Price.from_dict(json_price)
    try:
        try:
            timestamp = parse_datetime(price.timestamp)
            timestamp_parsed = True
        except (ValueError, TypeError):
            timestamp = None
            timestamp_parsed = False
        if not timestamp_parsed:
            return False  # Return False if timestamp parsing failed
    except ValueError:
        return False  # Return False if the timestamp format is invalid
    # Ensure timestamp is a datetime object for type checker
    assert isinstance(timestamp, dt.datetime), f"Expected datetime object, got {type(timestamp)}"
    now = dt.datetime.now()
    return now <= timestamp + dt.timedelta(seconds=60)


def _get_price_mds(brok: BrokerBase, symbol: str, exchange: str = "NSE", channel: str = "mds"):
    mapped_exchange = brok.map_exchange_for_db(symbol, exchange)
    history = review_price_history(symbol, mapped_exchange)
    if len(history) == 1:
        if is_within_60_seconds(history[0]):
            return Price.from_dict(history[0])
        # Stale MDS data: request re-subscription, wait briefly for a fresh tick,
        # then return whatever is available (avoids REST API rate-limit errors).
        request = {
            "action": "subscribe",
            "symbol": symbol,
            "exchange": mapped_exchange,
            "channel": channel,
        }
        mds_history.publish("subscription_requests", json.dumps(request))
        trading_logger.log_info(
            f"symbol:{symbol} MDS data stale, re-subscribing; returning last known price"
        )
        return Price.from_dict(history[0])
    # No MDS history yet — subscribe and fall back to REST only for the first call
    trading_logger.log_info(
        f"symbol:{symbol} subscription received by {brok.broker.name}. exchange received in request:{exchange}, exchange sent in broker request:{mapped_exchange}"
    )
    out = get_price(brok, symbol, exchange=exchange)
    request = {
        "action": "subscribe",
        "symbol": symbol,
        "exchange": mapped_exchange,
        "channel": channel,
    }
    mds_history.publish("subscription_requests", json.dumps(request))
    return out


@log_execution_time
@retry_on_error(max_retries=3, delay=0.5, backoff_factor=2.0)
def get_price(
    brokers: Union[List[BrokerBase], BrokerBase],
    long_symbol: str,
    checks: List[str] = ["bid", "ask", "last", "prior_close"],
    attempts: int = 3,
    exchange="NSE",
    mds: Optional[str] = None,
) -> Price:
    def sum_prices(prices: List[Price]) -> Price:
        if not prices:
            return Price()  # Return an empty Price if the list is empty

        return Price(
            bid=sum(price.bid for price in prices),
            ask=sum(price.ask for price in prices),
            bid_volume=sum(price.bid_volume for price in prices),
            ask_volume=sum(price.ask_volume for price in prices),
            prior_close=sum(price.prior_close for price in prices),
            last=sum(price.last for price in prices),
            symbol=prices[0].symbol,  # Assuming symbol remains the same for all prices
        )

    if isinstance(brokers, BrokerBase):
        brokers = [brokers]

    if any(getattr(getattr(broker, "broker", None), "name", "") == "DHAN" for broker in brokers):
        attempts = 1

    if "?" not in long_symbol:
        out = Price()
        out.symbol = long_symbol
        for attempt in range(attempts):
            for broker in brokers:
                try:
                    mapped_exchange = broker.map_exchange_for_db(long_symbol, exchange)
                    if mds:
                        price = _get_price_mds(broker, long_symbol, mapped_exchange, channel=mds)
                    else:
                        price = broker.get_quote(long_symbol, mapped_exchange)
                    out.update(price)
                    if all(not math.isnan(getattr(out, check)) for check in checks):
                        trading_logger.log_debug(
                            f"Successfully retrieved price for {long_symbol}",
                            {
                                "symbol": long_symbol,
                                "exchange": exchange,
                                "attempt": attempt + 1,
                                "broker": broker.broker.name if hasattr(broker, "broker") else "unknown",
                            },
                        )
                        return out
                except Exception as e:
                    err_msg = f"{type(e).__name__}: {getattr(e, 'message', str(e))}"
                    context = {
                        "symbol": long_symbol,
                        "exchange": exchange,
                        "attempt": attempt + 1,
                        "broker": broker.broker.name if hasattr(broker, "broker") else "unknown",
                        "error": err_msg,
                    }
                    is_final_attempt = attempt == attempts - 1 and broker == brokers[-1]
                    if is_final_attempt:
                        trading_logger.log_error(
                            f"Failed to get price for {long_symbol} from {broker.broker.name if hasattr(broker, 'broker') else 'unknown'}",
                            e,
                            context,
                        )
                    else:
                        trading_logger.log_info(
                            f"Failed to get price for {long_symbol} from {broker.broker.name if hasattr(broker, 'broker') else 'unknown'}",
                            context,
                        )
                    continue
    else:
        out_list = []
        symbols = parse_combo_symbol(long_symbol)
        for symbol, size in symbols.items():
            out = Price()
            valid_price_found = False
            for attempt in range(attempts):
                for broker in brokers:
                    try:
                        mapped_exchange = broker.map_exchange_for_db(symbol, exchange)
                        if mds:
                            price = _get_price_mds(broker, symbol, mapped_exchange, channel=mds)
                        else:
                            price = broker.get_quote(symbol, mapped_exchange)
                        out.update(price, size)
                        if all(not math.isnan(getattr(out, check)) for check in checks):
                            valid_price_found = True
                            break  # Stop attempts for this symbol if a valid price is found
                    except Exception as e:
                        err_msg = f"{type(e).__name__}: {getattr(e, 'message', str(e))}"
                        context = {
                            "symbol": symbol,
                            "exchange": exchange,
                            "attempt": attempt + 1,
                            "broker": broker.broker.name if hasattr(broker, "broker") else "unknown",
                            "error": err_msg,
                        }
                        is_final_attempt = attempt == attempts - 1 and broker == brokers[-1]
                        if is_final_attempt:
                            trading_logger.log_error(
                                f"Failed to get price for {symbol} from {broker.broker.name if hasattr(broker, 'broker') else 'unknown'}",
                                e,
                                context,
                            )
                        else:
                            trading_logger.log_info(
                                f"Failed to get price for {symbol} from {broker.broker.name if hasattr(broker, 'broker') else 'unknown'}",
                                context,
                            )
                        continue
                if valid_price_found:
                    break  # Stop attempts for other brokers for this symbol
            out_list.append(out)
        out = sum_prices(out_list)
        out.symbol = long_symbol

    trading_logger.log_debug(
        f"Retrieved price for {long_symbol}", {"symbol": long_symbol, "exchange": exchange, "final_price": str(out)}
    )
    return out


# ---------------------------------------------------------------------------
# Unified price cache: (symbol, time_key) -> price. Used for EOD and intraday.
# time_key: "YYYYMMDD_1529" for EOD, "YYYYMMDD_HHMM" for intraday. No TTL.
# ---------------------------------------------------------------------------
_price_cache: Dict[Tuple[str, str], float] = {}
_GET_HISTORICAL_CALL_LOG_FILE = os.path.join(os.path.expanduser("~/logs"), "get_historical_calls.log")
_get_historical_call_count = 0
_get_historical_call_lock = threading.Lock()

try:
    from ohlcutils.data import load_symbol
    from ohlcutils.enums import Periodicity

    _ohlcutils_available = True
except ImportError:
    _ohlcutils_available = False
    load_symbol = None  # type: ignore[assignment, misc]
    Periodicity = None  # type: ignore[assignment, misc]


def get_price_cache(symbol: str, time_key: str) -> Optional[float]:
    """Return cached price for (symbol, time_key) or None."""
    return _price_cache.get((symbol, time_key))


def set_price_cache(symbol: str, time_key: str, value: Optional[float]) -> None:
    """Cache price for (symbol, time_key). No-op if value is None or nan."""
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return
    _price_cache[(symbol, time_key)] = float(value)


def get_historical_call_count() -> int:
    """Return the process-level count of get_historical calls logged to get_historical_calls.log."""
    with _get_historical_call_lock:
        return _get_historical_call_count


def _log_get_historical_call(
    broker: object,
    symbols: str,
    date_start: str,
    date_end: str,
    time_key: str,
    periodicity: str,
) -> None:
    """Log get_historical call to get_historical_calls.log (used only from get_historical_close_at_time)."""
    global _get_historical_call_count
    ts = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    broker_name = type(broker).__name__ if broker is not None else "None"
    with _get_historical_call_lock:
        try:
            os.makedirs(os.path.dirname(_GET_HISTORICAL_CALL_LOG_FILE), exist_ok=True)
            with open(_GET_HISTORICAL_CALL_LOG_FILE, "a+", encoding="utf-8") as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                f.seek(0)
                lines = f.readlines()
                if lines:
                    last = lines[-1].strip().split(",", 1)[0]
                    try:
                        count = int(last) + 1
                    except (TypeError, ValueError):
                        count = 1
                else:
                    count = 1
                _get_historical_call_count = count
                line = f"{count},{ts},{broker_name},{symbols},{date_start},{date_end},{time_key},{periodicity}\n"
                f.write(line)
                f.flush()
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        except Exception as e:
            trading_logger.log_debug(f"Failed to log get_historical call: {e}")


def get_historical_close_at_time(
    broker: BrokerBase,
    symbol: str,
    exchange: str,
    at: Union[dt.datetime, dt.date, str, pd.Timestamp],
    *,
    refresh_mapping: bool = False,
) -> float:
    """
    Get historical close price at a specific time or EOD for a date.

    - If `at` is a date (or date-only str): return EOD close (15:29 bar) for that date.
    - If `at` is a datetime with time: return close of 1m bar at or just before that time.

    Priority: (1) cache, (2) ohlcutils load_symbol if available, (3) broker.get_historical.
    Logs to ~/logs/get_historical_calls.log only when broker API is used.
    Returns float('nan') on failure.
    """
    target_dt: dt.datetime
    date_str: str
    time_key: str
    try:
        if isinstance(at, pd.Timestamp):
            at = at.to_pydatetime()
        if isinstance(at, dt.date) and not isinstance(at, dt.datetime):
            d = at
            target_dt = dt.datetime.combine(d, dt.time(15, 29, 0))
            date_str = d.strftime("%Y-%m-%d")
            time_key = d.strftime("%Y%m%d") + "_1529"
        elif isinstance(at, str):
            at_parsed = parse_datetime(at)
            if hasattr(at_parsed, "hour") and at_parsed.hour == 0 and at_parsed.minute == 0:
                d = at_parsed.date()
                target_dt = dt.datetime.combine(d, dt.time(15, 29, 0))
                date_str = d.strftime("%Y-%m-%d")
                time_key = d.strftime("%Y%m%d") + "_1529"
            else:
                target_dt = at_parsed.replace(tzinfo=None) if at_parsed.tzinfo else at_parsed
                target_dt = target_dt.replace(second=0, microsecond=0)
                date_str = target_dt.strftime("%Y-%m-%d")
                time_key = target_dt.strftime("%Y%m%d_%H%M")
        else:
            at_dt = cast(dt.datetime, at)
            target_dt = at_dt.replace(tzinfo=None) if at_dt.tzinfo else at_dt
            target_dt = target_dt.replace(second=0, microsecond=0)
            if target_dt.hour == 0 and target_dt.minute == 0:
                target_dt = dt.datetime.combine(target_dt.date(), dt.time(15, 29, 0))
                time_key = target_dt.strftime("%Y%m%d") + "_1529"
            else:
                time_key = target_dt.strftime("%Y%m%d_%H%M")
            date_str = target_dt.strftime("%Y-%m-%d")
    except Exception:
        return float("nan")

    cached = get_price_cache(symbol, time_key)
    if cached is not None:
        return cached

    if _ohlcutils_available and load_symbol is not None and Periodicity is not None:
        try:
            date_str_fmt = date_str if "-" in date_str else f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]}"
            df = load_symbol(
                symbol,
                start_time=date_str_fmt,
                end_time=date_str_fmt + " 23:59:59",
                src=Periodicity.PERMIN,
                exchange=exchange,
                market_close_time="15:30:00",
            )
            if df is not None and not df.empty and "close" in df.columns:
                import pytz

                tz = pytz.timezone("Asia/Kolkata")
                target_tz = tz.localize(target_dt) if target_dt.tzinfo is None else target_dt
                index = df.index
                if getattr(index, "tz", None) is None:
                    df_index_tz = getattr(index, "tz_localize", lambda t: index)(tz)
                else:
                    df_index_tz = index
                filtered = df[df_index_tz <= target_tz]
                if not filtered.empty:
                    close_price = float(filtered["close"].iloc[-1])
                    set_price_cache(symbol, time_key, close_price)
                    return close_price
        except Exception:
            pass

    try:
        _log_get_historical_call(broker, symbol, date_str, date_str, time_key = time_key,periodicity="1m")
        hist = broker.get_historical(
            symbols=symbol,
            date_start=date_str,
            date_end=date_str,
            exchange=exchange,
            periodicity="1m",
            market_close_time="15:30:00",
            refresh_mapping=refresh_mapping,
        )
        if symbol.startswith("NIFTY_"):
            keys_to_replace = [k for k in hist if k.startswith("NSENIFTY_")]
            for old_key in keys_to_replace:
                new_key = old_key.replace("NSENIFTY_", "NIFTY_", 1)
                hist[new_key] = hist.pop(old_key)
        data = hist.get(symbol, [])
        if not data:
            return float("nan")
        data = sorted(data, key=lambda x: x.date)
        target_naive = target_dt.replace(tzinfo=None) if target_dt.tzinfo else target_dt
        candidates = []
        for x in data:
            x_naive = x.date
            if getattr(x_naive, "tzinfo", None) is not None:
                x_naive = x_naive.replace(tzinfo=None)  # type: ignore[union-attr]
            if x_naive <= target_naive:
                candidates.append((x_naive, x))
        if candidates:
            result = float(candidates[-1][1].close)
        else:
            result = float(data[0].close)
        set_price_cache(symbol, time_key, result)
        return result
    except Exception:
        return float("nan")


def get_price_at_time(
    broker: BrokerBase,
    symbol: str,
    exchange: str = "NSE",
    as_of: Optional[Union[dt.datetime, dt.date, str, pd.Timestamp]] = None,
    *,
    mds: Optional[str] = None,
    last: bool = True,
    refresh_mapping: bool = False,
) -> Optional[float]:
    """Price of symbol at a time. as_of=None => live mid/last; as_of=datetime => historical close. Returns None on failure."""
    if as_of is not None:
        price = get_historical_close_at_time(broker, symbol, exchange, as_of, refresh_mapping=refresh_mapping)
        return None if math.isnan(price) else float(price)
    time_key = dt.datetime.now().replace(second=0, microsecond=0).strftime("%Y%m%d_%H%M")
    cached = get_price_cache(symbol, time_key)
    if cached is not None:
        return float(cached)
    price = get_mid_price([broker], symbol, exchange=exchange, mds=mds, last=last)
    if math.isnan(price):
        return None
    set_price_cache(symbol, time_key, price)
    return float(price)


def get_future_underlying_price(
    broker: BrokerBase,
    future_symbol: str,
    exchange: str = "NSE",
    as_of: Optional[Union[dt.datetime, dt.date, str, pd.Timestamp]] = None,
    *,
    mds: Optional[str] = None,
    last: bool = True,
) -> Optional[float]:
    """Underlying price for a future. Index future => IND; else => STK. No interpolation. Returns None on failure."""
    if "_FUT_" not in future_symbol:
        return None
    base = future_symbol.split("_")[0]
    is_index = "NIFTY" in future_symbol or "SENSEX" in future_symbol
    underlying = f"{base}_IND___" if is_index else f"{base}_STK___"
    return get_price_at_time(broker, underlying, exchange, as_of=as_of, mds=mds, last=last)


def get_mid_price(brokers: list[BrokerBase], long_symbol: str, exchange="NSE", mds: Optional[str] = None, last=True):
    if isinstance(brokers, BrokerBase):
        brokers = [brokers]
    try:
        quote = get_price(brokers, long_symbol, exchange=exchange, mds=mds)
    except Exception as e:
        trading_logger.log_error(f"Error getting price for {long_symbol} on {exchange}: {e}")
        return float("nan")
    mid = float("nan")
    if quote.bid > 0 and quote.ask > 0:
        mid = (quote.bid + quote.ask) / 2
        mapped_exchange = brokers[0].map_exchange_for_api(long_symbol, exchange)
        ticksize = brokers[0].exchange_mappings[mapped_exchange]["contracttick_map"].get(long_symbol, 0.05)
        mid = round(mid / ticksize) * ticksize
        mid = round(mid, 2)  # <-- Add this line to ensure two decimal places
    mid = mid if mid > 0 else float("nan")
    if last and math.isnan(mid):
        return quote.last
    return mid


def get_option_underlying_price(
    brokers: list[BrokerBase],
    symbol: str,
    opt_expiry: str,
    fut_expiry: Optional[str] = "",
    exchange="NSE",
    mds: Optional[str] = None,
    last=True,
    as_of: Optional[Union[dt.datetime, dt.date, str, pd.Timestamp]] = None,
) -> Optional[float]:
    """Retrieve underlying price for a symbol; interpolates for index options when fut_expiry given.

    When as_of is None: uses current mid (or last) price and now() for interpolation.
    When as_of is set: uses historical close at as_of (1m bar close at or before as_of) and
    as_of for interpolation; index options use IND + FUT close and t_o/t_f from as_of.

    Args:
        symbol: Symbol name (e.g. NIFTY_OPT_... or BASE_FUT_...).
        opt_expiry: Expiry date of option (yyyymmdd). Not parsed from symbol.
        fut_expiry: Expiry of underlying future (yyyymmdd). Empty for index => IND only; for index with fut => interpolate.
        exchange: Exchange (NSE/BSE).
        mds: Optional MDS.
        last: If True, use last price when mid not available (current path only).
        as_of: If set, use historical close at this time; else current prices and now().

    Returns:
        Price of underlying, or None on failure.
    """
    base = symbol.split("_")[0]
    is_index = "NIFTY" in symbol or "SENSEX" in symbol

    if as_of is not None:
        # Historical path: use close at as_of (via 1m bars)
        broker = brokers[0] if brokers else None
        if broker is None:
            return None
        if is_index and fut_expiry:
            underlying_ind = f"{base}_IND___"
            underlying_fut = f"{base}_FUT_{fut_expiry}__"
            price_u = get_price_at_time(broker, underlying_ind, exchange, as_of=as_of)
            price_f = get_price_at_time(broker, underlying_fut, exchange, as_of=as_of)
            if price_u is None or price_f is None:
                return None
            as_of_dt = parse_datetime(as_of)
            t_o = calc_fractional_business_days(
                as_of_dt, dt.datetime.strptime(opt_expiry + " 15:30:00", "%Y%m%d %H:%M:%S")
            )
            t_f = calc_fractional_business_days(
                as_of_dt, dt.datetime.strptime(fut_expiry + " 15:30:00", "%Y%m%d %H:%M:%S")
            )
            if t_f and t_f > 0:
                price_f = price_u + (price_f - price_u) * t_o / t_f
            return price_f
        if is_index and not fut_expiry:
            underlying_ind = f"{base}_IND___"
            return get_price_at_time(broker, underlying_ind, exchange, as_of=as_of)
        # Non-index: FUT with expiry = option expiry
        underlying_fut = f"{base}_FUT_{opt_expiry}__"
        return get_price_at_time(broker, underlying_fut, exchange, as_of=as_of)

    # Current path: mid (or last) and now()
    if not fut_expiry:
        underlying = base + "_IND___" if is_index else base + "_STK___"
        price_f = get_mid_price(brokers, underlying, exchange=exchange, mds=mds, last=last)
        trading_logger.log_debug(

            f"get_option_underlying_price: no fut_expiry underlying={underlying} price_f={price_f}"

        )
    else:
        underlying = base + "_FUT_" + fut_expiry + "__"
        price_f = get_mid_price(brokers, underlying, exchange=exchange, mds=mds, last=last)
        if math.isnan(price_f):
            return None
        trading_logger.log_debug(

            f"get_option_underlying_price: fut_expiry={fut_expiry} underlying={underlying} price_f (fut)={price_f}"

        )
    if math.isnan(price_f):
        return None

    if is_index and fut_expiry:
        t_o = calc_fractional_business_days(
            dt.datetime.now(), dt.datetime.strptime(opt_expiry + " 15:30:00", "%Y%m%d %H:%M:%S")
        )
        t_f = calc_fractional_business_days(
            dt.datetime.now(), dt.datetime.strptime(fut_expiry + " 15:30:00", "%Y%m%d %H:%M:%S")
        )
        underlying_ind = f"{base}_IND___"
        last_price = get_mid_price(brokers, underlying_ind, exchange=exchange, mds=mds, last=True)
        if not math.isnan(last_price):
            price_u = last_price
        else:
            price_u = get_price(brokers, underlying_ind, checks=["prior_close"], exchange=exchange, mds=mds).prior_close
            if math.isnan(price_u):
                return None
        if t_f is None or t_f == 0:
            return None
        price_f = price_u + (price_f - price_u) * t_o / t_f
        trading_logger.log_debug(

            f"get_option_underlying_price: index interpolated price_u={price_u} t_o={t_o} t_f={t_f} price_f={price_f}"

        )
    return float(price_f)


def _asof_to_ref_time_naive(as_of: Union[dt.datetime, dt.date, str, pd.Timestamp]) -> dt.datetime:
    """Naive clock for time-to-expiry when using historical ``as_of`` (date-only -> 09:15)."""
    if isinstance(as_of, pd.Timestamp):
        ref = as_of.to_pydatetime()
    elif isinstance(as_of, dt.date) and not isinstance(as_of, dt.datetime):
        ref = dt.datetime.combine(as_of, dt.time(9, 15, 0))
    elif isinstance(as_of, str):
        ref = parse_datetime(as_of)
    else:
        ref = cast(dt.datetime, as_of)
    if getattr(ref, "tzinfo", None):
        ref = ref.replace(tzinfo=None)
    return ref


def calculate_delta(
    brokers: list[BrokerBase],
    long_symbol,
    price_f,
    market_close_time="15:30:00",
    exchange="NSE",
    mds: Optional[str] = None,
    as_of: Optional[Union[dt.datetime, dt.date, str, pd.Timestamp]] = None,
):
    delta = float("nan")
    if as_of is None:
        ticker = get_price(brokers, long_symbol, checks=["bid", "ask", "prior_close"], exchange=exchange, mds=mds)
        price = (ticker.bid + ticker.ask) / 2 if ticker.bid > 0 and ticker.ask > 0 else ticker.prior_close
        t = (
            calc_fractional_business_days(
                get_tradingapi_now(),
                dt.datetime.strptime(long_symbol.split("_")[2] + " " + market_close_time, "%Y%m%d %H:%M:%S"),
            )
            / 252
        )  # convert days number of years
    else:
        br: List[BrokerBase] = [brokers] if isinstance(brokers, BrokerBase) else brokers
        broker = br[0]
        price_at = get_price_at_time(broker, long_symbol, exchange, as_of=as_of, mds=mds, last=True)
        if price_at is None or (isinstance(price_at, float) and (math.isnan(price_at) or price_at <= 0)):
            return float("nan")
        price = float(price_at)
        ref_time = _asof_to_ref_time_naive(as_of)
        t = (
            calc_fractional_business_days(
                ref_time,
                dt.datetime.strptime(long_symbol.split("_")[2] + " " + market_close_time, "%Y%m%d %H:%M:%S"),
            )
            / 252
        )
    vol = BlackScholesIV(
        S=price_f,
        X=float(long_symbol.split("_")[4]),
        r=0,
        T=t,
        OptionType=long_symbol.split("_")[3],
        OptionPrice=price,
    )
    delta = BlackScholesDelta(
        S=price_f,
        X=float(long_symbol.split("_")[4]),
        r=0,
        sigma=vol,
        T=t,
        OptionType=long_symbol.split("_")[3],
    )
    return delta


def find_option_with_delta(
    brokers: list[BrokerBase],
    price_f,
    option_chain,
    target_delta,
    return_lower_delta,
    market_close_time="15:30:00",
    exchange="NSE",
    mds: Optional[str] = "mds",
    as_of: Optional[Union[dt.datetime, dt.date, str, pd.Timestamp]] = None,
):
    # Determine the correct option exchange
    opt_exchange = "NFO" if exchange == "NSE" else "BFO" if exchange == "BSE" else exchange

    left, right = 0, len(option_chain) - 1
    best_index = -1  # Default to -1 if no valid option is found
    best_delta = float("-inf") if return_lower_delta else float("inf")  # Best delta found so far

    def _strike(sym: str) -> float:
        return float(sym.split("_")[4]) if "_" in sym and len(sym.split("_")) > 4 else float("nan")

    chain_strikes = [_strike(s) for s in option_chain] if option_chain else []
    strike_lo = min(chain_strikes) if chain_strikes else float("nan")
    strike_hi = max(chain_strikes) if chain_strikes else float("nan")
    n = len(option_chain)
    total_delta_checks = 0
    valid_delta_count = 0
    nan_delta_count = 0
    nan_delta_strikes = []  # track strikes where delta could not be calculated
    # Cache so seeding sweep + binary search never recompute the same strike.
    delta_cache: dict[int, float] = {}

    def _delta_at(idx: int) -> float:
        nonlocal total_delta_checks, valid_delta_count, nan_delta_count
        if idx in delta_cache:
            return delta_cache[idx]
        d = calculate_delta(
            brokers, option_chain[idx], price_f, market_close_time, exchange=opt_exchange, mds=mds, as_of=as_of
        )
        total_delta_checks += 1
        if d is None or math.isnan(d):
            d = float("nan")
            nan_delta_count += 1
            nan_delta_strikes.append(_strike(option_chain[idx]))
        else:
            valid_delta_count += 1
        delta_cache[idx] = d
        return d

    def _consider(idx: int, abs_delta: float) -> None:
        nonlocal best_index, best_delta
        if return_lower_delta:
            if abs_delta <= target_delta and abs_delta > best_delta:
                best_delta = abs_delta
                best_index = idx
        else:
            if abs_delta >= target_delta and abs_delta < best_delta:
                best_delta = abs_delta
                best_index = idx

    if n == 0:
        trading_logger.log_warning(
            f"find_option_with_delta: empty option_chain. price_f={price_f} target_delta={target_delta}"
        )
        return -1

    # --- Change 1: robust direction seeding via spread-out probes ---
    seed_fractions = [0.1, 0.25, 0.5, 0.75, 0.9]
    seed_indices = sorted({min(n - 1, max(0, int(round(f * (n - 1))))) for f in seed_fractions})
    seed_samples: list[tuple[int, float]] = []  # (idx, |delta|)
    for idx in seed_indices:
        d = _delta_at(idx)
        if not math.isnan(d):
            ad = abs(d)
            seed_samples.append((idx, ad))
            _consider(idx, ad)

    if len(seed_samples) < 2:
        if best_index < 0:
            trading_logger.log_warning(
                f"find_option_with_delta: no valid option strike found (seed failure). "
                f"price_f={price_f} target_delta={target_delta} return_lower_delta={return_lower_delta} "
                f"chain_len={n} strike_range=[{strike_lo}, {strike_hi}] "
                f"valid_delta_count={valid_delta_count} nan_delta_count={nan_delta_count} "
                f"total_delta_checks={total_delta_checks} nan_delta_strikes={sorted(set(nan_delta_strikes))}"
            )
        return best_index

    # Determine monotonicity from lowest- vs. highest-strike valid seeds.
    increasing = seed_samples[-1][1] > seed_samples[0][1]

    # --- Change 2: NaN at mid -> scan to nearest valid neighbor instead of shrinking range ---
    NAN_SCAN_CAP = 5

    def _nearest_valid(mid: int, lo: int, hi: int) -> int:
        # Returns idx of nearest valid delta within [lo, hi], or -1 if none within cap.
        for step in range(1, NAN_SCAN_CAP + 1):
            for cand in (mid - step, mid + step):
                if lo <= cand <= hi and not math.isnan(_delta_at(cand)):
                    return cand
        return -1

    while left <= right:
        mid = (left + right) // 2
        d = _delta_at(mid)
        eff_idx = mid
        if math.isnan(d):
            alt = _nearest_valid(mid, left, right)
            if alt < 0:
                # Wide NaN band: stop here instead of expanding into a full-chain scan.
                break
            eff_idx = alt
            d = delta_cache[alt]
        ad = abs(d)
        _consider(eff_idx, ad)

        if increasing:
            if ad > target_delta:
                right = eff_idx - 1
            else:
                left = eff_idx + 1
        else:
            if ad > target_delta:
                left = eff_idx + 1
            else:
                right = eff_idx - 1

    if best_index < 0:
        trading_logger.log_warning(
            f"find_option_with_delta: no valid option strike found. "
            f"price_f={price_f} chain_len={n} strike_range=[{strike_lo}, {strike_hi}] "
            f"valid_delta_count={valid_delta_count} nan_delta_count={nan_delta_count} total_delta_checks={total_delta_checks} "
            f"nan_delta_strikes={sorted(set(nan_delta_strikes))}"
        )
    return best_index


@log_execution_time
@validate_inputs(
    underlying_symbol=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    delta=lambda x: isinstance(x, (int, float)) and 0 < x < 1,
    opt_expiry=lambda x: isinstance(x, str) and len(x.strip()) == 8,
    option_type=lambda x: isinstance(x, str) and x in ["CALL", "PUT"],
    exchange=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    market_close_time=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    as_of=lambda x: x is None
    or isinstance(x, (dt.datetime, dt.date, str))
    or isinstance(x, pd.Timestamp),
)
def get_delta_strike(
    brokers: list[BrokerBase],
    underlying_symbol: str,
    delta: float,
    opt_expiry: str,
    option_type: str,
    fut_expiry=None,
    rounding=None,
    return_lower_delta=True,
    use_future=True,
    search_range=[0.8, 1.2],
    market_close_time="15:30:00",
    exchange="NSE",
    mds: Optional[str] = None,
    as_of: Optional[Union[dt.datetime, dt.date, str, pd.Timestamp]] = None,
) -> Union[str, None]:
    """Get option strike price for a given delta with enhanced error handling.

    Args:
        brokers: List of broker instances
        underlying_symbol: Underlying symbol name
        delta: Target delta value (0-1)
        opt_expiry: Option expiry date (YYYYMMDD)
        option_type: Option type (CALL/PUT)
        fut_expiry: Optional future expiry date
        rounding: Optional rounding value for strikes
        return_lower_delta: Whether to return lower delta if exact not found
        use_future: Whether to use future prices
        search_range: Range around underlying price to search
        market_close_time: Market close time
        exchange: Exchange name
        mds: Market data service channel name (str). If None or empty, uses broker quotes.
             If provided (e.g., "mds"), uses market data service with that channel.
        as_of: Optional. When omitted (default), behavior matches pre-change realtime paths.
            When set, underlying and option marks use historical OHLC at that time; T for IV/delta
            uses ``as_of`` instead of now.

    Returns:
        Union[str, None]: Option symbol or None if not found

    Raises:
        ValidationError: If input parameters are invalid
        MarketDataError: If price retrieval fails
        SymbolError: If symbol mapping fails
    """
    """Returns long symbol for specified value  of absolute delta


    Args:
        underlying_symbol (str): underlying symbol as _STK___ or _IND___
        delta (float): absolute value of delta
        expiry (str): formatted as YYYYMMDD
        option_type (str): CALL or PUT
        rounding (float, optional): Rounding of strike. Defaults to None.
        return_lower_strike (bool, optional): should lower strike value be returend. Defaults to True.
        use_future(bool, optional): Should future prices be used as underlying
        search_range (list, optional): the range of strikes to search with reference to underlying price. Defaults to [0.8,1.2].

    Returns:
        Union[str,None]: long_symbol or None
    """
    if isinstance(brokers, BrokerBase):
        brokers = [brokers]
    exchange = brokers[0].map_exchange_for_api(underlying_symbol, exchange)
    if use_future:
        price_f = get_option_underlying_price(
            brokers, underlying_symbol, opt_expiry, fut_expiry, exchange=exchange, mds=mds, as_of=as_of
        )
        trading_logger.log_debug(f"get_delta_strike: price_f from get_option_underlying_price={price_f}")
        if price_f is None:
            trading_logger.log_debug("get_delta_strike: no underlying price available from get_option_underlying_price")
            return None
    elif as_of is not None:
        price_at = get_price_at_time(brokers[0], underlying_symbol, exchange, as_of=as_of, mds=mds, last=True)
        price_f = float(price_at) if price_at is not None else float("nan")
        trading_logger.log_debug(f"get_delta_strike: price_f from get_price_at_time(underlying)={price_f}")
    else:
        price_f = get_price(brokers, underlying_symbol, checks=["last"], exchange=exchange, mds=mds).last
        trading_logger.log_debug(f"get_delta_strike: price_f from get_price(underlying).last={price_f}")
    option_chain = get_linked_options(brokers[0], underlying_symbol, opt_expiry, exchange)
    # option_chain = get_opt_chain(broker, underlying_symbol.split("_")[0], opt_expiry_yyyy_mm_dd)
    option_chain = [opt for opt in option_chain if f"_{option_type}_" in opt]
    option_chain = [
        opt for opt in option_chain if search_range[0] * price_f < float(opt.split("_")[4]) < search_range[1] * price_f
    ]
    option_chain = sorted(option_chain, key=lambda x: float(x.split("_")[-1]))  # sort ascending
    if rounding is not None and rounding > 0:
        option_chain = [t for t in option_chain if abs(float(t.split("_")[4]) % rounding) < 1e-6]
    if len(option_chain) == 0:
        trading_logger.log_info(f"Option Chain not found for symbol: {underlying_symbol}")
        return None
    if price_f is None or (isinstance(price_f, float) and math.isnan(price_f)):
        trading_logger.log_debug(f"get_delta_strike: invalid underlying price_f={price_f}")
        return None
    index = find_option_with_delta(
        brokers,
        price_f,
        option_chain,
        delta,
        return_lower_delta,
        market_close_time,
        exchange=exchange,
        mds=mds,
        as_of=as_of,
    )
    if index >= 0:
        return option_chain[index]
    else:
        trading_logger.log_debug(f"get_delta_strike: no option found (index={index})")
        return None


def get_impact_cost(brokers: list[BrokerBase], symbol: str, exchange="NSE", mds: Optional[str] = None) -> dict[str, Any]:
    ticker = get_price(brokers, symbol, checks=["bid", "ask"], exchange=exchange, mds=mds)
    mid_price = (ticker.ask + ticker.bid) / 2
    if mid_price == 0 or math.isnan(mid_price):
        impact_cost = float("nan")
    else:
        impact_cost = (ticker.ask - ticker.bid) / mid_price
    return {"ticker": ticker, "impact_cost": impact_cost}


def _sort_list(symbols, quantities, price_types, additional_info, exchanges=None, trigger_prices=None):
    # Handle cases where price_types is None or partially filled
    if not price_types or price_types == [None]:
        price_types = ["LMT"] * len(symbols)
    elif len(price_types) < len(symbols):
        # Propagate the first price type to all symbols
        price_types = [price_types[0]] * len(symbols)

    # Ensure all lists are the same length
    n = len(symbols)
    if not price_types or len(price_types) < n:
        price_types = [price_types[0]] * n if price_types else ["LMT"] * n
    if not quantities or len(quantities) < n:
        quantities = [quantities[0]] * n if quantities else [1] * n
    if not additional_info or len(additional_info) < n:
        additional_info = (additional_info + [""] * n)[:n]
    include_triggers = trigger_prices is not None
    if include_triggers:
        assert trigger_prices is not None  # Type narrowing for mypy
        if not isinstance(trigger_prices, list):
            trigger_prices = [trigger_prices]
        if len(trigger_prices) < n:
            trigger_prices = (trigger_prices + [trigger_prices[0] if trigger_prices else float("nan")] * n)[:n]
        trigger_prices = trigger_prices[:n]
    if exchanges is not None and (not exchanges or len(exchanges) < n):
        exchanges = (exchanges + [exchanges[0]] * n)[:n]

    # Zip the relevant pairs based on whether exchanges are provided
    if exchanges is not None:
        if include_triggers:
            # Type assertion: trigger_prices is guaranteed to be not None here
            assert trigger_prices is not None
            zipped_pairs = list(zip(quantities, symbols, exchanges, price_types, additional_info, trigger_prices))
        else:
            zipped_pairs = list(zip(quantities, symbols, exchanges, price_types, additional_info))
    else:
        if include_triggers:
            # Type assertion: trigger_prices is guaranteed to be not None here
            assert trigger_prices is not None
            zipped_pairs = list(zip(quantities, symbols, price_types, additional_info, trigger_prices))
        else:
            zipped_pairs = list(zip(quantities, symbols, price_types, additional_info))

    # Sort zipped pairs by quantities in descending order
    sorted_pairs = sorted(zipped_pairs, reverse=True)

    # Unpack the sorted pairs into lists
    sorted_triggers: tuple[Any, ...] | list[Any] | None = None
    if exchanges is not None:
        if not sorted_pairs:
            sorted_quantities = []
            sorted_symbols = []
            sorted_exchanges = []
            sorted_order_types = []
            sorted_additional_info = []
            sorted_triggers = [] if include_triggers else None
        else:
            if include_triggers:
                (
                    sorted_quantities,
                    sorted_symbols,
                    sorted_exchanges,
                    sorted_order_types,
                    sorted_additional_info,
                    sorted_triggers,
                ) = zip(*sorted_pairs)
            else:
                (
                    sorted_quantities,
                    sorted_symbols,
                    sorted_exchanges,
                    sorted_order_types,
                    sorted_additional_info,
                ) = zip(*sorted_pairs)
        if include_triggers:
            # Type assertion: sorted_triggers is guaranteed to be a list when include_triggers is True
            assert sorted_triggers is not None
            return (
                list(sorted_symbols),
                list(sorted_quantities),
                list(sorted_order_types),
                list(sorted_exchanges),
                list(sorted_additional_info),
                list(sorted_triggers),
            )
        else:
            return (
                list(sorted_symbols),
                list(sorted_quantities),
                list(sorted_order_types),
                list(sorted_exchanges),
                list(sorted_additional_info),
                [],
            )
    else:
        if not sorted_pairs:
            if include_triggers:
                return [], [], [], [], []
            return [], [], [], [], []
        if include_triggers:
            (
                sorted_quantities,
                sorted_symbols,
                sorted_order_types,
                sorted_additional_info,
                sorted_triggers,
            ) = zip(*sorted_pairs)
            return (
                list(sorted_symbols),
                list(sorted_quantities),
                list(sorted_order_types),
                list(sorted_additional_info),
                list(sorted_triggers),
            )
        else:
            sorted_quantities, sorted_symbols, sorted_order_types, sorted_additional_info = zip(*sorted_pairs)
            return (
                list(sorted_symbols),
                list(sorted_quantities),
                list(sorted_order_types),
                list(sorted_additional_info),
                [],
            )


def _is_fno_symbol(symbol: str) -> bool:
    first_leg = str(symbol or "").split(":")[0].split("?")[0].strip()
    return "_OPT_" in first_leg or "_FUT_" in first_leg


def _compute_slices(total: int, max_per_order: Optional[int]) -> List[int]:
    total = int(total)
    if total <= 0:
        return []
    if not max_per_order or int(max_per_order) <= 0 or total <= int(max_per_order):
        return [total]
    n = int(max_per_order)
    return [n] * (total // n) + ([total % n] if total % n else [])


def _get_freeze_limit_lots(broker: BrokerBase, combo_symbol: str) -> Optional[int]:
    """Return max combo-units per order for the FNO underlying in combo_symbol.

    Config values are in total contracts (= lots × lot_size).  The returned
    value is in combo-units so that: combo_units × max_leg_size ≤ limit_contracts.
    Returns None for non-FNO symbols or when no limit is configured.
    """
    first_leg = str(combo_symbol or "").split(":")[0].split("?")[0].strip()
    if "_OPT_" not in first_leg and "_FUT_" not in first_leg:
        return None
    underlying = first_leg.split("_")[0]
    broker_name = getattr(getattr(broker, "broker", None), "name", "") or ""
    limit_contracts = get_fno_freeze_limit(broker_name, underlying)
    if not limit_contracts:
        return None
    legs = parse_combo_symbol(combo_symbol)
    if not legs:
        return None
    max_leg_size = max(abs(int(q)) for q in legs.values())
    if max_leg_size <= 0:
        return None
    return max(1, int(limit_contracts) // max_leg_size)


@log_execution_time
@validate_inputs(
    strategy=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    entry=lambda x: isinstance(x, bool),
    validate_db_position=lambda x: isinstance(x, bool),
    paper=lambda x: isinstance(x, bool),
)
def place_combo_order(
    execution_broker: BrokerBase,
    strategy: str,
    symbols: list[str],
    quantities: list[int],
    entry: bool,
    additional_infos: list[str] = [""],
    exchanges: list[str] = ["NSE"],
    price_broker: Optional[List[BrokerBase]] = None,
    price_types: list[str] = [],
    trigger_prices: Union[Sequence[float], float, None] = None,
    mds: Optional[str] = None,
    validate_db_position: bool = True,
    paper: bool = True,
    freeze_limit_lots: Optional[int] = None,
) -> dict[str, Any]:
    """Place a combo order with broker with enhanced error handling.

    Args:
        execution_broker: Broker instance for order execution
        strategy: Strategy name
        symbols: List of symbols to trade
        quantities: List of quantities for each symbol
        entry: True if entry order, False if exit order
        additional_infos: List of additional info strings
        exchanges: List of exchanges for each symbol
        price_broker: Optional list of brokers for price data
        price_types: List of price types for each symbol
        validate_db_position: Whether to validate database position
        paper: Whether this is a paper trade

    Returns:
        dict: Dictionary with symbol to internal order ID mapping

    Raises:
        ValidationError: If input parameters are invalid
        OrderError: If order placement fails
    """
    """Place a combo order with broker

    Args:
        broker: broker instance
        strategy (str): strategy name
        symbols (list[str]): list of symbols
        quantities (list[int]): list of quantities
        entry (bool): True if entry else False
        additional_infos (list): list of json formatted string,
        price_types (list, optional): list of order types. Should be same length as symbols. Defaults to None which reflects in limit orders at midprice
        trigger_prices (list | float | None): trigger price(s) for conditional orders. Scalar applied to all legs.
        validate_db_position(bool): if set to false, exit orders are generated without updating redis
        paper: if set to True (default), simulated orders are generated

    Returns:
        dict: for entry orders a dict containing symbol:int order id is returned. dict is empty for exit orders
    """

    if price_broker is None:
        price_broker = [execution_broker]
    if not isinstance(symbols, list):
        symbols = [symbols]
    if not isinstance(price_types, list):
        price_types = [price_types]
    if not isinstance(quantities, list):
        quantities = [quantities]
    if not isinstance(exchanges, list):
        exchanges = [exchanges]
    if len(exchanges) < len(symbols):
        exchanges = [exchanges[0]] * len(symbols)
    if not isinstance(additional_infos, list):
        additional_infos = [additional_infos]
    if len(additional_infos) < len(symbols):
        additional_infos = additional_infos + [""] * (len(symbols) - len(additional_infos))
    if trigger_prices is None:
        trigger_prices = [float("nan")] * len(symbols)
    elif isinstance(trigger_prices, list):
        trigger_prices = (
            (trigger_prices + [trigger_prices[-1]] * len(symbols))[: len(symbols)]
            if trigger_prices
            else [float("nan")] * len(symbols)
        )
    else:
        # trigger_prices is guaranteed to be a scalar (float/int) here, not a sequence
        assert isinstance(trigger_prices, (int, float))
        trigger_prices = [float(trigger_prices)] * len(symbols)

    # Ensure all variables are lists for the zip operation
    assert isinstance(symbols, list)
    assert isinstance(quantities, list)
    assert isinstance(price_types, list)
    assert isinstance(exchanges, list)
    assert isinstance(additional_infos, list)
    assert isinstance(trigger_prices, list)

    exchanges = [
        execution_broker.map_exchange_for_api(symbol, exchange) for symbol, exchange in zip(symbols, exchanges)
    ]
    (
        symbols,
        quantities,
        price_types,
        exchanges,
        additional_infos,
        trigger_prices,
    ) = _sort_list(symbols, quantities, price_types, additional_infos, exchanges, trigger_prices)
    assert isinstance(trigger_prices, list)

    # Auto-detect freeze limit from config if not explicitly provided.
    # FNO symbols without a configured limit are refused — placing an oversized
    # FNO order without a freeze limit is unsafe.
    if freeze_limit_lots is None and symbols:
        first_sym = symbols[0]
        if _is_fno_symbol(first_sym):
            freeze_limit_lots = _get_freeze_limit_lots(execution_broker, first_sym)
            if freeze_limit_lots is None:
                first_leg = first_sym.split(":")[0].split("?")[0].strip()
                underlying = first_leg.split("_")[0]
                broker_name = getattr(getattr(execution_broker, "broker", None), "name", "") or ""
                trading_logger.log_error(
                    f"freeze_limit not configured for FNO "
                    f"underlying={underlying} broker={broker_name}; "
                    f"order skipped symbol={first_sym}"
                )
                return {}

    out = {}
    for symbol, exchange, quantity, price_type, additional_info, trigger_price in zip(
        symbols, exchanges, quantities, price_types, additional_infos, trigger_prices
    ):
        if entry:
            side = "BUY" if quantity > 0 else "SHORT"
        else:
            side = "COVER" if quantity > 0 else "SELL"

        slices = _compute_slices(abs(int(quantity)), freeze_limit_lots)
        if len(slices) > 1:
            trading_logger.log_info(
                f"freeze slicing symbol={symbol} total_qty={abs(int(quantity))} "
                f"max_per_order={freeze_limit_lots} slices={slices} entry={entry}"
            )

        # Pre-allocate one internal_order_id shared across all slices (entry only).
        # transmit_entry_order honours a pre-set order.internal_order_id, so all
        # slices' broker_order_ids accumulate under the same entry_keys in Redis.
        symbol_shared_id: Optional[str] = None
        if entry and len(slices) > 1:
            next_id = execution_broker.starting_order_ids_int.get(strategy, 1)
            execution_broker.starting_order_ids_int[strategy] = next_id + 1
            symbol_shared_id = f"{strategy}_{next_id}"

        exch = exchange
        exch_type = execution_broker.exchange_mappings[exch]["exchangetype_map"].get(symbol.split("?")[0])

        for idx, slice_qty in enumerate(slices, start=1):
            slice_additional_info = additional_info
            if len(slices) > 1:
                slice_meta = json.dumps(
                    {
                        "freeze_limited_order_size": freeze_limit_lots,
                        "requested_quantity": abs(int(quantity)),
                        "slice_count": len(slices),
                        "slice_index": idx,
                        "slice_quantity": slice_qty,
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                )
                try:
                    slice_additional_info = _merge_additional_info(additional_info, slice_meta)
                except Exception:
                    slice_additional_info = additional_info

            temp_order = Order(
                order_type=side,
                quantity=int(slice_qty),
                exchange=exch,
                exchange_segment=exch_type,
                is_intraday=False,
                price=float("nan"),
                ahplaced="N",
                long_symbol=symbol,
                price_type=price_type,
                additional_info=slice_additional_info,
                trigger_price=trigger_price,
            )
            if symbol_shared_id:
                temp_order.internal_order_id = symbol_shared_id
            if not math.isnan(temp_order.trigger_price):
                temp_order.is_stoploss_order = True
            trading_logger.log_info(f"{symbol} {exch} {slice_qty} {side} slice={idx}/{len(slices)}")
            if entry:
                temp = transmit_entry_order(execution_broker, strategy, temp_order, paper=paper, mds=mds)
                out[symbol] = temp
            else:
                transmit_exit_order(
                    execution_broker,
                    strategy,
                    temp_order,
                    validate_db_position,
                    paper=paper,
                    mds=mds,
                )
            if idx < len(slices):
                time.sleep(5)
    return out


@log_execution_time
@validate_inputs(pnl=lambda x: isinstance(x, pd.DataFrame) and len(x) >= 0)
def calculate_mtm(brokers: list[BrokerBase], pnl: pd.DataFrame, mds: Optional[str] = None) -> pd.DataFrame:
    """Calculates MTM for a profit DataFrame which has open trades.

    Args:
        brokers: List of broker instances
        pnl: Profit DataFrame with open trades
        mds: Market data service channel name (str). If None or empty, uses broker quotes.
             If provided (e.g., "mds"), uses market data service with that channel.

    Returns:
        pd.DataFrame: Profit DataFrame with mark-to-market prices

    Raises:
        ValidationError: If input parameters are invalid
        MarketDataError: If price retrieval fails
        PnLError: If MTM calculation fails
    """
    pnl = pnl.copy()
    pnl.reset_index(drop=True, inplace=True)
    for index, row in pnl.iterrows():
        if row["exit_quantity"] + row["entry_quantity"] != 0 and row["entry_price"] != 0:
            trading_logger.log_debug(f'Getting mtm for {row["symbol"]}')
            exchange = "BSE" if "SENSEX" in row["symbol"] else "NSE"
            quote = get_price(
                brokers,
                row["symbol"],
                checks=["bid", "ask", "last", "prior_close"],
                attempts=1,
                exchange=exchange,
                mds=mds,
            )
            if all(not math.isnan(attr) for attr in [quote.bid, quote.ask]):
                mtm_price = (quote.bid + quote.ask) / 2
            else:
                mtm_price = quote.last if not math.isnan(quote.last) else quote.prior_close
            pnl.loc[index, "mtm"] = mtm_price
    pnl["gross_pnl"] = -1 * (
        pnl["exit_price"] * pnl["exit_quantity"]
        + pnl["mtm"] * -1 * (pnl["entry_quantity"] + pnl["exit_quantity"])
        + pnl["entry_quantity"] * pnl["entry_price"]
    )
    return pnl


def get_expiry_from_FormattedExpiryTime(timestamp_str) -> str:
    """Convert str formatted as "/Date(1703754000000+0530)/" to yyyy-mm-dd

    Args:
        timestamp_str (_type_): str formatted as "/Date(1703754000000+0530)/"

    Returns:
        str: date formatted as yyyy-mm-dd
    """
    timestamp_str = timestamp_str.replace("/Date(", "").replace(")/", "")
    # Extract milliseconds and timezone offset
    milliseconds = int(timestamp_str[:-5])
    timezone_offset = int(timestamp_str[-5:])

    # Create a timedelta object for the timezone offset
    offset_timedelta = dt.timedelta(minutes=timezone_offset // 100 * 60 + timezone_offset % 100)

    # Convert milliseconds to seconds and add the offset
    timestamp_seconds = milliseconds / 1000
    timestamp_with_offset = timestamp_seconds + offset_timedelta.total_seconds()

    # Convert the timestamp to a datetime object
    date_object = dt.datetime.fromtimestamp(timestamp_with_offset, tz=dt.timezone.utc)

    # Format the datetime object as a string
    formatted_date = date_object.strftime("%Y-%m-%d")
    return formatted_date


def historical_to_dataframes(historical_data: Dict[str, List[HistoricalData]]) -> List[pd.DataFrame]:
    """
    Converts a dictionary of lists of HistoricalData to a list of pandas DataFrames.

    Args:
        historical_data (Dict[str, List[HistoricalData]]): Dictionary with symbol as keys and lists of HistoricalData as values.

    Returns:
        List[pd.DataFrame]: List of DataFrames, each containing historical data for a symbol.
    """
    dataframes = []
    for symbol, data_list in historical_data.items():
        try:
            # Convert list of HistoricalData to a DataFrame
            df = pd.DataFrame(
                [{**data.to_dict(), "symbol": symbol} for data in data_list if data.date != dt.datetime(1970, 1, 1)]
            )  # Filter out entries with missing dates

            if not df.empty:
                df = df.sort_values(by="date")
                df.reset_index(inplace=True, drop=True)
                dataframes.append(df)
        except Exception as e:
            print(f"Error processing data for symbol {symbol}: {e}")

    return dataframes


def _hds_json_default(obj):
    if isinstance(obj, (dt.datetime, dt.date)) or hasattr(obj, "isoformat"):
        return obj.isoformat()
    raise TypeError(f"Object of type {obj.__class__.__name__} is not serializable")


def _deserialize_historical(data_dict: dict) -> Dict[str, List[HistoricalData]]:
    result: Dict[str, List[HistoricalData]] = {}
    for symbol, bars in data_dict.items():
        hd_list = []
        for bar in bars:
            date_val = bar.get("date")
            if date_val:
                parsed = pd.Timestamp(date_val)
                if parsed.tzinfo is None:
                    parsed = parsed.tz_localize("Asia/Kolkata")
                else:
                    parsed = parsed.tz_convert("Asia/Kolkata")
            else:
                parsed = pd.Timestamp("1970-01-01", tz="Asia/Kolkata")
            hd_list.append(HistoricalData(
                date=parsed,
                open=float(bar.get("open", float("nan"))),
                high=float(bar.get("high", float("nan"))),
                low=float(bar.get("low", float("nan"))),
                close=float(bar.get("close", float("nan"))),
                volume=int(bar.get("volume", 0)),
                intoi=int(bar.get("intoi", 0)),
                oi=int(bar.get("oi", 0)),
            ))
        result[symbol] = hd_list
    return result


def get_historical_data(
    brokers: Union[List[BrokerBase], BrokerBase],
    symbol: str,
    date_start: Union[str, "dt.datetime", "dt.date"],
    date_end: Union[str, "dt.datetime", "dt.date"],
    exchange: str = "NSE",
    periodicity: str = "1m",
    refresh_mapping: bool = False,
    hds: Optional[str] = None,
    redis_host: str = "localhost",
    redis_port: int = 6379,
    redis_db: int = 3,
    timeout: int = 120,
    max_attempts: int = 2,
    bypass_cache: str = "",
) -> Dict[str, List[HistoricalData]]:
    """Fetch historical OHLCV data broker-agnostically.

    When hds is provided the request is routed through a running
    historical_data_server process via Redis pub/sub.  Without hds the
    call is made directly to one of the supplied brokers with round-robin
    load distribution and per-broker retry.

    bypass_cache controls HDS Redis cache behaviour (ignored when hds is None):
      ""      — normal cache read+write (default)
      "read"  — skip cache read, fetch from broker, write result to cache
      "write" — use cached data if available, do not write result to cache
      "both"  — skip cache read and write entirely
    """
    if isinstance(brokers, BrokerBase):
        brokers = [brokers]

    # ------------------------------------------------------------------ #
    # Direct broker path (no HDS)
    # ------------------------------------------------------------------ #
    if not hds:
        exchange_upper = str(exchange).strip().upper()
        candidates = [
            b for b in brokers
            if b.is_connected() and broker_supports_market_data_exchange(b.broker, exchange_upper)
        ]
        if not candidates:
            raise MarketDataError(
                f"No connected broker supports exchange {exchange} for get_historical_data",
                {"symbol": symbol, "exchange": exchange},
            )
        n = len(candidates)
        start = _hds_rr_state[0] % n
        _hds_rr_state[0] += 1
        ordered = candidates[start:] + candidates[:start]
        last_exc: Optional[Exception] = None
        for broker in ordered[:max_attempts]:
            try:
                result = broker.get_historical(
                    symbol,
                    date_start,
                    date_end,
                    exchange=exchange,
                    periodicity=periodicity,
                    refresh_mapping=refresh_mapping,
                )
                if result and any(len(v) > 0 for v in result.values()):
                    return result
                trading_logger.log_info(
                    f"get_historical_data: empty result from {broker.broker.name}, trying next broker",
                    {"symbol": symbol, "exchange": exchange, "periodicity": periodicity},
                )
            except Exception as e:
                last_exc = e
                trading_logger.log_info(
                    f"get_historical_data: {broker.broker.name} raised {type(e).__name__}, trying next broker",
                    {"symbol": symbol, "exchange": exchange, "error": str(e)},
                )
        raise MarketDataError(
            f"get_historical_data: all {min(max_attempts, n)} broker attempts failed for {symbol}~{exchange}",
            {"symbol": symbol, "exchange": exchange, "periodicity": periodicity, "last_error": str(last_exc)},
        )

    # ------------------------------------------------------------------ #
    # HDS path — route through Redis pub/sub
    # ------------------------------------------------------------------ #
    request_id = str(uuid.uuid4())
    response_channel = f"hds_response:{request_id}"
    r_hds = redis.Redis(host=redis_host, port=redis_port, db=redis_db, encoding="utf-8", decode_responses=True)
    ps = r_hds.pubsub()
    ps.subscribe(response_channel)
    request = {
        "symbol": symbol,
        "exchange": exchange,
        "periodicity": periodicity,
        "date_start": date_start if isinstance(date_start, str) else (
            date_start.isoformat() if hasattr(date_start, "isoformat") else str(date_start)
        ),
        "date_end": date_end if isinstance(date_end, str) else (
            date_end.isoformat() if hasattr(date_end, "isoformat") else str(date_end)
        ),
        "refresh_mapping": refresh_mapping,
        "bypass_cache": bypass_cache,
        "max_attempts": max_attempts,
        "response_channel": response_channel,
    }
    r_hds.publish("historical_data_requests", json.dumps(request))
    deadline = time.time() + timeout
    try:
        while time.time() < deadline:
            msg = ps.get_message(ignore_subscribe_messages=True, timeout=1.0)
            if msg and msg["type"] == "message":
                response = json.loads(msg["data"])
                if response.get("status") == "error":
                    raise MarketDataError(
                        f"HDS error for {symbol}~{exchange}: {response.get('error', 'unknown')}",
                        {"symbol": symbol, "exchange": exchange, "periodicity": periodicity},
                    )
                return _deserialize_historical(response.get("data", {}))
    finally:
        ps.unsubscribe(response_channel)
        ps.close()
        r_hds.close()
    raise MarketDataError(
        f"HDS timeout ({timeout}s) waiting for {symbol}~{exchange} {periodicity}",
        {"symbol": symbol, "exchange": exchange, "periodicity": periodicity},
    )


def _get_active_commission_config(entry_date: str, config) -> str:
    """
    Get the active commission configuration effective date based on the entry date.

    :param entry_date: A string in the form "yyyy-mm-dd".
    :param config: A dictionary containing the YAML data loaded using yaml.safe_load.
    :return: The most recent effective_date that is less than the entry_date.
    """

    # Extract and sort the effective dates as strings
    effective_dates = sorted(list(config.get("commissions").keys()))

    # Find the most recent effective date less than entry_date
    for effective_date in effective_dates:
        if effective_date < entry_date:
            return effective_date

    # Return 1970 if no effective date is found
    return "1970-01-01"


def _update_commissions(dataframe: pd.DataFrame, brok: Optional[BrokerBase] = None):
    """get commission values in trades dataframe

    Args:
        dataframe (pd.DataFrame): trades dataframe
        brok (BrokerBase, optional): BrokerBase containing database with trades. Defaults to None.
    """

    def get_redis_price(broker_order_id: str, long_symbol: str, brok: Optional[BrokerBase] = None):
        """Fetch the price from Redis using the broker_order_id and ensure it matches the long_symbol."""
        if brok is None:
            return np.nan
        order_data = cast(dict[str, Any], brok.redis_o.hgetall(broker_order_id))
        if order_data.get("long_symbol") == long_symbol:
            return float(order_data.get("price", 0))
        return np.nan

    def is_expiry_paper_exit(broker_order_id: str, long_symbol: str, brok: Optional[BrokerBase] = None) -> bool:
        """Return True when the exit order is an expiry paper square-off."""
        if brok is None:
            return False
        order_data = cast(dict[str, Any], brok.redis_o.hgetall(broker_order_id))
        if order_data.get("long_symbol") != long_symbol:
            return False
        exchange = str(order_data.get("exchange", "") or "").upper()
        message = str(order_data.get("message", "") or "").upper()
        return exchange == "SQUAREOFF" or "EXPIRATION PAPER ORDER" in message

    def get_exchange_for_order(broker_order_id: str, long_symbol: str, brok: Optional[BrokerBase]) -> str:
        """Return the exchange for this order key, defaulting to NSE."""
        if brok is None:
            return "NSE"
        order_data = cast(dict[str, Any], brok.redis_o.hgetall(broker_order_id))
        if order_data.get("long_symbol") != long_symbol:
            return "NSE"
        raw = str(order_data.get("exchange", "") or "NSE").strip().upper()
        if not raw:
            return "NSE"
        if raw == "N":
            return "NSE"
        if raw == "B":
            return "BSE"
        return raw or "NSE"

    broker_name = brok.broker.name if brok is not None else "UNDEFINED"

    if "commission" not in dataframe.columns:
        dataframe["commission"] = 0.0
    else:
        dataframe["commission"] = pd.to_numeric(dataframe["commission"], errors="coerce").fillna(0.0).astype(float)
    dataframe["entry_commission"] = 0.0
    dataframe["exit_commission"] = 0.0

    dataframe = dataframe.reset_index(drop=True)
    for index, row in dataframe.iterrows():
        symbol_str = str(row["symbol"])
        symbol_parts = symbol_str.split("_", 2)
        if len(symbol_parts) < 2:
            continue  # Skip if the symbol is not in the expected format
        entry_date = str(row["entry_time"])[:10]
        exit_date = str(row["exit_time"])[:10]
        entry_gst = config.get_commission_by_date(entry_date, f"{broker_name}.GST", 0)
        exit_gst = config.get_commission_by_date(exit_date, f"{broker_name}.GST", 0)

        # Check if the symbol is a combo symbol and split it into legs
        legs = symbol_str.split(":") if ":" in symbol_str else [symbol_str]
        entry_keys_str = str(row.get("entry_keys", ""))
        entry_keys = entry_keys_str.split(" ") if entry_keys_str else []
        exit_keys_str = str(row.get("exit_keys", ""))
        exit_keys = exit_keys_str.split(" ") if exit_keys_str else []
        total_commission = 0
        total_entry_commission = 0.0
        total_exit_commission = 0.0
        if len(legs) > 1 and brok is None:
            raise ValueError("brok needs to be specfied for combo trades")
        for leg in legs:
            leg_parts = leg.split("?")
            leg_symbol = leg_parts[0]
            leg_size = float(leg_parts[1]) if len(leg_parts) > 1 else 1

            leg_symbol_parts = leg_symbol.split("_")
            symbol_type = leg_symbol_parts[1]

            # Determine the trade_side for each leg based on leg_size
            if leg_size > 0:
                trade_side = str(row["side"])
            else:
                trade_side = "SHORT" if str(row["side"]) == "BUY" else "BUY"

            exit_side = "SHORT" if trade_side == "BUY" else "BUY"  # Determine exit side

            # Find the correct entry and exit keys for this leg
            entry_price = None
            exit_price = None
            entry_exchange = "NSE"
            exit_exchange = "NSE"
            matched_entry_key: Optional[str] = None
            matched_exit_key: Optional[str] = None

            # First finite Redis price per leg (negative allowed); reject nan/inf.
            for entry_key in entry_keys:
                price = get_redis_price(entry_key, leg_symbol, brok)
                if math.isfinite(price):
                    entry_price = price
                    entry_exchange = get_exchange_for_order(entry_key, leg_symbol, brok)
                    matched_entry_key = entry_key
                    break

            for exit_key in exit_keys:
                price = get_redis_price(exit_key, leg_symbol, brok)
                if math.isfinite(price):
                    exit_price = price
                    exit_exchange = get_exchange_for_order(exit_key, leg_symbol, brok)
                    matched_exit_key = exit_key
                    break

            # Fallback to row's entry_price and exitPrice if not found in Redis
            entry_price = entry_price if entry_price is not None else row["entry_price"]
            # exit_price is set to 0 for combo orders irrespective of mtm.
            exit_price = exit_price if exit_price is not None else row["exit_price"] if len(legs) == 1 else 0

            # Fetch commission rates for the entry trade
            flat_rate = config.get_commission_by_date(entry_date, f"{broker_name}.{entry_exchange}.{symbol_type}.{trade_side}.flat", 0)
            per_commission = config.get_commission_by_date(
                entry_date, f"{broker_name}.{entry_exchange}.{symbol_type}.{trade_side}.percentage.commission", 0
            )
            per_stt = config.get_commission_by_date(
                entry_date, f"{broker_name}.{entry_exchange}.{symbol_type}.{trade_side}.percentage.stt", 0
            )
            per_exchange = config.get_commission_by_date(
                entry_date, f"{broker_name}.{entry_exchange}.{symbol_type}.{trade_side}.percentage.exchange", 0
            )
            per_sebi = config.get_commission_by_date(
                entry_date, f"{broker_name}.{entry_exchange}.{symbol_type}.{trade_side}.percentage.sebi", 0
            )
            per_stampduty = config.get_commission_by_date(
                entry_date, f"{broker_name}.{entry_exchange}.{symbol_type}.{trade_side}.percentage.stampduty", 0
            )

            # Calculate the total commission for the entry trade
            entry_trade_value = abs(row["entry_quantity"] * abs(leg_size) * entry_price)
            entry_commission = (
                flat_rate * (100 + entry_gst) / 100
                + (per_commission / 100 * entry_trade_value) * (100 + entry_gst) / 100
                + (per_stt / 100 * entry_trade_value)
                + (per_exchange / 100 * entry_trade_value) * (100 + entry_gst) / 100
                + (per_sebi / 100 * entry_trade_value) * (100 + entry_gst) / 100
                + (per_stampduty / 100 * entry_trade_value)
            )

            # Fetch commission rates for the exit trade
            flat_rate = config.get_commission_by_date(exit_date, f"{broker_name}.{exit_exchange}.{symbol_type}.{exit_side}.flat", 0)
            per_commission = config.get_commission_by_date(
                exit_date, f"{broker_name}.{exit_exchange}.{symbol_type}.{exit_side}.percentage.commission", 0
            )
            per_stt = config.get_commission_by_date(
                exit_date, f"{broker_name}.{exit_exchange}.{symbol_type}.{exit_side}.percentage.stt", 0
            )
            per_exchange = config.get_commission_by_date(
                exit_date, f"{broker_name}.{exit_exchange}.{symbol_type}.{exit_side}.percentage.exchange", 0
            )
            per_sebi = config.get_commission_by_date(
                exit_date, f"{broker_name}.{exit_exchange}.{symbol_type}.{exit_side}.percentage.sebi", 0
            )
            per_stampduty = config.get_commission_by_date(
                exit_date, f"{broker_name}.{exit_exchange}.{symbol_type}.{exit_side}.percentage.stampduty", 0
            )

            # For expiry paper exits, waive only brokerage.
            # Keep statutory levies (STT/exchange/SEBI/stamp duty) unchanged.
            for exit_key in exit_keys:
                if is_expiry_paper_exit(exit_key, leg_symbol, brok):
                    flat_rate = 0
                    per_commission = 0
                    break

            # Calculate the total commission for the exit trade
            exit_trade_value = abs(row["exit_quantity"] * abs(leg_size) * exit_price)
            exit_commission = (
                flat_rate * (100 + exit_gst) / 100
                + (per_commission / 100 * exit_trade_value) * (100 + exit_gst) / 100
                + (per_stt / 100 * exit_trade_value)
                + (per_exchange / 100 * exit_trade_value) * (100 + exit_gst) / 100
                + (per_sebi / 100 * exit_trade_value) * (100 + exit_gst) / 100
                + (per_stampduty / 100 * exit_trade_value)
            )

            # Write commission back to the matched Redis keys
            if brok is not None:
                if matched_entry_key is not None:
                    brok.redis_o.hset(matched_entry_key, "commission", round(entry_commission, 2))
                if matched_exit_key is not None:
                    brok.redis_o.hset(matched_exit_key, "commission", round(exit_commission, 2))

            # Sum up the commission for this leg
            total_commission += entry_commission + exit_commission
            total_entry_commission += entry_commission
            total_exit_commission += exit_commission

        # Update the dataframe with the total commission for the combo symbol
        dataframe.at[index, "commission"] = round(float(total_commission), 2)
        dataframe.at[index, "entry_commission"] = round(total_entry_commission, 2)
        dataframe.at[index, "exit_commission"] = round(total_exit_commission, 2)

    return dataframe


@log_execution_time
@validate_inputs(trades=lambda x: isinstance(x, pd.DataFrame) and len(x) >= 0)
def calc_pnl(trades: pd.DataFrame, brok: Optional[BrokerBase] = None):
    """Calculates absolute profit/loss arising from a trade object.
    This function adds/amends pnl column to input dataframe.

    Args:
        trades: Dataframe of trades
        brok: Optional broker instance for commission calculations

    Returns:
        pd.DataFrame: Trades dataframe with calculated P&L

    Raises:
        ValidationError: If input parameters are invalid
        PnLError: If P&L calculation fails
        CommissionError: If commission calculation fails
    """
    broker_name = brok.broker.name if brok is not None else "UNDEFINED"
    if len(trades) == 0:
        trading_logger.log_info("No trades")
        return trades
    trades = trades.copy()
    if broker_name is not None:
        trades = _update_commissions(trades, brok=brok)
    trades["gross_pnl"] = -1 * (
        trades["exit_price"] * trades["exit_quantity"]
        + trades["mtm"] * -1 * (trades["entry_quantity"] + trades["exit_quantity"])
        + trades["entry_quantity"] * trades["entry_price"]
    )
    trades["pnl"] = trades["gross_pnl"] - trades["commission"]
    return trades


@log_execution_time
@validate_inputs(
    strategy_name=lambda x: isinstance(x, str) and len(x.strip()) > 0,
    capital_allocated=lambda x: isinstance(x, (int, float)) and x >= 0,
    username=lambda x: x is None or (isinstance(x, str) and len(x.strip()) > 0),
)
def register_strategy_capital(
    strategy_name: str,
    broker: BrokerBase,
    capital_allocated: float,
    redis_host: str = "localhost",
    redis_port: int = 6379,
    date: Optional[str] = None,
    username: Optional[str] = None,
) -> bool:
    """
    Register strategy capital allocation and broker capital availability in Redis DB 0.

    Updates the consolidated JSON key:
    - capital:user:{username}:registration:{YYYYMMDD} when username is provided
    - capital:registration:{YYYYMMDD} otherwise

    Args:
        strategy_name: Strategy/algorithm name
        broker: BrokerBase instance (used to get broker name and available capital)
        capital_allocated: Capital allocated to this strategy
        redis_host: Redis host (default: localhost)
        redis_port: Redis port (default: 6379)
        date: Date in YYYYMMDD format (defaults to today)
        username: Optional username (when provided, writes to user-scoped key)

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Determine date
        if date is None:
            date = dt.datetime.now().strftime("%Y%m%d")

        # Get broker name
        if hasattr(broker, "broker") and broker.broker:
            try:
                broker_name = broker.broker.name
            except AttributeError:
                broker_name = "UNKNOWN"
        else:
            broker_name = "UNKNOWN"

        # Get broker available capital
        try:
            capital_dict = broker.get_available_capital()
            if not isinstance(capital_dict, dict):
                # Fallback for old implementations that might still return float
                trading_logger.log_warning(f"get_available_capital returned non-dict type {type(capital_dict)}, converting to dict")
                capital_dict = {
                    "cash": float(capital_dict) if isinstance(capital_dict, (int, float)) else 0.0,
                    "collateral": 0.0,
                }
            # Ensure both keys exist
            cash = capital_dict.get("cash", 0.0)
            collateral = capital_dict.get("collateral", 0.0)
            capital_available = cash + collateral
        except Exception as e:
            trading_logger.log_warning(f"Failed to get available capital from broker {broker_name}: {e}")
            capital_dict = {"cash": 0.0, "collateral": 0.0}
            capital_available = 0.0

        # Connect to Redis DB 0
        redis_conn = redis.Redis(host=redis_host, db=0, port=redis_port, decode_responses=True)
        trading_logger.log_info(f"Connected to Redis at {redis_host}:{redis_port} DB 0 for capital registration")

        # Define registration key
        if username:
            registration_key = f"capital:user:{username}:registration:{date}"
        else:
            registration_key = f"capital:registration:{date}"

        # Use Redis transactions to ensure atomic read-modify-write operations
        max_retries = 3
        for attempt in range(max_retries):
            try:
                with redis_conn.pipeline() as pipe:
                    # Watch the key for changes
                    pipe.watch(registration_key)
                    trading_logger.log_info(f"Watching registration key: {registration_key}")

                    # Get current data (read directly; pipe is in watch mode so reads are immediate)
                    existing_data_str = redis_conn.get(registration_key)
                    trading_logger.log_info(
                        f"Current registration data length: {len(existing_data_str) if existing_data_str else 0}"
                    )

                    if existing_data_str:
                        try:
                            registration_data: dict[str, Any] = json.loads(existing_data_str)
                        except json.JSONDecodeError:
                            trading_logger.log_warning(f"Failed to parse existing registration data for {date}, creating new")
                            registration_data = {
                                "date": date,
                                "brokers": {},
                                "strategies": {},
                                "last_updated": dt.datetime.now().isoformat(),
                            }
                    else:
                        registration_data = {
                            "date": date,
                            "brokers": {},
                            "strategies": {},
                            "last_updated": dt.datetime.now().isoformat(),
                        }

                    # Update broker capital (store both individual values and total)
                    current_time = dt.datetime.now().isoformat()
                    registration_data["brokers"][broker_name] = {
                        "capital_available": capital_available,  # Total for backward compatibility
                        "cash": capital_dict.get("cash", 0.0),
                        "collateral": capital_dict.get("collateral", 0.0),
                        "timestamp": current_time,
                    }

                    # Update strategy registration
                    registration_data["strategies"][strategy_name] = {
                        "broker": broker_name,
                        "capital_allocated": capital_allocated,
                        "timestamp": current_time,
                    }
                    if username:
                        registration_data["strategies"][strategy_name]["username"] = username

                    # Update last_updated timestamp
                    registration_data["last_updated"] = current_time
                    trading_logger.log_info(
                        f"Saving registration data with {len(registration_data.get('strategies', {}))} strategies and {len(registration_data.get('brokers', {}))} brokers"
                    )

                    # Atomically update the registration data
                    pipe.multi()
                    pipe.set(registration_key, json.dumps(registration_data))
                    result = pipe.execute()
                    trading_logger.log_info(f"Redis transaction executed for key {registration_key}, result: {result}")

                # Success - break out of retry loop
                trading_logger.log_info(f"Successfully updated capital registration for {strategy_name} with broker {broker_name}")
                break

            except redis.WatchError:
                # Another client modified the key, retry
                if attempt < max_retries - 1:
                    trading_logger.log_debug(
                        f"Registration key {registration_key} modified by another client, retrying (attempt {attempt + 1}/{max_retries})"
                    )
                    continue
                else:
                    trading_logger.log_error(
                        f"Failed to update registration data after {max_retries} attempts due to concurrent modifications"
                    )
                    return False
            except Exception as e:
                trading_logger.log_error(f"Unexpected error during registration update: {e}")
                return False

        # Also register broker in strategy:broker_universe set
        try:
            # Get Redis DB number from broker's redis_o connection
            redis_db = 0  # Default
            if hasattr(broker, "redis_o") and broker.redis_o:
                # Try to get DB number from connection pool
                if hasattr(broker.redis_o, "connection_pool"):
                    pool = broker.redis_o.connection_pool
                    if hasattr(pool, "connection_kwargs") and "db" in pool.connection_kwargs:
                        redis_db = pool.connection_kwargs["db"]

            # Add broker:DB entry to strategy:broker_universe set
            broker_universe_key = "strategy:broker_universe"
            broker_entry = f"{broker_name}:{redis_db}"
            redis_conn.sadd(broker_universe_key, broker_entry)
            trading_logger.log_debug(f"Added broker to strategy:broker_universe: {broker_entry}")
        except Exception as e:
            # Non-critical error, log but don't fail the registration
            trading_logger.log_warning(f"Failed to register broker in strategy:broker_universe: {e}")

        trading_logger.log_info(
            f"Registered strategy capital: {strategy_name} with broker {broker_name}, "
            f"allocated={capital_allocated}, broker_capital={capital_available}"
        )

        # Verify the data was actually saved
        try:
            saved_data = redis_conn.get(registration_key)
            if saved_data:
                saved_json = json.loads(saved_data)
                strategies = list(saved_json.get("strategies", {}).keys())
                brokers = list(saved_json.get("brokers", {}).keys())
                trading_logger.log_info(
                    f"Verification: Redis key {registration_key} contains strategies={strategies}, brokers={brokers}"
                )
            else:
                trading_logger.log_error(
                    f"Verification FAILED: Redis key {registration_key} is empty or missing after successful registration"
                )
        except Exception as e:
            trading_logger.log_error(f"Verification FAILED: Could not read back Redis key {registration_key}: {e}")

        return True

    except Exception as e:
        trading_logger.log_error(f"Failed to register strategy capital: {e}", exc_info=True)
        return False
