"""Standalone test for find_option_with_delta NaN-robustness fix.

Run: /home/psharma/envs/base/bin/python3 tradingapi2/tests/test_find_option_with_delta.py
"""
import math
import sys
from unittest.mock import patch

# Force import from source repo, not site-packages installed copy.
sys.path.insert(0, "/home/psharma/onedrive/code/tradingapi2")

from tradingapi import utils

assert utils.__file__.startswith("/home/psharma/onedrive/code/tradingapi2/"), (
    f"Wrong tradingapi loaded: {utils.__file__}"
)


def make_chain(strikes, expiry="20260529", opt_type="CALL", underlying="NIFTY"):
    # Symbol format expected by _strike() and calculate_delta: "<u>_<x>_<expiry>_<type>_<strike>_..."
    return [f"{underlying}_X_{expiry}_{opt_type}_{int(s) if s == int(s) else s}_X" for s in strikes]


def bs_like_delta(strike, spot, opt_type="CALL"):
    """Smooth monotone proxy for |delta| as a function of strike. Just needs to be monotone."""
    # CALL delta ~ N(d1); approximate with logistic in (spot - strike)
    x = (spot - strike) / (spot * 0.05)
    sig = 1.0 / (1.0 + math.exp(-x))
    return sig if opt_type == "CALL" else -(1.0 - sig)


def run_case(name, chain, price_f, target_delta, nan_strikes=(), return_lower=True, expect_index=True):
    nan_set = set(nan_strikes)
    call_log = []

    def fake_calc_delta(brokers, sym, pf, *a, **kw):
        strike = float(sym.split("_")[4])
        call_log.append(strike)
        if strike in nan_set:
            return float("nan")
        return bs_like_delta(strike, pf, opt_type=sym.split("_")[3])

    with patch.object(utils, "calculate_delta", side_effect=fake_calc_delta):
        idx = utils.find_option_with_delta(
            brokers=[],
            price_f=price_f,
            option_chain=chain,
            target_delta=target_delta,
            return_lower_delta=return_lower,
        )

    found = idx >= 0
    status = "PASS" if found == expect_index else "FAIL"
    chosen_strike = float(chain[idx].split("_")[4]) if found else None
    chosen_delta = bs_like_delta(chosen_strike, price_f) if chosen_strike is not None else None
    delta_str = f"{abs(chosen_delta):.4f}" if chosen_delta is not None else "n/a"
    print(
        f"[{status}] {name}: idx={idx} strike={chosen_strike} |delta|≈{delta_str} "
        f"calls={len(call_log)} unique={len(set(call_log))} target={target_delta}"
    )
    return status == "PASS", idx, len(call_log)


def main():
    results = []

    # Case 1 — clean chain, no NaN. Should land near target_delta=0.3 and be efficient.
    strikes = [64900 + 100 * i for i in range(215)]  # 64900..86300
    chain = make_chain(strikes)
    ok, idx, calls = run_case("clean chain, target=0.3", chain, 76956.7, 0.3)
    results.append(ok)
    assert calls < 30, f"clean chain should be cheap, got {calls} calls"

    # Case 2 — exact repro of warning: NaN at deep ITM call strikes.
    nan_strikes = [64900.0, 65100.0, 65400.0, 66100.0, 67500.0]
    ok, idx, calls = run_case(
        "warning repro: 5 NaN deep-ITM, target=0.3", chain, 76956.7, 0.3, nan_strikes=nan_strikes
    )
    results.append(ok)

    # Case 3 — NaN cluster centered on mid (chain mid ~ index 107, strike ~75600).
    mid_nans = [strikes[i] for i in range(100, 115)]
    ok, _, _ = run_case("NaN cluster around mid", chain, 76956.7, 0.3, nan_strikes=mid_nans)
    results.append(ok)

    # Case 4 — NaN around the seeding fractions (0.1, 0.25, 0.5, 0.75, 0.9).
    seed_idxs = [int(round(f * 214)) for f in [0.1, 0.25, 0.5, 0.75]]  # leave 0.9 valid
    seed_nans = [strikes[i] for i in seed_idxs]
    ok, _, _ = run_case("NaN at most seed fractions", chain, 76956.7, 0.3, nan_strikes=seed_nans)
    results.append(ok)

    # Case 5 — all but two strikes NaN; should still find via linear fallback.
    valid_strikes = {strikes[50], strikes[160]}
    all_nan = [s for s in strikes if s not in valid_strikes]
    ok, _, _ = run_case(
        "only 2 valid strikes (linear fallback)", chain, 76956.7, 0.3, nan_strikes=all_nan
    )
    results.append(ok)

    # Case 6 — entire chain NaN: must return -1 with warning, not crash.
    ok, idx, _ = run_case(
        "all NaN -> expect -1", chain, 76956.7, 0.3, nan_strikes=strikes, expect_index=False
    )
    results.append(ok)

    # Case 7 — PUT chain (decreasing |delta| with strike).
    put_chain = make_chain(strikes, opt_type="PUT")
    ok, _, _ = run_case("PUT chain target=0.3", put_chain, 76956.7, 0.3)
    results.append(ok)

    # Case 8 — empty chain.
    ok, idx, _ = run_case("empty chain -> -1", [], 76956.7, 0.3, expect_index=False)
    results.append(ok)

    passed = sum(results)
    total = len(results)
    print(f"\n{passed}/{total} passed")
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()
