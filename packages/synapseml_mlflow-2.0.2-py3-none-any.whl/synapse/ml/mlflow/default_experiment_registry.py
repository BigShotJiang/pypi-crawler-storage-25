import logging
import os
from typing import List

from mlflow.tracking.default_experiment.abstract_context import (
    DefaultExperimentProvider,
)

from .model.shared_artifact import (
    _ARTIFACT_TYPE_PUBLIC_NOTEBOOK,
    _ARTIFACT_TYPE_SJD,
    O_PBIArtifact,
)
from .shared_platform_utils import list_workspace_artifacts
from .synapse_mlflow_utils import (
    get_mlflow_env_config,
    in_context,
    record_all_public_functions,
)

logger = logging.getLogger(__name__)


@record_all_public_functions
class SynapseNotebookDefaultExperimentProvider(DefaultExperimentProvider):
    def in_context(self):
        if not in_context():
            return False
        conf = get_mlflow_env_config(False)
        if conf and conf.artifact_id:
            return True
        return False

    def get_experiment_id(self):
        artifact_id = get_mlflow_env_config(False).artifact_id

        try:
            notebooks: List[O_PBIArtifact] = list_workspace_artifacts(
                artifact_type=_ARTIFACT_TYPE_PUBLIC_NOTEBOOK
            )
            sjds: List[O_PBIArtifact] = list_workspace_artifacts(
                artifact_type=_ARTIFACT_TYPE_SJD
            )
            artifacts = notebooks + sjds

            filtered_artifacts_by_id = [
                x
                for x in artifacts
                if x.type in [_ARTIFACT_TYPE_PUBLIC_NOTEBOOK, _ARTIFACT_TYPE_SJD]
                and x.id == artifact_id
            ]
            if len(filtered_artifacts_by_id) == 0:
                raise Exception("Notebook or SJD id not found")
            current_notebook = filtered_artifacts_by_id[0]

            import re

            artifact_name = re.sub("\W+", "-", current_notebook.displayName).strip()
            import mlflow

            return mlflow.set_experiment(f"{artifact_name}").experiment_id

        except:
            logger.exception(
                "Error find or created notebook/SJD default experiment, please call mlflow.set_experiment to set a valid one before run"
            )
            raise
