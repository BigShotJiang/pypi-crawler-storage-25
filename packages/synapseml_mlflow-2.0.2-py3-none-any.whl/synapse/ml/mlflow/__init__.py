import logging
import os

from fabric.analytics.environment.context import FabricContext
from fabric.analytics.environment.log_handlers import LoggingHandlerProvider

from .synapse_mlflow_utils import (
    _TRACKING_URI_ENV_VAR,
    get_mlflow_env_config,
    get_sds_url,
    in_context,
    set_envs,
    set_mlflow_env_config,
)
from .version import VERSION as __version__

logger = logging.getLogger(__name__)
LoggingHandlerProvider().add_handlers(logger)

__all__ = [
    "MLConfig",
    "set_envs",
    "get_sds_url",
    "set_mlflow_env_config",
    "get_mlflow_env_config",
]


def initialize_mlflow():
    if FabricContext().runtime_name in [
        "spark_notebook_driver",
        "spark_notebook_executor",
        "sjd_driver",
        "sjd_executor",
        "python_notebook",
    ]:
        os.environ.setdefault(_TRACKING_URI_ENV_VAR, "sds://")  # This is used by mlflow
        os.environ['MLFLOW_SUPPRESS_PRINTING_URL_TO_STDOUT'] = '1'
        # Fabric synaspeml need this allowlist file
        allow_list_file_path = "/tmp/log_model_allowlist.txt"
        try:
            import shutil
            from importlib.resources import as_file, files

            with as_file(files(__name__).joinpath("log_model_allowlist.txt")) as file:
                builtin_allowlist_file = file.as_posix()
                if not os.path.exists(allow_list_file_path):
                    shutil.copy(builtin_allowlist_file, allow_list_file_path)
        except Exception:
            logger.warning("prepare log_model_allow_list failed")


initialize_mlflow()
