from typing import Dict, List
import logging

logging.getLogger("gson").setLevel(logging.ERROR)

_ARTIFACT_TYPE_NOTEBOOK = "SynapseNotebook"
_ARTIFACT_TYPE_PUBLIC_NOTEBOOK = (
    "Notebook"  # In public api, the artifactType is Notebook
)
_ARTIFACT_TYPE_LAKEHOUSE = "Lakehouse"
_ARTIFACT_TYPE_EXPERIMENT = "MLExperiment"
_ARTIFACT_TYPE_REGISTERED_MODEL = "MLModel"
_ARTIFACT_TYPE_SJD = "SparkJobDefinition"
_ARTIFACT_TYPE_GENRIC = "Item"


class O_PBIArtifact:
    """artifact object in open api"""

    def __init__(
        self,
        id: str,
        type: str,
        displayName: str,
        description: str = "",
        properties: Dict[str, str] = None,
    ):
        self.id = id
        self.type = type
        self.displayName = displayName
        self.description = description
        self.properties = properties


class PBIArtifact:
    def __init__(
        self,
        objectId: str,
        artifactType: str,
        displayName: str,
        provisionState: str,
        description: str = "",
        extendedProperties: Dict[str, str] = None,
    ):
        self.objectId = objectId
        self.artifactType = artifactType
        self.displayName = displayName
        self.provisionState = provisionState
        self.description = description
        self.extendedProperties = extendedProperties


class ListPBIArtifactResponse:
    def __init__(
        self,
        value: List[O_PBIArtifact] = [],
        continuationToken: str = None,
        continuationUri: str = None,
    ):
        self.value = value
        self.continuationToken = continuationToken
        self.continuationUri = continuationUri


class ErrorResponse:
    def __init__(self, requestId: str = "", errorCode: str = "", message: str = ""):
        self.requestId = requestId
        self.errorCode = errorCode
        self.message = message


class PublicApiException(Exception):
    def __init__(self, http_status_code: int, error_response: ErrorResponse):
        self.http_status_code = http_status_code
        self.error_response = error_response


class OperationStatus:
    def __init__(
        self, status: str, createdTimeUtc: str = "", lastUpdatedTimeUtc: str = ""
    ):
        self.status = status
        self.createdTimeUtc = createdTimeUtc
        self.lastUpdatedTimeUtc = lastUpdatedTimeUtc
