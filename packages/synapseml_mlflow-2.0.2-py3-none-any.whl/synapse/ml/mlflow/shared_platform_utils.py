import logging
import time
from typing import List
from urllib.parse import urljoin

import gson

from .model.shared_artifact import (
    _ARTIFACT_TYPE_GENRIC,
    ErrorResponse,
    ListPBIArtifactResponse,
    O_PBIArtifact,
    OperationStatus,
    PublicApiException,
)
from .synapse_mlflow_utils import _get_fabric_rest_client, get_mlflow_env_config, timed

logger = logging.getLogger(__name__)

ASYNC_CREATE_RETRY_COUNT = 60
ASYNC_CREATE_RETRY_INTERVAL = 5


@timed
def list_workspace_artifacts(
    artifact_type: str = _ARTIFACT_TYPE_GENRIC, continuation_token: str = None
) -> List[O_PBIArtifact]:
    res: List[O_PBIArtifact] = []
    config = get_mlflow_env_config(refresh_token=False)
    url = config.public_api_endpoint + f"{artifact_type}s"

    while True:
        url_paginated = url
        if continuation_token:
            url_paginated = url + f"?continuationToken={continuation_token}"

        resp = _get_fabric_rest_client().get(url_paginated)
        if resp.status_code != 200:
            logger.error(
                f"list {artifact_type} failed, status_code: {resp.status_code}, {resp.content}"
            )
            error_resp, _ = gson.unmarshal_from_str(resp.content, ErrorResponse)
            raise PublicApiException(resp.status_code, error_resp)

        artifact_list, _ = gson.unmarshal_from_str(
            resp.content, ListPBIArtifactResponse
        )
        res.extend(artifact_list.value)
        if not artifact_list.continuationToken:
            logger.debug(
                f"continuation token is None, return artifact {artifact_type} list of length {len(res)}"
            )
            break
        else:
            continuation_token = artifact_list.continuationToken
            logger.debug(f"continuation token is {continuation_token}, keep trying...")

    return res


@timed
def create_artifact(
    name: str, artifact_type: str, discription: str = ""
) -> O_PBIArtifact:
    logger.debug("creating new artifact using plugin")

    config = get_mlflow_env_config(refresh_token=False)
    url = config.public_api_endpoint + f"{artifact_type}s"

    data = {
        "displayName": str(name),
        "description": discription,
    }

    if config.folderId:
        data["folderId"] = config.folderId

    logger.debug(f"sending post request to {url}")

    resp = _get_fabric_rest_client().post(url, json=data)
    logger.debug(
        f"create artifact {artifact_type} get return code: {resp.status_code}, headers: {resp.headers}"
    )

    if resp.status_code not in [201, 202]:
        logger.error(
            f"Create {artifact_type} failed, status_code: {resp.status_code}, {resp.content}"
        )
        error_resp, _ = gson.unmarshal_from_str(resp.content, ErrorResponse)
        raise PublicApiException(resp.status_code, error_resp)

    if resp.status_code == 202:
        artifact = check_async_create_result(
            operation_id=resp.headers["x-ms-operation-id"]
        )
    else:
        artifact, _ = gson.unmarshal_from_str(resp.content, O_PBIArtifact)

    artifact = get_artifact(artifact.id, artifact.type)
    return artifact


@timed
def get_artifact(
    artifact_id: str, aritfact_type: str = _ARTIFACT_TYPE_GENRIC
) -> O_PBIArtifact:
    logger.debug("get artifact metadata using plugin")

    config = get_mlflow_env_config(refresh_token=False)
    url = config.public_api_endpoint + f"{aritfact_type}s/{artifact_id}"

    logger.debug(f"sending get request to {url}")

    resp = _get_fabric_rest_client().get(url)
    logger.debug(f"get return code: {resp.status_code}, headers: {resp.headers}")
    if resp.status_code != 200:
        logger.error(
            f"get {artifact_id} {aritfact_type} failed, status_code: {resp.status_code}"
        )
        error_resp, _ = gson.unmarshal_from_str(resp.content, ErrorResponse)
        raise PublicApiException(resp.status_code, error_resp)
    artifact, _ = gson.unmarshal_from_str(resp.content, O_PBIArtifact)
    return artifact


@timed
def delete_artifact(artifact_id: str, artifact_type: str = _ARTIFACT_TYPE_GENRIC):
    logger.debug("delete artifact using plugin")

    config = get_mlflow_env_config(refresh_token=False)
    url = config.public_api_endpoint + f"{artifact_type}s/{artifact_id}"

    logger.debug(f"sending delete request to {url}")
    resp = _get_fabric_rest_client().delete(url)
    logger.debug(
        f"Call delete artifact to shared, with return code: {resp.status_code}, headers {resp.headers}"
    )
    if resp.status_code != 200:
        logger.error(f"{artifact_id} delete failed, status_code: {resp.status_code}")
        error_resp, _ = gson.unmarshal_from_str(resp.content, ErrorResponse)
        raise PublicApiException(resp.status_code, error_resp)


@timed
def get_operation_status(operation_id: str) -> str:
    logger.debug(f"get operation: {operation_id} status using plugin")

    config = get_mlflow_env_config(refresh_token=False)
    url = urljoin(config.shared_host, f"/v1/operations/{operation_id}")

    resp = _get_fabric_rest_client().get(url)
    if resp.status_code != 200:
        error_resp, _ = gson.unmarshal_from_str(resp.content, ErrorResponse)
        raise PublicApiException(resp.status_code, error_resp)
    else:
        operation_status, _ = gson.unmarshal_from_str(resp.content, OperationStatus)
        return operation_status.status


@timed
def get_operation_result(operation_id: str) -> O_PBIArtifact:
    logger.debug(f"get operation: {operation_id} result using plugin")

    config = get_mlflow_env_config(refresh_token=False)
    url = urljoin(config.shared_host, f"/v1/operations/{operation_id}/result")

    resp = _get_fabric_rest_client().get(url)
    if resp.status_code != 200:
        error_resp, _ = gson.unmarshal_from_str(resp.content, ErrorResponse)
        raise PublicApiException(resp.status_code, error_resp)
    else:
        artifact, _ = gson.unmarshal_from_str(resp.content, O_PBIArtifact)
        return artifact


@timed
def check_async_create_result(operation_id: str) -> O_PBIArtifact:
    for _ in range(1, ASYNC_CREATE_RETRY_COUNT + 1):
        operation_status = get_operation_status(operation_id)
        if operation_status not in ["Running", "Succeeded"]:
            raise Exception(f"operation failure, status: {operation_status}")
        if operation_status == "Succeeded":
            return get_operation_result(operation_id)
        time.sleep(ASYNC_CREATE_RETRY_INTERVAL)
