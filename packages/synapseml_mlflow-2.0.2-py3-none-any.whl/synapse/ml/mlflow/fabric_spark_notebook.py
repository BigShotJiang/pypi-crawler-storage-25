from typing import Dict

from fabric.analytics.environment.notebook_plugin.context import get_fabric_context


def parse_and_write_hadoop_conf() -> str:
    """On executor, predict needs to create local spark session in order to
    load spark model. But read/write to onelake will fail since not all necessary
    hadoop config are export to core-site.xml. This function is supposed to used on
    executor which copies origin core-site.xml and fill necessary values in
    '/home/trusted-service-user/.trident-context'

    Raises:
        Exception: When source hadoop config file not found

    Returns:
        str: new HADOOP_CONF_DIR value
    """
    import os
    import shutil
    import xml.etree.ElementTree as ET

    path_to_tmp_hadoop_config = "/tmp/mlflow_predict_hadoop"
    file_name = "core-site.xml"
    file_path = os.path.join(path_to_tmp_hadoop_config, file_name)
    if os.path.exists(file_path):
        return path_to_tmp_hadoop_config
    os.makedirs(path_to_tmp_hadoop_config, exist_ok=True)
    if os.environ.get("HADOOP_CONF_DIR"):
        src_dir = os.environ.get("HADOOP_CONF_DIR")
        files = os.listdir(src_dir)
        for file_name in files:
            src_file_path = os.path.join(src_dir, file_name)
            dst_file_path = os.path.join(path_to_tmp_hadoop_config, file_name)
            try:
                shutil.copy2(src_file_path, dst_file_path)
            except shutil.SameFileError:
                pass
    else:
        raise Exception("HADOOP_CONF_DIR does not exist")

    config_path = os.path.join(os.environ["HADOOP_CONF_DIR"], "core-site.xml")
    tree = ET.parse(config_path)
    root = tree.getroot()
    true_config = get_fabric_context()
    if not true_config:
        raise Exception("fabric context file does not exist")
    for k, v in true_config.items():
        target_element = root.find(f"./property[name='{k}']")
        if target_element:
            target_element.find("value").text = str(v)
        else:
            property_element = ET.Element("property")
            name_elem = ET.SubElement(property_element, "name")
            name_elem.text = str(k)
            value_ele = ET.SubElement(property_element, "value")
            value_ele.text = str(v)
            root.append(property_element)
    tree.write(file_path)
    return path_to_tmp_hadoop_config
