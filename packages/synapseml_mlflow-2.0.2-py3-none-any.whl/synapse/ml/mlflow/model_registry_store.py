# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import List

from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import RESOURCE_ALREADY_EXISTS
from mlflow.protos.model_registry_pb2 import (
    DeleteModelVersion,
    DeleteModelVersionTag,
    DeleteRegisteredModelTag,
)
from mlflow.store.model_registry.rest_store import _METHOD_TO_INFO, RestStore
from mlflow.utils.proto_json_utils import message_to_json
from mlflow.utils.rest_utils import MlflowHostCreds, call_endpoint

from .model.shared_artifact import (
    _ARTIFACT_TYPE_REGISTERED_MODEL,
    O_PBIArtifact,
    PublicApiException,
)
from .shared_platform_utils import (
    create_artifact,
    delete_artifact,
    list_workspace_artifacts,
)
from .synapse_mlflow_utils import (
    _get_fabric_token,
    check_model_name,
    get_mlflow_env_config,
    record_all_public_functions,
    timed,
)

logger = logging.getLogger(__name__)


@record_all_public_functions
class TridentMLflowModelRegistryStore(record_all_public_functions(RestStore)):
    def __init__(self):
        RestStore.__init__(self, self.get_host_credentials)

    @staticmethod
    def get_host_credentials():
        config = get_mlflow_env_config(refresh_token=False)
        url_base = config.public_api_endpoint + "mlflow/"
        token = _get_fabric_token()
        return MlflowHostCreds(
            host=url_base,
            token=token,
        )

    @timed
    def delete_registered_model(self, name):
        logger.debug("deleting registered model using plugin")

        artifact_id = ""
        artifacts: List[O_PBIArtifact] = list_workspace_artifacts(
            _ARTIFACT_TYPE_REGISTERED_MODEL
        )
        for art in artifacts:
            if art.displayName == name and art.type == _ARTIFACT_TYPE_REGISTERED_MODEL:
                artifact_id = art.id

        logger.debug(f"plugin: get artifact id: {artifact_id}")
        if not artifact_id:
            logger.info(f"register model {name} does not exist")

        delete_artifact(artifact_id, artifact_type=_ARTIFACT_TYPE_REGISTERED_MODEL)
        return

    @timed
    def create_registered_model(self, name, tags=None, description=None, deployment_job_id=None):
        if not check_model_name(name):
            err_msg = "Model names must be less than 256 characters, begin with a letter or number, and may only include dashes (-), periods (.), or underscores (_)."
            logger.error(err_msg)
            raise Exception(err_msg)

        try:
            create_artifact(name=name, artifact_type=_ARTIFACT_TYPE_REGISTERED_MODEL)
        except PublicApiException as e:
            if (
                e.error_response
                and e.error_response.errorCode == "ItemDisplayNameAlreadyInUse"
            ):
                raise MlflowException(
                    f"model name {name} already in use", RESOURCE_ALREADY_EXISTS
                )

        return super().get_registered_model(name)

    def _call_endpoint_custom(self, api, json_body, endpoint, method):
        response_proto = api.Response()
        return call_endpoint(
            self.get_host_creds(), endpoint, method, json_body, response_proto
        )

    @timed
    def delete_model_version_tag(self, name, version, key):
        """
        Delete a tag associated with the model version.

        Args:
            name: Registered model name.
            version: Registered model version.
            key: Tag key.

        Returns:
            None
        """
        req_body = message_to_json(
            DeleteModelVersionTag(name=name, version=version, key=key)
        )
        endpoint, method = _METHOD_TO_INFO[DeleteModelVersionTag]
        self._call_endpoint_custom(
            DeleteModelVersionTag,
            req_body,
            endpoint=endpoint + f"?name={name}&version={version}&key={key}",
            method=method,
        )

    @timed
    def delete_model_version(self, name, version):
        """
        Delete model version in backend.

        Args:
            name: Registered model name.
            version: Registered model version.

        Returns:
            None
        """
        req_body = message_to_json(DeleteModelVersion(name=name, version=str(version)))
        endpoint, method = _METHOD_TO_INFO[DeleteModelVersion]
        self._call_endpoint_custom(
            DeleteModelVersion,
            req_body,
            endpoint=endpoint + f"?name={name}&version={str(version)}",
            method=method,
        )

    @timed
    def delete_registered_model_tag(self, name, key):
        """
        Delete a tag associated with the registered model.

        Args:
            name: Registered model name.
            key: Registered model tag key.

        Returns:
            None
        """
        req_body = message_to_json(DeleteRegisteredModelTag(name=name, key=key))
        endpoint, method = _METHOD_TO_INFO[DeleteRegisteredModelTag]
        self._call_endpoint_custom(
            DeleteRegisteredModelTag,
            req_body,
            endpoint=endpoint + f"?name={name}&key={key}",
            method=method,
        )
