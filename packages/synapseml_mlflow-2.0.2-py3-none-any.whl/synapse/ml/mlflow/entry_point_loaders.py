# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


def tridentml_tracking_store_builder(store_uri, artifact_uri=None):
    from mlflow.exceptions import MlflowException

    from .tracking_store import TridentMLflowTrackingStore

    if not store_uri:
        raise MlflowException(
            "Store URI provided to synapseml_tracking_store_builder cannot be None or empty."
        )
    return TridentMLflowTrackingStore()


def tridentml_artifacts_builder(artifact_uri=None):
    from .artifact_repo import TridentMLflowArtifactRepository

    return TridentMLflowArtifactRepository(artifact_uri)


def tridentml_run_context_provider_builder():
    from .run_context_provider import TridentMLflowContextProvider

    return TridentMLflowContextProvider()


def tridentml_model_registry_store_builder(store_uri):
    from mlflow.exceptions import MlflowException

    from .model_registry_store import TridentMLflowModelRegistryStore

    if not store_uri:
        raise MlflowException(
            "Store URI provided to synapseml_model_registry_store_builder cannot be None or empty."
        )
    return TridentMLflowModelRegistryStore()


def tridentml_request_header_provider_builder():
    from .request_header_provider import TridentRequestHeaderProvider

    return TridentRequestHeaderProvider()
