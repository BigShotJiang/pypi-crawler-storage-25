# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import inspect
import logging
import os
import re
import time
import urllib
from typing import Optional, Tuple
from urllib.parse import urljoin

from azure.core.pipeline import PipelineContext, PipelineRequest
from azure.core.pipeline.policies import BearerTokenCredentialPolicy, RetryPolicy
from azure.core.pipeline.transport import HttpRequest, RequestsTransport
from fabric.analytics.environment.constant import PBI_SCOPE, PBI_SCOPE_PPE
from fabric.analytics.environment.context import FabricContext, InternalContext
from fabric.analytics.environment.credentials import FabricAnalyticsTokenCredentials
from fabric.analytics.rest.fabric_client import FabricRestClient

logger = logging.getLogger(__name__)

_TRACKING_URI_ENV_VAR = "MLFLOW_TRACKING_URI"
_MLFLOW_DFS_TMP = "MLFLOW_DFS_TMP"  # since mlflow 1.30

_fabric_client: Optional[FabricRestClient] = None
_fabric_bearer_credential_policy: Optional[BearerTokenCredentialPolicy] = None


_REVERSE_MAPPING_FROM_HOST_TO_ENV = {
    "onebox-redirect.analysis.windows-int.net": "onebox",
    "dailyapi.fabric.microsoft.com": "daily",
    "powerbiapi.analysis-df.windows.net": "edog",
    "dxtapi.fabric.microsoft.com": "dxt",
    "msitapi.fabric.microsoft.com": "msit",
    "api.fabric.microsoft.com": "prod",
}


class MLflowEnvConfig:
    def __init__(
        self,
        workspace_id: str,
        onelake_endpoint: str,
        shared_host: str,
        shared_endpoint: str,
        tracking_uri: str,
        pbienv: str,
        public_api_endpoint: str,
        is_ppe: bool,
        runtime_name: str,
        pbi_audience: str,
        capacity_id: Optional[str] = None,
        artifact_id: Optional[str] = None,
        artifact_type: Optional[str] = None,
        workload_endpoint: Optional[str] = None,  # MLFLOW
        region: Optional[str] = None,
        driver_aad_token: Optional[str] = None,
        driver_storage_token: Optional[str] = None,
        driver_ml_aad_token: Optional[str] = None,
        session_id: Optional[str] = None,
        folderId: Optional[str] = None,
    ):
        self.capacity_id = capacity_id
        self.workspace_id = workspace_id
        self.artifact_id = artifact_id
        self.artifact_type = artifact_type
        self.onelake_endpoint = onelake_endpoint
        self.workload_endpoint = workload_endpoint
        self.shared_host = shared_host
        self.shared_endpoint = shared_endpoint
        self.tracking_uri = tracking_uri
        self.region = region
        self.pbienv = pbienv
        self.driver_aad_token = driver_aad_token
        self.driver_storage_token = driver_storage_token
        self.driver_ml_aad_token = driver_ml_aad_token
        self.public_api_endpoint = public_api_endpoint
        self.session_id = session_id
        self.is_ppe = is_ppe
        self.runtime_name = runtime_name
        self.pbi_audience = pbi_audience
        self.folderId = folderId

    def __str__(self) -> str:
        return gson.marshal(self)

    @classmethod
    def resolve_mlflow_config(
        self, context: FabricContext = FabricContext(), folderId=None
    ) -> "MLflowEnvConfig":
        capacity_id = context.capacity_id
        workspace_id = context.workspace_id
        artifact_id = (
            context.artifact_context.artifact_id if context.artifact_context else None
        )
        artifact_type = (
            context.artifact_context.artifact_type if context.artifact_context else None
        )
        onelake_endpoint = context.onelake_endpoint
        region = context.internal_context.region
        pbienv = context.internal_context.rollout_stage

        shared_host = context.pbi_shared_host
        shared_endpoint = urljoin(
            shared_host, f"/metadata/workspaces/{workspace_id}/artifacts"
        )
        public_api_endpoint = urljoin(shared_host, f"/v1/workspaces/{workspace_id}/")
        workload_endpoint = "unknown"
        try:
            workload_endpoint = urljoin(
                context.mwc_workload_host,
                f"/webapi/capacities/{capacity_id}/workloads/ML/ML/Automatic/workspaceid/{workspace_id}/",
            )
        except:
            logger.warning(
                f"Unable to resolve workload endpoint, if you ref MLflowEnvConfig.workload_endpoint, you must set mwc_workload_host explicitly"
            )

        session_id = (
            context.artifact_context.session_id if context.artifact_context else None
        )
        is_ppe = context.internal_context.is_ppe()
        runtime_name = context.runtime_name
        pbi_audience = (
            "https://analysis.windows.net/powerbi/api/.default"
            if not is_ppe
            else "https://analysis.windows-int.net/powerbi/api/.default"
        )
        tracking_uri = get_sds_url(public_api_endpoint + "mlflow", folderId=folderId)
        return MLflowEnvConfig(
            workspace_id=workspace_id,
            onelake_endpoint=onelake_endpoint,
            shared_host=shared_host,
            shared_endpoint=shared_endpoint,
            tracking_uri=tracking_uri,
            pbienv=pbienv,
            public_api_endpoint=public_api_endpoint,
            runtime_name=runtime_name,
            is_ppe=is_ppe,
            pbi_audience=pbi_audience,
            # below are optional and can be None
            capacity_id=capacity_id,
            artifact_id=artifact_id,
            artifact_type=artifact_type,
            workload_endpoint=workload_endpoint,
            region=region,
            session_id=session_id,
            folderId=folderId,
        )


_mlflow_env_config: Optional[MLflowEnvConfig] = None


def is_fabric_online_env() -> bool:
    if not _mlflow_env_config:
        return False
    return _mlflow_env_config.runtime_name in [
        "spark_notebook_driver",
        "spark_notebook_executor",
        "sjd_driver",
        "sjd_executor",
        "python_notebook",
    ]


def is_fabric_spark_executor() -> bool:
    if not _mlflow_env_config:
        return False
    return _mlflow_env_config.runtime_name in [
        "pyspark_notebook_executor",
        "sjd_executor",
    ]


def set_mlflow_env_config(value: MLflowEnvConfig):
    global _mlflow_env_config
    _mlflow_env_config = value

    os.environ[_TRACKING_URI_ENV_VAR] = (
        _mlflow_env_config.tracking_uri
    )  # This is used by mlflow
    # pass driver token to executor
    logger.info(
        f"setting mlflow tracking uri to {_mlflow_env_config.tracking_uri}, change this environment variable if you want log to other places"
    )

    if is_fabric_online_env():
        from fabric.analytics.environment.notebook_plugin.context import (
            get_fabric_context,
        )

        from .fabric_spark_notebook import parse_and_write_hadoop_conf

        # below are fabric notebook specific processing
        os.environ[_MLFLOW_DFS_TMP] = os.environ.get(
            _MLFLOW_DFS_TMP, "Files/tmp/mlflow"
        )  # this doesn't work for mlflow 1.27 and below
        if (
            get_fabric_context().get("trident.catalog.metastore.lakehouseName")
            == "<no-lakehouse-specified>"
        ):
            logger.warning(
                "To save or load Apache Spark model files, please attach a Lakehouse."
            )
        if is_fabric_spark_executor():
            # only on spark executor, we need below code to ensure safe local spark session
            try:
                hadoop_config_path = parse_and_write_hadoop_conf()
                os.environ["HADOOP_CONF_DIR"] = hadoop_config_path
            except Exception:
                logger.debug("parse_and_write_hadoop_conf error")


def get_mlflow_env_config(refresh_token: bool = True) -> MLflowEnvConfig:
    global _mlflow_env_config
    set_envs()

    if refresh_token:
        credential = FabricAnalyticsTokenCredentials()
        _mlflow_env_config.driver_aad_token = credential.get_token(
            (_mlflow_env_config.pbi_audience), use_ml_1p=False
        ).token
        _mlflow_env_config.driver_storage_token = credential.get_token(
            ("https://storage.azure.com/.default")
        ).token
        _mlflow_env_config.driver_ml_aad_token = credential.get_token(
            (_mlflow_env_config.pbi_audience)
        ).token
    return _mlflow_env_config


def extrat_context_from_tracking_uri() -> Tuple[Optional[FabricContext], Optional[str]]:
    tracking_uri = os.environ.get(_TRACKING_URI_ENV_VAR, "")
    pattern = re.compile(
        r"^sds://(?P<host>[^/]+)/v1/workspaces/(?P<workspace_id>[^/]+)/mlflow/?(?:\?folderId=(?P<folderId>[^&]+))?$"
    )
    match = pattern.match(tracking_uri)
    if not match:
        return None, None
    host, workspace_id, folderId = (
        match.group("host"),
        match.group("workspace_id"),
        match.group("folderId"),
    )
    rollout_stage = _REVERSE_MAPPING_FROM_HOST_TO_ENV.get(host, None)
    if not rollout_stage:  # doesn't match any pe disabled url
        # Maybe it is pe enabled host
        pattern = re.compile(
            r"^(?:[a-z0-9-]+\.)*(?:([a-z0-9]+))?api\.fabric\.microsoft\.com$",
            re.IGNORECASE,
        )
        match = pattern.search(host)
        if not match:
            logger.warning(f"can't parse {tracking_uri}, will use default context")
            return None, None
        else:
            rollout_stage = match.group(1) or "prod"
            logger.debug(
                f"successfully parse {tracking_uri} as rollout {rollout_stage}, pe enabled"
            )

            context = FabricContext(
                workspace_id=workspace_id,
                internal_context=InternalContext(
                    rollout_stage=rollout_stage, is_wspl_enabled=True
                ),
            )

            if host != (context.pbi_shared_host).removeprefix("https://").removesuffix(
                "/"
            ):
                raise Exception(
                    f"invalid tracking uri host: {tracking_uri}, resolved host name is {(context.pbi_shared_host).removeprefix('https://').removesuffix('/')}, but tracking uri has {host}"
                )

            return context, folderId
    else:
        logger.debug(
            f"successfully parse {tracking_uri} as rollout {rollout_stage}, pe disabled"
        )
        return (
            FabricContext(
                workspace_id=workspace_id,
                internal_context=InternalContext(
                    rollout_stage=rollout_stage, is_wspl_enabled=False
                ),
            ),
            folderId,
        )


def set_envs(
    context: Optional[FabricContext] = None,
    connection_timeout=30,
    read_timeout=30,
    retry_total=0,
):
    global _mlflow_env_config
    if not context and (
        _mlflow_env_config is not None
        and _mlflow_env_config.tracking_uri
        == os.environ.get(_TRACKING_URI_ENV_VAR, None)
    ):
        # no explicit context, and current setting match environment tracking uri
        return

    folderId = None
    if not context:
        # User pass context > tracking uri context > default context
        context, folderId = extrat_context_from_tracking_uri()
        if not context:
            context = FabricContext()

    config = MLflowEnvConfig.resolve_mlflow_config(context, folderId=folderId)
    set_mlflow_env_config(config)
    # remove cached credential and client
    _clean_up()
    _set_up(
        is_ppe=config.is_ppe,
        connection_timeout=connection_timeout,
        read_timeout=read_timeout,
        retry_total=retry_total,
    )


def get_sds_url(mlflow_endpoint: str, folderId: Optional[str] = None):
    parsed = urllib.parse.urlparse(mlflow_endpoint)
    host_name = parsed.hostname
    path = parsed.path
    endpoint = "sds://" + host_name + path

    if folderId:
        endpoint += f"?folderId={urllib.parse.quote(folderId)}"

    return endpoint


def protect_module(module_name: str, throwable: bool = True):
    """
    decorate a function so that it catch and record all exceptions
    """

    from mlflow.exceptions import MlflowException, RestException

    # reference here to avoid circular exception

    def catch_and_log_exception(original_function):
        function = original_function
        if isinstance(original_function, classmethod) or isinstance(
            original_function, staticmethod
        ):
            function = original_function.__func__

        def wrapper(*args, **kwargs):
            try:
                res = function(*args, **kwargs)
            except (RestException, MlflowException) as e:
                if e.error_code in {"RESOURCE_DOES_NOT_EXIST"}:
                    logger.warning(f"[fabric mlflow plugin]: {module_name} {e.message}")
                elif e.error_code in {"RESOURCE_ALREADY_EXISTS"}:
                    pass
                else:
                    logger.error(f"[fabric mlflow plugin]: {module_name} exception {e}")
                    logger.exception(f"[fabric mlflow plugin]: {module_name} exception")
                if throwable:
                    raise
            except Exception as e:
                logger.error(f"[fabric mlflow plugin]: {module_name} exception {e}")
                logger.exception(f"[fabric mlflow plugin]: {module_name} exception")
                if throwable:
                    raise
            return res

        if isinstance(original_function, classmethod):
            return classmethod(wrapper)
        elif isinstance(original_function, staticmethod):
            return staticmethod(wrapper)
        else:
            return wrapper

    return catch_and_log_exception


def record_all_public_functions(cls):
    for attr in cls.__dict__:
        if callable(inspect.getattr_static(cls, attr)) and not str(
            inspect.getattr_static(cls, attr).__qualname__
        ).startswith("_"):
            setattr(
                cls,
                attr,
                protect_module(f"{cls}.{attr}", throwable=True)(
                    inspect.getattr_static(cls, attr)
                ),
            )
    return cls


def timed(function):
    def wrapper(*args, **kwargs):
        start = time.time()
        res = function(*args, **kwargs)
        end = time.time()
        logger.debug(
            f"[trident mlflow plugin]: {function.__qualname__} takes {end-start}s"
        )
        return res

    return wrapper


def check_experiment_name(input_string) -> re.Match[str] | None:
    regex = r"^[a-zA-Z0-9][\w\\-]{0,255}$"
    return re.match(regex, input_string)


def check_model_name(input_string) -> re.Match[str] | None:
    regex = r"^[a-zA-Z0-9][a-zA-Z0-9\-\\._]{0,254}$"
    return re.match(regex, input_string)


def _clean_up():
    global _fabric_client
    global _fabric_bearer_credential_policy
    _fabric_client = None
    _fabric_bearer_credential_policy = None


def _set_up(
    is_ppe: bool = False,
    connection_timeout=30,
    read_timeout=30,
    retry_total=1,
):
    global _fabric_client
    global _fabric_bearer_credential_policy

    kwargs = {}
    if is_ppe:
        kwargs.setdefault("is_ppe", is_ppe)

    scopes = PBI_SCOPE_PPE if is_ppe else PBI_SCOPE

    credential = FabricAnalyticsTokenCredentials(**kwargs)
    _fabric_bearer_credential_policy = BearerTokenCredentialPolicy(credential, scopes)
    # Not passing endpoint since we will use the endpoint in mlflow env config
    _fabric_client = FabricRestClient(
        is_ppe=is_ppe,
        transport=RequestsTransport(
            connection_timeout=connection_timeout, read_timeout=read_timeout
        ),
        retry_policy=RetryPolicy(retry_total=retry_total),
    )


def _get_fabric_rest_client() -> FabricRestClient:
    if not _fabric_client:
        _set_up(is_ppe=get_mlflow_env_config(refresh_token=False).is_ppe)
    return _fabric_client


def _get_fabric_token() -> str:
    if not _fabric_bearer_credential_policy:
        _set_up(is_ppe=get_mlflow_env_config(refresh_token=False).is_ppe)
    http_request = HttpRequest("GET", "https://example.org")
    pipeline_request = PipelineRequest(http_request, PipelineContext(transport=None))
    _fabric_bearer_credential_policy.on_request(pipeline_request)
    return _extract_bearer_token(pipeline_request.http_request.headers["Authorization"])


def _extract_bearer_token(header):
    # Regex to match "Bearer <token>"
    match = re.match(r"^Bearer (\S+)$", header)
    if match:
        return match.group(1)  # Returns the token
    else:
        return None  # Return None if the header format is incorrect


def in_context():
    return os.environ.get(_TRACKING_URI_ENV_VAR, "").startswith("sds://")
