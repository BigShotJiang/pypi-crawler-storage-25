from mlflow.tracking.request_header.abstract_request_header_provider import (
    RequestHeaderProvider,
)

from .synapse_mlflow_utils import get_mlflow_env_config, in_context


class TridentRequestHeaderProvider(RequestHeaderProvider):
    def in_context(self):
        return in_context()

    def request_headers(self):
        request_headers = {}
        request_headers["x-ms-workload-resource-moniker"] = get_mlflow_env_config(
            refresh_token=False
        ).artifact_id
        return request_headers
