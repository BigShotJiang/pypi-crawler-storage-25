# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from mlflow.entities.run_status import RunStatus
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import RESOURCE_ALREADY_EXISTS
from mlflow.store.tracking.rest_store import RestStore
from mlflow.utils import rest_utils, validation
from mlflow.utils.proto_json_utils import message_to_json
from mlflow.utils.rest_utils import MlflowHostCreds
from requests import Response

from .model.shared_artifact import (
    _ARTIFACT_TYPE_EXPERIMENT,
    _ARTIFACT_TYPE_NOTEBOOK,
    O_PBIArtifact,
    PublicApiException,
)
from .run_context_provider import TridentMLflowContextProvider
from .shared_platform_utils import (
    create_artifact,
    delete_artifact,
    list_workspace_artifacts,
)
from .synapse_mlflow_utils import (
    _get_fabric_token,
    check_experiment_name,
    get_mlflow_env_config,
    record_all_public_functions,
    timed,
)

logger = logging.getLogger(__name__)
origin_func = rest_utils.verify_rest_response
validation.MAX_PARAM_VAL_LENGTH = 500


def wrapper(response: Response, endpoint: str):
    info_msg = f"call {endpoint}, resp code: {response.status_code}, headers: {response.headers}"
    logger.debug(info_msg)
    return origin_func(response, endpoint)


rest_utils.verify_rest_response = wrapper


@record_all_public_functions
class TridentMLflowTrackingStore(record_all_public_functions(RestStore)):
    def __init__(self):
        RestStore.__init__(self, self.get_host_credentials)
        pass

    @staticmethod
    def get_host_credentials():
        try:
            config = get_mlflow_env_config(refresh_token=False)
            url_base = config.public_api_endpoint + "mlflow/"
            token = _get_fabric_token()
            return MlflowHostCreds(host=url_base, token=token)
        except Exception:
            logger.exception("get_host_credentials fatal error")
            raise

    @staticmethod
    def check_experiment_name_valid(name):
        if not check_experiment_name(name):
            err_msg = "Experiment names must be less than 257 characters, begin with a letter or number, and may only include dashes (-) or underscores (_)."
            logger.error(err_msg)
            raise Exception(err_msg)

    @timed
    def check_experiment_artifact_id(self, experiment_id):
        logger.debug("check fabric artifact id using plugin")

        artifact_id = ""
        artifacts = list_workspace_artifacts(artifact_type=_ARTIFACT_TYPE_EXPERIMENT)
        for art in artifacts:
            if (
                art.properties
                and art.properties.get(
                    "mlFlowExperimentId", art.properties.get("MLFlowExperimentId", None)
                )
                == experiment_id
            ):
                artifact_id = art.id

        logger.debug(f"plugin: get artifact id: {artifact_id}")

        return artifact_id

    @timed
    def delete_experiment(self, experiment_id: str):
        logger.debug("delete experiment using plugin")

        artifact_id = self.check_experiment_artifact_id(experiment_id=experiment_id)

        if artifact_id == "":
            logger.error("Experiment Id not found")
            return

        delete_artifact(
            artifact_id=artifact_id, artifact_type=_ARTIFACT_TYPE_EXPERIMENT
        )
        return

    @timed
    def create_experiment(self, name, artifact_location=None, tags=None):
        self.check_experiment_name_valid(name)

        artifact: O_PBIArtifact = None
        try:
            artifact = create_artifact(
                name=name, artifact_type=_ARTIFACT_TYPE_EXPERIMENT
            )
        except PublicApiException as e:
            if (
                e.error_response
                and e.error_response.errorCode == "ItemDisplayNameAlreadyInUse"
            ):
                raise MlflowException(
                    f"experiment name {name} already in use", RESOURCE_ALREADY_EXISTS
                )

        experiment_id = artifact.properties.get(
            "mlFlowExperimentId", artifact.properties.get("MLFlowExperimentId", None)
        )
        logger.debug(f"experiment id: {experiment_id}")
        if not experiment_id:
            raise Exception("missing experiment id in experiment metadata")

        if tags:
            logger.debug(f"create experiment with tags {tags}")
            for tag in tags:
                self.set_experiment_tag(experiment_id, tag)

        return experiment_id

    def record_logged_model(self, run_id, mlflow_model):
        logger.debug(f"Model: {mlflow_model}")
        return

    @timed
    def get_experiment_by_name(self, experiment_name):
        self.check_experiment_name_valid(experiment_name)
        return super().get_experiment_by_name(experiment_name)

    @timed
    def log_metric(self, run_id, metric):
        super().log_metric(run_id, metric)

    @timed
    def log_param(self, run_id, param):
        validated_param = validation._validate_param(param.key, param.value)
        # In previous version, mlflow don't truncate for you and the function return None
        param = validated_param if validated_param else param
        return super().log_param(run_id, param)

    @timed
    def log_batch(self, run_id, metrics, params, tags):
        validated_data = validation._validate_batch_log_data(metrics, params, tags)
        if validated_data:
            metrics, params, tags = validated_data
        return super().log_batch(run_id, metrics, params, tags)

    def log_inputs(self, run_id: str, datasets=None):
        logger.debug("log_inputs not supported")
        return

    @timed
    def update_run_info(self, run_id, run_status, end_time, run_name):
        runinfo = super().update_run_info(run_id, run_status, end_time, run_name)
        if get_mlflow_env_config(refresh_token=False).runtime_name in [
            "spark_notebook_driver",
            "python_notebook",
        ] and run_status in [
            RunStatus.FINISHED,
            RunStatus.FAILED,
        ]:  # on driver
            try:
                from IPython.display import publish_display_data

                run = self.get_run(run_id=run_id)
                experiment = self.get_experiment(run.info.experiment_id)
                run_info_for_fe = run.to_dictionary()
                run_info_for_fe["data"]["tags"][
                    "synapseml.experimentName"
                ] = experiment.name
                run_info_for_fe["data"]["tags"]["synapseml.experiment.artifactId"] = (
                    self.check_experiment_artifact_id(run.info.experiment_id)
                )
                logger.debug(f"passing inline experiment info to FE: {run_info_for_fe}")
                publish_display_data(
                    {"application/vnd.mlflow.run-widget+json": run_info_for_fe}
                )
            except Exception as e:
                logger.exception("display inline experiment error")
                logger.debug(f"display inline experiment error: {e}")
        else:
            logger.debug("not in notebook env, skip inline display")

        return runinfo

    def delete_trace_tag(self, request_id, key):
        """
        Delete a tag on the trace with the given request_id.

        Args:
            request_id: The ID of the trace.
            key: The string key of the tag.
        """
        from mlflow.protos.service_pb2 import DeleteTraceTag
        from mlflow.utils.rest_utils import get_set_trace_tag_endpoint

        req_body = message_to_json(DeleteTraceTag(key=key))
        self._call_endpoint(
            DeleteTraceTag,
            req_body,
            endpoint=get_set_trace_tag_endpoint(request_id) + f"?key={key}",
        )

    def start_trace(
        self,
        experiment_id: str,
        timestamp_ms: int,
        request_metadata: dict[str, str],
        tags: dict[str, str],
    ):
        """
        Start an initial TraceInfo object in the backend store.

        Args:
            experiment_id: String id of the experiment for this run.
            timestamp_ms: Start time of the trace, in milliseconds since the UNIX epoch.
            request_metadata: Metadata of the trace.
            tags: Tags of the trace.

        Returns:
            The created TraceInfo object.
        """
        if tags is None:
            tags = {}

        tags.update(TridentMLflowContextProvider().tags())
        return super().start_trace(
            experiment_id=experiment_id,
            timestamp_ms=timestamp_ms,
            request_metadata=request_metadata,
            tags=tags,
        )
