# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import getpass
import logging
import os
import sys

import jwt
from mlflow import __version__
from mlflow.entities import SourceType
from mlflow.tracking.context.abstract_context import RunContextProvider
from mlflow.utils.mlflow_tags import MLFLOW_SOURCE_NAME, MLFLOW_SOURCE_TYPE, MLFLOW_USER

from .synapse_mlflow_utils import (
    _get_fabric_token,
    get_mlflow_env_config,
    in_context,
    is_fabric_online_env,
)

logger = logging.getLogger(__name__)

_DEFAULT_USER = "unknown"
_PRODUCT_PREFIX = "synapseml"


def _get_user():
    """Get the current computer username."""
    try:
        return getpass.getuser()
    except ImportError:
        return _DEFAULT_USER


def _get_main_file():
    if len(sys.argv) > 0:
        return sys.argv[0]
    return None


def _get_source_name():
    main_file = _get_main_file()
    if main_file is not None:
        return main_file
    return "<console>"


def _get_notebook_id():
    artifact_id = get_mlflow_env_config(False).artifact_id
    if artifact_id is not None:
        return artifact_id
    return None


def _get_trident_user():
    config = get_mlflow_env_config(refresh_token=False)
    aad_token = _get_fabric_token()

    try:
        t_decode = jwt.decode(aad_token, options={"verify_signature": False})
        user_name = t_decode.get("name")
        user_id = t_decode.get("oid")
    except:
        user_name = None
        user_id = None
    return user_name, user_id


def _get_source_type():
    return SourceType.LOCAL


class TridentMLflowContextProvider(RunContextProvider):
    def in_context(self):
        return in_context()

    def tags(self):
        tag_dict = {
            MLFLOW_USER: _get_user(),
            MLFLOW_SOURCE_NAME: _get_source_name(),
            MLFLOW_SOURCE_TYPE: SourceType.to_string(_get_source_type()),
            f"{_PRODUCT_PREFIX}.mlflow_oss.version": __version__,
        }

        notebook_id = _get_notebook_id()
        if notebook_id:
            tag_dict.update({f"{_PRODUCT_PREFIX}.notebook.artifactId": notebook_id})

        user_name, user_id = _get_trident_user()
        if user_name:
            tag_dict.update({f"{_PRODUCT_PREFIX}.user.name": user_name})
        if user_id:
            tag_dict.update({f"{_PRODUCT_PREFIX}.user.id": user_id})
        if get_mlflow_env_config(refresh_token=False).session_id:
            tag_dict["synapseml.livy.id"] = get_mlflow_env_config(
                refresh_token=False
            ).session_id
        if is_fabric_online_env():
            from fabric.analytics.environment.notebook_plugin.context import (
                get_fabric_context,
            )

            tag_dict["synapseml.source.workspace.id"] = get_fabric_context().get(
                "trident.artifact.workspace.id"
            )

        return tag_dict
