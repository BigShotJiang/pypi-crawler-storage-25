# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import functools
import logging
import os
import posixpath
import re
from typing import List, Optional

from azure.core.paging import ItemPaged
from azure.storage.filedatalake import DataLakeServiceClient, PathProperties
from azure.storage.filedatalake._list_paths_helper import PathPropertiesPaged
from fabric.analytics.environment.credentials import FabricAnalyticsTokenCredentials
from mlflow.entities import FileInfo
from mlflow.exceptions import MlflowException
from mlflow.store.artifact.artifact_repo import ArtifactRepository

from .synapse_mlflow_utils import get_mlflow_env_config, record_all_public_functions

logger = logging.getLogger(__name__)


@record_all_public_functions
class TridentMLflowArtifactRepository(record_all_public_functions(ArtifactRepository)):
    def __init__(self, artifact_uri, tracking_uri: Optional[str] = None):
        super().__init__(artifact_uri=artifact_uri)

        logger.debug(f"get artifact uri: {artifact_uri}")
        # the artifact uri is like: /{workspace_id}/{artifact_id}/{artifact_path}/artifacts
        # for example, the 'Experiment' artifact uri is /{workspace_id}/{experiment_artifact_id}/{run_id}
        if artifact_uri.startswith("sds"):
            ws_id, onelake_base_path = self.parse_onelake_tridentml(artifact_uri)
        elif artifact_uri.startswith("abfss"):
            ws_id, onelake_base_path = self.parse_onelake_abfss(artifact_uri)
        else:
            ws_id, onelake_base_path = "", ""
            raise MlflowException(f"Unknown artifact uri: {artifact_uri}")

        logger.debug(
            f"artifact repo: parsed workspace id: {ws_id}, onelake_path: {onelake_base_path}"
        )

        artifact_id, artifact_path = self.parse_onelake_path(onelake_base_path)

        self.workspace_id = ws_id
        self.onelake_base_path = (
            onelake_base_path  # this is artifact_id + artifact_path
        )
        self.artifact_id = artifact_id
        self.artifact_path = artifact_path

        config = get_mlflow_env_config(False)

        self.client = DataLakeServiceClient(
            account_url=config.onelake_endpoint,
            credential=FabricAnalyticsTokenCredentials(is_ppe=config.is_ppe),
        ).get_file_system_client(self.workspace_id)
        super().__init__(artifact_uri)

    def log_artifact(self, local_file, artifact_path=None):
        logger.debug(
            f"MLflow Plugin: logging artifact from {local_file} to {artifact_path}"
        )
        if not artifact_path:
            artifact_path = ""
        artifact_path = os.path.join(self.onelake_base_path, artifact_path)
        dest_path = os.path.join(artifact_path, os.path.basename(local_file))

        file_client = self.client.get_file_client(dest_path)
        with open(local_file, "rb") as f:
            file_client.upload_data(f, overwrite=True)
        return

    def log_artifacts(self, local_dir, artifact_path=None):
        logger.debug(
            f"MLflow Plugin: logging artifacts from {local_dir} to path {artifact_path}"
        )

        if not artifact_path:
            artifact_path = ""

        artifact_path = os.path.join(self.onelake_base_path, artifact_path)

        local_dir = os.path.abspath(local_dir)

        for root, _, filenames in os.walk(local_dir):
            if root != local_dir:
                rel_path = os.path.relpath(root, local_dir)
                upload_path = os.path.join(artifact_path, rel_path)
            else:
                upload_path = artifact_path

            for f in filenames:
                remote_file_path = os.path.join(upload_path, f)
                local_file_path = os.path.join(root, f)
                file_client = self.client.get_file_client(remote_file_path)
                with open(local_file_path, "rb") as f:
                    file_client.upload_data(f, overwrite=True)
        return

    def list_artifacts(self, path=None, recursive=False) -> List[FileInfo]:
        if not path:
            path = ""
        path = path.replace("\\", "/")
        file_path = posixpath.join(self.onelake_base_path, path)
        logger.debug(f"list artifact under {file_path}")
        files: ItemPaged[PathProperties] = self.get_paths(
            path=file_path, recursive=recursive
        )
        res: List[FileInfo] = []
        for f in files:
            file_path = os.path.relpath(f.name, self.onelake_base_path)
            if file_path == path:  # needs to exclude itself(this is not a prefix match)
                continue
            res.append(
                FileInfo(
                    path=file_path,
                    file_size=f.content_length,
                    is_dir=f.is_directory,
                )
            )
        return res

    def _check_local_path(self, local_path):
        local_dir_path = os.path.dirname(local_path)
        if not os.path.exists(local_dir_path):
            os.makedirs(local_dir_path, exist_ok=True)

    def _download_file(self, remote_file_path: str, local_path: str):
        self._check_local_path(local_path)
        logger.debug(f"download from {remote_file_path} to {local_path}")
        remote_file_path = os.path.join(self.onelake_base_path, remote_file_path)
        file_client = self.client.get_file_client(remote_file_path)
        with open(local_path, "wb") as f:
            download = file_client.download_file()
            downloaded_bytes = download.readall()
            f.write(downloaded_bytes)

    def delete_artifacts(self, artifact_path=None):
        raise MlflowException("Not implemented yet")

    def get_paths(self, path=None, recursive=True, max_results=None, **kwargs):
        # this is a patched function of self.client.get_paths
        # since azure storage built-in PathPropertiesPaged has bugs receiving kwargs (PathPropertiesPaged __init__ has no kwargs)
        timeout = kwargs.pop("timeout", None)
        command = functools.partial(
            self.client._client.file_system.list_paths,
            path=path,
            timeout=timeout,
            **kwargs,
        )
        return ItemPaged(
            command,
            recursive,
            path=path,
            max_results=max_results,
            page_iterator_class=PathPropertiesPaged,
        )

    @staticmethod
    def parse_onelake_tridentml(uri):
        try:
            pattern = r"sds://[^/]+/([^/]+)/(.+)"
            match = re.match(pattern=pattern, string=uri)
            groups = match.groups()
            workspace_id = groups[0]
            onelake_path = groups[1]
        except Exception as e:
            logger.exception("MLflow Plugin: parse onelake artifact uri failed")
        return workspace_id, onelake_path

    @staticmethod
    def parse_onelake_abfss(uri):
        try:
            pattern = r"abfss://([^@]+)@[^/]+/(.+)"
            match = re.match(pattern=pattern, string=uri)
            groups = match.groups()
            workspace_id = groups[0]
            onelake_path = groups[1]
        except Exception as e:
            logger.exception("MLflow Plugin: parse onelake artifact uri failed")
        return workspace_id, onelake_path

    @staticmethod
    def parse_onelake_path(onelake_path):
        try:
            match = re.match(r"([^/]+)/(.+)", onelake_path)
            groups = match.groups()
            artifact_id = groups[0]
            artifact_path = groups[1]
        except Exception as e:
            logger.exception("MLflow Plugin: parse onelake path failed")
        return artifact_id, artifact_path
