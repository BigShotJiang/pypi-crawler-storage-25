"""Plugin system for AIGuard."""
