# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class ListOperationActivityRequest(DaraModel):
    def __init__(
        self,
        instance_id: str = None,
        operation_id: str = None,
    ):
        # This parameter is required.
        self.instance_id = instance_id
        self.operation_id = operation_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.instance_id is not None:
            result['InstanceId'] = self.instance_id

        if self.operation_id is not None:
            result['OperationId'] = self.operation_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('InstanceId') is not None:
            self.instance_id = m.get('InstanceId')

        if m.get('OperationId') is not None:
            self.operation_id = m.get('OperationId')

        return self

