"""RTMDK MCP package."""
