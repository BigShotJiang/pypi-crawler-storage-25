"""RTMDK MCP package."""
