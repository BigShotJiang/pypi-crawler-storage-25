import inspect
import pygame as pg
import pygame._sdl2
from types import SimpleNamespace
import os
import sys
import traceback
from datetime import datetime
import platform
import math
import time
import miniaudio
import ctypes
pg.init()
pg.display.init()

VERSION = "1.2.5"

class Build:
    MGL = SimpleNamespace()
    sell = SimpleNamespace()
    fell = SimpleNamespace()
    fell.Data = fell.data = SimpleNamespace()
    sell.data_Texture = {}
    sell.data_Music = {}
    sell.Cache = {}
    sell.Events = {}
    sell.data_update = {}

    def __init__(self, name="My Game", screen_size=(800, 600), resize=True, ot_pos=True, SafeMode=True, logs=True, DeveLoperMode=True, vsync=True, FULLSCREEN=False, size_window_standart=(800, 600)):
        global VERSION
        print("Telegram: https://t.me/Teme20xx")
        if logs: print(f"\033[90mInitializing Engine {VERSION}\033[0m")
        if getattr(sys, 'frozen', False): self.sell.PATH = sys._MEIPASS
        else: self.sell.PATH = os.path.dirname(os.path.abspath(__file__))
        self.sell.PATH = "/".join(os.path.dirname(self.sell.PATH.rstrip(os.sep)).split("/")[:-3])

        pg.display.gl_set_attribute(pg.GL_MULTISAMPLEBUFFERS, 1)
        pg.display.gl_set_attribute(pg.GL_MULTISAMPLESAMPLES, 4)
        
        screen_size, size_window_standart = size_window_standart, screen_size
        left, up = screen_size

        self.sell.General_size = (1, 1)

        self.sell.screen = pg._sdl2.video.Window(name, size=size_window_standart, resizable=resize, opengl=1, fullscreen=FULLSCREEN)
        self.sell.name = name
        self.sell.resize = resize
        #self.sell.screen.set_fullscreen(FULLSCREEN)
        self.sell.FULLSCREEN = FULLSCREEN
        self.sell.left, self.sell.up = left, up
        self.sell.render = pg._sdl2.video.Renderer(self.sell.screen, index=-1, accelerated=1, vsync=vsync)
        self.sell.render_texture = pg._sdl2.video.Texture(self.sell.render, size=size_window_standart, target=1)
        self.sell.war = True
        self.sell.ot_pos = ot_pos
        def Event_List_def(events):
            res = {
                "quit": False,
                "mouse down left": False,
                "mouse down right": False,
                "mouse down center": False,
                "mouse up left": False,
                "mouse up right": False,
                "mouse up center": False,
                "touch down": False,
                "touch up": False,
                "scroll +": False,
                "scroll -": False,
                "mouse down additional 1": False,
                "mouse down additional 2": False,
                "mouse up additional 1": False,
                "mouse up additional 2": False
            }
            
            for ev in events:
                if ev.type == pg.QUIT: res["quit"] = True
                elif ev.type == pg.MOUSEBUTTONDOWN:
                    if ev.button == pg.BUTTON_LEFT: res["mouse down left"] = True
                    elif ev.button == pg.BUTTON_RIGHT: res["mouse down right"] = True
                    elif ev.button == pg.BUTTON_MIDDLE: res["mouse down center"] = True
                    elif ev.button == pg.BUTTON_X1: res["mouse down additional 1"] = True
                    elif ev.button == pg.BUTTON_X2: res["mouse down additional 2"] = True
                elif ev.type == pg.MOUSEBUTTONUP:
                    if ev.button == pg.BUTTON_LEFT: res["mouse up left"] = True
                    elif ev.button == pg.BUTTON_RIGHT: res["mouse up right"] = True
                    elif ev.button == pg.BUTTON_MIDDLE: res["mouse up center"] = True
                    elif ev.button == pg.BUTTON_X1: res["mouse up additional 1"] = True
                    elif ev.button == pg.BUTTON_X2: res["mouse up additional 2"] = True
                elif ev.type == pg.FINGERDOWN: res["touch down"] = True
                elif ev.type == pg.FINGERUP: res["touch up"] = True
                elif ev.type == pg.MOUSEWHEEL:
                    if ev.y < 0: res["scroll +"] = True
                    elif ev.y > 0: res["scroll -"] = True
                    
            return res
        self.sell.Event_List_def = Event_List_def
        self.sell.Scene = {}
        self.sell.falt = None
        self.sell.vsync = vsync
        self.sell.SafeMode = SafeMode
        self.sell.logs = logs
        self.sell.Clock = pg.time.Clock()
        self.sell.FPS = 0
        self.sell.PressedButton = None
        self.sell.DeltaTimeHow = None
        self.sell.DeveLoperMode = DeveLoperMode
        self.sell.DeveLoperMode_font = pg.font.SysFont(None, 45)
        self.sell.DeveLoperMode_text = f"DeveLoperMode: fps: {0} | ... "
        self.sell.DeveLoperMode_render = self.sell.DeveLoperMode_font.render(self.sell.DeveLoperMode_text, True, (255, 255, 255))
        self.sell.DeveLoperMode_Texture = pg._sdl2.Texture.from_surface(self.sell.render, self.sell.DeveLoperMode_render)
        self.sell.touch = {}
        self.sell.size_window_standart = size_window_standart
        self.sell.TextureScreen = pg._sdl2.video.Texture(self.sell.render, size=(left, up), target=1)
        self.sell.TextureScreen_angle = 0.
        self.sell.PyGame = pg
        self.sell.SDL2 = pg._sdl2
        self.sell.SDL2_video = pg._sdl2.video
        pg.key.set_repeat(500, 50)
        if logs: print("\033[92mcompleted successfully\033[0m")

        if logs: print("\033[90mInitializing Functions\033[0m")
        def NewCanvas(color=None):
            if not color is None: self.sell.render.draw_color = color
            self.sell.render.clear()
        self.fell.NewCanvas = NewCanvas
        
        def End(): self.sell.war = False
        self.fell.End = End
        
        def Draw():
            if self.sell.DeveLoperMode:
                if not self.sell.DeveLoperMode_text == f"DeveLoperMode: fps: {Build.fell.GetFPS()} | ... ":
                    self.sell.DeveLoperMode_text = f"DeveLoperMode: fps: {Build.fell.GetFPS()} | ... "
                    self.sell.DeveLoperMode_render = self.sell.DeveLoperMode_font.render(self.sell.DeveLoperMode_text, True, (255, 255, 255))
                    self.sell.DeveLoperMode_Texture = pg._sdl2.Texture.from_surface(
                        self.sell.render, self.sell.DeveLoperMode_font.render(self.sell.DeveLoperMode_text, True, (255, 255, 255)))
                self.sell.DeveLoperMode_Texture.draw(None, pg.Rect(0, 0, self.sell.DeveLoperMode_render.get_width(), self.sell.DeveLoperMode_render.get_height()))

            self.sell.render.target = None
            self.sell.render.draw_color = (0, 0, 0, 255)
            self.sell.render.clear()
            _cw, _ch = self.sell.screen.size
            _scale = min(_cw / self.sell.left, _ch / self.sell.up)
            _sw, _sh = self.sell.left * _scale, self.sell.up * _scale
            self.sell.TextureScreen.draw(None, pg.Rect(
                ((_cw - _sw) / 2, (_ch - _sh) / 2),
                (_sw, _sh)),
                self.sell.TextureScreen_angle, (_sw / 2, _sh / 2))
            self.sell.General_size = (_sw, _sh)
            pg._sdl2.video.Renderer.present(self.sell.render)
            self.sell.render.target = self.sell.TextureScreen
        self.fell.Draw = Draw

        def File(path): return os.path.join(Build.sell.PATH, path)
        self.fell.File = File
        
        def LoadedTexture(path):
            if path in Build.sell.Cache: return Build.sell.Cache[path]
            else:
                surf = pg.image.load(File(path))
                tex = pg._sdl2.video.Texture.from_surface(Build.sell.render, surf)
                Build.sell.Cache[path] = tex
                return tex
        self.fell.LoadedTexture = LoadedTexture

        class Texture:
            def __init__(self, name, file, x=100, y=100, w=100, h=100, angle=0, static=False, center=False):
                if ot_pos: x, y, w, h = left*x, up*y, left*w, up*h
                self.name = name
                self.alpha = 255
                self.center = center
                self.scripts = []
                self.type = "Texture"
                if logs:
                    if ot_pos:
                        print(f"\033[90mCreate {self.type} with parameters:\n- name:",\
                            f" {name};\n- file: {file};\n- position: {x, y};\n- size: {w, h};\n- angle: {angle};\n- static: {static};\033[0m")
                    else:
                        print(f"\033[90mCreate {self.type} with parameters:\n- name:",\
                            f" {name};\n- file: {file};\n- position: {x, y};\n- size: {w, h};\n- angle: {angle};\n- static: {static};\033[0m")
                self.static = static
                if file in Build.sell.Cache: tex = Build.sell.Cache[file]
                else:
                    surf = pg.image.load(File(file))
                    if surf.get_size() != (w, h): surf = pg.transform.scale(surf, (w, h))
                    tex = pg._sdl2.video.Texture.from_surface(Build.sell.render, surf)
                    Build.sell.Cache[file] = tex
                    del surf
                self.file = file
                self.texture = tex
                self.angle = angle
                self.pos = [x, y]
                self.size = [w, h]
                Build.sell.data_Texture[name] = {"tex": self}
                print(f"\033[92mCreate {self.type} completed successfully\033[0m")
            def ExecuteOnceScript(self, script): script.run(self)
            def ExecuteOnceCode(self, code): code(self)
            def AddScript(self, script):
                self.scripts.append(script(self))
                if logs: print(f"\033[90mAdd script {script} to {self.type} completed successfully\033[0m")
            def TextureUpdate(self):
                for script in self.scripts: script.run(self)
            def RemoveScript(self, script): self.scripts.remove(script)
            def GetScripts(self): return self.scripts

            def set_alpha(self, alpha): self.alpha = alpha
            def get_alpha(self): return self.alpha

            def get_size(self):
                if ot_pos: return [self.size[0] / left, self.size[1] / up]
                return self.size
            def set_size(self, w, h):
                if ot_pos: w, h = left*w, up*h
                self.size = [w, h]

            def get_type(self): return self.type

            def get_static(self): return self.static
            def set_static(self, static): self.static = static

            def get_angle(self): return self.angle
            def set_angle(self, angle): self.angle = angle

            def get_pos(self):
                if ot_pos: return [self.pos[0] / left, self.pos[1] / up] if self.static else [(self.pos[0] + Build.fell.Camera.pos[0]) / left, (self.pos[1] + Build.fell.Camera.pos[1]) / up]
                return self.pos if self.static else [self.pos[0] + Build.fell.Camera.pos[0], self.pos[1] + Build.fell.Camera.pos[1]]
            def set_pos(self, x, y):
                if ot_pos: x, y = left*x, up*y
                self.pos = [x, y]

            def get_texture(self): return self.texture

            def Move(self, x, y):
                if ot_pos: x, y = left*x, up*y
                self.pos[0] += x; self.pos[1] += y
            def MoveY(self, y):
                if ot_pos: y = up*y
                self.pos[1] += y
            def MoveX(self, x):
                if ot_pos: x = left*x
                self.pos[0] += x

            def AngleAdd(self, angle): self.angle += angle
            def AngleSub(self, angle): self.angle -= angle

            def get_name(self): return self.name

            def MoveMent(self, keys, speed):
                keys = keys.split(".")
                if ot_pos:
                    if Build.fell.ButtonPressed(keys[0]): self.MoveY(up*-speed)
                    if Build.fell.ButtonPressed(keys[1]): self.MoveX(left*-speed)
                    if Build.fell.ButtonPressed(keys[2]): self.MoveY(up*speed)
                    if Build.fell.ButtonPressed(keys[3]): self.MoveX(left*speed)
                else:
                    if Build.fell.ButtonPressed(keys[0]): self.MoveY(-speed)
                    if Build.fell.ButtonPressed(keys[1]): self.MoveX(-speed)
                    if Build.fell.ButtonPressed(keys[2]): self.MoveY(speed)
                    if Build.fell.ButtonPressed(keys[3]): self.MoveX(speed)

            def TextureDraw(self):
                    if (self.static and 0 < self.pos[0] + self.size[0] and self.pos[0] < Build.sell.left and \
                        0 < self.pos[1] + self.size[1] and self.pos[1] < Build.sell.up) or \
                            (not self.static and -Build.fell.Camera.pos[0] < self.pos[0] + self.size[0] and self.pos[0] < -Build.fell.Camera.pos[0] + Build.sell.left and \
                                -Build.fell.Camera.pos[1] < self.pos[1] + self.size[1] and self.pos[1] < -Build.fell.Camera.pos[1] + Build.sell.up):
                        try:
                            self.texture.alpha = self.alpha
                            self.texture.draw(None, pg.Rect((self.pos[0] - self.size[0] / 2, self.pos[1] - self.size[1] / 2) if self.center else self.pos, self.size),
                                              float(self.angle), (self.size[0] / 2., self.size[1] / 2.))
                        except Exception as f: print(f"\033[31mFATAL ERROR: {f}\033[0m")
        self.fell.Texture = Texture

        def DrawSquare(color=None, x=100, y=100, w=100, h=100, static=False):
            if ot_pos: x, y, w, h = left*x, up*y, left*w, up*h
            if not color is None: self.sell.render.draw_color = color
            if static: self.sell.render.fill_rect(pg.Rect(x, y, w, h))
            else: self.sell.render.fill_rect(pg.Rect(x - Build.fell.Camera.pos[0], y - Build.fell.Camera.pos[1], w, h))
        self.fell.DrawSquare = DrawSquare

        class Square:
            def __init__(self, name, color=None, x=100, y=100, w=100, h=100, angle=0, static=False, center=False):
                if ot_pos: x, y, w, h = left*x, up*y, left*w, up*h
                self.alpha = 255
                self.center = center
                self.name = name
                self.scripts = []
                self.type = "Square"
                if logs: print(f"\033[90mCreate {self.type} with parameters:\n- name:",\
                    f" {name};\n- position: {x, y};\n- size: {w, h};\n- angle: {angle};\n- static: {static};\033[0m")
                self.static = static
                surf = pg.Surface((w, h))
                surf.fill(color if color is not None else Build.sell.render.draw_color)
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, surf)
                self.texture.blend_mode = 1
                del surf
                self.angle = angle
                self.pos = [x, y]
                self.size = [w, h]
                self.color = name if not color is not None else color
                Build.sell.data_Texture[name] = {"tex": self}
                print(f"\033[92mCreate {self.type} completed successfully\033[0m")
            def ExecuteOnceScript(self, script): script.run(self)
            def ExecuteOnceCode(self, code): code(self)
            def AddScript(self, script):
                self.scripts.append(script(self))
                if logs: print(f"\033[90mAdd script {script} to {self.type} completed successfully\033[0m")
            def SquareUpdate(self):
                for script in self.scripts: script.run(self)
            def RemoveScript(self, script): self.scripts.remove(script)
            def GetScripts(self): return self.scripts

            def set_alpha(self, alpha): self.alpha = alpha
            def get_alpha(self): return self.alpha

            def get_color(self): return self.color
            def set_color(self, color):
                self.color = color
                surf = pg.Surface(self.size)
                surf.fill(color if color is not None else Build.sell.render.draw_color)
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, surf)
                del surf

            def get_size(self):
                if ot_pos: return [self.size[0] / left, self.size[1] / up]
                return self.size
            def set_size(self, w, h):
                if ot_pos: w, h = left*w, up*h
                self.size = [w, h]

            def get_type(self): return self.type

            def get_static(self): return self.static
            def set_static(self, static): self.static = static

            def get_angle(self): return self.angle
            def set_angle(self, angle): self.angle = angle

            def get_pos(self):
                if ot_pos: return [self.pos[0] / left, self.pos[1] / up] if self.static else [(self.pos[0] + Build.fell.Camera.pos[0]) / left, (self.pos[1] + Build.fell.Camera.pos[1]) / up]
                return self.pos if self.static else [self.pos[0] + Build.fell.Camera.pos[0], self.pos[1] + Build.fell.Camera.pos[1]]
            def set_pos(self, x, y): 
                if ot_pos: x, y = left*x, up*y
                self.pos = [x, y]

            def get_texture(self): return self.texture

            def Move(self, x, y):
                if ot_pos: x, y = left*x, up*y
                self.pos[0] += x; self.pos[1] += y
            def MoveY(self, y):
                if ot_pos: y = up*y
                self.pos[1] += y
            def MoveX(self, x):
                if ot_pos: x = left*x
                self.pos[0] += x

            def AngleAdd(self, angle): self.angle += angle
            def AngleSub(self, angle): self.angle -= angle

            def get_center(self): return self.center
            def set_center(self, center): self.center = center

            def get_name(self): return self.name

            def MoveMent(self, keys, speed):
                keys = keys.split(".")
                if ot_pos:
                    if Build.fell.ButtonPressed(keys[0]): self.MoveY(up*-speed)
                    if Build.fell.ButtonPressed(keys[1]): self.MoveX(left*-speed)
                    if Build.fell.ButtonPressed(keys[2]): self.MoveY(up*speed)
                    if Build.fell.ButtonPressed(keys[3]): self.MoveX(left*speed)
                else:
                    if Build.fell.ButtonPressed(keys[0]): self.MoveY(-speed)
                    if Build.fell.ButtonPressed(keys[1]): self.MoveX(-speed)
                    if Build.fell.ButtonPressed(keys[2]): self.MoveY(speed)
                    if Build.fell.ButtonPressed(keys[3]): self.MoveX(speed)

            def SquareDraw(self):
                if self.center: old_pos = self.pos.copy(); self.pos[0] -= self.size[0] / 2; self.pos[1] -= self.size[1] / 2
                if self.pos[0] + self.size[0] > -Build.fell.Camera.pos[0] and self.pos[0] < -Build.fell.Camera.pos[0] + Build.sell.left and \
                    self.pos[1] + self.size[1] > -Build.fell.Camera.pos[1] and self.pos[1] < -Build.fell.Camera.pos[1] + Build.sell.up:
                        try:
                            self.texture.alpha = self.alpha
                            self.texture.draw(None, pg.Rect(
                                (self.pos[0] + Build.fell.Camera.pos[0], self.pos[1] + Build.fell.Camera.pos[1]), self.size)\
                                if not self.static else pg.Rect((self.pos[0], self.pos[1]), self.size),
                                float(self.angle), (self.size[0] / 2., self.size[1] / 2.))
                        except Exception as f: print(f"\033[31mFATAL ERROR: {f}\033[0m")
                if self.center: self.pos = old_pos.copy()
        self.fell.Square = Square

        class Text:
            def __init__(self, name, text, x, y, size, angle, color, static=False, center=True, font=None):
                if ot_pos: x, y, size = left*x, up*y, up*size
                if text == "": text = " "
                self.alpha = 255
                self.name = name
                self.angle = angle
                self.text = text
                self.pos = [x, y]
                self.size = size
                self.color = color
                self.scripts = []
                self.render = pg.font.SysFont(None if font is None else font, int(size)).render(text, True, color)
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.render)
                self.type = "Text"
                if logs: print(f"\033[90mCreate {self.type} with parameters:\n- name:",\
                    f" {name};\n- text: {text};\n- position: {x, y};\n- size: {size};\n- color: {color};\n- static: {static};\n- center: {center};\033[0m")
                self.static = static
                self.center = center
                Build.sell.data_Texture[name] = {"tex": self}
                self.size_Rect = [*self.render.get_size()]
                if logs: print(f"\033[92mCreate {self.type} completed successfully\033[0m")
            def ExecuteOnceScript(self, script): script.run(self)
            def ExecuteOnceCode(self, code): code(self)
            def AddScript(self, script):
                self.scripts.append(script(self))
                if logs: print(f"\033[90mAdd script {script} to {self.type} completed successfully\033[0m")
            def TextUpdate(self):
                for script in self.scripts: script.run(self)
            def RemoveScript(self, script): self.scripts.remove(script)
            def GetScripts(self): return self.scripts

            def set_alpha(self, alpha): self.alpha = alpha
            def get_alpha(self): return self.alpha

            def get_color(self): return self.color
            def set_color(self, color):
                self.color = color
                self.render = pg.font.SysFont(None, int(self.size)).render(self.text, True, self.color)
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.render)

            def get_size(self):
                if ot_pos: return [self.size[0] / left, self.size[1] / up]
                return self.size
            def set_size(self, size):
                self.size = size
                self.font = pg.SysFont(None, size)
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.font.render(self.text, True, self.color))

            def get_type(self): return self.type
            def get_static(self): return self.static

            def get_pos(self):
                if ot_pos: return [self.pos[0] / left, self.pos[1] / up] if self.static else [(self.pos[0] + Build.fell.Camera.pos[0]) / left, (self.pos[1] + Build.fell.Camera.pos[1]) / up]
                return self.pos if self.static else [self.pos[0] + Build.fell.Camera.pos[0], self.pos[1] + Build.fell.Camera.pos[1]]
            def set_pos(self, x, y): 
                if ot_pos: x, y = left*x, up*y
                self.pos = [x, y]

            def set_angle(self, angle): self.angle = angle
            def get_angle(self): return self.angle

            def get_texture(self): return self.texture

            def get_text(self): return self.text
            def set_text(self, text):
                self.text = text
                self.render = pg.font.SysFont(None, int(self.size)).render(text, True, self.color)
                self.size_Rect = self.render.get_size()
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.render)
            
            def Move(self, x, y):
                if ot_pos: x, y = left*x, up*y
                self.pos[0] += x; self.pos[1] += y
            def MoveY(self, y):
                if ot_pos: y = up*y
                self.pos[1] += y
            def MoveX(self, x):
                if ot_pos: x = left*x
                self.pos[0] += x
            
            def AngleAdd(self, angle): self.angle += angle
            def AngleSub(self, angle): self.angle -= angle

            def get_center(self): return self.center
            def set_center(self, center): self.center = center

            def get_name(self): return self.name
            
            def MoveMent(self, keys, speed):
                keys = keys.split(".")
                if ot_pos:
                    if Build.fell.ButtonPressed(keys[0]): self.MoveY(up*-speed)
                    if Build.fell.ButtonPressed(keys[1]): self.MoveX(left*-speed)
                    if Build.fell.ButtonPressed(keys[2]): self.MoveY(up*speed)
                    if Build.fell.ButtonPressed(keys[3]): self.MoveX(left*speed)
                else:
                    if Build.fell.ButtonPressed(keys[0]): self.MoveY(-speed)
                    if Build.fell.ButtonPressed(keys[1]): self.MoveX(-speed)
                    if Build.fell.ButtonPressed(keys[2]): self.MoveY(speed)
                    if Build.fell.ButtonPressed(keys[3]): self.MoveX(speed)

            def TextDraw(self):
                if self.center:
                    if (self.static and 0 < self.pos[0] + self.size_Rect[0] / 2 and self.pos[0] < Build.sell.left + self.size_Rect[0] / 2 and \
                        0 < self.pos[1] + self.size_Rect[1] / 2 and self.pos[1] < Build.sell.up + self.size_Rect[1] / 2) or \
                           (not self.static and -Build.fell.Camera.pos[0] < self.pos[0] + self.size_Rect[0] / 2 and self.pos[0] < -Build.fell.Camera.pos[0] + Build.sell.left + self.size_Rect[0] / 2 and \
                                -Build.fell.Camera.pos[1] < self.pos[1] + self.size_Rect[1] / 2 and self.pos[1] < -Build.fell.Camera.pos[1] + Build.sell.up + self.size_Rect[1] / 2):
                            try:
                                self.texture.alpha = self.alpha
                                self.texture.draw(None, pg.Rect(
                                    (self.pos[0] + Build.fell.Camera.pos[0] - self.size_Rect[0] / 2, self.pos[1] + Build.fell.Camera.pos[1] - self.size_Rect[1] / 2), self.size_Rect)\
                                    if not self.static else pg.Rect((self.pos[0] - self.size_Rect[0] / 2, self.pos[1] - self.size_Rect[1] / 2), self.size_Rect),
                                    float(self.angle), (self.size_Rect[0] / 2., self.size_Rect[1] / 2.))
                            except Exception as f: print(f"\033[31mFATAL ERROR: {f}\033[0m")
                else:
                    if (self.static and 0 < self.pos[0] + self.size_Rect[0] and self.pos[0] < Build.sell.left and \
                        0 < self.pos[1] + self.size_Rect[1] and self.pos[1] < Build.sell.up) or \
                            (not self.static and -Build.fell.Camera.pos[0] < self.pos[0] + self.size_Rect[0] and self.pos[0] < -Build.fell.Camera.pos[0] + Build.sell.left and \
                                -Build.fell.Camera.pos[1] < self.pos[1] + self.size_Rect[1] and self.pos[1] < -Build.fell.Camera.pos[1] + Build.sell.up):
                            try:
                                self.texture.alpha = self.alpha
                                self.texture.draw(None, pg.Rect(
                                    (self.pos[0] + Build.fell.Camera.pos[0], self.pos[1] + Build.fell.Camera.pos[1]), self.size_Rect)\
                                    if not self.static else pg.Rect(self.pos, self.size_Rect),
                                    float(self.angle))
                            except Exception as f: print(f"\033[31mFATAL ERROR: {f}\033[0m")
        self.fell.Text = Text

        class Button:
            def __init__(self, name, text, x, y, size, angle, color, func, mouse="mouse down left", static=False, center=True):
                self.type = "Button"
                if ot_pos: x, y, size = left*x, up*y, up*size
                self.name = name
                self.angle = angle
                self.center = center
                self.mouse = mouse
                self.func = func
                self.name = name
                self.text = text
                self.x = x
                self.y = y
                self.pos = [x, y]
                self.size = size
                self.color = color
                self.font = pg.font.SysFont(None, int(size))
                self.render = self.font.render(text, True, color)
                texture_noText = pg.Surface((x, y), pg.SRCALPHA)
                texture_noText.fill((255, 255, 255, 255))
                self.texture_noText = pg._sdl2.video.Texture.from_surface(Build.sell.render, texture_noText)
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.render)
                self.type = "Button"
                if logs: print(f"\033[90mCreate {self.type} with parameters:\n- name:",\
                    f" {name};\n- text: {text};\n- position: {x, y};\n- size: {size};\n- color: {color};\n- static: {static};\033[0m")
                self.static = static
                self.size_Rect = [*self.render.get_size()]
                Build.sell.Events[name] = self
                Build.sell.data_Texture[name] = {"tex": self}
                if logs: print(f"\033[92mCreate {self.type} completed successfully\033[0m")
            def ExecuteOnceScript(self, script): script.run(self)
            def ExecuteOnceCode(self, code): code(self)
            def AddScript(self, script):
                self.scripts.append(script(self))
                if logs: print(f"\033[90mAdd script {script} to {self.type} completed successfully\033[0m")
            def TextUpdate(self):
                for script in self.scripts: script.run(self)
            def RemoveScript(self, script): self.scripts.remove(script)
            def GetScripts(self): return self.scripts
            def GetFunc(self): return self.func

            def get_type(self): return self.type
            def get_name(self): return self.name
            def get_texture(self): return self.texture
            
            def get_text(self): return self.text
            
            def get_color(self): return self.color
            def set_color(self, color):
                self.color = color
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.font.render(self.text, True, color))

            def get_size(self):
                if ot_pos: return [self.size[0] / left, self.size[1] / up]
                return self.size
            def set_size(self, size):
                self.size = size
                self.font = pg.SysFont(None, size)
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.font.render(self.text, True, self.color))
            
            def get_pos(self):
                if ot_pos: return [self.pos[0] / left, self.pos[1] / up] if self.static else [(self.pos[0] + Build.fell.Camera.pos[0]) / left, (self.pos[1] + Build.fell.Camera.pos[1]) / up]
                return self.pos if self.static else [self.pos[0] + Build.fell.Camera.pos[0], self.pos[1] + Build.fell.Camera.pos[1]]
            def set_pos(self, x, y): 
                if ot_pos: x, y = left*x, up*y
                self.pos = [x, y]
            
            def get_text(self): return self.text
            def set_text(self, text):
                self.text = text
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.font.render(text, True, self.color))

            def get_static(self): return self.static
            def set_static(self, static): self.static = static
            
            def get_func(self): return self.func
            def set_func(self, func): self.func = func
            
            def Move(self, x, y):
                if ot_pos: x, y = left*x, up*y
                self.pos[0] += x; self.pos[1] += y
            def MoveY(self, y):
                if ot_pos: y = up*y
                self.pos[1] += y
            def MoveX(self, x):
                if ot_pos: x = left*x
                self.pos[0] += x

            def get_angle(self): return self.angle
            def set_angle(self, angle): self.angle = angle

            def get_center(self): return self.center
            def set_center(self, center): self.center = center

            def AngleAdd(self, angle): self.angle += angle
            def AngleSub(self, angle): self.angle -= angle

            def is_hovered(self):
                m_pos = pg.mouse.get_pos()
                if self.center: rect = pg.Rect(self.pos[0] - self.size_Rect[0]/2, self.pos[1] - self.size_Rect[1]/2, *self.size_Rect)
                else: rect = pg.Rect(*self.pos, *self.size_Rect)
                return rect.collidepoint( \
                    (m_pos[0] - (Build.sell.size_window_standart[0] - Build.sell.General_size[0]) / 2) / (Build.sell.General_size[0] / Build.sell.left), \
                    (m_pos[1] - (Build.sell.size_window_standart[1] - Build.sell.General_size[1]) / 2) / (Build.sell.General_size[1] / Build.sell.up) \
                )
            
            def MoveMent(self, keys, speed):
                keys = keys.split(".")
                if ot_pos:
                    if Build.fell.ButtonPressed(keys[0]): self.MoveY(up*-speed)
                    if Build.fell.ButtonPressed(keys[1]): self.MoveX(left*-speed)
                    if Build.fell.ButtonPressed(keys[2]): self.MoveY(up*speed)
                    if Build.fell.ButtonPressed(keys[3]): self.MoveX(left*speed)
                else:
                    if Build.fell.ButtonPressed(keys[0]): self.MoveY(-speed)
                    if Build.fell.ButtonPressed(keys[1]): self.MoveX(-speed)
                    if Build.fell.ButtonPressed(keys[2]): self.MoveY(speed)
                    if Build.fell.ButtonPressed(keys[3]): self.MoveX(speed)

            def ButtonDraw(self):
                s = Build.sell
                m_pos = pg.mouse.get_pos()
                
                sc = s.General_size[0] / s.left
                mx = (m_pos[0] - (s.size_window_standart[0] - s.General_size[0]) / 2) / sc
                my = (m_pos[1] - (s.size_window_standart[1] - s.General_size[1]) / 2) / sc

                if self.center:
                    if mx > self.pos[0] - self.size_Rect[0] / 2 - 10 and mx < self.pos[0] + self.size_Rect[0] / 2 + 10 and \
                        my > self.pos[1] - self.size_Rect[1] / 2 - 10 and my < self.pos[1] + self.size_Rect[1] / 2 + 10:
                            self.texture_noText.color = (100, 100, 100)
                    else: self.texture_noText.color = (0, 0, 0)

                    if self.pos[0] + self.size_Rect[0] > -Build.fell.Camera.pos[0] and self.pos[0] < -Build.fell.Camera.pos[0] + s.left and \
                        self.pos[1] + self.size_Rect[1] > -Build.fell.Camera.pos[1] and self.pos[1] < -Build.fell.Camera.pos[1] + s.up:
                            try:
                                self.texture_noText.draw(None, pg.Rect( \
                                    (self.pos[0] + Build.fell.Camera.pos[0] - self.size_Rect[0] / 2 - 10, self.pos[1] + Build.fell.Camera.pos[1] - self.size_Rect[1] / 2 - 10), (self.size_Rect[0] + 20, self.size_Rect[1] + 20)) \
                                    if not self.static else pg.Rect((self.pos[0] - 10 - self.size_Rect[0] / 2, self.pos[1] - 10 - self.size_Rect[1] / 2), (self.size_Rect[0] + 20, self.size_Rect[1] + 20)), \
                                    float(self.angle), (self.size_Rect[0] / 2., self.size_Rect[1] / 2.))
                                self.texture.draw(None, pg.Rect( \
                                    (self.pos[0] + Build.fell.Camera.pos[0] - self.size_Rect[0] / 2, self.pos[1] + Build.fell.Camera.pos[1] - self.size_Rect[1] / 2), self.size_Rect) \
                                    if not self.static else pg.Rect((self.pos[0] - self.size_Rect[0] / 2, self.pos[1] - self.size_Rect[1] / 2), self.size_Rect), \
                                    float(self.angle), (self.size_Rect[0] / 2., self.size_Rect[1] / 2.))
                            except Exception as f: print(f"\033[31mFATAL ERROR: {f}\033[0m")
                else:
                    if mx > self.pos[0] and mx < self.pos[0] + self.size_Rect[0] and \
                        my > self.pos[1] and my < self.pos[1] + self.size_Rect[1]:
                            self.texture_noText.color = (100, 100, 100)
                    else: self.texture_noText.color = (0, 0, 0)
                    
                    if self.pos[0] + self.size_Rect[0] > -Build.fell.Camera.pos[0] and self.pos[0] < -Build.fell.Camera.pos[0] + s.left and \
                        self.pos[1] + self.size_Rect[1] > -Build.fell.Camera.pos[1] and self.pos[1] < -Build.fell.Camera.pos[1] + s.up:
                            try:
                                self.texture_noText.draw(None, pg.Rect( \
                                    (self.pos[0] + Build.fell.Camera.pos[0] - 10, self.pos[1] + Build.fell.Camera.pos[1] - 10), (self.size_Rect[0] + 20, self.size_Rect[1] + 20)) \
                                    if not self.static else pg.Rect((self.pos[0] - 10, self.pos[1] - 10), (self.size_Rect[0] + 20, self.size_Rect[1] + 20)), \
                                    float(self.angle))
                                self.texture.draw(None, pg.Rect( \
                                    (self.pos[0] + Build.fell.Camera.pos[0], self.pos[1] + Build.fell.Camera.pos[1]), self.size_Rect) \
                                    if not self.static else pg.Rect(self.pos, self.size_Rect), \
                                    float(self.angle))
                            except Exception as f: print(f"\033[31mFATAL ERROR: {f}\033[0m")
        self.fell.Button = Button

        class Input_Field:
            def __init__(self, name, default_text, x, y, w, h, angle, static=False, center=False):
                if ot_pos: x, y, w, h = left*x, up*y, left*w, up*h
                self.name = name
                self.type = "Input_Field"
                self.default_text = default_text
                self.text = ""
                self.Focus = False
                self.angle = angle
                self.x = x
                self.y = y
                self.w = w
                self.h = h
                self.time = 0
                self.static = static
                self.center = center
                self.pos = [x, y]
                self.size = [w, h]
                self.font = pg.font.SysFont(None, int(h))
                self.render_text_pg = pg.font.SysFont(None, int(h)).render(default_text, True, (0, 0, 0))
                self.render_text_pg.fill((255, 255, 255))
                self.render_size = self.render_text_pg.get_size()
                self.render = pg._sdl2.video.Texture.from_surface(Build.sell.render, pg.Surface((w, h), pg.SRCALPHA))
                texture = pg.Surface((left * 0.01, self.render_text_pg.get_size()[1]))
                self.render_text_pg = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.render_text_pg)
                texture.fill((255, 255, 255, 255))
                self.texture = pg._sdl2.video.Texture.from_surface(Build.sell.render, texture); self.texture_size = texture.get_size()
                Fon = pg.Surface((w, h), pg.SRCALPHA)
                Fon.fill((0, 0, 0, 255))
                self.Fon = pg._sdl2.video.Texture.from_surface(Build.sell.render, Fon)
                Build.sell.data_Texture[name] = {"tex": self}
                if logs:
                    print(f"\033[90mCreate {self.type} with name:"\
                        f" {name};\n- default text: {default_text};\n- position: {x, y};\n- size: {w, h};\n- angle: {angle};\n- static: {static};\n- center: {center};\033[0m")
                    print(f"\033[92mCreate {self.type} completed successfully\033[0m")
                self._update_texture()
            
            def Input_FieldDraw(self):
                if self.Focus: self.time += 4
                if self.center:
                    if self.pos[0] - self.w / 2 + self.render_size[0] > -Build.fell.Camera.pos[0] and self.pos[0] - self.w / 2 < -Build.fell.Camera.pos[0] + Build.sell.left and \
                        self.pos[1] - self.h / 2 + self.render_size[1] > -Build.fell.Camera.pos[1] and self.pos[1] - self.h / 2 < -Build.fell.Camera.pos[1] + Build.sell.up:

                        self.Fon.draw(None, pg.Rect(self.x + Build.fell.Camera.pos[0] - self.w / 2, self.y + Build.fell.Camera.pos[1] - self.y / 2, self.w, self.h) if\
                            not self.static else pg.Rect(self.x - self.w / 2, self.y - self.h / 2, self.w, self.h), float(self.angle), (self.w / 2., self.h / 2.))
                        
                        self.render.draw(None, pg.Rect(self.x + Build.fell.Camera.pos[0] - self.w / 2, self.y + Build.fell.Camera.pos[1] + 10 - self.h / 2, *self.render_size) if\
                            not self.static else pg.Rect(self.x - self.w / 2, self.y + 10 - self.h / 2, *self.render_size), float(self.angle), (self.w / 2., self.h / 2.))
                        
                        if (self.time // 100) % 2 == 1 and self.Focus:
                            if self.text == "":
                                self.texture.draw(None, pg.Rect(self.x + Build.fell.Camera.pos[0] - self.w / 2, self.y + Build.fell.Camera.pos[1] + 7.5 - self.h / 2, *self.texture_size) if\
                                    not self.static else pg.Rect(self.x - self.w / 2, self.y + 7.5 - self.h / 2, *self.texture_size), float(self.angle), (self.w / 2., self.h / 2.))
                            else:
                                self.texture.draw(None, pg.Rect(self.x + Build.fell.Camera.pos[0] + self.render_size[0] - self.w / 2, self.y + Build.fell.Camera.pos[1] + 7.5 - self.h / 2, *self.texture_size) if\
                                    not self.static else pg.Rect(self.x + self.render_size[0] - self.w / 2, self.y + 7.5 - self.h / 2, *self.texture_size), float(self.angle), (self.w / 2., self.h / 2.))
                else:
                    if self.pos[0] + self.render_size[0] > -Build.fell.Camera.pos[0] and self.pos[0] < -Build.fell.Camera.pos[0] + Build.sell.left and \
                        self.pos[1] + self.render_size[1] > -Build.fell.Camera.pos[1] and self.pos[1] < -Build.fell.Camera.pos[1] + Build.sell.up:

                        self.Fon.draw(None, pg.Rect(self.x + Build.fell.Camera.pos[0], self.y + Build.fell.Camera.pos[1], self.w, self.h) if\
                            not self.static else pg.Rect(self.x, self.y, self.w, self.h), float(self.angle), (0, 0))
                        
                        self.render.draw(None, pg.Rect(self.x + Build.fell.Camera.pos[0], self.y + Build.fell.Camera.pos[1] + 10, *self.render_size) if\
                            not self.static else pg.Rect(self.x, self.y + 10, *self.render_size), float(self.angle), (0, 0))
                        
                        if (self.time // 100) % 2 == 1 and self.Focus:
                            if self.text == "":
                                self.texture.draw(None, pg.Rect(self.x + Build.fell.Camera.pos[0], self.y + Build.fell.Camera.pos[1] + 7.5, *self.texture_size) if\
                                    not self.static else pg.Rect(self.x, self.y + 7.5, *self.texture_size), float(self.angle), (0, 0))
                            else:
                                self.texture.draw(None, pg.Rect(self.x + Build.fell.Camera.pos[0] + self.render_size[0], self.y + Build.fell.Camera.pos[1] + 7.5, *self.texture_size) if\
                                    not self.static else pg.Rect(self.x + self.render_size[0], self.y + 7.5, *self.texture_size), float(self.angle), (0, 0))
                
            def event(self, events):
                if events.type == pg.MOUSEBUTTONDOWN:
                    if self.pos[0] - self.size[0] / 2 < (events.pos[0] - (Build.sell.size_window_standart[0] - Build.sell.General_size[0]) / 2) / (Build.sell.General_size[0] / Build.sell.left) < self.pos[0] + self.size[0] / 2 and \
                       self.pos[1] - self.size[1] / 2 < (events.pos[1] - (Build.sell.size_window_standart[1] - Build.sell.General_size[1]) / 2) / (Build.sell.General_size[1] / Build.sell.up) < self.pos[1] + self.size[1] / 2: 
                        self.Focus = True
                    else: self.Focus = False

                if not self.Focus: return
                
                is_changed = False
                if events.type == pg.TEXTINPUT: self.text += events.text; is_changed = True
                elif events.type == pg.KEYDOWN:
                    if events.key == pg.K_BACKSPACE: self.text = self.text[:-1]; is_changed = True
                if is_changed: self._update_texture()
            
            def Clear_Input(self): self.text = ""; self._update_texture()
            
            def ExecuteOnceCode(self, code): code(self)
            
            def get_type(self): return self.type
            def get_text(self): return self.text
            def get_name(self): return self.name

            def get_pos(self):
                if ot_pos: return [self.pos[0] / left, self.pos[1] / up] if self.static else [(self.pos[0] + Build.fell.Camera.pos[0]) / left, (self.pos[1] + Build.fell.Camera.pos[1]) / up]
                return self.pos if self.static else [self.pos[0] + Build.fell.Camera.pos[0], self.pos[1] + Build.fell.Camera.pos[1]]
            def set_pos(self, x, y):
                if ot_pos: x, y = left*x, up*y
                self.pos = [x, y]

            def get_size(self):
                if ot_pos: return [self.size[0] / left, self.size[1] / up]
                return self.size
            def set_size(self, w, h):
                if ot_pos: w, h = left*w, up*h
                self.size = [w, h]

            def get_angle(self): return self.angle
            def set_angle(self, angle): self.angle = angle

            def get_static(self): return self.static

            def get_center(self): return self.center
            def set_center(self, center): self.center = center

            def set_static(self, static): self.static = static

            def set_text(self, text): self.text = text; self._update_texture()
            
            def _update_texture(self):
                if self.text == "":
                    self.render_text_pg = self.font.render(self.default_text, True, (150, 150, 150))
                    self.render_size = self.render_text_pg.get_size()
                    time_text = self.default_text
                else:
                    self.render_text_pg = self.font.render(self.text, True, (255, 255, 255))
                    self.render_size = self.render_text_pg.get_size()
                    time_text = self.text
                self.metrics = self.font.metrics(time_text)
                if self.render_size[0] > self.w:
                    self.render_text_pg = self.font.render(f"{time_text}...", True, (255, 255, 255))
                    self.render_size = self.render_text_pg.get_size()
                    num = [0, 0]
                    while self.render_size[0] - num[1] > self.w:
                        num[0] += 1
                        num[1] += self.metrics[-num[0]][4]
                    if num[0] > 0: self.render_text_pg = self.font.render(f"{time_text[:-num[0]]}...", True, (255, 255, 255))
                    self.render_size = self.render_text_pg.get_size()
                self.render = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.render_text_pg)
        self.fell.Input_Field = Input_Field

        def SetColor(color): self.sell.render.draw_color = color
        self.fell.SetColor = SetColor

        def AllDrawTexture():
            for t in Build.sell.data_Texture.values():
                if t["tex"].get_type() == "Texture": t["tex"].TextureDraw()
        self.fell.AllDrawTexture = AllDrawTexture

        def AllDrawSquare():
            for t in Build.sell.data_Texture.values():
                if t["tex"].get_type() == "Square": t["tex"].SquareDraw()
        self.fell.AllDrawSquare = AllDrawSquare

        def AllDrawText():
            for t in Build.sell.data_Texture.values():
                if t["tex"].get_type() == "Text": t["tex"].TextDraw()
        self.fell.AllDrawText = AllDrawText

        def AllDrawButton():
            for t in Build.sell.data_Texture.values():
                if t["tex"].get_type() == "Button": t["tex"].ButtonDraw()
        self.fell.AllDrawButton = AllDrawButton

        def AllDrawInputField():
            for t in Build.sell.data_Texture.values():
                if t["tex"].get_type() == "Input_Field": t["tex"].Input_FieldDraw()
        self.fell.AllDrawInputField = AllDrawInputField

        def AllDrawPolygon():
            for t in Build.sell.data_Texture.values():
                if t["tex"].get_type() == "Polygon": t["tex"].PolygonDraw()
        self.fell.AllDrawPolygon = AllDrawPolygon

        def AllDrawArrow():
            for t in Build.sell.data_Texture.values():
                if t["tex"].get_type() == "Arrow": t["tex"].ArrowDraw()
        self.fell.AllDrawArrow = AllDrawArrow

        def AllDraw():
            for t in Build.sell.data_Texture.values():
                obj = t["tex"]
                obj_type = obj.get_type()
                if obj_type == "Texture": obj.TextureDraw()
                elif obj_type == "Square": obj.SquareDraw()
                elif obj_type == "Text": obj.TextDraw()
                elif obj_type == "Button": obj.ButtonDraw()
                elif obj_type == "Input_Field": obj.Input_FieldDraw()
                elif obj_type == "Polygon": obj.PolygonDraw()
                elif obj_type == "Arrow": obj.ArrowDraw()
        self.fell.AllDraw = AllDraw
        def AllUpdateScript():
            for t in Build.sell.data_Texture.values():
                obj = t["tex"]
                obj_type = obj.get_type()
                if obj_type == "Texture": obj.TextureUpdate()
                elif obj_type == "Square": obj.SquareUpdate()
                elif obj_type == "Text": obj.TextUpdate()
                elif obj_type == "Button": obj.ButtonUpdate()
        self.fell.AllUpdateScript = AllUpdateScript
        def AllUpdate(dt):
            for t in Build.sell.data_update.values(): t.update(dt)
        self.fell.AllUpdate = AllUpdate

        def UpdateMusic():
            for Music in self.sell.data_Music.key():
                if self.sell.data_Music[Music].is_done() and self.sell.data_Music[Music].get_auto():
                    if self.sell.data_Music[Music].get_loop(): self.sell.data_Music[Music].play()
                    else: del self.sell.data_Music[Music]
        self.fell.UpdateMusic = UpdateMusic

        def MoveMent(keys, Texture, speed):
            keys = keys.split(".")
            if ot_pos:
                if Build.fell.ButtonPressed(keys[0]): Texture.MoveY(up*-speed)
                if Build.fell.ButtonPressed(keys[1]): Texture.MoveX(left*-speed)
                if Build.fell.ButtonPressed(keys[2]): Texture.MoveY(up*speed)
                if Build.fell.ButtonPressed(keys[3]): Texture.MoveX(left*speed)
            else:
                if Build.fell.ButtonPressed(keys[0]): Texture.MoveY(-speed)
                if Build.fell.ButtonPressed(keys[1]): Texture.MoveX(-speed)
                if Build.fell.ButtonPressed(keys[2]): Texture.MoveY(speed)
                if Build.fell.ButtonPressed(keys[3]): Texture.MoveX(speed)
        self.fell.MoveMent = MoveMent

        def event(events=None, list_obj=None, Keyboard=None):
            if events is None: events = {}
            if list_obj is None: list_obj = []
            if Keyboard is None: Keyboard = {}

            self = Build
            EV = pg.event.get()
            event_dict = self.sell.Event_List_def(EV)
            
            for ev in EV:
                for obj in list_obj:  obj.event(ev)

                if ev.type == pg.FINGERDOWN:  self.sell.touch[ev.finger_id] = {'x': ev.x, 'y': ev.y}
                elif ev.type == pg.FINGERUP:
                    if ev.finger_id in self.sell.touch:  del self.sell.touch[ev.finger_id]
                
                if ev.type == pg.WINDOWRESIZED:
                    for Scene in self.sell.Scene.keys(): self.sell.Scene[Scene][1] = self.sell.Scene[Scene][0]()
                    self.fell.Camera = Camera()
                
                if ev.type in (pg.KEYDOWN, pg.KEYUP):
                    if ev.type == pg.KEYDOWN: status = "down"
                    else: status = "up"
                    key = pg.key.name(ev.key)
                    if key == "return":
                        if "enter" in Keyboard: key = "enter"
                    if key.startswith("numpad "): key = key.replace("numpad ", ""); key = f"[{key}]"
                    key_examination = key
                    if key_examination in Keyboard:
                        if Keyboard[key_examination][0] == status: Keyboard[key_examination][1]()
                    if logs: print(f"Name: '{pg.key.name(ev.key)}' | Key ID: {ev.key} | Scan: {ev.scancode}")
            
            for btn_name in self.sell.Events:
                obj = self.sell.Events[btn_name]
                if event_dict.get(getattr(obj, 'mouse', '')) and obj.is_hovered(): obj.func()
                    
            for event_name in events.keys():
                if event_dict.get(event_name): events[event_name]()
                
        self.fell.Event = event

        def SetScene(name): self.sell.falt = name
        self.fell.ChangeScene = SetScene

        def ChangeScene(name): self.sell.falt = name
        self.fell.ChangeScene = ChangeScene

        def SetFPSValue(fps): self.sell.FPS = fps
        self.fell.SetFPSValue = SetFPSValue

        def GetFPSValue(): return self.sell.FPS
        self.fell.GetFPSValue = GetFPSValue

        def GetFPS(): return self.sell.Clock.get_fps()
        self.fell.GetFPS = GetFPS

        def ClockUse(stabilize_fps=True):
            if stabilize_fps: self.sell.Clock.tick_busy_loop(self.sell.FPS)
            else: self.sell.Clock.tick(self.sell.FPS)
        self.fell.ClockUse = ClockUse

        class Camera:
            def __init__(self):
                self.pos = [0, 0]

            def set_pos(self, x, y):
                if ot_pos: x, y = left*x, up*y
                self.pos = [-x, -y]
            def get_pos(self):
                if ot_pos: return -self.pos[0] / left, -self.pos[1] / up
                return -self.pos[0], -self.pos[1]

            def Move(self, x, y): self.pos[0] += -x; self.pos[1] += -y
            def MoveY(self, y): self.pos[1] += -y
            def MoveX(self, x): self.pos[0] += -x
        self.fell.Camera = Camera()

        def UpdateButtonPressedHow(): self.sell.PressedButton = pg.key.get_pressed()
        self.fell.UpdateButtonPressedHow = UpdateButtonPressedHow
        self.fell.UBPH = UpdateButtonPressedHow

        def ButtonPressed(key):
            if self.sell.PressedButton is None: print("\033[33mWARNING: ButtonPressedHow not updated\033[0m"); return None
            return self.sell.PressedButton[pg.key.key_code(key)]
        self.fell.ButtonPressed = ButtonPressed

        def Get_DeltaTime(): self.sell.DeltaTimeHow = self.sell.Clock.get_time() / 1000.; return self.sell.DeltaTimeHow
        self.fell.Get_DeltaTime = Get_DeltaTime

        def Get_DeltaTimeHow(): return self.sell.DeltaTimeHow
        self.fell.Get_DeltaTimeHow = Get_DeltaTimeHow

        def ClearCache(): self.sell.data_Texture = {}
        self.fell.ClearCache = ClearCache

        def GetCache(): return self.sell.data_Texture
        self.fell.GetCache = GetCache

        def ClearCache(): self.sell.Cache = {}
        self.fell.ClearCache = ClearCache
        def GetCache(): return self.sell.data_Texture
        self.fell.GetCache = GetCache

        def ClearDataTexture(): self.sell.data_Texture = {}
        self.fell.ClearDataTexture = ClearDataTexture
        def GetDataTexture(): return self.sell.data_Texture
        self.fell.GetDataTexture = GetDataTexture

        def ClearData(): self.sell.data = {}
        self.fell.ClearData = ClearData
        def GetData(): return self.sell.data
        self.fell.GetData = GetData

        def ClearEvents(): self.sell.Events = {}
        self.fell.ClearEvents = ClearEvents
        def GetEvents(): return self.sell.Events
        self.fell.GetEvents = GetEvents

        def ClearScene(): self.sell.Scene = {}
        self.fell.ClearScene = ClearScene
        def GetScene(): return self.sell.Scene
        self.fell.GetScene = GetScene

        def DeleteElement(name):
            del self.sell.data_Texture[name]
            try: del self.sell.Events[name]
            except: pass
            try: del self.sell.Cache[name]
            except: pass
            try: del self.sell.data[name]
            except: pass
            del name
        self.fell.DeleteElement = DeleteElement

        def Internal_Texture_Angle_add(add_angle): self.sell.TextureScreen_angle += add_angle
        def Internal_Texture_Angle_Sub(sub_angle): self.sell.TextureScreen_angle -= sub_angle
        def Internal_Texture_Angle_get(): return self.sell.TextureScreen_angle
        def Ingernal_Texture_Angle_set(angle): self.sell.TextureScreen_angle = angle
        def Internal_Texture_Angle_reset(): self.sell.TextureScreen_angle = 0.
        self.fell.Internal_Texture_Angle_add = Internal_Texture_Angle_add
        self.fell.Internal_Texture_Angle_Sub = Internal_Texture_Angle_Sub
        self.fell.Internal_Texture_Angle_get = Internal_Texture_Angle_get
        self.fell.Ingernal_Texture_Angle_set = Ingernal_Texture_Angle_set
        self.fell.Internal_Texture_Angle_reset = Internal_Texture_Angle_reset

        def set_Internal_Texture_Alpha(self, alpha): self.sell.TextureScreen.alpha = alpha
        def get_Internal_Texture_Alpha(self): return self.sell.TextureScreen.alpha
        self.fell.set_Internal_Texture_Alpha = set_Internal_Texture_Alpha
        self.fell.get_Internal_Texture_Alpha = get_Internal_Texture_Alpha

        def set_Internal_Texture_color(self, color): self.sell.TextureScreen.color = color
        def get_Internal_Texture_color(self): return self.sell.TextureScreen.color
        self.fell.set_Internal_Texture_color = set_Internal_Texture_color
        self.fell.get_Internal_Texture_color = get_Internal_Texture_color

        class SmoothMoverByTime:
            def __init__(self, name, start_pos, time_to_target):
                self.pos = [float(start_pos[0]), float(start_pos[1])]
                self.start_pos = [float(start_pos[0]), float(start_pos[1])]
                self.target = self.pos[:]
                self._duration = max(1, int(time_to_target)) / 60.0
                self._elapsed = 0.0
                self._EASE_POWER = 2.
                self._reverse = False
                self.name = name
            
            def get_name(self): return self.name

            def set_target(self, target, time_to_target=None, reverse=None):
                self.target = [float(target[0]), float(target[1])]
                self.start_pos = self.pos[:]
                self._elapsed = 0.0
                if time_to_target is not None: self._duration = max(1, int(time_to_target)) / 60.0
                if reverse is not None: self._reverse = bool(reverse)

            def set_time_to_target(self, time_to_target):
                self._duration = max(1, int(time_to_target)) / 60.0

            def set_reverse(self, reverse: bool):
                self._reverse = bool(reverse)

            def get_pos(self): return self.pos[:]

            def is_done(self): return self._elapsed >= self._duration

            def update(self, dt):
                if self._elapsed >= self._duration: return self.pos[:]
                self._elapsed = min(self._duration, self._elapsed + dt)
                if self._reverse:
                    self.pos[0] = self.start_pos[0] + (self.target[0] - self.start_pos[0]) * ((self._elapsed / self._duration) ** self._EASE_POWER)
                    self.pos[1] = self.start_pos[1] + (self.target[1] - self.start_pos[1]) * ((self._elapsed / self._duration) ** self._EASE_POWER)
                else:
                    self.pos[0] = self.start_pos[0] + (self.target[0] - self.start_pos[0]) * (1.0 - (1.0 - (self._elapsed / self._duration)) ** self._EASE_POWER)
                    self.pos[1] = self.start_pos[1] + (self.target[1] - self.start_pos[1]) * (1.0 - (1.0 - (self._elapsed / self._duration)) ** self._EASE_POWER)
                if self._elapsed >= self._duration:
                    self.pos[0], self.pos[1] = self.target[0], self.target[1]
                return self.pos[:]

        class SmoothRotationByTime:
            def __init__(self, name, start_angle, time_to_target):
                self.value = float(start_angle) % 360
                self.start_angle = self.value
                self.target = self.value
                self._duration = max(1, int(time_to_target)) / 60.0
                self._elapsed = 0.0
                self._EASE_POWER = 2.
                self._reverse = False
                self.name = name
            
            def get_name(self): return self.name

            def set_target(self, target, time_to_target=None, reverse=None):
                self.target = float(target) % 360
                self.start_angle = self.value
                self._elapsed = 0.0
                if time_to_target is not None: self._duration = max(1, int(time_to_target)) / 60.0
                if reverse is not None: self._reverse = bool(reverse)

            def set_time_to_target(self, time_to_target):
                self._duration = max(1, int(time_to_target)) / 60.0

            def set_reverse(self, reverse: bool):
                self._reverse = bool(reverse)

            def get_value(self): return self.value

            def is_done(self): return self._elapsed >= self._duration

            def update(self, dt):
                if self._elapsed >= self._duration: return self.value
                self._elapsed = min(self._duration, self._elapsed + dt)
                if self._reverse:
                    self.value = (self.start_angle + (((self.target - self.start_angle + 180) % 360) - 180) * ((self._elapsed / self._duration) ** self._EASE_POWER)) % 360
                else:
                    self.value = (self.start_angle + (((self.target - self.start_angle + 180) % 360) - 180) * (1.0 - (1.0 - (self._elapsed / self._duration)) ** self._EASE_POWER)) % 360
                if self._elapsed >= self._duration:
                    self.value = self.target
                return self.value
            
        self.fell.SmoothMoverByTime = SmoothMoverByTime
        self.fell.SmoothRotationByTime = SmoothRotationByTime
        
        class Sprite_Lighting:
            def __init__(self, strong, color):
                self.strong = strong
                self.radius = strong*10
                self.light = pg.Surface((strong*10 * 2, strong*10 * 2), pg.SRCALPHA)
                self.light.fill((0, 0, 0, 0))
                pixels = pg.PixelArray(self.light)
                r, g, b = color[:3]
                for y in range(self.radius * 2):
                    for x in range(self.radius * 2):
                        dx, dy = x - self.radius, y - self.radius
                        distance = math.sqrt(dx*dx + dy*dy)
                        if distance <= self.radius:
                            alpha_factor = 1.0 - (distance / self.radius)
                            alpha = max(0, int(255 * (alpha_factor ** 2)))
                            alpha = int(255 * alpha_factor)
                            pixels[x, y] = (r, g, b, alpha)
                pixels.close()
                self.light = pg._sdl2.video.Texture.from_surface(Build.sell.render, self.light)
                self.light.blend_mode = 2
            
            def Draw(self, xy): self.light.draw(None, pg.Rect(xy[0] - self.radius, xy[1] - self.radius, self.radius * 2, self.radius * 2), 0)
        self.fell.Sprite_Lighting = Sprite_Lighting

        class Music:
            def __init__(self, name, path, loop=False, auto=True):
                self.name = name
                self.path = File(path)
                self.auto = auto
                self.stream = miniaudio.stream_file(self.path)
                self.loop = loop
                self.device = miniaudio.PlaybackDevice()
                self.volume = 1
                self.set_volume(self.volume)
                self._info = miniaudio.get_file_info(self.path)
                Build.fell.sell.data_Music[name] = self
            def play(self): self.device.start(self.stream)
            def stop(self): self.device.stop()
            def get_time(self): return self.stream.position_in_seconds
            def get_length(self): return self._info.duration_milliseconds / 1000.
            def set_volume(self, volume):
                self.volume = volume
                self.device.set_volume(volume)
            def get_volume(self): return self.volume
            def set_time(self, pos): self.stream.seek_to_seconds(pos)
            def set_loop(self, loop):
                self.loop = loop
                self.device.stop()
                self.stream = miniaudio.stream_file(self.path)
                self.device.start(self.stream)
            def get_loop(self): return self.loop
            def is_done(self): return not self.get_time() < self.get_length()
            def set_auto(self, auto): self.auto = auto
            def get_auto(self): return self.auto
        self.fell.Music = Music

        class Sound:
            def __init__(self, name, path, loop=False, auto=True):
                self.name = name
                self.path = File(path)
                self.stream = pg.mixer.Sound(self.path)
                self.stream.set_volume(1)
                self.volume = 1
                self.loop = loop
                self.auto = auto
                Build.fell.sell.data_Sound[name] = self
            def play(self): self.stream.play()
            def stop(self): self.stream.stop()
            def get_length(self): return self.stream.get_length()
            def set_volume(self, volume):
                self.volume = volume
                self.stream.set_volume(volume)
            def get_volume(self): return self.volume
            def set_loop(self, loop): self.loop = loop
            def get_loop(self): return self.loop
            def is_playing(self): return self.stream.get_busy()
            def set_auto(self, auto): self.auto = auto
            def get_auto(self): return self.auto
        self.fell.Sound = Sound

        class Vector2D:
            def __init__(self, x, y): self.Vector = [x, y]
            def Add_x(self, x): self.Vector[0] += x
            def Add_y(self, y): self.Vector[1] += y
            def Add_l(self, l): self.Vector[0] += l[0]; self.Vector[1] += l[1]
            def Sub_x(self, x): self.Vector[0] -= x
            def Sub_y(self, y): self.Vector[1] -= y
            def Sub_l(self, l): self.Vector[0] -= l[0]; self.Vector[1] -= l[1]
            def Mult_x(self, x): self.Vector[0] *= x
            def Mult_y(self, y): self.Vector[1] *= y
            def Mult_l(self, l): self.Vector[0] *= l[0]; self.Vector[1] *= l[1]
            def Div_x(self, x): self.Vector[0] /= x
            def Div_y(self, y): self.Vector[1] /= y
            def Div_l(self, l): self.Vector[0] /= l[0]; self.Vector[1] /= l[1]
            def Get_x(self): return self.Vector[0]
            def Get_y(self): return self.Vector[1]
            def Get_l(self): return self.Vector
            def Set_x(self, x): self.Vector[0] = x
            def Set_y(self, y): self.Vector[1] = y
            def Set_l(self, l): self.Vector = l
            def Reset(self): self.Vector = [0, 0]
        class Vector3D:
            def __init__(self, x, y, z): self.Vector = [x, y, z]
            def Add_x(self, x): self.Vector[0] += x
            def Add_y(self, y): self.Vector[1] += y
            def Add_z(self, z): self.Vector[2] += z
            def Add_l(self, l): self.Vector[0] += l[0]; self.Vector[1] += l[1]; self.Vector[2] += l[2]
            def Sub_x(self, x): self.Vector[0] -= x
            def Sub_y(self, y): self.Vector[1] -= y
            def Sub_z(self, z): self.Vector[2] -= z
            def Sub_l(self, l): self.Vector[0] -= l[0]; self.Vector[1] -= l[1]; self.Vector[2] -= l[2]
            def Mult_x(self, x): self.Vector[0] *= x
            def Mult_y(self, y): self.Vector[1] *= y
            def Mult_z(self, z): self.Vector[2] *= z
            def Mult_l(self, l): self.Vector[0] *= l[0]; self.Vector[1] *= l[1]; self.Vector[2] *= l[2]
            def Div_x(self, x): self.Vector[0] /= x
            def Div_y(self, y): self.Vector[1] /= y
            def Div_z(self, z): self.Vector[2] /= z
            def Div_l(self, l): self.Vector[0] /= l[0]; self.Vector[1] /= l[1]; self.Vector[2] /= l[2]
            def Get_x(self): return self.Vector[0]
            def Get_y(self): return self.Vector[1]
            def Get_z(self): return self.Vector[2]
            def Get_l(self): return self.Vector
            def Set_x(self, x): self.Vector[0] = x
            def Set_y(self, y): self.Vector[1] = y
            def Set_z(self, z): self.Vector[2] = z
            def Set_l(self, l): self.Vector = l
            def Reset(self): self.Vector = [0, 0, 0]
        self.fell.Vector2D = Vector2D
        self.fell.Vector3D = Vector3D

        class Polygon:
            def __init__(self, name, points_list, color, save=True):
                points = []
                for p in points_list:
                    points.append((p[0] * left, p[1] * up))

                self.points = points
                self.color = color
                self.name = name
                self.type = "Polygon"

                min_x = min(p[0] for p in points)
                max_x = max(p[0] for p in points)
                min_y = min(p[1] for p in points)
                max_y = max(p[1] for p in points)
                self.min_x = min_x
                self.min_y = min_y
                self.size = (int(max_x - self.min_x) + 1, int(max_y - self.min_y) + 1)
                self.texture = pg._sdl2.video.Texture(Build.sell.render, (int(max_x - min_x) + 1, int(max_y - min_y) + 1), target=1)
                self.texture.blend_mode = pg.BLENDMODE_BLEND
                if save: Build.sell.data_Texture[name] = {"tex": self}
            
            def PolygonDraw(self):
                if len(self.points) < 3:
                    if logs: print("\033[31mERROR: Polygon must have at least 3 points\033[0m")
                    return
                
                old_color = Build.sell.render.draw_color
                Build.sell.render.target = self.texture
                Build.sell.render.draw_color = (0, 0, 0, 0)
                Build.sell.render.clear()
                Build.sell.render.draw_color = self.color
                
                p0 = (self.points[0][0] - self.min_x, self.points[0][1] - self.min_y)
                for i in range(1, len(self.points) - 1):
                    p1 = (self.points[i][0] - self.min_x, self.points[i][1] - self.min_y)
                    p2 = (self.points[i+1][0] - self.min_x, self.points[i+1][1] - self.min_y)
                    Build.sell.render.fill_triangle(p0, p1, p2)

                Build.sell.render.target = Build.sell.TextureScreen

                if self.color is not None: Build.sell.render.draw_color = self.color
                self.texture.draw(None, pg.Rect(self.min_x, self.min_y, *self.size))
                Build.sell.render.draw_color = old_color
            
            def get_name(self): return self.name
            def get_points(self): return self.points
            def get_color(self): return self.color
            def set_color(self, color): self.color = color
            def set_points(self, points): self.points = points
            def get_type(self): return self.type
        self.fell.Polygon = Polygon

        class Arrow:
            def __init__(self, name, point1, width, color, save=True):
                self.name = name
                self.point = point1
                self.width = width
                self.color = color
                self.type = "Arrow"
                angle = math.atan2((point1[1][1] - point1[0][1]), (point1[1][0] - point1[0][0]))
                self.angle = math.degrees(angle)
                self.point2 = (
                    (point1[0][0] + width * math.cos(angle + math.pi / 2),
                    point1[0][1] + width * math.sin(angle + math.pi / 2)),
                    (point1[1][0] + width * math.cos(angle + math.pi / 2),
                    point1[1][1] + width * math.sin(angle + math.pi / 2))
                )

                self.Arrow_line = Build.fell.Polygon("Arrow", (point1[0], point1[1], self.point2[1], self.point2[0]), color, save=False)
                if save: Build.sell.data_Texture[self.type] = {"tex": self}
            
            def ArrowDraw(self):
                self.Arrow_line.PolygonDraw()
            
            def get_type(self): return self.type

        self.fell.Arrow = Arrow

        if logs: print("\033[92mcompleted successfully\033[0m")

    def NewScene(self, name, func):
        if self.sell.logs: print(f"\033[90mCreating Scene {name}\033[0m")
        name = str(name)
        if not callable(func): print("\033[31mERROR: Code must be a function\033[0m"); return
        try: self.sell.Scene[name] = [func, func()]
        except: ERROR()
        if self.sell.logs: print("\033[92mcompleted successfully\033[0m")
    
    def SetScene(self, name):
        if self.sell.logs: print(f"\033[90mChanging Scene{name}\033[0m")
        self.sell.falt = name
        if self.sell.logs: print("\033[92mcompleted successfully\033[0m")

    def ChangeScene(self, name):
        self.sell.falt = name
        if self.sell.logs: print(f"\033[90mChanging Scene {name}\033[0m")
        if self.sell.logs: print("\033[92mcompleted successfully\033[0m")
    
    def SetSHADES(self, SHADERS):
        if self.sell.logs: print(f"\033[90mSetting SHADERS to {SHADERS}\033[0m")
        self.sell.SHADER = SHADERS
        if self.sell.logs: print("\033[92mcompleted successfully\033[0m")

    def ExecuteOneFrame(self, name=None):
        if self.sell.SafeMode:
            try:
                if self.sell.logs: print(f"\033[90mExecuting a single-frame scene {name if not name is None else self.sell.falt}\033[0m")
                if not name is None: self.sell.Scene[name]()
                else: self.sell.Scene[self.sell.falt]()
                if self.sell.logs: print("\033[92mcompleted successfully\033[0m")
            except: ERROR()
        else:
            if self.sell.logs: print(f"\033[90mExecuting a single-frame scene {name if not name is None else self.sell.falt}\033[0m")
            if not name is None: self.sell.Scene[name]()
            else: self.sell.Scene[self.sell.falt]()
            if self.sell.logs: print("\033[92mcompleted successfully\033[0m")
    def ExecuteOnceCode(self, code):
        if self.sell.SafeMode:
            try:
                if self.sell.logs: print(f"\033[90mExecuting a single-frame code\033[0m")
                if callable(code): 
                    if len(inspect.signature(code).parameters) == 1: code(self.fell)
                    else: print("\033[31mERROR: Code must be a function with one parameter\033[0m"); return
                else: print("\033[31mERROR: Code must be a function\033[0m"); return
                if self.sell.logs: print("\033[92mcompleted successfully\033[0m")
            except: ERROR()
        else:
            if self.sell.logs: print(f"\033[90mExecuting a single-frame code\033[0m")
            if callable(code): 
                if len(inspect.signature(code).parameters) == 1: code(self.fell)
                else: print("\033[31mERROR: Code must be a function with one parameter\033[0m"); return
            else: print("\033[31mERROR: Code must be a function\033[0m"); return
            if self.sell.logs: print("\033[92mcompleted successfully\033[0m")

    def SetSafeMode(self, SafeMode):
        self.sell.SafeMode = SafeMode
        if self.sell.logs: print(f"\033[90mSetting SafeMode to {SafeMode}\033[0m")
    def GetSafeMode(self):
        if self.sell.logs: print(f"\033[90mGetting SafeMode\033[0m")
        return self.sell.SafeMode
    
    def SetLogs(self, logs):
        self.sell.logs = logs
        if self.sell.logs: print(f"\033[90mSetting logs to {logs}\033[0m")
    def GetLogs(self):
        if self.sell.logs: print("\033[90mGetting logs\033[0m")
        return self.sell.logs
    
    def SetDeveLoperMode(self, DeveLoperMode):
        self.sell.DeveLoperMode = DeveLoperMode
        if self.sell.logs: print(f"\033[90mSetting DeveLoperMode to {DeveLoperMode}\033[0m")
    
    def GetDeveLoperMode(self):
        if self.sell.logs: print(f"\033[90mGetting DeveLoperMode\033[0m")
        return self.sell.DeveLoperMode
    
    def SetVsync(self, Vsync):
        self.sell.Vsync = Vsync
        if self.sell.logs: print(f"\033[90mSetting Vsync to {Vsync}\033[0m")
    
    def GetVsync(self):
        if self.sell.logs: print(f"\033[90mGetting Vsync\033[0m")
        return self.sell.Vsync
    
    def GetFell(self):
        if self.sell.logs: print(f"\033[90mGetting Fell\033[0m")
        return self.fell
    def _GetSell(self):
        if self.sell.logs: print(f"\033[90mGetting Sell\033[0m")
        return self.sell
    
    def GetVersion(self):
        if self.sell.logs: print(f"\033[90mGetting Version\033[0m")
        return VERSION
    
    def GetFULLSCREEN(self):
        if self.sell.logs: print(f"\033[90mGetting FULLSCREEN\033[0m")
        return self.sell.FULLSCREEN
    
    def SetName(self, name):
        self.sell.name = name
        self.sell.screen.title = name
        if self.sell.logs: print(f"\033[90mSetting Name to {name}\033[0m")
    def GetName(self):
        if self.sell.logs: print(f"\033[90mGetting Name\033[0m")
        return self.sell.name

    def SetFULLSCREEN(self, FULLSCREEN):
        self.sell.FULLSCREEN = FULLSCREEN
        if FULLSCREEN: self.sell.screen.set_fullscreen(2)
        else:
            self.sell.screen.set_windowed()
            self.sell.screen.size = self.sell.size_window_standart
        if self.sell.logs: print(f"\033[90mSetting FULLSCREEN to {FULLSCREEN}\033[0m")
    
    def Destroy(self):
        if self.sell.data_Music:
            for Music in self.sell.data_Music.key(): del self.sell.data_Music[Music]
        if self.sell.SafeMode:
            self.sell.war = False
            try:
                if self.sell.logs: print(f"\033[90mDestroying Engine Version {VERSION}\033[0m")
                self.sell.screen.destroy()
                del self.sell.render
            except: print("\033[31mFATAL ERROR: An error has fatal error.\033[0m")
        else:
            if self.sell.logs: print(f"\033[90mDestroying Engine Version {VERSION}\033[0m")
            self.sell.screen.destroy()
            del self.sell.render

    def run(self):
        if self.sell.logs: print(f"\033[90mStarting engine with parameters:\n- SafeMode: {self.sell.SafeMode};\n- logs: {self.sell.logs}\033[0m")
        if self.sell.SafeMode:
            try:
                while self.sell.war:
                    self.sell.Scene[self.sell.falt][1].run()
            except: ERROR()
        else:
            while self.sell.war: self.sell.Scene[self.sell.falt][1].run()
        
        if self.sell.logs: print("\033[90mDone.\033[0m")

class ERROR(Build):
    def __init__(self):
                if self.sell.logs: print("\033[31mFATAL ERROR: An error has fatal error.\033[0m")
                try: self.sell.screen.destroy()
                except: ...
                try: del self.sell.render
                except: ...
                screen = pg.display.set_mode((800, 600))
                pg.display.set_caption("Sorry, it looks like an error has fatal error (TT)")
                left, up = pg.display.Info().current_w, pg.display.Info().current_h
                clock = pg.time.Clock()
                ERROR_Font = pg.font.SysFont(None, int(up / 25.))
                w = True
                e = traceback.format_exc()
                errors = []
                errors.append(e)
                er = "\n".join(errors)
                print(er)
                RENDER = []
                Time = 0
                error_lines = er.splitlines() if er else []
                global VERSION
                fatal_errors = [
                    ("FATAL ERROR   :(", (255, 0, 0)),
                    ("", (0, 0, 0)),
                    (f"Platform: {platform.platform()}", (255, 255, 0)),
                    (f"PyGame version: {pg.__version__}", (255, 255, 0)),
                    (f"Python version: {sys.version}", (255, 255, 0)),
                    (f"_sdl2 version: {".".join(map(str, pg.get_sdl_version()))}", (255, 255, 0)),
                    (f"Engine version: {VERSION}", (255, 255, 0)),
                    ("", (0, 0, 0)),
                    (f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", (255, 255, 0)),
                    ("", (0, 0, 0))
                ]

                while w:
                    for ev in pg.event.get():
                        if not error_lines and not fatal_errors:
                            if ev.type == pg.QUIT: w = False; break
                            if ev.type == pg.KEYDOWN: w = False; break
                            if ev.type == pg.MOUSEBUTTONDOWN: w = False; break
                    screen.fill((0, 0, 0))
                    for index in range(len(RENDER)):
                        render = RENDER[index]
                        #screen.blit(render, (left / 2 - render.get_size()[0] / 2, index * render.get_size()[1]))
                        screen.blit(render, (0., index * render.get_size()[1]))
                    
                    if Time == 0:
                        Time = 0
                        if fatal_errors:
                            text, color = fatal_errors[0]
                            RENDER.append(ERROR_Font.render(text, True, color))
                            del fatal_errors[0]
                        elif error_lines:
                            RENDER.append(ERROR_Font.render(error_lines[0], True, (255, 255, 255)))
                            del error_lines[0]
                    else: Time += 1
                    clock.tick(30)
                    pg.display.update()
                sys.exit(-1)