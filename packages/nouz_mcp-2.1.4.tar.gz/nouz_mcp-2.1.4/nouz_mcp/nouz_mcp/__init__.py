from nouz_mcp.server import run_server, VERSION

__version__ = VERSION
__all__ = ["run_server", "VERSION"]
