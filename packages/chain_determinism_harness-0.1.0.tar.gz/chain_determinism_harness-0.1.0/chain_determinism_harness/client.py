"""Async OpenAI-compatible client for chain-determinism replay.

Supports any endpoint exposing the OpenAI Chat Completions API:
- OpenAI direct (`https://api.openai.com/v1`)
- OpenRouter (`https://openrouter.ai/api/v1`)
- Together AI (`https://api.together.xyz/v1`)
- vLLM (`http://localhost:8000/v1` for local serving)
- Modal vLLM (your-app.modal.run/v1)
"""
from __future__ import annotations

import asyncio
import json
import os
import re
from typing import Optional

from openai import AsyncOpenAI


_SECRET_PATTERNS = [
    # OpenAI/OpenRouter/Anthropic-style keys: sk-, sk-proj-, sk-or-, sk-ant-
    # (+ ≥10 trailing chars). `[A-Za-z0-9_\-]` is intentionally narrow — these
    # vendors don't include dots/colons/slashes in keys.
    (re.compile(r"sk-[A-Za-z0-9_\-]{10,}"), "sk-<REDACTED>"),
    # Modal API tokens (ak-...)
    (re.compile(r"ak-[A-Za-z0-9_\-]{10,}"), "ak-<REDACTED>"),
    # Modal API secret tokens (as-...)
    (re.compile(r"as-[A-Za-z0-9_\-]{10,}"), "as-<REDACTED>"),
    # Bearer tokens. Match bearer + payload. Constrain payload length
    # (10..512 chars) to avoid greedy over-matching of legitimate file
    # paths / URLs that follow "bearer" verbiage in error messages
    # ("could not bearer foo.txt was missing"). Only match when followed
    # by whitespace/quote/end-of-line so we don't redact arbitrary suffix.
    (re.compile(
        r"(?i)\b(bearer)\s+[A-Za-z0-9_\-\.=/+]{10,512}(?=[\s\"',]|$)"
    ), r"\1 <REDACTED>"),
    # Generic Authorization / API-key header values (key=value or key: value
    # forms). Payload class expanded to include dots, colons, slashes, equals
    # so JWTs and other compound tokens are fully redacted.
    (re.compile(
        r"(?i)(authorization|api[_\-]?key|x-api-key)"
        r"(\s*[:=]\s*[\"\']?)([^\s\"\',<>]+)"
    ), r"\1\2<REDACTED>"),
    # HuggingFace-style tokens (hf_...)
    (re.compile(r"hf_[A-Za-z0-9]{20,}"), "hf_<REDACTED>"),
    # GitHub-style PATs (ghp_..., ghs_..., github_pat_...)
    (re.compile(r"gh[ps]_[A-Za-z0-9]{20,}"), "ghX_<REDACTED>"),
    (re.compile(r"github_pat_[A-Za-z0-9_]{20,}"), "github_pat_<REDACTED>"),
]


# Vetted prefix list for openrouter-routed model names. The `/` heuristic in
# `_resolve_base_url` previously accepted ANY model name containing '/' —
# an SSRF vector if `model` is ever attacker-influenced (e.g., loaded from
# a user-uploaded query JSON). Restrict to known open-weights vendor
# namespaces. Update this list rather than weakening the regex.
_OPENROUTER_VENDOR_PREFIXES = (
    "qwen/", "meta-llama/", "meta/", "deepseek/", "mistralai/", "mistral/",
    "google/", "anthropic/", "openai/", "01-ai/", "nousresearch/",
    "microsoft/", "databricks/", "cohere/", "togethercomputer/",
    "perplexity/", "x-ai/", "alibaba/",
)


def _scrub_secrets(text: str) -> str:
    """Best-effort scrub of API keys / bearer tokens from error strings before
    they enter attestation Receipts. Patterns cover OpenAI, OpenRouter, generic
    Bearer, and `authorization=`/`x-api-key=` headers.

    Reviewers should treat error_category as untrusted: this is defense-in-depth
    against credential exfiltration via Receipt logs, not a substitute for
    redacting at the logging layer.
    """
    for pattern, replacement in _SECRET_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def _resolve_api_key(model: str, explicit: Optional[str] = None) -> str:
    """Pick an API key for the OpenAI-compatible endpoint.

    Provider-aware: only returns keys that match the resolved base URL's
    provider family. Explicit ANTHROPIC_API_KEY fallthrough has been removed
    (Anthropic keys are not OpenAI-compatible and routing them to OpenAI/
    OpenRouter/vLLM endpoints is a credential-leak vector).
    """
    if explicit:
        return explicit
    base_url = (os.environ.get("CHAIN_DET_BASE_URL") or "").lower()
    if "openrouter" in base_url:
        key = os.environ.get("OPENROUTER_API_KEY", "")
        if not key:
            raise RuntimeError(
                "OpenRouter base URL detected but OPENROUTER_API_KEY is not set"
            )
        return key
    # Default OpenAI / Together / vLLM / Modal — accept OpenAI key, fall back
    # to OpenRouter (some users serve via OpenRouter without setting the env).
    # ANTHROPIC_API_KEY is intentionally NOT considered: it is incompatible
    # with OpenAI-format endpoints and forwarding it would leak the credential
    # to a non-Anthropic backend.
    key = os.environ.get("OPENAI_API_KEY") or os.environ.get("OPENROUTER_API_KEY") or ""
    if not key:
        raise RuntimeError(
            "No OpenAI-compatible API key found. Set OPENAI_API_KEY (default) "
            "or OPENROUTER_API_KEY."
        )
    return key


def _resolve_base_url(model: str, explicit: Optional[str] = None) -> Optional[str]:
    if explicit:
        return explicit
    if os.environ.get("CHAIN_DET_BASE_URL"):
        return os.environ["CHAIN_DET_BASE_URL"]
    # Default to OpenRouter if OPENROUTER_API_KEY is set and OpenAI key isn't
    if os.environ.get("OPENROUTER_API_KEY") and not os.environ.get("OPENAI_API_KEY"):
        return "https://openrouter.ai/api/v1"
    # Heuristic for openrouter-style model identifiers (e.g.
    # "qwen/qwen-2.5-72b-instruct"). The earlier loose `/` check was an SSRF
    # vector if `model` was attacker-influenced — a model string like
    # "evil/path" would have routed the user's OPENROUTER_API_KEY to an
    # arbitrary host (the host is `openrouter.ai` here so not literally SSRF,
    # but the same heuristic applied to a future provider list could be).
    # Restrict to a vetted vendor-prefix allowlist instead.
    if model.startswith(_OPENROUTER_VENDOR_PREFIXES):
        return "https://openrouter.ai/api/v1"
    return None  # default OpenAI


async def run_one_replay(
    client: AsyncOpenAI,
    model: str,
    system: str,
    user: str,
    tools: list,
    *,
    temperature: float = 0.0,
    max_tool_calls: int = 10,
    max_tokens: int = 1024,
    stub_tool_response,
) -> dict:
    """Run one agent replay; collect tool-call sequence + final answer.

    Contract:
      - Each tool call emitted by the model is recorded in `tool_call_sequence`
        in arrival order, even if the same assistant message contains both
        regular tool calls and a final_answer call (the receipt is complete).
      - Malformed tool-call argument JSON is recorded with an explicit
        `args_malformed=True` marker; the chain-attestation receipt does NOT
        silently coerce malformed args to `{}`.
      - error_category strings are scrubbed of API keys / bearer tokens before
        return (defense-in-depth against credential leaks via Receipt logs).
      - The agent loop runs at most `max_tool_calls` *iterations* (full
        chat-completion turns); the historical "+4" magic constant is removed.
    """
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": user}]
    tool_call_sequence: list[dict] = []
    final_answer: Optional[str] = None
    error_category: Optional[str] = None
    rationale_chunks: list[str] = []

    for _ in range(max_tool_calls):
        try:
            resp = await client.chat.completions.create(
                model=model,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                tool_choice="auto",
            )
        except Exception as e:  # noqa: BLE001 — exception class varies by provider
            # Scrub FIRST, then truncate. The reverse order (truncate → scrub)
            # let a long URL prefix push API keys past the 160-char window
            # and into the Receipt unredacted (round-3 review finding).
            scrubbed = _scrub_secrets(f"api_error: {type(e).__name__}: {e!s}")
            error_category = scrubbed[:240]
            break

        # Defensive: providers can return empty `choices` on rate-limit or
        # content-policy hits; surface as a clean error rather than IndexError.
        if not getattr(resp, "choices", None):
            error_category = "empty_choices"
            break

        msg = resp.choices[0].message
        if msg.content:
            rationale_chunks.append(msg.content)

        if not msg.tool_calls:
            # Model emitted text without tool call — record as last-turn rationale
            break

        # Process each tool call. Two parallel records:
        #   tool_call_sequence  — the attestation receipt: records EVERY tool
        #     call the model emitted, including those after a mid-turn
        #     `final_answer`, so receipts are complete (no evidence erasure).
        #   processed_tool_calls — the conversation-history truncation: only
        #     calls processed up to (and including) the first `final_answer`,
        #     so the assistant-message we append below has matching tool_call
        #     responses (no unmatched tool_call_ids in `messages`).
        # The two diverge only when `final_answer` appears mid-turn — a
        # provider-rare event that our fix-bundle now handles correctly on
        # both axes (receipt completeness AND conversation well-formedness).
        terminal = False
        processed_tool_calls: list[dict] = []  # for assistant_msg.tool_calls
        tool_response_messages: list[dict] = []  # to extend `messages` after
        terminal_seen_at = -1  # index in msg.tool_calls when final_answer fired
        for tc_idx, tc in enumerate(msg.tool_calls):
            args_malformed = False
            raw_args = tc.function.arguments or "{}"
            try:
                args = json.loads(raw_args)
                if not isinstance(args, dict):
                    # OpenAI tool-call args must be a JSON object; non-object
                    # is itself an attestation-relevant anomaly.
                    args_malformed = True
                    args = {"_raw_value_repr": repr(args)[:120]}
            except json.JSONDecodeError:
                args_malformed = True
                args = {
                    "_raw_arguments_len": len(raw_args),
                    "_raw_arguments_head": raw_args[:80],
                }

            entry: dict = {
                "name": tc.function.name,
                "args": args,
                "tool_call_id": tc.id,
            }
            if args_malformed:
                # Surfaced explicitly so a hostile/buggy model cannot erase
                # argument evidence by emitting malformed JSON. Receipts
                # MUST flag this rather than silently coerce to `{}`.
                entry["args_malformed"] = True
                # Stash a sha256 of the full raw args for forensic recovery
                # (the args themselves are stored truncated for size, but the
                # hash lets a reviewer prove the original payload).
                import hashlib
                entry["raw_arguments_sha256"] = hashlib.sha256(
                    raw_args.encode("utf-8")
                ).hexdigest()

            # Mark trailing tool calls (after mid-turn final_answer) so the
            # receipt distinguishes "model emitted but harness skipped" from
            # "model emitted and harness processed". This preserves receipt
            # completeness without confusing the conversation-history layer.
            if terminal:
                entry["after_terminal"] = True
            tool_call_sequence.append(entry)

            if not terminal:
                # Conversation-history layer: only include calls before/at
                # the first final_answer. After-terminal calls are recorded
                # in tool_call_sequence (above) but NOT in
                # processed_tool_calls or tool_response_messages.
                processed_tool_calls.append({
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                })

            if tc.function.name == "final_answer" and not terminal:
                final_answer = args.get("answer", "") if not args_malformed else ""
                terminal = True
                terminal_seen_at = tc_idx
                # IMPORTANT: don't break — continue iterating so trailing
                # tool calls in this same message are still recorded in
                # tool_call_sequence (with after_terminal=True). The
                # well-formed conversation history is maintained because
                # the `if not terminal:` branch above stops appending to
                # processed_tool_calls / tool_response_messages.
                continue

            # Defer the stub response: stage it locally, append to `messages`
            # after we finalize the assistant message. This way, if
            # `stub_tool_response` raises mid-loop, we have not partially
            # appended to `messages`. We also wrap the call so a raised
            # KeyError (e.g., unknown tool name) becomes a clean
            # `error_category` rather than propagating out of run_one_replay
            # with `messages` in a half-mutated state.
            try:
                stub = stub_tool_response(tc.function.name)
            except Exception as exc:  # noqa: BLE001 — recover any handler bug
                error_category = _scrub_secrets(
                    f"stub_handler_error: {type(exc).__name__}: {exc!s}"
                )[:240]
                terminal = True  # bail out of the agent loop cleanly
                break
            tool_response_messages.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": stub,
            })

        # Append assistant message with ONLY the tool_calls we processed,
        # then append the corresponding tool-response messages. The
        # conversation history is well-formed even when final_answer appears
        # mid-turn (we drop trailing tool calls cleanly).
        if processed_tool_calls:
            messages.append({
                "role": "assistant",
                "content": msg.content or "",
                "tool_calls": processed_tool_calls,
            })
            messages.extend(tool_response_messages)

        if terminal:
            break

    return {
        "tool_call_sequence": tool_call_sequence,
        "final_answer": final_answer,
        "rationale": "\n".join(rationale_chunks),
        "n_tool_calls": len(tool_call_sequence),
        "error_category": error_category,
    }


async def run_query(
    client: AsyncOpenAI,
    model: str,
    query: dict,
    *,
    n_replays: int,
    temperature: float,
    system_prompt: str,
    tools: list,
    stub_tool_response,
    concurrency: int = 5,
) -> list[dict]:
    """Run N replays of a single query, collecting tool-call sequences.

    Uses `asyncio.gather(..., return_exceptions=True)` so a single replay's
    failure does not cancel the entire batch; failed replays are recorded
    with an explicit `error_category` field per the run_one_replay contract.
    """
    from .queries import kb_summary_to_prompt
    user = (
        f"{kb_summary_to_prompt(query)}\n\n"
        f"Question: {query['question']}\n\n"
        f"Use the primitive tools to compute the answer; then call final_answer "
        f"with just the value."
    )

    sem = asyncio.Semaphore(concurrency)

    async def one(idx: int):
        async with sem:
            r = await run_one_replay(
                client, model, system_prompt, user, tools,
                temperature=temperature,
                stub_tool_response=stub_tool_response,
            )
            r["query_id"] = query["query_id"]
            r["query_type"] = query["query_type"]
            r["run_idx"] = idx
            return r

    results = await asyncio.gather(
        *[one(i) for i in range(n_replays)],
        return_exceptions=True,
    )
    # Convert any exception placeholders into structured error rows so that
    # downstream metrics see a consistent dict shape (n_tool_calls=0,
    # error_category set) instead of an Exception object.
    cleaned: list[dict] = []
    for i, r in enumerate(results):
        if isinstance(r, BaseException):
            cleaned.append({
                "query_id": query["query_id"],
                "query_type": query["query_type"],
                "run_idx": i,
                "tool_call_sequence": [],
                "final_answer": None,
                "rationale": "",
                "n_tool_calls": 0,
                "error_category": _scrub_secrets(
                    f"replay_exception: {type(r).__name__}: {str(r)[:160]}"
                ),
            })
        else:
            cleaned.append(r)
    return cleaned


def make_client(base_url: Optional[str] = None, api_key: Optional[str] = None,
                timeout: float = 60.0) -> AsyncOpenAI:
    return AsyncOpenAI(
        api_key=_resolve_api_key("", api_key),
        base_url=_resolve_base_url("", base_url),
        timeout=timeout,
    )
