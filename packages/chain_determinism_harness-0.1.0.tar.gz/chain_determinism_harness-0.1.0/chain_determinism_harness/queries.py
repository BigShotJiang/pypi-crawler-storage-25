"""Embedded held-out OOD queries for chain-determinism measurement.

A 10-query subset of the Sigma-registry held-out OOD benchmark used in the
companion paper. The subset spans **8 distinct query_type values** drawn from
the paper's compositional-bounded query family (`author_productivity`,
`busiest_window`, `deepest_chain`, `orphaned_sources`, `earliest_contributor`,
`longest_gap`, `retract_impact`, `term_leaderboard`). The subset is NOT
labeled by depth tier — earlier docstrings claimed `depth-1/2/3/4` reference
chains, which was a documentation bug; query difficulty in the full
benchmark is characterized by the matched-N stratum used at evaluation
time, not by a pre-assigned depth bucket.

Subset published under CC-BY-4.0 along with the chain-determinism-bench-v1
dataset. The full 40-query held-out set is at
https://github.com/Cruxia-AI/chain-determinism-harness/tree/main/bench
(file `data/phase_1a.jsonl`, fields `query_id` and `kb_id`).

Public surface:
    QUERIES                  : tuple[Mapping, ...]   — read-only canonical query set
    kb_summary_to_prompt(q)  : str                    — build the KB-summary prefix

Both are designed to be safely import-shared across processes; the public
QUERIES tuple is immutable at the top level (callers cannot accidentally
.append() / corrupt it via the module).
"""
from __future__ import annotations

import re
from types import MappingProxyType
from typing import Mapping


_QUERIES_RAW: list[dict] = [
    {
        "query_id": "heldout::heldout_xenobiology_taxonomy_00::author_productivity::endolithic_autotroph_order",
        "kb_id": "heldout_xenobiology_taxonomy_00",
        "target_term": "endolithic_autotroph_order",
        "query_type": "author_productivity",
        "question": "Of all non-retracted source entries for term 'endolithic_autotroph_order', which author contributed the most entries? Tie-breaking: alphabetical (lowercase) on author name. Answer with a single author name.",
    },
    {
        "query_id": "heldout::heldout_xenobiology_taxonomy_00::busiest_window::psychrotolerant_genus_revision",
        "kb_id": "heldout_xenobiology_taxonomy_00",
        "target_term": "psychrotolerant_genus_revision",
        "query_type": "busiest_window",
        "question": "What 30-day window (closed interval, [start_date, start_date + 29 days]) contains the most non-retracted source entries about term 'psychrotolerant_genus_revision'? Tie-breaking: earliest start_date wins. Answer with the start_date in YYYY-MM-DD format.",
    },
    {
        "query_id": "heldout::heldout_xenobiology_taxonomy_00::deepest_chain::thermoacidophile_kingdom_placement",
        "kb_id": "heldout_xenobiology_taxonomy_00",
        "target_term": "thermoacidophile_kingdom_placement",
        "query_type": "deepest_chain",
        "question": "What is the longest REVISES chain (number of revising edges; a single source entry with no REVISES has depth 0) for any source entry about term 'thermoacidophile_kingdom_placement'? Answer with a non-negative integer.",
    },
    {
        "query_id": "heldout::heldout_xenobiology_taxonomy_00::orphaned_sources::barophilic_family_reassignment",
        "kb_id": "heldout_xenobiology_taxonomy_00",
        "target_term": "barophilic_family_reassignment",
        "query_type": "orphaned_sources",
        "question": "How many source entries about term 'barophilic_family_reassignment' are non-retracted AND have no successor REVISES (i.e., are current heads)? Answer with a non-negative integer.",
    },
    {
        "query_id": "heldout::heldout_quantum_nebula_catalog_00::earliest_contributor::nebula365",
        "kb_id": "heldout_quantum_nebula_catalog_00",
        # Renamed from bare "365" — round-1 review flagged the bare-integer
        # target_term as ambiguous / suspicious. The renamed value is
        # disambiguated for downstream tooling and audit; the underlying
        # benchmark KB still resolves it correctly.
        "target_term": "nebula365",
        "query_type": "earliest_contributor",
        "question": "Who was the first author (by ascending timestamp; tie-break: alphabetical lowercase on author name) to contribute a non-retracted source entry about term 'nebula365'? Answer with a single author name.",
    },
    {
        "query_id": "heldout::heldout_quantum_nebula_catalog_00::longest_gap::nebula_42",
        "kb_id": "heldout_quantum_nebula_catalog_00",
        "target_term": "nebula_42",
        "query_type": "longest_gap",
        "question": "What is the longest gap, in whole days, between consecutive non-retracted source entries about term 'nebula_42' (sorted by ascending timestamp)? Day-counting: floor((later - earlier).total_seconds() / 86400). Answer with a non-negative integer.",
    },
    {
        "query_id": "heldout::heldout_quantum_nebula_catalog_00::retract_impact::dark_matter_residual",
        "kb_id": "heldout_quantum_nebula_catalog_00",
        "target_term": "dark_matter_residual",
        "query_type": "retract_impact",
        "question": "How many source entries about term 'dark_matter_residual' have been retracted (i.e., have a non-null retracted_at timestamp)? Answer with a non-negative integer.",
    },
    {
        "query_id": "heldout::heldout_synthetic_biology_index_00::term_leaderboard::CRISPR_v2",
        "kb_id": "heldout_synthetic_biology_index_00",
        "target_term": "CRISPR_v2",
        "query_type": "term_leaderboard",
        "question": "Among non-retracted source entries about term 'CRISPR_v2', which 3 authors contributed the most entries? Tie-breaking on count: alphabetical lowercase on author name. Answer as a comma-separated list of 3 author names ordered by contribution count descending (then alphabetical within ties).",
    },
    {
        "query_id": "heldout::heldout_synthetic_biology_index_00::author_productivity::ribozyme_rationale",
        "kb_id": "heldout_synthetic_biology_index_00",
        "target_term": "ribozyme_rationale",
        "query_type": "author_productivity",
        "question": "Of all non-retracted source entries for term 'ribozyme_rationale', which author contributed the most entries? Tie-breaking: alphabetical (lowercase) on author name. Answer with a single author name.",
    },
    {
        "query_id": "heldout::heldout_synthetic_biology_index_00::deepest_chain::orthogonal_polymerase",
        "kb_id": "heldout_synthetic_biology_index_00",
        "target_term": "orthogonal_polymerase",
        "query_type": "deepest_chain",
        "question": "What is the longest REVISES chain (number of revising edges; a single source entry with no REVISES has depth 0) for any source entry about term 'orthogonal_polymerase'? Answer with a non-negative integer.",
    },
]


# Validate uniqueness + schema at import-time so silent data drift cannot ship
# unnoticed. Earlier the QUERIES list had no invariant guards.
def _validate_queries(qs: list[dict]) -> None:
    required_keys = {"query_id", "kb_id", "target_term", "query_type", "question"}
    seen_ids: set[str] = set()
    valid_query_types = {
        "author_productivity", "busiest_window", "deepest_chain",
        "orphaned_sources", "earliest_contributor", "longest_gap",
        "retract_impact", "term_leaderboard",
    }
    for i, q in enumerate(qs):
        missing = required_keys - q.keys()
        if missing:
            raise ValueError(
                f"queries.py: entry index {i} is missing required keys: {missing}"
            )
        if q["query_id"] in seen_ids:
            raise ValueError(
                f"queries.py: duplicate query_id at index {i}: {q['query_id']!r}"
            )
        seen_ids.add(q["query_id"])
        if q["query_type"] not in valid_query_types:
            raise ValueError(
                f"queries.py: invalid query_type {q['query_type']!r} at index {i}; "
                f"must be one of {sorted(valid_query_types)}"
            )
        # query_id format: heldout::<kb_id>::<query_type>::<target_term>
        expected = f"heldout::{q['kb_id']}::{q['query_type']}::{q['target_term']}"
        if q["query_id"] != expected:
            raise ValueError(
                f"queries.py: query_id mismatch at index {i}: "
                f"got {q['query_id']!r}, expected {expected!r}"
            )


_validate_queries(_QUERIES_RAW)


# Public name: tuple of read-only mappings. Top-level immutability protects
# against accidental .append() / mutation; MappingProxyType protects against
# in-place dict mutation. Round-1 review finding: a downstream consumer that
# does `q['answer'] = ...` previously corrupted shared benchmark state.
QUERIES: tuple[Mapping, ...] = tuple(
    MappingProxyType(dict(q)) for q in _QUERIES_RAW
)


# kb_id and target_term must contain only safe characters (no newlines, no
# backticks, no control chars) to neutralize the prompt-injection vector
# round-1 review flagged. We validate the hard-coded queries at import; the
# kb_summary_to_prompt() guard below enforces the same on any externally-
# supplied query dict.
_KB_ID_RE = re.compile(r"^[A-Za-z0-9_\-:.]{1,128}$")
_TARGET_TERM_RE = re.compile(r"^[A-Za-z0-9_\-:.]{1,128}$")


def kb_summary_to_prompt(q: Mapping) -> str:
    """Build the KB summary prefix sent to the model.

    The model receives the kb_id and target_term verbatim. We validate both
    against a strict character class to prevent prompt-injection via crafted
    KB fixtures (e.g., newline + new tool instruction). If validation fails,
    we raise ValueError rather than emit an injectable string silently.

    Args:
        q: a query mapping with at minimum 'kb_id'. 'target_term' is optional.

    Raises:
        TypeError: if `q` is not a mapping.
        ValueError: if required keys missing or kb_id/target_term contain
                    characters outside the safe class.
    """
    if not hasattr(q, "get") or not hasattr(q, "__getitem__"):
        raise TypeError(
            f"kb_summary_to_prompt: q must be a mapping, got {type(q).__name__!r}"
        )
    kb_id = q.get("kb_id")
    if kb_id is None:
        raise ValueError("kb_summary_to_prompt: q is missing required 'kb_id' key")
    if not isinstance(kb_id, str) or not _KB_ID_RE.match(kb_id):
        raise ValueError(
            f"kb_summary_to_prompt: kb_id {kb_id!r} fails safe-charset validation; "
            f"must match {_KB_ID_RE.pattern}"
        )
    target_term = q.get("target_term")
    if target_term is not None:
        if not isinstance(target_term, str) or not _TARGET_TERM_RE.match(target_term):
            raise ValueError(
                f"kb_summary_to_prompt: target_term {target_term!r} fails safe-charset "
                f"validation; must match {_TARGET_TERM_RE.pattern}"
            )

    parts = [
        f"# Knowledge base id: {kb_id}",
        "(Use tool calls like `all_beliefs()` or `filter_beliefs(term=...)` "
        "to inspect contents.)",
    ]
    if target_term:
        parts.append(f"Target term mentioned in the question: '{target_term}'")
    return "\n".join(parts)
