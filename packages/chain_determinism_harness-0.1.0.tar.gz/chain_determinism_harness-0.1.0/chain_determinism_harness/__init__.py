"""chain-determinism-harness — measure trace-structural consistency across replays.

Companion harness for the *Chain-Divergence: A Cross-Vendor Benchmark and
Mechanism Probe for Replay-Attestable LLM Agents* paper. Evaluates any
OpenAI-compatible LLM endpoint for chain-divergence: the fraction of queries
on which N replays produce non-byte-identical tool-call sequences.

Supported endpoints (via OpenAI-compatible HTTP API only):
- OpenAI direct (https://api.openai.com/v1)
- OpenRouter (https://openrouter.ai/api/v1)
- Together AI, Fireworks, Modal vLLM, local vLLM, etc. (via --base-url)

Note: this harness does NOT use ANTHROPIC_API_KEY. Anthropic keys are not
OpenAI-compatible; use Anthropic's models via OpenRouter (which IS supported)
or via a proxy that translates the Anthropic native protocol.

Quickstart::

    pip install git+https://github.com/Cruxia-AI/chain-determinism-harness.git
    export OPENAI_API_KEY=sk-...   # or OPENROUTER_API_KEY=sk-or-...

    python -m chain_determinism_harness eval \\
        --model gpt-4.1 \\
        --n-queries 5 --n-replays 10

Outputs chain-divergence rate with Wilson 95% CI.

Requires Python 3.10+.
"""
from __future__ import annotations

import sys

# Surface a clean error before any submodule imports if the runtime is too old
# (round-1 review noted: paper claims reference-grade reproducibility but the
# harness silently misbehaves on Python <3.10).
if sys.version_info < (3, 10):
    raise RuntimeError(
        f"chain-determinism-harness requires Python >=3.10; "
        f"got {sys.version_info.major}.{sys.version_info.minor}."
    )


# Single source of truth for the version string. We try `importlib.metadata`
# (the installed-package version) and fall back to the literal below for
# editable / source installs.
try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("chain-determinism-harness")
except Exception:  # noqa: BLE001
    # Editable install / source tree without dist-info available.
    __version__ = "0.1.0"


# Explicit public API surface (round-1 review: prior __init__ had no __all__,
# letting every transitively-imported name leak into the public namespace).
from .metrics import (
    chain_divergence_rate,
    wilson_ci,
    seq_full,
    format_summary,
)
from .queries import QUERIES, kb_summary_to_prompt
from .tools import SYSTEM_PROMPT, TOOL_SCHEMAS_OPENAI, stub_tool_response
from .client import make_client, run_one_replay, run_query

__all__ = [
    # Version
    "__version__",
    # Metrics (the load-bearing measurement primitives)
    "chain_divergence_rate",
    "wilson_ci",
    "seq_full",
    "format_summary",
    # Benchmark contents
    "QUERIES",
    "kb_summary_to_prompt",
    "SYSTEM_PROMPT",
    "TOOL_SCHEMAS_OPENAI",
    "stub_tool_response",
    # Client / agent loop
    "make_client",
    "run_one_replay",
    "run_query",
]
