"""Tests for `chain_determinism_harness.client` — security-relevant invariants.

These tests lock in the round-1 / round-2 / round-3 / round-4 stringent-review
fixes so the regressions cannot silently come back. Where possible we test
without needing a live API endpoint by introspecting the resolver / scrub
helpers directly.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import patch

_HARNESS_ROOT = Path(__file__).resolve().parent.parent
if str(_HARNESS_ROOT) not in sys.path:
    sys.path.insert(0, str(_HARNESS_ROOT))

from chain_determinism_harness.client import (  # noqa: E402
    _OPENROUTER_VENDOR_PREFIXES,
    _resolve_api_key,
    _resolve_base_url,
    _scrub_secrets,
)


# ---------------------------------------------------------------------------
# Secret scrubbing
# ---------------------------------------------------------------------------

def test_scrub_openai_sk_key():
    assert "sk-<REDACTED>" in _scrub_secrets("error: sk-1234567890abcdefghij")
    assert "1234567890abcdefghij" not in _scrub_secrets("error: sk-1234567890abcdefghij")


def test_scrub_sk_or_key():
    text = "error: sk-or-1234567890abcdefghij at /api/v1"
    out = _scrub_secrets(text)
    assert "1234567890abcdefghij" not in out


def test_scrub_jwt_bearer():
    """JWT-style Bearer token scrubbing (round-2 fix)."""
    text = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.body.sig"
    out = _scrub_secrets(text)
    assert "Bearer <REDACTED>" in out
    assert "eyJhbGciOiJI" not in out


def test_scrub_authorization_header():
    text = "request failed: Authorization: Bearer abc.def.ghi was rejected"
    out = _scrub_secrets(text)
    assert "abc.def.ghi" not in out


def test_scrub_huggingface_pat():
    text = "Token validation: hf_abcdef1234567890abcdef"
    out = _scrub_secrets(text)
    assert "hf_<REDACTED>" in out
    assert "abcdef1234567890abcdef" not in out


def test_scrub_github_pat():
    text = "remote: ghp_1234567890abcdefghij1234567890"
    out = _scrub_secrets(text)
    assert "1234567890abcdefghij" not in out


def test_scrub_does_not_mangle_normal_text():
    """Defensive check: scrubber must not eat legitimate non-secret text."""
    text = "error connecting to api.example.com on port 443"
    out = _scrub_secrets(text)
    assert "api.example.com" in out
    assert "443" in out


# ---------------------------------------------------------------------------
# OpenRouter routing — SSRF heuristic restriction (round-2 fix)
# ---------------------------------------------------------------------------

def test_openrouter_routing_for_known_prefix():
    """Models in the vetted vendor-prefix allowlist route to OpenRouter."""
    assert _resolve_base_url("qwen/qwen-2.5-72b-instruct") == "https://openrouter.ai/api/v1"
    assert _resolve_base_url("meta-llama/llama-3.3-70b-instruct") == "https://openrouter.ai/api/v1"
    assert _resolve_base_url("01-ai/yi-1.5-34b-chat") == "https://openrouter.ai/api/v1"


def test_openrouter_routing_rejects_unknown_path():
    """Models NOT in the allowlist do NOT trigger OpenRouter routing.
    Earlier the loose `/`-in-model heuristic accepted any model path,
    creating an SSRF-shaped bug if `model` was attacker-controlled."""
    assert _resolve_base_url("evil/path") is None
    assert _resolve_base_url("foo/bar") is None
    assert _resolve_base_url("../../etc/passwd") is None


def test_openai_models_default_to_openai():
    """OpenAI direct models / fine-tunes stay on the OpenAI default."""
    assert _resolve_base_url("gpt-4.1") is None
    assert _resolve_base_url("gpt-4-turbo") is None
    assert _resolve_base_url("ft:gpt-4o:org:suffix") is None
    assert _resolve_base_url("o1") is None
    assert _resolve_base_url("o3") is None


def test_openrouter_prefix_list_is_a_tuple():
    """The allowlist must be a tuple (immutable). Runtime mutation would
    silently broaden the SSRF guard."""
    assert isinstance(_OPENROUTER_VENDOR_PREFIXES, tuple)


# ---------------------------------------------------------------------------
# Credential resolution — provider-aware (round-2 fix)
# ---------------------------------------------------------------------------

def test_explicit_key_passes_through():
    key = _resolve_api_key("anything", explicit="sk-explicit-123")
    assert key == "sk-explicit-123"


def test_no_keys_set_raises():
    """If no OPENAI/OPENROUTER key is set AND no explicit key is supplied,
    raise rather than fall back to ANTHROPIC_API_KEY (which is the round-1
    cross-vendor credential leak class)."""
    import pytest
    env_clear = {
        "OPENAI_API_KEY": "",
        "OPENROUTER_API_KEY": "",
        "ANTHROPIC_API_KEY": "sk-ant-1234567890",  # set but should NOT be used
        "CHAIN_DET_BASE_URL": "",
    }
    with patch.dict(os.environ, env_clear, clear=False):
        with pytest.raises(RuntimeError, match="OpenAI-compatible"):
            _resolve_api_key("")


def test_anthropic_key_alone_is_rejected():
    """Same as above but more explicit: ANTHROPIC_API_KEY present, no others.
    The harness must NOT route the Anthropic key to an OpenAI-compatible
    endpoint."""
    import pytest
    env = {
        "OPENAI_API_KEY": "",
        "OPENROUTER_API_KEY": "",
        "ANTHROPIC_API_KEY": "sk-ant-foo",
        "CHAIN_DET_BASE_URL": "",
    }
    with patch.dict(os.environ, env, clear=False):
        with pytest.raises(RuntimeError):
            _resolve_api_key("")


def test_openai_key_used_when_set():
    env = {
        "OPENAI_API_KEY": "sk-openai-foo",
        "OPENROUTER_API_KEY": "",
        "CHAIN_DET_BASE_URL": "",
    }
    with patch.dict(os.environ, env, clear=False):
        assert _resolve_api_key("") == "sk-openai-foo"


def test_openrouter_key_used_when_only_set():
    env = {
        "OPENAI_API_KEY": "",
        "OPENROUTER_API_KEY": "sk-or-foo",
        "CHAIN_DET_BASE_URL": "",
    }
    with patch.dict(os.environ, env, clear=False):
        assert _resolve_api_key("") == "sk-or-foo"


def test_explicit_openrouter_base_url_uses_openrouter_key():
    env = {
        "OPENAI_API_KEY": "sk-openai",
        "OPENROUTER_API_KEY": "sk-or-correct",
        "CHAIN_DET_BASE_URL": "https://openrouter.ai/api/v1",
    }
    with patch.dict(os.environ, env, clear=False):
        # Should pick OpenRouter key based on base URL — even though
        # OPENAI_API_KEY is also set.
        assert _resolve_api_key("") == "sk-or-correct"


def test_explicit_openrouter_base_url_no_key_raises():
    import pytest
    env = {
        "OPENAI_API_KEY": "",
        "OPENROUTER_API_KEY": "",
        "CHAIN_DET_BASE_URL": "https://openrouter.ai/api/v1",
    }
    with patch.dict(os.environ, env, clear=False):
        with pytest.raises(RuntimeError, match="OPENROUTER_API_KEY"):
            _resolve_api_key("")


# ---------------------------------------------------------------------------
# Standalone runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    fns = [k for k in globals() if k.startswith("test_") and callable(globals()[k])]
    fns.sort()
    fail = 0
    for name in fns:
        fn = globals()[name]
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as e:
            print(f"  FAIL  {name}: {e}")
            fail += 1
        except Exception as e:
            print(f"  ERROR {name}: {type(e).__name__}: {e}")
            fail += 1
    print(f"\n  {len(fns) - fail}/{len(fns)} tests passed.")
    sys.exit(0 if fail == 0 else 1)
