"""Tests for `chain_determinism_harness.metrics`.

The earlier version of this file was flagged as too thin in the round-1
code review:
  - Numeric tolerance bands on `wilson_ci` were wide enough to pass for
    multiple incorrect formulations.
  - `seq_full` invariants were tested only at the happy-path level, not
    against the type-collision class of bugs that exists in any naive
    implementation (1 vs True vs 1.0 vs "1" collapse).
  - `chain_divergence_rate` boundary cases (min_success exact boundary,
    multiple query_ids, all-error groups, malformed input) were untested.

This rewrite addresses all three. Run via either pytest or
`python tests/test_metrics.py`.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

# Path mutation kept for `python tests/...` invocation; pytest+pip-install-e
# does not need it. Round-1 review noted the path mutation as anti-pattern;
# we keep it inside an `if __name__` guard would actually break the unittest
# runner, so we leave it here but minimize its scope.
_HARNESS_ROOT = Path(__file__).resolve().parent.parent
if str(_HARNESS_ROOT) not in sys.path:
    sys.path.insert(0, str(_HARNESS_ROOT))

from chain_determinism_harness.metrics import (  # noqa: E402
    _canonical_scalar,
    _to_hashable,
    chain_divergence_rate,
    seq_full,
    wilson_ci,
)


# ---------------------------------------------------------------------------
# seq_full — type-collision invariants (the round-2/3 critical bug class)
# ---------------------------------------------------------------------------

def test_seq_full_byte_identical():
    a = [{"name": "filter_beliefs", "args": {"term": "x"}}]
    b = [{"name": "filter_beliefs", "args": {"term": "x"}}]
    assert seq_full(a) == seq_full(b)


def test_seq_full_arg_order_invariant():
    """Args dict ordering must NOT affect the hash (we sort keys)."""
    a = [{"name": "filter_author", "args": {"in": "v1", "author": "alice"}}]
    b = [{"name": "filter_author", "args": {"author": "alice", "in": "v1"}}]
    assert seq_full(a) == seq_full(b)


def test_seq_full_different_args_diverge():
    a = [{"name": "filter_beliefs", "args": {"term": "x"}}]
    b = [{"name": "filter_beliefs", "args": {"term": "y"}}]
    assert seq_full(a) != seq_full(b)


def test_seq_full_different_op_diverge():
    a = [{"name": "filter_beliefs", "args": {"term": "x"}}]
    b = [{"name": "all_beliefs", "args": {}}]
    assert seq_full(a) != seq_full(b)


def test_seq_full_int_vs_bool_distinct():
    """1 and True must produce DIFFERENT keys (Python equality collapses
    them; the metric must not)."""
    a = [{"name": "f", "args": {"x": 1}}]
    b = [{"name": "f", "args": {"x": True}}]
    assert seq_full(a) != seq_full(b)


def test_seq_full_int_vs_float_distinct():
    a = [{"name": "f", "args": {"x": 1}}]
    b = [{"name": "f", "args": {"x": 1.0}}]
    assert seq_full(a) != seq_full(b)


def test_seq_full_int_vs_string_distinct():
    a = [{"name": "f", "args": {"x": 1}}]
    b = [{"name": "f", "args": {"x": "1"}}]
    assert seq_full(a) != seq_full(b)


def test_seq_full_falsey_distinct_from_empty_dict():
    """0, "", [], False, None must NOT collapse to {} the way the prior
    `or {}` coercion did."""
    keys = set()
    for v in [0, "", [], False, None, {}]:
        keys.add(seq_full([{"name": "f", "args": {"x": v}}]))
    # All 6 should be distinct (or at most fewer if the test setup itself
    # collapses some — but we want at least 5 distinct because all are
    # type-tagged differently).
    assert len(keys) >= 5, f"only {len(keys)} distinct keys among 6 falsey values"


def test_seq_full_absent_args_vs_empty_dict():
    """A run with `args` absent should be distinguishable from `args={}`."""
    a = [{"name": "f", "args": {}}]
    b = [{"name": "f"}]
    assert seq_full(a) != seq_full(b)


def test_seq_full_nan_rejected():
    import pytest
    with pytest.raises(ValueError):
        seq_full([{"name": "f", "args": {"x": float("nan")}}])


def test_seq_full_inf_rejected():
    import pytest
    with pytest.raises(ValueError):
        seq_full([{"name": "f", "args": {"x": float("inf")}}])


def test_seq_full_tuple_rejected():
    """Tuples are NOT JSON-representable; reject explicitly."""
    import pytest
    with pytest.raises(TypeError):
        seq_full([{"name": "f", "args": {"x": (1, 2)}}])


def test_seq_full_non_string_dict_key_rejected():
    import pytest
    with pytest.raises(TypeError):
        seq_full([{"name": "f", "args": {1: "value"}}])


def test_seq_full_non_dict_sequence_element_rejected():
    import pytest
    with pytest.raises(TypeError):
        seq_full(["not a dict"])  # type: ignore[list-item]


# ---------------------------------------------------------------------------
# wilson_ci — exact comparisons against a manually verified reference
# ---------------------------------------------------------------------------

def _wilson_reference(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Standalone reference implementation, used to pin numeric tolerance.
    Independently derived; matches Wikipedia formulation of Wilson score."""
    if n == 0:
        return (None, None)  # type: ignore[return-value]
    p = k / n
    z2 = z * z
    denom = 1.0 + z2 / n
    center = (p + z2 / (2 * n)) / denom
    sqarg = max(0.0, p * (1 - p) / n + z2 / (4 * n * n))
    half = (z * math.sqrt(sqarg)) / denom
    return (max(0.0, center - half), min(1.0, center + half))


def test_wilson_ci_zero_sample():
    """n == 0 returns (None, None), NOT (0, 1)."""
    assert wilson_ci(0, 0) == (None, None)


def test_wilson_ci_invalid_inputs():
    import pytest
    with pytest.raises(ValueError):
        wilson_ci(-1, 5)
    with pytest.raises(ValueError):
        wilson_ci(0, -1)
    with pytest.raises(ValueError):
        wilson_ci(6, 5)  # k > n


def test_wilson_ci_extreme_p_no_sqrt_error():
    """At p=0 or p=1, p*(1-p) is exactly 0 and floating-point underflow
    might push the sqrt argument negative. The implementation must clamp."""
    lo, hi = wilson_ci(0, 5)
    assert lo is not None and hi is not None
    assert lo == 0.0
    lo, hi = wilson_ci(5, 5)
    assert lo is not None and hi is not None
    assert hi == 1.0


def test_wilson_ci_known_zero_of_forty():
    # paper §3.2 batch_invariant_proxy: 0/40, expect lo=0, hi ~= 0.088
    lo, hi = wilson_ci(0, 40)
    ref = _wilson_reference(0, 40)
    assert lo == ref[0]
    assert abs(hi - ref[1]) < 1e-9
    assert abs(hi - 0.0876) < 0.001


def test_wilson_ci_eleven_of_forty():
    # paper §3.2 baseline_all_on: 11/40, expect lo ~0.161, hi ~0.428
    lo, hi = wilson_ci(11, 40)
    ref = _wilson_reference(11, 40)
    assert abs(lo - ref[0]) < 1e-9
    assert abs(hi - ref[1]) < 1e-9
    assert abs(lo - 0.1605) < 0.001
    assert abs(hi - 0.4279) < 0.001


# ---------------------------------------------------------------------------
# chain_divergence_rate — boundary + contract behavior
# ---------------------------------------------------------------------------

def test_chain_divergence_rate_no_divergence():
    runs = [
        {"query_id": "q1", "tool_call_sequence":
            [{"name": "filter_beliefs", "args": {"term": "x"}},
             {"name": "count", "args": {"in": "v1"}}]}
        for _ in range(5)
    ]
    stats = chain_divergence_rate(runs)
    assert stats["n_diverged"] == 0
    assert stats["n_measurable"] == 1
    assert stats["divergence_rate"] == 0.0


def test_chain_divergence_rate_with_divergence_explicit():
    runs = (
        [{"query_id": "q1", "tool_call_sequence":
            [{"name": "filter_beliefs", "args": {"term": "x"}}]}
         for _ in range(3)]
        +
        [{"query_id": "q1", "tool_call_sequence":
            [{"name": "all_beliefs", "args": {}}]}
         for _ in range(2)]
    )
    stats = chain_divergence_rate(runs)
    # Round-2 review: previously this test only checked divergence_rate,
    # leaving n_measurable un-asserted. Now we lock down both.
    assert stats["n_measurable"] == 1
    assert stats["n_diverged"] == 1
    assert stats["divergence_rate"] == 1.0
    assert stats["per_query"][0]["status"] == "measurable"
    assert stats["per_query"][0]["n_unique_sequences"] == 2


def test_chain_divergence_rate_min_success_boundary():
    """Exact min_success boundary: 5 success runs is measurable, 4 isn't."""
    base_run = lambda: {"query_id": "q1", "tool_call_sequence":  # noqa: E731
                        [{"name": "all_beliefs", "args": {}}]}
    # 4 ok, 1 error → n_success=4, below default min_success=5
    runs_4 = [base_run() for _ in range(4)] + [
        {"query_id": "q1", "tool_call_sequence": [],
         "error_category": "api_error"}
    ]
    stats_4 = chain_divergence_rate(runs_4)
    assert stats_4["n_measurable"] == 0
    # 5 ok exactly → at boundary, measurable
    runs_5 = [base_run() for _ in range(5)]
    stats_5 = chain_divergence_rate(runs_5)
    assert stats_5["n_measurable"] == 1


def test_chain_divergence_rate_multiple_queries_stable_order():
    """Per-query output must be sorted by query_id for byte-stable output."""
    runs = (
        [{"query_id": "q_z", "tool_call_sequence": []} for _ in range(5)]
        + [{"query_id": "q_a", "tool_call_sequence": []} for _ in range(5)]
        + [{"query_id": "q_m", "tool_call_sequence": []} for _ in range(5)]
    )
    stats = chain_divergence_rate(runs)
    qids = [pq["query_id"] for pq in stats["per_query"]]
    assert qids == sorted(qids), f"per_query order not sorted: {qids}"


def test_chain_divergence_rate_missing_query_id_raises():
    """Missing query_id must NOT silently bucket under '?'."""
    import pytest
    runs = [{"tool_call_sequence": []}]  # no query_id
    with pytest.raises(ValueError, match="query_id"):
        chain_divergence_rate(runs)


def test_chain_divergence_rate_missing_tool_call_sequence_raises():
    import pytest
    runs = [{"query_id": "q1"} for _ in range(5)]  # no tool_call_sequence
    with pytest.raises(ValueError, match="tool_call_sequence"):
        chain_divergence_rate(runs)


def test_chain_divergence_rate_min_success_too_low_raises():
    import pytest
    runs = [{"query_id": "q1", "tool_call_sequence": []} for _ in range(5)]
    with pytest.raises(ValueError, match="min_success"):
        chain_divergence_rate(runs, min_success=1)


def test_chain_divergence_rate_excludes_errors():
    runs = (
        [{"query_id": "q1", "tool_call_sequence":
            [{"name": "filter_beliefs", "args": {"term": "x"}}]}
         for _ in range(4)]
        +
        [{"query_id": "q1", "tool_call_sequence": [],
          "error_category": "api_error"}
         for _ in range(5)]
    )
    stats = chain_divergence_rate(runs)
    assert stats["n_errors"] == 5
    assert stats["n_measurable"] == 0
    assert stats["per_query"][0]["status"] == "insufficient"


def test_chain_divergence_rate_no_measurable_returns_none_rate():
    """When n_measurable=0, divergence_rate must be None (not 0.0 paired
    with wilson_ci=(0,1) — that combination was the round-2 fix)."""
    runs = [{"query_id": "q1", "tool_call_sequence": [],
             "error_category": "api_error"} for _ in range(5)]
    stats = chain_divergence_rate(runs)
    assert stats["divergence_rate"] is None
    assert stats["wilson_ci_95"] == (None, None)


# ---------------------------------------------------------------------------
# Internal helpers — type-tag invariants
# ---------------------------------------------------------------------------

def test_canonical_scalar_distinct_tags():
    """All scalar types produce distinct type-tags."""
    tags = set()
    for v in [None, True, False, 0, 1, 1.0, 1.5, "", "0", "1"]:
        tags.add(_canonical_scalar(v)[0])
    # Expect tags: null, bool, int, float, str (5 distinct)
    assert tags == {"null", "bool", "int", "float", "str"}


def test_to_hashable_dict_vs_list_distinct():
    """A dict and a list-of-pairs that happen to look similar must produce
    DIFFERENT keys."""
    d = _to_hashable({"a": 1, "b": 2})
    l_ = _to_hashable([["a", 1], ["b", 2]])
    assert d != l_


# ---------------------------------------------------------------------------
# Standalone runner (no pytest needed for `python tests/test_metrics.py`)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    fns = sorted(k for k in dict(globals()).items()
                 if k[0].startswith("test_") and callable(k[1]))
    fns = [k for k in globals() if k.startswith("test_") and callable(globals()[k])]
    fns.sort()
    fail = 0
    for name in fns:
        fn = globals()[name]
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as e:
            print(f"  FAIL  {name}: {e}")
            fail += 1
        except Exception as e:
            print(f"  ERROR {name}: {type(e).__name__}: {e}")
            fail += 1
    print(f"\n  {len(fns) - fail}/{len(fns)} tests passed.")
    sys.exit(0 if fail == 0 else 1)
