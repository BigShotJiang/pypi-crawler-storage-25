"""Tests for `chain_determinism_harness.tools` — canonical JSON + immutability.

Locks in the round-2 + round-3 stringent-review fixes:
- TOOL_SCHEMAS_OPENAI is a tuple (top-level immutable)
- _STUB_RESPONSES_RAW is deep-frozen via recursive MappingProxyType
- stub_tool_response output is byte-stable canonical JSON
- final_answer is intentionally NOT stubbable
- Unknown tool names raise KeyError (no silent fallback)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

_HARNESS_ROOT = Path(__file__).resolve().parent.parent
if str(_HARNESS_ROOT) not in sys.path:
    sys.path.insert(0, str(_HARNESS_ROOT))

from chain_determinism_harness.tools import (  # noqa: E402
    SYSTEM_PROMPT,
    TOOL_SCHEMAS_OPENAI,
    _STUB_RESPONSES_RAW,
    stub_tool_response,
)


def test_tool_schemas_is_tuple():
    assert isinstance(TOOL_SCHEMAS_OPENAI, tuple)


def test_tool_schemas_count():
    assert len(TOOL_SCHEMAS_OPENAI) == 22  # 21 primitives + final_answer


def test_tool_schemas_includes_final_answer():
    names = {entry["function"]["name"] for entry in TOOL_SCHEMAS_OPENAI}
    assert "final_answer" in names


def test_tool_schemas_no_duplicates():
    names = [entry["function"]["name"] for entry in TOOL_SCHEMAS_OPENAI]
    assert len(names) == len(set(names))


def test_tool_schemas_mutation_raises():
    import pytest
    with pytest.raises(AttributeError):
        TOOL_SCHEMAS_OPENAI.append({})  # type: ignore[attr-defined]


def test_system_prompt_present():
    assert isinstance(SYSTEM_PROMPT, str)
    assert len(SYSTEM_PROMPT) > 100


def test_stub_dict_top_level_frozen():
    import pytest
    with pytest.raises(TypeError):
        _STUB_RESPONSES_RAW["count"] = {"kind": "evil"}  # type: ignore[index]


def test_stub_dict_inner_frozen():
    import pytest
    with pytest.raises(TypeError):
        _STUB_RESPONSES_RAW["count"]["kind"] = "string"  # type: ignore[index]


def test_stub_dict_nested_frozen():
    import pytest
    with pytest.raises(TypeError):
        _STUB_RESPONSES_RAW["group_by_count"]["items"]["alice"] = 999


def test_stub_dict_all_primitives_present():
    primitives = {
        entry["function"]["name"] for entry in TOOL_SCHEMAS_OPENAI
        if entry["function"]["name"] != "final_answer"
    }
    stubbed = set(_STUB_RESPONSES_RAW.keys())
    missing = primitives - stubbed
    extra = stubbed - primitives
    assert not missing, f"Missing stubs for: {missing}"
    assert not extra, f"Stubs for unknown primitives: {extra}"


def test_stub_returns_canonical_json():
    out = stub_tool_response("count")
    parsed = json.loads(out)
    assert ", " not in out, f"Extra space after comma in: {out!r}"
    assert json.dumps(parsed, sort_keys=True, separators=(",", ":")) == out


def test_stub_byte_stable_across_invocations():
    a = stub_tool_response("group_by_count")
    b = stub_tool_response("group_by_count")
    assert a == b


def test_stub_ascii_safe():
    for primitive in _STUB_RESPONSES_RAW.keys():
        out = stub_tool_response(primitive)
        assert all(ord(c) < 128 for c in out), f"Non-ASCII in {primitive} stub: {out!r}"


def test_stub_final_answer_raises():
    import pytest
    with pytest.raises(KeyError, match="final_answer"):
        stub_tool_response("final_answer")


def test_stub_unknown_tool_raises():
    import pytest
    with pytest.raises(KeyError):
        stub_tool_response("does_not_exist")


def test_stub_argmin_returns_source_id_shape():
    out = json.loads(stub_tool_response("argmin_by_timestamp"))
    assert out["kind"] == "string"
    assert out["value"].startswith("b"), f"Expected source_id-shape, got {out['value']!r}"


def test_stub_has_any_pairwise_diff_returns_bool():
    out = json.loads(stub_tool_response("has_any_pairwise_diff"))
    assert out["kind"] == "bool"
    assert isinstance(out["value"], bool)


def test_stub_pairwise_diff_attr_returns_list():
    out = json.loads(stub_tool_response("pairwise_diff_attr"))
    assert out["kind"] == "list"
    assert "values" in out


if __name__ == "__main__":
    fns = sorted(k for k in globals() if k.startswith("test_") and callable(globals()[k]))
    fail = 0
    for name in fns:
        fn = globals()[name]
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as e:
            print(f"  FAIL  {name}: {e}")
            fail += 1
        except Exception as e:
            print(f"  ERROR {name}: {type(e).__name__}: {e}")
            fail += 1
    print(f"\n  {len(fns) - fail}/{len(fns)} tests passed.")
    sys.exit(0 if fail == 0 else 1)
