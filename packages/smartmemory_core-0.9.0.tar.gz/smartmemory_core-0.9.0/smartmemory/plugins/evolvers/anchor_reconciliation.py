"""Anchor reconciliation evolver (CORE-MEMORY-DYNAMICS-1 M2a Slice C C.3).

Runs the existing ``AnchorDriftChecker`` against each active anchor's recent
observation window and decides whether to mark the anchor **stale**.
Auto-staling is deliberately gated behind a conservative combined threshold
because the drift checker measures keyword-overlap absence, not contradiction
confidence (see blueprint-m2a.md Decision 5 and Corrections row 3).

**Default behaviour: warning-only.** An anchor only transitions to
``anchor_status="stale"`` when BOTH:

1. The combined drift score (one anchor vs. all recent observations) is
   at or above ``drift_score_threshold`` (default 0.8); AND
2. At least ``min_contradictions`` individual observations *each* produce
   a per-observation drift score at or above the same threshold.

Anything weaker emits an ``anchor.drift.warning`` telemetry event via
``trace_span`` and leaves the anchor state untouched. Full calibration of
both thresholds against a real workload is filed as an M2a follow-up.

Origin: ``evolver:anchor_reconciliation``.
"""
from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from smartmemory.anchors.drift import AnchorDriftChecker
from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata

logger = logging.getLogger(__name__)


@dataclass
class AnchorReconciliationConfig(MemoryBaseModel):
    observation_window_days: int = 7
    drift_score_threshold: float = 0.8
    min_contradictions: int = 2
    max_observations: int = 500


@dataclass
class AnchorReconciliationRequest(StageRequest):
    observation_window_days: int = 7
    drift_score_threshold: float = 0.8
    min_contradictions: int = 2
    max_observations: int = 500
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class AnchorReconciliationEvolver(EvolverPlugin):
    """Stale anchors that have clearly drifted; warn on weaker signals only."""

    def __init__(self, config: Optional[AnchorReconciliationConfig] = None):
        self.config = config or AnchorReconciliationConfig()
        self._checker = AnchorDriftChecker()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="anchor_reconciliation",
            version="1.0.0",
            author="SmartMemory Team",
            description="Stale anchors at drift_score >= 0.8 AND >= 2 contradictory observations; warn otherwise",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(AnchorReconciliationConfig)
        cfg = self.config
        threshold = float(cfg.drift_score_threshold)
        min_contradictions = max(1, int(cfg.min_contradictions))
        window = int(cfg.observation_window_days)
        obs_cap = int(cfg.max_observations)

        with trace_span(
            "pipeline.evolve.anchor_reconciliation",
            {
                "drift_threshold": threshold,
                "min_contradictions": min_contradictions,
                "window_days": window,
            },
        ):
            anchors_by_session = _load_active_anchors_grouped(memory)
            if not anchors_by_session:
                return EvolverResult(
                    stats={
                        "anchors_total": 0,
                        "observations_considered": 0,
                        "staled": 0,
                        "warned": 0,
                        "drift_threshold": threshold,
                        "min_contradictions": min_contradictions,
                        "window_days": window,
                    }
                )

            observations = _load_recent_observations(memory, window_days=window, cap=obs_cap)
            observation_texts = [getattr(o, "content", "") for o in observations if getattr(o, "content", "")]

            staled_ids: list[str] = []
            warned_ids: list[str] = []
            total_anchors = 0

            for session_id, anchors in anchors_by_session.items():
                total_anchors += len(anchors)
                if not observation_texts:
                    # No observations → no drift signal; no-op per anchor.
                    continue

                # Combined (one per anchor) check
                combined_reports = self._checker.check(anchors, observation_texts)
                combined_by_id = {r.anchor_id: r for r in combined_reports}

                # Per-observation check gives us a contradiction count
                for anchor in anchors:
                    anchor_id = getattr(anchor, "item_id", None)
                    if not anchor_id:
                        continue
                    combined = combined_by_id.get(anchor_id)
                    if combined is None:
                        continue

                    per_obs = [
                        self._checker.check([anchor], [text])[0]
                        for text in observation_texts
                    ]
                    contradiction_count = sum(
                        1 for r in per_obs if r.drift_score >= threshold
                    )

                    should_stale = (
                        combined.drift_score >= threshold
                        and contradiction_count >= min_contradictions
                    )

                    if should_stale:
                        _mark_anchor_stale(
                            memory,
                            anchor_id,
                            drift_score=combined.drift_score,
                            contradiction_count=contradiction_count,
                        )
                        staled_ids.append(anchor_id)
                        if logger:
                            logger.info(
                                "anchor_reconciliation: staled anchor=%s drift=%.2f contradictions=%d",
                                anchor_id, combined.drift_score, contradiction_count,
                            )
                    elif combined.drift_score >= threshold or contradiction_count >= 1:
                        # Weaker-but-notable signal: emit warning, no mutation.
                        with trace_span(
                            "anchor.drift.warning",
                            {
                                "anchor_id": anchor_id,
                                "session_id": session_id,
                                "drift_score": combined.drift_score,
                                "contradiction_count": contradiction_count,
                                "threshold": threshold,
                            },
                        ):
                            pass
                        warned_ids.append(anchor_id)

            if logger:
                logger.info(
                    "anchor_reconciliation: anchors=%d observations=%d staled=%d warned=%d",
                    total_anchors, len(observation_texts), len(staled_ids), len(warned_ids),
                )
            return EvolverResult(
                updated_ids=staled_ids,
                stats={
                    "anchors_total": total_anchors,
                    "observations_considered": len(observation_texts),
                    "staled": len(staled_ids),
                    "warned": len(warned_ids),
                    "drift_threshold": threshold,
                    "min_contradictions": min_contradictions,
                    "window_days": window,
                },
            )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_active_anchors_grouped(memory: Any) -> dict[str, list[MemoryItem]]:
    """Return active anchors keyed by session_id, as MemoryItem instances.

    AnchorQueries.get_active returns dicts; we need MemoryItems for the
    drift checker. Fetches the underlying item via `memory.get` / `_crud.get`
    when possible to keep the payload realistic. Uses `_crud.get` when
    available so the fetch does not trigger retrieval-tracking side effects
    (same rationale as get_working_context's anchor path in Slice B).
    """
    from smartmemory.anchors.queries import AnchorQueries

    try:
        queries = AnchorQueries(memory)
    except Exception as exc:
        logger.warning("anchor_reconciliation: AnchorQueries init failed — %s", exc)
        return {}

    grouped: dict[str, list[MemoryItem]] = defaultdict(list)

    try:
        rows = queries.get_all_active() or []
    except Exception as exc:
        logger.warning("anchor_reconciliation: get_all_active failed — %s", exc)
        return {}

    for row in rows:
        session_id = row.get("session_id") or ""
        anchor_id = row.get("anchor_id")
        if not anchor_id:
            continue
        item = _fetch_item_no_track(memory, anchor_id)
        if item is None:
            # Fabricate a minimal MemoryItem from the row so drift check still works.
            item = MemoryItem(
                item_id=anchor_id,
                content=row.get("content", "") or "",
                memory_type="anchor",
                metadata={"session_id": session_id},
            )
        grouped[session_id].append(item)

    return dict(grouped)


def _fetch_item_no_track(memory: Any, item_id: str) -> Optional[MemoryItem]:
    """Fetch a MemoryItem via _crud.get when available to avoid retrieval tracking."""
    crud = getattr(memory, "_crud", None)
    if crud is not None and hasattr(crud, "get"):
        try:
            return crud.get(item_id)
        except Exception:
            return None
    try:
        return memory.get(item_id)
    except Exception:
        return None


def _load_recent_observations(memory: Any, window_days: int, cap: int) -> List[MemoryItem]:
    """Fetch observations with `transaction_time` or metadata timestamp inside the window."""
    try:
        items = memory.search(query="*", memory_type="observation", top_k=cap) or []
    except Exception as exc:
        logger.warning("anchor_reconciliation: observation search failed — %s", exc)
        return []

    if window_days <= 0:
        return items

    cutoff = datetime.now(timezone.utc) - timedelta(days=window_days)
    recent: list[MemoryItem] = []
    for it in items:
        ts = _item_timestamp(it)
        if ts is None or ts >= cutoff:
            recent.append(it)
    return recent


def _item_timestamp(item: MemoryItem) -> Optional[datetime]:
    """Return the best available tz-aware timestamp for an item, or None."""
    md = getattr(item, "metadata", None) or {}
    for key in ("observed_at", "created_at", "reference_time"):
        val = md.get(key)
        ts = _coerce_datetime(val)
        if ts is not None:
            return ts
    return _coerce_datetime(getattr(item, "transaction_time", None))


def _coerce_datetime(val: Any) -> Optional[datetime]:
    if isinstance(val, datetime):
        return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
    if isinstance(val, str):
        try:
            parsed = datetime.fromisoformat(val)
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            return None
    return None


def _mark_anchor_stale(
    memory: Any,
    anchor_id: str,
    drift_score: float,
    contradiction_count: int,
) -> None:
    now = datetime.now(timezone.utc).isoformat()
    try:
        memory.update_properties(
            anchor_id,
            {
                "anchor_status": "stale",
                "drift_score": round(float(drift_score), 3),
                "contradiction_count": int(contradiction_count),
                "drift_detected_at": now,
            },
        )
        with trace_span(
            "anchor.drift.stale",
            {
                "anchor_id": anchor_id,
                "drift_score": drift_score,
                "contradiction_count": contradiction_count,
            },
        ):
            pass
    except Exception as exc:
        logger.warning(
            "anchor_reconciliation: update_properties failed for %s — %s",
            anchor_id, exc,
        )
