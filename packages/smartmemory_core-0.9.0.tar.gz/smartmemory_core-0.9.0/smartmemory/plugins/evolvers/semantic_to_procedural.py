"""Semantic → Procedural evolver (CORE-MEMORY-DYNAMICS-1 M2a Slice C, "the wedge").

Scans stable semantic items for how-to-shaped content and compiles clusters
of similar how-to items into a new procedural memory with a ``derived_from``
trail back to the semantic cluster members. The procedural item is the
compiled summary — originals remain intact (no archiving) because they may
still be useful as explanatory context.

**How-to detection** is heuristic-first (regex over common English imperative
markers: "step 1", "first,", "to do X, do Y", numbered lists, "how to"
prefix). The plan calls out LLM detection as a possible future refinement;
the wedge ships with a deterministic rule-based classifier so the acceptance
test is stable and cheap to run.

**Clustering** uses the lightweight token-Jaccard similarity available in
this repo (`clustering.semantic.jaccard_similarity`) rather than pulling in
a new embedding dependency. When two how-to candidates share ≥
``min_similarity`` tokens by Jaccard and the cluster reaches
``min_occurrences`` members, a procedural summary item is emitted.

Origin: ``evolver:semantic_to_procedural``.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# How-to pattern detection
# ---------------------------------------------------------------------------


_HOW_TO_PATTERNS = [
    re.compile(r"\bhow to\b", re.IGNORECASE),
    re.compile(r"\bstep\s+\d+\b", re.IGNORECASE),
    re.compile(r"\bfirst[,:]", re.IGNORECASE),
    re.compile(r"\b(then|next|finally)[,:]", re.IGNORECASE),
    re.compile(r"^\s*\d+[.)]\s+", re.MULTILINE),  # numbered list
    re.compile(r"\bto\s+\w+(?:\s+\w+){0,4},?\s+(?:do|run|call|invoke|use)\b", re.IGNORECASE),
]


def _looks_like_how_to(content: str) -> bool:
    if not content:
        return False
    for pat in _HOW_TO_PATTERNS:
        if pat.search(content):
            return True
    return False


# ---------------------------------------------------------------------------
# Cluster building — token Jaccard similarity
# ---------------------------------------------------------------------------


_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9_]{2,}")


def _tokenize(content: str) -> frozenset[str]:
    return frozenset(_TOKEN_RE.findall((content or "").lower()))


def _jaccard(a: frozenset[str], b: frozenset[str]) -> float:
    if not a or not b:
        return 0.0
    inter = len(a & b)
    if inter == 0:
        return 0.0
    return inter / len(a | b)


# ---------------------------------------------------------------------------
# Config / request
# ---------------------------------------------------------------------------


@dataclass
class SemanticToProceduralConfig(MemoryBaseModel):
    min_occurrences: int = 5
    min_similarity: float = 0.75
    max_memories: int = 1000


@dataclass
class SemanticToProceduralRequest(StageRequest):
    min_occurrences: int = 5
    min_similarity: float = 0.75
    max_memories: int = 1000
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Evolver
# ---------------------------------------------------------------------------


class SemanticToProceduralEvolver(EvolverPlugin):
    """Compile repeated how-to-shaped semantic memories into procedural items."""

    def __init__(self, config: Optional[SemanticToProceduralConfig] = None):
        self.config = config or SemanticToProceduralConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="semantic_to_procedural",
            version="1.0.0",
            author="SmartMemory Team",
            description="Detects repeated how-to semantic items and compiles them into procedural memories",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(SemanticToProceduralConfig)
        cfg = self.config
        min_occ = max(2, int(cfg.min_occurrences))
        min_sim = float(cfg.min_similarity)
        cap = int(cfg.max_memories)

        with trace_span(
            "pipeline.evolve.semantic_to_procedural",
            {"min_occurrences": min_occ, "min_similarity": min_sim, "cap": cap},
        ):
            candidates = _load_how_to_candidates(memory, cap)
            clusters = _cluster_by_jaccard(candidates, min_sim=min_sim)
            qualifying = [c for c in clusters if len(c) >= min_occ]

            created_ids: list[str] = []
            for cluster in qualifying:
                procedural_id = _emit_procedural(memory, cluster)
                if procedural_id:
                    created_ids.append(procedural_id)
                    if logger:
                        logger.info(
                            "semantic_to_procedural: compiled %d semantic items → %s",
                            len(cluster), procedural_id,
                        )

            if logger:
                logger.info(
                    "semantic_to_procedural: scanned=%d how_to=%d clusters=%d qualifying=%d created=%d",
                    cap, len(candidates), len(clusters), len(qualifying), len(created_ids),
                )
            return EvolverResult(
                created_ids=created_ids,
                stats={
                    "scanned_cap": cap,
                    "how_to_candidates": len(candidates),
                    "clusters": len(clusters),
                    "qualifying_clusters": len(qualifying),
                    "min_occurrences": min_occ,
                    "min_similarity": min_sim,
                },
            )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_how_to_candidates(memory: Any, cap: int) -> List[MemoryItem]:
    """Fetch up to `cap` semantic items and filter to how-to-shaped, uncompiled content."""
    try:
        items = memory.search(query="*", memory_type="semantic", top_k=cap) or []
    except Exception as exc:
        logger.warning("semantic_to_procedural: search failed — %s", exc)
        return []
    return [
        it
        for it in items
        if _looks_like_how_to(getattr(it, "content", ""))
        and not _already_compiled(it)
    ]


def _already_compiled(item: MemoryItem) -> bool:
    md = getattr(item, "metadata", None) or {}
    return bool(md.get("compiled_to_procedural"))


def _cluster_by_jaccard(items: List[MemoryItem], min_sim: float) -> List[List[MemoryItem]]:
    """Greedy single-link clustering using token-Jaccard similarity.

    Not optimal, but O(n²) is fine for the `max_memories` = 1000 cap.
    """
    tokens = [_tokenize(getattr(it, "content", "")) for it in items]
    clusters: list[list[int]] = []  # indices

    for i in range(len(items)):
        if not tokens[i]:
            continue
        placed = False
        for cluster in clusters:
            # Attach to cluster if similar to any existing member.
            if any(_jaccard(tokens[i], tokens[j]) >= min_sim for j in cluster):
                cluster.append(i)
                placed = True
                break
        if not placed:
            clusters.append([i])

    return [[items[j] for j in cluster] for cluster in clusters if cluster]


def _emit_procedural(memory: Any, cluster: List[MemoryItem]) -> Optional[str]:
    """Write a procedural MemoryItem summarizing a cluster.

    Content: concatenated cluster contents separated by a blank line, prefixed
    with a short header. Metadata records the cluster size. `derived_from` is
    set to the first member's id; additional member ids are recorded in
    `metadata["derived_from_ids"]` since `derived_from` is a single field.
    """
    if not cluster:
        return None
    member_ids = [getattr(it, "item_id", None) for it in cluster if getattr(it, "item_id", None)]
    if not member_ids:
        return None

    contents = [getattr(it, "content", "") for it in cluster]
    header = f"Compiled procedure from {len(cluster)} related how-to items."
    body = "\n\n".join(c for c in contents if c)
    procedural = MemoryItem(
        content=f"{header}\n\n{body}",
        memory_type="procedural",
        metadata={
            "cluster_size": len(cluster),
            "derived_from_ids": member_ids,
        },
    )
    procedural.derived_from = member_ids[0]
    procedural.origin = "evolver:semantic_to_procedural"
    try:
        procedural_id = memory.add(procedural)
    except Exception as exc:
        logger.warning("semantic_to_procedural: add failed — %s", exc)
        return None

    # Mark source items as compiled so subsequent evolver runs don't re-emit
    # the same cluster. Mirror of the archived-on-promotion pattern in
    # episodic_to_semantic.py. Per-item failure is tolerated — a stale
    # source will simply be re-scanned; a duplicate procedural is the cost.
    for mid in member_ids:
        try:
            memory.update_properties(mid, {"compiled_to_procedural": procedural_id})
        except Exception as exc:
            logger.warning(
                "semantic_to_procedural: mark-compiled failed for %s — %s", mid, exc
            )
    return procedural_id
