"""Q/A heuristic classifier for ResolutionChainEvolver (M2b Slice A).

Deterministic, LLM-free detection of question-shaped vs answer-shaped content.
Used by ``ResolutionChainEvolver`` to decide which endpoint of a co-retrieval
pair is the question and which is the answer. False positives are tolerated
because the downstream ``ANSWERED_BY`` edge carries a ``confidence`` property
derived from co-retrieval count.

**Design:** heuristic-only by design. The evolver's input pool is already
narrowed to co-activated pairs (hundreds per cycle at most), so the
expected real-workload false-positive rate does not justify an LLM dependency
on this path. See ``design-m2b.md`` §4.2 for the LLM vs heuristic trade-off.
"""

from __future__ import annotations

import re
from typing import Optional, Tuple

# Question-word prefix pattern. Anchored to start-of-string after optional
# whitespace; the content is assumed to be a single memory item's body, so
# an opening "what" / "how" / etc. is the dominant shape signal.
_QUESTION_WORD_PREFIX = re.compile(
    r"^\s*(what|how|why|when|where|who|which|can|could|does|do|did|"
    r"is|are|was|were|should|would|will)\b",
    re.IGNORECASE,
)

# Maximum tokens allowed for a question. Long rhetorical prose ending with
# "?" is not a query — cap enforces "short utterance" shape.
_MAX_QUESTION_TOKENS = 40

# Extended memory types that are never questions regardless of surface shape.
# ``reasoning`` is a chain-of-thought artifact; ``plan``/``decision`` are
# structural. ``opinion``/``observation`` are declarative by definition.
_NON_QUESTION_MEMORY_TYPES = frozenset({
    "reasoning",
    "plan",
    "decision",
    "opinion",
    "observation",
    "code",
    "procedural",
})


def _token_count(content: str) -> int:
    """Whitespace-delimited token count (cheap, good enough for the gate)."""
    return len(content.split())


def is_question(content: str, memory_type: Optional[str] = None) -> bool:
    """Return True when content is shaped like a short question.

    Rules (all must pass):
    1. ``memory_type`` is not in the non-question exclusion set.
    2. Stripped content is non-empty and at most ``_MAX_QUESTION_TOKENS`` tokens.
    3. Stripped content ends with ``?`` OR starts with a question-word prefix.
    """
    if memory_type in _NON_QUESTION_MEMORY_TYPES:
        return False
    if not content:
        return False
    stripped = content.strip()
    if not stripped:
        return False
    if _token_count(stripped) > _MAX_QUESTION_TOKENS:
        return False
    if stripped.endswith("?"):
        return True
    if _QUESTION_WORD_PREFIX.match(stripped):
        return True
    return False


def classify_qa_pair(
    src_content: str,
    tgt_content: str,
    src_memory_type: Optional[str] = None,
    tgt_memory_type: Optional[str] = None,
) -> Optional[Tuple[str, str]]:
    """Return ``('source', 'target')`` or ``('target', 'source')`` Q→A mapping.

    Inputs are two endpoints of a co-retrieval pair. Returns:
    - ``('source', 'target')`` — source is the question, target is the answer
    - ``('target', 'source')`` — target is the question, source is the answer
    - ``None`` — symmetric (both are questions or neither is a question)

    Mirrors the design's "Q-shaped/A-shaped asymmetry" rule: exactly one
    endpoint must be question-shaped for the pair to produce an
    ``ANSWERED_BY`` edge.
    """
    src_is_q = is_question(src_content, src_memory_type)
    tgt_is_q = is_question(tgt_content, tgt_memory_type)
    if src_is_q and not tgt_is_q:
        return ("source", "target")
    if tgt_is_q and not src_is_q:
        return ("target", "source")
    return None
