"""EvolverResult — structured return value for EvolverPlugin.evolve() (CORE-EVO-REPORT-1).

Every evolver's batch `evolve()` method returns an `EvolverResult` so that
orchestrators and UIs (Studio, Insights) can surface per-item drill-down,
in-place-update visibility, and evolver-specific stats without resorting to
coarse before/after node/edge-count snapshots.

An evolver that made no changes returns `EvolverResult()` and its `summary`
property reports "no changes".
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EvolverResult:
    """Structured return value from EvolverPlugin.evolve().

    All fields default to empty. Populate whichever make sense — an evolver
    that does in-place updates only populates `updated_ids` + `stats`; one
    that promotes items populates both `created_ids` (new summary) and
    `updated_ids` (archived originals).
    """

    created_ids: list[str] = field(default_factory=list)
    updated_ids: list[str] = field(default_factory=list)
    deleted_ids: list[str] = field(default_factory=list)
    stats: dict[str, Any] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    @property
    def summary(self) -> str:
        """Human-readable one-liner for UI sub-text."""
        parts: list[str] = []
        if self.created_ids:
            parts.append(f"+{len(self.created_ids)} created")
        if self.updated_ids:
            parts.append(f"~{len(self.updated_ids)} updated")
        if self.deleted_ids:
            parts.append(f"-{len(self.deleted_ids)} deleted")
        return ", ".join(parts) or "no changes"

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dict for Studio event details / API responses."""
        return {
            "summary": self.summary,
            "created_ids": list(self.created_ids),
            "updated_ids": list(self.updated_ids),
            "deleted_ids": list(self.deleted_ids),
            "stats": dict(self.stats),
            "notes": list(self.notes),
        }
