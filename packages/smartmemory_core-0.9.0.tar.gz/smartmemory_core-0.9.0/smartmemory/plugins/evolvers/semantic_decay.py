"""Semantic decay evolver.

Archives semantic facts whose `metadata.relevance` is below `threshold`.
Missing relevance is treated as 1.0 (fully relevant) so untagged items are
never accidentally archived.
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata


@dataclass
class SemanticDecayConfig(MemoryBaseModel):
    threshold: float = 0.2


@dataclass
class SemanticDecayRequest(StageRequest):
    threshold: float = 0.2
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class SemanticDecayEvolver(EvolverPlugin):
    """Archive semantic facts with relevance below `threshold`."""

    def __init__(self, config: Optional[SemanticDecayConfig] = None):
        self.config = config or SemanticDecayConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="semantic_decay",
            version="2.0.0",
            author="SmartMemory Team",
            description="Archives low-relevance semantic facts",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(SemanticDecayConfig)
        cfg = self.config
        threshold = float(cfg.threshold)

        memory_id = getattr(memory, "item_id", None)
        with trace_span(
            "pipeline.evolve.semantic_decay",
            {"memory_id": memory_id, "threshold": threshold},
        ):
            candidates = _load_active_semantic(memory)
            low = [c for c in candidates if _get_relevance(c) < threshold]

            archive_ts = datetime.now(timezone.utc).isoformat()
            archived_ids: list[str] = []
            for fact in low:
                if not fact.item_id:
                    continue
                memory.update_properties(
                    fact.item_id,
                    {
                        "archived": True,
                        "archive_reason": f"semantic_decay:threshold={threshold}",
                        "archive_timestamp": archive_ts,
                    },
                )
                archived_ids.append(fact.item_id)
                if logger:
                    logger.info(
                        f"Archived low-relevance semantic fact: {fact.item_id}"
                    )

            if logger:
                logger.info(
                    f"semantic_decay: archived {len(archived_ids)}/{len(low)} low-relevance facts"
                )
            return EvolverResult(
                updated_ids=archived_ids,
                stats={
                    "candidates": len(candidates),
                    "low_relevance": len(low),
                    "threshold": threshold,
                },
            )


def _load_active_semantic(memory: Any) -> List[MemoryItem]:
    results = memory.search(query="*", memory_type="semantic", top_k=1000) or []
    return [r for r in results if not _is_archived(r)]


def _get_relevance(item: MemoryItem) -> float:
    meta = getattr(item, "metadata", None) or {}
    try:
        # Missing relevance defaults to 1.0 — don't archive untagged items
        return float(meta.get("relevance", 1.0))
    except (TypeError, ValueError):
        return 1.0


def _is_archived(item: MemoryItem) -> bool:
    meta = getattr(item, "metadata", None) or {}
    return bool(meta.get("archived", False))
