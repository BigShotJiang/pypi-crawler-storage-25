"""Episodic → Semantic evolver.

Promotes stable episodic events to semantic memory. "Stable" means the event
has `confidence >= threshold` in metadata AND is older than `days` days.
Each promoted event is copied as a new semantic item (with a fresh item_id,
tracking `derived_from`) and the original episodic item is archived.

Uses the unified SmartMemory API.
"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata


@dataclass
class EpisodicToSemanticConfig(MemoryBaseModel):
    confidence: float = 0.9
    days: int = 3


@dataclass
class EpisodicToSemanticRequest(StageRequest):
    confidence: float = 0.9
    days: int = 3
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class EpisodicToSemanticEvolver(EvolverPlugin):
    """Promote stable episodic events to semantic memory."""

    def __init__(self, config: Optional[EpisodicToSemanticConfig] = None):
        self.config = config or EpisodicToSemanticConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="episodic_to_semantic",
            version="2.0.0",
            author="SmartMemory Team",
            description="Promotes stable episodic events to semantic memory",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(EpisodicToSemanticConfig)
        cfg = self.config
        confidence = float(cfg.confidence)
        min_days = int(cfg.days)

        memory_id = getattr(memory, "item_id", None)
        with trace_span(
            "pipeline.evolve.episodic_to_semantic",
            {"memory_id": memory_id, "confidence": confidence, "min_days": min_days},
        ):
            cutoff = datetime.now(timezone.utc) - timedelta(days=min_days)
            candidates = _load_active_episodic(memory)
            stable = [
                c for c in candidates
                if _get_confidence(c) >= confidence
                and _get_item_date(c) <= cutoff
            ]

            created_ids: list[str] = []
            updated_ids: list[str] = []
            for event in stable:
                episodic_id = event.item_id
                if not episodic_id:
                    continue

                semantic_item = MemoryItem(
                    content=event.content,
                    memory_type="semantic",
                    metadata={
                        **(event.metadata or {}),
                        # Don't inherit archive flags from the source
                        "archived": False,
                    },
                )
                semantic_item.metadata.pop("archive_reason", None)
                semantic_item.metadata.pop("archive_timestamp", None)
                semantic_item.derived_from = episodic_id
                semantic_item.origin = "evolver:episodic_to_semantic"
                new_id = memory.add(semantic_item)

                memory.update_properties(
                    episodic_id,
                    {
                        "archived": True,
                        "archive_reason": f"promoted_to_semantic:{new_id}",
                        "archive_timestamp": datetime.now(timezone.utc).isoformat(),
                    },
                )
                created_ids.append(new_id)
                updated_ids.append(episodic_id)
                if logger:
                    logger.info(
                        f"Promoted episodic event {episodic_id} to semantic {new_id}"
                    )

            if logger:
                logger.info(
                    f"episodic_to_semantic: promoted {len(created_ids)}/{len(stable)} stable events"
                )
            return EvolverResult(
                created_ids=created_ids,
                updated_ids=updated_ids,
                stats={
                    "candidates": len(candidates),
                    "stable": len(stable),
                    "confidence_threshold": confidence,
                    "min_days": min_days,
                },
            )


def _load_active_episodic(memory: Any) -> List[MemoryItem]:
    results = memory.search(query="*", memory_type="episodic", top_k=1000) or []
    return [r for r in results if not _is_archived(r)]


def _get_confidence(item: MemoryItem) -> float:
    """Return the item's confidence score.

    MemoryItem promotes `confidence` to a first-class field (see CORE-PROPS-1),
    so we prefer the attribute; metadata is just a fallback for items that
    came from older code paths or external seeds.
    """
    first_class = getattr(item, "confidence", None)
    if first_class is not None:
        try:
            return float(first_class)
        except (TypeError, ValueError):
            pass
    meta = getattr(item, "metadata", None) or {}
    try:
        return float(meta.get("confidence", 0.0))
    except (TypeError, ValueError):
        return 0.0


def _get_item_date(item: MemoryItem) -> datetime:
    """Return a tz-aware datetime for the item.

    Order of precedence:
    1. `metadata.created_at` / `metadata.reference_time` (explicit seeding)
    2. `transaction_time` (MemoryItem first-class field)
    3. `now` (fallback — defeats the cutoff but never crashes)
    """
    meta = getattr(item, "metadata", None) or {}
    for key in ("created_at", "reference_time"):
        val = meta.get(key)
        if isinstance(val, datetime):
            return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
        if isinstance(val, str):
            try:
                parsed = datetime.fromisoformat(val)
                return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
            except ValueError:
                pass
    tx = getattr(item, "transaction_time", None)
    if isinstance(tx, datetime):
        return tx if tx.tzinfo else tx.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc)


def _is_archived(item: MemoryItem) -> bool:
    meta = getattr(item, "metadata", None) or {}
    return bool(meta.get("archived", False))
