"""
SmartMemory Evolvers - Memory evolution plugins.

Evolvers transform memories across types and synthesize new memories from patterns.
"""

# Base evolver
from .base import Evolver

# Decision evolvers
from .decision_confidence import DecisionConfidenceEvolver

# Enhanced evolvers
from .enhanced.exponential_decay import ExponentialDecayEvolver
from .enhanced.interference_based_consolidation import InterferenceBasedConsolidationEvolver
from .enhanced.retrieval_based_strengthening import RetrievalBasedStrengtheningEvolver

# Maintenance evolvers
from .episodic_decay import EpisodicDecayEvolver
from .episodic_to_semantic import EpisodicToSemanticEvolver
from .semantic_decay import SemanticDecayEvolver
from .episodic_to_zettel import EpisodicToZettelEvolver
from .memory_consolidation import MemoryConsolidationEvolver
from .observation_synthesis import ObservationSynthesisEvolver
from .opinion_reinforcement import OpinionReinforcementEvolver
from .stale_memory import StaleMemoryEvolver

# Synthesis evolvers
from .opinion_synthesis import OpinionSynthesisEvolver

# Activation-driven evolvers (CORE-MEMORY-DYNAMICS-1 M2a Slice C)
from .anchor_reconciliation import AnchorReconciliationEvolver
from .procedural_reinforcement import ProceduralReinforcementEvolver
from .semantic_to_procedural import SemanticToProceduralEvolver

# Flow-expansion evolvers (CORE-MEMORY-DYNAMICS-1 M2b Slice A)
from .resolution_chain import ResolutionChainEvolver

# Type promotion evolvers — WorkingTo* deleted in CORE-MEMORY-DYNAMICS-1 M1b.
# The ConsolidationRouter (observational in M1a, gating in M1b) replaces the
# retroactive promotion pattern with at-ingest routing.

__all__ = [
    # Base
    "Evolver",
    # Type promotion
    "EpisodicToSemanticEvolver",
    "EpisodicToZettelEvolver",
    "SemanticToProceduralEvolver",
    # Maintenance
    "EpisodicDecayEvolver",
    "SemanticDecayEvolver",
    "StaleMemoryEvolver",
    # Synthesis
    "OpinionSynthesisEvolver",
    "ObservationSynthesisEvolver",
    "OpinionReinforcementEvolver",
    # Consolidation
    "MemoryConsolidationEvolver",
    # Decision
    "DecisionConfidenceEvolver",
    # Activation (CORE-MEMORY-DYNAMICS-1 M2a Slice C)
    "ProceduralReinforcementEvolver",
    "AnchorReconciliationEvolver",
    # Flow expansion (CORE-MEMORY-DYNAMICS-1 M2b Slice A)
    "ResolutionChainEvolver",
    # Enhanced
    "ExponentialDecayEvolver",
    "InterferenceBasedConsolidationEvolver",
    "RetrievalBasedStrengtheningEvolver",
]
