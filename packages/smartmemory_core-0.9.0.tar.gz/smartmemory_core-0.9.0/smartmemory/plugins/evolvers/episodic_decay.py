"""Episodic decay evolver.

Archives episodic events older than `half_life` days via the unified API.
Archived items are marked with `archived=True` and a reason/timestamp so they
stop appearing in un-archived searches.
"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata


@dataclass
class EpisodicDecayConfig(MemoryBaseModel):
    half_life: int = 30  # days


@dataclass
class EpisodicDecayRequest(StageRequest):
    half_life: int = 30
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class EpisodicDecayEvolver(EvolverPlugin):
    """Archive episodic events older than `half_life` days."""

    def __init__(self, config: Optional[EpisodicDecayConfig] = None):
        self.config = config or EpisodicDecayConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="episodic_decay",
            version="2.0.0",
            author="SmartMemory Team",
            description="Archives stale episodic events based on age",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(EpisodicDecayConfig)
        cfg = self.config
        half_life = int(cfg.half_life)

        memory_id = getattr(memory, "item_id", None)
        with trace_span(
            "pipeline.evolve.episodic_decay",
            {"memory_id": memory_id, "half_life": half_life},
        ):
            cutoff = datetime.now(timezone.utc) - timedelta(days=half_life)
            candidates = _load_active_episodic(memory)
            stale = [c for c in candidates if _get_item_date(c) <= cutoff]

            archive_ts = datetime.now(timezone.utc).isoformat()
            archived_ids: list[str] = []
            for event in stale:
                if not event.item_id:
                    continue
                memory.update_properties(
                    event.item_id,
                    {
                        "archived": True,
                        "archive_reason": f"episodic_decay:half_life={half_life}",
                        "archive_timestamp": archive_ts,
                    },
                )
                archived_ids.append(event.item_id)
                if logger:
                    logger.info(f"Archived stale episodic event: {event.item_id}")

            if logger:
                logger.info(
                    f"episodic_decay: archived {len(archived_ids)}/{len(stale)} stale events"
                )
            return EvolverResult(
                updated_ids=archived_ids,
                stats={
                    "half_life_days": half_life,
                    "candidates": len(candidates),
                    "stale": len(stale),
                },
            )


def _load_active_episodic(memory: Any) -> List[MemoryItem]:
    results = memory.search(query="*", memory_type="episodic", top_k=1000) or []
    return [r for r in results if not _is_archived(r)]


def _get_item_date(item: MemoryItem) -> datetime:
    """Return a tz-aware datetime for the item.

    Order of precedence:
    1. `metadata.created_at` / `metadata.reference_time` (explicit seeding)
    2. `transaction_time` (MemoryItem first-class field)
    3. `now` (fallback)
    """
    meta = getattr(item, "metadata", None) or {}
    for key in ("created_at", "reference_time"):
        val = meta.get(key)
        if isinstance(val, datetime):
            return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
        if isinstance(val, str):
            try:
                parsed = datetime.fromisoformat(val)
                return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
            except ValueError:
                pass
    tx = getattr(item, "transaction_time", None)
    if isinstance(tx, datetime):
        return tx if tx.tzinfo else tx.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc)


def _is_archived(item: MemoryItem) -> bool:
    meta = getattr(item, "metadata", None) or {}
    return bool(meta.get("archived", False))
