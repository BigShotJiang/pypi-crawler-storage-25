"""Zettel prune evolver.

Archives low-quality or duplicate zettels. Quality signals:
- Content length below `min_content_length`
- Fewer than `min_connections` graph neighbors
- Jaccard similarity over `similarity_threshold` against another zettel

Uses the unified SmartMemory API plus `memory._graph.get_neighbors()` for
connection counts (there is no public "count edges" helper, so the private
graph handle is the documented fallback).
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata


@dataclass
class ZettelPruneConfig(MemoryBaseModel):
    """Configuration for zettel pruning."""
    min_content_length: int = 50
    min_connections: int = 0
    similarity_threshold: float = 0.9
    dry_run: bool = False


@dataclass
class ZettelPruneRequest(StageRequest):
    min_content_length: int = 50
    min_connections: int = 0
    similarity_threshold: float = 0.9
    dry_run: bool = False
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class ZettelPruneEvolver(EvolverPlugin):
    """Archive low-quality or duplicate zettels via soft delete."""

    def __init__(self, config: Optional[ZettelPruneConfig] = None):
        self.config = config or ZettelPruneConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="zettel_prune",
            version="3.0.0",
            author="SmartMemory Team",
            description="Prunes low-quality or duplicate zettels using soft delete",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
            tags=["zettelkasten", "pruning", "deduplication", "soft-delete"],
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(ZettelPruneConfig)
        cfg = self.config

        memory_id = getattr(memory, "item_id", None)
        with trace_span(
            "pipeline.evolve.zettel_prune",
            {"memory_id": memory_id, "dry_run": cfg.dry_run},
        ):
            active = _load_active_zettel(memory)
            candidates = _select_prune_candidates(
                memory=memory,
                zettels=active,
                min_content_length=cfg.min_content_length,
                min_connections=cfg.min_connections,
                similarity_threshold=cfg.similarity_threshold,
            )

            if not candidates:
                if logger:
                    logger.info("No low-quality or duplicate zettels found")
                return EvolverResult(
                    stats={"active": len(active), "dry_run": cfg.dry_run},
                    notes=["no prune candidates"],
                )

            pruned_ids: list[str] = []
            skipped = 0
            archive_ts = datetime.now(timezone.utc).isoformat()
            notes: list[str] = []

            for zettel, reason in candidates:
                if cfg.dry_run:
                    if logger:
                        logger.info(f"[DRY RUN] Would prune zettel {zettel.item_id}: {reason}")
                    skipped += 1
                    notes.append(f"dry_run:{zettel.item_id}:{reason}")
                    continue

                if not zettel.item_id:
                    skipped += 1
                    continue
                # Fail hard — if the write breaks, the prune run is inconsistent
                # (some zettels archived, others silently skipped) and must surface.
                memory.update_properties(
                    zettel.item_id,
                    {
                        "archived": True,
                        "archive_reason": f"zettel_prune:{reason}",
                        "archive_timestamp": archive_ts,
                    },
                )
                pruned_ids.append(zettel.item_id)
                if logger:
                    logger.info(f"Archived zettel {zettel.item_id}: {reason}")

            if logger:
                verb = "Would prune" if cfg.dry_run else "Archived"
                logger.info(
                    f"{verb} {len(pruned_ids) if not cfg.dry_run else skipped} zettels, "
                    f"skipped {skipped if not cfg.dry_run else 0}"
                )
            return EvolverResult(
                updated_ids=pruned_ids,
                stats={
                    "active": len(active),
                    "candidates": len(candidates),
                    "pruned": len(pruned_ids),
                    "skipped": skipped,
                    "dry_run": cfg.dry_run,
                },
                notes=notes,
            )


def _load_active_zettel(memory: Any) -> List[MemoryItem]:
    results = memory.search(query="*", memory_type="zettel", top_k=1000) or []
    return [r for r in results if not _is_archived(r)]


def _select_prune_candidates(
    memory: Any,
    zettels: List[MemoryItem],
    min_content_length: int,
    min_connections: int,
    similarity_threshold: float,
) -> List[Tuple[MemoryItem, str]]:
    """Return (zettel, reason) pairs for items that should be pruned.

    Runs three filters:
    1. Content length below minimum
    2. Graph-connection count below minimum
    3. Jaccard similarity above threshold vs another already-seen zettel
    """
    candidates: List[Tuple[MemoryItem, str]] = []
    seen_for_dedup: List[MemoryItem] = []

    for zettel in zettels:
        reasons: List[str] = []

        content = zettel.content or ""
        if len(content) < min_content_length:
            reasons.append(f"short_content_{len(content)}_chars")

        if min_connections > 0 and zettel.item_id:
            connection_count = _count_connections(memory, zettel.item_id)
            if connection_count < min_connections:
                reasons.append(f"orphaned_{connection_count}_connections")

        duplicate_of = _find_duplicate(zettel, seen_for_dedup, similarity_threshold)
        if duplicate_of is not None:
            reasons.append(f"duplicate_of_{duplicate_of.item_id}")
        else:
            seen_for_dedup.append(zettel)

        if reasons:
            candidates.append((zettel, "_and_".join(reasons)))

    return candidates


def _count_connections(memory: Any, item_id: str) -> int:
    """Return the number of graph neighbors for an item.

    Uses memory._graph.get_neighbors() — the private graph handle is the
    documented escape hatch when the public memory API doesn't expose a
    "count edges" operation. If get_neighbors is missing, we raise so the
    bug is obvious instead of silently treating items as orphaned.
    """
    neighbors = memory._graph.get_neighbors(item_id) or []
    return len(neighbors)


def _find_duplicate(
    candidate: MemoryItem,
    pool: List[MemoryItem],
    threshold: float,
) -> Optional[MemoryItem]:
    """Return the first zettel in `pool` whose Jaccard similarity to
    `candidate` exceeds `threshold`, or None.
    """
    candidate_words = _tokenize(candidate.content or "")
    if not candidate_words:
        return None
    for existing in pool:
        existing_words = _tokenize(existing.content or "")
        if not existing_words:
            continue
        score = _jaccard(candidate_words, existing_words)
        if score >= threshold:
            return existing
    return None


def _tokenize(text: str) -> Set[str]:
    return set(text.lower().split())


def _jaccard(a: Set[str], b: Set[str]) -> float:
    union = a | b
    if not union:
        return 0.0
    return len(a & b) / len(union)


def _is_archived(item: MemoryItem) -> bool:
    meta = getattr(item, "metadata", None) or {}
    return bool(meta.get("archived", False))
