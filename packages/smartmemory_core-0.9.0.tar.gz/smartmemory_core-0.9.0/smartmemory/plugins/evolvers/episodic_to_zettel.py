"""Episodic → Zettel evolver.

Rolls up recent episodic events into zettel notes. For each episodic event
within the last `period` days, creates a new zettel MemoryItem whose content
is the event content, then stores it via the unified API.

Does not archive the source episodic event — both forms coexist. The zettel's
`derived_from` field tracks lineage back to the episodic event.
"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata


@dataclass
class EpisodicToZettelConfig(MemoryBaseModel):
    period: int = 1  # days


@dataclass
class EpisodicToZettelRequest(StageRequest):
    period: int = 1
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class EpisodicToZettelEvolver(EvolverPlugin):
    """Roll up recent episodic events into zettel notes."""

    def __init__(self, config: Optional[EpisodicToZettelConfig] = None):
        self.config = config or EpisodicToZettelConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="episodic_to_zettel",
            version="2.0.0",
            author="SmartMemory Team",
            description="Rolls up episodic events into zettel notes",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(EpisodicToZettelConfig)
        cfg = self.config
        period = int(cfg.period)

        memory_id = getattr(memory, "item_id", None)
        with trace_span(
            "pipeline.evolve.episodic_to_zettel",
            {"memory_id": memory_id, "period_days": period},
        ):
            cutoff = datetime.now(timezone.utc) - timedelta(days=period)
            events = [
                e for e in _load_active_episodic(memory)
                if _get_item_date(e) >= cutoff
            ]

            created_ids: list[str] = []
            for event in events:
                source_id = event.item_id
                if not source_id:
                    continue
                zettel = MemoryItem(
                    content=event.content,
                    memory_type="zettel",
                    metadata={
                        "title": (event.metadata or {}).get("title")
                        or (event.content or "")[:80],
                        "source_episodic_id": source_id,
                    },
                )
                zettel.derived_from = source_id
                zettel.origin = "evolver:episodic_to_zettel"
                new_id = memory.add(zettel)
                created_ids.append(new_id)
                if logger:
                    logger.info(
                        f"Rolled up episodic {source_id} into zettel {new_id}"
                    )

            if logger:
                logger.info(
                    f"episodic_to_zettel: rolled up {len(created_ids)}/{len(events)} events"
                )
            return EvolverResult(
                created_ids=created_ids,
                stats={"candidates": len(events), "period_days": period},
            )


def _load_active_episodic(memory: Any) -> List[MemoryItem]:
    results = memory.search(query="*", memory_type="episodic", top_k=1000) or []
    return [r for r in results if not _is_archived(r)]


def _get_item_date(item: MemoryItem) -> datetime:
    """Return a tz-aware datetime for the item.

    Order of precedence:
    1. `metadata.created_at` / `metadata.reference_time` (explicit seeding)
    2. `transaction_time` (MemoryItem first-class field)
    3. `now` (fallback)
    """
    meta = getattr(item, "metadata", None) or {}
    for key in ("created_at", "reference_time"):
        val = meta.get(key)
        if isinstance(val, datetime):
            return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
        if isinstance(val, str):
            try:
                parsed = datetime.fromisoformat(val)
                return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
            except ValueError:
                pass
    tx = getattr(item, "transaction_time", None)
    if isinstance(tx, datetime):
        return tx if tx.tzinfo else tx.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc)


def _is_archived(item: MemoryItem) -> bool:
    meta = getattr(item, "metadata", None) or {}
    return bool(meta.get("archived", False))
