"""Resolution-chain evolver — Q→A causal chains from CO_RETRIEVED asymmetry.

The graph already records which items get retrieved together (``CO_RETRIEVED``
edges written by ``RetrievalFlushConsumer``). When a question-shaped item and
an answer-shaped item are co-retrieved frequently enough, we promote that flat
co-activation to a directional ``ANSWERED_BY`` edge and boost the answer's
activation score.

**Signal source.** Mirrors the edge scan in
``enhanced/hebbian_co_retrieval.py:91-106`` — ``backend.get_all_edges()`` then
filter to ``edge_type == "CO_RETRIEVED"`` with ``co_retrieval_count >=
weight_threshold``.

**Q/A asymmetry.** Uses the heuristic classifier in
``smartmemory.plugins.evolvers.qa_heuristic``. Symmetric pairs (both
questions or neither question) are skipped.

**Idempotency.** FalkorDB ``add_edge`` uses ``MERGE`` semantics keyed on
``(source, target, relation_type)``, so re-running the evolver never
duplicates edges. However, we must avoid double-boosting the answer on
reruns — so the scan pre-indexes existing ``ANSWERED_BY`` edges and only
emits a boost when a NEW edge is being created. Confidence refresh on
existing edges is monotonic: we only write when the new confidence
exceeds the stored value.

**Origin:** ``evolver:resolution_chain``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from smartmemory.activation.boost import boost_activation
from smartmemory.activation.constants import BOOST_SIZE_RETRIEVE
from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata
from smartmemory.plugins.evolvers.qa_heuristic import classify_qa_pair

logger = logging.getLogger(__name__)


CONFIDENCE_DIVISOR: float = 10.0  # confidence = min(1.0, count / CONFIDENCE_DIVISOR)
ANSWERED_BY_EDGE_TYPE: str = "ANSWERED_BY"
CO_RETRIEVED_EDGE_TYPE: str = "CO_RETRIEVED"
RESOLUTION_ORIGIN: str = "evolver:resolution_chain"
BOOST_REASON: str = "answer_resolved"


@dataclass
class ResolutionChainConfig(MemoryBaseModel):
    weight_threshold: float = 2.0
    max_edges_per_cycle: int = 200


@dataclass
class ResolutionChainRequest(StageRequest):
    weight_threshold: float = 2.0
    max_edges_per_cycle: int = 200
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class ResolutionChainEvolver(EvolverPlugin):
    """Materialize ANSWERED_BY edges from Q/A-asymmetric CO_RETRIEVED pairs."""

    def __init__(self, config: Optional[ResolutionChainConfig] = None):
        self.config = config or ResolutionChainConfig()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="resolution_chain",
            version="1.0.0",
            author="SmartMemory Team",
            description=(
                "Detects Q/A asymmetry in CO_RETRIEVED pairs and writes "
                "directional ANSWERED_BY edges with activation boost on answers."
            ),
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.1.0",
        )

    def evolve(self, memory: Any, logger: Any = None) -> "EvolverResult":
        from smartmemory.plugins.evolvers.result import EvolverResult

        self._validate_config(ResolutionChainConfig)
        cfg = self.config
        weight_threshold = float(cfg.weight_threshold)
        max_edges = max(1, int(cfg.max_edges_per_cycle))

        with trace_span(
            "pipeline.evolve.resolution_chain",
            {"weight_threshold": weight_threshold, "max_edges": max_edges},
        ):
            backend = _get_backend(memory)
            if backend is None:
                return EvolverResult(notes=["no graph backend"])

            try:
                all_edges = backend.get_all_edges()
            except Exception as exc:
                logger_ref = logger or globals()["logger"]
                logger_ref.warning(
                    "resolution_chain: get_all_edges failed — %s", exc
                )
                return EvolverResult(notes=[f"get_all_edges failed: {exc}"])

            # Pre-index: existing ANSWERED_BY edges keyed by (src, tgt) → stored confidence.
            existing_answered_by = _index_existing_answered_by(all_edges)

            # Candidate CO_RETRIEVED edges above the weight threshold.
            candidates = _select_co_retrieved_candidates(
                all_edges, weight_threshold, max_edges
            )

            now = datetime.now(timezone.utc)
            new_edges: list[str] = []
            refreshed_edges: list[str] = []
            boosts_applied = 0
            boosts_fallback = 0
            skipped_symmetric = 0
            skipped_missing_node = 0

            for src_id, tgt_id, count in candidates:
                # Scope-aware node fetch via the workspace-scoped memory.get()
                # path (goes through CRUD + ScopeProvider). Falls back to the
                # unscoped backend read when memory.get() is unavailable
                # (duck-typed test fixtures) so we preserve the existing test
                # surface. Codex-caught in r1: backend.get_all_edges() /
                # backend.get_node() are unscoped on FalkorDB, which would
                # otherwise let one workspace inspect another workspace's
                # content before writing back.
                src_node = _scoped_get_node(memory, backend, src_id)
                tgt_node = _scoped_get_node(memory, backend, tgt_id)
                if src_node is None or tgt_node is None:
                    skipped_missing_node += 1
                    continue

                classification = classify_qa_pair(
                    src_content=_extract_content(src_node),
                    tgt_content=_extract_content(tgt_node),
                    src_memory_type=_extract_memory_type(src_node),
                    tgt_memory_type=_extract_memory_type(tgt_node),
                )
                if classification is None:
                    skipped_symmetric += 1
                    continue

                question_id, answer_id = _resolve_qa_ids(
                    classification, src_id, tgt_id
                )

                new_confidence = min(1.0, float(count) / CONFIDENCE_DIVISOR)
                stored_confidence = existing_answered_by.get((question_id, answer_id))

                if stored_confidence is None:
                    # New edge — write and boost.
                    if _write_answered_by_edge(
                        memory=memory,
                        question_id=question_id,
                        answer_id=answer_id,
                        confidence=new_confidence,
                        count=int(count),
                        detected_at=now,
                    ):
                        new_edges.append(answer_id)
                        # Update the in-cycle index so mirrored candidates
                        # (``(a, q)`` after we just wrote ``(q, a)`` from a
                        # ``(q, a)`` co-retrieval row) hit the refresh path
                        # instead of re-firing the boost. Codex-caught in r1.
                        existing_answered_by[(question_id, answer_id)] = new_confidence
                        redis_path = boost_activation(
                            memory, answer_id, BOOST_SIZE_RETRIEVE,
                            reason=BOOST_REASON, now=now,
                        )
                        if redis_path:
                            boosts_applied += 1
                        else:
                            boosts_fallback += 1
                    continue

                # Existing edge — monotonic refresh only. No boost on refresh.
                if new_confidence > stored_confidence:
                    if _write_answered_by_edge(
                        memory=memory,
                        question_id=question_id,
                        answer_id=answer_id,
                        confidence=new_confidence,
                        count=int(count),
                        detected_at=now,
                    ):
                        refreshed_edges.append(answer_id)
                        existing_answered_by[(question_id, answer_id)] = new_confidence

            stats = {
                "scanned_edges": len(all_edges),
                "candidate_co_retrieved": len(candidates),
                "existing_answered_by": len(existing_answered_by),
                "new_edges": len(new_edges),
                "refreshed_edges": len(refreshed_edges),
                "boosts_applied": boosts_applied,
                "boosts_fallback": boosts_fallback,
                "skipped_symmetric": skipped_symmetric,
                "skipped_missing_node": skipped_missing_node,
                "weight_threshold": weight_threshold,
            }
            return EvolverResult(updated_ids=new_edges, stats=stats)


# ---------------------------------------------------------------------------
# Helpers (module-private)
# ---------------------------------------------------------------------------


def _get_backend(memory: Any) -> Optional[Any]:
    graph = getattr(memory, "_graph", None)
    if graph is None:
        return None
    return getattr(graph, "backend", graph)


def _index_existing_answered_by(
    all_edges: list[dict],
) -> Dict[Tuple[str, str], float]:
    """Map (source_id, target_id) → stored confidence for existing ANSWERED_BY edges."""
    index: Dict[Tuple[str, str], float] = {}
    for edge in all_edges:
        if edge.get("edge_type") != ANSWERED_BY_EDGE_TYPE:
            continue
        src = edge.get("source_id")
        tgt = edge.get("target_id")
        if not src or not tgt:
            continue
        props = edge.get("properties") or {}
        try:
            conf = float(props.get("confidence", 0.0))
        except (TypeError, ValueError):
            conf = 0.0
        index[(src, tgt)] = conf
    return index


def _select_co_retrieved_candidates(
    all_edges: list[dict], weight_threshold: float, max_edges: int
) -> List[Tuple[str, str, float]]:
    """Return CO_RETRIEVED edges with count >= threshold, top ``max_edges`` by count."""
    co_retrieved: list[tuple[str, str, float]] = []
    for edge in all_edges:
        if edge.get("edge_type") != CO_RETRIEVED_EDGE_TYPE:
            continue
        props = edge.get("properties") or {}
        try:
            count = float(props.get("co_retrieval_count", 0))
        except (TypeError, ValueError):
            count = 0.0
        if count < weight_threshold:
            continue
        src = edge.get("source_id")
        tgt = edge.get("target_id")
        if not src or not tgt:
            continue
        co_retrieved.append((src, tgt, count))
    co_retrieved.sort(key=lambda x: x[2], reverse=True)
    return co_retrieved[:max_edges]


def _safe_get_node(backend: Any, item_id: str) -> Optional[Any]:
    """Best-effort ``get_node`` — returns None on any failure."""
    try:
        return backend.get_node(item_id)
    except Exception as exc:
        logger.debug("resolution_chain: get_node(%s) failed — %s", item_id, exc)
        return None


def _scoped_get_node(memory: Any, backend: Any, item_id: str) -> Optional[Any]:
    """Workspace-scoped node fetch.

    Prefers ``memory.get()`` — which applies the scope provider's workspace
    filter. When ``memory.get`` is unavailable (duck-typed fixtures that do
    not implement it) OR raises, fall back to the unscoped backend read.
    When ``memory.get`` returns ``None``, that is a definitive "not visible
    in this workspace" answer and the caller must treat it as a skip — do
    NOT fall through to the unscoped backend read, because doing so would
    materialise a cross-workspace node into a local ANSWERED_BY edge.
    Codex-caught in Slice A r2.
    """
    getter = getattr(memory, "get", None)
    if callable(getter):
        try:
            return getter(item_id)
        except Exception as exc:
            logger.debug(
                "resolution_chain: memory.get(%s) failed — falling back to "
                "backend.get_node (%s)", item_id, exc,
            )
    return _safe_get_node(backend, item_id)


def _extract_content(node: Any) -> str:
    """Pull ``content`` from either a dict node or a MemoryItem."""
    if node is None:
        return ""
    if isinstance(node, dict):
        return node.get("content") or ""
    return getattr(node, "content", "") or ""


def _extract_memory_type(node: Any) -> Optional[str]:
    """Pull ``memory_type`` from either a dict node or a MemoryItem."""
    if node is None:
        return None
    if isinstance(node, dict):
        return node.get("memory_type")
    return getattr(node, "memory_type", None)


def _resolve_qa_ids(
    classification: Tuple[str, str], src_id: str, tgt_id: str
) -> Tuple[str, str]:
    """Map the heuristic's ('source','target') | ('target','source') to concrete ids."""
    q_role, a_role = classification
    q_id = src_id if q_role == "source" else tgt_id
    a_id = tgt_id if a_role == "target" else src_id
    return q_id, a_id


def _write_answered_by_edge(
    memory: Any,
    question_id: str,
    answer_id: str,
    confidence: float,
    count: int,
    detected_at: datetime,
) -> bool:
    """Write or MERGE-update the ANSWERED_BY edge. Returns True on success."""
    try:
        memory.add_edge(
            source_id=question_id,
            target_id=answer_id,
            relation_type=ANSWERED_BY_EDGE_TYPE,
            properties={
                "confidence": confidence,
                "origin": RESOLUTION_ORIGIN,
                "detected_at": detected_at.isoformat(),
                "co_retrieval_count": count,
            },
        )
        return True
    except Exception as exc:
        logger.warning(
            "resolution_chain: add_edge failed (q=%s a=%s err=%s)",
            question_id, answer_id, exc,
        )
        return False
