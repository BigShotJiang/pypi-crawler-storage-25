"""
CORE-CONSOLIDATE-1: Memory Consolidation Evolver

Periodically merges overlapping episodic memories about the same entity
into unified semantic summaries. Fixes list-type retrieval failures where
facts are spread across sessions.

Example: "Melanie went camping at the beach" + "camping in the mountains"
+ "camping in the forest" -> single consolidated memory "Melanie camps at
beaches, mountains, and forests."

Pattern: ObservationSynthesisEvolver (entity-based batch synthesis).
"""

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from smartmemory.models.base import MemoryBaseModel, StageRequest
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata

logger = logging.getLogger(__name__)


@dataclass
class MemoryConsolidationConfig(MemoryBaseModel):
    """Configuration for memory consolidation."""

    min_memories_per_entity: int = 3  # Minimum episodic memories to trigger consolidation
    lookback_days: int = 90  # How far back to look for episodic memories
    max_consolidations_per_run: int = 20  # Limit consolidations per evolution cycle
    use_llm: bool = True  # Use LLM for high-quality summarization
    model_name: str = ""  # Resolved at runtime via get_default_model()


@dataclass
class MemoryConsolidationRequest(StageRequest):
    lookback_days: int = 90
    context: Dict[str, Any] = field(default_factory=dict)
    run_id: Optional[str] = None


class MemoryConsolidationEvolver(EvolverPlugin):
    """
    Consolidates overlapping episodic memories about the same entity
    into unified semantic summaries.

    Flow:
    1. Gather episodic memories and group by entity
    2. Filter to entities with enough memories (>= min_memories_per_entity)
    3. Skip entities whose episodics are already consolidated
    4. Summarize via LLM (or simple concatenation as fallback)
    5. Store consolidated semantic memory with origin=evolver:memory_consolidation
    6. Create CONSOLIDATED_FROM edges for provenance
    7. Mark source episodics with consolidated=true metadata
    """

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="memory_consolidation",
            version="1.0.0",
            author="SmartMemory Team",
            description="Consolidates overlapping episodic memories into unified semantic summaries",
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.3.0",
            tags=["consolidation", "episodic", "semantic", "synthesis"],
        )

    def __init__(self, config: Optional[MemoryConsolidationConfig] = None):
        self.config = config or MemoryConsolidationConfig()

    def evolve(self, memory, log=None) -> "EvolverResult":
        """
        Main evolution method: find entity clusters of episodic memories
        and consolidate them into semantic summaries.
        """
        from smartmemory.plugins.evolvers.result import EvolverResult

        log = log or logger
        cfg = self.config

        with trace_span("pipeline.evolve.memory_consolidation", {"min_memories": cfg.min_memories_per_entity}):
            # 1. Gather episodic memories grouped by entity
            entity_memories = self._gather_entity_episodics(memory, log)
            if not entity_memories:
                log.info("Memory consolidation: no episodic memories with entity references found")
                return EvolverResult(notes=["no episodic memories with entity references"])

            log.info(f"Memory consolidation: found {len(entity_memories)} entities with episodic memories")

            # 2. Filter to entities with enough memories, excluding already-consolidated
            eligible = {}
            for entity_id, memories in entity_memories.items():
                unconsolidated = [m for m in memories if not m.metadata.get("consolidated")]
                if len(unconsolidated) >= cfg.min_memories_per_entity:
                    eligible[entity_id] = unconsolidated

            if not eligible:
                log.info(
                    f"Memory consolidation: no entities have >= {cfg.min_memories_per_entity} "
                    f"unconsolidated episodic memories"
                )
                return EvolverResult(
                    stats={"entities": len(entity_memories), "eligible": 0},
                    notes=[f"no entities meet min_memories_per_entity={cfg.min_memories_per_entity}"],
                )

            log.info(f"Memory consolidation: {len(eligible)} entities eligible for consolidation")

            # 3. Consolidate each entity cluster. Fail hard — if one entity's
            # consolidation breaks, the whole run aborts rather than producing
            # a partially-consolidated graph.
            created_ids: list[str] = []
            updated_ids: list[str] = []
            for entity_id, memories in list(eligible.items())[: cfg.max_consolidations_per_run]:
                consolidated_id = self._consolidate_entity(memory, entity_id, memories, log)
                if consolidated_id:
                    created_ids.append(consolidated_id)
                    updated_ids.extend(m.item_id for m in memories if m.item_id)
                    log.info(
                        f"Memory consolidation: created consolidated memory {consolidated_id} "
                        f"for entity '{entity_id}' from {len(memories)} sources"
                    )

            log.info(f"Memory consolidation complete: {len(created_ids)} consolidations created")
            return EvolverResult(
                created_ids=created_ids,
                updated_ids=updated_ids,
                stats={
                    "entities": len(entity_memories),
                    "eligible": len(eligible),
                    "consolidations": len(created_ids),
                },
            )

    def _gather_entity_episodics(self, memory, log) -> Dict[str, List[MemoryItem]]:
        """Gather episodic memories and group by entity reference.

        Groups by entity name from:
        - item.entities[].name
        - item.metadata['subject']

        Uses a direct property-equality graph query rather than semantic
        search. LOCAL-PARITY-TEST-1 Wave 4 follow-up: ``memory.search("*",
        memory_type="episodic")`` treats ``"*"`` as a query string to embed
        (not a wildcard) and is unreliable on FalkorDB with sparse content —
        items are stored but not found. The same anti-pattern in
        FailureJournal + PlanQueries was replaced in Wave 4 with
        ``backend.search_nodes({...})``; this fix mirrors it. The
        ``row.get("item_id")`` filter excludes FalkorDB's dual-encoded shadow
        nodes (item_id=None) which would otherwise poison ``memory.get()``.

        Fails hard: backend errors propagate to the caller. Previously a
        ``try/except`` here silently masked backend failures as "nothing to
        consolidate" — removed so real backend issues surface loudly.
        """
        entity_memories: Dict[str, List[MemoryItem]] = defaultdict(list)

        rows = memory._graph.backend.search_nodes({"memory_type": "episodic"})
        results: List[MemoryItem] = []
        for row in rows:
            item_id = row.get("item_id")
            if not item_id:
                continue
            item = memory.get(item_id)
            if item is not None:
                results.append(item)
            if len(results) >= 500:
                break

        for item in results:
            entity_names = set()

            # Extract from entities field
            for entity in item.entities or []:
                name = entity.get("name", "").strip()
                if name:
                    entity_names.add(name)

            # Extract from metadata subject
            subject = (item.metadata or {}).get("subject", "").strip()
            if subject:
                entity_names.add(subject)

            for name in entity_names:
                entity_memories[name].append(item)

        return dict(entity_memories)

    def _consolidate_entity(
        self,
        memory,
        entity_id: str,
        memories: List[MemoryItem],
        log,
    ) -> Optional[str]:
        """Consolidate episodic memories for a single entity into a semantic summary.

        Returns the item_id of the new consolidated memory, or None on failure.
        """
        # Build summary content
        content = self._summarize_memories(entity_id, memories, log)
        if not content:
            log.warning(f"Memory consolidation: empty summary for entity '{entity_id}', skipping")
            return None

        # CORE-CONSOLIDATE-1 amendment: preserve metadata from sources
        # List property union — combine list-valued properties across all sources
        merged_lists: Dict[str, List] = defaultdict(list)
        source_sessions: List[str] = []
        source_dates: List = []
        for m in memories:
            meta = m.metadata or {}
            # Collect session IDs
            sid = meta.get("session_id")
            if sid and sid not in source_sessions:
                source_sessions.append(sid)
            # Collect dates for range tracking
            for date_key in ("resolved_date", "session_date"):
                dv = meta.get(date_key)
                if dv:
                    source_dates.append(dv)
            if m.valid_start_time:
                vst = m.valid_start_time
                source_dates.append(vst.isoformat() if hasattr(vst, "isoformat") else str(vst))
            # Union list properties — canonical singular keys per accumulation contract
            # Read both plural and singular forms, store under singular canonical key
            _KEY_MAP = {"locations": "location", "skills": "skills", "interests": "interests",
                        "hobbies": "hobbies", "activities": "activities",
                        "location": "location", "occupation": "occupation"}
            for raw_key, canonical in _KEY_MAP.items():
                vals = meta.get(raw_key)
                if isinstance(vals, list):
                    for v in vals:
                        if v not in merged_lists[canonical]:
                            merged_lists[canonical].append(v)
                elif isinstance(vals, str) and vals:
                    if vals not in merged_lists[canonical]:
                        merged_lists[canonical].append(vals)

        # Date range — parse to datetime for correct chronological sort
        from smartmemory.search.rerank import parse_session_date, _MAX_DT
        from dateutil.parser import parse as _dp, ParserError

        parsed_dates: List = []
        for d in source_dates:
            if not d:
                continue
            try:
                dt = _dp(d) if isinstance(d, str) else d
                if dt != _MAX_DT:
                    # Normalize to UTC naive for consistent sorting across timezones
                    if hasattr(dt, "tzinfo") and dt.tzinfo:
                        from datetime import timezone as _tz
                        dt = dt.astimezone(_tz.utc).replace(tzinfo=None)
                    parsed_dates.append(dt)
            except (ParserError, ValueError, TypeError):
                dt = parse_session_date(str(d))
                if dt != _MAX_DT:
                    if hasattr(dt, "tzinfo") and dt.tzinfo:
                        from datetime import timezone as _tz
                        dt = dt.astimezone(_tz.utc).replace(tzinfo=None)
                    parsed_dates.append(dt)

        date_range = {}
        if parsed_dates:
            parsed_dates.sort()
            date_range = {
                "earliest": parsed_dates[0].isoformat(),
                "latest": parsed_dates[-1].isoformat(),
            }

        # Build consolidated metadata
        consolidated_meta: Dict[str, Any] = {
            "consolidated_from_count": len(memories),
            "consolidated_entity": entity_id,
            "source_ids": [m.item_id for m in memories],
            "origin": "evolver:memory_consolidation",
        }
        if source_sessions:
            consolidated_meta["source_sessions"] = source_sessions
        if date_range:
            consolidated_meta["date_range"] = date_range
        # Merge list properties into metadata
        for key, vals in merged_lists.items():
            if vals:
                consolidated_meta[key] = vals

        # Create consolidated semantic memory
        consolidated_item = MemoryItem(
            content=content,
            memory_type="semantic",
            origin="evolver:memory_consolidation",
            confidence=0.9,
            entities=[{"name": entity_id, "type": "person"}],
            metadata=consolidated_meta,
        )

        # Store the consolidated memory
        consolidated_id = memory.add(consolidated_item)
        if not consolidated_id:
            log.error(f"Memory consolidation: failed to store consolidated memory for '{entity_id}'")
            return None

        # Create CONSOLIDATED_FROM edges. Fail hard — a consolidated node
        # without provenance edges is worse than not consolidating at all,
        # because it looks authoritative but has no traceable sources.
        for source in memories:
            if not source.item_id:
                continue
            memory._graph.add_edge(
                source_id=consolidated_id,
                target_id=source.item_id,
                edge_type="CONSOLIDATED_FROM",
                properties={
                    "origin": "evolver:memory_consolidation",
                    "confidence": 0.9,
                    "entity": entity_id,
                },
            )

        # Mark source episodics as consolidated. Fail hard — if we don't
        # mark them, the next run re-consolidates and creates duplicates.
        for source in memories:
            if not source.item_id:
                continue
            memory.update_properties(
                source.item_id,
                {"consolidated": True, "consolidated_into": consolidated_id},
            )

        return consolidated_id

    def _summarize_memories(self, entity_id: str, memories: List[MemoryItem], log) -> str:
        """Create a summary of episodic memories about an entity.

        Uses LLM when available, falls back to simple concatenation with WARNING.
        """
        fact_contents = [m.content for m in memories if m.content]
        if not fact_contents:
            return ""

        # Try LLM summarization first
        if self.config.use_llm:
            try:
                summary = self._llm_summarize(entity_id, fact_contents)
                if summary:
                    return summary
            except Exception as e:
                log.warning(
                    f"Memory consolidation: LLM summarization failed for '{entity_id}', "
                    f"falling back to simple concatenation: {e}"
                )

        # Fallback: simple concatenation (always logs WARNING per no-silent-degradation rule)
        log.warning(
            f"Memory consolidation: using simple concatenation fallback for '{entity_id}' "
            f"({len(fact_contents)} facts). LLM summarization not available."
        )
        return self._simple_summarize(entity_id, fact_contents)

    def _llm_summarize(self, entity_id: str, fact_contents: List[str]) -> Optional[str]:
        """Use LLM to create a high-quality consolidated summary."""
        from smartmemory.utils.llm import call_llm, get_default_model

        facts_text = "\n".join(f"- {fact}" for fact in fact_contents)
        system_prompt = (
            "You are a memory consolidation system. Given multiple episodic memories about the same entity, "
            "produce a single concise factual summary that captures ALL key information. "
            "Do not add information not present in the sources. "
            "Write in third person. Output only the summary text, no preamble."
        )
        user_content = (
            f"Entity: {entity_id}\n\n"
            f"Episodic memories:\n{facts_text}\n\n"
            f"Produce a single consolidated summary of all facts about {entity_id}."
        )

        model = self.config.model_name or get_default_model()
        parsed, raw = call_llm(
            model=model,
            system_prompt=system_prompt,
            user_content=user_content,
            max_output_tokens=300,
            temperature=0.3,
        )

        # Prefer raw text response for summary
        result = raw or (parsed.get("summary") if isinstance(parsed, dict) else None)
        if result and isinstance(result, str) and len(result.strip()) > 10:
            return result.strip()

        return None

    def _simple_summarize(self, entity_id: str, fact_contents: List[str]) -> str:
        """Simple concatenation fallback for when LLM is unavailable."""
        unique_facts = list(dict.fromkeys(fact_contents))[:10]
        facts_text = "; ".join(unique_facts)
        return f"Consolidated facts about {entity_id}: {facts_text}"
