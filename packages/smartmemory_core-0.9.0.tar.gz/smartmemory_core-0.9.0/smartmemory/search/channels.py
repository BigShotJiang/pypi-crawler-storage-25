"""CORE-SEARCH-2a: Named search channel registry.

Each channel maps to a search strategy in SmartGraphSearch. The registry
defines channel names and default RRF weights. Callers can override weights
per-query via ``channel_weights`` on ``SmartMemory.search()``.
"""

import math
from dataclasses import dataclass


@dataclass
class SearchChannel:
    """A named retrieval channel with a default RRF weight."""
    name: str
    default_weight: float = 1.0


CHANNEL_DEFAULTS = {
    "entity-graph": SearchChannel(name="entity-graph", default_weight=1.2),
    "ssg-traversal": SearchChannel(name="ssg-traversal", default_weight=1.0),
    "semantic": SearchChannel(name="semantic", default_weight=1.0),
    "regex-text": SearchChannel(name="regex-text", default_weight=0.9),
    "contains": SearchChannel(name="contains", default_weight=0.8),
    "keyword-bm25": SearchChannel(name="keyword-bm25", default_weight=0.8),
    "spreading-activation": SearchChannel(name="spreading-activation", default_weight=1.0),
}


def validate_weight(w: float, default: float) -> float:
    """Clamp a caller-supplied weight to [0.0, 10.0], replacing invalid values."""
    if not isinstance(w, (int, float)) or math.isnan(w) or math.isinf(w):
        return default
    return max(0.0, min(10.0, float(w)))
