"""Bounded-BFS spreading activation from seed item_ids (M3 Slice B).

Wraps the FalkorDB backend primitive ``search_by_activation_from_seeds``
(ships alongside this module in Slice B.1) with:

- Client-side decay: raw hop counts from the backend → ``damping ** hops``.
- Cross-seed max-aggregation: when multiple seeds reach the same target,
  the max propagated score wins (not the sum). Prevents unbounded
  inflation in dense graphs (design §6.5).
- Budget-exceeded handling: the Slice B spike (S1) confirmed FalkorDB
  raises ``ResponseError: Query timed out`` on timeout (Path B outcome).
  This wrapper catches and returns ``{}`` + WARN log rather than
  propagating to the caller. The public ``spread()`` contract is:
  *always returns a dict, never raises for timeout/backend errors.*

Unrelated exceptions (``ValueError``, ``KeyError``, bugs in callers)
propagate normally — swallowing them would hide real bugs.

Workspace scoping and global-node exclusion happen in the backend
Cypher (see ``FalkorDBBackend.search_by_activation_from_seeds``), not
here. This module is pure Python logic over the primitive's output.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Design §3.3 defaults.
DEFAULT_DEPTH: int = 2
DEFAULT_MAX_FAN_OUT: int = 20
DEFAULT_DAMPING: float = 0.5
DEFAULT_BUDGET_MS: int = 150


class SpreadingBudgetExceededError(Exception):
    """Raised internally when the backend reports a timeout.

    Never raised to the ``spread()`` caller — caught inside the wrapper
    and converted to ``{}``. Exposed as a named class so tests and
    future callers of the raw primitive can distinguish this class of
    failure.
    """


def spread(
    memory: Any,
    seed_item_ids: List[str],
    *,
    depth: int = DEFAULT_DEPTH,
    max_fan_out: int = DEFAULT_MAX_FAN_OUT,
    damping: float = DEFAULT_DAMPING,
    edge_types: Optional[List[str]] = None,
    budget_ms: int = DEFAULT_BUDGET_MS,
) -> Dict[str, float]:
    """Bounded BFS from seeds, returning propagated scores per reachable item.

    Args:
        memory: Workspace-scoped SmartMemory instance. Must expose
            ``_graph.backend.search_by_activation_from_seeds``.
        seed_item_ids: Starting point(s) for the BFS. Empty list →
            ``{}`` without touching the backend.
        depth: Max hop depth. Default 2 per design §3.3.
        max_fan_out: Cap on BFS frontier size per hop. Default 20.
        damping: Per-hop decay factor. Default 0.5.
        edge_types: Override the default edge allowlist. ``None`` →
            backend picks its default (all types minus
            ``CONTRADICTS``/``SUPERSEDES``/``GROUNDED_IN``).
        budget_ms: Backend query timeout in milliseconds. Default 150.

    Returns:
        ``{item_id: propagated_score}`` — items reachable within ``depth``
        hops of any seed, scored by ``damping ** shortest_hops``.
        Does NOT include the seeds themselves. Empty dict on:
        - Empty ``seed_item_ids``
        - Backend returns nothing
        - Backend raises ``ResponseError`` (timeout, syntax, etc.) — WARN logged

    Never raises for timeout/backend errors. Other exceptions propagate.
    """
    if not seed_item_ids:
        return {}

    try:
        raw = memory._graph.backend.search_by_activation_from_seeds(
            seed_item_ids=list(seed_item_ids),
            depth=depth,
            max_fan_out=max_fan_out,
            damping=damping,
            edge_types=edge_types,
            budget_ms=budget_ms,
        )
    except Exception as exc:
        # The FalkorDB client raises redis.exceptions.ResponseError on
        # GRAPH.QUERY failures. Importing redis just to isinstance-check
        # pulls in redis-py at module-import time which is fine (it's
        # already a dependency), but a name-based check also works if
        # the exact import path varies by client version.
        exc_class_name = exc.__class__.__name__
        if exc_class_name == "ResponseError":
            logger.warning(
                "spread: backend ResponseError (likely timeout or query "
                "error), returning empty dict: %s", exc,
            )
            return {}
        # Unrelated exception — propagate so real bugs are visible.
        raise

    seed_set = set(seed_item_ids)
    propagated: Dict[str, float] = {}
    for row in raw or []:
        # Backend returns (item_id, shortest_hop_count) tuples.
        try:
            item_id, hops = row[0], int(row[1])
        except (IndexError, TypeError, ValueError):
            continue
        if not item_id or item_id in seed_set:
            continue  # seeds are never their own spread targets
        if hops <= 0:
            # Defensive — a hop of 0 would give score=1.0, indistinguishable
            # from a direct hit. Skip.
            continue
        score = float(damping) ** hops
        # Max-aggregation across seeds — the strongest path wins.
        if item_id not in propagated or score > propagated[item_id]:
            propagated[item_id] = score
    return propagated
