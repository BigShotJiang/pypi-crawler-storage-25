"""Query-conditioned hop weighting for multi-hop search (CORE-ATTENTION-FUSION-1).

Replaces the fixed `HOP_DECAY ** i` weight in multi-hop RRF fusion with a
query-conditioned weight function. Phase 1 is heuristic-only: combines
query-intent classification with the cross-encoder rerank score already
attached to results by ``CrossEncoderReranker.rerank``. No new dependencies,
no LLM calls.

Falls back to fixed exponential decay when disabled or on any error.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import List, Optional

logger = logging.getLogger(__name__)

# Match the existing constant from multi_hop.py.
HOP_DECAY = 0.7

# Intent class → per-hop multiplier on the base decay.
# Index i applies to hop i; tail value repeats for any hop beyond the table.
_INTENT_HOP_MULT = {
    "entity":  [1.0, 1.15, 1.20, 1.20],   # graph traversal pays off — boost deeper hops
    "causal":  [1.0, 1.10, 0.90, 0.80],   # answer usually one hop away
    "recall":  [1.0, 0.90, 0.70, 0.60],   # first hop is the answer
}

_ENTITY_RE = re.compile(
    r"\b(who|what|which|where|whose|whom)\b",
    re.IGNORECASE,
)
_CAUSAL_RE = re.compile(
    r"\b(why|how come|because|reason|cause|caused|leads to|due to)\b",
    re.IGNORECASE,
)


@dataclass
class AttentionFusionConfig:
    """Configuration for query-conditioned hop attention.

    Attributes:
        enabled: Master switch. When False, callers receive fixed-decay
            weights (current behavior).
        decay_floor: Minimum weight any hop can receive. Prevents quality
            and intent multipliers from collapsing later hops to zero.
        quality_min: Lower clamp on the rerank-score quality multiplier.
        quality_max: Upper clamp on the rerank-score quality multiplier.
    """

    enabled: bool = False
    decay_floor: float = 0.4
    quality_min: float = 0.5
    quality_max: float = 1.5


def classify_intent(query: str) -> str:
    """Classify a query into one of {entity, causal, recall}.

    Pure-regex; no language model. Returns ``recall`` as the default.
    """
    if not query:
        return "recall"
    if _CAUSAL_RE.search(query):
        return "causal"
    if _ENTITY_RE.search(query):
        return "entity"
    return "recall"


def _hop_quality_multiplier(
    hop_results: list,
    quality_min: float,
    quality_max: float,
) -> float:
    """Average ``_rerank_score`` across a hop's top results, clamped to [min, max].

    Returns 1.0 (neutral) when no rerank scores are available — this is the
    common case when the cross-encoder is unavailable or the hop ran on a
    path that bypasses reranking.
    """
    scores = []
    for item in hop_results[:5]:
        s = getattr(item, "_rerank_score", None)
        if s is not None:
            try:
                scores.append(float(s))
            except (TypeError, ValueError):
                continue
    if not scores:
        return 1.0
    avg = sum(scores) / len(scores)
    # Cross-encoder scores are unbounded but typically clustered around 0;
    # we treat the *mean* as the multiplier directly, then clamp. This means
    # a hop whose top items the reranker liked at score ~1.2 gets a 1.2x
    # boost, while a hop with mean score ~0.4 gets pulled to the floor.
    return max(quality_min, min(quality_max, avg))


def compute_hop_weights(
    query: str,
    hop_results: List[list],
    config: Optional[AttentionFusionConfig] = None,
) -> List[float]:
    """Return per-hop RRF weights conditioned on the query.

    Args:
        query: Original user query (used for intent classification).
        hop_results: List of per-hop result lists, in hop order. Each inner
            list is the merged candidate list for that hop (already
            RRF-merged across parallel chains).
        config: Attention fusion config. When ``None`` or ``enabled=False``,
            the function returns the fixed exponential decay
            ``[HOP_DECAY ** i for i in range(len(hop_results))]`` so callers
            can use it as a drop-in replacement.

    Returns:
        A list of floats, one per hop, suitable to pass as ``weights`` to
        ``rrf_merge``. Length matches ``len(hop_results)``.
    """
    n = len(hop_results)
    if n == 0:
        return []

    cfg = config or AttentionFusionConfig()
    base = [HOP_DECAY ** i for i in range(n)]

    if not cfg.enabled:
        return base

    try:
        intent = classify_intent(query)
        intent_table = _INTENT_HOP_MULT.get(intent, _INTENT_HOP_MULT["recall"])

        weights: List[float] = []
        for i, results in enumerate(hop_results):
            intent_mult = intent_table[i] if i < len(intent_table) else intent_table[-1]
            quality_mult = _hop_quality_multiplier(
                results, cfg.quality_min, cfg.quality_max,
            )
            w = base[i] * intent_mult * quality_mult
            weights.append(max(cfg.decay_floor, w))

        logger.debug(
            "attention_fusion: intent=%s weights=%s base=%s",
            intent, [round(w, 3) for w in weights], [round(b, 3) for b in base],
        )
        return weights
    except Exception as exc:  # pragma: no cover — defensive fallback
        logger.warning("attention_fusion failed, falling back to fixed decay: %s", exc)
        return base
