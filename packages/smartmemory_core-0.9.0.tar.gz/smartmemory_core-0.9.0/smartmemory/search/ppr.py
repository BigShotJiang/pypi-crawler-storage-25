"""Personalized PageRank over a workspace subgraph (M3 Slice C.2).

Spike S2 verdict (2026-04-22): exact NetworkX ``pagerank`` on synthetic
workspaces:
    n=1000:   median ~2.35ms  p99 ~93ms (first-run JIT outlier)
    n=5000:   median ~11ms    p99 ~12ms
    n=10000:  median ~23ms    p99 ~25ms

All well under the 300ms budget bound. **Exact PPR ships** — no
random-walk approximation needed at M3 release. If a production
workspace ever exceeds ~20k nodes, the backend's
``materialize_workspace_subgraph`` returns None and this module
short-circuits to ``{}`` without running NetworkX at all.

**Concurrency control (design §6.4 + blueprint C7).** NetworkX
``pagerank`` running inside a ``ThreadPoolExecutor.submit().result(...)``
is NOT truly cancellable — a timeout returns control to the caller but
the background thread keeps running. A module-level
``threading.Semaphore(2)`` checked at submit time via
``acquire(blocking=False)`` enforces bounded work-in-flight: new callers
arriving while 2 PPR tasks are already running short-circuit to ``{}``
instead of queuing up on the executor's unbounded internal queue.

**Permit lifetime = task lifetime, NOT caller-wait lifetime.** The
permit is acquired by the caller, then ownership transfers to the
submitted task, which releases in its own ``finally`` when NetworkX
eventually returns. The caller does NOT release in any normal code path.
The one exception: if ``executor.submit()`` itself raises before the
task begins running, the caller must release (no task exists to own
the permit on that failure path).
"""

from __future__ import annotations

import concurrent.futures
import logging
import threading
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# Module-level concurrency primitives — shared across all callers. The
# semaphore gates submit; the executor runs the work.
#
# BoundedSemaphore (not plain Semaphore) — raises ValueError on
# over-release. That's load-bearing for the worker-failure path: if a
# double-release slipped in, a plain Semaphore would silently grow
# beyond 2 permits, defeating the advertised concurrency cap. Bounded
# catches the bug loudly at the over-release site so we can fix it.
_PPR_SEMAPHORE = threading.BoundedSemaphore(2)
_PPR_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
    max_workers=2, thread_name_prefix="ppr",
)


# Design §3.4 defaults.
DEFAULT_ALPHA: float = 0.85
DEFAULT_TOP_K: int = 100
DEFAULT_BUDGET_MS: int = 200


def _run_pagerank(
    graph, seed_item_ids: List[str], alpha: float, top_k: int,
) -> Dict[str, float]:
    """Pure-function pagerank wrapper. Kept as a module-level name so
    tests can monkeypatch it without touching the threading machinery.
    """
    import networkx as nx

    # Build the personalization vector. Unknown seeds are dropped —
    # NetworkX raises on unknown keys.
    known_nodes = set(graph.nodes())
    seed_vec: Dict[str, float] = {}
    for sid in seed_item_ids:
        if sid in known_nodes:
            seed_vec[sid] = 1.0
    if not seed_vec:
        return {}

    scores = nx.pagerank(graph, alpha=alpha, personalization=seed_vec)
    # Truncate to top_k for smaller payloads downstream.
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    return dict(ranked[:top_k])


def personalized_pagerank(
    memory: Any,
    seed_item_ids: List[str],
    *,
    alpha: float = DEFAULT_ALPHA,
    top_k: int = DEFAULT_TOP_K,
    budget_ms: int = DEFAULT_BUDGET_MS,
    cache: Optional[Any] = None,
    workspace_id: Optional[str] = None,
) -> Dict[str, float]:
    """Run personalized PageRank over the caller's workspace subgraph.

    Returns ``{item_id: score}`` for the top-``top_k`` items by PPR
    score. Empty dict on:
    - Empty ``seed_item_ids``.
    - Workspace exceeds ``materialize_workspace_subgraph``'s node cap
      (backend returns None; backend owns the INFO log).
    - Budget exceeded (``budget_ms`` expires before NetworkX returns).
    - Semaphore saturated (2 other PPR tasks already running).
    - Executor submit failure (rare — interpreter shutdown, broken pool).

    Never raises for any of the above; WARN-logged for debugging.
    """
    if not seed_item_ids:
        return {}

    # ── Cache hit path ──────────────────────────────────────────────────
    # Check the cache BEFORE acquiring the semaphore — a hit is a
    # Redis-only operation that doesn't touch the executor, so it
    # shouldn't count against the max-inflight bound.
    if cache is not None and workspace_id:
        from smartmemory.search.ppr_cache import _seed_hash
        cached = cache.get(workspace_id, _seed_hash(seed_item_ids))
        if cached is not None:
            return dict(cached)

    # Short-circuit on saturation before we ever touch the executor.
    if not _PPR_SEMAPHORE.acquire(blocking=False):
        logger.warning(
            "ppr_inflight_saturated — returning empty dict "
            "(2 concurrent PPR tasks already in flight)",
        )
        return {}

    # From here on, the permit is owned by the *submitted task* (via
    # _run_with_semaphore_release) once submit() succeeds. The caller
    # does NOT release in any normal code path — that would be a
    # double-release. The ONE exception is submit() or materialize
    # failure: no task exists yet, so the caller must release.
    try:
        # Materialize inside the critical section so we observe a
        # consistent graph state under the permit.
        graph = memory._graph.backend.materialize_workspace_subgraph()
        if graph is None:
            _PPR_SEMAPHORE.release()
            return {}

        future = _PPR_EXECUTOR.submit(
            _run_with_semaphore_release,
            _run_pagerank, graph, list(seed_item_ids), alpha, top_k,
        )
    except Exception as exc:
        # submit() failed OR materialize raised — permit has no task
        # owner. Release here so we don't leak.
        _PPR_SEMAPHORE.release()
        logger.warning(
            "ppr_executor_submit_failed — returning empty dict: %s",
            exc,
        )
        return {}

    try:
        result = future.result(timeout=budget_ms / 1000.0)
    except concurrent.futures.TimeoutError:
        # Task keeps running; its finally will release the permit
        # when NetworkX eventually returns. New callers arriving
        # during this window short-circuit at acquire().
        logger.warning(
            "ppr_budget_exceeded — returning empty dict "
            "(budget_ms=%d)", budget_ms,
        )
        return {}
    except Exception as exc:
        # Worker raised (NetworkX bug, unexpected graph shape, etc.).
        # The task's finally in _run_with_semaphore_release has ALREADY
        # released the permit. We must NOT release again — that would
        # trip BoundedSemaphore's over-release ValueError and grow the
        # permit count on plain Semaphore. Just log and return {}.
        logger.warning(
            "ppr_worker_failed — returning empty dict: %s", exc,
        )
        return {}

    # ── Cache write ─────────────────────────────────────────────────────
    if cache is not None and workspace_id and result:
        try:
            from smartmemory.search.ppr_cache import _seed_hash
            cache.set(workspace_id, _seed_hash(seed_item_ids), result)
        except Exception as exc:
            logger.debug("ppr: cache.set failed: %s", exc)
    return result


def _run_with_semaphore_release(fn, *args, **kwargs):
    """Task wrapper that runs ``fn`` and always releases the module
    permit in its finally. Bound to the executor at submit time.
    """
    try:
        return fn(*args, **kwargs)
    finally:
        _PPR_SEMAPHORE.release()
