"""Cross-encoder reranking for search results (CORE-RERANK-1).

Reranks search candidates using a cross-encoder that sees query+document
pairs together, improving precision over embedding-only similarity.
Lazy-loads the model on first use; gracefully degrades if unavailable.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass
from datetime import datetime
from typing import List

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"
RERANK_BUDGET_MS = 100  # Best-effort — model.predict() can't be cancelled mid-inference


@dataclass
class RerankerConfig:
    enabled: bool = True  # On by default, transparent to callers
    model: str = DEFAULT_MODEL
    top_k_multiplier: int = 3  # Over-fetch multiplier for candidate pool
    budget_ms: int = RERANK_BUDGET_MS


class CrossEncoderReranker:
    """Lazy-loaded cross-encoder reranker, keyed by model name. Thread-safe."""

    import threading

    _models: dict = {}
    _attempted: set = set()
    _lock = threading.Lock()

    @classmethod
    def get_model(cls, model_name: str = DEFAULT_MODEL):
        """Lazy-load CrossEncoder by name. Returns None if unavailable."""
        # Fast path: already loaded (no lock needed for dict read)
        if model_name in cls._models:
            return cls._models[model_name]
        # Fast path: already failed
        if model_name in cls._attempted:
            return None

        with cls._lock:
            # Double-check after acquiring lock
            if model_name in cls._models:
                return cls._models[model_name]
            if model_name in cls._attempted:
                return None
            try:
                from sentence_transformers import CrossEncoder

                model = CrossEncoder(model_name)
                cls._models[model_name] = model
                logger.info("Loaded cross-encoder: %s", model_name)
                return model
            except Exception as e:
                logger.warning("Cross-encoder %s unavailable: %s", model_name, e)
                cls._attempted.add(model_name)
                return None

    @classmethod
    def reset(cls) -> None:
        """Reset singleton state (for testing)."""
        with cls._lock:
            cls._models = {}
            cls._attempted = set()

    @classmethod
    def rerank(
        cls,
        query: str,
        results: list,
        top_k: int,
        model_name: str = DEFAULT_MODEL,
        budget_ms: int = RERANK_BUDGET_MS,
    ) -> list:
        """Rerank results using cross-encoder scores.

        Args:
            query: Search query string.
            results: List of objects with .content attribute.
            top_k: Number of results to return after reranking.
            model_name: Cross-encoder model identifier.
            budget_ms: Best-effort wall-clock budget in ms.

        Returns:
            Reranked list truncated to top_k. Falls back to
            input order (truncated) if model unavailable or budget exceeded.
        """
        if not results or len(results) <= 1:
            return results[:top_k]

        t0 = time.perf_counter()

        model = cls.get_model(model_name)
        if model is None:
            logger.debug("Reranker unavailable, returning unranked results")
            return results[:top_k]

        # Budget check after model load (first load is slow)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        if elapsed_ms > budget_ms:
            logger.warning(
                "Reranker model load took %.0fms (budget %dms), skipping rerank",
                elapsed_ms,
                budget_ms,
            )
            return results[:top_k]

        # Build query-document pairs
        pairs: List[List[str]] = []
        for r in results:
            content = getattr(r, "content", None) or ""
            pairs.append([query, content[:2000]])

        try:
            scores = model.predict(pairs, show_progress_bar=False)
        except Exception as e:
            logger.warning("Cross-encoder predict failed: %s", e)
            return results[:top_k]

        # Sort by score descending, preserving original objects.
        # Return full pool — caller truncates after temporal_boost (CORE-TEMPORAL-RERANK-1).
        scored = sorted(zip(results, scores, strict=True), key=lambda x: x[1], reverse=True)
        reranked = []
        for item, score in scored:
            # Attach score for downstream consumers (e.g. temporal_boost tier logic)
            try:
                item._rerank_score = float(score)
            except (AttributeError, TypeError):
                pass
            reranked.append(item)

        elapsed_ms = (time.perf_counter() - t0) * 1000
        if elapsed_ms > budget_ms:
            logger.warning(
                "Reranking took %.0fms (budget %dms)",
                elapsed_ms,
                budget_ms,
            )
        else:
            logger.debug(
                "Reranked %d candidates to %d in %.1fms",
                len(results),
                len(reranked),
                elapsed_ms,
            )

        return reranked

    @staticmethod
    def temporal_boost(
        query: str,
        results: list,
        score_tier_threshold: float = 1.0,
    ) -> list:
        """Reorder results by date within score tiers when query has temporal intent.

        Detects temporal keywords and determines direction: "earliest/first/when"
        sorts ascending (oldest first), "latest/most recent/last time" sorts
        descending (newest first). Within each cross-encoder score tier, items
        are re-sorted by date. Across tiers, order is preserved.

        Safe to call on any result list — no-op if no temporal intent.
        """
        if not results or len(results) <= 1:
            return results

        direction = get_temporal_direction(query)
        if not direction:
            return results

        return _tiered_temporal_sort(results, score_tier_threshold, reverse=(direction == "desc"))


# ---------------------------------------------------------------------------
# Module-level helpers (importable for testing)
# ---------------------------------------------------------------------------

_TEMPORAL_EARLIEST_RE = re.compile(
    r"\b("
    r"when|first|how long ago|what date|what time|what year|how many years"
    r"|before|earliest|originally"
    r")\b",
    re.IGNORECASE,
)

_TEMPORAL_LATEST_RE = re.compile(
    r"\b(most recent|latest|last time|after|newest)\b",
    re.IGNORECASE,
)


def has_temporal_intent(query: str) -> bool:
    """Return True if *query* contains a temporal keyword."""
    return bool(_TEMPORAL_EARLIEST_RE.search(query) or _TEMPORAL_LATEST_RE.search(query))


def get_temporal_direction(query: str) -> str:
    """Return 'desc' for newest-first queries, 'asc' for oldest-first, '' for non-temporal."""
    if _TEMPORAL_LATEST_RE.search(query):
        return "desc"
    if _TEMPORAL_EARLIEST_RE.search(query):
        return "asc"
    return ""


# Formats seen in SmartMemory session_date values.
_DATE_FORMATS = [
    "%I:%M %p on %d %B, %Y",   # "1:56 pm on 8 May, 2023"
    "%I:%M %p on %d %b, %Y",   # "1:56 pm on 8 May, 2023" (abbrev month)
    "%d %B, %Y",                # "8 May, 2023"
    "%d %b, %Y",                # "8 May, 2023" (abbrev)
    "%B %d, %Y",                # "May 8, 2023"
    "%b %d, %Y",                # "May 8, 2023" (abbrev)
    "%Y-%m-%dT%H:%M:%S",       # ISO-ish without TZ
    "%Y-%m-%d",                 # ISO date
]

# Sentinel used for items with unparseable / missing dates — sorts last.
_MAX_DT = datetime.max


def parse_session_date(date_str: str) -> datetime:
    """Parse a human-readable session_date string to a datetime.

    Returns ``datetime.max`` if the string is empty or unparseable so
    that such items sort to the end.
    """
    if not date_str:
        return _MAX_DT

    s = date_str.strip()
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue

    # Last resort: try dateutil if available
    try:
        from dateutil.parser import parse as _du_parse

        dt = _du_parse(s)
        # Strip timezone to avoid mixing aware/naive in sort
        return dt.replace(tzinfo=None) if dt.tzinfo else dt
    except Exception:
        logger.debug("Unparseable session_date: %r", date_str)
        return _MAX_DT


def _tiered_temporal_sort(results: list, threshold: float, reverse: bool = False) -> list:
    """Re-sort *results* by date within cross-encoder score tiers.

    A tier boundary is created whenever consecutive results differ by
    more than *threshold* in their ``_rerank_score`` (attached by
    ``CrossEncoderReranker.rerank``).  Within a tier the items are
    sorted by parsed date. *reverse=True* sorts newest-first.
    """
    # Partition into tiers.
    tiers: list[list] = []
    current_tier: list = []
    prev_score: float | None = None

    for item in results:
        score = getattr(item, "_rerank_score", None)
        if prev_score is not None and score is not None and abs(prev_score - score) > threshold:
            tiers.append(current_tier)
            current_tier = []
        current_tier.append(item)
        prev_score = score

    if current_tier:
        tiers.append(current_tier)

    # Sort each tier by parsed date.
    # CORE-TEMPORAL-RERANK-1 + CORE-TEMPORAL-RESOLVE-1: prefer resolved_date/valid_start_time
    # Use direction-aware sentinel: undated items always sort last regardless of direction.
    _sentinel = datetime.min if reverse else _MAX_DT
    out: list = []
    for tier in tiers:
        tier_sorted = sorted(
            tier,
            key=lambda item: (
                _sentinel if _get_temporal_key(item) == _MAX_DT else _get_temporal_key(item)
            ),
            reverse=reverse,
        )
        out.extend(tier_sorted)

    return out


def _get_temporal_key(item) -> datetime:
    """Extract the best temporal key from an item, checking resolved_date first.

    Fallback chain: resolved_date → valid_start_time → session_date → MAX.
    """
    meta = getattr(item, "metadata", None) or {}

    # 1. CORE-TEMPORAL-RESOLVE-1: resolved_date (ISO 8601 string)
    resolved = meta.get("resolved_date")
    if resolved:
        try:
            from dateutil.parser import parse as _dp
            dt = _dp(resolved)
            return dt.replace(tzinfo=None) if dt.tzinfo else dt
        except Exception:
            pass

    # 2. valid_start_time (datetime object from MemoryItem)
    vst = getattr(item, "valid_start_time", None)
    if vst and isinstance(vst, datetime):
        return vst.replace(tzinfo=None) if vst.tzinfo else vst

    # 3. session_date (human-readable string)
    return parse_session_date(meta.get("session_date", ""))
