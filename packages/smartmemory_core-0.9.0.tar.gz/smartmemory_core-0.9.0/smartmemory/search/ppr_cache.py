"""PPR result cache — workspace-scoped, Redis-backed (M3 Slice C.3).

PPR computation on a cold cache is the bottleneck for the p99 budget.
Spike S2 timings (see test_spike_ppr_timing.py) show p99 ~ 25ms for
10k-node workspaces, but that's single-threaded benchmark work with
no contention — production latency is dominated by graph
materialization (the ``MATCH (n) ... RETURN n, r, m`` roundtrip to
FalkorDB) plus network variability.

Caching the ``{item_id: score}`` top-K dict per (workspace, seed_hash)
key, invalidated on any graph mutation in the workspace, lets the
common case ("session sends a series of similar deep queries") hit
the cache on every call after the first.

**Storage.** Redis string value = gzip(pickle({item_id: score, ...})).
Gzip brings 100-item × ~40-byte-key-value pairs from ~5KB to ~1KB;
negligible CPU cost for the compression step.

**TTL.** 300 seconds. A PPR vector is stable on a frozen graph for
minutes-to-hours; the TTL is a secondary safety net on top of the
write-through invalidation. Bounds the staleness window if
invalidation has a Redis blip.

**Invalidation.** ``invalidate_workspace(workspace_id)`` does a
``SCAN MATCH sm:ppr:{ws}:* | DEL`` pass. Wrapped with a
debouncer so bulk imports that emit hundreds of mutations in a
burst produce a single SCAN+DEL rather than a storm. Debounce
window configurable via the ``invalidation_debounce_ms`` constructor
kwarg (default 1000ms).
"""

from __future__ import annotations

import gzip
import hashlib
import logging
import pickle
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


_CACHE_KEY_TEMPLATE = "sm:ppr:{workspace_id}:{seed_hash}"
_DEFAULT_TTL_SECONDS = 300
_DEFAULT_DEBOUNCE_MS = 1000


def _seed_hash(seed_item_ids: List[str]) -> str:
    """Order-stable short hash of a seed list for cache keys.

    Sorts the ids so ``[a, b, c]`` and ``[c, a, b]`` produce the same
    key — PPR is permutation-invariant over seeds (they're multiplied
    into a personalization vector), so the cache key should be too.
    """
    material = ",".join(sorted(seed_item_ids))
    return hashlib.sha1(material.encode("utf-8")).hexdigest()[:12]


class PPRCache:
    """Workspace-scoped Redis cache for PPR result dicts.

    Safe to call with a Redis client that's offline — get/set/invalidate
    all no-op and log DEBUG on Redis errors.
    """

    def __init__(
        self,
        redis_client: Any,
        ttl_seconds: int = _DEFAULT_TTL_SECONDS,
        invalidation_debounce_ms: int = _DEFAULT_DEBOUNCE_MS,
    ):
        self._r = redis_client
        self._ttl = int(ttl_seconds)
        self._debounce_ms = int(invalidation_debounce_ms)
        # Per-workspace last-scan timestamp. Debouncing short-circuits
        # subsequent invalidations inside the window.
        self._last_invalidation: Dict[str, float] = {}
        self._lock = threading.Lock()

    # ── Read / Write ────────────────────────────────────────────────────

    def get(self, workspace_id: str, seed_hash: str) -> Optional[Dict[str, float]]:
        """Return the cached dict or None on miss/error."""
        key = _CACHE_KEY_TEMPLATE.format(
            workspace_id=workspace_id, seed_hash=seed_hash,
        )
        try:
            raw = self._r.get(key)
        except Exception as exc:
            logger.debug("PPRCache.get: redis error: %s", exc)
            return None
        if raw is None:
            return None
        try:
            # Accept both str (fake/redis with decode_responses=True)
            # and bytes (the gzipped pickle we actually write).
            if isinstance(raw, str):
                raw = raw.encode("latin1")
            return pickle.loads(gzip.decompress(raw))
        except Exception as exc:
            logger.debug("PPRCache.get: deserialize error: %s", exc)
            return None

    def set(
        self,
        workspace_id: str,
        seed_hash: str,
        scores: Dict[str, float],
    ) -> None:
        """Write the gzipped pickle to Redis with TTL."""
        key = _CACHE_KEY_TEMPLATE.format(
            workspace_id=workspace_id, seed_hash=seed_hash,
        )
        try:
            payload = gzip.compress(pickle.dumps(dict(scores)))
            # Redis client may need str — fallback for fakes.
            try:
                self._r.set(key, payload, ex=self._ttl)
            except TypeError:
                self._r.set(key, payload.decode("latin1"), ex=self._ttl)
        except Exception as exc:
            logger.debug("PPRCache.set: redis error: %s", exc)

    # ── Invalidation ────────────────────────────────────────────────────

    def invalidate_workspace(self, workspace_id: str) -> None:
        """Scan+delete all cache entries for ``workspace_id``.

        Debounced: invocations within ``invalidation_debounce_ms`` of
        the last scan for the same workspace are no-ops. This is the
        fix for the bulk-import storm pattern where a single ingest
        pass can emit hundreds of graph mutations.
        """
        now_ms = time.monotonic() * 1000.0
        with self._lock:
            last = self._last_invalidation.get(workspace_id, 0.0)
            if (now_ms - last) < self._debounce_ms:
                return  # debounced — recent invalidation still in window
            self._last_invalidation[workspace_id] = now_ms

        pattern = _CACHE_KEY_TEMPLATE.format(
            workspace_id=workspace_id, seed_hash="*",
        )
        try:
            to_delete = list(self._r.scan_iter(match=pattern, count=100))
        except Exception as exc:
            logger.debug(
                "PPRCache.invalidate_workspace: scan_iter failed: %s", exc,
            )
            return
        if not to_delete:
            return
        try:
            self._r.delete(*to_delete)
        except Exception as exc:
            logger.debug(
                "PPRCache.invalidate_workspace: delete failed: %s", exc,
            )
