"""Fuzzy entity resolution via workspace-scoped embedding index (CORE-ENTITY-RESOLVE-1).

Provides a third search tier that activates when Cypher exact/alias matching returns
fewer than top_k results. Builds a per-workspace embedding index of canonical entity
names on first use (cold-start pattern matching CrossEncoderReranker). Subsequent
queries use cosine similarity for fast approximate matching.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


@dataclass
class EntityResolveConfig:
    enabled: bool = True
    alias_discount: float = 0.85
    fuzzy_discount: float = 0.70
    embedding_threshold: float = 0.75
    fuzzy_budget_ms: int = 50
    min_chain_length: int = 2
    alias_stoplist: set[str] = field(default_factory=lambda: {
        "he", "she", "they", "it", "this", "that",
        "the company", "the organization", "the team",
        "the group", "the person",
        "him", "her", "them", "his", "its", "their",
        "who", "whom", "whose",
    })


@dataclass
class EntityMatch:
    entity_node_id: str
    entity_name: str
    entity_type: str
    similarity_score: float


@dataclass
class _EntityIndex:
    """Internal index structure holding entity embeddings for one workspace."""

    entity_names: list[str]
    entity_types: list[str]
    entity_node_ids: list[str]
    embeddings: np.ndarray  # shape (N, embedding_dim), L2-normalized
    version: int


class EntityResolver:
    """Workspace-scoped embedding index for fuzzy entity matching.

    Thread-safe lazy index building — follows CrossEncoderReranker pattern
    from rerank.py. Returns [] (cold-start) while the index builds in the
    background; subsequent calls use the completed index.
    """

    _lock = threading.Lock()

    def __init__(self, config: EntityResolveConfig | None = None, backend: Any = None):
        self._config = config or EntityResolveConfig()
        self._backend = backend
        # (workspace_id, version) -> _EntityIndex
        self._indexes: dict[tuple[str, int], _EntityIndex] = {}
        # workspace_id -> current version counter
        self._versions: dict[str, int] = {}
        # workspace_ids currently building in background
        self._building: set[str] = set()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def resolve(self, query_tokens: list[str], workspace_id: str, top_k: int = 5) -> list[EntityMatch]:
        """Return up to top_k fuzzy entity matches for query_tokens.

        Returns [] on cold-start (index not ready yet) or if embeddings
        are unavailable. Budget enforcement via fuzzy_budget_ms.
        """
        if not self._config.enabled:
            return []

        # Normalize None/empty workspace to "default" (matches _build_index_async)
        workspace_id = workspace_id or "default"

        index = self._get_index(workspace_id)
        if index is None:
            self._trigger_build(workspace_id)
            return []

        if index.embeddings is None or len(index.entity_names) == 0:
            return []

        t0 = time.perf_counter()

        query_text = " ".join(query_tokens)
        from smartmemory.plugins.embedding import create_embeddings

        query_vec = create_embeddings(query_text)
        if query_vec is None:
            return []

        # L2-normalize query vector for cosine similarity via dot product
        norm = np.linalg.norm(query_vec)
        if norm < 1e-9:
            return []
        query_vec = query_vec / norm

        # Budget check before expensive dot product
        elapsed_ms = (time.perf_counter() - t0) * 1000
        if elapsed_ms > self._config.fuzzy_budget_ms:
            logger.warning(
                "EntityResolver.resolve() budget exceeded before similarity (%.0fms / %dms)",
                elapsed_ms,
                self._config.fuzzy_budget_ms,
            )
            return []

        # Cosine similarity: dot product (index embeddings are L2-normalized)
        similarities = index.embeddings @ query_vec  # shape (N,)

        # Filter by threshold
        above_threshold = np.where(similarities >= self._config.embedding_threshold)[0]
        if len(above_threshold) == 0:
            return []

        # Sort descending by similarity
        sorted_idxs = above_threshold[np.argsort(similarities[above_threshold])[::-1]]

        matches: list[EntityMatch] = []
        for idx in sorted_idxs[:top_k]:
            elapsed_ms = (time.perf_counter() - t0) * 1000
            if elapsed_ms > self._config.fuzzy_budget_ms:
                logger.warning(
                    "EntityResolver.resolve() budget exceeded during collection (%.0fms / %dms)",
                    elapsed_ms,
                    self._config.fuzzy_budget_ms,
                )
                break
            matches.append(
                EntityMatch(
                    entity_node_id=index.entity_node_ids[idx],
                    entity_name=index.entity_names[idx],
                    entity_type=index.entity_types[idx],
                    similarity_score=float(similarities[idx]),
                )
            )

        return matches

    def invalidate(self, workspace_id: str) -> None:
        """Increment workspace version so the next resolve() triggers a rebuild.

        Called after canonical entity nodes are created (not for alias stubs).
        """
        with self._lock:
            self._versions[workspace_id] = self._versions.get(workspace_id, 0) + 1
            # Remove stale index entries for this workspace
            stale = [k for k in self._indexes if k[0] == workspace_id]
            for k in stale:
                del self._indexes[k]
        logger.debug("EntityResolver: invalidated index for workspace %s", workspace_id)

    def reset(self, workspace_id: str | None = None) -> None:
        """Clear index state — used in tests to ensure a clean slate."""
        with self._lock:
            if workspace_id is None:
                self._indexes.clear()
                self._versions.clear()
                self._building.clear()
            else:
                stale = [k for k in self._indexes if k[0] == workspace_id]
                for k in stale:
                    del self._indexes[k]
                self._versions.pop(workspace_id, None)
                self._building.discard(workspace_id)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_index(self, workspace_id: str) -> _EntityIndex | None:
        """Fast-path index lookup without acquiring lock."""
        version = self._versions.get(workspace_id, 0)
        return self._indexes.get((workspace_id, version))

    def _trigger_build(self, workspace_id: str) -> None:
        """Spawn a background thread to build the index if not already building."""
        # Fast path: already building
        if workspace_id in self._building:
            return

        with self._lock:
            # Double-check after acquiring lock
            if workspace_id in self._building:
                return
            # Also check if index appeared while we were waiting for lock
            version = self._versions.get(workspace_id, 0)
            if (workspace_id, version) in self._indexes:
                return

            self._building.add(workspace_id)

        thread = threading.Thread(
            target=self._build_index_sync,
            args=(workspace_id,),
            daemon=True,
            name=f"entity-index-{workspace_id}",
        )
        thread.start()
        logger.debug("EntityResolver: triggered background index build for workspace %s", workspace_id)

    def _build_index_sync(self, workspace_id: str) -> None:
        """Build embedding index for all canonical entity nodes in workspace.

        Runs in a daemon thread. Atomically swaps the index in on completion.
        Excludes alias stub nodes (node_category='alias').
        """
        try:
            self._build_index_async(workspace_id)
        finally:
            with self._lock:
                self._building.discard(workspace_id)

    def _build_index_async(self, workspace_id: str) -> None:
        """Core index build logic. Called from daemon thread."""
        if self._backend is None:
            logger.warning("EntityResolver: no backend set, cannot build index")
            return

        from smartmemory.plugins.embedding import create_embeddings

        # CORE-ENTITY-RESOLVE-1 hardening: capture version at build START, not end.
        # If invalidate() bumps the version during build, this build's snapshot
        # is stale and must not overwrite the new version's slot.
        build_version = self._versions.get(workspace_id, 0)

        # Normalize None workspace to "default" so Cypher equality works (NULL != NULL)
        ws_id = workspace_id or "default"

        # Query all canonical entity nodes for this workspace
        # Exclude alias stubs (node_category='alias')
        query = """
        MATCH (e)
        WHERE (e.node_category = 'entity' OR e.memory_type = 'entity')
          AND coalesce(e.node_category, 'entity') <> 'alias'
          AND coalesce(e.workspace_id, 'default') = $workspace_id
        RETURN e.item_id, e.name, e.content, coalesce(e.entity_type, '') AS entity_type
        """
        try:
            res = self._backend._query(query, {"workspace_id": ws_id})
        except Exception as exc:
            logger.warning("EntityResolver: index build query failed: %s", exc)
            return

        if not res:
            logger.debug("EntityResolver: no entity nodes found for workspace %s", workspace_id)
            # Store empty index so we stop triggering builds.
            # Use build_version (captured at start) — if invalidated during build,
            # current version will be higher and this stale entry won't be found.
            empty_index = _EntityIndex(
                entity_names=[],
                entity_types=[],
                entity_node_ids=[],
                embeddings=np.empty((0, 1), dtype=np.float32),
                version=build_version,
            )
            with self._lock:
                # Only store if version hasn't been bumped since build started
                current_version = self._versions.get(workspace_id, 0)
                if current_version == build_version:
                    self._indexes[(workspace_id, build_version)] = empty_index
            return

        # Collect entity metadata
        entity_ids: list[str] = []
        entity_names: list[str] = []
        entity_types: list[str] = []
        raw_names: list[str] = []

        for record in res:
            item_id = record[0]
            name = record[1] or record[2] or ""  # name, fallback to content
            etype = record[3] if len(record) > 3 else ""
            if not item_id or not name:
                continue
            entity_ids.append(str(item_id))
            entity_names.append(str(name))
            entity_types.append(str(etype))
            raw_names.append(str(name))

        if not entity_ids:
            logger.debug("EntityResolver: all entity records had empty ids/names for workspace %s", workspace_id)
            return

        # Build embeddings — one call per entity (no batch API)
        embeddings_list: list[np.ndarray] = []
        valid_ids: list[str] = []
        valid_names: list[str] = []
        valid_types: list[str] = []

        for i, name in enumerate(raw_names):
            vec = create_embeddings(name)
            if vec is None:
                continue
            norm = np.linalg.norm(vec)
            if norm < 1e-9:
                continue
            embeddings_list.append(vec / norm)
            valid_ids.append(entity_ids[i])
            valid_names.append(entity_names[i])
            valid_types.append(entity_types[i])

        if not embeddings_list:
            logger.warning("EntityResolver: embedding generation returned None for all %d entities", len(raw_names))
            return

        # Filter to a single consistent dimension — mixed cache (e.g. 1536 from
        # OpenAI + 384 from local model) would crash np.stack.
        target_dim = embeddings_list[0].shape[0]
        filtered_idx = [i for i, v in enumerate(embeddings_list) if v.shape[0] == target_dim]
        if len(filtered_idx) < len(embeddings_list):
            dropped = len(embeddings_list) - len(filtered_idx)
            logger.warning(
                "EntityResolver: dropped %d/%d embeddings with mismatched dimensions (expected %d)",
                dropped, len(embeddings_list), target_dim,
            )
            embeddings_list = [embeddings_list[i] for i in filtered_idx]
            valid_ids = [valid_ids[i] for i in filtered_idx]
            valid_names = [valid_names[i] for i in filtered_idx]
            valid_types = [valid_types[i] for i in filtered_idx]

        if not embeddings_list:
            logger.warning("EntityResolver: no embeddings with consistent dimensions for workspace %s", workspace_id)
            return

        embeddings = np.stack(embeddings_list, axis=0).astype(np.float32)
        index = _EntityIndex(
            entity_names=valid_names,
            entity_types=valid_types,
            entity_node_ids=valid_ids,
            embeddings=embeddings,
            version=build_version,
        )

        with self._lock:
            # Only store if version hasn't been bumped since build started.
            # If invalidate() was called during build, current_version > build_version
            # and this stale snapshot is silently discarded.
            current_version = self._versions.get(workspace_id, 0)
            if current_version != build_version:
                logger.info(
                    "EntityResolver: discarding stale index build for workspace %s "
                    "(build_version=%d, current_version=%d)",
                    workspace_id,
                    build_version,
                    current_version,
                )
                return
            self._indexes[(workspace_id, build_version)] = index

        logger.info(
            "EntityResolver: built index for workspace %s — %d entities (v%d)",
            workspace_id,
            len(valid_ids),
            build_version,
        )
