"""SurfacingRouter — query-side strategy classifier (M3 Slice A).

Query-time mirror of the ingest-time ``ConsolidationRouter``
(``smartmemory/pipeline/router.py``): classifies an incoming query
into one of a small fixed set of retrieval strategies so downstream
surfacing can pick an appropriate channel mix.

The classifier is heuristic at M3 ship — no LLM call on the hot path.
The rule table below clears the LoCoMo-style conversational-vs-analytical
distinction (see parent design.md §301 / IDEA-73). An LLM classifier is
a planned follow-up.

**Reserved strategies.** ``procedural:lookup`` and ``temporal:windowed``
are present in the enum for forward-compat but are not shipped in M3;
the surfacing code soft-degrades them to ``fast:recency`` with an
explicit reason flag in the response.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

# Deep-signal keywords fire Rule 1 regardless of other features.
# Use word-boundary regex to avoid false positives: e.g. "show" contains
# "how" as a substring but isn't a question.
_DEEP_SIGNAL_KEYWORDS = ("why", "how", "what caused", "explain")
_DEEP_SIGNAL_RE = re.compile(
    r"\b(" + "|".join(re.escape(kw) for kw in _DEEP_SIGNAL_KEYWORDS) + r")\b",
    re.IGNORECASE,
)

# Recency-signal keywords force rule-2 skip → fast:recency fallback.
# (Codex r3 design fix — design-m3.md §3.2.)
_RECENCY_SIGNALS = (
    "recent", "latest", "newest", "today", "yesterday",
)

# Rule 2 lookup-noun prefixes (followed by whitespace or "of").
_LOOKUP_PREFIXES = ("list", "show", "get", "find", "all")

# Bare-noun pattern: optional "the ", then a single word optionally
# pluralized. Matches "users", "the user", "decisions", "the plan".
_BARE_NOUN_RE = re.compile(r"^(the\s+)?\w+s?$", re.IGNORECASE)

# Question-word prefix — if rule 2 query starts with these, it's a
# question, not a factual lookup; fall through to rule 3.
_QUESTION_WORDS = ("what", "who", "where", "when", "why", "which", "whose", "how")

# Length threshold for rule 1.
_LONG_QUERY_CHARS = 80

# Entity-count threshold for rule 1 (2+ entities → analytical).
_DEEP_ENTITY_COUNT = 2

# Rule 2 short-query cap (≤ 6 words).
_FACTUAL_MAX_WORDS = 6


class SurfacingStrategy(str, Enum):
    """Retrieval strategies the surfacing layer can dispatch on.

    Shipped in M3: ``FAST_RECENCY``, ``DEEP_MULTI_HOP``, ``FACTUAL_POINT``.
    Reserved for follow-up: ``PROCEDURAL_LOOKUP``, ``TEMPORAL_WINDOWED``.
    """

    FAST_RECENCY = "fast:recency"
    DEEP_MULTI_HOP = "deep:multi-hop"
    FACTUAL_POINT = "factual:point-query"
    PROCEDURAL_LOOKUP = "procedural:lookup"
    TEMPORAL_WINDOWED = "temporal:windowed"


@dataclass
class SurfacingDecision:
    """Record of a single surfacing-router decision.

    Mirror of ``pipeline.router.RouterDecision`` shape for consistency.

    Fields:
        strategy:   Chosen :class:`SurfacingStrategy`.
        confidence: 0.0 – 1.0 confidence in the chosen strategy.
        reasons:    Ordered human-readable signals (one per rule that
                    fired) for the audit trail.
        signals:    Raw query features (length, word count, detected
                    entities, etc.) — reproducible reasoning payload.
    """

    strategy: SurfacingStrategy
    confidence: float
    reasons: List[str] = field(default_factory=list)
    signals: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "strategy": self.strategy.value,
            "confidence": self.confidence,
            "reasons": list(self.reasons),
            "signals": dict(self.signals),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SurfacingDecision":
        return cls(
            strategy=SurfacingStrategy(data["strategy"]),
            confidence=float(data["confidence"]),
            reasons=list(data.get("reasons", [])),
            signals=dict(data.get("signals", {})),
        )


class SurfacingRouter:
    """Classify queries into retrieval strategies using a rule table.

    Stateless — classification is a pure function of the query plus an
    optional context dict (detected entities, session flags).
    Session-aware routing (e.g. "this session prefers deep queries") is
    a planned follow-up if the heuristic floor proves insufficient.
    """

    def classify(
        self, query: str, context: Optional[Dict[str, Any]] = None,
    ) -> SurfacingDecision:
        """Return the strategy to use for ``query``.

        Rules evaluated top-to-bottom; first match wins.
        """
        context = context or {}
        q = query or ""
        lower = q.lower()
        words = q.split()
        signals = {
            "query_length": len(q),
            "word_count": len(words),
            "entity_count": int(context.get("entity_count", 0)),
        }

        # ── Rule 1: deep:multi-hop ──────────────────────────────────────
        keyword_hits = [m.group(0).lower() for m in _DEEP_SIGNAL_RE.finditer(lower)]
        entity_count = signals["entity_count"]
        long_query = signals["query_length"] > _LONG_QUERY_CHARS

        if keyword_hits or entity_count >= _DEEP_ENTITY_COUNT or long_query:
            reasons: List[str] = []
            for kw in keyword_hits:
                reasons.append(f"keyword:{kw}")
            if entity_count >= _DEEP_ENTITY_COUNT:
                reasons.append(f"entity_count:{entity_count}")
            if long_query:
                reasons.append(f"length:{signals['query_length']}")
            return SurfacingDecision(
                strategy=SurfacingStrategy.DEEP_MULTI_HOP,
                confidence=0.75,
                reasons=reasons,
                signals=signals,
            )

        # ── Rule 2: factual:point-query ─────────────────────────────────
        # Hard-skip if the query carries a recency signal — those are
        # recency-scoped and route to fast:recency regardless of shape.
        recency_hit = next(
            (w for w in _RECENCY_SIGNALS if w in lower), None,
        )
        if recency_hit:
            return SurfacingDecision(
                strategy=SurfacingStrategy.FAST_RECENCY,
                confidence=0.8,
                reasons=[f"recency_signal:{recency_hit}"],
                signals=signals,
            )

        # No question words at the start (would be rule 3 territory).
        starts_with_question = bool(words) and words[0].lower() in _QUESTION_WORDS
        # Short query.
        short_enough = 0 < len(words) <= _FACTUAL_MAX_WORDS

        if short_enough and not starts_with_question:
            # Lookup-prefix match: "list of users", "show decisions", ...
            first_word = words[0].lower().rstrip(",")
            if first_word in _LOOKUP_PREFIXES:
                return SurfacingDecision(
                    strategy=SurfacingStrategy.FACTUAL_POINT,
                    confidence=0.7,
                    reasons=[f"lookup_prefix:{first_word}"],
                    signals=signals,
                )
            # Bare-noun regex: "users", "the user", ...
            if _BARE_NOUN_RE.match(q.strip()):
                return SurfacingDecision(
                    strategy=SurfacingStrategy.FACTUAL_POINT,
                    confidence=0.65,
                    reasons=["bare_noun"],
                    signals=signals,
                )
            # Single-entity detection (caller-provided).
            if entity_count == 1:
                return SurfacingDecision(
                    strategy=SurfacingStrategy.FACTUAL_POINT,
                    confidence=0.7,
                    reasons=["single_entity"],
                    signals=signals,
                )

        # ── Rule 3: fast:recency fallback ───────────────────────────────
        return SurfacingDecision(
            strategy=SurfacingStrategy.FAST_RECENCY,
            confidence=0.5,
            reasons=["fallback"],
            signals=signals,
        )
