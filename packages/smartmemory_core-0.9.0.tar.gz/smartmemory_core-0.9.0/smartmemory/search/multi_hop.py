"""Multi-hop recursive retrieval with heuristic hop planning (RLM-1c, CORE-MULTIHOP-2).

Parallel multi-chain: each hop produces up to MAX_PARALLEL_CHAINS follow-up
queries from the top-scoring novel entities in the results. All chains are
searched in parallel per hop. Budget cascading prevents runaway searches.
Cross-hop results merged via weighted RRF with hop-decay.

CORE-MULTIHOP-2 Phase 2: optional SemanticHopPlanner uses an LLM to reason
about optimal next hop given user intent + current results. Opt-in via
SemanticHopConfig or `semantic_hops=True` on search().
"""

from __future__ import annotations

import inspect
import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# Defaults
HOP_DECAY = 0.7           # Each successive hop weighted 0.7x the previous
MIN_HOP_BUDGET_MS = 100   # Don't start a new hop with less than this remaining
MIN_ENTITY_SCORE = 0.3    # Below this, entity is not worth following up
TOP_K_FOR_PLANNING = 3    # Examine top N results for entity extraction
MAX_PARALLEL_CHAINS = 3   # Max follow-up queries per hop (CORE-MULTIHOP-2)
SEMANTIC_HOP_MAX_CONTENT_CHARS = 200  # Per-result content truncation for LLM context
SEMANTIC_HOP_BUDGET_MS = 500          # Default per-hop LLM call budget
SEMANTIC_HOP_MAX_TOKENS = 200         # Default LLM response token cap

# Module-level pool for SemanticHopPlanner LLM calls.
# Do NOT use `with ThreadPoolExecutor() as pool:` — shutdown(wait=True) blocks on timeout.
_LLM_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="semantic_hop")


# ---------------------------------------------------------------------------
# VIS-PIPELINE-DAG-1: progress emission helpers (Phase 1a + Codex Round 1 fixes)
#
# Multi-hop search is invoked from many entry points (HTTP search route, agent
# SDKs, CLI). To satisfy the contract invariant that `pipeline.dag` is emitted
# exactly once per run with seq=0, multi-hop owns its own progress run when
# called outside a bound context (binds a fresh run_id), and skips the DAG
# emission entirely when nested inside another run (no per-run topology
# claim). Per-hop pipeline.stage events still fire in both modes so consumers
# get hop-by-hop telemetry either way.
#
# Failures here are non-fatal — they never break search. Bound-context
# failures escalate to WARNING (per no-silent-degradation.md); pre-bind path
# stays at debug.
# ---------------------------------------------------------------------------


def _progress_bound() -> bool:
    """Return True iff a progress context is bound in the current contextvar."""
    try:
        from smartmemory.progress import _run_id, _scope
        return _run_id.get() is not None and _scope.get() is not None
    except Exception:
        return False


def _emit_multi_hop_dag_if_owns_run(max_hops: int) -> None:
    """Emit pipeline.dag only when this call owns the bound run.

    Caller is expected to have just bound a fresh run for multi-hop. If we
    detect that other events have already been emitted on the current run
    (i.e. this is nested), skip the DAG emission — the outer producer owns
    the per-run pipeline.dag invariant.
    """
    if not _progress_bound():
        return
    try:
        from smartmemory.progress import _run_id, _seq_counters, emit as progress_emit
        from smartmemory.pipeline.dag import PipelineDag, DagNode, DagEdge

        run_id = _run_id.get()
        # If anything has already been emitted on this run, we're nested —
        # don't claim per-run topology ownership.
        if _seq_counters.get(run_id, 0) > 0:
            return

        nodes = [
            DagNode(id=f"hop_{i}", label=f"Hop {i}", kind="stage")
            for i in range(max_hops)
        ]
        edges = [
            DagEdge(from_id=f"hop_{i}", to_id=f"hop_{i + 1}", kind="sequence")
            for i in range(max_hops - 1)
        ]
        dag = PipelineDag(pipeline="multi_hop_search", nodes=nodes, edges=edges)
        progress_emit(
            kind="pipeline.dag",
            status="ok",
            stage=None,
            payload=dag.to_payload(),
        )
    except Exception as exc:
        logger.warning("VIS-PIPELINE-DAG-1: multi_hop pipeline.dag emit failed: %s", exc)


def _emit_multi_hop_stage(hop_num: int, status: str, **payload_extra) -> None:
    """Emit a pipeline.stage event for one hop boundary.

    Captures ts once and pins both top-level ts and payload.original_ts to it,
    per PayloadConventions: "original_ts MUST equal the top-level ts at first
    emission" for replay-participating events.
    """
    if not _progress_bound():
        return
    try:
        import time as _time
        from smartmemory.progress import emit as progress_emit

        ts = _time.time()
        payload = {"original_ts": ts, **payload_extra}
        progress_emit(
            kind="pipeline.stage",
            status=status,
            stage=f"hop_{hop_num}",
            payload=payload,
            _ts=ts,
        )
    except Exception as exc:
        logger.warning("VIS-PIPELINE-DAG-1: multi_hop stage emit failed: %s", exc)


def _emit_multi_hop_timeout(completed_hop: int, budget_remaining_ms: float) -> None:
    """Emit terminal warn/timed_out on the hop that exhausted the budget.

    Stage identity is the *completed* hop whose work overran — not the
    never-started next hop. This matches consumer expectations: "this hop
    finished but consumed all remaining budget; no further hops will run."
    """
    if not _progress_bound():
        return
    try:
        import time as _time
        from smartmemory.progress import emit as progress_emit

        ts = _time.time()
        progress_emit(
            kind="pipeline.stage",
            status="warn",
            stage=f"hop_{completed_hop}",
            payload={
                "original_ts": ts,
                "reason": "timed_out",
                "budget_remaining_ms": budget_remaining_ms,
            },
            _ts=ts,
        )
    except Exception as exc:
        logger.warning("VIS-PIPELINE-DAG-1: multi_hop timeout emit failed: %s", exc)


@dataclass
class HopPlan:
    follow_up_query: Optional[str] = None
    follow_up_queries: List[str] = field(default_factory=list)
    source_entities: List[str] = field(default_factory=list)
    confidence: float = 0.0
    stop: bool = False


@dataclass
class HopResult:
    hop_num: int
    query: str
    results: list  # List[MemoryItem]
    elapsed_ms: float
    entities_found: List[str] = field(default_factory=list)
    chain_queries: List[str] = field(default_factory=list)  # Actual queries for loop detection


@dataclass
class SemanticHopConfig:
    """Configuration for LLM-driven semantic hop planning (CORE-MULTIHOP-2 Phase 2)."""

    enabled: bool = False
    model: Optional[str] = "haiku"  # Bare alias for Claude Agent SDK routing
    budget_ms: int = SEMANTIC_HOP_BUDGET_MS
    max_output_tokens: int = SEMANTIC_HOP_MAX_TOKENS
    fallback_to_heuristic: bool = True


class HopPlanner:
    """Heuristic hop planning — extracts entities from result metadata."""

    def plan_next_hop(
        self,
        original_query: str,
        results: list,
        hop_num: int,
        seen_entities: set,
        **kwargs,
    ) -> HopPlan:
        """Decide follow-up query from current hop results.

        Args:
            original_query: The user's original search query.
            results: Results from the current hop.
            hop_num: Which hop we're planning (1-based).
            seen_entities: Entities already seen in previous hops.
            **kwargs: Forward-compat for seen_queries and future params.

        Returns:
            HopPlan with follow_up_query (or stop=True).
        """
        if not results:
            return HopPlan(stop=True)

        # Extract entities from top results' metadata
        candidates: Dict[str, int] = {}  # entity_name -> frequency
        for item in results[:TOP_K_FOR_PLANNING]:
            entities = []
            md = getattr(item, "metadata", None) or {}
            if isinstance(md, dict):
                entities = md.get("entities", [])
            for ent in entities:
                name = ent.get("name", "") if isinstance(ent, dict) else str(ent)
                name = name.strip()
                if not name:
                    continue
                # Skip entities already in original query or seen before
                if name.lower() in original_query.lower():
                    continue
                if name.lower() in seen_entities:
                    continue
                candidates[name] = candidates.get(name, 0) + 1

        if not candidates:
            return HopPlan(stop=True)

        # Score: frequency / total_candidates — rewards consensus, penalizes noise
        total_candidates = len(candidates)
        scored = sorted(candidates.items(), key=lambda x: x[1], reverse=True)
        top_entity, freq = scored[0]
        confidence = min(freq / max(total_candidates, 1), 1.0)

        if confidence < MIN_ENTITY_SCORE:
            return HopPlan(stop=True)

        # CORE-MULTIHOP-2: collect up to MAX_PARALLEL_CHAINS entities above threshold
        follow_ups: List[str] = []
        source_ents: List[str] = []
        for entity_name, entity_freq in scored[:MAX_PARALLEL_CHAINS]:
            entity_confidence = min(entity_freq / max(total_candidates, 1), 1.0)
            if entity_confidence < MIN_ENTITY_SCORE:
                break
            follow_ups.append(entity_name)
            source_ents.append(entity_name)

        return HopPlan(
            follow_up_query=follow_ups[0] if follow_ups else None,
            follow_up_queries=follow_ups,
            source_entities=source_ents,
            confidence=confidence,
            stop=False,
        )


class SemanticHopPlanner(HopPlanner):
    """LLM-driven hop planning — reasons about optimal next query (CORE-MULTIHOP-2 Phase 2).

    Uses a fast LLM (haiku/flash) to infer implicit connections, temporal/causal
    chains, and semantic equivalences that the heuristic planner misses. Falls back
    to the heuristic planner on timeout, parse failure, or any exception.
    """

    def __init__(self, config: Optional[SemanticHopConfig] = None):
        self._config = config or SemanticHopConfig()

    def plan_next_hop(
        self,
        original_query: str,
        results: list,
        hop_num: int,
        seen_entities: set,
        **kwargs,
    ) -> HopPlan:
        """Plan next hop using LLM reasoning, with heuristic fallback."""
        if not results:
            return HopPlan(stop=True)

        seen_queries: List[str] = kwargs.get("seen_queries") or []

        # Build LLM context
        results_summary = self._summarize_results(results)
        prompt = self._build_prompt(original_query, results_summary, hop_num, seen_queries)

        try:
            from smartmemory.utils.llm import call_llm

            future = _LLM_POOL.submit(
                call_llm,
                model=self._config.model,
                user_content=prompt,
                max_output_tokens=self._config.max_output_tokens,
                temperature=0.0,
                response_format={"type": "json_object"},
                config_section="search",
            )
            parsed_result, raw_response = future.result(
                timeout=self._config.budget_ms / 1000.0,
            )
        except TimeoutError:
            logger.warning(
                "semantic_hop: LLM call exceeded budget (%dms), falling back to heuristic",
                self._config.budget_ms,
            )
            if self._config.fallback_to_heuristic:
                return super().plan_next_hop(original_query, results, hop_num, seen_entities)
            return HopPlan(stop=True)
        except Exception as exc:
            logger.warning("semantic_hop: LLM call failed (%s), falling back to heuristic", exc)
            if self._config.fallback_to_heuristic:
                return super().plan_next_hop(original_query, results, hop_num, seen_entities)
            return HopPlan(stop=True)

        # Parse response
        result_dict = parsed_result
        if result_dict is None and raw_response:
            try:
                result_dict = json.loads(raw_response)
            except (json.JSONDecodeError, TypeError):
                pass

        if not result_dict or not isinstance(result_dict, dict):
            logger.warning("semantic_hop: LLM returned unparseable response, falling back to heuristic")
            if self._config.fallback_to_heuristic:
                return super().plan_next_hop(original_query, results, hop_num, seen_entities)
            return HopPlan(stop=True)

        # Normalize response — wrapped in try/except so malformed LLM output
        # (e.g. confidence="high", follow_up_queries=null) always falls back safely
        try:
            raw_queries = result_dict.get("follow_up_queries") or []
            if isinstance(raw_queries, str):
                raw_queries = [raw_queries]  # Single string → list
            follow_ups = self._normalize_queries(raw_queries)
            raw_confidence = result_dict.get("confidence", 0.5)
            try:
                confidence = max(0.0, min(1.0, float(raw_confidence)))
            except (TypeError, ValueError):
                confidence = 0.5
        except Exception as exc:
            logger.warning("semantic_hop: response normalization failed (%s), falling back to heuristic", exc)
            if self._config.fallback_to_heuristic:
                return super().plan_next_hop(original_query, results, hop_num, seen_entities)
            return HopPlan(stop=True)

        if not follow_ups:
            return HopPlan(stop=True, confidence=confidence)

        return HopPlan(
            follow_up_query=follow_ups[0],
            follow_up_queries=follow_ups,
            source_entities=[],  # LLM doesn't extract entities — semantic queries instead
            confidence=confidence,
            stop=False,
        )

    @staticmethod
    def _normalize_queries(raw_queries: list) -> List[str]:
        """Strip, dedupe, and cap follow-up queries from LLM response."""
        seen: set = set()
        normalized: List[str] = []
        for q in raw_queries:
            if not isinstance(q, str):
                continue
            q = q.strip()
            if not q:
                continue
            key = q.lower()
            if key in seen:
                continue
            seen.add(key)
            normalized.append(q)
            if len(normalized) >= MAX_PARALLEL_CHAINS:
                break
        return normalized

    def _summarize_results(self, results: list, max_results: int = 3) -> str:
        """Truncate results to essential content for LLM context."""
        summaries = []
        for item in results[:max_results]:
            content = (getattr(item, "content", None) or "")[:SEMANTIC_HOP_MAX_CONTENT_CHARS]
            md = getattr(item, "metadata", None) or {}
            entities = []
            if isinstance(md, dict):
                for ent in md.get("entities", [])[:5]:
                    name = ent.get("name", "") if isinstance(ent, dict) else str(ent)
                    if name.strip():
                        entities.append(name.strip())
            ent_str = f" [entities: {', '.join(entities)}]" if entities else ""
            summaries.append(f"- {content}{ent_str}")
        return "\n".join(summaries)

    @staticmethod
    def _build_prompt(
        original_query: str,
        results_summary: str,
        hop_num: int,
        seen_queries: List[str],
    ) -> str:
        """Build the LLM prompt for hop planning."""
        seen_str = ", ".join(f'"{q}"' for q in seen_queries) if seen_queries else "(none)"
        return f"""You are a search hop planner. Given a user's original query and the results from the current search hop, decide what to search next to better answer the question.

Original query: {original_query}
Hop number: {hop_num}
Previous queries: {seen_str}
Current results (top 3):
{results_summary}

Respond with JSON:
{{
  "follow_up_queries": ["query1", "query2"],
  "reasoning": "brief explanation",
  "confidence": 0.0
}}

Rules:
- Return 1-3 follow-up search queries, or empty list to stop
- Infer implicit connections (e.g., person -> identity -> related groups)
- Consider temporal/causal relationships
- Do NOT repeat semantically equivalent queries from previous hops
- Return empty follow_up_queries if the current results already answer the question"""


class MultiHopSearch:
    """Orchestrates multi-hop retrieval with budget cascading."""

    def __init__(self, search_fn: Callable, planner: Optional[HopPlanner] = None):
        """
        Args:
            search_fn: Callable(query, top_k, **kwargs) -> list.
                       This is self._search.search from SmartMemory.
            planner: HopPlanner instance (default: HopPlanner()).
        """
        self._search = search_fn
        self._planner = planner or HopPlanner()

    def execute(
        self,
        query: str,
        top_k: int,
        max_hops: int = 3,
        budget_ms: int = 1500,
        **kwargs,
    ) -> list:
        """Run multi-hop search, return merged results.

        CORE-MULTIHOP-2: each hop may produce multiple follow-up queries
        (parallel chains). Per-hop results from all chains are RRF-merged
        before applying hop-decay across hops.

        VIS-PIPELINE-DAG-1: opportunistic progress emission. If the caller
        bound a progress context before calling, per-hop pipeline.stage events
        and a one-shot pipeline.dag topology event are emitted. Without a
        bound context this is a silent no-op.
        """
        from smartmemory.search.rrf_merge import rrf_merge

        # CORE-ATTENTION-FUSION-1: pop fusion_config so it doesn't leak into search_fn kwargs.
        fusion_config = kwargs.pop("fusion_config", None)

        hop_results: List[HopResult] = []
        seen_entities: set = set()
        remaining_budget = float(budget_ms)
        current_queries = [query]

        # VIS-PIPELINE-DAG-1: emit topology event only if this call owns the
        # current run (skipped when nested inside another producer's run).
        _emit_multi_hop_dag_if_owns_run(max_hops)

        # CORE-MULTIHOP-2 Phase 2: check if planner accepts **kwargs (once, before loop)
        _sig = inspect.signature(self._planner.plan_next_hop)
        _accepts_kwargs = any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in _sig.parameters.values()
        )

        for hop_num in range(max_hops):
            # CORE-MULTIHOP-2: run all current queries for this hop in parallel
            t0 = time.perf_counter()
            _emit_multi_hop_stage(hop_num, status="started", chains=len(current_queries))
            all_chain_results: List[list] = []
            if len(current_queries) == 1:
                # Single chain — no thread overhead
                all_chain_results.append(self._search(current_queries[0], top_k=top_k, **kwargs) or [])
            else:
                # Parallel chains via thread pool
                with ThreadPoolExecutor(max_workers=len(current_queries)) as pool:
                    futures = {
                        pool.submit(self._search, cq, top_k=top_k, **kwargs): i
                        for i, cq in enumerate(current_queries)
                    }
                    # Pre-fill with empty lists to maintain order
                    all_chain_results = [[] for _ in current_queries]
                    for fut in as_completed(futures):
                        idx = futures[fut]
                        try:
                            all_chain_results[idx] = fut.result() or []
                        except Exception as exc:
                            logger.warning("Multi-hop chain %d failed: %s", idx, exc)

            # Merge parallel chain results via RRF if multiple chains
            if len(all_chain_results) > 1:
                results = rrf_merge(all_chain_results, top_k=top_k)
            elif all_chain_results:
                results = all_chain_results[0]
            else:
                results = []

            elapsed = (time.perf_counter() - t0) * 1000.0
            remaining_budget -= elapsed
            _emit_multi_hop_stage(
                hop_num,
                status="ok",
                duration_ms=elapsed,
                results=len(results),
                budget_remaining_ms=max(remaining_budget, 0.0),
            )

            # Collect entities from this hop (but don't add to seen yet — planner needs them)
            hop_entities = self._extract_entities(results)

            hop_results.append(HopResult(
                hop_num=hop_num,
                query=current_queries[0] if len(current_queries) == 1 else f"[{len(current_queries)} chains]",
                results=results,
                elapsed_ms=elapsed,
                entities_found=hop_entities,
                chain_queries=list(current_queries),  # Track actual queries for loop detection
            ))

            logger.debug(
                "multi_hop: hop=%d chains=%d results=%d elapsed=%.0fms budget_remaining=%.0fms",
                hop_num, len(current_queries), len(results), elapsed, remaining_budget,
            )

            # Last hop? Don't plan.
            if hop_num >= max_hops - 1:
                break

            # Budget check: enough remaining to justify another hop?
            if remaining_budget < MIN_HOP_BUDGET_MS:
                logger.debug("multi_hop: budget exhausted (%.0fms remaining)", remaining_budget)
                _emit_multi_hop_timeout(
                    completed_hop=hop_num,
                    budget_remaining_ms=max(remaining_budget, 0.0),
                )
                break

            # Plan next hop — seen_entities does NOT include current hop's entities
            # so the planner can select them as follow-up candidates.
            # CORE-MULTIHOP-2 Phase 2: pass seen_queries for semantic dedup
            _prev_queries = [query]
            for hr in hop_results:
                _prev_queries.extend(hr.chain_queries)

            if _accepts_kwargs:
                plan = self._planner.plan_next_hop(
                    query, results, hop_num, seen_entities,
                    seen_queries=_prev_queries,
                )
            else:
                plan = self._planner.plan_next_hop(query, results, hop_num, seen_entities)

            # NOW mark current hop's entities as seen (after planning used them)
            seen_entities.update(e.lower() for e in hop_entities)
            if plan.stop or not plan.follow_up_queries:
                # Backward compat: check legacy follow_up_query too
                if plan.stop or plan.follow_up_query is None:
                    logger.debug("multi_hop: planner stopped at hop %d", hop_num)
                    break

            # CORE-MULTIHOP-2: use parallel follow-up queries
            follow_ups = plan.follow_up_queries if plan.follow_up_queries else (
                [plan.follow_up_query] if plan.follow_up_query else []
            )
            if not follow_ups:
                break

            # Loop detection: if ALL follow-ups were already searched, stop
            prev_queries: set[str] = set()
            for hr in hop_results:
                for cq in hr.chain_queries:
                    prev_queries.add(cq.lower())
            prev_queries.add(query.lower())  # Include original query
            novel_follow_ups = [fq for fq in follow_ups if fq.lower() not in prev_queries]
            if not novel_follow_ups:
                logger.debug("multi_hop: all follow-ups are loops, stopping")
                break

            current_queries = novel_follow_ups

        # Merge results from all hops with decay weights
        if len(hop_results) == 1:
            return hop_results[0].results[:top_k]

        # CORE-ATTENTION-FUSION-1: query-conditioned hop weights when enabled,
        # otherwise the helper returns the original [HOP_DECAY ** i] decay.
        from smartmemory.search.attention_fusion import compute_hop_weights

        result_lists = [hr.results for hr in hop_results]
        hop_weights = compute_hop_weights(query, result_lists, config=fusion_config)
        return rrf_merge(result_lists, top_k=top_k, weights=hop_weights)

    @staticmethod
    def _extract_entities(results: list) -> List[str]:
        """Extract entity names from result metadata."""
        entities = []
        for item in results[:TOP_K_FOR_PLANNING]:
            md = getattr(item, "metadata", None) or {}
            if isinstance(md, dict):
                for ent in md.get("entities", []):
                    name = ent.get("name", "") if isinstance(ent, dict) else str(ent)
                    name = name.strip()
                    if name:
                        entities.append(name)
        return entities
