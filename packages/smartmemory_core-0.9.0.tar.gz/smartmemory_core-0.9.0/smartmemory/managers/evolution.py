"""Evolution and clustering operations extracted from SmartMemory."""

import logging

logger = logging.getLogger(__name__)


class EvolutionManager:
    """Manages evolution cycles, memory promotion, and clustering."""

    def __init__(self, evolution_orchestrator, clustering):
        self._evolution = evolution_orchestrator
        self._clustering = clustering

    def run_evolution_cycle(self):
        """Run a single evolution cycle with automatic scope filtering."""
        return self._evolution.run_evolution_cycle()

    # CORE-MEMORY-DYNAMICS-1 M1b: commit_working_to_episodic / commit_working_to_procedural
    # removed — the ConsolidationRouter now routes at ingest, obsoleting the
    # retroactive-promotion pattern these delegated to.

    def run_clustering(self) -> dict:
        """Run clustering to deduplicate entities."""
        return self._clustering.run()
