"""ONTO-RECONCILE-1 — Unified ontology type and relation dataclasses.

The substrate's value-object layer. `OntologyType` and `OntologyRelation`
are the OWL-Lite-shaped definitions persisted as `:OntologyType` and
`:OntologyRelation` nodes in FalkorDB.

Identity resolution (used by `OntologyService`):
    1. `iri` if present (canonical IRI from any standard ontology)
    2. `wikidata_qid` (or `wikidata_pid` for relations) — Wikidata convenience case
    3. `(layer, workspace_id, pack_id, name)` composite key

`name` is immutable. Curators rename via `display_name`. For relations,
`name` is also the Cypher edge label on instance edges.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal

Tier = Literal["working", "proposed", "confirmed", "retired"]
TrustOrigin = Literal["online_promoted", "batch_proposed", "imported", "manual"]
Layer = Literal["public", "domain", "private"]
Source = Literal[
    "inline", "batch", "manual", "inline_replay", "imported_owl", "migration_recovered"
]
Cardinality = Literal["1:1", "1:N", "N:N"]


@dataclass
class ApplyResult:
    """Result of `OntologyService.apply_changeset`.

    Returned to BatchObserver / ManualObserver callers and to the HTTP
    `apply_changeset` route handler. Counts are post-promoter, so they
    reflect what actually landed in the unified label, not what the IR
    requested.
    """

    new_version: str
    types_added: int = 0
    types_updated: int = 0
    relations_added: int = 0
    relations_updated: int = 0
    taxonomy_edges_added: int = 0
    audit_entries_written: int = 0
    hitl_queue_entries: int = 0
    rejected: int = 0
    snapshot_id: str | None = None
    warnings: list[str] = field(default_factory=list)


@dataclass
class ReconcileResult:
    """Result of `OntologyService.reconcile_seed`.

    Phase 4 Task 13c. Returned to operator callers running drift
    reconciliation against `WIKIDATA_TYPE_MAP`. `orphaned` is the count
    of public-layer rows whose names are not in the current map;
    `retired` is how many of those were transitioned to `retired` tier
    in this call (zero unless `retire=True`).
    """

    orphaned: int = 0
    retired: int = 0
    orphan_names: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass
class OntologyType:
    """Entity type definition — the OWL `Class`."""

    name: str
    iri: str | None = None
    wikidata_qid: str | None = None

    display_name: str | None = None
    definition: str | None = None
    description: str | None = None
    aliases: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)

    parent_types: list[str] = field(default_factory=list)
    equivalent_types: list[str] = field(default_factory=list)
    equivalent_iris: list[dict] = field(default_factory=list)

    properties_schema: dict = field(default_factory=dict)
    required_properties: set[str] = field(default_factory=set)

    tier: Tier = "working"
    trust_origin: TrustOrigin = "batch_proposed"

    layer: Layer = "private"
    pack_id: str | None = None
    pack_version: str | None = None
    workspace_id: str | None = None

    source: Source = "inline"
    evidence: list[str] = field(default_factory=list)
    confidence: float = 0.0
    frequency: int = 0
    disambiguator: str | None = None

    created_by: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass
class OntologyRelation:
    """Relation type definition — the OWL `ObjectProperty`.

    `name` is the Cypher edge label on relation instances; immutable.
    """

    name: str
    iri: str | None = None
    wikidata_pid: str | None = None

    display_name: str | None = None
    definition: str | None = None
    description: str | None = None
    aliases: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)

    domain: list[str] = field(default_factory=list)
    range: list[str] = field(default_factory=list)
    inverse_of: str | None = None
    cardinality: Cardinality = "N:N"
    temporal: bool = False

    properties_schema: dict = field(default_factory=dict)

    transitive: bool = False
    symmetric: bool = False
    reflexive: bool = False

    parent_relations: list[str] = field(default_factory=list)
    equivalent_relations: list[str] = field(default_factory=list)
    equivalent_iris: list[dict] = field(default_factory=list)

    tier: Tier = "working"
    trust_origin: TrustOrigin = "batch_proposed"

    layer: Layer = "private"
    pack_id: str | None = None
    pack_version: str | None = None
    workspace_id: str | None = None

    source: Source = "inline"
    evidence: list[str] = field(default_factory=list)
    confidence: float = 0.0
    frequency: int = 0
    disambiguator: str | None = None

    created_by: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
