"""ONTO-RECONCILE-1 Task 3b — Corpus-level scoring helper.

The legacy `LLMInferenceService._score_and_filter_concepts` (in
`smartmemory/ontology/inference/inference.py`) baked the confidence
threshold AND the score formula AND the promotion decision into one
method. ONTO-RECONCILE-1's contract: scoring is pure (no decisions),
the Promoter alone decides promotion.

`corpus_score()` returns the three batch-mode signals
(`cohesion`, `confidence_boost`, `hearst_strength`) as a dict so the
BatchObserver can flow them into `EvidenceStore` without conflating
them with per-observation confidences. The Promoter then reads the
accumulated state via `EvidenceSnapshot` and gates on it.
"""

from __future__ import annotations

from typing import Any

# Sub-score weights. Documented as constants so an operator tuning the
# legacy formula has one place to change. Same intent as the pre-existing
# `tau_low / tau_review / tau_high` constants in `inference.py`, but
# expressed as weights on signals (which the Promoter later gates on)
# rather than as decision thresholds.
_W_LLM_CERT = 0.4
_W_FREQUENCY = 0.3
_W_COHESION = 0.3


def corpus_score(concept: Any, corpus_signals: dict[str, Any] | None = None) -> dict[str, float]:
    """Score a corpus-level concept aggregate. Returns three signals.

    `concept` is an object with `confidence`, `evidence`, and `synonyms`
    attributes (the legacy `Concept` from `ir_models.py` shape — duck-typed
    so the helper composes with future IR models without coupling).

    `corpus_signals` is reserved for cross-concept signals (e.g. inverse
    document frequency, cluster compactness from a separate clusterer).
    Today only `cohesion` is read; unknown keys are ignored so callers
    can pass through extra metadata without breaking.

    Returns:
        {
            "cohesion": float,           # cluster-tightness proxy (0..1)
            "confidence_boost": float,   # frequency-weighted LLM-cert (0..1)
            "hearst_strength": float,    # Hearst-pattern multiplier (0..1)
        }

    Decision-free by design — the Promoter reads these via
    `EvidenceSnapshot` and applies its own gates.
    """
    corpus_signals = corpus_signals or {}

    # Per-concept LLM certainty (0..1). The legacy formula clamped to
    # `min(freq/10, 1.0)` so a single-evidence concept didn't dominate.
    # Preserving that clamp keeps the score comparable across migrations.
    evidence_count = len(getattr(concept, "evidence", []) or [])
    freq_proxy = min(evidence_count / 10.0, 1.0)
    llm_cert = float(getattr(concept, "confidence", 0.0) or 0.0)

    # Cohesion: prefer caller-supplied corpus signal; fall back to a
    # synonym-count proxy (the legacy heuristic — more synonyms ≈ tighter
    # cluster). Caller can override via corpus_signals["cohesion"].
    if "cohesion" in corpus_signals:
        cohesion = float(corpus_signals["cohesion"])
    else:
        synonym_count = len(getattr(concept, "synonyms", []) or [])
        cohesion = min(synonym_count * 0.1, 1.0)

    # Hearst strength is 1.0 if the concept appeared in any Hearst
    # taxonomy match, else 0. Surfaced as a separate signal so the
    # Promoter (or downstream curator) can treat Hearst evidence as
    # categorically different from LLM extraction.
    hearst_strength = 1.0 if corpus_signals.get("hearst_hits") else 0.0

    confidence_boost = (
        _W_LLM_CERT * llm_cert
        + _W_FREQUENCY * freq_proxy
        + _W_COHESION * cohesion
    )

    return {
        "cohesion": cohesion,
        "confidence_boost": confidence_boost,
        "hearst_strength": hearst_strength,
    }
