"""ONTO-RECONCILE-1 Task 3b — EvidenceStore.

FalkorDB-backed accumulator of per-type observations. Reads and writes
go through `OntologyGraph` helpers (no raw Cypher here) so the
"no direct Cypher against ontology labels outside `service.py` /
`ontology_graph.py`" discipline holds.

Storage layout sits on the existing `:OntologyType` row — no separate
`:Evidence` label. See `OntologyGraph._record_observation_evidence` for
the concrete property set. The Promoter (`promoter.py`) reads
`EvidenceSnapshot` instances and runs gates against them; nothing in the
Promoter touches FalkorDB directly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import logging

from smartmemory.backends.unsupported import UnsupportedBackendError
from smartmemory.ontology.observations import Observation

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from smartmemory.graph.ontology_graph import OntologyGraph


@dataclass
class EvidenceSnapshot:
    """Read-only view of accumulated evidence for one OntologyType.

    The Promoter consumes this dataclass — never calls EvidenceStore
    directly mid-evaluation. Snapshots are computed at evaluate-time so
    multiple gates see the same state (avoids gate-ordering drift if a
    concurrent observer added a row mid-evaluation).
    """

    identifier: str
    type_name: str
    frequency: int = 0
    confidence_sum: float = 0.0
    confidence_count: int = 0
    mention_distribution: dict[str, int] = field(default_factory=dict)
    evidence_refs: list[str] = field(default_factory=list)
    hearst_hits: list[dict] = field(default_factory=list)
    cohesion: float | None = None
    has_batch_signal: bool = False

    @classmethod
    def empty(cls, identifier: str = "", type_name: str = "") -> "EvidenceSnapshot":
        """Return a zero-evidence snapshot. Used by lite-mode shielding (DIST-LITE-ONTO-1)
        when EvidenceStore.get raises UnsupportedBackendError and a no-evidence read is
        the appropriate fallback.
        """
        return cls(identifier=identifier, type_name=type_name)

    @property
    def confidence_avg(self) -> float:
        if self.confidence_count == 0:
            return 0.0
        return self.confidence_sum / self.confidence_count

    @property
    def consistency(self) -> float:
        """Top-mention dominance. 1.0 = single mention always maps to this type.

        Returns 0.0 when no mentions have been recorded — the promoter's
        consistency gate then fails closed (correct: no data ≠ confident).
        """
        if not self.mention_distribution:
            return 0.0
        total = sum(self.mention_distribution.values())
        if total == 0:
            return 0.0
        top = max(self.mention_distribution.values())
        return top / total


class EvidenceStore:
    """FalkorDB-backed evidence accumulator.

    Constructor takes an `OntologyGraph` plus a `workspace_id` (resolved
    from the bound `ScopeProvider` by `OntologyService`). All evidence
    writes pin to private layer for that workspace — domain/public layers
    are not modified by observers.
    """

    def __init__(self, ontology_graph: OntologyGraph, *, workspace_id: str):
        self._graph = ontology_graph
        self._workspace_id = workspace_id

    def add(self, observation: Observation) -> None:
        """Record one observation against the type identified in it.

        Identifier resolution: iri → qid → type_name (mirrors the
        OntologyGraph identity rule). The type must already exist in the
        private layer; absent types are NOT auto-created here — that's
        the OntologyConstrainStage / OntologyService's job (Task 2 +
        Task 2d). When the type is absent, `_record_observation_evidence`
        logs a warning and skips, so the Promoter's `min_frequency` gate
        remains the truthful failure signal.
        """
        identifier = observation.type_iri or observation.type_qid or observation.type_name
        try:
            self._graph._record_observation_evidence(
                identifier,
                workspace_id=self._workspace_id,
                mention=observation.entity_mention,
                confidence=observation.confidence,
                evidence_ref=observation.evidence_ref,
                hearst_evidence=observation.hearst_evidence,
            )
        except UnsupportedBackendError as e:
            # DIST-LITE-ONTO-1: lite-mode SQLiteOntologyStore declares
            # the ontology_evidence_store capability as unsupported. The
            # Promoter then evaluates against the empty snapshot returned
            # by `get()` — frequency/cohesion gates fail closed, which is
            # the correct lite-mode behavior (no governance promotion).
            logger.debug("Evidence accrual skipped on lite backend: %s", e)
            return
        # Cohesion is set separately via `set_cohesion` — batch-only signal.

    def set_cohesion(self, identifier: str, cohesion: float) -> None:
        """Update the corpus-level cohesion score (BatchObserver-only)."""
        try:
            self._graph._set_cohesion(identifier, workspace_id=self._workspace_id, cohesion=cohesion)
        except UnsupportedBackendError as e:
            # DIST-LITE-ONTO-1: lite-mode no-op (see `add`).
            logger.debug("Cohesion set skipped on lite backend: %s", e)
            return

    def get(self, identifier: str, *, type_name: str | None = None) -> EvidenceSnapshot:
        """Return the current snapshot for the identifier.

        `type_name` defaults to `identifier` when not supplied — used as
        the human-readable label in gate-failure reasons. The promoter's
        length/blocklist gates run against `type_name`, so callers
        passing iri/qid as `identifier` should also pass the resolved
        name.

        DIST-LITE-ONTO-1: when the backend declares the evidence store
        unsupported (lite mode), returns `EvidenceSnapshot.empty()` so
        the Promoter sees no-evidence and gates fail closed.
        """
        try:
            raw = self._graph._get_evidence_for_type(identifier, workspace_id=self._workspace_id)
        except UnsupportedBackendError as e:
            logger.debug("Evidence read skipped on lite backend: %s", e)
            return EvidenceSnapshot.empty(identifier=identifier, type_name=type_name or identifier)
        return EvidenceSnapshot(
            identifier=identifier,
            type_name=type_name or identifier,
            frequency=raw["frequency"],
            confidence_sum=raw["confidence_sum"],
            confidence_count=raw["confidence_count"],
            mention_distribution=raw["mention_distribution"],
            evidence_refs=raw["evidence_refs"],
            hearst_hits=raw["hearst_hits"],
            cohesion=raw["cohesion"],
            has_batch_signal=raw["cohesion"] is not None,
        )
