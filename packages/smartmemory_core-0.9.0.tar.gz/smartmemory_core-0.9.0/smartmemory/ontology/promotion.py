"""Legacy promotion module — RETIRED in ONTO-RECONCILE-1 Task 5.

The unified Promoter (`smartmemory/ontology/promoter.py`) and
OnlineObserver / BatchObserver / ManualObserver
(`smartmemory/ontology/observers.py`) now own the entire promotion
flow. `PromotionEvaluator`, `PromotionCandidate`, and `PromotionResult`
have been removed; the in-pipeline `_handle_promotion` queue/inline
fallback in `OntologyConstrainStage` is gone too.

This module is preserved as a thin re-export shim for `COMMON_WORD_BLOCKLIST`
because it remains the published import path that earlier callers and
tests have imported. New code should import directly from
`smartmemory.ontology.blocklist`. The shim will be deleted in a
follow-up release once the deprecation window has closed.
"""

from __future__ import annotations

from smartmemory.ontology.blocklist import COMMON_WORD_BLOCKLIST as _UNIFIED_BLOCKLIST

COMMON_WORD_BLOCKLIST: frozenset[str] = _UNIFIED_BLOCKLIST

__all__ = ["COMMON_WORD_BLOCKLIST"]
