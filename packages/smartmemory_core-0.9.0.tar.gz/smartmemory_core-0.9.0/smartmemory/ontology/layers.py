"""ONTO-RECONCILE-1 Task 2b/2c — `LayerResolver` for effective-layer reads.

The substrate stores `:OntologyType` and `:OntologyRelation` per layer
(`private` / `domain` / `public`). `LayerResolver` provides the
read-side precedence rule:

    private (workspace overlay)
        ↓ fall through if absent
    domain (installed packs only)
        ↓ fall through if absent
    public (shared base)

This mirrors `LayeredOntology` (`overlay → base`) semantics — overlay
wins on conflict — but operates against graph-stored types instead of
in-memory `Ontology` objects.

Domain-layer read semantics:
- When `installed_packs` is supplied, the resolver iterates the packs in
  caller order and returns the first per-pack hit. A row whose `pack_id`
  is not in the supplied set is invisible.
- When `installed_packs` is `None` (transitional, until `:PackInstallation`
  ships in Task 2e), the resolver falls back to a single any-pack lookup
  with `ORDER BY pack_id` for deterministic resolution.

The walking logic is shared between types and relations via the
internal `_walk_layers` method, which takes per-slot and any-pack
lookup callables. `resolve_effective` / `resolve_by_identity` bind type
lookups; `resolve_relation_effective` / `resolve_relation_by_identity`
bind relation lookups (Task 2c).

Public-layer rows live in the same per-workspace ontology graph today
(replicated per workspace, like the existing `:EntityType` seed pattern).
Migration to a shared graph is part of the public-layer pack story
(ONTO-PACKS-INSTALL-1) and does not affect the resolver's surface.
"""

from __future__ import annotations

from typing import Iterable

from smartmemory.ontology.types import OntologyRelation, OntologyType


class LayerResolver:
    """Effective-layer resolver over `:OntologyType` and `:OntologyRelation`.

    Wraps an `OntologyGraph` instance and applies the precedence rule
    `private → domain → public` for both name-based and identity-based
    lookups across both labels. Identity-based lookups dispatch by which
    external identifier the caller supplies; iri wins over qid/pid when
    both are passed.
    """

    def __init__(self, ontology_graph) -> None:
        self._graph = ontology_graph

    # ------------------------------------------------------------------ #
    # Type resolution (Task 2b)
    # ------------------------------------------------------------------ #

    def resolve_effective(
        self,
        identifier: str,
        *,
        workspace_id: str,
        installed_packs: Iterable[str] | None = None,
    ) -> OntologyType | None:
        """Resolve a `:OntologyType` by `identifier` (iri / qid / name)
        using layer precedence. Auto identity-rule dispatch."""
        return self._walk_layers(
            workspace_id=workspace_id,
            installed_packs=installed_packs,
            lookup_in_slot=lambda layer, pack_id: self._graph._get_ontology_type(
                identifier, layer=layer, workspace_id=workspace_id, pack_id=pack_id, key=None
            ),
            lookup_any_pack=lambda layer: self._graph._get_ontology_type_any_pack(
                identifier, layer=layer, workspace_id=workspace_id, key=None
            ),
        )

    def resolve_by_identity(
        self,
        *,
        iri: str | None = None,
        qid: str | None = None,
        workspace_id: str,
        installed_packs: Iterable[str] | None = None,
    ) -> OntologyType | None:
        """Resolve a `:OntologyType` by external identifier (iri or qid)
        using layer precedence. Branch is constrained — qid lookup never
        falls through to iri or composite-name. iri wins over qid."""
        if iri is None and qid is None:
            return None
        external_id, key = (iri, "iri") if iri is not None else (qid, "qid")
        return self._walk_layers(
            workspace_id=workspace_id,
            installed_packs=installed_packs,
            lookup_in_slot=lambda layer, pack_id: self._graph._get_ontology_type(
                external_id, layer=layer, workspace_id=workspace_id, pack_id=pack_id, key=key
            ),
            lookup_any_pack=lambda layer: self._graph._get_ontology_type_any_pack(
                external_id, layer=layer, workspace_id=workspace_id, key=key
            ),
        )

    # ------------------------------------------------------------------ #
    # Relation resolution (Task 2c)
    # ------------------------------------------------------------------ #

    def resolve_relation_effective(
        self,
        identifier: str,
        *,
        workspace_id: str,
        installed_packs: Iterable[str] | None = None,
    ) -> OntologyRelation | None:
        """Mirror of `resolve_effective` for `:OntologyRelation`. Auto
        identity-rule dispatch (iri → pid → name)."""
        return self._walk_layers(
            workspace_id=workspace_id,
            installed_packs=installed_packs,
            lookup_in_slot=lambda layer, pack_id: self._graph._get_ontology_relation(
                identifier, layer=layer, workspace_id=workspace_id, pack_id=pack_id, key=None
            ),
            lookup_any_pack=lambda layer: self._graph._get_ontology_relation_any_pack(
                identifier, layer=layer, workspace_id=workspace_id, key=None
            ),
        )

    def resolve_relation_by_identity(
        self,
        *,
        iri: str | None = None,
        pid: str | None = None,
        workspace_id: str,
        installed_packs: Iterable[str] | None = None,
    ) -> OntologyRelation | None:
        """Mirror of `resolve_by_identity` for `:OntologyRelation`. Uses
        `pid` (Wikidata property id) as the secondary external identifier.
        iri wins over pid when both are supplied."""
        if iri is None and pid is None:
            return None
        external_id, key = (iri, "iri") if iri is not None else (pid, "pid")
        return self._walk_layers(
            workspace_id=workspace_id,
            installed_packs=installed_packs,
            lookup_in_slot=lambda layer, pack_id: self._graph._get_ontology_relation(
                external_id, layer=layer, workspace_id=workspace_id, pack_id=pack_id, key=key
            ),
            lookup_any_pack=lambda layer: self._graph._get_ontology_relation_any_pack(
                external_id, layer=layer, workspace_id=workspace_id, key=key
            ),
        )

    # ------------------------------------------------------------------ #
    # Shared walker
    # ------------------------------------------------------------------ #

    def _walk_layers(
        self,
        *,
        workspace_id: str,
        installed_packs: Iterable[str] | None,
        lookup_in_slot,
        lookup_any_pack,
    ):
        """Walk private → domain → public, applying the pack filter to
        the domain layer only.

        - `lookup_in_slot(layer, pack_id)` returns the per-slot hit.
          Single-slot layers (private, public) call with `pack_id=None`.
        - `lookup_any_pack(layer)` returns the deterministic any-pack hit
          for the domain layer when `installed_packs is None`.
        """
        # Private — overlay; no pack semantics.
        hit = lookup_in_slot("private", None)
        if hit is not None:
            return hit

        # Domain — pack-driven. Per-pack iteration when caller scoped the
        # set; deterministic any-pack lookup otherwise.
        if installed_packs is not None:
            for pack_id in installed_packs:
                hit = lookup_in_slot("domain", pack_id)
                if hit is not None:
                    return hit
        else:
            hit = lookup_any_pack("domain")
            if hit is not None:
                return hit

        # Public — shared base; no pack semantics today.
        return lookup_in_slot("public", None)
