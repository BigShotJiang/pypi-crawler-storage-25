"""ONTO-RECONCILE-1 Task 3 — tier transition rules.

Pure logic. The substrate's tier DAG is:

    working → proposed → confirmed → retired

Forward edges only; never demote. `working → confirmed` skip-forward
is illegal — every promotion to `confirmed` must pass through
`proposed` so the Promoter (Task 3b) and HITL review get a gate.
Same-tier transitions are legal idempotent no-ops.

Bridges legacy enums onto the unified tier:
- Online (`OntologyGraph.VALID_STATUSES`):
  `seed → confirmed`, `provisional → proposed`, `confirmed → confirmed`,
  `rejected → retired`.
- Batch (`Status` enum at `ir_models.py:18`):
  `APPROVED → confirmed`, `PROPOSED → proposed`, `REJECTED → retired`,
  `DEPRECATED → retired`.
- Default (unknown): `working`.
"""

from __future__ import annotations

# The DAG, expressed as a set of legal forward edges. Same-tier identity
# is allowed separately (idempotent transition); not listed here so the
# table stays small and obvious.
_LEGAL_FORWARD_EDGES: frozenset[tuple[str, str]] = frozenset(
    {
        ("working", "proposed"),
        ("proposed", "confirmed"),
        ("confirmed", "retired"),
    }
)

# Legacy → unified tier. Input is normalized to lowercase before lookup
# so the mapper accepts both `Status.APPROVED.value` ("approved") and
# the enum member's name as a string ("APPROVED") without separate
# branches.
_LEGACY_TO_TIER: dict[str, str] = {
    # Online (`VALID_STATUSES`):
    "seed": "confirmed",
    "provisional": "proposed",
    "confirmed": "confirmed",
    "rejected": "retired",
    # Batch (`Status` enum values, lowercase):
    "approved": "confirmed",
    "proposed": "proposed",
    "deprecated": "retired",
}


def can_transition(from_tier: str, to_tier: str, reason: str) -> bool:
    """Return True if the transition is permitted by the substrate DAG.

    `reason` is part of the contract for caller hygiene (audit
    requires a reason; passing the empty string still validates).
    The validator itself is reason-agnostic — policy decisions that
    depend on `reason` content live in the Promoter (Task 3b), not
    here.
    """
    if from_tier == to_tier:
        # Same-tier replay is a legal no-op. The service layer treats
        # this as a no-op write (no audit entry); the validator's job
        # is just to permit it.
        return from_tier in {"working", "proposed", "confirmed", "retired"}
    return (from_tier, to_tier) in _LEGAL_FORWARD_EDGES


def tier_for_status(legacy_status: str) -> str:
    """Map a legacy enum value (or member name) to the unified tier.

    Unknown values default to `"working"` — lets a migration script
    say "I haven't classified this yet" without crashing.
    """
    if not legacy_status:
        return "working"
    return _LEGACY_TO_TIER.get(legacy_status.lower(), "working")
