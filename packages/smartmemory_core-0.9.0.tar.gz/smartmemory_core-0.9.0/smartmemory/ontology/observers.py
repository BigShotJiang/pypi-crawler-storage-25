"""ONTO-RECONCILE-1 Task 3b — Observers (Online, Batch, Manual).

Three classes, ONE algorithm. All emit `Observation` records into
`EvidenceStore` via `OntologyService.record_observation` — except
`ManualObserver`, which is decisive and bypasses the Promoter entirely
to call `OntologyService.transition()` directly.

Why Manual bypasses the Promoter:

The Promoter is for evidence-driven automatic promotion. HITL approvals
are a different workflow — an operator looking at a candidate has
already done the gating in their head. Routing HITL through the
Promoter would either (a) re-gate decisions humans already made
(annoying, error-prone) or (b) require a "skip gates" flag (defeats
the unified-algorithm contract). Cleaner separation: Manual approvals
are direct tier transitions; the audit trail records `actor=<user>`
so the provenance is preserved.

Trust origin attribution:
    OnlineObserver  → "online_promoted"
    BatchObserver   → "batch_proposed"
    ManualObserver  → "manual"   (set on the audit row, not promoter)
    Pack/OWL import → "imported" (set by apply_changeset, not here)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from smartmemory.ontology.observations import Observation
from smartmemory.ontology.types import Tier

if TYPE_CHECKING:
    from smartmemory.ontology.service import OntologyService

logger = logging.getLogger(__name__)


class _BaseObserver:
    """Common plumbing — all observers feed `OntologyService` instances."""

    def __init__(self, service: OntologyService):
        self._service = service


class OnlineObserver(_BaseObserver):
    """Per-ingest observer. Called from `OntologyConstrainStage`.

    Emits one `Observation(mode="online", source="inline")` per accepted
    LLM-extracted entity. The service's `record_observation` then routes
    through `EvidenceStore.add` → `Promoter.evaluate` → optional tier
    transition + audit.

    Mode-independence: this observer's only job is to construct the
    `Observation` payload. The Promoter sees the same `EvidenceSnapshot`
    state regardless of which observer's `add()` call grew it.
    """

    def observe(
        self,
        *,
        entity_mention: str,
        type_name: str,
        confidence: float,
        evidence_ref: str | None = None,
        type_iri: str | None = None,
        type_qid: str | None = None,
    ) -> None:
        obs = Observation(
            entity_mention=entity_mention,
            type_name=type_name,
            type_iri=type_iri,
            type_qid=type_qid,
            confidence=confidence,
            source="inline",
            evidence_ref=evidence_ref,
            mode="online",
        )
        self._service.record_observation(obs)


class BatchObserver(_BaseObserver):
    """Corpus-level observer. Called from the batch inference loop.

    Replaces the legacy `_score_and_filter_concepts` decision path in
    `inference.py`. After scoring (via `corpus_score()`), the
    BatchObserver emits one `Observation` per concept with the
    cohesion signal attached; `EvidenceStore.set_cohesion` writes the
    corpus-level cohesion separately so the Promoter's cohesion gate
    can read it without conflating with per-observation confidence.
    """

    def observe(
        self,
        *,
        entity_mention: str,
        type_name: str,
        confidence: float,
        cohesion: float | None = None,
        evidence_ref: str | None = None,
        batch_id: str | None = None,
        type_iri: str | None = None,
        type_qid: str | None = None,
        hearst_evidence: dict | None = None,
    ) -> None:
        obs = Observation(
            entity_mention=entity_mention,
            type_name=type_name,
            type_iri=type_iri,
            type_qid=type_qid,
            confidence=confidence,
            source="batch",
            evidence_ref=evidence_ref,
            mode="batch",
            batch_id=batch_id,
            cohesion_score=cohesion,
            hearst_evidence=hearst_evidence,
        )
        self._service.record_observation(obs)
        if cohesion is not None:
            identifier = type_iri or type_qid or type_name
            self._service.set_evidence_cohesion(identifier, cohesion)


class ManualObserver(_BaseObserver):
    """HITL approver. DECISIVE — bypasses the Promoter entirely.

    `approve()` is the canonical HITL entry point: an operator has
    looked at a candidate type and decided to promote it. This skips
    gate evaluation and writes the tier transition directly via the
    service. The audit row records `actor=<user>`, preserving HITL
    provenance.

    Use `auto_approve=True` on `apply_changeset` only for trusted bulk
    imports (OWL bootstrap, pack install); never for HITL review.
    """

    def approve(
        self,
        identifier: str,
        actor: str,
        *,
        to_tier: Tier = "confirmed",
        reason: str = "manual approval",
    ) -> None:
        """Promote `identifier` decisively. Audit'd as `actor`."""
        self._service.transition(identifier, to_tier=to_tier, reason=reason, actor=actor)

    def reject(self, identifier: str, actor: str, reason: str) -> None:
        """Decisively retire a candidate (HITL veto).

        Note the substrate's tier DAG: only `confirmed → retired` is
        legal. A `working` or `proposed` candidate that the operator
        wants to remove from consideration must first be promoted to
        `confirmed` (defeating the point of rejection) or use a
        different mechanism entirely. Today the cleaner path is to
        record the rejection in the audit log and let the Promoter
        keep failing it on re-evaluation; we expose `reject()` for
        symmetry but log a warning when the transition isn't legal.
        """
        try:
            self._service.transition(identifier, to_tier="retired", reason=reason, actor=actor)
        except ValueError as e:
            logger.warning(
                "ManualObserver.reject: cannot retire %r directly (current tier disallows): %s",
                identifier,
                e,
            )
            raise
