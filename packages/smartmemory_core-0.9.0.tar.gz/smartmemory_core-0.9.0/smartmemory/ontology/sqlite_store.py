"""SQLiteOntologyStore — persistent ontology store for local mode.

Replaces InMemoryOntologyStore with SQLite-backed persistence. Entity types,
relation types, entity patterns, and novel relation labels survive daemon
restarts. Uses the same memory.db file as the graph backend.

DIST-FULL-LOCAL-1 Phase 2a.
"""

import json
import logging
import sqlite3
import threading
from datetime import datetime, UTC
from typing import Any, Dict, List, Optional

from smartmemory.ontology.in_memory_store import InMemoryOntologyStore, SEED_TYPES

logger = logging.getLogger(__name__)

# DIST-LITE-ONTO-1: schema v2 — full ONTO-RECONCILE-1 identity-resolution parity.
# Drops the old `name_lower` PK (which prevented same-name rows across layers)
# and adds a surrogate `id` PK plus 7 identity/governance columns. See
# `docs/features/DIST-LITE-ONTO-1/design.md` for the rationale and
# `_migrate_v1_to_v2` below for the upgrade path on existing databases.
_CREATE_ENTITY_TYPES = """
CREATE TABLE IF NOT EXISTS ontology_types (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name_lower      TEXT NOT NULL,
    name_display    TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'seed',
    frequency       INTEGER NOT NULL DEFAULT 0,
    avg_confidence  REAL NOT NULL DEFAULT 0.0,
    iri             TEXT,
    wikidata_qid    TEXT,
    layer           TEXT NOT NULL DEFAULT 'private',
    workspace_id    TEXT NOT NULL DEFAULT 'default',
    pack_id         TEXT,
    tier            TEXT NOT NULL DEFAULT 'working',
    trust_origin    TEXT NOT NULL DEFAULT 'batch_proposed'
)
"""

_CREATE_RELATION_TYPES = """
CREATE TABLE IF NOT EXISTS ontology_relation_types (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name_lower      TEXT NOT NULL,
    name_display    TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'provisional',
    category        TEXT NOT NULL DEFAULT 'unknown',
    frequency       INTEGER NOT NULL DEFAULT 0,
    aliases         TEXT DEFAULT '[]',
    type_pairs      TEXT DEFAULT '[]',
    iri             TEXT,
    wikidata_pid    TEXT,
    layer           TEXT NOT NULL DEFAULT 'private',
    workspace_id    TEXT NOT NULL DEFAULT 'default',
    pack_id         TEXT,
    tier            TEXT NOT NULL DEFAULT 'working',
    trust_origin    TEXT NOT NULL DEFAULT 'batch_proposed'
)
"""

# DIST-LITE-ONTO-1: entity ↔ ontology-type linkage (mirrors FalkorDB
# `(:Entity)-[:INSTANCE_OF]->(:OntologyType)`). Composite uniqueness via
# index because SQLite cannot use COALESCE in a PRIMARY KEY clause.
_CREATE_ENTITY_LINKS = """
CREATE TABLE IF NOT EXISTS ontology_entity_links (
    entity_id          TEXT NOT NULL,
    type_iri           TEXT,
    type_wikidata_qid  TEXT,
    type_name_lower    TEXT NOT NULL,
    type_layer         TEXT NOT NULL DEFAULT 'private',
    type_workspace_id  TEXT NOT NULL DEFAULT 'default',
    type_pack_id       TEXT,
    linked_at          TEXT
)
"""

# Identity-slot uniqueness + lookup speed (DIST-LITE-ONTO-1).
#
# Identity uniqueness is **slot-scoped** (`(iri, layer, workspace_id, pack_id)`),
# matching the FalkorDB reference. The same iri/qid CAN coexist across
# slots — e.g., a private-layer type might mirror a public seed. Global
# unique indexes on iri/qid would prevent this and break the
# `LayerResolver` contract. Post-Codex DIST-LITE-ONTO-1 implementation
# review correction.
_CREATE_INDEXES = [
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_ontology_types_iri "
    "ON ontology_types(iri, layer, workspace_id, COALESCE(pack_id, '')) "
    "WHERE iri IS NOT NULL",
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_ontology_types_qid "
    "ON ontology_types(wikidata_qid, layer, workspace_id, COALESCE(pack_id, '')) "
    "WHERE wikidata_qid IS NOT NULL",
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_ontology_types_composite "
    "ON ontology_types(name_lower, layer, workspace_id, COALESCE(pack_id, ''))",
    "CREATE INDEX IF NOT EXISTS ix_ontology_types_name_lower "
    "ON ontology_types(name_lower)",
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_ontology_relation_types_iri "
    "ON ontology_relation_types(iri, layer, workspace_id, COALESCE(pack_id, '')) "
    "WHERE iri IS NOT NULL",
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_ontology_relation_types_pid "
    "ON ontology_relation_types(wikidata_pid, layer, workspace_id, COALESCE(pack_id, '')) "
    "WHERE wikidata_pid IS NOT NULL",
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_ontology_relation_types_composite "
    "ON ontology_relation_types(name_lower, layer, workspace_id, COALESCE(pack_id, ''))",
    "CREATE INDEX IF NOT EXISTS ix_ontology_relation_types_name_lower "
    "ON ontology_relation_types(name_lower)",
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_entity_links_pk "
    "ON ontology_entity_links(entity_id, type_name_lower, type_layer, "
    "type_workspace_id, COALESCE(type_pack_id, ''))",
]

_CREATE_ENTITY_PATTERNS = """
CREATE TABLE IF NOT EXISTS ontology_entity_patterns (
    name_lower     TEXT NOT NULL,
    label          TEXT NOT NULL,
    workspace_id   TEXT NOT NULL DEFAULT 'default',
    count          INTEGER NOT NULL DEFAULT 1,
    confidence     REAL NOT NULL DEFAULT 0.85,
    is_global      INTEGER NOT NULL DEFAULT 0,
    source         TEXT NOT NULL DEFAULT 'llm_discovery',
    discovered_at  TEXT,
    PRIMARY KEY (name_lower, label, workspace_id)
)
"""

_CREATE_NOVEL_RELATIONS = """
CREATE TABLE IF NOT EXISTS ontology_novel_relations (
    name_lower     TEXT NOT NULL,
    workspace_id   TEXT NOT NULL DEFAULT 'default',
    frequency      INTEGER NOT NULL DEFAULT 1,
    status         TEXT NOT NULL DEFAULT 'tracking',
    raw_examples   TEXT DEFAULT '[]',
    source_types   TEXT DEFAULT '[]',
    target_types   TEXT DEFAULT '[]',
    first_seen     TEXT,
    last_seen      TEXT,
    PRIMARY KEY (name_lower, workspace_id)
)
"""


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


class SQLiteOntologyStore(InMemoryOntologyStore):
    """Persistent ontology store backed by SQLite.

    Uses the same memory.db as the graph backend. Thread-safe via RLock.
    """

    def __init__(self, db_path: str, workspace_id: str = "default"):
        # Skip InMemoryOntologyStore.__init__ — we don't need in-memory dicts
        self.workspace_id = workspace_id
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._create_tables()
        self.seed_types()

    def _create_tables(self) -> None:
        with self._lock:
            # DIST-LITE-ONTO-1: migrate v1 → v2 schema BEFORE running
            # CREATE TABLE IF NOT EXISTS, otherwise an existing v1 table
            # would silently keep its old PK and shape.
            self._migrate_v1_to_v2()
            self._conn.execute(_CREATE_ENTITY_TYPES)
            self._conn.execute(_CREATE_RELATION_TYPES)
            self._conn.execute(_CREATE_ENTITY_PATTERNS)
            self._conn.execute(_CREATE_NOVEL_RELATIONS)
            self._conn.execute(_CREATE_ENTITY_LINKS)
            # Drop pre-fix global iri/qid/pid indexes if present so the new
            # slot-scoped definitions can take effect. Post-Codex impl-review
            # correction: the original DIST-LITE-ONTO-1 commit had global
            # uniqueness on iri/qid/pid which violates the slot-scoped
            # identity contract. CREATE INDEX IF NOT EXISTS would not
            # update an existing index whose definition changed.
            for stale_index in (
                "ix_ontology_types_iri",
                "ix_ontology_types_qid",
                "ix_ontology_relation_types_iri",
                "ix_ontology_relation_types_pid",
            ):
                # Defensive: only drop if the existing definition differs
                # (i.e. doesn't include layer/workspace_id columns). Avoid
                # dropping freshly-correct indexes on every startup.
                cur = self._conn.execute(
                    "SELECT sql FROM sqlite_master WHERE type='index' AND name=?",
                    (stale_index,),
                )
                row = cur.fetchone()
                if row and row[0] and "layer" not in row[0]:
                    self._conn.execute(f"DROP INDEX {stale_index}")
            for index_sql in _CREATE_INDEXES:
                self._conn.execute(index_sql)
            self._conn.commit()

    def _table_exists(self, name: str) -> bool:
        cur = self._conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
        )
        return cur.fetchone() is not None

    def _table_has_column(self, table: str, column: str) -> bool:
        cur = self._conn.execute(f"PRAGMA table_info({table})")
        return any(row[1] == column for row in cur.fetchall())

    def _migrate_v1_to_v2(self) -> None:
        """Idempotent v1 → v2 schema rebuild for DIST-LITE-ONTO-1.

        Detects the v1 schema by the *absence* of the `id` column on
        `ontology_types` / `ontology_relation_types`. Rebuilds in a
        single transaction with WAL-rollback safety (PRAGMA already set
        at __init__).

        Idempotent: if `id` already exists or the table doesn't exist
        yet (fresh DB, CREATE TABLE will run next), this is a no-op.
        """
        for table_name, v2_ddl, copy_columns in (
            (
                "ontology_types",
                _CREATE_ENTITY_TYPES,
                "name_lower, name_display, status, frequency, avg_confidence",
            ),
            (
                "ontology_relation_types",
                _CREATE_RELATION_TYPES,
                "name_lower, name_display, status, category, frequency, aliases, type_pairs",
            ),
        ):
            if not self._table_exists(table_name):
                continue  # fresh DB; CREATE TABLE IF NOT EXISTS handles it
            if self._table_has_column(table_name, "id"):
                continue  # already v2

            logger.info(
                "DIST-LITE-ONTO-1: rebuilding %s (v1 → v2 schema)", table_name
            )
            v2_table = f"{table_name}_v2"
            v2_ddl_renamed = v2_ddl.replace(
                f"CREATE TABLE IF NOT EXISTS {table_name}",
                f"CREATE TABLE {v2_table}",
                1,
            )
            self._conn.execute("BEGIN")
            try:
                self._conn.execute(v2_ddl_renamed)
                self._conn.execute(
                    f"INSERT INTO {v2_table} ({copy_columns}) "
                    f"SELECT {copy_columns} FROM {table_name}"
                )
                self._conn.execute(f"DROP TABLE {table_name}")
                self._conn.execute(f"ALTER TABLE {v2_table} RENAME TO {table_name}")
                self._conn.execute("COMMIT")
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    def close(self) -> None:
        """Close the SQLite connection."""
        try:
            self._conn.close()
        except Exception:
            pass

    # ── Entity Type Management ──────────────────────────────────────

    def seed_types(self, types: Optional[List[str]] = None) -> int:
        types_to_seed = types or SEED_TYPES
        created = 0
        with self._lock:
            for name in types_to_seed:
                try:
                    cur = self._conn.execute(
                        "INSERT OR IGNORE INTO ontology_types (name_lower, name_display, status) "
                        "VALUES (?, ?, 'seed')",
                        (name.lower(), name),
                    )
                    if cur.rowcount > 0:
                        created += 1
                except Exception:
                    pass
            self._conn.commit()
        return created

    def get_type_status(self, name: str) -> Optional[str]:
        with self._lock:
            row = self._conn.execute(
                "SELECT status FROM ontology_types WHERE name_lower=?",
                (name.lower(),),
            ).fetchone()
        return row[0] if row else None

    def add_provisional(self, name: str) -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "INSERT OR IGNORE INTO ontology_types (name_lower, name_display, status) "
                "VALUES (?, ?, 'provisional')",
                (name.lower(), name),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def promote(self, name: str) -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE ontology_types SET status='confirmed' WHERE name_lower=?",
                (name.lower(),),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def reject(self, name: str) -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE ontology_types SET status='rejected' WHERE name_lower=?",
                (name.lower(),),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def increment_frequency(self, name: str, confidence: float) -> None:
        with self._lock:
            row = self._conn.execute(
                "SELECT frequency, avg_confidence FROM ontology_types WHERE name_lower=?",
                (name.lower(),),
            ).fetchone()
            if not row:
                return
            freq, avg_conf = row
            new_freq = freq + 1
            new_avg = (avg_conf * freq + confidence) / new_freq
            self._conn.execute(
                "UPDATE ontology_types SET frequency=?, avg_confidence=? WHERE name_lower=?",
                (new_freq, new_avg, name.lower()),
            )
            self._conn.commit()

    def get_frequency(self, name: str) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT frequency FROM ontology_types WHERE name_lower=?",
                (name.lower(),),
            ).fetchone()
        return row[0] if row else 0

    def get_entity_types(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT name_display, status, frequency, avg_confidence FROM ontology_types"
            ).fetchall()
        return [
            {"name": r[0], "status": r[1], "frequency": r[2], "avg_confidence": r[3]}
            for r in rows
        ]

    def get_all_frequencies(self) -> Dict[str, int]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT name_display, frequency FROM ontology_types"
            ).fetchall()
        return {r[0]: r[1] for r in rows}

    # ── Relation Types ──────────────────────────────────────────────

    def increment_relation_frequency(self, name: str, confidence: float) -> None:
        key = name.lower()
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO ontology_relation_types "
                "(name_lower, name_display, status, category, frequency) "
                "VALUES (?, ?, 'provisional', 'unknown', 0)",
                (key, name),
            )
            self._conn.execute(
                "UPDATE ontology_relation_types SET frequency=frequency+1 WHERE name_lower=?",
                (key,),
            )
            self._conn.commit()

    def add_provisional_relation_type(self, name: str, category: str = "unknown") -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "INSERT OR IGNORE INTO ontology_relation_types "
                "(name_lower, name_display, status, category) VALUES (?, ?, 'provisional', ?)",
                (name.lower(), name, category),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def get_relation_types(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._lock:
            if status:
                rows = self._conn.execute(
                    "SELECT name_display, status, category, frequency, aliases, type_pairs "
                    "FROM ontology_relation_types WHERE status=?",
                    (status,),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT name_display, status, category, frequency, aliases, type_pairs "
                    "FROM ontology_relation_types"
                ).fetchall()
        return [
            {
                "name": r[0], "status": r[1], "category": r[2], "frequency": r[3],
                "aliases": json.loads(r[4] or "[]"), "type_pairs": json.loads(r[5] or "[]"),
            }
            for r in rows
        ]

    # ── Entity Patterns ─────────────────────────────────────────────

    def add_entity_pattern(self, name, label, confidence=0.85,
                           workspace_id=None, is_global=False,
                           source="llm_discovery", initial_count=1, **kwargs) -> bool:
        key = name.lower()
        ws = workspace_id or self.workspace_id
        now = _now_iso()
        with self._lock:
            existing = self._conn.execute(
                "SELECT count FROM ontology_entity_patterns "
                "WHERE name_lower=? AND label=? AND workspace_id=?",
                (key, label, ws),
            ).fetchone()
            if existing:
                self._conn.execute(
                    "UPDATE ontology_entity_patterns SET count=count+1 WHERE "
                    "name_lower=? AND label=? AND workspace_id=?",
                    (key, label, ws),
                )
                self._conn.commit()
                return False  # Updated, not new
            else:
                self._conn.execute(
                    "INSERT INTO ontology_entity_patterns "
                    "(name_lower, label, workspace_id, count, confidence, is_global, source, discovered_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (key, label, ws, initial_count, confidence, int(is_global), source, now),
                )
                self._conn.commit()
                return True  # New pattern

    def get_entity_patterns(self, workspace_id=None) -> List[Dict]:
        ws = workspace_id or self.workspace_id
        with self._lock:
            rows = self._conn.execute(
                "SELECT name_lower, label, confidence, count, source "
                "FROM ontology_entity_patterns "
                "WHERE (is_global=1 OR workspace_id=?) AND count>=2",
                (ws,),
            ).fetchall()
        return [
            {"name": r[0], "label": r[1], "confidence": r[2], "count": r[3], "source": r[4]}
            for r in rows
        ]

    def seed_entity_patterns(self, patterns=None) -> int:
        return 0  # Seed patterns handled by JSONLPatternStore

    def get_pattern_stats(self) -> Dict[str, int]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT source, COUNT(*) FROM ontology_entity_patterns GROUP BY source"
            ).fetchall()
        return {r[0]: r[1] for r in rows}

    def get_type_assignments(self, entity_name: str) -> List[Dict]:
        """Return [{type, count}] matching OntologyGraph.get_type_assignments() shape."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT label, count FROM ontology_entity_patterns "
                "WHERE name_lower=? AND (is_global=1 OR workspace_id=?)",
                (entity_name.lower(), self.workspace_id),
            ).fetchall()
        return [{"type": r[0], "count": r[1]} for r in rows]

    def delete_entity_pattern(self, name, label, workspace_id=None) -> bool:
        ws = workspace_id or self.workspace_id
        with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM ontology_entity_patterns "
                "WHERE name_lower=? AND label=? AND workspace_id=?",
                (name.lower(), label, ws),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    # ── Novel Relation Labels ───────────────────────────────────────

    def add_novel_relation_label(self, name, raw_examples=None,
                                  source_types=None, target_types=None,
                                  workspace_id=None, **kwargs) -> bool:
        key = name.lower()
        ws = workspace_id or self.workspace_id
        now = _now_iso()
        examples_json = json.dumps(raw_examples or [])
        src_json = json.dumps(source_types or [])
        tgt_json = json.dumps(target_types or [])

        with self._lock:
            existing = self._conn.execute(
                "SELECT frequency, raw_examples FROM ontology_novel_relations "
                "WHERE name_lower=? AND workspace_id=?",
                (key, ws),
            ).fetchone()
            if existing:
                freq = existing[0]
                old_examples = json.loads(existing[1] or "[]")
                # Append new examples, cap at 10
                merged = (old_examples + (raw_examples or []))[:10]
                self._conn.execute(
                    "UPDATE ontology_novel_relations SET "
                    "frequency=?, raw_examples=?, last_seen=? "
                    "WHERE name_lower=? AND workspace_id=?",
                    (freq + 1, json.dumps(merged), now, key, ws),
                )
                self._conn.commit()
                return False  # Updated
            else:
                self._conn.execute(
                    "INSERT INTO ontology_novel_relations "
                    "(name_lower, workspace_id, frequency, status, raw_examples, "
                    "source_types, target_types, first_seen, last_seen) "
                    "VALUES (?, ?, 1, 'tracking', ?, ?, ?, ?, ?)",
                    (key, ws, examples_json, src_json, tgt_json, now, now),
                )
                self._conn.commit()
                return True  # New

    def get_novel_relation_labels(self, min_frequency=1, status=None,
                                   workspace_id=None) -> List[Dict]:
        ws = workspace_id or self.workspace_id
        with self._lock:
            if status:
                rows = self._conn.execute(
                    "SELECT name_lower, frequency, status, raw_examples, "
                    "source_types, target_types, first_seen, last_seen "
                    "FROM ontology_novel_relations "
                    "WHERE frequency>=? AND status=? AND workspace_id=?",
                    (min_frequency, status, ws),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT name_lower, frequency, status, raw_examples, "
                    "source_types, target_types, first_seen, last_seen "
                    "FROM ontology_novel_relations "
                    "WHERE frequency>=? AND workspace_id=?",
                    (min_frequency, ws),
                ).fetchall()
        return [
            {
                "name": r[0], "frequency": r[1], "status": r[2],
                "raw_examples": json.loads(r[3] or "[]"),
                "source_types": json.loads(r[4] or "[]"),
                "target_types": json.loads(r[5] or "[]"),
                "first_seen": r[6], "last_seen": r[7],
            }
            for r in rows
        ]

    def promote_relation_type(self, name, category="discovered",
                               aliases=None, type_pairs=None,
                               workspace_id=None, **kwargs) -> bool:
        key = name.lower()
        ws = workspace_id or self.workspace_id
        aliases_json = json.dumps(aliases or [])
        type_pairs_json = json.dumps(type_pairs or [])
        with self._lock:
            # DIST-LITE-ONTO-1 schema migration dropped `name_lower` PK
            # (replaced with surrogate `id INTEGER PRIMARY KEY` + composite
            # UNIQUE index on `(name_lower, layer, workspace_id,
            # COALESCE(pack_id, ''))`). The legacy `ON CONFLICT(name_lower)`
            # upsert no longer matches any single-column UNIQUE constraint
            # and SQLite raises OperationalError. Use the
            # UPDATE-then-INSERT-OR-IGNORE pattern that
            # `increment_relation_frequency` already uses (line 369): the
            # UPDATE touches every row sharing this `name_lower` (across
            # any slot), preserving the legacy v1 promote-by-name semantics
            # without depending on a single-column constraint.
            self._conn.execute(
                "UPDATE ontology_relation_types SET "
                "status='confirmed', name_display=?, category=?, "
                "aliases=?, type_pairs=? "
                "WHERE name_lower=?",
                (name, category, aliases_json, type_pairs_json, key),
            )
            # If no rows existed, insert a fresh confirmed row in the
            # default slot. INSERT OR IGNORE skips silently if a row
            # already landed during the UPDATE above (race-free under
            # the lock).
            self._conn.execute(
                "INSERT OR IGNORE INTO ontology_relation_types "
                "(name_lower, name_display, status, category, aliases, type_pairs) "
                "VALUES (?, ?, 'confirmed', ?, ?, ?)",
                (key, name, category, aliases_json, type_pairs_json),
            )
            # Update novel label status — scoped to workspace
            self._conn.execute(
                "UPDATE ontology_novel_relations SET status='promoted' "
                "WHERE name_lower=? AND workspace_id=?",
                (key, ws),
            )
            self._conn.commit()
            return True

    # ─────────────────────────────────────────────────────────────────
    # DIST-LITE-ONTO-1 — ONTO-RECONCILE-1 service surface (Buckets A/B/C)
    # All methods below mirror `OntologyGraph` private methods so
    # `OntologyService` works against either backend. See
    # `docs/features/DIST-LITE-ONTO-1/blueprint.md` for the contract.
    # ─────────────────────────────────────────────────────────────────

    # Column lists used by row → dataclass decoders. Kept in sync with
    # the v2 schema column order.
    _OT_SELECT_COLS = (
        "id, name_lower, name_display, status, frequency, avg_confidence, "
        "iri, wikidata_qid, layer, workspace_id, pack_id, tier, trust_origin"
    )
    _OR_SELECT_COLS = (
        "id, name_lower, name_display, status, category, frequency, "
        "aliases, type_pairs, iri, wikidata_pid, layer, workspace_id, "
        "pack_id, tier, trust_origin"
    )

    @staticmethod
    def _row_to_ontology_type(row) -> "OntologyType":
        """Map an `ontology_types` row tuple to an `OntologyType` dataclass.

        Lite mode persists only a subset of `OntologyType` fields. Missing
        fields take their dataclass defaults — governance/curation fields
        (definition, examples, parent_types, etc.) are not stored on SQLite.
        """
        from smartmemory.ontology.types import OntologyType
        (
            _id, _name_lower, name_display, _status, frequency, confidence,
            iri, wikidata_qid, layer, workspace_id, pack_id, tier, trust_origin,
        ) = row
        return OntologyType(
            name=name_display,
            iri=iri,
            wikidata_qid=wikidata_qid,
            display_name=name_display,
            tier=tier,
            trust_origin=trust_origin,
            layer=layer,
            workspace_id=workspace_id,
            pack_id=pack_id,
            frequency=frequency or 0,
            confidence=confidence or 0.0,
        )

    @staticmethod
    def _row_to_ontology_relation(row) -> "OntologyRelation":
        """Map an `ontology_relation_types` row tuple to an `OntologyRelation`."""
        from smartmemory.ontology.types import OntologyRelation
        (
            _id, _name_lower, name_display, _status, _category, frequency,
            aliases_json, _type_pairs_json, iri, wikidata_pid, layer,
            workspace_id, pack_id, tier, trust_origin,
        ) = row
        try:
            aliases = json.loads(aliases_json) if aliases_json else []
        except (TypeError, json.JSONDecodeError):
            aliases = []
        return OntologyRelation(
            name=name_display,
            iri=iri,
            wikidata_pid=wikidata_pid,
            display_name=name_display,
            aliases=aliases,
            tier=tier,
            trust_origin=trust_origin,
            layer=layer,
            workspace_id=workspace_id,
            pack_id=pack_id,
            frequency=frequency or 0,
        )

    # ── Bucket A — read-path lookups ────────────────────────────────

    def _get_ontology_type(
        self,
        identifier: str,
        layer: str,
        workspace_id: str,
        pack_id: Optional[str] = None,
        *,
        key: Optional[str] = None,
    ):
        """Resolve a single ontology type row within an exact slot.

        Mirrors `OntologyGraph._get_ontology_type`. Identity priority:
        iri → wikidata_qid → composite `(name_lower, layer, workspace_id, pack_id)`.
        Composite branch requires `iri IS NULL AND wikidata_qid IS NULL` so an
        iri/qid-anchored row in the same slot doesn't satisfy a name-only lookup.
        """
        branches = (key,) if key is not None else ("iri", "qid", "name")
        with self._lock:
            for branch in branches:
                row = self._lookup_ot_in_slot(branch, identifier, layer, workspace_id, pack_id)
                if row is not None:
                    return self._row_to_ontology_type(row)
        return None

    def _get_ontology_type_any_pack(
        self,
        identifier: str,
        layer: str,
        workspace_id: str,
        *,
        key: Optional[str] = None,
    ):
        """Resolve a type in a layer, ignoring `pack_id` slot. Deterministic via ORDER BY."""
        branches = (key,) if key is not None else ("iri", "qid", "name")
        with self._lock:
            for branch in branches:
                row = self._lookup_ot_any_pack(branch, identifier, layer, workspace_id)
                if row is not None:
                    return self._row_to_ontology_type(row)
        return None

    def _list_ontology_types(
        self,
        *,
        tier: Optional[str] = None,
        layer: Optional[str] = None,
        pack_id: Optional[str] = None,
        workspace_id: Optional[str] = None,
        has_iri: Optional[bool] = None,
        limit: Optional[int] = None,
    ) -> List["OntologyType"]:
        clauses = []
        params: List[Any] = []
        if tier is not None:
            clauses.append("tier = ?")
            params.append(tier)
        if layer is not None:
            clauses.append("layer = ?")
            params.append(layer)
        if pack_id is not None:
            clauses.append("pack_id = ?")
            params.append(pack_id)
        if workspace_id is not None:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        if has_iri is True:
            clauses.append("iri IS NOT NULL")
        elif has_iri is False:
            clauses.append("iri IS NULL")
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT {self._OT_SELECT_COLS} FROM ontology_types{where} ORDER BY frequency DESC, name_lower ASC"
        if limit is not None:
            sql += f" LIMIT {int(limit)}"
        with self._lock:
            cur = self._conn.execute(sql, params)
            return [self._row_to_ontology_type(r) for r in cur.fetchall()]

    def _list_ontology_types_for_priming(
        self,
        *,
        workspace_id: str,
        tier: str = "confirmed",
        limit: int,
    ) -> List[Dict[str, Any]]:
        """Projected, frequency-ranked list for `OntologyService.priming_payload`.

        Returns ONLY the priming-payload fields (`name`, `iri`, `qid`,
        `aliases`, `tier`, `frequency`) as plain dicts — mirrors the
        FalkorDB contract at `ontology_graph.py:1328`. SQLite has no
        `aliases` column on types, so the field is always `[]` here
        (fine for priming; lite mode rarely needs verbose aliases).
        """
        sql = (
            "SELECT name_display, iri, wikidata_qid, tier, frequency "
            "FROM ontology_types "
            "WHERE tier = ? AND workspace_id = ? "
            f"ORDER BY frequency DESC, name_lower ASC LIMIT {int(limit)}"
        )
        with self._lock:
            cur = self._conn.execute(sql, (tier, workspace_id))
            rows = cur.fetchall()
        return [
            {
                "name": r[0],
                "iri": r[1],
                "qid": r[2],
                "aliases": [],
                "tier": r[3],
                "frequency": r[4] or 0,
            }
            for r in rows
        ]

    def _get_ontology_relation(
        self,
        identifier: str,
        layer: str,
        workspace_id: str,
        pack_id: Optional[str] = None,
        *,
        key: Optional[str] = None,
    ):
        branches = (key,) if key is not None else ("iri", "pid", "name")
        with self._lock:
            for branch in branches:
                row = self._lookup_or_in_slot(branch, identifier, layer, workspace_id, pack_id)
                if row is not None:
                    return self._row_to_ontology_relation(row)
        return None

    def _get_ontology_relation_any_pack(
        self,
        identifier: str,
        layer: str,
        workspace_id: str,
        *,
        key: Optional[str] = None,
    ):
        branches = (key,) if key is not None else ("iri", "pid", "name")
        with self._lock:
            for branch in branches:
                row = self._lookup_or_any_pack(branch, identifier, layer, workspace_id)
                if row is not None:
                    return self._row_to_ontology_relation(row)
        return None

    def _list_ontology_relations(
        self,
        *,
        tier: Optional[str] = None,
        layer: Optional[str] = None,
        pack_id: Optional[str] = None,
        workspace_id: Optional[str] = None,
        has_iri: Optional[bool] = None,
        limit: Optional[int] = None,
    ) -> List["OntologyRelation"]:
        clauses = []
        params: List[Any] = []
        if tier is not None:
            clauses.append("tier = ?")
            params.append(tier)
        if layer is not None:
            clauses.append("layer = ?")
            params.append(layer)
        if pack_id is not None:
            clauses.append("pack_id = ?")
            params.append(pack_id)
        if workspace_id is not None:
            clauses.append("workspace_id = ?")
            params.append(workspace_id)
        if has_iri is True:
            clauses.append("iri IS NOT NULL")
        elif has_iri is False:
            clauses.append("iri IS NULL")
        where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = (
            f"SELECT {self._OR_SELECT_COLS} FROM ontology_relation_types"
            f"{where} ORDER BY frequency DESC, name_lower ASC"
        )
        if limit is not None:
            sql += f" LIMIT {int(limit)}"
        with self._lock:
            cur = self._conn.execute(sql, params)
            return [self._row_to_ontology_relation(r) for r in cur.fetchall()]

    # ── Identity-branch SQL helpers (Bucket A internals) ────────────

    def _lookup_ot_in_slot(self, branch, identifier, layer, workspace_id, pack_id):
        return self._lookup_in_slot("ontology_types", "wikidata_qid", branch,
                                    identifier, layer, workspace_id, pack_id)

    def _lookup_ot_any_pack(self, branch, identifier, layer, workspace_id):
        return self._lookup_any_pack("ontology_types", "wikidata_qid", branch,
                                     identifier, layer, workspace_id)

    def _lookup_or_in_slot(self, branch, identifier, layer, workspace_id, pack_id):
        return self._lookup_in_slot("ontology_relation_types", "wikidata_pid", branch,
                                    identifier, layer, workspace_id, pack_id)

    def _lookup_or_any_pack(self, branch, identifier, layer, workspace_id):
        return self._lookup_any_pack("ontology_relation_types", "wikidata_pid", branch,
                                     identifier, layer, workspace_id)

    def _lookup_in_slot(self, table, qid_col, branch, identifier, layer, workspace_id, pack_id):
        select_cols = self._OT_SELECT_COLS if table == "ontology_types" else self._OR_SELECT_COLS
        if branch == "iri":
            sql = (f"SELECT {select_cols} FROM {table} WHERE iri = ? "
                   "AND layer = ? AND workspace_id = ? "
                   "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1")
            params = (identifier, layer, workspace_id, pack_id)
        elif branch in ("qid", "pid"):
            sql = (f"SELECT {select_cols} FROM {table} WHERE {qid_col} = ? "
                   "AND layer = ? AND workspace_id = ? "
                   "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1")
            params = (identifier, layer, workspace_id, pack_id)
        elif branch == "name":
            sql = (f"SELECT {select_cols} FROM {table} "
                   f"WHERE iri IS NULL AND {qid_col} IS NULL "
                   "AND name_lower = ? AND layer = ? AND workspace_id = ? "
                   "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1")
            params = (identifier.lower(), layer, workspace_id, pack_id)
        else:
            return None
        cur = self._conn.execute(sql, params)
        return cur.fetchone()

    def _lookup_any_pack(self, table, qid_col, branch, identifier, layer, workspace_id):
        select_cols = self._OT_SELECT_COLS if table == "ontology_types" else self._OR_SELECT_COLS
        if branch == "iri":
            sql = (f"SELECT {select_cols} FROM {table} WHERE iri = ? "
                   "AND layer = ? AND workspace_id = ? "
                   "ORDER BY pack_id LIMIT 1")
            params = (identifier, layer, workspace_id)
        elif branch in ("qid", "pid"):
            sql = (f"SELECT {select_cols} FROM {table} WHERE {qid_col} = ? "
                   "AND layer = ? AND workspace_id = ? "
                   "ORDER BY pack_id LIMIT 1")
            params = (identifier, layer, workspace_id)
        elif branch == "name":
            sql = (f"SELECT {select_cols} FROM {table} "
                   f"WHERE iri IS NULL AND {qid_col} IS NULL "
                   "AND name_lower = ? AND layer = ? AND workspace_id = ? "
                   "ORDER BY pack_id LIMIT 1")
            params = (identifier.lower(), layer, workspace_id)
        else:
            return None
        cur = self._conn.execute(sql, params)
        return cur.fetchone()

    # ── Bucket B — write-path (upsert + entity link) ────────────────

    # Tier ranking for monotonicity guard. Mirrors the FalkorDB constant
    # `OntologyGraph._ONTO_TYPE_TIER_RANK` at ontology_graph.py:906.
    _TIER_RANK = {"working": 1, "proposed": 2, "confirmed": 3, "retired": 4}

    def _upsert_ontology_type(self, ot) -> None:
        """Upsert an `OntologyType` per the identity rule.

        Identity priority: iri → wikidata_qid → composite
        `(name_lower, layer, workspace_id, pack_id)`. Tier never demotes
        (mirror `_ONTO_TYPE_TIER_RANK`). Same iri/qid bound to a different
        name within the slot raises `ValueError`.
        """
        with self._lock:
            existing = self._resolve_ot_for_upsert(ot)
            if existing is None:
                self._conn.execute(
                    "INSERT INTO ontology_types (name_lower, name_display, status, "
                    "frequency, avg_confidence, iri, wikidata_qid, layer, workspace_id, "
                    "pack_id, tier, trust_origin) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        ot.name.lower(), ot.name, "seed",
                        int(ot.frequency or 0), float(ot.confidence or 0.0),
                        ot.iri, ot.wikidata_qid,
                        ot.layer or "private",
                        ot.workspace_id or "default",
                        ot.pack_id, ot.tier or "working",
                        ot.trust_origin or "batch_proposed",
                    ),
                )
            else:
                row_id, existing_name, existing_tier = existing
                # Identity-collision invariant: same iri/qid bound to a
                # different name → fail loudly, mirror FalkorDB.
                if (ot.iri or ot.wikidata_qid) and existing_name.lower() != ot.name.lower():
                    raise ValueError(
                        f"OntologyType identity conflict: iri={ot.iri!r} qid={ot.wikidata_qid!r} "
                        f"already bound to name={existing_name!r}, refusing rebind to {ot.name!r}"
                    )
                # Tier never demotes.
                new_tier = ot.tier or existing_tier
                if self._TIER_RANK.get(new_tier, 0) < self._TIER_RANK.get(existing_tier, 0):
                    new_tier = existing_tier
                self._conn.execute(
                    "UPDATE ontology_types SET name_display = ?, frequency = ?, "
                    "avg_confidence = ?, iri = COALESCE(?, iri), "
                    "wikidata_qid = COALESCE(?, wikidata_qid), tier = ?, "
                    "trust_origin = COALESCE(?, trust_origin) WHERE id = ?",
                    (
                        ot.name, int(ot.frequency or 0), float(ot.confidence or 0.0),
                        ot.iri, ot.wikidata_qid, new_tier, ot.trust_origin, row_id,
                    ),
                )
            self._conn.commit()

    def _upsert_ontology_relation(self, rel) -> None:
        """Upsert an `OntologyRelation` per the identity rule. Mirrors `_upsert_ontology_type`
        with `wikidata_pid` instead of `wikidata_qid`.
        """
        with self._lock:
            existing = self._resolve_or_for_upsert(rel)
            aliases_json = json.dumps(rel.aliases or [])
            if existing is None:
                self._conn.execute(
                    "INSERT INTO ontology_relation_types (name_lower, name_display, status, "
                    "category, frequency, aliases, type_pairs, iri, wikidata_pid, "
                    "layer, workspace_id, pack_id, tier, trust_origin) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        rel.name.lower(), rel.name, "provisional", "unknown",
                        int(rel.frequency or 0), aliases_json, "[]",
                        rel.iri, rel.wikidata_pid,
                        rel.layer or "private",
                        rel.workspace_id or "default",
                        rel.pack_id, rel.tier or "working",
                        rel.trust_origin or "batch_proposed",
                    ),
                )
            else:
                row_id, existing_name, existing_tier = existing
                if (rel.iri or rel.wikidata_pid) and existing_name.lower() != rel.name.lower():
                    raise ValueError(
                        f"OntologyRelation identity conflict: iri={rel.iri!r} "
                        f"pid={rel.wikidata_pid!r} already bound to name={existing_name!r}, "
                        f"refusing rebind to {rel.name!r}"
                    )
                new_tier = rel.tier or existing_tier
                if self._TIER_RANK.get(new_tier, 0) < self._TIER_RANK.get(existing_tier, 0):
                    new_tier = existing_tier
                self._conn.execute(
                    "UPDATE ontology_relation_types SET name_display = ?, frequency = ?, "
                    "aliases = ?, iri = COALESCE(?, iri), "
                    "wikidata_pid = COALESCE(?, wikidata_pid), tier = ?, "
                    "trust_origin = COALESCE(?, trust_origin) WHERE id = ?",
                    (
                        rel.name, int(rel.frequency or 0), aliases_json,
                        rel.iri, rel.wikidata_pid, new_tier, rel.trust_origin, row_id,
                    ),
                )
            self._conn.commit()

    def _link_entity_to_type(self, entity_id: str, type_obj) -> None:
        """Idempotent INSERT — second call on the same entity/type pair is a no-op."""
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO ontology_entity_links "
                "(entity_id, type_iri, type_wikidata_qid, type_name_lower, "
                "type_layer, type_workspace_id, type_pack_id, linked_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    entity_id, type_obj.iri, type_obj.wikidata_qid,
                    (type_obj.name or "").lower(),
                    type_obj.layer or "private",
                    type_obj.workspace_id or "default",
                    type_obj.pack_id, _now_iso(),
                ),
            )
            self._conn.commit()

    def _resolve_ot_for_upsert(self, ot):
        """Find existing row by identity (iri → qid → composite) **scoped to the
        target slot** `(layer, workspace_id, pack_id)`. Returns `(id, name_display, tier)`
        or `None`.

        Slot scoping on iri/qid branches matches the FalkorDB reference
        contract (`OntologyGraph._upsert_ontology_type`). Without it, the same
        iri/qid in a different slot (e.g., a public seed) would be matched
        and updated by a private-layer write — an identity-resolution
        invariant violation. Post-Codex DIST-LITE-ONTO-1 implementation
        review correction.
        """
        layer = ot.layer or "private"
        workspace_id = ot.workspace_id or "default"
        pack_id = ot.pack_id
        if ot.iri:
            row = self._conn.execute(
                "SELECT id, name_display, tier FROM ontology_types "
                "WHERE iri = ? AND layer = ? AND workspace_id = ? "
                "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1",
                (ot.iri, layer, workspace_id, pack_id),
            ).fetchone()
            if row:
                return row
        if ot.wikidata_qid:
            row = self._conn.execute(
                "SELECT id, name_display, tier FROM ontology_types "
                "WHERE wikidata_qid = ? AND layer = ? AND workspace_id = ? "
                "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1",
                (ot.wikidata_qid, layer, workspace_id, pack_id),
            ).fetchone()
            if row:
                return row
        row = self._conn.execute(
            "SELECT id, name_display, tier FROM ontology_types "
            "WHERE iri IS NULL AND wikidata_qid IS NULL "
            "AND name_lower = ? AND layer = ? AND workspace_id = ? "
            "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1",
            (ot.name.lower(), layer, workspace_id, pack_id),
        ).fetchone()
        return row

    def _resolve_or_for_upsert(self, rel):
        """Slot-scoped relation resolver — see `_resolve_ot_for_upsert` for rationale."""
        layer = rel.layer or "private"
        workspace_id = rel.workspace_id or "default"
        pack_id = rel.pack_id
        if rel.iri:
            row = self._conn.execute(
                "SELECT id, name_display, tier FROM ontology_relation_types "
                "WHERE iri = ? AND layer = ? AND workspace_id = ? "
                "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1",
                (rel.iri, layer, workspace_id, pack_id),
            ).fetchone()
            if row:
                return row
        if rel.wikidata_pid:
            row = self._conn.execute(
                "SELECT id, name_display, tier FROM ontology_relation_types "
                "WHERE wikidata_pid = ? AND layer = ? AND workspace_id = ? "
                "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1",
                (rel.wikidata_pid, layer, workspace_id, pack_id),
            ).fetchone()
            if row:
                return row
        row = self._conn.execute(
            "SELECT id, name_display, tier FROM ontology_relation_types "
            "WHERE iri IS NULL AND wikidata_pid IS NULL "
            "AND name_lower = ? AND layer = ? AND workspace_id = ? "
            "AND COALESCE(pack_id, '') = COALESCE(?, '') LIMIT 1",
            (rel.name.lower(), layer, workspace_id, pack_id),
        ).fetchone()
        return row

    # ── Bucket C — governance (real impls + UnsupportedBackendError raisers) ─

    # Lite-mode evidence read default — mirrors FalkorDB
    # `_EVIDENCE_DEFAULTS` shape from `ontology_graph.py:2183`.
    _EVIDENCE_DEFAULTS = {
        "frequency": 0,
        "confidence_sum": 0.0,
        "confidence_count": 0,
        "mention_distribution": {},
        "evidence_refs": [],
        "hearst_hits": [],
        "cohesion": None,
        "has_batch_signal": False,
    }

    def _set_ontology_type_tier(self, type_obj, new_tier: str) -> None:
        """UPDATE the tier of an existing type row, identity-resolved."""
        with self._lock:
            existing = self._resolve_ot_for_upsert(type_obj)
            if existing is None:
                logger.debug(
                    "DIST-LITE-ONTO-1: _set_ontology_type_tier — no row matches identity for %r",
                    type_obj.name,
                )
                return
            row_id = existing[0]
            self._conn.execute(
                "UPDATE ontology_types SET tier = ? WHERE id = ?",
                (new_tier, row_id),
            )
            self._conn.commit()

    def _get_evidence_for_type(self, identifier: str, *, workspace_id: str) -> Dict[str, Any]:
        """Lite mode does not persist evidence — return defaults (read-only no-op)."""
        return dict(self._EVIDENCE_DEFAULTS)

    def _list_workspace_installations(self, workspace_id: str) -> List[Dict[str, Any]]:
        """Lite mode has no pack registry — always empty."""
        return []

    def _get_audit_for_type(self, type_id: str) -> List[Dict[str, Any]]:
        """Lite mode does not persist an audit log — always empty."""
        return []

    def _get_audit_for_relation(self, relation_id: str) -> List[Dict[str, Any]]:
        """Lite mode does not persist an audit log — always empty."""
        return []

    # Write-side raisers — caught by EvidenceStore (evidence/cohesion) or
    # OntologyService._safe_governance (audit log). Pack registry calls
    # remain unshielded so install_pack/uninstall_pack fail loudly.

    def _record_observation_evidence(self, *args, **kwargs) -> None:
        from smartmemory.backends.unsupported import BackendKind, UnsupportedBackendError
        raise UnsupportedBackendError(
            BackendKind.SQLITE, "ontology_evidence_store",
            reason="evidence accrual not supported in lite mode",
        )

    def _set_cohesion(self, *args, **kwargs) -> None:
        from smartmemory.backends.unsupported import BackendKind, UnsupportedBackendError
        raise UnsupportedBackendError(
            BackendKind.SQLITE, "ontology_evidence_store",
            reason="cohesion is part of the evidence store; not supported in lite mode",
        )

    def _record_pack_installation(self, *args, **kwargs) -> None:
        from smartmemory.backends.unsupported import BackendKind, UnsupportedBackendError
        raise UnsupportedBackendError(
            BackendKind.SQLITE, "ontology_pack_registry",
            reason="pack installations not supported in lite mode",
        )

    def _remove_pack_installation(self, *args, **kwargs) -> bool:
        from smartmemory.backends.unsupported import BackendKind, UnsupportedBackendError
        raise UnsupportedBackendError(
            BackendKind.SQLITE, "ontology_pack_registry",
            reason="pack installations not supported in lite mode",
        )

    def _write_audit_entry(self, *args, **kwargs) -> str:
        from smartmemory.backends.unsupported import BackendKind, UnsupportedBackendError
        raise UnsupportedBackendError(
            BackendKind.SQLITE, "ontology_audit_log",
            reason="audit log not supported in lite mode",
        )
