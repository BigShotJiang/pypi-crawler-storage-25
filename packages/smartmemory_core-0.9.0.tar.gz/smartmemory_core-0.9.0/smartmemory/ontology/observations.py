"""ONTO-RECONCILE-1 — Observation dataclass.

Single source of truth for the observation record produced by all three
observers (online, batch, manual). The unified `Promoter` reads these
into the `EvidenceStore` and runs gates against accumulated state.

`entity_mention` is the extracted text (used for type-consistency and
disambiguation gates). `type_name` is the type label (used for length
and blocklist gates). They are deliberately distinct fields, not a
single ambiguous `name`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

ObservationMode = Literal["online", "batch", "manual"]
ObservationSource = Literal[
    "inline", "batch", "manual", "inline_replay", "imported_owl"
]


@dataclass
class Observation:
    entity_mention: str
    type_name: str
    type_iri: str | None = None
    type_qid: str | None = None
    confidence: float = 0.0
    source: ObservationSource = "inline"
    evidence_ref: str | None = None
    mode: ObservationMode = "online"
    batch_id: str | None = None
    cohesion_score: float | None = None
    hearst_evidence: dict | None = None
