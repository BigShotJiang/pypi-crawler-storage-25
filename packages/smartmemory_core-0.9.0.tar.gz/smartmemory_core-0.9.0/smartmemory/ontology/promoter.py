"""ONTO-RECONCILE-1 Task 3b — Unified Promoter.

ONE algorithm. THREE input modes (Online, Batch, Manual via
`smartmemory.ontology.observers`). All observers emit `Observation`
records to `EvidenceStore`; the Promoter reads `EvidenceSnapshot` and
runs the same gates regardless of mode.

Mode-independence is the load-bearing acceptance contract:

    Given the same EvidenceStore state, the Promoter returns the same
    PromotionVerdict regardless of which observer mode supplied the
    contributions.

(Modes can produce DIFFERENT evidence states — batch produces cohesion,
online doesn't — but evaluating the resulting state is mode-agnostic.)

Gate order (short-circuit: later gates only run if earlier ones pass):
    1. min_length         — gate on `type_name`
    2. blocklist          — gate on `type_name` (case-insensitive)
    3. min_confidence     — gate on `EvidenceSnapshot.confidence_avg`
    4. min_frequency      — gate on `EvidenceSnapshot.frequency`
    5. consistency        — gate on top-mention dominance
    6. cohesion           — batch-only; SKIPPED when no batch signal
    7. reasoning_validation — opt-in via config flag

Failed gate is recorded explicitly on the verdict (`failed_gate` /
`reason`) per `feedback_no_silent_fallbacks`.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from smartmemory.ontology.blocklist import COMMON_WORD_BLOCKLIST, is_blocked
from smartmemory.ontology.types import Tier, TrustOrigin

if TYPE_CHECKING:
    from smartmemory.ontology.evidence_store import EvidenceSnapshot, EvidenceStore
    from smartmemory.pipeline.config import PromotionConfig

logger = logging.getLogger(__name__)


# Mapping from the originating Observation.mode to the TrustOrigin that
# the Promoter stamps onto a positive verdict. ManualObserver bypasses
# the Promoter entirely (decisive HITL — see observers.py), so "manual"
# is included for symmetry but not normally produced here.
_MODE_TO_TRUST_ORIGIN: dict[str, TrustOrigin] = {
    "online": "online_promoted",
    "batch": "batch_proposed",
    "manual": "manual",
}


@dataclass
class PromotionVerdict:
    """The Promoter's decision on a type identifier.

    `promote=True` does NOT mean "write to graph" — `OntologyService`
    inspects current tier and writes only on actual change. Mirrors
    Task 3's same-tier no-op pattern.
    """

    promote: bool
    to_tier: Tier
    trust_origin: TrustOrigin
    failed_gate: str | None
    reason: str

    @property
    def passed(self) -> bool:
        return self.promote


class Promoter:
    """Apply gates to accumulated evidence. Returns a verdict."""

    def __init__(
        self,
        *,
        evidence_store: EvidenceStore,
        config: PromotionConfig,
        blocklist: frozenset[str] | None = None,
    ):
        self._store = evidence_store
        self._config = config
        # Operators override per-deployment by passing a custom blocklist;
        # default frozen set lives in `smartmemory/ontology/blocklist.py`.
        self._blocklist = blocklist if blocklist is not None else COMMON_WORD_BLOCKLIST

    def evaluate(
        self,
        identifier: str,
        *,
        type_name: str | None = None,
        mode: str = "online",
        current_tier: Tier = "working",
    ) -> PromotionVerdict:
        """Run gates against the snapshot at `identifier`.

        - `identifier` is iri / qid / type_name — same input set as
          `Observation` produces. Used as the EvidenceStore key.
        - `type_name` is the human-readable label gates 1-2 evaluate on.
          Defaults to `identifier` when not given (e.g. when callers
          look up by name).
        - `mode` determines `trust_origin` on a positive verdict.
          `online_promoted → inline-trust at proposed` is a heuristic;
          refine after Phase 0 measurement gives real promotion data.
        - `current_tier` is informational — the Promoter never writes
          tier itself; `OntologyService.record_observation` is responsible
          for the same-tier no-op check before calling
          `_set_ontology_type_tier`.
        """
        snap = self._store.get(identifier, type_name=type_name)
        name = snap.type_name

        # Gate 1: min_length on type_name.
        if len(name.strip()) < self._config.min_name_length:
            return self._reject(
                "min_length",
                f"type_name {name!r} length {len(name.strip())} < {self._config.min_name_length}",
            )

        # Gate 2: blocklist on type_name.
        if is_blocked(name, self._blocklist):
            return self._reject("blocklist", f"type_name {name!r} is in common-word blocklist")

        # Gate 3: min_confidence on accumulated avg.
        if snap.confidence_avg < self._config.min_confidence:
            return self._reject(
                "min_confidence",
                f"confidence_avg {snap.confidence_avg:.3f} < {self._config.min_confidence}",
            )

        # Gate 4: min_frequency.
        if snap.frequency < self._config.min_frequency:
            return self._reject(
                "min_frequency",
                f"frequency {snap.frequency} < {self._config.min_frequency}",
            )

        # Gate 5: consistency on (entity_mention → type) dominance.
        # Skipped when no mentions recorded (batch-imported types may have
        # zero mentions but valid LLM confidence + frequency).
        if snap.mention_distribution and snap.consistency < self._config.min_type_consistency:
            return self._reject(
                "consistency",
                f"top-mention dominance {snap.consistency:.3f} < {self._config.min_type_consistency}",
            )

        # Gate 6: cohesion (batch-only). When the snapshot has no batch
        # signal, this gate is a no-op — online-mode types pass through.
        # When batch contributed, require cohesion >= min_confidence as
        # a sane default; operators can tighten via config.min_confidence.
        if snap.has_batch_signal:
            cohesion = snap.cohesion or 0.0
            if cohesion < self._config.min_confidence:
                return self._reject(
                    "cohesion",
                    f"cohesion {cohesion:.3f} < {self._config.min_confidence}",
                )

        # Gate 7: reasoning_validation (optional). Behind config flag.
        # Lazy import to avoid pulling LLM dependencies into the Promoter
        # when the gate is off.
        if self._config.reasoning_validation:
            verdict = self._run_reasoning_validation(snap)
            if verdict is not None:
                return verdict  # rejection (or pass-through if validator absent)

        trust_origin = _MODE_TO_TRUST_ORIGIN.get(mode, "batch_proposed")
        return PromotionVerdict(
            promote=True,
            to_tier="proposed",
            trust_origin=trust_origin,
            failed_gate=None,
            reason="all gates passed",
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _reject(gate: str, reason: str) -> PromotionVerdict:
        # `to_tier` on rejection is the current "working" — promotion
        # didn't happen, so the caller's same-tier no-op path treats this
        # as no graph write needed. Keeps the verdict shape uniform so
        # callers don't branch on `promote`.
        return PromotionVerdict(
            promote=False,
            to_tier="working",
            trust_origin="batch_proposed",
            failed_gate=gate,
            reason=reason,
        )

    def _run_reasoning_validation(self, snap: EvidenceSnapshot) -> PromotionVerdict | None:
        """Run the optional ReasoningValidator if available.

        Returns a rejection verdict if validation fails; None if the
        validator is absent (degrades visibly via WARNING log) or
        passes. Per `feedback_no_silent_fallbacks`, an absent validator
        is logged but not treated as failure — operators opt-in via
        config and the failure mode is "validator missing", not
        "promotion silently unchecked".
        """
        try:
            from smartmemory.ontology.reasoning_validator import ReasoningValidator
        except ImportError:
            logger.warning(
                "reasoning_validation gate enabled but ReasoningValidator import failed; "
                "skipping gate for type %r — install reasoning extras to enable",
                snap.type_name,
            )
            return None

        validator = ReasoningValidator()
        stats = {"frequency": snap.frequency, "confidence_avg": snap.confidence_avg}
        result = validator.validate_snapshot(snap, stats) if hasattr(validator, "validate_snapshot") else None
        if result is None:
            logger.warning(
                "ReasoningValidator does not implement validate_snapshot; "
                "skipping gate for type %r",
                snap.type_name,
            )
            return None
        if not result.is_valid:
            return self._reject(
                "reasoning_validation",
                f"reasoning validator rejected: {getattr(result, 'explanation', '<no explanation>')}",
            )
        return None
