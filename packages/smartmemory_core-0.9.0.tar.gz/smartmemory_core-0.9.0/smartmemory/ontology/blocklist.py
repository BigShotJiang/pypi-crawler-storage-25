"""ONTO-RECONCILE-1 Task 3b — Common-word blocklist for the unified Promoter.

Lifted out of `smartmemory/ontology/promotion.py` so the unified Promoter
(`smartmemory/ontology/promoter.py`) and the legacy `PromotionEvaluator`
both read from a single source. Operators tune the blocklist
per-deployment by either editing this module or pointing
`Promoter(blocklist=...)` at a custom frozenset.

Membership lookup is case-insensitive — callers MUST `.lower().strip()`
before checking, OR call `is_blocked()` which handles normalization.
"""

from __future__ import annotations

COMMON_WORD_BLOCKLIST: frozenset[str] = frozenset(
    {
        "the", "a", "an", "this", "that", "these", "those", "it", "its",
        "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did",
        "will", "would", "shall", "should", "may", "might", "must", "can", "could",
        "and", "but", "or", "nor", "for", "yet", "so",
        "if", "then", "else", "when", "where", "while",
        "although", "because", "since", "until",
        "after", "before", "during",
        "about", "above", "below", "between", "into", "through",
        "with", "without", "under", "over",
        "from", "to", "in", "on", "at", "by", "of", "up", "out", "off",
        "not", "no", "yes",
        "all", "each", "every", "both", "few", "more", "most",
        "other", "some", "such", "any", "only", "own", "same",
        "than", "too", "very", "just", "also", "now",
        "here", "there", "how", "what", "which", "who", "whom", "whose", "why",
        "much", "many", "new", "old", "big", "small",
        "long", "short", "high", "low", "good", "bad", "great", "little",
        "first", "last", "next", "back",
        "well", "way", "even", "still",
        "already", "always", "never", "often",
        "really", "quite", "rather", "almost", "enough",
        "thing", "things", "something", "nothing", "anything", "everything",
        "one", "two", "three", "part", "time", "day", "year", "people",
        "made", "make", "like", "know", "get", "got", "say", "said", "see",
        "go", "come", "take", "give", "think", "tell", "work", "call", "try",
        "need", "use", "find", "want", "seem", "show", "look",
        "set", "put", "run", "move", "play", "point", "help", "turn",
        "start", "end", "keep", "let", "begin",
        "fact", "case", "lot", "able", "sure", "real",
        "right", "left", "different", "important", "another",
        "used", "using",
    }
)


def is_blocked(name: str, blocklist: frozenset[str] | None = None) -> bool:
    """Case-insensitive blocklist check after stripping whitespace.

    `blocklist=None` uses the default `COMMON_WORD_BLOCKLIST`. Operators
    overriding the default pass a custom frozenset (the Promoter accepts
    one in its ctor — no monkey-patching needed).
    """
    if blocklist is None:
        blocklist = COMMON_WORD_BLOCKLIST
    return name.lower().strip() in blocklist
