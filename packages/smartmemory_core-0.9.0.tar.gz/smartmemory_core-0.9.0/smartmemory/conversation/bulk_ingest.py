"""Conversation-aware bulk ingestion (RLM-1g).

Session-level chunking with concurrent pipeline execution.
Each session chunk runs the full 11-stage pipeline.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

DEFAULT_TURNS_PER_CHUNK = 15
DEFAULT_MAX_CHUNK_CHARS = 12000
DEFAULT_MAX_CONCURRENT = 4


@dataclass
class ChunkResult:
    chunk_index: int
    item_id: Optional[str] = None
    error: Optional[str] = None
    turn_range: Tuple[int, int] = (0, 0)
    duration_ms: float = 0.0

    @property
    def ok(self) -> bool:
        return self.error is None


@dataclass
class ConversationIngestResponse:
    conversation_id: str
    conversation_node_id: str
    chunks_ingested: int
    chunks_failed: int
    total_turns: int
    total_chunks: int
    chunk_results: List[ChunkResult] = field(default_factory=list)
    total_duration_ms: float = 0.0


class ConversationChunker:
    """Groups conversation turns into session chunks for pipeline ingestion."""

    def __init__(
        self,
        turns_per_chunk: int = DEFAULT_TURNS_PER_CHUNK,
        max_chunk_chars: int = DEFAULT_MAX_CHUNK_CHARS,
    ):
        self._turns_per_chunk = turns_per_chunk
        self._max_chunk_chars = max_chunk_chars

    def chunk(
        self,
        turns: List[Dict[str, str]],
        session_boundaries: Optional[List[int]] = None,
        session_dates: Optional[List[str]] = None,
        conversation_id: str = "",
    ) -> List[Dict[str, Any]]:
        """Split turns into chunks with metadata.

        Returns list of chunk dicts:
        {
            "content": str,          # Concatenated turns as "[Speaker]: content"
            "metadata": dict,        # session_index, turn_range, conversation_id, speakers
            "turn_range": (int,int), # For ChunkResult
        }
        """
        if not turns:
            raise ValueError("turns must be non-empty")

        # Determine session groups
        if session_boundaries is not None:
            self._validate_boundaries(session_boundaries, len(turns), session_dates)
            groups = self._split_by_boundaries(turns, session_boundaries)
        else:
            groups = self._split_by_count(turns)

        # Build chunks with metadata
        chunks = []
        for session_idx, (start, _end, group_turns) in enumerate(groups):
            session_date = (
                session_dates[session_idx]
                if session_dates and session_idx < len(session_dates)
                else None
            )

            # Sub-split by max_chunk_chars if needed
            sub_chunks = self._split_by_chars(group_turns, start)
            for sub_start, sub_end, sub_turns in sub_chunks:
                content = self._format_chunk(sub_turns)
                speakers = list(
                    {t.get("speaker") or t.get("role", "unknown") for t in sub_turns}
                )
                chunks.append(
                    {
                        "content": content,
                        "metadata": {
                            "conversation_id": conversation_id,
                            "session_index": session_idx,
                            "turn_range": [sub_start, sub_end],
                            "speakers": speakers,
                            "session_date": session_date,
                        },
                        "turn_range": (sub_start, sub_end),
                    }
                )

        return chunks

    def _validate_boundaries(
        self,
        boundaries: List[int],
        num_turns: int,
        dates: Optional[List[str]],
    ) -> None:
        if not boundaries or boundaries[0] != 0:
            raise ValueError("session_boundaries must start with 0")
        if sorted(boundaries) != boundaries:
            raise ValueError("session_boundaries must be sorted")
        if any(b >= num_turns for b in boundaries):
            raise ValueError(
                f"session_boundaries values must be < len(turns) ({num_turns})"
            )
        if dates is not None and len(dates) != len(boundaries):
            raise ValueError(
                f"session_dates length ({len(dates)}) must match session count ({len(boundaries)})"
            )

    def _split_by_boundaries(
        self, turns: List[Dict], boundaries: List[int]
    ) -> List[Tuple[int, int, List[Dict]]]:
        groups = []
        for i, start in enumerate(boundaries):
            end = boundaries[i + 1] if i + 1 < len(boundaries) else len(turns)
            groups.append((start, end, turns[start:end]))
        return groups

    def _split_by_count(
        self, turns: List[Dict]
    ) -> List[Tuple[int, int, List[Dict]]]:
        groups = []
        for i in range(0, len(turns), self._turns_per_chunk):
            end = min(i + self._turns_per_chunk, len(turns))
            groups.append((i, end, turns[i:end]))
        return groups

    def _split_by_chars(
        self, turns: List[Dict], offset: int
    ) -> List[Tuple[int, int, List[Dict]]]:
        """Further split a group if concatenated text exceeds max_chunk_chars."""
        sub_chunks: List[Tuple[int, int, List[Dict]]] = []
        current: List[Dict] = []
        current_chars = 0
        chunk_start = offset

        for i, turn in enumerate(turns):
            turn_text = self._format_turn(turn)
            if current and (current_chars + len(turn_text)) > self._max_chunk_chars:
                sub_chunks.append((chunk_start, offset + i, current))
                current = []
                current_chars = 0
                chunk_start = offset + i
            current.append(turn)
            current_chars += len(turn_text)

        if current:
            sub_chunks.append((chunk_start, offset + len(turns), current))
        return sub_chunks

    @staticmethod
    def _format_turn(turn: Dict) -> str:
        speaker = turn.get("speaker") or turn.get("role", "unknown")
        content = turn.get("content", "")
        return f"[{speaker}]: {content}\n"

    def _format_chunk(self, turns: List[Dict]) -> str:
        return "".join(self._format_turn(t) for t in turns)


async def ingest_conversation(
    memory: Any,  # SmartMemory instance
    turns: List[Dict[str, str]],
    session_boundaries: Optional[List[int]] = None,
    conversation_id: Optional[str] = None,
    session_dates: Optional[List[str]] = None,
    turns_per_chunk: int = DEFAULT_TURNS_PER_CHUNK,
    max_chunk_chars: int = DEFAULT_MAX_CHUNK_CHARS,
    max_concurrent: int = DEFAULT_MAX_CONCURRENT,
    write_context: Optional[Dict[str, Any]] = None,
    **ingest_kwargs: Any,
) -> ConversationIngestResponse:
    """Ingest a conversation as session chunks through the full pipeline.

    Args:
        memory: SmartMemory instance.
        turns: List of turn dicts with "role"/"speaker" and "content".
        session_boundaries: Turn indices where sessions start (e.g. [0, 50, 120]).
        conversation_id: User-supplied ID (auto-generated if None).
        session_dates: ISO date per session for metadata.
        turns_per_chunk: Max turns per auto-chunk (default 15).
        max_chunk_chars: Safety split for oversized chunks (default 12000).
        max_concurrent: Semaphore limit (default 4).
        write_context: Tenant metadata dict (user_id, tenant_id, workspace_id).
                       Injected by SecureSmartMemory wrapper. Merged into container
                       node metadata and chunk ingest context for tenant scoping.
        **ingest_kwargs: Passed to memory.ingest() per chunk.
    """
    from smartmemory.batch import _clear_last_fields

    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    # session_dates requires explicit boundaries (ambiguous in auto-chunk mode)
    if session_dates is not None and session_boundaries is None:
        raise ValueError("session_dates requires explicit session_boundaries")

    t_start = time.perf_counter()
    conversation_id = conversation_id or str(uuid.uuid4())

    # Chunk turns
    chunker = ConversationChunker(turns_per_chunk, max_chunk_chars)
    chunks = chunker.chunk(turns, session_boundaries, session_dates, conversation_id)

    # Count logical sessions (pre-subsplit) — not len(chunks) which overcounts
    # when char-based splitting produces multiple chunks per session
    num_sessions = (
        len(session_boundaries)
        if session_boundaries
        else len(range(0, len(turns), turns_per_chunk))
    )

    # Merge tenant context into ingest kwargs for chunk scoping
    if write_context:
        ingest_kwargs.setdefault("context", {})
        if isinstance(ingest_kwargs["context"], dict):
            ingest_kwargs["context"].update(write_context)

    # Create conversation container node (blocking graph write — run in thread)
    all_speakers = list({s for c in chunks for s in c["metadata"]["speakers"]})
    container_data: Dict[str, Any] = {
        "conversation_id": conversation_id,
        "total_turns": len(turns),
        "total_sessions": num_sessions,
        "speakers": all_speakers,
        "session_dates": session_dates or [],
    }
    # Merge tenant metadata into container for scoping
    if write_context:
        container_data.update(write_context)
    container_id = await asyncio.to_thread(
        memory.ingest_structured,
        container_data,
        "conversation",
    )

    # Prewarm pipeline runner (match batch.py pattern)
    if memory._pipeline_runner is None:
        memory._pipeline_runner = memory._create_pipeline_runner()

    # Clear ALL shared _last_* state before concurrent work (match batch.py:75)
    _clear_last_fields(memory)

    semaphore = asyncio.Semaphore(max_concurrent)

    async def _ingest_one(idx: int, chunk: Dict) -> ChunkResult:
        t0 = time.perf_counter()
        try:
            async with semaphore:
                # All three operations (ingest, update_properties, add_edge) are
                # blocking graph writes — run them together in to_thread() to avoid
                # blocking the event loop and undercutting concurrency.
                def _chunk_pipeline():
                    item_id = memory.ingest(
                        chunk["content"], sync=True, **ingest_kwargs
                    )
                    # Normalize item_id (ingest may return dict)
                    if isinstance(item_id, dict):
                        item_id = item_id.get("item_id") or item_id.get(
                            "memory_node_id"
                        )
                    # Set chunk metadata (session_index, turn_range, etc.)
                    memory.update_properties(item_id, chunk["metadata"])
                    # Create PART_OF edge: chunk → conversation container
                    memory.add_edge(
                        item_id,
                        container_id,
                        "PART_OF",
                        {
                            "origin": "conversation:ingest",
                            "confidence": 1.0,
                        },
                    )
                    return item_id

                item_id = await asyncio.to_thread(_chunk_pipeline)

            elapsed = (time.perf_counter() - t0) * 1000
            return ChunkResult(
                chunk_index=idx,
                item_id=item_id,
                turn_range=chunk["turn_range"],
                duration_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.perf_counter() - t0) * 1000
            logger.warning("conversation_ingest: chunk %d failed: %s", idx, e)
            return ChunkResult(
                chunk_index=idx,
                error=str(e),
                turn_range=chunk["turn_range"],
                duration_ms=elapsed,
            )

    # TaskGroup — safe because _ingest_one catches all exceptions
    try:
        async with asyncio.TaskGroup() as tg:
            task_handles = [
                tg.create_task(_ingest_one(i, c)) for i, c in enumerate(chunks)
            ]
        results = [t.result() for t in task_handles]
    finally:
        # Clear shared state after concurrent work (match batch.py:128 finally pattern)
        _clear_last_fields(memory)

    succeeded = sum(1 for r in results if r.ok)
    total_duration = (time.perf_counter() - t_start) * 1000

    return ConversationIngestResponse(
        conversation_id=conversation_id,
        conversation_node_id=container_id,
        chunks_ingested=succeeded,
        chunks_failed=len(results) - succeeded,
        total_turns=len(turns),
        total_chunks=len(chunks),
        chunk_results=results,
        total_duration_ms=total_duration,
    )
