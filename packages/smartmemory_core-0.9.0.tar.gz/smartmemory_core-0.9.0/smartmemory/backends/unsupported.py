"""LOCAL-PARITY-TEST-1: explicit registry of backend capability gaps.

Silent fallbacks are forbidden (see .claude/rules/no-silent-degradation.md).
Every backend capability gap must be either (a) fixed, or (b) declared here
and raised as ``UnsupportedBackendError``. The parity degradation asserter
allows ``UnsupportedBackendError`` but rejects silent no-ops and
WARNING-level 'falling back' messages.

Starting state is minimal by design — every entry is a tracked shipping gap.
"""
from __future__ import annotations

from enum import Enum


class BackendKind(str, Enum):
    """Graph backend identifiers. String values make ``BackendKind.FALKOR == "falkor"`` work."""
    FALKOR = "falkor"
    SQLITE = "sqlite"


#: Map of backend → frozenset of capability names that the backend does not
#: support. Callers that hit one of these must raise ``UnsupportedBackendError``
#: — silent no-ops are rejected by the parity test asserter.
#:
#: Each entry is a shipping gap tracked for follow-up; aim is to keep
#: ``UNSUPPORTED[BackendKind.SQLITE]`` empty.
UNSUPPORTED: dict[BackendKind, frozenset[str]] = {
    BackendKind.SQLITE: frozenset({
        # No AsyncSQLiteBackend counterpart to AsyncFalkorDBBackend yet.
        "async_operations",
        # DIST-LITE-ONTO-1: ONTO-RECONCILE-1 governance features that lite mode
        # does not implement (single-user mode — no audit trail, no evidence
        # accrual / Promoter, no pack registry). Read-side accessors return
        # empty results; write-side raises UnsupportedBackendError so callers
        # can shield at the right boundary (EvidenceStore for evidence/cohesion;
        # OntologyService._safe_governance for audit log).
        "ontology_audit_log",
        "ontology_evidence_store",
        "ontology_pack_registry",
    }),
    BackendKind.FALKOR: frozenset(),
}


class UnsupportedBackendError(RuntimeError):
    """Raised when a backend does not support the requested capability.

    Prefer this over silent no-ops, ``return []``, or "falling back" log warnings.
    The parity asserter treats this as an explicit, tracked gap rather than drift.
    """

    def __init__(self, backend: BackendKind | str, capability: str, *, reason: str | None = None):
        self.backend = backend if isinstance(backend, BackendKind) else BackendKind(backend)
        self.capability = capability
        self.reason = reason
        msg = f"Backend {self.backend.value!r} does not support capability {capability!r}"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


def is_supported(backend: BackendKind | str, capability: str) -> bool:
    """Return True if the given backend supports the capability.

    Use this to gate code paths cleanly:

        if not is_supported(BackendKind.SQLITE, "async_operations"):
            raise UnsupportedBackendError(BackendKind.SQLITE, "async_operations")
    """
    kind = backend if isinstance(backend, BackendKind) else BackendKind(backend)
    return capability not in UNSUPPORTED.get(kind, frozenset())
