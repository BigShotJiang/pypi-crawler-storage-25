"""Backend-level cross-cutting primitives (capability registry, parity helpers).

Distinct from ``smartmemory.graph.backends`` (concrete graph backends) —
this package hosts parity/capability concerns that apply across backend kinds.
"""
from smartmemory.backends.unsupported import BackendKind, UNSUPPORTED, UnsupportedBackendError, is_supported

__all__ = ["BackendKind", "UNSUPPORTED", "UnsupportedBackendError", "is_supported"]
