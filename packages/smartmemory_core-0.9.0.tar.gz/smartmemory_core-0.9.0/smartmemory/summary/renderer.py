"""Deterministic markdown renderer for MemorySnapshot (CORE-SUMMARY-1, A6).

Pure Python f-string template per design.md "Rendering" section. NO LLM
on the default path — the optional Haiku-polished rendering described in
the design is a Phase 2 follow-up (out of scope for CORE-SUMMARY-1).

Heartbeat (D6) short-circuits to H1 + a single ``*No changes since ...*``
line. This keeps cron-driven snapshots cheap on quiet workspaces while
still emitting a record so downstream consumers can detect the cadence.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from smartmemory.models.snapshot import MemorySnapshot


def render_markdown(
    snapshot: MemorySnapshot,
    prior_created_at: Optional[datetime] = None,
) -> str:
    """Render a MemorySnapshot to its canonical markdown form.

    Args:
        snapshot: The snapshot to render.
        prior_created_at: When the previous snapshot was created (used in
            the heartbeat "no changes since X" line). Falls back to
            ``snapshot.window_start`` when omitted.
    """
    h1 = (
        f"# Memory Snapshot — {snapshot.workspace_id} — "
        f"{_format_date(snapshot.created_at)}"
    )

    if snapshot.is_heartbeat:
        # D6 short-circuit: H1 + single 'no changes' line.
        anchor = prior_created_at or snapshot.window_start
        return f"{h1}\n\n*No changes since {_format_date(anchor)}.*\n"

    # Full body — every section from the design template.
    parts: list[str] = [h1, ""]

    # Header line: "Since {window_start} ({delta_days} days)"
    delta_days = _delta_days(snapshot.window_start, snapshot.created_at)
    parts.append(
        f"**Since:** {_format_date(snapshot.window_start)} ({delta_days} days)"
    )

    # Totals
    parts.append(
        f"**Totals:** {snapshot.entity_count} entities, "
        f"{snapshot.relation_count} relations"
    )

    # Change summary — Unicode minus (U+2212) per design template
    parts.append(
        f"**Change:** +{snapshot.entities_added} / "
        f"−{snapshot.entities_retracted} entities, "
        f"+{snapshot.relations_added} relations"
    )
    parts.append("")

    # Top Domains
    parts.append("## Top Domains")
    if snapshot.domain_clusters:
        for cluster in snapshot.domain_clusters:
            parts.append(
                f"- {cluster.name} ({cluster.item_count}, "
                f"{cluster.growth_pct:.1f}%)"
            )
    else:
        parts.append("- _None_")
    parts.append("")

    # New Ground Covered
    parts.append("## New Ground Covered")
    if snapshot.new_domains:
        # Look up representative entities per new domain via domain_clusters
        cluster_by_name = {c.name: c for c in snapshot.domain_clusters}
        for dom in snapshot.new_domains:
            rep = cluster_by_name.get(dom)
            reps = ", ".join(rep.representative_entities) if rep and rep.representative_entities else ""
            if reps:
                parts.append(f"- {dom}: {reps}")
            else:
                parts.append(f"- {dom}")
    else:
        parts.append("- _None_")
    parts.append("")

    # Notable Items
    parts.append("## Notable Items")
    if snapshot.notable_items:
        for ref in snapshot.notable_items[:50]:
            label = ref.title or ref.item_id
            link = f"smartmemory://item/{ref.item_id}"
            ctx = ref.content_snippet or ""
            parts.append(f"- **[{label}]({link})** — {ctx}")
    else:
        parts.append("- _None_")
    parts.append("")

    # Housekeeping
    parts.append("## Housekeeping")
    parts.append(f"- {snapshot.conflicts_resolved} conflicts resolved")
    parts.append(
        f"- {len(snapshot.procedures_confirmed)} procedures reinforced"
    )
    parts.append("")

    return "\n".join(parts)


def _format_date(dt: Optional[datetime]) -> str:
    if dt is None:
        return "—"
    return dt.strftime("%Y-%m-%d")


def _delta_days(start: Optional[datetime], end: Optional[datetime]) -> int:
    if start is None or end is None:
        return 0
    return max(0, (end - start).days)
