"""Delta computation between two MemorySnapshots (CORE-SUMMARY-1, A5).

Pure functions — no DB, no I/O. Adjacent deltas are precomputed by the
composer at snapshot creation time and stored on the newer snapshot so
``GET /summary/delta?from=N&to=N+1`` is O(1) (design "Deltas" section).
Non-adjacent deltas are computed on demand from two payload dicts.

The contract for ``SnapshotDelta`` lives in
``smart-memory-docs/docs/features/CORE-SUMMARY-1/snapshot-contract.json``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from smartmemory.models.base import MemoryBaseModel
from smartmemory.models.snapshot import MemorySnapshot


@dataclass
class SnapshotDelta(MemoryBaseModel):
    """Result of comparing two MemorySnapshots — see snapshot-contract.json."""

    from_snapshot_id: str = ""
    to_snapshot_id: str = ""
    entities_added: int = 0
    entities_retracted: int = 0
    relations_added: int = 0
    new_domains: list[str] = field(default_factory=list)
    conflicts_resolved: int = 0
    time_span_seconds: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "from_snapshot_id": self.from_snapshot_id,
            "to_snapshot_id": self.to_snapshot_id,
            "entities_added": self.entities_added,
            "entities_retracted": self.entities_retracted,
            "relations_added": self.relations_added,
            "new_domains": list(self.new_domains),
            "conflicts_resolved": self.conflicts_resolved,
            "time_span_seconds": self.time_span_seconds,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "SnapshotDelta":
        return cls(
            from_snapshot_id=d.get("from_snapshot_id", ""),
            to_snapshot_id=d.get("to_snapshot_id", ""),
            entities_added=int(d.get("entities_added", 0) or 0),
            entities_retracted=int(d.get("entities_retracted", 0) or 0),
            relations_added=int(d.get("relations_added", 0) or 0),
            new_domains=list(d.get("new_domains", []) or []),
            conflicts_resolved=int(d.get("conflicts_resolved", 0) or 0),
            time_span_seconds=float(d.get("time_span_seconds", 0.0) or 0.0),
        )


def compute_delta(prior: MemorySnapshot, current: MemorySnapshot) -> SnapshotDelta:
    """Compute the structural diff between two MemorySnapshots.

    Counts are taken from ``current`` minus ``prior`` (clamped at zero —
    negative adds are not meaningful; shrinkage is captured by the
    ``entities_retracted`` field already populated on ``current`` from the
    supersession-in-window query). ``new_domains`` is a set difference.
    """

    def _ensure_dt(v: datetime | str | None) -> datetime:
        if isinstance(v, datetime):
            return v
        if isinstance(v, str):
            try:
                return datetime.fromisoformat(v.replace("Z", "+00:00"))
            except ValueError:
                pass
        return datetime.now(timezone.utc)

    prior_created = _ensure_dt(prior.created_at)
    current_created = _ensure_dt(current.created_at)
    span = max(0.0, (current_created - prior_created).total_seconds())

    # Codex-R6 #3: compute the *absolute* domain difference, not the
    # difference between two *relative* (already-diffed) ``new_domains``
    # fields. ``new_domains`` on each snapshot is "new since *its* prior";
    # comparing two of those is meaningless. The design says non-adjacent
    # deltas compare ``domain_clusters`` (the absolute domain membership).
    prior_domains = {c.name for c in (prior.domain_clusters or []) if c.name}
    current_domains = {c.name for c in (current.domain_clusters or []) if c.name}
    new_domains = sorted(current_domains - prior_domains)

    return SnapshotDelta(
        from_snapshot_id=prior.snapshot_id,
        to_snapshot_id=current.snapshot_id,
        entities_added=max(0, current.entity_count - prior.entity_count),
        entities_retracted=int(current.entities_retracted or 0),
        relations_added=max(0, current.relation_count - prior.relation_count),
        new_domains=new_domains,
        conflicts_resolved=int(current.conflicts_resolved or 0),
        time_span_seconds=span,
    )
