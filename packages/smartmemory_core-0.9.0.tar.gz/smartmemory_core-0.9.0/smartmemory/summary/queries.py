"""Workspace-scoped Cypher helpers for snapshot composition (CORE-SUMMARY-1, A3).

Every helper here:

* Mutates a ``params`` dict in place via ``backend._build_scope_where()``
  (FalkorDB ``falkordb.py:1061``) — this is the *only* sanctioned way to
  enforce tenant isolation in raw Cypher (Correction 1).

* Adds ``AND coalesce(m.memory_type, '') <> 'snapshot'`` to every memory-node
  read (Correction 11). Without ``coalesce()``, ``m.memory_type <> 'snapshot'``
  silently drops rows where the property is NULL — see MEMORY.md
  ``feedback_falkordb_null_coalesce``.

* Distinguishes memory nodes from entity/relation nodes using the project
  convention at ``falkordb.py:1267-1276`` (``node_category`` + ``memory_type``
  flags).

Functions are FalkorDB-only by design. Lite-mode (SQLite) parity for snapshots
is a Phase F concern (LOCAL-PARITY-TEST-1 matrix), tracked separately.
"""

from __future__ import annotations

from typing import Any

from smartmemory.models.snapshot import EntityRef
from smartmemory.origin_policy import get_tier


# Common where-fragment used wherever we read MEMORY nodes. Excludes:
#   - entity/relation nodes (those have node_category in {'entity','relation'}
#     or memory_type in {'entity','relation'})
#   - snapshot rows themselves (Correction 11; coalesce required for NULL safety)
#   - alias stubs (node_category='alias') and 'Version' rows (per
#     falkordb.py:1267-1277 convention)
_MEMORY_NODE_WHERE = (
    "coalesce(m.node_category, 'memory') <> 'entity' "
    "AND coalesce(m.node_category, 'memory') <> 'relation' "
    "AND coalesce(m.node_category, 'memory') <> 'alias' "
    "AND coalesce(m.memory_type, '') <> 'entity' "
    "AND coalesce(m.memory_type, '') <> 'relation' "
    "AND coalesce(m.memory_type, '') <> 'Version' "
    "AND coalesce(m.memory_type, '') <> 'snapshot'"  # C11
)


def _scope_clause(backend, params: dict[str, Any]) -> str:
    """Wrap the FalkorDB-only ``_build_scope_where`` helper.

    Returns a string fragment beginning with `` AND ...`` (or empty string).
    Mutates ``params`` in place to add scope-binding parameters.
    """
    return backend._build_scope_where(params)


# ---------------------------------------------------------------------------
# Counts
# ---------------------------------------------------------------------------


def count_entities(backend) -> int:
    """Count distinct entity nodes mentioned by *workspace* memories.

    Entities themselves can be shared across workspaces (see comment at
    ``falkordb.py:1253``); the workspace-meaningful count is "entities a user
    in this workspace would see referenced from any of their memories".
    """
    params: dict[str, Any] = {}
    scope_where = _scope_clause(backend, params)
    cypher = f"""
    MATCH (e)-[:MENTIONED_IN|CONTAINS_ENTITY]-(m)
    WHERE (e.node_category = 'entity' OR e.memory_type = 'entity')
      AND coalesce(e.node_category, 'entity') <> 'alias'
      AND {_MEMORY_NODE_WHERE}
      {scope_where}
    RETURN count(DISTINCT e) AS n
    """
    rows = backend.query(cypher, params)
    return _scalar_int(rows)


def count_relations(backend) -> int:
    """Count distinct relation nodes referenced by workspace memories."""
    params: dict[str, Any] = {}
    scope_where = _scope_clause(backend, params)
    cypher = f"""
    MATCH (r)-[:MENTIONED_IN|CONTAINS_ENTITY]-(m)
    WHERE (r.node_category = 'relation' OR r.memory_type = 'relation')
      AND coalesce(r.node_category, 'relation') <> 'alias'
      AND {_MEMORY_NODE_WHERE}
      {scope_where}
    RETURN count(DISTINCT r) AS n
    """
    rows = backend.query(cypher, params)
    return _scalar_int(rows)


# ---------------------------------------------------------------------------
# Top-N entities
# ---------------------------------------------------------------------------


def list_top_entities(backend, limit: int = 20) -> list[EntityRef]:
    """Return the top-N entities for the current workspace, ranked by mention
    count (number of distinct workspace memories mentioning them).
    """
    params: dict[str, Any] = {"top_n": int(limit)}
    scope_where = _scope_clause(backend, params)
    cypher = f"""
    MATCH (e)-[:MENTIONED_IN|CONTAINS_ENTITY]-(m)
    WHERE (e.node_category = 'entity' OR e.memory_type = 'entity')
      AND coalesce(e.node_category, 'entity') <> 'alias'
      AND {_MEMORY_NODE_WHERE}
      {scope_where}
    WITH e, count(DISTINCT m) AS mentions
    RETURN e.item_id AS entity_id,
           coalesce(e.name, e.content, e.item_id) AS name,
           mentions AS mention_count,
           e.entity_type AS entity_type
    ORDER BY mentions DESC, name ASC
    LIMIT $top_n
    """
    rows = backend.query(cypher, params)
    out: list[EntityRef] = []
    for row in rows:
        entity_id, name, mention_count, entity_type = _row_tuple(row, 4)
        out.append(EntityRef(
            entity_id=str(entity_id or ""),
            name=str(name or ""),
            mention_count=int(mention_count or 0),
            edge_degree=0,  # cheap proxy: mention_count is already degree-on-MENTIONED_IN
            entity_type=str(entity_type) if entity_type else None,
        ))
    return out


# ---------------------------------------------------------------------------
# Origin-tier mix
# ---------------------------------------------------------------------------


def origin_tier_mix(backend) -> dict[str, int]:
    """Return ``{"tier_1": N, "tier_2": M, ...}`` over workspace memory items.

    Snapshots themselves are excluded by ``_MEMORY_NODE_WHERE`` (C11) so the
    tier mix never includes infrastructure rows. Origin-to-tier mapping uses
    ``smartmemory.origin_policy.get_tier``.
    """
    params: dict[str, Any] = {}
    scope_where = _scope_clause(backend, params)
    cypher = f"""
    MATCH (m)
    WHERE {_MEMORY_NODE_WHERE}
      {scope_where}
    RETURN coalesce(m.origin, 'unknown') AS origin, count(*) AS n
    """
    rows = backend.query(cypher, params)
    mix: dict[str, int] = {}
    for row in rows:
        origin, n = _row_tuple(row, 2)
        tier = get_tier(str(origin or "unknown"))
        key = f"tier_{tier}"
        mix[key] = mix.get(key, 0) + int(n or 0)
    return mix


# ---------------------------------------------------------------------------
# Supersession-in-window — by edge.detected_at
# ---------------------------------------------------------------------------


def get_supersession_in_window(
    backend, window_start: str, window_end: str
) -> int:
    """Count ``SUPERSEDED_BY`` edges with ``detected_at`` in [start, end].

    ``detected_at`` is stored as an ISO-8601 string (see
    ``pipeline/stages/supersede.py:213``); ISO-8601 strings sort
    lexicographically so a string range comparison is correct without parsing.

    Both endpoints of the edge must be non-snapshot memories (defensive — B1
    guard already prevents snapshot supersession edges, but counting is cheap
    and the filter forecloses a regression).
    """
    params: dict[str, Any] = {
        "window_start": window_start,
        "window_end": window_end,
    }
    scope_where = _scope_clause(backend, params)
    # Scope clause references variable `m`; we want it on the *old* (source)
    # memory to ensure we count supersessions inside this workspace only.
    scope_where_on_old = scope_where.replace("m.", "old.")

    cypher = f"""
    MATCH (old)-[r:SUPERSEDED_BY]->(new)
    WHERE r.detected_at >= $window_start
      AND r.detected_at <= $window_end
      AND coalesce(old.memory_type, '') <> 'snapshot'
      AND coalesce(new.memory_type, '') <> 'snapshot'
      {scope_where_on_old}
    RETURN count(*) AS n
    """
    rows = backend.query(cypher, params)
    return _scalar_int(rows)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _row_tuple(row: Any, n: int) -> tuple:
    """Coerce a FalkorDB result row to an n-tuple regardless of whether it
    came back as a list (FalkorDB) or a sequence wrapper.
    """
    if isinstance(row, (list, tuple)):
        out = list(row)
    else:
        out = [row]
    while len(out) < n:
        out.append(None)
    return tuple(out[:n])


def _scalar_int(rows: list[Any]) -> int:
    """Pull a single integer scalar from a FalkorDB result set."""
    if not rows:
        return 0
    first = rows[0]
    val, = _row_tuple(first, 1)
    return int(val or 0)
