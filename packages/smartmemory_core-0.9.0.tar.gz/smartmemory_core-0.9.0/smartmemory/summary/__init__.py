"""Snapshot composition primitives (CORE-SUMMARY-1).

This package contains the pure (non-persistent) building blocks for memory
snapshots:

- ``queries`` — workspace-scoped Cypher helpers (entities, relations, tier mix,
  supersession-in-window). All exclude ``memory_type='snapshot'`` so prior
  snapshots never inflate their successors (Blueprint Correction 11).
- ``composer`` — pure orchestrator that returns a ``MemorySnapshot``. Does NOT
  persist — that is the service-layer ``SnapshotPersister`` (R3-1 split).
- ``delta`` — pure functions over two ``MemorySnapshot`` objects.
- ``renderer`` — deterministic markdown template, with heartbeat short-circuit.

Service-layer concerns (Mongo writes, Redis lock, scheduler) live in
``smart-memory-service/memory_service/summary/`` per the core ↔ service
layering documented in CLAUDE.md.
"""
