"""SnapshotComposer — pure orchestration over A3 queries (CORE-SUMMARY-1, A4).

R3-1 split: composer is in core, returns a ``MemorySnapshot`` dataclass
instance only — NO persistence side effects. Service-layer
``SnapshotPersister`` (smart-memory-service) owns all writes.

Responsibilities:
  1. Pre-generate ``snapshot_id`` (C18) so the persister can write graph +
     Mongo with the same key without a placeholder swap.
  2. Pull workspace identity from the backend's scope provider.
  3. Run the A3 queries (count_entities, count_relations, list_top_entities,
     origin_tier_mix, get_supersession_in_window).
  4. Compute delta vs ``prior_snapshot`` via ``smartmemory.summary.delta``.
  5. Determine the heartbeat flag (D6) — scheduled trigger on an unchanged
     workspace.
  6. Cap notable items at 50.
  7. Render markdown via ``smartmemory.summary.renderer``.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from smartmemory.models.snapshot import (
    DomainCluster,
    EntityRef,
    MemoryItemRef,
    MemorySnapshot,
)
from smartmemory.summary import queries as Q
from smartmemory.summary.delta import compute_delta
from smartmemory.summary.renderer import render_markdown


def _group_into_clusters(
    entities: list[EntityRef],
    *,
    prior_clusters: Optional[list] = None,
) -> list[DomainCluster]:
    """Group entities by ``entity_type`` into domain clusters.

    Phase-1 minimum: ``entity_type`` is the available domain signal. Each
    cluster's ``item_count`` is the number of entities in the type bucket;
    ``representative_entities`` are the names of the top-3 by mention count.

    Codex-R6 #4: ``growth_pct`` is now computed against the prior
    snapshot's clusters (when available) as a percentage change in
    ``item_count``. New clusters get +100% (everything in them is new).
    """
    prior_by_name: dict[str, int] = {}
    for c in (prior_clusters or []):
        name = getattr(c, "name", "") or ""
        if name:
            prior_by_name[name] = int(getattr(c, "item_count", 0) or 0)

    buckets: dict[str, list[EntityRef]] = {}
    for ent in entities:
        key = ent.entity_type or "uncategorized"
        buckets.setdefault(key, []).append(ent)
    clusters: list[DomainCluster] = []
    for name, ents in buckets.items():
        ents_sorted = sorted(ents, key=lambda e: e.mention_count, reverse=True)
        item_count = len(ents)
        prior_count = prior_by_name.get(name, 0)
        if prior_count <= 0:
            growth_pct = 100.0 if item_count > 0 else 0.0
        else:
            growth_pct = round(((item_count - prior_count) / prior_count) * 100.0, 2)
        clusters.append(DomainCluster(
            name=name,
            item_count=item_count,
            growth_pct=growth_pct,
            representative_entities=[e.name for e in ents_sorted[:3] if e.name],
        ))
    return sorted(clusters, key=lambda c: c.item_count, reverse=True)


def _diff_new_domain_names(
    *,
    current: list[DomainCluster],
    prior: list,
) -> list[str]:
    """Names in ``current`` not present in ``prior``."""
    prior_names = {getattr(c, "name", "") for c in (prior or [])}
    return [c.name for c in current if c.name and c.name not in prior_names]


class SnapshotComposer:
    """Pure compose-only producer of MemorySnapshot instances."""

    def __init__(self, backend) -> None:
        """Args:
            backend: A graph backend exposing ``query()``,
                ``_build_scope_where()`` and ``scope_provider``.
                Currently FalkorDB-only — SQLite parity is a Phase F concern.
        """
        self._backend = backend

    # ------------------------------------------------------------------ public

    def compose(
        self,
        trigger: str,
        window_start: datetime,
        prior_snapshot: Optional[MemorySnapshot] = None,
    ) -> MemorySnapshot:
        """Compose a snapshot. Returns; does not persist."""
        if trigger not in ("scheduled", "manual", "threshold"):
            raise ValueError(
                f"Unknown trigger {trigger!r}; expected one of "
                "scheduled|manual|threshold (see snapshot-contract.json)."
            )

        snapshot_id = MemorySnapshot.generate_id()
        workspace_id = self._workspace_id()
        created_at = datetime.now(timezone.utc)
        window_end_iso = created_at.isoformat()
        window_start_iso = window_start.isoformat() if isinstance(window_start, datetime) else str(window_start)

        # 3. Rollup
        entity_count = Q.count_entities(self._backend)
        relation_count = Q.count_relations(self._backend)
        top_entities = Q.list_top_entities(self._backend, limit=20)
        origin_tier_mix = Q.origin_tier_mix(self._backend)

        # Supersessions in [window_start, created_at]
        entities_retracted = Q.get_supersession_in_window(
            self._backend, window_start_iso, window_end_iso
        )

        # 4. Delta vs prior (only used for change-counts; the queries above
        # already give us the absolute totals we need for the rollup).
        if prior_snapshot is not None:
            entities_added = max(0, entity_count - int(prior_snapshot.entity_count or 0))
            relations_added = max(0, relation_count - int(prior_snapshot.relation_count or 0))
            prior_id: Optional[str] = prior_snapshot.snapshot_id or None
        else:
            entities_added = entity_count
            relations_added = relation_count
            prior_id = None

        # 5. Heartbeat (D6) — scheduled-trigger only, against a prior snapshot,
        # with NO observable change in the window. Memory-count comparison
        # catches the case where users add raw memory items without entity
        # extraction (entity_count alone would miss it).
        memories_now = sum(int(v or 0) for v in origin_tier_mix.values())
        memories_prior = sum(
            int(v or 0) for v in (prior_snapshot.origin_tier_mix or {}).values()
        ) if prior_snapshot is not None else 0

        is_heartbeat = (
            trigger == "scheduled"
            and prior_snapshot is not None
            and entities_added == 0
            and relations_added == 0
            and entities_retracted == 0
            and memories_now == memories_prior
        )

        # 5b. Notable items — empty for heartbeats (Codex-R5 #3): per the
        # design, heartbeat snapshots render only H1 + "no changes" line and
        # MUST NOT carry a notable-items payload that the renderer hides.
        if is_heartbeat:
            notable_items: list[MemoryItemRef] = []
        else:
            notable_items = self._list_notable_items(limit=50)

        # 5c. Domain clusters + new_domains (Codex-R5 #7, Codex-R6 #4)
        # — derive from top_entities by grouping by entity_type, with
        # per-cluster growth_pct computed against the prior snapshot.
        domain_clusters = _group_into_clusters(
            top_entities,
            prior_clusters=prior_snapshot.domain_clusters if prior_snapshot else None,
        )
        new_domains = _diff_new_domain_names(
            current=domain_clusters,
            prior=prior_snapshot.domain_clusters if prior_snapshot else [],
        )

        snapshot = MemorySnapshot(
            snapshot_id=snapshot_id,
            workspace_id=workspace_id,
            created_at=created_at,
            window_start=window_start,
            trigger=trigger,
            schedule=None,
            entity_count=entity_count,
            relation_count=relation_count,
            domain_clusters=domain_clusters,
            top_entities=top_entities,
            origin_tier_mix=origin_tier_mix,
            entities_added=entities_added,
            entities_retracted=entities_retracted,
            relations_added=relations_added,
            procedures_confirmed=[],  # C5: phase-1 deferral
            conflicts_resolved=entities_retracted,  # supersession events resolve conflicts
            new_domains=new_domains,
            is_heartbeat=is_heartbeat,
            notable_items=notable_items,
            prior_snapshot_id=prior_id,
            markdown="",
            structured={},
        )

        # 6. (Capping already done by _list_notable_items via LIMIT 50)
        # 7. Render markdown last so it can include any computed fields above.
        prior_created_at = (
            prior_snapshot.created_at
            if prior_snapshot is not None and isinstance(prior_snapshot.created_at, datetime)
            else None
        )
        snapshot.markdown = render_markdown(snapshot, prior_created_at=prior_created_at)
        snapshot.structured = snapshot.to_dict()

        # Sanity: side-effect-free contract. Compute a delta for storage on
        # this snapshot if a prior exists; this is pure data, no I/O.
        if prior_snapshot is not None:
            snapshot.structured["adjacent_delta"] = compute_delta(
                prior_snapshot, snapshot
            ).to_dict()

        return snapshot

    # ----------------------------------------------------------------- helpers

    def _workspace_id(self) -> str:
        provider = getattr(self._backend, "scope_provider", None)
        if provider is None:
            return ""
        try:
            ctx = provider.get_write_context() or {}
        except Exception:  # noqa: BLE001
            return ""
        return str(ctx.get("workspace_id", "") or "")

    def _list_notable_items(self, *, limit: int = 50) -> list[MemoryItemRef]:
        """Phase-1 ranking: most-recent workspace memory items, capped at *limit*.

        Excludes snapshots (C11) and entity/relation nodes via the
        ``_MEMORY_NODE_WHERE`` constant. Refined ranking (mention-count
        weighted, tier graduation, newly superseded) is a Phase 2 follow-up.
        """
        params: dict[str, Any] = {"top_n": int(limit)}
        scope_where = self._backend._build_scope_where(params)
        cypher = f"""
        MATCH (m)
        WHERE {Q._MEMORY_NODE_WHERE}
          {scope_where}
        RETURN m.item_id AS item_id,
               coalesce(m.memory_type, '') AS memory_type,
               coalesce(m.content, '') AS content,
               coalesce(m.created_at, '') AS created_at
        ORDER BY created_at DESC, item_id ASC
        LIMIT $top_n
        """
        rows = self._backend.query(cypher, params)
        out: list[MemoryItemRef] = []
        for row in rows:
            item_id, memory_type, content, _created = Q._row_tuple(row, 4)
            snippet = (str(content or ""))[:120]
            out.append(MemoryItemRef(
                item_id=str(item_id or ""),
                memory_type=str(memory_type or ""),
                content_snippet=snippet,
                title=None,
            ))
        return out
