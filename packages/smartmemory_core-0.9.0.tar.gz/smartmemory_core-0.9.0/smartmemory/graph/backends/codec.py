"""Graph-backend value codec for CORE-CRUD-LIST-DESERIALIZE-1.

Symmetric serialize/deserialize at the FalkorDB backend boundary. Chosen
design is per-value hybrid:

- ``list`` of primitives (str/int/float/bool) → pass-through as native
  Python list. FalkorDB stores it as a native Cypher array (verified by
  ``tests/integration/test_falkordb_native_arrays.py``), so
  ``WHERE $v IN n.key`` matches without any decode.
- ``list`` with non-primitive elements, ``dict``, tuple, other non-scalar
  → marker-prefixed JSON string: ``"__sm_json_v1__:" + json.dumps(...)``.
- ``datetime`` / ``date`` / ``time`` (anything with ``.isoformat()``) →
  ISO string.
- Other scalars → pass-through.

Read path mirrors:

- Marker-prefixed string → strip prefix, ``json.loads``.
- Bare string that parses as JSON and yields ``list`` or ``dict`` → decode
  as a legacy-row fallback (for rows written by the pre-codec
  implementation). Emits a warn-once per key.
- Everything else → pass-through.

See ``smart-memory-docs/docs/features/CORE-CRUD-LIST-DESERIALIZE-1/`` for
the full design.
"""
from __future__ import annotations

import json
import logging
import threading
from typing import Any

logger = logging.getLogger(__name__)

JSON_MARKER = "__sm_json_v1__:"

_PRIMITIVE_TYPES = (str, int, float, bool)

_legacy_decode_warned: set[str] = set()
_complex_list_warned: set[str] = set()
_warn_lock = threading.Lock()


def _is_primitive(value: Any) -> bool:
    if isinstance(value, bool):
        return True
    return isinstance(value, _PRIMITIVE_TYPES)


def _is_primitive_list(value: Any) -> bool:
    if not isinstance(value, list):
        return False
    return all(_is_primitive(v) for v in value)


def _warn_once(bucket: set[str], key: str, message: str) -> None:
    with _warn_lock:
        if key in bucket:
            return
        bucket.add(key)
    logger.warning(message)


def serialize_value(value: Any, *, key: str = "<unknown>") -> Any:
    """Return the FalkorDB-storable form of ``value``.

    ``key`` is used only for warn-once logging; it does not affect output.

    Tuples are coerced to lists by design — FalkorDB (and JSON) have no
    tuple type, so the round-trip is intentionally ``tuple → list``.
    Callers that need tuple identity must not use graph-property storage.
    """
    if value is None:
        return None
    if isinstance(value, bool) or isinstance(value, (int, float, str)):
        return value
    if hasattr(value, "isoformat"):
        return value.isoformat()
    if isinstance(value, tuple):
        value = list(value)
    if isinstance(value, list):
        if _is_primitive_list(value):
            return value
        _warn_once(
            _complex_list_warned,
            f"complex_list:{key}",
            f"Storing list-of-complex under key `{key}` as opaque blob; "
            "this value will not match Cypher `IN` queries.",
        )
        return JSON_MARKER + json.dumps(value, default=str)
    if isinstance(value, dict):
        return JSON_MARKER + json.dumps(value, default=str)
    # Unknown non-scalar — best-effort JSON with marker.
    return JSON_MARKER + json.dumps(value, default=str)


def deserialize_value(value: Any, *, key: str = "<unknown>") -> Any:
    """Return the hydrated form of a stored value.

    Handles three cases:

    - marker-prefixed string → decode
    - bare JSON list/dict string (legacy pre-codec rows) → decode with
      warn-once
    - anything else → pass-through
    """
    if not isinstance(value, str):
        return value
    if value.startswith(JSON_MARKER):
        payload = value[len(JSON_MARKER):]
        try:
            return json.loads(payload)
        except json.JSONDecodeError:
            # Corrupted marker — return the raw string rather than raise;
            # the caller can decide what to do.
            logger.warning(
                "Marker-prefixed value under key `%s` failed to decode; "
                "returning raw string.",
                key,
            )
            return value
    # Legacy bare-JSON fallback: only decode if the string clearly looks
    # like a JSON list or dict. Avoid decoding bare numbers / booleans
    # since those shouldn't have been stringified on the old write path.
    if len(value) >= 2 and value[0] in "[{" and value[-1] in "]}":
        try:
            decoded = json.loads(value)
        except json.JSONDecodeError:
            return value
        if isinstance(decoded, (list, dict)):
            _warn_once(
                _legacy_decode_warned,
                f"legacy:{key}",
                f"Decoding legacy bare-JSON value under key `{key}`; "
                "rewrite the row via the codec to clear this warning.",
            )
            return decoded
    return value


def hydrate_props(props: dict[str, Any]) -> dict[str, Any]:
    """Apply ``deserialize_value`` to every entry in a props dict."""
    return {k: deserialize_value(v, key=k) for k, v in props.items()}


def hydrate_and_unflatten(props: dict[str, Any]) -> dict[str, Any]:
    """Hydrate values then unflatten dunder-keyed structure.

    CORE-GRAPH-UNFLATTEN-1: backends store nested dicts via ``flatten_dict``
    (`metadata.tags` → `metadata__tags`) before insert. Read paths used to
    return the flat shape inconsistently — this helper normalizes every
    backend read to a hydrated, nested dict so downstream consumers see
    the same shape regardless of which read path produced it.

    System invariant (pre-existing): the double-underscore (``__``) is the
    reserved path separator for ``flatten_dict``/``unflatten_dict``. Any
    property key containing ``__`` is interpreted as a nested path. Do
    NOT use ``__`` in property names that should remain flat — pick a
    different convention or escape on write. This is the same invariant
    that has applied to ``MemoryItem.from_vector_store`` since it was
    written; CORE-GRAPH-UNFLATTEN-1 just extends consistent enforcement
    across all backend read paths.
    """
    # Local import keeps the codec module free of upstream cycles.
    from smartmemory.utils import unflatten_dict

    return unflatten_dict(hydrate_props(props))


__all__ = [
    "JSON_MARKER",
    "serialize_value",
    "deserialize_value",
    "hydrate_props",
    "hydrate_and_unflatten",
]
