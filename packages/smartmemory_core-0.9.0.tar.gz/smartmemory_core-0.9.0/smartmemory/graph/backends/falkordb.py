from __future__ import annotations

import contextvars
import logging
import re
from typing import Any, Dict, List, Optional, Tuple

from smartmemory.graph.backends.backend import SmartGraphBackend
from smartmemory.graph.backends import codec
from smartmemory.utils import unflatten_dict, flatten_dict, get_config
from smartmemory.utils.deduplication import get_canonical_key, normalize_entity_type
from smartmemory.interfaces import ScopeProvider
from smartmemory.scope_provider import DefaultScopeProvider

# Thread-safe session_id for accumulation during add_dual_node().
# Set by StoreStage before CRUD.add(), read by add_dual_node() for property accumulation.
# ContextVar is safe under concurrent ingest_batch() (asyncio.to_thread uses copy_context).
_current_session_id_var: contextvars.ContextVar[str] = contextvars.ContextVar(
    "_current_session_id", default=""
)

logger = logging.getLogger(__name__)

# Cypher property-name allowlist. Used by APIs that interpolate property
# keys into Cypher source (FalkorDB does not parameterize identifiers).
# CORE-CRUD-LIST-MEMBER-1 + CORE-CYPHER-INJECTION-AUDIT-1.
_CYPHER_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _validate_property_key(key: str, *, where: str) -> None:
    """Raise ValueError if `key` is not a safe Cypher identifier.

    FalkorDB does not parameterize property names; any caller-controlled
    key reaches Cypher source as raw text. Validation is the only
    defense against syntax errors and the (narrow) injection surface.
    """
    if not isinstance(key, str) or not _CYPHER_IDENT_RE.match(key):
        raise ValueError(
            f"{where}: invalid property key {key!r} — "
            "must match ^[A-Za-z_][A-Za-z0-9_]*$"
        )


def sanitize_label(label: str) -> str:
    """
    Sanitize a string for use as a Neo4j/FalkorDB node label.

    Labels must:
    - Start with a letter
    - Contain only letters, numbers, and underscores
    - Not contain hyphens, spaces, or special characters
    """
    if not label:
        return "Entity"
    # Replace hyphens and spaces with underscores
    sanitized = re.sub(r"[-\s]+", "_", label)
    # Remove any other non-alphanumeric characters (except underscores)
    sanitized = re.sub(r"[^a-zA-Z0-9_]", "", sanitized)
    # Ensure it starts with a letter
    if sanitized and not sanitized[0].isalpha():
        sanitized = "E_" + sanitized
    # Default if empty
    return sanitized if sanitized else "Entity"


class FalkorDBBackend(SmartGraphBackend):
    """Minimal RedisGraph/FalkorDB backend implementing the SmartGraphBackend interface.

    This adapter lets Agentic Memory switch from Neo4j to FalkorDB by flipping
    `graph_db.backend_class` in `config.json` to ``FalkorDBBackend``.

    Notes
    -----
    * FalkorDB re-uses openCypher; parameter placeholders (e.g. `$name`) are supported.
    * The backend keeps the entire graph inside the Redis module. Ensure sufficient
      RAM or shard via Redis Cluster.
    * Only core CRUD and simple search are implemented for now. Add advanced
      analytics or vector search later if needed.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        graph_name: Optional[str] = None,
        config_path: str = "config.json",
        scope_provider: Optional[ScopeProvider] = None,
    ):
        from smartmemory.configuration.graph_name import resolve_main_graph_name

        config = get_config("graph_db")

        # Use direct config access with explicit parameter override
        self.host = host or config.host
        self.port = port or config.port
        # CORE-GRAPHCONFIG-1: resolve via helper — reads `main_graph_name`
        # (new), falls back to legacy `graph_name` with one-time warning,
        # raises if neither is set. No hardcoded default per
        # .claude/rules/no-silent-degradation.md.
        self.graph_name = resolve_main_graph_name(config, explicit=graph_name)

        self.scope_provider = scope_provider or DefaultScopeProvider()

        try:
            from falkordb import FalkorDB as _FalkorDB
        except ImportError:
            raise ImportError(
                "falkordb is required for server mode. Install it with: pip install smartmemory-core[server]"
            ) from None
        self.db = _FalkorDB(host=self.host, port=self.port)
        self.graph = self.db.select_graph(self.graph_name)

        from smartmemory.graph.cypher_algos import CypherAlgos

        self._algos = CypherAlgos(self)

        # CORE-ENTITY-RESOLVE-1: fuzzy entity resolver (wired in by SmartMemory.__init__)
        self._entity_resolver = None
        self._entity_resolve_config = None

        # CORE-EVENT-EXTRACT-1: multi-value property accumulation config
        self._accumulation_config = None

    @property
    def algos(self):
        return self._algos

    # ---------- Capability Checks ----------
    def has_capability(self, name: str) -> bool:
        if name in {"vector"}:  # FalkorDB lacks native vector ops
            return False
        return True

    # ---------- CORE-ENTITY-RESOLVE-1: EntityResolver wiring ----------

    def set_entity_resolver(self, resolver, config=None) -> None:
        """Wire an EntityResolver into this backend for fuzzy search fallback."""
        self._entity_resolver = resolver
        self._entity_resolve_config = config

    def set_accumulation_config(self, config) -> None:
        """Wire an AccumulationConfig into this backend (CORE-EVENT-EXTRACT-1)."""
        self._accumulation_config = config

    def _get_workspace_id(self) -> str:
        """Extract workspace_id from scope_provider isolation filters.

        Always returns a non-empty string (normalized to "default" when unset)
        so cache keys match between invalidation and resolution paths.
        """
        try:
            filters = self.scope_provider.get_isolation_filters()
            return filters.get("workspace_id") or "default"
        except Exception:
            return "default"

    # ---------- Utility ----------

    # ── CORE-EVO-LIVE-1: transaction support ────────────────────────────────

    def transaction_context(self):
        """No-op context manager — FalkorDB auto-commits each query."""
        from contextlib import contextmanager

        @contextmanager
        def _noop():
            yield

        return _noop()

    # ── Cypher query interface ────────────────────────────────────────────

    def execute_cypher(self, cypher: str, params: Optional[Dict[str, Any]] = None) -> List[Any]:
        """Execute a raw Cypher query."""
        return self._query(cypher, params)

    def query(self, cypher: str, params: Optional[Dict[str, Any]] = None, **kwargs) -> List[Any]:
        """Public Cypher query interface.

        Accepts optional ``graph_name`` kwarg for API compatibility with
        callers like ``OntologyGraph`` that were initialised with a dedicated
        graph — the kwarg is accepted but ignored because this backend is
        already bound to its graph at construction time.
        """
        return self._query(cypher, params)

    def _query(self, cypher: str, params: Optional[Dict[str, Any]] = None):
        """Run a Cypher query and return raw records list."""
        res = self.graph.query(cypher, params or {})
        return res.result_set if hasattr(res, "result_set") else []

    # ---------- Bulk helpers ----------

    @staticmethod
    def _chunked(items: list, size: int):
        """Yield successive chunks of *size* from *items*."""
        for i in range(0, len(items), size):
            yield items[i : i + size]

    def add_nodes_bulk(self, nodes: List[Dict[str, Any]], batch_size: int = 500, is_global: bool = False) -> int:
        """Bulk upsert nodes using UNWIND Cypher, grouped by label.

        When ``is_global=False`` (default), all nodes receive write context
        (workspace_id, user_id) from the scope provider for tenant isolation.

        When ``is_global=True``, write context is skipped — nodes are visible
        across all workspaces.  Use for shared reference data (ontology types,
        Wikipedia entities).

        Returns the total number of nodes created or updated.
        """
        if not nodes:
            return 0

        write_ctx = {} if is_global else self.scope_provider.get_write_context()

        # Group nodes by sanitized label
        by_label: Dict[str, List[Dict[str, Any]]] = {}
        for n in nodes:
            item_id = n.get("item_id")
            if not item_id:
                continue
            # Capitalize to match add_node() behavior (FalkorDB labels are case-sensitive)
            raw_type = n.get("memory_type", "Node")
            label = sanitize_label(raw_type.capitalize() if raw_type else "Node")
            flat = flatten_dict(n)
            # Filter and serialize properties like add_node() does
            props: Dict[str, Any] = {}
            for key, value in flat.items():
                if self._is_valid_property(key, value):
                    props[key] = self._serialize_value(value)
            props.update(write_ctx)
            by_label.setdefault(label, []).append({"item_id": item_id, "props": props})

        total = 0
        has_canonical_entities = False
        for label, batch_items in by_label.items():
            query = (
                f"UNWIND $batch AS item "
                f"MERGE (n:{label} {{item_id: item.item_id}}) "
                f"SET n += item.props "
                f"RETURN count(n) AS cnt"
            )
            for chunk in self._chunked(batch_items, batch_size):
                res = self.graph.query(query, {"batch": chunk})
                if hasattr(res, "result_set") and res.result_set:
                    total += res.result_set[0][0]
            # Check if any entity/relation nodes were created (excluding alias stubs)
            if label.lower() in ("entity", "relation"):
                canonical = [
                    item for item in batch_items
                    if item.get("props", {}).get("node_category") != "alias"
                ]
                if canonical:
                    has_canonical_entities = True

        # CORE-ENTITY-RESOLVE-1: Invalidate embedding index after bulk entity creation
        if has_canonical_entities and self._entity_resolver is not None:
            workspace_id = self._get_workspace_id()
            self._entity_resolver.invalidate(workspace_id)

        return total

    def add_edges_bulk(
        self,
        edges: List[Tuple[str, str, str, Dict[str, Any]]],
        batch_size: int = 500,
        is_global: bool = False,
    ) -> int:
        """Bulk upsert edges using UNWIND Cypher, grouped by edge type.

        When ``is_global=False`` (default), all edges receive write context
        and MATCH clauses are scoped to the workspace for tenant isolation.

        When ``is_global=True``, workspace scoping is skipped for both edge
        properties and MATCH clauses — use when connecting global nodes that
        have no ``workspace_id``.

        Returns the total number of edges created or updated.
        """
        if not edges:
            return 0

        write_ctx = {} if is_global else self.scope_provider.get_write_context()

        # Group edges by sanitized type
        by_type: Dict[str, List[Dict[str, Any]]] = {}
        for src, tgt, etype, raw_props in edges:
            sanitized = re.sub(r"[^A-Z0-9_]", "_", etype.upper().replace("-", "_"))
            if not sanitized:
                sanitized = "RELATED"
            flat = flatten_dict(raw_props)
            # Filter and serialize properties like add_edge() does
            props: Dict[str, Any] = {}
            for key, value in flat.items():
                if self._is_valid_property(key, value):
                    props[key] = self._serialize_value(value)
            props.update(write_ctx)
            by_type.setdefault(sanitized, []).append({"src": src, "tgt": tgt, "props": props})

        # Scope MATCH to workspace when in multi-tenant mode
        ws_id = write_ctx.get("workspace_id")
        if ws_id:
            match_tpl = (
                "UNWIND $batch AS edge "
                "MATCH (a {{item_id: edge.src, workspace_id: edge.props.workspace_id}}), "
                "(b {{item_id: edge.tgt, workspace_id: edge.props.workspace_id}}) "
                "MERGE (a)-[r:{etype}]->(b) "
                "SET r += edge.props "
                "RETURN count(r) AS cnt"
            )
        else:
            match_tpl = (
                "UNWIND $batch AS edge "
                "MATCH (a {{item_id: edge.src}}), (b {{item_id: edge.tgt}}) "
                "MERGE (a)-[r:{etype}]->(b) "
                "SET r += edge.props "
                "RETURN count(r) AS cnt"
            )

        total = 0
        for etype, batch_items in by_type.items():
            query = match_tpl.format(etype=etype)
            for chunk in self._chunked(batch_items, batch_size):
                res = self.graph.query(query, {"batch": chunk})
                created = 0
                if hasattr(res, "result_set") and res.result_set:
                    created = res.result_set[0][0]
                if created < len(chunk):
                    logger.warning(
                        "add_edges_bulk: %d/%d %s edges matched — %d dropped (source/target nodes not found)",
                        created,
                        len(chunk),
                        etype,
                        len(chunk) - created,
                    )
                total += created
        return total

    # ---------- CRUD ----------

    def clear(self):
        try:
            self.graph.delete()
        except Exception as e:
            # Ignore error if graph doesn't exist yet
            if "Invalid graph operation on empty key" not in str(e):
                raise

    def add_node(
        self,
        item_id: Optional[str],
        properties: Dict[str, Any],
        valid_time: Optional[Tuple] = None,
        created_at: Optional[Tuple] = None,
        memory_type: Optional[str] = None,
        is_global: bool = False,
    ):
        label = sanitize_label(memory_type.capitalize()) if memory_type else "Node"
        props = flatten_dict(properties)

        # Detect write mode marker (used by CRUD.update_memory_node for replace semantics)
        write_mode = props.pop("_write_mode", None)

        # Apply Scope Provider Logic
        # Only apply context if not explicitly global
        if not is_global:
            write_ctx = self.scope_provider.get_write_context()
            props.update(write_ctx)

        # Persist is_global flag — stripped by get_node()/get_properties() on read
        props["is_global"] = is_global

        # Build individual SET clauses for each property to avoid parameter expansion issues
        set_clauses = []
        params = {"item_id": item_id}

        for key, value in props.items():
            if not self._is_valid_property(key, value):
                continue
            # CORE-CYPHER-INJECTION-AUDIT-1: keys are caller-controlled
            # (REST `update_properties`, MCP, etc) and FalkorDB does not
            # parameterize property names. Validate before interpolation.
            _validate_property_key(key, where="add_node")

            param_key = f"prop_{key}"
            set_clauses.append(f"n.{key} = ${param_key}")
            params[param_key] = self._serialize_value(value)

        # If replace semantics requested, remove existing properties first (except item_id)
        if write_mode == "replace":
            try:
                # Get existing keys
                existing_res = self._query("MATCH (n {item_id: $item_id}) RETURN n LIMIT 1", {"item_id": item_id})
                if existing_res and existing_res[0]:
                    node_obj = existing_res[0][0]
                    if hasattr(node_obj, "properties"):
                        existing_keys = list(node_obj.properties.keys())
                    else:
                        existing_keys = [k for k in vars(node_obj).keys() if not k.startswith("_")]
                    # Exclude item_id; defensively skip any non-identifier-shaped
                    # stored key so a corrupt-shape entry can't break REMOVE syntax.
                    keys_to_remove = [
                        k for k in existing_keys
                        if k != "item_id" and _CYPHER_IDENT_RE.match(k)
                    ]
                    if keys_to_remove:
                        remove_clause = ", ".join([f"n.{k}" for k in keys_to_remove])
                        remove_query = f"MATCH (n:{label} {{item_id: $item_id}}) REMOVE {remove_clause}"
                        self._query(remove_query, {"item_id": item_id})
            except Exception:
                # Best-effort removal; continue to set new properties
                pass

        # Always set item_id as a property (not just in MERGE/MATCH pattern)
        set_clauses.insert(0, "n.item_id = $item_id")

        # Build final SET clause
        set_clause = "SET " + ", ".join(set_clauses) if set_clauses else "SET n.item_id = $item_id"

        # IMPORTANT: When a node with this item_id already exists, we must update it
        # regardless of its label instead of creating a second node with a different label.
        # Otherwise, calls like SmartGraph.add_node / SmartMemory._graph.add_node used for
        # enrichment will create a parallel node that backend.get_node() may not return,
        # causing properties (e.g. sentiment) to appear "missing".
        #
        # On node_exists() failure: use label-agnostic MATCH (not labeled MERGE).
        # A labeled MERGE would create a duplicate node with the same item_id under
        # a different label, violating the backend's global item_id uniqueness model.
        # Label-agnostic MATCH is safe: it either updates the existing node or is a
        # no-op if the node doesn't exist, which we follow up with a labeled MERGE.
        if self.node_exists(item_id):
            # Update existing node by item_id (label-agnostic)
            query = f"MATCH (n {{item_id: $item_id}}) {set_clause} RETURN n"
        else:
            # Create a new labeled node if it does not exist yet
            query = f"MERGE (n:{label} {{item_id: $item_id}}) {set_clause} RETURN n"

        self._query(query, params)

        # CORE-ENTITY-RESOLVE-1: Invalidate embedding index on canonical entity creation.
        # Alias stubs (node_category='alias') are excluded from the index and must NOT
        # trigger invalidation — they would cause unnecessary rebuilds.
        if (
            self._entity_resolver is not None
            and memory_type in ("entity", "relation")
            and props.get("node_category") != "alias"
        ):
            workspace_id = self._get_workspace_id()
            self._entity_resolver.invalidate(workspace_id)

        return {"item_id": item_id, "properties": props}

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        edge_type: str,
        properties: Dict[str, Any],
        valid_time: Optional[Tuple] = None,
        created_at: Optional[Tuple] = None,
        memory_type: Optional[str] = None,
        is_global: bool = False,
    ):
        # Attach write context to relationship properties
        props_in = dict(properties or {})
        write_ctx = {} if is_global else self.scope_provider.get_write_context()
        props_in.update(write_ctx)

        # Serialize properties for edge
        flat_props = flatten_dict(props_in)
        serialized_props = {}
        for k, v in flat_props.items():
            if self._is_valid_property(k, v):
                serialized_props[k] = self._serialize_value(v)

        # Sanitize edge type (same logic as add_edges_bulk)
        sanitized_type = re.sub(r"[^A-Z0-9_]", "_", edge_type.upper().replace("-", "_"))
        if not sanitized_type:
            sanitized_type = "RELATED"

        params = {
            "source": source_id,
            "target": target_id,
            "props": serialized_props,
        }
        # Scope MATCH to workspace when in multi-tenant mode
        ws_id = write_ctx.get("workspace_id")
        if ws_id:
            params["ws_id"] = ws_id
            query = (
                f"MATCH (a {{item_id: $source, workspace_id: $ws_id}}), "
                f"(b {{item_id: $target, workspace_id: $ws_id}}) "
                f"MERGE (a)-[r:{sanitized_type}]->(b) "
                f"SET r += $props"
            )
        else:
            query = (
                f"MATCH (a {{item_id: $source}}), (b {{item_id: $target}}) "
                f"MERGE (a)-[r:{sanitized_type}]->(b) "
                f"SET r += $props"
            )

        try:
            self._query(query, params)
            # Verify the edge was actually created
            verify_params = {"source": source_id, "target": target_id}
            if ws_id:
                verify_params["ws_id"] = ws_id
                verify_query = (
                    f"MATCH (a {{item_id: $source, workspace_id: $ws_id}})"
                    f"-[r:{sanitized_type}]->"
                    f"(b {{item_id: $target, workspace_id: $ws_id}}) RETURN count(r) as edge_count"
                )
            else:
                verify_query = f"MATCH (a {{item_id: $source}})-[r:{sanitized_type}]->(b {{item_id: $target}}) RETURN count(r) as edge_count"
            verify_result = self._query(verify_query, verify_params)
            edge_count = verify_result[0][0] if verify_result and verify_result[0] else 0

            if edge_count == 0:
                source_check = self._query("MATCH (n {item_id: $id}) RETURN count(n) as count", {"id": source_id})
                target_check = self._query("MATCH (n {item_id: $id}) RETURN count(n) as count", {"id": target_id})
                source_exists = source_check[0][0] if source_check and source_check[0] else 0
                target_exists = target_check[0][0] if target_check and target_check[0] else 0
                logger.debug(
                    "Edge not created: %s --[%s]--> %s | source_exists=%s target_exists=%s",
                    source_id,
                    sanitized_type,
                    target_id,
                    bool(source_exists),
                    bool(target_exists),
                )
                return False

            logger.debug("Edge created: %s --[%s]--> %s", source_id, sanitized_type, target_id)
            return True

        except Exception as e:
            logger.warning("Edge creation error: %s --[%s]--> %s: %s", source_id, sanitized_type, target_id, e)
            return False

    def get_node(self, item_id: str, as_of_time: Optional[str] = None):
        res = self._query("MATCH (n {item_id: $item_id}) RETURN n LIMIT 1", {"item_id": item_id})
        if not res or not res[0]:
            return None

        # Extract properties from FalkorDB Node object
        node = res[0][0]
        if hasattr(node, "properties"):
            props = codec.hydrate_and_unflatten(dict(node.properties))
        else:
            # Fallback to direct attribute access if properties attribute is not available
            props = {k: v for k, v in vars(node).items() if not k.startswith("_") and k != "properties"}

        # Ensure item_id is included in the returned properties at the top level
        props["item_id"] = item_id

        # Remove internal properties that shouldn't be exposed
        props.pop("is_global", None)

        return codec.hydrate_and_unflatten(props)

    def get_neighbors(
        self,
        item_id: str,
        edge_type: Optional[str] = None,
        as_of_time: Optional[str] = None,
        direction: str = "both",
    ):
        # Build relationship pattern with optional direction
        rel = f"[r:{edge_type.upper()}]" if edge_type else "[r]"
        if direction == "outgoing":
            pattern = f"-{rel}->"
        elif direction == "incoming":
            pattern = f"<-{rel}-"
        else:  # "both" — backward-compatible undirected traversal
            pattern = f"-{rel}-"
        query = f"MATCH (n){pattern}(m) WHERE n.item_id = $item_id RETURN m, type(r) as link_type"
        res = self._query(query, {"item_id": item_id})
        out = []
        for record in res:
            node = record[0]
            link_type = record[1] if len(record) > 1 else None

            # Handle both dict-like and Node objects
            if hasattr(node, "keys") and hasattr(node, "values"):
                props = dict(zip(node.keys(), node.values(), strict=False))
            elif hasattr(node, "properties"):
                # FalkorDB Node object
                props = codec.hydrate_and_unflatten(dict(node.properties))
            elif isinstance(node, dict):
                props = node
            else:
                # Fallback: try to convert to dict
                try:
                    props = dict(node)
                except Exception:
                    continue
            # Return tuple of (neighbor, link_type) to match expected format
            out.append((codec.hydrate_and_unflatten(props), link_type))
        return out

    def get_all_edges(self):
        """Get all edges in the graph for debugging purposes."""
        try:
            query = "MATCH (a)-[r]->(b) RETURN a.item_id as source_id, type(r) as edge_type, b.item_id as target_id, r"
            result = self._query(query, {})
            edges = []
            for record in result:
                # FalkorDB returns results as tuples/lists
                if len(record) >= 4:
                    source_id = record[0] if record[0] else "unknown"
                    edge_type = record[1] if record[1] else "unknown"
                    target_id = record[2] if record[2] else "unknown"
                    edge_obj = record[3]

                    # Extract edge properties
                    edge_props = {}
                    if hasattr(edge_obj, "properties"):
                        edge_props = codec.hydrate_and_unflatten(dict(edge_obj.properties))

                    edge_info = {
                        "source_id": source_id,
                        "target_id": target_id,
                        "edge_type": edge_type,
                        "valid_from": edge_props.get("valid_from"),
                        "valid_to": edge_props.get("valid_to"),
                        "created_at": edge_props.get("created_at"),
                        "properties": edge_props,
                    }
                    edges.append(edge_info)
            return edges
        except Exception as e:
            logger.debug("Error getting all edges: %s", e)
            return []

    def remove_node(self, item_id: str):
        self._query("MATCH (n {item_id: $item_id}) DETACH DELETE n", {"item_id": item_id})
        return True

    def remove_edge(self, source_id: str, target_id: str, edge_type: Optional[str] = None):
        if edge_type:
            query = f"MATCH (a {{item_id: $source}})-[r:{edge_type.upper()}]->(b {{item_id: $target}}) DELETE r"
        else:
            query = "MATCH (a {item_id: $source})-[r]->(b {item_id: $target}) DELETE r"
        self._query(query, {"source": source_id, "target": target_id})
        return True

    # ---------- Read helpers for transactional layer ----------

    def node_exists(self, item_id: str) -> bool:
        """Check if a node with this item_id exists (label-agnostic).

        Exceptions propagate to the caller — silent False on transient errors
        would cause add_node() to create duplicate nodes with different labels.
        """
        res = self._query("MATCH (n {item_id: $item_id}) RETURN count(n)", {"item_id": item_id})
        if res and res[0]:
            val = res[0][0]
            return int(val) > 0
        return False

    def get_properties(self, item_id: str) -> Dict[str, Any]:
        props = self.get_node(item_id) or {}
        # Remove internal flags
        props.pop("is_global", None)
        return props

    def set_properties(self, item_id: str, properties: Dict[str, Any]) -> bool:
        # Partial-update any provided properties — list/dict values are routed
        # through the codec (CORE-CRUD-LIST-DESERIALIZE-1); no scalar-only gate.
        from smartmemory.utils import flatten_dict

        props = flatten_dict(properties or {})
        if not props:
            return True
        set_parts = []
        params: Dict[str, Any] = {"item_id": item_id}
        for k, v in props.items():
            if not self._is_valid_property(k, v):
                continue
            # CORE-CYPHER-INJECTION-AUDIT-1: validate caller-controlled key.
            _validate_property_key(k, where="set_properties")
            pk = f"p_{k}"
            set_parts.append(f"n.{k} = ${pk}")
            params[pk] = self._serialize_value(v, key=k)
        if not set_parts:
            return True
        # CORE-EVENT-EXTRACT-1: add workspace scoping (pre-existing bug fix)
        scope_clauses = []
        try:
            filters = self.scope_provider.get_isolation_filters()
            for k, v in filters.items():
                scope_clauses.append(f"n.{k} = $scope_{k}")
                params[f"scope_{k}"] = v
        except Exception:
            pass
        scope_where = (" AND " + " AND ".join(scope_clauses)) if scope_clauses else ""
        q = f"MATCH (n {{item_id: $item_id}}) WHERE 1=1{scope_where} SET {', '.join(set_parts)}"
        self._query(q, params)
        return True

    def accumulate_property(
        self,
        item_id: str,
        property_name: str,
        value: Any,
        session_id: Optional[str] = None,
    ) -> bool:
        """Append *value* to a list-valued property (read-deserialize-append-write).

        Writes the list as a native Cypher array (via the shared codec) so
        queries like ``WHERE $v IN n.{property_name}`` match directly.
        Maintains a parallel ``{property_name}_sources`` dict mapping each
        value to the list of session_ids that contributed it — stored via
        the codec's marker-JSON encoding since dicts can't be native in
        FalkorDB. Workspace-scoped via scope_provider (CORE-EVENT-EXTRACT-1).

        Legacy rows (lists written as bare JSON strings by the pre-codec
        implementation) are transparently decoded on read via
        ``codec.hydrate_props`` and rewritten as native arrays on the next
        accumulate call.

        Not atomic: concurrent writes on the same entity may race. This is
        acceptable because pipeline execution is serialised per item and
        cross-item races on the same entity are rare (canonical_key dedup
        prevents duplicate entity creation within a batch).
        """
        # 1. Build scoped MATCH WHERE clause
        # CORE-CYPHER-INJECTION-AUDIT-1: property_name is interpolated into
        # both the read RETURN clause and write SET clause; sources_prop
        # derives from it so validation covers both.
        _validate_property_key(property_name, where="accumulate_property")

        params: Dict[str, Any] = {"item_id": item_id}
        scope_clauses: list = []
        try:
            filters = self.scope_provider.get_isolation_filters()
            for k, v in filters.items():
                scope_clauses.append(f"n.{k} = $scope_{k}")
                params[f"scope_{k}"] = v
        except Exception:
            pass
        scope_where = (" AND " + " AND ".join(scope_clauses)) if scope_clauses else ""
        sources_prop = f"{property_name}_sources"

        # 2. Read current list and sources dict via codec (handles native
        #    arrays, codec-marker strings, and legacy bare-JSON strings).
        q_read = (
            f"MATCH (n {{item_id: $item_id}}) WHERE 1=1{scope_where} "
            f"RETURN n.{property_name}, n.{sources_prop}"
        )
        res = self._query(q_read, params)

        # Node not found — return False (matches SQLite backend behavior)
        if not res:
            return False

        raw_values = res[0][0]
        raw_sources = res[0][1]
        current_values = codec.deserialize_value(raw_values, key=property_name)
        current_sources = codec.deserialize_value(raw_sources, key=sources_prop)

        if not isinstance(current_values, list):
            # Legacy scalar or missing — normalize to list form.
            current_values = [] if current_values in (None, "") else [current_values]
        if not isinstance(current_sources, dict):
            current_sources = {}

        # 3. Append with dedup; always record session even on dedup
        str_value = str(value)
        if str_value not in current_values:
            current_values.append(str_value)
        if session_id:
            sessions_for_value: list = current_sources.setdefault(str_value, [])
            if session_id not in sessions_for_value:
                sessions_for_value.append(session_id)

        # 4. Write via codec: list-of-strings emerges as native Cypher array,
        #    dict emerges marker-JSON-encoded.
        params["values_v"] = codec.serialize_value(current_values, key=property_name)
        params["sources_v"] = codec.serialize_value(current_sources, key=sources_prop)
        q_write = (
            f"MATCH (n {{item_id: $item_id}}) WHERE 1=1{scope_where} "
            f"SET n.{property_name} = $values_v, n.{sources_prop} = $sources_v"
        )
        self._query(q_write, params)
        return True

    def increment_access(self, item_ids: list, timestamp_iso: str) -> int:
        """Atomically increment access_count and set last_accessed via batch Cypher.

        Uses COALESCE(n.access_count, 0) + 1 for atomic increment.
        Batches all item_ids in one MATCH with WHERE...IN.
        """
        if not item_ids:
            return 0
        q = (
            "MATCH (n) WHERE n.item_id IN $ids "
            "SET n.access_count = COALESCE(n.access_count, 0) + 1, "
            "n.last_accessed = $ts "
            "RETURN count(n) AS updated"
        )
        rows = self._query(q, {"ids": list(item_ids), "ts": timestamp_iso})
        try:
            return rows[0][0] if rows else 0
        except (IndexError, TypeError):
            return 0

    def edge_exists(self, source_id: str, target_id: str, relation_type: str) -> bool:
        try:
            q = f"MATCH (a {{item_id: $s}})-[r:{relation_type.upper()}]->(b {{item_id: $t}}) RETURN count(r)"
            res = self._query(q, {"s": source_id, "t": target_id})
            if res and res[0]:
                return int(res[0][0]) > 0
        except Exception:
            return False
        return False

    def get_edge_properties(self, source_id: str, target_id: str, relation_type: str) -> Optional[Dict[str, Any]]:
        try:
            q = f"MATCH (a {{item_id: $s}})-[r:{relation_type.upper()}]->(b {{item_id: $t}}) RETURN r LIMIT 1"
            res = self._query(q, {"s": source_id, "t": target_id})
            if res and res[0] and res[0][0] is not None:
                r = res[0][0]
                if hasattr(r, "properties"):
                    return dict(r.properties)
                # best-effort
                return {k: v for k, v in vars(r).items() if not k.startswith("_")}
        except Exception:
            return None
        return None

    def list_edges(self, item_id: str) -> List[Dict[str, Any]]:
        try:
            return self.get_edges_for_node(item_id)
        except Exception:
            return []

    def archive(self, item_id: str) -> bool:
        self._query("MATCH (n {item_id: $id}) SET n.archived = true", {"id": item_id})
        return True

    def unarchive(self, item_id: str) -> bool:
        self._query("MATCH (n {item_id: $id}) SET n.archived = false", {"id": item_id})
        return True

    def merge_nodes(self, target_id: str, source_ids: List[str]) -> bool:
        """Merge multiple source nodes into a target node.

        Rewires relationships and merges properties, then deletes source nodes.
        Uses a read-then-recreate approach because FalkorDB does not support
        dynamic edge types (``TYPE(r)``) in MERGE/CREATE patterns.

        Args:
            target_id: The ID of the node to keep (canonical node).
            source_ids: List of IDs of nodes to merge into the target.

        Returns:
            True if successful, False if target does not exist or on error.
        """
        if not source_ids:
            return True

        try:
            # Guard: target must exist — otherwise source deletion causes silent data loss.
            target_check = self._query(
                "MATCH (t {item_id: $tid}) RETURN t.item_id LIMIT 1",
                {"tid": target_id},
            )
            if not target_check:
                logger.error("merge_nodes: target %s does not exist", target_id)
                return False

            for source_id in source_ids:
                if source_id == target_id:
                    continue

                # 1. Read outgoing edges: (source)-[r]->(other), excluding target.
                out_rows = self._query(
                    "MATCH (source {item_id: $sid})-[r]->(other) "
                    "WHERE other.item_id <> $tid "
                    "RETURN other.item_id, type(r), properties(r)",
                    {"sid": source_id, "tid": target_id},
                )

                # 2. Read incoming edges: (other)-[r]->(source), excluding target.
                in_rows = self._query(
                    "MATCH (other)-[r]->(source {item_id: $sid}) "
                    "WHERE other.item_id <> $tid "
                    "RETURN other.item_id, type(r), properties(r)",
                    {"sid": source_id, "tid": target_id},
                )

                # 3. Delete all edges from/to source.
                self._query(
                    "MATCH (source {item_id: $sid})-[r]-() DELETE r",
                    {"sid": source_id},
                )

                # 4. Recreate outgoing edges on target.
                for row in out_rows:
                    other_id, etype, props = row[0], row[1], row[2] if len(row) > 2 else {}
                    self.add_edge(target_id, other_id, etype, props or {})

                # 5. Recreate incoming edges on target.
                for row in in_rows:
                    other_id, etype, props = row[0], row[1], row[2] if len(row) > 2 else {}
                    self.add_edge(other_id, target_id, etype, props or {})

                # 6. Merge properties (source fills gaps, target keeps identity).
                #    ``+=`` overwrites ALL matching keys, including ``item_id``,
                #    so we immediately restore the target's ``item_id`` afterward.
                self._query(
                    "MATCH (source {item_id: $sid}), (target {item_id: $tid}) "
                    "SET target += properties(source), target.item_id = $tid",
                    {"sid": source_id, "tid": target_id},
                )

                # 7. Delete source node.
                self.remove_node(source_id)

            return True

        except Exception as e:
            logger.error("Failed to merge nodes into %s: %s", target_id, e)
            return False

    # ---------- Vector similarity ----------
    def vector_similarity_search(self, embedding: List[float], top_k: int = 5, prop_key: str = "embedding"):
        # Fallback to base implementation (Python-side) until Redis vector module available
        return super().vector_similarity_search(embedding, top_k, prop_key)

    # ---------- Query helpers ----------

    def search_nodes(self, query: Dict[str, Any], is_global: bool = False):
        """Search for nodes matching query properties.

        Args:
            query: Dictionary of property filters (simple equality only)
            is_global: Whether to search globally or scope to user/workspace

        Returns:
            List of node dictionaries matching the query
        """
        clauses = []
        params = {}

        # Add query clauses (simple equality). List-member matching uses
        # the dedicated `search_nodes_by_member` helper — see
        # CORE-CRUD-LIST-DESERIALIZE-1 design for why polymorphic
        # predicates can't be expressed safely in one FalkorDB query.
        for idx, (k, v) in enumerate(query.items()):
            # CORE-CYPHER-INJECTION-AUDIT-1: caller-controlled key.
            _validate_property_key(k, where="search_nodes")
            param_key = f"p{idx}"
            clauses.append(f"n.{k} = ${param_key}")
            params[param_key] = v

        # Apply Scope Provider Isolation
        if is_global:
            # Global search: Explicitly exclude user-scoped nodes (Public/Shared nodes)
            user_key = self.scope_provider.get_user_isolation_key()
            clauses.append(f"(n.{user_key} IS NULL)")

            # Enforce isolation filters for global searches (excludes user-level)
            filters = self.scope_provider.get_global_search_filters()
            for k, v in filters.items():
                clauses.append(f"n.{k} = $ctx_{k}")
                params[f"ctx_{k}"] = v
        else:
            # Scoped search: Enforce all isolation filters (User + Tenant + Workspace)
            filters = self.scope_provider.get_isolation_filters()
            for k, v in filters.items():
                # Skip if the query itself explicitly filters on this key
                if k not in query:
                    clauses.append(f"n.{k} = $ctx_{k}")
                    params[f"ctx_{k}"] = v

        if clauses:
            where_clause = " AND ".join(clauses)
            cypher = f"MATCH (n) WHERE {where_clause} RETURN n"
        else:
            cypher = "MATCH (n) RETURN n"
        res = self._query(cypher, params)
        result = []
        for record in res:
            node = record[0]
            if hasattr(node, "properties"):
                props = codec.hydrate_and_unflatten(dict(node.properties))
            else:
                # Fallback to direct attribute access if properties attribute is not available
                props = {k: v for k, v in vars(node).items() if not k.startswith("_") and k != "properties"}

            # Remove internal properties that shouldn't be exposed
            props.pop("is_global", None)

            # Don't use unflatten_dict to preserve flat structure with item_id
            result.append(props)
        return result

    def _build_token_match(self, tokens: List[str], var_name: str = "e") -> tuple[str, str, Dict[str, Any]]:
        """Build Cypher WHERE clause + overlap expression for token matching.

        Returns (token_where, overlap_expr, params).
        Reused by search_by_entity() and search_by_activation().

        Args:
            tokens: Lowercase query tokens.
            var_name: Cypher variable name to use (default "e"; pass "alias" for UNION branch).
        """
        token_clauses = []
        params: Dict[str, Any] = {}
        for i, token in enumerate(tokens):
            p_tok = f"tok{i}"
            p_tok_sp = f"tok{i}_sp"     # "token "
            p_sp_tok = f"tok{i}_sp2"    # " token"
            p_sp_tok_sp = f"tok{i}_sp3"  # " token "
            params[p_tok] = token
            params[p_tok_sp] = token + " "
            params[p_sp_tok] = " " + token
            params[p_sp_tok_sp] = " " + token + " "
            # Word-boundary match on both content and name fields
            v = var_name
            field_match = (
                f"(toLower({v}.content) = ${p_tok}"
                f" OR toLower({v}.content) STARTS WITH ${p_tok_sp}"
                f" OR toLower({v}.content) ENDS WITH ${p_sp_tok}"
                f" OR toLower({v}.content) CONTAINS ${p_sp_tok_sp}"
                f" OR toLower({v}.name) = ${p_tok}"
                f" OR toLower({v}.name) STARTS WITH ${p_tok_sp}"
                f" OR toLower({v}.name) ENDS WITH ${p_sp_tok}"
                f" OR toLower({v}.name) CONTAINS ${p_sp_tok_sp})"
            )
            token_clauses.append(field_match)
        token_where = " OR ".join(token_clauses)

        # Overlap expression: count matching tokens per entity for scoring
        token_count_clauses = []
        v = var_name
        for i in range(len(tokens)):
            p_tok = f"tok{i}"
            p_tok_sp = f"tok{i}_sp"
            p_sp_tok = f"tok{i}_sp2"
            p_sp_tok_sp = f"tok{i}_sp3"
            token_count_clauses.append(
                f"CASE WHEN (toLower({v}.content) = ${p_tok}"
                f" OR toLower({v}.content) STARTS WITH ${p_tok_sp}"
                f" OR toLower({v}.content) ENDS WITH ${p_sp_tok}"
                f" OR toLower({v}.content) CONTAINS ${p_sp_tok_sp}"
                f" OR toLower({v}.name) = ${p_tok}"
                f" OR toLower({v}.name) STARTS WITH ${p_tok_sp}"
                f" OR toLower({v}.name) ENDS WITH ${p_sp_tok}"
                f" OR toLower({v}.name) CONTAINS ${p_sp_tok_sp})"
                f" THEN 1 ELSE 0 END"
            )
        overlap_expr = " + ".join(token_count_clauses)

        return token_where, overlap_expr, params

    def _build_scope_where(self, params: Dict[str, Any]) -> str:
        """Build scoping clause for memory nodes (variable 'm').

        Mutates *params* in-place to add scope parameters.
        Returns a string like ' AND ( ... )' or ''.

        CORE-SCOPE-1 (2026-04-17): prefers structured retrieval filters via
        ``get_retrieval_filters()`` when available — composes an OR-group so
        WORKSPACE mode (default) returns workspace items PLUS the requester's
        personal items (``scope = 'personal' AND user_id = X``). Falls back
        to the legacy flat ``get_isolation_filters()`` dict for providers that
        haven't adopted the new contract.

        **Conflict precedence** (design decision, CORE-SCOPE-1): when both a
        workspace-match and a personal-match row exist for the same logical
        content (e.g. "use Vitest" personal vs "use Jest" workspace),
        WORKSPACE WINS — project decisions override personal preferences.
        This is enforced downstream at the ranking layer (SSG/BM25/RRF
        favor specific workspace matches over cross-scope personal ones);
        the Cypher layer returns both rows, ranking resolves the conflict.
        """
        provider = self.scope_provider

        # Prefer structured filter (CORE-SCOPE-1) when provider supports it
        if hasattr(provider, "get_retrieval_filters"):
            structured = provider.get_retrieval_filters()
            # Validate shape: must be dict with the 4 known clause keys.
            # Anything else (None, non-dict, missing keys) indicates a
            # misconfigured provider — fail loud per no-silent-degradation.md.
            if structured is None:
                raise ValueError(
                    "CORE-SCOPE-1: scope_provider.get_retrieval_filters() "
                    "returned None. Per no-silent-degradation.md, a None "
                    "return cannot silently fall back to no filter — "
                    "cross-tenant read leak risk."
                )
            if not isinstance(structured, dict):
                raise ValueError(
                    f"CORE-SCOPE-1: scope_provider.get_retrieval_filters() "
                    f"returned {type(structured).__name__}, expected dict. "
                    f"Cannot compose retrieval filter — fail loud rather than "
                    f"silently widening the query."
                )
            where = FalkorDBBackend._compose_retrieval_where(structured, params)
            if where:
                return " AND " + where
            return ""

        # Legacy path: flat AND-chain from get_isolation_filters()
        filters = provider.get_isolation_filters()
        scope_clauses = []
        for k, v in filters.items():
            scope_clauses.append(f"m.{k} = $ctx_{k}")
            params[f"ctx_{k}"] = v
        return (" AND " + " AND ".join(scope_clauses)) if scope_clauses else ""

    # CORE-SCOPE-1: exact key set expected from get_retrieval_filters().
    # Enforced in _compose_retrieval_where to reject malformed providers.
    _RETRIEVAL_FILTER_KEYS = frozenset(
        {"workspace_clause", "personal_clause", "tenant_clause", "user_clause"}
    )

    @staticmethod
    def _compose_retrieval_where(
        structured: Dict[str, Any], params: Dict[str, Any]
    ) -> str:
        """Compose an OR-group Cypher fragment from a structured retrieval filter.

        Shape of ``structured`` (per MemoryScopeProvider.get_retrieval_filters):
            {
                "workspace_clause": {..} | None,
                "personal_clause":  {..} | None,
                "tenant_clause":    {..} | None,
                "user_clause":      {..} | None,
            }

        All four keys MUST be present (values may be None). Unknown keys are
        rejected — a malformed provider that omits ``tenant_clause`` could
        silently widen reads past the org boundary, so we fail loud instead.

        Composition:
            (workspace_clause AND user_clause AND tenant_clause)
            OR (personal_clause AND tenant_clause)

        None clauses are skipped. If only one clause survives (e.g. TENANT
        mode or PERSONAL mode), no OR is emitted.

        Returns the fragment *without* a leading " AND " (caller prefixes).
        """
        # Validate shape — reject unknown keys and missing-required keys.
        actual_keys = set(structured.keys())
        missing = FalkorDBBackend._RETRIEVAL_FILTER_KEYS - actual_keys
        unknown = actual_keys - FalkorDBBackend._RETRIEVAL_FILTER_KEYS
        if missing or unknown:
            raise ValueError(
                f"CORE-SCOPE-1: malformed retrieval filter. "
                f"Expected keys {sorted(FalkorDBBackend._RETRIEVAL_FILTER_KEYS)}; "
                f"missing={sorted(missing)}, unknown={sorted(unknown)}. "
                f"Refusing to compose — fail loud rather than silently "
                f"widening the query."
            )

        workspace = structured.get("workspace_clause")
        personal = structured.get("personal_clause")
        tenant = structured.get("tenant_clause")
        user = structured.get("user_clause")

        def _clause_to_fragment(
            clause: Optional[Dict[str, Any]],
            params: Dict[str, Any],
            param_prefix: str,
        ) -> str:
            """Turn a ``{field: value}`` dict into ``m.field = $param`` AND-chain."""
            if not clause:
                return ""
            parts = []
            for k, v in clause.items():
                pkey = f"ctx_{param_prefix}{k}"
                parts.append(f"m.{k} = ${pkey}")
                params[pkey] = v
            return " AND ".join(parts)

        # Workspace-arm: workspace + user (if USER mode) + tenant
        ws_arm_parts = []
        ws_frag = _clause_to_fragment(workspace, params, "ws_")
        if ws_frag:
            ws_arm_parts.append(ws_frag)
        user_frag = _clause_to_fragment(user, params, "user_")
        if user_frag:
            ws_arm_parts.append(user_frag)
        # Tenant participates in BOTH arms if present (tenant isolation holds
        # for both workspace reads and personal reads)
        tenant_frag = _clause_to_fragment(tenant, params, "tenant_")
        if tenant_frag and ws_arm_parts:
            ws_arm_parts.append(tenant_frag)
        ws_arm = " AND ".join(ws_arm_parts) if ws_arm_parts else ""

        # Personal-arm: personal + tenant
        p_arm_parts = []
        p_frag = _clause_to_fragment(personal, params, "personal_")
        if p_frag:
            p_arm_parts.append(p_frag)
        if tenant_frag and p_arm_parts:
            p_arm_parts.append(tenant_frag)
        personal_arm = " AND ".join(p_arm_parts) if p_arm_parts else ""

        arms = [a for a in (ws_arm, personal_arm) if a]

        if not arms:
            # Only tenant_clause survived (TENANT isolation mode)
            if tenant_frag:
                return f"({tenant_frag})"
            return ""

        if len(arms) == 1:
            return f"({arms[0]})"

        return f"(({arms[0]}) OR ({arms[1]}))"

    def search_by_entity(self, tokens: List[str], top_k: int = 5) -> Optional[List[Dict[str, Any]]]:
        """CORE-SEARCH-2 Phase 2: Entity lookup via Cypher.

        Matches entity/relation nodes whose content or name contains any query
        token, then traverses MENTIONED_IN and CONTAINS_ENTITY edges to find
        linked memory nodes. Results are scoped to the current workspace.

        Args:
            tokens: Lowercase query tokens (stop words already removed).
            top_k: Maximum memories to return.

        Returns:
            List of memory node dicts ordered by edge confidence, or None if
            no entities match.
        """
        if not tokens:
            return None

        # Build token match clause: match entity/relation nodes on content OR name.
        # Use word-boundary-aware matching to avoid substring false positives
        # (e.g., "go" matching "Django"). Simulates token overlap from the lite
        # path (_search_with_graph_entities) which uses set intersection on words.
        # A token matches a field if: field equals token, field starts with "token ",
        # field ends with " token", or field contains " token ".
        #
        # CORE-ENTITY-RESOLVE-1: Two UNION branches:
        #   Tier 1 — direct canonical entity match (excludes alias stubs)
        #   Tier 2 — ALIAS_OF traversal (matches alias stub → canonical → memory)
        token_where_e, overlap_expr_e, params = self._build_token_match(tokens, var_name="e")
        token_where_a, overlap_expr_a, _ = self._build_token_match(tokens, var_name="alias")
        # params are shared (same tok0/tok1/... names); UNION branches share the namespace
        total_tokens = len(tokens)

        # Workspace scoping on memory nodes (not entity nodes — entities may be shared)
        scope_where = self._build_scope_where(params)

        alias_discount = (
            self._entity_resolve_config.alias_discount
            if self._entity_resolve_config is not None
            else 0.85
        )

        # Tier 1: direct canonical entity → memory traversal
        # Tier 2: alias stub → ALIAS_OF → canonical → memory traversal (score discounted)
        # Both branches exclude alias stubs from being treated as canonical entities.
        cypher = f"""
        MATCH (e)
        WHERE (e.node_category = 'entity' OR e.node_category = 'relation'
               OR e.memory_type = 'entity' OR e.memory_type = 'relation')
          AND coalesce(e.node_category, 'entity') <> 'alias'
          AND ({token_where_e})
        WITH e, toFloat({overlap_expr_e}) / {total_tokens} AS overlap_ratio
        MATCH (e)-[r:MENTIONED_IN|CONTAINS_ENTITY]-(m)
        WHERE coalesce(m.node_category, 'memory') <> 'entity'
          AND coalesce(m.node_category, 'memory') <> 'relation'
          AND coalesce(m.memory_type, '') <> 'entity'
          AND coalesce(m.memory_type, '') <> 'relation'
          AND coalesce(m.memory_type, '') <> 'Version'
          {scope_where}
        RETURN DISTINCT m, max(overlap_ratio * coalesce(r.confidence, 0.5)) AS score
        ORDER BY score DESC, m.item_id ASC
        LIMIT $top_k

        UNION

        MATCH (alias)
        WHERE alias.node_category = 'alias'
          AND ({token_where_a})
          {scope_where.replace('m.', 'alias.')}
        WITH alias, toFloat({overlap_expr_a}) / {total_tokens} AS overlap_ratio
        MATCH (alias)-[:ALIAS_OF]->(canonical)-[r:MENTIONED_IN|CONTAINS_ENTITY]-(m)
        WHERE coalesce(m.node_category, 'memory') <> 'entity'
          AND coalesce(m.node_category, 'memory') <> 'relation'
          AND coalesce(m.memory_type, '') <> 'entity'
          AND coalesce(m.memory_type, '') <> 'relation'
          AND coalesce(m.memory_type, '') <> 'Version'
          {scope_where}
        RETURN DISTINCT m, max(overlap_ratio * {alias_discount} * coalesce(r.confidence, 0.5)) AS score
        ORDER BY score DESC, m.item_id ASC
        LIMIT $top_k
        """
        params["top_k"] = top_k

        try:
            res = self._query(cypher, params)
        except Exception as e:
            logger.warning("search_by_entity Cypher failed: %s", e)
            return None

        # CORE-ENTITY-SEARCH-HARDEN-1: dedup UNION results (CORE-16) + capture scores (CORE-17).
        # UNION can return the same memory via both canonical and alias branches.
        result = []
        seen_ids: Dict[str, int] = {}  # item_id → index in result (for score upgrade)
        if res:
            for record in res:
                node = record[0]
                # record[1] is the score from Cypher ORDER BY
                score = float(record[1]) if len(record) > 1 and record[1] else 0.0
                if hasattr(node, "properties"):
                    props = codec.hydrate_and_unflatten(dict(node.properties))
                else:
                    props = node if isinstance(node, dict) else {}
                props.pop("is_global", None)
                iid = props.get("item_id")
                if iid and iid in seen_ids:
                    # CORE-16: duplicate from other UNION branch — keep higher score
                    existing_idx = seen_ids[iid]
                    if score > result[existing_idx].get("_entity_score", 0.0):
                        props["_entity_score"] = score
                        result[existing_idx] = props
                    continue
                props["_entity_score"] = score
                if iid:
                    seen_ids[iid] = len(result)
                result.append(props)

        # CORE-17: sort by score descending (guarantees exact > alias ordering)
        result.sort(key=lambda r: -r.get("_entity_score", 0.0))
        result = result[:top_k]  # CORE-16: enforce top_k after merge

        # CORE-ENTITY-RESOLVE-1 Tier 3: Embedding fuzzy fallback.
        # Only activates when exact+alias Cypher returned fewer than top_k results
        # and an EntityResolver is wired in.
        if len(result) < top_k and self._entity_resolver is not None:
            workspace_id = self._get_workspace_id()
            remaining = top_k - len(result)
            # Overfetch entities: request more than remaining so lower-similarity entities
            # with stronger edges can still contribute candidates. Final sort handles ranking.
            # Note: this is best-effort — perfect global top-k would require traversing ALL
            # above-threshold entities, which may exceed the 50ms fuzzy budget.
            _entity_fetch_k = max(remaining * 3, top_k)
            fuzzy_matches = self._entity_resolver.resolve(tokens, workspace_id, top_k=_entity_fetch_k)
            fuzzy_discount = (
                self._entity_resolve_config.fuzzy_discount
                if self._entity_resolve_config is not None
                else 0.70
            )
            # Overfetch across all fuzzy entities — don't stop early.
            # Final sort+truncate ensures best-effort global top-k selection.
            _fuzzy_fetch_k = max(top_k, remaining)
            for match in fuzzy_matches:
                fuzzy_params: Dict[str, Any] = {"eid": match.entity_node_id, "top_k": _fuzzy_fetch_k}
                fuzzy_scope = self._build_scope_where(fuzzy_params)
                fuzzy_cypher = f"""
                MATCH (e {{item_id: $eid}})-[r:MENTIONED_IN|CONTAINS_ENTITY]-(m)
                WHERE coalesce(m.node_category, 'memory') <> 'entity'
                  AND coalesce(m.node_category, 'memory') <> 'relation'
                  AND coalesce(m.memory_type, '') <> 'entity'
                  AND coalesce(m.memory_type, '') <> 'relation'
                  AND coalesce(m.memory_type, '') <> 'Version'
                  {fuzzy_scope}
                RETURN DISTINCT m, max(coalesce(r.confidence, 0.5)) AS edge_conf
                ORDER BY edge_conf DESC
                LIMIT $top_k
                """
                try:
                    fuzzy_res = self._query(fuzzy_cypher, fuzzy_params)
                    for rec in fuzzy_res or []:
                        node = rec[0]
                        # Use real edge confidence (matches exact/alias Cypher scoring)
                        edge_conf = float(rec[1]) if len(rec) > 1 and rec[1] else 0.5
                        discounted_score = match.similarity_score * fuzzy_discount * edge_conf
                        props = codec.hydrate_and_unflatten(dict(node.properties)) if hasattr(node, "properties") else {}
                        props.pop("is_global", None)
                        item_id = props.get("item_id")
                        if item_id not in seen_ids:
                            props["_fuzzy_score"] = discounted_score
                            seen_ids[item_id] = len(result)
                            result.append(props)
                        else:
                            # Duplicate — upgrade score if this path is better
                            existing_idx = seen_ids[item_id]
                            existing = result[existing_idx]
                            old_score = max(existing.get("_entity_score", 0.0), existing.get("_fuzzy_score", 0.0))
                            if discounted_score > old_score:
                                existing["_fuzzy_score"] = discounted_score
                except Exception as fuzzy_exc:
                    logger.warning(
                        "EntityResolver fuzzy traversal failed for entity %s: %s",
                        match.entity_node_id,
                        fuzzy_exc,
                    )

        # Unified sort: exact/alias by _entity_score, fuzzy by _fuzzy_score.
        # All tiers use real edge confidence: exact = overlap * conf,
        # alias = overlap * alias_discount * conf, fuzzy = similarity * fuzzy_discount * conf.
        # With default conf=0.5: exact max=0.50, alias max=0.425, fuzzy max=0.35.
        if result:
            result.sort(key=lambda r: -max(r.get("_entity_score", 0.0), r.get("_fuzzy_score", 0.0)))
            result = result[:top_k]

        return result if result else None

    def search_by_activation(
        self,
        tokens: List[str],
        top_k: int = 5,
        max_hops: int = 2,
        decay: float = 0.5,
    ) -> Optional[List[Dict[str, Any]]]:
        """NEURO-1d: Spreading activation retrieval through entity graph edges.

        Seeds from entity token matches (same as search_by_entity), then
        traverses 2+ edge paths to find memory nodes reachable through
        intermediate entities. 1-hop results are skipped (already covered
        by the entity-graph channel).

        Score = seed_overlap * decay^(path_length). Max activation per
        memory node across all seed paths.

        Args:
            tokens: Lowercase query tokens (stop words already removed).
            top_k: Maximum memories to return.
            max_hops: Maximum edge depth to traverse (default 2 = paths of 2-3 edges).
            decay: Decay factor per edge hop (default 0.5).

        Returns:
            List of memory node dicts ordered by activation score, or None.
        """
        if not tokens:
            return None

        token_where, overlap_expr, params = self._build_token_match(tokens)
        total_tokens = len(tokens)
        scope_where = self._build_scope_where(params)

        # Variable-length path: *2..max_hops+1 skips 1-hop (entity-graph channel)
        max_path_len = max_hops + 1
        params["top_k"] = top_k
        params["decay"] = decay

        cypher = f"""
        MATCH (e)
        WHERE (e.node_category = 'entity' OR e.node_category = 'relation'
               OR e.memory_type = 'entity' OR e.memory_type = 'relation')
          AND coalesce(e.node_category, 'entity') <> 'alias'
          AND ({token_where})
        WITH e, toFloat({overlap_expr}) / {total_tokens} AS seed_score
        MATCH path = (e)-[:MENTIONED_IN|:CONTAINS_ENTITY|:PART_OF|:related_to*2..{max_path_len}]-(m)
        WHERE coalesce(m.node_category, 'memory') <> 'entity'
          AND coalesce(m.node_category, 'memory') <> 'relation'
          AND coalesce(m.memory_type, '') <> 'entity'
          AND coalesce(m.memory_type, '') <> 'relation'
          AND coalesce(m.memory_type, '') <> 'Version'
          AND m.content IS NOT NULL
          {scope_where}
        WITH m, max(seed_score * exp(log($decay) * length(path))) AS activation
        RETURN m, activation AS score
        ORDER BY score DESC
        LIMIT $top_k
        """

        try:
            res = self._query(cypher, params)
        except Exception as e:
            logger.warning("search_by_activation Cypher failed: %s", e)
            return None

        if not res:
            return None

        result = []
        for record in res:
            node = record[0]
            if hasattr(node, "properties"):
                props = codec.hydrate_and_unflatten(dict(node.properties))
            else:
                props = node if isinstance(node, dict) else {}
            props.pop("is_global", None)
            result.append(props)

        return result if result else None

    def search_by_activation_from_seeds(
        self,
        seed_item_ids: List[str],
        depth: int = 2,
        max_fan_out: int = 20,
        damping: float = 0.5,
        edge_types: Optional[List[str]] = None,
        budget_ms: int = 150,
    ) -> List[tuple]:
        """Bounded BFS spreading from seed item_ids (M3 Slice B.1).

        Sibling of :meth:`search_by_activation` — same spreading pattern,
        but driven by caller-provided seed item_ids instead of tokens. The
        token-driven path stays untouched so M0-M2 callers are unaffected.

        Returns a list of ``(item_id, shortest_hops)`` tuples. Client-side
        decay (damping ** hops) and cross-seed aggregation happen in
        :func:`smartmemory.search.spreading_activation.spread` — this
        method is the pure-Cypher primitive.

        Workspace scoping: seeds and targets are both filtered on the
        current workspace_id, and global nodes (``workspace_id='*'``) are
        excluded at both ends. An explicit workspace filter is used rather
        than ``_build_scope_where`` because the semantics here are
        strictly "same workspace as the caller" — personal-overlay reads
        don't make sense for graph traversal.

        Edge-type filter: ``edge_types=None`` means "every type except the
        design-specified excludes" (CONTRADICTS / SUPERSEDES / GROUNDED_IN).
        Passing an explicit list uses that list verbatim. See design §3.3.

        Budget: the ``budget_ms`` kwarg maps to FalkorDB's per-query TIMEOUT
        (in milliseconds). Spike S1 confirmed FalkorDB raises
        ``ResponseError: Query timed out`` on timeout — the caller (``spread``)
        catches that. This method does NOT catch — bubble the raw error so
        the caller can distinguish timeout from other failure modes.
        """
        if not seed_item_ids:
            return []

        workspace_id = self._get_workspace_id()

        # Default edge allowlist — spreading-relevant types from the
        # graph schema (see docs/FEATURES.md — blueprint-m3.md §C3).
        # Semantic-excludes (CONTRADICTS, SUPERSEDES, GROUNDED_IN) are
        # dropped because (a) contradictions shouldn't propagate boosts,
        # (b) supersession is a replacement relation not a semantic
        # neighbour, and (c) grounded-in paths lead to global Wikidata
        # entities we'd skip anyway via the workspace filter.
        _DEFAULT_ALLOWED = [
            "RELATED", "RELATES_TO", "CO_RETRIEVED", "ANSWERED_BY",
            "PART_OF", "MENTIONS", "MENTIONED_IN", "CONTAINS_ENTITY",
            "LINKS_TO", "LINKED_TO", "DERIVED_FROM", "INFERRED_FROM",
            "HAS_SKILL", "HAS_CONTEXT", "TAGGED_WITH", "ALIAS_OF",
        ]
        if edge_types is None:
            allowed = list(_DEFAULT_ALLOWED)
        else:
            allowed = list(edge_types)
        if not allowed:
            return []  # no edge types to traverse → no paths → empty

        # Sanitize type names to prevent Cypher injection: relationship
        # types are identifiers, so only alphanumeric + underscore allowed.
        # A caller passing something exotic gets filtered silently — the
        # default list is always safe.
        import re as _re
        _safe_pat = _re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
        safe_allowed = [t for t in allowed if _safe_pat.match(t)]
        if not safe_allowed:
            return []

        # Cap fan-out globally (max_fan_out per hop × depth).
        total_limit = max_fan_out * max(1, int(depth))

        params: Dict[str, Any] = {
            "seeds": list(seed_item_ids),
            "ws_id": workspace_id,
            "limit": int(total_limit),
        }

        # Variable-length path with inline edge-type list. This is the
        # FalkorDB-supported pattern (see existing ``search_by_activation``
        # at this file for precedent). ``type(r)`` + ``ALL()`` is NOT
        # supported in variable-length MATCH predicates — the engine
        # rejects with "Type mismatch: expected List or Null but was Edge".
        edge_pattern = "|".join(f":{t}" for t in safe_allowed)
        cypher = f"""
        MATCH (seed)
        WHERE seed.item_id IN $seeds
          AND seed.workspace_id = $ws_id
        MATCH path = (seed)-[{edge_pattern}*1..{int(depth)}]-(m)
        WHERE m.workspace_id = $ws_id
          AND seed.item_id <> m.item_id
        WITH m, min(length(path)) AS shortest
        RETURN m.item_id AS item_id, shortest
        ORDER BY shortest, item_id
        LIMIT $limit
        """

        # Pass TIMEOUT via query param. FalkorDB's python client accepts
        # ``timeout`` on graph.query(...) — spike S1 verified this path.
        try:
            res = self.graph.query(cypher, params, timeout=int(budget_ms))
        except TypeError:
            # Very old falkordb client without timeout kwarg — fall back
            # to untimed query. Logged at debug, not fatal.
            logger.debug(
                "search_by_activation_from_seeds: client does not accept "
                "timeout kwarg; running without budget enforcement",
            )
            res = self.graph.query(cypher, params)

        rows = res.result_set if hasattr(res, "result_set") else []
        out: List[tuple] = []
        for row in rows:
            try:
                item_id = row[0]
                hops = int(row[1])
            except (IndexError, TypeError, ValueError):
                continue
            if item_id:
                out.append((item_id, hops))
        return out

    def materialize_workspace_subgraph(self, max_nodes: int = 10_000):
        """Materialize the current workspace's subgraph into a NetworkX
        DiGraph for PPR computation (M3 Slice C.1.1).

        Two-step fetch:
        1. Cheap node-count probe: ``MATCH (n {workspace_id: $ws})
           RETURN count(n) AS c``. Exact node count, unaffected by
           edge density. If ``c > max_nodes``, returns None and emits
           INFO ``ppr_skipped_oversized_workspace`` (single-owner
           contract per blueprint C8).
        2. Subgraph fetch: ``MATCH (n {workspace_id: $ws})
           OPTIONAL MATCH (n)-[r]->(m {workspace_id: $ws})
           RETURN n, r, m``. The ``OPTIONAL MATCH`` keeps isolated
           nodes in the graph. Global nodes (``workspace_id='*'``)
           excluded at both endpoints so shared Wikidata entities
           don't bridge the subgraph.

        Returns ``None`` on over-cap. Raises on unexpected DB errors —
        caller (``personalized_pagerank``) catches at its
        submit/timeout envelope.
        """
        try:
            import networkx as nx
        except ImportError:
            logger.warning(
                "materialize_workspace_subgraph: networkx not installed; "
                "PPR unavailable",
            )
            return None

        workspace_id = self._get_workspace_id()

        # Step 1: node-count probe.
        count_cypher = (
            "MATCH (n) WHERE n.workspace_id = $ws RETURN count(n) AS c"
        )
        count_res = self._query(count_cypher, {"ws": workspace_id})
        if not count_res:
            return nx.DiGraph()  # empty workspace
        try:
            node_count = int(count_res[0][0])
        except (IndexError, TypeError, ValueError):
            logger.debug(
                "materialize_workspace_subgraph: node-count probe "
                "returned unexpected shape: %r", count_res,
            )
            return nx.DiGraph()

        if node_count > max_nodes:
            logger.info(
                "ppr_skipped_oversized_workspace: workspace %s has %d "
                "nodes > cap=%d — returning None",
                workspace_id, node_count, max_nodes,
            )
            return None

        # Step 2: fetch the subgraph. OPTIONAL MATCH keeps isolated
        # nodes in the result; we dedupe client-side by item_id.
        fetch_cypher = """
        MATCH (n)
        WHERE n.workspace_id = $ws
        OPTIONAL MATCH (n)-[r]->(m)
        WHERE m.workspace_id = $ws
        RETURN n.item_id AS src, m.item_id AS tgt
        """
        rows = self._query(fetch_cypher, {"ws": workspace_id})

        g = nx.DiGraph()
        for row in rows:
            try:
                src, tgt = row[0], row[1]
            except (IndexError, TypeError):
                continue
            if src:
                g.add_node(src, item_id=src)
            if src and tgt:
                g.add_node(tgt, item_id=tgt)
                g.add_edge(src, tgt)
        return g

    def search_nodes_by_member(
        self, key: str, value: Any, is_global: bool = False
    ) -> List[Dict[str, Any]]:
        """Search for nodes whose ``n.{key}`` list contains ``value``.

        Assumes the queried key holds a homogeneous native Cypher array
        across all matched rows. CORE-CRUD-LIST-MEMBER-1: callers running
        against a corpus that may contain legacy stringified-list values
        must run ``migrate_list_properties()`` first; otherwise FalkorDB
        will raise ``Type mismatch: expected List or Null but was String``
        on the first scalar-storage row encountered.

        Pass the dunder-flattened key (``"metadata__tags"``), not the
        nested form (``"metadata.tags"``) — the backend stores values
        under the flat key.

        Raises:
            ValueError: if ``key`` is not a safe Cypher identifier
                (must match ``^[A-Za-z_][A-Za-z0-9_]*$``). Cypher does
                not support property-name parameterization, so the key
                is interpolated directly — validation prevents injection.
        """
        _validate_property_key(key, where="search_nodes_by_member")
        clauses = [f"$value IN n.{key}"]
        params: Dict[str, Any] = {"value": value}

        if is_global:
            user_key = self.scope_provider.get_user_isolation_key()
            clauses.append(f"(n.{user_key} IS NULL)")
            filters = self.scope_provider.get_global_search_filters()
        else:
            filters = self.scope_provider.get_isolation_filters()
        for k, v in filters.items():
            clauses.append(f"n.{k} = $ctx_{k}")
            params[f"ctx_{k}"] = v

        cypher = f"MATCH (n) WHERE {' AND '.join(clauses)} RETURN n"
        res = self._query(cypher, params)
        result = []
        for record in res:
            node = record[0]
            if hasattr(node, "properties"):
                props = codec.hydrate_and_unflatten(dict(node.properties))
            else:
                props = {k: v for k, v in vars(node).items() if not k.startswith("_") and k != "properties"}
            props.pop("is_global", None)
            result.append(props)
        return result

    def migrate_list_properties(
        self,
        key_filter: Optional[List[str]] = None,
        batch_size: int = 500,
        dry_run: bool = False,
    ) -> Dict[str, int]:
        """Rewrite legacy stringified list properties as native Cypher arrays.

        Idempotent: native-list values are skipped. Marker-prefixed JSON
        strings and bare-JSON strings that decode to a list are rewritten.

        Args:
            key_filter: If provided, only migrate these property keys
                (use the dunder-flat form, e.g. ``["metadata__tags"]``).
                None means scan all property keys.
            batch_size: Nodes per batch (currently informational; the
                migration uses one-row-at-a-time SET to keep changes
                atomic per node).
            dry_run: If True, count what would be rewritten without
                writing. Returns the same counts dict.

        Returns:
            ``{"rewritten": N, "skipped": N, "failed": N, "scanned": N}``
        """
        # CORE-CRUD-LIST-MEMBER-1: prerequisite for safe `IN` queries on
        # any property whose history mixes native arrays with legacy
        # JSON-stringified lists.
        # TODO(perf): batch via UNWIND once a million-node corpus shows up.
        counts = {"rewritten": 0, "skipped": 0, "failed": 0, "scanned": 0}

        # Validate caller-supplied key_filter — interpolated into Cypher.
        if key_filter is not None:
            for k in key_filter:
                _validate_property_key(k, where="migrate_list_properties.key_filter")

        # Apply scope filtering — never migrate across workspaces.
        scope_clauses = []
        scope_params: Dict[str, Any] = {}
        try:
            for k, v in self.scope_provider.get_isolation_filters().items():
                scope_clauses.append(f"n.{k} = $scope_{k}")
                scope_params[f"scope_{k}"] = v
        except Exception:
            pass
        scope_where_read = (" WHERE " + " AND ".join(scope_clauses)) if scope_clauses else ""
        # Same scope predicates re-applied on write-back so a stray cross-tenant
        # node with the same item_id can never be rewritten by this call.
        scope_where_write = (" AND " + " AND ".join(scope_clauses)) if scope_clauses else ""

        nodes_q = f"MATCH (n){scope_where_read} RETURN n"
        for record in self._query(nodes_q, scope_params):
            node = record[0]
            counts["scanned"] += 1
            item_id = (
                getattr(node, "properties", {}).get("item_id")
                if hasattr(node, "properties")
                else None
            )
            if not item_id:
                continue
            raw_props = dict(node.properties) if hasattr(node, "properties") else {}
            for prop_key, raw_value in raw_props.items():
                if key_filter is not None and prop_key not in key_filter:
                    continue
                if not _CYPHER_IDENT_RE.match(prop_key):
                    # Stored key not a safe Cypher identifier — skip rather
                    # than risk injection or syntax error.
                    counts["skipped"] += 1
                    continue
                if isinstance(raw_value, list):
                    counts["skipped"] += 1
                    continue
                decoded = codec.deserialize_value(raw_value, key=prop_key)
                if not isinstance(decoded, list):
                    counts["skipped"] += 1
                    continue
                if dry_run:
                    counts["rewritten"] += 1
                    continue
                try:
                    write_params = {"iid": item_id, "val": decoded, **scope_params}
                    self._query(
                        f"MATCH (n {{item_id: $iid}}) "
                        f"WHERE 1=1{scope_where_write} "
                        f"SET n.{prop_key} = $val",
                        write_params,
                    )
                    counts["rewritten"] += 1
                except Exception as e:  # noqa: BLE001
                    counts["failed"] += 1
                    logger.warning(
                        "migrate_list_properties failed for item_id=%s key=%s: %s",
                        item_id, prop_key, e,
                    )
        return counts

    def search_nodes_by_type_or_tag(self, type_or_tag: str, is_global: bool = False) -> List[Dict[str, Any]]:
        """Search for nodes by type OR tag using proper Cypher OR logic.

        This replaces the MongoDB-style {"$or": [{"type": x}, {"tags": x}]} pattern.

        Args:
            type_or_tag: The type or tag value to search for
            is_global: Whether to search globally or scope to user/workspace

        Returns:
            List of node dictionaries matching the query
        """
        clauses = []
        params = {"type_or_tag": type_or_tag}

        # Match either type equality, tags-scalar equality (legacy rows
        # where tags was stored as JSON string), or tags-array membership
        # (CORE-CRUD-LIST-DESERIALIZE-1 native-array storage).
        # FalkorDB errors on `$v IN <non-list>`, so the array branch is
        # evaluated via UNION rather than OR to keep type-compatibility.
        # Plain equality comparisons are safe regardless of stored type.
        or_clause = "(n.type = $type_or_tag OR n.tags = $type_or_tag)"
        clauses.append(or_clause)

        # Apply Scope Provider Isolation
        if is_global:
            # Global search constraints
            user_key = self.scope_provider.get_user_isolation_key()
            clauses.append(f"(n.{user_key} IS NULL)")
            filters = self.scope_provider.get_global_search_filters()
            for k, v in filters.items():
                clauses.append(f"n.{k} = $ctx_{k}")
                params[f"ctx_{k}"] = v
        else:
            # Scoped search constraints
            filters = self.scope_provider.get_isolation_filters()
            for k, v in filters.items():
                clauses.append(f"n.{k} = $ctx_{k}")
                params[f"ctx_{k}"] = v

        where_clause = " AND ".join(clauses)
        cypher = f"MATCH (n) WHERE {where_clause} RETURN n"
        res = self._query(cypher, params)

        result = []
        for record in res:
            node = record[0]
            if hasattr(node, "properties"):
                props = codec.hydrate_and_unflatten(dict(node.properties))
            else:
                props = {k: v for k, v in vars(node).items() if not k.startswith("_") and k != "properties"}
            props.pop("is_global", None)
            result.append(props)
        return result

    def get_all_nodes(self):
        """Get all nodes in the graph."""
        query = "MATCH (n) RETURN n"
        result = self._query(query)
        nodes = []
        for record in result:
            if record and len(record) > 0:
                node = record[0]
                if hasattr(node, "properties"):
                    node_dict = codec.hydrate_and_unflatten(dict(node.properties))
                    nodes.append(node_dict)
                elif isinstance(node, dict):
                    nodes.append(codec.hydrate_and_unflatten(node))
        return nodes

    def get_edges_for_node(self, item_id: str) -> List[Dict[str, Any]]:
        """Get all edges involving a specific node.

        Returns list of dicts with normalized keys:
        {source_id, target_id, edge_type, valid_from, valid_to, created_at, properties}
        """
        query = """
        MATCH (n {item_id: $item_id})-[r]-(m)
        RETURN startNode(r).item_id as source_id, endNode(r).item_id as target_id,
               type(r) as edge_type, r
        """
        result = self._query(query, {"item_id": item_id})

        edges = []
        for record in result:
            if record and len(record) >= 4:
                source_id = record[0] if record[0] else "unknown"
                target_id = record[1] if record[1] else "unknown"
                edge_type = record[2] if record[2] else "unknown"
                edge_obj = record[3]

                edge_props = {}
                if hasattr(edge_obj, "properties"):
                    edge_props = codec.hydrate_and_unflatten(dict(edge_obj.properties))

                edges.append({
                    "source_id": source_id,
                    "target_id": target_id,
                    "edge_type": edge_type,
                    "valid_from": edge_props.get("valid_from"),
                    "valid_to": edge_props.get("valid_to"),
                    "created_at": edge_props.get("created_at"),
                    "properties": edge_props,
                })

        return edges

    # ---------- Stats helpers ----------
    def get_node_count(self) -> int:
        """Return total number of nodes in the graph."""
        try:
            res = self._query("MATCH (n) RETURN count(n)")
            if res and res[0]:
                val = res[0][0]
                try:
                    return int(val)
                except Exception:
                    # Some drivers return dict-like or typed values
                    return int(str(val))
        except Exception:
            pass
        return 0

    def get_edge_count(self) -> int:
        """Return total number of edges (relationships) in the graph."""
        try:
            res = self._query("MATCH ()-[r]->() RETURN count(r)")
            if res and res[0]:
                val = res[0][0]
                try:
                    return int(val)
                except Exception:
                    return int(str(val))
        except Exception:
            pass
        return 0

    def get_counts(self) -> Dict[str, int]:
        """Return a dict with node_count and edge_count for fast stats emission."""
        return {
            "node_count": self.get_node_count(),
            "edge_count": self.get_edge_count(),
        }

    # ---------- (De)Serialization ----------

    def serialize(self) -> Any:
        nodes_res = self._query("MATCH (n) RETURN n")
        edges_res = self._query("MATCH (a)-[r]->(b) RETURN a.item_id, b.item_id, type(r), r")
        nodes = []
        for rec in nodes_res:
            node = rec[0]
            if hasattr(node, "properties"):
                props = dict(node.properties)
            else:
                props = dict(zip(node.keys(), node.values(), strict=False))  # type: ignore[index]
            nodes.append(codec.hydrate_and_unflatten(props))
        edges = []
        for src, tgt, etype, rel in edges_res:
            if hasattr(rel, "properties"):
                eprops = codec.hydrate_and_unflatten(dict(rel.properties))
            elif isinstance(rel, dict):
                eprops = codec.hydrate_and_unflatten(rel)
            else:
                eprops = {}
            edges.append(
                {
                    "source": src,
                    "target": tgt,
                    "type": etype,
                    "properties": eprops,
                }
            )
        return {"nodes": nodes, "edges": edges}

    def deserialize(self, data: Any):
        self.clear()
        for node in data.get("nodes", []):
            item_id = node.pop("item_id")
            self.add_node(item_id, node)
        for edge in data.get("edges", []):
            self.add_edge(edge["source"], edge["target"], edge["type"], edge.get("properties") or {})

    def find_entity_by_canonical_key(
        self,
        canonical_key: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Find an existing entity node by its canonical key.

        Used for cross-memory entity resolution - if an entity with the same
        canonical key exists, we link to it instead of creating a duplicate.

        Args:
            canonical_key: Normalized key like "john smith|person"

        Returns:
            Entity node dict with item_id and properties, or None if not found
        """
        # Build query with scope isolation filters
        filters = ["n.canonical_key = $canonical_key"]
        params = {"canonical_key": canonical_key}

        # Apply scope provider isolation
        isolation_filters = self.scope_provider.get_isolation_filters()
        for k, v in isolation_filters.items():
            filters.append(f"n.{k} = $ctx_{k}")
            params[f"ctx_{k}"] = v

        where_clause = " AND ".join(filters)

        # Search across all entity labels (we don't know the exact type)
        query = f"""
            MATCH (n)
            WHERE {where_clause}
            RETURN n.item_id AS item_id, n AS props
            LIMIT 1
        """

        try:
            result = self._query(query, params)
            # _query() returns a plain list, not an object with .result_set
            if result:
                row = result[0]
                return {
                    "item_id": row[0],
                    "properties": dict(row[1].properties) if hasattr(row[1], "properties") else {},
                }
        except Exception as e:
            logger.debug(f"Entity lookup failed for {canonical_key}: {e}")

        return None

    def add_dual_node(
        self,
        item_id: str,
        memory_properties: Dict[str, Any],
        memory_type: str,
        entity_nodes: List[Dict[str, Any]] = None,
        is_global: bool = False,
    ):
        """
        Add a dual-node structure: one memory node + related entity nodes.

        Args:
            item_id: Unique identifier for the memory node
            memory_properties: Properties for the memory node (content, metadata, etc.)
            memory_type: Memory type for the memory node label (semantic, episodic, etc.)
            entity_nodes: List of entity node dicts with {entity_type, properties, relationships}
            is_global: Whether nodes are global or user-scoped

        Returns:
            Dict with creation results and node IDs

        .. warning::
            This operation is NOT atomic in FalkorDB as it executes multiple sequential queries.
            If an error occurs midway, the graph may be left in an inconsistent state (e.g., memory node created but entities missing).
        """
        # Note: FalkorDB executes queries sequentially (no multi-statement transactions).
        # This is acceptable for now - failures are rare and can be cleaned up.

        # Prepare memory node
        memory_label = sanitize_label(memory_type.capitalize())
        memory_props = flatten_dict(memory_properties)

        # Apply scope provider logic
        if not is_global:
            write_ctx = self.scope_provider.get_write_context()
            memory_props.update(write_ctx)

        memory_props["is_global"] = is_global

        # Build transaction query for atomic dual-node creation
        queries = []
        params = {"memory_id": item_id}

        # 1. Create memory node
        memory_set_clauses = []
        for key, value in memory_props.items():
            if self._is_valid_property(key, value):
                param_key = f"mem_{key}"
                memory_set_clauses.append(f"m.{key} = ${param_key}")
                params[param_key] = self._serialize_value(value)

        if memory_set_clauses:
            memory_query = f"MERGE (m:{memory_label} {{item_id: $memory_id}}) SET {', '.join(memory_set_clauses)}"
        else:
            memory_query = f"MERGE (m:{memory_label} {{item_id: $memory_id}})"
        queries.append(memory_query)

        # 2. Process entity nodes with cross-memory resolution
        entity_ids = []
        resolved_entities = []  # Track which entities were resolved vs created
        entity_id_map = {}  # Map index to actual entity_id for relationship creation

        if entity_nodes:
            for i, entity_node in enumerate(entity_nodes):
                entity_type = entity_node.get("entity_type", "Entity")
                entity_props = entity_node.get("properties") or {}
                entity_relationships = entity_node.get("relations", [])
                entity_name = entity_props.get("name") or entity_props.get("content", "")

                # Generate canonical key for entity resolution
                canonical_key = entity_props.get("canonical_key")
                if not canonical_key and entity_name:
                    canonical_key = get_canonical_key(entity_name, entity_type)

                logger.info(
                    f"Entity resolution: name='{entity_name}', type='{entity_type}', canonical_key='{canonical_key}'"
                )

                # Try to find existing entity with same canonical key (uses scope_provider for isolation)
                existing_entity = None
                if canonical_key:
                    existing_entity = self.find_entity_by_canonical_key(canonical_key)
                    logger.info(f"Entity lookup result for '{canonical_key}': {existing_entity}")

                if existing_entity:
                    # Reuse existing entity - just link to it
                    entity_id = existing_entity["item_id"]
                    entity_ids.append(entity_id)
                    entity_id_map[i] = entity_id
                    resolved_entities.append(
                        {"index": i, "entity_id": entity_id, "resolved": True, "canonical_key": canonical_key}
                    )
                    logger.debug(f"Resolved entity '{entity_name}' to existing node {entity_id}")

                    # Create MENTIONED_IN relationship from existing entity to new memory
                    # This links the entity to all memories that mention it
                    link_query = f"""
                        MATCH (m:{memory_label} {{item_id: $memory_id}}), (e {{item_id: $existing_entity_id}})
                        MERGE (m)-[r1:CONTAINS_ENTITY]->(e) ON CREATE SET r1.origin = 'enricher:entity_ruler', r1.confidence = 0.8
                        MERGE (e)-[r2:MENTIONED_IN]->(m) ON CREATE SET r2.origin = 'enricher:entity_ruler', r2.confidence = 0.8
                    """
                    params[f"existing_entity_id_{i}"] = entity_id
                    # Execute this after memory node is created

                    # CORE-EVENT-EXTRACT-1: accumulate eligible properties onto existing entity
                    accum_cfg = self._accumulation_config
                    if accum_cfg and accum_cfg.enabled:
                        _session_id = _current_session_id_var.get("")
                        for _prop in accum_cfg.accumulate_properties:
                            _val = entity_props.get(_prop)
                            if _val is not None:
                                _vals = _val if isinstance(_val, (list, tuple)) else [_val]
                                for _v in _vals:
                                    try:
                                        self.accumulate_property(entity_id, _prop, _v, session_id=_session_id)
                                    except Exception as _exc:
                                        logger.warning(
                                            "accumulate_property failed for %s.%s: %s",
                                            entity_id, _prop, _exc,
                                        )

                else:
                    # Create new entity node
                    entity_id = f"{item_id}_entity_{i}"
                    entity_ids.append(entity_id)
                    entity_id_map[i] = entity_id
                    entity_label = sanitize_label(normalize_entity_type(entity_type).capitalize())

                    resolved_entities.append(
                        {"index": i, "entity_id": entity_id, "resolved": False, "canonical_key": canonical_key}
                    )

                    # Add user context to entity via scope provider
                    if not is_global:
                        write_ctx = self.scope_provider.get_write_context()
                        entity_props.update(write_ctx)

                    entity_props["is_global"] = is_global
                    entity_props["canonical_key"] = canonical_key  # Store for future resolution
                    entity_props["node_category"] = "entity"  # CORE-20: explicit for Cypher WHERE matching
                    # LOCAL-PARITY-TEST-1 post-P5: SQLite's add_dual_node stores
                    # memory_type="entity" and content=entity_name on the node so
                    # get_all_nodes() returns a consistent shape across backends.
                    # The Cypher label is the specific entity type (Person,
                    # Organization, …); the memory_type property is the generic
                    # tag consumers filter by; content mirrors name for parity.
                    entity_props["memory_type"] = "entity"
                    if entity_name and not entity_props.get("content"):
                        entity_props["content"] = entity_name

                    # Build entity creation query
                    entity_set_clauses = []
                    for key, value in entity_props.items():
                        if self._is_valid_property(key, value):
                            param_key = f"ent_{i}_{key}"
                            entity_set_clauses.append(f"e{i}.{key} = ${param_key}")
                            params[param_key] = self._serialize_value(value)

                    params[f"entity_id_{i}"] = entity_id

                    if entity_set_clauses:
                        entity_query = f"MERGE (e{i}:{entity_label} {{item_id: $entity_id_{i}}}) SET {', '.join(entity_set_clauses)}"
                    else:
                        entity_query = f"MERGE (e{i}:{entity_label} {{item_id: $entity_id_{i}}})"
                    queries.append(entity_query)

                    # Create bidirectional relationships using MATCH to find the
                    # already-created nodes.  Bare CREATE (m)-[:R]->(e) in a
                    # standalone query would create *new* anonymous nodes because
                    # variable bindings don't persist across separate query() calls.
                    queries.append(
                        f"MATCH (m:{memory_label} {{item_id: $memory_id}}), "
                        f"(e {{item_id: $entity_id_{i}}}) "
                        f"CREATE (m)-[:CONTAINS_ENTITY {{origin: 'enricher:entity_ruler', confidence: 0.8}}]->(e)"
                    )
                    queries.append(
                        f"MATCH (e {{item_id: $entity_id_{i}}}), "
                        f"(m:{memory_label} {{item_id: $memory_id}}) "
                        f"CREATE (e)-[:MENTIONED_IN {{origin: 'enricher:entity_ruler', confidence: 0.8}}]->(m)"
                    )

                # Store relationships for later (after all entities processed)
                entity_node["_relationships"] = entity_relationships
                entity_node["_index"] = i

            # Create semantic relationships between entities (using resolved IDs).
            # Use MERGE to safely handle both new and resolved (deduplicated) entities —
            # resolved entities may already have this edge from a prior ingestion.
            for entity_node in entity_nodes:
                i = entity_node.get("_index", 0)
                for rel in entity_node.get("_relationships", []):
                    target_idx = rel.get("target_index")
                    rel_type = rel.get("relation_type", "RELATED")
                    if target_idx is not None and target_idx in entity_id_map:
                        source_eid = entity_id_map[i]
                        target_eid = entity_id_map[target_idx]
                        rel_param_src = f"rel_src_{i}_{target_idx}"
                        rel_param_tgt = f"rel_tgt_{i}_{target_idx}"
                        params[rel_param_src] = source_eid
                        params[rel_param_tgt] = target_eid
                        queries.append(
                            f"MATCH (a {{item_id: ${rel_param_src}}}), "
                            f"(b {{item_id: ${rel_param_tgt}}}) "
                            f"MERGE (a)-[:{rel_type}]->(b)"
                        )

        # Create memory node first with all properties
        # Note: The logic below duplicates the queries list building above.
        # The original code had a confusing double-block structure (queries append vs memory_query direct execution?).
        # Ah, I see the original code builds 'queries' list but then seems to have a secondary block
        # starting at line 783 "Create memory node first with all properties" which re-does memory params.
        # This looks like dead code or a merge artifact in the original file.
        # I will stick to the first block which builds 'queries'.
        # Wait, the original code effectively ignored 'queries' list execution?
        # No, looking at the end of the file (which I can't see all of), it probably executes 'queries'.
        # But there is a block at 783 that rebuilds memory params.
        # Let's assume the first block is the correct one for the transaction.

        # Execute queries sequentially
        if queries:
            for q in queries:
                self._query(q, params)

        # Link resolved entities to the new memory node
        for resolved in resolved_entities:
            if resolved["resolved"]:
                link_query = f"""
                    MATCH (m:{memory_label} {{item_id: $memory_id}}), (e {{item_id: $resolved_entity_id}})
                    MERGE (m)-[r1:CONTAINS_ENTITY]->(e) ON CREATE SET r1.origin = 'enricher:entity_ruler', r1.confidence = 0.8
                    MERGE (e)-[r2:MENTIONED_IN]->(m) ON CREATE SET r2.origin = 'enricher:entity_ruler', r2.confidence = 0.8
                """
                self._query(link_query, {"memory_id": item_id, "resolved_entity_id": resolved["entity_id"]})
                logger.info(f"Linked existing entity {resolved['entity_id']} to memory {item_id}")

        # Log resolution stats
        new_count = sum(1 for e in resolved_entities if not e["resolved"])
        resolved_count = sum(1 for e in resolved_entities if e["resolved"])
        if resolved_count > 0:
            logger.info(f"Entity resolution: {new_count} new, {resolved_count} resolved to existing")

        return {
            "memory_node_id": item_id,
            "entity_node_ids": entity_ids,
            "resolved_entities": resolved_entities,
            "memory_type": memory_type,
            "entity_count": len(entity_ids),
            "new_entity_count": new_count,
            "resolved_entity_count": resolved_count,
        }

    def _is_valid_property(self, key: str, value: Any) -> bool:
        """Check if a property is valid for FalkorDB storage."""
        if value is None or key == "embedding":
            return False
        if isinstance(value, str) and value == "":
            return False
        # All other values are acceptable; the codec picks the storage shape.
        return isinstance(value, (str, int, float, bool, list, tuple, dict)) or hasattr(
            value, "isoformat"
        )

    def _serialize_value(self, value: Any, key: str = "<unknown>") -> Any:
        """Serialize a value for FalkorDB storage via the shared codec.

        See ``smartmemory/graph/backends/codec.py`` and the
        CORE-CRUD-LIST-DESERIALIZE-1 design doc.
        """
        return codec.serialize_value(value, key=key)
