"""Async SQLite backend — placeholder that raises through the unsupported registry.

There is no async SQLite counterpart to ``AsyncFalkorDBBackend`` yet. Before this
file existed, callers who tried ``from smartmemory.graph.backends import
AsyncSQLiteBackend`` got an ``ImportError`` — an *implicit* gap with no tracking
or consistent message. This module replaces that implicit gap with an explicit
one: construction raises ``UnsupportedBackendError`` pointing at the
``UNSUPPORTED`` registry, so the capability gap is enforced in production code
rather than existing only in docs and tests.

When an async SQLite implementation ships, (1) replace this file with the real
class, and (2) remove ``"async_operations"`` from
``UNSUPPORTED[BackendKind.SQLITE]`` in ``smartmemory.backends.unsupported``.
"""
from __future__ import annotations

from smartmemory.backends.unsupported import BackendKind, UnsupportedBackendError


class AsyncSQLiteBackend:
    """Deliberately-unimplemented stub.

    Instantiation raises ``UnsupportedBackendError`` with a pointer to the
    registered capability gap. Do not subclass; replace with a real
    implementation when shipping async SQLite support.
    """

    def __init__(self, *args, **kwargs):
        raise UnsupportedBackendError(
            BackendKind.SQLITE,
            "async_operations",
            reason=(
                "No AsyncSQLiteBackend implementation yet. "
                "This capability is tracked in smartmemory.backends.unsupported.UNSUPPORTED. "
                "Use FalkorDBBackend + AsyncFalkorDBBackend for async, or use the sync "
                "SQLiteBackend via create_lite_memory() for local mode."
            ),
        )
