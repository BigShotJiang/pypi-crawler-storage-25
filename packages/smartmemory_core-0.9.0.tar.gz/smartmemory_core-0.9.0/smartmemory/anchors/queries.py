"""Read-only query helpers for CORE-GAPS-1 anchors.

Follows the PlanQueries pattern: direct SQLite for INDEXED types,
search fallback for FalkorDB.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from smartmemory.smart_memory import SmartMemory

logger = logging.getLogger(__name__)


class AnchorQueries:
    """Read-only queries for anchor items."""

    def __init__(self, memory: SmartMemory) -> None:
        self.memory = memory

    def get_active(
        self, session_id: str, anchor_type: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """Get active anchors for a session.

        Args:
            session_id: Session scope.
            anchor_type: Optional filter (spec, scope, decision, constraint).

        Returns:
            List of anchor dicts with keys: anchor_id, content, anchor_type,
            session_id, status, created_at.
        """
        backend = self.memory._graph.backend

        from smartmemory.graph.backends.sqlite import SQLiteBackend
        if isinstance(backend, SQLiteBackend):
            return self._get_active_sqlite(backend, session_id, anchor_type)
        return self._get_active_search_fallback(session_id, anchor_type)

    def get_all_active(
        self, anchor_type: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """Get every active anchor across all sessions.

        Added for cross-session reconciliation workers (e.g. the
        ``AnchorReconciliationEvolver``). Mirrors ``get_needs_review``'s
        session_id=None semantics but filters on ``anchor_status='active'``.

        Args:
            anchor_type: Optional filter (spec, scope, decision, constraint).

        Returns:
            List of anchor dicts matching the same shape as ``get_active``.
        """
        backend = self.memory._graph.backend

        from smartmemory.graph.backends.sqlite import SQLiteBackend
        if isinstance(backend, SQLiteBackend):
            return self._get_all_active_sqlite(backend, anchor_type)
        return self._get_all_active_search_fallback(anchor_type)

    def get_needs_review(
        self, session_id: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """Get anchors that have been flagged as needs_review after critical drift.

        Args:
            session_id: Optional session scope. If None, returns all needs_review
                anchors regardless of session.

        Returns:
            List of anchor dicts with keys: anchor_id, content, anchor_type,
            session_id, status, created_at. Status will be "needs_review".
        """
        backend = self.memory._graph.backend

        from smartmemory.graph.backends.sqlite import SQLiteBackend
        if isinstance(backend, SQLiteBackend):
            return self._get_needs_review_sqlite(backend, session_id)
        return self._get_needs_review_search_fallback(session_id)

    def get_by_id(self, anchor_id: str) -> Optional[dict[str, Any]]:
        """Get a single anchor by ID."""
        item = self.memory.get(anchor_id)
        if item is None:
            return None
        if getattr(item, "memory_type", None) != "anchor":
            return None
        return self._to_dict(item)

    # -- SQLite path --

    def _get_active_sqlite(
        self, backend: Any, session_id: str, anchor_type: Optional[str]
    ) -> list[dict[str, Any]]:
        """Direct SQLite query for active anchors."""
        sql = (
            "SELECT item_id, properties FROM nodes "
            "WHERE memory_type = 'anchor' "
            "AND json_extract(properties, '$.anchor_status') = 'active' "
            "AND json_extract(properties, '$.anchor_session') = ?"
        )
        params: list[Any] = [session_id]

        if anchor_type:
            sql += " AND json_extract(properties, '$.anchor_type') = ?"
            params.append(anchor_type)

        with backend._lock:
            rows = backend._conn.execute(sql, params).fetchall()

        return [self._row_to_dict(row) for row in rows]

    # -- Search fallback --

    def _get_active_search_fallback(
        self, session_id: str, anchor_type: Optional[str]
    ) -> list[dict[str, Any]]:
        """Fallback using graph.search_nodes() for non-SQLite backends.

        INDEXED types have no embeddings, so memory.search() is unreliable.
        Use direct property-equality queries on the graph backend instead.
        """
        query: dict[str, Any] = {
            "memory_type": "anchor",
            "anchor_status": "active",
            "anchor_session": session_id,
        }
        if anchor_type:
            query["anchor_type"] = anchor_type

        try:
            rows = self.memory._graph.backend.search_nodes(query)
        except Exception as e:
            logger.warning(f"FalkorDB anchor query failed: {e}")
            return []

        return [self._node_to_dict(row) for row in rows]

    # -- all-active path --

    def _get_all_active_sqlite(
        self, backend: Any, anchor_type: Optional[str]
    ) -> list[dict[str, Any]]:
        """Cross-session active-anchor query via SQLite."""
        sql = (
            "SELECT item_id, properties FROM nodes "
            "WHERE memory_type = 'anchor' "
            "AND json_extract(properties, '$.anchor_status') = 'active'"
        )
        params: list[Any] = []
        if anchor_type:
            sql += " AND json_extract(properties, '$.anchor_type') = ?"
            params.append(anchor_type)

        with backend._lock:
            rows = backend._conn.execute(sql, params).fetchall()

        return [self._row_to_dict(row) for row in rows]

    def _get_all_active_search_fallback(
        self, anchor_type: Optional[str]
    ) -> list[dict[str, Any]]:
        """Cross-session active-anchor query via graph search fallback."""
        query: dict[str, Any] = {
            "memory_type": "anchor",
            "anchor_status": "active",
        }
        if anchor_type:
            query["anchor_type"] = anchor_type

        try:
            rows = self.memory._graph.backend.search_nodes(query)
        except Exception as e:
            logger.warning(f"FalkorDB all-active anchor query failed: {e}")
            return []

        return [self._node_to_dict(row) for row in rows]

    # -- needs_review path --

    def _get_needs_review_sqlite(
        self, backend: Any, session_id: Optional[str]
    ) -> list[dict[str, Any]]:
        """Direct SQLite query for needs_review anchors."""
        sql = (
            "SELECT item_id, properties FROM nodes "
            "WHERE memory_type = 'anchor' "
            "AND json_extract(properties, '$.anchor_status') = 'needs_review'"
        )
        params: list[Any] = []

        if session_id is not None:
            sql += " AND json_extract(properties, '$.anchor_session') = ?"
            params.append(session_id)

        with backend._lock:
            rows = backend._conn.execute(sql, params).fetchall()

        return [self._row_to_dict(row) for row in rows]

    def _get_needs_review_search_fallback(
        self, session_id: Optional[str]
    ) -> list[dict[str, Any]]:
        """Fallback using graph.search_nodes() for non-SQLite backends."""
        query: dict[str, Any] = {
            "memory_type": "anchor",
            "anchor_status": "needs_review",
        }
        if session_id is not None:
            query["anchor_session"] = session_id

        try:
            rows = self.memory._graph.backend.search_nodes(query)
        except Exception as e:
            logger.warning(f"FalkorDB needs_review anchor query failed: {e}")
            return []

        return [self._node_to_dict(row) for row in rows]

    def _node_to_dict(self, node: dict[str, Any]) -> dict[str, Any]:
        """Convert a graph node dict to anchor dict."""
        return {
            "anchor_id": node.get("item_id", ""),
            "content": node.get("content", ""),
            "anchor_type": node.get("anchor_type", "spec"),
            "session_id": node.get("anchor_session", ""),
            "status": node.get("anchor_status", "active"),
            "created_at": node.get("transaction_time", ""),
            "drift_score": node.get("drift_score"),
            "drift_detected_at": node.get("drift_detected_at"),
            "graduated_to": node.get("graduated_to"),
        }

    # -- Converters --

    def _row_to_dict(self, row: tuple) -> dict[str, Any]:
        """Convert SQLite row to anchor dict."""
        item_id, props_str = row
        props = json.loads(props_str) if props_str else {}
        return {
            "anchor_id": item_id,
            "content": props.get("content", ""),
            "anchor_type": props.get("anchor_type", "spec"),
            "session_id": props.get("anchor_session", ""),
            "status": props.get("anchor_status", "active"),
            "created_at": props.get("transaction_time", ""),
            "drift_score": props.get("drift_score"),
            "drift_detected_at": props.get("drift_detected_at"),
            "graduated_to": props.get("graduated_to"),
        }

    def _to_dict(self, item: Any) -> dict[str, Any]:
        """Convert MemoryItem to anchor dict."""
        meta = getattr(item, "metadata", {}) or {}
        return {
            "anchor_id": getattr(item, "item_id", ""),
            "content": getattr(item, "content", ""),
            "anchor_type": meta.get("anchor_type", "spec"),
            "session_id": meta.get("anchor_session", ""),
            "status": meta.get("anchor_status", "active"),
            "created_at": str(getattr(item, "transaction_time", "")),
            "drift_score": meta.get("drift_score"),
            "drift_detected_at": meta.get("drift_detected_at"),
            "graduated_to": meta.get("graduated_to"),
        }
