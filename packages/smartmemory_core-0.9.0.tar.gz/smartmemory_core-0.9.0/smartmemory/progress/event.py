"""ProgressEvent dataclass — wire format for the unified progress event bus.

Matches progress-event-contract.json exactly. No Pydantic (per dependency policy).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

# Status values declared in progress-event-contract.json → ProgressEvent.status.enum.
# This set is the single in-code reference; contract test asserts parity.
_VALID_STATUSES = frozenset({"started", "progress", "ok", "warn", "error"})


@dataclass(frozen=True)
class ProgressEvent:
    """Frozen dataclass matching ProgressEvent in progress-event-contract.json.

    Fields
    ------
    run_id   : Parent operation UUID string (uuid format).
    scope    : Subscription + tenancy key, e.g. "workspace:<id>".
    seq      : Monotonic integer per run_id. Clients order and dedupe on this.
    ts       : Server epoch seconds at emission time.
    kind     : Dotted kind tag, e.g. "pipeline.stage". Producer-owned.
    stage    : Pipeline stage name if applicable. Optional; omitted from wire form when None.
    status   : One of: started | progress | ok | warn | error.
    payload  : Kind-specific data dict. Untyped at transport layer.
    """

    run_id: str
    scope: str
    seq: int
    ts: float
    kind: str
    stage: Optional[str]
    status: str
    payload: dict

    def __post_init__(self) -> None:
        if self.status not in _VALID_STATUSES:
            raise ValueError(
                f"Invalid status {self.status!r}. "
                f"Must be one of: {sorted(_VALID_STATUSES)}"
            )

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Produce the JSON-serializable wire dict.

        None values for optional fields are omitted so the wire form is clean.
        The payload dict is included as-is (caller is responsible for serializability).
        """
        d: dict = {
            "run_id": self.run_id,
            "scope": self.scope,
            "seq": self.seq,
            "ts": self.ts,
            "kind": self.kind,
            "status": self.status,
            "payload": self.payload,
        }
        if self.stage is not None:
            d["stage"] = self.stage
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "ProgressEvent":
        """Reconstruct a ProgressEvent from a wire dict (exact round-trip).

        Optional fields absent from the dict are treated as None.
        """
        return cls(
            run_id=d["run_id"],
            scope=d["scope"],
            seq=int(d["seq"]),
            ts=float(d["ts"]),
            kind=d["kind"],
            stage=d.get("stage"),
            status=d["status"],
            payload=d["payload"],
        )
