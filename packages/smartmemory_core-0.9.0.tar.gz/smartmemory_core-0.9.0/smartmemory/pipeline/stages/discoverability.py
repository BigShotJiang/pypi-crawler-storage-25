"""Discoverability scoring stage (SELF-IMPROVE-2).

Computes a structural quality score [0.0, 1.0] for a memory item after
LinkStage, writes it via update_properties(), and emits a WARNING for
items unlikely to be found via any search channel.

This is a *pre-enrichment* structural proxy: it measures extraction quality
(entity linkage, relation coverage, grounding success, content length,
metadata richness) at the point the NLP pipeline has finished. Relations added
by EnrichStage are not captured — see design doc for rationale.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING

from smartmemory.pipeline.state import PipelineState

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig

logger = logging.getLogger(__name__)


@dataclass
class DiscoverabilityConfig:
    enabled: bool = True
    low_threshold: float = 0.4
    weights: dict = field(
        default_factory=lambda: {
            "entity_linkage": 0.3,
            "relation_coverage": 0.2,
            "resolution": 0.2,
            "content_length": 0.15,
            "metadata_richness": 0.15,
        }
    )


class DiscoverabilityStage:
    """Compute and persist a discoverability score after linking.

    Constructor injection follows the same pattern as StoreStage — accepts a
    SmartMemory instance so it can call update_properties().
    """

    # Rate-limiting counters (class-level so they accumulate across calls in a
    # single process — intentional for bulk-ingestion noise reduction).
    _low_score_count: int = 0

    # Metadata fields considered for the richness score.
    _RICHNESS_FIELDS: tuple[str, ...] = ("tags", "origin", "memory_type", "source")

    def __init__(self, memory) -> None:
        """Args: memory — a SmartMemory instance."""
        self._memory = memory

    @property
    def name(self) -> str:
        return "discoverability"

    # ------------------------------------------------------------------
    # StageCommand protocol
    # ------------------------------------------------------------------

    def execute(self, state: PipelineState, config: PipelineConfig) -> PipelineState:
        from smartmemory.observability.tracing import trace_span

        disc_config: DiscoverabilityConfig = getattr(config, "discoverability", None) or DiscoverabilityConfig()

        if not disc_config.enabled:
            return state

        if config.mode == "preview":
            return state

        if not state.item_id:
            logger.debug("DiscoverabilityStage skipped: no item_id in state")
            return state

        # --- gather inputs ---
        entity_count = len(state.entities or [])
        relation_count = len(state.relations or [])
        unresolved_count = len(state.unresolved_entities or [])
        content = state.resolved_text or state.text or ""
        metadata = state.raw_metadata or {}

        # --- compute components ---
        w = disc_config.weights
        entity_score = _score_entity_linkage(entity_count)
        relation_score = _score_relation_coverage(relation_count)
        resolution_score = _score_resolution(entity_count, unresolved_count)
        length_score = _score_content_length(len(content))
        richness_score = _score_metadata_richness(metadata, self._RICHNESS_FIELDS)

        score = round(
            w["entity_linkage"] * entity_score
            + w["relation_coverage"] * relation_score
            + w["resolution"] * resolution_score
            + w["content_length"] * length_score
            + w["metadata_richness"] * richness_score,
            3,
        )
        # Clamp to [0.0, 1.0] to guard against weight misconfiguration
        score = max(0.0, min(1.0, score))

        span_attrs = {
            "item_id": state.item_id,
            "score": score,
            "entity_count": entity_count,
            "relation_count": relation_count,
            "unresolved_count": unresolved_count,
            "entity_score": entity_score,
            "relation_score": relation_score,
            "resolution_score": resolution_score,
            "length_score": length_score,
            "richness_score": richness_score,
        }

        with trace_span("pipeline.discoverability", span_attrs):
            if score < disc_config.low_threshold:
                DiscoverabilityStage._low_score_count += 1
                count = DiscoverabilityStage._low_score_count
                if count <= 10 or count % 100 == 0:
                    logger.warning(
                        "Low discoverability (%.2f) for item %s "
                        "[%d total low-score items] — "
                        "entities=%d, relations=%d, unresolved=%d",
                        score,
                        state.item_id,
                        count,
                        entity_count,
                        relation_count,
                        unresolved_count,
                    )

        # Write score to graph node (one extra ~2 ms write)
        persisted = False
        try:
            self._memory.update_properties(state.item_id, {"discoverability_score": score})
            persisted = True
        except Exception as exc:
            logger.warning(
                "Failed to write discoverability_score for item %s: %s",
                state.item_id,
                exc,
            )

        # Only expose score in pipeline context if it was actually persisted —
        # prevents downstream consumers from acting on a score that never reached storage.
        if persisted:
            return replace(state, _context={**(state._context or {}), "discoverability_score": score})
        return state

    def undo(self, state: PipelineState) -> PipelineState:
        return state


# ---------------------------------------------------------------------------
# Scoring helpers
# ---------------------------------------------------------------------------


def _score_entity_linkage(entity_count: int) -> float:
    """Tiered entity score: 0 → 0.0; 1-2 → 0.4; 3-4 → 0.7; 5+ → 1.0."""
    if entity_count == 0:
        return 0.0
    if entity_count <= 2:
        return 0.4
    if entity_count <= 4:
        return 0.7
    return 1.0


def _score_relation_coverage(relation_count: int) -> float:
    """min(1.0, relation_count / 3) — 3+ relations = full coverage."""
    return min(1.0, relation_count / 3)


def _score_resolution(entity_count: int, unresolved_count: int) -> float:
    """1.0 - (unresolved / total); 1.0 when no entities (nothing to resolve)."""
    if entity_count == 0:
        return 1.0
    return 1.0 - (unresolved_count / entity_count)


def _score_content_length(char_count: int) -> float:
    """< 20 chars → 0.2; 20-500 → linear; > 500 → 1.0."""
    if char_count < 20:
        return 0.2
    if char_count >= 500:
        return 1.0
    return char_count / 500


def _score_metadata_richness(metadata: dict, fields: tuple[str, ...]) -> float:
    """Fraction of richness fields present in metadata."""
    if not fields:
        return 1.0
    present = sum(1 for f in fields if metadata.get(f))
    return present / len(fields)
