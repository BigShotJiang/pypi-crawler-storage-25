"""Alias link stage — create ALIAS_OF edges from coreference chains (CORE-ENTITY-RESOLVE-1).

Runs after LinkStage. Reads coreference chains stored in pipeline context by
CoreferenceStageCommand, creates alias stub nodes (node_category='alias') for
non-pronoun mentions, and connects them to canonical entity nodes via ALIAS_OF edges.

Alias stubs share memory_type='entity' for FalkorDB labeling but are distinguished
from canonical entities by node_category='alias'. Every entity query must exclude
them with AND node_category <> 'alias'.
"""

from __future__ import annotations

import hashlib
import logging
from typing import TYPE_CHECKING

from smartmemory.pipeline.state import PipelineState

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig

logger = logging.getLogger(__name__)

# Pronouns and generic spans that must not become alias nodes
_DEFAULT_STOPLIST = {
    "he", "she", "they", "it", "this", "that",
    "the company", "the organization", "the team",
    "the group", "the person",
    "him", "her", "them", "his", "its", "their",
    "who", "whom", "whose",
}


class AliasLinkStage:
    """Create alias stub nodes and ALIAS_OF edges from coreference chains."""

    def __init__(self, graph, entity_resolve_config=None):
        # graph is a SmartGraph instance; use graph.backend for direct add_node/add_edge
        self._graph = graph
        # Accept injected config; import lazily to avoid circular deps
        if entity_resolve_config is None:
            from smartmemory.search.entity_resolve import EntityResolveConfig
            entity_resolve_config = EntityResolveConfig()
        self._config = entity_resolve_config

    @property
    def name(self) -> str:
        return "alias_link"

    def execute(self, state: PipelineState, config: "PipelineConfig") -> PipelineState:
        if config.mode == "preview":
            return state

        if not self._config.enabled:
            return state

        # Read coreference chains from context (stored by CoreferenceStageCommand)
        coref_result = state._context.get("coreference_result", {})
        chains = coref_result.get("chains", [])
        if not chains:
            return state

        entity_ids = state.entity_ids or {}
        if not entity_ids:
            return state

        min_chain_length = self._config.min_chain_length
        stoplist = self._config.alias_stoplist

        aliases_created = 0
        for chain in chains:
            head = chain.get("head", "")
            mentions = chain.get("mentions", [])

            if len(mentions) < min_chain_length:
                continue

            # Find canonical entity node ID (case-insensitive match against extracted entities)
            canonical_id = _find_canonical_id(head, entity_ids)
            if not canonical_id:
                continue

            for mention in mentions:
                if not _is_valid_alias(mention, head, stoplist):
                    continue

                alias_id = _make_alias_id(mention, canonical_id)
                try:
                    self._graph.backend.add_node(
                        item_id=alias_id,
                        properties={
                            "name": mention,
                            "content": mention,
                            "node_category": "alias",
                            "source": "coreference",
                        },
                        memory_type="entity",
                    )
                    self._graph.backend.add_edge(
                        source_id=alias_id,
                        target_id=canonical_id,
                        edge_type="ALIAS_OF",
                        properties={
                            "source": "coreference",
                            "chain_length": len(mentions),
                            "origin": "enricher:alias_link",
                        },
                    )
                    aliases_created += 1
                except Exception as exc:
                    logger.warning(
                        "Failed to create alias '%s' -> '%s': %s",
                        mention,
                        head,
                        exc,
                    )

        if aliases_created:
            logger.info(
                "Created %d alias nodes/edges for item %s",
                aliases_created,
                state.item_id,
            )

        return state

    def undo(self, state: PipelineState) -> PipelineState:
        # Graph side effects only — no PipelineState fields to undo
        return state


def _find_canonical_id(head: str, entity_ids: dict) -> str | None:
    """Case-insensitive lookup of head mention in entity_ids map."""
    if head in entity_ids:
        return entity_ids[head]
    head_lower = head.lower()
    for name, node_id in entity_ids.items():
        if name.lower() == head_lower:
            return node_id
    return None


_ARTICLE_PREFIXES = {"the", "a", "an"}


def _is_valid_alias(mention: str, head: str, stoplist: set) -> bool:
    """Filter alias candidates per design doc criteria.

    Returns False for:
    - Identity (same text as canonical head)
    - Stoplist entries (pronouns, generic spans)
    - Single characters
    - Tokens with no uppercase letter AND not multi-word (rejects lowercase common nouns)
    - Generic noun phrases: "the/a/an + single word" (e.g. "the boss", "a client")
    """
    # Skip identity
    if mention.lower() == head.lower():
        return False
    # Skip stoplist
    if mention.lower() in stoplist:
        return False
    # Skip single characters
    if len(mention) < 2:
        return False
    # Skip generic article + noun phrases ("the boss", "a client", "an employee")
    # but allow proper nouns ("The Rock", "The Hague") where the second word is capitalized
    words = mention.split()
    if len(words) == 2 and words[0].lower() in _ARTICLE_PREFIXES and words[1][0].islower():
        return False
    # Must have uppercase letter OR be multi-word (proper noun heuristic)
    if not any(c.isupper() for c in mention) and len(mention.split()) < 2:
        return False
    return True


def _make_alias_id(mention: str, canonical_id: str) -> str:
    """Deterministic alias node ID for deduplication across ingestions."""
    return hashlib.sha256(f"alias:{mention.lower()}:{canonical_id}".encode()).hexdigest()
