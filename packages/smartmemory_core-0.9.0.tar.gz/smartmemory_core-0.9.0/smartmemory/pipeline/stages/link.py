"""Link stage — wraps Linking.link_new_item()."""

from __future__ import annotations

import hashlib
import logging
from dataclasses import replace
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from smartmemory.pipeline.state import PipelineState

if TYPE_CHECKING:
    from smartmemory.memory.pipeline.stages.linking import Linking
    from smartmemory.pipeline.config import PipelineConfig

logger = logging.getLogger(__name__)


class LinkStage:
    """Create semantic links between the new item and existing memory."""

    def __init__(self, linking: Linking):
        self._linking = linking

    @property
    def name(self) -> str:
        return "link"

    def execute(self, state: PipelineState, config: PipelineConfig) -> PipelineState:
        if config.mode == "preview":
            return state

        # Build an IngestionContext-compatible dict for the legacy Linking API
        context = {
            "item": _build_item_stub(state),
            "entity_ids": dict(state.entity_ids),
            "entities": list(state.entities),
            "relations": list(state.relations),
        }

        self._linking.link_new_item(context)

        # --- CORE-AGENT-1: Create agent self-knowledge edges ---
        try:
            scope_provider = getattr(self._linking.graph, "backend", None)
            if scope_provider:
                scope_provider = getattr(scope_provider, "scope_provider", None)

            if scope_provider and getattr(scope_provider, "user_type", None) == "agent":
                user_id = None
                # Get user_id from scope_provider methods
                write_ctx = scope_provider.get_write_context()
                user_id = write_ctx.get("user_id") or write_ctx.get("created_by")

                if user_id:
                    agent_item_id = hashlib.sha256(f"agent:{user_id}".encode()).hexdigest()
                    memory_type = state.memory_type
                    now_iso = datetime.now(timezone.utc).isoformat()

                    if memory_type == "procedural":
                        self._linking.graph.add_edge(
                            source_id=agent_item_id,
                            target_id=state.item_id,
                            edge_type="HAS_SKILL",
                            properties={
                                "domain": self._extract_domain(state),
                                "confidence": 0.7,
                                "last_used": now_iso,
                                "origin": "enricher:skill_extract",
                            },
                        )
                    elif memory_type == "decision":
                        self._linking.graph.add_edge(
                            source_id=agent_item_id,
                            target_id=state.item_id,
                            edge_type="MADE_DECISION",
                            properties={
                                "decision_type": (state.raw_metadata or {}).get("decision_type", "unknown"),
                                "origin": "enricher:decision_detect",
                                "confidence": 0.7,
                            },
                        )
                    elif memory_type == "pending":
                        self._linking.graph.add_edge(
                            source_id=agent_item_id,
                            target_id=state.item_id,
                            edge_type="HAS_CONTEXT",
                            properties={
                                "session_id": (state.raw_metadata or {}).get("session_id", ""),
                                "created_at": now_iso,
                                "origin": "enricher:context_link",
                                "confidence": 0.7,
                            },
                        )
        except Exception as e:
            logger.warning(
                "CORE-AGENT-1: Failed to create agent self-knowledge edge for item %s: %s",
                state.item_id,
                e,
            )

        # CORE-MULTI-AGENT-1: links may be a list of {source_id, target_id, edge_type} dicts
        raw_links = context.get("links")
        if isinstance(raw_links, list):
            # Convert list to dict keyed by edge_type for PipelineState.links compatibility
            links_dict = {}
            for i, link_entry in enumerate(raw_links):
                if isinstance(link_entry, dict):
                    key = f"{link_entry.get('edge_type', 'RELATED')}_{i}"
                    links_dict[key] = link_entry
            return replace(state, links=links_dict)
        return replace(state, links=raw_links or {})

    @staticmethod
    def _extract_domain(state: PipelineState) -> str:
        """Extract primary domain from pipeline state entities."""
        for entity in state.entities or []:
            if isinstance(entity, dict):
                etype = entity.get("entity_type", "")
                if etype and etype.lower() not in ("agent", "person"):
                    return etype
        return "general"

    def undo(self, state: PipelineState) -> PipelineState:
        return replace(state, links={})


def _build_item_stub(state: PipelineState):
    """Build a minimal MemoryItem-like object for legacy APIs."""
    from smartmemory.models.memory_item import MemoryItem

    return MemoryItem(
        content=state.resolved_text or state.text,
        memory_type=state.memory_type or "semantic",
        metadata=dict(state.raw_metadata),
        item_id=state.item_id,
    )
