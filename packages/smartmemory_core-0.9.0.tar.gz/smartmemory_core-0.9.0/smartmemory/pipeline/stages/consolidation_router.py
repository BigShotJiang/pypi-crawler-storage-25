"""ConsolidationRouterStage (CORE-MEMORY-DYNAMICS-1 M1a Task 3.1).

Observational router — runs between ``ontology_constrain`` and ``store``,
records a ``RouterDecision`` on ``PipelineState.router_decision``, and
lets the rest of the pipeline proceed unchanged.

In M1a the decision is *recorded only*: it does not yet gate the
``StoreStage``'s ``memory_type`` assignment.  That capability arrives in
M1b alongside the ``working`` → ``pending`` rename.
"""

from __future__ import annotations

import re
from dataclasses import replace
from typing import TYPE_CHECKING, Any, Dict, List, Pattern

from smartmemory.pipeline.router import RouterDecision, RouterStrategy

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig
    from smartmemory.pipeline.state import PipelineState


_TYPE_TO_COMMIT: Dict[str, RouterStrategy] = {
    "semantic": RouterStrategy.COMMIT_SEMANTIC,
    "episodic": RouterStrategy.COMMIT_EPISODIC,
    "procedural": RouterStrategy.COMMIT_PROCEDURAL,
    "reasoning": RouterStrategy.COMMIT_REASONING,
    # ``decision`` is not routed here — structured-schema items bypass the
    # pipeline entirely (design.md:140, 149) so the router never sees them.
}

# Upper bound of the "ambiguous" confidence band for PARALLEL_DUAL_ENCODE.
_AMBIGUOUS_BAND_TOP = 0.7

# Entity density threshold for ambiguous high-value content.
_AMBIGUOUS_ENTITY_THRESHOLD = 3


def _compile_lexicon(markers: List[str]) -> Pattern[str]:
    """Compile the imperative lexicon into a single word-bounded regex.

    Uses ``\\b`` boundaries so ``"step"`` matches ``"step X"`` and ``"a step"``
    but NOT ``"misstep"`` or ``"stepwise"``.  Markers containing trailing
    punctuation (``"first,"``, ``"then,"``) match as written; alpha-only
    markers pick up a word boundary on both sides.
    """
    # Group markers by whether they are pure word-boundary vs literal.
    alnum_markers = [m.rstrip() for m in markers if m.strip().isalpha()]
    literal_markers = [m for m in markers if not m.strip().isalpha()]

    parts: List[str] = []
    if alnum_markers:
        parts.append(r"\b(?:" + "|".join(re.escape(m) for m in alnum_markers) + r")\b")
    if literal_markers:
        parts.append("|".join(re.escape(m) for m in literal_markers))

    if not parts:
        # Empty lexicon — match nothing.
        return re.compile(r"(?!x)x")
    return re.compile("|".join(parts), re.IGNORECASE)


class ConsolidationRouterStage:
    """Rules-based v1 consolidation router (observational in M1a)."""

    @property
    def name(self) -> str:
        return "consolidation_router"

    def execute(self, state: "PipelineState", config: "PipelineConfig") -> "PipelineState":
        cfg = config.consolidation_router
        if not cfg.enabled:
            return state

        decision = self._route(state, cfg)
        return replace(state, router_decision=decision)

    def undo(self, state: "PipelineState") -> "PipelineState":
        return replace(state, router_decision=None)

    # ------------------------------------------------------------------ #
    # Routing logic
    # ------------------------------------------------------------------ #

    def _route(self, state: "PipelineState", cfg) -> RouterDecision:
        raw_metadata: Dict[str, Any] = state.raw_metadata or {}
        origin: str = (raw_metadata.get("origin") or "").strip()
        raw_confidence = raw_metadata.get("confidence")
        # Exclude booleans — in Python ``isinstance(True, (int, float))`` is
        # True, which would route ``confidence=False`` to HOLD_PENDING and
        # ``confidence=True`` as 1.0.  Treat bools as unknown (None).
        confidence = raw_confidence if (isinstance(raw_confidence, (int, float)) and not isinstance(raw_confidence, bool)) else None
        conversation_id = raw_metadata.get("conversation_id")
        memory_type = state.memory_type
        text = state.text or ""
        entities = state.entities or []

        signals: Dict[str, Any] = {
            "origin": origin,
            "confidence": confidence,
            "conversation_id": conversation_id,
            "memory_type": memory_type,
            "entities_count": len(entities),
            "classified_types": list(state.classified_types or []),
        }
        reasons: List[str] = []

        # Rule 1 — Telemetry hooks never re-append (case-insensitive — some
        # producers stamp "Hook:" despite the lowercase convention).
        if origin.lower().startswith("hook:"):
            reasons.append("telemetry_origin")
            return RouterDecision(RouterStrategy.SKIP_APPEND, 1.0, reasons, signals)

        # Rule 2 — Low-confidence items wait for reinforcement.  MUST run
        # before imperative detection so ambiguous how-to text gets pended
        # rather than compiled prematurely.
        if confidence is not None and confidence < cfg.low_confidence_threshold:
            reasons.append(f"low_confidence:{confidence}")
            if conversation_id:
                reasons.append("conversation_context")
            return RouterDecision(RouterStrategy.HOLD_PENDING, float(confidence), reasons, signals)

        # Rule 3 — Imperative markers short-circuit to procedural compilation
        # (word-bounded match prevents "misstep" → procedural false positives).
        lexicon_re = _compile_lexicon(list(cfg.imperative_lexicon or []))
        if lexicon_re.search(text):
            hits = lexicon_re.findall(text)[:3]
            reasons.append(f"imperative_markers:{hits}")
            confidence_val = float(confidence) if confidence is not None else 0.8
            return RouterDecision(RouterStrategy.COMPILE_PROCEDURAL, confidence_val, reasons, signals)

        # Rule 4 — Ambiguous band + entity density + session → dual-encode.
        if (
            confidence is not None
            and cfg.low_confidence_threshold <= confidence < _AMBIGUOUS_BAND_TOP
            and len(entities) >= _AMBIGUOUS_ENTITY_THRESHOLD
            and conversation_id
        ):
            reasons.append(
                f"ambiguous_high_value:entities={len(entities)},session={conversation_id}"
            )
            return RouterDecision(RouterStrategy.PARALLEL_DUAL_ENCODE, float(confidence), reasons, signals)

        # Rule 5 — Route by memory_type (fallback = commit_semantic).
        strategy = _TYPE_TO_COMMIT.get(memory_type or "", RouterStrategy.COMMIT_SEMANTIC)
        reasons.append(f"memory_type:{memory_type}" if memory_type else "memory_type:default_semantic")
        chosen_confidence = float(confidence) if confidence is not None else 0.7
        return RouterDecision(strategy, chosen_confidence, reasons, signals)
