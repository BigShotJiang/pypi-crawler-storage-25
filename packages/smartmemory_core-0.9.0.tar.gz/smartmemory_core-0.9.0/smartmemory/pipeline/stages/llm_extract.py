"""LLMExtract stage — extract entities and relations via LLMSingleExtractor."""

from __future__ import annotations

import logging
from dataclasses import replace
from typing import TYPE_CHECKING

from smartmemory.pipeline.state import PipelineState
from smartmemory.utils.llm import get_default_model as _default_model

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig
    from smartmemory.plugins.extractors.llm_single import LLMSingleExtractor

logger = logging.getLogger(__name__)


class LLMExtractStage:
    """Extract entities and relations using an LLM in a single call."""

    def __init__(self, extractor: LLMSingleExtractor | None = None):
        """Args: extractor — optional pre-built LLMSingleExtractor (for testing/DI)."""
        self._extractor = extractor

    @property
    def name(self) -> str:
        return "llm_extract"

    # Average tokens per extraction call — used to estimate avoided tokens on cache hit.
    _AVG_EXTRACTION_TOKENS: int = 800

    def execute(self, state: PipelineState, config: PipelineConfig) -> PipelineState:
        llm_cfg = config.extraction.llm_extract
        if not llm_cfg.enabled:
            if state.token_tracker:
                from smartmemory.pipeline.model_router import get_routed_model
                state.token_tracker.record_avoided(
                    "llm_extract",
                    self._AVG_EXTRACTION_TOKENS,
                    model=llm_cfg.model or get_routed_model() or _default_model(),
                    reason="stage_disabled",
                )
            return replace(state, extraction_status="ruler_only")

        # Build input text from simplified sentences or resolved/raw text
        if state.simplified_sentences:
            text = " ".join(state.simplified_sentences)
        else:
            text = state.resolved_text or state.text

        if not text or not text.strip():
            return replace(state, extraction_status="ruler_only")

        try:
            extractor = self._extractor or self._create_extractor(llm_cfg)
            result = extractor.extract(text)

            # Track token usage (CFS-1)
            self._track_tokens(state, llm_cfg)

            entities = result.get("entities", [])
            relations = result.get("relations", [])

            # Truncate to configured limits
            entities = entities[: llm_cfg.max_entities]
            relations = relations[: llm_cfg.max_relations]

            # VIS-PIPELINE-DAG-1 Phase 2 (IDEA-85 fold-in): post-extraction
            # batched drip. Emit one pipeline.stage event per entity and per
            # relation immediately after extract() returns and before the
            # stage finishes, so the graph viewer can drip-feed extracted
            # items into the graph during long pipeline runs without waiting
            # for store/link/enrich/ground/evolve. Opportunistic — silent
            # no-op if no progress context bound.
            _emit_extraction_drip(entities, relations)

            # CORE-SYS2-1b: pass raw decision dicts through to SmartMemory.ingest() dispatch
            llm_decisions = result.get("decisions", []) if llm_cfg.extract_decisions else []

            return replace(
                state,
                llm_entities=entities,
                llm_relations=relations,
                llm_decisions=llm_decisions,
                extraction_status="llm_enriched",
            )
        except Exception as e:
            logger.error("LLM extraction failed: %s", e, exc_info=True)
            raise

    def _track_tokens(self, state: PipelineState, llm_cfg) -> None:
        """Record spent or avoided tokens from the extraction call."""
        tracker = state.token_tracker
        if not tracker:
            return

        from smartmemory.pipeline.model_router import get_routed_model
        model = llm_cfg.model or get_routed_model() or _default_model()

        # Check the positive cache-hit flag from the extractor first.
        # This avoids false positives from missing DSPy usage data.
        try:
            from smartmemory.plugins.extractors.llm_single import was_last_extract_cached

            cache_hit = was_last_extract_cached()
        except ImportError:
            cache_hit = False

        if cache_hit:
            tracker.record_avoided("llm_extract", self._AVG_EXTRACTION_TOKENS, model=model, reason="cache_hit")
            return

        # Not a cache hit — try to capture actual token usage from DSPy.
        try:
            from smartmemory.utils.llm_client.dspy import get_last_usage

            usage = get_last_usage()
        except ImportError:
            usage = None

        if usage:
            tracker.record_spent(
                "llm_extract",
                prompt_tokens=usage.get("prompt_tokens", 0),
                completion_tokens=usage.get("completion_tokens", 0),
                model=model,
            )
        # If usage is None and it was NOT a cache hit, we have no data —
        # don't record anything rather than producing a false "cache_hit".

    def _create_extractor(self, llm_cfg):
        """Build an LLMSingleExtractor from config.

        When no model is explicitly configured and ``GROQ_API_KEY`` is set,
        automatically uses the higher-quality GroqExtractor (Llama-3.3-70b,
        97.7% E-F1 at 878ms) instead of defaulting to gpt-4o-mini.
        """
        import os

        from smartmemory.plugins.extractors.llm_single import LLMSingleExtractor, LLMSingleExtractorConfig

        # RLM-1d: Router overrides Groq auto-detection
        from smartmemory.pipeline.model_router import get_routed_model
        routed = get_routed_model()
        if routed and not llm_cfg.model:
            ext_config = LLMSingleExtractorConfig(model_name=routed)
            ext_config.extract_decisions = llm_cfg.extract_decisions
            if llm_cfg.temperature is not None:
                ext_config.temperature = llm_cfg.temperature
            if llm_cfg.max_tokens is not None:
                ext_config.max_tokens = llm_cfg.max_tokens
            return LLMSingleExtractor(config=ext_config)

        # Auto-detect Groq when no model explicitly configured
        if not llm_cfg.model and os.getenv("GROQ_API_KEY"):
            try:
                from smartmemory.plugins.extractors.llm_single import GroqExtractor

                extractor = GroqExtractor()
                if llm_cfg.temperature is not None:
                    extractor.cfg.temperature = llm_cfg.temperature
                if llm_cfg.max_tokens is not None:
                    extractor.cfg.max_tokens = llm_cfg.max_tokens
                # CORE-SYS2-1b: GroqExtractor is a zero-arg subclass of LLMSingleExtractor;
                # inject extract_decisions after construction via replace() (already imported).
                # Do NOT call dataclasses.replace() — only 'replace' is in scope here.
                extractor.cfg = replace(extractor.cfg, extract_decisions=llm_cfg.extract_decisions)
                return extractor
            except Exception:
                logger.debug("GroqExtractor init failed, falling back to default")

        ext_config = LLMSingleExtractorConfig()
        if llm_cfg.model:
            ext_config.model_name = llm_cfg.model
        if llm_cfg.temperature is not None:
            ext_config.temperature = llm_cfg.temperature
        if llm_cfg.max_tokens is not None:
            ext_config.max_tokens = llm_cfg.max_tokens
        # CORE-SYS2-1b: forward the flag so non-Groq providers (OpenAI, etc.) also extract decisions
        ext_config.extract_decisions = llm_cfg.extract_decisions

        return LLMSingleExtractor(config=ext_config)

    def undo(self, state: PipelineState) -> PipelineState:
        return replace(state, llm_entities=[], llm_relations=[], llm_decisions=[])


# ---------------------------------------------------------------------------
# VIS-PIPELINE-DAG-1 Phase 2: post-extraction batched drip helper
#
# Emits one `pipeline.stage` event per extracted entity and per extracted
# relation, with `status="progress"` and `payload.entity` / `payload.relation`
# carrying the extractor's dict shape verbatim. Consumers (graph viewer)
# drip-feed these into the graph during the rest of the pipeline.
#
# Opportunistic — silent no-op if no progress context is bound. Failures
# from a bound context escalate to WARNING per no-silent-degradation.md.
# Captures one ts per event and pins both top-level ts and payload.original_ts
# to it, per PayloadConventions: original_ts MUST equal ts at first emission.
# ---------------------------------------------------------------------------


def _entity_to_drip_dict(entity) -> dict:
    """Project an LLMSingleExtractor entity (MemoryItem or dict) into a JSON-
    serializable drip payload matching PLAT-PROGRESS-1 v1.4.0 PayloadConventions.

    LLMSingleExtractor emits `MemoryItem` instances with metadata={name,
    entity_type, confidence, ...}. This helper extracts the renderer-friendly
    shape `{id, name, type, confidence}` so consumers don't need to depend on
    the MemoryItem class.
    """
    # MemoryItem path
    if hasattr(entity, "metadata") and isinstance(getattr(entity, "metadata", None), dict):
        meta = entity.metadata
        return {
            "id": getattr(entity, "item_id", None),
            "name": meta.get("name") or getattr(entity, "content", ""),
            "type": meta.get("entity_type") or "concept",
            "confidence": meta.get("confidence"),
        }
    # Plain dict path (test stubs, future producers)
    if isinstance(entity, dict):
        return {
            "id": entity.get("id") or entity.get("item_id"),
            "name": entity.get("name"),
            "type": entity.get("type") or entity.get("entity_type") or "concept",
            "confidence": entity.get("confidence"),
        }
    return {}


def _relation_to_drip_dict(relation) -> dict:
    """Project an LLMSingleExtractor relation dict into a drip payload.

    LLMSingleExtractor relations are `{source_id, target_id, relation_type,
    raw_predicate}`. We forward the canonical fields plus optional confidence.
    """
    if not isinstance(relation, dict):
        return {}
    return {
        "source_id": relation.get("source_id") or relation.get("subject"),
        "target_id": relation.get("target_id") or relation.get("object"),
        "type": relation.get("relation_type") or relation.get("predicate") or "related_to",
        "raw_predicate": relation.get("raw_predicate"),
        "confidence": relation.get("confidence"),
    }


def _emit_extraction_drip(entities: list, relations: list) -> None:
    try:
        from smartmemory.progress import _run_id, _scope
        if _run_id.get() is None or _scope.get() is None:
            return
    except Exception:
        return

    try:
        import time as _time
        from smartmemory.progress import emit as progress_emit
    except ImportError:
        return

    for entity in entities or []:
        try:
            drip = _entity_to_drip_dict(entity)
            if not drip.get("name"):
                continue  # malformed — skip rather than emit empty payload
            ts = _time.time()
            progress_emit(
                kind="pipeline.stage",
                status="progress",
                stage="llm_extract",
                payload={"original_ts": ts, "entity": drip},
                _ts=ts,
            )
        except Exception as exc:
            logger.warning(
                "VIS-PIPELINE-DAG-1: extraction-drip entity emit failed (non-fatal but degraded): %s",
                exc,
            )

    for relation in relations or []:
        try:
            drip = _relation_to_drip_dict(relation)
            if not (drip.get("source_id") and drip.get("target_id")):
                continue
            ts = _time.time()
            progress_emit(
                kind="pipeline.stage",
                status="progress",
                stage="llm_extract",
                payload={"original_ts": ts, "relation": drip},
                _ts=ts,
            )
        except Exception as exc:
            logger.warning(
                "VIS-PIPELINE-DAG-1: extraction-drip relation emit failed (non-fatal but degraded): %s",
                exc,
            )
