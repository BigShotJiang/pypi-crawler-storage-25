"""Temporal resolution stage — resolve relative dates to ISO 8601 at ingest (CORE-TEMPORAL-RESOLVE-1).

Runs after SimplifyStage, before EntityRulerStage. Scans text for temporal
expressions, resolves relative ones against a reference date (state.started_at
or caller-provided reference_date in raw_metadata).

No LLM — regex + dateutil only. Zero cost, <1ms latency.
"""

from __future__ import annotations

import logging
import re
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any

from dateutil.parser import parse as dateutil_parse, ParserError

from smartmemory.pipeline.state import PipelineState

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig

logger = logging.getLogger(__name__)

# ── Relative date patterns (no LLM, pure regex) ──────────────────────────

_DAYS_OF_WEEK = {
    "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
    "friday": 4, "saturday": 5, "sunday": 6,
}

_RELATIVE_PATTERNS: list[tuple[re.Pattern, str]] = [
    # "yesterday", "the day before yesterday"
    (re.compile(r"\bthe day before yesterday\b", re.I), "day_before_yesterday"),
    (re.compile(r"\byesterday\b", re.I), "yesterday"),
    (re.compile(r"\btoday\b", re.I), "today"),
    (re.compile(r"\btomorrow\b", re.I), "tomorrow"),
    # "N days/weeks/months/years ago"
    (re.compile(r"\b(\d+)\s+(day|week|month|year)s?\s+ago\b", re.I), "n_ago"),
    # "last week/month/year"
    (re.compile(r"\blast\s+(week|month|year)\b", re.I), "last_period"),
    # "last Monday" etc.
    (re.compile(r"\blast\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", re.I), "last_day"),
]

# Absolute date patterns (for dateutil)
_ABSOLUTE_DATE_RE = re.compile(
    r"\b("
    r"\d{4}[-/]\d{1,2}[-/]\d{1,2}"  # 2026-03-15, 2026/3/15
    r"|(?:January|February|March|April|May|June|July|August|September|October|November|December)"
    r"\s+\d{1,2}(?:,?\s+\d{4})?"  # January 15, 2026 or January 15
    r"|(?:\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)"
    r"(?:\s+\d{4})?)"  # 15 January 2026
    r"|(?:January|February|March|April|May|June|July|August|September|October|November|December)"
    r"\s+\d{4}"  # March 2026 (month-year, no day)
    r")\b",
    re.I,
)


def _resolve_relative(match: re.Match, kind: str, ref: datetime) -> datetime | None:
    """Resolve a relative date expression against a reference datetime."""
    if kind == "yesterday":
        return ref - timedelta(days=1)
    if kind == "day_before_yesterday":
        return ref - timedelta(days=2)
    if kind == "today":
        return ref
    if kind == "tomorrow":
        return ref + timedelta(days=1)
    if kind == "n_ago":
        n = int(match.group(1))
        unit = match.group(2).lower()
        if unit == "day":
            return ref - timedelta(days=n)
        if unit == "week":
            return ref - timedelta(weeks=n)
        if unit == "month":
            # Approximate: 30 days per month
            return ref - timedelta(days=n * 30)
        if unit == "year":
            return ref - timedelta(days=n * 365)
    if kind == "last_period":
        unit = match.group(1).lower()
        if unit == "week":
            return ref - timedelta(weeks=1)
        if unit == "month":
            return ref - timedelta(days=30)
        if unit == "year":
            return ref - timedelta(days=365)
    if kind == "last_day":
        day_name = match.group(1).lower()
        target_dow = _DAYS_OF_WEEK.get(day_name)
        if target_dow is not None:
            current_dow = ref.weekday()
            days_back = (current_dow - target_dow) % 7
            if days_back == 0:
                days_back = 7  # "last Monday" when today is Monday means 7 days ago
            return ref - timedelta(days=days_back)
    return None


def resolve_temporal_expressions(text: str, reference_date: datetime) -> list[dict[str, Any]]:
    """Extract and resolve temporal expressions from text.

    Returns list of {text: str, date: str (ISO 8601), type: "relative"|"absolute"}.
    """
    results: list[dict[str, Any]] = []
    seen_spans: set[tuple[int, int]] = set()  # avoid overlapping matches

    # 1. Relative patterns first (higher priority)
    for pattern, kind in _RELATIVE_PATTERNS:
        for match in pattern.finditer(text):
            span = (match.start(), match.end())
            if any(s[0] <= span[0] < s[1] or s[0] < span[1] <= s[1] for s in seen_spans):
                continue
            resolved = _resolve_relative(match, kind, reference_date)
            if resolved:
                results.append({
                    "text": match.group(0),
                    "date": resolved.date().isoformat(),
                    "type": "relative",
                })
                seen_spans.add(span)

    # 2. Absolute dates via regex + dateutil
    # Month-year-only pattern (no day) — normalize default to day=1
    _month_year_only = re.compile(
        r"^(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}$",
        re.I,
    )
    for match in _ABSOLUTE_DATE_RE.finditer(text):
        span = (match.start(), match.end())
        if any(s[0] <= span[0] < s[1] or s[0] < span[1] <= s[1] for s in seen_spans):
            continue
        try:
            match_text = match.group(0)
            # For month-year-only ("March 2026"), default day to 1st
            if _month_year_only.match(match_text):
                default = reference_date.replace(day=1)
            else:
                default = reference_date
            parsed = dateutil_parse(match_text, default=default)
            results.append({
                "text": match_text,
                "date": parsed.date().isoformat(),
                "type": "absolute",
            })
            seen_spans.add(span)
        except (ParserError, ValueError):
            pass

    return results


class TemporalResolveStage:
    """Resolve relative date expressions to absolute ISO 8601 at ingest time."""

    @property
    def name(self) -> str:
        return "temporal_resolve"

    def execute(self, state: PipelineState, config: "PipelineConfig") -> PipelineState:
        if config.mode == "preview":
            return state

        temporal_cfg = getattr(config, "temporal_resolve", None)
        if temporal_cfg and not temporal_cfg.enabled:
            return state

        text = state.resolved_text or state.text
        if not text:
            return state

        # Reference date: caller override > pipeline start > now
        ref_str = state.raw_metadata.get("reference_date")
        if ref_str:
            try:
                reference_date = dateutil_parse(ref_str)
            except (ParserError, ValueError):
                logger.warning("Invalid reference_date '%s', using pipeline start", ref_str)
                reference_date = state.started_at or datetime.now(timezone.utc)
        else:
            reference_date = state.started_at or datetime.now(timezone.utc)

        resolved = resolve_temporal_expressions(text, reference_date)
        if not resolved:
            return state

        # Store all resolved dates in metadata for downstream stages
        new_meta = dict(state.raw_metadata)
        new_meta["resolved_dates"] = resolved
        # Set the earliest resolved date as the primary resolved_date
        dates = sorted(resolved, key=lambda r: r["date"])
        new_meta["resolved_date"] = dates[0]["date"]

        logger.debug(
            "Temporal resolution: %d expressions resolved (earliest: %s)",
            len(resolved), dates[0]["date"],
        )

        return replace(state, raw_metadata=new_meta)

    def undo(self, state: PipelineState) -> PipelineState:
        new_meta = dict(state.raw_metadata)
        new_meta.pop("resolved_dates", None)
        new_meta.pop("resolved_date", None)
        return replace(state, raw_metadata=new_meta)
