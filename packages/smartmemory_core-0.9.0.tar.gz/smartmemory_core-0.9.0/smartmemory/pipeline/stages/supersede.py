"""Supersede stage — detect contradictions and mark old memories as superseded (CORE-SUPERSEDE-1).

Runs after StoreStage. For each newly stored semantic memory, searches for existing
memories that contradict it and marks them as superseded with a SUPERSEDED_BY edge.

Uses the existing contradiction detection cascade from smartmemory.reasoning.detection.
"""

from __future__ import annotations

import logging
from dataclasses import replace
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List

from smartmemory.pipeline.state import PipelineState

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig

logger = logging.getLogger(__name__)


class SupersedeStage:
    """Detect contradictions and supersede old memories after storing a new one."""

    def __init__(self, memory):
        """Args: memory — a SmartMemory instance."""
        self._memory = memory

    @property
    def name(self) -> str:
        return "supersede"

    def execute(self, state: PipelineState, config: PipelineConfig) -> PipelineState:
        if config.mode == "preview":
            return state

        if not config.supersede.enabled:
            return state

        # CORE-SUMMARY-1 D5/B1: snapshots are append-only time-series.
        # Even if the broader semantic-only filter below is ever loosened,
        # this explicit guard ensures snapshots never acquire SUPERSEDED_BY.
        if state.memory_type == "snapshot":
            return state

        # Only supersede semantic facts
        if state.memory_type not in (None, "semantic"):
            return state

        # Opt-out via metadata
        if state.raw_metadata.get("skip_supersession"):
            return state

        # Need an item_id from the store stage
        if not state.item_id:
            logger.warning("SupersedeStage: no item_id in state, skipping")
            return state

        content = state.resolved_text or state.text
        if not content or len(content.strip()) < 10:
            return state

        results = self._find_and_supersede(
            new_item_id=state.item_id,
            content=content,
            config=config,
        )

        if results:
            return replace(state, supersession_results=results)
        return state

    def undo(self, state: PipelineState) -> PipelineState:
        return replace(state, supersession_results=[])

    def _find_and_supersede(
        self,
        new_item_id: str,
        content: str,
        config: PipelineConfig,
    ) -> List[Dict[str, Any]]:
        """Search for contradicting memories and supersede them."""
        from smartmemory.reasoning.detection import (
            DetectionCascade,
            EmbeddingDetector,
            GraphDetector,
            HeuristicDetector,
        )
        from smartmemory.reasoning.detection.base import DetectionContext

        # Search for candidate memories that might contradict the new one
        try:
            candidates = self._memory.search(
                content,
                top_k=config.supersede.max_candidates,
                memory_type="semantic",
                include_superseded=True,  # Don't re-supersede already superseded items — filter below
            )
        except Exception as e:
            logger.warning("SupersedeStage: search for candidates failed: %s", e)
            return []

        if not candidates:
            return []

        # Filter out the item we just stored, already-superseded items, and items with no content
        candidates = [
            c for c in candidates
            if getattr(c, "item_id", None) != new_item_id
            and not _is_superseded(c)
            and getattr(c, "content", None)  # Guard against None content in detection cascade
        ]

        if not candidates:
            return []

        # Build detection cascade (no LLM for initial pass — LLM used only for confirmation)
        detectors = [GraphDetector(), EmbeddingDetector(), HeuristicDetector()]
        cascade = DetectionCascade(detectors)

        results: List[Dict[str, Any]] = []

        for candidate in candidates:
            ctx = DetectionContext(
                new_assertion=content,
                existing_item=candidate,
                existing_fact=candidate.content,
            )
            conflict = cascade.detect(ctx)
            if not conflict:
                continue

            confidence = conflict.confidence

            # High confidence: auto-supersede
            if confidence >= config.supersede.auto_threshold:
                self._apply_supersession(
                    old_item=candidate,
                    new_item_id=new_item_id,
                    conflict=conflict,
                    method="auto",
                )
                results.append(self._result_dict(candidate, new_item_id, conflict, "auto"))
                continue

            # Medium confidence: LLM confirmation
            if confidence >= config.supersede.llm_confirm_threshold and config.supersede.use_llm_confirmation:
                llm_conflict = self._llm_confirm(content, candidate)
                if llm_conflict:
                    self._apply_supersession(
                        old_item=candidate,
                        new_item_id=new_item_id,
                        conflict=llm_conflict,
                        method="llm_confirmed",
                    )
                    results.append(self._result_dict(candidate, new_item_id, llm_conflict, "llm_confirmed"))

        return results

    def _llm_confirm(self, new_content: str, existing_item) -> Any | None:
        """Use LLM detector to confirm a borderline contradiction."""
        try:
            from smartmemory.reasoning.detection import LLMDetector
            from smartmemory.reasoning.detection.base import DetectionContext

            detector = LLMDetector()
            ctx = DetectionContext(
                new_assertion=new_content,
                existing_item=existing_item,
                existing_fact=existing_item.content,
            )
            return detector.detect(ctx)
        except Exception as e:
            logger.warning("SupersedeStage: LLM confirmation failed: %s", e)
            return None

    def _apply_supersession(
        self,
        old_item,
        new_item_id: str,
        conflict,
        method: str,
    ) -> None:
        """Mark old item as superseded and create SUPERSEDED_BY edge."""
        old_id = getattr(old_item, "item_id", None)
        if not old_id:
            logger.warning("SupersedeStage: old item has no item_id, cannot supersede")
            return

        now = datetime.now(timezone.utc).isoformat()

        # Mark old node as superseded
        try:
            self._memory.update_properties(
                old_id,
                {
                    "superseded": True,
                    "superseded_by": new_item_id,
                    "superseded_at": now,
                },
            )
        except Exception as e:
            logger.warning("SupersedeStage: failed to update old item %s: %s", old_id, e)
            return

        # Create SUPERSEDED_BY edge (old -> new)
        try:
            self._memory.add_edge(
                source_id=old_id,
                target_id=new_item_id,
                relation_type="SUPERSEDED_BY",
                properties={
                    "confidence": conflict.confidence,
                    "conflict_type": conflict.conflict_type.value
                    if hasattr(conflict.conflict_type, "value")
                    else str(conflict.conflict_type),
                    "detected_at": now,
                    "detection_method": method,
                    "explanation": conflict.explanation[:200] if conflict.explanation else "",
                },
            )
        except Exception as e:
            logger.warning("SupersedeStage: failed to create SUPERSEDED_BY edge %s -> %s: %s", old_id, new_item_id, e)
            return

        logger.warning(
            "SupersedeStage: superseded memory %s by %s (confidence=%.2f, method=%s, reason=%s)",
            old_id,
            new_item_id,
            conflict.confidence,
            method,
            (conflict.explanation or "")[:100],
        )

    @staticmethod
    def _result_dict(old_item, new_item_id: str, conflict, method: str) -> Dict[str, Any]:
        return {
            "old_item_id": getattr(old_item, "item_id", None),
            "new_item_id": new_item_id,
            "confidence": conflict.confidence,
            "conflict_type": conflict.conflict_type.value
            if hasattr(conflict.conflict_type, "value")
            else str(conflict.conflict_type),
            "method": method,
            "explanation": conflict.explanation,
        }


def _is_superseded(item) -> bool:
    """Check if a memory item is already superseded."""
    # Check node property (set by update_properties)
    if getattr(item, "superseded", False):
        return True
    # Check metadata fallback
    metadata = getattr(item, "metadata", None) or {}
    return bool(metadata.get("superseded"))
