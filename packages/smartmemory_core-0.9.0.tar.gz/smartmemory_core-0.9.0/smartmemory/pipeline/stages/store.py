"""Store stage — wraps CRUD.add() + StoragePipeline."""

from __future__ import annotations

import logging
from dataclasses import replace
from typing import TYPE_CHECKING, List

from smartmemory.pipeline.state import PipelineState

if TYPE_CHECKING:
    from smartmemory.pipeline.config import PipelineConfig

logger = logging.getLogger(__name__)


class StoreStage:
    """Persist the memory item and extracted entities to the graph."""

    # Average tokens per embedding call — used to estimate avoided tokens on cache hit.
    _AVG_EMBEDDING_TOKENS: int = 250

    def __init__(self, memory):
        """Args: memory — a SmartMemory instance."""
        self._memory = memory

    @property
    def name(self) -> str:
        return "store"

    def execute(self, state: PipelineState, config: PipelineConfig) -> PipelineState:
        from smartmemory.models.memory_item import MemoryItem

        if config.mode == "preview":
            return replace(state, item_id="preview_item")

        content = state.resolved_text or state.text
        metadata = dict(state.raw_metadata)
        if state.extraction_status:
            metadata["extraction_status"] = state.extraction_status
        # Inject run_id if present for run-based cleanup
        if state.raw_metadata.get("run_id"):
            metadata["run_id"] = state.raw_metadata["run_id"]
        # OL-2: Inject ontology version metadata
        if state.ontology_version:
            metadata["ontology_version"] = state.ontology_version
        if state.ontology_registry_id:
            metadata["ontology_registry_id"] = state.ontology_registry_id
        # CORE-PROPS-1: Read origin + caller-supplied confidence from pipeline metadata
        origin = state.raw_metadata.get("origin", "unknown")
        caller_confidence = state.raw_metadata.get("confidence")

        item = MemoryItem(
            content=content,
            memory_type=state.memory_type or "semantic",
            metadata=metadata,
            origin=origin,
        )

        # CORE-PROPS-1: Preserve caller-supplied confidence if provided
        if caller_confidence is not None:
            try:
                item.confidence = float(caller_confidence)
            except (ValueError, TypeError):
                pass

        # CORE-PROPS-1 Phase 6: propagate reference flag from metadata
        if state.raw_metadata.get("reference"):
            item.reference = True

        # CORE-TEMPORAL-RESOLVE-1: populate valid_start_time from resolved date
        resolved_date_str = state.raw_metadata.get("resolved_date")
        if resolved_date_str and item.valid_start_time is None:
            try:
                from dateutil.parser import parse as _dp
                item.valid_start_time = _dp(resolved_date_str)
            except Exception:
                pass

        # CORE-PROPS-1: Apply provenance ceiling (caps, never raises).
        # Always apply — explicit origin="unknown" gets the documented 0.3 cap
        # per CORE-PROPS-1 contract (see tests/integration/test_recall_confidence.py).
        ceiling = _get_provenance_ceiling(origin, config.store.confidence_ceilings)
        item.confidence = min(item.confidence, ceiling)

        # Build ontology_extraction payload.
        # When OntologyConstrainStage ran, it sets state.entities (accepted)
        # and state.rejected (rejected). Even if entities=[] and rejected=[],
        # that means the stage ran and found nothing — respect that.
        # When OntologyConstrainStage was skipped entirely, state.entities
        # and state.rejected are both unset (None/empty) but ruler_entities
        # has extractions — use those so entity nodes get created.
        ontology_ran = bool(state.entities) or bool(getattr(state, "rejected", None))
        entities = state.entities if ontology_ran else (state.ruler_entities or [])
        relations = state.relations
        ontology_extraction = None
        if entities or relations:
            ontology_extraction = {"entities": entities, "relations": relations}

        # CORE-EVENT-EXTRACT-1: stamp session_id via ContextVar for accumulation during add()
        # ContextVar is thread-safe — no cross-contamination under concurrent ingest_batch()
        session_id = state.raw_metadata.get("session_id", "") or ""
        _backend = getattr(getattr(self._memory, "_graph", None), "backend", None)

        _token = None
        try:
            from smartmemory.graph.backends.falkordb import _current_session_id_var
            _token = _current_session_id_var.set(session_id) if session_id else None
        except ImportError:
            pass  # SQLite backend — no ContextVar needed, accumulation uses explicit session_id param

        try:
            add_result = self._memory._crud.add(item, ontology_extraction=ontology_extraction)
        finally:
            if _token is not None:
                try:
                    from smartmemory.graph.backends.falkordb import _current_session_id_var
                    _current_session_id_var.reset(_token)
                except ImportError:
                    pass

        # Process result
        entity_ids = {}
        if isinstance(add_result, dict):
            item_id = add_result.get("memory_node_id")
            created_ids = add_result.get("entity_node_ids", []) or []
            entity_ids = self._map_entity_ids(entities, created_ids, item_id)
        else:
            item_id = add_result
            entity_ids = self._map_entity_ids(entities, [], item_id)

        item.item_id = item_id
        item.update_status("created", notes="Item ingested")

        # CORE-EVENT-EXTRACT-1: stamp source_session_id on entity nodes (provenance, always when session_id present)
        _created = (add_result.get("entity_node_ids", []) or []) if isinstance(add_result, dict) else []
        if session_id and _backend is not None and _created:
            for _idx in range(min(len(entities or []), len(_created))):
                _node_id = _created[_idx]
                try:
                    _backend.set_properties(_node_id, {"source_session_id": session_id})
                except Exception as _exc:
                    logger.warning("source_session_id stamp failed for %s: %s", _node_id, _exc)

        # CORE-EVENT-EXTRACT-1: trigger property accumulation for new entities (gated by config)
        # Drive by index (not name) to avoid mismatch when entity names collide.
        # session_id is optional — accumulation normalizes to list shape regardless.
        _accum_cfg = getattr(config.store, "accumulation", None)
        if _accum_cfg and _accum_cfg.enabled and _backend is not None:
            for _idx, _entity in enumerate(entities or []):
                if _idx >= len(_created):
                    break
                _node_id = _created[_idx]
                _eprops = _entity.get("metadata", _entity) if isinstance(_entity, dict) else (
                    getattr(_entity, "metadata", None) or {}
                )
                if not isinstance(_eprops, dict):
                    _eprops = {}
                for _prop in _accum_cfg.accumulate_properties:
                    _val = _eprops.get(_prop)
                    if _val is not None:
                        _vals = _val if isinstance(_val, (list, tuple)) else [_val]
                        for _v in _vals:
                            try:
                                _backend.accumulate_property(
                                    _node_id, _prop, _v, session_id=session_id,
                                )
                            except Exception as _exc:
                                logger.warning(
                                    "accumulate_property failed for %s.%s: %s",
                                    _node_id, _prop, _exc,
                                )

        # Process external relations via StoragePipeline
        # CORE-15: pass position-preserving created_ids for disambiguation
        _created_for_rels = (add_result.get("entity_node_ids", []) or []) if isinstance(add_result, dict) else []
        if relations:
            self._process_relations(state, item_id, entities, relations, entity_ids, created_ids=_created_for_rels)

        # Save to vector and graph with token tracking (CFS-1a)
        context = {
            "item": item,
            "entity_ids": entity_ids,
            "entities": entities,
        }
        try:
            from smartmemory.memory.ingestion.storage import StoragePipeline
            from smartmemory.memory.ingestion.observer import IngestionObserver

            storage = StoragePipeline(self._memory, IngestionObserver())
            storage.save_to_vector_and_graph(context)
        except Exception as e:
            logger.warning("Vector/graph save failed (non-fatal): %s", e)
        finally:
            # Track embedding token usage (CFS-1a) — must happen even on save failure
            # because the embedding API call may have completed before the error
            self._track_embedding_usage(state)

        return replace(state, item_id=item_id, entity_ids=entity_ids)

    def undo(self, state: PipelineState) -> PipelineState:
        return replace(state, item_id=None, entity_ids={})

    @staticmethod
    def _map_entity_ids(entities: List, created_ids: List, item_id) -> dict:
        entity_ids = {}
        for i, entity in enumerate(entities):
            name = _entity_name(entity, i)
            real_id = created_ids[i] if i < len(created_ids) else f"{item_id}_entity_{i}"
            if name in entity_ids:
                # Same name, different entity — last one wins. Log so it's observable.
                logger.warning(
                    "Entity name collision in entity_ids: '%s' (overwriting %s with %s)",
                    name, entity_ids[name], real_id,
                )
            entity_ids[name] = real_id
        return entity_ids

    def _process_relations(self, state, item_id, entities, relations, entity_ids: dict | None = None,
                           created_ids: list | None = None):
        """Resolve relation endpoints to graph node IDs and create semantic edges."""
        entity_ids = entity_ids or state.entity_ids or {}
        if not relations or not entity_ids:
            return

        # CORE-15: use position-preserving created_ids when available
        ordered_graph_ids = created_ids if created_ids else list(entity_ids.values())
        id_map: dict[str, str] = {graph_id: graph_id for graph_id in ordered_graph_ids if graph_id}

        def _normalize_key(value):
            if value is None:
                return None
            value = str(value).strip()
            return value or None

        def _entity_extraction_id(entity):
            if isinstance(entity, dict):
                return _normalize_key(entity.get("item_id") or entity.get("id"))
            return _normalize_key(getattr(entity, "item_id", None))

        def _entity_name_candidates(entity, index: int) -> list[str]:
            candidates: list[str] = []

            def _add(value):
                value = _normalize_key(value)
                if value and value not in candidates:
                    candidates.append(value)

            if isinstance(entity, dict):
                metadata = entity.get("metadata") or {}
                _add(entity.get("name"))
                _add(metadata.get("name"))
                _add(entity.get("source_text"))
                _add(entity.get("target_text"))
                _add(entity.get("content"))
            else:
                metadata = getattr(entity, "metadata", None) or {}
                _add(getattr(entity, "name", None))
                _add(metadata.get("name"))
                _add(getattr(entity, "content", None))

            fallback_name = _entity_name(entity, index)
            if fallback_name:
                _add(fallback_name)

            lowered = [name.lower() for name in candidates if name.lower() not in candidates]
            return candidates + lowered

        def _lookup_graph_id(*candidates):
            for candidate in candidates:
                candidate = _normalize_key(candidate)
                if not candidate:
                    continue
                graph_id = id_map.get(candidate)
                if graph_id:
                    return graph_id
                graph_id = entity_ids.get(candidate)
                if graph_id:
                    return graph_id
                lowered = candidate.lower()
                graph_id = id_map.get(lowered)
                if graph_id:
                    return graph_id
                graph_id = entity_ids.get(lowered)
                if graph_id:
                    return graph_id
            return None

        def _register_entity(entity, index: int, graph_id: str | None = None):
            extraction_id = _entity_extraction_id(entity)
            names = _entity_name_candidates(entity, index)

            resolved_graph_id = graph_id or _lookup_graph_id(extraction_id, *names)
            if not resolved_graph_id and index < len(ordered_graph_ids):
                resolved_graph_id = ordered_graph_ids[index]
            if not resolved_graph_id:
                return

            id_map[resolved_graph_id] = resolved_graph_id
            if extraction_id:
                id_map[extraction_id] = resolved_graph_id
            for name in names:
                id_map[name] = resolved_graph_id
            # CORE-15: register type-qualified name for collision disambiguation
            etype = ""
            if isinstance(entity, dict):
                etype = (entity.get("metadata") or {}).get("entity_type") or entity.get("entity_type", "")
            if etype:
                for name in names:
                    id_map[f"{name}:{etype.lower()}"] = resolved_graph_id

        for i, entity in enumerate(entities or []):
            graph_id = ordered_graph_ids[i] if i < len(ordered_graph_ids) else None
            _register_entity(entity, i, graph_id)

        for source_list in (
            getattr(state, "entities", None),
            getattr(state, "ruler_entities", None),
            getattr(state, "llm_entities", None),
        ):
            if not source_list:
                continue
            for i, entity in enumerate(source_list):
                _register_entity(entity, i)

        resolved = []
        for relation in relations:
            if not isinstance(relation, dict):
                continue

            src_id = _lookup_graph_id(
                relation.get("source_id"),
                relation.get("source_text"),
                relation.get("subject"),
                relation.get("source"),
            )
            tgt_id = _lookup_graph_id(
                relation.get("target_id"),
                relation.get("target_text"),
                relation.get("object"),
                relation.get("target"),
            )

            if src_id and tgt_id:
                resolved_relation = dict(relation)
                resolved_relation["source_id"] = src_id
                resolved_relation["target_id"] = tgt_id
                resolved.append(resolved_relation)
                continue

            logger.warning(
                "Unresolvable relation: src=%s (text=%s) tgt=%s (text=%s) | id_map_keys=%s",
                relation.get("source_id"),
                relation.get("source_text") or relation.get("subject") or relation.get("source"),
                relation.get("target_id"),
                relation.get("target_text") or relation.get("object") or relation.get("target"),
                list(id_map.keys())[:10],
            )

        if resolved:
            try:
                from smartmemory.memory.ingestion.storage import StoragePipeline
                from smartmemory.memory.ingestion.observer import IngestionObserver

                context = dict(getattr(state, "_context", {}) or {})
                context["entity_ids"] = entity_ids
                storage = StoragePipeline(self._memory, IngestionObserver())
                storage.process_extracted_relations(context, item_id, resolved)
            except Exception as e:
                logger.warning("Failed to process relations: %s", e)

    def _track_embedding_usage(self, state: PipelineState) -> None:
        """Track embedding token usage from the last embedding call (CFS-1a).

        Retrieves token usage from the EmbeddingService's thread-local storage
        and records it to the pipeline token tracker. Cache hits are recorded
        as avoided tokens with an estimated cost.
        """
        tracker = state.token_tracker
        if not tracker:
            return

        try:
            from smartmemory.plugins.embedding import get_last_embedding_usage

            usage = get_last_embedding_usage()
        except ImportError:
            return

        if not usage:
            return

        model = usage.get("model", "text-embedding-ada-002")

        if usage.get("cached"):
            # Cache hit — record estimated avoided tokens
            tracker.record_avoided(
                "store",
                self._AVG_EMBEDDING_TOKENS,
                model=model,
                reason="cache_hit",
            )
        else:
            # API call — record actual tokens spent (embeddings have no completion tokens)
            prompt_tokens = usage.get("prompt_tokens", 0)
            tracker.record_spent("store", prompt_tokens, 0, model=model)


# ---------------------------------------------------------------------------
# Provenance ceilings (CORE-PROPS-1 Phase 1a)
# ---------------------------------------------------------------------------

# Default provenance ceilings — matches design spec table.
# Exact keys are checked first; prefix keys (ending with ':' or '_') are
# matched longest-first so "evolver:opinion_" beats "evolver:".
_DEFAULT_CEILINGS: dict[str, float] = {
    "user": 1.0,
    "import:corpus": 1.0,
    # Tier 1 — user-authored content (no penalty)
    "user:": 1.0,
    "cli:": 1.0,
    "api:": 1.0,
    "import:": 1.0,
    "mcp:memory_add": 1.0,
    "code:index": 1.0,
    "import:pack": 0.9,
    "conversation:distill": 0.85,
    "evolver:": 0.8,
    "code:derived": 0.7,
    "conversation:summary": 0.7,
    "enricher:": 0.6,
    "evolver:opinion_": 0.5,
    "evolver:observation_": 0.5,
    "evolver:decision_": 0.5,
    "conversation:observe": 0.5,
    "hook:": 0.4,
    "unknown": 0.3,
}


def _get_provenance_ceiling(origin: str, overrides: dict[str, float] | None = None) -> float:
    """Return confidence ceiling for a given origin prefix.

    Checks exact match first, then longest prefix match.
    Overrides (from PipelineConfig) take precedence over defaults.
    Origin is normalized (strip + lowercase) before lookup.
    """
    origin = origin.strip().lower() if origin else "unknown"
    ceilings = {**_DEFAULT_CEILINGS, **(overrides or {})}
    # Exact match first
    if origin in ceilings:
        return ceilings[origin]
    # Prefix match (longest wins — e.g. "evolver:opinion_" before "evolver:")
    best_match = None
    best_len = 0
    for prefix, ceiling in ceilings.items():
        if prefix.endswith(":") or prefix.endswith("_"):
            if origin.startswith(prefix) and len(prefix) > best_len:
                best_match = ceiling
                best_len = len(prefix)
    if best_match is not None:
        return best_match
    # No match — use "unknown" ceiling, not 1.0
    return ceilings.get("unknown", 0.3)


def _entity_name(entity, index: int) -> str:
    """Extract display name from an entity (MemoryItem or dict)."""
    if hasattr(entity, "metadata") and isinstance(getattr(entity, "metadata", None), dict):
        name = entity.metadata.get("name")
        if name:
            return name
    if isinstance(entity, dict):
        meta = entity.get("metadata", {})
        return meta.get("name") or entity.get("name", f"entity_{index}")
    return f"entity_{index}"


def _find_entity_props(entity_name: str, entities: list, entity_type: str = None) -> dict:
    """Find extracted property dict for a named entity (CORE-EVENT-EXTRACT-1).

    Returns the metadata dict (or the entity dict itself) for the entity whose
    name matches *entity_name* (case-insensitive).  When *entity_type* is given,
    prefers a match on both name+type to avoid collisions (e.g. "Jordan" as
    person vs location).  Returns ``{}`` if not found.
    """
    name_lower = entity_name.lower()
    best = {}
    for e in (entities or []):
        if isinstance(e, dict):
            e_name = (e.get("metadata") or {}).get("name") or e.get("name", "")
            if e_name and e_name.lower() == name_lower:
                props = e.get("metadata") or e
                e_type = (e.get("metadata") or {}).get("entity_type") or e.get("entity_type", "")
                if entity_type and e_type and e_type.lower() == entity_type.lower():
                    return props  # exact name+type match — best possible
                if not best:
                    best = props  # first name-only match as fallback
        else:
            meta = getattr(e, "metadata", None) or {}
            e_name = meta.get("name") if isinstance(meta, dict) else getattr(meta, "name", None)
            if e_name and str(e_name).lower() == name_lower:
                if not best:
                    best = meta if isinstance(meta, dict) else {}
    return best
