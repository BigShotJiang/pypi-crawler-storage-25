"""ConsolidationRouter data types (CORE-MEMORY-DYNAMICS-1 M1a Task 2.1).

Defines the strategy enum and decision record written to ``PipelineState``
by ``ConsolidationRouterStage``.  The stage is observational in M1a — it
records decisions into the trajectory but does not yet gate ``StoreStage``
behavior (that lands in M1b alongside the ``working`` → ``pending`` rename).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List


class RouterStrategy(str, Enum):
    """Consolidation strategies emitted by the router."""

    COMMIT_SEMANTIC = "commit_semantic"
    COMMIT_EPISODIC = "commit_episodic"
    COMMIT_PROCEDURAL = "commit_procedural"
    COMMIT_DECISION = "commit_decision"
    COMMIT_REASONING = "commit_reasoning"
    HOLD_PENDING = "hold_pending"
    COMPILE_PROCEDURAL = "compile_procedural"
    PARALLEL_DUAL_ENCODE = "parallel_dual_encode"
    SKIP_APPEND = "skip_append"


@dataclass
class RouterDecision:
    """Record of a single consolidation-router decision.

    Fields:
        strategy:   Chosen ``RouterStrategy``.
        confidence: Router's confidence in the chosen strategy, ``0.0 – 1.0``.
        reasons:    Ordered human-readable signals that produced the decision.
        signals:    Arbitrary signal payload for trajectory/debugging.
    """

    strategy: RouterStrategy
    confidence: float
    reasons: List[str] = field(default_factory=list)
    signals: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "strategy": self.strategy.value,
            "confidence": self.confidence,
            "reasons": list(self.reasons),
            "signals": dict(self.signals),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RouterDecision":
        return cls(
            strategy=RouterStrategy(data["strategy"]),
            confidence=float(data["confidence"]),
            reasons=list(data.get("reasons", [])),
            signals=dict(data.get("signals", {})),
        )
