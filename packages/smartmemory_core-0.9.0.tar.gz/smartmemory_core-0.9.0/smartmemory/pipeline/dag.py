"""PipelineDag — topology declaration for VIS-PIPELINE-DAG-1.

Built at run start from the runner's *actual resolved stage list*. The DAG
is emitted once per run as a `pipeline.dag` progress event so consumers
(Studio Run Inspector, Insights, Maya) can render the machinery view as a
peer to the graph viewer's output view.

Key invariant: the DAG reflects what THIS run will execute, not a
hardcoded canonical pipeline. Stages disabled by config are absent from the
runner's stage list and therefore absent from the DAG.

See: smart-memory-docs/docs/features/VIS-PIPELINE-DAG-1/design.md
     smart-memory-docs/docs/features/PLAT-PROGRESS-1/progress-event-contract.json
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Sequence


@dataclass(frozen=True)
class DagNode:
    id: str
    label: str
    kind: str = "stage"  # "stage" | "fanout" | "join"
    parent: str | None = None

    def to_dict(self) -> dict:
        d: dict = {"id": self.id, "label": self.label, "kind": self.kind}
        if self.parent is not None:
            d["parent"] = self.parent
        return d


@dataclass(frozen=True)
class DagEdge:
    from_id: str
    to_id: str
    kind: str = "sequence"  # "sequence" | "fanout" | "join"

    def to_dict(self) -> dict:
        return {"from": self.from_id, "to": self.to_id, "kind": self.kind}


@dataclass
class PipelineDag:
    """Topology for one pipeline run."""

    pipeline: str
    nodes: List[DagNode] = field(default_factory=list)
    edges: List[DagEdge] = field(default_factory=list)

    def to_payload(self) -> dict:
        """Serialize to the `pipeline.dag` event payload shape."""
        return {
            "pipeline": self.pipeline,
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
        }

    @classmethod
    def from_stage_names(cls, pipeline: str, stage_names: Sequence[str]) -> "PipelineDag":
        """Build a linear DAG from an ordered list of stage names.

        The resolved stage list is the source of truth. Stages disabled by
        config are not in the list and therefore not in the DAG.
        """
        names = list(stage_names)
        nodes = [DagNode(id=name, label=_humanize(name), kind="stage") for name in names]
        edges = [
            DagEdge(from_id=names[i], to_id=names[i + 1], kind="sequence")
            for i in range(len(names) - 1)
        ]
        return cls(pipeline=pipeline, nodes=nodes, edges=edges)


def _humanize(stage_name: str) -> str:
    """Convert snake_case stage name to a renderer-friendly label.

    Used only when the producer doesn't supply an explicit label. Cheap
    capitalize-and-replace; renderers can override per-stage if needed.
    """
    return stage_name.replace("_", " ").strip().title()
