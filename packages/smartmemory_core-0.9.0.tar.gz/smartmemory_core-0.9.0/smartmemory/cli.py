"""smartmemory.cli — command-line interface for SmartMemory Lite."""
import json
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from smartmemory.tools.factory import create_lite_memory
from smartmemory.tools.markdown_writer import write_markdown

console = Console()


@click.group()
@click.option("--data-dir", default=None, help="Data directory (default: ~/.smartmemory)")
@click.pass_context
def main(ctx, data_dir):
    """SmartMemory Lite — zero-infra persistent memory for AI agents."""
    ctx.ensure_object(dict)
    ctx.obj["data_dir"] = data_dir
    ctx.obj["memory"] = None  # lazy init


def _get_memory(ctx):
    if ctx.obj["memory"] is None:
        ctx.obj["memory"] = create_lite_memory(ctx.obj["data_dir"])
    return ctx.obj["memory"]


@main.command()
@click.argument("text", required=False, default=None)
@click.option("--no-markdown", is_flag=True, default=False, help="Skip markdown file creation")
@click.option("--schema", default=None, help="Structured ingestion schema (e.g. decision, tool_call, plan)")
@click.pass_context
def add(ctx, text, no_markdown, schema):
    """Add a memory. Extracts entities and stores to local database.

    TEXT may be omitted or set to "-" to read from stdin
    (e.g. ``echo '{...}' | smartmemory-core add --schema tool_call``).

    With --schema, treats TEXT as JSON and routes through structured ingestion
    (bypasses NLP pipeline). Available schemas: decision, tool_call, plan_task,
    conversation_turn, hook_capture, seed_item, code_entity, plan, anchor,
    document, conversation.
    """
    import sys as _sys
    if text is None or text == "-":
        if _sys.stdin.isatty():
            console.print("[red]No TEXT given and stdin is a tty.[/red]")
            raise SystemExit(2) from None
        text = _sys.stdin.read()

    memory = _get_memory(ctx)

    if schema:
        import json as _json

        try:
            data = _json.loads(text)
        except _json.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON:[/red] {e}")
            raise SystemExit(1) from None
        try:
            item_id = memory.ingest_structured(data, schema=schema)
        except KeyError as e:
            console.print(f"[red]Unknown schema:[/red] {e}")
            raise SystemExit(1) from None
        except ValueError as e:
            console.print(f"[red]Validation error:[/red] {e}")
            raise SystemExit(1) from None
        console.print(f"[green]Stored ({schema}):[/green] {item_id}")
        return

    from smartmemory.models.memory_item import MemoryItem as _MI
    _item = _MI(content=text, origin="cli:add")
    item_id = memory.ingest(_item)
    console.print(f"[green]Stored:[/green] {item_id}")
    if not no_markdown:
        data_dir = ctx.obj["data_dir"] or str(Path.home() / ".smartmemory")
        notes_dir = Path(data_dir) / "notes"
        notes_dir.mkdir(parents=True, exist_ok=True)
        path = write_markdown(memory, item_id, str(notes_dir))
        console.print(f"[dim]Written:[/dim] {path}")


@main.group()
@click.pass_context
def schemas(ctx):
    """Manage structured ingestion schemas."""
    pass


@schemas.command("list")
@click.pass_context
def schemas_list(ctx):
    """List registered structured ingestion schemas."""
    from smartmemory.memory.ingestion.structured import (
        DescribableHandler,
        get_structured_registry,
    )
    registry = get_structured_registry()
    table = Table(title="Registered structured schemas")
    table.add_column("Schema", style="cyan")
    table.add_column("Strategy", style="green")
    table.add_column("Embed", style="dim")
    table.add_column("Description")
    for name in registry.schemas:
        h = registry.get(name)
        embed = "default" if h.embed is None else str(h.embed)
        if isinstance(h, DescribableHandler):
            desc = h.describe().get("description", "")
        else:
            desc = (h.__class__.__doc__ or "").strip().split("\n")[0]
        table.add_row(name, h.strategy.value, embed, desc)
    console.print(table)


@schemas.command("describe")
@click.argument("schema_name")
@click.pass_context
def schemas_describe(ctx, schema_name):
    """Describe a schema's required fields, edges, and strategy."""
    from smartmemory.memory.ingestion.structured import (
        DescribableHandler,
        get_structured_registry,
    )
    registry = get_structured_registry()
    try:
        handler = registry.get(schema_name)
    except KeyError as e:
        console.print(f"[red]Unknown schema:[/red] {e}")
        raise SystemExit(1) from None

    info = handler.describe() if isinstance(handler, DescribableHandler) else {}
    console.print(f"[bold cyan]{schema_name}[/bold cyan]")
    console.print(f"  Strategy: [green]{handler.strategy.value}[/green]")
    embed = handler.embed if handler.embed is not None else "(strategy default)"
    console.print(f"  Embed: {embed}")
    if info.get("description"):
        console.print(f"  {info['description']}")
    if info.get("required"):
        console.print("  [bold]Required:[/bold]")
        for field, desc in info["required"].items():
            console.print(f"    - {field}: {desc}")
    if info.get("optional"):
        console.print("  [bold]Optional:[/bold]")
        for field, desc in info["optional"].items():
            console.print(f"    - {field}: {desc}")
    if info.get("edge_types"):
        console.print(f"  [bold]Edges created:[/bold] {', '.join(info['edge_types'])}")


@main.command()
@click.argument("query")
@click.option("--top-k", default=5, help="Number of results")
@click.option("--json", "as_json", is_flag=True, default=False, help="Output as JSON")
@click.pass_context
def search(ctx, query, top_k, as_json):
    """Search memories by semantic similarity."""
    memory = _get_memory(ctx)
    results = memory.search(query, top_k=top_k)
    if as_json:
        click.echo(json.dumps([
            {"item_id": r.item_id if hasattr(r, "item_id") else str(r),
             "content": r.content if hasattr(r, "content") else str(r)}
            for r in results
        ], indent=2))
        return
    table = Table(title=f"Results for: {query}")
    table.add_column("ID", style="dim", max_width=12)
    table.add_column("Content")
    for r in results:
        item_id = r.item_id if hasattr(r, "item_id") else str(r)
        content = r.content if hasattr(r, "content") else str(r)
        table.add_row(item_id[:12], content[:120])
    console.print(table)


@main.command()
@click.pass_context
def rebuild(ctx):
    """Rebuild the vector index from existing graph data.

    This is a pure vector reindex — graph nodes are read but never written.
    It calls create_embeddings() + VectorStore().upsert() directly, the same
    two-step path that SmartMemory.add() uses internally after the graph write,
    but without the graph write itself. All node metadata (source, label, custom
    fields, etc.) is preserved from the serialized graph snapshot.
    """
    from smartmemory.plugins.embedding import create_embeddings
    from smartmemory.stores.vector.vector_store import VectorStore
    memory = _get_memory(ctx)
    data = memory._graph.backend.serialize()
    VectorStore().clear()
    count = 0
    skipped = 0
    for node in data.get("nodes", []):
        node_id = node.get("item_id") or node.get("id", "")
        # Properties dict holds all metadata stored alongside the node
        properties = node.get("properties") or {}
        content = properties.get("content") or node.get("content", "")
        if not (content and node_id):
            skipped += 1
            continue
        try:
            embedding = create_embeddings(content)
            if embedding is not None:
                VectorStore().upsert(
                    item_id=node_id,
                    embedding=embedding,
                    metadata=properties,
                    node_ids=[node_id],
                    is_global=False,
                )
                count += 1
            else:
                skipped += 1
        except Exception as exc:
            console.print(f"[yellow]Skipped {node_id}:[/yellow] {exc}")
            skipped += 1
    console.print(f"[green]Rebuilt:[/green] {count} items re-indexed", end="")
    if skipped:
        console.print(f" ([dim]{skipped} skipped[/dim])")
    else:
        console.print()


@main.command()
@click.argument("vault_path", type=click.Path(exists=True))
@click.pass_context
def watch(ctx, vault_path):
    """Watch a directory and auto-ingest new/changed markdown files."""
    try:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer
    except ImportError:
        console.print("[red]watchdog not installed.[/red] Run: pip install smartmemory-core[watch]")
        raise SystemExit(1)

    memory = _get_memory(ctx)

    class MarkdownHandler(FileSystemEventHandler):
        def on_created(self, event):
            if not event.is_directory and event.src_path.endswith(".md"):
                self._ingest(event.src_path)

        def on_modified(self, event):
            if not event.is_directory and event.src_path.endswith(".md"):
                self._ingest(event.src_path)

        def _ingest(self, path):
            try:
                content = Path(path).read_text(encoding="utf-8")
                from smartmemory.models.memory_item import MemoryItem as _MI
                _item = _MI(content=content, origin="cli:watch")
                item_id = memory.ingest(_item)
                console.print(f"[green]Ingested:[/green] {path} → {item_id}")
            except Exception as e:
                console.print(f"[red]Error ingesting {path}:[/red] {e}")

    observer = Observer()
    observer.schedule(MarkdownHandler(), vault_path, recursive=True)
    observer.start()
    console.print(f"[green]Watching:[/green] {vault_path} (Ctrl+C to stop)")
    try:
        import time
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()


@main.command()
@click.argument("text")
@click.option("--type", "anchor_type", default="spec",
              type=click.Choice(["spec", "scope", "decision", "constraint"]))
@click.option("--session", default="")
@click.pass_context
def anchor(ctx, text, anchor_type, session):
    """Set a spec anchor (requirement/constraint for anti-drift)."""
    memory = _get_memory(ctx)
    from smartmemory.anchors.manager import AnchorManager
    manager = AnchorManager(memory)
    item_id = manager.set(text, anchor_type, session)
    console.print(f"[green]Anchor set:[/green] {item_id} (type={anchor_type})")


@main.command()
@click.option("--session", default="")
@click.option("--type", "anchor_type", default=None,
              type=click.Choice(["spec", "scope", "decision", "constraint"]))
@click.pass_context
def anchors(ctx, session, anchor_type):
    """List active anchors."""
    memory = _get_memory(ctx)
    from smartmemory.anchors.manager import AnchorManager
    manager = AnchorManager(memory)
    items = manager.list(session, anchor_type)
    if not items:
        console.print("[dim]No active anchors.[/dim]")
        return
    for item in items:
        console.print(f"[bold][{item['anchor_type']}][/bold] {item['content']}")


@main.command(name="anchor-clear")
@click.option("--session", default="")
@click.option("--type", "anchor_type", default=None,
              type=click.Choice(["spec", "scope", "decision", "constraint"]))
@click.pass_context
def anchor_clear(ctx, session, anchor_type):
    """Clear active anchors."""
    memory = _get_memory(ctx)
    from smartmemory.anchors.manager import AnchorManager
    manager = AnchorManager(memory)
    count = manager.clear(session, anchor_type)
    console.print(f"[green]Cleared {count} anchor(s).[/green]")


# ------------------------------------------------------------------ #
# Sweep commands (SWEEP-1a)
# ------------------------------------------------------------------ #


@main.group()
@click.pass_context
def sweep(ctx):
    """Pipeline parameter sweep — measure and optimize config parameters."""
    pass


@sweep.command("run")
@click.option("--param", required=True, help="Parameter path (e.g. extraction.constrain.confidence_threshold)")
@click.option("--min", "range_min", type=float, required=True, help="Range minimum")
@click.option("--max", "range_max", type=float, required=True, help="Range maximum")
@click.option("--step", type=float, required=True, help="Step size")
@click.option("--sample-size", type=int, default=50, help="Number of recent items to replay")
@click.option("--output-dir", default=None, help="JSONL output dir (default: ~/.smartmemory/sweeps/)")
@click.pass_context
def sweep_run(ctx, param, range_min, range_max, step, sample_size, output_dir):
    """Run a single-parameter sweep. Auto-flushes Redis metrics first."""
    from smartmemory.sweep.config import SweepConfig, SweepParamConfig
    from smartmemory.sweep.metrics_store import SweepMetricsStore
    from smartmemory.sweep.runner import SweepRunner
    from smartmemory.sweep.scorer import SweepScorer

    memory = _get_memory(ctx)

    # Auto-flush Redis metrics to SQLite before sweeping
    try:
        from smartmemory.pipeline.metrics_consumer import MetricsConsumer
        db_path = Path.home() / ".smartmemory" / "sweep" / "metrics.db"
        store = SweepMetricsStore(db_path)
        consumer = MetricsConsumer()
        rows = store.flush_from_redis(consumer, hours=24)
        if rows:
            console.print(f"[dim]Flushed {rows} metric rows from Redis to SQLite.[/dim]")
        store.close()
    except Exception as e:
        console.print(f"[dim]Metrics flush skipped: {e}[/dim]")

    # Pull sample texts
    console.print(f"[dim]Pulling {sample_size} recent items...[/dim]")
    results = memory.search("", top_k=sample_size, sort_by="recency")
    sample_texts = [r.content for r in results if hasattr(r, "content") and r.content]
    if not sample_texts:
        console.print("[red]No items found to replay.[/red]")
        return
    console.print(f"[dim]Got {len(sample_texts)} items.[/dim]")

    # Build sweep config
    sweep_cfg = SweepConfig(
        params=[SweepParamConfig(
            parameter_path=param,
            range_min=range_min,
            range_max=range_max,
            step=step,
        )],
        sample_size=sample_size,
    )

    # Create pipeline runner for sweep (preview mode, no side-effects)
    if memory._pipeline_runner is None:
        memory._pipeline_runner = memory._create_pipeline_runner()

    console.print(f"[dim]Sweeping {param} from {range_min} to {range_max} step {step}...[/dim]")
    runner = SweepRunner(memory._pipeline_runner)
    result = runner.run(sweep_cfg, sample_texts)

    # Score
    scorer = SweepScorer()
    result = scorer.score(result)

    # Output report
    console.print()
    console.print(result.to_report())

    # Write JSONL
    out_dir = Path(output_dir) if output_dir else Path.home() / ".smartmemory" / "sweeps"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / "sweep-results.jsonl"
    with open(out_file, "a") as f:
        f.write(result.to_jsonl_line() + "\n")
    console.print(f"\n[dim]Results written to {out_file}[/dim]")


@sweep.command("flush")
@click.option("--hours", type=int, default=24, help="Hours of Redis history to flush")
@click.pass_context
def sweep_flush(ctx, hours):
    """Flush Redis metrics to persistent SQLite store."""
    from smartmemory.pipeline.metrics_consumer import MetricsConsumer
    from smartmemory.sweep.metrics_store import SweepMetricsStore

    db_path = Path.home() / ".smartmemory" / "sweep" / "metrics.db"
    store = SweepMetricsStore(db_path)
    try:
        consumer = MetricsConsumer()
        rows = store.flush_from_redis(consumer, hours=hours)
        console.print(f"[green]Flushed {rows} metric rows ({hours}h window).[/green]")
    except Exception as e:
        console.print(f"[red]Flush failed: {e}[/red]")
    finally:
        store.close()


@sweep.command("report")
@click.option("--param", default=None, help="Filter by parameter path")
@click.pass_context
def sweep_report(ctx, param):
    """Show latest sweep results from JSONL."""
    results_file = Path.home() / ".smartmemory" / "sweeps" / "sweep-results.jsonl"
    if not results_file.exists():
        console.print("[dim]No sweep results found. Run 'sweep run' first.[/dim]")
        return

    import json
    from smartmemory.sweep.result import SweepResult, SweepValueMetrics

    # Read all results, filter by param if specified
    with open(results_file) as f:
        lines = f.readlines()

    if not lines:
        console.print("[dim]No sweep results found.[/dim]")
        return

    # Show the most recent result (or most recent matching param)
    for line in reversed(lines):
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if param and data.get("parameter_path") != param:
            continue

        # Reconstruct result for report
        result = SweepResult(
            parameter_path=data["parameter_path"],
            primary_metric=data.get("primary_metric", ""),
            current_value=data["current_value"],
            recommended_value=data.get("recommended_value"),
            improvement_pct=data.get("improvement_pct", 0.0),
            tradeoff_narrative=data.get("tradeoff_narrative", ""),
            values_tested=[
                SweepValueMetrics(
                    value=v["value"],
                    metrics=v["metrics"],
                    sample_count=v["sample_count"],
                )
                for v in data.get("values_tested", [])
            ],
            started_at=data.get("started_at", ""),
            completed_at=data.get("completed_at", ""),
        )
        console.print(result.to_report())
        return

    console.print(f"[dim]No results found for param '{param}'.[/dim]")


@sweep.command("list-params")
@click.pass_context
def sweep_list_params(ctx):
    """List all sweepable PipelineConfig parameters with current values."""
    from smartmemory.pipeline.config import PipelineConfig
    from dataclasses import fields as dc_fields

    config = PipelineConfig.default()
    table = Table(title="Sweepable Parameters")
    table.add_column("Path", style="cyan")
    table.add_column("Value", style="green")
    table.add_column("Type", style="dim")

    def _walk(obj, prefix: str) -> None:
        for f in dc_fields(obj):
            if f.name.startswith("_"):
                continue
            val = getattr(obj, f.name)
            path = f"{prefix}.{f.name}" if prefix else f.name
            if isinstance(val, (int, float)) and not isinstance(val, bool):
                table.add_row(path, str(val), type(val).__name__)
            elif hasattr(val, "__dataclass_fields__"):
                _walk(val, path)

    _walk(config, "")
    console.print(table)
