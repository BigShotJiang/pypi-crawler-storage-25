from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class ScopeProvider(ABC):
    """
    Interface for providing isolation scope context to storage backends.
    Allows the service layer to define tenancy/policy, which the core library
    enforces transparently.
    """

    @abstractmethod
    def get_isolation_filters(self) -> Dict[str, Any]:
        """
        Return a dictionary of filters that MUST be applied to data queries.
        Example: {'tenant_id': 't1', 'workspace_id': 'w1'}
        Used for READ operations (MATCH, SEARCH).
        """
        pass

    @abstractmethod
    def get_write_context(self) -> Dict[str, Any]:
        """
        Return a dictionary of properties that MUST be written to new data.
        Example: {'tenant_id': 't1', 'created_by': 'u1'}
        Used for WRITE operations (CREATE, MERGE).
        """
        pass

    @abstractmethod
    def get_global_search_filters(self) -> Dict[str, Any]:
        """
        Return isolation filters for global/shared data searches.
        Excludes user-level isolation but keeps tenant/workspace boundaries.
        """
        pass

    @abstractmethod
    def get_user_isolation_key(self) -> str:
        """
        Return the field name used for user-level isolation.
        Allows backends to check for user-scoped vs global data without hardcoding.
        """
        pass

    @property
    def user_type(self) -> Optional[str]:
        """Return the user type ('human', 'agent', 'service') or None if unknown.

        Concrete implementations should override. Default returns None for
        backward compatibility with existing ScopeProvider subclasses.
        """
        return None

    def get_retrieval_filters(self) -> Dict[str, Any]:
        """CORE-SCOPE-1 structured filter contract (2026-04-17).

        Consumers that support OR-group composition (e.g. FalkorDB
        ``_build_scope_where``) call this instead of
        ``get_isolation_filters()``. Returns a dict with up to four named
        clauses that the consumer composes as::

            (workspace_clause AND user_clause AND tenant_clause)
            OR (personal_clause AND tenant_clause)

        Default implementation wraps the legacy flat filter in a
        workspace/user clause so pre-CORE-SCOPE-1 providers keep working —
        subclasses with PERSONAL-scope awareness should override.
        """
        flat = self.get_isolation_filters()
        if not flat:
            return {
                "workspace_clause": None,
                "personal_clause": None,
                "tenant_clause": None,
                "user_clause": None,
            }

        tenant_clause: Optional[Dict[str, Any]] = None
        if "tenant_id" in flat:
            tenant_clause = {"tenant_id": flat["tenant_id"]}

        workspace_kv: Dict[str, Any] = {}
        if "workspace_id" in flat:
            workspace_kv["workspace_id"] = flat["workspace_id"]
        workspace_clause = workspace_kv or None

        user_clause: Optional[Dict[str, Any]] = None
        if "user_id" in flat:
            user_clause = {"user_id": flat["user_id"]}

        return {
            "workspace_clause": workspace_clause,
            "personal_clause": None,
            "tenant_clause": tenant_clause,
            "user_clause": user_clause,
        }
