"""Graph name resolution for the split main-vs-ontology config contract.

CORE-GRAPHCONFIG-1 (2026-04-17): the single ``config.graph_db.graph_name``
key was overloaded across two semantically different graphs — the main
memory/data graph and the ontology graph — which caused a class of silent
drift bugs (most recently the 2026-04-15 Insights CI outage, where a stale
``"agentic_memory"`` default routed queries to an empty graph for 64
minutes before detection).

This module provides two resolvers that enforce the split:

    resolve_main_graph_name(config, explicit=None) -> str
    resolve_ontology_graph_name(config, explicit=None) -> str

Precedence, applied per resolver:

    1. ``explicit`` kwarg (highest — test overrides, constructor args).
    2. New key (``main_graph_name`` / ``ontology_graph_name``).
    3. Legacy ``graph_name`` (emits one-time deprecation warning per purpose).
    4. Raise ``ValueError`` — per ``.claude/rules/no-silent-degradation.md``,
       no hardcoded fallback; missing config is a deploy-time error.

See ``docs/features/CORE-GRAPHCONFIG-1/plan.md`` for rationale.
"""

from __future__ import annotations

import logging
from typing import Any, Optional, Set

logger = logging.getLogger(__name__)

# One-time warning gates — process-scoped. Tests may reset via
# ``_reset_deprecation_state()`` for isolation.
_warned_legacy_for: Set[str] = set()


def _reset_deprecation_state() -> None:
    """Testing helper — reset one-time-warning gates."""
    _warned_legacy_for.clear()


def _get(config: Any, key: str) -> Optional[str]:
    """Uniform key lookup for dict-like and ValidatedConfigDict-like configs.

    Returns None if the key is absent or present-but-empty.
    """
    if config is None:
        return None
    value: Any = None
    if hasattr(config, "get"):
        value = config.get(key)
    elif isinstance(config, dict):
        value = config.get(key)
    else:
        value = getattr(config, key, None)
    if value is None or value == "":
        return None
    return str(value)


def _resolve(
    config: Any,
    explicit: Optional[str],
    new_key: str,
    purpose: str,
) -> str:
    """Shared resolution logic for main and ontology resolvers.

    Args:
        config: dict-like config section (typically ``config.graph_db``).
        explicit: explicit override (constructor kwarg); highest priority.
        new_key: the purpose-specific key (``main_graph_name`` or
            ``ontology_graph_name``).
        purpose: human-readable label used in the deprecation warning.

    Returns:
        The resolved graph name.

    Raises:
        ValueError: when neither the new key nor the legacy key is set.
    """
    if explicit:
        return explicit

    new_value = _get(config, new_key)
    if new_value:
        return new_value

    legacy_value = _get(config, "graph_name")
    if legacy_value:
        if purpose not in _warned_legacy_for:
            _warned_legacy_for.add(purpose)
            logger.warning(
                "CORE-GRAPHCONFIG-1: reading %s graph name from legacy "
                "`config.graph_db.graph_name` (value=%r). Set "
                "`config.graph_db.%s` explicitly. The legacy key is "
                "deprecated and will be removed in a future release.",
                purpose,
                legacy_value,
                new_key,
            )
        return legacy_value

    raise ValueError(
        f"CORE-GRAPHCONFIG-1: no graph name configured for {purpose}. "
        f"Set `config.graph_db.{new_key}` (preferred) or the legacy "
        f"`config.graph_db.graph_name` (deprecated)."
    )


def resolve_main_graph_name(config: Any, explicit: Optional[str] = None) -> str:
    """Resolve the main (data) graph name.

    Used by ``FalkorDBBackend``, ``AsyncFalkorDBBackend``, the FalkorDB vector
    store, and any observability/analytics consumer that queries memory data.
    """
    return _resolve(config, explicit, "main_graph_name", "main")


def resolve_ontology_graph_name(config: Any, explicit: Optional[str] = None) -> str:
    """Resolve the ontology graph name.

    Used by the ontology store (``stores/ontology/falkordb.py``) and the
    ontology registry (``ontology/registry.py``).
    """
    return _resolve(config, explicit, "ontology_graph_name", "ontology")
