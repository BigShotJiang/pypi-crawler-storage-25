"""EnrichmentPipeline component for componentized memory ingestion pipeline.
Handles synchronous enrichment plugin execution with configurable plugin selection.
"""
import logging
from typing import Dict, Any, List

from smartmemory.memory.pipeline.components import PipelineComponent, ComponentResult
from smartmemory.memory.pipeline.config import EnrichmentConfig
from smartmemory.memory.pipeline.stages.enrichment import merge_enricher_result, flatten_enrichment_properties
from smartmemory.memory.pipeline.state import LinkingState
from smartmemory.memory.pipeline.transactions.change_set import ChangeOp, ChangeSet
from smartmemory.memory.ingestion.utils import sanitize_relation_type, flatten_to_graph_properties
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.utils.pipeline_utils import create_error_result

logger = logging.getLogger(__name__)


class EnrichmentPipeline(PipelineComponent[EnrichmentConfig]):
    """
    Component responsible for running enrichment plugins synchronously.
    Supports configurable plugin selection and execution order.
    """

    def __init__(self, enrichment_instance=None, memory_instance=None):
        if enrichment_instance is None:
            raise ValueError("EnrichmentPipeline requires a valid enrichment_instance")
        if memory_instance is None:
            raise ValueError("EnrichmentPipeline requires a valid memory_instance")
        self.enrichment = enrichment_instance
        self.memory = memory_instance

    def _add_derived_items(self, context: Dict[str, Any], enrichment_result: Dict[str, Any], *, preview_mode: bool = False, proposed_ops: List[ChangeOp] | None = None) -> List[
        str]:
        """Add new items from enrichment to memory graph and link them.

        In preview mode, append ChangeOps instead of mutating stores.
        """
        derived_ids: List[str] = []

        if not enrichment_result or not enrichment_result.get('new_items'):
            return derived_ids

        original_id = context.get('item_id')
        if not original_id:
            return derived_ids

        try:
            for i, new_item in enumerate(enrichment_result['new_items']):
                # Convert to MemoryItem if needed
                if not hasattr(new_item, 'item_id'):
                    if isinstance(new_item, dict):
                        mem_item = MemoryItem(**new_item)
                    else:
                        mem_item = MemoryItem(content=str(new_item))
                else:
                    mem_item = new_item

                if preview_mode:
                    # Propose node add and canonical edge
                    derived_id = getattr(mem_item, 'item_id', None) or f"derived_{i}"
                    derived_ids.append(derived_id)
                    if proposed_ops is not None:
                        try:
                            proposed_ops.append(ChangeOp(op_type='add_node', args={
                                'node_id': derived_id,
                                'properties': {
                                    'type': 'memory_node',
                                    'content': getattr(mem_item, 'content', None),
                                    'memory_type': getattr(mem_item, 'memory_type', None),
                                    'provenance': 'enrichment'
                                }
                            }))
                            proposed_ops.append(ChangeOp(op_type='add_edge', args={
                                'source': derived_id,
                                'target': original_id,
                                'relation_type': sanitize_relation_type('CANONICAL'),
                                'properties': {'provenance': 'enrichment'}
                            }))
                        except Exception:
                            # keep preview robust
                            pass
                    # Skip relation handling for preview
                else:
                    # Mutating path
                    derived_id = self.memory.add(mem_item)
                    derived_ids.append(derived_id)
                    try:
                        self.memory._graph.add_edge(
                            source_id=derived_id,
                            target_id=original_id,
                            edge_type=sanitize_relation_type('CANONICAL'),
                            properties={'provenance': 'enrichment'},
                        )
                    except Exception as e:
                        logger.warning(f"Failed to create CANONICAL edge {derived_id}->{original_id}: {e}")
                    # Handle relations/triples if present (omitted here)
        except Exception as e:
            logger.warning(f"Failed to add derived items: {e}")

        return derived_ids

    def validate_config(self, config: EnrichmentConfig) -> bool:
        """Validate EnrichmentPipeline configuration using typed config"""
        try:
            names = getattr(config, 'enricher_names', None)
            if names is not None and not isinstance(names, list):
                return False
            order = getattr(config, 'execution_order', 'parallel')
            if order not in ['parallel', 'sequential', 'priority']:
                return False
            edi = getattr(config, 'enable_derived_items', True)
            if not isinstance(edi, bool):
                return False
            return True
        except Exception:
            return False

    def prepare_context(self, linking_state: LinkingState) -> tuple[Dict[str, Any] | None, ComponentResult | None]:
        """Validate linking state, extract context, and rehydrate the MemoryItem.

        Returns:
            (context, None) on success, or (None, error_result) on failure.
        """
        if not linking_state or not linking_state.success:
            return None, create_error_result('enrichment_pipeline', ValueError('Invalid or failed linking state'))

        context = linking_state.data.get('context', {})
        if not context:
            return None, ComponentResult(
                success=False,
                data={'error': 'No context available from linking state'},
                metadata={'stage': 'enrichment_pipeline'}
            )

        # Rehydrate MemoryItem when Studio runs stages individually.
        # Linking state carries only item_id; enrichers need the live object.
        if 'item' not in context:
            _item_id = context.get('item_id')
            if not _item_id:
                return None, ComponentResult(
                    success=False,
                    data={'error': (
                        "Enrichment context missing both 'item' and 'item_id'. "
                        "Re-run extraction and linking for this run before enriching."
                    )},
                    metadata={'stage': 'enrichment_pipeline', 'error_type': 'ItemNotInContext'},
                )
            try:
                _item = self.memory.get(_item_id)
            except Exception as e:
                logger.warning("memory.get(%s) raised during enrichment rehydration: %s", _item_id, e)
                return None, ComponentResult(
                    success=False,
                    data={'error': (
                        f"Failed to load MemoryItem {_item_id} for enrichment: "
                        f"{type(e).__name__}: {e}. Start a new run if the backend is healthy."
                    )},
                    metadata={'stage': 'enrichment_pipeline', 'error_type': 'RehydrationFailed', 'item_id': _item_id},
                )
            if _item is None:
                return None, ComponentResult(
                    success=False,
                    data={'error': (
                        f"MemoryItem {_item_id} not found in memory store for this scope. "
                        f"Start a new run to recover — do not re-use this run_id."
                    )},
                    metadata={'stage': 'enrichment_pipeline', 'error_type': 'ItemNotFound', 'item_id': _item_id},
                )
            context['item'] = _item
            logger.info("Rehydrated MemoryItem %s into enrichment context (standalone stage)", _item_id)

        return context, None

    def finalize(
        self,
        context: Dict[str, Any],
        enrichment_result: Dict[str, Any],
        config: EnrichmentConfig,
        *,
        enrichment_success: bool = True,
        enrichment_error: str | None = None,
    ) -> ComponentResult:
        """Post-process enrichment results: derived items, graph properties, result packaging.

        Called after all enrichers have run (either by ``run()`` or by an
        external per-enricher loop that needs progress reporting).
        """
        preview_mode = bool(getattr(config, 'preview', False))
        proposed_ops: List[ChangeOp] = []

        # Add derived items from enrichment to memory graph
        derived_ids = []
        if enrichment_success and enrichment_result:
            derived_ids = self._add_derived_items(context, enrichment_result, preview_mode=preview_mode, proposed_ops=proposed_ops)

        # Apply enricher output to the source MemoryItem's graph node
        if enrichment_success and enrichment_result:
            _enrich_item_id = context.get('item_id') or getattr(context.get('item'), 'item_id', None)
            if _enrich_item_id:
                enrichment_props = flatten_to_graph_properties(enrichment_result)
                if enrichment_props:
                    if preview_mode:
                        try:
                            proposed_ops.append(ChangeOp(
                                op_type='set_properties',
                                args={'node_id': _enrich_item_id, 'properties': enrichment_props},
                            ))
                        except Exception as e:
                            logger.warning("Preview: failed to propose set_properties for %s: %s", _enrich_item_id, e)
                    else:
                        try:
                            self.memory.update_properties(_enrich_item_id, enrichment_props)
                            logger.info("Applied %d enrichment properties to memory item %s", len(enrichment_props), _enrich_item_id)
                        except Exception as e:
                            logger.warning("Failed to apply enrichment properties to %s: %s", _enrich_item_id, e)

        # Preview mode: propose edges from enricher-produced relations/triples
        proposed_relation_edges = 0
        if preview_mode and enrichment_success and enrichment_result:
            def _append_edge(src: Any, rel_type: Any, tgt: Any, props: Dict[str, Any] | None = None):
                nonlocal proposed_relation_edges
                try:
                    proposed_ops.append(ChangeOp(op_type='add_edge', args={
                        'source': src, 'target': tgt,
                        'relation_type': sanitize_relation_type(rel_type) if isinstance(rel_type, str) else (rel_type or 'RELATED'),
                        'properties': props or {}
                    }))
                    proposed_relation_edges += 1
                except Exception:
                    pass

            def _process_relations_payload(payload: Dict[str, Any]):
                rels = (payload.get('relations') or []) if isinstance(payload, dict) else []
                for rel in rels:
                    if isinstance(rel, dict):
                        src = rel.get('source') or rel.get('source_id') or rel.get('from')
                        tgt = rel.get('target') or rel.get('target_id') or rel.get('to')
                        rtype = rel.get('relation_type') or rel.get('type') or 'RELATED'
                        props = rel.get('properties') or rel.get('metadata') or {}
                        if src and tgt:
                            _append_edge(src, rtype, tgt, props)
                    elif isinstance(rel, (list, tuple)) and len(rel) == 3:
                        src, rtype, tgt = rel
                        if src and tgt:
                            _append_edge(src, rtype, tgt, {})

            _process_relations_payload(enrichment_result)
            if isinstance(enrichment_result, dict):
                for k, v in enrichment_result.items():
                    if isinstance(v, dict) and str(k).startswith('plugin_'):
                        _process_relations_payload(v)

        # Separate enriched data from plugin-specific results
        enriched_data = {}
        plugin_results = {}
        if enrichment_result:
            for key, value in enrichment_result.items():
                if key.startswith('plugin_'):
                    plugin_results[key] = value
                else:
                    enriched_data[key] = value

        enricher_names = getattr(config, 'enricher_names', None)
        enrichment_metadata = {
            'enrichers_requested': enricher_names or ['all'],
            'enrichment_success': enrichment_success,
            'enrichment_error': enrichment_error,
            'derived_items_created': len(derived_ids),
            'execution_order': getattr(config, 'execution_order', 'parallel'),
            'plugins_executed': len(plugin_results)
        }
        if preview_mode:
            enrichment_metadata['proposed_relation_edges'] = proposed_relation_edges

        provenance_candidates = context.get('provenance_candidates', [])
        if enrichment_result and 'provenance_candidates' in enrichment_result:
            provenance_candidates.extend(enrichment_result['provenance_candidates'])

        result_data: Dict[str, Any] = {
            'enriched_data': enriched_data,
            'plugin_results': plugin_results,
            'enrichment_metadata': enrichment_metadata,
            'derived_ids': derived_ids,
            'provenance_candidates': provenance_candidates,
            'context': context,
        }
        if not enrichment_success:
            result_data['error'] = enrichment_error or 'Enrichment failed'

        if preview_mode and proposed_ops:
            cs = ChangeSet.new(stage='enrichment', plugin='EnrichmentPipeline', run_id=getattr(config, 'run_id', None))
            cs.ops.extend(proposed_ops)
            result_data['change_set'] = {'change_set_id': cs.change_set_id, 'ops_count': len(cs.ops)}
            result_data['change_set_ops'] = [{'op_type': op.op_type, 'args': op.args} for op in proposed_ops]

        return ComponentResult(
            success=enrichment_success,
            data=result_data,
            metadata={
                'stage': 'enrichment_pipeline',
                'plugins_count': len(plugin_results),
                'derived_items': len(derived_ids),
                **({"error_type": "EnrichmentFailed"} if not enrichment_success else {}),
            }
        )

    def run(self, linking_state: LinkingState, config: EnrichmentConfig) -> ComponentResult:
        """Execute EnrichmentPipeline: prepare context, run enrichers, finalize results."""
        try:
            context, err = self.prepare_context(linking_state)
            if err:
                return err

            enricher_names = getattr(config, 'enricher_names', None)
            if enricher_names:
                context['enricher_names'] = enricher_names

            enricher_configs = getattr(config, 'enricher_configs', None) or {}
            memory_id = context.get('item_id')
            _enricher_names = enricher_names or ['all']

            try:
                with trace_span("pipeline.enrich", {"memory_id": memory_id, "enricher_names": _enricher_names}):
                    if enricher_names:
                        enrichment_result = {}
                        for enricher_name in enricher_names:
                            partial = self.enrichment.enrich(
                                context, enricher_names=[enricher_name], enricher_configs=enricher_configs
                            )
                            merge_enricher_result(enrichment_result, partial)
                        enrichment_result = flatten_enrichment_properties(enrichment_result)
                    else:
                        enrichment_result = self.enrichment.enrich(context, enricher_configs=enricher_configs)
                return self.finalize(context, enrichment_result, config)
            except Exception as e:
                logger.warning(f"Enrichment failed: {e}")
                return self.finalize(context, {}, config, enrichment_success=False, enrichment_error=str(e))

        except Exception as e:
            return create_error_result('enrichment_pipeline', e)
