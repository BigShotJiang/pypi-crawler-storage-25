"""GroundingEngine component for componentized memory ingestion pipeline.
Handles synchronous grounding with external knowledge bases and provenance linking.
"""
import logging
from typing import Dict, Any, List, Optional

from smartmemory.memory.pipeline.components import PipelineComponent, ComponentResult
from smartmemory.memory.pipeline.config import GroundingConfig
from smartmemory.memory.pipeline.state import EnrichmentState
from smartmemory.memory.pipeline.transactions.change_set import ChangeOp
from smartmemory.memory.ingestion.utils import flatten_to_graph_properties
from smartmemory.observability.tracing import trace_span
from smartmemory.utils.pipeline_utils import create_error_result

logger = logging.getLogger(__name__)


class GroundingEngine(PipelineComponent[GroundingConfig]):
    """
    Component responsible for grounding entities with external knowledge bases.
    Creates GROUNDED_IN edges for provenance candidates and KB matches.
    """

    def __init__(self, grounding_instance=None, memory_instance=None):
        if grounding_instance is None:
            raise ValueError("GroundingEngine requires a valid grounding_instance")
        self.grounding = grounding_instance
        # Optional: when provided, GroundingEngine writes its structured
        # results (grounded_entities, kb_matches, filtered_matches) back
        # onto the source memory item via memory.update_properties(). The
        # underlying grounder (PublicKnowledgeGrounder) already creates
        # wikidata nodes + GROUNDED_IN edges; this adds the per-item
        # metadata so search/retrieval can filter by "has been grounded".
        # Backwards compatible: if None, writes are skipped (legacy behavior).
        self.memory = memory_instance

    def ground_with_wikipedia(self, context: Dict[str, Any], *, preview: bool = False) -> Dict[str, Any]:
        """Ground entities with Wikipedia data.

        Tries two paths in order:

        1. **Legacy enricher path.** Reads pre-populated `wikipedia_data` from
           the enrichment context.  In current pipelines no registered
           enricher populates this — `WikipediaEnricher` was retired and moved
           to `plugins/grounders/wikipedia.py` as the `wikipedia_grounder`
           plugin — but the code path is preserved for backward compat in
           case a custom enricher provides it.

        2. **Direct grounder path.** When `wikipedia_data` is empty, pull
           entities from the linking state in `context['node_ids']
           ['semantic_entities']` and call the registered grounder plugin
           (`self.grounding.default_grounder`) directly.  The grounder
           creates `wikipedia:<name>` nodes and `GROUNDED_IN` edges in the
           graph and returns a list of node IDs; we look each up to build
           the structured kb_matches dict the Studio panel expects.

        Until 2026-04-12 only path 1 existed, which meant grounding was a
        permanent no-op (`grounding_kb_matches_count: 0` on every run) ever
        since the WikipediaEnricher was retired — a `STUDIO-GROUND-1` gap
        flagged in the session resume doc but never tracked.  Adding path 2
        wires the existing grounder plugin into the engine so KB matches
        actually surface in the Studio enrichment panel.
        """
        grounded_entities = []
        kb_matches = {}

        # Path 1: legacy enricher-populated wikipedia_data (preserved for
        # backward compat — no built-in enricher uses this anymore).
        enrichment_result = context.get('enrichment_result') or {}
        wiki_data = enrichment_result.get('wikipedia_data') or {}
        if wiki_data:
            for entity_name, wiki_info in wiki_data.items():
                if isinstance(wiki_info, dict) and 'url' in wiki_info:
                    grounded_entities.append({
                        'entity': entity_name,
                        'source': 'wikipedia',
                        'url': wiki_info['url'],
                        'title': wiki_info.get('title', entity_name),
                        'summary': wiki_info.get('summary', '')
                    })
                    kb_matches[entity_name] = {
                        'source': 'wikipedia',
                        'confidence': wiki_info.get('confidence', 0.8),
                        'metadata': wiki_info
                    }

        # Path 2: direct grounding via the registered grounder plugin.
        # Fires when the legacy path produced nothing — i.e. the common case
        # in current pipelines.  Reads entities from the linking state and
        # delegates to whichever grounder plugin is registered (typically
        # `wikipedia_grounder`).  The grounder is responsible for the
        # network call and graph mutations; we just translate its output
        # into the kb_matches shape the Studio panel reads.
        #
        # Skipped in preview mode because the grounder plugin is mutating
        # (writes wikipedia nodes + GROUNDED_IN edges immediately).
        # GroundingEngine.run() advertises preview as non-mutating; calling
        # the grounder here would violate that contract.  (Codex review
        # 2026-04-12 flagged this — the first version did not check.)
        if not kb_matches and self.grounding is not None and not preview:
            grounder = getattr(self.grounding, 'default_grounder', None)
            graph = getattr(self.grounding, 'graph', None)
            if grounder is None or graph is None:
                logger.warning(
                    "Direct grounding skipped: no plugin grounder registered "
                    "(grounder=%s, graph=%s).  Check that "
                    "smartmemory.plugins.grounders is on the plugin path and "
                    "that wikipedia_grounder loaded.",
                    grounder, graph,
                )
            else:
                node_ids = (
                    context.get('node_ids')
                    or context.get('entity_ids')
                    or {}
                )
                entities = node_ids.get('semantic_entities') or []
                if not entities:
                    logger.info(
                        "Direct grounding skipped: no semantic_entities in "
                        "linking state for item %s.  Did the linking stage "
                        "run before grounding?",
                        context.get('item_id') or 'unknown',
                    )
                else:
                    item = context.get('item')
                    try:
                        wiki_node_ids = grounder.ground(item, entities, graph) or []
                        logger.info(
                            "Direct wikipedia grounding produced %d wiki "
                            "nodes from %d entities (item=%s)",
                            len(wiki_node_ids), len(entities),
                            context.get('item_id') or 'unknown',
                        )
                    except Exception as e:
                        logger.warning(
                            "Direct wikipedia grounding raised %s: %s",
                            type(e).__name__, e,
                        )
                        wiki_node_ids = []

                    # Build kb_matches by reading each created/reused wiki
                    # node back from the graph.  The grounder writes the
                    # entity name, summary, and URL onto the node already.
                    for wiki_id in wiki_node_ids:
                        try:
                            wiki_node = graph.get_node(wiki_id)
                        except Exception as e:
                            logger.debug(
                                "Failed to read wiki node %s: %s",
                                wiki_id, e,
                            )
                            continue
                        if wiki_node is None:
                            continue
                        # The node may be a raw dict (FalkorDB direct read)
                        # or a MemoryItem-like object depending on backend.
                        if isinstance(wiki_node, dict):
                            entity_name = (
                                wiki_node.get('entity')
                                or wiki_node.get('title')
                                or wiki_id
                            )
                            url = wiki_node.get('url')
                            summary = wiki_node.get('summary', '') or ''
                        else:
                            meta = getattr(wiki_node, 'metadata', None) or {}
                            entity_name = (
                                meta.get('entity')
                                or meta.get('title')
                                or wiki_id
                            )
                            url = meta.get('url')
                            summary = meta.get('summary', '') or ''

                        grounded_entities.append({
                            'entity': entity_name,
                            'source': 'wikipedia',
                            'url': url,
                            'title': entity_name,
                            'summary': summary,
                        })
                        kb_matches[entity_name] = {
                            'source': 'wikipedia',
                            'confidence': 0.8,
                            'metadata': {
                                'url': url,
                                'summary': summary,
                            },
                        }

        return {
            'grounded_entities': grounded_entities,
            'kb_matches': kb_matches,
            'wikipedia_matches': len(grounded_entities)
        }

    def ground_with_custom_kb(self, context: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
        """Ground entities with custom knowledge bases"""
        grounded_entities = []
        kb_matches = {}

        # Custom KB grounding logic would go here
        # For now, this is a placeholder implementation
        kb_sources = config.get('knowledge_bases', [])

        for kb_source in kb_sources:
            # Placeholder for custom KB integration
            pass

        return {
            'grounded_entities': grounded_entities,
            'kb_matches': kb_matches,
            'custom_kb_matches': len(grounded_entities)
        }

    def validate_config(self, config: GroundingConfig) -> bool:
        """Validate GroundingEngine configuration using typed config"""
        try:
            kb_sources = getattr(config, 'knowledge_bases', [])
            if kb_sources is not None and not isinstance(kb_sources, list):
                return False
            strategy = getattr(config, 'grounding_strategy', 'wikipedia')
            if strategy not in ['wikipedia', 'custom', 'both', 'none', 'hybrid', 'knowledge_base']:
                return False
            ct = float(getattr(config, 'confidence_threshold', 0.7))
            if not (0.0 <= ct <= 1.0):
                return False
            return True
        except Exception:
            return False

    def run(
        self,
        enrichment_state: EnrichmentState,
        config: GroundingConfig,
        proposed_ops: Optional[List[ChangeOp]] = None,
    ) -> ComponentResult:
        """
        Execute GroundingEngine with given enrichment state and configuration.

        Args:
            enrichment_state: EnrichmentState from previous stage with enrichment results
            config: Grounding configuration dict
            proposed_ops: Optional ChangeOp list. If provided AND
                config.preview is True, the engine appends a set_properties
                ChangeOp instead of mutating the graph directly. Mirrors the
                preview pattern used by EnrichmentPipeline.

        Returns:
            ComponentResult with grounding results and metadata
        """
        preview_mode = bool(getattr(config, 'preview', False))
        if proposed_ops is None:
            proposed_ops = []
        try:
            if not enrichment_state or not enrichment_state.success:
                return create_error_result('grounding_engine', ValueError('Invalid or failed enrichment state'))

            # Extract context and provenance candidates
            context = enrichment_state.data.get('context', {})
            provenance_candidates = enrichment_state.data.get('provenance_candidates', [])

            if not context:
                return ComponentResult(
                    success=False,
                    data={'error': 'No context available from enrichment state'},
                    metadata={'stage': 'grounding_engine'}
                )

            # Initialize grounding results
            all_grounded_entities = []
            all_kb_matches = {}
            grounding_metadata = {
                'grounding_strategy': getattr(config, 'grounding_strategy', 'wikipedia'),
                'confidence_threshold': getattr(config, 'confidence_threshold', 0.7),
                'provenance_candidates_count': len(provenance_candidates)
            }

            # Perform grounding based on strategy
            strategy = getattr(config, 'grounding_strategy', 'wikipedia')

            if strategy in ['wikipedia', 'both']:
                # Ground with Wikipedia
                wiki_results = self.ground_with_wikipedia(context, preview=preview_mode)
                all_grounded_entities.extend(wiki_results['grounded_entities'])
                all_kb_matches.update(wiki_results['kb_matches'])
                grounding_metadata['wikipedia_matches'] = wiki_results['wikipedia_matches']

            if strategy in ['custom', 'both']:
                # Ground with custom knowledge bases
                # Convert subset to dict for the helper expecting dict
                custom_results = self.ground_with_custom_kb(context, {'knowledge_bases': getattr(config, 'knowledge_bases', [])})
                all_grounded_entities.extend(custom_results['grounded_entities'])
                all_kb_matches.update(custom_results['kb_matches'])
                grounding_metadata['custom_kb_matches'] = custom_results['custom_kb_matches']

            # Use the grounding module for provenance candidates.
            # Skip if the direct grounding path in _ground_with_wikipedia
            # already grounded entities (all_kb_matches would be non-empty)
            # — calling self.grounding.ground() again would invoke the same
            # grounder plugin on the same entity set, causing double graph
            # churn.  (Codex review 2026-04-12 flagged this.)
            grounding_success = True
            grounding_error = None

            if provenance_candidates and strategy != 'none' and not all_kb_matches:
                try:
                    # Add provenance candidates to context for grounding
                    context['provenance_candidates'] = provenance_candidates
                    with trace_span("pipeline.ground", {"memory_id": context.get('item_id'), "strategy": strategy, "provenance_candidate_count": len(provenance_candidates)}):
                        self.grounding.ground(context)
                    grounding_metadata['provenance_grounding_success'] = True
                except Exception as e:
                    grounding_success = False
                    grounding_error = str(e)
                    grounding_metadata['provenance_grounding_success'] = False
                    logger.warning(f"Provenance grounding failed: {e}")

            # Filter results by confidence threshold
            confidence_threshold = getattr(config, 'confidence_threshold', 0.7)
            filtered_matches = {}
            for entity, match_info in all_kb_matches.items():
                if match_info.get('confidence', 0.0) >= confidence_threshold:
                    filtered_matches[entity] = match_info

            # Update grounding metadata
            grounding_metadata.update({
                'total_entities_processed': len(all_grounded_entities),
                'high_confidence_matches': len(filtered_matches),
                'grounding_success': grounding_success,
                'grounding_error': grounding_error
            })

            result_data = {
                'grounded_entities': all_grounded_entities,
                'kb_matches': all_kb_matches,
                'filtered_matches': filtered_matches,
                'grounding_metadata': grounding_metadata,
                'context': context  # Pass final context
            }
            if not grounding_success:
                result_data['error'] = grounding_error or 'Grounding failed'

            # Apply grounding metadata to the source MemoryItem's graph node
            # so search/retrieval can filter by "has been grounded" and see
            # what KB matches the item carries. The underlying grounder
            # (PublicKnowledgeGrounder) already writes wikidata nodes and
            # GROUNDED_IN edges; this is the per-item metadata that was
            # missing — without it, the structured grounding results lived
            # only in pipeline_stage_states (Mongo) and never reached the
            # graph itself.
            #
            # We use a `grounding_` prefix on every property to avoid
            # collisions with enrichment fields (e.g. enrichment may write
            # `summary` from the basic enricher; grounding writes its own
            # summary statistics).
            #
            # Skipped if `memory_instance` was not passed at construction
            # time (preserves backwards compatibility with callers that only
            # built GroundingEngine(grounding_instance=...) on older API).
            if grounding_success and self.memory is not None:
                _ground_item_id = context.get('item_id') or getattr(
                    context.get('item'), 'item_id', None,
                )
                if _ground_item_id:
                    # Build a flat property bag from the structured results.
                    # We exclude grounded_entities/kb_matches/filtered_matches
                    # from the body and instead include just their counts and
                    # JSON-serialized form under a single property each, so
                    # node properties stay reasonable in size.
                    grounding_payload = {
                        'grounded_entities_count': len(all_grounded_entities),
                        'kb_matches_count': len(all_kb_matches),
                        'high_confidence_matches_count': len(filtered_matches),
                        'kb_matches': all_kb_matches,
                        'filtered_matches': filtered_matches,
                        'grounding_metadata': grounding_metadata,
                    }
                    grounding_props = flatten_to_graph_properties(
                        grounding_payload,
                        key_prefix='grounding_',
                    )
                    if grounding_props:
                        if preview_mode:
                            try:
                                proposed_ops.append(ChangeOp(
                                    op_type='set_properties',
                                    args={
                                        'node_id': _ground_item_id,
                                        'properties': grounding_props,
                                    },
                                ))
                            except Exception as e:
                                logger.warning(
                                    "Preview: failed to propose grounding "
                                    "set_properties for %s: %s",
                                    _ground_item_id, e,
                                )
                        else:
                            try:
                                self.memory.update_properties(
                                    _ground_item_id, grounding_props,
                                )
                                logger.info(
                                    "Applied %d grounding properties to "
                                    "memory item %s",
                                    len(grounding_props), _ground_item_id,
                                )
                            except Exception as e:
                                logger.warning(
                                    "Failed to apply grounding properties "
                                    "to %s: %s",
                                    _ground_item_id, e,
                                )

            return ComponentResult(
                success=grounding_success,
                data=result_data,
                metadata={
                    'stage': 'grounding_engine',
                    'entities_grounded': len(all_grounded_entities),
                    'kb_sources_used': len(getattr(config, 'knowledge_bases', []) or []) + (1 if strategy in ['wikipedia', 'both'] else 0),
                    **({"error_type": "GroundingFailed"} if not grounding_success else {}),
                }
            )

        except Exception as e:
            return create_error_result('grounding_engine', e)
