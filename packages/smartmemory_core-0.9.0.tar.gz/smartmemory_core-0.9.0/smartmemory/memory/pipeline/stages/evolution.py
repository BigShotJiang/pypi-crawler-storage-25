"""
Evolution orchestrator component for SmartMemory.
Handles all evolution logic and coordination between memory types.
"""

import logging
from typing import List, Optional, Dict, Any

from smartmemory.evolution.flow import EvolutionFlow
from smartmemory.evolution.registry import EVOLVER_REGISTRY

logger = logging.getLogger(__name__)


class EvolutionOrchestrator:
    """
    Orchestrates evolution processes between memory types.
    Eliminates mixed abstractions by centralizing evolution logic.
    """

    def __init__(self, smart_memory):
        """
        Initialize with reference to the smartmemory instance for evolution operations.

        Args:
            smart_memory: The SmartMemory instance to operate on
        """
        self.smart_memory = smart_memory
        # Optional dynamic DAG workflow (set at runtime by Studio)
        self._workflow: Optional[EvolutionFlow] = None

    def run_evolution_cycle(self):
        """
        Run evolution cycle.  CORE-MEMORY-DYNAMICS-1 M1b: the former
        ``commit_working_to_episodic`` / ``commit_working_to_procedural``
        paths have been removed — the ConsolidationRouter now routes at
        ingest time and retroactive promotion from a ``working`` bucket is
        obsolete.

        Filtering is handled automatically by ScopeProvider in all operations.
        """
        # Workflow mode (Studio) — honored if set.
        if self._workflow:
            logger.info("Using dynamic evolution workflow from Studio")
            return self._workflow.run(self.smart_memory)

        # Default: no-op in M1b.  Workflow-driven evolution covers the
        # full evolver DAG when Studio configures one; the ambient
        # "promote from working" default is retired.
        logger.info("Running default evolution cycle (no-op; router-driven)")

    # ------------------------------
    # Dynamic DAG workflow support
    # ------------------------------
    def set_workflow(self, dag: "EvolutionFlow") -> None:
        """Install a dynamic DAG to drive evolution (built at runtime)."""
        if not isinstance(dag, EvolutionFlow):
            raise TypeError("dag must be an EvolutionFlow")
        dag.validate_acyclic()
        self._workflow = dag

    def get_workflow(self) -> Optional["EvolutionFlow"]:
        return getattr(self, "_workflow", None)

    def run_workflow(self, context: Optional[Dict[str, Any]] = None, stop_on_error: bool = False) -> Dict[str, Any]:
        """
        Execute the currently installed DAG. Conditions are callables evaluated at runtime.

        CORE-EVO-REPORT-1: the returned `results` dict propagates each evolver's
        `EvolverResult.to_dict()` under the node_id, so Studio / Insights can
        surface per-item drill-down instead of relying on coarse node/edge-count
        deltas.

        Returns:
          {
            "executed": [node_ids],
            "skipped":  [node_ids],
            "errors":   {node_id: str},
            "results":  {node_id: {summary, created_ids, updated_ids, deleted_ids, stats, notes}}
          }
        """
        dag = getattr(self, "_workflow", None)
        if not dag:
            raise RuntimeError("No workflow set. Call set_workflow() first.")
        dag.validate_acyclic()
        order = dag.topological_order()
        executed: List[str] = []
        skipped: List[str] = []
        errors: Dict[str, str] = {}
        results: Dict[str, Dict[str, Any]] = {}

        for node_id in order:
            node = dag.nodes[node_id]
            try:
                should_run = True
                if node.condition is not None:
                    should_run = bool(node.condition(self.smart_memory, context))
                if not should_run:
                    skipped.append(node_id)
                    continue

                # Resolve via registry key (preferred) or dotted path fallback
                evolver_cls = EVOLVER_REGISTRY.try_resolve(node.evolver_path)
                if evolver_cls is None:
                    raise ImportError(f"Could not resolve evolver '{node.evolver_path}' from registry or dotted path")
                evolver = evolver_cls(config=getattr(self.smart_memory, "config", {}))

                # Allow extra params for evolve
                params = node.params or {}
                result = evolver.evolve(self.smart_memory, logger=logger, **params)
                if hasattr(result, "to_dict"):
                    results[node_id] = result.to_dict()
                    summary_txt = getattr(result, "summary", type(result).__name__)
                else:
                    # Legacy evolver returning None (pre-CORE-EVO-REPORT-1)
                    logger.warning(
                        f"Workflow node '{node_id}' evolver {type(evolver).__name__} "
                        f"returned {type(result).__name__} — expected EvolverResult. "
                        f"Update evolver per CORE-EVO-REPORT-1."
                    )
                    summary_txt = type(result).__name__ if result is not None else "None"
                logger.info(
                    f"Workflow node '{node_id}' executed: {type(evolver).__name__} -> {summary_txt}"
                )
                executed.append(node_id)
            except Exception as e:
                logger.exception(f"Workflow node '{node_id}' failed: {e}")
                errors[node_id] = str(e)
                if stop_on_error:
                    break

        return {"executed": executed, "skipped": skipped, "errors": errors, "results": results}

    # CORE-MEMORY-DYNAMICS-1 M1b: removed ``commit_working_to_episodic``,
    # ``commit_working_to_procedural``, ``_fallback_working_to_episodic``,
    # ``_fallback_working_to_procedural``, ``should_evolve_working_to_episodic``,
    # ``should_evolve_working_to_procedural``.  The ConsolidationRouter's at-ingest
    # routing replaces the retroactive-promotion pattern.  Public façades on
    # ``SmartMemory`` and ``EvolutionManager`` were removed in the same commit.


# ------------------------------
# DAG primitives
# ------------------------------
