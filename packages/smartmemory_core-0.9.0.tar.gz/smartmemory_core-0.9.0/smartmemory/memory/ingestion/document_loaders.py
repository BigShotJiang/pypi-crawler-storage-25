"""Document loaders for ingest_document() orchestration (CORE-STRUCT-DOC-1).

All loaders are lazy-imported — optional dependencies (trafilatura, pymupdf,
python-docx) are NOT required at import time. Missing deps raise ImportError
with a clear pip install hint (no silent degradation per no-silent-degradation.md).
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Protocol

logger = logging.getLogger(__name__)

_INSTALL_HINT = "pip install 'smartmemory-core[docs]'"


@dataclass
class LoadedDocument:
    """Result of a document load operation."""

    content: str
    title: str | None
    source_url: str
    file_type: str
    page_count: int


class DocumentLoader(Protocol):
    """Structural protocol for document loaders."""

    def load(self, source: str) -> LoadedDocument: ...


class TXTLoader:
    """Plain-text loader — no optional dependencies."""

    def load(self, source: str) -> LoadedDocument:
        with open(source, encoding="utf-8", errors="replace") as fh:
            content = fh.read()
        return LoadedDocument(
            content=content,
            title=os.path.basename(source),
            source_url=os.path.abspath(source),
            file_type="txt",
            page_count=1,
        )


class MarkdownLoader:
    """Markdown loader — no optional dependencies; strips fenced code blocks for clean text."""

    def load(self, source: str) -> LoadedDocument:
        import re

        with open(source, encoding="utf-8", errors="replace") as fh:
            raw = fh.read()

        # Extract title from first H1
        title_match = re.search(r"^#\s+(.+)$", raw, re.MULTILINE)
        title = title_match.group(1).strip() if title_match else os.path.basename(source)

        return LoadedDocument(
            content=raw,
            title=title,
            source_url=os.path.abspath(source),
            file_type="markdown",
            page_count=1,
        )


class HTMLLoader:
    """HTML/URL loader using trafilatura for clean text extraction."""

    def load(self, source: str) -> LoadedDocument:
        try:
            import trafilatura
        except ImportError as exc:
            raise ImportError(
                f"HTML loading requires trafilatura: {_INSTALL_HINT}"
            ) from exc

        is_url = source.startswith("http://") or source.startswith("https://")
        if is_url:
            raw_html = trafilatura.fetch_url(source)
            canonical = source
        else:
            with open(source, encoding="utf-8", errors="replace") as fh:
                raw_html = fh.read()
            canonical = os.path.abspath(source)

        if not raw_html:
            raise ValueError(f"Could not fetch or read HTML content from: {source}")

        content = trafilatura.extract(raw_html, include_comments=False, include_tables=True) or ""
        metadata = trafilatura.extract_metadata(raw_html)
        title = metadata.title if metadata else None

        if not content:
            logger.warning("trafilatura returned empty content for %s", source)
            content = raw_html  # fall back to raw HTML rather than silently empty

        return LoadedDocument(
            content=content,
            title=title,
            source_url=canonical,
            file_type="html",
            page_count=1,
        )


class PDFLoader:
    """PDF loader using pymupdf."""

    def load(self, source: str) -> LoadedDocument:
        try:
            import fitz  # pymupdf
        except ImportError as exc:
            raise ImportError(
                f"PDF loading requires pymupdf: {_INSTALL_HINT}"
            ) from exc

        doc = fitz.open(source)
        pages = [page.get_text() for page in doc]
        content = "\n\n".join(p for p in pages if p.strip())
        title = doc.metadata.get("title") or os.path.basename(source)
        page_count = len(doc)
        doc.close()

        return LoadedDocument(
            content=content,
            title=title or None,
            source_url=os.path.abspath(source),
            file_type="pdf",
            page_count=page_count,
        )


class DOCXLoader:
    """DOCX loader using python-docx."""

    def load(self, source: str) -> LoadedDocument:
        try:
            import docx
        except ImportError as exc:
            raise ImportError(
                f"DOCX loading requires python-docx: {_INSTALL_HINT}"
            ) from exc

        doc = docx.Document(source)
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        content = "\n\n".join(paragraphs)

        # First non-empty paragraph often serves as title; if it's short, use it
        title = paragraphs[0] if paragraphs and len(paragraphs[0]) < 120 else os.path.basename(source)

        return LoadedDocument(
            content=content,
            title=title or None,
            source_url=os.path.abspath(source),
            file_type="docx",
            page_count=1,
        )


_LOADERS: dict[str, DocumentLoader] = {
    "html": HTMLLoader(),
    "pdf": PDFLoader(),
    "docx": DOCXLoader(),
    "txt": TXTLoader(),
    "markdown": MarkdownLoader(),
}


def detect_source_type(source: str) -> str:
    """Infer document type from URL scheme or file extension."""
    if source.startswith("http://") or source.startswith("https://"):
        return "html"
    lower = source.lower()
    if lower.endswith(".pdf"):
        return "pdf"
    if lower.endswith(".docx"):
        return "docx"
    if lower.endswith(".md") or lower.endswith(".markdown"):
        return "markdown"
    if lower.endswith(".html") or lower.endswith(".htm"):
        return "html"
    return "txt"


def load_document(source: str, source_type: str = "auto") -> LoadedDocument:
    """Load a document from a URL or file path.

    Args:
        source: URL or absolute/relative file path.
        source_type: One of "html", "pdf", "docx", "txt", "markdown", or "auto".
                     "auto" detects from URL/extension.

    Returns:
        LoadedDocument with content, title, and metadata.

    Raises:
        ImportError: If the required optional dependency is not installed.
        ValueError: If source_type is unrecognised or source is unreadable.
    """
    if source_type == "auto":
        source_type = detect_source_type(source)

    loader = _LOADERS.get(source_type)
    if loader is None:
        raise ValueError(
            f"Unknown source_type '{source_type}'. "
            f"Supported: {', '.join(sorted(_LOADERS.keys()))}"
        )

    logger.debug("Loading document type=%s source=%s", source_type, source)
    return loader.load(source)
