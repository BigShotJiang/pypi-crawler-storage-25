"""Conversation container handler (RLM-1g).

INDEXED strategy: lightweight container node linking session chunks via PART_OF edges.
No embedding — this is a structural node, not searchable content.
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class ConversationHandler:
    """Structured handler for conversation container nodes."""

    strategy = IngestionStrategy.INDEXED
    schema_name = "conversation"
    embed: Optional[bool] = None  # No embedding for container nodes

    # Known conversation fields — everything else passed through to metadata
    # (including tenant scoping fields: user_id, tenant_id, workspace_id)
    _KNOWN_FIELDS = {
        "conversation_id",
        "total_turns",
        "total_sessions",
        "speakers",
        "session_dates",
    }

    def validate(self, data: dict) -> bool:
        return bool(data.get("conversation_id"))

    def to_memory_item(self, data: dict) -> MemoryItem:
        meta = {
            "conversation_id": data["conversation_id"],
            "total_turns": data.get("total_turns", 0),
            "total_sessions": data.get("total_sessions", 0),
            "speakers": data.get("speakers", []),
            "session_dates": data.get("session_dates", []),
        }
        # Pass through extra keys (tenant scoping, custom metadata)
        for k, v in data.items():
            if k not in self._KNOWN_FIELDS and v is not None:
                meta[k] = v
        return MemoryItem(
            content=f"Conversation {data['conversation_id']}",
            memory_type="conversation",
            metadata=meta,
            origin=data.get("origin", "structured:conversation"),
        )

    def get_edges(self, data: dict, item_id: str) -> list:
        return []  # Chunks create PART_OF edges to this node

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_conversation_id "
            "ON nodes(json_extract(properties, '$.conversation_id')) "
            "WHERE memory_type='conversation'",
        ]

    def describe(self) -> dict:
        return {
            "description": "Conversation container — INDEXED structural node; chunks link to it via PART_OF.",
            "required": {"conversation_id": "non-empty/truthy string"},
            "optional": {
                "total_turns": "int (default 0)",
                "total_sessions": "int (default 0)",
                "speakers": "list[str]",
                "session_dates": "list[str]",
                "origin": "str (default 'structured:conversation')",
                "(any other key)": "passed through to metadata (e.g. tenant scoping)",
            },
            "edge_types": [],
        }
