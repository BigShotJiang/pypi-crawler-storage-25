"""PlanTaskHandler — structured ingestion for plan task DAG nodes (CORE-STRUCT-1 Phase 1b).

Strategy: INDEXED — queryable by status, plan_id; creates DEPENDS_ON edges for DAG structure.
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class PlanTaskHandler:
    """Structured handler for plan task records."""

    strategy = IngestionStrategy.INDEXED
    schema_name = "plan_task"
    embed: Optional[bool] = None

    def validate(self, data: dict) -> bool:
        """Require content and plan_id."""
        content = data.get("content")
        plan_id = data.get("plan_id")
        return (
            isinstance(content, str)
            and len(content.strip()) > 0
            and isinstance(plan_id, str)
            and len(plan_id.strip()) > 0
        )

    def to_memory_item(self, data: dict) -> MemoryItem:
        return MemoryItem(
            content=data["content"],
            memory_type="plan_task",
            metadata={
                "plan_id": data["plan_id"],
                "status": data.get("status", "pending"),
                "task_index": data.get("task_index"),
                "depends_on": data.get("depends_on", []),
            },
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        """Create DEPENDS_ON edges for DAG structure."""
        edges: list[tuple[str, str, str, dict]] = []
        for dep_id in data.get("depends_on", []):
            edges.append(
                (
                    item_id,
                    dep_id,
                    "DEPENDS_ON",
                    {"origin": "structured:plan_task", "confidence": 1.0},
                )
            )
        return edges

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_plan_task_status "
            "ON nodes(json_extract(properties, '$.status')) WHERE memory_type='plan_task'",
            "CREATE INDEX IF NOT EXISTS idx_plan_task_plan_id "
            "ON nodes(json_extract(properties, '$.plan_id')) WHERE memory_type='plan_task'",
        ]

    def describe(self) -> dict:
        return {
            "description": "Plan task DAG node — INDEXED, queryable by status/plan_id.",
            "required": {
                "content": "non-empty string (task description)",
                "plan_id": "non-empty string (parent plan)",
            },
            "optional": {
                "status": "str (default 'pending')",
                "task_index": "int",
                "depends_on": "list[str] — creates DEPENDS_ON edges",
            },
            "edge_types": ["DEPENDS_ON"],
        }
