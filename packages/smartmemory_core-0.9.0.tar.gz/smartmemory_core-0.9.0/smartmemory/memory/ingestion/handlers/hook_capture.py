"""HookCaptureHandler — structured ingestion for hook event telemetry (CORE-STRUCT-1 Phase 1b).

Strategy: APPEND — high-volume hook event telemetry.
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class HookCaptureHandler:
    """Structured handler for hook capture records."""

    strategy = IngestionStrategy.APPEND
    schema_name = "hook_capture"
    embed: Optional[bool] = None

    def validate(self, data: dict) -> bool:
        """Require hook_type."""
        return isinstance(data.get("hook_type"), str) and len(data["hook_type"].strip()) > 0

    def to_memory_item(self, data: dict) -> MemoryItem:
        content = data.get("content", "") or f"hook:{data['hook_type']}"
        return MemoryItem(
            content=content,
            memory_type="hook_capture",
            metadata={
                "hook_type": data["hook_type"],
                "tool_name": data.get("tool_name"),
                "session_id": data.get("session_id"),
            },
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        return []

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_hook_capture_type "
            "ON nodes(json_extract(properties, '$.hook_type')) WHERE memory_type='hook_capture'",
        ]

    def describe(self) -> dict:
        return {
            "description": "Hook event telemetry — APPEND, indexed by hook_type.",
            "required": {"hook_type": "non-empty string"},
            "optional": {
                "content": "str (defaults to 'hook:<type>')",
                "tool_name": "str",
                "session_id": "str",
            },
            "edge_types": [],
        }
