"""
Pending memory — thin graph-backed memory type.

Registered with `MemoryFactory` so callers that ask for `MemoryType.PENDING`
get a `GraphBackedMemory` whose items are tagged `memory_type="pending"`.

Evolvers and pipeline code should go through `SmartMemory.search(memory_type="pending")`
and `SmartMemory.add(MemoryItem(memory_type="pending", ...))` rather than touching
this class directly. This module exists only for factory compatibility.

Renamed from ``WorkingMemory`` in CORE-MEMORY-DYNAMICS-1 M1b (2026-04-19).
The old name was a misnomer: items here are NOT a short-term buffer — they
are full memory items that the ConsolidationRouter flagged as ``hold_pending``
(low-confidence or ambiguous) awaiting reinforcement.
"""

from typing import Optional

from smartmemory.configuration import MemoryConfig
from smartmemory.memory.base import GraphBackedMemory


class PendingMemory(GraphBackedMemory):
    """Minimal graph-backed memory type for pending items.

    Inherits `_add_impl`, `_get_impl`, `_update_impl`, `_remove_impl`, and
    `_search_impl` from `GraphBackedMemory`. The `capacity` kwarg is accepted
    for backward compatibility but has no effect — capacity limits are
    enforced by the pipeline / evolver layer, not by this class.
    """

    def __init__(
        self,
        capacity: Optional[int] = None,
        config: MemoryConfig = None,
        scope_provider=None,
        *args,
        **kwargs,
    ):
        super().__init__(
            memory_type="pending",
            config=config,
            scope_provider=scope_provider,
            *args,
            **kwargs,
        )
        # Retained on the instance for any legacy inspection code, but unused.
        self.capacity = capacity
