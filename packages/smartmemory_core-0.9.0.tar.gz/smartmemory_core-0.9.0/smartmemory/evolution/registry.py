"""
Evolver registry for SmartMemory evolution workflows.

- Provides a pluggable interface for internal and external evolvers.
- Studio can list, validate, and select evolvers by keyword.
- External packages can register their evolvers at import time.
"""

from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Dict, Type, Optional, Iterable


@dataclass(frozen=True)
class EvolverSpec:
    key: str
    dotted_path: str  # e.g., "smartmemory.plugins.evolvers.episodic_to_semantic.EpisodicToSemanticEvolver"
    description: str = ""
    tags: tuple[str, ...] = ()


class EvolverRegistry:
    def __init__(self):
        self._specs: Dict[str, EvolverSpec] = {}
        self._cache: Dict[str, Type] = {}

    def register(self, key: str, dotted_path: str, description: str = "", tags: Optional[Iterable[str]] = None) -> None:
        if not key or not dotted_path or "." not in dotted_path:
            raise ValueError("Invalid key or dotted_path for evolver registration")
        k = key.strip()
        if k in self._specs:
            # Allow idempotent re-registration if dotted path matches
            if self._specs[k].dotted_path != dotted_path:
                raise ValueError(f"Evolver key already registered with different path: {k}")
            return
        spec = EvolverSpec(key=k, dotted_path=dotted_path, description=description or "", tags=tuple(tags or ()))
        self._specs[k] = spec

    def get(self, key: str) -> Type:
        spec = self._specs.get(key)
        if not spec:
            raise KeyError(f"Unknown evolver key: {key}")
        if spec.dotted_path in self._cache:
            return self._cache[spec.dotted_path]
        module_path, attr = spec.dotted_path.rsplit(".", 1)
        module = importlib.import_module(module_path)
        cls = getattr(module, attr)
        self._cache[spec.dotted_path] = cls
        return cls

    def try_resolve(self, key_or_path: str) -> Optional[Type]:
        # Prefer registry key
        if key_or_path in self._specs:
            return self.get(key_or_path)
        # Fallback: dotted path import
        try:
            module_path, attr = key_or_path.rsplit(".", 1)
            module = importlib.import_module(module_path)
            return getattr(module, attr)
        except Exception:
            return None

    def list_specs(self) -> Dict[str, EvolverSpec]:
        return dict(self._specs)


# Global registry instance
EVOLVER_REGISTRY = EvolverRegistry()


def register_builtin_evolvers() -> None:
    """Register all built-in evolvers with stable keys and tags."""
    R = EVOLVER_REGISTRY
    # CORE-MEMORY-DYNAMICS-1 M1b: ``working_to_episodic`` + ``working_to_procedural``
    # evolvers deleted — the ConsolidationRouter performs at-ingest routing and
    # the ``working`` memory_type was renamed to ``pending``.

    # Episodic promotions and maintenance
    R.register(
        "episodic_to_semantic",
        "smartmemory.plugins.evolvers.episodic_to_semantic.EpisodicToSemanticEvolver",
        description="Promote stable episodic facts to semantic",
        tags=("episodic", "semantic", "promote", "builtin"),
    )
    R.register(
        "episodic_to_zettel",
        "smartmemory.plugins.evolvers.episodic_to_zettel.EpisodicToZettelEvolver",
        description="Roll up episodic events into zettels",
        tags=("episodic", "zettel", "rollup", "builtin"),
    )
    R.register(
        "episodic_decay",
        "smartmemory.plugins.evolvers.episodic_decay.EpisodicDecayEvolver",
        description="Archive/delete stale episodic events",
        tags=("episodic", "decay", "maintenance", "builtin"),
    )

    # Semantic maintenance
    R.register(
        "semantic_decay",
        "smartmemory.plugins.evolvers.semantic_decay.SemanticDecayEvolver",
        description="Archive low-relevance semantic facts",
        tags=("semantic", "decay", "maintenance", "builtin"),
    )

    # Zettel maintenance
    R.register(
        "zettel_prune",
        "smartmemory.plugins.evolvers.zettel_prune.ZettelPruneEvolver",
        description="Prune/merge low-quality or duplicate zettels",
        tags=("zettel", "prune", "maintenance", "builtin"),
    )

    # Memory consolidation (CORE-CONSOLIDATE-1)
    R.register(
        "memory_consolidation",
        "smartmemory.plugins.evolvers.memory_consolidation.MemoryConsolidationEvolver",
        description="Consolidate overlapping episodic memories into unified semantic summaries",
        tags=("consolidation", "episodic", "semantic", "synthesis", "builtin"),
    )

    # Agent-optimized suite (from service_common)
    R.register(
        "maximal_connectivity",
        "service_common.plugins.evolvers.optimized.maximal_connectivity.MaximalConnectivityEvolver",
        description="Create maximum useful connections between items",
        tags=("agent", "connectivity", "links", "experimental"),
    )
    R.register(
        "rapid_enrichment",
        "service_common.plugins.evolvers.optimized.rapid_enrichment.RapidEnrichmentEvolver",
        description="Immediately enrich items with comprehensive context",
        tags=("agent", "enrichment", "experimental"),
    )
    R.register(
        "strategic_pruning",
        "service_common.plugins.evolvers.optimized.strategic_pruning.StrategicPruningEvolver",
        description="Strategically prune redundant/outdated/low-value items",
        tags=("agent", "pruning", "experimental"),
    )
    R.register(
        "hierarchical_organization",
        "service_common.plugins.evolvers.optimized.hierarchical_organization.HierarchicalOrganizationEvolver",
        description="Create hierarchical topic/entity/temporal organization",
        tags=("agent", "hierarchy", "experimental"),
    )

    # Enhanced evolvers present in codebase but not registered

    R.register(
        "enhanced_working_to_episodic",
        "smartmemory.plugins.evolvers.enhanced.working_to_episodic.EnhancedWorkingToEpisodicEvolver",
        description="Cognitively-informed promotion from working to episodic (enhanced)",
        tags=("enhanced", "working", "episodic", "promote"),
    )
    R.register(
        "interference_based_consolidation",
        "smartmemory.plugins.evolvers.enhanced.interference_based_consolidation.InterferenceBasedConsolidationEvolver",
        description="Consolidate while mitigating interference effects (enhanced)",
        tags=("enhanced", "consolidation", "interference"),
    )
    R.register(
        "retrieval_based_strengthening",
        "smartmemory.plugins.evolvers.enhanced.retrieval_based_strengthening.RetrievalBasedStrengtheningEvolver",
        description="Strengthen memories via retrieval practice (enhanced)",
        tags=("enhanced", "retrieval", "strengthening"),
    )
    R.register(
        "exponential_decay",
        "smartmemory.plugins.evolvers.enhanced.exponential_decay.ExponentialDecayEvolver",
        description="Apply exponential forgetting curves (enhanced)",
        tags=("enhanced", "decay"),
    )

    # Decision confidence evolution
    R.register(
        "decision_confidence",
        "smartmemory.plugins.evolvers.decision_confidence.DecisionConfidenceEvolver",
        description="Evidence-based reinforcement, contradiction, decay, and retraction for decisions",
        tags=("decision", "confidence", "decay", "reinforcement", "builtin"),
    )

    # Staleness tracking
    R.register(
        "stale_memory",
        "smartmemory.plugins.evolvers.stale_memory.StaleMemoryEvolver",
        description="Mark non-code memories stale when referenced source files change",
        tags=("maintenance", "code", "staleness", "builtin"),
    )

    # Opinion / observation synthesis + reinforcement (previously unregistered —
    # surfaced by CORE-EVO-REPORT-1 Codex review; registering so Studio can resolve
    # them by key rather than only via direct dotted-path imports).
    R.register(
        "opinion_synthesis",
        "smartmemory.plugins.evolvers.opinion_synthesis.OpinionSynthesisEvolver",
        description="Synthesize opinions from episodic patterns via disposition-weighted confidence",
        tags=("opinion", "synthesis", "builtin"),
    )
    R.register(
        "opinion_reinforcement",
        "smartmemory.plugins.evolvers.opinion_reinforcement.OpinionReinforcementEvolver",
        description="Reinforce/contradict opinions based on new evidence; decay stale opinions",
        tags=("opinion", "reinforcement", "decay", "builtin"),
    )
    R.register(
        "observation_synthesis",
        "smartmemory.plugins.evolvers.observation_synthesis.ObservationSynthesisEvolver",
        description="Synthesize entity observations from semantic facts; compress hook:observe items",
        tags=("observation", "synthesis", "entity", "builtin"),
    )
    R.register(
        "hebbian_co_retrieval",
        "smartmemory.plugins.evolvers.enhanced.hebbian_co_retrieval.HebbianCoRetrievalEvolver",
        description="Boost retention on nodes frequently co-retrieved together (enhanced)",
        tags=("enhanced", "hebbian", "co-retrieval", "retention"),
    )

    # Activation-driven evolvers (CORE-MEMORY-DYNAMICS-1 M2a Slice C)
    R.register(
        "semantic_to_procedural",
        "smartmemory.plugins.evolvers.semantic_to_procedural.SemanticToProceduralEvolver",
        description="Compile repeated how-to-shaped semantic memories into procedural memories",
        tags=("semantic", "procedural", "compile", "activation", "builtin"),
    )
    R.register(
        "procedural_reinforcement",
        "smartmemory.plugins.evolvers.procedural_reinforcement.ProceduralReinforcementEvolver",
        description="Boost activation on procedural memories with recent retrieval activity",
        tags=("procedural", "activation", "reinforcement", "builtin"),
    )
    R.register(
        "anchor_reconciliation",
        "smartmemory.plugins.evolvers.anchor_reconciliation.AnchorReconciliationEvolver",
        description="Stale anchors with strong drift + >= 2 contradictions; warn otherwise",
        tags=("anchor", "drift", "reconciliation", "builtin"),
    )

    # Flow-expansion evolvers (CORE-MEMORY-DYNAMICS-1 M2b Slice A)
    R.register(
        "resolution_chain",
        "smartmemory.plugins.evolvers.resolution_chain.ResolutionChainEvolver",
        description=(
            "Materialize ANSWERED_BY edges from Q/A-asymmetric CO_RETRIEVED "
            "pairs; boost answer activation on new edges."
        ),
        tags=("resolution", "answered_by", "activation", "flow", "builtin"),
    )


# Auto-register builtins on import
register_builtin_evolvers()


# Convenience functions for callers


def get_evolver_by_key(key: str):
    return EVOLVER_REGISTRY.get(key)


def list_evolver_specs() -> Dict[str, EvolverSpec]:
    return EVOLVER_REGISTRY.list_specs()
