"""Phase A activation migration — idempotent one-shot workspace seeding.

Seeds the nested ``metadata["activation"]`` dict on items that lack it, using
contract defaults (``score=0.5``, ``last_boost_at=now``, ``half_life_hours=720``,
``boost_count=0``, ``rot_score=0.0``). Items that already carry an activation
dict are skipped — running twice is safe.

**Scope:** the caller is responsible for passing a workspace-scoped
``SmartMemory`` instance. Migration never crosses workspace boundaries because
all reads and writes route through the provided instance's ``ScopeProvider``.

**Fetch strategy:** a single ``memory.search(query="*", top_k=max_items)``
call is used rather than pagination. ``memory.search`` has no cursor/offset
API, so a doubling-loop approach cannot make forward progress on workspaces
larger than the cap (Codex r2 blocker). The default ``max_items`` is set
deliberately high (1,000,000) so any realistic M2a workspace fits in one
pass. If a workspace genuinely exceeds this, the returned ``cap_hit`` flag
is set and a WARNING is logged — the operator must raise ``max_items``
explicitly rather than relying on reruns.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from smartmemory.activation.constants import (
    BOOST_COUNT_KEY,
    DEFAULT_BOOST_COUNT,
    DEFAULT_HALF_LIFE_HOURS,
    DEFAULT_ROT_SCORE,
    DEFAULT_SCORE,
    HALF_LIFE_KEY,
    LAST_BOOST_KEY,
    NAMESPACE,
    ROT_SCORE_KEY,
    SCORE_KEY,
)

logger = logging.getLogger(__name__)

MAX_MIGRATE_ITEMS: int = 1_000_000


def migrate_workspace(
    memory: Any,
    now: Optional[datetime] = None,
    max_items: int = MAX_MIGRATE_ITEMS,
) -> Dict[str, int]:
    """Seed ``metadata[activation]`` on every item missing the key.

    Args:
        memory: Workspace-scoped ``SmartMemory`` instance. All operations
            inherit the workspace boundary from the instance's scope provider.
        now: Reference time for ``last_boost_at``. Defaults to
            ``datetime.now(utc)``.
        max_items: Upper bound on items fetched in the single ``search("*")``
            call. Default 1,000,000. If the backend returns exactly this many
            items the workspace may have more — ``cap_hit`` is set and a
            WARNING is logged. Rerunning is not a fix: raise ``max_items``
            explicitly (memory.search has no cursor to paginate with).

    Returns:
        Stats dict with ``scanned``, ``migrated``, ``skipped``, ``cap_hit``
        keys. ``migrated + skipped == scanned``.
    """
    now = now or datetime.now(timezone.utc)
    scanned = 0
    migrated = 0
    skipped = 0
    cap_hit = 0

    try:
        items = memory.search(query="*", top_k=max_items) or []
    except Exception as exc:
        logger.warning("migrate_workspace: search failed — %s", exc)
        return {"scanned": 0, "migrated": 0, "skipped": 0, "cap_hit": 0}

    # Deduplicate by item_id in case the backend echoes rows.
    seen_ids: set[str] = set()
    seed_template = {
        HALF_LIFE_KEY: DEFAULT_HALF_LIFE_HOURS,
        BOOST_COUNT_KEY: DEFAULT_BOOST_COUNT,
        ROT_SCORE_KEY: DEFAULT_ROT_SCORE,
    }
    last_boost_iso = now.isoformat()

    for item in items:
        item_id = getattr(item, "item_id", None)
        if not item_id or item_id in seen_ids:
            continue
        seen_ids.add(item_id)
        scanned += 1

        md = getattr(item, "metadata", None)
        if isinstance(md, dict) and isinstance(md.get(NAMESPACE), dict):
            skipped += 1
            continue

        seed = {
            SCORE_KEY: DEFAULT_SCORE,
            LAST_BOOST_KEY: last_boost_iso,
            **seed_template,
        }
        try:
            memory.update_properties(item_id, {NAMESPACE: seed})
            migrated += 1
        except Exception as exc:
            logger.warning(
                "migrate_workspace: update failed for %s — %s", item_id, exc
            )
            skipped += 1

    # If the fetch returned exactly max_items rows the workspace may be larger
    # than our cap — migration is NOT complete. Surface loudly; reruns alone
    # will not fix this (no cursor/offset), the caller must raise max_items.
    if len(items) >= max_items:
        cap_hit = 1
        logger.warning(
            "migrate_workspace: hit max_items=%d — workspace may have more "
            "items beyond the cap. memory.search has no cursor; raise "
            "max_items explicitly rather than rerunning.",
            max_items,
        )

    logger.info(
        "migrate_workspace: scanned=%d migrated=%d skipped=%d cap_hit=%d",
        scanned, migrated, skipped, cap_hit,
    )
    return {
        "scanned": scanned,
        "migrated": migrated,
        "skipped": skipped,
        "cap_hit": cap_hit,
    }
