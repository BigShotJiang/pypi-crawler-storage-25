"""Activation boost producer — Redis-first with non-raising direct-write fallback.

The boost path is on the hot retrieval path; under no circumstance may
``boost_activation`` raise back to the caller. Redis-down falls through to
a direct ``memory.update_properties()`` write emitting debug telemetry.

**Full-dict invariant:** both paths write the complete nested ``activation``
dict (all five sub-keys), never a partial write. This is load-bearing for
Slice A / Slice B co-existence: items boosted in Slice A before Slice B's
migration must still deserialize cleanly under the ranking formula.
"""

import logging
import os
import threading
from datetime import datetime, timezone
from typing import Any, Optional

from smartmemory.activation.constants import (
    BOOST_COUNT_KEY,
    DEFAULT_BOOST_COUNT,
    DEFAULT_HALF_LIFE_HOURS,
    DEFAULT_ROT_SCORE,
    DEFAULT_SCORE,
    HALF_LIFE_KEY,
    LAST_BOOST_KEY,
    NAMESPACE,
    PENDING_BOOST_TTL_SECONDS,
    REDIS_PENDING_KEY_TEMPLATE,
    ROT_SCORE_KEY,
    SCORE_KEY,
)

logger = logging.getLogger(__name__)

# Redis DB 1 is the activation/progress namespace (shared with PLAT-PROGRESS-1).
_REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
_REDIS_PORT = int(os.getenv("REDIS_PORT", "9012"))
_REDIS_DB = int(os.getenv("ACTIVATION_REDIS_DB", "1"))

_redis_client: Optional[object] = None
_redis_lock = threading.Lock()
_redis_failed = False


def _get_redis_client():
    """Lazy singleton Redis client for pending-boost INCRBYFLOAT.

    Mirrors the failure-suppression idiom from
    ``observability/retrieval_tracking.py`` exactly.
    """
    global _redis_client, _redis_failed
    if _redis_failed:
        return None
    if _redis_client is not None:
        return _redis_client
    with _redis_lock:
        if _redis_client is not None:
            return _redis_client
        try:
            import redis  # type: ignore

            client = redis.Redis(
                host=_REDIS_HOST,
                port=_REDIS_PORT,
                db=_REDIS_DB,
                decode_responses=True,
                socket_connect_timeout=1.0,
                socket_timeout=1.0,
            )
            client.ping()
            _redis_client = client
            return _redis_client
        except Exception as exc:  # pragma: no cover - infra fallback
            logger.debug("activation.boost: Redis client unavailable — %s", exc)
            _redis_failed = True
            return None


def _reset_redis_state_for_tests() -> None:
    """Clear the cached client so tests can re-probe Redis availability."""
    global _redis_client, _redis_failed
    with _redis_lock:
        _redis_client = None
        _redis_failed = False


def boost_activation_redis(workspace_id: str, item_id: str, delta: float) -> bool:
    """Pure-Redis INCRBYFLOAT boost for the hot retrieval path.

    Unlike :func:`boost_activation`, this function does **no** direct-write
    fallback — it returns ``False`` when Redis is unavailable and lets the
    caller (typically ``observability.retrieval_tracking``) drop the boost.
    This is the correct trade-off on the retrieval hot path: attempting a
    direct-write per retrieved item would add a DB roundtrip to every search,
    and the worker's activation-flusher will catch up when Redis recovers.

    Args:
        workspace_id: Workspace identifier for the pending-key template.
        item_id: Target item. No-op on empty.
        delta: Boost magnitude.

    Returns:
        ``True`` if Redis accepted the INCRBYFLOAT; ``False`` otherwise
        (including missing workspace_id or unreachable Redis).
    """
    if not workspace_id or not item_id:
        return False
    client = _get_redis_client()
    if client is None:
        return False
    try:
        key = REDIS_PENDING_KEY_TEMPLATE.format(
            workspace_id=workspace_id, item_id=item_id
        )
        pipe = client.pipeline()
        pipe.incrbyfloat(key, float(delta))
        pipe.expire(key, PENDING_BOOST_TTL_SECONDS)
        pipe.execute()
        return True
    except Exception as exc:
        logger.debug(
            "boost_activation_redis: write failed (ws=%s item=%s err=%s)",
            workspace_id, item_id, exc,
        )
        return False


def boost_activation(
    memory: Any,
    item_id: str,
    delta: float,
    reason: str,
    now: Optional[datetime] = None,
) -> bool:
    """Apply an activation boost to an item.

    Attempts Redis ``INCRBYFLOAT`` on the workspace-scoped pending key first.
    On Redis unavailability, falls back to a direct metadata write honouring
    the full-dict invariant. **Never raises.**

    Args:
        memory: Scoped SmartMemory instance. Used for workspace_id resolution
            and for the fallback ``update_properties`` write.
        item_id: Target item. No-op if empty/None.
        delta: Boost magnitude. Should come from ``constants.BOOST_SIZE_*``.
        reason: Tag for telemetry (``retrieve``, ``surface``, ``procedure_invoked``, etc.).
        now: Timestamp to record as ``last_boost_at``. Defaults to ``datetime.now(utc)``.

    Returns:
        ``True`` if the Redis INCRBYFLOAT path was taken; ``False`` if the
        direct-write fallback was taken (or the call was a no-op).
    """
    if not item_id:
        return False
    now = now or datetime.now(timezone.utc)

    workspace_id = _resolve_workspace_id(memory)
    if not workspace_id:
        logger.debug("activation.boost: no workspace_id; skipping (item=%s)", item_id)
        return False

    client = _get_redis_client()
    if client is not None:
        try:
            key = REDIS_PENDING_KEY_TEMPLATE.format(
                workspace_id=workspace_id, item_id=item_id
            )
            pipe = client.pipeline()
            pipe.incrbyfloat(key, float(delta))
            pipe.expire(key, PENDING_BOOST_TTL_SECONDS)
            pipe.execute()
            logger.debug(
                "activation.boost: Redis ok (item=%s reason=%s delta=%.4f)",
                item_id, reason, delta,
            )
            return True
        except Exception as exc:
            logger.debug(
                "activation.boost: Redis write failed, falling through (item=%s err=%s)",
                item_id, exc,
            )

    # Fallback: direct full-dict write. Full-dict invariant enforced here.
    try:
        existing = _fetch_activation_dict(memory, item_id)
        merged = _merged_activation_dict(existing, float(delta), now)
        memory.update_properties(item_id, {NAMESPACE: merged})
        logger.debug(
            "activation.boost.fallback: direct write (item=%s reason=%s delta=%.4f)",
            item_id, reason, delta,
        )
    except Exception as exc:
        logger.debug(
            "activation.boost.fallback: direct-write failed silently (item=%s err=%s)",
            item_id, exc,
        )
    return False


def _resolve_workspace_id(memory: Any) -> Optional[str]:
    """Extract workspace_id from the memory instance's scope provider.

    Duck-types: looks for ``_scope_provider.workspace_id``, then common
    attribute names. Returns ``None`` if unresolvable — caller treats as
    no-op (no cross-workspace leak possible).
    """
    sp = getattr(memory, "_scope_provider", None) or getattr(memory, "scope_provider", None)
    if sp is not None:
        for attr in ("workspace_id", "get_workspace_id"):
            val = getattr(sp, attr, None)
            if callable(val):
                try:
                    return val()
                except Exception:
                    continue
            if isinstance(val, str) and val:
                return val
    return getattr(memory, "workspace_id", None)


def _fetch_activation_dict(memory: Any, item_id: str) -> dict:
    """Best-effort read of existing ``metadata[activation]`` for merging.

    Returns empty dict on any failure — caller will seed defaults via
    ``_merged_activation_dict``.
    """
    try:
        item = memory.get(item_id)
    except Exception:
        return {}
    if item is None:
        return {}
    md = getattr(item, "metadata", None)
    if not isinstance(md, dict):
        # Corrupted/unexpected metadata shape — treat as missing, let
        # _merged_activation_dict seed a clean full dict.
        return {}
    activation = md.get(NAMESPACE)
    return activation if isinstance(activation, dict) else {}


def _merged_activation_dict(
    existing: Optional[dict],
    delta: float,
    now: datetime,
) -> dict:
    """Build a full activation dict for a BOOST event — increments ``boost_count``.

    Slice A / Slice B co-existence depends on this function: items that have
    never been migrated get a complete dict on first boost, so later reads
    through ``compute_activation_score`` do not encounter partial shapes.
    """
    base = normalize_activation_dict(existing)
    new_score = max(0.0, min(1.0, base[SCORE_KEY] + delta))
    return {
        SCORE_KEY: new_score,
        LAST_BOOST_KEY: now.isoformat(),
        HALF_LIFE_KEY: base[HALF_LIFE_KEY],
        BOOST_COUNT_KEY: base[BOOST_COUNT_KEY] + 1,
        ROT_SCORE_KEY: base[ROT_SCORE_KEY],
    }


def normalize_activation_dict(existing: Optional[dict]) -> dict:
    """Coerce a possibly-partial activation dict to the full 5-key shape.

    Used by decay-sweep and any other non-boost writer that must honour the
    full-dict invariant without incrementing ``boost_count``. Robust against
    garbage values (non-numeric, wrong types) — always returns a complete
    dict populated with either the coerced-from-existing value or the
    contract default.
    """
    existing = existing if isinstance(existing, dict) else {}

    try:
        cur_score = float(existing.get(SCORE_KEY, DEFAULT_SCORE))
    except (TypeError, ValueError):
        cur_score = DEFAULT_SCORE
    try:
        cur_count = int(existing.get(BOOST_COUNT_KEY, DEFAULT_BOOST_COUNT))
    except (TypeError, ValueError):
        cur_count = DEFAULT_BOOST_COUNT
    try:
        cur_half_life = int(existing.get(HALF_LIFE_KEY, DEFAULT_HALF_LIFE_HOURS))
    except (TypeError, ValueError):
        cur_half_life = DEFAULT_HALF_LIFE_HOURS
    try:
        cur_rot = float(existing.get(ROT_SCORE_KEY, DEFAULT_ROT_SCORE))
    except (TypeError, ValueError):
        cur_rot = DEFAULT_ROT_SCORE

    last_boost = existing.get(LAST_BOOST_KEY)
    if not isinstance(last_boost, str):
        last_boost = datetime.now(timezone.utc).isoformat()

    return {
        SCORE_KEY: max(0.0, min(1.0, cur_score)),
        LAST_BOOST_KEY: last_boost,
        HALF_LIFE_KEY: cur_half_life,
        BOOST_COUNT_KEY: cur_count,
        ROT_SCORE_KEY: cur_rot,
    }
