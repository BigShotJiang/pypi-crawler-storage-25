"""LLM-backed summarization helpers for progressive compaction (M2b Slice B).

Three tier transitions emit new content via different mechanisms:

- ``SUMMARY``: LLM compresses ``content`` to ≤40% while preserving names /
  numbers / decisions. Returns ``None`` on LLM failure (caller silent-skips
  the transition and retries next cycle).
- ``SKELETON``: LLM extracts 5-10 keyphrases. Same failure semantics.
- ``TOMBSTONE``: deterministic — no LLM. Returns a marker string unconditionally.

All functions are pure; they do NOT write back to the store. The caller
(:func:`smartmemory.activation.compaction.run_compaction_sweep`) owns the
write path so failures never leave the item in a partial state.
"""

from __future__ import annotations

import logging
from typing import Optional

from smartmemory.activation.compaction_constants import TOMBSTONE_MARKER_TEMPLATE

logger = logging.getLogger(__name__)


_SUMMARY_PROMPT: str = (
    "Compress the following content to no more than 40% of its length while "
    "preserving all specific names, numbers, and decisions. Return only the "
    "compressed text — no commentary, no preamble, no quotation marks.\n\n"
    "CONTENT:\n{content}"
)

_SKELETON_PROMPT: str = (
    "Extract the 5 to 10 most important keyphrases or subject terms from the "
    "following content. Return ONLY a comma-separated list of keyphrases — no "
    "numbering, no bullets, no explanation.\n\n"
    "CONTENT:\n{content}"
)


def compress_to_summary(content: str) -> Optional[str]:
    """Compress ``content`` to ≤40% of its length via LLM.

    Returns:
        Compressed text on success, or ``None`` on any LLM failure (the
        caller silent-skips the tier transition for this cycle).
    """
    if not content or not content.strip():
        return None
    try:
        from smartmemory.utils.llm import call_llm

        _, raw = call_llm(
            system_prompt="You compress text preserving all specific facts.",
            user_content=_SUMMARY_PROMPT.format(content=content),
            max_output_tokens=800,
            temperature=0.0,
            config_section="extractor",
        )
    except Exception as exc:
        logger.debug("compress_to_summary: LLM call failed — %s", exc)
        return None
    if not raw or not raw.strip():
        return None
    return raw.strip()


def compress_to_skeleton(content: str) -> Optional[str]:
    """Extract 5–10 keyphrases via LLM.

    Returns:
        Comma-separated keyphrase list on success, or ``None`` on LLM failure.
    """
    if not content or not content.strip():
        return None
    try:
        from smartmemory.utils.llm import call_llm

        _, raw = call_llm(
            system_prompt="You extract concise topical keyphrases.",
            user_content=_SKELETON_PROMPT.format(content=content),
            max_output_tokens=200,
            temperature=0.0,
            config_section="extractor",
        )
    except Exception as exc:
        logger.debug("compress_to_skeleton: LLM call failed — %s", exc)
        return None
    if not raw or not raw.strip():
        return None
    return raw.strip()


def compress_to_tombstone(content: str) -> str:
    """Deterministic tombstone marker — no LLM involved.

    Records the original content's character length so the tombstone carries
    some forensic value ("there was a 1200-char item here") without any
    retrievable text. Snapshots at higher tiers remain in ``metadata`` for
    rehydration.
    """
    n = len(content) if content else 0
    return TOMBSTONE_MARKER_TEMPLATE.format(n=n)
