"""Activation score computation — exponential decay from last boost."""

import math
from datetime import datetime, timezone
from typing import Any, Optional

from smartmemory.activation.constants import (
    BOOST_COUNT_KEY,
    DEFAULT_HALF_LIFE_HOURS,
    DEFAULT_SCORE,
    HALF_LIFE_KEY,
    LAST_BOOST_KEY,
    NAMESPACE,
    ROT_SCORE_KEY,
    SCORE_KEY,
)


def compute_activation_score(item: Any, now: Optional[datetime] = None) -> float:
    """Return the current activation score for a MemoryItem.

    Reads the nested ``metadata["activation"]`` dict. If absent, returns
    ``DEFAULT_SCORE``. If present, decays the stored score exponentially
    from ``last_boost_at`` using ``half_life_hours`` as the time constant:

        score(t) = stored_score * exp(-ln(2) * elapsed_hours / half_life_hours)

    Result is clamped to ``[0.0, 1.0]``.

    Args:
        item: MemoryItem (or dict with ``metadata`` key). Must be read-only;
            no mutation side effects.
        now: Reference time for decay. Defaults to ``datetime.now(utc)``.

    Returns:
        Activation score in ``[0.0, 1.0]``.
    """
    now = now or datetime.now(timezone.utc)

    metadata = _get_metadata(item)
    activation = metadata.get(NAMESPACE) if isinstance(metadata, dict) else None

    # Transitional: the search() path presents metadata with flat
    # ``activation__*`` keys rather than a nested dict (pre-existing
    # deserialization asymmetry between get() and search()). Recover the
    # nested form on the fly so ranking is correct regardless of which
    # read path produced the item. Can be removed once the search path
    # flows through MemoryItemSerializer.from_storage uniformly.
    if (not activation or not isinstance(activation, dict)) and isinstance(metadata, dict):
        flat = _extract_flat_activation(metadata)
        if flat:
            activation = flat

    if not activation or not isinstance(activation, dict):
        return DEFAULT_SCORE

    stored_score = _coerce_float(activation.get(SCORE_KEY), DEFAULT_SCORE)
    half_life = _coerce_int(activation.get(HALF_LIFE_KEY), DEFAULT_HALF_LIFE_HOURS)
    if half_life <= 0:
        # Degenerate half-life — treat as fully decayed. Log-scale guard.
        return 0.0

    last_boost = _parse_iso(activation.get(LAST_BOOST_KEY))
    if last_boost is None:
        return _clamp(stored_score)

    elapsed_hours = max(0.0, (now - last_boost).total_seconds() / 3600.0)
    decay = math.exp(-math.log(2) * elapsed_hours / half_life)
    return _clamp(stored_score * decay)


def _get_metadata(item: Any) -> dict:
    md = getattr(item, "metadata", None)
    if md is None and isinstance(item, dict):
        md = item.get("metadata")
    return md or {}


def _extract_flat_activation(metadata: dict) -> Optional[dict]:
    """Recover nested activation dict from flat ``activation__*`` keys.

    Returns ``None`` if no flat-form keys are present. Only returns a
    populated dict if at least ``SCORE_KEY`` is present in flat form —
    avoids synthesizing a bogus activation from garbage.
    """
    prefix = f"{NAMESPACE}__"
    flat_keys = {k: v for k, v in metadata.items() if isinstance(k, str) and k.startswith(prefix)}
    if not flat_keys:
        return None
    score_flat_key = f"{prefix}{SCORE_KEY}"
    if score_flat_key not in flat_keys:
        return None
    return {
        SCORE_KEY: flat_keys.get(score_flat_key),
        LAST_BOOST_KEY: flat_keys.get(f"{prefix}{LAST_BOOST_KEY}"),
        HALF_LIFE_KEY: flat_keys.get(f"{prefix}{HALF_LIFE_KEY}"),
        BOOST_COUNT_KEY: flat_keys.get(f"{prefix}{BOOST_COUNT_KEY}"),
        ROT_SCORE_KEY: flat_keys.get(f"{prefix}{ROT_SCORE_KEY}"),
    }


def _coerce_float(value: Any, default: float) -> float:
    try:
        return float(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _coerce_int(value: Any, default: int) -> int:
    try:
        return int(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _parse_iso(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value)
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            return None
    return None


def _clamp(score: float) -> float:
    return max(0.0, min(1.0, score))
