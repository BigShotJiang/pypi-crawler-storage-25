"""Activation primitives constants.

Source of truth for field names, defaults, Redis key templates, and boost
magnitudes. Mirror of
``smart-memory-docs/docs/features/CORE-MEMORY-DYNAMICS-1/activation-contract.json``.
"""

# Nested-dict namespace. Mandated because literal ``activation__*`` keys
# would split on ``__`` during ``MemoryItem`` flatten/unflatten round-trip —
# see blueprint-m2a.md Corrections table row 2.
NAMESPACE = "activation"

SCORE_KEY = "score"
LAST_BOOST_KEY = "last_boost_at"
HALF_LIFE_KEY = "half_life_hours"
BOOST_COUNT_KEY = "boost_count"
ROT_SCORE_KEY = "rot_score"

# Defaults applied at migration (Phase A) and on first boost against an
# un-migrated item (full-dict invariant — see boost.py::_merged_activation_dict).
DEFAULT_SCORE: float = 0.5
DEFAULT_HALF_LIFE_HOURS: int = 720  # 30 days
DEFAULT_BOOST_COUNT: int = 0
DEFAULT_ROT_SCORE: float = 0.0

# Floor applied in get_working_context ranking composite to prevent cold
# items from being zeroed by low activation despite strong relevance. See
# blueprint-m2a.md Decision 6 and Codex r1 finding Q4.
ACTIVATION_FLOOR: float = 0.05

# Boost magnitudes per retrieval reason. Applied via Redis INCRBYFLOAT or
# direct metadata write on fallback.
BOOST_SIZE_RETRIEVE: float = 0.05
BOOST_SIZE_SURFACE: float = 0.02
BOOST_SIZE_CORETRIEVE: float = 0.01

# Scheduled-job cadences. Enforced by BaseScheduledJob subclasses in worker.
FLUSH_INTERVAL_SECONDS: int = 5
DECAY_INTERVAL_SECONDS: int = 3600

# Redis key templates — workspace-scoped to preserve cross-workspace isolation.
REDIS_PENDING_KEY_TEMPLATE: str = "sm:activation:pending:{workspace_id}:{item_id}"
REDIS_DECAY_LOCK_TEMPLATE: str = "sm:activation:decay-lock:{workspace_id}"

# TTLs for Redis keys (seconds).
PENDING_BOOST_TTL_SECONDS: int = 3600
DECAY_LOCK_TTL_SECONDS: int = 600

# ---------------------------------------------------------------------------
# Surfacing composite weights (CORE-MEMORY-DYNAMICS-1 M3 Slice A)
# ---------------------------------------------------------------------------

# Multiplier on normalized PPR centrality when wiring the composite's
# bounded additive lift: ``centrality_lift = 1 + PPR_WEIGHT × centrality_norm``.
# At centrality_norm=1.0, peak lift is 1.5x. Cold-centrality items are
# unpenalized (lift = 1.0). Slice A leaves centrality_norm=0 because PPR
# lands in Slice C — the composite still compiles with lift=1.0.
PPR_WEIGHT: float = 0.5

# Additive-boost cap for freshness. `freshness_boost = (age_weight) *
# FRESHNESS_BOOST_WEIGHT`, where age_weight linearly decays 1→0 over
# the freshness window.
FRESHNESS_BOOST_WEIGHT: float = 0.2

# Multiplier applied to a caller-supplied pin weight before adding to
# the composite. `session_pin_boost = pin_weight × SESSION_PIN_MULTIPLIER`.
# Keeps absolute-scale consistency with freshness_boost.
SESSION_PIN_MULTIPLIER: float = 0.3

# Linear decay window for the freshness boost. Items younger than this
# get a non-zero boost decaying to 0 at the boundary.
FRESHNESS_WINDOW_HOURS: int = 24

# ---------------------------------------------------------------------------
# Capacity cap + competitive inhibition (CORE-MEMORY-DYNAMICS-1 M2b Slice C)
# ---------------------------------------------------------------------------

# Per-workspace soft cap. ``None`` disables capacity enforcement entirely
# (the decay sweep behaves identically to M2a when cap is None). Production
# rollouts opt in by passing an integer cap per workspace via the sweep
# kwargs.
DEFAULT_CAPACITY_CAP: int | None = None

# Multiplier applied to the bottom-percentile activation scores when the
# workspace exceeds its cap. 0.7 is gentle — a 30% one-shot penalty —
# paired with the activation-driven tier progression in Slice B.
DEFAULT_INHIBITION_FACTOR: float = 0.7

# Fraction of items that receive the inhibition penalty when over-cap.
# 0.20 = the bottom 20% of the workspace's activation scores for this pass.
DEFAULT_INHIBITION_PERCENTILE: float = 0.20
