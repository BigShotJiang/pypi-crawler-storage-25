"""Progressive compaction sweep — activation-driven tier progression.

Runs per-item tier progression based on activation score (thresholds in
:mod:`smartmemory.activation.compaction_constants`). Tier-1 origins (per
:mod:`smartmemory.origin_policy`) never compact below ``FULL`` — this is a
load-bearing invariant for acceptance criterion #4 (design-m2b §535-538).

**Read-path safety:** this sweep reads items via ``memory._crud.get()``
(not ``memory.get()``) so the fetch does NOT trigger the retrieval-boost
hook. Mirrors the M2a Slice B r3 lesson — internal scans must never
inflate activation scores.

**Write shape:** a single ``update_properties`` call carries ``content``,
``compression_tier``, ``snapshots``, and ``tier_transitions`` together.
``metadata["activation"]`` is never touched by compaction — the decay
sweep owns the activation namespace.

**Failure semantics:** LLM summarization failure → silent-skip the
transition for this cycle (retried next cycle). Write failure → logged
WARNING + item counted as ``skipped``. Never raises to the caller.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from smartmemory.activation.compaction_constants import (
    COMPACTION_TIER_KEY,
    NEEDS_REEMBED_KEY,
    SNAPSHOTS_KEY,
    TIER_FORGOTTEN,
    TIER_FULL,
    TIER_ORDER,
    TIER_SKELETON,
    TIER_SUMMARY,
    TIER_THRESHOLD_SKELETON,
    TIER_THRESHOLD_SUMMARY,
    TIER_THRESHOLD_TOMBSTONE,
    TIER_TOMBSTONE,
    TIER_TRANSITIONS_KEY,
    TOMBSTONE_MIN_AGE_DAYS,
)
from smartmemory.activation.constants import NAMESPACE, SCORE_KEY
from smartmemory.activation.summarize import (
    compress_to_skeleton,
    compress_to_summary,
    compress_to_tombstone,
)
from smartmemory.origin_policy import get_tier as get_origin_tier

logger = logging.getLogger(__name__)


DEFAULT_MAX_ITEMS: int = 10_000


def determine_target_tier(item: Any, now: datetime) -> str:
    """Return the tier the item should progress TO based on activation + age.

    Rules:
    - Tier-1 origins short-circuit to ``FULL`` regardless of score/age.
    - Score >= ``TIER_THRESHOLD_SUMMARY``         → ``FULL``
    - Score >= ``TIER_THRESHOLD_SKELETON``        → ``SUMMARY``
    - Score >= ``TIER_THRESHOLD_TOMBSTONE``       → ``SKELETON``
    - Score <  ``TIER_THRESHOLD_TOMBSTONE`` AND age >= 30d → ``TOMBSTONE``
    - Score <  ``TIER_THRESHOLD_TOMBSTONE`` AND age <  30d → ``SKELETON`` (cold-start guard)
    """
    origin = getattr(item, "origin", None) or ""
    if origin and get_origin_tier(origin) == 1:
        return TIER_FULL

    score = _extract_activation_score(item)
    if score >= TIER_THRESHOLD_SUMMARY:
        return TIER_FULL
    if score >= TIER_THRESHOLD_SKELETON:
        return TIER_SUMMARY
    if score >= TIER_THRESHOLD_TOMBSTONE:
        return TIER_SKELETON

    age_days = _item_age_days(item, now)
    if age_days >= TOMBSTONE_MIN_AGE_DAYS:
        return TIER_TOMBSTONE
    # Cold-start guard: don't tombstone young low-activation items.
    return TIER_SKELETON


def _resolve_authoritative(memory: Any, item: Any) -> Any:
    """Re-read an item via ``_crud.get()`` to recover ``memory_type`` /
    ``origin`` lost in the search-result projection. Falls back to the
    original item if the re-read fails (defensive — never raise from a
    helper used inside the sweep loop).
    """
    item_id = getattr(item, "item_id", None)
    if not item_id:
        return item
    try:
        crud = getattr(memory, "_crud", None)
        if crud is None:
            return item
        fetched = crud.get(item_id)
        return fetched if fetched is not None else item
    except Exception:  # noqa: BLE001
        return item


def run_compaction_sweep(
    memory: Any,
    now: Optional[datetime] = None,
    max_items: int = DEFAULT_MAX_ITEMS,
) -> Dict[str, int]:
    """Iterate workspace items, progress each to its target tier.

    Mirrors the ``run_decay_sweep`` pagination-substitute pattern — doubling
    ``top_k`` on each outer iteration until the result set stops growing.

    Returns:
        Stats dict with ``scanned`` / ``progressed`` / ``skipped`` /
        ``tier_1_preserved`` / ``llm_failures`` counters.
    """
    now = now or datetime.now(timezone.utc)
    scanned = 0
    progressed = 0
    skipped = 0
    tier_1_preserved = 0
    llm_failures = 0
    seen_ids: set[str] = set()

    if not _compaction_enabled(memory):
        logger.debug("compaction: disabled on memory (tier_compaction=False)")
        return {
            "scanned": 0,
            "progressed": 0,
            "skipped": 0,
            "tier_1_preserved": 0,
            "llm_failures": 0,
            "disabled": 1,
        }

    top_k = 500
    batch_cap = 500
    while top_k <= max_items:
        try:
            items = memory.search(query="*", top_k=top_k) or []
        except Exception as exc:
            logger.warning("run_compaction_sweep: search failed — %s", exc)
            break

        new_items = [
            it for it in items
            if getattr(it, "item_id", None) and it.item_id not in seen_ids
        ]
        if not new_items:
            break

        for item in new_items:
            seen_ids.add(item.item_id)
            scanned += 1

            # Authoritative re-read: ``memory.search()`` is observed to
            # strip ``memory_type`` and ``origin`` for some rows (the
            # FalkorDB read-path coerces them to defaults); ``_crud.get()``
            # returns the actual stored values. This single re-read also
            # hardens the existing tier-1 short-circuit below — both the
            # B2 snapshot guard and the tier-1 preservation rely on
            # ``origin`` being correct, so neither can trust the search
            # result alone.
            authoritative = _resolve_authoritative(memory, item)
            origin = getattr(authoritative, "origin", None) or ""
            memory_type = getattr(authoritative, "memory_type", None)

            # CORE-SUMMARY-1 D4/B2: snapshots are append-only digests.
            # Retention sweep alone governs their lifetime — tier compaction
            # would only waste LLM calls trying to summarize a summary.
            if memory_type == "snapshot" or origin.startswith("snapshot:"):
                skipped += 1
                continue

            # Tier-1 short-circuit — accounted separately for telemetry.
            if origin and get_origin_tier(origin) == 1:
                tier_1_preserved += 1
                continue

            target = determine_target_tier(item, now)
            current = _current_tier(item)
            if current == target:
                skipped += 1
                continue

            outcome = progress_item(memory, item, target, now)
            if outcome == "progressed":
                progressed += 1
            elif outcome == "llm_failed":
                llm_failures += 1
            else:
                skipped += 1

        if len(items) < top_k:
            break
        next_top_k = top_k * 2
        if next_top_k > max_items:
            break
        top_k = next_top_k

    logger.info(
        "run_compaction_sweep: scanned=%d progressed=%d skipped=%d "
        "tier_1_preserved=%d llm_failures=%d",
        scanned, progressed, skipped, tier_1_preserved, llm_failures,
    )
    return {
        "scanned": scanned,
        "progressed": progressed,
        "skipped": skipped,
        "tier_1_preserved": tier_1_preserved,
        "llm_failures": llm_failures,
    }


def progress_item(
    memory: Any, item: Any, target_tier: str, now: datetime
) -> str:
    """Transition a single item to ``target_tier``. Returns outcome string.

    Outcomes: ``"progressed"`` / ``"llm_failed"`` / ``"skipped"``.
    """
    current = _current_tier(item)
    if current == target_tier:
        return "skipped"

    # Generate new content per target tier.
    content = getattr(item, "content", "") or ""
    snapshots = dict(_extract_snapshots(item))

    # Preserve any fidelity level we don't already have that's >= current.
    # When transitioning FULL → SUMMARY, we capture the FULL snapshot now.
    if current == TIER_FULL and TIER_FULL not in snapshots:
        snapshots[TIER_FULL] = content

    if target_tier == TIER_SUMMARY:
        new_content = compress_to_summary(content)
        if new_content is None:
            return "llm_failed"
        snapshots.setdefault(TIER_SUMMARY, new_content)
    elif target_tier == TIER_SKELETON:
        # Preserve SUMMARY snapshot on the way down if we're skipping it.
        if current in (TIER_FULL, TIER_SUMMARY) and TIER_SUMMARY not in snapshots:
            summary_text = compress_to_summary(content)
            if summary_text is None:
                return "llm_failed"
            snapshots[TIER_SUMMARY] = summary_text
        new_content = compress_to_skeleton(content)
        if new_content is None:
            return "llm_failed"
        snapshots.setdefault(TIER_SKELETON, new_content)
    elif target_tier == TIER_TOMBSTONE:
        # Ensure SUMMARY + SKELETON exist for rehydration.
        if TIER_SUMMARY not in snapshots:
            summary_text = compress_to_summary(content)
            if summary_text is None:
                return "llm_failed"
            snapshots[TIER_SUMMARY] = summary_text
        if TIER_SKELETON not in snapshots:
            skel_text = compress_to_skeleton(snapshots.get(TIER_FULL, content))
            if skel_text is None:
                return "llm_failed"
            snapshots[TIER_SKELETON] = skel_text
        new_content = compress_to_tombstone(snapshots.get(TIER_FULL, content))
    elif target_tier == TIER_FORGOTTEN:
        # Preserve SKELETON as evidence per design §Resolved open questions.
        skel_existing = snapshots.get(TIER_SKELETON)
        snapshots = {TIER_SKELETON: skel_existing} if skel_existing else {}
        new_content = ""  # FORGOTTEN strips content
    elif target_tier == TIER_FULL:
        # Upward progression should happen via rehydrate_item, not the sweep.
        return "skipped"
    else:
        logger.warning("progress_item: unknown target tier %r", target_tier)
        return "skipped"

    transitions = list(_extract_transitions(item))
    transitions.append(
        {"from": current, "to": target_tier, "at": now.isoformat()}
    )

    update_payload = {
        "content": new_content,
        COMPACTION_TIER_KEY: target_tier,
        SNAPSHOTS_KEY: snapshots,
        TIER_TRANSITIONS_KEY: transitions,
    }
    try:
        memory.update_properties(item.item_id, update_payload)
    except Exception as exc:
        logger.warning(
            "progress_item: update_properties failed for %s — %s",
            getattr(item, "item_id", "?"), exc,
        )
        return "skipped"
    return "progressed"


# ---------------------------------------------------------------------------
# Rehydration (read-side API — always available, not gated by tier_compaction)
# ---------------------------------------------------------------------------


def rehydrate_from_snapshot(
    memory: Any, item_id: str, target_tier: str = TIER_FULL
) -> Any:
    """Restore ``item_id`` content from the snapshot for ``target_tier``.

    Raises:
        ValueError: when the snapshot for ``target_tier`` is missing.

    Sets ``metadata[needs_reembed] = True`` so a downstream enrichment pass
    can reconcile the embedding asynchronously. Rehydration itself does NOT
    re-embed (embedding generation is expensive).
    """
    if target_tier not in TIER_ORDER:
        raise ValueError(f"unknown target tier: {target_tier!r}")

    # Use _crud.get() so the rehydration read does NOT trigger the retrieval
    # boost hook. M2a Slice B r3 lesson applied to the read side too.
    item = _crud_get(memory, item_id)
    if item is None:
        raise ValueError(f"item not found: {item_id!r}")

    snapshots = dict(_extract_snapshots(item))
    current = _current_tier(item) or TIER_FULL

    if current == target_tier:
        return item  # already at target — no-op

    snapshot_content = snapshots.get(target_tier)
    if snapshot_content is None:
        # Special case: FULL can be restored from snapshots[FULL], which is
        # explicitly captured on the first downward transition. If missing,
        # we genuinely have no recoverable content.
        raise ValueError(
            f"cannot rehydrate {item_id!r} to {target_tier!r}: snapshot missing"
        )

    transitions = list(_extract_transitions(item))
    now = datetime.now(timezone.utc)
    transitions.append(
        {"from": current, "to": target_tier, "at": now.isoformat(), "via": "rehydrate"}
    )

    update_payload = {
        "content": snapshot_content,
        COMPACTION_TIER_KEY: target_tier,
        TIER_TRANSITIONS_KEY: transitions,
        NEEDS_REEMBED_KEY: True,
    }
    memory.update_properties(item_id, update_payload)

    # Re-read the item so the caller sees the post-update state. If the
    # reread fails (e.g. transient CRUD error), we now return None from
    # _crud_get by design (Codex Slice B r1 — preserve the no-boost
    # invariant on the error path). But the public contract of
    # ``SmartMemory.rehydrate_item`` promises a MemoryItem. Raise an
    # explicit RuntimeError rather than silently returning None — the
    # update already happened, the caller just can't see the result
    # this cycle. Codex Slice B r2.
    refreshed = _crud_get(memory, item_id)
    if refreshed is None:
        raise RuntimeError(
            f"rehydrate_from_snapshot: update_properties succeeded for "
            f"{item_id!r} but post-update reread returned None — the "
            f"content has been restored in the backend but the local "
            f"view is unavailable this cycle"
        )
    return refreshed


# ---------------------------------------------------------------------------
# Helpers (module-private)
# ---------------------------------------------------------------------------


def _compaction_enabled(memory: Any) -> bool:
    """Tier-compaction is opt-in via ``SmartMemory(tier_compaction=True)``.

    Defaults to OFF. The worker's ``CompactionSweepJob`` registration is
    gated by ``SMARTMEMORY_COMPACTION_ENABLED`` env var, so end-to-end
    compaction requires BOTH constructor flag + worker env.
    """
    return bool(getattr(memory, "_tier_compaction", False))


def _current_tier(item: Any) -> str:
    md = getattr(item, "metadata", None) or {}
    tier = md.get(COMPACTION_TIER_KEY)
    if isinstance(tier, str) and tier in TIER_ORDER:
        return tier
    return TIER_FULL  # items without a compression_tier are implicitly FULL


def _extract_snapshots(item: Any) -> Dict[str, str]:
    md = getattr(item, "metadata", None) or {}
    snapshots = md.get(SNAPSHOTS_KEY)
    return snapshots if isinstance(snapshots, dict) else {}


def _extract_transitions(item: Any) -> List[Dict[str, str]]:
    md = getattr(item, "metadata", None) or {}
    transitions = md.get(TIER_TRANSITIONS_KEY)
    return transitions if isinstance(transitions, list) else []


def _extract_activation_score(item: Any) -> float:
    md = getattr(item, "metadata", None) or {}
    activation = md.get(NAMESPACE)
    if isinstance(activation, dict):
        try:
            return float(activation.get(SCORE_KEY, 0.0))
        except (TypeError, ValueError):
            return 0.0
    return 0.0


def _item_age_days(item: Any, now: datetime) -> float:
    md = getattr(item, "metadata", None) or {}
    candidates = [
        md.get("ingested_at"),
        md.get("created_at"),
        getattr(item, "ingested_at", None),
        getattr(item, "created_at", None),
    ]
    for c in candidates:
        if not c:
            continue
        if isinstance(c, datetime):
            age = now - (c if c.tzinfo else c.replace(tzinfo=timezone.utc))
            return age.total_seconds() / 86_400.0
        if isinstance(c, str):
            try:
                dt = datetime.fromisoformat(c.replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                age = now - dt
                return age.total_seconds() / 86_400.0
            except ValueError:
                continue
    # Unknown age — treat as "old enough to tombstone" so the ladder still
    # applies to legacy items without timestamp metadata. The practical
    # result is the cold-start guard only protects items we can timestamp.
    return float(TOMBSTONE_MIN_AGE_DAYS + 1)


def _crud_get(memory: Any, item_id: str) -> Any:
    """Fetch via ``memory._crud.get()`` to bypass the retrieval boost hook.

    **Strict invariant:** falls back to ``memory.get()`` **only** when the
    CRUD layer is unavailable (duck-typed test fixtures that never built
    one). A ``_crud.get()`` that RAISES is NOT a fallback trigger —
    returning ``None`` on the error path preserves the no-boost invariant
    that Slice B depends on. Codex r1 finding: a transient CRUD failure
    used to fall through to ``memory.get`` and silently trigger the
    retrieval boost on the very read path we're trying to keep quiet.
    """
    crud = getattr(memory, "_crud", None)
    if crud is not None:
        getter = getattr(crud, "get", None)
        if callable(getter):
            try:
                return getter(item_id)
            except Exception as exc:
                logger.debug(
                    "compaction: _crud.get(%s) failed — returning None "
                    "instead of falling through to memory.get to preserve "
                    "the no-boost invariant (%s)", item_id, exc,
                )
                return None
    # No CRUD layer at all — fall back to memory.get (test fixtures only).
    getter = getattr(memory, "get", None)
    if callable(getter):
        try:
            return getter(item_id)
        except Exception as exc:
            logger.debug("compaction: memory.get(%s) failed — %s", item_id, exc)
    return None
