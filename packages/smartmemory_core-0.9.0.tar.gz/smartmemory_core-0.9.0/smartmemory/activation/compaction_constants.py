"""Progressive-compaction constants (CORE-MEMORY-DYNAMICS-1 M2b Slice B).

Source of truth for tier names, progression thresholds, metadata keys, and
marker templates used by :func:`smartmemory.activation.compaction.run_compaction_sweep`.

The tier ladder collapses the binary ``metadata["archived"] = True`` / absent
state into a 5-level progression driven by activation score + item age:

    FULL → SUMMARY → SKELETON → TOMBSTONE → FORGOTTEN

``FORGOTTEN`` drops both ``content`` and snapshots except ``SKELETON``;
``TOMBSTONE`` replaces content with a fixed marker but preserves all
higher-fidelity snapshots for later :meth:`SmartMemory.rehydrate_item`.

Design reference: ``design-m2b.md`` §5.2-5.3.
"""

# ---------------------------------------------------------------------------
# Metadata keys (nested under item.metadata)
# ---------------------------------------------------------------------------

COMPACTION_TIER_KEY: str = "compression_tier"
SNAPSHOTS_KEY: str = "snapshots"
TIER_TRANSITIONS_KEY: str = "tier_transitions"
NEEDS_REEMBED_KEY: str = "needs_reembed"

# ---------------------------------------------------------------------------
# Tier names + order (FULL is the default / "not yet compressed" state)
# ---------------------------------------------------------------------------

TIER_FULL: str = "FULL"
TIER_SUMMARY: str = "SUMMARY"
TIER_SKELETON: str = "SKELETON"
TIER_TOMBSTONE: str = "TOMBSTONE"
TIER_FORGOTTEN: str = "FORGOTTEN"

# Ordered from most-fidelity to least. Used to preserve higher-fidelity
# snapshots when transitioning downward.
TIER_ORDER: tuple[str, ...] = (
    TIER_FULL,
    TIER_SUMMARY,
    TIER_SKELETON,
    TIER_TOMBSTONE,
    TIER_FORGOTTEN,
)

# ---------------------------------------------------------------------------
# Progression thresholds — activation-score-driven (not time-driven alone)
# ---------------------------------------------------------------------------

TIER_THRESHOLD_SUMMARY: float = 0.4
TIER_THRESHOLD_SKELETON: float = 0.15
TIER_THRESHOLD_TOMBSTONE: float = 0.05

# TOMBSTONE transition requires both low activation AND age >= this bound.
# Prevents recently-ingested items that happen to have low initial activation
# (cold-start) from being tombstoned before they have a chance to warm up.
TOMBSTONE_MIN_AGE_DAYS: int = 30

# Deterministic TOMBSTONE content — no LLM involved on this transition.
TOMBSTONE_MARKER_TEMPLATE: str = "[compressed: {n} chars original]"

# ---------------------------------------------------------------------------
# Sweep cadence (mirror of worker's BaseScheduledJob interval for parity)
# ---------------------------------------------------------------------------

COMPACTION_INTERVAL_SECONDS: int = 21_600  # 6 hours
COMPACTION_LOCK_TTL_SECONDS: int = 1_800  # 30 minutes (LLM calls slow the sweep)
COMPACTION_LOCK_KEY_TEMPLATE: str = "sm:activation:compaction-lock:{workspace_id}"
