"""Activation primitives for CORE-MEMORY-DYNAMICS-1 Milestone 2a.

This package provides the activation-scoring foundation used by
``get_working_context`` ranking and by the three M2a evolvers. The nested
``metadata["activation"]`` dict shape is defined in the activation contract
(``smart-memory-docs/docs/features/CORE-MEMORY-DYNAMICS-1/activation-contract.json``).

Public surface:

- ``compute_activation_score(item, now=None)`` — decays score from last boost.
- ``boost_activation(memory, item_id, delta, reason)`` — Redis-first producer
  with non-raising direct-write fallback.
- ``run_decay_sweep(memory)`` — batched per-workspace decay pass.
- ``migrate_workspace(memory)`` — idempotent Phase A seed (Slice B).
- Constants: ``ACTIVATION_FLOOR``, ``DEFAULT_SCORE``, ``DEFAULT_HALF_LIFE_HOURS``,
  Redis key templates, boost sizes.

**Full-dict invariant:** when ``metadata["activation"]`` is present, all five
sub-keys (score, last_boost_at, half_life_hours, boost_count, rot_score) must
be present. Partial dicts are a contract violation — see
``_merged_activation_dict`` in ``boost.py``.
"""

from smartmemory.activation.constants import (
    ACTIVATION_FLOOR,
    BOOST_SIZE_CORETRIEVE,
    BOOST_SIZE_RETRIEVE,
    BOOST_SIZE_SURFACE,
    DECAY_INTERVAL_SECONDS,
    DEFAULT_HALF_LIFE_HOURS,
    DEFAULT_SCORE,
    FLUSH_INTERVAL_SECONDS,
    NAMESPACE,
    REDIS_DECAY_LOCK_TEMPLATE,
    REDIS_PENDING_KEY_TEMPLATE,
)
from smartmemory.activation.score import compute_activation_score

__all__ = [
    "NAMESPACE",
    "ACTIVATION_FLOOR",
    "DEFAULT_SCORE",
    "DEFAULT_HALF_LIFE_HOURS",
    "BOOST_SIZE_RETRIEVE",
    "BOOST_SIZE_SURFACE",
    "BOOST_SIZE_CORETRIEVE",
    "FLUSH_INTERVAL_SECONDS",
    "DECAY_INTERVAL_SECONDS",
    "REDIS_PENDING_KEY_TEMPLATE",
    "REDIS_DECAY_LOCK_TEMPLATE",
    "compute_activation_score",
]
