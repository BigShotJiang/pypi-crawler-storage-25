"""Data migration scripts.

Naming convention: ``{milestone}_{action}.py``.

Examples:
    m1_rename_working_to_pending.py
    m2a_activation_schema_add.py
"""
