"""Redis key templates and TTLs for session-scoped state (M3 Slice A)."""

# Hash storing {item_id: weight} for a session's active pins.
SESSION_PIN_KEY_TEMPLATE = "sm:session:{session_id}:pins"

# String binding a session to a single workspace — set on first pin,
# enforced on subsequent pins to prevent cross-workspace leakage via
# a shared session's pin set.
SESSION_PINNED_WORKSPACE_KEY_TEMPLATE = "sm:session:{session_id}:pinned_workspace"

# Session state TTL. 24h bounds orphan accumulation when an agent
# forgets to call unpin at session close.
SESSION_TTL_SECONDS: int = 86400  # 24 hours
