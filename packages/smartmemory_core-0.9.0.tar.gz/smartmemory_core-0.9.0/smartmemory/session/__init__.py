"""Session-scoped state for surfacing (CORE-MEMORY-DYNAMICS-1 M3 Slice A).

Session pins are short-lived, Redis-backed boosts that let callers
force specific items to the top of ``get_working_context`` results for
a given session. They live in their own package so the activation
subsystem (workspace-scoped, persistent) and session state
(session-scoped, ephemeral) can evolve independently.

Public surface:

- ``SessionPinStore`` — Redis-backed pin store with workspace binding.
- ``SessionPinWorkspaceConflict`` — raised when a pin tries to cross
  workspace boundaries within a single session.
- ``constants`` — Redis key templates and TTLs.
"""

from smartmemory.session.pins import (
    SessionPinStore,
    SessionPinWorkspaceConflict,
)

__all__ = [
    "SessionPinStore",
    "SessionPinWorkspaceConflict",
]
