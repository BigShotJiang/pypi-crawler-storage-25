"""Session pin store — Redis-backed, workspace-bound (M3 Slice A.2.2).

Pins are a caller-controlled override to the activation-driven ranking
in ``get_working_context``. A pinned item is force-included in the
returned context and gets an additive ``session_pin_boost`` contribution
to its score breakdown.

**Workspace binding** — the first pin in a session binds the session to
a single workspace. Subsequent pins that disagree raise
:class:`SessionPinWorkspaceConflict`. Without this binding, a caller
could accumulate pins across workspaces and, by querying with that
session, retrieve cross-workspace results stitched together via the pin
set. Binding is the structural guarantee against that class of leak.

**TTL** — 24h per design §3.5. Pins and the workspace binding share a
TTL so a session goes away cleanly as a unit.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from smartmemory.session.constants import (
    SESSION_PIN_KEY_TEMPLATE,
    SESSION_PINNED_WORKSPACE_KEY_TEMPLATE,
    SESSION_TTL_SECONDS,
)

logger = logging.getLogger(__name__)


class SessionPinWorkspaceConflict(ValueError):
    """A pin attempted to cross the session's bound workspace.

    Subclasses :class:`ValueError` so callers can catch it as a generic
    input-validation error without depending on this module.
    """


class SessionPinStore:
    """Redis-backed pin primitive.

    Duck-types against any redis.Redis-compatible client. Tests inject
    a fake client; production uses the standard Redis DB-1 client.

    All operations are O(1) HGETALL/HSET/HDEL with the pin hash, so
    callers on the hot path can afford to read pins on every call.
    """

    def __init__(self, redis_client: Any):
        self._r = redis_client

    # ── Write API ──────────────────────────────────────────────────────

    def pin(
        self,
        session_id: str,
        item_id: str,
        weight: float,
        workspace_id: str,
    ) -> None:
        """Add or update a pin. Raises on cross-workspace conflict.

        Always an atomic operation: the pipeline sets the workspace
        binding (if absent) and the pin weight in one round-trip,
        refreshing the TTL on both keys.
        """
        if not session_id or not item_id:
            return
        if not workspace_id:
            # Without a workspace binding target, refuse — pins without
            # a scope are a security foot-gun, not a degraded mode.
            raise ValueError(
                "session pin requires a non-empty workspace_id",
            )

        ws_key = SESSION_PINNED_WORKSPACE_KEY_TEMPLATE.format(
            session_id=session_id,
        )
        pin_key = SESSION_PIN_KEY_TEMPLATE.format(session_id=session_id)

        # Check-then-set pattern for the workspace binding. Race window
        # is negligible in practice (session state is written from one
        # place per session) but if two racing first-pins on the same
        # session landed with different workspaces, the loser's HSET
        # still races — acceptable because the caller's contract is
        # "one session = one workspace", not "first-write-wins across
        # concurrent workspaces." Log a WARNING if we detect the race
        # after the fact.
        existing_ws = self._r.get(ws_key)
        if existing_ws is None:
            # First pin — bind the session atomically with the pin write.
            pipe = self._r.pipeline()
            pipe.set(ws_key, workspace_id, nx=True, ex=SESSION_TTL_SECONDS)
            pipe.hset(pin_key, item_id, str(float(weight)))
            pipe.expire(pin_key, SESSION_TTL_SECONDS)
            pipe.execute()
            return

        if existing_ws != workspace_id:
            raise SessionPinWorkspaceConflict(
                f"session {session_id!r} is bound to workspace "
                f"{existing_ws!r}; cannot pin in {workspace_id!r}. "
                "Start a new session for cross-workspace work.",
            )

        # Same-workspace update — just refresh the pin weight and TTLs.
        pipe = self._r.pipeline()
        pipe.hset(pin_key, item_id, str(float(weight)))
        pipe.expire(pin_key, SESSION_TTL_SECONDS)
        pipe.expire(ws_key, SESSION_TTL_SECONDS)
        pipe.execute()

    def unpin(self, session_id: str, item_id: str) -> None:
        """Remove a single pin. No-op if absent."""
        if not session_id or not item_id:
            return
        pin_key = SESSION_PIN_KEY_TEMPLATE.format(session_id=session_id)
        try:
            self._r.hdel(pin_key, item_id)
        except Exception as exc:
            logger.debug(
                "SessionPinStore.unpin: hdel failed for session=%s item=%s: %s",
                session_id, item_id, exc,
            )

    # ── Read API ───────────────────────────────────────────────────────

    def get_pins(self, session_id: str) -> Dict[str, float]:
        """Return the current pin set for ``session_id``.

        Empty dict for unknown or expired sessions — never raises.
        """
        if not session_id:
            return {}
        pin_key = SESSION_PIN_KEY_TEMPLATE.format(session_id=session_id)
        try:
            raw = self._r.hgetall(pin_key) or {}
        except Exception as exc:
            logger.debug(
                "SessionPinStore.get_pins: hgetall failed for session=%s: %s",
                session_id, exc,
            )
            return {}

        result: Dict[str, float] = {}
        for item_id, weight_raw in raw.items():
            try:
                result[item_id] = float(weight_raw)
            except (TypeError, ValueError):
                logger.debug(
                    "SessionPinStore.get_pins: non-numeric weight at "
                    "session=%s item=%s raw=%r — skipping",
                    session_id, item_id, weight_raw,
                )
                continue
        return result

    def get_workspace(self, session_id: str) -> Optional[str]:
        """Return the workspace the session is bound to, or None if unbound."""
        if not session_id:
            return None
        ws_key = SESSION_PINNED_WORKSPACE_KEY_TEMPLATE.format(
            session_id=session_id,
        )
        try:
            return self._r.get(ws_key)
        except Exception as exc:
            logger.debug(
                "SessionPinStore.get_workspace: get failed for session=%s: %s",
                session_id, exc,
            )
            return None
