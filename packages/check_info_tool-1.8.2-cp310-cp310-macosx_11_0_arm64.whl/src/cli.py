#!/usr/bin/env python3
"""CLI interface for Check Info Tool — extract information from Teradyne IG-XL test programs."""

import argparse
import json
import os
import sys
from importlib.metadata import version as _pkg_version
from tempfile import TemporaryDirectory

from src.check_info import CheckInfo


def _get_version():
    try:
        return _pkg_version("check-info-tool")
    except Exception:
        return "0.0.0"


def create_parser():
    parser = argparse.ArgumentParser(
        prog="check-info",
        description="Extract information from Teradyne IG-XL test programs",
    )
    parser.add_argument("--version", "-V", action="version",
                        version=f"%(prog)s {_get_version()}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # --- list ---
    list_parser = subparsers.add_parser("list", help="List available jobs in a test program")
    _add_common_args(list_parser)
    list_parser.set_defaults(func=cmd_list)

    # --- run ---
    run_parser = subparsers.add_parser("run", help="Run analysis on selected jobs")
    _add_common_args(run_parser)
    run_parser.add_argument(
        "--jobs", "-j", required=True,
        help="Comma-separated job names, or 'all'",
    )
    run_parser.add_argument(
        "--output", "-o", default=".",
        help="Output directory (default: current directory)",
    )
    run_parser.set_defaults(func=cmd_run)

    # --- gui ---
    gui_parser = subparsers.add_parser("gui", help="Launch the graphical user interface")
    gui_parser.set_defaults(func=cmd_gui)

    # --- version (kept as subcommand for backward compatibility) ---
    version_parser = subparsers.add_parser("version", help="Show version")
    version_parser.set_defaults(func=cmd_version)

    return parser


def _add_common_args(parser):
    parser.add_argument("--program", required=True,
                        help="Path to .igxl/.zip/.xlsm file or directory")
    parser.add_argument("--platform", "-p", required=True,
                        choices=["UltraFLEXplus", "UltraFLEX", "J750"])
    parser.add_argument("--cycle-mode", default="Period",
                        choices=["Period", "Frequency"])
    parser.add_argument("--context-env", default="",
                        help="Spec context environment prefix")
    parser.add_argument("--enable-vbt-check", action="store_true",
                        help="Enable VBT naming convention checker")
    parser.add_argument("--power-order", default="",
                        help="Path to power order Excel file")
    parser.add_argument("--pattern-path", default="",
                        help="Path to pattern directory")
    parser.add_argument("--json", action="store_true",
                        help="Output results as JSON")
    parser.add_argument("--quiet", "-q", action="store_true",
                        help="Suppress progress output")


def _make_log_callback(quiet):
    if quiet:
        return None
    def log(msg):
        print(msg, file=sys.stderr)
    return log


def _make_progress_callback(quiet, json_mode):
    if quiet or json_mode:
        return None
    def progress(val):
        pct = int(val)
        bar_len = 30
        filled = int(bar_len * pct / 100)
        bar = "=" * filled + "-" * (bar_len - filled)
        sys.stderr.write(f"\r[{bar}] {pct}%")
        sys.stderr.flush()
        if pct >= 100:
            sys.stderr.write("\n")
    return progress


def _load_jobs(args):
    """Shared logic: validate inputs and return (check_info, job_list_dict, temp_dir)."""
    program = os.path.abspath(args.program)
    if not os.path.exists(program):
        print(f"Error: program path not found: {program}", file=sys.stderr)
        sys.exit(1)

    log_cb = _make_log_callback(args.quiet)
    progress_cb = _make_progress_callback(args.quiet, args.json)

    temp_dir = TemporaryDirectory()
    ci = CheckInfo(temp_dir.name)
    try:
        ci.read_device(
            device_path=program,
            power_order_path=args.power_order,
            pattern_path=args.pattern_path,
            platform=args.platform,
            text=log_cb,
            cycle_mode=args.cycle_mode,
            context_env=args.context_env,
            enable_vbt_check=1 if args.enable_vbt_check else 0,
            progressbarOne=progress_cb,
        )
    except Exception as e:
        print(f"Error loading program: {e}", file=sys.stderr)
        temp_dir.cleanup()
        sys.exit(1)

    job_list = ci.get_job_list()
    if not job_list:
        print("No jobs found in the test program.", file=sys.stderr)
        temp_dir.cleanup()
        sys.exit(1)

    return ci, job_list, temp_dir


def cmd_list(args):
    ci, job_list, temp_dir = _load_jobs(args)
    try:
        if args.json:
            print(json.dumps({"jobs": job_list}, indent=2))
        else:
            print(f"{'Job Name':<30} {'Flow Table':<25} {'DC Spec':<20} {'AC Spec':<20} {'PatternSet':<20}")
            print("-" * 115)
            for name, info in job_list.items():
                flow = info.get("Flow Table", "")
                dc = info.get("DC Spec", "")
                ac = info.get("AC Spec", "")
                pat = ", ".join(info.get("PatternSet", [])) if isinstance(info.get("PatternSet"), list) else str(info.get("PatternSet", ""))
                print(f"{name:<30} {flow:<25} {dc:<20} {ac:<20} {pat:<20}")
    finally:
        temp_dir.cleanup()


def cmd_run(args):
    ci, job_list, temp_dir = _load_jobs(args)
    try:
        if args.jobs.lower() == "all":
            selected = list(job_list.keys())
        else:
            selected = [j.strip() for j in args.jobs.split(",")]
            missing = [j for j in selected if j not in job_list]
            if missing:
                print(f"Error: job(s) not found: {', '.join(missing)}", file=sys.stderr)
                print(f"Available jobs: {', '.join(job_list.keys())}", file=sys.stderr)
                sys.exit(1)

        output_dir = os.path.abspath(args.output)
        os.makedirs(output_dir, exist_ok=True)

        result_paths = ci.run(selected, work_dir=output_dir)

        if args.json:
            print(json.dumps({
                "output_files": result_paths,
                "jobs_run": selected,
            }, indent=2))
        else:
            for path in result_paths:
                print(path)
    except SystemExit:
        raise
    except Exception as e:
        print(f"Error running analysis: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        temp_dir.cleanup()


def cmd_gui(args):
    """Launch the graphical user interface."""
    try:
        from src.gui_application import Application, Menu
    except ImportError:
        print("Error: GUI dependencies (tkinter) not available.", file=sys.stderr)
        sys.exit(1)

    with TemporaryDirectory() as temp_directory:
        check_info_inst = CheckInfo(temp_directory)
        app = Application(check_info_inst)

        def _quit():
            app.quit()
            app.destroy()

        app.protocol("WM_DELETE_WINDOW", _quit)
        app.add_menu(Menu)
        app.mainloop()


def cmd_version(args):
    print(f"check-info {_get_version()}")


def main():
    parser = create_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
