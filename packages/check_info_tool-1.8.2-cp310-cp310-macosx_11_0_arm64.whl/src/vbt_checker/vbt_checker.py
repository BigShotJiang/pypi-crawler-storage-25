#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VBT Coding Standards Checker and Refactorer
根据VBT编程规范检查和重构VBA代码

Author: Claude Code Assistant
Date: 2025-11-13
"""

import os
import re
import sys
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass
from enum import Enum
from datetime import datetime
import collections

# 尝试导入pandas，如果失败则提示用户
try:
    import pandas as pd
except ImportError:
    pd = None
    print("警告: pandas未安装，Excel相关功能将不可用。请运行: pip install pandas openpyxl")

class VariableScope(Enum):
    """变量作用域枚举"""
    LOCAL = "local"           # 函数内私有变量
    MODULE_PRIVATE = "module_private"  # 模块内私有变量
    GLOBAL = "global"         # 全局变量
    CLASS_PRIVATE = "class_private"    # 类内私有变量
    CLASS_PUBLIC = "class_public"      # 类内公有变量
    CLASS_EXTERNAL = "class_external"  # 类外部可见变量

class VariableType(Enum):
    """变量类型枚举"""
    INTEGER = "Integer"
    LONG = "Long"
    SINGLE = "Single"
    DOUBLE = "Double"
    STRING = "String"
    BOOLEAN = "Boolean"
    VARIANT = "Variant"
    SITELONG = "SiteLong"
    SITEDOUBLE = "SiteDouble"
    SITEBOOLEAN = "SiteBoolean"
    DSPWAVE = "DspWave"
    ENUM = "Enum"
    TYPE = "Type"
    PINDATA = "PinData"
    PINLISTDATA = "PinListData"
    CSL = "CSL"
    USERCLASS = "UserClass"
    PINLIST = "PinList"
    PATTERN = "Pattern"

class FunctionType(Enum):
    """函数类型枚举"""
    VBT = "VBT"
    DSP = "DSP"
    IP = "IP"
    OTHER = "OTHER"

@dataclass
class VariableInfo:
    """变量信息"""
    name: str
    original_name: str
    scope: VariableScope
    var_type: VariableType
    is_array: bool
    file_path: str
    line_number: int
    function_name: Optional[str] = None
    is_const: bool = False
    correct_name: Optional[str] = None
    issue_description: Optional[str] = None

@dataclass
class FunctionInfo:
    """函数信息"""
    name: str
    original_name: str
    func_type: FunctionType
    file_path: str
    start_line: int
    end_line: int
    parameters: List[Tuple[str, str, str]]  # (name, type, byval_byref)
    issues: List[str]

@dataclass
class TypeInfo:
    """Type/Enum信息"""
    name: str
    original_name: str
    info_type: str  # "Type" or "Enum"
    file_path: str
    line_number: int
    scope: str = "public"  # "public" or "private"
    correct_name: Optional[str] = None
    issue_description: Optional[str] = None
    reference_count: int = 0
    referenced_files: Set[str] = None  # Set of file paths that reference this type/enum

    def __post_init__(self):
        if self.referenced_files is None:
            self.referenced_files = set()

@dataclass
class VariableReference:
    """变量引用信息"""
    var_name: str
    file_path: str
    line_number: int
    function_name: Optional[str] = None
    context: str = ""  # 引用的上下文代码行

class VBTNamingRules:
    """VBT命名规则引擎"""

    # 预留变量名
    RESERVED_VARS = {'i', 'j', 'k', 'm', 'n', 'site'}

    # 类型后缀映射
    TYPE_SUFFIXES = {
        VariableType.INTEGER: ('_int', '_aint'),
        VariableType.LONG: ('_lng', '_alng'),
        VariableType.SINGLE: ('_sgl', '_asgl'),
        VariableType.DOUBLE: ('_dbl', '_adbl'),
        VariableType.STRING: ('_str', '_astr'),
        VariableType.BOOLEAN: ('_bool', '_abool'),
        VariableType.VARIANT: ('_var',),
        VariableType.SITELONG: ('_SLNG', '_aSLNG'),
        VariableType.SITEDOUBLE: ('_SDBL', '_aSDBL'),
        VariableType.SITEBOOLEAN: ('_SBOOL', '_aSBOOL'),
        VariableType.DSPWAVE: ('_DSP',),
        VariableType.ENUM: ('_enum',),
        VariableType.TYPE: ('_type',),
        VariableType.PINDATA: ('_PD',),
        VariableType.PINLISTDATA: ('_PLD',),
        VariableType.CSL: ('_CSL',),
        VariableType.PATTERN: ('_PT',)
    }

    # 作用域前缀
    SCOPE_PREFIXES = {
        VariableScope.LOCAL: 'i_',
        VariableScope.MODULE_PRIVATE: 'm_',
        VariableScope.GLOBAL: 'g_',
        VariableScope.CLASS_PRIVATE: 'i_',
        VariableScope.CLASS_PUBLIC: 'm_',
        VariableScope.CLASS_EXTERNAL: 'v_'
    }

    @classmethod
    def check_function_parameter(cls, param_name: str, param_type: str, byval_byref: str,
                                 func_type: FunctionType) -> Tuple[str, str]:
        """
        检查函数参数命名

        Args:
            param_name: 参数名
            param_type: 参数类型
            byval_byref: ByVal/ByRef指定
            func_type: 函数类型 (VBT, DSP, OTHER, IP)

        Returns:
            Tuple[str, str]: (正确名称, 问题描述)
        """
        if func_type == FunctionType.VBT:
            # VBT传参：应该使用PascalCase，无前缀
            if param_name.startswith(('in_', 'out_', 'inout_')):
                # VBT函数不应该有in_/out_前缀
                base_name = param_name
                # 移除前缀获取基础名称
                if param_name.startswith('in_'):
                    base_name = param_name[3:]
                elif param_name.startswith('out_'):
                    base_name = param_name[4:]
                elif param_name.startswith('inout_'):
                    base_name = param_name[6:]

                # 转换为PascalCase
                correct_name = cls._to_camel_style(base_name)
                return correct_name, f"VBT函数参数 '{param_name}' 不应有前缀，应为PascalCase格式：'{correct_name}'"

            # 检查是否为PascalCase
            if not cls._is_camel_style(param_name):
                correct_name = cls._to_camel_style(param_name)
                return correct_name, f"VBT函数参数 '{param_name}' 应为PascalCase格式：'{correct_name}'"

            return param_name, None

        elif func_type in [FunctionType.DSP, FunctionType.OTHER]:
            # DSP传参和非VBT传参：应该有in_/out_/inout_前缀 + PascalCase，强制指定ByVal/ByRef

            # 首先检查是否指定了ByVal或ByRef
            if not byval_byref:
                # 没有指定ByVal/ByRef，这是VBT规则要求的
                return param_name, f"DSP/非VBT函数参数 '{param_name}' 必须指定ByVal或ByRef"

            # 检查是否有正确的前缀
            has_valid_prefix = False
            if param_name.startswith('in_'):
                has_valid_prefix = True
                base_name = param_name[3:]
            elif param_name.startswith('out_'):
                has_valid_prefix = True
                base_name = param_name[4:]
            elif param_name.startswith('inout_'):
                has_valid_prefix = True
                base_name = param_name[6:]

            if not has_valid_prefix:
                # 没有前缀，根据类型建议添加
                # 这里简化处理，默认建议in_前缀
                correct_name = "in_" + cls._to_camel_style(param_name)
                return correct_name, f"DSP/非VBT函数参数 '{param_name}' 应有in_/out_/inout_前缀，建议：'{correct_name}'"

            # 检查基础名称是否为PascalCase
            if not cls._is_camel_style(base_name):
                correct_base = cls._to_camel_style(base_name)
                if param_name.startswith('in_'):
                    correct_name = "in_" + correct_base
                elif param_name.startswith('out_'):
                    correct_name = "out_" + correct_base
                else:
                    correct_name = "inout_" + correct_base
                return correct_name, f"DSP/非VBT函数参数 '{param_name}' 的基础名称应为PascalCase格式：'{correct_name}'"

            return param_name, None

        elif func_type == FunctionType.IP:
            # Interpose function - 暂时不检查，按照用户要求
            return param_name, None

        return param_name, None

    @classmethod
    def get_correct_variable_name(cls, var_info: VariableInfo) -> Tuple[str, str]:
        """
        获取正确的变量名和问题描述

        Returns:
            Tuple[str, str]: (正确名称, 问题描述)
        """
        current_name = var_info.name
        original_name = var_info.original_name

        # 检查是否为常量 - 常量需要特殊命名规则
        if var_info.is_const:
            return cls._get_correct_constant_name(var_info)

        # 检查是否为预留变量名
        if current_name.lower() in cls.RESERVED_VARS:
            if var_info.scope == VariableScope.LOCAL:
                # 预留变量名只允许在函数内部使用
                if current_name.lower() in {'i', 'j', 'k', 'm', 'n'} and var_info.var_type != VariableType.LONG:
                    return current_name, f"预留变量名 '{current_name}' 必须为 Long 类型"
                if current_name.lower() == 'site' and var_info.var_type != VariableType.VARIANT:
                    return current_name, f"预留变量名 '{current_name}' 必须为 Variant 类型"
                return current_name, None  # 预留变量名符合规则
            else:
                # 预留变量名不能在全局/模块级别使用
                suffix = cls._get_type_suffix(var_info.var_type, var_info.is_array)
                correct_name = f"i_{current_name}{suffix}" if var_info.scope == VariableScope.LOCAL else f"g_{current_name}{suffix}"
                return correct_name, f"预留变量名 '{current_name}' 不能在 {var_info.scope.value} 作用域使用"

        # 检查User Class和PinList特殊情况
        if var_info.var_type in [VariableType.USERCLASS, VariableType.PINLIST]:
            # User Class和PinList不需要后缀，按易读原则命名

            if var_info.scope == VariableScope.LOCAL:
                # 对于局部变量，i_前缀是可选的，和普通局部变量规则一致
                # 检查是否已经有 i_ 前缀
                if current_name.startswith('i_'):
                    prefix = 'i_'
                    base_name = current_name[2:]  # 移除 i_ 前缀
                else:
                    prefix = ''  # i_ 前缀可选，可以为空
                    base_name = current_name

                # 检查基础名称是否符合PascalCaseStyle
                if not cls._is_camel_style(base_name):
                    camel_base_name = cls._to_camel_style(base_name)
                else:
                    camel_base_name = base_name

                # 对于局部变量，提供两种有效的命名选择
                with_prefix = f"i_{camel_base_name}"
                without_prefix = f"{camel_base_name}"

                # 优先选择不带 i_ 的版本（更简洁）
                correct_name = without_prefix

                # 如果当前名称符合两种格式中的任何一种，都认为是正确的
                if current_name in [with_prefix, without_prefix]:
                    return current_name, None
                else:
                    return correct_name, f"{var_info.var_type.value} 类型变量名 '{current_name}' 应为 PascalCaseStyle 格式"
            else:
                # 对于非局部变量，需要作用域前缀
                prefix = cls.SCOPE_PREFIXES.get(var_info.scope, '')
                expected_name = f"{prefix}{current_name}"

                if not current_name.startswith(prefix):
                    return expected_name, f"{var_info.var_type.value} 类型变量需要作用域前缀 '{prefix}'"

                return current_name, None

        # 检查命名规则
        suffix = cls._get_type_suffix(var_info.var_type, var_info.is_array)

        # 对于局部变量，i_ 前缀是可选的
        if var_info.scope == VariableScope.LOCAL:
            # 检查是否已经有 i_ 前缀
            if current_name.startswith('i_'):
                prefix = 'i_'
                base_name = current_name[2:]  # 移除 i_ 前缀
            else:
                prefix = ''  # i_ 前缀可选，可以为空
                base_name = current_name

            # 移除类型后缀获取基础名称
            for type_suffixes in cls.TYPE_SUFFIXES.values():
                for type_suffix in type_suffixes:
                    if base_name.endswith(type_suffix):
                        base_name = base_name[:-len(type_suffix)]
                        break

            # 检查基础名称是否符合PascalCaseStyle
            if not cls._is_camel_style(base_name):
                camel_base_name = cls._to_camel_style(base_name)
            else:
                camel_base_name = base_name

            # 对于局部变量，提供两种有效的命名选择
            with_prefix = f"i_{camel_base_name}{suffix}"
            without_prefix = f"{camel_base_name}{suffix}"

            # 优先选择不带 i_ 的版本（更简洁）
            correct_name = without_prefix

            # 如果当前名称符合两种格式中的任何一种，都认为是正确的
            if current_name in [with_prefix, without_prefix]:
                return current_name, None

            # 否则推荐不带 i_ 的版本
            return correct_name, f"变量命名不符合规范，建议使用 '{correct_name}' 或 '{with_prefix}'"

        # 对于非局部变量，作用域前缀是强制的
        else:
            prefix = cls.SCOPE_PREFIXES.get(var_info.scope, '')

            # 移除现有前缀和后缀，获取基础名称
            base_name = current_name
            for scope_prefix in cls.SCOPE_PREFIXES.values():
                if base_name.startswith(scope_prefix):
                    base_name = base_name[len(scope_prefix):]
                    break

            for type_suffixes in cls.TYPE_SUFFIXES.values():
                for type_suffix in type_suffixes:
                    if base_name.endswith(type_suffix):
                        base_name = base_name[:-len(type_suffix)]
                        break

            # 检查基础名称是否符合PascalCaseStyle
            if not cls._is_camel_style(base_name):
                camel_base_name = cls._to_camel_style(base_name)
            else:
                camel_base_name = base_name

            correct_name = f"{prefix}{camel_base_name}{suffix}"

            if current_name != correct_name:
                return correct_name, f"变量命名不符合规范，应为 '{correct_name}'"

            return current_name, None

    @classmethod
    def _get_correct_constant_name(cls, var_info: VariableInfo) -> Tuple[str, str]:
        """
        获取正确的常量名称和问题描述

        常量命名规则：
        - 使用下划线命名法
        - 所有字母大写
        - 前缀和后缀规则同变量相同
        """
        current_name = var_info.name
        scope = var_info.scope
        var_type = var_info.var_type
        is_array = var_info.is_array

        # 获取作用域前缀
        prefix = cls.SCOPE_PREFIXES.get(scope, '')

        # 获取类型后缀（常量使用小写版本，符合VBT编程规范）
        suffix = cls._get_type_suffix(var_type, is_array)

        # 检查当前名称是否符合常量命名格式
        # 常量应该是：前缀 + 基础名称(全大写+下划线) + 后缀
        expected_pattern = f'^{prefix}([A-Z0-9_]+){suffix}$'

        # 首先检查名称是否已经符合常量命名规则
        # 常量应该：前缀 + 基础名称(全大写+下划线) + 后缀
        if current_name.startswith(prefix):
            # 提取基础名称（去除前缀）
            base_name = current_name[len(prefix):]

            # 检查是否以正确的类型后缀结尾
            if suffix and base_name.endswith(suffix):
                base_name_without_suffix = base_name[:-len(suffix)]

                # 检查基础名称是否全大写且只包含字母、数字和下划线
                if base_name_without_suffix.isupper() and re.match(r'^[A-Z0-9_]+$', base_name_without_suffix):
                    return current_name, None
            elif not suffix:  # 如果没有后缀要求
                # 检查整个名称（除前缀外）是否全大写
                if base_name.isupper() and re.match(r'^[A-Z0-9_]+$', base_name):
                    return current_name, None
            else:
                # 格式符合但内容不符合，生成正确的大写版本
                correct_base = base_name.upper()
                # 将驼峰命名转换为下划线命名
                correct_base = cls._camel_to_snake_case(correct_base)
                correct_name = f"{prefix}{correct_base}{suffix}"
                return correct_name, f"常量名 '{current_name}' 应使用全大写和下划线格式，建议改为：'{correct_name}'"

        # 当前名称不符合常量格式，生成正确的常量名称
        # 移除现有的前缀和后缀
        base_name = current_name
        for scope_prefix in cls.SCOPE_PREFIXES.values():
            if base_name.startswith(scope_prefix):
                base_name = base_name[len(scope_prefix):]
                break

        for type_suffixes in cls.TYPE_SUFFIXES.values():
            for type_suffix in type_suffixes:
                if base_name.endswith(type_suffix):
                    base_name = base_name[:-len(type_suffix)]
                    break

        # 转换为下划线全大写格式
        # 首先转换为驼峰格式，再转换为下划线格式
        camel_base = cls._to_camel_style(base_name)
        snake_base = cls._camel_to_snake_case(camel_base).upper()

        correct_name = f"{prefix}{snake_base}{suffix}"

        return correct_name, f"常量名 '{current_name}' 应使用下划线全大写格式，建议改为：'{correct_name}'"

    @classmethod
    def _camel_to_snake_case(cls, camel_str: str) -> str:
        """将驼峰命名转换为下划线命名"""
        if not camel_str:
            return ""

        # 在大写字母前添加下划线（除了第一个字符）
        snake_str = ''
        for i, char in enumerate(camel_str):
            if char.isupper() and i > 0:
                # 检查前一个字符是否是小写或数字，如果是则添加下划线
                if camel_str[i-1].islower() or camel_str[i-1].isdigit():
                    snake_str += '_'
                # 检查后一个字符是否是小写，如果是则添加下划线
                elif i < len(camel_str) - 1 and camel_str[i+1].islower():
                    snake_str += '_'
            snake_str += char

        return snake_str

    @classmethod
    def _get_type_suffix(cls, var_type: VariableType, is_array: bool) -> str:
        """获取类型后缀"""
        if var_type in cls.TYPE_SUFFIXES:
            suffixes = cls.TYPE_SUFFIXES[var_type]
            return suffixes[1] if is_array and len(suffixes) > 1 else suffixes[0]
        return ''

    @classmethod
    def _is_camel_style(cls, name: str) -> bool:
        """检查是否符合PascalCaseStyle命名（大驼峰命名法，所有首字母大写）"""
        if not name:
            return False
        # 首字母大写，其余字母可以是大写或小写
        return name[0].isupper() and name.replace('_', '').isalnum()

    @classmethod
    def _to_camel_style(cls, name: str) -> str:
        """转换为PascalCaseStyle命名（大驼峰命名法，所有首字母大写）"""
        if not name:
            return ''

        # 检查是否有分隔符（下划线等），如果有则进行分割处理
        if re.search(r'[^a-zA-Z0-9]', name):
            # 有分隔符，进行分割处理
            words = re.split(r'[^a-zA-Z0-9]+', name)
            words = [word for word in words if word]
            if not words:
                return ''

            # 所有单词首字母大写
            return ''.join(word.capitalize() for word in words)

        # 没有分隔符，检查是否已经是正确格式
        if name[0].isupper():
            # 首字母已经大写，直接返回
            return name

        # 首字母小写，转换为大写
        return name.capitalize()

class VBAParser:
    """VBA代码解析器"""

    def __init__(self):
        self.files: Dict[str, List[str]] = {}  # 文件路径 -> 文件行内容
        self.global_variables: List[VariableInfo] = []
        self.module_variables: Dict[str, List[VariableInfo]] = {}  # file_path -> variables
        self.local_variables: Dict[str, List[VariableInfo]] = {}  # function_key -> variables
        self.functions: Dict[str, FunctionInfo] = {}
        self.types: Dict[str, TypeInfo] = {}
        self.enums: Dict[str, TypeInfo] = {}
        # 交叉引用跟踪
        self.variable_references: Dict[str, List[VariableReference]] = collections.defaultdict(list)  # var_name -> references

    def parse_files(self, directory_path: str):
        """解析目录中的所有.bas文件"""
        bas_files = []
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                if file.lower().endswith('.bas'):
                    bas_files.append(os.path.join(root, file))

        print(f"找到 {len(bas_files)} 个 .bas 文件")

        # 第一遍：解析所有文件，收集声明信息
        for file_path in bas_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                    self.files[file_path] = lines
                    self._parse_file(file_path, lines)
            except Exception as e:
                print(f"解析文件 {file_path} 时出错: {e}")

        # 第二遍：收集所有变量的引用信息
        self._collect_variable_references()

        # 第三遍：检查函数参数命名
        self._check_function_parameters()

        print(f"解析完成：{len(self.global_variables)} 个全局变量，{len(self.functions)} 个函数")

    def _check_function_parameters(self):
        """检查函数参数命名"""

        for func_key, func_info in self.functions.items():
            if not func_info.parameters:
                continue

            for param_name, param_type, byval_byref in func_info.parameters:
                correct_name, issue = VBTNamingRules.check_function_parameter(
                    param_name, param_type, byval_byref, func_info.func_type
                )

                if issue:
                    # 将参数问题添加到函数的issues列表中
                    param_issue = f"参数 '{param_name}': {issue}"
                    if correct_name != param_name:
                        param_issue += f" (建议改为: '{correct_name}')"
                    func_info.issues.append(param_issue)

    def _parse_file(self, file_path: str, lines: List[str]):
        """解析单个文件"""
        in_function = False
        current_function = None
        function_start_line = 0
        function_content = []

        for line_num, line in enumerate(lines, 1):
            line_stripped = line.strip()

            # 解析函数定义（优先于变量声明检查）
            if self._is_function_definition(line_stripped):
                if in_function and current_function:
                    # 结束前一个函数
                    current_function.end_line = line_num - 1
                    key = f"{file_path}:{current_function.name}"
                    self.functions[key] = current_function

                in_function = True
                function_start_line = line_num
                current_function = self._parse_function_definition(line_stripped, file_path, line_num)
                function_content = [line]

            # 解析Type定义（优先于变量声明）
            elif not in_function and (line_stripped.startswith('Type ') or re.match(r'^\s*(Public|Private)\s+Type\s+', line_stripped, re.IGNORECASE)):
                self._parse_type_definition(line_stripped, lines, line_num, file_path)

            # 解析Enum定义（优先于变量声明）
            elif not in_function and (line_stripped.startswith('Enum ') or re.match(r'^\s*(Public|Private)\s+Enum\s+', line_stripped, re.IGNORECASE)):
                self._parse_enum_definition(line_stripped, lines, line_num, file_path)

            # 解析全局/模块变量声明
            elif not in_function and self._is_variable_declaration(line_stripped):
                self._parse_variable_declaration(line_stripped, file_path, line_num, None)

            # 解析函数内变量声明
            elif in_function and current_function:
                function_content.append(line)
                if self._is_variable_declaration(line_stripped):
                    self._parse_variable_declaration(line_stripped, file_path, line_num, current_function.name)

            # 解析函数结束
            elif in_function and (line_stripped.startswith('End Function') or line_stripped.startswith('End Sub')):
                if current_function:
                    current_function.end_line = line_num
                    key = f"{file_path}:{current_function.name}"
                    self.functions[key] = current_function
                in_function = False
                current_function = None
                function_content = []

        # 检查是否在文件末尾仍然在函数中
        if in_function and current_function:
            current_function.end_line = len(lines)
            key = f"{file_path}:{current_function.name}"
            self.functions[key] = current_function

    def _is_variable_declaration(self, line: str) -> bool:
        """检查是否为变量声明行"""
        # 首先确保不是函数定义
        if self._is_function_definition(line):
            return False

        patterns = [
            r'^\s*(Public|Private|Global|Dim|Const)\s+',
            r'^\s*(Public|Private|Global)\s+Const\s+'
        ]
        return any(re.match(pattern, line, re.IGNORECASE) for pattern in patterns)

    def _parse_variable_declaration(self, line: str, file_path: str, line_num: int, function_name: Optional[str]):
        """解析变量声明"""
        # 简化的解析逻辑，实际项目中需要更复杂的解析
        try:
            # 匹配变量声明模式 - 修复正则表达式，支持New关键字和Const关键字
            pattern = r'^\s*(Public|Private|Global|Dim|Const)\s+(?:(Const)\s+)?(?P<names>.+?)\s+As\s+(?:New\s+)?(?P<type>\w+)(?:\s*\([^)]*\))?\s*(?:=\s*.+)?$'
            match = re.match(pattern, line, re.IGNORECASE)

            if match:
                scope_keyword = match.group(1).lower()
                const_keyword = match.group(2)  # Could be 'Const' or None
                names_part = match.group('names')
                var_type_str = match.group('type')

                # 确定作用域
                if function_name:
                    scope = VariableScope.LOCAL
                elif scope_keyword in ['public', 'global']:
                    scope = VariableScope.GLOBAL
                elif scope_keyword in ['private', 'dim']:
                    scope = VariableScope.MODULE_PRIVATE
                elif scope_keyword == 'const':
                    # 常量的作用域由其修饰符决定
                    # 如果没有明确的修饰符，默认为模块级别
                    scope = VariableScope.MODULE_PRIVATE
                else:
                    scope = VariableScope.LOCAL

                # 解析变量类型
                var_type = self._parse_variable_type(var_type_str)
                is_const = const_keyword is not None or scope_keyword == 'const'
                is_array = '(' in line

                # 处理多个变量声明
                var_names = [name.strip() for name in names_part.split(',')]

                for var_name in var_names:
                    var_info = VariableInfo(
                        name=var_name,
                        original_name=var_name,
                        scope=scope,
                        var_type=var_type,
                        is_array=is_array,
                        file_path=file_path,
                        line_number=line_num,
                        function_name=function_name,
                        is_const=is_const
                    )

                    # 检查命名并生成问题
                    correct_name, issue = VBTNamingRules.get_correct_variable_name(var_info)
                    if issue:
                        var_info.correct_name = correct_name
                        var_info.issue_description = issue

                    # 分类存储
                    if scope == VariableScope.GLOBAL:
                        self.global_variables.append(var_info)
                    elif function_name:
                        func_key = f"{file_path}:{function_name}"
                        if func_key not in self.local_variables:
                            self.local_variables[func_key] = []
                        self.local_variables[func_key].append(var_info)
                    else:
                        if file_path not in self.module_variables:
                            self.module_variables[file_path] = []
                        self.module_variables[file_path].append(var_info)

        except Exception as e:
            print(f"解析变量声明时出错 (行 {line_num}): {line} - {e}")

    def _parse_variable_type(self, type_str: str) -> VariableType:
        """解析变量类型"""
        type_mapping = {
            'integer': VariableType.INTEGER,
            'long': VariableType.LONG,
            'single': VariableType.SINGLE,
            'double': VariableType.DOUBLE,
            'string': VariableType.STRING,
            'boolean': VariableType.BOOLEAN,
            'variant': VariableType.VARIANT,
            'sitelong': VariableType.SITELONG,
            'sitedouble': VariableType.SITEDOUBLE,
            'siteboolean': VariableType.SITEBOOLEAN,
            'dspwave': VariableType.DSPWAVE,
            'pindata': VariableType.PINDATA,
            'pinlistdata': VariableType.PINLISTDATA,
            'pinlist': VariableType.PINLIST,
            'pattern': VariableType.PATTERN,
            'csl': VariableType.CSL
        }
        return type_mapping.get(type_str.lower(), VariableType.VARIANT)

    def _is_function_definition(self, line: str) -> bool:
        """检查是否为函数定义行"""
        patterns = [
            r'^\s*(Public|Private|Friend)?\s*Function\s+',
            r'^\s*(Public|Private|Friend)?\s*Sub\s+'
        ]
        return any(re.match(pattern, line, re.IGNORECASE) for pattern in patterns)

    def _parse_function_definition(self, line: str, file_path: str, line_num: int) -> FunctionInfo:
        """解析函数定义"""
        # 完整的函数解析，包括参数
        func_pattern = r'^\s*(Public|Private|Friend)?\s*(Function|Sub)\s+(?P<name>\w+)\s*(\((?P<params>.*)\))?'
        func_match = re.match(func_pattern, line, re.IGNORECASE)

        if func_match:
            func_name = func_match.group('name')
            params_str = func_match.group('params') or ''

            # 确定函数类型
            if func_name.endswith('_VBT'):
                func_type = FunctionType.VBT
            elif func_name.endswith('_DSP'):
                func_type = FunctionType.DSP
            elif func_name.endswith('_IP'):
                func_type = FunctionType.IP
            else:
                func_type = FunctionType.OTHER

            # 解析参数
            parameters = self._parse_function_parameters(params_str)

            return FunctionInfo(
                name=func_name,
                original_name=func_name,
                func_type=func_type,
                file_path=file_path,
                start_line=line_num,
                end_line=0,
                parameters=parameters,
                issues=[]
            )

        return FunctionInfo(
            name="unknown",
            original_name="unknown",
            func_type=FunctionType.OTHER,
            file_path=file_path,
            start_line=line_num,
            end_line=0,
            parameters=[],
            issues=[]
        )

    def _parse_function_parameters(self, params_str: str) -> List[Tuple[str, str, str]]:
        """解析函数参数列表
        Returns:
            List[Tuple[str, str, str]]: (name, type, byval_byref)
        """
        if not params_str.strip():
            return []

        parameters = []
        # 分割参数（考虑嵌套的括号）
        param_list = []
        current_param = ""
        paren_count = 0

        for char in params_str:
            if char == '(':
                paren_count += 1
            elif char == ')':
                paren_count -= 1
            elif char == ',' and paren_count == 0:
                if current_param.strip():
                    param_list.append(current_param.strip())
                current_param = ""
                continue

            current_param += char

        if current_param.strip():
            param_list.append(current_param.strip())

        for param in param_list:
            # 解析单个参数: ByVal/ByRef + name + As + type
            param_pattern = r'^(ByVal|ByRef)?\s*(?P<name>\w+)\s*(As\s+(?P<type>[\w\[\]]+))?'
            param_match = re.match(param_pattern, param.strip(), re.IGNORECASE)

            if param_match:
                byval_byref = param_match.group(1) or ""  # empty string if not specified
                name = param_match.group('name')
                var_type = param_match.group('type') or "Variant"

                parameters.append((name, var_type, byval_byref))

        return parameters

    def _parse_type_definition(self, line: str, all_lines: List[str], line_num: int, file_path: str):
        """解析Type定义"""
        type_match = re.match(r'^\s*(?P<scope>Public|Private)?\s*Type\s+(?P<name>\w+)', line, re.IGNORECASE)
        if type_match:
            type_name = type_match.group('name')
            scope_keyword = type_match.group('scope')

            # 确定作用域：默认为 Public（如果未指定）
            scope = "private" if scope_keyword and scope_keyword.lower() == 'private' else "public"

            # 检查命名规则
            if not type_name.startswith('type_'):
                correct_name = f"type_{type_name}"
                issue = f"Type定义应以 'type_' 为前缀"
            else:
                correct_name = None
                issue = None

            type_info = TypeInfo(
                name=type_name,
                original_name=type_name,
                info_type="Type",
                file_path=file_path,
                line_number=line_num,
                scope=scope,
                correct_name=correct_name,
                issue_description=issue
            )

            self.types[f"{file_path}:{type_name}"] = type_info

    def _parse_enum_definition(self, line: str, all_lines: List[str], line_num: int, file_path: str):
        """解析Enum定义"""
        enum_match = re.match(r'^\s*(?P<scope>Public|Private)?\s*Enum\s+(?P<name>\w+)', line, re.IGNORECASE)
        if enum_match:
            enum_name = enum_match.group('name')
            scope_keyword = enum_match.group('scope')

            # 确定作用域：默认为 Public（如果未指定）
            scope = "private" if scope_keyword and scope_keyword.lower() == 'private' else "public"

            # 检查命名规则
            if not enum_name.startswith('enum_'):
                correct_name = f"enum_{enum_name}"
                issue = f"Enum定义应以 'enum_' 为前缀"
            else:
                correct_name = None
                issue = None

            enum_info = TypeInfo(
                name=enum_name,
                original_name=enum_name,
                info_type="Enum",
                file_path=file_path,
                line_number=line_num,
                scope=scope,
                correct_name=correct_name,
                issue_description=issue
            )

            self.enums[f"{file_path}:{enum_name}"] = enum_info

    def _collect_variable_references(self):
        """收集所有变量的引用信息"""
        print("正在收集变量引用信息...")

        # 创建变量名到变量信息的映射
        all_variables = {}

        # 全局变量
        for var in self.global_variables:
            all_variables[var.original_name] = var
            all_variables[var.name] = var  # 也存储当前名称

        # 模块变量
        for file_vars in self.module_variables.values():
            for var in file_vars:
                all_variables[var.original_name] = var
                all_variables[var.name] = var

        # 局部变量
        for func_vars in self.local_variables.values():
            for var in func_vars:
                all_variables[var.original_name] = var
                all_variables[var.name] = var

        # 遍历所有文件，查找变量引用
        for file_path, lines in self.files.items():
            self._collect_references_in_file(file_path, lines, all_variables)

        # 收集 Type/Enum 的引用信息
        self._collect_type_enum_references()

        print(f"收集到 {len(self.variable_references)} 个变量的引用信息")

    def _collect_references_in_file(self, file_path: str, lines: List[str], all_variables: Dict[str, VariableInfo]):
        """在单个文件中收集变量引用"""
        in_function = False
        current_function = None

        for line_num, line in enumerate(lines, 1):
            line_stripped = line.strip()

            # 检查函数边界
            if self._is_function_definition(line_stripped):
                in_function = True
                func_match = re.match(r'^\s*(Public|Private|Friend)?\s*(Function|Sub)\s+(?P<name>\w+)', line_stripped, re.IGNORECASE)
                if func_match:
                    current_function = func_match.group('name')
                # 跳过函数声明行，不在此行中查找变量引用
                continue
            elif line_stripped.startswith('End Function') or line_stripped.startswith('End Sub'):
                in_function = False
                current_function = None
                # 跳过函数结束行
                continue

            # 跳过变量声明行和Type/Enum定义行
            if self._is_variable_declaration(line_stripped) or line_stripped.startswith('Type ') or line_stripped.startswith('Enum '):
                continue

            # 查找变量引用
            self._find_variable_references_in_line(line, line_num, file_path, current_function, all_variables)

    def _find_variable_references_in_line(self, line: str, line_num: int, file_path: str,
                                         function_name: Optional[str], all_variables: Dict[str, VariableInfo]):
        """在单行代码中查找变量引用"""
        # 简化的变量名匹配模式
        # 匹配单词边界，避免匹配到字符串字面量
        pattern = r'\b([a-zA-Z_][a-zA-Z0-9_]*)\b'

        # 排除关键字、函数名和VBA保留字
        vba_keywords = {
            'If', 'Then', 'Else', 'ElseIf', 'End', 'Select', 'Case', 'For', 'To', 'Next',
            'While', 'Wend', 'Do', 'Loop', 'Until', 'Exit', 'Goto', 'On', 'Error',
            'Resume', 'With', 'Function', 'Sub', 'Property', 'Get', 'Let', 'Set',
            'Public', 'Private', 'Friend', 'Global', 'Dim', 'Const', 'As', 'ByVal', 'ByRef',
            'Optional', 'ParamArray', 'Type', 'Enum', 'Nothing', 'True', 'False', 'Me',
            'Function', 'Sub'  # 添加函数/子程序关键字
        }

        # 添加已知的函数名到排除列表
        function_names = set()
        for func_info in self.functions.values():
            function_names.add(func_info.name)
            function_names.add(func_info.original_name)

        for match in re.finditer(pattern, line):
            var_name = match.group(1)

            # 跳过VBA关键字和函数名
            if var_name in vba_keywords or var_name in function_names:
                continue

            # 检查是否为已声明的变量
            if var_name in all_variables:
                var_info = all_variables[var_name]

                # 创建引用信息
                reference = VariableReference(
                    var_name=var_name,
                    file_path=file_path,
                    line_number=line_num,
                    function_name=function_name,
                    context=line.strip()
                )

                self.variable_references[var_name].append(reference)

    def get_variable_references(self, var_name: str) -> List[VariableReference]:
        """获取指定变量的所有引用"""
        return self.variable_references.get(var_name, [])

    def get_all_variable_issues(self) -> Dict[str, List[VariableInfo]]:
        """获取所有有问题的变量，按问题类型分类"""
        issues = {
            'global_variables': [],
            'module_variables': [],
            'local_variables': [],
            'type_definitions': [],
            'enum_definitions': []
        }

        # 全局变量问题
        for var in self.global_variables:
            if var.issue_description:
                issues['global_variables'].append(var)

        # 模块变量问题
        for file_vars in self.module_variables.values():
            for var in file_vars:
                if var.issue_description:
                    issues['module_variables'].append(var)

        # 局部变量问题
        for func_vars in self.local_variables.values():
            for var in func_vars:
                if var.issue_description:
                    issues['local_variables'].append(var)

        # Type定义问题
        for type_info in self.types.values():
            if type_info.issue_description:
                issues['type_definitions'].append(type_info)

        # Enum定义问题
        for enum_info in self.enums.values():
            if enum_info.issue_description:
                issues['enum_definitions'].append(enum_info)

        return issues

    def _collect_type_enum_references(self):
        """收集 Type/Enum 的引用信息"""
        # 创建 Type/Enum 名称到信息的映射
        all_types = {}

        # 添加所有 Types
        for type_key, type_info in self.types.items():
            all_types[type_info.name] = type_info
            all_types[type_info.original_name] = type_info

        # 添加所有 Enums
        for enum_key, enum_info in self.enums.items():
            all_types[enum_info.name] = enum_info
            all_types[enum_info.original_name] = enum_info

        # 遍历所有文件，查找 Type/Enum 引用
        for file_path, lines in self.files.items():
            for line_num, line in enumerate(lines, 1):
                # 跳过 Type/Enum 定义行
                if (re.match(r'^\s*(Public|Private)?\s*(Type|Enum)\s+', line, re.IGNORECASE)):
                    continue

                # 查找 Type/Enum 引用（在变量声明或函数参数中）
                for type_name, type_info in all_types.items():
                    if re.search(r'\b' + re.escape(type_name) + r'\b', line):
                        type_info.reference_count += 1
                        type_info.referenced_files.add(file_path)

class VBTRefactorer:
    """VBT代码重构器"""

    def __init__(self, parser: VBAParser):
        self.parser = parser
        self.changes_made = collections.defaultdict(list)

    def _is_variable_declaration(self, line: str) -> bool:
        """检查是否为变量声明行"""
        patterns = [
            r'^\s*(Public|Private|Global|Dim|Const)\s+',
            r'^\s*(Public|Private|Global)\s+Const\s+'
        ]
        return any(re.match(pattern, line, re.IGNORECASE) for pattern in patterns)

    def _is_function_definition(self, line: str) -> bool:
        """检查是否为函数定义行"""
        patterns = [
            r'^\s*(Public|Private|Friend)?\s*Function\s+',
            r'^\s*(Public|Private|Friend)?\s*Sub\s+'
        ]
        return any(re.match(pattern, line, re.IGNORECASE) for pattern in patterns)

    def apply_changes_from_excel(self, excel_path: str):
        """从Excel文件中读取修改并应用"""
        if pd is None:
            print("错误: pandas未安装，无法读取Excel文件")
            return False

        try:
            print(f"正在读取Excel报告: {excel_path}")

            # 读取所有工作表
            all_changes = []

            # 读取全局变量修改
            try:
                global_vars_df = pd.read_excel(excel_path, sheet_name="Global Variables")
                if not global_vars_df.empty:
                    # 查找包含修改信息的列（假设有"应用修改"列或类似的标识）
                    apply_columns = [col for col in global_vars_df.columns if '应用' in col or 'apply' in col.lower()]
                    if apply_columns:
                        apply_col = apply_columns[0]
                        # 只选择用户确认要应用的修改
                        confirmed_changes = global_vars_df[global_vars_df[apply_col] == True]

                        for _, row in confirmed_changes.iterrows():
                            if pd.notna(row.get('变量名')) and pd.notna(row.get('正确命名')):
                                self._add_change('global_variable', {
                                    'file_path': row.get('文件路径', ''),
                                    'line_number': int(row.get('行号', 0)),
                                    'original_name': row['变量名'],
                                    'new_name': row['正确命名'],
                                    'description': f"全局变量 '{row['变量名']}' 重命名为 '{row['正确命名']}'",
                                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                })
                                all_changes.append(f"全局变量: {row['变量名']} -> {row['正确命名']}")
            except Exception as e:
                print(f"读取全局变量工作表失败: {e}")

            # 读取模块变量修改
            try:
                module_vars_df = pd.read_excel(excel_path, sheet_name="Module Variables")
                if not module_vars_df.empty:
                    apply_columns = [col for col in module_vars_df.columns if '应用' in col or 'apply' in col.lower()]
                    if apply_columns:
                        apply_col = apply_columns[0]
                        confirmed_changes = module_vars_df[module_vars_df[apply_col] == True]

                        for _, row in confirmed_changes.iterrows():
                            if pd.notna(row.get('变量名')) and pd.notna(row.get('正确命名')):
                                self._add_change('module_variable', {
                                    'file_path': row.get('文件路径', ''),
                                    'line_number': int(row.get('行号', 0)),
                                    'original_name': row['变量名'],
                                    'new_name': row['正确命名'],
                                    'description': f"模块变量 '{row['变量名']}' 重命名为 '{row['正确命名']}'",
                                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                })
                                all_changes.append(f"模块变量: {row['变量名']} -> {row['正确命名']}")
            except Exception as e:
                print(f"读取模块变量工作表失败: {e}")

            # 读取局部变量修改
            try:
                local_vars_df = pd.read_excel(excel_path, sheet_name="Local Variables")
                if not local_vars_df.empty:
                    apply_columns = [col for col in local_vars_df.columns if '应用' in col or 'apply' in col.lower()]
                    if apply_columns:
                        apply_col = apply_columns[0]
                        confirmed_changes = local_vars_df[local_vars_df[apply_col] == True]

                        for _, row in confirmed_changes.iterrows():
                            if pd.notna(row.get('变量名')) and pd.notna(row.get('正确命名')):
                                self._add_change('local_variable', {
                                    'file_path': row.get('文件路径', ''),
                                    'line_number': int(row.get('行号', 0)),
                                    'original_name': row['变量名'],
                                    'new_name': row['正确命名'],
                                    'description': f"局部变量 '{row['变量名']}' 在函数 '{row.get('函数名', '')}' 中重命名为 '{row['正确命名']}'",
                                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                })
                                all_changes.append(f"局部变量: {row['变量名']} -> {row['正确命名']}")
            except Exception as e:
                print(f"读取局部变量工作表失败: {e}")

            if all_changes:
                print(f"从Excel中读取到 {len(all_changes)} 个确认的修改:")
                for change in all_changes[:10]:  # 显示前10个修改
                    print(f"  - {change}")
                if len(all_changes) > 10:
                    print(f"  ... 以及另外 {len(all_changes) - 10} 个修改")

                # 应用修改
                self._apply_all_changes()
                return True
            else:
                print("未找到任何确认的修改")
                return False

        except Exception as e:
            print(f"读取Excel文件失败: {e}")
            return False

    def refactor_all_issues(self):
        """自动修复所有问题"""
        print("开始自动重构...")

        # 1. 重构全局变量
        self._refactor_global_variables()

        # 2. 重构模块变量
        self._refactor_module_variables()

        # 3. 重构局部变量
        self._refactor_local_variables()

        # 4. 重构Type定义
        self._refactor_type_definitions()

        # 5. 重构Enum定义
        self._refactor_enum_definitions()

        # 6. 应用所有修改
        self._apply_all_changes()

        print("自动重构完成！")

    def _refactor_global_variables(self):
        """重构全局变量"""
        for var in self.parser.global_variables:
            if var.correct_name and var.correct_name != var.name:
                self._add_change('global_variable', {
                    'file_path': var.file_path,
                    'line_number': var.line_number,
                    'original_name': var.name,
                    'new_name': var.correct_name,
                    'description': f"全局变量 '{var.name}' 重命名为 '{var.correct_name}'",
                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                })

    def _refactor_module_variables(self):
        """重构模块变量"""
        for file_path, variables in self.parser.module_variables.items():
            for var in variables:
                if var.correct_name and var.correct_name != var.name:
                    self._add_change('module_variable', {
                        'file_path': var.file_path,
                        'line_number': var.line_number,
                        'original_name': var.name,
                        'new_name': var.correct_name,
                        'description': f"模块变量 '{var.name}' 重命名为 '{var.correct_name}'",
                        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    })

    def _refactor_local_variables(self):
        """重构局部变量"""
        for func_key, variables in self.parser.local_variables.items():
            for var in variables:
                if var.correct_name and var.correct_name != var.name:
                    self._add_change('local_variable', {
                        'file_path': var.file_path,
                        'line_number': var.line_number,
                        'original_name': var.name,
                        'new_name': var.correct_name,
                        'description': f"局部变量 '{var.name}' 在函数 '{var.function_name}' 中重命名为 '{var.correct_name}'",
                        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    })

    def _refactor_type_definitions(self):
        """重构Type定义"""
        for type_key, type_info in self.parser.types.items():
            if type_info.correct_name and type_info.correct_name != type_info.name:
                self._add_change('type_definition', {
                    'file_path': type_info.file_path,
                    'line_number': type_info.line_number,
                    'original_name': type_info.name,
                    'new_name': type_info.correct_name,
                    'description': f"Type定义 '{type_info.name}' 重命名为 '{type_info.correct_name}'",
                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                })

    def _refactor_enum_definitions(self):
        """重构Enum定义"""
        for enum_key, enum_info in self.parser.enums.items():
            if enum_info.correct_name and enum_info.correct_name != enum_info.name:
                self._add_change('enum_definition', {
                    'file_path': enum_info.file_path,
                    'line_number': enum_info.line_number,
                    'original_name': enum_info.name,
                    'new_name': enum_info.correct_name,
                    'description': f"Enum定义 '{enum_info.name}' 重命名为 '{enum_info.correct_name}'",
                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                })

    def _add_change(self, change_type: str, change_info: Dict):
        """添加修改记录"""
        self.changes_made[change_type].append(change_info)

    def _apply_all_changes(self):
        """应用所有修改到文件"""
        # 按文件分组修改
        file_changes = collections.defaultdict(list)
        for change_type, changes in self.changes_made.items():
            for change in changes:
                file_changes[change['file_path']].append(change)

        # 对每个文件应用修改
        for file_path, changes in file_changes.items():
            self._apply_changes_to_file(file_path, changes)

    def _apply_changes_to_file(self, file_path: str, changes: List[Dict]):
        """对单个文件应用修改"""
        if file_path not in self.parser.files:
            return

        # 备份原文件
        backup_path = f"{file_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        try:
            with open(file_path, 'r', encoding='utf-8') as src:
                with open(backup_path, 'w', encoding='utf-8') as backup:
                    backup.write(src.read())
            print(f"已备份文件: {backup_path}")
        except Exception as e:
            print(f"备份文件失败 {file_path}: {e}")
            return

        # 读取文件内容
        lines = self.parser.files[file_path].copy()

        # 创建变量名映射
        var_name_mapping = {}
        for change in changes:
            var_name_mapping[change['original_name']] = change['new_name']

        # 应用修改到整个文件，不仅仅是声明行
        self._apply_variable_references_to_file(lines, var_name_mapping, file_path)

        # 同时也要处理声明行的特殊修改（如类型声明等）
        for change in changes:
            line_num = change['line_number'] - 1  # 转换为0基索引
            if 0 <= line_num < len(lines):
                original_name = change['original_name']
                new_name = change['new_name']

                # 在声明行中替换变量名
                pattern = r'\b' + re.escape(original_name) + r'\b'
                lines[line_num] = re.sub(pattern, new_name, lines[line_num])

        # 写入修改后的文件
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.writelines(lines)
            print(f"已修改文件: {file_path}")

            # 输出修改统计
            total_changes = len(var_name_mapping)
            print(f"  - 更新了 {total_changes} 个变量名的所有引用")

        except Exception as e:
            print(f"写入文件失败 {file_path}: {e}")

    def _apply_variable_references_to_file(self, lines: List[str], var_name_mapping: Dict[str, str], file_path: str):
        """应用变量名修改到文件中的所有引用位置"""
        # 获取该文件中所有的函数信息，用于跳过函数名
        vba_keywords = {
            'If', 'Then', 'Else', 'ElseIf', 'End', 'Select', 'Case', 'For', 'To', 'Next',
            'While', 'Wend', 'Do', 'Loop', 'Until', 'Exit', 'Goto', 'On', 'Error',
            'Resume', 'With', 'Function', 'Sub', 'Property', 'Get', 'Let', 'Set',
            'Public', 'Private', 'Friend', 'Global', 'Dim', 'Const', 'As', 'ByVal', 'ByRef',
            'Optional', 'ParamArray', 'Type', 'Enum', 'Nothing', 'True', 'False', 'Me'
        }

        # 获取所有函数名以避免误替换
        function_names = set()
        for func_info in self.parser.functions.values():
            if func_info.file_path == file_path:
                function_names.add(func_info.name)
                function_names.add(func_info.original_name)

        # 逐行处理
        for line_num, line in enumerate(lines):
            line_stripped = line.strip()
            modified_line = line

            # 跳过以下行类型：
            # 1. 函数/子程序声明行
            # 2. 变量声明行
            # 3. Type/Enum定义行
            # 4. 函数/子程序结束行
            if (self._is_function_definition(line_stripped) or
                self._is_variable_declaration(line_stripped) or
                line_stripped.startswith('Type ') or
                line_stripped.startswith('Enum ') or
                line_stripped.startswith('End Function') or
                line_stripped.startswith('End Sub')):
                continue

            # 对每个需要修改的变量名进行替换
            for original_name, new_name in var_name_mapping.items():
                # 使用词边界确保精确匹配
                pattern = r'\b' + re.escape(original_name) + r'\b'

                # 检查这一行中是否包含该变量
                if re.search(pattern, modified_line):
                    # 检查是否为函数名或关键字
                    if (original_name in vba_keywords or
                        original_name in function_names):
                        continue

                    # 替换这个变量名
                    modified_line = re.sub(pattern, new_name, modified_line)

            # 更新行内容
            if modified_line != line:
                lines[line_num] = modified_line

def main():
    if len(sys.argv) < 2:
        print("用法: python vbt_checker.py <目录路径> [模式] [报告路径]")
        print("模式:")
        print("  dry-run  - 仅检查并生成报告 (默认)")
        print("  refactor - 使用已有报告进行重构，不生成新报告")
        print("报告路径:")
        print("  在refactor模式下，指定dry-run模式生成的Excel报告路径")
        sys.exit(1)

    directory_path = sys.argv[1]
    mode = sys.argv[2] if len(sys.argv) > 2 else "dry-run"
    report_path = sys.argv[3] if len(sys.argv) > 3 else None

    if not os.path.exists(directory_path):
        print(f"错误：目录 '{directory_path}' 不存在")
        sys.exit(1)

    print(f"开始处理目录: {directory_path}")
    print(f"模式: {mode}")

    # 创建解析器并解析文件
    parser = VBAParser()
    parser.parse_files(directory_path)

    print("解析完成！")
    print(f"发现 {len(parser.global_variables)} 个全局变量")
    print(f"发现 {len(parser.functions)} 个函数")
    print(f"发现 {len(parser.types)} 个Type定义")
    print(f"发现 {len(parser.enums)} 个Enum定义")

    # 导入Excel报告生成器
    try:
        from src.vbt_checker.excel_reporter import ExcelReporter
        reporter = ExcelReporter()

        if mode == "dry-run":
            # 生成检查报告
            generated_report_path = reporter.generate_dry_run_report(parser, directory_path)
            if not report_path:
                report_path = generated_report_path
            print(f"\n✓ Dry-run报告已生成: {report_path}")
            print("\n请查看报告并确认修改，然后使用refactor模式应用修改")

        elif mode == "refactor":
            if not report_path:
                print("错误：refactor模式需要指定报告路径")
                print("用法: python vbt_checker.py <目录路径> refactor <报告路径>")
                sys.exit(1)

            if not os.path.exists(report_path):
                print(f"错误：指定的报告文件 '{report_path}' 不存在")
                sys.exit(1)

            print(f"使用已有报告: {report_path}")

            # 询问用户是否继续
            response = input("\n是否继续自动重构？(y/N): ").strip().lower()
            if response == 'y':
                # 创建重构器并从Excel报告读取用户确认的修改
                refactorer = VBTRefactorer(parser)
                if refactorer.apply_changes_from_excel(report_path):
                    print("重构应用成功！")

                    # 生成重构报告
                    refactor_report_path = reporter.generate_refactor_report(refactorer.changes_made, directory_path)
                    print(f"✓ 重构报告已生成: {refactor_report_path}")
                else:
                    print("重构应用失败")
            else:
                print("重构已取消")
        else:
            print(f"错误：无效的模式 '{mode}'")
            print("支持的模式:")
            print("  dry-run  - 仅检查并生成报告 (默认)")
            print("  refactor - 使用已有报告进行重构")
            print("用法: python vbt_checker.py <目录路径> [模式] [报告路径]")
            sys.exit(1)

    except ImportError as e:
        print(f"无法导入Excel报告生成器: {e}")
        print("请安装所需依赖: pip install pandas openpyxl")
    except Exception as e:
        print(f"生成报告时出错: {e}")

if __name__ == "__main__":
    main()