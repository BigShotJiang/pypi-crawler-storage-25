#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Excel报告生成器
为VBT检查器生成Excel格式的报告
"""

import pandas as pd
from datetime import datetime
import os
import re
from typing import Dict, List
from src.vbt_checker.vbt_checker import VariableInfo, TypeInfo, FunctionInfo, VariableReference

class ExcelReporter:
    """Excel报告生成器"""

    def __init__(self):
        self.report_data = {}

    def generate_dry_run_report(self,update_progressbar, parser, output_dir: str = ".") -> str:
        """生成dry-run模式的Excel报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"VBT_Checker_Report_{timestamp}.xlsx"
        filepath = os.path.join(output_dir, filename)

        print(f"正在生成dry-run报告: {filepath}")

        # 获取所有问题
        all_issues = parser.get_all_variable_issues()
        update_progressbar(10)

        # 创建Excel writer
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # 1. 全局变量问题
            self._write_variable_issues_sheet(writer, all_issues['global_variables'],
                                            "Global Variables", parser.variable_references)
            update_progressbar(20)

            # 2. 模块变量问题
            self._write_variable_issues_sheet(writer, all_issues['module_variables'],
                                            "Module Variables", parser.variable_references)
            update_progressbar(30)

            # 3. 局部变量问题
            self._write_variable_issues_sheet(writer, all_issues['local_variables'],
                                            "Local Variables", parser.variable_references)
            update_progressbar(40)

            # 4. Type定义问题
            self._write_type_issues_sheet(writer, all_issues['type_definitions'], "Type Definitions")
            update_progressbar(50)

            # 5. Enum定义问题
            self._write_type_issues_sheet(writer, all_issues['enum_definitions'], "Enum Definitions")
            update_progressbar(60)

            # 6. 函数参数命名问题
            self._write_function_issues_sheet(writer, parser.functions, "Function Parameters")
            update_progressbar(70)

            # 7. 统计信息
            self._write_summary_sheet(writer, all_issues, parser)
            update_progressbar(80)

            # 8. 需要人工检查的问题
            self._write_manual_check_sheet(writer, parser, "Manual Check Required")
            update_progressbar(90)

        print(f"Dry-run报告已生成: {filepath}")
        return filepath

    def generate_refactor_report(self, changes_made: Dict, output_dir: str = ".") -> str:
        """生成重构模式的Excel报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"VBT_Refactor_Report_{timestamp}.xlsx"
        filepath = os.path.join(output_dir, filename)

        print(f"正在生成重构报告: {filepath}")

        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # 重构修改记录
            self._write_refactor_changes_sheet(writer, changes_made, "Refactor Changes")

            # 重构统计
            self._write_refactor_summary_sheet(writer, changes_made, "Refactor Summary")

        print(f"重构报告已生成: {filepath}")
        return filepath

    def _write_variable_issues_sheet(self, writer, variables: List[VariableInfo],
                                   sheet_name: str, references: Dict[str, List[VariableReference]]):
        """写入变量问题表"""
        if not variables:
            return

        data = []
        for var in variables:
            refs = references.get(var.original_name, [])

            # For local variables, only count references within the same function
            if var.scope.value == 'local' and var.function_name:
                # Filter references to only those within the declaring function
                filtered_refs = [ref for ref in refs if ref.function_name == var.function_name]
                ref_count = len(filtered_refs)
            else:
                # For global and module variables, count all references
                ref_count = len(refs)

            ref_files = len(set(ref.file_path for ref in refs))

            data.append({
                '变量名': var.name,
                '建议名称': var.correct_name or '',
                '问题描述': var.issue_description or '',
                '作用域': var.scope.value,
                '类型': var.var_type.value,
                '是否数组': '是' if var.is_array else '否',
                '文件路径': var.file_path,
                '行号': var.line_number,
                '所在函数': var.function_name or '',
                '引用次数': ref_count,
                '涉及文件数': ref_files,
                '是否常量': '是' if var.is_const else '否'
            })

        df = pd.DataFrame(data)
        df.to_excel(writer, sheet_name=sheet_name, index=False)

        # 调整列宽
        worksheet = writer.sheets[sheet_name]
        for column in worksheet.columns:
            max_length = max(len(str(cell.value)) for cell in column)
            worksheet.column_dimensions[column[0].column_letter].width = min(max_length + 2, 50)

    def _write_type_issues_sheet(self, writer, types: List[TypeInfo], sheet_name: str):
        """写入Type/Enum问题表"""
        if not types:
            return

        data = []
        for type_info in types:
            data.append({
                '名称': type_info.name,
                '建议名称': type_info.correct_name or '',
                '问题描述': type_info.issue_description or '',
                '类型': type_info.info_type,
                '作用域': type_info.scope.capitalize(),
                '引用次数': type_info.reference_count,
                '涉及文件数': len(type_info.referenced_files),
                '文件路径': type_info.file_path,
                '行号': type_info.line_number
            })

        df = pd.DataFrame(data)
        df.to_excel(writer, sheet_name=sheet_name, index=False)

        # 调整列宽
        worksheet = writer.sheets[sheet_name]
        for column in worksheet.columns:
            max_length = max(len(str(cell.value)) for cell in column)
            worksheet.column_dimensions[column[0].column_letter].width = min(max_length + 2, 50)

    def _write_function_issues_sheet(self, writer, functions: Dict[str, FunctionInfo], sheet_name: str):
        """写入函数参数问题表"""
        data = []
        for func_key, func_info in functions.items():
            # 使用已经在vbt_checker.py中检查好的issues
            for issue in func_info.issues:
                # 解析issue字符串来提取信息
                if "参数" in issue:
                    # 提取参数名（从 "参数 'param_name':" 格式）
                    param_name_match = re.search(r"参数\s+'([^']+)':", issue)
                    param_name = param_name_match.group(1) if param_name_match else "Unknown"

                    # 提取建议名称（从 "建议改为: 'correct_name')" 格式）
                    suggestion_match = re.search(r"建议改为:\s*'([^']*)'", issue)
                    suggestion = suggestion_match.group(1) if suggestion_match else ""

                    data.append({
                        '参数名': param_name,
                        '建议名称': suggestion,
                        '问题描述': issue.split(" (建议改为:")[0] if " (建议改为:" in issue else issue,
                        '函数名': func_info.name,
                        '函数类型': func_info.func_type.value,
                        '类型': "函数参数",  # Parameter type is always "函数参数"
                        '文件路径': func_info.file_path,
                        '行号': func_info.start_line,
                        '所在函数': func_info.name,
                    })

        if not data:
            return

        df = pd.DataFrame(data)
        df.to_excel(writer, sheet_name=sheet_name, index=False)

        # 调整列宽
        worksheet = writer.sheets[sheet_name]
        for column in worksheet.columns:
            max_length = max(len(str(cell.value)) for cell in column)
            worksheet.column_dimensions[column[0].column_letter].width = min(max_length + 2, 50)

  
    def _write_summary_sheet(self, writer, all_issues: Dict, parser):
        """写入统计信息表"""
        summary_data = {
            '检查项目': [
                '全局变量',
                '模块变量',
                '局部变量',
                'Type定义',
                'Enum定义',
                '总计'
            ],
            '发现问题数': [
                len(all_issues['global_variables']),
                len(all_issues['module_variables']),
                len(all_issues['local_variables']),
                len(all_issues['type_definitions']),
                len(all_issues['enum_definitions']),
                sum(len(issues) for issues in all_issues.values())
            ],
            '总数量': [
                len(parser.global_variables),
                sum(len(vars) for vars in parser.module_variables.values()),
                sum(len(vars) for vars in parser.local_variables.values()),
                len(parser.types),
                len(parser.enums),
                'N/A'
            ]
        }

        df = pd.DataFrame(summary_data)
        df.to_excel(writer, sheet_name="Summary", index=False)

    def _write_manual_check_sheet(self, writer, parser, sheet_name: str):
        """写入需要人工检查的问题表"""
        manual_issues = []

        # 检查可能需要人工判断的情况
        # 1. 无法确定类型的变量
        for var in parser.global_variables:
            if var.var_type.value == "Variant" and not var.is_const and var.name not in ['site']:
                manual_issues.append({
                    '检查类型': '变量类型判断',
                    '文件路径': var.file_path,
                    '行号': var.line_number,
                    '问题描述': f"变量 '{var.name}' 为Variant类型，请确认是否为正确类型",
                    '建议操作': '确认变量类型，如有需要请手动更改变量声明'
                })

        # 2. 可能的命名冲突
        var_names = {}
        for var in parser.global_variables:
            if var.name in var_names:
                manual_issues.append({
                    '检查类型': '变量名冲突',
                    '文件路径': var.file_path,
                    '行号': var.line_number,
                    '问题描述': f"变量名 '{var.name}' 可能与其他变量冲突",
                    '建议操作': '检查是否存在命名冲突，考虑重命名'
                })
            else:
                var_names[var.name] = var

        # 3. 函数行数检查
        for func_key, func_info in parser.functions.items():
            line_count = func_info.end_line - func_info.start_line + 1
            if line_count > 60:
                manual_issues.append({
                    '检查类型': '函数长度',
                    '文件路径': func_info.file_path,
                    '行号': func_info.start_line,
                    '问题描述': f"函数 '{func_info.name}' 长度为 {line_count} 行，超过建议的60行",
                    '建议操作': '考虑将函数分解为更小的函数'
                })

        if manual_issues:
            df = pd.DataFrame(manual_issues)
            df.to_excel(writer, sheet_name=sheet_name, index=False)

            # 调整列宽
            worksheet = writer.sheets[sheet_name]
            for column in worksheet.columns:
                max_length = max(len(str(cell.value)) for cell in column)
                worksheet.column_dimensions[column[0].column_letter].width = min(max_length + 2, 50)

    def _write_refactor_changes_sheet(self, writer, changes_made: Dict, sheet_name: str):
        """写入重构修改记录表"""
        data = []
        for change_type, changes in changes_made.items():
            for change in changes:
                data.append({
                    '修改类型': change_type,
                    '文件路径': change.get('file_path', ''),
                    '行号': change.get('line_number', ''),
                    '原名称': change.get('original_name', ''),
                    '新名称': change.get('new_name', ''),
                    '修改描述': change.get('description', ''),
                    '修改时间': change.get('timestamp', '')
                })

        if data:
            df = pd.DataFrame(data)
            df.to_excel(writer, sheet_name=sheet_name, index=False)

    def _write_refactor_summary_sheet(self, writer, changes_made: Dict, sheet_name: str):
        """写入重构统计表"""
        summary_data = []
        total_changes = 0

        for change_type, changes in changes_made.items():
            count = len(changes)
            total_changes += count
            summary_data.append({
                '修改类型': change_type,
                '修改数量': count
            })

        summary_data.append({
            '修改类型': '总计',
            '修改数量': total_changes
        })

        df = pd.DataFrame(summary_data)
        df.to_excel(writer, sheet_name=sheet_name, index=False)