"""
Data Quality Assessment (DQA) module for CLIFpy tables.

This module provides comprehensive DQA functions implementing:

CONFORMANCE CHECKS:
- A.1. Table presence verification
- A.2. Required columns presence check
- B.1. Data type validation
- B.2. Datetime format validation
- B.4. Categorical values validation against mCIDE
- B.5. Category-to-group mapping validation

COMPLETENESS CHECKS:
- A.1. Missingness analysis for required columns
- A.2. Conditional required fields validation
- B. mCIDE value coverage checks
- C.1. Relational integrity checks

DESIGN PRINCIPLES:
- Default backend is Polars (memory-efficient, lazy evaluation)
- Falls back to DuckDB if Polars is unavailable or fails a runtime smoke test
- Uses garbage collection and cache clearing for memory management
"""
import os
import yaml
from typing import List, Dict, Any, Optional, Union
import pandas as pd
import logging
import duckdb
from pathlib import Path 
import gc

# Logger for this module
_logger = logging.getLogger(__name__)

try:
    import polars as pl
    _logger.debug("Polars imported (version %s), running smoke tests", pl.__version__)
    # Smoke test: exercise the compute paths used by DQA checks so that
    # platforms where Polars imports but fails at runtime (e.g. Windows
    # thread-pool/SIMD issues) fall back to DuckDB immediately.
    _smoke_a = pl.LazyFrame({"k": [1, 1, 2], "v": [10, 20, 30]})
    _smoke_a.collect_schema()                                      # 1. schema inspection
    _smoke_a.group_by("k").agg(pl.col("v").sum()).collect()        # 2. group_by + agg
    _smoke_b = pl.LazyFrame({"k": [1, 2]})
    _smoke_a.join(_smoke_b, on="k").collect()                      # 3. join
    _smoke_a.filter(pl.col("k").is_in([1])).collect()              # 4. filter + is_in
    _smoke_a.select(pl.col("v").sum()).collect(streaming=True)     # 5. streaming collect
    del _smoke_a, _smoke_b
    HAS_POLARS = True
except (ImportError, Exception) as _pl_err:
    HAS_POLARS = False
    if not isinstance(_pl_err, ImportError):
        _logger.warning("Polars imported but failed runtime check, falling back to DuckDB: %s", _pl_err)

_ACTIVE_BACKEND = 'polars' if HAS_POLARS else 'duckdb'
_logger.info("DQA backend: %s", _ACTIVE_BACKEND)

# Default plausibility thresholds: {check_name: {error_threshold, warning_threshold}}
# - warning_threshold: percent above which a warning is raised
# - error_threshold: percent above which an error is raised
_DEFAULT_PLAUSIBILITY_THRESHOLDS: Dict[str, Dict[str, float]] = {
    "temporal_ordering": {"error_threshold": 10.0, "warning_threshold": 0.0},
    "numeric_range_plausibility": {"error_threshold": 10.0, "warning_threshold": 0.0},
    "medication_dose_unit_consistency": {"error_threshold": 10.0, "warning_threshold": 0.0},
    "cross_table_temporal": {"error_threshold": 10.0, "warning_threshold": 0.0},
    "duplicate_composite_keys": {"error_threshold": 10.0, "warning_threshold": 0.0},
}


def _load_schema(table_name: str, schema_dir: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Load YAML schema for a table."""
    if schema_dir is None:
        schema_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'schemas')

    schema_file = os.path.join(schema_dir, f'{table_name}_schema.yaml')
    _logger.debug("Loading schema for '%s' from %s", table_name, schema_file)
    if not os.path.exists(schema_file):
        _logger.warning("Schema file not found: %s", schema_file)
        return None

    with open(schema_file, 'r') as f:
        return yaml.safe_load(f)


def get_schema_check_counts(
    table_name: str,
    schema_dir: Optional[str] = None,
) -> Dict[str, int]:
    """Compute expected DQA check message counts from schema alone.

    Returns the expected number of messages per DQA category
    (conformance, completeness, plausibility) for a table,
    determined purely from the schema without needing any data.
    This allows showing ``0/N`` instead of ``N/A`` in combined reports
    for tables a site did not submit.

    Parameters
    ----------
    table_name : str
        Name of the CLIF table (e.g. ``'labs'``, ``'vitals'``).
    schema_dir : str, optional
        Override path to the schemas directory.

    Returns
    -------
    Dict[str, int]
        Keys ``conformance``, ``completeness``, ``plausibility`` each
        mapping to the expected total message count for that category.
    """
    schema = _load_schema(table_name, schema_dir)
    if schema is None:
        return {"conformance": 0, "completeness": 0, "plausibility": 0}

    columns = schema.get('columns', [])
    category_columns = set(schema.get('category_columns') or [])

    # --- Conformance ---
    conf = 0
    # C.1 table_presence: 1 message
    conf += 1
    # C.2 required_columns: 1 per required column
    conf += len(schema.get('required_columns', []))
    # C.3 column_dtypes: 1 per column with data_type
    conf += sum(1 for c in columns if c.get('data_type'))
    # C.4 datetime_format: 1 per DATETIME or DATE column
    conf += sum(1 for c in columns if c.get('data_type') in ('DATETIME', 'DATE'))
    # C.5 categorical_values: 1 per category column with permissible_values
    conf += sum(
        1 for c in columns
        if c['name'] in category_columns and c.get('permissible_values')
    )
    # C.6 category_group_mapping: 1 per mapping entry (category → group pair).
    # When no mappings exist the check emits a "not applicable" info that
    # is filtered out by enrich_issue(), so it contributes 0 to the score.
    mapping_keys = [k for k in schema if k.endswith('_category_to_group_mapping')]
    for k in mapping_keys:
        mapping = schema.get(k, {})
        if mapping:
            conf += len(mapping)
    # C.7 lab_reference_units (labs only): 1 per lab category with defined units.
    # When absent the "not applicable" info is filtered by enrich_issue().
    if table_name == 'labs':
        lab_units = schema.get('lab_reference_units', {})
        if lab_units:
            conf += len(lab_units)

    return {"conformance": conf, "completeness": 0, "plausibility": 0}


class DQAConformanceResult:
    """Container for DQA conformance check results."""

    def __init__(self, check_type: str, table_name: str):
        self.check_type = check_type
        self.table_name = table_name
        self.passed = True
        self.errors: List[Dict[str, Any]] = []
        self.warnings: List[Dict[str, Any]] = []
        self.info: List[Dict[str, Any]] = []
        self.metrics: Dict[str, Any] = {}

    def add_error(self, message: str, details: Optional[Dict] = None):
        self.passed = False
        self.errors.append({"message": message, "details": details or {}})

    def add_warning(self, message: str, details: Optional[Dict] = None):
        self.warnings.append({"message": message, "details": details or {}})

    def add_info(self, message: str, details: Optional[Dict] = None):
        self.info.append({"message": message, "details": details or {}})

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_type": self.check_type,
            "table_name": self.table_name,
            "passed": self.passed,
            "errors": self.errors,
            "warnings": self.warnings,
            "info": self.info,
            "metrics": self.metrics
        }


class DQACompletenessResult:
    """Container for DQA completeness check results."""

    def __init__(self, check_type: str, table_name: str):
        self.check_type = check_type
        self.table_name = table_name
        self.passed = True
        self.errors: List[Dict[str, Any]] = []
        self.warnings: List[Dict[str, Any]] = []
        self.info: List[Dict[str, Any]] = []
        self.metrics: Dict[str, Any] = {}

    def add_error(self, message: str, details: Optional[Dict] = None):
        self.passed = False
        self.errors.append({"message": message, "details": details or {}})

    def add_warning(self, message: str, details: Optional[Dict] = None):
        self.warnings.append({"message": message, "details": details or {}})

    def add_info(self, message: str, details: Optional[Dict] = None):
        self.info.append({"message": message, "details": details or {}})

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_type": self.check_type,
            "table_name": self.table_name,
            "passed": self.passed,
            "errors": self.errors,
            "warnings": self.warnings,
            "info": self.info,
            "metrics": self.metrics
        }


class DQAPlausibilityResult:
    """Container for DQA plausibility check results."""

    def __init__(self, check_type: str, table_name: str):
        self.check_type = check_type
        self.table_name = table_name
        self.passed = True
        self.errors: List[Dict[str, Any]] = []
        self.warnings: List[Dict[str, Any]] = []
        self.info: List[Dict[str, Any]] = []
        self.metrics: Dict[str, Any] = {}

    def add_error(self, message: str, details: Optional[Dict] = None):
        self.passed = False
        self.errors.append({"message": message, "details": details or {}})

    def add_warning(self, message: str, details: Optional[Dict] = None):
        self.warnings.append({"message": message, "details": details or {}})

    def add_info(self, message: str, details: Optional[Dict] = None):
        self.info.append({"message": message, "details": details or {}})

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_type": self.check_type,
            "table_name": self.table_name,
            "passed": self.passed,
            "errors": self.errors,
            "warnings": self.warnings,
            "info": self.info,
            "metrics": self.metrics
        }


# ---------------------------------------------------------------------------
# CONFORMANCE CHECKS - A. Structure Checks
# ---------------------------------------------------------------------------

# A.1. Whether table is present
def check_table_exists(
    table_path: Union[str, Path],
    table_name: str,
    filetype: str = 'parquet'
) -> DQAConformanceResult:
    """
    Check if a table file exists at the specified path.

    Parameters
    ----------
    table_path : str or Path
        Directory containing the table files
    table_name : str
        Name of the table to check
    filetype : str
        File extension (parquet, csv, etc.)

    Returns
    -------
    DQAConformanceResult
        Result object with check status
    """
    result = DQAConformanceResult("table_exists", table_name)

    table_path = Path(table_path)
    expected_file = table_path / f"{table_name}.{filetype}"

    if expected_file.exists():
        result.add_info(f"Table file found: {expected_file}")
        result.metrics["file_path"] = str(expected_file)
        result.metrics["file_size_mb"] = expected_file.stat().st_size / (1024 * 1024)
    else:
        result.add_error(
            f"Table file not found: {expected_file}",
            {"expected_path": str(expected_file)}
        )

    return result


# A.1b. Table presence check (DataFrame-level)
def check_table_presence_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    table_name: str
) -> DQAConformanceResult:
    """
    Check that a loaded DataFrame has rows and columns using Polars.

    Parameters
    ----------
    df : pl.DataFrame or pl.LazyFrame
        The data to validate
    table_name : str
        Name of the table
    """
    result = DQAConformanceResult("table_presence", table_name)

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        column_names = lf.collect_schema().names()
        column_count = len(column_names)
        row_count = lf.select(pl.len()).collect().item()

        result.metrics["row_count"] = row_count
        result.metrics["column_count"] = column_count

        if column_count == 0:
            result.add_error(
                f"Table '{table_name}' has no columns",
                {"column_count": column_count},
            )
        if row_count == 0:
            result.add_error(
                f"Table '{table_name}' has 0 rows",
                {"row_count": row_count},
            )
        if result.passed:
            result.add_info(
                f"Table '{table_name}' present with {row_count} rows and {column_count} columns"
            )
    except Exception as e:
        _logger.error("Check 'table_presence' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking table presence: {str(e)}")

    return result


def check_table_presence_duckdb(
    df: pd.DataFrame,
    table_name: str
) -> DQAConformanceResult:
    """
    Check that a loaded DataFrame has rows and columns using DuckDB/pandas.

    Parameters
    ----------
    df : pd.DataFrame
        The data to validate
    table_name : str
        Name of the table
    """
    result = DQAConformanceResult("table_presence", table_name)

    try:
        row_count = len(df)
        column_count = len(df.columns)

        result.metrics["row_count"] = row_count
        result.metrics["column_count"] = column_count

        if column_count == 0:
            result.add_error(
                f"Table '{table_name}' has no columns",
                {"column_count": column_count},
            )
        if row_count == 0:
            result.add_error(
                f"Table '{table_name}' has 0 rows",
                {"row_count": row_count},
            )
        if result.passed:
            result.add_info(
                f"Table '{table_name}' present with {row_count} rows and {column_count} columns"
            )
    except Exception as e:
        _logger.error("Check 'table_presence' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking table presence: {str(e)}")

    return result


def check_table_presence(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    table_name: str
) -> DQAConformanceResult:
    """
    Check that a loaded DataFrame has rows and columns.

    Parameters
    ----------
    df : pd.DataFrame, pl.DataFrame, or pl.LazyFrame
        Data to validate (already loaded)
    table_name : str
        Name of the table
    """
    _logger.debug("check_table_presence: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_table_presence_polars(df, table_name)
    else:
        result = check_table_presence_duckdb(df, table_name)
    _logger.debug("check_table_presence: table '%s' — rows=%s, cols=%s",
                  table_name, result.metrics.get("row_count"), result.metrics.get("column_count"))
    return result


# A.2. Whether all required columns are present
def check_required_columns_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """
    Check if all required columns are present using Polars.

    Memory-efficient implementation using lazy evaluation.
    """
    result = DQAConformanceResult("required_columns", table_name)

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        actual_columns = set(lf.collect_schema().names())
        required_list = schema.get('required_columns', [])

        missing = set(required_list) - actual_columns

        result.metrics["total_required"] = len(required_list)
        result.metrics["total_present"] = len(required_list) - len(missing)
        result.metrics["total_missing"] = len(missing)

        for col_name in required_list:
            if col_name in missing:
                result.add_error(
                    f"Column '{col_name}': missing from data",
                    {"column": col_name}
                )
            else:
                result.add_info(
                    f"Column '{col_name}': present",
                    {"column": col_name}
                )

    except Exception as e:
        _logger.error("Check 'required_columns' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking columns: {str(e)}")

    return result


def check_required_columns_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if all required columns are present using DuckDB."""
    result = DQAConformanceResult("required_columns", table_name)

    try:
        actual_columns = set(df.columns)
        required_list = schema.get('required_columns', [])

        missing = set(required_list) - actual_columns

        result.metrics["total_required"] = len(required_list)
        result.metrics["total_present"] = len(required_list) - len(missing)
        result.metrics["total_missing"] = len(missing)

        for col_name in required_list:
            if col_name in missing:
                result.add_error(
                    f"Column '{col_name}': missing from data",
                    {"column": col_name}
                )
            else:
                result.add_info(
                    f"Column '{col_name}': present",
                    {"column": col_name}
                )

    except Exception as e:
        _logger.error("Check 'required_columns' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking columns: {str(e)}")

    return result


def check_required_columns(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """
    Check if all required columns are present.

    Parameters
    ----------
    df : pd.DataFrame, pl.DataFrame, or pl.LazyFrame
        Data to validate (already loaded)
    schema : dict
        Table schema containing required_columns
    table_name : str
        Name of the table
    """
    _logger.debug("check_required_columns: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_required_columns_polars(df, schema, table_name)
    else:
        result = check_required_columns_duckdb(df, schema, table_name)
    if result.metrics.get("total_missing", 0) > 0:
        _logger.info("check_required_columns: table '%s' missing %d of %d required columns",
                     table_name, result.metrics["total_missing"], result.metrics.get("total_required", 0))
    _logger.debug("check_required_columns: table '%s' — required=%s, present=%s, missing=%s",
                  table_name, result.metrics.get("total_required"),
                  result.metrics.get("total_present"), result.metrics.get("total_missing"))
    return result


# ---------------------------------------------------------------------------
# CONFORMANCE CHECKS - B. Value Checks
# ---------------------------------------------------------------------------

# B.1. Data type validation
def check_column_dtypes_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if columns have correct data types using Polars."""
    result = DQAConformanceResult("column_dtypes", table_name)

    # mCIDE type to Polars type mapping
    type_mapping = {
        'VARCHAR': [pl.Utf8, pl.String, pl.Categorical],
        'DATETIME': [pl.Datetime],
        'DATE': [pl.Date],
        'INTEGER': [pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64],
        'INT': [pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64],
        'FLOAT': [pl.Float32, pl.Float64],
        'DOUBLE': [pl.Float32, pl.Float64],
    }

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        schema_dict = lf.collect_schema()

        dtype_errors = []
        dtype_warnings = []

        for col_spec in schema.get('columns', []):
            col_name = col_spec['name']
            expected_type = col_spec.get('data_type')

            if not expected_type or col_name not in schema_dict.names():
                continue

            actual_dtype = schema_dict[col_name]
            expected_pl_types = type_mapping.get(expected_type, [])

            type_matches = any(
                isinstance(actual_dtype, t) or actual_dtype == t
                for t in expected_pl_types
            )

            if not type_matches:
                dtype_str = str(actual_dtype)
                # Check common patterns
                if expected_type in ('DATETIME',) and 'Datetime' in dtype_str:
                    continue
                if expected_type in ('VARCHAR',) and ('Utf8' in dtype_str or 'String' in dtype_str):
                    continue

                # Skip all-null columns — type inference is unreliable with no data
                null_check = lf.select(pl.col(col_name).is_null().all()).collect()
                if null_check.item():
                    continue

                castable = _check_castable_polars(lf, col_name, expected_type)

                if castable:
                    dtype_warnings.append({
                        "column": col_name,
                        "expected": expected_type,
                        "actual": str(actual_dtype),
                        "castable": True
                    })
                else:
                    dtype_errors.append({
                        "column": col_name,
                        "expected": expected_type,
                        "actual": str(actual_dtype),
                        "castable": False
                    })

        result.metrics["columns_checked"] = len(schema.get('columns', []))
        result.metrics["dtype_errors"] = len(dtype_errors)
        result.metrics["dtype_warnings"] = len(dtype_warnings)

        issue_cols = {err['column'] for err in dtype_errors} | {warn['column'] for warn in dtype_warnings}

        for err in dtype_errors:
            result.add_error(
                f"Column '{err['column']}' has type {err['actual']}, cannot cast to {err['expected']}",
                err
            )

        for warn in dtype_warnings:
            result.add_warning(
                f"Column '{warn['column']}' has type {warn['actual']}, can be cast to {warn['expected']}",
                warn
            )

        for col_spec in schema.get('columns', []):
            col_name = col_spec['name']
            expected_type = col_spec.get('data_type')
            if not expected_type:
                continue
            if col_name not in schema_dict.names():
                result.add_info(
                    f"Column '{col_name}': not present in data (dtype check skipped)",
                    {"column": col_name, "expected": expected_type}
                )
            elif col_name not in issue_cols:
                result.add_info(
                    f"Column '{col_name}': dtype matches schema ({expected_type})",
                    {"column": col_name, "expected": expected_type}
                )

    except Exception as e:
        _logger.error("Check 'column_dtypes' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking dtypes: {str(e)}")

    return result


def _check_castable_polars(lf: 'pl.LazyFrame', col_name: str, target_type: str) -> bool:
    """Check if a column can be cast to the target type using Polars."""
    try:
        if target_type in ('INTEGER', 'INT'):
            sample = lf.select(pl.col(col_name).drop_nulls().head(100)).collect()
            if len(sample) > 0:
                sample.select(pl.col(col_name).cast(pl.Int64))
            return True
        elif target_type in ('FLOAT', 'DOUBLE'):
            sample = lf.select(pl.col(col_name).drop_nulls().head(100)).collect()
            if len(sample) > 0:
                sample.select(pl.col(col_name).cast(pl.Float64))
            return True
        elif target_type == 'DATETIME':
            sample = lf.select(pl.col(col_name).drop_nulls().head(100)).collect()
            if len(sample) > 0:
                sample.select(pl.col(col_name).str.to_datetime())
            return True
        elif target_type == 'VARCHAR':
            return True
        return False
    except Exception:
        return False


def check_column_dtypes_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if columns have correct data types using DuckDB."""
    result = DQAConformanceResult("column_dtypes", table_name)

    type_mapping = {
        'VARCHAR': ['VARCHAR', 'TEXT', 'STRING'],
        'DATETIME': ['TIMESTAMP', 'TIMESTAMP WITH TIME ZONE'],
        'DATE': ['DATE'],
        'INTEGER': ['INTEGER', 'BIGINT', 'SMALLINT', 'TINYINT', 'INT'],
        'INT': ['INTEGER', 'BIGINT', 'SMALLINT', 'TINYINT', 'INT'],
        'FLOAT': ['FLOAT', 'DOUBLE', 'REAL', 'DECIMAL'],
        'DOUBLE': ['FLOAT', 'DOUBLE', 'REAL', 'DECIMAL'],
    }

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        describe_result = con.execute("DESCRIBE df").fetchall()
        actual_types = {row[0]: row[1].upper() for row in describe_result}

        dtype_errors = []
        dtype_warnings = []

        for col_spec in schema.get('columns', []):
            col_name = col_spec['name']
            expected_type = col_spec.get('data_type')

            if not expected_type or col_name not in actual_types:
                continue

            actual_dtype = actual_types[col_name]
            expected_duckdb_types = type_mapping.get(expected_type, [])

            type_matches = any(
                expected_t in actual_dtype
                for expected_t in expected_duckdb_types
            )

            if not type_matches:
                # When all values are NULL *and* the pandas dtype is object,
                # DuckDB infers an arbitrary type (e.g. INTEGER) because it
                # has no data to work with.  Skip only this ambiguous case.
                # Columns with a concrete pandas dtype (Int32, datetime64, …)
                # have a reliable inferred type even when all-null.
                if col_name in df.columns and df[col_name].isna().all() and df[col_name].dtype == object:
                    continue

                castable = _check_castable_duckdb(con, col_name, expected_type)

                if castable:
                    dtype_warnings.append({
                        "column": col_name,
                        "expected": expected_type,
                        "actual": actual_dtype,
                        "castable": True
                    })
                else:
                    dtype_errors.append({
                        "column": col_name,
                        "expected": expected_type,
                        "actual": actual_dtype,
                        "castable": False
                    })

        result.metrics["columns_checked"] = len(schema.get('columns', []))
        result.metrics["dtype_errors"] = len(dtype_errors)
        result.metrics["dtype_warnings"] = len(dtype_warnings)

        issue_cols = {err['column'] for err in dtype_errors} | {warn['column'] for warn in dtype_warnings}

        for err in dtype_errors:
            result.add_error(
                f"Column '{err['column']}' has type {err['actual']}, cannot cast to {err['expected']}",
                err
            )

        for warn in dtype_warnings:
            result.add_warning(
                f"Column '{warn['column']}' has type {warn['actual']}, can be cast to {warn['expected']}",
                warn
            )

        for col_spec in schema.get('columns', []):
            col_name = col_spec['name']
            expected_type = col_spec.get('data_type')
            if not expected_type:
                continue
            if col_name not in actual_types:
                result.add_info(
                    f"Column '{col_name}': not present in data (dtype check skipped)",
                    {"column": col_name, "expected": expected_type}
                )
            elif col_name not in issue_cols:
                result.add_info(
                    f"Column '{col_name}': dtype matches schema ({expected_type})",
                    {"column": col_name, "expected": expected_type}
                )

        con.close()

    except Exception as e:
        _logger.error("Check 'column_dtypes' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking dtypes: {str(e)}")

    return result


def _check_castable_duckdb(con, col_name: str, target_type: str) -> bool:
    """Check if a column can be cast to the target type using DuckDB."""
    try:
        if target_type in ('INTEGER', 'INT'):
            con.execute(f'SELECT TRY_CAST("{col_name}" AS BIGINT) FROM df LIMIT 100')
        elif target_type in ('FLOAT', 'DOUBLE'):
            con.execute(f'SELECT TRY_CAST("{col_name}" AS DOUBLE) FROM df LIMIT 100')
        elif target_type == 'DATETIME':
            con.execute(f'SELECT TRY_CAST("{col_name}" AS TIMESTAMP) FROM df LIMIT 100')
        elif target_type == 'VARCHAR':
            con.execute(f'SELECT CAST("{col_name}" AS VARCHAR) FROM df LIMIT 100')
        return True
    except Exception:
        return False


def check_column_dtypes(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """
    Check if columns have correct data types.

    Parameters
    ----------
    df : pd.DataFrame, pl.DataFrame, or pl.LazyFrame
        Data to validate (already loaded)
    schema : dict
        Table schema
    table_name : str
        Name of the table
    """
    _logger.debug("check_column_dtypes: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_column_dtypes_polars(df, schema, table_name)
    else:
        result = check_column_dtypes_duckdb(df, schema, table_name)
    _logger.debug("check_column_dtypes: table '%s' — checked=%s, errors=%s, warnings=%s",
                  table_name, result.metrics.get("columns_checked"),
                  result.metrics.get("dtype_errors"), result.metrics.get("dtype_warnings"))
    return result


# B.2. Datetime format validation
def check_datetime_format_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str,
    expected_tz: str = 'UTC'
) -> DQAConformanceResult:
    """Validate datetime columns are in correct format using Polars."""
    result = DQAConformanceResult("datetime_format", table_name)

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        schema_dict = lf.collect_schema()

        all_datetime_columns = [
            col['name'] for col in schema.get('columns', [])
            if col.get('data_type') in ('DATETIME', 'DATE')
        ]
        data_col_names = set(schema_dict.names())

        result.metrics["datetime_columns_checked"] = len(all_datetime_columns)
        columns_with_messages = set()

        for col in all_datetime_columns:
            if col not in data_col_names:
                result.add_info(
                    f"Column '{col}': not present in data (datetime check skipped)",
                    {"column": col}
                )
                columns_with_messages.add(col)
                continue

            col_dtype = schema_dict[col]
            dtype_str = str(col_dtype)

            if 'Datetime' not in dtype_str and 'Date' not in dtype_str:
                result.add_warning(
                    f"Column '{col}' should be DATETIME but is {col_dtype}",
                    {"column": col, "actual_type": str(col_dtype)}
                )
                columns_with_messages.add(col)
                continue

            if expected_tz and 'Datetime' in dtype_str:
                if expected_tz not in dtype_str and 'time_zone' not in dtype_str:
                    result.add_info(
                        f"Column '{col}' may be timezone-naive, expected {expected_tz}",
                        {"column": col, "expected_tz": expected_tz}
                    )
                    columns_with_messages.add(col)

        for col in all_datetime_columns:
            if col not in columns_with_messages:
                result.add_info(
                    f"Column '{col}': datetime format valid",
                    {"column": col}
                )

    except Exception as e:
        _logger.error("Check 'datetime_format' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking datetime format: {str(e)}")

    return result


def check_datetime_format_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str,
    expected_tz: str = 'UTC'
) -> DQAConformanceResult:
    """Validate datetime columns are in correct format using DuckDB."""
    result = DQAConformanceResult("datetime_format", table_name)

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        describe_result = con.execute("DESCRIBE df").fetchall()
        actual_types = {row[0]: row[1].upper() for row in describe_result}

        all_datetime_columns = [
            col['name'] for col in schema.get('columns', [])
            if col.get('data_type') in ('DATETIME', 'DATE')
        ]

        result.metrics["datetime_columns_checked"] = len(all_datetime_columns)
        columns_with_messages = set()

        for col in all_datetime_columns:
            if col not in actual_types:
                result.add_info(
                    f"Column '{col}': not present in data (datetime check skipped)",
                    {"column": col}
                )
                columns_with_messages.add(col)
                continue

            col_dtype = actual_types[col]

            if 'TIMESTAMP' not in col_dtype and 'DATE' not in col_dtype:
                result.add_warning(
                    f"Column '{col}' should be DATETIME but is {col_dtype}",
                    {"column": col, "actual_type": col_dtype}
                )
                columns_with_messages.add(col)

        for col in all_datetime_columns:
            if col not in columns_with_messages:
                result.add_info(
                    f"Column '{col}': datetime format valid",
                    {"column": col}
                )

        con.close()

    except Exception as e:
        _logger.error("Check 'datetime_format' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking datetime format: {str(e)}")

    return result


def check_datetime_format(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str,
    expected_tz: str = 'UTC'
) -> DQAConformanceResult:
    """Validate datetime columns are in correct format."""
    _logger.debug("check_datetime_format: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_datetime_format_polars(df, schema, table_name, expected_tz)
    else:
        result = check_datetime_format_duckdb(df, schema, table_name, expected_tz)
    _logger.debug("check_datetime_format: table '%s' — columns_checked=%s",
                  table_name, result.metrics.get("datetime_columns_checked"))
    return result


# B.3. Lab reference units validation
def check_lab_reference_units_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str = 'labs'
) -> DQAConformanceResult:
    """Check if lab reference units match schema definitions using Polars."""
    result = DQAConformanceResult("lab_reference_units", table_name)

    lab_units = schema.get('lab_reference_units', {})
    if not lab_units:
        result.add_info("No lab reference units defined in schema")
        return result

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        if 'lab_category' not in col_names or 'reference_unit' not in col_names:
            result.add_error("Missing required columns: lab_category and/or reference_unit")
            return result

        unit_counts = (
            lf
            .group_by(['lab_category', 'reference_unit'])
            .agg(pl.len().alias('count'))
            .collect(streaming=True)
        )

        # Build lookup: lab_category -> list of (reference_unit, count)
        actual_units: Dict[str, list] = {}
        total_count = 0
        for row in unit_counts.iter_rows(named=True):
            lab_cat = row['lab_category']
            ref_unit = row['reference_unit']
            count = row['count']
            total_count += count
            actual_units.setdefault(lab_cat, []).append((ref_unit, count))

        result.metrics["total_records"] = total_count
        invalid_count = 0

        # Emit one message per lab_reference_units entry
        for lab_cat, expected_units in lab_units.items():
            pairs = actual_units.get(lab_cat)
            if pairs is None:
                result.add_info(
                    f"Lab category '{lab_cat}': not present in data",
                    {"column": lab_cat}
                )
                continue

            expected_lower = [str(u).lower().strip() for u in expected_units]
            no_units = '(no units)' in expected_lower
            bad = []
            for ref_unit, count in pairs:
                ref_unit_lower = str(ref_unit).lower().strip() if ref_unit else ''
                if no_units and not ref_unit_lower:
                    continue
                if ref_unit_lower not in expected_lower and ref_unit not in expected_units:
                    bad.append({"reference_unit": ref_unit, "expected_units": expected_units, "count": count})

            if bad:
                invalid_count += 1
                bad.sort(key=lambda x: x['count'], reverse=True)
                result.add_warning(
                    f"Lab category '{lab_cat}': non-standard units found",
                    {"column": lab_cat, "top_invalid_units": bad[:10]}
                )
            else:
                result.add_info(
                    f"Lab category '{lab_cat}': reference units match schema",
                    {"column": lab_cat}
                )

        result.metrics["invalid_unit_categories"] = invalid_count
        gc.collect()

    except Exception as e:
        _logger.error("Check 'lab_reference_units' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking lab reference units: {str(e)}")

    return result


def check_lab_reference_units_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str = 'labs'
) -> DQAConformanceResult:
    """Check if lab reference units match schema definitions using DuckDB."""
    result = DQAConformanceResult("lab_reference_units", table_name)

    lab_units = schema.get('lab_reference_units', {})
    if not lab_units:
        result.add_info("No lab reference units defined in schema")
        return result

    try:
        con = duckdb.connect(':memory:')
        con.register('labs_df', df)

        if 'lab_category' not in df.columns or 'reference_unit' not in df.columns:
            result.add_error("Missing required columns: lab_category and/or reference_unit")
            con.close()
            return result

        unit_counts = con.execute("""
            SELECT lab_category, reference_unit, COUNT(*) as count
            FROM labs_df
            GROUP BY lab_category, reference_unit
        """).fetchall()

        # Build lookup: lab_category -> list of (reference_unit, count)
        actual_units: Dict[str, list] = {}
        total_count = 0
        for row in unit_counts:
            lab_cat, ref_unit, count = row
            total_count += int(count)
            actual_units.setdefault(lab_cat, []).append((ref_unit, int(count)))

        result.metrics["total_records"] = total_count
        invalid_count = 0

        # Emit one message per lab_reference_units entry
        for lab_cat, expected_units in lab_units.items():
            pairs = actual_units.get(lab_cat)
            if pairs is None:
                result.add_info(
                    f"Lab category '{lab_cat}': not present in data",
                    {"column": lab_cat}
                )
                continue

            expected_lower = [str(u).lower().strip() for u in expected_units]
            no_units = '(no units)' in expected_lower
            bad = []
            for ref_unit, count in pairs:
                ref_unit_lower = str(ref_unit).lower().strip() if ref_unit else ''
                if no_units and not ref_unit_lower:
                    continue
                if ref_unit_lower not in expected_lower and ref_unit not in expected_units:
                    bad.append({"reference_unit": ref_unit, "expected_units": expected_units, "count": count})

            if bad:
                invalid_count += 1
                bad.sort(key=lambda x: x['count'], reverse=True)
                result.add_warning(
                    f"Lab category '{lab_cat}': non-standard units found",
                    {"column": lab_cat, "top_invalid_units": bad[:10]}
                )
            else:
                result.add_info(
                    f"Lab category '{lab_cat}': reference units match schema",
                    {"column": lab_cat}
                )

        result.metrics["invalid_unit_categories"] = invalid_count
        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'lab_reference_units' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking lab reference units: {str(e)}")

    return result


def check_lab_reference_units(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str = 'labs'
) -> DQAConformanceResult:
    """Check if lab reference units match schema definitions."""
    _logger.debug("check_lab_reference_units: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_lab_reference_units_polars(df, schema, table_name)
    else:
        result = check_lab_reference_units_duckdb(df, schema, table_name)
    _logger.debug("check_lab_reference_units: table '%s' — valid=%s, invalid_categories=%s",
                  table_name, result.metrics.get("valid_units"),
                  result.metrics.get("invalid_unit_categories"))
    return result


# B.4. Categorical values validation
def check_categorical_values_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if categorical values match mCIDE permissible values using Polars."""
    result = DQAConformanceResult("categorical_values", table_name)

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        category_columns = schema.get('category_columns') or []
        invalid_values_by_col = {}
        columns_checked = []
        columns_missing = set()

        for col_spec in schema.get('columns', []):
            col_name = col_spec['name']
            permissible = col_spec.get('permissible_values', [])

            if not permissible:
                continue

            if col_name not in category_columns:
                continue

            columns_checked.append(col_name)

            if col_name not in col_names:
                columns_missing.add(col_name)
                continue

            unique_vals = (
                lf
                .select(pl.col(col_name))
                .drop_nulls()
                .group_by(col_name)
                .agg(pl.len().alias('count'))
                .collect(streaming=True)
            )

            permissible_lower = {str(v).lower().strip() for v in permissible}

            invalid_for_col = []
            for row in unique_vals.iter_rows(named=True):
                val = row[col_name]
                count = row['count']

                val_str = str(val).lower().strip() if val is not None else ''
                if val_str not in permissible_lower and val not in permissible:
                    invalid_for_col.append({
                        "value": val,
                        "count": count
                    })

            if invalid_for_col:
                invalid_for_col.sort(key=lambda x: x['count'], reverse=True)
                invalid_values_by_col[col_name] = {
                    "invalid_values": invalid_for_col[:20],
                    "total_invalid_unique": len(invalid_for_col),
                    "permissible_values": permissible
                }

        result.metrics["category_columns_checked"] = len(columns_checked)
        result.metrics["columns_with_invalid_values"] = len(invalid_values_by_col)

        for col_name in columns_checked:
            if col_name in columns_missing:
                result.add_info(
                    f"Column '{col_name}': not present in data (categorical check skipped)",
                    {"column": col_name}
                )
            elif col_name in invalid_values_by_col:
                details = invalid_values_by_col[col_name]
                result.add_warning(
                    f"{details['total_invalid_unique']} invalid categorical values",
                    {
                        "column": col_name,
                        "top_invalid": details['invalid_values'][:10],
                        "permissible_values": details['permissible_values']
                    }
                )
            else:
                result.add_info(
                    f"Column '{col_name}': all values match mCIDE permissible values",
                    {"column": col_name}
                )

        gc.collect()

    except Exception as e:
        _logger.error("Check 'categorical_values' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking categorical values: {str(e)}")

    return result


def check_categorical_values_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if categorical values match mCIDE permissible values using DuckDB."""
    result = DQAConformanceResult("categorical_values", table_name)

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        category_columns = schema.get('category_columns') or []
        invalid_values_by_col = {}
        columns_checked = []
        columns_missing = set()

        for col_spec in schema.get('columns', []):
            col_name = col_spec['name']
            permissible = col_spec.get('permissible_values', [])

            if not permissible:
                continue

            if col_name not in category_columns:
                continue

            columns_checked.append(col_name)

            if col_name not in df.columns:
                columns_missing.add(col_name)
                continue

            unique_vals = con.execute(f"""
                SELECT "{col_name}", COUNT(*) as count
                FROM df
                WHERE "{col_name}" IS NOT NULL
                GROUP BY "{col_name}"
            """).fetchdf()

            permissible_lower = {str(v).lower().strip() for v in permissible}

            invalid_for_col = []
            for _, row in unique_vals.iterrows():
                val = row[col_name]
                count = row['count']

                val_str = str(val).lower().strip() if val is not None else ''
                if val_str not in permissible_lower and val not in permissible:
                    invalid_for_col.append({
                        "value": val,
                        "count": int(count)
                    })

            if invalid_for_col:
                invalid_for_col.sort(key=lambda x: x['count'], reverse=True)
                invalid_values_by_col[col_name] = {
                    "invalid_values": invalid_for_col[:20],
                    "total_invalid_unique": len(invalid_for_col),
                    "permissible_values": permissible
                }

        result.metrics["category_columns_checked"] = len(columns_checked)
        result.metrics["columns_with_invalid_values"] = len(invalid_values_by_col)

        for col_name in columns_checked:
            if col_name in columns_missing:
                result.add_info(
                    f"Column '{col_name}': not present in data (categorical check skipped)",
                    {"column": col_name}
                )
            elif col_name in invalid_values_by_col:
                details = invalid_values_by_col[col_name]
                result.add_warning(
                    f"{details['total_invalid_unique']} invalid categorical values",
                    {
                        "column": col_name,
                        "top_invalid": details['invalid_values'][:10],
                        "permissible_values": details['permissible_values']
                    }
                )
            else:
                result.add_info(
                    f"Column '{col_name}': all values match mCIDE permissible values",
                    {"column": col_name}
                )

        con.close()

    except Exception as e:
        _logger.error("Check 'categorical_values' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking categorical values: {str(e)}")

    return result


def check_categorical_values(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if categorical values match mCIDE permissible values."""
    _logger.debug("check_categorical_values: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_categorical_values_polars(df, schema, table_name)
    else:
        result = check_categorical_values_duckdb(df, schema, table_name)
    _logger.debug("check_categorical_values: table '%s' — columns_checked=%s, columns_with_invalid=%s",
                  table_name, result.metrics.get("category_columns_checked"),
                  result.metrics.get("columns_with_invalid_values"))
    return result


# B.5. Category-to-group mapping validation

def check_category_group_mapping_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if category-to-group mappings match schema definitions using Polars."""
    result = DQAConformanceResult("category_group_mapping", table_name)

    # Discover all *_category_to_group_mapping keys in the schema
    mapping_keys = [k for k in schema if k.endswith('_category_to_group_mapping')]
    if not mapping_keys:
        result.add_info("No category-to-group mappings defined in schema")
        return result

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        for mapping_key in mapping_keys:
            mapping = schema[mapping_key]
            if not mapping:
                continue

            # Derive column names: e.g. "med_category_to_group_mapping" -> category_col="med_category", group_col="med_group"
            category_col = mapping_key.replace('_to_group_mapping', '')
            group_col = category_col.replace('_category', '_group')

            if category_col not in col_names or group_col not in col_names:
                # Emit one info per mapping entry so the count stays deterministic
                for cat_val in mapping:
                    result.add_info(
                        f"Category '{cat_val}': columns not in data (mapping check skipped)",
                        {"column": cat_val, "category_column": category_col, "group_column": group_col}
                    )
                continue

            # Group by (category_col, group_col) where both non-null
            pair_counts = (
                lf
                .filter(pl.col(category_col).is_not_null() & pl.col(group_col).is_not_null())
                .group_by([category_col, group_col])
                .agg(pl.len().alias('count'))
                .collect(streaming=True)
            )

            # Build lookup: category_val -> list of (group_val, count)
            actual_groups: Dict[str, list] = {}
            total_count = 0
            for row in pair_counts.iter_rows(named=True):
                cat_val = row[category_col]
                grp_val = row[group_col]
                count = row['count']
                total_count += count
                actual_groups.setdefault(cat_val, []).append((grp_val, count))

            result.metrics[f"{mapping_key}_total_records"] = total_count
            mismatch_count = 0

            # Emit one message per mapping entry
            for cat_val, expected_group in mapping.items():
                pairs = actual_groups.get(cat_val)
                if pairs is None:
                    result.add_info(
                        f"Category '{cat_val}': not present in data",
                        {"column": cat_val, "category_column": category_col, "group_column": group_col}
                    )
                    continue

                bad = []
                for grp_val, count in pairs:
                    grp_lower = str(grp_val).lower().strip() if grp_val else ''
                    exp_lower = str(expected_group).lower().strip()
                    if grp_lower != exp_lower and grp_val != expected_group:
                        bad.append({"actual_group": grp_val, "expected_group": expected_group, "count": count})

                if bad:
                    mismatch_count += 1
                    result.add_warning(
                        f"Category '{cat_val}': group mismatch (expected '{expected_group}')",
                        {"column": cat_val, "category_column": category_col,
                         "group_column": group_col, "mismatched_pairs": bad}
                    )
                else:
                    result.add_info(
                        f"Category '{cat_val}': group mapping correct",
                        {"column": cat_val, "category_column": category_col, "group_column": group_col}
                    )

            result.metrics[f"{mapping_key}_mismatch_count"] = mismatch_count

        gc.collect()

    except Exception as e:
        _logger.error("Check 'category_group_mapping' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking category-group mapping: {str(e)}")

    return result


def check_category_group_mapping_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if category-to-group mappings match schema definitions using DuckDB."""
    result = DQAConformanceResult("category_group_mapping", table_name)

    # Discover all *_category_to_group_mapping keys in the schema
    mapping_keys = [k for k in schema if k.endswith('_category_to_group_mapping')]
    if not mapping_keys:
        result.add_info("No category-to-group mappings defined in schema")
        return result

    try:
        con = duckdb.connect(':memory:')
        con.register('mapping_df', df)
        col_names = list(df.columns)

        for mapping_key in mapping_keys:
            mapping = schema[mapping_key]
            if not mapping:
                continue

            # Derive column names
            category_col = mapping_key.replace('_to_group_mapping', '')
            group_col = category_col.replace('_category', '_group')

            if category_col not in col_names or group_col not in col_names:
                for cat_val in mapping:
                    result.add_info(
                        f"Category '{cat_val}': columns not in data (mapping check skipped)",
                        {"column": cat_val, "category_column": category_col, "group_column": group_col}
                    )
                continue

            # Group by (category_col, group_col) where both non-null
            pair_counts = con.execute(f"""
                SELECT "{category_col}", "{group_col}", COUNT(*) as count
                FROM mapping_df
                WHERE "{category_col}" IS NOT NULL AND "{group_col}" IS NOT NULL
                GROUP BY "{category_col}", "{group_col}"
            """).fetchall()

            # Build lookup: category_val -> list of (group_val, count)
            actual_groups: Dict[str, list] = {}
            total_count = 0
            for row in pair_counts:
                cat_val, grp_val, count = row
                total_count += int(count)
                actual_groups.setdefault(cat_val, []).append((grp_val, int(count)))

            result.metrics[f"{mapping_key}_total_records"] = total_count
            mismatch_count = 0

            # Emit one message per mapping entry
            for cat_val, expected_group in mapping.items():
                pairs = actual_groups.get(cat_val)
                if pairs is None:
                    result.add_info(
                        f"Category '{cat_val}': not present in data",
                        {"column": cat_val, "category_column": category_col, "group_column": group_col}
                    )
                    continue

                bad = []
                for grp_val, count in pairs:
                    grp_lower = str(grp_val).lower().strip() if grp_val else ''
                    exp_lower = str(expected_group).lower().strip()
                    if grp_lower != exp_lower and grp_val != expected_group:
                        bad.append({"actual_group": grp_val, "expected_group": expected_group, "count": count})

                if bad:
                    mismatch_count += 1
                    result.add_warning(
                        f"Category '{cat_val}': group mismatch (expected '{expected_group}')",
                        {"column": cat_val, "category_column": category_col,
                         "group_column": group_col, "mismatched_pairs": bad}
                    )
                else:
                    result.add_info(
                        f"Category '{cat_val}': group mapping correct",
                        {"column": cat_val, "category_column": category_col, "group_column": group_col}
                    )

            result.metrics[f"{mapping_key}_mismatch_count"] = mismatch_count

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'category_group_mapping' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking category-group mapping: {str(e)}")

    return result


def check_category_group_mapping(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQAConformanceResult:
    """Check if category-to-group mappings match schema definitions."""
    _logger.debug("check_category_group_mapping: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_category_group_mapping_polars(df, schema, table_name)
    else:
        result = check_category_group_mapping_duckdb(df, schema, table_name)
    _logger.debug("check_category_group_mapping: table '%s' — completed", table_name)
    return result


# ---------------------------------------------------------------------------
# COMPLETENESS CHECKS
# ---------------------------------------------------------------------------

# A.1. Missingness in required columns
def check_missingness_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str,
    error_threshold: float = 50.0,
    warning_threshold: float = 10.0
) -> DQACompletenessResult:
    """Check missingness in required columns using Polars."""
    result = DQACompletenessResult("missingness", table_name)

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        required_columns = schema.get('required_columns', [])
        required_not_in_df = [c for c in required_columns if c not in col_names]
        required_in_df = [c for c in required_columns if c in col_names]

        # Skip columns covered by conditional requirements (checked in K.2)
        conditions = _get_default_conditions(table_name)
        conditional_cols = {col for cond in conditions for col in cond.get('then_required', [])}
        required_in_df = [c for c in required_in_df if c not in conditional_cols]

        # Skip columns marked nullable in schema (e.g. death_dttm)
        nullable_cols = {col['name'] for col in schema.get('columns', []) if col.get('nullable')}
        required_in_df = [c for c in required_in_df if c not in nullable_cols]

        # Columns with allow_missing: severity capped at warning (never error)
        allow_missing_cols = {col['name'] for col in schema.get('columns', []) if col.get('allow_missing')}

        total_rows = lf.select(pl.len()).collect()[0, 0]

        if total_rows == 0:
            result.add_error("DataFrame is empty")
            return result

        null_exprs = [
            pl.col(c).is_null().sum().alias(f"{c}_null")
            for c in required_in_df
        ]

        null_counts = lf.select(null_exprs).collect(streaming=True)

        missingness_stats = []
        high_missingness = []

        for col in required_in_df:
            null_count = null_counts[0, f"{col}_null"]
            pct_missing = (null_count / total_rows) * 100

            missingness_stats.append({
                "column": col,
                "null_count": int(null_count),
                "total_rows": int(total_rows),
                "percent_missing": round(pct_missing, 2)
            })

            # For allow_missing columns, cap severity at warning
            if col in allow_missing_cols:
                if pct_missing >= warning_threshold:
                    high_missingness.append({
                        "column": col,
                        "percent_missing": round(pct_missing, 2),
                        "severity": "warning"
                    })
            elif pct_missing >= error_threshold:
                high_missingness.append({
                    "column": col,
                    "percent_missing": round(pct_missing, 2),
                    "severity": "error"
                })
            elif pct_missing >= warning_threshold:
                high_missingness.append({
                    "column": col,
                    "percent_missing": round(pct_missing, 2),
                    "severity": "warning"
                })

        missingness_stats.sort(key=lambda x: x['percent_missing'], reverse=True)

        result.metrics["total_rows"] = int(total_rows)
        result.metrics["required_columns_checked"] = len(required_in_df)
        result.metrics["missingness_stats"] = missingness_stats

        high_miss_cols = {item['column'] for item in high_missingness}

        for item in high_missingness:
            if item["severity"] == "error":
                result.add_error(
                    f"Column '{item['column']}' has {item['percent_missing']}% missing values",
                    item
                )
            else:
                result.add_warning(
                    f"Column '{item['column']}' has {item['percent_missing']}% missing values",
                    item
                )

        for stat in missingness_stats:
            if stat['column'] not in high_miss_cols:
                result.add_info(
                    f"Column '{stat['column']}': {stat['percent_missing']}% missing (below thresholds)",
                    {"column": stat['column'],
                     "percent_missing": stat['percent_missing'],
                     "error_threshold": error_threshold,
                     "warning_threshold": warning_threshold},
                )

        for col in required_not_in_df:
            if col not in conditional_cols:
                result.add_info(
                    f"Column '{col}': not present in data (missingness check skipped)",
                    {"column": col},
                )

        gc.collect()

    except Exception as e:
        _logger.error("Check 'missingness' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking missingness: {str(e)}")

    return result


def check_missingness_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str,
    error_threshold: float = 50.0,
    warning_threshold: float = 10.0
) -> DQACompletenessResult:
    """Check missingness in required columns using DuckDB."""
    result = DQACompletenessResult("missingness", table_name)

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        required_columns = schema.get('required_columns', [])
        required_not_in_df = [c for c in required_columns if c not in df.columns]
        required_in_df = [c for c in required_columns if c in df.columns]

        # Skip columns covered by conditional requirements (checked in K.2)
        conditions = _get_default_conditions(table_name)
        conditional_cols = {col for cond in conditions for col in cond.get('then_required', [])}
        required_in_df = [c for c in required_in_df if c not in conditional_cols]

        # Skip columns marked nullable in schema (e.g. death_dttm)
        nullable_cols = {col['name'] for col in schema.get('columns', []) if col.get('nullable')}
        required_in_df = [c for c in required_in_df if c not in nullable_cols]

        # Columns with allow_missing: severity capped at warning (never error)
        allow_missing_cols = {col['name'] for col in schema.get('columns', []) if col.get('allow_missing')}

        total_rows = con.execute("SELECT COUNT(*) FROM df").fetchone()[0]

        if total_rows == 0:
            result.add_error("DataFrame is empty")
            con.close()
            return result

        # Build a single query for all null counts (efficient single scan)
        null_count_exprs = [f'COUNT(*) - COUNT("{col}") as "{col}_null"' for col in required_in_df]
        if null_count_exprs:
            null_query = f"SELECT {', '.join(null_count_exprs)} FROM df"
            null_counts = con.execute(null_query).fetchone()
        else:
            null_counts = []

        missingness_stats = []
        high_missingness = []

        for i, col in enumerate(required_in_df):
            null_count = null_counts[i] if null_counts else 0
            pct_missing = (null_count / total_rows) * 100

            missingness_stats.append({
                "column": col,
                "null_count": int(null_count),
                "total_rows": int(total_rows),
                "percent_missing": round(pct_missing, 2)
            })

            # For allow_missing columns, cap severity at warning
            if col in allow_missing_cols:
                if pct_missing >= warning_threshold:
                    high_missingness.append({
                        "column": col,
                        "percent_missing": round(pct_missing, 2),
                        "severity": "warning"
                    })
            elif pct_missing >= error_threshold:
                high_missingness.append({
                    "column": col,
                    "percent_missing": round(pct_missing, 2),
                    "severity": "error"
                })
            elif pct_missing >= warning_threshold:
                high_missingness.append({
                    "column": col,
                    "percent_missing": round(pct_missing, 2),
                    "severity": "warning"
                })

        missingness_stats.sort(key=lambda x: x['percent_missing'], reverse=True)

        result.metrics["total_rows"] = int(total_rows)
        result.metrics["required_columns_checked"] = len(required_in_df)
        result.metrics["missingness_stats"] = missingness_stats

        high_miss_cols = {item['column'] for item in high_missingness}

        for item in high_missingness:
            if item["severity"] == "error":
                result.add_error(
                    f"Column '{item['column']}' has {item['percent_missing']}% missing values",
                    item
                )
            else:
                result.add_warning(
                    f"Column '{item['column']}' has {item['percent_missing']}% missing values",
                    item
                )

        for stat in missingness_stats:
            if stat['column'] not in high_miss_cols:
                result.add_info(
                    f"Column '{stat['column']}': {stat['percent_missing']}% missing (below thresholds)",
                    {"column": stat['column'],
                     "percent_missing": stat['percent_missing'],
                     "error_threshold": error_threshold,
                     "warning_threshold": warning_threshold},
                )

        for col in required_not_in_df:
            if col not in conditional_cols:
                result.add_info(
                    f"Column '{col}': not present in data (missingness check skipped)",
                    {"column": col},
                )

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'missingness' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking missingness: {str(e)}")

    return result


def check_missingness(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str,
    error_threshold: float = 50.0,
    warning_threshold: float = 10.0
) -> DQACompletenessResult:
    """
    Check missingness in required columns.

    Parameters
    ----------
    df : pd.DataFrame, pl.DataFrame, or pl.LazyFrame
        Data to validate (already loaded)
    schema : dict
        Table schema containing required_columns
    table_name : str
        Name of the table
    error_threshold : float
        Percent missing above which an error is raised
    warning_threshold : float
        Percent missing above which a warning is raised

    Returns
    -------
    DQACompletenessResult
        Result containing missingness statistics
    """
    _logger.debug("check_missingness: starting for table '%s' (error_threshold=%.1f%%, warning_threshold=%.1f%%)",
                  table_name, error_threshold, warning_threshold)
    if _ACTIVE_BACKEND == 'polars':
        result = check_missingness_polars(df, schema, table_name, error_threshold, warning_threshold)
    else:
        result = check_missingness_duckdb(df, schema, table_name, error_threshold, warning_threshold)
    if result.errors:
        for err in result.errors:
            _logger.info("check_missingness: table '%s' — %s", table_name, err["message"])
    _logger.debug("check_missingness: table '%s' — columns_checked=%s",
                  table_name, result.metrics.get("required_columns_checked"))
    return result


# A.2. Conditional required fields
def _load_validation_rules() -> Dict[str, Any]:
    """Load the centralised validation rules YAML."""
    rules_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), 'schemas', 'validation_rules.yaml'
    )
    if not os.path.exists(rules_path):
        _logger.warning("Validation rules file not found: %s", rules_path)
        return {}
    with open(rules_path, 'r') as f:
        return yaml.safe_load(f) or {}


def _get_default_conditions(table_name: str) -> List[Dict[str, Any]]:
    """Load default conditional requirements for a table from validation_rules.yaml."""
    rules = _load_validation_rules()
    return rules.get('conditional_requirements', {}).get(table_name, [])


def check_conditional_requirements_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    conditions: Optional[List[Dict[str, Any]]] = None
) -> DQACompletenessResult:
    """Check conditional required fields using Polars."""
    result = DQACompletenessResult("conditional_requirements", table_name)

    if conditions is None:
        conditions = _get_default_conditions(table_name)

    if not conditions:
        result.add_info("No conditional requirements defined for this table")
        return result

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        for cond in conditions:
            when_col = cond['when_column']
            when_values = cond['when_value']
            then_required = cond['then_required']
            description = cond.get('description', '')

            if when_col not in col_names:
                continue

            if not isinstance(when_values, list):
                when_values = [when_values]

            filtered = lf.filter(
                pl.col(when_col).cast(pl.Utf8).str.to_lowercase().str.strip_chars().is_in(
                    [str(v).lower().strip() for v in when_values]
                )
            )

            # Optional compound condition: and_column / and_value
            and_col = cond.get('and_column')
            and_values = cond.get('and_value')
            if and_col and and_values is not None:
                if and_col not in col_names:
                    continue
                if not isinstance(and_values, list):
                    and_values = [and_values]
                filtered = filtered.filter(
                    pl.col(and_col).cast(pl.Utf8).str.to_lowercase().str.strip_chars().is_in(
                        [str(v).lower().strip() for v in and_values]
                    )
                )

            condition_label = f"{when_col} IN {when_values}"
            if and_col and and_values is not None:
                condition_label += f" AND {and_col} IN {and_values}"

            for req_col in then_required:
                if req_col not in col_names:
                    continue

                stats = filtered.select([
                    pl.len().alias('total'),
                    pl.col(req_col).is_null().sum().alias('null_count')
                ]).collect(streaming=True)

                total = stats[0, 'total']
                null_count = stats[0, 'null_count']

                if total > 0 and null_count > 0:
                    pct_missing = (null_count / total) * 100
                    result.add_warning(
                        f"Conditional requirement violated: {description}",
                        {
                            "condition": condition_label,
                            "required_column": req_col,
                            "rows_meeting_condition": int(total),
                            "rows_with_missing": int(null_count),
                            "percent_missing": round(pct_missing, 2)
                        }
                    )
                elif total > 0:
                    result.add_info(
                        f"Conditional requirement satisfied: {description} — {int(total):,}/{int(total):,} rows present (100%)",
                        {"column": req_col, "condition": condition_label,
                         "rows_meeting_condition": int(total),
                         "rows_present": int(total),
                         "percent_present": 100.0}
                    )

        gc.collect()

    except Exception as e:
        _logger.error("Check 'conditional_requirements' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking conditional requirements: {str(e)}")

    return result


def check_conditional_requirements_duckdb(
    df: pd.DataFrame,
    table_name: str,
    conditions: Optional[List[Dict[str, Any]]] = None
) -> DQACompletenessResult:
    """Check conditional required fields using DuckDB."""
    result = DQACompletenessResult("conditional_requirements", table_name)

    if conditions is None:
        conditions = _get_default_conditions(table_name)

    if not conditions:
        result.add_info("No conditional requirements defined for this table")
        return result

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        for cond in conditions:
            when_col = cond['when_column']
            when_values = cond['when_value']
            then_required = cond['then_required']
            description = cond.get('description', '')

            if when_col not in df.columns:
                continue

            if not isinstance(when_values, list):
                when_values = [when_values]

            # Optional compound condition: and_column / and_value
            and_col = cond.get('and_column')
            and_values = cond.get('and_value')
            and_clause = ""
            if and_col and and_values is not None:
                if and_col not in df.columns:
                    continue
                if not isinstance(and_values, list):
                    and_values = [and_values]
                and_values_str = ', '.join([f"'{v.lower().strip()}'" for v in and_values])
                and_clause = f' AND TRIM(LOWER("{and_col}")) IN ({and_values_str})'

            condition_label = f"{when_col} IN {when_values}"
            if and_col and and_values is not None:
                condition_label += f" AND {and_col} IN {and_values}"

            for req_col in then_required:
                if req_col not in df.columns:
                    continue

                values_str = ', '.join([f"'{v.lower().strip()}'" for v in when_values])
                stats = con.execute(f"""
                    SELECT
                        COUNT(*) as total,
                        COUNT(*) - COUNT("{req_col}") as null_count
                    FROM df
                    WHERE TRIM(LOWER("{when_col}")) IN ({values_str}){and_clause}
                """).fetchone()

                total, null_count = stats

                if total > 0 and null_count > 0:
                    pct_missing = (null_count / total) * 100
                    result.add_warning(
                        f"Conditional requirement violated: {description}",
                        {
                            "condition": condition_label,
                            "required_column": req_col,
                            "rows_meeting_condition": int(total),
                            "rows_with_missing": int(null_count),
                            "percent_missing": round(pct_missing, 2)
                        }
                    )
                elif total > 0:
                    result.add_info(
                        f"Conditional requirement satisfied: {description} — {int(total):,}/{int(total):,} rows present (100%)",
                        {"column": req_col, "condition": condition_label,
                         "rows_meeting_condition": int(total),
                         "rows_present": int(total),
                         "percent_present": 100.0}
                    )

        con.close()

    except Exception as e:
        _logger.error("Check 'conditional_requirements' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking conditional requirements: {str(e)}")

    return result


def check_conditional_requirements(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    conditions: Optional[List[Dict[str, Any]]] = None
) -> DQACompletenessResult:
    """Check conditional required fields."""
    n_conditions = len(conditions) if conditions else 0
    _logger.debug("check_conditional_requirements: starting for table '%s' (%d explicit conditions)",
                  table_name, n_conditions)
    if _ACTIVE_BACKEND == 'polars':
        result = check_conditional_requirements_polars(df, table_name, conditions)
    else:
        result = check_conditional_requirements_duckdb(df, table_name, conditions)
    if result.warnings:
        _logger.info("check_conditional_requirements: table '%s' — %d violations found",
                     table_name, len(result.warnings))
    _logger.debug("check_conditional_requirements: table '%s' complete", table_name)
    return result

# B. mCIDE value coverage
def check_mcide_value_coverage_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQACompletenessResult:
    """Check if all mCIDE standardized values are present in the data using Polars."""
    result = DQACompletenessResult("mcide_value_coverage", table_name)

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        category_columns = schema.get('category_columns') or []
        coverage_by_col = {}
        columns_missing = set()

        for col_spec in schema.get('columns', []):
            col_name = col_spec['name']
            permissible = col_spec.get('permissible_values', [])

            if not permissible:
                continue

            if col_name not in category_columns:
                continue

            if col_name not in col_names:
                columns_missing.add(col_name)
                continue

            unique_vals = (
                lf
                .select(pl.col(col_name).drop_nulls().unique())
                .collect(streaming=True)
                .to_series()
                .to_list()
            )

            unique_vals_lower = {str(v).lower().strip() for v in unique_vals if v is not None}

            missing_vals = [
                v for v in permissible
                if str(v).lower().strip() not in unique_vals_lower
            ]

            coverage_pct = ((len(permissible) - len(missing_vals)) / len(permissible)) * 100

            coverage_by_col[col_name] = {
                "expected_values": len(permissible),
                "found_values": len(permissible) - len(missing_vals),
                "missing_values": missing_vals,
                "coverage_percent": round(coverage_pct, 2)
            }

        result.metrics["category_columns_checked"] = len(coverage_by_col) + len(columns_missing)
        result.metrics["coverage_by_column"] = coverage_by_col

        for col_name, details in coverage_by_col.items():
            if details['missing_values']:
                result.add_error(
                    f"Missing {len(details['missing_values'])} mCIDE values: {', '.join(str(v) for v in details['missing_values'])}",
                    {
                        "column": col_name,
                        "missing_values": details['missing_values'],
                        "coverage_percent": details['coverage_percent']
                    }
                )
            else:
                result.add_info(
                    f"Column '{col_name}': all {details['expected_values']} mCIDE values present",
                    {
                        "column": col_name,
                        "coverage_percent": details['coverage_percent'],
                        "expected_values": details['expected_values']
                    }
                )

        for col_name in columns_missing:
            result.add_info(
                f"Column '{col_name}': not present in data (coverage check skipped)",
                {"column": col_name}
            )

        gc.collect()

    except Exception as e:
        _logger.error("Check 'mcide_value_coverage' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking mCIDE value coverage: {str(e)}")

    return result


def check_mcide_value_coverage_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str
) -> DQACompletenessResult:
    """Check if all mCIDE standardized values are present in the data using DuckDB."""
    result = DQACompletenessResult("mcide_value_coverage", table_name)

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        category_columns = schema.get('category_columns') or []
        coverage_by_col = {}
        columns_missing = set()

        for col_spec in schema.get('columns', []):
            col_name = col_spec['name']
            permissible = col_spec.get('permissible_values', [])

            if not permissible:
                continue

            if col_name not in category_columns:
                continue

            if col_name not in df.columns:
                columns_missing.add(col_name)
                continue

            unique_vals = con.execute(f"""
                SELECT DISTINCT "{col_name}" FROM df WHERE "{col_name}" IS NOT NULL
            """).fetchdf()[col_name].tolist()

            unique_vals_lower = {str(v).lower().strip() for v in unique_vals if v is not None}

            missing_vals = [
                v for v in permissible
                if str(v).lower().strip() not in unique_vals_lower
            ]

            coverage_pct = ((len(permissible) - len(missing_vals)) / len(permissible)) * 100

            coverage_by_col[col_name] = {
                "expected_values": len(permissible),
                "found_values": len(permissible) - len(missing_vals),
                "missing_values": missing_vals,
                "coverage_percent": round(coverage_pct, 2)
            }

        result.metrics["category_columns_checked"] = len(coverage_by_col) + len(columns_missing)
        result.metrics["coverage_by_column"] = coverage_by_col

        for col_name, details in coverage_by_col.items():
            if details['missing_values']:
                result.add_error(
                    f"Missing {len(details['missing_values'])} mCIDE values: {', '.join(str(v) for v in details['missing_values'])}",
                    {
                        "column": col_name,
                        "missing_values": details['missing_values'],
                        "coverage_percent": details['coverage_percent']
                    }
                )
            else:
                result.add_info(
                    f"Column '{col_name}': all {details['expected_values']} mCIDE values present",
                    {
                        "column": col_name,
                        "coverage_percent": details['coverage_percent'],
                        "expected_values": details['expected_values']
                    }
                )

        for col_name in columns_missing:
            result.add_info(
                f"Column '{col_name}': not present in data (coverage check skipped)",
                {"column": col_name}
            )

        con.close()

    except Exception as e:
        _logger.error("Check 'mcide_value_coverage' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking mCIDE value coverage: {str(e)}")

    return result


def check_mcide_value_coverage(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> DQACompletenessResult:
    """Check if all mCIDE standardized values are present in the data."""
    _logger.debug("check_mcide_value_coverage: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_mcide_value_coverage_polars(df, schema, table_name)
    else:
        result = check_mcide_value_coverage_duckdb(df, schema, table_name)
    _logger.debug("check_mcide_value_coverage: table '%s' — columns_checked=%s",
                  table_name, result.metrics.get("category_columns_checked"))
    return result

# C. Relational integrity checks
def check_relational_integrity_polars(
    source_df: Union['pl.DataFrame', 'pl.LazyFrame'],
    reference_df: Union['pl.DataFrame', 'pl.LazyFrame'],
    source_table: str,
    reference_table: str,
    key_column: str
) -> DQACompletenessResult:
    """Check relational integrity between tables using Polars."""
    result = DQACompletenessResult("relational_integrity", f"{source_table}->{reference_table}")

    try:
        source_lf = source_df if isinstance(source_df, pl.LazyFrame) else source_df.lazy()
        ref_lf = reference_df if isinstance(reference_df, pl.LazyFrame) else reference_df.lazy()

        source_ids = (
            source_lf
            .select(pl.col(key_column).drop_nulls().unique())
            .collect(streaming=True)
        )

        ref_ids = (
            ref_lf
            .select(pl.col(key_column).drop_nulls().unique())
            .collect(streaming=True)
        )

        source_id_set = set(source_ids[key_column].to_list())
        ref_id_set = set(ref_ids[key_column].to_list())

        orphan_ids = source_id_set - ref_id_set

        total_source = len(source_id_set)
        total_orphan = len(orphan_ids)
        coverage_pct = ((total_source - total_orphan) / total_source * 100) if total_source > 0 else 100

        result.metrics["source_unique_ids"] = total_source
        result.metrics["reference_unique_ids"] = len(ref_id_set)
        result.metrics["orphan_ids"] = total_orphan
        result.metrics["coverage_percent"] = round(coverage_pct, 2)

        if orphan_ids:
            result.add_warning(
                f"{total_orphan}/{total_source} {key_column} values in {source_table} "
                f"not found in {reference_table} ({round(coverage_pct, 1)}% coverage)",
                {
                    "orphan_count": total_orphan,
                    "coverage_percent": round(coverage_pct, 2)
                }
            )
        else:
            result.add_info(f"All {key_column} values in {source_table} exist in {reference_table}")

        gc.collect()

    except Exception as e:
        _logger.error("Check 'relational_integrity' failed for '%s' -> '%s': %s", source_table, reference_table, e)
        result.add_error(f"Error checking relational integrity: {str(e)}")

    return result


def check_relational_integrity_duckdb(
    source_df: pd.DataFrame,
    reference_df: pd.DataFrame,
    source_table: str,
    reference_table: str,
    key_column: str
) -> DQACompletenessResult:
    """Check relational integrity between tables using DuckDB."""
    result = DQACompletenessResult("relational_integrity", f"{source_table}->{reference_table}")

    try:
        con = duckdb.connect(':memory:')
        con.register('source_tbl', source_df)
        con.register('ref_tbl', reference_df)

        # Efficient anti-join query
        orphan_query = f"""
            WITH source_ids AS (
                SELECT DISTINCT "{key_column}" as id
                FROM source_tbl
                WHERE "{key_column}" IS NOT NULL
            ),
            ref_ids AS (
                SELECT DISTINCT "{key_column}" as id
                FROM ref_tbl
                WHERE "{key_column}" IS NOT NULL
            )
            SELECT
                (SELECT COUNT(*) FROM source_ids) as total_source,
                (SELECT COUNT(*) FROM ref_ids) as total_ref,
                (SELECT COUNT(*) FROM source_ids s
                 WHERE NOT EXISTS (SELECT 1 FROM ref_ids r WHERE r.id = s.id)) as orphan_count
        """

        stats = con.execute(orphan_query).fetchone()
        total_source, total_ref, orphan_count = stats

        coverage_pct = ((total_source - orphan_count) / total_source * 100) if total_source > 0 else 100

        result.metrics["source_unique_ids"] = int(total_source)
        result.metrics["reference_unique_ids"] = int(total_ref)
        result.metrics["orphan_ids"] = int(orphan_count)
        result.metrics["coverage_percent"] = round(coverage_pct, 2)

        if orphan_count > 0:
            result.add_warning(
                f"{orphan_count}/{total_source} {key_column} values in {source_table} "
                f"not found in {reference_table} ({round(coverage_pct, 1)}% coverage)",
                {
                    "orphan_count": int(orphan_count),
                    "coverage_percent": round(coverage_pct, 2)
                }
            )
        else:
            result.add_info(f"All {key_column} values in {source_table} exist in {reference_table}")

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'relational_integrity' failed for '%s' -> '%s': %s", source_table, reference_table, e)
        result.add_error(f"Error checking relational integrity: {str(e)}")

    return result


def check_relational_integrity(
    target_df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    reference_df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    target_table: str,
    reference_table: str,
    key_column: str
) -> DQACompletenessResult:
    """Check bidirectional relational integrity between tables.

    Runs the backend-specific check in both directions:
    - **Forward** (reference → target): What percentage of reference IDs
      appear in the target table?  (e.g., "what % of hospitalizations
      have labs?")
    - **Reverse** (target → reference): What percentage of target IDs
      exist in the reference table?  (e.g., "what % of lab hosp_ids are
      valid?")

    Parameters
    ----------
    target_df : DataFrame
        The target table (e.g., labs).
    reference_df : DataFrame
        The reference table (e.g., hospitalization).
    target_table : str
        Name of the target table.
    reference_table : str
        Name of the reference table.
    key_column : str
        The shared key column (e.g., ``hospitalization_id``).

    Returns
    -------
    DQACompletenessResult
        Consolidated result with forward/reverse coverage metrics.
    """
    _logger.debug(
        "check_relational_integrity: '%s' <-> '%s' on key '%s'",
        target_table, reference_table, key_column,
    )
    result = DQACompletenessResult(
        "relational_integrity",
        f"{target_table}<->{reference_table}",
    )

    # Pick the right backend dispatcher
    _backend_fn = (check_relational_integrity_polars
                   if _ACTIVE_BACKEND == 'polars'
                   else check_relational_integrity_duckdb)

    try:
        # Forward: reference → target  (source=reference, ref=target)
        fwd = _backend_fn(
            reference_df, target_df, reference_table, target_table, key_column
        )
        # Reverse: target → reference  (source=target, ref=reference)
        rev = _backend_fn(
            target_df, reference_df, target_table, reference_table, key_column
        )

        result.metrics["forward_coverage_percent"] = fwd.metrics.get("coverage_percent", 0)
        result.metrics["forward_orphan_ids"] = fwd.metrics.get("orphan_ids", 0)
        result.metrics["forward_reference_unique_ids"] = fwd.metrics.get("source_unique_ids", 0)
        result.metrics["reverse_coverage_percent"] = rev.metrics.get("coverage_percent", 0)
        result.metrics["reverse_orphan_ids"] = rev.metrics.get("orphan_ids", 0)
        result.metrics["reverse_target_unique_ids"] = rev.metrics.get("source_unique_ids", 0)

        # Propagate warnings/errors from both directions
        for w in fwd.warnings:
            result.add_warning(w['message'], w.get("details", {}))
        for w in rev.warnings:
            result.add_warning(w['message'], w.get("details", {}))
        for e in fwd.errors:
            result.add_error(e['message'], e.get("details", {}))
        for e in rev.errors:
            result.add_error(e['message'], e.get("details", {}))

        # Info when both directions are clean (no errors AND no warnings)
        if fwd.passed and rev.passed and not fwd.warnings and not rev.warnings:
            result.add_info(
                f"Full bidirectional coverage for {key_column} between "
                f"{target_table} and {reference_table}"
            )

        _logger.info(
            "check_relational_integrity: '%s' <-> '%s' — "
            "fwd_coverage=%.1f%%, rev_coverage=%.1f%%",
            target_table, reference_table,
            result.metrics["forward_coverage_percent"],
            result.metrics["reverse_coverage_percent"],
        )

    except Exception as e:
        _logger.error(
            "Check 'relational_integrity' failed for '%s' <-> '%s': %s",
            target_table, reference_table, e,
        )
        result.add_error(f"Error checking relational integrity: {str(e)}")

    return result


# ---------------------------------------------------------------------------
# PLAUSIBILITY CHECKS
# ---------------------------------------------------------------------------

# Helpers for plausibility checks

def _load_outlier_config() -> Dict[str, Any]:
    """Load the outlier_config.yaml for numeric range checks."""
    config_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), 'schemas', 'outlier_config.yaml'
    )
    if not os.path.exists(config_path):
        _logger.warning("Outlier config file not found: %s", config_path)
        return {}
    with open(config_path, 'r') as f:
        return yaml.safe_load(f) or {}


def _get_temporal_ordering_rules(table_name: str) -> List[Dict[str, str]]:
    """Load temporal ordering rules for a table from validation_rules.yaml."""
    rules = _load_validation_rules()
    return rules.get('temporal_ordering', {}).get(table_name, [])


def _get_field_plausibility_rules(table_name: str) -> List[Dict[str, Any]]:
    """Load field plausibility rules for a table from validation_rules.yaml."""
    rules = _load_validation_rules()
    return rules.get('field_plausibility_rules', {}).get(table_name, [])


def _get_composite_keys(table_name: str, schema: Optional[Dict[str, Any]] = None) -> List[str]:
    """Get composite keys for a table from schema or validation_rules.yaml."""
    if schema and 'composite_keys' in schema:
        return schema['composite_keys']
    rules = _load_validation_rules()
    entry = rules.get('composite_keys', {}).get(table_name, {})
    return entry.get('keys', [])


# Category column mapping for numeric range checks
_CATEGORY_COLUMN_MAP = {
    'labs': {'lab_value_numeric': 'lab_category'},
    'vitals': {'vital_value': 'vital_category'},
    'patient_assessments': {'numerical_value': 'assessment_category'},
    'medication_admin_continuous': {'med_dose': ('med_category', 'med_dose_unit')},
    'medication_admin_intermittent': {'med_dose': ('med_category', 'med_dose_unit')},
    'ecmo_mcs': {'sweep': 'device_category', 'flow': 'device_category', 'fdO2': 'device_category'},
}

# Reverse map: (table_name, category_col) → numeric_col (or None to skip avg)
_CATEGORY_TO_NUMERIC_MAP = {}
for _tbl, _col_map in _CATEGORY_COLUMN_MAP.items():
    for _num_col, _cat_col_info in _col_map.items():
        if isinstance(_cat_col_info, tuple):
            # Tuple: (category_col, unit_col) — averaging is safe when grouped by unit
            _CATEGORY_TO_NUMERIC_MAP[(_tbl, _cat_col_info[0])] = _num_col
        else:
            _key = (_tbl, _cat_col_info)
            # Multiple numeric cols → same category (e.g. ecmo_mcs): skip avg
            if _key in _CATEGORY_TO_NUMERIC_MAP:
                _CATEGORY_TO_NUMERIC_MAP[_key] = None
            else:
                _CATEGORY_TO_NUMERIC_MAP[_key] = _num_col

# Maps (table_name, category_col) → unit column name present in the data.
# Tables listed here will GROUP BY this column during monthly aggregation.
_CATEGORY_UNIT_COL_MAP = {
    ('labs', 'lab_category'): 'reference_unit',
    ('medication_admin_continuous', 'med_category'): 'med_dose_unit',
    ('medication_admin_intermittent', 'med_category'): 'med_dose_unit',
}


def _get_schema_units(schema: Dict[str, Any], cat_col: str) -> Optional[Dict[str, str]]:
    """Extract a {category_value: unit} map from schema *_units keys.

    Works for schemas like vitals (vital_units: {temp_c: Celsius, ...}).
    For list values (e.g. labs lab_reference_units), takes the first element.
    Returns None if no matching _units key is found.
    """
    for key, mapping in schema.items():
        if key.endswith('_units') and isinstance(mapping, dict):
            result: Dict[str, str] = {}
            for cat_val, unit in mapping.items():
                if isinstance(unit, list):
                    result[cat_val] = str(unit[0]) if unit else ''
                else:
                    result[cat_val] = str(unit)
            if result:
                return result
    return None


# Datetime columns per table for cross-table temporal checks
_CROSS_TABLE_TIME_COLUMNS = {
    'adt': ['in_dttm', 'out_dttm'],
    'labs': ['lab_order_dttm', 'lab_collect_dttm', 'lab_result_dttm'],
    'vitals': ['recorded_dttm'],
    'respiratory_support': ['recorded_dttm'],
    'medication_admin_continuous': ['admin_dttm'],
    'medication_admin_intermittent': ['admin_dttm'],
    'patient_assessments': ['recorded_dttm'],
    'position': ['recorded_dttm'],
    'microbiology_culture': ['order_dttm', 'collect_dttm', 'result_dttm'],
    'microbiology_nonculture': ['order_dttm', 'collect_dttm', 'result_dttm'],
    'crrt_therapy': ['recorded_dttm'],
    'ecmo_mcs': ['recorded_dttm'],
}

# Time-denominator patterns for medication dose unit checks
_TIME_DENOMINATOR_PATTERNS = ['/sec', '/min', '/hr', '/hour', '/day']


# ---------------------------------------------------------------------------
# A.1 Temporal ordering
# ---------------------------------------------------------------------------

def check_temporal_ordering_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    temporal_rules: Optional[List[Dict[str, str]]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check that datetime pairs follow expected temporal ordering using Polars."""
    result = DQAPlausibilityResult("temporal_ordering", table_name)

    if temporal_rules is None:
        temporal_rules = _get_temporal_ordering_rules(table_name)

    if not temporal_rules:
        result.add_info("No temporal ordering rules defined for this table")
        return result

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()
        violations_by_pair = {}

        for rule in temporal_rules:
            earlier = rule['earlier']
            later = rule['later']
            strict = rule.get('strict', False)
            description = rule.get('description', f"{earlier} {'<' if strict else '<='} {later}")

            if earlier not in col_names or later not in col_names:
                continue

            applicable = lf.filter(
                pl.col(earlier).is_not_null() & pl.col(later).is_not_null()
            )

            if strict:
                violation_expr = (pl.col(earlier) >= pl.col(later)).sum().alias('violations')
            else:
                violation_expr = (pl.col(earlier) > pl.col(later)).sum().alias('violations')

            stats = applicable.select([
                pl.len().alias('total'),
                violation_expr
            ]).collect(streaming=True)

            total = stats[0, 'total']
            violation_count = stats[0, 'violations']
            pct = (violation_count / total * 100) if total > 0 else 0

            violations_by_pair[f"{earlier}->{later}"] = {
                "total_applicable": int(total),
                "violations": int(violation_count),
                "violation_percent": round(pct, 2),
                "description": description,
            }

            if pct > error_threshold:
                result.add_error(
                    f"Temporal ordering violation: {description} — {violation_count}/{total} rows ({pct:.1f}%)",
                    {"pair": f"{earlier}->{later}", "violations": int(violation_count),
                     "total": int(total), "percent": round(pct, 2)}
                )
            elif pct > warning_threshold:
                result.add_warning(
                    f"Temporal ordering violation: {description} — {violation_count}/{total} rows ({pct:.1f}%)",
                    {"pair": f"{earlier}->{later}", "violations": int(violation_count),
                     "total": int(total), "percent": round(pct, 2)}
                )
            else:
                if total > 0:
                    result.add_info(
                        f"Temporal ordering satisfied: {description} — {int(total):,}/{int(total):,} rows valid (100%)",
                        {"column": f"{earlier}, {later}",
                         "rows_checked": int(total),
                         "rows_valid": int(total),
                         "percent_valid": 100.0}
                    )

        result.metrics["pairs_checked"] = len(violations_by_pair)
        result.metrics["violations_by_pair"] = violations_by_pair

        gc.collect()

    except Exception as e:
        _logger.error("Check 'temporal_ordering' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking temporal ordering: {str(e)}")

    return result


def check_temporal_ordering_duckdb(
    df: pd.DataFrame,
    table_name: str,
    temporal_rules: Optional[List[Dict[str, str]]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check that datetime pairs follow expected temporal ordering using DuckDB."""
    result = DQAPlausibilityResult("temporal_ordering", table_name)

    if temporal_rules is None:
        temporal_rules = _get_temporal_ordering_rules(table_name)

    if not temporal_rules:
        result.add_info("No temporal ordering rules defined for this table")
        return result

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)
        violations_by_pair = {}

        for rule in temporal_rules:
            earlier = rule['earlier']
            later = rule['later']
            strict = rule.get('strict', False)
            description = rule.get('description', f"{earlier} {'<' if strict else '<='} {later}")

            if earlier not in df.columns or later not in df.columns:
                continue

            op = ">=" if strict else ">"
            stats = con.execute(f"""
                SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN "{earlier}" {op} "{later}" THEN 1 ELSE 0 END) as violations
                FROM df
                WHERE "{earlier}" IS NOT NULL AND "{later}" IS NOT NULL
            """).fetchone()

            total, violation_count = stats
            pct = (violation_count / total * 100) if total > 0 else 0

            violations_by_pair[f"{earlier}->{later}"] = {
                "total_applicable": int(total),
                "violations": int(violation_count),
                "violation_percent": round(pct, 2),
                "description": description,
            }

            if pct > error_threshold:
                result.add_error(
                    f"Temporal ordering violation: {description} — {violation_count}/{total} rows ({pct:.1f}%)",
                    {"pair": f"{earlier}->{later}", "violations": int(violation_count),
                     "total": int(total), "percent": round(pct, 2)}
                )
            elif pct > warning_threshold:
                result.add_warning(
                    f"Temporal ordering violation: {description} — {violation_count}/{total} rows ({pct:.1f}%)",
                    {"pair": f"{earlier}->{later}", "violations": int(violation_count),
                     "total": int(total), "percent": round(pct, 2)}
                )
            else:
                if total > 0:
                    result.add_info(
                        f"Temporal ordering satisfied: {description} — {int(total):,}/{int(total):,} rows valid (100%)",
                        {"column": f"{earlier}, {later}",
                         "rows_checked": int(total),
                         "rows_valid": int(total),
                         "percent_valid": 100.0}
                    )

        result.metrics["pairs_checked"] = len(violations_by_pair)
        result.metrics["violations_by_pair"] = violations_by_pair

        con.close()

    except Exception as e:
        _logger.error("Check 'temporal_ordering' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking temporal ordering: {str(e)}")

    return result


def check_temporal_ordering(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    temporal_rules: Optional[List[Dict[str, str]]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check that datetime pairs follow expected temporal ordering."""
    _logger.debug("check_temporal_ordering: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_temporal_ordering_polars(df, table_name, temporal_rules,
                                                warning_threshold=warning_threshold,
                                                error_threshold=error_threshold)
    else:
        result = check_temporal_ordering_duckdb(df, table_name, temporal_rules,
                                                warning_threshold=warning_threshold,
                                                error_threshold=error_threshold)
    _logger.debug("check_temporal_ordering: table '%s' — pairs_checked=%s",
                  table_name, result.metrics.get("pairs_checked"))
    return result


# ---------------------------------------------------------------------------
# A.2 Numeric range plausibility
# ---------------------------------------------------------------------------

def check_numeric_range_plausibility_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    outlier_config: Optional[Dict[str, Any]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check numeric values are within plausible ranges using Polars."""
    result = DQAPlausibilityResult("numeric_range_plausibility", table_name)

    if outlier_config is None:
        outlier_config = _load_outlier_config()

    table_config = outlier_config.get('tables', {}).get(table_name, {})
    if not table_config:
        result.add_info("No numeric range configuration for this table")
        return result

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()
        oor_summary = {}
        cat_map = _CATEGORY_COLUMN_MAP.get(table_name, {})

        # Pre-cast: ensure all configured columns are numeric (string → Float64)
        schema = lf.collect_schema()
        cast_exprs = []
        for _col in table_config:
            if _col in schema.names():
                _dtype = schema[_col]
                if _dtype in (pl.Utf8, pl.String):
                    cast_exprs.append(pl.col(_col).cast(pl.Float64, strict=False))
        if cast_exprs:
            lf = lf.with_columns(cast_exprs)

        for col_name, col_ranges in table_config.items():
            if col_name not in col_names:
                continue

            if isinstance(col_ranges, dict) and 'min' in col_ranges and 'max' in col_ranges:
                # Simple range
                rmin, rmax = col_ranges['min'], col_ranges['max']
                stats = lf.select([
                    pl.col(col_name).drop_nulls().len().alias('total'),
                    ((pl.col(col_name) < rmin) | (pl.col(col_name) > rmax)).sum().alias('oor'),
                    (pl.col(col_name) < rmin).sum().alias('below'),
                    (pl.col(col_name) > rmax).sum().alias('above'),
                ]).collect(streaming=True)

                total = stats[0, 'total']
                oor = stats[0, 'oor']
                below = stats[0, 'below']
                above = stats[0, 'above']
                pct = (oor / total * 100) if total > 0 else 0

                oor_summary[col_name] = {
                    "total_non_null": int(total), "out_of_range": int(oor),
                    "out_of_range_percent": round(pct, 2),
                    "below_min": int(below), "above_max": int(above),
                    "min": rmin, "max": rmax,
                }

                if pct > error_threshold:
                    result.add_error(
                        f"Column '{col_name}': {oor}/{total} values ({pct:.1f}%) outside range [{rmin}, {rmax}]",
                        {"column": col_name, "percent": round(pct, 2)}
                    )
                elif pct > warning_threshold:
                    result.add_warning(
                        f"Column '{col_name}': {oor}/{total} values ({pct:.1f}%) outside range [{rmin}, {rmax}]",
                        {"column": col_name, "percent": round(pct, 2)}
                    )

            elif isinstance(col_ranges, dict):
                # Category-dependent ranges
                cat_col_info = cat_map.get(col_name)
                if cat_col_info is None:
                    continue

                if isinstance(cat_col_info, tuple):
                    # 2-level: (category_col, unit_col) — batched single scan
                    cat_col, unit_col = cat_col_info
                    if cat_col not in col_names or unit_col not in col_names:
                        continue

                    combo_keys = []  # (cat_val, unit_val, rmin, rmax)
                    range_exprs = []
                    lf_cat = lf.with_columns([
                        pl.col(cat_col).cast(pl.Utf8).str.to_lowercase().str.strip_chars().alias('_cat_norm'),
                        pl.col(unit_col).cast(pl.Utf8).str.to_lowercase().str.strip_chars().alias('_unit_norm'),
                    ])

                    for cat_val, unit_ranges in col_ranges.items():
                        if not isinstance(unit_ranges, dict):
                            continue
                        for unit_val, ranges in unit_ranges.items():
                            if not isinstance(ranges, dict) or 'min' not in ranges:
                                continue
                            rmin, rmax = ranges['min'], ranges['max']
                            idx = len(combo_keys)
                            combo_keys.append((cat_val, unit_val, rmin, rmax))
                            cat_norm = str(cat_val).lower().strip()
                            unit_norm = str(unit_val).lower().strip()
                            mask = (
                                (pl.col('_cat_norm') == cat_norm) &
                                (pl.col('_unit_norm') == unit_norm) &
                                pl.col(col_name).is_not_null()
                            )
                            oor = (pl.col(col_name) < rmin) | (pl.col(col_name) > rmax)
                            range_exprs.append(mask.sum().alias(f'_t{idx}'))
                            range_exprs.append((mask & oor).sum().alias(f'_o{idx}'))

                    if not range_exprs:
                        continue

                    stats_row = lf_cat.select(range_exprs).collect(streaming=True)
                    total_oor = 0
                    total_count = 0
                    for idx, (cat_val, unit_val, rmin, rmax) in enumerate(combo_keys):
                        cat_total = int(stats_row[0, f'_t{idx}'])
                        cat_oor = int(stats_row[0, f'_o{idx}'])
                        cat_pct = (cat_oor / cat_total * 100) if cat_total > 0 else 0
                        total_count += cat_total
                        total_oor += cat_oor

                        if cat_oor > 0 and cat_pct > error_threshold:
                            result.add_error(
                                f"Column '{col_name}' ({cat_val}, {unit_val}): {cat_oor}/{cat_total} values ({cat_pct:.1f}%) outside range [{rmin}, {rmax}]",
                                {"column": col_name, "category": cat_val, "unit": unit_val, "percent": round(cat_pct, 2)}
                            )
                        elif cat_oor > 0 and cat_pct > warning_threshold:
                            result.add_warning(
                                f"Column '{col_name}' ({cat_val}, {unit_val}): {cat_oor}/{cat_total} values ({cat_pct:.1f}%) outside range [{rmin}, {rmax}]",
                                {"column": col_name, "category": cat_val, "unit": unit_val, "percent": round(cat_pct, 2)}
                            )

                    pct = (total_oor / total_count * 100) if total_count > 0 else 0
                    oor_summary[col_name] = {
                        "total_non_null": int(total_count), "out_of_range": int(total_oor),
                        "out_of_range_percent": round(pct, 2),
                    }
                else:
                    # 1-level category-dependent — batched single scan
                    cat_col = cat_col_info
                    if cat_col not in col_names:
                        continue

                    combo_keys = []  # (cat_val, rmin, rmax)
                    range_exprs = []
                    lf_cat = lf.with_columns(
                        pl.col(cat_col).cast(pl.Utf8).str.to_lowercase().str.strip_chars().alias('_cat_norm')
                    )

                    for cat_val, ranges in col_ranges.items():
                        if not isinstance(ranges, dict) or 'min' not in ranges:
                            continue
                        rmin, rmax = ranges['min'], ranges['max']
                        idx = len(combo_keys)
                        combo_keys.append((cat_val, rmin, rmax))
                        cat_norm = str(cat_val).lower().strip()
                        mask = (pl.col('_cat_norm') == cat_norm) & pl.col(col_name).is_not_null()
                        oor = (pl.col(col_name) < rmin) | (pl.col(col_name) > rmax)
                        range_exprs.append(mask.sum().alias(f'_t{idx}'))
                        range_exprs.append((mask & oor).sum().alias(f'_o{idx}'))

                    if not range_exprs:
                        continue

                    stats_row = lf_cat.select(range_exprs).collect(streaming=True)
                    total_oor = 0
                    total_count = 0
                    for idx, (cat_val, rmin, rmax) in enumerate(combo_keys):
                        cat_total = int(stats_row[0, f'_t{idx}'])
                        cat_oor = int(stats_row[0, f'_o{idx}'])
                        cat_pct = (cat_oor / cat_total * 100) if cat_total > 0 else 0
                        total_count += cat_total
                        total_oor += cat_oor

                        if cat_oor > 0 and cat_pct > error_threshold:
                            result.add_error(
                                f"Column '{col_name}' ({cat_val}): {cat_oor}/{cat_total} values ({cat_pct:.1f}%) outside range [{rmin}, {rmax}]",
                                {"column": col_name, "category": cat_val, "percent": round(cat_pct, 2)}
                            )
                        elif cat_oor > 0 and cat_pct > warning_threshold:
                            result.add_warning(
                                f"Column '{col_name}' ({cat_val}): {cat_oor}/{cat_total} values ({cat_pct:.1f}%) outside range [{rmin}, {rmax}]",
                                {"column": col_name, "category": cat_val, "percent": round(cat_pct, 2)}
                            )

                    pct = (total_oor / total_count * 100) if total_count > 0 else 0
                    oor_summary[col_name] = {
                        "total_non_null": int(total_count), "out_of_range": int(total_oor),
                        "out_of_range_percent": round(pct, 2),
                    }

        result.metrics["columns_checked"] = len(oor_summary)
        result.metrics["out_of_range_summary"] = oor_summary

        if not result.warnings and not result.errors:
            if oor_summary:
                cols_str = ', '.join(sorted(oor_summary.keys()))
                result.add_info(
                    f"All numeric values within plausible ranges ({cols_str})",
                    {"columns_checked": sorted(oor_summary.keys())},
                )
            else:
                result.add_info("No numeric columns with range configuration to check")

        gc.collect()

    except Exception as e:
        _logger.error("Check 'numeric_range_plausibility' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking numeric range plausibility: {str(e)}")

    return result


def check_numeric_range_plausibility_duckdb(
    df: pd.DataFrame,
    table_name: str,
    outlier_config: Optional[Dict[str, Any]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check numeric values are within plausible ranges using DuckDB."""
    result = DQAPlausibilityResult("numeric_range_plausibility", table_name)

    if outlier_config is None:
        outlier_config = _load_outlier_config()

    table_config = outlier_config.get('tables', {}).get(table_name, {})
    if not table_config:
        result.add_info("No numeric range configuration for this table")
        return result

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)
        actual_cols = list(df.columns)
        oor_summary = {}
        cat_map = _CATEGORY_COLUMN_MAP.get(table_name, {})

        # Pre-cast: ensure all configured columns are numeric (string → float)
        _needs_reregister = False
        for _col in table_config:
            if _col in actual_cols:
                if df[_col].dtype == object or pd.api.types.is_string_dtype(df[_col].dtype):
                    df[_col] = pd.to_numeric(df[_col], errors='coerce')
                    _needs_reregister = True
        if _needs_reregister:
            con.register('df', df)

        for col_name, col_ranges in table_config.items():
            if col_name not in actual_cols:
                continue

            if isinstance(col_ranges, dict) and 'min' in col_ranges and 'max' in col_ranges:
                rmin, rmax = col_ranges['min'], col_ranges['max']
                stats = con.execute(f"""
                    SELECT
                        COUNT("{col_name}") as total,
                        SUM(CASE WHEN "{col_name}" < {rmin} OR "{col_name}" > {rmax} THEN 1 ELSE 0 END) as oor,
                        SUM(CASE WHEN "{col_name}" < {rmin} THEN 1 ELSE 0 END) as below,
                        SUM(CASE WHEN "{col_name}" > {rmax} THEN 1 ELSE 0 END) as above
                    FROM df
                    WHERE "{col_name}" IS NOT NULL
                """).fetchone()

                total, oor, below, above = stats
                pct = (oor / total * 100) if total > 0 else 0

                oor_summary[col_name] = {
                    "total_non_null": int(total), "out_of_range": int(oor),
                    "out_of_range_percent": round(pct, 2),
                    "below_min": int(below), "above_max": int(above),
                    "min": rmin, "max": rmax,
                }

                if pct > error_threshold:
                    result.add_error(
                        f"Column '{col_name}': {oor}/{total} values ({pct:.1f}%) outside range [{rmin}, {rmax}]",
                        {"column": col_name, "percent": round(pct, 2)}
                    )
                elif pct > warning_threshold:
                    result.add_warning(
                        f"Column '{col_name}': {oor}/{total} values ({pct:.1f}%) outside range [{rmin}, {rmax}]",
                        {"column": col_name, "percent": round(pct, 2)}
                    )

            elif isinstance(col_ranges, dict):
                cat_col_info = cat_map.get(col_name)
                if cat_col_info is None:
                    continue

                total_oor = 0
                total_count = 0

                if isinstance(cat_col_info, tuple):
                    # 2-level: (category_col, unit_col) — batched single query
                    cat_col, unit_col = cat_col_info
                    if cat_col not in actual_cols or unit_col not in actual_cols:
                        continue

                    combo_keys = []  # (cat_val, unit_val, rmin, rmax)
                    case_parts = []
                    for cat_val, unit_ranges in col_ranges.items():
                        if not isinstance(unit_ranges, dict):
                            continue
                        for unit_val, ranges in unit_ranges.items():
                            if not isinstance(ranges, dict) or 'min' not in ranges:
                                continue
                            rmin, rmax = ranges['min'], ranges['max']
                            idx = len(combo_keys)
                            combo_keys.append((cat_val, unit_val, rmin, rmax))
                            cat_norm = str(cat_val).lower().strip().replace("'", "''")
                            unit_norm = str(unit_val).lower().strip().replace("'", "''")
                            where = (
                                f"TRIM(LOWER(CAST(\"{cat_col}\" AS VARCHAR))) = '{cat_norm}' "
                                f"AND TRIM(LOWER(CAST(\"{unit_col}\" AS VARCHAR))) = '{unit_norm}' "
                                f"AND \"{col_name}\" IS NOT NULL"
                            )
                            case_parts.append(
                                f"COALESCE(SUM(CASE WHEN {where} THEN 1 ELSE 0 END), 0) AS col_{idx}_total, "
                                f"COALESCE(SUM(CASE WHEN {where} AND (\"{col_name}\" < {rmin} OR \"{col_name}\" > {rmax}) THEN 1 ELSE 0 END), 0) AS col_{idx}_oor"
                            )

                    if not case_parts:
                        continue

                    sql = f'SELECT {", ".join(case_parts)} FROM df'
                    row = con.execute(sql).fetchone()

                    for idx, (cat_val, unit_val, rmin, rmax) in enumerate(combo_keys):
                        cat_total = row[idx * 2] or 0
                        cat_oor = row[idx * 2 + 1] or 0
                        cat_pct = (cat_oor / cat_total * 100) if cat_total > 0 else 0
                        total_count += cat_total
                        total_oor += cat_oor

                        if cat_oor > 0 and cat_pct > error_threshold:
                            result.add_error(
                                f"Column '{col_name}' ({cat_val}, {unit_val}): {cat_oor}/{cat_total} values ({cat_pct:.1f}%) outside range [{rmin}, {rmax}]",
                                {"column": col_name, "category": cat_val, "unit": unit_val, "percent": round(cat_pct, 2)}
                            )
                        elif cat_oor > 0 and cat_pct > warning_threshold:
                            result.add_warning(
                                f"Column '{col_name}' ({cat_val}, {unit_val}): {cat_oor}/{cat_total} values ({cat_pct:.1f}%) outside range [{rmin}, {rmax}]",
                                {"column": col_name, "category": cat_val, "unit": unit_val, "percent": round(cat_pct, 2)}
                            )
                else:
                    # 1-level category-dependent — batched single query
                    cat_col = cat_col_info
                    if cat_col not in actual_cols:
                        continue

                    combo_keys = []  # (cat_val, rmin, rmax)
                    case_parts = []
                    for cat_val, ranges in col_ranges.items():
                        if not isinstance(ranges, dict) or 'min' not in ranges:
                            continue
                        rmin, rmax = ranges['min'], ranges['max']
                        idx = len(combo_keys)
                        combo_keys.append((cat_val, rmin, rmax))
                        cat_norm = str(cat_val).lower().strip().replace("'", "''")
                        where = (
                            f"TRIM(LOWER(CAST(\"{cat_col}\" AS VARCHAR))) = '{cat_norm}' "
                            f"AND \"{col_name}\" IS NOT NULL"
                        )
                        case_parts.append(
                            f"COALESCE(SUM(CASE WHEN {where} THEN 1 ELSE 0 END), 0) AS col_{idx}_total, "
                            f"COALESCE(SUM(CASE WHEN {where} AND (\"{col_name}\" < {rmin} OR \"{col_name}\" > {rmax}) THEN 1 ELSE 0 END), 0) AS col_{idx}_oor"
                        )

                    if not case_parts:
                        continue

                    sql = f'SELECT {", ".join(case_parts)} FROM df'
                    row = con.execute(sql).fetchone()

                    for idx, (cat_val, rmin, rmax) in enumerate(combo_keys):
                        cat_total = row[idx * 2] or 0
                        cat_oor = row[idx * 2 + 1] or 0
                        cat_pct = (cat_oor / cat_total * 100) if cat_total > 0 else 0
                        total_count += cat_total
                        total_oor += cat_oor

                        if cat_oor > 0 and cat_pct > error_threshold:
                            result.add_error(
                                f"Column '{col_name}' ({cat_val}): {cat_oor}/{cat_total} values ({cat_pct:.1f}%) outside range [{rmin}, {rmax}]",
                                {"column": col_name, "category": cat_val, "percent": round(cat_pct, 2)}
                            )
                        elif cat_oor > 0 and cat_pct > warning_threshold:
                            result.add_warning(
                                f"Column '{col_name}' ({cat_val}): {cat_oor}/{cat_total} values ({cat_pct:.1f}%) outside range [{rmin}, {rmax}]",
                                {"column": col_name, "category": cat_val, "percent": round(cat_pct, 2)}
                            )

                pct = (total_oor / total_count * 100) if total_count > 0 else 0
                oor_summary[col_name] = {
                    "total_non_null": int(total_count), "out_of_range": int(total_oor),
                    "out_of_range_percent": round(pct, 2),
                }

        result.metrics["columns_checked"] = len(oor_summary)
        result.metrics["out_of_range_summary"] = oor_summary

        if not result.warnings and not result.errors:
            if oor_summary:
                cols_str = ', '.join(sorted(oor_summary.keys()))
                result.add_info(
                    f"All numeric values within plausible ranges ({cols_str})",
                    {"columns_checked": sorted(oor_summary.keys())},
                )
            else:
                result.add_info("No numeric columns with range configuration to check")

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'numeric_range_plausibility' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking numeric range plausibility: {str(e)}")

    return result


def check_numeric_range_plausibility(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    outlier_config: Optional[Dict[str, Any]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check numeric values are within plausible ranges."""
    _logger.debug("check_numeric_range_plausibility: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_numeric_range_plausibility_polars(df, table_name, outlier_config,
                                                         warning_threshold=warning_threshold,
                                                         error_threshold=error_threshold)
    else:
        result = check_numeric_range_plausibility_duckdb(df, table_name, outlier_config,
                                                         warning_threshold=warning_threshold,
                                                         error_threshold=error_threshold)
    _logger.debug("check_numeric_range_plausibility: table '%s' — columns_checked=%s",
                  table_name, result.metrics.get("columns_checked"))
    return result


# ---------------------------------------------------------------------------
# A.3 Field-level plausibility rules
# ---------------------------------------------------------------------------

def check_field_plausibility_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    rules: Optional[List[Dict[str, Any]]] = None,
) -> DQAPlausibilityResult:
    """Check field-level plausibility constraints using Polars."""
    result = DQAPlausibilityResult("field_plausibility", table_name)

    if rules is None:
        rules = _get_field_plausibility_rules(table_name)

    if not rules:
        result.add_info("No field plausibility rules defined for this table")
        return result

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()
        violations_by_rule = {}

        for rule in rules:
            when_col = rule['when_column']
            description = rule.get('description', '')

            if when_col not in col_names:
                continue

            # New-variant: when_not_null + then_column + then_not_value
            if rule.get('when_not_null'):
                then_col = rule['then_column']
                forbidden = rule['then_not_value']
                if not isinstance(forbidden, list):
                    forbidden = [forbidden]

                if then_col not in col_names:
                    continue

                filtered = lf.filter(pl.col(when_col).is_not_null())
                stats = filtered.select([
                    pl.len().alias('total'),
                    pl.col(then_col).cast(pl.Utf8).str.to_lowercase().str.strip_chars().is_in(
                        [str(v).lower().strip() for v in forbidden]
                    ).sum().alias('violations')
                ]).collect(streaming=True)

                total = stats[0, 'total']
                violations = stats[0, 'violations']
                pct = (violations / total * 100) if total > 0 else 0

                if violations > 0:
                    violations_by_rule[description] = {
                        "total_applicable": int(total),
                        "violations": int(violations),
                        "violation_percent": round(pct, 2),
                    }
                    result.add_warning(
                        f"Field plausibility violation: {description} — {violations}/{total} rows ({pct:.1f}%)",
                        {"rule": description, "violations": int(violations),
                         "total": int(total), "percent": round(pct, 2)}
                    )
                else:
                    if total > 0:
                        result.add_info(
                            f"Field plausibility satisfied: {description} — {int(total):,}/{int(total):,} rows valid (100%)",
                            {"column": then_col,
                             "rows_checked": int(total),
                             "rows_valid": int(total),
                             "percent_valid": 100.0}
                        )
                continue

            # Old-variant: when_not_value + then_null_or_absent
            when_not_values = rule['when_not_value']
            then_null_cols = rule['then_null_or_absent']

            if not isinstance(when_not_values, list):
                when_not_values = [when_not_values]

            # Filter rows where when_col is NOT in the specified values
            filtered = lf.filter(
                ~pl.col(when_col).cast(pl.Utf8).str.to_lowercase().str.strip_chars().is_in(
                    [str(v).lower().strip() for v in when_not_values]
                )
            )

            for check_col in then_null_cols:
                if check_col not in col_names:
                    continue

                stats = filtered.select([
                    pl.len().alias('total'),
                    pl.col(check_col).is_not_null().sum().alias('non_null')
                ]).collect(streaming=True)

                total = stats[0, 'total']
                non_null = stats[0, 'non_null']
                pct = (non_null / total * 100) if total > 0 else 0

                if non_null > 0:
                    violations_by_rule[description] = {
                        "total_applicable": int(total),
                        "violations": int(non_null),
                        "violation_percent": round(pct, 2),
                    }
                    result.add_warning(
                        f"Field plausibility violation: {description} — {non_null}/{total} rows ({pct:.1f}%)",
                        {"rule": description, "violations": int(non_null),
                         "total": int(total), "percent": round(pct, 2)}
                    )
                else:
                    if total > 0:
                        result.add_info(
                            f"Field plausibility satisfied: {description} — {int(total):,}/{int(total):,} rows valid (100%)",
                            {"column": check_col,
                             "rows_checked": int(total),
                             "rows_valid": int(total),
                             "percent_valid": 100.0}
                        )

        result.metrics["rules_checked"] = len(rules)
        result.metrics["violations_by_rule"] = violations_by_rule

        gc.collect()

    except Exception as e:
        _logger.error("Check 'field_plausibility' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking field plausibility: {str(e)}")

    return result


def check_field_plausibility_duckdb(
    df: pd.DataFrame,
    table_name: str,
    rules: Optional[List[Dict[str, Any]]] = None,
) -> DQAPlausibilityResult:
    """Check field-level plausibility constraints using DuckDB."""
    result = DQAPlausibilityResult("field_plausibility", table_name)

    if rules is None:
        rules = _get_field_plausibility_rules(table_name)

    if not rules:
        result.add_info("No field plausibility rules defined for this table")
        return result

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)
        violations_by_rule = {}

        for rule in rules:
            when_col = rule['when_column']
            description = rule.get('description', '')

            if when_col not in df.columns:
                continue

            # New-variant: when_not_null + then_column + then_not_value
            if rule.get('when_not_null'):
                then_col = rule['then_column']
                forbidden = rule['then_not_value']
                if not isinstance(forbidden, list):
                    forbidden = [forbidden]

                if then_col not in df.columns:
                    continue

                forbidden_str = ', '.join([f"'{str(v).lower().strip()}'" for v in forbidden])

                stats = con.execute(f"""
                    SELECT
                        COUNT(*) as total,
                        SUM(CASE WHEN TRIM(LOWER(CAST("{then_col}" AS VARCHAR))) IN ({forbidden_str}) THEN 1 ELSE 0 END) as violations
                    FROM df
                    WHERE "{when_col}" IS NOT NULL
                """).fetchone()

                total, violations = stats
                pct = (violations / total * 100) if total > 0 else 0

                if violations > 0:
                    violations_by_rule[description] = {
                        "total_applicable": int(total),
                        "violations": int(violations),
                        "violation_percent": round(pct, 2),
                    }
                    result.add_warning(
                        f"Field plausibility violation: {description} — {violations}/{total} rows ({pct:.1f}%)",
                        {"rule": description, "violations": int(violations),
                         "total": int(total), "percent": round(pct, 2)}
                    )
                else:
                    if total > 0:
                        result.add_info(
                            f"Field plausibility satisfied: {description} — {int(total):,}/{int(total):,} rows valid (100%)",
                            {"column": then_col,
                             "rows_checked": int(total),
                             "rows_valid": int(total),
                             "percent_valid": 100.0}
                        )
                continue

            # Old-variant: when_not_value + then_null_or_absent
            when_not_values = rule['when_not_value']
            then_null_cols = rule['then_null_or_absent']

            if not isinstance(when_not_values, list):
                when_not_values = [when_not_values]

            values_str = ', '.join([f"'{str(v).lower().strip()}'" for v in when_not_values])

            for check_col in then_null_cols:
                if check_col not in df.columns:
                    continue

                stats = con.execute(f"""
                    SELECT
                        COUNT(*) as total,
                        SUM(CASE WHEN "{check_col}" IS NOT NULL THEN 1 ELSE 0 END) as non_null
                    FROM df
                    WHERE TRIM(LOWER(CAST("{when_col}" AS VARCHAR))) NOT IN ({values_str})
                """).fetchone()

                total, non_null = stats
                pct = (non_null / total * 100) if total > 0 else 0

                if non_null > 0:
                    violations_by_rule[description] = {
                        "total_applicable": int(total),
                        "violations": int(non_null),
                        "violation_percent": round(pct, 2),
                    }
                    result.add_warning(
                        f"Field plausibility violation: {description} — {non_null}/{total} rows ({pct:.1f}%)",
                        {"rule": description, "violations": int(non_null),
                         "total": int(total), "percent": round(pct, 2)}
                    )
                else:
                    if total > 0:
                        result.add_info(
                            f"Field plausibility satisfied: {description} — {int(total):,}/{int(total):,} rows valid (100%)",
                            {"column": check_col,
                             "rows_checked": int(total),
                             "rows_valid": int(total),
                             "percent_valid": 100.0}
                        )

        result.metrics["rules_checked"] = len(rules)
        result.metrics["violations_by_rule"] = violations_by_rule

        con.close()

    except Exception as e:
        _logger.error("Check 'field_plausibility' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking field plausibility: {str(e)}")

    return result


def check_field_plausibility(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    rules: Optional[List[Dict[str, Any]]] = None,
) -> DQAPlausibilityResult:
    """Check field-level plausibility constraints."""
    _logger.debug("check_field_plausibility: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_field_plausibility_polars(df, table_name, rules)
    else:
        result = check_field_plausibility_duckdb(df, table_name, rules)
    _logger.debug("check_field_plausibility: table '%s' — rules_checked=%s",
                  table_name, result.metrics.get("rules_checked"))
    return result


# ---------------------------------------------------------------------------
# A.4 Medication dose unit consistency
# ---------------------------------------------------------------------------

def check_medication_dose_unit_consistency_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check medication dose unit consistency using Polars."""
    result = DQAPlausibilityResult("medication_dose_unit_consistency", table_name)

    if table_name not in ('medication_admin_continuous', 'medication_admin_intermittent'):
        result.add_info("Medication dose unit check not applicable to this table")
        return result

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        if 'med_dose_unit' not in col_names:
            result.add_info("Column 'med_dose_unit' not found in table")
            return result

        rules = _load_validation_rules().get('medication_dose_unit_rules', {}).get(table_name, {})
        expect = rules.get('expect', 'per_time' if 'continuous' in table_name else 'discrete')

        # Build expression to detect time denominators
        has_time_denom = pl.lit(False)
        for pat in _TIME_DENOMINATOR_PATTERNS:
            has_time_denom = has_time_denom | pl.col('med_dose_unit').cast(pl.Utf8).str.contains(pat.replace('/', '\\/'))

        non_null = lf.filter(pl.col('med_dose_unit').is_not_null())
        total = non_null.select(pl.len()).collect(streaming=True).item()

        if total == 0:
            result.add_info("No non-null med_dose_unit values to check")
            return result

        if expect == 'per_time':
            # Continuous: expect time denominators
            violations = non_null.filter(~has_time_denom).select(pl.len()).collect(streaming=True).item()
        else:
            # Intermittent: expect NO time denominators
            violations = non_null.filter(has_time_denom).select(pl.len()).collect(streaming=True).item()

        pct = (violations / total * 100) if total > 0 else 0

        result.metrics["total_rows"] = int(total)
        result.metrics["unit_pattern_violations"] = int(violations)
        result.metrics["violation_percent"] = round(pct, 2)

        if violations > 0:
            # Get sample violations
            if expect == 'per_time':
                sample = non_null.filter(~has_time_denom)
            else:
                sample = non_null.filter(has_time_denom)

            sample_cols = ['med_dose_unit']
            if 'med_category' in col_names:
                sample_cols.insert(0, 'med_category')

            sample_data = (
                sample
                .group_by(sample_cols)
                .agg(pl.len().alias('count'))
                .sort('count', descending=True)
                .head(10)
                .collect(streaming=True)
            )
            sample_list = sample_data.to_dicts()
            result.metrics["sample_violations"] = sample_list

            if expect == 'per_time':
                warn_msg = f"Medication dose unit inconsistency: {violations}/{total} rows ({pct:.1f}%) use non-rate-based units unexpected for continuous administration"
            else:
                warn_msg = f"Medication dose unit inconsistency: {violations}/{total} rows ({pct:.1f}%) use rate-based units unexpected for intermittent administration"
            if pct > error_threshold:
                result.add_error(warn_msg, {"violations": int(violations), "total": int(total), "percent": round(pct, 2)})
            elif pct > warning_threshold:
                result.add_warning(warn_msg, {"violations": int(violations), "total": int(total), "percent": round(pct, 2)})
        else:
            if expect == 'per_time':
                result.add_info("All med_dose_unit values use rate-based units (e.g. mcg/kg/min) appropriate for continuous administration")
            else:
                result.add_info("All med_dose_unit values use dose-based units (e.g. mg, mL) appropriate for intermittent administration")

        gc.collect()

    except Exception as e:
        _logger.error("Check 'medication_dose_unit_consistency' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking medication dose unit consistency: {str(e)}")

    return result


def check_medication_dose_unit_consistency_duckdb(
    df: pd.DataFrame,
    table_name: str,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check medication dose unit consistency using DuckDB."""
    result = DQAPlausibilityResult("medication_dose_unit_consistency", table_name)

    if table_name not in ('medication_admin_continuous', 'medication_admin_intermittent'):
        result.add_info("Medication dose unit check not applicable to this table")
        return result

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        if 'med_dose_unit' not in df.columns:
            result.add_info("Column 'med_dose_unit' not found in table")
            con.close()
            return result

        rules = _load_validation_rules().get('medication_dose_unit_rules', {}).get(table_name, {})
        expect = rules.get('expect', 'per_time' if 'continuous' in table_name else 'discrete')

        # Build CASE expression for time denominator detection
        time_conditions = ' OR '.join([
            f"CAST(\"med_dose_unit\" AS VARCHAR) LIKE '%{pat}%'"
            for pat in _TIME_DENOMINATOR_PATTERNS
        ])

        total_row = con.execute("""
            SELECT COUNT(*) FROM df WHERE "med_dose_unit" IS NOT NULL
        """).fetchone()
        total = total_row[0]

        if total == 0:
            result.add_info("No non-null med_dose_unit values to check")
            con.close()
            return result

        if expect == 'per_time':
            violation_query = f"""
                SELECT COUNT(*) FROM df
                WHERE "med_dose_unit" IS NOT NULL AND NOT ({time_conditions})
            """
        else:
            violation_query = f"""
                SELECT COUNT(*) FROM df
                WHERE "med_dose_unit" IS NOT NULL AND ({time_conditions})
            """

        violations = con.execute(violation_query).fetchone()[0]
        pct = (violations / total * 100) if total > 0 else 0

        result.metrics["total_rows"] = int(total)
        result.metrics["unit_pattern_violations"] = int(violations)
        result.metrics["violation_percent"] = round(pct, 2)

        if violations > 0:
            if expect == 'per_time':
                warn_msg = f"Medication dose unit inconsistency: {violations}/{total} rows ({pct:.1f}%) use non-rate-based units unexpected for continuous administration"
            else:
                warn_msg = f"Medication dose unit inconsistency: {violations}/{total} rows ({pct:.1f}%) use rate-based units unexpected for intermittent administration"
            if pct > error_threshold:
                result.add_error(warn_msg, {"violations": int(violations), "total": int(total), "percent": round(pct, 2)})
            elif pct > warning_threshold:
                result.add_warning(warn_msg, {"violations": int(violations), "total": int(total), "percent": round(pct, 2)})
        else:
            if expect == 'per_time':
                result.add_info("All med_dose_unit values use rate-based units (e.g. mcg/kg/min) appropriate for continuous administration")
            else:
                result.add_info("All med_dose_unit values use dose-based units (e.g. mg, mL) appropriate for intermittent administration")

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'medication_dose_unit_consistency' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking medication dose unit consistency: {str(e)}")

    return result


def check_medication_dose_unit_consistency(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check medication dose unit consistency."""
    _logger.debug("check_medication_dose_unit_consistency: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_medication_dose_unit_consistency_polars(df, table_name,
                                                               warning_threshold=warning_threshold,
                                                               error_threshold=error_threshold)
    else:
        result = check_medication_dose_unit_consistency_duckdb(df, table_name,
                                                               warning_threshold=warning_threshold,
                                                               error_threshold=error_threshold)
    _logger.debug("check_medication_dose_unit_consistency: table '%s' — violations=%s",
                  table_name, result.metrics.get("unit_pattern_violations"))
    return result


# ---------------------------------------------------------------------------
# B.1 Cross-table temporal plausibility
# ---------------------------------------------------------------------------

def check_cross_table_temporal_plausibility_polars(
    target_df: Union['pl.DataFrame', 'pl.LazyFrame'],
    hospitalization_df: Union['pl.DataFrame', 'pl.LazyFrame'],
    target_table: str,
    time_columns: List[str],
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check that datetime values fall within hospitalization bounds using Polars."""
    result = DQAPlausibilityResult("cross_table_temporal", target_table)

    try:
        target_lf = target_df if isinstance(target_df, pl.LazyFrame) else target_df.lazy()
        hosp_lf = hospitalization_df if isinstance(hospitalization_df, pl.LazyFrame) else hospitalization_df.lazy()

        target_cols = target_lf.collect_schema().names()
        hosp_cols = hosp_lf.collect_schema().names()

        if 'hospitalization_id' not in target_cols or 'hospitalization_id' not in hosp_cols:
            result.add_info("Missing hospitalization_id column; skipping cross-table check")
            return result

        if 'admission_dttm' not in hosp_cols or 'discharge_dttm' not in hosp_cols:
            result.add_info("Missing admission/discharge columns in hospitalization table")
            return result

        hosp_bounds = hosp_lf.select([
            'hospitalization_id', 'admission_dttm', 'discharge_dttm'
        ])

        joined = target_lf.join(hosp_bounds, on='hospitalization_id', how='inner')
        violations_by_col = {}

        for time_col in time_columns:
            if time_col not in target_cols:
                continue

            applicable = joined.filter(
                pl.col(time_col).is_not_null() &
                pl.col('admission_dttm').is_not_null() &
                pl.col('discharge_dttm').is_not_null()
            )

            stats = applicable.select([
                pl.len().alias('total'),
                (pl.col(time_col) < pl.col('admission_dttm')).sum().alias('before_admission'),
                (pl.col(time_col) > pl.col('discharge_dttm')).sum().alias('after_discharge'),
            ]).collect(streaming=True)

            total = stats[0, 'total']
            before = stats[0, 'before_admission']
            after = stats[0, 'after_discharge']
            violation_total = before + after
            pct = (violation_total / total * 100) if total > 0 else 0

            violations_by_col[time_col] = {
                "total_joined": int(total),
                "before_admission": int(before),
                "after_discharge": int(after),
                "violation_count": int(violation_total),
                "violation_percent": round(pct, 2),
            }

            if pct > error_threshold:
                result.add_error(
                    f"Column '{time_col}': {violation_total}/{total} records ({pct:.1f}%) outside admission-to-discharge window ({before} before admission, {after} after discharge)",
                    {"column": time_col, "before_admission": int(before),
                     "after_discharge": int(after), "percent": round(pct, 2)}
                )
            elif pct > warning_threshold:
                result.add_warning(
                    f"Column '{time_col}': {violation_total}/{total} records ({pct:.1f}%) outside admission-to-discharge window ({before} before admission, {after} after discharge)",
                    {"column": time_col, "before_admission": int(before),
                     "after_discharge": int(after), "percent": round(pct, 2)}
                )
            else:
                result.add_info(
                    f"Column '{time_col}': all records within admission-to-discharge window",
                    {"column": time_col, "total_joined": int(total)}
                )

        result.metrics["time_columns_checked"] = list(violations_by_col.keys())
        result.metrics["violations_by_column"] = violations_by_col

        gc.collect()

    except Exception as e:
        _logger.error("Check 'cross_table_temporal' failed for table '%s': %s", target_table, e)
        result.add_error(f"Error checking cross-table temporal plausibility: {str(e)}")

    return result


def check_cross_table_temporal_plausibility_duckdb(
    target_df: pd.DataFrame,
    hospitalization_df: pd.DataFrame,
    target_table: str,
    time_columns: List[str],
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check that datetime values fall within hospitalization bounds using DuckDB."""
    result = DQAPlausibilityResult("cross_table_temporal", target_table)

    try:
        con = duckdb.connect(':memory:')
        con.register('target_tbl', target_df)
        con.register('hosp_tbl', hospitalization_df)

        if 'hospitalization_id' not in target_df.columns or 'hospitalization_id' not in hospitalization_df.columns:
            result.add_info("Missing hospitalization_id column; skipping cross-table check")
            con.close()
            return result

        if 'admission_dttm' not in hospitalization_df.columns or 'discharge_dttm' not in hospitalization_df.columns:
            result.add_info("Missing admission/discharge columns in hospitalization table")
            con.close()
            return result

        violations_by_col = {}

        for time_col in time_columns:
            if time_col not in target_df.columns:
                continue

            stats = con.execute(f"""
                SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN t."{time_col}" < h.admission_dttm THEN 1 ELSE 0 END) as before_admission,
                    SUM(CASE WHEN t."{time_col}" > h.discharge_dttm THEN 1 ELSE 0 END) as after_discharge
                FROM target_tbl t
                INNER JOIN hosp_tbl h ON t.hospitalization_id = h.hospitalization_id
                WHERE t."{time_col}" IS NOT NULL
                  AND h.admission_dttm IS NOT NULL
                  AND h.discharge_dttm IS NOT NULL
            """).fetchone()

            total, before, after = stats
            violation_total = before + after
            pct = (violation_total / total * 100) if total > 0 else 0

            violations_by_col[time_col] = {
                "total_joined": int(total),
                "before_admission": int(before),
                "after_discharge": int(after),
                "violation_count": int(violation_total),
                "violation_percent": round(pct, 2),
            }

            if pct > error_threshold:
                result.add_error(
                    f"Column '{time_col}': {violation_total}/{total} records ({pct:.1f}%) outside admission-to-discharge window ({before} before admission, {after} after discharge)",
                    {"column": time_col, "before_admission": int(before),
                     "after_discharge": int(after), "percent": round(pct, 2)}
                )
            elif pct > warning_threshold:
                result.add_warning(
                    f"Column '{time_col}': {violation_total}/{total} records ({pct:.1f}%) outside admission-to-discharge window ({before} before admission, {after} after discharge)",
                    {"column": time_col, "before_admission": int(before),
                     "after_discharge": int(after), "percent": round(pct, 2)}
                )
            else:
                result.add_info(
                    f"Column '{time_col}': all records within admission-to-discharge window",
                    {"column": time_col, "total_joined": int(total)}
                )

        result.metrics["time_columns_checked"] = list(violations_by_col.keys())
        result.metrics["violations_by_column"] = violations_by_col

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'cross_table_temporal' failed for table '%s': %s", target_table, e)
        result.add_error(f"Error checking cross-table temporal plausibility: {str(e)}")

    return result


def check_cross_table_temporal_plausibility(
    target_df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    hospitalization_df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    target_table: str,
    time_columns: List[str],
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check that datetime values fall within hospitalization bounds."""
    _logger.debug("check_cross_table_temporal_plausibility: starting for table '%s'", target_table)
    if _ACTIVE_BACKEND == 'polars':
        result = check_cross_table_temporal_plausibility_polars(
            target_df, hospitalization_df, target_table, time_columns,
            warning_threshold=warning_threshold, error_threshold=error_threshold)
    else:
        result = check_cross_table_temporal_plausibility_duckdb(
            target_df, hospitalization_df, target_table, time_columns,
            warning_threshold=warning_threshold, error_threshold=error_threshold)
    _logger.debug("check_cross_table_temporal_plausibility: table '%s' complete", target_table)
    return result


# ---------------------------------------------------------------------------
# C.1 Overlapping time periods
# ---------------------------------------------------------------------------

def check_overlapping_periods_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    entity_col: str = 'hospitalization_id',
    start_col: str = 'in_dttm',
    end_col: str = 'out_dttm',
) -> DQAPlausibilityResult:
    """Check for overlapping time periods within entities using Polars."""
    result = DQAPlausibilityResult("overlapping_periods", table_name)

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        if entity_col not in col_names or start_col not in col_names or end_col not in col_names:
            result.add_info(f"Required columns ({entity_col}, {start_col}, {end_col}) not all present")
            return result

        # Filter to rows where both start and end are non-null, sort, then compare with previous
        sorted_lf = lf.filter(
            pl.col(start_col).is_not_null() & pl.col(end_col).is_not_null()
        ).sort([entity_col, start_col])

        with_prev = sorted_lf.with_columns(
            pl.col(end_col).shift(1).over(entity_col).alias('_prev_end')
        )

        overlaps_df = with_prev.filter(
            pl.col('_prev_end').is_not_null() & (pl.col(start_col) < pl.col('_prev_end'))
        )

        total_records = sorted_lf.select(pl.len()).collect(streaming=True).item()
        overlap_count = overlaps_df.select(pl.len()).collect(streaming=True).item()
        entities_checked = sorted_lf.select(
            pl.col(entity_col).n_unique()
        ).collect(streaming=True).item()
        pct = (overlap_count / total_records * 100) if total_records > 0 else 0

        result.metrics["total_records"] = int(total_records)
        result.metrics["entities_checked"] = int(entities_checked)
        result.metrics["overlapping_records"] = int(overlap_count)
        result.metrics["overlap_percent"] = round(pct, 2)

        if overlap_count > 0:
            result.add_warning(
                f"{overlap_count} overlapping time periods detected ({pct:.1f}% of records)",
                {"column": f"{start_col}, {end_col}",
                 "overlapping_records": int(overlap_count), "percent": round(pct, 2)}
            )
        else:
            result.add_info(
                f"No overlapping time periods detected for {entity_col} on {start_col}/{end_col} — {int(total_records):,} records checked",
                {"column": f"{start_col}, {end_col}",
                 "entity_col": entity_col,
                 "records_checked": int(total_records),
                 "entities_checked": int(entities_checked)}
            )

        gc.collect()

    except Exception as e:
        _logger.error("Check 'overlapping_periods' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking overlapping periods: {str(e)}")

    return result


def check_overlapping_periods_duckdb(
    df: pd.DataFrame,
    table_name: str,
    entity_col: str = 'hospitalization_id',
    start_col: str = 'in_dttm',
    end_col: str = 'out_dttm',
) -> DQAPlausibilityResult:
    """Check for overlapping time periods within entities using DuckDB."""
    result = DQAPlausibilityResult("overlapping_periods", table_name)

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        if entity_col not in df.columns or start_col not in df.columns or end_col not in df.columns:
            result.add_info(f"Required columns ({entity_col}, {start_col}, {end_col}) not all present")
            con.close()
            return result

        stats = con.execute(f"""
            WITH filtered AS (
                SELECT * FROM df
                WHERE "{start_col}" IS NOT NULL AND "{end_col}" IS NOT NULL
            ),
            ordered AS (
                SELECT *,
                       LAG("{end_col}") OVER (
                           PARTITION BY "{entity_col}" ORDER BY "{start_col}"
                       ) AS prev_end
                FROM filtered
            )
            SELECT
                (SELECT COUNT(*) FROM filtered) as total_records,
                (SELECT COUNT(DISTINCT "{entity_col}") FROM filtered) as entities_checked,
                COUNT(*) as overlap_count
            FROM ordered
            WHERE prev_end IS NOT NULL AND "{start_col}" < prev_end
        """).fetchone()

        total_records, entities_checked, overlap_count = stats
        pct = (overlap_count / total_records * 100) if total_records > 0 else 0

        result.metrics["total_records"] = int(total_records)
        result.metrics["entities_checked"] = int(entities_checked)
        result.metrics["overlapping_records"] = int(overlap_count)
        result.metrics["overlap_percent"] = round(pct, 2)

        if overlap_count > 0:
            result.add_warning(
                f"{overlap_count} overlapping time periods detected ({pct:.1f}% of records)",
                {"column": f"{start_col}, {end_col}",
                 "overlapping_records": int(overlap_count), "percent": round(pct, 2)}
            )
        else:
            result.add_info(
                f"No overlapping time periods detected for {entity_col} on {start_col}/{end_col} — {int(total_records):,} records checked",
                {"column": f"{start_col}, {end_col}",
                 "entity_col": entity_col,
                 "records_checked": int(total_records),
                 "entities_checked": int(entities_checked)}
            )

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'overlapping_periods' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking overlapping periods: {str(e)}")

    return result


def check_overlapping_periods(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    entity_col: str = 'hospitalization_id',
    start_col: str = 'in_dttm',
    end_col: str = 'out_dttm',
) -> DQAPlausibilityResult:
    """Check for overlapping time periods within entities."""
    _logger.debug("check_overlapping_periods: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_overlapping_periods_polars(df, table_name, entity_col, start_col, end_col)
    else:
        result = check_overlapping_periods_duckdb(df, table_name, entity_col, start_col, end_col)
    _logger.debug("check_overlapping_periods: table '%s' — overlaps=%s",
                  table_name, result.metrics.get("overlapping_records"))
    return result


# ---------------------------------------------------------------------------
# C.2 Category temporal consistency
# ---------------------------------------------------------------------------

def _detect_time_column(col_names: List[str], table_name: str) -> Optional[str]:
    """Auto-detect the primary datetime column for a table."""
    candidates = ['recorded_dttm', 'admin_dttm', 'admission_dttm',
                   'lab_result_dttm', 'in_dttm', 'procedure_billed_dttm',
                   'result_dttm', 'start_dttm']
    for c in candidates:
        if c in col_names:
            return c
    return None


def check_category_temporal_consistency_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str,
    time_column: Optional[str] = None,
    hosp_years: Optional[set] = None,
) -> DQAPlausibilityResult:
    """Check category distribution consistency over time using Polars."""
    result = DQAPlausibilityResult("category_temporal_consistency", table_name)

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        if time_column is None:
            time_column = _detect_time_column(col_names, table_name)

        if time_column is None or time_column not in col_names:
            result.add_info("No suitable datetime column found for temporal consistency check")
            return result

        # Find category columns from schema
        category_columns = schema.get('category_columns') or []
        cat_cols_present = [c for c in category_columns if c in col_names]

        if not cat_cols_present:
            result.add_info("No category columns found for temporal consistency check")
            return result

        # Need hospitalization_id for unique ID counting
        id_col = 'hospitalization_id' if 'hospitalization_id' in col_names else (
            'patient_id' if 'patient_id' in col_names else None
        )

        yearly_distributions = {}
        missing_in_years = {}
        monthly_trends = {}

        for cat_col in cat_cols_present:
            # Get yearly distribution
            if id_col:
                yearly = (
                    lf.filter(pl.col(time_column).is_not_null() & pl.col(cat_col).is_not_null())
                    .with_columns(pl.col(time_column).dt.year().alias('_year'))
                    .group_by(['_year', cat_col])
                    .agg(pl.col(id_col).n_unique().alias('unique_ids'))
                    .sort(['_year', cat_col])
                    .collect(streaming=True)
                )
            else:
                yearly = (
                    lf.filter(pl.col(time_column).is_not_null() & pl.col(cat_col).is_not_null())
                    .with_columns(pl.col(time_column).dt.year().alias('_year'))
                    .group_by(['_year', cat_col])
                    .agg(pl.len().alias('unique_ids'))
                    .sort(['_year', cat_col])
                    .collect(streaming=True)
                )

            if len(yearly) == 0:
                continue

            # Build year -> {value: count} dict
            dist = {}
            all_years = set()
            all_values = set()
            for row in yearly.iter_rows(named=True):
                year = int(row['_year'])
                val = row[cat_col]
                count = row['unique_ids']
                all_years.add(year)
                all_values.add(val)
                dist.setdefault(year, {})[val] = int(count)

            yearly_distributions[cat_col] = dist

            # Check for values absent in some years (requires >= 2 years)
            if len(all_years) >= 2:
                absent = {}
                for val in all_values:
                    absent_years = [y for y in sorted(all_years) if val not in dist.get(y, {})]
                    if absent_years and len(absent_years) < len(all_years):
                        absent[str(val)] = absent_years
                if absent:
                    missing_in_years[cat_col] = absent

            # Monthly trends for CSV export
            num_col = _CATEGORY_TO_NUMERIC_MAP.get((table_name, cat_col))
            unit_col = _CATEGORY_UNIT_COL_MAP.get((table_name, cat_col))
            avg_expr = ([pl.col(num_col).mean().alias('avg')]
                        if num_col and num_col in col_names else [])

            group_cols = ['month_year', cat_col]
            if unit_col and unit_col in col_names:
                group_cols.append(unit_col)

            # n = unique hospitalization_ids (matches yearly distribution above and the
            # PDF YearlySparkBar sparklines). avg remains a row-weighted mean, so n and
            # avg use different denominators — n * avg does NOT approximate the sum of
            # values. For tables grouped by a unit column, a hospitalization recording
            # the same category in multiple units counts once per unit row.
            n_expr = (pl.col(id_col).n_unique() if id_col else pl.len()).alias('n')
            monthly = (
                lf.filter(pl.col(time_column).is_not_null() & pl.col(cat_col).is_not_null())
                .with_columns(pl.col(time_column).dt.strftime('%Y-%m').alias('month_year'))
                .group_by(group_cols)
                .agg([n_expr] + avg_expr)
                .sort(group_cols)
                .collect(streaming=True)
            )

            # For tables with schema-based units (no unit col in data), add unit column
            if num_col and num_col in col_names and not (unit_col and unit_col in col_names):
                schema_unit_map = _get_schema_units(schema, cat_col)
                if schema_unit_map:
                    monthly = monthly.with_columns(
                        pl.col(cat_col).replace_strict(
                            schema_unit_map, default=None
                        ).alias('unit')
                    )

            monthly_trends[cat_col] = monthly.to_dicts()

        result.metrics["category_columns_checked"] = len(cat_cols_present)
        result.metrics["yearly_distributions"] = yearly_distributions
        result.metrics["missing_in_years"] = missing_in_years
        result.metrics["monthly_trends"] = monthly_trends

        for cat_col, absent in missing_in_years.items():
            col_dist = yearly_distributions.get(cat_col, {})
            all_col_years = sorted(col_dist.keys())
            total_years = len(all_col_years)
            for val, years in absent.items():
                yearly_counts = {y: col_dist.get(y, {}).get(val, 0) for y in all_col_years}
                year_range = f"{all_col_years[0]}-{all_col_years[-1]}" if all_col_years else ""
                emit = result.add_info if cat_col == "organism_category" else result.add_warning
                emit(
                    f"{cat_col}: {val} absent in {len(years)}/{total_years} years ({year_range})",
                    {
                        "column": cat_col,
                        "value": val,
                        "absent_years": years,
                        "total_years": total_years,
                        "yearly_counts": yearly_counts,
                    }
                )

        if not result.warnings and not result.errors:
            for cat_col in cat_cols_present:
                dist = yearly_distributions.get(cat_col, {})
                n_years = len(dist)
                all_vals = {v for yr in dist.values() for v in yr}
                if n_years >= 2:
                    # Per-value info with yearly_counts for sparkline rendering
                    sorted_years = sorted(dist.keys())
                    year_range = f"{sorted_years[0]}-{sorted_years[-1]}"
                    for val in sorted(all_vals, key=str):
                        yearly_counts = {y: dist.get(y, {}).get(val, 0)
                                         for y in sorted_years}
                        n_present = sum(1 for c in yearly_counts.values() if c > 0)
                        msg = (f"{cat_col}: {val} present in "
                               f"{n_present}/{n_years} years ({year_range})")
                        result.add_info(msg, {
                            "column": cat_col,
                            "value": str(val),
                            "yearly_counts": yearly_counts,
                        })
                elif n_years == 1:
                    year = next(iter(dist))
                    n_values = len(all_vals)
                    sorted_vals = sorted(str(v) for v in all_vals)
                    if len(sorted_vals) > 5:
                        vals_str = ', '.join(sorted_vals[:5]) + f' ... ({n_values} total)'
                    else:
                        vals_str = ', '.join(sorted_vals)
                    msg = (f"{cat_col}: {vals_str} found "
                           f"(single year {year}, trend check requires 2+ years)")
                    result.add_info(msg, {"column": cat_col})
                else:
                    msg = f"No temporal data for {cat_col}"
                    result.add_info(msg, {"column": cat_col})

        gc.collect()

    except Exception as e:
        _logger.error("Check 'category_temporal_consistency' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking category temporal consistency: {str(e)}")

    return result


def check_category_temporal_consistency_duckdb(
    df: pd.DataFrame,
    schema: Dict[str, Any],
    table_name: str,
    time_column: Optional[str] = None,
    hosp_years: Optional[set] = None,
) -> DQAPlausibilityResult:
    """Check category distribution consistency over time using DuckDB."""
    result = DQAPlausibilityResult("category_temporal_consistency", table_name)

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)
        actual_cols = list(df.columns)

        if time_column is None:
            time_column = _detect_time_column(actual_cols, table_name)

        if time_column is None or time_column not in actual_cols:
            result.add_info("No suitable datetime column found for temporal consistency check")
            con.close()
            return result

        category_columns = schema.get('category_columns') or []
        cat_cols_present = [c for c in category_columns if c in actual_cols]

        if not cat_cols_present:
            result.add_info("No category columns found for temporal consistency check")
            con.close()
            return result

        id_col = 'hospitalization_id' if 'hospitalization_id' in actual_cols else (
            'patient_id' if 'patient_id' in actual_cols else None
        )

        yearly_distributions = {}
        missing_in_years = {}
        monthly_trends = {}

        for cat_col in cat_cols_present:
            if id_col:
                agg_expr = f'COUNT(DISTINCT "{id_col}") as unique_ids'
            else:
                agg_expr = 'COUNT(*) as unique_ids'

            rows = con.execute(f"""
                SELECT EXTRACT(YEAR FROM "{time_column}") as yr,
                       "{cat_col}",
                       {agg_expr}
                FROM df
                WHERE "{time_column}" IS NOT NULL AND "{cat_col}" IS NOT NULL
                GROUP BY yr, "{cat_col}"
                ORDER BY yr, "{cat_col}"
            """).fetchall()

            if not rows:
                continue

            dist = {}
            all_years = set()
            all_values = set()
            for row in rows:
                year = int(row[0])
                val = row[1]
                count = int(row[2])
                all_years.add(year)
                all_values.add(val)
                dist.setdefault(year, {})[val] = count

            yearly_distributions[cat_col] = dist

            if len(all_years) >= 2:
                absent = {}
                for val in all_values:
                    absent_years = [y for y in sorted(all_years) if val not in dist.get(y, {})]
                    if absent_years and len(absent_years) < len(all_years):
                        absent[str(val)] = absent_years
                if absent:
                    missing_in_years[cat_col] = absent

            # Monthly trends for CSV export
            num_col = _CATEGORY_TO_NUMERIC_MAP.get((table_name, cat_col))
            unit_col = _CATEGORY_UNIT_COL_MAP.get((table_name, cat_col))
            avg_select = f', AVG("{num_col}") as avg' if num_col and num_col in actual_cols else ''

            unit_select = ''
            unit_group = ''
            unit_order = ''
            if unit_col and unit_col in actual_cols:
                unit_select = f', "{unit_col}"'
                unit_group = f', "{unit_col}"'
                unit_order = f', "{unit_col}"'

            # n = unique hospitalization_ids (matches yearly distribution above and the
            # PDF YearlySparkBar sparklines). avg remains a row-weighted mean, so n and
            # avg use different denominators — n * avg does NOT approximate the sum of
            # values. For tables grouped by a unit column, a hospitalization recording
            # the same category in multiple units counts once per unit row.
            n_select = f'COUNT(DISTINCT "{id_col}") as n' if id_col else 'COUNT(*) as n'

            monthly_rows = con.execute(f"""
                SELECT STRFTIME(CAST("{time_column}" AS TIMESTAMP), '%Y-%m') as month_year,
                       "{cat_col}"{unit_select},
                       {n_select}
                       {avg_select}
                FROM df
                WHERE "{time_column}" IS NOT NULL AND "{cat_col}" IS NOT NULL
                GROUP BY month_year, "{cat_col}"{unit_group}
                ORDER BY month_year, "{cat_col}"{unit_order}
            """).fetchdf()

            # For tables with schema-based units (no unit col in data), add unit column
            if num_col and num_col in actual_cols and not (unit_col and unit_col in actual_cols):
                schema_unit_map = _get_schema_units(schema, cat_col)
                if schema_unit_map:
                    monthly_rows['unit'] = monthly_rows[cat_col].map(schema_unit_map)

            monthly_trends[cat_col] = monthly_rows.to_dict(orient='records')

        result.metrics["category_columns_checked"] = len(cat_cols_present)
        result.metrics["yearly_distributions"] = yearly_distributions
        result.metrics["missing_in_years"] = missing_in_years
        result.metrics["monthly_trends"] = monthly_trends

        for cat_col, absent in missing_in_years.items():
            col_dist = yearly_distributions.get(cat_col, {})
            all_col_years = sorted(col_dist.keys())
            total_years = len(all_col_years)
            for val, years in absent.items():
                yearly_counts = {y: col_dist.get(y, {}).get(val, 0) for y in all_col_years}
                year_range = f"{all_col_years[0]}-{all_col_years[-1]}" if all_col_years else ""
                emit = result.add_info if cat_col == "organism_category" else result.add_warning
                emit(
                    f"{cat_col}: {val} absent in {len(years)}/{total_years} years ({year_range})",
                    {
                        "column": cat_col,
                        "value": val,
                        "absent_years": years,
                        "total_years": total_years,
                        "yearly_counts": yearly_counts,
                    }
                )

        if not result.warnings and not result.errors:
            for cat_col in cat_cols_present:
                dist = yearly_distributions.get(cat_col, {})
                n_years = len(dist)
                all_vals = {v for yr in dist.values() for v in yr}
                if n_years >= 2:
                    # Per-value info with yearly_counts for sparkline rendering
                    sorted_years = sorted(dist.keys())
                    year_range = f"{sorted_years[0]}-{sorted_years[-1]}"
                    for val in sorted(all_vals, key=str):
                        yearly_counts = {y: dist.get(y, {}).get(val, 0)
                                         for y in sorted_years}
                        n_present = sum(1 for c in yearly_counts.values() if c > 0)
                        msg = (f"{cat_col}: {val} present in "
                               f"{n_present}/{n_years} years ({year_range})")
                        result.add_info(msg, {
                            "column": cat_col,
                            "value": str(val),
                            "yearly_counts": yearly_counts,
                        })
                elif n_years == 1:
                    year = next(iter(dist))
                    n_values = len(all_vals)
                    sorted_vals = sorted(str(v) for v in all_vals)
                    if len(sorted_vals) > 5:
                        vals_str = ', '.join(sorted_vals[:5]) + f' ... ({n_values} total)'
                    else:
                        vals_str = ', '.join(sorted_vals)
                    msg = (f"{cat_col}: {vals_str} found "
                           f"(single year {year}, trend check requires 2+ years)")
                    result.add_info(msg, {"column": cat_col})
                else:
                    msg = f"No temporal data for {cat_col}"
                    result.add_info(msg, {"column": cat_col})

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'category_temporal_consistency' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking category temporal consistency: {str(e)}")

    return result


def check_category_temporal_consistency(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str,
    time_column: Optional[str] = None,
    hosp_years: Optional[set] = None,
) -> DQAPlausibilityResult:
    """Check category distribution consistency over time."""
    _logger.debug("check_category_temporal_consistency: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_category_temporal_consistency_polars(df, schema, table_name, time_column, hosp_years)
    else:
        result = check_category_temporal_consistency_duckdb(df, schema, table_name, time_column, hosp_years)
    _logger.debug("check_category_temporal_consistency: table '%s' — columns_checked=%s",
                  table_name, result.metrics.get("category_columns_checked"))
    return result


# ---------------------------------------------------------------------------
# D.1 Duplicate composite keys
# ---------------------------------------------------------------------------

def check_duplicate_composite_keys_polars(
    df: Union['pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    composite_keys: Optional[List[str]] = None,
    schema: Optional[Dict[str, Any]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check for duplicate composite keys using Polars."""
    result = DQAPlausibilityResult("duplicate_composite_keys", table_name)

    if composite_keys is None:
        composite_keys = _get_composite_keys(table_name, schema)

    if not composite_keys:
        result.add_info("No composite keys defined for this table")
        return result

    try:
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        col_names = lf.collect_schema().names()

        # Verify all key columns exist
        missing_keys = [k for k in composite_keys if k not in col_names]
        if missing_keys:
            result.add_info(f"Composite key columns missing: {missing_keys}")
            return result

        total = lf.select(pl.len()).collect(streaming=True).item()
        unique = (
            lf.group_by(composite_keys)
            .agg(pl.len().alias('_n'))
            .select(pl.len())
            .collect(streaming=True)
            .item()
        )
        duplicates = total - unique
        pct = (duplicates / total * 100) if total > 0 else 0

        result.metrics["composite_keys"] = composite_keys
        result.metrics["total_records"] = int(total)
        result.metrics["unique_records"] = int(unique)
        result.metrics["duplicate_records"] = int(duplicates)
        result.metrics["duplicate_percent"] = round(pct, 2)

        keys_str = ', '.join(composite_keys)
        if pct > error_threshold:
            result.add_error(
                f"{duplicates} duplicate records ({pct:.1f}%) on composite key ({keys_str}) in {table_name}",
                {"duplicate_records": int(duplicates), "percent": round(pct, 2),
                 "keys": composite_keys}
            )
        elif pct > warning_threshold:
            result.add_warning(
                f"{duplicates} duplicate records ({pct:.1f}%) on composite key ({keys_str}) in {table_name}",
                {"duplicate_records": int(duplicates), "percent": round(pct, 2),
                 "keys": composite_keys}
            )
        else:
            result.add_info("No duplicate composite keys found")

        gc.collect()

    except Exception as e:
        _logger.error("Check 'duplicate_composite_keys' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking duplicate composite keys: {str(e)}")

    return result


def check_duplicate_composite_keys_duckdb(
    df: pd.DataFrame,
    table_name: str,
    composite_keys: Optional[List[str]] = None,
    schema: Optional[Dict[str, Any]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check for duplicate composite keys using DuckDB."""
    result = DQAPlausibilityResult("duplicate_composite_keys", table_name)

    if composite_keys is None:
        composite_keys = _get_composite_keys(table_name, schema)

    if not composite_keys:
        result.add_info("No composite keys defined for this table")
        return result

    try:
        con = duckdb.connect(':memory:')
        con.register('df', df)

        missing_keys = [k for k in composite_keys if k not in df.columns]
        if missing_keys:
            result.add_info(f"Composite key columns missing: {missing_keys}")
            con.close()
            return result

        key_cols_str = ', '.join([f'"{k}"' for k in composite_keys])
        stats = con.execute(f"""
            SELECT
                (SELECT COUNT(*) FROM df) as total,
                (SELECT COUNT(*) FROM (SELECT DISTINCT {key_cols_str} FROM df)) as unique_count
        """).fetchone()

        total, unique = stats
        duplicates = total - unique
        pct = (duplicates / total * 100) if total > 0 else 0

        result.metrics["composite_keys"] = composite_keys
        result.metrics["total_records"] = int(total)
        result.metrics["unique_records"] = int(unique)
        result.metrics["duplicate_records"] = int(duplicates)
        result.metrics["duplicate_percent"] = round(pct, 2)

        keys_str = ', '.join(composite_keys)
        if pct > error_threshold:
            result.add_error(
                f"{duplicates} duplicate records ({pct:.1f}%) on composite key ({keys_str}) in {table_name}",
                {"duplicate_records": int(duplicates), "percent": round(pct, 2),
                 "keys": composite_keys}
            )
        elif pct > warning_threshold:
            result.add_warning(
                f"{duplicates} duplicate records ({pct:.1f}%) on composite key ({keys_str}) in {table_name}",
                {"duplicate_records": int(duplicates), "percent": round(pct, 2),
                 "keys": composite_keys}
            )
        else:
            result.add_info("No duplicate composite keys found")

        con.close()
        gc.collect()

    except Exception as e:
        _logger.error("Check 'duplicate_composite_keys' failed for table '%s': %s", table_name, e)
        result.add_error(f"Error checking duplicate composite keys: {str(e)}")

    return result


def check_duplicate_composite_keys(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    table_name: str,
    composite_keys: Optional[List[str]] = None,
    schema: Optional[Dict[str, Any]] = None,
    warning_threshold: float = 0.0,
    error_threshold: float = 10.0,
) -> DQAPlausibilityResult:
    """Check for duplicate composite keys."""
    _logger.debug("check_duplicate_composite_keys: starting for table '%s'", table_name)
    if _ACTIVE_BACKEND == 'polars':
        result = check_duplicate_composite_keys_polars(df, table_name, composite_keys, schema,
                                                       warning_threshold=warning_threshold,
                                                       error_threshold=error_threshold)
    else:
        result = check_duplicate_composite_keys_duckdb(df, table_name, composite_keys, schema,
                                                       warning_threshold=warning_threshold,
                                                       error_threshold=error_threshold)
    _logger.debug("check_duplicate_composite_keys: table '%s' — duplicates=%s",
                  table_name, result.metrics.get("duplicate_records"))
    return result
# ---------------------------------------------------------------------------
# COMPREHENSIVE DQA RUNNER
# ---------------------------------------------------------------------------

def run_conformance_checks(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str
) -> Dict[str, DQAConformanceResult]:
    """
    Run all conformance checks on a table.

    Parameters
    ----------
    df : DataFrame
        The data to validate
    schema : dict
        Schema for the table
    table_name : str
        Name of the table

    Returns
    -------
    Dict[str, DQAConformanceResult]
        Dictionary of check results keyed by check type
    """
    _logger.info("Running conformance checks for table '%s' using %s backend", table_name, _ACTIVE_BACKEND)

    # Convert pandas DataFrame to Polars if the active backend is Polars
    if _ACTIVE_BACKEND == 'polars' and isinstance(df, pd.DataFrame):
        _logger.debug("Converting pandas DataFrame to Polars for table '%s'", table_name)
        df = pl.from_pandas(df)

    results = {}

    results['table_presence'] = check_table_presence(df, table_name)
    gc.collect()

    results['required_columns'] = check_required_columns(df, schema, table_name)
    gc.collect()

    results['column_dtypes'] = check_column_dtypes(df, schema, table_name)
    gc.collect()

    results['datetime_format'] = check_datetime_format(df, schema, table_name)
    gc.collect()

    if table_name == 'labs':
        results['lab_reference_units'] = check_lab_reference_units(df, schema, table_name)
        gc.collect()

    results['categorical_values'] = check_categorical_values(df, schema, table_name)
    gc.collect()

    results['category_group_mapping'] = check_category_group_mapping(df, schema, table_name)
    gc.collect()

    passed = sum(1 for r in results.values() if r.passed)
    failed = len(results) - passed
    _logger.info("Conformance checks complete for '%s': %d passed, %d failed", table_name, passed, failed)

    return results


def run_completeness_checks(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str,
    error_threshold: float = 50.0,
    warning_threshold: float = 10.0
) -> Dict[str, DQACompletenessResult]:
    """
    Run all completeness checks on a table.

    Parameters
    ----------
    df : DataFrame
        The data to validate
    schema : dict
        Schema for the table
    table_name : str
        Name of the table
    error_threshold : float
        Percent missing above which an error is raised
    warning_threshold : float
        Percent missing above which a warning is raised

    Returns
    -------
    Dict[str, DQACompletenessResult]
        Dictionary of check results keyed by check type
    """
    _logger.info("Running completeness checks for table '%s' using %s backend", table_name, _ACTIVE_BACKEND)

    # Convert pandas DataFrame to Polars if the active backend is Polars
    if _ACTIVE_BACKEND == 'polars' and isinstance(df, pd.DataFrame):
        _logger.debug("Converting pandas DataFrame to Polars for table '%s'", table_name)
        df = pl.from_pandas(df)

    results = {}

    results['missingness'] = check_missingness(
        df, schema, table_name, error_threshold, warning_threshold
    )
    gc.collect()

    results['conditional_requirements'] = check_conditional_requirements(df, table_name)
    gc.collect()

    results['mcide_value_coverage'] = check_mcide_value_coverage(df, schema, table_name)
    gc.collect()

    passed = sum(1 for r in results.values() if r.passed)
    failed = len(results) - passed
    _logger.info("Completeness checks complete for '%s': %d passed, %d failed", table_name, passed, failed)

    return results


def run_relational_integrity_checks(
    tables: list,
) -> Dict[str, Dict[str, DQACompletenessResult]]:
    """Auto-detect and run relational integrity checks for loaded tables.

    Reads FK rules from ``validation_rules.yaml`` and runs
    :func:`check_relational_integrity` for every applicable
    (table, fk_column) pair.

    Parameters
    ----------
    tables : list
        Objects with ``.table_name`` (str) and ``.df`` (DataFrame)
        attributes — typically :class:`BaseTable` instances.

    Returns
    -------
    Dict[str, Dict[str, DQACompletenessResult]]
        ``{table_name: {fk_column: DQACompletenessResult}}``.
    """
    _logger.info("run_relational_integrity_checks: starting with %d tables", len(tables))

    # Build lookup: table_name -> (DataFrame, schema_col_names)
    # Convert pandas DataFrames to Polars when the Polars backend is active,
    # matching the pattern used by run_conformance_checks / run_completeness_checks.
    lookup = {}
    for obj in tables:
        df = obj.df
        if _ACTIVE_BACKEND == 'polars' and isinstance(df, pd.DataFrame):
            _logger.debug("Converting pandas DataFrame to Polars for table '%s'", obj.table_name)
            df = pl.from_pandas(df)
        # Extract schema-defined column names (only check FK columns that belong
        # to the table's schema, not extra columns that happen to be in the data).
        schema = getattr(obj, 'schema', None) or {}
        schema_cols = {c['name'] for c in schema.get('columns', [])} if schema.get('columns') else None
        lookup[obj.table_name] = (df, schema_cols)

    # Load FK rules
    fk_rules = _load_validation_rules().get('relational_integrity', {})
    _logger.debug("run_relational_integrity_checks: loaded %d FK rules", len(fk_rules))

    results: Dict[str, Dict[str, DQACompletenessResult]] = {}

    for table_name, (df, schema_cols) in lookup.items():
        # Use schema columns when available; fall back to DataFrame columns
        if schema_cols is not None:
            col_names = schema_cols
        elif HAS_POLARS and isinstance(df, (pl.DataFrame, pl.LazyFrame)):
            lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
            col_names = set(lf.collect_schema().names())
        else:
            col_names = set(df.columns.tolist())

        for fk_column, rule in fk_rules.items():
            if fk_column not in col_names:
                continue

            ref_table_name = rule['references_table']

            # Skip self-references
            if ref_table_name == table_name:
                _logger.debug(
                    "run_relational_integrity_checks: skipping self-ref "
                    "%s.%s -> %s", table_name, fk_column, ref_table_name,
                )
                continue

            # Skip if the reference table isn't loaded
            if ref_table_name not in lookup:
                _logger.debug(
                    "run_relational_integrity_checks: skipping %s.%s — "
                    "reference table '%s' not loaded",
                    table_name, fk_column, ref_table_name,
                )
                continue

            _logger.info(
                "run_relational_integrity_checks: checking %s.%s -> %s",
                table_name, fk_column, ref_table_name,
            )
            result = check_relational_integrity(
                target_df=df,
                reference_df=lookup[ref_table_name][0],
                target_table=table_name,
                reference_table=ref_table_name,
                key_column=fk_column,
            )
            results.setdefault(table_name, {})[fk_column] = result

    checked = sum(len(v) for v in results.values())
    _logger.info(
        "run_relational_integrity_checks: completed %d checks across %d tables",
        checked, len(results),
    )
    return results


# ---------------------------------------------------------------------------
# CACHE-BASED CROSS-TABLE FUNCTIONS (memory-optimised pipeline)
# ---------------------------------------------------------------------------


def extract_cross_table_cache(table_obj) -> Dict[str, Any]:
    """Extract a lightweight cache from a single table object.

    Used by the optimised pipeline in CLIF-TableOne's runner to avoid
    keeping full DataFrames in memory for cross-table checks.

    Parameters
    ----------
    table_obj : BaseTable
        Object with ``.table_name``, ``.df``, and ``.schema`` attributes.

    Returns
    -------
    dict
        Keys: ``table_name``, ``fk_ids``, ``schema_cols``,
        ``temporal_df``, ``hosp_bounds_df``, ``hosp_years``.
    """
    tname = getattr(table_obj, 'table_name', '').replace('clif_', '')
    df = table_obj.df
    schema = getattr(table_obj, 'schema', None) or {}

    # Schema-defined column names
    schema_cols = (
        {c['name'] for c in schema.get('columns', [])}
        if schema.get('columns') else None
    )

    # Determine actual columns in the DataFrame
    if HAS_POLARS and isinstance(df, (pl.DataFrame, pl.LazyFrame)):
        lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
        actual_cols = set(lf.collect_schema().names())
    else:
        actual_cols = set(df.columns.tolist())

    # Use schema cols when available; fall back to actual cols
    col_names = schema_cols if schema_cols is not None else actual_cols

    # --- FK ID sets ---
    fk_rules = _load_validation_rules().get('relational_integrity', {})
    fk_ids: Dict[str, set] = {}
    for fk_column in fk_rules:
        if fk_column not in col_names or fk_column not in actual_cols:
            continue
        if HAS_POLARS and isinstance(df, (pl.DataFrame, pl.LazyFrame)):
            lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
            id_series = (
                lf.select(pl.col(fk_column).drop_nulls().unique())
                .collect(streaming=True)
            )
            fk_ids[fk_column] = set(id_series[fk_column].to_list())
        else:
            fk_ids[fk_column] = set(df[fk_column].dropna().unique().tolist())

    # --- Temporal subset for cross-table plausibility ---
    time_cols = _CROSS_TABLE_TIME_COLUMNS.get(tname, [])
    temporal_df = None
    if time_cols and 'hospitalization_id' in actual_cols:
        needed = ['hospitalization_id'] + [c for c in time_cols if c in actual_cols]
        if HAS_POLARS and isinstance(df, (pl.DataFrame, pl.LazyFrame)):
            lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
            temporal_df = lf.select(needed).collect()
        else:
            temporal_df = df[needed].copy()

    # --- Hospitalization-specific caches ---
    hosp_bounds_df = None
    hosp_years = None
    if tname == 'hospitalization':
        if HAS_POLARS and isinstance(df, (pl.DataFrame, pl.LazyFrame)):
            lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
            hosp_cols_available = set(lf.collect_schema().names())
            bound_cols = [c for c in ['hospitalization_id', 'admission_dttm', 'discharge_dttm']
                          if c in hosp_cols_available]
            if 'hospitalization_id' in bound_cols:
                hosp_bounds_df = lf.select(bound_cols).collect()
            if 'admission_dttm' in hosp_cols_available:
                hosp_years = set(
                    lf.select(pl.col('admission_dttm').dt.year().alias('yr'))
                    .filter(pl.col('yr').is_not_null())
                    .unique()
                    .collect()
                    .get_column('yr')
                    .to_list()
                )
        elif isinstance(df, pd.DataFrame):
            bound_cols = [c for c in ['hospitalization_id', 'admission_dttm', 'discharge_dttm']
                          if c in df.columns]
            if 'hospitalization_id' in bound_cols:
                hosp_bounds_df = df[bound_cols].copy()
            if 'admission_dttm' in df.columns:
                hosp_years = set(
                    int(y) for y in df['admission_dttm'].dropna().dt.year.unique()
                )

    # --- Cross-table conditional requirements cache ---
    ct_cond_rules = _load_validation_rules().get('cross_table_conditional_requirements', [])
    conditional_source_ids: Dict[str, set] = {}
    conditional_target_ids: Dict[str, set] = {}

    for rule in ct_cond_rules:
        rule_key = f"{rule['source_column']}_{rule['target_column']}"
        join_col = rule['join_column']

        if tname == rule['source_table'] and join_col in actual_cols and rule['source_column'] in actual_cols:
            # Extract join_column IDs where source_column matches source_value (case-insensitive)
            match_values = [str(v).strip().lower() for v in rule['source_value']]
            if HAS_POLARS and isinstance(df, (pl.DataFrame, pl.LazyFrame)):
                lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
                matched = (
                    lf.filter(
                        pl.col(rule['source_column']).cast(pl.Utf8).str.strip_chars().str.to_lowercase().is_in(match_values)
                    )
                    .select(pl.col(join_col).drop_nulls().unique())
                    .collect(streaming=True)
                )
                conditional_source_ids[rule_key] = set(matched[join_col].to_list())
            else:
                mask = df[rule['source_column']].astype(str).str.strip().str.lower().isin(match_values)
                conditional_source_ids[rule_key] = set(df.loc[mask, join_col].dropna().unique().tolist())

        if tname == rule['target_table'] and join_col in actual_cols and rule['target_column'] in actual_cols:
            # Extract join_column IDs where target_column is not null (and not empty string)
            if HAS_POLARS and isinstance(df, (pl.DataFrame, pl.LazyFrame)):
                lf = df if isinstance(df, pl.LazyFrame) else df.lazy()
                tcol = pl.col(rule['target_column'])
                # Handle both datetime and string columns: not null AND not empty string
                not_null_filter = tcol.is_not_null()
                dtype = lf.collect_schema()[rule['target_column']]
                if dtype == pl.Utf8 or dtype == pl.String:
                    not_null_filter = not_null_filter & (tcol.str.strip_chars().str.len_chars() > 0)
                matched = (
                    lf.filter(not_null_filter)
                    .select(pl.col(join_col).drop_nulls().unique())
                    .collect(streaming=True)
                )
                conditional_target_ids[rule_key] = set(matched[join_col].to_list())
            else:
                target_col = df[rule['target_column']]
                mask = target_col.notna()
                # If string dtype, also exclude empty/whitespace-only strings
                if hasattr(target_col, 'str') and target_col.dtype == 'object':
                    mask = mask & (target_col.astype(str).str.strip() != '')
                conditional_target_ids[rule_key] = set(df.loc[mask, join_col].dropna().unique().tolist())

    cache = {
        'table_name': tname,
        'fk_ids': fk_ids,
        'schema_cols': schema_cols,
        'temporal_df': temporal_df,
        'hosp_bounds_df': hosp_bounds_df,
        'hosp_years': hosp_years,
        'conditional_source_ids': conditional_source_ids,
        'conditional_target_ids': conditional_target_ids,
    }
    _logger.info(
        "extract_cross_table_cache: table='%s', fk_keys=%s, temporal=%s, hosp_bounds=%s, "
        "cond_source_keys=%s, cond_target_keys=%s",
        tname, list(fk_ids.keys()), temporal_df is not None, hosp_bounds_df is not None,
        list(conditional_source_ids.keys()), list(conditional_target_ids.keys()),
    )
    return cache


def run_relational_integrity_checks_from_cache(
    caches: Dict[str, Dict[str, Any]],
) -> Dict[str, Dict[str, DQACompletenessResult]]:
    """Run relational integrity checks using pre-extracted caches.

    Equivalent to :func:`run_relational_integrity_checks` but operates on
    Python ``set`` objects (FK ID sets) instead of scanning full DataFrames.

    Parameters
    ----------
    caches : dict
        ``{table_name: cache_dict}`` as returned by
        :func:`extract_cross_table_cache`.

    Returns
    -------
    Dict[str, Dict[str, DQACompletenessResult]]
        Same structure as :func:`run_relational_integrity_checks`.
    """
    _logger.info(
        "run_relational_integrity_checks_from_cache: starting with %d cached tables",
        len(caches),
    )

    fk_rules = _load_validation_rules().get('relational_integrity', {})
    results: Dict[str, Dict[str, DQACompletenessResult]] = {}

    for table_name, cache in caches.items():
        col_names = cache['schema_cols'] if cache['schema_cols'] is not None else set(cache['fk_ids'].keys())

        for fk_column, rule in fk_rules.items():
            if fk_column not in col_names:
                continue

            ref_table_name = rule['references_table']

            if ref_table_name == table_name:
                continue

            if ref_table_name not in caches:
                _logger.debug(
                    "run_relational_integrity_checks_from_cache: skipping %s.%s — "
                    "reference table '%s' not cached",
                    table_name, fk_column, ref_table_name,
                )
                continue

            # Get the FK ID sets
            source_ids = cache['fk_ids'].get(fk_column)
            if source_ids is None:
                continue

            ref_cache = caches[ref_table_name]
            ref_ids = ref_cache['fk_ids'].get(fk_column)
            if ref_ids is None:
                # Reference table doesn't have this FK column cached — skip
                continue

            _logger.info(
                "run_relational_integrity_checks_from_cache: checking %s.%s -> %s",
                table_name, fk_column, ref_table_name,
            )

            # Build the bidirectional result (same structure as check_relational_integrity)
            result = DQACompletenessResult(
                "relational_integrity",
                f"{table_name}<->{ref_table_name}",
            )

            try:
                # Forward: reference -> target (source=ref, ref=target)
                fwd_orphans = ref_ids - source_ids
                fwd_total = len(ref_ids)
                fwd_orphan_count = len(fwd_orphans)
                fwd_coverage = ((fwd_total - fwd_orphan_count) / fwd_total * 100) if fwd_total > 0 else 100

                # Reverse: target -> reference (source=target, ref=reference)
                rev_orphans = source_ids - ref_ids
                rev_total = len(source_ids)
                rev_orphan_count = len(rev_orphans)
                rev_coverage = ((rev_total - rev_orphan_count) / rev_total * 100) if rev_total > 0 else 100

                result.metrics["forward_coverage_percent"] = round(fwd_coverage, 2)
                result.metrics["forward_orphan_ids"] = fwd_orphan_count
                result.metrics["forward_reference_unique_ids"] = fwd_total
                result.metrics["reverse_coverage_percent"] = round(rev_coverage, 2)
                result.metrics["reverse_orphan_ids"] = rev_orphan_count
                result.metrics["reverse_target_unique_ids"] = rev_total

                # Forward warnings/errors
                if fwd_orphans:
                    result.add_warning(
                        f"{fwd_orphan_count}/{fwd_total} {fk_column} values in {ref_table_name} "
                        f"not found in {table_name} ({round(fwd_coverage, 1)}% coverage)",
                        {"orphan_count": fwd_orphan_count,
                         "coverage_percent": round(fwd_coverage, 2)}
                    )

                # Reverse warnings/errors
                if rev_orphans:
                    result.add_warning(
                        f"{rev_orphan_count}/{rev_total} {fk_column} values in {table_name} "
                        f"not found in {ref_table_name} ({round(rev_coverage, 1)}% coverage)",
                        {"orphan_count": rev_orphan_count,
                         "coverage_percent": round(rev_coverage, 2)}
                    )

                if not fwd_orphans and not rev_orphans:
                    result.add_info(
                        f"Full bidirectional coverage for {fk_column} between "
                        f"{table_name} and {ref_table_name}"
                    )

                _logger.info(
                    "run_relational_integrity_checks_from_cache: '%s' <-> '%s' — "
                    "fwd_coverage=%.1f%%, rev_coverage=%.1f%%",
                    table_name, ref_table_name, fwd_coverage, rev_coverage,
                )

            except Exception as e:
                _logger.error(
                    "Cached relational check failed for '%s' <-> '%s': %s",
                    table_name, ref_table_name, e,
                )
                result.add_error(f"Error checking relational integrity: {str(e)}")

            results.setdefault(table_name, {})[fk_column] = result

    checked = sum(len(v) for v in results.values())
    _logger.info(
        "run_relational_integrity_checks_from_cache: completed %d checks across %d tables",
        checked, len(results),
    )
    return results


def run_cross_table_completeness_checks_from_cache(
    caches: Dict[str, Dict[str, Any]],
) -> Dict[str, Dict[str, DQACompletenessResult]]:
    """Run cross-table conditional completeness checks (K.5) from caches.

    For each YAML rule in ``cross_table_conditional_requirements``, computes
    the set of join-column IDs that satisfy the source condition but are
    missing the required target column value.

    Parameters
    ----------
    caches : dict
        ``{table_name: cache_dict}`` as returned by
        :func:`extract_cross_table_cache`.

    Returns
    -------
    Dict[str, Dict[str, DQACompletenessResult]]
        Results keyed by **target** table name, then by a descriptive
        check key.
    """
    _logger.info(
        "run_cross_table_completeness_checks_from_cache: starting with %d cached tables",
        len(caches),
    )

    ct_cond_rules = _load_validation_rules().get('cross_table_conditional_requirements', [])
    if not ct_cond_rules:
        return {}

    results: Dict[str, Dict[str, DQACompletenessResult]] = {}

    for rule in ct_cond_rules:
        rule_key = f"{rule['source_column']}_{rule['target_column']}"
        source_table = rule['source_table']
        target_table = rule['target_table']

        # Both tables must be cached
        if source_table not in caches or target_table not in caches:
            _logger.debug(
                "K.5: skipping rule '%s' — source '%s' or target '%s' not cached",
                rule_key, source_table, target_table,
            )
            continue

        source_cache = caches[source_table]
        target_cache = caches[target_table]

        source_ids = source_cache.get('conditional_source_ids', {}).get(rule_key)
        target_ids = target_cache.get('conditional_target_ids', {}).get(rule_key)

        result = DQACompletenessResult(
            "cross_table_conditional_completeness",
            f"{source_table}->{target_table}",
        )

        if source_ids is None or target_ids is None:
            result.add_info(
                "No cross-table conditional requirements applicable"
            )
            results.setdefault(target_table, {})[rule_key] = result
            continue

        if not source_ids:
            result.add_info(
                f"No {rule['source_column']} = {rule['source_value']} found in "
                f"{source_table}; cross-table conditional check not triggered"
            )
            results.setdefault(target_table, {})[rule_key] = result
            continue

        missing_ids = source_ids - target_ids
        total = len(source_ids)
        missing_count = len(missing_ids)
        pct = round(missing_count / total * 100, 1) if total > 0 else 0

        result.metrics["total_matching_source"] = total
        result.metrics["missing_in_target"] = missing_count
        result.metrics["coverage_percent"] = round(100 - pct, 2)

        if missing_ids:
            sample = sorted(list(missing_ids))[:10]
            result.add_warning(
                f"{missing_count}/{total} patients discharged as {rule['source_value']} "
                f"in {source_table} are missing {rule['target_column']} in {target_table} "
                f"({pct}% missing)",
                {
                    "column": rule['target_column'],
                    "missing_count": missing_count,
                    "total_matching": total,
                    "percent_missing": pct,
                    "sample_ids": sample,
                    "source_condition": f"{rule['source_column']} in {rule['source_value']}",
                },
            )
        else:
            result.add_info(
                f"All {total} patients discharged as {rule['source_value']} in "
                f"{source_table} have {rule['target_column']} in {target_table}"
            )

        results.setdefault(target_table, {})[rule_key] = result
        _logger.info(
            "K.5: %s->%s rule '%s': %d/%d missing (%.1f%%)",
            source_table, target_table, rule_key, missing_count, total, pct,
        )

    checked = sum(len(v) for v in results.values())
    _logger.info(
        "run_cross_table_completeness_checks_from_cache: completed %d checks across %d tables",
        checked, len(results),
    )
    return results


def run_cross_table_completeness_checks(
    tables: list,
) -> Dict[str, Dict[str, DQACompletenessResult]]:
    """Run cross-table conditional completeness checks (K.5) on full DataFrames.

    Parameters
    ----------
    tables : list
        Objects with ``.table_name`` and ``.df`` attributes.

    Returns
    -------
    Dict[str, Dict[str, DQACompletenessResult]]
        Results keyed by **target** table name.
    """
    _logger.info("run_cross_table_completeness_checks: starting with %d tables", len(tables))

    ct_cond_rules = _load_validation_rules().get('cross_table_conditional_requirements', [])
    if not ct_cond_rules:
        return {}

    lookup = {}
    for obj in tables:
        tname = getattr(obj, 'table_name', '').replace('clif_', '')
        tdf = obj.df
        if _ACTIVE_BACKEND == 'polars' and isinstance(tdf, pd.DataFrame):
            tdf = pl.from_pandas(tdf)
        lookup[tname] = tdf

    results: Dict[str, Dict[str, DQACompletenessResult]] = {}

    for rule in ct_cond_rules:
        rule_key = f"{rule['source_column']}_{rule['target_column']}"
        source_table = rule['source_table']
        target_table = rule['target_table']
        join_col = rule['join_column']

        if source_table not in lookup or target_table not in lookup:
            continue

        src_df = lookup[source_table]
        tgt_df = lookup[target_table]
        match_values = [str(v).strip().lower() for v in rule['source_value']]

        # Get source IDs matching condition
        if HAS_POLARS and isinstance(src_df, (pl.DataFrame, pl.LazyFrame)):
            lf = src_df if isinstance(src_df, pl.LazyFrame) else src_df.lazy()
            if rule['source_column'] not in lf.collect_schema().names() or join_col not in lf.collect_schema().names():
                continue
            matched = (
                lf.filter(
                    pl.col(rule['source_column']).cast(pl.Utf8).str.strip_chars().str.to_lowercase().is_in(match_values)
                )
                .select(pl.col(join_col).drop_nulls().unique())
                .collect(streaming=True)
            )
            source_ids = set(matched[join_col].to_list())
        else:
            if rule['source_column'] not in src_df.columns or join_col not in src_df.columns:
                continue
            mask = src_df[rule['source_column']].astype(str).str.strip().str.lower().isin(match_values)
            source_ids = set(src_df.loc[mask, join_col].dropna().unique().tolist())

        # Get target IDs with non-null target column (also exclude empty strings)
        if HAS_POLARS and isinstance(tgt_df, (pl.DataFrame, pl.LazyFrame)):
            lf = tgt_df if isinstance(tgt_df, pl.LazyFrame) else tgt_df.lazy()
            schema_names = lf.collect_schema().names()
            if rule['target_column'] not in schema_names or join_col not in schema_names:
                continue
            tcol = pl.col(rule['target_column'])
            not_null_filter = tcol.is_not_null()
            dtype = lf.collect_schema()[rule['target_column']]
            if dtype == pl.Utf8 or dtype == pl.String:
                not_null_filter = not_null_filter & (tcol.str.strip_chars().str.len_chars() > 0)
            matched = (
                lf.filter(not_null_filter)
                .select(pl.col(join_col).drop_nulls().unique())
                .collect(streaming=True)
            )
            target_ids = set(matched[join_col].to_list())
        else:
            if rule['target_column'] not in tgt_df.columns or join_col not in tgt_df.columns:
                continue
            target_col = tgt_df[rule['target_column']]
            mask = target_col.notna()
            if hasattr(target_col, 'str') and target_col.dtype == 'object':
                mask = mask & (target_col.astype(str).str.strip() != '')
            target_ids = set(tgt_df.loc[mask, join_col].dropna().unique().tolist())

        result = DQACompletenessResult(
            "cross_table_conditional_completeness",
            f"{source_table}->{target_table}",
        )

        if not source_ids:
            result.add_info(
                f"No {rule['source_column']} = {rule['source_value']} found in "
                f"{source_table}; cross-table conditional check not triggered"
            )
            results.setdefault(target_table, {})[rule_key] = result
            continue

        missing_ids = source_ids - target_ids
        total = len(source_ids)
        missing_count = len(missing_ids)
        pct = round(missing_count / total * 100, 1) if total > 0 else 0

        result.metrics["total_matching_source"] = total
        result.metrics["missing_in_target"] = missing_count
        result.metrics["coverage_percent"] = round(100 - pct, 2)

        if missing_ids:
            sample = sorted(list(missing_ids))[:10]
            result.add_warning(
                f"{missing_count}/{total} patients discharged as {rule['source_value']} "
                f"in {source_table} are missing {rule['target_column']} in {target_table} "
                f"({pct}% missing)",
                {
                    "column": rule['target_column'],
                    "missing_count": missing_count,
                    "total_matching": total,
                    "percent_missing": pct,
                    "sample_ids": sample,
                    "source_condition": f"{rule['source_column']} in {rule['source_value']}",
                },
            )
        else:
            result.add_info(
                f"All {total} patients discharged as {rule['source_value']} in "
                f"{source_table} have {rule['target_column']} in {target_table}"
            )

        results.setdefault(target_table, {})[rule_key] = result

    checked = sum(len(v) for v in results.values())
    _logger.info(
        "run_cross_table_completeness_checks: completed %d checks across %d tables",
        checked, len(results),
    )
    return results


def run_cross_table_plausibility_checks_from_cache(
    caches: Dict[str, Dict[str, Any]],
    plausibility_thresholds: Optional[Dict[str, Dict[str, float]]] = None,
) -> Dict[str, Dict[str, DQAPlausibilityResult]]:
    """Run cross-table plausibility checks using pre-extracted caches.

    Equivalent to :func:`run_cross_table_plausibility_checks` but uses
    cached temporal subset DataFrames and hospitalization bounds instead
    of full DataFrames.

    Parameters
    ----------
    caches : dict
        ``{table_name: cache_dict}`` as returned by
        :func:`extract_cross_table_cache`.
    plausibility_thresholds : dict, optional
        Override default plausibility thresholds per check.

    Returns
    -------
    Dict[str, Dict[str, DQAPlausibilityResult]]
        Same structure as :func:`run_cross_table_plausibility_checks`.
    """
    _logger.info(
        "run_cross_table_plausibility_checks_from_cache: starting with %d cached tables",
        len(caches),
    )

    # Merge caller overrides with defaults
    thresholds = {k: dict(v) for k, v in _DEFAULT_PLAUSIBILITY_THRESHOLDS.items()}
    if plausibility_thresholds:
        for check_name, overrides in plausibility_thresholds.items():
            if check_name in thresholds:
                thresholds[check_name].update(overrides)
            else:
                thresholds[check_name] = overrides

    # Need hospitalization bounds
    hosp_cache = caches.get('hospitalization')
    if hosp_cache is None or hosp_cache.get('hosp_bounds_df') is None:
        _logger.info("Hospitalization cache not available; skipping cross-table plausibility")
        return {}

    hosp_bounds_df = hosp_cache['hosp_bounds_df']
    # Ensure hosp_bounds_df matches active backend
    if _ACTIVE_BACKEND == 'polars' and isinstance(hosp_bounds_df, pd.DataFrame):
        hosp_bounds_df = pl.from_pandas(hosp_bounds_df)

    results: Dict[str, Dict[str, DQAPlausibilityResult]] = {}

    for tbl_name, cache in caches.items():
        if tbl_name == 'hospitalization':
            continue

        temporal_df = cache.get('temporal_df')
        if temporal_df is None:
            continue

        # Ensure temporal_df matches active backend
        if _ACTIVE_BACKEND == 'polars' and isinstance(temporal_df, pd.DataFrame):
            temporal_df = pl.from_pandas(temporal_df)

        time_cols = _CROSS_TABLE_TIME_COLUMNS.get(tbl_name, [])
        if not time_cols:
            continue

        # Determine available time columns in the cached temporal subset
        if HAS_POLARS and isinstance(temporal_df, (pl.DataFrame, pl.LazyFrame)):
            actual_cols = (temporal_df.collect_schema().names()
                          if isinstance(temporal_df, pl.LazyFrame)
                          else temporal_df.columns)
        else:
            actual_cols = temporal_df.columns.tolist()

        available_time_cols = [c for c in time_cols if c in actual_cols]
        if not available_time_cols or 'hospitalization_id' not in actual_cols:
            continue

        result = check_cross_table_temporal_plausibility(
            temporal_df, hosp_bounds_df, tbl_name, available_time_cols,
            **thresholds['cross_table_temporal']
        )
        results.setdefault(tbl_name, {})["cross_table_temporal"] = result

    checked = sum(len(v) for v in results.values())
    _logger.info(
        "run_cross_table_plausibility_checks_from_cache: completed %d checks across %d tables",
        checked, len(results),
    )
    return results


def run_plausibility_checks(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: str,
    hosp_years: Optional[set] = None,
    plausibility_thresholds: Optional[Dict[str, Dict[str, float]]] = None,
) -> Dict[str, DQAPlausibilityResult]:
    """
    Run all single-table plausibility checks on a table.

    Parameters
    ----------
    df : DataFrame
        The data to validate
    schema : dict
        Schema for the table
    table_name : str
        Name of the table
    plausibility_thresholds : dict, optional
        Override default plausibility thresholds per check.

    Returns
    -------
    Dict[str, DQAPlausibilityResult]
        Dictionary of check results keyed by check type
    """
    _logger.info("Running plausibility checks for table '%s' using %s backend", table_name, _ACTIVE_BACKEND)

    # Merge caller overrides with defaults
    thresholds = {k: dict(v) for k, v in _DEFAULT_PLAUSIBILITY_THRESHOLDS.items()}
    if plausibility_thresholds:
        for check_name, overrides in plausibility_thresholds.items():
            if check_name in thresholds:
                thresholds[check_name].update(overrides)
            else:
                thresholds[check_name] = overrides

    if _ACTIVE_BACKEND == 'polars' and isinstance(df, pd.DataFrame):
        _logger.debug("Converting pandas DataFrame to Polars for table '%s'", table_name)
        df = pl.from_pandas(df)

    results = {}

    # A.1 Temporal ordering
    results['temporal_ordering'] = check_temporal_ordering(
        df, table_name, **thresholds['temporal_ordering'])
    gc.collect()

    # A.2 Numeric range plausibility
    results['numeric_range_plausibility'] = check_numeric_range_plausibility(
        df, table_name, **thresholds['numeric_range_plausibility'])
    gc.collect()

    # A.3 Field-level plausibility
    results['field_plausibility'] = check_field_plausibility(df, table_name)
    gc.collect()

    # A.4 Medication dose unit consistency (only for med tables)
    if table_name in ('medication_admin_continuous', 'medication_admin_intermittent'):
        results['medication_dose_unit_consistency'] = check_medication_dose_unit_consistency(
            df, table_name, **thresholds['medication_dose_unit_consistency'])
        gc.collect()

    # C.1 Overlapping periods
    overlap_rules = _load_validation_rules().get('overlapping_periods', {}).get(table_name)
    if overlap_rules:
        results['overlapping_periods'] = check_overlapping_periods(
            df, table_name,
            entity_col=overlap_rules.get('entity_column', 'hospitalization_id'),
            start_col=overlap_rules.get('start_column', 'in_dttm'),
            end_col=overlap_rules.get('end_column', 'out_dttm'),
        )
        gc.collect()

    # C.2 Category temporal consistency
    results['category_temporal_consistency'] = check_category_temporal_consistency(df, schema, table_name, hosp_years=hosp_years)
    gc.collect()

    # D.1 Duplicate composite keys
    results['duplicate_composite_keys'] = check_duplicate_composite_keys(
        df, table_name, schema=schema, **thresholds['duplicate_composite_keys'])
    gc.collect()

    passed = sum(1 for r in results.values() if r.passed)
    failed = len(results) - passed
    _logger.info("Plausibility checks complete for '%s': %d passed, %d failed", table_name, passed, failed)
    return results


def run_cross_table_plausibility_checks(
    tables: list,
    plausibility_thresholds: Optional[Dict[str, Dict[str, float]]] = None,
) -> Dict[str, Dict[str, DQAPlausibilityResult]]:
    """Run cross-table plausibility checks (B.1).

    Parameters
    ----------
    tables : list
        Objects with ``.table_name`` and ``.df`` attributes.
    plausibility_thresholds : dict, optional
        Override default plausibility thresholds per check.

    Returns
    -------
    Dict[str, Dict[str, DQAPlausibilityResult]]
        ``{table_name: {"cross_table_temporal": DQAPlausibilityResult}}``.
    """
    _logger.info("run_cross_table_plausibility_checks: starting with %d tables", len(tables))

    # Merge caller overrides with defaults
    thresholds = {k: dict(v) for k, v in _DEFAULT_PLAUSIBILITY_THRESHOLDS.items()}
    if plausibility_thresholds:
        for check_name, overrides in plausibility_thresholds.items():
            if check_name in thresholds:
                thresholds[check_name].update(overrides)
            else:
                thresholds[check_name] = overrides

    lookup = {}
    for obj in tables:
        tdf = obj.df
        if _ACTIVE_BACKEND == 'polars' and isinstance(tdf, pd.DataFrame):
            tdf = pl.from_pandas(tdf)
        lookup[obj.table_name] = tdf

    if 'hospitalization' not in lookup:
        _logger.info("Hospitalization table not loaded; skipping cross-table plausibility")
        return {}

    hosp_df = lookup['hospitalization']
    results: Dict[str, Dict[str, DQAPlausibilityResult]] = {}

    for tbl_name, tdf in lookup.items():
        if tbl_name == 'hospitalization':
            continue
        time_cols = _CROSS_TABLE_TIME_COLUMNS.get(tbl_name, [])
        if not time_cols:
            continue

        if HAS_POLARS and isinstance(tdf, (pl.DataFrame, pl.LazyFrame)):
            lf = tdf if isinstance(tdf, pl.LazyFrame) else tdf.lazy()
            actual_cols = lf.collect_schema().names()
        else:
            actual_cols = tdf.columns.tolist()

        available_time_cols = [c for c in time_cols if c in actual_cols]
        if not available_time_cols or 'hospitalization_id' not in actual_cols:
            continue

        result = check_cross_table_temporal_plausibility(
            tdf, hosp_df, tbl_name, available_time_cols,
            **thresholds['cross_table_temporal']
        )
        results.setdefault(tbl_name, {})["cross_table_temporal"] = result

    checked = sum(len(v) for v in results.values())
    _logger.info(
        "run_cross_table_plausibility_checks: completed %d checks across %d tables",
        checked, len(results),
    )
    return results


def run_full_dqa(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Optional[Dict[str, Any]] = None,
    table_name: str = "",
    tables: Optional[list] = None,
    error_threshold: float = 50.0,
    warning_threshold: float = 10.0,
    hosp_years: Optional[set] = None,
    plausibility_thresholds: Optional[Dict[str, Dict[str, float]]] = None,
) -> Dict[str, Any]:
    """Run the complete DQA suite on a single table.

    Orchestrates conformance checks, completeness checks, plausibility
    checks, and — when *tables* is provided — auto-detected relational
    integrity and cross-table plausibility checks.

    Parameters
    ----------
    df : DataFrame
        The data to validate.
    schema : dict, optional
        Schema for the table.  When *None* (the default), the schema is
        loaded automatically from the built-in schemas using *table_name*.
    table_name : str
        Name of the table.
    tables : list, optional
        Objects with ``.table_name`` and ``.df`` attributes (e.g.
        :class:`BaseTable` instances).  When provided, relational
        integrity and cross-table plausibility checks are run.
    error_threshold : float
        Percent missing above which an error is raised (default 50).
    warning_threshold : float
        Percent missing above which a warning is raised (default 10).
    hosp_years : set, optional
        Pre-extracted hospitalization years for P.6 temporal consistency.
        When provided, skips scanning the hospitalization table to
        extract years.
    plausibility_thresholds : dict, optional
        Override default plausibility thresholds per check.

    Returns
    -------
    Dict[str, Any]
        Keys: ``table_name``, ``backend``, ``conformance``,
        ``completeness``, ``relational``, ``plausibility``.
    """
    if not table_name:
        raise ValueError("table_name is required")
    if schema is None:
        schema = _load_schema(table_name)
        if schema is None:
            raise FileNotFoundError(
                f"No built-in schema found for table '{table_name}'. "
                "Pass a schema dict explicitly."
            )
    _logger.info("Starting full DQA for table: %s", table_name)

    results: Dict[str, Any] = {
        'table_name': table_name,
        'backend': _ACTIVE_BACKEND,
        'conformance': {},
        'completeness': {},
        'relational': {},
        'plausibility': {},
    }

    results['conformance'] = {
        k: v.to_dict()
        for k, v in run_conformance_checks(df, schema, table_name).items()
    }

    results['completeness'] = {
        k: v.to_dict()
        for k, v in run_completeness_checks(
            df, schema, table_name, error_threshold, warning_threshold
        ).items()
    }

    if tables is not None:
        rel_results = run_relational_integrity_checks(tables)
        if table_name in rel_results:
            results['relational'] = {
                k: v.to_dict()
                for k, v in rel_results[table_name].items()
            }

    # Extract hospitalization years for P.6 temporal consistency context
    # (skip scan if hosp_years was provided by caller)
    if hosp_years is None and tables is not None:
        for obj in tables:
            tname = getattr(obj, 'table_name', '').replace('clif_', '')
            if tname == 'hospitalization':
                hdf = obj.df
                if HAS_POLARS and isinstance(hdf, (pl.DataFrame, pl.LazyFrame)):
                    hlf = hdf if isinstance(hdf, pl.LazyFrame) else hdf.lazy()
                    hcols = hlf.collect_schema().names()
                    if 'admission_dttm' in hcols:
                        hosp_years = set(
                            hlf.select(pl.col('admission_dttm').dt.year().alias('yr'))
                            .filter(pl.col('yr').is_not_null())
                            .unique()
                            .collect()
                            .get_column('yr')
                            .to_list()
                        )
                elif isinstance(hdf, pd.DataFrame) and 'admission_dttm' in hdf.columns:
                    hosp_years = set(
                        int(y) for y in hdf['admission_dttm'].dropna().dt.year.unique()
                    )
                break

    # Plausibility checks (single-table)
    results['plausibility'] = {
        k: v.to_dict()
        for k, v in run_plausibility_checks(
            df, schema, table_name, hosp_years=hosp_years,
            plausibility_thresholds=plausibility_thresholds,
        ).items()
    }

    # Cross-table plausibility checks (when tables provided)
    if tables is not None:
        cross_plaus = run_cross_table_plausibility_checks(
            tables, plausibility_thresholds=plausibility_thresholds)
        if table_name in cross_plaus:
            for k, v in cross_plaus[table_name].items():
                results['plausibility'][k] = v.to_dict()

    gc.collect()
    _logger.info("Completed full DQA for table: %s", table_name)
    return results


# ---------------------------------------------------------------------------
# CLIF-TABLEONE COMPATIBILITY LAYER
# ---------------------------------------------------------------------------
# These functions provide backward compatibility with CLIF-TableOne's
# validation interface expectations.

def validate_dataframe(
    df: Union[pd.DataFrame, 'pl.DataFrame', 'pl.LazyFrame'],
    schema: Dict[str, Any],
    table_name: Optional[str] = None,
    plausibility_thresholds: Optional[Dict[str, Dict[str, float]]] = None,
) -> List[Dict[str, Any]]:
    """
    Validate a dataframe against schema and return list of errors.

    This function provides compatibility with CLIF-TableOne's expected
    validation interface.

    Parameters
    ----------
    df : pd.DataFrame, pl.DataFrame, or pl.LazyFrame
        Data to validate
    schema : dict
        Table schema containing columns, required_columns, etc.
    table_name : str, optional
        Name of the table (inferred from schema if not provided)
    plausibility_thresholds : dict, optional
        Override default plausibility thresholds per check.

    Returns
    -------
    List[Dict[str, Any]]
        List of error dictionaries with keys:
        - type: str - Error type/check name
        - description: str - Human-readable error description
        - details: dict - Additional error details
        - category: str - 'schema' or 'data_quality'
    """
    table_name = table_name or schema.get('table_name', 'unknown')
    _logger.info("validate_dataframe: starting validation for table '%s'", table_name)
    errors = []

    # Schema-level checks (affect 'incomplete' status)
    schema_checks = ['required_columns', 'column_dtypes']

    # Run conformance checks
    conformance_results = run_conformance_checks(df, schema, table_name)
    for check_name, result in conformance_results.items():
        category = 'schema' if check_name in schema_checks else 'data_quality'

        for err in result.errors:
            errors.append({
                'type': _format_check_type(check_name),
                'description': err['message'],
                'details': err.get('details', {}),
                'category': category
            })

        # Include warnings as data quality issues
        for warn in result.warnings:
            errors.append({
                'type': _format_check_type(check_name),
                'description': warn['message'],
                'details': warn.get('details', {}),
                'category': 'data_quality',
                'severity': 'warning'
            })

    # Run completeness checks
    completeness_results = run_completeness_checks(df, schema, table_name)
    for check_name, result in completeness_results.items():
        for err in result.errors:
            errors.append({
                'type': _format_check_type(check_name),
                'description': err['message'],
                'details': err.get('details', {}),
                'category': 'data_quality'
            })

        for warn in result.warnings:
            errors.append({
                'type': _format_check_type(check_name),
                'description': warn['message'],
                'details': warn.get('details', {}),
                'category': 'data_quality',
                'severity': 'warning'
            })

    # Run plausibility checks
    plausibility_results = run_plausibility_checks(
        df, schema, table_name,
        plausibility_thresholds=plausibility_thresholds,
    )
    for check_name, result in plausibility_results.items():
        for err in result.errors:
            errors.append({
                'type': _format_check_type(check_name),
                'description': err['message'],
                'details': err.get('details', {}),
                'category': 'data_quality'
            })

        for warn in result.warnings:
            errors.append({
                'type': _format_check_type(check_name),
                'description': warn['message'],
                'details': warn.get('details', {}),
                'category': 'data_quality',
                'severity': 'warning'
            })

    gc.collect()
    error_count = sum(1 for e in errors if e.get('severity', 'error') == 'error')
    warning_count = sum(1 for e in errors if e.get('severity') == 'warning')
    _logger.info("validate_dataframe: table '%s' complete — %d errors, %d warnings",
                 table_name, error_count, warning_count)
    return errors


def _format_check_type(check_name: str) -> str:
    """Convert internal check names to human-readable format."""
    type_mapping = {
        'required_columns': 'Missing Required Columns',
        'column_dtypes': 'Data Type Mismatch',
        'datetime_format': 'Datetime Format Issue',
        'lab_reference_units': 'Lab Unit Mismatch',
        'categorical_values': 'Invalid Categorical Values',
        'missingness': 'High Missingness',
        'conditional_requirements': 'Conditional Requirement Violation',
        'mcide_value_coverage': 'mCIDE Coverage Gap',
        'relational_integrity': 'Relational Integrity',
        'temporal_ordering': 'Temporal Ordering Violation',
        'numeric_range_plausibility': 'Numeric Range Implausibility',
        'field_plausibility': 'Field Plausibility Violation',
        'medication_dose_unit_consistency': 'Medication Dose Unit Inconsistency',
        'cross_table_temporal': 'Cross-Table Temporal Implausibility',
        'overlapping_periods': 'Overlapping Time Periods',
        'category_temporal_consistency': 'Category Distribution Shift',
        'duplicate_composite_keys': 'Duplicate Composite Keys',
    }
    return type_mapping.get(check_name, check_name.replace('_', ' ').title())


def format_clifpy_error(
    error: Dict[str, Any],
    row_count: int,
    table_name: str
) -> Dict[str, Any]:
    """
    Format a validation error for display.

    Parameters
    ----------
    error : dict
        Error dictionary from validate_dataframe()
    row_count : int
        Total row count of the table
    table_name : str
        Name of the table

    Returns
    -------
    dict
        Formatted error with type, description, category, and details
    """
    formatted = {
        'type': error.get('type', 'Unknown Error'),
        'description': error.get('description', str(error)),
        'category': error.get('category', 'other'),
        'details': error.get('details', {}),
        'table_name': table_name,
        'row_count': row_count
    }

    # Add severity if present
    if 'severity' in error:
        formatted['severity'] = error['severity']

    return formatted


def determine_validation_status(
    errors: List[Dict[str, Any]],
    required_columns: Optional[List[str]] = None,
    table_name: Optional[str] = None
) -> str:
    """
    Determine validation status based on errors.

    Status Logic:
    - INCOMPLETE (red): Missing required columns OR non-castable datatype errors
      OR 100% null in required columns
    - PARTIAL (yellow): Required columns present but has data quality issues
      (missing categorical values, high missingness, etc.)
    - COMPLETE (green): All required columns present, no critical issues

    Parameters
    ----------
    errors : list
        List of formatted error dictionaries
    required_columns : list, optional
        List of required column names
    table_name : str, optional
        Name of the table (for table-specific logic)

    Returns
    -------
    str
        'complete', 'partial', or 'incomplete'
    """
    if not errors:
        _logger.debug("determine_validation_status: no errors — status='complete'")
        return 'complete'

    # Check for schema-level errors that make data incomplete
    for error in errors:
        error_type = error.get('type', '').lower()
        category = error.get('category', '')
        details = error.get('details', {})
        severity = error.get('severity', 'error')

        # Missing required columns -> incomplete
        if 'missing required columns' in error_type or 'missing_columns' in details:
            _logger.debug("determine_validation_status: missing required columns — status='incomplete'")
            return 'incomplete'

        # Non-castable data type errors -> incomplete
        if 'data type' in error_type and category == 'schema':
            if details.get('castable') is False:
                _logger.debug("determine_validation_status: non-castable dtype — status='incomplete'")
                return 'incomplete'

        # 100% missingness in required columns -> incomplete
        if 'missingness' in error_type and severity != 'warning':
            pct_missing = details.get('percent_missing', 0)
            column = details.get('column', '')
            if pct_missing >= 100 and required_columns and column in required_columns:
                _logger.debug("determine_validation_status: 100%% null in '%s' — status='incomplete'", column)
                return 'incomplete'

    # Has errors but not critical -> partial
    has_errors = any(
        e.get('severity', 'error') == 'error'
        for e in errors
    )

    if has_errors:
        _logger.debug("determine_validation_status: has non-critical errors — status='partial'")
        return 'partial'

    # Only warnings -> complete
    _logger.debug("determine_validation_status: warnings only — status='complete'")
    return 'complete'


def classify_errors_by_status_impact(
    errors: Dict[str, List[Dict[str, Any]]],
    required_columns: List[str],
    table_name: str,
    config_timezone: Optional[str] = None
) -> Dict[str, Dict[str, List[Dict[str, Any]]]]:
    """
    Classify errors into status-affecting and informational categories.

    Used by PDF/report generators to separate critical errors from
    informational messages.

    Parameters
    ----------
    errors : dict
        Dictionary with keys 'schema_errors', 'data_quality_issues', 'other_errors'
    required_columns : list
        List of required column names
    table_name : str
        Name of the table
    config_timezone : str, optional
        Configured timezone (to filter timezone-related errors)

    Returns
    -------
    dict
        Dictionary with 'status_affecting' and 'informational', each containing
        'schema_errors', 'data_quality_issues', and 'other_errors' lists
    """
    status_affecting = {
        'schema_errors': [],
        'data_quality_issues': [],
        'other_errors': []
    }
    informational = {
        'schema_errors': [],
        'data_quality_issues': [],
        'other_errors': []
    }

    # Columns that are optional and shouldn't affect status
    optional_columns = {
        'patient': ['race', 'ethnicity', 'language'],
        'hospitalization': ['discharge_category'],
    }
    table_optional = optional_columns.get(table_name, [])

    # Process each error category
    for category_key in ['schema_errors', 'data_quality_issues', 'other_errors']:
        for error in errors.get(category_key, []):
            error_type = error.get('type', '').lower()
            details = error.get('details', {})
            description = error.get('description', '').lower()

            is_informational = False

            # Filter out timezone errors for configured timezone
            if config_timezone and 'timezone' in error_type:
                if config_timezone.lower() in description:
                    is_informational = True

            # Filter out optional column issues
            column = details.get('column', '')
            if column in table_optional:
                is_informational = True

            # mCIDE coverage gaps are informational
            if 'mcide' in error_type or 'coverage' in error_type:
                is_informational = True

            # Plausibility warnings are informational; plausibility errors affect status
            plausibility_keywords = ['temporal ordering', 'numeric range', 'field plausibility',
                                     'dose unit', 'overlapping', 'distribution shift',
                                     'duplicate composite', 'cross-table temporal']
            is_plausibility = any(p in error_type for p in plausibility_keywords)
            if is_plausibility and error.get('severity') == 'warning':
                is_informational = True

            # Warnings are generally informational
            if error.get('severity') == 'warning':
                is_informational = True

            # Classify into appropriate bucket
            if is_informational:
                informational[category_key].append(error)
            else:
                status_affecting[category_key].append(error)

    return {
        'status_affecting': status_affecting,
        'informational': informational
    }


def get_validation_summary(validation_results: Dict[str, Any]) -> str:
    """
    Generate a text summary of validation results.

    Parameters
    ----------
    validation_results : dict
        Validation results from validate() method

    Returns
    -------
    str
        Human-readable summary string
    """
    status = validation_results.get('status', 'unknown')
    errors = validation_results.get('errors', {})

    schema_count = len(errors.get('schema_errors', []))
    dq_count = len(errors.get('data_quality_issues', []))
    other_count = len(errors.get('other_errors', []))
    total = schema_count + dq_count + other_count

    status_emoji = {
        'complete': '✓',
        'partial': '⚠',
        'incomplete': '✗'
    }

    summary_parts = [
        f"Status: {status_emoji.get(status, '?')} {status.upper()}"
    ]

    if total > 0:
        summary_parts.append(f"Issues: {total} total")
        if schema_count:
            summary_parts.append(f"  - Schema: {schema_count}")
        if dq_count:
            summary_parts.append(f"  - Data Quality: {dq_count}")
        if other_count:
            summary_parts.append(f"  - Other: {other_count}")
    else:
        summary_parts.append("No issues found")

    return '\n'.join(summary_parts)
