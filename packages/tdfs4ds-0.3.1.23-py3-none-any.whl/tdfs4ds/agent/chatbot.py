"""
Gradio-based chatbot interface for the tdfs4ds consumer agent.

Provides a simple web UI that non-technical users can interact with
directly from a Jupyter notebook or as a standalone server.

Usage in a notebook::

    from tdfs4ds.agent.chatbot import launch_chatbot
    demo = launch_chatbot()          # opens inline + new-tab link

Standalone::

    python -m tdfs4ds.agent.chatbot   # starts on port 7860
"""

from __future__ import annotations

import os
import uuid
import inspect
from typing import Optional

import gradio as gr

import tdfs4ds
from tdfs4ds.agent.graph import consumer_agent, consumer_agent_stream, _build_context_graph_plotly
from tdfs4ds.agent.vector_index import build_vector_index

# ═══════════════════════════════════════════════════════════════════════════
# Step label helpers for the real-time progress indicator
# ═══════════════════════════════════════════════════════════════════════════

_STEP_LABELS: dict = {
    "classify":           "Classifying intent",
    "detect_domain":      "Detecting data domain",
    "recognize_entity":   "Recognizing entities",
    "skill_search":       "Searching features",
    "skill_definition":   "Looking up definition",
    "skill_usage":        "Checking usage",
    "skill_freshness":    "Checking data freshness",
    "skill_summary":      "Summarizing dataset",
    "skill_lineage":      "Building lineage graph",
    "skill_explain":      "Explaining process SQL",
    "node_skill_dataset": "Looking up datasets",
    "skill_data_query":   "Querying data",
    "synthesize":         "Synthesizing answer",
}

_SKILL_NODES = frozenset({
    "recognize_entity", "skill_search", "skill_definition",
    "skill_usage", "skill_freshness", "skill_summary",
    "skill_lineage", "skill_explain", "node_skill_dataset",
    "skill_data_query",
})


def _format_step(node_name: str, state: dict) -> str:
    """Return a human-readable progress label for the given graph node."""
    base   = _STEP_LABELS.get(node_name, node_name)
    obj    = state.get("object_name") or state.get("resolved_object_name") or ""
    intent = state.get("intent") or ""
    domain = state.get("resolved_data_domain") or ""

    if node_name == "classify" and intent:
        suffix = f" → **{intent}**" + (f" (`{obj}`)" if obj else "")
    elif node_name == "detect_domain" and domain:
        suffix = f" → **{domain}**"
    elif obj and node_name in _SKILL_NODES:
        suffix = f" — **{obj}**"
    else:
        suffix = ""
    return f"⏳ {base}{suffix}..."


# ═══════════════════════════════════════════════════════════════════════════
# Chat function wrappers
# ═══════════════════════════════════════════════════════════════════════════

def _chat_fn(message: str, history: list[dict]) -> tuple[list[dict], str]:
    """Synchronous chat function compatible with Gradio Chatbot (messages format).

    Args:
        message: User message text.
        history: List of message dicts with 'role' and 'content' keys.

    Returns:
        Tuple of (updated history, empty string to clear the input box).
    """
    thread_id = "chatbot-default"
    try:
        answer, _ = consumer_agent(message, thread_id=thread_id, return_trace=True)
    except Exception as exc:
        answer = f"An error occurred: {exc}"

    history = history + [
        {"role": "user", "content": message},
        {"role": "assistant", "content": answer},
    ]
    return history, ""


# ═══════════════════════════════════════════════════════════════════════════
# Gradio UI builder
# ═══════════════════════════════════════════════════════════════════════════

def launch_chatbot(
    title: str = "Feature Store Assistant",
    description: str = (
        "Ask questions about available features, datasets, definitions, "
        "data freshness, or usage guidance — in French or English."
    ),
    port: int = 7860,
    public_base_url: Optional[str] = None,
    inline: bool = True,
    share: bool = False,
    thread_id: Optional[str] = None,
) -> gr.Blocks:
    """Launch a Gradio chatbot interface for the consumer agent.

    Args:
        title: Title displayed at the top of the UI.
        description: Subtitle / description text.
        port: HTTP port for the Gradio server.
        public_base_url: If running behind JupyterHub, the public base URL
            (e.g. ``https://dmproject.myddns.me``). Enables proxy-aware URLs.
        inline: Whether to display an inline iframe in Jupyter.
        share: Whether to create a public Gradio share link.
        thread_id: Fixed conversation thread ID. If None, a new UUID is
            generated per session.

    Returns:
        The Gradio Blocks demo instance.
    """
    initial_thread_id = thread_id or f"chatbot-{uuid.uuid4().hex[:8]}"
    _TRACE_PLACEHOLDER = "_No trace yet. Send a message to see the agent steps._"

    _mcp_available = bool(tdfs4ds.MCP_SERVER_URL)

    def _new_thread_id():
        """Generate a new session thread ID."""
        return f"chatbot-{uuid.uuid4().hex[:8]}"

    def _respond(message: str, history: list[dict], mcp_enabled: bool = False, current_thread_id: str = ""):
        # Use the passed thread_id from gr.State (rotated on each clear)
        active_thread_id = current_thread_id or initial_thread_id
        new_history = history + [{"role": "user", "content": message}]
        # Show user message and clear input immediately, before agent starts
        yield new_history, "⏳ Starting...", _TRACE_PLACEHOLDER, None, ""

        answer   = "An error occurred: unknown error"
        trace_md = _TRACE_PLACEHOLDER
        context_fig = None
        try:
            for event in consumer_agent_stream(
                message,
                thread_id=active_thread_id,
                mcp_enabled=mcp_enabled,
            ):
                if event[0] == "done":
                    answer   = event[1]
                    trace_md = event[2]
                    context_fig = event[3] if len(event) > 3 else None
                else:
                    _, node_name, partial_state = event
                    yield new_history, _format_step(node_name, partial_state), _TRACE_PLACEHOLDER, None, ""
        except Exception as exc:
            answer   = f"An error occurred: {exc}"
            trace_md = f"**Error during execution**\n\n```\n{exc}\n```"

        final_history = new_history + [{"role": "assistant", "content": answer}]
        yield final_history, "", trace_md, context_fig, ""

    with gr.Blocks(title=title) as demo:
        gr.Markdown(f"# {title}")
        if description:
            gr.Markdown(description)

        chatbot = gr.Chatbot(
            height=450,
            label="Conversation",
            latex_delimiters=[
                {"left": "$$", "right": "$$", "display": True},
                {"left": "$",  "right": "$",  "display": False},
            ],
        )
        msg = gr.Textbox(
            placeholder="Type your question here...",
            label="Your question",
            show_label=False,
        )

        mcp_toggle = gr.Checkbox(
            label="Enable MCP Tools",
            value=False,
            visible=_mcp_available,
            info="Route questions to the configured MCP server when no feature store skill applies."
            if _mcp_available else "",
        )

        step_indicator = gr.Markdown("")

        # Thread ID state: rotated on each clear to start a fresh session
        thread_id_state = gr.State(initial_thread_id)

        with gr.Accordion("Agent trace — skills and tools used", open=False):
            trace = gr.Markdown(_TRACE_PLACEHOLDER)

        with gr.Accordion("Context knowledge graph", open=False):
            context_graph = gr.Plot()

        with gr.Row():
            clear = gr.Button("Clear conversation")

        def _clear():
            """Clear conversation and start a new session (new thread ID)."""
            return [], "", _TRACE_PLACEHOLDER, "", _new_thread_id()

        msg.submit(_respond, [msg, chatbot, mcp_toggle, thread_id_state], [chatbot, step_indicator, trace, context_graph, msg])
        clear.click(
            _clear,
            None,
            [chatbot, step_indicator, trace, msg, thread_id_state],
        )

    # Server launch kwargs
    launch_kwargs = dict(
        server_name="0.0.0.0",
        server_port=port,
        inline=inline,
        share=share,
        prevent_thread_lock=True,
    )

    # JupyterHub proxy support
    jupyterhub_user = os.environ.get("JUPYTERHUB_USER")
    if jupyterhub_user:
        service_prefix = os.environ.get(
            "JUPYTERHUB_SERVICE_PREFIX",
            f"/user/{jupyterhub_user}/",
        )
        launch_kwargs["root_path"] = f"/user/{jupyterhub_user}/proxy/{port}/"

        if public_base_url:
            public_url = f"{public_base_url}{service_prefix}proxy/{port}/"

            try:
                from IPython.display import display, HTML

                display(HTML(
                    f'<div style="margin-bottom:10px;">'
                    f'<b>Open in new tab:</b> '
                    f'<a href="{public_url}" target="_blank">{public_url}</a>'
                    f'</div>'
                ))
            except ImportError:
                pass

    demo.launch(**launch_kwargs)
    return demo


# ═══════════════════════════════════════════════════════════════════════════
# Combined index + launch helper
# ═══════════════════════════════════════════════════════════════════════════

def launch_chatbot_with_index(
    port: int = 7860,
    force_rebuild: bool = False,
    title: str = "Feature Store Assistant",
    description: str = (
        "Ask questions about available features, datasets, definitions, "
        "data freshness, or usage guidance — in French or English."
    ),
    public_base_url: Optional[str] = None,
    inline: bool = True,
    share: bool = False,
    thread_id: Optional[str] = None,
) -> gr.Blocks:
    """Build the vector index then launch the Gradio chatbot in one call.

    Args:
        port: HTTP port for the Gradio server.
        force_rebuild: If True, wipe and rebuild the Chroma index from scratch.
            If False (default), only index new rows (incremental).
        title: Title displayed at the top of the UI.
        description: Subtitle / description text.
        public_base_url: JupyterHub public base URL for proxy-aware links.
        inline: Whether to display an inline iframe in Jupyter.
        share: Whether to create a public Gradio share link.
        thread_id: Fixed conversation thread ID (None = new UUID per session).

    Returns:
        The Gradio Blocks demo instance.
    """
    build_vector_index(force_rebuild=force_rebuild)
    return launch_chatbot(
        title=title,
        description=description,
        port=port,
        public_base_url=public_base_url,
        inline=inline,
        share=share,
        thread_id=thread_id,
    )


# ═══════════════════════════════════════════════════════════════════════════
# CLI entry point
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    demo = launch_chatbot(inline=False)
    demo.block_thread()
