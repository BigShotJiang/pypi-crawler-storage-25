"""Upstream metadata probes for nostos.

Parses a git remote URL into (provider, host, owner, name), then calls
the matching provider probe to fetch a small metadata record (stars,
archived, default branch, last push, latest release, license) which
is cached in the metadata index.

Design principles
- Zero new runtime dependencies: everything uses urllib.request.
- Fail-closed on unknown hosts: a host not present in
  ~/.config/nostos/auth.toml is skipped entirely (no network call).
  This is the critical opsec guarantee; see README > Security.
- Per-repo `quiet=1` repos are always skipped: the upstream layer
  never queries them, never logs them.
- Tokens are redacted from every log path; inline tokens are passed
  via Authorization header only.
- Errors are surfaced, not swallowed: the caller decides whether to
  record the error in upstream_meta.fetch_error or just report.
"""

from __future__ import annotations

import datetime
import json
import logging
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Protocol

from .auth import AuthConfig


class _Probe(Protocol):
    kind: str

    def fetch(
        self,
        host: str,
        owner: str,
        name: str,
        token: str | None,
    ) -> dict[str, Any]: ...

# ---------- result / error types ----------


class ProbeError(Exception):
    """Base class for upstream probe failures surfaced to callers."""


class HostNotAllowed(ProbeError):
    """Host is not configured in auth.toml and allow_unknown is False."""


class ProviderUnknown(ProbeError):
    """Host is configured but no probe is registered for its provider."""


class ProbeHTTPError(ProbeError):
    """The upstream API returned an error (401, 403, 404, 429, 5xx, etc.)."""

    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status


# ---------- remote URL parsing ----------


_SCP_RE = re.compile(r"^(?:[\w.\-]+@)?(?P<host>[\w.\-]+):(?P<path>[\w./\-]+?)(?:\.git)?$")
_URL_RE = re.compile(
    r"^(?:https?|ssh|git)://(?:[\w.\-]+@)?(?P<host>[\w.\-]+)"
    r"(?::\d+)?/(?P<path>[\w./\-]+?)(?:\.git)?/?$"
)


def parse_remote_url(url: str) -> tuple[str, str, str] | None:
    """Return (host, owner, name) or None if the URL is unrecognisable.

    Handles the common git remote forms:
    - git@github.com:owner/repo.git            (SCP-style SSH)
    - ssh://git@github.com/owner/repo.git      (ssh:// URL)
    - https://github.com/owner/repo(.git)      (HTTPS)
    - git://host/owner/repo.git                (git://)
    and gracefully handles subgroup paths on GitLab by taking the
    *last* path component as the repo name and everything-before
    as the owner (so 'group/subgroup/repo' becomes owner='group/subgroup').
    """
    if not url:
        return None
    url = url.strip()

    m = _URL_RE.match(url)
    if m is None:
        m = _SCP_RE.match(url)
    if m is None:
        return None

    host = m.group("host")
    path = m.group("path").rstrip("/").removesuffix(".git")
    parts = path.split("/")
    if len(parts) < 2:
        return None
    name = parts[-1]
    owner = "/".join(parts[:-1])
    return host, owner, name


# ---------- provider probes ----------


def _http_get_json(
    url: str,
    *,
    token: str | None = None,
    accept: str | None = None,
    timeout: float = 15.0,
) -> tuple[dict[str, Any], dict[str, str]]:
    """GET a URL and parse JSON. Returns (body, headers).

    Raises ProbeHTTPError on HTTP 4xx/5xx, ProbeError on parse/timeout
    failures. Never logs Authorization headers.
    """
    req = urllib.request.Request(url, method="GET")
    req.add_header("User-Agent", "nostos")
    if accept:
        req.add_header("Accept", accept)
    if token:
        # GitHub uses 'Bearer <token>'; GitLab/Gitea use 'token <token>' on
        # /api/v4 and /api/v1 respectively, but both also accept
        # 'Authorization: Bearer' since late 2023.
        req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            headers = {k: v for k, v in resp.headers.items()}
            body = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        # Drain to get a message if possible; still don't leak auth.
        try:
            body = e.read().decode("utf-8", errors="replace")
        except OSError:
            body = ""
        msg = _short_http_message(body) or e.reason or ""
        raise ProbeHTTPError(e.code, f"{e.code} {msg}") from None
    except urllib.error.URLError as e:
        raise ProbeError(f"network error: {e.reason}") from None
    except TimeoutError:
        raise ProbeError("timeout") from None
    except OSError as e:
        raise ProbeError(f"os error: {e}") from None

    try:
        data = json.loads(body)
    except json.JSONDecodeError as e:
        raise ProbeError(f"invalid JSON from upstream: {e}") from None
    if not isinstance(data, dict):
        raise ProbeError("unexpected JSON shape from upstream")
    return data, headers


def _http_get_json_list(
    url: str,
    *,
    token: str | None = None,
    accept: str | None = None,
    timeout: float = 15.0,
) -> tuple[list[Any], dict[str, str]]:
    """Like `_http_get_json` but expects a list response.

    Raises ProbeHTTPError on HTTP 4xx/5xx, ProbeError on parse/timeout
    failures or unexpected (non-list) JSON shape.
    """
    req = urllib.request.Request(url, method="GET")
    req.add_header("User-Agent", "nostos")
    if accept:
        req.add_header("Accept", accept)
    if token:
        req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            headers = {k: v for k, v in resp.headers.items()}
            body = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
        except OSError:
            body = ""
        msg = _short_http_message(body) or e.reason or ""
        raise ProbeHTTPError(e.code, f"{e.code} {msg}") from None
    except urllib.error.URLError as e:
        raise ProbeError(f"network error: {e.reason}") from None
    except TimeoutError:
        raise ProbeError("timeout") from None
    except OSError as e:
        raise ProbeError(f"os error: {e}") from None

    try:
        data = json.loads(body)
    except json.JSONDecodeError as e:
        raise ProbeError(f"invalid JSON from upstream: {e}") from None
    if not isinstance(data, list):
        raise ProbeError("unexpected JSON shape from upstream (expected list)")
    return data, headers


def _short_http_message(body: str) -> str:
    """Extract a short human message from a JSON error body, never a token."""
    try:
        data = json.loads(body)
    except (json.JSONDecodeError, ValueError):
        return body[:80].replace("\n", " ")
    if isinstance(data, dict):
        for key in ("message", "error", "description"):
            val = data.get(key)
            if isinstance(val, str):
                return val[:120]
    return ""


def _clean_topics(raw: Any) -> list[str]:
    """Coerce a provider's topics field into a list of clean lowercase tags.

    Accepts None, list, or junk; rejects empty strings and non-strings.
    Topic strings from GitHub/GitLab/Gitea are already kebab-case, but
    we lowercase defensively and dedupe while preserving order.
    """
    if not isinstance(raw, list):
        return []
    seen: set[str] = set()
    out: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            continue
        name = item.strip().lower()
        if not name or name in seen:
            continue
        seen.add(name)
        out.append(name)
    return out


def _respect_rate_limit(headers: dict[str, str]) -> None:
    """Sleep briefly when a provider reports we are near zero remaining."""
    remaining = headers.get("X-RateLimit-Remaining") or headers.get(
        "RateLimit-Remaining"
    )
    try:
        if remaining is not None and int(remaining) <= 1:
            logging.warning(
                "nostos: upstream rate-limit nearly exhausted "
                f"(remaining={remaining}); sleeping 2s"
            )
            time.sleep(2)
    except ValueError:
        pass


# ---- GitHub (github.com + GHE) ----


class GitHubProbe:
    kind = "github"

    @staticmethod
    def api_base(host: str) -> str:
        if host == "github.com":
            return "https://api.github.com"
        # GitHub Enterprise: <host>/api/v3
        return f"https://{host}/api/v3"

    def fetch(
        self,
        host: str,
        owner: str,
        name: str,
        token: str | None,
    ) -> dict[str, Any]:
        base = self.api_base(host)
        repo_url = f"{base}/repos/{urllib.parse.quote(owner)}/{urllib.parse.quote(name)}"
        data, headers = _http_get_json(
            repo_url,
            token=token,
            accept="application/vnd.github+json",
        )
        _respect_rate_limit(headers)

        license_info = data.get("license") or {}
        license_name = license_info.get("spdx_id") if isinstance(license_info, dict) else None

        result: dict[str, Any] = {
            "provider": self.kind,
            "host": host,
            "owner": owner,
            "name": name,
            "description": data.get("description"),
            "stars": data.get("stargazers_count"),
            "forks": data.get("forks_count"),
            "open_issues": data.get("open_issues_count"),
            "archived": bool(data.get("archived")),
            "default_branch": data.get("default_branch"),
            "license": license_name,
            "last_push": data.get("pushed_at"),
            "latest_release": None,
            "topics": _clean_topics(data.get("topics")),
        }

        # Latest release (optional; a repo with no releases returns 404).
        try:
            rel, _ = _http_get_json(
                f"{base}/repos/{urllib.parse.quote(owner)}/{urllib.parse.quote(name)}/releases/latest",
                token=token,
                accept="application/vnd.github+json",
            )
            result["latest_release"] = rel.get("tag_name")
        except ProbeHTTPError as e:
            if e.status != 404:
                # Non-404 is unusual but not fatal; leave latest_release as None.
                logging.debug(f"nostos: release fetch failed: {e}")
        except ProbeError:
            pass

        return result


# ---- security advisories (GitHub) ----


_SEVERITY_RANK: dict[str, int] = {
    "critical": 4, "high": 3, "medium": 2, "low": 1,
}


def fetch_repo_advisories(
    host: str,
    owner: str,
    name: str,
    token: str | None,
    *,
    timeout: float = 15.0,
) -> tuple[int, str | None]:
    """Return (count, top_severity) of open repo-level GitHub Security
    Advisories.

    "Open" means state in {"published","triaged"} - we exclude
    "closed" (fixed) and "withdrawn" (revoked). The endpoint returns
    repository-level advisories the maintainer has filed, NOT
    Dependabot alerts (those require admin access).

    Output:
        (0, None)               - no open advisories.
        (N, "critical"|"high"|"medium"|"low")
                                - N advisories, top severity is the
                                  highest level seen.

    Raises ProbeHTTPError(404) when the repo doesn't exist.
    Returns (0, None) on every other HTTP error (advisory fetch is
    best-effort; we don't want a missing endpoint to mark a repo
    "vulnerable").
    """
    base = GitHubProbe.api_base(host)
    url = (
        f"{base}/repos/{urllib.parse.quote(owner)}/"
        f"{urllib.parse.quote(name)}/security-advisories?per_page=100"
    )
    try:
        items = _github_list_paginated(
            url, token=token, accept="application/vnd.github+json", timeout=timeout
        )
    except ProbeHTTPError as e:
        if e.status == 404:
            raise
        # 403 (rate limit / disabled), 410, etc. - degrade gracefully.
        return (0, None)
    except ProbeError:
        return (0, None)

    open_severities: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        state = (item.get("state") or "").lower()
        if state not in {"published", "triaged"}:
            continue
        sev = (item.get("severity") or "").lower()
        if sev in _SEVERITY_RANK:
            open_severities.append(sev)
        else:
            # Unknown severity - count it but flag as "low" for ranking
            # purposes; better to under-report than over-report.
            open_severities.append("low")

    if not open_severities:
        return (0, None)
    top = max(open_severities, key=lambda s: _SEVERITY_RANK[s])
    return (len(open_severities), top)


# ---- bulk owner enumeration ----


_PAGINATION_SAFETY_CAP: int = 50  # max pages, i.e. 5000 repos at per_page=100


def _github_list_paginated(
    base_url: str,
    *,
    token: str | None,
    accept: str,
    timeout: float,
) -> list[Any]:
    """Fetch every page of a GitHub list endpoint.

    Stops when a page returns fewer than per_page items or the safety
    cap is hit. Returns the concatenated list of items. Caller is
    responsible for filtering / shaping the entries.
    """
    out: list[Any] = []
    page = 1
    per_page = 100
    while page <= _PAGINATION_SAFETY_CAP:
        sep = "&" if "?" in base_url else "?"
        url = f"{base_url}{sep}per_page={per_page}&page={page}"
        items, headers = _http_get_json_list(
            url, token=token, accept=accept, timeout=timeout
        )
        _respect_rate_limit(headers)
        if not items:
            break
        out.extend(items)
        if len(items) < per_page:
            break
        page += 1
    return out


def list_owner_repos(
    host: str,
    owner: str,
    token: str | None,
    *,
    include_forks: bool = False,
    include_archived: bool = False,
    timeout: float = 30.0,
) -> list[dict[str, Any]]:
    """Return repo metadata for every public repo owned by an entity.

    Tries `/users/{owner}/repos` first; falls back to
    `/orgs/{owner}/repos` if the user endpoint 404s. (GitHub treats
    users and organizations distinctly: the user endpoint returns no
    rows for an org slug, and vice versa.)

    Filters:
        include_forks=False  - drop repos where `fork` is true
        include_archived=False - drop repos where `archived` is true

    Returns a list of dicts with the fields a caller needs to clone
    and tag the repo: full_name, name, clone_url, fork, archived,
    language, stargazers_count, topics, description, default_branch.

    Raises:
        ProbeHTTPError(404) when neither endpoint resolves (owner
        does not exist).
        ProbeError on network / parse failures.
    """
    base = GitHubProbe.api_base(host)
    accept = "application/vnd.github+json"

    user_url = f"{base}/users/{urllib.parse.quote(owner)}/repos"
    org_url = f"{base}/orgs/{urllib.parse.quote(owner)}/repos"

    try:
        raw = _github_list_paginated(
            user_url, token=token, accept=accept, timeout=timeout
        )
    except ProbeHTTPError as e:
        if e.status != 404:
            raise
        raw = _github_list_paginated(
            org_url, token=token, accept=accept, timeout=timeout
        )

    out: list[dict[str, Any]] = []
    for repo in raw:
        if not isinstance(repo, dict):
            continue
        if not include_forks and repo.get("fork"):
            continue
        if not include_archived and repo.get("archived"):
            continue
        out.append({
            "full_name": str(repo.get("full_name") or ""),
            "name": str(repo.get("name") or ""),
            "clone_url": str(
                repo.get("clone_url") or repo.get("html_url") or ""
            ),
            "html_url": str(repo.get("html_url") or ""),
            "fork": bool(repo.get("fork")),
            "archived": bool(repo.get("archived")),
            "language": repo.get("language"),
            "stargazers_count": int(repo.get("stargazers_count") or 0),
            "topics": _clean_topics(repo.get("topics")),
            "description": repo.get("description"),
            "default_branch": repo.get("default_branch"),
        })
    return out


# ---- GitLab (gitlab.com + self-hosted) ----


class GitLabProbe:
    kind = "gitlab"

    @staticmethod
    def api_base(host: str) -> str:
        return f"https://{host}/api/v4"

    def fetch(
        self,
        host: str,
        owner: str,
        name: str,
        token: str | None,
    ) -> dict[str, Any]:
        base = self.api_base(host)
        project = urllib.parse.quote(f"{owner}/{name}", safe="")
        data, headers = _http_get_json(f"{base}/projects/{project}", token=token)
        _respect_rate_limit(headers)

        last_push = data.get("last_activity_at") or data.get("pushed_at")

        result: dict[str, Any] = {
            "provider": self.kind,
            "host": host,
            "owner": owner,
            "name": name,
            "description": data.get("description"),
            "stars": data.get("star_count"),
            "forks": data.get("forks_count"),
            "open_issues": data.get("open_issues_count"),
            "archived": bool(data.get("archived")),
            "default_branch": data.get("default_branch"),
            "license": (data.get("license") or {}).get("nickname")
            or (data.get("license") or {}).get("key"),
            "last_push": last_push,
            "latest_release": None,
            "topics": _clean_topics(data.get("topics") or data.get("tag_list")),
        }

        try:
            rel, _ = _http_get_json(
                f"{base}/projects/{project}/releases?per_page=1", token=token
            )
            # GitLab returns a list; but our _http_get_json demands a dict.
            # Use a list-accepting fallback here.
        except ProbeError:
            pass

        try:
            req = urllib.request.Request(
                f"{base}/projects/{project}/releases?per_page=1", method="GET"
            )
            req.add_header("User-Agent", "nostos")
            if token:
                req.add_header("Authorization", f"Bearer {token}")
            with urllib.request.urlopen(req, timeout=15) as resp:
                body = resp.read().decode("utf-8", errors="replace")
            items = json.loads(body)
            if isinstance(items, list) and items:
                tag = items[0].get("tag_name")
                if tag:
                    result["latest_release"] = tag
        except (urllib.error.URLError, OSError, ValueError, TimeoutError):
            pass

        return result


# ---- Gitea (self-hosted) ----


class GiteaProbe:
    kind = "gitea"

    @staticmethod
    def api_base(host: str) -> str:
        return f"https://{host}/api/v1"

    def fetch(
        self,
        host: str,
        owner: str,
        name: str,
        token: str | None,
    ) -> dict[str, Any]:
        base = self.api_base(host)
        data, headers = _http_get_json(
            f"{base}/repos/{urllib.parse.quote(owner)}/{urllib.parse.quote(name)}",
            token=token,
        )
        _respect_rate_limit(headers)

        result: dict[str, Any] = {
            "provider": self.kind,
            "host": host,
            "owner": owner,
            "name": name,
            "description": data.get("description"),
            "stars": data.get("stars_count"),
            "forks": data.get("forks_count"),
            "open_issues": data.get("open_issues_count"),
            "archived": bool(data.get("archived")),
            "default_branch": data.get("default_branch"),
            "license": None,
            "last_push": data.get("updated_at"),
            "latest_release": None,
            "topics": _clean_topics(data.get("topics")),
        }
        return result


_PROBES: dict[str, _Probe] = {
    "github": GitHubProbe(),
    "gitlab": GitLabProbe(),
    "gitea": GiteaProbe(),
}


# ---------- dispatcher ----------


def probe_upstream(
    remote_url: str,
    auth: AuthConfig,
    *,
    offline: bool = False,
) -> dict[str, Any]:
    """Probe the upstream for a repo. Returns a dict matching the
    upstream_meta schema, with `fetched_at` set.

    Raises:
    - ProbeError if offline, if parsing fails, or if the network call fails.
    - HostNotAllowed if the host is not configured and allow_unknown is False.
    - ProviderUnknown if the host is configured but has no known provider.
    """
    if offline:
        raise ProbeError("offline mode: no network calls permitted")

    parsed = parse_remote_url(remote_url)
    if parsed is None:
        raise ProbeError(f"cannot parse remote URL: {remote_url!r}")
    host, owner, name = parsed

    if not auth.is_allowed(host):
        raise HostNotAllowed(f"host not configured: {host}")

    provider = auth.provider_for(host)
    if provider is None:
        raise ProviderUnknown(f"no provider registered for host: {host}")

    probe = _PROBES.get(provider)
    if probe is None:
        raise ProviderUnknown(f"unknown provider: {provider}")

    token = auth.resolve_token(host)
    result = probe.fetch(host, owner, name, token)
    result["fetched_at"] = datetime.datetime.now(
        datetime.timezone.utc
    ).isoformat(timespec="seconds")
    return result
