# slingshot-types

Typed shims for popular Python package functions that often show up as `Unknown` in strict type checking.

The package uses `Protocol` and `cast` to provide stable, importable typed callables for:

- `sklearn.metrics.classification_report`
- `sklearn.model_selection.train_test_split`
- `tqdm.tqdm`

## Install

```bash
pip install -e .
```

## Usage

```python
from slingshot_types import classification_report, train_test_split, tqdm

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

for row in tqdm(rows):
    ...

report = classification_report(y_test, y_pred)
```

## Why this exists

Some downstream codebases run strict checks (`Unknown`/`Any` bans in pyright or mypy configurations).
These shims give typed import points while preserving runtime behavior.
