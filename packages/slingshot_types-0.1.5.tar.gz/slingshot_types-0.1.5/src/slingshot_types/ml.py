from __future__ import annotations

from collections.abc import Iterator, Sequence
from typing import Any, Literal, Protocol, TypeVar, cast, overload

from numpy.typing import NDArray # type: ignore[import]
from sklearn.metrics import classification_report as _classification_report # type: ignore[import]
from sklearn.model_selection import GroupShuffleSplit as _GroupShuffleSplit # type: ignore[import]
from sklearn.model_selection import train_test_split as _train_test_split # type: ignore[import]

ArrayLike1D = Sequence[Any] | NDArray[Any]
LabelArrayLike1D = Sequence[Any] | NDArray[Any]
FloatArrayLike1D = Sequence[float] | NDArray[Any]
ClassificationReportDict = dict[str, Any]
ZeroDivisionArg = Literal["warn", 0, 1]

T = TypeVar("T")


class ClassificationReportFn(Protocol):
    @overload
    def __call__(
        self,
        y_true: ArrayLike1D,
        y_pred: ArrayLike1D,
        *,
        labels: LabelArrayLike1D | None = ...,
        target_names: Sequence[str] | None = ...,
        sample_weight: FloatArrayLike1D | None = ...,
        digits: int = ...,
        output_dict: Literal[False] = ...,
        zero_division: ZeroDivisionArg = ...,
    ) -> str: ...

    @overload
    def __call__(
        self,
        y_true: ArrayLike1D,
        y_pred: ArrayLike1D,
        *,
        labels: LabelArrayLike1D | None = ...,
        target_names: Sequence[str] | None = ...,
        sample_weight: FloatArrayLike1D | None = ...,
        digits: int = ...,
        output_dict: Literal[True],
        zero_division: ZeroDivisionArg = ...,
    ) -> ClassificationReportDict: ...


class TrainTestSplitFn(Protocol):
    def __call__(
        self,
        *arrays: T,
        test_size: float | int | None = ...,
        train_size: float | int | None = ...,
        random_state: int | None = ...,
        shuffle: bool = ...,
        stratify: Any | None = ...,
    ) -> tuple[T, ...]: ...


IndexSequence = Sequence[int]
GroupArrayLike = Sequence[Any] | NDArray[Any]


class GroupShuffleSplitProtocol(Protocol):
    def split(
        self,
        X: Any,
        y: Any | None = ...,
        groups: GroupArrayLike | None = ...,
    ) -> Iterator[tuple[IndexSequence, IndexSequence]]: ...

    def get_n_splits(
        self,
        X: Any | None = ...,
        y: Any | None = ...,
        groups: GroupArrayLike | None = ...,
    ) -> int: ...


class GroupShuffleSplitCtor(Protocol):
    def __call__(
        self,
        n_splits: int = ...,
        *,
        test_size: float | int | None = ...,
        train_size: float | int | None = ...,
        random_state: int | None = ...,
    ) -> GroupShuffleSplitProtocol: ...


classification_report = cast(ClassificationReportFn, _classification_report)
train_test_split = cast(TrainTestSplitFn, _train_test_split)
GroupShuffleSplit = cast(GroupShuffleSplitCtor, _GroupShuffleSplit)
