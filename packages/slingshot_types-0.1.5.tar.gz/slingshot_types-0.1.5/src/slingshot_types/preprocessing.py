from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, Protocol, cast, overload

from numpy.typing import NDArray # type: ignore[import]
from scipy.sparse import spmatrix # type: ignore[import]
from sklearn.preprocessing import StandardScaler as _StandardScaler # type: ignore[import]

if TYPE_CHECKING:
    from pandas import DataFrame as PandasDataFrame # type: ignore[import]
else:
    PandasDataFrame = Any

DenseFeatureMatrix = NDArray[Any] | PandasDataFrame
SparseFeatureMatrix = spmatrix
FeatureMatrix = DenseFeatureMatrix | SparseFeatureMatrix
TargetArray = NDArray[Any] | Sequence[Any]
SampleWeightLike = NDArray[Any] | Sequence[float]


class StandardScalerProtocol(Protocol):
    def fit(
        self,
        X: FeatureMatrix,
        y: TargetArray | None = ...,
        sample_weight: SampleWeightLike | None = ...,
    ) -> StandardScalerProtocol: ...

    def partial_fit(
        self,
        X: FeatureMatrix,
        y: TargetArray | None = ...,
        sample_weight: SampleWeightLike | None = ...,
    ) -> StandardScalerProtocol: ...

    @overload
    def transform(self, X: DenseFeatureMatrix, copy: bool | None = ...) -> NDArray[Any]: ...

    @overload
    def transform(self, X: SparseFeatureMatrix, copy: bool | None = ...) -> spmatrix: ...

    @overload
    def fit_transform(
        self,
        X: DenseFeatureMatrix,
        y: TargetArray | None = ...,
        **fit_params: Any,
    ) -> NDArray[Any]: ...

    @overload
    def fit_transform(
        self,
        X: SparseFeatureMatrix,
        y: TargetArray | None = ...,
        **fit_params: Any,
    ) -> spmatrix: ...

    @overload
    def inverse_transform(self, X: NDArray[Any], copy: bool | None = ...) -> NDArray[Any]: ...

    @overload
    def inverse_transform(self, X: spmatrix, copy: bool | None = ...) -> spmatrix: ...


class StandardScalerCtor(Protocol):
    def __call__(
        self,
        *,
        copy: bool = ...,
        with_mean: bool = ...,
        with_std: bool = ...,
    ) -> StandardScalerProtocol: ...


StandardScaler = cast(StandardScalerCtor, _StandardScaler)