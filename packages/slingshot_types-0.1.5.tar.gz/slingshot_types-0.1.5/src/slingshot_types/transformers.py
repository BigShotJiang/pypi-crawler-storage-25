from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Literal, Protocol, cast, overload

from numpy.typing import NDArray # type: ignore[import]
from sentence_transformers import SentenceTransformer as _SentenceTransformer # type: ignore[import]

PrecisionArg = Literal["float32", "int8", "uint8", "binary", "ubinary"]
OutputValueArg = Literal["sentence_embedding", "token_embeddings"]


class SentenceTransformerProtocol(Protocol):
	@overload
	def encode(
		self,
		inputs: str,
		*,
		prompt_name: str | None = ...,
		prompt: str | None = ...,
		batch_size: int = ...,
		show_progress_bar: bool | None = ...,
		output_value: Literal["sentence_embedding"] = ...,
		precision: PrecisionArg = ...,
		convert_to_numpy: Literal[True] = ...,
		convert_to_tensor: Literal[False] = ...,
		normalize_embeddings: bool = ...,
		truncate_dim: int | None = ...,
		**kwargs: Any,
	) -> NDArray[Any]: ...

	@overload
	def encode(
		self,
		inputs: Sequence[str],
		*,
		prompt_name: str | None = ...,
		prompt: str | None = ...,
		batch_size: int = ...,
		show_progress_bar: bool | None = ...,
		output_value: Literal["sentence_embedding"] = ...,
		precision: PrecisionArg = ...,
		convert_to_numpy: Literal[True] = ...,
		convert_to_tensor: Literal[False] = ...,
		normalize_embeddings: bool = ...,
		truncate_dim: int | None = ...,
		**kwargs: Any,
	) -> NDArray[Any]: ...

	@overload
	def encode(
		self,
		inputs: str | Sequence[str],
		*,
		prompt_name: str | None = ...,
		prompt: str | None = ...,
		batch_size: int = ...,
		show_progress_bar: bool | None = ...,
		output_value: OutputValueArg = ...,
		precision: PrecisionArg = ...,
		convert_to_numpy: Literal[False] = ...,
		convert_to_tensor: bool = ...,
		normalize_embeddings: bool = ...,
		truncate_dim: int | None = ...,
		**kwargs: Any,
	) -> Any: ...


class SentenceTransformerCtor(Protocol):
	def __call__(self, model_name_or_path: str, *args: Any, **kwargs: Any) -> SentenceTransformerProtocol: ...


SentenceTransformer = cast(SentenceTransformerCtor, _SentenceTransformer)
