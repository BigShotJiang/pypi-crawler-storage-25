from __future__ import annotations

from collections.abc import Iterable, Iterator
from typing import Any, Protocol, TypeVar, cast, overload

from tqdm import tqdm as _tqdm

T = TypeVar("T")


class TqdmFn(Protocol):
    @overload
    def __call__(self, iterable: Iterable[T], *args: Any, **kwargs: Any) -> Iterator[T]: ...

    @overload
    def __call__(self, iterable: None = ..., *args: Any, **kwargs: Any) -> Any: ...


tqdm = cast(TqdmFn, _tqdm)
