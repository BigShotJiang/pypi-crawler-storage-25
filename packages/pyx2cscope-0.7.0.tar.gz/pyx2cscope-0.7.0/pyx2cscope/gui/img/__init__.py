"""Module for images."""
