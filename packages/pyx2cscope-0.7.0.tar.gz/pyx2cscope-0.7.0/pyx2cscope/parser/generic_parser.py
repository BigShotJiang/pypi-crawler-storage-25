"""This module provides functionalities for parsing ELF files.

It focuses on extracting structure members and variable information from DWARF debugging information.
"""

import logging
import math
import re
from itertools import product

from elftools.construct.lib import ListContainer
from elftools.dwarf.dwarf_expr import DWARFExprParser
from elftools.elf.elffile import ELFFile
from elftools.elf.sections import SymbolTableSection

from pyx2cscope.parser.elf_parser import ElfParser
from pyx2cscope.variable.variable import VariableInfo

TARGET_SIGNATURE_PATTERNS = (
    ("dspic33a", ("__DSPIC33A", "__33AK")),
    ("arm", ("__PIC32C", "PIC32C/", "SAME", "__GENERIC_ARM_", "ARMV6", "ARMV7")),
    ("pic32", ("__PIC32",)),
    ("dspic", ("__DSPIC", "__PIC24", "__33CK", "__33CH", "__33EP", "__33FJ")),
)
REGISTER_SYMBOL_PATTERN = re.compile(r"^[A-Z][A-Z0-9]*$")
FAMILY_REGISTER_BYTE_SIZE = {
    "arm": 4,
    "pic32": 4,
    "dspic33a": 4,
    "dspic": 2,
}


class GenericParser(ElfParser):
    """Class for parsing ELF files compatible with 32-bit architectures."""

    def __init__(self, elf_path):
        """Initialize the GenericParser with the given ELF file path."""
        super().__init__(elf_path)

        # These variables are used as local holders during the file parsing
        self.die_variable = None
        self.var_name = None
        self.address = None
        self.is_sfr = False  # True when the current DIE is a peripheral register (DW_AT_external)

    def _load_elf_file(self):
        try:
            self.stream = open(self.elf_path, "rb")
            self.elf_file = ELFFile(self.stream)
            self.elf_machine = self.elf_file["e_machine"]
            self.dwarf_info = self.elf_file.get_dwarf_info()
        except IOError:
            raise Exception(f"Error loading ELF file: {self.elf_path}")

    def _close_elf_file(self):
        """Closes the ELF file stream."""
        if self.stream:
            self.stream.close()

    def _get_die_variable(self, die_struct):
        """Process the die_struct to obtain the die containing the variable and its info.

        This method populates class members:
        - self.die_variable
        - self.var_name
        - self.address
        """
        self.die_variable = None
        self.var_name = None
        self.address = None
        self.is_sfr = False

        # In DIE structure, a variable to be considered valid, has under
        # its attributes the attribute DW_AT_specification or DW_AT_location
        if "DW_AT_specification" in die_struct.attributes:
            spec_ref_addr = die_struct.attributes["DW_AT_specification"].value + die_struct.cu.cu_offset
            spec_die = self.dwarf_info.get_DIE_from_refaddr(spec_ref_addr)
            # if it is not a concrete variable, return
            if spec_die.tag != "DW_TAG_variable":
                return
            self.die_variable = spec_die
        elif die_struct.attributes.get("DW_AT_location") and die_struct.attributes.get("DW_AT_name") is not None:
            self.die_variable = die_struct
        elif die_struct.attributes.get("DW_AT_external") and die_struct.attributes.get("DW_AT_name") is not None:
            if die_struct.tag != "DW_TAG_variable":
                return
            self.die_variable = die_struct
            self.is_sfr = True
        else:
            return

        self.var_name = self.die_variable.attributes.get("DW_AT_name").value.decode("utf-8")
        self.address = self._extract_address(die_struct)

    def _process_die(self, die):
        """Process a DIE structure containing the variable and its members.

        Firmware variables (no DW_AT_external) are stored in variable_map.
        Peripheral registers / SFRs (DW_AT_external, address from symbol table) are
        stored in register_map, including any bitfield sub-entries.
        """
        self._get_die_variable(die)
        if self.address is None:
            return

        members = {}
        self._process_end_die(members, self.die_variable, self.var_name, 0)

        target_map = self.register_map if self.is_sfr else self.variable_map
        for member_name, member_data in members.items():
            target_map[member_name] = VariableInfo(
                name=member_name,
                byte_size=member_data["byte_size"],
                bit_size=member_data["bit_size"],
                bit_offset=member_data["bit_offset"],
                type=member_data["type"],
                address=self.address + member_data["address_offset"],
                array_size=member_data["array_size"],
                valid_values=member_data["valid_values"],
            )

        if self.is_sfr:
            self._add_sfr_aliases(self.var_name, target_map)

    @staticmethod
    def _get_sfr_alias_names(register_name: str, member_name: str) -> list[str]:
        """Return alternate names for SFR bitfield members."""
        aliases = []
        if "." not in member_name:
            return aliases

        member_leaf = member_name.split(".")[-1]
        aliases.append(member_leaf)

        return aliases

    def _add_sfr_aliases(self, register_name: str, target_map: dict[str, VariableInfo]):
        """Add convenience aliases for parsed SFR bitfield members."""
        register_entries = list(target_map.items())
        for member_name, variable_info in register_entries:
            if not member_name.startswith(register_name + "."):
                continue
            for alias_name in self._get_sfr_alias_names(register_name, member_name):
                if alias_name not in target_map:
                    target_map[alias_name] = VariableInfo(
                        name=alias_name,
                        type=variable_info.type,
                        byte_size=variable_info.byte_size,
                        bit_size=variable_info.bit_size,
                        bit_offset=variable_info.bit_offset,
                        address=variable_info.address,
                        array_size=variable_info.array_size,
                        valid_values=variable_info.valid_values,
                    )

    def _get_base_type_die(self, current_die):
        """Find the base type die regarding the current selected die, i.e. array_type."""
        type_attr = current_die.attributes.get("DW_AT_type")
        if type_attr:
            ref_addr = type_attr.value + current_die.cu.cu_offset
            return self.dwarf_info.get_DIE_from_refaddr(ref_addr)
        return None

    def _get_end_die(self, current_die):
        """Find the end DIE of a type iteratively."""
        ref_addr = None
        end_die = current_die
        valid_tags = {
            "DW_TAG_base_type",
            "DW_TAG_pointer_type",
            "DW_TAG_structure_type",
            "DW_TAG_array_type",
            "DW_TAG_enumeration_type",
            "DW_TAG_union_type"
        }
        while end_die and end_die.tag not in valid_tags:
            type_attr = end_die.attributes.get("DW_AT_type")
            if not type_attr:
                logging.warning(f"Skipping DIE at offset {current_die.offset} with no 'DW_AT_type'")
                return None, None
            ref_addr = type_attr.value + end_die.cu.cu_offset
            end_die = self.dwarf_info.get_DIE_from_refaddr(ref_addr)
        return end_die, ref_addr

    def _extract_address_from_expression(self, expr_value, structs):
        """Extracts an address from DWARF expression.

        Args:
            expr_value: The raw DWARF expression bytes.
            structs: The DWARF structs used for parsing expressions.

        Returns:
            int or None: The extracted address, or None if it couldn't be determined.
        """
        try:
            expression = DWARFExprParser(structs).parse_expr(expr_value)
            for op in expression:
                if op.op_name in {"DW_OP_plus_uconst", "DW_OP_plus_const", "DW_OP_addr"}:
                    return op.args[0]
        except TypeError as e:
            logging.warning(f"Error parsing DWARF expression: {e}")
        return None

    def _extract_address(self, die_variable):
        """Extracts the address of the current variable or fetches it from the symbol table if not found."""
        try:
            if "DW_AT_location" in die_variable.attributes:
                expr_value = die_variable.attributes["DW_AT_location"].value
                return self._extract_address_from_expression(
                    expr_value, die_variable.cu.structs
                )
            else:
                return self._fetch_address_from_symtab(
                    die_variable.attributes.get("DW_AT_name").value.decode("utf-8")
                )
        except Exception as e:
            logging.error(e)
            return None

    def _load_symbol_table(self):
        """Loads symbol table entries into a dictionary for fast access."""
        all_symbol_names = []
        for section in self.elf_file.iter_sections():
            if isinstance(section, SymbolTableSection):
                for symbol in section.iter_symbols():
                    all_symbol_names.append(symbol.name)
                    if symbol.name:
                        self.symbol_table[symbol.name] = symbol["st_value"]
                        if symbol["st_shndx"] == "SHN_ABS":
                            self.absolute_symbol_table[symbol.name] = {
                                "address": symbol["st_value"],
                                "size": symbol["st_size"],
                                "type": symbol["st_info"].type,
                                "bind": symbol["st_info"].bind,
                            }
        self.target_signature = self._infer_target_signature(all_symbol_names)

    def _infer_target_signature(self, symbol_names):
        """Infer a more specific target signature from the ELF symbol table."""
        symbol_names = "\n".join(symbol_names).upper()
        for signature, markers in TARGET_SIGNATURE_PATTERNS:
            if any(marker in symbol_names for marker in markers):
                return signature
        return self.get_target_family()

    def _fetch_address_from_symtab(self, variable_name):
        """Fetches the address of a variable from the preloaded symbol table."""
        candidates = [variable_name]
        if not variable_name.startswith("_"):
            candidates.append("_" + variable_name)
        else:
            candidates.append(variable_name[1:])

        for candidate in candidates:
            if candidate in self.symbol_table:
                return self.symbol_table[candidate]
        return None

    def _find_actual_declaration(self, die_variable):
        """Find the actual declaration of an extern variable."""
        while "DW_AT_specification" in die_variable.attributes:
            spec_ref_addr = (
                die_variable.attributes["DW_AT_specification"].value
                + die_variable.cu.cu_offset
            )
            die_variable = self.dwarf_info.get_DIE_from_refaddr(spec_ref_addr)
        return die_variable

    def _get_member_offset(self, die) -> tuple[int | None, int, int]:
        """Extracts the offset for a structure member.

        Args:
            die: The DIE of the structure member.

        Returns:
            int, int, int: The offset value, the bit_size (union) and bit offset (union).
        """
        offset = None
        bit_size = 0
        bit_offset = 0
        if "DW_AT_data_member_location" in die.attributes:
            data_member_location = die.attributes.get("DW_AT_data_member_location")
            if "DW_AT_bit_size" in die.attributes:
                bit_size = die.attributes.get("DW_AT_bit_size").value
                bit_offset = die.attributes.get("DW_AT_bit_offset").value
            offset = data_member_location.value
            if isinstance(offset, int):
                return offset, bit_size, bit_offset
            if isinstance(offset, ListContainer):
                offset = self._extract_address_from_expression(offset, die.cu.structs)
                return offset, bit_size, bit_offset
            else:
                logging.warning(f"Unknown data_member_location value: {offset}")
        return offset, bit_size, bit_offset

    def _process_array_type(self, end_die, member_name, offset):
        """Process array type members recursively.

        The easiest implementation is the array of primitives, which contains only primitives,
        e.g.: char my_array[10]. In this case, function _process_end_die(...) will return the
        variable 'members' with only one element. Considering multidimensional arrays, arrays of
        structs, and arrays of unions, the variable 'members' will have multiple elements, that should
        be considered when calculating the size of the main array element. Afterward, each element need
        to be added as single indexed element in the array_members variable.
        """
        members = {}
        array_members = {}
        array_dimensions = self._get_array_dimensions(end_die)
        array_size = math.prod(array_dimensions)
        base_type_die = self._get_base_type_die(end_die)
        self._process_end_die(members, base_type_die, member_name, offset)
        if members:
            idx_size = sum(item["byte_size"] for item in members.values())
            # Generate array variable
            array_members[member_name] = {
                "type": members[next(iter(members))]["type"] if len(members) == 1 else "array",
                "byte_size": array_size * idx_size,
                "bit_size": 0,
                "bit_offset": 0,
                "address_offset": offset,
                "array_size": array_size,  # Individual elements aren't arrays
                "valid_values": {}
            }

            # Generate array members, e.g.: array[0], array[1], ..., array[i]
            ranges = [range(d) for d in array_dimensions]
            for idx, idx_tuple in enumerate(product(*ranges)):
                idx_str = ''.join(f'[{i}]' for i in idx_tuple)
                for name, values in members.items():
                    element_name = name + idx_str
                    array_members[element_name] = values.copy()
                    array_members[element_name]["address_offset"] += idx * idx_size

        return array_members

    def _process_end_die(self, members, child_die, parent_name, offset):
        """Process the current die according to its tag.

        A variable can be a primitive or can have multiple children, e.g., a struct or and array of structs.
        After calling this method, members is populated with details of the variable and its children.
        """
        end_die, type_ref_addr = self._get_end_die(child_die)
        if end_die is None:
            return

        nested_member = {}
        if end_die.tag == "DW_TAG_pointer_type":
            pass
        elif end_die.tag == "DW_TAG_enumeration_type":
            nested_member = self._process_enum_type(end_die, parent_name, offset)
        elif end_die.tag == "DW_TAG_array_type":
            nested_member = self._process_array_type(end_die, parent_name, offset)
        elif end_die.tag == "DW_TAG_structure_type":
            nested_member = self._process_structure_type(end_die, parent_name, offset)
        elif end_die.tag == "DW_TAG_union_type":
            nested_member = self._process_union_type(end_die, parent_name, offset)
        else:
            nested_member = self._process_base_type(end_die, parent_name, offset)

        members.update(nested_member)
        return

    @staticmethod
    def _process_enum_type(end_die, parent_name, offset):
        """Process an enum type variable and map its members."""
        enum_name_attr = end_die.attributes.get("DW_AT_name")
        enum_name = (
            enum_name_attr.value.decode("utf-8") if enum_name_attr else "anonymous_enum"
        )

        # Dictionary to store enum member names and values
        enum_members = {}
        for child in end_die.iter_children():
            if child.tag == "DW_TAG_enumerator":
                name_attr = child.attributes.get("DW_AT_name")
                value_attr = child.attributes.get("DW_AT_const_value")
                if name_attr and value_attr:
                    member_name = name_attr.value.decode("utf-8")
                    member_value = value_attr.value
                    enum_members[member_name] = member_value

        return {
            parent_name: {
                "type": f"enum {enum_name}",
                "byte_size": end_die.attributes.get("DW_AT_byte_size", 0).value,
                "bit_size" : 0,
                "bit_offset" : 0,
                "address_offset": offset,
                "array_size": 0,
                "valid_values": enum_members
            }
        }

    def _process_union_type(self, die, parent_name: str, offset=0):
        """Recursively extracts union members from a DWARF DIE."""
        members = {}
        for child_die in die.iter_children():
            member = {}
            if child_die.tag == "DW_TAG_member":
                member_name = parent_name
                name_attr = child_die.attributes.get("DW_AT_name")
                if name_attr:
                    member_name += "." + name_attr.value.decode("utf-8")
                self._process_end_die(member, child_die, member_name, offset)
                members.update(member)
        return members

    def _process_structure_type(self, die, parent_name: str, offset=0):
        """Recursively extracts structure members from a DWARF DIE, including arrays."""
        members = {}
        for child_die in die.iter_children():
            member = {}
            if child_die.tag == "DW_TAG_member":
                member_offset, bit_size, bit_offset = self._get_member_offset(child_die)
                if member_offset is None:
                    continue
                member_name = parent_name
                name_attr = child_die.attributes.get("DW_AT_name")
                if name_attr:
                    member_name += "." + name_attr.value.decode("utf-8")
                self._process_end_die(member, child_die, member_name, offset + member_offset)
                # in case of a union, here is the location where the bit size and offset are registered.
                # on later versions of DWARF, it is available on the base type.
                if bit_size:
                    member[member_name]["bit_size"] = bit_size
                    member[member_name]["bit_offset"] = bit_offset
                members.update(member)
        return members

    @staticmethod
    def _get_array_dimensions(type_die):
        """Gets the length of an array type.

        Multidimensional arrays have multiple children with the tag DW_TAG_subrange_type.
        """
        dimensions = []
        for child in type_die.iter_children():
            if child.tag == "DW_TAG_subrange_type":
                array_length_attr = child.attributes.get("DW_AT_upper_bound")
                if array_length_attr:
                    dimensions.append(array_length_attr.value + 1)
        return dimensions

    @staticmethod
    def _process_base_type(end_die, parent_name, offset):
        """Process a base type variable."""
        type_name_attr = end_die.attributes.get("DW_AT_name")
        type_name = type_name_attr.value.decode("utf-8") if type_name_attr else "base unknown"
        byte_size_attr = end_die.attributes.get("DW_AT_byte_size")
        byte_size = byte_size_attr.value if byte_size_attr else None
        return {
            parent_name: {
                "type": type_name,
                "byte_size": byte_size,
                "bit_size": 0,
                "bit_offset": 0,
                "address_offset": offset,
                "array_size": 0,
                "valid_values": {}
            }
        }

    def _get_dwarf_die_by_offset(self, offset):
        """Retrieve a DWARF DIE given its offset."""
        for compilation_unit in self.dwarf_info.iter_CUs():
            root_die = compilation_unit.iter_DIEs()
            for die in root_die:
                if die.offset == offset:
                    return die
        return None

    def _map_registers(self) -> dict[str, VariableInfo]:
        """No-op: register_map is populated as part of _map_variables() in a single pass.

        Both firmware variables and peripheral registers (SFRs) are processed together
        in ``_map_variables()``. The ``self.is_sfr`` flag set in ``_get_die_variable()``
        determines which map each entry is written to inside ``_process_die()``.
        """
        return self.register_map

    def _get_symbol_only_register_byte_size(self) -> int:
        """Return a best-effort byte size for symbol-only SFR entries."""
        signature = self.get_target_signature()
        family = self.get_target_family()
        return FAMILY_REGISTER_BYTE_SIZE.get(signature, FAMILY_REGISTER_BYTE_SIZE.get(family, 2))

    @staticmethod
    def _get_symbol_only_register_type(byte_size: int) -> str:
        """Return the variable type string for a symbol-only SFR entry."""
        type_by_size = {
            1: "unsigned char",
            2: "unsigned int",
            4: "unsigned long",
            8: "unsigned long long",
        }
        return type_by_size.get(byte_size, "unsigned int")

    def _map_symbol_only_registers(self):
        """Populate missing SFRs from absolute symbol-table entries when DWARF lacks variables."""
        byte_size = self._get_symbol_only_register_byte_size()
        for symbol_name, symbol_data in self.absolute_symbol_table.items():
            if not REGISTER_SYMBOL_PATTERN.fullmatch(symbol_name):
                continue
            if symbol_name in self.register_map:
                continue
            self.register_map[symbol_name] = VariableInfo(
                name=symbol_name,
                type=self._get_symbol_only_register_type(byte_size),
                byte_size=byte_size,
                bit_size=0,
                bit_offset=0,
                address=symbol_data["address"],
                array_size=0,
                valid_values={},
            )

    def _map_variables(self) -> dict[str, VariableInfo]:
        """Maps all variables in the ELF file."""
        self.variable_map.clear()
        self.register_map.clear()
        for cu in self.dwarf_info.iter_CUs():
            for die in filter(lambda d: d.tag == "DW_TAG_variable", cu.iter_DIEs()):
                self.expression_parser = DWARFExprParser(die.cu.structs)
                self._process_die(die)

        self._map_symbol_only_registers()

        return self.variable_map


if __name__ == "__main__":

    # elf_file = r"..\..\tests\data\qspin_foc_same54.elf"
    elf_file = r"..\..\..\tests\data\dsPIC33ak128mc106_foc.elf"
    elf_reader = GenericParser(elf_file)
    variable_map = elf_reader._map_variables()
    register_map = elf_reader._map_registers()

    print(variable_map)
    print(len(variable_map))
    print("'''''''''''''''''''''''''''''''''''''''' ")

    print("Array variables:")
    for var_info in variable_map.values():
        if var_info.array_size > 0:
            print(var_info)
    print("'''''''''''''''''''''''''''''''''''''''' ")

    print("register variables:")
    print(register_map)
    print(len(register_map))
    print("'''''''''''''''''''''''''''''''''''''''' ")
