import hmac
import hashlib
import secrets
from typing import Any, Callable, Optional, Dict
from railpy.core.context import Context

class SessionOpts:
    def __init__(
        self,
        secret: str,
        cookie_name: str = "sid",
        max_age: int = 86400,  # 24 hours
        secure: bool = False,
        same_site: str = "lax",
        store: Optional[Dict[str, Any]] = None
    ):
        self.secret = secret
        self.cookie_name = cookie_name
        self.max_age = max_age
        self.secure = secure
        self.same_site = same_site
        self.store: Dict[str, Any] = store if store is not None else {}

def session(options: SessionOpts):
    """
    Session middleware with HMAC-signed cookies to prevent tampering.
    """

    # --- Helper: generate HMAC signature ---
    def sign(val: str) -> str:
        return hmac.new(
            options.secret.encode(),
            val.encode(),
            hashlib.sha256
        ).hexdigest()

    async def middleware(ctx: Context, next_fn: Optional[Callable] = None):
        # --- 1. Parse cookies from header ---
        raw_cookie = ctx.get_header("cookie") or ""
        cookies: Dict[str, str] = {}
        for item in raw_cookie.split(";"):
            if "=" in item:
                k, v = item.strip().split("=", 1)
                cookies[k] = v

        sid_raw = cookies.get(options.cookie_name)
        sid: Optional[str] = None

        # --- 2. Verify HMAC signature (anti-tamper) ---
        if sid_raw and "." in sid_raw:
            id_part, sig_part = sid_raw.split(".", 1)
            if hmac.compare_digest(sig_part, sign(id_part)):
                sid = id_part

        # --- 3. Generate new SID if missing or invalid ---
        if not sid:
            sid = secrets.token_hex(16)

        # --- 4. Attach session data to context ---
        if sid not in options.store:
            options.store[sid] = {}

        ctx.state["session"] = options.store[sid]

        # --- 5. Continue to next middleware/handler ---
        if next_fn:
            await next_fn()

        # --- 6. Persist session back to store ---
        options.store[sid] = ctx.state["session"]

        # --- 7. Set signed cookie in response ---
        signed_sid = f"{sid}.{sign(sid)}"
        cookie_str = (
            f"{options.cookie_name}={signed_sid}; "
            f"Max-Age={options.max_age}; "
            f"Path=/; "
            f"SameSite={options.same_site}; "
            "HttpOnly"
        )
        if options.secure:
            cookie_str += "; Secure"

        ctx.set("Set-Cookie", cookie_str)

    return middleware