# middlewares/body_parser.py
import json
import urllib.parse
from typing import Callable, Optional

from multipart import MultipartParser
from multipart.multipart import parse_options_header

from railpy.core.context import Context

async def body_parser(ctx: Context, next_fn: Optional[Callable] = None):
    """
    Universal body parser middleware.

    Supports:
    - application/json
    - application/x-www-form-urlencoded
    - multipart/form-data

    Injects parsed data into:
        ctx.data["body"]
    """
    if ctx.method.upper() in ["GET", "HEAD", "OPTIONS"]:
        if next_fn:
            return await next_fn()
        return

    content_type = (ctx.get_header("content-type") or "").lower()
    ctx.data["body"] = {}

    try:
        # ======================
        # JSON
        # ======================
        if "application/json" in content_type:
            raw = await ctx.req.body()
            if raw:
                ctx.data["body"] = json.loads(raw)

        # ======================
        # URL ENCODED
        # ======================
        elif "application/x-www-form-urlencoded" in content_type:
            raw = (await ctx.req.body()).decode()
            parsed = urllib.parse.parse_qs(raw, keep_blank_values=True)
            # flatten single-value lists
            ctx.data["body"] = {k: v[0] if len(v) == 1 else v for k, v in parsed.items()}

        # ======================
        # MULTIPART
        # ======================
        elif "multipart/form-data" in content_type:
            raw = await ctx.req.body()
            _, params = parse_options_header(content_type)
            boundary = params.get(b"boundary")
            if not boundary:
                raise ValueError("Missing multipart boundary")
            boundary = boundary.decode() if isinstance(boundary, bytes) else boundary

            body = {}
            current_name = None
            current_file = None
            headers = {}

            def on_part_begin():
                nonlocal current_name, current_file, headers
                current_name = None
                current_file = None
                headers = {}

            def on_header_field(data, start, end):
                nonlocal headers
                headers['field'] = data[start:end].decode().lower()

            def on_header_value(data, start, end):
                nonlocal headers, current_name
                value = data[start:end].decode()
                headers[headers['field']] = value
                # Parse name from Content-Disposition
                if headers['field'] == 'content-disposition':
                    parts = value.split(";")
                    for part in parts:
                        part = part.strip()
                        if part.startswith("name="):
                            current_name = part.split("=", 1)[1].strip('"')

            def on_part_data(data, start, end):
                nonlocal current_name, body
                if not current_name:
                    return
                chunk = data[start:end]
                if current_name in body:
                    if isinstance(body[current_name], bytes):
                        body[current_name] += chunk
                    else:
                        body[current_name] = chunk
                else:
                    body[current_name] = chunk

            def on_part_end():
                pass

            callbacks = {
                "on_part_begin": on_part_begin,
                "on_header_field": on_header_field,
                "on_header_value": on_header_value,
                "on_part_data": on_part_data,
                "on_part_end": on_part_end,
            }

            parser = MultipartParser(boundary, callbacks)  # type: ignore
            parser.write(raw)
            parser.finalize()
            ctx.data["body"] = body

    except json.JSONDecodeError:
        ctx.status = 400
        ctx.send("Invalid JSON format")
        return

    except Exception as e:
        ctx.status = 400
        ctx.send(f"Body parsing failed: {str(e)}")
        return

    if next_fn:
        await next_fn()