from typing import Callable, List, Optional, Union
from railpy.core.context import Context

OriginType = Union[str, Callable[[Optional[str]], Optional[str]]]

class CorsOpts:
    def __init__(
        self,
        origin: OriginType = "*",
        methods: Optional[List[str]] = None,
        headers: Optional[List[str]] = None,
        credentials: bool = False,
        max_age: int = 86400,  # seconds
    ):
        self.origin = origin
        self.methods = methods or ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"]
        self.headers = headers or ["Content-Type", "Authorization"]
        self.credentials = credentials
        self.max_age = max_age

def cors(options: Optional[CorsOpts] = None):
    opts = options or CorsOpts()

    async def middleware(ctx: Context, next_fn: Optional[Callable] = None):
        # Resolve origin
        request_origin = ctx.get_header("origin")
        resolved_origin = opts.origin(request_origin) if callable(opts.origin) else opts.origin

        # Set CORS headers
        ctx.set("Access-Control-Allow-Origin", resolved_origin or "*")
        if opts.credentials:
            ctx.set("Access-Control-Allow-Credentials", "true")
        ctx.set("Access-Control-Allow-Methods", ", ".join([m.upper() for m in opts.methods]))

        req_headers = ctx.get_header("access-control-request-headers")
        if req_headers:
            ctx.set("Access-Control-Allow-Headers", req_headers)
        else:
            ctx.set("Access-Control-Allow-Headers", ", ".join([h.strip() for h in opts.headers]))

        ctx.set("Vary", "Origin")
        ctx.set("Access-Control-Max-Age", str(opts.max_age))

        # Pre-flight
        if ctx.method.upper() == "OPTIONS":
            ctx.no_content()  # 204
            return

        if next_fn:
            await next_fn()

    return middleware