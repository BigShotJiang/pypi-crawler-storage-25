import json
from typing import Callable, Optional
from railpy.core.context import Context

class JsonOpts:
    def __init__(self, limit: int = 1_000_000, strict: bool = True):
        self.limit = limit
        self.strict = strict

def json_parser(options: Optional[JsonOpts] = None):
    """
    Middleware to parse JSON bodies with size limits and strict checking.
    """
    opts = options or JsonOpts()

    async def middleware(ctx: Context, next_fn: Optional[Callable] = None):
        if ctx.method.upper() in ["GET", "HEAD"]:
            if next_fn:
                return await next_fn()
            return

        content_type = (ctx.get_header("content-type") or "").lower().strip()
        if "application/json" not in content_type:
            if next_fn:
                return await next_fn()
            return

        try:
            content_length = int(ctx.get_header("content-length") or 0)
            if content_length > opts.limit:
                ctx.status = 413
                ctx.set("Content-Type", "application/json")
                ctx.send(json.dumps({"success": False, "error": "Payload too large"}))
                return

            raw_body = await ctx.req.body()

            if len(raw_body) > opts.limit:
                ctx.status = 413
                ctx.set("Content-Type", "application/json")
                ctx.send(json.dumps({"success": False, "error": "Payload too large"}))
                return

            if not raw_body:
                ctx.data["body"] = {}
                if next_fn:
                    return await next_fn()
                return

            # Parse JSON
            try:
                body = json.loads(raw_body)
                if opts.strict and not isinstance(body, (dict, list)):
                    ctx.status = 400
                    ctx.set("Content-Type", "application/json")
                    ctx.send(json.dumps({"success": False, "error": "Invalid JSON: Root must be object or array"}))
                    return

                ctx.data["body"] = body

            except json.JSONDecodeError:
                ctx.status = 400
                ctx.set("Content-Type", "application/json")
                ctx.send(json.dumps({"success": False, "error": "Invalid JSON format"}))
                return

        except Exception as e:
            ctx.status = 400
            ctx.set("Content-Type", "application/json")
            ctx.send(json.dumps({"success": False, "error": f"Error parsing body: {str(e)}"}))
            return

        if next_fn:
            await next_fn()

    return middleware