import os
import mimetypes
from railpy.core.context import Context
from typing import Callable, Optional

def serve_static(root_dir: str):
    """
    Middleware to serve static files safely.

    - Serves only GET/HEAD requests
    - Prevents directory traversal
    - Sets proper Content-Type based on file extension
    """
    abs_root = os.path.abspath(root_dir)

    async def middleware(ctx: Context, next_fn: Optional[Callable] = None):
        # 1. Only handle GET/HEAD requests
        if ctx.method not in ["GET", "HEAD"]:
            if next_fn:
                return await next_fn()
            return

        # 2. Resolve requested file path
        file_path = os.path.abspath(os.path.join(abs_root, ctx.path.lstrip("/")))

        # 3. Prevent directory traversal attacks
        if not file_path.startswith(abs_root):
            ctx.status = 403
            ctx.body = b"Access denied"
            ctx.set("Content-Type", "text/plain")
            return

        # 4. Serve file if exists
        if os.path.isfile(file_path):
            mime_type, _ = mimetypes.guess_type(file_path)
            ctx.set("Content-Type", mime_type or "application/octet-stream")

            # Read file in binary mode
            with open(file_path, "rb") as f:
                ctx.body = f.read()

            return  # Stop pipeline

        # 5. Continue to next middleware/handler if file not found
        if next_fn:
            await next_fn()

    return middleware