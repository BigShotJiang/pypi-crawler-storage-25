from typing import Callable, Optional
from railpy.core.context import Context
import traceback
import json

async def error_handler(ctx: Context, next_fn: Optional[Callable] = None):
    """
    Global error boundary middleware.
    Should be placed at the top of the middleware stack.
    """
    try:
        if next_fn:
            await next_fn()
    except Exception as e:
        # Log full stack trace
        print("[CRITICAL ERROR]:", traceback.format_exc())

        # Set JSON response
        ctx.status = 500
        ctx.set("Content-Type", "application/json")
        ctx.send(json.dumps({
            "success": False,
            "error": "Internal Server Error",
            "message": str(e)
        }))