from urllib.parse import urlparse, parse_qs
from typing import Callable, Optional
from railpy.core.context import Context

def query_parser():
    """
    Middleware to parse the query string from the request URL.
    Results are stored in ctx.query as a flat dictionary.
    """
    async def middleware(ctx: Context, next_fn: Optional[Callable] = None):
        # 1. Get the raw query string from ASGI scope
        # Railpy's ASGIRequest already provides access to the scope
        query_string = ctx.req.scope.get("query_string", b"").decode("utf-8")

        if query_string:
            # 2. Parse query string into a dictionary
            # parse_qs returns List[str] for each key, we take the first element for simplicity
            # e.g., ?page=1&page=2 -> {"page": "1"}
            parsed = parse_qs(query_string, keep_blank_values=True)
            ctx.query = {k: v[0] for k, v in parsed.items()}
        else:
            ctx.query = {}

        # 3. Continue to the next middleware
        if next_fn:
            await next_fn()

    return middleware