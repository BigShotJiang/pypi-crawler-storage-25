import time
from typing import Callable, Optional
from railpy.core.context import Context
from datetime import datetime

async def logger(ctx: Context, next_fn: Optional[Callable] = None, log_body: bool = False):
    """
    Request/Response logging middleware.
    Measures execution time and logs request details to the console.
    """
    start_time = time.perf_counter()
    method = ctx.method.upper()
    path = ctx.path
    query = getattr(ctx, "query", {})

    # Log incoming request
    timestamp = datetime.utcnow().isoformat()
    log_msg = f"{timestamp} [→] {method} {path}"
    if query:
        log_msg += f"?{query}"
    if log_body and hasattr(ctx.data, "body"):
        log_msg += f" | body: {ctx.data.get('body')}"
    print(log_msg)

    try:
        if next_fn:
            await next_fn()
    finally:
        # Calculate duration in milliseconds
        duration = (time.perf_counter() - start_time) * 1000
        print(f"{timestamp} [←] {method} {path} - {ctx.status} ({duration:.2f}ms)")