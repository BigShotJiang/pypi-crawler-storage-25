import time
from typing import Callable, Optional, Dict
from railpy.core.context import Context

# In-memory store for rate limits (per IP)
rate_store: Dict[str, Dict[str, float]] = {}

def rate_limit(limit: int = 100, window_ms: int = 60000):
    """
    Fixed-window rate limiting middleware.
    limit: max requests per IP
    window_ms: window duration in milliseconds
    """
    async def middleware(ctx: Context, next_fn: Optional[Callable] = None):
        # 1. Identify client IP
        forwarded = ctx.get_header("x-forwarded-for")
        if forwarded:
            ip = forwarded.split(",")[0].strip()
        else:
            client = ctx.req.scope.get("client")
            ip = client[0] if client else None
            if not ip:
                ip = "unknown"
                print("[WARNING] Cannot determine client IP for rate limiting")

        # 2. Current time in ms
        now = time.time() * 1000

        # 3. Get or init record
        record = rate_store.get(ip, {"count": 0, "start_time": now})

        # 4. Reset window if expired
        if now - record["start_time"] > window_ms:
            record = {"count": 0, "start_time": now}

        # 5. Increment count and update store
        record["count"] += 1
        rate_store[ip] = record

        # 6. Check limit
        if record["count"] > limit:
            retry_after = int((window_ms - (now - record["start_time"])) / 1000)
            ctx.status = 429
            ctx.set("Retry-After", str(retry_after))
            ctx.send({
                "success": False,
                "error": "Too Many Requests",
                "message": f"Rate limit exceeded. Try again in {retry_after}s."
            })
            return

        # 7. Continue
        if next_fn:
            await next_fn()

    return middleware