from typing import Callable, Optional
from railpy.core.context import Context

def normalize_headers(lower_case: bool = True):
    """
    Middleware to normalize request headers.
    Converts all header keys to lowercase for consistent access.
    Stores result in ctx.req.normalized_headers.
    """
    async def middleware(ctx: Context, next_fn: Optional[Callable] = None):
        headers = ctx.req.headers or {}
        if lower_case:
            normalized = {}
            for k, v in headers.items():
                key = k.lower() if isinstance(k, str) else str(k)
                value = v if isinstance(v, str) else str(v)
                normalized[key] = value
            ctx.req.normalized_headers = normalized
        else:
            ctx.req.normalized_headers = headers

        if next_fn:
            await next_fn()

    return middleware