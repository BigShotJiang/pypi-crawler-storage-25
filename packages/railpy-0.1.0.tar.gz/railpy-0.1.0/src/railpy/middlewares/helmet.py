from typing import Callable, Optional
from railpy.core.context import Context

async def helmet(ctx: Context, next_fn: Optional[Callable] = None):
    """
    Standard Security Headers Middleware (Helmet-style).
    Protects against common web vulnerabilities.
    """
    # 1. Prevent Clickjacking
    ctx.set("X-Frame-Options", "DENY")

    # 2. Prevent XSS attacks in older browsers
    ctx.set("X-XSS-Protection", "1; mode=block")

    # 3. Prevent MIME-type sniffing
    ctx.set("X-Content-Type-Options", "nosniff")

    # 4. Strict Transport Security (HSTS) - Only for HTTPS
    if ctx.req.scope.get("scheme") == "https":
        ctx.set("Strict-Transport-Security", "max-age=15552000; includeSubDomains")

    # 5. Content Security Policy (CSP)
    ctx.set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self';")

    # 6. Optional: Referrer Policy & Permissions Policy
    ctx.set("Referrer-Policy", "no-referrer")
    ctx.set("Permissions-Policy", "geolocation=(), camera=()")

    if next_fn:
        await next_fn()