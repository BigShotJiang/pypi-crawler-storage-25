import jwt
from typing import Callable, Optional, List
from railpy.core.context import Context

def jwt_auth(secret: str, mandatory: bool = True, algorithms: Optional[List[str]] = None):
    """
    JWT authentication middleware for Railpy.
    Injects decoded payload into ctx.data["user"].
    """
    algorithms = algorithms or ["HS256"]

    async def middleware(ctx: Context, next_fn: Optional[Callable] = None):
        auth_header = (ctx.get_header("authorization") or "").strip()

        # 1. Validate header presence and format
        if not auth_header or not auth_header.startswith("Bearer "):
            if mandatory:
                ctx.status = 401
                ctx.set("Content-Type", "application/json")
                ctx.send({"success": False, "error": "Unauthorized: Missing token"})
                return
            if next_fn:
                return await next_fn()
            return

        # 2. Token decoding and validation
        try:
            token = auth_header.split(" ")[1]
            payload = jwt.decode(token, secret, algorithms=algorithms)
            ctx.data["user"] = payload

        except jwt.ExpiredSignatureError:
            ctx.status = 401
            ctx.set("Content-Type", "application/json")
            ctx.send({"success": False, "error": "Token expired"})
            return
        except jwt.InvalidTokenError:
            ctx.status = 401
            ctx.set("Content-Type", "application/json")
            ctx.send({"success": False, "error": "Invalid token"})
            return
        except Exception as e:
            ctx.status = 500
            ctx.set("Content-Type", "application/json")
            ctx.send({"success": False, "error": str(e)})
            return

        # 3. Proceed to next middleware/handler
        if next_fn:
            await next_fn()

    return middleware