import asyncio

class Hooks:
    def __init__(self):
        self.map = {
            "request": [],
            "response": [],
            "error": []
        }

    def on(self, name: str, fn):
        """Register a hook"""
        if name not in self.map:
            raise ValueError(f"Hook '{name}' does not exist")
        self.map[name].append(fn)

    async def run(self, name: str, ctx, err=None):
        """Run all hooks; supports sync and async functions, catches individual hook errors"""
        for fn in self.map.get(name, []):
            try:
                if asyncio.iscoroutinefunction(fn):
                    await fn(ctx, err)
                else:
                    fn(ctx, err)
            except Exception as e:
                # Log error but continue with other hooks
                print(f"[Hooks:{name}] Error in hook {fn.__name__}: {e}")