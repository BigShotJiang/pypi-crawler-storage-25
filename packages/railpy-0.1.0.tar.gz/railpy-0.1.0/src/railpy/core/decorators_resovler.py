import inspect
import functools
import re
from typing import Any, Callable, List, Optional, Type
from pydantic import BaseModel, ValidationError

from .context import Context
from .pipeline import PipelineBuilder
from .decorators import (
    PARAMS, PREFIX, MIDDLEWARES, PIPELINE, ERROR,
    VALIDATE_BODY, VALIDATE_QUERY, VALIDATE_PARAM, ROUTE
)

HandlerFn = Callable[..., Any]

class DecoratorsResolver:
    def __init__(self, app: Any):
        self.app = app

    async def resolve_params(self, fn: HandlerFn, ctx: Context) -> List[Any]:
        """
        Injects arguments into the controller method based on 
        Pydantic schemas, decorators, or naming conventions.
        """
        sig = inspect.signature(fn)
        args = []

        # 1. Fetch Schema Metadata
        body_model = getattr(fn, VALIDATE_BODY, None)
        query_model = getattr(fn, VALIDATE_QUERY, None)
        param_model = getattr(fn, VALIDATE_PARAM, None)

        param_meta = getattr(fn, PARAMS, [])
        meta_i = 0

        # 2. Pre-validate Query and Path Params if schemas exist
        validated_query = None
        if query_model:
            try:
                validated_query = query_model(**ctx.query)
            except ValidationError as e:
                ctx.status = 422
                ctx.json({"errors": e.errors(), "source": "query"})
                raise ValueError(f"Query validation failed")

        validated_param = None
        if param_model:
            try:
                validated_param = param_model(**ctx.params)
            except ValidationError as e:
                ctx.status = 422
                ctx.json({"errors": e.errors(), "source": "params"})
                raise ValueError(f"Param validation failed")

        # 3. Iterate over function parameters to inject values
        for name, param in sig.parameters.items():
            if name == "self": continue
            if name == "ctx":
                args.append(ctx)
                continue

            # A. Body Validation (Pydantic)
            if body_model and issubclass(param.annotation, BaseModel):
                args.append(await ctx.validate(body_model))
                continue

            # B. Query Object Injection
            if query_model and issubclass(param.annotation, query_model):
                args.append(validated_query)
                continue

            # C. Path Param Object Injection
            if param_model and issubclass(param.annotation, param_model):
                args.append(validated_param)
                continue

            # D. Individual extraction from Metadata or Context
            raw_val = None
            if meta_i < len(param_meta):
                meta = param_meta[meta_i]
                if meta["type"] == "param":
                    raw_val = ctx.params.get(meta["key"])
                elif meta["type"] == "header":
                    raw_val = ctx.get_header(meta["key"])
                elif meta["type"] == "query":
                    raw_val = ctx.query.get(meta["key"])
                meta_i += 1
            elif name in ctx.params:
                raw_val = ctx.params[name]
            elif name in ctx.query:
                raw_val = ctx.query[name]

            # E. Simple Auto-Casting for individual fields
            if raw_val is not None and param.annotation is not inspect.Parameter.empty:
                try:
                    args.append(param.annotation(raw_val))
                except (ValueError, TypeError):
                    args.append(raw_val)
            else:
                args.append(raw_val)

        return args

    def register(self, controller_cls: Type):
        """
        Scans the controller class for routed methods and binds them to the app.
        """
        instance = controller_cls()
        prefix = getattr(controller_cls, PREFIX, "")
        controller_mw = getattr(controller_cls, MIDDLEWARES, [])

        for attr in dir(instance):
            fn = getattr(instance, attr)
            route_meta = getattr(fn, ROUTE, None)
            if not route_meta: continue

            method, path = route_meta

            # Normalize path
            full_path = f"/{prefix}/{path}"
            full_path = re.sub(r'/+', '/', full_path).rstrip("/") or "/"

            pipeline_fn = getattr(fn, PIPELINE, None)
            pipeline_mw = PipelineBuilder().apply(pipeline_fn).build() if pipeline_fn else []
            error_handler = getattr(fn, ERROR, None)

            handler = self._create_handler(instance, fn, error_handler)

            # Sync Metadata to the wrapped handler for OpenAPI/Swagger
            setattr(handler, PARAMS, getattr(fn, PARAMS, []))
            setattr(handler, VALIDATE_BODY, getattr(fn, VALIDATE_BODY, None))
            setattr(handler, VALIDATE_QUERY, getattr(fn, VALIDATE_QUERY, None))
            setattr(handler, VALIDATE_PARAM, getattr(fn, VALIDATE_PARAM, None))

            route_mw = getattr(fn, MIDDLEWARES, [])
            stack = [*controller_mw, *route_mw, *pipeline_mw, handler]

            self.app.route(method, full_path, *stack)

    def _create_handler(self, instance: Any, fn: HandlerFn, error_handler: Optional[Callable]):
        """
        Wraps the controller method into an ASGI-compatible middleware.
        """
        @functools.wraps(fn)
        async def handler(ctx: Context, next_fn=None):
            try:
                args = await self.resolve_params(fn, ctx)
                result = await fn(*args)

                if result is not None:
                    ctx.send(result)
                return result
            except Exception as e:
                if error_handler:
                    return await error_handler(ctx, e)

                # Validation errors already handled in ctx.validate or resolve_params
                if "validation failed" in str(e).lower():
                    return
                raise e
        return handler

def register_controller(app: Any, controller_cls: Type):
    resolver = DecoratorsResolver(app)
    resolver.register(controller_cls)