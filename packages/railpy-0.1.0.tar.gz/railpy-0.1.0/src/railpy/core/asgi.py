from typing import Callable, Awaitable, Dict, Any, Optional, Union

# Standard ASGI type aliases
Receive = Callable[[], Awaitable[Dict[str, Any]]]
Send = Callable[[Dict[str, Any]], Awaitable[None]]

class ASGIRequest:
    def __init__(self, scope: Dict[str, Any]):
        # Store original scope for external helpers (e.g., Lambda adapters)
        self.scope = scope

        self.method: str = scope.get("method", "GET").upper()
        self.path: str = scope.get("path", "/")

        # Safe raw_path decoding
        raw_path = scope.get("raw_path", b"/")
        self.raw_path: str = raw_path.decode("utf-8") if isinstance(raw_path, bytes) else str(raw_path)

        # Normalize headers to lowercase for case-insensitive access
        self.headers: Dict[str, str] = {
            k.decode("ascii").lower(): v.decode("ascii") 
            for k, v in scope.get("headers", [])
        }

        self._receive: Optional[Receive] = None
        self._body: Optional[bytes] = None

        self.normalized_headers: Dict[str, str] = {}

    async def body(self) -> bytes:
        """Reads and concatenates the request body from the ASGI stream."""
        if self._body is not None:
            return self._body

        if not self._receive:
            raise RuntimeError("ASGIRequest._receive was never set by the framework.")

        chunks = []
        while True:
            message = await self._receive()
            if message["type"] == "http.request":
                chunks.append(message.get("body", b""))
                if not message.get("more_body", False):
                    break
            elif message["type"] == "http.disconnect":
                # Break stream if client disconnects
                break

        self._body = b"".join(chunks)
        return self._body


class ASGIResponse:
    def __init__(self, send: Send):
        self.send: Send = send
        self._sent: bool = False

    async def send_response(
        self,
        body: Union[bytes, str] = b"",
        status: int = 200,
        headers: Optional[Dict[str, str]] = None,
    ):
        """Dispatches the response to the ASGI server (Uvicorn/Daphne/Lambda)."""
        if self._sent:
            raise RuntimeError("ASGI Error: Response has already been sent to the client.")

        # Normalize Body to bytes
        if isinstance(body, str):
            payload = body.encode("utf-8")
        else:
            payload = body

        # Prepare headers in ASGI format: List[Tuple[bytes, bytes]]
        headers_dict = headers or {}

        # Auto-inject Content-Length if missing
        if "content-length" not in [k.lower() for k in headers_dict.keys()]:
            headers_dict["content-length"] = str(len(payload))

        asgi_headers = [
            (k.lower().encode("ascii"), str(v).encode("ascii"))
            for k, v in headers_dict.items()
        ]

        # Step 1: Send 'http.response.start'
        await self.send({
            "type": "http.response.start",
            "status": status,
            "headers": asgi_headers,
        })

        # Step 2: Send 'http.response.body'
        await self.send({
            "type": "http.response.body",
            "body": payload,
            "more_body": False,
        })

        self._sent = True