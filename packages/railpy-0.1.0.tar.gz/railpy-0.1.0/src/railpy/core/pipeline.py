from typing import Any, Callable, List, Optional, Dict

class PipelineBuilder:
    def __init__(self):
        self.nodes: Dict[Any, Dict[str, Any]] = {}
        self.order = 0

    def use(self, fn: Callable, name: Optional[str] = None):
        """Adds a middleware node to the pipeline graph"""
        node_id = object()

        self.nodes[node_id] = {
            "id": node_id,
            "fn": fn,
            "name": name or getattr(fn, "__name__", "anonymous"),
            "before": set(),
            "after": set(),
            "order": self.order
        }
        self.order += 1

        def before(ref: Dict):
            self.nodes[node_id]["before"].add(ref["id"])
            return api

        def after(ref: Dict):
            self.nodes[node_id]["after"].add(ref["id"])
            return api

        api = {"id": node_id, "before": before, "after": after}
        return api

    def apply(self, fn: Optional[Callable[["PipelineBuilder"], None]]) -> "PipelineBuilder":
        """Used by decorators to trigger pipeline configuration functions"""
        if fn and callable(fn):
            fn(self)
        return self

    def _get_sorted_nodes(self):
        """Internal helper to perform topological sort on pipeline nodes"""
        graph, indeg = {}, {}

        for k in self.nodes:
            graph[k], indeg[k] = [], 0

        for k, n in self.nodes.items():
            for b in n["before"]:
                graph[k].append(b)
                indeg[b] += 1
            for a in n["after"]:
                graph[a].append(k)
                indeg[k] += 1

        # Kahn's algorithm for topological sorting
        queue = [k for k in indeg if indeg[k] == 0]
        result = []

        while queue:
            cur = queue.pop(0)
            result.append(self.nodes[cur])
            if cur in graph:
                for nxt in graph[cur]:
                    indeg[nxt] -= 1
                    if indeg[nxt] == 0:
                        queue.append(nxt)

        if len(result) != len(self.nodes):
            raise Exception("Pipeline cycle detected or dangling references")

        return result

    def build(self) -> List[Callable]:
        """Returns the final ordered list of middleware functions"""
        nodes = self._get_sorted_nodes()
        return [n["fn"] for n in nodes]

    def print_pipeline(self):
        """Utility to debug the final pipeline order"""
        print("\n🔗 Pipeline Order:")
        for n in self._get_sorted_nodes():
            print(f" - {n['name']}")