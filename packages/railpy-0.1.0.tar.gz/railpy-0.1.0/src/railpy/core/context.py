import json
import os
import mimetypes
import asyncio
from urllib.parse import parse_qs
from typing import Any, Dict, List, Optional, Tuple, Type, Callable
from pydantic import BaseModel, ValidationError

from .asgi import ASGIRequest, ASGIResponse

class ResponseContext:
    def __init__(self):
        self.headers: Dict[str, str] = {}
        self.cookies: List[str] = []

class Context:
    def __init__(self, req: ASGIRequest, res: ASGIResponse):
        self.req: ASGIRequest = req
        self._asgi_res: ASGIResponse = res
        self.res = ResponseContext()

        self.method: str = req.method
        self.path: str = req.path

        self.params: Dict[str, Any] = {}
        self.query: Dict[str, str] = {}
        self.data: Dict[str, Any] = {}
        self.state: Dict[str, Any] = {}

        self.status: int = 200
        self.body: Any = None

        query_string = ""
        if hasattr(req, 'scope'):
            query_string = req.scope.get("query_string", b"").decode()

        self.query = {k: v[0] for k, v in parse_qs(query_string).items()}
        self.background_tasks: List[Tuple[Callable, Tuple, Dict]] = []

    # --- Header Helpers ---
    def set(self, name: str, value: str) -> "Context":
        self.res.headers[name.lower()] = str(value)
        return self

    def get_header(self, name: str, default: Optional[str] = None) -> Optional[str]:
        return self.req.headers.get(name.lower(), default)

    def bearer_token(self) -> Optional[str]:
        auth = self.get_header("authorization") or ""
        if auth.startswith("Bearer "):
            return auth[7:]
        return None

    def add_background_task(self, func: Callable, *args, **kwargs):
        self.background_tasks.append((func, args, kwargs))

    # --- Response Helpers ---
    def json(self, data: Any, status: Optional[int] = None) -> None:
        if status: self.status = status
        self.set("content-type", "application/json; charset=utf-8")
        self.body = data

    def text(self, text: str, status: Optional[int] = None) -> None:
        if status: self.status = status
        self.set("content-type", "text/plain; charset=utf-8")
        self.body = str(text)

    def html(self, html: str, status: Optional[int] = None) -> None:
        if status: self.status = status
        self.set("content-type", "text/html; charset=utf-8")
        self.body = html

    def file(self, path: str, filename: Optional[str] = None) -> None:
        if not os.path.isfile(path):
            return self.not_found("File not found")

        mime_type, _ = mimetypes.guess_type(path)
        self.set("content-type", mime_type or "application/octet-stream")

        if filename:
            self.set("content-disposition", f'attachment; filename="{filename}"')

        with open(path, "rb") as f:
            self.body = f.read()

    def redirect(self, url: str, status: int = 302) -> None:
        self.status = status
        self.set("location", url)

    def send(self, data: Any) -> None:
        if isinstance(data, (dict, list)):
            return self.json(data)
        return self.text(str(data))

    # --- Body & Validation ---
    async def parse_body(self) -> Any:
        if "body" in self.data:
            return self.data["body"]

        raw = await self.req.body()
        if not raw:
            return {}

        try:
            self.data["body"] = json.loads(raw)
        except Exception:
            try:
                self.data["body"] = raw.decode()
            except:
                self.data["body"] = raw

        return self.data["body"]

    async def validate(self, schema: Type[BaseModel]) -> BaseModel:
        body = await self.parse_body()
        try:
            return schema(**body)
        except ValidationError as e:
            self.status = 422
            self.json({"errors": e.errors()})
            raise ValueError(f"Validation failed: {e.json()}")

    # --- Cookies ---
    def get_cookie(self, name: str) -> Optional[str]:
        raw = self.get_header("cookie")
        if not raw: return None
        for p in raw.split(";"):
            k, _, v = p.strip().partition("=")
            if k == name: return v
        return None

    def set_cookie(self, name: str, value: str, max_age: int = 3600,
                   path: str = "/", http_only: bool = True, secure: bool = False) -> None:
        cookie = f"{name}={value}; Max-Age={max_age}; Path={path}"
        if http_only: cookie += "; HttpOnly"
        if secure: cookie += "; Secure"
        self.res.cookies.append(cookie)

    # --- Status Shorthands ---
    def ok(self, data: Any = None) -> None: self.json(data, 200)
    def created(self, data: Any = None) -> None: self.json(data, 201)
    def no_content(self) -> None:
        self.status = 204
        self.body = b""
    def bad_request(self, msg: str = "Bad Request") -> None: self.json({"error": msg}, 400)
    def unauthorized(self, msg: str = "Unauthorized") -> None: self.json({"error": msg}, 401)
    def forbidden(self, msg: str = "Forbidden") -> None: self.json({"error": msg}, 403)
    def not_found(self, msg: str = "Not Found") -> None: self.json({"error": msg}, 404)
    def internal_error(self, msg: str = "Internal Server Error") -> None: self.json({"error": msg}, 500)

async def finalize_response(res: ASGIResponse, ctx: Context) -> None:
    """Serializes Context and sends response via ASGI, then runs background tasks."""
    if getattr(res, "_sent", False):
        return

    status: int = ctx.status
    body: Any = ctx.body

    # 1. Body Serialization
    if isinstance(body, (dict, list)):
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        if "content-type" not in ctx.res.headers:
            ctx.res.headers["content-type"] = "application/json; charset=utf-8"
    elif body is None:
        payload = b""
    elif isinstance(body, bytes):
        payload = body
    else:
        payload = str(body).encode("utf-8")

    # 2. Header and Cookie Assembly
    final_headers: List[Tuple[bytes, bytes]] = []
    for k, v in ctx.res.headers.items():
        final_headers.append((k.lower().encode("ascii"), v.encode("ascii")))

    for cookie_val in ctx.res.cookies:
        final_headers.append((b"set-cookie", cookie_val.encode("ascii")))

    if "content-length" not in ctx.res.headers and payload:
        final_headers.append((b"content-length", str(len(payload)).encode("ascii")))

    # 3. ASGI Send Events
    await res.send({
        "type": "http.response.start",
        "status": status,
        "headers": final_headers,
    })

    await res.send({
        "type": "http.response.body",
        "body": payload,
        "more_body": False
    })

    res._sent = True

    # 4. Background Task Execution
    if ctx.background_tasks:
        for func, args, kwargs in ctx.background_tasks:
            try:
                if asyncio.iscoroutinefunction(func):
                    asyncio.create_task(func(*args, **kwargs))
                else:
                    loop = asyncio.get_event_loop()
                    loop.run_in_executor(None, lambda: func(*args, **kwargs))
            except Exception as e:
                print(f"Background task execution failed: {e}")