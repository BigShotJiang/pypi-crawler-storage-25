import inspect
import re
from typing import Any, Dict, Type
from pydantic import BaseModel
from .decorators import VALIDATE_BODY, VALIDATE_QUERY, VALIDATE_PARAM

class OpenAPIGenerator:
    def __init__(self, title: str = "Railpy API", version: str = "1.0.0"):
        self.spec: Dict[str, Any] = {
            "openapi": "3.0.0",
            "info": {"title": title, "version": version},
            "paths": {},
            "components": {
                "schemas": {}, 
                "securitySchemes": {
                    "bearerAuth": {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"}
                }
            },
        }

    def _register_schema(self, model: Type[BaseModel]):
        """Extracts Pydantic schemas and handles nested definitions ($defs)."""
        name = model.__name__
        if name not in self.spec["components"]["schemas"]:
            # Extract full schema including nested definitions
            schema_data = model.model_json_schema()

            # Move internal definitions to components/schemas
            if "$defs" in schema_data:
                defs = schema_data.pop("$defs")
                for def_name, def_schema in defs.items():
                    if def_name not in self.spec["components"]["schemas"]:
                        self.spec["components"]["schemas"][def_name] = def_schema

            self.spec["components"]["schemas"][name] = schema_data
        return f"#/components/schemas/{name}"

    def add_route(self, method: str, path: str, handler: Any):
        if not callable(handler): return

        # Convert Railpy syntax (:id) to OpenAPI syntax ({id})
        openapi_path = path.replace(":", "{")
        if not openapi_path.startswith("/"): openapi_path = "/" + openapi_path

        if openapi_path not in self.spec["paths"]:
            self.spec["paths"][openapi_path] = {}

        # Parse docstrings for summary and description
        doc = inspect.getdoc(handler) or ""
        lines = doc.split("\n")
        summary = lines[0] if lines[0] else f"{method.upper()} {path}"
        description = "\n".join(lines[1:]).strip()

        operation = {
            "summary": summary,
            "description": description,
            "tags": [self._get_tag_from_path(path)],
            "responses": {
                "200": {"description": "Successful Response", "content": {"application/json": {"schema": {"type": "object"}}}}
            },
            "security": [{"bearerAuth": []}],
            "parameters": []
        }

        # Handle Request Body
        body_model = getattr(handler, VALIDATE_BODY, None)
        if body_model:
            ref = self._register_schema(body_model)
            operation["requestBody"] = {
                "content": {"application/json": {"schema": {"$ref": ref}}},
                "required": True
            }

        # Handle Query Parameters
        query_model = getattr(handler, VALIDATE_QUERY, None)
        if query_model:
            schema = query_model.model_json_schema()
            for prop_name, prop_info in schema.get("properties", {}).items():
                operation["parameters"].append({
                    "name": prop_name,
                    "in": "query",
                    "description": prop_info.get("description", ""),
                    "required": prop_name in schema.get("required", []),
                    "schema": prop_info
                })

        # Handle Path Parameters
        path_vars = re.findall(r"\{(.*?)\}", openapi_path)
        param_model = getattr(handler, VALIDATE_PARAM, None)

        for var in path_vars:
            param_schema = {"type": "string"}
            description = ""
            if param_model:
                schema = param_model.model_json_schema()
                param_schema = schema.get("properties", {}).get(var, {"type": "string"})
                description = param_schema.get("description", "")

            operation["parameters"].append({
                "name": var,
                "in": "path",
                "required": True,
                "description": description,
                "schema": param_schema
            })

        self.spec["paths"][openapi_path][method.lower()] = operation

    def _get_tag_from_path(self, path: str) -> str:
        parts = [p for p in path.split("/") if p and not p.startswith(("{", ":"))]
        return parts[0].capitalize() if parts else "Default"

    def get_spec(self) -> Dict[str, Any]:
        return self.spec

    def get_html(self, spec_url: str = "/openapi.json") -> str:
        """Returns the HTML for Swagger UI."""
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>{self.spec['info']['title']}</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css">
        </head>
        <body>
            <div id="swagger-ui"></div>
            <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
            <script>
                const ui = SwaggerUIBundle({{
                    url: '{spec_url}',
                    dom_id: '#swagger-ui',
                    presets: [SwaggerUIBundle.presets.apis, SwaggerUIBundle.SwaggerUIStandalonePreset],
                    layout: "BaseLayout"
                }});
            </script>
        </body>
        </html>
        """