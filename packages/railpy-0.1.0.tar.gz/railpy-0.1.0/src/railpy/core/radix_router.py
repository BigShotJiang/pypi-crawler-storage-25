from .compose import compose
from .utils import split_segments, normalize_pattern, suggest
from .wrap import wrap_handler
from urllib.parse import unquote

def create_node():
    return {
        "children": {},
        "param": None,
        "param_name": None,
        "handlers": {},
        "wildcard": None
    }

def compute_score(path: str):
    segs = split_segments(path)
    score = 0

    for seg in segs:
        if seg == "*":
            return float("-inf")
        elif seg.startswith(":"):
            score += 10
        else:
            score += 100

    return score + len(segs)

class RadixRouter:
    def __init__(self):
        self.root = create_node()
        self.routes = []
        self.meta = []  # NEW

    def get(self, path, *h):
        return self.add_route("get", path, h)

    def add_route(self, method, path, handlers):
        method = method.lower()

        # detect duplicate + conflict
        self._detect_conflict(method, path)

        # track meta
        score = compute_score(path)
        self.meta.append({
            "method": method,
            "path": path,
            "score": score
        })

        segs = split_segments(path)
        node = self.root

        handler = compose([wrap_handler(fn) for fn in handlers])

        for s in segs:
            if s == "*":
                node["wildcard"] = handler
                break

            if s.startswith(":"):
                if not node["param"]:
                    node["param"] = create_node()
                    node["param"]["param_name"] = s[1:]
                node = node["param"]
            else:
                node = node["children"].setdefault(s, create_node())

        node["handlers"][method] = handler
        self.routes.append(path)
        return self

    # =========================
    # CONFLICT DETECTION
    # =========================

    def _detect_conflict(self, method, path):
        normalized = normalize_pattern(path)

        for r in self.meta:
            if r["method"] != method:
                continue

            # duplicate
            if r["path"] == path:
                print(f"⚠️ Duplicate route {method.upper()} {path}")

            # pattern conflict
            if normalize_pattern(r["path"]) == normalized and r["path"] != path:
                print(f"⚠️ Route conflict: {path} <-> {r['path']}")

            # wildcard warning
            if "*" in path or "*" in r["path"]:
                print(f"⚠️ Wildcard may override: {path} <-> {r['path']}")

    # =========================
    # SORTED PATHS
    # =========================

    def get_sorted_paths(self, method):
        return [
            r["path"] for r in sorted(
                self.meta,
                key=lambda x: x["score"],
                reverse=True
            )
            if r["method"] == method
        ]

    # =========================
    # HANDLE
    # =========================

    async def handle(self, ctx):
        segs = split_segments(ctx.path)
        node = self.root
        params = {}

        for s in segs:
            if s in node["children"]:
                node = node["children"][s]
                continue

            if node["param"]:
                params[node["param"]["param_name"]] = unquote(s)
                node = node["param"]
                continue

            if node["wildcard"]:
                ctx.params = params
                await node["wildcard"](ctx)
                return

            # better suggest
            suggestion = suggest(
                ctx.path,
                self.get_sorted_paths(ctx.method)
            )

            ctx.status = 404
            ctx.body = (
                f"Not Found. Did you mean '{suggestion}'?"
                if suggestion else "Not Found"
            )
            return

        method = ctx.method.lower()

        handler = node["handlers"].get(method) \
            or node["handlers"].get("all")

        if handler:
            ctx.params = params
            await handler(ctx)
            return

        if node["handlers"]:
            ctx.status = 405
            ctx.body = "Method Not Allowed"
            return

        if node["wildcard"]:
            ctx.params = params
            await node["wildcard"](ctx)
            return

        ctx.status = 404
        ctx.body = "Not Found"

    def print_routes(self):
        print("\n📌 Registered Routes:")
        for r in sorted(self.meta, key=lambda x: -x["score"]):
            print(f"{r['method'].upper():6} {r['path']} (score={r['score']})")