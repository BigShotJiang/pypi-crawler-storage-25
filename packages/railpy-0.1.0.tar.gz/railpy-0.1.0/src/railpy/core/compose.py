from typing import Callable, Awaitable, Any, List

Middleware = Callable[..., Awaitable[Any]]

def compose(middlewares: List[Middleware]) -> Callable[[Any], Awaitable[Any]]:

    arities = [fn.__code__.co_argcount for fn in middlewares]

    async def run(ctx: Any) -> Any:

        last_index = -1

        async def dispatch(i: int) -> Any:
            nonlocal last_index

            if i <= last_index:
                raise RuntimeError("next() called multiple times")

            last_index = i

            if i >= len(middlewares):
                return None

            fn = middlewares[i]

            async def next_fn(*_):
                return await dispatch(i + 1)

            try:

                # Handler style
                if arities[i] == 1:
                    result = await fn(ctx)

                # Middleware style
                else:
                    result = await fn(ctx, next_fn)

                if getattr(ctx, "body", None) is not None:
                    return ctx.body

                return result

            except Exception:
                raise

        return await dispatch(0)

    return run