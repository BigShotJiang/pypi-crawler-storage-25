import re

def split_segments(p): return [x for x in p.split('/') if x]

def normalize_pattern(path: str):
    return re.sub(r':\w+', ':param', path).replace('*', ':wildcard')

def levenshtein(a, b):
    dp = [[0]*(len(b)+1) for _ in range(len(a)+1)]

    for i in range(len(a)+1): dp[i][0] = i
    for j in range(len(b)+1): dp[0][j] = j

    for i in range(1, len(a)+1):
        for j in range(1, len(b)+1):
            dp[i][j] = dp[i-1][j-1] if a[i-1]==b[j-1] else 1 + min(
                dp[i-1][j-1],
                dp[i][j-1],
                dp[i-1][j]
            )
    return dp[-1][-1]

def suggest(path, routes):
    if not routes:
        return None

    best = routes[0]
    dist = levenshtein(path, best)

    for r in routes:
        d = levenshtein(path, r)
        if d < dist:
            best, dist = r, d

    return best if dist <= 3 else None