import logging
import sys

class RailpyLogger:
    def __init__(self, name: str = "RAILPY"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False # Prevent double logging

        # ANSI Color Codes
        self.GREEN = "\033[92m"
        self.RED = "\033[91m"
        self.RESET = "\033[0m"

        # Standard Format: Time | Level | Message
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

        # Stream Handler (Console)
        if not self.logger.handlers:
            ch = logging.StreamHandler(sys.stdout)
            ch.setFormatter(formatter)
            self.logger.addHandler(ch)

    def info(self, msg: str):
        self.logger.info(msg)

    def error(self, msg: str):
        self.logger.error(msg)

    def log_request(self, method: str, path: str, status: int, duration: float):
        """
        Logs HTTP requests with status-based coloring and latency.
        """
        # Select color based on status code
        color = self.GREEN if status < 400 else self.RED

        # Check if the output is a terminal to apply colors
        if sys.stdout.isatty():
            msg = f"{method.upper()} {path} | {color}{status}{self.RESET} | {duration:.2f}ms"
        else:
            msg = f"{method.upper()} {path} | {status} | {duration:.2f}ms"

        self.info(msg)

    def log_startup(self, host: str, port: int):
        self.info(f"🚀 Railpy server running on http://{host}:{port}")

    def log_shutdown(self):
        self.info("🛑 Railpy server stopped.")