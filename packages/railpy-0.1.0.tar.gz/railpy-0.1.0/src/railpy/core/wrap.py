import inspect
import functools
from typing import Callable, Awaitable, Optional, Any
from .context import Context

# Type definitions
HandlerFn = Callable[..., Awaitable[Any]]
MiddlewareFn = Callable[[Context, Optional[Callable]], Awaitable[Any]]

def wrap_handler(fn: HandlerFn) -> MiddlewareFn:
    """
    Wraps a controller method or a simple function into a standard Railpy middleware.
    Supports:
    - async def handler(ctx)
    - async def handler(ctx, next_fn)
    - Bound class methods (self is ignored in count)
    """
    sig = inspect.signature(fn)
    # Filter out 'self' for bound methods to get the true functional parameter count
    params = [p for p in sig.parameters.values() if p.name != 'self']
    params_count = len(params)

    @functools.wraps(fn)
    async def _wrapped(ctx: Context, next_fn: Optional[Callable] = None):
        try:
            # 1. Execute the handler based on its signature
            if params_count <= 1:
                result = await fn(ctx)
            else:
                # Passes next_fn only if the function expects two arguments
                result = await fn(ctx, next_fn)

            # 2. Check if the response was already sent via ctx.send() or ctx.json()
            if ctx.body is not None:
                return ctx.body

            # 3. Auto-send return values (converts dict/list to JSON response)
            if result is not None:
                ctx.send(result)
                return ctx.body

        except Exception as err:
            # Fallback error handling if not already caught by error_handler middleware
            if not ctx.status or ctx.status < 400:
                ctx.status = 500
                ctx.send({"success": False, "error": "Internal Server Error", "message": str(err)})
            print(f"❌ [Railpy Handler Error]: {err}")

    return _wrapped