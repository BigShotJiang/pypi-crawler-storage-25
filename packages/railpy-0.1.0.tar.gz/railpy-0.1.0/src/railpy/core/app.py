# railpy/app.py

import asyncio
import uvicorn
import time
import os
from typing import Any, Callable, Coroutine, List, Optional, Tuple, Union, Sequence

from .compose import compose, Middleware
from .context import Context, finalize_response
from .radix_router import RadixRouter
from .asgi import ASGIRequest, ASGIResponse
from .hooks import Hooks
from .pipeline import PipelineBuilder
from .logger import RailpyLogger
from .openapi import OpenAPIGenerator

# Type Aliases
Handler = Union[Middleware, str]
ErrorHandler = Callable[[Any, Exception], Coroutine[Any, Any, Any]]

class Railpy:
    def __init__(self, title: str = "Railpy API", version: str = "1.0.0"):
        """
        Initialize the Railpy Application.
        """
        self.router: RadixRouter = RadixRouter()

        # Core Systems
        self.hooks: Hooks = Hooks()
        self.logger: RailpyLogger = RailpyLogger()
        self.openapi_gen: OpenAPIGenerator = OpenAPIGenerator(title=title, version=version)

        self._global_error_handler: Optional[ErrorHandler] = None
        self._compiled_pipeline: Optional[Callable] = None

        # Middleware stacks
        self.middlewares: List[Middleware] = []
        self.pipeline_middlewares: List[Middleware] = []
        self._middleware_map: dict[str, Middleware] = {}

        # Context stacks for Group routing
        self._prefix_stack: List[str] = [""]
        self._group_middleware_stack: List[List[Middleware]] = [[]]
        self._static_routes: List[Tuple[str, str]] = []

    # =========================
    # CONFIGURATION
    # =========================

    def setup_swagger(self, path: str = "/docs", json_path: str = "/openapi.json"):
        """
        Registers routes to serve Swagger UI and OpenAPI Spec.
        """
        async def get_openapi_spec(ctx: Context, next=None):
            return self.openapi_gen.get_spec()

        async def swagger_ui(ctx: Context, next=None):
            ctx.res.headers["content-type"] = "text/html"
            return self.openapi_gen.get_html(spec_url=json_path)

        self.get(json_path, get_openapi_spec)
        self.get(path, swagger_ui)
        return self

    def static(self, prefix: str, directory: str):
        """
        Mounts a physical directory for serving static files.
        """
        if not os.path.isdir(directory):
            raise ValueError(f"Directory {directory} does not exist")
        self._static_routes.append((prefix.rstrip("/"), os.path.abspath(directory)))
        return self

    def exception_handler(self, fn: ErrorHandler) -> ErrorHandler:
        """
        Decorator to register a global error handler.
        """
        self._global_error_handler = fn
        return fn

    def pipeline(self, fn):
        """
        Configure deterministic middleware pipeline.
        """
        builder = PipelineBuilder()
        builder.apply(fn)

        self.pipeline_middlewares = builder.build()
        self._compiled_pipeline = None

        return self

    # =========================
    # ROUTING & MIDDLEWARE
    # =========================

    def use(self, mw: Middleware, name: Optional[str] = None) -> "Railpy":
        """
        Registers global or group-level middleware.
        """
        if name:
            self._middleware_map[name] = mw

        if len(self._group_middleware_stack) > 1:
            self._group_middleware_stack[-1].append(mw)
        else:
            self.middlewares.append(mw)
            self._compiled_pipeline = None # Reset pipeline to re-compile on next request
        return self

    def group(self, prefix: str, fn: Callable[["Railpy"], None]) -> "Railpy":
        """
        Scopes routes and middlewares under a specific path prefix.
        """
        self._prefix_stack.append(self._prefix_stack[-1] + prefix)
        self._group_middleware_stack.append([])
        fn(self)
        self._prefix_stack.pop()
        self._group_middleware_stack.pop()
        return self

    def route(self, method: str, path: str, *handlers: Handler) -> "Railpy":
        """
        Registers a new route and collects metadata for OpenAPI.
        """
        full_path, resolved = self._apply_group(path, handlers)
        self.router.add_route(method.lower(), full_path, resolved)

        if handlers:
            last_handler = handlers[-1]
            if callable(last_handler):
                self.openapi_gen.add_route(method, full_path, last_handler)
        return self

    # HTTP Method Shorthands
    def get(self, path: str, *handlers: Handler): return self.route("get", path, *handlers)
    def post(self, path: str, *handlers: Handler): return self.route("post", path, *handlers)
    def put(self, path: str, *handlers: Handler): return self.route("put", path, *handlers)
    def delete(self, path: str, *handlers: Handler): return self.route("delete", path, *handlers)
    def patch(self, path: str, *handlers: Handler): return self.route("patch", path, *handlers)

    # =========================
    # INTERNALS
    # =========================

    def _resolve_handlers(self, handlers: Sequence[Handler]) -> List[Middleware]:
        resolved: List[Middleware] = []
        for h in handlers:
            if isinstance(h, str):
                mw = self._middleware_map.get(h)
                if not mw: raise Exception(f'Middleware "{h}" not found')
                resolved.append(mw)
            else:
                resolved.append(h)
        return resolved

    def _apply_group(self, path: str, handlers: Sequence[Handler]) -> Tuple[str, List[Middleware]]:
        full_path = (self._prefix_stack[-1] + path).replace("//", "/")
        group_mws: List[Middleware] = []
        for g in self._group_middleware_stack:
            group_mws.extend(g)
        resolved_handlers = self._resolve_handlers(handlers)
        return full_path, [*group_mws, *resolved_handlers]

    def _compile_middleware(self):
        """
        Pre-compiles the middleware stack into a single executable function.
        """
        self._compiled_pipeline = compose([
            *self._resolve_handlers(self.middlewares),
            *self.pipeline_middlewares,
            self._final_handler
        ])

    async def _final_handler(self, ctx: Context, next_fn=None):
        """
        The end of the onion: Checks for static files, then fallback to router.
        """
        # Try serving static files
        for prefix, disk_path in self._static_routes:
            if ctx.path.startswith(prefix):
                rel_path = ctx.path[len(prefix):].lstrip("/")
                full_path = os.path.join(disk_path, rel_path)
                if os.path.isfile(full_path):
                    return ctx.file(full_path)

        # Fallback to dynamic routing
        return await self.router.handle(ctx)

    # =========================
    # LIFECYCLE & SERVER
    # =========================

    def start(self, host: str = "0.0.0.0", port: int = 8000):
        """
        Starts the ASGI server using uvicorn.
        """
        uvicorn.run(self, host=host, port=port)
        return self

    async def __call__(self, scope: dict, receive: Callable, send: Callable):
        """
        Main ASGI Entry point.
        """
        if scope["type"] == "lifespan":
            await self._handle_lifespan(receive, send)
            return

        if not self._compiled_pipeline:
            self._compile_middleware()

        start_time = time.perf_counter()
        req, res = ASGIRequest(scope), ASGIResponse(send)
        req._receive = receive
        ctx = Context(req, res)

        try:
            await self.hooks.run("request", ctx)

            if self._compiled_pipeline:
                await self._compiled_pipeline(ctx)

            await self.hooks.run("response", ctx)
        except Exception as err:
            await self._handle_error(ctx, err)
        finally:
            # 1. Log metrics
            duration = (time.perf_counter() - start_time) * 1000
            self.logger.log_request(req.method, req.path, ctx.status, duration)

            # 2. Finalize HTTP transmission
            await finalize_response(res, ctx)

            # 3. Handle Background Tasks
            if ctx.background_tasks:
                for func, args, kwargs in ctx.background_tasks:
                    asyncio.create_task(func(*args, **kwargs))

    async def _handle_error(self, ctx: Context, err: Exception):
        if self._global_error_handler:
            try:
                await self._global_error_handler(ctx, err)
            except Exception as fatal:
                ctx.status = 500
                ctx.body = {"error": "Fatal Error", "details": str(fatal)}
        else:
            await self.hooks.run("error", ctx, err)
            ctx.status = 500
            ctx.body = {"error": str(err)}

        self.logger.error(f"Error on {ctx.method} {ctx.path}: {str(err)}")

    async def _handle_lifespan(self, receive: Callable, send: Callable):
        while True:
            message = await receive()
            if message["type"] == "lifespan.startup":
                print(f"🚀 Railpy {self.openapi_gen.spec['info']['title']} starting...")
                await send({"type": "lifespan.startup.complete"})
            elif message["type"] == "lifespan.shutdown":
                print("🛑 Railpy Application shutting down...")
                await send({"type": "lifespan.shutdown.complete"})
                return