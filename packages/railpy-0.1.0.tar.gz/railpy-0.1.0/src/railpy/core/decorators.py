from typing import Any, Callable, Optional, Type
from pydantic import BaseModel
from .pipeline import PipelineBuilder

# Metadata Keys - Standardized Naming
PARAMS = "__params__"
PREFIX = "__prefix__"
MIDDLEWARES = "__middlewares__"
PIPELINE = "__pipeline__"
ERROR = "__error__"
VALIDATE_BODY = "__validate_body__"
VALIDATE_QUERY = "__validate_query__"
VALIDATE_PARAM = "__validate_param__"
ROUTE = "__route__"

Middleware = Callable[[Any, Optional[Callable]], Any]
HandlerFn = Callable[..., Any]

def Controller(prefix: str = ""):
    """Class decorator to define a base path for all routes in the class."""
    def wrapper(cls: Type):
        setattr(cls, PREFIX, prefix)
        return cls
    return wrapper

def _create_method(method: str):
    """Internal helper to create HTTP method decorators."""
    def decorator(path: str = ""):
        def wrapper(fn: HandlerFn):
            setattr(fn, ROUTE, (method, path))
            return fn
        return wrapper
    return decorator

# Standard HTTP Methods
Get, Post, Put, Delete, Patch = [_create_method(m) for m in ["get", "post", "put", "delete", "patch"]]

def Use(*middlewares: Middleware):
    """Apply one or more middlewares to a controller or a specific route."""
    def decorator(target: Any):
        existing = getattr(target, MIDDLEWARES, [])
        setattr(target, MIDDLEWARES, [*existing, *middlewares])
        return target
    return decorator

# =========================
# VALIDATION DECORATORS
# =========================

def ValidateBody(model: Type[BaseModel]):
    """Validates the request body against a Pydantic model."""
    def decorator(fn: HandlerFn):
        setattr(fn, VALIDATE_BODY, model)
        return fn
    return decorator

def ValidateQuery(model: Type[BaseModel]):
    """Validates query string parameters against a Pydantic model."""
    def decorator(fn: HandlerFn):
        setattr(fn, VALIDATE_QUERY, model)
        return fn
    return decorator

def ValidateParam(model: Type[BaseModel]):
    """Validates path parameters against a Pydantic model."""
    def decorator(fn: HandlerFn):
        setattr(fn, VALIDATE_PARAM, model)
        return fn
    return decorator

# =========================
# PARAMETER EXTRACTORS (Metadata-based)
# =========================

def Header(key: str):
    """Marks a function argument to be extracted from request headers."""
    def decorator(fn: HandlerFn):
        if not hasattr(fn, PARAMS): setattr(fn, PARAMS, [])
        getattr(fn, PARAMS).insert(0, {"type": "header", "key": key})
        return fn
    return decorator

def Param(key: str):
    """Marks a function argument to be extracted from path parameters."""
    def decorator(fn: HandlerFn):
        if not hasattr(fn, PARAMS): setattr(fn, PARAMS, [])
        getattr(fn, PARAMS).insert(0, {"type": "param", "key": key})
        return fn
    return decorator

def Query(key: str):
    """Marks a function argument to be extracted from query strings."""
    def decorator(fn: HandlerFn):
        if not hasattr(fn, PARAMS): setattr(fn, PARAMS, [])
        getattr(fn, PARAMS).insert(0, {"type": "query", "key": key})
        return fn
    return decorator

# =========================
# OTHER UTILITIES
# =========================

def Pipeline(fn: Callable[[PipelineBuilder], None]):
    """Applies a complex middleware pipeline to the route."""
    def decorator(handler: HandlerFn):
        setattr(handler, PIPELINE, fn)
        return handler
    return decorator

def Catch(fn: HandlerFn):
    """Registers a route-specific error handler."""
    def decorator(handler: HandlerFn):
        setattr(handler, ERROR, fn)
        return handler
    return decorator