import asyncio
from typing import Any, Dict
from railpy.core.app import Railpy

class RailpyLambda:
    def __init__(self, app: Railpy):
        self.app = app

    def __call__(self, event: Dict[str, Any], context: Any):
        scope = self._event_to_scope(event, context)

        body_buffer = bytearray()
        response_meta = {"status": 200, "headers": []}

        async def receive():
            # Handle trường hợp body là None (GET request)
            body = event.get("body") or ""
            return {
                "type": "http.request",
                "body": body.encode() if isinstance(body, str) else body,
                "more_body": False
            }

        async def send(message):
            if message["type"] == "http.response.start":
                response_meta["status"] = message["status"]
                response_meta["headers"] = message["headers"]
            elif message["type"] == "http.response.body":
                body_buffer.extend(message.get("body", b""))

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        loop.run_until_complete(self.app(scope, receive, send))

        return {
            "statusCode": response_meta["status"],
            "headers": {k.decode() if isinstance(k, bytes) else k:
                        v.decode() if isinstance(v, bytes) else v
                        for k, v in response_meta["headers"]},
            "body": body_buffer.decode("utf-8"),
            "isBase64Encoded": False
        }

    def _event_to_scope(self, event: Dict[str, Any], context: Any) -> Dict[str, Any]:
        headers = []
        if event.get("headers"):
            headers = [[k.lower().encode(), v.encode()] for k, v in event["headers"].items()]

        return {
            "type": "http",
            "method": event.get("httpMethod", event.get("requestContext", {}).get("http", {}).get("method", "GET")),
            "path": event.get("path", event.get("rawPath", "/")),
            "query_string": self._build_query_string(event),
            "headers": headers,
            "client": ("127.0.0.1", 0),
            "scheme": "https",
            "serverless.event": event,
            "serverless.context": context,
            "aws.request_id": getattr(context, "aws_request_id", None)
        }

    def _build_query_string(self, event: Dict[str, Any]) -> bytes:
        qs = event.get("queryStringParameters")
        if not qs: return b""
        import urllib.parse
        return urllib.parse.urlencode(qs).encode()