# app.py
import asyncio
from railpy import Railpy, Controller, Get, Post, Param, Context, register_controller, Use
from railpy.middlewares import (
    logger,
    error_handler,
    cors,
    body_parser,
    rate_limit,
    jwt_auth,
    helmet,
    session,
    query_parser,
    serve_static,
    normalize_headers,
    SessionOpts
)

# =========================
# App & Config
# =========================
app = Railpy()

SECRET = "your-very-secure-secret"
SESSION_SECRET = "super-secret-session"

# Create session options
session_opts = SessionOpts(secret=SESSION_SECRET)

# =========================
# Global Middlewares
# =========================
app.use(logger)               # Request logging
app.use(error_handler)        # Global error handling
app.use(rate_limit(60))       # Rate limiting
app.use(cors())               # CORS
app.use(helmet)               # Security headers
app.use(normalize_headers())  # Normalize headers
app.use(body_parser)          # Parse JSON & form bodies
app.use(query_parser())       # Parse query string
app.use(session(session_opts))
app.use(serve_static("public"))  # Serve static files

# =========================
# Background Task Example
# =========================
async def send_email(user_id: str):
    await asyncio.sleep(1)  # simulate async operation
    print(f"Email sent to user {user_id}")

# =========================
# Public Route
# =========================
async def home(ctx: Context, next_fn=None):
    return {"message": "Welcome to Railpy 🚀", "query": ctx.query}

app.get("/", home)

# =========================
# Protected Route
# =========================
async def secret_route(ctx: Context):
    user = ctx.data.get("user")
    return {"message": "Hello JWT", "user": user}

app.get("/secret", jwt_auth(SECRET), secret_route)

# =========================
# Register with Background Task
# =========================
# Basic function route
async def register_user(ctx: Context):
    user_id = ctx.params["id"]

    # Define background task
    async def send_email(u_id):
        await asyncio.sleep(1)  # simulate async operation
        print(f"Email sent to {u_id}")

    # Add the background task
    ctx.background_tasks.append((send_email, (user_id,), {}))

    return {"message": "User registered"}

# Register the route with Railpy
app.get("/register/:id", register_user)

# =========================
# User Controller with JWT
# =========================
@Controller("/api/v1")
# @Use(jwt_auth(SECRET))  # Apply JWT to all controller routes if desired
class UserController:

    @Get("/users/:id")
    @Param("id")
    async def get_user(self, user_id: str, ctx: Context):
        user = ctx.data.get("user")

        # Add a background task inside controller
        async def send_welcome_email(u_id: str):
            await asyncio.sleep(1)  # simulate async operation
            print(f"Email sent to user {u_id}")

        ctx.background_tasks.append((send_welcome_email, (user_id,), {}))
        return {"user_id": user_id, "logged_in_user": user}

    @Post("/users")
    async def create_user(self, ctx: Context):
        user = ctx.data.get("user")
        body = ctx.data.get("body")
        return {"message": "User created", "body": body, "logged_in_user": user}

    @Get("/profile")
    async def profile(self, ctx: Context):
        user = ctx.data.get("user")
        sess = ctx.state.get("session")
        return {"message": "Your profile", "user": user, "session": sess}

# Register controller
register_controller(app, UserController)

# =========================
# Run server
# =========================
if __name__ == "__main__":
    app.start(port=3000)