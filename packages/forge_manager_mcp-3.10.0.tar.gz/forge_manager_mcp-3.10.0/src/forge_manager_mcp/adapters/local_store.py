"""LocalStoreAdapter — filesystem-backed PlatformAdapter (3.0 / Phase 2 sub-run C).

Refactors the 2.4.0 special-case-decorator pattern into a peer adapter
per Discussion #1 OQ6. Operations land on a local docs repo
(``~/telejester-claude-skills-docs/`` by default) following the schema
from CONVENTIONS.md:

    issues/<N>/
        title.md, body.md, state.txt, labels.txt, meta.json
        comments/
            <utc-ts>-<author>.md

    discussions/<N>/    # same shape; kind:discussion in labels per OQ1

    _orphan-comments/   # comments whose target wasn't found

Auto-commits each fallback write to the docs repo's git history. The
``ReplicationManager`` in Phase 6 routes a single operation across
multiple adapters; LocalStoreAdapter is one such adapter, no longer the
fallback target via a special-case decorator.

Mark-as-answer / decided uses the ``decided`` state value (multi-dim
state per OQ1) — added to state.txt, not encoded as a separate label.
"""
from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, ClassVar

from .. import vocab
from ..docs_repo import ensure_local_docs_repo
from . import errors as _errors
from . import _recovery
from .types import (
    ArtifactKind,
    ArtifactRef,
    BootstrapResult,
    Comment,
    Discussion,
    DriftReport,
    HistoryEntry,
    ImportConflict,
    Issue,
    Milestone,
    RecoveryBundle,
    Release,
    RemoteChange,
    SearchResult,
    SessionEvent,
)


DEFAULT_DOCS_REPO_ENV = "FORGE_MANAGER_DOCS_REPO"
"""Env var override for the canonical docs repo path. Falls back to
``~/<project>-docs/`` if unset."""


class LocalStoreAdapter:
    """PlatformAdapter implementation backed by a local git docs repo.

    Constructed with a docs-repo path (env var override available);
    every operation lands on the filesystem and auto-commits to the
    repo's git history.
    """

    platform_id: ClassVar[str] = "local"
    has_scaffold: ClassVar[bool] = True
    has_session_event_surface: ClassVar[bool] = True
    has_project_boards: ClassVar[bool] = False  # forgejo #10 / 3.4.0 — LocalStore has no project-board concept.

    def __init__(self, *, docs_repo_path: Path):
        self._path = docs_repo_path

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "LocalStoreAdapter":
        """Construct from a forge-config.json platform entry.

        Expected shape:

            {"id": "local", "path": "/abs/path/to/docs/repo"}

        ``path`` is optional; falls back to env var ``FORGE_MANAGER_DOCS_REPO``,
        then to ``~/telejester-claude-skills-docs/``.
        """
        path_str = (
            config.get("path")
            or os.environ.get(DEFAULT_DOCS_REPO_ENV)
            or "~/telejester-claude-skills-docs"
        )
        path = Path(path_str).expanduser()
        if not path.exists():
            raise _errors.ForgeError(
                f"LocalStoreAdapter: docs repo not found at {path}. "
                f"Set ${DEFAULT_DOCS_REPO_ENV} or pass `path` in the platform "
                f"config to override the default."
            )
        return cls(docs_repo_path=path)

    @property
    def path(self) -> Path:
        return self._path

    # =====================================================================
    # Repo-level reads
    # =====================================================================

    async def get_repo_node_id(self, owner: str, repo: str) -> str:
        # Local store doesn't have a node-ID concept; use a synthetic
        # ID so callers that pass it back can recognize the origin.
        return f"local://{owner}/{repo}"

    async def get_repo_visibility(self, owner: str, repo: str) -> str | None:
        """LocalStore has no real visibility concept — its access is
        gated by filesystem permissions, not a publish flag. Reports
        ``"PUBLIC"`` by convention so callers (e.g., the session-start
        repo-shape audit) get a non-None answer rather than a
        not-found signal. Returns ``None`` only if the docs path
        itself doesn't exist. (PAR-3)
        """
        return "PUBLIC" if self._path.is_dir() else None

    async def list_all_issue_numbers(
        self, owner: str, repo: str,
    ) -> list[int]:
        """(3.10.0 D7.1 / #388 LocalStore impl) Walk
        ``<docs-repo>/issues/`` and return every numeric directory
        name as an int. Sorted ascending. Used by
        ``_audit_toc_drift`` for the canonical-on-local TOC drift
        computation. Non-numeric directory names (none expected
        in well-formed canonical stores; defensive) are skipped.
        """
        issues_dir = self._path / "issues"
        if not issues_dir.is_dir():
            return []
        out: list[int] = []
        for entry in issues_dir.iterdir():
            if not entry.is_dir():
                continue
            try:
                out.append(int(entry.name))
            except ValueError:
                continue
        out.sort()
        return out

    async def list_all_discussion_numbers(
        self, owner: str, repo: str,
    ) -> list[int]:
        """(3.10.0 D7.1 / #388 LocalStore impl) Sibling of
        ``list_all_issue_numbers`` for the discussions/ directory.
        Same numeric-dir filter and ascending sort.
        """
        d_dir = self._path / "discussions"
        if not d_dir.is_dir():
            return []
        out: list[int] = []
        for entry in d_dir.iterdir():
            if not entry.is_dir():
                continue
            try:
                out.append(int(entry.name))
            except ValueError:
                continue
        out.sort()
        return out

    async def get_file_content(
        self, owner: str, repo: str, branch: str, path: str,
    ) -> str | None:
        """(3.10.0 D7.1 / #388 LocalStore impl) Read a file from
        the LocalStore root. ``branch`` is ignored — LocalStore
        operates on a checked-out filesystem tree, not on git
        refs. ``owner`` and ``repo`` are also ignored — LocalStore
        is bound to a single docs repo at construction time.

        Returns the file's UTF-8 text on success, or None on a
        miss (file doesn't exist, isn't a regular file, or
        unreadable). Raises ``ForgeError`` only on unexpected
        decode errors so caller failover can degrade.

        Use case: when the operator's project has the upstream
        skill prose mirrored into the docs repo (e.g. a docs/
        snapshot of the skill), this adapter answers; otherwise
        falls through to the next adapter via
        ``ReplicationManager.read`` failover.
        """
        target = self._path / path
        if not target.is_file():
            return None
        try:
            return target.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return None

    async def list_milestones(
        self, owner: str, repo: str, state: str = "all"
    ) -> list[Milestone]:
        # milestones/<X.Y.Z>.md is narrative-only; we return a list with
        # title-only Milestones (number=0; state derived from filename
        # patterns isn't available, default to open).
        ms_dir = self._path / "milestones"
        if not ms_dir.exists():
            return []
        result: list[Milestone] = []
        for entry in sorted(ms_dir.iterdir()):
            if entry.is_file() and entry.suffix == ".md":
                title = entry.stem
                result.append(Milestone(title=title, number=0, state="open"))
        return result

    async def find_milestone(
        self, owner: str, repo: str, name_or_number: str | int
    ) -> Milestone | None:
        """Resolve a milestone by title (string) or raise on integer ID.

        LocalStore's filesystem schema is title-keyed —
        ``milestones/<title>.md`` — and has no native integer-ID
        concept. ``Milestone.number`` is always ``0`` in
        ``list_milestones``. Passing an integer to ``find_milestone``
        is therefore unanswerable; raise so the caller learns about
        the limitation rather than silently receiving ``None``
        (which would be indistinguishable from "not found").
        Callers that need integer-ID resolution should run on a
        backend that has them (Forgejo / GitLab / GitHub).
        """
        if isinstance(name_or_number, int):
            raise _errors.ForgeError(
                "LocalStoreAdapter: find_milestone(int) is not supported "
                "— LocalStore identifies milestones by title, not number. "
                "Pass the milestone title as a string, or run this lookup "
                "on a numeric-ID backend (Forgejo / GitLab / GitHub)."
            )
        ms_file = self._path / "milestones" / f"{name_or_number}.md"
        if ms_file.exists():
            return Milestone(title=name_or_number, number=0, state="open")
        return None

    # =====================================================================
    # Issue operations
    # =====================================================================

    async def create_issue(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        labels: list[str],
        milestone: str | int | None = None,
    ) -> Issue:
        number = self._next_artifact_number("issues")
        issue_dir = self._path / "issues" / str(number)
        issue_dir.mkdir(parents=True)

        (issue_dir / "title.md").write_text(title.rstrip() + "\n", encoding="utf-8")
        (issue_dir / "body.md").write_text(body, encoding="utf-8")
        (issue_dir / "state.txt").write_text("open\n", encoding="utf-8")
        labels_text = "\n".join(labels) + ("\n" if labels else "")
        (issue_dir / "labels.txt").write_text(labels_text, encoding="utf-8")

        meta = {
            "number": number,
            "url": None,
            "node_id": None,
            "milestone": str(milestone) if milestone is not None else None,
            "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            "created_by": self.platform_id,
            "github_replication_status": (
                "pending — replays as real Issue when access returns"
            ),
        }
        (issue_dir / "meta.json").write_text(
            json.dumps(meta, indent=2) + "\n", encoding="utf-8"
        )

        self._auto_commit(f"local: create_issue #{number}: {title[:60]}")

        return Issue(
            ref=self._make_ref(
                native_id=f"issues/{number}",
                kind="issue",
                owner=owner,
                repo=repo,
                number=number,
            ),
            title=title,
            body=body,
            state="open",
            labels=list(labels),
            milestone=str(milestone) if milestone is not None else None,
            url=f"local://issues/{number}",
        )

    async def get_issue(self, owner: str, repo: str, number: int) -> Issue:
        issue_dir = self._path / "issues" / str(number)
        if not issue_dir.exists():
            raise _errors.InvalidArtifactRefError("issue number", str(number))
        return self._read_issue(owner=owner, repo=repo, number=number, issue_dir=issue_dir)

    def _append_history(
        self,
        artifact_dir: Path,
        operation: str,
        payload: dict[str, Any],
    ) -> None:
        """Append a timestamped JSON entry to the artifact's history/
        directory (3.0 / Phase 6 sub-run C — append-only schema per OQ3).

        Each mutation (body update, state change, label add/remove,
        decision) writes one JSON file: ``history/<utc-ts>-<op>.json``.
        Current-state files (body.md, state.txt, labels.txt) remain the
        authoritative quick-read surface; the history log is the
        durable audit trail.

        Failures are swallowed — a history-write failure should never
        block the canonical write that triggered it. The history is
        defense in depth, not a hard dependency.
        """
        try:
            history_dir = artifact_dir / "history"
            history_dir.mkdir(exist_ok=True)
            ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            entry = {
                "timestamp": ts,
                "operation": operation,
                **payload,
            }
            (history_dir / f"{ts}-{operation}.json").write_text(
                json.dumps(entry, indent=2) + "\n",
                encoding="utf-8",
            )
        except OSError:
            # History is best-effort.
            pass

    async def get_issue_body(self, ref: ArtifactRef) -> str:
        body_file = self._artifact_dir_from_ref(ref) / "body.md"
        if not body_file.parent.exists():
            raise _errors.InvalidArtifactRefError("ref.native_id", ref.native_id)
        if not body_file.exists():
            return ""
        return body_file.read_text(encoding="utf-8")

    async def update_issue_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        body_file = self._artifact_dir_from_ref(ref) / "body.md"
        if not body_file.parent.exists():
            raise _errors.InvalidArtifactRefError("ref.native_id", ref.native_id)
        prior_body = body_file.read_text(encoding="utf-8") if body_file.exists() else ""
        body_file.write_text(new_body, encoding="utf-8")
        self._append_history(
            body_file.parent,
            "update_body",
            {"prior_length": len(prior_body), "new_length": len(new_body)},
        )
        rel = body_file.parent.relative_to(self._path)
        self._auto_commit(f"local: update_body on {rel}")

    async def update_issue_milestone(
        self, ref: ArtifactRef, milestone_title: str | None,
    ) -> None:
        """(#388, 3.9.0 D5) Set the issue's meta.json `milestone` field.

        ``milestone_title=None`` clears the field. Writes meta.json
        atomically (read → mutate → write) and appends a history
        entry; auto-commits when the LocalStore is in
        autocommit mode.
        """
        import json as _json
        artifact_dir = self._artifact_dir_from_ref(ref)
        meta_file = artifact_dir / "meta.json"
        if not meta_file.parent.exists():
            raise _errors.InvalidArtifactRefError(
                "ref.native_id", ref.native_id,
            )
        meta: dict
        if meta_file.exists():
            try:
                meta = _json.loads(
                    meta_file.read_text(encoding="utf-8"),
                )
            except _json.JSONDecodeError:
                meta = {}
        else:
            meta = {}
        prior = meta.get("milestone")
        meta["milestone"] = milestone_title
        meta_file.write_text(
            _json.dumps(meta, indent=2) + "\n", encoding="utf-8",
        )
        self._append_history(
            meta_file.parent,
            "update_milestone",
            {"prior": prior, "new": milestone_title},
        )
        rel = meta_file.parent.relative_to(self._path)
        self._auto_commit(
            f"local: update_milestone on {rel} → {milestone_title!r}"
        )

    async def close_issue(
        self, ref: ArtifactRef, state_reason: str = "completed"
    ) -> Issue:
        issue_dir = self._artifact_dir_from_ref(ref)
        state_file = issue_dir / "state.txt"
        prior_text = state_file.read_text(encoding="utf-8") if state_file.exists() else ""
        states = vocab.parse_state_file(prior_text)
        # Replace lifecycle axis: open → closed.
        states.discard("open")
        states.add("closed")
        state_file.write_text(vocab.render_state_file(states), encoding="utf-8")
        self._append_history(
            state_file.parent,
            "close_issue",
            {"prior_state": prior_text.strip(), "state_reason": state_reason,
             "new_state": "\n".join(sorted(states))},
        )
        rel = state_file.parent.relative_to(self._path)
        self._auto_commit(f"local: close_issue on {rel}")
        # Return the now-closed Issue. ref.number may be None for
        # cross-adapter refs; fall back to parsing native_id which
        # is "issues/N" / "discussions/N" by local convention.
        number = ref.number
        if number is None:
            tail = ref.native_id.rsplit("/", 1)[-1]
            try:
                number = int(tail)
            except ValueError:
                number = 0
        return self._read_issue(
            owner=ref.owner, repo=ref.repo,
            number=number, issue_dir=issue_dir,
        )

    async def add_label(self, ref: ArtifactRef, label_name: str) -> None:
        labels_file = self._artifact_dir_from_ref(ref) / "labels.txt"
        existing = (
            labels_file.read_text(encoding="utf-8").splitlines()
            if labels_file.exists() else []
        )
        existing_set = {line.strip() for line in existing if line.strip()}
        if label_name in existing_set:
            return
        existing_set.add(label_name)
        labels_file.write_text(
            "\n".join(sorted(existing_set)) + "\n", encoding="utf-8",
        )
        self._append_history(
            labels_file.parent,
            "add_label",
            {"label": label_name, "labels_after": sorted(existing_set)},
        )
        rel = labels_file.parent.relative_to(self._path)
        self._auto_commit(f"local: add_label {label_name!r} on {rel}")

    async def remove_label(self, ref: ArtifactRef, label_name: str) -> None:
        labels_file = self._artifact_dir_from_ref(ref) / "labels.txt"
        if not labels_file.exists():
            return
        existing = labels_file.read_text(encoding="utf-8").splitlines()
        kept = [line for line in existing if line.strip() and line.strip() != label_name]
        if [l.strip() for l in existing if l.strip()] == [l.strip() for l in kept if l.strip()]:
            # Label wasn't present; no-op (don't write a misleading history entry).
            return
        labels_file.write_text(
            "\n".join(kept) + ("\n" if kept else ""), encoding="utf-8",
        )
        self._append_history(
            labels_file.parent,
            "remove_label",
            {"label": label_name, "labels_after": [l.strip() for l in kept if l.strip()]},
        )
        rel = labels_file.parent.relative_to(self._path)
        self._auto_commit(f"local: remove_label {label_name!r} on {rel}")

    async def search_issues(
        self,
        *,
        owner: str,
        repo: str,
        query: str = "",
        state: str = "all",
        labels: list[str] | None = None,
        milestone: str | None = None,
        limit: int = 30,
    ) -> SearchResult:
        # Simple implementation: walk all issues, filter, then optionally
        # match query against title/body. Adequate for solo-dev scale.
        issues_dir = self._path / "issues"
        if not issues_dir.exists():
            return SearchResult(results=[], total_count=0, query=query)
        # Walk every issue to count total matches; track ``results`` up
        # to the limit. ``total_count`` reflects the full set so callers
        # can detect "more available" without re-querying.
        results: list[Issue] = []
        total = 0
        for entry in sorted(issues_dir.iterdir(), key=lambda e: e.name):
            if not entry.is_dir():
                continue
            try:
                number = int(entry.name)
            except ValueError:
                continue
            issue = self._read_issue(
                owner=owner, repo=repo, number=number, issue_dir=entry,
            )
            if state != "all" and issue.state != state:
                continue
            if labels:
                if not all(lbl in issue.labels for lbl in labels):
                    continue
            if milestone is not None and issue.milestone != milestone:
                continue
            if query and query.lower() not in (issue.title + " " + issue.body).lower():
                continue
            total += 1
            if len(results) < limit:
                results.append(issue)
        return SearchResult(
            results=results, total_count=total, query=query,
        )

    async def list_open_issues(
        self, *, owner: str, repo: str, limit: int = 100
    ) -> list[Issue]:
        result = await self.search_issues(
            owner=owner, repo=repo, state="open", limit=limit,
        )
        return list(result.results)

    # =====================================================================
    # Discussion operations
    # =====================================================================

    async def create_discussion(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        category: str | None = None,
    ) -> Discussion:
        number = self._next_artifact_number("discussions")
        disc_dir = self._path / "discussions" / str(number)
        disc_dir.mkdir(parents=True)

        (disc_dir / "title.md").write_text(title.rstrip() + "\n", encoding="utf-8")
        (disc_dir / "body.md").write_text(body, encoding="utf-8")
        (disc_dir / "state.txt").write_text("open\n", encoding="utf-8")

        # Encode kind:discussion + category:* per OQ1.
        labels = ["kind:discussion"]
        if category:
            labels.append(f"category:{category.lower().replace(' / ', '_').replace(' ', '_')}")
        (disc_dir / "labels.txt").write_text("\n".join(labels) + "\n", encoding="utf-8")

        meta = {
            "number": number,
            "url": None,
            "node_id": None,
            "category": category,
            "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            "created_by": self.platform_id,
        }
        (disc_dir / "meta.json").write_text(
            json.dumps(meta, indent=2) + "\n", encoding="utf-8"
        )

        self._auto_commit(f"local: create_discussion #{number}: {title[:60]}")

        return Discussion(
            ref=self._make_ref(
                native_id=f"discussions/{number}",
                kind="discussion",
                owner=owner,
                repo=repo,
                number=number,
            ),
            title=title,
            body=body,
            category=category,
            labels=labels,
            url=f"local://discussions/{number}",
        )

    async def get_discussion(
        self, owner: str, repo: str, number: int
    ) -> Discussion:
        disc_dir = self._path / "discussions" / str(number)
        if not disc_dir.exists():
            raise _errors.InvalidArtifactRefError("discussion number", str(number))
        return self._read_discussion(
            owner=owner, repo=repo, number=number, disc_dir=disc_dir,
        )

    async def get_discussion_body(self, ref: ArtifactRef) -> str:
        # Discussions are stored under discussions/ but the body shape
        # is identical — same body.md file, same _artifact_dir_from_ref
        # resolution.
        return await self.get_issue_body(ref)

    async def update_discussion_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        await self.update_issue_body(ref, new_body, force)  # same shape

    async def list_recent_discussions(
        self, *, owner: str, repo: str, since_days: int = 7
    ) -> list[Discussion]:
        disc_root = self._path / "discussions"
        if not disc_root.exists():
            return []
        cutoff = datetime.now(timezone.utc).timestamp() - (since_days * 86400)
        result: list[Discussion] = []
        for entry in sorted(disc_root.iterdir()):
            if not entry.is_dir():
                continue
            try:
                number = int(entry.name)
            except ValueError:
                continue
            mtime = entry.stat().st_mtime
            if mtime < cutoff:
                continue
            result.append(self._read_discussion(
                owner=owner, repo=repo, number=number, disc_dir=entry,
            ))
        return result

    async def mark_decided(self, ref: ArtifactRef) -> None:
        state_file = self._artifact_dir_from_ref(ref) / "state.txt"
        prior_text = state_file.read_text(encoding="utf-8") if state_file.exists() else "open\n"
        states = vocab.parse_state_file(prior_text)
        states.add("decided")
        state_file.write_text(vocab.render_state_file(states), encoding="utf-8")
        self._append_history(
            state_file.parent,
            "mark_decided",
            {"prior_state": prior_text.strip(), "new_state": "\n".join(sorted(states))},
        )
        rel = state_file.parent.relative_to(self._path)
        self._auto_commit(f"local: mark_decided on {rel}")

    async def mark_answer(self, comment_ref: ArtifactRef) -> None:
        # LocalStoreAdapter has no comment-level answer concept.
        # Callers should use mark_decided against the parent.
        raise NotImplementedError(
            "LocalStoreAdapter.mark_answer: filesystem store has no "
            "comment-level answer feature. Use mark_decided(parent_ref) "
            "for the portable `decided` label on the parent discussion."
        )

    # =====================================================================
    # Comment operations
    # =====================================================================

    async def append_comment(self, target: ArtifactRef, body: str) -> Comment:
        target_dir = self._artifact_dir_from_ref(target)
        if target_dir.exists():
            comments_dir = target_dir / "comments"
            relative_dir = target_dir.relative_to(self._path) / "comments"
        else:
            # Orphan: target ref doesn't resolve. Comment lands in
            # _orphan-comments/ for later reconciliation.
            comments_dir = self._path / "_orphan-comments"
            relative_dir = Path("_orphan-comments")
        comments_dir.mkdir(parents=True, exist_ok=True)

        # Use microsecond precision in the filename so two near-instant
        # comments don't collide AND filename-sort = chronological sort.
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%S-%fZ")
        # Author taken from environment or default. Future: thread through
        # the adapter constructor / from_config.
        author = "claude"
        filename = f"{ts}-{author}.md"
        comment_file = comments_dir / filename
        comment_file.write_text(body, encoding="utf-8")

        relative_path = relative_dir / filename
        self._auto_commit(f"local: append_comment on {relative_dir}")

        return Comment(
            ref=self._make_ref(
                native_id=str(relative_path),
                kind="comment",
                owner=target.owner,
                repo=target.repo,
            ),
            body=body,
            author=author,
            created_at=datetime.now(timezone.utc),
            parent=target,
        )

    async def list_comments(
        self,
        target: ArtifactRef,
        *,
        since_days: int | None = None,
        limit: int | None = None,
    ) -> list[Comment]:
        target_dir = self._artifact_dir_from_ref(target)
        comments_dir = target_dir / "comments"
        if not comments_dir.exists():
            return []
        cutoff = (
            datetime.now(timezone.utc).timestamp() - (since_days * 86400)
            if since_days is not None else None
        )
        result: list[Comment] = []
        # Sort by mtime for robustness — filename sort with microsecond
        # timestamps is also chronological, but mtime handles edge cases
        # like manually-added comment files that don't follow the
        # timestamp-prefix convention.
        for entry in sorted(comments_dir.iterdir(), key=lambda e: e.stat().st_mtime):
            if not entry.is_file():
                continue
            mtime = entry.stat().st_mtime
            if cutoff is not None and mtime < cutoff:
                continue
            # Filename convention: <utc-ts>-<author>.md where utc-ts is
            # 27 chars (YYYY-MM-DDTHH-MM-SS-ffffffZ). Author is everything
            # between the timestamp suffix and `.md`.
            stem = entry.stem
            ts_end = 27  # YYYY-MM-DDTHH-MM-SS-ffffffZ
            author = stem[ts_end + 1:] if len(stem) > ts_end + 1 else "unknown"
            result.append(Comment(
                ref=self._make_ref(
                    native_id=str(entry.relative_to(self._path)),
                    kind="comment",
                    owner=target.owner,
                    repo=target.repo,
                ),
                body=entry.read_text(encoding="utf-8"),
                author=author,
                created_at=datetime.fromtimestamp(mtime, tz=timezone.utc),
                parent=target,
            ))
        if limit is not None and len(result) > limit:
            result = result[-limit:]
        return result

    # =====================================================================
    # Label management
    # =====================================================================

    async def ensure_label(
        self,
        *,
        owner: str,
        repo: str,
        name: str,
        color: str = "0E8A16",
        description: str = "",
    ) -> str:
        # Local store has open-set labels: any string in any artifact's
        # labels.txt is "ensured" implicitly. Return a synthetic ID for
        # contract conformance.
        return f"local-label://{name}"

    # =====================================================================
    # Release operations
    # =====================================================================

    async def create_release(
        self,
        *,
        owner: str,
        repo: str,
        tag: str,
        name: str,
        body: str = "",
        prerelease: bool = False,
        draft: bool = False,
    ) -> Release:
        """Local-only release record.

        Useful for the release-canonical-source-of-truth pattern:
        write the release metadata locally first, then replicate to
        whichever backends host published releases (GitHub, etc.) per
        the multi-host replication model.

        Persistence schema (PAR-2): YAML frontmatter for structured
        fields the body alone can't carry (``prerelease`` flag,
        ``created_at`` timestamp), then the standard H1-headed
        markdown body. Loss-free round-trip when a future
        ``get_release`` / ``list_releases`` reader lands.
        """
        releases_dir = self._path / "releases"
        releases_dir.mkdir(exist_ok=True)
        release_file = releases_dir / f"{tag}.md"
        created_at = datetime.now(timezone.utc)
        frontmatter = (
            "---\n"
            f"tag: {tag}\n"
            f"name: {name}\n"
            f"prerelease: {'true' if prerelease else 'false'}\n"
            f"draft: {'true' if draft else 'false'}\n"
            f"created_at: {created_at.isoformat()}\n"
            "---\n"
        )
        release_file.write_text(
            f"{frontmatter}# {name}\n\n{body}\n", encoding="utf-8",
        )
        self._auto_commit(f"local: create_release {tag}")
        return Release(
            tag=tag,
            name=name,
            body=body,
            prerelease=prerelease,
            created_at=created_at,
            url=f"local://releases/{tag}",
        )

    def get_clone_url(self, owner: str, repo: str) -> str:
        """Synthetic local URL — there's no remote to clone from (#282).

        Returns ``local://{owner}/{repo}``. Handlers consuming this
        should never pass it to ``git clone``; it's a sentinel for
        canonical-store-only operation.
        """
        return f"local://{owner}/{repo}"

    def noreply_email(
        self, login: str, user_id: int | None = None
    ) -> str:
        """Synthetic local noreply email (#282)."""
        del user_id  # not used; accepted for Protocol uniformity
        return f"claude+{login}@local.invalid"

    def public_issue_url_regex(self) -> "re.Pattern[str]":
        """Never-matches sentinel (#11).

        LocalStore has no public-issue URL surface — there's no remote
        host serving Issue pages. Return a regex that matches nothing
        rather than letting handlers default into a wrong pattern.
        """
        import re
        return re.compile(r"(?!)")  # always-fails pattern (negative lookahead at start)

    async def delete_release(
        self, *, owner: str, repo: str, tag: str,
    ) -> None:
        """Remove a local Release record by tag (#294 Phase A).

        Unlinks ``<docs>/releases/{tag}.md`` if it exists. Idempotent —
        a missing file is treated as already-deleted.
        """
        del owner, repo  # local store doesn't carry owner/repo state
        release_file = self._path / "releases" / f"{tag}.md"
        try:
            release_file.unlink()
        except FileNotFoundError:
            return  # already deleted
        self._auto_commit(f"local: delete_release {tag}")

    # =====================================================================
    # File-content reads
    # =====================================================================

    async def fetch_file_content(
        self, *, owner: str, repo: str, path: str, ref: str = "main"
    ) -> str | None:
        # Local store can serve content from the docs repo's checkout.
        # Path-relative-to-docs-repo lookup; ref ignored (always HEAD).
        target = self._path / path
        if target.exists() and target.is_file():
            return target.read_text(encoding="utf-8")
        return None

    # =====================================================================
    # Bundled reads (Phase C5)
    # =====================================================================

    async def bundle_recover_context(
        self,
        *,
        owner: str,
        repo: str,
        toc_discussion_id: str,
        since_days: int = 7,
        issue_limit: int = 100,
    ) -> RecoveryBundle:
        # LocalStore has no concept of "batched" — every read hits
        # the filesystem regardless. Use the shared decomposed default.
        return await _recovery.default_bundle_recover_context(
            self, owner=owner, repo=repo,
            toc_discussion_id=toc_discussion_id,
            since_days=since_days, issue_limit=issue_limit,
        )

    # =====================================================================
    # Session lock (canonical-side groundwork for open_session fix)
    # =====================================================================

    async def record_session_event(
        self, *, session_id: str, event: str, body: str = "",
    ) -> SessionEvent:
        """Persist one session-lifecycle event to the canonical store.

        Writes ``<docs_repo>/sessions/<session_id>/<utc-ts>-<event>.json``
        with the timestamp embedded both in the filename (for cheap
        chronological glob) and in the JSON body (for round-trip read).
        Idempotent at the file level — microsecond precision in the
        timestamp prevents collisions even when called in rapid
        succession.

        Foundation surface for the open_session handler migration that
        the bug filed in this session calls for. Once the handler
        dispatches through ``ctx.replication.write``, this becomes the
        canonical write target with the GitHub Session Lock Discussion
        as the (degradable) mirror.
        """
        if not session_id.strip():
            raise _errors.ForgeError(
                "record_session_event: session_id must not be empty."
            )
        if not event.strip():
            raise _errors.ForgeError(
                "record_session_event: event kind must not be empty."
            )
        sessions_dir = self._path / "sessions" / session_id
        sessions_dir.mkdir(parents=True, exist_ok=True)
        now = datetime.now(timezone.utc)
        ts_str = now.strftime("%Y-%m-%dT%H-%M-%S-%fZ")
        payload = {
            "session_id": session_id,
            "event": event,
            "body": body,
            "timestamp": now.isoformat(),
        }
        (sessions_dir / f"{ts_str}-{event}.json").write_text(
            json.dumps(payload, indent=2), encoding="utf-8",
        )
        return SessionEvent(
            session_id=session_id,
            event=event,
            body=body,
            timestamp=now,
        )

    async def read_session_events(
        self, *, last_n: int | None = None,
    ) -> list[SessionEvent]:
        """Return session events oldest-first, optionally clipped to
        the most recent ``last_n``.

        Globs every ``sessions/<id>/*.json``, parses each, sorts by the
        embedded timestamp, and returns the resulting list. ``last_n``
        clamps from the tail (most-recent N) — None returns all events.
        Used by the future open_session handler to compute
        ``prior_session_clean`` from the canonical store rather than the
        GitHub Session Lock Discussion.
        """
        sessions_root = self._path / "sessions"
        if not sessions_root.exists():
            return []
        events: list[SessionEvent] = []
        for session_dir in sessions_root.iterdir():
            if not session_dir.is_dir():
                continue
            for entry in session_dir.iterdir():
                if not entry.is_file() or entry.suffix != ".json":
                    continue
                try:
                    raw = json.loads(entry.read_text(encoding="utf-8"))
                except json.JSONDecodeError:
                    # Skip malformed entries silently — they may be
                    # mid-write or hand-edited; loud failure here would
                    # poison every session-start probe.
                    continue
                ts_value = raw.get("timestamp")
                if not ts_value:
                    continue
                try:
                    ts = datetime.fromisoformat(ts_value)
                except ValueError:
                    continue
                events.append(SessionEvent(
                    session_id=str(raw.get("session_id", session_dir.name)),
                    event=str(raw.get("event", "")),
                    body=str(raw.get("body", "")),
                    timestamp=ts,
                ))
        events.sort(key=lambda e: e.timestamp)
        if last_n is not None and last_n >= 0 and len(events) > last_n:
            events = events[-last_n:]
        return events

    # =====================================================================
    # Bootstrap (multi-platform scaffold C1)
    # =====================================================================

    async def bootstrap_project(
        self,
        *,
        owner: str,
        project_name: str,
        description: str,
        existing_state: dict | None = None,
    ) -> BootstrapResult:
        """Bootstrap the local canonical docs repo.

        Composes the existing ``ensure_local_docs_repo`` helper (Gap A)
        with placeholder-directory creation. Idempotent — re-running
        no-ops on each step that already completed.

        ``owner`` and ``description`` are accepted for Protocol parity
        but unused here; LocalStore identity is the filesystem path,
        not an org/account, and the README is generated from
        ``project_name``. ``existing_state`` is also accepted for
        Protocol parity; nothing the LocalStore step does depends on
        prior adapters.
        """
        actions = ensure_local_docs_repo(
            self._path,
            project_name=project_name,
            remote_url=None,
        )
        placeholder_dirs = ("issues", "discussions", "milestones")
        for name in placeholder_dirs:
            (self._path / name).mkdir(parents=True, exist_ok=True)
        return BootstrapResult(
            platform_id=self.platform_id,
            artifacts={
                "docs_repo_path": str(self._path),
                "dir": actions["dir"],
                "readme": actions["readme"],
                "git": actions["git"],
                "placeholders": list(placeholder_dirs),
            },
            manual_steps=[],
            phase="complete",
        )

    # =====================================================================
    # Health + drift
    # =====================================================================

    async def probe(self) -> bool:
        # Filesystem is always reachable if the dir exists. Adapter
        # init validates this; if dir was deleted post-init, return False.
        return self._path.exists()

    # =====================================================================
    # History query (#274 Phase D — read counterpart to _append_history)
    # =====================================================================

    async def query_history(
        self,
        ref: ArtifactRef,
        *,
        since: datetime | None = None,
        operation: str | None = None,
    ) -> list[HistoryEntry]:
        """Return audit-log entries for an artifact, oldest-first.

        Reads ``<artifact_dir>/history/*.json``, parses each into a
        ``HistoryEntry``, and returns the result sorted by timestamp.

        Filters:
          * ``since`` — only entries newer than (or equal to) this
            timestamp. None means "all history".
          * ``operation`` — only entries whose ``operation`` field
            matches exactly (e.g., ``"close_issue"``).

        ``ref`` resolves through the same ``_artifact_dir_from_ref``
        path the mutation methods use, so cross-adapter refs (a
        GitHub-platform ref pointing at the same artifact) work too
        — the directory lookup walks meta.json files for a matching
        node ID.

        Empty list when the artifact has no history yet (newly-
        created or pre-Phase-6 records).
        """
        artifact_dir = self._artifact_dir_from_ref(ref)
        history_dir = artifact_dir / "history"
        if not history_dir.exists():
            return []

        entries: list[HistoryEntry] = []
        for entry_path in sorted(history_dir.iterdir(), key=lambda p: p.name):
            if not entry_path.is_file() or entry_path.suffix != ".json":
                continue
            try:
                raw = json.loads(entry_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                # Best-effort read — skip malformed entries rather
                # than failing the whole query.
                continue

            ts_str = raw.get("timestamp", "")
            try:
                # _append_history writes "%Y%m%dT%H%M%S%fZ" — same
                # parser that handles it.
                ts = datetime.strptime(
                    ts_str, "%Y%m%dT%H%M%S%fZ",
                ).replace(tzinfo=timezone.utc)
            except (ValueError, TypeError):
                continue

            op = raw.get("operation", "")
            if operation is not None and op != operation:
                continue
            if since is not None and ts < since:
                continue

            payload = {
                k: v for k, v in raw.items()
                if k not in ("timestamp", "operation")
            }
            entries.append(HistoryEntry(
                ref=ref,
                timestamp=ts,
                operation=op,
                payload=payload,
            ))
        return entries

    async def aggregate_history_since(
        self,
        *,
        since: datetime,
        kind: ArtifactKind | None = None,
        owner: str = "",
        repo: str = "",
    ) -> list[HistoryEntry]:
        """Return every ``HistoryEntry`` newer than ``since`` across the
        whole canonical store, oldest-first.

        Walks ``issues/*/history/*.json`` and
        ``discussions/*/history/*.json`` (filtered by ``kind`` when set),
        delegating per-artifact parsing to ``query_history``. Useful for
        the time-window complement to ``compute_drift``'s set-based
        view: "what changed locally in the last N hours" → can drive
        replay decisions, drift-recheck cadences, and
        ``import_remote_changes`` reconciliation.

        ``owner`` / ``repo`` populate the resulting refs but don't gate
        filtering — the local store has one canonical set of artifacts;
        cross-repo discrimination isn't a concept here. Callers that
        carry per-repo refs through the manager pass them through.
        """
        kinds_to_walk: list[tuple[str, ArtifactKind]] = []
        if kind in (None, "issue"):
            kinds_to_walk.append(("issues", "issue"))
        if kind in (None, "discussion"):
            kinds_to_walk.append(("discussions", "discussion"))

        results: list[HistoryEntry] = []
        for subdir, kind_label in kinds_to_walk:
            root = self._path / subdir
            if not root.exists():
                continue
            for entry in sorted(root.iterdir(), key=lambda p: p.name):
                if not entry.is_dir():
                    continue
                try:
                    number = int(entry.name)
                except ValueError:
                    continue
                ref = self._make_ref(
                    native_id=f"{subdir}/{number}",
                    kind=kind_label,
                    owner=owner,
                    repo=repo,
                    number=number,
                )
                # Per-artifact filter is handled by query_history;
                # accumulate.
                results.extend(
                    await self.query_history(ref, since=since)
                )
        # Merge-sort the per-artifact lists by timestamp.
        results.sort(key=lambda e: e.timestamp)
        return results

    async def snapshot(
        self, *, owner: str, repo: str,
        since: datetime | None = None,
    ) -> dict:
        """Emit the local-canonical state as a structured dict that
        remote adapters' ``compute_drift`` can compare against.

        Shape:

            {
              "platform_id": "local",
              "issues": {<number>: {"state": "...", "labels": [...]}, ...},
              "discussions": {<number>: {"state": "...", "labels": [...]}, ...},
              "milestones": [<title>, ...],
              "since": "<iso>" | null,  # echoed only when narrowed
            }

        ``since`` (Phase D drift improvement): when set, the issues /
        discussions maps are filtered to only those with a history
        entry newer than the cutoff. Useful for "what diverges in
        the last N hours" drift queries — pairs naturally with
        ``aggregate_history_since``. Milestones aren't filtered
        because they don't carry per-artifact history.

        Body content + per-comment lists are excluded — drift detection
        in 3.0 Phase 6 sub-run B is set-based (membership + state).
        Field-level divergence detection (body diffs) is deferred to
        sub-run C / a future phase.
        """
        # Pre-compute the set of artifact numbers that changed since
        # the cutoff, if a cutoff is set. Otherwise None means
        # "include everything".
        recent_issue_numbers: set[int] | None = None
        recent_disc_numbers: set[int] | None = None
        if since is not None:
            recent_issues = await self.aggregate_history_since(
                since=since, kind="issue", owner=owner, repo=repo,
            )
            recent_issue_numbers = {
                e.ref.number for e in recent_issues
                if e.ref.number is not None
            }
            recent_discs = await self.aggregate_history_since(
                since=since, kind="discussion", owner=owner, repo=repo,
            )
            recent_disc_numbers = {
                e.ref.number for e in recent_discs
                if e.ref.number is not None
            }

        result: dict[str, Any] = {
            "platform_id": self.platform_id,
            "owner": owner,
            "repo": repo,
            "issues": {},
            "discussions": {},
            "milestones": [],
            "since": since.isoformat() if since is not None else None,
        }

        issues_dir = self._path / "issues"
        if issues_dir.exists():
            for entry in sorted(issues_dir.iterdir()):
                if not entry.is_dir():
                    continue
                try:
                    number = int(entry.name)
                except ValueError:
                    continue
                if (
                    recent_issue_numbers is not None
                    and number not in recent_issue_numbers
                ):
                    continue
                state_lines = (entry / "state.txt").read_text(
                    encoding="utf-8",
                ).strip().splitlines() if (entry / "state.txt").exists() else []
                state = state_lines[0].strip() if state_lines else "open"
                labels_text = (entry / "labels.txt").read_text(
                    encoding="utf-8",
                ).strip() if (entry / "labels.txt").exists() else ""
                labels = [l.strip() for l in labels_text.splitlines() if l.strip()]
                result["issues"][number] = {"state": state, "labels": labels}

        disc_dir = self._path / "discussions"
        if disc_dir.exists():
            for entry in sorted(disc_dir.iterdir()):
                if not entry.is_dir():
                    continue
                try:
                    number = int(entry.name)
                except ValueError:
                    continue
                if (
                    recent_disc_numbers is not None
                    and number not in recent_disc_numbers
                ):
                    continue
                state_lines = (entry / "state.txt").read_text(
                    encoding="utf-8",
                ).strip().splitlines() if (entry / "state.txt").exists() else []
                state = state_lines[0].strip() if state_lines else "open"
                labels_text = (entry / "labels.txt").read_text(
                    encoding="utf-8",
                ).strip() if (entry / "labels.txt").exists() else ""
                labels = [l.strip() for l in labels_text.splitlines() if l.strip()]
                result["discussions"][number] = {"state": state, "labels": labels}

        ms_dir = self._path / "milestones"
        if ms_dir.exists():
            for entry in sorted(ms_dir.iterdir()):
                if entry.is_file() and entry.suffix == ".md":
                    result["milestones"].append(entry.stem)

        return result

    async def compute_drift(self, snapshot: dict) -> DriftReport:
        # Local IS the canonical source of truth — no drift against itself.
        return DriftReport(platform_id=self.platform_id, is_clean=True)

    # =====================================================================
    # Project board sub-Protocol (forgejo #10 / 3.4.0) — NotImplementedError
    # =====================================================================
    #
    # LocalStore has no project-board concept; status tracking happens
    # via the existing state.txt convention on each artifact directory.
    # Could be added (e.g., a boards/<name>/items.txt schema) but no
    # concrete need yet — operators with LocalStore-only projects use
    # the kind/category labels for organization.

    async def add_to_project_board(
        self, *, board_id: str, ref,
    ) -> str:
        raise NotImplementedError(
            "LocalStoreAdapter.add_to_project_board: LocalStore has "
            "no project-board concept. Status tracking is per-artifact "
            "via state.txt; project boards are a UI concept that "
            "would need a boards/<name>/items.txt schema to model."
        )

    async def get_project_status_field(
        self, *, board_id: str,
    ) -> dict:
        raise NotImplementedError(
            "LocalStoreAdapter.get_project_status_field: see "
            "add_to_project_board for the LocalStore project-boards "
            "non-implementation."
        )

    async def get_project_item_id(
        self, *, ref, board_id: str,
    ) -> str:
        raise NotImplementedError(
            "LocalStoreAdapter.get_project_item_id: see "
            "add_to_project_board."
        )

    async def move_project_item(
        self, *, board_id: str, item_id: str,
        status_field_id: str, option_id: str,
    ) -> None:
        raise NotImplementedError(
            "LocalStoreAdapter.move_project_item: see "
            "add_to_project_board."
        )

    async def fetch_remote_changes(
        self, *, since: datetime, owner: str, repo: str,
    ) -> list[RemoteChange]:
        """Treat the local history as a "remote" change feed.

        Useful for testing the ``import_remote_changes`` flow with
        two LocalStores: one acts as the "remote" source, the other
        as the canonical sink. In production, the canonical store
        is unique per project so this is mostly a test substrate —
        but the contract is well-defined and the implementation is
        the foundation for live remote-fetch impls per the deferred
        OQ4 work.
        """
        history = await self.aggregate_history_since(
            since=since, owner=owner, repo=repo,
        )
        return [
            RemoteChange(
                source_platform_id=self.platform_id,
                ref=entry.ref,
                operation=entry.operation,
                observed_at=entry.timestamp,
                payload=entry.payload,
            )
            for entry in history
        ]

    async def apply_remote_change(
        self, change: RemoteChange,
    ) -> ImportConflict | None:
        """Apply a ``RemoteChange`` to the canonical store.

        Conflict detection: if the local history on the same artifact
        contains an entry newer than ``change.observed_at`` whose
        ``source_platform_id`` doesn't match the incoming change's
        source, that's a conflict — the canonical has been mutated
        independently since the remote observed its state. Return an
        ``ImportConflict`` describing the divergence; don't apply.

        Otherwise: dispatch on ``change.operation`` to the matching
        adapter method. Returns None on clean apply.

        Foundation: supports the operations the canonical store
        knows how to round-trip (update_body / close_issue /
        add_label). Other operations return None as a no-op since
        they don't have a clean inverse on the local schema yet —
        callers can extend this method as adapters add their own
        operations.
        """
        # Resolve the local artifact dir — if the ref is from another
        # platform, _artifact_dir_from_ref walks meta.json files.
        try:
            artifact_dir = self._artifact_dir_from_ref(change.ref)
        except _errors.InvalidArtifactRefError:
            return ImportConflict(
                change=change,
                reason="local artifact not found for incoming ref",
            )
        if not artifact_dir.exists():
            return ImportConflict(
                change=change,
                reason="local artifact dir missing",
            )

        # Conflict check: any local history entry newer than
        # observed_at that wasn't sourced from this remote?
        local_history = await self.query_history(
            change.ref, since=change.observed_at,
        )
        diverging = [
            e for e in local_history
            # An entry written by import-of-this-source is fine; only
            # local-origin or other-source entries count as conflicts.
            # The local store's _append_history doesn't carry
            # source_platform_id today, so we treat ALL post-watermark
            # history as conflicting — conservative until import-
            # provenance lands.
            if e.timestamp > change.observed_at
        ]
        if diverging:
            return ImportConflict(
                change=change,
                reason=(
                    f"local has {len(diverging)} mutation(s) newer than "
                    f"the remote watermark {change.observed_at.isoformat()}"
                ),
                local_history=diverging,
            )

        # Dispatch on operation. The four below are the operations
        # the local schema can round-trip cleanly today.
        op = change.operation
        if op == "update_body":
            new_body = change.payload.get("new_body", "")
            await self.update_issue_body(change.ref, new_body)
        elif op == "close_issue":
            state_reason = change.payload.get("state_reason", "completed")
            await self.close_issue(change.ref, state_reason=state_reason)
        elif op == "add_label":
            label = change.payload.get("label", "")
            if label:
                await self.add_label(change.ref, label)
        elif op == "remove_label":
            label = change.payload.get("label", "")
            if label:
                await self.remove_label(change.ref, label)
        # Other operations — no-op. Callers can extend.
        return None

    # =====================================================================
    # Internal helpers
    # =====================================================================

    def _make_ref(
        self,
        *,
        native_id: str,
        kind: str,
        owner: str,
        repo: str,
        number: int | None = None,
    ) -> ArtifactRef:
        return ArtifactRef(
            platform_id=self.platform_id,
            native_id=native_id,
            kind=kind,  # type: ignore[arg-type]
            owner=owner,
            repo=repo,
            number=number,
        )

    def _next_artifact_number(self, kind: str) -> int:
        """Return ``max(existing-numeric-dirs) + 1`` for ``<kind>/``."""
        kind_dir = self._path / kind
        if not kind_dir.exists():
            return 1
        numbers: list[int] = []
        for entry in kind_dir.iterdir():
            if not entry.is_dir():
                continue
            try:
                numbers.append(int(entry.name))
            except ValueError:
                continue
        return max(numbers) + 1 if numbers else 1

    def _artifact_dir_from_ref(self, ref: ArtifactRef) -> Path:
        """Resolve an ArtifactRef to its filesystem dir.

        For local refs, ``native_id`` is the relative path
        (``issues/N`` or ``discussions/N``). For non-local refs (cross-
        adapter routing scenarios), we attempt a node_id meta.json scan.
        """
        if ref.platform_id == self.platform_id:
            return self._path / ref.native_id
        # Cross-adapter ref — scan meta.json files for a matching node_id.
        for kind_subdir in ("issues", "discussions"):
            kind_dir = self._path / kind_subdir
            if not kind_dir.exists():
                continue
            for entry in kind_dir.iterdir():
                meta_file = entry / "meta.json"
                if not meta_file.exists():
                    continue
                try:
                    meta = json.loads(meta_file.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    continue
                if meta.get("node_id") == ref.native_id:
                    return entry
        # No match — return a path that won't exist, so callers raise
        # InvalidArtifactRefError on access.
        return self._path / "_orphan" / ref.native_id

    def _read_issue(
        self,
        *,
        owner: str,
        repo: str,
        number: int,
        issue_dir: Path,
    ) -> Issue:
        title = (issue_dir / "title.md").read_text(encoding="utf-8").rstrip() if (issue_dir / "title.md").exists() else ""
        body = (issue_dir / "body.md").read_text(encoding="utf-8") if (issue_dir / "body.md").exists() else ""
        state_text = (
            (issue_dir / "state.txt").read_text(encoding="utf-8")
            if (issue_dir / "state.txt").exists() else "open\n"
        )
        states = vocab.parse_state_file(state_text)
        state: Any = "closed" if vocab.is_closed(states) else "open"
        labels = []
        if (issue_dir / "labels.txt").exists():
            labels = [
                line.strip()
                for line in (issue_dir / "labels.txt").read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
        meta: dict = {}
        if (issue_dir / "meta.json").exists():
            try:
                meta = json.loads((issue_dir / "meta.json").read_text(encoding="utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                meta = {}
        return Issue(
            ref=self._make_ref(
                native_id=f"issues/{number}",
                kind="issue",
                owner=owner,
                repo=repo,
                number=number,
            ),
            title=title,
            body=body,
            state=state,
            labels=labels,
            milestone=meta.get("milestone"),
            url=f"local://issues/{number}",
        )

    def _read_discussion(
        self,
        *,
        owner: str,
        repo: str,
        number: int,
        disc_dir: Path,
    ) -> Discussion:
        title = (disc_dir / "title.md").read_text(encoding="utf-8").rstrip() if (disc_dir / "title.md").exists() else ""
        body = (disc_dir / "body.md").read_text(encoding="utf-8") if (disc_dir / "body.md").exists() else ""
        state_text = (
            (disc_dir / "state.txt").read_text(encoding="utf-8")
            if (disc_dir / "state.txt").exists() else "open\n"
        )
        states = vocab.parse_state_file(state_text)
        labels = []
        if (disc_dir / "labels.txt").exists():
            labels = [
                line.strip()
                for line in (disc_dir / "labels.txt").read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
        meta: dict = {}
        if (disc_dir / "meta.json").exists():
            try:
                meta = json.loads((disc_dir / "meta.json").read_text(encoding="utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                meta = {}
        return Discussion(
            ref=self._make_ref(
                native_id=f"discussions/{number}",
                kind="discussion",
                owner=owner,
                repo=repo,
                number=number,
            ),
            title=title,
            body=body,
            state=("closed" if vocab.is_closed(states) else "open"),
            category=meta.get("category"),
            labels=labels,
            decided=vocab.is_decided(states),
            url=f"local://discussions/{number}",
        )

    def _auto_commit(self, message: str) -> str | None:
        """``git add . && git commit -m <message>`` in the docs repo.

        Idempotent — returns the commit SHA on success, None if nothing
        was staged. Best-effort — git failures don't propagate (the
        write itself is what matters; replication catches up via cron).
        """
        try:
            subprocess.run(
                ["git", "add", "."], cwd=self._path,
                check=True, capture_output=True,
            )
            diff_result = subprocess.run(
                ["git", "diff", "--cached", "--quiet"],
                cwd=self._path, capture_output=True,
            )
            if diff_result.returncode == 0:
                return None  # nothing staged
            subprocess.run(
                ["git", "commit", "-m", message, "--no-verify"],
                cwd=self._path, check=True, capture_output=True,
            )
            sha = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self._path, check=True, capture_output=True, text=True,
            )
            return sha.stdout.strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            return None

