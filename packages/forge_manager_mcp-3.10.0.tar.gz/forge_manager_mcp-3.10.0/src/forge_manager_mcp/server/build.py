"""Server construction and dispatch.

`build_server` wires MCP's `list_tools` / `call_tool` decorators to
handler functions living in `.handlers.*`. Each handler accepts
`ctx: ServerContext` as its first parameter; dispatch passes `ctx`
explicitly.
"""
from __future__ import annotations

from pathlib import Path

from mcp.server import Server
from mcp.types import TextContent, Tool

# Late binding — see helpers.py docstring. `build_server` reads
# exception classes (GitHubError, ClassificationError,
# InvalidNodeIdError) via _s so tests can monkey-patch them if needed,
# matching pre-split behaviour.
from forge_manager_mcp import server as _s
from ..buffer import write_pending
from ..daemon_client import DaemonUnavailableError
from ..config import (
    ConfigError,
    ConfigMissingError,
    get_github_token,
    load_config,
    require_env,
)
from ..adapters.github import GitHubAdapter
from ..adapters.local_store import LocalStoreAdapter
from ..adapters.protocol import PlatformAdapter
from ..adapters.registry import PLATFORM_ADAPTERS as _PLATFORM_ADAPTERS
from ..context import ServerContext
from ..gate_registry import (
    GateRegistry,
    GateRegistryError,
    ProcessRegistry,
    load_gates,
    load_processes,
)
from ..models import GithubConfig, OperationError
from ..parsers import parse_owner_repo
from ..project_rules import (
    ProjectRules,
    ProjectRulesError,
    load_project_rules,
    validate_against_registry,
)
from ..replication.errors import ReplicationWriteError
from ..replication.manager import ReplicationManager
from .helpers import (
    err,
    ok,
    preflight_cross_repo_mutation,
    resolve_thread_identifier,
    validate_tool_node_ids,
)
from .preflight import CrossRepoMutationBlocked
from .handlers import audit as audit_handlers
from .handlers import code_design as code_design_handlers
from .handlers import infra as infra_handlers
from .handlers import issues as issues_handlers
from .handlers import meta as meta_handlers
from .handlers import migration as migration_handlers
from .handlers import release as release_handlers
from .handlers import session as session_handlers
from .handlers import threads as threads_handlers
from .handlers import verify as verify_handlers
from .tool_schemas import all_tool_schemas


def _build_replication(
    config: GithubConfig | None,
    github_token: str,
    *,
    state_dir: Path | None = None,
) -> ReplicationManager | None:
    """Construct the per-server ReplicationManager from project config (#274).

    Two paths:

    * **3.0 multi-platform** — ``config.platforms`` is non-empty and
      ``config.replication_order`` lists at least one platform_id.
      Build the manager by walking ``replication_order`` in order;
      for each ID, find the matching ``platforms[*]`` entry (or
      synthesize a default for ``local``, which is implicit) and
      construct via the adapter's ``from_config`` classmethod. First
      entry is canonical per OQ3.
    * **2.x single-GitHub fallback** — used when ``platforms`` is
      empty (legacy ``github-config.json`` configs that haven't run
      the 2.x → 3.0 migration tool). Wraps a single ``GitHubAdapter``
      in a one-element ``ReplicationManager``.

    Pre-bootstrap mode (config is None) returns None.

    ``state_dir`` (#377 / 3.8.1 D1) — when set, the constructed
    manager persists adapter state across restart. Only the daemon
    supplies a value; MCP-side ReplicationManagers (none today
    post-3.7.0 D8.12, but retained for back-compat) leave it None.
    """
    if config is None:
        return None

    # Multi-platform path is gated on `schema_version == "3.0"` rather
    # than the presence of either field individually — that way an
    # inconsistent config (one of platforms / replication_order
    # populated but not the other) fails loudly inside
    # `_build_replication_from_platforms` rather than silently falling
    # back to the 2.x single-GitHub wrapper.
    if config.schema_version == "3.0":
        return _build_replication_from_platforms(
            config, github_token, state_dir=state_dir,
        )

    # 2.x single-GitHub fallback.
    adapter = GitHubAdapter(token=github_token)
    return ReplicationManager(
        [("github", adapter)], config=config, state_dir=state_dir,
    )


def _normalize_per_platform_categories(
    raw: dict,
) -> dict[str, str]:
    """Normalize a per-platform `discussion_categories` map (#299
    schema 4.0) to the flat name → ID dict that adapters consume.

    Two possible shapes per #299 closure (operator may write either):

    * **Flat:** ``{"Architecture": "DIC_kw_arch", ...}`` — direct
      name → ID strings. The shape that `migrate_to_4_0` emits.
    * **Object:** ``{"Architecture": {"id": "DIC_kw_arch"}, ...}`` —
      mirrors the legacy 3.x DiscussionCategories Pydantic shape;
      operator-readable JSON shape carries the explicit `id` key.

    Both flatten to the same name → ID dict the adapter expects.

    The Announcements/Project alias logic (#191) is preserved here
    same as in `_discussion_categories_map`.
    """
    out: dict[str, str] = {}
    for name, value in raw.items():
        if isinstance(value, str) and value:
            out[name] = value
        elif isinstance(value, dict) and value.get("id"):
            out[name] = value["id"]
    # #191 — running-log alias preserved for the per-platform shape.
    announcements_id = out.get("Announcements")
    project_id = out.get("Project")
    if announcements_id and not project_id:
        out["Project"] = announcements_id
    elif project_id and not announcements_id:
        out["Announcements"] = project_id
    return out


def _discussion_categories_map(config: GithubConfig) -> dict[str, str]:
    """Flatten ``config.discussion_categories`` into a name → ID map (#295).

    Used by ``_build_replication_from_platforms`` to inject the map
    into GitHubAdapter's ``from_config`` so ``create_discussion`` can
    resolve category names to GraphQL node IDs without handler-layer
    ctx access. The model is a Pydantic BaseModel with named fields
    plus extras (e.g. project-specific ``General``); both are
    flattened here.

    The Announcements / Project alias logic (#191) is preserved at
    map-build time: the running-log category may be configured under
    either field name. Pre-#295 the handler resolved the alias at
    dispatch time; post-#295 it lives here so the adapter sees a
    uniform map regardless of which field name the project uses.
    """
    if config.discussion_categories is None:
        return {}
    cats = config.discussion_categories
    result: dict[str, str] = {}
    # Walk model_dump to capture both named fields and ``extra`` keys.
    for name, value in cats.model_dump(by_alias=True).items():
        if isinstance(value, dict) and value.get("id"):
            result[name] = value["id"]
    # #191 — running-log alias. Whichever field is populated answers
    # for both names; both names hit the same ID.
    announcements_id = result.get("Announcements")
    project_id = result.get("Project")
    if announcements_id and not project_id:
        result["Project"] = announcements_id
    elif project_id and not announcements_id:
        result["Announcements"] = project_id
    return result


def _build_replication_from_platforms(
    config: GithubConfig,
    github_token: str,
    *,
    state_dir: Path | None = None,
) -> ReplicationManager:
    """Assemble the ReplicationManager from a 3.0 forge-config (#274 Phase D).

    Walks ``config.replication_order`` in order. Each entry is a
    platform_id matched against ``config.platforms[*]['id']``; the
    matching entry is passed to that platform's adapter
    ``from_config`` classmethod.

    ``local`` is implicit — if it appears in ``replication_order``
    but no ``platforms[id=local]`` entry exists, synthesize a default
    config (LocalStoreAdapter falls back to env var + home dir).
    """
    platforms_by_id = {entry.get("id", ""): entry for entry in config.platforms}
    adapters: list[tuple[str, PlatformAdapter]] = []
    for platform_id in config.replication_order:
        adapter_cls = _PLATFORM_ADAPTERS.get(platform_id)
        if adapter_cls is None:
            raise ConfigError(
                f"Unknown platform_id {platform_id!r} in "
                f"replication_order. Known: {sorted(_PLATFORM_ADAPTERS)}."
            )
        platform_config = platforms_by_id.get(platform_id)
        if platform_config is None:
            if platform_id == "local":
                # Local is implicit — synthesize a default config.
                platform_config = {"id": "local"}
            else:
                raise ConfigError(
                    f"replication_order references {platform_id!r} but no "
                    "matching entry in platforms[]."
                )
        # #295 — GitHubAdapter.create_discussion needs the project's
        # category name → node-ID map. Inject it into platform_config
        # so from_config captures it as instance state.
        #
        # Schema 4.0 (#299 / 3.6.0 D3): each platform entry may
        # carry its own `discussion_categories` field. When present,
        # use it directly — that's the canonical 4.0 shape. When
        # absent, fall back to the legacy top-level
        # `config.discussion_categories` (3.0+ shape; GitHub-only).
        # The top-level fallback is removed when the schema 4.0
        # hard cutover lands later in D3.
        per_platform_cats = (
            platform_config.get("discussion_categories")
            if isinstance(platform_config, dict) else None
        )
        if isinstance(per_platform_cats, dict) and per_platform_cats:
            # 4.0 shape: per-platform map already present. Just
            # ensure flat name→ID structure (handle both
            # `{"Architecture": "DIC_..."}` and
            # `{"Architecture": {"id": "DIC_..."}}` shapes).
            normalized = _normalize_per_platform_categories(per_platform_cats)
            platform_config = {
                **platform_config,
                "discussion_categories": normalized,
            }
        elif platform_id == "github" and config.discussion_categories is not None:
            # 3.x shape: top-level → inject into GitHub adapter only.
            platform_config = {
                **platform_config,
                "discussion_categories": _discussion_categories_map(config),
            }
        adapter = adapter_cls.from_config(platform_config)
        adapters.append((platform_id, adapter))

    if not adapters:
        raise ConfigError(
            "replication_order is non-empty but no adapters were "
            "constructed. Check forge-config.json shape."
        )
    return ReplicationManager(adapters, config=config, state_dir=state_dir)


_DEFAULT_SKILL_DIR = Path(".claude") / "skills" / "forge-manager"


def _load_registries(
    project_dir: Path,
) -> tuple[GateRegistry | None, ProcessRegistry | None]:
    """Load gate + process registries from the project's skill directory (#287).

    Returns ``(None, None)`` for either when the matching YAML file is
    absent or fails to parse. Failures log a warning rather than aborting
    server startup so a malformed registry doesn't take the whole server
    down — handlers that call ``evaluate_gate`` see ``UnknownGate`` and
    handle it like any other gate-not-registered case.
    """
    import logging

    logger = logging.getLogger(__name__)
    skill_dir = project_dir / _DEFAULT_SKILL_DIR

    gates_path = skill_dir / "gates.yaml"
    processes_path = skill_dir / "processes.yaml"

    gate_registry: GateRegistry | None = None
    if gates_path.exists():
        try:
            gate_registry = load_gates(gates_path)
        except GateRegistryError as exc:
            logger.warning("gate_registry: failed to load %s: %s", gates_path, exc)

    process_registry: ProcessRegistry | None = None
    if processes_path.exists():
        try:
            process_registry = load_processes(processes_path)
        except GateRegistryError as exc:
            logger.warning(
                "process_registry: failed to load %s: %s", processes_path, exc
            )

    return gate_registry, process_registry


def _load_project_rules(
    project_dir: Path, gate_registry: GateRegistry | None
) -> ProjectRules | None:
    """Load .claude/project-rules.md when present and validate against the
    gate registry (#288).

    Returns None when the file is absent (no rules, default-only chains)
    or when the file fails to parse / validate. Like
    ``_load_registries``, parse / validation failure logs a warning and
    starts the server in degraded mode rather than aborting.

    The validation step runs only when ``gate_registry`` is non-None.
    Without a registry there's no truth source to validate references
    against — the rules still parse and attach so independent rules
    (which don't reference gates) remain accessible.
    """
    import logging

    logger = logging.getLogger(__name__)
    rules_path = project_dir / ".claude" / "project-rules.md"
    if not rules_path.exists():
        return None
    try:
        rules = load_project_rules(rules_path)
    except ProjectRulesError as exc:
        logger.warning("project_rules: failed to parse %s: %s", rules_path, exc)
        return None
    if gate_registry is not None:
        try:
            validate_against_registry(rules, gate_registry)
        except ProjectRulesError as exc:
            logger.warning(
                "project_rules: %s references unknown gates: %s. "
                "Loading anyway; evaluate_gate will skip the unknown layers.",
                rules_path,
                exc,
            )
    return rules


def _resolve_public_face(
    config: GithubConfig | None, github_token: str,
) -> "PlatformAdapter | None":
    """Resolve the configured public-face adapter (#280).

    Post-3.7.0 D8.12 (#356) the MCP no longer holds a per-session
    ReplicationManager, so this resolver instantiates the adapter
    directly from ``config.platforms[]`` rather than walking a chain.

    Returns None when:
      * config is None (pre-bootstrap), or
      * config.public_face is None (no public face configured), or
      * the named platform_id has no matching ``platforms[]`` entry, or
      * no adapter class is registered for that platform_id.

    Otherwise returns the adapter built via the registered class's
    ``from_config`` classmethod, mirroring the construction
    ``_build_replication_from_platforms`` performs for the daemon's
    chain. Handlers that touch the public face (#280 / #282) dispatch
    through ``ctx.public_face`` rather than hardcoding GitHub-specific
    paths.
    """
    if config is None or config.public_face is None:
        return None
    target_id = config.public_face
    if config.schema_version != "3.0":
        # 2.x compat: only GitHub. ``public_face`` is unset on 2.x
        # configs by validation, but defend anyway.
        if target_id == "github":
            return GitHubAdapter(token=github_token)
        return None
    platforms_by_id = {entry.get("id", ""): entry for entry in config.platforms}
    platform_config = platforms_by_id.get(target_id)
    if platform_config is None:
        return None
    adapter_cls = _PLATFORM_ADAPTERS.get(target_id)
    if adapter_cls is None:
        return None
    if target_id == "github" and config.discussion_categories is not None:
        platform_config = {
            **platform_config,
            "discussion_categories": _discussion_categories_map(config),
        }
    return adapter_cls.from_config(platform_config)


def build_server(
    project_dir: Path,
) -> tuple[Server, GithubConfig | None, str, str]:
    """Build and configure the MCP server.

    Fails immediately (ConfigError) if config is malformed, fails
    validation, ANTHROPIC_API_KEY is unset, or a GitHub token is
    unavailable.

    If `.claude/github-config.json` is *absent* (pre-bootstrap), the
    server starts in **degraded mode** (#156): only `scaffold_project`
    and `check_skill_version` are callable; every other tool returns a
    bootstrap-required error. After bootstrap completes the operator
    must restart Claude Code so the next session loads the new config.

    Returns (server, config_or_None, github_token, anthropic_api_key).
    """
    pre_bootstrap = False
    try:
        config: GithubConfig | None = load_config(project_dir)
    except ConfigMissingError:
        config = None
        pre_bootstrap = True

    github_token = get_github_token()
    anthropic_api_key = require_env("ANTHROPIC_API_KEY")

    server = Server("forge-manager")

    # (#356, 3.7.0 D8.12) The MCP no longer holds a per-session
    # ReplicationManager — canonical reads / writes go through the
    # daemon. ``_build_replication`` and the related helpers stay in
    # this module because the daemon imports them at startup
    # (forge_manager_mcp.daemon.main._build_daemon_replication).
    public_face = _resolve_public_face(config, github_token)
    gate_registry, process_registry = _load_registries(project_dir)
    project_rules = _load_project_rules(project_dir, gate_registry)

    # (3.4.0 / Codeberg-dev #3 Phase 1b) Register default evaluators for
    # every pre-publish runbook gate. Idempotent — re-registers each
    # time build_server runs (last-wins). Safe when gate_registry is
    # None (no gates loaded → no evaluators to register).
    if gate_registry is not None:
        from ..runbook_evaluator import register_runbook_evaluators
        register_runbook_evaluators(gate_registry)

    # (#356, 3.7.0 D8 carryover) Resolve canonical platform_id at build
    # time so ``make_canonical_ref`` doesn't need a daemon round-trip.
    # Default "local" matches the conventional canonical for projects
    # with replication_order: [local, ...] (the 3.0+ shape).
    canonical_platform_id = "local"
    if config is not None and config.schema_version == "3.0" and config.replication_order:
        canonical_platform_id = config.replication_order[0]
    elif config is not None and config.schema_version != "3.0":
        # 2.x single-GitHub fallback path.
        canonical_platform_id = "github"

    ctx = ServerContext(
        config=config,
        github_token=github_token,
        anthropic_api_key=anthropic_api_key,
        project_dir=project_dir,
        pre_bootstrap=pre_bootstrap,
        canonical_platform_id=canonical_platform_id,
        public_face=public_face,
        gate_registry=gate_registry,
        process_registry=process_registry,
        project_rules=project_rules,
    )

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return all_tool_schemas()

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        # Pre-bootstrap mode (#156): only `scaffold_project` and
        # `check_skill_version` are config-independent. Other tools
        # would crash on `ctx.config.*` access; instead, return a clear
        # bootstrap-required error so the operator sees what to do.
        _PRE_BOOTSTRAP_SAFE = {
            "scaffold_project",
            "scaffold_project_multi",
            "check_skill_version",
        }
        if ctx.pre_bootstrap and name not in _PRE_BOOTSTRAP_SAFE:
            ctx.activity.tool_errors += 1
            return err(
                OperationError(
                    success=False,
                    error=(
                        f"Tool {name!r} requires .claude/github-config.json. "
                        "This project has not been bootstrapped yet. Run "
                        "`scaffold_project` first (or follow §Self-Bootstrap). "
                        "After bootstrap completes, restart Claude Code so "
                        "the next session picks up the generated config."
                    ),
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                )
            )

        # Pre-bootstrap-safe handlers don't read ctx.config; full-mode
        # handlers do. Resolve owner/repo only in full mode to avoid a
        # None.repos crash on the pre-bootstrap path.
        if ctx.config is not None:
            owner, private_repo = parse_owner_repo(ctx.config.repos.private)
        else:
            owner, private_repo = "", ""

        try:
            await validate_tool_node_ids(name, arguments, ctx.github_token)

            # Cross-repo mutation preflight (#98). No-op unless the
            # caller passed explicit owner/repo targeting a cousin /
            # foreign repo per related_repos. Skipped pre-bootstrap.
            if ctx.config is not None:
                preflight_cross_repo_mutation(ctx.config, arguments)

            if name == "open_session":
                return await session_handlers.open_session(ctx)

            if name == "recover_context":
                return await session_handlers.recover_context(
                    ctx,
                    int(arguments.get("days", 7)),
                    include_toc_body=bool(arguments.get("include_toc_body", True)),
                    include_open_issues=bool(arguments.get("include_open_issues", True)),
                    include_recent_discussions=bool(
                        arguments.get("include_recent_discussions", True)
                    ),
                    include_milestones=bool(arguments.get("include_milestones", True)),
                    max_open_issues=int(arguments.get("max_open_issues", 100)),
                )

            if name == "scaffold_project":
                return await infra_handlers.scaffold_project(
                    ctx,
                    arguments["org"],
                    arguments["project_name"],
                    arguments.get("description", ""),
                )

            if name == "scaffold_project_multi":
                return await infra_handlers.scaffold_project_multi(
                    ctx,
                    project_name=arguments["project_name"],
                    description=arguments.get("description", ""),
                    platforms=list(arguments.get("platforms") or []),
                    replication_order=list(
                        arguments.get("replication_order") or []
                    ),
                    require_bazel_builds=bool(
                        arguments.get("require_bazel_builds", False)
                    ),
                    require_maximal_coverage=bool(
                        arguments.get("require_maximal_coverage", False)
                    ),
                    enable_llm_verifier=arguments.get("enable_llm_verifier"),
                    custom_running_log=arguments.get("custom_running_log"),
                )

            if name == "classify_and_create":
                return await meta_handlers.classify_and_create(
                    ctx,
                    arguments["text"],
                    arguments.get("auto_create_threshold", "high"),
                    bool(arguments.get("also_post_turn", True)),
                    arguments.get("opening_body", ""),
                    owner,
                    private_repo,
                )

            if name == "check_skill_version":
                return await infra_handlers.check_skill_version(ctx)

            if name == "replay_pending":
                targets = arguments.get("targets")
                inspect_only = bool(arguments.get("inspect_only", False))
                return await infra_handlers.replay_pending(
                    ctx, call_tool,
                    targets=targets,
                    inspect_only=inspect_only,
                )

            if name == "close_issue_with_comment":
                issue_id = await resolve_thread_identifier(
                    arguments,
                    primary_id_param="issue_id",
                    kind="issue",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await issues_handlers.close_issue_with_comment(
                    ctx,
                    issue_id,
                    arguments["comment"],
                    arguments.get("state_reason", "completed"),
                )

            if name == "close_triaged_public_issues":
                return await issues_handlers.close_triaged_public_issues(
                    ctx,
                    arguments["version"],
                    bool(arguments.get("dry_run", True)),
                    bool(arguments.get("skip_pre_release", True)),
                )

            if name == "get_thread_comments":
                return await threads_handlers.get_thread_comments(
                    ctx,
                    arguments["thread_id"],
                    arguments["thread_type"],
                    int(arguments.get("limit", 20)),
                )

            if name == "close_session":
                return await session_handlers.close_session(
                    ctx,
                    arguments.get("summary"),
                    int(arguments.get("skill_update_candidates", 0)),
                    bool(arguments.get("update_memory", True)),
                )

            if name == "post_turn":
                thread_type = arguments["thread_type"]
                thread_id = await resolve_thread_identifier(
                    arguments,
                    primary_id_param="thread_id",
                    kind=thread_type,
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await threads_handlers.post_turn(
                    ctx,
                    thread_id,
                    thread_type,
                    arguments["speaker"],
                    arguments["body"],
                    ctx.project_dir,
                )

            if name == "create_thread":
                return await threads_handlers.create_thread(
                    ctx,
                    arguments["type"],
                    arguments["category_or_label"],
                    arguments["title"],
                    arguments["opening_body"],
                    arguments.get("discussion_origin_id", ""),
                    owner,
                    private_repo,
                    milestone=arguments.get("milestone"),
                )

            if name == "classify_turn":
                return await meta_handlers.classify_turn(ctx, arguments["text"])

            if name == "detect_theme_change":
                return await meta_handlers.detect_theme_change(
                    ctx,
                    arguments["thread_id"],
                    arguments["new_turn_text"],
                )

            if name == "fork_discussion":
                original_id = await resolve_thread_identifier(
                    arguments,
                    primary_id_param="original_id",
                    kind="discussion",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                fork_args = dict(arguments)
                fork_args["original_id"] = original_id
                return await threads_handlers.fork_discussion(
                    ctx, fork_args, owner, private_repo
                )

            if name == "create_issue":
                # Accept either `labels: List[str]` (#55) or the deprecated
                # single `label: str` form. Exactly one must be provided.
                raw_labels = arguments.get("labels")
                legacy_label = arguments.get("label")
                if raw_labels is not None and legacy_label:
                    raise ValueError(
                        "Provide either `labels` or `label`, not both. "
                        "`label` is deprecated."
                    )
                if raw_labels is None and not legacy_label:
                    raise ValueError(
                        "Either `labels` (list) or `label` (deprecated "
                        "single value) must be provided."
                    )
                labels_list = (
                    [legacy_label] if legacy_label else list(raw_labels or [])
                )
                return await issues_handlers.create_issue_tool(
                    ctx,
                    arguments["title"],
                    arguments["body"],
                    labels_list,
                    arguments.get("discussion_origin_id", ""),
                    owner,
                    private_repo,
                    milestone=arguments.get("milestone"),
                )

            if name == "update_issue_toc":
                issue_id = await resolve_thread_identifier(
                    arguments,
                    primary_id_param="issue_id",
                    kind="issue",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await issues_handlers.update_issue_toc(
                    ctx,
                    issue_id,
                    arguments.get("new_body"),
                    arguments.get("new_body_path"),
                    bool(arguments.get("force", False)),
                )

            if name == "update_issue_milestone":
                # (#388, 3.9.0 D5) Daemon-routed milestone mutation.
                # Closes the meta-bypass that surfaced during 3.9.0
                # planning. Routes through the daemon's /writes
                # endpoint so the canonical store is the source of
                # truth and remote mirrors fan out per replication
                # order.
                from forge_manager_mcp.daemon_client import dispatch_write
                from forge_manager_mcp.daemon.paths import (
                    DEFAULT_PROJECT_NAME, state_dir,
                )
                issue_number = int(arguments["issue_number"])
                response = await dispatch_write(
                    state_dir(DEFAULT_PROJECT_NAME),
                    "update_issue_milestone",
                    {
                        "native_id": f"issues/{issue_number}",
                        "owner": arguments.get("owner") or owner,
                        "repo": arguments.get("repo") or private_repo,
                        "milestone_title": arguments.get("milestone_title"),
                        "repo_role": "private",
                    },
                )
                return ok({
                    "issue_number": issue_number,
                    "milestone_title": arguments.get("milestone_title"),
                    "mirror_warnings": response.get("mirror_warnings", []),
                })

            if name == "move_project_item":
                issue_id = await resolve_thread_identifier(
                    arguments,
                    primary_id_param="issue_id",
                    kind="issue",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await issues_handlers.move_project_item(
                    ctx,
                    arguments["column_name"],
                    issue_id,
                )

            if name == "update_project_toc":
                return await threads_handlers.update_project_toc(
                    ctx,
                    arguments.get("new_body"),
                    arguments.get("new_body_path"),
                    bool(arguments.get("force", False)),
                )

            if name == "update_discussion_body":
                discussion_id = await resolve_thread_identifier(
                    arguments,
                    primary_id_param="discussion_id",
                    kind="discussion",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await threads_handlers.update_discussion_body_tool(
                    ctx,
                    discussion_id,
                    arguments.get("new_body"),
                    arguments.get("new_body_path"),
                    bool(arguments.get("force", False)),
                )

            if name == "search_issues":
                # Allow caller to override repo scope (e.g., search the
                # public mirror instead of the dev repo). Defaults to dev.
                search_owner = arguments.get("owner") or owner
                search_repo = arguments.get("repo") or private_repo
                return await issues_handlers.search_issues_tool(
                    ctx,
                    arguments.get("query", ""),
                    arguments.get("state", "all"),
                    arguments.get("labels"),
                    arguments.get("milestone"),
                    search_owner,
                    search_repo,
                    int(arguments.get("limit", 50)),
                )

            if name == "compose_post_reframe_toc":
                return await threads_handlers.compose_post_reframe_toc_tool(
                    ctx,
                    arguments["project_name"],
                    arguments.get("preamble", ""),
                    arguments.get("releases", ""),
                    arguments.get("milestones", ""),
                    arguments.get("discussions", ""),
                    arguments.get("cross_repo_activity", ""),
                    arguments.get("project_board_url", ""),
                    arguments.get("repos", ""),
                    arguments.get("pointer_line"),
                )

            if name == "generate_changelog":
                return await release_handlers.generate_changelog(
                    ctx,
                    bool(arguments.get("write", False)),
                )

            if name == "validate_release":
                return await release_handlers.validate_release(
                    ctx,
                    arguments["version"],
                    bool(arguments.get("skip_bazel", False)),
                    bool(arguments.get("skip_smoke_test", False)),
                    arguments.get("runbook_confirmations"),
                )

            if name == "verify_plan_completeness":
                return await verify_handlers.verify_plan_completeness(
                    ctx,
                    arguments["plan_body"],
                )

            if name == "verify_existing_code_assumptions":
                return await verify_handlers.verify_existing_code_assumptions(
                    ctx,
                    arguments["plan_body"],
                    arguments["pr_diff"],
                    arguments.get("repo_root"),
                    arguments.get("model", "claude-sonnet-4-6"),
                    int(arguments.get("token_budget", 100_000)),
                )

            if name == "verify_diff_covers_plan":
                # `project_rules` is intentionally optional at the
                # tool surface — callers that omit it inherit the
                # default rule set (#192) composed from the project's
                # configured fields. Explicit lists from operators
                # override the default so projects can experiment
                # without touching config.
                project_rules = arguments.get("project_rules")
                return await verify_handlers.verify_diff_covers_plan(
                    ctx,
                    arguments["plan_body"],
                    arguments["diff_text"],
                    arguments.get("evidence_text", ""),
                    project_rules,
                )

            if name == "release_project":
                return await release_handlers.release_project(
                    ctx,
                    arguments["version"],
                    bool(arguments.get("dry_run", True)),
                    arguments.get("stop_after", "release_notes"),
                    bool(arguments.get("approve_version_bump", False)),
                    bool(arguments.get("skip_bazel", False)),
                    pypi_only=bool(arguments.get("pypi_only", False)),
                )

            if name == "mark_discussion_decided":
                discussion_id = await resolve_thread_identifier(
                    arguments,
                    primary_id_param="discussion_id",
                    kind="discussion",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await threads_handlers.mark_decided(
                    ctx,
                    discussion_id,
                    arguments["decision_comment_id"],
                    arguments["category_name"],
                )

            if name == "migrate_to_3_0":
                return await migration_handlers.migrate_to_3_0(
                    ctx,
                    bool(arguments.get("apply", False)),
                )

            if name == "migrate_to_3_0_rollback":
                return await migration_handlers.migrate_to_3_0_rollback(
                    ctx,
                    arguments["backup_path"],
                )

            if name == "migrate_to_3_5":
                return await migration_handlers.migrate_to_3_5(
                    ctx,
                    bool(arguments.get("apply", False)),
                )

            if name == "migrate_to_3_5_rollback":
                return await migration_handlers.migrate_to_3_5_rollback(
                    ctx,
                    arguments["backup_path"],
                )

            if name == "migrate_to_4_0":
                return await migration_handlers.migrate_to_4_0(
                    ctx,
                    bool(arguments.get("apply", False)),
                )

            if name == "migrate_to_4_0_rollback":
                return await migration_handlers.migrate_to_4_0_rollback(
                    ctx,
                    arguments["backup_path"],
                )

            if name == "add_backend":
                return await migration_handlers.add_backend(
                    ctx,
                    arguments["platform_id"],
                    arguments["config"],
                )

            if name == "audit_project_prose":
                return await audit_handlers.audit_project_prose(
                    ctx,
                    include=arguments.get("include"),
                    exclude=arguments.get("exclude"),
                    since=arguments.get("since"),
                    apply_finding_id=arguments.get("apply_finding_id"),
                )

            if name == "check_code_design":
                return await code_design_handlers.check_code_design(
                    ctx,
                    rules=arguments.get("rules"),
                    paths=arguments.get("paths"),
                    severity_filter=arguments.get("severity_filter"),
                )

            if name == "get_daemon_alerts":
                from forge_manager_mcp.daemon_client import fetch_alerts
                from forge_manager_mcp.daemon.paths import (
                    DEFAULT_PROJECT_NAME, state_dir,
                )
                sd = state_dir(DEFAULT_PROJECT_NAME)
                alerts = await fetch_alerts(
                    sd,
                    since=arguments.get("since"),
                    level=arguments.get("level"),
                    limit=arguments.get("limit"),
                )
                return ok({"alerts": alerts})

            if name == "get_daemon_status":
                from forge_manager_mcp import __version__ as _mcp_version
                from forge_manager_mcp.daemon.paths import (
                    DEFAULT_PROJECT_NAME, state_dir,
                )
                from forge_manager_mcp.daemon_client import full_status_probe
                sd = state_dir(DEFAULT_PROJECT_NAME)
                status = await full_status_probe(sd, _mcp_version)
                return ok(status)

            if name == "get_code_design_status":
                # Same evaluator-walk as check_code_design, but
                # always-all-rules + summary-only return.
                return await code_design_handlers.check_code_design(
                    ctx,
                    rules=None,
                    paths=None,
                    severity_filter=arguments.get(
                        "severity_filter", "info",
                    ),
                )

            if name == "analyze_gaps":
                from .handlers import gap_analysis as gap_handlers
                return await gap_handlers.analyze_gaps(
                    ctx,
                    detectors=arguments.get("detectors"),
                    paths=arguments.get("paths"),
                    severity_filter=arguments.get("severity_filter"),
                )

            if name == "run_command":
                # (#387 / 3.9.0 D4.3) Text-grammar dispatch.
                # Parses /<verb> <noun> [args] via command_registry,
                # then routes to the registered surface:
                #   * daemon_endpoint → HTTP GET against the daemon
                #     (same dispatch shape as search_local), or
                #   * ui_route → return the URL fragment for the
                #     caller to navigate, or
                #   * mcp_tool only → return a "use the typed tool
                #     directly" hint per #13's design (mutating MCP
                #     tools stay typed).
                #   * verb=help → in-line meta handler.
                from pathlib import Path as _P
                from forge_manager_mcp.command_registry import (
                    CommandRegistryError, load_commands, parse_command,
                )
                raw = arguments.get("command", "")
                # Locate commands.yaml — default project layout is
                # .claude/skills/forge-manager/ relative to project_dir.
                commands_path = (
                    ctx.project_dir / ".claude" / "skills"
                    / "forge-manager" / "commands.yaml"
                )
                if not commands_path.exists():
                    return ok({
                        "error": (
                            f"commands.yaml not found at {commands_path}. "
                            f"This project may not have the registry "
                            f"installed yet — see Discussion #13."
                        ),
                        "command": raw,
                    })
                try:
                    registry = load_commands(commands_path)
                    parsed = parse_command(raw, registry)
                except CommandRegistryError as exc:
                    return ok({
                        "error": str(exc),
                        "command": raw,
                    })

                cmd = parsed.command
                # Special-case the meta /help command.
                if cmd.verb == "help":
                    target_verb = (
                        parsed.positional[0] if parsed.positional else None
                    )
                    if target_verb is None:
                        return ok({
                            "kind": "help",
                            "verbs": registry.list_verbs(),
                            "command": raw,
                        })
                    matches = [
                        {"verb": c.verb, "noun": c.noun, "summary": c.summary}
                        for c in registry.list_for_verb(target_verb)
                    ]
                    return ok({
                        "kind": "help",
                        "verb": target_verb,
                        "commands": matches,
                        "command": raw,
                    })

                # UI-only (open / navigation) — return the resolved
                # route for the caller to consume.
                if cmd.ui_route is not None and cmd.daemon_endpoint is None:
                    rendered = parsed.substitute(cmd.ui_route)
                    return ok({
                        "kind": "ui_route",
                        "route": rendered,
                        "command": raw,
                    })

                # daemon_endpoint dispatch.
                if cmd.daemon_endpoint is not None:
                    import httpx
                    import json as _json
                    from forge_manager_mcp.daemon.paths import (
                        DEFAULT_PROJECT_NAME, state_dir,
                    )
                    from forge_manager_mcp.daemon.discovery import read_discovery
                    sd = state_dir(DEFAULT_PROJECT_NAME)
                    df = read_discovery(sd)
                    if df is None:
                        return ok({
                            "error": (
                                "command requires a running daemon "
                                "(no discovery file). Start it via "
                                "`forge-manager-mcp daemon-restart`."
                            ),
                            "command": raw,
                        })
                    method, _, path = cmd.daemon_endpoint.partition(" ")
                    params_raw = parsed.substitute(cmd.daemon_params_json or "{}")
                    try:
                        params = _json.loads(params_raw)
                    except _json.JSONDecodeError as exc:
                        return ok({
                            "error": (
                                f"daemon_params_json template did not "
                                f"render to valid JSON: {exc}"
                            ),
                            "rendered": params_raw,
                            "command": raw,
                        })
                    try:
                        async with httpx.AsyncClient(timeout=5.0) as client:
                            if method.upper() == "GET":
                                resp = await client.get(
                                    f"http://127.0.0.1:{df.port}{path}",
                                    headers={
                                        "Authorization": f"Bearer {df.auth_token}",
                                    },
                                    params={
                                        k: str(v) for k, v in params.items()
                                    },
                                )
                            else:
                                resp = await client.request(
                                    method,
                                    f"http://127.0.0.1:{df.port}{path}",
                                    headers={
                                        "Authorization": f"Bearer {df.auth_token}",
                                    },
                                    json=params,
                                )
                    except httpx.HTTPError as exc:
                        return ok({
                            "error": f"daemon dispatch failed: {exc}",
                            "command": raw,
                        })
                    if resp.status_code != 200:
                        return ok({
                            "error": (
                                f"daemon returned HTTP {resp.status_code}: "
                                f"{resp.text[:200]}"
                            ),
                            "command": raw,
                        })
                    try:
                        body = resp.json()
                    except _json.JSONDecodeError:
                        body = {"raw": resp.text}
                    payload = {
                        "kind": "daemon",
                        "endpoint": cmd.daemon_endpoint,
                        "result": body,
                        "command": raw,
                    }
                    # (#387, 3.9.0 D4.6) Publish command.executed to
                    # the daemon broadcaster — operator-facing audit
                    # trail. Best-effort; failure doesn't poison the
                    # already-dispatched command.
                    try:
                        from forge_manager_mcp.daemon_client import post_event
                        await post_event(sd, "command.executed", {
                            "command": raw,
                            "kind": payload["kind"],
                            "verb": cmd.verb,
                            "noun": cmd.noun,
                        })
                    except Exception:
                        pass
                    return ok(payload)

                # mcp_tool-only commands — surface the typed tool name.
                payload = {
                    "kind": "mcp_tool_hint",
                    "tool_name": cmd.mcp_tool,
                    "args_template": cmd.mcp_args_json,
                    "args_rendered": parsed.substitute(cmd.mcp_args_json or "{}"),
                    "message": (
                        f"This command dispatches via the typed MCP "
                        f"tool {cmd.mcp_tool!r}. Per Discussion #13's "
                        f"asymmetric-dispatch design, call the tool "
                        f"directly with the rendered args."
                    ),
                    "command": raw,
                }
                try:
                    from forge_manager_mcp.daemon.paths import (
                        DEFAULT_PROJECT_NAME, state_dir,
                    )
                    from forge_manager_mcp.daemon_client import post_event
                    await post_event(
                        state_dir(DEFAULT_PROJECT_NAME),
                        "command.executed",
                        {
                            "command": raw,
                            "kind": payload["kind"],
                            "verb": cmd.verb,
                            "noun": cmd.noun,
                        },
                    )
                except Exception:
                    pass
                return ok(payload)

            if name == "search_local":
                # (#354 / D4.5) Proxies to the daemon's /search
                # endpoint. Daemon owns the FTS5 cache; MCP is a
                # thin caller per Discussion #6 OQ2 (Option C).
                import httpx
                from forge_manager_mcp.daemon.paths import (
                    DEFAULT_PROJECT_NAME, state_dir,
                )
                from forge_manager_mcp.daemon.discovery import read_discovery
                sd = state_dir(DEFAULT_PROJECT_NAME)
                df = read_discovery(sd)
                if df is None:
                    return ok({
                        "error": (
                            "search_local requires a running daemon "
                            "(no discovery file). Start it via "
                            "`forge-manager-mcp daemon-restart` or "
                            "open the UI."
                        ),
                        "results": [],
                        "total_count": 0,
                        "query": arguments.get("query", ""),
                    })
                params: dict[str, str] = {"q": arguments.get("query", "")}
                if arguments.get("kind"):
                    params["kind"] = arguments["kind"]
                if arguments.get("limit") is not None:
                    params["limit"] = str(arguments["limit"])
                try:
                    async with httpx.AsyncClient(timeout=5.0) as client:
                        resp = await client.get(
                            f"http://127.0.0.1:{df.port}/search",
                            headers={
                                "Authorization": f"Bearer {df.auth_token}",
                            },
                            params=params,
                        )
                    if resp.status_code != 200:
                        return ok({
                            "error": (
                                f"daemon /search returned "
                                f"HTTP {resp.status_code}: {resp.text[:200]}"
                            ),
                            "results": [],
                            "total_count": 0,
                            "query": arguments.get("query", ""),
                        })
                    return ok(resp.json())
                except (httpx.HTTPError, OSError) as exc:
                    return ok({
                        "error": (
                            f"daemon /search unreachable: "
                            f"{type(exc).__name__}: {exc}"
                        ),
                        "results": [],
                        "total_count": 0,
                        "query": arguments.get("query", ""),
                    })

            return ok(f"Unknown tool: {name}")

        except _s.InvalidNodeIdError as exc:
            # Client-side error — do NOT buffer. Retrying the same bad
            # ID would fail identically and clog the buffer (#51).
            ctx.activity.tool_errors += 1
            return err(
                OperationError(
                    success=False,
                    error=str(exc),
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                )
            )

        except CrossRepoMutationBlocked as exc:
            # Protocol gate, not a transient error (#98). Not buffered —
            # retrying without user permission would fail identically.
            ctx.activity.tool_errors += 1
            return err(
                OperationError(
                    success=False,
                    error=(
                        f"{exc.relationship}-repo mutation blocked: "
                        f"{exc.target_repo}"
                    ),
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                    manual_step=exc.manual_step,
                )
            )

        except (
            ValueError,
            _s.GitHubError,
            _s.ClassificationError,
            ReplicationWriteError,
            DaemonUnavailableError,
        ) as exc:
            # ReplicationWriteError wraps backend errors raised by the
            # canonical adapter (#274). The wrapped cause is typically
            # a GitHubError for the GitHub-canonical 2.x config path;
            # handling them here means the buffered-error envelope
            # surfaces the same retry semantics regardless of which
            # layer threw.
            # (#355 / D5.3) DaemonUnavailableError is the post-D5
            # equivalent — daemon's /writes endpoint can't be reached
            # OR returned a 5xx (typically because the daemon-side
            # ReplicationManager raised). Same buffered-retry envelope
            # so operator UX matches.
            ctx.activity.tool_errors += 1
            buffer_path = write_pending(
                ctx.project_dir, name, arguments, str(exc)
            )
            return err(
                OperationError(
                    success=False,
                    error=str(exc),
                    buffered=True,
                    buffer_file=str(buffer_path),
                    retry_tool=name,
                    retry_args=arguments,
                )
            )

    # Expose the registered handlers for test harnesses (#65).
    server.list_tools_handler = list_tools  # type: ignore[attr-defined]
    server.call_tool_handler = call_tool  # type: ignore[attr-defined]

    return server, config, github_token, anthropic_api_key
