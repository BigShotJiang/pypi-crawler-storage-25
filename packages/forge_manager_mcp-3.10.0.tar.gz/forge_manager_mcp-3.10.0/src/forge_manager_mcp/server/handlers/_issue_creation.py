"""Shared Issue-creation orchestration (#274 follow-up; DRY refactor).

`create_issue_tool` (issues.py) and `create_thread` Issue branch
(threads.py) both need the same four-step sequence:

  1. Dispatch through the daemon's ``POST /writes`` endpoint
     (#355 / D5.2 / capability 8 — pre-D5.2 this went through
     ``ctx.replication.write``; the migration moves the canonical
     write boundary to the daemon per Discussion #6 OQ2 closure).
  2. Attach the new Issue to the project board (forgejo #10 / 3.4.0
     sub-Protocol — first replication adapter with
     ``has_project_boards=True`` wins; skips silently when none).
  3. Increment ``ctx.activity.issues_created``.

Factored here so the test surface is one helper, not two near-
duplicate handler call sites. The result-model shaping
(``CreateIssueResult`` vs ``CreateThreadResult``) and the
project-TOC-body fetch stay at the call sites — those genuinely
diverge between the two handlers.
"""
from __future__ import annotations

from ...adapters.errors import ForgeError, ForgeUnavailableError
from ...adapters.types import Issue
from ...context import ServerContext
from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
from ...daemon_client import dispatch_write


async def _attach_to_project_board_if_supported(
    ctx: ServerContext, issue: Issue,
) -> str:
    """Attach an Issue to the configured project board on whichever
    replication adapter supports it (forgejo #10 / 3.4.0).

    Walks ``ctx.replication.entries()`` in order; the first adapter
    with ``has_project_boards=True`` performs the attach. If no
    adapter supports project boards, or no ``project_board`` is
    configured on this project, returns "" cleanly — the caller
    treats the empty string as "no board attachment performed".

    Any ``ForgeError`` (including ``ForgeUnavailableError``,
    backend-specific HTTP failures like the GitHub-suspension 403,
    and adapter-side validation errors) from the supporting adapter
    falls through to the next adapter; if no adapter succeeds, the
    helper returns "" cleanly. The board attach is best-effort —
    the canonical Issue write has already succeeded by the time this
    helper runs, and a board-attach failure must not propagate
    upstream and mask the canonical-success outcome (#297-class bug
    at the handler-helper layer; 3.4.2 fix).

    On a LocalStore-only or Forgejo-only project, this returns ""
    every call — the calling handler should accept project_item_id
    being optional in its response model.
    """
    if ctx.config.project_board is None:
        return ""
    # (#356, 3.7.0 D8 carryover) Daemon-routed attach. Pre-D8.7 this
    # helper walked `ctx.replication.entries()` for a project-board-
    # capable adapter; now the daemon does the walk via the
    # `attach_to_project_board` op. The adapter-level ForgeError
    # fallthrough semantics from 3.4.2 are preserved server-side.
    from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
    from ...daemon_client import DaemonUnavailableError, dispatch_write
    try:
        response = await dispatch_write(
            state_dir(DEFAULT_PROJECT_NAME),
            "attach_to_project_board",
            {
                "board_id": ctx.config.project_board.id,
                "native_id": issue.ref.native_id,
                "owner": issue.ref.owner,
                "repo": issue.ref.repo,
                "kind": issue.ref.kind,
            },
        )
        return response.get("value") or ""
    except DaemonUnavailableError:
        # Daemon down → treat as clean no-op (canonical Issue write
        # has already succeeded; board attach is best-effort).
        return ""


async def create_issue_via_replication(
    ctx: ServerContext,
    *,
    owner: str,
    repo: str,
    title: str,
    body: str,
    labels: list[str],
    milestone: str | int | None = None,
) -> tuple[Issue, str]:
    """Create an Issue through the canonical ReplicationManager and
    attach it to the project board.

    Returns ``(issue, project_item_id)``. Increments
    ``ctx.activity.issues_created`` after the canonical adapter call
    succeeds; the board-attach result no longer gates the counter
    (3.4.2 fix — pre-3.4.2 a board-attach failure propagated and
    masked the canonical-success outcome of the Issue write).

    Failure semantics:

      * Adapter ``create_issue`` raises (typically wrapped as
        ``ReplicationWriteError``) → propagates; board attach is
        skipped; counter unchanged.
      * Adapter succeeds but board attach raises → the helper
        catches every ``ForgeError`` (including HTTP 4xx like the
        GitHub-suspension 403, ``ForgeUnavailableError``, validation
        errors). ``project_item_id`` is ``""``; counter increments
        because the Issue exists in the canonical store. Operator
        can re-attach manually post-recovery.
      * No adapter supports project boards → ``project_item_id`` is
        ``""`` and counter increments. Caller's response model
        treats project_item_id as optional.

    Caller is responsible for any ``ok(...)`` / ``err(...)`` shaping
    around the return value.
    """
    # (#355 / D5.2) Daemon-routed canonical write. MCP becomes a
    # thin caller per Discussion #6 OQ2 closure ("Option C — stdio
    # MCP delegates to daemon"). The daemon owns ReplicationManager
    # and threads per-platform coords (#296) into each adapter's
    # ``create_issue`` call.
    response = await dispatch_write(
        state_dir(DEFAULT_PROJECT_NAME),
        "create_issue",
        {
            "owner": owner,
            "repo": repo,
            "title": title,
            "body": body,
            "labels": labels,
            "milestone": milestone,
            "repo_role": "private",
        },
    )
    issue = Issue.model_validate(response["value"])
    project_item_id = await _attach_to_project_board_if_supported(ctx, issue)
    ctx.activity.issues_created += 1
    return issue, project_item_id
