"""Session lifecycle handlers: open_session, close_session, recover_context."""
from __future__ import annotations

import asyncio
import secrets
from datetime import datetime, timezone

from mcp.types import TextContent

from ... import __version__
from ...automemory import commit_session_state
from ...buffer import has_pending
from ...context import ServerContext
from ...models import GithubConfig, RepoShapeEntry, SessionState, TocDrift
from ...parsers import parse_owner_repo, parse_skill_version
from ...toc_drift import compute_toc_drift
# Late binding for monkey-patch interception (#82 Phase 2b): tests
# reassign attributes on `forge_manager_mcp.server`, so handlers
# must look up github/classifier helpers through the package at call
# time rather than via early-bound `from ...github.foo import bar`.
from forge_manager_mcp import server as _s
from ..helpers import (
    fetch_upstream_skill_text,
    ok,
    resolve_local_skill_path,
)
from ...utils import compose_session_summary


def _read_local_skill_version(project_dir) -> str | None:
    """Parse the local skill file's `**Version:**` header, or None on miss.

    Mirrors the resolve+parse flow used by check_skill_version (#60) so
    open_session reports the same version that drift checks would.
    """
    local_path = resolve_local_skill_path(project_dir)
    if local_path is None:
        return None
    try:
        return parse_skill_version(local_path.read_text(encoding="utf-8"))
    except OSError:
        return None


async def _read_latest_skill_version(
    token: str, public_repo: str, dev_repo: str
) -> str | None:
    """Fetch the upstream skill file's text, parse its version.

    Probes multiple candidate (repo, path) pairs — see helpers
    `fetch_upstream_skill_text` for the order. Returns None if every
    candidate fails (network, missing file, parse miss). (#159)
    """
    text = await fetch_upstream_skill_text(token, public_repo, dev_repo)
    if not text:
        return None
    return parse_skill_version(text)


def _build_repo_shape_targets(
    config: GithubConfig,
) -> list[tuple[str, str]]:
    """Return [(role, owner/name)] for every managed repo to audit."""
    targets: list[tuple[str, str]] = []
    targets.append(("publish_target", config.repos.public))
    targets.append(("dev", config.repos.private))
    for related in config.related_repos:
        if related.relationship == "subsystem":
            targets.append(("subsystem", related.repo))
        elif related.relationship == "publish_target":
            targets.append(("subsystem_publish", related.repo))
    return targets


def _evaluate_compliance(
    role: str,
    path: str,
    visibility: str,
    config: GithubConfig,
) -> tuple[bool, str | None]:
    """Apply §Step 3.5 compliance rules to a single repo entry.

    Rules:
    - role=dev: must be PRIVATE. Anything else is drift.
    - role=publish_target / subsystem_publish: ABSENT or PRIVATE permitted
      pre-release; PUBLIC always permitted. Outside-org placement permitted
      only if `publish_target_outside_org=True` is set.
    - role=subsystem: visibility unconstrained (subsystem repos can be
      public or private depending on project's release state).
    - For all roles: ABSENT is non-compliant unless explicitly allowed
      above.

    "Pre-release" is defined as: `publish_target_outside_org` flag is
    irrelevant; the absence/private state is permitted regardless.
    Tightening this to "no public release tag" is left to a future
    refinement when the repo-shape audit gains release-history visibility.
    """
    if role == "dev":
        if visibility == "PRIVATE":
            return True, None
        if visibility == "ABSENT":
            return False, f"dev repo not found at {path}"
        return False, f"dev repo is {visibility}; must be PRIVATE"

    if role in ("publish_target", "subsystem_publish"):
        # Cross-owner check first (org-membership of owner)
        org_owner = config.owner.lower()
        path_owner = path.split("/", 1)[0].lower()
        if path_owner != org_owner and not config.publish_target_outside_org:
            return False, (
                f"{path} owner '{path_owner}' is not the project's org "
                f"'{org_owner}'; set publish_target_outside_org=true in "
                "github-config.json if intentional"
            )
        # Visibility check — PUBLIC, PRIVATE, ABSENT all allowed.
        # INTERNAL is a no-op for now (no release-state to compare against).
        if visibility in ("PUBLIC", "PRIVATE", "ABSENT", "INTERNAL"):
            return True, None
        return False, f"unexpected visibility {visibility} for {path}"

    if role == "subsystem":
        if visibility == "ABSENT":
            return False, f"subsystem repo not found at {path}"
        return True, None

    return False, f"unknown role {role!r} for {path}"


async def _audit_one_repo(
    token: str,
    role: str,
    path: str,
    config: GithubConfig,
) -> RepoShapeEntry:
    """Per-target audit; safe to run concurrently with peers (#178).

    Each call is one `get_repo_visibility` GraphQL read plus a pure-CPU
    compliance evaluation. Returns a fully-formed RepoShapeEntry —
    including the "path malformed", "GitHub returned ABSENT" (404), and
    "API unreachable" (#381 — degraded public face) sad paths — so the
    caller can simply `gather` and concatenate.

    The three not-known states are kept distinct because they mean
    different things for the operator:

    * ``visibility=ABSENT, compliant=False`` — repo deleted or never
      created. Real drift; banner shows ⚠.
    * ``visibility=UNREACHABLE, compliant=None`` — API failed (auth /
      network / suspension). We don't actually know if the repo exists.
      Banner suppresses ⚠ since this is degraded-mode noise, not drift.
    * ``visibility=PUBLIC|PRIVATE|INTERNAL`` — known.

    Pre-#381 the GitHubError path silently became ``visibility=ABSENT,
    compliant=False`` and the operator had to manually distinguish
    "actually deleted" from "GitHub 403 because suspended" by reading
    `mirror_failures` separately.
    """
    try:
        owner, name = parse_owner_repo(path)
    except ValueError:
        return RepoShapeEntry(
            path=path,
            role=role,
            visibility="ABSENT",
            compliant=False,
            compliance_note=f"path {path!r} is not in owner/name form",
        )

    # (#388, 3.9.0 D5) Daemon-routed visibility probe. Lazy import to
    # tolerate test contexts whose BUILD deps don't include daemon.
    # On daemon-unavailable / route failure → fall back to the
    # legacy GitHub-direct path so existing test coverage works
    # unchanged. Both paths preserve the tri-state compliance
    # contract from #381 / D1.2: ForgeUnavailableError /
    # GitHubError → UNREACHABLE + compliant=None; visibility=None
    # → ABSENT + compliant per role rules.
    visibility: str | None = None
    audit_error_msg: str | None = None
    try:
        from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
        from ...daemon_client import dispatch_read
        sd = state_dir(DEFAULT_PROJECT_NAME)
        try:
            response = await dispatch_read(
                sd, "get_repo_visibility",
                {"owner": owner, "repo": name, "repo_role": "public"},
            )
            visibility = response.get("value")
        except Exception as exc:
            audit_error_msg = str(exc)
            visibility = None
    except ImportError:
        # Daemon module unavailable in this test target — fall through
        # to the legacy GitHub-direct path.
        try:
            visibility = await _s.get_repo_visibility(token, owner, name)
        except _s.GitHubError as exc:
            audit_error_msg = str(exc)

    if audit_error_msg is not None:
        return RepoShapeEntry(
            path=path,
            role=role,
            visibility="UNREACHABLE",
            compliant=None,
            compliance_note=f"audit unreachable — public face degraded: {audit_error_msg}",
        )
    if visibility is None:
        visibility = "ABSENT"
    compliant, note = _evaluate_compliance(role, path, visibility, config)
    return RepoShapeEntry(
        path=path,
        role=role,
        visibility=visibility,
        compliant=compliant,
        compliance_note=note,
    )


async def _audit_repo_shape(
    token: str,
    config: GithubConfig,
) -> list[RepoShapeEntry]:
    """Query GitHub for each managed repo's visibility; evaluate compliance.

    #178 — every target is independent (no shared state between
    visibility lookups), so dispatch them in parallel via
    `asyncio.gather`. Wall time drops from N×round-trip to
    ~max-of-N. Order of returned entries matches the targets list.
    """
    targets = _build_repo_shape_targets(config)
    return list(
        await asyncio.gather(
            *(_audit_one_repo(token, role, path, config) for role, path in targets)
        )
    )


async def _audit_toc_drift(
    token: str,
    config: GithubConfig,
) -> TocDrift | None:
    """Detect Project Discussion TOC drift against current repo state (#194).

    Fetches the active TOC body plus every issue + discussion number
    in the dev repo (in parallel via `asyncio.gather`) and composes a
    `TocDrift` report. Surface is advisory: any failure
    (`GitHubError`, malformed `repos.private`, etc.) returns None and
    `open_session` proceeds — drift detection never gates a session.

    (#388, 3.9.0 D5) Migrated from GitHub-direct
    ``_s.get_discussion_body`` / ``_s.list_all_issue_numbers`` /
    ``_s.list_all_discussion_numbers`` to daemon-routed
    ``dispatch_read``. Lazy daemon import + legacy fallback so test
    contexts whose BUILD deps don't include daemon keep working.
    """
    try:
        owner, repo = parse_owner_repo(config.repos.private)
    except ValueError:
        return None

    # Try daemon-routed dispatch first; fall back to legacy on import
    # failure. Either path returns None on any read failure (advisory
    # surface — never gates a session).
    try:
        from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
        from ...daemon_client import dispatch_read
        sd = state_dir(DEFAULT_PROJECT_NAME)
        try:
            toc_resp, issue_resp, disc_resp = await asyncio.gather(
                dispatch_read(sd, "get_discussion_body", {
                    "native_id": config.project_discussion_id,
                    "owner": owner, "repo": repo,
                    "repo_role": "private",
                }),
                dispatch_read(sd, "list_all_issue_numbers", {
                    "owner": owner, "repo": repo,
                    "repo_role": "private",
                }),
                dispatch_read(sd, "list_all_discussion_numbers", {
                    "owner": owner, "repo": repo,
                    "repo_role": "private",
                }),
            )
            toc_body = toc_resp.get("value")
            issue_numbers = issue_resp.get("value") or []
            discussion_numbers = disc_resp.get("value") or []
        except Exception:
            return None
    except ImportError:
        # Daemon module unavailable in this test context — legacy path.
        try:
            toc_body, issue_numbers, discussion_numbers = await asyncio.gather(
                _s.get_discussion_body(token, config.project_discussion_id),
                _s.list_all_issue_numbers(token, owner, repo),
                _s.list_all_discussion_numbers(token, owner, repo),
            )
        except _s.GitHubError:
            return None

    drift = compute_toc_drift(toc_body, issue_numbers, discussion_numbers)
    return TocDrift(**drift)


async def open_session(ctx: ServerContext) -> list[TextContent]:
    session_id = secrets.token_hex(8)
    timestamp = datetime.now(timezone.utc).isoformat()
    mirror_failures: list[str] = []

    # (#356, 3.7.0 D8.11) Session-event surface goes through the
    # daemon's read_session_events / record_session_event ops.
    # Pre-D8.11 the handler fetched `ctx.replication.canonical()`
    # directly and dispatched against the canonical adapter; post-
    # D8.11 the daemon owns the canonical access. The MCP-side
    # handler reads the daemon's response envelope to detect when
    # the surface is unavailable (legacy 2.x configs without the
    # session-event capability) and falls back to the GitHub
    # comment path same as before.
    from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
    from ...daemon_client import (
        DaemonUnavailableError, dispatch_read, dispatch_write,
    )
    sd = state_dir(DEFAULT_PROJECT_NAME)

    # 3.5.0 Phase C — read prior-session state canonical-first. Pre-3.5.0
    # this was a GitHub-direct `_s.get_discussion_comments` call, so
    # degraded mode (GitHub 403'd since 2026-04-28) appended a
    # "github: prior-session read failed" entry to mirror_failures every
    # session even though the canonical store had the events written by
    # `record_session_event` above. Same fix-class as #297 / 3.4.2 /
    # #309 at the read-side helper.
    #
    # (#358, 3.7.0 D0) The read MUST happen BEFORE the current session's
    # opened.json is written. Pre-#358 the order was reversed: write
    # first, then read — and the read picked up the just-written
    # current-session event as if it were a prior unmatched open,
    # producing a false-positive `prior_session_clean=false` with
    # `prior_session_timestamp` matching the current session. Every
    # operator saw a spurious "unclosed prior session" banner at every
    # session start.
    #
    # Resolution order:
    #   1. daemon-routed `read_session_events` against canonical
    #      adapter — when the canonical has has_session_event_surface,
    #      walk newest-first for the latest opened/closed marker.
    #   2. when the daemon reports `skipped_reason` (canonical lacks
    #      the surface — legacy 2.x configs; Forgejo / GitLab / GitHub
    #      canonical) → fall back to the GitHub Session Lock Discussion
    #      comment read for the legacy backward-compat path.
    #
    # Default `prior_clean=True` if both paths fail or have no markers
    # — the operator can re-investigate via context recovery once
    # access is restored.
    prior_clean = True
    prior_timestamp = None
    canonical_events_read = False
    if ctx.config is not None:
        try:
            response = await dispatch_read(
                sd, "read_session_events", {"last_n": 5},
            )
            error_msg = response.get("error")
            if error_msg:
                # Daemon-side adapter failure (e.g., OSError from a
                # broken docs store) — surface it and let the GitHub
                # fallback run, matching the pre-D8.11 contract.
                mirror_failures.append(
                    f"daemon: prior-session canonical read failed: {error_msg}"
                )
            elif response.get("skipped_reason") is None:
                events = response.get("value") or []
                for evt in reversed(events):
                    # Events come back as model_dump(mode="json") dicts
                    # — keys are session_id / event / timestamp / body.
                    # Defense-in-depth: skip any event whose session_id
                    # matches the current session.
                    if evt.get("session_id") == session_id:
                        continue
                    evt_kind = evt.get("event")
                    # (#356, 3.7.0 D8.11) Pydantic mode="json" emits
                    # datetime as "...Z"; pre-D8.11 the handler called
                    # `evt.timestamp.isoformat()` which produced
                    # "...+00:00". Normalize for caller-visible
                    # string-format stability.
                    evt_ts = (evt.get("timestamp") or "").replace("Z", "+00:00")
                    if evt_kind == "opened":
                        prior_clean = False
                        prior_timestamp = evt_ts or None
                        break
                    if evt_kind == "closed":
                        prior_timestamp = evt_ts or None
                        break
                canonical_events_read = True
        except DaemonUnavailableError as exc:
            mirror_failures.append(
                f"daemon: prior-session read unavailable: {exc}"
            )

    if not canonical_events_read:
        try:
            comments = await _s.get_discussion_comments(
                ctx.github_token, ctx.config.session_lock_discussion_id, last_n=5
            )
            for comment in reversed(comments):
                body = comment["body"]
                if "**Session opened**" in body:
                    prior_clean = False
                    prior_timestamp = comment.get("createdAt")
                    break
                if "**Session closed**" in body:
                    prior_timestamp = comment.get("createdAt")
                    break
        except _s.GitHubError as exc:
            mirror_failures.append(f"github: prior-session read failed: {exc}")

    # (#358) Write the current session's opened.json AFTER the prior-
    # session read. (#356, 3.7.0 D8.11) Daemon-routed canonical-side
    # session-event recording. Skipped silently when the canonical
    # adapter lacks the session-event surface (legacy 2.x configs).
    if ctx.config is not None:
        try:
            response = await dispatch_write(
                sd, "record_session_event", {
                    "session_id": session_id,
                    "event": "opened",
                    "body": (
                        f"timestamp={timestamp} skill_version={__version__}"
                    ),
                },
            )
            err_msg = response.get("error")
            if err_msg:
                mirror_failures.append(
                    f"daemon: record_session_event failed: {err_msg}"
                )
        except DaemonUnavailableError as exc:
            mirror_failures.append(
                f"daemon: record_session_event unavailable: {exc}"
            )

    # Write session-opened comment to the GitHub Session Lock Discussion.
    # Best-effort — failure surfaces in mirror_failures and does NOT
    # poison the response. session_id has already been minted and the
    # canonical write (if applicable) has already succeeded above.
    #
    # (#388, 3.9.0 D5 / bypass 5/5) Migrated from GitHub-direct
    # ``_s.add_discussion_comment`` to daemon-routed ``dispatch_write``
    # via the existing ``append_comment`` op (#355 / D5.3). Routes
    # through ReplicationManager.write so backend failures properly
    # degrade adapter state — fixes the bypass that caused every
    # session to re-attempt + re-fail GitHub without state-machine
    # propagation. Lazy daemon import → tolerant of test contexts
    # whose BUILD deps don't include daemon (legacy GitHub-direct
    # fallback preserved). Session Lock isn't a canonical artifact;
    # this path is purely a mirror operation, but the routing intent
    # is to make the failure observable through the standard
    # backend-state surface.
    body = (
        f"**Session opened**\n"
        f"Time: {timestamp}\n"
        f"Session ID: {session_id}\n"
        f"Skill version: {__version__}"
    )
    try:
        from ...daemon.paths import (
            DEFAULT_PROJECT_NAME as _DPN, state_dir as _sdfn,
        )
        from ...daemon_client import dispatch_write as _dispatch_write
        try:
            await _dispatch_write(
                _sdfn(_DPN),
                "append_comment",
                {
                    "parent_kind": "discussion",
                    "parent_native_id": ctx.config.session_lock_discussion_id,
                    "owner": "",
                    "repo": "",
                    "body": body,
                    "repo_role": "private",
                },
            )
        except Exception as exc:
            mirror_failures.append(f"github: session-opened write failed: {exc}")
    except ImportError:
        # Daemon module unavailable — legacy GitHub-direct fallback.
        try:
            await _s.add_discussion_comment(
                ctx.github_token, ctx.config.session_lock_discussion_id, body
            )
        except _s.GitHubError as exc:
            mirror_failures.append(f"github: session-opened write failed: {exc}")

    pending_notice = ""
    if has_pending(ctx.project_dir):
        pending_notice = " ⚠️ Pending buffer has unresolved operations."

    skill_version = _read_local_skill_version(ctx.project_dir)
    # (#382 follow-up, 3.10.0 D0) Probe the daemon and auto-restart on
    # version drift BEFORE the advisory-read gather. Several of those
    # reads route through daemon ops added in 3.9.0 D5 #388
    # (`get_repo_visibility`, `list_all_issue_numbers`,
    # `list_all_discussion_numbers`); a daemon stuck on an older
    # version doesn't have those handlers registered and returns
    # HTTP 400, surfacing as UNREACHABLE / drift in the audit
    # results. Probing first means the auto-restart completes before
    # the audits dispatch, and they hit the version that knows the
    # new ops. The probe is fast (~50ms typical); the lost
    # parallelism with the audits is not load-bearing.
    daemon_status = await _probe_daemon_status_for_session(
        project_dir=ctx.project_dir,
    )

    # The three GitHub-bound startup reads — upstream skill version,
    # repo-shape compliance audit (#178), TOC drift detection (#194) —
    # are independent. Dispatch them in parallel so wall time is the
    # max of the three rather than the sum. Each helper already
    # tolerates GitHubError internally and returns None / [] / None;
    # the outer try wraps the unlikely case where one of them raises
    # an unexpected error so a single failure doesn't gate the
    # session.
    latest_skill_version: str | None = None
    repo_shape: list[RepoShapeEntry] = []
    toc_drift = None
    try:
        latest_skill_version, repo_shape, toc_drift = await asyncio.gather(
            _read_latest_skill_version(
                ctx.github_token,
                ctx.config.repos.public,
                ctx.config.repos.private,
            ),
            _audit_repo_shape(ctx.github_token, ctx.config),
            _audit_toc_drift(ctx.github_token, ctx.config),
        )
    except _s.GitHubError as exc:
        mirror_failures.append(f"github: advisory reads failed: {exc}")

    state = SessionState(
        session_id=session_id,
        prior_session_clean=prior_clean,
        prior_session_timestamp=prior_timestamp,
        project_discussion_id=ctx.config.project_discussion_id,
        session_lock_discussion_id=ctx.config.session_lock_discussion_id,
        category_architecture_id=ctx.config.discussion_categories.Architecture.id,
        category_ux_ui_id=ctx.config.discussion_categories.UX_UI.id,
        category_ideas_id=ctx.config.discussion_categories.Ideas.id,
        category_claude_use_only_id=ctx.config.discussion_categories.claude_use_only.id,
        project_board_id=ctx.config.project_board.id,
        account_type=ctx.config.account_type,
        skill_version=skill_version,
        mcp_server_version=__version__,
        latest_skill_version=latest_skill_version,
        repo_shape=repo_shape,
        toc_drift=toc_drift,
    )

    # (#340 / Phase D3b.4n) Comprehensive daemon-health snapshot
    # already captured above before the audit gather (#382 follow-up,
    # 3.10.0 D0) — `daemon_status` is in scope from there. Reusing
    # rather than re-probing keeps the response single-source-of-
    # truth on daemon state.

    # (#341 / Phase D3b.4o) Surface daemon-side alerts the operator
    # may have missed while the UI was closed. Best-effort — when
    # no daemon is running this returns an empty list.
    daemon_alerts = await _fetch_daemon_alerts_for_session()

    # (#345 / Phase D3b.4r) Code-design status snapshot at session
    # start so Claude can surface unresolved findings as an
    # advisory before getting absorbed in the work. Best-effort —
    # tolerant of import + walk failures so session start never
    # fails on this surface.
    from forge_manager_mcp.code_design.probe import probe_code_design_status
    code_design_status = probe_code_design_status(ctx.project_dir)

    # (#372 / 3.8.0 D1 / Discussion #8) Multi-user version coordination
    # — surface drift between the user's installed MCP wheel, the
    # project's required version (read from skill prose), and PyPI
    # latest. Best-effort: PyPI probe failures fall through to None;
    # never blocks session start.
    try:
        from forge_manager_mcp.version_coord import (
            compute_drift, to_dict as _drift_to_dict,
        )
        state_dir = _resolve_state_dir(ctx)
        drift = compute_drift(
            project_dir=ctx.project_dir, state_dir=state_dir,
        )
        version_drift = _drift_to_dict(drift)
    except Exception:  # noqa: BLE001 — coord layer is advisory
        version_drift = None

    result = state.model_dump()
    result["pending_notice"] = pending_notice
    result["mirror_failures"] = mirror_failures
    result["daemon_status"] = daemon_status
    result["daemon_alerts"] = daemon_alerts
    result["code_design_status"] = code_design_status
    result["version_drift"] = version_drift
    ctx.current_session = dict(result)
    return ok(result)


def _resolve_state_dir(ctx) -> "Path | None":
    """Resolve the daemon state-dir for the current project.

    Used by version_coord's PyPI cache. Returns None on any failure;
    PyPI probe falls through to network-only mode.
    """
    try:
        from forge_manager_mcp.daemon.paths import state_dir
        return state_dir()
    except Exception:  # noqa: BLE001
        return None


def _empty_daemon_status() -> dict:
    return {
        "running": False,
        "version": None,
        "version_match": False,
        "credentials_loaded": False,
        "config_loaded": False,
        "url": None,
        "warnings": [],
    }


async def _probe_daemon_status_for_session(project_dir=None) -> dict:
    """(#340) Tolerant call to ``daemon_client.full_status_probe``.

    Returns the snapshot shape on every path; on import failure
    returns a default-not-running snapshot so session start
    proceeds even without the daemon module available.

    (#382, 3.9.0) When the daemon's running version differs from
    MCP's and the on-disk wheel matches MCP, auto-restart the
    daemon via ``restart_daemon`` then re-probe — eliminates the
    operator-friction "consider daemon-restart" warning loop in
    favor of just doing the restart. When MCP itself is stale
    relative to the on-disk wheel, surface a "restart Claude Code"
    hint instead (daemon-restart wouldn't fix the asymmetry).
    The decision logic lives in pure
    ``decide_auto_restart_action``; this wrapper is the IO shell.
    """
    try:
        from forge_manager_mcp import __version__ as _mcp_version
        from forge_manager_mcp.daemon.paths import (
            DEFAULT_PROJECT_NAME, state_dir,
        )
        from forge_manager_mcp.daemon_client import (
            decide_auto_restart_action,
            full_status_probe,
            installed_package_version,
            restart_daemon,
        )
    except Exception:
        return _empty_daemon_status()

    sd = state_dir(DEFAULT_PROJECT_NAME)
    try:
        status = await full_status_probe(sd, _mcp_version)
    except Exception:
        return _empty_daemon_status()

    decision = decide_auto_restart_action(
        status.get("version"), _mcp_version, installed_package_version(),
    )
    restart_action: dict | None = None
    if decision == "restart":
        try:
            restart_action = restart_daemon(
                sd, DEFAULT_PROJECT_NAME, project_dir=project_dir,
            )
            try:
                status = await full_status_probe(sd, _mcp_version)
            except Exception:
                pass  # Keep stale snapshot; restart_action carries the truth.
        except Exception as exc:  # noqa: BLE001
            restart_action = {
                "ok": False, "from_pid": None, "to_pid": None,
                "from_version": status.get("version"),
                "to_version": None,
                "message": f"restart_daemon raised: {exc}",
            }
    elif decision == "skip_mcp_stale":
        restart_action = {
            "ok": False, "from_pid": None, "to_pid": None,
            "from_version": status.get("version"),
            "to_version": None,
            "message": (
                f"MCP {_mcp_version} is stale relative to installed "
                f"{installed_package_version()}; restart Claude Code "
                f"to pick up the new MCP version (daemon-restart "
                f"alone wouldn't align)"
            ),
        }

    if restart_action is not None:
        status = {**status, "restart_action": restart_action}
    return status


async def _fetch_daemon_alerts_for_session() -> dict:
    """(#341) Read cursor → fetch alerts since cursor → optionally
    publish a version-mismatch alert → return the daemon_alerts
    payload for inclusion in open_session's response.

    Returns ``{since, alerts, unobserved_count}`` per Issue body.
    Cursor is updated by the corresponding helper in close_session;
    we read here, write at close, so cross-session continuity holds
    even when alerts are observed mid-session via get_daemon_alerts.

    Tolerant of every failure mode — when the daemon is absent or
    unreachable, returns ``{since: None, alerts: [], unobserved_count: 0}``
    rather than poisoning session start.
    """
    try:
        from forge_manager_mcp import __version__ as _mcp_version
        from forge_manager_mcp.daemon.discovery import read_discovery
        from forge_manager_mcp.daemon.paths import (
            DEFAULT_PROJECT_NAME, state_dir,
        )
        from forge_manager_mcp.daemon_client import (
            fetch_alerts,
            post_alert_to_daemon,
            read_alert_cursor,
        )
    except Exception:
        return {"since": None, "alerts": [], "unobserved_count": 0}

    sd = state_dir(DEFAULT_PROJECT_NAME)
    cursor = read_alert_cursor(sd)

    # Version-mismatch source: when the daemon's running version
    # differs from this MCP's version, post an alert. Idempotency
    # is rough — a long-running daemon plus repeated MCP restarts
    # could re-post; the daemon's ring-buffer dedup is the operator-
    # visible mitigation.
    try:
        df = read_discovery(sd)
        if df is not None and df.version != _mcp_version:
            await post_alert_to_daemon(sd, {
                "level": "warning",
                "message": (
                    f"Daemon version {df.version} differs from MCP "
                    f"version {_mcp_version}. Consider `forge-manager-"
                    f"mcp daemon-restart` to align."
                ),
                "tags": ["daemon", "version-mismatch"],
            })
    except Exception:
        # Tolerant — version-mismatch alert is informational; never
        # fail session start because of it.
        pass

    alerts = await fetch_alerts(sd, since=cursor)
    return {
        "since": cursor,
        "alerts": alerts,
        "unobserved_count": len(alerts),
    }


def _persist_alert_cursor(current_session: dict | None) -> None:
    """(#341) Update the alert cursor at session close.

    Reads ``current_session.daemon_alerts.alerts`` (set by
    ``open_session``); the newest alert's timestamp becomes the
    new cursor. When no alerts were fetched this session the
    prior cursor stays in place — next session sees alerts
    posted between this close and that open.

    Tolerant — every failure mode (missing session, missing field,
    malformed cursor, file IO error) is silently swallowed.
    """
    if not current_session:
        return
    daemon_alerts = current_session.get("daemon_alerts") or {}
    alerts = daemon_alerts.get("alerts") or []
    if not alerts:
        return
    try:
        from forge_manager_mcp.daemon.paths import (
            DEFAULT_PROJECT_NAME, state_dir,
        )
        from forge_manager_mcp.daemon_client import write_alert_cursor
    except Exception:
        return
    # Alerts come back newest-first per the daemon's ordering
    # contract; alerts[0] has the latest timestamp.
    latest = alerts[0].get("timestamp")
    if not isinstance(latest, str):
        return
    try:
        write_alert_cursor(state_dir(DEFAULT_PROJECT_NAME), latest)
    except Exception:
        pass


async def close_session(
    ctx: ServerContext,
    summary: str | None,
    skill_update_candidates: int,
    update_memory: bool = True,
) -> list[TextContent]:
    pending = has_pending(ctx.project_dir)
    effective = summary.strip() if isinstance(summary, str) else ""
    if not effective:
        effective = compose_session_summary(
            ctx.activity, skill_update_candidates, pending
        )

    timestamp = datetime.now(timezone.utc).isoformat()
    body = (
        f"**Session closed**\n"
        f"Time: {timestamp}\n"
        f"Summary: {effective}\n"
        f"Skill update candidates: {skill_update_candidates}"
    )

    # Best-effort GitHub-side comment write — same tolerance as
    # open_session's f4853e7 fix. Failures land in close_failures so
    # the response surfaces the degradation without dropping the
    # close itself.
    close_failures: list[str] = []
    try:
        await _s.add_discussion_comment(
            ctx.github_token, ctx.config.session_lock_discussion_id, body
        )
    except _s.GitHubError as exc:
        close_failures.append(f"github: session-closed write failed: {exc}")

    # (#356, 3.7.0 D8.11) Daemon-routed canonical-side session-event
    # for the close. Same gating as open_session — daemon's op
    # checks `has_session_event_surface` and skips silently when
    # the canonical lacks the surface (legacy 2.x configs).
    if ctx.config is not None:
        from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
        from ...daemon_client import (
            DaemonUnavailableError, dispatch_write,
        )
        session_id = (ctx.current_session or {}).get("session_id", "")
        if session_id:
            try:
                response = await dispatch_write(
                    state_dir(DEFAULT_PROJECT_NAME),
                    "record_session_event",
                    {
                        "session_id": session_id,
                        "event": "closed",
                        "body": effective,
                    },
                )
                err_msg = response.get("error")
                if err_msg:
                    close_failures.append(
                        f"daemon: record_session_event failed: {err_msg}"
                    )
            except DaemonUnavailableError as exc:
                close_failures.append(
                    f"daemon: record_session_event unavailable: {exc}"
                )

    # (Phase H / 3.5.0) SiteRebuilder flush REMOVED with Hugo. The
    # daemon (D3a+) replaces SiteRebuilder; close_session no longer
    # has a static-site flush step. The `site_rebuild` field in the
    # response is kept (set to a removed-marker dict) so existing
    # operator-side scripts that read the field don't crash on
    # missing-key — they just see ``{"removed_in": "3.5.0"}``.

    # (#341 / Phase D3b.4o) Persist the latest-observed-alert
    # cursor so the next session's open_session reads it back +
    # fetches only new alerts. Cursor is the ISO timestamp of the
    # newest alert observed in this session, OR the prior cursor
    # if no alerts were fetched this session.
    _persist_alert_cursor(ctx.current_session)

    # Auto-memory commit (#161). Best-effort — the GitHub-side
    # session-close has already happened; a memory-write failure does
    # NOT fail close_session.
    memory_status: dict = {"committed": False, "skipped_reason": "disabled"}
    if update_memory:
        memory_status = commit_session_state(
            ctx.config, ctx.activity, skill_update_candidates, pending
        )

    return ok({
        "summary": effective,
        "memory": memory_status,
        "site_rebuild": {"removed_in": "3.5.0"},
        "close_failures": close_failures,
    })


async def recover_context(
    ctx: ServerContext,
    days: int,
    include_toc_body: bool = True,
    include_open_issues: bool = True,
    include_recent_discussions: bool = True,
    include_milestones: bool = True,
    max_open_issues: int = 100,
) -> list[TextContent]:
    """Bundled context-recovery read with optional component opt-outs (#222).

    Component opt-out flags let callers skip sections they don't need.
    Defaults reproduce the pre-2.3 behavior — every component included.

    `max_open_issues` caps the open-Issues list defensively (1–100); the
    underlying GraphQL query limits at the same range. The original
    auto-spill / file-path output proposal (#222 v1) was descoped per
    the #235 reframe cascade — the dominant byte contributor (the
    unbounded ## Issues table in the Project TOC) drops out via #235
    + #241, so the inline payload fits comfortably without auto-spill.
    """
    if max_open_issues < 1 or max_open_issues > 100:
        raise ValueError("max_open_issues must be between 1 and 100.")

    if ctx.current_session is None:
        await open_session(ctx)
    session_snapshot = ctx.current_session

    owner_name, private_repo = parse_owner_repo(ctx.config.repos.private)

    # (#356, 3.7.0 D8.5) Daemon-routed composite read. Bundle
    # arrives as a JSON dict; reconstruct as RecoveryBundle so the
    # downstream attribute-access shapers (`_issue_to_recovery_dict`
    # etc.) work unchanged.
    from ...daemon.paths import DEFAULT_PROJECT_NAME, state_dir
    from ...daemon_client import dispatch_read
    from ...adapters.types import RecoveryBundle
    read_response = await dispatch_read(
        state_dir(DEFAULT_PROJECT_NAME),
        "bundle_recover_context",
        {
            "owner": owner_name,
            "repo": private_repo,
            "toc_discussion_id": ctx.config.project_discussion_id,
            "since_days": days,
            "issue_limit": max_open_issues,
            "repo_role": "private",
        },
    )
    bundle_payload = read_response.get("value", {}) or {}
    bundle = (
        RecoveryBundle(**bundle_payload)
        if isinstance(bundle_payload, dict)
        else bundle_payload
    )

    response: dict = {
        "session": session_snapshot,
        # #98 — surface the typed multi-repo graph so Claude's
        # cross-repo decisions at session start don't rely on
        # memory or a second config read. Always included; tiny.
        "related_repos": [
            r.model_dump() for r in ctx.config.related_repos
        ],
    }
    if include_toc_body:
        response["project_toc_body"] = bundle.toc_body
    if include_open_issues:
        response["open_issues"] = [_issue_to_recovery_dict(i) for i in bundle.open_issues]
    if include_recent_discussions:
        response["recent_discussions"] = [
            _discussion_to_recovery_dict(d) for d in bundle.recent_discussions
        ]
    if include_milestones:
        response["milestones"] = [
            _milestone_to_recovery_dict(m) for m in bundle.milestones
        ]

    return ok(response)


def _issue_to_recovery_dict(issue) -> dict:
    """Reshape a canonical Issue to the legacy recovery-bundle dict
    shape (#274 Phase C5). Preserves the {number, title, url,
    updated_at, labels} keys callers expect."""
    return {
        "number": issue.ref.number,
        "title": issue.title,
        "url": issue.url,
        "updated_at": issue.updated_at.isoformat() if issue.updated_at else "",
        "labels": list(issue.labels),
    }


def _discussion_to_recovery_dict(disc) -> dict:
    """Reshape a canonical Discussion to legacy recovery-bundle shape
    {number, title, url, updated_at, category}."""
    # Discussions don't carry an updated_at on the canonical type
    # today; created_at is the closest proxy. Empty string when the
    # backend doesn't report a timestamp.
    return {
        "number": disc.ref.number,
        "title": disc.title,
        "url": disc.url,
        "updated_at": disc.created_at.isoformat() if disc.created_at else "",
        "category": disc.category,
    }


def _milestone_to_recovery_dict(ms) -> dict:
    """Reshape a canonical Milestone to legacy recovery-bundle shape
    {title, due_on, percent_complete}."""
    return {
        "title": ms.title,
        "due_on": ms.due_on.isoformat() if ms.due_on else None,
        "percent_complete": ms.percent_complete,
    }
