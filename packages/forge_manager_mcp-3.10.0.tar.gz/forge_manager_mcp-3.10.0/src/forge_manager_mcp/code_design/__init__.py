"""Code-design evaluators for the `check_code_design` MCP tool
(Phase D2 / #330 / #308).

Five mechanical evaluators corresponding to the `code_design.*`
gates declared in 3.4.1's `gates.yaml`:

- ``schema_as_functions`` — Rule 5; AST scan for top-level
  Pydantic / dataclass / TypedDict.
- ``test_purity_tagging`` — Rule 6; BUILD-file scan for
  py_test missing exactly one of `pure` / `impure`.
- ``schema_tests_tagged`` — Rule 7; depends on schema_as_functions
  output; assert each factory has ≥1 positive test in
  `schema`-tagged target.
- ``negative_tests_tagged`` — Rule 8; depends on
  schema_as_functions + effect-function inventory; assert each
  has ≥1 negative test in `negative`-tagged target.
- ``utility_dir_isolation`` — Rule 4; static import-graph; flag
  modules imported by ≥3 modules outside utility directories.

Implementation scope per #330 / OQ4: Python-only in 3.5.0;
TypeScript-equivalent evaluators in 3.6.0+.

Each evaluator lives in its own module with its own library
target per Test Dep-Graph Discipline; this `__init__` is the
re-export surface only.
"""
from forge_manager_mcp.code_design._types import (
    finding_to_dict,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import (
    all_rules,
    clear_registry,
    get_evaluator,
    register_evaluator,
)

# Side-effect imports: each evaluator registers itself at import
# time via ``register_evaluator(RULE_NAME, evaluate)``. The handler
# imports this package and walks the registry.
from forge_manager_mcp.code_design import schema_as_functions  # noqa: F401
from forge_manager_mcp.code_design import test_purity_tagging  # noqa: F401
from forge_manager_mcp.code_design import schema_tests_tagged  # noqa: F401
from forge_manager_mcp.code_design import negative_tests_tagged  # noqa: F401
from forge_manager_mcp.code_design import utility_dir_isolation  # noqa: F401
# (#344 / D3b.4q) Advisory tier — judgment-heavy Rules 1/2/3.
from forge_manager_mcp.code_design import effect_inline_advisory  # noqa: F401
from forge_manager_mcp.code_design import async_parity_advisory  # noqa: F401
from forge_manager_mcp.code_design import interceptor_reuse_advisory  # noqa: F401
# (#346 / D3b.4s) Diff-aware advisory.
from forge_manager_mcp.code_design import refactor_advisory  # noqa: F401


__all__ = [
    "all_rules",
    "clear_registry",
    "finding_to_dict",
    "get_evaluator",
    "make_finding",
    "make_location",
    "register_evaluator",
]
