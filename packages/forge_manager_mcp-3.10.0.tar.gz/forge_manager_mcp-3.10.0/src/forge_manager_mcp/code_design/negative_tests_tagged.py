"""negative_tests_tagged evaluator (Phase D2.4 / Rule 8).

Per Rule 8 (`code_design.negative_tests_tagged` gate at
``code-design.md#rule-negative-tests``):

> Every effect function and every schema factory has at least one
> negative test (assert the right error type / message on invalid
> input). Test target carries the `negative` tag.

Implementation: BUILD-target-level cross-reference, same shape as
``schema_tests_tagged`` but with two enforcement classes:

1. **Schema-factory libraries** — same inventory as
   ``schema_tests_tagged``: ``make_*`` functions in the library's
   srcs.
2. **Effect-function libraries** — libraries whose srcs live under
   canonical effect-function directories (per
   ``factory_inventory.is_effect_path``: ``flows/``, ``adapters/``,
   ``replication/``, ``migration/``, plus ``interceptors.py``).

For each library matching either class, the rule requires ≥1 test
target tagged ``negative`` whose ``deps`` reference the library.

Same heuristic-and-cross-reference shape as schema_tests_tagged;
shares the BUILD-walk + factory-inventory infrastructure.
"""
from __future__ import annotations

from pathlib import Path

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.build_parser import parse_file
from forge_manager_mcp.code_design.factory_inventory import (
    inventory_for_path,
    is_effect_path,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "negative_tests_tagged"
RULE_ANCHOR = "code-design.md#rule-negative-tests"


def _normalize_dep(dep: str) -> str:
    if dep.startswith("@"):
        return ""
    if "//" in dep:
        return dep.split(":")[-1]
    if dep.startswith(":"):
        return dep[1:]
    return dep


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    configured_severity: Severity,
) -> list:
    """Walk BUILD files; identify libraries needing negative tests
    (factory-bearing OR effect-bearing); cross-reference against
    `negative`-tagged test targets' declared deps.
    """
    targets = scan_paths if scan_paths else [project_root]
    libraries: list[dict] = []
    test_targets = []
    findings = []

    for target in targets:
        target_root = target if target.is_absolute() else project_root / target
        for build_file in _walk_builds(target_root):
            parsed = parse_file(build_file)
            build_dir = build_file.parent
            for t in parsed:
                if t.rule == "py_library" or t.rule.endswith("_library"):
                    # Resolve srcs relative to the BUILD file's directory.
                    resolved_srcs = []
                    rel_srcs = []
                    for s in t.srcs:
                        abs_path = (build_dir / s).resolve()
                        resolved_srcs.append(abs_path)
                        try:
                            rel = abs_path.relative_to(project_root)
                            rel_srcs.append(str(rel).replace("\\", "/"))
                        except ValueError:
                            rel_srcs.append(s)
                    libraries.append({
                        "name": t.name,
                        "build_file": build_file,
                        "line": t.line,
                        "abs_srcs": resolved_srcs,
                        "rel_srcs": rel_srcs,
                    })
                elif (
                    t.rule == "py_test"
                    or t.rule.endswith("_test")
                ) and t.rule != "test_suite":
                    test_targets.append(t)

    # Identify libraries needing negative coverage.
    needing_coverage: list[dict] = []
    for lib in libraries:
        if lib["name"] is None:
            continue
        # Check for factories.
        factories: list[str] = []
        for src in lib["abs_srcs"]:
            factories.extend(inventory_for_path(src))
        # Check for effect-directory placement.
        is_effect = any(is_effect_path(rel) for rel in lib["rel_srcs"])
        if factories or is_effect:
            lib["factories"] = factories
            lib["is_effect"] = is_effect
            needing_coverage.append(lib)

    # Index `negative`-tagged tests' deps.
    negative_tested: set[str] = set()
    for test in test_targets:
        if "negative" not in test.tags:
            continue
        for dep in test.deps:
            normalized = _normalize_dep(dep)
            if normalized:
                negative_tested.add(normalized)

    for lib in needing_coverage:
        if lib["name"] in negative_tested:
            continue
        try:
            rel = lib["build_file"].relative_to(project_root)
            rel_str = str(rel).replace("\\", "/")
        except ValueError:
            rel_str = str(lib["build_file"])

        kind_descr = []
        if lib["factories"]:
            kind_descr.append(f"{len(lib['factories'])} schema factories")
        if lib["is_effect"]:
            kind_descr.append("effect functions")
        kind_str = " and ".join(kind_descr) if kind_descr else "tracked surface"

        findings.append(
            make_finding(
                rule=RULE_NAME,
                severity=configured_severity,
                location=make_location(
                    path=rel_str, line=lib["line"], symbol=lib["name"],
                ),
                message=(
                    f"Library '{lib['name']}' contains {kind_str} "
                    f"but no test target tagged `negative` "
                    f"declares deps on it."
                ),
                rule_anchor=RULE_ANCHOR,
                suggestion=(
                    f"Add `tags = [\"negative\", ...]` to a test "
                    f"target whose deps include `:{lib['name']}` "
                    f"and that exercises invalid-input / error "
                    f"paths."
                ),
            )
        )
    return findings


def _walk_builds(root: Path):
    if root.is_file():
        if root.name in ("BUILD", "BUILD.bazel"):
            yield root
        return
    for p in root.rglob("BUILD"):
        if any(part.startswith("bazel-") for part in p.parts):
            continue
        if any(part in ("__pycache__", ".git", ".venv", "node_modules")
               for part in p.parts):
            continue
        yield p
    for p in root.rglob("BUILD.bazel"):
        if any(part.startswith("bazel-") for part in p.parts):
            continue
        if any(part in ("__pycache__", ".git", ".venv", "node_modules")
               for part in p.parts):
            continue
        yield p


# Register at import time.
register_evaluator(RULE_NAME, evaluate)
