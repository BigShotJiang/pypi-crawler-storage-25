"""effect_inline_advisory evaluator (Phase D3b.4q / #344, Rule 2).

Heuristic advisory for Rule 2 (Effect-then-interceptor pattern).
Detects functions that inline ≥2 IO calls (file read/write, HTTP,
subprocess, etc.) without splitting them into named effect
functions. Emits ``info`` severity by default — these are
*candidates for review*, not authoritative violations.

**Why an advisory tier.** The 5 mechanical evaluators (D2 / #308)
give definitive `fail`/`warn`/`info` for AST-pattern-matched
rules. The 3 judgment-heavy rules (1/2/3) were prose-only-
enforced; #344's audit showed this leaves gaps the dogfood gate
can't catch. This advisory is the heuristic-tier middle ground —
imprecise but visible.

**False positives + false negatives are expected.** A function
with 2 inlined IO calls might be a one-shot script that doesn't
warrant the effect-split ceremony; a single-IO-call function
might still violate Rule 2 if that one call mixes with substantial
business logic. Operators treat findings as candidates.
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterable, Literal

from forge_manager_mcp.code_design._types import (
    Severity,
    make_finding,
    make_location,
)
from forge_manager_mcp.code_design.registry import register_evaluator


RULE_NAME = "effect_inline_advisory"
RULE_ANCHOR = "code-design.md#rule-effect-then-interceptor"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
})


# IO-call attribute patterns. Each tuple is (module-or-instance,
# attribute) — when an `ast.Call` node's `.func` is an Attribute
# whose .attr matches AND .value resolves to a name in the prefix
# set, count it as an IO call.
_IO_ATTR_PATTERNS: dict[str, frozenset[str]] = {
    # File-IO via Path / Path-like
    "PATH_METHODS": frozenset({
        "read_text", "write_text", "read_bytes", "write_bytes",
        "iterdir", "stat", "lstat", "mkdir", "rmdir", "unlink",
        "rename", "replace", "chmod", "exists", "is_file", "is_dir",
        "open",
    }),
    # HTTP via httpx
    "HTTPX_METHODS": frozenset({
        "get", "post", "put", "patch", "delete", "head", "request",
    }),
    # Subprocess
    "SUBPROCESS_METHODS": frozenset({
        "run", "check_call", "check_output", "Popen",
    }),
}


# Standalone names that count as IO when called directly (not via
# attribute access).
_IO_NAMES: frozenset[str] = frozenset({
    "open",  # builtins.open
})


def _is_io_call(node: ast.Call) -> bool:
    """Return True if the call node looks like an IO operation.

    Matches:
        Path(...).read_text()
        path.iterdir()
        client.get(...)            # httpx async/sync client
        subprocess.run(...)
        os.path.exists(...)
        await thing.read_text()    # await wrapper transparent to AST
    """
    func = node.func
    if isinstance(func, ast.Name) and func.id in _IO_NAMES:
        return True
    if isinstance(func, ast.Attribute):
        attr = func.attr
        for pattern_set in _IO_ATTR_PATTERNS.values():
            if attr in pattern_set:
                return True
    return False


def _count_io_calls(node: ast.AST) -> int:
    """Count IO calls inside a function body, recursively walking."""
    count = 0
    for child in ast.walk(node):
        if isinstance(child, ast.Call) and _is_io_call(child):
            count += 1
    return count


def analyze_module(
    *,
    tree: ast.AST,
    file_path: Path,
    severity: Severity,
    threshold: int = 2,
) -> list:
    """Pure analyzer — given a parsed AST, return findings for
    functions with ≥``threshold`` inline IO calls.

    Splits effect-then-interceptor's spirit: the FUNCTION is the
    candidate; the analyzer is pure of file IO.
    """
    findings: list = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        # Skip nested functions — Rule 2 is about the orchestrator
        # function's surface; nested helpers are part of the impl.
        # (We still walk into them via ast.walk, but only top-level
        # function defs receive findings.)
        io_count = _count_io_calls(node)
        if io_count < threshold:
            continue
        findings.append(make_finding(
            rule=RULE_NAME,
            severity=severity,
            location=make_location(
                path=str(file_path),
                line=node.lineno,
                symbol=node.name,
            ),
            message=(
                f"function '{node.name}' has {io_count} inline IO "
                f"calls; consider splitting effects into named "
                f"functions per Rule 2"
            ),
            rule_anchor=RULE_ANCHOR,
            suggestion=(
                "Extract IO into named effect functions in a "
                "sibling 'effects/' module; orchestrator passes "
                "data between them."
            ),
        ))
    return findings


def evaluate(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: Severity,
) -> list:
    """Evaluator entry point. Matches the registered signature
    (project_root, scan_paths, severity).

    Effect — file walk + parse. Pure analyzer split per Rule 2.
    """
    targets: list[Path]
    if scan_paths:
        targets = [Path(p) for p in scan_paths]
    else:
        targets = [project_root]

    files_to_scan: list[Path] = []
    for target in targets:
        full = target if target.is_absolute() else project_root / target
        if full.is_file() and full.suffix == ".py":
            files_to_scan.append(full)
            continue
        if not full.is_dir():
            continue
        for entry in full.rglob("*.py"):
            # Skip denylist directories.
            if any(part in _DEFAULT_DENYLIST for part in entry.parts):
                continue
            files_to_scan.append(entry)

    findings: list = []
    for file_path in files_to_scan:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file_path))
        except (OSError, SyntaxError):
            continue
        findings.extend(analyze_module(
            tree=tree, file_path=file_path, severity=severity,
        ))
    return findings


register_evaluator(RULE_NAME, evaluate)
