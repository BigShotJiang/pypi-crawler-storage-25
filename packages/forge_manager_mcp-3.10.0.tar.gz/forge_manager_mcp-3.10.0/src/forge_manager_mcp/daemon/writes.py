"""Daemon-side write dispatcher (Phase D5 / #355 / 3.6.0).

Capability 8 — HTTP-for-MCP per Discussion #6 OQ2 closure
("Option C — stdio MCP delegates to daemon"). MCP becomes a
thin adapter that POSTs canonical writes to the daemon's
``POST /writes`` endpoint; daemon owns ReplicationManager + all
state.

This module is the daemon-side dispatcher: a name → handler
registry that turns a wire-level ``{op, args}`` payload into a
``ReplicationManager.write`` call. Handlers know how to construct
the per-adapter closure for each op type.

**Effect-then-interceptor split (Rule 2).** The registry itself is
data; ``register`` is a decorator that mutates module state once
at import time; ``get_handler`` / ``all_ops`` are pure queries.
The handler functions themselves are async effect functions.

**Schema-as-data (Rule 5).** No Pydantic schemas at module level.
Per-op argument validation is handler-internal duck typing for
3.6.0 (#355 OQ2 closure: "formalize to Pydantic schemas as the
surface stabilizes"). The serialization functions (``_serialize_*``)
are factories invoked per-call.

**Migration policy.** D5.1 ships ``create_issue`` as the reference
op; D5.2+ migrate the rest of the write surface in dependency
order (#355 §Migration order).
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable

# An op handler takes the daemon's ReplicationManager + the op args
# dict; returns the WriteResult-equivalent dict for JSON
# serialization. Async because ReplicationManager.write is async.
OpHandler = Callable[[Any, dict], Awaitable[dict]]


_OP_REGISTRY: dict[str, OpHandler] = {}


def register(op_name: str):
    """Decorator: register a write-op handler under ``op_name``.

    Idempotent within a single import — re-registering the same
    name overrides (useful for tests that monkeypatch a handler).
    """
    def deco(fn: OpHandler) -> OpHandler:
        _OP_REGISTRY[op_name] = fn
        return fn
    return deco


def get_handler(op_name: str) -> OpHandler | None:
    """Look up a registered handler. Returns None for unknown ops —
    caller turns this into a 400 response."""
    return _OP_REGISTRY.get(op_name)


def all_ops() -> list[str]:
    """Return all registered op names, sorted. Used by the
    daemon's diagnostics surface."""
    return sorted(_OP_REGISTRY.keys())


# --- Serialization helpers ------------------------------------------------


def _serialize_mirror_warnings(warnings: tuple) -> list[dict]:
    """Convert a tuple of MirrorWarning dataclass instances into the
    JSON-friendly list-of-dicts shape the wire protocol uses."""
    return [
        {
            "platform_id": w.platform_id,
            "operation": w.operation,
            "error_type": w.error_type,
            "error_message": w.error_message,
        }
        for w in warnings
    ]


def _serialize_artifact(artifact) -> Any:
    """Convert a Pydantic adapter type (Issue, Discussion, Comment,
    etc.) to a dict via model_dump. Returns None for None inputs.

    The MCP-side caller deserializes back to the matching Pydantic
    type at the handler boundary — same shape, just round-tripped
    through JSON.
    """
    if artifact is None:
        return None
    if hasattr(artifact, "model_dump"):
        return artifact.model_dump(mode="json")
    # Fallback for plain values (str, int, dict). Adapters return
    # rich types in normal use, but tests sometimes stub primitives.
    return artifact


# --- Op handlers (D5.1: create_issue) -------------------------------------


@register("append_comment")
async def _op_append_comment(replication, args: dict) -> dict:
    """Dispatch an append_comment canonical write (D5.3 / post_turn).

    Args:
        parent_kind: Literal["issue", "discussion"]
        parent_native_id: str — the parent's ref.native_id.
        owner: str
        repo: str
        body: str
        repo_role: str (optional, default "private")

    The daemon reconstructs the parent ``ArtifactRef`` from the
    typed fields + per-platform coords; the adapter dispatches
    to ``add_discussion_comment`` vs ``add_issue_comment`` based
    on ``parent_kind``.

    Returns:
        ``{value: <Comment dict>, mirror_warnings: [...]}``
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    parent_kind = args["parent_kind"]
    parent_native_id = args["parent_native_id"]
    owner = args["owner"]
    repo = args["repo"]
    body = args["body"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        parent_ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=parent_native_id,
            kind=parent_kind,
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.append_comment(parent_ref, body)

    write_result = await replication.write(
        operation_name="append_comment",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("create_discussion")
async def _op_create_discussion(replication, args: dict) -> dict:
    """Dispatch a create_discussion canonical write (D5.4).

    Args:
        owner: str
        repo: str
        title: str
        body: str
        category: str — Discussion category name; each adapter
            resolves to its own backend representation (GitHub
            GraphQL category node ID via per-adapter
            ``_discussion_categories`` map; Forgejo / GitLab
            encode as ``category:*`` labels per OQ1 design;
            LocalStore writes the name into meta.json).
        repo_role: str (optional, default "private")

    Returns:
        ``{value: <Discussion dict>, mirror_warnings: [...]}``
    """
    title = args["title"]
    body = args["body"]
    category = args["category"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        return await adapter.create_discussion(
            owner=c_owner or owner,
            repo=c_repo or repo,
            title=title,
            body=body,
            category=category,
        )

    write_result = await replication.write(
        operation_name="create_discussion",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_issue_body")
async def _op_update_issue_body(replication, args: dict) -> dict:
    """Dispatch an update_issue_body canonical write (D5.5).

    Args:
        native_id: str — issue ref native_id (``issues/<n>``).
        owner: str
        repo: str
        body: str — new body text.
        force: bool — bypass size guardrail.
        repo_role: str (optional, default "private")

    Returns ``{value: None, mirror_warnings: [...]}`` — the
    underlying adapter method returns None on success.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    body = args["body"]
    force = args.get("force", False)
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.update_issue_body(ref, body, force=force)

    write_result = await replication.write(
        operation_name="update_issue_body",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_issue_milestone")
async def _op_update_issue_milestone(replication, args: dict) -> dict:
    """(#388, 3.9.0 D5) Dispatch an update_issue_milestone canonical write.

    Args:
        native_id: str — issue ref native_id (``issues/<n>``).
        owner: str
        repo: str
        milestone_title: str | None — None clears the milestone.
        repo_role: str (optional, default "private")

    Returns ``{value: None, mirror_warnings: [...]}`` — the
    underlying adapter method returns None on success.

    Closes the meta-bypass that surfaced during 3.9.0 planning:
    queueing Issues onto a milestone required direct meta.json edits
    because no MCP / daemon dispatch existed for milestone mutation.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    milestone_title = args.get("milestone_title")
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.update_issue_milestone(ref, milestone_title)

    write_result = await replication.write(
        operation_name="update_issue_milestone",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("update_discussion_body")
async def _op_update_discussion_body(replication, args: dict) -> dict:
    """Dispatch an update_discussion_body canonical write (D5.5).

    Mirrors ``update_issue_body`` but ref.kind = "discussion".
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    body = args["body"]
    force = args.get("force", False)
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="discussion",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.update_discussion_body(ref, body, force=force)

    write_result = await replication.write(
        operation_name="update_discussion_body",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("close_issue")
async def _op_close_issue(replication, args: dict) -> dict:
    """Dispatch a close_issue canonical write (D5.6).

    Args:
        native_id: str — issue ref native_id.
        owner: str
        repo: str
        state_reason: str — typically "completed" / "not_planned".
        repo_role: str (optional, default "private")

    Returns ``{value: <Issue dict>, mirror_warnings: [...]}`` —
    the closed Issue's post-close state (Phase C2 contract).
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    state_reason = args["state_reason"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.close_issue(ref, state_reason=state_reason)

    write_result = await replication.write(
        operation_name="close_issue",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("mark_answer")
async def _op_mark_answer(replication, args: dict) -> dict:
    """Dispatch a mark_answer canonical write (D5.6).

    Args:
        native_id: str — comment ref native_id.
        owner: str
        repo: str
        repo_role: str (optional, default "private")

    Returns ``{value: None, mirror_warnings: [...]}``. Adapters
    without a Discussion-mark-answer surface raise
    NotImplementedError → daemon returns 500 → MCP turns it into
    DaemonUnavailableError (caught by the dispatch layer per
    #355 / D5.3 wrapping).
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        comment_ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="comment",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.mark_answer(comment_ref)

    write_result = await replication.write(
        operation_name="mark_answer",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("create_issue")
async def _op_create_issue(replication, args: dict) -> dict:
    """Dispatch a create_issue canonical write.

    Args (all required unless noted):
        owner: str — repo owner.
        repo: str — repo name.
        title: str
        body: str
        labels: list[str] (optional, default empty)
        milestone: str | None (optional)
        repo_role: str (optional, default "private") — for
            per-platform coord resolution per #296.

    Returns:
        ``{value: <Issue dict>, mirror_warnings: [...]}``

    The daemon's ReplicationManager handles canonical-first write
    + mirror fan-out + warning accumulation per the existing
    contract; this handler is the thin shim that constructs the
    op closure.
    """
    title = args["title"]
    body = args["body"]
    labels = list(args.get("labels", []))
    milestone = args.get("milestone")
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        owner, repo = coords
        return await adapter.create_issue(
            owner=owner,
            repo=repo,
            title=title,
            body=body,
            labels=labels,
            milestone=milestone,
        )

    write_result = await replication.write(
        operation_name="create_issue",
        op=op,
        repo_role=repo_role,
    )
    return {
        "value": _serialize_artifact(write_result.value),
        "mirror_warnings": _serialize_mirror_warnings(
            write_result.mirror_warnings,
        ),
    }


@register("attach_to_project_board")
async def _op_attach_to_project_board(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8 carryover) Attach an Issue to the configured
    project board on whichever replication adapter supports project
    boards (forgejo #10 / 3.4.0).

    Pre-D8 the MCP-side helper `_attach_to_project_board_if_supported`
    walked `ctx.replication.entries()` directly. This op moves the
    walk daemon-side so the MCP can delete its own ReplicationManager.

    Args:
        board_id: str — the configured project board's node ID.
        native_id: str — the Issue's ref.native_id.
        owner: str
        repo: str
        kind: str (default "issue")

    Returns:
        ``{value: <project_item_id>, mirror_warnings: []}`` —
        ``value`` is the empty string on no-op (no project_board
        configured, no adapter supports project_boards, or every
        supporting adapter raised ForgeError per the 3.4.2 fix).
        Mirror_warnings is always empty since this isn't a
        replication.write — single canonical adapter on a probe
        chain, not a fan-out.
    """
    from forge_manager_mcp.adapters.errors import ForgeError
    from forge_manager_mcp.adapters.types import ArtifactRef

    board_id = args.get("board_id")
    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    kind = args.get("kind", "issue")

    if not board_id:
        return {"value": "", "mirror_warnings": []}

    for _platform_id, adapter in replication.entries():
        if not getattr(adapter, "has_project_boards", False):
            continue
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind=kind,
            owner=owner,
            repo=repo,
            number=None,
        )
        try:
            project_item_id = await adapter.add_to_project_board(
                board_id=board_id, ref=ref,
            )
            return {"value": project_item_id, "mirror_warnings": []}
        except ForgeError:
            # Per 3.4.2 fix: any ForgeError (Unavailable / HTTP 4xx /
            # validation / backend-specific subclass) falls through to
            # the next adapter; if no adapter succeeds, return "" so
            # the caller treats it as a clean no-op.
            continue

    return {"value": "", "mirror_warnings": []}


@register("move_project_item_to_column")
async def _op_move_project_item_to_column(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8.8 carryover) Composite project-board move op.

    Encapsulates the 3 adapter calls the MCP-side ``move_project_item``
    handler used to make: walk entries() for has_project_boards →
    optional get_project_status_field (if status_options not pre-
    cached) → get_project_item_id → move_project_item. Pre-D8.8 the
    handler walked `ctx.replication.entries()` directly; this op
    moves the walk + the per-adapter sequence daemon-side so the
    MCP can delete its own ReplicationManager.

    Args:
        board_id: str — project board node ID.
        column_name: str — target Status column name (e.g. "Done").
        native_id: str — Issue's ref.native_id.
        owner: str
        repo: str
        kind: str (default "issue")
        status_field_id: str | None — pre-cached field ID; when
            None or empty, the daemon fetches via
            get_project_status_field.
        status_options: dict | None — pre-cached
            ``{column_name: option_id}`` map; same fetch-when-None
            semantics as status_field_id.

    Returns:
        ``{value: <success_message>, mirror_warnings: []}`` on
        success — value is e.g. "Moved to Done.". On no-supporting-
        adapter / unknown-column / per-adapter failure, returns
        ``{value: "", error: <message>}`` so the MCP can surface
        the structured error envelope to Claude.
    """
    from forge_manager_mcp.adapters.errors import ForgeError
    from forge_manager_mcp.adapters.types import ArtifactRef

    board_id = args["board_id"]
    column_name = args["column_name"]
    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    kind = args.get("kind", "issue")
    status_field_id = args.get("status_field_id")
    status_options = args.get("status_options") or {}

    adapter = None
    for _platform_id, candidate in replication.entries():
        if getattr(candidate, "has_project_boards", False):
            adapter = candidate
            break
    if adapter is None:
        return {
            "value": "",
            "error": (
                "move_project_item_to_column: no configured platform "
                "supports project boards. GitHub is the only backend "
                "with a live impl today; Forgejo / GitLab / LocalStore "
                "raise NotImplementedError on the project-board "
                "surface."
            ),
            "mirror_warnings": [],
        }

    # Resolve column → option_id, fetching the field map if not pre-
    # cached. Cache miss is the normal path on first move per session;
    # the MCP-side board config carries cached values for re-use.
    if not status_field_id or not status_options:
        try:
            field_info = await adapter.get_project_status_field(
                board_id=board_id,
            )
        except ForgeError as exc:
            return {
                "value": "",
                "error": (
                    f"get_project_status_field failed: {type(exc).__name__}: "
                    f"{exc}"
                ),
                "mirror_warnings": [],
            }
        status_field_id = field_info["field_id"]
        status_options = field_info["options"]

    option_id = status_options.get(column_name)
    if not option_id:
        return {
            "value": "",
            "error": f"Column {column_name!r} not found on board.",
            "mirror_warnings": [],
        }

    ref = ArtifactRef(
        platform_id=adapter.platform_id,
        native_id=native_id,
        kind=kind,
        owner=owner,
        repo=repo,
        number=None,
    )
    try:
        project_item_id = await adapter.get_project_item_id(
            ref=ref, board_id=board_id,
        )
        await adapter.move_project_item(
            board_id=board_id,
            item_id=project_item_id,
            status_field_id=status_field_id,
            option_id=option_id,
        )
    except ForgeError as exc:
        return {
            "value": "",
            "error": (
                f"project-board move failed: {type(exc).__name__}: {exc}"
            ),
            "mirror_warnings": [],
        }
    return {
        "value": f"Moved to {column_name}.",
        "mirror_warnings": [],
    }


@register("replay_pending_writes")
async def _op_replay_pending_writes(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8.10 carryover) Daemon-side drain of the
    ReplicationManager's per-adapter pending_writes queues.

    Pre-D8.10 the MCP-side `replay_pending` handler called
    `ctx.replication.replay_pending_writes()` directly on its own
    ReplicationManager. Post-D8.10 the daemon owns the drain — its
    ReplicationManager is the one that accumulated the pending
    writes via the dispatch_write path (3.6.0 D5).

    Args: none (replication.replay_pending_writes takes none).

    Returns:
        ``{value: <per-platform-report-dict>, mirror_warnings: []}``
        — value mirrors the existing replay_pending_writes return
        shape: ``{platform_id: {"replayed": N, "still_pending": M,
        "errors": [...]}}``.
    """
    report = await replication.replay_pending_writes()
    return {"value": report, "mirror_warnings": []}


@register("record_session_event")
async def _op_record_session_event(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8.11 carryover) Record a session-lifecycle event
    on the canonical adapter's session-event surface.

    Pre-D8.11 the MCP-side `open_session` / `close_session` handlers
    fetched `ctx.replication.canonical()` directly and called
    `record_session_event` against the adapter. Post-D8.11 the
    daemon owns the canonical access; the handler just dispatches.

    Args:
        session_id: str
        event: str ("opened" or "closed")
        body: str (event payload — timestamp + skill version for
            "opened"; close summary for "closed")

    Behavior:
        - Probes the canonical adapter for ``has_session_event_
          surface``. Only LocalStoreAdapter has this surface today
          (#270 native session-lock); other backends encode session
          events as Discussion comments via add_comment.
        - When the canonical surface is unavailable, returns a
          structured no-op envelope so the MCP-side handler can
          surface "skipped" rather than treating it as an error.

    Returns:
        ``{value: <event_dict>, mirror_warnings: []}`` on success
        (event_dict is the recorded SessionEvent's model_dump).
        ``{value: None, "skipped_reason": <str>, mirror_warnings: []}``
        when the canonical adapter doesn't support the surface.
    """
    session_id = args["session_id"]
    event = args["event"]
    body = args.get("body", "")

    canonical = replication.canonical()
    if not getattr(canonical, "has_session_event_surface", False):
        return {
            "value": None,
            "skipped_reason": (
                f"canonical adapter platform_id="
                f"{canonical.platform_id!r} has "
                "has_session_event_surface=False; session events "
                "encode as Discussion comments via the legacy path."
            ),
            "mirror_warnings": [],
        }

    try:
        recorded = await canonical.record_session_event(
            session_id=session_id, event=event, body=body,
        )
    except Exception as exc:
        return {
            "value": None,
            "error": (
                f"{canonical.platform_id}: record_session_event "
                f"failed: {type(exc).__name__}: {exc}"
            ),
            "mirror_warnings": [],
        }

    if hasattr(recorded, "model_dump"):
        return {
            "value": recorded.model_dump(mode="json"),
            "mirror_warnings": [],
        }
    return {"value": recorded, "mirror_warnings": []}
