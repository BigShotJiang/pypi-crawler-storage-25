"""Daemon startup whoami probe (#378 / 3.8.1 D2).

After the daemon's ReplicationManager is constructed (and any
persisted #377 state rehydrated), fire a per-adapter whoami probe
in parallel:

  * Skip canonical (LocalStoreAdapter — no auth surface).
  * Skip PAUSED adapters (operator paused → respect intent).
  * Per-adapter timeout default 3.0s; total bounded by
    ``max(per-adapter)`` via ``asyncio.gather``.
  * Failure synthesizes an HTTP-status-bearing exception that
    routes through ``is_forge_unavailable`` → DEGRADED.
  * Probe success on a #377-persisted-DEGRADED adapter promotes
    back to HEALTHY (probe authoritative over stale persisted state).

D1 (#377) fixes "state lost on restart"; this fixes "state never
set in this run because no qualifying op has fanned out yet" — they
are paired and complementary.

Reuses ``daemon/credential_test.py``'s per-platform whoami helpers
(shipped 3.8.0 D6/F as the building blocks for the
``POST /credentials/{id}/test`` UI surface).
"""
from __future__ import annotations

import asyncio
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from forge_manager_mcp.replication.manager import ReplicationManager


DEFAULT_PROBE_TIMEOUT = 3.0
"""Per-adapter timeout in seconds. Bounded so a stuck remote can't
delay the daemon's first useful response window. Overridden by
``forge-config.json.daemon.startup_probe_timeout`` when set."""


_PLATFORM_ENV_VAR: dict[str, str] = {
    "github": "GITHUB_TOKEN",
    "codeberg": "CODEBERG_TOKEN",
    "forgejo": "FORGEJO_TOKEN",
    "gitlab": "GITLAB_TOKEN",
}


class StartupProbeError(Exception):
    """Synthesized error from the startup probe. Carries an HTTP
    status code (when the probe got a real response) so
    ``is_forge_unavailable`` classifies HTTP 401/403/etc. as
    Unavailable and the manager transitions DEGRADED."""

    def __init__(self, message: str, *, status_code: int | None = None):
        self.status_code = status_code
        super().__init__(message)


def _resolve_token(platform_id: str) -> str:
    """Read the token for ``platform_id`` from os.environ.

    Daemon's ``_load_and_populate_credentials`` runs before this
    module is invoked so daemon-managed encrypted tokens have
    already landed in env vars. Empty string when no token is
    available.
    """
    env_var = _PLATFORM_ENV_VAR.get(platform_id, "")
    if not env_var:
        return ""
    return os.environ.get(env_var, "")


def _status_code_from_error(message: str) -> int | None:
    """Best-effort extract an HTTP status code from a
    ``test_credential`` error string.

    ``test_credential`` returns ``error="HTTP 403"`` for clear API
    responses and ``error="<ExceptionType>: <details>"`` for client-
    side issues. The HTTP-prefixed shape parses cleanly; the
    exception-prefixed shape returns None (no status to classify
    on; the manager falls through to a non-Unavailable record-only
    path).
    """
    if message.startswith("HTTP "):
        try:
            return int(message.split(" ", 1)[1].split()[0])
        except (ValueError, IndexError):
            return None
    return None


async def _probe_one(platform_id: str, *, timeout: float) -> dict:
    """Probe one adapter. Returns ``test_credential``'s envelope
    plus a synthetic timeout case. Never raises — every failure
    surfaces as ``{ok: False, error: ...}``."""
    from .credential_test import test_credential
    token = _resolve_token(platform_id)
    if not token and platform_id != "local":
        return {
            "ok": False, "platform_id": platform_id,
            "error": "no token available in environment",
        }
    try:
        return await asyncio.wait_for(
            test_credential(platform_id, token), timeout=timeout,
        )
    except asyncio.TimeoutError:
        return {
            "ok": False, "platform_id": platform_id,
            "error": f"probe timeout after {timeout}s",
        }


async def run_startup_probe(
    replication: "ReplicationManager",
    *,
    timeout: float = DEFAULT_PROBE_TIMEOUT,
) -> None:
    """Fire whoami probes against every non-canonical, non-PAUSED
    adapter in parallel. Update each entry's state based on outcome.

    Best-effort throughout — outer exceptions never propagate; the
    ``replication.write/.read`` paths still operate on whatever
    state exists if the probe fails entirely. The next
    reconciliation cycle (#333) will eventually catch up.

    Probe success on a DEGRADED entry (rehydrated from #377)
    promotes back to HEALTHY — the fresh probe is authoritative
    over a stale persisted record.
    """
    from forge_manager_mcp.replication.manager import AdapterState

    candidates = []
    for entry in replication._entries[1:]:  # skip canonical
        if entry.state == AdapterState.PAUSED:
            continue
        candidates.append(entry)
    if not candidates:
        return

    async def _probe_entry(entry):
        result = await _probe_one(entry.platform_id, timeout=timeout)
        return entry, result

    results = await asyncio.gather(
        *(_probe_entry(e) for e in candidates),
        return_exceptions=True,
    )

    for outcome in results:
        if isinstance(outcome, BaseException):
            # asyncio.gather wrapper failure — extraordinarily rare
            # since _probe_entry's body never raises. Skip silently.
            continue
        entry, result = outcome
        if result.get("ok"):
            if entry.state == AdapterState.DEGRADED:
                # Fresh probe is authoritative; promote back.
                replication._set_state(entry, AdapterState.HEALTHY)
            continue
        err_msg = result.get("error") or "probe failed"
        status = _status_code_from_error(err_msg)
        exc = StartupProbeError(err_msg, status_code=status)
        if entry.state != AdapterState.DEGRADED:
            replication._set_state(
                entry, AdapterState.DEGRADED, error=exc,
            )
        else:
            # Already DEGRADED from #377 rehydration. Refresh the
            # error message but don't transition (avoids resetting
            # state_changed_at — UI's "DEGRADED since X" stays
            # truthful to the original transition).
            entry.last_error = exc


def is_startup_probe_enabled(config_payload: dict | None) -> bool:
    """Check ``config_payload['daemon']['startup_probe']``.

    Default True. False disables the probe entirely (for operator
    workflows that explicitly want fresh-start-healthy semantics).
    """
    if not isinstance(config_payload, dict):
        return True
    daemon_block = config_payload.get("daemon")
    if not isinstance(daemon_block, dict):
        return True
    raw = daemon_block.get("startup_probe", True)
    return bool(raw)


def get_startup_probe_timeout(config_payload: dict | None) -> float:
    """Read ``config_payload['daemon']['startup_probe_timeout']``,
    defaulting to ``DEFAULT_PROBE_TIMEOUT``."""
    if not isinstance(config_payload, dict):
        return DEFAULT_PROBE_TIMEOUT
    daemon_block = config_payload.get("daemon")
    if not isinstance(daemon_block, dict):
        return DEFAULT_PROBE_TIMEOUT
    raw = daemon_block.get("startup_probe_timeout")
    if raw is None:
        return DEFAULT_PROBE_TIMEOUT
    try:
        return float(raw)
    except (TypeError, ValueError):
        return DEFAULT_PROBE_TIMEOUT
