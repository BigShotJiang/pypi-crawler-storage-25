"""Daemon-side read dispatcher (Phase D8 / #356 / 3.7.0).

Capability 8 read-path closure. Per #356 the daemon now owns
read-path dispatch alongside writes — `ctx.replication` on the MCP
side becomes deletable once every read call site is migrated.

Mirrors `daemon/writes.py`'s registry pattern: a name → handler
map; each handler turns a wire-level ``{op, args}`` into a
``ReplicationManager.read`` call (or a direct adapter probe when
the op is naturally read-only at the canonical layer).

**Effect-then-interceptor split (Rule 2).** The registry is data;
``register`` is a decorator that mutates module state once at
import time; ``get_handler`` / ``all_ops`` are pure queries.
Handlers themselves are async effect functions.

**Schema-as-data (Rule 5).** No Pydantic schemas at module level.
Per-op argument validation is handler-internal duck typing for
3.7.0 (#355 OQ2 closure carries forward — formalize to Pydantic
schemas as the surface stabilizes).

**Migration policy.** D8.1 ships ``get_issue_body`` as the
reference op; D8.2+ migrate the rest of the read surface in
dependency order per #356. Once every read site is migrated and
the carryovers (project-board attach, canonical_platform_id,
replay_pending) are addressed, ``ServerContext.replication``
deletes — closing the 3.6.0 D5 asymmetry.

**Read failover semantics.** Mirrors the existing
``ReplicationManager.read`` shape: try canonical first, then
each healthy mirror in `replication_order` until one succeeds.
``ForgeUnavailable`` from one adapter falls through to the next.
``AllAdaptersFailedError`` propagates as a 500 from the daemon
(MCP-side `dispatch_read` surfaces it as ``DaemonUnavailableError``).

OQ1 closure (per #356): we propagate failures rather than
silently swallowing — read-paths that need graceful degradation
handle it case-by-case at the MCP layer, same as today's
``ctx.replication.read`` pattern.
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable

# An op handler takes the daemon's ReplicationManager + the op args
# dict; returns the JSON-serializable response dict. Async because
# ReplicationManager.read is async.
ReadOpHandler = Callable[[Any, dict], Awaitable[dict]]


_READ_OP_REGISTRY: dict[str, ReadOpHandler] = {}


def register(op_name: str):
    """Decorator: register a read-op handler under ``op_name``.

    Idempotent within a single import — re-registering the same
    name overrides (useful for tests that monkeypatch a handler).
    """
    def deco(fn: ReadOpHandler) -> ReadOpHandler:
        _READ_OP_REGISTRY[op_name] = fn
        return fn
    return deco


def get_handler(op_name: str) -> ReadOpHandler | None:
    """Look up a registered read-op handler. Returns None for
    unknown ops — caller turns this into a 400 response."""
    return _READ_OP_REGISTRY.get(op_name)


def all_ops() -> list[str]:
    """Return all registered read-op names, sorted. Used by the
    daemon's diagnostics surface and the MCP-side
    ``dispatch_read`` to validate ops before posting."""
    return sorted(_READ_OP_REGISTRY.keys())


# --- Op handlers (D8.1: get_issue_body) ----------------------------------


@register("get_issue_body")
async def _op_get_issue_body(replication, args: dict) -> dict:
    """Dispatch a get_issue_body canonical read (D8.1 / #356).

    Args:
        native_id: str — the issue's ref.native_id (canonical-shape
            string for LocalStore; GitHub node ID for GitHub
            canonical, etc.)
        owner: str
        repo: str
        repo_role: str (optional, default "private")

    The daemon reconstructs the ``ArtifactRef`` from the typed
    fields + per-platform coords; the adapter's ``get_issue_body``
    runs against the canonical store first, falling through to
    mirrors per ``ReplicationManager.read`` failover semantics.

    Returns:
        ``{value: <body string>}`` — wire shape mirrors writes'
        ``{value, mirror_warnings}`` envelope without the warnings
        field (reads don't generate warnings; mirror failures fall
        through silently per the failover contract).
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="issue",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.get_issue_body(ref)

    body = await replication.read(
        op=op,
        operation_name="get_issue_body",
        repo_role=repo_role,
    )
    return {"value": body}


@register("list_all_issue_numbers")
async def _op_list_all_issue_numbers(replication, args: dict) -> dict:
    """(#388, 3.9.0 D5) Dispatch a list_all_issue_numbers read.

    Used by ``_audit_toc_drift`` (open_session). Routes through
    ReplicationManager.read so adapter-level failures degrade
    state. Returns ``{value: [int, ...]}``.
    """
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        return await adapter.list_all_issue_numbers(
            c_owner or owner, c_repo or repo,
        )

    numbers = await replication.read(
        op=op,
        operation_name="list_all_issue_numbers",
        repo_role=repo_role,
    )
    return {"value": numbers}


@register("list_all_discussion_numbers")
async def _op_list_all_discussion_numbers(replication, args: dict) -> dict:
    """(#388, 3.9.0 D5) Dispatch a list_all_discussion_numbers read.

    Mirrors list_all_issue_numbers shape.
    """
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        return await adapter.list_all_discussion_numbers(
            c_owner or owner, c_repo or repo,
        )

    numbers = await replication.read(
        op=op,
        operation_name="list_all_discussion_numbers",
        repo_role=repo_role,
    )
    return {"value": numbers}


@register("get_repo_visibility")
async def _op_get_repo_visibility(replication, args: dict) -> dict:
    """(#388, 3.9.0 D5) Dispatch a get_repo_visibility read.

    Used by ``_audit_repo_shape`` (open_session). Routes through
    ReplicationManager.read so adapter-level failures (auth /
    network / 5xx) properly degrade adapter state — fixing the
    pre-#388 bypass that left github degraded with stale state
    even after reads failed.

    Args:
        owner: str
        repo: str
        repo_role: str (optional, default "public")

    Returns:
        ``{value: <"PUBLIC"|"PRIVATE"|"INTERNAL"> or None}``.
    """
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "public")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        return await adapter.get_repo_visibility(
            c_owner or owner, c_repo or repo,
        )

    visibility = await replication.read(
        op=op,
        operation_name="get_repo_visibility",
        repo_role=repo_role,
    )
    return {"value": visibility}


@register("get_file_content")
async def _op_get_file_content(replication, args: dict) -> dict:
    """(#388, 3.9.0 D5) Dispatch a get_file_content read.

    Used by the bypass-path migration for ``_read_latest_skill_version``
    — fetches the upstream skill markdown to compare versions. Routes
    through ``ReplicationManager.read`` so adapter-level failures
    (auth / network / 5xx) properly degrade the adapter's state.

    Args:
        owner: str
        repo: str
        branch: str — e.g., "main"
        path: str — repo-relative file path
        repo_role: str (optional, default "public" since this targets
            a public-mirror read)

    Returns:
        ``{value: <file text or None>}`` — None on a 404-class miss.
    """
    owner = args["owner"]
    repo = args["repo"]
    branch = args["branch"]
    path = args["path"]
    repo_role = args.get("repo_role", "public")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        return await adapter.get_file_content(
            c_owner or owner, c_repo or repo, branch, path,
        )

    body = await replication.read(
        op=op,
        operation_name="get_file_content",
        repo_role=repo_role,
    )
    return {"value": body}


@register("get_discussion_body")
async def _op_get_discussion_body(replication, args: dict) -> dict:
    """Dispatch a get_discussion_body canonical read (D8.2 / #356).

    Args:
        native_id: str — the discussion's ref.native_id (canonical-
            shape string for LocalStore; GitHub node ID for GitHub
            canonical, etc.)
        owner: str
        repo: str
        repo_role: str (optional, default "private")

    Same shape as get_issue_body — reconstructs ``ArtifactRef``
    server-side, dispatches via ``ReplicationManager.read``,
    returns ``{value: <body string>}``.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    native_id = args["native_id"]
    owner = args["owner"]
    repo = args["repo"]
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=native_id,
            kind="discussion",
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.get_discussion_body(ref)

    body = await replication.read(
        op=op,
        operation_name="get_discussion_body",
        repo_role=repo_role,
    )
    return {"value": body}


@register("list_comments")
async def _op_list_comments(replication, args: dict) -> dict:
    """Dispatch a list_comments canonical read (D8.3 / #356).

    Args:
        parent_kind: Literal["issue", "discussion"]
        parent_native_id: str
        owner: str
        repo: str
        limit: int (max comments to return; adapter caps at its own
            implementation limit)
        repo_role: str (optional, default "private")

    Returns:
        ``{value: [<Comment dict>, ...]}`` — Pydantic Comment values
        serialized via model_dump(mode="json") so the MCP-side
        caller can deserialize back to the canonical type or, in
        the case of `get_thread_comments`, reshape to the legacy
        `{comment_id, author, created_at, body}` dict shape.
    """
    from forge_manager_mcp.adapters.types import ArtifactRef

    parent_kind = args["parent_kind"]
    parent_native_id = args["parent_native_id"]
    owner = args["owner"]
    repo = args["repo"]
    limit = int(args.get("limit", 50))
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        parent_ref = ArtifactRef(
            platform_id=adapter.platform_id,
            native_id=parent_native_id,
            kind=parent_kind,
            owner=c_owner or owner,
            repo=c_repo or repo,
            number=None,
        )
        return await adapter.list_comments(parent_ref, limit=limit)

    comments = await replication.read(
        op=op,
        operation_name="list_comments",
        repo_role=repo_role,
    )
    return {
        "value": [
            c.model_dump(mode="json") if hasattr(c, "model_dump") else c
            for c in comments
        ],
    }


@register("search_issues")
async def _op_search_issues(replication, args: dict) -> dict:
    """Dispatch a search_issues canonical read (D8.4 / #356).

    Args:
        owner: str
        repo: str
        query: str (GitHub search syntax; passed through to the
            adapter)
        state: str (optional; "open" / "closed" / etc.)
        labels: list[str] | None (optional)
        milestone: str | None (optional)
        limit: int (max results)
        repo_role: str (optional, default "private")

    Returns:
        ``{value: <SearchResult dict>}`` — the canonical
        SearchResult Pydantic shape carries
        ``{results: [Issue, ...], total_count, query}``;
        serialized via model_dump(mode="json"). The MCP-side caller
        reshapes ``results`` per the legacy SearchIssueHit shape.
    """
    owner = args["owner"]
    repo = args["repo"]
    query = args["query"]
    state = args.get("state")
    labels = args.get("labels")
    milestone = args.get("milestone")
    limit = int(args.get("limit", 50))
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        return await adapter.search_issues(
            owner=c_owner or owner, repo=c_repo or repo,
            query=query, state=state,
            labels=labels, milestone=milestone, limit=limit,
        )

    search_result = await replication.read(
        op=op,
        operation_name="search_issues",
        repo_role=repo_role,
    )
    return {
        "value": (
            search_result.model_dump(mode="json")
            if hasattr(search_result, "model_dump")
            else search_result
        ),
    }


@register("bundle_recover_context")
async def _op_bundle_recover_context(replication, args: dict) -> dict:
    """Dispatch a bundle_recover_context canonical read (D8.5 / #356).

    Composite read aggregating four sub-reads in one round-trip:
    Project TOC body + open Issues + recent Discussions + active
    Milestones. On GitHub the adapter folds these into a single
    aliased GraphQL query (#181); other adapters decompose.

    Args:
        owner: str
        repo: str
        toc_discussion_id: str (project_discussion_id from config)
        since_days: int (days back for "recent")
        issue_limit: int (cap on open Issues)
        repo_role: str (optional, default "private")

    Returns:
        ``{value: <RecoveryBundle dict>}`` — Pydantic
        RecoveryBundle serialized via model_dump(mode="json").
        The MCP-side caller decomposes into the response shape
        per #222 component opt-outs.
    """
    owner = args["owner"]
    repo = args["repo"]
    toc_discussion_id = args["toc_discussion_id"]
    since_days = int(args["since_days"])
    issue_limit = int(args["issue_limit"])
    repo_role = args.get("repo_role", "private")

    async def op(adapter, coords):
        c_owner, c_repo = coords
        return await adapter.bundle_recover_context(
            owner=c_owner or owner, repo=c_repo or repo,
            toc_discussion_id=toc_discussion_id,
            since_days=since_days,
            issue_limit=issue_limit,
        )

    bundle = await replication.read(
        op=op,
        operation_name="bundle_recover_context",
        repo_role=repo_role,
    )
    return {
        "value": (
            bundle.model_dump(mode="json")
            if hasattr(bundle, "model_dump")
            else bundle
        ),
    }


@register("resolve_thread_identifier")
async def _op_resolve_thread_identifier(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8.9 carryover) Resolve `number` → canonical
    `native_id` server-side via the canonical adapter.

    Pre-D8.9 the MCP-side helper `resolve_thread_identifier` took a
    canonical adapter as a positional argument; build.py's ~7 call
    sites passed `ctx.replication.canonical()` directly. Migrating
    the resolution to a daemon op lets the MCP delete the
    `ctx.replication` field.

    Args:
        primary_id: str (may be empty if `number` is set)
        number: int | None
        kind: str ("issue" or "discussion")
        owner: str
        repo: str

    Returns:
        ``{value: <native_id_string>}`` — the canonical native_id
        string. The MCP-side handler uses this verbatim downstream.

    Per the existing helper's contract:
        - Both `primary_id` and `number` set → ValueError raised on
          MCP side BEFORE dispatch (so the daemon never sees this);
          this op assumes the MCP layer has already validated args.
        - Only `primary_id` set → return it as-is (no canonical
          lookup needed).
        - Only `number` set → look up via canonical.get_issue /
          get_discussion, return result.ref.native_id.
    """
    primary_id = args.get("primary_id") or ""
    number = args.get("number")
    kind = args["kind"]
    owner = args["owner"]
    repo = args["repo"]

    if primary_id:
        return {"value": primary_id}

    if number is None:
        return {"value": ""}

    canonical = replication.canonical()
    try:
        number_int = int(number)
    except (TypeError, ValueError):
        raise ValueError(f"number must be an integer, got: {number!r}")

    if kind == "issue":
        issue = await canonical.get_issue(owner, repo, number_int)
        return {"value": issue.ref.native_id}
    if kind == "discussion":
        discussion = await canonical.get_discussion(
            owner, repo, number_int,
        )
        return {"value": discussion.ref.native_id}
    raise ValueError(f"Unsupported kind: {kind!r}")


@register("replication_states_and_pending")
async def _op_replication_states_and_pending(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8.10 carryover) Daemon-side snapshot of per-
    adapter state + pending_writes count.

    Pre-D8.10 the MCP's `_inspect_pending` walked
    `ctx.replication.states()` + `ctx.replication.pending_count()`
    on its own ReplicationManager. Post-D8.10 the daemon owns the
    state machine; this op returns the same shape from the daemon's
    perspective.

    Args: none.

    Returns:
        ``{value: {platform_id: {"state": <state.value>,
        "pending_writes": <count>}}}`` — only entries with non-zero
        pending OR non-healthy state are included (mirrors the
        MCP-side `_inspect_pending` filter so the response shape
        is identical).
    """
    summary: dict[str, dict] = {}
    for platform_id, state in replication.states().items():
        count = replication.pending_count(platform_id)
        if count == 0 and state.value == "healthy":
            continue
        summary[platform_id] = {
            "state": state.value,
            "pending_writes": count,
        }
    return {"value": summary}


@register("read_session_events")
async def _op_read_session_events(replication, args: dict) -> dict:
    """(#356, 3.7.0 D8.11 carryover) Read recent session-lifecycle
    events from the canonical adapter's session-event surface.

    Pre-D8.11 the MCP-side `open_session` handler fetched
    `ctx.replication.canonical()` directly and called
    `read_session_events`. Post-D8.11 the daemon owns the
    canonical access.

    Args:
        last_n: int (max events to return; default 5)

    Behavior:
        - Probes canonical for ``has_session_event_surface``.
          When unavailable, returns empty list with skipped_reason
          so the handler falls back to the GitHub comment read
          (legacy 2.x-compat path).

    Returns:
        ``{value: [<event_dict>, ...]}`` — list of SessionEvent
        Pydantic dicts (via model_dump). Empty list with
        ``skipped_reason`` when the surface is unavailable.
    """
    last_n = int(args.get("last_n", 5))

    canonical = replication.canonical()
    if not getattr(canonical, "has_session_event_surface", False):
        return {
            "value": [],
            "skipped_reason": (
                f"canonical adapter platform_id="
                f"{canonical.platform_id!r} has "
                "has_session_event_surface=False"
            ),
        }

    try:
        events = await canonical.read_session_events(last_n=last_n)
    except Exception as exc:
        return {
            "value": [],
            "error": (
                f"{canonical.platform_id}: read_session_events "
                f"failed: {type(exc).__name__}: {exc}"
            ),
        }

    return {
        "value": [
            e.model_dump(mode="json") if hasattr(e, "model_dump") else e
            for e in events
        ],
    }
