"""Daemon auth middleware (Phase D3b.1 / 3.5.0).

Per the parent RFC #5 §Auth model + #298 sub-RFC §Discovery file
shape: every endpoint except the unauth-allowlist requires
``Authorization: Bearer <auth_token>`` matching the token written
to the discovery file at startup.

The token is 256 bits of entropy (``secrets.token_hex(32)``);
filesystem perms on the discovery file (0o600) keep it from peer
users on the same machine. This is the localhost-only contract.

**Unauth allowlist.** ``/health`` is the sole auth-free endpoint
in D3a/D3b. The MCP daemon-client probes it BEFORE reading the
discovery file's auth_token (e.g., to detect stale-PID daemons or
daemons owned by another tenant). The allowlist is hardcoded —
expanding it requires a code change, not a config change, by
design.

**Per Effects + Async parity (code-design.md):** the middleware's
core decision is pure (token comparison via ``secrets.compare_digest``
to avoid timing attacks); the IO is the request/response wrapping
that Starlette's ASGI contract provides.
"""
from __future__ import annotations

import secrets
from typing import Iterable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response


# Endpoints that bypass the auth check. Format: exact path strings.
# Wildcards / prefix matches are intentionally NOT supported —
# expanding the allowlist should be a deliberate code change.
#
# `/auth/bootstrap` (#334) is auth-free at the middleware layer
# because it's the bootstrap mechanism that hands the token to the
# browser via cookie. The endpoint itself enforces a localhost-
# origin check (`is_localhost_request`) so an external attacker
# can't probe it to harvest the token.
DEFAULT_UNAUTH_PATHS: frozenset[str] = frozenset({
    "/health",
    "/auth/bootstrap",
})


# Cookie name carrying the auth token for browser clients (#334).
# HttpOnly + Secure + SameSite=Strict — see the bootstrap endpoint
# in daemon/http.py for the cookie-set side; the middleware only
# reads + validates.
AUTH_COOKIE_NAME = "auth_token"


def is_localhost_request(request: Request) -> bool:
    """True if the request originated from the local machine.

    Localhost recognition: ``127.0.0.1``, ``::1``, ``localhost``.
    Used by the ``/auth/bootstrap`` endpoint to refuse cross-origin
    or external probes that would otherwise be able to harvest the
    token (since bootstrap is auth-free per the unauth allowlist).

    Pure decision function — extracted so tests can monkeypatch it
    without constructing real ASGI scopes.
    """
    if request.client is None:
        return False
    return request.client.host in {"127.0.0.1", "::1", "localhost"}


class BearerTokenMiddleware(BaseHTTPMiddleware):
    """Require ``Authorization: Bearer <token>`` on every request
    whose path isn't in the unauth allowlist.

    Token comparison uses ``secrets.compare_digest`` — constant-
    time comparison to avoid leaking the token via timing.

    Returns 401 with a structured JSON body on:
      * Missing Authorization header
      * Header doesn't start with ``Bearer ``
      * Bearer token doesn't match the expected token

    The 401 body intentionally does NOT include the expected
    token's prefix or any hint that would help an attacker —
    just a generic ``{"error": "unauthorized"}``.
    """

    def __init__(
        self,
        app,
        *,
        expected_token: str,
        unauth_paths: Iterable[str] = DEFAULT_UNAUTH_PATHS,
    ):
        super().__init__(app)
        if not expected_token:
            raise ValueError("expected_token must be non-empty")
        self._expected_token = expected_token
        self._unauth = frozenset(unauth_paths)

    async def dispatch(
        self, request: Request, call_next,
    ) -> Response:
        if request.url.path in self._unauth:
            return await call_next(request)

        # Static-file mounts use the path's longest-prefix match;
        # check the prefix form too so /assets/foo.js (mounted via
        # the UI's StaticFiles at /) doesn't 401 in the all-or-
        # nothing model. The UI's static surface is the same
        # localhost-only territory as /health, so it's allowed
        # un-auth too. Future endpoint additions stay strict.
        # The UI _itself_ uses the auth_token via cookies once D-UI
        # adds the auth-cookie boot flow (parent RFC #5 OQ6 closure
        # — set HttpOnly Secure cookie via initial GET). Until then
        # the UI's content is treated as open localhost-only data;
        # actual privileged ops still go through API routes that
        # require Bearer.
        if _is_static_path(request.url.path):
            return await call_next(request)

        # #334: accept either Bearer header (MCP / CLI clients) or
        # the auth_token cookie (browser clients post-bootstrap).
        # Both compared via constant-time digest.
        header = request.headers.get("authorization", "")
        if header.startswith("Bearer "):
            token = header[len("Bearer "):]
            if secrets.compare_digest(token, self._expected_token):
                return await call_next(request)

        cookie = request.cookies.get(AUTH_COOKIE_NAME, "")
        if cookie and secrets.compare_digest(cookie, self._expected_token):
            return await call_next(request)

        return _unauth_response()


def _is_static_path(path: str) -> bool:
    """True if the path looks like a static-file request (UI bundle).

    The UI's StaticFiles mount is at /, so anything that isn't a
    known API path is potentially static. Heuristic: API routes
    are /<single-component> with no extension OR known prefixes
    like /api/. UI paths typically end in a file extension or are
    /. The future D3b /api/ prefix consolidation will replace this
    heuristic with a clean prefix split.

    For D3b.1 the explicit allow-set is conservative: /, paths
    with file extensions (`.js`, `.css`, `.html`, `.svg`, `.ico`,
    `.png`, `.json`, `.map`, `.woff`, `.woff2`, `.ttf`).
    """
    if path == "/":
        return True
    # File-extension heuristic — covers static bundle output.
    static_extensions = (
        ".js", ".css", ".html", ".svg", ".ico", ".png", ".jpg",
        ".jpeg", ".json", ".map", ".woff", ".woff2", ".ttf",
        ".webmanifest",
    )
    return any(path.endswith(ext) for ext in static_extensions)


def _unauth_response() -> JSONResponse:
    """Generic 401 response. Body intentionally minimal — no hint
    about WHY the auth failed (missing header vs wrong token)."""
    return JSONResponse(
        {"error": "unauthorized"},
        status_code=401,
        headers={"WWW-Authenticate": "Bearer"},
    )
