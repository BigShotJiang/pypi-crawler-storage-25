"""ReplicationManager-bound effects (Phase D3b.4p / #343).

The handlers' interactions with ReplicationManager — pause /
resume / snapshot — extracted to standalone functions so each is
testable with a stub manager + asserts on call shape, without a
full TestClient round-trip.

Per Rule 2 each effect:
  * takes explicit inputs (no Context coupling)
  * returns explicit outputs OR raises a typed exception
  * has a single call site at the boundary that mocks it cleanly
"""
from __future__ import annotations


class UnknownPlatform(KeyError):
    """Raised by ``pause_backend`` / ``resume_backend`` when the
    platform_id isn't in the manager's adapter list. Distinct
    subclass so handlers can map it to 404 without confusing it
    with other KeyError-raising bugs."""


def pause_backend(replication, platform_id: str) -> None:
    """Set the named backend's state to PAUSED via the manager.

    Raises UnknownPlatform when ``platform_id`` doesn't exist.
    Caller validates ``replication is not None`` before calling.
    """
    try:
        replication.pause(platform_id)
    except KeyError as exc:
        raise UnknownPlatform(platform_id) from exc


def resume_backend(replication, platform_id: str) -> None:
    """Set the named backend's state to HEALTHY (from PAUSED).

    Raises UnknownPlatform when ``platform_id`` doesn't exist.
    Caller validates ``replication is not None`` before calling.
    """
    try:
        replication.resume(platform_id)
    except KeyError as exc:
        raise UnknownPlatform(platform_id) from exc


def list_backends(replication) -> list[dict]:
    """Snapshot the manager's per-adapter state into the wire shape
    used by GET /backends.

    Returns ``[]`` when ``replication is None`` so the handler can
    emit ``{"backends": []}`` without branching.

    The wire shape (state, display_status, canonical, last_error,
    state_changed_at, last_error_at, next_attempt_at) was added in
    #333 / D3b.4g; preserving it verbatim here.
    """
    if replication is None:
        return []
    out: list[dict] = []
    for idx, entry in enumerate(replication._entries):
        state_value = entry.state.value
        out.append({
            "platform_id": entry.platform_id,
            "state": state_value,
            "display_status": state_value,
            "canonical": idx == 0,
            "last_error": (
                str(entry.last_error)
                if entry.last_error is not None else None
            ),
            "state_changed_at": entry.state_changed_at.isoformat(),
            "last_error_at": (
                entry.last_error_at.isoformat()
                if entry.last_error_at is not None else None
            ),
            "next_attempt_at": (
                entry.next_attempt_at.isoformat()
                if entry.next_attempt_at is not None else None
            ),
        })
    return out
