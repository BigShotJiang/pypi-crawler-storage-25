"""Daemon HTTP application (Phase D3a / 3.5.0).

Starlette app exposing the foundation endpoints:

- ``GET /health`` — version, uptime, PID. Used by the MCP daemon-
  client to verify the discovered daemon is alive + the right
  version.

D3b adds the rest of the endpoint surface (``GET /config``,
``POST /writes/{op}``, ``GET /pending``, ``WS /events``) per the
parent RFC #5 §To the MCP server.

**Auth model.** Every endpoint except ``/health`` requires
``Authorization: Bearer <auth_token>`` matching the token written
to the discovery file at startup. ``/health`` is auth-free so the
MCP can probe a daemon's liveness before reading the discovery
file's auth_token (e.g., to detect a stale-PID daemon owned by
another tenant). This is the localhost-only contract described in
parent RFC #5 §To external tools.

**Per Effects + Async parity (code-design.md):** the request
handlers are async (starlette's contract); the underlying state
(start time, version, etc.) is captured at construction and read
without IO. Pure-function payload composition; only the wrapping
``Request → Response`` IO happens via starlette.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.responses import JSONResponse, Response, StreamingResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from forge_manager_mcp.daemon.auth import BearerTokenMiddleware
from forge_manager_mcp.daemon.events import (
    EventBroadcaster,
    stream_events,
)


_MAX_FILE_BYTES = 1_048_576
"""1 MiB cap on /files/content responses. Larger files require an
operator workflow (e.g. download via the canonical store directly);
the JSON-API surface targets human-readable text files."""


# #343: path-resolution + IO effects extracted to daemon/effects/.
# Re-exported here for any external callers that imported the
# legacy name; new code calls effects/files.py directly.
def _resolve_files_path(replication, rel: str):
    from forge_manager_mcp.daemon.effects.files import resolve_path
    target, err = resolve_path(replication, rel)
    if err is None:
        return target, None
    # Pre-#343 callers used a single (path, error_msg) tuple where
    # error_msg was a string. Map (status_code, msg) → msg for
    # back-compat. Tests covering the legacy shape stay green.
    return None, err[1]


# Phase D-UI / 3.5.0. The daemon serves the SolidJS app shell from
# ``ui/dist/`` when present. Resolution order:
#   1. ``$FORGE_MANAGER_UI_DIST`` env var (operator override)
#   2. ``<package-root>/ui_dist/`` (installed-wheel layout — D-UI.3
#      Bazel-hermetic build will populate this in the wheel)
#   3. ``<repo-root>/ui/dist/`` (dev-tree layout — operator runs
#      ``cd ui && pnpm build`` to populate this)
# Returns None if no dist tree is found; the daemon then serves
# only ``/health`` + future API routes without a UI.
def resolve_ui_dist() -> Path | None:
    """Resolve the UI dist directory, or None if not present."""
    override = os.environ.get("FORGE_MANAGER_UI_DIST")
    if override:
        path = Path(override)
        if path.is_dir() and (path / "index.html").is_file():
            return path
        return None

    # Installed-wheel layout (D-UI.3 will produce this).
    package_root = Path(__file__).resolve().parent.parent
    in_package = package_root / "ui_dist"
    if in_package.is_dir() and (in_package / "index.html").is_file():
        return in_package

    # Dev-tree layout: from src/forge_manager_mcp/daemon/http.py walk
    # up to mcp-server/ (3 levels: daemon/ → forge_manager_mcp/ →
    # src/ → mcp-server/) and look at ui/dist/. (D7.1 / 3.6.0:
    # ui/ moved from repo-root to mcp-server/ui/ so it lives inside
    # the Bazel workspace.)
    mcp_server_root = package_root.parent.parent
    in_repo = mcp_server_root / "ui" / "dist"
    if in_repo.is_dir() and (in_repo / "index.html").is_file():
        return in_repo

    return None


def make_app(
    *,
    version: str,
    auth_token: str,
    started_at: datetime | None = None,
    ui_dist: Path | None = None,
    broadcaster: EventBroadcaster | None = None,
    config_payload: dict | None = None,
    config_load_error: str | None = None,
    replication=None,
    state_dir: Path | None = None,
    platform_ids: list[str] | None = None,
    alert_log=None,
    action_log_con=None,
    project_dir: Path | None = None,
) -> Starlette:
    """Construct the daemon's HTTP application.

    Pure factory — captures the version + auth_token + start time
    in the route closures; no module-level state. Each call returns
    a fresh Starlette instance, so tests can construct multiple
    independent apps without interference.

    ``started_at`` defaults to ``datetime.now(timezone.utc)`` when
    omitted. Tests pass an explicit value to make uptime
    deterministic.

    ``ui_dist`` is the explicit dist-tree path. When None, the
    daemon serves only ``/health`` + future API routes — the
    factory does NOT auto-resolve. Auto-resolution happens in
    ``daemon/main.py`` so tests get a deterministic surface (pass
    ``ui_dist=None`` to keep the static mount off; pass an
    explicit path to enable it). When set, the daemon mounts the
    dist tree at ``/`` so ``http://127.0.0.1:<port>/`` returns the
    SolidJS app shell.
    """
    if started_at is None:
        started_at = datetime.now(timezone.utc)
    if broadcaster is None:
        broadcaster = EventBroadcaster()

    pid = os.getpid()

    async def health(request) -> JSONResponse:
        """Auth-free liveness probe. Returns version + uptime + PID.

        The MCP daemon-client uses this to:
        - Confirm the discovered daemon is alive (vs stale-PID).
        - Confirm version match between MCP and daemon (mismatch
          triggers graceful daemon restart per RFC #5 §Lifecycle).
        """
        now = datetime.now(timezone.utc)
        uptime = (now - started_at).total_seconds()
        payload: dict[str, Any] = {
            "version": version,
            "pid": pid,
            "started_at": started_at.isoformat(),
            "uptime_seconds": uptime,
        }
        return JSONResponse(payload)

    async def whoami(request) -> JSONResponse:
        """Auth-required minimal endpoint (D3b.1).

        Returns the requesting client's effective auth state. This
        endpoint exists primarily as a 200 target for end-to-end
        auth tests and as the simplest auth-required handler shape
        for D3b.4+ to clone. Will be replaced or extended by /config
        in D3b.3.
        """
        return JSONResponse({"authenticated": True})

    async def config(request) -> JSONResponse:
        """Resolved GithubConfig (Phase D3b.3 / 3.5.0).

        Returns ``{"loaded": True, "config": {...}}`` when the
        daemon was started with ``--project-dir`` and load_config
        succeeded; otherwise ``{"loaded": False, "reason": "..."}``.

        Per #299 sub-RFC closure (D0): 3.5.0 ships read-only —
        write surface (PATCH /config/backends/{id}) is 3.6.0+.
        The shared loader code path between daemon and MCP per
        #299 OQ6 closure means both processes parse the same
        forge-config.json with the same Pydantic model; this
        endpoint exposes the daemon's parsed result.
        """
        if config_payload is None:
            return JSONResponse({
                "loaded": False,
                "reason": (
                    config_load_error
                    or "no --project-dir passed; daemon has no config"
                ),
            })
        return JSONResponse({"loaded": True, "config": config_payload})

    async def backends(request) -> JSONResponse:
        """List configured backends + per-adapter state (Phase D3b.4
        / Capability 1 read surface; #333 timestamp extensions).

        Returns ``{"backends": [...]}`` where each entry is::

            {
              platform_id, state, display_status, canonical,
              last_error, state_changed_at, last_error_at,
              next_attempt_at,
            }

        - ``platform_id`` — adapter's identifier (e.g., ``local``,
          ``github``, ``codeberg``)
        - ``state`` — raw AdapterState: ``healthy`` / ``degraded`` /
          ``reconciling`` / ``paused``
        - ``display_status`` — same set as ``state`` for D3b.4g;
          allows future shape changes without breaking UI conditional
          rendering (UI can switch on display_status alone)
        - ``canonical`` — true for the first entry (the
          replication-order canonical adapter)
        - ``last_error`` — string of the most recent error if any,
          else None
        - ``state_changed_at`` — ISO-8601 UTC; when ``state`` last
          transitioned (#333). UI renders relative-time + absolute.
        - ``last_error_at`` — ISO-8601 UTC; when ``last_error`` was
          recorded; None when error is None
        - ``next_attempt_at`` — ISO-8601 UTC; when the manager's
          next reconciliation attempt is expected; None for HEALTHY
          / PAUSED

        When the daemon was started without ``--project-dir``, or
        config loading failed, returns ``{"backends": []}``.
        """
        # #343: snapshot effect lives in effects/replication_state.py
        # so the handler is a one-liner over the standalone-testable
        # effect.
        from forge_manager_mcp.daemon.effects.replication_state import (
            list_backends,
        )
        return JSONResponse({"backends": list_backends(replication)})

    async def files_tree(request) -> JSONResponse:
        """Directory listing under the canonical store (Phase D3b.4d
        / capability 4 read surface).

        Query string: ``?path=<relative-path>`` (default empty =
        canonical store root).

        Returns ``{"path": "<resolved>", "entries": [...]}`` where
        each entry is ``{"name": "<basename>", "type": "file|dir",
        "size": <bytes-or-null>}``. Sorted alphabetically with dirs
        first.

        404 when no LocalStore canonical is configured (the daemon
        was started without --project-dir, or the canonical adapter
        is a remote backend with no filesystem path).

        400 on path traversal attempts (`..` components, absolute
        paths, anything that resolves outside the canonical store
        root).
        """
        # #343: path-resolution + listing effects in effects/files.py.
        # 3.7.0 D5 / #351: optional ?repo=<id> selects which repo's
        # tree to walk; absent defaults to canonical store (back-compat).
        from forge_manager_mcp.daemon.effects.files import (
            list_directory, resolve_path,
        )
        rel = request.query_params.get("path", "")
        repo_id = request.query_params.get("repo") or None
        target, err = resolve_path(
            replication, rel,
            repo_id=repo_id,
            project_dir=project_dir,
            config_payload=config_payload,
        )
        if err is not None:
            return JSONResponse({"error": err[1]}, status_code=err[0])
        entries, err = list_directory(target)
        if err is not None:
            return JSONResponse({"error": err[1]}, status_code=err[0])
        return JSONResponse({
            "path": rel, "repo": repo_id, "entries": entries,
        })

    async def files_content(request) -> JSONResponse:
        """File contents (Phase D3b.4d / capability 4 read surface).

        Query string: ``?path=<relative-path>`` (required, non-empty).

        Returns ``{"path": "<resolved>", "content": "<text>",
        "size": <bytes>}``. Content is decoded as UTF-8; binary or
        non-UTF-8 files return 415.

        Same path-traversal validation as ``/files/tree``. The 1MB
        max-content guard prevents an accidental huge-file load
        from blocking the response thread; over-cap returns 413.
        """
        # #343: resolution + read effects in effects/files.py.
        # 3.7.0 D5 / #351: optional ?repo=<id> selects which repo's
        # tree to read from; absent defaults to canonical (back-compat).
        from forge_manager_mcp.daemon.effects.files import (
            read_text_file, resolve_path,
        )
        rel = request.query_params.get("path", "")
        repo_id = request.query_params.get("repo") or None
        if not rel:
            return JSONResponse(
                {"error": "path query parameter is required"},
                status_code=400,
            )
        target, err = resolve_path(
            replication, rel,
            repo_id=repo_id,
            project_dir=project_dir,
            config_payload=config_payload,
        )
        if err is not None:
            return JSONResponse({"error": err[1]}, status_code=err[0])
        result, err = read_text_file(target)
        if err is not None:
            return JSONResponse({"error": err[1]}, status_code=err[0])
        return JSONResponse({
            "path": rel,
            "repo": repo_id,
            "content": result["content"],
            "size": result["size"],
        })

    async def test_credential_endpoint(request) -> JSONResponse:
        """Pre-save credential test (#366 / 3.8.0 D6 / Theme F).

        Body: ``{"token": "<plaintext>"}``. Validates the token
        against the platform's whoami endpoint. Returns ``{ok,
        platform_id, identity?, error?}``. **The token is not
        persisted** — it lives only in the request body and the
        transient httpx call. Use ``PUT /credentials/{platform_id}``
        to persist after a successful test.

        400 on bad input. Network / auth failures surface as
        ``{ok: false, error: "..."}`` with a 200 status — the
        wizard renders the structured error rather than handling
        HTTP-level exceptions.
        """
        platform_id = request.path_params["platform_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        token = body.get("token", "")
        if not isinstance(token, str) or not token.strip():
            return JSONResponse(
                {"error": "token must be a non-empty string"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.credential_test import (
            test_credential,
        )
        result = await test_credential(platform_id, token)
        return JSONResponse(result)

    async def setup_scaffold(request) -> JSONResponse:
        """Run multi-platform scaffold from the wizard
        (#374 / 3.8.0 D3.2 / Discussion #11).

        Body: ``{project_name, description, platforms,
        replication_order}``. Walks every platform with
        ``has_scaffold = True`` and runs ``bootstrap_project``.
        Returns ``{per_platform, pending_manual, skipped}``.

        Local file generation (CLAUDE.md, project-rules.md) deferred
        to D3.6; the daemon endpoint stays focused on cross-backend
        orchestration. The wizard's UX flow is: scaffold → POST /config
        → CLAUDE.md merger.

        400 on bad input. 500 wraps adapter exceptions so the wizard
        sees a structured error rather than a starlette traceback.
        """
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body, dict):
            return JSONResponse(
                {"error": "body must be a JSON object"},
                status_code=400,
            )
        project_name = body.get("project_name", "")
        description = body.get("description", "")
        platforms_in = body.get("platforms", [])
        replication_order = body.get("replication_order", [])
        if not isinstance(platforms_in, list) or not isinstance(
            replication_order, list,
        ):
            return JSONResponse(
                {
                    "error": (
                        "platforms must be a list and replication_order "
                        "must be a list of platform_ids"
                    ),
                },
                status_code=400,
            )
        from forge_manager_mcp.daemon.setup import run_scaffold
        try:
            result = await run_scaffold(
                project_name=project_name,
                description=description,
                platforms=platforms_in,
                replication_order=replication_order,
            )
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        except Exception as exc:
            return JSONResponse(
                {
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                },
                status_code=500,
            )
        return JSONResponse(result)

    async def write_config(request) -> JSONResponse:
        """Write a new forge-config.json (#374 / 3.8.0 D3.1 / Discussion #11).

        Body: full GithubConfig payload (the same shape ``GET /config``
        returns under the ``config`` key). Validates via Pydantic
        before any disk write; rejects malformed payloads with 400.
        Atomic-writes to ``<project_dir>/.claude/forge-config.json``
        — temp file in the same directory + fsync + rename — so a
        partial write can't corrupt the operator's existing config.

        Returns ``{written: true, config: <validated payload>}`` on
        success. The daemon's in-memory ``config_payload`` snapshot
        is updated so subsequent ``GET /config`` calls reflect the
        new state without a daemon restart.

        503 when no ``--project-dir`` was passed (no canonical
        location for the file).
        """
        if project_dir is None:
            return JSONResponse(
                {
                    "error": (
                        "daemon has no --project-dir; "
                        "cannot resolve a forge-config.json path."
                    ),
                },
                status_code=503,
            )
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        if not isinstance(body, dict):
            return JSONResponse(
                {"error": "body must be a JSON object"}, status_code=400,
            )
        try:
            from forge_manager_mcp.models import GithubConfig
            from pydantic import ValidationError
            try:
                validated = GithubConfig.model_validate(body)
            except ValidationError as exc:
                return JSONResponse(
                    {
                        "error": "config validation failed",
                        "details": [
                            {
                                "loc": list(e.get("loc", ())),
                                "msg": e.get("msg", ""),
                                "type": e.get("type", ""),
                            }
                            for e in exc.errors()
                        ],
                    },
                    status_code=400,
                )
        except ImportError:
            return JSONResponse(
                {"error": "config validator unavailable"},
                status_code=503,
            )
        from forge_manager_mcp.daemon.effects.config_write import (
            atomic_write_config,
        )
        target = project_dir / ".claude" / "forge-config.json"
        payload = validated.model_dump(mode="json", exclude_none=True)
        try:
            atomic_write_config(target, payload)
        except OSError as exc:
            return JSONResponse(
                {"error": f"could not write config: {exc}"},
                status_code=500,
            )
        # Refresh the daemon's in-memory snapshot so subsequent reads
        # see the new state without a restart. The closure-captured
        # variable is rebound via the helper-cell pattern; for
        # simplicity we also keep the existing config_payload alive
        # so other endpoints (probe_schema_version, etc.) don't see
        # a None until restart.
        nonlocal config_payload
        config_payload = payload
        return JSONResponse({"written": True, "config": payload})

    async def upgrade_execute(request) -> JSONResponse:
        """Run dry_run / execute / rollback for one upgrade step
        (#373 / 3.8.0 D2.4 / Discussion #12).

        URL: ``POST /upgrade/execute/{step}`` where ``step`` is one
        of the registered ``repair_type`` keys (pipx_upgrade,
        daemon_restart, schema_migration, skill_prose_pull,
        config_patch, claude_md_merge, verify).

        Body: ``{"action": "dry_run" | "execute" | "rollback",
        "ctx": {...}, "prior_state": {...}}``.

        Returns the executor's StepDryRun (for action=dry_run) or
        StepResult (for execute / rollback) as JSON. 400 on unknown
        action / unknown step / malformed body.
        """
        from forge_manager_mcp.upgrade import executors
        step = request.path_params["step"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        action = body.get("action")
        ctx = body.get("ctx", {})
        prior_state = body.get("prior_state")
        if action not in ("dry_run", "execute", "rollback"):
            return JSONResponse(
                {"error": f"unknown action: {action!r}"},
                status_code=400,
            )
        if not isinstance(ctx, dict):
            return JSONResponse(
                {"error": "ctx must be a JSON object"}, status_code=400,
            )
        try:
            ex = executors.get_executor(step)
        except executors.UnknownExecutorError:
            return JSONResponse(
                {"error": f"unknown step: {step!r}"}, status_code=400,
            )
        try:
            if action == "dry_run":
                outcome = ex.dry_run_fn(ctx)
                payload = executors.to_dry_run_dict(outcome)
            elif action == "execute":
                outcome = ex.execute_fn(ctx)
                payload = executors.to_result_dict(outcome)
            else:  # rollback
                outcome = ex.rollback_fn(ctx, prior_state)
                payload = executors.to_result_dict(outcome)
        except Exception as exc:
            return JSONResponse(
                {
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                    "step": step,
                    "action": action,
                },
                status_code=500,
            )
        return JSONResponse(payload)

    async def findings_endpoint(request) -> JSONResponse:
        """Full code-design findings list + per-path index
        (#369 / 3.8.0 D7.1). Sibling of /gates which returns the
        truncated top-10 inside its code_design_status field; this
        endpoint returns the full untruncated list suitable for a
        tree-icon roll-up or a dedicated Findings index view.

        Returns ``{ran_at, scope, findings, by_path, by_rule}``.
        Falls back to ``status: skipped`` shape on any failure
        (matches the status helper's tolerant pattern).
        """
        if project_dir is None:
            return JSONResponse({
                "ran_at": None,
                "scope": "skipped",
                "findings": [],
                "by_path": {},
                "by_rule": {},
                "reason": "daemon has no --project-dir",
            })
        try:
            from forge_manager_mcp.code_design.probe import (
                probe_code_design_findings,
            )
            payload = probe_code_design_findings(project_dir)
            # Normalize paths to project_dir-relative so the UI's
            # tree-sidebar paths (repo-relative) match by_path keys.
            project_root = str(project_dir.resolve())
            prefix = project_root + "/"

            def _norm(p: str) -> str:
                if p.startswith(prefix):
                    return p[len(prefix):]
                return p

            payload["findings"] = [
                {**f, "path": _norm(f["path"])}
                for f in payload.get("findings", [])
            ]
            payload["by_path"] = {
                _norm(k): v for k, v in (payload.get("by_path") or {}).items()
            }
            return JSONResponse(payload)
        except Exception as exc:
            return JSONResponse({
                "ran_at": None,
                "scope": "skipped",
                "findings": [],
                "by_path": {},
                "by_rule": {},
                "reason": f"probe failed: {exc}",
            })

    async def upgrade_status(request) -> JSONResponse:
        """Multi-source drift snapshot for the upgrade wizard
        (#373 / 3.8.0 D2.2 / Discussion #12).

        Aggregates eight drift sources (currently 5 active + 3
        stubbed for D2.x) and returns the wizard's punch-list:

            {
              "drifts": [{source, current, target, status, severity,
                          repair_type, message, recommendation}, ...],
              "summary": {by_status, by_severity, needs_repair},
            }

        Auth-required like the rest of the daemon's API surface.
        """
        from forge_manager_mcp.upgrade import detect
        drifts = detect.aggregate(
            project_dir=project_dir,
            state_dir=state_dir,
            config_payload=config_payload,
        )
        return JSONResponse({
            "drifts": [detect.to_dict(d) for d in drifts],
            "summary": detect.summary(drifts),
        })

    async def gates_endpoint(request) -> JSONResponse:
        """Skill gate + process registry snapshot for the UI's Gates view.

        Reads ``<project_dir>/.claude/skills/forge-manager/gates.yaml``
        and ``processes.yaml`` and returns the parsed registries plus
        a fresh ``code_design_status`` snapshot (same shape that
        ``open_session`` already returns) so the UI can render live
        finding counts per ``code_design.*`` rule.

        ``{"loaded": false, "reason": "..."}`` on missing project_dir
        or YAML files; ``{"loaded": true, "gates": [...], "processes":
        [...], "code_design_status": {...}}`` on success.
        """
        if project_dir is None:
            return JSONResponse({
                "loaded": False,
                "reason": "daemon has no --project-dir",
                "gates": [],
                "processes": [],
                "code_design_status": None,
            })
        skill_dir = project_dir / ".claude" / "skills" / "forge-manager"
        gates_path = skill_dir / "gates.yaml"
        processes_path = skill_dir / "processes.yaml"
        if not gates_path.is_file() or not processes_path.is_file():
            return JSONResponse({
                "loaded": False,
                "reason": (
                    f"skill prose not found at {skill_dir} "
                    "(gates.yaml and/or processes.yaml missing)"
                ),
                "gates": [],
                "processes": [],
                "code_design_status": None,
            })
        try:
            from forge_manager_mcp.gate_registry import (
                load_gates, load_processes,
            )
            gates_reg = load_gates(gates_path)
            procs_reg = load_processes(processes_path)
        except Exception as exc:
            return JSONResponse({
                "loaded": False,
                "reason": f"registry parse failed: {exc}",
                "gates": [],
                "processes": [],
                "code_design_status": None,
            })

        gates_payload = [
            {
                "name": g.name,
                "type": g.type,
                "summary": g.summary,
                "default_state": g.default_state,
                "extension_semantics": g.extension_semantics,
                "override_semantics": g.override_semantics,
                "location": g.location,
                "rationale_doc": g.rationale_doc,
                "introduced_in": g.introduced_in,
                "last_changed_in": g.last_changed_in,
                "related": list(g.related),
                "runbook_url": g.runbook_url,
            }
            for g in gates_reg.list_gates()
        ]
        processes_payload = [
            {
                "name": p.name,
                "type": p.type,
                "summary": p.summary,
                "location": p.location,
                "rationale_doc": p.rationale_doc,
                "introduced_in": p.introduced_in,
                "last_changed_in": p.last_changed_in,
                "related_processes": list(p.related_processes),
                "steps": [
                    {
                        "id": s.id,
                        "location": s.location,
                        "gates": list(s.gates),
                    }
                    for s in p.steps
                ],
            }
            for p in procs_reg.list_processes()
        ]
        try:
            from forge_manager_mcp.code_design.probe import (
                probe_code_design_status,
            )
            code_design_status = probe_code_design_status(project_dir)
        except Exception:
            code_design_status = None
        return JSONResponse({
            "loaded": True,
            "gates": gates_payload,
            "processes": processes_payload,
            "code_design_status": code_design_status,
        })

    async def repos(request) -> JSONResponse:
        """Repo enumeration for the per-repo tab strip (3.7.0 D5 / #351).

        Returns ``{"repos": [{id, label, path, kind}, ...]}``. Each
        entry corresponds to a locally-cloned repo in the project's
        scope: docs canonical, code (project_dir), public mirror,
        related repos. Repos with no local clone are omitted (per
        #351 OQ2 closure: skip rather than grey-out).

        Auth-required like /files/*. Returns an empty list when no
        replication / project_dir / config is configured.
        """
        from forge_manager_mcp.daemon.effects.files import enumerate_repos
        return JSONResponse({
            "repos": enumerate_repos(replication, project_dir, config_payload),
        })

    async def pause_backend(request) -> JSONResponse:
        """Operator-driven pause (Phase D3b.4c).

        Sets the backend's state to PAUSED via
        ReplicationManager.pause(). Reads + writes skip the adapter
        until resumed. Returns the new state map for the resumed
        backend.

        404 when no replication is configured (pre-bootstrap mode
        or --project-dir omitted) or when the platform_id doesn't
        match any configured adapter.
        """
        # #343: pause effect in effects/replication_state.py.
        from forge_manager_mcp.daemon.effects.replication_state import (
            UnknownPlatform, pause_backend as _pause_effect,
        )
        platform_id = request.path_params["platform_id"]
        if replication is None:
            return JSONResponse(
                {"error": "no replication manager — daemon started without --project-dir"},
                status_code=404,
            )
        try:
            _pause_effect(replication, platform_id)
        except UnknownPlatform:
            return JSONResponse(
                {"error": f"unknown platform_id: {platform_id}"},
                status_code=404,
            )
        return JSONResponse({"platform_id": platform_id, "state": "paused"})

    async def resume_backend(request) -> JSONResponse:
        """Operator-driven resume (Phase D3b.4c).

        Sets the backend's state to HEALTHY if currently PAUSED;
        no-op otherwise. Returns the resulting state.
        """
        # #343: resume effect in effects/replication_state.py.
        from forge_manager_mcp.daemon.effects.replication_state import (
            UnknownPlatform, resume_backend as _resume_effect,
        )
        platform_id = request.path_params["platform_id"]
        if replication is None:
            return JSONResponse(
                {"error": "no replication manager — daemon started without --project-dir"},
                status_code=404,
            )
        try:
            _resume_effect(replication, platform_id)
        except UnknownPlatform:
            return JSONResponse(
                {"error": f"unknown platform_id: {platform_id}"},
                status_code=404,
            )
        # Look up the resulting state to surface back to the caller.
        new_state = next(
            (e.state.value for e in replication._entries if e.platform_id == platform_id),
            None,
        )
        return JSONResponse({"platform_id": platform_id, "state": new_state})

    async def publish_event(request) -> JSONResponse:
        """Accept a `{event, data}` payload and publish to the
        broadcaster (Phase D3b.4b).

        Auth-required. The MCP is the primary publisher: when an
        MCP-initiated write completes (via the MCP's own
        ReplicationManager), it POSTs an event here so the
        daemon's SSE subscribers (the UI) see it.

        Validation:
        - `event` must be a non-empty string
        - `data` must be a JSON-object (dict)
        - timestamps are server-stamped (clients can't backdate
          events — keeps the SSE timeline coherent)

        400 on validation failure; 200 on publish. Publish is
        always successful from the publisher's perspective —
        slow-subscriber overflow is handled by the broadcaster's
        FIFO-drop semantics, not surfaced to the caller.
        """
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        event_name = body.get("event")
        data = body.get("data", {})
        if not isinstance(event_name, str) or not event_name:
            return JSONResponse(
                {"error": "event must be a non-empty string"},
                status_code=400,
            )
        if not isinstance(data, dict):
            return JSONResponse(
                {"error": "data must be a JSON object"},
                status_code=400,
            )
        # #343: publish effect in effects/events.py.
        from forge_manager_mcp.daemon.effects.events import publish
        subs = publish(broadcaster, event_name, data)

        # (#354 / D4.6) Incremental FTS5 refresh on write.completed
        # events. Best-effort: any failure (no action_log connection,
        # no canonical store path, sqlite error) is swallowed so the
        # canonical write's success isn't masked by a cache-refresh
        # bug. Full rebuild rather than incremental-by-ref because
        # the hook's ``write.completed`` payload doesn't carry the
        # changed-artifact ref today; capability 8 (HTTP-for-MCP)
        # will redesign the write boundary and at that point the ref
        # becomes available for true incremental updates.
        if event_name == "write.completed" and action_log_con is not None:
            docs_root = None
            if replication is not None:
                try:
                    docs_root = replication.canonical_store_path()
                except Exception:
                    docs_root = None
            if docs_root is not None:
                try:
                    # (#386, 3.9.0 D3.3) Use refresh_fts5_for_op when
                    # the event payload carries an operation_name —
                    # rebuilds only the affected FTS5 kind instead
                    # of the full multi-table rebuild. Pre-D3.3 every
                    # canonical write rebuilt all 4 FTS5 tables on a
                    # single-Issue change; post-D3.3, create_issue
                    # touches only issues_fts.
                    op_name = (data or {}).get("operation_name")
                    from forge_manager_mcp.daemon.action_log import (
                        refresh_fts5_for_op,
                    )
                    if op_name is not None:
                        refresh_fts5_for_op(
                            action_log_con, docs_root, op_name,
                            project_root=project_dir,
                        )
                    else:
                        # Backward-compat: payload without operation_name
                        # (legacy publishers) → full rebuild.
                        from forge_manager_mcp.daemon.action_log import (
                            rebuild_fts5,
                        )
                        rebuild_fts5(
                            action_log_con, docs_root,
                            project_root=project_dir,
                        )
                except Exception:
                    pass

        return JSONResponse({"published": True, "subscribers": subs})

    async def events(request) -> StreamingResponse:
        """SSE channel (Phase D3b.2).

        Long-lived ``text/event-stream`` connection. The skeleton
        emits a ``hello`` event on connect + heartbeats every 15s
        of silence. D3b.4+ wires concrete event publishers
        (backend status changes, write completions, backfill
        progress).

        Auth-required per the middleware. Browsers' EventSource
        cannot send custom headers, so the UI's auth-cookie boot
        flow (RFC #5 OQ6) sets a cookie that the middleware
        accepts as an alternative to Bearer; that cookie support
        lands in D-UI's auth-cookie wiring.
        """
        return StreamingResponse(
            stream_events(broadcaster),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",  # disable nginx-style buffering
            },
        )

    async def auth_bootstrap(request):
        """Hand the auth token to a browser client via cookie (#334).

        Auth-free at the middleware layer (in DEFAULT_UNAUTH_PATHS)
        because this IS the bootstrap. Origin-restricted to
        localhost — an external attacker can't reach this endpoint
        to harvest the token.

        Cookie attributes:
        * ``HttpOnly`` — JS in the static bundle can't read it; XSS
          can't exfiltrate the token.
        * ``Secure`` — won't travel over plain HTTP if the daemon
          ever fronts behind TLS. Modern browsers honor Secure on
          plain-HTTP localhost (Chrome / Firefox both treat
          127.0.0.1 + localhost as a secure context).
        * ``SameSite=Strict`` — cross-origin sites can't trigger
          authenticated requests.
        * ``Path=/`` — cookie travels with every request to the
          daemon's surface, including SSE.

        Returns 204 No Content on success; 403 from a non-localhost
        origin.
        """
        from forge_manager_mcp.daemon.auth import (
            AUTH_COOKIE_NAME,
            is_localhost_request,
        )
        if not is_localhost_request(request):
            return JSONResponse(
                {"error": "bootstrap requires localhost origin"},
                status_code=403,
            )
        response = Response(status_code=204)
        response.set_cookie(
            key=AUTH_COOKIE_NAME,
            value=auth_token,
            httponly=True,
            secure=True,
            samesite="strict",
            path="/",
        )
        return response

    async def get_alerts(request) -> JSONResponse:
        """List retained alerts (Phase D3b.4o / #341).

        Query params:
            ``since=<iso-ts>`` — only alerts with timestamp > since
            ``level=<min>`` — minimum severity (info/warning/error/
                critical)
            ``limit=<int>`` — cap on returned entries

        Returns ``{"alerts": [...]}`` newest-first; each entry per
        ``alert_to_dict``. When the daemon has no alert log
        configured (factory called without one), returns
        ``{"alerts": []}`` so the MCP's polling path is graceful.
        """
        if alert_log is None:
            return JSONResponse({"alerts": []})
        from datetime import datetime as _dt
        from forge_manager_mcp.daemon.alerts import alert_to_dict

        since_raw = request.query_params.get("since")
        level = request.query_params.get("level")
        limit_raw = request.query_params.get("limit")
        since = None
        if since_raw:
            try:
                since = _dt.fromisoformat(since_raw)
            except ValueError:
                return JSONResponse(
                    {"error": f"invalid since timestamp: {since_raw!r}"},
                    status_code=400,
                )
        limit = None
        if limit_raw:
            try:
                limit = int(limit_raw)
                if limit <= 0:
                    raise ValueError("limit must be positive")
            except ValueError:
                return JSONResponse(
                    {"error": f"invalid limit: {limit_raw!r}"},
                    status_code=400,
                )
        entries = alert_log.recent(
            since=since, level_at_least=level, limit=limit,
        )
        return JSONResponse({
            "alerts": [alert_to_dict(a) for a in entries],
        })

    async def post_alert(request) -> JSONResponse:
        """Accept an MCP-published alert (Phase D3b.4o / #341).

        The MCP uses this to surface its own concerns (version
        mismatch detected at probe time, daemon-spawn fallthrough)
        into the same retained log the UI sees. Auth-required.

        Body: JSON with the alert_to_dict shape. ``alert_from_dict``
        tolerates partial payloads — missing level → "info",
        missing timestamp → now.

        Dual-publishes to the broadcaster (live) + log (retained).
        """
        if alert_log is None:
            return JSONResponse(
                {"error": "daemon has no alert log"},
                status_code=503,
            )
        try:
            payload = await request.json()
        except Exception as exc:
            return JSONResponse(
                {"error": f"invalid JSON: {exc}"},
                status_code=400,
            )
        if not isinstance(payload, dict):
            return JSONResponse(
                {"error": "body must be a JSON object"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.alerts import alert_from_dict
        from forge_manager_mcp.daemon.events import publish_alert
        alert = alert_from_dict(payload)
        publish_alert(broadcaster, alert_log, alert)
        return JSONResponse({"published": True})

    async def credentials(request) -> JSONResponse:
        """Per-platform credential diagnostics (Phase D3b.4e / #331).

        Returns ``{"credentials": [{platform_id, has_credential,
        source}, ...]}`` where ``source`` is one of
        ``"encrypted_store"`` / ``"env"`` / ``"missing"`` /
        ``"error"``. **Never returns the token itself** — operator
        UI uses this to render presence indicators without exposing
        secrets to the browser.

        Returns ``{"loaded": False, "reason": "..."}`` when the
        daemon was started without ``--project-dir`` (no platforms
        to report on) or without ``--state-dir`` (no place to
        check for an encrypted store).

        Auth-required per the middleware.
        """
        if state_dir is None or platform_ids is None:
            return JSONResponse({
                "loaded": False,
                "reason": (
                    "daemon has no state-dir or platform list "
                    "(was --project-dir passed?)"
                ),
            })
        from forge_manager_mcp.daemon.credentials import credential_status
        return JSONResponse({
            "credentials": credential_status(state_dir, platform_ids),
        })

    async def put_credential(request) -> JSONResponse:
        """Write or update one platform's token (#313 cap 3 / D6).

        Body: ``{"token": "<plaintext>"}``. Loads the existing
        encrypted store, sets ``platform_id → token``, atomic-writes
        back. The token is also pushed into ``os.environ`` under
        the platform's canonical env-var name so the daemon's
        already-running ReplicationManager picks it up on the next
        write/read without a restart.

        404 when the daemon has no state-dir.
        400 when the body is invalid or the token is empty.
        """
        if state_dir is None:
            return JSONResponse(
                {"error": "daemon has no state-dir"}, status_code=404,
            )
        platform_id = request.path_params["platform_id"]
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        token = body.get("token", "")
        if not isinstance(token, str) or not token.strip():
            return JSONResponse(
                {"error": "token must be a non-empty string"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.credentials import (
            CredentialsError, env_var_for, set_credential,
        )
        try:
            set_credential(state_dir, platform_id, token)
        except CredentialsError as exc:
            return JSONResponse(
                {"error": str(exc)}, status_code=400,
            )
        # Live-promote to env so the running ReplicationManager
        # adapter dispatcher picks up the new value next request.
        var = env_var_for(platform_id)
        if var is not None:
            import os
            os.environ[var] = token
        return JSONResponse({"platform_id": platform_id, "stored": True})

    async def delete_credential(request) -> JSONResponse:
        """Remove one platform's token from the encrypted store
        (#313 cap 3 / D6).

        Atomic-writes the trimmed map back. Also unsets the
        corresponding ``os.environ`` entry so subsequent
        ReplicationManager calls see the credential as absent.

        404 when the daemon has no state-dir.
        Returns ``{platform_id, removed: bool}`` — `removed=False`
        when the platform had no entry (no-op).
        """
        if state_dir is None:
            return JSONResponse(
                {"error": "daemon has no state-dir"}, status_code=404,
            )
        platform_id = request.path_params["platform_id"]
        from forge_manager_mcp.daemon.credentials import (
            delete_credential as do_delete, env_var_for,
        )
        removed = do_delete(state_dir, platform_id)
        if removed:
            var = env_var_for(platform_id)
            if var is not None:
                import os
                os.environ.pop(var, None)
        return JSONResponse(
            {"platform_id": platform_id, "removed": removed},
        )

    async def post_write(request) -> JSONResponse:
        """Dispatch a canonical write through the daemon (Phase D5 /
        #355 / capability 8).

        Body: ``{"op": <op_name>, "args": <op-specific dict>}``.
        Looks up the op in ``daemon.writes._OP_REGISTRY``; 400 if
        unknown. Calls the handler with the daemon's
        ``replication`` manager + the args dict; serializes the
        ``WriteResult`` envelope back to JSON.

        Returns ``{value: <op-result>, mirror_warnings: [...]}``.

        503 when the daemon was started without a replication
        manager (no --project-dir or pre-bootstrap mode).

        500 on any handler exception — body carries the error
        type + message so the MCP can wrap it into an
        ``OperationError`` envelope without parsing.

        Per #355 OQ3 closure: this handler also publishes a
        ``write.completed`` event to the broadcaster on success,
        moving that side-effect from the MCP to the daemon
        (matches "daemon owns state → daemon owns the event").
        """
        if replication is None:
            return JSONResponse(
                {
                    "error": (
                        "daemon has no replication manager — was "
                        "--project-dir passed? Pre-bootstrap mode "
                        "rejects writes."
                    ),
                },
                status_code=503,
            )
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        op_name = body.get("op")
        args = body.get("args", {})
        if not isinstance(op_name, str) or not op_name:
            return JSONResponse(
                {"error": "op must be a non-empty string"},
                status_code=400,
            )
        if not isinstance(args, dict):
            return JSONResponse(
                {"error": "args must be a JSON object"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.writes import get_handler
        handler = get_handler(op_name)
        if handler is None:
            return JSONResponse(
                {
                    "error": f"unknown write op: {op_name!r}",
                    "op": op_name,
                },
                status_code=400,
            )
        try:
            result = await handler(replication, args)
        except Exception as exc:
            return JSONResponse(
                {
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                    "op": op_name,
                },
                status_code=500,
            )

        # (#355 OQ3) Publish write.completed daemon-side. Best-
        # effort — broadcaster failure must not poison the
        # already-succeeded canonical write.
        try:
            from forge_manager_mcp.daemon.effects.events import publish
            publish(broadcaster, "write.completed", {
                "operation_name": op_name,
            })
        except Exception:
            pass

        return JSONResponse(result)

    async def post_read(request) -> JSONResponse:
        """(#356, 3.7.0 D8) Dispatch a canonical read through the daemon.

        Mirrors ``post_write``: body ``{"op": <op_name>, "args": <op-
        specific dict>}``; looks up the op in
        ``daemon.reads._READ_OP_REGISTRY``; calls the handler with
        the daemon's ``replication`` manager + the args dict.

        Wire-shape: ``{value: <op-result>}`` (reads don't generate
        ``mirror_warnings`` — read failover is silent per
        ``ReplicationManager.read``'s existing contract).

        503 when no replication manager. 400 on bad input or
        unknown op. 500 on handler exception (mirrored from
        ``post_write``).

        Per #356 OQ1 closure: failures propagate. Read paths that
        need graceful degradation handle it case-by-case at the
        MCP-side ``dispatch_read`` boundary.
        """
        if replication is None:
            return JSONResponse(
                {
                    "error": (
                        "daemon has no replication manager — was "
                        "--project-dir passed? Pre-bootstrap mode "
                        "rejects reads."
                    ),
                },
                status_code=503,
            )
        try:
            body = await request.json()
        except Exception:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        op_name = body.get("op")
        args = body.get("args", {})
        if not isinstance(op_name, str) or not op_name:
            return JSONResponse(
                {"error": "op must be a non-empty string"},
                status_code=400,
            )
        if not isinstance(args, dict):
            return JSONResponse(
                {"error": "args must be a JSON object"},
                status_code=400,
            )
        from forge_manager_mcp.daemon.reads import get_handler
        handler = get_handler(op_name)
        if handler is None:
            return JSONResponse(
                {
                    "error": f"unknown read op: {op_name!r}",
                    "op": op_name,
                },
                status_code=400,
            )
        try:
            result = await handler(replication, args)
        except Exception as exc:
            return JSONResponse(
                {
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                    "op": op_name,
                },
                status_code=500,
            )
        return JSONResponse(result)

    async def search_local(request) -> JSONResponse:
        """Full-text search across canonical Issues / Discussions /
        Sessions / code files (Phase D4.5 / #354; D3.1 / #384 added
        ``code`` kind for code-content FTS).

        Query params:
            ``q`` — FTS5 MATCH query string. Required.
            ``kind`` — optional filter; one of ``issue``,
                ``discussion``, ``session``, ``code``. Omitted =
                union all.
            ``limit`` — cap on returned hits (default 50).

        Returns the shaped envelope:

            {
              "results": [
                {"kind": "issue", "ref_native_id": "...", "title": "...", "snippet": "..."},
                ...
              ],
              "total_count": <int>,
              "query": "<echo-back>"
            }

        ``snippet`` uses sqlite's FTS5 ``snippet()`` function to
        return a 32-token contextual snippet around the match.
        Sessions have no title field; their ``title`` is empty.

        Returns 503 when the daemon was started without an
        action_log connection.
        """
        import sqlite3
        if action_log_con is None:
            return JSONResponse(
                {"error": "daemon has no action-log connection"},
                status_code=503,
            )
        q = request.query_params.get("q", "").strip()
        if not q:
            return JSONResponse(
                {"error": "query parameter 'q' is required"},
                status_code=400,
            )
        kind = request.query_params.get("kind")
        limit_raw = request.query_params.get("limit")
        limit = 50
        if limit_raw:
            try:
                limit = int(limit_raw)
                if limit <= 0:
                    raise ValueError("limit must be positive")
            except ValueError:
                return JSONResponse(
                    {"error": f"invalid limit: {limit_raw!r}"},
                    status_code=400,
                )

        results: list[dict] = []
        per_kind_limit = limit  # cap per query; final list may be less

        def _search(
            table: str, kind_label: str, *,
            id_col: str = "ref_native_id",
            has_title: bool = True,
        ) -> None:
            """Run one FTS5 query against ``table`` + append hits.

            ``id_col`` names the UNINDEXED column that uniquely
            identifies the row — ``ref_native_id`` for issues_fts /
            discussions_fts, ``session_id`` for sessions_fts,
            ``path`` for code_fts (#384, 3.9.0 D3.1).
            """
            try:
                title_clause = "title, " if has_title else ""
                sql = (
                    f"SELECT {id_col} AS ref_native_id, {title_clause}"
                    f"snippet({table}, -1, '<mark>', '</mark>', '...', 32) AS snippet "
                    f"FROM {table} WHERE {table} MATCH ? "
                    f"LIMIT ?"
                )
                cur = action_log_con.execute(sql, (q, per_kind_limit))
                for row in cur:
                    entry: dict = {
                        "kind": kind_label,
                        "ref_native_id": row["ref_native_id"],
                        "snippet": row["snippet"],
                    }
                    entry["title"] = row["title"] if has_title else ""
                    results.append(entry)
            except sqlite3.OperationalError:
                # Malformed FTS5 query → skip this table; let the
                # caller see whatever did parse.
                pass

        if kind in (None, "issue"):
            _search("issues_fts", "issue")
        if kind in (None, "discussion"):
            _search("discussions_fts", "discussion")
        if kind in (None, "session"):
            _search(
                "sessions_fts", "session",
                id_col="session_id", has_title=False,
            )
        if kind in (None, "code"):
            # (#384, 3.9.0 D3.1) Code hits use the file path as the
            # ref_native_id; UI maps to /files/content?path=<path>.
            _search(
                "code_fts", "code",
                id_col="path", has_title=False,
            )

        # Apply final cross-kind limit.
        results = results[:limit]
        return JSONResponse({
            "results": results,
            "total_count": len(results),
            "query": q,
        })

    async def get_commands(request) -> JSONResponse:
        """(3.10.0 D3) GET /commands — return the loaded text-grammar
        registry as JSON for the UI omnibar's autocomplete + help
        rendering.

        Each command is serialized as
        ``{verb, noun, summary, args, dispatch_kind, mutating}``
        — enough for the omnibar to:

        * suggest noun-verb pairs as the operator types,
        * render argument hints,
        * decide whether to run a confirmation modal (mutating
          commands per #392 G5).

        Response: ``{commands: [...], schema_version: "3.10.0"}``.

        Returns 404 if commands.yaml is absent (greenfield project
        without scaffolded skill prose).
        """
        if project_dir is None:
            return JSONResponse(
                {"error": (
                    "daemon was started without --project-dir; "
                    "commands.yaml not in scope"
                )},
                status_code=503,
            )
        commands_path = (
            project_dir / ".claude" / "skills" / "forge-manager"
            / "commands.yaml"
        )
        if not commands_path.exists():
            return JSONResponse(
                {"error": f"commands.yaml not found at {commands_path}"},
                status_code=404,
            )
        from forge_manager_mcp.command_registry import (
            CommandRegistryError, load_commands,
        )
        try:
            registry = load_commands(commands_path)
        except CommandRegistryError as exc:
            return JSONResponse(
                {"error": str(exc)},
                status_code=500,
            )

        # Mutating-command heuristic: any command whose verb belongs
        # to a small set of mutating-shaped verbs gets flagged. The
        # operator-facing UX is "show confirm modal before
        # dispatching." Read-only verbs (search, show, list, open,
        # help) bypass the modal and run directly.
        MUTATING_VERBS = frozenset({
            "add", "create", "close", "open-issue", "delete",
            "update", "edit", "move", "mark-decided", "merge",
            "release", "publish", "tag",
        })

        commands_out: list = []
        # Use a dict to dedupe — aliases register multiple keys but
        # point to the same Command instance.
        seen_keys: set = set()
        for (key_verb, key_noun), cmd in registry._by_key.items():
            canonical_key = (cmd.verb, cmd.noun)
            if canonical_key in seen_keys:
                continue
            seen_keys.add(canonical_key)
            dispatch_kind = (
                "ui_route" if cmd.ui_route is not None
                else ("daemon" if cmd.daemon_endpoint is not None
                      else "mcp_tool")
            )
            commands_out.append({
                "verb": cmd.verb,
                "noun": cmd.noun,
                "summary": cmd.summary,
                "args": [
                    {
                        "name": a.name,
                        "type": a.type,
                        "positional": a.positional,
                        "required": a.required,
                    } for a in cmd.args
                ],
                "dispatch_kind": dispatch_kind,
                "mutating": cmd.verb in MUTATING_VERBS,
                "introduced_in": cmd.introduced_in,
            })
        # Stable sort by (noun, verb) for deterministic UI rendering.
        commands_out.sort(key=lambda c: (c["noun"], c["verb"]))

        return JSONResponse({
            "commands": commands_out,
            "schema_version": "3.10.0",
        })

    async def post_command(request) -> JSONResponse:
        """(#387, 3.9.0 D4.4) POST /command — text-grammar dispatch
        from the daemon side.

        Mirrors the MCP-side ``run_command`` tool: parse via
        ``commands.yaml`` registry, route to the resolved dispatch
        surface. The daemon-side variant is the execution surface
        the Cmd-K UI palette posts to (#13 §"Surface-by-surface
        dispatch").

        Routing differences from MCP:
          * ``daemon_endpoint`` commands → call ourselves over
            localhost HTTP (uvicorn handles concurrent self-calls
            fine; recursion depth is bounded to 1 since the inner
            call hits a non-/command endpoint).
          * ``ui_route`` commands → return the rendered route as
            data; UI consumer follows it.
          * ``mcp_tool`` commands → return a hint pointing at the
            typed MCP tool; daemon can't invoke MCP tools.
          * ``/help`` → in-line meta handler reads the registry.

        Body: ``{"command": "<raw text>"}``.
        Response shape mirrors run_command's: ``kind`` ∈ {help,
        ui_route, daemon, mcp_tool_hint, error}.
        """
        import json as _json
        try:
            body = await request.json()
        except _json.JSONDecodeError:
            return JSONResponse(
                {"error": "request body must be valid JSON"},
                status_code=400,
            )
        raw = (body or {}).get("command", "")
        if not isinstance(raw, str):
            return JSONResponse(
                {"error": "command field must be a string"},
                status_code=400,
            )
        if project_dir is None:
            return JSONResponse(
                {
                    "error": (
                        "daemon was started without --project-dir; "
                        "commands.yaml not in scope"
                    ),
                    "command": raw,
                },
                status_code=503,
            )
        commands_path = (
            project_dir / ".claude" / "skills" / "forge-manager"
            / "commands.yaml"
        )
        if not commands_path.exists():
            return JSONResponse(
                {
                    "error": (
                        f"commands.yaml not found at {commands_path}"
                    ),
                    "command": raw,
                },
                status_code=404,
            )
        from forge_manager_mcp.command_registry import (
            CommandRegistryError, load_commands, parse_command,
        )
        try:
            registry = load_commands(commands_path)
            parsed = parse_command(raw, registry)
        except CommandRegistryError as exc:
            return JSONResponse(
                {"error": str(exc), "command": raw},
                status_code=400,
            )

        cmd = parsed.command

        def _publish_executed(payload: dict) -> None:
            """(#387, 3.9.0 D4.6) Publish ``command.executed`` event.

            Best-effort — broadcaster failure must not poison the
            already-dispatched command. Subscribers (UI palette
            history, action_log capture, external SSE consumers)
            see the operator-typed string + the resolved kind.
            """
            try:
                from forge_manager_mcp.daemon.effects.events import publish
                publish(broadcaster, "command.executed", {
                    "command": raw,
                    "kind": payload.get("kind"),
                    "verb": cmd.verb,
                    "noun": cmd.noun,
                })
            except Exception:
                pass

        # Inline /help handler.
        if cmd.verb == "help":
            target_verb = (
                parsed.positional[0] if parsed.positional else None
            )
            if target_verb is None:
                payload = {
                    "kind": "help",
                    "verbs": registry.list_verbs(),
                    "command": raw,
                }
                _publish_executed(payload)
                return JSONResponse(payload)
            matches = [
                {"verb": c.verb, "noun": c.noun, "summary": c.summary}
                for c in registry.list_for_verb(target_verb)
            ]
            payload = {
                "kind": "help",
                "verb": target_verb,
                "commands": matches,
                "command": raw,
            }
            _publish_executed(payload)
            return JSONResponse(payload)

        # ui_route — return the rendered fragment as data.
        if cmd.ui_route is not None and cmd.daemon_endpoint is None:
            rendered = parsed.substitute(cmd.ui_route)
            payload = {
                "kind": "ui_route",
                "route": rendered,
                "command": raw,
            }
            _publish_executed(payload)
            return JSONResponse(payload)

        # daemon_endpoint — recursive localhost dispatch.
        if cmd.daemon_endpoint is not None:
            method, _, path = cmd.daemon_endpoint.partition(" ")
            params_raw = parsed.substitute(cmd.daemon_params_json or "{}")
            try:
                params = _json.loads(params_raw)
            except _json.JSONDecodeError as exc:
                return JSONResponse({
                    "error": (
                        f"daemon_params_json template did not render to "
                        f"valid JSON: {exc}"
                    ),
                    "rendered": params_raw,
                    "command": raw,
                }, status_code=500)
            # Recursive self-call. The auth header from this request
            # is reused — the inner call has the same Bearer token
            # as the operator's POST.
            auth = request.headers.get("Authorization", "")
            base = f"http://127.0.0.1:{request.url.port}{path}"
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    if method.upper() == "GET":
                        resp = await client.get(
                            base,
                            headers={"Authorization": auth},
                            params={k: str(v) for k, v in params.items()},
                        )
                    else:
                        resp = await client.request(
                            method, base,
                            headers={"Authorization": auth},
                            json=params,
                        )
            except httpx.HTTPError as exc:
                return JSONResponse({
                    "error": f"daemon self-dispatch failed: {exc}",
                    "command": raw,
                }, status_code=500)
            try:
                inner_body = resp.json()
            except _json.JSONDecodeError:
                inner_body = {"raw": resp.text}
            payload = {
                "kind": "daemon",
                "endpoint": cmd.daemon_endpoint,
                "status_code": resp.status_code,
                "result": inner_body,
                "command": raw,
            }
            _publish_executed(payload)
            return JSONResponse(payload)

        # mcp_tool-only — surface the typed tool name.
        payload = {
            "kind": "mcp_tool_hint",
            "tool_name": cmd.mcp_tool,
            "args_template": cmd.mcp_args_json,
            "args_rendered": parsed.substitute(cmd.mcp_args_json or "{}"),
            "message": (
                f"This command dispatches via the typed MCP tool "
                f"{cmd.mcp_tool!r}. The daemon cannot invoke MCP tools "
                f"directly; call the tool via your MCP client."
            ),
            "command": raw,
        }
        _publish_executed(payload)
        return JSONResponse(payload)

    routes: list = [
        Route("/health", health, methods=["GET"]),
        Route("/auth/bootstrap", auth_bootstrap, methods=["GET"]),
        Route("/whoami", whoami, methods=["GET"]),
        Route("/config", config, methods=["GET"]),
        Route("/config", write_config, methods=["POST"]),
        Route(
            "/setup/scaffold", setup_scaffold, methods=["POST"],
        ),
        Route("/backends", backends, methods=["GET"]),
        Route("/credentials", credentials, methods=["GET"]),
        Route(  # (#313 cap 3 / D6)
            "/credentials/{platform_id}",
            put_credential, methods=["PUT", "POST"],
        ),
        Route(  # (#313 cap 3 / D6)
            "/credentials/{platform_id}",
            delete_credential, methods=["DELETE"],
        ),
        Route(  # (#366 / 3.8.0 D6 / Theme F)
            "/credentials/{platform_id}/test",
            test_credential_endpoint, methods=["POST"],
        ),
        Route("/alerts", get_alerts, methods=["GET"]),
        Route("/alerts", post_alert, methods=["POST"]),
        Route("/files/tree", files_tree, methods=["GET"]),
        Route("/files/content", files_content, methods=["GET"]),
        Route("/repos", repos, methods=["GET"]),  # (#351, 3.7.0 D5)
        Route("/gates", gates_endpoint, methods=["GET"]),
        Route("/findings", findings_endpoint, methods=["GET"]),
        Route("/upgrade/status", upgrade_status, methods=["GET"]),
        Route(
            "/upgrade/execute/{step}", upgrade_execute,
            methods=["POST"],
        ),
        Route(
            "/backends/{platform_id}/pause", pause_backend, methods=["POST"],
        ),
        Route(
            "/backends/{platform_id}/resume", resume_backend, methods=["POST"],
        ),
        Route("/events", events, methods=["GET"]),
        Route("/events", publish_event, methods=["POST"]),
        Route("/search", search_local, methods=["GET"]),
        Route("/writes", post_write, methods=["POST"]),
        Route("/reads", post_read, methods=["POST"]),  # (#356, 3.7.0 D8)
        Route("/command", post_command, methods=["POST"]),  # (#387, 3.9.0 D4.4)
        Route("/commands", get_commands, methods=["GET"]),  # (3.10.0 D3)
    ]
    # The static mount goes LAST so /health (and future API routes)
    # match before the catch-all static handler.
    if ui_dist is not None:
        routes.append(
            Mount(
                "/",
                app=StaticFiles(directory=str(ui_dist), html=True),
                name="ui",
            )
        )

    middleware = [
        Middleware(BearerTokenMiddleware, expected_token=auth_token),
    ]
    return Starlette(routes=routes, middleware=middleware)
