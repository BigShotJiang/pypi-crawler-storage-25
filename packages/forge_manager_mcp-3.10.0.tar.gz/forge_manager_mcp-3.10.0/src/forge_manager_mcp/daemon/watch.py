"""(#347 / 3.7.0 D4) Live code-design analyzer via filesystem polling.

Runs as a daemon background task. Polls ``project_dir`` for ``*.py``
mtime changes; on change, invokes the registered ``code_design``
evaluators against each changed file and pushes findings into the
daemon's alert log. Findings show up via the existing
``GET /alerts`` endpoint and SSE channel — same surface as
backend-transition + credentials-failure alerts.

**Why polling rather than ``watchfiles``.** Polling-based design
keeps the runtime dep tree at stdlib only — ``watchfiles`` would
add a Rust-backed wheel for sub-second latency that's overkill
for the target use case (operator wants feedback the next time
they check the alert log or open a session). The full LSP-tier
sub-second-latency alternative is tracked in #347 as the higher-
fidelity follow-up; the watch-daemon path is the bounded "lighter-
weight" alternative the issue body itself suggests.

**No initial-tree scan.** ``check_code_design`` (the MCP tool)
covers the snapshot scan; the watch loop's job is the
since-last-poll delta. This means the loop's first poll captures
the mtime baseline silently — only post-baseline edits surface as
alerts.

**Test purity.** All four primitive functions (``snapshot_mtimes``
/ ``changed_paths`` / ``evaluate_paths`` / ``alerts_for_findings``)
are pure relative to their inputs (the directory walk + stat is
deterministic given the filesystem). The async ``watch_loop``
wraps them with sleep + record-into-alert-log; tests cover each
primitive independently and use ``asyncio.timeout`` to bound the
loop test.
"""
from __future__ import annotations

import asyncio
import fnmatch
import logging
import os
from pathlib import Path

from .alerts import make_alert


_LOG = logging.getLogger(__name__)


_DEFAULT_SCOPE: tuple[str, ...] = ("**/*.py",)
_DEFAULT_POLL_INTERVAL = 2.0  # seconds

# (#380) Path-component fnmatch patterns the watch loop skips. Covers
# Bazel build artifacts (``build/lib/<pkg>/``), Python bytecode caches,
# editable-install eggs, virtualenvs, JS toolchain output, VCS plumbing,
# and pytest scratch — all of which contain ``*.py`` files but mirror
# canonical sources (so scanning them double/triple-fires every
# code_design finding). Matched against each path component via
# ``fnmatch.fnmatchcase`` so glob suffixes (``*.egg-info``, ``bazel-*``)
# work without per-pattern special-casing.
_DEFAULT_DENYLIST: tuple[str, ...] = (
    "build", "dist", "__pycache__", "*.egg-info",
    ".venv", "venv", "node_modules", ".git",
    ".pytest_cache", "bazel-*",
)


def path_in_denylist(path: Path, denylist: tuple[str, ...]) -> bool:
    """True when any segment of ``path`` matches any ``denylist`` pattern.

    Pure: depends only on its inputs. Tests cover it directly.
    """
    return any(
        fnmatch.fnmatchcase(part, pattern)
        for part in path.parts
        for pattern in denylist
    )


def snapshot_mtimes(
    project_dir: Path, *,
    scope: tuple[str, ...] = _DEFAULT_SCOPE,
    denylist: tuple[str, ...] = _DEFAULT_DENYLIST,
) -> "dict[Path, float]":
    """Walk ``project_dir`` for files matching ``scope`` glob patterns
    and return a path → mtime mapping.

    Files whose path includes a denylisted segment are skipped (#380 —
    Bazel build artifacts, ``__pycache__``, etc. would otherwise
    fire every code_design finding multiple times).

    Symlinked or otherwise duplicate paths that resolve to the same
    real file are deduped: the first appearance wins, subsequent
    aliases are silently skipped (#380 — the project's Bazel symlink
    layout has ``mcp-server/forge_manager_mcp/<name>.py`` symlinked to
    ``mcp-server/src/forge_manager_mcp/<name>.py``; both used to scan).

    Files that fail to stat (raced delete) are silently skipped —
    they'll either reappear on the next poll or stay absent.
    """
    out: dict[Path, float] = {}
    seen_realpaths: set[str] = set()
    for pattern in scope:
        for path in project_dir.glob(pattern):
            if not path.is_file():
                continue
            if path_in_denylist(path, denylist):
                continue
            try:
                real = os.path.realpath(path)
            except OSError:
                continue
            if real in seen_realpaths:
                continue
            seen_realpaths.add(real)
            try:
                out[path] = path.stat().st_mtime
            except OSError:
                continue
    return out


def changed_paths(
    prev: "dict[Path, float]", curr: "dict[Path, float]",
) -> "list[Path]":
    """Return the paths whose mtime changed (or appeared) between
    snapshots.

    Removed files are NOT returned — there's no current state to
    evaluate against. Their absence shows up implicitly: the next
    snapshot won't include them.
    """
    return [
        path for path, mtime in curr.items()
        if path not in prev or prev[path] != mtime
    ]


def evaluate_paths(
    project_dir: Path, paths: "list[Path]",
) -> list:
    """Run every registered ``code_design`` evaluator against
    ``paths``.

    Returns a flat list of ``Finding`` values. Each evaluator
    receives the project root + a list of paths (relative when
    possible — that matches the ``check_code_design`` tool's
    contract) + a default ``warn`` severity.

    Per-evaluator exceptions are logged and skipped rather than
    aborting the whole run — a single buggy evaluator should not
    take down the watch loop.
    """
    from forge_manager_mcp.code_design import all_rules, get_evaluator

    relative_paths: list[Path] = []
    for path in paths:
        try:
            relative_paths.append(path.relative_to(project_dir))
        except ValueError:
            relative_paths.append(path)

    findings: list = []
    for rule_name in all_rules():
        evaluator = get_evaluator(rule_name)
        if evaluator is None:
            continue
        try:
            rule_findings = evaluator(project_dir, relative_paths, "warn")
        except Exception as exc:  # noqa: BLE001 — see docstring
            _LOG.warning(
                "code_design rule %r raised on changed paths %s: %s",
                rule_name, relative_paths, exc,
            )
            continue
        findings.extend(rule_findings)
    return findings


def alerts_for_findings(findings: list) -> list:
    """Build one ``Alert`` per ``Finding`` for the alert-log push.

    Tags: ``("code_design", "<rule>", "<severity>")`` so the UI's
    backend-filter pattern from #341 generalises (filter by tag).
    Detail carries the finding's message; the headline message is
    ``code_design.<rule>: <path>:<line>``.
    """
    out: list = []
    for f in findings:
        location = getattr(f, "location", None)
        path = getattr(location, "path", None) or "?"
        line = getattr(location, "line", None)
        location_str = f"{path}:{line}" if line is not None else str(path)
        severity = getattr(f, "severity", "info")
        level = severity if severity in ("info", "warn", "fail") else "info"
        out.append(make_alert(
            level=level,
            message=f"code_design.{f.rule}: {location_str}",
            detail=getattr(f, "message", ""),
            tags=("code_design", f.rule, severity),
        ))
    return out


async def watch_loop(
    project_dir: "Path | None",
    alert_log,
    *,
    poll_interval: float = _DEFAULT_POLL_INTERVAL,
    scope: tuple[str, ...] = _DEFAULT_SCOPE,
) -> None:
    """Long-running async task. Polls ``project_dir`` for changes and
    emits ``code_design`` findings to ``alert_log``.

    No-op (returns immediately) when:
      * ``project_dir`` is None — daemon started without
        ``--project-dir``.
      * ``alert_log`` is None — test contexts that disable it.
      * ``project_dir`` doesn't exist or isn't a directory.

    Cancellation: respects ``asyncio.CancelledError``. The daemon's
    main loop cancels this task on shutdown so the polling stops
    cleanly.

    Per-iteration exceptions are logged and the loop continues —
    one bad poll should not break the whole watcher.
    """
    if project_dir is None or alert_log is None:
        return
    if not project_dir.exists() or not project_dir.is_dir():
        return

    prev = snapshot_mtimes(project_dir, scope=scope)

    while True:
        try:
            await asyncio.sleep(poll_interval)
            curr = snapshot_mtimes(project_dir, scope=scope)
            changed = changed_paths(prev, curr)
            prev = curr
            if not changed:
                continue
            findings = evaluate_paths(project_dir, changed)
            for alert in alerts_for_findings(findings):
                alert_log.record(alert)
        except asyncio.CancelledError:
            return
        except Exception as exc:  # noqa: BLE001 — see docstring
            _LOG.warning("watch_loop iteration failed: %s", exc)
