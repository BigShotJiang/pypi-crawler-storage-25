"""forge-manager MCP server (3.0+; renamed from active-claude-github per RFC #264 / OQ5)."""

__version__ = "3.10.0"
