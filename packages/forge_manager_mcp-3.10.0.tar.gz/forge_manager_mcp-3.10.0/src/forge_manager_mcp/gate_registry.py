"""Gate and process registries — first-class abstraction (#287).

The skill enforces *gates* (point-in-time checks: commit-time test
coverage, plan validation, release validation, etc.) and *processes*
(stateful sequences: session.start, session.end, release.process,
recording.two_turn). Pre-3.2 these were scattered across topic-file
prose with no formal handle. This module makes them a data structure
projects can reference, extend, override, or open/close by name.

The two YAML files at ``.claude/skills/forge-manager/`` —
``gates.yaml`` and ``processes.yaml`` — are the canonical source. The
prose in ``commit-rules.md``, ``release.md``, etc. carries the human-
readable rationale; YAML carries the machine-addressable contract.

Loader exports
--------------

- :class:`Gate` / :class:`Process` / :class:`ProcessStep` Pydantic models.
- :class:`GateRegistry` / :class:`ProcessRegistry` with
  ``get(name)`` / ``list(*, type=)`` accessors.
- :func:`load_gates` / :func:`load_processes` — parse a YAML file into
  a registry.
- :exc:`GateRegistryError` — raised on schema violation, duplicate
  name, or malformed YAML.

YAML subset
-----------

This module ships its own constrained-shape YAML parser instead of
depending on PyYAML — matching the precedent in
``validators/plan.py``. The schema is small, the dep is permanent;
PyYAML's ergonomics aren't worth the lockfile churn for this scope.

Supported shapes:

- Top-level mapping with a single key (``gates:`` or ``processes:``).
- That key's value is a sequence of mappings (``- key: value`` blocks).
- Each mapping's fields can be:

  * Scalar string (quoted or unquoted),
  * Inline sequence: ``[a, b, c]`` or ``[]``,
  * Block scalar with the ``|`` indicator (multi-line literal,
    indentation-stripped),
  * Nested sequence of mappings (one level deep, used by
    ``processes[*].steps``).

- ``# `` introduces a line / inline comment.
- Indentation is two spaces per level. Tabs are rejected.

Anything outside this shape raises :exc:`GateRegistryError` at load
time so a malformed file fails loudly at server startup rather than
silently producing wrong-shaped data.
"""
from __future__ import annotations

from functools import cache
from pathlib import Path
from typing import ClassVar, Literal, TypeVar

from pydantic import BaseModel, Field, ValidationError, model_validator


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

GateType = Literal[
    "pre-commit",
    "post-commit",
    "pre-push",
    "pre-tag",
    "pre-publish",
    "post-tag",
    "classification",
]

ProcessType = Literal[
    "lifecycle",
    "recording",
    "release",
]

DefaultState = Literal["open", "closed"]
ExtensionSemantics = Literal["tighten", "loosen", "layer"]
OverrideSemantics = Literal["replace", "augment"]
StateChangeSemantics = Literal["open_close", "open_only", "closed_only"]


class GateRegistryError(Exception):
    """Raised on YAML parse / schema / duplicate-name failure."""


@cache
def _gate_class() -> type:
    class Gate(BaseModel):
        """Point-in-time check declaration.

        A Gate is the "what does this check do, where does it live, and
        how can projects extend it" record. Runtime evaluation is built
        on top via :func:`evaluate_gate` (in ``server/gates.py``); this
        record is the static metadata.
        """

        model_config = {"frozen": True, "extra": "forbid"}

        name: str = Field(
            ..., description="Dot-namespaced identifier (e.g. ``commit.test_coverage``)."
        )
        type: GateType = Field(..., description="When in the lifecycle this gate fires.")
        location: str = Field(
            ...,
            description=(
                "Topic-file anchor where the gate is defined "
                "(``commit-rules.md#commit.test_coverage``)."
            ),
        )
        summary: str = Field(..., description="One-line description.")
        default_state: DefaultState = Field(
            ...,
            description=(
                "Default state when no project rule overrides it. ``open`` "
                "fires; ``closed`` is a no-op."
            ),
        )
        extension_semantics: ExtensionSemantics = Field(
            ...,
            description=(
                "How project extensions compose with the default evaluator. "
                "``tighten`` adds stricter checks; ``loosen`` relaxes; "
                "``layer`` runs alongside without altering the default."
            ),
        )
        override_semantics: OverrideSemantics = Field(
            ...,
            description=(
                "How project overrides interact with the default evaluator. "
                "``replace`` halts the chain; ``augment`` runs after."
            ),
        )
        state_change_semantics: StateChangeSemantics = Field(
            ...,
            description=(
                "Which state transitions a project rule may declare. "
                "``open_close`` permits both directions."
            ),
        )
        rationale_doc: str = Field(
            ..., description="Topic-file anchor where the rationale lives."
        )
        introduced_in: str = Field(
            ..., description="Skill version when this gate was first declared."
        )
        last_changed_in: str | None = Field(
            None,
            description=(
                "Skill version of the last semantic change. Optional — present "
                "when the gate's contract has evolved since introduction."
            ),
        )
        related: tuple[str, ...] = Field(
            default_factory=tuple,
            description="Names of gates that interact with this one.",
        )
        notes: str | None = Field(
            None, description="Optional multi-line clarifying notes."
        )
        runbook_url: str | None = Field(
            None,
            description=(
                "Path within the docs repo (e.g. ``runbooks/<gate-name>.md``) "
                "for ``pre-publish`` gates whose evaluator is operator-driven. "
                "Required when ``type == 'pre-publish'``; forbidden otherwise."
            ),
        )

        @model_validator(mode="after")
        def _name_is_dot_namespaced(self) -> "Gate":
            if "." not in self.name:
                raise ValueError(
                    f"gate name must be dot-namespaced (e.g. 'commit.test_coverage'), got {self.name!r}"
                )
            return self

        @model_validator(mode="after")
        def _runbook_url_matches_type(self) -> "Gate":
            if self.type == "pre-publish" and not self.runbook_url:
                raise ValueError(
                    f"gate {self.name!r} has type='pre-publish' but no "
                    f"runbook_url; pre-publish gates are operator-driven "
                    f"and must declare a runbook path"
                )
            if self.type != "pre-publish" and self.runbook_url:
                raise ValueError(
                    f"gate {self.name!r} has runbook_url={self.runbook_url!r} "
                    f"but type={self.type!r}; runbook_url is only meaningful "
                    f"for type='pre-publish' gates"
                )
            return self

    return Gate


Gate = _gate_class()


@cache
def _process_step_class() -> type:
    class ProcessStep(BaseModel):
        """One step in a multi-step process declaration."""

        model_config = {"frozen": True, "extra": "forbid"}

        id: str = Field(..., description="Stable step identifier within the process.")
        location: str = Field(
            ..., description="Topic-file anchor where this step's prose lives."
        )
        gates: tuple[str, ...] = Field(
            default_factory=tuple,
            description="Names of gates evaluated during this step.",
        )

    return ProcessStep


ProcessStep = _process_step_class()


@cache
def _process_class() -> type:
    class Process(BaseModel):
        """Stateful sequence declaration."""

        model_config = {"frozen": True, "extra": "forbid"}

        name: str = Field(..., description="Dot-namespaced identifier.")
        type: ProcessType = Field(..., description="Process category.")
        location: str = Field(..., description="Topic-file anchor for the process body.")
        summary: str = Field(..., description="One-line description.")
        steps: tuple[ProcessStep, ...] = Field(
            default_factory=tuple, description="Ordered steps."
        )
        rationale_doc: str = Field(
            ..., description="Topic-file anchor where the rationale lives."
        )
        introduced_in: str = Field(..., description="Skill version when first declared.")
        last_changed_in: str | None = Field(
            None, description="Skill version of last semantic change."
        )
        related_processes: tuple[str, ...] = Field(
            default_factory=tuple, description="Other processes that interact with this one."
        )

        @model_validator(mode="after")
        def _name_is_dot_namespaced(self) -> "Process":
            if "." not in self.name:
                raise ValueError(
                    f"process name must be dot-namespaced (e.g. 'session.start'), got {self.name!r}"
                )
            return self

    return Process


Process = _process_class()


# ---------------------------------------------------------------------------
# Registries — small wrappers giving the get / list accessors the issue spec
# describes. Frozen by virtue of holding immutable tuples.
# ---------------------------------------------------------------------------

T = TypeVar("T")


class GateRegistry:
    """Read-only collection of :class:`Gate` records, keyed by name."""

    __slots__ = ("_by_name",)

    def __init__(self, gates: list[Gate]) -> None:
        self._by_name: dict[str, Gate] = {}
        for gate in gates:
            if gate.name in self._by_name:
                raise GateRegistryError(
                    f"duplicate gate name in registry: {gate.name!r}"
                )
            self._by_name[gate.name] = gate

    def get_gate(self, name: str) -> Gate | None:
        """Return the gate with the given name, or None if absent."""
        return self._by_name.get(name)

    def list_gates(self, *, type: GateType | None = None) -> list[Gate]:
        """Return all gates, optionally filtered by ``type``."""
        if type is None:
            return list(self._by_name.values())
        return [g for g in self._by_name.values() if g.type == type]

    def __len__(self) -> int:
        return len(self._by_name)

    def __contains__(self, name: object) -> bool:
        return isinstance(name, str) and name in self._by_name


class ProcessRegistry:
    """Read-only collection of :class:`Process` records, keyed by name."""

    __slots__ = ("_by_name",)

    def __init__(self, processes: list[Process]) -> None:
        self._by_name: dict[str, Process] = {}
        for proc in processes:
            if proc.name in self._by_name:
                raise GateRegistryError(
                    f"duplicate process name in registry: {proc.name!r}"
                )
            self._by_name[proc.name] = proc

    def get_process(self, name: str) -> Process | None:
        return self._by_name.get(name)

    def list_processes(self, *, type: ProcessType | None = None) -> list[Process]:
        if type is None:
            return list(self._by_name.values())
        return [p for p in self._by_name.values() if p.type == type]

    def __len__(self) -> int:
        return len(self._by_name)

    def __contains__(self, name: object) -> bool:
        return isinstance(name, str) and name in self._by_name


# ---------------------------------------------------------------------------
# Loader entry points
# ---------------------------------------------------------------------------

def load_gates(path: Path) -> GateRegistry:
    """Parse a ``gates.yaml`` file into a :class:`GateRegistry`.

    Raises :exc:`GateRegistryError` on any failure (missing file,
    parse error, schema violation, duplicate name).
    """
    parsed = _parse_yaml_file(path, root_key="gates")
    gates: list[Gate] = []
    for idx, item in enumerate(parsed):
        try:
            gates.append(Gate(**item))
        except ValidationError as exc:
            raise GateRegistryError(
                f"gates.yaml entry {idx} failed schema validation: {exc}"
            ) from exc
    return GateRegistry(gates)


def load_processes(path: Path) -> ProcessRegistry:
    """Parse a ``processes.yaml`` file into a :class:`ProcessRegistry`."""
    parsed = _parse_yaml_file(path, root_key="processes")
    processes: list[Process] = []
    for idx, item in enumerate(parsed):
        steps_raw = item.get("steps", [])
        if isinstance(steps_raw, list):
            try:
                item["steps"] = [ProcessStep(**s) for s in steps_raw]
            except ValidationError as exc:
                raise GateRegistryError(
                    f"processes.yaml entry {idx} step failed validation: {exc}"
                ) from exc
        try:
            processes.append(Process(**item))
        except ValidationError as exc:
            raise GateRegistryError(
                f"processes.yaml entry {idx} failed schema validation: {exc}"
            ) from exc
    return ProcessRegistry(processes)


# ---------------------------------------------------------------------------
# Constrained YAML parser
# ---------------------------------------------------------------------------

# Public so tests can exercise the parser independently.

def parse_yaml_text(text: str, *, root_key: str) -> list[dict]:
    """Parse a constrained-YAML document into a list of mapping dicts.

    See module docstring for the supported shape. Returns the value
    of ``root_key`` (which must be a sequence of mappings). Raises
    :exc:`GateRegistryError` on shape mismatch.
    """
    lines = text.splitlines()
    pos = 0
    # Skip leading blanks / comment-only lines.
    while pos < len(lines) and _is_blank_or_comment(lines[pos]):
        pos += 1
    if pos == len(lines):
        raise GateRegistryError(
            f"YAML document is empty (no `{root_key}:` root key)"
        )
    root_line = lines[pos]
    if "\t" in root_line:
        raise GateRegistryError(f"tabs not permitted (line {pos + 1})")
    if root_line.lstrip() != root_line:
        raise GateRegistryError(
            f"root key must start at column 0 (line {pos + 1})"
        )
    expected_prefix = f"{root_key}:"
    if not root_line.startswith(expected_prefix):
        raise GateRegistryError(
            f"expected root key {root_key!r} on line {pos + 1}, got: {root_line!r}"
        )
    after = root_line[len(expected_prefix):].strip()
    if after:
        raise GateRegistryError(
            f"root key {root_key!r} must be followed by an indented sequence, "
            f"not an inline value (line {pos + 1})"
        )
    pos += 1
    # Collect indented sequence under root_key; expect 2-space dash items.
    items, pos = _parse_sequence_of_mappings(lines, pos, indent=2)
    # Trailing content must be blank / comment-only.
    while pos < len(lines):
        if not _is_blank_or_comment(lines[pos]):
            raise GateRegistryError(
                f"unexpected content after root sequence (line {pos + 1}): {lines[pos]!r}"
            )
        pos += 1
    return items


def _parse_yaml_file(path: Path, *, root_key: str) -> list[dict]:
    if not path.exists():
        raise GateRegistryError(f"YAML file not found: {path}")
    text = path.read_text(encoding="utf-8")
    try:
        return parse_yaml_text(text, root_key=root_key)
    except GateRegistryError as exc:
        raise GateRegistryError(f"{path}: {exc}") from None


def _is_blank_or_comment(line: str) -> bool:
    s = line.strip()
    return not s or s.startswith("#")


def _parse_sequence_of_mappings(
    lines: list[str], start: int, *, indent: int
) -> tuple[list[dict], int]:
    """Parse ``  - key: value`` blocks at the given indent level.

    Returns (parsed items, position after the sequence).
    """
    items: list[dict] = []
    pos = start
    dash_prefix = " " * indent + "- "
    cont_prefix = " " * (indent + 2)
    while pos < len(lines):
        line = lines[pos]
        if _is_blank_or_comment(line):
            pos += 1
            continue
        if "\t" in line:
            raise GateRegistryError(f"tabs not permitted (line {pos + 1})")
        if not line.startswith(dash_prefix):
            # Sequence ended.
            break
        # Start a new mapping item.
        first_field = line[len(dash_prefix):]
        item: dict = {}
        _consume_field_into(item, first_field, line_no=pos + 1)
        pos += 1
        # Continuation lines live at indent+2 (key) or indent+4 (nested).
        while pos < len(lines):
            cont = lines[pos]
            if _is_blank_or_comment(cont):
                pos += 1
                continue
            if "\t" in cont:
                raise GateRegistryError(f"tabs not permitted (line {pos + 1})")
            if cont.startswith(dash_prefix):
                break  # next item in sequence
            if not cont.startswith(cont_prefix):
                break  # outdented — sequence ends
            field_text = cont[len(cont_prefix):]
            if field_text.startswith(" "):
                # Deeper indent (e.g. a continuation of a block scalar
                # already consumed above); we should never land here
                # because block scalar / nested sequence consumers
                # advance pos past their own lines.
                raise GateRegistryError(
                    f"unexpected deeper indentation (line {pos + 1}): {cont!r}"
                )
            # Is this a nested sequence header? `key:` with empty value
            # followed by lines starting with the deeper dash prefix.
            key, sep, inline_value = field_text.partition(":")
            if not sep:
                raise GateRegistryError(
                    f"expected `key: value` continuation (line {pos + 1}): {cont!r}"
                )
            key = key.strip()
            if not key:
                raise GateRegistryError(
                    f"empty key on continuation line {pos + 1}: {cont!r}"
                )
            inline_value = inline_value.strip()
            pos += 1
            if inline_value == "|":
                # Block scalar — collect indented continuation lines.
                block_indent = indent + 4
                value, pos = _consume_block_scalar(lines, pos, indent=block_indent)
                item[key] = value
                continue
            if inline_value == "":
                # Either nested sequence or continuation block list of strings.
                # Peek next non-blank line.
                peek = pos
                while peek < len(lines) and _is_blank_or_comment(lines[peek]):
                    peek += 1
                if peek >= len(lines):
                    item[key] = []
                    continue
                next_line = lines[peek]
                nested_dash = " " * (indent + 4) + "- "
                if next_line.startswith(nested_dash):
                    nested_items, pos = _parse_sequence_of_mappings(
                        lines, pos, indent=indent + 4
                    )
                    item[key] = nested_items
                    continue
                # No content under this key — empty list.
                item[key] = []
                continue
            # Inline scalar / inline sequence.
            item[key] = _parse_scalar_or_inline_seq(inline_value, line_no=pos)
        items.append(item)
    return items, pos


def _consume_field_into(item: dict, text: str, *, line_no: int) -> None:
    """Parse a ``key: value`` (or ``key:``) field on the dash-line itself."""
    key, sep, inline_value = text.partition(":")
    if not sep:
        raise GateRegistryError(
            f"expected `key: value` after dash (line {line_no}): {text!r}"
        )
    key = key.strip()
    if not key:
        raise GateRegistryError(f"empty key on line {line_no}: {text!r}")
    inline_value = inline_value.strip()
    if inline_value == "":
        # Caller's responsibility: an inline-empty value at the dash
        # position implies a nested structure on subsequent lines, but
        # that is uncommon for the gates / processes shapes. Reject
        # so authors keep the dash-line + at least one scalar / inline
        # sequence pair.
        raise GateRegistryError(
            f"first field on a sequence item must have an inline value "
            f"(line {line_no}): {text!r}"
        )
    if inline_value == "|":
        raise GateRegistryError(
            f"block scalar `|` not permitted on the dash-line itself "
            f"(line {line_no}): {text!r}"
        )
    item[key] = _parse_scalar_or_inline_seq(inline_value, line_no=line_no)


def _consume_block_scalar(
    lines: list[str], start: int, *, indent: int
) -> tuple[str, int]:
    """Collect a literal block scalar starting at line ``start``.

    Block lines are at ``indent`` columns or deeper. Returns the
    joined text (with newlines preserved, no trailing newline) and
    the position immediately after the block.
    """
    pos = start
    collected: list[str] = []
    while pos < len(lines):
        line = lines[pos]
        if line == "":
            # Allow blank line inside the block, attributing it to the block.
            collected.append("")
            pos += 1
            continue
        if "\t" in line:
            raise GateRegistryError(f"tabs not permitted (line {pos + 1})")
        leading = len(line) - len(line.lstrip(" "))
        if leading < indent:
            break
        collected.append(line[indent:])
        pos += 1
    # Trim trailing blank lines (cosmetic — keep YAML semantics close).
    while collected and collected[-1] == "":
        collected.pop()
    return "\n".join(collected), pos


def _parse_scalar_or_inline_seq(text: str, *, line_no: int) -> object:
    """Parse a scalar string, an inline sequence ``[a, b, c]``, or empty list."""
    if text.startswith("[") and text.endswith("]"):
        inner = text[1:-1].strip()
        if not inner:
            return []
        # Split on commas not inside quotes. Simple state machine.
        items: list[str] = []
        buf: list[str] = []
        in_str = False
        str_char = ""
        for ch in inner:
            if in_str:
                if ch == str_char:
                    in_str = False
                buf.append(ch)
                continue
            if ch in ("'", '"'):
                in_str = True
                str_char = ch
                buf.append(ch)
                continue
            if ch == ",":
                items.append("".join(buf).strip())
                buf = []
                continue
            buf.append(ch)
        items.append("".join(buf).strip())
        return [_unquote(it) for it in items if it]
    return _unquote(text)


def _unquote(token: str) -> str:
    if len(token) >= 2 and token[0] == token[-1] and token[0] in ("'", '"'):
        return token[1:-1]
    return token


__all__ = [
    "DefaultState",
    "ExtensionSemantics",
    "Gate",
    "GateRegistry",
    "GateRegistryError",
    "GateType",
    "OverrideSemantics",
    "Process",
    "ProcessRegistry",
    "ProcessStep",
    "ProcessType",
    "StateChangeSemantics",
    "load_gates",
    "load_processes",
    "parse_yaml_text",
]
