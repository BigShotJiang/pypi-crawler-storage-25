"""usability_gap detector (Phase 3.7.0 D3 / #348).

Walks Python source under handlers/ looking for error responses
that lack actionable guidance. Each return / raise that surfaces
an error message without a recover / next-step / suggestion hint
flags as a usability gap.

**Scope.** First-pass heuristic on operator-facing handler error
messages. The check looks at strings inside `_check(...)`,
`_step(...)`, `error=...`, and `message=...` arguments where
`ok=False` / `status="failed"` is set; if the message text
doesn't contain "recover", "retry", "fix", "set", "run",
"check", or similar action verbs, it's flagged.

**Heuristic, not policy.** Some failures are genuinely
unrecoverable; the operator can't do anything but file a bug.
The detector flags every match; operators triage. Future
enhancement: a `# usability:no-action-applicable` comment marker
the detector recognizes as suppression.

Per Rule 2 the file walk is the effect; analysis is pure.
``analyze_module`` takes parsed AST + source + returns findings.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

from forge_manager_mcp.gap_analysis._types import (
    GapSeverity,
    make_gap_finding,
    make_gap_location,
)
from forge_manager_mcp.gap_analysis.registry import register_detector


DETECTOR_NAME = "usability_gap"


_DEFAULT_DENYLIST = frozenset({
    "__pycache__", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".bazel", ".git", ".pytest_cache",
})


# Default scan roots — handler entry points are the obvious target.
# Adapter / replication / model code raises errors that handlers
# wrap; the wrapped form is what the operator sees.
_DEFAULT_SCAN_SUBDIRS: tuple[str, ...] = (
    "src/forge_manager_mcp/server/handlers",
    "forge_manager_mcp/server/handlers",
)


# Action verbs / phrases that signal the message is actionable.
# Each hint is matched with word boundaries (regex `\b<hint>\b`)
# rather than as a substring — `"use"` shouldn't false-match
# "because", `"set"` shouldn't false-match "asset", etc.
_ACTIONABLE_HINTS: tuple[str, ...] = (
    "recover", "retry", "fix", "set", "run", "check",
    "verify", "configure", "edit", "update", "install",
    "rerun", "rebuild", "restart", "see", "use",
    "consider", "rotate", "regenerate", "remove",
    "manually", "via", "either",
)
# Phrases that can stay substring-matched (no false-positive risk).
_ACTIONABLE_PHRASES: tuple[str, ...] = ("—", "see #")


# Minimum length below which we don't flag — short messages like
# "ok" or "skipped" aren't expected to carry guidance.
_MIN_MESSAGE_LEN = 30


def _is_failure_call(call: ast.Call) -> bool:
    """True if the call looks like an error / failure construction
    (`_check(name, ok_=False, ...)` or `_step(name, "failed", ...)`).

    Recognized shapes:
      _check(name, False, severity, detail)
      _check(name, ok_=False, ...)
      _step(name, "failed", ...)
      _step(name, status="failed", ...)
    """
    func = call.func
    if isinstance(func, ast.Attribute):
        fname = func.attr
    elif isinstance(func, ast.Name):
        fname = func.id
    else:
        return False
    if fname not in {"_check", "_step"}:
        return False
    # _check positional: (name, ok_, severity, detail) — second arg
    # is ok_; we want ok_=False.
    if fname == "_check":
        if len(call.args) >= 2 and _const_is_false(call.args[1]):
            return True
        for kw in call.keywords:
            if kw.arg in ("ok_", "ok") and _const_is_false(kw.value):
                return True
        return False
    # _step: (name, status, detail) — second arg is status string;
    # we want status == "failed".
    if fname == "_step":
        if len(call.args) >= 2 and _const_string_equals(call.args[1], "failed"):
            return True
        for kw in call.keywords:
            if kw.arg == "status" and _const_string_equals(kw.value, "failed"):
                return True
        return False
    return False


def _const_is_false(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and node.value is False


def _const_string_equals(node: ast.AST, expected: str) -> bool:
    return isinstance(node, ast.Constant) and node.value == expected


def _extract_message_string(call: ast.Call) -> str | None:
    """Find the operator-facing message string in a _check / _step
    call. _check's 4th positional arg is `detail`; _step's 3rd
    positional arg is `detail` (which can be a dict). Returns the
    message text if it's a literal string, else None — non-literal
    messages can't be statically analyzed."""
    func_name = (
        call.func.id
        if isinstance(call.func, ast.Name)
        else getattr(call.func, "attr", None)
    )
    if func_name == "_check":
        if len(call.args) >= 4 and isinstance(call.args[3], ast.Constant):
            v = call.args[3].value
            return v if isinstance(v, str) else None
        for kw in call.keywords:
            if kw.arg in ("detail", "message") and isinstance(kw.value, ast.Constant):
                v = kw.value.value
                return v if isinstance(v, str) else None
        return None
    if func_name == "_step":
        # _step's detail is typically a dict; look for an "error"
        # or "message" key with a string literal value.
        if len(call.args) >= 3 and isinstance(call.args[2], ast.Dict):
            return _dict_string_for_keys(call.args[2], ("error", "message"))
        for kw in call.keywords:
            if kw.arg == "detail" and isinstance(kw.value, ast.Dict):
                return _dict_string_for_keys(kw.value, ("error", "message"))
        return None
    return None


def _dict_string_for_keys(
    dnode: ast.Dict, keys: tuple[str, ...],
) -> str | None:
    """Look up a string-literal value in a Dict AST node by key."""
    for k, v in zip(dnode.keys, dnode.values):
        if (
            isinstance(k, ast.Constant)
            and k.value in keys
            and isinstance(v, ast.Constant)
            and isinstance(v.value, str)
        ):
            return v.value
    return None


_HINT_PATTERN = re.compile(
    r"\b(" + "|".join(_ACTIONABLE_HINTS) + r")\b",
    re.IGNORECASE,
)


def _has_actionable_hint(message: str) -> bool:
    lower = message.lower()
    if any(phrase in lower for phrase in _ACTIONABLE_PHRASES):
        return True
    return _HINT_PATTERN.search(message) is not None


def analyze_module(
    *,
    path: Path,
    source: str,
    severity: GapSeverity,
) -> list:
    """Pure analyzer: parse `source` and yield findings for every
    failure-shaped call whose message text lacks actionable guidance."""
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return []

    findings: list = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_failure_call(node):
            continue
        message = _extract_message_string(node)
        if message is None:
            continue  # non-literal; can't analyze statically
        if len(message) < _MIN_MESSAGE_LEN:
            continue  # too short to expect guidance
        if _has_actionable_hint(message):
            continue
        findings.append(make_gap_finding(
            detector=DETECTOR_NAME,
            category="usability",
            severity=severity,
            location=make_gap_location(
                path=str(path),
                line=getattr(node, "lineno", None),
                symbol=None,
            ),
            message=(
                "Failure message lacks actionable guidance — "
                f"first 60 chars: {message[:60]!r}"
            ),
            suggestion=(
                "Add a recovery hint: what command to run, what "
                "config to edit, what doc to read. Operators "
                "hitting this error need to know the next step."
            ),
            tags=("error_message", "no_action"),
        ))
    return findings


def detect(
    project_root: Path,
    scan_paths: list[Path] | None,
    severity: GapSeverity,
) -> list:
    """Detector entry point. Walks Python files under handler dirs
    (default) or operator-supplied `scan_paths`."""
    if scan_paths:
        roots = [
            p if p.is_absolute() else project_root / p for p in scan_paths
        ]
    else:
        roots = [
            project_root / sub for sub in _DEFAULT_SCAN_SUBDIRS
            if (project_root / sub).is_dir()
        ]
        if not roots:
            return []

    findings: list = []
    for root in roots:
        if not root.is_dir():
            continue
        for py_path in root.rglob("*.py"):
            if any(part in _DEFAULT_DENYLIST for part in py_path.parts):
                continue
            try:
                source = py_path.read_text(encoding="utf-8")
            except OSError:
                continue
            findings.extend(analyze_module(
                path=py_path, source=source, severity=severity,
            ))
    return findings


register_detector(DETECTOR_NAME, detect)
