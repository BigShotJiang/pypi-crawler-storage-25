"""Unit tests for GitHubAdapter shape conversions (3.0 / Phase 2 sub-run B).

Focus: the dict-to-canonical-type shapers, the platform_id classvar,
and the probe predicate. Live integration is covered by the cross-
adapter conformance suite (Phase 2 sub-run D).
"""
from __future__ import annotations

from datetime import datetime
from unittest.mock import AsyncMock, patch

import pytest

from forge_manager_mcp.adapters.github import (
    GitHubAdapter,
    _comment_from_dict,
    _discussion_from_dict,
    _issue_from_dict,
    _make_ref,
    _milestone_from_dict,
    _milestone_from_field,
)
from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    Comment,
    Discussion,
    Issue,
    Milestone,
)


# ---------------------------------------------------------------------------
# platform_id classvar
# ---------------------------------------------------------------------------

class TestPlatformId:
    def test_classvar(self):
        assert GitHubAdapter.platform_id == "github"

    def test_instance_inherits(self):
        adapter = GitHubAdapter(token="fake")
        assert adapter.platform_id == "github"

    def test_has_scaffold_true_after_c2(self):
        assert GitHubAdapter.has_scaffold is True

    def test_has_session_event_surface_false(self):
        assert GitHubAdapter.has_session_event_surface is False


# ---------------------------------------------------------------------------
# _make_ref
# ---------------------------------------------------------------------------

class TestMakeRef:
    def test_basic(self):
        ref = _make_ref(
            native_id="I_kwDO123",
            kind="issue",
            owner="org",
            repo="proj",
            number=42,
        )
        assert ref.platform_id == "github"
        assert ref.native_id == "I_kwDO123"
        assert ref.kind == "issue"
        assert ref.number == 42

    def test_comment_no_number(self):
        ref = _make_ref(
            native_id="DC_abc",
            kind="comment",
            owner="o",
            repo="r",
        )
        assert ref.number is None


# ---------------------------------------------------------------------------
# _issue_from_dict
# ---------------------------------------------------------------------------

class TestIssueFromDict:
    def test_minimal(self):
        d = {"id": "I_x", "number": 1, "title": "t", "body": "b"}
        issue = _issue_from_dict(d, owner="o", repo="r")
        assert issue.title == "t"
        assert issue.body == "b"
        assert issue.state == "open"
        assert issue.ref.number == 1

    def test_state_normalization(self):
        d = {"id": "x", "number": 1, "title": "t", "body": "", "state": "CLOSED"}
        assert _issue_from_dict(d, owner="o", repo="r").state == "closed"

    def test_state_default_open(self):
        d = {"id": "x", "number": 1, "title": "t", "body": ""}
        assert _issue_from_dict(d, owner="o", repo="r").state == "open"

    def test_labels_explicit(self):
        d = {"id": "x", "number": 1, "title": "t", "body": ""}
        issue = _issue_from_dict(
            d, owner="o", repo="r", labels=["kind:bug", "area:mcp"],
        )
        assert issue.labels == ["kind:bug", "area:mcp"]

    def test_labels_from_dict_field(self):
        d = {
            "id": "x", "number": 1, "title": "t", "body": "",
            "labels": [{"name": "bug"}, {"name": "area:mcp"}],
        }
        issue = _issue_from_dict(d, owner="o", repo="r")
        assert "bug" in issue.labels
        assert "area:mcp" in issue.labels

    def test_milestone_from_field_dict(self):
        d = {
            "id": "x", "number": 1, "title": "t", "body": "",
            "milestone": {"title": "3.0.0"},
        }
        issue = _issue_from_dict(d, owner="o", repo="r")
        assert issue.milestone == "3.0.0"

    def test_milestone_explicit_overrides_field(self):
        d = {
            "id": "x", "number": 1, "title": "t", "body": "",
            "milestone": {"title": "from-dict"},
        }
        issue = _issue_from_dict(
            d, owner="o", repo="r", milestone="explicit",
        )
        assert issue.milestone == "explicit"

    def test_body_none_normalized_to_empty(self):
        # Some github/* responses have body: None for empty Issues.
        d = {"id": "x", "number": 1, "title": "t", "body": None}
        issue = _issue_from_dict(d, owner="o", repo="r")
        assert issue.body == ""


# ---------------------------------------------------------------------------
# _discussion_from_dict
# ---------------------------------------------------------------------------

class TestDiscussionFromDict:
    def test_minimal(self):
        d = {"id": "D_x", "number": 5, "title": "t", "body": "b"}
        disc = _discussion_from_dict(d, owner="o", repo="r")
        assert disc.title == "t"
        assert disc.ref.kind == "discussion"
        assert disc.category is None

    def test_with_category(self):
        d = {
            "id": "D_x", "number": 5, "title": "t", "body": "b",
            "category": "Architecture",
        }
        disc = _discussion_from_dict(d, owner="o", repo="r")
        assert disc.category == "Architecture"


# ---------------------------------------------------------------------------
# _comment_from_dict
# ---------------------------------------------------------------------------

class TestCommentFromDict:
    def test_minimal(self):
        parent = _make_ref(
            native_id="I_x", kind="issue", owner="o", repo="r", number=1,
        )
        d = {"id": "DC_a", "body": "hello", "author": "claude"}
        c = _comment_from_dict(d, parent=parent)
        assert c.body == "hello"
        assert c.author == "claude"
        assert c.parent.kind == "issue"

    def test_iso_timestamp_parsed(self):
        parent = _make_ref(
            native_id="I_x", kind="issue", owner="o", repo="r",
        )
        d = {
            "id": "DC_a", "body": "x", "author": "a",
            "createdAt": "2026-04-29T15:00:00Z",
        }
        c = _comment_from_dict(d, parent=parent)
        assert c.created_at.year == 2026
        assert c.created_at.month == 4

    def test_missing_timestamp_uses_now(self):
        parent = _make_ref(
            native_id="I_x", kind="issue", owner="o", repo="r",
        )
        d = {"id": "DC_a", "body": "x", "author": "a"}
        c = _comment_from_dict(d, parent=parent)
        # Should fall back to datetime.now(); just verify it's a real datetime.
        assert isinstance(c.created_at, datetime)


# ---------------------------------------------------------------------------
# _milestone_from_dict / _milestone_from_field
# ---------------------------------------------------------------------------

class TestMilestoneFromDict:
    def test_basic(self):
        d = {"title": "3.0.0", "number": 5, "state": "open"}
        m = _milestone_from_dict(d)
        assert m.title == "3.0.0"
        assert m.number == 5
        assert m.state == "open"

    def test_closed_state_normalization(self):
        d = {"title": "2.3.0", "number": 1, "state": "CLOSED"}
        assert _milestone_from_dict(d).state == "closed"


class TestMilestoneFromField:
    def test_none(self):
        assert _milestone_from_field(None) is None

    def test_string(self):
        assert _milestone_from_field("3.0.0") == "3.0.0"

    def test_dict_with_title(self):
        assert _milestone_from_field({"title": "3.0.0"}) == "3.0.0"

    def test_dict_without_title(self):
        assert _milestone_from_field({}) is None


# ---------------------------------------------------------------------------
# probe
# ---------------------------------------------------------------------------

class TestProbe:
    @pytest.mark.asyncio
    async def test_probe_success(self):
        adapter = GitHubAdapter(token="fake")
        with patch(
            "forge_manager_mcp.github.core._graphql",
            new=AsyncMock(return_value={"viewer": {"login": "test"}}),
        ):
            assert await adapter.probe() is True

    @pytest.mark.asyncio
    async def test_probe_unavailable_returns_false(self):
        from forge_manager_mcp.adapters.errors import ForgeUnavailableError

        adapter = GitHubAdapter(token="fake")
        with patch(
            "forge_manager_mcp.github.core._graphql",
            new=AsyncMock(side_effect=ForgeUnavailableError("503")),
        ):
            assert await adapter.probe() is False


# ---------------------------------------------------------------------------
# create_issue — lookup parallelism + failure propagation
# ---------------------------------------------------------------------------
#
# Pre-#274 these concerns lived at the handler level (in test_create_issue.py
# and test_create_thread.py). Post-#274 the adapter owns the
# repo / label / milestone resolution dance, so the tests follow.

class TestCreateIssueParallelism:
    """#179 / #180 — repo + label (+ milestone) lookups must dispatch
    concurrently. Pre-#274 the handler did the gather; #274 moved the
    gather inside ``GitHubAdapter.create_issue``. Either layer must
    keep the lookup phase parallel — the test asserts on observable
    peak in-flight count."""

    @pytest.mark.asyncio
    async def test_lookup_phase_runs_in_parallel(self, monkeypatch):
        import asyncio

        in_flight = 0
        peak = 0
        release = asyncio.Event()

        async def stalled_lookup(*args, **kwargs):
            nonlocal in_flight, peak
            in_flight += 1
            peak = max(peak, in_flight)
            try:
                await release.wait()
                return "STUB"
            finally:
                in_flight -= 1

        monkeypatch.setattr(
            "forge_manager_mcp.github.resolvers.get_repo_node_id", stalled_lookup
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.get_label_id", stalled_lookup
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.resolvers.find_milestone_node_id", stalled_lookup
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.create_issue",
            AsyncMock(return_value={
                "id": "I_x", "number": 1, "url": "u",
            }),
        )

        adapter = GitHubAdapter(token="fake")
        labels = ["feature", "area:mcp", "area:skill"]
        task = asyncio.create_task(
            adapter.create_issue(
                owner="o", repo="r", title="t", body="b",
                labels=labels, milestone="2.3.0",
            )
        )

        # 1 repo + 3 labels + 1 milestone = 5 concurrent reads expected.
        for _ in range(40):
            await asyncio.sleep(0)
            if in_flight >= 5:
                break

        assert peak == 5, (
            f"expected 5 concurrent lookups (1 repo + 3 labels + 1 "
            f"milestone), got peak={peak}. GitHubAdapter.create_issue "
            "lookup phase is running sequentially."
        )

        release.set()
        await task


class TestCreateIssueMilestoneFailure:
    """#232 — milestone resolution failure surfaces clearly. Pre-#274
    this was tested at the handler level via
    `test_milestone_resolution_failure_propagates`; #274 moved the
    lookup into the adapter, so the test follows. The adapter must
    NOT call `_gh.create_issue` when milestone resolution fails — a
    bad milestone shouldn't leak a partially-created Issue."""

    @pytest.mark.asyncio
    async def test_milestone_lookup_failure_skips_create_issue(self, monkeypatch):
        from forge_manager_mcp.github.core import GitHubError

        async def boom(*args, **kwargs):
            raise GitHubError(
                "Milestone '9.9.9' not found in o/r. Available milestones: ['1.2.0']"
            )

        monkeypatch.setattr(
            "forge_manager_mcp.github.resolvers.get_repo_node_id",
            AsyncMock(return_value="R_x"),
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.get_label_id",
            AsyncMock(return_value="LA_x"),
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.resolvers.find_milestone_node_id", boom,
        )
        create_mock = AsyncMock()
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.create_issue", create_mock,
        )

        adapter = GitHubAdapter(token="fake")
        with pytest.raises(GitHubError, match="Available milestones"):
            await adapter.create_issue(
                owner="o", repo="r", title="t", body="b",
                labels=["feature"], milestone="9.9.9",
            )

        create_mock.assert_not_called()


# ---------------------------------------------------------------------------
# close_issue returns Issue (Phase C2)
# ---------------------------------------------------------------------------

class TestCloseIssueReturnShape:
    """#274 Phase C2 — close_issue returns the closed canonical Issue.
    Pre-Phase-C2 it returned None and the handler relied on the raw
    GraphQL dict from _gh_issues.close_issue (url + closed_at)."""

    @pytest.mark.asyncio
    async def test_returns_canonical_issue_with_url_and_updated_at(
        self, monkeypatch
    ):
        from datetime import datetime
        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="I_abc",
            kind="issue", owner="o", repo="r", number=42,
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.close_issue",
            AsyncMock(return_value={
                "url": "https://github.com/o/r/issues/42",
                "closed_at": "2026-04-23T17:00:00Z",
            }),
        )
        issue = adapter.close_issue(ref)
        result = await issue
        assert result.state == "closed"
        assert result.url == "https://github.com/o/r/issues/42"
        assert result.updated_at == datetime(
            2026, 4, 23, 17, 0, 0,
            tzinfo=result.updated_at.tzinfo,
        )
        # ref echoed through unchanged
        assert result.ref.native_id == "I_abc"


# ---------------------------------------------------------------------------
# get_issue_body / get_discussion_body (Phase C1)
# ---------------------------------------------------------------------------

class TestGetBodyByRef:
    """#274 Phase C1 — node-ID-based body fetch. Lets handlers that
    have an issue_id / discussion_id (not a number) fetch the current
    body for size-guardrail checks."""

    @pytest.mark.asyncio
    async def test_get_issue_body_delegates_to_gh_layer(self, monkeypatch):
        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="I_x", kind="issue",
            owner="o", repo="r",
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.issues.get_issue_body",
            AsyncMock(return_value="the body"),
        )
        body = await adapter.get_issue_body(ref)
        assert body == "the body"

    @pytest.mark.asyncio
    async def test_get_discussion_body_delegates_to_gh_layer(self, monkeypatch):
        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="D_x", kind="discussion",
            owner="o", repo="r",
        )
        monkeypatch.setattr(
            "forge_manager_mcp.github.discussions.get_discussion_body",
            AsyncMock(return_value="discussion body"),
        )
        body = await adapter.get_discussion_body(ref)
        assert body == "discussion body"


# ---------------------------------------------------------------------------
# compute_drift stub (Phase 6 will implement)
# ---------------------------------------------------------------------------

class TestComputeDriftStub:
    @pytest.mark.asyncio
    async def test_returns_clean_report(self):
        adapter = GitHubAdapter(token="fake")
        report = await adapter.compute_drift({})
        assert report.platform_id == "github"
        assert report.is_clean is True


class TestProjectBoardErrorWrap:
    """3.4.2 fix — every GitHubAdapter project-board method normalizes
    legacy ``GitHubError`` (raised by ``forge_manager_mcp.github.projects``
    helpers) into the canonical ``ForgeError`` Protocol contract so
    handler-helper code can catch a single exception type. Pre-3.4.2
    the raw GitHubError leaked past `except ForgeError` clauses, masking
    canonical-success outcomes (notably in
    `_attach_to_project_board_if_supported`)."""

    @pytest.mark.asyncio
    async def test_add_to_project_board_wraps_github_error(self, monkeypatch):
        from forge_manager_mcp.adapters import github as gh_mod
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github.core import GitHubError

        async def _raise(*a, **kw):
            raise GitHubError("HTTP 403")

        monkeypatch.setattr(gh_mod, "__name__", gh_mod.__name__)
        # Monkey-patch the indirect import the adapter uses
        from forge_manager_mcp.github import projects as gh_projects
        monkeypatch.setattr(gh_projects, "add_item_to_project", _raise)

        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="I_x", kind="issue",
            owner="o", repo="r", number=1,
        )
        with pytest.raises(ForgeError, match="HTTP 403"):
            await adapter.add_to_project_board(board_id="PVT_x", ref=ref)

    @pytest.mark.asyncio
    async def test_get_project_status_field_wraps_github_error(self, monkeypatch):
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as gh_projects
        from forge_manager_mcp.github.core import GitHubError

        async def _raise(*a, **kw):
            raise GitHubError("HTTP 403")

        monkeypatch.setattr(gh_projects, "get_project_status_field", _raise)
        adapter = GitHubAdapter(token="fake")
        with pytest.raises(ForgeError, match="HTTP 403"):
            await adapter.get_project_status_field(board_id="PVT_x")

    @pytest.mark.asyncio
    async def test_get_project_item_id_wraps_github_error(self, monkeypatch):
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as gh_projects
        from forge_manager_mcp.github.core import GitHubError

        async def _raise(*a, **kw):
            raise GitHubError("HTTP 403")

        monkeypatch.setattr(gh_projects, "get_project_item_id", _raise)
        adapter = GitHubAdapter(token="fake")
        ref = ArtifactRef(
            platform_id="github", native_id="I_x", kind="issue",
            owner="o", repo="r", number=1,
        )
        with pytest.raises(ForgeError, match="HTTP 403"):
            await adapter.get_project_item_id(ref=ref, board_id="PVT_x")

    @pytest.mark.asyncio
    async def test_move_project_item_wraps_github_error(self, monkeypatch):
        from forge_manager_mcp.adapters.errors import ForgeError
        from forge_manager_mcp.github import projects as gh_projects
        from forge_manager_mcp.github.core import GitHubError

        async def _raise(*a, **kw):
            raise GitHubError("HTTP 403")

        monkeypatch.setattr(gh_projects, "move_project_item", _raise)
        adapter = GitHubAdapter(token="fake")
        with pytest.raises(ForgeError, match="HTTP 403"):
            await adapter.move_project_item(
                board_id="PVT_x", item_id="PVTI_x",
                status_field_id="PVTSSF_x", option_id="OPT_x",
            )


class TestBootstrapProject:
    """Multi-platform scaffold C2 first stage — GitHubAdapter.bootstrap_project.

    Method is implemented but the capability flag stays False until
    stage 2 wires it into scaffold_project_multi's dispatch. Tests
    cover the method in isolation by monkey-patching the github.scaffold
    helpers (no live GraphQL calls)."""

    @staticmethod
    def _stub_stage_2b_i(monkeypatch):
        """Install canonical-happy-path stubs for the C2 stage 2b-i
        project-board calls. Used by every test that runs past the
        Discussion-categories check (where stage 2b-i fires)."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def _list_projects(token, owner_id):
            return []

        async def _create_project(token, owner_id, title):
            return {
                "id": f"PVT_{title}", "number": 1,
                "url": f"https://github.com/orgs/o/projects/1",
                "title": title,
            }

        async def _link_project(token, project_id, repo_id):
            return True

        async def _get_status(token, project_id):
            return {
                "field_id": "PVTSSF_x",
                "options": {"Todo": "OPT_t", "In Progress": "OPT_p", "Done": "OPT_d"},
            }

        async def _update_status(token, project_id, field_id, desired):
            return {
                "field_id": field_id,
                "options": {n: f"OPT_{n}" for n in desired},
                "changed": True,
            }

        monkeypatch.setattr(gh_mod._gh_projects, "list_owner_projects", _list_projects)
        monkeypatch.setattr(gh_mod._gh_projects, "create_projectv2", _create_project)
        monkeypatch.setattr(gh_mod._gh_projects, "link_projectv2_to_repo", _link_project)
        monkeypatch.setattr(gh_mod._gh_projects, "get_project_status_field", _get_status)
        monkeypatch.setattr(
            gh_mod._gh_projects, "update_projectv2_status_options", _update_status,
        )

    @staticmethod
    def _stub_stage_2b_ii(monkeypatch):
        """Install canonical-happy-path stubs for the C2 stage 2b-ii
        Discussion seeding calls."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def _create_discussion(token, repo_id, category_id, title, body):
            return {
                "id": f"D_{title.replace(' ', '_')}",
                "number": 1,
                "url": "https://github.com/x/y/discussions/1",
            }

        monkeypatch.setattr(gh_mod._gh_discussions, "create_discussion", _create_discussion)

    @pytest.mark.asyncio
    async def test_missing_org_returns_awaiting_manual(self, monkeypatch):
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return None  # org missing

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="ghost-org", project_name="widgets", description="",
        )
        assert result.platform_id == "github"
        assert result.phase == "awaiting_manual"
        assert any("does not exist" in s for s in result.manual_steps)
        assert result.artifacts["org_id"] is None

    @pytest.mark.asyncio
    async def test_creates_repo_trio_and_seeds_labels(self, monkeypatch):
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        repos_created: list[tuple[str, str]] = []
        labels_seeded_per_repo: dict[str, list[str]] = {}

        async def fake_get_org_id(token, login):
            return "O_widgets"

        async def fake_get_repo_node_id(token, owner, name):
            # All three repos new — raise so creation fires.
            raise _errs.ForgeError("not found")

        async def fake_create_repository(token, *, owner_id, name, visibility, description):
            repos_created.append((name, visibility))
            return {
                "id": f"R_{name}",
                "name_with_owner": f"acme/{name}",
                "url": f"https://github.com/acme/{name}",
            }

        async def fake_create_label(token, repo_id, label_name, color, label_desc):
            labels_seeded_per_repo.setdefault(repo_id, []).append(label_name)
            return {"id": f"LA_{label_name}"}

        # Stage 2a stubs — Discussions enabled, all required categories present.
        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "DIC_a", "isAnswerable": False},
                    "Architecture": {"id": "DIC_b", "isAnswerable": True},
                    "UX / UI": {"id": "DIC_c", "isAnswerable": True},
                    "Ideas": {"id": "DIC_d", "isAnswerable": False},
                    "claude-use-only": {"id": "DIC_e", "isAnswerable": False},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        # Stage 2b-i stubs — fresh board path.
        async def fake_list_projects(token, owner_id):
            return []  # no existing project

        async def fake_create_project(token, owner_id, title):
            return {
                "id": f"PVT_{title}", "number": 7,
                "url": f"https://github.com/orgs/acme/projects/7",
                "title": title,
            }

        async def fake_link_project(token, project_id, repo_id):
            return True

        async def fake_get_status(token, project_id):
            # Default GitHub Status options post-create.
            return {
                "field_id": "PVTSSF_x",
                "options": {"Todo": "OPT_t", "In Progress": "OPT_p", "Done": "OPT_d"},
            }

        async def fake_update_status(token, project_id, field_id, desired):
            return {
                "field_id": field_id,
                "options": {n: f"OPT_{n}" for n in desired},
                "changed": True,
            }

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        monkeypatch.setattr(gh_mod._gh_projects, "list_owner_projects", fake_list_projects)
        monkeypatch.setattr(gh_mod._gh_projects, "create_projectv2", fake_create_project)
        monkeypatch.setattr(gh_mod._gh_projects, "link_projectv2_to_repo", fake_link_project)
        monkeypatch.setattr(gh_mod._gh_projects, "get_project_status_field", fake_get_status)
        monkeypatch.setattr(
            gh_mod._gh_projects, "update_projectv2_status_options", fake_update_status,
        )
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="widgets!",
        )

        # All three repos created.
        assert {n for n, _ in repos_created} == {"widgets-dev", "widgets", "widgets-docs"}
        # dev is private; public + docs are public.
        priv = next(v for n, v in repos_created if n == "widgets-dev")
        assert priv == "PRIVATE"
        for n in ("widgets", "widgets-docs"):
            assert next(v for nn, v in repos_created if nn == n) == "PUBLIC"
        # Labels seeded on dev + public (not docs — docs is the rendered site).
        assert "R_widgets-dev" in labels_seeded_per_repo
        assert "R_widgets" in labels_seeded_per_repo
        assert "R_widgets-docs" not in labels_seeded_per_repo
        for repo_id in ("R_widgets-dev", "R_widgets"):
            assert "bug" in labels_seeded_per_repo[repo_id]
            assert "rfc" in labels_seeded_per_repo[repo_id]
            assert "area:mcp" in labels_seeded_per_repo[repo_id]
        # C2 fully absorbed → phase = complete (no manual_steps
        # since the canonical-happy-path stubs satisfy every step).
        assert result.phase == "complete"
        assert result.manual_steps == []

    @pytest.mark.asyncio
    async def test_idempotent_when_repos_exist(self, monkeypatch):
        from forge_manager_mcp.adapters import github as gh_mod

        creates: list[str] = []

        async def fake_get_org_id(token, login):
            return "O_widgets"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"  # exists

        async def fake_create_repository(token, *, owner_id, name, **kwargs):
            creates.append(name)
            return {"id": f"R_{name}", "name_with_owner": f"acme/{name}", "url": ""}

        async def fake_create_label(token, repo_id, label_name, color, label_desc):
            return {"id": f"LA_{label_name}"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "1", "isAnswerable": False},
                    "Architecture": {"id": "2", "isAnswerable": True},
                    "UX / UI": {"id": "3", "isAnswerable": True},
                    "Ideas": {"id": "4", "isAnswerable": False},
                    "claude-use-only": {"id": "5", "isAnswerable": False},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        assert creates == []  # nothing created — all probed-as-existing.
        assert result.artifacts["dev_repo"]["created_now"] is False
        assert result.artifacts["public_repo"]["created_now"] is False
        assert result.artifacts["docs_repo"]["created_now"] is False

    @pytest.mark.asyncio
    async def test_rejects_empty_owner_or_project_name(self):
        from forge_manager_mcp.adapters import errors as _errs
        adapter = GitHubAdapter(token="fake")
        with pytest.raises(_errs.ForgeError, match="owner"):
            await adapter.bootstrap_project(
                owner=" ", project_name="widgets", description="",
            )
        with pytest.raises(_errs.ForgeError, match="project_name"):
            await adapter.bootstrap_project(
                owner="acme", project_name="", description="",
            )

    @pytest.mark.asyncio
    async def test_enables_discussions_when_disabled(self, monkeypatch):
        """C2 stage 2a — Discussions enable absorption.

        When the dev repo has Discussions disabled, bootstrap_project
        calls enable_discussions then re-fetches state. Pre-fetch
        returns enabled=False, post-enable fetch returns enabled=True
        + the auto-created Announcements category."""
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            raise _errs.ForgeError("not found")

        async def fake_create_repository(token, *, owner_id, name, **kwargs):
            return {
                "id": f"R_{name}", "name_with_owner": f"acme/{name}",
                "url": f"https://github.com/acme/{name}",
            }

        async def fake_create_label(token, repo_id, label_name, color, label_desc):
            return {"id": f"LA_{label_name}"}

        # Discussions state: first call returns disabled, second
        # returns enabled with the four required categories present.
        state_calls = {"count": 0}

        async def fake_get_state(token, repo_id):
            state_calls["count"] += 1
            if state_calls["count"] == 1:
                return {"enabled": False, "categories": {}}
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "DIC_a", "isAnswerable": False},
                    "Architecture": {"id": "DIC_b", "isAnswerable": True},
                    "UX / UI": {"id": "DIC_c", "isAnswerable": True},
                    "Ideas": {"id": "DIC_d", "isAnswerable": False},
                    "claude-use-only": {"id": "DIC_e", "isAnswerable": False},
                },
            }

        enable_calls: list[str] = []

        async def fake_enable(token, repo_id):
            enable_calls.append(repo_id)
            return True

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        assert enable_calls == ["R_widgets-dev"]
        assert result.artifacts["discussions"]["enabled"] is True
        assert result.artifacts["discussions"]["enabled_now"] is True
        assert "Architecture" in result.artifacts["discussions"]["categories"]
        # All required categories present + canonical-happy-path stubs
        # → phase=complete after C2 absorption.
        assert result.phase == "complete"
        assert not any("Discussion categories missing" in s for s in result.manual_steps)

    @pytest.mark.asyncio
    async def test_skips_enable_when_discussions_already_on(self, monkeypatch):
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": "x"}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Architecture": {"id": "1", "isAnswerable": True},
                    "UX / UI": {"id": "2", "isAnswerable": True},
                    "Ideas": {"id": "3", "isAnswerable": False},
                    "claude-use-only": {"id": "4", "isAnswerable": False},
                    "Announcements": {"id": "5", "isAnswerable": False},
                },
            }

        enable_called: list[str] = []

        async def fake_enable(token, repo_id):
            enable_called.append(repo_id)
            return True

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        # enable_discussions NOT called (idempotent — already enabled).
        assert enable_called == []
        assert result.artifacts["discussions"]["enabled_now"] is False

    @pytest.mark.asyncio
    async def test_project_board_created_with_canonical_status_options(
        self, monkeypatch,
    ):
        """C2 stage 2b-i — Project board absorption.

        Fresh-bootstrap path: project doesn't exist, gets created,
        Status field gets read-diff-written from the GitHub default
        (Todo / In Progress / Done) to the canonical
        (Backlog / In Progress / In Review / Done / Parked)."""
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": ""}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    n: {"id": f"DIC_{n}", "isAnswerable": False}
                    for n in ("Announcements", "Architecture", "UX / UI",
                              "Ideas", "claude-use-only")
                },
            }

        async def fake_enable(token, repo_id):
            return True

        # Project board: doesn't exist; create returns; GitHub default
        # Status options post-create; update_status replaces with canonical.
        list_calls: list[str] = []
        update_calls: list[tuple[str, list[str]]] = []

        async def fake_list_projects(token, owner_id):
            list_calls.append(owner_id)
            return []

        async def fake_create_project(token, owner_id, title):
            return {
                "id": f"PVT_{title}", "number": 7,
                "url": "https://github.com/orgs/acme/projects/7",
                "title": title,
            }

        async def fake_link_project(token, project_id, repo_id):
            return True

        async def fake_get_status(token, project_id):
            return {
                "field_id": "PVTSSF_x",
                "options": {"Todo": "OPT_t", "In Progress": "OPT_p", "Done": "OPT_d"},
            }

        async def fake_update_status(token, project_id, field_id, desired):
            update_calls.append((field_id, list(desired)))
            return {
                "field_id": field_id,
                "options": {n: f"OPT_{n}" for n in desired},
                "changed": True,
            }

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        monkeypatch.setattr(gh_mod._gh_projects, "list_owner_projects", fake_list_projects)
        monkeypatch.setattr(gh_mod._gh_projects, "create_projectv2", fake_create_project)
        monkeypatch.setattr(gh_mod._gh_projects, "link_projectv2_to_repo", fake_link_project)
        monkeypatch.setattr(gh_mod._gh_projects, "get_project_status_field", fake_get_status)
        monkeypatch.setattr(
            gh_mod._gh_projects, "update_projectv2_status_options", fake_update_status,
        )
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        # Project board absorbed in artifacts.
        assert "project_board" in result.artifacts
        board = result.artifacts["project_board"]
        assert board["created_now"] is True
        assert board["status_options"]["Backlog"] == "OPT_Backlog"
        assert board["status_options"]["In Progress"] == "OPT_In Progress"
        # update_projectv2_status_options was called with the canonical list.
        assert len(update_calls) == 1
        assert update_calls[0][1] == [
            "Backlog", "In Progress", "In Review", "Done", "Parked",
        ]

    @pytest.mark.asyncio
    async def test_project_board_custom_status_surfaces_manual_step(
        self, monkeypatch,
    ):
        """When a pre-existing board has custom Status options that
        match neither the canonical set nor GitHub's default, surface
        a manual-step note rather than clobbering the operator's
        existing Status assignments."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": ""}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    n: {"id": f"DIC_{n}", "isAnswerable": False}
                    for n in ("Announcements", "Architecture", "UX / UI",
                              "Ideas", "claude-use-only")
                },
            }

        async def fake_enable(token, repo_id):
            return True

        async def fake_list_projects(token, owner_id):
            # Pre-existing board with custom Status options.
            return [{
                "id": "PVT_existing", "number": 3, "title": "widgets",
                "url": "https://github.com/orgs/acme/projects/3",
            }]

        async def fake_create_project(*args, **kwargs):
            raise AssertionError("should not create — board already exists")

        async def fake_link_project(token, project_id, repo_id):
            return True

        async def fake_get_status(token, project_id):
            # Custom set — not canonical, not GitHub-default.
            return {
                "field_id": "PVTSSF_y",
                "options": {"Active": "1", "Blocked": "2", "Resolved": "3"},
            }

        update_called = False

        async def fake_update_status(*args, **kwargs):
            nonlocal update_called
            update_called = True
            return {}

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        monkeypatch.setattr(gh_mod._gh_projects, "list_owner_projects", fake_list_projects)
        monkeypatch.setattr(gh_mod._gh_projects, "create_projectv2", fake_create_project)
        monkeypatch.setattr(gh_mod._gh_projects, "link_projectv2_to_repo", fake_link_project)
        monkeypatch.setattr(gh_mod._gh_projects, "get_project_status_field", fake_get_status)
        monkeypatch.setattr(
            gh_mod._gh_projects, "update_projectv2_status_options", fake_update_status,
        )
        self._stub_stage_2b_ii(monkeypatch)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        assert result.artifacts["project_board"]["created_now"] is False
        # update was NOT called — operator state preserved.
        assert update_called is False
        # Manual step explains the custom-options situation.
        joined = "\n".join(result.manual_steps)
        assert "custom Status options" in joined
        assert "⋯ → Settings" in joined

    @pytest.mark.asyncio
    async def test_seeds_discussions_when_existing_state_empty(self, monkeypatch):
        """C2 stage 2b-ii — Project Index + Session Lock Discussions
        seeded when existing_state doesn't carry their IDs."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": ""}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "DIC_announce", "isAnswerable": False},
                    "Architecture": {"id": "DIC_arch", "isAnswerable": True},
                    "UX / UI": {"id": "DIC_ux", "isAnswerable": True},
                    "Ideas": {"id": "DIC_ideas", "isAnswerable": False},
                    "claude-use-only": {"id": "DIC_cuo", "isAnswerable": False},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        create_discussion_calls: list[tuple[str, str]] = []

        async def fake_create_discussion(token, repo_id, category_id, title, body):
            create_discussion_calls.append((category_id, title))
            return {
                "id": f"D_{title.replace(' ', '_')}",
                "number": len(create_discussion_calls),
                "url": f"https://github.com/x/y/discussions/{len(create_discussion_calls)}",
            }

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        monkeypatch.setattr(gh_mod._gh_discussions, "create_discussion", fake_create_discussion)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        # Both Discussions seeded under Announcements.
        assert len(create_discussion_calls) == 2
        for category_id, _title in create_discussion_calls:
            assert category_id == "DIC_announce"
        titles = {t for _, t in create_discussion_calls}
        assert "widgets — Project" in titles
        assert "widgets — Session Lock" in titles

        assert result.artifacts["project_discussion_id"] == "D_widgets_—_Project"
        assert result.artifacts["session_lock_discussion_id"] == "D_widgets_—_Session_Lock"
        assert result.artifacts["project_discussion_created_now"] is True
        assert result.artifacts["session_lock_created_now"] is True
        # Phase = complete since no manual_step warnings.
        assert result.phase == "complete"

    @pytest.mark.asyncio
    async def test_seeds_discussions_skipped_when_existing_state_has_ids(
        self, monkeypatch,
    ):
        """When existing_state carries prior project_discussion_id +
        session_lock_discussion_id, the adapter reuses them and
        does NOT call create_discussion. Idempotency-via-state-
        threading from the multi-platform handler."""
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": ""}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "DIC_a", "isAnswerable": False},
                    "Architecture": {"id": "1", "isAnswerable": True},
                    "UX / UI": {"id": "2", "isAnswerable": True},
                    "Ideas": {"id": "3", "isAnswerable": False},
                    "claude-use-only": {"id": "4", "isAnswerable": False},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        create_called: list[str] = []

        async def fake_create_discussion(*args, **kwargs):
            create_called.append("called")
            return {"id": "D_unexpected", "number": 0, "url": ""}

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)
        self._stub_stage_2b_i(monkeypatch)
        monkeypatch.setattr(gh_mod._gh_discussions, "create_discussion", fake_create_discussion)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
            existing_state={
                "github": {
                    "project_discussion_id": "D_PRIOR_Project",
                    "session_lock_discussion_id": "D_PRIOR_SessionLock",
                },
            },
        )

        # No create_discussion calls — both reused from existing_state.
        assert create_called == []
        assert result.artifacts["project_discussion_id"] == "D_PRIOR_Project"
        assert result.artifacts["session_lock_discussion_id"] == "D_PRIOR_SessionLock"
        assert result.artifacts["project_discussion_created_now"] is False
        assert result.artifacts["session_lock_created_now"] is False
        assert result.phase == "complete"

    @pytest.mark.asyncio
    async def test_pauses_when_required_categories_missing(self, monkeypatch):
        """When required Discussion categories are missing, the
        method returns awaiting_manual with copy-pasteable instructions
        naming exactly which categories the operator must create."""
        from forge_manager_mcp.adapters import errors as _errs
        from forge_manager_mcp.adapters import github as gh_mod

        async def fake_get_org_id(token, login):
            return "O_acme"

        async def fake_get_repo_node_id(token, owner, name):
            return f"R_{name}"

        async def fake_create_repository(token, **kwargs):
            return {"id": "X", "name_with_owner": "acme/X", "url": "x"}

        async def fake_create_label(*args, **kwargs):
            return {"id": "LA"}

        async def fake_get_state(token, repo_id):
            # Only Announcements + Architecture present.
            return {
                "enabled": True,
                "categories": {
                    "Announcements": {"id": "1", "isAnswerable": False},
                    "Architecture": {"id": "2", "isAnswerable": True},
                },
            }

        async def fake_enable(token, repo_id):
            return True

        monkeypatch.setattr(gh_mod._gh_scaffold, "get_organization_id", fake_get_org_id)
        monkeypatch.setattr(gh_mod._gh_resolvers, "get_repo_node_id", fake_get_repo_node_id)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_repository", fake_create_repository)
        monkeypatch.setattr(gh_mod._gh_scaffold, "create_label", fake_create_label)
        monkeypatch.setattr(gh_mod._gh_scaffold, "get_repo_discussions_state", fake_get_state)
        monkeypatch.setattr(gh_mod._gh_scaffold, "enable_discussions", fake_enable)

        adapter = GitHubAdapter(token="fake")
        result = await adapter.bootstrap_project(
            owner="acme", project_name="widgets", description="",
        )

        assert result.phase == "awaiting_manual"
        # Pause-on-categories surfaces the missing names + URL.
        joined = "\n".join(result.manual_steps)
        assert "Discussion categories missing" in joined
        # The missing list explicitly names the three NOT present.
        # Pull it out by parsing — the message has the form
        # "missing on <repo>: <name>, <name>, <name>. ..."
        missing_segment = joined.split("missing on ", 1)[1].split(".", 1)[0]
        assert "UX / UI" in missing_segment
        assert "Ideas" in missing_segment
        assert "claude-use-only" in missing_segment
        assert "Architecture" not in missing_segment  # already present
        assert "Announcements" not in missing_segment  # never required
        assert "/discussions/categories" in joined


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
