"""Tests for migrate_to_4_0 (Phase 3.6.0 D3 / #299)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from forge_manager_mcp.migrations.migrate_4_0 import (
    SCHEMA_VERSION_TARGET,
    apply_migration,
    detect_4_0_state,
    restore_to_targets,
    transform_config,
)


def _write_config(project_dir: Path, config: dict) -> Path:
    claude = project_dir / ".claude"
    claude.mkdir(parents=True, exist_ok=True)
    cp = claude / "forge-config.json"
    cp.write_text(json.dumps(config, indent=2))
    return cp


def _three_oh_with_categories() -> dict:
    return {
        "schema_version": "3.0",
        "platforms": [
            {"id": "github"},
            {"id": "codeberg"},
            {"id": "local"},
        ],
        "discussion_categories": {
            "Architecture": {"id": "DIC_kw_arch"},
            "Ideas": {"id": "DIC_kw_ideas"},
        },
    }


class TestTransformConfig:
    def test_moves_top_level_categories_onto_github(self):
        out = transform_config(_three_oh_with_categories(), github_idx=0)
        assert "discussion_categories" not in out
        assert out["schema_version"] == "4.0"
        gh = out["platforms"][0]
        assert gh["id"] == "github"
        assert gh["discussion_categories"]["Architecture"]["id"] == "DIC_kw_arch"

    def test_drops_categories_when_no_github(self):
        c = _three_oh_with_categories()
        c["platforms"] = [{"id": "codeberg"}]
        out = transform_config(c, github_idx=None)
        assert "discussion_categories" not in out
        assert out["platforms"][0].get("discussion_categories") is None

    def test_idempotent_on_4_0(self):
        c = {"schema_version": "4.0", "platforms": [{"id": "github"}]}
        out = transform_config(c, github_idx=None)
        assert out == c

    def test_does_not_overwrite_existing_per_platform_map(self):
        """If somehow a 4.0-shape platform already has its own
        discussion_categories AND a top-level one exists, prefer
        the per-platform (operator-curated) value."""
        c = _three_oh_with_categories()
        c["platforms"][0]["discussion_categories"] = {
            "Architecture": {"id": "DIC_already_set"},
        }
        out = transform_config(c, github_idx=0)
        assert (
            out["platforms"][0]["discussion_categories"]
            ["Architecture"]["id"]
        ) == "DIC_already_set"


class TestDetect:
    def test_no_config_clean(self, tmp_path):
        plan = detect_4_0_state(tmp_path)
        assert plan.is_clean is True
        assert "no forge-config.json" in plan.warnings[0]

    def test_already_4_0_clean(self, tmp_path):
        _write_config(tmp_path, {
            "schema_version": "4.0",
            "platforms": [{"id": "github"}],
        })
        plan = detect_4_0_state(tmp_path)
        assert plan.is_clean is True
        assert plan.current_schema == "4.0"

    def test_3_0_with_categories_needs_migration(self, tmp_path):
        _write_config(tmp_path, _three_oh_with_categories())
        plan = detect_4_0_state(tmp_path)
        assert plan.is_clean is False
        assert plan.current_schema == "3.0"
        assert plan.has_top_level_categories is True
        assert plan.github_platform_index == 0

    def test_3_0_without_github_warns(self, tmp_path):
        c = _three_oh_with_categories()
        c["platforms"] = [{"id": "codeberg"}]
        _write_config(tmp_path, c)
        plan = detect_4_0_state(tmp_path)
        assert plan.is_clean is False
        assert plan.github_platform_index is None
        assert any(
            "no GitHub platform entry" in w for w in plan.warnings
        )

    def test_malformed_json_clean_with_warning(self, tmp_path):
        claude = tmp_path / ".claude"
        claude.mkdir()
        (claude / "forge-config.json").write_text("not json")
        plan = detect_4_0_state(tmp_path)
        assert plan.is_clean is True
        assert any("malformed" in w for w in plan.warnings)


class TestApplyMigration:
    def test_apply_writes_4_0_config(self, tmp_path):
        cp = _write_config(tmp_path, _three_oh_with_categories())
        plan = detect_4_0_state(tmp_path)
        result = apply_migration(plan)
        assert result["success"] is True
        assert "backup_path" in result
        new_config = json.loads(cp.read_text())
        assert new_config["schema_version"] == "4.0"
        assert "discussion_categories" not in new_config
        assert (
            new_config["platforms"][0]["discussion_categories"]
            ["Architecture"]["id"]
        ) == "DIC_kw_arch"

    def test_apply_creates_backup(self, tmp_path):
        _write_config(tmp_path, _three_oh_with_categories())
        plan = detect_4_0_state(tmp_path)
        result = apply_migration(plan)
        backup = Path(result["backup_path"])
        assert backup.is_dir()
        assert "migration-4.0-" in backup.name
        backed_up_config = backup / ".claude" / "forge-config.json"
        assert backed_up_config.is_file()
        # The backup carries the pre-migration shape.
        bc = json.loads(backed_up_config.read_text())
        assert bc["schema_version"] == "3.0"
        assert "discussion_categories" in bc

    def test_apply_lists_transformations(self, tmp_path):
        _write_config(tmp_path, _three_oh_with_categories())
        plan = detect_4_0_state(tmp_path)
        result = apply_migration(plan)
        joined = "\n".join(result["transformations"])
        assert "Moved top-level discussion_categories" in joined
        assert "schema_version" in joined


class TestRollback:
    def test_round_trip(self, tmp_path):
        cp = _write_config(tmp_path, _three_oh_with_categories())
        plan = detect_4_0_state(tmp_path)
        result = apply_migration(plan)

        # Confirm migrated state.
        assert json.loads(cp.read_text())["schema_version"] == "4.0"

        rollback_result = restore_to_targets(
            Path(result["backup_path"]), project_dir=tmp_path,
        )
        assert rollback_result["success"] is True

        # Restored to pre-migration state.
        restored = json.loads(cp.read_text())
        assert restored["schema_version"] == "3.0"
        assert "discussion_categories" in restored

    def test_missing_backup(self, tmp_path):
        result = restore_to_targets(
            tmp_path / "nonexistent", project_dir=tmp_path,
        )
        assert result["success"] is False


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
