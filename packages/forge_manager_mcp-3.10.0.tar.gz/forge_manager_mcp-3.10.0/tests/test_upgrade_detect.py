"""Tests for upgrade.detect (#373 / 3.8.0 D2.1 / Discussion #12).

Pure-effect probes + the aggregator are exercised against tmp_path
scaffolding for the project repo + state dir + config payload; the
PyPI probe + daemon /health are monkeypatched.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from forge_manager_mcp import version_coord
from forge_manager_mcp.upgrade import detect


# ---------------------------------------------------------------------------
# probe_mcp_version (delegates to version_coord.compute_drift)
# ---------------------------------------------------------------------------

class TestProbeMcpVersion:
    def _stub_compute(self, monkeypatch, **kwargs):
        defaults = {
            "installed": "3.7.1",
            "required": "3.7.1",
            "pypi_latest": "3.7.1",
            "pypi_probed_at": None,
            "status": "match",
            "severity": "info",
            "recommendation": None,
            "message": None,
        }
        defaults.update(kwargs)

        class _Snap:
            pass

        snap = _Snap()
        for k, v in defaults.items():
            setattr(snap, k, v)
        monkeypatch.setattr(version_coord, "compute_drift", lambda **_: snap)

    def test_match_status_no_repair(self, monkeypatch):
        self._stub_compute(monkeypatch)
        d = detect.probe_mcp_version(project_dir=None, state_dir=None)
        assert d.source == "mcp_version"
        assert d.status == "match"
        assert d.repair_type == "none"

    def test_behind_routes_to_pipx_upgrade(self, monkeypatch):
        self._stub_compute(
            monkeypatch,
            installed="3.6.0", required="3.7.1",
            status="behind", severity="warn",
            message="...", recommendation="pipx upgrade forge-manager-mcp",
        )
        d = detect.probe_mcp_version(project_dir=None, state_dir=None)
        assert d.status == "behind"
        assert d.repair_type == "pipx_upgrade"
        assert d.severity == "warn"


# ---------------------------------------------------------------------------
# probe_daemon_version
# ---------------------------------------------------------------------------

class TestProbeDaemonVersion:
    def test_unknown_when_state_dir_missing(self):
        d = detect.probe_daemon_version(None)
        assert d.source == "daemon_version"
        assert d.status == "unknown"

    def test_unknown_when_no_discovery_file(self, tmp_path):
        d = detect.probe_daemon_version(tmp_path)
        assert d.status == "unknown"
        assert "isn't running" in (d.message or "")

    def test_match_when_daemon_version_aligns(self, tmp_path, monkeypatch):
        # Discovery file points at a /health endpoint we mock to
        # return the same version as the installed MCP.
        (tmp_path / "daemon.json").write_text(
            json.dumps({"port": 12345, "pid": 1, "version": "3.7.1"})
        )

        class _MockResp:
            def __init__(self, payload):
                self._payload = payload

            def __enter__(self): return self
            def __exit__(self, *a): pass
            def read(self): return json.dumps(self._payload).encode()

        def _fake_urlopen(url, timeout=None):
            return _MockResp({"version": version_coord.MCP_VERSION})

        monkeypatch.setattr(
            detect.urllib.request, "urlopen", _fake_urlopen,
        )
        # json.load reads .read() — patch json.load to use payload directly
        monkeypatch.setattr(
            detect.json, "load",
            lambda r: {"version": version_coord.MCP_VERSION},
        )

        d = detect.probe_daemon_version(tmp_path)
        assert d.status == "match"
        assert d.repair_type == "none"

    def test_behind_when_daemon_version_lower(self, tmp_path, monkeypatch):
        (tmp_path / "daemon.json").write_text(
            json.dumps({"port": 12345, "pid": 1, "version": "3.6.0"})
        )

        class _MockResp:
            def __enter__(self): return self
            def __exit__(self, *a): pass

        def _fake_urlopen(url, timeout=None): return _MockResp()

        monkeypatch.setattr(
            detect.urllib.request, "urlopen", _fake_urlopen,
        )
        monkeypatch.setattr(
            detect.json, "load", lambda r: {"version": "3.6.0"},
        )
        monkeypatch.setattr(version_coord, "MCP_VERSION", "3.7.1")

        d = detect.probe_daemon_version(tmp_path)
        assert d.status == "behind"
        assert d.repair_type == "daemon_restart"
        assert d.recommendation == "forge-manager-mcp daemon-restart"

    def test_unknown_when_daemon_unreachable(self, tmp_path, monkeypatch):
        (tmp_path / "daemon.json").write_text(
            json.dumps({"port": 12345, "pid": 1, "version": "3.7.1"})
        )

        def _fail(*a, **kw):
            raise OSError("connection refused")

        monkeypatch.setattr(detect.urllib.request, "urlopen", _fail)

        d = detect.probe_daemon_version(tmp_path)
        assert d.status == "unknown"
        assert "unreachable" in (d.message or "")


# ---------------------------------------------------------------------------
# probe_schema_version
# ---------------------------------------------------------------------------

class TestProbeSchemaVersion:
    def test_unknown_when_no_payload(self):
        d = detect.probe_schema_version(None)
        assert d.source == "schema_version"
        assert d.status == "unknown"

    def test_match_when_at_latest(self):
        d = detect.probe_schema_version(
            {"schema_version": detect.LATEST_SCHEMA_VERSION},
        )
        assert d.status == "match"
        assert d.repair_type == "none"

    def test_behind_when_legacy_schema(self):
        d = detect.probe_schema_version({"schema_version": "3.0"})
        assert d.status == "behind"
        assert d.repair_type == "schema_migration"
        assert d.severity == "warn"
        assert d.recommendation == "migrate_to_4_0"

    def test_legacy_default_when_field_absent(self):
        # Pre-3.0 configs lack schema_version entirely; default to
        # "3.0" and surface as behind so the migrator runs.
        d = detect.probe_schema_version({})
        assert d.current == "3.0"
        assert d.status == "behind"


# ---------------------------------------------------------------------------
# Stub probes
# ---------------------------------------------------------------------------

class TestStubbedProbes:
    def test_skill_prose_returns_unknown_for_now(self):
        d = detect.probe_skill_prose(None)
        assert d.source == "skill_prose"
        assert d.status == "unknown"

    def test_project_rules_returns_unknown_for_now(self):
        d = detect.probe_project_rules(None)
        assert d.source == "project_rules"
        assert d.status == "unknown"

    def test_claude_md_returns_unknown_for_now(self):
        d = detect.probe_claude_md(None)
        assert d.source == "claude_md"
        assert d.status == "unknown"


# ---------------------------------------------------------------------------
# Aggregator
# ---------------------------------------------------------------------------

class TestAggregate:
    def test_aggregate_returns_six_drifts_in_display_order(
        self, monkeypatch, tmp_path,
    ):
        class _Snap:
            installed = "3.7.1"
            required = "3.7.1"
            pypi_latest = "3.7.1"
            pypi_probed_at = None
            status = "match"
            severity = "info"
            recommendation = None
            message = None

        monkeypatch.setattr(version_coord, "compute_drift", lambda **_: _Snap())

        drifts = detect.aggregate(
            project_dir=tmp_path, state_dir=tmp_path,
            config_payload={"schema_version": "4.0"},
        )

        assert [d.source for d in drifts] == [
            "mcp_version", "daemon_version", "schema_version",
            "skill_prose", "project_rules", "claude_md",
        ]


# ---------------------------------------------------------------------------
# Summary roll-up
# ---------------------------------------------------------------------------

class TestSummary:
    def _drift(self, **kwargs):
        return detect.Drift(
            source=kwargs.get("source", "x"),
            current=kwargs.get("current"),
            target=kwargs.get("target"),
            status=kwargs.get("status", "match"),
            severity=kwargs.get("severity", "info"),
            repair_type=kwargs.get("repair_type", "none"),
            message=kwargs.get("message"),
            recommendation=kwargs.get("recommendation"),
        )

    def test_summary_counts_by_status_and_severity(self):
        drifts = [
            self._drift(status="match"),
            self._drift(status="behind", severity="warn"),
            self._drift(status="behind", severity="warn"),
            self._drift(status="unknown"),
        ]
        s = detect.summary(drifts)
        assert s["by_status"] == {"match": 1, "behind": 2, "unknown": 1}
        assert s["by_severity"] == {"info": 2, "warn": 2}
        assert s["needs_repair"] == 2

    def test_summary_handles_empty_drifts(self):
        s = detect.summary([])
        assert s["by_status"] == {}
        assert s["by_severity"] == {}
        assert s["needs_repair"] == 0


# ---------------------------------------------------------------------------
# to_dict serialization
# ---------------------------------------------------------------------------

class TestToDict:
    def test_to_dict_carries_every_field(self):
        d = detect.Drift(
            source="src", current="3.6.0", target="3.7.1",
            status="behind", severity="warn", repair_type="pipx_upgrade",
            message="Upgrade required.",
            recommendation="pipx upgrade forge-manager-mcp",
        )
        payload = detect.to_dict(d)
        for key in (
            "source", "current", "target", "status", "severity",
            "repair_type", "message", "recommendation",
        ):
            assert key in payload
        assert payload["source"] == "src"
        assert payload["repair_type"] == "pipx_upgrade"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
