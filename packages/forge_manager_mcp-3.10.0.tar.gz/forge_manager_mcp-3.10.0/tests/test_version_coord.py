"""Tests for version_coord (#372 / 3.8.0 D1 / Discussion #8).

Pure-effect helpers + the compute_drift orchestrator are exercised
against tmp_path scaffolding for the project repo + state dir; the
PyPI probe is monkeypatched to avoid network access.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from forge_manager_mcp import version_coord


# ---------------------------------------------------------------------------
# read_required_version
# ---------------------------------------------------------------------------

class TestReadRequiredVersion:
    def _make_skill_md(self, project_dir: Path, body: str) -> Path:
        skill_dir = project_dir / ".claude" / "skills" / "forge-manager"
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_md = skill_dir / "SKILL.md"
        skill_md.write_text(body, encoding="utf-8")
        return skill_md

    def test_none_when_project_dir_is_none(self):
        assert version_coord.read_required_version(None) is None

    def test_none_when_skill_md_missing(self, tmp_path):
        assert version_coord.read_required_version(tmp_path) is None

    def test_parses_version_header(self, tmp_path):
        self._make_skill_md(tmp_path, "# forge-manager\n**Version:** 3.7.1\n")
        assert version_coord.read_required_version(tmp_path) == "3.7.1"

    def test_handles_pre_release_suffix(self, tmp_path):
        self._make_skill_md(tmp_path, "**Version:** 3.8.0a1\n")
        assert version_coord.read_required_version(tmp_path) == "3.8.0a1"

    def test_none_when_header_absent(self, tmp_path):
        self._make_skill_md(tmp_path, "# Some skill\nNo version line here.\n")
        assert version_coord.read_required_version(tmp_path) is None


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

class TestPyPICache:
    def test_read_returns_none_when_state_dir_is_none(self):
        assert version_coord.read_pypi_cache(None) == (None, None)

    def test_read_returns_none_when_file_missing(self, tmp_path):
        assert version_coord.read_pypi_cache(tmp_path) == (None, None)

    def test_write_then_read_roundtrips(self, tmp_path):
        now = datetime.now(timezone.utc)
        version_coord.write_pypi_cache(tmp_path, "3.8.0", now)
        version, fetched_at = version_coord.read_pypi_cache(tmp_path)
        assert version == "3.8.0"
        assert fetched_at == now

    def test_read_returns_raw_value_regardless_of_staleness(self, tmp_path):
        old = datetime.now(timezone.utc) - timedelta(hours=12)
        version_coord.write_pypi_cache(tmp_path, "3.8.0", old)
        version, fetched_at = version_coord.read_pypi_cache(tmp_path)
        # read_pypi_cache returns the raw value; freshness check
        # lives in is_cache_fresh so probe_pypi_latest can fall back
        # to a stale value on network failure.
        assert version == "3.8.0"
        assert fetched_at == old
        assert version_coord.is_cache_fresh(fetched_at) is False

    def test_read_handles_malformed_json(self, tmp_path):
        (tmp_path / "pypi-version.json").write_text("not json")
        assert version_coord.read_pypi_cache(tmp_path) == (None, None)


# ---------------------------------------------------------------------------
# probe_pypi_latest
# ---------------------------------------------------------------------------

class TestProbePyPILatest:
    def test_uses_fresh_cache_without_network(self, tmp_path, monkeypatch):
        now = datetime.now(timezone.utc)
        version_coord.write_pypi_cache(tmp_path, "3.7.1", now)

        def _explode(*args, **kwargs):
            raise AssertionError("network call must not happen on cache hit")

        monkeypatch.setattr(version_coord.urllib.request, "urlopen", _explode)
        version, _ = version_coord.probe_pypi_latest(tmp_path)
        assert version == "3.7.1"

    def test_falls_back_to_stale_cache_on_network_failure(
        self, tmp_path, monkeypatch,
    ):
        old = datetime.now(timezone.utc) - timedelta(hours=12)
        version_coord.write_pypi_cache(tmp_path, "3.6.0", old)

        def _fail(*args, **kwargs):
            raise OSError("network down")

        monkeypatch.setattr(version_coord.urllib.request, "urlopen", _fail)
        version, fetched_at = version_coord.probe_pypi_latest(tmp_path)
        # Stale cache surfaces — better than nothing.
        assert version == "3.6.0"
        assert fetched_at == old


# ---------------------------------------------------------------------------
# compute_drift
# ---------------------------------------------------------------------------

class TestComputeDrift:
    def _stub_pypi(self, monkeypatch, version: str | None):
        def _stub(state_dir):
            return version, (
                datetime.now(timezone.utc) if version else None
            )
        monkeypatch.setattr(version_coord, "probe_pypi_latest", _stub)

    def _stub_required(self, monkeypatch, version: str | None):
        def _stub(project_dir):
            return version
        monkeypatch.setattr(version_coord, "read_required_version", _stub)

    def _stub_mcp(self, monkeypatch, version: str):
        monkeypatch.setattr(version_coord, "MCP_VERSION", version)

    def test_match_status_when_versions_align(self, monkeypatch, tmp_path):
        self._stub_mcp(monkeypatch, "3.7.1")
        self._stub_required(monkeypatch, "3.7.1")
        self._stub_pypi(monkeypatch, "3.7.1")

        drift = version_coord.compute_drift(
            project_dir=tmp_path, state_dir=tmp_path,
        )
        assert drift.status == "match"
        assert drift.severity == "info"
        assert drift.message is None
        assert drift.recommendation is None

    def test_behind_status_when_installed_lt_required(
        self, monkeypatch, tmp_path,
    ):
        self._stub_mcp(monkeypatch, "3.6.0")
        self._stub_required(monkeypatch, "3.7.1")
        self._stub_pypi(monkeypatch, "3.7.1")

        drift = version_coord.compute_drift(
            project_dir=tmp_path, state_dir=tmp_path,
        )
        assert drift.status == "behind"
        assert drift.severity == "warn"
        assert drift.message is not None
        assert "3.7.1" in drift.message
        assert "3.6.0" in drift.message
        assert drift.recommendation == "pipx upgrade forge-manager-mcp"

    def test_ahead_status_when_installed_gt_required(
        self, monkeypatch, tmp_path,
    ):
        self._stub_mcp(monkeypatch, "3.8.0")
        self._stub_required(monkeypatch, "3.7.1")
        self._stub_pypi(monkeypatch, "3.7.1")

        drift = version_coord.compute_drift(
            project_dir=tmp_path, state_dir=tmp_path,
        )
        # Mid-release window — silent per OQ4 closure.
        assert drift.status == "ahead"
        assert drift.severity == "info"
        assert drift.message is None

    def test_unknown_status_when_required_absent(self, monkeypatch, tmp_path):
        self._stub_mcp(monkeypatch, "3.7.1")
        self._stub_required(monkeypatch, None)
        self._stub_pypi(monkeypatch, "3.7.1")

        drift = version_coord.compute_drift(
            project_dir=tmp_path, state_dir=tmp_path,
        )
        assert drift.status == "unknown"
        assert drift.severity == "info"
        assert drift.message is None

    def test_severity_override_tightens_warn_to_fail(
        self, monkeypatch, tmp_path,
    ):
        self._stub_mcp(monkeypatch, "3.6.0")
        self._stub_required(monkeypatch, "3.7.1")
        self._stub_pypi(monkeypatch, "3.7.1")

        drift = version_coord.compute_drift(
            project_dir=tmp_path, state_dir=tmp_path,
            severity_override="fail",
        )
        # Project rule tightened the gate from default warn to fail
        # per Discussion #8 OQ2 closure path c.
        assert drift.severity == "fail"
        assert drift.status == "behind"

    def test_message_flags_pre_publish_window(self, monkeypatch, tmp_path):
        # Project requires 3.8.0; PyPI latest is 3.7.1; installed is
        # 3.7.1. Operator can't upgrade yet — wait for publish or build
        # from source.
        self._stub_mcp(monkeypatch, "3.7.1")
        self._stub_required(monkeypatch, "3.8.0")
        self._stub_pypi(monkeypatch, "3.7.1")

        drift = version_coord.compute_drift(
            project_dir=tmp_path, state_dir=tmp_path,
        )
        assert drift.status == "behind"
        assert drift.message is not None
        assert "isn't on PyPI yet" in drift.message


# ---------------------------------------------------------------------------
# to_dict
# ---------------------------------------------------------------------------

class TestSerialization:
    def test_to_dict_carries_every_field(self, monkeypatch, tmp_path):
        monkeypatch.setattr(version_coord, "MCP_VERSION", "3.7.1")
        monkeypatch.setattr(
            version_coord, "read_required_version", lambda d: "3.7.1",
        )
        monkeypatch.setattr(
            version_coord, "probe_pypi_latest",
            lambda s: ("3.7.1", datetime.now(timezone.utc)),
        )

        drift = version_coord.compute_drift(
            project_dir=tmp_path, state_dir=tmp_path,
        )
        payload = version_coord.to_dict(drift)
        # Keys present + correct types — JSON-serializable contract.
        for key in (
            "installed", "required", "pypi_latest", "pypi_probed_at",
            "status", "severity", "recommendation", "message",
        ):
            assert key in payload


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
