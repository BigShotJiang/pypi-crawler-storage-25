"""Tests for the `daemon-status` / `open-ui` CLI subcommands (#335).

The MCP-server default mode (no subcommand) is exercised by
test_server.py + integration; we don't re-cover it here. These
tests focus on the new subcommand routing + output shapes.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone

import pytest

from forge_manager_mcp.daemon import discovery as discovery_mod
from forge_manager_mcp.daemon.discovery import (
    make_discovery_file, write_discovery,
)
from forge_manager_mcp.daemon_client import DaemonStatus
from forge_manager_mcp.server import cli as cli_mod


def _stub_df(**overrides):
    defaults = {
        "pid": 99999,
        "port": 51223,
        "version": "3.5.0",
        "started_at": datetime(2026, 5, 5, 12, 0, tzinfo=timezone.utc),
        "auth_token": "x" * 64,
    }
    defaults.update(overrides)
    return make_discovery_file(**defaults)


class TestDaemonStatus_Absent:
    def test_human_format_reports_absent(
        self, tmp_path, monkeypatch, capsys,
    ):
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status"])
        assert excinfo.value.code == 1
        out = capsys.readouterr().out
        assert "ABSENT" in out
        assert str(tmp_path) in out

    def test_json_format_reports_absent(
        self, tmp_path, monkeypatch, capsys,
    ):
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status", "--json"])
        assert excinfo.value.code == 1
        payload = json.loads(capsys.readouterr().out)
        assert payload["status"] == "absent"
        assert payload["state_dir"] == str(tmp_path)


class TestDaemonStatus_Running:
    def test_human_format_reports_running(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(port=51223, version="3.5.0"))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # Bypass /health probe — return RUNNING.
        from forge_manager_mcp.server import cli as _cli_mod
        monkeypatch.setattr(
            _cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "RUNNING" in out
        assert "3.5.0" in out
        assert "http://127.0.0.1:51223/" in out

    def test_json_format_reports_running(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(port=51223, version="3.5.0"))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status", "--json"])
        assert excinfo.value.code == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload["status"] == "running"
        assert payload["version"] == "3.5.0"
        assert payload["url"] == "http://127.0.0.1:51223/"


class TestDaemonStatus_Stale:
    def test_stale_exits_2_with_next_step(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df())
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.STALE,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-status"])
        assert excinfo.value.code == 2
        out = capsys.readouterr().out
        assert "STALE" in out
        assert "daemon-restart" in out


class TestOpenUi:
    def test_no_daemon_exits_1(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui"])
        assert excinfo.value.code == 1
        err = capsys.readouterr().err
        assert "No daemon running" in err

    def test_running_no_browser_prints_url(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(port=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui", "--no-browser"])
        assert excinfo.value.code == 0
        assert "http://127.0.0.1:12345/" in capsys.readouterr().out

    def test_running_launches_browser(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(port=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.RUNNING,
        )
        opened = {}
        # Stub webbrowser via sys.modules so the cli's import inside
        # _run_open_ui resolves to our fake.
        import types
        fake_wb = types.SimpleNamespace(
            open=lambda url: opened.setdefault("url", url),
        )
        monkeypatch.setitem(sys.modules, "webbrowser", fake_wb)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui"])
        assert excinfo.value.code == 0
        assert opened["url"] == "http://127.0.0.1:12345/"

    def test_stale_exits_2(self, tmp_path, monkeypatch, capsys):
        write_discovery(tmp_path, _stub_df())
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        monkeypatch.setattr(
            cli_mod, "probe_daemon", lambda sd: DaemonStatus.STALE,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["open-ui"])
        assert excinfo.value.code == 2
        err = capsys.readouterr().err
        assert "/health is unreachable" in err


class TestDaemonStop:
    """#339 — `forge-manager-mcp daemon-stop`."""

    def test_no_daemon_exits_1(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 1
        assert "No daemon running" in capsys.readouterr().err

    def test_stale_pid_cleans_up_file(
        self, tmp_path, monkeypatch, capsys,
    ):
        write_discovery(tmp_path, _stub_df(pid=99999))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # First os.kill(pid, sig) raises ProcessLookupError → already gone.
        kill_calls = []
        def _kill(pid, sig):
            kill_calls.append((pid, sig))
            raise ProcessLookupError(f"no such process {pid}")
        import os as _os
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 0
        assert kill_calls[0][0] == 99999
        out = capsys.readouterr().out
        assert "stale discovery file" in out

    def test_clean_sigterm(self, tmp_path, monkeypatch, capsys):
        write_discovery(tmp_path, _stub_df(pid=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        # First kill = signal send (succeeds); subsequent kill(pid, 0) =
        # liveness probe that raises ProcessLookupError → process dead.
        sent = []
        liveness_probes = {"n": 0}
        def _kill(pid, sig):
            if sig == 0:
                liveness_probes["n"] += 1
                raise ProcessLookupError("dead")
            sent.append((pid, sig))
        import os as _os
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-stop"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "stopped via SIGTERM" in out

    def test_force_uses_sigkill(self, tmp_path, monkeypatch, capsys):
        import signal
        write_discovery(tmp_path, _stub_df(pid=12345))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )
        sent = []
        def _kill(pid, sig):
            if sig == 0:
                raise ProcessLookupError("dead")
            sent.append((pid, sig))
        import os as _os
        monkeypatch.setattr(_os, "kill", _kill)
        with pytest.raises(SystemExit):
            cli_mod.main(["daemon-stop", "--force"])
        assert any(sig == signal.SIGKILL for _, sig in sent)


class TestDaemonRestart:
    """#339 — `forge-manager-mcp daemon-restart`."""

    def test_restart_with_running_daemon(
        self, tmp_path, monkeypatch, capsys,
    ):
        from forge_manager_mcp.server import cli as _cli_mod
        write_discovery(tmp_path, _stub_df(pid=11111))
        monkeypatch.setattr(
            cli_mod, "_resolve_state_dir", lambda args: tmp_path,
        )

        # Stub the stop path: kill returns ProcessLookupError so
        # the stop helper short-circuits + cleans up.
        import os as _os
        def _kill(pid, sig):
            raise ProcessLookupError("dead")
        monkeypatch.setattr(_os, "kill", _kill)

        # Stub spawn_daemon: write a fresh discovery file at a new port.
        spawn_calls = []
        def _spawn(sd, name, *, project_dir=None):
            spawn_calls.append({"sd": sd, "name": name, "project_dir": project_dir})
            write_discovery(sd, _stub_df(pid=22222, port=9999))
            return 22222
        monkeypatch.setattr(_cli_mod, "spawn_daemon", _spawn)
        monkeypatch.setattr(
            _cli_mod, "wait_for_discovery", lambda sd, timeout=5.0: True,
        )

        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main([
                "daemon-restart", "--project-dir", str(tmp_path / "proj"),
            ])
        assert excinfo.value.code == 0
        assert spawn_calls[0]["project_dir"] == tmp_path / "proj"
        out = capsys.readouterr().out
        assert "respawned" in out
        assert "PID=22222" in out


class TestDaemonLogs:
    """#339 — `forge-manager-mcp daemon-logs`."""

    def test_no_log_file_exits_1(self, tmp_path, monkeypatch, capsys):
        from forge_manager_mcp.daemon import paths as _paths
        monkeypatch.setattr(
            _paths, "log_dir", lambda name=None: tmp_path / "logs",
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-logs"])
        assert excinfo.value.code == 1
        assert "No log file" in capsys.readouterr().err

    def test_tail_default_lines(self, tmp_path, monkeypatch, capsys):
        from forge_manager_mcp.daemon import paths as _paths
        ld = tmp_path / "logs"
        ld.mkdir()
        log_path = ld / "forge-manager.log"
        log_path.write_text("\n".join(f"line{i}" for i in range(200)) + "\n")
        monkeypatch.setattr(
            _paths, "log_dir", lambda name=None: ld,
        )
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["daemon-logs", "-n", "5"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        # Last 5 lines should be 195..199.
        assert "line195" in out
        assert "line199" in out
        assert "line194" not in out


class TestCheckDesign:
    """#345 — `forge-manager-mcp check-design` CLI subcommand."""

    def test_clean_project_exits_0(self, tmp_path, monkeypatch, capsys):
        # tmp_path with no python files → no findings; should exit 0.
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design"])
        assert excinfo.value.code == 0
        out = capsys.readouterr().out
        assert "0 fail" in out

    def test_severity_filter_threshold(self, tmp_path, monkeypatch, capsys):
        # Severity filter set to fail; fewer findings shown.
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            cli_mod.main(["check-design", "--severity-filter", "fail"])
        # Empty project → zero findings even at filter=fail.
        assert excinfo.value.code == 0

    def test_diff_arg_prints_warning(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit):
            cli_mod.main(["check-design", "--diff", "main"])
        err = capsys.readouterr().err
        assert "3.5.x scope" in err


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
