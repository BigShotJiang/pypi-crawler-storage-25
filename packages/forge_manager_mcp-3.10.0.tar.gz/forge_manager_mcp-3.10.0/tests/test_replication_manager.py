"""Unit tests for ReplicationManager (3.0 / Phase 6 sub-run A).

Covers the orchestration shape: read-path failover ordering, write-
path local-first invariant, per-adapter state-machine transitions,
DEGRADED-skip behavior, and the queueing semantics for failed remote
writes. Real adapters aren't needed — the tests construct minimal
mock adapters that record calls.
"""
from __future__ import annotations

from typing import Any, ClassVar

import pytest

from forge_manager_mcp.adapters import errors as _adapter_errors
from forge_manager_mcp.replication import (
    AdapterState,
    AllAdaptersFailedError,
    MirrorWarning,
    ReplicationError,
    ReplicationManager,
    ReplicationWriteError,
    WriteResult,
)


# ---------------------------------------------------------------------------
# Mock adapter helpers
# ---------------------------------------------------------------------------

class _MockAdapter:
    """Minimal stand-in for a PlatformAdapter — records every method
    call on `.calls` so tests can assert on order + count."""

    def __init__(
        self,
        platform_id: str,
        *,
        fail_with: BaseException | None = None,
        return_value: Any = "ok",
    ):
        self.platform_id: str = platform_id
        self.fail_with = fail_with
        self.return_value = return_value
        self.calls: list[str] = []

    async def some_op(self, *args, **kwargs) -> Any:
        self.calls.append("some_op")
        if self.fail_with is not None:
            raise self.fail_with
        return self.return_value


def _manager_with(*adapters: _MockAdapter) -> ReplicationManager:
    return ReplicationManager(
        [(a.platform_id, a) for a in adapters],  # type: ignore[arg-type]
    )


class _StubConfig:
    """Stand-in for GithubConfig.coords_for_platform used by #296 tests.

    Real GithubConfig requires a populated forge-config.json shape;
    this stub exposes only the surface ReplicationManager needs.
    """

    def __init__(self, mapping: dict[tuple[str, str], tuple[str, str]]):
        self._mapping = mapping

    def coords_for_platform(
        self, platform_id: str, repo_role: str = "private",
    ) -> tuple[str, str]:
        return self._mapping.get((platform_id, repo_role), ("", ""))


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestConstruction:
    def test_empty_adapters_raises(self):
        with pytest.raises(ValueError, match="at least one adapter"):
            ReplicationManager([])

    def test_initial_states_all_healthy(self):
        m = _manager_with(_MockAdapter("local"), _MockAdapter("remote"))
        states = m.states()
        assert states == {"local": AdapterState.HEALTHY, "remote": AdapterState.HEALTHY}

    def test_canonical_returns_first(self):
        local = _MockAdapter("local")
        remote = _MockAdapter("remote")
        m = _manager_with(local, remote)
        assert m.canonical() is local


# ---------------------------------------------------------------------------
# Read-path failover
# ---------------------------------------------------------------------------

class TestReadFailover:
    @pytest.mark.asyncio
    async def test_first_healthy_wins(self):
        local = _MockAdapter("local", return_value="local-result")
        remote = _MockAdapter("remote", return_value="remote-result")
        m = _manager_with(local, remote)
        result = await m.read(lambda a, _: a.some_op())
        assert result == "local-result"
        assert local.calls == ["some_op"]
        assert remote.calls == []  # short-circuited

    @pytest.mark.asyncio
    async def test_unavailable_falls_through_to_next(self):
        local = _MockAdapter(
            "local",
            fail_with=_adapter_errors.ForgeUnavailableError("offline"),
        )
        remote = _MockAdapter("remote", return_value="remote-saved-the-day")
        m = _manager_with(local, remote)
        result = await m.read(lambda a, _: a.some_op())
        assert result == "remote-saved-the-day"
        # Local was tried + degraded; remote took over.
        assert m.states()["local"] == AdapterState.DEGRADED
        assert m.states()["remote"] == AdapterState.HEALTHY

    @pytest.mark.asyncio
    async def test_caller_fault_error_propagates(self):
        # Caller-fault error (not unavailable) must NOT trigger failover —
        # next adapter would fail identically; raise immediately so the
        # caller can fix the underlying problem.
        local = _MockAdapter(
            "local",
            fail_with=_adapter_errors.InvalidArtifactRefError("issue", "9999"),
        )
        remote = _MockAdapter("remote", return_value="remote-result")
        m = _manager_with(local, remote)
        with pytest.raises(_adapter_errors.InvalidArtifactRefError):
            await m.read(lambda a, _: a.some_op())
        assert remote.calls == []  # remote never consulted

    @pytest.mark.asyncio
    async def test_all_adapters_unavailable_raises_all_failed(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("a"),
        )
        remote = _MockAdapter(
            "remote", fail_with=_adapter_errors.ForgeUnavailableError("b"),
        )
        m = _manager_with(local, remote)
        with pytest.raises(AllAdaptersFailedError) as exc_info:
            await m.read(lambda a, _: a.some_op())
        # Both per-adapter errors captured.
        assert "local" in exc_info.value.errors
        assert "remote" in exc_info.value.errors

    @pytest.mark.asyncio
    async def test_degraded_adapters_skipped(self):
        local = _MockAdapter("local")
        remote = _MockAdapter("remote", return_value="should-not-reach")
        m = _manager_with(local, remote)
        # Pre-degrade local; should skip to remote.
        m._entries[0].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        result = await m.read(lambda a, _: a.some_op())
        assert result == "should-not-reach"  # i.e., remote did get called
        assert local.calls == []


# ---------------------------------------------------------------------------
# Write-path fan-out
# ---------------------------------------------------------------------------

class TestWriteFanOut:
    @pytest.mark.asyncio
    async def test_canonical_first_then_mirrors(self):
        local = _MockAdapter("local", return_value="canonical-result")
        m1 = _MockAdapter("mirror1")
        m2 = _MockAdapter("mirror2")
        m = _manager_with(local, m1, m2)
        result = await m.write(lambda a, _: a.some_op())
        # #297 — write() now returns WriteResult; .value carries the
        # canonical adapter's return.
        assert isinstance(result, WriteResult)
        assert result.value == "canonical-result"
        assert result.mirror_warnings == ()
        # All three got the call, local first.
        assert local.calls == ["some_op"]
        assert m1.calls == ["some_op"]
        assert m2.calls == ["some_op"]

    @pytest.mark.asyncio
    async def test_canonical_failure_is_fatal(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("local-down"),
        )
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        with pytest.raises(ReplicationWriteError) as exc_info:
            await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        assert exc_info.value.platform_id == "local"
        assert exc_info.value.operation == "create_issue"
        # Mirror was NOT attempted — local is canonical, fatal failure.
        assert mirror.calls == []
        assert m.states()["local"] == AdapterState.DEGRADED

    @pytest.mark.asyncio
    async def test_mirror_unavailable_does_not_fail_call(self):
        # A mirror going down should not affect the caller — the
        # canonical write succeeded, the mirror's failure becomes a
        # queued replay. #297 — surfaces as a MirrorWarning on the
        # WriteResult so the caller can see what didn't replicate.
        local = _MockAdapter("local", return_value="local-ok")
        mirror = _MockAdapter(
            "mirror", fail_with=_adapter_errors.ForgeUnavailableError("mirror-down"),
        )
        m = _manager_with(local, mirror)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="update_issue_body",
        )
        assert result.value == "local-ok"
        assert m.states()["mirror"] == AdapterState.DEGRADED
        assert m.pending_count("mirror") == 1
        # Warning surfaced on the envelope.
        assert len(result.mirror_warnings) == 1
        warning = result.mirror_warnings[0]
        assert warning.platform_id == "mirror"
        assert warning.operation == "update_issue_body"
        assert warning.error_type == "ForgeUnavailableError"
        assert "mirror-down" in warning.error_message

    @pytest.mark.asyncio
    async def test_mirror_legacy_github_403_drives_DEGRADED_transition(self):
        # (#362, 3.7.0 D1) Pre-#362 a GitHubError(status=403) raised
        # by the github/* layer fell through the
        # ``except ForgeUnavailableError`` class match in
        # ReplicationManager.write — last_error was recorded but the
        # state machine never transitioned to DEGRADED. Operator
        # dashboards showed every adapter as healthy indefinitely
        # while every write 403'd.
        #
        # Fix: predicate-based dispatch via ``is_forge_unavailable``,
        # which duck-types on ``status_code`` so legacy GitHubError-
        # shape exceptions classify correctly.
        legacy_403 = RuntimeError("GitHub API returned HTTP 403.")
        legacy_403.status_code = 403  # type: ignore[attr-defined]
        legacy_403.body = ""  # type: ignore[attr-defined]

        local = _MockAdapter("local", return_value="local-ok")
        github_mirror = _MockAdapter("github", fail_with=legacy_403)
        m = _manager_with(local, github_mirror)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="create_issue",
        )
        # Canonical write succeeded; the call returned cleanly.
        assert result.value == "local-ok"
        # State machine transitioned to DEGRADED (the bug-fix contract).
        assert m.states()["github"] == AdapterState.DEGRADED, (
            "GitHubError(status=403) must drive DEGRADED transition (#362)"
        )
        # Op queued for replay.
        assert m.pending_count("github") == 1
        # MirrorWarning surfaced with the original error_type for
        # downstream observability.
        assert len(result.mirror_warnings) == 1
        assert result.mirror_warnings[0].error_type == "RuntimeError"
        assert "403" in result.mirror_warnings[0].error_message

    @pytest.mark.asyncio
    async def test_mirror_fan_out_runs_concurrently(self):
        """(#273 F1, 3.7.0 D7) Mirror writes run in parallel via
        asyncio.gather — total wall-clock is bounded by max(latency)
        not sum(latency). Pre-F1 the loop awaited each mirror serially
        so a slow GitHub timeout (~5s under suspended-account 403)
        delayed every other mirror.

        Test assertion: each mirror's coroutine starts BEFORE any
        completes. Pre-F1 (sequential) the second mirror wouldn't
        start until the first returned; with F1 (gather) all three
        start, then complete.
        """
        import asyncio

        # Three slow mirrors that block on a barrier; without
        # parallelism, only one would be "in flight" at a time and
        # the gather below would deadlock waiting for the barrier.
        started = [asyncio.Event() for _ in range(3)]
        proceed = asyncio.Event()

        class StepAdapter:
            """Inline adapter with a `step(idx)` method that signals
            the matching `started[idx]` event then waits on
            `proceed`. The canonical (idx=-1) skips the wait so the
            mirror fan-out runs."""
            def __init__(self, platform_id: str, idx: int):
                self.platform_id = platform_id
                self._idx = idx

            async def step(self):
                if self._idx >= 0:
                    started[self._idx].set()
                    await proceed.wait()
                return f"ok-{self._idx}"

        local = StepAdapter("local", -1)  # canonical; no wait
        m1 = StepAdapter("m1", 0)
        m2 = StepAdapter("m2", 1)
        m3 = StepAdapter("m3", 2)
        m = _manager_with(local, m1, m2, m3)  # type: ignore[arg-type]

        # Schedule the write; it should not complete until proceed
        # is set, but all three mirrors should have STARTED.
        write_task = asyncio.create_task(
            m.write(lambda a, _: a.step(), operation_name="op"),
        )

        # Wait for all three to start. If the loop were serial, only
        # `started[0]` would set within the timeout.
        await asyncio.wait_for(
            asyncio.gather(*(e.wait() for e in started)),
            timeout=2.0,
        )
        # All three confirmed in flight before any completed.
        assert all(e.is_set() for e in started), (
            "all 3 mirrors must start concurrently (F1 contract)"
        )
        proceed.set()
        result = await write_task
        assert result.value == "ok--1"
        assert result.mirror_warnings == ()

    @pytest.mark.asyncio
    async def test_mirror_caller_fault_404_does_NOT_drive_DEGRADED(self):
        # (#362) Caller-fault errors (404 stale-ref, 422 validation)
        # must NOT trigger a state transition — the adapter is healthy,
        # the request is bad. #297 contract: record + queue + continue,
        # state stays unchanged.
        legacy_404 = RuntimeError("GitHub API returned HTTP 404.")
        legacy_404.status_code = 404  # type: ignore[attr-defined]
        legacy_404.body = ""  # type: ignore[attr-defined]

        local = _MockAdapter("local", return_value="local-ok")
        github_mirror = _MockAdapter("github", fail_with=legacy_404)
        m = _manager_with(local, github_mirror)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="update_issue_body",
        )
        assert result.value == "local-ok"
        # State stays HEALTHY — not a service-availability failure.
        assert m.states()["github"] == AdapterState.HEALTHY, (
            "404 caller-fault must NOT degrade adapter state (#362 contract)"
        )
        # Still surfaces as a MirrorWarning so the UI sees the failure.
        assert len(result.mirror_warnings) == 1
        # last_error_at populated even without state change.
        assert m._entries[1].last_error is legacy_404

    @pytest.mark.asyncio
    async def test_mirror_non_unavailable_error_does_not_propagate(self):
        # #297 — pre-fix: a non-Unavailable mirror error (HTTP 4xx,
        # malformed-body, adapter-coords-bug, etc.) propagated to the
        # caller, masking the canonical-success outcome. Now: recorded
        # as a MirrorWarning, queued for replay, surfaced on the
        # WriteResult — does NOT propagate.
        local = _MockAdapter("local", return_value="local-ok")
        mirror = _MockAdapter(
            "mirror", fail_with=_adapter_errors.InvalidArtifactRefError("repo", "x"),
        )
        m = _manager_with(local, mirror)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="create_issue",
        )
        # Canonical success surfaces — pre-#297 this was masked.
        assert result.value == "local-ok"
        assert local.calls == ["some_op"]
        assert mirror.calls == ["some_op"]
        # Mirror failure recorded as a warning, not raised.
        assert len(result.mirror_warnings) == 1
        warning = result.mirror_warnings[0]
        assert warning.platform_id == "mirror"
        assert warning.operation == "create_issue"
        assert warning.error_type == "InvalidArtifactRefError"
        # Mirror queued for replay — same shape as Unavailable path.
        assert m.pending_count("mirror") == 1

    @pytest.mark.asyncio
    async def test_mirror_warnings_for_multiple_failures(self):
        # Mixed failure modes across mirrors: one Unavailable, one
        # non-Unavailable. Both surface as warnings; both queue for
        # replay; canonical result returns clean.
        local = _MockAdapter("local", return_value="canonical-ok")
        m1 = _MockAdapter(
            "m1", fail_with=_adapter_errors.ForgeUnavailableError("m1-down"),
        )
        m2 = _MockAdapter(
            "m2", fail_with=_adapter_errors.InvalidArtifactRefError("repo", "y"),
        )
        m = _manager_with(local, m1, m2)
        result = await m.write(
            lambda a, _: a.some_op(), operation_name="append_comment",
        )
        assert result.value == "canonical-ok"
        # Both warnings present, in fan-out order.
        assert len(result.mirror_warnings) == 2
        assert {w.platform_id for w in result.mirror_warnings} == {"m1", "m2"}
        # Both queued.
        assert m.pending_count("m1") == 1
        assert m.pending_count("m2") == 1
        # m1 degraded (Unavailable convention); m2 stays healthy
        # because non-Unavailable doesn't trigger DEGRADED transition
        # (the error may be caller-fault that a future op shouldn't
        # automatically skip — DEGRADED is reserved for service-down).
        assert m.states()["m1"] == AdapterState.DEGRADED
        assert m.states()["m2"] == AdapterState.HEALTHY

    @pytest.mark.asyncio
    async def test_canonical_failure_still_propagates_after_297(self):
        # Regression guard: #297 changed mirror-failure semantics;
        # canonical-failure semantics MUST stay the same. A failed
        # canonical write is still fatal — local IS the source of
        # truth. ReplicationWriteError raises; WriteResult never
        # reaches the caller.
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.InvalidArtifactRefError("repo", "z"),
        )
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        with pytest.raises(ReplicationWriteError):
            await m.write(lambda a, _: a.some_op())
        # Mirror NOT attempted — fatal canonical failure short-circuits.
        assert mirror.calls == []

    @pytest.mark.asyncio
    async def test_pre_degraded_mirror_queues_without_call(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        # Pre-degrade the mirror.
        m._entries[1].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        await m.write(lambda a, _: a.some_op())
        # Mirror not called (already known degraded), but operation queued.
        assert mirror.calls == []
        assert m.pending_count("mirror") == 1


class TestPerPlatformCoords:
    """#296 — write/read thread per-platform coordinates so each
    adapter receives its OWN coords rather than a single set shared
    across all backends. Pre-#296, every adapter got the project's
    GitHub coords, causing Codeberg fan-out to 404 against Codeberg's
    API. The fix routes coords through ``config.coords_for_platform``
    per iteration.
    """

    @pytest.mark.asyncio
    async def test_each_adapter_receives_its_own_coords(self):
        """Multi-platform setup with diverging owner slugs — each
        adapter's lambda invocation MUST receive its own coords."""
        observed: dict[str, tuple[str, str]] = {}

        class _CoordAwareAdapter:
            def __init__(self, platform_id: str):
                self.platform_id = platform_id
                self.calls: list[str] = []

            async def some_op(self, *args, owner: str = "", repo: str = "", **kw):
                self.calls.append("some_op")
                observed[self.platform_id] = (owner, repo)
                return f"{self.platform_id}-result"

        local = _CoordAwareAdapter("local")
        github = _CoordAwareAdapter("github")
        codeberg = _CoordAwareAdapter("codeberg")

        config = _StubConfig({
            ("local", "private"): ("local-owner", "local-repo"),
            ("github", "private"): ("gh-owner", "gh-repo"),
            ("codeberg", "private"): ("cb-owner", "cb-repo"),
        })
        m = ReplicationManager(
            [("local", local), ("github", github), ("codeberg", codeberg)],  # type: ignore[arg-type]
            config=config,
        )

        await m.write(
            lambda a, c: a.some_op(owner=c[0], repo=c[1]),
            operation_name="some_op",
            repo_role="private",
        )

        # Each backend received its OWN coords — pre-#296 they all
        # would have been ("", "") (no config) or all the same
        # (single-tenant config field).
        assert observed["local"] == ("local-owner", "local-repo")
        assert observed["github"] == ("gh-owner", "gh-repo")
        assert observed["codeberg"] == ("cb-owner", "cb-repo")

    @pytest.mark.asyncio
    async def test_repo_role_param_threads_through(self):
        """`repo_role="public"` resolves coords from the public
        per-platform field, not private — proves the role parameter
        threads correctly."""
        observed: dict[str, str] = {}

        class _RoleAwareAdapter:
            def __init__(self, platform_id: str):
                self.platform_id = platform_id

            async def some_op(self, *args, owner: str = "", **kw):
                observed[self.platform_id] = owner
                return None

        local = _RoleAwareAdapter("local")
        github = _RoleAwareAdapter("github")

        config = _StubConfig({
            ("local", "private"): ("local-private", "x"),
            ("local", "public"): ("local-public", "y"),
            ("github", "private"): ("gh-private", "z"),
            ("github", "public"): ("gh-public", "w"),
        })
        m = ReplicationManager(
            [("local", local), ("github", github)],  # type: ignore[arg-type]
            config=config,
        )

        await m.write(
            lambda a, c: a.some_op(owner=c[0]),
            operation_name="some_op",
            repo_role="public",
        )

        assert observed == {"local": "local-public", "github": "gh-public"}

    @pytest.mark.asyncio
    async def test_no_config_falls_back_to_empty_coords(self):
        """When config is None (pre-bootstrap, test fixtures), each
        adapter receives ``("", "")``. Lambdas that fall back via
        ``c[0] or default`` see the default; safe for legacy paths."""
        observed: list[tuple[str, str]] = []

        async def op(adapter, coords):
            observed.append(coords)
            return adapter.return_value

        local = _MockAdapter("local")
        m = ReplicationManager([("local", local)])  # config defaults to None

        await m.write(op, operation_name="some_op")
        assert observed == [("", "")]


class TestOnCanonicalWriteHook:
    """The Hugo live-update hook fires once after every successful
    canonical write — wiring point for SiteRebuilder.notify."""

    @pytest.mark.asyncio
    async def test_hook_fires_after_canonical_success(self):
        local = _MockAdapter("local", return_value="ok")
        captured: list[str] = []
        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=captured.append,
        )
        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        assert captured == ["create_issue"]

    @pytest.mark.asyncio
    async def test_hook_does_not_fire_on_canonical_failure(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("down"),
        )
        captured: list[str] = []
        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=captured.append,
        )
        with pytest.raises(ReplicationWriteError):
            await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        # Hook MUST NOT fire on failure — rebuild on a failed write
        # would publish stale state.
        assert captured == []

    @pytest.mark.asyncio
    async def test_hook_error_doesnt_poison_canonical_write(self):
        """A broken hook (raising callback) doesn't fail the
        underlying write — the canonical store IS authoritative."""
        local = _MockAdapter("local", return_value="ok")

        def broken(name):
            raise RuntimeError("hook is broken")

        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=broken,
        )
        # Write completes cleanly despite the broken hook.
        result = await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        assert result.value == "ok"  # #297 — WriteResult envelope


# ---------------------------------------------------------------------------
# State machine transitions
# ---------------------------------------------------------------------------

class TestStateTransitions:
    def test_mark_healthy(self):
        local = _MockAdapter("local")
        m = _manager_with(local)
        m._entries[0].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        m._entries[0].last_error = ValueError("x")  # type: ignore[attr-defined]
        m.mark_healthy("local")
        assert m.states()["local"] == AdapterState.HEALTHY
        assert m._entries[0].last_error is None  # type: ignore[attr-defined]

    def test_mark_reconciling(self):
        m = _manager_with(_MockAdapter("local"))
        m.mark_reconciling("local")
        assert m.states()["local"] == AdapterState.RECONCILING

    def test_mark_unknown_platform_raises(self):
        m = _manager_with(_MockAdapter("local"))
        with pytest.raises(KeyError):
            m.mark_healthy("nonexistent")

    @pytest.mark.asyncio
    async def test_reconciling_skipped_in_read(self):
        local = _MockAdapter("local")
        remote = _MockAdapter("remote", return_value="from-remote")
        m = _manager_with(local, remote)
        m.mark_reconciling("local")
        result = await m.read(lambda a, _: a.some_op())
        assert result == "from-remote"


class TestStateTimestampTracking:
    """#333 — `_set_state` keeps `state_changed_at`, `last_error_at`,
    and `next_attempt_at` coherent across every transition."""

    def test_initial_state_has_state_changed_at(self):
        m = _manager_with(_MockAdapter("local"))
        entry = m._entries[0]  # type: ignore[attr-defined]
        assert entry.state_changed_at is not None
        assert entry.last_error_at is None
        assert entry.next_attempt_at is None

    def test_pause_sets_state_changed_at_clears_next_attempt(self):
        from forge_manager_mcp.replication.manager import _now
        m = _manager_with(_MockAdapter("local"))
        before = _now()
        m.pause("local")
        entry = m._entries[0]  # type: ignore[attr-defined]
        assert entry.state == AdapterState.PAUSED
        assert entry.state_changed_at >= before
        assert entry.next_attempt_at is None

    def test_resume_clears_error_fields(self):
        m = _manager_with(_MockAdapter("local"))
        m._entries[0].state = AdapterState.PAUSED  # type: ignore[attr-defined]
        m._entries[0].last_error = ValueError("from prior")  # type: ignore[attr-defined]
        m.resume("local")
        entry = m._entries[0]  # type: ignore[attr-defined]
        assert entry.state == AdapterState.HEALTHY
        assert entry.last_error is None
        assert entry.last_error_at is None
        assert entry.next_attempt_at is None

    def test_set_degraded_records_error_and_schedules_next_attempt(self):
        from datetime import timedelta
        from forge_manager_mcp.replication.manager import (
            DEGRADED_RECONCILIATION_CADENCE_SECONDS,
        )
        m = _manager_with(_MockAdapter("local"))
        entry = m._entries[0]  # type: ignore[attr-defined]
        exc = RuntimeError("boom")
        m._set_state(entry, AdapterState.DEGRADED, error=exc)  # type: ignore[attr-defined]
        assert entry.state == AdapterState.DEGRADED
        assert entry.last_error is exc
        assert entry.last_error_at == entry.state_changed_at
        assert entry.next_attempt_at == entry.state_changed_at + timedelta(
            seconds=DEGRADED_RECONCILIATION_CADENCE_SECONDS,
        )

    def test_set_reconciling_sets_next_attempt_now(self):
        m = _manager_with(_MockAdapter("local"))
        entry = m._entries[0]  # type: ignore[attr-defined]
        m._set_state(entry, AdapterState.RECONCILING)  # type: ignore[attr-defined]
        assert entry.state == AdapterState.RECONCILING
        assert entry.next_attempt_at == entry.state_changed_at

    def test_set_healthy_clears_error(self):
        m = _manager_with(_MockAdapter("local"))
        entry = m._entries[0]  # type: ignore[attr-defined]
        m._set_state(entry, AdapterState.DEGRADED, error=RuntimeError("x"))  # type: ignore[attr-defined]
        assert entry.last_error is not None
        m._set_state(entry, AdapterState.HEALTHY)  # type: ignore[attr-defined]
        assert entry.last_error is None
        assert entry.last_error_at is None
        assert entry.next_attempt_at is None

    def test_on_state_change_listener_fires(self):
        """#333 — daemon attaches a listener that publishes
        backend.state_changed events. _set_state must invoke it."""
        events: list = []
        m = _manager_with(_MockAdapter("local"))
        m.set_on_state_change(lambda entry: events.append(
            (entry.platform_id, entry.state),
        ))
        m._set_state(m._entries[0], AdapterState.DEGRADED, error=RuntimeError("x"))  # type: ignore[attr-defined]
        m._set_state(m._entries[0], AdapterState.HEALTHY)  # type: ignore[attr-defined]
        assert events == [
            ("local", AdapterState.DEGRADED),
            ("local", AdapterState.HEALTHY),
        ]

    def test_listener_failure_does_not_poison_state(self):
        """Listener exception is swallowed — state mutation still
        takes effect."""
        m = _manager_with(_MockAdapter("local"))
        def _broken(entry):
            raise RuntimeError("listener kaboom")
        m.set_on_state_change(_broken)
        # Should not raise.
        m._set_state(m._entries[0], AdapterState.PAUSED)  # type: ignore[attr-defined]
        assert m._entries[0].state == AdapterState.PAUSED  # type: ignore[attr-defined]

    def test_set_state_idempotent_refreshes_state_changed_at(self):
        """Re-asserting the same state still bumps state_changed_at —
        signals to the UI that the transition was observed (e.g.,
        a second auto-degrade on the same adapter)."""
        m = _manager_with(_MockAdapter("local"))
        entry = m._entries[0]  # type: ignore[attr-defined]
        m._set_state(entry, AdapterState.DEGRADED, error=RuntimeError("a"))  # type: ignore[attr-defined]
        ts1 = entry.state_changed_at
        # Force a measurable delta (datetime.now resolution).
        import time
        time.sleep(0.001)
        m._set_state(entry, AdapterState.DEGRADED, error=RuntimeError("b"))  # type: ignore[attr-defined]
        assert entry.state_changed_at > ts1
        assert str(entry.last_error) == "b"


class TestPauseResume:
    """Phase D3b.4c — operator-driven pause/resume via PAUSED state."""

    def test_pause_sets_paused(self):
        m = _manager_with(_MockAdapter("local"))
        m.pause("local")
        assert m.states()["local"] == AdapterState.PAUSED

    def test_pause_unknown_raises(self):
        m = _manager_with(_MockAdapter("local"))
        with pytest.raises(KeyError):
            m.pause("nonexistent")

    def test_resume_from_paused_returns_to_healthy(self):
        m = _manager_with(_MockAdapter("local"))
        m.pause("local")
        m.resume("local")
        assert m.states()["local"] == AdapterState.HEALTHY

    def test_resume_from_non_paused_is_noop(self):
        m = _manager_with(_MockAdapter("local"))
        m._entries[0].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        m.resume("local")
        # resume only fires HEALTHY transition from PAUSED state;
        # DEGRADED stays put (different transition path through
        # mark_healthy / mark_reconciling).
        assert m.states()["local"] == AdapterState.DEGRADED

    def test_resume_unknown_raises(self):
        m = _manager_with(_MockAdapter("local"))
        with pytest.raises(KeyError):
            m.resume("nonexistent")

    @pytest.mark.asyncio
    async def test_paused_skipped_in_read(self):
        local = _MockAdapter("local")
        remote = _MockAdapter("remote", return_value="from-remote")
        m = _manager_with(local, remote)
        m.pause("local")
        result = await m.read(lambda a, _: a.some_op())
        assert result == "from-remote"


# ---------------------------------------------------------------------------
# Healthy-adapters introspection
# ---------------------------------------------------------------------------

class TestIntrospection:
    def test_healthy_adapters_filters_out_degraded(self):
        m = _manager_with(_MockAdapter("a"), _MockAdapter("b"), _MockAdapter("c"))
        m._entries[1].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        m._entries[2].state = AdapterState.RECONCILING  # type: ignore[attr-defined]
        assert m.healthy_adapters() == ["a"]


# ---------------------------------------------------------------------------
# Error types
# ---------------------------------------------------------------------------

class TestErrorTypes:
    def test_replication_write_error_is_replication_error(self):
        assert issubclass(ReplicationWriteError, ReplicationError)

    def test_all_adapters_failed_is_replication_error(self):
        assert issubclass(AllAdaptersFailedError, ReplicationError)

    def test_all_adapters_failed_message_lists_causes(self):
        errors = {
            "local": _adapter_errors.ForgeUnavailableError("net"),
            "remote": _adapter_errors.ForgeUnavailableError("auth"),
        }
        exc = AllAdaptersFailedError(errors)
        msg = str(exc)
        assert "local" in msg and "remote" in msg
        assert exc.errors == errors


class TestReplayPendingWrites:
    """#274 Phase D — drain DEGRADED-adapter pending_writes once the
    backend is reachable again."""

    @staticmethod
    def _toggleable_adapter(platform_id: str):
        """A mock adapter whose probe()/some_op() can be flipped from
        unavailable → healthy mid-test by toggling ``self.online``."""
        class _T:
            def __init__(self, pid: str):
                self.platform_id = pid
                self.online = False
                self.replays: list[str] = []

            async def probe(self) -> bool:
                return self.online

            async def some_op(self, marker: str) -> str:
                if not self.online:
                    raise _adapter_errors.ForgeUnavailableError("offline")
                self.replays.append(marker)
                return marker
        return _T(platform_id)

    @pytest.mark.asyncio
    async def test_drains_when_probe_passes(self):
        canonical = _MockAdapter("local")
        remote = self._toggleable_adapter("remote")
        manager = _manager_with(canonical, remote)  # type: ignore[arg-type]

        # Two writes hit the canonical, fan out to remote which is
        # unavailable → both queue in pending_writes.
        for marker in ("first", "second"):
            await manager.write(
                lambda a, _, m=marker: a.some_op(m),
                operation_name="some_op",
            )
        assert manager.pending_count("remote") == 2
        assert manager.states()["remote"] == AdapterState.DEGRADED

        # Bring the remote back online and replay.
        remote.online = True
        report = await manager.replay_pending_writes()

        assert report["remote"]["queued_before"] == 2
        assert report["remote"]["replayed"] == 2
        assert report["remote"]["still_pending"] == 0
        assert manager.pending_count("remote") == 0
        # The op callable carried the original markers — replay
        # observed both.
        assert remote.replays == ["first", "second"]
        # Drain restored the adapter to HEALTHY.
        assert manager.states()["remote"] == AdapterState.HEALTHY

    @pytest.mark.asyncio
    async def test_probe_failure_leaves_queue_intact(self):
        canonical = _MockAdapter("local")
        remote = self._toggleable_adapter("remote")
        manager = _manager_with(canonical, remote)  # type: ignore[arg-type]

        await manager.write(
            lambda a, _: a.some_op("payload"),
            operation_name="some_op",
        )
        assert manager.pending_count("remote") == 1

        # Probe still fails — don't drain.
        report = await manager.replay_pending_writes()
        assert report["remote"]["probe_failed"] is True
        assert report["remote"]["replayed"] == 0
        assert report["remote"]["still_pending"] == 1
        assert manager.pending_count("remote") == 1
        # State stays DEGRADED.
        assert manager.states()["remote"] == AdapterState.DEGRADED

    @pytest.mark.asyncio
    async def test_canonical_excluded_from_drain(self):
        """The canonical store never has pending_writes (failed
        canonical writes raise immediately), so the report should
        omit it even when explicitly asked."""
        canonical = _MockAdapter("local")
        remote = self._toggleable_adapter("remote")
        manager = _manager_with(canonical, remote)  # type: ignore[arg-type]

        report = await manager.replay_pending_writes()
        assert "local" not in report

    @pytest.mark.asyncio
    async def test_partial_drain_when_replay_re_fails(self):
        """If the adapter probes healthy but a replayed op still
        fails with unavailable, that entry stays queued for next
        replay — it's not dropped."""
        canonical = _MockAdapter("local")

        class _Flaky:
            def __init__(self):
                self.platform_id = "remote"
                self.online = True
                self.fail_first = True

            async def probe(self) -> bool:
                return self.online

            async def some_op(self, *args, **kwargs):
                if self.fail_first:
                    self.fail_first = False
                    raise _adapter_errors.ForgeUnavailableError("flaky")
                return "ok"

        remote = _Flaky()
        manager = _manager_with(canonical, remote)  # type: ignore[arg-type]

        # Force two pending writes (set state DEGRADED so the writes
        # queue without trying).
        manager.mark_reconciling("remote")
        manager._entries[1].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        for _ in range(2):
            await manager.write(
                lambda a, _: a.some_op(),
                operation_name="some_op",
            )
        assert manager.pending_count("remote") == 2

        report = await manager.replay_pending_writes()
        assert report["remote"]["queued_before"] == 2
        # First op fails, second succeeds.
        assert report["remote"]["replayed"] == 1
        assert report["remote"]["failed"] == 1
        assert report["remote"]["still_pending"] == 1
        # Adapter still DEGRADED because the queue isn't fully drained.
        assert manager.states()["remote"] == AdapterState.DEGRADED


class TestLocalChangesSince:
    """#274 Phase D — time-window complement to compute_drifts.
    Delegates to canonical adapter's aggregate_history_since when
    available; raises NotImplementedError when canonical doesn't
    expose history (i.e., remote-only canonical configurations)."""

    @pytest.mark.asyncio
    async def test_delegates_to_canonical_when_method_present(self):
        from datetime import datetime, timezone

        class _HistoricalAdapter:
            platform_id = "local"

            def __init__(self):
                self.calls: list[dict] = []

            async def aggregate_history_since(
                self, *, since, kind=None, owner="", repo="",
            ):
                self.calls.append({
                    "since": since, "kind": kind,
                    "owner": owner, "repo": repo,
                })
                return ["sentinel-entry"]

        canonical = _HistoricalAdapter()
        manager = _manager_with(canonical)  # type: ignore[arg-type]

        marker = datetime.now(timezone.utc)
        result = await manager.local_changes_since(
            since=marker, kind="issue", owner="o", repo="r",
        )
        assert result == ["sentinel-entry"]
        assert len(canonical.calls) == 1
        assert canonical.calls[0]["since"] == marker
        assert canonical.calls[0]["kind"] == "issue"

    @pytest.mark.asyncio
    async def test_raises_when_canonical_lacks_method(self):
        from datetime import datetime, timezone

        # Plain _MockAdapter has no aggregate_history_since attribute.
        canonical = _MockAdapter("remote-canonical")
        manager = _manager_with(canonical)

        with pytest.raises(NotImplementedError, match="aggregate_history_since"):
            await manager.local_changes_since(since=datetime.now(timezone.utc))


class TestImportRemoteChanges:
    """#274 Phase D — orchestrator for the OQ4 import_remote_changes
    flow. Foundation only: tests use mocked source adapters; live
    fetch_remote_changes implementations are deferred per the
    project-level GitHub-defer directive."""

    @staticmethod
    def _stub_source(platform_id: str, changes: list):
        """Mock a remote source adapter with a configurable change feed."""

        class _Source:
            def __init__(self, pid, payload):
                self.platform_id = pid
                self._changes = list(payload)
                self.fetch_calls: list[dict] = []

            async def fetch_remote_changes(
                self, *, since, owner="", repo="",
            ):
                self.fetch_calls.append({
                    "since": since, "owner": owner, "repo": repo,
                })
                return list(self._changes)

        return _Source(platform_id, changes)

    @staticmethod
    def _stub_canonical():
        """Mock a canonical adapter with apply_remote_change. The mock
        records each change applied; configurable conflict-mode lets
        the test return ImportConflict for specific operations."""
        from forge_manager_mcp.adapters.types import ImportConflict

        class _Canonical:
            def __init__(self):
                self.platform_id = "local"
                self.applied: list = []
                self.conflict_on_op: str | None = None

            async def apply_remote_change(self, change):
                if self.conflict_on_op and change.operation == self.conflict_on_op:
                    return ImportConflict(
                        change=change,
                        reason="synthetic conflict for test",
                    )
                self.applied.append(change)
                return None

        return _Canonical()

    @pytest.mark.asyncio
    async def test_routes_changes_from_source_to_canonical(self):
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import ArtifactRef, RemoteChange

        ref = ArtifactRef(
            platform_id="github", native_id="I_x",
            kind="issue", owner="o", repo="r", number=1,
        )
        ts = datetime.now(timezone.utc)
        change = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="update_body", observed_at=ts,
            payload={"new_body": "imported"},
        )

        canonical = self._stub_canonical()
        source = self._stub_source("github", [change])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        report = await manager.import_remote_changes(
            source_platform_id="github", since=ts,
        )
        assert len(report.applied) == 1
        assert report.applied[0].operation == "update_body"
        assert report.conflicts == []
        assert canonical.applied == [change]
        # Source got the right since/owner/repo.
        assert source.fetch_calls[0]["since"] == ts

    @pytest.mark.asyncio
    async def test_conflicts_route_to_conflicts_list(self):
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import ArtifactRef, RemoteChange

        ref = ArtifactRef(
            platform_id="github", native_id="I_x",
            kind="issue", owner="o", repo="r", number=1,
        )
        ts = datetime.now(timezone.utc)
        clean = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="update_body", observed_at=ts,
        )
        conflicting = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="close_issue", observed_at=ts,
        )

        canonical = self._stub_canonical()
        canonical.conflict_on_op = "close_issue"
        source = self._stub_source("github", [clean, conflicting])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        report = await manager.import_remote_changes(
            source_platform_id="github", since=ts,
        )
        assert len(report.applied) == 1
        assert len(report.conflicts) == 1
        assert report.conflicts[0].change.operation == "close_issue"

    @pytest.mark.asyncio
    async def test_unknown_source_platform_raises(self):
        from datetime import datetime, timezone

        canonical = self._stub_canonical()
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(KeyError, match="bitbucket"):
            await manager.import_remote_changes(
                source_platform_id="bitbucket",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_canonical_as_source_raises(self):
        """Importing from the canonical itself is a programmer error
        — the canonical is the sink, not a remote source."""
        from datetime import datetime, timezone

        canonical = self._stub_canonical()
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(ValueError, match="canonical adapter"):
            await manager.import_remote_changes(
                source_platform_id="local",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_canonical_without_apply_method_raises(self):
        from datetime import datetime, timezone

        # Plain _MockAdapter has no apply_remote_change.
        canonical = _MockAdapter("local")
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(NotImplementedError, match="apply_remote_change"):
            await manager.import_remote_changes(
                source_platform_id="github",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_source_not_implemented_propagates(self):
        from datetime import datetime, timezone

        class _UnimplementedSource:
            platform_id = "github"
            async def fetch_remote_changes(self, *, since, owner="", repo=""):
                raise NotImplementedError("no fetch implementation yet")

        canonical = self._stub_canonical()
        source = _UnimplementedSource()
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(NotImplementedError, match="no fetch"):
            await manager.import_remote_changes(
                source_platform_id="github",
                since=datetime.now(timezone.utc),
            )


class TestBackgroundMirrorMode:
    """(#368) Async mirror fan-out: canonical succeeds → write returns
    immediately; mirror outcomes publish via the broadcaster. Eliminates
    the ReadTimeout false-positive class that was burying successful
    canonical writes in `.claude/pending-posts.md` whenever a remote
    mirror was slow / failing."""

    def _capture(self):
        events: list[tuple[str, dict]] = []

        def publisher(event_name: str, data: dict) -> None:
            events.append((event_name, data))

        return events, publisher

    async def _drain(self, ticks: int = 5) -> None:
        """Yield control so background tasks scheduled via
        ``asyncio.create_task`` can run + publish their events."""
        import asyncio
        for _ in range(ticks):
            await asyncio.sleep(0)

    @pytest.mark.asyncio
    async def test_canonical_returns_with_empty_mirror_warnings(self):
        local = _MockAdapter("local", return_value="local-ok")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        result = await m.write(
            lambda a, _: a.some_op(), operation_name="create_issue",
        )

        assert result.value == "local-ok"
        # Mirror warnings empty in background mode — outcomes flow via
        # broadcaster events, not the response envelope.
        assert result.mirror_warnings == ()
        await self._drain()

    @pytest.mark.asyncio
    async def test_background_mirror_actually_runs(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        _, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

        # Mirror was eventually called even though write() returned
        # before the mirror completed.
        assert mirror.calls == ["some_op"]

    @pytest.mark.asyncio
    async def test_publishes_mirror_completed_for_success(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

        completed = [e for e in events if e[0] == "mirror.completed"]
        assert len(completed) == 1
        assert completed[0][1] == {
            "platform_id": "mirror",
            "operation_name": "create_issue",
        }

    @pytest.mark.asyncio
    async def test_publishes_mirror_failed_for_failure(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter(
            "mirror",
            fail_with=_adapter_errors.ForgeUnavailableError("mirror-down"),
        )
        m = _manager_with(local, mirror)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

        failed = [e for e in events if e[0] == "mirror.failed"]
        assert len(failed) == 1
        payload = failed[0][1]
        assert payload["platform_id"] == "mirror"
        assert payload["operation_name"] == "create_issue"
        assert payload["error_type"] == "ForgeUnavailableError"
        assert "mirror-down" in payload["error_message"]

    @pytest.mark.asyncio
    async def test_publishes_fan_out_complete_summary(self):
        local = _MockAdapter("local")
        mirror_a = _MockAdapter("mirror_a")
        mirror_b = _MockAdapter(
            "mirror_b",
            fail_with=_adapter_errors.ForgeUnavailableError("b-down"),
        )
        m = _manager_with(local, mirror_a, mirror_b)
        events, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

        summary = [e for e in events if e[0] == "mirror.fan_out_complete"]
        assert len(summary) == 1
        assert summary[0][1] == {
            "operation_name": "create_issue",
            "success_count": 1,
            "failure_count": 1,
        }

    @pytest.mark.asyncio
    async def test_canonical_failure_still_raises_in_background_mode(self):
        local = _MockAdapter(
            "local",
            fail_with=_adapter_errors.ForgeError("canonical-down"),
        )
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        _, pub = self._capture()
        m.set_background_mirror_mode(publisher=pub)

        with pytest.raises(ReplicationWriteError):
            await m.write(
                lambda a, _: a.some_op(), operation_name="create_issue",
            )
        # Mirror was NOT scheduled — canonical fatality preserved.
        assert mirror.calls == []

    @pytest.mark.asyncio
    async def test_publisher_exception_does_not_crash_background_task(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)

        def bad_publisher(event_name, data):
            raise RuntimeError("publisher exploded")

        m.set_background_mirror_mode(publisher=bad_publisher)

        # Should not raise — the publisher exception is swallowed.
        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()

    @pytest.mark.asyncio
    async def test_no_publisher_is_acceptable(self):
        # Background mode should work even when no publisher is set
        # (the daemon may construct without one before wiring later).
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        m.set_background_mirror_mode(publisher=None)

        await m.write(lambda a, _: a.some_op(), operation_name="create_issue")
        await self._drain()
        assert mirror.calls == ["some_op"]


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
