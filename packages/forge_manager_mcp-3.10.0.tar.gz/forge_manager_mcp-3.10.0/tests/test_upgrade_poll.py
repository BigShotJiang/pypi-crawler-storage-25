"""Tests for upgrade.poll (#373 / 3.8.0 D2.6 / Discussion #12)."""
from __future__ import annotations

from datetime import datetime, timezone

import pytest

from forge_manager_mcp.upgrade import poll
from forge_manager_mcp.upgrade.detect import Drift


class TestShouldAlert:
    def test_first_poll_emits_when_repairs_needed(self):
        assert poll.should_alert(None, {"needs_repair": 3}) is True

    def test_first_poll_silent_when_no_repairs(self):
        assert poll.should_alert(None, {"needs_repair": 0}) is False

    def test_steady_state_silent(self):
        assert poll.should_alert(
            {"needs_repair": 2}, {"needs_repair": 2},
        ) is False

    def test_increase_emits(self):
        assert poll.should_alert(
            {"needs_repair": 1}, {"needs_repair": 3},
        ) is True

    def test_decrease_silent(self):
        # Operator just repaired something — don't re-alert.
        assert poll.should_alert(
            {"needs_repair": 3}, {"needs_repair": 1},
        ) is False


class TestMakeDriftAlert:
    def _drift(self, **kwargs):
        return Drift(
            source=kwargs.get("source", "x"),
            current=kwargs.get("current"),
            target=kwargs.get("target"),
            status=kwargs.get("status", "behind"),
            severity=kwargs.get("severity", "warn"),
            repair_type=kwargs.get("repair_type", "pipx_upgrade"),
            message=kwargs.get("message"),
            recommendation=kwargs.get("recommendation"),
        )

    def test_alert_carries_count_and_sources(self):
        drifts = [
            self._drift(source="mcp_version"),
            self._drift(source="schema_version"),
        ]
        alert = poll.make_drift_alert({"needs_repair": 2}, drifts)
        assert alert["level"] == "warning"
        assert "2 upgrades" in alert["message"]
        assert "mcp_version" in (alert["detail"] or "")
        assert "schema_version" in (alert["detail"] or "")
        assert alert["tags"] == ("upgrade", "drift_detected")

    def test_singular_pluralization(self):
        alert = poll.make_drift_alert(
            {"needs_repair": 1}, [self._drift()],
        )
        assert "1 upgrade " in alert["message"]
        assert "upgrades" not in alert["message"]

    def test_alert_omits_match_drifts_from_detail(self):
        drifts = [
            self._drift(source="mcp_version", status="behind"),
            self._drift(source="schema_version", status="match"),
        ]
        alert = poll.make_drift_alert({"needs_repair": 1}, drifts)
        assert "mcp_version" in (alert["detail"] or "")
        assert "schema_version" not in (alert["detail"] or "")

    def test_explicit_when_overrides_now(self):
        when = datetime(2026, 5, 8, 0, 0, tzinfo=timezone.utc)
        alert = poll.make_drift_alert(
            {"needs_repair": 1}, [self._drift()], when=when,
        )
        assert alert["timestamp"] == when.isoformat()


class TestPollLoop:
    @pytest.mark.asyncio
    async def test_loop_publishes_when_drift_grows(self, monkeypatch):
        published: list[dict] = []

        def _publisher(payload: dict) -> None:
            published.append(payload)

        # Aggregator stub: alternates between 1-needed and 2-needed.
        call_count = {"n": 0}

        class _Drift:
            def __init__(self, source, status):
                self.source = source
                self.status = status

        def _stub_aggregate(**_):
            call_count["n"] += 1
            if call_count["n"] == 1:
                return [_Drift("a", "behind")]
            return [_Drift("a", "behind"), _Drift("b", "behind")]

        def _stub_summary(drifts):
            n = sum(1 for d in drifts if d.status == "behind")
            return {"needs_repair": n, "by_status": {}, "by_severity": {}}

        from forge_manager_mcp.upgrade import detect
        monkeypatch.setattr(detect, "aggregate", _stub_aggregate)
        monkeypatch.setattr(detect, "summary", _stub_summary)

        await poll.poll_loop(
            project_dir=None, state_dir=None,
            config_provider=lambda: None,
            publisher=_publisher,
            interval_seconds=0,  # zero-sleep for test
            max_iterations=2,
        )

        # Iteration 1: needs_repair=1, prev=None → emit (1 > 0).
        # Iteration 2: needs_repair=2, prev=1 → emit (grew).
        assert len(published) == 2

    @pytest.mark.asyncio
    async def test_loop_silent_when_steady_state(self, monkeypatch):
        published: list[dict] = []

        class _Drift:
            def __init__(self, source, status):
                self.source = source
                self.status = status

        from forge_manager_mcp.upgrade import detect
        monkeypatch.setattr(
            detect, "aggregate",
            lambda **_: [_Drift("a", "behind")],
        )
        monkeypatch.setattr(
            detect, "summary",
            lambda drifts: {
                "needs_repair": 1, "by_status": {}, "by_severity": {},
            },
        )

        await poll.poll_loop(
            project_dir=None, state_dir=None,
            config_provider=lambda: None,
            publisher=lambda p: published.append(p),
            interval_seconds=0,
            max_iterations=3,
        )

        # First iteration emits (None → 1 needs_repair); subsequent
        # iterations stay silent.
        assert len(published) == 1

    @pytest.mark.asyncio
    async def test_loop_swallows_aggregate_exceptions(self, monkeypatch):
        from forge_manager_mcp.upgrade import detect

        def _explode(**_):
            raise RuntimeError("aggregate broke")

        monkeypatch.setattr(detect, "aggregate", _explode)

        # Loop must complete without raising despite aggregate
        # raising every iteration.
        await poll.poll_loop(
            project_dir=None, state_dir=None,
            config_provider=lambda: None,
            publisher=lambda p: None,
            interval_seconds=0,
            max_iterations=2,
        )

    @pytest.mark.asyncio
    async def test_loop_swallows_publisher_exceptions(self, monkeypatch):
        class _Drift:
            def __init__(self, source, status):
                self.source = source
                self.status = status

        from forge_manager_mcp.upgrade import detect
        monkeypatch.setattr(
            detect, "aggregate",
            lambda **_: [_Drift("a", "behind")],
        )
        monkeypatch.setattr(
            detect, "summary",
            lambda drifts: {
                "needs_repair": 1, "by_status": {}, "by_severity": {},
            },
        )

        def _bad_publisher(payload):
            raise RuntimeError("publisher down")

        await poll.poll_loop(
            project_dir=None, state_dir=None,
            config_provider=lambda: None,
            publisher=_bad_publisher,
            interval_seconds=0,
            max_iterations=2,
        )

    @pytest.mark.asyncio
    async def test_max_iterations_zero_returns_immediately(self):
        await poll.poll_loop(
            project_dir=None, state_dir=None,
            config_provider=lambda: None,
            publisher=lambda p: None,
            interval_seconds=0,
            max_iterations=0,
        )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
