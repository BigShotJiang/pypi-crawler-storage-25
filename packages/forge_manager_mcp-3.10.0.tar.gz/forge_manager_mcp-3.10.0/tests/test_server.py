"""
Unit tests for the server package — build-server fast-fail, tool
registration, and the `resolve_thread_identifier` dispatch helper.

The pure parsers (parse_skill_version, parse_changelog, semver_gt,
parse_owner_repo) live in test_parsers.py.

The IO-free utilities (SessionActivity, compose_session_summary,
meets_confidence_threshold, check_overwrite_size) live in
test_utils.py.

Full tool execution is covered in tests/tools/.
MCP protocol compliance is covered in tests/integration/.
"""

from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from forge_manager_mcp.adapters.types import ArtifactRef, Discussion, Issue
from forge_manager_mcp.config import ConfigError
from forge_manager_mcp.server import build_server
from forge_manager_mcp.server.helpers import resolve_thread_identifier


def _stub_canonical(*, issue_native: str = "issues/42", disc_native: str = "discussions/7"):
    """Minimal canonical PlatformAdapter stub.

    3.5.0 Phase C → 3.7.0 D8.9 — resolve_thread_identifier now
    dispatches through the daemon's `resolve_thread_identifier` op.
    The stub exposes get_issue / get_discussion so the bridge
    fixture's monkeypatched `dispatch_read` can drive the canonical
    lookup against the same shape.
    """
    issue = Issue(
        ref=ArtifactRef(
            platform_id="local-test",
            native_id=issue_native,
            kind="issue",
            owner="defowner",
            repo="defrepo",
            number=42,
        ),
        title="(stub)",
        body="(stub)",
        state="open",
        labels=[],
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    discussion = Discussion(
        ref=ArtifactRef(
            platform_id="local-test",
            native_id=disc_native,
            kind="discussion",
            owner="defowner",
            repo="defrepo",
            number=7,
        ),
        title="(stub)",
        body="(stub)",
        state="open",
        category="Architecture",
        created_at=datetime.now(timezone.utc),
    )
    return SimpleNamespace(
        platform_id="local-test",
        get_issue=AsyncMock(return_value=issue),
        get_discussion=AsyncMock(return_value=discussion),
    )


def _patch_dispatch_read_via_canonical(monkeypatch, canonical):
    """(#356, 3.7.0 D8.9) Bridge `dispatch_read("resolve_thread_
    identifier", ...)` to the test's canonical stub. Mirrors what
    the daemon op does server-side. Tests can still drive the
    canonical adapter mock to verify call-arg shape.
    """
    async def _stub(state_dir, op, args):
        if op != "resolve_thread_identifier":
            raise NotImplementedError(f"unexpected op: {op}")
        primary_id = args.get("primary_id") or ""
        if primary_id:
            return {"value": primary_id}
        number = args.get("number")
        if number is None:
            return {"value": ""}
        kind = args["kind"]
        owner = args["owner"]
        repo = args["repo"]
        if kind == "issue":
            issue = await canonical.get_issue(owner, repo, int(number))
            return {"value": issue.ref.native_id}
        if kind == "discussion":
            discussion = await canonical.get_discussion(
                owner, repo, int(number),
            )
            return {"value": discussion.ref.native_id}
        raise ValueError(f"Unsupported kind: {kind!r}")

    monkeypatch.setattr(
        "forge_manager_mcp.daemon_client.dispatch_read", _stub,
    )


class TestResolveThreadIdentifier:
    """#56 (original) + #309 / 3.5.0 Phase C (canonical-first refactor).

    resolve_thread_identifier translates either a primary-id arg or
    (number, owner, repo) into a canonical native_id. 3.5.0 dropped the
    GitHub-direct GraphQL roundtrip and routes number→ref through the
    canonical adapter. Tests verify the canonical is consulted and no
    GitHub call ever fires.
    """

    @pytest.mark.asyncio
    async def test_uses_node_id_when_provided(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        result = await resolve_thread_identifier(
            {"issue_id": "I_abc"},
            primary_id_param="issue_id",
            kind="issue",
            default_owner="owner",
            default_repo="repo",
        )
        assert result == "I_abc"
        canonical.get_issue.assert_not_called()
        canonical.get_discussion.assert_not_called()

    @pytest.mark.asyncio
    async def test_resolves_from_number_with_default_owner_repo(self, monkeypatch):
        canonical = _stub_canonical(issue_native="issues/42")
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        result = await resolve_thread_identifier(
            {"number": 42},
            primary_id_param="issue_id",
            kind="issue",
            default_owner="defowner",
            default_repo="defrepo",
        )
        assert result == "issues/42"
        canonical.get_issue.assert_called_once_with("defowner", "defrepo", 42)

    @pytest.mark.asyncio
    async def test_explicit_owner_repo_override_defaults(self, monkeypatch):
        canonical = _stub_canonical(disc_native="discussions/7")
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        result = await resolve_thread_identifier(
            {"number": 7, "owner": "alt", "repo": "altrepo"},
            primary_id_param="discussion_id",
            kind="discussion",
            default_owner="defowner",
            default_repo="defrepo",
        )
        assert result == "discussions/7"
        canonical.get_discussion.assert_called_once_with("alt", "altrepo", 7)

    @pytest.mark.asyncio
    async def test_both_forms_raises(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        with pytest.raises(ValueError, match="either"):
            await resolve_thread_identifier(
                {"issue_id": "I_abc", "number": 42},
                primary_id_param="issue_id",
                kind="issue",
                default_owner="owner",
                default_repo="repo",
            )

    @pytest.mark.asyncio
    async def test_neither_form_raises(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        with pytest.raises(ValueError, match="must be provided"):
            await resolve_thread_identifier(
                {},
                primary_id_param="issue_id",
                kind="issue",
                default_owner="owner",
                default_repo="repo",
            )

    @pytest.mark.asyncio
    async def test_non_integer_number_raises(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        with pytest.raises(ValueError, match="number must be"):
            await resolve_thread_identifier(
                {"number": "not_an_int"},
                primary_id_param="issue_id",
                kind="issue",
                default_owner="owner",
                default_repo="repo",
            )

    @pytest.mark.asyncio
    async def test_unknown_kind_raises(self, monkeypatch):
        canonical = _stub_canonical()
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        with pytest.raises(ValueError, match="Unsupported kind"):
            await resolve_thread_identifier(
                {"number": 1},
                primary_id_param="thread_id",
                kind="pull_request",
                default_owner="owner",
                default_repo="repo",
            )

    @pytest.mark.asyncio
    async def test_canonical_first_no_github_required(self, monkeypatch):
        """The post-3.5.0 contract: number-resolution succeeds without any
        GitHub credentials available — closes the bug class that caused
        every `close_issue_with_comment(number=...)` against the dev repo
        to fail with HTTP 403 + buffered while GitHub access was
        suspended (2026-04-28+).

        Post-D8.9 the resolution flows through the daemon's
        `resolve_thread_identifier` op rather than calling the
        canonical adapter directly. The bridge fixture preserves
        the same contract."""
        canonical = _stub_canonical(issue_native="issues/316")
        _patch_dispatch_read_via_canonical(monkeypatch, canonical)
        result = await resolve_thread_identifier(
            {"number": 316},
            primary_id_param="issue_id",
            kind="issue",
            default_owner="telejester-claude-skills",
            default_repo="telejester-claude-skills-dev",
        )
        assert result == "issues/316"
        canonical.get_issue.assert_called_once()


TOOL_NAMES = {
    "open_session",
    "recover_context",
    "check_skill_version",
    "replay_pending",
    "get_thread_comments",
    "close_issue_with_comment",
    "close_triaged_public_issues",
    "close_session",
    "post_turn",
    "create_thread",
    "classify_turn",
    "classify_and_create",
    "scaffold_project",
    "scaffold_project_multi",
    "detect_theme_change",
    "fork_discussion",
    "create_issue",
    "search_issues",
    "update_issue_toc",
    "move_project_item",
    "update_project_toc",
    "update_discussion_body",
    "compose_post_reframe_toc",
    "mark_discussion_decided",
    "validate_release",
    "release_project",
    "generate_changelog",
    "verify_plan_completeness",
    "verify_diff_covers_plan",
    "verify_existing_code_assumptions",
    "migrate_to_3_0",
    "migrate_to_3_0_rollback",
    "migrate_to_3_5",
    "migrate_to_3_5_rollback",
    "migrate_to_4_0",
    "migrate_to_4_0_rollback",
    "add_backend",
    "audit_project_prose",
    "check_code_design",
    "get_daemon_alerts",
    "get_daemon_status",
    "get_code_design_status",
    "analyze_gaps",
    "search_local",
    "run_command",  # (#387, 3.9.0 D4.3) text command grammar dispatch
    "update_issue_milestone",  # (#388, 3.9.0 D5) milestone mutation
}


class TestBuildServerFastFail:
    def test_raises_config_error_if_project_dir_missing(self, tmp_path):
        missing = tmp_path / "no-such-dir"
        with pytest.raises(ConfigError, match="does not exist"):
            build_server(missing)

    def test_no_config_file_starts_in_pre_bootstrap_mode(
        self, empty_project_dir, monkeypatch
    ):
        # #156 — absent .claude/github-config.json is no longer fatal.
        # The server starts in degraded mode: config=None, pre_bootstrap=True.
        # Tool dispatch will reject every tool except scaffold_project /
        # check_skill_version (covered by separate dispatch tests).
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        server, config, _, _ = build_server(empty_project_dir)
        assert server is not None
        assert config is None

    def test_raises_config_error_if_api_key_missing(
        self, project_dir, monkeypatch
    ):
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        with pytest.raises(ConfigError, match="ANTHROPIC_API_KEY"):
            build_server(project_dir)


class TestBuildReplication:
    """#274 — `_build_replication` constructs the per-server
    ReplicationManager from project config.

    Pre-bootstrap (config is None) returns None so the server can
    still start in degraded mode (#156). With a loaded config it
    wraps a single GitHubAdapter as the canonical entry — the 2.x
    config schema doesn't yet carry a multi-platform list.
    """

    def test_returns_none_pre_bootstrap(self):
        from forge_manager_mcp.server.build import _build_replication
        assert _build_replication(None, "ghp_test") is None

    def test_wraps_github_adapter_when_config_present(self, project_dir):
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication

        config = load_config(project_dir)
        manager = _build_replication(config, "ghp_test")

        assert manager is not None
        assert manager.canonical().platform_id == "github"
        assert manager.healthy_adapters() == ["github"]

    def test_3_0_multi_platform_local_canonical(
        self, project_dir, tmp_path, monkeypatch
    ):
        """#274 Phase D — when schema_version is "3.0", the manager
        assembles platforms in replication_order with the first as
        canonical. Local-first per OQ3."""
        import copy
        import json
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication
        from tests.conftest import VALID_CONFIG

        # GitHubAdapter.from_config calls get_github_token() which
        # reads $GITHUB_TOKEN; in this test environment we set it
        # explicitly rather than rely on `gh auth token`.
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        cfg["platforms"] = [
            {"id": "local", "path": str(tmp_path / "docs")},
            {"id": "github", "owner": "telejester",
             "private": "telejester/dev", "public": "telejester/pub"},
        ]
        cfg["replication_order"] = ["local", "github"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8"
        )
        (tmp_path / "docs").mkdir()

        config = load_config(project_dir)
        manager = _build_replication(config, "ghp_test")

        assert manager is not None
        # Canonical = first entry in replication_order = local.
        assert manager.canonical().platform_id == "local"
        states = manager.states()
        assert "local" in states
        assert "github" in states

    def test_3_0_unknown_platform_id_raises(self, project_dir):
        import copy
        import json
        from forge_manager_mcp.config import ConfigError, load_config
        from forge_manager_mcp.server.build import _build_replication
        from tests.conftest import VALID_CONFIG

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        cfg["platforms"] = [{"id": "bitbucket", "owner": "x"}]
        cfg["replication_order"] = ["bitbucket"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8"
        )

        config = load_config(project_dir)
        with pytest.raises(ConfigError, match="Unknown platform_id"):
            _build_replication(config, "ghp_test")

    def test_3_0_replication_order_references_missing_platform_raises(
        self, project_dir, monkeypatch
    ):
        """A non-local platform in replication_order without a
        matching platforms[] entry is a config inconsistency."""
        import copy
        import json
        from forge_manager_mcp.config import ConfigError, load_config
        from forge_manager_mcp.server.build import _build_replication
        from tests.conftest import VALID_CONFIG

        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        # gitlab is referenced in order but no entry in platforms[].
        cfg["platforms"] = [
            {"id": "github", "owner": "x", "private": "x/dev",
             "public": "x/pub"},
        ]
        cfg["replication_order"] = ["github", "gitlab"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8"
        )

        config = load_config(project_dir)
        with pytest.raises(ConfigError, match="no matching entry"):
            _build_replication(config, "ghp_test")

    def test_normalize_per_platform_categories_flat(self):
        """#299 / 3.6.0 D3 — per-platform discussion_categories
        flat shape (`{"Architecture": "DIC_..."}`) flattens to
        name → ID dict directly."""
        from forge_manager_mcp.server.build import (
            _normalize_per_platform_categories,
        )
        result = _normalize_per_platform_categories({
            "Architecture": "DIC_arch",
            "Ideas": "DIC_ideas",
        })
        assert result == {
            "Architecture": "DIC_arch",
            "Ideas": "DIC_ideas",
        }

    def test_normalize_per_platform_categories_object(self):
        """Object shape (`{"Architecture": {"id": "DIC_..."}}`)
        also flattens correctly — mirrors the legacy 3.x
        DiscussionCategories model_dump output."""
        from forge_manager_mcp.server.build import (
            _normalize_per_platform_categories,
        )
        result = _normalize_per_platform_categories({
            "Architecture": {"id": "DIC_arch"},
            "Ideas": {"id": "DIC_ideas"},
        })
        assert result == {
            "Architecture": "DIC_arch",
            "Ideas": "DIC_ideas",
        }

    def test_normalize_per_platform_categories_announcements_alias(self):
        """#191 alias preserved: Announcements ↔ Project."""
        from forge_manager_mcp.server.build import (
            _normalize_per_platform_categories,
        )
        # Only Announcements set → Project mirrors it.
        result = _normalize_per_platform_categories({
            "Announcements": "DIC_ann",
        })
        assert result["Project"] == "DIC_ann"
        # Only Project set → Announcements mirrors it.
        result = _normalize_per_platform_categories({
            "Project": "DIC_proj",
        })
        assert result["Announcements"] == "DIC_proj"

    def test_normalize_per_platform_categories_skips_empty(self):
        """Empty string IDs and missing `id` keys silently drop."""
        from forge_manager_mcp.server.build import (
            _normalize_per_platform_categories,
        )
        result = _normalize_per_platform_categories({
            "Empty": "",
            "Ok": "DIC_ok",
            "MissingId": {},
            "OkObject": {"id": "DIC_obj"},
        })
        assert result == {"Ok": "DIC_ok", "OkObject": "DIC_obj"}

    def test_3_0_local_is_implicit_when_absent_from_platforms(
        self, project_dir, tmp_path, monkeypatch
    ):
        """``local`` is allowed in replication_order without an
        explicit platforms entry — LocalStoreAdapter falls back to
        the env var or home-dir default."""
        import copy
        import json
        from forge_manager_mcp.config import load_config
        from forge_manager_mcp.server.build import _build_replication
        from tests.conftest import VALID_CONFIG

        docs_path = tmp_path / "implicit-docs"
        docs_path.mkdir()
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", str(docs_path))

        cfg = copy.deepcopy(VALID_CONFIG)
        cfg["schema_version"] = "3.0"
        cfg["platforms"] = []  # no explicit local entry
        cfg["replication_order"] = ["local"]
        (project_dir / ".claude" / "github-config.json").write_text(
            json.dumps(cfg), encoding="utf-8"
        )

        config = load_config(project_dir)
        manager = _build_replication(config, "ghp_test")
        assert manager is not None
        assert manager.canonical().platform_id == "local"


class TestToolRegistration:
    """
    Verify that all expected tools are registered and have
    valid inputSchema definitions.
    """

    @pytest.fixture
    def server_and_config(self, project_dir, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_test")
        return build_server(project_dir)

    @pytest.mark.asyncio
    async def test_all_tools_registered(self, server_and_config):
        server, _, _, _ = server_and_config
        tools = await server.list_tools_handler()
        tool_names = {t.name for t in tools}
        assert TOOL_NAMES == tool_names, (
            f"Missing tools: {TOOL_NAMES - tool_names}\n"
            f"Extra tools: {tool_names - TOOL_NAMES}"
        )

    @pytest.mark.asyncio
    async def test_all_tools_have_schemas(self, server_and_config):
        server, _, _, _ = server_and_config
        tools = await server.list_tools_handler()
        for tool in tools:
            assert tool.inputSchema is not None, f"{tool.name} missing inputSchema"
            assert tool.inputSchema.get("type") == "object", (
                f"{tool.name} inputSchema type should be 'object'"
            )

    @pytest.mark.asyncio
    async def test_required_fields_declared(self, server_and_config):
        server, _, _, _ = server_and_config
        tools = await server.list_tools_handler()
        tool_map = {t.name: t for t in tools}

        # post_turn requires thread_type / speaker / body. thread_id is
        # optional post-#56 — callers can provide number + owner/repo
        # instead.
        post_turn = tool_map["post_turn"]
        assert set(post_turn.inputSchema.get("required", [])) >= {
            "thread_type", "speaker", "body"
        }
        props = post_turn.inputSchema.get("properties", {})
        assert "thread_id" in props
        assert "number" in props

        # create_issue requires title and body. Either `labels` (list)
        # or `label` (deprecated single) must be supplied at call time
        # but neither is declared required in the schema (#55).
        create_issue = tool_map["create_issue"]
        assert set(create_issue.inputSchema.get("required", [])) >= {
            "title", "body"
        }
        props = create_issue.inputSchema.get("properties", {})
        assert "labels" in props
        assert "label" in props  # deprecated alias still present


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
