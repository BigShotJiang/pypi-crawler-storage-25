# qlip

Simple and fast video clip cutting by start and end time.

## Features

- **Fast Mode** - Cut videos in seconds using stream copy (no re-encoding)
- **Preview** - Drag the timeline to preview any frame
- **Precise Mode** - Frame-accurate cutting with re-encoding
- **GUI & CLI** - Both graphical interface and command-line tools

## Installation

### Requirements

- Python 3.8+
- ffmpeg (installed on your system)

**Install ffmpeg:**

```bash
# Windows
winget install --id=Gyan.FFmpeg

# macOS
brew install ffmpeg

# Linux
sudo apt install ffmpeg
```

### Install from PyPI

```bash
pip install quick-video-clip
```

### Install with GUI support

```bash
pip install quick-video-clip[gui]
```

## Usage

### GUI

```bash
qlip
```

1. Click "Browse" to select a video
2. Drag the timeline to preview and find your start/end points
3. Click "Set" to set start/end times
4. Click "Cut"

### CLI

```bash
# Fast mode (default)
qlip input.mp4 00:00:30 00:02:00 output.mp4

# Precise mode
qlip input.mp4 30 120 output.mp4 --precise

# Show video info
qlip input.mp4 --info
```

### Python API

```python
from video_cutter import cut_video

success, message = cut_video(
    "input.mp4",
    "output.mp4",
    "00:00:30",
    "00:02:00",
    mode="fast"
)
```

## Time Format

| Format | Description | Example |
|--------|-------------|---------|
| `HH:MM:SS` | Hours:Minutes:Seconds | `00:01:30` = 1 min 30 sec |
| Seconds | Plain seconds | `90` = 1 min 30 sec |

## Modes

| Mode | Speed | Accuracy | Quality | Use Case |
|------|-------|----------|---------|----------|
| **Fast** | Seconds | +/-1-2 sec | Lossless | Most scenarios |
| **Precise** | Minutes | Frame-accurate | Adjustable | Precision needed |

## License

MIT
