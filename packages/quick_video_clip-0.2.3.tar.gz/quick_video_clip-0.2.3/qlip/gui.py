"""
qlip - GUI Interface
"""

import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
from pathlib import Path
import threading
import tempfile
import os

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

from qlip.core import VideoCutterCore


class VideoCutterGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("qlip")
        self.root.minsize(700, 600)

        # Get screen height and set window size
        screen_height = root.winfo_screenheight()
        window_height = min(900, screen_height - 100)
        self.root.geometry(f"850x{window_height}")

        self.input_file = None
        self.preview_image = None
        self.current_preview_path = None
        self.temp_dir = tempfile.gettempdir()
        self.preview_loading = False
        self.video_duration = 0
        self.scale_dragging = False
        self.cutter = VideoCutterCore()

        self.setup_ui()

    def setup_ui(self):
        # Top control panel
        top_panel = tk.Frame(self.root)
        top_panel.pack(fill=tk.X, padx=10, pady=5)

        # Header
        header_frame = tk.Frame(top_panel)
        header_frame.pack(fill=tk.X)

        tk.Label(
            header_frame,
            text="qlip",
            font=("Arial", 14, "bold")
        ).pack(side=tk.LEFT, padx=(0, 20))

        # Mode selection
        self.mode_var = tk.StringVar(value="fast")

        tk.Label(header_frame, text="Mode:").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(
            header_frame,
            text="Fast",
            variable=self.mode_var,
            value="fast",
            command=self.on_mode_change,
            fg="green"
        ).pack(side=tk.LEFT)
        tk.Radiobutton(
            header_frame,
            text="Precise",
            variable=self.mode_var,
            value="precise",
            command=self.on_mode_change,
            fg="orange"
        ).pack(side=tk.LEFT)

        # File selection
        file_frame = tk.Frame(top_panel)
        file_frame.pack(fill=tk.X, pady=5)

        tk.Label(file_frame, text="Input:", width=6, anchor=tk.W).pack(side=tk.LEFT)
        self.input_label = tk.Label(
            file_frame,
            text="No file selected",
            bg="#f5f5f5",
            relief=tk.SUNKEN,
            anchor=tk.W,
            height=2
        )
        self.input_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        tk.Button(file_frame, text="Browse", command=self.select_input, width=8).pack(side=tk.LEFT)

        self.duration_label = tk.Label(file_frame, text="", fg="gray", font=("Arial", 8))
        self.duration_label.pack(side=tk.LEFT, padx=(10, 0))

        # Output file
        output_frame = tk.Frame(top_panel)
        output_frame.pack(fill=tk.X, pady=5)

        tk.Label(output_frame, text="Output:", width=6, anchor=tk.W).pack(side=tk.LEFT)
        self.output_entry = tk.Entry(output_frame, font=("Arial", 9))
        self.output_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        tk.Button(output_frame, text="Browse", command=self.select_output, width=8).pack(side=tk.LEFT)

        # Time settings
        time_frame = tk.Frame(top_panel)
        time_frame.pack(fill=tk.X, pady=5)

        tk.Label(time_frame, text="Start:", width=6, anchor=tk.W).pack(side=tk.LEFT)
        self.start_entry = tk.Entry(time_frame, width=10, font=("Arial", 10))
        self.start_entry.insert(0, "00:00:00")
        self.start_entry.pack(side=tk.LEFT, padx=2)
        self.start_entry.bind("<Return>", lambda _: self.draw_timeline())
        tk.Button(time_frame, text="Set", command=lambda: self.set_time_from_timeline("start"), width=4).pack(side=tk.LEFT, padx=2)

        tk.Label(time_frame, text="  End:", width=6, anchor=tk.W).pack(side=tk.LEFT)
        self.end_entry = tk.Entry(time_frame, width=10, font=("Arial", 10))
        self.end_entry.insert(0, "00:01:00")
        self.end_entry.pack(side=tk.LEFT, padx=2)
        self.end_entry.bind("<Return>", lambda _: self.draw_timeline())
        tk.Button(time_frame, text="Set", command=lambda: self.set_time_from_timeline("end"), width=4).pack(side=tk.LEFT, padx=2)

        # Cut button
        self.cut_button = tk.Button(
            time_frame,
            text="Cut",
            command=self.cut_video,
            bg="#4CAF50",
            fg="white",
            font=("Arial", 10, "bold"),
            width=8,
            state=tk.DISABLED
        )
        self.cut_button.pack(side=tk.RIGHT, padx=(10, 0))

        # Separator
        tk.Frame(self.root, height=2, bd=1, relief=tk.SUNKEN).pack(fill=tk.X, padx=10, pady=5)

        # Progress bar
        progress_frame = tk.Frame(self.root)
        progress_frame.pack(fill=tk.X, padx=10, pady=(0, 5))

        self.current_time_label = tk.Label(
            progress_frame,
            text="00:00:00 / 00:00:00",
            font=("Arial", 10)
        )
        self.current_time_label.pack(anchor=tk.W)

        self.timeline_canvas = tk.Canvas(
            progress_frame,
            height=45,
            bg="#f0f0f0",
            highlightthickness=1,
            highlightbackground="#ccc"
        )
        self.timeline_canvas.pack(fill=tk.X)
        self.timeline_canvas.bind("<Button-1>", self.on_timeline_click)
        self.timeline_canvas.bind("<B1-Motion>", self.on_timeline_drag)
        self.timeline_canvas.bind("<ButtonRelease-1>", self.on_timeline_release)

        # Preview area
        preview_frame = tk.Frame(self.root)
        preview_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.preview_container = tk.Frame(preview_frame, bg="#222")
        self.preview_container.pack(fill=tk.BOTH, expand=True)

        self.preview_label = tk.Label(
            self.preview_container,
            text="Select a video to preview\nDrag timeline to seek",
            bg="#222",
            fg="#666",
            font=("Arial", 14),
            justify=tk.CENTER
        )
        self.preview_label.pack(expand=True, fill=tk.BOTH)

        # Status label
        self.status_label = tk.Label(self.root, text="", fg="blue", font=("Arial", 9))
        self.status_label.pack(pady=(0, 5))

        self.root.bind("<Configure>", self.on_window_resize)

    def draw_timeline(self):
        """Draw timeline progress bar"""
        self.timeline_canvas.delete("all")

        width = self.timeline_canvas.winfo_width()
        if width <= 1:
            return

        # Background track
        self.timeline_canvas.create_rectangle(
            5, 18, width - 5, 27,
            fill="#ddd", outline="#999"
        )

        if self.video_duration > 0:
            start_sec = self._parse_time(self.start_entry.get()) or 0
            end_sec = self._parse_time(self.end_entry.get()) or 0

            start_x = 5 + (start_sec / self.video_duration) * (width - 10)
            end_x = 5 + (end_sec / self.video_duration) * (width - 10)

            # Selection area
            if start_x < end_x:
                self.timeline_canvas.create_rectangle(
                    start_x, 16, end_x, 29,
                    fill="#4CAF50", outline=""
                )

            # Start marker
            self.timeline_canvas.create_polygon(
                start_x, 5, start_x - 6, 16, start_x + 6, 16,
                fill="#2196F3", outline=""
            )

            # End marker
            self.timeline_canvas.create_polygon(
                end_x, 5, end_x - 6, 16, end_x + 6, 16,
                fill="#f44336", outline=""
            )

            # Time ticks
            for i in range(11):
                x = 5 + (i / 10) * (width - 10)
                self.timeline_canvas.create_line(x, 29, x, 33, fill="#999")

            # Current position
            if hasattr(self, 'current_preview_seconds'):
                cur_x = 5 + (self.current_preview_seconds / self.video_duration) * (width - 10)
                self.timeline_canvas.create_line(
                    cur_x, 14, cur_x, 31, fill="#FF9800", width=2
                )

    def on_timeline_click(self, event):
        if self.video_duration <= 0:
            return
        self.scale_dragging = True
        self.seek_to_position(event.x)

    def on_timeline_drag(self, event):
        if self.scale_dragging and self.video_duration > 0:
            self.seek_to_position(event.x)

    def on_timeline_release(self, event):
        self.scale_dragging = False

    def seek_to_position(self, x):
        width = self.timeline_canvas.winfo_width()
        if width <= 0:
            return

        ratio = max(0, min(1, (x - 5) / (width - 10)))
        seconds = ratio * self.video_duration
        self.current_preview_seconds = seconds

        time_str = self._seconds_to_time(int(seconds))
        total_str = self._seconds_to_time(int(self.video_duration))
        self.current_time_label.config(text=f"{time_str} / {total_str}")

        if hasattr(self, 'preview_timer'):
            self.root.after_cancel(self.preview_timer)
        self.preview_timer = self.root.after(200, lambda: self.extract_frame_at_seconds(seconds))

        self.draw_timeline()

    def set_time_from_timeline(self, which):
        if not hasattr(self, 'current_preview_seconds'):
            return

        time_str = self._seconds_to_time(int(self.current_preview_seconds))
        if which == "start":
            self.start_entry.delete(0, tk.END)
            self.start_entry.insert(0, time_str)
        else:
            self.end_entry.delete(0, tk.END)
            self.end_entry.insert(0, time_str)

        self.draw_timeline()

    def on_window_resize(self, event):
        if event.widget == self.timeline_canvas:
            self.draw_timeline()
        elif event.widget == self.preview_container and self.preview_image:
            self.refresh_preview_display()

    def on_mode_change(self):
        pass

    def select_input(self):
        file_path = filedialog.askopenfilename(
            title="Select Video File",
            filetypes=[
                ("Video Files", "*.mp4 *.avi *.mov *.mkv *.wmv *.flv *.webm"),
                ("All Files", "*.*")
            ]
        )
        if file_path:
            self.input_file = file_path
            self.input_label.config(text=Path(file_path).name)

            # Get duration
            duration = self.cutter.get_duration(file_path)
            if duration:
                self.video_duration = duration
                self.duration_label.config(text=f"Duration: {self._seconds_to_time(int(duration))}")
                self.current_time_label.config(text=f"00:00:00 / {self._seconds_to_time(int(duration))}")
                self.draw_timeline()

            # Set default output
            default_output = str(Path(file_path).with_stem(Path(file_path).stem + "_cut"))
            self.output_entry.delete(0, tk.END)
            self.output_entry.insert(0, default_output)

            self.cut_button.config(state=tk.NORMAL)

            self.preview_label.config(
                text="Drag timeline to preview\nor set start/end time",
                bg="#222", fg="#666"
            )

    def select_output(self):
        if not self.input_file:
            messagebox.showwarning("Warning", "Please select input file first!")
            return

        file_path = filedialog.asksaveasfilename(
            title="Save As",
            defaultextension=".mp4",
            filetypes=[
                ("MP4", "*.mp4"),
                ("AVI", "*.avi"),
                ("MOV", "*.mov"),
                ("MKV", "*.mkv")
            ]
        )
        if file_path:
            self.output_entry.delete(0, tk.END)
            self.output_entry.insert(0, file_path)

    def extract_frame_at_seconds(self, seconds):
        if not self.input_file:
            return

        time_str = self._seconds_to_time(int(seconds))
        self.extract_frame(time_str)

    def extract_frame(self, time_str):
        if not self.input_file or self.preview_loading:
            return

        seconds = self._parse_time(time_str)
        if seconds is None:
            return

        self.preview_loading = True
        self.preview_label.config(text="Loading...", bg="#222", fg="white")

        def load_in_background():
            temp_path = os.path.join(self.temp_dir, "qlip_preview.jpg")

            success, message = self.cutter.extract_frame(
                self.input_file,
                temp_path,
                time_str
            )

            if success and os.path.exists(temp_path):
                self.root.after(0, lambda: self.display_preview(temp_path))
            else:
                self.root.after(0, lambda: self.preview_label.config(
                    text="Failed to load", bg="#222", fg="#f66"
                ))
            self.root.after(0, lambda: setattr(self, 'preview_loading', False))

        threading.Thread(target=load_in_background, daemon=True).start()

    def display_preview(self, image_path):
        self.current_preview_path = image_path
        self.refresh_preview_display()

    def refresh_preview_display(self):
        if not self.current_preview_path or not HAS_PIL:
            return

        try:
            img = Image.open(self.current_preview_path)

            container_width = self.preview_container.winfo_width()
            container_height = self.preview_container.winfo_height()

            if container_width <= 1 or container_height <= 1:
                return

            img_ratio = img.width / img.height
            container_ratio = container_width / container_height

            if img_ratio > container_ratio:
                new_width = container_width
                new_height = int(new_width / img_ratio)
            else:
                new_height = container_height
                new_width = int(new_height * img_ratio)

            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            self.preview_image = ImageTk.PhotoImage(img)

            self.preview_label.config(image=self.preview_image, text="", bg="#222")

        except Exception:
            pass

    def cut_video(self):
        if not self.input_file:
            messagebox.showerror("Error", "Please select input file first!")
            return

        start_time = self.start_entry.get().strip()
        end_time = self.end_entry.get().strip()
        output_path = self.output_entry.get().strip()

        start_seconds = self._parse_time(start_time)
        end_seconds = self._parse_time(end_time)

        if start_seconds is None or end_seconds is None:
            messagebox.showerror("Error", "Invalid time format! Use HH:MM:SS")
            return

        if start_seconds >= end_seconds:
            messagebox.showerror("Error", "End time must be after start time!")
            return

        if not output_path:
            messagebox.showerror("Error", "Please specify output path!")
            return

        # Check if file exists
        if os.path.exists(output_path):
            filename = Path(output_path).name
            result = messagebox.askyesno(
                "File Exists",
                f'File "{filename}" already exists. Overwrite?',
                icon=messagebox.WARNING
            )
            if not result:
                return

        mode = "precise" if self.mode_var.get() == "precise" else "fast"

        self.cut_button.config(state=tk.DISABLED, text="Cutting...")
        self.status_label.config(text="Cutting video...", fg="blue")
        self.root.update()

        success, message = self.cutter.cut_video(
            self.input_file,
            output_path,
            start_time,
            end_time,
            mode=mode,
            overwrite=True
        )

        if success:
            self.status_label.config(text="Success!", fg="green")
            messagebox.showinfo("Success", f"Video saved:\n{output_path}")
        else:
            self.status_label.config(text="Failed!", fg="red")
            messagebox.showerror("Failed", message)

        self.cut_button.config(state=tk.NORMAL, text="Cut")

    def _parse_time(self, time_str):
        """Parse time string to seconds"""
        return self.cutter._parse_time(time_str)

    def _seconds_to_time(self, seconds):
        """Convert seconds to HH:MM:SS"""
        h = seconds // 3600
        m = (seconds % 3600) // 60
        s = seconds % 60
        return f"{h:02d}:{m:02d}:{s:02d}"


def main():
    root = tk.Tk()
    app = VideoCutterGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
