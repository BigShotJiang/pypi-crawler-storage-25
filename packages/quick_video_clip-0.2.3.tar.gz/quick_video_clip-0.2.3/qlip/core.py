"""
Video Cutter - Core functionality
"""

import subprocess
import os
from pathlib import Path
from typing import Optional, Tuple


class VideoCutterCore:
    """Core video cutting functionality"""

    def __init__(self, ffmpeg_path: str = "ffmpeg", ffprobe_path: str = "ffprobe"):
        self.ffmpeg_path = ffmpeg_path
        self.ffprobe_path = ffprobe_path

    def get_duration(self, video_path: str) -> Optional[float]:
        """Get video duration in seconds"""
        cmd = [
            self.ffprobe_path, "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            video_path
        ]

        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                errors='ignore'
            )

            if result.returncode == 0:
                return float(result.stdout.strip())
        except Exception:
            pass

        return None

    def cut_video(
        self,
        input_path: str,
        output_path: str,
        start_time: str,
        end_time: str,
        mode: str = "fast",
        overwrite: bool = False
    ) -> Tuple[bool, str]:
        """
        Cut video

        Args:
            input_path: Input video file path
            output_path: Output video file path
            start_time: Start time (HH:MM:SS or seconds)
            end_time: End time (HH:MM:SS or seconds)
            mode: "fast" for stream copy, "precise" for re-encoding
            overwrite: Whether to overwrite existing output file

        Returns:
            Tuple of (success: bool, message: str)
        """

        # Check if input exists
        if not os.path.exists(input_path):
            return False, "Input file not found"

        # Check if output exists
        if os.path.exists(output_path) and not overwrite:
            return False, "Output file already exists"

        # Parse times
        start_seconds = self._parse_time(start_time)
        end_seconds = self._parse_time(end_time)

        if start_seconds is None or end_seconds is None:
            return False, "Invalid time format. Use HH:MM:SS or seconds"

        if start_seconds >= end_seconds:
            return False, "End time must be after start time"

        # Build command
        if mode == "fast":
            cmd = [
                self.ffmpeg_path,
                "-ss", str(start_seconds),
                "-i", input_path,
                "-to", str(end_seconds),
                "-c", "copy",
                "-y" if overwrite else "-n",
                output_path
            ]
        else:  # precise mode
            duration = end_seconds - start_seconds
            cmd = [
                self.ffmpeg_path,
                "-i", input_path,
                "-ss", str(start_seconds),
                "-t", str(duration),
                "-c:v", "libx264",
                "-c:a", "aac",
                "-y" if overwrite else "-n",
                output_path
            ]

        # Execute
        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                errors='ignore'
            )

            if result.returncode == 0:
                return True, "Video cut successfully"
            else:
                return False, f"ffmpeg error: {result.stderr[-200:]}"

        except FileNotFoundError:
            return False, "ffmpeg not found. Please install ffmpeg."
        except Exception as e:
            return False, f"Error: {str(e)}"

    def extract_frame(
        self,
        video_path: str,
        output_path: str,
        time_point: str,
        quality: int = 2
    ) -> Tuple[bool, str]:
        """
        Extract a single frame from video

        Args:
            video_path: Input video file path
            output_path: Output image file path
            time_point: Time point to extract (HH:MM:SS or seconds)
            quality: JPEG quality (1-31, lower is better)

        Returns:
            Tuple of (success: bool, message: str)
        """
        seconds = self._parse_time(time_point)
        if seconds is None:
            return False, "Invalid time format"

        cmd = [
            self.ffmpeg_path,
            "-ss", str(seconds),
            "-i", video_path,
            "-vframes", "1",
            "-q:v", str(quality),
            "-y",
            output_path
        ]

        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                errors='ignore'
            )

            if result.returncode == 0 and os.path.exists(output_path):
                return True, "Frame extracted successfully"
            else:
                return False, "Failed to extract frame"

        except Exception as e:
            return False, f"Error: {str(e)}"

    def _parse_time(self, time_str: str) -> Optional[int]:
        """Parse time string to seconds"""
        time_str = time_str.strip()

        # Try as plain seconds first
        try:
            return int(time_str)
        except ValueError:
            pass

        # Try HH:MM:SS format
        try:
            parts = time_str.split(":")
            if len(parts) == 3:
                h, m, s = map(int, parts)
                return h * 3600 + m * 60 + s
        except ValueError:
            pass

        return None


def cut_video(
    input_path: str,
    output_path: str,
    start_time: str,
    end_time: str,
    mode: str = "fast",
    overwrite: bool = False
) -> Tuple[bool, str]:
    """
    Convenience function for cutting videos

    Example:
        success, message = cut_video(
            "input.mp4",
            "output.mp4",
            "00:00:30",
            "00:02:00",
            mode="fast"
        )
    """
    cutter = VideoCutterCore()
    return cutter.cut_video(input_path, output_path, start_time, end_time, mode, overwrite)
