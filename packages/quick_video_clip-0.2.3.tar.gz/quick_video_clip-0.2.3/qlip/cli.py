"""
Video Cutter - CLI Interface
"""

import argparse
import sys
from qlip.core import VideoCutterCore


def seconds_to_time(seconds: int) -> str:
    """Convert seconds to HH:MM:SS format"""
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def main():
    parser = argparse.ArgumentParser(
        description="Video Cutter - A fast video cutting tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Launch GUI (no arguments)
  video-cutter

  # Cut from 30 seconds to 2 minutes (fast mode)
  video-cutter input.mp4 00:00:30 00:02:00 output.mp4

  # Cut using seconds
  video-cutter input.mp4 30 120 output.mp4

  # Use precise mode
  video-cutter input.mp4 00:00:30 00:02:00 output.mp4 --precise

  # Show video duration
  video-cutter input.mp4 --info
        """
    )

    parser.add_argument("input", nargs="?", help="Input video file")
    parser.add_argument("start", nargs="?", help="Start time (HH:MM:SS or seconds)")
    parser.add_argument("end", nargs="?", help="End time (HH:MM:SS or seconds)")
    parser.add_argument("output", nargs="?", help="Output video file")

    parser.add_argument("--precise", action="store_true",
                        help="Use precise mode (re-encoding) instead of fast mode")
    parser.add_argument("--info", action="store_true",
                        help="Show video information")
    parser.add_argument("--overwrite", "-y", action="store_true",
                        help="Overwrite output file if exists")
    parser.add_argument("--gui", "-g", action="store_true",
                        help="Launch GUI mode")

    args = parser.parse_args()

    # Launch GUI if no arguments or explicitly requested
    if args.gui or not args.input:
        from qlip.gui import VideoCutterGUI
        import tkinter as tk
        root = tk.Tk()
        app = VideoCutterGUI(root)
        root.mainloop()
        return 0

    cutter = VideoCutterCore()

    # Show info mode
    if args.info:
        if not args.input:
            parser.error("--info requires input file")

        duration = cutter.get_duration(args.input)
        if duration:
            print(f"Duration: {seconds_to_time(int(duration))} ({int(duration)} seconds)")
            return 0
        else:
            print("Failed to get video info")
            return 1

    # Cut mode
    if not all([args.input, args.start, args.end, args.output]):
        parser.error("cut mode requires: input start end output")

    mode = "precise" if args.precise else "fast"

    print(f"Cutting video: {args.input}")
    print(f"Time range: {args.start} -> {args.end}")
    print(f"Output: {args.output}")
    print(f"Mode: {mode}")
    print("-" * 50)

    success, message = cutter.cut_video(
        args.input,
        args.output,
        args.start,
        args.end,
        mode=mode,
        overwrite=args.overwrite
    )

    if success:
        print(f"✓ {message}")
        return 0
    else:
        print(f"✗ {message}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
