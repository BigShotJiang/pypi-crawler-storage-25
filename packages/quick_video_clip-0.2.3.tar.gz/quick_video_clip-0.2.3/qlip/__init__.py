"""
Video Cutter - A fast video cutting tool

This package provides both CLI and GUI interfaces for cutting videos
using ffmpeg. Supports fast stream copy mode and precise re-encoding mode.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__license__ = "MIT"

from qlip.core import cut_video, VideoCutterCore

__all__ = ["cut_video", "VideoCutterCore", "__version__"]
