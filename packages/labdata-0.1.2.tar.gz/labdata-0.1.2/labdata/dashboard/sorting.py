import pandas as pd
import streamlit as st
import numpy as np
import altair as alt


colors = ['#1f77b4',
          '#ff7f0e',
          '#d62728',
          '#2ca02c',
          '#9467bd',
          '#8c564b',
          '#e377c2',
          '#7f7f7f',
          '#bcbd22']

def sorting_tab(schema=None):

    @st.cache_data
    def get_all_sorting_sessions():
        rows = (schema.SpikeSorting * schema.Session).fetch(
            'subject_name', 'session_name', 'dataset_name',
            'parameter_set_num', 'session_datetime', as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows).drop_duplicates(
            subset=['subject_name', 'session_name', 'dataset_name', 'parameter_set_num'])
        df['parameter_set_num'] = df['parameter_set_num'].astype(str)
        return df.sort_values(['subject_name', 'session_datetime']).reset_index(drop=True)

    @st.cache_data
    def get_session_counts():
        rows = (schema.Subject * schema.SpikeSortingParams).aggr(
            schema.SpikeSorting,
            n_sessions='count(session_name)'
        ).fetch(as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        df = df[df['n_sessions'] > 0].reset_index(drop=True)
        df['parameter_set_num'] = df['parameter_set_num'].astype(str)
        return df

    pars = schema.SpikeSortingParams().fetch(format='frame')[['algorithm_name', 'parameters_dict']]
    pars.insert(0, 'Select', False)
    edited_df = st.data_editor(pars.sort_index(),
                               hide_index=False,
                               disabled=['parameter_set_num',
                                         'algorithm_name',
                                         'parameters_dict'])
    sessions = schema.SpikeSorting().fetch(format='frame').reset_index()
    par_sets = edited_df[edited_df.Select == 1].reset_index()
    from functools import partial
    st.button('Update unit counts',
              on_click=partial(schema.UnitCount.populate, display_progress=True))

    # histogram: session counts per subject
    counts_df = get_session_counts()
    if not counts_df.empty:
        # filter to selected param sets if any are chosen
        if len(par_sets):
            selected_params = par_sets.parameter_set_num.astype(str).tolist()
            counts_filt = counts_df[counts_df['parameter_set_num'].isin(selected_params)]
        else:
            counts_filt = counts_df

        if not counts_filt.empty:
            param_sets_h = sorted(counts_filt['parameter_set_num'].unique().tolist())
            bar_color_scale = alt.Scale(
                domain=param_sets_h,
                range=[colors[i % len(colors)] for i in range(len(param_sets_h))])

            bar_sel = alt.selection_point(
                fields=['subject_name', 'parameter_set_num'], name='bar_sel')
            bar_chart = (
                alt.Chart(counts_filt).mark_bar().encode(
                    x=alt.X('subject_name:N', sort='ascending', title='Subject'),
                    xOffset=alt.XOffset('parameter_set_num:N', title='Param set'),
                    y=alt.Y('n_sessions:Q', title='# sessions'),
                    color=alt.Color('parameter_set_num:N', title='Param set',
                                    scale=bar_color_scale),
                    opacity=alt.condition(bar_sel, alt.value(1.0), alt.value(0.4)),
                    tooltip=['subject_name:N', 'parameter_set_num:N', 'n_sessions:Q'],
                ).add_params(bar_sel).properties(height=200)
            )
            bar_event = st.altair_chart(bar_chart, width='stretch', on_select='rerun',
                                        key='srt_sessions_bar')

            bar_pts = (bar_event.selection or {}).get('bar_sel', [])
            if bar_pts and bar_pts[0].get('subject_name'):
                clicked_subj = bar_pts[0]['subject_name']
                current = list(st.session_state.get('srt_subjects', []))
                if clicked_subj not in current:
                    current.append(clicked_subj)
                    st.session_state['srt_subjects'] = current

    # all-sessions scatter
    all_sessions_df = get_all_sorting_sessions()
    if not all_sessions_df.empty:
        scatter_df = all_sessions_df.copy()
        if len(par_sets):
            selected_params = par_sets.parameter_set_num.astype(str).tolist()
            flt = scatter_df[scatter_df['parameter_set_num'].isin(selected_params)]
            if not flt.empty:
                scatter_df = flt.reset_index(drop=True)

        param_sets_s = sorted(scatter_df['parameter_set_num'].unique().tolist())
        scat_color_scale = alt.Scale(
            domain=param_sets_s,
            range=[colors[i % len(colors)] for i in range(len(param_sets_s))])

        n_subjects = scatter_df['subject_name'].nunique()
        scat_sel = alt.selection_point(
            fields=['subject_name', 'session_name', 'dataset_name'], name='srt_scat_sel')
        scat_chart = (
            alt.Chart(scatter_df).mark_circle(size=80, opacity=0.7).encode(
                x=alt.X('session_datetime:T', title='Date',
                         axis=alt.Axis(tickCount='month', format='%b %Y', labelAngle=-45)),
                y=alt.Y('subject_name:N', title='Subject name', sort='ascending'),
                yOffset=alt.YOffset('jitter:Q', scale=alt.Scale(range=[-12, 12])),
                color=alt.Color('parameter_set_num:N', scale=scat_color_scale,
                                title='Param set'),
                opacity=alt.condition(scat_sel, alt.value(0.9), alt.value(0.35)),
                tooltip=['subject_name:N', 'session_name:N', 'parameter_set_num:N',
                         alt.Tooltip('session_datetime:T', format='%Y-%m-%d')],
            ).transform_calculate(jitter='random() - 0.5')
             .add_params(scat_sel)
             .properties(height=max(150, 60 * n_subjects + 60))
        )
        scat_event = st.altair_chart(scat_chart, width='stretch', on_select='rerun',
                                     key='srt_sessions_scatter')

        scat_pts = (scat_event.selection or {}).get('srt_scat_sel', [])
        if scat_pts and scat_pts[0].get('subject_name'):
            clicked_subj = scat_pts[0]['subject_name']
            current = list(st.session_state.get('srt_subjects', []))
            if clicked_subj not in current:
                current.append(clicked_subj)
                st.session_state['srt_subjects'] = current

    # subject/unit-count
    selected_subjects = []
    if len(par_sets):
        sess = []
        for p in par_sets.parameter_set_num.values:
            sess.append(sessions[sessions.parameter_set_num == p])
        sess = pd.concat(sess)
        subjects = np.unique(sess.subject_name.values)

        sesdict = []
        for p in par_sets.parameter_set_num.values:
            for subj in subjects:
                sub = sessions[(sessions.subject_name == subj) &
                               (sessions.parameter_set_num == p)]
                sesdict.append({'subject_name': subj,
                                'number_of_sessions': len(sub),
                                'parameter_set_num': p,
                                'number_of_probes': len(np.unique(sub.probe_num.values))})
        sesdict = pd.DataFrame(sesdict)
        if not len(sesdict):
            return

        selected_subjects = st.multiselect('Select subject:', subjects,
                                           key='srt_subjects')

    criteria_ids = schema.UnitCountCriteria().fetch(as_dict=True)
    if not len(criteria_ids):
        st.write('Add a UnitCountCriteria to the table: example '
                 '"isi_contamination < 0.1 & amplitude_cutoff < 0.1 & '
                 'spike_duration > 0.1 & spike_amplitude > 50 & presence_ratio > 0.6"')
        return
    selection = st.selectbox('Unit count criteria:',
                             [f'[{c["unit_criteria_id"]}] -> {c["sua_criteria"]}'
                              for c in criteria_ids])
    if '->' in selection:
        unit_criteria = int(int(selection.split('->')[0].strip(' []')))
    else:
        return

    @st.cache_data
    def get_unit_counts(s, p, unit_criteria):
        return pd.DataFrame(
            schema.UnitCount() * schema.Session() * schema.EphysRecording.ProbeSetting()
            & dict(subject_name=s, parameter_set_num=p, unit_criteria_id=unit_criteria))

    if len(selected_subjects):
        units = []
        for p in par_sets.parameter_set_num.values:
            for s in selected_subjects:
                units.append(get_unit_counts(s, p, unit_criteria))
        if not len(units):
            return
        unit_counts = pd.concat(units).set_index('subject_name')
        N = len(colors)
        cc = np.array([colors[0] for c in np.arange(len(unit_counts.probe_id.values))])
        for i, p in enumerate(np.unique(unit_counts.probe_id)):
            idx = np.where(unit_counts.probe_id.values == p)[0]
            cc[idx] = colors[np.mod(i, N)]
        unit_counts['probe_color'] = cc
        st.scatter_chart(unit_counts,
                         x='session_datetime', y='all',
                         x_label='Session date', y_label='Number of units',
                         color='probe_color', size=30)
        st.scatter_chart(unit_counts,
                         x='session_datetime', y='sua',
                         x_label='Session date', y_label='Number of single units',
                         color='probe_color', size=30)
