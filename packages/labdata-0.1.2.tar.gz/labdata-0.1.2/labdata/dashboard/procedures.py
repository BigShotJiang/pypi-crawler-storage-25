import pandas as pd
import streamlit as st
from datetime import datetime


def parse_procedure(procedure_dict):
    note_insert = None
    weight_insert = None
    insert = dict(subject_name=procedure_dict['subject_name'],
                  procedure_datetime=datetime.combine(procedure_dict['date'], procedure_dict['time']),
                  procedure_type=procedure_dict['procedure_type'])
    if procedure_dict['user_name'] is not None:
        insert['user_name'] = procedure_dict['user_name']
        if procedure_dict['note'] is not None:
            note_insert = dict(notetaker=insert['user_name'],
                               note_datetime=insert['procedure_datetime'],
                               notes=procedure_dict['note'])
            insert['note_datetime'] = note_insert['note_datetime']
            insert['notetaker'] = note_insert['notetaker']
    if procedure_dict['user_name'] is None and procedure_dict['note'] is not None:
        raise ValueError('Need to specify a user_name for adding notes.')
    if procedure_dict['weight'] is not None:
        weight_insert = dict(weight=procedure_dict['weight'],
                             subject_name=procedure_dict['subject_name'],
                             weighing_datetime=insert['procedure_datetime'])
        insert['weighing_datetime'] = weight_insert['weighing_datetime']
    return insert, note_insert, weight_insert


def procedures_tab(schema=None):
    import altair as alt

    @st.cache_data
    def get_procedure_counts():
        import datajoint as dj
        try:
            rows = dj.U('procedure_type').aggr(schema.Procedure, n='count(*)').fetch(as_dict=True)
        except Exception:
            rows = []
        return pd.DataFrame(rows) if rows else pd.DataFrame(columns=['procedure_type', 'n'])

    @st.cache_data
    def get_procedures_by_type(procedure_type):
        rows = (schema.Procedure & dict(procedure_type=procedure_type)).fetch(as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        cols = ['subject_name', 'procedure_datetime', 'user_name', 'procedure_metadata',
                'weighing_datetime', 'notetaker', 'note_datetime']
        cols = [c for c in cols if c in df.columns]
        return df[cols].sort_values('procedure_datetime', ascending=False).reset_index(drop=True)

    @st.cache_data
    def get_procedures_by_subject(subject_name):
        rows = (schema.Procedure & dict(subject_name=subject_name)).fetch(as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        cols = ['subject_name', 'procedure_datetime', 'procedure_type', 'user_name',
                'procedure_metadata', 'weighing_datetime', 'notetaker', 'note_datetime']
        cols = [c for c in cols if c in df.columns]
        return df[cols].sort_values('procedure_datetime').reset_index(drop=True)

    @st.cache_data
    def get_users():
        return list(schema.LabMember.fetch('user_name'))

    @st.cache_data
    def get_subjects():
        return list(schema.Subject.fetch('subject_name'))

    @st.cache_data
    def get_procedure_types():
        return list(schema.ProcedureType.fetch('procedure_type'))

    @st.cache_data
    def get_note(notetaker, note_datetime):
        rows = (schema.Note & dict(notetaker=notetaker, note_datetime=note_datetime)).fetch('notes')
        return str(rows[0]) if len(rows) else ''

    @st.cache_data
    def get_weight(subject_name, weighing_datetime):
        rows = (schema.Weighing & dict(subject_name=subject_name,
                                       weighing_datetime=weighing_datetime)).fetch('weight')
        return float(rows[0]) if len(rows) else None

    browse_tab, add_tab = st.tabs(['Browse', 'Add'])

    with browse_tab:
        if msg := st.session_state.pop('proc_success_msg', None):
            st.success(msg)

        browse_mode = st.radio('Browse by', ['By type', 'By subject'], horizontal=True,
                               key='proc_browse_mode', label_visibility='collapsed')

        if browse_mode != st.session_state.get('proc_browse_mode_prev'):
            st.session_state['proc_browse_mode_prev'] = browse_mode
            st.session_state.pop('proc_filter', None)
            st.session_state.pop('proc_edit_row', None)

        if browse_mode == 'By type':
            counts_df = get_procedure_counts()
            if counts_df.empty:
                st.write('No procedures in the database.')
            else:
                sel = alt.selection_point(fields=['procedure_type'], name='proc_type_sel')
                chart = (alt.Chart(counts_df).mark_bar().encode(
                    y=alt.Y('procedure_type:N', sort='-x', title=None,
                            axis=alt.Axis(labelLimit=300, labelFontSize=13)),
                    x=alt.X('n:Q', title='Count'),
                    color=alt.condition(sel, alt.value('black'), alt.value('#aaaaaa')),
                    tooltip=['procedure_type:N', 'n:Q'],
                ).add_params(sel).properties(height=alt.Step(40)))
                event = st.altair_chart(chart, width="stretch", on_select='rerun',
                                        key='proc_type_chart')
                pts = (event.selection or {}).get('proc_type_sel', [])
                if pts and pts[0].get('procedure_type'):
                    st.session_state['proc_filter'] = {'mode': 'type',
                                                        'value': pts[0]['procedure_type']}
                elif not pts:
                    st.session_state.pop('proc_filter', None)

        else:  # By subject
            subjects = get_subjects()
            subject = st.selectbox('Subject', subjects, index=None, key='proc_subj_select')
            if subject:
                st.session_state['proc_filter'] = {'mode': 'subject', 'value': subject}
                procs_subj = get_procedures_by_subject(subject)
                if procs_subj.empty:
                    st.write('No procedures found for this subject.')
                else:
                    colors = ['#000000', '#d62728', '#1f77b4', '#ff7f0e', '#2ca02c',
                              '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22']
                    ptypes = list(procs_subj['procedure_type'].unique())
                    color_scale = alt.Scale(domain=ptypes, range=colors[:len(ptypes)])
                    timeline = (alt.Chart(procs_subj).mark_point(size=200, filled=True).encode(
                        x=alt.X('procedure_datetime:T', title='Date'),
                        y=alt.Y('procedure_type:N', title=None,
                                axis=alt.Axis(labelLimit=300, labelFontSize=13)),
                        color=alt.Color('procedure_type:N', scale=color_scale, legend=None),
                        tooltip=['procedure_type:N', 'procedure_datetime:T', 'user_name:N'],
                    ).properties(height=alt.Step(50)))
                    st.altair_chart(timeline, width="stretch", key='proc_subj_chart')
            else:
                st.session_state.pop('proc_filter', None)

        # shared table — updated by whichever plot/selector was last used
        proc_filter = st.session_state.get('proc_filter')
        if proc_filter:
            if proc_filter['mode'] == 'type':
                procs = get_procedures_by_type(proc_filter['value']).copy()
                procs.insert(0, 'procedure_type', proc_filter['value'])
            else:
                procs = get_procedures_by_subject(proc_filter['value'])
            st.write(f"**{proc_filter['value']}**")
            if not procs.empty:
                event_procs = st.dataframe(
                    procs,
                    hide_index=True,
                    width="stretch",
                    on_select='rerun',
                    selection_mode='single-row',
                    key='procs_table',
                )
                sel_idx = (event_procs.selection or {}).get('rows', [])
                if sel_idx:
                    st.session_state['proc_edit_row'] = procs.iloc[sel_idx[0]].to_dict()

        # shared edit form — populated by either view via session state
        row_dict = st.session_state.get('proc_edit_row')
        if row_dict:
            procedure_type = row_dict.get('procedure_type', '')
            users = get_users()
            procedure_types = get_procedure_types()
            proc_key = dict(subject_name=row_dict['subject_name'],
                            procedure_type=procedure_type,
                            procedure_datetime=row_dict['procedure_datetime'])
            notetaker = row_dict.get('notetaker')
            note_datetime = row_dict.get('note_datetime')
            weighing_datetime = row_dict.get('weighing_datetime')
            has_note = pd.notna(notetaker) and pd.notna(note_datetime)
            has_weight = pd.notna(weighing_datetime)
            existing_note = get_note(notetaker, note_datetime) if has_note else ''
            existing_weight = get_weight(row_dict['subject_name'], weighing_datetime) if has_weight else None
            type_idx = procedure_types.index(procedure_type) if procedure_type in procedure_types else 0

            st.write('### Edit procedure')
            col_info, col_dismiss = st.columns([8, 1])
            col_info.write(f"**Subject:** {row_dict['subject_name']} &nbsp; "
                           f"**Date:** {row_dict['procedure_datetime']} &nbsp; "
                           f"**Type:** {procedure_type}")
            if col_dismiss.button('✕', key='proc_edit_dismiss'):
                st.session_state.pop('proc_edit_row', None)
                st.rerun()
            with st.form('edit_procedure'):
                new_type = st.selectbox('Procedure type', procedure_types, index=type_idx)
                user_idx = users.index(row_dict['user_name']) if row_dict.get('user_name') in users else None
                new_user = st.selectbox('Experimenter', users, index=user_idx)
                new_metadata = st.text_input('Metadata', value=str(row_dict.get('procedure_metadata') or ''))
                new_weight = st.number_input('Weight (g)', value=existing_weight)
                new_note = st.text_area('Note', value=existing_note, max_chars=4000)
                if st.form_submit_button('Save changes', type='primary'):
                    type_changed = new_type != procedure_type
                    if type_changed:
                        new_proc = dict(subject_name=proc_key['subject_name'],
                                        procedure_datetime=proc_key['procedure_datetime'],
                                        procedure_type=new_type,
                                        user_name=new_user,
                                        procedure_metadata=new_metadata or None)
                        if has_note:
                            new_proc['notetaker'] = notetaker
                            new_proc['note_datetime'] = note_datetime
                        if has_weight:
                            new_proc['weighing_datetime'] = weighing_datetime
                        (schema.Procedure & proc_key).delete(safemode=False)
                        schema.Procedure.insert1(new_proc)
                    else:
                        schema.Procedure.update1({**proc_key, 'user_name': new_user,
                                                  'procedure_metadata': new_metadata or None})
                    target_key = {**proc_key, 'procedure_type': new_type} if type_changed else proc_key
                    if has_weight and new_weight is not None:
                        schema.Weighing.update1(dict(subject_name=row_dict['subject_name'],
                                                     weighing_datetime=weighing_datetime,
                                                     weight=new_weight))
                    elif not has_weight and new_weight is not None:
                        weigh_dt = datetime.now()
                        schema.Weighing.insert1(dict(subject_name=row_dict['subject_name'],
                                                     weighing_datetime=weigh_dt,
                                                     weight=new_weight))
                        schema.Procedure.update1({**target_key, 'weighing_datetime': weigh_dt})
                    if has_note:
                        schema.Note.update1(dict(notetaker=notetaker,
                                                 note_datetime=note_datetime,
                                                 notes=new_note))
                    elif new_note.strip():
                        note_dt = datetime.now()
                        schema.Note.insert1(dict(notetaker=new_user,
                                                 note_datetime=note_dt,
                                                 notes=new_note))
                        schema.Procedure.update1({**target_key, 'notetaker': new_user,
                                                  'note_datetime': note_dt})
                    get_procedures_by_type.clear()
                    get_procedures_by_subject.clear()
                    get_procedure_counts.clear()
                    get_note.clear()
                    get_weight.clear()
                    st.session_state.pop('proc_edit_row', None)
                    st.session_state['proc_success_msg'] = (
                        f'Procedure updated: {new_type} for {row_dict["subject_name"]} '
                        f'on {pd.Timestamp(row_dict["procedure_datetime"]).strftime("%Y-%m-%d")}.'
                    )
                    st.rerun()

    with add_tab:
        users = get_users()
        subjects = get_subjects()
        procedure_types = get_procedure_types()
        project_users = list((schema.Project.User() & f'project_name = "{schema.schema_project}"').fetch('user_name'))
        userindex = users.index(project_users[0]) if project_users and project_users[0] in users else None

        procedure_dict = dict()
        procedure_dict['subject_name'] = st.selectbox('Subject', subjects, index=None)
        with st.form('add_procedure'):
            procedure_dict['user_name'] = st.selectbox('Experimenter', users, index=userindex)
            procedure_dict['date'] = st.date_input('Date', value='today')
            procedure_dict['time'] = st.time_input('Procedure start time', value='now')
            procedure_dict['procedure_type'] = st.selectbox('Procedure type', procedure_types, index=None)
            procedure_dict['procedure_metadata'] = st.text_input('Metadata', value=None)
            procedure_dict['weight'] = st.number_input('Weight (g)', value=None)
            procedure_dict['note'] = st.text_area('Notes', value=None)
            if st.form_submit_button('Add Procedure', type='primary'):
                missing = [a for a in ['subject_name', 'procedure_type', 'user_name']
                           if not procedure_dict.get(a)]
                if missing:
                    st.error(f'Please specify: {", ".join(missing)}')
                else:
                    proc_dict, note_dict, weigh_dict = parse_procedure(procedure_dict)
                    if note_dict is not None:
                        schema.Note.insert1(note_dict)
                    if weigh_dict is not None:
                        schema.Weighing.insert1(weigh_dict)
                    schema.Procedure.insert1(proc_dict)
                    get_procedure_counts.clear()
                    st.success(f'Added {procedure_dict["procedure_type"]} for {procedure_dict["subject_name"]}.')
