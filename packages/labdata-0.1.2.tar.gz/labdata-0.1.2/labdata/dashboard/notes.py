import pandas as pd
import streamlit as st
from datetime import datetime, date, time as dtime


def notes_tab(schema=None):

    @st.cache_data
    def get_users():
        return list(schema.LabMember.fetch('user_name'))

    @st.cache_data
    def get_subjects():
        return list(schema.Subject.fetch('subject_name'))

    @st.cache_data
    def get_sessions(subject_name):
        return list((schema.Session & dict(subject_name=subject_name)).fetch('session_name'))

    @st.cache_data
    def get_datasets(subject_name, session_name):
        return list((schema.Dataset & dict(subject_name=subject_name,
                                           session_name=session_name)).fetch('dataset_name'))

    @st.cache_data
    def get_note_counts():
        rows = (schema.Subject.aggr(
            schema.Dataset * schema.Note,
            note_count='count(*)'
        )).fetch(as_dict=True)
        df = pd.DataFrame(rows)
        if len(df):
            return df[df['note_count'] > 0].sort_values('note_count', ascending=False).reset_index(drop=True)
        return []

    @st.cache_data
    def get_subject_notes(subject_name):
        query = schema.Dataset * schema.Session * schema.Note & dict(subject_name=subject_name)
        rows = query.fetch(as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        cols = ['subject_name', 'session_name', 'dataset_name', 'session_datetime',
                'notes', 'notetaker', 'note_datetime']
        cols = [c for c in cols if c in df.columns]
        return df[cols].sort_values('note_datetime', ascending=False).reset_index(drop=True)

    users = get_users()
    subjects = get_subjects()

    browse_tab, update_tab, add_tab = st.tabs(['Browse', 'Update', 'Create'])

    def _render_notes_table(notes_df, editor_key):
        display_df = notes_df.copy()
        display_df.insert(0, 'Select', False)
        edited = st.data_editor(
            display_df,
            column_config={'Select': st.column_config.CheckboxColumn(required=True)},
            disabled=[c for c in display_df.columns if c != 'Select'],
            width="stretch",
            key=editor_key,
        )
        selected_rows = edited[edited['Select'] == True]
        if len(selected_rows) > 1:
            st.warning('Multiple notes selected — selecting the first one.')
        if len(selected_rows):
            st.session_state['selected_note'] = selected_rows.iloc[0].to_dict()

    with browse_tab:
        import altair as alt
        counts_df = get_note_counts()
        subject_filter = None
        if len(counts_df):
            sel = alt.selection_point(fields=['subject_name'], name='subject_sel')
            chart = (alt.Chart(counts_df).mark_bar().encode(
                x=alt.X('subject_name:N', sort='ascending', title='Subject'),
                y=alt.Y('note_count:Q', title='# notes'),
                color=alt.condition(sel, alt.value('black'), alt.value('#aaaaaa')),
                tooltip=['subject_name:N', 'note_count:Q'],
            ).add_params(sel).properties(height=200))
            event = st.altair_chart(chart, width="stretch", on_select='rerun',
                                    key='notes_count_chart')
            if st.session_state.pop('notes_clear_pending', False):
                st.session_state.pop('notes_selected_subject', None)
            else:
                pts = (event.selection or {}).get('subject_sel', [])
                if pts and pts[0].get('subject_name'):
                    st.session_state['notes_selected_subject'] = pts[0]['subject_name']
            subject_filter = st.session_state.get('notes_selected_subject')
            if subject_filter:
                st.write(f'**Selected:** {subject_filter}')
                if st.button('Clear selection', key='notes_clear_subject'):
                    st.session_state['notes_clear_pending'] = True
                    st.rerun()
        else:
            st.write('No notes in the database.')

        if subject_filter:
            notes_df = get_subject_notes(subject_filter)
            if len(notes_df):
                if len(notes_df) > 1:
                    idx = st.slider('Note', min_value=1, max_value=len(notes_df), value=1,
                                    format='%d', key='notes_slider',
                                    help='Cycle through notes (sorted by date, newest first)')
                    row = notes_df.iloc[idx - 1]
                    st.write(f"**{row.get('session_datetime', '')}** — {row.get('dataset_name', '')} — *{row.get('notetaker', '')}*")
                    st.write(row.get('notes', ''))
                    st.session_state['selected_note'] = row.to_dict()
                    with st.expander('Show all notes as table'):
                        _render_notes_table(notes_df, 'notes_browse_editor')
                else:
                    _render_notes_table(notes_df, 'notes_browse_editor')
            else:
                st.write('No notes found for this subject.')

    with add_tab:
        st.write('### Add a note to a dataset')
        subject_name = st.selectbox('Subject', subjects, index=None, key='notes_add_subject')
        session_name = None
        dataset_name = None
        if subject_name:
            sessions = get_sessions(subject_name)
            session_name = st.selectbox('Session', sessions, index=None, key='notes_add_session')
        if session_name:
            datasets = get_datasets(subject_name, session_name)
            dataset_name = st.selectbox('Dataset', datasets, index=None, key='notes_add_dataset')
        with st.form('add_note'):
            project_users = (schema.Project.User() & f'project_name = "{schema.schema_project}"').fetch('user_name')
            user_index = None
            if len(project_users) and project_users[0] in users:
                user_index = users.index(project_users[0])
            notetaker = st.selectbox('Notetaker', users, index=user_index)
            note_date = st.date_input('Date', value=date.today())
            note_time = st.time_input('Time', value=dtime(datetime.now().hour, datetime.now().minute))
            note_text = st.text_area('Note (max 4000 characters)', max_chars=4000)
            submitted = st.form_submit_button('Add Note', type='primary')
            if submitted:
                if not subject_name:
                    st.error('Select a subject.')
                elif not session_name:
                    st.error('Select a session.')
                elif not dataset_name:
                    st.error('Select a dataset.')
                elif not notetaker:
                    st.error('Select a notetaker.')
                elif not note_text.strip():
                    st.error('Note text cannot be empty.')
                else:
                    note_dt = datetime.combine(note_date, note_time)
                    dataset_key = dict(subject_name=subject_name, session_name=session_name,
                                       dataset_name=dataset_name)
                    schema.Note.insert1(dict(notetaker=notetaker, note_datetime=note_dt, notes=note_text))
                    schema.Dataset.update1({**dataset_key, 'notetaker': notetaker, 'note_datetime': note_dt})
                    get_note_counts.clear()
                    get_subject_notes.clear()
                    st.success(f'Note {dataset_key} added successfully.')

    with update_tab:
        selected = st.session_state.get('selected_note', {})
        if not selected:
            st.info('Select a note in the Browse tab first.')
        else:
            notetaker_upd = selected.get('notetaker')
            note_dt_upd = selected.get('note_datetime')
            pre_text = selected.get('notes', '')
            subject_name_upd = selected.get('subject_name')
            session_name_upd = selected.get('session_name')
            dataset_name_upd = selected.get('dataset_name')
            if subject_name_upd and session_name_upd and dataset_name_upd:
                st.write(f"**Subject:** {subject_name_upd} &nbsp; **Session:** {session_name_upd} &nbsp; **Dataset:** {dataset_name_upd}")
            st.write(f"**Notetaker:** {notetaker_upd} &nbsp; **Date/time:** {note_dt_upd}")
            with st.form('update_note'):
                new_text = st.text_area('Note', value=pre_text, max_chars=4000)
                submitted_upd = st.form_submit_button('Update Note', type='primary')
                if submitted_upd:
                    if not new_text.strip():
                        st.error('Note text cannot be empty.')
                    else:
                        schema.Note.update1(dict(notetaker=notetaker_upd, note_datetime=note_dt_upd,
                                                 notes=new_text))
                        get_note_counts.clear()
                        get_subject_notes.clear()
                        st.session_state.pop('selected_note', None)
                        st.success(f'Note {dict(notetaker=notetaker_upd, note_datetime=note_dt_upd)} updated.')
