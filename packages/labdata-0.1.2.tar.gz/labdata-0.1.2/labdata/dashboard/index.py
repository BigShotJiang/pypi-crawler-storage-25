import streamlit as st
import pandas as pd
import numpy as np
from functools import partial

import sys

def intro_tab(user_name = None, schema = None):
    @st.cache_data
    def get_subjects():
        if user_name is not None:
            df = pd.DataFrame((schema.Subject() & f'user_name = "{user_name}"').fetch())
        else:
            df = pd.DataFrame(schema.Subject().fetch())
        return df.sort_values("subject_name").reset_index(drop=True)

    @st.cache_data
    def get_sessions(subject_names):
        dfs = [pd.DataFrame((schema.Session() * schema.Dataset() &
                              f'subject_name = "{s}"').fetch()) for s in subject_names]
        dfs = [d for d in dfs if len(d)]
        if not dfs:
            return None
        return pd.concat(dfs).sort_values("session_datetime").reset_index(drop=True)

    @st.cache_data
    def get_files(dataset_keys_frozen):
        keys = [dict(k) for k in dataset_keys_frozen]
        rows = (schema.Dataset.DataFiles * schema.File & keys).fetch(
            'subject_name', 'session_name', 'dataset_name',
            'file_path', 'file_size', 'file_datetime', 'storage', as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        df['size'] = df['file_size'].apply(
            lambda b: f'{b/1e9:.2f} GB' if b >= 1e9 else f'{b/1e6:.1f} MB' if b >= 1e6 else f'{b/1e3:.0f} KB')
        return df.drop(columns='file_size')

    @st.cache_data
    def get_users():
        return list(schema.LabMember.fetch('user_name'))

    @st.cache_data
    def get_strains():
        return list(schema.Strain().fetch('strain_name'))

    list_tab, add_tab, edit_tab = st.tabs(['Subjects/Sessions', 'New', 'Update'])

    with list_tab:
        subjects = get_subjects()
        event_subjects = st.dataframe(
            subjects,
            hide_index=True,
            width="stretch",
            on_select='rerun',
            selection_mode='multi-row',
            key='subjects_table',
        )
        sel_subj_idx = (event_subjects.selection or {}).get('rows', [])
        selected_names = list(subjects.iloc[sel_subj_idx]['subject_name']) if sel_subj_idx else []
        if selected_names:
            st.session_state['subjects_selected'] = selected_names

        sessions = get_sessions(selected_names) if selected_names else None
        if sessions is None:
            st.write('No subjects selected.')
        else:
            dtype_vals = [s if s is not None else 'None' for s in sessions.dataset_type.values]
            uniqueds = np.unique(dtype_vals)
            metric_cols = st.columns(max(1, len(uniqueds)))
            for col, d in zip(metric_cols, uniqueds):
                col.metric(d, sum(1 for v in dtype_vals if v == d))

            # color palette for dataset types (light backgrounds, readable text)
            type_palette = ['#d0e8ff', '#ffd6d6', '#d4f5d4', '#fff0cc',
                            '#e8d4f5', '#ffd9b3', '#d4f0f5', '#f5d4e8',
                            '#e8f5d4', '#f5e8d4']
            dtype_list = [s if s is not None else 'None' for s in sessions['dataset_type'].values]
            unique_types = list(dict.fromkeys(dtype_list))  # preserve order, deduplicate
            type_color = {t: type_palette[i % len(type_palette)] for i, t in enumerate(unique_types)}

            def _color_rows(row):
                dt = row.get('dataset_type')
                dt = dt if dt is not None else 'None'
                bg = type_color.get(dt, '')
                return [f'background-color: {bg}'] * len(row)

            sess_styled = sessions.style.apply(_color_rows, axis=1)
            event_sessions = st.dataframe(
                sess_styled,
                hide_index=True,
                width="stretch",
                on_select='rerun',
                selection_mode='multi-row',
                key='sessions_table',
            )
            sel_indices = (event_sessions.selection or {}).get('rows', [])
            sel_datasets = sessions.iloc[sel_indices] if sel_indices else pd.DataFrame()
            if len(sel_datasets):
                dataset_keys = sel_datasets[['subject_name', 'session_name', 'dataset_name']].to_dict('records')
                file_stats = get_files(tuple(frozenset(d.items()) for d in dataset_keys))
                if len(file_stats):
                    st.write('### Files')
                    ds_order = list(dict.fromkeys(file_stats['dataset_name'].values))
                    even_color, odd_color = '#dceeff', '#fff3dc'
                    ds_color = {ds: (even_color if i % 2 == 0 else odd_color)
                                for i, ds in enumerate(ds_order)}

                    def _color_file_rows(row):
                        bg = ds_color.get(row['dataset_name'], '')
                        return [f'background-color: {bg}'] * len(row)

                    file_styled = file_stats.style.apply(_color_file_rows, axis=1)
                    event_files = st.dataframe(
                        file_styled,
                        hide_index=True,
                        width="stretch",
                        on_select='rerun',
                        selection_mode='multi-row',
                        key='files_table',
                    )
                    sel_file_idx = (event_files.selection or {}).get('rows', [])
                    if sel_file_idx:
                        sel_files = file_stats.iloc[sel_file_idx]
                        st.caption(f'{len(sel_file_idx)} file(s) selected')
                        if st.button('Download files', key='download_files_btn'):
                            keys = sel_files[['file_path', 'storage']].to_dict('records')
                            with st.spinner(f'Downloading {len(sel_file_idx)} file(s)…'):
                                local = (schema.File & keys).get()
                            if local:
                                st.success(f'Downloaded {len(local)} file(s).')
                                for p in local:
                                    st.code(str(p))
                else:
                    st.write('No files found for the selected datasets.')

    with add_tab:
        users = get_users()
        available_strains = get_strains()
        project_users = list((schema.Project.User() & f'project_name = "{schema.schema_project}"').fetch('user_name'))
        userindex = users.index(project_users[0]) if project_users and project_users[0] in users else None
        with st.form('add_subject'):
            insert_dict = dict()
            insert_dict['user_name'] = st.selectbox('User Name', users, index=userindex)
            insert_dict['subject_name'] = st.text_input('Subject ID', value=None)
            insert_dict['subject_dob'] = st.date_input('Date of Birth')
            sex = st.selectbox('Sex', ['M', 'F', 'Unknown'])
            insert_dict['subject_sex'] = 'U' if sex == 'Unknown' else sex
            insert_dict['strain_name'] = st.selectbox('Strain', available_strains)
            if st.form_submit_button('Add Subject', type='primary'):
                schema.Subject().insert1(insert_dict)
                get_subjects.clear()
                st.success(f'Added subject {insert_dict["subject_name"]}.')
                st.rerun()

    with edit_tab:
        users = get_users()
        available_strains = get_strains()
        selected_names = st.session_state.get('subjects_selected', [])
        if not selected_names:
            st.info('Select a subject in the Subjects/Sessions tab first.')
        else:
            selected_subject = selected_names[0]
            st.write(f'### Edit subject: {selected_subject}')
            with st.form('edit_subject'):
                edit_dict = (schema.Subject & dict(subject_name=selected_subject)).fetch1()
                edit_dict['subject_dob'] = st.date_input('Date of Birth', value=edit_dict['subject_dob'])
                edit_dict['subject_sex'] = st.selectbox('Sex', ['M', 'F', 'U'],
                                                         index=['M', 'F', 'U'].index(edit_dict['subject_sex']))
                edit_dict['strain_name'] = st.selectbox('Strain', available_strains,
                                                         index=available_strains.index(edit_dict['strain_name']))
                if st.form_submit_button('Save changes', type='primary'):
                    schema.Subject().update1(edit_dict)
                    get_subjects.clear()
                    st.success(f'Updated {selected_subject}.')
                    st.rerun()
st.set_page_config(
    page_title="labdata dashboard",
    page_icon="🧪",
    layout="wide",
      initial_sidebar_state="auto")


from procedures import procedures_tab
from notes import notes_tab
from sorting import sorting_tab
from segmentation import segmentation_tab
from video import video_tab
from decisiontask import decisionmaking_tab
from compute import compute_tab

@st.cache_resource
def load_schema(project):
    # load project
    from labdata import load_project_schema
    return load_project_schema(project)

project = None
show_console = False
for k in sys.argv:
    if 'project=' in k:
        project = k.replace('project=','')
    if k == 'console=1':
        from console import console_tab
        show_console = True
with st.spinner(f'Connecting to {"project " + project if project else "database"}…'):
    schema = load_schema(project)

page_names_to_funcs = {
    "**Subjects**": partial(intro_tab, schema = schema),
    "**Procedures**": partial(procedures_tab, schema = schema),
    "**Notes**": partial(notes_tab, schema = schema),
    "**Spike sorting**": partial(sorting_tab, schema = schema),
    "**Cell Segmentation**": partial(segmentation_tab, schema = schema),
    "**Video**": partial(video_tab, schema = schema),
    "**Decision-making behavior**": partial(decisionmaking_tab, schema = schema),
    "**Compute/Upload**": partial(compute_tab, schema = schema),
}

if show_console:
    page_names_to_funcs["**Console**"] = partial(console_tab, schema=schema)

from labdata import plugins
for p in plugins.keys():
    if hasattr(plugins[p],'dashboard_function'):
        page_names_to_funcs[plugins[p].dashboard_name] = partial(plugins[p].dashboard_function, schema = schema)


tab_name = st.sidebar.radio(
    "``labdata dashboard``",
    page_names_to_funcs.keys())

page_names_to_funcs[tab_name]()
