import pandas as pd
import numpy as np
import streamlit as st

STATES = ['COMPLETED', 'WORKING', 'WAITING', 'FAILED', 'CANCELED','ON SERVER']
STATE_COLORS = ['#01D186', '#48CAE4', '#F3A21C', '#FF5733', '#F3A21C','#F3A21C']

def _jobs_panel(table, status_field, target_field, cols, delete_key):

    import datajoint as dj
    import altair as alt

    rows = table.fetch(as_dict=True)
    if not rows:
        st.write('### There are no jobs in the table')
        return

    df = pd.DataFrame(rows)[[c for c in cols if c in pd.DataFrame(rows).columns]]

    # counts via aggr
    counts = {r[status_field]: r['n'] for r in
              dj.U(status_field).aggr(table, n='count(*)').fetch(as_dict=True)}
    metric_cols = st.columns(len(STATES))
    for col, t in zip(metric_cols, STATES):
        col.metric(t, counts.get(t, 0))

    # bar chart per target queue
    df = df.set_index('job_id')
    if target_field in df.columns:
        targets = [d if d is not None else 'unknown' for d in df[target_field].values]
        df[target_field] = targets
        qcounts = []
        for t in np.unique(targets):
            status_vals = df[status_field].values
            target_vals = df[target_field].values
            for tt, c in zip(STATES, STATE_COLORS):
                qcounts.append({'Task status': f'{tt}|{t}',
                                'Jobs': int(sum(1 for a, tv in zip(status_vals, target_vals)
                                               if tt in a and tv == t)),
                                'color': c})
        qcounts = [q for q in qcounts if q['Jobs'] > 0]
        ch = (alt.Chart(pd.DataFrame(qcounts)).mark_bar().encode(
            y='Task status:N',
            x='Jobs:Q',
            color=alt.Color('color:N').scale(None)
        ).configure_axis(labelLimit=3000))
        st.altair_chart(ch, width="stretch")

    # filtered table
    selected_states = st.multiselect('Select status:', STATES, default=STATES[1:], key=f'{delete_key}_filter')
    idx = np.zeros(len(df), dtype=bool)
    for s in selected_states:
        idx = idx | np.array([s in a for a in df[status_field].values])

    display_df = df.iloc[idx].copy()
    display_df.insert(0, 'Select', False)
    edited = st.data_editor(
        display_df,
        column_config={'Select': st.column_config.CheckboxColumn(required=True)},
        disabled=[c for c in display_df.columns if c != 'Select'],
        width="stretch",
        key=f'{delete_key}_editor',
    )
    selected_jobs = edited[edited['Select'] == True].index.tolist()
    if selected_jobs:
        st.caption(f'{len(selected_jobs)} job(s) selected')
        if st.button('Delete selected', type='primary', key=f'{delete_key}_btn'):
            st.session_state[f'{delete_key}_pending'] = selected_jobs
        if st.session_state.get(f'{delete_key}_pending'):
            jobs_to_delete = st.session_state[f'{delete_key}_pending']
            st.warning(f'Are you sure you want to delete {len(jobs_to_delete)} job(s)? This cannot be undone and scheduled jobs might fail.')
            col_yes, col_no, _ = st.columns([1, 1, 4])
            if col_yes.button('Yes, delete', type='primary', key=f'{delete_key}_yes'):
                (table & [dict(job_id=j) for j in jobs_to_delete]).delete(safemode=False)
                st.session_state.pop(f'{delete_key}_pending', None)
                st.success(f'Deleted {len(jobs_to_delete)} job(s).')
                st.rerun()
            if col_no.button('Cancel', key=f'{delete_key}_no'):
                st.session_state.pop(f'{delete_key}_pending', None)
                st.rerun()


def compute_tab(schema=None):
    if schema is None:
        from labdata import load_project_schema
        schema = load_project_schema()

    tab_compute, tab_upload = st.tabs(['Compute tasks', 'Upload jobs'])

    with tab_compute:
        _jobs_panel(
            table=schema.ComputeTask,
            status_field='task_status',
            target_field='task_target',
            cols=['job_id', 'task_name', 'task_status', 'task_host', 'task_target',
                  'task_waiting', 'task_log', 'subject_name', 'session_name',
                  'task_starttime', 'task_endtime'],
            delete_key='compute',
        )

    with tab_upload:
        all_projects = st.toggle('Show all projects', value=False, key='upload_all_projects')
        upload_table = schema.UploadJob if all_projects else schema.UploadJob & dict(project_name=schema.schema_project)
        _jobs_panel(
            table=upload_table,
            status_field='job_status',
            target_field='job_host',
            cols=['job_id', 'job_status', 'job_host', 'job_rule', 'job_waiting',
                  'job_log', 'subject_name', 'session_name', 'dataset_name',
                  'upload_storage', 'job_starttime', 'job_endtime'],
            delete_key='upload',
        )
