import streamlit as st
import base64


def _execute_silent(kc, code):
    """Fire-and-forget execution (used for kernel init)."""
    kc.execute(code, silent=True)
    while True:
        try:
            msg = kc.get_iopub_msg(timeout=60)
        except Exception:
            break
        if (msg['msg_type'] == 'status' and
                msg['content'].get('execution_state') == 'idle'):
            break


def _execute(kc, code):
    """Execute code and collect text outputs, inline images, and errors."""
    kc.execute(code)
    outputs = []   # list of (kind, text)  kind in ('stream','result')
    images  = []   # list of base-64 PNG strings
    error   = None
    while True:
        try:
            msg = kc.get_iopub_msg(timeout=60)
        except Exception:
            break
        mtype   = msg['msg_type']
        content = msg['content']
        if mtype == 'stream':
            outputs.append(('stream', content['text']))
        elif mtype in ('execute_result', 'display_data'):
            img = content['data'].get('image/png')
            if img:
                images.append(img)
            else:
                text = content['data'].get('text/plain', '')
                if text:
                    outputs.append(('result', text))
        elif mtype == 'error':
            error = '\n'.join(content['traceback'])
        elif mtype == 'status' and content.get('execution_state') == 'idle':
            break
    return outputs, images, error


def _start_kernel(project_name):
    import jupyter_client
    km = jupyter_client.KernelManager(kernel_name='python3')
    km.start_kernel()
    kc = km.client()
    kc.start_channels()
    kc.wait_for_ready(timeout=60)

    # Configure matplotlib for inline PNG output, then preload labdata
    init_lines = [
        "import matplotlib",
        "matplotlib.use('Agg')",
        "import pylab as plt",
        "%matplotlib inline",
    ]
    if project_name:
        init_lines += [
            "import os",
            f"os.environ['LABDATA_DATABASE_PROJECT'] = {project_name!r}",
        ]
    init_lines += [
        "from labdata import *",
        "from labdata.schema import *",
    ]
    _execute_silent(kc, '\n'.join(init_lines))

    st.session_state['_console_km']    = km
    st.session_state['_console_kc']    = kc
    st.session_state['_console_hist']  = []
    st.session_state['_console_n']     = 0


def _shutdown_kernel():
    km = st.session_state.pop('_console_km', None)
    st.session_state.pop('_console_kc', None)
    st.session_state.pop('_console_hist', None)
    st.session_state.pop('_console_n', None)
    if km is not None:
        try:
            km.shutdown_kernel(now=True)
        except Exception:
            pass


def console_tab(schema=None):
    project_name = getattr(schema, 'schema_project', None) if schema else None

    # kernel status bar
    alive = '_console_km' in st.session_state
    status_col, btn_col = st.columns([4, 1])
    with status_col:
        if alive:
            st.success("Kernel running  •  `from labdata import *` and `from labdata.schema import *` pre-loaded")
        else:
            st.info("Kernel not started. Click **Start kernel** to launch an IPython kernel.")
    with btn_col:
        if not alive:
            if st.button("Start kernel", type="primary", use_container_width=True):
                with st.spinner("Starting IPython kernel…"):
                    _start_kernel(project_name)
                st.rerun()
        else:
            if st.button("Restart kernel", type="secondary", use_container_width=True):
                _shutdown_kernel()
                with st.spinner("Restarting…"):
                    _start_kernel(project_name)
                st.rerun()

    if not alive:
        return

    kc      = st.session_state['_console_kc']
    history = st.session_state['_console_hist']

    # cell history
    for entry in history:
        n = entry['n']
        st.code(f"In [{n}]:\n{entry['input']}", language='python')
        for kind, text in entry['outputs']:
            if kind == 'result':
                st.text(f"Out [{n}]: {text.rstrip()}")
            else:
                st.text(text.rstrip())
        for b64 in entry['images']:
            st.image(base64.b64decode(b64))
        if entry['error']:
            st.error(entry['error'])

    if history:
        st.divider()

    # input area 
    code = st.text_area(
        "code_input",
        height=130,
        placeholder="Python / IPython code — plots are displayed inline",
        label_visibility='collapsed',
        key='_console_code',
    )

    run_col, clear_col, _ = st.columns([1, 1, 6])
    with run_col:
        run_pressed = st.button("▶ Run", type="primary", use_container_width=True)
    with clear_col:
        if st.button("Clear", use_container_width=True):
            st.session_state['_console_hist'] = []
            st.session_state['_console_n']    = 0
            st.rerun()

    if run_pressed and code.strip():
        with st.spinner("Running…"):
            outputs, images, error = _execute(kc, code)
        n = st.session_state['_console_n'] + 1
        st.session_state['_console_n'] = n
        history.append(dict(n=n, input=code,
                            outputs=outputs, images=images, error=error))
        st.rerun()

        
