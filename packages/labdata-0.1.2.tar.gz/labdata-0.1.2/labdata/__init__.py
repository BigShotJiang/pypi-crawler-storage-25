VERSION = "0.1.2"

from .utils import *
from .copy import copy_to_upload_server
from .s3 import copy_to_s3

_default_project = (prefs.get('database', {}) or {}).get('database.project', None)
plugins = load_plugins(project=_default_project)
for _name, _mod in plugins.items():
    globals()[_name] = _mod

