from .general import *
from .procedures import *
from .histology import *

@dataschema
class TwoPhoton(dj.Imported):
    definition = '''
    -> Dataset
    ---
    n_planes               : smallint            # number of planes
    n_channels             : smallint            # number of channels
    n_frames               : int                 # duration of the recording
    width                  : int                 # width of each frame
    height                 : int                 # height of each frame
    frame_rate             : double              # frame rate
    -> File                                      # path to the stack
    magnification = NULL   : double              # magnification
    objective_angle = NULL : double              # angle
    objective = NULL       : varchar(32)         # objective
    um_per_pixel = NULL    : blob                # XY scale conversion factors
    scanning_mode = NULL   : varchar(32)         # bidirectional or unidirectional
    pmt_gain = NULL        : blob                # pmt gains
    imaging_software       : varchar(32)         # software and version
    -> [nullable] Atlas.Region                   # target region (or the center of the imaging plane)
    '''

    class Plane(dj.Part):
        definition = '''
        -> master
        plane_num               : smallint       # probe number
        ---
        plane_depth = NULL      : float          # depth from surface
        '''
    
    def open(self):
        # download and open a stack
        if len(self) != 1:
            raise(ValueError(f'Select only one dataset {self.proj().fetch(as_dict = True)}.'))
        fname = (File() & self).get()[0]
        return open_zarr(fname)

@analysisschema
class CellSegmentationParams(dj.Manual):
    definition = '''
    parameter_set_num      : int            # number of the parameters set
    ---
    algorithm_name               : varchar(64)    # cell segmentation algorithm
    parameter_description = NULL : varchar(256)   # description or specific use case
    parameters_dict              : varchar(2000)  # parameters json formatted dictionary "json.dumps"
    code_link = NULL             : varchar(300)   # link to the code
    '''


@analysisschema
class CellSegmentation(dj.Imported):
    definition = '''
    -> Dataset
    -> CellSegmentationParams
    ---
    algorithm_version             : varchar(56)     # version of the algorithm
    n_rois                        : int             # number of segmented ROIs
    crop_region = NULL            : blob            # Region to crop
    segmentation_datetime = NULL  : datetime        # date that the algorith was ran
    -> [nullable] AnalysisFile                      # results file (optional)
    container_version = NULL      : varchar(512)    # name and version of the container
     '''
    class Plane(dj.Part):
        definition = '''
        -> master
        plane_num                 : smallint
        ---
        plane_n_rois              : int
        dims = NULL               : blob            # dimensions of the plane
        '''
    class MotionCorrection(dj.Part):
        definition = '''
        -> master.Plane
        ---
        motion_block_size = 0     : int             # 0 is rigid
        displacement              : longblob        # storage of the motion displacement 
        '''
    class Projection(dj.Part):
        definition = '''
        -> master.Plane
        proj_name                 : varchar(16)
        ---
        proj_im                   : longblob
        '''
    class ROI(dj.Part):
        definition = '''
        -> master.Plane
        roi_num                   : int
        ---
        roi_pixels                : blob
        roi_pixels_values = NULL  : blob
        neuropil_pixels = NULL    : blob
        '''
        def get_roi_sparse_masks(self):
            '''
            This returns a sparse array for the sake of speed.
        
            '''
            try:
                dims = (CellSegmentation.Plane & self).fetch1('dims')
            except dj.DataJointError as err:
                if 'fetch1 should only' in str(err):
                    raise ValueError(
                        f"Can only get ROIs simultanously from a single plane {(CellSegmentation.Plane & self).fetch('session_name','plane_num',as_dict = True)}.")
                else:
                    raise(err)
            sparse_masks = []
            from scipy import sparse
            for roi in self.fetch(as_dict = True):
                sparse_masks.append(sparse.csr_array((roi['roi_pixels_values'], 
                                                      np.unravel_index(roi['roi_pixels'],dims)), shape=dims, dtype = 'float32'))
            return sparse_masks
        
        def get_roi_contours(self, percentile_threshold = 80, footprints = None):
            if footprints is None:
                footprints = self.get_roi_sparse_masks()
            roi_contours = []
            from skimage.measure import find_contours
            for f in footprints:
                level = np.percentile(f.data,percentile_threshold)
                from skimage.measure import find_contours
                cc = find_contours(f.todense(),level = level)
                if len(cc):
                    # take the largest contour
                    roi_contours.append(cc[np.argmax([len(c) for c in cc])][:,::-1]) # flip the dimensions so the scatter works out of the box
                else:
                    roi_contours.append(None)
            return roi_contours
                
    class RawTraces(dj.Part):
        definition = '''
        -> master.ROI
        ---
        f_trace                   : longblob
        f_neuropil = NULL         : longblob 
        '''    
    class Traces(dj.Part):
        definition = '''
        -> master.ROI
        ---
        dff                       : longblob
        neuropil_coeff = NULL     : float
        '''
    class Deconvolved(dj.Part):
        definition = '''
        -> master.ROI
        ---
        deconv                    : longblob
        '''
    
    class Selection(dj.Part):
        definition = '''
        -> master.ROI
        selection_method = 'auto' : varchar(12)
        ---
        selection                 : smallint      # 0 not a cell, 1 is a cell
        likelihood = NULL         : float
        '''
    
    class LinkedDatasets(dj.Part):
        definition = '''
        -> master
        linked_session_id         : int
        ---
        -> Dataset.proj(linked_session_name='session_name',linked_dataset_session='dataset_name')
    '''
        
    def delete(
            self,
            transaction = True,
            safemode  = None,
            force_parts = False):
        files = [f['file_path'] for f in self]
        
        super().delete(transaction = transaction,
                       safemode = safemode,
                       force_parts = force_parts)
        if len(self) == 0:
            if len(files):
                (AnalysisFile() & [f'file_path = "{t}"' for t in files]).delete(force_parts=force_parts, 
                                                                                safemode = safemode) 

def _roi_compactness(ypix, xpix):
    '''Ratio of actual mean radial spread to the expected value for a same-area disk.

    A perfect disk returns 1.0; more irregular or elongated ROIs return values > 1.0.
    The expected mean radial spread for a uniform disk of radius R is (2/3)*R,
    and R = sqrt(npix / pi), giving mrs0 = (2/3) * sqrt(npix / pi).
    '''
    med_y = np.median(ypix)
    med_x = np.median(xpix)
    dists = np.sqrt((ypix - med_y) ** 2 + (xpix - med_x) ** 2)
    mrs = dists.mean()
    mrs0 = (2.0 / 3.0) * np.sqrt(len(ypix) / np.pi)
    return float(max(1.0, mrs / (mrs0 + 1e-10)))


def _roi_aspect_ratio(ypix, xpix, values=None):
    '''Aspect ratio and diameter from the eigenvalues of the weighted pixel covariance matrix.

    Fits a 2-D Gaussian to the ROI by computing the weighted covariance of pixel
    positions.  The square-roots of the covariance eigenvalues give the principal-axis
    radii (major r0, minor r1).
    
    Returns:
      aspect_ratio = 2*r0 / (r0 + r1 + 0.01) — circular ~1.0, elongated approaches 2.0
      diameter     = 2*r0 in pixels (major-axis diameter of the fitted Gaussian)

    Returns (None, None) if it can not fit
    '''
    lam = np.ones(len(ypix), dtype='float64') if values is None else np.array(values, dtype='float64')
    lam = lam / lam.sum()
    mu_y = np.dot(lam, ypix)
    mu_x = np.dot(lam, xpix)
    dy = ypix - mu_y
    dx = xpix - mu_x
    cov = np.array([
        [np.dot(lam, dy * dy), np.dot(lam, dy * dx)],
        [np.dot(lam, dx * dy), np.dot(lam, dx * dx)],
    ])
    eigvals = np.sort(np.linalg.eigvalsh(cov))[::-1]  # descending: major, minor
    radii = np.sqrt(np.maximum(eigvals, 0.0))
    if radii[0] + radii[1] < 1e-10:
        return None, None
    aspect_ratio = float(2.0 * radii[0] / (radii[0] + radii[1] + 0.01))
    diameter = float(2.0 * radii[0])
    return aspect_ratio, diameter


def _crop_soma(ypix, xpix, values):
    '''Boolean mask that keeps soma pixels and excludes dendritic/process pixels.

    Pixels are sorted by distance from the weighted centroid.  The cumulative
    sum of pixel weights grows steeply in the soma (high-weight pixels near the
    center) and slows once sparse dendrite pixels are reached.  The cutoff is
    set at the last sorted pixel whose weight still exceeds 1/3 of the peak
    per-pixel weight.

    For ROIs with uniform weights (no spatial weight information), the fallback
    keeps all pixels within the effective disk radius sqrt(npix / pi).

    Adapted from suite2p
    '''
    lam = np.array(values, dtype='float64')

    # Uniform-weight fallback: use distance from mean centre
    if lam.max() <= lam.min():
        mu_y, mu_x = ypix.mean(), xpix.mean()
        dists = np.sqrt((ypix - mu_y) ** 2 + (xpix - mu_x) ** 2)
        return dists <= np.sqrt(len(ypix) / np.pi)

    lam_norm = lam / lam.sum()
    mu_y = np.dot(lam_norm, ypix)
    mu_x = np.dot(lam_norm, xpix)
    dists = np.sqrt((ypix - mu_y) ** 2 + (xpix - mu_x) ** 2)

    order = np.argsort(dists)
    lam_sorted = lam[order]

    # diff of cumulative weight = per-pixel weight in distance order
    darea = np.diff(np.cumsum(lam_sorted))   # length n-1
    darea_max = darea.max()
    above = np.where(darea > darea_max / 3.0)[0]
    if len(above) == 0:
        return np.ones(len(ypix), dtype=bool)

    # +2: darea is 1 shorter than lam_sorted, and we include the cutoff pixel
    cutoff = above[-1] + 2
    mask = np.zeros(len(ypix), dtype=bool)
    mask[order[:cutoff]] = True
    return mask


@analysisschema
class CellSegmentationMetrics(dj.Computed):
    definition = '''
    -> CellSegmentation.ROI
    ---
    x_pos = NULL             : float         # x centroid coordinate (pixels)
    y_pos = NULL             : float         # y centroid coordinate (pixels)
    npix = NULL              : int           # number of pixels in ROI
    diameter = NULL          : float         # effective diameter = 2*sqrt(npix/pi)
    roi_skewness = NULL      : float         # skewness of pixel-weight distribution
    compactness = NULL       : float         # mean radial spread / expected for same-area disk (>=1)
    aspect_ratio = NULL      : float         # 2*major/(major+minor+0.01) from pixel covariance
    snr = NULL               : float         # 90th-pctile dff / noise_level
    noise_level = NULL       : float         # median(|diff(dff)|) / sqrt(2)
    std = NULL               : float         # standard deviation of dff trace
    trace_skewness = NULL    : float         # skewness of dff distribution
    max_dff = NULL           : float         # peak dff value
    activity_fraction = NULL : float         # fraction of frames where dff > 2*noise_level
    event_rate = NULL        : float         # mean deconvolved activity * frame_rate (events/s)
    neuropil_coeff = NULL    : float         # neuropil contamination coefficient
    correlation_neuropil = NULL : float      # Pearson correlation of raw F with neuropil F
    '''

    def make(self, key):
        from scipy.stats import skew

        # ROI 
        roi = (CellSegmentation.ROI & key).fetch1()
        dims = (CellSegmentation.Plane & key).fetch1('dims')
        ypix, xpix = np.unravel_index(roi['roi_pixels'], dims)
        values = roi['roi_pixels_values']
        if values is None:
            values = np.ones(len(ypix), dtype='float32')

        w = float(values.sum())
        x_pos = float(np.dot(xpix, values) / w)
        y_pos = float(np.dot(ypix, values) / w)
        npix = len(ypix)

        # restrict shape metrics to soma pixels only
        soma = _crop_soma(ypix, xpix, values)
        sy, sx, sv = ypix[soma], xpix[soma], values[soma]

        aspect_ratio, diameter = _roi_aspect_ratio(sy, sx, sv)

        metrics = dict(key,
            x_pos=x_pos, y_pos=y_pos,
            npix=npix,
            diameter=diameter,
            roi_skewness=float(skew(values)) if npix > 3 else None,
            compactness=_roi_compactness(sy, sx),
            aspect_ratio=aspect_ratio,
        )

        # traces 
        trace_rows = (CellSegmentation.Traces & key).fetch(as_dict=True)
        if trace_rows:
            dff = trace_rows[0]['dff']
            noise_level = float(np.median(np.abs(np.diff(dff))) / np.sqrt(2))
            snr = float(np.percentile(dff, 90) / noise_level) if noise_level > 0 else None
            metrics.update(
                snr=snr,
                noise_level=noise_level,
                std=float(np.std(dff)),
                trace_skewness=float(skew(dff)),
                max_dff=float(np.max(dff)),
                activity_fraction=float(np.mean(dff > 2 * noise_level)),
                neuropil_coeff=trace_rows[0].get('neuropil_coeff'),
            )
            # correlation with neuropil (only when f_neuropil is available)
            raw_rows = (CellSegmentation.RawTraces & key).fetch(as_dict=True)
            if raw_rows and raw_rows[0].get('f_neuropil') is not None:
                fneu = raw_rows[0]['f_neuropil'].astype('float32')
                fraw = raw_rows[0]['f_trace'].astype('float32')
                if np.std(fneu) > 0 and np.std(fraw) > 0:
                    metrics['correlation_neuropil'] = float(np.corrcoef(fraw, fneu)[0, 1])

        # event rate 
        deconv_rows = (CellSegmentation.Deconvolved & key).fetch(as_dict=True)
        if deconv_rows:
            from .onephoton import Miniscope
            frame_rate = None
            for table in (TwoPhoton, Miniscope):
                try:
                    frame_rate = (table & key).fetch1('frame_rate')
                except Exception:
                    pass
            if not frame_rate is None:
                metrics['event_rate'] = float(np.mean(deconv_rows[0]['deconv']) * frame_rate)

        self.insert1(metrics, skip_duplicates=True)
