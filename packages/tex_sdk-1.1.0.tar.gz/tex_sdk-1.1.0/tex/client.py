from __future__ import annotations

import json
import os
import time
import uuid
from functools import cached_property
from typing import Any, Dict, List, Optional, Tuple, Union

import httpx

from .config import TexConfig
from .errors import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)
from .models import AddResponse, ProfileResponse
from .resources.auth_resource import AuthResource
from .resources.conversations import ConversationsResource
from .resources.db import DBResource
from .resources.documents import DocumentsResource
from .resources.episodes import EpisodesResource
from .resources.jobs import JobsResource
from .resources.memories import MemoriesResource
from .resources.nlq import NLQResource
from .resources.preferences import PreferencesResource
from .resources.recall import RecallResource
from .resources.search import SearchResource
from .resources.usage import UsageResource


_CID_HEADER = "X-Correlation-ID"

_RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}

# Compat endpoints use raw API key as Bearer token (no JWT).
# Tex-unique endpoints use JWT from token exchange.
_COMPAT_PATH_PREFIXES = ("/v3/", "/v4/")

_STATUS_CODE_TO_ERROR = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    422: UnprocessableEntityError,
    429: RateLimitError,
}


class Tex:
    """Tex Python SDK — SuperMemory-compatible, resource-based API."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        org_id: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        access_token: Optional[str] = None,
        refresh_token: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        http2: bool = True,
        config: Optional[TexConfig] = None,
    ):
        if config is not None:
            self._config = config
        else:
            resolved_api_key = api_key or os.environ.get("TEX_API_KEY")
            resolved_base_url = base_url or os.environ.get("TEX_BASE_URL", "")
            self._config = TexConfig(
                base_url=resolved_base_url,
                api_key=resolved_api_key,
                org_id=org_id,
                user_id=user_id,
                session_id=session_id,
                access_token=access_token,
                refresh_token=refresh_token,
                timeout_s=timeout if timeout is not None else 60.0,
                max_retries=max_retries if max_retries is not None else 2,
                http2=http2,
            )

        base = self._config.base_url.rstrip("/")
        if not base:
            raise ValueError(
                "base_url is required. Provide it directly or set TEX_BASE_URL."
            )

        try:
            self._http = httpx.Client(
                base_url=base,
                timeout=self._config.timeout_s,
                http2=self._config.http2,
                headers={"Accept": "application/json"},
            )
        except ImportError as e:
            if "h2" in str(e):
                self._http = httpx.Client(
                    base_url=base,
                    timeout=self._config.timeout_s,
                    http2=False,
                    headers={"Accept": "application/json"},
                )
                self._config.http2 = False
            else:
                raise

        self._access_token: Optional[str] = self._config.access_token
        self._refresh_token: Optional[str] = self._config.refresh_token
        self._tenant: Optional[Dict[str, Any]] = None

        self._explicit_org_id = self._config.org_id
        self._explicit_user_id = self._config.user_id
        self._explicit_session_id = self._config.session_id
        self._refreshing = False

    # ----------------------------- Lifecycle --------------------------------

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Tex:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    # ----------------------------- Resources --------------------------------

    @cached_property
    def documents(self) -> DocumentsResource:
        return DocumentsResource(self)

    @cached_property
    def search(self) -> SearchResource:
        return SearchResource(self)

    @cached_property
    def memories(self) -> MemoriesResource:
        return MemoriesResource(self)

    @cached_property
    def conversations(self) -> ConversationsResource:
        return ConversationsResource(self)

    @cached_property
    def recall(self) -> RecallResource:
        return RecallResource(self)

    @cached_property
    def nlq(self) -> NLQResource:
        return NLQResource(self)

    @cached_property
    def episodes(self) -> EpisodesResource:
        return EpisodesResource(self)

    @cached_property
    def preferences(self) -> PreferencesResource:
        return PreferencesResource(self)

    @cached_property
    def db(self) -> DBResource:
        return DBResource(self)

    @cached_property
    def auth(self) -> AuthResource:
        return AuthResource(self)

    @cached_property
    def jobs(self) -> JobsResource:
        return JobsResource(self)

    @cached_property
    def usage(self) -> UsageResource:
        """Read this org's metering totals: ``tex.usage.today()`` /
        ``tex.usage.summary()``. The org is implicit in the JWT — no need to
        pass an org_id from the call site.
        """
        return UsageResource(self)

    # ----------------------------- Top-level convenience -------------------

    def add(
        self,
        content: str,
        *,
        container_tag: Optional[str] = None,
        container_tags: Optional[List[str]] = None,
        custom_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AddResponse:
        return self.documents.add(
            content,
            container_tag=container_tag,
            container_tags=container_tags,
            custom_id=custom_id,
            metadata=metadata,
        )

    def profile(
        self,
        container_tag: str,
        *,
        q: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
        threshold: Optional[float] = None,
    ) -> ProfileResponse:
        ep = self._config.endpoints
        payload: Dict[str, Any] = {"containerTag": container_tag}
        if q is not None:
            payload["q"] = q
        if filters is not None:
            payload["filters"] = filters
        if threshold is not None:
            payload["threshold"] = threshold
        raw = self._request("POST", ep.profile, json_body=payload)
        return ProfileResponse.from_dict(raw)

    # ----------------------------- Internal: scope -------------------------

    def _scope_payload(self) -> Dict[str, Any]:
        self._ensure_auth()
        if not self._config.org_id or not self._config.user_id:
            self._ensure_tenant()

        org_id = self._config.org_id or (self._tenant or {}).get("org_id") or "_"
        user_id = self._config.user_id or (self._tenant or {}).get("user_id") or "_"
        session_id = self._config.session_id or (self._tenant or {}).get("session_id")
        return {"org_id": org_id, "user_id": user_id, "session_id": session_id}

    def _ensure_tenant(self) -> None:
        if self._tenant is not None and self._tenant.get("org_id") and self._tenant.get("user_id"):
            return
        try:
            data = self._request("GET", self._config.endpoints.auth_verify)
            tenant = data.get("tenant") if isinstance(data, dict) else None
            if isinstance(tenant, dict):
                self._tenant = tenant
                if not self._config.org_id and isinstance(tenant.get("org_id"), str):
                    self._config.org_id = tenant.get("org_id")
                if not self._config.user_id and isinstance(tenant.get("user_id"), str):
                    self._config.user_id = tenant.get("user_id")
                if not self._config.session_id and isinstance(tenant.get("session_id"), str):
                    self._config.session_id = tenant.get("session_id")
                return
        except APIStatusError:
            pass
        self._tenant = self._tenant or {}

    # ----------------------------- Internal: auth --------------------------

    def _ensure_auth(self) -> None:
        if self._access_token:
            return
        ep = self._config.endpoints

        if self._config.access_token:
            self._access_token = self._config.access_token
            self._refresh_token = self._config.refresh_token
            return

        if self._config.api_key:
            tokens = self._post_noauth(ep.auth_token_exchange, {"api_key": self._config.api_key})
            access = tokens.get("access_token")
            if not access:
                raise AuthenticationError(
                    "Token exchange did not return access_token", status_code=401
                )
            self._access_token = access
            self._refresh_token = tokens.get("refresh_token")

            self._ensure_tenant()

            if self._explicit_user_id:
                org_id = self._explicit_org_id or self._config.org_id or (self._tenant or {}).get("org_id")
                if not isinstance(org_id, str) or not org_id:
                    raise AuthenticationError(
                        "Could not determine org_id for user login", status_code=401
                    )
                login_tokens = self._post_noauth(
                    ep.auth_login,
                    {
                        "org_id": org_id,
                        "user_id": self._explicit_user_id,
                        "session_id": self._explicit_session_id,
                    },
                )
                self._access_token = login_tokens.get("access_token")
                self._refresh_token = login_tokens.get("refresh_token")
                if not self._access_token:
                    raise AuthenticationError(
                        "Login did not return access_token", status_code=401
                    )
                self._tenant = None
                self._ensure_tenant()
            return

        if self._config.org_id and self._config.user_id:
            tokens = self._post_noauth(
                ep.auth_login,
                {
                    "org_id": self._config.org_id,
                    "user_id": self._config.user_id,
                    "session_id": self._config.session_id,
                },
            )
            self._access_token = tokens.get("access_token")
            self._refresh_token = tokens.get("refresh_token")
            if not self._access_token:
                raise AuthenticationError(
                    "Login did not return access_token", status_code=401
                )
            return

        raise AuthenticationError(
            "No auth configured. Provide api_key, or org_id+user_id, or access_token.",
            status_code=401,
        )

    def _refresh_auth(self) -> None:
        if self._refreshing:
            raise AuthenticationError(
                "Authentication refresh cycle detected", status_code=401
            )
        self._refreshing = True
        try:
            self._refresh_auth_inner()
        finally:
            self._refreshing = False

    def _refresh_auth_inner(self) -> None:
        ep = self._config.endpoints
        if self._refresh_token:
            tokens = self._post_noauth(ep.auth_refresh, {"refresh_token": self._refresh_token})
            self._access_token = tokens.get("access_token")
            self._refresh_token = tokens.get("refresh_token")
            if self._access_token:
                return

        if self._config.api_key:
            if self._explicit_user_id:
                org_id = self._explicit_org_id or self._config.org_id or (self._tenant or {}).get("org_id")
                if not org_id:
                    self._access_token = None
                    self._refresh_token = None
                    self._tenant = None
                    self._ensure_auth()
                    return
                login_tokens = self._post_noauth(
                    ep.auth_login,
                    {
                        "org_id": org_id,
                        "user_id": self._explicit_user_id,
                        "session_id": self._explicit_session_id,
                    },
                )
                self._access_token = login_tokens.get("access_token")
                self._refresh_token = login_tokens.get("refresh_token")
                if self._access_token:
                    self._tenant = None
                    return

            self._access_token = None
            self._refresh_token = None
            self._tenant = None
            self._ensure_auth()
            return

        raise AuthenticationError(
            "Authentication expired and could not be refreshed", status_code=401
        )

    # ----------------------------- Internal: HTTP --------------------------

    @staticmethod
    def _is_compat_path(path: str) -> bool:
        """Check if path targets a compat endpoint (/v3/* or /v4/*)."""
        return any(path.startswith(prefix) for prefix in _COMPAT_PATH_PREFIXES)

    def _compat_headers(self) -> Dict[str, str]:
        """Headers for compat endpoints: raw API key as Bearer token."""
        if not self._config.api_key:
            raise AuthenticationError(
                "Compat endpoints (/v3/*, /v4/*) require api_key auth. "
                "JWTs and org_id+user_id login are not accepted.",
                status_code=401,
            )
        return {
            "Authorization": f"Bearer {self._config.api_key}",
            _CID_HEADER: str(uuid.uuid4()),
        }

    def _jwt_headers(self) -> Dict[str, str]:
        """Headers for Tex-unique endpoints: JWT from token exchange."""
        self._ensure_auth()
        return {
            "Authorization": f"Bearer {self._access_token}",
            _CID_HEADER: str(uuid.uuid4()),
        }

    def _headers_for_path(self, path: str) -> Dict[str, str]:
        """Route to compat or JWT headers based on endpoint path."""
        if self._is_compat_path(path):
            return self._compat_headers()
        return self._jwt_headers()

    def _request(
        self,
        method: str,
        path: str,
        json_body: Any = None,
        query_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        is_compat = self._is_compat_path(path)
        headers = self._headers_for_path(path)
        last_exc: Optional[Exception] = None
        max_retries = self._config.max_retries
        attempt = 0
        did_401_refresh = False

        while True:
            try:
                resp = self._http.request(
                    method, path, json=json_body, params=query_params, headers=headers
                )
            except httpx.TimeoutException as e:
                last_exc = APITimeoutError(f"Request timed out: {e}")
                if attempt < max_retries:
                    time.sleep(self._backoff_delay(attempt))
                    attempt += 1
                    continue
                raise last_exc
            except httpx.HTTPError as e:
                last_exc = APIConnectionError(f"Network error: {e}")
                if attempt < max_retries:
                    time.sleep(self._backoff_delay(attempt))
                    attempt += 1
                    continue
                raise last_exc

            # 401 on compat endpoints means bad API key — no refresh possible
            # 401 on tex-unique endpoints: try JWT refresh (at most once)
            if resp.status_code == 401 and not is_compat and not did_401_refresh:
                did_401_refresh = True
                self._refresh_auth()
                headers = self._headers_for_path(path)
                continue

            # Retryable status codes
            if resp.status_code in _RETRYABLE_STATUS_CODES and attempt < max_retries:
                delay = self._backoff_delay(attempt)
                retry_after = resp.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = max(delay, float(retry_after))
                    except ValueError:
                        pass
                time.sleep(delay)
                attempt += 1
                continue

            # Error responses
            if resp.status_code >= 400:
                self._raise_for_status(resp)

            # Success
            if not resp.content:
                return {}
            try:
                data = resp.json()
                return data if isinstance(data, dict) else {"data": data}
            except Exception:
                return {"data": resp.text}

    def _post_noauth(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        headers = {_CID_HEADER: str(uuid.uuid4())}
        try:
            resp = self._http.post(path, json=payload, headers=headers)
        except httpx.TimeoutException as e:
            raise APITimeoutError(f"Request timed out: {e}")
        except httpx.HTTPError as e:
            raise APIConnectionError(f"Network error: {e}")

        if resp.status_code >= 400:
            self._raise_for_status(resp)

        data = resp.json()
        return data if isinstance(data, dict) else {"data": data}

    def _raise_for_status(self, resp: httpx.Response) -> None:
        request_id = resp.headers.get(_CID_HEADER)
        msg, details = self._safe_error_from_response(resp)
        msg = self._decorate_error_message(msg, resp.status_code, details)
        response_text = resp.text[:2000] if resp.text else None

        exc_cls = _STATUS_CODE_TO_ERROR.get(resp.status_code)
        if exc_cls is None:
            exc_cls = InternalServerError if resp.status_code >= 500 else APIStatusError

        raise exc_cls(
            msg,
            status_code=resp.status_code,
            request_id=request_id,
            response_text=response_text,
            details=details,
        )

    @staticmethod
    def _backoff_delay(attempt: int) -> float:
        return 0.5 * (2 ** attempt)

    @staticmethod
    def _safe_error_from_response(resp: httpx.Response) -> Tuple[str, Any]:
        try:
            payload = resp.json()
            if isinstance(payload, dict):
                error = payload.get("error")
                if isinstance(error, str) and error.strip():
                    return error, payload
                detail = payload.get("detail")
                if isinstance(detail, str) and detail.strip():
                    return detail, payload
                if detail is not None:
                    try:
                        return json.dumps(detail, ensure_ascii=False), payload
                    except Exception:
                        return str(detail), payload
                message = payload.get("message")
                if isinstance(message, str) and message.strip():
                    return message, payload
                return "Request failed", payload
            return "Request failed", payload
        except Exception:
            return "Request failed", resp.text

    @staticmethod
    def _decorate_error_message(msg: str, status_code: int, details: Any) -> str:
        if not isinstance(msg, str) or not msg.strip():
            return "Request failed"
        if status_code == 422:
            lowered = msg.lower()
            if "intentgraph validation" in lowered or "root variable must have a type" in lowered:
                return (
                    f"{msg.strip()}\n\n"
                    "Hint: this is usually a planner/schema issue. Verify the DB has a non-empty schema "
                    "and that the backend can fetch it (e.g., GET /schema-json and POST /planner/plan)."
                )
        return msg.strip()
