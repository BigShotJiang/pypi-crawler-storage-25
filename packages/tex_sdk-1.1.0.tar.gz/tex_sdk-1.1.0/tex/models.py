from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


def _get(d: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    """Try multiple keys (camelCase / snake_case) and return first match."""
    for k in keys:
        if k in d:
            return d[k]
    return default


# ---------------------------------------------------------------------------
# Documents
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AddResponse:
    id: str
    status: str
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> AddResponse:
        return cls(id=d.get("id", ""), status=d.get("status", ""), raw=d)


@dataclass(frozen=True)
class DocumentGetResponse:
    id: str
    content: Optional[str]
    created_at: Optional[str]
    updated_at: Optional[str]
    custom_id: Optional[str]
    metadata: Any
    container_tags: Optional[List[str]]
    status: Optional[str]
    type: Optional[str]
    title: Optional[str]
    summary: Optional[str]
    url: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> DocumentGetResponse:
        return cls(
            id=d.get("id", ""),
            content=d.get("content"),
            created_at=_get(d, "createdAt", "created_at"),
            updated_at=_get(d, "updatedAt", "updated_at"),
            custom_id=_get(d, "customId", "custom_id"),
            metadata=d.get("metadata"),
            container_tags=_get(d, "containerTags", "container_tags"),
            status=d.get("status"),
            type=d.get("type"),
            title=d.get("title"),
            summary=d.get("summary"),
            url=d.get("url"),
            raw=d,
        )


@dataclass(frozen=True)
class Pagination:
    current_page: int
    total_items: int
    total_pages: int
    limit: int
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> Pagination:
        return cls(
            current_page=int(_get(d, "current_page", "currentPage", default=0)),
            total_items=int(_get(d, "total_items", "totalItems", default=0)),
            total_pages=int(_get(d, "total_pages", "totalPages", default=0)),
            limit=int(d.get("limit", 0)),
            raw=d,
        )


@dataclass(frozen=True)
class Memory:
    id: str
    status: Optional[str]
    type: Optional[str]
    title: Optional[str]
    summary: Optional[str]
    created_at: Optional[str]
    updated_at: Optional[str]
    custom_id: Optional[str]
    metadata: Any
    container_tags: Optional[List[str]]
    content: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> Memory:
        return cls(
            id=d.get("id", ""),
            status=d.get("status"),
            type=d.get("type"),
            title=d.get("title"),
            summary=d.get("summary"),
            created_at=_get(d, "createdAt", "created_at"),
            updated_at=_get(d, "updatedAt", "updated_at"),
            custom_id=_get(d, "customId", "custom_id"),
            metadata=d.get("metadata"),
            container_tags=_get(d, "containerTags", "container_tags"),
            content=d.get("content"),
            raw=d,
        )


@dataclass(frozen=True)
class DocumentListResponse:
    memories: List[Memory]
    pagination: Pagination
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> DocumentListResponse:
        memories_raw = d.get("memories", [])
        memories = [Memory.from_dict(m) if isinstance(m, dict) else m for m in memories_raw]
        pag_raw = d.get("pagination", {})
        pagination = Pagination.from_dict(pag_raw) if isinstance(pag_raw, dict) else Pagination(0, 0, 0, 0)
        return cls(memories=memories, pagination=pagination, raw=d)


@dataclass(frozen=True)
class BatchResult:
    id: str
    status: str
    error: Optional[str]
    details: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> BatchResult:
        return cls(
            id=d.get("id", ""), status=d.get("status", ""),
            error=d.get("error"), details=d.get("details"), raw=d,
        )


@dataclass(frozen=True)
class DocumentBatchAddResponse:
    success: int
    failed: int
    results: List[BatchResult]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> DocumentBatchAddResponse:
        results_raw = d.get("results", [])
        results = [BatchResult.from_dict(r) if isinstance(r, dict) else r for r in results_raw]
        return cls(
            success=int(d.get("success", 0)), failed=int(d.get("failed", 0)),
            results=results, raw=d,
        )


@dataclass(frozen=True)
class DocumentDeleteBulkResponse:
    deleted_count: int
    success: bool
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> DocumentDeleteBulkResponse:
        return cls(
            deleted_count=int(_get(d, "deleted_count", "deletedCount", default=0)),
            success=bool(d.get("success", False)), raw=d,
        )


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SearchChunk:
    content: str
    is_relevant: Optional[bool]
    score: Optional[float]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> SearchChunk:
        return cls(
            content=d.get("content", ""),
            is_relevant=_get(d, "is_relevant", "isRelevant"),
            score=d.get("score"), raw=d,
        )


@dataclass(frozen=True)
class SearchResult:
    document_id: str
    score: float
    chunks: List[SearchChunk]
    created_at: Optional[str]
    updated_at: Optional[str]
    metadata: Any
    title: Optional[str]
    type: Optional[str]
    content: Optional[str]
    summary: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> SearchResult:
        chunks_raw = d.get("chunks", [])
        chunks = [SearchChunk.from_dict(c) if isinstance(c, dict) else c for c in chunks_raw]
        return cls(
            document_id=_get(d, "documentId", "document_id", default=""),
            score=float(d.get("score", 0.0)), chunks=chunks,
            created_at=_get(d, "createdAt", "created_at"),
            updated_at=_get(d, "updatedAt", "updated_at"),
            metadata=d.get("metadata"), title=d.get("title"),
            type=d.get("type"), content=d.get("content"),
            summary=d.get("summary"), raw=d,
        )


@dataclass(frozen=True)
class SearchDocumentsResponse:
    results: List[SearchResult]
    timing: float
    total: int
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> SearchDocumentsResponse:
        results_raw = d.get("results", [])
        results = [SearchResult.from_dict(r) if isinstance(r, dict) else r for r in results_raw]
        return cls(
            results=results, timing=float(d.get("timing", 0.0)),
            total=int(d.get("total", 0)), raw=d,
        )


@dataclass(frozen=True)
class MemorySearchResult:
    id: str
    similarity: float
    updated_at: Optional[str]
    metadata: Any
    memory: Optional[str]
    chunk: Optional[str]
    version: Optional[int]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> MemorySearchResult:
        return cls(
            id=d.get("id", ""), similarity=float(d.get("similarity", 0.0)),
            updated_at=_get(d, "updatedAt", "updated_at"),
            metadata=d.get("metadata"), memory=d.get("memory"),
            chunk=d.get("chunk"), version=d.get("version"), raw=d,
        )


@dataclass(frozen=True)
class SearchMemoriesResponse:
    results: List[MemorySearchResult]
    timing: float
    total: int
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> SearchMemoriesResponse:
        results_raw = d.get("results", [])
        results = [MemorySearchResult.from_dict(r) if isinstance(r, dict) else r for r in results_raw]
        return cls(
            results=results, timing=float(d.get("timing", 0.0)),
            total=int(d.get("total", 0)), raw=d,
        )


# ---------------------------------------------------------------------------
# Memories (v4)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MemoryForgetResponse:
    id: str
    forgotten: bool
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> MemoryForgetResponse:
        return cls(id=d.get("id", ""), forgotten=bool(d.get("forgotten", False)), raw=d)


@dataclass(frozen=True)
class MemoryUpdateResponse:
    id: str
    memory: str
    version: int
    created_at: Optional[str]
    parent_memory_id: Optional[str]
    root_memory_id: Optional[str]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> MemoryUpdateResponse:
        return cls(
            id=d.get("id", ""), memory=d.get("memory", ""),
            version=int(d.get("version", 0)),
            created_at=_get(d, "createdAt", "created_at"),
            parent_memory_id=_get(d, "parentMemoryId", "parent_memory_id"),
            root_memory_id=_get(d, "rootMemoryId", "root_memory_id"),
            raw=d,
        )


# ---------------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Profile:
    static: List[str]
    dynamic: List[str]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> Profile:
        return cls(static=d.get("static", []), dynamic=d.get("dynamic", []), raw=d)


@dataclass(frozen=True)
class SearchResults:
    results: List[Any]
    timing: float
    total: int
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> SearchResults:
        return cls(
            results=d.get("results", []), timing=float(d.get("timing", 0.0)),
            total=int(d.get("total", 0)), raw=d,
        )


@dataclass(frozen=True)
class ProfileResponse:
    profile: Profile
    search_results: Optional[SearchResults]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> ProfileResponse:
        profile_raw = d.get("profile", {})
        profile = Profile.from_dict(profile_raw) if isinstance(profile_raw, dict) else Profile([], [])
        sr_raw = _get(d, "searchResults", "search_results")
        search_results = SearchResults.from_dict(sr_raw) if isinstance(sr_raw, dict) else None
        return cls(profile=profile, search_results=search_results, raw=d)


# ---------------------------------------------------------------------------
# Tex-unique: NLQ
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AskResult:
    """User-friendly NLQ output."""
    text: str
    evidence: List[str]
    entities: List[str]
    documents: List[str]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)


# ---------------------------------------------------------------------------
# Tex-unique: Memories (v4) write response
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MemoryWriteResult:
    id: str
    memory: str
    is_static: bool
    created_at: Optional[str]
    metadata: Any
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> MemoryWriteResult:
        return cls(
            id=d.get("id", ""), memory=d.get("memory", ""),
            is_static=bool(_get(d, "isStatic", "is_static", default=False)),
            created_at=_get(d, "createdAt", "created_at"),
            metadata=d.get("metadata"), raw=d,
        )


@dataclass(frozen=True)
class Usage:
    """Tokens billed for a single Tex API call.

    Mirrors OpenAI / Anthropic ``usage`` objects so a developer's Tex bill
    is denominated in the same unit they already track for their LLM
    provider. Counted server-side using the ``cl100k_base`` encoding (matches
    ``text-embedding-3-large``).
    """

    tokens_in: int
    tokens_out: int

    @classmethod
    def from_dict(cls, d: Optional[Dict[str, Any]]) -> Optional["Usage"]:
        if not d:
            return None
        return cls(
            tokens_in=int(_get(d, "tokens_in", "tokensIn", default=0) or 0),
            tokens_out=int(_get(d, "tokens_out", "tokensOut", default=0) or 0),
        )


@dataclass(frozen=True)
class RememberResponse:
    active_fragment_ids: List[str]
    passive_job_id: Optional[str]
    job_id: Optional[str] = None
    usage: Optional[Usage] = None
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> RememberResponse:
        return cls(
            active_fragment_ids=list(_get(d, "active_fragment_ids", "activeFragmentIds", default=[]) or []),
            passive_job_id=_get(d, "passive_job_id", "passiveJobId"),
            job_id=_get(d, "job_id", "jobId"),
            usage=Usage.from_dict(_get(d, "usage")),
            raw=d,
        )


# ---------------------------------------------------------------------------
# Tex-unique: Recall
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RecallHit:
    id: Optional[str]
    text: str
    score: float
    kind: str = "turn"
    timestamp: Optional[str] = None
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RecallHit":
        return cls(
            id=_get(d, "id"),
            text=str(_get(d, "text", default="") or ""),
            score=float(_get(d, "score", default=0.0) or 0.0),
            kind=str(_get(d, "kind", default="turn") or "turn"),
            timestamp=_get(d, "timestamp"),
            raw=d,
        )


@dataclass(frozen=True)
class RecallEntity:
    id: Optional[str]
    label: str
    score: float
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RecallEntity":
        return cls(
            id=_get(d, "id"),
            label=str(_get(d, "label", default="") or ""),
            score=float(_get(d, "score", default=0.0) or 0.0),
            raw=d,
        )


@dataclass(frozen=True)
class RecallHits:
    observations: List[RecallHit]
    turns: List[RecallHit]
    entities: List[RecallEntity]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RecallHits":
        obs_raw = d.get("observations", []) or []
        turns_raw = d.get("turns", []) or []
        ents_raw = d.get("entities", []) or []
        observations = [RecallHit.from_dict(x) if isinstance(x, dict) else x for x in obs_raw]
        turns = [RecallHit.from_dict(x) if isinstance(x, dict) else x for x in turns_raw]
        entities = [RecallEntity.from_dict(x) if isinstance(x, dict) else x for x in ents_raw]
        return cls(observations=observations, turns=turns, entities=entities, raw=d)


@dataclass(frozen=True)
class RecallResponse:
    hits: RecallHits
    timeline: Optional[str]
    confidence: float
    mode: str
    usage: Optional[Usage] = None
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RecallResponse":
        hits_raw = d.get("hits", {}) or {}
        hits = RecallHits.from_dict(hits_raw) if isinstance(hits_raw, dict) else RecallHits([], [], [])
        return cls(
            hits=hits,
            timeline=_get(d, "timeline"),
            confidence=float(_get(d, "confidence", default=0.0) or 0.0),
            mode=str(_get(d, "mode", default="active") or "active"),
            usage=Usage.from_dict(_get(d, "usage")),
            raw=d,
        )


@dataclass(frozen=True)
class MemoryWriteResponse:
    document_id: Optional[str]
    memories: List[MemoryWriteResult]
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> MemoryWriteResponse:
        mems_raw = d.get("memories", [])
        mems = [MemoryWriteResult.from_dict(m) if isinstance(m, dict) else m for m in mems_raw]
        return cls(
            document_id=_get(d, "documentId", "document_id"),
            memories=mems, raw=d,
        )
