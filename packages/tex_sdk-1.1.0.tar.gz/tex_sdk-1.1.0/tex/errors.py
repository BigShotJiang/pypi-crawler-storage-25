from __future__ import annotations

from typing import Any, Optional


class TexError(Exception):
    """Base SDK error."""


class APIError(TexError):
    """Base class for all API errors."""

    message: str

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)

    def __str__(self) -> str:
        return self.message


class APIConnectionError(APIError):
    """Network-level failure (DNS, refused, reset, etc.)."""


class APITimeoutError(APIConnectionError):
    """Request timed out."""


class APIStatusError(APIError):
    """HTTP response with status >= 400."""

    status_code: int
    request_id: Optional[str]
    response_text: Optional[str]
    details: Any

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        request_id: Optional[str] = None,
        response_text: Optional[str] = None,
        details: Any = None,
    ) -> None:
        self.status_code = status_code
        self.request_id = request_id
        self.response_text = response_text
        self.details = details
        super().__init__(message)

    def __str__(self) -> str:
        base = f"HTTP {self.status_code}: {self.message}"
        if self.request_id:
            base = f"{base} (request_id={self.request_id})"
        return base


class BadRequestError(APIStatusError):
    """400 Bad Request."""


class AuthenticationError(APIStatusError):
    """401 Unauthorized."""


class PermissionDeniedError(APIStatusError):
    """403 Forbidden."""


class NotFoundError(APIStatusError):
    """404 Not Found."""


class ConflictError(APIStatusError):
    """409 Conflict."""


class UnprocessableEntityError(APIStatusError):
    """422 Unprocessable Entity."""


class RateLimitError(APIStatusError):
    """429 Too Many Requests."""


class InternalServerError(APIStatusError):
    """500+ Server Error."""


class APIResponseValidationError(APIError):
    """Response body did not match expected shape."""


# Backward compatibility aliases
TexHTTPError = APIStatusError
TexAuthError = AuthenticationError
