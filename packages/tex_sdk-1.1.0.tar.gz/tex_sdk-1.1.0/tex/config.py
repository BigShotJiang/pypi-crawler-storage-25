from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class TexEndpoints:
    """Endpoint paths for IntegrationBackend (override to match deployments)."""

    # Auth
    auth_login: str = "/auth/login"
    auth_refresh: str = "/auth/refresh"
    auth_token_exchange: str = "/auth/token-exchange"
    auth_verify: str = "/auth/verify"

    # v3 compat — documents
    documents: str = "/v3/documents"
    documents_batch: str = "/v3/documents/batch"
    documents_list: str = "/v3/documents/list"
    documents_bulk_delete: str = "/v3/documents/bulk"

    # v3 compat — search
    search_documents: str = "/v3/search"

    # v4 compat — memories
    memories: str = "/v4/memories"

    # v4 compat — search
    search_memories: str = "/v4/search"

    # v4 compat — profile
    profile: str = "/v4/profile"

    # Tex-unique: ingestion pipeline
    ingestion_document: str = "/ingestion/document"
    ingestion_episode: str = "/ingestion/episode"
    ingestion_preference: str = "/ingestion/preference"
    ingestion_batch: str = "/ingestion/batch"
    ingestion_memory: str = "/ingestion/memory"
    ingestion_status: str = "/ingestion/status/{job_id}"

    # Tex-unique: retrieval
    recall: str = "/recall"

    # Tex-unique: DB
    db_query: str = "/helixdb/query"
    db_schema: str = "/helixdb/schema"

    # Tex-unique: NLQ
    nlq_execute: str = "/nlq/execute"

    # Tex-unique: legacy memories CRUD (non-compat)
    memories_list: str = "/memories"
    memories_get: str = "/memories/{memory_id}"

    # Tex-unique: episodes
    episodes_list: str = "/memories/episodes"

    # Tex-unique: user profile (legacy)
    user_profile: str = "/users/profile"

    # Tex-unique: usage / metering
    usage_today: str = "/usage/today"
    usage_summary: str = "/usage/summary"


@dataclass
class TexConfig:
    """SDK configuration.

    Auth options (in priority order):
    1. api_key: exchanges via /auth/token-exchange -> JWT
    2. org_id + user_id (+ optional session_id): obtains tokens via /auth/login
    3. access_token: directly uses provided token
    """

    base_url: str = ""

    # Auth
    api_key: Optional[str] = None
    org_id: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None

    # Transport
    timeout_s: float = 60.0
    max_retries: int = 2
    http2: bool = True
    endpoints: TexEndpoints = field(default_factory=TexEndpoints)
