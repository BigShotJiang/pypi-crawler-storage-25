from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from ..models import (
    AddResponse,
    DocumentBatchAddResponse,
    DocumentDeleteBulkResponse,
    DocumentGetResponse,
    DocumentListResponse,
)

if TYPE_CHECKING:
    from ..client import Tex


class DocumentsResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def add(
        self,
        content: str,
        *,
        container_tag: Optional[str] = None,
        container_tags: Optional[List[str]] = None,
        custom_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AddResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {"content": content}
        if container_tag is not None:
            payload["containerTag"] = container_tag
        if container_tags is not None:
            payload["containerTags"] = container_tags
        if custom_id is not None:
            payload["customId"] = custom_id
        if metadata is not None:
            payload["metadata"] = metadata
        raw = self._client._request("POST", ep.documents, json_body=payload)
        return AddResponse.from_dict(raw)

    def get(self, id: str, *, container_tag: Optional[str] = None) -> DocumentGetResponse:
        ep = self._client._config.endpoints
        path = f"{ep.documents}/{id}"
        params: Optional[Dict[str, Any]] = None
        if container_tag is not None:
            params = {"containerTag": container_tag}
        raw = self._client._request("GET", path, query_params=params)
        return DocumentGetResponse.from_dict(raw)

    def update(
        self,
        id: str,
        *,
        content: Optional[str] = None,
        container_tag: Optional[str] = None,
        container_tags: Optional[List[str]] = None,
        custom_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AddResponse:
        ep = self._client._config.endpoints
        path = f"{ep.documents}/{id}"
        payload: Dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        if container_tag is not None:
            payload["containerTag"] = container_tag
        if container_tags is not None:
            payload["containerTags"] = container_tags
        if custom_id is not None:
            payload["customId"] = custom_id
        if metadata is not None:
            payload["metadata"] = metadata
        raw = self._client._request("PATCH", path, json_body=payload)
        return AddResponse.from_dict(raw)

    def delete(self, id: str) -> None:
        ep = self._client._config.endpoints
        path = f"{ep.documents}/{id}"
        self._client._request("DELETE", path)

    def delete_bulk(
        self,
        *,
        ids: Optional[List[str]] = None,
        container_tags: Optional[List[str]] = None,
    ) -> DocumentDeleteBulkResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {}
        if ids is not None:
            payload["ids"] = ids
        if container_tags is not None:
            payload["containerTags"] = container_tags
        raw = self._client._request("DELETE", ep.documents_bulk_delete, json_body=payload)
        return DocumentDeleteBulkResponse.from_dict(raw)

    def list(
        self,
        *,
        container_tags: Optional[List[str]] = None,
        include_content: Optional[bool] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        sort: Optional[str] = None,
        order: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> DocumentListResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {}
        if container_tags is not None:
            payload["containerTags"] = container_tags
        if include_content is not None:
            payload["includeContent"] = include_content
        if limit is not None:
            payload["limit"] = limit
        if page is not None:
            payload["page"] = page
        if sort is not None:
            payload["sort"] = sort
        if order is not None:
            payload["order"] = order
        if filters is not None:
            payload["filters"] = filters
        raw = self._client._request("POST", ep.documents_list, json_body=payload)
        return DocumentListResponse.from_dict(raw)

    def batch_add(
        self,
        documents: Union[List[Dict[str, Any]], List[str]],
        *,
        container_tag: Optional[str] = None,
        container_tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> DocumentBatchAddResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {"documents": documents}
        if container_tag is not None:
            payload["containerTag"] = container_tag
        if container_tags is not None:
            payload["containerTags"] = container_tags
        if metadata is not None:
            payload["metadata"] = metadata
        raw = self._client._request("POST", ep.documents_batch, json_body=payload)
        return DocumentBatchAddResponse.from_dict(raw)
