from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..models import RememberResponse

if TYPE_CHECKING:
    from ..client import Tex


class ConversationsResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def remember(
        self,
        turns: List[Dict[str, Any]],
        *,
        session_id: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> RememberResponse:
        """Persist a batch of conversation turns through /ingestion/memory.

        Each turn is {text, role, timestamp, observations?} matching the
        IngestTurn model on the backend. The returned RememberResponse
        carries the active fragment ids and (currently None) passive job id.
        """
        cfg = self._client._config
        ep = cfg.endpoints
        payload: Dict[str, Any] = {
            "scope": {
                "org_id": cfg.org_id,
                "user_id": cfg.user_id,
                "session_id": session_id,
            },
            "turns": turns,
        }
        if metadata is not None:
            payload["metadata"] = metadata
        raw = self._client._request("POST", ep.ingestion_memory, json_body=payload)
        return RememberResponse.from_dict(raw)
