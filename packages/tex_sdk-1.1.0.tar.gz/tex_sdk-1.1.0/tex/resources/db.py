from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ..client import Tex


class DBResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def query(self, query: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {"query": query, "params": params or {}}
        return self._client._request("POST", ep.db_query, json_body=payload)

    def schema(self) -> Dict[str, Any]:
        ep = self._client._config.endpoints
        return self._client._request("GET", ep.db_schema)
