from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..models import MemoryForgetResponse, MemoryUpdateResponse, MemoryWriteResponse

if TYPE_CHECKING:
    from ..client import Tex


class MemoriesResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def add(
        self,
        memories: List[Dict[str, Any]],
        *,
        container_tag: Optional[str] = None,
    ) -> MemoryWriteResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {"memories": memories}
        if container_tag is not None:
            payload["containerTag"] = container_tag
        raw = self._client._request("POST", ep.memories, json_body=payload)
        return MemoryWriteResponse.from_dict(raw)

    def forget(
        self,
        container_tag: Optional[str] = None,
        *,
        id: Optional[str] = None,
        content: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> MemoryForgetResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {}
        if container_tag is not None:
            payload["containerTag"] = container_tag
        if id is not None:
            payload["id"] = id
        if content is not None:
            payload["content"] = content
        if reason is not None:
            payload["reason"] = reason
        raw = self._client._request("DELETE", ep.memories, json_body=payload)
        return MemoryForgetResponse.from_dict(raw)

    def update_memory(
        self,
        container_tag: Optional[str] = None,
        new_content: Optional[str] = None,
        *,
        id: Optional[str] = None,
        content: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> MemoryUpdateResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {}
        if container_tag is not None:
            payload["containerTag"] = container_tag
        if new_content is not None:
            payload["newContent"] = new_content
        if id is not None:
            payload["id"] = id
        if content is not None:
            payload["content"] = content
        if metadata is not None:
            payload["metadata"] = metadata
        raw = self._client._request("PATCH", ep.memories, json_body=payload)
        return MemoryUpdateResponse.from_dict(raw)
