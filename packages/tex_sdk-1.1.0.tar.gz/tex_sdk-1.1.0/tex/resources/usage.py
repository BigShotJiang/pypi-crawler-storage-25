"""Usage resource — read the caller's own metering totals.

These hit the integration backend's ``/usage/*`` endpoints which scope
results to the authenticated org automatically. No org_id parameter needed
on the call site (it's in the JWT).

Example
-------
    tex = Tex(api_key=...)
    today = tex.usage.today()
    print(today.tokens_in_used, "/", today.tokens_in_limit)

    month = tex.usage.summary()       # current calendar month
    march = tex.usage.summary("2026-03")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from ..client import Tex


@dataclass(frozen=True)
class UsageQuotaStatus:
    """Daily usage and quota for the caller's org."""

    tokens_in_used: int
    tokens_out_used: int
    tokens_in_limit: int
    tokens_out_limit: int
    period: str
    period_start: str
    period_end: str
    raw: Dict[str, Any]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "UsageQuotaStatus":
        return cls(
            tokens_in_used=int(d.get("tokens_in_used") or 0),
            tokens_out_used=int(d.get("tokens_out_used") or 0),
            tokens_in_limit=int(d.get("tokens_in_limit") or 0),
            tokens_out_limit=int(d.get("tokens_out_limit") or 0),
            period=str(d.get("period") or ""),
            period_start=str(d.get("period_start") or ""),
            period_end=str(d.get("period_end") or ""),
            raw=d,
        )


@dataclass(frozen=True)
class UsageWindow:
    """A rollup window — used for monthly summaries."""

    period: str
    start: str
    end: str
    tokens_in: int
    tokens_out: int
    raw: Dict[str, Any]

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "UsageWindow":
        return cls(
            period=str(d.get("period") or ""),
            start=str(d.get("start") or ""),
            end=str(d.get("end") or ""),
            tokens_in=int(d.get("tokens_in") or 0),
            tokens_out=int(d.get("tokens_out") or 0),
            raw=d,
        )


class UsageResource:
    def __init__(self, client: "Tex") -> None:
        self._client = client

    def today(self) -> UsageQuotaStatus:
        """Today's tokens_in / tokens_out plus the active daily quota."""
        ep = self._client._config.endpoints
        raw = self._client._request("GET", ep.usage_today)
        return UsageQuotaStatus.from_dict(raw)

    def summary(self, month: Optional[str] = None) -> UsageWindow:
        """Calendar-month rollup (UTC). ``month`` is ``YYYY-MM`` or omitted
        for the current month."""
        ep = self._client._config.endpoints
        params = {"month": month} if month else None
        raw = self._client._request("GET", ep.usage_summary, query_params=params)
        return UsageWindow.from_dict(raw)
