from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..models import SearchDocumentsResponse, SearchMemoriesResponse

if TYPE_CHECKING:
    from ..client import Tex


class SearchResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def documents(
        self,
        q: str,
        *,
        container_tags: Optional[List[str]] = None,
        limit: Optional[int] = None,
        chunk_threshold: Optional[float] = None,
        include_full_docs: Optional[bool] = None,
        include_summary: Optional[bool] = None,
        rerank: Optional[bool] = None,
        rewrite_query: Optional[bool] = None,
        filters: Optional[Dict[str, Any]] = None,
        doc_id: Optional[str] = None,
        only_matching_chunks: Optional[bool] = None,
    ) -> SearchDocumentsResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {"q": q}
        if container_tags is not None:
            payload["containerTags"] = container_tags
        if limit is not None:
            payload["limit"] = limit
        if chunk_threshold is not None:
            payload["chunkThreshold"] = chunk_threshold
        if include_full_docs is not None:
            payload["includeFullDocs"] = include_full_docs
        if include_summary is not None:
            payload["includeSummary"] = include_summary
        if rerank is not None:
            payload["rerank"] = rerank
        if rewrite_query is not None:
            payload["rewriteQuery"] = rewrite_query
        if filters is not None:
            payload["filters"] = filters
        if doc_id is not None:
            payload["docId"] = doc_id
        if only_matching_chunks is not None:
            payload["onlyMatchingChunks"] = only_matching_chunks
        raw = self._client._request("POST", ep.search_documents, json_body=payload)
        return SearchDocumentsResponse.from_dict(raw)

    def execute(self, q: str, **kwargs: Any) -> SearchDocumentsResponse:
        return self.documents(q, **kwargs)

    def memories(
        self,
        q: str,
        *,
        container_tag: Optional[str] = None,
        limit: Optional[int] = None,
        threshold: Optional[float] = None,
        rerank: Optional[bool] = None,
        rewrite_query: Optional[bool] = None,
        filters: Optional[Dict[str, Any]] = None,
        search_mode: Optional[str] = None,
    ) -> SearchMemoriesResponse:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {"q": q}
        if container_tag is not None:
            payload["containerTag"] = container_tag
        if limit is not None:
            payload["limit"] = limit
        if threshold is not None:
            payload["threshold"] = threshold
        if rerank is not None:
            payload["rerank"] = rerank
        if rewrite_query is not None:
            payload["rewriteQuery"] = rewrite_query
        if filters is not None:
            payload["filters"] = filters
        if search_mode is not None:
            payload["searchMode"] = search_mode
        raw = self._client._request("POST", ep.search_memories, json_body=payload)
        return SearchMemoriesResponse.from_dict(raw)
