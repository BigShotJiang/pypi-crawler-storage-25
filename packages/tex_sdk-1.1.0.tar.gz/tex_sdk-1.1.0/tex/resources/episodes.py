from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

if TYPE_CHECKING:
    from ..client import Tex


class EpisodesResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def store(
        self,
        messages: Union[str, List[Dict[str, Any]]],
        *,
        episode_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        ep = self._client._config.endpoints
        coerced = self._coerce_messages(messages)
        payload: Dict[str, Any] = {
            "messages": coerced,
            "scope": self._client._scope_payload(),
        }
        if episode_id is not None:
            payload["episode_id"] = episode_id
        if metadata is not None:
            payload["metadata"] = metadata
        if options is not None:
            payload["options"] = options
        return self._client._request("POST", ep.ingestion_episode, json_body=payload)

    def list(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        since: Optional[str] = None,
    ) -> Dict[str, Any]:
        ep = self._client._config.endpoints
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if since is not None:
            params["since"] = since
        return self._client._request("GET", ep.episodes_list, query_params=params)

    def _coerce_messages(self, content: Union[str, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
        if isinstance(content, str):
            return [{"role": "user", "content": content}]
        if isinstance(content, list) and content and all(isinstance(m, dict) for m in content):
            return content
        raise ValueError("messages must be a string or list of {role, content} dicts")
