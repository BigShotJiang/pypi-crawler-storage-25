from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict

if TYPE_CHECKING:
    from ..client import Tex


class AuthResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def whoami(self) -> Dict[str, Any]:
        self._client._ensure_auth()
        self._client._ensure_tenant()
        return dict(self._client._tenant or {})
