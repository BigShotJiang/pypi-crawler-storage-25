from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict

if TYPE_CHECKING:
    from ..client import Tex


class JobsResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def get(self, job_id: str) -> Dict[str, Any]:
        ep = self._client._config.endpoints
        path = ep.ingestion_status.format(job_id=job_id)
        return self._client._request("GET", path)
