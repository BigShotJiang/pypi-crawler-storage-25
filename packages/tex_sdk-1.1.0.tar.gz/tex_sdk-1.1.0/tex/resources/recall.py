from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Literal, Optional

from ..models import RecallResponse

if TYPE_CHECKING:
    from ..client import Tex


class RecallResource:
    """Callable resource for verb-shaped retrieval.

    Instances are themselves callable, so `tex.recall(...)` issues a
    single POST to /recall on the backend.
    """

    def __init__(self, client: "Tex") -> None:
        self._client = client

    def __call__(
        self,
        q: str,
        *,
        session_id: str,
        mode: Literal["active", "deep"] = "active",
        top_k: Optional[int] = None,
        include_timeline: bool = False,
    ) -> RecallResponse:
        cfg = self._client._config
        ep = cfg.endpoints
        payload: Dict[str, Any] = {
            "scope": {
                "org_id": cfg.org_id,
                "user_id": cfg.user_id,
                "session_id": session_id,
            },
            "q": q,
            "mode": mode,
            "include_timeline": include_timeline,
        }
        if top_k is not None:
            payload["top_k"] = top_k
        raw = self._client._request("POST", ep.recall, json_body=payload)
        return RecallResponse.from_dict(raw)
