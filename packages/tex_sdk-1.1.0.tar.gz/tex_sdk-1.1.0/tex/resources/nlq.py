from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..models import AskResult

if TYPE_CHECKING:
    from ..client import Tex


class NLQResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def execute(
        self,
        question: str,
        *,
        execute: bool = True,
        enable_pruning: bool = True,
        use_local_intelligence: bool = True,
        intent_match_options: Optional[Dict[str, Any]] = None,
        compact: bool = True,
    ) -> AskResult:
        ep = self._client._config.endpoints
        payload: Dict[str, Any] = {
            "query": question,
            "execute": execute,
            "enable_pruning": enable_pruning,
            "use_local_intelligence": use_local_intelligence,
            "compact": compact,
        }
        if intent_match_options is not None:
            payload["intent_match_options"] = intent_match_options
        raw = self._client._request("POST", ep.nlq_execute, json_body=payload)
        return self._simplify_nlq(raw)

    def _simplify_nlq(self, raw: Dict[str, Any]) -> AskResult:
        evidence: List[str] = []
        entities: List[str] = []
        documents: List[str] = []
        intent_matches = (raw.get("intent_matches") or {}) if isinstance(raw, dict) else {}
        matches = intent_matches.get("matches") if isinstance(intent_matches, dict) else None
        if isinstance(matches, list):
            for match in matches:
                if not isinstance(match, dict):
                    continue
                for ev in match.get("evidence", []) or []:
                    if isinstance(ev, dict):
                        txt = ev.get("text")
                        if isinstance(txt, str) and txt.strip():
                            evidence.append(txt.strip())
                bindings = match.get("bindings")
                if isinstance(bindings, dict):
                    for b in bindings.values():
                        if isinstance(b, dict):
                            name = b.get("entity_name") or b.get("canonical_id")
                            if isinstance(name, str) and name.strip():
                                entities.append(name.strip())
                for d in match.get("documents", []) or []:
                    if isinstance(d, dict):
                        name = d.get("entity_name") or d.get("canonical_id")
                        if isinstance(name, str) and name.strip():
                            documents.append(name.strip())
        evidence = list(dict.fromkeys(evidence))
        entities = list(dict.fromkeys(entities))
        documents = list(dict.fromkeys(documents))
        lines: List[str] = []
        if evidence:
            lines.append("Evidence:\n" + "\n".join(f"- {e}" for e in evidence[:50]))
        if entities:
            lines.append("Entities:\n" + "\n".join(f"- {e}" for e in entities[:50]))
        if documents:
            lines.append("Documents:\n" + "\n".join(f"- {d}" for d in documents[:50]))
        text = "\n\n".join(lines).strip() or "No evidence returned."
        return AskResult(text=text, evidence=evidence, entities=entities, documents=documents, raw=raw)
