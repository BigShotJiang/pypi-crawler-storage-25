from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from ..client import Tex


class PreferencesResource:
    def __init__(self, client: Tex) -> None:
        self._client = client

    def store(
        self,
        preferences: List[Any],
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        ep = self._client._config.endpoints
        scope = self._client._scope_payload()
        payload: Dict[str, Any] = {
            "org_id": scope.get("org_id") or "_",
            "user_id": scope.get("user_id") or "_",
            "session_id": self._client._config.session_id,
            "preferences": preferences,
        }
        if metadata is not None:
            payload["metadata"] = metadata
        return self._client._request("POST", ep.ingestion_preference, json_body=payload)
