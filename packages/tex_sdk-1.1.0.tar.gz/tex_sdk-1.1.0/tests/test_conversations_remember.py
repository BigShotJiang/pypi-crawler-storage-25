import httpx
import respx

from tex import Tex


def _mock_auth(mock):
    mock.post("/auth/token-exchange").mock(
        return_value=httpx.Response(200, json={"access_token": "a", "refresh_token": "r"})
    )
    mock.post("/auth/login").mock(
        return_value=httpx.Response(200, json={"access_token": "a", "refresh_token": "r"})
    )
    mock.get("/auth/verify").mock(
        return_value=httpx.Response(200, json={"org_id": "o", "user_id": "u"})
    )


def test_remember_posts_turns_to_ingestion_memory():
    with respx.mock(base_url="http://x") as mock:
        _mock_auth(mock)
        route = mock.post("/ingestion/memory").mock(
            return_value=httpx.Response(202, json={
                "active_fragment_ids": ["f1", "f2"],
                "passive_job_id": None,
                "job_id": "abc",
            })
        )
        c = Tex(api_key="k", base_url="http://x", org_id="o", user_id="u")
        out = c.conversations.remember(
            turns=[{"text": "hi", "role": "user", "timestamp": "2026-05-01T10:00:00Z"}],
            session_id="s",
            metadata={"src": "test"},
        )
        assert out.active_fragment_ids == ["f1", "f2"]
        assert out.passive_job_id is None
        assert out.job_id == "abc"
        body = route.calls.last.request.read()
        # Body has the right top-level shape
        assert b'"session_id":"s"' in body or b'"session_id": "s"' in body
        assert b'"turns"' in body
        assert b'"metadata"' in body


def test_remember_omits_metadata_when_not_passed():
    with respx.mock(base_url="http://x") as mock:
        _mock_auth(mock)
        route = mock.post("/ingestion/memory").mock(
            return_value=httpx.Response(202, json={
                "active_fragment_ids": [], "passive_job_id": None, "job_id": "x",
            })
        )
        c = Tex(api_key="k", base_url="http://x", org_id="o", user_id="u")
        c.conversations.remember(
            turns=[{"text": "hi", "role": "user", "timestamp": "2026-05-01T10:00:00Z"}],
            session_id="s",
        )
        body = route.calls.last.request.read()
        assert b'"metadata"' not in body
