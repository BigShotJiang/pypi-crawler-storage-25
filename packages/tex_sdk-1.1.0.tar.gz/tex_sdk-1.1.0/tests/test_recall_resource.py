import httpx
import respx

from tex import Tex


def _mock_auth(mock):
    mock.post("/auth/token-exchange").mock(
        return_value=httpx.Response(200, json={"access_token": "tok", "refresh_token": "r"})
    )
    mock.post("/auth/login").mock(
        return_value=httpx.Response(200, json={"access_token": "tok", "refresh_token": "r"})
    )
    mock.get("/auth/verify").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )


def test_recall_active_mode_posts_and_parses_response():
    with respx.mock(base_url="http://x", assert_all_called=False) as mock:
        _mock_auth(mock)
        route = mock.post("/recall").mock(
            return_value=httpx.Response(200, json={
                "hits": {
                    "observations": [],
                    "turns": [{"id": "t1", "text": "hello", "score": 0.9, "kind": "turn"}],
                    "entities": [],
                },
                "timeline": None,
                "confidence": 0.7,
                "mode": "active",
            })
        )
        c = Tex(api_key="k", base_url="http://x", org_id="o", user_id="u")
        out = c.recall(q="hi", session_id="s", mode="active")
        assert out.mode == "active"
        assert out.confidence == 0.7
        assert len(out.hits.turns) == 1
        assert out.hits.turns[0].text == "hello"
        body = route.calls.last.request.read()
        assert b'"q":"hi"' in body or b'"q": "hi"' in body
        assert b'"mode":"active"' in body or b'"mode": "active"' in body


def test_recall_omits_top_k_when_not_passed():
    with respx.mock(base_url="http://x", assert_all_called=False) as mock:
        _mock_auth(mock)
        route = mock.post("/recall").mock(
            return_value=httpx.Response(200, json={
                "hits": {"observations": [], "turns": [], "entities": []},
                "timeline": None, "confidence": 0.0, "mode": "active",
            })
        )
        c = Tex(api_key="k", base_url="http://x", org_id="o", user_id="u")
        c.recall(q="hi", session_id="s")
        body = route.calls.last.request.read()
        assert b'"top_k"' not in body


def test_recall_deep_mode_with_timeline_passes_flags():
    with respx.mock(base_url="http://x", assert_all_called=False) as mock:
        _mock_auth(mock)
        route = mock.post("/recall").mock(
            return_value=httpx.Response(200, json={
                "hits": {"observations": [], "turns": [], "entities": []},
                "timeline": "Timeline of relevant events:\n- 8 May 2023: x",
                "confidence": 0.5, "mode": "deep",
            })
        )
        c = Tex(api_key="k", base_url="http://x", org_id="o", user_id="u")
        out = c.recall(q="hi", session_id="s", mode="deep", top_k=20, include_timeline=True)
        assert out.mode == "deep"
        assert out.timeline.startswith("Timeline")
        body = route.calls.last.request.read()
        assert b'"mode":"deep"' in body or b'"mode": "deep"' in body
        assert b'"top_k":20' in body or b'"top_k": 20' in body
        assert b'"include_timeline":true' in body or b'"include_timeline": true' in body
