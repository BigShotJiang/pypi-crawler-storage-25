"""OpenAI-compatible client wrapper supporting multiple providers."""

from __future__ import annotations

import json
import logging
from collections.abc import Generator
from typing import Any, Dict, List, Type

from openai import LengthFinishReasonError, OpenAI
from openai.types.chat import ChatCompletion
from pydantic import BaseModel

from .config import ModelConfig

logger = logging.getLogger(__name__)


class OpenAIClientWrapper:
    """Thin wrapper around the OpenAI SDK with pluggable base URLs."""

    def __init__(self, config: ModelConfig) -> None:
        self.config = config
        self.client = OpenAI(
            base_url=config.base_url,
            api_key=config.api_key,
            default_headers=config.default_headers,
        )

    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] | None = None,
        timeout: float | None = None,
        temperature: float | None = None,
        response_format: Type[BaseModel] | None = None,
        extra_params: Dict[str, Any] | None = None,
    ) -> ChatCompletion:
        base_params: Dict[str, Any] = {
            "messages": messages,
            "temperature": temperature if temperature is not None else self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }
        base_params.update(self.config.default_chat_params)

        if tools:
            base_params["tools"] = tools

        if timeout:
            base_params["timeout"] = timeout

        if extra_params:
            base_params.update(extra_params)

        models_to_try = [self.config.model]
        if self.config.provider.lower() == "openrouter":
            models_to_try.extend(self.config.fallback_models)

        last_error: Exception | None = None
        for index, model_name in enumerate(models_to_try):
            params = {"model": model_name, **base_params}

            try:
                if response_format is not None:
                    try:
                        return self.client.beta.chat.completions.parse(
                            **params,
                            response_format=response_format,
                        )
                    except LengthFinishReasonError as exc:
                        return exc.completion

                return self.client.chat.completions.create(**params)
            except Exception as exc:  # pragma: no cover - exercised via tests
                last_error = exc
                if index >= len(models_to_try) - 1:
                    raise
                logger.warning(
                    "OpenRouter request failed for model '%s', trying fallback model '%s': %s",
                    model_name,
                    models_to_try[index + 1],
                    exc,
                )

        if last_error is not None:
            raise last_error
        raise RuntimeError("No model candidates available for chat completion")

    def stream_chat_completion(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] | None = None,
        timeout: float | None = None,
        temperature: float | None = None,
    ) -> Generator[tuple[str, None] | tuple[None, list[dict[str, Any]]], None, None]:
        """Stream a chat completion.

        Yields ``(text_delta, None)`` for each incremental text token and then
        a single ``(None, tool_calls)`` tuple at the end where *tool_calls* is
        the fully assembled list of tool-call dicts (may be empty).
        """
        base_params: Dict[str, Any] = {
            "messages": messages,
            "temperature": temperature if temperature is not None else self.config.temperature,
            "max_tokens": self.config.max_tokens,
            "stream": True,
        }
        base_params.update(self.config.default_chat_params)

        if tools:
            base_params["tools"] = tools

        if timeout:
            base_params["timeout"] = timeout

        models_to_try = [self.config.model]
        if self.config.provider.lower() == "openrouter":
            models_to_try.extend(self.config.fallback_models)

        stream = None
        last_error: Exception | None = None
        for index, model_name in enumerate(models_to_try):
            try:
                stream = self.client.chat.completions.create(model=model_name, **base_params)
                break
            except Exception as exc:  # pragma: no cover
                last_error = exc
                if index >= len(models_to_try) - 1:
                    raise
                logger.warning(
                    "OpenRouter stream request failed for model '%s', trying fallback '%s': %s",
                    model_name,
                    models_to_try[index + 1],
                    exc,
                )

        if stream is None:
            if last_error is not None:
                raise last_error
            raise RuntimeError("No model candidates available for streaming chat completion")

        tool_calls_raw: dict[int, dict[str, str]] = {}

        for chunk in stream:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            if delta.content:
                yield delta.content, None
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index
                    if idx not in tool_calls_raw:
                        tool_calls_raw[idx] = {"id": "", "name": "", "arguments": ""}
                    if tc.id:
                        tool_calls_raw[idx]["id"] = tc.id
                    if tc.function:
                        if tc.function.name:
                            tool_calls_raw[idx]["name"] += tc.function.name
                        if tc.function.arguments:
                            tool_calls_raw[idx]["arguments"] += tc.function.arguments

        assembled: list[dict[str, Any]] = []
        for idx in sorted(tool_calls_raw.keys()):
            raw = tool_calls_raw[idx]
            args: Any = raw["arguments"]
            if not isinstance(args, dict):
                try:
                    args = json.loads(args or "{}")
                except json.JSONDecodeError:
                    args = {}
            assembled.append({"id": raw["id"], "name": raw["name"], "args": args})

        yield None, assembled
