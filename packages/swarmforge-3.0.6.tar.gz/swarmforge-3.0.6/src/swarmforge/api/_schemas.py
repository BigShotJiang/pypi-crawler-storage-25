"""Pydantic request models and OpenAPI examples for the FastAPI transport."""

from __future__ import annotations

from typing import Any, Dict, List, Union

from pydantic import AliasChoices, BaseModel, Field

from ..authoring import build_swarm_definition

# A multimodal content item as accepted by OpenAI-compatible endpoints.
# Supports text (``{"type": "text", "text": "..."}``), image URLs
# (``{"type": "image_url", "image_url": {"url": "...", "detail": "auto"}}``),
# and audio (``{"type": "input_audio", "input_audio": {"data": "<base64>", "format": "wav"}}``).
UserInputContent = Union[str, List[Dict[str, Any]]]

RUN_SWARM_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Run a swarm turn with server-configured provider defaults",
        "value": {
            "swarm": {
                "id": "support",
                "name": "Support Swarm",
                "nodes": [
                    {
                        "node_key": "assistant",
                        "name": "Assistant",
                        "system_prompt": "You are a helpful assistant.",
                        "is_entry_node": True,
                    }
                ],
                "edges": [],
                "variables": [],
            },
            "user_input": "Give me a concise answer.",
            "state": {"account_id": "ACME-991"},
        },
    }
}

SEND_MESSAGE_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Send a session message with server-configured provider defaults",
        "value": {
            "user_input": "Help me with this request.",
            "state": {"account_id": "ACME-991", "priority": "high"},
        },
    }
}

CREATE_SESSION_OPENAPI_EXAMPLE = {
    "summary": "Create a swarm session",
    "value": {
        "session_id": "session-1",
        "swarm": {
            "id": "single-agent",
            "name": "Single Agent",
            "nodes": [
                {
                    "node_key": "assistant",
                    "name": "Assistant",
                    "system_prompt": "You are a helpful assistant.",
                    "is_entry_node": True,
                }
            ],
            "edges": [],
            "variables": [],
        },
        "state": {"account_id": "ACME-991"},
    },
}


class SwarmVariablePayload(BaseModel):
    key_name: str
    description: str = ""
    reducer_rule: str = "overwrite"


class SwarmEdgePayload(BaseModel):
    source_node_key: str
    target_node_key: str
    handoff_description: str
    required_variables: List[str] = Field(default_factory=list)


class SwarmNodeSubAgentPayload(BaseModel):
    sub_agent: str
    handoff_description: str
    required_variables: List[str] = Field(default_factory=list)


class SwarmNodePayload(BaseModel):
    node_key: str
    name: str
    system_prompt: str = ""
    intent: str = ""
    capabilities: List[str] = Field(default_factory=list)
    persona: str = ""
    model_choice: str = ""
    enabled_tools: List[Dict[str, Any]] = Field(default_factory=list)
    sub_agents: List[SwarmNodeSubAgentPayload] = Field(default_factory=list)
    behavior_config: Dict[str, Any] = Field(default_factory=dict)
    is_entry_node: bool = False


class SwarmDefinitionPayload(BaseModel):
    id: str = "swarm"
    name: str = "Swarm"
    graph_version: int = 1
    nodes: List[SwarmNodePayload]
    edges: List[SwarmEdgePayload] = Field(default_factory=list)
    variables: List[SwarmVariablePayload] = Field(default_factory=list)

    def to_runtime(self):
        return build_swarm_definition(
            {
                "nodes": [node.model_dump(mode="python") for node in self.nodes],
                "edges": [edge.model_dump(mode="python") for edge in self.edges],
                "variables": [variable.model_dump(mode="python") for variable in self.variables],
            },
            swarm_id=self.id,
            name=self.name,
            graph_version=self.graph_version,
        )


class VariableInjectionPayload(BaseModel):
    state: Dict[str, Any] = Field(
        default_factory=dict,
        validation_alias=AliasChoices("state", "variables", "global_variables"),
    )

    @property
    def variables(self) -> Dict[str, Any]:
        return self.state

    @property
    def global_variables(self) -> Dict[str, Any]:
        return self.state


class TurnVariableInjectionPayload(VariableInjectionPayload):
    pass


class CreateSessionRequest(VariableInjectionPayload):
    session_id: str | None = None
    swarm: SwarmDefinitionPayload


class SendMessageRequest(TurnVariableInjectionPayload):
    user_input: UserInputContent


class RunSwarmRequest(VariableInjectionPayload):
    session_id: str | None = None
    swarm: SwarmDefinitionPayload
    user_input: UserInputContent


class CreateConfiguredSessionRequest(VariableInjectionPayload):
    session_id: str | None = None


class SessionVariableUpdateRequest(BaseModel):
    state: Dict[str, Any] = Field(
        default_factory=dict,
        validation_alias=AliasChoices("state", "values", "variables", "global_variables"),
    )
    mode: str = Field(
        default="merge",
        validation_alias=AliasChoices("mode", "state_mode", "variable_mode", "global_variable_mode"),
    )

    @property
    def values(self) -> Dict[str, Any]:
        return self.state

    @property
    def variables(self) -> Dict[str, Any]:
        return self.state

    @property
    def global_variables(self) -> Dict[str, Any]:
        return self.state
