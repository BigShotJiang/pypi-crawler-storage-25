from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from augint_opencodex.ignore import ExcludeUpdate, ensure_git_exclude
from augint_opencodex.manifest import load_manifest
from augint_opencodex.profiles import ResolvedPolicy, resolve_policy
from augint_opencodex.renderer import managed_file_paths, render_project


@dataclass(frozen=True)
class SyncReport:
    """The result of resolving and optionally writing generated files."""

    mode: Literal["write", "dry-run", "check"]
    policy: ResolvedPolicy
    changed_files: tuple[Path, ...]
    stale_files: tuple[Path, ...]
    written_files: tuple[Path, ...]
    removed_files: tuple[Path, ...]
    unchanged_files: tuple[Path, ...]
    exclude_update: ExcludeUpdate

    @property
    def needs_changes(self) -> bool:
        return bool(self.changed_files or self.stale_files) or self.exclude_update.needs_update


def sync_project(
    project_root: Path,
    manifest_path: Path | None = None,
    *,
    mode: Literal["write", "dry-run", "check"] = "write",
) -> SyncReport:
    """Load the manifest, resolve policy, and render local project files."""

    resolved_root = project_root.resolve()
    resolved_manifest_path = _resolve_manifest_path(resolved_root, manifest_path)
    manifest = load_manifest(resolved_manifest_path)
    policy = resolve_policy(manifest, resolved_root, resolved_manifest_path)
    rendered_files = render_project(policy)

    changed_files: list[Path] = []
    stale_files: list[Path] = []
    written_files: list[Path] = []
    removed_files: list[Path] = []
    unchanged_files: list[Path] = []

    for rendered_file in rendered_files:
        target_path = resolved_root / rendered_file.path
        if target_path.exists():
            current_content = target_path.read_text(encoding="utf-8")
        else:
            current_content = None

        if current_content == rendered_file.content:
            unchanged_files.append(rendered_file.path)
            continue

        changed_files.append(rendered_file.path)
        if mode == "write":
            target_path.parent.mkdir(parents=True, exist_ok=True)
            target_path.write_text(rendered_file.content, encoding="utf-8")
            written_files.append(rendered_file.path)

    expected_paths = {rendered_file.path for rendered_file in rendered_files}
    for managed_path in managed_file_paths():
        if managed_path in expected_paths:
            continue

        target_path = resolved_root / managed_path
        if not target_path.exists():
            continue

        stale_files.append(managed_path)
        if mode == "write":
            target_path.unlink()
            _prune_empty_parent_dirs(target_path.parent, stop_at=resolved_root)
            removed_files.append(managed_path)

    exclude_update = ensure_git_exclude(resolved_root, write=mode == "write")
    return SyncReport(
        mode=mode,
        policy=policy,
        changed_files=tuple(changed_files),
        stale_files=tuple(stale_files),
        written_files=tuple(written_files),
        removed_files=tuple(removed_files),
        unchanged_files=tuple(unchanged_files),
        exclude_update=exclude_update,
    )


def _resolve_manifest_path(project_root: Path, manifest_path: Path | None) -> Path:
    if manifest_path is not None:
        return manifest_path.resolve()
    return (project_root / ".ai-codex.json").resolve()


def _prune_empty_parent_dirs(path: Path, *, stop_at: Path) -> None:
    current = path
    resolved_stop = stop_at.resolve()
    while current != resolved_stop and current.exists():
        try:
            current.rmdir()
        except OSError:
            break
        current = current.parent
