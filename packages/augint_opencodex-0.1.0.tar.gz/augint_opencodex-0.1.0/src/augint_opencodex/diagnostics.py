from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from augint_opencodex.ignore import ExcludeUpdate, ensure_git_exclude
from augint_opencodex.manifest import load_manifest
from augint_opencodex.profiles import ResolvedPolicy, resolve_policy
from augint_opencodex.renderer import managed_file_paths, render_project


@dataclass(frozen=True)
class DoctorReport:
    """Diagnostics for a target repository."""

    policy: ResolvedPolicy
    expected_files: tuple[Path, ...]
    missing_files: tuple[Path, ...]
    stale_files: tuple[Path, ...]
    exclude_update: ExcludeUpdate
    staged_generated_files: tuple[Path, ...]
    root_agents_present: bool


def inspect_project(project_root: Path, manifest_path: Path | None = None) -> DoctorReport:
    """Inspect the current project and report sync-related state."""

    resolved_root = project_root.resolve()
    resolved_manifest_path = _resolve_manifest_path(resolved_root, manifest_path)
    manifest = load_manifest(resolved_manifest_path)
    policy = resolve_policy(manifest, resolved_root, resolved_manifest_path)
    rendered_files = render_project(policy)
    expected_files = tuple(rendered_file.path for rendered_file in rendered_files)
    missing_files = tuple(
        rendered_file.path
        for rendered_file in rendered_files
        if not (resolved_root / rendered_file.path).exists()
    )
    stale_files = tuple(
        managed_path
        for managed_path in managed_file_paths()
        if managed_path not in expected_files and (resolved_root / managed_path).exists()
    )
    exclude_update = ensure_git_exclude(resolved_root, write=False)
    staged_generated_files = _find_staged_generated_files(resolved_root, managed_file_paths())
    root_agents_present = (resolved_root / "AGENTS.md").exists()

    return DoctorReport(
        policy=policy,
        expected_files=expected_files,
        missing_files=missing_files,
        stale_files=stale_files,
        exclude_update=exclude_update,
        staged_generated_files=staged_generated_files,
        root_agents_present=root_agents_present,
    )


def _resolve_manifest_path(project_root: Path, manifest_path: Path | None) -> Path:
    if manifest_path is not None:
        return manifest_path.resolve()
    return (project_root / ".ai-codex.json").resolve()


def _find_staged_generated_files(
    project_root: Path, expected_files: tuple[Path, ...]
) -> tuple[Path, ...]:
    if not (project_root / ".git").exists():
        return ()

    command = [
        "git",
        "-C",
        str(project_root),
        "diff",
        "--cached",
        "--name-only",
        "--",
        *(path.as_posix() for path in expected_files),
    ]
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode not in (0, 1):
        return ()

    staged_files = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    return tuple(Path(staged_file) for staged_file in staged_files)
