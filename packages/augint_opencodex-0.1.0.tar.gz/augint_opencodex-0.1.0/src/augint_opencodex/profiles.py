from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from augint_opencodex.manifest import Manifest


@dataclass(frozen=True)
class ProfileDefinition:
    """Resolved defaults for a named profile before manifest overrides."""

    name: str
    summary: str
    instruction_bullets: tuple[str, ...]
    blocked_paths: tuple[str, ...]
    ask_patterns: tuple[str, ...]
    deny_patterns: tuple[str, ...]
    approval_policy: str = "on-request"
    sandbox_mode: str = "workspace-write"
    web_search: str = "live"


@dataclass(frozen=True)
class ResolvedPolicy:
    """Effective policy after layering baseline, profile, and manifest settings."""

    project_root: Path
    manifest_path: Path
    profile_name: str
    profile_summary: str
    references: tuple[str, ...]
    blocked_paths: tuple[str, ...]
    ask_patterns: tuple[str, ...]
    deny_patterns: tuple[str, ...]
    no_emojis: bool
    no_ai_mentions: bool
    org_python_library: bool
    opencode_enabled: bool
    codex_approval_policy: str
    codex_sandbox_mode: str
    codex_web_search: str
    instruction_bullets: tuple[str, ...]


BASELINE_INSTRUCTION_BULLETS = (
    "Use `.ai-codex.json` as the tracked source of truth for local agent configuration.",
    "Use `.ai-opencodex.md` as the generated repo instruction file.",
    "Avoid a root `AGENTS.md` in the repository root because it shadows fallback instruction filenames for Codex discovery.",
    "Treat `.codex/config.toml`, `opencode.json`, and `.agents/skills/` as generated local artifacts.",
    "Re-run `ai-codex sync` after manifest changes instead of editing generated files by hand.",
)


PROFILE_DEFINITIONS: dict[str, ProfileDefinition] = {
    "augint": ProfileDefinition(
        name="augint",
        summary="Standard Augmenting Integrations work profile with live web access and local agent guidance.",
        instruction_bullets=(
            "Prefer practical, minimal changes that preserve the existing repository's patterns.",
            "Treat shell guardrails as real approval prompts for risky operational commands.",
        ),
        blocked_paths=(
            "**/secrets/**",
            "**/*.pem",
            "**/terraform.tfstate*",
        ),
        ask_patterns=(
            "aws *",
            "terraform *",
            "kubectl *",
            "git push *",
        ),
        deny_patterns=(),
    ),
    "gov": ProfileDefinition(
        name="gov",
        summary="Stricter overlay for compliance-sensitive repositories with broader defaults and more conservative command handling.",
        instruction_bullets=(
            "Use the same working model as `augint`, but be more conservative with compliance-sensitive changes.",
            "Escalate or slow down when commands or outputs could affect regulated systems or sensitive data.",
        ),
        blocked_paths=(
            "**/secrets/**",
            "**/*.pem",
            "**/*.key",
            "**/*.p12",
            "**/terraform.tfstate*",
            "**/.aws/**",
        ),
        ask_patterns=(
            "aws *",
            "terraform *",
            "kubectl *",
            "git push *",
            "az *",
            "gcloud *",
            "gh secret *",
        ),
        deny_patterns=(
            "aws iam create*",
            "aws iam put*",
            "terraform destroy *",
        ),
    ),
}


def resolve_policy(manifest: Manifest, project_root: Path, manifest_path: Path) -> ResolvedPolicy:
    """Merge baseline policy, profile defaults, and manifest settings."""

    profile = PROFILE_DEFINITIONS[manifest.profile]
    return ResolvedPolicy(
        project_root=project_root.resolve(),
        manifest_path=manifest_path.resolve(),
        profile_name=profile.name,
        profile_summary=profile.summary,
        references=_dedupe(manifest.references),
        blocked_paths=_dedupe(profile.blocked_paths + tuple(manifest.blocked_paths)),
        ask_patterns=_dedupe(profile.ask_patterns + tuple(manifest.shell_guardrails.ask)),
        deny_patterns=_dedupe(profile.deny_patterns + tuple(manifest.shell_guardrails.deny)),
        no_emojis=manifest.content_policy.no_emojis,
        no_ai_mentions=manifest.content_policy.no_ai_mentions,
        org_python_library=manifest.patterns.org_python_library,
        opencode_enabled=manifest.opencode.enabled,
        codex_approval_policy=profile.approval_policy,
        codex_sandbox_mode=profile.sandbox_mode,
        codex_web_search=profile.web_search,
        instruction_bullets=BASELINE_INSTRUCTION_BULLETS + profile.instruction_bullets,
    )


def _dedupe(values: tuple[str, ...] | list[str]) -> tuple[str, ...]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value not in seen:
            ordered.append(value)
            seen.add(value)
    return tuple(ordered)
