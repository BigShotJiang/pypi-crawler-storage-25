from __future__ import annotations

import sys

import click

from augint_opencodex import __version__
from augint_opencodex.cli.commands import doctor, sync


@click.group()
@click.version_option(version=__version__, prog_name="ai-codex")
def cli() -> None:
    """Render local Codex and OpenCode repo config from `.ai-codex.json`."""


cli.add_command(sync.sync_command)
cli.add_command(doctor.doctor_command)


def main() -> None:
    """Run the `ai-codex` CLI."""

    try:
        cli()
    except click.ClickException as exc:
        exc.show()
        sys.exit(exc.exit_code)
    except Exception as exc:  # pragma: no cover - defensive CLI boundary
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
