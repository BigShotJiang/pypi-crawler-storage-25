from __future__ import annotations

from pathlib import Path

import click

from augint_opencodex.diagnostics import inspect_project


@click.command(name="doctor")
@click.option(
    "--project-root",
    type=click.Path(file_okay=False, path_type=Path),
    default=Path("."),
    show_default=True,
    help="Repository root to inspect.",
)
@click.option(
    "--manifest",
    type=click.Path(dir_okay=False, path_type=Path),
    help="Explicit manifest path. Defaults to PROJECT_ROOT/.ai-codex.json.",
)
def doctor_command(project_root: Path, manifest: Path | None) -> None:
    """Inspect manifest resolution and generated file state."""

    report = inspect_project(project_root, manifest_path=manifest)
    click.echo(f"Project root: {report.policy.project_root}")
    click.echo(f"Manifest: {report.policy.manifest_path}")
    click.echo(f"Profile: {report.policy.profile_name}")

    for expected_file in report.expected_files:
        status = "ok" if expected_file not in report.missing_files else "missing"
        click.echo(f"{status}: {expected_file.as_posix()}")

    for stale_file in report.stale_files:
        click.echo(f"stale: {stale_file.as_posix()}")

    if not report.exclude_update.available:
        click.echo("git exclude: unavailable")
    elif report.exclude_update.needs_update:
        click.echo("git exclude: missing ai-codex block")
    else:
        click.echo("git exclude: ok")

    if report.root_agents_present:
        click.echo(
            "warning: root AGENTS.md is present and will shadow .ai-opencodex.md for Codex discovery"
        )

    if report.staged_generated_files:
        for staged_file in report.staged_generated_files:
            click.echo(f"warning: staged generated file {staged_file.as_posix()}")
    else:
        click.echo("staged generated files: none")

    if report.missing_files or report.stale_files:
        click.echo("Run `ai-codex sync` to reconcile missing or stale generated files.")
