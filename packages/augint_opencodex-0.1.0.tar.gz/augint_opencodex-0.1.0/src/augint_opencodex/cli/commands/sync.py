from __future__ import annotations

from pathlib import Path
from typing import Literal

import click

from augint_opencodex.sync_engine import SyncReport, sync_project


@click.command(name="sync")
@click.option(
    "--project-root",
    type=click.Path(file_okay=False, path_type=Path),
    default=Path("."),
    show_default=True,
    help="Repository root to sync.",
)
@click.option(
    "--manifest",
    type=click.Path(dir_okay=False, path_type=Path),
    help="Explicit manifest path. Defaults to PROJECT_ROOT/.ai-codex.json.",
)
@click.option("--dry-run", is_flag=True, help="Preview changes without writing files.")
@click.option("--check", is_flag=True, help="Exit non-zero when generated files are out of sync.")
def sync_command(
    project_root: Path,
    manifest: Path | None,
    dry_run: bool,
    check: bool,
) -> None:
    """Render project-local Codex and OpenCode files."""

    if dry_run and check:
        raise click.ClickException("`--dry-run` and `--check` cannot be used together.")

    mode: Literal["write", "dry-run", "check"] = (
        "check" if check else "dry-run" if dry_run else "write"
    )
    report = sync_project(project_root, manifest_path=manifest, mode=mode)
    _print_report(report)

    if check and report.needs_changes:
        raise click.ClickException("Generated files are out of sync. Run `ai-codex sync`.")


def _print_report(report: SyncReport) -> None:
    root = report.policy.project_root
    click.echo(f"Project root: {root}")
    click.echo(f"Manifest: {report.policy.manifest_path}")
    click.echo(f"Profile: {report.policy.profile_name}")

    if report.changed_files:
        verb = {
            "write": "wrote",
            "dry-run": "would write",
            "check": "needs update",
        }[report.mode]
        for path in report.changed_files:
            click.echo(f"{verb}: {_display_path(path)}")
    else:
        click.echo("Generated files are already in sync.")

    if report.stale_files:
        verb = {
            "write": "removed",
            "dry-run": "would remove",
            "check": "needs removal",
        }[report.mode]
        for path in report.stale_files:
            click.echo(f"{verb}: {_display_path(path)}")

    if report.unchanged_files:
        click.echo(f"unchanged: {len(report.unchanged_files)} file(s)")

    exclude_update = report.exclude_update
    if not exclude_update.available:
        click.echo("git exclude: skipped (no .git/info directory found)")
    elif exclude_update.updated:
        click.echo(f"git exclude: updated {_display_path(exclude_update.path, root)}")
    elif exclude_update.needs_update:
        click.echo(f"git exclude: would update {_display_path(exclude_update.path, root)}")
    else:
        click.echo("git exclude: already current")


def _display_path(path: Path | None, base: Path | None = None) -> str:
    if path is None:
        return "<missing>"
    if base is None:
        return path.as_posix()
    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return path.as_posix()
