from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError


class ManifestError(ValueError):
    """Raised when `.ai-codex.json` cannot be loaded or validated."""


class ContentPolicy(BaseModel):
    """Output-style constraints applied by the generated profile."""

    model_config = ConfigDict(extra="forbid")

    no_emojis: bool = True
    no_ai_mentions: bool = True


class ShellGuardrails(BaseModel):
    """Shell command patterns that should prompt or be denied."""

    model_config = ConfigDict(extra="forbid")

    ask: list[str] = Field(default_factory=list)
    deny: list[str] = Field(default_factory=list)


class PatternFlags(BaseModel):
    """Named organizational patterns that can influence generated output."""

    model_config = ConfigDict(extra="forbid")

    org_python_library: bool = False


class OpenCodeConfig(BaseModel):
    """Compatibility settings for OpenCode generation."""

    model_config = ConfigDict(extra="forbid")

    enabled: bool = True


class Manifest(BaseModel):
    """Tracked repo manifest used to render local agent config."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    schema_uri: str | None = Field(default=None, alias="$schema")
    version: Literal[1]
    profile: Literal["augint", "gov"]
    references: list[str] = Field(default_factory=list)
    blocked_paths: list[str] = Field(default_factory=list)
    content_policy: ContentPolicy = Field(default_factory=ContentPolicy)
    shell_guardrails: ShellGuardrails = Field(default_factory=ShellGuardrails)
    patterns: PatternFlags = Field(default_factory=PatternFlags)
    opencode: OpenCodeConfig = Field(default_factory=OpenCodeConfig)


def load_manifest(path: Path) -> Manifest:
    """Load and validate a manifest file from disk."""

    resolved_path = path.resolve()
    if not resolved_path.exists():
        raise ManifestError(f"Manifest not found: {resolved_path}")

    try:
        payload = json.loads(resolved_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ManifestError(f"Manifest is not valid JSON: {resolved_path}") from exc
    except OSError as exc:
        raise ManifestError(f"Unable to read manifest: {resolved_path}") from exc

    try:
        return Manifest.model_validate(payload)
    except ValidationError as exc:
        raise ManifestError(f"Manifest validation failed for {resolved_path}: {exc}") from exc
