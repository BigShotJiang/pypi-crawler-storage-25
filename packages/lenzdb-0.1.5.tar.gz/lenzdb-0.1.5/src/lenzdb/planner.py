"""Lens diffing, mutation planning, and writeback."""

from __future__ import annotations

import csv
import hashlib
import json
import shlex
import shutil
import subprocess
import tempfile
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from lenzdb.analysis import (
    AnalyzedColumn,
    LensAnalysis,
    analyze_resource,
    infer_defaults_from_resource_where,
)
from lenzdb.engine import QueryResult, ResourceQuery, query_resource, query_resource_view
from lenzdb.errors import MutationError
from lenzdb.project import Project, canonical_scalar, parse_column_value, serialize_value


@dataclass(slots=True)
class DiffEntry:
    key: str
    change_type: str
    changes: list[tuple[str, str, str]]


@dataclass(slots=True)
class TableMutation:
    table: str
    key: str
    changes: dict[str, Any]


@dataclass(slots=True)
class TableInsert:
    table: str
    row: dict[str, Any]


@dataclass(slots=True)
class MutationPlan:
    lens_name: str
    primary_table: str
    primary_key_output: str
    primary_key_outputs: list[str]
    diff_entries: list[DiffEntry]
    updates: list[TableMutation]
    inserts: list[TableInsert]
    reference_creations: list[TableInsert]
    generated_primary_keys: list[str]
    inferred_defaults: dict[str, str]
    inferred_default_sources: dict[str, str]
    rows_by_table: dict[str, list[dict[str, Any]]] = field(repr=False)
    touched_tables: set[str] = field(repr=False)

    @property
    def has_changes(self) -> bool:
        return bool(self.updates or self.inserts or self.reference_creations)


@dataclass(slots=True)
class EditResult:
    plan: MutationPlan
    recovery_path: Path
    recovered_from: Path | None = None


def query_fingerprint(query: ResourceQuery) -> str:
    payload = {
        "columns": query.columns,
        "distinct": query.distinct,
        "where": query.where,
        "order": query.order,
        "limit": query.limit,
        "offset": query.offset,
        "count": query.count,
        "sql": query.sql,
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha1(encoded).hexdigest()[:12]


def snapshot_rows(columns: list[str], rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    return [{column: canonical_scalar(row.get(column)) for column in columns} for row in rows]


def read_snapshot_csv(path: Path, expected_columns: list[str]) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        if set(headers) != set(expected_columns):
            raise MutationError(
                f"Edited CSV columns must match the lens output exactly. "
                f"expected={expected_columns}, got={headers}"
            )
        return [{column: row.get(column, "") for column in expected_columns} for row in reader]


def diff_snapshots(
    current_rows: list[dict[str, str]],
    edited_rows: list[dict[str, str]],
    key_columns: list[str],
    columns: list[str],
) -> list[DiffEntry]:
    if key_columns:
        current_by_key = {snapshot_key_tuple(row, key_columns): row for row in current_rows}
        edited_by_key = {snapshot_key_tuple(row, key_columns): row for row in edited_rows}
        keys = list(dict.fromkeys([*current_by_key, *edited_by_key]))
        entries: list[DiffEntry] = []
        for key in keys:
            current = current_by_key.get(key)
            edited = edited_by_key.get(key)
            if current is None and edited is not None:
                changes = [(column, "", edited.get(column, "")) for column in columns]
                entries.append(
                    DiffEntry(key=snapshot_key_display(key) or "<new>", change_type="inserted", changes=changes)
                )
                continue
            if current is not None and edited is None:
                changes = [(column, current.get(column, ""), "") for column in columns]
                entries.append(
                    DiffEntry(key=snapshot_key_display(key) or "<missing>", change_type="deleted", changes=changes)
                )
                continue
            assert current is not None and edited is not None
            cell_changes = []
            for column in columns:
                before = current.get(column, "")
                after = edited.get(column, "")
                if before != after:
                    cell_changes.append((column, before, after))
            if cell_changes:
                entries.append(
                    DiffEntry(key=snapshot_key_display(key) or "<blank>", change_type="updated", changes=cell_changes)
                )
        return entries

    entries: list[DiffEntry] = []
    max_rows = max(len(current_rows), len(edited_rows))
    for index in range(max_rows):
        current = current_rows[index] if index < len(current_rows) else None
        edited = edited_rows[index] if index < len(edited_rows) else None
        if current is None and edited is not None:
            entries.append(
                DiffEntry(
                    key=f"row {index + 1}",
                    change_type="inserted",
                    changes=[(column, "", edited.get(column, "")) for column in columns],
                )
            )
            continue
        if current is not None and edited is None:
            entries.append(
                DiffEntry(
                    key=f"row {index + 1}",
                    change_type="deleted",
                    changes=[(column, current.get(column, ""), "") for column in columns],
                )
            )
            continue
        assert current is not None and edited is not None
        cell_changes = []
        for column in columns:
            before = current.get(column, "")
            after = edited.get(column, "")
            if before != after:
                cell_changes.append((column, before, after))
        if cell_changes:
            entries.append(
                DiffEntry(key=f"row {index + 1}", change_type="updated", changes=cell_changes)
            )
    return entries


def snapshot_key_tuple(row: dict[str, str], key_columns: list[str]) -> tuple[str, ...]:
    return tuple(row.get(column, "") for column in key_columns)


def snapshot_key_display(key: tuple[str, ...]) -> str:
    if len(key) == 1:
        return key[0]
    return " | ".join(key)


def resolve_target_column(
    project: Project,
    analyzed_column: AnalyzedColumn,
) -> tuple[str, str] | None:
    if analyzed_column.source_table and analyzed_column.source_column:
        return analyzed_column.source_table, analyzed_column.source_column
    return None


def parse_input_value(project: Project, table: str, column_name: str, raw_value: str) -> Any:
    column = project.schema_for(table).columns[column_name]
    return parse_column_value(raw_value, column, location=f"{table}.{column_name}")


def collect_row_changes(
    *,
    project: Project,
    analysis: LensAnalysis,
    current_row: dict[str, str] | None,
    edited_row: dict[str, str],
    is_insert: bool,
    rows_by_table: dict[str, list[dict[str, Any]]],
    reference_creations: list[TableInsert],
) -> dict[str, Any]:
    column_map = analysis.column_map()
    primary_schema = project.schema_for(analysis.primary_table or "")
    changes: dict[str, Any] = {}

    for output_name, new_value in edited_row.items():
        if output_name in analysis.primary_key_outputs:
            if current_row is not None and new_value != current_row.get(output_name, ""):
                raise MutationError("Updating a lens row primary key is not supported")
            continue

        old_value = "" if current_row is None else current_row.get(output_name, "")
        if not is_insert and old_value == new_value:
            continue
        if is_insert and new_value == "":
            continue

        analyzed_column = column_map[output_name]
        if analyzed_column.kind in {"computed", "aggregate", "wildcard"}:
            raise MutationError(f"Column {output_name!r} is not writable")
        if analyzed_column.kind == "joined_lookup":
            raise MutationError(f"Joined lookup column {output_name!r} is not writable")
        if not analyzed_column.writable:
            raise MutationError(f"Column {output_name!r} is not writable")
        target = resolve_target_column(project, analyzed_column)
        if target is None:
            raise MutationError(f"Column {output_name!r} does not map to a writable target")
        target_table, target_column = target
        parsed_value = parse_input_value(project, target_table, target_column, new_value)

        if target_table != analysis.primary_table:
            raise MutationError(
                f"Writable output {output_name!r} maps outside the primary table, which is unsupported in v1"
            )

        source_column = primary_schema.columns[target_column]
        if source_column.immutable:
            raise MutationError(f"Column {analysis.primary_table}.{target_column} is immutable")

        previous_value = changes.get(target_column)
        if previous_value is not None and previous_value != parsed_value:
            raise MutationError(
                f"Edited outputs conflict on the target column {analysis.primary_table}.{target_column}"
            )
        changes[target_column] = parsed_value

    return changes


def apply_inferred_defaults(
    project: Project, analysis: LensAnalysis, row: dict[str, Any]
) -> None:
    if not analysis.inferred_defaults:
        return
    primary_schema = project.schema_for(analysis.primary_table or "")
    for column_name, raw_value in analysis.inferred_defaults.items():
        if row.get(column_name) is not None:
            continue
        column = primary_schema.columns.get(column_name)
        if column is None:
            continue
        row[column_name] = parse_input_value(project, analysis.primary_table or "", column_name, raw_value)


def ensure_writable_analysis(analysis: LensAnalysis, *, subject: str = "Resource") -> None:
    if not analysis.writable:
        raise MutationError(
            f"{subject} is not writable: "
            + "; ".join(analysis.reasons or ["missing primary key mapping"])
        )
    if analysis.primary_table is None or not analysis.primary_key_outputs:
        raise MutationError("Lens is missing primary table or primary key information")


def analyze_resource_view(
    project: Project,
    resource_name: str,
    result_columns: list[str],
    query: ResourceQuery | None = None,
) -> LensAnalysis:
    analysis = analyze_resource(project, resource_name)
    column_map = analysis.column_map()
    columns: list[AnalyzedColumn] = []
    reasons = list(analysis.reasons)

    for column_name in result_columns:
        analyzed_column = column_map.get(column_name)
        if analyzed_column is None:
            reasons.append(f"dynamic edit output {column_name!r} does not map to the resource")
            continue
        columns.append(deepcopy(analyzed_column))

    missing_primary_keys = [
        output_name for output_name in analysis.primary_key_outputs if output_name not in result_columns
    ]
    if missing_primary_keys:
        reasons.append(
            "dynamic edit view must include primary key output column(s) "
            f"{', '.join(missing_primary_keys)!r}"
        )

    primary_key_outputs = [
        output_name for output_name in analysis.primary_key_outputs if output_name in result_columns
    ]
    writable = analysis.writable and not reasons and len(columns) == len(result_columns)

    inferred_defaults = dict(analysis.inferred_defaults)
    inferred_default_sources = dict(analysis.inferred_default_sources)
    warnings = [*analysis.warnings, "dynamic edit view"]
    if query is not None and query.where:
        extra_defaults, extra_sources, extra_warnings = infer_defaults_from_resource_where(
            project, analysis, query.where
        )
        for column_name, value in extra_defaults.items():
            inferred_defaults[column_name] = value
            inferred_default_sources[column_name] = extra_sources[column_name]
        warnings.extend(extra_warnings)
    return LensAnalysis(
        lens_name=analysis.lens_name,
        primary_table=analysis.primary_table,
        primary_alias=analysis.primary_alias,
        primary_key_output=primary_key_outputs[0] if len(primary_key_outputs) == 1 else None,
        primary_key_outputs=primary_key_outputs,
        columns=columns,
        writable=writable,
        reasons=reasons,
        warnings=warnings,
        inferred_defaults=inferred_defaults,
        inferred_default_sources=inferred_default_sources,
    )


def build_mutation_plan_from_result(
    project: Project,
    analysis: LensAnalysis,
    result: QueryResult,
    edited_csv_path: str | Path,
    *,
    subject: str = "Resource",
) -> MutationPlan:
    ensure_writable_analysis(analysis, subject=subject)

    current_rows = snapshot_rows(result.columns, result.rows)
    edited_rows = read_snapshot_csv(Path(edited_csv_path), result.columns)
    diff_entries = diff_snapshots(
        current_rows, edited_rows, analysis.primary_key_outputs, result.columns
    )

    current_by_key: dict[tuple[str, ...], dict[str, str]] = {}
    for row in current_rows:
        key = snapshot_key_tuple(row, analysis.primary_key_outputs)
        if any(value == "" for value in key):
            raise MutationError("Lens contains a row without the primary key output")
        if key in current_by_key:
            raise MutationError("Lens rows do not map one-to-one to the primary table")
        current_by_key[key] = row

    edited_keys = [snapshot_key_tuple(row, analysis.primary_key_outputs) for row in edited_rows if row]
    deleted_keys = sorted(set(current_by_key) - {key for key in edited_keys if all(key)})
    if deleted_keys:
        raise MutationError(
            "Deleting rows through edited lens snapshots is not supported in v1: "
            f"{[snapshot_key_display(key) for key in deleted_keys]}"
        )

    rows_by_table = project.load_all_rows()
    working_rows = deepcopy(rows_by_table)
    primary_schema = project.schema_for(analysis.primary_table)
    primary_keys = project.primary_key_columns(analysis.primary_table)
    base_index = {
        project.primary_key_tuple(analysis.primary_table, row): row
        for row in working_rows[analysis.primary_table]
    }

    updates: list[TableMutation] = []
    inserts: list[TableInsert] = []
    reference_creations: list[TableInsert] = []
    generated_primary_keys: list[str] = []
    touched_tables: set[str] = set()
    pending_insert_keys: set[tuple[str, ...]] = set()

    for edited_row in edited_rows:
        key = snapshot_key_tuple(edited_row, analysis.primary_key_outputs)
        current_row = current_by_key.get(key)

        if current_row is not None:
            base_row = base_index.get(key)
            if base_row is None:
                raise MutationError(
                    f"Lens row {key!r} does not map back to a source row in {analysis.primary_table}"
                )
            changes = collect_row_changes(
                project=project,
                analysis=analysis,
                current_row=current_row,
                edited_row=edited_row,
                is_insert=False,
                rows_by_table=working_rows,
                reference_creations=reference_creations,
                )
            if changes:
                base_row.update(changes)
                updates.append(
                    TableMutation(
                        table=analysis.primary_table,
                        key=snapshot_key_display(key),
                        changes=deepcopy(changes),
                    )
                )
                touched_tables.add(analysis.primary_table)
            continue

        new_row = project.blank_row(analysis.primary_table)
        pk_values = key
        if len(primary_keys) == 1 and pk_values[0] == "":
            pk_column = primary_schema.columns[primary_keys[0]]
            if pk_column.type != "string":
                raise MutationError(
                    f"Inserted rows for {analysis.primary_table!r} must supply primary key "
                    f"{primary_keys[0]!r} because it is not a string column"
                )
            pk_value = project.generate_primary_key(analysis.primary_table)
            generated_primary_keys.append(pk_value)
            edited_row = dict(edited_row)
            edited_row[analysis.primary_key_outputs[0]] = pk_value
            pk_values = (pk_value,)
        elif any(value == "" for value in pk_values):
            missing_outputs = [
                output_name
                for output_name, value in zip(analysis.primary_key_outputs, pk_values, strict=True)
                if value == ""
            ]
            raise MutationError(
                f"Inserted rows for {analysis.primary_table!r} must supply primary key output(s) "
                f"{', '.join(missing_outputs)}"
            )

        if pk_values in base_index or pk_values in pending_insert_keys:
            raise MutationError(
                f"Inserted row primary key {snapshot_key_display(pk_values)!r} "
                f"already exists in {analysis.primary_table!r}"
            )

        for primary_key, pk_value in zip(primary_keys, pk_values, strict=True):
            new_row[primary_key] = parse_input_value(
                project, analysis.primary_table, primary_key, pk_value
            )
        apply_inferred_defaults(project, analysis, new_row)
        changes = collect_row_changes(
            project=project,
            analysis=analysis,
            current_row=None,
            edited_row=edited_row,
            is_insert=True,
            rows_by_table=working_rows,
            reference_creations=reference_creations,
        )
        new_row.update(changes)
        working_rows[analysis.primary_table].append(new_row)
        base_index[pk_values] = new_row
        pending_insert_keys.add(pk_values)
        inserts.append(TableInsert(table=analysis.primary_table, row=deepcopy(new_row)))
        touched_tables.add(analysis.primary_table)

    if reference_creations:
        touched_tables.update(insert.table for insert in reference_creations)

    project.validate_rows_map(working_rows)

    return MutationPlan(
        lens_name=analysis.lens_name,
        primary_table=analysis.primary_table,
        primary_key_output=analysis.primary_key_output or ", ".join(analysis.primary_key_outputs),
        primary_key_outputs=analysis.primary_key_outputs,
        diff_entries=diff_entries,
        updates=updates,
        inserts=inserts,
        reference_creations=reference_creations,
        generated_primary_keys=generated_primary_keys,
        inferred_defaults=dict(analysis.inferred_defaults),
        inferred_default_sources=dict(analysis.inferred_default_sources),
        rows_by_table=working_rows,
        touched_tables=touched_tables,
    )


def build_mutation_plan(
    project: Project, resource_name: str, edited_csv_path: str | Path
) -> MutationPlan:
    analysis = analyze_resource(project, resource_name)
    result = query_resource(project, resource_name)
    return build_mutation_plan_from_result(project, analysis, result, edited_csv_path)


def build_mutation_plan_for_view(
    project: Project,
    resource_name: str,
    query: ResourceQuery,
    edited_csv_path: str | Path,
) -> MutationPlan:
    result = query_resource_view(project, resource_name, query)
    analysis = analyze_resource_view(project, resource_name, result.columns, query=query)
    return build_mutation_plan_from_result(
        project,
        analysis,
        result,
        edited_csv_path,
        subject="Dynamic edit view",
    )


def apply_mutation_plan(project: Project, plan: MutationPlan) -> MutationPlan:
    if plan.has_changes:
        project.write_rows_map_atomic(plan.rows_by_table, plan.touched_tables)
        project.validate()
    return plan


def recovery_dir(project: Project) -> Path:
    return project.root / ".lenzdb" / "recovery"


def recovery_stem(resource_name: str) -> str:
    return (
        resource_name.replace("/", "_")
        .replace("\\", "_")
        .replace(":", "_")
        .replace(" ", "_")
    )


def recovery_resource_name(
    project: Project, resource_name: str, query: ResourceQuery | None = None
) -> str:
    resolved_name = project.resolve_resource_name(resource_name)[1]
    if query is None:
        return resolved_name
    return f"{resolved_name}.view.{query_fingerprint(query)}"


def recovery_glob(project: Project, resource_name: str, query: ResourceQuery | None = None) -> str:
    return f"{recovery_stem(recovery_resource_name(project, resource_name, query))}-*.csv"


def recovery_path(project: Project, resource_name: str, query: ResourceQuery | None = None) -> Path:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    stem = recovery_stem(recovery_resource_name(project, resource_name, query))
    return recovery_dir(project) / f"{stem}-{timestamp}.csv"


def latest_recovery_path(
    project: Project, resource_name: str, query: ResourceQuery | None = None
) -> Path | None:
    directory = recovery_dir(project)
    if not directory.exists():
        return None
    paths = sorted(directory.glob(recovery_glob(project, resource_name, query)))
    return paths[-1] if paths else None


def clear_recovery_files(
    project: Project, resource_name: str, query: ResourceQuery | None = None
) -> None:
    directory = recovery_dir(project)
    if not directory.exists():
        return
    for path in directory.glob(recovery_glob(project, resource_name, query)):
        path.unlink()


def preserve_recovery_file(
    project: Project,
    resource_name: str,
    edited_path: Path,
    query: ResourceQuery | None = None,
) -> Path:
    preserved_path = recovery_path(project, resource_name, query)
    preserved_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(edited_path, preserved_path)
    return preserved_path


def export_lens_csv(
    project: Project,
    resource_name: str,
    target: Path,
    query: ResourceQuery | None = None,
) -> None:
    result = query_resource_view(project, resource_name, query) if query is not None else query_resource(project, resource_name)
    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=result.columns, lineterminator="\n")
        writer.writeheader()
        for row in snapshot_rows(result.columns, result.rows):
            writer.writerow(row)


def run_editor(editor: str, path: Path) -> None:
    command = [*shlex.split(editor), str(path)]
    try:
        subprocess.run(command, check=True)
    except FileNotFoundError as exc:
        raise MutationError(f"Editor command not found: {editor!r}") from exc
    except subprocess.CalledProcessError as exc:
        raise MutationError(f"Editor command failed with exit code {exc.returncode}") from exc


def edit_lens(
    project: Project,
    resource_name: str,
    editor: str,
    *,
    discard_recovery: bool = False,
    query: ResourceQuery | None = None,
) -> EditResult:
    if query is not None:
        result = query_resource_view(project, resource_name, query)
        analysis = analyze_resource_view(project, resource_name, result.columns, query=query)
        ensure_writable_analysis(analysis, subject="Dynamic edit view")

    with tempfile.TemporaryDirectory(prefix="lenzdb-") as temp_dir:
        safe_name = resource_name.replace("/", "_").replace("\\", "_")
        temp_path = Path(temp_dir) / f"{safe_name}.csv"
        recovered_from = None if discard_recovery else latest_recovery_path(project, resource_name, query)
        if recovered_from is not None:
            shutil.copy2(recovered_from, temp_path)
        else:
            export_lens_csv(project, resource_name, temp_path, query)
        try:
            run_editor(editor, temp_path)
        except MutationError as exc:
            preserved_path = preserve_recovery_file(project, resource_name, temp_path, query)
            raise MutationError(f"{exc}\nEdited file preserved at: {preserved_path}") from exc
        preserved_path = preserve_recovery_file(project, resource_name, temp_path, query)
        try:
            if query is None:
                plan = build_mutation_plan(project, resource_name, temp_path)
            else:
                plan = build_mutation_plan_for_view(project, resource_name, query, temp_path)
        except MutationError as exc:
            raise MutationError(f"{exc}\nEdited file preserved at: {preserved_path}") from exc
        return EditResult(plan=plan, recovery_path=preserved_path, recovered_from=recovered_from)
