"""Normalise a Markor note from inbox/android/ into a triaged vault note.

A Markor note is a plain markdown file typed on Android and synced to
`inbox/android/` via FolderSync over SFTP.  This normalizer:

1. Validates the source path is inside the android inbox (no traversal,
   no symlinks pointing out).
2. Reads the file as UTF-8; on decode failure moves it to inbox/failed/.
3. Scans for ![[image.ext]] embeds co-located in the same directory.
   When `ollama_chat` is provided, OCRs each image and appends the
   transcript to the note body; the image is copied to "Jpeg and other media/"
   and a .processed marker is written so the watcher skips it later.
4. Builds a vault-style header stamped with the provided time, STATE #infant,
   SOURCE Android/Markor, and default tags [[amie]] [[Android]].
5. Writes the result to inbox/triaged/ with mode 0o600.
6. Writes a `.processed.<name>` marker beside the source file; the source
   is preserved so sync tools (FolderSync, Syncthing) are not confused by
   deletions.  The watcher and startup scan skip files whose marker exists.

The `now` and `ollama_chat` parameters are injected so callers (and tests)
can supply a fixed timestamp or a fake OCR function.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any

from amie.config import Config
from amie.normalizers.header import Header, compose

logger = logging.getLogger(__name__)

OllamaChat = Callable[[str, list[dict[str, Any]]], str]

# Matches Obsidian image embeds like ![[photo.jpg]] or ![[scan.HEIC]]
_EMBED_IMAGE_RE = re.compile(r"!\[\[([^\]]+\.(?:jpg|jpeg|png|heic))\]\]", re.IGNORECASE)


class SecurityError(ValueError):
    """Raised when the source path fails inbox-boundary validation."""


def normalize(
    source: Path,
    cfg: Config,
    *,
    now: Callable[[], datetime] = datetime.now,
    ollama_chat: OllamaChat | None = None,
) -> Path:
    """Normalize a Markor note into inbox/triaged/.

    Returns the path of the written triaged note.
    Raises `SecurityError` if the source path is outside the android inbox.
    Raises `ValueError` (and moves source to failed/) if the file is not UTF-8.

    When `ollama_chat` is provided, any ![[image.ext]] embeds found alongside
    the source file are OCR'd and their transcripts are appended to the note.
    """
    _validate_source_path(source, cfg.android_dir)
    content = _read_or_quarantine(source, cfg.failed_dir)

    enriched_content, embedded_images = (
        _enrich_embedded_images(content, source.parent, cfg, ollama_chat)
        if ollama_chat is not None
        else (content, [])
    )

    header = Header.from_now(
        now=now,
        state="infant",
        tags=["amie", "Android"],
        source="Android/Markor",
    )
    note = compose(header, enriched_content)
    dest = _unique_path(cfg.triaged_dir / source.name)
    dest.write_text(note, encoding="utf-8")
    dest.chmod(0o600)
    (source.parent / f".processed.{source.name}").write_text("")

    for img in embedded_images:
        marker = img.parent / f".processed.{img.name}"
        if not marker.exists():
            marker.write_text("")

    return dest


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _validate_source_path(source: Path, android_dir: Path) -> None:
    """Raise SecurityError if source resolves outside the android inbox."""
    resolved = source.resolve()
    inbox_resolved = android_dir.resolve()
    if not resolved.is_relative_to(inbox_resolved):
        raise SecurityError(f"{source!r} is outside the android inbox {inbox_resolved!r}")


def _read_or_quarantine(source: Path, failed_dir: Path) -> str:
    """Read source as UTF-8. On failure move it to failed/ and raise."""
    try:
        return source.read_text(encoding="utf-8")
    except UnicodeDecodeError as err:
        dest = _unique_path(failed_dir / source.name)
        source.rename(dest)
        raise ValueError(f"{source.name} is not valid UTF-8; moved to {dest}") from err


def _unique_path(path: Path) -> Path:
    """Return path if it does not exist, else path_1, path_2, … until free."""
    if not path.exists():
        return path
    stem, suffix, parent = path.stem, path.suffix, path.parent
    counter = 1
    while True:
        candidate = parent / f"{stem}_{counter}{suffix}"
        if not candidate.exists():
            return candidate
        counter += 1


def _enrich_embedded_images(
    content: str,
    source_dir: Path,
    cfg: Config,
    ollama_chat: OllamaChat,
) -> tuple[str, list[Path]]:
    """OCR any ![[image.ext]] embeds that exist in source_dir.

    Returns (enriched_content, list_of_processed_image_paths).
    Transcripts are appended to the content, separated by a horizontal rule.
    Images that are missing, already processed, or fail OCR are silently skipped.
    """
    # Late import to avoid module-level circular dependency (photo.py imports
    # _unique_path from this module at the top level).
    from amie.normalizers.photo import (
        _call_ocr,
        _copy_to_media,
        _resize_for_ocr,
        _to_jpg,
    )

    names = _EMBED_IMAGE_RE.findall(content)
    if not names:
        return content, []

    additions: list[str] = []
    processed: list[Path] = []

    for name in names:
        img = source_dir / name
        if not img.exists():
            continue
        if (source_dir / f".processed.{img.name}").exists():
            continue
        try:
            jpg_path, is_converted = _to_jpg(img)
            try:
                ocr_path, is_resized = _resize_for_ocr(jpg_path)
                try:
                    raw = _call_ocr(ocr_path, cfg.ocr_model, ollama_chat)
                finally:
                    if is_resized:
                        ocr_path.unlink(missing_ok=True)
                transcript = (raw or "").strip()
                if transcript:
                    _copy_to_media(jpg_path, cfg.media_dir, img.name)
                    additions.append(transcript)
                    processed.append(img)
                else:
                    logger.warning("OCR returned empty transcript for embedded image %s", img.name)
            finally:
                if is_converted:
                    jpg_path.unlink(missing_ok=True)
        except Exception:
            logger.exception("failed to OCR embedded image %s", img.name)

    if not additions:
        return content, processed

    enriched = content.rstrip("\n") + "\n\n---\n\n" + "\n\n---\n\n".join(additions)
    return enriched, processed
