"""Health checks exposed via `amie doctor`.

Each check is a pure function over a `Probe` — a callable that runs a shell
command and returns `(returncode, stdout)`. The default probe shells out via
subprocess; tests inject a fake.

The vault check is the only one that touches the file system directly (via
the existing `amie.vault` module). Everything else is shelling-out.
"""

from __future__ import annotations

import subprocess
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path

from amie.config import DEFAULT_SSHD_DROP_IN, Config
from amie.vault import vault_status

Probe = Callable[[Sequence[str]], tuple[int, str]]

REQUIRED_MODELS: tuple[str, ...] = ("llama3.2:3b", "mistral:7b", "glm-ocr")


@dataclass(frozen=True)
class CheckResult:
    name: str
    ok: bool
    message: str


def real_probe(args: Sequence[str]) -> tuple[int, str]:
    try:
        completed = subprocess.run(
            list(args),
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return 127, ""
    return completed.returncode, completed.stdout


def check_uv(probe: Probe) -> CheckResult:
    rc, stdout = probe(["which", "uv"])
    if rc == 0 and stdout.strip():
        return CheckResult("uv", True, stdout.strip())
    return CheckResult("uv", False, "uv not found in PATH")


def check_ollama(probe: Probe) -> CheckResult:
    rc, _ = probe(["ollama", "list"])
    if rc == 0:
        return CheckResult("ollama", True, "ollama daemon responding")
    return CheckResult("ollama", False, "ollama not installed or not running")


def check_models(probe: Probe) -> CheckResult:
    rc, stdout = probe(["ollama", "list"])
    if rc != 0:
        return CheckResult("models", False, "could not list ollama models")
    missing = [m for m in REQUIRED_MODELS if m not in stdout]
    if missing:
        return CheckResult(
            "models",
            False,
            f"missing models: {', '.join(missing)} (run: ollama pull <name>)",
        )
    return CheckResult("models", True, f"all required models present ({len(REQUIRED_MODELS)})")


def check_vault(cfg: Config) -> CheckResult:
    status = vault_status(cfg)
    if not status.vault_exists:
        return CheckResult("vault", False, f"vault root not found at {cfg.vault_path}")
    if status.missing:
        names = ", ".join(p.relative_to(cfg.vault_path).as_posix() for p in status.missing)
        return CheckResult("vault", False, f"missing inbox dirs: {names}")
    return CheckResult("vault", True, f"all inbox directories present at {cfg.vault_path}")


def check_ssh(probe: Probe, *, sshd_config: Path = DEFAULT_SSHD_DROP_IN) -> CheckResult:
    rc, _ = probe(["pgrep", "-x", "sshd"])
    if rc != 0:
        return CheckResult("ssh", False, "sshd not running (run: sudo systemctl start ssh)")

    rc, _ = probe(["id", "amie-sync"])
    if rc != 0:
        return CheckResult("ssh", False, "amie-sync user missing — run `amie init` to create it")

    if not sshd_config.exists():
        return CheckResult("ssh", False, "AMI sshd config absent — run `amie init` to write it")

    try:
        content = sshd_config.read_text()
    except PermissionError:
        return CheckResult(
            "ssh",
            False,
            f"AMI sshd config not readable — run: sudo chmod 644 {sshd_config}",
        )

    if "passwordauthentication no" not in content.lower():
        return CheckResult("ssh", False, "PasswordAuthentication not disabled in AMI sshd config")

    return CheckResult("ssh", True, "sshd running, amie-sync user present, key-only auth enforced")


def run_all_checks(
    cfg: Config,
    *,
    probe: Probe = real_probe,
    sshd_config: Path = DEFAULT_SSHD_DROP_IN,
) -> list[CheckResult]:
    return [
        check_uv(probe),
        check_ollama(probe),
        check_models(probe),
        check_vault(cfg),
        check_ssh(probe, sshd_config=sshd_config),
    ]
