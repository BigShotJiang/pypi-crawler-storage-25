"""Typer CLI entry point for AMI.

This module is deliberately thin — it only wires Typer to domain modules.
All logic lives in `amie.dev`, `amie.vault`, `ami.doctor`, `amie.init`,
`amie.security`. The CLI's job is two things:

1. Wire Typer subcommands to the domain.
2. Translate domain exceptions into friendly messages with exact next steps.

CLI tests exercise real subprocess and real filesystem; no internal mocking.
"""

from __future__ import annotations

import sys
from collections.abc import Callable
from functools import wraps
from pathlib import Path

import typer
from dotenv import load_dotenv

from amie import dev, security, vault
from amie import inbox as inbox_mod
from amie.config import Config, ConfigError, user_config_path
from amie.doctor import CheckResult, run_all_checks
from amie.init import InitOutcome, SshSetupResult, run_init, setup_ssh_server

# Load `.env` from the working directory at CLI startup. Domain modules read
# only `os.environ`; this is the one place we touch the file system for env.
load_dotenv(override=False)

app = typer.Typer(help="AMI — Anonymous Memory Intelligence")
dev_app = typer.Typer(help="Developer tooling: tests, lint, format, sync.")
test_app = typer.Typer(help="Run integration test suite.")
vault_app = typer.Typer(help="Manage AMI's folders inside the Obsidian vault.")
push_app = typer.Typer(help="Manually push files through the normaliser pipeline.")
app.add_typer(dev_app, name="dev")
app.add_typer(test_app, name="test")
app.add_typer(vault_app, name="vault")
app.add_typer(push_app, name="push")


# ---------------------------------------------------------------------------
# Friendly error wrapper
# ---------------------------------------------------------------------------


def friendly(func: Callable[..., None]) -> Callable[..., None]:
    """Decorator: catch domain exceptions and print plain-English messages.

    Domain code is allowed to be strict (raise). The CLI translates every
    expected exception into a clear, actionable message for the user. Stack
    traces only appear if AMIE_DEBUG=1 is set.
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ConfigError as err:
            typer.echo("\n  Hold on — AMI hasn't been set up yet on this machine.\n", err=True)
            typer.echo(f"  Reason: {err}\n", err=True)
            typer.echo("  Run this once to fix it:", err=True)
            typer.echo("\n      amie init\n", err=True)
            raise typer.Exit(code=1) from err
        except FileNotFoundError as err:
            typer.echo("\n  Couldn't find a file or folder AMI needs:\n", err=True)
            typer.echo(f"  {err}\n", err=True)
            typer.echo("  Try `amie doctor` to see what's missing.\n", err=True)
            raise typer.Exit(code=1) from err

    return wrapper


# ---------------------------------------------------------------------------
# Top-level commands
# ---------------------------------------------------------------------------


@app.command()
def install(
    vault_path: Path | None = typer.Option(
        None,
        "--vault-path",
        help="Path to your Obsidian vault. If omitted you'll be asked.",
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Accept all defaults; create the vault if missing."
    ),
) -> None:
    """Bootstrap AMI on this machine: install the binary and run first-time setup."""
    import subprocess

    project_root = Path(__file__).resolve().parent.parent.parent
    if (project_root / "pyproject.toml").exists():
        rc = subprocess.run(
            ["uv", "tool", "install", "--editable", str(project_root)],
            check=False,
        ).returncode
        if rc != 0:
            typer.echo(
                "\n  Binary install failed. Make sure uv is on PATH, then run:\n"
                f"\n      uv tool install --editable {project_root}\n",
                err=True,
            )
            raise typer.Exit(code=rc)
        typer.echo("\n  Binary installed. Running first-time setup...\n")

    init(vault_path=vault_path, yes=yes)


@app.command()
def init(
    vault_path: Path | None = typer.Option(
        None,
        "--vault-path",
        help="Path to your Obsidian vault. If omitted you'll be asked.",
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Accept all defaults; create the vault if missing."
    ),
) -> None:
    """Set up AMI on this machine: write the config file and create inbox folders."""
    chosen_path = _ask_for_vault_path(vault_path)
    create_if_missing = _ask_to_create_vault(chosen_path, auto_yes=yes)

    try:
        outcome = run_init(
            vault_path=chosen_path,
            config_path=user_config_path(),
            create_vault_if_missing=create_if_missing,
        )
    except FileNotFoundError:
        typer.echo("\n  Cancelled — your vault wasn't created.", err=True)
        typer.echo(
            f"  When you're ready, run `amie init` again or create {chosen_path} manually.\n",
            err=True,
        )
        raise typer.Exit(code=1) from None

    ssh = setup_ssh_server(sshd_drop_in=Config.sshd_drop_in_from_env())
    _display_init_outcome(outcome, ssh)


@app.command()
@friendly
def watch() -> None:
    """Watch the inbox folders and normalize incoming notes."""
    import logging
    import os
    import signal

    from amie.watcher import Watcher

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-7s  %(message)s",
        datefmt="%H:%M:%S",
    )

    cfg = Config.from_env()
    _scaffold_with_notice(cfg)

    typer.echo(f"\n  amie watch  pid={os.getpid()}")
    typer.echo(f"  vault:  {cfg.vault_path}")
    typer.echo(f"  inbox:  {cfg.inbox_dir}")
    typer.echo("  Ctrl-C to stop.\n")

    watcher = Watcher(cfg)

    def _stop(signum, frame):
        watcher.stop()

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    watcher.start()
    watcher._observer.join()


@app.command()
@friendly
def inbox(
    once: bool = typer.Option(False, "--once", help="Print once and exit (no live refresh)."),
    failed: bool = typer.Option(False, "--failed", help="Show filenames in failed/ only."),
) -> None:
    """Show a live view of inbox folder state. Refreshes every second. Ctrl-C to stop."""
    _ANSI_RED = "\033[31m"
    _ANSI_RESET = "\033[0m"
    _CLEAR = "\033[H\033[2J"

    cfg = Config.from_env()
    _scaffold_with_notice(cfg)

    if failed:
        names = inbox_mod.failed_files(cfg)
        if names:
            for name in names:
                typer.echo(name)
        else:
            typer.echo("  failed/ is empty")
        return

    def _render() -> str:
        snapshot = inbox_mod.inbox_snapshot(cfg)
        lines = []
        for info, (_, waiting) in zip(snapshot, inbox_mod.INBOX_SUBFOLDERS, strict=True):
            line = inbox_mod.format_folder_line(info, waiting=waiting)
            if info.attention:
                line = f"{_ANSI_RED}{line}{_ANSI_RESET}"
            lines.append(line)
        return "\n".join(lines)

    if once:
        typer.echo(_render())
        return

    _run_live_inbox(_render, _CLEAR)


def _run_live_inbox(render_fn, clear_seq: str) -> None:  # pragma: no cover
    import signal
    import time

    _stop = False

    def _handle_sigint(signum, frame):
        nonlocal _stop
        _stop = True

    signal.signal(signal.SIGINT, _handle_sigint)

    while not _stop:
        sys.stdout.write(clear_seq + render_fn() + "\n")
        sys.stdout.flush()
        time.sleep(1)


@app.command()
def version() -> None:
    """Print the installed amie version."""
    from importlib.metadata import version as _version

    typer.echo(f"amie {_version('amie')}")


def _editable_root() -> Path | None:
    """Return the project root if amie is installed as an editable (dev) install.

    Reads PEP 610 direct_url.json from the amie dist-info directory.
    Returns None for normal PyPI / uv tool installs.
    """
    try:
        from importlib.metadata import distribution

        dist = distribution("amie")
        direct_url_text = dist.read_text("direct_url.json")
        if not direct_url_text:
            return None
        import json

        info = json.loads(direct_url_text)
        dir_info = info.get("dir_info", {})
        if not dir_info.get("editable"):
            return None
        url = info.get("url", "")
        if not url.startswith("file://"):
            return None
        return Path(url[len("file://") :])
    except Exception:
        return None


@app.command()
def update() -> None:
    """Update amie to the latest version from PyPI (or pull latest for editable installs)."""
    import subprocess

    root = _editable_root()
    if root is not None:
        typer.echo(f"Editable install detected at {root} — pulling latest changes…")
        rc = subprocess.run(["git", "-C", str(root), "pull"], check=False).returncode
        if rc == 0:
            rc = subprocess.run(["uv", "sync", "--project", str(root)], check=False).returncode
        if rc != 0:
            typer.echo(
                f"Update failed. Try manually: git -C {root} pull && uv sync --project {root}",
                err=True,
            )
            raise typer.Exit(code=rc)
        return

    rc = subprocess.run(["uv", "tool", "upgrade", "amie"], check=False).returncode
    if rc != 0:
        rc = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "amie"],
            check=False,
        ).returncode
    if rc != 0:
        typer.echo("Update failed. Try manually: uv tool upgrade amie", err=True)
        raise typer.Exit(code=rc)


@app.command()
@friendly
def digest() -> None:
    """Generate the weekly digest."""
    cfg = Config.from_env()
    _scaffold_with_notice(cfg)
    typer.echo("digest: not yet implemented (see docs/amie/11-weekly-digest.md)")


@app.command()
@friendly
def ocr(path: str) -> None:
    """Run OCR on a single image and print the transcript."""
    cfg = Config.from_env()
    _scaffold_with_notice(cfg)
    typer.echo(f"ocr {path}: not yet implemented (see docs/amie/09-photo-ocr.md)")


@app.command()
@friendly
def doctor() -> None:
    """Run all health checks and report status."""
    cfg = Config.from_env()
    results: list[CheckResult] = run_all_checks(cfg)
    for result in results:
        marker = "OK" if result.ok else "FAIL"
        typer.echo(f"  [{marker}] {result.name}: {result.message}")
    if any(not r.ok for r in results):
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# dev sub-app
# ---------------------------------------------------------------------------


@dev_app.command("test")
def dev_test(no_cov: bool = typer.Option(False, "--no-cov", help="Skip coverage gate.")) -> None:
    """Run the test suite under uv. Coverage gate is enforced by default."""
    rc = dev.run(dev.build_test_command(no_cov=no_cov))
    raise typer.Exit(code=rc)


@dev_app.command("lint")
def dev_lint(fix: bool = typer.Option(False, "--fix", help="Auto-fix lint issues.")) -> None:
    """Run ruff check across the project."""
    rc = dev.run(dev.build_lint_command(fix=fix))
    raise typer.Exit(code=rc)


@dev_app.command("fmt")
def dev_fmt() -> None:
    """Format the codebase with ruff."""
    rc = dev.run(dev.build_fmt_command())
    raise typer.Exit(code=rc)


@dev_app.command("sync")
def dev_sync() -> None:
    """Sync project dependencies (uv sync)."""
    rc = dev.run(dev.build_sync_command())
    raise typer.Exit(code=rc)


@dev_app.command("guard")
def dev_guard(
    skip_audit: bool = typer.Option(
        False,
        "--skip-audit",
        help="Skip the security-audit step (which makes a network call). Use for fast iteration.",
    ),
) -> None:
    """Run lint + format-check + tests-with-coverage + security audit + docs check.

    Run before AND after every code change. With `--skip-audit`, the network
    call is skipped — useful for tight inner loops, but full guard must pass
    before declaring work done.

    The docs-check step runs automatically when AMIE_DOCS_PATH is set.
    """
    results = dev.run_guards(skip_audit=skip_audit, docs_dir=Config.docs_path_from_env())
    for result in results:
        marker = "OK" if result.passed else "FAIL"
        typer.echo(f"  [{marker}] {result.name}")
    if results and not results[-1].passed:
        raise typer.Exit(code=results[-1].exit_code)


@dev_app.command("audit")
def dev_audit() -> None:
    """Run a security audit on the project's dependencies (pip-audit)."""
    rc = dev.run(security.build_audit_command())
    raise typer.Exit(code=rc)


@dev_app.command("docs")
@friendly
def dev_docs(
    docs_dir: str = typer.Option(
        "",
        "--docs-dir",
        help="Path to the docs folder. Defaults to AMIE_DOCS_PATH env var.",
    ),
) -> None:
    """Check that the docs folder is not stale.

    Verifies that vault-structure.md mentions every top-level vault section
    and that 14-cli-reference.md mentions every CLI command. Exits non-zero
    and lists gaps if anything is out of date.

    Set AMIE_DOCS_PATH in your .env or environment to run this automatically
    as part of `amie dev guard`.
    """
    from amie.docs import run_docs_check
    from amie.vault import VAULT_SKELETON

    resolved = Path(docs_dir) if docs_dir else Config.docs_path_from_env()
    if resolved is None:
        typer.echo(
            "  docs check skipped — set AMIE_DOCS_PATH to enable.\n"
            "  Example: AMIE_DOCS_PATH=~/source/ubuntu/docs/amie"
        )
        return

    commands = _collect_all_commands()
    issues = run_docs_check(resolved, skeleton=VAULT_SKELETON, commands=commands)

    if not issues:
        typer.echo(f"  OK — docs are current ({resolved})")
        return

    typer.echo(f"  FAIL — {len(issues)} doc gap(s) found:\n", err=True)
    for issue in issues:
        typer.echo(f"    [{issue.doc}] {issue.missing}", err=True)
    raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _display_init_outcome(
    outcome: InitOutcome,
    ssh: SshSetupResult,
    *,
    file: object = None,
) -> None:
    vault_state = "created" if outcome.vault_created else "already existed"
    sshd_state = "installed" if ssh.sshd_was_installed else "already present"
    user_state = "created" if ssh.user_was_created else "already present"
    kwargs = {"file": file} if file is not None else {}
    typer.echo("", **kwargs)
    typer.echo("  All set!", **kwargs)
    typer.echo(f"    config:        {outcome.config_path}", **kwargs)
    typer.echo(f"    vault:         {outcome.vault_path} ({vault_state})", **kwargs)
    typer.echo(f"    vault folders: {outcome.folders_created} created or verified", **kwargs)
    typer.echo(f"    openssh-server: {sshd_state}", **kwargs)
    typer.echo(f"    amie-sync user:  {user_state}", **kwargs)
    typer.echo("\n  Next: run `amie doctor` to confirm Ollama and SSH are ready.\n", **kwargs)


def _scaffold_with_notice(cfg: Config) -> None:
    """Create any missing vault folders, printing a notice if any were added."""
    created = vault.scaffold_vault(cfg)
    if created:
        typer.echo(
            f"Notice: created {len(created)} missing vault folder(s)"
            " — run `amie vault status` for details."
        )


def _collect_all_commands() -> list[str]:
    """Return every CLI command name as it appears in the reference doc."""

    def _name(cmd_info) -> str:
        if cmd_info.name:
            return cmd_info.name
        if cmd_info.callback:
            return cmd_info.callback.__name__.replace("_", "-")
        return ""

    commands = [f"amie {_name(c)}" for c in app.registered_commands if _name(c)]
    commands += [f"amie dev {_name(c)}" for c in dev_app.registered_commands if _name(c)]
    commands += [f"amie test {_name(c)}" for c in test_app.registered_commands if _name(c)]
    commands += [f"amie vault {_name(c)}" for c in vault_app.registered_commands if _name(c)]
    commands += [f"amie push {_name(c)}" for c in push_app.registered_commands if _name(c)]
    return [c for c in commands if c.strip()]


# ---------------------------------------------------------------------------
# vault sub-app
# ---------------------------------------------------------------------------


@vault_app.command("init")
@friendly
def vault_init() -> None:
    """Create the full vault folder structure inside the Obsidian vault."""
    cfg = Config.from_env()
    created = vault.scaffold_vault(cfg)
    if created:
        typer.echo(f"OK — created {len(created)} folders under {cfg.vault_path}")
    else:
        typer.echo(f"OK — all vault folders already present under {cfg.vault_path}")


@vault_app.command("status")
@friendly
def vault_status_cmd() -> None:
    """Report whether AMI's folders exist inside the vault."""
    cfg = Config.from_env()
    status = vault.vault_status(cfg)
    if not status.vault_exists:
        typer.echo(f"vault: not ready — root missing at {cfg.vault_path}")
        raise typer.Exit(code=1)
    if status.missing:
        names = "\n  - ".join(p.relative_to(cfg.vault_path).as_posix() for p in status.missing)
        typer.echo(f"vault: not ready — missing dirs:\n  - {names}")
        raise typer.Exit(code=1)
    typer.echo(f"vault: ready — all inbox directories present at {cfg.vault_path}")


# ---------------------------------------------------------------------------
# test sub-app
# ---------------------------------------------------------------------------


@test_app.command("integration")
def test_integration() -> None:
    """Run live integration tests against Ollama. Requires a vision model loaded."""
    rc = dev.run(dev.build_integration_command())
    raise typer.Exit(code=rc)


# ---------------------------------------------------------------------------
# push sub-app
# ---------------------------------------------------------------------------


@push_app.command("photo")
@friendly
def push_photo(
    file: Path = typer.Argument(..., help="Photo to OCR. Use inbox/failed/ path to retry."),
) -> None:
    """Run the full OCR pipeline on a single photo and write a triaged note."""
    import shutil

    from amie.normalizers.photo import SecurityError
    from amie.normalizers.photo import normalize as normalize_photo

    cfg = Config.from_env()
    _scaffold_with_notice(cfg)

    source = file.resolve()

    # Move android and failed photos into photos/ before normalising.
    if source.parent == cfg.failed_dir.resolve():
        dest = cfg.photos_dir / source.name
        shutil.move(str(source), dest)
        source = dest
        typer.echo(f"  Moved from failed/ → photos/{source.name}")
    elif source.parent == cfg.android_dir.resolve():
        dest = cfg.photos_dir / source.name
        shutil.move(str(source), dest)
        source = dest
        typer.echo(f"  Moved from android/ → photos/{source.name}")

    try:
        note = normalize_photo(source, cfg)
    except SecurityError as err:
        typer.echo(f"\n  {err}", err=True)
        typer.echo(
            f"\n  File must be inside {cfg.photos_dir} (or inbox/failed/ or"
            " inbox/android/ for a retry).",
            err=True,
        )
        raise typer.Exit(code=1) from err
    except ValueError as err:
        typer.echo(f"\n  OCR failed: {err}", err=True)
        raise typer.Exit(code=1) from err

    typer.echo(f"  OK — note written to {note.relative_to(cfg.vault_path)}")


_PHOTO_SUFFIXES = {".jpg", ".jpeg", ".png", ".heic"}


@push_app.command("photos")
@friendly
def push_photos() -> None:
    """Run OCR on every unprocessed photo in inbox/photos/."""
    from amie.normalizers.photo import normalize as normalize_photo

    cfg = Config.from_env()
    _scaffold_with_notice(cfg)

    processed = 0
    failed = 0
    for source in sorted(cfg.photos_dir.iterdir()):
        if source.name.startswith("."):
            continue
        if (source.parent / f".processed.{source.name}").exists():
            continue
        if source.suffix.lower() not in _PHOTO_SUFFIXES:
            continue
        try:
            note = normalize_photo(source, cfg)
            typer.echo(f"  OK {source.name} → {note.relative_to(cfg.vault_path)}")
            processed += 1
        except Exception as err:
            typer.echo(f"  FAIL {source.name}: {err}", err=True)
            failed += 1

    typer.echo(f"\n  {processed} processed, {failed} failed.")


# ---------------------------------------------------------------------------
# Private helpers (CLI-side prompts)
# ---------------------------------------------------------------------------


def _ask_for_vault_path(provided: Path | None) -> Path:
    """If the user supplied --vault-path, use it. Otherwise prompt with a default."""
    if provided is not None:
        return provided
    default = Path.home() / "Obsidian"
    answer: str = typer.prompt(
        "Where is (or should be) your Obsidian vault?",
        default=str(default),
    )
    return Path(answer).expanduser()


def _ask_to_create_vault(vault_path: Path, *, auto_yes: bool) -> bool:
    """If the vault doesn't exist, ask whether to create it. Default yes."""
    if vault_path.expanduser().is_dir():
        return False
    if auto_yes:
        return True
    return typer.confirm(f"  {vault_path} doesn't exist yet. Create it now?", default=True)


if __name__ == "__main__":
    sys.exit(app())
