"""Watch inbox/android/ and inbox/photos/ and dispatch arriving files.

The watcher runs as a long-lived foreground process (`amie watch`).
Watchdog fires events when files are created or renamed into the inbox
folders; each event is dispatched to the appropriate normalizer.

Dispatch functions are injectable so tests can pass fakes without touching
the real normalizers.  The real defaults call the production normalizers.

Error handling: a failure on any single file is caught and logged — it
must never crash the watcher loop.

Debounce note: Markor writes a temp file (`.name.md.tmp`) then renames it
to the final name.  The handler reacts to both `on_created` and `on_moved`
(the rename event) so the final stable file is always processed.

Idempotency: `dispatch_android` checks for a `.processed.<name>` marker
before dispatching.  `markor.normalize` writes this marker on success, so
restarting the watcher never re-processes files that already landed in
`inbox/triaged/`.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from pathlib import Path

from watchdog.events import FileCreatedEvent, FileMovedEvent, FileSystemEventHandler
from watchdog.observers.polling import PollingObserver

from amie.config import Config
from amie.normalizers.markor import SecurityError
from amie.normalizers.markor import normalize as normalize_markor

logger = logging.getLogger(__name__)

# Image extensions the photo normalizer handles.
_PHOTO_SUFFIXES: frozenset[str] = frozenset({".jpg", ".jpeg", ".heic", ".png"})

DispatchFn = Callable[[Path, Config], None]


# ---------------------------------------------------------------------------
# Public dispatch functions — called by the watcher, mockable in tests.
# ---------------------------------------------------------------------------


def normalize_photo(source: Path, cfg: Config) -> None:
    from amie.normalizers.photo import normalize as _normalize_photo

    _normalize_photo(source, cfg)


def dispatch_android(source: Path, cfg: Config) -> None:
    """Dispatch a file that landed in inbox/android/.

    .md files → markor normalizer.
    Photo files (.jpg, .jpeg, .heic, .png) → moved into inbox/photos/ so the
    existing photos pipeline handles OCR.  The move is atomic (rename within
    the same vault filesystem) and a .processed marker is written in android/
    so a watcher restart never re-dispatches the same file.
    Dotfiles and already-processed files are skipped regardless of type.
    """
    if source.name.startswith("."):
        return
    if (source.parent / f".processed.{source.name}").exists():
        return
    suffix = source.suffix.lower()
    if suffix in _PHOTO_SUFFIXES:
        dest = cfg.photos_dir / source.name
        n = 1
        while dest.exists():
            dest = cfg.photos_dir / f"{source.stem}_{n}{source.suffix}"
            n += 1
        try:
            source.rename(dest)
            (source.parent / f".processed.{source.name}").write_text("")
        except OSError:
            logger.exception("failed to move android photo %s to photos/", source)
            return
        dispatch_photos(dest, cfg)
        return
    if suffix != ".md":
        return
    try:
        from amie.normalizers.photo import _default_ollama_chat

        normalize_markor(source, cfg, ollama_chat=_default_ollama_chat)
    except SecurityError:
        logger.warning("security violation in android file %s — skipping", source)
    except Exception:
        logger.exception("failed to normalize android file %s", source)


def dispatch_photos(source: Path, cfg: Config) -> None:
    """Dispatch a file that landed in inbox/photos/."""
    if source.suffix.lower() not in _PHOTO_SUFFIXES:
        return
    if source.name.startswith("."):
        return
    if (source.parent / f".processed.{source.name}").exists():
        return
    try:
        normalize_photo(source, cfg)
    except Exception:
        logger.exception("failed to normalize photo %s", source)


# ---------------------------------------------------------------------------
# Watchdog event handler
# ---------------------------------------------------------------------------


class _InboxEventHandler(FileSystemEventHandler):
    def __init__(
        self,
        android_dir: Path,
        photos_dir: Path,
        cfg: Config,
        android_dispatch: DispatchFn,
        photos_dispatch: DispatchFn,
    ) -> None:
        super().__init__()
        self._android_dir = android_dir
        self._photos_dir = photos_dir
        self._cfg = cfg
        self._android_dispatch = android_dispatch
        self._photos_dispatch = photos_dispatch

    def handle_path(self, path: Path) -> None:
        if path.is_relative_to(self._android_dir):
            self._android_dispatch(path, self._cfg)
        elif path.is_relative_to(self._photos_dir):
            self._photos_dispatch(path, self._cfg)

    def on_created(self, event: FileCreatedEvent) -> None:
        if not event.is_directory:
            self.handle_path(Path(event.src_path))

    def on_moved(self, event: FileMovedEvent) -> None:
        if not event.is_directory:
            self.handle_path(Path(event.dest_path))


# ---------------------------------------------------------------------------
# Watcher — public API
# ---------------------------------------------------------------------------


class Watcher:
    """Manages the watchdog observer over the inbox folders.

    Inject `android_dispatch` / `photos_dispatch` to override the real
    normalizers — used by tests.
    """

    def __init__(
        self,
        cfg: Config,
        *,
        android_dispatch: DispatchFn = dispatch_android,
        photos_dispatch: DispatchFn = dispatch_photos,
    ) -> None:
        self._cfg = cfg
        self._handler = _InboxEventHandler(
            android_dir=cfg.android_dir,
            photos_dir=cfg.photos_dir,
            cfg=cfg,
            android_dispatch=android_dispatch,
            photos_dispatch=photos_dispatch,
        )
        self._observer = PollingObserver()
        self._observer.schedule(self._handler, str(cfg.inbox_dir), recursive=True)

    def start(self) -> None:
        self._process_existing_files()
        self._observer.start()
        logger.info(
            "watching  android=%s  photos=%s",
            self._cfg.android_dir,
            self._cfg.photos_dir,
        )
        self._start_heartbeat()

    def stop(self) -> None:
        self._observer.stop()
        if self._observer.is_alive():
            self._observer.join(timeout=5)
        logger.info("watcher stopped")

    def _start_heartbeat(self, interval: int = 300) -> None:  # pragma: no cover
        """Log a heartbeat every *interval* seconds so the process is visibly alive."""

        def _beat() -> None:
            while self._observer.is_alive():
                time.sleep(interval)
                if self._observer.is_alive():
                    logger.info("still watching — inbox=%s", self._cfg.inbox_dir)

        threading.Thread(target=_beat, daemon=True, name="amie-heartbeat").start()

    def _process_existing_files(self) -> None:
        """Dispatch any files already in the inbox dirs before the observer starts.

        Covers the gap where files arrive while the watcher is not running.
        """
        for inbox_dir in (self._cfg.android_dir, self._cfg.photos_dir):
            if inbox_dir.is_dir():
                for path in sorted(inbox_dir.iterdir()):
                    self._handler.handle_path(path)
