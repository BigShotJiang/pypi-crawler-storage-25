from setuptools import setup
setup(
    name="sortsW",
    version="1.0.1",
    packages=["sortsW"],
    python_requires=">=3.13,<3.14",
)