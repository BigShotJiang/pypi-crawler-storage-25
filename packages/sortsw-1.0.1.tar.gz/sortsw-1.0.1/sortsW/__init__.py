class sorts():
    def __init__(self):
        pass
    def quick_sort(self, arr):
        if len(arr) <= 1:
            return arr
        pivot = arr[len(arr) // 2]
        left = [x for x in arr if x < pivot]
        middle = [x for x in arr if x == pivot]
        right = [x for x in arr if x > pivot]
        return self.quick_sort(left) + middle + self.quick_sort(right)
    def selection_sort(self, arr):
        arr = arr.copy()
        n = len(arr)
        for i in range(n - 1):
            min_index = i
            for j in range(i + 1, n):
                if arr[j] < arr[min_index]:
                    min_index = j
            if min_index != i:
                arr[i], arr[min_index] = arr[min_index], arr[i]
        return arr
    def bubble_sort(self, arr):
        arr = arr.copy()
        for i in range(0, len(arr)-1):
            for j in range(0, len(arr)-1-i):
                if arr[j] > arr[j+1]:
                    arr[j], arr[j+1] = arr[j+1], arr[j]
        return arr
    def insertion_sort(self, arr):
        arr = arr.copy()
        for i in range(1, len(arr)):
                key = arr[i]
                j = i - 1
                while j >= 0 and arr[j] > key:
                    arr[j + 1] = arr[j]
                    j -= 1
                arr[j + 1] = key
        return arr
    def check_sorts(self, arr):
        if self.quick_sort(arr) == self.selection_sort(arr) == self.bubble_sort(arr) == self.insertion_sort(arr):
            return True
        else:
            return False
if __name__ == "__main__":
    s = sorts()
    arr = [3, 1, 4, 1, 5, 9, 2, 6]
    print(s.quick_sort(arr)) 
    print(s.selection_sort(arr))
    print(s.bubble_sort(arr))
    print(s.insertion_sort(arr))
    print(s.check_sorts(arr))