from typing import Any, Type, Dict, get_origin, get_args, Union, List, Tuple, Annotated, _TypedDictMeta, Literal
from typing import get_type_hints
from pytastic.exceptions import SchemaDefinitionError
from pytastic.utils import parse_constraints, ConstraintNode, LeafConstraint, ConditionalConstraint, OrConstraint, NotConstraint
import math 
import re

try:
    from typing import NotRequired, Required
except ImportError:
    try:
        from typing_extensions import NotRequired, Required
    except ImportError:
        NotRequired = Required = object() # Fallback


class CodegenCompiler:
    """Generates optimized Python validation functions from type schemas."""
    def __init__(self):
        self._cache: Dict[tuple, Any] = {}
        self._counter = 0
        self._patterns: Dict[str, 're.Pattern'] = {}
        self._pattern_counter = 0
        self._getters: Dict[str, Any] = {}
        self._setters: Dict[str, Any] = {}
        self._defaults: Dict[str, Any] = {}

    def compile(self, schema: Type, strip: bool = False, partial: Union[bool, frozenset] = False, exclude_unset: bool = False, exclude_none: bool = False, getters: Dict[str, Any] = None, setters: Dict[str, Any] = None) -> Any:
        """Compiles a schema into a fast validation function."""
        if getters:
            self._getters = getters
        if setters:
            self._setters = setters

        cache_key = (schema, strip, partial, exclude_unset, exclude_none)
        if cache_key in self._cache:
            return self._cache[cache_key]

        self._defaults = {}
        schema_name = getattr(schema, '__name__', f'Schema{self._counter}')
        self._counter += 1

        code_lines = []
        code_lines.append(f"def validate_{schema_name}(data, path='', context=None):")

        body_lines = self._generate_validator(schema, 'data', 'path', 'context', indent=1, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path="")
        code_lines.extend(body_lines)
        code_lines.append("    return data")

        code = '\n'.join(code_lines)

        # Inject getters/setters/defaults into namespace with prefixed names
        getter_ns = {f'_getter_{k}': v for k, v in self._getters.items()}
        setter_ns = {f'_setter_{k}': v for k, v in self._setters.items()}

        namespace = {
            'ValidationError': __import__('pytastic.exceptions', fromlist=['ValidationError']).ValidationError,
            'SchemaDefinitionError': __import__('pytastic.exceptions', fromlist=['SchemaDefinitionError']).SchemaDefinitionError,
            're': __import__('re'),
            'math': __import__('math'),
            **self._patterns,
            **getter_ns,
            **setter_ns,
            **self._defaults,
        }

        exec(code, namespace)
        validator_func = namespace[f'validate_{schema_name}']

        self._cache[cache_key] = validator_func
        # Clear per-compilation defaults for next compile
        self._defaults = {}
        return validator_func

    def _coerce_default(self, raw_value: Any, field_type: Type) -> Any:
        """Coerce a default value string to the field's base type."""
        # Unwrap Annotated to get the base type
        if get_origin(field_type) is Annotated:
            field_type = get_args(field_type)[0]
        # Unwrap NotRequired/Required
        origin = get_origin(field_type)
        if origin in (NotRequired, Required):
            field_type = get_args(field_type)[0]
            if get_origin(field_type) is Annotated:
                field_type = get_args(field_type)[0]

        if isinstance(raw_value, str):
            if field_type is int:
                return int(raw_value)
            elif field_type is float:
                return float(raw_value)
            elif field_type is bool:
                return raw_value.lower() in ('true', '1', 'yes')
            elif field_type is str:
                return raw_value
            elif field_type is list or get_origin(field_type) is list:
                import json
                try:
                    return json.loads(raw_value)
                except (json.JSONDecodeError, ValueError):
                    return raw_value
        return raw_value

    def _generate_validator(self, schema: Type, var_name: str, path_var: str, context_var: str, indent: int, strip: bool = False, partial: Union[bool, frozenset] = False, exclude_unset: bool = False, exclude_none: bool = False, current_path: str = "") -> List[str]:
        """Generate validation code for a schema type."""
        origin = get_origin(schema)
        args = get_args(schema)
        ind = '    ' * indent
        lines = []

        if origin is Annotated:
            base_type = args[0]
            constraint_str = ''
            for arg in args[1:]:
                if isinstance(arg, str):
                    constraint_str += arg + ';'
            parsed = parse_constraints(constraint_str)

            constraints = {}
            wrappers = []

            if isinstance(parsed, dict):
                constraints = parsed
            else:
                for node in parsed:
                    if isinstance(node, LeafConstraint):
                        constraints[node.key] = node.value
                    else:
                        wrappers.append(node)

            # Generate base validation
            base_lines = []
            base_origin = get_origin(base_type)

            if base_type is int or base_type is float:
                base_lines = self._gen_number(var_name, path_var, base_type, constraints, indent)
            elif base_type is str:
                base_lines = self._gen_string(var_name, path_var, constraints, indent)
            elif self._is_typeddict(base_type):
                base_lines = self._gen_object(base_type, var_name, path_var, context_var, constraints, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)
            elif base_origin is list or base_origin is List:
                inner_type = get_args(base_type)[0] if get_args(base_type) else Any
                base_lines = self._gen_list(var_name, path_var, context_var, inner_type, constraints, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)
            elif base_origin is tuple or base_origin is Tuple:
                inner_types = get_args(base_type)
                base_lines = self._gen_tuple(var_name, path_var, context_var, inner_types, constraints, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)
            elif base_origin is Union:
                union_types = get_args(base_type)
                one_of = bool(constraints.pop('one_of', False))
                base_lines = self._gen_union(var_name, path_var, context_var, union_types, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path, one_of=one_of)
            elif base_origin is dict or base_type is dict:
                base_args = get_args(base_type)
                key_type = base_args[0] if base_args else Any
                value_type = base_args[1] if len(base_args) > 1 else Any
                base_lines = self._gen_dict(var_name, path_var, context_var, key_type, value_type, constraints, indent)

            lines.extend(base_lines)

            # Wrappers applied AFTER base type checks (AND logic)
            for wrapper in wrappers:
                lines.extend(self._gen_complex_node(wrapper, var_name, path_var, context_var, base_type, indent))

            return lines

        if self._is_typeddict(schema):
            constraints = {}
            if hasattr(schema, '__annotations__') and '_' in schema.__annotations__:
                 meta_annotation = schema.__annotations__.get('_', None)
                 if meta_annotation and get_origin(meta_annotation) is Annotated:
                     meta_args = get_args(meta_annotation)
                     constraint_str = ""
                     for arg in meta_args[1:]:
                        if isinstance(arg, str):
                            constraint_str += arg + ";"
                     parsed = parse_constraints(constraint_str)
                     if isinstance(parsed, dict):
                         constraints.update(parsed)
            if strip and 'strip' not in constraints:
                constraints['strip'] = 'True'
            if partial is True and 'partial' not in constraints:
                constraints['partial'] = 'True'
            return self._gen_object(schema, var_name, path_var, context_var, constraints, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)

        if origin is list or origin is List:
            inner_type = args[0] if args else Any
            return self._gen_list(var_name, path_var, context_var, inner_type, {}, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)

        if origin is tuple or origin is Tuple:
            return self._gen_tuple(var_name, path_var, context_var, args, {}, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)

        if origin is Union:
            return self._gen_union(var_name, path_var, context_var, args, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)

        if origin is dict:
            key_type = args[0] if args else Any
            value_type = args[1] if len(args) > 1 else Any
            return self._gen_dict(var_name, path_var, context_var, key_type, value_type, {}, indent)

        if schema is dict:
            return self._gen_dict(var_name, path_var, context_var, Any, Any, {}, indent)

        if origin is Literal:
            return self._gen_literal(var_name, path_var, args, indent)

        if schema is int or schema is float:
            return self._gen_number(var_name, path_var, schema, {}, indent)

        if schema is str:
            return self._gen_string(var_name, path_var, {}, indent)

        if schema is bool:
            lines.append(f"{ind}# bool validation (passthrough)")
            lines.append(f"{ind}if not isinstance({var_name}, bool):")
            lines.append(f"{ind}    raise ValidationError(f'Expected bool at {{{path_var}}}, got {{type({var_name}).__name__}}', [{{'path': {path_var}, 'message': f'Expected bool, got {{type({var_name}).__name__}}'}}])")

        if schema is type(None):
            lines.append(f"{ind}if {var_name} is not None:")
            lines.append(f"{ind}    raise ValidationError(f'Expected None at {{{path_var}}}', [{{'path': {path_var}, 'message': 'Must be None'}}])")

        if origin is NotRequired or origin is Required:
            return self._generate_validator(args[0], var_name, path_var, context_var, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)

        return lines

    def _gen_complex_node(self, node: ConstraintNode, var: str, path: str, context: str, base_type: Type, indent: int) -> List[str]:
        ind = '    ' * indent
        lines = []

        if isinstance(node, ConditionalConstraint):
            lines.append(f"{ind}# Conditional Check: {node.condition}")
            key, val = node.condition.split('==')
            key = key.strip()
            val = val.strip()

            lines.append(f"{ind}_cond_match = False")
            lines.append(f"{ind}if isinstance({context}, dict):")
            lines.append(f"{ind}    _cond_ctx_val = {context}.get('{key}')")
            lines.append(f"{ind}    if str(_cond_ctx_val) == '{val}':")
            lines.append(f"{ind}        _cond_match = True")

            lines.append(f"{ind}if _cond_match:")
            if isinstance(node.constraint, LeafConstraint):
                 c = {node.constraint.key: node.constraint.value}
                 if base_type is int or base_type is float:
                     lines.extend(self._gen_number(var, path, base_type, c, indent + 1))
                 elif base_type is str:
                     lines.extend(self._gen_string(var, path, c, indent + 1))
            else:
                 lines.extend(self._gen_complex_node(node.constraint, var, path, context, base_type, indent + 1))

        elif isinstance(node, NotConstraint):
            lines.append(f"{ind}# NOT Check")
            lines.append(f"{ind}try:")
            if isinstance(node.constraint, LeafConstraint):
                 c = {node.constraint.key: node.constraint.value}
                 if base_type is int or base_type is float:
                     lines.extend(self._gen_number(var, path, base_type, c, indent + 1))
                 elif base_type is str:
                     lines.extend(self._gen_string(var, path, c, indent + 1))
            else:
                 lines.extend(self._gen_complex_node(node.constraint, var, path, context, base_type, indent + 1))
            lines.append(f"{ind}except ValidationError:")
            lines.append(f"{ind}    pass # Expected failure for NOT")
            lines.append(f"{ind}else:")
            lines.append(f"{ind}    raise ValidationError(f'NOT constraint failed at {{{path}}}', [{{'path': {path}, 'message': 'NOT check failed'}}])")

        elif isinstance(node, OrConstraint):
            lines.append(f"{ind}# OR Check")
            lines.append(f"{ind}_or_errors = []")
            lines.append(f"{ind}_or_success = False")

            for sub_node in node.constraints:
                lines.append(f"{ind}if not _or_success:")
                lines.append(f"{ind}    try:")
                if isinstance(sub_node, LeafConstraint):
                     c = {sub_node.key: sub_node.value}
                     if base_type is int or base_type is float:
                         lines.extend(self._gen_number(var, path, base_type, c, indent + 2))
                     elif base_type is str:
                         lines.extend(self._gen_string(var, path, c, indent + 2))
                else:
                     lines.extend(self._gen_complex_node(sub_node, var, path, context, base_type, indent + 2))
                lines.append(f"{ind}        _or_success = True")
                lines.append(f"{ind}    except ValidationError as e:")
                lines.append(f"{ind}        _or_errors.append(e)")

            lines.append(f"{ind}if not _or_success:")
            lines.append(f"{ind}    raise ValidationError(f'OR constraint failed at {{{path}}}', [{{'path': {path}, 'message': 'OR check failed'}}])")

        return lines

    def _gen_number(self, var: str, path: str, num_type: type, constraints: Dict, indent: int) -> List[str]:
        """Generate number validation code."""
        ind = '    ' * indent
        lines = []

        lines.append(f"{ind}if isinstance({var}, bool):")
        lines.append(f"{ind}    raise ValidationError(f'Expected number at {{{path}}}, got bool', [{{'path': {path}, 'message': 'Expected number, got bool'}}])")
        lines.append(f"{ind}if not isinstance({var}, (int, float)):")
        lines.append(f"{ind}    raise ValidationError(f'Expected number at {{{path}}}, got {{type({var}).__name__}}', [{{'path': {path}, 'message': f'Expected number, got {{type({var}).__name__}}'}}])")

        if num_type is int:
            lines.append(f"{ind}if isinstance({var}, float) and not {var}.is_integer():")
            lines.append(f"{ind}    raise ValidationError(f'Expected integer at {{{path}}}', [{{'path': {path}, 'message': 'Expected integer'}}])")

        if 'min' in constraints:
            min_val = float(constraints['min'])
            lines.append(f"{ind}if {var} < {min_val}:")
            lines.append(f"{ind}    raise ValidationError(f'Value {{{var}}} < {min_val} at {{{path}}}', [{{'path': {path}, 'message': 'Must be >= {min_val}'}}])")

        if 'max' in constraints:
            max_val = float(constraints['max'])
            lines.append(f"{ind}if {var} > {max_val}:")
            lines.append(f"{ind}    raise ValidationError(f'Value {{{var}}} > {max_val} at {{{path}}}', [{{'path': {path}, 'message': 'Must be <= {max_val}'}}])")

        if 'exclusive_min' in constraints:
            ex_min = float(constraints['exclusive_min'])
            lines.append(f"{ind}if {var} <= {ex_min}:")
            lines.append(f"{ind}    raise ValidationError(f'Value {{{var}}} <= {ex_min} at {{{path}}}', [{{'path': {path}, 'message': 'Must be > {ex_min}'}}])")

        if 'exclusive_max' in constraints:
            ex_max = float(constraints['exclusive_max'])
            lines.append(f"{ind}if {var} >= {ex_max}:")
            lines.append(f"{ind}    raise ValidationError(f'Value {{{var}}} >= {ex_max} at {{{path}}}', [{{'path': {path}, 'message': 'Must be < {ex_max}'}}])")

        step = constraints.get('step') or constraints.get('multiple_of')
        if step:
            step_val = float(step)
            lines.append(f"{ind}if not math.isclose({var} % {step_val}, 0, abs_tol=1e-9) and not math.isclose({var} % {step_val}, {step_val}, abs_tol=1e-9):")
            lines.append(f"{ind}    raise ValidationError(f'Value {{{var}}} is not a multiple of {step_val} at {{{path}}}', [{{'path': {path}, 'message': 'Must be multiple of {step_val}'}}])")

        return lines

    def _gen_string(self, var: str, path: str, constraints: Dict, indent: int) -> List[str]:
        """Generate string validation code."""
        ind = '    ' * indent
        lines = []

        lines.append(f"{ind}if not isinstance({var}, str):")
        lines.append(f"{ind}    raise ValidationError(f'Expected string at {{{path}}}, got {{type({var}).__name__}}', [{{'path': {path}, 'message': f'Expected string, got {{type({var}).__name__}}'}}])")

        min_len = constraints.get('min_length') or constraints.get('min_len')
        if min_len:
            min_len = int(min_len)
            lines.append(f"{ind}if len({var}) < {min_len}:")
            lines.append(f"{ind}    raise ValidationError(f'String too short at {{{path}}}', [{{'path': {path}, 'message': 'Min length {min_len}'}}])")

        max_len = constraints.get('max_length') or constraints.get('max_len')
        if max_len:
            max_len = int(max_len)
            lines.append(f"{ind}if len({var}) > {max_len}:")
            lines.append(f"{ind}    raise ValidationError(f'String too long at {{{path}}}', [{{'path': {path}, 'message': 'Max length {max_len}'}}])")

        pattern = constraints.get('regex') or constraints.get('pattern')
        if pattern:
            pat_name = f"_pat_{self._pattern_counter}"
            self._pattern_counter += 1
            self._patterns[pat_name] = re.compile(pattern)
            lines.append(f"{ind}if not {pat_name}.search({var}):")
            lines.append(f"{ind}    raise ValidationError(f'Pattern mismatch at {{{path}}}', [{{'path': {path}, 'message': 'Pattern mismatch'}}])")

        fmt = constraints.get('format')
        if fmt:
            if fmt == 'email':
                lines.append(f"{ind}if '@' not in {var}:")
                lines.append(f"{ind}    raise ValidationError('Invalid email format', [{{'path': {path}, 'message': 'Invalid email'}}])")
            elif fmt == 'uuid':
                uuid_pat = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
                lines.append(f"{ind}if not re.match(r'{uuid_pat}', {var}.lower()):")
                lines.append(f"{ind}    raise ValidationError('Invalid UUID format', [{{'path': {path}, 'message': 'Invalid UUID'}}])")
            elif fmt == 'ipv4':
                lines.append(f"{ind}is_valid_ipv4 = False")
                lines.append(f"{ind}try:")
                lines.append(f"{ind}    parts = {var}.split('.')")
                lines.append(f"{ind}    if len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):")
                lines.append(f"{ind}        is_valid_ipv4 = True")
                lines.append(f"{ind}except:")
                lines.append(f"{ind}    pass")
                lines.append(f"{ind}if not is_valid_ipv4:")
                lines.append(f"{ind}    raise ValidationError('Invalid IPv4 format', [{{'path': {path}, 'message': 'Invalid IPv4'}}])")
            elif fmt == 'date-time':
                 lines.append(f"{ind}if not re.match(r'^\\d{{4}}-\\d{{2}}-\\d{{2}}T\\d{{2}}:\\d{{2}}:\\d{{2}}', {var}):")
                 lines.append(f"{ind}    raise ValidationError('Invalid date-time format', [{{'path': {path}, 'message': 'Invalid date-time'}}])")
            elif fmt == 'uri':
                 lines.append(f"{ind}if not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', {var}):")
                 lines.append(f"{ind}    raise ValidationError('Invalid URI format', [{{'path': {path}, 'message': 'Invalid URI'}}])")

        return lines

    def _gen_object(self, td_cls: Type, var: str, path: str, context: str, constraints: Dict, indent: int, strip: bool = False, partial: Union[bool, frozenset] = False, exclude_unset: bool = False, exclude_none: bool = False, current_path: str = "") -> List[str]:
        """Generate object/TypedDict validation code."""
        # Check if this object itself has "partial=True" in its metadata or passed in constraints (legacy)
        obj_partial_flag = bool(constraints.get('partial'))

        ind = '    ' * indent
        lines = []

        lines.append(f"{ind}if not isinstance({var}, dict):")
        lines.append(f"{ind}    raise ValidationError(f'Expected dict at {{{path}}}, got {{type({var}).__name__}}', [{{'path': {path}, 'message': f'Expected dict, got {{type({var}).__name__}}'}}])")

        type_hints = get_type_hints(td_cls, include_extras=True)
        is_total = getattr(td_cls, '__total__', True)
        required_keys = getattr(td_cls, '__required_keys__', set(type_hints.keys()) if is_total else set())

        # We need to pass 'var' (the current dict) as 'context' to children
        child_context = var

        # Track fields that use 'from' so we can rebuild dict keys properly
        has_field_mapping = False

        for key, field_type in type_hints.items():
            if key == '_':
                continue

            field_var = f"{var}__{key}"

            # Construct dot-notation path for this field
            field_dot_path = f"{current_path}.{key}" if current_path else key

            # Extract from/getter/setter/default from field-level Annotated metadata
            field_from = None
            field_getter = None
            field_setter = None
            field_default = None
            has_default = False
            # Unwrap NotRequired/Required to reach Annotated layer
            meta_type = field_type
            if get_origin(meta_type) in (NotRequired, Required):
                meta_type = get_args(meta_type)[0]
            if get_origin(meta_type) is Annotated:
                f_args = get_args(meta_type)
                f_constraint_str = ''
                for f_arg in f_args[1:]:
                    if isinstance(f_arg, str):
                        f_constraint_str += f_arg + ';'
                if f_constraint_str:
                    f_parsed = parse_constraints(f_constraint_str)
                    if isinstance(f_parsed, dict):
                        field_from = f_parsed.pop('from', None)
                        field_getter = f_parsed.pop('getter', None)
                        field_setter = f_parsed.pop('setter', None)
                        # Also pop alias — it's only used for dump(), not validation
                        f_parsed.pop('alias', None)
                        if 'default' in f_parsed:
                            has_default = True
                            field_default = self._coerce_default(f_parsed.pop('default'), field_type)

            if field_getter and field_from:
                raise SchemaDefinitionError(f"Field '{key}' cannot have both 'getter' and 'from' — getter already reads from the full input dict")

            if field_from:
                has_field_mapping = True

            # The input key to read from
            input_key = field_from or key

            # Determine if this specific field is partial
            is_field_partial = False
            if partial is True or obj_partial_flag:
                is_field_partial = True
            elif isinstance(partial, frozenset) and field_dot_path in partial:
                is_field_partial = True

            is_required = key in required_keys and not is_field_partial

            # Inject default value into namespace if needed
            if has_default:
                default_ns_name = f"_default_{key}"
                self._defaults[default_ns_name] = field_default

            saved_indent = indent

            if field_getter:
                # Getter: compute value from full input dict
                getter_ns_name = f"_getter_{field_getter}"
                if is_required and not has_default:
                    lines.append(f"{ind}{field_var} = {getter_ns_name}({var})")
                else:
                    lines.append(f"{ind}try:")
                    lines.append(f"{ind}    {field_var} = {getter_ns_name}({var})")
                    lines.append(f"{ind}except (KeyError, TypeError, IndexError):")
                    if has_default:
                        lines.append(f"{ind}    {field_var} = _default_{key}")
                    else:
                        lines.append(f"{ind}    {field_var} = None")
                    lines.append(f"{ind}if {field_var} is not None:")
                    indent += 1
                    ind = '    ' * indent
            elif is_required and not has_default:
                # Required fields with no default must check for key existence
                lines.append(f"{ind}if '{input_key}' not in {var}:")
                lines.append(f"{ind}    raise ValidationError(f'Missing field {key} at {{{path}}}', [{{'path': {path} + '.{key}', 'message': 'Required'}}])")
                lines.append(f"{ind}{field_var} = {var}['{input_key}']")
            elif has_default:
                if exclude_unset:
                    # Only process if key was actually provided in input
                    lines.append(f"{ind}if '{input_key}' in {var}:")
                    indent += 1
                    ind = '    ' * indent
                    lines.append(f"{ind}{field_var} = {var}['{input_key}']")
                    # Explicit None: skip validation but preserve the key
                    lines.append(f"{ind}if {field_var} is not None:")
                    indent += 1
                    ind = '    ' * indent
                else:
                    # Backward compatible: absent or None triggers default
                    lines.append(f"{ind}{field_var} = {var}.get('{input_key}')")
                    lines.append(f"{ind}if {field_var} is None:")
                    lines.append(f"{ind}    {field_var} = _default_{key}")
                    # Still need to write back the default into the dict so it appears in output
                    lines.append(f"{ind}    {var}['{key}'] = {field_var}")
            else:
                # Optional field, no default — use 'in' to distinguish absent from explicit None
                lines.append(f"{ind}if '{input_key}' in {var}:")
                indent += 1
                ind = '    ' * indent
                lines.append(f"{ind}{field_var} = {var}['{input_key}']")
                lines.append(f"{ind}if {field_var} is not None:")
                indent += 1
                ind = '    ' * indent

            # Setter: transform value before validation
            if field_setter:
                setter_ns_name = f"_setter_{field_setter}"
                lines.append(f"{ind}{field_var} = {setter_ns_name}({field_var})")

            field_path = f"{path} + '.{key}'" if path != "''" else f"'{key}'"
            field_lines = self._generate_validator(field_type, field_var, field_path, child_context, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=field_dot_path)
            lines.extend(field_lines)

            # Always write back to the TypedDict key name (not the source key)
            if strip or field_from or field_getter or field_setter:
                lines.append(f"{ind}{var}['{key}'] = {field_var}")
                # Remove the old source key if it differs from the output key
                if field_from:
                    lines.append(f"{ind}if '{field_from}' in {var} and '{field_from}' != '{key}':")
                    lines.append(f"{ind}    del {var}['{field_from}']")

            indent = saved_indent
            ind = '    ' * indent

        if constraints.get('strict') or constraints.get('additional_properties') is False:
             lines.append(f"{ind}known_keys = set({repr(list(type_hints.keys()))}) - {{'_'}}")
             lines.append(f"{ind}extra_keys = set({var}.keys()) - known_keys")
             lines.append(f"{ind}if extra_keys:")
             lines.append(f"{ind}    raise ValidationError(f'Extra fields not allowed at {{{path}}}: {{extra_keys}}', [{{'path': {path}, 'message': 'Extra fields not allowed'}}])")

        if constraints.get('strip'):
             known = [k for k in type_hints if k != '_']
             lines.append(f"{ind}{var} = {{k: {var}[k] for k in {repr(known)} if k in {var}}}")

        if exclude_none:
             lines.append(f"{ind}for _nk in [k for k in {var} if {var}[k] is None]:")
             lines.append(f"{ind}    del {var}[_nk]")

        min_props = constraints.get('min_properties') or constraints.get('min_props')
        if min_props:
             min_props_val = int(min_props)
             lines.append(f"{ind}if len({var}) < {min_props_val}:")
             lines.append(f"{ind}    raise ValidationError(f'Too few properties at {{{path}}}', [{{'path': {path}, 'message': 'Min properties {min_props_val}'}}])")

        max_props = constraints.get('max_properties') or constraints.get('max_props')
        if max_props:
             max_props_val = int(max_props)
             lines.append(f"{ind}if len({var}) > {max_props_val}:")
             lines.append(f"{ind}    raise ValidationError(f'Too many properties at {{{path}}}', [{{'path': {path}, 'message': 'Max properties {max_props_val}'}}])")

        return lines

    def _gen_dict(self, var: str, path: str, context: str, key_type: Type, value_type: Type, constraints: Dict, indent: int) -> List[str]:
        """Generate dict validation code for Dict[K, V] or bare dict."""
        ind = '    ' * indent
        lines = []

        lines.append(f"{ind}if not isinstance({var}, dict):")
        lines.append(f"{ind}    raise ValidationError(f'Expected dict at {{{path}}}, got {{type({var}).__name__}}', [{{'path': {path}, 'message': f'Expected dict, got {{type({var}).__name__}}'}}])")

        # If key/value types are specified (not Any), validate each entry
        if key_type is not Any or value_type is not Any:
            k_var = f"_dk_{indent}"
            v_var = f"_dv_{indent}"
            lines.append(f"{ind}for {k_var}, {v_var} in {var}.items():")
            k_path = f"{path} + f'.{{' + k_var + '}}'"
            if key_type is not Any:
                key_lines = self._generate_validator(key_type, k_var, k_path, context, indent + 1)
                lines.extend(key_lines)
            if value_type is not Any:
                value_lines = self._generate_validator(value_type, v_var, k_path, context, indent + 1)
                lines.extend(value_lines)

        return lines

    def _gen_list(self, var: str, path: str, context: str, item_type: Type, constraints: Dict, indent: int, strip: bool = False, partial: Union[bool, frozenset] = False, exclude_unset: bool = False, exclude_none: bool = False, current_path: str = "") -> List[str]:
        """Generate list validation code."""
        ind = '    ' * indent
        lines = []

        lines.append(f"{ind}if not isinstance({var}, (list, tuple)):")
        lines.append(f"{ind}    raise ValidationError(f'Expected list at {{{path}}}, got {{type({var}).__name__}}', [{{'path': {path}, 'message': f'Expected list, got {{type({var}).__name__}}'}}])")

        min_items = constraints.get('min_items')
        if min_items:
            min_items_val = int(min_items)
            lines.append(f"{ind}if len({var}) < {min_items_val}:")
            lines.append(f"{ind}    raise ValidationError(f'Too few items at {{{path}}}', [{{'path': {path}, 'message': 'Min {min_items_val} items'}}])")

        max_items = constraints.get('max_items')
        if max_items:
            max_items_val = int(max_items)
            lines.append(f"{ind}if len({var}) > {max_items_val}:")
            lines.append(f"{ind}    raise ValidationError(f'Too many items at {{{path}}}', [{{'path': {path}, 'message': 'Max {max_items_val} items'}}])")

        if constraints.get('unique'):
            lines.append(f"{ind}if len({var}) != len(set({var})):")
            lines.append(f"{ind}    raise ValidationError(f'Duplicate items found at {{{path}}}', [{{'path': {path}, 'message': 'Duplicate items found'}}])")

        idx_var = f"_idx_{indent}"
        item_var = f"_item_{indent}"

        lines.append(f"{ind}for {idx_var}, {item_var} in enumerate({var}):")
        item_path = f"{path} + f'[{{{idx_var}}}]'"
        # Let's pass 'context' variable (which is parent of list)
        item_lines = self._generate_validator(item_type, item_var, item_path, context, indent + 1, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)
        lines.extend(item_lines)

        if strip:
            inner_ind = '    ' * (indent + 1)
            lines.append(f"{inner_ind}{var}[{idx_var}] = {item_var}")

        contains_val = constraints.get('contains')
        if contains_val:
            contains_type = Annotated[item_type, contains_val]
            contains_item_var = f"_contains_item_{indent}"
            contains_flag_var = f"_contains_found_{indent}"
            lines.append(f"{ind}{contains_flag_var} = False")
            lines.append(f"{ind}for {contains_item_var} in {var}:")
            inner_ind = '    ' * (indent + 1)
            lines.append(f"{inner_ind}try:")
            contains_lines = self._generate_validator(contains_type, contains_item_var, path, context, indent + 2, strip=False, partial=False, current_path=current_path)
            lines.extend(contains_lines)
            lines.append(f"{inner_ind}    {contains_flag_var} = True")
            lines.append(f"{inner_ind}    break")
            lines.append(f"{inner_ind}except ValidationError:")
            lines.append(f"{inner_ind}    continue")
            lines.append(f"{ind}if not {contains_flag_var}:")
            lines.append(f"{ind}    raise ValidationError(f'List does not contain required item at {{{path}}}', [{{'path': {path}, 'message': 'Contains check failed'}}])")

        return lines

    def _gen_union(self, var: str, path: str, context: str, types: Tuple, indent: int, strip: bool = False, partial: Union[bool, frozenset] = False, exclude_unset: bool = False, exclude_none: bool = False, current_path: str = "", one_of: bool = False) -> List[str]:
        """Generate union validation code."""
        ind = '    ' * indent
        lines = []

        lines.append(f"{ind}_union_match = False")
        lines.append(f"{ind}_union_errors = []")

        if one_of:
            lines.append(f"{ind}_union_match_count = 0")

            for i, union_type in enumerate(types):
                lines.append(f"{ind}try:")
                type_lines = self._generate_validator(union_type, var, path, context, indent + 1, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)
                lines.extend(type_lines)
                lines.append(f"{ind}    _union_match = True")
                lines.append(f"{ind}    _union_match_count += 1")
                lines.append(f"{ind}except ValidationError as _e:")
                lines.append(f"{ind}    _union_errors.append(_e)")

            lines.append(f"{ind}if _union_match_count != 1:")
            lines.append(f"{ind}    if _union_match_count == 0:")
            lines.append(f"{ind}        raise ValidationError(f'No oneOf match at {{{path}}}', [{{'path': {path}, 'message': 'No match'}}])")
            lines.append(f"{ind}    else:")
            lines.append(f"{ind}        raise ValidationError(f'Multiple oneOf matches at {{{path}}}', [{{'path': {path}, 'message': 'Multiple matches'}}])")
        else:
            for i, union_type in enumerate(types):
                lines.append(f"{ind}if not _union_match:")
                lines.append(f"{ind}    try:")
                type_lines = self._generate_validator(union_type, var, path, context, indent + 2, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)
                lines.extend(type_lines)
                lines.append(f"{ind}        _union_match = True")
                lines.append(f"{ind}    except ValidationError as _e:")
                lines.append(f"{ind}        _union_errors.append(_e)")

            lines.append(f"{ind}if not _union_match:")
            lines.append(f"{ind}    raise ValidationError(f'No union match at {{{path}}}', [{{'path': {path}, 'message': 'No match'}}])")

        return lines

    def _gen_tuple(self, var: str, path: str, context: str, item_types: Tuple[Type, ...], constraints: Dict, indent: int, strip: bool = False, partial: Union[bool, frozenset] = False, exclude_unset: bool = False, exclude_none: bool = False, current_path: str = "") -> List[str]:
        """Generate tuple validation code."""
        ind = '    ' * indent
        lines = []

        lines.append(f"{ind}if not isinstance({var}, (list, tuple)):")
        lines.append(f"{ind}    raise ValidationError(f'Expected tuple at {{{path}}}, got {{type({var}).__name__}}', [{{'path': {path}, 'message': f'Expected tuple, got {{type({var}).__name__}}'}}])")

        expected_len = len(item_types)
        lines.append(f"{ind}if len({var}) != {expected_len}:")
        lines.append(f"{ind}    raise ValidationError(f'Expected {expected_len} items at {{{path}}}', [{{'path': {path}, 'message': 'Expected {expected_len} items'}}])")

        for i, item_type in enumerate(item_types):
            item_path = f"{path} + f'[{i}]'"
            # Tuple items are accessed by index
            # We need to assign to a temp var to be safe for recursive validation
            temp_var = f"_tuple_item_{indent}_{i}"
            lines.append(f"{ind}{temp_var} = {var}[{i}]")

            item_lines = self._generate_validator(item_type, temp_var, item_path, context, indent, strip=strip, partial=partial, exclude_unset=exclude_unset, exclude_none=exclude_none, current_path=current_path)
            lines.extend(item_lines)

        return lines

    def _gen_literal(self, var: str, path: str, values: Tuple, indent: int) -> List[str]:
        """Generate literal validation code."""
        ind = '    ' * indent
        lines = []
        
        allowed = list(values)
        lines.append(f"{ind}_allowed = {repr(allowed)}")
        lines.append(f"{ind}if {var} not in _allowed:")
        lines.append(f"{ind}    raise ValidationError(f'Invalid literal value at {{{path}}}', [{{'path': {path}, 'message': 'Must be one of ' + str(_allowed)}}])")
        
        return lines
    
    def _is_typeddict(self, t: Type) -> bool:
        """Check if type is a TypedDict."""
        return isinstance(t, _TypedDictMeta) or (isinstance(t, type) and issubclass(t, dict) and hasattr(t, '__annotations__'))
