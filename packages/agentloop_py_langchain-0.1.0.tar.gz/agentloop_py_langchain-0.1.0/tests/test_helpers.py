"""Tests for the extraction helpers — these are the parts most likely to
break across LangChain versions, so we test them independently of any
real langchain install.
"""

from __future__ import annotations

from types import SimpleNamespace

from agentloop_langchain._helpers import (
    extract_answer_from_response,
    extract_question_from_prompts,
    merge_options,
)


# ---------------------------------------------------------------------------
# extract_question_from_prompts
# ---------------------------------------------------------------------------


def _msg(type_: str, content):
    return SimpleNamespace(type=type_, content=content)


def test_extract_question_chat_messages_simple():
    messages = [[_msg("system", "be helpful"), _msg("human", "what's the pix limit")]]
    assert extract_question_from_prompts(None, messages) == "what's the pix limit"


def test_extract_question_chat_uses_last_human():
    # Last human (not last message) is what we want
    messages = [[
        _msg("human", "first question"),
        _msg("ai", "first answer"),
        _msg("human", "follow-up question"),
        _msg("ai", "second answer"),
    ]]
    # Should pick the most recent human message
    assert extract_question_from_prompts(None, messages) == "follow-up question"


def test_extract_question_chat_falls_back_to_last_when_no_human():
    messages = [[_msg("system", "preamble only")]]
    assert extract_question_from_prompts(None, messages) == "preamble only"


def test_extract_question_text_completion_prompts():
    prompts = ["context: blah\nquestion: what's the limit?"]
    assert extract_question_from_prompts(prompts, None) == \
        "context: blah\nquestion: what's the limit?"


def test_extract_question_handles_multipart_content():
    multipart = [{"type": "text", "text": "what's "}, {"type": "text", "text": "the limit?"}]
    messages = [[_msg("human", multipart)]]
    assert extract_question_from_prompts(None, messages) == "what's \nthe limit?"


def test_extract_question_skips_image_parts():
    multipart = [
        {"type": "text", "text": "describe this"},
        {"type": "image_url", "image_url": {"url": "..."}},
    ]
    messages = [[_msg("human", multipart)]]
    assert extract_question_from_prompts(None, messages) == "describe this"


def test_extract_question_empty_inputs():
    assert extract_question_from_prompts(None, None) == ""
    assert extract_question_from_prompts([], []) == ""
    assert extract_question_from_prompts(None, [[]]) == ""


def test_extract_question_class_name_fallback():
    # A subclass without .type attribute — fallback uses class name
    class HumanMessage:
        def __init__(self, content):
            self.content = content
    messages = [[HumanMessage("hello")]]
    assert extract_question_from_prompts(None, messages) == "hello"


# ---------------------------------------------------------------------------
# extract_answer_from_response
# ---------------------------------------------------------------------------


def test_extract_answer_chat_generation():
    # ChatGeneration: has .message.content
    gen = SimpleNamespace(message=SimpleNamespace(content="the answer"))
    response = SimpleNamespace(generations=[[gen]])
    assert extract_answer_from_response(response) == "the answer"


def test_extract_answer_text_generation():
    # Generation: has .text
    gen = SimpleNamespace(text="text-completion answer", message=None)
    response = SimpleNamespace(generations=[[gen]])
    assert extract_answer_from_response(response) == "text-completion answer"


def test_extract_answer_empty_generations():
    response = SimpleNamespace(generations=[])
    assert extract_answer_from_response(response) == ""


def test_extract_answer_multipart_content():
    multipart = [{"type": "text", "text": "part 1"}, {"type": "text", "text": "part 2"}]
    gen = SimpleNamespace(message=SimpleNamespace(content=multipart))
    response = SimpleNamespace(generations=[[gen]])
    assert extract_answer_from_response(response) == "part 1\npart 2"


def test_extract_answer_handles_garbage():
    assert extract_answer_from_response(None) == ""
    assert extract_answer_from_response(SimpleNamespace()) == ""
    assert extract_answer_from_response("string") == ""


# ---------------------------------------------------------------------------
# merge_options
# ---------------------------------------------------------------------------


def test_merge_options_per_call_overrides_default():
    defaults = {"user_id": "u_default", "tags": ["beta"]}
    metadata = {"agentloop": {"user_id": "u_per_call"}}
    out = merge_options(defaults, metadata)
    assert out["user_id"] == "u_per_call"
    assert out["tags"] == ["beta"]


def test_merge_options_metadata_with_no_agentloop_block():
    defaults = {"user_id": "u_default"}
    metadata = {"some_other": "data"}
    assert merge_options(defaults, metadata) == {"user_id": "u_default"}


def test_merge_options_none_inputs():
    assert merge_options(None, None) == {}
    assert merge_options({}, {"agentloop": {"user_id": "x"}}) == {"user_id": "x"}


def test_merge_options_doesnt_overwrite_with_none():
    defaults = {"user_id": "u_default"}
    metadata = {"agentloop": {"user_id": None}}  # explicit None should NOT clobber
    assert merge_options(defaults, metadata) == {"user_id": "u_default"}
