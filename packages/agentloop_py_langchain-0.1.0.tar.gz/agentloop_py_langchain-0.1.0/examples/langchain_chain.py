"""
Minimal LangChain integration example.

Run with:
    pip install agentloop-py agentloop-py-langchain langchain-openai
    export OPENAI_API_KEY=...
    export AGENTLOOP_API_KEY=ak_live_...
    python langchain_chain.py

Demonstrates the full pattern:
1. AgentLoopMemoryInjector retrieves relevant past corrections (the magic)
2. ChatPromptTemplate uses {agentloop_memories} as a slot
3. AgentLoopCallbackHandler logs the turn for review afterwards

The result: your reviewers' corrections automatically improve future
answers without any retraining or prompt engineering on your end.
"""

import os

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from agentloop import AgentLoop
from agentloop_langchain import (
    AgentLoopCallbackHandler,
    AgentLoopMemoryInjector,
)


def main() -> None:
    loop = AgentLoop(api_key=os.environ["AGENTLOOP_API_KEY"])

    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            "You are a helpful assistant for a Brazilian fintech support team.\n\n"
            "Use these trusted facts from past corrections (if relevant):\n"
            "{agentloop_memories}",
        ),
        ("user", "{question}"),
    ])

    llm = ChatOpenAI(model="gpt-4o-mini").with_config(
        callbacks=[AgentLoopCallbackHandler(loop=loop)],
    )

    chain = (
        AgentLoopMemoryInjector(loop=loop, query_field="question")
        | prompt
        | llm
        | StrOutputParser()
    )

    answer = chain.invoke(
        {"question": "What's the Pix limit at night?"},
        config={"metadata": {"agentloop": {"user_id": "u_demo"}}},
    )
    print("Answer:", answer)
    print()
    print("Now check the AgentLoop dashboard — this turn is in the review queue.")
    print("Correct it (if needed) and the next time a similar question comes")
    print("through, the corrected fact will be injected into the prompt.")


if __name__ == "__main__":
    main()
