"""
Helpers shared between the callback handler and the memory injector.

Most of the complexity here is dealing with LangChain's heterogeneous
prompt/message representations: chat models pass List[List[BaseMessage]],
text completion models pass List[str], some chains pass kwargs in
different shapes. We normalize everything to a single string for the
question / response.
"""

from __future__ import annotations

from typing import Any


def extract_question_from_prompts(
    prompts: list[Any] | None,
    messages: list[list[Any]] | None = None,
) -> str:
    """Pull the user question out of LangChain's `on_llm_start` / `on_chat_model_start` payload.

    Prefers the last *human* message when available (chat models). For
    text-completion models that pass `prompts: list[str]`, returns the
    last prompt as-is. Returns "" when nothing usable is found — caller
    should treat that as "skip this turn."
    """
    # Chat models call on_chat_model_start with messages: List[List[BaseMessage]]
    # The outer list is "one entry per request in the batch", inner list is
    # the conversation. We assume batch size 1 (the common case).
    if messages:
        try:
            convo = messages[0] if messages else []
            for msg in reversed(convo):
                msg_type = _message_type(msg)
                if msg_type == "human":
                    return _message_text(msg)
            # No human message — fall back to last message of any type
            if convo:
                return _message_text(convo[-1])
        except (IndexError, AttributeError, TypeError):
            pass

    # Text-completion models call on_llm_start with prompts: List[str]
    if prompts:
        try:
            return prompts[-1] if isinstance(prompts[-1], str) else str(prompts[-1])
        except (IndexError, TypeError):
            pass

    return ""


def extract_answer_from_response(response: Any) -> str:
    """Pull the assistant's text out of an LLMResult.

    LLMResult.generations is List[List[Generation]] — outer list per-input,
    inner list per-completion (usually 1 unless n>1). We take the first
    generation of the first input.
    """
    try:
        generations = getattr(response, "generations", None)
        if not generations or not generations[0]:
            return ""

        gen = generations[0][0]

        # ChatGeneration has .message.content; Generation has .text.
        # Prefer .message.content because it preserves typed message info,
        # but fall back gracefully.
        message = getattr(gen, "message", None)
        if message is not None:
            content = getattr(message, "content", None)
            if isinstance(content, str):
                return content
            # Multi-part content (tool calls, images): concat text parts only
            if isinstance(content, list):
                parts = []
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        parts.append(part.get("text", ""))
                    elif isinstance(part, str):
                        parts.append(part)
                return "\n".join(parts)

        text = getattr(gen, "text", None)
        if isinstance(text, str):
            return text
    except (AttributeError, IndexError, TypeError):
        pass
    return ""


def merge_options(
    handler_defaults: dict[str, Any] | None,
    metadata: dict[str, Any] | None,
) -> dict[str, Any]:
    """Resolve effective per-call options from handler defaults + metadata.

    Per-call values from `config={"metadata": {"agentloop": {...}}}`
    override handler-construction defaults. Returns a dict with
    user_id, session_id, signals, tags, skip — any of which may be None
    or absent.
    """
    out: dict[str, Any] = dict(handler_defaults or {})
    per_call = (metadata or {}).get("agentloop") or {}
    if isinstance(per_call, dict):
        for k, v in per_call.items():
            if v is not None:
                out[k] = v
    return out


# ---------------------------------------------------------------------------
# Internal — message-type detection across langchain-core versions
# ---------------------------------------------------------------------------
#
# LangChain has shuffled the BaseMessage class hierarchy a few times. We
# avoid hard-importing HumanMessage/AIMessage so this module loads even
# on minor langchain-core versions that change the import path. Detection
# uses the .type attribute (always present on BaseMessage subclasses)
# plus a class-name fallback.


def _message_type(msg: Any) -> str:
    """Return 'human', 'ai', 'system', 'function', 'tool', or '' (unknown)."""
    t = getattr(msg, "type", None)
    if isinstance(t, str) and t:
        return t.lower()
    cls = type(msg).__name__.lower()
    if "human" in cls:
        return "human"
    if "ai" in cls or "assistant" in cls:
        return "ai"
    if "system" in cls:
        return "system"
    return ""


def _message_text(msg: Any) -> str:
    """Pull text content from any BaseMessage variant."""
    content = getattr(msg, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for part in content:
            if isinstance(part, dict) and part.get("type") == "text":
                parts.append(part.get("text", ""))
            elif isinstance(part, str):
                parts.append(part)
        return "\n".join(parts)
    return ""
