"""
LangChain callback handler that auto-logs every LLM turn to AgentLoop.

Limitation by design: by the time `on_llm_start` fires, LangChain has
already finalized the prompt and is sending it to the LLM provider.
We can OBSERVE the prompt but cannot MODIFY it. Therefore the callback
handler does NOT perform memory injection — see `AgentLoopMemoryInjector`
for that, which lives upstream in the chain where it can actually
mutate the prompt.

The callback handler captures (question, response) on every successful
LLM call and posts to /v1/turns. On errors, it skips logging entirely
(we don't have a useful response to log).

Both sync and async are supported. Apps using `chain.invoke(...)` get
the sync handler; apps using `chain.ainvoke(...)` get the async one.
"""

from __future__ import annotations

import logging
import threading
from typing import Any
from uuid import UUID

from langchain_core.callbacks import (
    AsyncCallbackHandler,
    BaseCallbackHandler,
)

from ._helpers import (
    extract_answer_from_response,
    extract_question_from_prompts,
    merge_options,
)

logger = logging.getLogger("agentloop.langchain")


# We track in-flight calls by run_id so we can correlate the prompt
# (captured at on_*_start) with the response (captured at on_llm_end).
# LangChain hands us a UUID per LLM call. We index a small per-handler
# dict on it. Cleared on success, error, or end.
_RUN_QUESTIONS_LIMIT = 1000  # bound memory if a chain leaks runs


class AgentLoopCallbackHandler(BaseCallbackHandler):
    """Synchronous callback handler. Use for `chain.invoke(...)` flows.

    Construction:

        loop = AgentLoop(api_key="ak_...")
        handler = AgentLoopCallbackHandler(loop=loop, user_id="u_42")

        chain = prompt | llm.with_config(callbacks=[handler])

    Per-call options can override the construction-time defaults:

        result = chain.invoke(
            {"question": "..."},
            config={"metadata": {"agentloop": {"user_id": "u_99",
                                               "signals": {"thumbs_down": True}}}},
        )

    Accepted per-call keys: user_id, session_id, signals, tags, skip.
    `skip=True` short-circuits the handler entirely for that call.
    """

    # We claim to be the LangChain handler, not "verbose" — important so
    # LangChain's internal output formatting doesn't double up.
    raise_error: bool = False

    def __init__(
        self,
        *,
        loop: Any,
        user_id: str | None = None,
        session_id: str | None = None,
        signals: dict[str, Any] | None = None,
        tags: list[str] | None = None,
    ) -> None:
        """
        loop:       an AgentLoop instance (sync). Required.
        user_id:    default user_id for log_turn calls
        session_id: default session_id for log_turn calls
        signals:    default signals dict (merged with per-call signals)
        tags:       default tags list (merged with per-call tags)
        """
        super().__init__()
        if loop is None:
            raise ValueError("loop is required")
        self.loop = loop
        self._defaults: dict[str, Any] = {}
        if user_id is not None:
            self._defaults["user_id"] = user_id
        if session_id is not None:
            self._defaults["session_id"] = session_id
        if signals is not None:
            self._defaults["signals"] = dict(signals)
        if tags is not None:
            self._defaults["tags"] = list(tags)

        # run_id (UUID) -> question text. Bounded by _RUN_QUESTIONS_LIMIT.
        self._questions: dict[UUID, str] = {}
        # Same shape, holds resolved per-call options for the run.
        self._opts: dict[UUID, dict[str, Any]] = {}
        self._lock = threading.Lock()

    # --- LangChain interface --------------------------------------------------

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Text-completion model started — capture the prompt."""
        self._capture_start(run_id=run_id, prompts=prompts, messages=None,
                            metadata=metadata)

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Chat model started — capture the last human message as question."""
        self._capture_start(run_id=run_id, prompts=None, messages=messages,
                            metadata=metadata)

    def on_llm_end(self, response: Any, *, run_id: UUID, **kwargs: Any) -> Any:
        """LLM call finished — log the (question, response) pair."""
        try:
            with self._lock:
                question = self._questions.pop(run_id, "")
                opts = self._opts.pop(run_id, {})

            if not question or opts.get("skip"):
                return

            answer = extract_answer_from_response(response)
            if not answer:
                return

            # log_turn already swallows network errors silently when
            # throw_on_error=False (default). We still wrap to defend
            # against unexpected exception types.
            try:
                self.loop.log_turn(
                    question=question,
                    agent_response=answer,
                    user_id=opts.get("user_id"),
                    session_id=opts.get("session_id"),
                    signals=opts.get("signals"),
                    metadata=_build_log_metadata(opts),
                )
            except Exception as e:  # noqa: BLE001
                logger.warning("agentloop log_turn failed: %s", e)
        except Exception as e:  # noqa: BLE001
            # Belt-and-suspenders: a broken handler must NEVER fail the chain.
            logger.warning("agentloop on_llm_end error: %s", e)

    def on_llm_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> Any:
        """LLM call errored — drop the captured prompt; nothing useful to log."""
        with self._lock:
            self._questions.pop(run_id, None)
            self._opts.pop(run_id, None)

    # --- Internal -------------------------------------------------------------

    def _capture_start(
        self,
        *,
        run_id: UUID,
        prompts: list[str] | None,
        messages: list[list[Any]] | None,
        metadata: dict[str, Any] | None,
    ) -> None:
        try:
            question = extract_question_from_prompts(prompts, messages)
            opts = merge_options(self._defaults, metadata)
            with self._lock:
                # Bound memory in case a misbehaving chain never calls
                # on_llm_end. Drop the oldest entry rather than refusing
                # to capture a new one.
                if len(self._questions) >= _RUN_QUESTIONS_LIMIT:
                    try:
                        oldest = next(iter(self._questions))
                        self._questions.pop(oldest, None)
                        self._opts.pop(oldest, None)
                    except StopIteration:
                        pass
                self._questions[run_id] = question
                self._opts[run_id] = opts
        except Exception as e:  # noqa: BLE001
            logger.warning("agentloop on_*_start error: %s", e)


class AsyncAgentLoopCallbackHandler(AsyncCallbackHandler):
    """Asynchronous callback handler. Use for `chain.ainvoke(...)` flows.

    Construct with an AsyncAgentLoop (from `agentloop.aio`), or a sync
    AgentLoop — in the latter case we run log_turn on a thread-pool
    executor to avoid blocking the event loop.

        from agentloop.aio import AsyncAgentLoop
        from agentloop_langchain import AsyncAgentLoopCallbackHandler

        async with AsyncAgentLoop(api_key="ak_...") as loop:
            handler = AsyncAgentLoopCallbackHandler(loop=loop)
            ...
    """

    raise_error: bool = False

    def __init__(
        self,
        *,
        loop: Any,
        user_id: str | None = None,
        session_id: str | None = None,
        signals: dict[str, Any] | None = None,
        tags: list[str] | None = None,
    ) -> None:
        super().__init__()
        if loop is None:
            raise ValueError("loop is required")
        self.loop = loop
        # Cache whether the loop has an async log_turn at construction time
        # so we don't introspect it on every call.
        self._is_async_loop = _looks_async(loop)

        self._defaults: dict[str, Any] = {}
        if user_id is not None:
            self._defaults["user_id"] = user_id
        if session_id is not None:
            self._defaults["session_id"] = session_id
        if signals is not None:
            self._defaults["signals"] = dict(signals)
        if tags is not None:
            self._defaults["tags"] = list(tags)

        # Async handlers may run on different event loops concurrently;
        # asyncio doesn't multi-thread but a Lock prevents weird interleaving
        # if someone uses the handler across loops.
        import asyncio
        self._questions: dict[UUID, str] = {}
        self._opts: dict[UUID, dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    async def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        await self._capture_start(run_id=run_id, prompts=prompts, messages=None,
                                  metadata=metadata)

    async def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:
        await self._capture_start(run_id=run_id, prompts=None, messages=messages,
                                  metadata=metadata)

    async def on_llm_end(self, response: Any, *, run_id: UUID, **kwargs: Any) -> Any:
        try:
            async with self._lock:
                question = self._questions.pop(run_id, "")
                opts = self._opts.pop(run_id, {})

            if not question or opts.get("skip"):
                return

            answer = extract_answer_from_response(response)
            if not answer:
                return

            try:
                if self._is_async_loop:
                    await self.loop.log_turn(
                        question=question,
                        agent_response=answer,
                        user_id=opts.get("user_id"),
                        session_id=opts.get("session_id"),
                        signals=opts.get("signals"),
                        metadata=_build_log_metadata(opts),
                    )
                else:
                    # Sync loop in async context — dispatch to default executor
                    # so we don't block the event loop on the HTTP call.
                    import asyncio
                    await asyncio.get_event_loop().run_in_executor(
                        None,
                        lambda: self.loop.log_turn(
                            question=question,
                            agent_response=answer,
                            user_id=opts.get("user_id"),
                            session_id=opts.get("session_id"),
                            signals=opts.get("signals"),
                            metadata=_build_log_metadata(opts),
                        ),
                    )
            except Exception as e:  # noqa: BLE001
                logger.warning("agentloop log_turn failed (async): %s", e)
        except Exception as e:  # noqa: BLE001
            logger.warning("agentloop on_llm_end (async) error: %s", e)

    async def on_llm_error(
        self, error: BaseException, *, run_id: UUID, **kwargs: Any
    ) -> Any:
        async with self._lock:
            self._questions.pop(run_id, None)
            self._opts.pop(run_id, None)

    async def _capture_start(
        self,
        *,
        run_id: UUID,
        prompts: list[str] | None,
        messages: list[list[Any]] | None,
        metadata: dict[str, Any] | None,
    ) -> None:
        try:
            question = extract_question_from_prompts(prompts, messages)
            opts = merge_options(self._defaults, metadata)
            async with self._lock:
                if len(self._questions) >= _RUN_QUESTIONS_LIMIT:
                    try:
                        oldest = next(iter(self._questions))
                        self._questions.pop(oldest, None)
                        self._opts.pop(oldest, None)
                    except StopIteration:
                        pass
                self._questions[run_id] = question
                self._opts[run_id] = opts
        except Exception as e:  # noqa: BLE001
            logger.warning("agentloop on_*_start (async) error: %s", e)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_log_metadata(opts: dict[str, Any]) -> dict[str, Any] | None:
    """Bundle non-first-class options into the log_turn metadata field.

    The backend stores arbitrary metadata, but tags / source_framework
    are searchable / filterable, so we lift them to top-level inside
    metadata. Custom user metadata is preserved verbatim.
    """
    md: dict[str, Any] = {"source": "langchain"}
    if "tags" in opts and opts["tags"]:
        md["tags"] = list(opts["tags"])
    user_md = opts.get("metadata")
    if isinstance(user_md, dict):
        # User metadata wins — they may want to override even our 'source'.
        md.update(user_md)
    return md


def _looks_async(loop: Any) -> bool:
    """Best-effort detect: is `loop.log_turn` a coroutine function?

    We don't import AsyncAgentLoop here to avoid a hard dep on the
    'aio' submodule's import path (which has shifted before).
    """
    import inspect
    fn = getattr(loop, "log_turn", None)
    if fn is None:
        return False
    return inspect.iscoroutinefunction(fn)
