"""
Memory injector — the part of the LangChain integration that gives you
the same "agent benefits from past corrections immediately" experience
the OpenAI/Anthropic wrappers provide.

The callback handler can only OBSERVE the prompt (it runs after LangChain
has finalized it). The injector runs UPSTREAM in the chain — it modifies
the input that the prompt template will see — so it can actually shape
what the LLM receives.

Two ways to use it:

1. As a Runnable in your chain (recommended)

       from agentloop_langchain import AgentLoopMemoryInjector
       from langchain_core.prompts import ChatPromptTemplate

       prompt = ChatPromptTemplate.from_messages([
           ("system", "You are a helpful assistant.\\n\\n"
                      "Trusted facts from past corrections:\\n{agentloop_memories}"),
           ("user", "{question}"),
       ])

       chain = (
           AgentLoopMemoryInjector(loop=loop, query_field="question")
           | prompt
           | llm.with_config(callbacks=[AgentLoopCallbackHandler(loop=loop)])
       )

       chain.invoke({"question": "What's the Pix limit at night?"})

2. As a callable (if you're not using LCEL composition)

       enriched = inject_memories({"question": "..."}, loop=loop)
       result = chain.invoke(enriched)

In both cases the injector adds a key to the input dict (default name:
`agentloop_memories`) containing a formatted string of relevant past
corrections. Your prompt template references that key with `{agentloop_memories}`.
If no memories match, the field is empty string — your prompt should
handle that case gracefully (the default formatter returns "(none yet)"
when memories list is empty, so something always renders).
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from langchain_core.runnables import RunnableLambda

logger = logging.getLogger("agentloop.langchain")


def default_format_memories(memories: list[Any]) -> str:
    """Default rendering: bulleted list of `.fact` strings, or '(none yet)'.

    Customize by passing your own `format_memories` to the injector.
    Useful when you want different framing for different domains (e.g.
    "Known facts", "Customer-specific notes", "Approved responses only").
    """
    if not memories:
        return "(none yet)"
    return "\n".join(f"- {getattr(m, 'fact', '')}" for m in memories if getattr(m, 'fact', None))


class AgentLoopMemoryInjector(RunnableLambda):
    """LCEL Runnable that retrieves AgentLoop memories and adds them to the input.

    Construct with:

        injector = AgentLoopMemoryInjector(
            loop=loop,                  # required
            query_field="question",     # which input key to search on
            output_field="agentloop_memories",  # where to put the formatted string
            limit=3,                    # how many memories to retrieve
            tags=["pix"],               # optional tag filter on search
            format_memories=None,       # optional custom formatter
            user_id_field="user_id",    # optional input key for per-user search
        )

    The injector reads `input[query_field]` and writes to
    `input[output_field]`, leaving every other input key untouched. Use
    `{agentloop_memories}` in your prompt template to reference the
    retrieved facts.

    Failure mode: if AgentLoop is unreachable or returns an error, the
    injector logs a warning and returns the input unchanged with
    `output_field` set to "(none yet)". The chain continues normally —
    the LLM just doesn't get any retrieved facts for that call.
    """

    def __init__(
        self,
        *,
        loop: Any,
        query_field: str = "question",
        output_field: str = "agentloop_memories",
        limit: int = 3,
        tags: list[str] | None = None,
        user_id_field: str | None = None,
        format_memories: Callable[[list[Any]], str] | None = None,
    ) -> None:
        if loop is None:
            raise ValueError("loop is required")
        self.loop = loop
        self.query_field = query_field
        self.output_field = output_field
        self.limit = limit
        self.tags = list(tags) if tags else None
        self.user_id_field = user_id_field
        self.format_memories = format_memories or default_format_memories

        # RunnableLambda needs a callable. We pass our bound _invoke and
        # also _ainvoke for async support. RunnableLambda inspects whether
        # the callable is a coroutine to decide which path to use.
        super().__init__(self._invoke, afunc=self._ainvoke)

    # --- sync ----------------------------------------------------------------

    def _invoke(self, input: Any, config: dict | None = None) -> Any:
        """Sync invocation — calls loop.search() inline."""
        if not isinstance(input, dict):
            # Non-dict input: nothing for us to enrich. Pass through.
            return input

        query = input.get(self.query_field, "")
        if not isinstance(query, str) or not query.strip():
            # No query in input — leave the field empty string so the
            # prompt template doesn't blow up on a missing key.
            return {**input, self.output_field: self.format_memories([])}

        user_id = None
        if self.user_id_field:
            user_id = input.get(self.user_id_field)

        try:
            memories = self.loop.search(
                query=query,
                limit=self.limit,
                tags=self.tags,
                user_id=user_id,
            )
        except Exception as e:  # noqa: BLE001
            logger.warning("agentloop search failed: %s", e)
            memories = []

        return {**input, self.output_field: self.format_memories(memories)}

    # --- async ---------------------------------------------------------------

    async def _ainvoke(self, input: Any, config: dict | None = None) -> Any:
        """Async invocation — uses AsyncAgentLoop if available, else thread pool."""
        if not isinstance(input, dict):
            return input

        query = input.get(self.query_field, "")
        if not isinstance(query, str) or not query.strip():
            return {**input, self.output_field: self.format_memories([])}

        user_id = None
        if self.user_id_field:
            user_id = input.get(self.user_id_field)

        # Detect whether loop.search is a coroutine
        import inspect
        is_async = inspect.iscoroutinefunction(getattr(self.loop, "search", None))

        try:
            if is_async:
                memories = await self.loop.search(
                    query=query,
                    limit=self.limit,
                    tags=self.tags,
                    user_id=user_id,
                )
            else:
                # Sync client in async chain — run on default executor to
                # avoid blocking the event loop.
                import asyncio
                memories = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: self.loop.search(
                        query=query,
                        limit=self.limit,
                        tags=self.tags,
                        user_id=user_id,
                    ),
                )
        except Exception as e:  # noqa: BLE001
            logger.warning("agentloop search failed (async): %s", e)
            memories = []

        return {**input, self.output_field: self.format_memories(memories)}


# ---------------------------------------------------------------------------
# Functional shortcut — for the "I'm not using LCEL composition" case
# ---------------------------------------------------------------------------


def inject_memories(
    input: dict,
    *,
    loop: Any,
    query_field: str = "question",
    output_field: str = "agentloop_memories",
    limit: int = 3,
    tags: list[str] | None = None,
    user_id_field: str | None = None,
    format_memories: Callable[[list[Any]], str] | None = None,
) -> dict:
    """Imperative version of AgentLoopMemoryInjector.

    Useful when you're calling the LLM directly (not through an LCEL
    chain) but still want the search step:

        enriched = inject_memories({"question": q}, loop=loop)
        prompt_text = template.format(**enriched)
        response = llm.invoke(prompt_text)
        loop.log_turn(question=q, agent_response=response.content)
    """
    injector = AgentLoopMemoryInjector(
        loop=loop,
        query_field=query_field,
        output_field=output_field,
        limit=limit,
        tags=tags,
        user_id_field=user_id_field,
        format_memories=format_memories,
    )
    return injector._invoke(input)
