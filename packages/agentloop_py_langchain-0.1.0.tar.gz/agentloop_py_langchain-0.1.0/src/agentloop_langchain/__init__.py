"""
agentloop-py-langchain — LangChain integration for AgentLoop.

The full integration:

    from agentloop import AgentLoop
    from agentloop_langchain import (
        AgentLoopCallbackHandler,
        AgentLoopMemoryInjector,
    )
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_openai import ChatOpenAI

    loop = AgentLoop(api_key="ak_...")

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful assistant.\\n\\n"
                   "Trusted facts from past corrections:\\n{agentloop_memories}"),
        ("user", "{question}"),
    ])

    llm = ChatOpenAI(model="gpt-4o").with_config(
        callbacks=[AgentLoopCallbackHandler(loop=loop)],  # logging
    )

    chain = (
        AgentLoopMemoryInjector(loop=loop, query_field="question")  # retrieval
        | prompt
        | llm
    )

    chain.invoke({"question": "What's the Pix limit at night?"})

The injector retrieves relevant memories before the LLM call (the magic).
The callback handler logs the turn after for review (the housekeeping).
Together they replicate the experience of `wrap_openai` / `wrap_anthropic`
inside the LangChain composition model.

Per-call options via metadata:

    chain.invoke(
        {"question": "..."},
        config={"metadata": {"agentloop": {
            "user_id": "u_42",
            "session_id": "sess_xyz",
            "signals": {"thumbs_down": True},
        }}},
    )
"""

from ._callback import AgentLoopCallbackHandler, AsyncAgentLoopCallbackHandler
from ._injector import (
    AgentLoopMemoryInjector,
    default_format_memories,
    inject_memories,
)

__all__ = [
    # Logging (after the LLM call)
    "AgentLoopCallbackHandler",
    "AsyncAgentLoopCallbackHandler",
    # Retrieval (before the LLM call) — the magic
    "AgentLoopMemoryInjector",
    "inject_memories",
    "default_format_memories",
]

__version__ = "0.1.0"
