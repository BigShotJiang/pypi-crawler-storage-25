# Changelog

All notable changes to `palveron-langchain` will be documented in this file.

This project follows [Semantic Versioning](https://semver.org/).

## [1.0.0] — 2026-05-17

### Added
- Initial public release of `palveron-langchain` on PyPI
- `PalveronCallbackHandler` — drop-in `BaseCallbackHandler` that runs every
  LangChain LLM call through the Palveron gateway before the model sees it
- Automatic blocking of disallowed prompts, with the policy reason
  surfaced as a LangChain `ValueError`
- Automatic PII masking of inputs and outputs when the gateway returns
  `decision="MODIFIED"`
- Trace ID propagation onto each `LLMResult` for cross-system audit
- Compatible with the synchronous `Palveron` and the async `AsyncPalveron`
  clients from `palveron-sdk`
- Full type hints (PEP 561 compliant via `py.typed`)
