"""
AgentGuard(TM) Spend — Core SDK entry point

`with_spend_guard()` wraps a provider SDK client (OpenAI, Anthropic, Bedrock)
and enforces a SpendPolicy locally before each call is sent to the provider.

Design rule: ZERO DATA PLANE INVOLVEMENT.
  - Prompts never leave the customer process.
  - Provider API keys never leave the customer process.
  - The signing key never leaves the customer process.
  - All decisions and the entire signed log live in the customer's storage.

Patent notice: Protected by U.S. patent-pending technology
(App. Nos. 63/983,615; 63/983,621; 63/983,843; 63/984,626;
64/071,781; 64/071,789).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional, Union

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from .decision_log import (
    GENESIS_PREVIOUS_HASH,
    InMemoryDecisionLogStore,
    sign_decision,
)
from .policy import evaluate_policy
from .store_memory import InMemorySpendStore
from .types import (
    CallContext,
    CapabilityTier,
    DecisionLogStore,
    SignedDecisionLogEntry,
    SpendDecision,
    SpendPolicy,
    SpendScope,
    SpendStore,
)

OnDecisionHook = Callable[
    [SpendDecision, Optional[SignedDecisionLogEntry]],
    Union[None, Awaitable[None]],
]


@dataclass
class SigningKeys:
    """32-byte Ed25519 secret seed + 32-byte public key.

    Both can be raw bytes or pre-built cryptography objects. The seed never
    leaves the customer environment.
    """

    privateKey: Union[bytes, Ed25519PrivateKey]
    publicKey: Union[bytes, Ed25519PublicKey]


@dataclass
class SpendGuardConfig:
    """Configuration for an AgentGuard Spend instance.

    `policy` is required at construction unless using the SpendGuard
    constructor with a policy kwarg.
    """

    policy: SpendPolicy
    spendStore: Optional[SpendStore] = None
    logStore: Optional[DecisionLogStore] = None
    signingKeys: Optional[SigningKeys] = None
    onDecision: Optional[OnDecisionHook] = None
    tokenEstimator: Optional[Callable[[str], int]] = None


def _format_cents(cents: int) -> str:
    """Format integer cents as $X,XXX.XX (US locale)."""
    sign = "-" if cents < 0 else ""
    cents = abs(cents)
    dollars, remainder = divmod(cents, 100)
    return f"{sign}${dollars:,}.{remainder:02d}"


def _window_label(window: str, locale: Optional[str] = None) -> str:
    from .i18n import t
    key = {
        "per_call": "window_per_call",
        "per_minute": "window_per_minute",
        "per_hour": "window_per_hour",
        "per_day": "window_per_day",
        "per_month": "window_per_month",
    }.get(window)
    return t(key, locale) if key else window


def format_blocked_trace(
    decision: SpendDecision,
    scope: SpendScope,
    locale: Optional[str] = None,
) -> str:
    """Multi-line formatted trace matching agentguard.run/the-block/.

    Includes the saved-amount line when a cap is breached. Localized via
    the i18n module — pass `locale="es-419"` or `locale="pt-BR"` to
    override the auto-detected locale.

    ANSI color (TTY-only, honors NO_COLOR=1 and AGENTGUARD_COLOR=0) is
    applied to BLOCKED, saved amount, checkmarks, and field labels.
    """
    from .i18n import t
    from .cli.colors import red_bold, green_bold, green, dim

    cap = decision.triggeredCap
    agent_id = scope.agentId or scope.userId or scope.tenantId or "unknown"
    if cap is not None:
        cap_str = f"{_format_cents(cap.amountCents)} / {_window_label(cap.window, locale)}"
        saved_cents = max(
            0,
            decision.projectedCents
            - max(0, cap.amountCents - decision.windowSpendBefore),
        )
    else:
        cap_str = "n/a"
        saved_cents = 0

    amount_str = _format_cents(decision.projectedCents)
    reasons_str = "; ".join(decision.reasons) if decision.reasons else t("reasons_none", locale)

    # Field labels right-padded so values align across all locales.
    field_agent = t("field_agent", locale)
    field_provider = t("field_provider", locale)
    field_amount = t("field_amount", locale)
    field_cap = t("field_cap", locale)
    field_status = t("field_status", locale)
    field_saved = t("field_saved", locale)
    label_width = max(len(field_agent), len(field_provider), len(field_amount),
                      len(field_cap), len(field_status), len(field_saved)) + 2

    lines = [
        t("blocked_header", locale),
        "",
        f"  {dim(field_agent.ljust(label_width))}{agent_id}",
        f"  {dim(field_provider.ljust(label_width))}{decision.provider}",
        f"  {dim(field_amount.ljust(label_width))}{amount_str}",
        f"  {dim(field_cap.ljust(label_width))}{cap_str}",
        f"  {dim(field_status.ljust(label_width))}{red_bold(t('status_blocked', locale))}",
        "",
        f"  {dim(field_saved.ljust(label_width))}{green_bold('+' + _format_cents(saved_cents))}",
        "",
        f"  {green('✓')} {t('check_cap_enforced', locale)}",
        f"  {green('✓')} {t('check_receipt', locale)}",
        f"  {green('✓')} {t('check_provider_never_charged', locale)}",
        "",
        f"{dim(t('field_policy', locale) + ':')} {decision.policyId}",
        f"{dim(t('field_reasons', locale) + ':')} {reasons_str}",
    ]
    return "\n".join(lines)


class AgentGuardBlockedError(Exception):
    """Raised when a call is blocked by the policy.

    The message is a multi-line formatted trace matching the marketing
    screenshot at agentguard.run/the-block/. Programmatic callers should
    use `error.decision` for structured access. The trace is localized
    in en-US, es-419, and pt-BR; pass `locale` to override auto-detection.
    """

    def __init__(
        self,
        decision: SpendDecision,
        scope: Optional[SpendScope] = None,
        locale: Optional[str] = None,
    ) -> None:
        self.decision = decision
        self.scope = scope or SpendScope(tenantId="unknown")
        self.locale = locale
        super().__init__(format_blocked_trace(decision, self.scope, locale))


class SpendGuard:
    """Per-policy guard instance.

    Holds the chain pointer (sequence number + previous hash) and routes
    every decided call through the policy engine and the signed decision
    log.
    """

    def __init__(self, config: SpendGuardConfig) -> None:
        self._config = config
        self._spend_store: SpendStore = config.spendStore or InMemorySpendStore()
        self._log_store: DecisionLogStore = config.logStore or InMemoryDecisionLogStore()
        self._next_sequence = 0
        self._previous_hash = GENESIS_PREVIOUS_HASH

    async def hydrate(self) -> None:
        """Hydrate the chain pointer from the log store.

        Call this once at startup if the log store is persistent and may
        already contain entries from a previous run.
        """
        latest = await self._log_store.get_latest()
        if latest is not None:
            self._next_sequence = latest.sequence + 1
            self._previous_hash = latest.entryHash

    async def decide(
        self, call: CallContext
    ) -> tuple[SpendDecision, Optional[SignedDecisionLogEntry]]:
        """Evaluate the policy for a call and append to the decision log.

        Returns the decision plus the signed log entry (or None if unsigned).
        """
        decision = await evaluate_policy(self._config.policy, call, self._spend_store)
        signed: Optional[SignedDecisionLogEntry] = None
        if self._config.signingKeys is not None:
            keys = self._config.signingKeys
            signed = await sign_decision(
                sequence=self._next_sequence,
                decision=decision,
                previous_hash=self._previous_hash,
                private_key=keys.privateKey,
                public_key=keys.publicKey,
            )
            await self._log_store.append(signed)
            self._next_sequence += 1
            self._previous_hash = signed.entryHash

        if self._config.onDecision is not None:
            result = self._config.onDecision(decision, signed)
            # Allow either sync or async hooks
            if result is not None and hasattr(result, "__await__"):
                await result  # type: ignore[func-returns-value]

        return decision, signed

    def _default_token_estimator(self, text: str) -> int:
        return math.ceil(len(text) / 4)

    def estimate_tokens(self, text: str) -> int:
        """Estimate tokens for a string using the configured estimator.

        Default: approximately 1 token per 4 characters of English text.
        """
        fn = self._config.tokenEstimator or self._default_token_estimator
        return fn(text)

    @property
    def spend_store(self) -> SpendStore:
        """Expose the spend store for tests and dashboards."""
        return self._spend_store

    @property
    def log_store(self) -> DecisionLogStore:
        """Expose the log store for tests and dashboards."""
        return self._log_store


# ---------------------------------------------------------------------------
# Drop-in wrapper for provider SDK clients
# ---------------------------------------------------------------------------


@dataclass
class BindingOptions:
    """Options for wrapping a provider SDK client.

    Equivalent to OpenAIBindingOptions in the TypeScript SDK.
    """

    policy: SpendPolicy
    scope: SpendScope
    capabilityClaim: Optional[CapabilityTier] = None
    config: Optional[SpendGuardConfig] = None


def _serialize_messages(messages: Any) -> str:
    if not isinstance(messages, (list, tuple)):
        return ""
    out: list[str] = []
    for m in messages:
        content = None
        if isinstance(m, dict):
            content = m.get("content")
        else:
            content = getattr(m, "content", None)
        if isinstance(content, str):
            out.append(content)
        else:
            try:
                import json as _json
                out.append(_json.dumps(content if content is not None else ""))
            except Exception:
                out.append(str(content) if content is not None else "")
    return "\n".join(out)


def with_spend_guard(
    client: Any,
    *,
    policy: SpendPolicy,
    scope: SpendScope,
    capabilityClaim: Optional[CapabilityTier] = None,
    config: Optional[SpendGuardConfig] = None,
) -> Any:
    """Drop-in wrapper for an OpenAI v1+ client.

    Returns a proxy whose `chat.completions.create` enforces the spend
    policy. Other endpoints pass through untouched in this alpha; subsequent
    releases will cover responses, embeddings, and images.

    Usage:
        from openai import OpenAI
        from agentguard_spend import with_spend_guard, SpendPolicy, SpendScope

        openai_client = OpenAI()
        policy = SpendPolicy(...)
        guarded = with_spend_guard(
            openai_client,
            policy=policy,
            scope=SpendScope(tenantId="acme", userId="alice"),
        )
        completion = guarded.chat.completions.create(model="gpt-4o", messages=[...])
    """
    # Lazy import to avoid pulling in the OpenAI binding for users of the
    # core SDK. Anthropic/Bedrock callers should use their specific bindings.
    from .bindings.openai_binding import with_openai_spend_guard

    return with_openai_spend_guard(
        client,
        policy=policy,
        scope=scope,
        capabilityClaim=capabilityClaim,
        config=config,
    )
