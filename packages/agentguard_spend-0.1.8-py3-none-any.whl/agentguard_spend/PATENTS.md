# Patent Notice

`agentguard-spend` (Python) is protected by U.S. patent-pending technology, including the
following provisional patent applications filed with the United States Patent and
Trademark Office by Dunecrest Ventures Inc.:

| Application No. | Filing Date       | Subject Matter (summary)                                            |
|-----------------|-------------------|---------------------------------------------------------------------|
| 63/983,615      | February 15, 2026 | Agent identity, scope derivation, and policy substrate              |
| 63/983,621      | February 15, 2026 | Tamper-evident signed decision logging for agent enforcement        |
| 63/983,843      | February 16, 2026 | Capability gating and in-flight model routing                       |
| 63/984,626      | February 17, 2026 | DAG Trust Attestation Token framework (§7.3 capability substrate)   |
| 64/071,781      | May 21, 2026      | Hard monetary spend caps with multi-action response and downgrade   |
| 64/071,789      | May 21, 2026      | Hierarchical scope-key resolution and coordination-free windowing   |

Additional patent applications are pending.

## No Patent License Granted

This package and its accompanying LICENSE grant copyright permission for use within the
thresholds described in Section 1 of the LICENSE. **Nothing in this package grants, expressly
or by implication, any patent license** to any patent, patent application, or other
intellectual property right of Dunecrest Ventures Inc. All patent rights are expressly
reserved.

## Patent marking (35 U.S.C. § 287)

This file serves as virtual patent marking pursuant to 35 U.S.C. § 287(a). It is a
constructive-notice declaration that the technology embodied in `agentguard-spend` is the
subject of pending United States patent applications.

For commercial licensing, OEM agreements, or strategic partnership inquiries, contact
`invest@agentguard.run`.

AgentGuard(TM) is a trademark of Dunecrest Ventures Inc. (USPTO Serial No. 99462472, pending).
MerchantGuard(TM) is a trademark of Dunecrest Ventures Inc. (USPTO Serial No. 99051215,
pending).
