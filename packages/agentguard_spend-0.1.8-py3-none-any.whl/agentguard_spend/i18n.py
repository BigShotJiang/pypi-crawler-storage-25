"""
AgentGuard Spend i18n module.

Resolves locale at runtime via the standard priority chain:

  1. explicit config (passed to SpendGuardConfig or to a binding)
  2. AGENTGUARD_LOCALE environment variable
  3. operating-system locale (locale.getdefaultlocale())
  4. en-US fallback

Supports en-US (default), es-419 (Latin American Spanish), and pt-BR
(Brazilian Portuguese) in v0.1.4. Additional locales may be added
without API changes by extending the TRANSLATIONS table below.
"""
from __future__ import annotations

import locale as _system_locale
import os
from typing import Optional


SUPPORTED_LOCALES = ("en-US", "es-419", "pt-BR")
DEFAULT_LOCALE = "en-US"


def _normalize_locale(raw: str) -> str:
    """Map any locale string to one of the supported locales.

    Examples:
        es_MX, es_AR, es_CO, es_419, es-MX → es-419
        pt_BR, pt-BR                       → pt-BR
        pt_PT, pt-PT                       → pt-BR (closest supported)
        en_US, en_GB, en-US, en            → en-US
        de_DE, fr_FR, ja_JP                → en-US (fallback)
    """
    if not raw:
        return DEFAULT_LOCALE
    s = raw.lower().replace("_", "-")
    if s.startswith("es"):
        return "es-419"
    if s.startswith("pt"):
        return "pt-BR"
    return DEFAULT_LOCALE


def resolve_locale(explicit: Optional[str] = None) -> str:
    """Resolve the active locale using the standard priority chain."""
    if explicit:
        return _normalize_locale(explicit)

    env = os.environ.get("AGENTGUARD_LOCALE")
    if env:
        return _normalize_locale(env)

    try:
        # locale.getdefaultlocale() is deprecated in Python 3.11+. Prefer the
        # LANG/LC_ALL env vars (which is what getdefaultlocale read anyway),
        # then fall back to getlocale().
        for env_var in ("LC_ALL", "LC_MESSAGES", "LANG"):
            raw = os.environ.get(env_var)
            if raw:
                # Strip encoding suffix like "en_US.UTF-8" -> "en_US".
                return _normalize_locale(raw.split(".")[0])
        sys_loc = _system_locale.getlocale()[0]
        if sys_loc:
            return _normalize_locale(sys_loc)
    except Exception:
        # locale module can raise on some systems; fall through to default
        pass

    return DEFAULT_LOCALE


TRANSLATIONS: dict[str, dict[str, str]] = {
    # ---------------- English (source of truth) ----------------
    "en-US": {
        "blocked_header": "AgentGuard Spend — call blocked",
        "field_agent": "agent",
        "field_provider": "provider",
        "field_amount": "amount",
        "field_cap": "cap",
        "field_status": "status",
        "status_blocked": "BLOCKED",
        "field_saved": "saved",
        "check_cap_enforced": "spend cap enforced",
        "check_receipt": "receipt tamper-evident",
        "check_provider_never_charged": "provider never charged",
        "field_policy": "policy",
        "field_reasons": "reasons",
        "reasons_none": "(none)",
        "window_per_call": "call",
        "window_per_minute": "minute",
        "window_per_hour": "hour",
        "window_per_day": "day",
        "window_per_month": "month",
        "short_message": "AgentGuard Spend blocked call",
        "default_soft_cap_reason": "Soft daily cap reached, routing to fallback model",
        "default_hard_cap_reason": "Hard daily ceiling exceeded",
        "default_minute_burst_reason": "Per-minute burst guard",
        "default_monthly_ceiling_reason": "Monthly hard ceiling",
        "cap_exceeded_format": "Cap '{window}={amount_cents}c' exceeded",
    },
    # ---------------- Latin American Spanish (es-419) ----------------
    "es-419": {
        "blocked_header": "AgentGuard Spend — llamada bloqueada",
        "field_agent": "agente",
        "field_provider": "proveedor",
        "field_amount": "monto",
        "field_cap": "límite",
        "field_status": "estado",
        "status_blocked": "BLOQUEADO",
        "field_saved": "ahorrado",
        "check_cap_enforced": "límite de gasto aplicado",
        "check_receipt": "recibo a prueba de manipulación",
        "check_provider_never_charged": "proveedor nunca cobrado",
        "field_policy": "política",
        "field_reasons": "razones",
        "reasons_none": "(ninguna)",
        "window_per_call": "llamada",
        "window_per_minute": "minuto",
        "window_per_hour": "hora",
        "window_per_day": "día",
        "window_per_month": "mes",
        "short_message": "AgentGuard Spend bloqueó la llamada",
        "default_soft_cap_reason": "Límite diario blando alcanzado, enrutando al modelo de respaldo",
        "default_hard_cap_reason": "Tope diario duro excedido",
        "default_minute_burst_reason": "Protección de ráfaga por minuto",
        "default_monthly_ceiling_reason": "Tope mensual duro",
        "cap_exceeded_format": "Límite '{window}={amount_cents}c' excedido",
    },
    # ---------------- Brazilian Portuguese (pt-BR) ----------------
    "pt-BR": {
        "blocked_header": "AgentGuard Spend — chamada bloqueada",
        "field_agent": "agente",
        "field_provider": "provedor",
        "field_amount": "valor",
        "field_cap": "limite",
        "field_status": "status",
        "status_blocked": "BLOQUEADO",
        "field_saved": "economizado",
        "check_cap_enforced": "limite de gasto aplicado",
        "check_receipt": "recibo à prova de adulteração",
        "check_provider_never_charged": "provedor nunca cobrado",
        "field_policy": "política",
        "field_reasons": "motivos",
        "reasons_none": "(nenhum)",
        "window_per_call": "chamada",
        "window_per_minute": "minuto",
        "window_per_hour": "hora",
        "window_per_day": "dia",
        "window_per_month": "mês",
        "short_message": "AgentGuard Spend bloqueou a chamada",
        "default_soft_cap_reason": "Limite diário leve atingido, redirecionando para modelo alternativo",
        "default_hard_cap_reason": "Teto diário rígido excedido",
        "default_minute_burst_reason": "Proteção de pico por minuto",
        "default_monthly_ceiling_reason": "Teto mensal rígido",
        "cap_exceeded_format": "Limite '{window}={amount_cents}c' excedido",
    },
}


def t(key: str, locale: Optional[str] = None) -> str:
    """Look up a translation key in the active locale, falling back to English."""
    loc = resolve_locale(locale)
    return TRANSLATIONS.get(loc, TRANSLATIONS[DEFAULT_LOCALE]).get(
        key,
        TRANSLATIONS[DEFAULT_LOCALE].get(key, key),
    )
