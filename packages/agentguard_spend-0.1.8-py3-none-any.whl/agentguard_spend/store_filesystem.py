"""
File-backed persistent decision log store.

Appends one canonical-JSON entry per line to an NDJSON file. Fully crash-safe
via O_APPEND. Reads are O(N) — fine for tens of thousands of entries which is
plenty for a per-tenant local file. Production deployments at higher volume
should swap in a real database adapter.

Stores live under ~/.agentguard/<tenant>/decisions.ndjson by default.
"""
from __future__ import annotations

import asyncio
import dataclasses
import json
import os
import pathlib
from typing import Any, Optional

from .types import DecisionLogStore, SignedDecisionLogEntry, SpendCap, SpendDecision


_HOME_DIR = pathlib.Path("~/.agentguard").expanduser()


def _default_log_path(tenant_id: str = "default") -> pathlib.Path:
    """Default decisions.ndjson location for a tenant."""
    return _HOME_DIR / tenant_id / "decisions.ndjson"


def _to_serializable(obj: Any) -> Any:
    if dataclasses.is_dataclass(obj):
        return {k: _to_serializable(v) for k, v in dataclasses.asdict(obj).items()}
    if isinstance(obj, dict):
        return {k: _to_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_serializable(x) for x in obj]
    return obj


def _entry_from_dict(d: dict) -> SignedDecisionLogEntry:
    decision_dict = dict(d["decision"])
    if decision_dict.get("triggeredCap") is not None and isinstance(
        decision_dict["triggeredCap"], dict
    ):
        decision_dict["triggeredCap"] = SpendCap(**decision_dict["triggeredCap"])
    decision = SpendDecision(**decision_dict)
    return SignedDecisionLogEntry(
        sequence=d["sequence"],
        entryHash=d["entryHash"],
        previousHash=d["previousHash"],
        signature=d["signature"],
        signerFingerprint=d["signerFingerprint"],
        decision=decision,
    )


class FilesystemDecisionLogStore(DecisionLogStore):
    """
    Append-only NDJSON decision log on local disk.

    Each call to `append()` writes one JSON object per line (O_APPEND for
    atomicity). The chain integrity is enforced by the SDK's hash-chain
    logic; this store just persists what it's given.

    Example:
        store = FilesystemDecisionLogStore("~/.agentguard/acme/decisions.ndjson")
        config = SpendGuardConfig(policy=..., logStore=store)
    """

    def __init__(self, path: pathlib.Path | str | None = None, *, tenant_id: str = "default") -> None:
        if path is None:
            path = _default_log_path(tenant_id)
        self.path = pathlib.Path(os.path.expanduser(str(path)))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()

    async def append(self, entry: SignedDecisionLogEntry) -> None:
        line = json.dumps(_to_serializable(entry), separators=(",", ":"))
        async with self._lock:
            # O_APPEND is atomic on POSIX for writes < PIPE_BUF (~4KB).
            # Decision entries are well under that. For very long reason
            # strings, use a smaller per-call line cap upstream.
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(line + "\n")

    async def get_latest(self) -> Optional[SignedDecisionLogEntry]:
        if not self.path.is_file():
            return None
        async with self._lock:
            # Efficient tail read for huge files: seek-back from end.
            try:
                with open(self.path, "rb") as f:
                    f.seek(0, os.SEEK_END)
                    file_size = f.tell()
                    if file_size == 0:
                        return None
                    # Read last 8KB (more than enough for one entry)
                    read_size = min(8192, file_size)
                    f.seek(file_size - read_size)
                    tail = f.read().decode("utf-8", errors="replace")
                last_line = tail.strip().split("\n")[-1]
                if not last_line:
                    return None
                return _entry_from_dict(json.loads(last_line))
            except (OSError, json.JSONDecodeError):
                return None

    async def read(
        self, from_sequence: int, limit: int
    ) -> list[SignedDecisionLogEntry]:
        if not self.path.is_file():
            return []
        results: list[SignedDecisionLogEntry] = []
        async with self._lock:
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if d.get("sequence", -1) >= from_sequence:
                        results.append(_entry_from_dict(d))
                        if len(results) >= limit:
                            break
        return results

    def read_all_sync(self) -> list[dict]:
        """
        Sync read of all entries as plain dicts. Used by the dashboard server
        which doesn't need the typed objects and benefits from avoiding the
        async-context-from-sync-handler dance.
        """
        if not self.path.is_file():
            return []
        out: list[dict] = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return out
