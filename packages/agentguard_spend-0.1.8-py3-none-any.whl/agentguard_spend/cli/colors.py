"""
ANSI color helpers with TTY detection.

Honors:
  - NO_COLOR=1                (industry standard; https://no-color.org)
  - AGENTGUARD_COLOR=0        (product-specific opt-out)
  - sys.stdout.isatty()       (no color when piped to file or non-TTY)
"""
from __future__ import annotations

import os
import sys


def _color_enabled() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("AGENTGUARD_COLOR", "").lower() in ("0", "false", "no", "off"):
        return False
    if not sys.stdout.isatty():
        return False
    return True


def _wrap(code: str) -> "callable":
    def applier(text: str) -> str:
        if _color_enabled():
            return f"\033[{code}m{text}\033[0m"
        return text
    return applier


# Colors used in the AgentGuard block trace
red = _wrap("31")
green = _wrap("32")
yellow = _wrap("33")
cyan = _wrap("36")
bright_red = _wrap("91")
bright_green = _wrap("92")
bright_cyan = _wrap("96")
bold = _wrap("1")
dim = _wrap("2")


def cyan_bold(text: str) -> str:
    if _color_enabled():
        return f"\033[1;36m{text}\033[0m"
    return text


def red_bold(text: str) -> str:
    if _color_enabled():
        return f"\033[1;31m{text}\033[0m"
    return text


def green_bold(text: str) -> str:
    if _color_enabled():
        return f"\033[1;32m{text}\033[0m"
    return text


def banner(version: str) -> str:
    """Single-line AgentGuard CLI banner, cyan."""
    hex_glyph = "⧫"  # ⧫ (black lozenge) — fallback for terminals without ⬡
    try:
        # Prefer the proper hexagon if encoding supports it
        "⬡".encode("utf-8")
        hex_glyph = "⬡"  # ⬡ WHITE HEXAGON
    except UnicodeEncodeError:
        pass
    return cyan_bold(f"{hex_glyph} AGENTGUARD SPEND  ·  v{version}")
