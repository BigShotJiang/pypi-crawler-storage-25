"""AgentGuard Spend CLI."""
from .main import main

__all__ = ["main"]
