"""
AgentGuard CLI entry point.

Usage:
    agentguard demo                       Run a deterministic simulation
    agentguard verify --trace latest      Verify the latest demo receipt
    agentguard --version                  Show installed SDK version
    agentguard --help                     Show this help

Roadmap (not in v0.1.5):
    agentguard init                       Scaffold a project policy file
    agentguard doctor                     Check installation health
    agentguard explain <receipt-id>       Show cap math + signature breakdown
    agentguard serve                      Local dashboard at localhost:8787
"""
from __future__ import annotations

import sys
from typing import List, Optional


_HELP = """\
agentguard — local-runtime spend caps + signed receipts for AI agents

usage:
  agentguard <command> [options]

commands:
  demo              Run a deterministic simulation with a real cryptographic receipt.
  verify            Verify a signed AgentGuard receipt.
  init              Scaffold a project (policy.yaml + quickstart.py + .gitignore).
  doctor            Check installation health and configuration.
  explain           Decode a signed receipt with cap math + signature breakdown.
  serve             Open a local dashboard at http://localhost:8787.
  --version         Show the installed SDK version.
  --help            Show this help.

examples:
  agentguard init
  agentguard doctor
  agentguard demo
  agentguard verify --trace latest
  agentguard explain latest

docs:    https://agentguard.run
install: pip install agentguard-spend  /  npm install @agentguard-run/spend
"""


def main(argv: Optional[List[str]] = None) -> int:
    args = list(argv if argv is not None else sys.argv[1:])

    if not args or args[0] in ("-h", "--help", "help"):
        print(_HELP)
        return 0

    if args[0] in ("-v", "--version", "version"):
        from .. import AGENTGUARD_SPEND_VERSION
        print(f"agentguard {AGENTGUARD_SPEND_VERSION}")
        return 0

    command = args[0]
    rest = args[1:]

    if command == "demo":
        from .demo import run_demo
        return run_demo(rest)
    if command == "verify":
        from .verify import run_verify
        return run_verify(rest)
    if command == "init":
        from .init import run_init
        return run_init(rest)
    if command == "doctor":
        from .doctor import run_doctor
        return run_doctor(rest)
    if command == "explain":
        from .explain import run_explain
        return run_explain(rest)
    if command == "serve":
        from .serve import run_serve
        return run_serve(rest)

    print(f"agentguard: unknown command '{command}'\n", file=sys.stderr)
    print(_HELP, file=sys.stderr)
    return 2
