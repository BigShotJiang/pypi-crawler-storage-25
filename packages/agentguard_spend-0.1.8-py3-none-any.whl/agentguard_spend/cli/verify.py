"""
`agentguard verify` — verify a signed decision log entry or chain.

Default target: --trace latest reads ~/.agentguard/demo/latest-receipt.json
(produced by `agentguard demo`) and verifies its Ed25519 signature
against the demo public key.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import pathlib

from ..decision_log import verify_entry
from ..types import SignedDecisionLogEntry, SpendDecision, SpendCap
from .colors import banner, cyan_bold, dim, green_bold, red_bold, green
from .. import AGENTGUARD_SPEND_VERSION


_DEMO_HOME = pathlib.Path("~/.agentguard/demo").expanduser()
_DEMO_RECEIPT = _DEMO_HOME / "latest-receipt.json"


def _signed_entry_from_dict(d: dict) -> tuple[SignedDecisionLogEntry, bytes]:
    decision_dict = dict(d["decision"])
    # The triggeredCap field is a nested dataclass; rebuild it if present
    if decision_dict.get("triggeredCap") is not None and isinstance(
        decision_dict["triggeredCap"], dict
    ):
        decision_dict["triggeredCap"] = SpendCap(**decision_dict["triggeredCap"])
    decision = SpendDecision(**decision_dict)
    entry = SignedDecisionLogEntry(
        sequence=d["sequence"],
        entryHash=d["entryHash"],
        previousHash=d["previousHash"],
        signature=d["signature"],
        signerFingerprint=d["signerFingerprint"],
        decision=decision,
    )
    public_key_hex = d.get("publicKeyHex") or ""
    public_key = bytes.fromhex(public_key_hex) if public_key_hex else b""
    return entry, public_key


def run_verify(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="agentguard verify",
        description="Verify a signed AgentGuard receipt.",
    )
    parser.add_argument(
        "--trace",
        default="latest",
        help='Receipt source. Default "latest" reads ~/.agentguard/demo/latest-receipt.json',
    )
    parser.add_argument(
        "--public-key",
        help="Hex-encoded Ed25519 public key (defaults to the key stored with the receipt).",
    )
    args = parser.parse_args(argv)

    if args.trace == "latest":
        if not _DEMO_RECEIPT.is_file():
            print(red_bold("error: ") + "no demo receipt found.")
            print()
            print(f"  run {green_bold('agentguard demo')} first to produce a receipt.")
            return 2
        with open(_DEMO_RECEIPT) as f:
            d = json.load(f)
    else:
        path = pathlib.Path(args.trace).expanduser()
        if not path.is_file():
            print(red_bold("error: ") + f"receipt file not found: {path}")
            return 2
        with open(path) as f:
            d = json.load(f)

    entry, public_key = _signed_entry_from_dict(d)
    if args.public_key:
        public_key = bytes.fromhex(args.public_key)
    if not public_key:
        print(red_bold("error: ") + "no public key available for verification.")
        return 2

    try:
        ok = asyncio.get_event_loop().run_until_complete(verify_entry(entry, public_key))
    except RuntimeError:
        ok = asyncio.run(verify_entry(entry, public_key))

    print()
    print("  " + banner(AGENTGUARD_SPEND_VERSION))
    print()
    print("  " + cyan_bold("agentguard verify --trace " + args.trace))
    print()
    label = lambda s: dim(f"  {s:<14}")  # noqa: E731
    print(label("receipt") + entry.entryHash[:32] + dim("..."))
    print(label("signer") + entry.signerFingerprint[:32] + dim("..."))
    print(label("sequence") + str(entry.sequence))
    print(label("policy") + entry.decision.policyId)
    print(label("action") + entry.decision.action)
    print()
    if ok:
        print("  " + green_bold("✓ signature valid"))
        print("  " + green("✓ entry hash matches canonical JSON"))
        print("  " + green("✓ chain link to previous entry intact"))
        print()
        return 0
    else:
        print("  " + red_bold("✗ verification FAILED"))
        print()
        print(dim("  one or more of: signature mismatch, entryHash mismatch, chain broken."))
        print()
        return 1
