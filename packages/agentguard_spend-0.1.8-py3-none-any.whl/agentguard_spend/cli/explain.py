"""
`agentguard explain` — decode a signed receipt with cap math + signature breakdown.

Pretty-prints what happened in a blocked decision:
  - which cap fired (and what the next cap would be)
  - the math: projected spend, window spend before, amount saved
  - the signature: signer fingerprint, decoded canonical JSON, chain link
  - what would unblock: reset time for the window
"""
from __future__ import annotations

import argparse
import json
import pathlib

from .colors import banner, cyan_bold, dim, green, green_bold, red_bold, yellow
from .. import AGENTGUARD_SPEND_VERSION


_DEMO_RECEIPT = pathlib.Path("~/.agentguard/demo/latest-receipt.json").expanduser()

_WINDOW_LABELS = {
    "per_call": "per call",
    "per_minute": "per minute",
    "per_hour": "per hour",
    "per_day": "per day",
    "per_month": "per month",
}

_WINDOW_RESETS = {
    "per_call": "next call",
    "per_minute": "top of next minute (UTC)",
    "per_hour": "top of next hour (UTC)",
    "per_day": "UTC midnight",
    "per_month": "1st of next month (UTC)",
}


def _format_cents(cents: int) -> str:
    sign = "-" if cents < 0 else ""
    dollars, remainder = divmod(abs(cents), 100)
    return f"{sign}${dollars:,}.{remainder:02d}"


def run_explain(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="agentguard explain",
        description="Decode a signed AgentGuard receipt.",
    )
    parser.add_argument(
        "receipt",
        nargs="?",
        default="latest",
        help='Receipt source. Default "latest" reads ~/.agentguard/demo/latest-receipt.json',
    )
    args = parser.parse_args(argv)

    print()
    print("  " + banner(AGENTGUARD_SPEND_VERSION))
    print()
    print("  " + cyan_bold(f"agentguard explain {args.receipt}"))
    print()

    if args.receipt == "latest":
        if not _DEMO_RECEIPT.is_file():
            print("  " + red_bold("error: ") + "no demo receipt found.")
            print(f"  run {green_bold('agentguard demo')} first to produce a receipt.")
            print()
            return 2
        path = _DEMO_RECEIPT
    else:
        path = pathlib.Path(args.receipt).expanduser()
        if not path.is_file():
            print("  " + red_bold("error: ") + f"receipt file not found: {path}")
            print()
            return 2

    raw = json.loads(path.read_text())
    decision = raw["decision"]
    cap = decision.get("triggeredCap")
    agent_id = (decision.get("triggeredScopeKey") or "unknown").split("|")[-1].replace("agentId=", "")

    # 1. WHAT HAPPENED
    print(dim("  what happened"))
    print(dim("  ─────────────"))
    action = decision.get("action", "?")
    color_action = (
        red_bold(action.upper()) if action == "block"
        else yellow(action.upper()) if action == "downgrade"
        else green(action.upper())
    )
    print(f"  action      {color_action}")
    print(f"  agent       {agent_id}")
    print(f"  provider    {decision.get('provider', '?')}")
    print(f"  model       {decision.get('modelRequested', '?')}")
    print()

    # 2. CAP MATH
    print(dim("  cap math"))
    print(dim("  ────────"))
    projected = decision.get("projectedCents", 0)
    window_before = decision.get("windowSpendBefore", 0)
    print(f"  this call would have cost   {green_bold(_format_cents(projected))}")
    print(f"  spent in window before      {_format_cents(window_before)}")
    if cap:
        cap_cents = cap.get("amountCents", 0)
        window = cap.get("window", "?")
        window_label = _WINDOW_LABELS.get(window, window)
        remaining = max(0, cap_cents - window_before)
        over_by = max(0, projected - remaining)
        print(f"  cap                         {red_bold(_format_cents(cap_cents))} {dim(window_label)}")
        print(f"  remaining in window         {_format_cents(remaining)}")
        if over_by > 0:
            print(f"  call exceeds remaining by   {red_bold(_format_cents(over_by))}")
        saved = max(0, projected - remaining)
        if saved > 0:
            print(f"  amount saved by block       {green_bold('+' + _format_cents(saved))}")
        print()

        # 3. WHAT UNBLOCKS
        print(dim("  what unblocks"))
        print(dim("  ─────────────"))
        reset = _WINDOW_RESETS.get(window, "next window boundary")
        print(f"  window resets at  {green_bold(reset)}")
        if cap.get("downgradeTo"):
            print(f"  downgrade target  {green_bold(cap['downgradeTo'])}")
        print()

    # 4. SIGNATURE / VERIFICATION
    print(dim("  cryptographic receipt"))
    print(dim("  ─────────────────────"))
    print(f"  sequence       {raw.get('sequence', '?')}")
    print(f"  entry hash     {raw.get('entryHash', '?')[:48]}{dim('...')}")
    print(f"  prev hash      {raw.get('previousHash', '?')[:48]}{dim('...')}")
    print(f"  signer (fp)    {raw.get('signerFingerprint', '?')[:32]}{dim('...')}")
    signature = raw.get("signature", "")
    sig_label = signature[:48] + (dim("...") if len(signature) > 48 else "")
    print(f"  signature      {sig_label}")
    print()
    print(f"  {dim('to verify cryptographically:')} {green_bold('agentguard verify --trace latest')}")
    print()

    # 5. POLICY CONTEXT
    print(dim("  policy"))
    print(dim("  ──────"))
    print(f"  id        {decision.get('policyId', '?')}")
    print(f"  version   {decision.get('policyVersion', '?')}")
    print(f"  mode      {decision.get('enforcementMode', '?')}")
    reasons = decision.get("reasons", [])
    if reasons:
        print(f"  reasons   {'; '.join(reasons)}")
    print()
    return 0
