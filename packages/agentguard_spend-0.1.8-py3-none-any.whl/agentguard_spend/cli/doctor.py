"""
`agentguard doctor` — check installation health and configuration.

Verifies:
  ✓ agentguard-spend package importable
  ✓ optional providers detected (openai, anthropic, boto3)
  ✓ ~/.agentguard/ writable for keypair persistence
  ✓ policy file detected (agentguard.policy.yaml in cwd)
  ✓ ed25519 cryptography backend works
  ✓ dry-run block simulation passes

Nothing phones home. No outbound network calls. Fully offline.
"""
from __future__ import annotations

import argparse
import importlib
import pathlib

from .colors import banner, cyan_bold, dim, green, green_bold, red_bold, yellow
from .. import AGENTGUARD_SPEND_VERSION


def _check_import(module_name: str) -> tuple[bool, str]:
    try:
        m = importlib.import_module(module_name)
        version = getattr(m, "__version__", "?")
        return True, version
    except ImportError:
        return False, ""


def _check_path_writable(path: pathlib.Path) -> tuple[bool, str]:
    try:
        path.mkdir(parents=True, exist_ok=True)
        test_file = path / ".doctor-write-test"
        test_file.write_text("ok")
        test_file.unlink()
        return True, str(path)
    except OSError as exc:
        return False, str(exc)


def _check_crypto() -> tuple[bool, str]:
    try:
        from ..decision_log import generate_keypair
        priv, pub = generate_keypair()
        if len(priv) == 32 and len(pub) == 32:
            return True, "Ed25519 keypair generation OK (32-byte priv + 32-byte pub)"
        return False, f"unexpected key sizes priv={len(priv)} pub={len(pub)}"
    except Exception as exc:
        return False, f"crypto backend failed: {exc}"


def _check_dry_run_block() -> tuple[bool, str]:
    """Simulate a blocked call end-to-end without touching the network."""
    try:
        import asyncio
        from ..types import CallContext, SpendCap, SpendPolicy, SpendScope
        from ..spend_guard import SpendGuard, SpendGuardConfig, SigningKeys
        from ..store_memory import InMemorySpendStore
        from ..decision_log import InMemoryDecisionLogStore, generate_keypair

        priv, pub = generate_keypair()
        cap = SpendCap(amountCents=0, window="per_day", action="block", reason="doctor check")
        scope = SpendScope(tenantId="doctor", agentId="dry-run")
        policy = SpendPolicy(
            id="doctor-v1",
            name="Doctor dry-run policy",
            scope=SpendScope(tenantId="doctor"),
            caps=[cap],
            mode="enforce",
            version=1,
            effectiveFrom="2026-01-01T00:00:00.000Z",
        )
        config = SpendGuardConfig(
            policy=policy,
            spendStore=InMemorySpendStore(),
            logStore=InMemoryDecisionLogStore(),
            signingKeys=SigningKeys(privateKey=priv, publicKey=pub),
        )
        guard = SpendGuard(config)
        call = CallContext(
            provider="openai",
            model="gpt-4o",
            inputTokens=100,
            outputTokens=50,
            scope=scope,
        )

        async def _run():
            return await guard.decide(call)

        try:
            decision, _ = asyncio.get_event_loop().run_until_complete(_run())
        except RuntimeError:
            decision, _ = asyncio.run(_run())

        if decision.action == "block":
            return True, "block path fires correctly"
        return False, f"expected action=block, got action={decision.action}"
    except Exception as exc:
        return False, f"dry-run block failed: {type(exc).__name__}: {exc}"


def run_doctor(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="agentguard doctor",
        description="Check AgentGuard Spend installation health.",
    )
    parser.parse_args(argv)

    print()
    print("  " + banner(AGENTGUARD_SPEND_VERSION))
    print()
    print("  " + cyan_bold("agentguard doctor") + dim("  ·  setup health check"))
    print()

    checks: list[tuple[str, bool, str]] = []

    # 1. Core package import
    ok, version = _check_import("agentguard_spend")
    checks.append(("agentguard_spend package", ok, f"v{version}" if ok else "not importable"))

    # 2. Crypto backend
    ok, note = _check_crypto()
    checks.append(("Ed25519 crypto backend", ok, note))

    # 3. Optional providers
    for provider in ("openai", "anthropic", "boto3"):
        ok, version = _check_import(provider)
        checks.append((
            f"provider: {provider}",
            ok,
            f"v{version}" if ok else "not installed (optional)",
        ))

    # 4. Keypair dir writable
    ok, note = _check_path_writable(pathlib.Path("~/.agentguard").expanduser())
    checks.append(("~/.agentguard/ writable", ok, note))

    # 5. Policy file detected
    policy_path = pathlib.Path.cwd() / "agentguard.policy.yaml"
    if policy_path.exists():
        checks.append((
            "policy file (cwd)",
            True,
            f"found: {policy_path.name}",
        ))
    else:
        checks.append((
            "policy file (cwd)",
            False,
            f"not found in {pathlib.Path.cwd().name}/ — run 'agentguard init'",
        ))

    # 6. Dry-run block simulation
    ok, note = _check_dry_run_block()
    checks.append(("dry-run block simulation", ok, note))

    # Render
    label_width = max(len(name) for name, _, _ in checks) + 2
    pass_count = 0
    optional_fail_count = 0
    fail_count = 0

    for name, ok, note in checks:
        # The 3 providers are optional; failing them is informational only.
        is_optional_provider = name.startswith("provider: ")
        if ok:
            mark = green("✓")
            pass_count += 1
        elif is_optional_provider:
            mark = dim("·")
            optional_fail_count += 1
        else:
            mark = red_bold("✗")
            fail_count += 1
        print(f"  {mark} {name:<{label_width}}{dim(note)}")

    print()
    print(dim("  ───────────────────────────────────────────"))
    if fail_count == 0:
        print(
            f"  {green_bold('healthy')}  "
            + dim(f"({pass_count} passing, {optional_fail_count} optional providers not installed)")
        )
        print()
        return 0
    print(
        f"  {red_bold('issues found')}  "
        + dim(f"({fail_count} failing, {pass_count} passing)")
    )
    print()
    print(dim("  fix the ✗ items above, then re-run 'agentguard doctor'."))
    print()
    return 1
