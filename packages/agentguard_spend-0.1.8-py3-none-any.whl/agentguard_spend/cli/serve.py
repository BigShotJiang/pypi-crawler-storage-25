"""
`agentguard serve` — local dashboard at localhost:8787 (configurable).

Aggregates per-tenant decision logs under ~/.agentguard/<tenant>/decisions.ndjson
and serves a single-page dashboard with:
  - today's spend (per agent, per provider)
  - recent decisions (last 50, color-coded by action)
  - blocked count + amount saved
  - per-receipt verify link (delegates to /api/verify/<entry_hash>)

Zero outbound network calls. Pure stdlib HTTP server. Auto-opens browser.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import pathlib
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from .colors import banner, cyan_bold, dim, green, green_bold, red_bold
from .. import AGENTGUARD_SPEND_VERSION
from ..store_filesystem import FilesystemDecisionLogStore
from ..decision_log import verify_entry
from ..types import SignedDecisionLogEntry, SpendCap, SpendDecision


_AGENTGUARD_HOME = pathlib.Path("~/.agentguard").expanduser()


def _scan_log_files() -> list[pathlib.Path]:
    """Find all decisions.ndjson files under ~/.agentguard/."""
    if not _AGENTGUARD_HOME.is_dir():
        return []
    return sorted(_AGENTGUARD_HOME.glob("*/decisions.ndjson"))


def _load_all_decisions() -> list[dict]:
    """Read every persisted decision across every tenant."""
    out: list[dict] = []
    for log_path in _scan_log_files():
        tenant = log_path.parent.name
        store = FilesystemDecisionLogStore(log_path)
        for d in store.read_all_sync():
            d["_tenant"] = tenant
            out.append(d)
    return out


def _entry_from_dict(d: dict) -> SignedDecisionLogEntry:
    dec = dict(d["decision"])
    if dec.get("triggeredCap") and isinstance(dec["triggeredCap"], dict):
        dec["triggeredCap"] = SpendCap(**dec["triggeredCap"])
    return SignedDecisionLogEntry(
        sequence=d["sequence"],
        entryHash=d["entryHash"],
        previousHash=d["previousHash"],
        signature=d["signature"],
        signerFingerprint=d["signerFingerprint"],
        decision=SpendDecision(**dec),
    )


def _compute_stats(decisions: list[dict]) -> dict:
    """Aggregate decisions into dashboard-ready stats."""
    total_calls = len(decisions)
    blocked_count = sum(1 for d in decisions if d["decision"].get("action") == "block")
    downgrade_count = sum(1 for d in decisions if d["decision"].get("action") == "downgrade")
    allow_count = total_calls - blocked_count - downgrade_count

    # Spent: sum of projected cents for allow + downgrade decisions
    # Saved: sum of projected cents for blocked decisions
    spent_cents = sum(
        d["decision"].get("projectedCents", 0)
        for d in decisions
        if d["decision"].get("action") in ("allow", "downgrade")
    )
    saved_cents = sum(
        d["decision"].get("projectedCents", 0)
        for d in decisions
        if d["decision"].get("action") == "block"
    )

    # Spend by agent
    by_agent: dict[str, int] = {}
    for d in decisions:
        scope_key = d["decision"].get("triggeredScopeKey", "") or ""
        agent_id = "unknown"
        for part in scope_key.split("|"):
            if part.startswith("agentId="):
                agent_id = part.split("=", 1)[1]
                break
        if d["decision"].get("action") in ("allow", "downgrade"):
            by_agent[agent_id] = by_agent.get(agent_id, 0) + d["decision"].get("projectedCents", 0)

    by_provider: dict[str, int] = {}
    for d in decisions:
        prov = d["decision"].get("provider", "unknown")
        if d["decision"].get("action") in ("allow", "downgrade"):
            by_provider[prov] = by_provider.get(prov, 0) + d["decision"].get("projectedCents", 0)

    return {
        "totals": {
            "spent_cents": spent_cents,
            "saved_cents": saved_cents,
            "calls": total_calls,
            "blocked": blocked_count,
            "downgraded": downgrade_count,
            "allowed": allow_count,
        },
        "by_agent": [{"agent": k, "spent_cents": v} for k, v in sorted(by_agent.items(), key=lambda x: -x[1])],
        "by_provider": [{"provider": k, "spent_cents": v} for k, v in sorted(by_provider.items(), key=lambda x: -x[1])],
        "recent": list(reversed(decisions[-50:])),  # newest first
        "version": AGENTGUARD_SPEND_VERSION,
    }


# ============================================================================
# Dashboard HTML — single page, no external deps, dark theme matching site
# ============================================================================

DASHBOARD_HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>AgentGuard Spend · Local Dashboard</title>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<style>
:root {
  --bg: #07101E;
  --surface: #0C1828;
  --surface-2: #0F1F35;
  --border: rgba(42,188,180,0.18);
  --border-dim: rgba(255,255,255,0.08);
  --teal: #2abcb4;
  --teal-glow: rgba(42,188,180,0.15);
  --text: #FFF;
  --text-2: #DCE8F0;
  --muted: #8AA0B3;
  --green: #4ade80;
  --amber: #F1C40F;
  --red: #FF6B6B;
  --code: #E6F0F5;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body {
  background: var(--bg); color: var(--text-2);
  font-family: 'DM Sans', -apple-system, system-ui, sans-serif;
  font-size: 15px; min-height: 100vh;
  -webkit-font-smoothing: antialiased;
}
a { color: var(--teal); text-decoration: none; }
a:hover { text-decoration: underline; }
code, .mono { font-family: 'JetBrains Mono', monospace; font-size: 13px; }

.topbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 16px 32px; border-bottom: 1px solid var(--border-dim);
  background: rgba(7,16,30,0.92); backdrop-filter: blur(10px);
  position: sticky; top: 0; z-index: 50;
}
.brand { display: inline-flex; align-items: center; gap: 12px; }
.brand .hex {
  width: 22px; height: 22px;
  background: var(--teal); color: var(--bg);
  display: inline-flex; align-items: center; justify-content: center;
  font-weight: 800; font-size: 13px; border-radius: 4px;
}
.brand .name { font-family: 'Cormorant Garamond', Georgia, serif; font-size: 22px; color: var(--text); }
.brand .name .accent { color: var(--teal); }
.brand .tag {
  margin-left: 8px;
  font-family: 'JetBrains Mono', monospace;
  font-size: 10px; font-weight: 700; letter-spacing: 0.15em; text-transform: uppercase;
  color: var(--teal);
  padding: 3px 8px; border: 1px solid var(--border); border-radius: 3px;
}
.refresh-btn {
  font-family: 'JetBrains Mono', monospace; font-size: 12px;
  color: var(--teal); background: transparent;
  border: 1px solid var(--teal); border-radius: 4px;
  padding: 7px 14px; cursor: pointer;
}
.refresh-btn:hover { background: var(--teal-glow); }

.shell { padding: 32px; max-width: 1280px; margin: 0 auto; }

/* Top stat cards */
.stats-row {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px;
  margin-bottom: 28px;
}
@media (max-width: 800px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
.stat-card {
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 8px; padding: 18px 20px;
}
.stat-card .label {
  font-family: 'JetBrains Mono', monospace;
  font-size: 10px; font-weight: 700; letter-spacing: 0.15em; text-transform: uppercase;
  color: var(--muted); margin-bottom: 8px;
}
.stat-card .value {
  font-size: 28px; font-weight: 800; color: var(--text);
  font-variant-numeric: tabular-nums; letter-spacing: -0.02em;
}
.stat-card.green .value { color: var(--green); }
.stat-card.red .value { color: var(--red); }
.stat-card.amber .value { color: var(--amber); }
.stat-card .sub { color: var(--muted); font-size: 12px; margin-top: 4px; }

/* Section heads */
.section {
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 8px; padding: 24px 26px; margin-bottom: 24px;
}
.section h2 {
  font-family: 'JetBrains Mono', monospace;
  font-size: 11px; font-weight: 700; letter-spacing: 0.15em; text-transform: uppercase;
  color: var(--teal); margin-bottom: 16px;
}

/* Two column */
.two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
@media (max-width: 800px) { .two-col { grid-template-columns: 1fr; } }

/* Bar */
.bar-row {
  display: flex; align-items: center; gap: 12px;
  padding: 8px 0; border-bottom: 1px solid var(--border-dim);
  font-size: 13.5px;
}
.bar-row:last-child { border-bottom: none; }
.bar-row .name { width: 35%; color: var(--text); }
.bar-row .bar {
  flex: 1; height: 10px; background: var(--surface-2); border-radius: 2px; overflow: hidden;
}
.bar-row .bar-fill {
  height: 100%; background: var(--teal); transition: width 0.4s;
}
.bar-row .amount {
  width: 80px; text-align: right; color: var(--green); font-weight: 700;
  font-family: 'JetBrains Mono', monospace; font-size: 13px;
}

/* Table */
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th {
  text-align: left; padding: 10px 12px;
  font-family: 'JetBrains Mono', monospace; font-size: 10px;
  letter-spacing: 0.12em; text-transform: uppercase; color: var(--muted);
  border-bottom: 1px solid var(--border);
}
td {
  padding: 12px; border-bottom: 1px solid var(--border-dim);
  vertical-align: top;
}
td.action-block { color: var(--red); font-weight: 700; }
td.action-downgrade { color: var(--amber); font-weight: 700; }
td.action-allow { color: var(--green); }
td.action-shadow { color: var(--muted); }
td .mono { color: var(--code); }

.pill {
  display: inline-block; padding: 2px 8px; border-radius: 3px;
  font-family: 'JetBrains Mono', monospace; font-size: 11px;
  background: var(--surface-2); color: var(--text-2); border: 1px solid var(--border-dim);
}
.empty {
  text-align: center; padding: 56px 20px; color: var(--muted); font-size: 14px;
}
.empty code {
  display: block; margin-top: 8px; font-size: 14px; color: var(--teal);
}
.live-indicator {
  display: inline-block; width: 8px; height: 8px; border-radius: 50%;
  background: var(--green); margin-right: 6px;
  animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
  0%, 100% { opacity: 1; box-shadow: 0 0 0 0 rgba(74,222,128,0.4); }
  50% { opacity: 0.7; box-shadow: 0 0 0 6px rgba(74,222,128,0); }
}
</style>
</head>
<body>

<div class="topbar">
  <div class="brand">
    <span class="hex">⬡</span>
    <span class="name">Agent<span class="accent">Guard</span></span>
    <span class="tag">Spend · Local Dashboard</span>
  </div>
  <div>
    <span class="mono" style="color: var(--muted); margin-right: 16px;">
      <span class="live-indicator"></span>v__VERSION__ · localhost:8787
    </span>
    <button class="refresh-btn" onclick="loadStats()">Refresh</button>
  </div>
</div>

<div class="shell">

  <div class="stats-row">
    <div class="stat-card green">
      <div class="label">Spent (all-time)</div>
      <div class="value" id="spent">$0.00</div>
      <div class="sub" id="spent-sub">across <span id="call-count">0</span> calls</div>
    </div>
    <div class="stat-card red">
      <div class="label">Saved by blocks</div>
      <div class="value" id="saved">+$0.00</div>
      <div class="sub"><span id="blocked-count">0</span> calls blocked</div>
    </div>
    <div class="stat-card amber">
      <div class="label">Downgraded</div>
      <div class="value" id="downgraded">0</div>
      <div class="sub">calls routed to cheaper model</div>
    </div>
    <div class="stat-card">
      <div class="label">Allowed</div>
      <div class="value" id="allowed">0</div>
      <div class="sub">policy-checked & passed</div>
    </div>
  </div>

  <div class="two-col">
    <div class="section">
      <h2>Spend by Agent</h2>
      <div id="by-agent"></div>
    </div>
    <div class="section">
      <h2>Spend by Provider</h2>
      <div id="by-provider"></div>
    </div>
  </div>

  <div class="section">
    <h2>Recent Decisions</h2>
    <table>
      <thead>
        <tr>
          <th style="width:80px">Action</th>
          <th>Agent</th>
          <th>Provider · Model</th>
          <th style="width:120px;text-align:right">Amount</th>
          <th style="width:120px">Receipt</th>
        </tr>
      </thead>
      <tbody id="recent-rows"></tbody>
    </table>
  </div>

  <div style="text-align: center; color: var(--muted); font-size: 12px; margin-top: 32px;">
    Local-only. No outbound network calls. Reads from <code class="mono">~/.agentguard/*/decisions.ndjson</code>.
    <br/>
    Source: <a href="https://agentguard.run">agentguard.run</a>
    · <a href="https://www.npmjs.com/package/@agentguard-run/spend">npm</a>
    · <a href="https://pypi.org/project/agentguard-spend/">pypi</a>
  </div>
</div>

<script>
function formatCents(cents) {
  const sign = cents < 0 ? '-' : '';
  const abs = Math.abs(Math.round(cents));
  const dollars = Math.floor(abs / 100);
  const remainder = abs % 100;
  return sign + '$' + dollars.toLocaleString() + '.' + String(remainder).padStart(2, '0');
}

function renderBars(containerId, items, key) {
  const el = document.getElementById(containerId);
  if (!items.length) { el.innerHTML = '<div style="color:var(--muted);font-size:13px;padding:8px 0">no data yet</div>'; return; }
  const max = Math.max(...items.map(i => i.spent_cents)) || 1;
  el.innerHTML = items.slice(0, 8).map(i => `
    <div class="bar-row">
      <span class="name">${i[key]}</span>
      <span class="bar"><span class="bar-fill" style="width:${(i.spent_cents/max*100).toFixed(1)}%"></span></span>
      <span class="amount">${formatCents(i.spent_cents)}</span>
    </div>
  `).join('');
}

function renderRecent(items) {
  const tbody = document.getElementById('recent-rows');
  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="5"><div class="empty">
      no decisions yet.<br>
      run <code>agentguard demo</code> in your terminal to see a real signed receipt here.
    </div></td></tr>`;
    return;
  }
  tbody.innerHTML = items.map(d => {
    const dec = d.decision;
    const scope = dec.triggeredScopeKey || '';
    const agentMatch = scope.match(/agentId=([^|]+)/);
    const agent = agentMatch ? agentMatch[1] : '<span style="color:var(--muted)">—</span>';
    const action = dec.action || 'allow';
    return `<tr>
      <td class="action-${action}">${action.toUpperCase()}</td>
      <td class="mono">${agent}</td>
      <td><span class="pill">${dec.provider || '?'}</span> ${dec.modelRequested || ''}</td>
      <td style="text-align:right" class="mono">${formatCents(dec.projectedCents || 0)}</td>
      <td class="mono"><a href="#" onclick="return verifyReceipt('${d.entryHash}')">${d.entryHash.slice(0, 12)}...</a></td>
    </tr>`;
  }).join('');
}

async function verifyReceipt(hash) {
  try {
    const r = await fetch('/api/verify/' + hash);
    const d = await r.json();
    alert(d.ok
      ? '✓ verified: signature valid, hash matches, chain intact'
      : '✗ verification failed: ' + (d.reason || 'unknown'));
  } catch (e) {
    alert('verify error: ' + e);
  }
  return false;
}

async function loadStats() {
  try {
    const r = await fetch('/api/stats');
    const s = await r.json();
    document.getElementById('spent').textContent = formatCents(s.totals.spent_cents);
    document.getElementById('saved').textContent = '+' + formatCents(s.totals.saved_cents);
    document.getElementById('downgraded').textContent = s.totals.downgraded;
    document.getElementById('allowed').textContent = s.totals.allowed;
    document.getElementById('call-count').textContent = s.totals.calls;
    document.getElementById('blocked-count').textContent = s.totals.blocked;
    renderBars('by-agent', s.by_agent, 'agent');
    renderBars('by-provider', s.by_provider, 'provider');
    renderRecent(s.recent);
  } catch (e) {
    console.error('load failed:', e);
  }
}

loadStats();
setInterval(loadStats, 5000);  // auto-refresh every 5s
</script>
</body>
</html>
"""


class _DashboardHandler(BaseHTTPRequestHandler):
    """HTTP handler — no logging chatter, JSON API + static HTML."""

    def log_message(self, format: str, *args: Any) -> None:  # silence stdlib chatter
        return

    def _send_json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html: str) -> None:
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = self.path.split("?")[0]
        if path == "/" or path == "/index.html":
            html = DASHBOARD_HTML.replace("__VERSION__", AGENTGUARD_SPEND_VERSION)
            self._send_html(html)
            return
        if path == "/api/stats":
            decisions = _load_all_decisions()
            self._send_json(200, _compute_stats(decisions))
            return
        if path.startswith("/api/verify/"):
            entry_hash = path.split("/")[-1]
            decisions = _load_all_decisions()
            match = next((d for d in decisions if d.get("entryHash") == entry_hash), None)
            if not match:
                self._send_json(404, {"ok": False, "reason": "receipt not found"})
                return
            try:
                public_key_hex = match.get("publicKeyHex", "")
                if not public_key_hex:
                    self._send_json(400, {"ok": False, "reason": "no public key in stored receipt"})
                    return
                entry = _entry_from_dict(match)
                public_key = bytes.fromhex(public_key_hex)
                try:
                    ok = asyncio.get_event_loop().run_until_complete(
                        verify_entry(entry, public_key)
                    )
                except RuntimeError:
                    ok = asyncio.run(verify_entry(entry, public_key))
                self._send_json(200, {"ok": bool(ok)})
            except Exception as exc:
                self._send_json(500, {"ok": False, "reason": str(exc)})
            return
        self._send_json(404, {"error": "not found"})


def run_serve(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="agentguard serve",
        description="Local dashboard for AgentGuard Spend.",
    )
    parser.add_argument("--port", type=int, default=8787, help="Port to bind (default: 8787)")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    parser.add_argument("--no-open", action="store_true", help="Do not auto-open the browser")
    args = parser.parse_args(argv)

    print()
    print("  " + banner(AGENTGUARD_SPEND_VERSION))
    print()
    print("  " + cyan_bold("agentguard serve") + dim("  ·  local dashboard"))
    print()

    log_files = _scan_log_files()
    if not log_files:
        print(f"  {dim('no decision logs found yet at ~/.agentguard/*/decisions.ndjson')}")
        print(f"  {dim('run')} {green_bold('agentguard demo')} {dim('to produce one, then refresh.')}")
        print()

    server = ThreadingHTTPServer((args.host, args.port), _DashboardHandler)
    url = f"http://{args.host}:{args.port}"
    print(f"  {green('→')} dashboard:  {green_bold(url)}")
    print(f"  {dim('  reading:    ~/.agentguard/*/decisions.ndjson')}")
    print(f"  {dim('  press Ctrl+C to stop')}")
    print()

    if not args.no_open:
        threading.Timer(0.4, lambda: webbrowser.open_new(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print()
        print(f"  {green('✓')} dashboard stopped")
        print()
    return 0
