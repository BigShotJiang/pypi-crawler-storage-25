"""
`agentguard demo` — deterministic simulation with real cryptographic receipt.

Produces output that visually matches agentguard.run/the-block/. The
dollar amount, agent name, and provider are simulated parameters
(fixed values for reproducibility). The Ed25519 signature, SHA-256
chain hash, and canonical-JSON serialization are REAL — the demo
receipt can be verified with `agentguard verify --trace latest`.

No network calls. Fully offline. Deterministic output across runs.
"""
from __future__ import annotations

import argparse
import asyncio
import dataclasses
import json
import os
import pathlib
from datetime import datetime, timezone
from typing import Any

from ..types import SpendCap, SpendDecision, SpendScope
from ..spend_guard import format_blocked_trace
from ..decision_log import (
    GENESIS_PREVIOUS_HASH,
    compute_entry_hash,
    compute_signer_fingerprint,
    public_key_from_seed,
    sign_decision,
)
from .colors import banner, cyan_bold, dim, green, green_bold
from .. import AGENTGUARD_SPEND_VERSION


_DEMO_HOME = pathlib.Path("~/.agentguard/demo").expanduser()
_DEMO_PRIVATE_KEY = _DEMO_HOME / "demo-private.key"
_DEMO_PUBLIC_KEY = _DEMO_HOME / "demo-public.key"
_DEMO_RECEIPT = _DEMO_HOME / "latest-receipt.json"


def _to_serializable(obj: Any) -> Any:
    """Convert dataclasses + nested dataclasses to plain JSON-friendly types."""
    if dataclasses.is_dataclass(obj):
        return {k: _to_serializable(v) for k, v in dataclasses.asdict(obj).items()}
    if isinstance(obj, dict):
        return {k: _to_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_serializable(x) for x in obj]
    return obj


def run_demo(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="agentguard demo",
        description="Run a deterministic simulation with a real cryptographic receipt.",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colored output (same as NO_COLOR=1).",
    )
    args = parser.parse_args(argv)

    if args.no_color:
        os.environ["NO_COLOR"] = "1"

    # Simulated parameters - kept fixed so demo output is deterministic
    # and matches the marketing screenshot at agentguard.run/the-block/.
    agent_id = "agent-finance-bot-v3"
    provider = "anthropic"
    model_requested = "claude-opus-4-7"
    daily_cap_cents = 50000  # $500.00
    projected_cents = 112241  # $1,122.41 attempted call
    window_spend_before = 0
    timestamp = "2026-05-24T18:00:00.000Z"

    # Deterministic Ed25519 keypair from a fixed seed.
    # Public + reproducible by design — NEVER use for production.
    private_seed = bytes(range(32))
    public_key = public_key_from_seed(private_seed)

    # Construct the decision artifact directly. This is what the SDK
    # would produce internally when the cap fires on a real call.
    triggered_cap = SpendCap(
        amountCents=daily_cap_cents,
        window="per_day",
        action="block",
        reason=f"Hard daily ceiling (${daily_cap_cents / 100:.2f}/day)",
    )
    scope = SpendScope(tenantId="demo", agentId=agent_id)

    decision = SpendDecision(
        decisionId="agentguard-demo-decision-v1",
        timestamp=timestamp,
        policyId="agentguard-demo-policy-v1",
        policyVersion=1,
        enforcementMode="enforce",
        action="block",
        reasons=[f"Cap 'per_day={daily_cap_cents}c' exceeded"],
        provider=provider,
        modelRequested=model_requested,
        modelResolved=model_requested,
        projectedCents=projected_cents,
        windowSpendBefore=window_spend_before,
        windowSpendAfter=window_spend_before,
        triggeredCap=triggered_cap,
        triggeredScopeKey="tenantId=demo|agentId=" + agent_id,
    )

    # REAL Ed25519 signature over REAL canonical JSON. This is what makes
    # `agentguard verify` produce a real OK against this demo receipt.
    sequence = 0
    previous_hash = GENESIS_PREVIOUS_HASH
    entry_hash = compute_entry_hash(
        sequence=sequence,
        decision=decision,
        previous_hash=previous_hash,
    )

    async def _sign():
        return await sign_decision(
            sequence=sequence,
            decision=decision,
            previous_hash=previous_hash,
            private_key=private_seed,
            public_key=public_key,
        )

    try:
        signed_entry = asyncio.get_event_loop().run_until_complete(_sign())
    except RuntimeError:
        signed_entry = asyncio.run(_sign())
    signature = signed_entry.signature
    signer_fingerprint = compute_signer_fingerprint(public_key)

    # Print the framing line ABOVE the trace so the demo is honest.
    print()
    print("  " + banner(AGENTGUARD_SPEND_VERSION))
    print()
    print(
        "  "
        + cyan_bold("AgentGuard Demo")
        + dim("  ·  ")
        + dim("[simulated transaction · real cryptographic receipt]")
    )
    print()
    print(format_blocked_trace(decision, scope))
    print()

    # Persist the real receipt so `agentguard verify --trace latest` works.
    receipt = {
        "sequence": sequence,
        "entryHash": entry_hash,
        "previousHash": previous_hash,
        "signature": signature,
        "signerFingerprint": signer_fingerprint,
        "publicKeyHex": public_key.hex(),
        "decision": _to_serializable(decision),
    }
    try:
        _DEMO_HOME.mkdir(parents=True, exist_ok=True)
        _DEMO_PRIVATE_KEY.write_bytes(private_seed)
        _DEMO_PUBLIC_KEY.write_bytes(public_key)
        _DEMO_RECEIPT.write_text(json.dumps(receipt, indent=2))
        # Also append to the canonical NDJSON log so `agentguard serve`
        # can show the demo decision in the dashboard.
        log_path = _DEMO_HOME / "decisions.ndjson"
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(receipt, separators=(",", ":")) + "\n")
        try:
            _DEMO_PRIVATE_KEY.chmod(0o600)
        except OSError:
            pass
    except OSError:
        pass

    receipt_id = entry_hash[:16]
    print(dim("  ───────────────────────────────────────────"))
    print(f"  {dim('receipt')}    {receipt_id}{dim('...')}")
    print(f"  {dim('signer')}     {signer_fingerprint[:16]}{dim('...')}")
    print(f"  {dim('sequence')}   {sequence}")
    print(dim("  ───────────────────────────────────────────"))
    print()
    print(
        "  "
        + green("→")
        + " "
        + dim("verify this receipt:")
        + " "
        + green_bold("agentguard verify --trace latest")
    )
    print()
    return 0
