"""
AgentGuard(TM) Spend — Core type definitions

Patent notice: Protected by U.S. patent-pending technology
(App. Nos. 63/983,615; 63/983,621; 63/983,843; 63/984,626;
64/071,781; 64/071,789).

Design rule: NO DATA PLANE INVOLVEMENT.
All policy decisions are made locally in the customer runtime.
Prompts, completions, and provider API keys never leave the customer process.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Literal, Optional

SpendAction = Literal["block", "downgrade", "shadow", "allow"]

SpendWindow = Literal["per_call", "per_minute", "per_hour", "per_day", "per_month"]

Provider = Literal["openai", "anthropic", "bedrock", "gemini", "unknown"]

EnforcementMode = Literal["shadow", "canary", "enforce"]

CapabilityTier = Literal["read_only", "data_write", "payment_initiate", "payment_execute"]


@dataclass
class SpendCap:
    """A spend cap with one or more thresholds across configurable windows.

    All amounts are USD cents (integer math, no floating-point cost drift).
    """

    amountCents: int
    window: SpendWindow
    action: SpendAction
    downgradeTo: Optional[str] = None
    reason: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "amountCents": self.amountCents,
            "window": self.window,
            "action": self.action,
        }
        if self.downgradeTo is not None:
            out["downgradeTo"] = self.downgradeTo
        if self.reason is not None:
            out["reason"] = self.reason
        return out


@dataclass
class SpendScope:
    """Identity scope a cap applies to.

    Caps are matched on EVERY matching scope. If any scope's cap is exceeded,
    the most restrictive action wins.
    """

    tenantId: str
    userId: Optional[str] = None
    teamId: Optional[str] = None
    agentId: Optional[str] = None
    taskId: Optional[str] = None
    provider: Optional[Provider] = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"tenantId": self.tenantId}
        for k in ("userId", "teamId", "agentId", "taskId", "provider"):
            v = getattr(self, k)
            if v is not None:
                out[k] = v
        return out


@dataclass
class SpendPolicy:
    """A full spend policy: name, scope, and ordered list of caps.

    The first cap whose threshold is reached determines the action.
    """

    id: str
    name: str
    scope: SpendScope
    caps: list[SpendCap]
    mode: EnforcementMode
    version: int
    effectiveFrom: str
    requiredCapability: Optional[CapabilityTier] = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "id": self.id,
            "name": self.name,
            "scope": self.scope.to_dict(),
            "caps": [c.to_dict() for c in self.caps],
            "mode": self.mode,
            "version": self.version,
            "effectiveFrom": self.effectiveFrom,
        }
        if self.requiredCapability is not None:
            out["requiredCapability"] = self.requiredCapability
        return out


@dataclass
class CallContext:
    """A single LLM call attempted under a policy."""

    provider: Provider
    model: str
    inputTokens: int
    outputTokens: int
    scope: SpendScope
    label: Optional[str] = None
    capabilityClaim: Optional[CapabilityTier] = None


@dataclass
class SpendDecision:
    """The policy decision for a given call.

    Field order and presence rules match the TypeScript SpendDecision exactly;
    canonical-JSON serialization sorts keys lexicographically regardless of
    insertion order, so this dataclass simply mirrors the TS shape.
    """

    decisionId: str
    timestamp: str
    action: SpendAction
    triggeredCap: Optional[SpendCap]
    triggeredScopeKey: Optional[str]
    projectedCents: int
    windowSpendBefore: int
    windowSpendAfter: int
    provider: Provider
    modelRequested: str
    modelResolved: str
    policyId: str
    policyVersion: int
    enforcementMode: EnforcementMode
    reasons: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "decisionId": self.decisionId,
            "timestamp": self.timestamp,
            "action": self.action,
            "triggeredCap": self.triggeredCap.to_dict() if self.triggeredCap is not None else None,
            "triggeredScopeKey": self.triggeredScopeKey,
            "projectedCents": self.projectedCents,
            "windowSpendBefore": self.windowSpendBefore,
            "windowSpendAfter": self.windowSpendAfter,
            "provider": self.provider,
            "modelRequested": self.modelRequested,
            "modelResolved": self.modelResolved,
            "policyId": self.policyId,
            "policyVersion": self.policyVersion,
            "enforcementMode": self.enforcementMode,
            "reasons": list(self.reasons),
        }


@dataclass
class SignedDecisionLogEntry:
    """A signed, hash-chained decision log entry.

    The chain enables tamper-evident audit: each entry binds the previous
    entry's hash, and the entire chain is verifiable with a public key.

    The capability-tier framework used here is informed by Patent D §7.3
    (App. No. 63/984,626). The flat tier comparison implemented in this SDK
    does not by itself implement the full DAG-TAT cryptographic gating of
    §7.3; integration with a DAG-TAT verifier is performed separately and
    is not required for the spend-governance functions of this package.
    """

    sequence: int
    decision: SpendDecision
    previousHash: str
    entryHash: str
    signature: str
    signerFingerprint: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "sequence": self.sequence,
            "decision": self.decision.to_dict(),
            "previousHash": self.previousHash,
            "entryHash": self.entryHash,
            "signature": self.signature,
            "signerFingerprint": self.signerFingerprint,
        }


class SpendStore(ABC):
    """Storage backend for spend state.

    Implementations may use Redis, Postgres, SQLite, in-memory, or anything else.
    Spend state never leaves the customer runtime in the no-data-plane
    configuration.
    """

    @abstractmethod
    async def get_window_spend(self, scope_key: str, window: SpendWindow) -> int:
        """Get the total cents spent for a given scope key + window since the window start."""

    @abstractmethod
    async def increment_window_spend(
        self, scope_key: str, window: SpendWindow, cents: int
    ) -> int:
        """Atomically increment the cents spent for a given scope key + window.

        Returns the new total. Implementations MUST be atomic to prevent races.
        """


class DecisionLogStore(ABC):
    """Storage backend for the signed decision log.

    Implementations may append to a local file, a database table, or any other
    append-only sink.
    """

    @abstractmethod
    async def append(self, entry: SignedDecisionLogEntry) -> None:
        """Append a new signed entry to the chain."""

    @abstractmethod
    async def get_latest(self) -> Optional[SignedDecisionLogEntry]:
        """Get the most recent entry, or None if empty."""

    @abstractmethod
    async def read(self, from_sequence: int, limit: int) -> list[SignedDecisionLogEntry]:
        """Iterate from sequence onward (used by verification tools)."""
