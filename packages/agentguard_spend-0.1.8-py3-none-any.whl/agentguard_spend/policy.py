"""
AgentGuard(TM) Spend — Policy evaluation engine

Evaluates a SpendPolicy against a CallContext and returns a SpendDecision.
Pure function over inputs and the spend store; no network calls, no provider
SDK dependencies, no data plane involvement.

Patent notice: Protected by U.S. patent-pending technology
(App. Nos. 63/983,615; 63/983,621; 63/983,843; 63/984,626;
64/071,781; 64/071,789).
"""

from __future__ import annotations

import datetime as _dt
import uuid

from .cost_table import compute_call_cents, infer_provider
from .types import (
    CallContext,
    CapabilityTier,
    SpendAction,
    SpendCap,
    SpendDecision,
    SpendPolicy,
    SpendScope,
    SpendStore,
    SpendWindow,
)


def build_scope_key(scope: SpendScope) -> str:
    """Build a deterministic scope key from a SpendScope.

    The key identifies a single (tenant, user, team, agent, provider)
    combination for storing window spend totals. Format is
    pipe-delimited key=value pairs, ordered as the TypeScript reference
    implementation does.
    """
    parts = [f"tenant={scope.tenantId}"]
    if scope.userId:
        parts.append(f"user={scope.userId}")
    if scope.teamId:
        parts.append(f"team={scope.teamId}")
    if scope.agentId:
        parts.append(f"agent={scope.agentId}")
    if scope.taskId:
        parts.append(f"task={scope.taskId}")
    if scope.provider:
        parts.append(f"prov={scope.provider}")
    return "|".join(parts)


def _policy_matches_call(policy_scope: SpendScope, call_scope: SpendScope) -> bool:
    """Returns True if the cap's scope shape is satisfied by the call's scope.

    A cap matches if every non-empty field in the cap's policy scope is
    present AND equal in the call's scope. Empty fields in the policy scope
    are wildcards (match anything).
    """
    if policy_scope.tenantId != call_scope.tenantId:
        return False
    if policy_scope.userId and policy_scope.userId != call_scope.userId:
        return False
    if policy_scope.teamId and policy_scope.teamId != call_scope.teamId:
        return False
    if policy_scope.agentId and policy_scope.agentId != call_scope.agentId:
        return False
    if policy_scope.taskId and policy_scope.taskId != call_scope.taskId:
        return False
    if policy_scope.provider and policy_scope.provider != call_scope.provider:
        return False
    return True


# Restrictiveness order: block > downgrade > shadow > allow.
ACTION_RANK: dict[SpendAction, int] = {
    "block": 3,
    "downgrade": 2,
    "shadow": 1,
    "allow": 0,
}


def _most_restrictive(a: SpendAction, b: SpendAction) -> SpendAction:
    return a if ACTION_RANK[a] >= ACTION_RANK[b] else b


CAPABILITY_ORDER: dict[CapabilityTier, int] = {
    "read_only": 0,
    "data_write": 1,
    "payment_initiate": 2,
    "payment_execute": 3,
}


def _capability_meets_requirement(claimed: CapabilityTier, required: CapabilityTier) -> bool:
    return CAPABILITY_ORDER[claimed] >= CAPABILITY_ORDER[required]


def _iso_timestamp_now() -> str:
    """Match TS new Date().toISOString() format: YYYY-MM-DDTHH:MM:SS.mmmZ."""
    now = _dt.datetime.now(_dt.timezone.utc)
    ms = now.microsecond // 1000
    return f"{now.strftime('%Y-%m-%dT%H:%M:%S')}.{ms:03d}Z"


async def evaluate_policy(
    policy: SpendPolicy,
    call: CallContext,
    store: SpendStore,
) -> SpendDecision:
    """Evaluate the policy against the call.

    Returns a SpendDecision describing the action to take, the cap that
    triggered it (if any), and the projected vs actual spend in the relevant
    window.

    Side effect: on 'allow' and 'downgrade', this function INCREMENTS the
    window spend. On 'block' and 'shadow' the increment is NOT applied (a
    blocked call does not cost anything; a shadow call is observed but not
    yet wired through). Callers that need to count shadow calls toward spend
    should increment explicitly after the provider call returns.
    """
    decision_id = str(uuid.uuid4())
    timestamp = _iso_timestamp_now()
    reasons: list[str] = []
    call_provider = call.provider or infer_provider(call.model)

    # 1. Confirm policy applies to this call.
    if not _policy_matches_call(policy.scope, call.scope):
        reasons.append(f"Policy {policy.id} scope does not match call scope")
        return SpendDecision(
            decisionId=decision_id,
            timestamp=timestamp,
            action="allow",
            triggeredCap=None,
            triggeredScopeKey=None,
            projectedCents=0,
            windowSpendBefore=0,
            windowSpendAfter=0,
            provider=call_provider,
            modelRequested=call.model,
            modelResolved=call.model,
            policyId=policy.id,
            policyVersion=policy.version,
            enforcementMode=policy.mode,
            reasons=reasons,
        )

    # 2. Capability gate (Patent D §7.3 reduction).
    if policy.requiredCapability:
        claimed = call.capabilityClaim
        if claimed is None or not _capability_meets_requirement(
            claimed, policy.requiredCapability
        ):
            reasons.append(
                f"Capability '{claimed if claimed else 'none'}' below required "
                f"'{policy.requiredCapability}'"
            )
            return SpendDecision(
                decisionId=decision_id,
                timestamp=timestamp,
                action="block",
                triggeredCap=None,
                triggeredScopeKey=None,
                projectedCents=0,
                windowSpendBefore=0,
                windowSpendAfter=0,
                provider=call_provider,
                modelRequested=call.model,
                modelResolved=call.model,
                policyId=policy.id,
                policyVersion=policy.version,
                enforcementMode=policy.mode,
                reasons=reasons,
            )

    # 3. Compute projected cost.
    projected_cents = compute_call_cents(call.model, call.inputTokens, call.outputTokens)
    if projected_cents is None:
        reasons.append(
            f"Unknown model '{call.model}', no cost data — defaulting to allow"
        )
        return SpendDecision(
            decisionId=decision_id,
            timestamp=timestamp,
            action="block" if policy.mode == "enforce" else "allow",
            triggeredCap=None,
            triggeredScopeKey=None,
            projectedCents=0,
            windowSpendBefore=0,
            windowSpendAfter=0,
            provider=call_provider,
            modelRequested=call.model,
            modelResolved=call.model,
            policyId=policy.id,
            policyVersion=policy.version,
            enforcementMode=policy.mode,
            reasons=reasons,
        )

    # 4. Evaluate caps in order. Most-restrictive-wins.
    chosen_action: SpendAction = "allow"
    triggered_cap: SpendCap | None = None
    triggered_scope_key: str | None = None
    window_spend_before = 0
    window_spend_after = 0
    model_resolved = call.model

    scope_key = build_scope_key(call.scope)

    for cap in policy.caps:
        current_spend = await store.get_window_spend(scope_key, cap.window)
        projected_total = current_spend + projected_cents
        if projected_total > cap.amountCents:
            candidate_action = cap.action
            if ACTION_RANK[candidate_action] > ACTION_RANK[chosen_action]:
                chosen_action = candidate_action
                triggered_cap = cap
                triggered_scope_key = scope_key
                window_spend_before = current_spend
                window_spend_after = projected_total
                if candidate_action == "downgrade" and cap.downgradeTo:
                    model_resolved = cap.downgradeTo
                reasons.append(
                    f"Cap '{cap.window}={cap.amountCents}c' exceeded "
                    f"(spent={current_spend}c, +call={projected_cents}c, "
                    f"total={projected_total}c) → {candidate_action}"
                    + (f" ({cap.reason})" if cap.reason else "")
                )

    if chosen_action == "allow":
        reasons.append(
            f"All caps within budget (call={projected_cents}c, "
            f"model={call.model}, scope={scope_key})"
        )
        window_spend_before = 0
        window_spend_after = projected_cents

    # 5. Apply enforcement mode. In SHADOW mode, downgrade with the same cap
    #    to 'shadow' (log only, do not block or rewrite).
    effective_action: SpendAction = chosen_action
    if policy.mode == "shadow" and chosen_action in ("block", "downgrade"):
        effective_action = "shadow"

    # 6. On downgrade, the customer pays for the RESOLVED model.
    charged_cents = projected_cents
    if effective_action == "downgrade" and model_resolved != call.model:
        downgraded_cost = compute_call_cents(
            model_resolved, call.inputTokens, call.outputTokens
        )
        if downgraded_cost is not None:
            charged_cents = downgraded_cost

    if effective_action in ("allow", "downgrade"):
        windows_to_track: set[SpendWindow] = {c.window for c in policy.caps}
        for w in windows_to_track:
            await store.increment_window_spend(scope_key, w, charged_cents)

    return SpendDecision(
        decisionId=decision_id,
        timestamp=timestamp,
        action=effective_action,
        triggeredCap=triggered_cap,
        triggeredScopeKey=triggered_scope_key,
        projectedCents=projected_cents,
        windowSpendBefore=window_spend_before,
        windowSpendAfter=window_spend_after,
        provider=call_provider,
        modelRequested=call.model,
        modelResolved=model_resolved,
        policyId=policy.id,
        policyVersion=policy.version,
        enforcementMode=policy.mode,
        reasons=reasons,
    )
