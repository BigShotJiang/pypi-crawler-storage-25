"""
AgentGuard Spend — one-line install API.

The simplest path from `pip install agentguard-spend` to a working
wrapped client. Handles keypair generation, policy construction,
in-memory stores, and the wrap — all from a single function call with
sensible defaults.

Example:
    from openai import OpenAI
    from agentguard_spend import easy_install

    client = easy_install(OpenAI(), daily_cap_dollars=20)
    # done. every call is now policy-checked and signed.
"""
from __future__ import annotations

import pathlib
import socket
import sys
from datetime import datetime, timezone
from typing import Any, Optional, Union

from .types import SpendCap, SpendPolicy, SpendScope
from .spend_guard import SigningKeys, SpendGuardConfig, with_spend_guard
from .store_memory import InMemorySpendStore
from .store_filesystem import FilesystemDecisionLogStore
from .decision_log import InMemoryDecisionLogStore, generate_keypair


_HOME_DIR = pathlib.Path("~/.agentguard").expanduser()


def _default_agent_id() -> str:
    host = socket.gethostname().split(".")[0] or "host"
    script = pathlib.Path(sys.argv[0]).stem if sys.argv else "python"
    return f"{host}-{script}"


def _default_tenant_id() -> str:
    host = socket.gethostname().split(".")[0] or "host"
    return f"{host}-tenant"


def _ensure_keypair(tenant_id: str) -> tuple[bytes, bytes]:
    tenant_dir = _HOME_DIR / tenant_id
    private_path = tenant_dir / "private.key"
    public_path = tenant_dir / "public.key"

    if private_path.is_file() and public_path.is_file():
        return private_path.read_bytes(), public_path.read_bytes()

    tenant_dir.mkdir(parents=True, exist_ok=True)
    private_key, public_key = generate_keypair()
    private_path.write_bytes(private_key)
    public_path.write_bytes(public_key)
    try:
        private_path.chmod(0o600)
    except OSError:
        pass
    return private_key, public_key


def _dollars_to_cents(amount: Union[int, float]) -> int:
    return int(round(float(amount) * 100))


def easy_install(
    client: Any,
    *,
    daily_cap_dollars: Union[int, float],
    soft_cap_dollars: Optional[Union[int, float]] = None,
    downgrade_to: Optional[str] = None,
    per_minute_cap_dollars: Optional[Union[int, float]] = None,
    agent_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
    enforce: bool = True,
    locale: Optional[str] = None,
) -> Any:
    """
    One-line setup for AgentGuard Spend.

    Wraps any OpenAI, Anthropic, OpenAI-compatible (OpenRouter, Together,
    Groq, Anyscale, vLLM), or AWS Bedrock client with a sensible default
    policy. Auto-generates and persists an Ed25519 signing keypair on
    first call.

    Required:
        client: the provider SDK client to wrap
        daily_cap_dollars: hard daily ceiling in USD

    Optional:
        soft_cap_dollars: daily soft cap; calls above this downgrade
        downgrade_to: model to downgrade to (requires soft_cap_dollars)
        per_minute_cap_dollars: per-minute burst guard
        agent_id, tenant_id, user_id: scope identifiers (auto-detected if None)
        enforce: True (block/downgrade) or False (shadow mode, log only)
        locale: 'en-US', 'es-419', or 'pt-BR' (auto-detected if None)

    Returns:
        The wrapped client. Use it exactly like the unwrapped one.

    Example:
        client = easy_install(OpenAI(), daily_cap_dollars=20)
        # raises AgentGuardBlockedError when daily spend exceeds $20
    """
    resolved_agent_id = agent_id or _default_agent_id()
    resolved_tenant_id = tenant_id or _default_tenant_id()
    private_key, public_key = _ensure_keypair(resolved_tenant_id)

    caps: list[SpendCap] = []

    if soft_cap_dollars is not None and downgrade_to is not None:
        caps.append(
            SpendCap(
                amountCents=_dollars_to_cents(soft_cap_dollars),
                window="per_day",
                action="downgrade",
                downgradeTo=downgrade_to,
                reason=f"Soft daily cap reached, routing to {downgrade_to}",
            )
        )
    elif soft_cap_dollars is not None and downgrade_to is None:
        raise ValueError(
            "easy_install: soft_cap_dollars requires downgrade_to. "
            "Pass downgrade_to='claude-haiku-4-5-20251001' or similar."
        )

    caps.append(
        SpendCap(
            amountCents=_dollars_to_cents(daily_cap_dollars),
            window="per_day",
            action="block",
            reason=f"Hard daily ceiling (${float(daily_cap_dollars):.2f}/day)",
        )
    )

    if per_minute_cap_dollars is not None:
        caps.append(
            SpendCap(
                amountCents=_dollars_to_cents(per_minute_cap_dollars),
                window="per_minute",
                action="block",
                reason=f"Per-minute burst guard (${float(per_minute_cap_dollars):.2f}/min)",
            )
        )

    policy = SpendPolicy(
        id=f"easy-install-{resolved_tenant_id}-v1",
        name=f"AgentGuard easy-install policy ({resolved_tenant_id})",
        scope=SpendScope(tenantId=resolved_tenant_id),
        caps=caps,
        mode="enforce" if enforce else "shadow",
        version=1,
        effectiveFrom=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
    )

    scope_kwargs: dict[str, str] = {"tenantId": resolved_tenant_id, "agentId": resolved_agent_id}
    if user_id:
        scope_kwargs["userId"] = user_id
    scope = SpendScope(**scope_kwargs)

    # v0.1.8+: default to PERSISTENT decision log so `agentguard serve`
    # dashboard can see real spend history. Spend store stays in-memory
    # (window state — rebuilt by reading the log on restart if needed).
    log_store = FilesystemDecisionLogStore(tenant_id=resolved_tenant_id)

    config_kwargs: dict[str, Any] = {
        "policy": policy,
        "spendStore": InMemorySpendStore(),
        "logStore": log_store,
        "signingKeys": SigningKeys(privateKey=private_key, publicKey=public_key),
    }
    if locale:
        config_kwargs["locale"] = locale
    config = SpendGuardConfig(**config_kwargs)

    return with_spend_guard(client, policy=policy, scope=scope, config=config)
