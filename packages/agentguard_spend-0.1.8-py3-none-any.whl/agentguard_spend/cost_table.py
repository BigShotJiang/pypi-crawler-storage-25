"""
AgentGuard(TM) Spend — Per-model cost table

Costs are USD cents per 1,000 tokens (integer math).
Values reflect publicly-listed pricing as of May 2026 and are intentionally
conservative (rounded UP) so spend caps fire early rather than late.

Customers can override this table via set_cost_override() when enterprise
contracts have negotiated rates that differ from public list pricing.

Licensed under the alpha evaluation license; see LICENSE in the package
root. Patent notice: Protected by U.S. patent-pending technology
(App. Nos. 63/983,615; 63/983,621; 63/983,843; 63/984,626;
64/071,781; 64/071,789).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from .types import Provider


@dataclass(frozen=True)
class ModelCost:
    """Per-1000-token cost in USD cents."""

    inputCentsPerKtok: float
    outputCentsPerKtok: float


# Default cost table. Values are list-price ceilings as of May 2026.
# Update via set_cost_override() for negotiated enterprise rates.
DEFAULT_COSTS: dict[str, ModelCost] = {
    # OpenAI
    "gpt-5":           ModelCost(0.5,   1.5),
    "gpt-5-mini":      ModelCost(0.05,  0.2),
    "gpt-4o":          ModelCost(0.25,  1.0),
    "gpt-4o-mini":     ModelCost(0.015, 0.06),

    # Anthropic
    "claude-opus-4-7":       ModelCost(2.0,  10.0),
    "claude-opus-4-6":       ModelCost(1.5,  7.5),
    "claude-sonnet-4-6":     ModelCost(0.3,  1.5),
    "claude-sonnet-4-5":     ModelCost(0.3,  1.5),
    "claude-haiku-4-5":      ModelCost(0.1,  0.5),

    # Google Gemini
    "gemini-3.1-pro-preview":     ModelCost(0.2,  1.0),
    "gemini-3-flash-preview":     ModelCost(0.02, 0.1),
    "gemini-3-pro-image-preview": ModelCost(0.4,  2.0),

    # AWS Bedrock - common models (us-east-1 ceilings)
    "anthropic.claude-opus-4-v1:0":   ModelCost(1.5,   7.5),
    "anthropic.claude-sonnet-4-v1:0": ModelCost(0.3,   1.5),
    "amazon.nova-pro-v1:0":           ModelCost(0.08,  0.32),
    "amazon.nova-lite-v1:0":          ModelCost(0.006, 0.024),
}

# Runtime override storage. Keyed by exact model name.
_overrides: dict[str, ModelCost] = {}


def set_cost_override(model: str, cost: ModelCost) -> None:
    """Override the cost for a specific model.

    Used when the customer has negotiated enterprise rates that differ from
    list pricing.
    """
    _overrides[model] = cost


def clear_cost_overrides() -> None:
    """Clear all cost overrides. Mainly for testing."""
    _overrides.clear()


def get_model_cost(model: str) -> Optional[ModelCost]:
    """Look up the cost for a model.

    Returns None if the model is unknown AND no override has been registered.
    Callers should treat unknown models defensively (e.g., by registering an
    override or by rejecting the call).
    """
    if model in _overrides:
        return _overrides[model]
    return DEFAULT_COSTS.get(model)


def compute_call_cents(
    model: str,
    input_tokens: int,
    output_tokens: int,
) -> Optional[int]:
    """Compute the cents this call would cost given input + output token counts.

    Returns None if the model is unknown (caller must decide how to handle).

    Formula:  cents = ceil( (cents_per_ktok * tokens) / 1000 )

    Rounds UP so caps fire conservatively (a call that would cost 19.4c
    counts as 20c against the budget).
    """
    cost = get_model_cost(model)
    if cost is None:
        return None
    input_cents = math.ceil((cost.inputCentsPerKtok * input_tokens) / 1000)
    output_cents = math.ceil((cost.outputCentsPerKtok * output_tokens) / 1000)
    return input_cents + output_cents


def infer_provider(model: str) -> Provider:
    """Infer the Provider enum from a model name.

    Used when callers do not pass provider explicitly. Returns 'unknown' if no
    pattern matches.
    """
    if model.startswith("gpt-") or model.startswith("o1") or model.startswith("o3"):
        return "openai"
    if model.startswith("claude-"):
        return "anthropic"
    if model.startswith("gemini-"):
        return "gemini"
    if "claude-" in model and "-v" in model:
        return "bedrock"
    if (
        model.startswith("amazon.")
        or model.startswith("anthropic.")
        or model.startswith("meta.")
    ):
        return "bedrock"
    return "unknown"
