"""
AgentGuard(TM) Spend — Signed hash-chained decision log

Each policy decision is appended to a tamper-evident log:
  entry_n.previousHash = SHA-256(canonical_json(entry_{n-1} minus signature))
  entry_n.entryHash    = SHA-256(canonical_json(entry_n minus signature))
  entry_n.signature    = Ed25519(privateKey, entryHash)

The log lives entirely in the customer runtime. The signing key never leaves
the customer environment. Public verification is performed by anyone with
the corresponding public key.

The log structure (sequence number, previousHash binding, canonical-JSON
serialization, Ed25519 signature) is the subject of a U.S. provisional
patent application filed by the applicant in May 2026.

Patent notice: Protected by U.S. patent-pending technology
(App. Nos. 63/983,615; 63/983,621; 63/983,843; 63/984,626;
64/071,781; 64/071,789).
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from typing import Any, Optional, Union

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)

from .types import DecisionLogStore, SignedDecisionLogEntry, SpendDecision

GENESIS_PREVIOUS_HASH = "0" * 64


def canonical_json(value: Any) -> str:
    """Deterministic JSON serialization.

    Object keys are sorted, no insignificant whitespace, no NaN / Infinity.
    Required for stable hashing across runtimes. Matches the TypeScript
    canonicalJson() in src/decision-log.ts byte-for-byte for the value shapes
    used by AgentGuard Spend (integers, ASCII strings, arrays, objects,
    nulls).
    """
    if value is None:
        return "null"
    if isinstance(value, bool):
        # bool must be checked BEFORE int (bool is a subclass of int in Python)
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("canonical_json: non-finite numbers are not permitted")
        # We don't use floats in serialized payloads. Reject to keep parity
        # with TS where Number.toString of an integer-valued float would
        # differ ("1.0" vs "1"). If a downstream payload ever needs floats,
        # add a JS-compatible formatter here.
        raise ValueError(
            "canonical_json: floats are not supported (use integer cents)"
        )
    if isinstance(value, str):
        # json.dumps with ensure_ascii=False matches JSON.stringify for the
        # control-character escapes and quote/backslash handling required by
        # the test surface (ASCII payloads). It does not escape U+2028 /
        # U+2029, matching modern V8 JSON.stringify behavior.
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(canonical_json(v) for v in value) + "]"
    if isinstance(value, dict):
        keys = sorted(value.keys())
        parts = [
            json.dumps(k, ensure_ascii=False, separators=(",", ":"))
            + ":"
            + canonical_json(value[k])
            for k in keys
        ]
        return "{" + ",".join(parts) + "}"
    raise TypeError(f"canonical_json: unsupported type {type(value).__name__}")


def sha256_hex(input_str: str) -> str:
    """SHA-256 of a string, returned as lowercase hex."""
    return hashlib.sha256(input_str.encode("utf-8")).hexdigest()


def compute_entry_hash(
    *,
    sequence: int,
    decision: Union[SpendDecision, dict[str, Any]],
    previous_hash: str,
) -> str:
    """Compute the entryHash for a decision and the previous hash.

    This is the value that gets signed.
    """
    decision_dict = (
        decision.to_dict() if isinstance(decision, SpendDecision) else decision
    )
    payload = canonical_json(
        {
            "sequence": sequence,
            "decision": decision_dict,
            "previousHash": previous_hash,
        }
    )
    return sha256_hex(payload)


def compute_signer_fingerprint(public_key: bytes) -> str:
    """Compute the public key fingerprint: first 8 bytes of SHA-256(pubkey), hex.

    Used for short identification of which key signed an entry.
    """
    return hashlib.sha256(public_key).hexdigest()[:16]


def _public_key_bytes(public_key: Union[bytes, Ed25519PublicKey]) -> bytes:
    if isinstance(public_key, Ed25519PublicKey):
        return public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)
    return public_key


def _private_key_from_seed(seed: Union[bytes, Ed25519PrivateKey]) -> Ed25519PrivateKey:
    if isinstance(seed, Ed25519PrivateKey):
        return seed
    if len(seed) != 32:
        raise ValueError(
            f"Ed25519 private seed must be 32 bytes, got {len(seed)} bytes"
        )
    return Ed25519PrivateKey.from_private_bytes(seed)


def _public_key_from_raw(
    public_key: Union[bytes, Ed25519PublicKey],
) -> Ed25519PublicKey:
    if isinstance(public_key, Ed25519PublicKey):
        return public_key
    return Ed25519PublicKey.from_public_bytes(public_key)


async def sign_decision(
    *,
    sequence: int,
    decision: SpendDecision,
    previous_hash: str,
    private_key: Union[bytes, Ed25519PrivateKey],
    public_key: Union[bytes, Ed25519PublicKey],
) -> SignedDecisionLogEntry:
    """Sign a decision and produce a SignedDecisionLogEntry.

    The private_key is a 32-byte Ed25519 secret seed (or a pre-built
    Ed25519PrivateKey). It MUST be generated and stored by the customer;
    AgentGuard Spend never sees or transmits it.
    """
    entry_hash = compute_entry_hash(
        sequence=sequence,
        decision=decision,
        previous_hash=previous_hash,
    )
    sk = _private_key_from_seed(private_key)
    sig_bytes = sk.sign(bytes.fromhex(entry_hash))
    pk_bytes = _public_key_bytes(public_key)
    return SignedDecisionLogEntry(
        sequence=sequence,
        decision=decision,
        previousHash=previous_hash,
        entryHash=entry_hash,
        signature=sig_bytes.hex(),
        signerFingerprint=compute_signer_fingerprint(pk_bytes),
    )


async def verify_entry(
    entry: SignedDecisionLogEntry,
    public_key: Union[bytes, Ed25519PublicKey],
) -> bool:
    """Verify a single entry's signature and hash.

    Returns True iff the entryHash recomputes correctly AND the signature is
    valid for the given public key. Does NOT verify chain linkage (that's
    verify_chain's job).
    """
    expected_hash = compute_entry_hash(
        sequence=entry.sequence,
        decision=entry.decision,
        previous_hash=entry.previousHash,
    )
    if expected_hash != entry.entryHash:
        return False
    pk = _public_key_from_raw(public_key)
    try:
        pk.verify(bytes.fromhex(entry.signature), bytes.fromhex(entry.entryHash))
        return True
    except InvalidSignature:
        return False
    except Exception:
        return False


@dataclass
class ChainVerificationResult:
    ok: bool
    sequence: Optional[int] = None
    reason: Optional[str] = None


async def verify_chain(
    entries: list[SignedDecisionLogEntry],
    public_key: Union[bytes, Ed25519PublicKey],
) -> ChainVerificationResult:
    """Verify an entire chain of decision log entries.

    Returns ChainVerificationResult(ok=True) if every entry is valid AND each
    entry's previousHash matches the prior entry's entryHash, AND the genesis
    entry has GENESIS_PREVIOUS_HASH, AND sequences are strictly increasing
    starting at 0.

    Returns ChainVerificationResult(ok=False, sequence=..., reason=...) on
    the first detected fault.
    """
    if len(entries) == 0:
        return ChainVerificationResult(ok=True)

    for i, entry in enumerate(entries):
        if entry is None:
            return ChainVerificationResult(
                ok=False, sequence=i, reason=f"Missing entry at index {i}"
            )
        expected_seq = entries[0].sequence if i == 0 else entries[i - 1].sequence + 1
        if entry.sequence != expected_seq:
            return ChainVerificationResult(
                ok=False,
                sequence=entry.sequence,
                reason=f"Sequence gap: expected {expected_seq}, got {entry.sequence}",
            )
        expected_prev = (
            GENESIS_PREVIOUS_HASH if i == 0 else entries[i - 1].entryHash
        )
        if entry.previousHash != expected_prev:
            return ChainVerificationResult(
                ok=False,
                sequence=entry.sequence,
                reason=(
                    f"previousHash mismatch at sequence {entry.sequence}: "
                    f"expected {expected_prev}, got {entry.previousHash}"
                ),
            )
        ok = await verify_entry(entry, public_key)
        if not ok:
            return ChainVerificationResult(
                ok=False,
                sequence=entry.sequence,
                reason=f"Signature or hash invalid at sequence {entry.sequence}",
            )

    return ChainVerificationResult(ok=True)


def generate_keypair() -> tuple[bytes, bytes]:
    """Generate a fresh Ed25519 keypair.

    Returns (private_seed, public_key) as raw 32-byte values. The caller is
    responsible for storing the private seed securely (HSM, KMS, Vault).
    """
    sk = Ed25519PrivateKey.generate()
    seed = sk.private_bytes(
        encoding=Encoding.Raw,
        format=PrivateFormat.Raw,
        encryption_algorithm=NoEncryption(),
    )
    pk = sk.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    return seed, pk


def public_key_from_seed(private_seed: bytes) -> bytes:
    """Derive the raw 32-byte Ed25519 public key from a 32-byte private seed."""
    sk = Ed25519PrivateKey.from_private_bytes(private_seed)
    return sk.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)


class InMemoryDecisionLogStore(DecisionLogStore):
    """In-memory decision log store.

    Useful for tests, examples, and short-lived shadow deployments. Production
    callers will typically supply their own implementation that writes to a
    database table or append-only file.
    """

    def __init__(self) -> None:
        self._entries: list[SignedDecisionLogEntry] = []

    async def append(self, entry: SignedDecisionLogEntry) -> None:
        self._entries.append(entry)

    async def get_latest(self) -> Optional[SignedDecisionLogEntry]:
        if not self._entries:
            return None
        return self._entries[-1]

    async def read(
        self, from_sequence: int, limit: int
    ) -> list[SignedDecisionLogEntry]:
        start = next(
            (i for i, e in enumerate(self._entries) if e.sequence >= from_sequence),
            -1,
        )
        if start == -1:
            return []
        return self._entries[start : start + limit]

    def snapshot(self) -> list[SignedDecisionLogEntry]:
        """Returns a defensive copy of all entries. Mainly for testing."""
        return list(self._entries)
