"""
AgentGuard Spend — Anthropic binding

Wraps an anthropic.Anthropic / AsyncAnthropic client so that
`messages.create` enforces the spend policy locally before any network call
is made.

Usage:
    from anthropic import Anthropic
    from agentguard_spend import SpendPolicy, SpendScope
    from agentguard_spend.bindings import with_anthropic_spend_guard

    anthropic_client = Anthropic()
    guarded = with_anthropic_spend_guard(
        anthropic_client,
        policy=policy,
        scope=SpendScope(tenantId="acme", userId="alice"),
    )
    response = guarded.messages.create(
        model="claude-opus-4-7",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Optional

from ..cost_table import infer_provider
from ..spend_guard import (
    AgentGuardBlockedError,
    SpendGuard,
    SpendGuardConfig,
    _serialize_messages,
)
from ..types import CallContext, CapabilityTier, SpendPolicy, SpendScope
from .openai_binding import _run_coro_sync


class _GuardedAnthropicClient:
    def __init__(
        self,
        client: Any,
        guard: SpendGuard,
        scope: SpendScope,
        capability_claim: Optional[CapabilityTier],
    ) -> None:
        self._client = client
        self._guard = guard
        self._scope = scope
        self._capability_claim = capability_claim
        self._messages = _MessagesProxy(client.messages, guard, scope, capability_claim)
        client._agentguard = guard  # type: ignore[attr-defined]

    def __getattr__(self, name: str) -> Any:
        if name == "messages":
            return self._messages
        return getattr(self._client, name)


class _MessagesProxy:
    def __init__(
        self,
        messages: Any,
        guard: SpendGuard,
        scope: SpendScope,
        capability_claim: Optional[CapabilityTier],
    ) -> None:
        self._messages = messages
        self._guard = guard
        self._scope = scope
        self._capability_claim = capability_claim

    def create(self, **params: Any) -> Any:
        underlying = self._messages.create
        if inspect.iscoroutinefunction(underlying):
            return self._async_create(params)
        return self._sync_create(params)

    def _decide(self, params: dict[str, Any]) -> CallContext:
        input_text = _serialize_messages(params.get("messages", []))
        if "system" in params and isinstance(params["system"], str):
            input_text = params["system"] + "\n" + input_text
        input_tokens = self._guard.estimate_tokens(input_text)
        max_tokens = params.get("max_tokens")
        output_tokens = max_tokens if isinstance(max_tokens, int) else 1024
        model = params.get("model") or "unknown"
        provider = infer_provider(model) or "anthropic"
        return CallContext(
            provider=provider,
            model=model,
            inputTokens=input_tokens,
            outputTokens=output_tokens,
            scope=self._scope,
            capabilityClaim=self._capability_claim,
            label=(params.get("metadata") or {}).get("label")
            if isinstance(params.get("metadata"), dict)
            else None,
        )

    def _sync_create(self, params: dict[str, Any]) -> Any:
        call = self._decide(params)
        decision, _signed = _run_coro_sync(self._guard.decide(call))
        if decision.action == "block":
            raise AgentGuardBlockedError(decision, scope=self._scope)
        if (
            decision.action == "downgrade"
            and decision.modelResolved != decision.modelRequested
        ):
            params = {**params, "model": decision.modelResolved}
        return self._messages.create(**params)

    async def _async_create(self, params: dict[str, Any]) -> Any:
        call = self._decide(params)
        decision, _signed = await self._guard.decide(call)
        if decision.action == "block":
            raise AgentGuardBlockedError(decision, scope=self._scope)
        if (
            decision.action == "downgrade"
            and decision.modelResolved != decision.modelRequested
        ):
            params = {**params, "model": decision.modelResolved}
        return await self._messages.create(**params)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._messages, name)


def with_anthropic_spend_guard(
    client: Any,
    *,
    policy: SpendPolicy,
    scope: SpendScope,
    capabilityClaim: Optional[CapabilityTier] = None,
    config: Optional[SpendGuardConfig] = None,
) -> Any:
    """Wrap an Anthropic client. Returns a proxy whose messages.create
    enforces the spend policy.
    """
    if config is None:
        guard_config = SpendGuardConfig(policy=policy)
    else:
        guard_config = SpendGuardConfig(
            policy=policy,
            spendStore=config.spendStore,
            logStore=config.logStore,
            signingKeys=config.signingKeys,
            onDecision=config.onDecision,
            tokenEstimator=config.tokenEstimator,
        )
    guard = SpendGuard(guard_config)
    if not hasattr(client, "messages"):
        raise TypeError(
            "with_anthropic_spend_guard: expected an Anthropic client with "
            "messages.create. For OpenAI or Bedrock, use the matching binding."
        )
    return _GuardedAnthropicClient(client, guard, scope, capabilityClaim)
