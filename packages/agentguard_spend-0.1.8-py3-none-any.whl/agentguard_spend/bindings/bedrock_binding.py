"""
AgentGuard Spend — AWS Bedrock binding

Wraps a boto3 bedrock-runtime client so that `invoke_model` and
`converse` enforce the spend policy locally before any network call is
made.

Usage:
    import boto3
    from agentguard_spend import SpendPolicy, SpendScope
    from agentguard_spend.bindings import with_bedrock_spend_guard

    bedrock = boto3.client("bedrock-runtime")
    guarded = with_bedrock_spend_guard(
        bedrock,
        policy=policy,
        scope=SpendScope(tenantId="acme"),
    )
    response = guarded.invoke_model(
        modelId="anthropic.claude-sonnet-4-v1:0",
        body=b'{"messages":[{"role":"user","content":"hi"}]}',
    )
"""

from __future__ import annotations

import json
from typing import Any, Optional

from ..cost_table import infer_provider
from ..spend_guard import (
    AgentGuardBlockedError,
    SpendGuard,
    SpendGuardConfig,
)
from ..types import CallContext, CapabilityTier, SpendPolicy, SpendScope
from .openai_binding import _run_coro_sync


def _approximate_token_count(text: str) -> int:
    # Same heuristic as the default SpendGuard token estimator.
    if not text:
        return 0
    return max(1, (len(text) + 3) // 4)


def _summarize_invoke_body(body: Any) -> tuple[str, int]:
    """Best-effort extraction of input text + max_tokens from a Bedrock body.

    The Bedrock invoke_model body shape varies by provider. We handle:
      - Anthropic Claude on Bedrock: {"messages": [...], "max_tokens": N}
      - Amazon Nova / Titan: {"inputText": "..."} or {"messages": [...]}
      - Generic: any string -> length-based estimate
    """
    if isinstance(body, (bytes, bytearray)):
        try:
            body_obj = json.loads(body.decode("utf-8"))
        except Exception:
            return body.decode("utf-8", errors="replace"), 1024
    elif isinstance(body, str):
        try:
            body_obj = json.loads(body)
        except Exception:
            return body, 1024
    elif isinstance(body, dict):
        body_obj = body
    else:
        return "", 1024

    parts: list[str] = []
    if isinstance(body_obj, dict):
        if isinstance(body_obj.get("messages"), list):
            for m in body_obj["messages"]:
                content = m.get("content") if isinstance(m, dict) else None
                if isinstance(content, str):
                    parts.append(content)
                elif isinstance(content, list):
                    for piece in content:
                        if isinstance(piece, dict) and isinstance(piece.get("text"), str):
                            parts.append(piece["text"])
        if isinstance(body_obj.get("inputText"), str):
            parts.append(body_obj["inputText"])
        if isinstance(body_obj.get("system"), str):
            parts.append(body_obj["system"])

        max_tokens = body_obj.get("max_tokens") or body_obj.get("maxTokens") or 1024
        if not isinstance(max_tokens, int):
            max_tokens = 1024
    else:
        max_tokens = 1024

    return "\n".join(parts), max_tokens


class _GuardedBedrockClient:
    def __init__(
        self,
        client: Any,
        guard: SpendGuard,
        scope: SpendScope,
        capability_claim: Optional[CapabilityTier],
    ) -> None:
        self._client = client
        self._guard = guard
        self._scope = scope
        self._capability_claim = capability_claim

    def __getattr__(self, name: str) -> Any:
        # We only intercept invoke_model and converse; everything else passes
        # through to the underlying boto3 client.
        if name == "invoke_model":
            return self._invoke_model
        if name == "converse":
            return self._converse
        return getattr(self._client, name)

    def _build_call(
        self,
        *,
        model_id: str,
        input_text: str,
        max_tokens: int,
    ) -> CallContext:
        provider = infer_provider(model_id) or "bedrock"
        input_tokens = self._guard.estimate_tokens(input_text)
        return CallContext(
            provider=provider,
            model=model_id,
            inputTokens=input_tokens,
            outputTokens=max_tokens,
            scope=self._scope,
            capabilityClaim=self._capability_claim,
        )

    def _run_decision(self, call: CallContext) -> Any:
        return _run_coro_sync(self._guard.decide(call))

    def _invoke_model(self, **kwargs: Any) -> Any:
        model_id = kwargs.get("modelId") or "unknown"
        body = kwargs.get("body")
        input_text, max_tokens = _summarize_invoke_body(body)
        call = self._build_call(
            model_id=model_id, input_text=input_text, max_tokens=max_tokens
        )
        decision, _signed = self._run_decision(call)
        if decision.action == "block":
            raise AgentGuardBlockedError(decision, scope=self._scope)
        if (
            decision.action == "downgrade"
            and decision.modelResolved != decision.modelRequested
        ):
            kwargs = {**kwargs, "modelId": decision.modelResolved}
        return self._client.invoke_model(**kwargs)

    def _converse(self, **kwargs: Any) -> Any:
        model_id = kwargs.get("modelId") or "unknown"
        messages = kwargs.get("messages") or []
        parts: list[str] = []
        for m in messages:
            content = m.get("content") if isinstance(m, dict) else None
            if isinstance(content, list):
                for piece in content:
                    if isinstance(piece, dict) and isinstance(piece.get("text"), str):
                        parts.append(piece["text"])
            elif isinstance(content, str):
                parts.append(content)
        input_text = "\n".join(parts)
        inference_config = kwargs.get("inferenceConfig") or {}
        max_tokens = inference_config.get("maxTokens", 1024)
        call = self._build_call(
            model_id=model_id, input_text=input_text, max_tokens=max_tokens
        )
        decision, _signed = self._run_decision(call)
        if decision.action == "block":
            raise AgentGuardBlockedError(decision, scope=self._scope)
        if (
            decision.action == "downgrade"
            and decision.modelResolved != decision.modelRequested
        ):
            kwargs = {**kwargs, "modelId": decision.modelResolved}
        return self._client.converse(**kwargs)


def with_bedrock_spend_guard(
    client: Any,
    *,
    policy: SpendPolicy,
    scope: SpendScope,
    capabilityClaim: Optional[CapabilityTier] = None,
    config: Optional[SpendGuardConfig] = None,
) -> Any:
    """Wrap a boto3 bedrock-runtime client.

    The wrapped client is API-compatible with the underlying boto3 client
    for every operation EXCEPT `invoke_model` and `converse`, which go
    through the policy engine first.
    """
    if config is None:
        guard_config = SpendGuardConfig(policy=policy)
    else:
        guard_config = SpendGuardConfig(
            policy=policy,
            spendStore=config.spendStore,
            logStore=config.logStore,
            signingKeys=config.signingKeys,
            onDecision=config.onDecision,
            tokenEstimator=config.tokenEstimator,
        )
    guard = SpendGuard(guard_config)
    if not (hasattr(client, "invoke_model") or hasattr(client, "converse")):
        raise TypeError(
            "with_bedrock_spend_guard: expected a boto3 bedrock-runtime client "
            "with invoke_model or converse."
        )
    return _GuardedBedrockClient(client, guard, scope, capabilityClaim)
