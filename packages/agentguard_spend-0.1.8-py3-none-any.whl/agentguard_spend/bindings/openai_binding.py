"""
AgentGuard Spend — OpenAI binding

Wraps an OpenAI v1+ client (sync or async) so that chat.completions.create
enforces the spend policy locally before any network call is made. Other
endpoints pass through unchanged.

Usage:
    from openai import OpenAI
    from agentguard_spend import SpendPolicy, SpendScope
    from agentguard_spend.bindings import with_openai_spend_guard

    openai_client = OpenAI()
    guarded = with_openai_spend_guard(
        openai_client,
        policy=policy,
        scope=SpendScope(tenantId="acme", userId="alice"),
    )
    completion = guarded.chat.completions.create(model="gpt-4o", messages=[...])
"""

from __future__ import annotations

import asyncio
import inspect
import threading
from typing import Any, Optional

from ..spend_guard import (
    AgentGuardBlockedError,
    BindingOptions,
    SpendGuard,
    SpendGuardConfig,
    _serialize_messages,
)
from ..cost_table import infer_provider
from ..types import CallContext, CapabilityTier, SpendPolicy, SpendScope


def _run_coro_sync(coro: Any) -> Any:
    """Run an awaitable to completion from a sync context.

    Works whether or not the caller is already inside a running event loop.
    When a loop is already running, the coroutine is executed on a fresh loop
    in a worker thread so we don't deadlock on the caller's loop.
    """
    try:
        asyncio.get_running_loop()
        in_loop = True
    except RuntimeError:
        in_loop = False
    if not in_loop:
        return asyncio.run(coro)
    result: list[Any] = []
    error: list[BaseException] = []

    def runner() -> None:
        try:
            result.append(asyncio.run(coro))
        except BaseException as e:  # noqa: BLE001 — re-raised on caller thread
            error.append(e)

    t = threading.Thread(target=runner, daemon=True)
    t.start()
    t.join()
    if error:
        raise error[0]
    return result[0]


class _GuardedOpenAIClient:
    """Proxy wrapper around an OpenAI client.

    Intercepts `chat.completions.create`. Any other attribute access is
    delegated to the underlying client unchanged.
    """

    def __init__(
        self,
        client: Any,
        guard: SpendGuard,
        scope: SpendScope,
        capability_claim: Optional[CapabilityTier],
    ) -> None:
        self._client = client
        self._guard = guard
        self._scope = scope
        self._capability_claim = capability_claim
        self._chat_proxy = _ChatProxy(client.chat, guard, scope, capability_claim)
        # Attach guard for introspection / hydration. Note: single underscore
        # avoids Python's class-scope name mangling that mangles `__x` writes
        # inside a class body.
        client._agentguard = guard  # type: ignore[attr-defined]

    def __getattr__(self, name: str) -> Any:
        if name == "chat":
            return self._chat_proxy
        return getattr(self._client, name)


class _ChatProxy:
    def __init__(
        self,
        chat: Any,
        guard: SpendGuard,
        scope: SpendScope,
        capability_claim: Optional[CapabilityTier],
    ) -> None:
        self._chat = chat
        self._completions = _CompletionsProxy(
            chat.completions, guard, scope, capability_claim
        )

    def __getattr__(self, name: str) -> Any:
        if name == "completions":
            return self._completions
        return getattr(self._chat, name)


class _CompletionsProxy:
    def __init__(
        self,
        completions: Any,
        guard: SpendGuard,
        scope: SpendScope,
        capability_claim: Optional[CapabilityTier],
    ) -> None:
        self._completions = completions
        self._guard = guard
        self._scope = scope
        self._capability_claim = capability_claim

    def create(self, **params: Any) -> Any:
        """Intercept chat.completions.create.

        Works against both sync OpenAI clients (returns the response) and
        async clients (returns a coroutine).
        """
        underlying = self._completions.create
        if inspect.iscoroutinefunction(underlying):
            return self._async_create(params)
        return self._sync_create(params)

    def _decide(self, params: dict[str, Any]) -> Any:
        input_text = _serialize_messages(params.get("messages", []))
        input_tokens = self._guard.estimate_tokens(input_text)
        max_tokens = params.get("max_tokens")
        output_tokens = max_tokens if isinstance(max_tokens, int) else 512
        model = params.get("model") or "unknown"
        provider = infer_provider(model)

        call = CallContext(
            provider=provider,
            model=model,
            inputTokens=input_tokens,
            outputTokens=output_tokens,
            scope=self._scope,
            capabilityClaim=self._capability_claim,
            label=(params.get("metadata") or {}).get("label"),
        )
        return call

    def _run_decision(self, call: CallContext) -> Any:
        return _run_coro_sync(self._guard.decide(call))

    def _sync_create(self, params: dict[str, Any]) -> Any:
        call = self._decide(params)
        decision, _signed = self._run_decision(call)
        if decision.action == "block":
            raise AgentGuardBlockedError(decision, scope=self._scope)
        if decision.action == "downgrade" and decision.modelResolved != decision.modelRequested:
            params = {**params, "model": decision.modelResolved}
        return self._completions.create(**params)

    async def _async_create(self, params: dict[str, Any]) -> Any:
        call = self._decide(params)
        decision, _signed = await self._guard.decide(call)
        if decision.action == "block":
            raise AgentGuardBlockedError(decision, scope=self._scope)
        if decision.action == "downgrade" and decision.modelResolved != decision.modelRequested:
            params = {**params, "model": decision.modelResolved}
        return await self._completions.create(**params)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._completions, name)


def with_openai_spend_guard(
    client: Any,
    *,
    policy: SpendPolicy,
    scope: SpendScope,
    capabilityClaim: Optional[CapabilityTier] = None,
    config: Optional[SpendGuardConfig] = None,
) -> Any:
    """Wrap an OpenAI client. Returns a proxy whose chat.completions.create
    enforces the spend policy.

    The wrapped client is API-compatible with the underlying OpenAI client
    for every endpoint EXCEPT chat.completions.create, which goes through
    the policy engine first.
    """
    if config is None:
        guard_config = SpendGuardConfig(policy=policy)
    else:
        guard_config = SpendGuardConfig(
            policy=policy,
            spendStore=config.spendStore,
            logStore=config.logStore,
            signingKeys=config.signingKeys,
            onDecision=config.onDecision,
            tokenEstimator=config.tokenEstimator,
        )
    guard = SpendGuard(guard_config)

    if not hasattr(client, "chat") or not hasattr(client.chat, "completions"):
        raise TypeError(
            "with_openai_spend_guard: expected an OpenAI client with "
            "chat.completions.create. For Anthropic or Bedrock, use "
            "with_anthropic_spend_guard or with_bedrock_spend_guard."
        )

    return _GuardedOpenAIClient(client, guard, scope, capabilityClaim)
