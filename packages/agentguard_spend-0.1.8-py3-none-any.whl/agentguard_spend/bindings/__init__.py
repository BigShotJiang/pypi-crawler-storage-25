"""Provider-SDK bindings for AgentGuard Spend.

Each binding wraps a specific provider client (OpenAI, Anthropic, Bedrock)
and intercepts its completion entry point to enforce a SpendPolicy locally
before any network call is made.

The peer SDKs are optional dependencies. Import the matching binding only
when you have the corresponding SDK installed.
"""

from .anthropic_binding import with_anthropic_spend_guard
from .bedrock_binding import with_bedrock_spend_guard
from .openai_binding import with_openai_spend_guard

__all__ = [
    "with_openai_spend_guard",
    "with_anthropic_spend_guard",
    "with_bedrock_spend_guard",
]
