"""
AgentGuard(TM) Spend — Python SDK

Local-runtime spend caps and capability-gated model routing for AI agents.
Prompts, API keys, and signing keys stay inside the customer runtime.
Zero data plane involvement.

Patent notice: Protected by U.S. patent-pending technology
(App. Nos. 63/983,615; 63/983,621; 63/983,843; 63/984,626;
64/071,781; 64/071,789).
"""

from __future__ import annotations

# Types
from .types import (
    CallContext,
    CapabilityTier,
    DecisionLogStore,
    EnforcementMode,
    Provider,
    SignedDecisionLogEntry,
    SpendAction,
    SpendCap,
    SpendDecision,
    SpendPolicy,
    SpendScope,
    SpendStore,
    SpendWindow,
)

# Cost table
from .cost_table import (
    DEFAULT_COSTS,
    ModelCost,
    clear_cost_overrides,
    compute_call_cents,
    get_model_cost,
    infer_provider,
    set_cost_override,
)

# Policy engine
from .policy import build_scope_key, evaluate_policy

# Decision log
from .decision_log import (
    ChainVerificationResult,
    GENESIS_PREVIOUS_HASH,
    InMemoryDecisionLogStore,
    canonical_json,
    compute_entry_hash,
    compute_signer_fingerprint,
    generate_keypair,
    public_key_from_seed,
    sha256_hex,
    sign_decision,
    verify_chain,
    verify_entry,
)

# Spend store
from .store_memory import InMemorySpendStore, window_start, WINDOW_DURATION_MS

# Filesystem-backed decision log store (v0.1.8+)
from .store_filesystem import FilesystemDecisionLogStore

# Core wrapper
from .spend_guard import (
    AgentGuardBlockedError,
    BindingOptions,
    SigningKeys,
    SpendGuard,
    SpendGuardConfig,
    format_blocked_trace,
    with_spend_guard,
)

# Localization (en-US, es-419, pt-BR)
from .i18n import (
    DEFAULT_LOCALE,
    SUPPORTED_LOCALES,
    TRANSLATIONS,
    resolve_locale,
    t,
)

# One-line install helper (v0.1.5+)
from .easy_install import easy_install

__version__ = "0.1.8"
AGENTGUARD_SPEND_VERSION = __version__

# Patent marking. 35 U.S.C. § 287 constructive notice.
PATENT_NOTICE = (
    "Protected by U.S. patent-pending technology "
    "(App. Nos. 63/983,615; 63/983,621; 63/983,843; 63/984,626; "
    "64/071,781; 64/071,789). "
    "Additional patents pending."
)

__all__ = [
    "__version__",
    "AGENTGUARD_SPEND_VERSION",
    "PATENT_NOTICE",
    # i18n
    "DEFAULT_LOCALE",
    "SUPPORTED_LOCALES",
    "TRANSLATIONS",
    "resolve_locale",
    "t",
    # easy_install
    "easy_install",
    # Filesystem store
    "FilesystemDecisionLogStore",
    # Types
    "CallContext",
    "CapabilityTier",
    "DecisionLogStore",
    "EnforcementMode",
    "Provider",
    "SignedDecisionLogEntry",
    "SpendAction",
    "SpendCap",
    "SpendDecision",
    "SpendPolicy",
    "SpendScope",
    "SpendStore",
    "SpendWindow",
    # Cost table
    "DEFAULT_COSTS",
    "ModelCost",
    "clear_cost_overrides",
    "compute_call_cents",
    "get_model_cost",
    "infer_provider",
    "set_cost_override",
    # Policy engine
    "build_scope_key",
    "evaluate_policy",
    # Decision log
    "ChainVerificationResult",
    "GENESIS_PREVIOUS_HASH",
    "InMemoryDecisionLogStore",
    "canonical_json",
    "compute_entry_hash",
    "compute_signer_fingerprint",
    "generate_keypair",
    "public_key_from_seed",
    "sha256_hex",
    "sign_decision",
    "verify_chain",
    "verify_entry",
    # Spend store
    "InMemorySpendStore",
    "WINDOW_DURATION_MS",
    "window_start",
    # Core wrapper
    "AgentGuardBlockedError",
    "BindingOptions",
    "SigningKeys",
    "SpendGuard",
    "SpendGuardConfig",
    "format_blocked_trace",
    "with_spend_guard",
]
