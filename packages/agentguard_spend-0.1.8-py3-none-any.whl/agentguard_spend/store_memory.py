"""
AgentGuard(TM) Spend — In-memory spend store

Reference implementation of the SpendStore interface. Suitable for tests,
examples, and single-process shadow deployments. Production callers with
multi-process or distributed workloads should supply their own store
(typically Redis with INCR, or Postgres with SELECT FOR UPDATE).

Licensed under the alpha evaluation license; see LICENSE in the package
root. Patent notice: Protected by U.S. patent-pending technology
(App. Nos. 63/983,615; 63/983,621; 63/983,843; 63/984,626;
64/071,781; 64/071,789).
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from .types import SpendStore, SpendWindow

WINDOW_DURATION_MS: dict[SpendWindow, int] = {
    "per_call": 0,
    "per_minute": 60_000,
    "per_hour": 3_600_000,
    "per_day": 86_400_000,
    "per_month": 30 * 86_400_000,  # approximate; production stores should use calendar-month boundaries
}


def window_start(window: SpendWindow, now_ms: int) -> int:
    """Returns the millisecond timestamp at which a window of the given
    duration containing `now_ms` started.

    For fixed-grid windows we align to UTC epoch (so all processes agree on
    window boundaries without coordination).
    """
    dur = WINDOW_DURATION_MS[window]
    if dur == 0:
        return now_ms
    return (now_ms // dur) * dur


def _now_ms() -> int:
    return int(time.time() * 1000)


@dataclass
class _WindowState:
    cents: int
    window_start_ms: int


class InMemorySpendStore(SpendStore):
    """In-memory spend store.

    Thread-safe in single-process Python under the GIL for the simple
    arithmetic this store performs. Production stores must provide their own
    atomicity guarantees.
    """

    def __init__(self) -> None:
        self._state: dict[str, _WindowState] = {}

    def _key(self, scope_key: str, window: SpendWindow) -> str:
        return f"{scope_key}::{window}"

    def _roll_if_stale(
        self, scope_key: str, window: SpendWindow, now_ms: int
    ) -> _WindowState:
        k = self._key(scope_key, window)
        expected_start = window_start(window, now_ms)
        existing = self._state.get(k)
        if existing is None or existing.window_start_ms != expected_start:
            fresh = _WindowState(cents=0, window_start_ms=expected_start)
            self._state[k] = fresh
            return fresh
        return existing

    async def get_window_spend(self, scope_key: str, window: SpendWindow) -> int:
        state = self._roll_if_stale(scope_key, window, _now_ms())
        return state.cents

    async def increment_window_spend(
        self, scope_key: str, window: SpendWindow, cents: int
    ) -> int:
        state = self._roll_if_stale(scope_key, window, _now_ms())
        state.cents += cents
        return state.cents

    def reset(self) -> None:
        """Clear all state. Test helper."""
        self._state.clear()
