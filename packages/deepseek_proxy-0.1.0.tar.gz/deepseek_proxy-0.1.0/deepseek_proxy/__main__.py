from deepseek_proxy import main
main()
