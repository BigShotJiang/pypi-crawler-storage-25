from ..biblioteca import *
from typing import Optional
from dacite import from_dict
from ..Domain.Entity.CatalogoBot import CatalogoBot

class controllerAxis:
    def gerar_Token(self, data: dict) -> str:
        url = f"{Enviroment.PRODUCAO.value}/api/Login"

        try:
            # Usando a biblioteca nativa requests para fazer o POST
            response = requests.post(url, json=data)
            response.raise_for_status()
            
            # Lê o JSON de resposta
            return response.json()
            
        except requests.exceptions.RequestException as e:
            return None

    def consultar_catalogo_bot(self, id_bot: str, token: str) -> Optional[CatalogoBot]:
        url = f"{Enviroment.PRODUCAO.value}/api/CatalogoBot/{id_bot}"

        headers = {
            "Authorization": f"Bearer {token}"
        }

        try:
            # GET autenticado com Bearer token
            response = requests.get(url, headers=headers)
            response.raise_for_status()

            # Desserializa o JSON na entidade CatalogoBot
            return from_dict(data_class=CatalogoBot, data=response.json())

        except requests.exceptions.RequestException as e:
            return None