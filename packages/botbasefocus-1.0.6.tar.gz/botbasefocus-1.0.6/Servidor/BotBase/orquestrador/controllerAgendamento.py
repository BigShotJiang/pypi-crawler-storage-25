from ..biblioteca import *

class ControllerAgendamento:
    # Orquestrador    
    def _grava_log_erro(self, log: logErro):
        url = f"{self.Enviroment.PRODUCAO.value}/api/LogErroPY"
        data = {"_id": "", "id_agendamento": log.id_agendamento, "mensagem": log.mensagem, "imagem": log.path_imagem_erro, "id_bot": self.id_bot}
        response = httpx.post(url, json=data)

        return response

    # Orquestrador
    def _grava_agendamento(self, agend: Agendamento):
        url = f"{self.Enviroment.PRODUCAO.value}/api/AgendamentoPY"
        try:
            # Converte o objeto Agendamento em dicionário
            payload = asdict(agend)
            
            print(payload)
            # Envia o POST com o JSON diretamente
            response = httpx.post(url, json=payload)

            # Verifica o status da resposta
            response.raise_for_status()

            # Retorna a resposta (ou processe conforme necessário)
            return response

        except httpx.RequestError as exc:
            print(f"Erro na requisição para {url}: {exc}")
            if(self.agendamento.status == None):
                print("Agendamento está vazio!")
            raise

        except httpx.HTTPStatusError as exc:
            print(f"Erro HTTP {exc.response.status_code} ao acessar {url}: {exc}")
            raise

    # Orquestrador
    async def _get_agendamento(self, id_bot: str) -> Agendamento:
        url = f"{self.Enviroment.PRODUCAO.value}/api/AgendamentoPY/{id_bot}?host={os.environ.get('COMPUTERNAME', 'localhost')}&user_name={os.environ.get('USERNAME')}"

        response = httpx.get(url)
        # Verificar se a resposta foi bem-sucedida
        if response.status_code == 200:
            try:
                # Se o código for 200, tentamos converter o JSON
                dados_dict = response.json()  # Tenta obter o JSON da resposta
                
                # Convertendo o JSON para uma instância de Agendamento
                self.agendamento = dacite.from_dict(data_class=Agendamento, data=dados_dict)
                return self.agendamento  # Retorna o agendamento processado
                
            except httpx.JSONDecodeError:
                print("Erro: O corpo da resposta não é um JSON válido.")
                return None
        else:
            print(f"Erro: A requisição falhou com o status {response.status_code}.")
            print(f"Detalhes do erro: {response.text}")
            return None  # Em caso de erro, retorna None

    # Orquestrador
    async def adicionar_anexo_agendamento(self, porcentagem=0):
        try:
            # Caminho do arquivo
            arquivo_path = fr'C:\bots\temp\{self.agendamento._id}.txt'
            
            # Verificar se o arquivo existe
            if not os.path.exists(arquivo_path):
                raise FileNotFoundError(f"Arquivo não encontrado: {arquivo_path}")
            
            # Ler o arquivo em modo binário
            with open(arquivo_path, "rb") as f:
                conteudo_arquivo = f.read()

            # Codificar em Base64
            arquivo_base64 = base64.b64encode(conteudo_arquivo).decode('utf-8')
            
            # Atualizar as propriedades do objeto agendamento
            self.agendamento.porcentagem = porcentagem
            self.agendamento.anexo = arquivo_base64

        except Exception as e:
            # Log do erro para depuração
            print(f"Erro ao adicionar anexo ao agendamento: {e}")
            raise
                                            
    # Orquestrador
    async def apagar_arquivo(self, path_arquivo):
        if os.path.exists(path_arquivo) and os.path.isfile(path_arquivo):
            try:
                os.remove(path_arquivo)
            except Exception:
                pass

    # Orquestrador
    async def alteraStatusAgendamento(self, Status):
        self.agendamento.status = Status
        self._grava_agendamento(self.agendamento)