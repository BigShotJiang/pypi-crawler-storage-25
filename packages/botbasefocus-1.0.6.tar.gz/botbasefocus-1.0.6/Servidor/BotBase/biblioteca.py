# ==========================================
# Bibliotecas Padrão do Python (Built-ins)
# ==========================================
import os
import sys
import io
import json
import time
import shutil
import zipfile
import tempfile
import base64
import subprocess
import ctypes
from ctypes import wintypes
from typing import Optional, List, Any
from dataclasses import dataclass, asdict
from enum import Enum

# Configura para o padrão do sistema
import platform
import locale
locale.setlocale(locale.LC_ALL, '')
arch = "win64" if platform.machine().endswith('64') else "win32"
idioma, codificacao = locale.getlocale()

# ==========================================
# Bibliotecas de Terceiros
# ==========================================
import httpx
import requests
import dacite
import psutil
import pyautogui

# ==========================================
# Automação Web
# ==========================================
import undetected_chromedriver as uc
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ==========================================
# Automação RPA (BotCity)
# ==========================================
from botcity.core import DesktopBot
from botcity.web import WebBot

# ==========================================
# Classe de Entidades
# ==========================================
from .Domain.Entity import *
from .Domain.VO import *