from .biblioteca import *

# Importação de classes estruturais
from .sistemas import *
from .service import service


class BotBase(service):        
    def __init__(self, id_bot):
        super().__init__() 

        # Declaração de variáveis
        self._parametros = []
        self.id_bot: str = id_bot
        self._id_agendamento: str = ''

        # Instância das bibliotecas de Bot
        self.bot = DesktopBot()
        self.bot_web = WebBot()

        self.agendamento = None
        
    # Função principal de execução do Bot
    async def executa_bot(self, abreSistema):
        
        await self.alteraStatusAgendamento(Status=Status.EXECUTANDO.value)

        try:
            if abreSistema:
                self.sistema_ativo = carregar_sistema("Dominio", core=self)
                await self.sistema_ativo.executa_login()

            # Executa o bot principal da automação
            await self.executa_bot_especifico()

            if os.path.exists(fr'C:\bots\temp\{self.agendamento._id}.txt'):
                await self.adicionar_anexo_agendamento(fr'C:\bots\temp\{self.agendamento._id}.txt')
                await self.apagar_arquivo(fr'C:\bots\temp\{self.agendamento._id}.txt')

            await self.alteraStatusAgendamento(Status=Status.CONCLUIDO.value)
        except Exception as e:
            if os.path.exists(fr'C:\bots\temp\{self.agendamento._id}.txt'):
                await self.adicionar_anexo_agendamento(fr'C:\bots\temp\{self.agendamento._id}.txt')
                await self.apagar_arquivo(fr'C:\bots\temp\{self.agendamento._id}.txt')

            await self.alteraStatusAgendamento(Status=Status.ERRO.value)
        finally:
            if abreSistema:
                await self.fecharTaskUser('contabil.exe')
                await self.StopBrowser()
    