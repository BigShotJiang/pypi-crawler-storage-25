from enum import Enum

class Status(Enum):
    AGUARDANDO = "Aguardando"
    EXECUTANDO = "Executando"
    CONCLUIDO = "Concluido"
    ERRO = "Erro"