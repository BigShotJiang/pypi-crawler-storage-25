from enum import Enum

class Enviroment(Enum):
    #PRODUCAO = "http://192.168.25.6:8021"
    #PRODUCAO = "localhost:8021"
    PRODUCAO = "https://backorquestradorrpa.sistemasfocuscontabil.com"