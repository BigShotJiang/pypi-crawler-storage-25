from dataclasses import dataclass
from typing import Any

@dataclass
class ParametroEtapa:
    nomeParametro: str
    valor: Any
    tipo: str