from dataclasses import dataclass

@dataclass
class Execucao:
    intervalo: str
    hora_inicio: str
    hora_fim: str