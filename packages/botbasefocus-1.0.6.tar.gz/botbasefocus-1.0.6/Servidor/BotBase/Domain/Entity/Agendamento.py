from dataclasses import dataclass
from typing import Optional, List
from .etapa import Etapa
from .Execucao import Execucao

@dataclass
class Agendamento:
    _id: str
    mensagem: str
    id_bot: str
    nome_bot: str
    path_bot: str
    descricao_bot: str
    dataHoraExecucao: str
    dataHoraCadastro: str
    status: str
    periodo: Optional[str]
    user_name: Optional[str]
    host: Optional[str]
    sessao: Optional[str]
    dataHorarioInicioExecucao: Optional[str]
    modulo: str
    porcentagem: Optional[int]
    anexo: Optional[str]
    nomeAnexo: Optional[str] 
    etapa: List[Etapa]
    tipo_sistema: Optional[str]
    execucao_teste: bool
    ambiente: str
    execucao: Execucao