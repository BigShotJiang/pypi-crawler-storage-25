from dataclasses import dataclass
from typing import Optional, List

@dataclass
class CatalogoBot:
    _id: str
    nome_bot: str
    path_bot: str
    descricao_bot: str
    modulo: str
    etapa: List
    ambiente: str
    anexo: Optional[str]
    nomeAnexo: Optional[str]
    dataHoraCadastro: Optional[str]
    usuarioCadastro: Optional[str]
    dataHoraAlteracao: Optional[str]
    usuarioAlteracao: Optional[str]
