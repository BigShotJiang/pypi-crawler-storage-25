from dataclasses import dataclass
from typing import Optional, List
from .parametroEtapa import ParametroEtapa

@dataclass
class Etapa:
    nome: Optional[str]
    descricao: str
    parametroEtapa: List[ParametroEtapa]