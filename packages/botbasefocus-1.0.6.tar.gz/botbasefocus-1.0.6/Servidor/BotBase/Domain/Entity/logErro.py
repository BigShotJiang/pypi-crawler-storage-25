from dataclasses import dataclass

@dataclass
class logErro:
    _id: str
    id_agendamento: str
    mensagem: str
    path_imagem_erro: str
    id_bot: str
    dataHoraErro: str