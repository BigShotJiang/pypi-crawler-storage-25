from .biblioteca import *
from .orquestrador import *


class Browser():
    def __init__(self, nome_projeto="FocusContabilidade"):
        # Local central para os binários (Um para o computador inteiro)
        self.base_path = os.path.abspath(os.path.join(os.getenv('PROGRAMDATA'), nome_projeto))
        self.pasta_binarios = os.path.join(self.base_path, 'binarios')
        
        # Caminhos fixos e únicos dinâmicos por arquitetura
        self.chrome_exe = os.path.join(self.pasta_binarios, f'chrome-{arch}', 'chrome.exe')
        self.driver_exe = os.path.join(self.pasta_binarios, 'chromedriver.exe')

        os.makedirs(self.pasta_binarios, exist_ok=True)

    def _garantir_binarios(self):
        if os.path.exists(self.chrome_exe) and os.path.exists(self.driver_exe):
            return

        res = requests.get("https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json").json()
        v_main = int(res['channels']['Stable']['version'].split('.')[0])
        
        urls = res['channels']['Stable']['downloads']
        # Busca a URL certa para a arquitetura atual (win32 ou win64)
        url_chromium = next(i['url'] for i in urls['chrome'] if i['platform'] == arch)
        url_chromedriver = next(i['url'] for i in urls['chromedriver'] if i['platform'] == arch)

        def download(url, is_driver=False):
            r = requests.get(url)
            with zipfile.ZipFile(io.BytesIO(r.content)) as z:
                z.extractall(self.pasta_binarios)
            if is_driver:
                nome_pasta_zip = f'chromedriver-{arch}'
                origem = os.path.join(self.pasta_binarios, nome_pasta_zip, 'chromedriver.exe')
                shutil.move(origem, self.driver_exe)
                shutil.rmtree(os.path.join(self.pasta_binarios, nome_pasta_zip))

        download(url_chromium)
        download(url_chromedriver, True)
        return v_main

    def _iniciar_navegador(self, nome_perfil="focus", pos_x=0, pos_y=0):
        """
        Inicia o navegador. 
        'nome_perfil' permite que você rode vários ao mesmo tempo (sessao_1, sessao_2...)
        """
        v_main = self._garantir_binarios()
        
        perfil_path = os.path.join(self.base_path, "perfis", nome_perfil)
        download_path = os.path.join(self.base_path, "downloads", nome_perfil)
        
        os.makedirs(perfil_path, exist_ok=True)
        os.makedirs(download_path, exist_ok=True)

        chrome_options = uc.ChromeOptions()
        
        chrome_options.add_argument(f"--user-data-dir={perfil_path}")
        
        chrome_options.add_argument(f"--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v_main}.0.0.0 Safari/537.36")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-notifications")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--kiosk-printing")

        prefs = {
            "download.default_directory": download_path,
            "savefile.default_directory": download_path,
            "download.prompt_for_download": False,
            "printing.print_preview_sticky_settings.appState": json.dumps({
                "recentDestinations": [{"id": "Save as PDF", "origin": "local", "account": ""}],
                "selectedDestinationId": "Save as PDF",
                "version": 2
            })
        }
        chrome_options.add_experimental_option("prefs", prefs)

        driver = uc.Chrome(
            options=chrome_options,
            browser_executable_path=self.chrome_exe,
            driver_executable_path=self.driver_exe,
            use_subprocess=True
        )

        if pos_x != 0 and pos_y != 0:
            driver.set_window_size(683, 384)
            driver.set_window_position(pos_x, pos_y)
        else:
            driver.maximize_window()

        return driver

    async def StartBrowser(self, nome_perfil="focus", pos_x=0, pos_y=0):
        return self._iniciar_navegador(nome_perfil, pos_x, pos_y)

    async def StopBrowser(self):
        if hasattr(self, "driver") and self.driver:
            try:
                self.driver.quit()
            except Exception as e:
                print(f"Erro ao tentar encerrar o navegador: {e}")
            finally:
                self.driver = None


class service(Browser, ControllerAgendamento):
    def RecuperaHostName(self) -> str:
        # Diretório onde o script está
        diretorio_atual = os.path.dirname(os.path.abspath(__file__))

        # Caminho completo para o arquivo
        arquivo = os.path.join(diretorio_atual, "hostname.json")

        # Exemplo: ler o arquivo
        with open(arquivo, 'r', encoding='utf-8') as f:
            dados = json.load(f)
            host = dados.get('host')
        return host

    def find_element(self, selector, element=None, wait=30, by_type='css'):
        if by_type == 'xpath':
            return WebDriverWait(element or self.driver, wait).until(
                EC.presence_of_element_located((By.XPATH, selector))
            )
        else:
            return WebDriverWait(element or self.driver, wait).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, selector))
            )

    def type_slowly(self, text, delay=0.1):
        # Mapeamento de dead keys para o layout ABNT2
        DEAD_KEY_MAP = {
            'á': ('a'), 'Á': ('A'),
            'é': ('e'), 'É': ('E'),
            'í': ('i'), 'Í': ('I'),
            'ó': ('o'), 'Ó': ('O'),
            'ú': ('u'), 'Ú': ('U'),
            'ã': ('a'), 'Ã': ('A'),
            'õ': ('o'), 'Õ': ('O'),
            'à': ('a'), 'À': ('A'),
            'â': ('a'), 'Â': ('A'),
            'ê': ('e'), 'Ê': ('E'),
            'ô': ('o'), 'Ô': ('O'),
        }

        text = str(text)
        try:
            delay = float(delay)
        except ValueError:
            delay = 0.1  # fallback se delay inválido

        for char in text:
            if char in DEAD_KEY_MAP:
                base = DEAD_KEY_MAP[char]
                # envia letra base
                pyautogui.write(base)
            else:
                pyautogui.write(char)
            time.sleep(delay)

    def found(self, label):
        with open(fr'C:\bots\temp\{self.agendamento._id}.txt', 'a') as file:
            file.write(label + '\n')

    def not_found(self, label):
        erros = []
        screenshot = pyautogui.screenshot()
        img_bytes = io.BytesIO()
        screenshot.save(img_bytes, format='PNG')
        img_base64 = base64.b64encode(img_bytes.getvalue()).decode('utf-8')
        erros.append({"Erro": label, "image": f"data:image/png;base64,{img_base64}"})
        httpErro = logErro(_id='',
                            id_agendamento= self.agendamento._id,
                            mensagem =label,
                            path_imagem_erro = erros[0]['image'],
                            id_bot = self.id_bot,
                            dataHoraErro = '')
        
        resposta = self._grava_log_erro(httpErro)
        return resposta

    async def fecharTaskUser(self, app):
        usuario_atual = psutil.Process().username()  # Obtém o usuário atual no formato esperado

        for proc in psutil.process_iter(attrs=['name', 'username']):
            try:
                if proc.info['name'] == app and proc.info['username'] == usuario_atual:
                    proc.terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
    
    def MonitorarCursorCarregamento(self, duration=10):
        class CURSORINFO(ctypes.Structure):
            _fields_ = [
                ("cbSize", wintypes.DWORD),
                ("flags", wintypes.DWORD),
                ("hCursor", wintypes.HANDLE),
                ("ptScreenPos", wintypes.POINT)
            ]

        IDC_WAIT = 32514
        IDC_APPSTARTING = 32650

        def is_cursor_loading():
            user32 = ctypes.windll.user32
            cursor_info = CURSORINFO()
            cursor_info.cbSize = ctypes.sizeof(CURSORINFO)

            if user32.GetCursorInfo(ctypes.byref(cursor_info)):
                return cursor_info.hCursor in (
                    user32.LoadCursorW(0, IDC_WAIT),
                    user32.LoadCursorW(0, IDC_APPSTARTING)
                )
            return False

        while True:
            start_time = time.time()
            while time.time() - start_time < duration:
                if is_cursor_loading():
                    break
                time.sleep(0.1)
            else:
                return