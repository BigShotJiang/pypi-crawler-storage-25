from .biblioteca import *

class BotBase:
    def __init__(self):
        # Declaração das bibliotecas de Bot
        self.bot = DesktopBot()
        self.idioma, self.codificacao = locale.getlocale()
        self.pasta_download = str(Path.home() / "Downloads")

    async def executa_bot(self, abreDominio, LoginDominio):
        if abreDominio:
            await self.executa_login(LoginDominio)
        await self.executa_bot_especifico()
            
    async def StartBrowser(self):
        chrome_options = uc.ChromeOptions()
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        #chrome_options.add_argument("--headless=new")  # Executa o navegador em modo headless (sem interface gráfica)
        #chrome_options.add_argument("--disable-gpu") # Necessário para headless no Windows
        chrome_options.add_argument("--window-size=1920,1080")  # Define tamanho da tela
        chrome_options.add_argument("--disable-extensions") # Desativa extensões
        chrome_options.add_argument("--disable-notifications") # Desativa notificações
        chrome_options.add_argument("--disable-dev-shm-usage") # Evita problemas de memória
        chrome_options.add_argument("--disable-infobars") # Remove a barra de informações "Chrome is being controlled by automated test software"

        os.makedirs(self.pasta_download, exist_ok=True)

        chrome_options.add_experimental_option("prefs", {
        "download.default_directory": self.pasta_download,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
        })
        
        self.driver = uc.Chrome(
            options=chrome_options, 
            use_subprocess=True
        )

    async def StopBrowser(self):
        if hasattr(self, "driver") and self.driver:
            try:
                self.driver.quit()  # Encerra o navegador e libera os recursos
            except Exception as e:
                print(f"Erro ao tentar encerrar o navegador: {e}")
            finally:
                self.driver = None  # Garante que o atributo `driver` não seja reutilizado

    async def _abre_sistema(self, login_web, senha_web):
        await self.StartBrowser()
        #acessar o site
        self.driver.get(r"https://www.dominioweb.com.br/")
        # acessar pagina de login
        self.find_element('//*[@id="enterButton"]', by_type='xpath').click()
        #login
        self.find_element('//*[@id="username"]', by_type='xpath').clear()
        self.find_element('//*[@id="username"]', by_type='xpath').send_keys(login_web)
        self.find_element('[name="action"]').click()
        self.find_element('//*[@id="password"]', by_type='xpath').clear()
        self.find_element('//*[@id="password"]', by_type='xpath').send_keys(senha_web)
        self.find_element('[name="action"]').click()

        if self.idioma == "en_US":
            if not self.bot.find_text(fr"login\open_ing", matching=0.83, waiting_time=20000):
                self.not_found(fr"login\open_ing")
            self.bot.wait(2000)
            self.bot.double_click()
        elif self.idioma == "pt_BR":
            if not self.bot.find_text(fr"login\open_pt", matching=0.83, waiting_time=20000):
                self.not_found(fr"login\open_pt")
            self.bot.wait(2000)
            self.bot.double_click()

    async def _abrir_modulo(self, login_dominio, senha_dominio, Dominio):
#        await self._abrir_modulo(self.get_nome_modulo())
        if not self.bot.find_text(fr"login\btn{Dominio}Dominio", matching=0.97, waiting_time=120000):
            self.not_found(fr"login\btn{Dominio}Dominio")
        self.bot.double_click()

        if not self.bot.find_text(r"login\inputNomeUsuarioDominio", matching=0.97, waiting_time=50000):
            self.not_found(r"login\inputNomeUsuarioDominio")
        self.bot.click_relative(130, 10)
        self.type_slowly(login_dominio)
        
        if not self.bot.find_text(r"login\inputSenhaDominio", matching=0.97, waiting_time=10000):
            self.not_found(r"login\inputSenhaDominio")
        self.bot.click_relative(130, 10)
        self.type_slowly(senha_dominio)

        if not self.bot.find_text(r"login\btnOkLoginDominio", matching=0.97, waiting_time=10000):
            self.not_found(r"login\btnOkLoginDominio")
        self.bot.click()

        self._mensagens_modulos()

    async def _abrir_modulo_local(self, login_dominio, senha_dominio, Dominio):
        subprocess.run(fr'start "" "C:\\Contabil\\contabil.exe" /{Dominio}', shell=True)
        
        if not self.bot.find_text(r"login\inputNomeUsuarioDominio", matching=0.97, waiting_time=50000):
            self.not_found(r"login\inputNomeUsuarioDominio")
        self.bot.double_click_relative(130, 10)
        self.type_slowly(login_dominio)
        
        if not self.bot.find_text(r"login\inputSenhaDominio", matching=0.97, waiting_time=10000):
            self.not_found(r"login\inputSenhaDominio")
        self.bot.double_click_relative(130, 10)
        self.type_slowly(senha_dominio)

        if not self.bot.find_text(r"login\btnOkLoginDominio", matching=0.97, waiting_time=10000):
            self.not_found(r"login\btnOkLoginDominio")
        self.bot.click()

        self._mensagens_modulos()

    def _mensagens_modulos(self):
        if self.bot.find_text(r"login\ancAvisoSenha", matching=0.97, waiting_time=10000):    
            if not self.bot.find_text(r"login\btnOkAvisoInicio", matching=0.97, waiting_time=10000):
                self.not_found(r"login\btnOkAvisoInicio")
            self.bot.click()

        self.bot.wait(30000)

        if self.bot.find_text(r"login\ancAvisoSemParametrosemp", matching=0.97, waiting_time=1000):
            if not self.bot.find_text(r"login\btnOKAviso", matching=0.97, waiting_time=10000):
                self.not_found(r"login\btnOKAviso")
            self.bot.click()
            if not self.bot.find_text(r"login\btnNao", matching=0.97, waiting_time=10000):
                self.not_found(r"login\btnNao")
            self.bot.click()
 
    # Trocar entre lojas no sistema dominio
    def alterarEmpresa_old(self, Cod):
        if self.bot.find_text(r"TrocarEmpresa\logoDominio", matching=0.97, waiting_time=10000):
            self.bot.click()            
            for _ in range(5):
                pyautogui.hotkey('alt', 'n')
                pyautogui.hotkey('esc')
                time.sleep(1)

            pyautogui.press('F8')

        if self.bot.find_text(r"TrocarEmpresa\btnBuscarPorCodigoLoja", matching=0.97, waiting_time=3000):
            self.bot.click()
        
        if self.bot.find_text(r"TrocarEmpresa\ancBuscarPorCodigoLoja", matching=0.97, waiting_time=10000):
            self.type_slowly(Cod)
            pyautogui.press('enter')
        self.bot.wait(2000)

        for _ in range(5):
            pyautogui.hotkey('alt', 'n')
            pyautogui.hotkey('esc')
            time.sleep(1)  # Adiciona um pequeno atraso

    def alterarEmpresa(self, Cod):
            if self.bot.find_text(r"TrocarEmpresa\logoDominio", matching=0.97, waiting_time=10000):
                self.bot.click()            
                for _ in range(5):
                    pyautogui.hotkey('alt', 'n')
                    pyautogui.hotkey('esc')
                    pyautogui.hotkey('alt', 'o')
                    time.sleep(1)

                pyautogui.press('F8')

            if self.bot.find_text(r"TrocarEmpresa\ancBuscarPorCodigoLoja", matching=0.97, waiting_time=30000):
                pass
            else:
                return False
            
            if self.bot.find_text(r"TrocarEmpresa\btnBuscarPorCodigoLoja", matching=0.97, waiting_time=5000):
                self.bot.click()
            
            
            if self.bot.find_text(r"TrocarEmpresa\ancBuscarPorCodigoLoja", matching=0.97, waiting_time=5000):
                self.type_slowly(Cod)
                pyautogui.press('enter')

            self.MonitorarCursorCarregamento(3)

            tempo = 0
            tempo_max = 90
            while True:
                time.sleep(1)
                if not self.bot.find_text(r"TrocarEmpresa\ancBuscarPorCodigoLoja", matching=0.97, waiting_time=0):
                    break
                             
                if tempo < 4:
                    pyautogui.hotkey('alt', 'n')
                    pyautogui.hotkey('esc')
                    pyautogui.hotkey('alt', 'o')
                    time.sleep(1)
                tempo += 1
                if tempo > tempo_max:
                    return False
                
            
            self.MonitorarCursorCarregamento(3)

            return True



    def find_element(self, selector, element=None, wait=30, by_type='css'):
        if by_type == 'xpath':
            return WebDriverWait(element or self.driver, wait).until(
                EC.presence_of_element_located((By.XPATH, selector))
            )
        else:
            return WebDriverWait(element or self.driver, wait).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, selector))
            )

    def type_slowly(self, text, delay=0.1):
        # Mapeamento de dead keys para o layout ABNT2
        DEAD_KEY_MAP = {
            'á': ('a'), 'Á': ('A'),
            'é': ('e'), 'É': ('E'),
            'í': ('i'), 'Í': ('I'),
            'ó': ('o'), 'Ó': ('O'),
            'ú': ('u'), 'Ú': ('U'),
            'ã': ('a'), 'Ã': ('A'),
            'õ': ('o'), 'Õ': ('O'),
            'à': ('a'), 'À': ('A'),
            'â': ('a'), 'Â': ('A'),
            'ê': ('e'), 'Ê': ('E'),
            'ô': ('o'), 'Ô': ('O'),
        }

        text = str(text)
        try:
            delay = float(delay)
        except ValueError:
            delay = 0.1  # fallback se delay inválido

        for char in text:
            if char in DEAD_KEY_MAP:
                base = DEAD_KEY_MAP[char]
                # envia letra base
                pyautogui.write(base)
            else:
                pyautogui.write(char)
            time.sleep(delay)

    def found(self, label):
        with open(fr'.\log.txt', 'a') as file:
            file.write(label + '\n')

    def not_found(self, label):
        with open(fr'.\log.txt', 'a') as file:
            file.write(label + '\n')
                                            
    async def apagar_arquivo(self, path_arquivo):
        if os.path.exists(path_arquivo) and os.path.isfile(path_arquivo):
            try:
                os.remove(path_arquivo)
            except Exception:
                pass

    async def executa_login(self, LoginDominio):
        tarefas = ['contabil.exe']
        for tarefa in tarefas:
            await self.fecharTaskUser(tarefa)

        if LoginDominio['tipo_sistema'] == "virtual":
            await self._abre_sistema(login_web=LoginDominio['login_web'],
                                    senha_web=LoginDominio['senha_web'])
            
            await self._abrir_modulo(login_dominio=LoginDominio['login_dominio'],
                                    senha_dominio=LoginDominio['senha_dominio'],
                                    Dominio=LoginDominio['Dominio'])
                
        elif LoginDominio['tipo_sistema'] == "local":
            await self._abrir_modulo_local(login_dominio=LoginDominio['login_dominio'],
                                            senha_dominio=LoginDominio['senha_dominio'],
                                            Dominio=LoginDominio['Dominio'])
        self.MonitorarCursorCarregamento(3)

    async def fecharTaskUser(self, app):
        usuario_atual = psutil.Process().username()  # Obtém o usuário atual no formato esperado

        for proc in psutil.process_iter(attrs=['name', 'username']):
            try:
                if proc.info['name'] == app and proc.info['username'] == usuario_atual:
                    proc.terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

    def MonitorarCursorCarregamento(self, duration=10):
        class CURSORINFO(ctypes.Structure):
            _fields_ = [
                ("cbSize", wintypes.DWORD),
                ("flags", wintypes.DWORD),
                ("hCursor", wintypes.HANDLE),
                ("ptScreenPos", wintypes.POINT)
            ]

        IDC_WAIT = 32514
        IDC_APPSTARTING = 32650

        def is_cursor_loading():
            user32 = ctypes.windll.user32
            cursor_info = CURSORINFO()
            cursor_info.cbSize = ctypes.sizeof(CURSORINFO)

            if user32.GetCursorInfo(ctypes.byref(cursor_info)):
                return cursor_info.hCursor in (
                    user32.LoadCursorW(0, IDC_WAIT),
                    user32.LoadCursorW(0, IDC_APPSTARTING)
                )
            return False

        while True:
            start_time = time.time()
            while time.time() - start_time < duration:
                if is_cursor_loading():
                    break
                time.sleep(0.1)
            else:
                return        



