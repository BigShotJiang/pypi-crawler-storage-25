# Bibliotecas Padrão BOTBASE
import asyncio
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from botcity.core import DesktopBot
from botcity.web import WebBot
import pyautogui
import time
import os
import psutil
import locale
import subprocess
import undetected_chromedriver as uc 
locale.setlocale(locale.LC_ALL, '')  # Configura para o padrão do sistema
from ctypes import wintypes
import ctypes
import requests
from datetime import datetime
from pathlib import Path
