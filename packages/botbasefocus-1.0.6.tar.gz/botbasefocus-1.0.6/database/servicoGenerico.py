from typing import List, Any
from dataclasses import asdict
from database.ServicoPadrao import ServicoPadrao

class ServicoGenerico(ServicoPadrao):
    """
    Inserir e Deletar qualquer Entity baseada em Dataclass.
    """
    
    # Gerencia a conexão e a transação
    def __init__(self, connection_string: str, lista_entities: List[Any], nome_tabela: str, campo_id: str = "id"):
        super().__init__(connection_string)
        
        self.dados = lista_entities
        self.tabela = nome_tabela
        self.campo_id = campo_id  # chave primária

    def valida_parametros(self, tipo_operacao):
        """
        Sobrescreve validação do pai.
        Se não tiver dados para processar, gera erro e aborta.
        """
        if not self.dados:
            self.lista_erro.adiciona_erro("GEN001", f"A lista de dados para a tabela {self.tabela} está vazia.")

    def executar_operacao_especifica(self):
        """
        REALIZA O INSERT (BULK INSERT).
        Lógica: Descobre as colunas olhando para o primeiro objeto e monta o SQL.
        """
        if not self.dados: return

        try:
            # Passo 1: Introspecção (Olhar para o objeto e ver quais campos ele tem)
            primeiro_objeto = self.dados[0]
            dict_modelo = asdict(primeiro_objeto)

            # Passo 2: Filtrar colunas válidas
            # Regra: Só incluímos colunas que NÃO são None.
            # Isso é vital para campos Auto-Incremento (Identity) que estão como None no objeto.
            colunas_validas = [k for k, v in dict_modelo.items() if v is not None]

            # Passo 3: Montar o SQL Dinamicamente
            # Ex: "cnpj, razao_social, data_cadastro"
            colunas_str = ", ".join(colunas_validas)
            # Ex: "?, ?, ?"
            placeholders = ", ".join(["?"] * len(colunas_validas))
            
            sql = f"INSERT INTO {self.tabela} ({colunas_str}) VALUES ({placeholders})"

            # Passo 4: Preparar os valores (Extrair dados de todos os objetos)
            valores_lote = []
            for entity in self.dados:
                dicionario = asdict(entity)
                # Cria uma lista de valores na mesma ordem das colunas_validas
                linha = [dicionario[col] for col in colunas_validas]
                valores_lote.append(linha)

            # Passo 5: Execução Otimizada (Turbo Mode do SQL Server)
            self.cursor.fast_executemany = True
            self.cursor.executemany(sql, valores_lote)
            
            # O COMMIT é feito pelo ServicoPadrao automaticamente se não der erro.

        except Exception as e:
            # Captura erro técnico, loga e relança para o Pai fazer Rollback
            msg = f"Erro ao inserir em {self.tabela}: {str(e)}"
            self.lista_erro.adiciona_erro("SQL_ERR", msg)
            raise e

    def executar_exclusao_especifica(self):
        """
        REALIZA O DELETE.
        Lógica: Pega todos os IDs da lista e deleta de uma vez.
        """
        if not self.dados: return

        try:
            # Passo 1: Extrair IDs usando getattr (pois o nome do campo ID varia)
            ids_para_deletar = []
            for entity in self.dados:
                # Tenta pegar entity.id ou entity.Numero_Solicitacao, etc...
                valor = getattr(entity, self.campo_id, None)
                if valor is not None:
                    ids_para_deletar.append(valor)

            if not ids_para_deletar: return

            # Passo 2: Montar SQL "DELETE FROM Tabela WHERE id IN (?, ?, ?)"
            placeholders = ", ".join(["?"] * len(ids_para_deletar))
            sql = f"DELETE FROM {self.tabela} WHERE {self.campo_id} IN ({placeholders})"

            # Passo 3: Executar
            self.cursor.execute(sql, ids_para_deletar)

        except Exception as e:
            msg = f"Erro ao excluir de {self.tabela}: {str(e)}"
            self.lista_erro.adiciona_erro("SQL_DEL", msg)
            raise e