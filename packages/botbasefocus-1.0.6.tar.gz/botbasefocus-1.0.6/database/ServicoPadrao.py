from enum import Enum
import pyodbc
import logging

# Configuração básica de Log
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ServiceLayer")

class TipoOperacao(Enum):
    InserirOuAtualizar = 1
    Excluir = 2
    SemAcao = 0

class MensagemErro:
    def __init__(self, codigo, texto):
        self.codigo = codigo
        self.texto = texto

class ListaDeMensagens:
    def __init__(self):
        self._erros = []

    def adiciona_erro(self, codigo, texto):
        self._erros.append(MensagemErro(codigo, texto))

    def existe_erro(self):
        return len(self._erros) > 0

    def get_erros(self):
        return self._erros
    
    def limpar(self):
        self._erros = []

class ServicoPadrao:
    def __init__(self, connection_string):
        self.connection_string = connection_string
        self.conn = None
        self.cursor = None
        
        # Equivalente ao seu ListaErro
        self.lista_erro = ListaDeMensagens()
        
        # Configurações de controle
        self.controla_transacao_interna = True
        self.erro_inesperado_cod = "CRM00004"

    def _abrir_conexao(self):
        if self.conn is None:
            try:
                self.conn = pyodbc.connect(self.connection_string, autocommit=False) # autocommit=False é vital para transações manuais
                self.cursor = self.conn.cursor()
            except Exception as e:
                self.lista_erro.adiciona_erro("DB001", f"Erro ao conectar: {str(e)}")

    def executar_operacao_especifica(self):
        raise NotImplementedError("As classes filhas devem implementar executar_operacao_especifica")

    def executar_exclusao_especifica(self):
        raise NotImplementedError("As classes filhas devem implementar executar_exclusao_especifica")

    def valida_parametros(self, tipo_operacao):
        """Pode ser sobrescrito opcionalmente"""
        pass

    # O Fluxo Principal
    def executar_operacao(self, tipo_operacao=TipoOperacao.InserirOuAtualizar):
        self.lista_erro.limpar()
        self._abrir_conexao()

        # 1. Validação
        self.valida_parametros(tipo_operacao)

        if not self.lista_erro.existe_erro():
            try:
                # 2. Início da Transação (pyodbc faz implícito se autocommit=False, mas vamos garantir o controle)
                
                # 3. Execução Específica
                if tipo_operacao == TipoOperacao.Excluir:
                    self.executar_exclusao_especifica()
                else:
                    self.executar_operacao_especifica()

                # 4. Commit ou Rollback
                if self.controla_transacao_interna:
                    if not self.lista_erro.existe_erro():
                        self.conn.commit()
                        logger.info("Transação commitada com sucesso.")
                    else:
                        self.conn.rollback()
                        logger.warning("Erros encontrados. Rollback realizado.")

            except Exception as erro:
                if self.controla_transacao_interna and self.conn:
                    self.conn.rollback()
                
                msg_erro = str(erro)
                logger.error(f"Erro inesperado: {msg_erro}")
                self.lista_erro.adiciona_erro(self.erro_inesperado_cod, f"Ocorreu um erro inesperado: {msg_erro}")

        # Fecha conexão no final (Pattern Dispose)
        self.dispose()

    def dispose(self):
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
        self.conn = None
        self.cursor = None