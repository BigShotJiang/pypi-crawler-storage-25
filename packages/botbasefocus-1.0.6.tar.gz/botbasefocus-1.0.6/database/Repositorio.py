import pyodbc
import logging
from typing import List, Any, Optional

from database.ServicoPadrao import ServicoPadrao, TipoOperacao
from database.servicoGenerico import ServicoGenerico

logger = logging.getLogger("Repositorio")


class Repositorio:
    """
    Interface única e portátil para acesso ao banco SQL Server.

    Encapsula ServicoPadrao e ServicoGenerico, expondo métodos simples
    que podem ser usados em qualquer projeto sem reescrever lógica de banco.

    Uso:
        repo = Repositorio.from_params(server='...', database='...')
        # ou
        repo = Repositorio(connection_string='DRIVER=...;SERVER=...;...')

        dados   = repo.buscar('CCT001')
        erros   = repo.inserir([CCT001(Numero_Solicitacao='123')], 'CCT001', 'Numero_Solicitacao')
        erros   = repo.deletar([CCT001(Numero_Solicitacao='123')], 'CCT001', 'Numero_Solicitacao')
        erros   = repo.executar_sql("UPDATE CCT003 SET data_consulta=? WHERE cnpj=?", [('2024-01-01','00')])
    """

    # ------------------------------------------------------------------
    # Construtores
    # ------------------------------------------------------------------

    def __init__(self, connection_string: str):
        """Inicializa com uma connection string pyodbc já montada."""
        self.connection_string = connection_string

    @classmethod
    def from_params(
        cls,
        server: str,
        database: str,
        user: Optional[str] = None,
        password: Optional[str] = None,
        trusted_connection: bool = True,
        driver: str = '{ODBC Driver 17 for SQL Server}'
    ) -> 'Repositorio':
        """
        Cria o Repositorio a partir dos parâmetros de conexão.
        Se trusted_connection=True, usa autenticação Windows (sem user/password).
        """
        if trusted_connection:
            conn_str = (
                f'DRIVER={driver};'
                f'SERVER={server};'
                f'DATABASE={database};'
                f'Trusted_Connection=yes;'
            )
        else:
            conn_str = (
                f'DRIVER={driver};'
                f'SERVER={server};'
                f'DATABASE={database};'
                f'UID={user};'
                f'PWD={password};'
            )
        return cls(conn_str)

    # ------------------------------------------------------------------
    # Leitura
    # ------------------------------------------------------------------

    def buscar(self, tabela: str, condicao: Optional[str] = None, colunas: str = "*") -> List[dict]:
        """
        Retorna todos os registros de uma tabela como lista de dicts.

        Returns:
            Lista de dicts com os registros, ou [] em caso de erro.
        """
        conn = None
        cursor = None
        try:
            conn = pyodbc.connect(self.connection_string, autocommit=True)
            cursor = conn.cursor()

            query = f"SELECT {colunas} FROM {tabela}"
            if condicao:
                query += f" WHERE {condicao}"

            cursor.execute(query)

            if cursor.description:
                colunas = [col[0] for col in cursor.description]
                return [dict(zip(colunas, linha)) for linha in cursor.fetchall()]
            return []

        except Exception as e:
            logger.error(f"[Repositorio.buscar] Erro em '{tabela}': {e}")
            return []
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    # ------------------------------------------------------------------
    # Escrita via Entity (dataclass)
    # ------------------------------------------------------------------

    def inserir(
        self,
        entities: List[Any],
        tabela: str,
        campo_pk: str = 'id'
    ) -> List[str]:
        """
        Insere uma lista de entities (dataclasses) na tabela informada.
        Campos com valor None são omitidos automaticamente (ex: IDENTITY, GETDATE()).

        Args:
            entities:  Lista de dataclasses (ex: [CCT001(...), CCT001(...)])
            tabela:    Nome da tabela no banco (ex: 'CCT001')
            campo_pk:  Nome do campo PK — usado para omitir no INSERT se for IDENTITY

        Returns:
            Lista de mensagens de erro (vazia = sucesso).
        """
        if not entities:
            return []

        svc = ServicoGenerico(self.connection_string, entities, tabela, campo_pk)
        svc.executar_operacao(TipoOperacao.InserirOuAtualizar)
        return self._extrair_erros(svc)

    def deletar(
        self,
        entities: List[Any],
        tabela: str,
        campo_pk: str = 'id'
    ) -> List[str]:
        """
        Deleta registros da tabela com base no campo PK das entities.

        Args:
            entities:  Lista de dataclasses com o campo PK preenchido
            tabela:    Nome da tabela no banco (ex: 'CCT001')
            campo_pk:  Nome do campo PK usado no WHERE (ex: 'Numero_Solicitacao')

        Returns:
            Lista de mensagens de erro (vazia = sucesso).
        """
        if not entities:
            return []

        svc = ServicoGenerico(self.connection_string, entities, tabela, campo_pk)
        svc.executar_operacao(TipoOperacao.Excluir)
        return self._extrair_erros(svc)

    # ------------------------------------------------------------------
    # Escrita via SQL direto (UPDATE, DELETE customizado, etc.)
    # ------------------------------------------------------------------

    def executar_sql(
        self,
        sql: str,
        parametros: Optional[List[tuple]] = None,
        bulk: bool = False
    ) -> List[str]:
        """
        Executa um SQL arbitrário com controle de transação.
        Ideal para UPDATE e operações que não se encaixam no ServicoGenerico.

        Args:
            sql:         Query SQL com placeholders '?' (ex: "UPDATE CCT003 SET data_consulta=? WHERE cnpj=?")
            parametros:  Lista de tuplas de parâmetros.
                         - bulk=False → executa cada tupla individualmente (cursor.execute)
                         - bulk=True  → executa em lote (cursor.fast_executemany)
            bulk:        Se True, usa fast_executemany para melhor performance em lotes grandes.

        Returns:
            Lista de mensagens de erro (vazia = sucesso).
        """
        conn = None
        cursor = None
        erros = []
        try:
            conn = pyodbc.connect(self.connection_string, autocommit=False)
            cursor = conn.cursor()

            if parametros:
                if bulk:
                    cursor.fast_executemany = True
                    cursor.executemany(sql, parametros)
                else:
                    for params in parametros:
                        cursor.execute(sql, params)
            else:
                cursor.execute(sql)

            conn.commit()
            logger.info(f"[Repositorio.executar_sql] Commit OK.")

        except Exception as e:
            msg = f"[Repositorio.executar_sql] Erro: {e}"
            logger.error(msg)
            erros.append(msg)
            if conn:
                conn.rollback()
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

        return erros

    # ------------------------------------------------------------------
    # Utilitário interno
    # ------------------------------------------------------------------

    def _extrair_erros(self, svc: ServicoGenerico) -> List[str]:
        """Extrai mensagens de erro do ServicoGenerico após execução."""
        if svc.lista_erro.existe_erro():
            msgs = [f"[{e.codigo}] {e.texto}" for e in svc.lista_erro.get_erros()]
            for m in msgs:
                logger.error(m)
            return msgs 
        return []
