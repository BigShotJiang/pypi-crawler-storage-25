#!/usr/bin/env python3
"""
UI Server — supero.server with two automatic fixes.

Fix A — supero-ui.js auto-fetch (Bug #6):
    If supero-ui.js failed to download during setup (CDN unreachable, firewall,
    timeout), _download_ui_js() fails silently and the server starts without
    the file. The browser gets a 404, AppShell never loads, white screen forever.
    This handler intercepts every /supero-ui.js request and fetches the file
    from CDN inline before serving it. Thread-safe, retries on every request
    until successful. Falls back to a JS console.error shim if CDN is also
    unreachable at request time.

Fix B — supero:ready event (Bug #3):
    Babel Standalone (type="text/babel") fetches and transforms app.js via
    async XHR after DOMContentLoaded. supero-ui.js is large and may still be
    executing when Babel evals app.js. AppShell is a global set at the END of
    supero-ui.js execution — if it hasn't finished, AppShell is undefined.
    This handler appends a CustomEvent dispatch to supero-ui.js at serve time:
        window.__superoUILoaded = true;
        window.dispatchEvent(new CustomEvent("supero:ready"));
    app.js listens for this event instead of calling AppShell.render() bare.
    The flag __superoUILoaded handles the case where the event already fired.
"""

import os
import ssl
import threading
import urllib.request

os.chdir(os.path.dirname(os.path.abspath(__file__)))

from supero.server import SuperoRequestHandler, SuperoServer

# ── Config ────────────────────────────────────────────────────────────────────

_LIB_VER = os.getenv("SUPERO_LIB_VERSION", "1.0.2")
_CDN_URL  = f"https://cdn.supero.dev/web-ui/supero-ui-{_LIB_VER}.js"
_UI_JS    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "supero-ui.js")
_LOCK     = threading.Lock()

# Appended to supero-ui.js content at serve time (Fix B).
# Compact single-line to minimise served bytes.
_READY_SUFFIX = (
    b"\n;(function(){"
    b'if(typeof window!=="undefined"){'
    b"window.__superoUILoaded=true;"
    b'window.dispatchEvent(new CustomEvent("supero:ready"));'
    b"}})();\n"
)

# Disable SSL verification (matches supero.server default for dev environments)
ssl._create_default_https_context = ssl._create_unverified_context


# ── Auto-fetch helper (Fix A) ─────────────────────────────────────────────────

def _fetch_ui_js() -> bool:
    """
    Download supero-ui.js from CDN into the ui/ directory.
    Thread-safe — only one download runs at a time.
    Returns True on success, False on failure.
    """
    with _LOCK:
        # Re-check inside lock — another thread may have just finished
        if os.path.exists(_UI_JS) and os.path.getsize(_UI_JS) > 10_000:
            return True

        print(f"  ⬇  supero-ui.js missing — fetching from CDN: {_CDN_URL}")
        try:
            req = urllib.request.Request(
                _CDN_URL,
                headers={"User-Agent": "Mozilla/5.0 supero-server/auto-fetch"},
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read()

            with open(_UI_JS, "wb") as f:
                f.write(data)

            size_kb = len(data) // 1024
            print(f"  ✓  supero-ui.js ready ({size_kb} KB)")
            return True

        except Exception as exc:
            print(f"  ✗  CDN fetch failed: {exc}")
            # Remove partial file so next request retries cleanly
            if os.path.exists(_UI_JS):
                try:
                    os.remove(_UI_JS)
                except OSError:
                    pass
            return False


# ── Request handler ───────────────────────────────────────────────────────────

class _Handler(SuperoRequestHandler):
    """
    Extends SuperoRequestHandler with auto-fetch (Fix A) and
    supero:ready event injection (Fix B) for /supero-ui.js requests.
    All other requests are handled by the base class unchanged.
    """

    def do_GET(self):
        if self.path.startswith("/supero-ui.js"):
            # Fix A: ensure file exists
            if not (os.path.exists(_UI_JS) and os.path.getsize(_UI_JS) > 10_000):
                if not _fetch_ui_js():
                    self._serve_error_shim()
                    return
            # Fix B: serve with ready-event suffix
            self._serve_ui_js()
            return

        # All other requests handled normally (API proxy, static files, etc.)
        super().do_GET()

    def _serve_ui_js(self):
        """Serve supero-ui.js with supero:ready event appended."""
        try:
            with open(_UI_JS, "rb") as f:
                content = f.read()
        except OSError as exc:
            self._send_json(500, {"error": f"Could not read supero-ui.js: {exc}"})
            return

        body = content + _READY_SUFFIX

        self.send_response(200)
        self.send_header("Content-Type", "application/javascript; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=3600")
        self.end_headers()
        self.wfile.write(body)

    def _serve_error_shim(self):
        """
        Serve a JS console.error when CDN is completely unreachable.
        Visible in devtools — far better than a silent white screen.
        """
        msg = (
            f'console.error("[Supero] supero-ui.js could not be loaded. '
            f'CDN: {_CDN_URL}. '
            f'If this server has no CDN access, download it manually and '
            f'place it in the ui/ directory.");\n'
        ).encode()

        self.send_response(200)
        self.send_header("Content-Type", "application/javascript")
        self.send_header("Content-Length", str(len(msg)))
        self.end_headers()
        self.wfile.write(msg)


# ── Entry point ───────────────────────────────────────────────────────────────

port = int(os.getenv("PORT", os.getenv("UI_PORT", "5648")))
# PUBLIC_SCHEMAS — schemas.py is authoritative.
# An empty list there is a deliberate "no public schemas" signal and MUST
# be passed through as-is. Only fall back to the env var if the schemas.py
# import actually fails.
_pub = None
try:
    import sys as _sys
    _sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    from schemas import PUBLIC_SCHEMAS
    _pub = list(PUBLIC_SCHEMAS)
except Exception:
    _env_pub = [s.strip() for s in os.getenv("PUBLIC_SCHEMAS", "").split(",") if s.strip()]
    _pub = _env_pub if _env_pub else None
SuperoServer(port=port, handler_class=_Handler, public_schemas=_pub).serve()
