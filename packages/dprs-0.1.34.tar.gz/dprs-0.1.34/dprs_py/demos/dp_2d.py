#!/usr/bin/env python3

from dprs import sim
from dprs.utils import DUAL

print(f"\n{sim}")

class Parameters:
    growth_model = sim.GrowthModel.SimplifiedDomanyKinzel
    dim = sim.Dimension.D2
    n_x: int = 1_000
    n_y: int = 1_000
    n_z: int = 1
    p_1: float = 0.163145
    p_2: float = 0
    p_conj: float = 0
    p_nbr: float = 0.5
    p_diag: float = 0.5
    n_iterations: int = 1000
    sample_period: int  = 1000
    initial_condition = sim.InitialCondition.Randomized
    p_initial: float = 0.99
    random_seed: int = 1
    topology_x = sim.Topology.Periodic
    topology_y = sim.Topology.Periodic
    topology_z = sim.Topology.Unspecified
    bcs_x = (sim.BoundaryCondition.Floating, sim.BoundaryCondition.Floating)
    bcs_y = (sim.BoundaryCondition.Floating, sim.BoundaryCondition.Floating)
    bcs_z = (sim.BoundaryCondition.Unspecified, sim.BoundaryCondition.Unspecified)
    bc_values_x = (DUAL.OCCUPIED.state, DUAL.OCCUPIED.state)
    bc_values_y = (DUAL.OCCUPIED.state, DUAL.OCCUPIED.state)
    bc_values_z = (DUAL.EMPTY.state, DUAL.EMPTY.state)
    do_edge_buffering: bool = True
    processing = sim.Processing.Parallel
    n_threads: int = 16
parameters = Parameters()

_ = sim.dk(parameters)