# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Type, Optional, cast

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._wrappers import DataWrapper
from ...types.alpha import inference_rerank_params
from ..._base_client import make_request_options
from ...types.alpha.inference_rerank_response import InferenceRerankResponse

__all__ = ["InferenceResource", "AsyncInferenceResource"]


class InferenceResource(SyncAPIResource):
    """OGX Inference API for generating completions, chat completions, and embeddings.

    This API provides the raw interface to the underlying models. Three kinds of models are supported:
    - LLM models: these models generate "raw" and "chat" (conversational) completions.
    - Embedding models: these models generate embeddings to be used for semantic search.
    - Rerank models: these models reorder the documents based on their relevance to a query.
    """

    @cached_property
    def with_raw_response(self) -> InferenceResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/ogx-ai/ogx-client-python#accessing-raw-response-data-eg-headers
        """
        return InferenceResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> InferenceResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/ogx-ai/ogx-client-python#with_streaming_response
        """
        return InferenceResourceWithStreamingResponse(self)

    def rerank(
        self,
        *,
        items: SequenceNotStr[inference_rerank_params.Item],
        model: str,
        query: inference_rerank_params.Query,
        max_num_results: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceRerankResponse:
        """
        Rerank a list of documents based on their relevance to a query.

        Args:
          items: List of items to rerank. Each item can be a string, text content part, or image
              content part.

          model: The identifier of the reranking model to use.

          query: The search query to rank items against. Can be a string, text content part, or
              image content part.

          max_num_results: Maximum number of results to return. Default: returns all.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1alpha/inference/rerank",
            body=maybe_transform(
                {
                    "items": items,
                    "model": model,
                    "query": query,
                    "max_num_results": max_num_results,
                },
                inference_rerank_params.InferenceRerankParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                post_parser=DataWrapper[InferenceRerankResponse]._unwrapper,
            ),
            cast_to=cast(Type[InferenceRerankResponse], DataWrapper[InferenceRerankResponse]),
        )


class AsyncInferenceResource(AsyncAPIResource):
    """OGX Inference API for generating completions, chat completions, and embeddings.

    This API provides the raw interface to the underlying models. Three kinds of models are supported:
    - LLM models: these models generate "raw" and "chat" (conversational) completions.
    - Embedding models: these models generate embeddings to be used for semantic search.
    - Rerank models: these models reorder the documents based on their relevance to a query.
    """

    @cached_property
    def with_raw_response(self) -> AsyncInferenceResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/ogx-ai/ogx-client-python#accessing-raw-response-data-eg-headers
        """
        return AsyncInferenceResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncInferenceResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/ogx-ai/ogx-client-python#with_streaming_response
        """
        return AsyncInferenceResourceWithStreamingResponse(self)

    async def rerank(
        self,
        *,
        items: SequenceNotStr[inference_rerank_params.Item],
        model: str,
        query: inference_rerank_params.Query,
        max_num_results: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InferenceRerankResponse:
        """
        Rerank a list of documents based on their relevance to a query.

        Args:
          items: List of items to rerank. Each item can be a string, text content part, or image
              content part.

          model: The identifier of the reranking model to use.

          query: The search query to rank items against. Can be a string, text content part, or
              image content part.

          max_num_results: Maximum number of results to return. Default: returns all.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1alpha/inference/rerank",
            body=await async_maybe_transform(
                {
                    "items": items,
                    "model": model,
                    "query": query,
                    "max_num_results": max_num_results,
                },
                inference_rerank_params.InferenceRerankParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                post_parser=DataWrapper[InferenceRerankResponse]._unwrapper,
            ),
            cast_to=cast(Type[InferenceRerankResponse], DataWrapper[InferenceRerankResponse]),
        )


class InferenceResourceWithRawResponse:
    def __init__(self, inference: InferenceResource) -> None:
        self._inference = inference

        self.rerank = to_raw_response_wrapper(
            inference.rerank,
        )


class AsyncInferenceResourceWithRawResponse:
    def __init__(self, inference: AsyncInferenceResource) -> None:
        self._inference = inference

        self.rerank = async_to_raw_response_wrapper(
            inference.rerank,
        )


class InferenceResourceWithStreamingResponse:
    def __init__(self, inference: InferenceResource) -> None:
        self._inference = inference

        self.rerank = to_streamed_response_wrapper(
            inference.rerank,
        )


class AsyncInferenceResourceWithStreamingResponse:
    def __init__(self, inference: AsyncInferenceResource) -> None:
        self._inference = inference

        self.rerank = async_to_streamed_response_wrapper(
            inference.rerank,
        )
