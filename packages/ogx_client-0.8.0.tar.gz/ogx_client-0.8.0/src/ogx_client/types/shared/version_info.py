# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["VersionInfo"]


class VersionInfo(BaseModel):
    """Version information for the service."""

    version: str
    """The version string of the service"""
