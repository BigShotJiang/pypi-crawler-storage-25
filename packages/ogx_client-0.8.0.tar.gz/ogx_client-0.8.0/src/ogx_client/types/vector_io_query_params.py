# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Literal, Required, TypeAlias, TypedDict

__all__ = [
    "VectorIoQueryParams",
    "Query",
    "QueryImageContentItemInput",
    "QueryImageContentItemInputImage",
    "QueryImageContentItemInputImageURL",
    "QueryTextContentItem",
    "QueryListImageContentItemInputTextContentItem",
    "QueryListImageContentItemInputTextContentItemImageContentItemInput",
    "QueryListImageContentItemInputTextContentItemImageContentItemInputImage",
    "QueryListImageContentItemInputTextContentItemImageContentItemInputImageURL",
    "QueryListImageContentItemInputTextContentItemTextContentItem",
]


class VectorIoQueryParams(TypedDict, total=False):
    query: Required[Query]
    """The query content to search for."""

    vector_store_id: Required[str]
    """The ID of the vector store to query."""

    params: Optional[Dict[str, object]]
    """Additional query parameters."""


class QueryImageContentItemInputImageURL(TypedDict, total=False):
    """A URL reference to external content."""

    uri: Required[str]


class QueryImageContentItemInputImage(TypedDict, total=False):
    """A URL or a base64 encoded string"""

    data: Optional[str]

    url: Optional[QueryImageContentItemInputImageURL]
    """A URL reference to external content."""


class QueryImageContentItemInput(TypedDict, total=False):
    """A image content item"""

    image: Required[QueryImageContentItemInputImage]
    """A URL or a base64 encoded string"""

    type: Literal["image"]


class QueryTextContentItem(TypedDict, total=False):
    """A text content item"""

    text: Required[str]

    type: Literal["text"]


class QueryListImageContentItemInputTextContentItemImageContentItemInputImageURL(TypedDict, total=False):
    """A URL reference to external content."""

    uri: Required[str]


class QueryListImageContentItemInputTextContentItemImageContentItemInputImage(TypedDict, total=False):
    """A URL or a base64 encoded string"""

    data: Optional[str]

    url: Optional[QueryListImageContentItemInputTextContentItemImageContentItemInputImageURL]
    """A URL reference to external content."""


class QueryListImageContentItemInputTextContentItemImageContentItemInput(TypedDict, total=False):
    """A image content item"""

    image: Required[QueryListImageContentItemInputTextContentItemImageContentItemInputImage]
    """A URL or a base64 encoded string"""

    type: Literal["image"]


class QueryListImageContentItemInputTextContentItemTextContentItem(TypedDict, total=False):
    """A text content item"""

    text: Required[str]

    type: Literal["text"]


QueryListImageContentItemInputTextContentItem: TypeAlias = Union[
    QueryListImageContentItemInputTextContentItemImageContentItemInput,
    QueryListImageContentItemInputTextContentItemTextContentItem,
]

Query: TypeAlias = Union[
    str, QueryImageContentItemInput, QueryTextContentItem, Iterable[QueryListImageContentItemInputTextContentItem]
]
