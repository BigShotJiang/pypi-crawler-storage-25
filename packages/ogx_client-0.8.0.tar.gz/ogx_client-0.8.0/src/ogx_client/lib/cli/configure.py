from __future__ import annotations

import os
from urllib.parse import urlparse

import yaml
import click
from prompt_toolkit import prompt
from prompt_toolkit.validation import Validator
from ogx_client.lib.cli.constants import OGX_CLIENT_CONFIG_DIR, get_config_file_path


def get_config():
    config_file = get_config_file_path()
    if config_file.exists():
        with open(config_file, "r") as f:
            return yaml.safe_load(f)
    return None


@click.command()
@click.help_option("-h", "--help")
@click.option("--endpoint", type=str, help="OGX server endpoint", default="")
@click.option("--api-key", type=str, help="OGX server API key", default="")
def configure(endpoint: str | None, api_key: str | None):
    """Configure OGX Client CLI."""
    os.makedirs(OGX_CLIENT_CONFIG_DIR, exist_ok=True)
    config_path = get_config_file_path()

    if endpoint != "":
        final_endpoint = endpoint
    else:
        final_endpoint = prompt(
            "> Enter the endpoint of the OGX server: ",
            validator=Validator.from_callable(
                lambda x: len(x) > 0 and (parsed := urlparse(x)).scheme and parsed.netloc,
                error_message="Endpoint cannot be empty and must be a valid URL, please enter a valid endpoint",
            ),
        )

    if api_key != "":
        final_api_key = api_key
    else:
        final_api_key = prompt(
            "> Enter the API key (leave empty if no key is needed): ",
        )

    # Prepare config dict before writing it
    config_dict = {
        "endpoint": final_endpoint,
    }
    if final_api_key != "":
        config_dict["api_key"] = final_api_key

    with open(config_path, "w") as f:
        f.write(
            yaml.dump(
                config_dict,
                sort_keys=True,
            )
        )

    print(f"Done! You can now use the OGX Client CLI with endpoint {final_endpoint}")  # noqa: T201
