import json
import uuid
from typing import List, Union, Optional

from pydantic import BaseModel, ValidationError

from ..types import ToolCall, CompletionMessage
from ..tool_parser import ToolParser


class Param(BaseModel):
    name: str
    value: Union[str, int, float, bool]


class Action(BaseModel):
    tool_name: str
    tool_params: List[Param]


class ReActOutput(BaseModel):
    thought: str
    action: Optional[Action]
    answer: Optional[str]


class ReActToolParser(ToolParser):
    def get_tool_calls(self, output_message: CompletionMessage) -> List[ToolCall]:
        tool_calls = []
        response_text = str(output_message.content)
        try:
            react_output = ReActOutput.model_validate_json(response_text)
        except ValidationError as e:
            print(f"Error parsing action: {e}")  # noqa: T201
            return tool_calls

        if react_output.answer:
            return tool_calls

        if react_output.action:
            tool_name = react_output.action.tool_name
            tool_params = react_output.action.tool_params
            params = {param.name: param.value for param in tool_params}
            if tool_name and tool_params:
                call_id = str(uuid.uuid4())
                tool_calls = [
                    ToolCall(
                        call_id=call_id,
                        tool_name=tool_name,
                        arguments=json.dumps(params),
                    )
                ]

        return tool_calls
