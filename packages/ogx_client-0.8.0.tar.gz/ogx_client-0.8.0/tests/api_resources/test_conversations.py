# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from ogx_client import OgxClient, AsyncOgxClient
from tests.utils import assert_matches_type
from ogx_client.types import (
    ConversationObject,
    ConversationDeleteResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestConversations:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: OgxClient) -> None:
        conversation = client.conversations.create()
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: OgxClient) -> None:
        conversation = client.conversations.create(
            items=[
                {
                    "content": "string",
                    "role": "system",
                    "id": "id",
                    "status": "status",
                    "type": "message",
                }
            ],
            metadata={"foo": "string"},
        )
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: OgxClient) -> None:
        response = client.conversations.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        conversation = response.parse()
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: OgxClient) -> None:
        with client.conversations.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            conversation = response.parse()
            assert_matches_type(ConversationObject, conversation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: OgxClient) -> None:
        conversation = client.conversations.retrieve(
            "conversation_id",
        )
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: OgxClient) -> None:
        response = client.conversations.with_raw_response.retrieve(
            "conversation_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        conversation = response.parse()
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: OgxClient) -> None:
        with client.conversations.with_streaming_response.retrieve(
            "conversation_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            conversation = response.parse()
            assert_matches_type(ConversationObject, conversation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: OgxClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `conversation_id` but received ''"):
            client.conversations.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: OgxClient) -> None:
        conversation = client.conversations.update(
            conversation_id="conversation_id",
            metadata={"foo": "string"},
        )
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: OgxClient) -> None:
        response = client.conversations.with_raw_response.update(
            conversation_id="conversation_id",
            metadata={"foo": "string"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        conversation = response.parse()
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: OgxClient) -> None:
        with client.conversations.with_streaming_response.update(
            conversation_id="conversation_id",
            metadata={"foo": "string"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            conversation = response.parse()
            assert_matches_type(ConversationObject, conversation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: OgxClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `conversation_id` but received ''"):
            client.conversations.with_raw_response.update(
                conversation_id="",
                metadata={"foo": "string"},
            )

    @parametrize
    def test_method_delete(self, client: OgxClient) -> None:
        conversation = client.conversations.delete(
            "conversation_id",
        )
        assert_matches_type(ConversationDeleteResponse, conversation, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: OgxClient) -> None:
        response = client.conversations.with_raw_response.delete(
            "conversation_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        conversation = response.parse()
        assert_matches_type(ConversationDeleteResponse, conversation, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: OgxClient) -> None:
        with client.conversations.with_streaming_response.delete(
            "conversation_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            conversation = response.parse()
            assert_matches_type(ConversationDeleteResponse, conversation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: OgxClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `conversation_id` but received ''"):
            client.conversations.with_raw_response.delete(
                "",
            )


class TestAsyncConversations:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncOgxClient) -> None:
        conversation = await async_client.conversations.create()
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncOgxClient) -> None:
        conversation = await async_client.conversations.create(
            items=[
                {
                    "content": "string",
                    "role": "system",
                    "id": "id",
                    "status": "status",
                    "type": "message",
                }
            ],
            metadata={"foo": "string"},
        )
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncOgxClient) -> None:
        response = await async_client.conversations.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        conversation = await response.parse()
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncOgxClient) -> None:
        async with async_client.conversations.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            conversation = await response.parse()
            assert_matches_type(ConversationObject, conversation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncOgxClient) -> None:
        conversation = await async_client.conversations.retrieve(
            "conversation_id",
        )
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncOgxClient) -> None:
        response = await async_client.conversations.with_raw_response.retrieve(
            "conversation_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        conversation = await response.parse()
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncOgxClient) -> None:
        async with async_client.conversations.with_streaming_response.retrieve(
            "conversation_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            conversation = await response.parse()
            assert_matches_type(ConversationObject, conversation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncOgxClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `conversation_id` but received ''"):
            await async_client.conversations.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncOgxClient) -> None:
        conversation = await async_client.conversations.update(
            conversation_id="conversation_id",
            metadata={"foo": "string"},
        )
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncOgxClient) -> None:
        response = await async_client.conversations.with_raw_response.update(
            conversation_id="conversation_id",
            metadata={"foo": "string"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        conversation = await response.parse()
        assert_matches_type(ConversationObject, conversation, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncOgxClient) -> None:
        async with async_client.conversations.with_streaming_response.update(
            conversation_id="conversation_id",
            metadata={"foo": "string"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            conversation = await response.parse()
            assert_matches_type(ConversationObject, conversation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncOgxClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `conversation_id` but received ''"):
            await async_client.conversations.with_raw_response.update(
                conversation_id="",
                metadata={"foo": "string"},
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncOgxClient) -> None:
        conversation = await async_client.conversations.delete(
            "conversation_id",
        )
        assert_matches_type(ConversationDeleteResponse, conversation, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncOgxClient) -> None:
        response = await async_client.conversations.with_raw_response.delete(
            "conversation_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        conversation = await response.parse()
        assert_matches_type(ConversationDeleteResponse, conversation, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncOgxClient) -> None:
        async with async_client.conversations.with_streaming_response.delete(
            "conversation_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            conversation = await response.parse()
            assert_matches_type(ConversationDeleteResponse, conversation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncOgxClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `conversation_id` but received ''"):
            await async_client.conversations.with_raw_response.delete(
                "",
            )
