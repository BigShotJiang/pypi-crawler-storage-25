---
name: sdk-method
description: Add a new SDK method wrapping an API endpoint. Auto-invoked when adding methods to agents.py, trust.py, billing.py, etc.
---

# SDK Method Pattern

Every SDK method follows this pattern:

```python
def list(self, page: int = 1, per_page: int = 20) -> list[Agent]:
    """List all agents.

    Args:
        page: Page number (1-indexed)
        per_page: Results per page (max 100)

    Returns:
        List of Agent objects

    Raises:
        AuthError: If API key is invalid
        ApiError: If the API returns an error
    """
    response = self._client.get("/v1/agents", params={"page": page, "per_page": per_page})
    return [Agent.model_validate(a) for a in response]
```

Rules:
1. Always return Pydantic models, never raw dicts
2. Always include docstring with Args, Returns, Raises
3. Always add type hints on parameters and return type
4. Use self._client (the httpx wrapper) for HTTP calls
5. Add corresponding async method in the async client
6. Add a test in tests/ with pytest-httpx mock
