---
name: pydantic-types
description: Define Pydantic v2 models for API response types. Use when adding new response schemas.
---

# Pydantic Type Pattern

All API responses are typed as Pydantic v2 models in types.py:

```python
from pydantic import BaseModel, ConfigDict
from datetime import datetime

class Agent(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    description: str
    framework: str
    compute_tier: str
    status: str
    created_at: datetime
    updated_at: datetime

class TrustScore(BaseModel):
    agent_id: str
    overall_score: float
    grade: str
    dimensions: dict[str, float]
    computed_at: datetime
```

Rules:
1. Use ConfigDict(populate_by_name=True) for snake_case ↔ camelCase
2. Use datetime for timestamps (auto-parsed from ISO 8601)
3. Use Optional[] for nullable fields
4. Match the API response schema from api.ainfera.ai/docs exactly
