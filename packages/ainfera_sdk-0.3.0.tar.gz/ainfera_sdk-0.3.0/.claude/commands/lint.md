---
description: Lint and type check
---
```bash
ruff check ainfera_sdk/ --fix
ruff format ainfera_sdk/
mypy ainfera_sdk/ --strict
```
