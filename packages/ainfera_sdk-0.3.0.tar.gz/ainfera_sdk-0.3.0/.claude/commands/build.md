---
description: Build package
---
```bash
python -m build
pip install dist/ainfera_sdk-*.whl --force-reinstall
python -c "import ainfera_sdk; print(ainfera_sdk.__version__)"
```
