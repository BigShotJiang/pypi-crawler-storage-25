---
description: Tag and release to PyPI
---
Ask version number. Update pyproject.toml + CHANGELOG.md.
Commit "release: v{version}", tag v{version}, push --tags.
GitHub Actions auto-publishes.
