"""Inspect trust history and anomalies, and record a trust event.

Run:
    export AINFERA_API_KEY=ainf_sk_live_...
    python examples/trust_monitoring.py <agent_id>
"""

from __future__ import annotations

import sys

from ainfera_sdk import Ainfera


def main() -> None:
    if len(sys.argv) < 2:
        print("usage: python trust_monitoring.py <agent_id>")
        sys.exit(1)

    agent_id = sys.argv[1]
    client = Ainfera()

    score = client.trust.get_score(agent_id)
    print(f"Current: {score.overall_score} ({score.grade})")

    history = client.trust.get_history(agent_id)
    print(f"\nHistory ({len(history)} points):")
    for entry in history[-5:]:
        print(f"  {entry.recorded_at:%Y-%m-%d}  {entry.overall_score:>5.1f}  {entry.grade}")

    anomalies = client.trust.get_anomalies(agent_id)
    print(f"\nAnomalies ({len(anomalies)}):")
    for a in anomalies:
        print(f"  [{a.severity}] {a.anomaly_type}: {a.description}")

    client.trust.record_event(
        agent_id,
        event_type="manual_review",
        data={"reviewer": "ops@ainfera.ai", "verdict": "ok"},
    )
    print("\nRecorded manual_review event.")
    print(f"Badge: {client.trust.badge_url(agent_id)}")


if __name__ == "__main__":
    main()
