"""Deploy a LangChain agent and run a single invocation.

Run:
    export AINFERA_API_KEY=ainf_sk_live_...
    python examples/deploy_langchain.py
"""

from __future__ import annotations

from ainfera_sdk import Ainfera


def main() -> None:
    client = Ainfera()

    agent = client.agents.create(
        name="research-assistant",
        framework="langchain",
        description="LangChain ReAct agent with web search tools",
        compute_tier="standard",
    )
    print(f"Deployed agent: {agent.id} (status={agent.status})")

    run = client.execution.invoke(
        agent.id,
        input={"query": "What is the capital of Singapore?"},
    )
    print(f"Run {run.id}: status={run.status}")
    if run.output:
        print("Output:", run.output)


if __name__ == "__main__":
    main()
