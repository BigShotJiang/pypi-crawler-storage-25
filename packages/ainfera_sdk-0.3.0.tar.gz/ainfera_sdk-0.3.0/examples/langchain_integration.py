"""Register a LangChain agent with Ainfera and publish it to the marketplace."""

from __future__ import annotations

from ainfera_sdk import AinferaClient, TrustBadge


def main() -> None:
    client = AinferaClient()  # reads AINFERA_API_KEY from env

    agent = client.register_agent(
        {
            "name": "research-agent",
            "framework": "langchain",
            "description": "Academic paper summarization agent",
            "trust": {"min_score": 700, "auto_kill_below": 400},
        }
    )

    print(f"Registered: {agent.id}")
    print(f"Trust: {agent.grade} {agent.trust_score}")

    # Publish to the public marketplace
    published = client.publish_agent(agent.id)
    print(f"Published at: https://ainfera.ai/trust/{published.id}")

    # Print a README badge
    print()
    print(TrustBadge.markdown_badge(agent.id))


if __name__ == "__main__":
    main()
