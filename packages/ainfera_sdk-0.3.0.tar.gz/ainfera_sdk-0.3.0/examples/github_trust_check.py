"""Run a trust check as part of a CI/CD pipeline (e.g. GitHub Actions).

Exits non-zero if trust dropped below threshold so the CI job fails the PR.
"""

from __future__ import annotations

import os
import sys

from ainfera_sdk import AinferaClient


def main() -> int:
    client = AinferaClient(api_key=os.environ["AINFERA_API_KEY"])

    agent_id = os.environ.get("AINFERA_AGENT_ID", "research-agent")
    commit_sha = os.environ["GITHUB_SHA"]
    base_sha = os.environ.get("GITHUB_BASE_SHA")

    result = client.trust_check(agent_id, commit_sha=commit_sha, base_sha=base_sha)

    print(f"Trust: {result.score_before} → {result.score_after} (Δ{result.diff:+d})")
    if not result.passed:
        print(f"Failed threshold ({result.threshold}).")
        print(result.comment_markdown)
        return 1

    print("Trust check passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
