"""Ainfera SDK quickstart — trust scoring, discovery, and embeddable badge.

Run:
    export AINFERA_API_KEY=ainf_sk_live_...
    python examples/quickstart.py
"""

from __future__ import annotations

from ainfera_sdk import AinferaClient, TrustBadge


def main() -> None:
    client = AinferaClient(api_key=None)  # reads AINFERA_API_KEY from env

    # Trust score (safety dimension evaluated via NeMo Guardrails)
    score = client.get_trust_score("research-agent")
    print(f"Trust: {score.grade} {score.overall_score}")
    for dim, value in score.dimensions.items():
        print(f"  {dim:>12}: {value}")

    # Marketplace search (NIM-powered semantic search)
    agents = client.search_agents("research assistant", min_trust=700)
    print(f"\nFound {len(agents)} matching agents:")
    for agent in agents:
        print(f"  {agent.name} — {agent.grade}")

    # Embeddable trust badge
    print()
    print(TrustBadge.markdown_badge("research-agent"))


if __name__ == "__main__":
    main()
