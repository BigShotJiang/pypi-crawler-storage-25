# Changelog

All notable changes to `ainfera-sdk` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-04-13

### Added
- Initial SDK release
- Sync and async clients (`Ainfera`, `AsyncAinfera`)
- Resources: agents, trust, billing, execution, registry
- Pydantic v2 response models
- Typed exceptions: `AuthError`, `NotFoundError`, `ValidationError`, `ServerError`
- Examples: quickstart, deploy LangChain agent, trust monitoring
- Test suite using `pytest-httpx`
