"""Typed exceptions for the Ainfera SDK."""

from __future__ import annotations

from typing import Any


class AinferaError(Exception):
    """Base class for all Ainfera SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_body = response_body

    def __str__(self) -> str:
        if self.status_code is not None:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthError(AinferaError):
    """Raised when the API key is missing, invalid, or lacks permission (HTTP 401/403)."""


class NotFoundError(AinferaError):
    """Raised when a requested resource does not exist (HTTP 404)."""


class ValidationError(AinferaError):
    """Raised when the request payload is invalid (HTTP 400/422)."""


class RateLimitError(AinferaError):
    """Raised when the client has been rate limited (HTTP 429)."""


class ServerError(AinferaError):
    """Raised when the API returns a 5xx error."""


class ApiError(AinferaError):
    """Generic non-2xx error not covered by a more specific exception."""


def raise_for_status(status_code: int, message: str, body: Any = None) -> None:
    """Raise the exception class that matches the given HTTP status code."""
    if status_code in (401, 403):
        raise AuthError(message, status_code, body)
    if status_code == 404:
        raise NotFoundError(message, status_code, body)
    if status_code in (400, 422):
        raise ValidationError(message, status_code, body)
    if status_code == 429:
        raise RateLimitError(message, status_code, body)
    if 500 <= status_code < 600:
        raise ServerError(message, status_code, body)
    raise ApiError(message, status_code, body)
