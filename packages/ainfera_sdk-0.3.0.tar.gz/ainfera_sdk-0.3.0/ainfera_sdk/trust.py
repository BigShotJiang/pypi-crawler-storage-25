"""Trust resource — scores, history, anomalies, events, and badges."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .types import Anomaly, TrustCheckResult, TrustEvent, TrustHistoryEntry, TrustScore

if TYPE_CHECKING:
    from .client import _AsyncHttp, _SyncHttp


class TrustResource:
    """Synchronous trust-scoring API."""

    def __init__(self, http: _SyncHttp) -> None:
        self._http = http

    def get_score(self, agent_id: str) -> TrustScore:
        """Return the current composite trust score for an agent."""
        return TrustScore.model_validate(self._http.get(f"/v1/trust/{agent_id}/score"))

    def get_history(self, agent_id: str) -> list[TrustHistoryEntry]:
        """Return the full trust score history for an agent."""
        data = self._http.get(f"/v1/trust/{agent_id}/history")
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [TrustHistoryEntry.model_validate(h) for h in items]

    def get_anomalies(self, agent_id: str) -> list[Anomaly]:
        """Return anomalies detected for an agent."""
        data = self._http.get(f"/v1/trust/{agent_id}/anomalies")
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [Anomaly.model_validate(a) for a in items]

    def record_event(
        self,
        agent_id: str,
        *,
        event_type: str,
        data: dict[str, Any] | None = None,
    ) -> TrustEvent:
        """Record a trust-relevant event against an agent."""
        payload = {"event_type": event_type, "data": data or {}}
        return TrustEvent.model_validate(
            self._http.post(f"/v1/trust/{agent_id}/events", json=payload)
        )

    def recompute(self, agent_id: str) -> TrustScore:
        """Force a recomputation of the composite trust score."""
        return TrustScore.model_validate(self._http.post(f"/v1/trust/{agent_id}/recompute"))

    def evaluate(self, agent_id: str) -> TrustScore:
        """Trigger a server-side safety/quality evaluation (NeMo Guardrails)."""
        return TrustScore.model_validate(self._http.post(f"/v1/trust/{agent_id}/evaluate"))

    def check(
        self,
        agent_id: str,
        *,
        commit_sha: str,
        base_sha: str | None = None,
    ) -> TrustCheckResult:
        """Run a CI/CD trust check comparing the agent's score at two commits."""
        payload: dict[str, Any] = {"commit_sha": commit_sha}
        if base_sha is not None:
            payload["base_sha"] = base_sha
        return TrustCheckResult.model_validate(
            self._http.post(f"/v1/trust/{agent_id}/check", json=payload)
        )

    def badge_url(self, agent_id: str) -> str:
        """Return the URL of the SVG trust badge for an agent."""
        base = self._http._client.base_url
        return f"{str(base).rstrip('/')}/v1/trust/{agent_id}/badge.svg"


class AsyncTrustResource:
    """Asynchronous trust-scoring API."""

    def __init__(self, http: _AsyncHttp) -> None:
        self._http = http

    async def get_score(self, agent_id: str) -> TrustScore:
        return TrustScore.model_validate(await self._http.get(f"/v1/trust/{agent_id}/score"))

    async def get_history(self, agent_id: str) -> list[TrustHistoryEntry]:
        data = await self._http.get(f"/v1/trust/{agent_id}/history")
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [TrustHistoryEntry.model_validate(h) for h in items]

    async def get_anomalies(self, agent_id: str) -> list[Anomaly]:
        data = await self._http.get(f"/v1/trust/{agent_id}/anomalies")
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [Anomaly.model_validate(a) for a in items]

    async def record_event(
        self,
        agent_id: str,
        *,
        event_type: str,
        data: dict[str, Any] | None = None,
    ) -> TrustEvent:
        payload = {"event_type": event_type, "data": data or {}}
        return TrustEvent.model_validate(
            await self._http.post(f"/v1/trust/{agent_id}/events", json=payload)
        )

    async def recompute(self, agent_id: str) -> TrustScore:
        return TrustScore.model_validate(await self._http.post(f"/v1/trust/{agent_id}/recompute"))

    async def evaluate(self, agent_id: str) -> TrustScore:
        return TrustScore.model_validate(await self._http.post(f"/v1/trust/{agent_id}/evaluate"))

    async def check(
        self,
        agent_id: str,
        *,
        commit_sha: str,
        base_sha: str | None = None,
    ) -> TrustCheckResult:
        payload: dict[str, Any] = {"commit_sha": commit_sha}
        if base_sha is not None:
            payload["base_sha"] = base_sha
        return TrustCheckResult.model_validate(
            await self._http.post(f"/v1/trust/{agent_id}/check", json=payload)
        )

    def badge_url(self, agent_id: str) -> str:
        base = self._http._client.base_url
        return f"{str(base).rstrip('/')}/v1/trust/{agent_id}/badge.svg"


__all__ = ["AsyncTrustResource", "TrustResource"]
