"""Execution resource — invoke agents and inspect runs."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .types import ExecutionRun

if TYPE_CHECKING:
    from .client import _AsyncHttp, _SyncHttp


class ExecutionResource:
    """Synchronous execution API."""

    def __init__(self, http: _SyncHttp) -> None:
        self._http = http

    def invoke(self, agent_id: str, *, input: dict[str, Any]) -> ExecutionRun:
        """Invoke an agent and return the completed run."""
        return ExecutionRun.model_validate(
            self._http.post(f"/v1/agents/{agent_id}/invoke", json={"input": input})
        )

    def get_run(self, run_id: str) -> ExecutionRun:
        """Fetch a single execution run by id."""
        return ExecutionRun.model_validate(self._http.get(f"/v1/runs/{run_id}"))

    def list_runs(self, agent_id: str, *, limit: int = 20) -> list[ExecutionRun]:
        """List recent execution runs for an agent."""
        data = self._http.get(f"/v1/agents/{agent_id}/runs", params={"limit": limit})
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [ExecutionRun.model_validate(r) for r in items]


class AsyncExecutionResource:
    """Asynchronous execution API."""

    def __init__(self, http: _AsyncHttp) -> None:
        self._http = http

    async def invoke(self, agent_id: str, *, input: dict[str, Any]) -> ExecutionRun:
        return ExecutionRun.model_validate(
            await self._http.post(f"/v1/agents/{agent_id}/invoke", json={"input": input})
        )

    async def get_run(self, run_id: str) -> ExecutionRun:
        return ExecutionRun.model_validate(await self._http.get(f"/v1/runs/{run_id}"))

    async def list_runs(self, agent_id: str, *, limit: int = 20) -> list[ExecutionRun]:
        data = await self._http.get(f"/v1/agents/{agent_id}/runs", params={"limit": limit})
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [ExecutionRun.model_validate(r) for r in items]


__all__ = ["AsyncExecutionResource", "ExecutionResource"]
