"""CrewAI integration — trust-score and optionally gate crew executions.

Usage:
    from ainfera_sdk.crewai import ainfera_trust

    @ainfera_trust(api_key="your-key", agent_id="my-crew", threshold=700)
    def run_crew():
        crew = Crew(agents=[...], tasks=[...])
        return crew.kickoff()

If ``threshold`` is set and the post-run composite score falls below it,
``TrustGateError`` is raised so CI / production gates can halt low-trust runs.
"""

from __future__ import annotations

import functools
import time
from collections.abc import Callable
from typing import Any, TypeVar, cast

from .client import Ainfera
from .exceptions import AinferaError

F = TypeVar("F", bound=Callable[..., Any])


class TrustGateError(AinferaError):
    """Raised when a gated crew run falls below the configured trust threshold."""

    def __init__(self, agent_id: str, score: float, threshold: int) -> None:
        super().__init__(
            f"Trust score {score:.0f} for agent '{agent_id}' is below threshold {threshold}"
        )
        self.agent_id = agent_id
        self.score = score
        self.threshold = threshold


def ainfera_trust(
    func: F | None = None,
    *,
    api_key: str | None = None,
    agent_id: str | None = None,
    base_url: str | None = None,
    threshold: int | None = None,
    client: Ainfera | None = None,
) -> Callable[[F], F] | F:
    """Decorator that records a crew execution against the Ainfera trust API.

    Can be used as ``@ainfera_trust`` or ``@ainfera_trust(agent_id=...)``.

    Parameters
    ----------
    api_key:
        Ainfera API key. Falls back to ``AINFERA_API_KEY``.
    agent_id:
        Agent id to score. Defaults to the decorated function's name.
    threshold:
        If set, raise ``TrustGateError`` when the post-run score is lower.
    client:
        Optional pre-built ``Ainfera`` client.
    """

    def decorator(fn: F) -> F:
        resolved_agent_id = agent_id or fn.__name__

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            c = client or Ainfera(api_key=api_key, base_url=base_url)
            owns = client is None
            start = time.monotonic()
            error: BaseException | None = None
            try:
                result = fn(*args, **kwargs)
            except BaseException as exc:
                error = exc
                raise
            finally:
                duration_ms = int((time.monotonic() - start) * 1000)
                try:
                    c.trust.record_event(
                        resolved_agent_id,
                        event_type=(
                            "crewai.kickoff_error" if error else "crewai.kickoff"
                        ),
                        data={
                            "duration_ms": duration_ms,
                            "error": (
                                f"{type(error).__name__}: {error}" if error else None
                            ),
                        },
                    )
                    if threshold is not None and error is None:
                        score = c.get_trust_score(resolved_agent_id)
                        if score.overall_score < threshold:
                            raise TrustGateError(
                                resolved_agent_id, score.overall_score, threshold
                            )
                finally:
                    if owns:
                        c.close()
            return result

        return cast(F, wrapper)

    if func is not None:
        return decorator(func)
    return decorator


__all__ = ["TrustGateError", "ainfera_trust"]
