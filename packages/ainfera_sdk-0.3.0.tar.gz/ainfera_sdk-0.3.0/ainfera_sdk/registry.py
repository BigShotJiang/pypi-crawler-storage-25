"""Registry resource — browse publicly discoverable agents (no auth required)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .types import PublicAgent, RegistryStats

if TYPE_CHECKING:
    from .client import _AsyncHttp, _SyncHttp


class RegistryResource:
    """Synchronous public registry API.

    Semantic search is powered by NVIDIA NIM embeddings server-side.
    """

    def __init__(self, http: _SyncHttp) -> None:
        self._http = http

    def search(
        self,
        *,
        q: str | None = None,
        framework: str | None = None,
        min_trust: int | None = None,
        trust_grade: str | None = None,
        page: int = 1,
        per_page: int = 20,
        limit: int | None = None,
    ) -> list[PublicAgent]:
        """Search publicly listed agents."""
        params: dict[str, str | int] = {
            "page": page,
            "per_page": limit if limit is not None else per_page,
        }
        if q:
            params["q"] = q
        if framework:
            params["framework"] = framework
        if min_trust is not None:
            params["min_trust"] = min_trust
        if trust_grade:
            params["trust_grade"] = trust_grade
        data = self._http.get("/v1/registry/agents", params=params)
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [PublicAgent.model_validate(a) for a in items]

    def get(self, agent_id: str) -> PublicAgent:
        """Fetch a single publicly listed agent by id."""
        return PublicAgent.model_validate(self._http.get(f"/v1/registry/agents/{agent_id}"))

    def stats(self) -> RegistryStats:
        """Return aggregate registry statistics."""
        return RegistryStats.model_validate(self._http.get("/v1/registry/stats"))

    def publish(self, agent_id: str) -> PublicAgent:
        """Publish an owned agent to the public registry."""
        return PublicAgent.model_validate(
            self._http.post(f"/v1/registry/agents/{agent_id}/publish")
        )

    def register(self, config: dict[str, Any]) -> PublicAgent:
        """Register a new agent from an ainfera.yaml-style config dict."""
        return PublicAgent.model_validate(self._http.post("/v1/registry/agents", json=config))


class AsyncRegistryResource:
    """Asynchronous public registry API."""

    def __init__(self, http: _AsyncHttp) -> None:
        self._http = http

    async def search(
        self,
        *,
        q: str | None = None,
        framework: str | None = None,
        min_trust: int | None = None,
        trust_grade: str | None = None,
        page: int = 1,
        per_page: int = 20,
        limit: int | None = None,
    ) -> list[PublicAgent]:
        params: dict[str, str | int] = {
            "page": page,
            "per_page": limit if limit is not None else per_page,
        }
        if q:
            params["q"] = q
        if framework:
            params["framework"] = framework
        if min_trust is not None:
            params["min_trust"] = min_trust
        if trust_grade:
            params["trust_grade"] = trust_grade
        data = await self._http.get("/v1/registry/agents", params=params)
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [PublicAgent.model_validate(a) for a in items]

    async def get(self, agent_id: str) -> PublicAgent:
        return PublicAgent.model_validate(await self._http.get(f"/v1/registry/agents/{agent_id}"))

    async def stats(self) -> RegistryStats:
        return RegistryStats.model_validate(await self._http.get("/v1/registry/stats"))

    async def publish(self, agent_id: str) -> PublicAgent:
        return PublicAgent.model_validate(
            await self._http.post(f"/v1/registry/agents/{agent_id}/publish")
        )

    async def register(self, config: dict[str, Any]) -> PublicAgent:
        return PublicAgent.model_validate(
            await self._http.post("/v1/registry/agents", json=config)
        )


__all__ = ["AsyncRegistryResource", "RegistryResource"]
