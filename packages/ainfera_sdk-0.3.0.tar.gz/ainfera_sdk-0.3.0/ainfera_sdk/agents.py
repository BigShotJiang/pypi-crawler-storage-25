"""Agents resource — create, list, update, kill, and delete deployed agents."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .types import Agent

if TYPE_CHECKING:
    from .client import _AsyncHttp, _SyncHttp


def _agent_payload(
    *,
    name: str,
    framework: str,
    description: str | None,
    compute_tier: str | None,
    extra: dict[str, Any] | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"name": name, "framework": framework}
    if description is not None:
        payload["description"] = description
    if compute_tier is not None:
        payload["compute_tier"] = compute_tier
    if extra:
        payload.update(extra)
    return payload


class AgentsResource:
    """Synchronous agents API."""

    def __init__(self, http: _SyncHttp) -> None:
        self._http = http

    def list(self, *, page: int = 1, per_page: int = 20) -> list[Agent]:
        """List agents owned by the authenticated account.

        Args:
            page: Page number (1-indexed).
            per_page: Results per page (max 100).

        Returns:
            A list of :class:`Agent` objects.
        """
        data = self._http.get("/v1/agents", params={"page": page, "per_page": per_page})
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [Agent.model_validate(a) for a in items]

    def get(self, agent_id: str) -> Agent:
        """Fetch a single agent by id."""
        data = self._http.get(f"/v1/agents/{agent_id}")
        return Agent.model_validate(data)

    def create(
        self,
        *,
        name: str,
        framework: str,
        description: str | None = None,
        compute_tier: str | None = None,
        **extra: Any,
    ) -> Agent:
        """Deploy a new agent."""
        payload = _agent_payload(
            name=name,
            framework=framework,
            description=description,
            compute_tier=compute_tier,
            extra=extra,
        )
        data = self._http.post("/v1/agents", json=payload)
        return Agent.model_validate(data)

    def update(self, agent_id: str, **kwargs: Any) -> Agent:
        """Update mutable fields on an agent."""
        data = self._http.patch(f"/v1/agents/{agent_id}", json=kwargs)
        return Agent.model_validate(data)

    def delete(self, agent_id: str) -> None:
        """Permanently delete an agent."""
        self._http.delete(f"/v1/agents/{agent_id}")

    def kill(self, agent_id: str) -> None:
        """Emergency-stop an agent — halts all pending and in-flight executions."""
        self._http.post(f"/v1/agents/{agent_id}/kill")

    def unkill(self, agent_id: str) -> None:
        """Reverse a prior :meth:`kill` and return the agent to service."""
        self._http.post(f"/v1/agents/{agent_id}/unkill")


class AsyncAgentsResource:
    """Asynchronous agents API."""

    def __init__(self, http: _AsyncHttp) -> None:
        self._http = http

    async def list(self, *, page: int = 1, per_page: int = 20) -> list[Agent]:
        data = await self._http.get("/v1/agents", params={"page": page, "per_page": per_page})
        items = data["items"] if isinstance(data, dict) and "items" in data else data
        return [Agent.model_validate(a) for a in items]

    async def get(self, agent_id: str) -> Agent:
        data = await self._http.get(f"/v1/agents/{agent_id}")
        return Agent.model_validate(data)

    async def create(
        self,
        *,
        name: str,
        framework: str,
        description: str | None = None,
        compute_tier: str | None = None,
        **extra: Any,
    ) -> Agent:
        payload = _agent_payload(
            name=name,
            framework=framework,
            description=description,
            compute_tier=compute_tier,
            extra=extra,
        )
        data = await self._http.post("/v1/agents", json=payload)
        return Agent.model_validate(data)

    async def update(self, agent_id: str, **kwargs: Any) -> Agent:
        data = await self._http.patch(f"/v1/agents/{agent_id}", json=kwargs)
        return Agent.model_validate(data)

    async def delete(self, agent_id: str) -> None:
        await self._http.delete(f"/v1/agents/{agent_id}")

    async def kill(self, agent_id: str) -> None:
        await self._http.post(f"/v1/agents/{agent_id}/kill")

    async def unkill(self, agent_id: str) -> None:
        await self._http.post(f"/v1/agents/{agent_id}/unkill")


__all__ = ["AgentsResource", "AsyncAgentsResource"]
